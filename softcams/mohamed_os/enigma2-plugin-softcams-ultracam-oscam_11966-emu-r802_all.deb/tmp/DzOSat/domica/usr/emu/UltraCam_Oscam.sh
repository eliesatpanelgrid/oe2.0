#!/bin/bash
#### "***********************************************"
#### "*       ..:: Script by MOHAMED_OS ::..        *"
#### "*  Support: https://github.com/MOHAMED19OS    *"
#### "*       E-Mail: mohamed19eng@gmail.com        *"
#### "***********************************************"

CAMNAME="UltraCam_Oscam"
CAM_BIN="OSCam_11966-r802"
BINARY="UltraCam"

remove_tmp() {
  rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/oscam* /tmp/.oscam
}

case "$1" in
start)
  remove_tmp
  /usr/bin/"${CAM_BIN}" --config-dir /etc/tuxbox/config --daemon --pidfile /tmp/"${CAM_BIN}".pid --restart 2 &
  /etc/tuxbox/"${BINARY,,}"/"${BINARY,,}" --config-dir /etc/tuxbox/"${BINARY,,}" --daemon --pidfile /tmp/"${BINARY}".pid --restart 2 &
  ;;
stop)
  killall -9 ${CAM_BIN} 2>/dev/null
  killall -9 ${BINARY,,} 2>/dev/null
  sleep 2
  remove_tmp
  ;;
*)
  $0 stop
  exit 0
  ;;
esac

exit 0
