#!/bin/bash
#### "***********************************************"
#### "*       ..:: Script by MOHAMED_OS ::..        *"
#### "*  Support: https://github.com/MOHAMED19OS    *"
#### "*       E-Mail: mohamed19eng@gmail.com        *"
#### "***********************************************"

CAMNAME="GosatPlus_Oscam"
CAM_BIN="OSCam_11966-r802"
BINARY="GosatPlus"

remove_tmp() {
	rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/oscam* /tmp/.oscam
}

case "$1" in
start)
	echo "[SCRIPT] $1: $CAMNAME"
	remove_tmp
	/usr/bin/"${CAM_BIN}" --config-dir /etc/tuxbox/config --daemon --pidfile /tmp/"${CAM_BIN}".pid --restart 2 &
	/usr/bin/"${BINARY}" --config-dir /etc/tuxbox/"${BINARY}" --daemon --pidfile /tmp/"${BINARY}".pid --restart 2 &
	;;
stop)
	echo "[SCRIPT] $1: $CAMNAME"
	killall -9 ${CAM_BIN} 2>/dev/null
	killall -9 ${BINARY} 2>/dev/null
	sleep 1
	remove_tmp
	;;
*)
	$0 stop
	exit 0
	;;
esac

exit 0
