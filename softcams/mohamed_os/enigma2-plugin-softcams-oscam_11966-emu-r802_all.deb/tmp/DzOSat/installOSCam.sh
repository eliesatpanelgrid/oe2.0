#!/bin/bash
#### "***********************************************"
#### "*       ..:: Script by MOHAMED_OS ::..        *"
#### "*  Support: https://github.com/MOHAMED19OS    *"
#### "*       E-Mail: mohamed19eng@gmail.com        *"
#### "***********************************************"
FIN="<--------------------------------------------->"
sslVersion=$(openssl version | awk '{print $2}' | cut -d '.' -f 1)

#### Binary File ####
BIN_FILES="oscam"
BIN="OSCam_11966-r802"

##### Path File #####
TMPDIR="/tmp/DzOSat"
CONFIGPATH='/etc/tuxbox/config'

if [ "${sslVersion}" = 3 ]; then
    SSL_VERSION="Openssl-3.6"
elif [ "${sslVersion}" = 4 ]; then
    SSL_VERSION="Openssl-4.0"
fi

declare -A arch_map=(
    ["armv7l"]="ARM"
    ["mips"]="MIPS"
    ["7401c0"]="MIPS"
    ["aarch64"]="AARCH64"
    ["sh4"]="SH4"
)
platform=${arch_map["$(uname -m)"]:-"unknown"}

##### Bianry Path #####
if [ "${sslVersion}" = 3 ] || [ "${sslVersion}" = 4 ]; then
    rm -rf "${TMPDIR}/${platform}/${BIN:?}"
    mv "${TMPDIR}/${platform}/${BIN_FILES}-${SSL_VERSION}" "${TMPDIR}/${platform}/${BIN}"
fi
BinaryPath="${TMPDIR}/${platform}/${BIN}"

#### checking your device and bin file #####
echo ${FIN}
echo ":I'm checking your device processor ..."
echo "OpenSSL version: $(openssl version | awk '{print $2}')"

if [ "${platform}" == "unknown" ];then
    echo "Sorry, your device does not have the proper Emu :("
    rm -rf ${TMPDIR} >/dev/null 2>&1
    exit 1
fi

echo ":Your Device IS ${platform} processor ..."
if [ ! -f "${BinaryPath}" ]; then
    echo "Bin file Missing :("
    rm -rf ${TMPDIR} >/dev/null 2>&1
    exit 1
else
    mv -f "${BinaryPath}" ${TMPDIR} >/dev/null 2>&1
fi

####
if [ -r /usr/lib/enigma2/python/Plugins/Extensions/Manager ]; then
    echo "Levi45 Manager"
    cp -rf ${TMPDIR}/SatLodge/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/Extensions/tvManager ]; then
    echo "TV Manager"
    cp -rf ${TMPDIR}/SatLodge/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/Extensions/nssManager ]; then
    echo "NSS Manager"
    cp -rf ${TMPDIR}/SatLodge/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatcamManager ]; then
    echo "DreamOSat camManager"
    cp -rf ${TMPDIR}/DreamOSat/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "OpenNFR" /etc/image-version; then
    echo "OpenNFR image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Blackhole ]; then
    echo "Blackhole image"
    cp -rf ${TMPDIR}/BH/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -f /usr/lib/enigma2/python/Screens/BpBlue.pyc ]; then
    echo "OpenBlackhole image"
    cp -rf ${TMPDIR}/BH/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "OpenSPA" /etc/image-version; then
    echo "OpenSPA image"
    cp -rf ${TMPDIR}/dddemon/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "openATV" /etc/image-version; then
    echo "openATV image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/OPENDROID ]; then
    echo "OpenDroid image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/EGAMI ]; then
    echo "Egami image"
    if [ ! -d /var/bin ]; then
        ln -sfn /usr/bin /var/bin
    fi
    cp -rf ${TMPDIR}/egami/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/Satdreamgr ]; then
    echo "SatdreamGr image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/Extensions/PowerboardCenter ]; then
    echo "PBnigma-VIX image"
    cp -rf ${TMPDIR}/Pure2/* / >/dev/null 2>&1
    if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam >/dev/null 2>&1
    fi
    cp -rf ${TMPDIR}/${BIN} /usr/bin/cam/ >/dev/null 2>&1
elif grep -qs -i "PURE2" /etc/image-version; then
    echo "PURE2 image"
    cp -rf ${TMPDIR}/Pure2/* / >/dev/null 2>&1
    if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam >/dev/null 2>&1
    fi
    cp -rf ${TMPDIR}/${BIN} /usr/bin/cam/ >/dev/null 2>&1
elif grep -qs -i "openpli" /etc/issue; then
    echo "OpenPLI image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "openvision" /etc/issue; then
    echo "OpenVision image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "cobralibero" /etc/issue; then
    echo "CobraLibero image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/Extensions/PKT ]; then
    echo "PKT image"
    if [ ! -r /var/emu ]; then
        mkdir -p /var/emu >/dev/null 2>&1
    fi
    cp -rf ${TMPDIR}/${BIN} /var/emu/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/SystemPlugins/ViX ]; then
    echo "OpenVIX image"
    if [ ! -r /usr/softcams ]; then
        mkdir -p /usr/softcams >/dev/null 2>&1
    fi
    cp -rf ${TMPDIR}/${BIN} /usr/softcams/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/Extensions/HDF-Toolbox ]; then
    echo "OpenHDF image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/Extensions/LDteam ]; then
    echo "OpenLD image"
    cp -rf ${TMPDIR}/BH/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/Extensions/ExtraAddonss ]; then
    echo "OpenESI image"
    cp -rf ${TMPDIR}/OpenESI/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "teamBlue" /etc/image-version; then
    echo "TeamBlue image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/Extensions/NssPanel ]; then
    echo "NonSoloSat image"
    cp -rf ${TMPDIR}/Pure2/* / >/dev/null 2>&1
    if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam >/dev/null 2>&1
    fi
    cp -rf ${TMPDIR}/${BIN} /usr/bin/cam/ >/dev/null 2>&1
elif grep -qs -i "OpenEight" /etc/image-version; then
    echo "OpenEight image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "openMips" /etc/image-version; then
    echo "OpenMips image"
    cp -rf ${TMPDIR}/Pure2/* / >/dev/null 2>&1
    if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam >/dev/null 2>&1
    fi
    cp -rf ${TMPDIR}/${BIN} /usr/bin/cam/ >/dev/null 2>&1
elif grep -qs -i "OpenPlus" /etc/image-version; then
    echo "OpenPlus image"
    cp -rf ${TMPDIR}/OpenPlus/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "titannit" /etc/image-version; then
    echo " OpenAFF-Titan image"
    cp -rf ${TMPDIR}/OpenPlus/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/TSimage ]; then
    echo "OpenTS/Ts image"
    cp -rf ${TMPDIR}/Pure2/* / >/dev/null 2>&1
    if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam >/dev/null 2>&1
    fi
    cp -rf ${TMPDIR}/${BIN} /usr/bin/cam/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/SystemPlugins/DemonisatManager ]; then
    echo "DDD-Demoni image"
    cp -rf ${TMPDIR}/dddemon/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif [ -r /usr/lib/enigma2/python/Plugins/Domica ]; then
    echo "Domica image"
    cp -rf ${TMPDIR}/domica/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "openfix" /etc/issue; then
    echo "OpenFIX image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "opentr" /etc/issue; then
    echo "OpenTR image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "SatLodge" /etc/issue.net; then
    echo "SatLodge image"
    cp -rf ${TMPDIR}/SatLodge/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
elif grep -qs -i "areadeltasat" /etc/issue.net; then
    echo "AreadeLtasat image"
    cp -rf ${TMPDIR}/openpli/* / >/dev/null 2>&1
    cp -rf ${TMPDIR}/${BIN} /usr/bin/ >/dev/null 2>&1
else
    rm -r ${TMPDIR} >/dev/null 2>&1
    echo "No emu script to this image now .. ask about it :("
    rm -rf /tmp/enigma2-plugin-softcams-oscam*.ipk
    exit 1
fi

#### Checking Config Files ####
if [ ! -d ${CONFIGPATH} ]; then
    mkdir -p ${CONFIGPATH} >/dev/null 2>&1
fi

echo ${FIN}
echo ":I'm checking your config OSCam ..."
for file in ${BIN_FILES}.conf ${BIN_FILES}.dvbapi ${BIN_FILES}.provid ${BIN_FILES}.server ${BIN_FILES}.services ${BIN_FILES}.user CCcam.cfg; do
    if [ ! -f "${CONFIGPATH}/${file}" ]; then
        cp -f "${TMPDIR}${CONFIGPATH}/${file}" $CONFIGPATH >/dev/null 2>&1
        echo "  send: ${file} ... file"
    fi
done
echo ${FIN}

#### Checking OpenPLI Softcam Symlink ####
if [ -f /etc/init.d/softcam.None ]; then
    if type update-rc.d 2>/dev/null; then
        if [ -n "${D}" ]; then
            OPT="-r ${D}"
        else
            OPT="-s"
        fi
        update-rc.d "${OPT}" softcam defaults 50 >/dev/null 2>&1
    fi
fi
