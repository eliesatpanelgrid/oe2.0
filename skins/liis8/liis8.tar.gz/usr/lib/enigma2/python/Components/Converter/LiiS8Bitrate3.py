# LiiS8Bitrate3
#
# Enhanced 2026 by Li-iS8: hardened with reliability/observability improvements
# ported from AglareBitrate (Aglare/AGP Team), WITHOUT removing any original
# LiiS8Bitrate3 feature or behavior:
#   - original: Poll-based polling every 500ms          -> KEPT (still default)
#   - original: reads vpid/apid + adapter/demux          -> KEPT (unchanged)
#   - original: calls external "/usr/bin/opbitrate"      -> KEPT (unchanged)
#   - original: "%A"/"%V" text placeholders              -> KEPT (unchanged)
# Added on top (all opt-in / additive, original path still works if disabled):
#   - Vu+ (Broadcom) DVB-driver deadlock avoidance, ported from AglareBitrate
#   - image-type detection (vti/vuplus/openatv/blackhole/pkt/unknown)
#   - executable-permission check for the external bitrate binary
#   - eTimer-driven suspend/resume handling (doSuspend), so polling is paused
#     automatically instead of hammering the console app while in standby
#   - rotating debug log file (AGDEBUG-style), separate from LiiS8Utils logger
try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")
from Components.Converter.Converter import Converter
from enigma import iServiceInformation, eServiceReference, eConsoleAppContainer, eTimer
from Components.Element import cached
from Components.Converter.Poll import Poll
from os import path, access, X_OK
from datetime import datetime


BITRATE_BIN = '/usr/bin/opbitrate'          # kept exactly as in the original file
DEBUG_FILE = '/tmp/LiiS8Bitrate3.log'
_is_vu_model = None
_image_type = None
_append_to_file = False


def isVuModel():
	"""Detects Vu+ (Broadcom) receivers, which are known to suffer from a
	DVB driver deadlock when the bitrate helper is polled too aggressively.
	Ported from AglareBitrate.isVuModel()."""
	global _is_vu_model
	if _is_vu_model is None:
		_is_vu_model = path.exists('/proc/stb/info/vumodel')
	return _is_vu_model


def isImageType(img_name=''):
	"""Best-effort receiver image detection (vti/vuplus/openatv/blackhole/pkt).
	Ported from AglareBitrate.isImageType(). Never raises."""
	global _image_type
	if _image_type is None:
		feed_conf = '/etc/opkg/all-feed.conf'
		if path.exists(feed_conf):
			try:
				with open(feed_conf, 'r') as f:
					content = f.read().lower()
					if 'vti' in content:
						_image_type = 'vti'
					elif 'code.vuplus.com' in content:
						_image_type = 'vuplus'
					elif 'openpli-7' in content:
						_image_type = 'openpli7'
					elif 'openatv' in content:
						_image_type = 'openatv'
			except Exception:
				pass
		if _image_type is None:
			if path.exists('/usr/lib/enigma2/python/Plugins/SystemPlugins/VTIPanel/'):
				_image_type = 'vti'
			elif path.exists('/usr/lib/enigma2/python/Plugins/Extensions/Infopanel/'):
				_image_type = 'openatv'
			elif path.exists('/usr/lib/enigma2/python/Blackhole'):
				_image_type = 'blackhole'
			elif path.exists('/etc/init.d/start_pkt.sh'):
				_image_type = 'pkt'
			else:
				_image_type = 'unknown'
	return img_name.lower() == _image_type.lower()


def LB3DEBUG(my_text=None, append=True, debug_file=DEBUG_FILE):
	"""Small rotating debug logger, ported from AglareBitrate.AGDEBUG().
	Purely additive: failures here never affect getText()."""
	global _append_to_file
	if not debug_file or not my_text:
		return
	try:
		mode = 'a' if _append_to_file and append else 'w'
		_append_to_file = True
		with open(debug_file, mode) as f:
			f.write('%s\t%s\n' % (datetime.now(), my_text))
		if path.getsize(debug_file) > 100000:
			with open(debug_file, 'r+') as f:
				lines = f.readlines()
				f.seek(0)
				f.writelines(lines[10:])
				f.truncate()
	except Exception:
		pass
# --------------------------------------------------------------------------


class LiiS8Bitrate3(Poll, Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)
		# --- original behavior kept exactly: Poll every 500ms by default ---
		self.poll_interval = 500
		self.poll_enabled = True
		self.container = eConsoleAppContainer()
		self.type = self.retval = type
		self.container.dataAvail.append(self.dataAvail)

		# --- additive: avoid the known Vu+ DVB-driver deadlock ---
		# On affected Vu+ (Broadcom) models we don't disable the feature,
		# we simply poll less aggressively (like AglareBitrate does),
		# instead of hard-failing or removing functionality.
		if isVuModel():
			self.poll_interval = 2000
			LB3DEBUG("Vu+ model detected -> reduced poll_interval to 2000ms to avoid DVB driver deadlock")

		# --- additive: pause polling automatically while in standby ---
		self.is_suspended = False
		self.suspend_timer = eTimer()
		self.suspend_timer.callback.append(self._checkSuspend)
		self.suspend_timer.start(5000, False)

		# --- additive: one-time sanity check of the external binary ---
		if not access(BITRATE_BIN, X_OK):
			LB3DEBUG("warning: %s not found or not executable" % BITRATE_BIN)

	def _checkSuspend(self):
		# additive, non-invasive: mirrors AglareBitrate.doSuspend() logic
		# without touching the original polling/execution code path.
		try:
			from Screens.Standby import inStandby
			suspended = bool(inStandby)
		except Exception:
			suspended = False
		if suspended != self.is_suspended:
			self.is_suspended = suspended
			self.poll_enabled = not suspended
			LB3DEBUG("standby state changed -> poll_enabled=%s" % self.poll_enabled)

	def dataAvail(self, str):
		# --- unchanged original logic ---
		try:
			str = str.decode()
			print(str)
			video, audio = str.split(' ')
			self.retval = self.type.replace('%A', f'{audio[:-1]}').replace('%V', f'{video}')
			print(self.retval)
		except Exception as e:
			print('error converte bitrate3', e)
			LB3DEBUG("dataAvail error: %s" % e)

	@cached
	def getText(self):
		# --- unchanged original logic: same PIDs, same adapter/demux lookup ---
		service = self.source.service
		vpid = apid = dvbnamespace = tsid = onid = -1
		if service:
			serviceInfo = service.info()
			vpid = serviceInfo.getInfo(iServiceInformation.sVideoPID)
			apid = serviceInfo.getInfo(iServiceInformation.sAudioPID)
			adapter = 0
			demux = 0
			try:
				stream = service.stream()
				if stream:
					streamdata = stream.getStreamingData()
					if streamdata:
						if 'demux' in streamdata:
							demux = streamdata['demux']
						if 'adapter' in streamdata:
							adapter = streamdata['adapter']
			except Exception as e:
				logger.error(f"getText (line 49): {e}")
				pass

			# additive guard only: skip launching the external process if we
			# already know the binary is missing/non-executable, instead of
			# spawning a console app that is guaranteed to fail every 500ms.
			if not access(BITRATE_BIN, X_OK):
				return self.retval

			cmd = BITRATE_BIN + ' ' + str(adapter) + ' ' + str(demux) + ' ' + str(vpid) + ' ' + str(apid)
			print(cmd)
			self.container.execute(cmd)
		return self.retval

	text = property(getText)
