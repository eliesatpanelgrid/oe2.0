#!/usr/bin/python
# -*- coding: utf-8 -*-
###################################################################
## Original implementation: "Lululla" / AGP Team (Agp_apikeys.py) ##
## Original modification:   "MNASR"                                ##
## Integrated & adapted for LiiS8 by: LiiS8 Team                   ##
##   - renamed to fit LiiS8 naming/module conventions              ##
##   - wired into LiiS8Converlibr._runtime_cfg / get_cfg()         ##
##   - config namespace switched to config.plugins.LiiS8           ##
###################################################################
#
# منظومة مفاتيح API متعددة المزوّدين (TMDB / OMDB / TheTVDB / Fanart)
# مبنية على عمل فريق AGP الأصلي (Lululla / MNASR)، ودُمجت هنا لتعمل
# ضمن بنية إعدادات LiiS8 (_runtime_cfg / get_cfg) بدلًا من الاعتماد
#
from __future__ import absolute_import, print_function

from pathlib import Path
from threading import Lock

from Components.config import config

try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")

from .LiiS8Converlibr import _runtime_cfg, get_cfg  # noqa: F401  (get_cfg re-exported for convenience)

# قفل مزامنة الوصول لمفاتيح API بين الخيوط (Threads) المختلفة
api_lock = Lock()

# ================ START MULTI-PROVIDER API CONFIGURATION ===============

# مفاتيح افتراضية احتياطية (Fallback) - نفس المفاتيح الافتراضية المستخدمة
# أصلًا في كل من LiiS8Converlibr.py وAgp_apikeys.py (مصدر مشترك واحد)
_DEFAULT_API_KEYS = {
    "TMDB_API_KEY":    "3c3efcf47c3577558812bb9d64019d65",
    "OMDB_API_KEY":    "4ca6ea60",
    "THETVDB_API_KEY": "a99d487bb3426e5f3a60dea6d3d3c7ef",
    "FANART_API_KEY":  "6d231536dea4318a88cb2520ce89473b",
}

# أسماء ملفات المفاتيح البديلة داخل مجلد السكين (نفس تسمية AGP الأصلية،
# تُقرأ إن وُجدت كوسيلة إعداد بديلة بدون الحاجة لإعادة تصدير الإضافة)
_SKIN_KEY_FILES = {
    "TMDB_API_KEY":    "tmdbkey",
    "OMDB_API_KEY":    "omdbkey",
    "THETVDB_API_KEY": "thetvdbkey",
    "FANART_API_KEY":  "fanartkey",
}

# تأكد من وجود المفاتيح الأربعة في القاموس المركزي لـ LiiS8 بقيمها
# الافتراضية أولًا (سيُستبدَل أي منها إن نجحت load_api_keys أدناه)
for _k, _v in _DEFAULT_API_KEYS.items():
    _runtime_cfg.setdefault(_k, _v)


def load_api_keys(plugin_cfg=None):
    """
    يحمّل مفاتيح API حسب ترتيب الأولوية التالي (نفس منطق AGP الأصلي):
      1) إعدادات الإضافة (config.plugins.LiiS8) إن كانت مفعّلة وممتلئة
      2) ملف مفتاح داخل مجلد السكين الحالي (tmdbkey, omdbkey, ...)
      3) القيمة الافتراضية المُضمَّنة (Fallback)

    يُستدعى هذا مع/بعد apply_plugin_config() من LiiS8Converlibr.py.
    plugin_cfg: كائن config.plugins.LiiS8 (اختياري - إن لم يُمرَّر
    تُستخدم القيم الافتراضية/ملفات السكين فقط دون قسم الإضافة).
    """
    try:
        cur_skin = config.skin.primary_skin.value.replace("/skin.xml", "")
        skin_path = Path("/usr/share/enigma2/%s" % cur_skin)
    except Exception as e:
        logger.error("[LiiS8 API Config] تعذّر تحديد مسار السكين الحالي: %s" % e)
        skin_path = None

    keys_loaded = False
    with api_lock:
        for key_name, skin_file in _SKIN_KEY_FILES.items():
            # 1) إعدادات الإضافة (إن وُجدت ومفعّلة)
            if plugin_cfg is not None:
                try:
                    attr_base = key_name.split("_API_KEY")[0].lower()  # tmdb / omdb / thetvdb / fanart
                    enabled = getattr(plugin_cfg, attr_base).value
                    value = getattr(plugin_cfg, attr_base + "_api").value.strip()
                    if enabled and value:
                        _runtime_cfg[key_name] = value
                        logger.debug("[LiiS8 API Config] استخدام مفتاح %s من إعدادات الإضافة" % key_name)
                        keys_loaded = True
                        continue
                except Exception:
                    pass  # الحقل غير معرَّف في إعدادات هذه النسخة - انتقل للخطوة التالية

            # 2) ملف مفتاح داخل مجلد السكين
            if skin_path is not None:
                file_path = skin_path / skin_file
                if file_path.exists():
                    try:
                        with open(str(file_path), "r") as f:
                            value = f.read().strip()
                        if value:
                            _runtime_cfg[key_name] = value
                            logger.debug("[LiiS8 API Config] تحميل %s من %s" % (key_name, file_path))
                            keys_loaded = True
                            continue
                    except Exception as e:
                        logger.error("[LiiS8 API Config] خطأ في قراءة %s: %s" % (file_path, e))

            # 3) البقاء على القيمة الافتراضية (مُعيَّنة مسبقًا في _runtime_cfg أعلاه)
            logger.debug("[LiiS8 API Config] استخدام المفتاح الافتراضي لـ %s" % key_name)

    return keys_loaded


# تحميل أولي عند استيراد الوحدة (بدون plugin_cfg - يُعاد تحميلها لاحقًا
# مع الكائن الفعلي عند تهيئة الإضافة عبر apply_plugin_config)
load_api_keys()

# ================ END MULTI-PROVIDER API CONFIGURATION ================


# ============================================================================
# LiiS8ApiKeyManager
# منفذ دقيق من Plugins/Extensions/Aglare/api_config.py (ApiKeyManager) —
# بعد فحص الملف الأصلي فعليًا وتصحيح الافتراضات السابقة:
#   - يشمل فقط 4 مزوّدين حقيقيين (tmdb/fanart/thetvdb/omdb)، وليس google/imdb
#     (تلك تُفعَّل عبر أعلام مستقلة تمامًا، وليس عبر مدير المفاتيح)
#   - نفس منطق: مفعّل فقط إن كان العلم "enabled" ON *و* المفتاح غير فارغ
#   - get_api_key تُعيد None (وليس "") لمزوّد غير معروف، كالأصل تمامًا
# ============================================================================
from Components.config import config, ConfigOnOff, ConfigText, ConfigSubsection

# تسجيل قسم إعدادات LiiS8 الخاص بمزوّدي API (إن لم يكن مسجَّلًا مسبقًا من مكان آخر)
if not hasattr(config.plugins, "LiiS8"):
    config.plugins.LiiS8 = ConfigSubsection()

_liis8_cfg = config.plugins.LiiS8

# نفس القيم الافتراضية والحالة المفعّلة/معطّلة الأصلية بالضبط من api_config.py
# (tmdb مفعّل افتراضيًا، البقية معطّلة افتراضيًا - كالأصل تمامًا)
if not hasattr(_liis8_cfg, "tmdb"):
    _liis8_cfg.tmdb = ConfigOnOff(default=True)
    _liis8_cfg.tmdb_api = ConfigText(default="3c3efcf47c3577558812bb9d64019d65", visible_width=50, fixed_size=False)

if not hasattr(_liis8_cfg, "fanart"):
    _liis8_cfg.fanart = ConfigOnOff(default=False)
    _liis8_cfg.fanart_api = ConfigText(default="6d231536dea4318a88cb2520ce89473b", visible_width=50, fixed_size=False)

if not hasattr(_liis8_cfg, "thetvdb"):
    _liis8_cfg.thetvdb = ConfigOnOff(default=False)
    _liis8_cfg.thetvdb_api = ConfigText(default="a99d487bb3426e5f3a60dea6d3d3c7ef", visible_width=50, fixed_size=False)

if not hasattr(_liis8_cfg, "omdb"):
    _liis8_cfg.omdb = ConfigOnOff(default=False)
    # القيمة الفعلية المُعتمدة في الأصل (وليس "cb1d9f55" المذكورة في قاموس داخلي متناقض)
    _liis8_cfg.omdb_api = ConfigText(default="4ca6ea60", visible_width=50, fixed_size=False)

if not hasattr(_liis8_cfg, "info_display_mode"):
    from Components.config import ConfigSelection
    _liis8_cfg.info_display_mode = ConfigSelection(default="off", choices=[
        ("auto", "Automatic"),
        ("tmdb", "TMDB Only"),
        ("omdb", "OMDB Only"),
        ("off", "Off"),
    ])

if not hasattr(_liis8_cfg, "xemc_poster"):
    _liis8_cfg.xemc_poster = ConfigOnOff(default=False)

# اسم مستعار عام (مثل "cfg" في api_config.py الأصلي) لتستخدمه ملفات EMC الأخرى
liis8_cfg = _liis8_cfg


class LiiS8ApiKeyManager(object):
    def __init__(self):
        self.API_CONFIG = {
            "tmdb":    {"config_entry": _liis8_cfg.tmdb_api,    "enabled_entry": _liis8_cfg.tmdb},
            "fanart":  {"config_entry": _liis8_cfg.fanart_api,  "enabled_entry": _liis8_cfg.fanart},
            "thetvdb": {"config_entry": _liis8_cfg.thetvdb_api, "enabled_entry": _liis8_cfg.thetvdb},
            "omdb":    {"config_entry": _liis8_cfg.omdb_api,    "enabled_entry": _liis8_cfg.omdb},
        }

    def get_active_providers(self):
        """
        مطابق تمامًا لسلوك ApiKeyManager الأصلي: يُعيد فقط المزوّدين المفعّلين
        (enabled=True) والذين لديهم مفتاح غير فارغ. google/imdb/elcinema/
        molotov/programmetv عمدًا غير موجودين هنا (كالأصل).
        """
        active = {}
        for api, cfg in self.API_CONFIG.items():
            enabled = cfg["enabled_entry"].value
            key_valid = bool(cfg["config_entry"].value)
            if enabled and key_valid:
                active[api] = True
        return active

    def get_api_key(self, provider):
        if provider in self.API_CONFIG:
            return self.API_CONFIG[provider]["config_entry"].value
        return None


# نسخة وحيدة مشتركة (Singleton) بنفس نمط الأصل (api_key_manager = ApiKeyManager())
liis8_api_key_manager = LiiS8ApiKeyManager()
