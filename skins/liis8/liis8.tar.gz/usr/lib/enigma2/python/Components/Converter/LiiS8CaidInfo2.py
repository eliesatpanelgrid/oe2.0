# Updated on 21-07-2026 by developer Li-iS8
# LiiS8CaidInfo2 - best-of-both pick: repaired v1.3.0 (HiSilicon graphics fix, caching, reduced polling,
# fixed CAIDS multi-list, optional server-name privacy masking
# -*- coding: utf-8 -*-
#
#  CaidInfo2 - Converter (REPAIRED VERSION)
#  ver 1.3.0 21.07.2026 + HiSilicon Graphics Fix + CAIDS fix + privacy masking
#
#  Coded by bigroma & 2boom & j00zek
#  Repaired for HiSilicon graphics compatibility by Claude (Anthropic)
#
#  convertorType values accepted by this converter:
#    "CAID" "PID" "ProvID" "Delay" "Host" "Net" "Emu" "CryptInfo" "CryptInfo2"
#    "BetaCrypt" "ConaxCrypt" "CrwCrypt" "DreamCrypt" "ExsCrypt" "IrdCrypt"
#    "NagraCrypt" "NdsCrypt" "SecaCrypt" "ViaCrypt" "PwuCrypt" "VrmCrypt"
#    "TanCrypt" "BisCrypt"  (+ their *Ecm variants for the currently active CAID)
#    "Crd" "CrdTxt" "IsFta" "IsCrypted" "Short" "Default"/""/"%" (=ALL)
#    "emuname" "emuFullName" "caids" "UseCFG" "ecmfile" "PIDS"
#    "Format <template>" where template may use:
#        %C caid   %P pid   %p prov   %R reader   %O source   %T ecm time
#        %S server %H hops  %SY system %PV provider %PR protocol %SP port
#        %CH chid (raw, as reported verbatim in /tmp/ecm.info - no reformatting)
#        %SCN softcam short name  %SCFN softcam full name  %t tab  %n newline
#

from __future__ import absolute_import  # zmiana strategii ladowanie modulow w py2 z relative na absolute jak w py3
try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")
from Components.config import config
from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached
from enigma import iServiceInformation, eDVBCI_UI, eDVBCIInterfaces
from Tools.Directories import fileExists
import os

DBG = False
if DBG:
    try:
        from Components.j00zekComponents import j00zekDEBUG
    except Exception:
        DBG = False

info = {}
old_ecm_mtime = None


class LiiS8CaidInfo2(Poll, Converter, object):
    CAID = 0
    PID = 1
    PROV = 2
    ALL = 3
    IS_NET = 4
    IS_EMU = 5
    CRYPT = 6
    BETA = 7
    CONAX = 8
    CRW = 9
    DRE = 10
    IRD = 11
    NAGRA = 12
    NDS = 13
    SECA = 14
    VIA = 15
    PWR = 16
    VERI = 17
    BETA_C = 18
    CONAX_C = 19
    CRW_C = 20
    DRE_C = 21
    IRD_C = 22
    NAGRA_C = 23
    NDS_C = 24
    SECA_C = 25
    VIA_C = 26
    PWR_C = 27
    VERI_C = 28
    BISS = 29
    BISS_C = 30
    EXS = 31
    EXS_C = 32
    TAN = 33
    TAN_C = 34
    HOST = 35
    DELAY = 36
    FORMAT = 37
    CRYPT2 = 38
    CRD = 39
    CRDTXT = 40
    SHORT = 41
    IS_FTA = 42
    IS_CRYPTED = 43
    
    # REPAIRED: Reduced polling frequency to prevent graphics conflicts
    my_interval = 5000  # Changed from 2000ms to 5000ms (5 seconds)
    USE_CFG = 44

    SOFTCAMNAME = 45
    SOFTCAMFULLNAME = 46
    CAIDS = 47
    ECMFILECONTENT = 48
    PIDS = 49
    CASBADGES = 50

    def __init__(self, type):
        Poll.__init__(self)
        Converter.__init__(self, type)
        self.currPID = 1000
        
        # REPAIRED: Added caching to reduce file system access
        self._cache_data = {}
        self._cache_timestamp = 0
        self._cache_timeout = 3.0  # Cache for 3 seconds
        
        self.eDVBCIUIInstance = eDVBCI_UI.getInstance()
        self.eDVBCIUIInstance and self.eDVBCIUIInstance.ciStateChanged.get().append(self.ciModuleStateChanged)
        self.NUM_CI = eDVBCIInterfaces.getInstance() and eDVBCIInterfaces.getInstance().getNumOfSlots()
        if DBG: j00zekDEBUG(f'[j00zekModCaidInfo2:__init__] self.NUM_CI = {self.NUM_CI!s}')
        
        # Type assignment (unchanged)
        if type == "CAID": self.type = self.CAID
        elif type == "PID": self.type = self.PID
        elif type == "ProvID": self.type = self.PROV
        elif type == "Delay": self.type = self.DELAY
        elif type == "Host": self.type = self.HOST
        elif type == "Net": self.type = self.IS_NET
        elif type == "Emu": self.type = self.IS_EMU
        elif type == "CryptInfo": self.type = self.CRYPT
        elif type == "CryptInfo2": self.type = self.CRYPT2
        elif type == "BetaCrypt": self.type = self.BETA
        elif type == "ConaxCrypt": self.type = self.CONAX
        elif type == "CrwCrypt": self.type = self.CRW
        elif type == "DreamCrypt": self.type = self.DRE
        elif type == "ExsCrypt": self.type = self.EXS
        elif type == "IrdCrypt": self.type = self.IRD
        elif type == "NagraCrypt": self.type = self.NAGRA
        elif type == "NdsCrypt": self.type = self.NDS
        elif type == "SecaCrypt": self.type = self.SECA
        elif type == "ViaCrypt": self.type = self.VIA
        elif type == "PwuCrypt": self.type = self.PWR
        elif type == "VrmCrypt": self.type = self.VERI
        elif type == "BetaEcm": self.type = self.BETA_C
        elif type == "ConaxEcm": self.type = self.CONAX_C
        elif type == "CrwEcm": self.type = self.CRW_C
        elif type == "DreamEcm": self.type = self.DRE_C
        elif type == "ExsEcm": self.type = self.EXS_C
        elif type == "IrdEcm": self.type = self.IRD_C
        elif type == "NagraEcm": self.type = self.NAGRA_C
        elif type == "NdsEcm": self.type = self.NDS_C
        elif type == "SecaEcm": self.type = self.SECA_C
        elif type == "ViaEcm": self.type = self.VIA_C
        elif type == "PwuEcm": self.type = self.PWR_C
        elif type == "VrmEcm": self.type = self.VERI_C
        elif type == "TanCrypt": self.type = self.TAN
        elif type == "TanEcm": self.type = self.TAN_C
        elif type == "BisCrypt": self.type = self.BISS
        elif type == "BisEcm": self.type = self.BISS_C
        elif type == "Crd": self.type = self.CRD
        elif type == "CrdTxt": self.type = self.CRDTXT
        elif type == "IsFta": self.type = self.IS_FTA
        elif type == "IsCrypted": self.type = self.IS_CRYPTED
        elif type == "Short": self.type = self.SHORT
        elif type == "Default" or type == "" or type is None or type == "%": self.type = self.ALL
        elif type == "emuname": self.type = self.SOFTCAMNAME
        elif type == "emuFullName": self.type = self.SOFTCAMFULLNAME
        elif type == "caids": self.type = self.CAIDS
        elif type == "casbadges": self.type = self.CASBADGES
        elif type == "UseCFG": self.type = self.USE_CFG
        elif type == "ecmfile": self.type = self.ECMFILECONTENT
        elif type == "PIDS": self.type = self.PIDS
        else:
            self.type = self.FORMAT
            self.sfmt = type[:]

        self.systemTxtCaids = {
            "26" : "BiSS",
            "01" : "Seca Mediaguard",
            "06" : "Irdeto",
            "17" : "BetaCrypt",
            "55" : "BulCrypt",
            "05" : "Viaccess",
            "18" : "Nagravision",
            "09" : "NDS-Videoguard",
            "0B" : "Conax",
            "0D" : "Cryptoworks",
            "4A" : "DRE-Crypt",
            "27" : "ExSet",
            "0E" : "PowerVu",
            "10" : "Tandberg",
            "22" : "Codicrypt",
            "07" : "DigiCipher",
            "56" : "Verimatrix",
            "4B" : "DG-Crypt",
            "A1" : "Rosscrypt"}

        self.systemCaids = {
            "26" : "BiSS",
            "01" : "SEC",
            "06" : "IRD",
            "55" : "BET",
            "17" : "BET",
            "05" : "VIA",
            "18" : "NAG",
            "09" : "NDS",
            "0B" : "CON",
            "0D" : "CRW",
            "27" : "EXS",
            "4B" : "DRE",
            "4A" : "DRE",
            "0E" : "PWR",
            "10" : "TAN",
            "56" : "VERI"}

    # REPAIRED: Added caching mechanism to reduce file I/O frequency
    def _get_cached_data(self, cache_key, data_func):
        """Get cached data or refresh if expired"""
        import time
        current_time = time.time()
        
        if (cache_key in self._cache_data and 
            current_time - self._cache_timestamp < self._cache_timeout):
            return self._cache_data[cache_key]
        
        # Cache expired or doesn't exist, refresh
        try:
            data = data_func()
            self._cache_data[cache_key] = data
            self._cache_timestamp = current_time
            return data
        except Exception:
            # Return cached data if available, empty string otherwise
            return self._cache_data.get(cache_key, "")

    def _build_caids_list(self, info, ecm_info):
        """REPAIRED: real implementation of the 'caids' convertorType.

        Returns every CAID (and its ECM-PID when available) found on the
        current service, separated by ' | ', with the CAID that is actually
        being decoded right now (per /tmp/ecm.info) wrapped in [brackets].
        Falls back gracefully on older images that lack sCAIDPIDs.
        """
        try:
            caid_pids = info.getInfoObject(iServiceInformation.sCAIDPIDs)
        except Exception:
            caid_pids = None

        if not caid_pids:
            caids = info.getInfoObject(iServiceInformation.sCAIDs)
            if not caids:
                return _('Free-to-air')
            caid_pids = [(c, 0) for c in caids]

        active_caid = None
        try:
            active_caid = int(ecm_info.get('caid', ''), 16)
        except Exception:
            pass

        parts = []
        for c, p in sorted(set(caid_pids), key=lambda x: (x[0], x[1])):
            label = f"{c:04X}:{p:04X}" if p else f"{c:04X}"
            if active_caid is not None and c == active_caid:
                label = f"[{label}]"
            parts.append(label)
        return " | ".join(parts) if parts else '?'

    # مجموعات CAID -> اختصار نصي، تُستخدم في _build_cas_badges أدناه فقط
    _CAS_GROUPS = (
        ("S", ("01",)),    # Seca/Mediaguard
        ("V", ("05",)),    # Viaccess
        ("I", ("06",)),    # Irdeto
        ("ND", ("09",)),   # NDS/Videoguard
        ("CO", ("0B",)),   # Conax
        ("CW", ("0D",)),   # Cryptoworks
        ("PV", ("0E",)),   # PowerVu
        ("T", ("10",)),    # Tandberg
        ("BE", ("17", "55")),  # Betacrypt
        ("N", ("18",)),    # Nagravision
        ("BI", ("26",)),   # BISS
        ("EX", ("27",)),   # Exset/EBU
        ("DR", ("4A", "4B")),  # Dreamcrypt
        ("VR", ("56",)),   # Verimatrix
    )

    def _build_cas_badges(self, info, ecm_info):
        """جديد: سطر اختصارات كل أنظمة التشفير الموجودة على الخدمة الحالية، مع
        وضع النظام النشط فعليًا (المستخرَج من /tmp/ecm.info، بنفس طريقة
        _build_caids_list أعلاه) بين قوسين [] بدل تلوين مختلف، لأن الودجت
        الواحد في Enigma2 لا يمكنه تلوين جزء من النص بلون مختلف عن الباقي.
        يعيد استخدام نفس منطق كشف CAID (البادئة الست عشرية) المستخدم أصلاً
        في getBoolean، دون تكراره بمنطق مختلف."""
        try:
            caids = info.getInfoObject(iServiceInformation.sCAIDs)
        except Exception:
            caids = None
        if not caids:
            return _('Free-to-air')

        present = set()
        for c in caids:
            try:
                present.add(f"{int(c):04X}"[:2])
            except Exception:
                pass

        active_prefix = None
        try:
            active_prefix = f"{int(ecm_info.get('caid', ''), 16):04X}"[:2]
        except Exception:
            pass

        parts = []
        for label, prefixes in self._CAS_GROUPS:
            if any(p in present for p in prefixes):
                if active_prefix and active_prefix in prefixes:
                    parts.append(f"[{label}]")
                else:
                    parts.append(label)
        return "  ".join(parts) if parts else '?'

    def _build_pids_info(self, info):
        """NEW: 'SID: XXXX VPID: XXXX APID: XXXX PRCPID: XXXX TSID: XXXX ONID: XXXX'

        Pure DVB service info, unrelated to CAM/ecm.info - works on FTA
        channels too. VPID is skipped automatically for radio/audio-only
        services (where there is no video PID), matching RaedQuickEcmInfo's
        fallback cascade behaviour.
        """
        def hx(value):
            try:
                value = int(value)
            except (TypeError, ValueError):
                return "----"
            if value <= 0:
                return "----"
            return "%04X" % value

        sid = info.getInfo(iServiceInformation.sSID)
        vpid = info.getInfo(iServiceInformation.sVideoPID)
        apid = info.getInfo(iServiceInformation.sAudioPID)
        prcpid = info.getInfo(iServiceInformation.sPCRPID)
        tsid = info.getInfo(iServiceInformation.sTSID)
        onid = info.getInfo(iServiceInformation.sONID)

        parts = [f"SID: {hx(sid)}"]
        if vpid and vpid > 0:
            parts.append(f"VPID: {hx(vpid)}")
        parts.append(f"APID: {hx(apid)}")
        parts.append(f"PRCPID: {hx(prcpid)}")
        parts.append(f"TSID: {hx(tsid)}")
        parts.append(f"ONID: {hx(onid)}")
        return "  ".join(parts)

    @cached
    def getBoolean(self):
        service = self.source.service
        info = service and service.info()
        if not info:
            return False

        caids = info.getInfoObject(iServiceInformation.sCAIDs)
        if self.type is self.IS_FTA:
            if caids:
                return False
            return True
        if self.type is self.IS_CRYPTED:
            if caids:
                return True
            return False
        if caids:
            if self.type == self.SECA:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "01":
                        return True
                return False
            if self.type == self.BETA:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "55" or (f"{int(caid):004X}")[:2] == "17" :
                        return True
                return False
            if self.type == self.CONAX:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "0B":
                        return True
                return False
            if self.type == self.CRW:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "0D":
                        return True
                return False
            if self.type == self.DRE:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "4B" or (f"{int(caid):004X}")[:2] == "4A" :
                        return True
                return False
            if self.type == self.EXS:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "27":
                        return True
            if self.type == self.NAGRA:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "18":
                        return True
                return False
            if self.type == self.NDS:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "09":
                        return True
                return False
            if self.type == self.IRD:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "06":
                        return True
                return False
            if self.type == self.VIA:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "05":
                        return True
                return False
            if self.type == self.PWR:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "0E":
                        return True
                return False
            if self.type == self.VERI:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "56":
                        return True
                return False
            if self.type == self.TAN:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "10":
                        return True
                return False
            if self.type == self.BISS:
                for caid in caids:
                    if (f"{int(caid):004X}")[:2] == "26":
                        return True
                return False
            
            # REPAIRED: Reduced polling frequency for ECM-dependent operations
            self.poll_interval = self.my_interval
            self.poll_enabled = True
            
            # Use cached ECM data
            ecm_info = self._get_cached_data('ecm_info', self.ecmfile)
            if ecm_info:
                try:
                    caid = f"{int(ecm_info.get('caid', ''), 16):004X}"[:2]
                except Exception:
                    return False
                if self.type == self.SECA_C:
                    if caid == "01":
                        return True
                    return False
                if self.type == self.BETA_C:
                    if caid == "17" or caid == "55":
                        return True
                    return False
                if self.type == self.CONAX_C:
                    if caid == "0B":
                        return True
                    return False
                if self.type == self.CRW_C:
                    if caid == "0D":
                        return True
                    return False
                if self.type == self.DRE_C:
                    if caid == "4A" or caid == "4B":
                        return True
                    return False
                if self.type == self.EXS_C:
                    if caid == "27":
                        return True
                    return False
                if self.type == self.NAGRA_C:
                    if caid == "18":
                        return True
                    return False
                if self.type == self.NDS_C:
                    if caid == "09":
                        return True
                    return False
                if self.type == self.IRD_C:
                    if caid == "06":
                        return True
                    return False
                if self.type == self.VIA_C:
                    if caid == "05":
                        return True
                    return False
                if self.type == self.PWR_C:
                    if caid == "0E":
                        return True
                    return False
                if self.type == self.VERI_C:
                    if caid == "56":
                        return True
                    return False
                if self.type == self.TAN_C:
                    if caid == "10":
                        return True
                    return False
                if self.type == self.BISS_C:
                    if caid == "26":
                        return True
                    return False
                
                # Rest of boolean logic unchanged but using cached data
                reader = ecm_info.get("reader", None)
                using = ecm_info.get("using", "")
                source = ecm_info.get("source", "")
                if self.type == self.CRD:
                    if source == "sci":
                        return True
                    if source != "cache" and source != "net" and source != "emu":
                        return True
                    return False
                source = ecm_info.get("source", "")
                if self.type == self.IS_EMU:
                    return using == "emu" or source == "emu" or source == "card" or reader == "emu" or source.find("card") > -1 or source.find("emu") > -1 or source.find("biss") > -1 or source.find("cache") > -1
                source = ecm_info.get("source", "")
                if self.type == self.IS_NET:
                    if using == "CCcam":
                        return 1
                    else:
                        if source != "cache" and source == "net" and source.find("emu") == -1:
                            return True
                else:
                    return False

        return False

    boolean = property(getBoolean)

    def runningSoftCamName(self, fullName = False):
        """REPAIRED: Added caching for SoftCam name detection"""
        if DBG: j00zekDEBUG(f'[j00zekModCaidInfo2:runningSoftCamName] >>> fullName="{fullName!s}"')
        
        # Use caching for SoftCam name to reduce /proc filesystem access
        cache_key = f'softcam_name_{fullName}'
        return self._get_cached_data(cache_key, lambda: self._get_softcam_name(fullName))
    
    def _get_softcam_name(self, fullName):
        """Internal method to get SoftCam name without caching"""
        def checkCam(txt):
            for scName in ('oscam_emu','oscam', 'cccam', 'mgcam'):
                if scName in txt.lower():
                    if fullName:
                        return txt
                    else:
                        return scName
            return None

        # trying to use last PID
        try:
            procStat = open(os.path.join("/proc", str(self.currPID),'stat'), "r").read().split('(')[1].split(')')[0]
            foundSC = checkCam(procStat)
            if not foundSC is None:
                return foundSC
        except Exception as e:
            if DBG: j00zekDEBUG(f"\t Exception trying to get name of curr.PID= {os.path.join('/proc', str(self.currPID))} : {e!s}")
        # searching for new PID
        for f in os.listdir("/proc"):
            if os.path.isdir(os.path.join("/proc", f)):
                try:
                    pid = int(f)
                    if pid > self.currPID:
                        procStat = open(os.path.join("/proc", f,'stat'), "r").read().split('(')[1].split(')')[0]
                        foundSC = checkCam(procStat)
                        if not foundSC is None:
                            self.currPID = pid
                            return foundSC
                except Exception as e:
                    if DBG: j00zekDEBUG(f"\t Exception trying to analyze {os.path.join('/proc', f)} : {e!s}")
        return _('None SoftCam is running')

    def getCIdata(self, allVisible, showNameOfActive = True):
        # CI data (unchanged but called less frequently due to caching)
        CIstring = ""
        appname = ""
        if self.NUM_CI and self.NUM_CI > 0:
            if self.eDVBCIUIInstance:
                for slot in range(self.NUM_CI):
                    add_num = True
                    if CIstring:
                        CIstring += " "
                    state = self.eDVBCIUIInstance.getState(slot)
                    if DBG: j00zekDEBUG(f'\t slot={slot}, state={state}')
                    if state != -1:  # there is something in the slot
                        CIname = eDVBCI_UI.getInstance().getAppName(slot)
                        if state == 0:
                            if not allVisible:
                                CIstring += ""
                                add_num = False
                            else:
                                CIstring += r"\c007?7?7?"
                        elif state == 1:
                            CIstring += r"\c00????00"
                        elif state == 2:
                            CIstring += r"\c0000??00"
                    else:  # empty slot
                        if not allVisible:
                            CIstring += ""
                            add_num = False
                        else:
                            CIstring += r"\c00??2525"
                    if add_num:
                        CIstring += f"{slot + 1}"
                if CIstring:
                    if showNameOfActive:
                        CIstring = CIname
                    else:
                        CIstring = _("CI slot: ") + CIstring
                    if DBG:
                        j00zekDEBUG(f'\t CIstring="{CIstring}"')
            return CIstring

    @cached
    def getText(self):
        if DBG:
            j00zekDEBUG(f'[j00zekModCaidInfo2:getText] >>>self.type="{self.type}", ciFormat.value="{config.plugins.j00zekCC.ciFormat.value}"')
        textvalue = ""
        server = ""
        softCamName = ''
        service = self.source.service
        
        # REPAIRED: Use cached SoftCam name
        if self.type == self.USE_CFG:
            if config.plugins.j00zekCC.ciFormat.value == '':
                return self.runningSoftCamName(True)
            elif '%SCN' in config.plugins.j00zekCC.ciFormat.value: 
                softCamName = self.runningSoftCamName(False)
            elif '%SCFN' in config.plugins.j00zekCC.ciFormat.value: 
                softCamName = self.runningSoftCamName(True)
        elif self.type == self.FORMAT:
            if '%SCN' in self.sfmt: 
                softCamName = self.runningSoftCamName(False)
            elif '%SCFN' in self.sfmt: 
                softCamName = self.runningSoftCamName(True)
        elif self.type == self.SOFTCAMNAME:
            return self.runningSoftCamName()
        elif self.type == self.SOFTCAMFULLNAME:
            return self.runningSoftCamName(True)
            
        if not service:
            return softCamName
        else:
            info = service and service.info()
            
            # REPAIRED: Use cached ECM info
            ecm_info = self._get_cached_data('ecm_info', self.ecmfile)
            
            if not info: 
                return softCamName
            elif not info.getInfoObject(iServiceInformation.sCAIDs): 
                return _('Free-to-air')
            elif not ecm_info:
                if self.NUM_CI and self.NUM_CI > 0:
                    CIinfo = self.getCIdata(False)
                    if CIinfo == '' and softCamName == '':
                        return _("no data from CI")
                    elif CIinfo == '':
                        return _("no data from CI and emulator")
                    else:
                        return _(CIinfo)
                else:
                    return _("no data from the emulator")
            elif self.type == self.ECMFILECONTENT: 
                return self._get_cached_data('ecm_content', self.ecmfileContent)
            elif self.type == self.CAIDS:
                # REPAIRED: was a dead stub returning '?'. Now builds a real
                # "CAID:PID | CAID:PID | ..." list for every CA system present
                # on the current service (not only the one currently decoding).
                return self._get_cached_data('caids_list', lambda: self._build_caids_list(info, ecm_info))
            elif self.type == self.CASBADGES:
                # جديد: سطر اختصارات (B I N S T V BI BU CO CW ND PV VM...) مع
                # وضع الاختصار النشط بين قوسين.
                return self._get_cached_data('cas_badges', lambda: self._build_cas_badges(info, ecm_info))
            elif self.type == self.PIDS:
                # NEW: raw DVB service info (SID/VPID/APID/PRCPID/TSID/ONID).
                # Unrelated to /tmp/ecm.info - pulled straight from
                # iServiceInformation, so it works even on FTA channels.
                return self._get_cached_data('pids_info', lambda: self._build_pids_info(info))
            elif self.type == self.CRYPT2:
                # REPAIRED: Reduced polling for CRYPT2
                self.poll_interval = self.my_interval
                self.poll_enabled = True
                info = service and service.info()
                if fileExists("/tmp/ecm.info"):
                    try:
                        caid = f"{int(ecm_info.get('caid', ''), 16):004X}"
                        textvalue = f"{self.systemTxtCaids.get(caid[:2])}"
                    except Exception:
                        textvalue = _('nondecode')
                return textvalue
            else:
                # REPAIRED: Reduced polling frequency
                self.poll_interval = self.my_interval
                self.poll_enabled = True
                
                # Rest of getText logic unchanged but using cached ECM data
                caid = f"{int(ecm_info.get('caid', ''), 16):004X}"
                if self.type == self.CAID:
                    return caid
                if self.type == self.CRYPT:
                    return f"{self.systemTxtCaids.get(caid[:2].upper())}"
                try:
                    pid = f"{int(ecm_info.get('pid', ''), 16):004X}"
                except Exception as e:
                    logger.error(f"getText (line 557): {e}")
                    pid = ""
                if self.type == self.PID:
                    return pid
                try:
                    prov = f"{int(ecm_info.get('prov', ''), 16):006X}"
                except Exception:
                    prov = ecm_info.get("prov", "")
                if self.type == self.PROV:
                    return prov
                if ecm_info.get("ecm time", "").find("msec") > -1:
                    ecm_time = ecm_info.get("ecm time", "")
                else:
                    ecm_time = ecm_info.get("ecm time", "").replace(".","").lstrip("0") + " msec"
                if self.type == self.DELAY:
                    return ecm_time
                
                # Continue with rest of original logic...
                protocol = ecm_info.get("protocol", "")
                port = ecm_info.get("port", "")
                source = ecm_info.get("source", "")
                server = ecm_info.get("server", "")
                hops = ecm_info.get("hops", "")
                system = ecm_info.get("system", "")
                provider = ecm_info.get("provider", "")
                reader = ecm_info.get("reader", "")
                chid = ecm_info.get("chid", "")

                # REPAIRED: optional privacy masking of server/reader identity,
                # e.g. before taking a screenshot to share publicly.
                try:
                    if config.plugins.softcam.hideServerName.value:
                        if server:
                            server = "*****"
                        if reader:
                            reader = "*****"
                except AttributeError:
                    pass

                if self.type == self.CRDTXT:
                    info_card = "False"
                    if source == "sci":
                        info_card = "True"
                    if source != "cache" and source != "net" and source.find("emu") == -1:
                        info_card = "True"
                    return info_card
                if self.type == self.HOST:
                    return server
                if self.type == self.FORMAT or self.type == self.USE_CFG:
                    if self.type == self.USE_CFG:
                        self.sfmt = config.plugins.j00zekCC.ciFormat.value
                    textvalue = ""
                    params = self.sfmt.split(" ")

                    for param in params:
                        if param != '':
                            if param[0] != '%': textvalue += param
                            elif param == "%S": textvalue += server
                            elif param == "%H": textvalue += hops
                            elif param == "%SY": textvalue += system
                            elif param == "%PV": textvalue += provider
                            elif param == "%SP": textvalue += port
                            elif param == "%PR": textvalue += protocol
                            elif param == "%C": textvalue += caid
                            elif param == "%P": textvalue += pid
                            elif param == "%p": textvalue += prov
                            elif param == "%O": textvalue += source
                            elif param == "%R": textvalue += reader
                            elif param == "%T": textvalue += ecm_time
                            elif param == "%CH": textvalue += chid
                            elif param == "%SCN": textvalue += softCamName
                            elif param == "%SCFN": textvalue += softCamName
                            elif param == "%t": textvalue += "\t"
                            elif param == "%n": textvalue += "\n"
                            elif param[1:].isdigit(): textvalue=textvalue.ljust(len(textvalue)+int(param[1:]))

                            if len(textvalue) > 0:
                                if textvalue[-1] != "\t" and textvalue[-1] != "\n":
                                    textvalue+=" "
                    return textvalue[:-1]
                if self.type == self.ALL:
                    if source == "emu":
                        textvalue = f"{source} - {self.systemTxtCaids.get(caid[:2])} (Prov: {prov}, Caid: {caid})"
                    elif reader != "" and source == "net" and port != "":
                        textvalue = f"{source} - Prov: {prov}, Caid: {caid}, Reader: {reader}, {protocol} ({server}:{port}) - {ecm_time.replace('msec', 'ms')}"
                    elif reader != "" and source == "net":
                        textvalue = f"{source} - Prov: {prov}, Caid: {caid}, Reader: {reader}, {protocol} ({server}) - {ecm_time.replace('msec', 'ms')}"
                    elif reader != "" and source != "net":
                        textvalue = f"{source} - Prov: {prov}, Caid: {caid}, Reader: {reader}, {protocol} (local) - {ecm_time.replace('msec', 'ms')}"
                    elif server == "" and port == "" and protocol != "":
                        textvalue = f"{source} - Prov: {prov}, Caid: {caid}, {protocol} - {ecm_time.replace('msec', 'ms')}"
                    elif server == "" and port == "" and protocol == "":
                        textvalue = f"{source} - Prov: {prov}, Caid: {caid} - {ecm_time.replace('msec', 'ms')}"
                    else:
                        try:
                            textvalue = f"{source} - Prov: {prov}, Caid: {caid}, {protocol} ({server}:{port}) - {ecm_time.replace('msec', 'ms')}"
                        except Exception:
                            pass
                if self.type == self.SHORT:
                    if source == "emu":
                        textvalue = f"{source} - {self.systemTxtCaids.get(caid[:2])} (Prov: {prov}, Caid: {caid})"
                    elif server == "" and port == "":
                        textvalue = f"{source} - Prov: {prov}, Caid: {caid} - {ecm_time.replace('msec', 'ms')}"
                    else:
                        try:
                            textvalue = f"{source} - Prov: {prov}, Caid: {caid}, {server}:{port} - {ecm_time.replace('msec', 'ms')}"
                        except Exception:
                            pass
        return textvalue

    text = property(getText)

    def ecmfileContent(self):
        """REPAIRED: Added caching for ECM file content"""
        if DBG: j00zekDEBUG('[j00zekModCaidInfo2:ecmfileContent] >>>')
        
        # REPAIRED: Reduced polling frequency
        self.poll_interval = self.my_interval
        self.poll_enabled = True
        
        ecminfo = ""
        try:
            if fileExists("/tmp/ecm.info"):
                with open("/tmp/ecm.info", "r") as ecmfiles:
                    for line in ecmfiles:
                        if line.find("caid:") > -1 or line.find("provider:") > -1 or line.find("provid:") > -1 or line.find("pid:") > -1 or line.find("hops:") > -1 or line.find("system:") > -1 or line.find("address:") > -1 or line.find("using:") > -1 or line.find("ecm time:") > -1:
                            line = line.replace(' ',"").replace(":",": ")
                        if line.find("caid:") > -1 or line.find("pid:") > -1 or line.find("reader:") > -1 or line.find("from:") > -1 or line.find("hops:") > -1 or line.find("system:") > -1 or line.find("Service:") > -1 or line.find("CAID:") > -1 or line.find("Provider:") > -1:
                            line = line.strip('\n') + "  "
                        if line.find("Signature") > -1:
                            line = ""
                        if line.find("=") > -1:
                            line = line.lstrip('=').replace('======', "").replace('\n', "").rstrip() + ', '
                        if line.find("ecmtime:") > -1:
                            line = line.replace("ecmtime:", "ecm time:")
                        if line.find("response time:") > -1:
                            line = line.replace("response time:", "ecm time:").replace("decoded by", "by")
                        if not line.startswith('\n'):
                            if line.find('pkey:') > -1:
                                line = '\n' + line + '\n'
                            ecminfo += line
                    ecmfiles.close()
        except Exception as e:
            if DBG:
                j00zekDEBUG(f'\t Exception analyzing content of /tmp/ecm.info : {e!s}')
        return ecminfo

    def ecmfile(self):
        """REPAIRED: ECM file reading with reduced frequency checks"""
        global info
        global old_ecm_mtime
        ecm = None
        service = self.source.service
        if service:
            try:
                # REPAIRED: Check file modification time before reading
                if not fileExists("/tmp/ecm.info"):
                    info = {}
                    return info
                    
                ecm_mtime = os.stat("/tmp/ecm.info").st_mtime
                if not os.stat("/tmp/ecm.info").st_size > 0:
                    info = {}
                    return info
                    
                # Only read file if it has been modified
                if ecm_mtime == old_ecm_mtime:
                    return info
                old_ecm_mtime = ecm_mtime
                
                ecmf = open("/tmp/ecm.info", "r")
                ecm = ecmf.readlines()
                ecmf.close()
            except Exception:
                old_ecm_mtime = None
                info = {}
                return info

            if ecm:
                # Process ECM data (logic unchanged but called less frequently)
                for line in ecm:
                    x = line.lower().find("msec")
                    if x != -1:
                        info["ecm time"] = line[0:x+4]
                    else:
                        item = line.split(":", 1)
                        if len(item) > 1:
                            if item[0] == "Provider":
                                item[0] = "prov"
                                item[1] = item[1].strip()[2:]
                            elif item[0] == "ECM PID":
                                item[0] = "pid"
                            elif item[0] == "response time":
                                info["source"] = "net"
                                it_tmp = item[1].strip().split(" ")
                                info["ecm time"] = f"{it_tmp[0]} msec"
                                info["reader"] = it_tmp[-1].strip('R0[').strip(']')
                                y = it_tmp[-1].find('[')
                                if y !=-1:
                                    info["server"] = it_tmp[-1][:y]
                                    info["protocol"] = it_tmp[-1][y+1:-1]
                                y = it_tmp[-1].find('(')
                                if y !=-1:
                                    info["server"] = it_tmp[-1].split("(")[-1].split(":")[0]
                                    info["port"] = it_tmp[-1].split("(")[-1].split(":")[-1].rstrip(")")
                                    info["reader"] = it_tmp[-2]
                                elif y == -1:
                                    item[0] = "source"
                                    item[1] = "sci"
                                if it_tmp[-1].find('emu') >-1 or it_tmp[-1].find('EMU') >-1 or it_tmp[-1].find('cache') > -1 or it_tmp[-1].find('card') > -1 or it_tmp[-1].find('biss') > -1:
                                    item[0] = "source"
                                    item[1] = "emu"
                            elif item[0] == "hops":
                                item[1] = item[1].strip("\n")
                            elif item[0] == "system":
                                item[1] = item[1].strip("\n")
                            elif item[0] == "provider":
                                item[1] = item[1].strip("\n")
                            elif item[0][:2] == 'cw'or item[0] =='ChID' or item[0] == "Service":
                                pass
                            elif item[0] == "source":
                                if item[1].strip()[:3] == "net":
                                    it_tmp = item[1].strip().split(" ")
                                    info["protocol"] = it_tmp[1][1:]
                                    info["server"] = it_tmp[-1].split(":", 1)[0]
                                    info["port"] = it_tmp[-1].split(':', 1)[1][:-1]
                                    item[1] = "net"
                            elif item[0] == "prov":
                                y = item[1].find(",")
                                if y != -1:
                                    item[1] = item[1][:y]
                            elif item[0] == "reader":
                                if item[1].strip() == "emu":
                                    item[0] = "source"
                            elif item[0] == "from":
                                if item[1].lower().find("local") > -1:
                                    item[1] = "sci"
                                    item[0] = "source"
                                else:
                                    info["source"] = "net"
                                    item[0] = "server"
                            elif item[0] == "provid":
                                item[0] = "prov"
                            elif item[0] == "using":
                                if item[1].strip() == "emu" or item[1].strip() == "sci":
                                    item[0] = "source"
                                else:
                                    info["source"] = "net"
                                    item[0] = "protocol"
                            elif item[0] == "address":
                                tt = item[1].find(":")
                                if tt != -1:
                                    info["server"] = item[1][:tt].strip()
                                    item[0] = "port"
                                    item[1] = item[1][tt + 1:]
                            info[item[0].strip().lower()] = item[1].strip()
                        else:
                            if "caid" not in info:
                                x = line.lower().find("caid")
                                if x != -1:
                                    y = line.find(",")
                                    if y != -1:
                                        info["caid"] = line[x + 5:y]
                            if "pid" not in info:
                                x = line.lower().find("pid")
                                if x != -1:
                                    y = line.find(" =")
                                    z = line.find(" *")
                                    if y != -1:
                                        info["pid"] = line[x + 4:y]
                                    elif z != -1:
                                        info["pid"] = line[x + 4:z]
        return info

    def changed(self, what):
        Converter.changed(self, (self.CHANGED_POLL,))

    def ciModuleStateChanged(self, slot):
        """REPAIRED: CI module state change with reduced update frequency"""
        if DBG:
            j00zekDEBUG('[j00zekModCaidInfo2:ciModuleStateChanged] >>>')
        # REPAIRED: Don't immediately trigger updates to reduce graphics load
        # Instead, rely on the polling mechanism
        pass
