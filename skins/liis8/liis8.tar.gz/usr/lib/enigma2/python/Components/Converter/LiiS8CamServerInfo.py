# LiiS8CamServerInfo
# Exposes Host / Port / User / Pass of the active CAM server
# for OSCam, NCam, CCcam and MgCamd.
#
# IMPORTANT: this file is intentionally SEPARATE from LiiS8Access.py,
# LiiS8CaidInfo2.py, LiiS8CamdRAED.py, LiiS8EcmInfo.py and LiiS8CryptoInfo.py.
# It does not touch or import from them, so nothing that already works
# in the skin is at risk.
#
# Skin usage example:
# <widget source="session.CurrentService" render="Label" position="0,0" size="200,20" font="Regular;16">
#     <convert type="LiiS8CamServerInfo">Host</convert>
# </widget>
# <widget source="session.CurrentService" render="Label" position="0,20" size="200,20" font="Regular;16">
#     <convert type="LiiS8CamServerInfo">Port</convert>
# </widget>
# <widget source="session.CurrentService" render="Label" position="0,40" size="200,20" font="Regular;16">
#     <convert type="LiiS8CamServerInfo">User</convert>
# </widget>
# <widget source="session.CurrentService" render="Label" position="0,60" size="200,20" font="Regular;16">
#     <convert type="LiiS8CamServerInfo">PassMasked</convert>
# </widget>
#
# Supported "type" values:
#   Host          -> server address of the first active reader/entry found
#   Port          -> port of that entry
#   User          -> username of that entry
#   Pass           -> RAW password (only use this on a screen you control - not on infobar/screenshots)
#   PassMasked    -> password with all but the last 3 characters replaced by *
#   CamType       -> which emulator was detected (oscam / ncam / cccam / mgcamd / unknown)
#   Label         -> the reader label / server name, if available
#   All           -> "user:pass@host:port" convenience string (raw password)

try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")

from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached
import os
import re


# ---------------------------------------------------------------------------
# Candidate config paths per emulator. Different images/versions put these
# in slightly different places, so we try each candidate in order and use
# the first one that actually exists on this box.
# ---------------------------------------------------------------------------
OSCAM_PATHS = [
	"/etc/tuxbox/config/oscam.server",
	"/usr/keys/oscam.server",
	"/var/etc/oscam.server",
	"/var/tuxbox/config/oscam.server",
]

NCAM_PATHS = [
	"/etc/tuxbox/config/ncam.server",
	"/usr/keys/ncam.server",
	"/var/etc/ncam.server",
	"/var/tuxbox/config/ncam.server",
]

CCCAM_PATHS = [
	"/etc/CCcam.cfg",
	"/etc/tuxbox/config/CCcam.cfg",
	"/usr/keys/CCcam.cfg",
	"/var/etc/CCcam.cfg",
]

MGCAMD_PATHS = [
	"/etc/tuxbox/config/mg/mg_cfg",
	"/etc/tuxbox/config/mgcamd.cfg",
	"/usr/keys/mgcamd.cfg",
	"/var/etc/mgcamd.cfg",
]


def _first_existing(paths):
	for p in paths:
		if os.path.exists(p):
			return p
	return None


def detect_cam_and_config():
	"""
	Very small, best-effort detector - separate from the one in
	LiiS8CamdRAED.py on purpose so this file has zero dependency on it.
	Returns (camtype, path) or (None, None) if nothing recognizable was found.
	"""
	if os.path.exists("/tmp/.ncam/ncam.version"):
		path = _first_existing(NCAM_PATHS)
		if path:
			return "ncam", path
	if os.path.exists("/tmp/.oscam/oscam.version"):
		path = _first_existing(OSCAM_PATHS)
		if path:
			return "oscam", path
	path = _first_existing(CCCAM_PATHS)
	if path:
		return "cccam", path
	path = _first_existing(MGCAMD_PATHS)
	if path:
		return "mgcamd", path
	# fall back: config file present even if version file wasn't found
	path = _first_existing(OSCAM_PATHS)
	if path:
		return "oscam", path
	path = _first_existing(NCAM_PATHS)
	if path:
		return "ncam", path
	return None, None


# ---------------------------------------------------------------------------
# Live status: which reader is ACTUALLY decoding right now.
# This is the same /tmp/ecm*.info file LiiS8Access.py / LiiS8CaidInfo2.py
# already read for ECM status - oscam/ncam write the label of whichever
# reader just decoded the current channel's ECM into a "Reader:" line.
# ---------------------------------------------------------------------------
_ECM_INFO_CANDIDATES = [
	"/tmp/ecm7.info", "/tmp/ecm6.info", "/tmp/ecm5.info", "/tmp/ecm4.info",
	"/tmp/ecm3.info", "/tmp/ecm2.info", "/tmp/ecm1.info", "/tmp/ecm.info",
]


def _find_ecm_info_path():
	for p in _ECM_INFO_CANDIDATES:
		if os.path.exists(p) and os.path.getsize(p) > 0:
			return p
	return None


def get_live_reader_label():
	"""
	Returns the label of the reader currently decoding the channel being
	watched, or None if nothing is decoding right now (FTA channel, no
	ecm.info yet, etc). This is a live/runtime fact, NOT something the
	config file alone can tell you.
	"""
	path = _find_ecm_info_path()
	if not path:
		return None
	try:
		with open(path, "r") as f:
			for line in f:
				if line.strip().lower().startswith("reader"):
					_, _, value = line.partition(":")
					label = value.strip()
					if label and label.lower() not in ("emu", "cache", ""):
						return label
	except Exception as e:
		logger.error(f"get_live_reader_label: {e}")
	return None


# ---------------------------------------------------------------------------
# Config parsing
# ---------------------------------------------------------------------------
# protocols that are local/self-contained and never represent a real
# network server - blocks using these are always skipped
_NON_NETWORK_PROTOCOLS = ("emu", "internal")


def _reader_block_is_usable(block):
	if block.get("enable") == "0":
		return False
	if block.get("protocol", "").lower() in _NON_NETWORK_PROTOCOLS:
		return False
	if "," not in block.get("device", ""):
		return False  # not a host,port pair (e.g. a URL or /dev/sci0)
	return True


def _parse_all_oscam_readers(path):
	"""Parses every [reader] block in oscam.server / ncam.server into a list of dicts, in file order."""
	blocks = []
	current = None
	try:
		with open(path, "r") as f:
			for raw_line in f:
				line = raw_line.strip()
				if not line or line.startswith("#") or line.startswith(";"):
					continue
				if line.startswith("[") and line.endswith("]"):
					if line.lower() == "[reader]":
						current = {"label": "", "enable": "1", "protocol": "", "device": "", "user": "", "pass": ""}
						blocks.append(current)
					else:
						current = None
					continue
				if current is None or "=" not in line:
					continue
				key, _, value = line.partition("=")
				key = key.strip().lower()
				value = value.strip()
				if key == "label":
					current["label"] = value
				elif key == "enable":
					current["enable"] = value
				elif key == "protocol":
					current["protocol"] = value
				elif key == "device":
					current["device"] = value
				elif key in ("user", "username"):
					current["user"] = value
				elif key in ("password", "pass"):
					current["pass"] = value
	except Exception as e:
		logger.error(f"_parse_all_oscam_readers: {e}")
	return blocks


def _block_to_result(block):
	parts = block["device"].split(",")
	return {
		"host": parts[0].strip() if len(parts) >= 1 else "",
		"port": parts[1].strip() if len(parts) >= 2 else "",
		"user": block["user"],
		"pass": block["pass"],
		"label": block["label"],
	}


def parse_oscam_style(path):
	"""
	Priority 1: the live reader value from ecm.info is often the actual
	"host:port" of the server directly (confirmed from a real OSCam
	status screen) rather than the config label. When that's the case we
	use host/port straight from ecm.info, and find user/pass by matching
	that same host+port against each [reader] block's device= field.
	Priority 2: if the live value has no ":" (older/other OSCam builds
	report the label instead), match by label as before.
	Priority 3 (fallback, nothing decoding right now): last enabled,
	real-network block.
	"""
	result = {"host": "", "port": "", "user": "", "pass": "", "label": ""}
	blocks = _parse_all_oscam_readers(path)
	if not blocks:
		return result

	live_value = get_live_reader_label()
	if live_value:
		if ":" in live_value:
			live_host, _, live_port = live_value.rpartition(":")
			live_host = live_host.strip()
			live_port = live_port.strip()
			for b in blocks:
				b_host, _, b_port = b.get("device", "").partition(",")
				if b_host.strip().lower() == live_host.lower() and (not live_port or b_port.strip() == live_port):
					out = _block_to_result(b)
					out["host"], out["port"] = live_host, live_port  # trust the live value
					return out
			# no config block matches this address (e.g. reader was
			# renamed/removed) - we still know host/port, just not user/pass
			result["host"], result["port"] = live_host, live_port
			return result
		else:
			for b in blocks:
				if b["label"].strip().lower() == live_value.strip().lower():
					return _block_to_result(b)
		logger.debug(f"parse_oscam_style: live reader '{live_value}' not matched in {path}, falling back")

	valid_blocks = [b for b in blocks if _reader_block_is_usable(b)]
	if valid_blocks:
		result = _block_to_result(valid_blocks[-1])
	return result


def parse_cccam_style(path):
	"""
	Parses CCcam.cfg / mg_cfg style files:
		C: host port user pass
		N: host port user pass ...
	Returns the FIRST "C:" (or, if none, first "N:") line found.
	"""
	result = {"host": "", "port": "", "user": "", "pass": "", "label": ""}
	try:
		fallback = None
		with open(path, "r") as f:
			for raw_line in f:
				line = raw_line.strip()
				if line.upper().startswith("C:"):
					parts = line[2:].split()
					if len(parts) >= 4:
						result["host"], result["port"], result["user"], result["pass"] = parts[0], parts[1], parts[2], parts[3]
						result["label"] = "cccam"
						return result
				elif line.upper().startswith("N:") and fallback is None:
					parts = line[2:].split()
					if len(parts) >= 4:
						fallback = {"host": parts[0], "port": parts[1], "user": parts[2], "pass": parts[3], "label": "newcamd"}
		if fallback:
			result = fallback
	except Exception as e:
		logger.error(f"parse_cccam_style: {e}")
	return result


# ---------------------------------------------------------------------------
# OSCam webif (local status.html) - the ONLY source that tells us whether a
# reader is actually CONNECTED right now, independent of any decode
# happening at this instant.
# ---------------------------------------------------------------------------
_OSCAM_CONF_PATHS = [
	"/etc/tuxbox/config/oscam.conf",
	"/var/etc/oscam.conf",
	"/usr/keys/oscam.conf",
	"/var/tuxbox/config/oscam.conf",
]


def _read_webif_config():
	"""Reads httpport/httpuser from the [webif] section of oscam.conf."""
	conf_path = _first_existing(_OSCAM_CONF_PATHS)
	if not conf_path:
		return None, ""
	port = None
	user = ""
	try:
		in_webif = False
		with open(conf_path, "r") as f:
			for raw_line in f:
				line = raw_line.strip()
				if not line or line.startswith("#") or line.startswith(";"):
					continue
				if line.startswith("[") and line.endswith("]"):
					in_webif = line.lower() == "[webif]"
					continue
				if not in_webif or "=" not in line:
					continue
				key, _, value = line.partition("=")
				key = key.strip().lower()
				value = value.strip()
				if key == "httpport":
					port = value
				elif key == "httpuser":
					user = value
	except Exception as e:
		logger.error(f"_read_webif_config: {e}")
	return port, user


def get_webif_reader_status(label):
	"""
	Fetches http://127.0.0.1:<httpport>/status.html and returns the live
	state of the READER row matching `label` - NOT the client row (which
	also mentions the label, e.g. "FiFa2026 (995 ms)" for the last-used
	reader of a client). The reader row is identified by its unique
	"readerconfig.html?label=<label>" edit link.
	Returns None if webif isn't configured/reachable, or the label wasn't
	found in the table (e.g. still starting up).
	"""
	port, user = _read_webif_config()
	if not port:
		return None
	try:
		import urllib.request
		import base64
		url = f"http://127.0.0.1:{port}/status.html"
		req = urllib.request.Request(url)
		if user:
			token = base64.b64encode(f"{user}:".encode()).decode()
			req.add_header("Authorization", f"Basic {token}")
		with urllib.request.urlopen(req, timeout=3) as resp:
			html = resp.read().decode("utf-8", errors="ignore")
	except Exception as e:
		logger.error(f"get_webif_reader_status: {e}")
		return None

	marker = f'readerconfig.html?label={label}"'
	idx = html.find(marker)
	if idx == -1:
		return None
	# work only within this one row: from the marker to the next </TR>
	row_end = html.find("</TR>", idx)
	row = html[idx:row_end if row_end != -1 else idx + 4000]

	m_state = re.search(r'CLASS="tooltip">(ON|OFF)<SPAN', row)
	m_addr = re.search(r'CLASS="statuscol7">([^<]*)</TD>', row)
	m_port = re.search(r'CLASS="statuscol8">([^<]*)</TD>', row)
	m_proto = re.search(r'CLASS="statuscol9"[^>]*>([^<]*)</TD>', row)
	m_status = re.search(r'CLASS="statuscol16">([^<]*)', row)

	return {
		"enabled": m_state.group(1) if m_state else "",
		"address": m_addr.group(1).strip() if m_addr else "",
		"port": m_port.group(1).strip() if m_port else "",
		"protocol": m_proto.group(1).strip() if m_proto else "",
		"status": m_status.group(1).strip() if m_status else "",
	}


def get_server_info():
	camtype, path = detect_cam_and_config()
	if not camtype or not path:
		return "unknown", {"host": "", "port": "", "user": "", "pass": "", "label": "", "status": "", "enabled": "", "protocol": ""}
	if camtype in ("oscam", "ncam"):
		data = parse_oscam_style(path)
		data.setdefault("status", "")
		data.setdefault("enabled", "")
		data.setdefault("protocol", "")
		if data.get("label"):
			webif = get_webif_reader_status(data["label"])
			if webif:
				data["status"] = webif["status"]
				data["enabled"] = webif["enabled"]
				data["protocol"] = webif["protocol"]
				# webif is the ground truth for host/port too - live and
				# always numeric IP, unlike ecm.info which can vary by build
				if webif.get("address"):
					data["host"] = webif["address"]
				if webif.get("port"):
					data["port"] = webif["port"]
		return camtype, data
	if camtype in ("cccam", "mgcamd"):
		data = parse_cccam_style(path)
		data.setdefault("status", "")
		data.setdefault("enabled", "")
		data.setdefault("protocol", "")
		return camtype, data
	return camtype, {"host": "", "port": "", "user": "", "pass": "", "label": "", "status": "", "enabled": "", "protocol": ""}


def mask_password(pw):
	if not pw:
		return ""
	if len(pw) <= 3:
		return "*" * len(pw)
	return "*" * (len(pw) - 3) + pw[-3:]


class LiiS8CamServerInfo(Poll, Converter, object):
	HOST = 0
	PORT = 1
	USER = 2
	PASS = 3
	PASSMASKED = 4
	CAMTYPE = 5
	LABEL = 6
	ALL = 7
	STATUS = 8
	PROTOCOL = 9
	ENABLED = 10

	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)
		self.poll_interval = 5000  # config files rarely change - no need to poll fast
		self.poll_enabled = True
		if type == "Host":
			self.type = self.HOST
		elif type == "Port":
			self.type = self.PORT
		elif type == "User":
			self.type = self.USER
		elif type == "Pass":
			self.type = self.PASS
		elif type == "PassMasked":
			self.type = self.PASSMASKED
		elif type == "CamType":
			self.type = self.CAMTYPE
		elif type == "Label":
			self.type = self.LABEL
		elif type == "ConnectionStatus":
			self.type = self.STATUS
		elif type == "Protocol":
			self.type = self.PROTOCOL
		elif type == "Enabled":
			self.type = self.ENABLED
		else:
			self.type = self.ALL

	@cached
	def getText(self):
		camtype, data = get_server_info()

		if self.type == self.CAMTYPE:
			return camtype
		if self.type == self.LABEL:
			return data.get("label", "")
		if self.type == self.HOST:
			return data.get("host", "")
		if self.type == self.PORT:
			return data.get("port", "")
		if self.type == self.USER:
			return data.get("user", "")
		if self.type == self.PASS:
			return data.get("pass", "")
		if self.type == self.PASSMASKED:
			return mask_password(data.get("pass", ""))
		if self.type == self.STATUS:
			return data.get("status", "")
		if self.type == self.PROTOCOL:
			return data.get("protocol", "")
		if self.type == self.ENABLED:
			return data.get("enabled", "")
		if self.type == self.ALL:
			return f"{data.get('user','')}:{data.get('pass','')}@{data.get('host','')}:{data.get('port','')}"
		return ""

	text = property(getText)

	def changed(self, what):
		Converter.changed(self, what)
