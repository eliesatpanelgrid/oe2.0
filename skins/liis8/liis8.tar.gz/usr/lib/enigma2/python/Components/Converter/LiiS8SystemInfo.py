# LiiS8SystemInfo
# -*- coding: utf-8 -*-
# LiiS8SystemInfo - RAM usage & CPU speed/usage converter for enigma2
# by LiiS8, 2026
try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")
from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.Converter.Poll import Poll

_cpu_last = {"idle": 0, "total": 0}


def _read_cpu_percent():
	try:
		with open("/proc/stat", "r") as f:
			line = f.readline()
		parts = line.split()
		# user nice system idle iowait irq softirq
		values = [int(x) for x in parts[1:8]]
		idle = values[3] + values[4]
		total = sum(values)
		prev_idle = _cpu_last["idle"]
		prev_total = _cpu_last["total"]
		_cpu_last["idle"] = idle
		_cpu_last["total"] = total
		diff_idle = idle - prev_idle
		diff_total = total - prev_total
		if diff_total <= 0:
			return 0
		usage = (1 - (diff_idle / float(diff_total))) * 100
		return max(0, min(100, usage))
	except Exception as e:
		logger.error(f"_read_cpu_percent (line 31): {e}")
		return 0


def _read_mem_usage():
	try:
		meminfo = {}
		with open("/proc/meminfo", "r") as f:
			for line in f:
				parts = line.split(":")
				if len(parts) == 2:
					key = parts[0].strip()
					val = parts[1].strip().split()[0]
					meminfo[key] = int(val)
		total = meminfo.get("MemTotal", 0)
		free = meminfo.get("MemFree", 0)
		buffers = meminfo.get("Buffers", 0)
		cached = meminfo.get("Cached", 0)
		used = total - free - buffers - cached
		if used < 0:
			used = total - free
		return total, used
	except Exception as e:
		logger.error(f"_read_mem_usage (line 53): {e}")
		return 0, 0


def _read_cpu_freq():
	# المحاولة 1: من /proc/cpuinfo
	try:
		with open("/proc/cpuinfo", "r") as f:
			for line in f:
				if "cpu MHz" in line or "clock" in line.lower():
					val = line.split(":")[1].strip()
					val = val.replace("MHz", "").strip()
					return float(val)
	except Exception as e:
		logger.error(f"_read_cpu_freq (line 66): {e}")
		pass
	# المحاولة 2: من sysfs (أدق على أغلب أجهزة enigma2)
	try:
		with open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq", "r") as f:
			khz = int(f.read().strip())
			return khz / 1000.0
	except Exception as e:
		logger.error(f"_read_cpu_freq (line 73): {e}")
		pass
	# المحاولة 3: تردد ثابت (max freq) لو التردد الحالي غير متاح
	try:
		with open("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq", "r") as f:
			khz = int(f.read().strip())
			return khz / 1000.0
	except Exception as e:
		logger.error(f"_read_cpu_freq (line 80): {e}")
		pass
	return 0


class LiiS8SystemInfo(Poll, Converter):
	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)
		self.type = type
		self.poll_interval = 2000
		self.poll_enabled = True

	@cached
	def getText(self):
		if self.type == "CPUUsage":
			usage = _read_cpu_percent()
			return f"CPU: {int(usage)}%"
		elif self.type == "CPUUsageValue":
			return f"{int(_read_cpu_percent())}"
		elif self.type == "CPUSpeed":
			mhz = _read_cpu_freq()
			if mhz <= 0:
				return "CPU: N/A"
			if mhz >= 1000:
				return f"{mhz / 1000.0:.2f} GHz"
			return f"{int(mhz)} MHz"
		elif self.type == "CPUFull":
			usage = _read_cpu_percent()
			mhz = _read_cpu_freq()
			speed = f"{mhz / 1000.0:.2f} GHz" if mhz >= 1000 else f"{int(mhz)} MHz"
			return f"CPU: {int(usage)}% ({speed})"
		elif self.type == "RAMUsage":
			total, used = _read_mem_usage()
			if total > 0:
				pct = used * 100.0 / total
				return f"RAM: {int(pct)}%"
			return "RAM: N/A"
		elif self.type == "RAMUsageValue":
			total, used = _read_mem_usage()
			if total > 0:
				return f"{int(used * 100.0 / total)}"
			return "0"
		elif self.type == "RAMUsageMB":
			total, used = _read_mem_usage()
			if total > 0:
				return f"{int(used // 1024)}/{int(total // 1024)} MB"
			return "N/A"
		elif self.type == "RAMFull":
			total, used = _read_mem_usage()
			if total > 0:
				pct = used * 100.0 / total
				return f"RAM: {int(pct)}% ({int(used // 1024)}/{int(total // 1024)} MB)"
			return "RAM: N/A"
		return ""

	text = property(getText)

	def changed(self, what):
		Converter.changed(self, what)
