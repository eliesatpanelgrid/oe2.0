# Updated on 05-07-2026 by developer Li-iS8
# LiiS8ServiceName2
#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import division
try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")
#
# Extended ServiceName Converter for Enigma2 Dreamboxes (ServiceName2.py)
# Coded by vlamo (c) 2011
#
# Version: 0.5 (03.06.2011 18:40)
# Version: 0.6 (08.09.2012) add Alternative numbering mode support - Dmitry73 & 2boom
# Version: 0.7 (19.10.2012) add stream mapping
# Version: 0.8 (19.09.2013) add iptv info - nikolasi & 2boom
# Version: 0.9 (29.10.2013) add correct output channelnumner - Dmitry73
# Version: 0.10 (18.11.2013) code fix and optimization - Taapat & nikolasi
# Version: 1.1 (04.12.2013) code fix and optimization - Dmitry73
# Version: 1.2 (06-17.12.2013) small cosmetic fix - 2boom
# Version: 1.3 (25.12.2013) small iptv fix - MegAndretH
# Version: 1.4 (27.01.2014) small iptv fix - 2boom
# Version: 1.5 (30.06.2014) fix iptv reference - 2boom
# Version: 1.6 (04.07.2014) fix iptv reference cosmetic - 2boom
# Version: 1.7 (14.10.2014) add Tricolor Sibir prov - 2boom
# Version: 1.8 (10.03.2015) remove Tricolor Sibir prov - 2boom
# Version: 1.9 (15.03.2015) add custom provname - 2boom
# Version: 1.10 (31.07.2015) add custom provname for custom name channel- 2boom
# Version: 2.1 (11.12.2018) Edit to compitable with OE2.0 and OE2.5 - RAED
# Version: 2.2 (21.05.2021) Support py3 - RAED
# 2025.04.01 @ lululla fix

# ==============================================
# LiiS8ServiceName2 – Supported Placeholders Reference
# ==============================================

# %O → Service name (channel name) 
#       e.g. "BBC One HD"

# %N → Service number (channel number)
#       e.g. "101"

# %B → Bouquet name 
#       e.g. "Entertainment"

# %P → Provider name 
#       DVB: "Sky UK"
#       IPTV: "SHARA IPTV" / "Farline" (if mapped)

# %R → Full service reference 
#       e.g. "1:0:1:6DCA:44D:1:C00000:0:0:0:"

# %S → Satellite name
#       e.g. "Astra 28.2E", or "Internet" (for IPTV)

# %A → AllRef (reference type)
#       e.g. "Bouquet …", "Provider …", or stream URL

# %T / %t → Tuner type
#       e.g. "Satellite", "Cable", "Terrestrial", "Stream-tv"

# %s → System 
#       e.g. "DVB-S", "DVB-S2"

# %F → Frequency 
#       DVB-S/C: "11938 MHz"
#       DVB-T: "498.000 MHz"
#       IPTV: (skipped / hidden)

# %Y → Symbol rate 
#       DVB-S/C: "27500"
#       IPTV: (skipped / hidden)

# %f → FEC inner 
#       e.g. "3/4", "5/6", "Auto"

# %i → Inversion 
#       e.g. "On", "Off", "Auto"

# %O (inside transponder) → Orbital position
#       e.g. "13.0E", "30.0W"
#       DVB-T → "DVB-T"
#       DVB-C → "DVB-C"
#       IPTV → "Stream"

# %M → Modulation 
#       DVB-S: "QPSK", "8PSK"
#       DVB-C: "QAM64", "QAM256"

# %p → Polarization 
#       "H", "V", "L", "R"

# %r → Rolloff (DVB-S2 only)
#       e.g. "0.35", "0.25", "0.20"

# %o → Pilot (DVB-S2 only)
#       e.g. "Off", "On", "Auto"

# %c → Constellation (DVB-T)
#       e.g. "QPSK", "QAM16", "QAM64"

# %l → Code rate LP (DVB-T)
#       e.g. "2/3", "5/6", "Auto"

# %h → Code rate HP (DVB-T)
#       e.g. "2/3", "5/6", "Auto"

# %m → Transmission mode (DVB-T)
#       e.g. "2k", "8k", "Auto"

# %g → Guard interval (DVB-T)
#       e.g. "1/32", "1/16", "1/8", "1/4"

# %b → Bandwidth (DVB-T)
#       e.g. "8 MHz", "7 MHz", "6 MHz"

# %e → Hierarchy information (DVB-T)
#       e.g. "None", "1", "2", "4", "Auto"

# ==============================================


from Components.Converter.Converter import Converter
from enigma import (
    iServiceInformation,
    iPlayableService,
    iPlayableServicePtr,
    eServiceReference,
    eServiceCenter,
    eTimer,
    getBestPlayableServiceReference,
    iDVBFrontend,
)
from Components.Element import cached
from Components.config import config
import NavigationInstance
from os import path as os_path

import gettext
_ = gettext.gettext


def DreamOS():
    if os_path.exists('/var/lib/dpkg/status'):
        return DreamOS


# ============================================================================
# FIX: caching for the two expensive, uncached linear scans that used to run
# on every single channel zap:
#   - getServiceNumber() walks the whole bouquet/provider service list
#   - getProviderName() walks every provider and every service inside it
# Both are pure functions of (service ref, current list context) - the same
# ref browsed from the same context always returns the same result until the
# channel list itself changes (rescan / bouquet edit / reorder), which is
# rare compared to how often zapping happens. So we cache the result for a
# short time instead of recomputing it on every zap.
#
# The cache key for getServiceNumber() includes lastpath (not just the ref)
# because the same ref can legitimately return a different number/bouquet
# depending on which list it is being viewed from (e.g. "FROM PROVIDERS" vs
# "FROM BOUQUET ..."). Without that, we could serve a stale/wrong number
# while switching between list views.
# ============================================================================
import threading as _threading
import time as _time

_NUMCACHE_TTL = 30
_num_cache = {}
_num_cache_lock = _threading.Lock()

_PROVCACHE_TTL = 30
_prov_cache = {}
_prov_cache_lock = _threading.Lock()

# Cache for the ServiceName2.ref lookup file itself (avoid re-reading /
# re-scanning the file from disk on every zap when the provider is unknown).
_reffile_cache = {"mtime": None, "lines": [], "path": None}
_reffile_lock = _threading.Lock()


def _cache_get(cache, lock, key, ttl):
    with lock:
        entry = cache.get(key)
        if entry is None:
            return None
        ts, value = entry
        if _time.time() - ts > ttl:
            del cache[key]
            return None
        return value


def _cache_set(cache, lock, key, value, max_entries=500):
    with lock:
        cache[key] = (_time.time(), value)
        if len(cache) > max_entries:
            for k in sorted(cache, key=lambda k: cache[k][0])[:max_entries // 4]:
                del cache[k]


def _read_ref_file_cached(path):
    """Read ServiceName2.ref once and keep it cached until the file changes,
    instead of re-opening and re-scanning it from disk on every zap."""
    try:
        mtime = os_path.getmtime(path)
    except OSError:
        return []
    with _reffile_lock:
        if _reffile_cache["path"] == path and _reffile_cache["mtime"] == mtime:
            return _reffile_cache["lines"]
    try:
        with open(path) as f:
            lines = f.readlines()
    except Exception:
        return []
    with _reffile_lock:
        _reffile_cache["path"]  = path
        _reffile_cache["mtime"] = mtime
        _reffile_cache["lines"] = lines
    return lines


class LiiS8ServiceName2(Converter, object):
    NAME = 0
    NUMBER = 1
    BOUQUET = 2
    PROVIDER = 3
    REFERENCE = 4
    ORBPOS = 5
    TPRDATA = 6
    SATELLITE = 7
    ALLREFERENCE = 8
    FORMAT = 9
    # --- Additive: explicit IPTV field types ported from AglareServName2
    # (StreamURL/StreamType/StreamHost), on top of the existing FORMAT
    # placeholder system which is left completely untouched. ---
    STREAMURL = 10
    STREAMTYPE = 11
    STREAMHOST = 12

    def __init__(self, type):
        Converter.__init__(self, type)
        if type == "Name" or not len(str(type)):
            self.type = self.NAME
        elif type == "Number":
            self.type = self.NUMBER
        elif type == "Bouquet":
            self.type = self.BOUQUET
        elif type == "Provider":
            self.type = self.PROVIDER
        elif type == "Reference":
            self.type = self.REFERENCE
        elif type == "OrbitalPos":
            self.type = self.ORBPOS
        elif type == "TransponderInfo":
            self.type = self.TPRDATA
        elif type == "Satellite":
            self.type = self.SATELLITE
        elif type == "AllReference":
            self.type = self.ALLREFERENCE
        elif type == "StreamURL":
            self.type = self.STREAMURL
        elif type == "StreamType":
            self.type = self.STREAMTYPE
        elif type == "StreamHost":
            self.type = self.STREAMHOST
        else:
            self.type = self.FORMAT
            self.sfmt = type[:]

        self.refstr = self.isStream = self.ref = self.info = self.what = self.tpdata = None
        self.timer = eTimer()
        try:
            self.timer.callback.append(self.neededChange)
        except Exception as e:
            logger.error(f"__init__ (line 185): {e}")
            self.timer_conn = self.timer.timeout.connect(self.neededChange)

    def getServiceNumber(self, ref):
        def searchHelper(serviceHandler, num, bouquet):
            servicelist = serviceHandler.list(bouquet)
            if servicelist is not None:
                while True:
                    s = servicelist.getNext()
                    if not s.valid():
                        break
                    if not (s.flags & (eServiceReference.isMarker | eServiceReference.isDirectory)):
                        num += 1
                        if s == ref:
                            return s, num
            return None, num

        if isinstance(ref, eServiceReference):
            isRadioService = ref.getData(0) in (2, 10)
            lastpath = isRadioService and config.radio.lastroot.value or config.tv.lastroot.value

            # FIX: cache by (ref, lastpath) - same ref can mean a different
            # number/bouquet depending on which list it's being viewed from,
            # so lastpath has to be part of the key for this to stay correct.
            cache_key = f"{ref.toString()}|{lastpath}"
            cached = _cache_get(_num_cache, _num_cache_lock, cache_key, _NUMCACHE_TTL)
            if cached is not None:
                return cached

            if 'FROM BOUQUET' not in lastpath:
                if 'FROM PROVIDERS' in lastpath:
                    result = ('P', 'Provider')
                elif 'FROM SATELLITES' in lastpath:
                    result = ('S', 'Satellites')
                elif ') ORDER BY name' in lastpath:
                    result = ('A', 'All Services')
                else:
                    result = (0, 'N/A')
                _cache_set(_num_cache, _num_cache_lock, cache_key, result)
                return result
            try:
                acount = config.plugins.NumberZapExt.enable.value and config.plugins.NumberZapExt.acount.value or config.usage.alternative_number_mode.value
            except Exception as e:
                logger.error(f"searchHelper (line 215): {e}")
                acount = False
            rootstr = ''
            for x in lastpath.split(';'):
                if x != '':
                    rootstr = x
            serviceHandler = eServiceCenter.getInstance()
            if acount is True or not config.usage.multibouquet.value:
                bouquet = eServiceReference(rootstr)
                service, number = searchHelper(serviceHandler, 0, bouquet)
            else:
                if isRadioService:
                    bqrootstr = '1:7:2:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.radio" ORDER BY bouquet'
                else:
                    bqrootstr = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'
                number = 0
                cur = eServiceReference(rootstr)
                bouquet = eServiceReference(bqrootstr)
                bouquetlist = serviceHandler.list(bouquet)
                if bouquetlist is not None:
                    while True:
                        bouquet = bouquetlist.getNext()
                        if not bouquet.valid():
                            break
                        if bouquet.flags & eServiceReference.isDirectory:
                            service, number = searchHelper(serviceHandler, number, bouquet)
                            if service is not None and cur == bouquet:
                                break
            if service is not None:
                info = serviceHandler.info(bouquet)
                name = info and info.getName(bouquet) or ''
                result = (number, name)
                _cache_set(_num_cache, _num_cache_lock, cache_key, result)
                return result
        return 0, ''

    def getProviderName(self, ref):
        if isinstance(ref, eServiceReference):
            refstr = ref.toString()
            cached = _cache_get(_prov_cache, _prov_cache_lock, refstr, _PROVCACHE_TTL)
            if cached is not None:
                return cached
            from Screens.ChannelSelection import service_types_radio, service_types_tv
            typestr = ref.getData(0) in (2, 10) and service_types_radio or service_types_tv
            pos = typestr.rfind(':')
            rootstr = f'{typestr[:pos + 1]} (channelID == {ref.getUnsignedData(4):08x}{ref.getUnsignedData(2):04x}{ref.getUnsignedData(3):04x}) && {typestr[pos + 1:]} FROM PROVIDERS ORDER BY name'
            provider_root = eServiceReference(rootstr)
            serviceHandler = eServiceCenter.getInstance()
            providerlist = serviceHandler.list(provider_root)
            if providerlist is not None:
                while True:
                    provider = providerlist.getNext()
                    if not provider.valid():
                        break
                    if provider.flags & eServiceReference.isDirectory:
                        servicelist = serviceHandler.list(provider)
                        if servicelist is not None:
                            while True:
                                service = servicelist.getNext()
                                if not service.valid():
                                    break
                                if service == ref:
                                    info = serviceHandler.info(provider)
                                    result = info and info.getName(provider) or "Unknown"
                                    _cache_set(_prov_cache, _prov_cache_lock, refstr, result)
                                    return result
        return ""

    def getTransponderInfo(self, info, ref, fmt):
        result = ""
        if self.tpdata is None:
            if ref:
                self.tpdata = ref and info.getInfoObject(ref, iServiceInformation.sTransponderData)
            else:
                self.tpdata = info.getInfoObject(iServiceInformation.sTransponderData)
            if not isinstance(self.tpdata, dict):
                self.tpdata = None
                return result
        if self.isStream:
            type = 'IP-TV'
        else:
            type = self.tpdata.get('tuner_type', '')
        if not fmt or fmt == 'T':
            if DreamOS():
                if type == iDVBFrontend.feCable:
                    fmt = ["t ", "F ", "Y ", "i ", "f ", "M"]  # (type frequency symbol_rate inversion fec modulation)
                elif type == iDVBFrontend.feTerrestrial:
                    if ref:
                        fmt = ["O ", "F ", "c ", "l ", "h ", "m ", "g "]   # (orbital_position code_rate_hp transmission_mode guard_interval constellation)
                    else:
                        fmt = ["t ", "F ", "c ", "l ", "h ", "m ", "g "]   # (type frequency code_rate_hp transmission_mode guard_interval constellation)
                elif type == 'IP-TV':
                    return _("Streaming")
                else:
                    fmt = ["O ", "F", "p ", "Y ", "f"]
            else:
                if type == 'DVB-C':
                    fmt = ["t ", "F ", "Y ", "i ", "f ", "M"]  # (type frequency symbol_rate inversion fec modulation)
                elif type == 'DVB-T':
                    if ref:
                        fmt = ["O ", "F ", "c ", "l ", "h ", "m ", "g "]   # (orbital_position code_rate_hp transmission_mode guard_interval constellation)
                    else:
                        fmt = ["t ", "F ", "c ", "l ", "h ", "m ", "g "]   # (type frequency code_rate_hp transmission_mode guard_interval constellation)
                elif type == 'IP-TV':
                    return _("Streaming")
                else:
                    fmt = ["O ", "F", "p ", "Y ", "f"]
        for line in fmt:
            f = line[:1]
            if f == 't':  # %t - tuner_type (dvb-s/s2/c/t)
                if DreamOS():
                    if type == iDVBFrontend.feSatellite:
                        result += _("Satellite")
                    elif type == iDVBFrontend.feCable:
                        result += _("Cable")
                    elif type == iDVBFrontend.feTerrestrial:
                        result += _("Terrestrial")
                    elif type == 'IP-TV':
                        result += _('Stream-tv')
                    else:
                        result += 'N/A'
                else:
                    if type == 'DVB-S':
                        result += _("Satellite")
                    elif type == 'DVB-C':
                        result += _("Cable")
                    elif type == 'DVB-T':
                        result += _("Terrestrial")
                    elif type == 'IP-TV':
                        result += _('Stream-tv')
                    else:
                        result += 'N/A'
            elif f == 's':  # %s - system (dvb-s/s2/c/t)
                if DreamOS():
                    if type == iDVBFrontend.feSatellite:
                        x = self.tpdata.get('system', 0)
                        result += x in list(range(2)) and {0: 'DVB-S', 1: 'DVB-S2'}[x] or ''
                    else:
                        result += 'N/A'  # str(type)
                else:
                    if type == 'DVB-S':
                        x = self.tpdata.get('system', 0)
                        result += x in list(range(2)) and {0: 'DVB-S', 1: 'DVB-S2'}[x] or ''
                    else:
                        result += 'N/A'
            elif f == 'F':  # %F - frequency
                # Skip frequency output for IPTV/streaming services
                if self.isStream or type == 'IP-TV':
                    continue
                if DreamOS():
                    result += f"{int(self.tpdata.get('frequency', 0) / 1000)}"
                else:
                    if type in ('DVB-S', 'DVB-C') and self.tpdata.get('frequency', 0) > 0:
                        result += f"{int(self.tpdata.get('frequency', 0) / 1000)} MHz"
                    elif type == 'DVB-T':
                        result += f"{(self.tpdata.get('frequency', 0) + 500) / 1000 / 1000.0:.3f} MHz"

                        # result += '%.3f'%(((self.tpdata.get('frequency', 0) / 1000) +1) / 1000.0) + " MHz "
            elif f == 'f':  # %f - fec_inner (dvb-s/s2/c/t)
                if DreamOS():
                    if type == iDVBFrontend.feCable or type == iDVBFrontend.feSatellite:
                        x = self.tpdata.get('fec_inner', 15)
                        result += x in list(range(10)) + [15] and {0: 'Auto', 1: '1/2', 2: '2/3', 3: '3/4', 4: '5/6', 5: '7/8', 6: '8/9', 7: '3/5', 8: '4/5', 9: '9/10', 15: 'None'}[x] or ''
                    elif type == iDVBFrontend.feTerrestrial:
                        x = self.tpdata.get('code_rate_lp', 5)
                        result += x in list(range(6)) and {0: '1/2', 1: '2/3', 2: '3/4', 3: '5/6', 4: '7/8', 5: 'Auto'}[x] or ''
                else:
                    if type in ('DVB-S', 'DVB-C'):
                        x = self.tpdata.get('fec_inner', 15)
                        result += x in list(range(10)) + [15] and {0: 'Auto', 1: '1/2', 2: '2/3', 3: '3/4', 4: '5/6', 5: '7/8', 6: '8/9', 7: '3/5', 8: '4/5', 9: '9/10', 15: 'None'}[x] or ''
                    elif type == 'DVB-T':
                        x = self.tpdata.get('code_rate_lp', 5)
                        result += x in list(range(6)) and {0: '1/2', 1: '2/3', 2: '3/4', 3: '5/6', 4: '7/8', 5: 'Auto'}[x] or ''
            elif f == 'i':  # %i - inversion (dvb-s/s2/c/t)
                if DreamOS():
                    x = self.tpdata.get('inversion', 2)
                    result += x in list(range(3)) and {0: 'On', 1: 'Off', 2: 'Auto'}[x] or ''
                else:
                    if type in ('DVB-S', 'DVB-C', 'DVB-T'):
                        x = self.tpdata.get('inversion', 2)
                        result += x in list(range(3)) and {0: 'On', 1: 'Off', 2: 'Auto'}[x] or ''
            elif f == 'O':  # %O - orbital_position (dvb-s/s2)
                if DreamOS():
                    if type == iDVBFrontend.feSatellite:
                        x = self.tpdata.get('orbital_position', 0)
                        result += x > 1800 and f"{int((3600 - x) / 10)}.{int((3600 - x) % 10)}°W" or f"{int(x / 10)}.{int(x % 10)}°E"
                        result = result.replace("°", "")
                    elif type == 'Iptv':
                        result += 'Stream'
                else:
                    if type == 'DVB-S':
                        x = self.tpdata.get('orbital_position', 0)
                        result += x > 1800 and f"{int((3600 - x) / 10)}.{int((3600 - x) % 10)}°W" or f"{int(x / 10)}.{int(x % 10)}°E"
                        result = result.replace("°", "")
                    elif type == 'DVB-T':
                        result += 'DVB-T'
                    elif type == 'DVB-C':
                        result += 'DVB-C'
                    elif type == 'Iptv':
                        result += 'Stream'
            elif f == 'M':  # %M - modulation (dvb-s/s2/c)
                if DreamOS():
                    x = self.tpdata.get('modulation', 1)
                    if type == iDVBFrontend.feSatellite:
                        result += x in list(range(4)) and {0: 'Auto', 1: 'QPSK', 2: '8PSK', 3: 'QAM16'}[x] or ''
                    elif type == iDVBFrontend.feCable:
                        result += x in list(range(6)) and {0: 'Auto', 1: 'QAM16', 2: 'QAM32', 3: 'QAM64', 4: 'QAM128', 5: 'QAM256'}[x] or ''
                else:
                    x = self.tpdata.get('modulation', 1)
                    if type == 'DVB-S':
                        result += x in list(range(4)) and {0: 'Auto', 1: 'QPSK', 2: '8PSK', 3: 'QAM16'}[x] or ''
                    elif type == 'DVB-C':
                        result += x in list(range(6)) and {0: 'Auto', 1: 'QAM16', 2: 'QAM32', 3: 'QAM64', 4: 'QAM128', 5: 'QAM256'}[x] or ''
            elif f == 'p':  # %p - polarization (dvb-s/s2)
                if DreamOS():
                    if type == iDVBFrontend.feSatellite:
                        x = self.tpdata.get('polarization', 0)
                        result += x in list(range(4)) and {0: 'H', 1: 'V', 2: 'L', 3: 'R'}[x] or '?'
                else:
                    if type == 'DVB-S':
                        x = self.tpdata.get('polarization', 0)
                        result += x in list(range(4)) and {0: 'H', 1: 'V', 2: 'L', 3: 'R'}[x] or '?'
            elif f == 'Y':  # %Y - symbol_rate
                # Skip symbol rate output for IPTV/streaming services
                if self.isStream or type == 'IP-TV':
                    continue
                if DreamOS():
                    if type in (iDVBFrontend.feCable, iDVBFrontend.feSatellite):
                        result += f"{int(self.tpdata.get('symbol_rate', 0) / 1000)}"
                else:
                    if type in ('DVB-C', 'DVB-S'):
                        result += f"{int(self.tpdata.get('symbol_rate', 0) / 1000)}"

            elif f == 'r':  # %r - rolloff (dvb-s2)
                if not self.isStream:
                    x = self.tpdata.get('rolloff')
                    if x is not None:
                        result += x in list(range(3)) and {0: '0.35', 1: '0.25', 2: '0.20'}[x] or ''
            elif f == 'o':  # %o - pilot (dvb-s2)
                if not self.isStream:
                    x = self.tpdata.get('pilot')
                    if x is not None:
                        result += x in list(range(3)) and {0: 'Off', 1: 'On', 2: 'Auto'}[x] or ''
            elif f == 'c':  # %c - constellation (dvb-t)
                if DreamOS():
                    if type == iDVBFrontend.feTerrestrial:
                        x = self.tpdata.get('constellation', 3)
                        result += x in list(range(4)) and {0: 'QPSK', 1: 'QAM16', 2: 'QAM64', 3: 'Auto'}[x] or ''
                else:
                    if type == 'DVB-T':
                        x = self.tpdata.get('constellation', 3)
                        result += x in list(range(4)) and {0: 'QPSK', 1: 'QAM16', 2: 'QAM64', 3: 'Auto'}[x] or ''
            elif f == 'l':  # %l - code_rate_lp (dvb-t)
                if DreamOS():
                    if type == iDVBFrontend.feTerrestrial:
                        x = self.tpdata.get('code_rate_lp', 5)
                        result += x in list(range(6)) and {0: '1/2', 1: '2/3', 2: '3/4', 3: '5/6', 4: '7/8', 5: 'Auto'}[x] or ''
                else:
                    if type == 'DVB-T':
                        x = self.tpdata.get('code_rate_lp', 5)
                        result += x in list(range(6)) and {0: '1/2', 1: '2/3', 2: '3/4', 3: '5/6', 4: '7/8', 5: 'Auto'}[x] or ''
            elif f == 'h':  # %h - code_rate_hp (dvb-t)
                if DreamOS():
                    if type == iDVBFrontend.feTerrestrial:
                        x = self.tpdata.get('code_rate_hp', 5)
                        result += x in list(range(6)) and {0: '1/2', 1: '2/3', 2: '3/4', 3: '5/6', 4: '7/8', 5: 'Auto'}[x] or ''
                else:
                    if type == 'DVB-T':
                        x = self.tpdata.get('code_rate_hp', 5)
                        result += x in list(range(6)) and {0: '1/2', 1: '2/3', 2: '3/4', 3: '5/6', 4: '7/8', 5: 'Auto'}[x] or ''
            elif f == 'm':  # %m - transmission_mode (dvb-t)
                if DreamOS():
                    if type == iDVBFrontend.feTerrestrial:
                        x = self.tpdata.get('transmission_mode', 2)
                        result += x in list(range(3)) and {0: '2k', 1: '8k', 2: 'Auto'}[x] or ''
                else:
                    if type == 'DVB-T':
                        x = self.tpdata.get('transmission_mode', 2)
                        result += x in list(range(3)) and {0: '2k', 1: '8k', 2: 'Auto'}[x] or ''
            elif f == 'g':  # %g - guard_interval (dvb-t)
                if DreamOS():
                    if type == iDVBFrontend.feTerrestrial:
                        x = self.tpdata.get('guard_interval', 4)
                        result += x in list(range(5)) and {0: '1/32', 1: '1/16', 2: '1/8', 3: '1/4', 4: 'Auto'}[x] or ''
                else:
                    if type == 'DVB-T':
                        x = self.tpdata.get('guard_interval', 4)
                        result += x in list(range(5)) and {0: '1/32', 1: '1/16', 2: '1/8', 3: '1/4', 4: 'Auto'}[x] or ''
            elif f == 'b':  # %b - bandwidth (dvb-t)
                if DreamOS():
                    if type == iDVBFrontend.feTerrestrial:
                        x = self.tpdata.get('bandwidth', 1)
                        result += x in list(range(4)) and {0: '8 MHz', 1: '7 MHz', 2: '6 MHz', 3: 'Auto'}[x] or ''
                else:
                    if type == 'DVB-T':
                        x = self.tpdata.get('bandwidth', 1)
                        result += x in list(range(4)) and {0: '8 MHz', 1: '7 MHz', 2: '6 MHz', 3: 'Auto'}[x] or ''
            elif f == 'e':  # %e - hierarchy_information (dvb-t)
                if DreamOS():
                    if type == iDVBFrontend.feTerrestrial:
                        x = self.tpdata.get('hierarchy_information', 4)
                        result += x in list(range(5)) and {0: 'None', 1: '1', 2: '2', 3: '4', 4: 'Auto'}[x] or ''
                else:
                    if type == 'DVB-T':
                        x = self.tpdata.get('hierarchy_information', 4)
                        result += x in list(range(5)) and {0: 'None', 1: '1', 2: '2', 3: '4', 4: 'Auto'}[x] or ''
            result += line[1:]
        return result

    def getSatelliteName(self, ref):
        if isinstance(ref, eServiceReference):
            orbpos = ref.getUnsignedData(4) >> 16
            if orbpos == 0xFFFF:  # Cable
                return _("Cable")
            elif orbpos == 0xEEEE:  # Terrestrial
                return _("Terrestrial")
            else:  # Satellite
                orbpos = ref.getData(4) >> 16
                if orbpos < 0:
                    orbpos += 3600
                try:
                    from Components.NimManager import nimmanager
                    return str(nimmanager.getSatDescription(orbpos))
                except Exception as e:
                    logger.debug(f"getSatelliteName - الموقع المداري غير مُدرَج في nimmanager، استخدام الحساب الاحتياطي: {e}")
                    dir = ref.flags & (eServiceReference.isDirectory | eServiceReference.isMarker)
                    if not dir:
                        refString = ref.toString().lower()
                        if refString.startswith("-1"):
                            return ''
                        elif refString.startswith("1:134:"):
                            return _("Alternative")
                        elif refString.startswith("4097:"):
                            return _("Internet")
                        else:
                            return orbpos > 1800 and f"{int((3600 - orbpos) / 10)}.{int((3600 - orbpos) % 10)}°W" or f"{int(orbpos / 10)}.{int(orbpos % 10)}°E"
        return ""

    def getIPTVProvider(self, refstr):
        if '3a10000' in refstr or ('::' in refstr and '2' == refstr.split(':')[-3]):
            return "Farline"
        elif '3a24000' in refstr or ('::' in refstr and '2' == refstr.split(':')[-3]):
            return "SHARA IPTV"
        return ""

    def getPlayingref(self, ref):
        playingref = None
        if NavigationInstance.instance:
            playingref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if not playingref:
            playingref = eServiceReference()
        return playingref

    def resolveAlternate(self, ref):
        nref = getBestPlayableServiceReference(ref, self.getPlayingref(ref))
        if not nref:
            nref = getBestPlayableServiceReference(ref, eServiceReference(), True)
        return nref

    def getReferenceType(self, refstr, ref):
        if ref is None:
            if NavigationInstance.instance:
                playref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                if playref:
                    refstr = playref.toString() or ''
                    prefix = ''
                    if refstr.startswith("4097:"):
                        prefix += "GStreamer "
                    if '%3a//' in refstr:
                        sref = ' '.join(refstr.split(':')[10:])
                        refstr = prefix + sref
                    else:
                        sref = ':'.join(refstr.split(':')[:10])
                        refstr = prefix + sref
        else:
            if refstr != '':
                prefix = ''
                if refstr.startswith("1:7:"):
                    if 'FROM BOUQUET' in refstr:
                        prefix += "Bouquet "
                    elif '(provider == ' in refstr:
                        prefix += "Provider "
                    elif '(satellitePosition == ' in refstr:
                        prefix += "Satellit "
                    elif '(channelID == ' in refstr:
                        prefix += "Current tr "
                elif refstr.startswith("1:134:"):
                    prefix += "Alter "
                elif refstr.startswith("1:64:"):
                    prefix += "Marker "
                elif refstr.startswith("4097:"):
                    prefix += "GStreamer "
                if self.isStream:
                    if self.refstr:
                        if '%3a//' in self.refstr:
                            sref = ' '.join(self.refstr.split(':')[10:])
                        else:
                            sref = ':'.join(self.refstr.split(':')[:10])
                    else:
                        sref = ' '.join(refstr.split(':')[10:])
                    return prefix + sref
                else:
                    if self.refstr:
                        sref = ':'.join(self.refstr.split(':')[:10])
                    else:
                        sref = ':'.join(refstr.split(':')[:10])
                    return prefix + sref
        return refstr

    @cached
    def getText(self):
        service = self.source.service
        if isinstance(service, iPlayableServicePtr):
            info = service and service.info()
            ref = None
        else:  # reference
            info = service and self.source.info
            ref = service
        if not info:
            return ""
        refname = 'ServiceName2.ref'
        searchpath = ['/etc/enigma2/']
        if ref:
            refstr = ref.toString()
        else:
            refstr = info.getInfoString(iServiceInformation.sServiceref)
        if refstr is None:
            refstr = ''
        if self.type == self.NAME:
            name = ref and (info.getName(ref) or 'N/A') or (info.getName() or 'N/A')
            prefix = ''
            if self.ref:
                prefix = " (alter)"
            name += prefix
            return name.replace('\xc2\x86', '').replace('\xc2\x87', '')
        elif self.type == self.NUMBER:
            try:
                service = self.source.serviceref
                num = service and service.getChannelNum() or None
            except Exception as e:
                logger.error(f"getText (line 645): {e}")
                num = None
            if num:
                return str(num)
            else:
                num, bouq = self.getServiceNumber(ref or eServiceReference(info.getInfoString(iServiceInformation.sServiceref)))
                return num and str(num) or ''
        elif self.type == self.BOUQUET:
            num, bouq = self.getServiceNumber(ref or eServiceReference(info.getInfoString(iServiceInformation.sServiceref)))
            return bouq
        elif self.type == self.PROVIDER:
            tmpprov = tmpref = refpath = ''
            if self.isStream:
                if self.refstr:
                    tmpprov = self.getIPTVProvider(self.refstr)
                tmpprov = self.getIPTVProvider(refstr)
            else:
                if self.ref:
                    tmpprov = self.getProviderName(self.ref)
                if ref:
                    tmpprov = self.getProviderName(ref)
                else:
                    tmpprov = info.getInfoString(iServiceInformation.sProvider) or ''
            if tmpprov == '' or 'Unknown' in tmpprov:
                if self.refstr:
                    tmpref = self.refstr
                else:
                    tmpref = refstr
                for i in list(range(len(searchpath))):
                    if os_path.isfile(f'{searchpath[i]}{refname}'):
                        refpath = f'{searchpath[i]}{refname}'
                if refpath != '':
                    # FIX: was open()+re-scanning the file from disk on every
                    # zap; now the file is read once and cached until it
                    # changes on disk (mtime check inside the helper).
                    for line in _read_ref_file_cached(refpath):
                        if tmpref in line or tmpref.strip()[:-15] in line:
                            tmpprov = line.split(':')[-1].strip('\r').strip('\n').strip()

                return tmpprov
            return tmpprov
        elif self.type == self.REFERENCE:
            if self.refstr:
                return self.refstr
            return refstr
        elif self.type == self.ORBPOS:
            if self.isStream:
                return r"00\B0E"
            else:
                if self.ref and self.info:
                    return self.getTransponderInfo(self.info, self.ref, 'O')
                return self.getTransponderInfo(info, ref, 'O')
        elif self.type == self.TPRDATA:
            if self.isStream:
                return _("Streaming")
            else:
                if self.ref and self.info:
                    return self.getTransponderInfo(self.info, self.ref, 'T')
                return self.getTransponderInfo(info, ref, 'T')
        elif self.type == self.SATELLITE:
            if self.isStream:
                return _("Internet")
            else:
                if self.ref:
                    return self.getSatelliteName(self.ref)
            # test
                return self.getSatelliteName(ref or eServiceReference(info.getInfoString(iServiceInformation.sServiceref)))

#               elif self.type == self.ALLREF:
#                       tmpref = self.getReferenceType(refstr, ref)
#                       if 'Bouquet' in tmpref or 'Satellit' in tmpref or 'Provider' in tmpref:
#                               return ' '
#                       elif '%3a' in tmpref:
#                               return ':'.join(refstr.split(':')[:10])
#                       return tmpref
        elif self.type == self.ALLREFERENCE:
            orbp = f"{self.getTransponderInfo(info, ref, '%O')}"
            refer = f"{ref and ref.toString() or info.getInfoString(iServiceInformation.sServiceref)}"
            if isinstance(service, iPlayableServicePtr):
                prov = f"{info.getInfoString(iServiceInformation.sProvider)}"
            else:
                prov = f"{ref and self.getProviderName(ref)}"
            all = f"{refer},,,{prov},,,{orbp}"
            return all
        elif self.type in (self.STREAMURL, self.STREAMTYPE, self.STREAMHOST):
            # Additive: explicit IPTV field extraction, ported from
            # AglareServName2. Reuses the same reference-parsing convention
            # already used elsewhere in this file (colon-split at index 10,
            # "%3a" percent-encoding of "://") instead of introducing a new
            # parsing scheme.
            src_refstr = self.refstr if self.refstr else refstr
            is_stream_ref = bool(src_refstr) and (
                src_refstr.startswith("4097:") or "%3a" in src_refstr or "://" in src_refstr
            )
            if not is_stream_ref:
                return ""
            try:
                if "%3a//" in src_refstr:
                    url_part = " ".join(src_refstr.split(":")[10:]).replace("%3a", ":")
                else:
                    url_part = ":".join(src_refstr.split(":")[10:])
                url_part = url_part.strip()
                if self.type == self.STREAMURL:
                    return url_part
                # split "scheme://host[:port]/path" style strings
                scheme = ""
                rest = url_part
                if "://" in url_part:
                    scheme, rest = url_part.split("://", 1)
                if self.type == self.STREAMTYPE:
                    return scheme.upper() if scheme else ""
                # STREAMHOST
                host = rest.split("/")[0]
                return host
            except Exception as e:
                logger.error(f"getText StreamURL/Type/Host: {e}")
                return ""
        elif self.type == self.FORMAT:
            num = bouq = ''
            tmp = self.sfmt[:].split("%")
            if tmp:
                ret = tmp[0]
                tmp.remove(ret)
            else:
                return ""
            for line in tmp:
                f = line[:1]
                if f == 'N':    # %N - Name
                    name = ref and (info.getName(ref) or 'N/A') or (info.getName() or 'N/A')
                    postfix = ''
                    if self.ref:
                        postfix = " (alter)"
                    name += postfix
                    ret += name.replace('\xc2\x86', '').replace('\xc2\x87', '')
                elif f == 'n':  # %n - Number
                    try:
                        service = self.source.serviceref
                        num = service and service.getChannelNum() or None
                    except Exception as e:
                        logger.error(f"getText (line 749): {e}")
                        num = None
                    if num:
                        ret += str(num)
                    else:
                        num, bouq = self.getServiceNumber(ref or eServiceReference(info.getInfoString(iServiceInformation.sServiceref)))
                        ret += num and str(num) or ''
                elif f == 'B':  # %B - Bouquet
                    num, bouq = self.getServiceNumber(ref or eServiceReference(info.getInfoString(iServiceInformation.sServiceref)))
                    ret += bouq
                elif f == 'P':  # %P - Provider
                    tmpprov = tmpref = refpath = ''
                    if self.isStream:
                        if self.refstr:
                            tmpprov = self.getIPTVProvider(self.refstr)
                        tmpprov = self.getIPTVProvider(refstr)
                    else:
                        if self.ref:
                            tmpprov = self.getProviderName(self.ref)
                        if ref:
                            tmpprov = self.getProviderName(ref)
                        else:
                            tmpprov = info.getInfoString(iServiceInformation.sProvider) or ''
                    if tmpprov == '' or 'Unknown' in tmpprov:
                        if self.refstr:
                            tmpref = self.refstr
                        else:
                            tmpref = refstr
                        for i in list(range(len(searchpath))):
                            if os_path.isfile(f'{searchpath[i]}{refname}'):
                                refpath = f'{searchpath[i]}{refname}'
                            if refpath != '':
                                # FIX: cached file read instead of open()+scan on every zap
                                for line in _read_ref_file_cached(refpath):
                                    if tmpref in line or tmpref.strip()[:-15] in line:
                                        tmpprov = line.split(':')[-1].strip('\r').strip('\n').strip()
                    ret += tmpprov
                elif f == 'R':  # %R - Reference
                    if self.refstr:
                        ret += self.refstr
                    else:
                        ret += refstr
                elif f == 'S':  # %S - Satellite
                    if self.isStream:
                        ret += _("Internet")
                    else:
                        if self.ref:
                            ret += self.getSatelliteName(self.ref)
                        else:
                            ret += self.getSatelliteName(ref or eServiceReference(info.getInfoString(iServiceInformation.sServiceref)))
                elif f == 'A':  # %A - AllRef
                    tmpref = self.getReferenceType(refstr, ref)
                    if 'Bouquet' in tmpref or 'Satellit' in tmpref or 'Provider' in tmpref:
                        ret += ' '
                    elif '%3a' in tmpref:
                        ret += ':'.join(refstr.split(':')[:10])
                    else:
                        ret += tmpref
                elif f == 'U':  # %U - Stream URL (additive, ported from AglareServName2)
                    src_refstr = self.refstr if self.refstr else refstr
                    if src_refstr and ("%3a" in src_refstr or src_refstr.startswith("4097:") or "://" in src_refstr):
                        try:
                            if "%3a//" in src_refstr:
                                ret += " ".join(src_refstr.split(":")[10:]).replace("%3a", ":").strip()
                            else:
                                ret += ":".join(src_refstr.split(":")[10:]).strip()
                        except Exception as e:
                            logger.error(f"getText FORMAT %U: {e}")
                elif f in 'TtsFfiOMpYroclhmgbe':
                    if self.ref:
                        ret += self.getTransponderInfo(self.info, self.ref, f)
                    else:
                        ret += self.getTransponderInfo(info, ref, f)
                ret += line[1:]
            return f"{ret.replace('N/A', '').strip()}"

    text = property(getText)

    def neededChange(self):
        if self.what:
            Converter.changed(self, self.what)
            self.what = None

    def changed(self, what):
        if what[0] != self.CHANGED_SPECIFIC or what[1] in (iPlayableService.evStart,):
            self.refstr = self.isStream = self.ref = self.info = self.tpdata = None
            if self.type in (self.NUMBER, self.BOUQUET) or \
               (self.type == self.FORMAT and ('%n' in self.sfmt or '%B' in self.sfmt)):
                self.what = what
                self.timer.start(200, True)
            else:
                Converter.changed(self, what)
