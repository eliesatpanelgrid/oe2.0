# LiiS8ServiceInfo
# -*- coding: utf-8 -*-
# by Li-iS8...06.2026
# Bitrate support based on MetrixHDBitrate by areq/Fhroma
try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")
from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import iServiceInformation, iPlayableService, eServiceReference, iPlayableServicePtr, eConsoleAppContainer, eTimer
from Components.Converter.Poll import Poll
from Components.config import config
from os import path as _os_path, access as _os_access, X_OK as _X_OK
import time as _time

# مخزن مشترك للـ Bitrate
_bs = {"vcur": 0, "acur": 0, "running": False, "remaining": "", "lines": []}
_container = None
_runTimer = None

# --- Additive, ported from AglareBitrate: avoid the known Vu+ (Broadcom)
# DVB-driver deadlock by not re-spawning the bitrate helper too aggressively
# on affected models. Does not disable the feature, only throttles it. ---
_is_vu_model = None
_last_bitrate_run = 0.0


def _isVuModel():
	global _is_vu_model
	if _is_vu_model is None:
		_is_vu_model = _os_path.exists('/proc/stb/info/vumodel')
	return _is_vu_model


def _runBitrate(service):
	global _container, _runTimer, _last_bitrate_run
	# additive guard: on Vu+ models, don't relaunch more than once every 2s
	if _isVuModel():
		now = _time.time()
		if now - _last_bitrate_run < 2.0:
			return
		_last_bitrate_run = now
	# additive guard: don't spawn a console app we already know will fail
	if not _os_access('/usr/bin/bitrate', _X_OK):
		logger.error("_runBitrate: /usr/bin/bitrate missing or not executable")
		return
	try:
		adapter = 0
		demux = 0
		try:
			stream = service.stream()
			if stream:
				streamdata = stream.getStreamingData()
				if streamdata:
					if 'demux' in streamdata:
						demux = streamdata['demux']
						if demux < 0: demux = 0
					if 'adapter' in streamdata:
						adapter = streamdata['adapter']
						if adapter < 0: adapter = 0
		except Exception as e:
			logger.error(f"_runBitrate (line 33): {e}")
			pass
		info = service.info()
		vpid = info.getInfo(iServiceInformation.sVideoPID)
		apid = info.getInfo(iServiceInformation.sAudioPID)
		if vpid >= 0 and apid >= 0:
			# نفس الأمر تماماً كما في MetrixHDBitrate — vpid مرتين
			cmd = f'killall -9 bitrate > /dev/null 2>&1; nice bitrate {int(adapter)} {int(demux)} {int(vpid)} {int(vpid)}'
			_container = eConsoleAppContainer()
			_container.appClosed.append(_onClosed)
			_container.dataAvail.append(_onData)
			_bs["running"] = True
			_bs["remaining"] = ""
			_bs["lines"] = []
			_container.execute(cmd)
	except Exception as e:
		logger.error(f"_runBitrate (line 48): {e}")
		pass


def _onData(data):
	try:
		conStr = _bs["remaining"] + str(data, 'utf-8', 'ignore')
		newlines = conStr.split('\n')
		if len(newlines[-1]):
			_bs["remaining"] = newlines[-1]
			newlines = newlines[0:-1]
		else:
			_bs["remaining"] = ""
		for line in newlines:
			if len(line):
				_bs["lines"].append(line)
		if len(_bs["lines"]) >= 2:
			try:
				vals = [int(x) for x in _bs["lines"][0].split(' ')]
				_bs["vcur"] = vals[3]
			except Exception as e:
				logger.error(f"_onData (line 68): {e}")
				pass
			try:
				vals = [int(x) for x in _bs["lines"][1].split(' ')]
				_bs["acur"] = vals[3]
			except Exception as e:
				logger.error(f"_onData (line 73): {e}")
				pass
			_bs["lines"] = []
	except Exception as e:
		logger.error(f"_onData (line 76): {e}")
		pass


def _onClosed(retval):
	global _runTimer
	_bs["running"] = False
	# إعادة التشغيل تلقائياً بعد 10ms كما في MetrixHDBitrate
	try:
		_runTimer = eTimer()
		_runTimer.callback.append(lambda: _restartBitrate())
		_runTimer.start(10, True)
	except Exception as e:
		logger.error(f"_onClosed (line 88): {e}")
		pass

_last_service = None


def _getProcResolution():
	"""
	قراءة الدقة الحقيقية للفيديو مباشرة من الديكودر (proc)
	بدل الاعتماد فقط على iServiceInformation.sVideoWidth/sVideoHeight
	التي قد تُرجع قيمة قديمة أو خاطئة (مثلاً 1280x720) على قنوات
	4K UHD (خصوصاً DVB-S2/H.265) رغم أن الرسيفر يدعم 4K فعلياً.
	"""
	try:
		with open("/proc/stb/vmpeg/0/xres", "r") as f:
			w = int(f.read().strip(), 16)
		with open("/proc/stb/vmpeg/0/yres", "r") as f:
			h = int(f.read().strip(), 16)
		if w > 0 and h > 0:
			return w, h
	except Exception as e:
		logger.error(f"_getProcResolution (line 108): {e}")
		pass
	return 0, 0


def _restartBitrate():
	global _last_service
	if _last_service:
		_runBitrate(_last_service)


class LiiS8ServiceInfo(Poll, Converter):
	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)
		self.type = type
		self.poll_interval = 1000
		self.poll_enabled = True

	@cached
	def getText(self):
		global _last_service
		xres = ""
		yres = ""
		fps = ""
		service = self.source.service
		info = service and service.info()
		if not info:
			return ""
		xres = info.getInfo(iServiceInformation.sVideoWidth)
		yres = info.getInfo(iServiceInformation.sVideoHeight)
		fps = info.getInfo(iServiceInformation.sFrameRate)
		# تصحيح الدقة الحقيقية (خصوصاً لقنوات 4K UHD التي قد يُرجع
		# لها getInfo دقة قديمة/خاطئة مثل 1280x720)
		pw, ph = _getProcResolution()
		if pw > 0 and ph > 0:
			xres, yres = pw, ph

		if self.type == "Name":
			return info.getName()
		elif self.type == "Number":
			try:
				if config.usage.show_infobar_channel_number.value:
					ref = self.source.serviceref
					num = ref.getChannelNum() or None
					return str(num)
				else:
					return ""
			except Exception as e:
				logger.error(f"getText (line 156): {e}")
				return ""
		elif self.type == "Orbital":
			ti = info.getInfoObject(iServiceInformation.sTransponderData)
			pos = ti.get("orbital_position", 0)
			return pos > 1800 and f"{int((3600 - pos) / 10)}.{int((3600 - pos) % 10)}°W" or f"{int(pos / 10)}.{int(pos % 10)}°E"
		elif self.type == "Provider":
			return info.getInfoString(iServiceInformation.sProvider)
		elif self.type == "ServiceCompact":
			gamma = ('SDR', 'HDR', 'HDR10', 'HLG', '')[info.getInfo(iServiceInformation.sGamma)]
			inf = []
			audio = service.audioTracks()
			if audio:
				n = audio.getNumberOfTracks()
				idx = 0
				while idx < n:
					i = audio.getTrackInfo(idx)
					description = i.getDescription()
					if description in ('AC3', 'AC3+', 'DTS', 'DTS-HD', 'AC-3'):
						inf.append("DOLBY")
						break
					idx += 1
			if gamma != "":
				inf.append(gamma)
			if yres < 720:
				inf.append("SD")
			elif yres >= 720 and yres < 1080:
				inf.append("HD")
			elif yres >= 1080 and yres < 2160:
				inf.append("FHD")
			elif yres >= 2160:
				inf.append("4K")
			if info.getInfo(iServiceInformation.sIsCrypted) == 1:
				inf.append("$")
			else:
				inf.append("FTA")
			if info.getInfoString(iServiceInformation.sHBBTVUrl) != "":
				hbb = '\\c00??2200H\\c0000??00b\\c00????00b\\c0000????TV'
				inf.append(hbb)
			subservices = service.subServices()
			if subservices and subservices.getNumberOfSubservices() > 0:
				inf.append("SUB")
			subtitle = service and service.subtitle()
			subtitlelist = subtitle and subtitle.getSubtitleList()
			if subtitlelist:
				if len(subtitlelist) > 0:
					inf.append("SUBT")
			audio = service.audioTracks()
			if bool(audio and audio.getNumberOfTracks() > 1):
				inf.append("A")
			if service.streamed() is not None:
				inf.append("Stream")
			tpid = info.getInfo(iServiceInformation.sTXTPID)
			if tpid != -1:
				inf.append("TxT")
			sep_color = '\\c0000???? | '
			sep_color += '\\c00??????'
			return sep_color.join(inf)

		elif self.type == "Resolution":
			try:
				# جلب كودك الفيديو
				vtypes = ("MPEG2", "H.264", "MPEG1", "MPEG4-II", "VC1", "VC1-SM", "H.265", "")
				vtype_idx = info.getInfo(iServiceInformation.sVideoType)
				vtype = vtypes[vtype_idx] if 0 <= vtype_idx < len(vtypes) else ""

				# جلب التراك الصوتي
				atype = ""
				audio = service.audioTracks()
				if audio:
					cur = audio.getCurrentTrack()
					if cur >= 0:
						atype = str(audio.getTrackInfo(cur).getDescription()).replace(",", "").strip()

				# تشغيل bitrate إذا لم يكن يعمل
				_last_service = service
				if not _bs["running"]:
					_runBitrate(service)

				v_kb = _bs["vcur"]
				a_kb = _bs["acur"]

				# بناء النص
				res = "{}x{}i({})Fps".format(xres, yres, (fps // 1000))
				if vtype:
					if v_kb > 0:
						res += " VIDEO {}: {:.2f} Mb/s".format(vtype, v_kb / 1000.0)
					else:
						res += " VIDEO {}".format(vtype)
				if atype:
					if a_kb > 0:
						res += " AUDIO {}: {} kbit/s".format(atype, a_kb)
					else:
						res += " AUDIO {}".format(atype)
				return res
			except Exception as e:
				logger.error(f"getText (line 251): {e}")
				return "{}x{}i({})Fps".format(xres, yres, (fps // 1000))

		elif self.type == "AVtype":
			try:
				atype = ""
				vtype = ""
				audio = service.audioTracks()
				if audio:
					if audio.getCurrentTrack() > -1:
						atype = str(audio.getTrackInfo(audio.getCurrentTrack()).getDescription()).replace(",", "")
				vtype = ("MPEG2", "H.264", "MPEG1", "MPEG4-II", "VC1", "VC1-SM", "H.265", "")[info.getInfo(iServiceInformation.sVideoType)]
				return "\\c0000??80Audio : \\c00??????{}  \\c0000??80Video : \\c00??????{}".format(atype, vtype)
			except Exception as e:
				logger.error(f"getText (line 264): {e}")
				return ""
		elif self.type == "TunerType":
			tt = self.source.frontend_type
			return tt or _("Unknown")

		# --- Additive: raw DVB fields ported from AglaresvcInfo2, so LiiS8ServiceInfo
		# can also expose low-level/technical data on top of its existing
		# consumer-facing badges (HDR/Dolby/4K/...). None of the branches
		# above were touched or removed. ---
		elif self.type == "XRES":
			# raw video width, unlike "ServiceCompact"/"Resolution" which only
			# use xres internally to decide SD/HD/FHD/4K
			return str(xres)
		elif self.type == "YRES":
			return str(yres)
		elif self.type == "FRAMERATE":
			try:
				return str(fps // 1000)
			except Exception as e:
				logger.error(f"getText FRAMERATE: {e}")
				return ""
		elif self.type == "TRANSFERBPS":
			# raw combined bitrate in kbit/s, reusing the same background
			# bitrate sampler already used by "Resolution" above (no new
			# external process is spawned).
			try:
				_last_service = service
				if not _bs["running"]:
					_runBitrate(service)
				return str(_bs["vcur"] + _bs["acur"])
			except Exception as e:
				logger.error(f"getText TRANSFERBPS: {e}")
				return "0"
		elif self.type == "VIDEO_CODEC":
			# مُصحَّح: نعتمد أولاً على sTagVideoCodec (كما في AglaresvcInfo2) لأنه
			# نص ديناميكي قادم من طبقة الديمكس نفسها ويدعم أي كودك (AV1، VP9...)
			# بدون الحاجة لتحديث جدول يدوي. الجدول الثابت القديم يبقى fallback
			# فقط للفيرموير الأقدم الذي لا يوفّر sTagVideoCodec.
			try:
				tag = info.getInfoString(iServiceInformation.sTagVideoCodec)
				if tag:
					return tag
			except Exception as e:
				logger.error(f"getText VIDEO_CODEC (sTagVideoCodec): {e}")
			try:
				vtypes = ("MPEG2", "H.264", "MPEG1", "MPEG4-II", "VC1", "VC1-SM", "H.265", "")
				vtype_idx = info.getInfo(iServiceInformation.sVideoType)
				return vtypes[vtype_idx] if 0 <= vtype_idx < len(vtypes) else ""
			except Exception as e:
				logger.error(f"getText VIDEO_CODEC (fallback): {e}")
				return ""
		elif self.type == "AUDIO_CODEC":
			# مُصحَّح بنفس المنطق: sTagAudioCodec أولاً، ثم getTrackInfo كـ fallback
			try:
				tag = info.getInfoString(iServiceInformation.sTagAudioCodec)
				if tag:
					return tag
			except Exception as e:
				logger.error(f"getText AUDIO_CODEC (sTagAudioCodec): {e}")
			try:
				audio = service.audioTracks()
				if audio and audio.getCurrentTrack() > -1:
					return str(audio.getTrackInfo(audio.getCurrentTrack()).getDescription()).replace(",", "").strip()
				return ""
			except Exception as e:
				logger.error(f"getText AUDIO_CODEC (fallback): {e}")
				return ""
		elif self.type == "VPID":
			return str(info.getInfo(iServiceInformation.sVideoPID))
		elif self.type == "APID":
			return str(info.getInfo(iServiceInformation.sAudioPID))
		elif self.type == "PCRPID":
			return str(info.getInfo(iServiceInformation.sPCRPID))
		elif self.type == "PMTPID":
			return str(info.getInfo(iServiceInformation.sPMTPID))
		elif self.type == "TXTPID":
			return str(info.getInfo(iServiceInformation.sTXTPID))
		elif self.type == "TSID":
			return str(info.getInfo(iServiceInformation.sTSID))
		elif self.type == "ONID":
			return str(info.getInfo(iServiceInformation.sONID))
		elif self.type == "SID":
			return str(info.getInfo(iServiceInformation.sSID))

		# --- إضافة: سطر واحد مُجمَّع يطابق شكل "RaedQuickSignal" المطلوب ---
		# SID: 3324  VPID: 0169  APID: 0181  PRCPID: 0169  TSID: 0190  ONID: 013E
		elif self.type == "PIDS":
			try:
				sid = info.getInfo(iServiceInformation.sSID)
				vpid = info.getInfo(iServiceInformation.sVideoPID)
				apid = info.getInfo(iServiceInformation.sAudioPID)
				pcrpid = info.getInfo(iServiceInformation.sPCRPID)
				tsid = info.getInfo(iServiceInformation.sTSID)
				onid = info.getInfo(iServiceInformation.sONID)
				return "SID: %04X  VPID: %04X  APID: %04X  PRCPID: %04X  TSID: %04X  ONID: %04X" % (
					sid if sid > -1 else 0,
					vpid if vpid > -1 else 0,
					apid if apid > -1 else 0,
					pcrpid if pcrpid > -1 else 0,
					tsid if tsid > -1 else 0,
					onid if onid > -1 else 0,
				)
			except Exception as e:
				logger.error(f"getText PIDS: {e}")
				return ""

	text = property(getText)

	@cached
	def getBoolean(self):
		service = self.source.service
		info = service and service.info()
		if not info:
			return False
		xres = info.getInfo(iServiceInformation.sVideoWidth)
		yres = info.getInfo(iServiceInformation.sVideoHeight)
		# تصحيح الدقة الحقيقية (خصوصاً لقنوات 4K UHD)
		pw, ph = _getProcResolution()
		if pw > 0 and ph > 0:
			xres, yres = pw, ph

		if self.type == "isStream":
			return service.streamed() is not None
		elif self.type == "isCryptedON":
			return info.getInfo(iServiceInformation.sIsCrypted) == 1
		elif self.type == "isCryptedOFF":
			return bool(xres) and info.getInfo(iServiceInformation.sIsCrypted) == 1
		elif self.type == "isFta":
			return info.getInfo(iServiceInformation.sIsCrypted) == 0
		elif self.type == "isSD":
			return 0 < yres < 720
		elif self.type == "isHD":
			return 720 <= yres < 1080
		elif self.type == "isFHD":
			return 1080 <= yres < 2160
		elif self.type == "is4K":
			return yres >= 2160
		elif self.type == "isHDR":
			try:
				gamma = info.getInfo(iServiceInformation.sGamma)
				return gamma in (1, 2, 3)  # HDR, HDR10, HLG
			except Exception as e:
				logger.error(f"getBoolean (line 305): {e}")
				return False
		elif self.type == "isDolby":
			audio = service.audioTracks()
			if audio:
				n = audio.getNumberOfTracks()
				for idx in range(n):
					desc = audio.getTrackInfo(idx).getDescription()
					if desc in ("AC3", "AC3+", "DTS", "DTS-HD", "AC-3"):
						return True
			return False
		elif self.type == "isHBBTV":
			return info.getInfoString(iServiceInformation.sHBBTVUrl) != ""
		elif self.type == "isSub":
			subtitle = service.subtitle()
			subtitlelist = subtitle and subtitle.getSubtitleList()
			if subtitlelist and len(subtitlelist) > 0:
				return True
			subservices = service.subServices()
			return bool(subservices and subservices.getNumberOfSubservices() > 0)
		elif self.type == "isTXT":
			return info.getInfo(iServiceInformation.sTXTPID) != -1
		elif self.type == "isMultiAudio":
			audio = service.audioTracks()
			return bool(audio and audio.getNumberOfTracks() > 1)
		elif self.type == "16-9":
			aspect = info.getInfo(iServiceInformation.sAspect)
			return aspect not in (1, 2, 5, 6, 9, 10, 13, 14)
		elif self.type == "4-3":
			aspect = info.getInfo(iServiceInformation.sAspect)
			return aspect in (1, 2, 5, 6, 9, 10, 13, 14)
		elif self.type == "isSDR":
			try:
				gamma = info.getInfo(iServiceInformation.sGamma)
				return gamma == 0
			except Exception as e:
				logger.error(f"getBoolean (line 340): {e}")
				return False
		elif self.type == "isResOff":
			# لا توجد دقة فيديو معروفة بعد (مثلاً وقت التبديل بين القنوات)
			return yres <= 0
		elif self.type == "isGammaOff":
			# تُظهر الأيقونة الباهتة لو القناة لا تدعم SDR ولا HDR بشكل واضح
			# أو لو تعذّرت قراءة قيمة gamma أصلاً (بعض القنوات/الأنواع لا تدعم هذا الحقل)
			try:
				gamma = info.getInfo(iServiceInformation.sGamma)
				return gamma not in (0, 1, 2, 3)
			except Exception as e:
				logger.error(f"getBoolean (line 351): {e}")
				return True

		# --- Additive: boolean checks ported from AglaresvcInfo2, giving
		# finer-grained resolution/format booleans alongside the existing
		# isSD/isHD/isFHD/is4K checks (all of which remain unchanged above). ---
		elif self.type == "IS_1080":
			return yres == 1080 or yres == 1088
		elif self.type == "IS_720":
			return yres == 720
		elif self.type == "IS_576":
			return yres == 576
		elif self.type == "IS_480":
			return yres == 480
		elif self.type == "HAS_TELETEXT":
			return info.getInfo(iServiceInformation.sTXTPID) != -1
		elif self.type == "IS_WIDESCREEN":
			aspect = info.getInfo(iServiceInformation.sAspect)
			return aspect not in (1, 2, 5, 6, 9, 10, 13, 14)
		elif self.type == "IS_NOT_WIDESCREEN":
			aspect = info.getInfo(iServiceInformation.sAspect)
			return aspect in (1, 2, 5, 6, 9, 10, 13, 14)
		elif self.type == "SUBSERVICES_AVAILABLE":
			subservices = service.subServices()
			return bool(subservices and subservices.getNumberOfSubservices() > 0)
		elif self.type == "AUDIOTRACKS_AVAILABLE":
			audio = service.audioTracks()
			return bool(audio and audio.getNumberOfTracks() > 0)
		elif self.type == "SUBTITLES_AVAILABLE":
			subtitle = service.subtitle()
			subtitlelist = subtitle and subtitle.getSubtitleList()
			return bool(subtitlelist and len(subtitlelist) > 0)
		elif self.type == "HAS_HBBTV":
			return info.getInfoString(iServiceInformation.sHBBTVUrl) != ""
		elif self.type == "EDITMODE":
			return bool(hasattr(self.source, "editmode") and self.source.editmode)
		return False

	boolean = property(getBoolean)

	def changed(self, what):
		Converter.changed(self, what)
