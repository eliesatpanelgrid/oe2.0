# LiiS8DebugTrace
#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
LiiS8DebugTrace.py
"""

from __future__ import absolute_import

import os
import threading
import time

TRACE_ENABLED = False

TRACE_FILE = "/tmp/xdreamy_trace.log"
TRACE_MAX_BYTES = 4 * 1024 * 1024

_trace_lock = threading.Lock()
_trace_start = time.time()
_seq = [0]


def _rotate_if_needed():
    try:
        if os.path.exists(TRACE_FILE) and os.path.getsize(TRACE_FILE) > TRACE_MAX_BYTES:
            try:
                os.replace(TRACE_FILE, TRACE_FILE + ".1")
            except Exception:
                os.remove(TRACE_FILE)
    except Exception:
        pass


def trace(component, event, detail=""):
    if not TRACE_ENABLED:
        return
    try:
        with _trace_lock:
            _seq[0] += 1
            seq = _seq[0]
            now = time.time()
            elapsed_ms = int((now - _trace_start) * 1000)
            line = (
                f'{seq:06d} | {time.strftime("%H:%M:%S", time.localtime(now))} | '
                f't+{elapsed_ms:8d}ms | {component:<22} | {event:<22} | {detail} | '
                f'thread={threading.current_thread().name}\n'
            )
            _rotate_if_needed()
            with open(TRACE_FILE, "a") as f:
                f.write(line)
    except Exception:
        pass


class timed_block(object):
    __slots__ = ("component", "event", "detail", "_t0")

    def __init__(self, component, event, detail=""):
        self.component = component
        self.event = event
        self.detail = detail
        self._t0 = None

    def __enter__(self):
        if TRACE_ENABLED:
            self._t0 = time.time()
            trace(self.component, self.event + "-start", self.detail)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if TRACE_ENABLED and self._t0 is not None:
            took_ms = int((time.time() - self._t0) * 1000)
            extra = f"took={int(took_ms)}ms"
            detail = (self.detail + " " + extra) if self.detail else extra
            if exc_type is not None:
                detail += f" EXCEPTION={exc_type.__name__}"
            trace(self.component, self.event + "-end", detail)
        return False