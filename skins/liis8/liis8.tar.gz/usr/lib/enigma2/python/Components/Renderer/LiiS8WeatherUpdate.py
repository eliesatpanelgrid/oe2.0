# -*- coding: utf-8 -*-
# LiiS8WeatherUpdate - يوفر checkUpdateWeather / dataRead / runOM / runISS / errorlog / py3
# مطلوب من: LiiS8WeatherOM, LiiS8WeatherOMc, LiiS8WeatherPixmap, LiiS8WeatherLabel,
#            LiiS8ISS, LiiS8CircleProgress, LiiS8Crypted, LiiS8Events, LiiS8CryptoPixmap,
#            LiiS8PrimeTime, LiiS8LiveTextProgress, LiiS8PrgrsVol, LiiS8DiskInfos
from __future__ import absolute_import
import os
import time
import json
from sys import version_info

try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")

try:
	from Tools.LiiS8Requests import fetch_json
	HAS_NET = True
except Exception:
	HAS_NET = False

py3 = version_info[0] >= 3

CITY_CACHE_JSON = "/tmp/LiiS8_city_cache.json"


def _reverse_geocode(lat, lon):
	"""
	يحوّل الإحداثيات إلى اسم مدينة عبر BigDataCloud (مجانية، لا تحتاج مفتاح API).
	يخزّن النتيجة في ملف مؤقت لتفادي طلب شبكة إضافي كل ساعة لموقع ثابت غالبًا.
	"""
	try:
		if os.path.exists(CITY_CACHE_JSON):
			with open(CITY_CACHE_JSON, "r") as f:
				cache = json.load(f)
			cached_city = cache.get("city")
			# نفس الإحداثيات تقريبًا (فرق أقل من 0.05 درجة ~ 5 كم) -> استخدم المخزَّن
			# فقط إذا كانت القيمة المخزَّنة ناجحة فعليًا (وليست N/A/فارغة من محاولة فاشلة سابقة)
			if cached_city and cached_city != "N/A" \
					and abs(cache.get("lat", 999) - lat) < 0.05 \
					and abs(cache.get("lon", 999) - lon) < 0.05:
				return cached_city
	except Exception:
		pass

	if not HAS_NET:
		return "N/A"

	url = "https://api.bigdatacloud.net/data/reverse-geocode-client"
	data = fetch_json(url, params={"latitude": lat, "longitude": lon, "localityLanguage": "ar"})
	city = "N/A"
	if data:
		city = data.get("city") or data.get("locality") or data.get("principalSubdivision") or "N/A"

	# لا نكتب نتيجة فاشلة (N/A) في الكاش، حتى تُعاد المحاولة في المرة القادمة
	# بدل أن تُحبَس المدينة على "N/A" إلى الأبد بسبب فشل شبكة مؤقت
	if city != "N/A":
		try:
			with open(CITY_CACHE_JSON, "w") as f:
				json.dump({"lat": lat, "lon": lon, "city": city}, f)
		except Exception as e:
			errorlog(e, "_reverse_geocode cache write")
	else:
		errorlog("فشل جلب اسم المدينة (reverse geocode) - سيُعاد المحاولة عند التحديث القادم", "_reverse_geocode")

	return city

WEATHER_JSON = "/tmp/LiiS8_Weather_OM.json"
ISS_JSON = "/tmp/LiiS8_ISS.json"

# إحداثيات افتراضية (تُستخدم فقط إن لم يوجد config.usage.location)، مثال: القاهرة
DEFAULT_LAT = 30.0444
DEFAULT_LON = 31.2357

# خرائط ترميز الطقس WMO (المستخدمة في Open-Meteo) إلى ترقيم الأيقونات المستخدم في LiiS8WeatherOM.py
# (نفس منظومة ترقيم Yahoo Weather 0-47 المستخدمة في تعليقات الكود الأصلي: 9،10،11،12،13،30،31،32،33،34،45...)
_WMO_TO_ICON_DAY = {
	0: "32", 1: "34", 2: "30", 3: "26",
	45: "20", 48: "20",
	51: "9", 53: "9", 55: "9",
	56: "8", 57: "8",
	61: "11", 63: "12", 65: "12",
	66: "10", 67: "10",
	71: "16", 73: "16", 75: "16", 77: "16",
	80: "40", 81: "40", 82: "40",
	85: "41", 86: "41",
	95: "4", 96: "3", 99: "3",
}
_WMO_TO_ICON_NIGHT = {
	0: "31", 1: "33", 2: "29", 3: "27",
	45: "20", 48: "20",
	51: "9", 53: "9", 55: "9",
	56: "8", 57: "8",
	61: "11", 63: "45", 65: "45",
	66: "10", 67: "10",
	71: "16", 73: "16", 75: "16", 77: "16",
	80: "45", 81: "45", 82: "45",
	85: "41", 86: "41",
	95: "4", 96: "3", 99: "3",
}
_WMO_DESC = {
	0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
	45: "Fog", 48: "Depositing rime fog",
	51: "Light drizzle", 53: "Drizzle", 55: "Dense drizzle",
	56: "Freezing drizzle", 57: "Dense freezing drizzle",
	61: "Slight rain", 63: "Rain", 65: "Heavy rain",
	66: "Freezing rain", 67: "Heavy freezing rain",
	71: "Slight snow", 73: "Snow", 75: "Heavy snow", 77: "Snow grains",
	80: "Rain showers", 81: "Rain showers", 82: "Violent rain showers",
	85: "Snow showers", 86: "Heavy snow showers",
	95: "Thunderstorm", 96: "Thunderstorm with hail", 99: "Thunderstorm with heavy hail",
}


def errorlog(err, filename=""):
	logger.error(f"{filename or '?'}: {err}")


def checkUpdateWeather(path):
	try:
		if not os.path.exists(path):
			return True
		age = time.time() - os.path.getmtime(path)
		return age > 3600  # تحديث كل ساعة
	except Exception as e:
		errorlog(e, "checkUpdateWeather")
		return False


def dataRead(path):
	try:
		with open(path, "r") as f:
			return json.load(f)
	except Exception as e:
		errorlog(e, "dataRead")
		return "N/A"


def getmtimedatajson(path):
	try:
		return time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(path)))
	except Exception as e:
		errorlog(e, "getmtimedatajson")
		return "N/A"


def _get_location():
	"""يحاول قراءة موقع المستخدم من إعدادات enigma2، وإلا يستخدم الإحداثيات الافتراضية."""
	try:
		from Components.config import config
		lat = float(config.geolocation.latitude.value)
		lon = float(config.geolocation.longitude.value)
		if lat and lon:
			return lat, lon
	except Exception:
		pass
	return DEFAULT_LAT, DEFAULT_LON


def runOM():
	"""
	يجلب بيانات الطقس فعليًا من Open-Meteo (لا يحتاج مفتاح API) ويكتبها بصيغة JSON
	متوافقة تمامًا مع ما يتوقعه LiiS8WeatherOM.py (day_0..day_6 + current).
	"""
	if not HAS_NET:
		errorlog("Tools.LiiS8Requests غير متوفر - لا يمكن جلب الطقس", "runOM")
		return False

	lat, lon = _get_location()
	url = "https://api.open-meteo.com/v1/forecast"
	params = {
		"latitude": lat,
		"longitude": lon,
		"current_weather": "true",
		"hourly": "relativehumidity_2m,surface_pressure,cloudcover",
		"daily": "weathercode,temperature_2m_max,temperature_2m_min,sunrise,sunset,"
		         "precipitation_sum,snowfall_sum,shortwave_radiation_sum,windspeed_10m_max",
		"timezone": "auto",
	}
	data = fetch_json(url, params=params)
	if not data:
		errorlog("فشل جلب بيانات Open-Meteo", "runOM")
		return False

	try:
		out = {}
		daily = data.get("daily", {})
		dates = daily.get("time", [])
		codes = daily.get("weathercode", [])
		tmax = daily.get("temperature_2m_max", [])
		tmin = daily.get("temperature_2m_min", [])
		sunrise = daily.get("sunrise", [])
		sunset = daily.get("sunset", [])
		rain = daily.get("precipitation_sum", [])
		snow = daily.get("snowfall_sum", [])
		rad = daily.get("shortwave_radiation_sum", [])
		wind = daily.get("windspeed_10m_max", [])

		for i in range(len(dates)):
			try:
				code = codes[i]
				day_struct = time.strptime(dates[i], "%Y-%m-%d")
				out[f"day_{i}"] = {
					"date": dates[i],
					"short_day": time.strftime("%a", day_struct),
					"desc": _WMO_DESC.get(code, "N/A"),
					"temp_min": tmin[i],
					"temp_max": tmax[i],
					"radiation": rad[i] if i < len(rad) else "N/A",
					"wind": wind[i] if i < len(wind) else "N/A",
					"sunrise": sunrise[i][-5:] if i < len(sunrise) else "N/A",
					"sunset": sunset[i][-5:] if i < len(sunset) else "N/A",
					"rain_sum": rain[i] if i < len(rain) else 0,
					"snowfall_sum": snow[i] if i < len(snow) else 0,
					"icon": _WMO_TO_ICON_DAY.get(code, "44"),
				}
			except Exception as e:
				errorlog(e, f"runOM day_{i}")

		cw = data.get("current_weather", {})
		is_day = cw.get("is_day", 1)
		code = cw.get("weathercode", 0)
		icon_map = _WMO_TO_ICON_DAY if is_day else _WMO_TO_ICON_NIGHT
		hourly = data.get("hourly", {})
		humidity = hourly.get("relativehumidity_2m", ["N/A"])[0] if hourly.get("relativehumidity_2m") else "N/A"
		pressure = hourly.get("surface_pressure", ["N/A"])[0] if hourly.get("surface_pressure") else "N/A"
		cloud = hourly.get("cloudcover", ["N/A"])[0] if hourly.get("cloudcover") else "N/A"

		out["current"] = {
			"temp": f"{cw.get('temperature', 'N/A')} °C",
			"icon": icon_map.get(code, "44"),
			"city": _reverse_geocode(lat, lon),
			"elevation": data.get("elevation", "N/A"),
			"date": dates[0] if dates else "N/A",
			"desc": _WMO_DESC.get(code, "N/A"),
			"wind": f"{cw.get('windspeed', 'N/A')} km/h",
			"humidity": f"{humidity}%",
			"pressure": f"{pressure} hPa",
			"rain": rain[0] if rain else 0,
			"snowfall": snow[0] if snow else 0,
			"cloud": f"{cloud}%",
		}

		with open(WEATHER_JSON, "w") as f:
			json.dump(out, f)
		logger.info("runOM: تم تحديث بيانات الطقس بنجاح")
		return True
	except Exception as e:
		errorlog(e, "runOM parse")
		return False


def runISS():
	"""يجلب الموقع الحالي لمحطة الفضاء الدولية عبر API عام مجاني (Open Notify)."""
	if not HAS_NET:
		errorlog("Tools.LiiS8Requests غير متوفر - لا يمكن جلب موقع ISS", "runISS")
		return False
	data = fetch_json("http://api.open-notify.org/iss-now.json")
	if not data:
		errorlog("فشل جلب موقع ISS", "runISS")
		return False
	try:
		pos = data.get("iss_position", {})
		out = {
			"latitude": pos.get("latitude", "N/A"),
			"longitude": pos.get("longitude", "N/A"),
			"timestamp": data.get("timestamp", int(time.time())),
			"updated": time.strftime("%Y-%m-%d %H:%M:%S"),
		}
		with open(ISS_JSON, "w") as f:
			json.dump(out, f)
		logger.info("runISS: تم تحديث موقع ISS بنجاح")
		return True
	except Exception as e:
		errorlog(e, "runISS parse")
		return False
