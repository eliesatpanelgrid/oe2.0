# LiiS8NetworkInfo
#!/usr/bin/python
# -*- coding: utf-8 -*-

try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")
from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.Network import iNetwork
from Components.Converter.Poll import Poll


class LiiS8NetworkInfo(Poll, Converter, object):
	IP = 0
	Interface = 1
	Gateway = 2
	DNS = 3
	MAC = 4
	LinkState = 5

	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)
		self.poll_interval = 5000
		self.poll_enabled = True
		if type == "IP":
			self.type = self.IP
		elif type == "Interface":
			self.type = self.Interface
		elif type == "Gateway":
			self.type = self.Gateway
		elif type == "DNS":
			self.type = self.DNS
		elif type == "MAC":
			self.type = self.MAC
		elif type == "LinkState":
			self.type = self.LinkState
		else:
			self.type = self.IP

	def getActiveInterface(self):
		try:
			ifaces = iNetwork.getConfiguredAdapters()
			for iface in ifaces:
				if iNetwork.getAdapterAttribute(iface, "up"):
					return iface
			if ifaces:
				return ifaces[0]
		except Exception as e:
			logger.error(f"getActiveInterface (line 47): {e}")
			pass
		return None

	@cached
	def getText(self):
		iface = self.getActiveInterface()
		if not iface:
			return "No Connection"
		try:
			if self.type == self.IP:
				ip = iNetwork.getAdapterAttribute(iface, "ip")
				if ip:
					return ".".join(str(x) for x in ip)
				return "0.0.0.0"
			elif self.type == self.Interface:
				return iface
			elif self.type == self.Gateway:
				gw = iNetwork.getAdapterAttribute(iface, "gateway")
				if gw:
					return ".".join(str(x) for x in gw)
				return "N/A"
			elif self.type == self.DNS:
				dns = iNetwork.getAdapterAttribute(iface, "dns-nameservers")
				if dns:
					return ".".join(str(x) for x in dns[0])
				return "N/A"
			elif self.type == self.MAC:
				mac = iNetwork.getAdapterAttribute(iface, "mac")
				return mac or "N/A"
			elif self.type == self.LinkState:
				up = iNetwork.getAdapterAttribute(iface, "up")
				return "Connected" if up else "Disconnected"
		except Exception as e:
			logger.error(f"getText (line 80): {e}")
			return "N/A"
		return ""

	text = property(getText)

	@cached
	def getBoolean(self):
		iface = self.getActiveInterface()
		if not iface:
			return False
		if self.type == self.IP:
			# isWifi: إذا بدأ اسم الواجهة بـ wlan أو wlp أو ra
			return iface.startswith(("wlan", "wlp", "ra", "wifi"))
		return False

	boolean = property(getBoolean)

	def changed(self, what):
		Converter.changed(self, what)
