#!/usr/bin/python
# -*- coding: utf-8 -*-

#
from __future__ import absolute_import, print_function
import sys

PY3 = sys.version_info[0] >= 3
if not PY3:
    from urllib import quote_plus
else:
    from urllib.parse import quote_plus


def safe_str(value):
    try:
        if value is None:
            return ""
        return str(value).strip()
    except Exception:
        return ""


def quoteEventName(eventName, safe="+"):
    """
    ترميز اسم الحدث/العنوان بصيغة URL-safe (لاستخدامه في روابط بحث API).
    """
    try:
        text = eventName.decode('utf8').replace(u'\x86', u'').replace(u'\x87', u'').encode('utf8')
    except BaseException:
        text = eventName
    return quote_plus(text, safe=safe)


def split_title_and_year(title):
    """
    يفصل السنة الملحقة بنهاية العنوان (مثل "Inception 2010" أو "Inception - 2010")
    عن اسم الفيلم/المسلسل نفسه.

    يُعيد: (base_title, year) أو (title, "") إن لم توجد سنة.
    """
    try:
        import re
        title = safe_str(title)
        if not title:
            return "", ""
        match = re.compile(r'^(.*?)(?:[\s:._\-]+)((?:19|20)\d{2})$').search(title)
        if not match:
            return title, ""
        base_title = safe_str(match.group(1)).strip(" :._-")
        year = safe_str(match.group(2))
        if not base_title:
            return title, ""
        return base_title, year
    except Exception:
        return safe_str(title), ""


def create_secure_log_dir():
    """
    ينشئ مجلد سجلات آمنًا (صلاحيات 0700 + تحقق من الملكية) تحت المجلد المؤقت
    للنظام، مطابق لسلوك create_secure_log_dir الأصلي في Agp_Utils.py، لكن
    باسم مجلد "liis8log" بدل "agplog".
    """
    import os
    import tempfile

    base_tmp = tempfile.gettempdir()
    target_dir = os.path.join(base_tmp, "liis8log")

    try:
        if not os.path.exists(target_dir):
            os.makedirs(target_dir, 0o700)
        else:
            os.chmod(target_dir, 0o700)

        if not os.path.isdir(target_dir):
            return tempfile.mkdtemp(prefix="liis8log_")

        if os.stat(target_dir).st_uid != os.getuid():
            return tempfile.mkdtemp(prefix="liis8log_")

        return target_dir

    except Exception:
        return tempfile.mkdtemp(prefix="liis8log_")
