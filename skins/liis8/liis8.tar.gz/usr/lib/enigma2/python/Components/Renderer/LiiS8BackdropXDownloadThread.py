# LiiS8BackdropXDownloadThread
#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
LiiS8BackdropXDownloadThread.py
"""

from __future__ import absolute_import

import json
import os
import random
import threading
import time
import queue as _queue

try:
    from PIL import Image
except Exception:
    Image = None

try:
    import requests
    http_session = requests.Session()
    try:
        adapter = requests.adapters.HTTPAdapter(pool_connections=3, pool_maxsize=3)
        http_session.mount("http://", adapter)
        http_session.mount("https://", adapter)
    except Exception:
        pass
    REQUESTS_OK = True
except Exception:
    requests     = None
    http_session = None
    REQUESTS_OK  = False

from .LiiS8Converlibr import (
    get_backdrop_folder,
    get_cfg,
    queue_gui_callback,
    set_batch_backdrop_queue_fn,
    get_cached_search,
    set_cached_search,
    invalidate_file_cache,
    file_exists_cached,
)
from .LiiS8PosterXDownloadThread import get_backdrop_url
from .LiiS8DebugTrace import trace, timed_block

TMDB_SEARCH_MULTI = "https://api.themoviedb.org/3/search/multi"
TMDB_IMG_BASE     = "https://image.tmdb.org/t/p/"
TMDB_IMG_W500     = "https://image.tmdb.org/t/p/w500"

T_CONN = 1.5
T_READ = 3
T_IMG  = 8
MIN_BYTES = 8192

MAX_RETRIES   = 2
RETRY_DELAY_S = 7200
FLUSH_EVERY   = 50
STATE_VERSION = "7"
NET_COOLDOWN  = 10
CLEANUP_DAYS_FAILED  = 7
CLEANUP_DAYS_SUCCESS = 180
CLEANUP_INTERVAL_S   = 6 * 3600

STATUS_FOUND     = "found"
STATUS_NOT_FOUND = "not_found"
STATUS_NETWORK   = "network"
STATUS_SAVE_FAIL = "save_fail"

live_queue    = _queue.Queue(maxsize=200)
_pending      = {}
_pending_lock = threading.Lock()

_pending_callbacks = {}
_callback_lock     = threading.Lock()


def register_renderer_callback(clean_title, renderer_obj):
    if not clean_title or renderer_obj is None:
        return
    with _callback_lock:
        bucket = _pending_callbacks.setdefault(clean_title, [])
        if renderer_obj not in bucket:
            bucket.append(renderer_obj)


def unregister_renderer(clean_title, renderer_obj):
    with _callback_lock:
        bucket = _pending_callbacks.get(clean_title)
        if not bucket:
            return
        try:
            bucket.remove(renderer_obj)
        except ValueError:
            return
        if not bucket:
            del _pending_callbacks[clean_title]


def _notify_success(clean_title, saved_path):
    if not clean_title or not saved_path or not os.path.exists(saved_path):
        return
    invalidate_file_cache(saved_path)
    with _callback_lock:
        renderers = _pending_callbacks.pop(clean_title, None)
    if not renderers:
        return
    for r in renderers:
        queue_gui_callback(r.backdrop_download_completed, clean_title, saved_path)


LOG_FILE      = "/tmp/LiiS8BackdropX.log"
LOG_MAX_BYTES = 1024 * 1024


def log_event(source, ch, raw, clean, status, provider, msg):
    try:
        line = "[%s] | [%s] | %s | %s | %s | %s | %s | %s\n" % (
            time.strftime("%Y-%m-%d %H:%M:%S"), str(source).upper(),
            ch or "-", raw or "-", clean or "-",
            str(status).upper(), provider or "-", msg or "")
        try:
            if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX_BYTES:
                with open(LOG_FILE, "rb") as f:
                    f.seek(-(LOG_MAX_BYTES // 2), os.SEEK_END)
                    tail = f.read()
                with open(LOG_FILE, "wb") as f:
                    f.write(tail)
        except Exception:
            pass
        with open(LOG_FILE, "a") as f:
            f.write(line)
    except Exception:
        pass


def log(msg, level="INFO"):
    log_event("SYSTEM", "-", "-", "-", level, "-", msg)


_net_down_until = [0]


def _now():
    return int(time.time())


def network_available():
    return _now() >= _net_down_until[0]


def mark_network_error(reason=None):
    _net_down_until[0] = _now() + NET_COOLDOWN


def mark_network_ok():
    _net_down_until[0] = 0


def _is_net_exc(err):
    if requests is None:
        return True
    try:
        return isinstance(err, (requests.exceptions.Timeout,
                                requests.exceptions.ConnectionError,
                                requests.exceptions.RequestException))
    except Exception:
        return True


def _is_net_status(code):
    try:
        return int(code) in (408, 429) or int(code) >= 500
    except Exception:
        return False


_state        = {}
_state_lock   = threading.Lock()
_write_lock   = threading.Lock()
_dirty        = [0]
_flush_ev     = threading.Event()
_last_cleanup = [0]
_neg_cache    = {}
_neg_expiry   = 12 * 3600


def _state_file():
    return os.path.join(get_backdrop_folder(), "scan_state.json")


def _set_state(title, status, retries=0, next_scan=0):
    with _state_lock:
        _state[title] = {
            "status":    status,
            "retries":   int(retries),
            "last_scan": int(time.time()),
            "next_scan": int(next_scan),
        }
        _dirty[0] += 1
        if _dirty[0] >= FLUSH_EVERY:
            _flush_ev.set()


def _write_state():
    with _write_lock:
        try:
            with _state_lock:
                snapshot = dict(_state)
            if not snapshot:
                return
            sf  = _state_file()
            tmp = sf + ".tmp"
            with open(tmp, "w") as f:
                f.write('{"_version":"%s","_updated":"%s","entries":{' % (
                    STATE_VERSION, time.strftime("%Y-%m-%d %H:%M:%S")))
                items = list(snapshot.items())
                for idx, (key, value) in enumerate(items):
                    f.write('%s:%s' % (
                        json.dumps(key),
                        json.dumps(value, separators=(",", ":"))))
                    if idx < len(items) - 1:
                        f.write(",")
                f.write("}}")
                f.flush()
            os.replace(tmp, sf)
            with _state_lock:
                _dirty[0] = 0
        except Exception as e:
            log("State write error: %s" % e, "WARN")


def _load_state():
    global _state
    sf = _state_file()
    try:
        if not os.path.exists(sf) or os.path.getsize(sf) == 0:
            return
        with open(sf, "r") as f:
            raw = json.load(f)
        _state = raw.get("entries", raw) if isinstance(raw, dict) else {}
        log("Backdrop state: %d entries" % len(_state))
    except Exception as e:
        log("State load error: %s" % e, "WARN")
        _state = {}


def _clean_old_entries():
    now = time.time()
    to_del = []
    with _state_lock:
        for title, entry in _state.items():
            ls  = entry.get("last_scan", 0)
            st  = entry.get("status", "")
            ret = entry.get("retries", 0)
            if st == "failed" and ret >= MAX_RETRIES and now - ls > CLEANUP_DAYS_FAILED * 86400:
                to_del.append(title)
            elif st == "ok" and now - ls > CLEANUP_DAYS_SUCCESS * 86400:
                to_del.append(title)
        for t in to_del:
            del _state[t]
            _dirty[0] += 1
    if to_del:
        _write_state()
    cutoff = now - _neg_expiry
    for t in [k for k, v in list(_neg_cache.items()) if v < cutoff]:
        _neg_cache.pop(t, None)


def state_is_ok(title):
    with _state_lock:
        st = _state.get(title)
        return st is not None and st.get("status") == "ok"


def _mark_found(title):
    _set_state(title, "ok")
    _neg_cache.pop(title, None)
    _notify_success(title, os.path.join(get_backdrop_folder(), title + ".jpg"))
    with _state_lock:
        dirty = _dirty[0]
    if dirty >= FLUSH_EVERY:
        _write_state()


def _mark_not_found(title):
    with _state_lock:
        retries = int(_state.get(title, {}).get("retries", 0)) + 1
    if retries >= MAX_RETRIES:
        with _state_lock:
            _state.pop(title, None)
            _dirty[0] += 1
        _neg_cache[title] = time.time()
    else:
        _set_state(title, "failed", retries, int(time.time()) + RETRY_DELAY_S)


def _should_download(title, dest):
    if file_exists_cached(dest):
        if not state_is_ok(title):
            _mark_found(title)
        return False
    if title in _neg_cache:
        if time.time() - _neg_cache[title] < _neg_expiry:
            return False
        del _neg_cache[title]
    with _state_lock:
        st = _state.get(title)
    if st is None:
        return True
    status  = st.get("status", "pending")
    retries = int(st.get("retries", 0))
    next_sc = int(st.get("next_scan", 0))
    if status == "ok":
        return False
    if status == "failed":
        return retries < MAX_RETRIES and time.time() >= next_sc
    return True


_UA = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Firefox/115.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/114.0",
]


def _ua():
    return random.choice(_UA)


def _find_backdrop_url(title, candidates=None):
    # 1. Check shared cache from poster downloader
    cached_url = get_backdrop_url(title)
    if cached_url:
        return STATUS_FOUND, cached_url

    # 2. Check local search cache
    tries = list(dict.fromkeys(filter(None, candidates or [title])))[:4]
    title_lower = title.lower()
    for candidate in tries:
        cached = get_cached_search(candidate)
        if cached is not None:
            if cached.get("status") == STATUS_FOUND:
                url = cached.get("backdrop_url") or cached.get("url", "")
                if url:
                    return STATUS_FOUND, url
            elif cached.get("status") == STATUS_NOT_FOUND:
                continue

    if not REQUESTS_OK or not network_available():
        return STATUS_NETWORK, None

    # Get configured size (default w500)
    size = get_cfg("BACKDROP_SIZE") or "w500"
    valid_sizes = ["w300", "w500", "w780", "w1280", "original"]
    if size not in valid_sizes:
        size = "w500"
    size_part = "" if size == "original" else size

    for candidate in tries:
        try:
            resp = http_session.get(
                TMDB_SEARCH_MULTI,
                params={
                    "api_key":       get_cfg("TMDB_API_KEY"),
                    "language":      get_cfg("TMDB_LANGUAGE"),
                    "include_adult": "false",
                    "query":         candidate,
                },
                headers={"User-Agent": _ua()},
                timeout=(T_CONN, T_READ),
                verify=False,
            )
            if not resp.ok:
                if _is_net_status(resp.status_code):
                    mark_network_error("backdrop search: %s" % candidate)
                    return STATUS_NETWORK, None
                continue

            mark_network_ok()
            results = resp.json().get("results", [])
            exact_item = None
            for item in results:
                item_title = (item.get("title") or item.get("name") or "").lower()
                if item_title == title_lower:
                    exact_item = item
                    break
            if exact_item:
                results = [exact_item]

            for item in results:
                mt = item.get("media_type")
                if mt not in ("movie", "tv"):
                    continue
                bp = item.get("backdrop_path")
                pp = item.get("poster_path")
                if bp:
                    if size_part:
                        url = TMDB_IMG_BASE + size_part + bp
                    else:
                        url = TMDB_IMG_BASE + "original" + bp
                elif pp:
                    url = TMDB_IMG_W500 + pp
                else:
                    continue
                set_cached_search(candidate, {
                    "status":       STATUS_FOUND,
                    "url":          url,
                    "backdrop_url": url,
                    "vote_average": item.get("vote_average", 0),
                })
                return STATUS_FOUND, url

        except Exception as e:
            if _is_net_exc(e):
                mark_network_error(str(e))
                return STATUS_NETWORK, None

    return STATUS_NOT_FOUND, None


def _save_backdrop(url, dest):
    if not REQUESTS_OK or not network_available():
        return STATUS_NETWORK
    tmp = dest + ".part"
    try:
        resp = http_session.get(url, headers={"User-Agent": _ua()},
                                timeout=(T_CONN, T_IMG), verify=False)
        if not resp.ok:
            if _is_net_status(resp.status_code):
                mark_network_error("backdrop img failed")
                return STATUS_NETWORK
            return STATUS_SAVE_FAIL
        mark_network_ok()
        data = resp.content
        if not data or len(data) < MIN_BYTES:
            return STATUS_SAVE_FAIL
        with open(tmp, "wb") as f:
            f.write(data)
        if Image is not None:
            try:
                img = Image.open(tmp)
                img.verify()
                img.close()
            except Exception:
                return STATUS_SAVE_FAIL
        os.replace(tmp, dest)
        return STATUS_FOUND if os.path.exists(dest) else STATUS_SAVE_FAIL
    except Exception as e:
        if _is_net_exc(e):
            mark_network_error(str(e))
            return STATUS_NETWORK
        return STATUS_SAVE_FAIL
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


def _release(title):
    with _pending_lock:
        _pending.pop(title, None)


def _process(item):
    if len(item) >= 4:
        clean_title, raw, ch, candidates = item
    else:
        clean_title, raw, ch = item[:3]
        candidates = [clean_title]

    bfolder = get_backdrop_folder()
    dest    = os.path.join(bfolder, clean_title + ".jpg")

    try:
        if not _should_download(clean_title, dest):
            if os.path.exists(dest):
                _notify_success(clean_title, dest)
            return
        if not network_available():
            return
        with timed_block("BackdropWorker", "find-url", clean_title):
            status, url = _find_backdrop_url(clean_title, candidates)
        if status == STATUS_NETWORK:
            return
        if status == STATUS_FOUND and url:
            save_st = _save_backdrop(url, dest)
            if save_st == STATUS_FOUND:
                _mark_found(clean_title)
                log_event("LIVE", ch, raw, clean_title, "FOUND", "TMDB", "saved")
            elif save_st == STATUS_NETWORK:
                _mark_not_found(clean_title)
            else:
                _mark_not_found(clean_title)
        else:
            _mark_not_found(clean_title)
    except Exception as e:
        log("Process error: %s" % e, "ERROR")
    finally:
        _release(clean_title)


def _worker(worker_id):
    while True:
        try:
            item = live_queue.get(timeout=1.0)
            if item is None:
                continue
            _process(item)
        except _queue.Empty:
            continue
        except Exception as e:
            log("Worker %d error: %s" % (worker_id, e), "WARN")


def queue_live(clean_title, raw_name=None, candidates=None):
    """Queue a title for backdrop download. raw_name is the original EPG title."""
    if not clean_title or not get_cfg("BACKDROPX_ENABLED"):
        return False
    bfolder = get_backdrop_folder()
    if file_exists_cached(os.path.join(bfolder, clean_title + ".jpg")):
        return False
    with _pending_lock:
        if clean_title in _pending:
            return False
        _pending[clean_title] = time.time()
    raw   = raw_name or clean_title
    tries = list(dict.fromkeys(candidates or [clean_title])) or [clean_title]
    try:
        live_queue.put_nowait((clean_title, raw, "-", tries))
        return True
    except _queue.Full:
        _release(clean_title)
        log("Queue full: %s" % clean_title, "WARN")
        return False


def _flush_loop():
    while True:
        _flush_ev.wait(timeout=60)
        _flush_ev.clear()
        with _state_lock:
            dirty = _dirty[0]
        if dirty > 0:
            _write_state()
        if time.time() - _last_cleanup[0] > CLEANUP_INTERVAL_S:
            _clean_old_entries()
            _last_cleanup[0] = time.time()


def _async_initialize():
    _load_state()
    try:
        n = max(1, int(get_cfg("WORKER_THREADS") or 6) // 2)
    except Exception:
        n = 3
    for i in range(n):
        t = threading.Thread(target=_worker, args=(i,))
        t.daemon = True
        t.start()
    t = threading.Thread(target=_flush_loop)
    t.daemon = True
    t.start()
    log("BackdropX initialized: %d workers" % n)


set_batch_backdrop_queue_fn(queue_live)
threading.Thread(target=_async_initialize, daemon=True).start()