# LiiS8BackdropX
#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
LiiS8BackdropX.py
"""

from __future__ import absolute_import, print_function

import os

from Components.Renderer.Renderer import Renderer
from Components.Sources.CurrentService import CurrentService
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.ServiceEvent import ServiceEvent
from Components.config import config
from ServiceReference import ServiceReference
from enigma import ePixmap, loadJPG, eTimer
import NavigationInstance

from .LiiS8Converlibr import (
    get_zap_context,
    is_sport_or_news_channel,
    clean_name,
    convtext,
    get_backdrop_folder,
    register_backdrop_slot,
    register_nxts_slot,
    file_exists_cached,
    _zap_ctx,
    invalidate_zap_context,
)
from .LiiS8BackdropXDownloadThread import (
    queue_live,
    log,
    register_renderer_callback,
    unregister_renderer,
)
from .LiiS8DebugTrace import trace

# ── no-backdrop fallback ────────────────────────────────────────────────
try:
    _cur_skin = config.skin.primary_skin.value.replace("/skin.xml", "")
except Exception:
    _cur_skin = "default"

nobackdrop = None
for _name in ["nobackdrop.jpg", "noposter.jpg"]:
    for _path in [
        f"/usr/share/enigma2/{_cur_skin}/main/{_name}",
        f"/usr/share/enigma2/skin_default/main/{_name}",
        f"/tmp/{_name}",
    ]:
        if os.path.exists(_path):
            nobackdrop = _path
            break
    if nobackdrop:
        break

_nobackdrop_pixmap = None

def _get_nobackdrop_pixmap():
    global _nobackdrop_pixmap
    if _nobackdrop_pixmap is None and nobackdrop and os.path.exists(nobackdrop):
        try:
            _nobackdrop_pixmap = loadJPG(nobackdrop)
        except Exception:
            pass
    return _nobackdrop_pixmap


class LiiS8BackdropX(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.nxts             = 0
        self._old_key         = None
        self._waiting_key     = None
        self._last_ref        = None
        self._last_generation = -1
        self._epg_retry_timer = None
        self._epg_retry_count = 0

    def destroy(self):
        self._cleanup()
        self._stop_epg_retry()
        Renderer.destroy(self)

    def applySkin(self, desktop, parent):
        keep = []
        for attrib, value in self.skinAttributes:
            if attrib == "nexts":
                try:
                    self.nxts = int(value)
                except Exception:
                    self.nxts = 0
            keep.append((attrib, value))
        self.skinAttributes = keep
        register_backdrop_slot(self.nxts)
        register_nxts_slot(self.nxts)   # <-- FIX: register for event cap
        return Renderer.applySkin(self, desktop, parent)

    def _get_service_ref(self):
        src = self.source; stype = type(src)
        if stype is Event and self.nxts:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if stype is ServiceEvent:   return src.getCurrentService()
        if stype is CurrentService: return src.getCurrentServiceRef()
        if stype is EventInfo:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return None

    def _read_from_event_source(self):
        try:
            evt = self.source.event
            if not evt: return None
            raw   = clean_name(evt.getEventName())
            clean = convtext(raw)
            if not clean: return None
            bfolder   = get_backdrop_folder()
            bpath = os.path.join(bfolder, clean + ".jpg")
            return {
                "clean_title":       clean,
                "backdrop_path":     bpath if file_exists_cached(bpath) else None,
                "skip":              False,
                "search_candidates": [clean],
                "event_key":         f"{evt.getBeginTime()}-{raw}",
                "raw_name":          raw,
            }
        except Exception:
            return None

    def _stop_epg_retry(self):
        if self._epg_retry_timer:
            self._epg_retry_timer.stop()
            self._epg_retry_timer = None
        self._epg_retry_count = 0

    def _start_epg_retry(self):
        self._stop_epg_retry()
        if self._epg_retry_count >= 3:
            return
        self._epg_retry_count += 1
        self._epg_retry_timer = eTimer()
        self._epg_retry_timer.callback.append(self._epg_retry_timer_cb)
        self._epg_retry_timer.start(1000, True)

    def _epg_retry_timer_cb(self):
        self._epg_retry_timer = None
        if not self.instance:
            return
        ctx = _zap_ctx   # global from LiiS8Converlibr
        # Only invalidate if the context is still empty
        if ctx is None or ctx._slot_count == 0:
            invalidate_zap_context(force=True)
        self.changed((self.CHANGED_DEFAULT,))

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._cleanup()
            self._old_key = None
            self._last_ref = None
            self._last_generation = -1
            self._stop_epg_retry()
            self._show_nobackdrop()
            return

        trace("LiiS8BackdropX", "changed-enter", f"nxts={int(self.nxts)}")

        slot = None
        service = None

        if type(self.source) is Event and self.nxts == 0:
            slot = self._read_from_event_source()
            self._stop_epg_retry()
        else:
            try:
                service = self._get_service_ref()
                if service is None:
                    self._show_nobackdrop()
                    self._stop_epg_retry()
                    return
                ctx = get_zap_context(service)
                if ctx is None:
                    self._show_nobackdrop()
                    self._stop_epg_retry()
                    return

                ref_str = ctx.ref_str
                if ref_str != self._last_ref:
                    self._old_key = None
                if ref_str == self._last_ref and ctx.generation == self._last_generation:
                    trace("LiiS8BackdropX", "changed-exit", f"nxts={int(self.nxts)} reason=same-generation")
                    return
                self._last_ref = ref_str
                self._last_generation = ctx.generation

                slot = ctx.get_slot(self.nxts)
            except Exception as e:
                log(f"[LiiS8BackdropX] context error: {e}", "WARN")
                self._show_nobackdrop()
                return

        if not slot or slot.get("skip"):
            self._cleanup()
            self._old_key = None
            self._show_nobackdrop()
            if type(self.source) is not Event:
                self._start_epg_retry()
            trace("LiiS8BackdropX", "changed-exit", f"nxts={int(self.nxts)} reason=no-slot-or-skip")
            return

        self._stop_epg_retry()

        event_key = slot.get("event_key", "")
        if self._old_key is not None and event_key == self._old_key:
            trace("LiiS8BackdropX", "changed-exit", f"nxts={int(self.nxts)} reason=dedup-same-key")
            return

        self._cleanup()
        self._old_key = None   # reset until displayed

        try:
            if service is None:
                service = self._get_service_ref()
            if service:
                ch = clean_name(ServiceReference(service).getServiceName())
                if is_sport_or_news_channel(ch):
                    self._show_nobackdrop()
                    trace("LiiS8BackdropX", "changed-exit", f"nxts={int(self.nxts)} reason=sport-news")
                    return
        except Exception:
            pass

        clean_title = slot.get("clean_title", "")
        if not clean_title:
            self._show_nobackdrop()
            return

        backdrop_path = slot.get("backdrop_path")
        if not backdrop_path and clean_title:
            candidate = os.path.join(get_backdrop_folder(), clean_title + ".jpg")
            if file_exists_cached(candidate):
                backdrop_path = candidate

        if backdrop_path:
            self._show_file(backdrop_path)
            self._old_key = event_key
            trace("LiiS8BackdropX", "changed-exit", f"nxts={int(self.nxts)} title={clean_title} reason=shown")
            return

        self._show_nobackdrop()
        if self._waiting_key != clean_title:
            self._cleanup()
            self._waiting_key = clean_title
            register_renderer_callback(clean_title, self)

            queued = queue_live(clean_title,
                              raw_name=slot.get("raw_name", ""),
                              candidates=slot.get("search_candidates"))
            if not queued:
                unregister_renderer(clean_title, self)
                self._waiting_key = None
                if file_exists_cached(os.path.join(get_backdrop_folder(), clean_title + ".jpg")):
                    self._show_file(os.path.join(get_backdrop_folder(), clean_title + ".jpg"))
                    self._old_key = event_key

    def backdrop_download_completed(self, clean_title, path=None):
        if path is None:
            path, clean_title = clean_title, self._waiting_key
        if not clean_title or clean_title != self._waiting_key:
            return
        if not self.instance:
            self._waiting_key = None
            return
        if not path or not os.path.exists(path):
            return
        self._waiting_key = None

        self._last_ref = None
        self._last_generation = -1
        self._old_key = None

        trace("LiiS8BackdropX", "download-completed", f"nxts={int(self.nxts)} title={clean_title}")
        self._show_file(path)
        self.changed((self.CHANGED_DEFAULT,))

    poster_download_completed = backdrop_download_completed

    def _cleanup(self):
        if self._waiting_key:
            unregister_renderer(self._waiting_key, self)
            self._waiting_key = None

    def _show_file(self, path):
        try:
            if not path or not os.path.exists(path):
                self._show_nobackdrop()
                return
            self.instance.setPixmap(loadJPG(path))
            self.instance.setScale(1)
            self.instance.show()
        except Exception as e:
            log(f"[LiiS8BackdropX] loadJPG error: {e}", "WARN")
            self._show_nobackdrop()

    def _show_nobackdrop(self):
        pix = _get_nobackdrop_pixmap()
        if pix:
            try:
                self.instance.setPixmap(pix)
                self.instance.setScale(1)
                self.instance.show()
                return
            except Exception:
                pass
        if nobackdrop and os.path.exists(nobackdrop):
            try:
                self.instance.setPixmap(loadJPG(nobackdrop))
                self.instance.setScale(1)
                self.instance.show()
                return
            except Exception:
                pass
        try:
            self.instance.show()
        except Exception:
            pass