# LiiS8Parental
#!/usr/bin/python
# -*- coding: utf-8 -*-
# by Li-iS8...06.2026

"""
LiiS8Parental.py
"""

from __future__ import absolute_import

import os
import json

from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, loadPNG, eTimer
from Components.config import config
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance

from .LiiS8Converlibr import (
    get_zap_context,
    register_metadata_callback,
    unregister_metadata_callback,
    register_nxts_slot,
    get_event_source_metadata,
    _load_json_once,
    _has_useful_metadata,
    _zap_ctx,
    invalidate_zap_context,
)
from .LiiS8DebugTrace import trace

DEFAULT_RATING = 'UN'

RATING_MAP = {
    'TV-Y': '0', 'TV-Y7': '6', 'TV-G': '0', 'TV-PG': '12',
    'TV-14': '16', 'TV-MA': '18', 'G': '0', 'PG': '6',
    'PG-13': '12', 'R': '16', 'NC-17': '18',
    'PEGI-3': '0', 'PEGI-7': '6', 'PEGI-12': '12',
    'PEGI-16': '16', 'PEGI-18': '18',
    'FSK 0': '0', 'FSK 6': '6', 'FSK 12': '12',
    'FSK 16': '16', 'FSK 18': '18',
    '0': '0', '6': '6', '12': '12', '16': '16', '18': '18',
    'U': '0', 'U/A': '12', 'A': '16',
    '': DEFAULT_RATING, 'UN': DEFAULT_RATING,
}


def _get_icon_path(rating_code):
    try:
        cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
        skin_path = f"/usr/share/enigma2/{cur_skin}/parental/FSK_{rating_code}.png"
        if os.path.exists(skin_path):
            return skin_path
    except Exception:
        pass
    default = f"/usr/share/enigma2/skin_default/parental/FSK_{rating_code}.png"
    return default if os.path.exists(default) else None


_icon_pixmap_cache = {}


def _get_cached_pixmap(icon_path):
    if not icon_path:
        return None
    pix = _icon_pixmap_cache.get(icon_path)
    if pix is not None:
        return pix
    try:
        if os.path.exists(icon_path):
            pix = loadPNG(icon_path)
            if pix:
                _icon_pixmap_cache[icon_path] = pix
    except Exception:
        pix = None
    return pix


class LiiS8Parental(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.nxts = 0
        self.old_key = None
        self._pending_title = None
        self._pending_callback = None
        self._last_ref = None
        self._last_generation = -1
        self._epg_retry_timer = None
        self._epg_retry_count = 0

    def destroy(self):
        self._clear_pending()
        self._stop_epg_retry()
        Renderer.destroy(self)

    def applySkin(self, desktop, screen):
        for attrib, value in self.skinAttributes:
            if attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except Exception:
                    self.nxts = 0
        register_nxts_slot(self.nxts)
        return Renderer.applySkin(self, desktop, screen)

    def _get_service_ref(self):
        src = self.source
        stype = type(src)
        if stype is ServiceEvent:
            return src.getCurrentService()
        if stype is CurrentService:
            return src.getCurrentServiceRef()
        if stype is EventInfo:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if stype is Event:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return None

    def _on_metadata_ready(self, for_title):
        if self._pending_title == for_title and self.instance:
            self.old_key = None
            self._pending_title = None
            self._pending_callback = None
            self._last_ref = None
            self._last_generation = -1
            self.changed((self.CHANGED_DEFAULT,))

    def _show_icon(self, icon_path):
        pix = _get_cached_pixmap(icon_path)
        if pix:
            try:
                self.instance.setPixmap(pix)
                self.instance.show()
                return
            except Exception:
                pass
        try:
            self.instance.hide()
        except Exception:
            pass

    def _fallback_load_parental(self, clean_title):
        if not clean_title:
            return None
        try:
            data = _load_json_once({clean_title})
            entry = data.get(clean_title, {})
            if entry and (entry.get('parental_rating') or entry.get('title')):
                return entry.get('parental_rating', '')
        except Exception:
            pass
        return None

    def _stop_epg_retry(self):
        if self._epg_retry_timer:
            self._epg_retry_timer.stop()
            self._epg_retry_timer = None
        self._epg_retry_count = 0

    def _start_epg_retry(self):
        self._stop_epg_retry()
        if self._epg_retry_count >= 3:
            return
        self._epg_retry_count += 1
        self._epg_retry_timer = eTimer()
        self._epg_retry_timer.callback.append(self._epg_retry_timer_cb)
        self._epg_retry_timer.start(1000, True)

    def _epg_retry_timer_cb(self):
        self._epg_retry_timer = None
        if not self.instance:
            return
        ctx = _zap_ctx
        if ctx is None or ctx._slot_count == 0:
            invalidate_zap_context(force=True)
        self.changed((self.CHANGED_DEFAULT,))

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._clear_pending()
            self._stop_epg_retry()
            self.old_key = None
            self._last_ref = None
            self._last_generation = -1
            self.instance.hide()
            return

        try:
            cur_key = None
            parental = None

            if type(self.source) is Event:
                slot = get_event_source_metadata(self.source)
                if not slot or slot.get('skip'):
                    self._clear_pending()
                    self._stop_epg_retry()
                    self.instance.hide()
                    return
                cur_key = slot.get('event_key', '')
                if cur_key and cur_key == self.old_key:
                    return
                self.old_key = None
                self._last_ref = None
                self._last_generation = -1
                parental = slot.get('parental', '')
                if (not parental and (not slot.get('metadata_resolved') or not slot.get('title'))) and slot.get('clean_title'):
                    parental = self._fallback_load_parental(slot.get('clean_title', ''))
                self._stop_epg_retry()
            else:
                service = self._get_service_ref()
                if service is None:
                    self.instance.hide()
                    return
                ctx = get_zap_context(service)
                if ctx is None:
                    self.instance.hide()
                    return
                ref_str = ctx.ref_str
                if ref_str != self._last_ref:
                    self.old_key = None
                if ref_str == self._last_ref and ctx.generation == self._last_generation:
                    return
                self._last_ref = ref_str
                self._last_generation = ctx.generation
                slot = ctx.get_slot(self.nxts)
                if not slot or slot.get('skip'):
                    self._clear_pending()
                    self.instance.hide()
                    if self._epg_retry_count < 3:
                        self._start_epg_retry()
                    return
                cur_key = slot.get('event_key', '')
                if cur_key and cur_key == self.old_key:
                    return
                parental = slot.get('parental', '')
                if (not parental and (not slot.get('metadata_resolved') or not slot.get('title'))) and slot.get('clean_title'):
                    parental = self._fallback_load_parental(slot.get('clean_title', ''))
                self._stop_epg_retry()

            if parental:
                self._clear_pending()
                code = RATING_MAP.get(parental.upper(), DEFAULT_RATING)
                icon = _get_icon_path(code)
                if icon:
                    self._show_icon(icon)
                    self.old_key = cur_key
                    return

            if slot and slot.get('metadata_resolved'):
                self._clear_pending()
                self._show_icon(_get_icon_path(DEFAULT_RATING))
                self.old_key = cur_key
                return

            clean_title = slot.get('clean_title', '') if slot else ''
            if clean_title:
                if clean_title != self._pending_title:
                    self._clear_pending()
                    self._pending_title = clean_title
                    cb = lambda t=clean_title: self._on_metadata_ready(t)
                    self._pending_callback = cb
                    register_metadata_callback(clean_title, cb)
            else:
                self._clear_pending()

            self._show_icon(_get_icon_path(DEFAULT_RATING))

        except Exception:
            self.instance.hide()

    def _clear_pending(self):
        if self._pending_title and self._pending_callback:
            unregister_metadata_callback(self._pending_title, self._pending_callback)
        self._pending_title = None
        self._pending_callback = None