# LiiS8InfoEvents 
#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
LiiS8InfoEvents.py
INFO EVENTS RENDERER - improved EPG retry
"""

from __future__ import absolute_import
try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")

import json

from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText
from enigma import eLabel, eTimer
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance

from .LiiS8Converlibr import (
    get_zap_context,
    clean_name,
    convtext,
    register_metadata_callback,
    unregister_metadata_callback,
    register_nxts_slot,
    get_event_source_metadata,
    format_overview,
    _load_json_once,
    _has_useful_metadata,
    _zap_ctx,
    invalidate_zap_context,
)
from .LiiS8DebugTrace import trace


class LiiS8InfoEvents(Renderer, VariableText):
    GUI_WIDGET = eLabel

    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)
        self.nxts = 0
        self.field = None
        self.old_key = None
        self._label_color = "\\c00ffcc00"
        self._value_color = "\\c00ffffff"
        self._title_color = "\\c00ffffff"
        self._pending_title = None
        self._pending_callback = None
        self._last_ref = None
        self._last_generation = -1
        self._epg_retry_timer = None
        self._epg_retry_count = 0

        self._plot_lines = []
        self._scroll_offset = 0
        self._visible_lines = 0
        self._scroll_timer = None
        self._scroll_enabled = False
        self._scroll_speed = 3000

    def destroy(self):
        self._stop_scroll()
        self._clear_pending()
        self._stop_epg_retry()
        Renderer.destroy(self)

    def applySkin(self, desktop, screen):
        for attrib, value in self.skinAttributes:
            if attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except Exception as e:
                    logger.error(f"applySkin (line 77): {e}")
                    self.nxts = 0
            elif attrib == 'field':
                self.field = str(value).lower()
            elif attrib == "labelcolor":
                try:
                    hex_val = value.strip().lstrip("#")
                    if len(hex_val) == 6:
                        self._label_color = f"\\c00{hex_val.lower()}"
                except Exception as e:
                    logger.error(f"applySkin (line 86): {e}")
                    pass
            elif attrib == "valuecolor":
                try:
                    hex_val = value.strip().lstrip("#")
                    if len(hex_val) == 6:
                        self._value_color = f"\\c00{hex_val.lower()}"
                except Exception as e:
                    logger.error(f"applySkin (line 93): {e}")
                    pass
            elif attrib == "titlecolor":
                try:
                    hex_val = value.strip().lstrip("#")
                    if len(hex_val) == 6:
                        self._title_color = f"\\c00{hex_val.lower()}"
                except Exception as e:
                    logger.error(f"applySkin (line 100): {e}")
                    pass
            elif attrib == "scroll":
                self._scroll_enabled = value.lower() == "true"
            elif attrib == "speed":
                try:
                    self._scroll_speed = int(value)
                except Exception as e:
                    logger.error(f"applySkin (line 107): {e}")
                    pass
        register_nxts_slot(self.nxts)
        return Renderer.applySkin(self, desktop, screen)

    def _get_service_ref(self):
        src = self.source
        stype = type(src)
        if stype is ServiceEvent:
            return src.getCurrentService()
        if stype is CurrentService:
            return src.getCurrentServiceRef()
        if stype is EventInfo:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if stype is Event:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return None

    def _on_metadata_ready(self, for_title):
        if self._pending_title == for_title and self.instance:
            self.old_key = None
            self._pending_title = None
            self._pending_callback = None
            self._last_ref = None
            self._last_generation = -1
            self.changed((self.CHANGED_DEFAULT,))

    def _start_scroll(self):
        if not self._scroll_enabled or self._scroll_timer is not None:
            return
        if len(self._plot_lines) <= self._visible_lines:
            return
        self._scroll_offset = 0
        self._scroll_timer = eTimer()
        self._scroll_timer.callback.append(self._scroll_down)
        self._scroll_timer.start(self._scroll_speed, True)

    def _stop_scroll(self):
        if self._scroll_timer:
            self._scroll_timer.stop()
            self._scroll_timer = None
        self._plot_lines = []
        self._scroll_offset = 0

    def _scroll_down(self):
        if not self._plot_lines or not self.instance:
            self._stop_scroll()
            return
        self._scroll_offset += 1
        if self._scroll_offset > len(self._plot_lines) - self._visible_lines:
            self._scroll_offset = 0
        self._update_scroll_display()
        if self._scroll_timer:
            self._scroll_timer.start(self._scroll_speed, True)

    def _update_scroll_display(self):
        if not self._plot_lines:
            return
        end = min(self._scroll_offset + self._visible_lines, len(self._plot_lines))
        visible_lines = self._plot_lines[self._scroll_offset:end]
        if len(self._plot_lines) > self._visible_lines:
            if self._scroll_offset > 0 and end < len(self._plot_lines):
                visible_lines.append("...")
        self.text = "\n".join(visible_lines)

    def _display_data(self, data):
        if not self.instance:
            return

        lc = self._label_color
        vc = self._value_color
        tc = self._title_color

        if self.field:
            val = ""
            f = self.field
            if f == "title":
                val = data.get('title', '')
            elif f == "year":
                val = data.get('year', '')
            elif f == "country":
                val = data.get('country', '')
            elif f == "genre":
                val = data.get('genres', '')
            elif f == "director":
                val = data.get('director', '')
            elif f == "cast":
                val = data.get('cast', '')
                if len(val) > 100:
                    val = val[:97] + "..."
            elif f == "rated":
                val = data.get('rated', '') or data.get('parental', '')
            elif f == "imdb":
                val = data.get('imdb', '')
                if val and val not in ("0", "0.0"):
                    val = f"{val}/10"
                else:
                    val = ""
            elif f == "plot":
                val = data.get('plot', '') or data.get('overview', '')
                if val:
                    val = format_overview(val)
                    self._plot_lines = val.split('\n') if '\n' in val else [val]
                    try:
                        widget_height = self.instance.size().height()
                        font_height = 22
                        self._visible_lines = max(1, widget_height // font_height)
                    except Exception as e:
                        logger.error(f"_display_data (line 214): {e}")
                        self._visible_lines = 5
                    if len(self._plot_lines) <= self._visible_lines:
                        self._stop_scroll()
                        self.text = val
                        return
                    self._start_scroll()
                    self._update_scroll_display()
                    return
            else:
                val = ""
            if val:
                self.text = f"{vc}{val}"
            else:
                self.text = ""
            return

        # full panel
        lines = []
        title = data.get('title', '')
        if title:
            lines.append(f"{tc}{title}")
            lines.append(f"{tc}{'-' * min(len(title), 40)}")
            lines.append("")
        year = data.get('year', '')
        if year:
            lines.append(f"{lc}{'Year:':10}{vc}{year}")
        country = data.get('country', '')
        if country:
            lines.append(f"{lc}{'From:':10}{vc}{country}")
        genre = data.get('genres', '')
        if genre:
            genre_display = genre.replace(', ', ' • ')
            lines.append(f"{lc}{'Genre:':10}{vc}{genre_display}")
        director = data.get('director', '')
        if director:
            lines.append(f"{lc}{'Dir:':10}{vc}{director}")
        cast = data.get('cast', '')
        if cast:
            if len(cast) > 60:
                cast = cast[:57] + "..."
            lines.append(f"{lc}{'Cast:':10}{vc}{cast}")
        rated = data.get('rated', '') or data.get('parental', '')
        if rated:
            lines.append(f"{lc}{'Rated:':10}{vc}{rated}")
        imdb = data.get('imdb', '')
        if imdb and imdb not in ("0", "0.0"):
            lines.append(f"{lc}{'IMDb:':10}{vc}{imdb}/10")
        plot = data.get('plot', '') or data.get('overview', '')
        if plot:
            lines.append("")
            plot = format_overview(plot)
            self._plot_lines = plot.split('\n') if '\n' in plot else [plot]
            lines.append(f"{vc}{plot}")
        self.text = "\n".join(lines)
        if self._scroll_enabled and self._plot_lines:
            try:
                widget_height = self.instance.size().height()
                font_height = 22
                self._visible_lines = max(1, widget_height // font_height)
            except Exception as e:
                logger.error(f"_display_data (line 274): {e}")
                self._visible_lines = 5
            if len(self._plot_lines) > self._visible_lines:
                self._start_scroll()
                self._update_scroll_display()

    def _fallback_load_metadata(self, clean_title):
        if not clean_title:
            return None
        try:
            data = _load_json_once({clean_title})
            entry = data.get(clean_title, {})
            if entry and (entry.get('title') or entry.get('vote_average') or
                          entry.get('parental_rating') or entry.get('genres') or
                          entry.get('year') or entry.get('director') or
                          entry.get('cast') or entry.get('overview')):
                rv = entry.get('vote_average', 0)
                try:
                    rv = float(rv) if rv else 0
                except Exception as e:
                    logger.error(f"_fallback_load_metadata (line 293): {e}")
                    rv = 0
                ov = entry.get('overview', '') or ''
                return {
                    'title': entry.get('title', clean_title),
                    'year': entry.get('year', ''),
                    'country': entry.get('country', ''),
                    'genres': entry.get('genres', ''),
                    'director': entry.get('director', ''),
                    'cast': entry.get('cast', ''),
                    'rated': entry.get('parental_rating', ''),
                    'parental': entry.get('parental_rating', ''),
                    'imdb': str(rv) if rv > 0 else '',
                    'overview': format_overview(ov),
                    'plot': format_overview(ov),
                    'metadata_resolved': True,
                }
        except Exception as e:
            trace("LiiS8InfoEvents", "fallback-json-error", str(e))
        return None

    def _stop_epg_retry(self):
        if self._epg_retry_timer:
            self._epg_retry_timer.stop()
            self._epg_retry_timer = None
        self._epg_retry_count = 0

    def _start_epg_retry(self):
        self._stop_epg_retry()
        if self._epg_retry_count >= 3:
            return
        self._epg_retry_count += 1
        self._epg_retry_timer = eTimer()
        self._epg_retry_timer.callback.append(self._epg_retry_timer_cb)
        self._epg_retry_timer.start(1000, True)

    def _epg_retry_timer_cb(self):
        self._epg_retry_timer = None
        if not self.instance:
            return
        ctx = _zap_ctx
        if ctx is None or ctx._slot_count == 0:
            invalidate_zap_context(force=True)
        self.changed((self.CHANGED_DEFAULT,))

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._stop_scroll()
            self._clear_pending()
            self._stop_epg_retry()
            self.old_key = None
            self._last_ref = None
            self._last_generation = -1
            self.text = ""
            return

        try:
            if type(self.source) is Event:
                slot = get_event_source_metadata(self.source)
                if not slot or slot.get('skip'):
                    self._stop_scroll()
                    self._clear_pending()
                    self._stop_epg_retry()
                    self.text = ""
                    return
                cur_key = slot.get('event_key', '')
                if cur_key and cur_key == self.old_key:
                    return
                self.old_key = None
                self._last_ref = None
                self._last_generation = -1
                self._stop_epg_retry()
            else:
                service = self._get_service_ref()
                if service is None:
                    self.text = ""
                    return
                ctx = get_zap_context(service)
                if ctx is None:
                    self.text = ""
                    return
                ref_str = ctx.ref_str
                # Clear old_key if service reference changed
                if ref_str != self._last_ref:
                    self.old_key = None
                if ref_str == self._last_ref and ctx.generation == self._last_generation:
                    return
                self._last_ref = ref_str
                self._last_generation = ctx.generation
                slot = ctx.get_slot(self.nxts)
                if not slot or slot.get('skip'):
                    self._stop_scroll()
                    self._clear_pending()
                    if self._epg_retry_count < 3:
                        self._start_epg_retry()
                    self.text = ""
                    return
                cur_key = slot.get('event_key', '')
                if cur_key and cur_key == self.old_key:
                    return
                self._stop_epg_retry()

            clean_title = slot.get('clean_title', '')
            if (not slot.get('metadata_resolved') or not slot.get('title')) and clean_title:
                fallback_data = self._fallback_load_metadata(clean_title)
                if fallback_data:
                    for k, v in fallback_data.items():
                        if v and not slot.get(k):
                            slot[k] = v
                    slot['metadata_resolved'] = True

            if slot.get('title') or slot.get('metadata_resolved'):
                self._clear_pending()
                self._display_data(slot)
                self.old_key = cur_key
                return

            if clean_title:
                if clean_title != self._pending_title:
                    self._clear_pending()
                    self._pending_title = clean_title
                    cb = lambda t=clean_title: self._on_metadata_ready(t)
                    self._pending_callback = cb
                    register_metadata_callback(clean_title, cb)
            else:
                self._clear_pending()

            if not self.field:
                self.text = "\\c00ff9900Loading..."
            else:
                self.text = ""

        except Exception:
            self.text = ""

    def _clear_pending(self):
        if self._pending_title and self._pending_callback:
            unregister_metadata_callback(self._pending_title, self._pending_callback)
        self._pending_title = None
        self._pending_callback = None