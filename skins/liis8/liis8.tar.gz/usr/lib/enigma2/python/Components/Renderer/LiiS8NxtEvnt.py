# LiiS8NxtEvnt
#!/usr/bin/python
# -*- coding: utf-8 -*-
# by Li-iS8...06.2026

from __future__ import absolute_import

from time import localtime
from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText
from enigma import eLabel, eEPGCache

class LiiS8NxtEvnt(Renderer, VariableText):
    GUI_WIDGET = eLabel
    
    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)
        self.nxEvnt = "0"
        self.snglEvnt = ""
        self.timeColor = ""
        self.currentColor = ""
        self.nextColor = ""
        self.epg = eEPGCache.getInstance()

    def applySkin(self, desktop, parent):
        attribs = self.skinAttributes[:]
        for attrib, value in self.skinAttributes:
            if attrib == 'nxtEvents':
                self.nxEvnt = value
            elif attrib == 'snglEvent':
                self.snglEvnt = value
            elif attrib == 'timeColor':
                self.timeColor = value.replace('0x', '')
            elif attrib == 'currentColor':
                self.currentColor = value.replace('0x', '')
            elif attrib == 'nextColor':
                self.nextColor = value.replace('0x', '')
        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    def _color(self, text, color):
        if not color or not text:
            return text
        return f'#{color}{text}#{color}'

    def changed(self, what):
        """Direct, non-locking EPG lookup for high stability."""
        self.text = ''
        ref = self.source.service
        if not ref:
            return
            
        try:
            # Direct lookup - no threading.Lock, no cache, no interference.
            events = self.epg.lookupEvent(['IBOCTESX', (ref.toString(), 0, -1, -1)])
            if not events:
                return

            if self.snglEvnt != "":
                idx = int(self.snglEvnt)
                if idx < len(events):
                    event_title = events[idx][4]
                    begin_time = localtime(events[idx][1])
                    time_str = f"{begin_time[3]:02d}:{begin_time[4]:02d}"
                    colored_time = self._color(time_str, self.timeColor)
                    colored_title = self._color(event_title, self.currentColor if idx == 0 else self.nextColor)
                    self.text = colored_time + " - " + colored_title
                return

            if self.nxEvnt != "0":
                count = int(self.nxEvnt)
                lines = []
                for i in range(1, min(count + 1, len(events))):
                    event_title = events[i][4]
                    begin_time = localtime(events[i][1])
                    time_str = f"{begin_time[3]:02d}:{begin_time[4]:02d}"
                    lines.append(self._color(time_str, self.timeColor) + " - " + self._color(event_title, self.nextColor))
                if lines:
                    self.text = "\n".join(lines)
                return

            if len(events) > 1:
                event_title = events[1][4]
                begin_time = localtime(events[1][1])
                time_str = f"{begin_time[3]:02d}:{begin_time[4]:02d}"
                self.text = self._color(time_str, self.timeColor) + " - " + event_title
        
        except Exception:
            self.text = ''