# LiiS8Events
# -*- coding: utf-8 -*-
# by digiteng...03.2022, 04.2022
# <widget render="LiiS8Events" source="ServiceEvent" eventNumber="4" position="1265,605" size="600,210" font="Regular; 28" noWrap="1" zPosition="2" transparent="1" />
from __future__ import absolute_import
try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")
from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText
from enigma import eLabel, eEPGCache
from time import localtime

class LiiS8Events(Renderer, VariableText):
	def __init__(self):
		Renderer.__init__(self)
		VariableText.__init__(self)
		self.epgcache = eEPGCache.getInstance()
		self.evntNmbr = 1
		
	def applySkin(self, desktop, parent):
		attribs = self.skinAttributes[:]
		for attrib, value in self.skinAttributes:
			if attrib == 'eventNumber':
				self.evntNmbr = int(value)
		self.skinAttributes = attribs
		return Renderer.applySkin(self, desktop, parent)

	GUI_WIDGET = eLabel
	def changed(self, what):
		try:
			event = self.source.event
			if event is None:
				self.text = "N/A"
				return
			if what[0] == self.CHANGED_CLEAR:
				self.text = ""
			else:
				txt = ""
				evnts=""
				service = self.source.service
				events = self.epgcache.lookupEvent(['BDTM', (service.toString(), 0, -1, -1)])
				if self.evntNmbr > len(events):
					n = len(events)
				else:
					n = self.evntNmbr + 1
				if events:
					for i in range(1, n, 1):
						if i == n:
							break
							break
						try:
							evnts = events[i][2]
							bt = localtime(events[i][0])
							txt = txt + f"\\c0000??80{bt[3]:02d}:{bt[4]:02d} \\c00??????{evnts} \n"
						except Exception as e:
							logger.error(f"changed (line 53): {e}")
							pass

				self.text = txt
		except Exception as err:
			from Tools.LiiS8WeatherUpdate import errorlog
			errorlog(err, __file__)
