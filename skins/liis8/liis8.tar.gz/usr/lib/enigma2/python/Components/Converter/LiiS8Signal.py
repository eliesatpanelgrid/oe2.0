# LiiS8Signal
# UPDATE by Li-iS8...06.2026
from Components.Converter.Converter import Converter
from Components.Element import cached

class LiiS8Signal(Converter):

	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type

	@cached
	def getText(self):

		if self.type == "SNR":
			sr = self.source.snr or 0
			if sr:
				return "{}".format(sr * 100 // 65536)
			else:
				return "0"
		
		# إضافة دعم SNRdB هنا
		# REPAIRED (مستند فعليًا إلى RaedQuickFrontendInfo2.py المؤكد وليس تخمينًا):
		# القيمة القديمة (self.source.snr / 256) لم تكن ديسيبل حقيقيًا.
		# المصدر: self.source.snr_db بمقياس (dB * 100)، مع تراجع (fallback)
		# لتقدير تقريبي من نسبة SNR المئوية إن كانت snr_db غير متاحة على
		# بعض الأجهزة/التعريفات القديمة.
		if self.type == "SNRdB":
			snr_db = getattr(self.source, "snr_db", None)
			if snr_db is not None:
				return "%3.02f dB" % (snr_db / 100.0)
			snr = getattr(self.source, "snr", None)
			if snr is not None:
				return "%3.02f dB" % (0.32 * ((snr * 100) / 65536.0) / 2)
			return "0.00 dB"

		if self.type == "SNR_LABEL":
			sr = self.source.snr or 0
			if sr:
				return "SNR : {}%".format(sr * 100 // 65536)
			else:
				return "0%"
		if self.type == "AGC":
			ac = self.source.agc or 0
			if ac:
				return "{}".format(ac * 100 // 65536)
			else:
				return "0"
		elif self.type == "AGC_LABEL":
			ac = self.source.agc or 0
			if ac:
				return "AGC : {}%".format(ac * 100 // 65536)
			else:
				return "0%"

		elif self.type == "BER":
			# REPAIRED: بعض التيونرات/التعريفات تُرجع 0xFFFFFFFF (4294967295)
			# كقيمة حارسة (sentinel) تعني "لا قراءة صالحة" (قبل القفل على
			# الإشارة أو أثناء انعدامها)، بدل ترك القيمة فارغة. كان الكود
			# القديم يعرض هذا الرقم الخام مباشرة على الشاشة.
			br = self.source.ber
			if br and br < 0xFFFFFFFF:
				return str(br)
			else:
				return "0"
		elif self.type == "Event":
			from time import time
			event = self.source.event
			if event:
				duration = event.getDuration() or 1  # REPAIRED: تفادي القسمة على صفر
				prgrs = int((int(time()) - event.getBeginTime()) * 100 // duration)
				return str(prgrs)
			else:
				return None
		elif self.type == "Event_Percent":
			from time import time
			event = self.source.event
			if event:
				duration = event.getDuration() or 1  # REPAIRED: تفادي القسمة على صفر
				prgrs = int((int(time()) - event.getBeginTime()) * 100 // duration)
				return "{}%".format(prgrs)
			else:
				return None		
	text = property(getText)

	@cached
	def getBool(self):
		if self.type == "BER":
			# REPAIRED: نفس منطق تصفية القيمة الحارسة 0xFFFFFFFF المستخدم في getText
			ber = self.source.ber
			if ber and ber < 0xFFFFFFFF:
				return True
			else:
				return False
		if self.type == "LOCK":
			lock = self.source.lock
			if lock:
				return True
			else:
				return False

	boolean = property(getBool)
	