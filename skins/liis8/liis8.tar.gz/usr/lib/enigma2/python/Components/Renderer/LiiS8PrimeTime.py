# LiiS8PrimeTime
# -*- coding: utf-8 -*-
# by Li-iS8...06.2026
# <widget render="LiiS8PrimeTime" source="ServiceEvent" position="1265,795" size="600,40" font="Regular; 30" noWrap="1" zPosition="2" transparent="1" />
from __future__ import absolute_import
try:
	from Tools.LiiS8Utils import logger
except Exception:
	import logging
	logger = logging.getLogger("LiiS8")
from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText
from enigma import eLabel, eEPGCache, eServiceReference
from time import localtime, mktime, time
from datetime import datetime
from Components.config import config

class LiiS8PrimeTime(Renderer, VariableText):

	def __init__(self):
		Renderer.__init__(self)
		VariableText.__init__(self)
		self.epgcache = eEPGCache.getInstance()

	GUI_WIDGET = eLabel
	def changed(self, what):
		try:
			if what[0] == self.CHANGED_CLEAR:
				self.text = ""
				return
			else:
				event = self.source.event
				if event is None:
					self.text = "N/A"
					return
					return
				try:
					service = self.source.service
				except Exception as e:
					logger.error(f"changed (line 34): {e}")
					import NavigationInstance
					service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
				primetime = "N/A"
				self.text = "N/A"
				if self.epgcache is not None:
					try:
						prime_hour = config.epgselection.graph_primetimehour.value
						prime_minute = config.epgselection.graph_primetimemins.value
					except Exception as e:
						logger.error(f"changed (line 43): {e}")
						prime_hour = 20
						prime_minute = 15
					bt = None
					now = localtime(time())
					dt = datetime(now.tm_year, now.tm_mon, now.tm_mday, prime_hour, prime_minute)
					pt = int(mktime(dt.timetuple()))
					self.epgcache.startTimeQuery(eServiceReference(service.toString()), pt)
					event = self.epgcache.getNextTimeEntry()
					if event and (now.tm_hour <= prime_hour):
						bt = localtime(event.getBeginTime())
						duration = round(event.getDuration() // 60)
						primetime = f"\\c0000??80{bt[3]:02d}:{bt[4]:02d} \\c00??????{event.getEventName()} ({duration}min)"
					else:
						self.text = "N/A"

				self.text = primetime
		except Exception as err:
			from Tools.LiiS8WeatherUpdate import errorlog
			errorlog(err, __file__)
