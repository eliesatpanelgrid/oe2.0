#!/usr/bin/python
# -*- coding: utf-8 -*-
###################################################################
## Original implementation: "Lululla" / AGP Team (AgpEMCBase.py)  ##
## Original modification:   "MNASR"                                ##
## Integrated & adapted for LiiS8 by: LiiS8 Team                   ##
##   - renamed module/constants to fit LiiS8 naming conventions    ##
##   - EMC_ROOT path renamed to /media/hdd/LiiS8EMC                ##
##   - logic itself left untouched (pure filename/regex utilities, ##
##     no Enigma2-API dependency, nothing to adapt functionally)   ##
###################################################################
#
# وحدة أساسية مشتركة لعائلة عرض معلومات EMC (Enhanced Movie Center)
# تحتوي منطق تنظيف أسماء ملفات الأفلام/المسلسلات واستخراج السنة
# ورقم الموسم/الحلقة، بدون أي اعتماد على واجهات Enigma2 نفسها -
# لذلك نُقلت كما هي دون أي تعديل منطقي، فقط إعادة تسمية للمسارات.
#
from __future__ import absolute_import, print_function
import re
from os import makedirs
from os.path import basename, exists, join

EMC_ROOT = "/media/hdd/LiiS8EMC"
EMC_POSTER_FOLDER = join(EMC_ROOT, "poster")
EMC_BACKDROP_FOLDER = join(EMC_ROOT, "backdrop")
EMC_LOGO_FOLDER = join(EMC_ROOT, "logo")
EMC_INFO_FOLDER = join(EMC_ROOT, "info")
EMC_CAST_FOLDER = join(EMC_ROOT, "cast")

VIDEO_EXTENSIONS = (
    ".mp4", ".mkv", ".avi", ".ts", ".mov", ".iso", ".m2ts",
    ".m4v", ".mpeg", ".mpg", ".wmv"
)


def ensure_emc_dirs(root_path=EMC_ROOT):
    root = str(root_path or EMC_ROOT).rstrip("/")
    paths = {
        "root": root,
        "poster": join(root, "poster"),
        "backdrop": join(root, "backdrop"),
        "logo": join(root, "logo"),
        "info": join(root, "info"),
        "cast": join(root, "cast"),
    }
    for path in paths.values():
        if not exists(path):
            makedirs(path, exist_ok=True)
    return paths


def is_video_file(path):
    try:
        lower = str(path or "").lower()
        return any(lower.endswith(ext) for ext in VIDEO_EXTENSIONS)
    except Exception:
        return False


def safe_str(value):
    try:
        return str(value or "")
    except Exception:
        return ""


def extract_emc_year(value):
    try:
        text = safe_str(value)
        m = re.search(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)", text)
        if m:
            return m.group(1)
        m = re.search(r"(?<!\d)(19\d)h(\d)(?!\d)", text, flags=re.IGNORECASE)
        if m:
            return "{}{}".format(m.group(1), m.group(2))
        return ""
    except Exception:
        return ""


def is_emc_episode(value):
    try:
        text = str(value or "")
        if re.search(r"\bS\s*\d{1,2}[\s._-]*E\s*\d{1,3}\b", text, flags=re.IGNORECASE):
            return True
        if re.search(r"\b\d{1,2}x\d{1,3}\b", text, flags=re.IGNORECASE):
            return True
        if re.search(r"\bseason[\s._-]*\d+\b", text, flags=re.IGNORECASE):
            return True
        if re.search(r"\bepisode[\s._-]*\d+\b", text, flags=re.IGNORECASE):
            return True
        return False
    except Exception:
        return False


def extract_emc_episode_marker(value):
    """
    استخراج رقم الموسم/الحلقة الفعلي من اسم/مسار ملف EMC.

    يُعيد:
        ("S02E07", "season 2 episode 7") عند العثور عليه.
        ("", "") إن لم يوجد رقم موسم/حلقة موثوق.

    يُستخدم فقط كإشارة (Hint) لنوع المحتوى (فيلم/مسلسل) عند البحث في TMDB،
    وليس كعنوان بحث بحد ذاته.
    """
    try:
        text = str(value or "")

        m = re.search(r"\bS\s*(\d{1,2})[\s._-]*E\s*(\d{1,3})\b", text, flags=re.IGNORECASE)
        if m:
            season = int(m.group(1))
            episode = int(m.group(2))
            return "S%02dE%02d" % (season, episode), "season %d episode %d" % (season, episode)

        m = re.search(r"\b(\d{1,2})x(\d{1,3})\b", text, flags=re.IGNORECASE)
        if m:
            season = int(m.group(1))
            episode = int(m.group(2))
            return "S%02dE%02d" % (season, episode), "season %d episode %d" % (season, episode)

        m = re.search(
            r"\bseason[\s._-]*(\d{1,2}).*?\bepisode[\s._-]*(\d{1,3})\b",
            text,
            flags=re.IGNORECASE
        )
        if m:
            season = int(m.group(1))
            episode = int(m.group(2))
            return "S%02dE%02d" % (season, episode), "season %d episode %d" % (season, episode)

        if is_emc_episode(text):
            return "S01E01", "season 1 episode 1"

        return "", ""
    except Exception:
        return "", ""


def clean_movie_filename(name):
    """
    تنظيف اسم ملف الفيديو للإبقاء فقط على العنوان الحقيقي + السنة (اختياريًا).

    محافظ عمدًا لأغراض بحث EMC/TMDB:
    - الحلقات تُبحث باسم المسلسل فقط.
    - ملفات الأفلام التي تحوي سنة: يُبقى فقط النص قبل أول سنة + تلك السنة.
    - أسماء الفرق/الترميز/الجودة تُزال من الملفات التي لا تحوي سنة صالحة.
    """
    try:
        original = safe_str(name).strip()

        if not re.search(r"\.(mp4|mkv|avi|ts|mov|iso|m2ts|m4v|mpeg|mpg|wmv)$", original, flags=re.IGNORECASE):
            return ""

        name = re.sub(r"\.(mp4|mkv|avi|ts|mov|iso|m2ts|m4v|mpeg|mpg|wmv)$", "", original, flags=re.IGNORECASE)

        name = re.sub(
            r"^(COCAIN|GECKOS|DRONES|SPARKS|DiAMOND|FGT|ION10|RARBG|YIFY|YTS|ETRG|XVID|MkvCage|ShAaNiG|RUSTED|WAR|GETiT|playSD)-",
            "",
            name,
            flags=re.IGNORECASE
        )

        if re.search(r"\bS\d{1,2}E\d{1,3}\b", name, flags=re.IGNORECASE):
            name = re.sub(r"\bS\d{1,2}E\d{1,3}\b.*$", "", name, flags=re.IGNORECASE)

        name = re.sub(r"[\[\(]\s*((?:19|20)\d{2})\s*[\]\)]", r" \1 ", name)

        name = name.replace("_", " ").replace(".", " ")

        name = re.sub(r"\[[^\]]+\]", " ", name)
        name = re.sub(r"\([^\)]*\)", " ", name)
        name = re.sub(r"\{[^\}]+\}", " ", name)
        name = re.sub(r"\s{2,}", " ", name).strip()

        name = re.sub(r"(?<!\d)(19\d)h(\d)(?!\d)", lambda m: "{}{}".format(m.group(1), m.group(2)), name, flags=re.IGNORECASE)

        year_match = re.search(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)", name)
        if year_match:
            title_part = name[:year_match.start()].strip(" -._")
            title_part = re.sub(r"\b(EXTENDED|REMASTERED|UNRATED|PROPER|REPACK|INTERNAL|LIMITED|FINAL|THEATRICAL|DIRECTORS? CUT|RUSSIAN|Hindi|Arabic Subbed|RoSubbed|Subbed)\b", " ", title_part, flags=re.IGNORECASE)
            title_part = re.sub(r"\bDisc\s*\d+\b", " ", title_part, flags=re.IGNORECASE)
            title_part = re.sub(r"(?<!\d)(19\d)h(\d)(?!\d)", " ", title_part, flags=re.IGNORECASE)
            title_part = re.sub(r"\s{2,}", " ", title_part).strip(" -._")
            year_part = year_match.group(1)
            name = "{} {}".format(title_part, year_part).strip()
        else:
            split_audio_patterns = [
                r"\bAAC\s*[257]\s*[01]\b",
                r"\bDDP\s*[257]\s*[01]\b",
                r"\bDD\s*[257]\s*[01]\b",
                r"\bAC3\s*[257]\s*[01]\b",
                r"\bDTS\s*[257]\s*[01]\b",
                r"\bEAC3\s*[257]\s*[01]\b",
                r"\bTRUEHD\s*[257]\s*[01]\b",
            ]
            for pattern in split_audio_patterns:
                name = re.sub(pattern, " ", name, flags=re.IGNORECASE)

            garbage_patterns = [
                r"\b(480p|576p|720p|1080p|2160p|4K)\b",
                r"\b(WEBRip|WEB[\- ]DL|WEB|BluRay|BRRip|BRRiP|BDRip|DVDRip|DvDrip|HDRip|HDTV|CAM|TS|TC|SCR|AMZN)\b",
                r"\b(Line|LiNE)\b",
                r"\b(x264|x265|h264|h265|H264|H265|HEVC|AVC|XViD|XviD|XVID)\b",
                r"\b(8bit|10bit|10bits|12bit)\b",
                r"\b(HDR|HDR10|DV|Dolby Vision)\b",
                r"\b(AAC|AC3|EAC3|DD|DDP|DTS|TRUEHD|Atmos|MP3)\b",
                r"\b(2CH|6CH|7CH|8CH|Dual Audio)\b",
                r"\b(REPACK|PROPER|INTERNAL|EXTENDED|REMASTERED|UNRATED|REMUX|LIMITED)\b",
                r"\b(Arabic Subbed|RoSubbed|Subbed|Hindi|RUSSIAN|Eng)\b",
                r"\b(\d+(?:\.\d+)?\s*(?:GB|MB))\b",
                r"\b(YTS|YTS AM|YTS AG|YTS LT|YTS MX|YTS BZ|PSA|Rapta|Rapita|GalaxyRG|NeoNoir|RARBG|BONE|Yify|MkvCage|Mkvking|ShAaNiG|GECKOS|DRONES|COCAIN|SPARKS|DiAMOND|FGT|ION10|WAR|RUSTED|ETRG|BOKUTOX|LOKI|aXXo|iExTV|playSD|getit|FiLMEY|akoam|net|Com|ws|WS|AM)\b",
                r"\b(mp4|mkv|avi)\b",
            ]
            for pattern in garbage_patterns:
                name = re.sub(pattern, " ", name, flags=re.IGNORECASE)

        name = re.sub(r"\bakoam\s+net\b", " ", name, flags=re.IGNORECASE)
        name = re.sub(r"\bSpiderMan\b", "Spider Man", name)

        name = re.sub(r"\b(480p|576p|720p|1080p|2160p|4K)\b", " ", name, flags=re.IGNORECASE)
        name = re.sub(r"\b(WEBRip|WEB[\- ]DL|WEB|BluRay|BRRip|BRRiP|BDRip|DVDRip|DvDrip|HDRip|HDTV|AMZN)\b", " ", name, flags=re.IGNORECASE)
        name = re.sub(r"\b(x264|x265|h264|h265|H264|H265|HEVC|AVC|XViD|XviD|XVID|MP3|AAC|AC3|DD|DDP|DTS)\b", " ", name, flags=re.IGNORECASE)
        name = re.sub(r"\b(\d+(?:\.\d+)?\s*(?:GB|MB))\b", " ", name, flags=re.IGNORECASE)
        name = re.sub(r"\b(YTS|PSA|Rapta|Rapita|GalaxyRG|NeoNoir|RARBG|BONE|Yify|MkvCage|Mkvking|ShAaNiG|GECKOS|DRONES|COCAIN|SPARKS|DiAMOND|FGT|ION10|RUSTED|ETRG|BOKUTOX|LOKI|aXXo|iExTV|playSD|getit|FiLMEY|akoam|Com|ws|WS|AM|AG|LT|MX|BZ|rmteam)\b", " ", name, flags=re.IGNORECASE)
        name = re.sub(r"\s+-\s+", " ", name)
        name = name.replace("-", " ")
        name = re.sub(r"\s{2,}", " ", name).strip()

        name = re.sub(
            r"(?<!\d\s)\b(\d+)\s+(\d)\b",
            lambda m: "{}.{}".format(m.group(1), m.group(2)),
            name
        )

        years = re.findall(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)", name)
        keep_year = years[0] if years else ""

        if keep_year:
            body = re.sub(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)", " ", name)
            body = re.sub(r"\s{2,}", " ", body).strip(" -._")
            name = "{} {}".format(body, keep_year).strip()
        else:
            name = re.sub(r"\s{2,}", " ", name).strip(" -._")

        junk_only = set([
            "rarbg", "com", "www", "sample", "trailer", "yts", "psa", "mkv", "mp4", "avi"
        ])
        words = [w.lower() for w in re.findall(r"[A-Za-z0-9]+", name)]
        if words and all(w in junk_only for w in words):
            return ""

        return name

    except Exception:
        return ""


def build_emc_search_title(movie_path, keep_year=False):
    raw = basename(safe_str(movie_path))
    cleaned = clean_movie_filename(raw)
    if not cleaned:
        return ""

    if keep_year:
        return cleaned

    cleaned = re.sub(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)$", "", cleaned).strip()
    cleaned = re.sub(r"\s{2,}", " ", cleaned).strip()
    return cleaned
