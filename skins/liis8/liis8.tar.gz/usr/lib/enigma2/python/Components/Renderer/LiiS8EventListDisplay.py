# LiiS8EventListDisplay 
#!/usr/bin/python
# -*- coding: utf-8 -*-



#<widget source="ServiceEvent" render="LiiS8EventListDisplay" position="970,670" size="920,280" backgroundColor="buttonsc" column0="10,200,yellow,Regular,30,0,0" column1="210,710,white,Regular,30,1,1" primetimeoffset="0" rowHeight="35" transparent="1" zPosition="50"><convert type="iEventList">primetime=yes,eventcount=8</convert></widget>

from __future__ import absolute_import
from Components.Renderer.Renderer import Renderer
from enigma import eCanvas, eRect, gFont
from skin import parseColor


class LiiS8EventListDisplay(Renderer):

    GUI_WIDGET = eCanvas

    def __init__(self):
        Renderer.__init__(self)
        self.backgroundColor = parseColor("#ff000000")
        self.rowHeight = 20
        self.columns = {}
        self.primetimeoffset = 10

    def pull_updates(self):
        if self.instance is None:
            return
        self.instance.clear(self.backgroundColor)
        content = self.source.getContent()
        content_count = len(content)
        primetime = self.source.primetime
        if primetime == 1 and content_count == 1:
            primetime = 0
        y = 0
        a = 1
        for item in content:
            i = 0
            while i < 3:
                if str(i) in self.columns:
                    value = self.columns[str(i)]
                    self.instance.writeText(eRect(value[0], y + int((self.rowHeight - value[4]) / 2), value[1], self.rowHeight), value[2], self.backgroundColor, value[3], item[value[5]], value[6])
                i += 1
            a += 1
            y += self.rowHeight
            if a == content_count and primetime == 1:
                y += self.primetimeoffset

    def changed(self, what):
        self.pull_updates()

    def applySkin(self, desktop, parent):
        attribs = []
        from enigma import eSize

        def parseSize(str):
            x, y = str.split(',')
            return eSize(int(x), int(y))

        def parseColumnValue(value):
            x, length, color, fontname, fontheight, align, itemindex = value.split(',')
            return (int(x), int(length), parseColor(color), gFont(fontname, int(fontheight)), int(fontheight), int(itemindex), int(align))

        for (attrib, value) in self.skinAttributes:
            if attrib == "size":
                self.instance.setSize(parseSize(value))
                attribs.append((attrib, value))
            elif attrib == "column0":
                self.columns["0"] = parseColumnValue(value)
            elif attrib == "column1":
                self.columns["1"] = parseColumnValue(value)
            elif attrib == "column2":
                self.columns["2"] = parseColumnValue(value)
            elif attrib == "rowHeight":
                self.rowHeight = int(value)
            elif attrib == "primetimeoffset":
                self.primetimeoffset = int(value)
            elif attrib == "backgroundColor":
                self.backgroundColor = parseColor(value)
                self.instance.clear(self.backgroundColor)
                attribs.append((attrib, value))
            else:
                attribs.append((attrib, value))
        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)
