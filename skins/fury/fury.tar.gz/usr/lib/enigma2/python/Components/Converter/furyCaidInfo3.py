from Components.Converter.Converter import Converter
from enigma import iServiceInformation
from Tools.Directories import fileExists
from Components.Element import cached
from Components.Converter.Poll import Poll
import os
import sys
import threading
import time

info = {}
old_ecm_mtime = None

# ---------------------------------------------------------------------------
# Shared asynchronous ECM cache
#
# All filesystem access and ECM parsing happens in one daemon thread.  The
# converter's getText/getBoolean methods only read a small in-memory snapshot,
# so opening the InfoBar cannot be delayed by a busy HDD/flash filesystem.
# This keeps the original converter names, output formats and skin usage.
# ---------------------------------------------------------------------------
_ECM_LOCK = threading.RLock()
_ECM_CACHE = {}
_ECM_ACTIVE_PATH = ""
_ECM_SIGNATURE = None
_ECM_LAST_OK = 0.0
_ECM_WORKER_STARTED = False
_ECM_POLL_SECONDS = 0.75
_ECM_CLEAR_GRACE_SECONDS = 2.0
_ECM_RESCAN_SECONDS = 4.0
_ECM_NEXT_RESCAN = 0.0


def _ecm_candidate_paths():
    # /tmp/ecm.info is the traditional path and remains first for identical
    # behaviour.  Extra paths cover multi-tuner and OSCam/NCam variants used by
    # OpenATV, OpenPLi, OpenViX, OpenBH, DreamOS and related images.
    paths = ["/tmp/ecm.info", "/tmp/ecm0.info"]
    paths.extend(["/tmp/ecm%d.info" % n for n in range(1, 8)])
    paths.extend([
        "/tmp/.oscam/ecm.info",
        "/tmp/.ncam/ecm.info",
        "/var/volatile/tmp/ecm.info",
    ])
    return paths


def _stat_nonempty(path):
    if not path:
        return None
    try:
        st = os.stat(path)
        if int(getattr(st, "st_size", 0) or 0) > 0:
            return st
    except Exception:
        pass
    return None


def _shared_access_path():
    """Reuse fury2Access' already discovered path when that converter is loaded."""
    try:
        module = sys.modules.get("Components.Converter.fury2Access")
        if module is None:
            module = sys.modules.get("fury2Access")
        if module is not None:
            lock = getattr(module, "_FURY_ECM_LOCK", None)
            if lock is not None:
                with lock:
                    return getattr(module, "_FURY_ECM_PATH", "") or ""
    except Exception:
        pass
    return ""


def _select_ecm_path():
    """Return (path, stat) without rescanning every possible path each cycle."""
    global _ECM_NEXT_RESCAN
    now = time.time()

    # If fury2Access is active, it already did the expensive multi-path search.
    shared = _shared_access_path()
    if shared:
        st = _stat_nonempty(shared)
        if st is not None:
            _ECM_NEXT_RESCAN = now + _ECM_RESCAN_SECONDS
            return shared, st

    current = ""
    try:
        with _ECM_LOCK:
            current = _ECM_ACTIVE_PATH or ""
            next_scan = float(_ECM_NEXT_RESCAN or 0.0)
    except Exception:
        next_scan = 0.0

    if current and now < next_scan:
        st = _stat_nonempty(current)
        if st is not None:
            return current, st

    try:
        for candidate in _ecm_candidate_paths():
            st = _stat_nonempty(candidate)
            if st is not None:
                _ECM_NEXT_RESCAN = now + _ECM_RESCAN_SECONDS
                return candidate, st
    except Exception:
        pass

    _ECM_NEXT_RESCAN = now + 1.5
    return "", None


def _file_signature(path, st):
    try:
        stamp = getattr(st, "st_mtime_ns", None)
        if stamp is None:
            stamp = int(float(st.st_mtime) * 1000.0)
        return (path, int(stamp), int(st.st_size))
    except Exception:
        return (path, 0, 0)


def _parse_ecm_lines(lines):
    # Same parsing rules as the original ecmfile() implementation.
    parsed = {}
    for line in (lines or []):
        try:
            x = line.lower().find("msec")
            if x != -1:
                parsed["ecm time"] = line[0:x + 4]
                continue

            item = line.split(":", 1)
            if len(item) > 1:
                if item[0] == "Provider":
                    item[0] = "prov"
                    item[1] = item[1].strip()[2:]
                elif item[0] == "ECM PID":
                    item[0] = "pid"
                elif item[0] == "response time":
                    parsed["source"] = "net"
                    it_tmp = item[1].strip().split(" ")
                    if it_tmp:
                        parsed["ecm time"] = "%s msec" % it_tmp[0]
                        y = it_tmp[-1].find("[")
                        if y != -1:
                            parsed["server"] = it_tmp[-1][:y]
                            parsed["protocol"] = it_tmp[-1][y + 1:-1]
                        y = it_tmp[-1].find("(")
                        if y != -1:
                            endpoint = it_tmp[-1].split("(")[-1].rstrip(")")
                            if ":" in endpoint:
                                parsed["server"] = endpoint.split(":", 1)[0]
                                parsed["port"] = endpoint.split(":", 1)[1]
                        elif y == -1:
                            item[0] = "source"
                            item[1] = "sci"
                        low_last = it_tmp[-1].lower()
                        if ("emu" in low_last or "cache" in low_last or
                                "card" in low_last or "biss" in low_last):
                            item[0] = "source"
                            item[1] = "emu"
                elif item[0] == "hops":
                    item[1] = item[1].strip("\n")
                elif item[0] == "system":
                    item[1] = item[1].strip("\n")
                elif item[0] == "provider":
                    item[1] = item[1].strip("\n")
                elif item[0][:2] == "cw" or item[0] == "ChID" or item[0] == "Service":
                    continue
                elif item[0] == "source":
                    if item[1].strip()[:3] == "net":
                        it_tmp = item[1].strip().split(" ")
                        if len(it_tmp) > 1:
                            parsed["protocol"] = it_tmp[1][1:]
                        try:
                            endpoint = it_tmp[-1]
                            if ":" in endpoint:
                                parsed["server"] = endpoint.split(":", 1)[0]
                                parsed["port"] = endpoint.split(":", 1)[1][:-1]
                        except Exception:
                            pass
                        item[1] = "net"
                elif item[0] == "prov":
                    y = item[1].find(",")
                    if y != -1:
                        item[1] = item[1][:y]
                elif item[0] == "reader":
                    if item[1].strip() == "emu":
                        item[0] = "source"
                elif item[0] == "from":
                    if item[1].strip() == "local":
                        item[1] = "sci"
                        item[0] = "source"
                    else:
                        parsed["source"] = "net"
                        item[0] = "server"
                elif item[0] == "provid":
                    item[0] = "prov"
                elif item[0] == "using":
                    if item[1].strip() == "emu" or item[1].strip() == "sci":
                        item[0] = "source"
                    else:
                        parsed["source"] = "net"
                        item[0] = "protocol"
                elif item[0] == "address":
                    tt = item[1].find(":")
                    if tt != -1:
                        parsed["server"] = item[1][:tt].strip()
                        item[0] = "port"
                        item[1] = item[1][tt + 1:]
                parsed[item[0].strip().lower()] = item[1].strip()
            else:
                # Preserve the original one-line CAID/PID fallbacks.
                if "caid" not in parsed and "CaID" not in parsed:
                    x = line.lower().find("caid")
                    if x != -1:
                        y = line.find(",")
                        if y != -1:
                            parsed["caid"] = line[x + 5:y]
                if "pid" not in parsed:
                    x = line.lower().find("pid")
                    if x != -1:
                        y = line.find(" =")
                        z = line.find(" *")
                        if y != -1:
                            parsed["pid"] = line[x + 4:y]
                        elif z != -1:
                            parsed["pid"] = line[x + 4:z]
        except Exception:
            continue
    return parsed


def _ecm_cache_worker():
    global info, old_ecm_mtime
    global _ECM_CACHE, _ECM_ACTIVE_PATH, _ECM_SIGNATURE, _ECM_LAST_OK, _ECM_NEXT_RESCAN
    while True:
        try:
            path, st = _select_ecm_path()
            if path and st is not None:
                sig = _file_signature(path, st)
                with _ECM_LOCK:
                    previous_sig = _ECM_SIGNATURE
                if sig != previous_sig:
                    parsed = None
                    try:
                        f = open(path, "r")
                        try:
                            lines = f.readlines()
                        finally:
                            f.close()
                        parsed = _parse_ecm_lines(lines)
                    except Exception:
                        parsed = None
                    if parsed is not None:
                        with _ECM_LOCK:
                            _ECM_CACHE = parsed
                            _ECM_ACTIVE_PATH = path
                            _ECM_SIGNATURE = sig
                            _ECM_LAST_OK = time.time()
                            info = dict(parsed)
                            old_ecm_mtime = st.st_mtime
                else:
                    with _ECM_LOCK:
                        _ECM_ACTIVE_PATH = path
                        _ECM_LAST_OK = time.time()
            else:
                with _ECM_LOCK:
                    if (time.time() - float(_ECM_LAST_OK or 0.0)) >= _ECM_CLEAR_GRACE_SECONDS:
                        _ECM_CACHE = {}
                        _ECM_ACTIVE_PATH = ""
                        _ECM_SIGNATURE = None
                        _ECM_NEXT_RESCAN = 0.0
                        info = {}
                        old_ecm_mtime = None
        except Exception:
            pass
        try:
            time.sleep(_ECM_POLL_SECONDS)
        except Exception:
            pass


def _start_ecm_worker():
    global _ECM_WORKER_STARTED
    if _ECM_WORKER_STARTED:
        return
    try:
        worker = threading.Thread(target=_ecm_cache_worker, name="fury-caid-ecm-cache")
        try:
            worker.daemon = True
        except Exception:
            worker.setDaemon(True)
        worker.start()
        _ECM_WORKER_STARTED = True
    except Exception:
        _ECM_WORKER_STARTED = False


def _ecm_snapshot():
    try:
        with _ECM_LOCK:
            return dict(_ECM_CACHE)
    except Exception:
        return {}


def _ecm_available():
    try:
        with _ECM_LOCK:
            return bool(_ECM_ACTIVE_PATH and _ECM_CACHE)
    except Exception:
        return False


_start_ecm_worker()

class furyCaidInfo3(Poll, Converter, object):
    CAID = 0
    PID = 1
    PROV = 2
    ALL = 3
    IS_NET = 4
    IS_EMU = 5
    CRYPT = 6
    BETA = 7
    CONAX = 8
    CRW = 9
    DRE = 10
    IRD = 11
    NAGRA = 12
    NDS = 13
    SECA = 14
    VIA = 15
    BETA_C = 16
    CONAX_C = 17
    CRW_C = 18
    DRE_C = 19
    IRD_C = 20
    NAGRA_C = 21
    NDS_C = 22
    SECA_C = 23
    VIA_C = 24
    BISS = 25
    BISS_C = 26
    EXS = 27
    EXS_C = 28
    HOST = 29
    DELAY = 30
    FORMAT = 31
    CRYPT2 = 32
    CRD = 33
    CRDTXT = 34
    SHORT = 35
    my_interval = 1000

    def __init__(self, type):
        _start_ecm_worker()
        Poll.__init__(self)
        Converter.__init__(self, type)
        if type == 'CAID':
            self.type = self.CAID
        elif type == 'PID':
            self.type = self.PID
        elif type == 'ProvID':
            self.type = self.PROV
        elif type == 'Delay':
            self.type = self.DELAY
        elif type == 'Host':
            self.type = self.HOST
        elif type == 'Net':
            self.type = self.IS_NET
        elif type == 'Emu':
            self.type = self.IS_EMU
        elif type == 'CryptInfo':
            self.type = self.CRYPT
        elif type == 'CryptInfo2':
            self.type = self.CRYPT2
        elif type == 'BetaCrypt':
            self.type = self.BETA
        elif type == 'ConaxCrypt':
            self.type = self.CONAX
        elif type == 'CrwCrypt':
            self.type = self.CRW
        elif type == 'DreamCrypt':
            self.type = self.DRE
        elif type == 'ExsCrypt':
            self.type = self.EXS
        elif type == 'IrdCrypt':
            self.type = self.IRD
        elif type == 'NagraCrypt':
            self.type = self.NAGRA
        elif type == 'NdsCrypt':
            self.type = self.NDS
        elif type == 'SecaCrypt':
            self.type = self.SECA
        elif type == 'ViaCrypt':
            self.type = self.VIA
        elif type == 'BetaEcm':
            self.type = self.BETA_C
        elif type == 'ConaxEcm':
            self.type = self.CONAX_C
        elif type == 'CrwEcm':
            self.type = self.CRW_C
        elif type == 'DreamEcm':
            self.type = self.DRE_C
        elif type == 'ExsEcm':
            self.type = self.EXS_C
        elif type == 'IrdEcm':
            self.type = self.IRD_C
        elif type == 'NagraEcm':
            self.type = self.NAGRA_C
        elif type == 'NdsEcm':
            self.type = self.NDS_C
        elif type == 'SecaEcm':
            self.type = self.SECA_C
        elif type == 'ViaEcm':
            self.type = self.VIA_C
        elif type == 'BisCrypt':
            self.type = self.BISS
        elif type == 'BisEcm':
            self.type = self.BISS_C
        elif type == 'Crd':
            self.type = self.CRD
        elif type == 'CrdTxt':
            self.type = self.CRDTXT
        elif type == 'Short':
            self.type = self.SHORT
        elif type == 'Default' or type == '' or type == None or type == '%':
            self.type = self.ALL
        else:
            self.type = self.FORMAT
            self.sfmt = type[:]
        self.systemTxtCaids = {'26': 'BiSS',
         '01': 'Seca Mediaguard',
         '06': 'Irdeto',
         '17': 'BetaCrypt',
         '05': 'Viacces',
         '18': 'Nagravision',
         '09': 'NDS-Videoguard',
         '0B': 'Conax',
         '0D': 'Cryptoworks',
         '4A': 'DRE-Crypt',
         '27': 'ExSet',
         '0E': 'PowerVu',
         '22': 'Codicrypt',
         '07': 'DigiCipher',
         '56': 'Verimatrix',
         '7B': 'DRE-Crypt',
         'A1': 'Rosscrypt'}
        self.systemCaids = {'26': 'BiSS',
         '01': 'SEC',
         '06': 'IRD',
         '17': 'BET',
         '05': 'VIA',
         '18': 'NAG',
         '09': 'NDS',
         '0B': 'CON',
         '0D': 'CRW',
         '27': 'EXS',
         '7B': 'DRE',
         '4A': 'DRE'}
        self.poll_interval = self.my_interval
        self.poll_enabled = True
        return

    @cached
    def getBoolean(self):
        service = self.source.service
        info = service and service.info()
        if not info:
            return False
        else:
            caids = info.getInfoObject(iServiceInformation.sCAIDs)
            if caids:
                if self.type == self.SECA:
                    for caid in caids:
                        if ('%0.4X' % int(caid))[:2] == '01':
                            return True

                    return False
                if self.type == self.BETA:
                    for caid in caids:
                        if ('%0.4X' % int(caid))[:2] == '17':
                            return True

                    return False
                if self.type == self.CONAX:
                    for caid in caids:
                        if ('%0.4X' % int(caid))[:2] == '0B':
                            return True

                    return False
                if self.type == self.CRW:
                    for caid in caids:
                        if ('%0.4X' % int(caid))[:2] == '0D':
                            return True

                    return False
                if self.type == self.DRE:
                    for caid in caids:
                        if ('%0.4X' % int(caid))[:2] == '7B' or ('%0.4X' % int(caid))[:2] == '4A':
                            return True

                    return False
                if self.type == self.EXS:
                    for caid in caids:
                        if ('%0.4X' % int(caid))[:2] == '27':
                            return True

                if self.type == self.NAGRA:
                    for caid in caids:
                        if ('%0.4X' % int(caid))[:2] == '18':
                            return True

                    return False
                if self.type == self.NDS:
                    for caid in caids:
                        if ('%0.4X' % int(caid))[:2] == '09':
                            return True

                    return False
                if self.type == self.IRD:
                    for caid in caids:
                        if ('%0.4X' % int(caid))[:2] == '06':
                            return True

                    return False
                if self.type == self.VIA:
                    for caid in caids:
                        if ('%0.4X' % int(caid))[:2] == '05':
                            return True

                    return False
                if self.type == self.BISS:
                    for caid in caids:
                        if ('%0.4X' % int(caid))[:2] == '26':
                            return True

                    return False
                ecm_info = self.ecmfile()
                if ecm_info:
                    caid = ('%0.4X' % int(ecm_info.get('caid', ''), 16))[:2]
                    if self.type == self.SECA_C:
                        if caid == '01':
                            return True
                        return False
                    if self.type == self.BETA_C:
                        if caid == '17':
                            return True
                        return False
                    if self.type == self.CONAX_C:
                        if caid == '0B':
                            return True
                        return False
                    if self.type == self.CRW_C:
                        if caid == '0D':
                            return True
                        return False
                    if self.type == self.DRE_C:
                        if caid == '4A' or caid == '7B':
                            return True
                        return False
                    if self.type == self.EXS_C:
                        if caid == '27':
                            return True
                        return False
                    if self.type == self.NAGRA_C:
                        if caid == '18':
                            return True
                        return False
                    if self.type == self.NDS_C:
                        if caid == '09':
                            return True
                        return False
                    if self.type == self.IRD_C:
                        if caid == '06':
                            return True
                        return False
                    if self.type == self.VIA_C:
                        if caid == '05':
                            return True
                        return False
                    if self.type == self.BISS_C:
                        if caid == '26':
                            return True
                        return False
                    reader = ecm_info.get('reader', None)
                    using = ecm_info.get('using', '')
                    source = ecm_info.get('source', '')
                    if self.type == self.CRD:
                        if source == 'sci':
                            return True
                        if source != 'cache' and source != 'net' and source.find('emu') == -1:
                            return True
                        return False
                    source = ecm_info.get('source', '')
                    if self.type == self.IS_EMU:
                        return using == 'emu' or source == 'emu' or source == 'card' or reader == 'emu' or source.find('card') > -1 or source.find('emu') > -1 or source.find('biss') > -1 or source.find('cache') > -1
                    source = ecm_info.get('source', '')
                    if self.type == self.IS_NET:
                        if using == 'CCcam-s2s':
                            return 1
                        if source != 'cache' and source == 'net' and source.find('emu') == -1:
                            return True
                    else:
                        return False
            return False

    boolean = property(getBoolean)

    @cached
    def getText(self):
        textvalue = ''
        server = ''
        service = self.source.service
        if service:
            if self.type == self.CRYPT2:
                ecm_info = self.ecmfile()
                if _ecm_available():
                    try:
                        caid = '%0.4X' % int(ecm_info.get('caid', ''), 16)
                        return '%s' % self.systemTxtCaids.get(caid[:2])
                    except:
                        return 'nondecode'

                else:
                    return 'nondecode'
        if service:
            info = service and service.info()
            if info:
                if info.getInfoObject(iServiceInformation.sCAIDs):
                    ecm_info = self.ecmfile()
                    if ecm_info:
                        caid = '%0.4X' % int(ecm_info.get('caid', ''), 16)
                        if self.type == self.CAID:
                            return caid
                        if self.type == self.CRYPT:
                            return '%s' % self.systemTxtCaids.get(caid[:2].upper())
                        try:
                            pid = '%0.4X' % int(ecm_info.get('pid', ''), 16)
                        except:
                            pid = ''

                        if self.type == self.PID:
                            return pid
                        try:
                            prov = '%0.6X' % int(ecm_info.get('prov', ''), 16)
                        except:
                            prov = ecm_info.get('prov', '')

                        if self.type == self.PROV:
                            return prov
                        if ecm_info.get('ecm time', '').find('msec') > -1:
                            ecm_time = ecm_info.get('ecm time', '')
                        else:
                            ecm_time = ecm_info.get('ecm time', '').replace('.', '').lstrip('0') ########msec####
                        if self.type == self.DELAY:
                            return ecm_time
                        protocol = ecm_info.get('protocol', '')
                        port = ecm_info.get('port', '')
                        source = ecm_info.get('source', '')
                        server = ecm_info.get('server', '')
                        hops = ecm_info.get('hops', '')
                        system = ecm_info.get('system', '')
                        provider = ecm_info.get('provider', '')
                        reader = ecm_info.get('reader', '')
                        if self.type == self.CRDTXT:
                            info_card = 'False'
                            if source == 'sci':
                                info_card = 'True'
                            if source != 'cache' and source != 'net' and source.find('emu') == -1:
                                info_card = 'True'
                            return info_card
                        if self.type == self.HOST:
                            return server
                        if self.type == self.FORMAT:
                            textvalue = ''
                            params = self.sfmt.split(' ')
                            for param in params:
                                if param != '':
                                    if param[0] != '%':
                                        textvalue += param
                                    elif param == '%S':
                                        textvalue += server
                                    elif param == '%H':
                                        textvalue += hops
                                    elif param == '%SY':
                                        textvalue += system
                                    elif param == '%PV':
                                        textvalue += provider
                                    elif param == '%SP':
                                        textvalue += port
                                    elif param == '%PR':
                                        textvalue += protocol
                                    elif param == '%C':
                                        textvalue += caid
                                    elif param == '%P':
                                        textvalue += pid
                                    elif param == '%p':
                                        textvalue += prov
                                    elif param == '%O':
                                        textvalue += source
                                    elif param == '%R':
                                        textvalue += reader
                                    elif param == '%T':
                                        textvalue += ecm_time
                                    elif param == '%t':
                                        textvalue += '\t'
                                    elif param == '%n':
                                        textvalue += '\n'
                                    elif param[1:].isdigit():
                                        textvalue = textvalue.ljust(len(textvalue) + int(param[1:]))
                                    if len(textvalue) > 0:
                                        if textvalue[-1] != '\t' and textvalue[-1] != '\n':
                                            textvalue += ' '

                            return textvalue[:-1]
                        if self.type == self.ALL:
                            if source == 'emu':
                                textvalue = '%s - %s (Prov: %s, Caid: %s)' % (source,
                                 self.systemTxtCaids.get(caid[:2]),
                                 prov,
                                 caid)
                            elif reader != '' and source == 'net' and port != '':
                                textvalue = '%s - Prov: %s, Caid: %s, Reader: %s, %s (%s:%s) - %s' % (source,
                                 prov,
                                 caid,
                                 reader,
                                 protocol,
                                 server,
                                 port,
                                 ecm_time.replace('msec', 'ms'))
                            elif reader != '' and source == 'net':
                                textvalue = '%s - Prov: %s, Caid: %s, Reader: %s, %s (%s) - %s' % (source,
                                 prov,
                                 caid,
                                 reader,
                                 protocol,
                                 server,
                                 ecm_time.replace('msec', 'ms'))
                            elif reader != '' and source != 'net':
                                textvalue = '%s - Prov: %s, Caid: %s, Reader: %s, %s (local) - %s' % (source,
                                 prov,
                                 caid,
                                 reader,
                                 protocol,
                                 ecm_time.replace('msec', 'ms'))
                            elif server == '' and port == '' and protocol != '':
                                textvalue = '%s - Prov: %s, Caid: %s, %s - %s' % (source,
                                 prov,
                                 caid,
                                 protocol,
                                 ecm_time.replace('msec', 'ms'))
                            elif server == '' and port == '' and protocol == '':
                                textvalue = '%s - Prov: %s, Caid: %s - %s' % (source,
                                 prov,
                                 caid,
                                 ecm_time.replace('msec', 'ms'))
                            else:
                                try:
                                    textvalue = '%s - Prov: %s, Caid: %s, %s (%s:%s) - %s' % (source,
                                     prov,
                                     caid,
                                     protocol,
                                     server,
                                     port,
                                     ecm_time.replace('msec', 'ms'))
                                except:
                                    pass

                        if self.type == self.SHORT:
                            if source == 'emu':
                                textvalue = '%s - %s (Prov: %s, Caid: %s)' % (source,
                                 self.systemTxtCaids.get(caid[:2]),
                                 prov,
                                 caid)
                            elif server == '' and port == '':
                                textvalue = '%s - Prov: %s, Caid: %s - %s' % (source,
                                 prov,
                                 caid,
                                 ecm_time.replace('msec', 'ms'))
                            else:
                                try:
                                    textvalue = '%s - Prov: %s, Caid: %s, %s:%s - %s' % (source,
                                     prov,
                                     caid,
                                     server,
                                     port,
                                     ecm_time.replace('msec', 'ms'))
                                except:
                                    pass

                    elif self.type == self.ALL or self.type == self.SHORT or self.type == self.FORMAT and self.sfmt.count('%') > 3:
                        textvalue = 'No parse cannot emu'
                elif self.type == self.ALL or self.type == self.SHORT or self.type == self.FORMAT and self.sfmt.count('%') > 3:
                    textvalue = 'Free-to-air'
        return textvalue

    text = property(getText)

    def ecmfile(self):
        """Return the latest parsed ECM snapshot without touching the filesystem."""
        return _ecm_snapshot()

    def changed(self, what):
        Converter.changed(self, (self.CHANGED_POLL,))