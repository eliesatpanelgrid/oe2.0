#!/usr/bin/python
# -*- coding: utf-8 -*-

# by digiteng
# v1 07.2020, 11.2021
# recode from lululla 2022
# for channellist
# <widget source="ServiceEvent" render="furyStarX" position="750,390" size="200,20" alphatest="blend" transparent="1" zPosition="3" />
# or
# <widget source="ServiceEvent" render="furyStarX" pixmap="xtra/star.png" position="750,390" size="200,20" alphatest="blend" transparent="1" zPosition="3" />
# edit lululla 05-2022
# <ePixmap pixmap="oZeta-FHD/star.png" position="136,104" size="200,20" alphatest="blend" zPosition="10" transparent="1" />
# <widget source="session.Event_Now" render="furyStarX" pixmap="oZeta-FHD/menu/staryellow.png" position="560,367" size="200,20" alphatest="blend" transparent="1" zPosition="3" />
# <ePixmap pixmap="menu/stargrey.png" position="136,104" size="200,20" alphatest="blend" zPosition="10" transparent="1" />
# <widget source="session.Event_Next" render="furyStarX" pixmap="oZeta-FHD/menu/staryellow.png" position="560,367" size="200,20" alphatest="blend" transparent="1" zPosition="3" />

from __future__ import print_function

from Components.Renderer.Renderer import Renderer
from Components.VariableValue import VariableValue
from Components.config import config
from enigma import eSlider, eTimer

import json
import os
import socket
import sys
import threading
import time

from .furyConverlibr import convtext, quoteEventName


global cur_skin, my_cur_skin, tmdb_api

PY3 = sys.version_info[0] >= 3
if PY3:
    from urllib.request import urlopen
    from urllib.error import HTTPError, URLError
else:
    from urllib2 import urlopen
    from urllib2 import HTTPError, URLError


try:
    lng = config.osd.language.value
    lng = lng[:-3]
except Exception:
    lng = "en"

print("language: ", lng)


formatImg = "w185"
tmdb_api = "3c3efcf47c3577558812bb9d64019d65"
omdb_api = "cb1d9f55"
thetvdbkey = "D19315B88B2DE21F"

# One short TMDB request only. The old renderer performed two blocking
# requests directly from changed()/infos() on the Enigma2 GUI thread.
TMDB_TIMEOUT = 3.0
MEMORY_CACHE_TTL = 12 * 60 * 60
MEMORY_CACHE_LIMIT = 200

_memory_cache = {}
_memory_cache_order = []
_memory_cache_lock = threading.Lock()


def _to_text(value):
    if value is None:
        return ""
    try:
        if PY3:
            if isinstance(value, bytes):
                return value.decode("utf-8", "ignore")
            return str(value)
        try:
            if isinstance(value, unicode):  # noqa: F821
                return value
        except Exception:
            pass
        if isinstance(value, str):
            try:
                return value.decode("utf-8", "ignore")
            except Exception:
                return value
        return str(value)
    except Exception:
        return ""


def _memory_cache_get(key):
    try:
        now = time.time()
        with _memory_cache_lock:
            item = _memory_cache.get(key)
            if not item:
                return None
            ts, data = item
            if now - float(ts or 0) > MEMORY_CACHE_TTL:
                try:
                    del _memory_cache[key]
                except Exception:
                    pass
                return None
            return dict(data or {})
    except Exception:
        return None


def _memory_cache_put(key, data):
    try:
        with _memory_cache_lock:
            _memory_cache[key] = (time.time(), dict(data or {}))
            try:
                _memory_cache_order.remove(key)
            except Exception:
                pass
            _memory_cache_order.append(key)
            while len(_memory_cache_order) > MEMORY_CACHE_LIMIT:
                old_key = _memory_cache_order.pop(0)
                try:
                    del _memory_cache[old_key]
                except Exception:
                    pass
    except Exception:
        pass


def isMountedInRW(mount_point):
    try:
        with open("/proc/mounts", "r") as f:
            for line in f:
                parts = line.split()
                if len(parts) > 1 and parts[1] == mount_point:
                    return True
    except Exception:
        pass
    return False


my_cur_skin = False
cur_skin = config.skin.primary_skin.value.replace("/skin.xml", "")

path_folder = "/tmp/poster"
if os.path.exists("/media/hdd"):
    if isMountedInRW("/media/hdd"):
        path_folder = "/media/hdd/poster"
elif os.path.exists("/media/usb"):
    if isMountedInRW("/media/usb"):
        path_folder = "/media/usb/poster"
elif os.path.exists("/media/mmc"):
    if isMountedInRW("/media/mmc"):
        path_folder = "/media/mmc/poster"

try:
    if not os.path.exists(path_folder):
        os.makedirs(path_folder)
except Exception as e:
    print("Unable to create rating cache folder:", e)
    path_folder = "/tmp/poster"
    try:
        if not os.path.exists(path_folder):
            os.makedirs(path_folder)
    except Exception:
        pass


try:
    if my_cur_skin is False:
        skin_paths = {
            "tmdb_api": "/usr/share/enigma2/{}/tmdbkey".format(cur_skin),
            "omdb_api": "/usr/share/enigma2/{}/omdbkey".format(cur_skin),
            "thetvdbkey": "/usr/share/enigma2/{}/thetvdbkey".format(cur_skin)
        }
        for key, path in skin_paths.items():
            if os.path.exists(path):
                with open(path, "r") as f:
                    value = f.read().strip()
                    if key == "tmdb_api":
                        tmdb_api = value
                    elif key == "omdb_api":
                        omdb_api = value
                    elif key == "thetvdbkey":
                        thetvdbkey = value
                my_cur_skin = True
except Exception as e:
    print("Errore nel caricamento delle API:", str(e))
    my_cur_skin = False


def intCheck():
    """
    Compatibility helper kept for external imports.

    The renderer no longer calls this from __init__, because the old Google
    connectivity test blocked the GUI for up to five seconds.
    """
    response = None
    try:
        response = urlopen("http://google.com", None, 3)
        return True
    except (HTTPError, URLError, socket.timeout):
        return False
    except Exception:
        return False
    finally:
        try:
            if response is not None:
                response.close()
        except Exception:
            pass


class furyStarX(VariableValue, Renderer):

    GUI_WIDGET = eSlider

    def __init__(self):
        Renderer.__init__(self)
        VariableValue.__init__(self)

        self.__start = 0
        self.__end = 100
        self.text = ""

        # Generation/pending state makes every old-channel result harmless.
        # There is only one worker per renderer instance.
        self._state_lock = threading.Lock()
        self._generation = 0
        self._pending = None
        self._result = None
        self._worker = None
        self._destroyed = False
        self._last_event_key = None

        # GUI timer polls the worker result. The background thread never
        # touches eSlider or any Enigma2 widget.
        self._result_timer = eTimer()
        self._result_timer.callback.append(self._poll_result)

    def postWidgetCreate(self, instance):
        instance.setRange(self.__start, self.__end)

    def preWidgetRemove(self, instance):
        try:
            with self._state_lock:
                self._destroyed = True
                self._generation += 1
                self._pending = None
                self._result = None
        except Exception:
            pass
        try:
            self._result_timer.stop()
        except Exception:
            pass
        try:
            self._result_timer.callback.remove(self._poll_result)
        except Exception:
            pass
        self._result_timer = None

    def changed(self, what):
        if what[0] == self.CHANGED_CLEAR:
            try:
                with self._state_lock:
                    self._generation += 1
                    self._pending = None
                    self._result = None
            except Exception:
                pass
            self._last_event_key = None
            try:
                (self.range, self.value) = ((0, 1), 0)
            except Exception:
                pass
            if self.instance:
                self.instance.hide()
            return

        if self.instance:
            self.instance.hide()
        self.infos()

    def _normalise_event_name(self, name):
        text = _to_text(name)
        text = text.replace("\xc2\x86", "").replace("\xc2\x87", "")
        return text.strip()

    def infos(self):
        try:
            event = self.source.event
            if not event:
                return

            event_name = self._normalise_event_name(event.getEventName())
            if not event_name:
                return

            cache_key = convtext(event_name)
            if not cache_key:
                print("Evento non trovato per la visualizzazione del poster")
                return

            # Duplicate source updates are common when the InfoBar opens.
            if cache_key == self._last_event_key:
                cached = _memory_cache_get(cache_key)
                if cached is not None:
                    self.process_data(cached)
                return

            self._last_event_key = cache_key
            cache_file = "%s/%s" % (path_folder, cache_key)

            # Fast RAM cache first.
            data = _memory_cache_get(cache_key)
            if data is not None:
                self.process_data(data)
                return

            # Small local JSON cache is safe and avoids every network request.
            if os.path.exists(cache_file):
                try:
                    data = self.load_info_from_file(cache_file)
                    _memory_cache_put(cache_key, data)
                    self.process_data(data)
                    return
                except Exception:
                    try:
                        os.remove(cache_file)
                    except Exception:
                        pass

            self._queue_download(event_name, cache_key, cache_file)
        except Exception as e:
            print("General Exception in infos:", e)

    def _queue_download(self, event_name, cache_key, cache_file):
        try:
            with self._state_lock:
                if self._destroyed:
                    return
                self._generation += 1
                generation = self._generation
                # Keep only the latest event; changing channel replaces pending.
                self._pending = (
                    generation,
                    event_name,
                    cache_key,
                    cache_file
                )
                worker_alive = (
                    self._worker is not None and self._worker.is_alive()
                )

            if not worker_alive:
                worker = threading.Thread(target=self._worker_loop)
                worker.daemon = True
                with self._state_lock:
                    self._worker = worker
                worker.start()

            self._start_result_timer()
        except Exception as e:
            print("Queue Exception:", e)

    def _start_result_timer(self):
        if self._result_timer is None:
            return
        try:
            self._result_timer.start(100, True)
        except Exception:
            try:
                self._result_timer.start(100)
            except Exception:
                pass

    def _worker_loop(self):
        while True:
            try:
                with self._state_lock:
                    if self._destroyed:
                        self._worker = None
                        return
                    job = self._pending
                    self._pending = None

                if job is None:
                    with self._state_lock:
                        # A new job may have appeared between the previous
                        # read and this lock acquisition.
                        if self._pending is None:
                            self._worker = None
                            return
                    continue

                generation, event_name, cache_key, cache_file = job
                data = self.download_and_save_info(
                    cache_file,
                    event_name=event_name,
                    cache_key=cache_key
                )

                with self._state_lock:
                    if (
                        not self._destroyed and
                        generation == self._generation
                    ):
                        self._result = (
                            generation,
                            cache_key,
                            data
                        )
            except Exception as e:
                print("Worker Exception:", e)
                try:
                    with self._state_lock:
                        self._worker = None
                except Exception:
                    pass
                return

    def _poll_result(self):
        result = None
        keep_polling = False
        try:
            with self._state_lock:
                result = self._result
                self._result = None
                keep_polling = (
                    not self._destroyed and
                    (
                        self._pending is not None or
                        (
                            self._worker is not None and
                            self._worker.is_alive()
                        )
                    )
                )
        except Exception:
            keep_polling = False

        if result is not None:
            generation, cache_key, data = result
            try:
                if cache_key == self._last_event_key and data:
                    self.process_data(data)
            except Exception as e:
                print("Result Process Exception:", e)

        if keep_polling:
            self._start_result_timer()

    def download_and_save_info(
        self,
        dwn_infos,
        event_name=None,
        cache_key=None
    ):
        """
        Background-only TMDB lookup.

        Search results already contain vote_average, so the old second movie
        details request is unnecessary for this rating renderer.
        """
        response = None
        try:
            title = event_name or ""
            url = (
                "https://api.themoviedb.org/3/search/multi"
                "?api_key=%s&query=%s"
            ) % (tmdb_api, quoteEventName(title))

            response = urlopen(url, timeout=TMDB_TIMEOUT)
            payload = response.read()

            if PY3 and isinstance(payload, bytes):
                payload = payload.decode("utf-8", "ignore")
            elif not PY3:
                try:
                    payload = payload.decode("utf-8", "ignore")
                except Exception:
                    pass

            url_data = json.loads(payload)
            results = url_data.get("results") or []

            selected = None
            # Prefer movie/TV results because people have no useful rating.
            for item in results:
                if item.get("media_type") in ("movie", "tv"):
                    selected = item
                    break
            if selected is None and results:
                selected = results[0]

            if not selected:
                return {}

            data = {
                "vote_average": selected.get("vote_average", 0),
                "media_type": selected.get("media_type", ""),
                "id": selected.get("id", 0)
            }

            if cache_key:
                _memory_cache_put(cache_key, data)

            self._save_info_atomic(dwn_infos, data)
            return data
        except Exception as e:
            print("Download Exception:", e)
            return {}
        finally:
            try:
                if response is not None:
                    response.close()
            except Exception:
                pass

    def _save_info_atomic(self, filepath, data):
        tmp_path = "%s.tmp.%s" % (filepath, os.getpid())
        try:
            with open(tmp_path, "w") as f:
                f.write(json.dumps(data))
            try:
                os.rename(tmp_path, filepath)
            except Exception:
                try:
                    if os.path.exists(filepath):
                        os.remove(filepath)
                except Exception:
                    pass
                os.rename(tmp_path, filepath)
        except Exception:
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except Exception:
                pass

    def fetch_movie_data(self, movie_id):
        """
        Compatibility method kept for skins/imports that may call it.
        It is not used by the renderer's normal rating path.
        """
        response = None
        try:
            movie_url = (
                "https://api.themoviedb.org/3/movie/%s"
                "?api_key=%s&append_to_response=credits&language=%s"
            ) % (movie_id, tmdb_api, lng)
            response = urlopen(movie_url, timeout=TMDB_TIMEOUT)
            payload = response.read()
            if PY3 and isinstance(payload, bytes):
                payload = payload.decode("utf-8", "ignore")
            elif not PY3:
                try:
                    payload = payload.decode("utf-8", "ignore")
                except Exception:
                    pass
            return json.loads(payload)
        except Exception:
            return {}
        finally:
            try:
                if response is not None:
                    response.close()
            except Exception:
                pass

    def load_info_from_file(self, filepath):
        with open(filepath, "r") as f:
            return json.load(f)

    def process_data(self, data):
        try:
            if not data or self.instance is None:
                return
            imdb_rating = data.get("vote_average", "0")
            if imdb_rating and imdb_rating != "0":
                rating = int(10 * float(imdb_rating))
            else:
                rating = 0
            rating = max(0, min(100, rating))
            (self.range, self.value) = ((0, 100), rating)
            self.instance.show()
        except Exception as e:
            print("Process Data Exception:", e)

    def setRange(self, range):
        (self.__start, self.__end) = range
        if self.instance is not None:
            self.instance.setRange(self.__start, self.__end)

    def getRange(self):
        return self.__start, self.__end
