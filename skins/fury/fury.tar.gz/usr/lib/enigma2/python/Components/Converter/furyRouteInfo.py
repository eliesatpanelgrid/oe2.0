# -*- coding: utf-8 -*-
#<!-- Shows connection type: "Ethernet", "WIFI", "Modem", or "Offline" -->
#<widget source="furyRouteInfo" render="Label" position="100,100" size="200,25" font="Regular;18">
#    <convert type="furyRouteInfo">All</convert>
#</widget>
#
# No-lag / universal-interface update:
# - /proc/net/route is read only by one daemon thread.
# - getText/getBoolean return RAM values only.
# - supports common interface names used by DreamOS, OpenATV, OpenBH,
#   OpenViX, OpenPLi and other Enigma2 images/devices.

from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached
import os
import threading
import time
try:
    from _thread import start_new_thread as _fury_start_new_thread
except Exception:
    try:
        from thread import start_new_thread as _fury_start_new_thread
    except Exception:
        _fury_start_new_thread = None


_ROUTE_LOCK = threading.RLock()
_ROUTE_STATE = {
    "lan": False,
    "wifi": False,
    "modem": False,
    "connected": False,
    "label": "Offline",
    "iface": "",
    "ts": 0.0,
}
_ROUTE_STARTED = [False]


def _iface_kind(iface):
    try:
        name = str(iface or "").strip().lower()
    except Exception:
        name = ""
    if not name:
        return ""

    if (name.startswith("wlan") or name.startswith("wl") or
            name.startswith("ra") or name.startswith("ath") or
            name.startswith("wifi")):
        return "wifi"

    if (name.startswith("ppp") or name.startswith("wwan") or
            name.startswith("rmnet") or name.startswith("gprs") or
            name.startswith("mobile") or name.startswith("cdc") or
            name.startswith("usb")):
        return "modem"

    if (name.startswith("eth") or name.startswith("en") or
            name.startswith("lan") or name.startswith("br") or
            name.startswith("bond")):
        return "lan"

    try:
        if os.path.isdir("/sys/class/net/%s/wireless" % name):
            return "wifi"
    except Exception:
        pass
    return ""


def _read_route_state():
    lan = False
    wifi = False
    modem = False
    selected_kind = ""
    selected_iface = ""

    try:
        with open("/proc/net/route", "r") as f:
            for raw in f:
                parts = raw.split()
                if len(parts) < 4 or parts[0] == "Iface":
                    continue
                iface = parts[0]
                destination = parts[1]
                try:
                    flags = int(parts[3], 16)
                except Exception:
                    flags = 0

                active = (flags & 0x0003) == 0x0003
                if not active:
                    continue

                kind = _iface_kind(iface)
                if kind == "lan":
                    lan = True
                elif kind == "wifi":
                    wifi = True
                elif kind == "modem":
                    modem = True

                if kind and (not selected_kind or destination == "00000000"):
                    selected_kind = kind
                    selected_iface = iface
                    if destination == "00000000":
                        break
    except Exception:
        pass

    connected = bool(lan or wifi or modem)
    if selected_kind == "wifi":
        label = "WIFI"
    elif selected_kind == "modem":
        label = "Modem"
    elif selected_kind == "lan":
        label = "Ethernet"
    elif wifi:
        label = "WIFI"
    elif modem:
        label = "Modem"
    elif lan:
        label = "Ethernet"
    else:
        label = "Offline"

    return {
        "lan": lan,
        "wifi": wifi,
        "modem": modem,
        "connected": connected,
        "label": label,
        "iface": selected_iface,
        "ts": time.time(),
    }


def _route_start_thread(target, name):
    def _runner():
        try:
            threading.current_thread().name = name
        except Exception:
            pass
        try:
            target()
        except Exception:
            pass
    try:
        if _fury_start_new_thread is not None:
            _fury_start_new_thread(_runner, ())
            return True
    except Exception:
        pass
    try:
        th = threading.Thread(target=_runner, name=name)
        th.daemon = True
        th.start()
        return True
    except Exception:
        return False


def _route_worker():
    while True:
        try:
            state = _read_route_state()
            with _ROUTE_LOCK:
                _ROUTE_STATE.update(state)
        except Exception:
            pass
        time.sleep(5.0)


def _ensure_route_worker():
    if _ROUTE_STARTED[0]:
        return
    try:
        with _ROUTE_LOCK:
            if _ROUTE_STARTED[0]:
                return
            _ROUTE_STARTED[0] = True
        if not _route_start_thread(_route_worker, "fury-routeinfo"):
            with _ROUTE_LOCK:
                _ROUTE_STARTED[0] = False
    except Exception:
        _ROUTE_STARTED[0] = False


def _route_snapshot():
    try:
        with _ROUTE_LOCK:
            return dict(_ROUTE_STATE)
    except Exception:
        return {
            "lan": False, "wifi": False, "modem": False,
            "connected": False, "label": "Offline", "iface": "", "ts": 0.0,
        }


class furyRouteInfo(Poll, Converter, object):
    Info = 0
    Lan = 1
    Wifi = 2
    Modem = 3
    All = 4

    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.poll_interval = 5000
        self.poll_enabled = True

        if type == "Info":
            self.type = self.Info
        elif type == "Lan":
            self.type = self.Lan
        elif type == "Wifi":
            self.type = self.Wifi
        elif type == "Modem":
            self.type = self.Modem
        else:
            self.type = self.All
        _ensure_route_worker()

    @cached
    def getBoolean(self):
        state = _route_snapshot()
        if self.type == self.All:
            return bool(state.get("connected"))
        if self.type == self.Lan:
            return bool(state.get("lan"))
        if self.type == self.Wifi:
            return bool(state.get("wifi"))
        if self.type == self.Modem:
            return bool(state.get("modem"))
        return False

    boolean = property(getBoolean)

    @cached
    def getText(self):
        state = _route_snapshot()
        label = state.get("label", "Offline")
        if self.type == self.All:
            return label
        if self.type == self.Info:
            return "" if label == "Offline" else label
        return ""

    text = property(getText)

    def changed(self, what):
        Converter.changed(self, what)
