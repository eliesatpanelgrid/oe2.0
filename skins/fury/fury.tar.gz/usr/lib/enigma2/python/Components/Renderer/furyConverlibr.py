# -*- coding: utf-8 -*-
# recode from islam salama 2026

from re import sub, S, I, search, compile, DOTALL, escape
from six import text_type
from unicodedata import normalize
import sys

DEBUG_CONVLIB = False  # keep convtext silent during zapping/channel-list navigation
_CONVTEXT_CACHE = {}
_CONVTEXT_CACHE_MAX = 800


try:
    unicode
except NameError:
    unicode = str


PY3 = False
if sys.version_info[0] >= 3:
    PY3 = True
    import html
    html_parser = html
    from urllib.parse import quote_plus
else:
    from urllib import quote_plus
    from HTMLParser import HTMLParser
    html_parser = HTMLParser()


def quoteEventName(eventName):
    try:
        text = eventName.decode('utf8').replace(u'\x86', u'').replace(u'\x87', u'').encode('utf8')
    except:
        text = eventName
    return quote_plus(text, safe="+")


REGEX = compile(
    r'[\(\[].*?[\)\]]|'                    # Parentesi tonde o quadre
    r':?\s?odc\.\d+|'                      # odc. con o senza numero prima
    r'\d+\s?:?\s?odc\.\d+|'                # numero con odc.
    r'[:!]|'                               # due punti o punto esclamativo
    r'\s-\s.*|'                            # trattino con testo successivo
    r',|'                                  # virgola
    r'/.*|'                                # tutto dopo uno slash
    r'\|\s?\d+\+|'                         # | seguito da numero e +
    r'\d+\+|'                              # numero seguito da +
    r'\s\*\d{4}\Z|'                        # * seguito da un anno a 4 cifre
    r'[\(\[\|].*?[\)\]\|]|'                # Parentesi tonde, quadre o pipe
    r'(?:\"[\.|\,]?\s.*|\"|'               # Testo tra virgolette
    r'\.\s.+)|'                            # Punto seguito da testo
    r'Премьера\.\s|'                       # Specifico per il russo
    r'[хмтдХМТД]/[фс]\s|'                  # Pattern per il russo con /ф o /с
    r'\s[сС](?:езон|ерия|-н|-я)\s.*|'      # Stagione o episodio in russo
    r'\s\d{1,3}\s[чсЧС]\.?\s.*|'           # numero di parte/episodio in russo
    r'\.\s\d{1,3}\s[чсЧС]\.?\s.*|'         # numero di parte/episodio in russo con punto
    r'\s[чсЧС]\.?\s\d{1,3}.*|'             # Parte/Episodio in russo
    r'\d{1,3}-(?:я|й)\s?с-н.*',            # Finale con numero e suffisso russo
    DOTALL)


def remove_accents(string):
    if not isinstance(string, text_type):
        string = text_type(string, 'utf-8')
    string = sub(u"[àáâãäå]", 'a', string)
    string = sub(u"[èéêë]", 'e', string)
    string = sub(u"[ìíîï]", 'i', string)
    string = sub(u"[òóôõö]", 'o', string)
    string = sub(u"[ùúûü]", 'u', string)
    string = sub(u"[ýÿ]", 'y', string)
    return string


def unicodify(s, encoding='utf-8', norm=None):
    if not isinstance(s, text_type):
        s = text_type(s, encoding)
    if norm:
        s = normalize(norm, s)
    return s


def str_encode(text, encoding="utf8"):
    if not PY3:
        if isinstance(text, text_type):
            return text.encode(encoding)
    return text


def cutName(eventName=""):
    if eventName:
        eventName = eventName.replace('"', '').replace('Х/Ф', '').replace('М/Ф', '').replace('Х/ф', '')  # .replace('.', '').replace(' | ', '')
        eventName = eventName.replace('(18+)', '').replace('18+', '').replace('(16+)', '').replace('16+', '').replace('(12+)', '')
        eventName = eventName.replace('12+', '').replace('(7+)', '').replace('7+', '').replace('(6+)', '').replace('6+', '')
        eventName = eventName.replace('(0+)', '').replace('0+', '').replace('+', '')
        eventName = eventName.replace('المسلسل العربي', '')
        eventName = eventName.replace('مسلسل', '')
        eventName = eventName.replace('برنامج', '')
        eventName = eventName.replace('فيلم وثائقى', '')
        eventName = eventName.replace('حفل', '')
        return eventName
    return ""


def getCleanTitle(eventitle=""):
    # save_name = sub('\\(\d+\)$', '', eventitle)
    # save_name = sub('\\(\d+\/\d+\)$', '', save_name)  # remove episode-number " (xx/xx)" at the end
    # # save_name = sub('\ |\?|\.|\,|\!|\/|\;|\:|\@|\&|\'|\-|\"|\%|\(|\)|\[|\]\#|\+', '', save_name)
    save_name = eventitle.replace(' ^`^s', '').replace(' ^`^y', '')
    return save_name


def sanitize_filename(filename):
    # Replace spaces with underscores and remove invalid characters (like ':')
    sanitized = sub(r'[^\w\s-]', '', filename)  # Remove invalid characters
    # sanitized = sanitized.replace(' ', '_')      # Replace spaces with underscores
    # sanitized = sanitized.replace('-', '_')      # Replace dashes with underscores
    return sanitized.strip()


def convtext(text=''):
    try:
        _cache_key = str(text)
        if _cache_key in _CONVTEXT_CACHE:
            return _CONVTEXT_CACHE[_cache_key]
        if str(text).strip().lower() == "2012":
            return text.strip()
        if text is None:
            if DEBUG_CONVLIB:
                print('return None original text:', type(text))
            return  # Esci dalla funzione se text è None
        if text == '':
            if DEBUG_CONVLIB:
                print('text is an empty string')
        else:
            text = str(text)
            # print('original text:', text)
            # Converti tutto in minuscolo
            text = text.lower().rstrip()
            # print('lowercased text:', text)

            # Mappatura sostituzioni con azione specifica
            sostituzioni = [
                # set
                ('superman & lois', 'superman e lois', 'set'),
                ('lois & clark', 'superman e lois', 'set'),
                ("una 44 magnum per", 'magnumxx', 'set'),
                ('john q', 'johnq', 'set'),
                # replace
                ('1/2', 'mezzo', 'replace'),
                ('c.s.i.', 'csi', 'replace'),
                ('c.s.i:', 'csi', 'replace'),
                ('n.c.i.s.:', 'ncis', 'replace'),
                ('ncis:', 'ncis', 'replace'),
                ('ritorno al futuro:', 'ritorno al futuro', 'replace'),

                # set
                ('il ritorno di colombo', 'colombo', 'set'),
                ('lingo: parole', 'lingo', 'set'),
                ('heartland', 'heartland', 'set'),
                ('io & marilyn', 'io e marilyn', 'set'),
                ('giochi olimpici parigi', 'olimpiadi di parigi', 'set'),
                ('bruno barbieri', 'brunobarbierix', 'set'),
                ("anni '60", 'anni 60', 'set'),
                ('cortesie per gli ospiti', 'cortesieospiti', 'set'),
                ('tg regione', 'tg3', 'set'),
                ('tg1', 'tguno', 'set'),
                ('planet earth', 'planet earth', 'set'),
                ('studio aperto', 'studio aperto', 'set'),
                ('josephine ange gardien', 'josephine ange gardien', 'set'),
                ('josephine angelo', 'josephine ange gardien', 'set'),
                ('elementary', 'elementary', 'set'),
                ('squadra speciale cobra 11', 'squadra speciale cobra 11', 'set'),
                ('criminal minds', 'criminal minds', 'set'),
                ('i delitti del barlume', 'i delitti del barlume', 'set'),
                ('senza traccia', 'senza traccia', 'set'),
                ('hudson e rex', 'hudson e rex', 'set'),
                ('ben-hur', 'ben-hur', 'set'),
                ('alessandro borghese - 4 ristoranti', 'alessandroborgheseristoranti', 'set'),
                ('alessandro borghese: 4 ristoranti', 'alessandroborgheseristoranti', 'set'),
                ('amici di maria', 'amicimaria', 'set'),

                ('csi miami', 'csi miami', 'set'),
                ('csi: miami', 'csi miami', 'set'),
                ('csi: scena del crimine', 'csi scena del crimine', 'set'),
                ('csi: new york', 'csi new york', 'set'),
                ('csi: vegas', 'csi vegas', 'set'),
                ('csi: cyber', 'csi cyber', 'set'),
                ('csi: immortality', 'csi immortality', 'set'),
                ('csi: crime scene talks', 'csi crime scene talks', 'set'),

                ('ncis unità anticrimine', 'ncis unità anticrimine', 'set'),
                ('ncis unita anticrimine', 'ncis unita anticrimine', 'set'),
                ('ncis new orleans', 'ncis new orleans', 'set'),
                ('ncis los angeles', 'ncis los angeles', 'set'),
                ('ncis origins', 'ncis origins', 'set'),
                ('ncis hawai', 'ncis hawai', 'set'),
                ('ncis sydney', 'ncis sydney', 'set'),

                ('ritorno al futuro - parte iii', 'ritornoalfuturoparteiii', 'set'),
                ('ritorno al futuro - parte ii', 'ritornoalfuturoparteii', 'set'),
                ('walker, texas ranger', 'walker texas ranger', 'set'),
                ('e.r.', 'ermediciinprimalinea', 'set'),
                ('alexa: vita da detective', 'alexa vita da detective', 'set'),
                ('delitti in paradiso', 'delitti in paradiso', 'set'),
                ('modern family', 'modern family', 'set'),
                ('shaun: vita da pecora', 'shaun', 'set'),
                ('calimero', 'calimero', 'set'),
                ('i puffi', 'i puffi', 'set'),
                ('stuart little', 'stuart little', 'set'),
                ('gf daily', 'grande fratello', 'set'),
                ('grande fratello', 'grande fratello', 'set'),
                ('castle', 'castle', 'set'),
                ('seal team', 'seal team', 'set'),
                ('fast forward', 'fast forward', 'set'),
                ('un posto al sole', 'un posto al sole', 'set'),
            ]

            # Applicazione delle sostituzioni
            for parola, sostituto, metodo in sostituzioni:
                if parola in text:
                    if metodo == 'set':
                        text = sostituto
                        break
                    elif metodo == 'replace':
                        text = text.replace(parola, sostituto)

            # Applica le funzioni di taglio e pulizia del titolo
            text = cutName(text)
            text = getCleanTitle(text)

            # Regola il titolo se finisce con "the"
            if text.endswith("the"):
                text = "the " + text[:-4]

            # Sostituisci caratteri speciali con stringhe vuote
            text = text.replace("\xe2\x80\x93", "").replace('\xc2\x86', '').replace('\xc2\x87', '').replace('webhdtv', '')
            text = text.replace('1080i', '').replace('dvdr5', '').replace('((', '(').replace('))', ')') .replace('hdtvrip', '')
            text = text.replace('german', '').replace('english', '').replace('ws', '').replace('ituneshd', '').replace('hdtv', '')
            text = text.replace('dvdrip', '').replace('unrated', '').replace('retail', '').replace('web-dl', '').replace('divx', '')
            text = text.replace('bdrip', '').replace('uncut', '').replace('avc', '').replace('ac3d', '').replace('ts', '')
            text = text.replace('ac3md', '').replace('ac3', '').replace('webhdtvrip', '').replace('xvid', '').replace('bluray', '')
            text = text.replace('complete', '').replace('internal', '').replace('dtsd', '').replace('h264', '').replace('dvdscr', '')
            text = text.replace('dubbed', '').replace('line.dubbed', '').replace('dd51', '').replace('dvdr9', '').replace('sync', '')
            text = text.replace('webhdrip', '').replace('webrip', '').replace('repack', '').replace('dts', '').replace('webhd', '')
            # set add
            text = text.replace('1^tv', '').replace('1^ tv', '').replace(' - prima tv', '').replace(' - primatv', '')
            text = text.replace('primatv', '').replace('en direct:', '').replace('first screening', '').replace('live:', '')
            text = text.replace('1^ visione rai', '').replace('1^ visione', '').replace('premiere:', '').replace('nouveau:', '')
            text = text.replace('prima visione', '').replace('film -', '').replace('en vivo:', '').replace('nueva emisión:', '')
            text = text.replace('new:', '').replace('film:', '').replace('première diffusion', '').replace('estreno:', '')
            if DEBUG_CONVLIB:
                print('cutlist:', text)

            # Rimuovi accenti
            text = remove_accents(text)
            # print('remove_accents text:', text)

            # remove episode number from series, like "series"
            regex = compile(r'^(.*?)([ ._-]*(ep|episodio|st|stag|odc|parte|pt!series|serie|s[0-9]{1,2}e[0-9]{1,2}|[0-9]{1,2}x[0-9]{1,2})[ ._-]*[.]?[ ._-]*[0-9]+.*)$')
            text = sub(regex, r'\1', text).strip()
            if DEBUG_CONVLIB:
                print("titolo_pulito:", text)
            # Force and remove episode number from series, like "series"
            if search(r'[Ss][0-9]+[Ee][0-9]+', text):
                text = sub(r'[Ss][0-9]+[Ee][0-9]+.*[a-zA-Z0-9_]+', '', text, flags=S | I)
            text = sub(r'\(.*\)', '', text).rstrip()  # remove episode number from series, like "series"

            # Rimozione pattern specifici
            text = sub(r'^\w{2}:', '', text)  # Rimuove "xx:" all'inizio
            text = sub(r'^\w{2}\|\w{2}\s', '', text)  # Rimuove "xx|xx" all'inizio
            text = sub(r'^.{2}\+? ?- ?', '', text)  # Rimuove "xx -" all'inizio
            text = sub(r'^\|\|.*?\|\|', '', text)  # Rimuove contenuti tra "||"
            text = sub(r'^\|.*?\|', '', text)  # Rimuove contenuti tra "|"
            text = sub(r'\|.*?\|', '', text)  # Rimuove qualsiasi altro contenuto tra "|"
            text = sub(r'\(\(.*?\)\)|\(.*?\)', '', text)  # Rimuove contenuti tra "()"
            text = sub(r'\[\[.*?\]\]|\[.*?\]', '', text)  # Rimuove contenuti tra "[]"

            text = sub(r'[^\w\s]+$', '', text)
            text = sub(r'\sح\s*\d+', '', text)   # remove episode number in arabic series
            text = sub(r'\sج\s*\d+', '', text)   # remove season number in arabic series
            text = sub(r'\sم\s*\d+', '', text)   # remove season number in arabic series
            # text = sub(r' +ح| +ج| +م', '', text)  # Rimuove numeri di episodi/serie in arabo

            # Rimozione di stringhe non valide
            bad_strings = [
                "ae|", "al|", "ar|", "at|", "ba|", "be|", "bg|", "br|", "cg|", "ch|", "cz|", "da|", "de|", "dk|",
                "ee|", "en|", "es|", "eu|", "ex-yu|", "fi|", "fr|", "gr|", "hr|", "hu|", "in|", "ir|", "it|", "lt|",
                "mk|", "mx|", "nl|", "no|", "pl|", "pt|", "ro|", "rs|", "ru|", "se|", "si|", "sk|", "sp|", "tr|",
                "uk|", "us|", "yu|",
                "1080p", "4k", "720p", "hdrip", "hindi", "imdb", "vod", "x264"
            ]

            years_to_remove = [str(year) for year in range(1900, 2030)]
            bad_strings.extend(years_to_remove)
            bad_strings_pattern = compile('|'.join(map(escape, bad_strings)))
            text = bad_strings_pattern.sub('', text)
            # Rimozione suffissi non validi
            bad_suffix = [
                " al", " ar", " ba", " da", " de", " en", " es", " eu", " ex-yu", " fi", " fr", " gr", " hr", " mk",
                " nl", " no", " pl", " pt", " ro", " rs", " ru", " si", " swe", " sw", " tr", " uk", " yu"
            ]
            bad_suffix_pattern = compile(r'(' + '|'.join(map(escape, bad_suffix)) + r')$')
            text = bad_suffix_pattern.sub('', text)
            # Rimuovi "." "_" "'" e sostituiscili con spazi
            text = sub(r'[._\']', ' ', text)
            # Rimuove tutto dopo i ":" (incluso ":")
            #text = sub(r':.*$', '', text)
            text = sub(r':\s*$', '', text)
            # Pulizia finale
            text = text.partition("(")[0]  # Rimuove contenuti dopo "("
            # text = text.partition(":")[0]
            # text = text + 'FIN'
            # text = sub(r'(odc.\s\d+)+.*?FIN', '', text)
            # text = sub(r'(odc.\d+)+.*?FIN', '', text)
            # text = sub(r'(\d+)+.*?FIN', '', text)
            # text = sub('FIN', '', text)

            # remove episode number in arabic series
            text = sub(r' +ح', '', text)
            # remove season number in arabic series
            text = sub(r' +ج', '', text)
            # remove season number in arabic series
            text = sub(r' +م', '', text)

            text = text.partition(" -")[0]  # Rimuove contenuti dopo "-"
            text = text.strip(' -')
            # Forzature finali
            text = text.replace('XXXXXX', '60')
            text = text.replace('magnumxx', "una 44 magnum per l ispettore")
            text = text.replace('amicimaria', 'amici di maria')
            text = text.replace('alessandroborgheseristoranti', 'alessandro borghese - 4 ristoranti')
            text = text.replace('brunobarbierix', 'bruno barbieri - 4 hotel')
            text = text.replace('johnq', 'john q')
            text = text.replace('il ritorno di colombo', 'colombo')
            text = text.replace('cortesieospiti', 'cortesie per gli ospiti')
            text = text.replace('ermediciinprimalinea', 'er medici in prima linea')
            text = text.replace('ritornoalfuturoparteiii', 'ritorno al futuro parte iii')
            text = text.replace('ritornoalfuturoparteii', 'ritorno al futuro parte ii')
            text = text.replace('tguno', 'tg1')
            # text = quote(text, safe="")
            # text = unquote(text)
            if DEBUG_CONVLIB:
                print('text safe:', text)

        result = text.capitalize()
        try:
            if len(_CONVTEXT_CACHE) >= _CONVTEXT_CACHE_MAX:
                _CONVTEXT_CACHE.clear()
            _CONVTEXT_CACHE[_cache_key] = result
        except Exception:
            pass
        return result
    except Exception as e:
        if DEBUG_CONVLIB:
            print('convtext error:', e)
        return None


# ---------------------------------------------------------------------
# Shared title matching helpers
# ---------------------------------------------------------------------
def safe_str(value):
    """Return a safe unicode/text value for title processing."""
    try:
        if value is None:
            return u""
        if PY3:
            return str(value)
        if isinstance(value, unicode):
            return value
        return unicode(value, 'utf-8', 'ignore')
    except Exception:
        try:
            return str(value)
        except Exception:
            return u""


def strip_trailing_series_markers(title):
    """Remove common Arabic/European episode and season suffixes."""
    try:
        value = safe_str(title)
        patterns = [
            r'\s+(?:الحلقة|حلقة|ح)\s*\d+.*$',
            r'\s+(?:الموسم|موسم|الجزء|جزء|ج)\s*\d+.*$',
            r'\s+S\d{1,2}\s*[.\-_/ ]?\s*E\d{1,3}.*$',
            r'\s+\d{1,2}\s*x\s*\d{1,3}.*$',
            r'\s+(?:odcinek|odc\.?|episode|episodio|folge|ep\.?)\s*\d+.*$',
            r'\s+\d{1,2}\s*[:\-]\s*(?:odcinek|odc\.?|episode|ep\.?)\s*\d+.*$',
        ]
        for pattern in patterns:
            value = sub(pattern, '', value, flags=I).strip()
        return sub(r'\s+', ' ', value).strip(' -:|')
    except Exception:
        return title


def remove_year_in_parentheses(title):
    """Remove a standalone year from a title while returning only the title text."""
    try:
        value = safe_str(title)
        value = sub(r'\s*[\(\[]\s*(?:19|20)\d{2}\s*[\)\]]\s*', ' ', value)
        value = sub(r'(?<!^)\s+(?:19|20)\d{2}\s*$', '', value)
        return sub(r'\s+', ' ', value).strip()
    except Exception:
        return title


def split_title_and_year(title):
    """Split titles like 'Movie (2024)' or 'Movie 2024' into (title, year)."""
    try:
        value = safe_str(title).strip()
        if not value:
            return value, ""
        year = ""
        match = search(r'[\(\[]\s*((?:19|20)\d{2})\s*[\)\]]\s*$', value)
        if not match:
            match = search(r'(?<!^)\s+((?:19|20)\d{2})\s*$', value)
        if match:
            year = match.group(1)
            value = value[:match.start()].strip()
        value = strip_trailing_series_markers(value)
        value = remove_year_in_parentheses(value)
        return value.strip(), year
    except Exception:
        return title, ""


def apply_arabic_title_normalization(title):
    """Normalize Arabic letters and remove diacritics for loose matching."""
    try:
        value = safe_str(title)
        value = sub(u'[\u064b-\u065f\u0670\u0640]', '', value)
        value = value.replace(u'أ', u'ا').replace(u'إ', u'ا').replace(u'آ', u'ا')
        value = value.replace(u'ى', u'ي').replace(u'ؤ', u'و').replace(u'ئ', u'ي')
        return value
    except Exception:
        return title


def clean_search_title(title):
    """Build a clean provider search title from an EPG title."""
    try:
        value = safe_str(title)
        value = value.replace('\xc2\x86', '').replace('\xc2\x87', '')
        value = value.replace('+', ' ').replace('–', '-').replace('—', '-')
        value = sub(r'\[[^\]]{0,80}\]', ' ', value)
        value = sub(r'\([^\)]{0,80}\)', ' ', value)
        value = sub(r'^\s*(?:فيلم|مسلسل|برنامج|movie|film|series|show)\s*[:\-]\s*', '', value, flags=I)
        value = strip_trailing_series_markers(value)
        value = remove_year_in_parentheses(value)
        value = apply_arabic_title_normalization(value)
        value = sub(r'\s+', ' ', value).strip(' -:|')
        return value
    except Exception:
        return title


def build_search_title(title, shortdesc="", fulldesc=""):
    """Return the best clean title available from the event title and descriptions."""
    try:
        base_title = clean_search_title(title)
        # Many EPG feeds include an official/original title in the description.
        label = r'(?:original\s+title|titulo\s+original|t\S*tulo\s+original|titre\s+original|titolo\s+originale|tytu\S*\s+oryginalny)\s*[:\-]\s*([^\n\r]{2,120})'
        for text in (shortdesc, fulldesc):
            match = search(label, safe_str(text), flags=I)
            if match:
                cand = clean_search_title(match.group(1))
                if cand:
                    return cand
        return base_title
    except Exception:
        return title


def should_skip_title(title):
    """Skip titles that are too generic to search accurately."""
    try:
        value = safe_str(title).strip().lower()
        if not value or len(value) < 2:
            return True
        generic = set(['news', 'live', 'replay', 'movie', 'film', 'series', 'برنامج', 'مسلسل', 'فيلم', 'نشرة', 'مباشر'])
        return value in generic
    except Exception:
        return False
