# -*- coding: utf-8 -*-
# ArBoxInfo
# Copyright (c) Tikhon 2019
# v.1.1
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

from Components.Converter.Poll import Poll
from Components.Converter.Converter import Converter
from Components.config import config
from Components.Element import cached
from Tools.Directories import fileExists
from os.path import isfile, exists
from os import popen
from re import search
import gettext
import subprocess
import threading
import time
try:
    from _thread import start_new_thread as _fury_start_new_thread
except Exception:
    try:
        from thread import start_new_thread as _fury_start_new_thread
    except Exception:
        _fury_start_new_thread = None
try:
    import queue as _queue
except Exception:
    try:
        import Queue as _queue
    except Exception:
        _queue = None
_ = gettext.gettext


# ---------------------------------------------------------------------------
# Shared no-lag cache
#
# Converter getters run on the Enigma2 GUI thread. The original file opened
# /proc files and sometimes launched hddtemp/gst-launch/openssl directly from
# getText(), which can freeze the channel list or InfoBar.
#
# One daemon worker now performs those operations in the background. All
# converter instances only return values already held in RAM. Public converter
# names, skin syntax and displayed text stay unchanged.
# ---------------------------------------------------------------------------
_BOX_CACHE = {}
_BOX_CACHE_TS = {}
_BOX_PENDING = set()
_BOX_LOCK = threading.RLock()
_BOX_WORKER_STARTED = [False]
_BOX_QUEUE = None
if _queue is not None:
    try:
        _BOX_QUEUE = _queue.Queue(maxsize=64)
    except Exception:
        _BOX_QUEUE = None

_BOX_REFRESH_SECONDS = {
    0: 3600.0, 1: 3600.0, 2: 90.0, 3: 10.0, 4: 10.0,
    5: 30.0, 6: 5.0, 7: 30.0, 8: 300.0,
    9: 60.0, 10: 60.0, 11: 60.0, 12: 60.0,
    13: 3600.0, 14: 3600.0, 15: 3600.0, 16: 3600.0,
}

_BOX_DEFAULTS = {
    0: "", 1: "", 2: "No info", 3: "N/A", 4: "Fan: N/A",
    5: " ", 6: "CPU Load: ", 7: "", 8: "",
    9: "+0", 10: "Timezone: GMT+00:00", 11: "+0", 12: "+0",
    13: "", 14: "", 15: "", 16: "",
}


def _run_command(argv, timeout=2.5):
    """Python-2-compatible command runner with a hard timeout.

    It is called only by the background worker, never by the GUI thread.
    """
    proc = None
    try:
        proc = subprocess.Popen(
            argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            close_fds=True
        )
        deadline = time.time() + float(timeout)
        while proc.poll() is None:
            if time.time() >= deadline:
                try:
                    proc.kill()
                except Exception:
                    try:
                        proc.terminate()
                    except Exception:
                        pass
                return ""
            time.sleep(0.05)
        out = proc.communicate()[0]
        if out is None:
            return ""
        try:
            if not isinstance(out, str):
                out = out.decode("utf-8", "ignore")
            else:
                try:
                    if not isinstance(out, unicode):  # noqa: F821
                        out = out.decode("utf-8", "ignore")
                except NameError:
                    pass
        except Exception:
            try:
                out = str(out)
            except Exception:
                return ""
        return out.strip()
    except Exception:
        try:
            if proc is not None and proc.poll() is None:
                proc.kill()
        except Exception:
            pass
        return ""



def _box_start_thread(target, name):
    """Start a daemon-style worker without blocking the Enigma2 GUI on Thread.start()."""
    def _runner():
        try:
            threading.current_thread().name = name
        except Exception:
            pass
        try:
            target()
        except Exception:
            pass
    try:
        if _fury_start_new_thread is not None:
            _fury_start_new_thread(_runner, ())
            return True
    except Exception:
        pass
    try:
        th = threading.Thread(target=_runner, name=name)
        try:
            th.daemon = True
        except Exception:
            th.setDaemon(True)
        th.start()
        return True
    except Exception:
        return False

def _box_worker():
    while True:
        try:
            item = _BOX_QUEUE.get()
            if item is None:
                return
            inst, info_type = item
            try:
                value = inst._computeText()
                if value is None:
                    value = _BOX_DEFAULTS.get(info_type, "")
                with _BOX_LOCK:
                    _BOX_CACHE[info_type] = value
                    _BOX_CACHE_TS[info_type] = time.time()
            except Exception:
                pass
            finally:
                try:
                    with _BOX_LOCK:
                        _BOX_PENDING.discard(info_type)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            _BOX_QUEUE.task_done()
        except Exception:
            pass


def _ensure_box_worker():
    if _BOX_QUEUE is None or _BOX_WORKER_STARTED[0]:
        return
    try:
        with _BOX_LOCK:
            if _BOX_WORKER_STARTED[0]:
                return
            # Set the guard before spawning so multiple converter instances opened
            # in the same skin pass can never create duplicate workers.
            _BOX_WORKER_STARTED[0] = True
        if not _box_start_thread(_box_worker, "fury-boxinfo"):
            with _BOX_LOCK:
                _BOX_WORKER_STARTED[0] = False
    except Exception:
        _BOX_WORKER_STARTED[0] = False


def _queue_box_refresh(inst, force=False):
    if _BOX_QUEUE is None:
        return
    try:
        info_type = int(inst.type)
        now = time.time()
        with _BOX_LOCK:
            if info_type in _BOX_PENDING:
                return
            age = now - float(_BOX_CACHE_TS.get(info_type, 0.0) or 0.0)
            ttl = float(_BOX_REFRESH_SECONDS.get(info_type, 30.0))
            if (not force) and info_type in _BOX_CACHE and age < ttl:
                return
            _BOX_PENDING.add(info_type)
        _ensure_box_worker()
        try:
            _BOX_QUEUE.put((inst, info_type), False)
        except Exception:
            with _BOX_LOCK:
                _BOX_PENDING.discard(info_type)
    except Exception:
        pass


def _box_cached_value(info_type):
    try:
        with _BOX_LOCK:
            if info_type in _BOX_CACHE:
                return _BOX_CACHE[info_type]
    except Exception:
        pass
    return _BOX_DEFAULTS.get(info_type, "")


class furyBoxInfo(Poll, Converter, object):
    """Enhanced system information converter for Enigma2"""
    Boxtype = 0
    CpuInfo = 1
    HddTemp = 2
    TempInfo = 3
    FanInfo = 4
    Upinfo = 5
    CpuLoad = 6
    CpuSpeed = 7
    SkinInfo = 8
    TimeInfo = 9
    TimeInfo2 = 10
    TimeInfo3 = 11
    TimeInfo4 = 12
    PythonVersion = 13
    GstreamerVersion = 14
    KernelVersion = 15
    OpenSslVersion = 16

    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.poll_interval = 2000
        self.poll_enabled = True

        type_map = {
            "Boxtype": self.Boxtype,
            "CpuInfo": self.CpuInfo,
            "HddTemp": self.HddTemp,
            "TempInfo": self.TempInfo,
            "FanInfo": self.FanInfo,
            "Upinfo": self.Upinfo,
            "CpuLoad": self.CpuLoad,
            "CpuSpeed": self.CpuSpeed,
            "SkinInfo": self.SkinInfo,
            "TimeInfo": self.TimeInfo,
            "TimeInfo2": self.TimeInfo2,
            "TimeInfo3": self.TimeInfo3,
            "TimeInfo4": self.TimeInfo4,
            "PythonVersion": self.PythonVersion,
            "GstreamerVersion": self.GstreamerVersion,
            "KernelVersion": self.KernelVersion,
            "OpenSslVersion": self.OpenSslVersion
        }

        if type in type_map:
            self.type = type_map[type]
        else:
            raise ValueError("Invalid converter type: %s" % type)

        # Poll only as often as this value can usefully change.  This avoids
        # waking every converter instance every 2 seconds just to read the same RAM.
        _poll_ms = {
            self.HddTemp: 60000,
            self.TempInfo: 10000,
            self.FanInfo: 10000,
            self.Upinfo: 30000,
            self.CpuLoad: 5000,
            self.CpuSpeed: 30000,
            self.TimeInfo: 60000,
            self.TimeInfo2: 60000,
            self.TimeInfo3: 60000,
            self.TimeInfo4: 60000,
        }
        self.poll_interval = int(_poll_ms.get(self.type, 300000))
        self.poll_enabled = True
        # force=False still queues the very first value, but duplicate instances
        # share the same pending/cache entry instead of recomputing at skin open.
        _queue_box_refresh(self, force=False)

    def imageinfo(self):
        """Find the package status file for image information"""
        imageinfo = ''
        if isfile('/usr/lib/opkg/status'):
            imageinfo = '/usr/lib/opkg/status'
        elif isfile('/usr/lib/ipkg/status'):
            imageinfo = '/usr/lib/ipkg/status'
        elif isfile('/var/lib/opkg/status'):
            imageinfo = '/var/lib/opkg/status'
        elif isfile('/var/opkg/status'):
            imageinfo = '/var/opkg/status'
        return imageinfo

    def get_gstreamer_version(self):
        """Get GStreamer version information (background worker only)."""
        try:
            commands = [
                ['/usr/bin/gst-launch-1.0', '--version'],
                ['/usr/bin/gst-launch', '--version'],
                ['gst-launch-1.0', '--version'],
                ['gst-launch', '--version'],
            ]
            for cmd in commands:
                try:
                    if cmd[0].startswith('/') and not fileExists(cmd[0]):
                        continue
                except Exception:
                    pass
                output = _run_command(cmd, 2.0)
                if output:
                    parts = output.split()
                    return parts[-1] if 'gst-launch' in output and parts else output
            return _("Not available")
        except Exception:
            return _("Error")

    def get_kernel_version(self):
        """Get kernel version information"""
        try:
            if isfile("/proc/version"):
                with open("/proc/version", "r") as f:
                    return f.read().split()[2]  # Kernel version is typically the third field
            return _("Not available")
        except Exception as e:
            print("Error getting kernel version:", str(e))
            return _("Error")

    def get_openssl_version(self):
        """Get OpenSSL version information (background worker only)."""
        try:
            for cmd in (['/usr/bin/openssl', 'version'], ['openssl', 'version']):
                try:
                    if cmd[0].startswith('/') and not fileExists(cmd[0]):
                        continue
                except Exception:
                    pass
                output = _run_command(cmd, 2.0)
                if output:
                    parts = output.split()
                    if len(parts) > 1:
                        return parts[1]
            try:
                import ssl
                parts = ssl.OPENSSL_VERSION.split()
                return parts[1] if len(parts) > 1 else ssl.OPENSSL_VERSION
            except Exception:
                pass
            return _("Not available")
        except Exception:
            return _("Error")

    def _computeText(self):
        if self.type == self.Boxtype:
            box = software = ""

            # Get Enigma version
            enigma = ""
            if isfile("/proc/version"):
                try:
                    with open("/proc/version", "r") as f:
                        enigma = f.read().split()[2]
                except Exception as e:
                    print("Error reading /proc/version:", str(e))

            # Get box brand and model
            try:
                from Components.SystemInfo import BoxInfo
                DISPLAYBRAND = BoxInfo.getItem("displaybrand")
                if DISPLAYBRAND.startswith("Maxytec"):
                    DISPLAYBRAND = "Novaler"
                DISPLAYMODEL = BoxInfo.getItem("displaymodel")
                box = DISPLAYBRAND + " " + DISPLAYMODEL
            except ImportError:
                try:
                    with open("/etc/hostname", "r") as f:
                        host = f.readline().strip()
                    box = host.split()[0] if host else _("Unknown")
                except Exception:
                    box = _("Unknown")

            # Detect distro info
            if isfile("/etc/issue"):
                try:
                    with open("/etc/issue", "r") as f:
                        for line in f:
                            clean_line = line.capitalize()
                            for r in [
                                "Open vision enigma2 image for", "More information : https://openvision.tech",
                                "%d, %t - (%s %r %m)", "release", "Welcome to openatv", "Welcome to teamblue",
                                "Welcome to openbh", "Welcome to openvix", "Welcome to openhdf",
                                "Welcome to opendroid", "Welcome to openspa", r"\n", r"\l", r"\\"
                            ]:
                                clean_line = clean_line.replace(r, "")
                            software += clean_line.strip().capitalize()[:-1]
                except Exception as e:
                    print("Error reading /etc/issue:", str(e))
                    software = ""

                # Get specific distro version details
                distro_mappings = {
                    "Egami": ("displaydistro", "imgversion", "imagedevbuild", " - R "),
                    "Openbh": ("displaydistro", "imgversion", "imagebuild", " "),
                    "Openvix": ("displaydistro", "imgversion", "imagebuild", " "),
                    "Openhdf": ("displaydistro", "imgversion", "imagebuild", " r"),
                    "Pure2": ("displaydistro", "imgversion", "imagedevbuild", " - R "),
                    "Openatv": ("displaydistro", "imgversion", "", ""),
                }

                for key, (distro, ver, build, sep) in distro_mappings.items():
                    if software.startswith(key):
                        try:
                            from Components.SystemInfo import BoxInfo
                            d = BoxInfo.getItem(distro)
                            v = BoxInfo.getItem(ver)
                            b = BoxInfo.getItem(build) if build else ""
                            software = d.upper() + " " + v + sep + b
                        except ImportError:
                            pass

                software = " : %s " % software.strip()

            # Check vtiversion override
            if isfile("/etc/vtiversion.info"):
                software = ""
                try:
                    with open("/etc/vtiversion.info", "r") as f:
                        for line in f:
                            parts = line.split()
                            if len(parts) >= 2:
                                software += parts[0].split("-")[0] + " " + parts[-1].replace("\n", "")
                    software = " : %s " % software.strip()
                except Exception as e:
                    print("Error reading /etc/vtiversion.info:", str(e))
                    pass

            return "%s%s" % (box, software)

        elif self.type == self.PythonVersion:
            pythonversion = ''
            try:
                from Screens.About import about
                pythonversion = 'Python' + ' ' + about.getPythonVersionString()
            except (ImportError, AttributeError):
                from sys import version_info
                pythonversion = 'Python' + ' ' + '%s.%s.%s' % (version_info.major, version_info.minor, version_info.micro)
            return '%s' % (pythonversion)

        elif self.type == self.CpuInfo:
            cpu_count = 0
            info = cpu_speed = cpu_info = core = ''
            core = _('core')
            cores = _('cores')
            if isfile('/proc/cpuinfo'):
                try:
                    with open('/proc/cpuinfo', 'r') as f:
                        for line in f:
                            if 'system type' in line:
                                info = line.split(':')[-1].split()[0].strip().strip('\n')
                            elif 'cpu MHz' in line:
                                cpu_speed = line.split(':')[-1].strip().strip('\n')
                            elif 'cpu type' in line:
                                info = line.split(':')[-1].strip().strip('\n')
                            elif 'model name' in line or 'Processor' in line:
                                info = line.split(':')[-1].strip().strip('\n').replace('Processor ', '')
                            elif line.startswith('processor'):
                                cpu_count += 1
                    if info.startswith('ARM') and isfile('/proc/stb/info/chipset'):
                        try:
                            with open('/proc/stb/info/chipset', 'r') as f:
                                chipset = f.readline().strip().lower()
                                chipset = chipset.replace('hi3798mv200', 'Hi3798MV200')
                                chipset = chipset.replace('bcm', 'BCM').replace('brcm', 'BCM')
                                chipset = chipset.replace('7444', 'BCM7444').replace('7278', 'BCM7278')
                                info = '%s (%s)' % (chipset, info)
                        except Exception:
                            pass
                    if not cpu_speed:
                        try:
                            with open('/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq', 'r') as f:
                                cpu_speed = int(f.read()) / 1000
                        except Exception:
                            try:
                                import binascii
                                with open('/sys/firmware/devicetree/base/cpus/cpu@0/clock-frequency', 'rb') as f:
                                    clockfrequency = f.read()
                                cpu_speed = "%s" % str(int(binascii.hexlify(clockfrequency), 16) / 1000000)
                            except Exception:
                                cpu_speed = '-'
                    if cpu_info == '':
                        return _('%s, %s MHz (%d %s)') % (info, cpu_speed, cpu_count, cpu_count > 1 and cores or core)
                except Exception as e:
                    print("Error reading CPU info:", str(e))
                    return _('Error')
            else:
                return _('No info')

        elif self.type == self.HddTemp:
            textvalue = 'No info'
            info = 'N/A'
            try:
                out_line = _run_command(['hddtemp', '-n', '-q', '/dev/sda'], 2.5)
                if out_line:
                    info = 'HDD: Temp:' + out_line[:2] + str('\xc2\xb0') + 'C'
                    textvalue = info
            except Exception:
                pass
            return textvalue

        elif self.type == self.TempInfo:
            info = "N/A"
            try:
                if exists("/proc/stb/sensors/temp0/value") and exists("/proc/stb/sensors/temp0/unit"):
                    with open("/proc/stb/sensors/temp0/value") as f_val, open("/proc/stb/sensors/temp0/unit") as f_unit:
                        value = f_val.read().strip()
                        unit = f_unit.read().strip()
                        info = "%s%s%s" % (value, "\xc2\xb0", unit)
                elif exists("/proc/stb/fp/temp_sensor_avs"):
                    with open("/proc/stb/fp/temp_sensor_avs") as f:
                        info = "%s%sC" % (f.read().strip(), "\xc2\xb0")
                elif exists("/proc/stb/fp/temp_sensor"):
                    with open("/proc/stb/fp/temp_sensor") as f:
                        info = "%s%sC" % (f.read().strip(), "\xc2\xb0")
                elif exists("/sys/devices/virtual/thermal/thermal_zone0/temp"):
                    with open("/sys/devices/virtual/thermal/thermal_zone0/temp") as f:
                        temp = f.read().strip()
                        info = "%s%sC" % (temp[:2], "\xc2\xb0")
                elif exists("/proc/hisi/msp/pm_cpu"):
                    try:
                        with open("/proc/hisi/msp/pm_cpu") as f:
                            content = f.read()
                            match = search(r"temperature = (\d+) degree", content)
                            if match:
                                info = "%s%sC" % (match.group(1), "\xc2\xb0")
                    except Exception:
                        pass
            except Exception as e:
                print("Error reading temperature:", str(e))
                info = "N/A"

            return info

        elif self.type == self.FanInfo:
            info = 'N/A'
            try:
                if exists('/proc/stb/fp/fan_speed'):
                    with open('/proc/stb/fp/fan_speed', 'r') as f:
                        info = f.read().strip('\n')
                elif exists('/proc/stb/fp/fan_pwm'):
                    with open('/proc/stb/fp/fan_pwm', 'r') as f:
                        info = f.read().strip('\n')
            except Exception as e:
                print("Error reading fan info:", str(e))
                info = 'N/A'
            if self.type is self.FanInfo:
                info = 'Fan: ' + info
            return info

        elif self.type == self.Upinfo:
            try:
                with open('/proc/uptime', 'r') as file:
                    uptime_info = file.read().split()
            except Exception as e:
                print("Error reading uptime:", str(e))
                return ' '
                uptime_info = None
            if uptime_info is not None:
                total_seconds = float(uptime_info[0])
                MINUTE = 60
                HOUR = MINUTE * 60
                DAY = HOUR * 24
                days = int(total_seconds / DAY)
                hours = int((total_seconds % DAY) / HOUR)
                minutes = int((total_seconds % HOUR) / MINUTE)
                # seconds = int(total_seconds % MINUTE)
                uptime = ''
                if days > 0:
                    uptime += str(days) + ' ' + (days == 1 and 'day' or 'days') + ' '
                if len(uptime) > 0 or hours > 0:
                    uptime += str(hours) + ' ' + (hours == 1 and 'hour' or 'hours') + ' '
                if len(uptime) > 0 or minutes > 0:
                    uptime += str(minutes) + ' ' + (minutes == 1 and 'minute' or 'minutes')
                return 'Time in work: %s' % uptime

        elif self.type == self.CpuLoad:
            info = ""
            load = ""
            try:
                if exists("/proc/loadavg"):
                    with open("/proc/loadavg", "r") as ls:
                        load = ls.readline(4)
            except Exception as e:
                print("Failed to read /proc/loadavg: " + str(e))
            info = load.replace("\n", "").replace(" ", "")
            return _("CPU Load: %s") % info

        elif self.type == self.CpuSpeed:
            info = 0
            try:
                with open('/proc/cpuinfo', 'r') as f:
                    for line in f:
                        line = [x.strip() for x in line.strip().split(':')]
                        if line[0] == 'cpu MHz':
                            info = '%1.0f' % float(line[1])
                if not info:
                    try:
                        with open('/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq', 'r') as f:
                            info = int(f.read()) / 1000
                    except Exception:
                        try:
                            import binascii
                            with open('/sys/firmware/devicetree/base/cpus/cpu@0/clock-frequency', 'rb') as f:
                                clock_data = f.read()
                            info = int(int(binascii.hexlify(clock_data), 16) / 100000000) * 100
                        except Exception:
                            info = '-'
                return 'CPU Speed: %s MHz' % info
            except Exception as e:
                print("Error reading CPU speed:", str(e))
                return ''

        elif self.type == self.SkinInfo:
            if fileExists('/etc/enigma2/settings'):
                try:
                    with open('/etc/enigma2/settings', 'r') as f:
                        for line in f:
                            if 'config.skin.primary_skin' in line:
                                return (_('Skin: ')) + line.replace('/skin.xml', ' ').split('=')[1]
                except Exception as e:
                    print("Error reading skin info:", str(e))
                    return _("Error")
            return _("Not available")

        elif self.type == self.TimeInfo:
            try:
                if not config.timezone.val.value.startswith('(GMT)'):
                    return config.timezone.val.value[4:7]
                else:
                    return '+0'
            except Exception:
                return '+0'

        elif self.type == self.TimeInfo2:
            try:
                if not config.timezone.val.value.startswith('(GMT)'):
                    return (_('Timezone: ')) + config.timezone.val.value[0:10]
                else:
                    return (_('Timezone: ')) + 'GMT+00:00'
            except Exception:
                return (_('Timezone: ')) + 'GMT+00:00'

        elif self.type == self.TimeInfo3:
            try:
                if not config.timezone.val.value.startswith('(GMT)'):
                    return (_('Timezone:')) + config.timezone.val.value[0:20]
                else:
                    return '+0'
            except Exception:
                return '+0'

        elif self.type == self.TimeInfo4:
            try:
                if not config.timezone.area.value.startswith('(GMT)'):
                    return (_('Part~of~the~light:')) + config.timezone.area.value[0:12]
                else:
                    return '+0'
            except Exception:
                return '+0'

        elif self.type == self.GstreamerVersion:
            return _("GStreamer: %s") % self.get_gstreamer_version()

        elif self.type == self.KernelVersion:
            return _("Kernel: %s") % self.get_kernel_version()

        elif self.type == self.OpenSslVersion:
            return _("OpenSSL: %s") % self.get_openssl_version()

        return _BOX_DEFAULTS.get(self.type, "")

    @cached
    def getText(self):
        # GUI-thread path: RAM lookup and a non-blocking queue operation only.
        _queue_box_refresh(self, force=False)
        return _box_cached_value(self.type)

    text = property(getText)