# -*- coding: utf-8 -*-
# recode from Islam Salama 2026
from __future__ import absolute_import
from Components.config import config
from PIL import Image
from enigma import getDesktop
import os
import shutil
import re
import requests

# --- Fast network pool (keeps connections alive; reduces latency) ---
try:
    _SESSION = requests.Session()
    # Use a modest pool to avoid stressing low-power receivers
    from requests.adapters import HTTPAdapter
    _SESSION.mount('http://', HTTPAdapter(pool_connections=4, pool_maxsize=4))
    _SESSION.mount('https://', HTTPAdapter(pool_connections=4, pool_maxsize=4))
except Exception:
    _SESSION = None
import socket
import sys
import threading
import unicodedata
import random
import json
from random import choice
from requests import get, exceptions
from twisted.internet.reactor import callInThread
from .furyConverlibr import quoteEventName, convtext, split_title_and_year, clean_search_title


try:
    from http.client import HTTPConnection
    HTTPConnection.debuglevel = 0
except ImportError:
    from httplib import HTTPConnection
    HTTPConnection.debuglevel = 0
from requests.adapters import HTTPAdapter, Retry

global my_cur_skin, srch

PY3 = False
if sys.version_info[0] >= 3:
    PY3 = True
    import html
    html_parser = html
else:
    from HTMLParser import HTMLParser
    html = HTMLParser()


try:
    from urllib.error import URLError, HTTPError
    from urllib.request import urlopen
except:
    from urllib2 import URLError, HTTPError
    from urllib2 import urlopen


try:
    lng = config.osd.language.value
    lng = lng[:-3]
except:
    lng = 'en'
    pass


def getRandomUserAgent():
    useragents = [
        'Mozilla/5.0 (compatible; Konqueror/4.5; FreeBSD) KHTML/4.5.4 (like Gecko)',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:29.0) Gecko/20120101 Firefox/29.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20120101 Firefox/35.0',
        'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0',
        'Mozilla/5.0 (X11; Linux x86_64; rv:28.0) Gecko/20100101 Firefox/28.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.13+ (KHTML, like Gecko) Version/5.1.7 Safari/534.57.2',
        'Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; de) Presto/2.9.168 Version/11.52',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101 Firefox/91.0'
    ]
    return random.choice(useragents)


tmdb_api = "3c3efcf47c3577558812bb9d64019d65"
omdb_api = "cb1d9f55"
# thetvdbkey = 'D19315B88B2DE21F'
thetvdbkey = "a99d487bb3426e5f3a60dea6d3d3c7ef"
fanart_api = "6d231536dea4318a88cb2520ce89473b"
my_cur_skin = False
cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')


try:
    if my_cur_skin is False:
        skin_paths = {
            "tmdb_api": "/usr/share/enigma2/{}/tmdbkey".format(cur_skin),
            "omdb_api": "/usr/share/enigma2/{}/omdbkey".format(cur_skin),
            "thetvdbkey": "/usr/share/enigma2/{}/thetvdbkey".format(cur_skin)
        }
        for key, path in skin_paths.items():
            if os.path.exists(path):
                with open(path, "r") as f:
                    value = f.read().strip()
                    if key == "tmdb_api":
                        tmdb_api = value
                    elif key == "omdb_api":
                        omdb_api = value
                    elif key == "thetvdbkey":
                        thetvdbkey = value
                my_cur_skin = True
except Exception as e:
    print("Errore nel caricamento delle API:", str(e))
    my_cur_skin = False


isz = "300,450"
screenwidth = getDesktop(0).size()
if screenwidth.width() <= 1280:
    isz = isz.replace(isz, "300,450")
elif screenwidth.width() <= 1920:
    isz = isz.replace(isz, "780,1170")
else:
    isz = isz.replace(isz, "1280,1920")

'''
isz = "w780"
"backdrop_sizes": [
      "w45",
      "w92",
      "w154",
      "w185",
      "w300",
      "w500",
      "w780",
      "w1280",
      "w1920",
      "original"
    ]
'''


# ---------------------------------------------------------------------
# Low bandwidth guard: prevent parallel duplicate backdrop image downloads.
# ---------------------------------------------------------------------
_download_guard_lock = threading.RLock()
_download_in_progress = set()

def _reserve_download_target(path):
    try:
        if not path:
            return False
        if os.path.exists(path) and os.path.getsize(path) > 0:
            return False
        with _download_guard_lock:
            if path in _download_in_progress:
                return False
            _download_in_progress.add(path)
            return True
    except Exception:
        return True

def _release_download_target(path):
    try:
        with _download_guard_lock:
            _download_in_progress.discard(path)
    except Exception:
        pass

BACKDROP_SEARCH_TIMEOUT = (2, 5)
BACKDROP_DOWNLOAD_TIMEOUT = (2, 8)
TMDB_BACKDROP_SIZE = "w780"

_adsl_ok = None

def intCheck(timeout=1):
    """Lightweight cached connectivity probe to keep renderer startup fast."""
    global _adsl_ok
    if _adsl_ok is not None:
        return _adsl_ok
    try:
        response = urlopen("http://google.com", None, timeout)
        response.close()
        _adsl_ok = True
    except HTTPError:
        _adsl_ok = False
    except URLError:
        _adsl_ok = False
    except socket.timeout:
        _adsl_ok = False
    except Exception:
        _adsl_ok = False
    return _adsl_ok


# ---------------------------------------------------------------------
# Albanian EPG title support (Digital Alb / Shqip)
# ---------------------------------------------------------------------
_ALBANIAN_TRANSLATE_CACHE = {}
_ALBANIAN_CHANNEL_HINTS = (
    'digital alb', 'digitalb', 'digit alb', 'alb premium', 'alb', 'shqip',
    'shqiptar', 'albania', 'kosova', 'kosovo', 'rtk', 'klan', 'top channel',
    'vizion plus', 'tring', 'artmotion', 'novelas+'
)
_ALBANIAN_WORD_HINTS = set([
    u'dhe', u'në', u'ne', u'për', u'per', u'nga', u'një', u'nje', u'është', u'eshte',
    u'vrasje', u'ambasadë', u'ambasade', u'lindja', u'dragoi', u'dragoit',
    u'hiri', u'kurajo', u'dashuri', u'jeta', u'familja', u'sekret', u'lufta',
    u'mbreti', u'zemra', u'hëna', u'hena', u'deti', u'natës', u'nates', u'dielli',
    u'bota', u'gruaja', u'vajza', u'djalë', u'djale', u'shtëpi', u'shtepi',
    u'pa', u'shtet', u'fund', u'tragjik', u'biri', u'bir', u'zdrukthëtarit', u'zdrukthetarit',
    u'zdrukthëtar', u'zdrukthetar', u'zjarr', u'hi', u'avatar', u'avatari', u'snajper',
    u'nusja', u'nuse', u'trendafili', u'trëndafili', u'tetëmbëdhjetë', u'tetembedhjete',
    u'rose', u'bride', u'violent', u'ends', u'carpenter', u'nation'
])



_ALBANIAN_TITLE_ALIAS_MAP = {
    u'trendafili i tetembedhjete': (u'18th Rose', u'Eighteenth Rose', u'The Eighteenth Rose'),
    u'trendafili tetembedhjete': (u'18th Rose', u'Eighteenth Rose', u'The Eighteenth Rose'),
    u'nusja': (u'The Bride!', u'The Bride'),
    u'snajper pa shtet': (u'Sniper: No Nation', u'Sniper No Nation'),
    u'fund tragjik': (u'Violent Ends',),
    u'avatari zjarr e hi': (u'Avatar: Fire and Ash',),
    u'avatar zjarr e hi': (u'Avatar: Fire and Ash',),
    u'biri i zdrukthetarit': (u"The Carpenter's Son", u'The Carpenter Son'),
    u'biri zdrukthetarit': (u"The Carpenter's Son", u'The Carpenter Son'),
}

# ---------------------------------------------------------------------
# Arabic channels with Latin EPG transliteration (Rotana Classic, etc.)
# ---------------------------------------------------------------------
# Some Arabic movie channels publish EPG titles in Latin transliteration.
# TMDB can then return a different Arabic title with a similar prefix, e.g.
# "Resalet Gharaam" -> "رسالة الإمام".  These aliases make the first lookup
# use the real Arabic title, and the stricter Arabic word check below rejects
# one-word/loose false positives.
_ARABIC_LATIN_TITLE_ALIAS_MAP = {
    u'resalet gharam': (u'رسالة غرام', u'Resalet Gharam', u'Resalat Gharam'),
    u'resalat gharam': (u'رسالة غرام', u'Resalet Gharam', u'Resalat Gharam'),
    u'kolohom awladi': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kolhom awladi': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'prayer el caravan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'prayer al caravan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'doaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer'),
    u'duaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer'),
    u'mawed ma eblees': (u'موعد مع إبليس', u'Mawed Maa Eblis'),
    u'mawed maa eblees': (u'موعد مع إبليس', u'Mawed Maa Eblis'),
    u'el anesa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anesa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'el anisa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anisa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al habeb al maghol': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'el habeb el maghol': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'al habib al majhoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'el kaf': (u'الكف', u'El Kaf'),
    u'al kaf': (u'الكف', u'El Kaf'),
    u'nehayet el tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nihayet el tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nehayet al tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'al rakesa wal tabaal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'el rakesa wal tabaal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'al raqisa wal tabal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'al ghawwas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawwas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'ghesh el zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish el zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish al zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish el zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgiya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgiya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgia': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgia': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawjeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'el ghawwas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawwas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'kolohom awlady': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kolhom awlady': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kollohom awladi': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kollohom awlady': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'doaa el karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'doaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'duaa el karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'duaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'el anesa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anesa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'el anisa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anisa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'el habib el maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'al habib al maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'el habeb el maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'al habeb al maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'nehayet el tarik': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nihayet el tarik': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nehayet al tarik': (u'نهاية الطريق', u'Nehayet El Tareek'),
}


def _arabic_latin_norm_key(value):
    try:
        txt = _alb_to_text(value).lower()
        txt = txt.replace(u'’', u' ').replace(u"'", u' ')
        txt = re.sub(u'[^a-z0-9]+', ' ', txt, flags=re.UNICODE)
        txt = re.sub(r'a{2,}', 'a', txt)
        txt = re.sub(r'e{2,}', 'e', txt)
        txt = re.sub(r'i{2,}', 'i', txt)
        txt = re.sub(r'o{2,}', 'o', txt)
        txt = re.sub(r'u{2,}', 'u', txt)
        txt = re.sub(r'\s+', ' ', txt).strip()
        return txt
    except Exception:
        return ''


def _arabic_latin_title_aliases(value):
    try:
        key = _arabic_latin_norm_key(value)
        if not key:
            return []
        aliases = []
        for k, vals in _ARABIC_LATIN_TITLE_ALIAS_MAP.items():
            kk = _arabic_latin_norm_key(k)
            # exact match, or exact title plus channel/noise suffix.
            if key == kk or key.startswith(kk + ' ') or (len(kk) >= 8 and kk in key):
                for v in vals:
                    if v and v not in aliases:
                        aliases.append(v)
        return aliases[:5]
    except Exception:
        return []


def _fx_arabic_words(value):
    try:
        n = _fx_norm_title(value)
        stop = set([u'ال', u'و', u'في', u'من', u'علي', u'على', u'مع', u'يا'])
        return [w for w in n.split() if len(w) > 1 and w not in stop]
    except Exception:
        return []


def _fx_is_clear_arabic_title_mismatch(query, found):
    try:
        if not (_fx_contains_arabic(query) and _fx_contains_arabic(found)):
            return False
        qn = _fx_norm_title(query)
        fn = _fx_norm_title(found)
        if not qn or not fn:
            return False
        if qn == fn or qn in fn or fn in qn:
            return False
        qw = set(_fx_arabic_words(query))
        fw = set(_fx_arabic_words(found))
        if len(qw) >= 2 and len(fw) >= 2:
            common = qw.intersection(fw)
            ratio = int(SequenceMatcher(None, qn, fn).ratio() * 100)
            if not common:
                return True
            # Sharing only a generic first word is how "رسالة غرام" matched
            # "رسالة الإمام". Keep close typos, reject loose one-word matches.
            if len(common) == 1 and ratio < 72:
                return True
        return False
    except Exception:
        return False


def _albanian_norm_key(value):
    try:
        txt = _alb_to_text(value).lower()
        repl = ((u'ë', u'e'), (u'ç', u'c'), (u'á', u'a'), (u'à', u'a'), (u'ä', u'a'),
                (u'é', u'e'), (u'è', u'e'), (u'í', u'i'), (u'ì', u'i'), (u'ó', u'o'),
                (u'ò', u'o'), (u'ú', u'u'), (u'ù', u'u'))
        for src, dst in repl:
            txt = txt.replace(src, dst)
        txt = re.sub(u'[^a-z0-9]+', ' ', txt, flags=re.UNICODE)
        txt = re.sub(r'\s+', ' ', txt).strip()
        return txt
    except Exception:
        return ''


def _albanian_title_aliases(value):
    try:
        key = _albanian_norm_key(value)
        if not key:
            return []
        aliases = []
        for k, vals in _ALBANIAN_TITLE_ALIAS_MAP.items():
            if key == k or (len(key) >= 6 and (key in k or k in key)):
                for v in vals:
                    if v and v not in aliases:
                        aliases.append(v)
        return aliases[:4]
    except Exception:
        return []
def _alb_to_text(val):
    try:
        if val is None:
            return u''
        if isinstance(val, bytes):
            return val.decode('utf-8', 'ignore')
        try:
            return unicode(val)  # type: ignore[name-defined]
        except Exception:
            return str(val)
    except Exception:
        try:
            return str(val)
        except Exception:
            return u''

def _is_albanian_channel(channel):
    try:
        ch = _alb_to_text(channel).lower()
        ch = re.sub(r'[^a-z0-9+]+', ' ', ch)
        ch = re.sub(r'\s+', ' ', ch).strip()
        if not ch:
            return False
        for hint in _ALBANIAN_CHANNEL_HINTS:
            h = hint.lower()
            if h == 'alb':
                if re.search(r'\balb\b', ch):
                    return True
            elif h in ch:
                return True
        return False
    except Exception:
        return False

def _looks_albanian_text(title):
    try:
        txt = _alb_to_text(title)
        if not txt:
            return False
        if _albanian_title_aliases(txt):
            return True
        if re.search(u'[ëËçÇ]', txt):
            return True
        words = re.findall(u"[A-Za-zëËçÇ]+", txt.lower())
        if not words:
            return False
        hits = 0
        for w in words:
            if w in _ALBANIAN_WORD_HINTS:
                hits += 1
        # One strong Albanian word like 'dhe', 'lindja', 'dragoit' is enough
        # for EPG titles; otherwise require at least two softer hints.
        if any(w in words for w in ('dhe', 'lindja', 'dragoit', 'dragoi', 'vrasje', 'hiri', 'kurajo')):
            return True
        return hits >= 2
    except Exception:
        return False

def _translate_albanian_query(title, channel=None):
    try:
        src = _alb_to_text(title).replace('+', ' ')
        src = re.sub(r'\s+', ' ', src).strip(' -:|')
        if not src or len(src) < 3:
            return None
        if not (_is_albanian_channel(channel) or _looks_albanian_text(src)):
            return None
        key = src.lower()
        if key in _ALBANIAN_TRANSLATE_CACHE:
            return _ALBANIAN_TRANSLATE_CACHE.get(key)
        aliases = _albanian_title_aliases(src)
        if aliases:
            _ALBANIAN_TRANSLATE_CACHE[key] = aliases[0]
            return aliases[0]
        try:
            resp = requests.get(
                'https://translate.googleapis.com/translate_a/single',
                params={'client': 'gtx', 'sl': 'auto', 'tl': 'en', 'dt': 't', 'q': src},
                headers={'User-Agent': getRandomUserAgent()},
                timeout=(2, 4),
                verify=False
            )
            data = resp.json()
            translated = u''
            try:
                translated = u''.join(_alb_to_text(part[0]) for part in data[0] if part and len(part) > 0 and part[0])
            except Exception:
                translated = u''
            translated = re.sub(r'\s+', ' ', translated).strip(' -:|')
            if not translated or len(translated) < 3:
                translated = None
            if translated and translated.lower() == src.lower():
                translated = None
            _ALBANIAN_TRANSLATE_CACHE[key] = translated
            return translated
        except Exception:
            _ALBANIAN_TRANSLATE_CACHE[key] = None
            return None
    except Exception:
        return None


class furyBackdropXDownloadThread(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.adsl = intCheck(timeout=1)
        # Do not return early: the worker should still initialize cleanly and can
        # retry lookups when connectivity comes back.
        if not self.adsl:
            print("Connessione assente/instabile, modalità offline (will recheck).")
        else:
            print("Connessione rilevata.")
        self.checkMovie = ["film", "movie", "фильм", "кино", "ταινία",
                           "película", "cinéma", "cine", "cinema",
                           "filma"]
        self.checkTV = ["serial", "series", "serie", "serien", "série",
                        "séries", "serious", "folge", "episodio",
                        "episode", "épisode", "l'épisode", "ep.",
                        "animation", "staffel", "soap", "doku", "tv",
                        "talk", "show", "news", "factual",
                        "entertainment", "telenovela", "dokumentation",
                        "dokutainment", "documentary", "informercial",
                        "information", "sitcom", "reality", "program",
                        "magazine", "mittagsmagazin", "т/с", "м/с",
                        "сезон", "с-н", "эпизод", "сериал", "серия",
                        "actualité", "discussion", "interview", "débat",
                        "émission", "divertissement", "jeu", "magasine",
                        "information", "météo", "journal", "sport",
                        "culture", "infos", "feuilleton", "téléréalité",
                        "société", "clips", "concert", "santé",
                        "éducation", "variété"]


    def _extract_year(self, description):
        """Extract the first plausible production year from EPG text."""
        try:
            year_matches = re.findall(r"19\d{2}|20\d{2}", description or "")
            return year_matches[0] if year_matches else ""
        except Exception:
            return ""

    def _normalize_match_title(self, value):
        """Normalize Latin and Arabic titles for strict result ranking."""
        try:
            value = str(value or "").lower().strip()
            value = value.replace("&", " and ")
            value = re.sub(u'[\u064b-\u065f\u0670\u0640]', '', value)
            value = value.replace(u'أ', u'ا').replace(u'إ', u'ا').replace(u'آ', u'ا')
            value = value.replace(u'ى', u'ي').replace(u'ؤ', u'و').replace(u'ئ', u'ي')
            value = re.sub(r"[^a-z0-9\u0600-\u06FF]+", " ", value)
            value = re.sub(r"\s+", " ", value).strip()
            return value
        except Exception:
            return str(value or "").lower().strip()

    def _contains_arabic(self, value):
        try:
            return bool(re.search(u'[\u0600-\u06FF]', str(value or "")))
        except Exception:
            return False

    def _tmdb_language_candidates(self, title):
        """Prefer Arabic for Arabic titles, then safe fallbacks."""
        candidates = []
        def add(lang):
            if not lang:
                return
            lang = str(lang).strip()
            if lang and lang not in candidates:
                candidates.append(lang)
        if self._contains_arabic(title):
            add("ar")
            add("ar-SA")
            add("en-US")
            add("en")
        else:
            lang = (lng or "en").strip()
            lang_map = {
                "en": "en-US", "ar": "ar-SA", "fr": "fr-FR", "it": "it-IT",
                "de": "de-DE", "es": "es-ES", "pt": "pt-BR", "ru": "ru-RU",
                "tr": "tr-TR", "sq": "sq-AL",
            }
            add(lang_map.get(lang, lang))
            add(lang[:2])
            add("en-US")
            add("en")
            add("ar")
        return candidates

    def _select_best_tmdb_result(self, results, title_safe, shortdesc="", fulldesc="", year=None, image_key="poster_path"):
        """Score TMDB results instead of accepting the first item blindly."""
        target = self._normalize_match_title(title_safe)
        srch, _fd = self.checkType(shortdesc, fulldesc)
        def _tmdb_meaningful_tokens(value):
            try:
                n = self._normalize_match_title(value)
                stop = set([u'al', u'el', u'the', u'a', u'an', u'and', u'of', u'wa', u'wal', u'بن', u'ابن', u'ال', u'و', u'في', u'من', u'مع', u'يا'])
                return [w for w in n.split() if len(w) > 1 and w not in stop]
            except Exception:
                return []

        candidates = []
        for each in results or []:
            try:
                media_type = str(each.get('media_type') or '').lower()
                if media_type == 'tv':
                    media_type = 'serie'
                if not media_type:
                    media_type = 'serie' if srch in ('tv', 'serie') else 'movie'
                if media_type not in ('movie', 'serie'):
                    continue
                if not each.get(image_key):
                    continue

                title = each.get('name') or each.get('title') or ''
                original_title = each.get('original_name') or each.get('original_title') or ''
                title_n = self._normalize_match_title(title)
                orig_n = self._normalize_match_title(original_title)

                direct_match = False
                if target:
                    if title_n == target or orig_n == target:
                        direct_match = True
                    elif title_n and (target in title_n or title_n in target):
                        direct_match = True
                    elif orig_n and (target in orig_n or orig_n in target):
                        direct_match = True
                try:
                    target_tokens = set(_tmdb_meaningful_tokens(target))
                    result_tokens = set(_tmdb_meaningful_tokens(title_n) + _tmdb_meaningful_tokens(orig_n))
                    token_hit = bool(target_tokens and result_tokens and target_tokens.intersection(result_tokens))
                except Exception:
                    token_hit = False
                # Do not accept a TMDB result only because it has the same media type.
                # This prevents Arabic/Latin-transliterated EPG titles from receiving
                # unrelated posters like "Redirected" when the title text does not match.
                if target and not direct_match and not token_hit:
                    continue

                result_year = ''
                if media_type == 'movie':
                    result_year = (each.get('release_date') or '')[:4]
                else:
                    result_year = (each.get('first_air_date') or '')[:4]

                score = 0
                if title_n == target:
                    score += 500
                if orig_n == target:
                    score += 450
                if target and title_n and (target in title_n or title_n in target):
                    score += 130
                if target and orig_n and (target in orig_n or orig_n in target):
                    score += 110
                if self._contains_arabic(title_safe) and self._contains_arabic(title):
                    score += 90

                if srch == 'movie' and media_type == 'movie':
                    score += 200
                elif srch in ('tv', 'serie') and media_type == 'serie':
                    score += 200
                elif srch == 'multi':
                    score += 30 if media_type == 'movie' else 10

                if year:
                    if result_year:
                        if str(year) == str(result_year):
                            score += 600
                        elif media_type != 'serie':
                            score -= 500
                    elif media_type != 'serie':
                        score -= 120

                try:
                    score += min(float(each.get('popularity') or 0), 20)
                    score += min(float(each.get('vote_average') or 0), 10)
                except Exception:
                    pass

                candidates.append((each, score, result_year))
            except Exception:
                continue

        if not candidates:
            return None, -1
        if year:
            exact_year = [(item, score) for item, score, result_year in candidates if str(result_year) == str(year)]
            if exact_year:
                exact_year.sort(key=lambda x: x[1], reverse=True)
                return exact_year[0][0], exact_year[0][1]
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][0], candidates[0][1]
    def search_tmdb(self, dwn_backdrop, title, shortdesc, fulldesc, channel=None, alias_paths=None, year=None):
        """Search TMDB using cleaned titles, Arabic-aware language, year ranking and strict result scoring."""
        def _strip_year_for_search(value):
            value = str(value or "").strip()
            value = re.sub(r"\s*[\(\[]\s*(?:19|20)\d{2}\s*[\)\]]\s*", " ", value)
            value = re.sub(r"(?<!^)\s+(?:19|20)\d{2}\s*$", "", value)
            return re.sub(r"\s+", " ", value).strip()

        try:
            self.dwn_backdrop = dwn_backdrop
            self._alias_paths = alias_paths
            if not dwn_backdrop or not title:
                return False, "[SKIP : tmdb] Invalid input"

            clean_input_title = (title or "").replace("+", " ").replace('–', '').strip()
            try:
                split_title, forced_year = split_title_and_year(clean_input_title)
            except Exception:
                split_title, forced_year = clean_input_title, ""
            local_title_safe = clean_search_title(_strip_year_for_search(split_title))
            if not local_title_safe:
                return False, "[SKIP : tmdb] Invalid title after cleaning"

            srch, fd = self.checkType(shortdesc, fulldesc)
            if not year:
                year = self._extract_year(fd)
            if forced_year and not year:
                year = forced_year
            rank_year = "" if srch in ("tv", "serie") else (year or "")

            search_types = [srch] if srch in ("movie", "tv") else ["multi", "movie", "tv"]
            lang_candidates = self._tmdb_language_candidates(local_title_safe)
            arabic_latin_aliases = []
            try:
                arabic_latin_aliases.extend(_arabic_latin_title_aliases(local_title_safe))
                for _a in _arabic_latin_title_aliases(clean_input_title):
                    if _a not in arabic_latin_aliases:
                        arabic_latin_aliases.append(_a)
            except Exception:
                arabic_latin_aliases = []
            if arabic_latin_aliases:
                query_candidates = []
                for _a in arabic_latin_aliases:
                    if _a.lower() not in [q.lower() for q in query_candidates]:
                        query_candidates.append(_a)
                # Arabic aliases must be searched in Arabic first.  Avoid putting
                # the noisy Latin transliteration first, because it can match a
                # different Arabic title with the same prefix.
                for _l in ("ar", "ar-SA", "en-US", "en"):
                    if _l not in lang_candidates:
                        lang_candidates.insert(0 if _l.startswith('ar') else len(lang_candidates), _l)
            else:
                query_candidates = [local_title_safe]
            for alias in _albanian_title_aliases(local_title_safe):
                if alias.lower() not in [q.lower() for q in query_candidates]:
                    query_candidates.append(alias)
            if (not arabic_latin_aliases) and clean_input_title and clean_input_title.lower() != local_title_safe.lower():
                query_candidates.append(clean_input_title)
            translated_al = None
            try:
                translated_al = _translate_albanian_query(local_title_safe, channel)
            except Exception:
                translated_al = None
            if translated_al and translated_al.lower() not in [q.lower() for q in query_candidates]:
                query_candidates.append(translated_al)

            headers = {'User-Agent': getRandomUserAgent()}
            getter_session = _SESSION if ("_SESSION" in globals() and _SESSION is not None) else requests.Session()
            timeout_value = globals().get('BACKDROP_SEARCH_TIMEOUT', (8, 15))
            for query_try in query_candidates[:5]:
                self.title_safe = query_try
                for search_type in search_types:
                    for lang_try in lang_candidates[:4]:
                        params = {
                            "api_key": tmdb_api,
                            "query": query_try,
                            "language": lang_try,
                            "include_adult": "false",
                            "page": "1",
                        }
                        if year and search_type in ("movie", "multi"):
                            params["year"] = str(year)
                        url = "https://api.themoviedb.org/3/search/{}".format(search_type)
                        response = getter_session.get(url, params=params, headers=headers, timeout=timeout_value, verify=False)
                        response.raise_for_status()
                        data = response.json()
                        if not data or not data.get('results'):
                            continue
                        ok, log = self.downloadData2(
                            data,
                            dwn_backdrop,
                            shortdesc,
                            fulldesc,
                            title_safe=query_try,
                            search_year=rank_year,
                            alias_paths=alias_paths
                        )
                        if ok and os.path.exists(dwn_backdrop) and os.path.getsize(dwn_backdrop) > 0:
                            return True, log
            return False, "[SKIP : tmdb] Not found"
        except Exception as e:
            try:
                if dwn_backdrop and os.path.exists(dwn_backdrop):
                    os.remove(dwn_backdrop)
            except Exception:
                pass
            return False, "[ERROR : tmdb] {}".format(str(e))

    def downloadData2(self, data, dwn_backdrop=None, shortdesc="", fulldesc="", title_safe="", search_year="", alias_paths=None):
        """Select the highest-scoring TMDB backdrop result and save it."""
        try:
            dwn_backdrop = dwn_backdrop or getattr(self, 'dwn_backdrop', None)
            if isinstance(data, bytes):
                data = data.decode('utf-8', 'ignore')
            data_json = data if isinstance(data, dict) else json.loads(data)
            results = data_json.get('results') or []
            if not results:
                return False, "[SKIP : tmdb] Empty results"
            best, best_score = self._select_best_tmdb_result(
                results,
                title_safe or getattr(self, 'title_safe', ''),
                shortdesc,
                fulldesc,
                search_year or self._extract_year(fulldesc or shortdesc or ""),
                image_key="backdrop_path"
            )
            if not best:
                return False, "[SKIP : tmdb] No valid result"
            backdrop_path = best.get('backdrop_path')
            if not backdrop_path:
                return False, "[SKIP : tmdb] No backdrop path"
            title = best.get('name') or best.get('title') or ''
            original_title = best.get('original_name') or best.get('original_title') or ''
            result_year = ((best.get('release_date') or best.get('first_air_date') or '')[:4])
            backdrop_url = "https://image.tmdb.org/t/p/{}{}".format(globals().get('TMDB_BACKDROP_SIZE', 'w780'), backdrop_path)
            self.savebackdrop(backdrop_url, dwn_backdrop, alias_paths if alias_paths is not None else getattr(self, '_alias_paths', None))
            if dwn_backdrop and os.path.exists(dwn_backdrop) and os.path.getsize(dwn_backdrop) > 0:
                show_title = title or original_title
                if result_year:
                    show_title = "{} ({})".format(show_title, result_year)
                return True, "[SUCCESS backdrop: tmdb] {} score={} => {}".format(show_title, int(best_score), backdrop_url)
            return False, "[SKIP : tmdb] Download failed"
        except Exception as e:
            try:
                dwn_backdrop = dwn_backdrop or getattr(self, 'dwn_backdrop', None)
                if dwn_backdrop and os.path.exists(dwn_backdrop):
                    os.remove(dwn_backdrop)
            except Exception:
                pass
            return False, "[ERROR : tmdb] {}".format(str(e))

            # Match furyPosterX behavior: preferred OSD language first, then en-US fallback.
            lang = (lng or "en").strip()
            lang_map = {
                "en": "en-US",
                "ar": "ar-SA",
                "fr": "fr-FR",
                "it": "it-IT",
                "de": "de-DE",
                "es": "es-ES",
                "pt": "pt-BR",
                "ru": "ru-RU",
                "tr": "tr-TR",
                "sq": "sq-AL",
            }
            lang_tag = lang_map.get(lang, lang)
            lang_candidates = [lang_tag]
            if _is_albanian_channel(channel) or _looks_albanian_text(title_safe):
                for _l in ("sq-AL", "sq"):
                    if _l not in lang_candidates:
                        lang_candidates.append(_l)
            if lang_tag != "en-US":
                lang_candidates.append("en-US")

            query_candidates = [title_safe]
            translated_al = _translate_albanian_query(title_safe, channel)
            if translated_al and translated_al.lower() != title_safe.lower():
                query_candidates.append(translated_al)

            headers = {'User-Agent': getRandomUserAgent()}
            getter = _SESSION.get if ("_SESSION" in globals() and _SESSION is not None) else requests.get

            for query_try in query_candidates:
                for lang_try in lang_candidates:
                    params = {
                        "api_key": tmdb_api,
                        "language": lang_try,
                        "query": query_try,
                        "include_adult": "false",
                        "page": "1",
                    }
                    response = getter(
                        "https://api.themoviedb.org/3/search/multi",
                        params=params,
                        headers=headers,
                        timeout=BACKDROP_SEARCH_TIMEOUT,
                        verify=False,
                    )
                    response.raise_for_status()
                    if response.status_code != requests.codes.ok:
                        continue
                    res = self.downloadData2(response.json())
                    if res:
                        ok, log = res
                        if ok and os.path.exists(self.dwn_backdrop) and os.path.getsize(self.dwn_backdrop) > 0:
                            return True, log

            return False, "[SKIP : tmdb] Not found"
        except Exception as e:
            try:
                if self.dwn_backdrop and os.path.exists(self.dwn_backdrop):
                    os.remove(self.dwn_backdrop)
            except Exception:
                pass
            print('Errore nella ricerca TMDb:', e)
            return False, "[ERROR : tmdb] {}".format(str(e))


            for each in results:
                media_type = str(each.get('media_type') or '')
                if media_type == "tv":
                    media_type = "serie"
                if media_type not in ('serie', 'movie'):
                    continue

                title = each.get('name') or each.get('title') or ''
                bp = each.get('backdrop_path')
                if not bp:
                    continue

                backdrop = "https://image.tmdb.org/t/p/{}{}".format(TMDB_BACKDROP_SIZE, bp)
                self.savebackdrop(backdrop, self.dwn_backdrop, getattr(self, '_alias_paths', None))
                if os.path.exists(self.dwn_backdrop) and os.path.getsize(self.dwn_backdrop) > 0:
                    return True, "[SUCCESS backdrop: tmdb] title {} => {}".format(title, backdrop)

            return False, "[SKIP : tmdb] Not found"
        except Exception as e:
            try:
                if self.dwn_backdrop and os.path.exists(self.dwn_backdrop):
                    os.remove(self.dwn_backdrop)
            except Exception:
                pass
            return False, "[ERROR : tmdb] {}".format(str(e))

    def search_omdb(self, dwn_backdrop, title, shortdesc, fulldesc, channel=None, alias_paths=None):
        try:
            self.dwn_backdrop = dwn_backdrop
            self._alias_paths = alias_paths
            title_safe = title.replace('+', ' ')
            url = f"http://www.omdbapi.com/?apikey={omdb_api}&t={title_safe}"
            headers = {'User-Agent': getRandomUserAgent()}
            response = requests.get(url, headers=headers, timeout=(10, 20))
            response.raise_for_status()
            if response.status_code == requests.codes.ok:
                data = response.json()
                if 'Poster' in data and data['Poster'] != 'N/A':
                    backdrop_url = data['Poster']
                    self.savebackdrop(backdrop_url, self.dwn_backdrop, getattr(self, '_alias_paths', None))
                    return True, f"[SUCCESS backdrop: omdb] title {title_safe} => {backdrop_url}"
                else:
                    return False, f"[SKIP : omdb] {title_safe} => Backdrop not found"
            else:
                return False, f"Errore durante la ricerca su OMDB: {response.status_code}"
        except Exception as e:
            print('Errore nella ricerca OMDB:', e)
            return False, "Errore durante la ricerca su OMDB"

    def savebackdrop(self, url, callback, alias_paths=None):
        """Download an image and persist as a real JPEG compatible with Enigma2 loadJPG().

        Performance-oriented:
          - smaller TMDb size (w780) upstream
          - pooled connections via requests.Session
          - atomic writes ('.part' then rename)
          - avoid JPEG optimize pass (CPU-heavy on receivers)
          - if payload is already JPEG, write bytes directly (no PIL conversion)
        """
        headers = {"User-Agent": getRandomUserAgent()}
        part_path = callback + ".part"
        reserved = _reserve_download_target(callback)
        if not reserved:
            return callback
        try:
            if isinstance(url, bytes):
                url = url.decode("utf-8", "ignore")

            getter = _SESSION.get if ("_SESSION" in globals() and _SESSION is not None) else requests.get

            # First request headers; we keep stream=True only for JPEG to reduce memory
            response = getter(url, headers=headers, timeout=BACKDROP_DOWNLOAD_TIMEOUT, stream=True, verify=False)
            response.raise_for_status()

            ctype = (response.headers.get("Content-Type") or "").lower()
            header_says_jpeg = ("image/jpeg" in ctype) or ("image/jpg" in ctype)

            if header_says_jpeg:
                # Stream JPEG to disk; validate magic from first chunk
                first_chunk = None
                with open(part_path, "wb") as f:
                    for chunk in response.iter_content(chunk_size=64 * 1024):
                        if not chunk:
                            continue
                        if first_chunk is None:
                            first_chunk = chunk
                            if first_chunk[:2] != b"\xff\xd8":
                                header_says_jpeg = False
                                break
                        f.write(chunk)

                if header_says_jpeg and first_chunk is not None:
                    try:
                        if os.path.exists(callback):
                            os.remove(callback)
                    except Exception:
                        pass
                    os.rename(part_path, callback)
                else:
                    try:
                        if os.path.exists(part_path):
                            os.remove(part_path)
                    except Exception:
                        pass

            if not header_says_jpeg:
                # Fetch full payload (non-JPEG like WebP/PNG, or invalid JPEG)
                try:
                    # If stream was consumed above, re-request without stream for simplicity
                    response2 = getter(url, headers=headers, timeout=BACKDROP_DOWNLOAD_TIMEOUT, stream=False, verify=False)
                    response2.raise_for_status()
                    payload = response2.content
                except Exception:
                    payload = response.content

                from io import BytesIO
                bio = BytesIO(payload)
                img = Image.open(bio)
                if img.mode not in ("RGB", "L"):
                    img = img.convert("RGB")
                elif img.mode == "L":
                    img = img.convert("RGB")

                img.save(part_path, "JPEG", quality=85, optimize=False)
                try:
                    img.close()
                except Exception:
                    pass

                try:
                    if os.path.exists(callback):
                        os.remove(callback)
                except Exception:
                    pass
                os.rename(part_path, callback)

            # Create aliases (legacy title-based filenames, etc.)
            try:
                if alias_paths:
                    if not isinstance(alias_paths, (list, tuple)):
                        alias_paths = [alias_paths]
                    for ap in alias_paths:
                        if not ap or ap == callback:
                            continue
                        if os.path.exists(ap):
                            continue
                        try:
                            os.link(callback, ap)
                        except Exception:
                            try:
                                shutil.copy2(callback, ap)
                            except Exception:
                                pass
            except Exception:
                pass

        except Exception as error:
            try:
                if os.path.exists(part_path):
                    os.remove(part_path)
            except Exception:
                pass
            print("ERROR in module 'download': %s" % (str(error)))
        finally:
            _release_download_target(callback)
        return callback

    def resizebackdrop(self, dwn_backdrop):
        try:
            img = Image.open(dwn_backdrop)
            width, height = img.size
            ratio = float(width) // float(height)
            new_height = int(isz.split(",")[1])
            new_width = int(ratio * new_height)
            rimg = img.resize((new_width, new_height), Image.LANCZOS)
            img.close()
            rimg.save(dwn_backdrop)
            rimg.close()
        except Exception as e:
            print("ERROR:{}".format(e))

    def verifybackdrop(self, dwn_backdrop):
        try:
            img = Image.open(dwn_backdrop)
            img.verify()
            if img.format == "JPEG":
                pass
            else:
                os.remove(dwn_backdrop)
                return False
        except Exception as e:
            print(e)
            os.remove(dwn_backdrop)
            return False
        return True

    def checkType(self, shortdesc, fulldesc):
        fd = shortdesc.splitlines()[0] if shortdesc else fulldesc.splitlines()[0] if fulldesc else ''
        global srch
        srch = "multi"
        return srch, fd

    def UNAC(self, string):
        string = html.unescape(string)
        string = unicodedata.normalize('NFD', string)
        string = re.sub(r"u0026", "&", string)
        string = re.sub(r"u003d", "=", string)
        string = re.sub(r'[\u0300-\u036f]', '', string)
        string = re.sub(r"[,!?\.\"]", ' ', string)
        string = re.sub(r'\s+', ' ', string)
        string = string.strip()
        return string

    def PMATCH(self, textA, textB):
        if not textB or not textA:
            return 0
        if textA == textB or textA.replace(" ", "") == textB.replace(" ", ""):
            return 100
        lId = len(textA.replace(" ", "")) if len(textA) > len(textB) else len(textB.replace(" ", ""))
        cId = sum(len(id) for id in textA.split() if id in textB)
        return 100 * cId // lId

class BackdropDB(furyBackdropXDownloadThread):
    def __init__(self):
        furyBackdropXDownloadThread.__init__(self)
        self.logdbg = None
        self.pstcanal = None

    def run(self):
        self.logDB("[QUEUE] : Initialized")
        while True:
            canal = pdb.get()
            self.logDB("[QUEUE] : {} : {}-{} ({})".format(canal[0], canal[1], canal[2], canal[5]))
            self.pstcanal = convtext(canal[5])

            if self.pstcanal is not None:
                dwn_backdrop = os.path.join(path_folder, self.pstcanal + ".jpg")
            else:
                print("None type detected - backdrop not found")
                pdb.task_done()  # Per evitare il blocco del thread
                continue

            if os.path.exists(dwn_backdrop):
                os.utime(dwn_backdrop, (time.time(), time.time()))

            # Prioritized search order
            if not os.path.exists(dwn_backdrop):
                val, log = self.search_tmdb(dwn_backdrop, self.pstcanal, canal[4], canal[3])
                self.logDB(log)
            if not os.path.exists(dwn_backdrop):
                val, log = self.search_tvdb(dwn_backdrop, self.pstcanal, canal[4], canal[3])
                self.logDB(log)
            if not os.path.exists(dwn_backdrop):
                val, log = self.search_fanart(dwn_backdrop, self.pstcanal, canal[4], canal[3])
                self.logDB(log)
            if not os.path.exists(dwn_backdrop):
                val, log = self.search_imdb(dwn_backdrop, self.pstcanal, canal[4], canal[3])
                self.logDB(log)
            if not os.path.exists(dwn_backdrop):
                val, log = self.search_programmetv_google(dwn_backdrop, self.pstcanal, canal[4], canal[3], canal[0])
                self.logDB(log)
            if not os.path.exists(dwn_backdrop):
                val, log = self.search_omdb(dwn_backdrop, self.pstcanal, canal[4], canal[3])
                self.logDB(log)
            pdb.task_done()

    def logDB(self, logmsg):
        try:
            with open("/tmp/BackdropDB.log", "a") as w:
                w.write("%s\n" % logmsg)
        except Exception as e:
            print('logDB error:', str(e))
            traceback.print_exc()