# -*- coding: utf-8 -*-

# recode from Islam Salama 2026

# Improving the performance of information and poster retrieval by Islam Salama
from __future__ import print_function
from Components.Renderer.Renderer import Renderer
from Components.Renderer.furyPosterXDownloadThread import furyPosterXDownloadThread
from Components.Sources.CurrentService import CurrentService
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.ServiceEvent import ServiceEvent
from Components.config import config
from ServiceReference import ServiceReference
from enigma import (
    ePixmap,
    loadJPG,
    eEPGCache,
    eTimer,
)
import NavigationInstance
import os
import socket
import sys
import hashlib
import time
import traceback
import datetime
import threading
import re
import json
from .furyConverlibr import convtext

PY3 = False
if sys.version_info[0] >= 3:
    PY3 = True
    import queue
    from _thread import start_new_thread
    from urllib.error import HTTPError, URLError
    from urllib.parse import quote_plus
    from urllib.request import urlopen
else:
    import Queue
    from thread import start_new_thread
    from urllib import quote_plus
    from urllib2 import HTTPError, URLError
    from urllib2 import urlopen

try:
    text_type = unicode  # type: ignore[name-defined]
    binary_type = str
except Exception:
    text_type = str
    binary_type = bytes


### NET_HARDENING_BEGIN

# Network hardening for weak/unstable connections and DNS issues.
# Goals:
#  - never block Enigma2 UI while zapping
#  - retry transient failures with backoff
#  - fail fast on repeated DNS errors and hand work to background threads
#
# NOTE: We patch the imported furyPosterXDownloadThread module's `urlopen`
# so all provider methods benefit without editing their source.

socket.setdefaulttimeout(6)

NET_TIMEOUT_FAST = 2.5   # for quick API probes while zapping
NET_TIMEOUT_SLOW = 6.0   # for background providers / image download
NET_RETRIES = 2
NET_BACKOFF_BASE = 0.35
DNS_FAIL_COOLDOWN = 120  # seconds to avoid hammering DNS when it is down

_dns_fail_until = 0
_dns_fail_lock = threading.Lock()

def _url_host(url):
    try:
        # Py2 compatibility: urlparse in urllib/urllib2; but urllib.parse exists in Py3.
        try:
            from urlparse import urlparse  # type: ignore
        except Exception:
            from urllib.parse import urlparse  # type: ignore
        return urlparse(url).hostname
    except Exception:
        return None

def _dns_is_blocked():
    try:
        with _dns_fail_lock:
            return time.time() < _dns_fail_until
    except Exception:
        return False

def _mark_dns_failed():
    global _dns_fail_until
    try:
        with _dns_fail_lock:
            _dns_fail_until = time.time() + DNS_FAIL_COOLDOWN
    except Exception:
        pass

def robust_urlopen(url, data=None, timeout=None, retries=None):
    """A drop-in replacement for urllib urlopen with retries and DNS cooldown."""
    _timeout = NET_TIMEOUT_SLOW if timeout is None else timeout
    _retries = NET_RETRIES if retries is None else retries

    # Fail fast if DNS was recently failing; don't stall UI.
    host = _url_host(url)
    if host and _dns_is_blocked():
        raise URLError("DNS temporarily blocked (cooldown) for host: %s" % host)

    last_err = None
    for attempt in range(0, int(_retries) + 1):
        try:
            return urlopen(url, data, _timeout)
        except Exception as e:
            last_err = e
            # Detect DNS / name resolution errors
            try:
                if isinstance(e, URLError) and hasattr(e, "reason"):
                    reason = e.reason
                    if isinstance(reason, socket.gaierror):
                        _mark_dns_failed()
                elif isinstance(e, socket.gaierror):
                    _mark_dns_failed()
            except Exception:
                pass

            # No more attempts
            if attempt >= int(_retries):
                break

            # Backoff (short) to reduce congestion; never sleep on UI thread
            try:
                time.sleep(NET_BACKOFF_BASE * (2 ** attempt))
            except Exception:
                pass

    # Re-raise as URLError for consistent handling in provider code
    try:
        if isinstance(last_err, URLError):
            raise last_err
        raise URLError(str(last_err))
    except Exception:
        raise

# Patch provider module (best effort)
try:
    import Components.Renderer.furyPosterXDownloadThread as _dlmod
    try:
        _dlmod.urlopen = robust_urlopen
    except Exception:
        pass
except Exception:
    pass
### NET_HARDENING_END


epgcache = eEPGCache.getInstance()
if PY3:
    pdb = queue.LifoQueue()
else:
    pdb = Queue.LifoQueue()

# Background (slow) poster queue: used to try additional providers without blocking zapping
try:
    pauto = queue.Queue()
except Exception:
    try:
        pauto = Queue.Queue()
    except Exception:
        pauto = None

_bg_pending = set()
_bg_pending_lock = threading.Lock()

# ---------------------------------------------------------------------
# Low bandwidth mode
# ---------------------------------------------------------------------
# Keep on-demand poster loading active, but stop repeated failed lookups and
# heavy whole-bouquet scans. Set AUTO_SCAN_ENABLED=True to restore old prefetch.
LOW_BANDWIDTH_MODE = True
AUTO_SCAN_ENABLED = False
AUTO_SCAN_INTERVAL = 12 * 3600
AUTO_LOOKAHEAD_MINUTES = 360
AUTO_MAX_NEW_PER_CHANNEL = 4
MISS_RETRY_COOLDOWN = 30 * 60
POSTER_DEBOUNCE_MS = 550
POSTER_SHOW_DELAY_MS = 80
# ServiceEvent/channel-list guard:
# non-English EPG titles are slower because they may need heavier cleaning/search.
# Wait a bit longer only while moving inside the channel list, then fetch normally
# when the selected row stays stable.
POSTER_SERVICEEVENT_LATIN_DEBOUNCE_MS = 500
POSTER_SERVICEEVENT_NON_LATIN_DEBOUNCE_MS = 850
POSTER_SERVICEEVENT_SKIP_OUTDATED = True
# v7: after the channel-list selection is stable, try more title candidates.
# This restores stronger poster fetching for non-English EPG while still skipping
# outdated rows during fast navigation.
POSTER_SERVICEEVENT_MAX_TMDB_CANDIDATES = 3
POSTER_NORMAL_MAX_TMDB_CANDIDATES = 2
# When the channel-list cursor stays on a service, also queue a few upcoming
# events for that selected service. This starts poster downloads without tuning
# to / playing the channel, but keeps it light while scrolling quickly.
POSTER_SERVICEEVENT_PREFETCH_COUNT = 3


# Strong net saver for furyPosterXDownloadThread:
# - on-demand poster still works for the selected event
# - only TMDB is used by default (one API call + one small image)
# - heavy fallback scrapers (Google/Molotov/ProgrammeTV/IMDB/Fanart/TVDB) are disabled by default
# Set these back to the old lists if you prefer higher hit-rate over bandwidth.
FAST_PROVIDER_ORDER = ('search_tmdb',)
SLOW_PROVIDER_FALLBACK_ENABLED = False
FURY_LOG_ENABLED = False  # keep renderer silent; /tmp logging can slow weak receivers

_pdb_pending = set()
_pdb_pending_lock = threading.Lock()
_latest_serviceevent_key = None
_latest_serviceevent_lock = threading.Lock()

def _set_latest_serviceevent_key(key):
    global _latest_serviceevent_key
    try:
        with _latest_serviceevent_lock:
            _latest_serviceevent_key = key
    except Exception:
        pass

def _is_latest_serviceevent_key(key):
    try:
        if not POSTER_SERVICEEVENT_SKIP_OUTDATED:
            return True
        with _latest_serviceevent_lock:
            return key == _latest_serviceevent_key
    except Exception:
        return True

def _is_serviceevent_canal(canal):
    try:
        # New format: [..6 fields.., service_ref, "ServiceEvent", latest_key]
        if canal and len(canal) > 8 and canal[7] == "ServiceEvent":
            return True
        # Backward compatibility with older queued items:
        # [..6 fields.., "ServiceEvent", latest_key]
        if canal and len(canal) > 7 and canal[6] == "ServiceEvent":
            return True
        return False
    except Exception:
        return False

def _serviceevent_canal_key(canal):
    try:
        if canal and len(canal) > 8 and canal[7] == "ServiceEvent":
            return canal[8]
        if canal and len(canal) > 7 and canal[6] == "ServiceEvent":
            return canal[7]
        return None
    except Exception:
        return None

def _canal_service_ref(canal):
    """Optional selected service reference carried by ServiceEvent/channel-list requests."""
    try:
        if canal and len(canal) > 8 and canal[7] == "ServiceEvent":
            return canal[6]
        # Generic extension used by some workers: canal[6] may be service_ref
        if canal and len(canal) > 6 and canal[6] not in ("ServiceEvent", None, ""):
            return canal[6]
    except Exception:
        pass
    return None

def _canal_dedupe_key(canal):
    try:
        service_name = canal[0]
        begin_time = canal[1]
        service_id = _canal_service_ref(canal) or apdb.get(service_name, service_name)
        uid = build_event_uid(service_id, begin_time)
        return uid or (service_name, begin_time, canal[5])
    except Exception:
        try:
            return (canal[0], canal[1], canal[5])
        except Exception:
            return repr(canal)

def enqueue_pdb(canal):
    try:
        key = _canal_dedupe_key(canal)
        with _pdb_pending_lock:
            if key in _pdb_pending:
                return False
            _pdb_pending.add(key)
        pdb.put(canal)
        return True
    except Exception:
        try:
            pdb.put(canal)
            return True
        except Exception:
            return False

def release_pdb(canal):
    try:
        key = _canal_dedupe_key(canal)
        with _pdb_pending_lock:
            _pdb_pending.discard(key)
    except Exception:
        pass

def _miss_path(path):
    return (path + ".miss") if path else None

def _has_recent_miss(path):
    try:
        if not path or os.path.exists(path):
            return False
        mp = _miss_path(path)
        return bool(mp and os.path.exists(mp) and (time.time() - os.path.getmtime(mp)) < MISS_RETRY_COOLDOWN)
    except Exception:
        return False

def _mark_miss(*paths):
    for path in paths:
        try:
            if not path or os.path.exists(path):
                continue
            mp = _miss_path(path)
            if mp:
                with open(mp, "w") as f:
                    f.write(str(int(time.time())))
        except Exception:
            pass

def _clear_miss(*paths):
    for path in paths:
        try:
            mp = _miss_path(path)
            if mp and os.path.exists(mp):
                os.remove(mp)
        except Exception:
            pass

def enqueue_bg(canal):
    """Enqueue a canal item for background (slow) provider lookup, deduplicated by uid."""
    global pauto
    if pauto is None or not canal:
        return
    try:
        service_name = canal[0]
        begin_time = canal[1]
        service_id = _canal_service_ref(canal) or apdb.get(service_name, service_name)
        uid = build_event_uid(service_id, begin_time)
        pst = convtext(canal[5]) if canal and len(canal) > 5 and canal[5] else None
        title_path = os.path.join(path_folder, str(pst) + ".jpg") if pst else None
        uid_path = os.path.join(path_folder, str(uid) + ".jpg") if uid else title_path
        if _has_recent_miss(uid_path) or _has_recent_miss(title_path):
            return
        key = uid or (service_name, begin_time, canal[5])
        with _bg_pending_lock:
            if key in _bg_pending:
                return
            _bg_pending.add(key)
        pauto.put(canal)
    except Exception:
        # Best-effort only
        pass



def _to_text(val):
    try:
        if val is None:
            return u""
        if isinstance(val, text_type):
            return val
        if isinstance(val, binary_type):
            try:
                return val.decode("utf-8", "ignore")
            except Exception:
                try:
                    return val.decode("latin-1", "ignore")
                except Exception:
                    return text_type(val)
        return text_type(val)
    except Exception:
        try:
            return text_type(str(val))
        except Exception:
            return u""


def _quote_utf8(val):
    try:
        txt = _to_text(val)
        if PY3:
            return quote_plus(txt)
        return quote_plus(txt.encode("utf-8"))
    except Exception:
        try:
            return quote_plus(str(val))
        except Exception:
            return ""


def _to_bytes(val):
    try:
        if val is None:
            return b""
        if isinstance(val, bytes):
            return val
        return str(val).encode("utf-8", "ignore")
    except Exception:
        try:
            return bytes(val)
        except Exception:
            return b""


def build_event_uid(service_id, begin_time):
    """Stable uid for an EPG event. Does NOT depend on event title/language."""
    try:
        h = hashlib.md5(_to_bytes(service_id)).hexdigest()[:12]
        bt = int(begin_time) if begin_time is not None else 0
        return "%s_%d" % (h, bt)
    except Exception:
        return None



def _contains_arabic(s):
    try:
        if not s:
            return False
        for ch in s:
            o = ord(ch)
            if (0x0600 <= o <= 0x06FF) or (0x0750 <= o <= 0x077F) or (0x08A0 <= o <= 0x08FF) or (0xFB50 <= o <= 0xFDFF) or (0xFE70 <= o <= 0xFEFF):
                return True
        return False
    except Exception:
        return False


def _strip_diacritics_ar(s):
    # Remove Arabic diacritics and tatweel; keep base letters
    try:
        if not s:
            return s
        # Arabic diacritics
        diacs = set([
            u'\u064b', u'\u064c', u'\u064d', u'\u064e', u'\u064f', u'\u0650', u'\u0651', u'\u0652',
            u'\u0653', u'\u0654', u'\u0655', u'\u0670', u'\u0640'
        ])
        return u"".join(ch for ch in s if ch not in diacs)
    except Exception:
        return s


def _normalize_arabic(s):
    try:
        if not s:
            return s
        s = _strip_diacritics_ar(s)
        # Normalize common variants
        s = s.replace(u'أ', u'ا').replace(u'إ', u'ا').replace(u'آ', u'ا')
        s = s.replace(u'ى', u'ي').replace(u'ؤ', u'و').replace(u'ئ', u'ي')
        s = s.replace(u'ة', u'ه')  # helps loose matching for some sources
        return s
    except Exception:
        return s


def _has_episode_noise(s):
    """Detect EPG episode markers that should not be sent as the first poster query."""
    try:
        if not s:
            return False
        s = _to_text(s)
        return bool(re.search(
            r"\b(?:S\d{1,2}\s*[.\-_/ ]?\s*E\d{1,3}|\d{1,2}\s*x\s*\d{1,3}|"
            r"ODCINEK\s*\d{1,4}|ODC\.?\s*\d{1,4}(?:\s*/\s*\d{1,4})?|"
            r"EPISODE\s*\d{1,4}|EPISODIO\s*\d{1,4}|FOLGE\s*\d{1,4}|"
            r"(?:EP|E)\.?\s*\d{1,4}|SEASON\s*\d{1,2})\b",
            s,
            flags=re.IGNORECASE
        )) or bool(re.search(r"(?:حلقة|الحلقة|الموسم|الجزء)\s*\d{1,4}", s))
    except Exception:
        return False


def _clean_title_common(s):
    """Remove common noise: episode markers, LIVE/REPEAT tags, bracketed metadata."""
    try:
        if not s:
            return s
        s = _to_text(s)
        # Remove control chars used by Enigma2
        s = s.replace('\xc2\x86', '').replace('\xc2\x87', '')
        # Normalize whitespace
        s = re.sub(r"\s+", " ", s).strip()

        # Remove bracketed parts that often add noise
        s = re.sub(r"\[[^\]]{0,60}\]", " ", s)
        s = re.sub(r"\([^\)]{0,60}\)", " ", s)

        # Remove generic prefixes that hurt poster matching
        s = re.sub(r"^\s*(?:MOVIE|FILM|SERIES|PROGRAM|SHOW)\s*[:\-]\s*", "", s, flags=re.IGNORECASE)
        s = re.sub(r"^\s*(?:فيلم|مسلسل|برنامج|عرض)\s*[:\-]\s*", "", s)

        # Remove common episode/season markers.
        # Important: some EPGs write episodes as Odc.2 / Odc. 2 / Odcinek 2.
        # Some EPGs also write the season before the episode marker, for example
        # "Brooklyn 9-9 2: odc.3". Strip that suffix before the normal episode
        # cleanup so the first low-bandwidth query is the real base title.
        s = re.sub(r"\s+\d{1,2}\s*[:\-]\s*(?:ODCINEK\s*\d{1,4}|ODC\.?\s*\d{1,4}(?:\s*/\s*\d{1,4})?|(?:EP|E)\.?\s*\d{1,4}|EPISODE\s*\d{1,4}|EPISODIO\s*\d{1,4}|FOLGE\s*\d{1,4}|AFLEVERING\s*\d{1,4})\b.*$", " ", s, flags=re.IGNORECASE)
        s = re.sub(r"\s+\d{1,2}\s*[:\-]\s*(?:حلقة|الحلقة)\s*\d{1,4}.*$", " ", s)
        # In low bandwidth mode only the first TMDB query is used, so the clean base title
        # must be produced before any network request.
        s = re.sub(r"\bS\d{1,2}\s*[.\-_/ ]?\s*E\d{1,3}\b", " ", s, flags=re.IGNORECASE)
        s = re.sub(r"\b\d{1,2}\s*x\s*\d{1,3}\b", " ", s, flags=re.IGNORECASE)
        s = re.sub(r"\bODCINEK\s*\d{1,4}\b", " ", s, flags=re.IGNORECASE)
        s = re.sub(r"\bODC\.?\s*\d{1,4}(?:\s*/\s*\d{1,4})?\b", " ", s, flags=re.IGNORECASE)
        s = re.sub(r"\b(?:EP|E)\.?\s*\d{1,4}\b", " ", s, flags=re.IGNORECASE)
        s = re.sub(r"\b(?:EPISODE|EPISODIO|FOLGE|AFLEVERING)\s*\d{1,4}\b", " ", s, flags=re.IGNORECASE)
        s = re.sub(r"\bSEASON\s*\d{1,2}\b", " ", s, flags=re.IGNORECASE)
        s = re.sub(r"(?:حلقة|الحلقة)\s*\d{1,4}", " ", s)
        s = re.sub(r"الموسم\s*\d{1,2}", " ", s)
        s = re.sub(r"الجزء\s*\d{1,2}", " ", s)

        # Remove LIVE/REPEAT and similar tags
        s = re.sub(r"\b(LIVE|REPLAY|NEW)\b", " ", s, flags=re.IGNORECASE)
        s = re.sub(r"(مباشر|اعاده|إعاده|إعادة|حصري|جديد)\b", " ", s)

        # Collapse spaces again
        s = re.sub(r"\s+", " ", s).strip(" -:|")
        return s
    except Exception:
        return s


def _extract_latin_candidates(*parts):
    """Extract likely English title fragments from title/shortdesc/fulldesc."""
    out = []
    try:
        for s in parts:
            if not s:
                continue
            try:
                s = _to_text(s)
            except Exception:
                continue
            # Pull phrases like "The Movie", "Game of Thrones", "UFC 300"
            for m in re.finditer(r"[A-Za-z0-9][A-Za-z0-9'&:\- ]{2,80}", s):
                frag = m.group(0).strip()
                # filter trivial fragments
                if len(frag) < 4:
                    continue
                if frag.lower() in ("live", "replay", "new"):
                    continue
                out.append(frag)
        # Deduplicate preserving order
        uniq = []
        seen = set()
        for x in out:
            k = x.lower()
            if k not in seen:
                seen.add(k)
                uniq.append(x)
        return uniq[:6]
    except Exception:
        return out[:3]


def _clean_original_title_fragment(fragment):
    """Clean titles extracted from EPG fields like 'Tytul oryginalny: ...'."""
    try:
        frag = _to_text(fragment)
        if not frag:
            return u""

        # Stop before the next EPG metadata label.  Use ASCII-only patterns so
        # Python2 does not choke on accented labels; \S* covers e.g. Rezyseria/Reżyseria.
        frag = re.split(
            r"\b(?:re\S*yseria|wyst\S*puj\S*|obsada|gatunek|director|directed\s+by|"
            r"regia|r\S*alis\S*|cast|starring|country|kraj|opis|description)\s*[:\-]",
            frag,
            1,
            flags=re.IGNORECASE
        )[0]

        frag = frag.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ')
        frag = re.sub(r"\s+", " ", frag).strip(" -:;,.|")

        # Common CANAL+/Polsat pattern: "Abismo de pasion MX, 2012" or
        # "Vale Tudo BR, 2025".  Remove the country/year trailer, keep the title.
        frag = re.sub(r"\s+\b[A-Z]{2,3}\b\s*,?\s*(?:19|20)\d{2}\b.*$", "", frag).strip()
        frag = re.sub(r"\s*,\s*(?:19|20)\d{2}\b.*$", "", frag).strip()
        frag = re.sub(r"\s+\b(?:BR|MX|US|USA|UK|GB|FR|DE|IT|ES|PL|TR|AR|IN|CA|AU|JP|KR|CN|RU)\b$", "", frag).strip()

        # Drop accidental metadata leftovers at the end.
        frag = re.sub(r"\s+\b(?:19|20)\d{2}\b$", "", frag).strip(" -:;,.|")
        if len(frag) < 3:
            return u""
        return frag
    except Exception:
        return u""


def _extract_original_title_candidates(*parts):
    """Extract official/original titles from multilingual EPG descriptions.

    Examples handled:
      Tytul/Tytuł oryginalny: Abismo de pasion MX, 2012
      Original title: Vale Tudo BR, 2025
    """
    out = []
    seen = set()
    try:
        label = (
            r"(?:tytu\S*\s+oryginalny|original\s+title|titulo\s+original|"
            r"t\S*tulo\s+original|titre\s+original|originaltitel|"
            r"titolo\s+originale|originale\s+titel)"
        )
        for s in parts:
            if not s:
                continue
            txt = _to_text(s)
            if not txt:
                continue
            for m in re.finditer(label + r"\s*[:\-]\s*(.{2,180})", txt, flags=re.IGNORECASE | re.DOTALL):
                cand = _clean_original_title_fragment(m.group(1))
                if not cand:
                    continue
                key = cand.lower()
                if key not in seen:
                    seen.add(key)
                    out.append(cand)
        return out[:4]
    except Exception:
        return out[:2]


def _strip_epg_series_tail(s, raw=None):
    """Remove broadcaster season-number tails like 'Title 1 (odc. 53)'."""
    try:
        if not s:
            return s
        if raw is not None and not _has_episode_noise(raw):
            return s
        txt = _to_text(s)
        # Only strip when the previous token contains letters; avoids blanking numeric titles.
        has_letters = bool(re.search(r"[A-Za-z]", txt))
        if not has_letters:
            try:
                has_letters = any(ord(ch) > 127 for ch in txt)
            except Exception:
                has_letters = False
        if has_letters:
            cleaned = re.sub(r"\s+\d{1,2}$", "", txt).strip(" -:;,.|")
            if cleaned and cleaned != txt and len(cleaned) >= 3:
                return cleaned
        return s
    except Exception:
        return s


def _has_latin_letters(s):
    try:
        return bool(re.search(r"[A-Za-z]", _to_text(s)))
    except Exception:
        return False


def _title_aliases(s):
    """Return very small, safe aliases for common EPG shorthand titles."""
    out = []
    try:
        txt = _to_text(s)
        if not txt:
            return out

        # Some EPGs use "Brooklyn 9-9" / "Brooklyn 99" while TMDB uses
        # the official "Brooklyn Nine-Nine" title. Keep this narrow to avoid
        # changing normal numeric titles.
        if re.search(r"\bbrooklyn\s*9\s*[- ]?\s*9\b", txt, flags=re.IGNORECASE):
            alias = re.sub(r"\bbrooklyn\s*9\s*[- ]?\s*9\b", "Brooklyn Nine-Nine", txt, flags=re.IGNORECASE)
            alias = re.sub(r"\s+", " ", alias).strip()
            if alias and alias.lower() != txt.lower():
                out.append(alias)
    except Exception:
        pass
    return out


def _needs_english_translation(s):
    try:
        txt = _clean_title_common(_to_text(s))
        if not txt:
            return False
        if _contains_arabic(txt):
            return True
        # Handle other non-English scripts and accented titles without touching plain English titles.
        if re.search(u"[\u0400-\u04FF\u0370-\u03FF\u0590-\u05FF\u4E00-\u9FFF\u3040-\u30FF\uAC00-\uD7AF]", txt):
            return True
        if re.search(u"[^\x00-\x7F]", txt):
            return True
        return False
    except Exception:
        return False


TRANSLATE_TIMEOUT = 1.0
TRANSLATE_CACHE_MAX = 768
# v7: enabled again, but it runs only inside background worker threads after debounce.
# This improves poster hits on Hotbird/Eutelsat non-English EPG without blocking UI.
POSTER_TRANSLATE_FALLBACK_ENABLED = True
_translate_cache = {}
_translate_fail_until = {}
_translate_lock = threading.Lock()


def translate_to_english_query(title, force=False):
    """Best-effort fast English query for non-English EPG titles.

    Keeps UI responsive because it runs only in poster worker threads,
    uses a very short timeout, caches results, and fails closed.
    """
    key = None
    try:
        if not (POSTER_TRANSLATE_FALLBACK_ENABLED or force):
            return None
        src = _clean_title_common(_to_text(title))
        if not src:
            return None
        if not force and not _needs_english_translation(src):
            return None

        key = src.lower()
        now = time.time()
        with _translate_lock:
            cached = _translate_cache.get(key)
            if cached:
                return cached
            if now < _translate_fail_until.get(key, 0):
                return None
            if len(_translate_cache) > TRANSLATE_CACHE_MAX:
                _translate_cache.clear()
                _translate_fail_until.clear()

        url = (
            "https://translate.googleapis.com/translate_a/single"
            "?client=gtx&sl=auto&tl=en&dt=t&q=%s" % _quote_utf8(src)
        )
        data = robust_urlopen(url, None, timeout=TRANSLATE_TIMEOUT, retries=0).read()
        txt = _to_text(data)
        payload = json.loads(txt)

        translated = u""
        try:
            translated = u"".join(_to_text(part[0]) for part in payload[0] if part and len(part) > 0 and part[0])
        except Exception:
            translated = u""

        translated = _clean_title_common(translated)
        translated = re.sub(r"\s+", " ", translated).strip(" -:|")
        if not translated or len(translated) < 2:
            raise ValueError("empty translation")
        if not _has_latin_letters(translated):
            raise ValueError("non latin translation")
        if len(translated) > 96:
            translated = translated[:96].rsplit(" ", 1)[0].strip()
        if translated.lower() == src.lower() and not _has_latin_letters(src):
            raise ValueError("translation not useful")

        with _translate_lock:
            _translate_cache[key] = translated
            _translate_fail_until.pop(key, None)
        return translated
    except Exception:
        try:
            if key:
                with _translate_lock:
                    _translate_fail_until[key] = time.time() + 1800
        except Exception:
            pass
        return None


def _clean_channel_name(channel):
    try:
        ch = _to_text(channel)
        ch = ch.replace('\xc2\x86', '').replace('\xc2\x87', '')
        ch = re.sub(r"\[[^\]]{0,40}\]", " ", ch)
        ch = re.sub(r"\([^\)]{0,40}\)", " ", ch)
        ch = re.sub(r"\b(?:HD|FHD|UHD|SD|4K|TV|CH)\b", " ", ch, flags=re.IGNORECASE)
        ch = re.sub(r"[|/_:+-]+", " ", ch)
        ch = re.sub(r"\s+", " ", ch).strip()
        return ch
    except Exception:
        return _to_text(channel).strip()



def _is_albanian_channel(channel):
    try:
        ch = _clean_channel_name(channel).lower()
        if not ch:
            return False
        if 'digital alb' in ch or 'digitalb' in ch or 'shqip' in ch or 'albania' in ch or 'kosova' in ch or 'kosovo' in ch:
            return True
        if re.search(r'\balb\b', ch):
            return True
        return False
    except Exception:
        return False

_ALBANIAN_WORD_HINTS = set([
    u'dhe', u'në', u'ne', u'për', u'per', u'nga', u'një', u'nje', u'është', u'eshte',
    u'vrasje', u'ambasadë', u'ambasade', u'lindja', u'dragoi', u'dragoit',
    u'hiri', u'kurajo', u'dashuri', u'jeta', u'familja', u'sekret', u'lufta',
    u'mbreti', u'zemra', u'hëna', u'hena', u'deti', u'natës', u'nates', u'dielli',
    u'bota', u'gruaja', u'vajza', u'djalë', u'djale', u'shtëpi', u'shtepi',
    u'pa', u'shtet', u'fund', u'tragjik', u'biri', u'bir', u'zdrukthëtarit', u'zdrukthetarit',
    u'zdrukthëtar', u'zdrukthetar', u'zjarr', u'hi', u'avatar', u'avatari', u'snajper',
    u'nusja', u'nuse', u'trendafili', u'trëndafili', u'tetëmbëdhjetë', u'tetembedhjete',
    u'rose', u'bride', u'violent', u'ends', u'carpenter', u'nation'
])



_ALBANIAN_TITLE_ALIAS_MAP = {
    u'trendafili i tetembedhjete': (u'18th Rose', u'Eighteenth Rose', u'The Eighteenth Rose'),
    u'trendafili tetembedhjete': (u'18th Rose', u'Eighteenth Rose', u'The Eighteenth Rose'),
    u'nusja': (u'The Bride!', u'The Bride'),
    u'snajper pa shtet': (u'Sniper: No Nation', u'Sniper No Nation'),
    u'fund tragjik': (u'Violent Ends',),
    u'avatari zjarr e hi': (u'Avatar: Fire and Ash',),
    u'avatar zjarr e hi': (u'Avatar: Fire and Ash',),
    u'biri i zdrukthetarit': (u"The Carpenter's Son", u'The Carpenter Son'),
    u'biri zdrukthetarit': (u"The Carpenter's Son", u'The Carpenter Son'),
}


def _albanian_norm_key(value):
    try:
        txt = _to_text(value).lower()
        repl = ((u'ë', u'e'), (u'ç', u'c'), (u'á', u'a'), (u'à', u'a'), (u'ä', u'a'),
                (u'é', u'e'), (u'è', u'e'), (u'í', u'i'), (u'ì', u'i'), (u'ó', u'o'),
                (u'ò', u'o'), (u'ú', u'u'), (u'ù', u'u'))
        for src, dst in repl:
            txt = txt.replace(src, dst)
        txt = re.sub(u'[^a-z0-9]+', ' ', txt, flags=re.UNICODE)
        txt = re.sub(r'\s+', ' ', txt).strip()
        return txt
    except Exception:
        return ''


def _albanian_title_aliases(value):
    try:
        key = _albanian_norm_key(value)
        if not key:
            return []
        aliases = []
        for k, vals in _ALBANIAN_TITLE_ALIAS_MAP.items():
            if key == k or (len(key) >= 6 and (key in k or k in key)):
                for v in vals:
                    if v and v not in aliases:
                        aliases.append(v)
        return aliases[:4]
    except Exception:
        return []
def _looks_albanian_text(title):
    try:
        txt = _to_text(title)
        if not txt:
            return False
        if _albanian_title_aliases(txt):
            return True
        if re.search(u'[ëËçÇ]', txt):
            return True
        words = re.findall(u"[A-Za-zëËçÇ]+", txt.lower())
        if not words:
            return False
        hits = 0
        for w in words:
            if w in _ALBANIAN_WORD_HINTS:
                hits += 1
        if any(w in words for w in ('dhe', 'lindja', 'dragoit', 'dragoi', 'vrasje', 'hiri', 'kurajo')):
            return True
        return hits >= 2
    except Exception:
        return False



# ---------------------------------------------------------------------
# Arabic channels with Latin EPG transliteration (Rotana Classic, etc.)
# ---------------------------------------------------------------------
_ARABIC_LATIN_TITLE_ALIAS_MAP = {
    u'resalet gharam': (u'رسالة غرام', u'Resalet Gharam', u'Resalat Gharam'),
    u'resalat gharam': (u'رسالة غرام', u'Resalet Gharam', u'Resalat Gharam'),
    u'kolohom awladi': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kolhom awladi': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'prayer el caravan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'prayer al caravan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'doaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer'),
    u'duaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer'),
    u'mawed ma eblees': (u'موعد مع إبليس', u'Mawed Maa Eblis'),
    u'mawed maa eblees': (u'موعد مع إبليس', u'Mawed Maa Eblis'),
    u'el anesa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anesa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'el anisa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anisa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al habeb al maghol': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'el habeb el maghol': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'al habib al majhoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'el kaf': (u'الكف', u'El Kaf'),
    u'al kaf': (u'الكف', u'El Kaf'),
    u'nehayet el tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nihayet el tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nehayet al tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'al rakesa wal tabaal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'el rakesa wal tabaal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'al raqisa wal tabal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'al ghawwas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawwas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'ghesh el zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish el zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish al zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish el zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgiya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgiya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgia': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgia': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawjeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'el ghawwas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawwas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'kolohom awlady': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kolhom awlady': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kollohom awladi': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kollohom awlady': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'doaa el karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'doaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'duaa el karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'duaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'el anesa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anesa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'el anisa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anisa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'el habib el maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'al habib al maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'el habeb el maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'al habeb al maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'nehayet el tarik': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nihayet el tarik': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nehayet al tarik': (u'نهاية الطريق', u'Nehayet El Tareek'),
}


def _arabic_latin_norm_key(value):
    try:
        txt = _to_text(value).lower()
        txt = txt.replace(u'’', u' ').replace(u"'", u' ')
        txt = re.sub(u'[^a-z0-9]+', ' ', txt, flags=re.UNICODE)
        txt = re.sub(r'a{2,}', 'a', txt)
        txt = re.sub(r'e{2,}', 'e', txt)
        txt = re.sub(r'i{2,}', 'i', txt)
        txt = re.sub(r'o{2,}', 'o', txt)
        txt = re.sub(r'u{2,}', 'u', txt)
        txt = re.sub(r'\s+', ' ', txt).strip()
        return txt
    except Exception:
        return ''


def _arabic_latin_title_aliases(value):
    try:
        key = _arabic_latin_norm_key(value)
        if not key:
            return []
        aliases = []
        for k, vals in _ARABIC_LATIN_TITLE_ALIAS_MAP.items():
            kk = _arabic_latin_norm_key(k)
            if key == kk or key.startswith(kk + ' ') or (len(kk) >= 8 and kk in key):
                for v in vals:
                    if v and v not in aliases:
                        aliases.append(v)
        return aliases[:5]
    except Exception:
        return []

def _is_arabic_channel(channel):
    try:
        ch = _clean_channel_name(channel)
        if not ch:
            return False
        if _contains_arabic(ch):
            return True
        chl = ch.lower()
        hints = (
            'mbc', 'rotana', 'dmc', 'cbc', 'onn', 'on e', 'on drama', 'alhayah', 'hayah',
            'annahar', 'nahar', 'sada el balad', 'sada', 'makan', 'alkass', 'sharjah',
            'dubai', 'sama dubai', 'abudhabi', 'abu dhabi', 'emarat', 'emirates',
            'ksa', 'saudi', 'riyadiya', 'iqraa', 'majid', 'samira', 'zee aflam',
            'zee alwan', 'al arabiya', 'alarabiya', 'alarabi', 'bein', 'alarabi 2',
            'annas', 'alresalah', 'resalah', 'ten', 'extra news', 'mekameleen',
            'almasriya', 'masr', 'bahrain', 'kuwait', 'oman', 'qatar', 'falastin', 'palestine'
        )
        for hint in hints:
            if hint in chl:
                return True
        return False
    except Exception:
        return False


def _is_likely_arabic_event(title, shortdesc=None, fulldesc=None):
    """Treat as Arabic/local event only when the visible event title itself is Arabic-ish.

    This avoids misclassifying imported English movies on Arabic channels just because
    their EPG description is written in Arabic.
    """
    try:
        raw = _clean_title_common(_to_text(title))
        if not raw:
            return False
        if _contains_arabic(raw):
            return True
        if _has_latin_letters(raw):
            return False
        return _contains_arabic(_to_text(shortdesc)) or _contains_arabic(_to_text(fulldesc))
    except Exception:
        return False


def build_provider_candidates(provider_name, all_titles, latin_titles, channel=None, title=None, shortdesc=None, fulldesc=None):
    """Provider-aware candidate ordering.

    Arabic channels need tighter matching so local Arabic events do not get wrong posters
    from English-biased sources. Google-like providers benefit from channel-scoped queries.
    """
    try:
        provider_name = _to_text(provider_name or '')
        arabic_channel = _is_arabic_channel(channel)
        arabic_event = _is_likely_arabic_event(title, shortdesc, fulldesc)

        def _dedupe(seq):
            out = []
            seen = set()
            for item in seq or []:
                item = re.sub(r"\s+", " ", _to_text(item)).strip()
                if len(item) < 3:
                    continue
                key = item.lower()
                if key not in seen:
                    seen.add(key)
                    out.append(item)
            return out[:12]

        if provider_name == 'search_elcinema':
            scoped = []
            scoped.extend(all_titles or [])
            # ElCinema TV-guide/search often stores Arabic works in transliterated
            # English. On Arabic channels, also try Latin candidates from EPG
            # descriptions, then the channel-scoped variant as a last resort.
            if arabic_channel:
                scoped.extend(latin_titles or [])
                ch = _clean_channel_name(channel)
                if ch:
                    for item in (all_titles or [])[:3]:
                        if ch.lower() not in _to_text(item).lower():
                            scoped.append(u'%s %s' % (_to_text(item), ch))
            return _dedupe(scoped)

        if provider_name in ('search_tvdb', 'search_imdb', 'search_fanart'):
            # These sources are strongly English-biased. Skip them for pure Arabic/local events
            # to reduce false positives on Arabic channels.
            if arabic_channel and arabic_event and not _has_latin_letters(title):
                return []
            return _dedupe(latin_titles)

        if provider_name in ('search_google', 'search_programmetv_google', 'search_molotov_google'):
            if not arabic_channel:
                return _dedupe(all_titles)

            ch = _clean_channel_name(channel)
            scoped = []
            base_titles = list(all_titles or [])
            if arabic_event and ch:
                # For Arabic/local events, surface channel-qualified queries very early.
                for item in base_titles[:4]:
                    scoped.append(item)
                    if ch.lower() not in _to_text(item).lower():
                        scoped.append(u'%s %s' % (_to_text(item), ch))
                scoped.extend(base_titles[4:])
            else:
                scoped.extend(base_titles)
                if ch:
                    # On Arabic channels, channel-qualified queries are usually more precise for
                    # local shows and news/events than a bare translated title.
                    for item in base_titles[:4]:
                        if ch.lower() not in _to_text(item).lower():
                            scoped.append(u'%s %s' % (_to_text(item), ch))
            return _dedupe(scoped)

        return _dedupe(all_titles)
    except Exception:
        try:
            return list(all_titles or [])[:12]
        except Exception:
            return []


def choose_fast_search_methods(channel=None, title=None, shortdesc=None, fulldesc=None):
    try:
        # Net-saver default: TMDB only for normal events.
        # Arabic/local events get ElCinema as a precise second step, matching the
        # Arabic-focused workflow while avoiding noisy English-biased fallbacks.
        if _is_arabic_channel(channel) or _is_likely_arabic_event(title, shortdesc, fulldesc):
            if _has_latin_letters(title) and not _contains_arabic(_to_text(title)):
                return ('search_elcinema', 'search_tmdb')
            return ('search_tmdb', 'search_elcinema')
        return tuple(FAST_PROVIDER_ORDER or ('search_tmdb',))
    except Exception:
        return ('search_tmdb',)


def choose_slow_search_methods(channel=None, title=None, shortdesc=None, fulldesc=None):
    try:
        arabic_channel = _is_arabic_channel(channel)
        arabic_event = _is_likely_arabic_event(title, shortdesc, fulldesc)
        # If we have an exact Arabic transliteration alias, do NOT fall back to
        # Google/IMDb/Fanart fuzzy sources.  Those sources caused unrelated
        # posters such as "Redirected" to be cached for titles like
        # "Nehayet El Tareek" and "Ghesh El Zawjya".
        if arabic_channel and _arabic_latin_title_aliases(title):
            return ('search_elcinema', 'search_tmdb')
        if arabic_channel or arabic_event:
            return (
                'search_elcinema',
                'search_tmdb',
            )
        return (
            'search_fanart',
            'search_imdb',
            'search_programmetv_google',
            'search_molotov_google',
            'search_google',
        )
    except Exception:
        return (
            'search_fanart',
            'search_imdb',
            'search_programmetv_google',
            'search_molotov_google',
            'search_google',
        )


def build_title_candidates(title, shortdesc=None, fulldesc=None, channel=None, is_serviceevent=False):
    """
    Return two lists:
      - all_candidates: title variants (Arabic and/or English), ordered by likelihood
      - latin_first: same list but with pure-latin candidates prioritized (better for TVDB/IMDB)
    """
    try:
        raw = _to_text(title).strip()
        raw = raw.replace('\xc2\x86', '').replace('\xc2\x87', '').strip()

        shortdesc = _to_text(shortdesc).strip() if shortdesc else u""
        fulldesc = _to_text(fulldesc).strip() if fulldesc else u""

        candidates = []
        seen = set()

        def _add(x):
            if not x:
                return
            x = _to_text(x)
            x = re.sub(r"\s+", " ", x).strip()
            if len(x) < 3:
                return
            k = x.lower()
            if k not in seen:
                seen.add(k)
                candidates.append(x)

        # 1) Clean common noise locally before any network request.
        # Latin transliteration aliases are added before the raw title on Arabic
        # channels so providers do not mistake, for example, Resalet Gharaam for
        # a different work that starts with "رسالة".
        try:
            if _is_arabic_channel(channel) or _is_likely_arabic_event(raw, shortdesc, fulldesc):
                for _ar_alias in _arabic_latin_title_aliases(raw):
                    _add(_ar_alias)
        except Exception:
            pass
        # If the EPG description provides an official/original title, try it first.
        # This fixes translated titles such as Polish "Za wszelka cene 1 (odc. 53)"
        # where the real lookup title is in the description: "Tytul oryginalny: Vale Tudo".
        original_titles = _extract_original_title_candidates(shortdesc, fulldesc)
        for original_title in original_titles:
            _add(original_title)
            original_clean = _clean_title_common(original_title)
            if original_clean and original_clean.lower() != original_title.lower():
                _add(original_clean)
            for alias in _title_aliases(original_title):
                _add(alias)

        # If the raw EPG title contains an episode marker such as "Odc.2", put the
        # clean base title first. This keeps LOW_BANDWIDTH_MODE at one TMDB query,
        # but stops the first/only query from being poisoned by episode numbers.
        cleaned = _clean_title_common(raw)
        try:
            if _is_arabic_channel(channel) or _is_likely_arabic_event(raw, shortdesc, fulldesc):
                for _ar_alias in _arabic_latin_title_aliases(cleaned):
                    _add(_ar_alias)
        except Exception:
            pass
        clean_no_series = _strip_epg_series_tail(cleaned, raw)
        if cleaned and cleaned.lower() != raw.lower() and _has_episode_noise(raw):
            # For titles like "Brooklyn 9-9 2: odc.3", put the official/base
            # title alias before the raw EPG title because low-bandwidth mode only
            # tries the first candidate.
            for alias in _title_aliases(clean_no_series):
                _add(alias)
            if clean_no_series and clean_no_series.lower() != cleaned.lower():
                _add(clean_no_series)
            for alias in _title_aliases(cleaned):
                _add(alias)
            _add(cleaned)
            _add(raw)
        else:
            # Raw title first still preserves exact matching for normal titles.
            _add(raw)
            for alias in _title_aliases(raw):
                _add(alias)
            if clean_no_series and clean_no_series.lower() != cleaned.lower():
                _add(clean_no_series)
            _add(cleaned)
            if cleaned and cleaned.lower() != raw.lower():
                for alias in _title_aliases(cleaned):
                    _add(alias)

        # 2) Early English translation / exact Albanian alias fallback (so fast search tries it within first slots)
        for alias in _albanian_title_aliases(cleaned or raw):
            _add(alias)
        force_albanian_translation = (_is_albanian_channel(channel) or _looks_albanian_text(cleaned or raw))
        translated_main = translate_to_english_query(cleaned or raw, force=force_albanian_translation)
        if translated_main:
            _add(translated_main)
            _add(_clean_title_common(translated_main))

        # 3) Arabic normalization (helps loose matching on some sources)
        if _contains_arabic(cleaned):
            _add(_normalize_arabic(cleaned))

        # 4) Some EPGs include a better subtitle after dash or colon; keep it early
        tail = None
        if raw and ("-" in raw or ":" in raw):
            tail = _clean_title_common(re.split(r"[-:]", raw)[-1].strip())
            _add(tail)
            for alias in _albanian_title_aliases(tail):
                _add(alias)
            translated_tail = None
            if not is_serviceevent:
                translated_tail = translate_to_english_query(tail, force=force_albanian_translation or _looks_albanian_text(tail))
            if translated_tail:
                _add(translated_tail)

        # 5) English fragments from title/desc (often official/original title is present there)
        latin = _extract_latin_candidates(raw, shortdesc, fulldesc)
        for x in latin:
            _add(x)

        # 6) Disambiguate with channel name for Google-like sources (kept later)
        if channel:
            try:
                ch = _to_text(channel)
                ch = re.sub(r"\s+", " ", ch).strip()
                if ch and raw and ch not in raw:
                    _add(raw + " " + ch)
                if ch and cleaned and ch not in cleaned:
                    _add(cleaned + " " + ch)
                if ch and translated_main and ch not in translated_main:
                    _add(translated_main + " " + ch)
            except Exception:
                pass

        # Build latin-first ordering
        def is_pure_latin(s):
            s = _to_text(s)
            return (not _contains_arabic(s)) and bool(re.search(r"[A-Za-z]", s))

        latin_first = []
        for x in candidates:
            if is_pure_latin(x) and x not in latin_first:
                latin_first.append(x)
        for x in candidates:
            if x not in latin_first:
                latin_first.append(x)

        return candidates[:12], latin_first[:12]
    except Exception:
        try:
            return [title] if title else [], [title] if title else []
        except Exception:
            return [], []


def ensure_poster_alias(src_path, dst_path):
    """Create dst_path from src_path (hardlink/symlink/copy)."""
    try:
        if not src_path or not dst_path:
            return False
        if not os.path.exists(src_path):
            return False
        if os.path.exists(dst_path):
            return True
        # Prefer hardlink (fast, no duplication) then symlink then copy
        try:
            os.link(src_path, dst_path)
            return True
        except Exception:
            pass
        try:
            os.symlink(src_path, dst_path)
            return True
        except Exception:
            pass
        try:
            import shutil
            shutil.copy2(src_path, dst_path)
            return True
        except Exception:
            return False
    except Exception:
        return False



def isMountedInRW(mount_point):
    with open("/proc/mounts", "r") as f:
        for line in f:
            parts = line.split()
            if len(parts) > 1 and parts[1] == mount_point:
                return True
    return False


cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
noposter = "/usr/share/enigma2/%s/main/noposter.png" % cur_skin
path_folder = "/tmp/poster"
if os.path.exists("/media/hdd"):
    if isMountedInRW("/media/hdd"):
        path_folder = "/media/hdd/FuryPoster/poster"
elif os.path.exists("/media/usb"):
    if isMountedInRW("/media/usb"):
        path_folder = "/media/usb/FuryPoster/poster"
elif os.path.exists("/media/mmc"):
    if isMountedInRW("/media/mmc"):
        path_folder = "/media/mmc/FuryPoster/poster"

if not os.path.exists(path_folder):
    os.makedirs(path_folder)


epgcache = eEPGCache.getInstance()
apdb = dict()


try:
    lng = config.osd.language.value
    lng = lng[:-3]
except:
    lng = 'en'
    pass


# SET YOUR PREFERRED BOUQUET FOR AUTOMATIC POSTER GENERATION
# WITH THE NUMBER OF ITEMS EXPECTED (BLANK LINE IN BOUQUET CONSIDERED)
# IF NOT SET OR WRONG FILE THE AUTOMATIC POSTER GENERATION WILL WORK FOR
# THE CHANNELS THAT YOU ARE VIEWING IN THE ENIGMA SESSION

def SearchBouquetTerrestrial():
    import glob
    import codecs
    file = '/etc/enigma2/userbouquet.favourites.tv'
    for file in sorted(glob.glob('/etc/enigma2/*.tv')):
        with codecs.open(file, "r", encoding="utf-8") as f:
            file = f.read()
            x = file.strip().lower()
            if x.find('eeee') != -1:
                if x.find('82000') == -1 and x.find('c0000') == -1:
                    return file
                    break


autobouquet_file = None


def process_autobouquet():
    global autobouquet_file
    autobouquet_file = SearchBouquetTerrestrial() or '/etc/enigma2/userbouquet.favourites.tv'
    autobouquet_count = 300
    apdb = {}

    if not os.path.exists(autobouquet_file):
        print("File non trovato:", autobouquet_file)
        return {}

    try:
        with open(autobouquet_file, 'r') as f:
            lines = f.readlines()
    except (IOError, OSError) as e:
        print("Errore nella lettura del file:", e)
        return {}

    autobouquet_count = min(autobouquet_count, len(lines))

    for i, line in enumerate(lines[:autobouquet_count]):
        if line.startswith('#SERVICE'):
            parts = line[9:].strip().split(':')
            if len(parts) == 11 and ':'.join(parts[3:7]) != '0:0:0:0':
                apdb[i] = ':'.join(parts)

    print("Trovati", len(apdb), "servizi validi.")
    return apdb


# NOTE: Autoboquet parsing is deferred to runtime to avoid slowing down Enigma2 startup.
# Cached internet check (avoid blocking Enigma2 startup / widget init)
_adsl_ok = None
_adsl_ok_ts = 0



def intCheck(timeout=1):
    """Return True if an internet connection appears available.

    Keep it fast; never block the UI on weak networks.
    """
    try:
        # Lightweight endpoint; avoids downloading full pages.
        resp = robust_urlopen("http://clients3.google.com/generate_204", None, timeout=timeout, retries=1)
        try:
            resp.close()
        except Exception:
            pass
        return True
    except Exception:
        return False


def intCheck_cached(timeout=1, ttl=60):
    """Cache intCheck(), but refresh every `ttl` seconds."""
    global _adsl_ok, _adsl_ok_ts
    now = time.time()
    if _adsl_ok is None or (now - _adsl_ok_ts) > ttl:
        _adsl_ok = intCheck(timeout=timeout)
        _adsl_ok_ts = now
    return bool(_adsl_ok)



def _force_refresh_arabic_latin_alias_cache(channel=None, title=None, *paths):
    """Remove old cached posters for exact Arabic transliteration aliases.

    This is intentionally limited to mapped Arabic Latin titles and only removes
    files older than this Python file, so a correct poster downloaded after this
    update will not be deleted again on every scan.
    """
    try:
        if not (_is_arabic_channel(channel) and _arabic_latin_title_aliases(title)):
            return False
        try:
            script_mtime = os.path.getmtime(__file__)
        except Exception:
            script_mtime = time.time()
        removed = False
        for p in paths:
            try:
                if p and os.path.exists(p) and os.path.getmtime(p) < script_mtime:
                    os.remove(p)
                    removed = True
            except Exception:
                pass
        if removed:
            try:
                _clear_miss(*paths)
            except Exception:
                pass
        return removed
    except Exception:
        return False

class PosterDB(furyPosterXDownloadThread):
    def __init__(self):
        furyPosterXDownloadThread.__init__(self)
        self.logdbg = None
        self.pstcanal = None

    def run(self):
        self.logDB("[QUEUE] : Initialized")
        while True:
            canal = pdb.get()
            if _is_serviceevent_canal(canal) and not _is_latest_serviceevent_key(_serviceevent_canal_key(canal)):
                release_pdb(canal)
                continue
            self.logDB("[QUEUE] : {} : {}-{} ({})".format(canal[0], canal[1], canal[2], canal[5]))
            self.pstcanal = convtext(canal[5]) if canal[5] else None

            # Title-based path (legacy)
            title_path = os.path.join(path_folder, str(self.pstcanal) + ".jpg") if self.pstcanal else None

            # Stable uid-based path (preferred)
            service_name = canal[0]
            begin_time = canal[1]
            service_id = _canal_service_ref(canal) or apdb.get(service_name, service_name)
            uid = build_event_uid(service_id, begin_time)
            uid_path = os.path.join(path_folder, str(uid) + ".jpg") if uid else title_path

            # If we already have legacy title poster, alias it to uid for cross-language reuse
            if title_path and uid_path and os.path.exists(title_path) and not os.path.exists(uid_path):
                ensure_poster_alias(title_path, uid_path)

            # Download target is uid_path when available; otherwise fallback to legacy
            dwn_poster = uid_path or title_path

            try:
                if _force_refresh_arabic_latin_alias_cache(canal[0], canal[5], title_path, uid_path, dwn_poster):
                    self.logDB("[CACHE] refreshed Arabic transliteration poster: {}".format(canal[5]))
            except Exception:
                pass

            if not dwn_poster:
                self.logDB("[ERROR] Invalid poster target (None)")
                release_pdb(canal)
                continue

            if _has_recent_miss(dwn_poster) or _has_recent_miss(title_path):
                self.logDB("[NET-SAVER] recent miss, skip: {}".format(dwn_poster))
                release_pdb(canal)
                continue

            # FAST lookup while standing on a channel.
            # Arabic channels use a slightly different provider order to avoid wrong English posters
            # for local Arabic events, while keeping the same lightweight worker flow.
            is_serviceevent = _is_serviceevent_canal(canal)
            all_titles, latin_titles = build_title_candidates(canal[5], canal[4], canal[3], canal[0], is_serviceevent=is_serviceevent)
            search_methods = []
            for _name in choose_fast_search_methods(canal[0], canal[5], canal[4], canal[3]):
                if hasattr(self, _name):
                    search_methods.append(getattr(self, _name))
            if not search_methods:
                # Safety net
                search_methods = [self.search_tmdb]

            for search_method in search_methods:
                if os.path.exists(dwn_poster):
                    break
                cand_list = build_provider_candidates(
                    search_method.__name__,
                    all_titles,
                    latin_titles,
                    canal[0],
                    canal[5],
                    canal[4],
                    canal[3],
                )
                if not cand_list:
                    continue
                max_try = 1 if LOW_BANDWIDTH_MODE else 3
                if search_method.__name__ == "search_tmdb":
                    if LOW_BANDWIDTH_MODE:
                        max_try = POSTER_SERVICEEVENT_MAX_TMDB_CANDIDATES if is_serviceevent else POSTER_NORMAL_MAX_TMDB_CANDIDATES
                    else:
                        max_try = 4
                elif search_method.__name__ == "search_elcinema":
                    if LOW_BANDWIDTH_MODE:
                        max_try = 4 if (_is_arabic_channel(canal[0]) or _is_likely_arabic_event(canal[5], canal[4], canal[3])) else 2
                    else:
                        max_try = 6
                elif search_method.__name__ in ("search_google", "search_programmetv_google", "search_molotov_google"):
                    max_try = 1 if LOW_BANDWIDTH_MODE else (3 if _is_likely_arabic_event(canal[5], canal[4], canal[3]) else 1)
                elif search_method.__name__ in ("search_tvdb", "search_imdb"):
                    max_try = 1 if LOW_BANDWIDTH_MODE else 3
                for cand in cand_list[:max_try]:
                    if os.path.exists(dwn_poster):
                        break
                    result = search_method(dwn_poster, cand, canal[4], canal[3], canal[0])

                    if result is None:
                        self.logDB("[ERROR] Search method '{}' returned None".format(search_method.__name__))
                        continue

                    try:
                        val, log = result
                    except ValueError:
                        self.logDB("[ERROR] Unexpected result from '{}': {}".format(search_method.__name__, result))
                        continue

                    self.logDB(log)
                    if "SUCCESS" in log:
                        break
            # Ensure both uid-based and title-based filenames exist for compatibility
            try:
                if dwn_poster and os.path.exists(dwn_poster) and title_path and not os.path.exists(title_path):
                    ensure_poster_alias(dwn_poster, title_path)
                if title_path and os.path.exists(title_path) and uid_path and not os.path.exists(uid_path):
                    ensure_poster_alias(title_path, uid_path)
            except Exception:
                pass
            if dwn_poster and os.path.exists(dwn_poster):
                _clear_miss(dwn_poster, title_path)
            # Still missing after fast providers: hand off to background (slow) providers.
            if dwn_poster and not os.path.exists(dwn_poster):
                if SLOW_PROVIDER_FALLBACK_ENABLED and pauto is not None:
                    enqueue_bg(canal)
                else:
                    _mark_miss(dwn_poster, title_path)
            release_pdb(canal)

    def logDB(self, logmsg):
        if not FURY_LOG_ENABLED:
            return
        try:
            with open("/tmp/PosterDB.log", "a") as w:
                w.write("%s\n" % logmsg)
        except Exception as e:
            print("logDB error:", str(e))
            traceback.print_exc()


# NOTE: PosterDB thread is started lazily (see init_bg_once()).
# Number of parallel poster download workers (helps responsiveness on weak/slow networks)
POSTER_DB_WORKERS = 1
threadDB = []
class PosterAutoDB(furyPosterXDownloadThread):
    def __init__(self):
        furyPosterXDownloadThread.__init__(self)
        self.logdbg = None
        self.pstcanal = None

    def run(self):
        self.logAutoDB("[AutoDB] *** Initialized ***")
        # Two roles:
        #  1) On-demand background provider fallback (slow sources only) triggered by channel zap logic.
        #  2) Periodic library refresh (full scan) every 2 hours.
        next_scan = time.time() + AUTO_SCAN_INTERVAL

        def _compute_paths(canal):
            pst = convtext(canal[5]) if canal and len(canal) > 5 and canal[5] else None
            title_path = os.path.join(path_folder, str(pst) + ".jpg") if pst else None
            service_name = canal[0] if canal else None
            begin_time = canal[1] if canal else None
            service_id = _canal_service_ref(canal) or apdb.get(service_name, service_name)
            uid = build_event_uid(service_id, begin_time)
            uid_path = os.path.join(path_folder, str(uid) + ".jpg") if uid else title_path
            return pst, title_path, uid_path, (uid_path or title_path), uid, service_id

        def _run_sources(canal, source_names):
            try:
                self.pstcanal, title_path, uid_path, dwn_poster, uid, _service_id = _compute_paths(canal)
                if not dwn_poster:
                    return
                try:
                    _force_refresh_arabic_latin_alias_cache(canal[0], canal[5], title_path, uid_path, dwn_poster)
                except Exception:
                    pass
                if _has_recent_miss(dwn_poster) or _has_recent_miss(title_path):
                    self.logAutoDB("[NET-SAVER] recent miss, skip: {}".format(dwn_poster))
                    return

                # Ensure uid/title aliasing when one exists
                try:
                    if title_path and uid_path and os.path.exists(title_path) and not os.path.exists(uid_path):
                        ensure_poster_alias(title_path, uid_path)
                except Exception:
                    pass

                # Build robust title candidates (Arabic/English) for background fallbacks
                is_serviceevent = _is_serviceevent_canal(canal)
                all_titles, latin_titles = build_title_candidates(canal[5], canal[4], canal[3], canal[0], is_serviceevent=is_serviceevent)
                source_names = tuple(source_names) if source_names else tuple()
                if source_names == slow_sources:
                    source_names = choose_slow_search_methods(canal[0], canal[5], canal[4], canal[3])
                for _name in source_names:
                    if os.path.exists(dwn_poster):
                        break
                    if not hasattr(self, _name):
                        continue
                    fn = getattr(self, _name)
                    cand_list = build_provider_candidates(
                        _name,
                        all_titles,
                        latin_titles,
                        canal[0],
                        canal[5],
                        canal[4],
                        canal[3],
                    )
                    if not cand_list:
                        continue
                    max_try = (2 if LOW_BANDWIDTH_MODE and _name == "search_tmdb" else (1 if LOW_BANDWIDTH_MODE else (2 if _name in ("search_tmdb", "search_tvdb") else 4)))
                    if _name in ("search_google", "search_programmetv_google", "search_molotov_google") and _is_arabic_channel(canal[0]):
                        max_try = 2 if LOW_BANDWIDTH_MODE else 3
                    for cand in cand_list[:max_try]:
                        if os.path.exists(dwn_poster):
                            break
                        result = fn(dwn_poster, cand, canal[4], canal[3], canal[0])
                        if result is None:
                            continue
                        try:
                            _val, log = result
                        except Exception:
                            continue
                        self.logAutoDB(log)
                        if "SUCCESS" in log:
                            break
                # Final alias for compatibility
                try:
                    if dwn_poster and os.path.exists(dwn_poster) and title_path and not os.path.exists(title_path):
                        ensure_poster_alias(dwn_poster, title_path)
                    if title_path and os.path.exists(title_path) and uid_path and not os.path.exists(uid_path):
                        ensure_poster_alias(title_path, uid_path)
                    if dwn_poster and os.path.exists(dwn_poster):
                        _clear_miss(dwn_poster, title_path)
                    else:
                        _mark_miss(dwn_poster, title_path)
                except Exception:
                    pass
            except Exception:
                traceback.print_exc()

        slow_sources = (
            "search_elcinema",
            "search_fanart",
            "search_imdb",
            "search_programmetv_google",
            "search_molotov_google",
            "search_google",
        )
        full_sources = (
            "search_tmdb",
            "search_elcinema",
            "search_tvdb",
            "search_fanart",
            "search_imdb",
            "search_programmetv_google",
            "search_molotov_google",
            "search_google",
        )

        while True:
            # 1) On-demand slow lookups (do not block channel zap)
            canal = None
            if pauto is not None:
                try:
                    canal = pauto.get(timeout=15)
                except Exception:
                    canal = None

            if canal:
                if not SLOW_PROVIDER_FALLBACK_ENABLED:
                    try:
                        _pst, _tpath, _upath, _dwn, uid, _sid = _compute_paths(canal)
                        _mark_miss(_dwn, _tpath)
                        key = uid or (canal[0], canal[1], canal[5])
                        with _bg_pending_lock:
                            _bg_pending.discard(key)
                    except Exception:
                        pass
                    continue
                _run_sources(canal, slow_sources)
                # Clear pending marker
                try:
                    _pst, _tpath, _upath, _dwn, uid, _sid = _compute_paths(canal)
                    key = uid or (canal[0], canal[1], canal[5])
                    with _bg_pending_lock:
                        _bg_pending.discard(key)
                except Exception:
                    pass
                continue

            # 2) Periodic full scan every 2 hours
            if (not AUTO_SCAN_ENABLED) or time.time() < next_scan:
                # Avoid CPU spin if pauto is unavailable
                try:
                    time.sleep(0.2)
                except Exception:
                    pass
                continue

            self.logAutoDB("[AutoDB] *** Running ***")
            self.pstcanal = None

            with _apdb_lock:
                services = list(apdb.values())

            for service in services:
                try:
                    events = epgcache.lookupEvent(['IBDCTESX', (service, 0, -1, AUTO_LOOKAHEAD_MINUTES)])  # bandwidth-safe lookahead
                    newfd = 0
                    newcn = None
                    for evt in events or []:
                        canal_evt = [None] * 6
                        try:
                            if PY3:
                                canal_evt[0] = ServiceReference(service).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
                            else:
                                canal_evt[0] = ServiceReference(service).getServiceName().replace('\\xc2\\x86', '').replace('\\xc2\\x87', '')
                        except Exception:
                            canal_evt[0] = service
                        canal_evt[1] = evt[1]
                        canal_evt[2] = evt[2]
                        canal_evt[3] = evt[3]
                        canal_evt[4] = evt[4]
                        canal_evt[5] = evt[5]

                        _pst, tpath, upath, dwn_poster, _uid, _sid = _compute_paths(canal_evt)
                        if (tpath and os.path.exists(tpath)) or (upath and os.path.exists(upath)):
                            continue

                        if newcn is None:
                            newcn = canal_evt[0]
                        if newcn != canal_evt[0]:
                            newcn = canal_evt[0]
                            newfd = 0
                        if newfd >= AUTO_MAX_NEW_PER_CHANNEL:
                            continue

                        _run_sources(canal_evt, full_sources)
                        if dwn_poster and os.path.exists(dwn_poster):
                            newfd += 1
                except Exception:
                    traceback.print_exc()

            try:
                now_tm = time.time()
                emptyfd = 0
                oldfd = 0
                for f in os.listdir(path_folder):
                    file_path = os.path.join(path_folder, f)
                    diff_tm = now_tm - os.path.getmtime(file_path)
                    if diff_tm > 120 and os.path.getsize(file_path) == 0:
                        os.remove(file_path)
                        emptyfd += 1
                    elif diff_tm > 31536000:
                        os.remove(file_path)
                        oldfd += 1
                self.logAutoDB("[AutoDB] {} old file(s) removed".format(oldfd))
                self.logAutoDB("[AutoDB] {} empty file(s) removed".format(emptyfd))
            except Exception:
                traceback.print_exc()

            self.logAutoDB("[AutoDB] *** Stopping ***")
            next_scan = time.time() + AUTO_SCAN_INTERVAL

    def logAutoDB(self, logmsg):
        if not FURY_LOG_ENABLED:
            return
        try:
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            with open("/tmp/PosterAutoDB.log", "a") as w:
                w.write("[{}] {}\n".format(timestamp, logmsg))
        except Exception as e:
            print("logAutoDB error: {}".format(e))
            traceback.print_exc()


# NOTE: PosterAutoDB thread is started lazily (see init_bg_once()).
threadAutoDB = None

# ---------------------------------------------------------------------
# Deferred initialization (reduce Enigma2 boot time)
# ---------------------------------------------------------------------
_bg_inited = False
_bg_init_lock = threading.Lock()
_apdb_lock = threading.Lock()

def _load_autobouquet_bg():
    """Parse bouquets in background and populate apdb."""
    global apdb
    try:
        data = process_autobouquet()
        if isinstance(data, dict):
            with _apdb_lock:
                apdb.update(data)
    except Exception:
        traceback.print_exc()


def init_bg_once():
    """Initialize heavy background resources once (threads + bouquet parsing)."""
    global _bg_inited, threadDB, threadAutoDB
    if _bg_inited:
        return
    with _bg_init_lock:
        if _bg_inited:
            return
        _bg_inited = True

        # Load bouquets in the background to avoid blocking UI.
        try:
            t = threading.Thread(target=_load_autobouquet_bg, name="furyPosterX-Autobouquet")
            try:
                t.daemon = True
            except Exception:
                t.setDaemon(True)
            t.start()
        except Exception:
            traceback.print_exc()

        # Start poster download threads lazily (parallel workers improve responsiveness on weak networks).
        try:
            if not threadDB:
                for i in range(int(POSTER_DB_WORKERS)):
                    tdb = PosterDB()
                    try:
                        tdb.name = "furyPosterX-PosterDB-{}".format(i + 1)
                    except Exception:
                        pass
                    tdb.start()
                    threadDB.append(tdb)
        except Exception:
            traceback.print_exc()

        try:
            if threadAutoDB is None:
                threadAutoDB = PosterAutoDB()
                threadAutoDB.start()
        except Exception:
            traceback.print_exc()


class furyPosterX(Renderer):
    def __init__(self):
        Renderer.__init__(self)
        self.adsl = intCheck_cached(timeout=1, ttl=60)
        # Do not return early: keep timers and rendering logic initialized even if
        # internet is weak/offline; we'll re-check later.
        if not self.adsl:
            print("Connessione assente/instabile, modalità offline (will recheck).")
        else:
            print("Connessione rilevata.")
        self.nxts = 0
        self.path = path_folder  # + '/'
        self.canal = [None, None, None, None, None, None]
        self.oldCanal = None
        self.pstrNm = None
        self.logdbg = None
        self.pstcanal = None
        self.timer = eTimer()
        self.service_str = None
        try:
            self.timer_conn = self.timer.timeout.connect(self.showPoster)
        except:
            self.timer.callback.append(self.showPoster)

        # Non-blocking polling to update poster as soon as download finishes (no threads/sleep)
        self._pollTimer = eTimer()
        self._debounceTimer = eTimer()
        self._expected_paths = None
        self._poll_deadline = 0
        self._pending_canal = None
        try:
            self._pollTimer_conn = self._pollTimer.timeout.connect(self._pollPoster)
        except:
            self._pollTimer.callback.append(self._pollPoster)
        try:
            self._debounce_conn = self._debounceTimer.timeout.connect(self._debouncedFetch)
        except:
            self._debounceTimer.callback.append(self._debouncedFetch)

    def applySkin(self, desktop, parent):
        attribs = []
        for (attrib, value,) in self.skinAttributes:
            if attrib == "nexts":
                self.nxts = int(value)
            if attrib == "path":
                self.path = str(value)
            attribs.append((attrib, value))
        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    GUI_WIDGET = ePixmap

    def changed(self, what):
        if not self.instance:
            return
        if what[0] == self.CHANGED_CLEAR:
            try:
                self.timer.stop()
                self._pollTimer.stop()
                self._debounceTimer.stop()
            except Exception:
                pass
            self._pending_canal = None
            self._expected_paths = None
            self.instance.hide()
            return

        # Do not start background threads / bouquet parsing on every list movement.
        # It will be started only if a real poster download is needed.

        servicetype = None
        try:
            service = None
            source_type = type(self.source)
            if isinstance(self.source, ServiceEvent) or hasattr(self.source, "getCurrentService"):  # source="ServiceEvent" / channel selection
                service = self.source.getCurrentService()
                servicetype = "ServiceEvent"
            elif isinstance(self.source, CurrentService) or hasattr(self.source, "getCurrentServiceRef"):  # source="session.CurrentService"
                service = self.source.getCurrentServiceRef()
                servicetype = "CurrentService"
            elif isinstance(self.source, EventInfo):  # source="session.Event_Now" or source="session.Event_Next"
                service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                servicetype = "EventInfo"
            elif isinstance(self.source, Event) or hasattr(self.source, "event"):  # source="Event"
                if self.nxts:
                    service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                else:
                    self.canal[0] = None
                    self.canal[1] = self.source.event.getBeginTime()
                    event_name = self.source.event.getEventName().replace('\xc2\x86', '').replace('\xc2\x87', '')
                    if not PY3:
                        event_name = event_name.encode('utf-8')
                    self.canal[2] = event_name
                    self.canal[3] = self.source.event.getExtendedDescription()
                    self.canal[4] = self.source.event.getShortDescription()
                    self.canal[5] = event_name
                servicetype = "Event"
            if service is not None:
                service_str = service.toString()
                self.service_str = service_str
                events = epgcache.lookupEvent(['IBDCTESX', (service_str, 0, -1, -1)])
                if not events or len(events) <= self.nxts or events[self.nxts] is None:
                    raise Exception("No EPG events for service (nxts={})".format(self.nxts))
                service_name = ServiceReference(service).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
                if not PY3:
                    service_name = service_name.encode('utf-8')
                self.canal[0] = service_name
                self.canal[1] = events[self.nxts][1]
                self.canal[2] = events[self.nxts][4]
                self.canal[3] = events[self.nxts][5]
                self.canal[4] = events[self.nxts][6]
                self.canal[5] = self.canal[2]

                if not autobouquet_file:
                    with _apdb_lock:
                        if service_name not in apdb:
                            apdb[service_name] = service_str

        except Exception as e:
            print("Error (service):", str(e))
            if self.instance:
                self.instance.hide()
            return
        if not servicetype:
            print("Error: service type undefined")
            if self.instance:
                self.instance.hide()
            return

        try:
            # Unique key includes service ref to avoid sticky posters between channels.
            # For ServiceEvent/channel-list, the freshness key must be the selected
            # service only. Some skins use several widgets (now/next/next+2); if
            # the key includes event begin/title, those widgets invalidate each
            # other and only the last one downloads.
            curCanal = "{}-{}-{}".format(self.service_str or "", self.canal[1], self.canal[2])
            serviceevent_key = self.service_str or self.canal[0] or ""
            if servicetype == "ServiceEvent":
                _set_latest_serviceevent_key(serviceevent_key)
            if curCanal == self.oldCanal:
                return

            self.oldCanal = curCanal
            self.logPoster("Service: {} [{}] : {} : {}".format(servicetype, self.nxts, self.canal[0], self.oldCanal))

            # Stop any previous polling/debounce (zapping fast)
            try:
                self.timer.stop()
                self._pollTimer.stop()
                self._debounceTimer.stop()
            except Exception:
                pass

            # Build expected poster filenames
            title_path = None
            try:
                pst_title = convtext(self.canal[5]) if self.canal and len(self.canal) > 5 else None
                title_path = os.path.join(self.path, str(pst_title) + ".jpg") if pst_title else None
            except Exception:
                title_path = None

            service_id = self.service_str or apdb.get(self.canal[0], self.canal[0])
            uid = build_event_uid(service_id, self.canal[1])
            uid_path = os.path.join(self.path, str(uid) + ".jpg") if uid else title_path

            self._expected_paths = [p for p in (uid_path, title_path) if p]

            # If we already have it, show immediately
            existing = None
            if uid_path and os.path.exists(uid_path):
                existing = uid_path
            elif title_path and os.path.exists(title_path):
                # legacy -> alias to uid for reuse
                if uid_path:
                    ensure_poster_alias(title_path, uid_path)
                    if os.path.exists(uid_path):
                        existing = uid_path
                if existing is None:
                    existing = title_path

            if existing:
                self.pstrNm = existing
                self.timer.start(POSTER_SHOW_DELAY_MS, True)
            else:
                # Hide old poster to avoid 'sticking' while new one downloads
                if self.instance:
                    self.instance.hide()
                if _has_recent_miss(uid_path) or _has_recent_miss(title_path):
                    try:
                        if noposter and os.path.exists(noposter):
                            self.pstrNm = noposter
                            self.timer.start(POSTER_SHOW_DELAY_MS, True)
                    except Exception:
                        pass
                    return
                self._pending_canal = self.canal[:]
                debounce_ms = POSTER_DEBOUNCE_MS
                if servicetype == "ServiceEvent":
                    # Carry selected service ref so the worker downloads for the highlighted
                    # channel, not the currently playing channel.
                    self._pending_canal.append(self.service_str)
                    self._pending_canal.append("ServiceEvent")
                    self._pending_canal.append(serviceevent_key)
                    try:
                        if _needs_english_translation(self.canal[5]) or _looks_albanian_text(self.canal[5]):
                            debounce_ms = POSTER_SERVICEEVENT_NON_LATIN_DEBOUNCE_MS
                        else:
                            debounce_ms = POSTER_SERVICEEVENT_LATIN_DEBOUNCE_MS
                    except Exception:
                        debounce_ms = POSTER_SERVICEEVENT_NON_LATIN_DEBOUNCE_MS
                # debounce avoids repeated network calls while zapping quickly
                self._debounceTimer.start(debounce_ms, True)

        except Exception as e:
            print("Error (eFile):", str(e))
            if self.instance:
                self.instance.hide()
            return

    def generatePosterPath(self):
        """Generate poster path with stable UID (channel+start time) and backward-compatible title fallback."""
        title_path = None
        if self.canal and len(self.canal) > 5 and self.canal[5]:
            try:
                pst_title = convtext(self.canal[5])
                title_path = os.path.join(self.path, str(pst_title) + ".jpg")
            except Exception:
                title_path = None

        service_id = self.service_str or (self.canal[0] if self.canal else None)
        uid = build_event_uid(service_id, self.canal[1] if self.canal else None)
        uid_path = os.path.join(self.path, str(uid) + ".jpg") if uid else title_path

        # Prefer stable uid
        if uid_path and os.path.exists(uid_path):
            return uid_path

        # Backward compatibility: if title-based exists, alias it to uid and use uid
        if title_path and os.path.exists(title_path):
            if uid_path:
                ensure_poster_alias(title_path, uid_path)
                if os.path.exists(uid_path):
                    return uid_path
            return title_path

        # Default to uid path (so waiting/downloading targets stable file)
        return uid_path or title_path


    def _enqueueSelectedServicePrefetch(self, selected_canal):
        """Queue a few posters for the highlighted channel without tuning to it.

        Runs only after the ServiceEvent debounce survived, so fast channel-list
        scrolling does not flood the receiver/network. The selected row key is
        attached to every queued item; stale jobs are skipped if the cursor moves.
        """
        try:
            if not _is_serviceevent_canal(selected_canal):
                return
            service_str = _canal_service_ref(selected_canal) or self.service_str
            latest_key = _serviceevent_canal_key(selected_canal)
            if not service_str or not latest_key or not _is_latest_serviceevent_key(latest_key):
                return
            count = int(POSTER_SERVICEEVENT_PREFETCH_COUNT)
            if count <= 1:
                return
            events = epgcache.lookupEvent(['IBDCTESX', (service_str, 0, -1, -1)])
            if not events:
                return
            service_name = selected_canal[0]
            try:
                if not service_name:
                    service_name = ServiceReference(service_str).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
            except Exception:
                pass
            queued = 0
            for evt in events[:count]:
                try:
                    if not evt:
                        continue
                    title = evt[4]
                    if not title:
                        continue
                    canal_evt = [service_name, evt[1], title, evt[5], evt[6], title, service_str, "ServiceEvent", latest_key]

                    pst_title = convtext(title) if title else None
                    title_path = os.path.join(self.path, str(pst_title) + ".jpg") if pst_title else None
                    uid = build_event_uid(service_str, evt[1])
                    uid_path = os.path.join(self.path, str(uid) + ".jpg") if uid else title_path
                    if (uid_path and os.path.exists(uid_path)) or (title_path and os.path.exists(title_path)):
                        continue
                    if _has_recent_miss(uid_path) or _has_recent_miss(title_path):
                        continue
                    if enqueue_pdb(canal_evt):
                        queued += 1
                except Exception:
                    continue
        except Exception as e:
            self.logPoster("[ERROR: ServiceEvent prefetch] {}".format(e))

    def _debouncedFetch(self):
        """Run download after a short debounce, then poll for the resulting file."""
        canal = self._pending_canal
        self._pending_canal = None
        if not canal:
            return
        if _is_serviceevent_canal(canal) and not _is_latest_serviceevent_key(_serviceevent_canal_key(canal)):
            return
        init_bg_once()
        try:
            enqueue_pdb(canal)
            if _is_serviceevent_canal(canal):
                self._enqueueSelectedServicePrefetch(canal)
        except Exception as e:
            self.logPoster("[ERROR: enqueue] {}".format(e))
            return
        self._startPosterPoll()

    def _startPosterPoll(self):
        """Poll for poster file existence using a debounced/backoff timer.

        Tuning goal:
          - Fast first paint (check frequently early)
          - Low I/O long-tail (backoff later)
        """
        self._poll_started_at = time.time()
        self._poll_deadline = self._poll_started_at + 300.0  # seconds
        # Fast initial cadence to reduce perceived latency after download finishes
        self._poll_next_ms = 120
        try:
            # Kick an immediate single-shot check
            self._pollTimer.start(self._poll_next_ms, True)
        except Exception:
            pass

    def _pollPoster(self):
        try:
            paths = self._expected_paths or []
            for p in paths:
                if p and os.path.exists(p):
                    self.pstrNm = p
                    self.timer.start(POSTER_SHOW_DELAY_MS, True)
                    return

            # Not found yet: stop if we exceeded the deadline
            if time.time() > (self._poll_deadline or 0):
                try:
                    self._pollTimer.stop()
                except Exception:
                    pass
                # If nothing was found, show the skin's noposter instead of leaving the widget empty
                try:
                    if noposter and os.path.exists(noposter):
                        self.pstrNm = noposter
                        self.timer.start(POSTER_SHOW_DELAY_MS, True)
                except Exception:
                    pass
                return

            # Backoff polling to reduce filesystem pressure during zapping / HDD spin-up
            try:
                elapsed = time.time() - float(getattr(self, "_poll_started_at", time.time()))
                # Early phase: keep checks frequent for fast first paint.
                if elapsed < 10.0:
                    cap = 800
                elif elapsed < 30.0:
                    cap = 2000
                else:
                    cap = 5000

                nxt = int(getattr(self, "_poll_next_ms", 200) * 1.25)
                if nxt < 200:
                    nxt = 200
                self._poll_next_ms = cap if nxt > cap else nxt
            except Exception:
                self._poll_next_ms = 1000

            try:
                self._pollTimer.start(self._poll_next_ms, True)  # single-shot
            except Exception:
                pass

        except Exception as e:
            self.logPoster("[ERROR: poll] {}".format(e))
            try:
                self._pollTimer.stop()
            except Exception:
                pass

    def showPoster(self):
        if self.instance:
            self.instance.hide()

        self.pstrNm = self.generatePosterPath()

        # Show poster if present, otherwise show default noposter (if available)
        target = None
        if self.pstrNm and os.path.exists(self.pstrNm):
            target = self.pstrNm
        elif noposter and os.path.exists(noposter):
            target = noposter

        if target and self.instance:
            self.logPoster("[LOAD : showPoster] " + target)
            self.instance.setPixmap(loadJPG(target))
            self.instance.setScale(1)
            self.instance.show()

    def waitPoster(self):
        if self.instance:
            self.instance.hide()

        self.pstrNm = self.generatePosterPath()
        if not self.pstrNm:
            self.logPoster("[ERROR: waitPoster] Poster path is None")
            return
        loop = 180  # Numero massimo di tentativi
        found = False
        self.logPoster("[LOOP: waitPoster] " + self.pstrNm)
        while loop > 0:
            if self.pstrNm and os.path.exists(self.pstrNm):
                found = True
                break
            time.sleep(0.5)
            loop -= 1
        if found:
            self.timer.start(POSTER_SHOW_DELAY_MS, True)

    def logPoster(self, logmsg):
        if not FURY_LOG_ENABLED:
            return
        import traceback
        try:
            with open("/tmp/logPosterXx.log", "a") as w:
                w.write("%s\n" % logmsg)
        except Exception as e:
            print('logPoster error:', str(e))
            traceback.print_exc()
