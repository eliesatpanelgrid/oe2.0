##############################################################################################################################################
#  Fury-FHD Renderer for Enigma2
#  Coded by Youchie SmartCam Tem (c)2025
#  If you use this Renderer for other skins and rename it, please keep the second line adding your credits below
#
#  No-lag update by Islam Salama / Fury:
#  - source data is read from the fury2Access RAM cache
#  - the same PNG is not decoded again on every Poll/change
#  - Python 2 and Python 3 compatible
##############################################################################################################################################

from __future__ import absolute_import
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap


class furyCamIconS(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.cam_icons = (
            ("oscam", "/usr/share/enigma2/Fury-FHD/CAM/oscam.png"),
            ("cccam", "/usr/share/enigma2/Fury-FHD/CAM/cccam.png"),
            ("ncam", "/usr/share/enigma2/Fury-FHD/CAM/ncam.png"),
            ("smartcam", "/usr/share/enigma2/Fury-FHD/CAM/smartcam.png"),
            ("gcam", "/usr/share/enigma2/Fury-FHD/CAM/gcam.png"),
            ("scam", "/usr/share/enigma2/Fury-FHD/CAM/scam.png"),
            ("gbox", "/usr/share/enigma2/Fury-FHD/CAM/gbox.png"),
            ("wicardd", "/usr/share/enigma2/Fury-FHD/CAM/wicardd.png"),
            ("camd3", "/usr/share/enigma2/Fury-FHD/CAM/camd3.png"),
            ("mgcamd", "/usr/share/enigma2/Fury-FHD/CAM/mgcamd.png"),
        )
        self.default_icon = "/usr/share/enigma2/Fury-FHD/CAM/default.png"
        self._last_icon_path = None

    def changed(self, what):
        if not self.instance:
            return

        try:
            raw = self.source.text if self.source is not None else ""
            cam_name = (raw or "").lower()
        except Exception:
            cam_name = ""

        icon_path = self.default_icon
        for key, path in self.cam_icons:
            if key in cam_name:
                icon_path = path
                break

        # setPixmapFromFile decodes the PNG on the Enigma2 GUI thread.  Polls
        # often deliver the same text every second, so avoid decoding it again.
        if icon_path == self._last_icon_path:
            try:
                self.instance.show()
            except Exception:
                pass
            return

        try:
            self.instance.setPixmapFromFile(icon_path)
            self._last_icon_path = icon_path
            self.instance.show()
        except Exception as e:
            try:
                print("Error loading CAM icon: %s" % e)
            except Exception:
                pass
            try:
                self.instance.hide()
            except Exception:
                pass
