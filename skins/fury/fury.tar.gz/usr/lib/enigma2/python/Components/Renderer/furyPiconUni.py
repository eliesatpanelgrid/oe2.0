﻿# PiconUni
# Copyright (c) 2boom 2012-16
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# 26.09.2012 added search mountpoints
# 25.06.2013 added resize picon
# 26.11.2013 code optimization
# 02.12.2013 added compatibility with CaidInfo2 (SatName)
# 18.12.2013 added picon miltipath
# 27.12.2013 added picon reference
# 27.01.2014 added noscale parameter (noscale="0" is default, scale picon is on)
# 28.01.2014 code otimization
# 02.04.2014 added iptv ref code
# 17.04.2014 added path in plugin dir...
# 02.07.2014 small fix reference
# 09.01.2015 redesign code
# 02.05.2015 add path uuid device
# 08.05.2016 add 5001, 5002 stream id
# 16.11.2018 fix search Paths (by Sirius, thx Taapat)

from Components.Renderer.Renderer import Renderer
from enigma import ePixmap
from Tools.Directories import SCOPE_SKIN_IMAGE, SCOPE_CURRENT_SKIN, SCOPE_PLUGINS, resolveFilename 
import os
import time

searchPaths = []

def initPiconPaths():
	global searchPaths
	paths = []
	try:
		if os.path.isfile('/proc/mounts'):
			with open('/proc/mounts', 'r') as mounts:
				for line in mounts:
					if '/dev/sd' in line or '/dev/disk/by-uuid/' in line or '/dev/mmc' in line:
						parts = line.split()
						if len(parts) > 1:
							piconPath = parts[1].replace('\\040', ' ') + '/%s/'
							if piconPath not in paths:
								paths.append(piconPath)
	except Exception:
		pass
	for piconPath in ('/usr/share/enigma2/%s/', '/usr/lib/enigma2/python/Plugins/%s/'):
		if piconPath not in paths:
			paths.append(piconPath)
	searchPaths[:] = paths


class furyPiconUni(Renderer):
	__module__ = __name__
	MISS_TTL = 30.0

	def __init__(self):
		Renderer.__init__(self)
		self.path = 'piconUni'
		self.scale = '0'
		self.nameCache = {}
		self.missCache = {}
		self.pngname = ''
		self._searchDirs = None

	def applySkin(self, desktop, parent):
		attribs = []
		for (attrib, value,) in self.skinAttributes:
			if attrib == 'path':
				self.path = value
			elif attrib == 'noscale':
				self.scale = value
			else:
				attribs.append((attrib, value))
		self.skinAttributes = attribs
		self._buildSearchDirs()
		return Renderer.applySkin(self, desktop, parent)

	GUI_WIDGET = ePixmap

	def _buildSearchDirs(self):
		dirs = []
		try:
			pathtmp = [x.strip() for x in self.path.split(',') if x.strip()]
		except Exception:
			pathtmp = ['piconUni']
		for base in searchPaths:
			for dirName in pathtmp:
				try:
					directory = base % dirName
				except Exception:
					continue
				if directory not in dirs:
					dirs.append(directory)
		self._searchDirs = dirs

	def _normalizeServiceName(self, value):
		try:
			sname = (value or '').upper().replace('.', '').replace('\xc2\xb0', '')
		except Exception:
			sname = ''
		if not sname.startswith('1'):
			sname = sname.replace('4097', '1', 1).replace('5001', '1', 1).replace('5002', '1', 1)
		if ':' in sname:
			sname = '_'.join(sname.split(':')[:10])
		return sname

	def _cachedPicon(self, sname):
		if not sname:
			return ''
		if sname in self.nameCache:
			return self.nameCache.get(sname, '')
		try:
			miss_ts = float(self.missCache.get(sname, 0.0) or 0.0)
			if miss_ts and (time.time() - miss_ts) < self.MISS_TTL:
				return ''
			if miss_ts:
				del self.missCache[sname]
		except Exception:
			pass

		pngname = self.findPicon(sname)
		if pngname:
			self.nameCache[sname] = pngname
			self.missCache.pop(sname, None)
		else:
			self.missCache[sname] = time.time()

		# Avoid unbounded growth when browsing very large service lists.
		if len(self.nameCache) > 1500:
			default = self.nameCache.get('default')
			self.nameCache.clear()
			if default:
				self.nameCache['default'] = default
		if len(self.missCache) > 1500:
			self.missCache.clear()
		return pngname

	def changed(self, what):
		if not self.instance:
			return

		pngname = ''
		if what[0] is not self.CHANGED_CLEAR:
			# Reading source.text may call a converter.  Do it once per renderer
			# update and never print it to stdout on the GUI thread.
			sname = self._normalizeServiceName(self.source.text)
			pngname = self._cachedPicon(sname)

		if pngname == '':
			pngname = self.nameCache.get('default', '')
			if pngname == '':
				pngname = self.findPicon('picon_default')
				if pngname == '':
					tmp = resolveFilename(SCOPE_CURRENT_SKIN, 'picon_default.png')
					if os.path.isfile(tmp):
						pngname = tmp
					else:
						pngname = resolveFilename(SCOPE_SKIN_IMAGE, 'skin_default/picon_default.png')
				self.nameCache['default'] = pngname

		# Compare values, not Python object identity.
		if self.pngname != pngname:
			if self.scale == '0':
				if pngname:
					self.instance.setScale(1)
					self.instance.setPixmapFromFile(pngname)
					self.instance.show()
				else:
					self.instance.hide()
			else:
				if pngname:
					self.instance.setPixmapFromFile(pngname)
			self.pngname = pngname

	def findPicon(self, serviceName):
		if self._searchDirs is None:
			self._buildSearchDirs()
		for directory in self._searchDirs:
			pngname = directory + serviceName + '.png'
			try:
				if os.path.isfile(pngname):
					return pngname
			except Exception:
				continue
		return ''


initPiconPaths()
