# -*- coding: utf-8 -*-
# FuryLogo Renderer (Standalone)
# Auto-downloads event logos from TMDB and displays them.
# Save location: /media/hdd/FuryPoster/logo/<CleanEventName>.png
#
# Language strategy (like FuryPosterX idea, extended):
#   1) Search in device language (e.g. pl-PL / pl)
#   2) If not found, search in English (en-US / en)
#   3) If still not found, search without language
#
# Skin usage example:
#   <widget source="session.Event_Now" render="furylogo" position="0,0" size="240,130" transparent="1" alphatest="on" />

# $$$$ This file was created by Islam Salama $$$$ V. 16/1/2026
from __future__ import absolute_import, print_function

import os
import re
import time
import threading
import sys
import hashlib
import json
import unicodedata
from difflib import SequenceMatcher

from Components.Renderer.Renderer import Renderer
from Components.config import config
from enigma import ePixmap, eTimer, loadPNG
import NavigationInstance

PY3 = False
if sys.version_info[0] >= 3:
    PY3 = True
    try:
        from urllib.request import urlopen
    except Exception:
        urlopen = None
else:
    try:
        from urllib2 import urlopen
    except Exception:
        urlopen = None

# ===================== User settings =====================
# Save location(s): the renderer will pick the first available mount.
LOGO_DIRS = [
    "/media/hdd/FuryPoster/logo",
    "/media/hdd1/FuryPoster/logo",
    "/media/hdd2/FuryPoster/logo",
    "/media/usb/FuryPoster/logo",
    "/media/usb1/FuryPoster/logo",
    "/media/usb2/FuryPoster/logo",
    "/media/mmc/FuryPoster/logo",
]


def _pick_logo_dir():
    """Pick the first LOGO_DIRS entry whose mount point exists."""
    for p in LOGO_DIRS:
        try:
            parts = p.strip("/").split("/")
            mount = "/" + "/".join(parts[:2]) if len(parts) >= 2 else os.path.dirname(p)
            if os.path.isdir(mount):
                return p
        except Exception:
            continue
    return LOGO_DIRS[0] if LOGO_DIRS else "/media/hdd/FuryPoster/logo"


LOGO_DIR = _pick_logo_dir()

# Accuracy first: do NOT reuse stable UID logo by default.
# Some EPG/Event widgets do not expose the real selected service reference;
# using current-service+begin-time can therefore show the previous event logo.
# Title-based cache is safer for the selected event. Set True only if your
# source always supplies the correct service reference for the selected event.
LOGO_USE_UID_CACHE = False

# A tiny transparent PNG used to actively clear the pixmap so the previous
# logo never sticks on screen while the next event is loading/missing.
BLANK_LOGO = "/tmp/furylogo_blank.png"

# TMDB API key (default key ). Better to replace with your own.
TMDB_API_KEY = "3c3efcf47c3577558812bb9d64019d65"

# TMDB logo size on image server: 45, 92, 154, 185, 300, 500, original
TMDB_LOGO_SIZE = "300"

# Disabled: do not create fallback text logos when TMDB has no official logo.
LOGO_TEXT_FALLBACK_ENABLED = False

# If download fails for a title, wait this long before retrying
RETRY_COOLDOWN_SEC = 6 * 60 * 60

# Cache TTL (speeds up repeated lookups)
CACHE_TTL_SEC = 24 * 60 * 60  # 24 hours

# Zapping performance guard: wait a little longer before network/poll work
# so fast channel surfing does not start unnecessary logo downloads.
LOGO_DEBOUNCE_MS = 850
LOGO_NON_LATIN_DEBOUNCE_MS = 1250
LOGO_POLL_MS = 500

# Optional logging
LOG_ENABLED = False
LOG_FILE = "/tmp/furylogo.log"
# =========================================================

# --- Title cleaning REGEX copied from xtraLogo.py (xtraEvent) ---
REGEX = re.compile(
    r'([\(\[]).*?([\)\]])|'
    r'(: odc.\d+)|'
    r'(\d+: odc.\d+)|'
    r'(\d+ odc.\d+)|(:)|'
    r'!|'
    r'/.*|'
    r'\|\s[0-9]+\+|'
    r'[0-9]+\+|'
    r'\s\d{4}\Z|'
    r'([\(\[\|].*?[\)\]\|])|'
    r'(\"|\"\.|\"\,|\.)\s.+|'
    r'\"|:|'
    r'\*|'
    r'\u041f\u0440\u0435\u043c\u044c\u0435\u0440\u0430\.\s|'
    r'(\u0445|\u0425|\u043c|\u041c|\u0442|\u0422|\u0434|\u0414)/\u0444\s|'
    r'(\u0445|\u0425|\u043c|\u041c|\u0442|\u0422|\u0434|\u0414)/\u0441\s|'
    r'\s(\u0441|\u0421)(\u0435\u0437\u043e\u043d|\u0435\u0440\u0438\u044f|-\u043d|-\u044f)\s.+|'
    r'\s\d{1,3}\s(\u0447|\u0447\.|\u0441\.|\u0441)\s.+|'
    r'\.\s\d{1,3}\s(\u0447|\u0447\.|\u0441\.|\u0441)\s.+|'
    r'\s(\u0447|\u0447\.|\u0441\.|\u0441)\s\d{1,3}.+|'
    r'\d{1,3}(-\u044f|-\u0439|\s\u0441-\u043d).+|'
    r'\s\u062d\s*\d+|'
    r'\s\u062c\s*\d+|'
    r'\s\u0645\s*\d+|'
    r'\d+$'
    , re.DOTALL)


def _log(msg):
    if not LOG_ENABLED:
        return
    try:
        with open(LOG_FILE, "a") as f:
            f.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def _ensure_dir(path):
    try:
        if not os.path.exists(path):
            os.makedirs(path)
    except Exception as e:
        _log("mkdir error: %s" % e)


def _ensure_blank_logo():
    """Create a 1x1 transparent PNG once and return its path."""
    try:
        if os.path.exists(BLANK_LOGO) and os.path.getsize(BLANK_LOGO) > 0:
            return BLANK_LOGO
        # 1x1 transparent PNG
        data = (
            b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"
            b"\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89"
            b"\x00\x00\x00\x0bIDATx\x9cc``\x00\x00\x00\x02\x00\x01\xe2!\xbc3"
            b"\x00\x00\x00\x00IEND\xaeB`\x82"
        )
        with open(BLANK_LOGO, "wb") as f:
            f.write(data)
        return BLANK_LOGO
    except Exception:
        return None


def _clear_pixmap(instance):
    """Hide and clear pixmap to prevent stale previous logos from sticking."""
    try:
        instance.hide()
    except Exception:
        pass
    try:
        blank = _ensure_blank_logo()
        if blank and os.path.exists(blank):
            instance.setPixmap(loadPNG(blank))
    except Exception:
        pass


# ---------------------------------------------------------------------
# Stable-ID + language helpers (mirrors FuryPosterX behavior)
# ---------------------------------------------------------------------

_tr_cache = {}


def _to_bytes(val):
    try:
        if val is None:
            return b""
        if isinstance(val, bytes):
            return val
        return str(val).encode("utf-8", "ignore")
    except Exception:
        try:
            return bytes(val)
        except Exception:
            return b""


def build_event_uid(service_id, begin_time):
    """Stable uid for an EPG event. Does NOT depend on event title/language."""
    try:
        h = hashlib.md5(_to_bytes(service_id)).hexdigest()[:12]
        bt = int(begin_time) if begin_time is not None else 0
        return "%s_%d" % (h, bt)
    except Exception:
        return None


def ensure_logo_alias(src_path, dst_path):
    """Create dst_path from src_path (hardlink/symlink/copy)."""
    try:
        if not src_path or not dst_path:
            return False
        if not os.path.exists(src_path):
            return False
        if os.path.exists(dst_path):
            return True

        # Prefer hardlink (fast, no duplication) then symlink then copy
        try:
            os.link(src_path, dst_path)
            return True
        except Exception:
            pass
        try:
            os.symlink(src_path, dst_path)
            return True
        except Exception:
            pass
        try:
            import shutil
            shutil.copy2(src_path, dst_path)
            return True
        except Exception:
            return False
    except Exception:
        return False


def _contains_arabic(s):
    try:
        if not s:
            return False
        for ch in s:
            o = ord(ch)
            if (0x0600 <= o <= 0x06FF) or (0x0750 <= o <= 0x077F) or (0x08A0 <= o <= 0x08FF) or (0xFB50 <= o <= 0xFDFF) or (0xFE70 <= o <= 0xFEFF):
                return True
        return False
    except Exception:
        return False




_ELCINEMA_TITLE_CACHE_TS = 0
_ELCINEMA_TITLE_CACHE = []


def _logo_html_unescape_safe(value):
    """Decode basic HTML entities for ElCinema pages."""
    try:
        txt = value or ""
        if isinstance(txt, bytes):
            txt = txt.decode('utf-8', 'ignore')
        try:
            if PY3:
                import html as _html
                return _html.unescape(txt)
            else:
                from HTMLParser import HTMLParser
                return HTMLParser().unescape(txt)
        except Exception:
            return (txt.replace('&#39;', "'").replace('&quot;', '"')
                       .replace('&amp;', '&').replace('&nbsp;', ' '))
    except Exception:
        return value or ""



def _logo_strip_tags(value):
    try:
        txt = re.sub(r'<script.*?</script>', ' ', str(value or ''), flags=re.I | re.S)
        txt = re.sub(r'<style.*?</style>', ' ', txt, flags=re.I | re.S)
        txt = re.sub(r'<[^>]+>', ' ', txt)
        txt = _logo_html_unescape_safe(txt)
        return re.sub(r'\s+', ' ', txt).strip()
    except Exception:
        return str(value or '').strip()

def _logo_attr(tag, name):
    try:
        m = re.search(name + r'\s*=\s*["\']([^"\']+)["\']', str(tag or ''), flags=re.I | re.S)
        return _logo_html_unescape_safe(m.group(1)).strip() if m else ''
    except Exception:
        return ''

def _logo_norm_elcinema_title(value):
    """Normalize Arabic and Latin titles for ElCinema TV-guide matching."""
    try:
        txt = _logo_html_unescape_safe(value).lower()
        txt = unicodedata.normalize('NFKC', txt)
        txt = re.sub(u'[\u064b-\u065f\u0670\u0640]', '', txt)
        for src, dst in ((u'أ', u'ا'), (u'إ', u'ا'), (u'آ', u'ا'), (u'ى', u'ي'), (u'ؤ', u'و'), (u'ئ', u'ي'), (u'ة', u'ه')):
            txt = txt.replace(src, dst)
        txt = re.sub(u'[^\\w\u0600-\u06FF]+', ' ', txt, flags=re.UNICODE)
        txt = re.sub(r'\s+', ' ', txt).strip()
        return txt
    except Exception:
        try:
            return str(value or '').lower().strip()
        except Exception:
            return ''





def _logo_title_words(value):
    try:
        n = _logo_norm_elcinema_title(value)
        stop = set(['the', 'a', 'an', 'and', 'or', 'of', 'to'])
        words = [w for w in n.split() if len(w) > 1 and w not in stop]
        return n, words
    except Exception:
        return str(value or '').lower().strip(), []

def _logo_is_clear_title_mismatch(query, found):
    """Block only obvious wrong Latin logo/title hints; do not reduce broad search."""
    try:
        qn, qw = _logo_title_words(query)
        fn, fw = _logo_title_words(found)
        if not qn or not fn:
            return False
        if _contains_arabic(qn) or _contains_arabic(fn):
            return False
        if qn == fn or qn in fn or fn in qn:
            return False
        qs = set(qw)
        fs = set(fw)
        if len(qs) >= 2 and len(fs) >= 2:
            common = len(qs.intersection(fs))
            ratio = int(SequenceMatcher(None, qn, fn).ratio() * 100)
            if common == 1 and ratio < 72:
                return True
        return False
    except Exception:
        return False

def _logo_all_known_titles_clear_mismatch(query, titles):
    try:
        known = [t for t in titles if t]
        return bool(known) and all(_logo_is_clear_title_mismatch(query, t) for t in known)
    except Exception:
        return False

def _elcinema_tvguide_title_entries(timeout=5):
    """Read ElCinema TV-guide titles without an API key."""
    global _ELCINEMA_TITLE_CACHE_TS, _ELCINEMA_TITLE_CACHE
    try:
        now = time.time()
        if _ELCINEMA_TITLE_CACHE and (now - _ELCINEMA_TITLE_CACHE_TS) < (30 * 60):
            return _ELCINEMA_TITLE_CACHE
        body = ''
        try:
            import requests
            response = requests.get(
                'https://elcinema.com/en/tvguide/',
                timeout=timeout,
                headers={'User-Agent': 'Mozilla/5.0', 'Accept-Language': 'ar,en;q=0.8'}
            )
            if response.status_code != 200:
                return _ELCINEMA_TITLE_CACHE or []
            body = response.text
        except Exception:
            try:
                from urllib.request import Request, urlopen as _uopen
            except Exception:
                from urllib2 import Request, urlopen as _uopen
            req = Request('https://elcinema.com/en/tvguide/', headers={'User-Agent': 'Mozilla/5.0'})
            raw = _uopen(req, timeout=timeout).read()
            body = raw.decode('utf-8', 'ignore') if isinstance(raw, bytes) else raw
        body = _logo_html_unescape_safe(body)
        entries = []
        seen = set()

        def add(found_title, work_id):
            try:
                found_title = _logo_strip_tags(found_title).strip()
                work_id = str(work_id or '').strip()
                if not found_title or not work_id:
                    return
                if _logo_norm_elcinema_title(found_title) in ('movie', 'series', 'program', 'favourite'):
                    return
                key = (found_title.lower(), work_id)
                if key in seen:
                    return
                seen.add(key)
                entries.append((found_title, work_id))
            except Exception:
                pass

        for tag, work_id, body_part in re.findall(r'(<a\b[^>]*\bhref=["\'](?:https?://elcinema\.com)?/(?:en/)?work/(\d+)/?["\'][^>]*>)(.*?)</a>', body, flags=re.I | re.S):
            add(_logo_attr(tag, 'title') or _logo_attr(tag, 'data-title') or body_part, work_id)
        for found_title, work_id in re.findall(r'title=["\']([^"\']+)["\'][^>]+href=["\'](?:https?://elcinema\.com)?/(?:en/)?work/(\d+)/?["\']', body, flags=re.I | re.S):
            add(found_title, work_id)
        for work_id, found_title in re.findall(r'href=["\'](?:https?://elcinema\.com)?/(?:en/)?work/(\d+)/?["\'][^>]+title=["\']([^"\']+)["\']', body, flags=re.I | re.S):
            add(found_title, work_id)

        if entries:
            _ELCINEMA_TITLE_CACHE = entries
            _ELCINEMA_TITLE_CACHE_TS = now
        return _ELCINEMA_TITLE_CACHE or []
    except Exception:
        return _ELCINEMA_TITLE_CACHE or []

def _elcinema_resolve_tvguide_titles(query):
    """Return closest ElCinema TV-guide title hints for logo lookup."""
    try:
        if not query:
            return []
        qn = _logo_norm_elcinema_title(query)
        if not qn:
            return []
        q_tokens = set([x for x in qn.split() if len(x) > 1])
        ranked = []
        for found_title, _work_id in _elcinema_tvguide_title_entries():
            tn = _logo_norm_elcinema_title(found_title)
            if not tn:
                continue
            if _logo_is_clear_title_mismatch(query, found_title):
                continue
            if qn == tn:
                score = 100
            else:
                score = int(SequenceMatcher(None, qn, tn).ratio() * 100)
                if len(qn) >= 4 and len(tn) >= 4 and (qn in tn or tn in qn):
                    score = max(score, 86)
                try:
                    t_tokens = set([x for x in tn.split() if len(x) > 1])
                    if q_tokens and t_tokens:
                        overlap = len(q_tokens.intersection(t_tokens)) * 100 // max(len(q_tokens), len(t_tokens))
                        score = max(score, overlap)
                        if overlap >= 50:
                            score += 12
                except Exception:
                    pass
            if score >= 64:
                ranked.append((score, found_title))
        ranked.sort(key=lambda item: item[0], reverse=True)
        result = []
        seen = set()
        for score, found_title in ranked[:5]:
            key = _logo_norm_elcinema_title(found_title)
            if key and key not in seen:
                seen.add(key)
                result.append((found_title, ''))
        return result
    except Exception:
        return []

def _is_latin_script(s):
    """Return True if the string is predominantly Latin script (incl. extended Latin)."""
    try:
        if not s:
            return True
        if not isinstance(s, str):
            s = str(s)
        has_alpha = False
        for ch in s:
            o = ord(ch)
            if not ch.isalpha():
                continue
            has_alpha = True
            # Basic Latin + Latin-1 Supplement + Latin Extended-A/B
            if (0x0041 <= o <= 0x024F) or (0x1E00 <= o <= 0x1EFF) or (0x2C60 <= o <= 0x2C7F):
                continue
            return False
        return True if has_alpha else True
    except Exception:
        return True


# ---------------------------------------------------------------------
# Albanian EPG title support (Digital Alb / Shqip)
# ---------------------------------------------------------------------
_ALBANIAN_WORD_HINTS = set([
    u'dhe', u'në', u'ne', u'për', u'per', u'nga', u'një', u'nje', u'është', u'eshte',
    u'vrasje', u'ambasadë', u'ambasade', u'lindja', u'dragoi', u'dragoit',
    u'hiri', u'kurajo', u'dashuri', u'jeta', u'familja', u'sekret', u'lufta',
    u'mbreti', u'zemra', u'hëna', u'hena', u'deti', u'natës', u'nates', u'dielli',
    u'bota', u'gruaja', u'vajza', u'djalë', u'djale', u'shtëpi', u'shtepi',
    u'pa', u'shtet', u'fund', u'tragjik', u'biri', u'bir', u'zdrukthëtarit', u'zdrukthetarit',
    u'zdrukthëtar', u'zdrukthetar', u'zjarr', u'hi', u'avatar', u'avatari', u'snajper',
    u'nusja', u'nuse', u'trendafili', u'trëndafili', u'tetëmbëdhjetë', u'tetembedhjete',
    u'rose', u'bride', u'violent', u'ends', u'carpenter', u'nation'
])



_ALBANIAN_TITLE_ALIAS_MAP = {
    u'trendafili i tetembedhjete': (u'18th Rose', u'Eighteenth Rose', u'The Eighteenth Rose'),
    u'trendafili tetembedhjete': (u'18th Rose', u'Eighteenth Rose', u'The Eighteenth Rose'),
    u'nusja': (u'The Bride!', u'The Bride'),
    u'snajper pa shtet': (u'Sniper: No Nation', u'Sniper No Nation'),
    u'fund tragjik': (u'Violent Ends',),
    u'avatari zjarr e hi': (u'Avatar: Fire and Ash',),
    u'avatar zjarr e hi': (u'Avatar: Fire and Ash',),
    u'biri i zdrukthetarit': (u"The Carpenter's Son", u'The Carpenter Son'),
    u'biri zdrukthetarit': (u"The Carpenter's Son", u'The Carpenter Son'),
}


def _albanian_to_text(value):
    try:
        if value is None:
            return u''
        if isinstance(value, bytes):
            return value.decode('utf-8', 'ignore')
        try:
            return unicode(value)  # type: ignore[name-defined]
        except Exception:
            return str(value)
    except Exception:
        try:
            return str(value)
        except Exception:
            return u''


def _albanian_norm_key(value):
    try:
        txt = _albanian_to_text(value).lower()
        repl = ((u'ë', u'e'), (u'ç', u'c'), (u'á', u'a'), (u'à', u'a'), (u'ä', u'a'),
                (u'é', u'e'), (u'è', u'e'), (u'í', u'i'), (u'ì', u'i'), (u'ó', u'o'),
                (u'ò', u'o'), (u'ú', u'u'), (u'ù', u'u'))
        for src, dst in repl:
            txt = txt.replace(src, dst)
        txt = re.sub(u'[^a-z0-9]+', ' ', txt, flags=re.UNICODE)
        txt = re.sub(r'\s+', ' ', txt).strip()
        return txt
    except Exception:
        return ''


def _albanian_title_aliases(value):
    try:
        key = _albanian_norm_key(value)
        if not key:
            return []
        aliases = []
        for k, vals in _ALBANIAN_TITLE_ALIAS_MAP.items():
            if key == k or (len(key) >= 6 and (key in k or k in key)):
                for v in vals:
                    if v and v not in aliases:
                        aliases.append(v)
        return aliases[:4]
    except Exception:
        return []
def _looks_albanian_text(title):
    try:
        txt = _albanian_to_text(title)
        if _albanian_title_aliases(txt):
            return True
        if re.search(u'[ëËçÇ]', txt):
            return True
        words = re.findall(u"[A-Za-zëËçÇ]+", txt.lower())
        if not words:
            return False
        hits = 0
        for w in words:
            if w in _ALBANIAN_WORD_HINTS:
                hits += 1
        if any(w in words for w in ('dhe', 'lindja', 'dragoit', 'dragoi', 'vrasje', 'hiri', 'kurajo')):
            return True
        return hits >= 2
    except Exception:
        return False



# ---------------------------------------------------------------------
# Arabic channels with Latin EPG transliteration (Rotana Classic, etc.)
# ---------------------------------------------------------------------
_ARABIC_LATIN_TITLE_ALIAS_MAP = {
    u'resalet gharam': (u'رسالة غرام', u'Resalet Gharam', u'Resalat Gharam'),
    u'resalat gharam': (u'رسالة غرام', u'Resalet Gharam', u'Resalat Gharam'),
    u'kolohom awladi': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kolhom awladi': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'prayer el caravan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'prayer al caravan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'doaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer'),
    u'duaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer'),
    u'mawed ma eblees': (u'موعد مع إبليس', u'Mawed Maa Eblis'),
    u'mawed maa eblees': (u'موعد مع إبليس', u'Mawed Maa Eblis'),
    u'el anesa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anesa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'el anisa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anisa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al habeb al maghol': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'el habeb el maghol': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'al habib al majhoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'el kaf': (u'الكف', u'El Kaf'),
    u'al kaf': (u'الكف', u'El Kaf'),
    u'nehayet el tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nihayet el tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nehayet al tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'al rakesa wal tabaal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'el rakesa wal tabaal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'al raqisa wal tabal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'al ghawwas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawwas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'ghesh el zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish el zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish al zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish el zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgiya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgiya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgia': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgia': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawjeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'el ghawwas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawwas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'kolohom awlady': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kolhom awlady': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kollohom awladi': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kollohom awlady': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'doaa el karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'doaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'duaa el karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'duaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'el anesa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anesa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'el anisa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anisa hanafi': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'el habib el maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'al habib al maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'el habeb el maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'al habeb al maghoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'nehayet el tarik': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nihayet el tarik': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nehayet al tarik': (u'نهاية الطريق', u'Nehayet El Tareek'),
}


def _arabic_latin_norm_key(value):
    try:
        txt = _albanian_to_text(value).lower()
        txt = txt.replace(u'’', u' ').replace(u"'", u' ')
        txt = re.sub(u'[^a-z0-9]+', ' ', txt, flags=re.UNICODE)
        txt = re.sub(r'a{2,}', 'a', txt)
        txt = re.sub(r'e{2,}', 'e', txt)
        txt = re.sub(r'i{2,}', 'i', txt)
        txt = re.sub(r'o{2,}', 'o', txt)
        txt = re.sub(r'u{2,}', 'u', txt)
        txt = re.sub(r'\s+', ' ', txt).strip()
        return txt
    except Exception:
        return ''


def _arabic_latin_title_aliases(value):
    try:
        key = _arabic_latin_norm_key(value)
        if not key:
            return []
        aliases = []
        for k, vals in _ARABIC_LATIN_TITLE_ALIAS_MAP.items():
            kk = _arabic_latin_norm_key(k)
            if key == kk or key.startswith(kk + ' ') or (len(kk) >= 8 and kk in key):
                for v in vals:
                    if v and v not in aliases:
                        aliases.append(v)
        return aliases[:5]
    except Exception:
        return []


def _logo_arabic_words(value):
    try:
        n = _normalize_match_title(value)
        stop = set([u'ال', u'و', u'في', u'من', u'علي', u'على', u'مع', u'يا'])
        return [w for w in n.split() if len(w) > 1 and w not in stop]
    except Exception:
        return []


def _logo_is_clear_arabic_title_mismatch(query, found):
    try:
        if not (_contains_arabic(query) and _contains_arabic(found)):
            return False
        qn = _normalize_match_title(query)
        fn = _normalize_match_title(found)
        if not qn or not fn:
            return False
        if qn == fn or qn in fn or fn in qn:
            return False
        qw = set(_logo_arabic_words(query))
        fw = set(_logo_arabic_words(found))
        if len(qw) >= 2 and len(fw) >= 2:
            common = qw.intersection(fw)
            ratio = int(SequenceMatcher(None, qn, fn).ratio() * 100)
            if not common:
                return True
            if len(common) == 1 and ratio < 72:
                return True
        return False
    except Exception:
        return False

def translate_to_en(text_in, timeout=3):
    """Translate text to English using Google's free endpoint (best-effort).

    Mirrors FuryPosterX behavior:
      - No translation is attempted for Arabic-script titles.
      - Cached in-memory to reduce network calls.
    """
    try:
        if not text_in:
            return None
        text_in = _albanian_to_text(text_in)
        q = text_in.strip()
        if not q or len(q) < 3:
            return None
        if _contains_arabic(q):
            return None

        cached = _tr_cache.get(q)
        if cached is not None:
            return cached

        aliases = _albanian_title_aliases(q)
        if aliases:
            _tr_cache[q] = aliases[0]
            return aliases[0]

        # If it already looks English-ish, skip network
        try:
            if all(ord(c) < 128 for c in q) and re.search(r"[A-Za-z]{3,}", q) and not _looks_albanian_text(q):
                _tr_cache[q] = q
                return q
        except Exception:
            pass

        try:
            if PY3:
                from urllib.parse import quote
            else:
                from urllib import quote
        except Exception:
            quote = None

        if quote is None or urlopen is None:
            _tr_cache[q] = None
            return None

        url = (
            "https://translate.googleapis.com/translate_a/single"
            "?client=gtx&sl=auto&tl=en&dt=t&q=" + (quote(q) if PY3 else quote(q.encode('utf-8')))
        )

        try:
            resp = urlopen(url, timeout=timeout)
            data = resp.read()
            try:
                resp.close()
            except Exception:
                pass
        except Exception:
            _tr_cache[q] = None
            return None

        try:
            if isinstance(data, bytes):
                data = data.decode('utf-8', 'ignore')
        except Exception:
            pass

        try:
            j = json.loads(data)
            out = []
            if isinstance(j, list) and j and isinstance(j[0], list):
                for seg in j[0]:
                    try:
                        if isinstance(seg, list) and seg:
                            out.append(seg[0])
                    except Exception:
                        continue
            translated = ''.join(out).strip() if out else None
        except Exception:
            translated = None

        if translated:
            translated = re.sub(r"\s+", " ", translated).strip()

        _tr_cache[q] = translated
        return translated
    except Exception:
        return None


def _get_device_locale():
    """Return locale like 'pl_PL' or 'ar_EG' (best-effort)."""
    try:
        from Components.Language import language
        lang = language.getLanguage()
        if lang:
            return lang
    except Exception:
        pass

    try:
        lang = config.osd.language.value
        if lang:
            return lang
    except Exception:
        pass

    return "en_US"


def _lang_candidates():
    """Generate TMDB language fallbacks."""
    loc = (_get_device_locale() or "en_US").strip()  # e.g. pl_PL
    loc_dash = loc.replace("_", "-")               # pl-PL
    short = loc_dash[:2].lower() if len(loc_dash) >= 2 else "en"

    cands = []

    def add(x):
        if x is None:
            if None not in cands:
                cands.append(None)
            return
        x = str(x).strip()
        if x and x not in cands:
            cands.append(x)

    # Device language first
    add(loc_dash)
    add(short)

    # Albanian fallback for Digital Alb/Shqip EPG translated titles
    add("sq-AL")
    add("sq")

    # English fallback
    add("en-US")
    add("en")

    # No language
    add(None)

    return cands


def _event_to_clean_name(evnt):
    """Match xtraLogo cleaning steps (LIVE removal + REGEX)."""
    if not evnt:
        return ""

    try:
        name = evnt.replace('\xc2\x86', '').replace('\xc2\x87', '')
    except Exception:
        name = evnt

    try:
        name = name.replace("live: ", "").replace("LIVE ", "")
        evnt2 = name.replace("live: ", "").replace("LIVE ", "").replace("LIVE: ", "").replace("live ", "")
        evnt2 = name  # keep same as original xtraLogo behavior
    except Exception:
        evnt2 = name

    clean = REGEX.sub('', evnt2).strip()

    # Extra safety: remove forbidden filename chars
    clean = re.sub(r'[\\/:*?"<>|]+', '', clean)
    clean = re.sub(r'\s+', ' ', clean).strip()

    return clean


def _title_variants(raw_title, clean_title):
    """Try a few title variants to improve match rate."""
    variants = []

    def add(t):
        if not t:
            return
        t = re.sub(r"\s+", " ", str(t)).strip()
        if t and t not in variants:
            variants.append(t)

    for alias in _arabic_latin_title_aliases(clean_title):
        add(alias)
    for alias in _arabic_latin_title_aliases(raw_title):
        add(alias)
    add(clean_title)
    add(raw_title)
    for alias in _albanian_title_aliases(clean_title):
        add(alias)
    for alias in _albanian_title_aliases(raw_title):
        add(alias)

    # Before ':' often matches better
    try:
        if raw_title and ":" in raw_title:
            add(raw_title.split(":", 1)[0])
    except Exception:
        pass

    # Remove trailing ' - ...'
    try:
        if raw_title:
            add(re.sub(r"\s*-\s*.+$", "", raw_title).strip())
    except Exception:
        pass

    return variants[:4]


def _logo_path(clean_name):
    if not clean_name:
        return None
    return os.path.join(LOGO_DIR, "%s.png" % clean_name)


def _logo_uid_path(uid):
    if not uid:
        return None
    return os.path.join(LOGO_DIR, "%s.png" % uid)


# ---------- HTTP helpers (requests preferred; urllib fallback) ----------

def _http_get_json(url, timeout=8, headers=None):
    hdrs = {"User-Agent": "Mozilla/5.0"}
    try:
        if headers:
            hdrs.update(headers)
    except Exception:
        pass

    # requests
    try:
        import requests
        r = requests.get(url, timeout=timeout, headers=hdrs)
        if r.status_code != 200:
            return None
        return r.json()
    except Exception:
        pass

    # urllib / urllib2
    try:
        try:
            from urllib.request import urlopen, Request
        except Exception:
            from urllib2 import urlopen, Request

        req = Request(url, headers=hdrs)
        raw = urlopen(req, timeout=timeout).read()
        try:
            import json
            return json.loads(raw)
        except Exception:
            import json
            return json.loads(raw.decode('utf-8', 'ignore'))
    except Exception:
        return None


def _http_download(url, out_path, timeout=12):
    # requests
    try:
        import requests
        r = requests.get(url, timeout=timeout, stream=True, headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code != 200:
            return False
        with open(out_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        return os.path.exists(out_path) and os.path.getsize(out_path) > 0
    except Exception:
        pass

    # urllib / urllib2
    try:
        try:
            from urllib.request import urlopen, Request
        except Exception:
            from urllib2 import urlopen, Request

        req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
        data = urlopen(req, timeout=timeout).read()
        with open(out_path, "wb") as f:
            f.write(data)
        return os.path.exists(out_path) and os.path.getsize(out_path) > 0
    except Exception:
        return False


# ---------- TMDB logic (multi search -> images logos) ----------

_SEARCH_CACHE = {}  # (title, lang) -> (ts, results[(media_type,id)])
_IMG_CACHE = {}     # (media_type,id) -> (ts, logos_list)


def _quote(s):
    try:
        try:
            from urllib.parse import quote
        except Exception:
            from urllib import quote
        return quote(s)
    except Exception:
        return (s or "").replace(" ", "%20")


def _html_unescape(value):
    """Decode basic HTML entities without adding a hard dependency."""
    try:
        try:
            from html import unescape
        except Exception:
            from HTMLParser import HTMLParser
            unescape = HTMLParser().unescape
        return unescape(value or "")
    except Exception:
        return value or ""


def _elcinema_logo_title_hints(title, year=None):
    """Return Arabic title hints for stricter TMDB logo lookup.

    The first path follows the xtraevent method: ElCinema TV guide is used as a
    no-API Arabic title resolver. The final transparent logo still comes from
    TMDB images because ElCinema does not normally provide transparent logos.
    """
    try:
        clean_title = re.sub(r"\s+", " ", str(title or "").replace("+", " ")).strip()
        if not clean_title or not _contains_arabic(clean_title):
            return []

        tvguide_hints = _elcinema_resolve_tvguide_titles(clean_title)
        if tvguide_hints:
            if year:
                return [(hint_title, year) for hint_title, _unused in tvguide_hints]
            return tvguide_hints

        target = _normalize_match_title(clean_title)
        if not target:
            return []

        # Secondary fallback: keep the old ElCinema AJAX lookup for titles that
        # are not currently listed in the TV-guide page.
        search_url = "https://elcinema.com/ajaxable/search_simple?q=%s" % _quote(clean_title)
        req_headers = {
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": "https://elcinema.com/",
        }
        data = _http_get_json(search_url, timeout=8, headers=req_headers)
        if not isinstance(data, list):
            return []

        candidates = []
        for html_fragment in data:
            try:
                if 'data-entity="Work"' not in html_fragment:
                    continue
                title_match = re.findall(r'title="([^"]+)"', html_fragment)
                found_title = _html_unescape(title_match[0].strip()) if title_match else ""
                found_norm = _normalize_match_title(found_title)
                if not found_norm:
                    continue
                if _logo_is_clear_title_mismatch(clean_title, found_title):
                    continue
                result_year_match = re.findall(r'<li>(19\d{2}|20\d{2})</li>', html_fragment)
                result_year = result_year_match[0] if result_year_match else ""
                poster_match = re.findall(r'<img[^>]+src="([^"]+)"', html_fragment)
                poster_url = poster_match[0] if poster_match else ""

                score = 0
                if found_norm == target:
                    score += 500
                if target and found_norm and (target in found_norm or found_norm in target):
                    score += 150
                if poster_url and "blank_photos" not in poster_url:
                    score += 60
                if year:
                    if result_year == str(year):
                        score += 250
                    elif result_year:
                        score -= 120
                candidates.append({"title": found_title, "year": result_year, "score": score})
            except Exception:
                continue

        if not candidates:
            return []
        candidates.sort(key=lambda item: item.get("score", 0), reverse=True)

        hints = []
        seen = set()
        for item in candidates[:4]:
            if item.get("score", 0) < 50:
                continue
            hint_title = item.get("title") or ""
            hint_year = item.get("year") or year or ""
            key = (_normalize_match_title(hint_title), str(hint_year or ""))
            if hint_title and key not in seen:
                seen.add(key)
                hints.append((hint_title, hint_year))
        return hints
    except Exception:
        return []



def _normalize_match_title(value):
    """Normalize Latin and Arabic titles for TMDB result ranking."""
    try:
        value = str(value or "").lower().strip()
        value = value.replace("&", " and ")
        value = re.sub(u'[\u064b-\u065f\u0670\u0640]', '', value)
        value = value.replace(u'أ', u'ا').replace(u'إ', u'ا').replace(u'آ', u'ا')
        value = value.replace(u'ى', u'ي').replace(u'ؤ', u'و').replace(u'ئ', u'ي')
        value = re.sub(r"[^a-z0-9\u0600-\u06FF]+", " ", value)
        value = re.sub(r"\s+", " ", value).strip()
        return value
    except Exception:
        return str(value or "").lower().strip()


def _split_title_and_year_local(title):
    """Split a trailing production year from a logo search title."""
    try:
        value = str(title or "").strip()
        year = ""
        m = re.search(r'[\(\[]\s*((?:19|20)\d{2})\s*[\)\]]\s*$', value)
        if not m:
            m = re.search(r'(?<!^)\s+((?:19|20)\d{2})\s*$', value)
        if m:
            year = m.group(1)
            value = value[:m.start()].strip()
        value = re.sub(r"\s+", " ", value).strip(" -:|")
        return value, year
    except Exception:
        return title, ""


def _score_tmdb_logo_result(item, title, year=None):
    """Rank TMDB search results before fetching logos."""
    def _logo_tmdb_meaningful_tokens(value):
        try:
            n = _normalize_match_title(value)
            stop = set([u'al', u'el', u'the', u'a', u'an', u'and', u'of', u'wa', u'wal', u'بن', u'ابن', u'ال', u'و', u'في', u'من', u'مع', u'يا'])
            return [w for w in n.split() if len(w) > 1 and w not in stop]
        except Exception:
            return []

    try:
        target = _normalize_match_title(title)
        media_type = str(item.get('media_type') or '').lower()
        if media_type not in ('movie', 'tv'):
            return -999
        display_title = item.get('name') or item.get('title') or ''
        original_title = item.get('original_name') or item.get('original_title') or ''
        if _logo_all_known_titles_clear_mismatch(title, (display_title, original_title)):
            return -999
        arabic_known_titles = [t for t in (display_title, original_title) if t]
        if arabic_known_titles and all(_logo_is_clear_arabic_title_mismatch(title, t) for t in arabic_known_titles):
            return -999
        title_n = _normalize_match_title(display_title)
        orig_n = _normalize_match_title(original_title)
        result_year = ((item.get('release_date') or item.get('first_air_date') or '')[:4])
        logo_direct_match = False
        if target:
            if title_n == target or orig_n == target:
                logo_direct_match = True
            elif title_n and (target in title_n or title_n in target):
                logo_direct_match = True
            elif orig_n and (target in orig_n or orig_n in target):
                logo_direct_match = True
        try:
            target_tokens = set(_logo_tmdb_meaningful_tokens(target))
            result_tokens = set(_logo_tmdb_meaningful_tokens(title_n) + _logo_tmdb_meaningful_tokens(orig_n))
            logo_token_hit = bool(target_tokens and result_tokens and target_tokens.intersection(result_tokens))
        except Exception:
            logo_token_hit = False
        if target and not logo_direct_match and not logo_token_hit:
            return -999
        score = 0
        if title_n == target:
            score += 500
        if orig_n == target:
            score += 450
        if target and title_n and (target in title_n or title_n in target):
            score += 130
        if target and orig_n and (target in orig_n or orig_n in target):
            score += 110
        if _contains_arabic(title) and _contains_arabic(item.get('name') or item.get('title') or ''):
            score += 90
        if year:
            if result_year == str(year):
                score += 500
            elif result_year:
                score -= 250
        try:
            score += min(float(item.get('popularity') or 0), 20)
        except Exception:
            pass
        return score
    except Exception:
        return -999
def _tmdb_search_multi(title, lang, year=None):
    """Return ranked (media_type, id) candidates for a title.

    TMDB multi search can miss or down-rank some Arabic/local works, so also
    query movie and tv directly and merge the ranked candidates.
    """
    if not title:
        return []

    title_clean, forced_year = _split_title_and_year_local(title)
    year = year or forced_year
    now = time.time()
    key = (title_clean, lang, year, 'multi_movie_tv')

    try:
        ts, cached = _SEARCH_CACHE.get(key, (0, None))
        if cached is not None and (now - ts) < CACHE_TTL_SEC:
            return cached
    except Exception:
        pass

    q = _quote(title_clean)
    ranked = []
    seen = set()
    for search_type in ('multi', 'tv', 'movie'):
        if lang:
            url = "https://api.themoviedb.org/3/search/%s?api_key=%s&query=%s&language=%s" % (search_type, TMDB_API_KEY, q, lang)
        else:
            url = "https://api.themoviedb.org/3/search/%s?api_key=%s&query=%s" % (search_type, TMDB_API_KEY, q)
        if year:
            if search_type == 'movie':
                url += "&year=%s" % year
            elif search_type == 'tv':
                url += "&first_air_date_year=%s" % year
            else:
                url += "&year=%s" % year
        data = _http_get_json(url)
        if not (data and 'results' in data):
            continue
        for it in data.get('results', []):
            mt = it.get('media_type')
            if search_type == 'tv':
                mt = 'tv'
                it['media_type'] = 'tv'
            elif search_type == 'movie':
                mt = 'movie'
                it['media_type'] = 'movie'
            tid = it.get('id')
            if mt in ('movie', 'tv') and tid is not None:
                dedupe_key = (mt, tid)
                if dedupe_key in seen:
                    continue
                seen.add(dedupe_key)
                ranked.append((_score_tmdb_logo_result(it, title_clean, year), mt, tid))
    ranked.sort(key=lambda x: x[0], reverse=True)
    results = [(mt, tid) for score, mt, tid in ranked if score > -999][:8]

    try:
        _SEARCH_CACHE[key] = (now, results)
    except Exception:
        pass
    return results

def _tmdb_images(media_type, tid):
    """Fetch /images once (cached)."""
    now = time.time()
    key = (media_type, tid)

    try:
        ts, cached = _IMG_CACHE.get(key, (0, None))
        if cached is not None and (now - ts) < CACHE_TTL_SEC:
            return cached
    except Exception:
        pass

    url = "https://api.themoviedb.org/3/%s/%s/images?api_key=%s" % (media_type, tid, TMDB_API_KEY)
    data = _http_get_json(url)

    logos = []
    if data:
        try:
            logos = data.get('logos', []) or []
        except Exception:
            logos = []

    try:
        _IMG_CACHE[key] = (now, logos)
    except Exception:
        pass

    return logos


def _pick_logo_file_path(logos, prefer_iso2):
    """Pick the best logo by language, PNG format, votes and dimensions."""
    if not logos:
        return None
    preferred = []
    def add(lang):
        if lang is None:
            lang = "null"
        lang = str(lang).lower()
        if lang not in preferred:
            preferred.append(lang)
    if prefer_iso2:
        add(prefer_iso2)
    add("ar")
    add("en")
    add("null")

    best = None
    best_score = -1
    for item in logos:
        try:
            fp = item.get('file_path')
            if not fp:
                continue
            iso = item.get('iso_639_1')
            iso_key = "null" if iso is None else str(iso).lower()
            score = 0
            if iso_key in preferred:
                score += 220 - preferred.index(iso_key) * 35
            if str(fp).lower().endswith('.png'):
                score += 80
            try:
                score += min(int(item.get('vote_count') or 0), 25)
                score += min(float(item.get('vote_average') or 0) * 5, 50)
                score += min(int(item.get('width') or 0) // 20, 50)
            except Exception:
                pass
            if score > best_score:
                best_score = score
                best = fp
        except Exception:
            continue
    return best


def _text_logo_font(size):
    """Return a font object for the generated text-logo fallback."""
    try:
        from PIL import ImageFont
        paths = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
            "/usr/share/enigma2/fonts/DejaVuSans-Bold.ttf",
            "/usr/share/enigma2/fonts/ae_AlMateen.ttf",
        ]
        for fp in paths:
            try:
                if os.path.exists(fp):
                    return ImageFont.truetype(fp, size)
            except Exception:
                continue
        return ImageFont.load_default()
    except Exception:
        return None


def _wrap_text_for_logo(draw, text, font, max_width):
    try:
        words = re.split(r'\s+', text.strip())
        lines = []
        cur = ''
        for word in words:
            test = (cur + ' ' + word).strip()
            try:
                bbox = draw.textbbox((0, 0), test, font=font)
                width = bbox[2] - bbox[0]
            except Exception:
                width = draw.textsize(test, font=font)[0]
            if width <= max_width or not cur:
                cur = test
            else:
                lines.append(cur)
                cur = word
            if len(lines) >= 1 and cur:
                # Keep fallback compact: max two lines.
                pass
        if cur:
            lines.append(cur)
        if len(lines) > 2:
            lines = [lines[0], ' '.join(lines[1:])]
        return lines[:2]
    except Exception:
        return [text[:36]]


def _create_text_logo(out_path, title):
    """Create a transparent PNG text logo as a last resort."""
    if not LOGO_TEXT_FALLBACK_ENABLED:
        return False
    try:
        from PIL import Image, ImageDraw
    except Exception:
        return False
    try:
        title = re.sub(r'\s+', ' ', str(title or '')).strip(' -:|')
        if not title or len(title) < 2:
            return False
        width, height = 420, 150
        img = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        font_size = 46
        font = _text_logo_font(font_size)
        if font is None:
            return False
        max_width = width - 28
        for size_try in (46, 42, 38, 34, 30, 26, 22):
            font = _text_logo_font(size_try)
            lines = _wrap_text_for_logo(draw, title, font, max_width)
            total_h = 0
            max_w = 0
            for line in lines:
                try:
                    bbox = draw.textbbox((0, 0), line, font=font)
                    w = bbox[2] - bbox[0]
                    h = bbox[3] - bbox[1]
                except Exception:
                    w, h = draw.textsize(line, font=font)
                total_h += h + 8
                max_w = max(max_w, w)
            if max_w <= max_width and total_h <= height - 20:
                break
        total_h = 0
        metrics = []
        for line in lines:
            try:
                bbox = draw.textbbox((0, 0), line, font=font)
                w = bbox[2] - bbox[0]
                h = bbox[3] - bbox[1]
            except Exception:
                w, h = draw.textsize(line, font=font)
            metrics.append((line, w, h))
            total_h += h + 8
        y = max(8, (height - total_h) // 2)
        for line, w, h in metrics:
            x = max(8, (width - w) // 2)
            # Shadow + white fill keeps the fallback visible on most skins.
            try:
                draw.text((x + 2, y + 2), line, font=font, fill=(0, 0, 0, 180))
                draw.text((x, y), line, font=font, fill=(255, 255, 255, 255))
            except Exception:
                draw.text((x, y), line, font=font, fill=(255, 255, 255, 255))
            y += h + 8
        tmp = out_path + '.tmp'
        img.save(tmp, 'PNG')
        if os.path.exists(out_path):
            try:
                os.remove(out_path)
            except Exception:
                pass
        os.rename(tmp, out_path)
        return os.path.exists(out_path) and os.path.getsize(out_path) > 0
    except Exception as e:
        _log('Text logo fallback failed: %s' % e)
        try:
            tmp = out_path + '.tmp'
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        return False


def _alias_logo_outputs(out_path, uid_path, title_path):
    try:
        if out_path and os.path.exists(out_path) and os.path.getsize(out_path) > 0:
            if title_path and not os.path.exists(title_path):
                ensure_logo_alias(out_path, title_path)
            if uid_path and not os.path.exists(uid_path):
                ensure_logo_alias(out_path, uid_path)
            if title_path and os.path.exists(title_path) and uid_path and not os.path.exists(uid_path):
                ensure_logo_alias(title_path, uid_path)
            return True
    except Exception:
        pass
    return False

def _download_logo(uid_path, title_path, clean_name, raw_title):
    """Download logo if possible; return True on success.

    Key behaviors (like FuryPosterX):
      - Save primarily under a stable UID filename (serviceRef+beginTime) so the
        logo does NOT change when EPG language changes.
      - Keep a backward-compatible alias under <CleanEventName>.png.
      - Search with original title first; if not found and title is non-Arabic,
        translate to English and retry.
    """
    if not uid_path and not title_path:
        return False

    _ensure_dir(LOGO_DIR)

    # If either file exists, ensure aliasing both ways and return.
    try:
        if uid_path and os.path.exists(uid_path) and os.path.getsize(uid_path) > 0:
            if title_path and not os.path.exists(title_path):
                ensure_logo_alias(uid_path, title_path)
            return True
        if title_path and os.path.exists(title_path) and os.path.getsize(title_path) > 0:
            if uid_path and not os.path.exists(uid_path):
                ensure_logo_alias(title_path, uid_path)
                if uid_path and os.path.exists(uid_path) and os.path.getsize(uid_path) > 0:
                    return True
            return True
    except Exception:
        pass

    out_path = uid_path or title_path
    if not out_path:
        return False

    titles = _title_variants(raw_title, clean_name)
    langs = _lang_candidates()
    if _contains_arabic(clean_name or raw_title):
        langs = ["ar", "ar-SA", "en-US", "en", None]

    prefer_iso2 = None
    try:
        for l in langs:
            if l:
                prefer_iso2 = str(l)[:2].lower()
                break
    except Exception:
        prefer_iso2 = None

    def _search(title_list, lang_list, year_override=None):
        for t in title_list:
            for lang in lang_list:
                res = _tmdb_search_multi(t, lang, year_override)
                if res:
                    return res, t, lang
        return None, None, None

    def _pick_from_results(result_list, prefer_lang):
        for (media_type, tid) in (result_list or [])[:3]:
            logos = _tmdb_images(media_type, tid)
            fp = _pick_logo_file_path(logos, prefer_lang)
            if fp:
                return (media_type, tid), fp
        return None, None

    # Phase 1: original-language title(s)
    best, used_title, used_lang = _search(titles, langs)

    # Phase 2: use ElCinema as an Arabic metadata resolver for stricter TMDB logo matching.
    # ElCinema does not normally provide transparent logos, so this only improves the
    # Arabic title/year used to locate the correct TMDB logo artwork.
    used_elcinema_hint = False
    elcinema_hints = []
    try:
        if _contains_arabic(clean_name or raw_title):
            for source_title in titles[:3]:
                elcinema_hints.extend(_elcinema_logo_title_hints(source_title))
    except Exception:
        elcinema_hints = []

    if not best and elcinema_hints:
        for hint_title, hint_year in elcinema_hints:
            best, used_title, used_lang = _search([hint_title], ["ar", "ar-SA", "en-US", "en", None], hint_year)
            if best:
                used_elcinema_hint = True
                break

    # Phase 3: translate to English (ONLY if not Arabic-script)
    used_translated = False
    if not best:
        trans_src = None
        try:
            trans_src = clean_name or raw_title
        except Exception:
            trans_src = raw_title
        translated = None if _contains_arabic(trans_src) else translate_to_en(trans_src)
        if translated and translated not in titles:
            best, used_title, used_lang = _search([translated], ["en-US", "en", None])
            used_translated = bool(best)

    if not best:
        _log("TMDB search failed (original+ElCinema+EN fallback): %s" % (clean_name or raw_title))
        if _create_text_logo(out_path, clean_name or raw_title):
            return _alias_logo_outputs(out_path, uid_path, title_path)
        return False

    chosen = None
    file_path = None

    # If we used translation fallback, prefer EN logos first.
    prefer_iso2_eff = "en" if used_translated else prefer_iso2

    chosen, file_path = _pick_from_results(best, prefer_iso2_eff)

    # If the first Arabic TMDB result has no logo, retry with ElCinema's exact
    # Arabic title/year hints before giving up.
    if not file_path and elcinema_hints and not used_elcinema_hint:
        for hint_title, hint_year in elcinema_hints:
            hint_best, hint_used_title, hint_used_lang = _search([hint_title], ["ar", "ar-SA", "en-US", "en", None], hint_year)
            hint_chosen, hint_file_path = _pick_from_results(hint_best, prefer_iso2_eff)
            if hint_file_path:
                best = hint_best
                used_title = hint_used_title
                used_lang = hint_used_lang
                chosen = hint_chosen
                file_path = hint_file_path
                used_elcinema_hint = True
                break

    if not file_path:
        _log("No TMDB logos for: %s (title=%s lang=%s)" % (clean_name, used_title, used_lang))
        if _create_text_logo(out_path, clean_name or raw_title):
            return _alias_logo_outputs(out_path, uid_path, title_path)
        return False

    url_img = "https://image.tmdb.org/t/p/w%s%s" % (TMDB_LOGO_SIZE, file_path)
    tmp = out_path + ".tmp"

    ok = _http_download(url_img, tmp)

    if not ok:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        _log("Download failed: %s" % url_img)
        return False

    try:
        if os.path.exists(out_path):
            os.remove(out_path)
    except Exception:
        pass

    try:
        os.rename(tmp, out_path)
    except Exception:
        try:
            import shutil
            shutil.copyfile(tmp, out_path)
            os.remove(tmp)
        except Exception:
            return False

    # Ensure both uid-based and title-based filenames exist for compatibility.
    try:
        if out_path and os.path.exists(out_path) and os.path.getsize(out_path) > 0:
            if title_path and not os.path.exists(title_path):
                ensure_logo_alias(out_path, title_path)
            if uid_path and not os.path.exists(uid_path):
                ensure_logo_alias(out_path, uid_path)
            if title_path and os.path.exists(title_path) and uid_path and not os.path.exists(uid_path):
                ensure_logo_alias(title_path, uid_path)
    except Exception:
        pass

    _log("Saved logo: %s (from %s/%s)" % (out_path, chosen[0], chosen[1] if chosen else "?"))
    return os.path.exists(out_path) and os.path.getsize(out_path) > 0


# ---------- Global guards ----------
_IN_PROGRESS = set()
_LAST_FAIL = {}
_LOCK = threading.Lock()


class furylogo(Renderer):
    """Renderer that shows event logo; if missing it downloads from TMDB then displays."""

    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self._last_path = None
        self._last_title = None

        # Debounce + polling (like FuryPosterX):
        # - Debounce prevents starting network work during rapid zapping.
        # - Polling updates the pixmap as soon as the background download finishes
        #   without calling eTimer APIs from a worker thread.
        self._pollTimer = eTimer()
        self._debounceTimer = eTimer()
        self._expected_paths = None
        self._poll_deadline = 0
        self._pending_download = None
        self._request_seq = 0
        self._active_key = None
        try:
            self._pollTimer.callback.append(self._poll_logo)
        except Exception:
            try:
                self._pollTimer.timeout.get().append(self._poll_logo)
            except Exception:
                pass
        try:
            self._debounceTimer.callback.append(self._debounced_fetch)
        except Exception:
            try:
                self._debounceTimer.timeout.get().append(self._debounced_fetch)
            except Exception:
                pass

        self._timer = eTimer()
        try:
            self._timer.callback.append(self._refresh)
        except Exception:
            try:
                self._timer.timeout.get().append(self._refresh)
            except Exception:
                pass

    def _refresh(self):
        try:
            self.changed((self.CHANGED_ALL,))
        except Exception:
            pass

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._last_path = None
            self._last_title = None
            self._expected_paths = None
            self._pending_download = None
            self._poll_deadline = 0
            try:
                self._pollTimer.stop()
            except Exception:
                pass
            try:
                self._debounceTimer.stop()
            except Exception:
                pass
            try:
                _clear_pixmap(self.instance)
            except Exception:
                pass
            return

        event = None
        try:
            event = self.source.event
        except Exception:
            event = None

        if not event:
            try:
                _clear_pixmap(self.instance)
            except Exception:
                pass
            return

        try:
            raw = event.getEventName() or ""
        except Exception:
            raw = ""

        clean = _event_to_clean_name(raw)

        # New event/title: immediately clear old pixmap and cancel stale timers.
        if clean != self._last_title:
            self._request_seq += 1
            self._last_title = clean
            self._last_path = None
            self._active_key = None
            self._expected_paths = None
            self._pending_download = None
            self._poll_deadline = 0
            try:
                self._pollTimer.stop()
                self._debounceTimer.stop()
            except Exception:
                pass
            try:
                _clear_pixmap(self.instance)
            except Exception:
                pass

        if not clean:
            try:
                _clear_pixmap(self.instance)
            except Exception:
                pass
            return

        # Build stable uid (serviceRef+beginTime) so saved logo stays the same
        # even if event title changes with EPG language.
        begin_time = None
        try:
            begin_time = event.getBeginTime()
        except Exception:
            begin_time = None

        service_id = None
        try:
            nav = getattr(NavigationInstance, 'instance', None)
            if nav is not None:
                ref = nav.getCurrentlyPlayingServiceReference()
                if ref is not None:
                    try:
                        service_id = ref.toString()
                    except Exception:
                        try:
                            service_id = str(ref)
                        except Exception:
                            service_id = None
        except Exception:
            service_id = None

        uid = build_event_uid(service_id, begin_time)
        uid_path = _logo_uid_path(uid) if (LOGO_USE_UID_CACHE and uid) else None
        title_path = _logo_path(clean)

        # If UID cache is explicitly enabled, alias legacy title logo to uid.
        # Disabled by default because some EPG screens report the currently-playing
        # service, not the selected event service, causing wrong repeated logos.
        try:
            if LOGO_USE_UID_CACHE and title_path and uid_path and os.path.exists(title_path) and not os.path.exists(uid_path):
                ensure_logo_alias(title_path, uid_path)
        except Exception:
            pass

        # Prefer the accurate title-based logo by default.
        for path in (uid_path, title_path):
            if path and os.path.exists(path) and os.path.getsize(path) > 0:
                if path != self._last_path:
                    self._last_path = path
                    try:
                        self.instance.setPixmap(loadPNG(path))
                        self.instance.setScale(1)
                    except Exception:
                        pass
                try:
                    self.instance.show()
                except Exception:
                    pass
                # Stop any polling once we have a logo.
                self._expected_paths = None
                self._pending_download = None
                self._poll_deadline = 0
                try:
                    self._pollTimer.stop()
                except Exception:
                    pass
                return

        now = time.time()
        key = (uid if (LOGO_USE_UID_CACHE and uid) else clean)
        with _LOCK:
            last_fail = _LAST_FAIL.get(key, 0)
            if (now - last_fail) < RETRY_COOLDOWN_SEC:
                try:
                    _clear_pixmap(self.instance)
                except Exception:
                    pass
                return

            # Debounce download start to avoid stutter during fast zapping.
            # We'll schedule the download in ~250ms; if the user zaps again,
            # the pending request will be replaced.
            self._pending_download = (self._request_seq, key, uid_path, title_path, clean, raw)
            self._active_key = key

        # Expected logo paths are kept, but polling starts only after the
        # debounced download begins. This avoids filesystem polling while
        # scrolling quickly through non-English EPG entries.
        self._expected_paths = [p for p in (uid_path, title_path) if p]
        self._poll_deadline = time.time() + 10

        debounce_ms = LOGO_DEBOUNCE_MS
        try:
            if (not _is_latin_script(clean)) or _looks_albanian_text(clean):
                debounce_ms = LOGO_NON_LATIN_DEBOUNCE_MS
        except Exception:
            debounce_ms = LOGO_NON_LATIN_DEBOUNCE_MS

        try:
            self._debounceTimer.start(debounce_ms, True)
        except Exception:
            pass

        try:
            _clear_pixmap(self.instance)
        except Exception:
            pass

    def _bg_download(self, key, uid_path, title_path, clean_name, raw_title):
        ok = False
        try:
            ok = _download_logo(uid_path, title_path, clean_name, raw_title)
        except Exception as e:
            _log("bg error: %s" % e)
            ok = False

        with _LOCK:
            try:
                _IN_PROGRESS.remove(key)
            except Exception:
                pass
            if not ok:
                _LAST_FAIL[key] = time.time()

        # Do not touch eTimer from this thread. UI update is handled by polling.


    def _debounced_fetch(self):
        """Start the background download after a short debounce delay."""
        if not self._pending_download:
            return

        try:
            seq, key, uid_path, title_path, clean_name, raw_title = self._pending_download
        except Exception:
            return

        # Ignore stale delayed calls from the previous selected event.
        try:
            if seq != self._request_seq or key != self._active_key:
                return
        except Exception:
            return

        # If logo arrived during debounce, do nothing.
        for p in (uid_path, title_path):
            try:
                if p and os.path.exists(p) and os.path.getsize(p) > 0:
                    return
            except Exception:
                pass

        with _LOCK:
            already_running = key in _IN_PROGRESS
            if not already_running:
                _IN_PROGRESS.add(key)

        # Start polling only after the request survived debounce.
        try:
            self._pollTimer.start(LOGO_POLL_MS, True)
        except Exception:
            pass

        if already_running:
            return

        t = threading.Thread(target=self._bg_download, args=(key, uid_path, title_path, clean_name, raw_title))
        t.daemon = True
        t.start()


    def _poll_logo(self):
        """Non-blocking poll: when file appears, show it immediately."""
        try:
            if not self.instance:
                return
        except Exception:
            return

        # Stop if no longer waiting.
        if not self._expected_paths:
            return

        # Timeout safety.
        try:
            if self._poll_deadline and time.time() > self._poll_deadline:
                self._expected_paths = None
                self._poll_deadline = 0
                return
        except Exception:
            pass

        # Prefer first existing path.
        found = None
        for p in self._expected_paths:
            try:
                if p and os.path.exists(p) and os.path.getsize(p) > 0:
                    found = p
                    break
            except Exception:
                continue

        if found:
            if found != self._last_path:
                self._last_path = found
                try:
                    self.instance.setPixmap(loadPNG(found))
                    self.instance.setScale(1)
                except Exception:
                    pass
            try:
                self.instance.show()
            except Exception:
                pass

            self._expected_paths = None
            self._poll_deadline = 0
            return

        # Continue polling.
        try:
            self._pollTimer.start(LOGO_POLL_MS, True)
        except Exception:
            pass


# Compatibility alias
FuryLogo = furylogo
