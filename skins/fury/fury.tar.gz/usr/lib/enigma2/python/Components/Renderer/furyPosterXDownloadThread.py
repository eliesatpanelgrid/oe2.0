# -*- coding: utf-8 -*-
# Improving the performance of information and poster retrieval by Islam Salama
# recode from Islam Salama 2026
from __future__ import absolute_import
from Components.config import config
from PIL import Image
from enigma import getDesktop
import os
import re
import requests
import socket
import sys
import threading
import unicodedata
import random
import json
import time
from random import choice
from difflib import SequenceMatcher
from requests import get, exceptions
from twisted.internet.reactor import callInThread
from .furyConverlibr import quoteEventName, split_title_and_year, clean_search_title


try:
    from http.client import HTTPConnection
    HTTPConnection.debuglevel = 0
except ImportError:
    from httplib import HTTPConnection
    HTTPConnection.debuglevel = 0
from requests.adapters import HTTPAdapter, Retry

global my_cur_skin, srch

PY3 = False
if sys.version_info[0] >= 3:
    PY3 = True
    import html
    html_parser = html
else:
    from HTMLParser import HTMLParser
    html = HTMLParser()


try:
    from urllib.error import URLError, HTTPError
    from urllib.request import urlopen
except:
    from urllib2 import URLError, HTTPError
    from urllib2 import urlopen


try:
    lng = config.osd.language.value
    lng = lng[:-3]
except:
    lng = 'en'
    pass


def getRandomUserAgent():
    useragents = [
        'Mozilla/5.0 (compatible; Konqueror/4.5; FreeBSD) KHTML/4.5.4 (like Gecko)',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:29.0) Gecko/20120101 Firefox/29.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20120101 Firefox/35.0',
        'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0',
        'Mozilla/5.0 (X11; Linux x86_64; rv:28.0) Gecko/20100101 Firefox/28.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.13+ (KHTML, like Gecko) Version/5.1.7 Safari/534.57.2',
        'Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; de) Presto/2.9.168 Version/11.52',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101 Firefox/91.0'
    ]
    return random.choice(useragents)


tmdb_api = "3c3efcf47c3577558812bb9d64019d65"
omdb_api = "cb1d9f55"
# thetvdbkey = 'D19315B88B2DE21F'
thetvdbkey = "a99d487bb3426e5f3a60dea6d3d3c7ef"
fanart_api = "6d231536dea4318a88cb2520ce89473b"
my_cur_skin = False
cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')


try:
    if my_cur_skin is False:
        skin_paths = {
            "tmdb_api": "/usr/share/enigma2/{}/tmdbkey".format(cur_skin),
            "omdb_api": "/usr/share/enigma2/{}/omdbkey".format(cur_skin),
            "thetvdbkey": "/usr/share/enigma2/{}/thetvdbkey".format(cur_skin)
        }
        for key, path in skin_paths.items():
            if os.path.exists(path):
                with open(path, "r") as f:
                    value = f.read().strip()
                    if key == "tmdb_api":
                        tmdb_api = value
                    elif key == "omdb_api":
                        omdb_api = value
                    elif key == "thetvdbkey":
                        thetvdbkey = value
                my_cur_skin = True
except Exception as e:
    print("Errore nel caricamento delle API:", str(e))
    my_cur_skin = False


isz = "185,278"
bisz = "300,450"
screenwidth = getDesktop(0).size()
if screenwidth.width() <= 1280:
    isz = isz.replace(isz, "185,278")
    bisz = bisz.replace(bisz, "300,450")
elif screenwidth.width() <= 1920:
    isz = isz.replace(isz, "342,514")
    bisz = bisz.replace(bisz, "780,1170")
else:
    isz = isz.replace(isz, "780,1170")
    bisz = bisz.replace(bisz, "1280,1920")


def isMountedInRW(mount_point):
    with open("/proc/mounts", "r") as f:
        for line in f:
            parts = line.split()
            if len(parts) > 1 and parts[1] == mount_point:
                return True
    return False


path_folder = "/tmp/backdrop"
if os.path.exists("/media/hdd"):
    if isMountedInRW("/media/hdd"):
        path_folder = "/media/hdd/FuryPoster/backdrop"
elif os.path.exists("/media/usb"):
    if isMountedInRW("/media/usb"):
        path_folder = "/media/usb/FuryPoster/backdrop"
elif os.path.exists("/media/mmc"):
    if isMountedInRW("/media/mmc"):
        path_folder = "/media/mmc/FuryPoster/backdrop"
if not os.path.exists(path_folder):
    os.makedirs(path_folder)

# ---------------------------------------------------------------------
# Low bandwidth guard
# ---------------------------------------------------------------------
# Provider methods already run in a background worker. Calling savePoster()
# synchronously here prevents spawning many parallel image downloads for the
# same poster while the worker immediately continues to the next provider.
_download_guard_lock = threading.RLock()
_download_in_progress = set()

# Hard bandwidth caps. These only affect oversized downloads/scraper fallbacks;
# normal poster files from TMDB are much smaller and continue to work.
POSTER_IMAGE_MAX_BYTES = 480 * 1024
POSTER_SEARCH_TIMEOUT = (2, 5)
POSTER_DOWNLOAD_TIMEOUT = (2, 5)
TMDB_POSTER_SIZE = "w154"


# ElCinema TV-guide fallback based on the xtraevent flow.
# It does not require an API key: tvguide -> work page -> poster jpg.
ELCINEMA_TVGUIDE_URL = "https://elcinema.com/en/tvguide/"
ELCINEMA_CACHE_TTL = 30 * 60
_ELCINEMA_CACHE_TS = 0
_ELCINEMA_CACHE_ENTRIES = []

def _fx_text(value):
    try:
        if value is None:
            return u''
        if isinstance(value, bytes):
            return value.decode('utf-8', 'ignore')
        try:
            return unicode(value)  # type: ignore[name-defined]
        except Exception:
            return str(value)
    except Exception:
        try:
            return str(value)
        except Exception:
            return u''

def _fx_html_unescape(value):
    try:
        txt = _fx_text(value)
        try:
            if PY3:
                return html_parser.unescape(txt)
            return html.unescape(txt)
        except Exception:
            return (txt.replace('&#39;', "'").replace('&quot;', '"')
                       .replace('&amp;', '&').replace('&nbsp;', ' '))
    except Exception:
        return _fx_text(value)

def _fx_contains_arabic(value):
    try:
        for ch in _fx_text(value):
            o = ord(ch)
            if (0x0600 <= o <= 0x06FF) or (0x0750 <= o <= 0x077F) or (0x08A0 <= o <= 0x08FF) or (0xFB50 <= o <= 0xFDFF) or (0xFE70 <= o <= 0xFEFF):
                return True
    except Exception:
        pass
    return False

def _fx_strip_tags(value):
    try:
        txt = re.sub(r'<script.*?</script>', ' ', _fx_text(value), flags=re.I | re.S)
        txt = re.sub(r'<style.*?</style>', ' ', txt, flags=re.I | re.S)
        txt = re.sub(r'<[^>]+>', ' ', txt)
        txt = _fx_html_unescape(txt)
        return re.sub(r'\s+', ' ', txt).strip()
    except Exception:
        return _fx_text(value).strip()

def _fx_attr(tag, name):
    try:
        m = re.search(name + r'\s*=\s*["\']([^"\']+)["\']', _fx_text(tag), flags=re.I | re.S)
        return _fx_html_unescape(m.group(1)).strip() if m else ''
    except Exception:
        return ''

def _fx_is_arabic_channel(channel):
    try:
        ch = _fx_norm_title(channel)
        if not ch:
            return False
        if _fx_contains_arabic(ch):
            return True
        hints = (
            'mbc', 'rotana', 'dmc', 'cbc', 'on drama', 'on e', 'alhayah', 'hayah',
            'annahar', 'nahar', 'sada el balad', 'sada', 'sharjah', 'dubai',
            'abudhabi', 'abu dhabi', 'emarat', 'emirates', 'ksa', 'saudi',
            'iqraa', 'majid', 'zee aflam', 'zee alwan', 'al arabiya', 'alarabiya',
            'bein', 'masr', 'almasriya', 'bahrain', 'kuwait', 'oman', 'qatar',
            'palestine', 'falastin', '2m', 'watania', 'sumaria', 'alsumaria'
        )
        for hint in hints:
            if hint in ch:
                return True
    except Exception:
        pass
    return False


def _fx_is_generic_event_title(value):
    try:
        n = _fx_norm_title(value)
        generic = set([
            u'برنامج', u'برامج', u'فيلم', u'افلام', u'مسلسل', u'مسلسلات',
            u'اخبار', u'نشره', u'النشره', u'النشره الجويه', u'طقس',
            'movie', 'film', 'series', 'program', 'show', 'news', 'weather'
        ])
        return n in generic or len(n) < 3
    except Exception:
        return False

def _fx_elcinema_title_variants(title):
    """Build safe ElCinema query variants from noisy EPG titles."""
    out = []
    seen = set()
    def add(x):
        try:
            x = _fx_html_unescape(x or '')
            x = x.replace('+', ' ')
            x = re.sub(r'\s+', ' ', x).strip(' -:|;,')
            if len(x) < 3:
                return
            if _fx_is_generic_event_title(x):
                return
            k = _fx_norm_title(x)
            if k and k not in seen:
                seen.add(k)
                out.append(x)
        except Exception:
            pass
    raw = _fx_text(title)
    for _ar_alias in _arabic_latin_title_aliases(raw):
        add(_ar_alias)
    add(raw)
    try:
        clean = clean_search_title(raw)
    except Exception:
        clean = raw
    for _ar_alias in _arabic_latin_title_aliases(clean):
        add(_ar_alias)
    add(clean)
    try:
        # Remove common Arabic/English programme prefixes and episode tails.
        c = re.sub(u'^\\s*(?:فيلم|مسلسل|برنامج|مسرحية|سهرة|movie|film|series|program|show)\\s*[:\\-–|]*\\s*', ' ', clean, flags=re.I)
        c = re.sub(u'(?:\\s+S\\d+|\\s+سيزون\\s*\\d+|\\s+الموسم\\s*\\d+|\\s+الجزء\\s*\\d+|\\s+حلقة\\s*\\d+|\\s+الحلقة\\s*\\d+|\\s+ح\\s*\\d+|\\s+ج\\s*\\d+)$', ' ', c, flags=re.I)
        add(c)
        # If the EPG has a suffix after dash/colon, it can be the real title.
        for part in re.split(u'[-–:|/]', clean):
            add(part)
    except Exception:
        pass
    return out[:8]

def _fx_norm_title(value):
    try:
        txt = _fx_html_unescape(value).lower()
        txt = unicodedata.normalize('NFKC', txt)
        txt = re.sub(u'[\u064b-\u065f\u0670\u0640]', '', txt)
        for src, dst in ((u'أ', u'ا'), (u'إ', u'ا'), (u'آ', u'ا'), (u'ى', u'ي'), (u'ؤ', u'و'), (u'ئ', u'ي'), (u'ة', u'ه')):
            txt = txt.replace(src, dst)
        txt = re.sub(u'[^\\w\u0600-\u06FF]+', ' ', txt, flags=re.UNICODE)
        txt = re.sub(r'\s+', ' ', txt).strip()
        return txt
    except Exception:
        return _fx_text(value).lower().strip()




def _fx_title_words(value):
    try:
        n = _fx_norm_title(value)
        stop = set(['the', 'a', 'an', 'and', 'or', 'of', 'to'])
        words = [w for w in n.split() if len(w) > 1 and w not in stop]
        return n, words
    except Exception:
        return _fx_text(value).lower().strip(), []

def _fx_is_clear_title_mismatch(query, found):
    """Block only obvious wrong Latin matches while keeping broad poster search."""
    try:
        qn, qw = _fx_title_words(query)
        fn, fw = _fx_title_words(found)
        if not qn or not fn:
            return False
        if _fx_contains_arabic(qn) or _fx_contains_arabic(fn):
            return False
        if qn == fn or qn in fn or fn in qn:
            return False
        qs = set(qw)
        fs = set(fw)
        if len(qs) >= 2 and len(fs) >= 2:
            common = len(qs.intersection(fs))
            ratio = int(SequenceMatcher(None, qn, fn).ratio() * 100)
            # Example: "Hamlet Ferizer" must not match "Hamlet Within".
            # Keep close typos accepted, but reject candidates that share only one word.
            if common == 1 and ratio < 72:
                return True
        return False
    except Exception:
        return False

def _fx_all_known_titles_clear_mismatch(query, titles):
    try:
        known = [t for t in titles if t]
        return bool(known) and all(_fx_is_clear_title_mismatch(query, t) for t in known)
    except Exception:
        return False

def _reserve_download_target(path):
    try:
        if not path:
            return False
        if os.path.exists(path) and os.path.getsize(path) > 0:
            return False
        with _download_guard_lock:
            if path in _download_in_progress:
                return False
            _download_in_progress.add(path)
            return True
    except Exception:
        return True

def _release_download_target(path):
    try:
        with _download_guard_lock:
            _download_in_progress.discard(path)
    except Exception:
        pass


_adsl_ok = None

def intCheck(timeout=1):
    """Lightweight connectivity probe.
    Keep timeout short to avoid UI stalls at startup."""
    try:
        response = urlopen("http://google.com", None, timeout)
        response.close()
    except HTTPError:
        return False
    except URLError:
        return False
    except socket.timeout:
        return False
    except Exception:
        return False
    return True

def intCheck_cached(timeout=1):
    global _adsl_ok
    if _adsl_ok is None:
        _adsl_ok = intCheck(timeout=timeout)
    return _adsl_ok


# ---------------------------------------------------------------------
# Albanian EPG title support (Digital Alb / Shqip)
# ---------------------------------------------------------------------
_ALBANIAN_TRANSLATE_CACHE = {}
_ALBANIAN_CHANNEL_HINTS = (
    'digital alb', 'digitalb', 'digit alb', 'alb premium', 'alb', 'shqip',
    'shqiptar', 'albania', 'kosova', 'kosovo', 'rtk', 'klan', 'top channel',
    'vizion plus', 'tring', 'artmotion', 'novelas+'
)
_ALBANIAN_WORD_HINTS = set([
    u'dhe', u'në', u'ne', u'për', u'per', u'nga', u'një', u'nje', u'është', u'eshte',
    u'vrasje', u'ambasadë', u'ambasade', u'lindja', u'dragoi', u'dragoit',
    u'hiri', u'kurajo', u'dashuri', u'jeta', u'familja', u'sekret', u'lufta',
    u'mbreti', u'zemra', u'hëna', u'hena', u'deti', u'natës', u'nates', u'dielli',
    u'bota', u'gruaja', u'vajza', u'djalë', u'djale', u'shtëpi', u'shtepi',
    u'pa', u'shtet', u'fund', u'tragjik', u'biri', u'bir', u'zdrukthëtarit', u'zdrukthetarit',
    u'zdrukthëtar', u'zdrukthetar', u'zjarr', u'hi', u'avatar', u'avatari', u'snajper',
    u'nusja', u'nuse', u'trendafili', u'trëndafili', u'tetëmbëdhjetë', u'tetembedhjete',
    u'rose', u'bride', u'violent', u'ends', u'carpenter', u'nation'
])



_ALBANIAN_TITLE_ALIAS_MAP = {
    u'trendafili i tetembedhjete': (u'18th Rose', u'Eighteenth Rose', u'The Eighteenth Rose'),
    u'trendafili tetembedhjete': (u'18th Rose', u'Eighteenth Rose', u'The Eighteenth Rose'),
    u'nusja': (u'The Bride!', u'The Bride'),
    u'snajper pa shtet': (u'Sniper: No Nation', u'Sniper No Nation'),
    u'fund tragjik': (u'Violent Ends',),
    u'avatari zjarr e hi': (u'Avatar: Fire and Ash',),
    u'avatar zjarr e hi': (u'Avatar: Fire and Ash',),
    u'biri i zdrukthetarit': (u"The Carpenter's Son", u'The Carpenter Son'),
    u'biri zdrukthetarit': (u"The Carpenter's Son", u'The Carpenter Son'),
}

# ---------------------------------------------------------------------
# Arabic channels with Latin EPG transliteration (Rotana Classic, etc.)
# ---------------------------------------------------------------------
# Some Arabic movie channels publish EPG titles in Latin transliteration.
# TMDB can then return a different Arabic title with a similar prefix, e.g.
# "Resalet Gharaam" -> "رسالة الإمام".  These aliases make the first lookup
# use the real Arabic title, and the stricter Arabic word check below rejects
# one-word/loose false positives.
_ARABIC_LATIN_TITLE_ALIAS_MAP = {
    u'resalet gharam': (u'رسالة غرام', u'Resalet Gharam', u'Resalat Gharam'),
    u'resalat gharam': (u'رسالة غرام', u'Resalet Gharam', u'Resalat Gharam'),
    u'kolohom awladi': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'kolhom awladi': (u'كلهم أولادي', u'Kolohom Awlady', u'Kolhom Awlady'),
    u'prayer el caravan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'prayer al caravan': (u'دعاء الكروان', u'The Nightingale\'s Prayer', u'Doaa Al Karawan'),
    u'doaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer'),
    u'duaa al karawan': (u'دعاء الكروان', u'The Nightingale\'s Prayer'),
    u'mawed ma eblees': (u'موعد مع إبليس', u'Mawed Maa Eblis'),
    u'mawed maa eblees': (u'موعد مع إبليس', u'Mawed Maa Eblis'),
    u'el anesa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anesa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'el anisa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al anisa hanafy': (u'الآنسة حنفي', u'El Anesa Hanafy'),
    u'al habeb al maghol': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'el habeb el maghol': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'al habib al majhoul': (u'الحبيب المجهول', u'Al Habeb Al Maghol'),
    u'el kaf': (u'الكف', u'El Kaf'),
    u'al kaf': (u'الكف', u'El Kaf'),
    u'nehayet el tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nihayet el tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'nehayet al tareek': (u'نهاية الطريق', u'Nehayet El Tareek'),
    u'al rakesa wal tabaal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'el rakesa wal tabaal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'al raqisa wal tabal': (u'الراقصة والطبال', u'Al Rakesa Wal Tabaal'),
    u'al ghawwas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawwas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawas': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawwas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawwas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'el ghawas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'al ghawas movie': (u'الغواص', u'Al Ghawwas', u'El Ghawwas'),
    u'ghesh el zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish el zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish al zawjya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghish el zawgeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgiya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgiya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawgia': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh al zawgia': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
    u'ghesh el zawjeya': (u'غش الزوجية', u'Ghesh El Zawjya', u'Ghesh El Zawgya'),
}


def _arabic_latin_norm_key(value):
    try:
        txt = _alb_to_text(value).lower()
        txt = txt.replace(u'’', u' ').replace(u"'", u' ')
        txt = re.sub(u'[^a-z0-9]+', ' ', txt, flags=re.UNICODE)
        txt = re.sub(r'a{2,}', 'a', txt)
        txt = re.sub(r'e{2,}', 'e', txt)
        txt = re.sub(r'i{2,}', 'i', txt)
        txt = re.sub(r'o{2,}', 'o', txt)
        txt = re.sub(r'u{2,}', 'u', txt)
        txt = re.sub(r'\s+', ' ', txt).strip()
        return txt
    except Exception:
        return ''


def _arabic_latin_title_aliases(value):
    try:
        key = _arabic_latin_norm_key(value)
        if not key:
            return []
        aliases = []
        for k, vals in _ARABIC_LATIN_TITLE_ALIAS_MAP.items():
            kk = _arabic_latin_norm_key(k)
            # exact match, or exact title plus channel/noise suffix.
            if key == kk or key.startswith(kk + ' ') or (len(kk) >= 8 and kk in key):
                for v in vals:
                    if v and v not in aliases:
                        aliases.append(v)
        return aliases[:5]
    except Exception:
        return []


def _fx_arabic_words(value):
    try:
        n = _fx_norm_title(value)
        stop = set([u'ال', u'و', u'في', u'من', u'علي', u'على', u'مع', u'يا'])
        return [w for w in n.split() if len(w) > 1 and w not in stop]
    except Exception:
        return []


def _fx_is_clear_arabic_title_mismatch(query, found):
    try:
        if not (_fx_contains_arabic(query) and _fx_contains_arabic(found)):
            return False
        qn = _fx_norm_title(query)
        fn = _fx_norm_title(found)
        if not qn or not fn:
            return False
        if qn == fn or qn in fn or fn in qn:
            return False
        qw = set(_fx_arabic_words(query))
        fw = set(_fx_arabic_words(found))
        if len(qw) >= 2 and len(fw) >= 2:
            common = qw.intersection(fw)
            ratio = int(SequenceMatcher(None, qn, fn).ratio() * 100)
            if not common:
                return True
            # Sharing only a generic first word is how "رسالة غرام" matched
            # "رسالة الإمام". Keep close typos, reject loose one-word matches.
            if len(common) == 1 and ratio < 72:
                return True
        return False
    except Exception:
        return False


def _albanian_norm_key(value):
    try:
        txt = _alb_to_text(value).lower()
        repl = ((u'ë', u'e'), (u'ç', u'c'), (u'á', u'a'), (u'à', u'a'), (u'ä', u'a'),
                (u'é', u'e'), (u'è', u'e'), (u'í', u'i'), (u'ì', u'i'), (u'ó', u'o'),
                (u'ò', u'o'), (u'ú', u'u'), (u'ù', u'u'))
        for src, dst in repl:
            txt = txt.replace(src, dst)
        txt = re.sub(u'[^a-z0-9]+', ' ', txt, flags=re.UNICODE)
        txt = re.sub(r'\s+', ' ', txt).strip()
        return txt
    except Exception:
        return ''


def _albanian_title_aliases(value):
    try:
        key = _albanian_norm_key(value)
        if not key:
            return []
        aliases = []
        for k, vals in _ALBANIAN_TITLE_ALIAS_MAP.items():
            if key == k or (len(key) >= 6 and (key in k or k in key)):
                for v in vals:
                    if v and v not in aliases:
                        aliases.append(v)
        return aliases[:4]
    except Exception:
        return []
def _alb_to_text(val):
    try:
        if val is None:
            return u''
        if isinstance(val, bytes):
            return val.decode('utf-8', 'ignore')
        try:
            return unicode(val)  # type: ignore[name-defined]
        except Exception:
            return str(val)
    except Exception:
        try:
            return str(val)
        except Exception:
            return u''

def _is_albanian_channel(channel):
    try:
        ch = _alb_to_text(channel).lower()
        ch = re.sub(r'[^a-z0-9+]+', ' ', ch)
        ch = re.sub(r'\s+', ' ', ch).strip()
        if not ch:
            return False
        for hint in _ALBANIAN_CHANNEL_HINTS:
            h = hint.lower()
            if h == 'alb':
                if re.search(r'\balb\b', ch):
                    return True
            elif h in ch:
                return True
        return False
    except Exception:
        return False

def _looks_albanian_text(title):
    try:
        txt = _alb_to_text(title)
        if not txt:
            return False
        if _albanian_title_aliases(txt):
            return True
        if re.search(u'[ëËçÇ]', txt):
            return True
        words = re.findall(u"[A-Za-zëËçÇ]+", txt.lower())
        if not words:
            return False
        hits = 0
        for w in words:
            if w in _ALBANIAN_WORD_HINTS:
                hits += 1
        # One strong Albanian word like 'dhe', 'lindja', 'dragoit' is enough
        # for EPG titles; otherwise require at least two softer hints.
        if any(w in words for w in ('dhe', 'lindja', 'dragoit', 'dragoi', 'vrasje', 'hiri', 'kurajo')):
            return True
        return hits >= 2
    except Exception:
        return False

def _translate_albanian_query(title, channel=None):
    try:
        src = _alb_to_text(title).replace('+', ' ')
        src = re.sub(r'\s+', ' ', src).strip(' -:|')
        if not src or len(src) < 3:
            return None
        if not (_is_albanian_channel(channel) or _looks_albanian_text(src)):
            return None
        key = src.lower()
        if key in _ALBANIAN_TRANSLATE_CACHE:
            return _ALBANIAN_TRANSLATE_CACHE.get(key)
        aliases = _albanian_title_aliases(src)
        if aliases:
            _ALBANIAN_TRANSLATE_CACHE[key] = aliases[0]
            return aliases[0]
        try:
            resp = requests.get(
                'https://translate.googleapis.com/translate_a/single',
                params={'client': 'gtx', 'sl': 'auto', 'tl': 'en', 'dt': 't', 'q': src},
                headers={'User-Agent': getRandomUserAgent()},
                timeout=(2, 4),
                verify=False
            )
            data = resp.json()
            translated = u''
            try:
                translated = u''.join(_alb_to_text(part[0]) for part in data[0] if part and len(part) > 0 and part[0])
            except Exception:
                translated = u''
            translated = re.sub(r'\s+', ' ', translated).strip(' -:|')
            if not translated or len(translated) < 3:
                translated = None
            if translated and translated.lower() == src.lower():
                translated = None
            _ALBANIAN_TRANSLATE_CACHE[key] = translated
            return translated
        except Exception:
            _ALBANIAN_TRANSLATE_CACHE[key] = None
            return None
    except Exception:
        return None


class furyPosterXDownloadThread(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        # Shared HTTP session (connection pooling) for faster background downloads
        self.http = requests.Session()
        try:
            retries = Retry(total=0, backoff_factor=0)
            adapter = HTTPAdapter(max_retries=retries, pool_connections=1, pool_maxsize=1)
            self.http.mount('http://', adapter)
            self.http.mount('https://', adapter)
        except Exception:
            pass
        self.adsl = intCheck_cached(timeout=1)
        if not self.adsl:
            print("Connessione assente, modalità offline.")
            return
        else:
            print("Connessione rilevata.")
        self.checkMovie = ["film", "movie", "фильм", "кино", "ταινία",
                           "película", "cinéma", "cine", "cinema",
                           "filma"]
        self.checkTV = ["serial", "series", "serie", "serien", "série",
                        "séries", "serious", "folge", "episodio",
                        "episode", "épisode", "l'épisode", "ep.",
                        "animation", "staffel", "soap", "doku", "tv",
                        "talk", "show", "news", "factual",
                        "entertainment", "telenovela", "dokumentation",
                        "dokutainment", "documentary", "informercial",
                        "information", "sitcom", "reality", "program",
                        "magazine", "mittagsmagazin", "т/с", "м/с",
                        "сезон", "с-н", "эпизод", "сериал", "серия",
                        "actualité", "discussion", "interview", "débat",
                        "émission", "divertissement", "jeu", "magasine",
                        "information", "météo", "journal", "sport",
                        "culture", "infos", "feuilleton", "téléréalité",
                        "société", "clips", "concert", "santé",
                        "éducation", "variété"]
        # self.sizeb = False

    def _extract_year(self, description):
        """Extract the first plausible production year from EPG text."""
        try:
            year_matches = re.findall(r"19\d{2}|20\d{2}", description or "")
            return year_matches[0] if year_matches else ""
        except Exception:
            return ""

    def _normalize_match_title(self, value):
        """Normalize Latin and Arabic titles for strict result ranking."""
        try:
            value = str(value or "").lower().strip()
            value = value.replace("&", " and ")
            value = re.sub(u'[\u064b-\u065f\u0670\u0640]', '', value)
            value = value.replace(u'أ', u'ا').replace(u'إ', u'ا').replace(u'آ', u'ا')
            value = value.replace(u'ى', u'ي').replace(u'ؤ', u'و').replace(u'ئ', u'ي')
            value = re.sub(r"[^a-z0-9\u0600-\u06FF]+", " ", value)
            value = re.sub(r"\s+", " ", value).strip()
            return value
        except Exception:
            return str(value or "").lower().strip()

    def _contains_arabic(self, value):
        try:
            return bool(re.search(u'[\u0600-\u06FF]', str(value or "")))
        except Exception:
            return False

    def _tmdb_language_candidates(self, title):
        """Prefer Arabic for Arabic titles, then safe fallbacks."""
        candidates = []
        def add(lang):
            if not lang:
                return
            lang = str(lang).strip()
            if lang and lang not in candidates:
                candidates.append(lang)
        if self._contains_arabic(title):
            add("ar")
            add("ar-SA")
            add("en-US")
            add("en")
        else:
            lang = (lng or "en").strip()
            lang_map = {
                "en": "en-US", "ar": "ar-SA", "fr": "fr-FR", "it": "it-IT",
                "de": "de-DE", "es": "es-ES", "pt": "pt-BR", "ru": "ru-RU",
                "tr": "tr-TR", "sq": "sq-AL",
            }
            add(lang_map.get(lang, lang))
            add(lang[:2])
            add("en-US")
            add("en")
            add("ar")
        return candidates

    def _select_best_tmdb_result(self, results, title_safe, shortdesc="", fulldesc="", year=None, image_key="poster_path"):
        """Score TMDB results instead of accepting the first item blindly."""
        target = self._normalize_match_title(title_safe)
        srch, _fd = self.checkType(shortdesc, fulldesc)
        def _tmdb_meaningful_tokens(value):
            try:
                n = self._normalize_match_title(value)
                stop = set([u'al', u'el', u'the', u'a', u'an', u'and', u'of', u'wa', u'wal', u'بن', u'ابن', u'ال', u'و', u'في', u'من', u'مع', u'يا'])
                return [w for w in n.split() if len(w) > 1 and w not in stop]
            except Exception:
                return []

        candidates = []
        for each in results or []:
            try:
                media_type = str(each.get('media_type') or '').lower()
                if media_type == 'tv':
                    media_type = 'serie'
                if not media_type:
                    media_type = 'serie' if srch in ('tv', 'serie') else 'movie'
                if media_type not in ('movie', 'serie'):
                    continue
                if not each.get(image_key):
                    continue

                title = each.get('name') or each.get('title') or ''
                original_title = each.get('original_name') or each.get('original_title') or ''
                if _fx_all_known_titles_clear_mismatch(title_safe, (title, original_title)):
                    continue
                arabic_known_titles = [t for t in (title, original_title) if t]
                if arabic_known_titles and all(_fx_is_clear_arabic_title_mismatch(title_safe, t) for t in arabic_known_titles):
                    continue
                title_n = self._normalize_match_title(title)
                orig_n = self._normalize_match_title(original_title)

                direct_match = False
                if target:
                    if title_n == target or orig_n == target:
                        direct_match = True
                    elif title_n and (target in title_n or title_n in target):
                        direct_match = True
                    elif orig_n and (target in orig_n or orig_n in target):
                        direct_match = True
                try:
                    target_tokens = set(_tmdb_meaningful_tokens(target))
                    result_tokens = set(_tmdb_meaningful_tokens(title_n) + _tmdb_meaningful_tokens(orig_n))
                    token_hit = bool(target_tokens and result_tokens and target_tokens.intersection(result_tokens))
                except Exception:
                    token_hit = False
                # Do not accept a TMDB result only because it has the same media type.
                # This prevents Arabic/Latin-transliterated EPG titles from receiving
                # unrelated posters like "Redirected" when the title text does not match.
                if target and not direct_match and not token_hit:
                    continue

                result_year = ''
                if media_type == 'movie':
                    result_year = (each.get('release_date') or '')[:4]
                else:
                    result_year = (each.get('first_air_date') or '')[:4]

                score = 0
                if title_n == target:
                    score += 500
                if orig_n == target:
                    score += 450
                if target and title_n and (target in title_n or title_n in target):
                    score += 130
                if target and orig_n and (target in orig_n or orig_n in target):
                    score += 110
                if self._contains_arabic(title_safe) and self._contains_arabic(title):
                    score += 90

                if srch == 'movie' and media_type == 'movie':
                    score += 200
                elif srch in ('tv', 'serie') and media_type == 'serie':
                    score += 200
                elif srch == 'multi':
                    score += 30 if media_type == 'movie' else 10

                if year:
                    if result_year:
                        if str(year) == str(result_year):
                            score += 600
                        elif media_type != 'serie':
                            score -= 500
                    elif media_type != 'serie':
                        score -= 120

                try:
                    score += min(float(each.get('popularity') or 0), 20)
                    score += min(float(each.get('vote_average') or 0), 10)
                except Exception:
                    pass

                candidates.append((each, score, result_year))
            except Exception:
                continue

        if not candidates:
            return None, -1
        if year:
            exact_year = [(item, score) for item, score, result_year in candidates if str(result_year) == str(year)]
            if exact_year:
                exact_year.sort(key=lambda x: x[1], reverse=True)
                return exact_year[0][0], exact_year[0][1]
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][0], candidates[0][1]
    def search_tmdb(self, dwn_poster, title, shortdesc, fulldesc, channel=None, year=None):
        """Search TMDB using cleaned titles, Arabic-aware language, year ranking and strict result scoring."""
        def _strip_year_for_search(value):
            value = str(value or "").strip()
            value = re.sub(r"\s*[\(\[]\s*(?:19|20)\d{2}\s*[\)\]]\s*", " ", value)
            value = re.sub(r"(?<!^)\s+(?:19|20)\d{2}\s*$", "", value)
            return re.sub(r"\s+", " ", value).strip()

        try:
            self.dwn_poster = dwn_poster
            if not dwn_poster or not title:
                return False, "[SKIP : tmdb] Invalid input"

            clean_input_title = (title or "").replace("+", " ").replace('–', '').strip()
            try:
                split_title, forced_year = split_title_and_year(clean_input_title)
            except Exception:
                split_title, forced_year = clean_input_title, ""
            local_title_safe = clean_search_title(_strip_year_for_search(split_title))
            if not local_title_safe:
                return False, "[SKIP : tmdb] Invalid title after cleaning"

            srch, fd = self.checkType(shortdesc, fulldesc)
            if not year:
                year = self._extract_year(fd)
            if forced_year and not year:
                year = forced_year
            rank_year = "" if srch in ("tv", "serie") else (year or "")

            search_types = [srch] if srch in ("movie", "tv") else ["multi", "movie", "tv"]
            lang_candidates = self._tmdb_language_candidates(local_title_safe)
            arabic_latin_aliases = []
            try:
                arabic_latin_aliases.extend(_arabic_latin_title_aliases(local_title_safe))
                for _a in _arabic_latin_title_aliases(clean_input_title):
                    if _a not in arabic_latin_aliases:
                        arabic_latin_aliases.append(_a)
            except Exception:
                arabic_latin_aliases = []
            if arabic_latin_aliases:
                query_candidates = []
                for _a in arabic_latin_aliases:
                    if _a.lower() not in [q.lower() for q in query_candidates]:
                        query_candidates.append(_a)
                # Arabic aliases must be searched in Arabic first.  Avoid putting
                # the noisy Latin transliteration first, because it can match a
                # different Arabic title with the same prefix.
                for _l in ("ar", "ar-SA", "en-US", "en"):
                    if _l not in lang_candidates:
                        lang_candidates.insert(0 if _l.startswith('ar') else len(lang_candidates), _l)
            else:
                query_candidates = [local_title_safe]
            for alias in _albanian_title_aliases(local_title_safe):
                if alias.lower() not in [q.lower() for q in query_candidates]:
                    query_candidates.append(alias)
            if (not arabic_latin_aliases) and clean_input_title and clean_input_title.lower() != local_title_safe.lower():
                query_candidates.append(clean_input_title)
            translated_al = None
            try:
                translated_al = _translate_albanian_query(local_title_safe, channel)
            except Exception:
                translated_al = None
            if translated_al and translated_al.lower() not in [q.lower() for q in query_candidates]:
                query_candidates.append(translated_al)

            headers = {'User-Agent': getRandomUserAgent()}
            http = getattr(self, 'http', None) or requests.Session()
            timeout_value = globals().get('POSTER_SEARCH_TIMEOUT', (8, 15))

            for query_try in query_candidates[:5]:
                self.title_safe = query_try
                for search_type in search_types:
                    for lang_try in lang_candidates[:4]:
                        params = {
                            "api_key": tmdb_api,
                            "query": query_try,
                            "language": lang_try,
                            "include_adult": "false",
                            "page": "1",
                        }
                        if year and search_type in ("movie", "multi"):
                            params["year"] = str(year)
                        url = "https://api.themoviedb.org/3/search/{}".format(search_type)
                        try:
                            response = http.get(url, params=params, headers=headers, timeout=timeout_value, verify=False)
                        except Exception:
                            response = requests.get(url, params=params, headers=headers, timeout=timeout_value, verify=False)
                        response.raise_for_status()
                        data = response.json()
                        if not data or not data.get('results'):
                            continue
                        ok, log = self.downloadData2(
                            data,
                            dwn_poster,
                            shortdesc,
                            fulldesc,
                            title_safe=query_try,
                            search_year=rank_year
                        )
                        if ok and os.path.exists(dwn_poster) and os.path.getsize(dwn_poster) > 0:
                            return True, log
            return False, "[SKIP : tmdb] Not found"
        except Exception as e:
            try:
                if dwn_poster and os.path.exists(dwn_poster):
                    os.remove(dwn_poster)
            except Exception:
                pass
            return False, "[ERROR : tmdb] {}".format(str(e))

    def downloadData2(self, data, dwn_poster=None, shortdesc="", fulldesc="", title_safe="", search_year=""):
        """Select the highest-scoring TMDB poster result and save it."""
        try:
            dwn_poster = dwn_poster or getattr(self, 'dwn_poster', None)
            if isinstance(data, bytes):
                data = data.decode('utf-8', 'ignore')
            data_json = data if isinstance(data, dict) else json.loads(data)
            results = data_json.get('results') or []
            if not results:
                return False, "[SKIP : tmdb] Empty results"

            best, best_score = self._select_best_tmdb_result(
                results,
                title_safe or getattr(self, 'title_safe', ''),
                shortdesc,
                fulldesc,
                search_year or self._extract_year(fulldesc or shortdesc or ""),
                image_key="poster_path"
            )
            if not best:
                return False, "[SKIP : tmdb] No valid result"

            poster_path = best.get('poster_path')
            if not poster_path:
                return False, "[SKIP : tmdb] No poster path"
            title = best.get('name') or best.get('title') or ''
            original_title = best.get('original_name') or best.get('original_title') or ''
            result_year = ((best.get('release_date') or best.get('first_air_date') or '')[:4])
            poster_url = "https://image.tmdb.org/t/p/{}{}".format(globals().get('TMDB_POSTER_SIZE', 'w185'), poster_path)
            self.savePoster(poster_url, dwn_poster)
            if dwn_poster and os.path.exists(dwn_poster) and os.path.getsize(dwn_poster) > 0:
                show_title = title or original_title
                if result_year:
                    show_title = "{} ({})".format(show_title, result_year)
                return True, "[SUCCESS poster: tmdb] {} score={} => {}".format(show_title, int(best_score), poster_url)
            return False, "[SKIP : tmdb] Download failed"
        except Exception as e:
            try:
                dwn_poster = dwn_poster or getattr(self, 'dwn_poster', None)
                if dwn_poster and os.path.exists(dwn_poster):
                    os.remove(dwn_poster)
            except Exception:
                pass
            return False, "[ERROR : tmdb] {}".format(str(e))

            # Keep the original title for query; TMDB handles UTF-8 queries.
            title_safe = title or ""
            self.title_safe = title_safe.replace('+', ' ')

            # Map 2-letter codes to IETF tags where TMDB expects e.g. 'en-US'
            lang = (lng or "en").strip()
            lang_map = {
                "en": "en-US",
                "ar": "ar-SA",
                "fr": "fr-FR",
                "it": "it-IT",
                "de": "de-DE",
                "es": "es-ES",
                "pt": "pt-BR",
                "ru": "ru-RU",
                "tr": "tr-TR",
                "sq": "sq-AL",
            }
            lang_tag = lang_map.get(lang, lang)

            # Try preferred language first, then fallback to en-US (often has better metadata coverage)
            lang_candidates = [lang_tag]
            if _is_albanian_channel(channel) or _looks_albanian_text(self.title_safe):
                for _l in ("sq-AL", "sq"):
                    if _l not in lang_candidates:
                        lang_candidates.append(_l)
            if lang_tag != "en-US":
                lang_candidates.append("en-US")

            query_candidates = [self.title_safe]
            translated_al = _translate_albanian_query(self.title_safe, channel)
            if translated_al and translated_al.lower() != self.title_safe.lower():
                query_candidates.append(translated_al)

            headers = {'User-Agent': getRandomUserAgent()}
            for query_try in query_candidates:
                self.title_safe = query_try
                for lang_try in lang_candidates:
                    params = {
                        "api_key": tmdb_api,
                        "query": query_try,
                        "language": lang_try,
                        "include_adult": "false",
                        "page": "1",
                    }
                    url = "https://api.themoviedb.org/3/search/multi"

                    try:
                        response = self.http.get(url, params=params, headers=headers, timeout=POSTER_SEARCH_TIMEOUT, verify=False)
                    except Exception:
                        response = requests.get(url, params=params, headers=headers, timeout=POSTER_SEARCH_TIMEOUT, verify=False)

                    response.raise_for_status()
                    try:
                        data = response.json()
                    except ValueError:
                        data = None

                    if not data:
                        continue

                    res = self.downloadData2(data)
                    if not res:
                        continue
                    ok, log = res
                    if ok and os.path.exists(self.dwn_poster):
                        return True, log

            return False, "[SKIP : tmdb] Not found"
        except Exception as e:
            try:
                if self.dwn_poster and os.path.exists(self.dwn_poster):
                    os.remove(self.dwn_poster)
            except Exception:
                pass
            return False, "[ERROR : tmdb] {}".format(str(e))


            data_json = data if isinstance(data, dict) else json.loads(data)

            results = data_json.get('results') or []
            if not isinstance(results, list) or not results:
                return False, "[SKIP : tmdb] Empty results"

            for each in results:
                try:
                    media_type = str(each.get('media_type') or '')
                    if media_type == "tv":
                        media_type = "serie"

                    if media_type not in ("movie", "serie"):
                        continue

                    poster_path = each.get('poster_path')
                    if not poster_path:
                        continue

                    # Title/year are only for logging
                    year = ""
                    if media_type == "movie":
                        rd = each.get('release_date') or ""
                        if rd:
                            year = rd.split("-")[0]
                    else:
                        fad = each.get('first_air_date') or ""
                        if fad:
                            year = fad.split("-")[0]

                    title = each.get('name') or each.get('title') or ''
                    rating = str(each.get('vote_average', 0))

                    poster_url = "https://image.tmdb.org/t/p/{}{}".format(TMDB_POSTER_SIZE, poster_path)

                    # Save and only report success if the file exists and is non-empty
                    self.savePoster(poster_url, self.dwn_poster)
                    if os.path.exists(self.dwn_poster) and os.path.getsize(self.dwn_poster) > 0:
                        show_title = title
                        if year:
                            show_title = "{} ({})".format(title, year)
                        return True, "[SUCCESS poster: tmdb] {} => year{} => rating{} => {}".format(title, year, rating, show_title)

                except Exception:
                    # Keep scanning other candidates
                    continue

            return False, "[SKIP : tmdb] Not found"
        except Exception as e:
            try:
                if self.dwn_poster and os.path.exists(self.dwn_poster):
                    os.remove(self.dwn_poster)
            except Exception:
                pass
            return False, "[ERROR : tmdb] {}".format(str(e))



    def search_tvdb(self, dwn_poster, title, shortdesc, fulldesc, channel=None):
        try:
            self.dwn_poster = dwn_poster
            series_nb = -1
            chkType, fd = self.checkType(shortdesc, fulldesc)
            title_safe = title
            # title_safe = self.UNAC(title)
            # title_safe = quoteEventName(title_safe)
            self.title_safe = title_safe.replace('+', ' ')
            # Sanitize the filename before saving
            # self.title_safe = sanitize_filename(self.title_safe)
            year = re.findall(r'19\d{2}|20\d{2}', fd)
            if len(year) > 0:
                year = year[0]
            else:
                year = ''
            url_tvdbg = "https://thetvdb.com/api/GetSeries.php?seriesname={}".format(self.title_safe)
            url_read = requests.get(url_tvdbg, timeout=6).text
            series_id = re.findall(r'<seriesid>(.*?)</seriesid>', url_read)
            series_name = re.findall(r'<SeriesName>(.*?)</SeriesName>', url_read)
            series_year = re.findall(r'<FirstAired>(19\d{2}|20\d{2})-\d{2}-\d{2}</FirstAired>', url_read)
            '''
            # series_banners = re.findall(r'<banner>(.*?)</banner>', url_read)
            # if series_banners:
                # series_banners = 'https://thetvdb.com' + series_banners
            '''
            i = 0
            for iseries_year in series_year:
                if year == '':
                    series_nb = 0
                    break
                elif year == iseries_year:
                    series_nb = i
                    break
                i += 1
            poster = None
            # backdrop = None
            if series_nb >= 0 and series_id and series_id[series_nb]:
                if series_name and series_name[series_nb]:
                    series_name = self.UNAC(series_name[series_nb])
                else:
                    series_name = ''
                if self.PMATCH(self.title_safe, series_name):
                    url_tvdb = "https://thetvdb.com/api/{}/series/{}".format(thetvdbkey, series_id[series_nb])
                    if lng:
                        url_tvdb += "/{}".format(lng)
                    else:
                        url_tvdb += "/en"
                    url_read = requests.get(url_tvdb, timeout=6).text
                    poster = re.findall(r'<poster>(.*?)</poster>', url_read)
                    url_poster = "https://artworks.thetvdb.com/banners/{}".format(poster[0])
                    # backdrop = re.findall(r'<backdrop>(.*?)</backdrop>', url_read)
                    # url_backdrop = "https://artworks.thetvdb.com/banners/{}".format(backdrop[0])
                    if poster is not None and poster[0]:
                        self.savePoster(url_poster, self.dwn_poster)
                        # # self.savePoster(dwn_poster, url_poster)
                        # if self.verifyPoster(dwn_poster):
                            # self.resizePoster(dwn_poster)

                        # if backdrop and backdrop[0]:
                            # self.pstrNm = path_folder + '/' + self.title_safe + ".jpg"
                            # dwn_poster = str(self.pstrNm)
                            # callInThread(self.savePoster, url_backdrop, dwn_poster)
                            # # # self.savePoster(dwn_poster, url_backdrop)
                        # if os.path.exists(self.pstrNm):
                            # if self.verifyPoster(self.pstrNm):
                                # self.sizeb = True
                                # self.resizePoster(self.pstrNm)
                        return True, "[SUCCESS : tvdb] {} [{}-{}] => {} => {} => {}".format(self.title_safe, chkType, year, url_tvdbg, url_tvdb, url_poster)
            else:
                return False, "[SKIP : tvdb] {} [{}-{}] => {} (Not found)".format(self.title_safe, chkType, year, url_tvdbg)

        except Exception as e:
            if os.path.exists(dwn_poster):
                os.remove(dwn_poster)
            return False, "[ERROR : tvdb] {} => {} ({})".format(title, url_tvdbg, str(e))

    def search_fanart(self, dwn_poster, title, shortdesc, fulldesc, channel=None):
        try:
            self.dwn_poster = dwn_poster
            year = None
            url_maze = ""
            url_fanart = ""
            url_poster = None
            # url_backdrop = None
            # self.sizeb = False
            id = "-"
            title_safe = title
            # title_safe = self.UNAC(title)
            # title_safe = quoteEventName(title_safe)
            self.title_safe = title_safe.replace('+', ' ')
            # Sanitize the filename before saving
            # self.title_safe = sanitize_filename(self.title_safe)
            chkType, fd = self.checkType(shortdesc, fulldesc)
            try:
                if re.findall(r'19\d{2}|20\d{2}', self.title_safe):
                    year = re.findall(r'19\d{2}|20\d{2}', fd)[1]
                else:
                    year = re.findall(r'19\d{2}|20\d{2}', fd)[0]
            except:
                year = ''
                pass

            try:
                url_maze = "http://api.tvmaze.com/singlesearch/shows?q={}".format(self.title_safe)
                mj = requests.get(url_maze).json()
                id = (mj['externals']['thetvdb'])
            except Exception as err:
                print('Error:', err)

            try:
                m_type = 'tv'
                url_fanart = "https://webservice.fanart.tv/v3/{}/{}?api_key={}".format(m_type, id, fanart_api)
                fjs = requests.get(url_fanart, verify=False, timeout=5).json()
                try:
                    url = (fjs['tvposter'][0]['url'])
                except:
                    url = (fjs['movieposter'][0]['url'])

                # try:
                    # url2 = (fjs['showbackground'][0]['url'])
                # except:
                    # url2 = (fjs['moviebackground'][0]['url'])

                url_poster = url
                # print('url fanart poster:', url_poster)
                if url_poster and url_poster != 'null' or url_poster is not None or url_poster != '':
                    self.savePoster(url_poster, self.dwn_poster)
                    # # self.savePoster(dwn_poster, url_poster)
                    # if self.verifyPoster(self.dwn_poster):
                        # self.resizePoster(self.dwn_poster)

                    # url_backdrop = requests.get(url2).json()
                    # # print('url fanart url_poster:', url_poster)
                    # if url_backdrop and url_backdrop != 'null' or url_backdrop is not None or url_backdrop != '':
                        # self.pstrNm = path_folder + '/' + self.title_safe + ".jpg"
                        # dwn_poster = str(self.pstrNm)
                        # callInThread(self.savePoster, url_backdrop, dwn_poster)
                        # # self.savePoster(dwn_poster, url_poster)
                    # if os.path.exists(self.pstrNm):
                        # if self.verifyPoster(self.pstrNm):
                            # self.sizeb = True
                            # self.resizePoster(self.pstrNm)
                    return True, "[SUCCESS poster: fanart] {} [{}-{}] => {} => {} => {}".format(self.title_safe, chkType, year, url_maze, url_fanart, url_poster)
                return False, "[SKIP : fanart] {} [{}-{}] => {} (Not found)".format(self.title_safe, chkType, year, url_fanart)
            except Exception as e:
                print(e)

        except Exception as e:
            if os.path.exists(dwn_poster):
                os.remove(dwn_poster)
            return False, "[ERROR : fanart] {} [{}-{}] => {} ({})".format(self.title_safe, chkType, year, url_fanart, str(e))

    def search_imdb(self, dwn_poster, title, shortdesc, fulldesc, channel=None):
        try:
            self.dwn_poster = dwn_poster
            url_poster = None
            chkType, fd = self.checkType(shortdesc, fulldesc)
            title_safe = title
            # title_safe = self.UNAC(title)
            # title_safe = quoteEventName(title_safe)
            self.title_safe = title_safe.replace('+', ' ')
            # Sanitize the filename before saving
            # self.title_safe = sanitize_filename(self.title_safe)
            aka = re.findall(r'\((.*?)\)', fd)
            if len(aka) > 1 and not aka[1].isdigit():
                aka = aka[1]
            elif len(aka) > 0 and not aka[0].isdigit():
                aka = aka[0]
            else:
                aka = None
            if aka:
                paka = self.UNAC(aka)
            else:
                paka = ''
            year = re.findall(r'19\d{2}|20\d{2}', fd)
            if len(year) > 0:
                year = year[0]
            else:
                year = ''
            imsg = ''
            url_mimdb = ''
            url_imdb = ''

            if aka and aka != self.title_safe:
                url_mimdb = "https://m.imdb.com/find?q={}%20({})".format(self.title_safe, quoteEventName(aka))
            else:
                url_mimdb = "https://m.imdb.com/find?q={}".format(self.title_safe)
            url_read = requests.get(url_mimdb, timeout=8).text
            rc = re.compile(r'<img src="(.*?)".*?<span class="h3">\n(.*?)\n</span>.*?\((\d+)\)(\s\(.*?\))?(.*?)</a>', re.DOTALL)
            url_imdb = rc.findall(url_read)

            if len(url_imdb) == 0 and aka:
                url_mimdb = "https://m.imdb.com/find?q={}".format(self.title_safe)
                url_read = requests.get(url_mimdb, timeout=8).text
                rc = re.compile(r'<img src="(.*?)".*?<span class="h3">\n(.*?)\n</span>.*?\((\d+)\)(\s\(.*?\))?(.*?)</a>', re.DOTALL)
                url_imdb = rc.findall(url_read)
            len_imdb = len(url_imdb)
            idx_imdb = 0
            pfound = False

            for imdb in url_imdb:
                imdb = list(imdb)
                imdb[1] = self.UNAC(imdb[1])
                tmp = re.findall(r'aka <i>"(.*?)"</i>', imdb[4])
                if tmp:
                    imdb[4] = tmp[0]
                else:
                    imdb[4] = ''
                imdb[4] = self.UNAC(imdb[4])
                imdb_poster = re.search(r"(.*?)._V1_.*?.jpg", imdb[0])
                if imdb_poster:
                    if imdb[3] == '':
                        if year and year != '':
                            if year == imdb[2]:
                                url_poster = "{}._V1_UY278,1,185,278_AL_.jpg".format(imdb_poster.group(1))
                                imsg = "Found title : '{}', aka : '{}', year : '{}'".format(imdb[1], imdb[4], imdb[2])
                                if self.PMATCH(self.title_safe, imdb[1]) or self.PMATCH(self.title_safe, imdb[4]) or (paka != '' and self.PMATCH(paka, imdb[1])) or (paka != '' and self.PMATCH(paka, imdb[4])):
                                    pfound = True
                                    break
                            elif not url_poster and (int(year) - 1 == int(imdb[2]) or int(year) + 1 == int(imdb[2])):
                                url_poster = "{}._V1_UY278,1,185,278_AL_.jpg".format(imdb_poster.group(1))
                                imsg = "Found title : '{}', aka : '{}', year : '+/-{}'".format(imdb[1], imdb[4], imdb[2])
                                if self.title_safe == imdb[1] or self.title_safe == imdb[4] or (paka != '' and paka == imdb[1]) or (paka != '' and paka == imdb[4]):
                                    pfound = True
                                    break
                        else:
                            url_poster = "{}._V1_UY278,1,185,278_AL_.jpg".format(imdb_poster.group(1))
                            imsg = "Found title : '{}', aka : '{}', year : ''".format(imdb[1], imdb[4])
                            if self.title_safe == imdb[1] or self.title_safe == imdb[4] or (paka != '' and paka == imdb[1]) or (paka != '' and paka == imdb[4]):
                                pfound = True
                                break
                idx_imdb += 1
            # self.sizeb = False
            if url_poster and pfound:
                self.savePoster(url_poster, dwn_poster)
                if os.path.exists(dwn_poster):
                    # # self.savePoster(dwn_poster, url_poster)
                    # if self.verifyPoster(dwn_poster):
                        # self.resizePoster(dwn_poster)

                    # # backdrop
                    # self.pstrNm = path_folder + '/' + self.title_safe + ".jpg"
                    # # dwn_poster = str(self.pstrNm)
                    # callInThread(self.savePoster, url_poster, self.pstrNm)
                    # if os.path.exists(self.pstrNm):
                        # # self.savePoster(dwn_poster, url_backdrop)
                        # if self.verifyPoster(self.pstrNm):
                            # self.sizeb = True
                            # self.resizePoster(self.pstrNm)
                    return True, "[SUCCESS url_poster: imdb] {} [{}-{}] => {} [{}/{}] => {} => {}".format(self.title_safe, chkType, year, imsg, idx_imdb, len_imdb, url_mimdb, url_poster)
            return False, "[SKIP : imdb] {} [{}-{}] => {} (No Entry found [{}])".format(self.title_safe, chkType, year, url_mimdb, len_imdb)

        except Exception as e:
            if os.path.exists(dwn_poster):
                os.remove(dwn_poster)
            return False, "[ERROR : imdb] {} [{}-{}] => {} ({})".format(self.title_safe, chkType, year, url_mimdb, str(e))

    def search_programmetv_google(self, dwn_poster, title, shortdesc, fulldesc, channel=None):
        try:
            self.dwn_poster = dwn_poster
            url_ptv = ''
            headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36"}
            chkType, fd = self.checkType(shortdesc, fulldesc)
            if chkType.startswith("movie"):
                return False, "[SKIP : programmetv-google] {} [{}] => Skip movie title".format(title, chkType)
            title_safe = title
            # title_safe = self.UNAC(title)
            # title_safe = quoteEventName(title_safe)
            self.title_safe = title_safe.replace('+', ' ')
            # Sanitize the filename before saving
            # self.title_safe = sanitize_filename(self.title_safe)
            url_ptv = "site:programme-tv.net+" + self.title_safe
            if channel and self.title_safe.find(channel.split()[0]) < 0:
                url_ptv += "+" + quoteEventName(channel)
            url_ptv = "https://www.google.com/search?q={}&tbm=isch&tbs=ift:jpg%2Cisz:m".format(url_ptv)
            ff = requests.get(url_ptv, stream=True, headers=headers, cookies={'CONSENT': 'YES+'}, timeout=8).text
            if not PY3:
                ff = ff.encode('utf-8')
            ptv_id = 0
            plst = re.findall(r'\],\["https://www.programme-tv.net(.*?)",\d+,\d+]', ff)
            for posterlst in plst:
                # self.sizeb = False
                ptv_id += 1
                url_poster = "https://www.programme-tv.net{}".format(posterlst)
                url_poster = re.sub(r"\\u003d", "=", url_poster)
                url_poster_size = re.findall(r'([\d]+)x([\d]+).*?([\w\.-]+).jpg', url_poster)
                if url_poster_size and url_poster_size[0]:
                    get_title = self.UNAC(url_poster_size[0][2].replace('-', ''))
                    if self.title_safe == get_title:
                        h_ori = float(url_poster_size[0][1])
                        h_tar = float(re.findall(r'(\d+)', isz)[1])
                        ratio = h_ori / h_tar
                        w_ori = float(url_poster_size[0][0])
                        w_tar = w_ori / ratio
                        w_tar = int(w_tar)
                        h_tar = int(h_tar)
                        url_poster = re.sub(r'/\d+x\d+/', "/" + str(w_tar) + "x" + str(h_tar) + "/", url_poster)
                        url_poster = re.sub(r'crop-from/top/', '', url_poster)
                        self.savePoster(url_poster, self.dwn_poster)
                        # self.savePoster(dwn_poster, url_poster)
                        if os.path.exists(dwn_poster):
                            # if self.verifyPoster(dwn_poster):
                                # self.resizePoster(dwn_poster)
                            # # backdrop
                            # self.pstrNm = path_folder + '/' + self.title_safe + ".jpg"
                            # dwn_poster = str(self.pstrNm)
                            # self.savePoster(url_poster, dwn_poster)
                            # # self.savePoster(dwn_poster, url_poster)
                            # if os.path.exists(dwn_poster):
                                # if self.verifyPoster(dwn_poster):
                                    # self.sizeb = True
                                    # self.resizePoster(dwn_poster)
                            return True, "[SUCCESS url_poster: programmetv-google] {} [{}] => Found self.title_safe : '{}' => {} => {} (initial size: {}) [{}]".format(self.title_safe, chkType, get_title, url_ptv, url_poster, url_poster_size, ptv_id)
                return False, "[SKIP : programmetv-google] {} [{}] => Not found [{}] => {}".format(self.title_safe, chkType, ptv_id, url_ptv)

        except Exception as e:
            if os.path.exists(dwn_poster):
                os.remove(dwn_poster)
            return False, "[ERROR : programmetv-google] {} [{}] => {} ({})".format(self.title_safe, chkType, url_ptv, str(e))

    def search_molotov_google(self, dwn_poster, title, shortdesc, fulldesc, channel=None):
        try:
            self.dwn_poster = dwn_poster
            url_mgoo = ''
            headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36"}
            chkType, fd = self.checkType(shortdesc, fulldesc)
            title_safe = title
            # title_safe = self.UNAC(title)
            # title_safe = quoteEventName(title_safe)
            self.title_safe = title_safe.replace('+', ' ')
            # Sanitize the filename before saving
            # self.title_safe = sanitize_filename(self.title_safe)
            if channel:
                pchannel = self.UNAC(channel).replace(' ', '')
            else:
                pchannel = ''
            poster = None
            pltc = None
            imsg = ''
            url_mgoo = "site:molotov.tv+" + self.title_safe
            if channel and self.title_safe.find(channel.split()[0]) < 0:
                url_mgoo += "+" + quoteEventName(channel)
            url_mgoo = "https://www.google.com/search?q={}&tbm=isch".format(url_mgoo)
            ff = requests.get(url_mgoo, stream=True, headers=headers, cookies={'CONSENT': 'YES+'}, timeout=8).text
            if not PY3:
                ff = ff.encode('utf-8')
            plst = re.findall(r'https://www.molotov.tv/(.*?)"(?:.*?)?"(.*?)"', ff)
            len_plst = len(plst)
            molotov_id = 0
            molotov_table = [0, 0, None, None, 0]
            partialtitle = 0
            partialchannel = 0
            for pl in plst:
                get_path = "https://www.molotov.tv/" + pl[0]
                get_name = self.UNAC(pl[1])
                get_title = re.findall(r'(.*?)[ ]+en[ ]+streaming', get_name)
                if get_title:
                    get_title = get_title[0]
                else:
                    get_title = None
                get_channel = re.findall(r'(?:streaming|replay)?[ ]+sur[ ]+(.*?)[ ]+molotov.tv', get_name)
                if get_channel:
                    get_channel = self.UNAC(get_channel[0]).replace(' ', '')
                else:
                    get_channel = re.findall(r'regarder[ ]+(.*?)[ ]+en', get_name)
                    if get_channel:
                        get_channel = self.UNAC(get_channel[0]).replace(' ', '')
                    else:
                        get_channel = None
                partialchannel = self.PMATCH(pchannel, get_channel)
                partialtitle = self.PMATCH(self.title_safe, get_title)
                if partialtitle > molotov_table[0]:
                    molotov_table = [partialtitle, partialchannel, get_name, get_path, molotov_id]
                if partialtitle == 100 and partialchannel == 100:
                    break
                molotov_id += 1

            if molotov_table[0]:
                ffm = requests.get(molotov_table[3], stream=True, headers=headers, timeout=8).text
                if not PY3:
                    ffm = ffm.encode('utf-8')
                pltt = re.findall(r'"https://fusion.molotov.tv/(.*?)/jpg" alt="(.*?)"', ffm)
                if len(pltt) > 0:
                    pltc = self.UNAC(pltt[0][1])
                    plst = "https://fusion.molotov.tv/" + pltt[0][0] + "/jpg"
                    imsg = "Found title ({}%) & channel ({}%) : '{}' + '{}' [{}/{}]".format(molotov_table[0], molotov_table[1], molotov_table[2], pltc, molotov_table[4], len_plst)
            else:
                plst = re.findall(r'\],\["https://(.*?)",\d+,\d+].*?"https://.*?","(.*?)"', ff)
                len_plst = len(plst)
                if len_plst > 0:
                    for pl in plst:
                        if pl[1].startswith("Regarder"):
                            pltc = self.UNAC(pl[1])
                            partialtitle = self.PMATCH(self.title_safe, pltc)
                            get_channel = re.findall(r'regarder[ ]+(.*?)[ ]+en', pltc)
                            if get_channel:
                                get_channel = self.UNAC(get_channel[0]).replace(' ', '')
                            else:
                                get_channel = None
                            partialchannel = self.PMATCH(pchannel, get_channel)
                            if partialchannel > 0 and partialtitle < 50:
                                partialtitle = 50
                            plst = "https://" + pl[0]
                            molotov_table = [partialtitle, partialchannel, pltc, plst, -1]
                            imsg = "Fallback title ({}%) & channel ({}%) : '{}' [{}/{}]".format(molotov_table[0], molotov_table[1], pltc, -1, len_plst)
                            break

            if molotov_table[0] == 100 and molotov_table[1] == 100:
                poster = plst
            elif chkType.startswith("movie"):
                imsg = "Skip movie type '{}' [{}%-{}%-{}]".format(pltc, molotov_table[0], molotov_table[1], len_plst)
            elif molotov_table[0] == 100:
                poster = plst
            elif molotov_table[0] >= 50 and molotov_table[1]:
                poster = plst
            elif molotov_table[0] >= 75:
                poster = plst
            elif chkType == '':
                imsg = "Skip unknown type '{}' [{}%-{}%-{}]".format(pltc, molotov_table[0], molotov_table[1], len_plst)
            elif molotov_table[0] >= 25 and molotov_table[1]:
                poster = plst
            elif molotov_table[0] >= 50:
                poster = plst
            else:
                imsg = "Not found '{}' [{}%-{}%-{}]".format(pltc, molotov_table[0], molotov_table[1], len_plst)
            if poster:
                # self.sizeb = False
                url_poster = re.sub(r'/\d+x\d+/', "/" + re.sub(r', ', 'x', isz) + "/", poster)
                self.savePoster(poster, dwn_poster)
                # self.savePoster(dwn_poster, url_poster)
                if os.path.exists(dwn_poster):
                    # if self.verifyPoster(dwn_poster):
                        # self.resizePoster(dwn_poster)
                    # # backdrop
                    # self.pstrNm = path_folder + '/' + self.title_safe + ".jpg"
                    # dwn_poster = str(self.pstrNm)
                    # url_poster = re.sub(r'/\d+x\d+/', "/" + re.sub(r', ', 'x', bisz) + "/", poster)
                    # self.savePoster(poster, dwn_poster)
                    # # self.savePoster(dwn_poster, url_poster)
                    # if os.path.exists(dwn_poster):
                        # if self.verifyPoster(dwn_poster):
                            # self.sizeb = True
                            # self.resizePoster(dwn_poster)
                    return True, "[SUCCESS url_poster: molotov-google] {} ({}) [{}] => {} => {} => {}".format(self.title_safe, channel, chkType, imsg, url_mgoo, url_poster)
                return False, "[SKIP : molotov-google] {} ({}) [{}] => {} => {} => {} (jpeg error)".format(self.title_safe, channel, chkType, imsg, url_mgoo, url_poster)
        except Exception as e:
            if os.path.exists(dwn_poster):
                os.remove(dwn_poster)
            return False, "[ERROR : molotov-google] {} [{}] => {} ({})".format(self.title_safe, chkType, url_mgoo, str(e))

    def search_google(self, dwn_poster, title, shortdesc, fulldesc, channel=None):
        try:
            self.dwn_poster = dwn_poster
            headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36"}
            chkType, fd = self.checkType(shortdesc, fulldesc)
            poster = None
            url_poster = ''
            year = None
            srch = None
            title_safe = title
            # title_safe = self.UNAC(title)
            # title_safe = quoteEventName(title_safe)
            self.title_safe = title_safe.replace('+', ' ')
            # Sanitize the filename before saving
            # self.title_safe = sanitize_filename(self.title_safe)
            year = re.findall(r'19\d{2}|20\d{2}', fd)
            if len(year) > 0:
                year = year[0]
            else:
                year = None
            if chkType.startswith("movie"):
                srch = chkType[6:]
            elif chkType.startswith("tv"):
                srch = chkType[3:]
            url_google = '"' + self.title_safe + '"'
            if channel and self.title_safe.find(channel) < 0:
                url_google += "+{}".format(quoteEventName(channel))
            if srch:
                url_google += "+{}".format(srch)
            if year:
                url_google += "+{}".format(year)
            url_google = "https://www.google.com/search?q={}&tbm=isch&tbs=sbd:0".format(url_google)
            ff = requests.get(url_google, stream=True, headers=headers, cookies={'CONSENT': 'YES+'}, timeout=8).text

            posterlst = re.findall(r'\],\["https://(.*?)",\d+,\d+]', ff)
            if len(posterlst) == 0:
                url_google = self.title_safe
                url_google = "https://www.google.com/search?q={}&tbm=isch&tbs=ift:jpg%2Cisz:m".format(url_google)
                ff = requests.get(url_google, stream=True, headers=headers, timeout=8).text
                posterlst = re.findall(r'\],\["https://(.*?)",\d+,\d+]', ff)

            for pl in posterlst:
                # self.sizeb = False
                url_poster = "https://{}".format(pl)
                url_poster = re.sub(r"\\u003d", " = ", url_poster)
                self.savePoster(url_poster, dwn_poster)
                # self.savePoster(dwn_poster, url_poster)
                if os.path.exists(dwn_poster):
                    # if self.verifyPoster(dwn_poster):
                        # self.resizePoster(dwn_poster)
                    poster = pl
                    break
                # # backdrop
                # self.pstrNm = path_folder + '/' + self.title_safe + ".jpg"
                # # url_backdrop = str(self.pstrNm)
                # url_backdrop = re.sub(r'/\d+x\d+/', "/" + re.sub(r', ', 'x', bisz) + "/", poster)
                # callInThread(self.savePoster, url_backdrop, self.pstrNm)
                # # self.savePoster(dwn_poster, url_poster)
                # # if os.path.exists(self.pstrNm):
                # if self.verifyPoster(self.pstrNm):
                    # self.sizeb = True
                    # self.resizePoster(self.pstrNm)
            if poster is not None:
                return True, "[SUCCESS poster: google] {} [{}-{}] => {} => {}".format(self.title_safe, chkType, year, url_google, url_poster)
            return False, "[SKIP : google] {} [{}-{}] => {} => {} (Not found)".format(self.title_safe, chkType, year, url_google, url_poster)
        except Exception as e:
            if os.path.exists(dwn_poster):
                os.remove(dwn_poster)
            return False, "[ERROR : google] {} [{}-{}] => {} => {} ({})".format(self.title_safe, chkType, year, url_google, url_poster, str(e))


    def _elcinema_tvguide_entries(self):
        """Return cached [(title, work_id)] entries from ElCinema TV guide.

        The site changes the order of href/title attributes from time to time,
        so the parser accepts both attribute orders and also reads the anchor
        text when no title attribute is present.
        """
        global _ELCINEMA_CACHE_TS, _ELCINEMA_CACHE_ENTRIES
        try:
            now = time.time()
            if _ELCINEMA_CACHE_ENTRIES and (now - _ELCINEMA_CACHE_TS) < ELCINEMA_CACHE_TTL:
                return _ELCINEMA_CACHE_ENTRIES
            headers = {"User-Agent": getRandomUserAgent(), "Accept-Language": "ar,en;q=0.8"}
            http = getattr(self, 'http', None) or requests.Session()
            try:
                response = http.get(ELCINEMA_TVGUIDE_URL, headers=headers, timeout=(2, 6), verify=False)
            except Exception:
                response = requests.get(ELCINEMA_TVGUIDE_URL, headers=headers, timeout=(2, 6), verify=False)
            if getattr(response, 'status_code', 0) != 200:
                return _ELCINEMA_CACHE_ENTRIES or []
            html_text = _fx_html_unescape(response.text)
            entries = []
            seen = set()

            def add(found_title, work_id):
                try:
                    found_title = _fx_strip_tags(found_title).strip()
                    work_id = str(work_id or '').strip()
                    if not found_title or not work_id:
                        return
                    # Drop generic labels that are not real work titles.
                    if _fx_norm_title(found_title) in ('movie', 'series', 'program', 'favourite'):
                        return
                    key = (found_title.lower(), work_id)
                    if key in seen:
                        return
                    seen.add(key)
                    entries.append((found_title, work_id))
                except Exception:
                    pass

            # Full anchor parser: <a ... href="/en/work/123/" ...>Title</a>
            for tag, work_id, body in re.findall(r'(<a\b[^>]*\bhref=["\'](?:https?://elcinema\.com)?/(?:en/)?work/(\d+)/?["\'][^>]*>)(.*?)</a>', html_text, flags=re.I | re.S):
                found_title = _fx_attr(tag, 'title') or _fx_attr(tag, 'data-title') or body
                add(found_title, work_id)

            # Attribute-order fallbacks.
            for found_title, work_id in re.findall(r'title=["\']([^"\']+)["\'][^>]+href=["\'](?:https?://elcinema\.com)?/(?:en/)?work/(\d+)/?["\']', html_text, flags=re.I | re.S):
                add(found_title, work_id)
            for work_id, found_title in re.findall(r'href=["\'](?:https?://elcinema\.com)?/(?:en/)?work/(\d+)/?["\'][^>]+title=["\']([^"\']+)["\']', html_text, flags=re.I | re.S):
                add(found_title, work_id)

            if entries:
                _ELCINEMA_CACHE_ENTRIES = entries
                _ELCINEMA_CACHE_TS = now
            return _ELCINEMA_CACHE_ENTRIES or []
        except Exception:
            return _ELCINEMA_CACHE_ENTRIES or []

    def _elcinema_best_tvguide_match(self, title, min_score=68):
        """Find the closest ElCinema TV-guide work for an event title."""
        try:
            query = _fx_norm_title(title)
            if not query:
                return None
            q_tokens = set([x for x in query.split() if len(x) > 1])
            best = None
            best_score = 0
            for found_title, work_id in self._elcinema_tvguide_entries():
                found_norm = _fx_norm_title(found_title)
                if not found_norm:
                    continue
                if _fx_is_clear_title_mismatch(title, found_title):
                    continue
                if query == found_norm:
                    score = 100
                else:
                    score = int(SequenceMatcher(None, query, found_norm).ratio() * 100)
                    if len(query) >= 4 and len(found_norm) >= 4 and (query in found_norm or found_norm in query):
                        score = max(score, 88)
                    try:
                        f_tokens = set([x for x in found_norm.split() if len(x) > 1])
                        if q_tokens and f_tokens:
                            overlap = len(q_tokens.intersection(f_tokens)) * 100 // max(len(q_tokens), len(f_tokens))
                            score = max(score, overlap)
                            if overlap >= 50:
                                score += 12
                    except Exception:
                        pass
                if score > best_score:
                    best_score = score
                    best = (found_title, work_id, score)
            if best and best_score >= min_score:
                return best
            return None
        except Exception:
            return None

    def _elcinema_save_work_poster(self, dwn_poster, work_id, label_title, score):
        """Open an ElCinema work page and save the first credible poster image."""
        try:
            url_work = "https://elcinema.com/en/work/{}/".format(work_id)
            headers = {"User-Agent": getRandomUserAgent(), "Accept-Language": "ar,en;q=0.8"}
            http = getattr(self, 'http', None) or requests.Session()
            try:
                response = http.get(url_work, headers=headers, timeout=(2, 5), stream=True, allow_redirects=True, verify=False)
            except Exception:
                response = requests.get(url_work, headers=headers, timeout=(2, 5), stream=True, allow_redirects=True, verify=False)
            if getattr(response, 'status_code', 0) != 200:
                return False, "[SKIP : elcinema] Work page failed"
            page = _fx_html_unescape(response.text)
            image_url = None
            patterns = [
                r'<meta\s+property=["\']og:image["\']\s+content=["\']([^"\']+?\.(?:jpg|jpeg|png))',
                r'<meta\s+content=["\']([^"\']+?\.(?:jpg|jpeg|png))["\']\s+property=["\']og:image["\']',
                r'<img[^>]+(?:class|id)=["\'][^"\']*(?:poster|cover|work|photo)[^"\']*["\'][^>]+(?:src|data-src)=["\']([^"\']+?\.(?:jpg|jpeg|png))',
                r'<img[^>]+(?:src|data-src)=["\']([^"\']+?_315x420_[^"\']+?\.(?:jpg|jpeg|png))',
                r'<img[^>]+(?:src|data-src)=["\']([^"\']+?/uploads/_[^"\']+?\.(?:jpg|jpeg|png))',
                r'<img[^>]+(?:src|data-src)=["\']([^"\']+?\.(?:jpg|jpeg|png))',
            ]
            for pattern in patterns:
                match = re.search(pattern, page, flags=re.I | re.S)
                if match:
                    image_url = match.group(1).strip()
                    break
            if not image_url:
                return False, "[SKIP : elcinema] No poster on work page"
            if image_url.startswith('//'):
                image_url = 'https:' + image_url
            elif image_url.startswith('/'):
                image_url = 'https://elcinema.com' + image_url
            self.savePoster(image_url, dwn_poster)
            if os.path.exists(dwn_poster) and os.path.getsize(dwn_poster) > 0:
                return True, "[SUCCESS poster: elcinema-tvguide] {} ({}) score={}".format(label_title, work_id, int(score))
            return False, "[SKIP : elcinema] Download failed"
        except Exception as e:
            return False, "[ERROR : elcinema] {}".format(str(e))

    def _elcinema_search_page_candidates(self, query):
        """Search ElCinema pages and return [(title, work_id, score)]."""
        out = []
        try:
            q = re.sub(r'\s+', ' ', _fx_text(query or '')).strip()
            if not q:
                return out
            target = _fx_norm_title(q)
            headers = {"User-Agent": getRandomUserAgent(), "Accept-Language": "ar,en;q=0.8"}
            http = getattr(self, 'http', None) or requests.Session()
            urls = [
                "https://elcinema.com/en/search/?q={}".format(quoteEventName(q)),
                "https://elcinema.com/search/?q={}".format(quoteEventName(q)),
            ]
            seen = set()
            for url in urls:
                try:
                    response = http.get(url, headers=headers, timeout=(3, 7), verify=False)
                    if getattr(response, 'status_code', 0) != 200:
                        continue
                    page = _fx_html_unescape(response.text)
                except Exception:
                    continue
                for tag, work_id, body in re.findall(r'(<a\b[^>]*\bhref=["\'](?:https?://elcinema\.com)?/(?:en/)?work/(\d+)/?["\'][^>]*>)(.*?)</a>', page, flags=re.I | re.S):
                    try:
                        found_title = _fx_attr(tag, 'title') or _fx_strip_tags(body)
                        if not work_id or not found_title:
                            continue
                        key = (work_id, found_title.lower())
                        if key in seen:
                            continue
                        seen.add(key)
                        fn = _fx_norm_title(found_title)
                        if _fx_is_clear_title_mismatch(q, found_title):
                            continue
                        score = int(SequenceMatcher(None, target, fn).ratio() * 100) if target and fn else 0
                        if target and fn and (target in fn or fn in target):
                            score = max(score, 86)
                        out.append((found_title, work_id, score))
                    except Exception:
                        continue
            out.sort(key=lambda x: x[2], reverse=True)
            return out[:6]
        except Exception:
            return out

    def search_elcinema(self, dwn_poster, title, shortdesc, fulldesc, channel=None):
        """Arabic/local poster fallback using ElCinema TV-guide, search pages, then AJAX."""
        try:
            self.dwn_poster = dwn_poster
            self.title_safe = (title or "").replace("+", " ").strip()
            if not dwn_poster or not self.title_safe:
                return False, "[SKIP : elcinema] Invalid input"
            if _fx_is_generic_event_title(self.title_safe):
                return False, "[SKIP : elcinema] Generic event title"
            is_local = (_fx_contains_arabic(title) or _fx_contains_arabic(shortdesc) or
                        _fx_contains_arabic(fulldesc) or _fx_is_arabic_channel(channel))
            if not is_local:
                return False, "[SKIP : elcinema] Not Arabic/local"

            variants = _fx_elcinema_title_variants(self.title_safe)
            for variant in variants:
                match = self._elcinema_best_tvguide_match(variant, min_score=64 if _fx_is_arabic_channel(channel) else 70)
                if match:
                    label_title, work_id, score = match
                    ok, log = self._elcinema_save_work_poster(dwn_poster, work_id, label_title, score)
                    if ok:
                        return ok, log

            # Search page is useful when the work is not in the current TV-guide block.
            for variant in variants[:4]:
                for label_title, work_id, score in self._elcinema_search_page_candidates(variant):
                    if score < 45 and not _fx_is_arabic_channel(channel):
                        continue
                    ok, log = self._elcinema_save_work_poster(dwn_poster, work_id, label_title, score)
                    if ok:
                        return ok, log

            # Keep the previous AJAX search as the final fallback.
            last_log = "[SKIP : elcinema] Not found"
            for variant in variants[:4]:
                ok, log = self._search_elcinema_ajax(dwn_poster, variant, shortdesc, fulldesc, channel)
                last_log = log
                if ok:
                    return ok, log
            return False, last_log
        except Exception as e:
            try:
                if dwn_poster and os.path.exists(dwn_poster):
                    os.remove(dwn_poster)
            except Exception:
                pass
            return False, "[ERROR : elcinema] {}".format(str(e))


    def _search_elcinema_ajax(self, dwn_poster, title, shortdesc, fulldesc, channel=None):
        """Legacy ElCinema AJAX fallback kept after the TV-guide path fails."""
        try:
            self.dwn_poster = dwn_poster
            self.title_safe = (title or "").replace("+", " ").strip()
            if not dwn_poster or not self.title_safe:
                return False, "[SKIP : elcinema] Invalid input"

            chkType, fd = self.checkType(shortdesc, fulldesc)
            year = self._extract_year(fd)
            clean_title = clean_search_title(self.title_safe)
            target_title = self._normalize_match_title(clean_title)
            if not target_title:
                return False, "[SKIP : elcinema] Empty title"

            search_url = "https://elcinema.com/ajaxable/search_simple?q={}".format(quoteEventName(clean_title))
            req_headers = {
                "User-Agent": getRandomUserAgent(),
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "X-Requested-With": "XMLHttpRequest",
                "Referer": "https://elcinema.com/"
            }
            http = getattr(self, 'http', None) or requests.Session()
            response = http.get(search_url, headers=req_headers, timeout=(8, 15), verify=False)
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, list):
                return False, "[SKIP : elcinema] Invalid response"

            candidates = []
            for html_fragment in data:
                try:
                    if 'data-entity="Work"' not in html_fragment:
                        continue
                    work_id_match = re.findall(r'data-id="(\d+)"', html_fragment)
                    if not work_id_match:
                        continue
                    work_id = work_id_match[0]
                    title_match = re.findall(r'title="([^"]+)"', html_fragment)
                    found_title = title_match[0].strip() if title_match else ""
                    poster_match = re.findall(r'<img[^>]+src="([^"]+)"', html_fragment)
                    poster_url = poster_match[0] if poster_match else ""
                    media_type_match = re.findall(u'<li>(فيلم|مسلسل|ﻣﺴﺮﺣﻴﺔ|برنامج|movie|series)</li>', html_fragment)
                    media_type = media_type_match[0] if media_type_match else ""
                    result_year_match = re.findall(r'<li>(19\d{2}|20\d{2})</li>', html_fragment)
                    result_year = result_year_match[0] if result_year_match else ""
                    found_norm = self._normalize_match_title(found_title)
                    if _fx_is_clear_title_mismatch(clean_title, found_title):
                        continue

                    score = 0
                    if found_norm == target_title:
                        score += 500
                    if target_title and found_norm and (target_title in found_norm or found_norm in target_title):
                        score += 150
                    if poster_url and "blank_photos" not in poster_url:
                        score += 100
                    if chkType == "movie" and media_type in (u"فيلم", "movie"):
                        score += 100
                    elif chkType == "tv" and media_type in (u"مسلسل", "series"):
                        score += 100
                    elif chkType == "multi" and media_type in (u"فيلم", u"مسلسل", "movie", "series"):
                        score += 25
                    if year:
                        if result_year == str(year):
                            score += 300
                        elif result_year:
                            score -= 120
                    candidates.append({"id": work_id, "title": found_title, "poster": poster_url, "year": result_year, "score": score})
                except Exception:
                    continue

            if not candidates:
                return False, "[SKIP : elcinema] No candidates"
            candidates.sort(key=lambda item: item.get('score', 0), reverse=True)
            best = candidates[0]
            if best.get('score', 0) < 50:
                return False, "[SKIP : elcinema] No valid match"

            work_html = None
            last_err = None
            for work_url in ("https://elcinema.com/en/work/{}/".format(best['id']), "https://elcinema.com/work/{}/".format(best['id'])):
                try:
                    work_response = http.get(work_url, headers=req_headers, timeout=(8, 15), verify=False)
                    work_response.raise_for_status()
                    work_html = work_response.text
                    break
                except Exception as e:
                    last_err = e
                    continue
            if work_html is None:
                raise last_err or Exception("work page failed")
            img_match = re.findall(r'<meta\s+property="og:image"\s+content="([^"]+)"', work_html)
            if not img_match:
                img_match = re.findall(r'<img[^>]+src="(https?://[^"]+_315x420_[^"]+)"', work_html)
            if not img_match:
                img_match = re.findall(r'<img[^>]+src="(https?://[^"]+\.(?:jpg|jpeg|png))"', work_html)
            if not img_match:
                return False, "[SKIP : elcinema] No poster on work page"

            poster_url = img_match[0]
            self.savePoster(poster_url, dwn_poster)
            if os.path.exists(dwn_poster) and os.path.getsize(dwn_poster) > 0:
                return True, "[SUCCESS poster: elcinema] {} ({}) score={}".format(best.get('title', ''), best.get('id', ''), int(best.get('score', 0)))
            return False, "[SKIP : elcinema] Download failed"
        except Exception as e:
            try:
                if dwn_poster and os.path.exists(dwn_poster):
                    os.remove(dwn_poster)
            except Exception:
                pass
            return False, "[ERROR : elcinema] {}".format(str(e))
    def savePoster(self, url, callback):
        # debug prints removed for performance
        AGENTS = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36",
                  "Mozilla/5.0 (iPhone; CPU iPhone OS 14_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1",
                  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0"]
        headers = {"User-Agent": choice(AGENTS), "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8"}
        part_path = callback + ".part"
        reserved = _reserve_download_target(callback)
        if not reserved:
            return callback
        response = None
        try:
            if isinstance(url, bytes):
                url = url.decode('utf-8', 'ignore')

            session = getattr(self, 'http', None) or requests
            response = session.get(url, headers=headers, stream=True, timeout=POSTER_DOWNLOAD_TIMEOUT)
            response.raise_for_status()

            # Do not pull multi-megabyte images. Some Google results point to huge originals.
            try:
                cl = response.headers.get('Content-Length') or response.headers.get('content-length')
                if cl and int(cl) > POSTER_IMAGE_MAX_BYTES:
                    try:
                        response.close()
                    except Exception:
                        pass
                    return callback
            except Exception:
                pass

            total = 0
            with open(part_path, "wb") as local_file:
                for chunk in response.iter_content(chunk_size=32 * 1024):
                    if not chunk:
                        continue
                    total += len(chunk)
                    if total > POSTER_IMAGE_MAX_BYTES:
                        # Stop immediately instead of downloading the whole file.
                        try:
                            local_file.close()
                        except Exception:
                            pass
                        try:
                            os.remove(part_path)
                        except Exception:
                            pass
                        return callback
                    local_file.write(chunk)

            if os.path.exists(part_path) and os.path.getsize(part_path) > 0:
                try:
                    if os.path.exists(callback):
                        os.remove(callback)
                except Exception:
                    pass
                os.rename(part_path, callback)

            # Normalize downloaded image to real JPEG (fast path for JPEG).
            try:
                if os.path.exists(callback) and os.path.getsize(callback) > 0:
                    with open(callback, "rb") as f:
                        head = f.read(3)
                    if head != b"\xff\xd8\xff":
                        img = Image.open(callback)
                        img = img.convert("RGB")
                        img.save(callback, "JPEG", quality=82, optimize=True)
                        img.close()
            except Exception:
                try:
                    os.remove(callback)
                except Exception:
                    pass

        except exceptions.RequestException:
            try:
                if os.path.exists(part_path):
                    os.remove(part_path)
            except Exception:
                pass
        except Exception:
            try:
                if os.path.exists(part_path):
                    os.remove(part_path)
            except Exception:
                pass
        finally:
            try:
                if response is not None:
                    response.close()
            except Exception:
                pass
            _release_download_target(callback)
        return callback

    def resizePoster(self, dwn_poster):
        try:
            print('resizePoster poster==============')
            # if self.sizeb:
                # self.sizeb = False
                # print('resizePoster backdrop==============')
                # img = Image.open(dwn_poster)
                # width, height = img.size
                # ratio = float(width) // float(height)
                # new_height = int(bisz.split(",")[1])
                # new_width = int(ratio * new_height)
                # try:
                    # rimg = img.resize((new_width, new_height), Image.LANCZOS)
                # except:
                    # rimg = img.resize((new_width, new_height), Image.ANTIALIAS)
                # img.close()
                # rimg.save(dwn_poster)
                # rimg.close()
            img = Image.open(dwn_poster)
            width, height = img.size
            ratio = float(width) // float(height)
            new_height = int(isz.split(",")[1])
            new_width = int(ratio * new_height)
            try:
                rimg = img.resize((new_width, new_height), Image.LANCZOS)
            except:
                rimg = img.resize((new_width, new_height), Image.ANTIALIAS)
            img.close()
            rimg.save(dwn_poster)
            rimg.close()
        except Exception as e:
            print("ERROR:{}".format(e))

    def verifyPoster(self, dwn_poster):
        try:
            img = Image.open(dwn_poster)
            img.verify()
            if img.format == "JPEG":
                pass
            else:
                try:
                    os.remove(dwn_poster)
                except:
                    pass
                return False
        except Exception as e:
            print(e)
            try:
                os.remove(dwn_poster)
            except:
                pass
            return False
        return True

    def checkType(self, shortdesc, fulldesc):
        if shortdesc and shortdesc != '':
            fd = shortdesc.splitlines()[0]
        elif fulldesc and fulldesc != '':
            fd = fulldesc.splitlines()[0]
        else:
            fd = ''
        global srch
        srch = "multi"
        return srch, fd

    def UNAC(self, string):
        string = html.unescape(string)
        string = unicodedata.normalize('NFD', string)
        string = re.sub(r"u0026", "&", string)
        string = re.sub(r"u003d", "=", string)
        string = re.sub(r'[\u0300-\u036f]', '', string)
        string = re.sub(r"[,!?\.\"]", ' ', string)
        string = re.sub(r'\s+', ' ', string)
        string = string.strip()
        return string

    def PMATCH(self, textA, textB):
        if not textB or textB == '' or not textA or textA == '':
            return 0
        if textA == textB:
            return 100
        if textA.replace(" ", "") == textB.replace(" ", ""):
            return 100
        if len(textA) > len(textB):
            lId = len(textA.replace(" ", ""))
        else:
            lId = len(textB.replace(" ", ""))
        textA = textA.split()
        cId = 0
        for id in textA:
            if id in textB:
                cId += len(id)
        cId = 100 * cId // lId
        return cId
