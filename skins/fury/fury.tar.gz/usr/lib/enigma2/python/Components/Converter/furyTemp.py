# -*- coding: utf-8 -*-

# thanks to Madhouse
# mod lululla
# Fury no-lag update: every /proc, /sys, netifaces and hddtemp read happens
# in one shared background worker. Enigma2 getters only format RAM values.

from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.Converter.Poll import Poll
import os
import subprocess
import threading
import time

try:
    import netifaces
except Exception:
    netifaces = None

try:
    from _thread import start_new_thread as _fury_start_new_thread
except Exception:
    try:
        from thread import start_new_thread as _fury_start_new_thread
    except Exception:
        _fury_start_new_thread = None


_TEMP_LOCK = threading.RLock()
_TEMP_WORKER_STARTED = [False]
_TEMP_STATE = {
    "temperature": "N/A",
    "hddtemp": "Waiting for HDD Temp Data...",
    "cpuload": "",
    "cpuspeed": "",
    "fan": ("", "", ""),
    "uptime": None,
    "iplocal": "",
}


def _read_temperature_from_system():
    systemp = ""
    cputemp = ""
    try:
        if os.path.exists("/proc/stb/sensors/temp0/value"):
            with open("/proc/stb/sensors/temp0/value") as stemp:
                systemp = "%s°C" % stemp.readline().replace("\n", "")
        elif os.path.exists("/proc/stb/fp/temp_sensor"):
            with open("/proc/stb/fp/temp_sensor") as stemp:
                systemp = "%s°C" % stemp.readline().replace("\n", "")

        if os.path.exists("/proc/stb/fp/temp_sensor_avs"):
            with open("/proc/stb/fp/temp_sensor_avs") as ctemp:
                cputemp = "%s°C" % ctemp.readline().replace("\n", "")
        elif os.path.exists("/sys/devices/virtual/thermal/thermal_zone0/temp"):
            with open("/sys/devices/virtual/thermal/thermal_zone0/temp") as ctemp:
                raw = ctemp.read().strip()
            try:
                value = int(raw)
                if value > 1000:
                    value = int(round(value / 1000.0))
                cputemp = "%s°C" % value
            except Exception:
                cputemp = "%s°C" % raw[:2]
        elif os.path.exists("/proc/hisi/msp/pm_cpu"):
            with open("/proc/hisi/msp/pm_cpu", "r") as handle:
                for raw_line in handle:
                    parts = [x.strip() for x in raw_line.strip().split(":")]
                    if len(parts) >= 2 and parts[0] == "Tsensor":
                        values = parts[1].split()
                        if len(values) >= 3:
                            cputemp = "%s°C" % values[2]
                        break
    except Exception:
        pass
    return cputemp or systemp or "N/A"


def _read_cpu_load():
    try:
        with open('/proc/loadavg', 'r') as handle:
            return handle.readline(4).replace('\n', '').replace(' ', '')
    except Exception:
        return ""


def _read_cpu_speed():
    cpuspeed = 0
    try:
        with open('/proc/cpuinfo', 'r') as handle:
            for raw in handle:
                parts = [x.strip() for x in raw.strip().split(':', 1)]
                if len(parts) > 1 and parts[0] == 'cpu MHz':
                    cpuspeed = '%1.0f' % float(parts[1])
                    break
    except Exception:
        cpuspeed = 0
    if not cpuspeed:
        try:
            with open('/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq', 'r') as handle:
                cpuspeed = int(handle.read()) / 1000
        except Exception:
            try:
                import binascii
                with open('/sys/firmware/devicetree/base/cpus/cpu@0/clock-frequency', 'rb') as handle:
                    raw = handle.read()
                cpuspeed = int(int(binascii.hexlify(raw), 16) / 100000000) * 100
            except Exception:
                cpuspeed = '-'
    return str(cpuspeed)


def _read_fan():
    fs = ''
    fv = ''
    fp = ''
    try:
        if os.path.exists('/proc/stb/fp/fan_speed'):
            with open('/proc/stb/fp/fan_speed', 'r') as handle:
                fs = str(handle.readline().strip())
        if os.path.exists('/proc/stb/fp/fan_vlt'):
            with open('/proc/stb/fp/fan_vlt', 'r') as handle:
                fv = str(int(handle.readline().strip(), 16))
        if os.path.exists('/proc/stb/fp/fan_pwm'):
            with open('/proc/stb/fp/fan_pwm', 'r') as handle:
                fp = str(int(handle.readline().strip(), 16))
    except Exception:
        pass
    return (fs, fv, fp)


def _read_uptime():
    try:
        with open('/proc/uptime', 'r') as handle:
            parts = handle.read().split()
        return float(parts[0]) if parts else None
    except Exception:
        return None


def _read_iplocal():
    if netifaces is None:
        return ''
    try:
        proto = netifaces.AF_INET
        values = []
        for iface in netifaces.interfaces():
            try:
                data = netifaces.ifaddresses(iface)
                if proto not in data:
                    continue
                for item in data[proto]:
                    addr = item.get("addr")
                    if addr:
                        values.append(str(addr))
            except Exception:
                continue
        # Preserve the old preference for index 1 when it exists; otherwise use
        # the first non-loopback address so boxes with one interface still work.
        if len(values) > 1:
            return values[1]
        for value in values:
            if not value.startswith("127."):
                return value
        return values[0] if values else ''
    except Exception:
        return ''


def _read_hddtemp():
    proc = None
    try:
        proc = subprocess.Popen(
            ['hddtemp', '-n', '-q', '/dev/sda'],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            close_fds=True
        )
        deadline = time.time() + 2.0
        while proc.poll() is None:
            if time.time() >= deadline:
                try:
                    proc.kill()
                except Exception:
                    try:
                        proc.terminate()
                    except Exception:
                        pass
                return 'HDD Temp: N/A'
            time.sleep(0.05)
        out = proc.communicate()[0]
        if out is None:
            return 'HDD Temp: N/A'
        try:
            if not isinstance(out, str):
                out = out.decode('utf-8', 'ignore')
            else:
                try:
                    if not isinstance(out, unicode):  # noqa: F821
                        out = out.decode('utf-8', 'ignore')
                except NameError:
                    pass
        except Exception:
            out = str(out)
        text = str(out).strip()
        if not text:
            return 'HDD idle or N/A'
        try:
            value = int(float(text.split()[0]))
            if value > 0:
                return 'HDD Temp: %s\xc2\xb0C' % value
        except Exception:
            pass
        return 'HDD idle or N/A'
    except Exception:
        try:
            if proc is not None and proc.poll() is None:
                proc.kill()
        except Exception:
            pass
        return 'HDD Temp: N/A'


def _temp_start_thread(target, name):
    def _runner():
        try:
            threading.current_thread().name = name
        except Exception:
            pass
        try:
            target()
        except Exception:
            pass
    try:
        if _fury_start_new_thread is not None:
            _fury_start_new_thread(_runner, ())
            return True
    except Exception:
        pass
    try:
        worker = threading.Thread(target=_runner, name=name)
        worker.daemon = True
        worker.start()
        return True
    except Exception:
        return False


def _temperature_worker():
    now = time.time()
    next_fast = 0.0
    next_thermal = 0.0
    next_ip = now + 1.0
    next_speed = now + 2.0
    next_hdd = now + 6.0

    while True:
        now = time.time()

        if now >= next_fast:
            load = _read_cpu_load()
            uptime = _read_uptime()
            with _TEMP_LOCK:
                _TEMP_STATE["cpuload"] = load
                _TEMP_STATE["uptime"] = uptime
            next_fast = now + 5.0

        if now >= next_thermal:
            temp = _read_temperature_from_system()
            fan = _read_fan()
            with _TEMP_LOCK:
                _TEMP_STATE["temperature"] = temp
                _TEMP_STATE["fan"] = fan
            next_thermal = now + 10.0

        if now >= next_ip:
            value = _read_iplocal()
            with _TEMP_LOCK:
                _TEMP_STATE["iplocal"] = value
            next_ip = now + 15.0

        if now >= next_speed:
            value = _read_cpu_speed()
            with _TEMP_LOCK:
                _TEMP_STATE["cpuspeed"] = value
            next_speed = now + 60.0

        if now >= next_hdd:
            value = _read_hddtemp()
            with _TEMP_LOCK:
                _TEMP_STATE["hddtemp"] = value
            next_hdd = now + 120.0

        time.sleep(0.50)


def _start_temperature_worker():
    if _TEMP_WORKER_STARTED[0]:
        return
    with _TEMP_LOCK:
        if _TEMP_WORKER_STARTED[0]:
            return
        _TEMP_WORKER_STARTED[0] = True
    if not _temp_start_thread(_temperature_worker, "furyTempWorker"):
        with _TEMP_LOCK:
            _TEMP_WORKER_STARTED[0] = False


def _temp_snapshot():
    try:
        with _TEMP_LOCK:
            return dict(_TEMP_STATE)
    except Exception:
        return dict(_TEMP_STATE)


def _format_uptime(total_seconds, short_format):
    if total_seconds is None:
        return 'Uptime: N/A'
    try:
        total_seconds = float(total_seconds)
        minute = 60
        hour = minute * 60
        day = hour * 24
        days = str(int(total_seconds / day))
        hours = str(int(total_seconds % day / hour))
        minutes = str(int(total_seconds % hour / minute))
        seconds = str(int(total_seconds % minute))
        if short_format:
            value = '%sd %sh %sm %ss' % (days, hours, minutes, seconds)
        else:
            value = ''
            if days > '0':
                value += days + ' ' + (days == '1' and 'day' or 'days') + ', '
            if len(value) > 0 or hours > '0':
                value += hours + ' ' + (hours == '1' and 'hr' or 'hrs') + ', '
            if len(value) > 0 or minutes > '0':
                value += minutes + ' ' + (minutes == '1' and 'min' or 'mins')
        return 'Uptime: %s' % value
    except Exception:
        return 'Uptime: N/A'


class furyTemp(Poll, Converter):
    TEMPERATURE = 0
    HDDTEMP = 1
    CPULOAD = 2
    CPUSPEED = 3
    FANINFO = 4
    UPTIME = 5
    IPLOCAL = 6

    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        type = type.split(',')
        self.short_list = True
        self.list = []
        self.shortFormat = 'Short' in type

        if 'CPULoad' in type:
            self.type = self.CPULOAD
            self.poll_interval = 5000
        elif 'CPUSpeed' in type:
            self.type = self.CPUSPEED
            self.poll_interval = 60000
        elif 'Temperature' in type:
            self.type = self.TEMPERATURE
            self.poll_interval = 10000
        elif 'Uptime' in type:
            self.type = self.UPTIME
            self.poll_interval = 7000
        elif 'Iplocal' in type:
            self.type = self.IPLOCAL
            self.poll_interval = 15000
        elif 'HDDTemp' in type:
            self.type = self.HDDTEMP
            self.poll_interval = 60000
        elif 'FanInfo' in type:
            self.type = self.FANINFO
            self.poll_interval = 10000
        else:
            self.type = self.TEMPERATURE
            self.poll_interval = 10000

        self.poll_enabled = True
        _start_temperature_worker()

    @cached
    def getText(self):
        state = _temp_snapshot()

        if self.type == self.CPULOAD:
            return 'CPU Load: %s' % state.get("cpuload", "")

        if self.type == self.TEMPERATURE:
            return state.get("temperature", "N/A")

        if self.type == self.HDDTEMP:
            return state.get("hddtemp", "HDD Temp: N/A")

        if self.type == self.IPLOCAL:
            return state.get("iplocal", "")

        if self.type == self.CPUSPEED:
            value = state.get("cpuspeed", "")
            return ('CPU Speed: %s MHz' % value) if value else ''

        if self.type == self.FANINFO:
            fs, fv, fp = state.get("fan", ("", "", ""))
            if fs == '':
                return 'Fan Info: N/A'
            if self.shortFormat:
                return '%s - %sV - P:%s' % (fs, fv, fp)
            return 'Speed: %s V: %s PWM: %s' % (fs, fv, fp)

        if self.type == self.UPTIME:
            return _format_uptime(state.get("uptime"), self.shortFormat)

        return ''

    text = property(getText)

    def changed(self, what):
        if what[0] == self.CHANGED_POLL:
            self.downstream_elements.changed(what)
