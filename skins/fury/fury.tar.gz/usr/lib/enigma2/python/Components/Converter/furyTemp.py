# -*- coding: utf-8 -*-

# thanks to Madhouse
# mod lululla
from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.Converter.Poll import Poll
from enigma import eConsoleAppContainer
import netifaces
import os
import threading
import time


# ------------------------------------------------------------------
# Non-blocking temperature cache
# Reading some /proc drivers (especially /proc/hisi/msp/pm_cpu) can
# occasionally block Enigma2's GUI thread.  A single daemon worker
# refreshes the value in the background; the Converter only reads RAM.
# ------------------------------------------------------------------
_TEMP_CACHE = "N/A"
_TEMP_LOCK = threading.Lock()
_TEMP_WORKER_STARTED = False


def _read_temperature_from_system():
    systemp = ""
    cputemp = ""
    try:
        if os.path.exists("/proc/stb/sensors/temp0/value"):
            with open("/proc/stb/sensors/temp0/value") as stemp:
                systemp = "%s°C" % stemp.readline().replace("\n", "")
        elif os.path.exists("/proc/stb/fp/temp_sensor"):
            with open("/proc/stb/fp/temp_sensor") as stemp:
                systemp = "%s°C" % stemp.readline().replace("\n", "")

        if os.path.exists("/proc/stb/fp/temp_sensor_avs"):
            with open("/proc/stb/fp/temp_sensor_avs") as ctemp:
                cputemp = "%s°C" % ctemp.readline().replace("\n", "")
        elif os.path.exists("/sys/devices/virtual/thermal/thermal_zone0/temp"):
            with open("/sys/devices/virtual/thermal/thermal_zone0/temp") as ctemp:
                raw = ctemp.read().strip()
                try:
                    value = int(raw)
                    if value > 1000:
                        value = int(round(value / 1000.0))
                    cputemp = "%s°C" % value
                except Exception:
                    cputemp = "%s°C" % raw[:2]
        elif os.path.exists("/proc/hisi/msp/pm_cpu"):
            with open("/proc/hisi/msp/pm_cpu", "r") as handle:
                for raw_line in handle:
                    parts = [x.strip() for x in raw_line.strip().split(":")]
                    if len(parts) >= 2 and parts[0] == "Tsensor":
                        values = parts[1].split()
                        if len(values) >= 3:
                            cputemp = "%s°C" % values[2]
                        break
    except Exception:
        pass

    if cputemp:
        return cputemp
    if systemp:
        return systemp
    return "N/A"


def _temperature_worker():
    global _TEMP_CACHE
    while True:
        try:
            value = _read_temperature_from_system()
            with _TEMP_LOCK:
                _TEMP_CACHE = value
        except Exception:
            pass
        time.sleep(7.0)


def _start_temperature_worker():
    global _TEMP_WORKER_STARTED
    if _TEMP_WORKER_STARTED:
        return
    _TEMP_WORKER_STARTED = True
    try:
        worker = threading.Thread(target=_temperature_worker, name="furyTempWorker")
        worker.daemon = True
        worker.start()
    except Exception:
        _TEMP_WORKER_STARTED = False


def _get_cached_temperature():
    try:
        with _TEMP_LOCK:
            return _TEMP_CACHE
    except Exception:
        return _TEMP_CACHE


class furyTemp(Poll, Converter):
    TEMPERATURE = 0
    HDDTEMP = 1
    CPULOAD = 2
    CPUSPEED = 3
    FANINFO = 4
    UPTIME = 5
    IPLOCAL = 6

    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.container = eConsoleAppContainer()
        type = type.split(',')
        self.short_list = True
        self.list = []
        self.shortFormat = 'Short' in type
        if 'CPULoad' in type:
            self.type = self.CPULOAD
        elif 'CPUSpeed' in type:
            self.type = self.CPUSPEED
        elif 'Temperature' in type:
            self.type = self.TEMPERATURE
            _start_temperature_worker()
        elif 'Uptime' in type:
            self.type = self.UPTIME
        elif 'Iplocal' in type:
            self.type = self.IPLOCAL
        elif 'HDDTemp' in type:
            self.type = self.HDDTEMP
            self.hddtemp_output = ''
            self.hddtemp = 'Waiting for HDD Temp Data...'
            self.container.appClosed.append(self.runFinished)
            self.container.dataAvail.append(self.dataAvail)
            self.container.execute('hddtemp -n -q /dev/sda')
        elif 'FanInfo' in type:
            self.type = self.FANINFO
        if 'HDDTemp' in type:
            self.poll_interval = 500
        else:
            self.poll_interval = 7000
        self.poll_enabled = True

    def dataAvail(self, strData):
        self.hddtemp_output = self.hddtemp_output.encode('utf-8', 'ignore') + strData

    def runFinished(self, retval):
        temp = self.hddtemp_output.decode('utf-8', 'ignore')
        if 'No such file or directory' in temp or 'not found' in temp:
            self.hddtemp = 'HDD Temp: N/A'
        else:
            temp = int(temp)
            if temp > 0:
                temp = str(temp)
                self.hddtemp = 'HDD Temp: %s\xc2\xb0C' % temp
            else:
                self.hddtemp = 'HDD idle or N/A'

    @cached
    def getText(self):
        text = ''
        if self.type == self.CPULOAD:
            cpuload = ''
            if os.path.exists('/proc/loadavg'):
                try:
                    with open('/proc/loadavg', 'r') as (l):
                        load = l.readline(4)
                except:
                    load = ''

                cpuload = load.replace('\n', '').replace(' ', '')
                return 'CPU Load: %s' % cpuload
        if self.type == self.TEMPERATURE:
            # Never touch /proc or /sys from the Enigma2 GUI thread.
            # The background worker above refreshes this cache every 7 seconds.
            return _get_cached_temperature()
        if self.type == self.HDDTEMP:
            return self.hddtemp
        if self.type == self.IPLOCAL:
            try:
                PROTO = netifaces.AF_INET
                ifaces = netifaces.interfaces()
                if_addrs = [netifaces.ifaddresses(iface) for iface in ifaces]
                if_inet_addrs = [addr[PROTO] for addr in if_addrs if PROTO in addr]
                iface_addrs = [s["addr"] for a in if_inet_addrs for s in a if "addr" in s]
                ip_local = str(iface_addrs[1])
            except:
                ip_local = ''
        return ip_local
        if self.type == self.CPUSPEED:
            try:
                cpuspeed = 0
                for line in open('/proc/cpuinfo').readlines():
                    line = [x.strip() for x in line.strip().split(':')]
                    if line[0] == 'cpu MHz':
                        cpuspeed = '%1.0f' % float(line[1])

                if not cpuspeed:
                    try:
                        import binascii
                        cpuspeed = int(int(binascii.hexlify(open('/sys/firmware/devicetree/base/cpus/cpu@0/clock-frequency', 'rb').read()), 16) / 100000000) * 100
                    except:
                        try:
                            cpuspeed = int(open('/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq').read()) / 1000
                        except:
                            cpuspeed = '-'

                return 'CPU Speed: %s MHz' % cpuspeed
            except:
                return ''

        if self.type == self.FANINFO:
            fs = ''
            fv = ''
            fp = ''
            try:
                if os.path.exists('/proc/stb/fp/fan_speed'):
                    with open('/proc/stb/fp/fan_speed', 'r') as (fs):
                        fs = str(fs.readline().strip())
                if os.path.exists('/proc/stb/fp/fan_vlt'):
                    with open('/proc/stb/fp/fan_vlt', 'r') as (fv):
                        fv = str(int(fv.readline().strip(), 16))
                if os.path.exists('/proc/stb/fp/fan_pwm'):
                    with open('/proc/stb/fp/fan_pwm', 'r') as (fp):
                        fp = str(int(fp.readline().strip(), 16))
            except:
                pass

            if fs == '':
                return 'Fan Info: N/A'
            if self.shortFormat:
                return '%s - %sV - P:%s' % (fs, fv, fp)
            return 'Speed: %s V: %s PWM: %s' % (fs, fv, fp)
        elif self.type == self.UPTIME:
            try:
                with open('/proc/uptime', 'r') as (up):
                    uptime_info = up.read().split()
            except:
                return 'Uptime: N/A'
                uptime_info = None

            if uptime_info is not None:
                total_seconds = float(uptime_info[0])
                MINUTE = 60
                HOUR = MINUTE * 60
                DAY = HOUR * 24
                days = str(int(total_seconds / DAY))
                hours = str(int(total_seconds % DAY / HOUR))
                minutes = str(int(total_seconds % HOUR / MINUTE))
                seconds = str(int(total_seconds % MINUTE))
                uptime = ''
                if self.shortFormat:
                    uptime = '%sd %sh %sm %ss' % (days, hours, minutes, seconds)
                else:
                    if days > '0':
                        uptime += days + ' ' + (days == '1' and 'day' or 'days') + ', '
                    if len(uptime) > 0 or hours > '0':
                        uptime += hours + ' ' + (hours == '1' and 'hr' or 'hrs') + ', '
                    if len(uptime) > 0 or minutes > '0':
                        uptime += minutes + ' ' + (minutes == '1' and 'min' or 'mins')
                return 'Uptime: %s' % uptime
        return text

    text = property(getText)

    def changed(self, what):
        if what[0] == self.CHANGED_POLL:
            self.downstream_elements.changed(what)
