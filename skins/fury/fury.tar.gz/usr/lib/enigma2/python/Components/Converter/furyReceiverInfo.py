from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.Converter.Poll import Poll
from os import popen, statvfs
import os
import subprocess
import threading
import time
try:
    from _thread import start_new_thread as _fury_start_new_thread
except Exception:
    try:
        from thread import start_new_thread as _fury_start_new_thread
    except Exception:
        _fury_start_new_thread = None

SIZE_UNITS = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB']


# ---------- shared no-lag receiver information cache ----------
# All filesystem reads, statvfs calls and hddtemp execution happen here,
# never inside Enigma GUI getters.
_RECEIVER_CACHE_LOCK = threading.RLock()
_RECEIVER_WORKER_LOCK = threading.Lock()
_RECEIVER_WORKER_STARTED = False

_RECEIVER_CACHE = {
	'loadavg': 'No info',
	'hddtemp': 'No info',
	'mem': [0, 0, 0, 0],
	'swap': [0, 0, 0, 0],
	'disks': {
		'/': [0, 0, 0, 0],
		'/media/hdd': [0, 0, 0, 0],
		'/media/usb': [0, 0, 0, 0],
		'/media/mmc': [0, 0, 0, 0],
	},
	'mounts': set(['/']),
}


def _receiver_percent(total, used):
	try:
		if total > 0:
			return int((used * 100) / total)
	except Exception:
		pass
	return 0


def _receiver_read_meminfo():
	mem = [0, 0, 0, 0]
	swap = [0, 0, 0, 0]
	values = {}
	try:
		with open('/proc/meminfo', 'r') as fd:
			for line in fd:
				parts = line.split()
				if len(parts) >= 2:
					key = parts[0].rstrip(':')
					if key in ('MemTotal', 'MemFree', 'MemAvailable', 'SwapTotal', 'SwapFree'):
						try:
							values[key] = int(parts[1]) * 1024
						except Exception:
							values[key] = 0
	except Exception:
		return mem, swap

	try:
		mem[0] = int(values.get('MemTotal', 0) or 0)
		# Preserve the original converter behaviour: use MemFree when available.
		mem[2] = int(values.get('MemFree', values.get('MemAvailable', 0)) or 0)
		mem[1] = max(0, mem[0] - mem[2])
		mem[3] = _receiver_percent(mem[0], mem[1])
	except Exception:
		mem = [0, 0, 0, 0]

	try:
		swap[0] = int(values.get('SwapTotal', 0) or 0)
		swap[2] = int(values.get('SwapFree', 0) or 0)
		swap[1] = max(0, swap[0] - swap[2])
		swap[3] = _receiver_percent(swap[0], swap[1])
	except Exception:
		swap = [0, 0, 0, 0]

	return mem, swap


def _receiver_read_mounts():
	mounts = set(['/'])
	try:
		with open('/proc/mounts', 'r') as fd:
			for line in fd:
				parts = line.split()
				if len(parts) > 1:
					path = parts[1].replace('\\040', ' ').replace('\\011', '\t')
					mounts.add(path)
	except Exception:
		pass
	return mounts


def _receiver_read_disk(path, mounts):
	result = [0, 0, 0, 0]
	try:
		if path != '/' and path not in mounts:
			return result
		st = statvfs(path)
		if st and st.f_bsize and st.f_blocks:
			result[0] = int(st.f_bsize * st.f_blocks)
			result[2] = int(st.f_bsize * st.f_bavail)
			result[1] = max(0, result[0] - result[2])
			result[3] = _receiver_percent(result[0], result[1])
	except Exception:
		pass
	return result


def _receiver_read_loadavg():
	try:
		with open('/proc/loadavg', 'r') as fd:
			return fd.readline()[:15].strip() or 'No info'
	except Exception:
		return 'No info'


def _receiver_read_hddtemp():
	# Never let hddtemp hold a worker forever (sleeping/absent disks are common).
	proc = None
	try:
		proc = subprocess.Popen(
			['hddtemp', '-n', '-q', '/dev/sda'],
			stdout=subprocess.PIPE,
			stderr=subprocess.STDOUT,
			close_fds=True
		)
		deadline = time.time() + 2.0
		while proc.poll() is None:
			if time.time() >= deadline:
				try:
					proc.kill()
				except Exception:
					try:
						proc.terminate()
					except Exception:
						pass
				return "No info"
			time.sleep(0.05)
		out = proc.communicate()[0]
		if out is None:
			return "No info"
		try:
			if not isinstance(out, str):
				out = out.decode('utf-8', 'ignore')
			else:
				try:
					if not isinstance(out, unicode):  # noqa: F821
						out = out.decode('utf-8', 'ignore')
				except NameError:
					pass
		except Exception:
			out = str(out)
		temp = str(out).strip()
		return ("%s°C" % temp) if temp else "No info"
	except Exception:
		try:
			if proc is not None and proc.poll() is None:
				proc.kill()
		except Exception:
			pass
		return "No info"


def _receiver_refresh_fast():
	mem, swap = _receiver_read_meminfo()
	loadavg = _receiver_read_loadavg()
	with _RECEIVER_CACHE_LOCK:
		_RECEIVER_CACHE['mem'] = mem
		_RECEIVER_CACHE['swap'] = swap
		_RECEIVER_CACHE['loadavg'] = loadavg


def _receiver_refresh_disks():
	mounts = _receiver_read_mounts()
	disks = {}
	for path in ('/', '/media/hdd', '/media/usb', '/media/mmc'):
		disks[path] = _receiver_read_disk(path, mounts)
	with _RECEIVER_CACHE_LOCK:
		_RECEIVER_CACHE['mounts'] = mounts
		_RECEIVER_CACHE['disks'] = disks


def _receiver_refresh_hddtemp():
	value = _receiver_read_hddtemp()
	with _RECEIVER_CACHE_LOCK:
		_RECEIVER_CACHE['hddtemp'] = value


def _receiver_start_thread(target, name):
	def _runner():
		try:
			threading.current_thread().name = name
		except Exception:
			pass
		try:
			target()
		except Exception:
			pass
	try:
		if _fury_start_new_thread is not None:
			_fury_start_new_thread(_runner, ())
			return True
	except Exception:
		pass
	try:
		worker = threading.Thread(target=_runner, name=name)
		worker.daemon = True
		worker.start()
		return True
	except Exception:
		return False


def _receiver_worker():
	# Stagger expensive probes so boot/skin creation never launches them together.
	now = time.time()
	next_fast = 0.0
	next_disks = now + 3.0
	next_temp = now + 8.0
	while True:
		now = time.time()
		if now >= next_fast:
			try:
				_receiver_refresh_fast()
			except Exception:
				pass
			next_fast = now + 2.0
		if now >= next_disks:
			try:
				_receiver_refresh_disks()
			except Exception:
				pass
			next_disks = now + 30.0
		if now >= next_temp:
			try:
				_receiver_refresh_hddtemp()
			except Exception:
				pass
			next_temp = now + 120.0
		time.sleep(0.50)


def _receiver_start_worker():
	global _RECEIVER_WORKER_STARTED
	if _RECEIVER_WORKER_STARTED:
		return
	with _RECEIVER_WORKER_LOCK:
		if _RECEIVER_WORKER_STARTED:
			return
		_RECEIVER_WORKER_STARTED = True
	if not _receiver_start_thread(_receiver_worker, 'furyReceiverInfo-cache'):
		with _RECEIVER_WORKER_LOCK:
			_RECEIVER_WORKER_STARTED = False


def _receiver_cache_list(key):
	with _RECEIVER_CACHE_LOCK:
		try:
			return list(_RECEIVER_CACHE.get(key, [0, 0, 0, 0]))
		except Exception:
			return [0, 0, 0, 0]


class furyReceiverInfo(Poll, Converter):
	HDDTEMP = 0
	LOADAVG = 1
	MEMTOTAL = 2
	MEMFREE = 3
	SWAPTOTAL = 4
	SWAPFREE = 5
	USBINFO = 6
	HDDINFO = 7
	FLASHINFO = 8
	MMCINFO = 9

	def __init__(self, type):
		Converter.__init__(self, type)
		Poll.__init__(self)
		type = type.split(',')
		self.shortFormat = 'Short' in type
		self.fullFormat = 'Full' in type
		self.type = self.get_type_from_string(type)
		if self.type in (self.FLASHINFO, self.HDDINFO, self.MMCINFO, self.USBINFO):
			self.poll_interval = 30000
		elif self.type == self.HDDTEMP:
			self.poll_interval = 60000
		else:
			self.poll_interval = 2000
		self.poll_enabled = True
		try:
			_receiver_start_worker()
		except Exception:
			pass

	def get_type_from_string(self, type_list):
		type_mapping = {
			'HddTemp': self.HDDTEMP,
			'LoadAvg': self.LOADAVG,
			'MemTotal': self.MEMTOTAL,
			'MemFree': self.MEMFREE,
			'SwapTotal': self.SWAPTOTAL,
			'SwapFree': self.SWAPFREE,
			'UsbInfo': self.USBINFO,
			'HddInfo': self.HDDINFO,
			'MmcInfo': self.MMCINFO,
		}
		for key, value in type_mapping.items():
			if key in type_list:
				return value
		return self.FLASHINFO

	@cached
	def getText(self):
		if self.type == self.HDDTEMP:
			return self.getHddTemp()
		elif self.type == self.LOADAVG:
			return self.getLoadAvg()
		else:
			entry = self.get_info_entry()
			info = self.get_disk_or_mem_info(entry[0])
			return self.format_text(entry[1], info)

	def get_info_entry(self):
		return {
			self.MEMTOTAL: ('Mem', 'Ram'),
			self.MEMFREE: ('Mem', 'Ram'),
			self.SWAPTOTAL: ('Swap', 'Swap'),
			self.SWAPFREE: ('Swap', 'Swap'),
			self.USBINFO: ('/media/usb', 'USB'),
			self.MMCINFO: ('/media/mmc', 'MMC'),
			self.HDDINFO: ('/media/hdd', 'HDD'),
			self.FLASHINFO: ('/', 'Flash')
		}.get(self.type, ('/', 'Unknown'))

	def get_disk_or_mem_info(self, path_or_value):
		if self.type in (self.USBINFO, self.MMCINFO, self.HDDINFO, self.FLASHINFO):
			return self.getDiskInfo(path_or_value)
		return self.getMemInfo(path_or_value)

	def format_text(self, label, info):
		if info[0] == 0:
			return '%s: Not Available' % label
		elif self.shortFormat:
			return '%s: %s, in use: %s%%' % (label, self.getSizeStr(info[0]), info[3])
		elif self.fullFormat:
			return '%s: %s Free:%s used:%s (%s%%)' % (
				label, self.getSizeStr(info[0]), self.getSizeStr(info[2]),
				self.getSizeStr(info[1]), info[3])
		else:
			return '%s: %s used:%s Free:%s' % (
				label, self.getSizeStr(info[0]), self.getSizeStr(info[1]),
				self.getSizeStr(info[2]))

	@cached
	def getValue(self):
		result = 0
		if self.type in (self.MEMTOTAL, self.MEMFREE, self.SWAPTOTAL, self.SWAPFREE):
			entry = {
				self.MEMTOTAL: 'Mem', self.MEMFREE: 'Mem',
				self.SWAPTOTAL: 'Swap', self.SWAPFREE: 'Swap'
			}[self.type]
			result = self.getMemInfo(entry)[3]
		elif self.type in (self.USBINFO, self.MMCINFO, self.HDDINFO, self.FLASHINFO):
			path = {
				self.USBINFO: '/media/usb', self.HDDINFO: '/media/hdd',
				self.MMCINFO: '/media/mmc', self.FLASHINFO: '/'
			}[self.type]
			result = self.getDiskInfo(path)[3]
		return result

	text = property(getText)
	value = property(getValue)
	range = 100  # Added range attribute to fix the skin error

	def getHddTemp(self):
		try:
			_receiver_start_worker()
		except Exception:
			pass
		with _RECEIVER_CACHE_LOCK:
			return _RECEIVER_CACHE.get('hddtemp', 'No info')

	def getLoadAvg(self):
		try:
			_receiver_start_worker()
		except Exception:
			pass
		with _RECEIVER_CACHE_LOCK:
			return _RECEIVER_CACHE.get('loadavg', 'No info')

	def getMemInfo(self, value):
		try:
			_receiver_start_worker()
		except Exception:
			pass
		return _receiver_cache_list('swap' if value == 'Swap' else 'mem')

	def getDiskInfo(self, path):
		try:
			_receiver_start_worker()
		except Exception:
			pass
		with _RECEIVER_CACHE_LOCK:
			try:
				return list(_RECEIVER_CACHE.get('disks', {}).get(path, [0, 0, 0, 0]))
			except Exception:
				return [0, 0, 0, 0]

	def is_mount_point(self, path):
		try:
			_receiver_start_worker()
		except Exception:
			pass
		with _RECEIVER_CACHE_LOCK:
			try:
				return path == '/' or path in _RECEIVER_CACHE.get('mounts', set(['/']))
			except Exception:
				return path == '/'

	def getSizeStr(self, value, u=0):
		fractal = 0
		if value >= 1024:
			while value >= 1024 and u < len(SIZE_UNITS):
				value, mod = divmod(value, 1024)
				fractal = mod * 10 // 1024
				u += 1
		return '%s%s %s' % (value, ('.' + str(fractal)) if fractal else '', SIZE_UNITS[u])

	def doSuspend(self, suspended):
		self.poll_enabled = not suspended
		if not suspended:
			self.downstream_elements.changed((self.CHANGED_POLL,))


"""
<screen name="ReceiverInfoScreen" position="center,center" size="1280,720" title="Receiver Information">
	<!-- Widget per mostrare la temperatura del disco HDD -->
	<widget name="hddTemp" source="ServiceEvent" render="Label" position="50,100" size="1180,50" font="Bold; 26" backgroundColor="background" transparent="1" noWrap="1" zPosition="1" foregroundColor="green" valign="center">
		<convert type="furyReceiverInfo">HddTemp</convert>
	</widget>

	<!-- Widget per mostrare il carico medio (LoadAvg) -->
	<widget name="loadAvg" source="ServiceEvent" render="Label" position="50,160" size="1180,50" font="Bold; 26" backgroundColor="background" transparent="1" noWrap="1" zPosition="1" foregroundColor="yellow" valign="center">
		<convert type="furyReceiverInfo">LoadAvg</convert>
	</widget>

	<!-- Widget per mostrare la memoria totale -->
	<widget name="memTotal" source="ServiceEvent" render="Label" position="50,220" size="1180,50" font="Bold; 26" backgroundColor="background" transparent="1" noWrap="1" zPosition="1" foregroundColor="blue" valign="center">
		<convert type="furyReceiverInfo">MemTotal</convert>
	</widget>

	<!-- Widget per mostrare la memoria libera -->
	<widget name="memFree" source="ServiceEvent" render="Label" position="50,280" size="1180,50" font="Bold; 26" backgroundColor="background" transparent="1" noWrap="1" zPosition="1" foregroundColor="red" valign="center">
		<convert type="furyReceiverInfo">MemFree</convert>
	</widget>

	<!-- Widget per mostrare lo spazio swap totale -->
	<widget name="swapTotal" source="ServiceEvent" render="Label" position="50,340" size="1180,50" font="Bold; 26" backgroundColor="background" transparent="1" noWrap="1" zPosition="1" foregroundColor="purple" valign="center">
		<convert type="furyReceiverInfo">SwapTotal</convert>
	</widget>

	<!-- Widget per mostrare lo spazio swap libero -->
	<widget name="swapFree" source="ServiceEvent" render="Label" position="50,400" size="1180,50" font="Bold; 26" backgroundColor="background" transparent="1" noWrap="1" zPosition="1" foregroundColor="orange" valign="center">
		<convert type="furyReceiverInfo">SwapFree</convert>
	</widget>

	<!-- Widget per mostrare informazioni sul dispositivo USB -->
	<widget name="usbInfo" source="ServiceEvent" render="Label" position="50,460" size="1180,50" font="Bold; 26" backgroundColor="background" transparent="1" noWrap="1" zPosition="1" foregroundColor="cyan" valign="center">
		<convert type="furyReceiverInfo">UsbInfo</convert>
	</widget>

	<!-- Widget per mostrare informazioni sul disco HDD -->
	<widget name="hddInfo" source="ServiceEvent" render="Label" position="50,520" size="1180,50" font="Bold; 26" backgroundColor="background" transparent="1" noWrap="1" zPosition="1" foregroundColor="pink" valign="center">
		<convert type="furyReceiverInfo">HddInfo</convert>
	</widget>

	<!-- Widget per mostrare informazioni sulla memoria Flash -->
	<widget name="flashInfo" source="ServiceEvent" render="Label" position="50,580" size="1180,50" font="Bold; 26" backgroundColor="background" transparent="1" noWrap="1" zPosition="1" foregroundColor="lime" valign="center">
		<convert type="furyReceiverInfo">FlashInfo</convert>
	</widget>

	<!-- Widget per mostrare informazioni sulla memoria MMC -->
	<widget name="mmcInfo" source="ServiceEvent" render="Label" position="50,640" size="1180,50" font="Bold; 26" backgroundColor="background" transparent="1" noWrap="1" zPosition="1" foregroundColor="magenta" valign="center">
		<convert type="furyReceiverInfo">MmcInfo</convert>
	</widget>
</screen>
"""
