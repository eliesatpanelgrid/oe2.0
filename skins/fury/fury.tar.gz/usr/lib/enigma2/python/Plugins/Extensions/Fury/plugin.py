# -*- coding: utf-8 -*-
# Skin Fury by islam salama (( Abou Yassin ))
# yassin.s76m@gmail.com
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Components.About import about
from Components.ActionMap import ActionMap
from Components.config import (
    config, configfile, ConfigYesNo, ConfigSubsection, getConfigListEntry,
    ConfigSelection, ConfigNumber, ConfigText, ConfigInteger, NoSave, ConfigNothing
)
from Components.ConfigList import ConfigListScreen
from Components.Sources.Progress import Progress
from Tools.Downloader import downloadWithProgress
from Components.Sources.StaticText import StaticText
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.AVSwitch import AVSwitch
from Tools.Directories import fileExists
import os
import sys
import re
import json
import time
from enigma import ePicLoad, eTimer, eConsoleAppContainer

PY3 = sys.version_info.major >= 3
if PY3:
    from urllib.request import urlopen, Request
else:
    from urllib2 import urlopen, Request

# ------------------- i18n / gettext -------------------
# We define a plugin-specific gettext domain here so that all _('...') strings
# in this file can be translated via locale/<lang>/LC_MESSAGES/<domain>.mo
import gettext

PLUGIN_LANGUAGE_DOMAIN = "Fury"
PLUGIN_LOCALE_DIR = os.path.join(os.path.dirname(__file__), "locale")

def localeInit():
    try:
        gettext.bindtextdomain(PLUGIN_LANGUAGE_DOMAIN, PLUGIN_LOCALE_DIR)
        gettext.textdomain(PLUGIN_LANGUAGE_DOMAIN)
    except Exception:
        pass

def _(txt):
    try:
        return gettext.dgettext(PLUGIN_LANGUAGE_DOMAIN, txt)
    except Exception:
        return txt

# Initialize translations early (before any _('...') usage below)
localeInit()

# ------------------- Plugin Verioin -------------------

version = "8.7"

# ------------------- AIFury extra plugin -------------------
AIFURY_BASE_URL = 'https://raw.githubusercontent.com/islam-2412/IPKS/main/fury/AIFury/aifury_py%s_%s.ipk'
AIFURY_API_BASE = 'https://api.github.com/repos/islam-2412/IPKS/contents/fury/AIFury'
AIFURY_REF_API = 'https://api.github.com/repos/islam-2412/IPKS/git/ref/heads/main'
AIFURY_RAW_REPO = 'https://raw.githubusercontent.com/islam-2412/IPKS'
# AIFury ships Cython compiled .so files, bound to one exact python ABI and
# one cpu, so a package of another python version would install but never
# import -> exact match only. Keep this False unless you publish pure-python
# builds.
AIFURY_TRY_FALLBACK_PY = False
AIFURY_FALLBACK_PY = ('3.14', '3.13', '3.12', '3.11', '3.10', '3.9', '3.8')
UPDATE_LOG = '/tmp/fury_update.log'
# flag file: tells the skin postinst not to install AIFury itself
AIFURY_LOCK = '/tmp/.fury_no_aifury'
# A small status file links the detached skin postinst to one live Enigma2
# progress screen.  The acknowledgement proves that this version of the Fury
# plugin is already loaded; otherwise postinst safely falls back to OpenWebif.
INSTALL_PROGRESS_FILE = '/tmp/fury_install_progress'
INSTALL_PROGRESS_ACK = '/tmp/fury_install_progress_ack'


# --- Helpers: version compare (avoid string-compare pitfalls) ---
def _ver_tuple(v):
    try:
        return tuple(int(x) for x in re.findall(r"\d+", str(v)))
    except Exception:
        return (0,)

# ------------------- Fury Config -------------------
config.plugins.Fury = ConfigSubsection()
config.plugins.Fury.SkinResolution = ConfigSelection(default='fhd', choices=[
 ('fhd', _('FHD'))])
 #('2k', _('2K'))])
# Migrate older installations that stored the removed 'default' value.
try:
    if config.plugins.Fury.SkinResolution.value not in ('fhd', '2k'):
        config.plugins.Fury.SkinResolution.value = 'fhd'
except Exception:
    pass
config.plugins.Fury.skinSelector = ConfigSelection(default='base', choices=[
 ('base', _('Default'))])
config.plugins.Fury.colorSelector = ConfigSelection(default='head', choices=[
 ('head', _('Default')),
 ('color1_Red', _('Red')),
 ('color2_Green', _('Green')),
 ('color3_Grey', _('Grey')),
 ('color4_Blue', _('Blue')),
 ('color5_Green2', _('Green2')),
 ('color6_Brown', _('Brown')),
 ('color7_Dark Purple', _('Dark Purple')),
 ('color8_Dark Red', _('Dark Red')),
 ('color9_Orange', _('Orange')),
 ('color10_Grey2', _('Grey2')),
 ('color11_Oily', _('Oily')),
 ('color12_Black', _('Black'))])
config.plugins.Fury.FontStyle = ConfigSelection(default='basic', choices=[
 ('basic', _('Default')),
 ('font1', _('Verdana')),
 ('font2', _('Cravelo')),
 ('font3', _('Mongule')),
 ('font4', _('Tenada')),
 ('font5', _('HandelGotDBol')),
 ('font6', _('Fury')),
 ('font7', _('Joyful')),
 ('font8', _('Nexa')),
 ('font9', _('Tommy ')),
 ('font10', _('Poetsen_One '))])
config.plugins.Fury.FontScale = ConfigSelection(default='93', choices=[
 ('93', _('Default')),
 ('75',  _('-25%')),
 ('80',  _('-20%')),
 ('85',  _('-15%')),
 ('90',  _('-10%')),
 ('95',  _('-5%')),
 ('102', _('+2%')),
 ('105', _('+5%')),
 ('107', _('+7%')),
 ('109', _('+9%')),
 ('110', _('+10%')),
 ('113', _('+13%')), 
 ('115', _('+15%')),
 ('120', _('+20%')), 
 ('125', _('+25%')),
 ('130', _('+30%'))]) 
config.plugins.Fury.transparency = ConfigSelection(default='06', choices=[
 ('06', _('Default')),
 ('10', _('~5%')),
 ('20', _('~10%')),
 ('25', _('~15%')),
 ('30', _('~20%')),
 ('40', _('~25%')),
 ('55', _('~30%')),
 ('65', _('~35%')),
 ('75', _('~40%')),
 ('80', _('~45%')),
 ('90', _('~50%')),
 ('00', _('Zero'))])
config.plugins.Fury.DateFormat = ConfigSelection(default='%d %B %Y', choices=[
 ('%d %B %Y', _('DD Month YYYY (e.g. 06 February 2026)')),
 ('%d-%m-%Y', _('DD-MM-YYYY')),
 ('%d/%m/%Y', _('DD/MM/YYYY')),
 ('%d.%m.%Y', _('DD.MM.YYYY')),
 ('%m-%d-%Y', _('MM-DD-YYYY')),
 ('%m/%d/%Y', _('MM/DD/YYYY')),
 ('%Y-%m-%d', _('YYYY-MM-DD')),
 ('%Y/%m/%d', _('YYYY/MM/DD')),
 ('%Y.%m.%d', _('YYYY.MM.DD')),
 ('%d %m %Y', _('DD MM YYYY')),
 ('%Y %b %d', _('2025 Jan 01')),
 ('%A, %d %m %Y', _('Monday, 01 01 2025')),
 ('%a %d %b %Y', _('Mon 01 Jan 2025')),
 ('%Y/%m/%d %A', _('2025/01/01 Monday')),
 ('%B %d, %Y', _('January 01, 2025')),
 ('%A %d %B %Y', _('Weekday DD Month YYYY (e.g. Friday 06 February 2026)')),
 ('%d %b %Y', _('DD Mon YYYY (e.g. 06 Feb 2026)')),
 ('%d %B, %Y', _('DD Month, YYYY (e.g. 06 February, 2026)')),
 ('%b %d, %Y', _('Mon DD, YYYY (e.g. Feb 06, 2026)')),
 ('%B %d, %Y', _('Month DD, YYYY (e.g. February 06, 2026)'))])
config.plugins.Fury.TimeFormat = ConfigSelection(default='%H:%M', choices=[
 ('%H:%M', _('24h HH:MM (e.g. 21:45)')),
 ('%H:%M:%S', _('24h HH:MM:SS (e.g. 21:45:09)')),
 ('%I:%M %p', _('12h HH:MM AM/PM (e.g. 09:45 PM)')),
 ('%I:%M:%S %p', _('12h HH:MM:SS AM/PM (e.g. 09:45:09 PM)'))])
config.plugins.Fury.ServerStyle = ConfigSelection(default='%S - %PR - CAID: %C - ECM: %T', choices=[
 ('%S - %PR - CAID: %C - ECM: %T', _('Default')),
 ('%R', _('Reader Only')),
 ('%R - CAID: %C - ECM: %T', _('Reader - CAID - ECM')),
 ('%R - %PR - CAID: %C - ECM: %T', _('Reader - Protocol - CAID - ECM')),
 ('%R - CAID: %C - ECM: %T', _('Reader - CAID - ECM')),
 ('%R - CAID: %C', _('Reader - CAID')),
 ('%R - %PR', _('Reader - Protocol')),
 ('%R - %PR - ECM: %T', _('Reader - Protocol - ECM')),
 ('%PR - ECM: %T - CAID: %C', _('Protocol - ECM - CAID')),
 ('%S', _('Server Only')),
 ('%S - %PR - ECM: %T', _('Server - Protocol - ECM')),
 ('%S - CAID: %C - ECM: %T', _('Server - CAID - ECM')),
 ('%S - %PR', _('Server - Protocol')),
 ('CAID: %C - ECM: %T', _('CAID - ECM Only')),
 ('%PR - CAID: %C', _('Protocol - CAID'))])
config.plugins.Fury.InfobarStyle = ConfigSelection(default='infobar_no_posters', choices=[
 ('infobar_no_posters', _('Infobar_NO_Posters')),
 ('infobar_2_posters', _('Infobar_2_Posters')),
 ('infobar_3_posters', _('Infobar_3_Posters')),
 ('infobar_2_logo', _('Infobar_2_Logo')),
 ('infobar_desc', _('Infobar_Desc')),
 ('infobar_star_3_backdrop', _('Infobar_star_3_Backdrop')),
 ('infobar_star_3_posters', _('Infobar_star_3_Posters')),
 ('infobar_mini', _('Infobar_Mini')),
 ('infobar_mini_2', _('Infobar_Mini_2')),
 ('infobar_mini_2_logo', _('Infobar_Mini_2_Logo')),
 ('infobar_mini_desc', _('Infobar_Mini_Desc')),
 ('infobar_round', _('Infobar_Round')),
 ('infobar_round_desc', _('Infobar_Round_Desc')),
 ('infobar_2_round', _('Infobar_2_Round')),
 ('infobar2_no_posters', _('Infobar2_NO_Posters')),
 ('infobar2_desc', _('Infobar2_Desc')),
 ('infobar2_2_posters', _('Infobar2_2_Posters')),
 ('infobar2_2_logo', _('Infobar2_2_Logo')),
 ('infobar2_3_posters', _('Infobar2_3_Posters')),
 ('infobar2_3_backdrop', _('Infobar2_3_Backdrop')),
 ('infobar3_2_posters', _('Infobar3_2_Posters')),
 ('infobar3_2_logo', _('Infobar3_2_Logo')),
 ('infobar3_2_backdrop', _('Infobar3_2_Backdrop')),
 ('infobar3_3_posters', _('Infobar3_3_Posters')),
 ('infobar3_no_posters', _('Infobar3_NO_Posters')),
 ('infobar3_no_posters_black', _('Infobar3_NO_Posters_Black')),
 ('infobar3_2_posters_black', _('Infobar3_2_Posters_Black')),
 ('infobar3_3_posters_black', _('Infobar3_3_Posters_Black')),
 ('infobar3_2_backdrop_black', _('Infobar3_2_Backdrop_Black')),
 ('infobar4_no_posters', _('Infobar4_NO_Posters')),
 ('infobar4_1_posters', _('Infobar4_1_Posters')),
 ('infobar4_desc', _('Infobar4_Desc')),
 ('infobar4_3_posters', _('Infobar4_3_Posters')),
 ('infobar4_backdrop', _('Infobar4_BackDrop')),
 ('infobar4_1_logo', _('Infobar4_1_Logo')),
 ('infobar5_no_posters', _('Infobar5_NO_Posters')),
 ('infobar5_desc', _('Infobar5_Desc')),
 ('infobar5_2_posters', _('Infobar5_2_Posters')),
 ('infobar5_3_posters', _('Infobar5_3_Posters')),
 ('infobar6_no_posters', _('Infobar6_NO_Posters')),
 ('infobar6_2_posters', _('Infobar6_2_Posters')),
 ('infobar6_desc', _('Infobar6_Desc')),
 ('infobar7_slim', _('Infobar7_Slim')),
 ('infobar7_2_posters', _('Infobar7_2_Posters')),
 ('infobar7_desc', _('Infobar7_Desc')),
 ('infobar8_plus', _('Infobar8_Plus')),
 ('infobar8_desc', _('Infobar8_Desc')),
 ('infobar8_2_posters', _('Infobar8_2_Posters'))])
config.plugins.Fury.SecondInfobarStyle = ConfigSelection(default='secondinfobar_no_posters', choices=[
 ('secondinfobar_no_posters', _('SecondInfobar_NO_Posters')),
 ('secondinfobar_posters', _('SecondInfobar_Posters')),
 ('secondinfobar_rating', _('SecondInfobar_Rating')),
 ('secondinfobar2_no_posters', _('SecondInfobar2_NO_Posters')),
 ('secondinfobar2_posters', _('SecondInfobar2_Posters')),
 ('secondinfobar3_no_posters', _('SecondInfobar3_NO_Posters')),
 ('secondinfobar3_posters', _('SecondInfobar3_Posters')),
 ('secondinfobar4_no_posters', _('SecondInfobar4_NO_Posters')),
 ('secondinfobar4_posters', _('SecondInfobar4_Posters')),
 ('secondinfobar5_signal', _('SecondInfobar5_Signal'))])
config.plugins.Fury.ChannSelector = ConfigSelection(default='channellist_no_posters', choices=[
 ('channellist_no_posters', _('ChannelSelection_NO_Posters')),
 ('channellist_5_posters', _('ChannelSelection_5_Posters')),
 ('channellist_5_backdrop', _('ChannelSelection_5_Backdrop')),
 ('channellist2_no_posters', _('ChannelSelection2_NO_Posters')),
 ('channellist2_1_posters', _('ChannelSelection2_1_Posters')),
 ('channellist2_4_posters', _('ChannelSelection2_4_Posters')),
 ('channellist2_6_posters', _('ChannelSelection2_6_Posters')),
 ('channellist2_cenima', _('ChannelSelection2_Cenima')),
 ('channellist2_12_posters', _('ChannelSelection2_12_Posters')),
 ('channellist3_no_posters', _('ChannelSelection3_No_Posters')),
 ('channellist3_5_posters', _('ChannelSelection3_5_Posters')),
 ('channellist4_no_posters', _('ChannelSelection4_No_Posters')),
 ('channellist4_4_posters', _('ChannelSelection4_4_Posters')),
 ('channellist5_no_posters', _('ChannelSelection5_No_Posters')),
 ('channellist5_4_desc', _('ChannelSelection5_4_Desc')),
 ('channellist6_11_yassin7', _('ChannelSelection6_11_Yassin7'))])
config.plugins.Fury.EventView = ConfigSelection(default='eventview_no_posters', choices=[
 ('eventview_no_posters', _('EventView_NO_Posters')),
 ('eventview_7_posters', _('EventView_7_Posters')),
 ('eventview_11_posters', _('EventView_11_Posters')),
 ('eventview_12_posters', _('EventView_12_Posters'))])
config.plugins.Fury.EPGSelection = ConfigSelection(default='epgselection_no_posters', choices=[
 ('epgselection_no_posters', _('EPGSelection_No_Posters')),
 ('epgselection_1_posters', _('EPGSelection_1_Posters'))])
config.plugins.Fury.VolumeBar = ConfigSelection(default='volume', choices=[
 ('volume', _('Default')),
 ('volume2', _('volume2')),
 ('volume3', _('volume3')),
 ('volume4', _('volume4'))])
config.plugins.Fury.ChannForegroundColor = ConfigSelection(default='#ffffff', choices=[
 ('#ffffff', _('Default'))])
config.plugins.Fury.ChannForegroundColorSelected = ConfigSelection(default='white', choices=[
 ('#ffffff', _('Default')),
 ('#e7e412', _('Yellow')),
 ('#FFFAFA', _('LightWhite')),
 ('#ff4a3c', _('Red')),
 ('#22539e', _('Blue')),
 ('#32CD32', _('Green')),
 ('#fcc000', _('Orange')),
 ('#00FFFF', _('Cyan')),
 ('#E799A3', _('Pink'))])
config.plugins.Fury.ChannServiceDescriptionColor = ConfigSelection(default='white', choices=[
 ('#49bbff', _('Default')),
 ('#e7e412', _('Yellow')),
 ('#FFFAFA', _('LightWhite')),
 ('#ff4a3c', _('Red')),
 ('#22539e', _('Blue')),
 ('#32CD32', _('Green')),
 ('#fcc000', _('Orange')),
 ('#00FFFF', _('Cyan')),
 ('#E799A3', _('Pink'))])
config.plugins.Fury.ChannServiceDescriptionColorSelected = ConfigSelection(default='white', choices=[
 ('#a1daff', _('Default')),
 ('#e7e412', _('Yellow')),
 ('#FFFAFA', _('LightWhite')),
 ('#FF4A4A', _('Red')),
 ('#6BA6FF', _('Blue')),
 ('#32CD32', _('Green')),
 ('#FFAE08', _('Orange')),
 ('#00CCCC', _('Cyan')),
 ('#FF8F9C', _('Pink'))])
config.plugins.Fury.ChannBackgroundColorSelected = ConfigSelection(default='#1b3c85', choices=[
 ('#1b3c85', _('Default')),
 ('#151311', _('Black')),
 ('#800000', _('Red')),
 ('#275918', _('Green')),
 ('#43494D', _('Grey')),
 ('#013C66', _('Blue')),
 ('#1b5c53', _('Green2')),
 ('#613f3f', _('Brown')),
 ('#5e1a67', _('DarkPurple')),
 ('#800001', _('DarkRed')),
 ('#151312', _('Orange')),
 ('#793604', _('Oily'))])

# Backup/Restore path (folder where Fury-FHD-Backup will be stored)
config.plugins.Fury.backupPath = ConfigText(default='/media/hdd/', fixed_size=False)

# ------------------- Background install progress -------------------
class FuryBackgroundInstallProgress(Screen):
    """One screen updated in place while postinst installs AIFury."""

    ANIMATION_MS = 40

    def __init__(self, session):
        self.session = session
        self.skin = '''
            <screen name="FuryBackgroundInstallProgress" position="center,center" size="900,360" flags="wfBorder" backgroundColor="background">
                <widget name="stage" position="30,18" size="840,62" font="Regular;34" halign="center" valign="center" transparent="1" foregroundColor="foreground" />
                <widget source="progress" render="Progress" position="50,102" size="800,28" borderWidth="2" foregroundColor="ltbluette" backgroundColor="background" />
                <widget name="percent" position="50,140" size="800,52" font="Regular;34" halign="center" valign="center" transparent="1" foregroundColor="foreground" />
                <widget name="detail" position="35,205" size="830,125" font="Regular;25" halign="center" valign="center" transparent="1" foregroundColor="foreground" />
            </screen>
        '''
        Screen.__init__(self, session)
        try:
            self.setTitle(_('Fury installation progress'))
        except Exception:
            pass

        self['stage'] = Label()
        self['progress'] = Progress()
        self['percent'] = Label('1%')
        self['detail'] = Label()
        self['actions'] = ActionMap(
            ['OkCancelActions', 'SetupActions'],
            {'ok': self.ignoreKey, 'cancel': self.ignoreKey}, -1)

        self.currentPercent = 1
        self.targetPercent = 1
        self['progress'].value = 1
        self.animTimer = eTimer()
        self.animTimer_conn = None
        try:
            self.animTimer.callback.append(self.animateProgress)
        except Exception:
            self.animTimer_conn = self.animTimer.timeout.connect(self.animateProgress)
        self.onClose.append(self.cleanUp)

    def ignoreKey(self):
        # Do not let OK/Exit hide the progress screen while opkg is working.
        return

    def setProgressData(self, stage, percent, detail):
        names = {
            1: _('Finishing Fury-FHD Skin installation'),
            2: _('Downloading AIFury'),
            3: _('Installing AIFury'),
            4: _('Finishing installation')
        }
        try:
            stage = max(1, min(4, int(stage)))
        except Exception:
            stage = 1
        try:
            percent = max(1, min(100, int(percent)))
        except Exception:
            percent = self.currentPercent

        self['stage'].setText('[%d/4] %s' % (stage, names.get(stage, '')))
        self['detail'].setText(str(detail or '').replace('\\n', '\n'))
        self.targetPercent = max(self.currentPercent, percent)
        if self.currentPercent < self.targetPercent:
            self.animTimer.start(self.ANIMATION_MS, False)
        else:
            self._paintPercent()

    def _paintPercent(self):
        self['progress'].value = self.currentPercent
        self['percent'].setText('%d%%' % self.currentPercent)

    def animateProgress(self):
        if self.currentPercent < self.targetPercent:
            self.currentPercent += 1
            self._paintPercent()
        else:
            try:
                self.animTimer.stop()
            except Exception:
                pass

    def cleanUp(self):
        try:
            self.animTimer.stop()
        except Exception:
            pass


class FuryInstallProgressMonitor(object):
    """Watch postinst state and keep a single on-screen progress dialog."""

    def __init__(self, session):
        self.session = session
        self.screen = None
        self.currentRun = ''
        self.lastState = ''
        self.pendingResult = None
        self.finalizing = False

        self.pollTimer = eTimer()
        self.pollTimer_conn = None
        try:
            self.pollTimer.callback.append(self.poll)
        except Exception:
            self.pollTimer_conn = self.pollTimer.timeout.connect(self.poll)

        self.finishTimer = eTimer()
        self.finishTimer_conn = None
        try:
            self.finishTimer.callback.append(self.finishProgress)
        except Exception:
            self.finishTimer_conn = self.finishTimer.timeout.connect(self.finishProgress)

        self.pollTimer.start(350, False)

    def stop(self):
        try:
            self.pollTimer.stop()
            self.finishTimer.stop()
        except Exception:
            pass

    def _remove(self, path):
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass

    def _readState(self):
        try:
            # Ignore a state abandoned by a power cut or very old install.
            if time.time() - os.path.getmtime(INSTALL_PROGRESS_FILE) > 600:
                self._remove(INSTALL_PROGRESS_FILE)
                self._remove(INSTALL_PROGRESS_ACK)
                return None
            with open(INSTALL_PROGRESS_FILE, 'r') as state_file:
                raw = state_file.read(4096).strip()
            parts = raw.split('|', 4)
            if len(parts) != 5:
                return None
            run_id, stage, percent, outcome, detail = parts
            if not run_id or outcome not in ('working', 'success', 'missing', 'failed'):
                return None
            return run_id, int(stage), int(percent), outcome, detail
        except Exception:
            return None

    def _writeAck(self, run_id):
        tmp_path = '%s.%d' % (INSTALL_PROGRESS_ACK, os.getpid())
        try:
            with open(tmp_path, 'w') as ack_file:
                ack_file.write(run_id)
            os.rename(tmp_path, INSTALL_PROGRESS_ACK)
        except Exception:
            self._remove(tmp_path)

    def _removeRunFiles(self, run_id):
        try:
            with open(INSTALL_PROGRESS_FILE, 'r') as state_file:
                owner = state_file.read(128).split('|', 1)[0]
            if owner == run_id:
                self._remove(INSTALL_PROGRESS_FILE)
        except Exception:
            pass
        try:
            with open(INSTALL_PROGRESS_ACK, 'r') as ack_file:
                owner = ack_file.read(128).strip()
            if owner == run_id:
                self._remove(INSTALL_PROGRESS_ACK)
        except Exception:
            pass

    def poll(self):
        state = self._readState()
        if state is None:
            return
        run_id, stage, percent, outcome, detail = state
        signature = '%s|%s|%s|%s|%s' % state

        if run_id != self.currentRun:
            self.currentRun = run_id
            self.lastState = ''
            self.pendingResult = None
            self.finalizing = False

        if self.screen is None:
            try:
                self.screen = self.session.openWithCallback(
                    self.screenClosed, FuryBackgroundInstallProgress)
            except Exception as error:
                print('Fury progress screen error:', str(error))
                self.screen = None
                return

        # Acknowledge only after the real Enigma2 screen exists.  If opening
        # it fails, postinst will keep its OpenWebif fallback instead of
        # suppressing every visible message.
        self._writeAck(run_id)

        if signature == self.lastState:
            return
        self.lastState = signature

        clean_detail = str(detail or '').replace('\\n', '\n')
        self.screen.setProgressData(stage, percent, clean_detail)

        if outcome != 'working' and not self.finalizing:
            self.finalizing = True
            self.pendingResult = (outcome, clean_detail)
            self._removeRunFiles(run_id)
            remaining = max(0, 100 - self.screen.currentPercent)
            # Let the visible counter reach 100, then leave 0.8 s to read it.
            delay = min(6000, max(900, remaining * self.screen.ANIMATION_MS + 800))
            self.finishTimer.start(delay, True)

    def finishProgress(self):
        if self.screen is not None:
            try:
                self.screen.close()
                return
            except Exception:
                self.screen = None
        self.showFinalResult()

    def screenClosed(self, *args):
        self.screen = None
        if self.pendingResult is not None:
            self.showFinalResult()

    def showFinalResult(self):
        result = self.pendingResult
        self.pendingResult = None
        self.finalizing = False
        if result is None:
            return
        outcome, detail = result
        if outcome == 'success':
            message = detail or _('AIFury was installed successfully.\nA GUI restart is required.')
            box_type = MessageBox.TYPE_INFO
            title = _('Installation completed')
        else:
            message = detail or _('AIFury was NOT installed. Check /tmp/fury_install.log')
            box_type = MessageBox.TYPE_ERROR
            title = _('AIFury installation failed')
        try:
            box = self.session.open(MessageBox, message, box_type, timeout=-1)
            box.setTitle(title)
        except Exception as error:
            print('Fury final message error:', str(error))


_furyInstallProgressMonitor = None


def furySessionStart(reason, **kwargs):
    global _furyInstallProgressMonitor
    if reason == 0:
        session = kwargs.get('session')
        if session is not None and _furyInstallProgressMonitor is None:
            _furyInstallProgressMonitor = FuryInstallProgressMonitor(session)
    elif reason == 1 and _furyInstallProgressMonitor is not None:
        _furyInstallProgressMonitor.stop()
        _furyInstallProgressMonitor = None


# ------------------- Plugin Entry -------------------
def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name='Fury v.%s' % version,
            description=_('Fury-FHD Skin Mod AbouYassin7'),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon='plugin.png',
            fnc=main
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=furySessionStart
        )
    ]

def main(session, **kwargs):
    session.open(FurySetup)


# --- Helpers: font scale + header-only transparency ---
def _apply_scale_to_font_xml(xml_text, scale_value):
    import re
    xml_text = re.sub(r'scale="\d+"', f'scale="{scale_value}"', xml_text)
    def _inject_scale(m):
        tag = m.group(0)
        return tag if 'scale=' in tag else tag[:-2] + f' scale="{scale_value}" />'
    xml_text = re.sub(r'<font\s+name="Regular"[^>]*?/>', _inject_scale, xml_text)
    return xml_text

def _apply_transparency_to_header_color(xml_text, alpha_hex):
    import re
    if not re.match(r'^[0-9A-Fa-f]{2}$', (alpha_hex or '')):
        return xml_text
    # ONLY change the header color node
    def _repl(m):
        return f"{m.group(1)}{alpha_hex.upper()}{m.group(2)}{m.group(3)}"
    xml_text = re.sub(
        r'(<color\s+name="header"[^>]*?value="#)[0-9A-Fa-f]{2}([0-9A-Fa-f]{6})(")',
        _repl, xml_text, flags=re.IGNORECASE
    )
    return xml_text

def _apply_date_format_to_clocktotext(xml_text, new_date_fmt):
    import re
    # Most skins write it as: <convert type="ClockToText">Format: %d %B %Y</convert>
    # Some write it without "Format:".
    fmt = str(new_date_fmt)

    # Case 1: with "Format:" prefix (the common one)
    pattern1 = r'(<convert\s+type="ClockToText">\s*Format:\s*)%d\s+%B\s+%Y(\s*</convert>)'
    xml_text2, n1 = re.subn(pattern1, r'\1' + fmt + r'\2', xml_text, flags=re.IGNORECASE)

    # Case 2: without "Format:"
    pattern2 = r'(<convert\s+type="ClockToText">\s*)%d\s+%B\s+%Y(\s*</convert>)'
    xml_text3, n2 = re.subn(pattern2, r'\1' + fmt + r'\2', xml_text2, flags=re.IGNORECASE)

    # Fallback (still safe): replace any ClockToText that contains Format: and the same default tokens
    if (n1 + n2) == 0:
        pattern3 = r'(<convert\s+type="ClockToText">\s*Format:\s*)([^<]*%d[^<]*%B[^<]*%Y[^<]*)(\s*</convert>)'
        xml_text3 = re.sub(pattern3, r'\1' + fmt + r'\3', xml_text3, flags=re.IGNORECASE)

    return xml_text3


def _apply_time_format_to_clocktotext_default(xml_text, new_time_fmt):
    import re
    fmt = str(new_time_fmt)

    # Replace only: <convert type="ClockToText">Default</convert>
    # with:         <convert type="ClockToText">Format: %H:%M</convert>
    pattern = r'(<convert\s+type="ClockToText">\s*)Default(\s*</convert>)'
    xml_text2, _n = re.subn(pattern, r'\1Format: ' + fmt + r'\2', xml_text, flags=re.IGNORECASE)

    return xml_text2


def _apply_server_style_to_furycaid(xml_text, new_server_fmt):
    import re
    fmt = str(new_server_fmt)

    pattern = r'(<convert\s+type="furyCaidInfo2">\s*)(.*?)(\s*</convert>)'
    xml_text = re.sub(
        pattern,
        r'\1' + fmt + r'\3',
        xml_text,
        flags=re.IGNORECASE | re.DOTALL
    )
    return xml_text


class FurySetup(ConfigListScreen, Screen):
    skin = """<screen name="FurySetup" position="center,center" size="1000,640" title="Fury-FHD Plugin">
        <eLabel font="Regular; 24" foregroundColor="#00ff4A3C" halign="center" position="20,598" size="120,26" text="Cancel" />
        <eLabel font="Regular; 24" foregroundColor="#0056C856" halign="center" position="220,598" size="120,26" text="Save" />
        <eLabel font="Regular; 24" foregroundColor="#00ffff00" halign="center" position="420,598" size="140,26" text="Backup" />
        <eLabel font="Regular; 24" foregroundColor="#0000bfff" halign="center" position="620,598" size="140,26" text="Restore" />
        <widget name="Preview" position="997,690" size="498, 280" zPosition="1" />
        <widget name="config" font="Regular; 24" itemHeight="40" position="5,5" scrollbarMode="showOnDemand" size="990,550" />
    </screen>"""

    def __init__(self, session):
        self.version = '.Fury-FHD'
        Screen.__init__(self, session)
        try:
            self.setTitle('Fury-FHD Plugin v.%s' % version)
        except Exception:
            pass
        self.session = session
        self.skinFile = '/usr/share/enigma2/Fury-FHD/skin.xml'
        self.pluginPath = os.path.dirname(os.path.abspath(__file__))
        self.previewFiles = self._getPreviewFiles()
        self['Preview'] = Pixmap()
        list = []
        list.append(getConfigListEntry(_('Skin Resolution:'), config.plugins.Fury.SkinResolution))
        list.append(getConfigListEntry(_('Color Style:'), config.plugins.Fury.colorSelector))
        list.append(getConfigListEntry(_('Skin Style:'), config.plugins.Fury.skinSelector))
        list.append(getConfigListEntry(_('Select Your Font:'), config.plugins.Fury.FontStyle))
        list.append(getConfigListEntry(_('Font Size:'), config.plugins.Fury.FontScale))
        list.append(getConfigListEntry(_('Transparency:'), config.plugins.Fury.transparency))
        list.append(getConfigListEntry(_('Date Format:'), config.plugins.Fury.DateFormat))
        list.append(getConfigListEntry(_('Time Format:'), config.plugins.Fury.TimeFormat))
        list.append(getConfigListEntry(_('Server Style:'), config.plugins.Fury.ServerStyle))
        list.append(getConfigListEntry(_('InfoBar Style:'), config.plugins.Fury.InfobarStyle))
        list.append(getConfigListEntry(_('SecondInfobar Style:'), config.plugins.Fury.SecondInfobarStyle))
        list.append(getConfigListEntry(_('ChannelSelection Style:'), config.plugins.Fury.ChannSelector))
        list.append(getConfigListEntry(_('EventView Style:'), config.plugins.Fury.EventView))
        list.append(getConfigListEntry(_('EPGSelection Style:'), config.plugins.Fury.EPGSelection))
        list.append(getConfigListEntry(_('VolumeBar Style:'), config.plugins.Fury.VolumeBar))
        list.append(getConfigListEntry(_('Channel Foreground Color:'), config.plugins.Fury.ChannForegroundColor))
        list.append(getConfigListEntry(_('Channel Selected Foreground Color:'), config.plugins.Fury.ChannForegroundColorSelected))
        list.append(getConfigListEntry(_('Channel Description Color:'), config.plugins.Fury.ChannServiceDescriptionColor))
        list.append(getConfigListEntry(_('Channel Selected Description Color:'), config.plugins.Fury.ChannServiceDescriptionColorSelected))
        list.append(getConfigListEntry(_('Channel Background Selected Color:'), config.plugins.Fury.ChannBackgroundColorSelected))


        ConfigListScreen.__init__(self, list)
        self['actions'] = ActionMap(
            ['OkCancelActions','DirectionActions','InputActions','ColorActions','NumberActions'], 
            {'left': self.keyLeft,
            'down': self.keyDown,
            'up': self.keyUp,
            'right': self.keyRight,
            'red': self.keyExit,
            'green': self.keySave,
            'yellow': self.checkforUpdate,
            'blue': self.info,
            '1': self.doBackup,
            '2': self.doRestore,
            'cancel': self.keyExit}, -1)
        self.onLayoutFinish.append(self.UpdateComponents)
        self.PicLoad = ePicLoad()
        self.Scale = AVSwitch().getFramebufferScale()
        try:
            self.PicLoad.PictureData.get().append(self.DecodePicture)
        except:
            self.PicLoad_conn = self.PicLoad.PictureData.connect(self.DecodePicture)

    def _getPreviewFiles(self):
        """Return the FHD or 2K XML source folder selected by Skin Resolution."""
        # 'default' is kept only as a migration alias for settings/backups from v8.5.
        folder_map = {'default': 'sample-fhd', 'fhd': 'sample-fhd', '2k': 'sample-2k'}
        folder = folder_map.get(config.plugins.Fury.SkinResolution.value, 'sample-fhd')
        selected = os.path.join(self.pluginPath, folder)
        # FHD is the permanent safe default; the old plain sample folder was removed.
        if not os.path.isdir(selected):
            selected = os.path.join(self.pluginPath, 'sample-fhd')
        return selected.rstrip('/') + '/'

    def modify_channel_colors(self, content):
       fg_color = config.plugins.Fury.ChannForegroundColor.value
       fg_selected_color = config.plugins.Fury.ChannForegroundColorSelected.value
       desc_color = config.plugins.Fury.ChannServiceDescriptionColor.value
       desc_selected_color = config.plugins.Fury.ChannServiceDescriptionColorSelected.value
       bg_selected_color = config.plugins.Fury.ChannBackgroundColorSelected.value

       content = content.replace('foregroundColor="white"', f'foregroundColor="{fg_color}"')
       content = content.replace('foregroundColorSelected="#ffffff"', f'foregroundColorSelected="{fg_selected_color}"')
       content = content.replace('colorServiceDescription="#49bbff"', f'colorServiceDescription="{desc_color}"')
       content = content.replace('colorServiceDescriptionSelected="#a1daff"', f'colorServiceDescriptionSelected="{desc_selected_color}"')
       content = content.replace('backgroundColorSelected="bluette"', f'backgroundColorSelected="{bg_selected_color}"')
       
       return content

    def _applySkinFromConfig(self):
        """Rebuild the final skin.xml from current config values."""
        if not fileExists(self.skinFile + self.version):
            return False
        try:
            self.previewFiles = self._getPreviewFiles()

            skin_lines = []
            head_file = self.previewFiles + 'head-' + config.plugins.Fury.colorSelector.value + '.xml'
            with open(head_file, 'r') as skFile:
                _head = skFile.read()
            _head = _apply_transparency_to_header_color(_head, config.plugins.Fury.transparency.value)
            skin_lines.append(_head)
            font_file = self.previewFiles + 'font-' + config.plugins.Fury.FontStyle.value + '.xml'
            with open(font_file, 'r') as skFile:
                _font = skFile.read()
            _font = _apply_scale_to_font_xml(_font, config.plugins.Fury.FontScale.value)
            skin_lines.append(_font)
            skn_file = self.previewFiles + 'infobar-' + config.plugins.Fury.InfobarStyle.value + '.xml'
            with open(skn_file, 'r') as skFile:
                skin_lines.extend(skFile.readlines())
            skn_file = self.previewFiles + 'secondinfobar-' + config.plugins.Fury.SecondInfobarStyle.value + '.xml'
            with open(skn_file, 'r') as skFile:
                skin_lines.extend(skFile.readlines())
            # هنا تعديل القنوات
            skn_file = self.previewFiles + 'channellist-' + config.plugins.Fury.ChannSelector.value + '.xml'
            with open(skn_file, 'r') as f:
                channellist_content = f.read()
            channellist_content = self.modify_channel_colors(channellist_content)
            skin_lines.append(channellist_content)
            # باقي الملفات
            skn_file = self.previewFiles + 'eventview-' + config.plugins.Fury.EventView.value + '.xml'
            with open(skn_file, 'r') as skFile:
                skin_lines.extend(skFile.readlines())
            skn_file = self.previewFiles + 'epgselection-' + config.plugins.Fury.EPGSelection.value + '.xml'
            with open(skn_file, 'r') as skFile:
                skin_lines.extend(skFile.readlines())
            skn_file = self.previewFiles + 'vol-' + config.plugins.Fury.VolumeBar.value + '.xml'
            with open(skn_file, 'r') as skFile:
                skin_lines.extend(skFile.readlines())
            base_file = self.previewFiles + 'base.xml'
            if config.plugins.Fury.skinSelector.value == 'base1':
                base_file = self.previewFiles + 'base1.xml'
            if config.plugins.Fury.skinSelector.value == 'base':
                base_file = self.previewFiles + 'base.xml'
            with open(base_file, 'r') as skFile:
                skin_lines.extend(skFile.readlines())
            xml_all = ''.join(skin_lines)
            xml_all = _apply_date_format_to_clocktotext(xml_all, config.plugins.Fury.DateFormat.value)
            xml_all = _apply_time_format_to_clocktotext_default(xml_all, config.plugins.Fury.TimeFormat.value)
            xml_all = _apply_server_style_to_furycaid(xml_all, config.plugins.Fury.ServerStyle.value)
            with open(self.skinFile, 'w') as xFile:
                xFile.write(xml_all)
        except Exception as e:
            try:
                self.session.open(MessageBox, _('Error by processing the skin file !!!\n%s') % str(e), MessageBox.TYPE_ERROR)
            except Exception:
                pass
            return False
        return True


    def keySave(self):
        if not fileExists(self.skinFile + self.version):
            for x in self['config'].list:
                x[1].cancel()
            self.close()
            return
        for x in self['config'].list:
            x[1].save()
        self._applySkinFromConfig()
        restartbox = self.session.openWithCallback(
            self.restartGUI, MessageBox,
            _('GUI needs a restart to apply a new skin.\nDo you want to Restart the GUI now?'),
            MessageBox.TYPE_YESNO)
        restartbox.setTitle(_('Restart GUI now?'))


    # ------------------- Backup / Restore -------------------
    def _backup_file(self):
        base = (config.plugins.Fury.backupPath.value or '').strip()
        if not base:
            base = '/tmp/'
        # ensure it's a folder path
        if not base.endswith('/'):
            base += '/'
        return os.path.join(base, 'Fury-FHD-Backup.json')

    def doBackup(self):
        try:
            bfile = self._backup_file()
            bdir = os.path.dirname(bfile)
            if bdir and not os.path.exists(bdir):
                os.makedirs(bdir)
            data = {}
            keys = [
                'SkinResolution','skinSelector','colorSelector','FontStyle','FontScale','transparency',
                'DateFormat','TimeFormat','ServerStyle','InfobarStyle','SecondInfobarStyle','ChannSelector',
                'EventView','EPGSelection','VolumeBar',
                'ChannForegroundColor','ChannForegroundColorSelected',
                'ChannServiceDescriptionColor','ChannServiceDescriptionColorSelected',
                'ChannBackgroundColorSelected'
            ]
            for k in keys:
                try:
                    data[k] = getattr(config.plugins.Fury, k).value
                except Exception:
                    pass
            # also store the chosen backup folder (optional)
            data['backupPath'] = config.plugins.Fury.backupPath.value
            with open(bfile, 'w') as f:
                json.dump(data, f, indent=2, sort_keys=True)
            self.session.open(MessageBox, _('Backup saved as:\n%s') % bfile, MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, _('Backup failed!\n%s') % str(e), MessageBox.TYPE_ERROR)

    def doRestore(self):
        try:
            bfile = self._backup_file()
            if not os.path.exists(bfile):
                self.session.open(MessageBox, _('Backup file not found:\n%s') % bfile, MessageBox.TYPE_ERROR)
                return
            with open(bfile, 'r') as f:
                data = json.load(f)
            for k, v in data.items():
                if hasattr(config.plugins.Fury, k):
                    try:
                        getattr(config.plugins.Fury, k).value = v
                    except Exception:
                        pass
            # Backups from older versions may contain the removed 'default' choice.
            try:
                if config.plugins.Fury.SkinResolution.value not in ('fhd', '2k'):
                    config.plugins.Fury.SkinResolution.value = 'fhd'
            except Exception:
                pass
            # refresh config list + save
            for x in self['config'].list:
                try:
                    x[1].save()
                except Exception:
                    pass
            configfile.save()
            # rebuild skin file from restored settings
            self._applySkinFromConfig()
            # update preview immediately (where possible)
            self.ShowPicture()
            restartbox = self.session.openWithCallback(
                self.restartGUI, MessageBox,
                _('Settings restored from backup.\nGUI needs a restart to apply.\nRestart GUI now?'),
                MessageBox.TYPE_YESNO)
            restartbox.setTitle(_('Restart GUI now?'))
        except Exception as e:
            self.session.open(MessageBox, _('Restore failed!\n%s') % str(e), MessageBox.TYPE_ERROR)

    def GetPicturePath(self):
        try:
            returnValue = self['config'].getCurrent()[1].value
            path = '/usr/lib/enigma2/python/Plugins/Extensions/Fury/screens/' + returnValue + '.png'
            if fileExists(path):
                return path
            else:
                return '/usr/lib/enigma2/python/Plugins/Extensions/Fury/screens/default.png'
        except:
            return '/usr/lib/enigma2/python/Plugins/Extensions/Fury/screens/default.png'

    def UpdatePicture(self):
        self.PicLoad.PictureData.get().append(self.DecodePicture)
        self.onLayoutFinish.append(self.ShowPicture)

    def ShowPicture(self, data=None):
        if self["Preview"].instance:
            width = 450
            height = 250
            self.PicLoad.setPara([width, height, self.Scale[0], self.Scale[1], 0, 1, "ff000000"])
            if self.PicLoad.startDecode(self.GetPicturePath()):
                self.PicLoad = ePicLoad()
                try:
                    self.PicLoad.PictureData.get().append(self.DecodePicture)
                except:
                    self.PicLoad_conn = self.PicLoad.PictureData.connect(self.DecodePicture)

    def DecodePicture(self, PicInfo=None):
        ptr = self.PicLoad.getData()
        if ptr is not None:
            self["Preview"].instance.setPixmap(ptr)
            self["Preview"].instance
            self["Preview"].instance.show()
        return

    def UpdateComponents(self):
        self.UpdatePicture()

    def info(self):
        aboutbox = self.session.open(MessageBox, _('Setup Fury for Fury-FHD v.%s') % version, MessageBox.TYPE_INFO)
        aboutbox.setTitle(_('Info...'))

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.ShowPicture()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.ShowPicture()

    def keyDown(self):
        self['config'].instance.moveSelection(self['config'].instance.moveDown)
        self.ShowPicture()

    def keyUp(self):
        self['config'].instance.moveSelection(self['config'].instance.moveUp)
        self.ShowPicture()

    def restartGUI(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    def checkforUpdate(self):
        try:
            fp = ''
            destr = '/tmp/furyversion.txt'
            req = Request('https://raw.githubusercontent.com/islam-2412/IPKS/main/fury/furyversion.txt')
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
            fp = urlopen(req)
            fp = fp.read().decode('utf-8')
            print('fp read:', fp)
            with open(destr, 'w') as f:
                f.write(str(fp))
                f.seek(0)
                f.close()
            if os.path.exists(destr):
                with open(destr, 'r') as cc:
                    s1 = cc.readline()
                    vers = s1.split('#')[0]
                    url = s1.split('#')[1]
                    version_server = vers.strip()
                    self.updateurl = url.strip()
                    cc.close()
                    if _ver_tuple(version_server) == _ver_tuple(version):
                        message = '%s %s\n%s %s\n\n%s' % (_('Server version:'),
                         version_server,
                         _('Version installed:'),
                         version,
                         _('You have the current version Fury!'))
                        self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
                    elif _ver_tuple(version_server) > _ver_tuple(version):
                        message = '%s %s\n%s %s\n\n%s' % (_('Server version:'),
                         version_server,
                         _('Version installed:'),
                         version,
                         _('The update is available!\n\nDo you want to run the update now?'))
                        self.session.openWithCallback(self.update, MessageBox, message, MessageBox.TYPE_YESNO)
                    else:
                        self.session.open(MessageBox, _('You have version %s!!!') % version, MessageBox.TYPE_ERROR)
        except Exception as e:
            print('error: ', str(e))

    def update(self, answer):
        if answer is True:
            self.session.open(FuryUpdater, self.updateurl)
        else:
            return

    def keyExit(self):
        for x in self['config'].list:
            x[1].cancel()
        self.close()


class FuryUpdater(Screen):
    # 1 = download skin, 2 = install skin, 3 = download AIFury, 4 = install AIFury
    STEPS = 4

    def __init__(self, session, updateurl):
        self.session = session
        skin = '''
                <screen name="FuryUpdater" position="center,center" size="900,350" flags="wfBorder" backgroundColor="background">
                    <widget name="status" position="20,10" size="860,60" transparent="1" font="Regular; 34" foregroundColor="foreground" backgroundColor="background" valign="center" halign="center" noWrap="1" zPosition="1" />
                    <widget name="percent" position="20,72" size="860,38" transparent="1" font="Regular; 28" foregroundColor="foreground" backgroundColor="background" valign="center" halign="center" zPosition="1" />
                    <widget source="progress" render="Progress" position="20,118" size="860,24" transparent="1" borderWidth="1" foregroundColor="ltbluette" backgroundColor="background" />
                    <widget source="progresstext" render="Label" position="20,155" zPosition="2" font="Regular; 24" halign="center" valign="center" transparent="1" size="860,170" foregroundColor="foreground" backgroundColor="background" />
                    <ePixmap position="62,20" size="90,40" pixmap="buttons/F-30.png" alphatest="blend" zPosition="4" />
                </screen>                
                '''
        self.skin = skin
        Screen.__init__(self, session)
        try:
            self.setTitle('Fury Updater v.%s' % version)
        except Exception:
            pass

        self.updateurl = updateurl
        print('self.updateurl', self.updateurl)

        self['status'] = Label()
        self['progress'] = Progress()
        self['percent'] = Label('1%')
        self['progresstext'] = StaticText()
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {'cancel': self.keyCancel}, -1)

        self.dlfile = '/tmp/fury.ipk'
        # Never share /tmp/aifury.ipk with a postinst from an older Fury build.
        # A unique file prevents a second installer from truncating/deleting the
        # package while opkg is reading it.
        self.aifile = '/tmp/fury_internal_aifury_%d.ipk' % os.getpid()
        self.aicheckfile = '/tmp/fury_internal_aifury_check_%d.json' % os.getpid()
        self.aibranchfile = '/tmp/fury_internal_aifury_main_%d.json' % os.getpid()
        self.pending_aifury_url = ''
        self.aifury_main_sha = ''

        self.download = None
        self.container = None
        self.container_conn = None
        self.cmd_callback = None

        self.busy = False
        self.aborted = False
        self.last_recvbytes = 0

        self.skin_ok = False
        self.aifury_ok = False
        self.aifury_msg = _('AIFury: skipped')
        self.aifury_urls = []
        self.aifury_index = 0
        self.aifury_errors = []
        self.aifury_required_name = ''
        self.opkg_wait_count = 0
        self.pyver = '%d.%d' % (sys.version_info[0], sys.version_info[1])
        self.arch = ''
        self.currentStep = 1
        self.currentPercent = 1
        self['progress'].value = 1

        # progress pulse (used while opkg is installing, no real % available)
        self.pulseValue = 0
        self.pulseTimer = eTimer()
        self.pulseTimer_conn = None
        try:
            self.pulseTimer.callback.append(self.doPulse)
        except Exception:
            self.pulseTimer_conn = self.pulseTimer.timeout.connect(self.doPulse)

        # small delay between the stages, so the user can read what is going on
        self.nextStep = None
        self.stepTimer = eTimer()
        self.stepTimer_conn = None
        try:
            self.stepTimer.callback.append(self.runNextStep)
        except Exception:
            self.stepTimer_conn = self.stepTimer.timeout.connect(self.runNextStep)

        self.onClose.append(self.cleanUp)
        self.onLayoutFinish.append(self.startUpdate)

    # ------------------- helpers -------------------

    def setStage(self, step, text):
        self.currentStep = max(1, min(self.STEPS, int(step)))
        self['status'].setText('(%d/%d) %s' % (step, self.STEPS, text))
        stage_min = {1: 1, 2: 26, 3: 51, 4: 76}.get(self.currentStep, 1)
        if self.currentPercent < stage_min:
            self.setProgress(stage_min)

    def setProgress(self, value):
        try:
            value = max(1, min(100, int(value)))
        except Exception:
            value = 1
        self.currentPercent = value
        self['progress'].value = value
        self['percent'].setText('%d%%' % value)

    def progressForDownload(self, download_percent):
        bounds = {1: (1, 25), 3: (51, 75)}
        low, high = bounds.get(self.currentStep, (1, 100))
        try:
            ratio = max(0.0, min(100.0, float(download_percent))) / 100.0
        except Exception:
            ratio = 0.0
        return int(low + ((high - low) * ratio))

    def setInfo(self, text):
        self['progresstext'].text = text

    def later(self, func, ms=1200):
        self.nextStep = func
        self.stepTimer.start(ms, True)

    def runNextStep(self):
        func = self.nextStep
        self.nextStep = None
        if func and not self.aborted:
            func()

    def startPulse(self):
        self.pulseValue = self.currentPercent
        self.pulseTimer.start(100, False)

    def doPulse(self):
        stage_max = {2: 50, 4: 99}.get(self.currentStep, 99)
        if self.pulseValue < stage_max:
            self.pulseValue += 1
            self.setProgress(self.pulseValue)
        else:
            try:
                self.pulseTimer.stop()
            except Exception:
                pass

    def stopPulse(self):
        try:
            self.pulseTimer.stop()
        except Exception:
            pass

    def isValidIpk(self, path):
        # github raw answers with a small html/text page ("404: Not Found")
        # when the package does not exist, so check size + magic bytes
        try:
            if not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, 'rb') as f:
                head = f.read(8)
            return head.startswith(b'!<arch>') or head.startswith(b'\x1f\x8b')
        except Exception:
            return False

    def detectArch(self):
        # the package arch of the running image is more reliable than uname,
        # some aarch64 kernels run a 32bit (arm) userland
        text = ''
        try:
            with open('/etc/opkg/arch.conf', 'r') as f:
                text = f.read().lower()
        except Exception:
            pass
        if 'aarch64' in text:
            return 'aarch64'
        if 'mips' in text:
            return 'mipsel'
        if 'arm' in text or 'cortex' in text:
            return 'arm'
        try:
            machine = os.uname()[4].lower()
        except Exception:
            machine = ''
        if 'aarch64' in machine:
            return 'aarch64'
        if 'mips' in machine:
            return 'mipsel'
        if 'arm' in machine:
            return 'arm'
        return 'arm'

    def buildAiFuryUrls(self):
        self.arch = self.detectArch()
        vers = [self.pyver]
        if AIFURY_TRY_FALLBACK_PY:
            for v in AIFURY_FALLBACK_PY:
                if v not in vers:
                    vers.append(v)
        # A unique query plus no reused local filename prevents a recently
        # deleted GitHub raw file from being accepted from an old CDN cache.
        cache_key = '%d_%d' % (int(time.time()), os.getpid())
        return [(AIFURY_BASE_URL % (v, self.arch)) + '?nocache=' + cache_key for v in vers]

    def aiUrlName(self, url):
        try:
            return os.path.basename(url.split('?', 1)[0])
        except Exception:
            return 'aifury_py%s_%s.ipk' % (self.pyver, self.arch)

    def cleanAiDownloadReason(self, error_message):
        try:
            reason = str(error_message or '').replace('\r', ' ').replace('\n', ' ').strip()
        except Exception:
            reason = ''
        low = reason.lower()
        if '404' in low or 'not found' in low:
            return _('HTTP 404: file not found on Server')
        if 'timed out' in low or 'timeout' in low:
            return _('Network timeout while contacting Server')
        if 'dns' in low or 'resolve' in low or 'name or service' in low:
            return _('Network/DNS error while contacting Server')
        if reason:
            return reason[:140]
        return _('Download failed: file missing or network/SSL error')

    def missingAiFuryMessage(self):
        required = self.aifury_required_name or ('aifury_py%s_%s.ipk' % (self.pyver, self.arch))
        reason = self.aifury_errors[-1] if self.aifury_errors else _('The exact package was not found on Server')
        message = '%s\n%s %s\n%s %s' % (
            _('AIFury was NOT installed.'),
            _('Required file:'), required,
            _('Reason:'), reason)
        if self.aifuryInstalled():
            message += '\n' + _('The old installed copy was kept; it was not downloaded now.')
        return message

    def aifuryInstalled(self):
        base = '/usr/lib/enigma2/python/Plugins/Extensions'
        try:
            for d in os.listdir(base):
                low = d.lower()
                if low.startswith('aifury') or low.startswith('furyepg'):
                    return True
        except Exception:
            pass
        return False

    def releaseAiFuryLock(self):
        try:
            if os.path.exists(AIFURY_LOCK):
                os.remove(AIFURY_LOCK)
        except Exception:
            pass

    def opkgBusy(self):
        """Return True while another opkg/opkg-cl process is still alive."""
        try:
            for pid in os.listdir('/proc'):
                if not pid.isdigit():
                    continue
                try:
                    with open('/proc/%s/comm' % pid, 'r') as f:
                        name = f.read().strip().lower()
                    if name in ('opkg', 'opkg-cl'):
                        return True
                except Exception:
                    pass
        except Exception:
            pass
        return False

    def startDownload(self, url, target, okcb, errcb):
        self.busy = True
        try:
            if os.path.exists(target):
                os.remove(target)
        except Exception:
            pass
        try:
            self.download = downloadWithProgress(url, target)
            self.download.addProgress(self.downloadProgress)
            self.download.start().addCallback(okcb).addErrback(errcb)
        except Exception as e:
            print('download error:', str(e))
            self.busy = False
            errcb(None, str(e))

    def downloadProgress(self, recvbytes, totalbytes):
        try:
            if totalbytes and totalbytes > 0:
                pct = 100 * recvbytes / float(totalbytes)
                self.setProgress(self.progressForDownload(pct))
                self.setInfo('%d / %d kB   (%.1f%%)' % (recvbytes / 1024, totalbytes / 1024, pct))
            else:
                self.setInfo('%d kB' % (recvbytes / 1024))
        except Exception:
            pass
        self.last_recvbytes = recvbytes

    def execCmd(self, cmd, callback):
        self.busy = True
        self.cmd_callback = callback
        self.container = eConsoleAppContainer()
        try:
            self.container.appClosed.append(self.cmdFinished)
        except Exception:
            self.container_conn = self.container.appClosed.connect(self.cmdFinished)
        print('exec:', cmd)
        if self.container.execute(cmd):
            self.cmdFinished(-1)

    def cmdFinished(self, retval):
        self.busy = False
        callback = self.cmd_callback
        self.cmd_callback = None
        if callback and not self.aborted:
            callback(retval)

    # ------------------- step 1: download the skin -------------------

    def startUpdate(self):
        self.setStage(1, _('Downloading Fury...'))
        self.setProgress(1)
        self.setInfo('')
        self.startDownload(self.updateurl, self.dlfile, self.downloadFinished, self.downloadFailed)

    def downloadFinished(self, string=''):
        self.download = None
        if self.aborted:
            return
        if not self.isValidIpk(self.dlfile):
            self.setStage(1, _('Downloaded file is not valid!'))
            self.setInfo(_('Please try again later.'))
            return
        self.setInfo(_('Download finished'))
        self.later(self.installSkin, 500)

    def downloadFailed(self, failure_instance=None, error_message=''):
        self.download = None
        if self.aborted:
            return
        if error_message == '' and failure_instance is not None:
            try:
                error_message = failure_instance.getErrorMessage()
            except Exception:
                error_message = ''
        self['status'].setText(_('Error downloading files!'))
        self.setInfo(error_message)

    # ------------------- step 2: install the skin -------------------

    def installSkin(self):
        self.setStage(2, _('Installing Skin... Please wait!'))
        self.setInfo(_('Please wait...'))
        self.startPulse()
        # tell the postinst of the skin package that AIFury is handled here,
        # so it is not downloaded/installed twice
        try:
            open(AIFURY_LOCK, 'w').write('1')
        except Exception:
            pass
        cmd = 'echo "== Fury %s ==" > %s; opkg install --force-reinstall --force-overwrite %s >> %s 2>&1; sync' % (
            version, UPDATE_LOG, self.dlfile, UPDATE_LOG)
        self.execCmd(cmd, self.skinInstallFinished)

    def skinInstallFinished(self, retval):
        self.stopPulse()
        self.setProgress(50)
        self.skin_ok = (retval == 0)
        # Keep AIFURY_LOCK until the whole internal update is finished.  The
        # newly installed skin postinst must not launch a competing AIFury job.
        try:
            if os.path.exists(self.dlfile):
                os.remove(self.dlfile)
        except Exception:
            pass
        if self.skin_ok:
            self.setStage(3, _('Starting AIFury immediately...'))
            self.setInfo(_('Skin installed successfully. Preparing the exact AIFury package now...'))
        else:
            self.setStage(3, _('Checking AIFury...'))
            self.setInfo(_('Skin installation reported an error. Checking AIFury now...'))
        # Do not leave a quiet gap after the skin stage: keep the user informed
        # and start AIFury on the next short GUI tick.
        self.later(self.prepareAiFury, 80)

    # ------------------- step 3: download AIFury -------------------

    def prepareAiFury(self):
        self.aifury_urls = self.buildAiFuryUrls()
        self.aifury_index = 0
        self.aifury_errors = []
        self.aifury_required_name = 'aifury_py%s_%s.ipk' % (self.pyver, self.arch)
        if not self.aifury_urls:
            self.aifury_ok = False
            self.aifury_errors.append(_('No download URL could be created'))
            self.aifury_msg = self.missingAiFuryMessage()
            self.setStage(3, _('AIFury not available'))
            self.setInfo(self.aifury_msg)
            self.later(self.finishAll, 1800)
            return
        self.setStage(3, _('Downloading AIFury now...'))
        self.setInfo('%s\n%s %s' % (
            _('Skin finished. AIFury installation is still running.'),
            _('Required file:'), self.aifury_required_name))
        self.later(self.downloadAiFury, 80)

    def downloadAiFury(self):
        if self.aifury_index >= len(self.aifury_urls):
            self.aifury_ok = False
            self.aifury_msg = self.missingAiFuryMessage()
            self.setStage(3, _('AIFury not available'))
            self.setInfo(self.aifury_msg)
            self.later(self.finishAll, 2200)
            return

        url = self.aifury_urls[self.aifury_index]
        self.pending_aifury_url = url
        self.aifury_required_name = self.aiUrlName(url)
        self.aifury_main_sha = ''
        self.setStage(3, _('Downloading AIFury...'))
        self.setInfo('%s\n%s %s' % (
            _('Please wait; the full installation has not finished.'),
            _('Required file:'), self.aifury_required_name))

        # Resolve the CURRENT main HEAD first.  We never trust raw/.../main
        # directly because an old CDN object may survive after a deletion.
        # The package must exist in exactly this main commit or it is rejected.
        cache_key = '%d_%d' % (int(time.time()), os.getpid())
        ref_url = '%s?nocache=%s' % (AIFURY_REF_API, cache_key)
        self.startDownload(ref_url, self.aibranchfile,
                           self.aiMainRefFinished, self.aiMainRefFailed)

    def _advanceAiFuryFailure(self, reason):
        self.aifury_errors.append(reason)
        self.aifury_index += 1
        self.pending_aifury_url = ''
        self.aifury_main_sha = ''
        self.setInfo('%s\n%s %s' % (
            _('AIFury download failed.'),
            _('Reason:'), reason))
        self.later(self.downloadAiFury, 250)

    def aiMainRefFinished(self, string=''):
        self.download = None
        if self.aborted:
            return
        sha = ''
        try:
            with open(self.aibranchfile, 'r') as f:
                data = json.load(f)
            sha = str(data.get('object', {}).get('sha', '') or '').strip().lower()
        except Exception:
            sha = ''
        try:
            if os.path.exists(self.aibranchfile):
                os.remove(self.aibranchfile)
        except Exception:
            pass

        if not re.match(r'^[0-9a-f]{40}$', sha):
            self._advanceAiFuryFailure(
                _('GitHub did not return a valid current main commit SHA'))
            return

        self.aifury_main_sha = sha
        cache_key = '%d_%d' % (int(time.time()), os.getpid())
        # Check the package against the exact current main commit, not a branch
        # name and not a historical commit.
        check_url = '%s/%s?ref=%s&nocache=%s' % (
            AIFURY_API_BASE, self.aifury_required_name, sha, cache_key)
        self.startDownload(check_url, self.aicheckfile,
                           self.aiRepositoryCheckFinished, self.aiRepositoryCheckFailed)

    def aiMainRefFailed(self, failure_instance=None, error_message=''):
        self.download = None
        if self.aborted:
            return
        try:
            if os.path.exists(self.aibranchfile):
                os.remove(self.aibranchfile)
        except Exception:
            pass
        if error_message == '' and failure_instance is not None:
            try:
                error_message = failure_instance.getErrorMessage()
            except Exception:
                error_message = ''
        reason = self.cleanAiDownloadReason(error_message)
        self._advanceAiFuryFailure(
            _('Could not resolve the current Server main commit: %s') % reason)

    def aiRepositoryCheckFinished(self, string=''):
        self.download = None
        if self.aborted:
            return

        valid_current_file = False
        blob_sha = ''
        try:
            with open(self.aicheckfile, 'r') as f:
                data = json.load(f)
            api_name = str(data.get('name', '') or '')
            api_type = str(data.get('type', '') or '')
            blob_sha = str(data.get('sha', '') or '').strip().lower()
            valid_current_file = (
                api_name == self.aifury_required_name and
                api_type == 'file' and
                re.match(r'^[0-9a-f]{40}$', blob_sha) is not None
            )
        except Exception:
            valid_current_file = False
        try:
            if os.path.exists(self.aicheckfile):
                os.remove(self.aicheckfile)
        except Exception:
            pass

        if not valid_current_file or not re.match(r'^[0-9a-f]{40}$', self.aifury_main_sha or ''):
            self._advanceAiFuryFailure(
                _('The exact AIFury package is not present in the current main commit'))
            return

        # IMPORTANT: download from the exact CURRENT main commit SHA.
        # Never download from raw/.../main and never use a historical SHA
        # returned by an old package URL.
        cache_key = '%d_%d' % (int(time.time()), os.getpid())
        pinned_url = '%s/%s/fury/AIFury/%s?nocache=%s' % (
            AIFURY_RAW_REPO, self.aifury_main_sha,
            self.aifury_required_name, cache_key)
        print('AIFury current main SHA:', self.aifury_main_sha,
              'blob:', blob_sha, 'file:', self.aifury_required_name)
        self.startDownload(pinned_url, self.aifile,
                           self.aiDownloadFinished, self.aiDownloadFailed)

    def aiRepositoryCheckFailed(self, failure_instance=None, error_message=''):
        self.download = None
        if self.aborted:
            return
        try:
            if os.path.exists(self.aicheckfile):
                os.remove(self.aicheckfile)
        except Exception:
            pass
        if error_message == '' and failure_instance is not None:
            try:
                error_message = failure_instance.getErrorMessage()
            except Exception:
                error_message = ''
        reason = self.cleanAiDownloadReason(error_message)
        # A 404 here means the file does NOT exist in the exact current main
        # commit.  Do not fall back to raw/main or any older commit.
        if '404' in str(reason) or 'not found' in str(reason).lower():
            reason = _('File not found in the current Server main commit')
        self._advanceAiFuryFailure(reason)

    def aiDownloadFinished(self, string=''):
        self.download = None
        if self.aborted:
            return
        if not self.isValidIpk(self.aifile):
            self.aifury_errors.append(_('GitHub response is not a valid or complete IPK file'))
            self.aifury_index += 1
            self.setInfo('%s\n%s' % (
                _('AIFury package is missing or invalid.'),
                self.aifury_errors[-1]))
            self.later(self.downloadAiFury, 250)
            return
        self.setInfo(_('Download finished'))
        self.setProgress(75)
        self.later(self.installAiFury, 120)

    def aiDownloadFailed(self, failure_instance=None, error_message=''):
        self.download = None
        if self.aborted:
            return
        if error_message == '' and failure_instance is not None:
            try:
                error_message = failure_instance.getErrorMessage()
            except Exception:
                error_message = ''
        print('aifury download failed:', error_message)
        reason = self.cleanAiDownloadReason(error_message)
        self.aifury_errors.append(reason)
        self.aifury_index += 1
        self.setInfo('%s\n%s %s' % (
            _('AIFury download failed.'),
            _('Reason:'), reason))
        self.later(self.downloadAiFury, 250)

    # ------------------- step 4: install AIFury -------------------

    def installAiFury(self):
        if not self.isValidIpk(self.aifile):
            self.aifury_ok = False
            self.aifury_msg = _('AIFury: downloaded package is incomplete')
            self.setStage(4, _('AIFury installation failed'))
            self.setInfo(self.aifury_msg)
            self.later(self.finishAll, 1200)
            return

        # A legacy postinst may still be finishing another package operation.
        # Wait without blocking the Enigma2 GUI instead of starting two opkg
        # processes at the same time.
        if self.opkgBusy():
            self.opkg_wait_count += 1
            if self.opkg_wait_count <= 120:
                self.setStage(4, _('Waiting for package manager...'))
                self.setInfo(_('AIFury is ready. Please wait...'))
                self.later(self.installAiFury, 1000)
                return
            self.aifury_ok = False
            self.aifury_msg = _('AIFury: package manager stayed busy')
            self.setStage(4, _('AIFury installation failed'))
            self.setInfo(self.aifury_msg)
            self.later(self.finishAll, 1200)
            return

        self.opkg_wait_count = 0
        self.setStage(4, _('Installing AIFury... Please wait!'))
        self.setInfo(_('Please wait...'))
        self.startPulse()
        cmd = 'test -s %s && opkg install --force-reinstall --force-overwrite %s >> %s 2>&1; sync' % (
            self.aifile, self.aifile, UPDATE_LOG)
        self.execCmd(cmd, self.aiInstallFinished)

    def aiInstallFinished(self, retval):
        self.stopPulse()
        self.setProgress(99)
        try:
            if os.path.exists(self.aifile):
                os.remove(self.aifile)
        except Exception:
            pass
        if retval == 0 and self.aifuryInstalled():
            self.aifury_ok = True
            self.aifury_msg = _('AIFury: installed successfully')
        else:
            self.aifury_ok = False
            self.aifury_msg = _('AIFury: installation failed! (see %s)') % UPDATE_LOG
        self.setInfo(self.aifury_msg)
        self.later(self.finishAll, 900)

    # ------------------- finish -------------------

    def finishAll(self):
        self.stopPulse()
        self.releaseAiFuryLock()
        self.setProgress(100)
        self.setStage(self.STEPS, _('Update finished'))
        if self.skin_ok:
            skinline = _('Skin: installed successfully')
        else:
            skinline = _('Skin: installation failed!')
        self.setInfo('%s\n%s' % (skinline, self.aifury_msg))
        if self.aifury_ok:
            heading = _('Fury & AIFury update was completed successfully.')
        else:
            heading = _('Fury skin finished, but AIFury was NOT installed.')
        message = '%s\n\n%s\n%s\n\n%s' % (heading,
         skinline,
         self.aifury_msg,
         _('Do you want to restart the GUI now?'))
        restartbox = self.session.openWithCallback(self.restartGUI, MessageBox, message, MessageBox.TYPE_YESNO)
        restartbox.setTitle(_('Restart GUI now?'))

    def keyCancel(self):
        if self.busy:
            if self.download is not None:
                self.aborted = True
                try:
                    self.download.stop()
                except Exception:
                    pass
                self.download = None
                self.busy = False
                self['status'].setText(_('Download aborted'))
                self.setInfo('')
                self.later(self.close, 800)
            # an opkg installation is never interrupted
            return
        self.close()

    def cleanUp(self):
        self.releaseAiFuryLock()
        self.stopPulse()
        try:
            self.stepTimer.stop()
        except Exception:
            pass
        if self.download is not None:
            try:
                self.download.stop()
            except Exception:
                pass
            self.download = None
        try:
            if os.path.exists(self.aifile):
                os.remove(self.aifile)
            if os.path.exists(self.aicheckfile):
                os.remove(self.aicheckfile)
            if os.path.exists(self.aibranchfile):
                os.remove(self.aibranchfile)
        except Exception:
            pass

    def restartGUI(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()
