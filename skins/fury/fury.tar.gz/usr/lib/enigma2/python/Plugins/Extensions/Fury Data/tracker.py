##
# Coding by Islam Salama (( skin Fury-FHD ))
# Fury Data Monitor v1.5
# - Real Python bytes for Renderers / Converters / Plugins
# - Persistent counters across GUI/Enigma restarts using /tmp
# - Auto reset after full device reboot / power cycle
##

import socket
import inspect
import os
import json
import time

try:
    import ssl
except Exception:
    ssl = None

STATE_FILE = "/tmp/fury_data_monitor_state.json"

plugin_usage_data = {}
plugin_download_data = {}
plugin_upload_data = {}
plugin_usage_bytes = {}
plugin_download_bytes = {}
plugin_upload_bytes = {}

_socket_owner = {}
_tracking_started = False
_iface_start_bytes = {}
_last_state_save = 0.0

original_socket_connect = socket.socket.connect
original_socket_recv = getattr(socket.socket, "recv", None)
original_socket_recv_into = getattr(socket.socket, "recv_into", None)
original_socket_send = getattr(socket.socket, "send", None)
original_socket_sendall = getattr(socket.socket, "sendall", None)
original_socket_close = getattr(socket.socket, "close", None)

if ssl is not None:
    original_ssl_recv = getattr(ssl.SSLSocket, "recv", None)
    original_ssl_read = getattr(ssl.SSLSocket, "read", None)
    original_ssl_send = getattr(ssl.SSLSocket, "send", None)
    original_ssl_sendall = getattr(ssl.SSLSocket, "sendall", None)
else:
    original_ssl_recv = None
    original_ssl_read = None
    original_ssl_send = None
    original_ssl_sendall = None

POSTER_LOGO_KEYWORDS = (
    "poster", "logo", "furylogo", "xtra", "tmdb", "tvdb", "kinopoisk",
    "backdrop", "cover", "imdb", "posterx"
)


def _bytes_to_mb(value):
    return float(value) / 1048576.0


def _get_boot_id():
    try:
        with open("/proc/sys/kernel/random/boot_id", "r") as f:
            return f.read().strip()
    except Exception:
        # Fallback: /tmp is normally cleared on reboot, so this is enough.
        return "unknown"


def _safe_int_dict(data):
    out = {}
    try:
        for k, v in data.items():
            try:
                out[str(k)] = int(v)
            except Exception:
                pass
    except Exception:
        pass
    return out


def _rebuild_mb_maps():
    plugin_download_data.clear()
    plugin_upload_data.clear()
    plugin_usage_data.clear()

    for name, value in plugin_download_bytes.items():
        plugin_download_data[name] = _bytes_to_mb(value)

    for name, value in plugin_upload_bytes.items():
        plugin_upload_data[name] = _bytes_to_mb(value)

    all_names = set(plugin_download_bytes.keys()) | set(plugin_upload_bytes.keys()) | set(plugin_usage_bytes.keys())
    for name in all_names:
        total = int(plugin_download_bytes.get(name, 0)) + int(plugin_upload_bytes.get(name, 0))
        plugin_usage_bytes[name] = total
        plugin_usage_data[name] = _bytes_to_mb(total)


def _load_state():
    global _iface_start_bytes
    try:
        if not os.path.exists(STATE_FILE):
            return

        with open(STATE_FILE, "r") as f:
            data = json.load(f)

        if data.get("boot_id") != _get_boot_id():
            # New boot / power cycle: start fresh.
            return

        plugin_download_bytes.update(_safe_int_dict(data.get("plugin_download_bytes", {})))
        plugin_upload_bytes.update(_safe_int_dict(data.get("plugin_upload_bytes", {})))
        plugin_usage_bytes.update(_safe_int_dict(data.get("plugin_usage_bytes", {})))

        start = data.get("iface_start_bytes", {})
        if isinstance(start, dict):
            for k, pair in start.items():
                try:
                    _iface_start_bytes[str(k)] = (int(pair[0]), int(pair[1]))
                except Exception:
                    pass

        _rebuild_mb_maps()
    except Exception:
        pass


def _save_state(force=False):
    global _last_state_save
    try:
        now = time.time()
        if not force and (now - _last_state_save) < 1.0:
            return
        _last_state_save = now

        data = {
            "boot_id": _get_boot_id(),
            "plugin_download_bytes": plugin_download_bytes,
            "plugin_upload_bytes": plugin_upload_bytes,
            "plugin_usage_bytes": plugin_usage_bytes,
            "iface_start_bytes": _iface_start_bytes,
        }

        tmp_file = STATE_FILE + ".tmp"
        with open(tmp_file, "w") as f:
            json.dump(data, f)

        try:
            os.rename(tmp_file, STATE_FILE)
        except Exception:
            try:
                os.remove(STATE_FILE)
            except Exception:
                pass
            os.rename(tmp_file, STATE_FILE)
    except Exception:
        pass


def _read_active_iface_bytes():
    active_iface = "Unknown"
    active_key = "Unknown"
    best_rx = 0
    best_tx = 0
    max_total = -1

    try:
        with open('/proc/net/dev', 'r') as f:
            lines = f.readlines()[2:]

        for line in lines:
            if ":" not in line:
                continue

            parts = line.split(":")
            iface_key = parts[0].strip()

            if iface_key == "lo":
                continue

            data = parts[1].split()
            rx = int(data[0])
            tx = int(data[8])
            total = rx + tx

            if total > max_total:
                max_total = total
                best_rx = rx
                best_tx = tx
                active_key = iface_key

                if "eth" in iface_key or "en" in iface_key:
                    active_iface = "LAN (Cable)"
                elif "wlan" in iface_key or "wl" in iface_key or "ra" in iface_key:
                    active_iface = "WLAN (Wi-Fi)"
                else:
                    active_iface = iface_key
    except Exception:
        pass

    return best_rx, best_tx, active_iface, active_key


def get_total_usage():
    """Total network usage since first start in this boot.
    This survives GUI/Enigma restart because baseline is saved in /tmp.
    It resets automatically after a full device reboot / power cycle.
    """
    rx, tx, active_iface, iface_key = _read_active_iface_bytes()

    if iface_key not in _iface_start_bytes:
        _iface_start_bytes[iface_key] = (rx, tx)
        _save_state(force=True)

    base_rx, base_tx = _iface_start_bytes.get(iface_key, (rx, tx))

    # If the network interface counter restarted without a full boot, protect from negative values.
    if rx < base_rx or tx < base_tx:
        _iface_start_bytes[iface_key] = (rx, tx)
        base_rx, base_tx = rx, tx
        _save_state(force=True)

    rx_delta = max(0, rx - base_rx)
    tx_delta = max(0, tx - base_tx)

    return _bytes_to_mb(rx_delta), _bytes_to_mb(tx_delta), active_iface


def analyze_stack(args_str=""):
    try:
        stack = inspect.stack()
        for frame in stack:
            filename = frame.filename.replace('\\', '/')
            filename_low = filename.lower()

            if "datamonitor" in filename_low or filename_low.endswith("/tracker.py"):
                continue

            if "Plugins/Extensions/" in filename:
                return "Plugin: " + filename.split("Plugins/Extensions/")[1].split("/")[0]
            elif "Components/Renderer/" in filename:
                return "Renderer: " + filename.split("Components/Renderer/")[1].split(".")[0]
            elif "Components/Converter/" in filename:
                return "Converter: " + filename.split("Components/Converter/")[1].split(".")[0]
            elif "oster" in filename_low or "xtra" in filename_low or "logo" in filename_low:
                base = os.path.basename(filename).split('.')[0]
                return "Renderer: " + base

        args_lower = str(args_str).lower()
        if "tmdb" in args_lower or "tvdb" in args_lower or "kinopoisk" in args_lower:
            return "Renderer: Poster/Info Fetcher"
        if "logo" in args_lower:
            return "Renderer: Logo Fetcher"
        if "poster" in args_lower or "xtra" in args_lower:
            return "Renderer: Poster Fetcher"
    except Exception:
        pass
    return None


def _get_caller(sock=None, args_str=""):
    caller = None
    try:
        if sock is not None:
            caller = _socket_owner.get(id(sock))
    except Exception:
        caller = None

    if not caller:
        caller = analyze_stack(args_str)
        if caller and sock is not None:
            try:
                _socket_owner[id(sock)] = caller
            except Exception:
                pass

    return caller


def _record_usage(caller, byte_count, direction="down"):
    if not caller or not byte_count or byte_count <= 0:
        return

    try:
        byte_count = int(byte_count)
    except Exception:
        return

    if direction == "up":
        plugin_upload_bytes[caller] = plugin_upload_bytes.get(caller, 0) + byte_count
    else:
        plugin_download_bytes[caller] = plugin_download_bytes.get(caller, 0) + byte_count

    total_bytes = plugin_download_bytes.get(caller, 0) + plugin_upload_bytes.get(caller, 0)
    plugin_usage_bytes[caller] = total_bytes

    plugin_download_data[caller] = _bytes_to_mb(plugin_download_bytes.get(caller, 0))
    plugin_upload_data[caller] = _bytes_to_mb(plugin_upload_bytes.get(caller, 0))
    plugin_usage_data[caller] = _bytes_to_mb(total_bytes)

    _save_state(False)


def get_media_download_usage():
    total = 0.0
    for name, value in plugin_download_data.items():
        low = name.lower()
        if any(k in low for k in POSTER_LOGO_KEYWORDS):
            total += value
    return total


def hooked_socket_connect(self, address):
    if address and ('127.0.0.1' in str(address) or 'localhost' in str(address)):
        return original_socket_connect(self, address)

    caller = analyze_stack(address)
    if caller:
        try:
            _socket_owner[id(self)] = caller
        except Exception:
            pass

    return original_socket_connect(self, address)


def hooked_socket_recv(self, bufsize, *args, **kwargs):
    data = original_socket_recv(self, bufsize, *args, **kwargs)
    caller = _get_caller(self)
    if caller and data:
        _record_usage(caller, len(data), "down")
    return data


def hooked_socket_recv_into(self, buffer, nbytes=0, *args, **kwargs):
    if nbytes:
        count = original_socket_recv_into(self, buffer, nbytes, *args, **kwargs)
    else:
        count = original_socket_recv_into(self, buffer, *args, **kwargs)
    caller = _get_caller(self)
    if caller and count:
        _record_usage(caller, count, "down")
    return count


def hooked_socket_send(self, data, *args, **kwargs):
    sent = original_socket_send(self, data, *args, **kwargs)
    caller = _get_caller(self)
    if caller and sent:
        _record_usage(caller, sent, "up")
    return sent


def hooked_socket_sendall(self, data, *args, **kwargs):
    result = original_socket_sendall(self, data, *args, **kwargs)
    caller = _get_caller(self)
    if caller and data:
        _record_usage(caller, len(data), "up")
    return result


def hooked_socket_close(self, *args, **kwargs):
    try:
        _socket_owner.pop(id(self), None)
    except Exception:
        pass
    return original_socket_close(self, *args, **kwargs)


def hooked_ssl_recv(self, buflen=1024, flags=0):
    data = original_ssl_recv(self, buflen, flags)
    caller = _get_caller(self)
    if caller and data:
        _record_usage(caller, len(data), "down")
    return data


def hooked_ssl_read(self, len=1024, buffer=None):
    if buffer is None:
        data = original_ssl_read(self, len)
        caller = _get_caller(self)
        if caller and data:
            _record_usage(caller, len(data), "down")
        return data
    else:
        count = original_ssl_read(self, len, buffer)
        caller = _get_caller(self)
        if caller and count:
            _record_usage(caller, count, "down")
        return count


def hooked_ssl_send(self, data, flags=0):
    sent = original_ssl_send(self, data, flags)
    caller = _get_caller(self)
    if caller and sent:
        _record_usage(caller, sent, "up")
    return sent


def hooked_ssl_sendall(self, data, flags=0):
    result = original_ssl_sendall(self, data, flags)
    caller = _get_caller(self)
    if caller and data:
        _record_usage(caller, len(data), "up")
    return result


try:
    import enigma
    original_execute = enigma.eConsoleAppContainer.execute

    def hooked_execute(self, cmd, *args):
        # External wget/curl is included in total network usage, but exact
        # per-plugin bytes cannot be attributed here without wrapping the process.
        return original_execute(self, cmd, *args)
except Exception:
    original_execute = None


def start_tracking():
    global _tracking_started

    if _tracking_started:
        return

    _tracking_started = True
    _load_state()

    # Do not reset counters here. Baseline is created once per boot and saved in /tmp.
    get_total_usage()

    try:
        socket.socket.connect = hooked_socket_connect
        if original_socket_recv:
            socket.socket.recv = hooked_socket_recv
        if original_socket_recv_into:
            socket.socket.recv_into = hooked_socket_recv_into
        if original_socket_send:
            socket.socket.send = hooked_socket_send
        if original_socket_sendall:
            socket.socket.sendall = hooked_socket_sendall
        if original_socket_close:
            socket.socket.close = hooked_socket_close
    except Exception:
        pass

    if ssl is not None:
        try:
            if original_ssl_recv:
                ssl.SSLSocket.recv = hooked_ssl_recv
            if original_ssl_read:
                ssl.SSLSocket.read = hooked_ssl_read
            if original_ssl_send:
                ssl.SSLSocket.send = hooked_ssl_send
            if original_ssl_sendall:
                ssl.SSLSocket.sendall = hooked_ssl_sendall
        except Exception:
            pass

    try:
        if original_execute is not None:
            enigma.eConsoleAppContainer.execute = hooked_execute
    except Exception:
        pass

    _save_state(force=True)
