##
# Coding by Islam Salama (( skin Fury-FHD ))
# Fury Data Monitor v1.0
# - Previous working Renderer / Converter / Plugin tracking
# - Untracked Network is calculated from screen-open moment only
# - Counters survive GUI/Enigma restart and reset after full device boot
##

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from enigma import eTimer
from . import tracker
import os
import time

tracker.start_tracking()

class DataMonitorScreen(Screen):
    skin = """
    <screen position="center,center" size="1580,900" title="Fury Data Monitor v1.0">
        <eLabel position="0,0" size="1580,66" backgroundColor="#1a1a1a" zPosition="-1" />
        <eLabel text="NETWORK DASHBOARD" position="28,16" size="760,38" font="Regular;31" foregroundColor="#d8aa2a" backgroundColor="#1a1a1a" transparent="1" />
        <widget name="uptime_label" position="1120,18" size="430,32" font="Regular;24" halign="right" foregroundColor="#ffffff" backgroundColor="#1a1a1a" transparent="1" />

        <eLabel text="TOTAL USAGE SINCE DEVICE START" position="28,92" size="700,30" font="Regular;24" foregroundColor="#bcbcbc" transparent="1" />
        <widget name="total_label" position="28,126" size="690,42" font="Regular;27" halign="left" foregroundColor="#ffffff" transparent="1" />

        <eLabel text="UNTRACKED NETWORK FROM SCREEN OPEN" position="800,92" size="740,30" font="Regular;24" foregroundColor="#ff6f7d" transparent="1" />
        <widget name="iptv_label" position="800,126" size="740,42" font="Regular;27" halign="left" foregroundColor="#ff6670" transparent="1" />

        <eLabel position="28,186" size="1524,2" backgroundColor="#333333" />

        <eLabel text="EXTERNAL SERVICES / SHARING" position="28,208" size="740,30" font="Regular;24" foregroundColor="#63f06f" transparent="1" />
        <widget name="cams_label" position="28,242" size="1524,42" font="Regular;24" halign="left" foregroundColor="#55e063" transparent="1" />

        <eLabel position="28,302" size="1524,2" backgroundColor="#333333" />

        <widget name="plugins_header_label" position="28,324" size="1524,30" font="Regular;24" halign="left" foregroundColor="#d8aa2a" transparent="1" />

        <eLabel text="PLUGINS" position="28,366" size="720,28" font="Regular;24" foregroundColor="#f3c54a" transparent="1" />
        <widget name="plugins_label_left" position="28,402" size="720,382" font="Regular;20" halign="left" valign="top" foregroundColor="#f4e1a3" transparent="1" />

        <eLabel position="780,364" size="2,420" backgroundColor="#333333" />

        <eLabel text="RENDERERS" position="806,366" size="720,28" font="Regular;24" foregroundColor="#63d8ff" transparent="1" />
        <widget name="renderers_label" position="806,402" size="720,190" font="Regular;20" halign="left" valign="top" foregroundColor="#b8efff" transparent="1" />

        <eLabel text="CONVERTERS" position="806,610" size="720,28" font="Regular;24" foregroundColor="#7df58f" transparent="1" />
        <widget name="converters_label" position="806,646" size="720,138" font="Regular;20" halign="left" valign="top" foregroundColor="#c8ffd0" transparent="1" />

        <eLabel position="0,856" size="1580,44" backgroundColor="#1a1a1a" zPosition="-1" />
        <eLabel text="Updating in real-time... Press EXIT to close" position="0,864" size="1580,28" font="Regular;20" halign="center" foregroundColor="#666666" backgroundColor="#1a1a1a" transparent="1" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self["actions"] = ActionMap(["SetupActions"], {"cancel": self.exit_plugin}, -1)

        self["uptime_label"] = Label("Uptime: Loading...")
        self["total_label"] = Label("Detecting Network...")
        self["iptv_label"] = Label("Calculating Untracked...")
        self["cams_label"] = Label("Monitoring Cams...")
        self["plugins_header_label"] = Label("PLUGIN DOWNLOADS")
        self["plugins_label_left"] = Label("Analyzing Plugins...")
        self["renderers_label"] = Label("Analyzing Renderers...")
        self["converters_label"] = Label("Analyzing Converters...")

        self.active_cam_name = self.get_active_cam()

        # Only Untracked Network starts from screen-open moment.
        # Renderer / Converter / Plugin counters are NOT reset here.
        self.untracked_start_rx = 0.0
        self.untracked_start_python_down = 0.0
        self.untracked_start_cam = 0.0
        self.init_untracked_baseline()

        self.live_timer = eTimer()
        try:
            self.live_timer_conn = self.live_timer.timeout.connect(self.update_data)
        except Exception:
            self.live_timer.callback.append(self.update_data)

        self.onShown.append(self.start_live_monitor)

    def init_untracked_baseline(self):
        try:
            rx, tx, iface = tracker.get_total_usage()
            self.untracked_start_rx = rx
            self.untracked_start_python_down = self._get_python_down_total()
            uptime_sec, uptime_str = self.get_system_uptime()
            self.untracked_start_cam = self._get_estimated_cam_usage(uptime_sec)
        except Exception:
            self.untracked_start_rx = 0.0
            self.untracked_start_python_down = 0.0
            self.untracked_start_cam = 0.0

    def start_live_monitor(self):
        self.update_data()
        self.live_timer.start(2000, False)

    def exit_plugin(self):
        self.live_timer.stop()
        self.close()

    def get_system_uptime(self):
        try:
            with open('/proc/uptime', 'r') as f:
                uptime_seconds = float(f.readline().split()[0])
                hours = int(uptime_seconds // 3600)
                minutes = int((uptime_seconds % 3600) // 60)
                seconds = int(uptime_seconds % 60)
                return uptime_seconds, "Uptime: %dh %dm %ds" % (hours, minutes, seconds)
        except Exception:
            return 0.0, "Uptime: Unknown"

    def get_active_cam(self):
        try:
            output = os.popen("ps").read().lower()
            if "ncam" in output: return "Ncam"
            elif "oscam" in output: return "OScam"
            elif "cccam" in output: return "CCcam"
            elif "gcam" in output: return "Gcam"
            elif "wicardd" in output: return "Wicardd"
            elif "mgcamd" in output: return "MGcamd"
            return "Active Cam"
        except Exception:
            return "SoftCam"

    def _fmt_usage(self, mb_value):
        try:
            if mb_value < 0.01:
                return "%.1f KB" % (mb_value * 1024.0)
            return "%.2f MB" % mb_value
        except Exception:
            return "0.00 MB"

    def _short_name(self, text, limit=27):
        if len(text) <= limit:
            return text
        return text[:limit - 2] + ".."

    def _format_item(self, clean_name, down_usage, up_usage):
        clean_name = self._short_name(clean_name, 27)
        return "%-29s D:%9s   U:%8s\n\n" % (
            clean_name,
            self._fmt_usage(down_usage),
            self._fmt_usage(up_usage)
        )

    def _get_estimated_cam_usage(self, uptime_sec):
        uptime_minutes = uptime_sec / 60.0
        usage = uptime_minutes * 0.002
        if usage < 0.001:
            usage = 0.001
        return usage

    def _get_python_down_total(self):
        total = 0.0
        try:
            for name, value in tracker.plugin_download_data.items():
                total += value
        except Exception:
            pass
        return total

    def update_data(self):
        uptime_sec, uptime_str = self.get_system_uptime()
        self["uptime_label"].setText(uptime_str)

        rx, tx, iface = tracker.get_total_usage()

        tracked_down_total = 0.0
        plugin_text = ""
        renderer_text = ""
        converter_text = ""

        if tracker.plugin_usage_data:
            def sort_key(item):
                name, total = item
                down = tracker.plugin_download_data.get(name, 0.0)
                return (down, total)

            sorted_usage = sorted(tracker.plugin_usage_data.items(), key=sort_key, reverse=True)
            valid_items = [(k, v) for k, v in sorted_usage if v > 0.0005]

            for name, total_usage in valid_items:
                down_usage = tracker.plugin_download_data.get(name, 0.0)
                up_usage = tracker.plugin_upload_data.get(name, 0.0)
                tracked_down_total += down_usage

                if name.startswith("Plugin:"):
                    clean_name = name.replace("Plugin: ", "")
                    plugin_text += self._format_item(clean_name, down_usage, up_usage)
                elif name.startswith("Renderer:"):
                    clean_name = name.replace("Renderer: ", "")
                    renderer_text += self._format_item(clean_name, down_usage, up_usage)
                elif name.startswith("Converter:"):
                    clean_name = name.replace("Converter: ", "")
                    converter_text += self._format_item(clean_name, down_usage, up_usage)
                else:
                    clean_name = self._short_name(name, 27)
                    plugin_text += self._format_item(clean_name, down_usage, up_usage)

        try:
            media_down = tracker.get_media_download_usage()
        except Exception:
            media_down = 0.0

        self["plugins_header_label"].setText(
            "PLUGIN DOWNLOADS   Posters/Logos: %s   |   Python Total Down: %s" % (
                self._fmt_usage(media_down), self._fmt_usage(tracked_down_total)
            )
        )

        self["plugins_label_left"].setText(plugin_text or "No plugin network activity yet.")
        self["renderers_label"].setText(renderer_text or "No renderer network activity yet.")
        self["converters_label"].setText(converter_text or "No converter network activity yet.")

        cams_total_usage = self._get_estimated_cam_usage(uptime_sec)
        self["cams_label"].setText(
            "[%s] Sharing / ECM Traffic ~ %s  (estimated, included in TOTAL USAGE)" % (
                self.active_cam_name, self._fmt_usage(cams_total_usage)
            )
        )

        self["total_label"].setText("[%s]  Down: %s  |  Up: %s" % (
            iface, self._fmt_usage(rx), self._fmt_usage(tx)
        ))

        # IMPORTANT:
        # Untracked Network is calculated only from the moment this screen was opened.
        # It does not reset Renderer / Converter / Plugin counters.
        rx_delta = rx - self.untracked_start_rx
        py_delta = tracked_down_total - self.untracked_start_python_down
        cam_delta = cams_total_usage - self.untracked_start_cam

        other_usage = rx_delta - py_delta - cam_delta
        if other_usage < 0:
            other_usage = 0.0

        self["iptv_label"].setText("Untracked Network  ~  %s" % self._fmt_usage(other_usage))


def main(session, **kwargs):
    session.open(DataMonitorScreen)


def Plugins(**kwargs):
    return [PluginDescriptor(
        name="Fury Data",
        description="Internet usage calculation Islam Salama",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="plugin.png",
        fnc=main
    )]
