# -*- coding: utf-8 -*-
# ============================================================================
#  iBase.py  -  GlamourBase converter (Final Zero-Lag Optimized Version)
# ============================================================================

from __future__ import absolute_import, division
from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.Element import cached
import NavigationInstance
from enigma import iServiceInformation, iPlayableService
from Tools.Transponder import ConvertToHumanReadable
from Components.config import config
import os
import time
import threading

# ----------------------------------------------------------------------------
#  Debug (gated by plugin debug settings)
# ----------------------------------------------------------------------------
MODULE_NAME = "iBase"
LOGFILE = "/tmp/%s_Debug.log" % MODULE_NAME

def _debug_enabled():
    try:
        xd = config.plugins.xDreamy
        return bool(xd.debug_master.value) and bool(getattr(xd, "dbg_%s" % MODULE_NAME).value)
    except Exception:
        return False

def dbg(tag, msg):
    if _debug_enabled():
        line = "[%s][%s] %s" % (MODULE_NAME, tag, msg)
        try:
            print(line)
        except Exception:
            pass
        try:
            with open(LOGFILE, "a") as f:
                f.write(line + "\n")
        except Exception:
            pass

# ----------------------------------------------------------------------------
#  XDREAMY active check
# ----------------------------------------------------------------------------
XDREAMY_SKIN_MARKER = "xdreamy"

def _is_xdreamy_active():
    try:
        skin_val = str(getattr(config.skin, "primary_skin", None) and config.skin.primary_skin.value or "")
        return XDREAMY_SKIN_MARKER in skin_val.lower()
    except Exception:
        return False

def _in_standby():
    try:
        import Screens.Standby
        return Screens.Standby.inStandby is not None
    except Exception:
        return False

try:
    from Components.Language import language
    _ = language.getText
except Exception:
    def _(txt):
        return txt

# ----------------------------------------------------------------------------
#  Codec maps
# ----------------------------------------------------------------------------
CODECS = {
    -1: "N/A",
    0: "MPEG2",
    1: "AVC",
    2: "H263",
    3: "VC1",
    4: "MPEG4-VC",
    5: "VC1-SM",
    6: "MPEG1",
    7: "HEVC",
    8: "VP8",
    9: "VP9",
    10: "XVID",
    11: "N/A 11",
    12: "N/A 12",
    13: "DIVX 3.11",
    14: "DIVX 4",
    15: "DIVX 5",
    16: "AVS",
    17: "N/A 17",
    18: "VP6",
    19: "N/A 19",
    20: "N/A 20",
    21: "SPARK",
    22: "AV1",
    23: "VVC",
    24: "AV2",
}

HDR_MAP = {
    0: "SDR",
    1: "HDR",
    2: "HDR10",
    3: "HLG",
    4: "HDR10+",
    5: "Dolby Vision"
}

# ----------------------------------------------------------------------------
#  Satellite database
# ----------------------------------------------------------------------------
SATNAMES = (
    (179.7, 180.3, "Intelsat 18"),
    (177.7, 178.3, "Intelsat 10"),
    (175.5, 176.5, "NSS 11"),
    (173.5, 174.5, "Eutelsat 174A"),
    (171.7, 172.3, "Eutelsat 172B"),
    (168.7, 169.3, "Horizons 3e"),
    (166.7, 167.5, "Luch 5A"),
    (165.7, 166.3, "Intelsat 19"),
    (163.7, 164.3, "Optus 10"),
    (162.7, 163.4, "ChinaSat 19"),
    (161.7, 162.3, "Superbird B3"),
    (159.7, 160.3, "Optus D2"),
    (158.7, 159.3, "ABS 6"),
    (156.7, 157.5, "Intelsat 1R"),
    (155.7, 156.3, "Optus 10,D3"),
    (153.7, 154.4, "JCSat 2B"),
    (151.7, 152.3, "Optus D1"),
    (150.4, 150.8, "BRIsat"),
    (149.7, 150.3, "JCSat 1C"),
    (145.7, 146.3, "Nusantara Satu"),
    (144.7, 145.4, "Express AMU7"),
    (143.7, 144.3, "Superbird C2"),
    (142.7, 143.3, "Inmarsat-4F1"),
    (141.7, 142.3, "Apstar 9"),
    (139.7, 140.4, "Express AM5,AT2"),
    (137.7, 138.3, "Telstar 18V"),
    (135.7, 136.4, "JCSat 16"),
    (133.7, 134.3, "Apstar 6C,6D"),
    (131.7, 132.3, "Vinasat 1,2/JCSat 5A,12"),
    (130.4, 130.8, "ChinaSat 6C"),
    (129.7, 130.3, "ChinaSat 2D"),
    (128.4, 128.8, "LaoSat 1"),
    (127.7, 128.3, "JCSat 3A"),
    (124.7, 125.3, "ChinaSat 26,6D"),
    (123.7, 124.3, "JCSat 4B"),
    (120.7, 122.5, "AsiaSat 9"),
    (119.8, 120.3, "AsiaSat 6/Thaicom 7"),
    (118.8, 119.7, "Bangabandhu 1/Thaicom 4"),
    (117.8, 118.3, "Telkom 3S"),
    (115.8, 116.3, "KoreaSat 6,7"),
    (115.3, 115.7, "ChinaSat 6B"),
    (112.7, 113.3, "KoreaSat 5,5A"),
    (110.3, 110.8, "ChinaSat 10"),
    (109.7, 110.2, "BSat 3A,3C,4A/JCSat 110A"),
    (107.5, 108.5, "SES 7,9/Telkom 4"),
    (105.3, 105.8, "AsiaSat 7"),
    (104.8, 105.1, "Asiastar 1"),
    (103.4, 103.7, "ChinaSat 2C"),
    (102.7, 103.3, "Express AMU3"),
    (101.1, 101.7, "Chinasat 9B"),
    (100.0, 100.7, "AsiaSat 5"),
    (98.5, 98.8, "Thuraya 3"),
    (97.8, 98.4, "Chinasat 11"),
    (96.8, 97.7, "GSat 9"),
    (96.2, 96.7, "Express 103"),
    (94.7, 95.3, "SES 8,12/Luch 5V"),
    (93.0, 93.8, "GSat 15,17"),
    (92.0, 92.5, "ChinaSat 9"),
    (91.3, 91.8, "Measat 3A,3B,3D"),
    (88.8, 90.3, "Yamal 401"),
    (87.8, 88.3, "ST 2"),
    (87.2, 87.7, "ChinaSat 12"),
    (86.2, 86.8, "Kazsat 2"),
    (84.8, 85.5, "Intelsat 15"),
    (82.8, 83.3, "GSat 10,24,30"),
    (79.8, 80.4, "Express 80"),
    (78.3, 78.8, "Thaicom 6,8"),
    (76.3, 76.8, "Apstar 7"),
    (74.7, 75.4, "ABS 2,2A"),
    (73.7, 74.4, "GSat 18"),
    (71.7, 72.4, "Intelsat 22"),
    (70.3, 70.8, "Eutelsat 70B"),
    (68.0, 68.8, "Intelsat 20,36"),
    (65.8, 66.3, "Intelsat 17"),
    (64.8, 65.3, "Amos 4"),
    (63.8, 64.4, "Intelsat 906/Inmarsat-4F2"),
    (63.2, 63.6, "Astra 1G"),
    (62.8, 63.1, "G-Sat 7A"),
    (62.4, 62.7, "Inmarsat GX1"),
    (61.7, 62.3, "Intelsat 39"),
    (60.8, 61.2, "ABS 4"),
    (60.2, 60.4, "WGS 2"),
    (59.4, 60.1, "Intelsat 33e"),
    (58.3, 58.7, "KazSat 3"),
    (56.8, 57.3, "NSS 12"),
    (56.4, 56.7, "Inmarsat GX4"),
    (55.7, 56.3, "Express AT1"),
    (55.0, 55.4, "Yamal 402/GSat 8"),
    (54.6, 54.9, "Yamal 402"),
    (52.9, 53.3, "Express AM6"),
    (52.7, 52.8, "Skynet 5D"),
    (52.3, 52.6, "Al Yah 1"),
    (51.8, 52.2, "TurkmenÄlem/MonacoSat"),
    (51.2, 51.7, "Belintersat 1"),
    (49.7, 50.3, "Türksat 4B"),
    (48.7, 49.3, "Yamal 601"),
    (47.8, 48.3, "GSat 19,31"),
    (47.8, 48.3, "Eutelsat Quantum/GSat 12"),
    (47.6, 47.7, "Al Yah 2"),
    (45.7, 46.3, "AzerSpace 1/Africasat 1A"),
    (44.7, 45.3, "AzerSpace 2/Intelsat 38/Blagovest 1"),
    (43.7, 44.3, "Thuraya 2"),
    (42.4, 42.7, "Nigcomsat 1R"),
    (41.7, 42.3, "Türksat 3A,4A,5Α"),
    (39.8, 40.3, "Express AM7"),
    (38.7, 39.3, "HellasSat 3,4"),
    (37.9, 38.5, "Paksat 1R"),
    (37.6, 37.8, "Athena Fidus"),
    (36.8, 37.3, "Sicral 2"),
    (35.7, 36.3, "Eutelsat 36B,AMU1"),
    (32.9, 33.3, "Eutelsat 33E"),
    (32.6, 32.8, "Intelsat 28"),
    (31.4, 31.8, "Astra 5B"),
    (31.1, 31.3, "Hylas 2,3"),
    (30.7, 31.0, "Türksat 5A"),
    (30.2, 30.6, "Arabsat 5A,6A"),
    (28.0, 28.8, "Astra 2E,2F,2G"),
    (25.2, 26.3, "Badr 4,5,7,8/Es'hail 1,2"),
    (24.3, 24.8, "Skynet 5B"),
    (23.0, 23.8, "Astra 3B,3C"),
    (21.4, 21.8, "Eutelsat 21B"),
    (20.8, 21.2, "AfriStar 1"),
    (19.8, 20.5, "Arabsat 5C"),
    (18.8, 19.5, "Astra 1KR,1L,1M,1N"),
    (16.6, 17.3, "Amos 17"),
    (15.6, 16.3, "Eutelsat 16A"),
    (12.7, 13.5, "HotBird 13F,13G"),
    (11.5, 11.9, "Sicral 1B"),
    (9.7, 10.3, "Eutelsat 10A"),
    (8.7, 9.3, "Eutelsat 9B,Ka-Sat"),
    (6.7, 7.3, "Eutelsat 7B,7C"),
    (5.7, 6.3, "WGS 1"),
    (4.5, 5.4, "Astra 4A/SES 5"),
    (3.0, 3.6, "Eutelsat 3B"),
    (2.5, 2.9, "Rascom QAF 1R"),
    (1.4, 2.4, "BulgariaSat 1"),
    (-0.5, -1.2, "Thor 5,6,7/Intelsat 10-02"),
    (-2.7, -3.3, "ABS 3A"),
    (-3.7, -4.4, "Amos 3,7"),
    (-4.7, -5.4, "Eutelsat 5WB"),
    (-6.7, -7.2, "Nilesat 201,301/Eutelsat 7WA"),
    (-7.3, -7.4, "Eutelsat 7 West A"),
    (-7.5, -7.7, "Eutelsat 7WA,8WB"),
    (-7.8, -8.3, "Eutelsat 8 West B"),
    (-10.7, -11.3, "Express AM44"),
    (-11.8, -12.2, "WGS 9"),
    (-12.3, -12.8, "Eutelsat 12 West G"),
    (-13.8, -14.3, "Express AM8"),
    (-14.8, -15.3, "Telstar 12V"),
    (-15.8, -16.3, "Luch 5B"),
    (-17.8, -18.3, "Intelsat 37e"),
    (-19.8, -20.3, "NSS 7"),
    (-21.8, -22.4, "SES 4"),
    (-24.2, -24.6, "Intelsat 905"),
    (-24.7, -25.2, "AlcomSat 1"),
    (-27.2, -27.8, "Intelsat 901"),
    (-29.3, -29.7, "Intelsat 904"),
    (-29.8, -30.5, "Hispasat 30W-5,30W-6"),
    (-31.2, -31.8, "Intelsat 25"),
    (-33.3, -33.7, "Hylas 4"),
    (-34.2, -34.8, "Intelsat 35e"),
    (-35.7, -36.3, "Hispasat 36W-1"),
    (-37.2, -37.7, "Telstar 11N/NSS 10"),
    (-40.2, -40.8, "SES 6"),
    (-42.7, -43.5, "Intelsat 11/Sky Brasil 1"),
    (-44.7, -45.3, "Intelsat 14"),
    (-47.2, -47.8, "SES 14"),
    (-49.7, -50.4, "Intelsat 9,902"),
    (-52.7, -53.3, "Intelsat 23"),
    (-53.7, -54.3, "Inmarsat 3F5"),
    (-54.7, -55.2, "Inmarsat GX2"),
    (-55.3, -55.8, "Intelsat 34"),
    (-57.7, -58.3, "Intelsat 21"),
    (-59.7, -61.3, "Amazonas 2,3,5"),
    (-61.4, -61.7, "EchoStar 16"),
    (-62.8, -63.2, "Telstar 14R"),
    (-64.7, -65.3, "Eutelsat 65WA/Star One C2"),
    (-66.7, -67.5, "SES 10"),
    (-67.7, -68.3, "Echostar 23"),
    (-69.7, -70.3, "Star One C4,D2/Viasat 2"),
    (-71.5, -72.3, "Arsat 1/AMC3"),
    (-72.4, -72.8, "Nimiq 5"),
    (-73.7, -74.3, "Hispasat 74W-1"),
    (-74.7, -75.3, "Star One C3"),
    (-76.0, -76.5, "Intelsat 16"),
    (-76.7, -77.3, "QuetzSat 1"),
    (-78.5, -79.2, "Sky Mexico 1"),
    (-80.7, -81.3, "Arsat 2"),
    (-81.7, -82.3, "Nimiq 4"),
    (-82.7, -83.3, "AMC 18"),
    (-83.7, -84.3, "Star One D1/Sirius XM8"),
    (-84.7, -85.5, "Galaxy 17/Sirius XM3"),
    (-86.0, -86.4, "Sirius FM-5"),
    (-86.7, -87.5, "SES 2/TKSat 1"),
    (-88.7, -89.3, "Galaxy 28,36"),
    (-90.7, -91.3, "Nimiq 6/Galaxy 32"),
    (-92.7, -93.4, "Galaxy 35"),
    (-94.7, -95.4, "Galaxy 3C/Intelsat 30,31"),
    (-96.7, -97.4, "Galaxy 19"),
    (-97.5, -97.9, "Inmarsat 4F3"),
    (-98.8, -99.5, "Galaxy 16/Directv 11,14"),
    (-100.7, -101.4, "SES 1/Directv 9S,16"),
    (-102.9, -103.4, "SES 3,18,20/Directv 10,12"),
    (-104.7, -105.4, "AMC 15/SES 11/Echostar 105"),
    (-107.2, -107.6, "Anik F1R,G1/"),
    (-109.7, -110.4, "Echostar 10,11/Directv 5"),
    (-110.8, -111.5, "Anik F2"),
    (-112.7, -113.4, "Eutelsat 113 West A"),
    (-114.6, -115.4, "Eutelsat 115 West B/Sirius XM5"),
    (-115.8, -116.3, "Sirius FM-6"),
    (-116.6, -117.4, "Eutelsat 117 West A,B"),
    (-118.7, -119.4, "Anik F3/Directv 8/Echostar 14"),
    (-120.7, -121.4, "Galaxy 31"),
    (-122.7, -123.4, "Galaxy 18"),
    (-124.7, -125.4, "AMC 21/Galaxy 30"),
    (-126.7, -127.4, "Galaxy 13/Horizons 1"),
    (-128.7, -129.4, "Ciel 2/SES 15/Galaxy 34"),
    (-130.7, -131.4, "SES 21"),
    (-132.7, -133.4, "Galaxy 33"),
    (-134.7, -135.4, "SES 19,22"),
    (-138.7, -139.4, "AMC 6"),
    (-168.7, -169.4, "NSS 6"),
    (-176.7, -177.4, "NSS 9")
)

# ----------------------------------------------------------------------------
#  BACKGROUND PROBER (Optimized with Smart Back-off & Pre-parsed Cache)
# ----------------------------------------------------------------------------
class _BackgroundProber:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super(_BackgroundProber, cls).__new__(cls)
                    cls._instance._initialize()
        return cls._instance

    def _initialize(self):
        self._data_lock = threading.Lock()
        self.video_data = {"width": 0, "height": 0, "fps": 0, "progressive": -1}
        self.transponder_data = {}
        self._current_service_ref = None
        self._stop_event = threading.Event()
        self._force_event = threading.Event()
        self._thread = threading.Thread(target=self._thread_loop)
        self._thread.daemon = True
        self._thread.start()

    def stop(self):
        self._stop_event.set()
        self._force_event.set()

    def force_update(self):
        self._force_event.set()

    def get_data(self):
        with self._data_lock:
            return self.video_data.copy(), self.transponder_data.copy()

    def _read_proc(self, path, default=0, is_hex=False):
        try:
            if os.path.exists(path):
                with open(path, "r") as f:
                    val = f.read().strip()
                    if val:
                        try:
                            return int(val, 16) if is_hex else int(val)
                        except ValueError:
                            pass
        except Exception:
            pass
        if "/vmpeg/" in path:
            alt = path.replace("/vmpeg/", "/video/")
            try:
                if os.path.exists(alt):
                    with open(alt, "r") as f:
                        val = f.read().strip()
                        if val:
                            try:
                                return int(val, 16) if is_hex else int(val)
                            except ValueError:
                                pass
            except Exception:
                pass
        return default

    def _get_current_service_ref(self):
        try:
            if NavigationInstance.instance is None:
                return None
            ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
            return ref.toString() if ref else None
        except Exception:
            return None

    def _fetch_service_info(self, service_ref):
        if service_ref is None:
            return {}
        try:
            if NavigationInstance.instance is None:
                return {}
            service = NavigationInstance.instance.getCurrentService()
            if not service:
                return {}
            info = service.info()
            if not info:
                return {}
            width = info.getInfo(iServiceInformation.sVideoWidth)
            height = info.getInfo(iServiceInformation.sVideoHeight)
            fps = info.getInfo(iServiceInformation.sFrameRate)
            return {"width": width, "height": height, "fps": fps}
        except Exception:
            return {}

    def _enrich_tp_data(self, tp):
        if tp:
            # Pre-parse human readable mapping once in background thread
            try:
                tp["cached_tpinfo"] = ConvertToHumanReadable(tp)
            except Exception:
                tp["cached_tpinfo"] = tp

            # Pre-calculate DVB booleans for zero main-thread overhead
            tt = tp.get("tuner_type", "")
            sys = tp.get("system", 0)
            is_gen2 = (sys == 1) or ("2" in tt)
            tp["cached_is_s"] = "DVB-S" in tt and not is_gen2
            tp["cached_is_s2"] = "DVB-S" in tt and is_gen2
            tp["cached_is_c"] = "DVB-C" in tt and not is_gen2
            tp["cached_is_c2"] = "DVB-C" in tt and is_gen2
            tp["cached_is_t"] = "DVB-T" in tt and not is_gen2
            tp["cached_is_t2"] = "DVB-T" in tt and is_gen2

            if "DVB-S" in tt:
                orb = int(tp.get("orbital_position", 0))
                orbe = orb / 10.0
                orbw = (orb - 3600) / 10.0
                sat_name = "Satellite"
                for sn in SATNAMES:
                    if sn[0] <= orbe <= sn[1] or sn[1] <= orbw <= sn[0]:
                        sat_name = sn[2]
                        break
                tp["cached_satname"] = sat_name
                if orb > 1800:
                    tp["cached_orbital"] = "%.1f°W" % ((3600 - orb) / 10.0)
                else:
                    tp["cached_orbital"] = "%.1f°E" % (orb / 10.0)

    def _fetch_frontend_info(self, service_ref):
        if service_ref is None:
            return {}
        try:
            if NavigationInstance.instance is None:
                return {}
            service = NavigationInstance.instance.getCurrentService()
            if not service:
                return {}
            feinfo = service.frontendInfo()
            if feinfo:
                use_settings = getattr(getattr(config, "usage", None), "infobar_frontend_source", None) == "settings"
                tp = feinfo.getAll(use_settings)
                if tp and tp.get("tuner_type"):
                    self._enrich_tp_data(tp)
                    return tp
            info = service.info()
            if info:
                tp = info.getInfoObject(iServiceInformation.sTransponderData)
                if tp and tp.get("tuner_type"):
                    self._enrich_tp_data(tp)
                    return tp
        except Exception as e:
            dbg("frontend", "exception: %r" % e)
        return {}

    def _thread_loop(self):
        self._do_update()
        rapid_polls = 0
        while not self._stop_event.is_set():
            try:
                if _in_standby():
                    self._force_event.wait(1.0)
                    continue

                force = self._force_event.is_set()
                if force:
                    self._force_event.clear()

                current_ref = self._get_current_service_ref()
                service_changed = (current_ref != self._current_service_ref)

                if force or service_changed:
                    self._current_service_ref = current_ref
                    with self._data_lock:
                        self.video_data = {"width": 0, "height": 0, "fps": 0, "progressive": -1}
                        self.transponder_data = {}
                    svc_info = self._fetch_service_info(current_ref)
                    if svc_info:
                        with self._data_lock:
                            if svc_info.get("width", 0) > 0:
                                self.video_data["width"] = svc_info["width"]
                            if svc_info.get("height", 0) > 0:
                                self.video_data["height"] = svc_info["height"]
                            if svc_info.get("fps", 0) > 0:
                                self.video_data["fps"] = svc_info["fps"]
                    self._do_update()
                    tp = self._fetch_frontend_info(current_ref)
                    with self._data_lock:
                        self.transponder_data = tp if tp else {}
                    # Trigger fast polling window for 1 second after zap
                    rapid_polls = 10
                else:
                    self._do_update()

                # Smart sleep: 100ms during active zaps, 1000ms during idle
                wait_time = 0.1 if rapid_polls > 0 else 1.0
                if rapid_polls > 0:
                    rapid_polls -= 1

                self._force_event.wait(wait_time)
                self._force_event.clear()
            except Exception as e:
                dbg("thread_loop", "unexpected error, continuing: %r" % e)

    def _do_update(self):
        w = self._read_proc("/proc/stb/vmpeg/0/xres", 0, is_hex=True)
        h = self._read_proc("/proc/stb/vmpeg/0/yres", 0, is_hex=True)
        fps = self._read_proc("/proc/stb/vmpeg/0/framerate", 0)
        prog = self._read_proc("/proc/stb/vmpeg/0/progressive", -1)

        with self._data_lock:
            if w > 0 and h > 0:
                self.video_data["width"] = w
                self.video_data["height"] = h
            if fps > 0:
                self.video_data["fps"] = fps
            if prog != -1:
                self.video_data["progressive"] = prog

_background_prober = _BackgroundProber()

# ----------------------------------------------------------------------------
#  CONVERTER CLASS
# ----------------------------------------------------------------------------
class iBase(Poll, Converter):
    FREQINFO = 0
    ORBITAL = 1
    RESCODEC = 2
    PIDINFO = 3
    PIDHEXINFO = 4
    VIDEOCODEC = 5
    FPS = 6
    VIDEOSIZE = 7
    IS1080 = 8
    IS720 = 9
    IS576 = 10
    IS1440 = 11
    IS2160 = 12
    IS480 = 13
    IS360 = 14
    IS288 = 15
    IS240 = 16
    IS144 = 17
    ISPROGRESSIVE = 18
    ISINTERLACED = 19
    STREAMURL = 20
    STREAMTYPE = 21
    ISSTREAMING = 22
    HASMPEG2 = 23
    HASAVC = 24
    HASH263 = 25
    HASVC1 = 26
    HASMPEG4VC = 27
    HASHEVC = 28
    HASMPEG1 = 29
    HASVP8 = 30
    HASVP9 = 31
    HASVP6 = 32
    HASDIVX = 33
    HASXVID = 34
    HASSPARK = 35
    HASAVS = 36
    ISSDR = 37
    ISHDR = 38
    ISHDR10 = 39
    ISHLG = 40
    HDRINFO = 41
    MEDIAINFO = 76
    VSIZEINFO = 77
    VIDEOCODECFULL = 78
    AUDIOCODEC = 79
    AUDIOCODECFULL = 80
    PROVIDERNAME = 81
    SERVICETYPE = 82
    TUNERSYSTEM = 83
    IS_SATELLITE_S = 84
    IS_SATELLITE_S2 = 85
    IS_CABLE_C = 86
    IS_CABLE_C2 = 87
    IS_TERRESTRIAL_T = 88
    IS_TERRESTRIAL_T2 = 89

    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.poll_interval = 200
        self.poll_enabled = True
        type_map = {
            "FreqInfo": self.FREQINFO,
            "Orbital": self.ORBITAL,
            "ResCodec": self.RESCODEC,
            "VideoCodec": self.VIDEOCODEC,
            "Fps": self.FPS,
            "VideoSize": self.VIDEOSIZE,
            "PidInfo": self.PIDINFO,
            "PidHexInfo": self.PIDHEXINFO,
            "Is1080": self.IS1080,
            "Is720": self.IS720,
            "Is576": self.IS576,
            "Is1440": self.IS1440,
            "Is2160": self.IS2160,
            "Is480": self.IS480,
            "Is360": self.IS360,
            "Is288": self.IS288,
            "Is240": self.IS240,
            "Is144": self.IS144,
            "IsProgressive": self.ISPROGRESSIVE,
            "IsInterlaced": self.ISINTERLACED,
            "StreamUrl": self.STREAMURL,
            "StreamType": self.STREAMTYPE,
            "IsStreaming": self.ISSTREAMING,
            "HasMPEG2": self.HASMPEG2,
            "HasAVC": self.HASAVC,
            "HasH263": self.HASH263,
            "HasVC1": self.HASVC1,
            "HasMPEG4VC": self.HASMPEG4VC,
            "HasHEVC": self.HASHEVC,
            "HasMPEG1": self.HASMPEG1,
            "HasVP8": self.HASVP8,
            "HasVP9": self.HASVP9,
            "HasVP6": self.HASVP6,
            "HasDIVX": self.HASDIVX,
            "HasXVID": self.HASXVID,
            "HasSPARK": self.HASSPARK,
            "HasAVS": self.HASAVS,
            "IsSDR": self.ISSDR,
            "IsHDR": self.ISHDR,
            "IsHDR10": self.ISHDR10,
            "IsHLG": self.ISHLG,
            "HDRInfo": self.HDRINFO,
            "MediaInfo": self.MEDIAINFO,
            "VsizeInfo": self.VSIZEINFO,
            "VideoCodecFull": self.VIDEOCODECFULL,
            "AudioCodec": self.AUDIOCODEC,
            "AudioCodecFull": self.AUDIOCODECFULL,
            "ProviderName": self.PROVIDERNAME,
            "ServiceType": self.SERVICETYPE,
            "TunerSystem": self.TUNERSYSTEM,
            "IsSatelliteS": self.IS_SATELLITE_S,
            "IsSatelliteS2": self.IS_SATELLITE_S2,
            "IsCableC": self.IS_CABLE_C,
            "IsCableC2": self.IS_CABLE_C2,
            "IsTerrestrialT": self.IS_TERRESTRIAL_T,
            "IsTerrestrialT2": self.IS_TERRESTRIAL_T2,
        }
        self.type = type_map.get(type, self.FREQINFO)

    def _get_video_data(self):
        vdata, _ = _background_prober.get_data()
        return vdata

    def _get_transponder_data(self):
        _, tp = _background_prober.get_data()
        return tp

    def _get_reference(self):
        try:
            if NavigationInstance.instance is None:
                return None
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        except Exception:
            return None

    def _get_stream_info(self):
        ref = self._get_reference()
        if not ref:
            return "", ""
        refstr = ref.toString()
        url = ""
        stype = ""
        if "%3a" in refstr or "http" in refstr.lower():
            for proto in ("http://", "https://"):
                if proto in refstr:
                    url = refstr[refstr.find(proto):].replace("http://", "").replace("https://", "")
                    url = url.split("/1:0:")[0].split("/")[0].split("@")[-1]
                    if len(url) > 80:
                        url = url[:79] + "..."
                    break
            if not refstr.startswith("1:0:"):
                stype = "IPTV/Non-TS Stream"
            elif "http" in refstr:
                stype = "IPTV/TS Stream"
        return url, stype

    def videowidth(self, info):
        vdata = self._get_video_data()
        w = vdata.get("width", 0)
        if w > 0:
            return w
        return info.getInfo(iServiceInformation.sVideoWidth) or 0

    def videoheight(self, info):
        vdata = self._get_video_data()
        h = vdata.get("height", 0)
        if h > 0:
            return h
        return info.getInfo(iServiceInformation.sVideoHeight) or 0

    def proginfo(self, info):
        vdata = self._get_video_data()
        prog = vdata.get("progressive", -1)
        if prog != -1:
            return "p" if prog == 1 else "i"
        h = self.videoheight(info)
        if h in (720, 1080, 2160, 1440):
            return "p"
        return "i"

    def videosize(self, info):
        w = self.videowidth(info)
        h = self.videoheight(info)
        prog = self.proginfo(info)
        if w > 0 and h > 0:
            return "%sx%s%s" % (w, h, prog)
        return ""

    def framerate(self, info):
        vdata = self._get_video_data()
        fps = vdata.get("fps", 0)
        if fps > 0:
            return "%.3f fps" % (fps / 1000.0)
        fps_info = info.getInfo(iServiceInformation.sFrameRate)
        if fps_info > 0:
            return "%.3f fps" % (fps_info / 1000.0)
        return ""

    def videocodec(self, info):
        vtype = info.getInfo(iServiceInformation.sVideoType)
        return CODECS.get(vtype, "N/A")

    def videocodec_full(self, info):
        vtype = info.getInfo(iServiceInformation.sVideoType)
        full_map = {7: "HEVC (H.265)", 1: "AVC (H.264)", 0: "MPEG-2", 22: "AV1", 23: "VVC (H.266)", 24: "AV2"}
        return full_map.get(vtype, self.videocodec(info))

    def hdr(self, info):
        gamma = info.getInfo(iServiceInformation.sGamma)
        return HDR_MAP.get(gamma, "SDR")

    def audio_codec(self, service, simple=True):
        if not service:
            return _("unknown")
        try:
            audio = service.audioTracks()
            if not audio:
                return _("unknown")
            ct = audio.getCurrentTrack()
            if ct < 0:
                return _("unknown")
            i = audio.getTrackInfo(ct)
            if not i:
                return _("unknown")
            languages = i.getLanguage() or ""
            desc = i.getDescription() or ""
            if "rus" in languages or "Russian" in languages or "ru" in languages:
                languages = "rus"
            elif "org" in languages:
                languages = _("Original")
            if simple:
                return ("%s %s" % (desc, languages)).strip()
            if "AC3" in desc:
                full_name = "AC3 (Dolby Digital)"
            elif "EAC3" in desc or "DD+" in desc:
                full_name = "E-AC3 (Dolby Digital Plus)"
            elif "DTS" in desc:
                full_name = "DTS"
            elif "PCM" in desc:
                full_name = "PCM"
            elif "MPEG" in desc:
                full_name = "MPEG Audio"
            elif "AAC" in desc:
                full_name = "AAC"
            else:
                full_name = desc
            return ("%s %s" % (full_name, languages)).strip()
        except Exception:
            return _("unknown")

    def frequency(self, tp):
        freq = (tp.get("frequency") + 500) // 1000 if tp.get("frequency") else 0
        return str(freq) if freq else ""

    def terrafreq(self, tp):
        return str((tp.get("frequency", 0) + 1) // 1000000)

    def symbolrate(self, tp):
        return str(tp.get("symbol_rate", 0) // 1000)

    def polarization(self, tpinfo):
        return tpinfo.get("polarization_abbreviation", "")

    def fecinfo(self, tpinfo):
        return tpinfo.get("fec_inner", "")

    def system(self, tpinfo):
        return tpinfo.get("system", "")

    def modulation(self, tpinfo):
        return tpinfo.get("modulation", "")

    def constellation(self, tpinfo):
        return tpinfo.get("constellation", "")

    def tunertype(self, tp):
        return tp.get("tuner_type", "")

    def channel(self, tpinfo):
        return tpinfo.get("channel", "")

    def multistream(self, tpinfo, tp):
        isid = tpinfo.get("is_id", 0)
        plscode = tpinfo.get("pls_code", 0)
        plsmode = tpinfo.get("pls_mode", None)
        parts = []
        if isid and isid != 0 and isid != "None" and isid != "-1":
            parts.append("IS:%s" % isid)
        if plsmode and plsmode not in ("None", "Unknown"):
            if not (plscode == 0 and plsmode == "Gold") and not (plscode == 1 and plsmode == "Root"):
                parts.append("%s" % plsmode)
                if plscode and plscode != 0:
                    parts.append("%s" % plscode)
        return " ".join(parts)

    def t2mi_info(self, tpinfo, tp):
        t2mi_id = tpinfo.get("t2mi_plp_id", -1)
        t2mi_pid = tpinfo.get("t2mi_pid", 0)
        parts = []
        if t2mi_id not in (None, -1, "None", "-1"):
            parts.append("T2MI PLP %s" % t2mi_id)
            if t2mi_pid and t2mi_pid != 0 and t2mi_pid != "None":
                parts.append("PID %s" % t2mi_pid)
        return " ".join(parts)

    def satname(self, tp):
        return tp.get("cached_satname", "Satellite")

    def orbital(self, tp):
        return tp.get("cached_orbital", "")

    def pidstring(self, info):
        parts = []
        for label, val in [
            ("VPID", info.getInfo(iServiceInformation.sVideoPID)),
            ("APID", info.getInfo(iServiceInformation.sAudioPID)),
            ("SID", info.getInfo(iServiceInformation.sSID)),
            ("PCR", info.getInfo(iServiceInformation.sPCRPID)),
            ("PMT", info.getInfo(iServiceInformation.sPMTPID)),
            ("TSID", info.getInfo(iServiceInformation.sTSID)),
            ("ONID", info.getInfo(iServiceInformation.sONID))
        ]:
            if val >= 0:
                parts.append("%s:%s" % (label, str(val).zfill(4)))
        return " ".join(parts)

    def pidhexstring(self, info):
        parts = []
        for label, val in [
            ("VPID", info.getInfo(iServiceInformation.sVideoPID)),
            ("APID", info.getInfo(iServiceInformation.sAudioPID)),
            ("SID", info.getInfo(iServiceInformation.sSID)),
            ("PMT", info.getInfo(iServiceInformation.sPMTPID))
        ]:
            if val >= 0:
                parts.append("%s:%s" % (label, hex(val)[2:].upper().zfill(4)))
        return " ".join(parts)

    # ------------------------------------------------------------------------
    #  getText
    # ------------------------------------------------------------------------
    @cached
    def getText(self):
        if not _is_xdreamy_active():
            return ""
        service = self.source.service
        info = service and service.info()
        if not info:
            return ""

        tp = self._get_transponder_data()
        tpinfo = tp.get("cached_tpinfo", tp) if tp else None

        t = self.type

        if t == self.VIDEOCODEC:
            return self.videocodec(info)
        if t == self.VIDEOCODECFULL:
            return self.videocodec_full(info)
        if t == self.FPS:
            return self.framerate(info)
        if t == self.VIDEOSIZE:
            return self.videosize(info)
        if t == self.RESCODEC:
            vs = self.videosize(info)
            fps = self.framerate(info)
            vc = self.videocodec(info)
            if not vs and not fps and not vc:
                return ""
            return "%s  %s  %s" % (vs, fps, vc)
        if t == self.HDRINFO:
            return self.hdr(info)
        if t == self.VSIZEINFO:
            vs = self.videosize(info) or "N/A"
            fps = self.framerate(info) or "N/A"
            hdr = self.hdr(info)
            vc = self.videocodec(info)
            ac = self.audio_codec(service, simple=True)
            return "%s | %s | %s | %s | %s" % (vs, fps, hdr, vc, ac)
        if t == self.MEDIAINFO:
            vs = self.videosize(info) or "N/A"
            fps = self.framerate(info) or "N/A"
            vc = self.videocodec(info)
            ac = self.audio_codec(service, simple=True)
            hdr = self.hdr(info)
            return "%s %s | %s | %s | %s" % (vs, fps, vc, ac, hdr)

        if t == self.AUDIOCODEC:
            return self.audio_codec(service, simple=True)
        if t == self.AUDIOCODECFULL:
            return self.audio_codec(service, simple=False)

        if t == self.PROVIDERNAME:
            return info.getInfoString(iServiceInformation.sProvider) or ""
        if t == self.SERVICETYPE:
            url, _ = self._get_stream_info()
            return "IPTV" if url else "DVB"
        if t == self.TUNERSYSTEM:
            if not tp:
                return ""
            sys = tpinfo.get("system") if tpinfo else None
            if not sys:
                sys = tp.get("system", tp.get("tuner_type", ""))
            return "IP-TV" if self._get_stream_info()[0] else str(sys)

        if t == self.FREQINFO:
            url, _ = self._get_stream_info()
            if url:
                return url
            if not tp:
                return ""
            if "DVB-S" in self.tunertype(tp):
                satf = "%s %s %s %s %s %s" % (
                    self.system(tpinfo) or tp.get("system", ""),
                    self.modulation(tpinfo) or tp.get("modulation", ""),
                    self.frequency(tp),
                    self.polarization(tpinfo) or tp.get("polarization_abbreviation", ""),
                    self.symbolrate(tp),
                    self.fecinfo(tpinfo) or tp.get("fec_inner", "")
                )
                ms = self.multistream(tpinfo, tp)
                t2 = self.t2mi_info(tpinfo, tp)
                if ms or t2:
                    return "%s %s %s" % (satf, ms, t2)
                return satf
            elif "DVB-C" in self.tunertype(tp):
                return "%s Mhz %s SR: %s FEC: %s" % (
                    self.frequency(tp),
                    self.modulation(tpinfo) or tp.get("modulation", ""),
                    self.symbolrate(tp),
                    self.fecinfo(tpinfo) or tp.get("fec_inner", "")
                )
            elif "DVB-T" in self.tunertype(tp):
                return "%s (%s Mhz) %s %s" % (
                    self.channel(tpinfo) or tp.get("channel", ""),
                    self.terrafreq(tp),
                    self.constellation(tpinfo) or tp.get("constellation", ""),
                    self.fecinfo(tpinfo) or tp.get("fec_inner", "")
                )
            else:
                return ""

        if t == self.ORBITAL:
            url, stype = self._get_stream_info()
            if url:
                return stype
            if not tp:
                return ""
            if "DVB-S" in self.tunertype(tp):
                return "%s (%s)" % (self.satname(tp), self.orbital(tp))
            else:
                return self.system(tpinfo) or tp.get("system", "")

        if t == self.PIDINFO:
            return self.pidstring(info)
        if t == self.PIDHEXINFO:
            return self.pidhexstring(info)

        if t == self.STREAMURL:
            url, _ = self._get_stream_info()
            return url
        if t == self.STREAMTYPE:
            _, stype = self._get_stream_info()
            return stype

        return ""

    text = property(getText)

    # ------------------------------------------------------------------------
    #  getBoolean
    # ------------------------------------------------------------------------
    @cached
    def getBoolean(self):
        if not _is_xdreamy_active():
            return False
        service = self.source.service
        info = service and service.info()
        if not info:
            return False

        xresol = self.videowidth(info)
        yresol = self.videoheight(info)
        progrs = self.proginfo(info)
        vcodec = self.videocodec(info)
        hdr = self.hdr(info)
        url, _ = self._get_stream_info()

        t = self.type
        if t == self.IS1080:
            return (900 <= yresol <= 1090) if yresol > 0 else (1880 <= xresol <= 2000)
        if t == self.IS720:
            return (601 <= yresol <= 740) if yresol > 0 else (1240 <= xresol <= 1300)
        if t == self.IS576:
            return (501 <= yresol <= 600) if yresol > 0 else (700 <= xresol <= 1030)
        if t == self.IS1440:
            return (1430 <= yresol <= 1450) if yresol > 0 else (2550 <= xresol <= 2570)
        if t == self.IS2160:
            return (2150 <= yresol <= 2170) if yresol > 0 else (3820 <= xresol <= 4100)
        if t == self.IS480:
            return 380 <= yresol <= 500
        if t == self.IS360:
            return 300 <= yresol <= 379
        if t == self.IS288:
            return 261 <= yresol <= 299
        if t == self.IS240:
            return 181 <= yresol <= 260
        if t == self.IS144:
            return 120 <= yresol <= 180
        if t == self.ISPROGRESSIVE:
            return progrs == "p"
        if t == self.ISINTERLACED:
            return progrs == "i"
        if t == self.ISSTREAMING:
            return bool(url)

        # Codec checks
        if t == self.HASMPEG2:
            return vcodec == "MPEG2"
        if t == self.HASAVC:
            return vcodec in ("AVC", "MPEG4")
        if t == self.HASH263:
            return vcodec == "H263"
        if t == self.HASVC1:
            return "VC1" in vcodec
        if t == self.HASMPEG4VC:
            return vcodec == "MPEG4-VC"
        if t == self.HASHEVC:
            return vcodec in ("HEVC", "H265")
        if t == self.HASMPEG1:
            return vcodec == "MPEG1"
        if t == self.HASVP8:
            return vcodec in ("VP8", "VB8")
        if t == self.HASVP9:
            return vcodec in ("VP9", "VB9")
        if t == self.HASVP6:
            return vcodec in ("VP6", "VB6")
        if t == self.HASDIVX:
            return "DIVX" in vcodec
        if t == self.HASXVID:
            return "XVID" in vcodec
        if t == self.HASSPARK:
            return vcodec == "SPARK"
        if t == self.HASAVS:
            return "AVS" in vcodec

        # HDR
        if t == self.ISSDR:
            return hdr == "SDR"
        if t == self.ISHDR:
            return hdr == "HDR"
        if t == self.ISHDR10:
            return hdr == "HDR10"
        if t == self.ISHLG:
            return hdr == "HLG"

        # DVB type booleans (Instant Dictionary Lookups)
        if t in (self.IS_SATELLITE_S, self.IS_SATELLITE_S2,
                 self.IS_CABLE_C, self.IS_CABLE_C2,
                 self.IS_TERRESTRIAL_T, self.IS_TERRESTRIAL_T2):
            tp = self._get_transponder_data()
            if not tp:
                return False
            if t == self.IS_SATELLITE_S:
                return tp.get("cached_is_s", False)
            if t == self.IS_SATELLITE_S2:
                return tp.get("cached_is_s2", False)
            if t == self.IS_CABLE_C:
                return tp.get("cached_is_c", False)
            if t == self.IS_CABLE_C2:
                return tp.get("cached_is_c2", False)
            if t == self.IS_TERRESTRIAL_T:
                return tp.get("cached_is_t", False)
            if t == self.IS_TERRESTRIAL_T2:
                return tp.get("cached_is_t2", False)
            return False

        return False

    boolean = property(getBoolean)

    def changed(self, what):
        if what[0] == self.CHANGED_SPECIFIC:
            if what[1] in (iPlayableService.evStart, iPlayableService.evUpdatedInfo):
                _background_prober.force_update()
        Converter.changed(self, what)