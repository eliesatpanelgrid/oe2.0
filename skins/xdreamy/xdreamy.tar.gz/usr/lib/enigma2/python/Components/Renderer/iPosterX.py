#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iPosterX.py - XDREAMY SKIN V7.1
Python 3 only. Poster/logo display. Shared cache, skin-attr parsing, and
EPG-slot preamble now live in iRendererBase -- this file only does the
poster/logo-specific work.
"""

import os

from Components.Renderer.Renderer import Renderer
from enigma import ePixmap

from .iConverlibr import get_poster_folder, get_logo_folder, file_exists_indexed, build_emc_candidates, is_activated, get_fallback_pixmap
from .iRendererBase import RendererMixin, PixmapCache, parse_nxts_attribute
from .iDownloadThread import get_predecoded_pixmap as _get_predecoded
from .iDebugger import traced, dbg

_pixmap_cache = PixmapCache(max_entries=50)

class iPosterX(RendererMixin, Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        RendererMixin.__init__(self)
        self.mode = "poster"

    def destroy(self):
        self.mixin_destroy()
        Renderer.destroy(self)

    def applySkin(self, desktop, parent):
        self.nxts = parse_nxts_attribute(self.skinAttributes)
        for attrib, value in self.skinAttributes:
            if attrib == "mode":
                self.mode = str(value) if value in ("poster", "logo") else "poster"
        self.mixin_apply_skin(self.mode)
        return Renderer.applySkin(self, desktop, parent)

    @traced("iPosterX")
    def changed(self, what):
        if not self.instance:
            return
        if not is_activated():
            self._show_empty()
            return

        if what[0] == self.CHANGED_CLEAR:
            self.mixin_clear()
            self._show_empty()
            return

        branch, payload = self.resolve_slot()
        if branch == "same":
            return
        if branch == "media":
            self._handle_media(payload)
            return
        if branch == "no_service":
            self._show_empty()
            return

        preamble = self.epg_slot_preamble(payload)
        if preamble is None:
            self._show_empty()
            return
        if preamble == "same":
            return
        event_key, clean_title = preamble

        if self.mode == "logo":
            self._display_logo_slot(payload, clean_title, event_key)
        else:
            self._display_poster_slot(payload, clean_title, event_key)

    def _handle_media(self, media):
        movie_path = media["movie_path"]
        clean_title = media["clean_title"]
        ext = ".jpg" if self.mode == "poster" else ".png"
        sidecar = self.get_sidecar_if_valid(movie_path, ".jpg") if self.mode == "poster" else None
        if sidecar:
            self._show_file(sidecar)
            return
        if not clean_title:
            self._show_empty()
            return
        folder = get_poster_folder() if self.mode == "poster" else get_logo_folder()
        fname = clean_title + ext
        dest = os.path.join(folder, fname)
        if file_exists_indexed(folder, fname):
            self._show_file(dest)
            return
        candidates = build_emc_candidates(movie_path)
        self.request_and_wait(self.mode, clean_title, os.path.basename(movie_path), candidates, emc_mode=True, priority=1)
        self._show_empty()

    def _display_poster_slot(self, slot, clean_title, event_key):
        local_path = self.resolve_asset_for_display(
            slot, "local_path", get_poster_folder, ".jpg", "poster", clean_title, event_key, priority=1)
        if local_path:
            self._show_file(local_path)
            return
        self._show_empty()

    def _display_logo_slot(self, slot, clean_title, event_key):
        logo_path = self.resolve_asset_for_display(
            slot, "logo_path", get_logo_folder, ".png", "logo", clean_title, event_key, priority=2)
        if logo_path:
            self._show_file(logo_path)
            return
        self._hide()

    def on_asset_ready(self, kind, clean_title, path):
        if kind != self.mode:
            return
        if not self.handle_asset_ready(kind, clean_title, path):
            return
        if not self.instance:
            return
        dbg("iPosterX", "asset-ready", "kind=%s title=%s" % (kind, clean_title))
        self._show_file(path)

    def _show_file(self, path):
        try:
            if not path:
                self._show_empty()
                return
            is_png = (self.mode == "logo")
            pix = _get_predecoded(path) or _pixmap_cache.get(path, is_png=is_png)
            if pix:
                self.instance.setPixmap(pix)
                self.instance.setScale(1)
                self.instance.show()
            else:
                self._show_empty()
        except Exception as e:
            dbg("iPosterX", "load-error", str(e))
            self._show_empty()

    def _hide(self):
        try:
            self.instance.hide()
        except Exception:
            pass

    def _show_empty(self):
        if self.mode == "logo":
            self._hide()
            return
        pix = get_fallback_pixmap("noposter.jpg")
        try:
            if pix:
                self.instance.setPixmap(pix)
                self.instance.setScale(1)
                self.instance.show()
            else:
                self.instance.show()
        except Exception:
            pass