#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iPosterX.py - XDREAMY SKIN V6.6.0
POSTER DISPLAY RENDERER - Uses unified helpers from iConverlibr
"""

from __future__ import absolute_import, print_function

import os
import sys
import threading

from Components.Renderer.Renderer import Renderer
from Components.Sources.CurrentService import CurrentService
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.ServiceEvent import ServiceEvent
from Components.config import config
from ServiceReference import ServiceReference
from enigma import ePixmap, loadJPG, eEPGCache
import NavigationInstance

from .iConverlibr import (
    analyze_event_name,
    is_sport_or_news_channel,
    is_sport_or_news_event,
    get_cached_clean_title,
    clean_name,
    direct_poster_path
)
from .iPosterXDownloadThread import (
    queue_live,
    path_folder,
    log,
    register_renderer_callback,
    unregister_renderer
)

epgcache = eEPGCache.getInstance()

# Default no-poster image
try:
    _cur_skin = config.skin.primary_skin.value.replace("/skin.xml", "")
except Exception:
    _cur_skin = "default"

noposter = None
for _name in ["noposter.jpg", "nobackdrop.jpg"]:
    for _path in [
        "/usr/share/enigma2/%s/main/%s" % (_cur_skin, _name),
        "/usr/share/enigma2/skin_default/main/%s" % _name,
        "/tmp/%s" % _name,
    ]:
        if os.path.exists(_path):
            noposter = _path
            break
    if noposter:
        break

_noposter_pixmap = None
_noposter_lock = threading.Lock()


def get_noposter_pixmap():
    global _noposter_pixmap
    if _noposter_pixmap is None:
        with _noposter_lock:
            if _noposter_pixmap is None and noposter and os.path.exists(noposter):
                try:
                    _noposter_pixmap = loadJPG(noposter)
                except Exception:
                    _noposter_pixmap = None
    return _noposter_pixmap


class iPosterX(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.nxts = 0
        self.path = path_folder
        self._old_key = None
        self._waiting_key = None

    def applySkin(self, desktop, parent):
        keep = []
        for attrib, value in self.skinAttributes:
            if attrib == "nexts":
                try:
                    self.nxts = int(value)
                except Exception:
                    self.nxts = 0
            elif attrib == "path":
                self.path = str(value)
            keep.append((attrib, value))
        self.skinAttributes = keep
        return Renderer.applySkin(self, desktop, parent)

    def _read_canal(self):
        canal = [None] * 6
        src_type = type(self.source)
        service = None

        if src_type is Event:
            if self.nxts:
                service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
            else:
                evt = self.source.event
                if not evt:
                    return None
                name = clean_name(evt.getEventName())
                canal[1] = evt.getBeginTime()
                canal[2] = name
                canal[3] = evt.getExtendedDescription()
                canal[4] = evt.getShortDescription()
                canal[5] = name
                return canal
        elif src_type is ServiceEvent:
            service = self.source.getCurrentService()
        elif src_type is CurrentService:
            service = self.source.getCurrentServiceRef()
        elif src_type is EventInfo:
            service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        else:
            return None

        if service is None:
            return None

        sref = service.toString()
        try:
            events = epgcache.lookupEvent(["IBOCTESX", (sref, 0, -1, -1)])
        except Exception:
            events = None

        if not events or len(events) <= self.nxts:
            return None

        evt = events[self.nxts]
        if len(evt) < 5 or not evt[4]:
            return None

        try:
            ch = clean_name(ServiceReference(service).getServiceName())
        except Exception:
            ch = ""

        canal[0] = ch
        canal[1] = evt[1]
        canal[2] = clean_name(evt[4])
        canal[3] = evt[5] if len(evt) > 5 else None
        canal[4] = evt[4]
        canal[5] = canal[2]
        return canal

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._cleanup()
            self._old_key = None
            self._show_noposter()
            return

        try:
            canal = self._read_canal()
        except Exception as e:
            log("[RENDERER-POSTER] read_canal error: %s" % e, "WARN")
            self._cleanup()
            self._old_key = None
            self._show_noposter()
            return

        if not canal or not canal[5]:
            self._cleanup()
            self._old_key = None
            self._show_noposter()
            return

        event_key = "%s-%s" % (canal[1], canal[5])
        if event_key == self._old_key:
            return

        self._cleanup()
        self._old_key = event_key

        if is_sport_or_news_channel(canal[0]) or is_sport_or_news_event(canal[5]):
            self._show_noposter()
            return

        raw_name = canal[5]
        info = analyze_event_name(raw_name)

        if info.get("skip"):
            self._show_noposter()
            return

        clean_title = info.get("cache_title") or get_cached_clean_title(raw_name)
        if not clean_title:
            self._show_noposter()
            return

        local_path = direct_poster_path(clean_title, self.path)
        if local_path and os.path.exists(local_path):
            self._show_file(local_path)
            return

        self._show_noposter()
        self._waiting_key = clean_title
        register_renderer_callback(clean_title, self)
        queue_live(clean_title, canal, info.get("search_candidates", []))

    def poster_download_completed(self, clean_title, path=None):
        if path is None:
            path = clean_title
            clean_title = self._waiting_key
        if not clean_title or clean_title != self._waiting_key:
            return
        if not path or not os.path.exists(path):
            return
        self._waiting_key = None
        self._show_file(path)

    def _cleanup(self):
        if self._waiting_key:
            unregister_renderer(self._waiting_key, self)
            self._waiting_key = None

    def _show_file(self, path):
        try:
            if not path or not os.path.exists(path):
                self._show_noposter()
                return
            self.instance.setPixmap(loadJPG(path))
            self.instance.setScale(1)
            self.instance.show()
        except Exception as e:
            log("[RENDERER-POSTER] loadJPG error: %s" % e, "WARN")
            self._show_noposter()

    def _show_noposter(self):
        pix = get_noposter_pixmap()
        if pix:
            try:
                self.instance.setPixmap(pix)
                self.instance.setScale(1)
                self.instance.show()
                return
            except Exception:
                pass
        if noposter and os.path.exists(noposter):
            try:
                self.instance.setPixmap(loadJPG(noposter))
                self.instance.setScale(1)
                self.instance.show()
                return
            except Exception:
                pass
        try:
            self.instance.show()
        except Exception:
            pass