#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iPosterX.py - XDREAMY SKIN V6.8.0
POSTER DISPLAY RENDERER

Uses get_zap_context() — ONE EPG + ONE JSON + ONE batch disk check
per zap, shared by ALL poster widgets. Zero independent I/O.

V6.8 fixes:
 - destroy() now unregisters any pending download callback (was missing,
   so a poster still downloading when the widget was torn down used to
   leak a reference to this renderer forever in the downloader's callback
   table).
 - _get_service_ref() is resolved once per changed() call instead of twice.
"""

from __future__ import absolute_import, print_function

import os
import threading

from Components.Renderer.Renderer import Renderer
from Components.Sources.CurrentService import CurrentService
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.ServiceEvent import ServiceEvent
from Components.config import config
from ServiceReference import ServiceReference
from enigma import ePixmap, loadJPG
import NavigationInstance

from .iConverlibr import (
    get_zap_context,
    is_sport_or_news_channel,
    clean_name,
    convtext,
    register_nxts_slot,
)
from .iPosterXDownloadThread import (
    queue_live,
    path_folder,
    log,
    register_renderer_callback,
    unregister_renderer,
)
from .iDebugTrace import trace  # DEBUG TRACE - remove this line + trace(...) calls when done diagnosing

# ── no-poster image (resolved once at startup) ────────────────────────────────
try:
    _cur_skin = config.skin.primary_skin.value.replace("/skin.xml", "")
except Exception:
    _cur_skin = "default"

noposter = None
for _name in ["noposter.jpg", "nobackdrop.jpg"]:
    for _path in [
        "/usr/share/enigma2/%s/main/%s" % (_cur_skin, _name),
        "/usr/share/enigma2/skin_default/main/%s" % _name,
        "/tmp/%s" % _name,
    ]:
        if os.path.exists(_path):
            noposter = _path
            break
    if noposter:
        break

# Noposter loaded once, reused — avoids repeated loadJPG on the same file
_noposter_pixmap = None
_noposter_lock   = threading.Lock()


def _get_noposter_pixmap():
    global _noposter_pixmap
    if _noposter_pixmap is None:
        with _noposter_lock:
            if _noposter_pixmap is None and noposter and os.path.exists(noposter):
                try:
                    _noposter_pixmap = loadJPG(noposter)
                except Exception:
                    pass
    return _noposter_pixmap


class iPosterX(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.nxts         = 0
        self.path         = path_folder
        self._old_key     = None
        self._waiting_key = None
        # Renderer-side dedup: skip the entire get_zap_context() round trip
        # (and therefore the EPG/JSON/build work it can trigger on a cache
        # miss) when nothing has actually changed since our last visit to
        # this exact channel+context-generation. The trace log showed this
        # was the dominant cost in the whole session: 184 genuine zaps but
        # 3333 total changed() calls — most of them re-deriving the same
        # "nothing to do here" conclusion for a context that hadn't
        # changed. event_key dedup (further below) still catches same-
        # widget repeats, but only AFTER paying for the context lookup;
        # this catches it BEFORE.
        self._last_ref = None
        self._last_generation = -1

    def destroy(self):
        self._cleanup()
        Renderer.destroy(self)

    def applySkin(self, desktop, parent):
        keep = []
        for attrib, value in self.skinAttributes:
            if attrib == "nexts":
                try:
                    self.nxts = int(value)
                except Exception:
                    self.nxts = 0
            elif attrib == "path":
                self.path = str(value)
            keep.append((attrib, value))
        self.skinAttributes = keep
        register_nxts_slot(self.nxts)
        return Renderer.applySkin(self, desktop, parent)

    # ── service ref resolution ────────────────────────────────────────────────

    def _get_service_ref(self):
        src   = self.source
        stype = type(src)
        if stype is Event and self.nxts:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if stype is ServiceEvent:
            return src.getCurrentService()
        if stype is CurrentService:
            return src.getCurrentServiceRef()
        if stype is EventInfo:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return None

    def _read_from_event_source(self):
        """Direct read for nxts=0 Event source — no EPG lookup needed."""
        try:
            evt = self.source.event
            if not evt:
                return None
            raw        = clean_name(evt.getEventName())
            clean      = convtext(raw)
            if not clean:
                return None
            local_path = os.path.join(self.path, clean + '.jpg')
            return {
                'clean_title':       clean,
                'local_path':        local_path if os.path.exists(local_path) else None,
                'skip':              False,
                'search_candidates': [clean],
                'event_key':         '%s-%s' % (evt.getBeginTime(), raw),
                'raw_name':          raw,
                'description':       evt.getExtendedDescription() or "",
            }
        except Exception:
            return None

    # ── main changed() ────────────────────────────────────────────────────────

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._cleanup()
            self._old_key = None
            self._last_ref = None
            self._last_generation = -1
            self._show_noposter()
            return

        trace("iPosterX", "changed-enter", "nxts=%d" % self.nxts)  # DEBUG TRACE

        # ── resolve slot ──────────────────────────────────────────────────────
        slot = None
        service = None

        if type(self.source) is Event and self.nxts == 0:
            # Direct event source — no ZapContext needed
            slot = self._read_from_event_source()
        else:
            # All other sources: use ZapContext.
            # Widget 0 builds it (EPG + batch exists + JSON) ~5-15ms.
            # Widgets 1-9 find it already built — instant dict read.
            try:
                service = self._get_service_ref()
                if service is None:
                    self._show_noposter()
                    return
                ctx  = get_zap_context(service)
                if ctx is None:
                    self._show_noposter()
                    return

                # Generation dedup: the trace log showed 184 genuine zaps
                # producing 3333 total changed() calls — most of them
                # Enigma2 re-invoking changed() on the same widget for a
                # context that hadn't changed at all (same ref, same
                # generation). The event_key dedup further below still
                # catches same-key repeats, but only after already paying
                # for get_slot() + the skip-check + cleanup logic on every
                # one of those calls. This catches it earlier: if we've
                # already fully processed this exact (ref, generation)
                # pair before, there is nothing new to compute at all.
                ref_str = ctx.ref_str
                if ref_str == self._last_ref and ctx.generation == self._last_generation:
                    trace("iPosterX", "changed-exit", "nxts=%d reason=same-generation" % self.nxts)  # DEBUG TRACE
                    return
                self._last_ref = ref_str
                self._last_generation = ctx.generation

                slot = ctx.get_slot(self.nxts)
            except Exception as e:
                log("[iPosterX] context error: %s" % e, "WARN")
                self._show_noposter()
                return

        if not slot or slot.get('skip'):
            self._cleanup()
            self._old_key = None
            self._show_noposter()
            trace("iPosterX", "changed-exit", "nxts=%d reason=no-slot-or-skip" % self.nxts)  # DEBUG TRACE
            return

        # ── dedup guard ───────────────────────────────────────────────────────
        event_key = slot.get('event_key', '')
        if event_key == self._old_key:
            trace("iPosterX", "changed-exit", "nxts=%d reason=dedup-same-key" % self.nxts)  # DEBUG TRACE
            return

        self._cleanup()
        self._old_key = event_key

        # ── sport/news channel check (reuses the service ref resolved above —
        #    no second _get_service_ref() call needed) ──────────────────────
        try:
            if service is None:
                service = self._get_service_ref()
            if service:
                ch = clean_name(ServiceReference(service).getServiceName())
                if is_sport_or_news_channel(ch):
                    self._show_noposter()
                    trace("iPosterX", "changed-exit", "nxts=%d reason=sport-news-skip" % self.nxts)  # DEBUG TRACE
                    return
        except Exception:
            pass

        clean_title = slot.get('clean_title', '')
        local_path  = slot.get('local_path')

        if not clean_title:
            self._show_noposter()
            trace("iPosterX", "changed-exit", "nxts=%d reason=no-clean-title" % self.nxts)  # DEBUG TRACE
            return

        # ── poster on disk ────────────────────────────────────────────────────
        # local_path is already the result of ZapContext's ONE batched
        # os.path.exists() check (done once per unique title, shared by
        # every poster widget). Trust it directly instead of re-stating the
        # same file here — re-checking per-widget defeats the point of the
        # batch check and was adding redundant disk I/O on every zap,
        # multiplied by however many poster widgets (nxts 0..9) the skin
        # has, which is part of why posters could feel like they loaded
        # "gradually" instead of all at once even when already on disk.
        if local_path:
            self._show_file(local_path, known_to_exist=True)
            trace("iPosterX", "changed-exit", "nxts=%d title=%s reason=shown-from-batch-cache" % (self.nxts, clean_title))  # DEBUG TRACE
            return

        # ── not on disk: show noposter and queue download ─────────────────────
        self._show_noposter()
        self._waiting_key = clean_title
        register_renderer_callback(clean_title, self)

        canal = [
            "",
            slot.get('event_key', ''),
            slot.get('raw_name', ''),
            slot.get('description', ''),
            slot.get('raw_name', ''),
            slot.get('raw_name', ''),
        ]
        queued = queue_live(clean_title, canal, slot.get('search_candidates', []))
        trace("iPosterX", "changed-exit", "nxts=%d title=%s reason=queued-download queued=%s" % (  # DEBUG TRACE
            self.nxts, clean_title, queued))

    # ── download callback ─────────────────────────────────────────────────────

    def poster_download_completed(self, clean_title, path=None):
        if path is None:
            path        = clean_title
            clean_title = self._waiting_key
        if not clean_title or clean_title != self._waiting_key:
            trace("iPosterX", "download-completed-IGNORED", "nxts=%d title=%s waiting_for=%s" % (  # DEBUG TRACE
                self.nxts, clean_title, self._waiting_key))
            return
        if not self.instance:
            self._waiting_key = None
            return
        if not path or not os.path.exists(path):
            return
        self._waiting_key = None
        trace("iPosterX", "download-completed-SHOWING", "nxts=%d title=%s" % (self.nxts, clean_title))  # DEBUG TRACE
        self._show_file(path)

    # ── internal ──────────────────────────────────────────────────────────────

    def _cleanup(self):
        if self._waiting_key:
            unregister_renderer(self._waiting_key, self)
            self._waiting_key = None

    def _show_file(self, path, known_to_exist=False):
        try:
            if not path:
                self._show_noposter()
                return
            if not known_to_exist and not os.path.exists(path):
                self._show_noposter()
                return
            self.instance.setPixmap(loadJPG(path))
            self.instance.setScale(1)
            self.instance.show()
        except Exception as e:
            log("[iPosterX] loadJPG error: %s" % e, "WARN")
            self._show_noposter()

    def _show_noposter(self):
        pix = _get_noposter_pixmap()
        if pix:
            try:
                self.instance.setPixmap(pix)
                self.instance.setScale(1)
                self.instance.show()
                return
            except Exception:
                pass
        if noposter and os.path.exists(noposter):
            try:
                self.instance.setPixmap(loadJPG(noposter))
                self.instance.setScale(1)
                self.instance.show()
                return
            except Exception:
                pass
        try:
            self.instance.show()
        except Exception:
            pass
