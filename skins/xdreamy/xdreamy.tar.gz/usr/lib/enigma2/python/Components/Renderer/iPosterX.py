#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iPosterX.py - XDREAMY SKIN V7.1.0
POSTER + LOGO DISPLAY RENDERER - register_nxts_slot, improved retry
"""

from __future__ import absolute_import, print_function

import os
import threading

from Components.Renderer.Renderer import Renderer
from Components.Sources.CurrentService import CurrentService
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.ServiceEvent import ServiceEvent
from Components.config import config
from ServiceReference import ServiceReference
from enigma import ePixmap, loadJPG, loadPNG, eTimer
import NavigationInstance

from .iConverlibr import (
    get_zap_context,
    is_sport_or_news_channel,
    clean_name,
    convtext,
    get_poster_folder,
    get_logo_folder,
    register_nxts_slot,
    _zap_ctx,
    invalidate_zap_context,
)
from .iPosterXDownloadThread import (
    queue_live,
    log,
    register_renderer_callback,
    unregister_renderer,
    register_logo_callback,
    unregister_logo_renderer,
)
from .iDebugTrace import trace

# ── no-poster image ────────────────────────────────────────────────
try:
    _cur_skin = config.skin.primary_skin.value.replace("/skin.xml", "")
except Exception:
    _cur_skin = "default"

noposter = None
for _name in ["noposter.jpg", "nobackdrop.jpg"]:
    for _path in [
        "/usr/share/enigma2/%s/main/%s" % (_cur_skin, _name),
        "/usr/share/enigma2/skin_default/main/%s" % _name,
        "/tmp/%s" % _name,
    ]:
        if os.path.exists(_path):
            noposter = _path
            break
    if noposter:
        break

_noposter_pixmap = None
_noposter_lock   = threading.Lock()


def _get_noposter_pixmap():
    global _noposter_pixmap
    if _noposter_pixmap is None:
        with _noposter_lock:
            if _noposter_pixmap is None and noposter and os.path.exists(noposter):
                try:
                    _noposter_pixmap = loadJPG(noposter)
                except Exception:
                    pass
    return _noposter_pixmap


class iPosterX(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.nxts              = 0
        self.mode              = "poster"
        self._old_key          = None
        self._waiting_key      = None
        self._waiting_logo_key = None
        self._last_ref         = None
        self._last_generation  = -1
        self._epg_retry_timer = None
        self._epg_retry_count = 0

    def destroy(self):
        self._cleanup()
        if self._waiting_logo_key:
            unregister_logo_renderer(self._waiting_logo_key, self)
            self._waiting_logo_key = None
        self._stop_epg_retry()
        Renderer.destroy(self)

    def applySkin(self, desktop, parent):
        keep = []
        for attrib, value in self.skinAttributes:
            if attrib == "nexts":
                try:
                    self.nxts = int(value)
                except Exception:
                    self.nxts = 0
            elif attrib == "mode":
                self.mode = str(value) if value in ("poster", "logo") else "poster"
            keep.append((attrib, value))
        self.skinAttributes = keep
        register_nxts_slot(self.nxts)   # <-- FIX: register for event cap
        return Renderer.applySkin(self, desktop, parent)

    def _get_service_ref(self):
        src   = self.source
        stype = type(src)
        if stype is Event and self.nxts:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if stype is ServiceEvent:
            return src.getCurrentService()
        if stype is CurrentService:
            return src.getCurrentServiceRef()
        if stype is EventInfo:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return None

    def _read_from_event_source(self):
        try:
            evt = self.source.event
            if not evt:
                return None
            raw        = clean_name(evt.getEventName())
            clean      = convtext(raw)
            if not clean:
                return None
            pfolder    = get_poster_folder()
            local_path = os.path.join(pfolder, clean + '.jpg')
            lfolder    = get_logo_folder()
            logo_path  = os.path.join(lfolder, clean + '.png')
            return {
                'clean_title':       clean,
                'local_path':        local_path if os.path.exists(local_path) else None,
                'logo_path':         logo_path if os.path.exists(logo_path) else None,
                'skip':              False,
                'search_candidates': [clean],
                'event_key':         '%s-%s' % (evt.getBeginTime(), raw),
                'raw_name':          raw,
                'description':       evt.getExtendedDescription() or "",
            }
        except Exception:
            return None

    def _stop_epg_retry(self):
        if self._epg_retry_timer:
            self._epg_retry_timer.stop()
            self._epg_retry_timer = None
        self._epg_retry_count = 0

    def _start_epg_retry(self):
        self._stop_epg_retry()
        if self._epg_retry_count >= 3:
            return
        self._epg_retry_count += 1
        self._epg_retry_timer = eTimer()
        self._epg_retry_timer.callback.append(self._epg_retry_timer_cb)
        self._epg_retry_timer.start(1000, True)

    def _epg_retry_timer_cb(self):
        self._epg_retry_timer = None
        if not self.instance:
            return
        ctx = _zap_ctx
        if ctx is None or ctx._slot_count == 0:
            invalidate_zap_context(force=True)
        self.changed((self.CHANGED_DEFAULT,))

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._cleanup()
            if self._waiting_logo_key:
                unregister_logo_renderer(self._waiting_logo_key, self)
                self._waiting_logo_key = None
            self._old_key = None
            self._last_ref = None
            self._last_generation = -1
            self._stop_epg_retry()
            if self.mode == "logo":
                try:
                    self.instance.hide()
                except Exception:
                    pass
            else:
                self._show_noposter()
            return

        trace("iPosterX", "changed-enter", "nxts=%d" % self.nxts)

        slot = None
        service = None

        if type(self.source) is Event and self.nxts == 0:
            slot = self._read_from_event_source()
            self._stop_epg_retry()
        else:
            try:
                service = self._get_service_ref()
                if service is None:
                    if self.mode == "logo":
                        try:
                            self.instance.hide()
                        except Exception:
                            pass
                    else:
                        self._show_noposter()
                    return
                ctx = get_zap_context(service)
                if ctx is None:
                    if self.mode == "logo":
                        try:
                            self.instance.hide()
                        except Exception:
                            pass
                    else:
                        self._show_noposter()
                    return

                ref_str = ctx.ref_str
                if ref_str != self._last_ref:
                    self._old_key = None
                if ref_str == self._last_ref and ctx.generation == self._last_generation:
                    trace("iPosterX", "changed-exit", "nxts=%d reason=same-generation" % self.nxts)
                    return
                self._last_ref = ref_str
                self._last_generation = ctx.generation

                slot = ctx.get_slot(self.nxts)
            except Exception as e:
                log("[iPosterX] context error: %s" % e, "WARN")
                if self.mode == "logo":
                    try:
                        self.instance.hide()
                    except Exception:
                        pass
                else:
                    self._show_noposter()
                return

        if not slot or slot.get('skip'):
            self._cleanup()
            if self._waiting_logo_key:
                unregister_logo_renderer(self._waiting_logo_key, self)
                self._waiting_logo_key = None
            self._old_key = None
            if self.mode == "logo":
                try:
                    self.instance.hide()
                except Exception:
                    pass
            else:
                self._show_noposter()
            if type(self.source) is not Event:
                self._start_epg_retry()
            trace("iPosterX", "changed-exit", "nxts=%d reason=no-slot-or-skip" % self.nxts)
            return

        self._stop_epg_retry()

        event_key = slot.get('event_key', '')
        if self._old_key is not None and event_key == self._old_key:
            trace("iPosterX", "changed-exit", "nxts=%d reason=dedup-same-key" % self.nxts)
            return

        self._cleanup()
        if self._waiting_logo_key:
            unregister_logo_renderer(self._waiting_logo_key, self)
            self._waiting_logo_key = None

        try:
            if service is None:
                service = self._get_service_ref()
            if service:
                ch = clean_name(ServiceReference(service).getServiceName())
                if is_sport_or_news_channel(ch):
                    if self.mode == "logo":
                        try:
                            self.instance.hide()
                        except Exception:
                            pass
                    else:
                        self._show_noposter()
                    trace("iPosterX", "changed-exit", "nxts=%d reason=sport-news-skip" % self.nxts)
                    return
        except Exception:
            pass

        clean_title = slot.get('clean_title', '')
        if not clean_title:
            if self.mode == "logo":
                try:
                    self.instance.hide()
                except Exception:
                    pass
            else:
                self._show_noposter()
            trace("iPosterX", "changed-exit", "nxts=%d reason=no-clean-title" % self.nxts)
            return

        if self.mode == "logo":
            logo_path = slot.get("logo_path")
            if not logo_path and clean_title:
                candidate = os.path.join(get_logo_folder(), clean_title + ".png")
                if os.path.exists(candidate):
                    logo_path = candidate

            if logo_path and os.path.exists(logo_path):
                try:
                    self.instance.setPixmap(loadPNG(logo_path))
                    self.instance.setScale(1)
                    self.instance.show()
                    self._old_key = event_key
                except Exception as e:
                    log("[iPosterX] loadPNG error: %s" % e, "WARN")
                    try:
                        self.instance.hide()
                    except Exception:
                        pass
                trace("iPosterX", "changed-exit", "nxts=%d title=%s reason=logo-shown" % (self.nxts, clean_title))
                return

            try:
                self.instance.hide()
            except Exception:
                pass

            if self._waiting_logo_key != clean_title:
                if self._waiting_logo_key:
                    unregister_logo_renderer(self._waiting_logo_key, self)
                self._waiting_logo_key = clean_title
                register_logo_callback(clean_title, self)
                queued = queue_live(clean_title,
                                    raw_name=slot.get("raw_name", ""),
                                    candidates=slot.get("search_candidates"))
                if not queued:
                    pass
            return

        local_path = slot.get('local_path')
        if not local_path and clean_title:
            pfolder = get_poster_folder()
            candidate = os.path.join(pfolder, clean_title + '.jpg')
            if os.path.exists(candidate):
                local_path = candidate

        if local_path:
            self._show_file(local_path)
            self._old_key = event_key
            trace("iPosterX", "changed-exit", "nxts=%d title=%s reason=shown" % (self.nxts, clean_title))
            return

        self._show_noposter()
        if self._waiting_key != clean_title:
            self._cleanup()
            self._waiting_key = clean_title
            register_renderer_callback(clean_title, self)

            queued = queue_live(clean_title,
                              raw_name=slot.get('raw_name', ''),
                              candidates=slot.get('search_candidates'))
            if not queued:
                pass

    def poster_download_completed(self, clean_title, path=None):
        if path is None:
            path        = clean_title
            clean_title = self._waiting_key
        if not clean_title or clean_title != self._waiting_key:
            trace("iPosterX", "download-completed-IGNORED", "nxts=%d title=%s waiting_for=%s" % (
                self.nxts, clean_title, self._waiting_key))
            return
        if not self.instance:
            self._waiting_key = None
            return
        if not path or not os.path.exists(path):
            return
        self._waiting_key = None

        self._last_ref = None
        self._last_generation = -1
        self._old_key = None

        trace("iPosterX", "poster-completed", "nxts=%d title=%s" % (self.nxts, clean_title))
        self._show_file(path)
        self.changed((self.CHANGED_DEFAULT,))

    def logo_download_completed(self, clean_title, path=None):
        if path is None:
            path        = clean_title
            clean_title = self._waiting_logo_key
        if not clean_title or clean_title != self._waiting_logo_key:
            return
        if not self.instance:
            self._waiting_logo_key = None
            return
        if not path or not os.path.exists(path):
            return
        self._waiting_logo_key = None

        self._last_ref = None
        self._last_generation = -1
        self._old_key = None

        trace("iPosterX", "logo-completed", "nxts=%d title=%s" % (self.nxts, clean_title))
        try:
            self.instance.setPixmap(loadPNG(path))
            self.instance.setScale(1)
            self.instance.show()
        except Exception as e:
            log("[iPosterX] loadPNG error: %s" % e, "WARN")
            try:
                self.instance.hide()
            except Exception:
                pass
        self.changed((self.CHANGED_DEFAULT,))

    def _cleanup(self):
        if self._waiting_key:
            unregister_renderer(self._waiting_key, self)
            self._waiting_key = None

    def _show_file(self, path):
        try:
            if not path or not os.path.exists(path):
                self._show_noposter()
                return
            self.instance.setPixmap(loadJPG(path))
            self.instance.setScale(1)
            self.instance.show()
        except Exception as e:
            log("[iPosterX] loadJPG error: %s" % e, "WARN")
            self._show_noposter()

    def _show_noposter(self):
        pix = _get_noposter_pixmap()
        if pix:
            try:
                self.instance.setPixmap(pix)
                self.instance.setScale(1)
                self.instance.show()
                return
            except Exception:
                pass
        if noposter and os.path.exists(noposter):
            try:
                self.instance.setPixmap(loadJPG(noposter))
                self.instance.setScale(1)
                self.instance.show()
                return
            except Exception:
                pass
        try:
            self.instance.show()
        except Exception:
            pass