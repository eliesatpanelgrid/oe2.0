#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iDebugger.py - XDREAMY SKIN V7.1
Python 3 only. Asynchronous debug logging and health probes.
"""

import os
import time
import functools
import threading

LOG_DIR       = "/tmp"
LOG_MAX_BYTES = 2 * 1024 * 1024

_lock = threading.Lock()
_health_event = threading.Event()

def _is_module_debug(module):
    try:
        from Components.config import config
        xd = config.plugins.xDreamy
        if not bool(xd.debug_master.value):
            return False
        cfg = getattr(xd, f"dbg_{module}", None)
        return bool(cfg.value) if cfg is not None else False
    except Exception:
        return False

def is_debug():
    try:
        from Components.config import config
        return bool(config.plugins.xDreamy.debug_master.value)
    except Exception:
        return False

def _log_path(module):
    safe_name = "".join(c for c in str(module) if c.isalnum() or c in ("_", "-")) or "unknown"
    return os.path.join(LOG_DIR, f"{safe_name}_Debug.log")

def _rotate_if_needed(path):
    try:
        if os.path.exists(path) and os.path.getsize(path) > LOG_MAX_BYTES:
            with open(path, "rb") as f:
                f.seek(-(LOG_MAX_BYTES // 2), os.SEEK_END)
                tail = f.read()
            with open(path, "wb") as f:
                f.write(tail)
    except Exception:
        pass

def _write(level, module, event, detail=""):
    try:
        t = time.time()
        ts = f"{time.strftime('%H:%M:%S', time.localtime(t))}.{int((t % 1) * 1000):03d}"
        line = f"{ts} | {level:<5} | {module:<16} | {event:<24} | {detail}\n"
        path = _log_path(module)
        with _lock:
            _rotate_if_needed(path)
            with open(path, "a", encoding="utf-8") as f:
                f.write(line)
    except Exception:
        pass

def dbg(module, event, detail=""):
    if _is_module_debug(module):
        _write("DBG", module, event, detail)

def warn(module, event, detail=""):
    _write("WARN", module, event, detail)

def err(module, event, detail=""):
    _write("ERR", module, event, detail)

def traced(module):
    def _decorator(fn):
        fname = fn.__name__
        @functools.wraps(fn)
        def _wrapper(*args, **kwargs):
            if not _is_module_debug(module):
                return fn(*args, **kwargs)
            t0 = time.time()
            _write("DBG", module, f"{fname}-enter", "")
            try:
                result = fn(*args, **kwargs)
            except Exception as e:
                dt = (time.time() - t0) * 1000
                _write("ERR", module, f"{fname}-EXCEPTION", f"{dt:.1f}ms err={e}")
                raise
            dt = (time.time() - t0) * 1000
            level = "WARN" if dt > 50 else "DBG"
            _write(level, module, f"{fname}-exit", f"{dt:.1f}ms")
            return result
        return _wrapper
    return _decorator

class timed_block(object):
    __slots__ = ("module", "event", "detail", "_t0")
    def __init__(self, module, event, detail=""):
        self.module = module
        self.event = event
        self.detail = detail
        self._t0 = None
    def __enter__(self):
        if _is_module_debug(self.module):
            self._t0 = time.time()
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._t0 is None:
            return False
        dt = (time.time() - self._t0) * 1000
        if exc_type is not None:
            _write("ERR", self.module, f"{self.event}-EXCEPTION", f"{dt:.1f}ms detail={self.detail} err={exc_val}")
        else:
            level = "WARN" if dt > 50 else "DBG"
            _write(level, self.module, self.event, f"{dt:.1f}ms {self.detail}")
        return False

def dump_vars(module, event, **kwargs):
    if not _is_module_debug(module):
        return
    parts = [f"{k}={v!r}" for k, v in kwargs.items()]
    _write("DBG", module, event, " ".join(parts))

_timelines = {}
_timeline_lock = threading.Lock()

def checkpoint(title, label):
    if not title or not is_debug():
        return
    with _timeline_lock:
        _timelines.setdefault(title, []).append((label, time.time()))

def timeline_flush(title):
    with _timeline_lock:
        steps = _timelines.pop(title, None)
    if not title or not is_debug() or not steps or len(steps) < 2:
        return
    t0 = steps[0][1]
    prev = t0
    parts = []
    for label, ts in steps:
        parts.append(f"{label}+{(ts - prev) * 1000:.0f}ms")
        prev = ts
    total = (steps[-1][1] - t0) * 1000
    level = "WARN" if total > 1500 else "DBG"
    _write(level, "Timeline", title[:30], f"{' -> '.join(parts)} | TOTAL={total:.0f}ms")

_health_probes = {}
_health_probe_lock = threading.Lock()
HEALTH_SNAPSHOT_INTERVAL_S = 5

def register_health_probe(name, fn):
    with _health_probe_lock:
        _health_probes[name] = fn

def _health_loop():
    while True:
        _health_event.wait()
        while is_debug():
            with _health_probe_lock:
                probes = dict(_health_probes)
            parts = []
            for name, fn in probes.items():
                try:
                    stats = fn() or {}
                    parts.append(" ".join(f"{name}.{k}={v}" for k, v in stats.items()))
                except Exception as e:
                    parts.append(f"{name}=ERROR({e})")
            if parts:
                _write("DBG", "Health", "snapshot", " | ".join(parts))
            for _ in range(HEALTH_SNAPSHOT_INTERVAL_S * 10):
                time.sleep(0.1)
                if not is_debug():
                    break
        _health_event.clear()

_health_thread = threading.Thread(target=_health_loop, daemon=True)
_health_thread.start()

def _on_debug_toggle():
    if is_debug():
        _health_event.set()
    else:
        _health_event.clear()