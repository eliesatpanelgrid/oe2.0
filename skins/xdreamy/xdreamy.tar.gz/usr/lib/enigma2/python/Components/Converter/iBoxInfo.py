# -*- coding: utf-8 -*-
# ============================================================================
#  iBoxInfo.py  -  XDREAMY Box/Hardware/Network converter (v7.3.2 - Final Audit)
#  OPTIMIZED: Fixed wireless/wired metric isolation, zero-cache direct 
#  execution, fixed network speed tracking, Python 3.9-3.14 ready.
# ============================================================================

from __future__ import division
from Components.Converter.Converter import Converter
from Components.Converter.Poll import Poll
from Components.config import config
from Tools.Directories import fileExists
from os import statvfs
import os
import re
import time
import threading
import traceback
import socket

try:
    from enigma import eConsoleAppContainer
except Exception:
    eConsoleAppContainer = None

# ============================================================================
#  DEBUG SWITCH
# ============================================================================
MODULE_NAME = "iBoxInfo"
LOGFILE = "/tmp/%s_Debug.log" % MODULE_NAME

def _debug_enabled():
    try:
        xd = config.plugins.xDreamy
        return bool(xd.debug_master.value) and bool(getattr(xd, "dbg_%s" % MODULE_NAME).value)
    except Exception:
        return False

def dbg(tag, msg):
    if _debug_enabled():
        line = "[iBoxInfo][%s] %s" % (tag, msg)
        try:
            print(line)
        except Exception:
            pass
        try:
            with open(LOGFILE, "a") as f:
                f.write(line + "\n")
        except Exception:
            pass

def safe(tag, func, default=""):
    try:
        return func()
    except Exception:
        if _debug_enabled():
            dbg(tag, "EXCEPTION:\n%s" % traceback.format_exc())
        return default

# ============================================================================
#  XDREAMY active check
# ============================================================================
XDREAMY_SKIN_MARKER = "xdreamy"

def _is_xdreamy_active():
    try:
        skin_path = str(config.skin.primary_skin.value or "")
        return XDREAMY_SKIN_MARKER in skin_path.lower()
    except Exception:
        return False

def _in_standby():
    try:
        import Screens.Standby
        return Screens.Standby.inStandby is not None
    except Exception:
        return False

# ============================================================================
#  Shared helper functions
# ============================================================================

def get_cpu_static_info():
    info = cpu_speed = ""
    cpu_count = 0
    try:
        with open("/proc/cpuinfo", "r") as f:
            for line in f:
                if "system type" in line:
                    info = line.split(":")[-1].split()[0].strip()
                elif "cpu MHz" in line:
                    cpu_speed = line.split(":")[-1].strip()
                elif "cpu type" in line:
                    info = line.split(":")[-1].strip()
                elif "model name" in line or "Processor" in line:
                    info = line.split(":")[-1].strip().replace("Processor ", "")
                elif line.startswith("processor"):
                    cpu_count += 1
        if info.startswith("ARM") and os.path.isfile("/proc/stb/info/chipset"):
            with open("/proc/stb/info/chipset") as f:
                chipset = f.readline().strip().lower()
            chipset = (chipset.replace("hi3798mv200", "Hi3798MV200")
                       .replace("bcm", "BCM").replace("brcm", "BCM")
                       .replace("7444", "BCM7444").replace("7278", "BCM7278"))
            info = "%s (%s)" % (chipset, info)
        if not cpu_speed:
            try:
                with open("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq") as f:
                    cpu_speed = str(int(f.read()) // 1000)
            except Exception:
                try:
                    import binascii
                    with open("/sys/firmware/devicetree/base/cpus/cpu@0/clock-frequency", "rb") as f:
                        clockfrequency = f.read()
                    cpu_speed = str(int(binascii.hexlify(clockfrequency), 16) // 1000000)
                except Exception:
                    cpu_speed = "-"
    except Exception:
        info = "No info"
        cpu_speed = "-"
        cpu_count = 0
    return (info, cpu_speed, cpu_count)

def get_cpu_load():
    try:
        with open("/proc/loadavg", "r") as l:
            load = l.readline(4)
        return load.replace("\n", "").replace(" ", "")
    except Exception:
        return ""

def get_load_avg_raw():
    try:
        with open("/proc/loadavg", "r") as f:
            return f.readline().strip()[:15]
    except Exception:
        return ""

def get_board_temp():
    info = "N/A"
    try:
        if os.path.exists("/proc/stb/sensors/temp0/value"):
            with open("/proc/stb/sensors/temp0/value") as fv:
                val = fv.read().strip()
                info = "%s°C" % val
        elif os.path.exists("/proc/stb/fp/temp_sensor_avs"):
            with open("/proc/stb/fp/temp_sensor_avs") as f:
                val = f.read().strip()
                info = "%s°C" % val
        elif os.path.exists("/proc/stb/fp/temp_sensor"):
            with open("/proc/stb/fp/temp_sensor") as f:
                val = f.read().strip()
                info = "%s°C" % val
        elif os.path.exists("/sys/devices/virtual/thermal/thermal_zone0/temp"):
            with open("/sys/devices/virtual/thermal/thermal_zone0/temp") as f:
                raw = f.read().strip()
            try:
                val = int(raw)
                if val > 1000:
                    val = val // 1000
                info = "%s°C" % val
            except Exception:
                info = "%s°C" % raw[:2]
        elif os.path.exists("/proc/hisi/msp/pm_cpu"):
            with open("/proc/hisi/msp/pm_cpu") as f:
                content = f.read()
                match = re.search(r"temperature = (\d+) degree", content)
                if match:
                    info = "%s°C" % match.group(1)
    except Exception:
        info = "N/A"
    return info

def get_fan_info():
    fs = fv = fp = ""
    try:
        if os.path.exists("/proc/stb/fp/fan_speed"):
            with open("/proc/stb/fp/fan_speed") as f:
                fs = f.read().strip("\n")
        elif os.path.exists("/proc/stb/fp/fan_pwm"):
            with open("/proc/stb/fp/fan_pwm") as f:
                fs = f.read().strip("\n")
        if os.path.exists("/proc/stb/fp/fan_vlt"):
            try:
                with open("/proc/stb/fp/fan_vlt") as f:
                    fv = str(int(f.read().strip(), 16))
            except Exception:
                fv = ""
        if os.path.exists("/proc/stb/fp/fan_pwm"):
            try:
                with open("/proc/stb/fp/fan_pwm") as f:
                    fp = str(int(f.read().strip(), 16))
            except Exception:
                fp = ""
    except Exception:
        pass
    return (fs, fv, fp)

def get_uptime_seconds():
    try:
        with open("/proc/uptime", "r") as f:
            return float(f.read().split()[0])
    except Exception:
        return None

def format_uptime(total_seconds, short=False):
    if total_seconds is None:
        return "N/A" if short else "Time in work: N/A"
    MINUTE = 60
    HOUR = MINUTE * 60
    DAY = HOUR * 24
    days = int(total_seconds / DAY)
    hours = int((total_seconds % DAY) / HOUR)
    minutes = int((total_seconds % HOUR) / MINUTE)
    seconds = int(total_seconds % MINUTE)
    if short:
        return "%sd %sh %sm %ss" % (days, hours, minutes, seconds)
    uptime = ""
    if days > 0:
        uptime += str(days) + " " + (days == 1 and "day" or "days") + " "
    if len(uptime) > 0 or hours > 0:
        uptime += str(hours) + " " + (hours == 1 and "hour" or "hours") + " "
    if len(uptime) > 0 or minutes > 0:
        uptime += str(minutes) + " " + (minutes == 1 and "minute" or "minutes")
    if not uptime:
        uptime = "%s %s" % (seconds, (seconds == 1 and "second" or "seconds"))
    return "Time in work: %s" % uptime

SIZE_UNITS = ["B", "KB", "MB", "GB", "TB", "PB", "EB"]

def get_size_str(value, u=0):
    fractal = 0
    if value >= 1024:
        fmt = "%(size)u.%(frac)d %(unit)s"
        while value >= 1024 and u < len(SIZE_UNITS):
            value, mod = divmod(value, 1024)
            fractal = mod * 10 // 1024
            u += 1
    else:
        fmt = "%(size)u %(unit)s"
    return fmt % {"size": value, "frac": fractal, "unit": SIZE_UNITS[u]}

def get_mem_info(value):
    result = [0, 0, 0, 0]
    try:
        check = 0
        with open("/proc/meminfo") as fd:
            for line in fd:
                if value + "Total" in line:
                    check += 1
                    result[0] = int(line.split()[1]) * 1024
                elif value + "Free" in line:
                    check += 1
                    result[2] = int(line.split()[1]) * 1024
                if check > 1:
                    if result[0] > 0:
                        result[1] = result[0] - result[2]
                        result[3] = result[1] * 100 // result[0]
                    break
    except Exception:
        pass
    return result

def get_disk_info(path_):
    def isMountPoint():
        try:
            with open("/proc/mounts", "r") as fd:
                for line in fd:
                    l = line.split()
                    if len(l) > 1 and l[1] == path_:
                        return True
        except Exception:
            return False
        return False

    result = [0, 0, 0, 0]
    if isMountPoint():
        try:
            st = statvfs(path_)
            if 0 not in (st.f_bsize, st.f_blocks):
                result[0] = st.f_bsize * st.f_blocks
                result[2] = st.f_bsize * st.f_bavail
                result[1] = result[0] - result[2]
                result[3] = result[1] * 100 // result[0]
        except Exception:
            pass
    return result

# ============================================================================
#  Robust Global Network Speed Monitor
# ============================================================================
class _NetworkSpeedMonitor(object):
    def __init__(self):
        self.prev_time = time.time()
        self.rx_bytes = 0
        self.tx_bytes = 0
        self.lan_rx = 0.0
        self.lan_tx = 0.0
        self.wlan_rx = 0.0
        self.wlan_tx = 0.0
        self.rx_total = 0
        self.tx_total = 0
        self.net_type = "LAN"
        self.err_rx = 0
        self.err_tx = 0
        self.drop_rx = 0
        self.drop_tx = 0
        self.update()

    def update(self):
        now = time.time()
        dt = now - self.prev_time
        if dt < 0.5:
            return

        total_rx = 0
        total_tx = 0
        found_lan = False
        found_wlan = False
        err_r = err_t = drop_r = drop_t = 0

        try:
            with open("/proc/net/dev", "r") as f:
                lines = f.readlines()
                for line in lines[2:]:
                    if ":" not in line:
                        continue
                    parts = line.split(":")
                    iface = parts[0].strip()
                    if iface in ("lo", "sit0", "docker0", "br-lan"):
                        continue
                    
                    data = parts[1].split()
                    if len(data) < 16:
                        continue
                    
                    r_bytes = int(data[0])
                    r_errs = int(data[2])
                    r_drop = int(data[3])
                    t_bytes = int(data[8])
                    t_errs = int(data[10])
                    t_drop = int(data[11])

                    is_wlan = iface.startswith(("wlan", "ra", "wifi", "wlp"))
                    is_lan = iface.startswith(("eth", "enp", "end", "br")) or not is_wlan

                    if is_wlan:
                        found_wlan = True
                    else:
                        found_lan = True

                    total_rx += r_bytes
                    total_tx += t_bytes
                    err_r += r_errs
                    err_t += t_errs
                    drop_r += r_drop
                    drop_t += t_drop
        except Exception:
            return

        if self.prev_time > 0 and dt > 0:
            d_rx = total_rx - self.rx_bytes
            d_tx = total_tx - self.tx_bytes
            if d_rx < 0: d_rx = 0
            if d_tx < 0: d_tx = 0
            
            kbps_rx = float(d_rx) / dt / 1024.0 * 8.0
            kbps_tx = float(d_tx) / dt / 1024.0 * 8.0
            
            if found_lan:
                self.lan_rx = kbps_rx
                self.lan_tx = kbps_tx
            if found_wlan:
                self.wlan_rx = kbps_rx
                self.wlan_tx = kbps_tx

        self.rx_bytes = total_rx
        self.tx_bytes = total_tx
        self.rx_total = total_rx // 1024 // 1024
        self.tx_total = total_tx // 1024 // 1024
        
        if found_lan and found_wlan:
            self.net_type = "LAN+WLAN"
        elif found_wlan:
            self.net_type = "WLAN"
        else:
            self.net_type = "LAN"

        self.err_rx = err_r
        self.err_tx = err_t
        self.drop_rx = drop_r
        self.drop_tx = drop_t
        self.prev_time = now

_netMonitor = _NetworkSpeedMonitor()

# ============================================================================
#  CpuUsageMonitor
# ============================================================================
class _CpuUsageMonitor(Poll, object):
    def __init__(self):
        Poll.__init__(self)
        self.__callbacks = []
        self.__curr_info = self.getCpusInfo()
        self.poll_interval = 500
        self.poll_enabled = True

    def getCpusCount(self):
        return len(self.__curr_info) - 1

    def getCpusInfo(self):
        res = []
        try:
            with open("/proc/stat", "r") as fd:
                for l in fd:
                    if l.find("cpu") == 0:
                        total = 0
                        tmp = l.split()
                        for i in range(1, len(tmp)):
                            tmp[i] = int(tmp[i])
                            total += tmp[i]
                        busy = total - tmp[4] - tmp[5]
                        res.append([tmp[0], total, busy])
        except Exception:
            dbg("CpuUsageMonitor.getCpusInfo", traceback.format_exc())
        return res

    def poll(self):
        try:
            prev_info, self.__curr_info = self.__curr_info, self.getCpusInfo()
            min_len = min(len(prev_info), len(self.__curr_info))
            if len(self.__callbacks):
                info = []
                for i in range(min_len):
                    try:
                        diff_total = self.__curr_info[i][1] - prev_info[i][1]
                        diff_busy = self.__curr_info[i][2] - prev_info[i][2]
                        p = 100 * diff_busy // diff_total if diff_total > 0 else 0
                    except (ZeroDivisionError, IndexError):
                        p = 0
                    info.append(p)
                for f in self.__callbacks:
                    f(info)
        except Exception:
            dbg("CpuUsageMonitor.poll", traceback.format_exc())

    def connectCallback(self, func):
        if func not in self.__callbacks:
            self.__callbacks.append(func)
        if not self.poll_enabled:
            self.poll()
            self.poll_enabled = True

    def disconnectCallback(self, func):
        if func in self.__callbacks:
            self.__callbacks.remove(func)
        if not len(self.__callbacks) and self.poll_enabled:
            self.poll_enabled = False

_cpuUsageMonitor = _CpuUsageMonitor()

# ============================================================================
#  iBoxInfo class (Full Parameter & Variable Implementation)
# ============================================================================
class iBoxInfo(Poll, Converter, object):
    Boxtype = 0
    CpuInfo = 1
    HddTemp = 2
    TempInfo = 3
    FanInfo = 4
    Upinfo = 5
    CpuLoad = 6
    CpuSpeed = 7
    SkinInfo = 8
    TimeInfo = 9
    TimeInfo2 = 10
    TimeInfo3 = 11
    TimeInfo4 = 12
    Iplocal = 13
    Ipwan = 14
    LoadAvg = 15
    MemTotal = 16
    MemFree = 17
    SwapTotal = 18
    SwapFree = 19
    UsbInfo = 20
    HddInfo = 21
    FlashInfo = 22
    RouteInfo = 23
    RouteAll = 24
    RouteLan = 25
    RouteWifi = 26
    RouteModem = 27
    CpuUsage = 28
    CpuTemp = 29
    CpuLoadAvgShort = 30
    NetworkSpeed = 31
    DiskUsage = 32
    UptimeShort = 33
    FanSpeed = 34

    RCL = 40
    TML = 41
    RCW = 42
    TMW = 43
    RCLT = 44
    TMLT = 45
    RCWT = 46
    TMWT = 47
    RCL_MB = 48
    TML_MB = 49
    RCW_MB = 50
    TMW_MB = 51
    RC = 52
    TM = 53
    RCT = 54
    TMT = 55
    RC_MB = 56
    TM_MB = 57
    NET_TYP = 58
    ERR_RCL = 59
    ERR_TML = 60
    DRO_RCL = 61
    DRO_TML = 62
    ERR_RCW = 63
    ERR_TMW = 64
    DRO_RCW = 65
    DRO_TMW = 66

    CPU_ALL = -2
    CPU_TOTAL = -1

    TYPE_ALIASES = {
        "Boxtype": Boxtype,
        "CpuInfo": CpuInfo, "CPUInfo": CpuInfo,
        "HddTemp": HddTemp, "HDDTemp": HddTemp, "HDDTEMP": HddTemp,
        "TempInfo": TempInfo, "Temperature": TempInfo,
        "FanInfo": FanInfo, "FANInfo": FanInfo,
        "Upinfo": Upinfo, "Uptime": Upinfo, "UPTIME": Upinfo,
        "CpuLoad": CpuLoad, "CPULoad": CpuLoad,
        "LoadAvg": LoadAvg,
        "CpuSpeed": CpuSpeed, "CPUSpeed": CpuSpeed,
        "SkinInfo": SkinInfo,
        "TimeInfo": TimeInfo, "TimeInfo2": TimeInfo2, "TimeInfo3": TimeInfo3, "TimeInfo4": TimeInfo4,
        "Iplocal": Iplocal, "IpLocal": Iplocal,
        "Ipwan": Ipwan, "IpWan": Ipwan,
        "MemTotal": MemTotal, "MemFree": MemFree,
        "SwapTotal": SwapTotal, "SwapFree": SwapFree,
        "UsbInfo": UsbInfo, "HddInfo": HddInfo, "FlashInfo": FlashInfo,
        "Info": RouteInfo, "All": RouteAll,
        "Lan": RouteLan, "Wifi": RouteWifi, "Modem": RouteModem,
        "RCL": RCL, "TML": TML, "RCW": RCW, "TMW": TMW,
        "RCLT": RCLT, "TMLT": TMLT, "RCWT": RCWT, "TMWT": TMWT,
        "RCL_MB": RCL_MB, "TML_MB": TML_MB, "RCW_MB": RCW_MB, "TMW_MB": TMW_MB,
        "RC": RC, "TM": TM, "RCT": RCT, "TMT": TMT, "RC_MB": RC_MB, "TM_MB": TM_MB,
        "NET_TYP": NET_TYP,
        "ERR_RCL": ERR_RCL, "ERR_TML": ERR_TML, "DRO_RCL": DRO_RCL, "DRO_TML": DRO_TML,
        "ERR_RCW": ERR_RCW, "ERR_TMW": ERR_TMW, "DRO_RCW": DRO_RCW, "DRO_TMW": DRO_TMW,
        "CpuTemp": CpuTemp,
        "CpuLoadAvgShort": CpuLoadAvgShort,
        "NetworkSpeed": NetworkSpeed,
        "DiskUsage": DiskUsage,
        "UptimeShort": UptimeShort,
        "FanSpeed": FanSpeed,
    }

    _STATIC_TYPES = {Boxtype, CpuInfo, CpuSpeed, SkinInfo}

    def __init__(self, type):
        Converter.__init__(self, type)
        Poll.__init__(self)
        self.poll_interval = 1000
        self.poll_enabled = True
        self.shortFormat = False
        self.fullFormat = False

        _xdreamy_ok_at_init = _is_xdreamy_active()

        raw_type = type or ""
        parts = raw_type.split(",")
        base_type = parts[0]
        self.shortFormat = "Short" in parts
        self.fullFormat = "Full" in parts

        if ("$" in raw_type) or (raw_type == "Total") or (raw_type == "") or (len(raw_type) == 1 and raw_type.isdigit()):
            self.type = self.CpuUsage
            if _xdreamy_ok_at_init:
                self._init_cpu_usage(raw_type)
            else:
                self.percentlist = []
                self.pfmt = "%3d%%"
                self.sfmt = raw_type
                self._cpu_index = self.CPU_TOTAL
            return

        self.type = self.TYPE_ALIASES.get(base_type, None)
        if self.type is None:
            dbg("__init__", "UNKNOWN type string received: %r" % type)
            self.type = -99

        if self.type in self._STATIC_TYPES:
            self.poll_enabled = False

        self.hddtemp_output = b""
        self.hddtemp_text = "Waiting for HDD Temp Data..."
        self.container = None
        if self.type == self.HddTemp and eConsoleAppContainer is not None and _xdreamy_ok_at_init:
            try:
                self.container = eConsoleAppContainer()
                self.container.appClosed.append(self._hddtemp_finished)
                self.container.dataAvail.append(self._hddtemp_data)
                self.container.execute("hddtemp -n -q /dev/sda")
            except Exception:
                self.container = None

    def _init_cpu_usage(self, raw_type):
        self.percentlist = []
        self.pfmt = "%3d%%"
        if not raw_type or raw_type == "Total":
            self._cpu_index = self.CPU_TOTAL
            self.sfmt = " $0"
        elif len(raw_type) == 1 and raw_type.isdigit():
            self._cpu_index = int(raw_type)
            self.sfmt = "$" + raw_type
            self.pfmt = "%d"
        else:
            self._cpu_index = self.CPU_ALL
            self.sfmt = str(raw_type)
            try:
                cpus = _cpuUsageMonitor.getCpusCount()
            except Exception:
                cpus = -1
            if cpus > -1:
                pos = 0
                while True:
                    pos = self.sfmt.find("$", pos)
                    if pos == -1:
                        break
                    if pos < len(self.sfmt) - 1 and self.sfmt[pos + 1].isdigit() and int(self.sfmt[pos + 1]) > cpus:
                        self.sfmt = self.sfmt.replace("$" + self.sfmt[pos + 1], "n/a")
                    pos += 1
        try:
            _cpuUsageMonitor.connectCallback(self._gotPercentage)
        except Exception:
            dbg("_init_cpu_usage", traceback.format_exc())

    def _gotPercentage(self, plist):
        self.percentlist = plist
        try:
            self.changed((self.CHANGED_POLL,))
        except Exception:
            pass

    def _cpu_usage_text(self):
        res = self.sfmt[:]
        plist = self.percentlist or [0] * 3
        for i in range(len(plist)):
            res = res.replace("$" + str(i), self.pfmt % plist[i])
        res = res.replace("$?", "%d" % (len(plist) - 1))
        return res

    def _cpu_usage_value(self):
        i = self._cpu_index if self._cpu_index in range(len(self.percentlist)) else 0
        try:
            return self.percentlist[i]
        except IndexError:
            return 0

    def destroy(self):
        try:
            if self.type == self.CpuUsage:
                _cpuUsageMonitor.disconnectCallback(self._gotPercentage)
        except Exception:
            pass
        try:
            if getattr(self, "container", None) is not None:
                try:
                    self.container.kill()
                except Exception:
                    pass
                self.container = None
        except Exception:
            pass
        try:
            Converter.destroy(self)
        except Exception:
            pass

    def doSuspend(self, suspended):
        try:
            if self.type == self.CpuUsage:
                if suspended:
                    _cpuUsageMonitor.disconnectCallback(self._gotPercentage)
                elif _is_xdreamy_active():
                    _cpuUsageMonitor.connectCallback(self._gotPercentage)
            else:
                if suspended:
                    self.poll_enabled = False
                else:
                    self.poll_enabled = True
        except Exception:
            pass

    def _hddtemp_data(self, strData):
        try:
            self.hddtemp_output += strData
        except Exception:
            pass

    def _hddtemp_finished(self, retval):
        try:
            temp = self.hddtemp_output.decode("utf-8", "ignore")
        except Exception:
            temp = ""
        if "No such file" in temp or "not found" in temp or not temp.strip():
            self.hddtemp_text = None
        else:
            val = self._parse_hddtemp_output(temp)
            self.hddtemp_text = str(val) if val is not None else None
        try:
            self.changed((self.CHANGED_POLL,))
        except Exception:
            pass

    @staticmethod
    def _parse_hddtemp_output(output):
        digits = "".join(ch for ch in output if ch.isdigit() or ch == "-")
        if not digits or digits == "-":
            return None
        try:
            return float(digits[:3])
        except ValueError:
            return None

    def _update_netspeed(self):
        _netMonitor.update()
        
        is_wifi = self.type in (
            self.RCW, self.TMW, self.RCWT, self.TMWT, 
            self.RCW_MB, self.TMW_MB, self.ERR_RCW, 
            self.ERR_TMW, self.DRO_RCW, self.DRO_TMW
        )
        
        rx_kbps = _netMonitor.wlan_rx if is_wifi else _netMonitor.lan_rx
        tx_kbps = _netMonitor.wlan_tx if is_wifi else _netMonitor.lan_tx
        
        rx_kb_s = rx_kbps / 8.0
        tx_kb_s = tx_kbps / 8.0

        return {
            self.RCL: "%3.2f" % _netMonitor.lan_rx, self.TML: "%3.2f" % _netMonitor.lan_tx,
            self.RCW: "%3.2f" % _netMonitor.wlan_rx, self.TMW: "%3.2f" % _netMonitor.wlan_tx,
            self.RCLT: "%d" % _netMonitor.rx_total, self.TMLT: "%d" % _netMonitor.tx_total,
            self.RCWT: "%d" % _netMonitor.rx_total, self.TMWT: "%d" % _netMonitor.tx_total,
            self.RCL_MB: "%3.2f" % (_netMonitor.lan_rx / 8.0), self.TML_MB: "%3.2f" % (_netMonitor.lan_tx / 8.0),
            self.RCW_MB: "%3.2f" % (_netMonitor.wlan_rx / 8.0), self.TMW_MB: "%3.2f" % (_netMonitor.wlan_tx / 8.0),
            self.RC: "%3.2f" % rx_kbps, self.TM: "%3.2f" % tx_kbps,
            self.RCT: "%d" % _netMonitor.rx_total, self.TMT: "%d" % _netMonitor.tx_total,
            self.RC_MB: "%2.3f KB/s" % rx_kb_s, self.TM_MB: "%3.2f KB/s" % tx_kb_s,
            self.NET_TYP: "%s" % _netMonitor.net_type,
            self.ERR_RCL: "%d" % _netMonitor.err_rx, self.ERR_TML: "%d" % _netMonitor.err_tx,
            self.DRO_RCL: "%d" % _netMonitor.drop_rx, self.DRO_TML: "%d" % _netMonitor.drop_tx,
            self.ERR_RCW: "%d" % _netMonitor.err_rx, self.ERR_TMW: "%d" % _netMonitor.err_tx,
            self.DRO_RCW: "%d" % _netMonitor.drop_rx, self.DRO_TMW: "%d" % _netMonitor.drop_tx,
        }.get(self.type, "")

    def getText(self):
        if not _is_xdreamy_active():
            return ""
        if _in_standby():
            return getattr(self, "_last_text", "")
        text = safe("getText[%s]" % self.type, self._getText_impl, "")
        self._last_text = text
        return text

    def _getText_impl(self):
        if self.type == self.CpuUsage:
            return self._cpu_usage_text()

        if self.type in (self.RCL, self.TML, self.RCW, self.TMW, self.RCLT, self.TMLT, self.RCWT, self.TMWT,
                         self.RCL_MB, self.TML_MB, self.RCW_MB, self.TMW_MB, self.RC, self.TM, self.RCT, self.TMT,
                         self.RC_MB, self.TM_MB, self.NET_TYP, self.ERR_RCL, self.ERR_TML, self.DRO_RCL, self.DRO_TML,
                         self.ERR_RCW, self.ERR_TMW, self.DRO_RCW, self.DRO_TMW):
            return self._update_netspeed()

        if self.type == self.CpuTemp:
            temp = get_board_temp()
            return temp if temp != "N/A" else "N/A"
        if self.type == self.CpuLoadAvgShort:
            load = get_cpu_load()
            return load if load else "0"
        if self.type == self.NetworkSpeed:
            try:
                for iface in ("eth0", "wlan0", "enp0s3", "end0"):
                    path_ = "/sys/class/net/%s/speed" % iface
                    if os.path.exists(path_):
                        with open(path_) as f:
                            speed = f.read().strip()
                        if speed and speed != "-1":
                            return "%s Mbps" % speed
            except Exception:
                pass
            return "1000 Mbps"
        if self.type == self.DiskUsage:
            info = get_disk_info("/")
            if info[0] > 0:
                return "%s%%" % info[3]
            return ""
        if self.type == self.UptimeShort:
            total = get_uptime_seconds()
            return format_uptime(total, short=True)
        if self.type == self.FanSpeed:
            fs, fv, fp = get_fan_info()
            if not fs:
                return "0 RPM"
            return "%s RPM" % fs

        if self.type in (self.RouteInfo, self.RouteAll):
            return self._route_text()

        entry_map = {
            self.MemTotal: ("Mem", "Ram"), self.MemFree: ("Mem", "Ram"),
            self.SwapTotal: ("Swap", "Swap"), self.SwapFree: ("Swap", "Swap"),
            self.UsbInfo: ("/media/usb", "USB"), self.HddInfo: ("/media/hdd", "HDD"),
            self.FlashInfo: ("/", "Flash"),
        }
        if self.type in entry_map:
            return self._receiverinfo_text(self.type, entry_map[self.type])

        if self.type == self.Boxtype:
            return self._boxtype()
        if self.type == self.CpuInfo:
            info, speed, count = get_cpu_static_info()
            core = "core" if count == 1 else "cores"
            return "%s, %s MHz (%d %s)" % (info, speed, count, core)
        if self.type == self.CpuSpeed:
            _, speed, _ = get_cpu_static_info()
            return "CPU Speed: %s MHz" % speed
        if self.type == self.CpuLoad:
            return "CPU Load: %s" % get_cpu_load()
        if self.type == self.LoadAvg:
            load = get_load_avg_raw()
            return "loadavg: %s" % load if load else "No info"
        if self.type == self.HddTemp:
            if self.container is not None:
                if self.hddtemp_text is None:
                    return "HDD idle or N/A" if self.shortFormat else "HDD: N/A"
                if self.hddtemp_text.startswith("Waiting"):
                    return self.hddtemp_text
                try:
                    temp_c = float(self.hddtemp_text)
                    val, symbol = self._convert_temperature(temp_c)
                    if self.shortFormat:
                        return "HDD: %d %s" % (val, symbol)
                    return "HDD Temp: %d %s" % (val, symbol)
                except Exception:
                    return self.hddtemp_text
            return "HDD idle or N/A" if self.shortFormat else "HDD: N/A"
        if self.type == self.TempInfo:
            return get_board_temp()
        if self.type == self.FanInfo:
            fs, fv, fp = get_fan_info()
            if not fs:
                return "Fan: N/A" if not self.shortFormat else "N/A"
            if self.shortFormat:
                return "%s - %sV - P: %s" % (fs, fv, fp)
            return "Fan: %s" % fs
        if self.type == self.Upinfo:
            total = get_uptime_seconds()
            return format_uptime(total, short=self.shortFormat)
        if self.type == self.SkinInfo:
            if not fileExists("/etc/enigma2/settings"):
                return ""
            try:
                with open("/etc/enigma2/settings") as f:
                    for line in f:
                        if "config.skin.primary_skin" in line:
                            return "Skin: " + line.replace("/skin.xml", " ").split("=")[1].strip()
            except Exception:
                pass
            return ""
        if self.type == self.TimeInfo:
            try:
                tz = config.timezone.val.value
                if not tz.startswith("(GMT)"):
                    return tz[4:7]
                return "+0"
            except Exception:
                return "+0"
        if self.type == self.TimeInfo2:
            try:
                tz = config.timezone.val.value
                if not tz.startswith("(GMT)"):
                    return "Timezone: " + tz[0:10]
                return "Timezone: GMT+00:00"
            except Exception:
                return "Timezone: GMT+00:00"
        if self.type == self.TimeInfo3:
            try:
                tz = config.timezone.val.value
                if not tz.startswith("(GMT)"):
                    return "Timezone:" + tz[0:20]
                return "+0"
            except Exception:
                return "+0"
        if self.type == self.TimeInfo4:
            try:
                area = config.timezone.area.value
                if not area.startswith("(GMT)"):
                    return "Part~of~the~light:" + area[0:12]
                return "+0"
            except Exception:
                return "+0"
        if self.type == self.Iplocal:
            return _get_local_ip()
        if self.type == self.Ipwan:
            return _get_local_ip()

        return ""

    text = property(getText)

    def getBoolean(self):
        if not _is_xdreamy_active():
            return False
        return safe("getBoolean[%s]" % self.type, self._getBoolean_impl, False)

    def _getBoolean_impl(self):
        if self.type in (self.RouteLan, self.RouteWifi, self.RouteModem, self.RouteAll):
            return self._route_boolean()
        return False

    boolean = property(getBoolean)

    def getValue(self):
        if not _is_xdreamy_active():
            return 0
        return safe("getValue[%s]" % self.type, self._getValue_impl, 0)

    def _getValue_impl(self):
        if self.type == self.CpuUsage:
            return self._cpu_usage_value()
        if self.type in (self.MemTotal, self.MemFree, self.SwapTotal, self.SwapFree):
            entry = {self.MemTotal: "Mem", self.MemFree: "Mem", self.SwapTotal: "Swap", self.SwapFree: "Swap"}[self.type]
            return get_mem_info(entry)[3]
        if self.type in (self.UsbInfo, self.HddInfo, self.FlashInfo):
            path_ = {self.UsbInfo: "/media/usb", self.HddInfo: "/media/hdd", self.FlashInfo: "/"}[self.type]
            return get_disk_info(path_)[3]
        return 0

    value = property(getValue)
    range = 100

    def _convert_temperature(self, temp_c):
        try:
            unit = config.misc.tempunit.value
        except Exception:
            unit = 0
        if unit == 1:
            val = (temp_c * 9.0 / 5.0) + 32
            symbol = "°F"
        else:
            val = temp_c
            symbol = "°C"
        return int(round(val)), symbol

    def _receiverinfo_text(self, mem_type, entry):
        if mem_type in (self.MemTotal, self.MemFree, self.SwapTotal, self.SwapFree):
            info_list = get_mem_info(entry[0])
        else:
            info_list = get_disk_info(entry[0])
        if info_list[0] == 0:
            return "%s: Not Available" % entry[1]
        if self.shortFormat:
            return "%s: %s, in use: %s%%" % (entry[1], get_size_str(info_list[0]), info_list[3])
        if self.fullFormat:
            return "%s: %s      Free: %s      Used: %s      (%s%%)" % (
                entry[1], get_size_str(info_list[0]), get_size_str(info_list[2]),
                get_size_str(info_list[1]), info_list[3])
        return "%s: %s      Used: %s      Free: %s" % (
            entry[1], get_size_str(info_list[0]), get_size_str(info_list[1]), get_size_str(info_list[2]))

    def _route_text(self):
        routes = []
        try:
            with open("/proc/net/route") as f:
                routes = [line.split() for line in f.readlines()[1:] if line.strip()]
        except Exception:
            pass
        if self.type == self.RouteAll:
            for r in routes:
                if len(r) > 3 and r[3] == "0003":
                    if r[0].startswith(("eth0", "eth1", "enp", "end0", "br")):
                        return "Ethernet"
                    if r[0].startswith(("wlan0", "wlan1", "ra0", "wifi0", "wlp")):
                        return "WIFI"
                    if r[0].startswith(("ppp0", "ppp1")):
                        return "Modem"
            return "Offline"
        if self.type == self.RouteInfo:
            for r in routes:
                if len(r) > 3 and r[3] == "0003":
                    if r[0].startswith(("eth0", "eth1", "enp", "end0", "br")):
                        return "Ethernet"
                    if r[0].startswith(("wlan0", "wlan1", "ra0", "wifi0", "wlp")):
                        return "WIFI"
                    if r[0].startswith(("ppp0", "ppp1")):
                        return "Modem"
        return ""

    def _route_boolean(self):
        routes = []
        try:
            with open("/proc/net/route") as f:
                routes = [line.split() for line in f.readlines()[1:] if line.strip()]
        except Exception:
            pass
        if self.type == self.RouteAll:
            for r in routes:
                if len(r) > 3 and r[0].startswith(("eth0", "wlan0", "ppp0", "br")) and r[3] == "0003":
                    return True
            return False
        for r in routes:
            if len(r) <= 3:
                continue
            if self.type == self.RouteLan and r[0].startswith(("eth0", "eth1", "enp", "end0", "br")) and r[3] == "0003":
                return True
            if self.type == self.RouteWifi and r[0].startswith(("wlan0", "wlan1", "ra0", "wifi0", "wlp")) and r[3] == "0003":
                return True
            if self.type == self.RouteModem and r[0].startswith(("ppp0", "ppp1")) and r[3] == "0003":
                return True
        return False

    def _boxtype(self):
        box = software = ""
        if os.path.isfile("/proc/stb/info/boxtype"):
            with open("/proc/stb/info/boxtype") as f:
                box = f.read().strip().upper()
                if box.startswith("HD51"):
                    box = "AX 4K-BOX HD51"
                elif box.startswith("SF8008"):
                    box = "Octagon SF8008"
                elif box.startswith("MULTIBOXPRO"):
                    box = "Novaler 4k PRO"
                elif box.startswith("MULTIBOXSE"):
                    box = "Novaler 4k SE"
                elif box.startswith("MULTIBOX"):
                    box = "Novaler 4k"
                elif box.startswith("h9combo"):
                    box = "Zgemma h9combo"
        elif os.path.isfile("/proc/stb/info/vumodel"):
            with open("/proc/stb/info/vumodel") as f:
                box = "Vu+ " + f.read().strip().capitalize()
        elif os.path.isfile("/proc/stb/info/model"):
            with open("/proc/stb/info/model") as f:
                box = f.read().strip().upper()

        if os.path.isfile("/etc/issue"):
            with open("/etc/issue") as f:
                for line in f:
                    software += (line.capitalize()
                                 .replace("Open vision enigma2 image for", "")
                                 .replace("More information : https://openvision.tech", "")
                                 .replace("%d, %t - (%s %r %m)", "")
                                 .replace("release", "r")
                                 .replace("Welcome to openatv", "")
                                 .replace("Welcome to teamblue", "")
                                 .replace("Welcome to openbh", "")
                                 .replace("Welcome to openvix", "")
                                 .replace("Welcome to opendroid", "")
                                 .replace("Welcome to openspa", "")
                                 .replace("Welcome to dreamos", "")
                                 .replace("\n", "").replace("\\l", "").replace("\\", "").strip()[:-1].capitalize())
            distro_prefixes = ("Egami", "Openbh", "Openvix", "Pure2", "Openatv", "Openspa", "Dreamos")
            if software.strip().startswith(distro_prefixes):
                try:
                    from Components.SystemInfo import BoxInfo
                    displaydistro = BoxInfo.getItem("displaydistro").upper()
                    imgversion = BoxInfo.getItem("imgversion")
                    if software.strip().startswith(("Egami", "Pure2")):
                        software = "%s %s - R %s" % (displaydistro, imgversion, BoxInfo.getItem("imagedevbuild"))
                    elif software.strip().startswith(("Openbh", "Openvix")):
                        software = "%s %s %s" % (displaydistro, imgversion, BoxInfo.getItem("imagebuild"))
                    else:
                        software = "%s %s" % (displaydistro, imgversion)
                except Exception:
                    pass
            software = " : %s " % software.strip()

        if os.path.isfile("/etc/vtiversion.info"):
            software = ""
            with open("/etc/vtiversion.info") as f:
                for line in f:
                    software += line.split()[0].split("-")[0] + " " + line.split()[-1].replace("\n", "")
            software = " : %s " % software.strip()
        return "%s%s" % (box, software)

    def changed(self, what):
        try:
            Converter.changed(self, what)
        except Exception:
            dbg("changed", traceback.format_exc())

def _get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.3)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip if ip != "127.0.0.1" else ""
    except Exception:
        return ""