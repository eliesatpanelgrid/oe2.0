#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iBackdropXDownloadThread.py - XDREAMY SKIN V6.5.2
BACKDROP DOWNLOADER - OPTIMIZED
"""

from __future__ import absolute_import

import json
import os
import random
import re
import sys
import threading
import time

PY3 = sys.version_info[0] >= 3

if PY3:
    import queue as _queue
    from urllib.parse import quote as urlquote
else:
    import Queue as _queue
    from urllib import quote as urlquote

try:
    import requests
    http_session = requests.Session()
    adapter = requests.adapters.HTTPAdapter(pool_connections=10, pool_maxsize=10)
    http_session.mount("http://", adapter)
    http_session.mount("https://", adapter)
    REQUESTS_OK = True
except Exception:
    requests = None
    http_session = None
    REQUESTS_OK = False

# ---------------------------------------------------------------------------
# Storage Configuration
# ---------------------------------------------------------------------------
path_folder = "/tmp/XDREAMY/backdrop"
for _mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
    try:
        if os.path.exists(_mount) and os.access(_mount, os.W_OK):
            path_folder = os.path.join(_mount, "XDREAMY/backdrop")
            break
    except Exception:
        pass

try:
    if not os.path.exists(path_folder):
        os.makedirs(path_folder)
except Exception:
    pass

SCAN_STATE_FILE = os.path.join(path_folder, "scan_state.json")

# ---------------------------------------------------------------------------
# API Configuration
# ---------------------------------------------------------------------------
TMDB_API_KEY = "3c3efcf47c3577558812bb9d64019d65"
TMDB_SEARCH = "https://api.themoviedb.org/3/search/multi"
TMDB_IMG_BASE = "https://image.tmdb.org/t/p/w342"  # Smaller = faster
IMDB_SUGGEST = "https://v2.sg.media-imdb.com/suggestion/{letter}/{query}.json"

T_CONN = 1.5
T_READ = 2.0
T_IMG = 4
MIN_BYTES = 4096

MAX_RETRIES = 2
RETRY_DELAY_S = 300
STATE_VERSION = "3"

STATUS_FOUND = "found"
STATUS_NOT_FOUND = "not_found"
STATUS_SAVE_FAIL = "save_fail"

_negative_cache = set()

# ---------------------------------------------------------------------------
# Callback Registration
# ---------------------------------------------------------------------------
_pending_callbacks = {}
_callback_lock = threading.Lock()


def register_renderer_callback(clean_title, renderer_obj):
    if not clean_title or renderer_obj is None:
        return
    with _callback_lock:
        if clean_title not in _pending_callbacks:
            _pending_callbacks[clean_title] = []
        if renderer_obj not in _pending_callbacks[clean_title]:
            _pending_callbacks[clean_title].append(renderer_obj)


def unregister_renderer(clean_title, renderer_obj):
    with _callback_lock:
        if clean_title in _pending_callbacks:
            try:
                _pending_callbacks[clean_title].remove(renderer_obj)
            except Exception:
                pass
            if not _pending_callbacks[clean_title]:
                del _pending_callbacks[clean_title]


def _notify_download_success(clean_title, saved_path):
    if not clean_title or not saved_path or not os.path.exists(saved_path):
        return
    with _callback_lock:
        renderers = _pending_callbacks.pop(clean_title, None)
    if renderers:
        for renderer in renderers:
            try:
                renderer.backdrop_download_completed(clean_title, saved_path)
            except Exception:
                try:
                    renderer.poster_download_completed(clean_title, saved_path)
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# Queues
# ---------------------------------------------------------------------------
live_queue = _queue.LifoQueue(maxsize=250)
prefetch_queue = _queue.LifoQueue(maxsize=500)

_pending = set()
_pending_lock = threading.Lock()

# ---------------------------------------------------------------------------
# Simplified Logging
# ---------------------------------------------------------------------------
LOG_FILE = "/tmp/iBackdropX.log"
_log_lock = threading.Lock()


def log_event(source, channel, raw_title, clean_title, status, provider, msg):
    try:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        line = "[%s] | [%s] | %s | %s | %s | %s | %s | %s\n" % (
            timestamp, str(source).upper(), str(channel or "-"),
            str(raw_title or "-"), str(clean_title or "-"),
            str(status).upper(), str(provider or "-"), str(msg or "")
        )
        with _log_lock:
            with open(LOG_FILE, "a") as f:
                f.write(line)
    except Exception:
        pass


def log(msg, level="INFO"):
    log_event("SYSTEM", "-", "-", "-", level, "-", msg)


# ---------------------------------------------------------------------------
# Simplified State Management
# ---------------------------------------------------------------------------
_state = {}
_state_lock = threading.Lock()
_state_dirty = False
_last_state_write = 0
STATE_WRITE_INTERVAL = 60


def _set_state(title, status):
    global _state_dirty
    with _state_lock:
        _state[title] = {"status": status, "last_scan": int(time.time())}
        _state_dirty = True


def _write_state_if_needed():
    global _state_dirty, _last_state_write
    now = time.time()
    if _state_dirty and now - _last_state_write > STATE_WRITE_INTERVAL:
        try:
            data = {"_version": STATE_VERSION, "entries": _state}
            with open(SCAN_STATE_FILE + ".tmp", "w") as f:
                json.dump(data, f)
            os.rename(SCAN_STATE_FILE + ".tmp", SCAN_STATE_FILE)
            _state_dirty = False
            _last_state_write = now
        except Exception:
            pass


def _load_state():
    global _state
    try:
        if not os.path.exists(SCAN_STATE_FILE):
            return
        with open(SCAN_STATE_FILE, "r") as f:
            raw = json.load(f)
        entries = raw.get("entries", raw) if isinstance(raw, dict) else {}
        if isinstance(entries, dict):
            _state = entries
    except Exception:
        pass


def _should_download(title, backdrop_path):
    if os.path.exists(backdrop_path):
        return False
    if title in _negative_cache:
        return False
    with _state_lock:
        st = _state.get(title)
    if st is None:
        return True
    status = st.get("status", "")
    if status == "ok" or status == "failed":
        return False
    return True


def _mark_found(title):
    _set_state(title, "ok")
    if title in _negative_cache:
        _negative_cache.discard(title)


def _mark_not_found(title):
    _set_state(title, "failed")
    _negative_cache.add(title)


# ---------------------------------------------------------------------------
# Queue Management
# ---------------------------------------------------------------------------
def _release(title):
    with _pending_lock:
        _pending.discard(title)


def queue_live(clean_title, canal):
    if not clean_title:
        return False
    
    dest = "%s/%s.jpg" % (path_folder, clean_title)
    if os.path.exists(dest):
        return False
    
    with _pending_lock:
        if clean_title in _pending:
            return False
        _pending.add(clean_title)
    
    try:
        raw = canal[5] if canal and len(canal) > 5 else clean_title
        ch = canal[0] if canal and len(canal) > 0 else "-"
        live_queue.put_nowait((clean_title, raw, ch))
        return True
    except _queue.Full:
        _release(clean_title)
        return False


# ---------------------------------------------------------------------------
# Metadata Providers
# ---------------------------------------------------------------------------
_UA = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Firefox/115.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/114.0",
]


def _ua():
    return random.choice(_UA)


def _tmdb_search(title):
    if not REQUESTS_OK or not title:
        return STATUS_NOT_FOUND, None
    
    try:
        resp = http_session.get(
            TMDB_SEARCH,
            params={"api_key": TMDB_API_KEY, "language": "en", "query": title},
            headers={"User-Agent": _ua()},
            timeout=(T_CONN, T_READ),
            verify=False,
        )
        if not resp.ok:
            return STATUS_NOT_FOUND, None
        
        results = resp.json().get("results", [])
        for item in results:
            media_type = item.get("media_type")
            if media_type not in ("movie", "tv"):
                continue
            backdrop_path = item.get("backdrop_path")
            if backdrop_path:
                return STATUS_FOUND, TMDB_IMG_BASE + backdrop_path
        
        return STATUS_NOT_FOUND, None
        
    except Exception:
        return STATUS_NOT_FOUND, None


def _imdb_search(title):
    if not REQUESTS_OK or not title:
        return STATUS_NOT_FOUND, None
    
    try:
        letter = title[0].lower() if title[0].isalpha() else "a"
        url = IMDB_SUGGEST.format(letter=letter, query=urlquote(title))
        resp = http_session.get(
            url,
            headers={"User-Agent": _ua(), "Accept": "application/json"},
            timeout=(T_CONN, T_READ),
        )
        if not resp.ok:
            return STATUS_NOT_FOUND, None
        
        for item in resp.json().get("d", []):
            img = item.get("i")
            url = None
            if isinstance(img, dict):
                url = img.get("imageUrl", "")
            elif isinstance(img, (list, tuple)) and img:
                url = img[0]
            if url and url.startswith("http"):
                return STATUS_FOUND, url
        
        return STATUS_NOT_FOUND, None
        
    except Exception:
        return STATUS_NOT_FOUND, None


def _find_url(title, source):
    status, url = _tmdb_search(title)
    
    if status == STATUS_FOUND:
        return status, url, "TMDB"
    
    if source == "live":
        status, url = _imdb_search(title)
        if status == STATUS_FOUND:
            return STATUS_FOUND, url, "IMDB"
    
    # Smart fallback: Strip trailing numbers
    fallback_match = re.search(r"^(.*?)\s+\d+$", title)
    if fallback_match:
        base_title = fallback_match.group(1).strip()
        if len(base_title) >= 3:
            status, url = _tmdb_search(base_title)
            if status == STATUS_FOUND:
                return STATUS_FOUND, url, "TMDB"
    
    return STATUS_NOT_FOUND, None, "-"


# ---------------------------------------------------------------------------
# Download & Save
# ---------------------------------------------------------------------------
def _save_backdrop(url, dest):
    if not REQUESTS_OK:
        return STATUS_SAVE_FAIL
    
    try:
        resp = http_session.get(
            url,
            headers={"User-Agent": _ua()},
            timeout=(T_CONN, T_IMG),
            verify=False,
        )
        if not resp.ok:
            return STATUS_SAVE_FAIL
        
        data = resp.content
        if not data or len(data) < MIN_BYTES:
            return STATUS_SAVE_FAIL
        
        with open(dest, "wb") as f:
            f.write(data)
        
        if os.path.exists(dest):
            return STATUS_FOUND
        return STATUS_SAVE_FAIL
        
    except Exception:
        return STATUS_SAVE_FAIL


# ---------------------------------------------------------------------------
# Worker Processing
# ---------------------------------------------------------------------------
def _process(item, source):
    clean_title, raw, ch = item
    try:
        dest = "%s/%s.jpg" % (path_folder, clean_title)

        if not _should_download(clean_title, dest):
            return

        status, url, provider = _find_url(clean_title, source)

        if status == STATUS_FOUND and url:
            save_status = _save_backdrop(url, dest)
            if save_status == STATUS_FOUND:
                _mark_found(clean_title)
                log_event(source, ch, raw, clean_title, "FOUND", provider, "saved")
                _notify_download_success(clean_title, dest)
            else:
                log_event(source, ch, raw, clean_title, "SAVE_FAIL", provider, "save error")
                _mark_not_found(clean_title)
        else:
            log_event(source, ch, raw, clean_title, "NOT_FOUND", "-", "not found")
            _mark_not_found(clean_title)
    except Exception as e:
        log("Process error: %s" % e, "ERROR")
    finally:
        _release(clean_title)
        _write_state_if_needed()


# ---------------------------------------------------------------------------
# Worker Thread
# ---------------------------------------------------------------------------
class iBackdropXDownloadThread(threading.Thread):
    def __init__(self, allow_prefetch=False):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        self.allow_prefetch = allow_prefetch

    def run(self):
        while True:
            try:
                try:
                    item = live_queue.get(timeout=0.2)
                    _process(item, "live")
                    continue
                except _queue.Empty:
                    pass

                if self.allow_prefetch:
                    try:
                        item = prefetch_queue.get(timeout=0.2)
                        _process(item, "prefetch")
                        continue
                    except _queue.Empty:
                        pass
                else:
                    time.sleep(0.001)  # 1ms
            except Exception:
                time.sleep(0.05)


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------
def _async_initialize():
    _load_state()
    
    for _idx in range(6):
        allow_prefetch = (_idx >= 4)
        t = iBackdropXDownloadThread(allow_prefetch=allow_prefetch)
        t.start()
        log(f"Worker {_idx} started ({'PREFETCH' if allow_prefetch else 'LIVE'})")


_init_thread = threading.Thread(target=_async_initialize)
_init_thread.setDaemon(True)
_init_thread.start()