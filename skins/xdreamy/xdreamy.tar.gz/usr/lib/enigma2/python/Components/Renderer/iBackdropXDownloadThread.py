#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iBackdropXDownloadThread.py - XDREAMY SKIN V6.10.0
BACKDROP DOWNLOAD WORKER POOL

V6.10.0 — brought up to parity with iPosterXDownloadThread.py's fixes,
applied after a trace-log-driven audit found the same classes of bug
here, plus one this file had on its own:

 1. _process()'s `finally: _write_state_if_needed()` ran on EVERY single
    job (success or failure), unconditionally — completely bypassing the
    file's own _FLUSH_EVERY=50 threshold (that threshold only ever armed
    the SEPARATE flush-loop thread's event; it never gated this direct
    call). This is the exact fsync-every-time bottleneck measured at
    65-1021ms per call in iPosterXDownloadThread.py's trace logs. Fixed
    the same way: write only when the dirty count actually crosses
    _FLUSH_EVERY, otherwise let the periodic flush loop handle it.

 2. _notify_download_success() called renderer.backdrop_download_completed()
    directly from the worker thread — the same cross-thread Enigma2-core
    hazard fixed earlier for posters/metadata (Enigma2's GUI/EPG core is
    not thread-safe; touching it from a worker thread is what caused the
    original "fine for a few zaps, then jams" failure mode system-wide).
    Fixed: routed through iConverlibr's queue_gui_callback() dispatcher,
    same mechanism iPosterXDownloadThread.py already uses.

 3. _wait_for_api_rate_limit() called time.sleep() WHILE HOLDING
    _api_request_lock — meaning if one worker had to wait out the rate
    limit, every other worker calling this function blocked on the same
    lock for that same sleep, serializing all workers' API calls whenever
    the limit was hit (defeating the purpose of having multiple workers).
    Fixed: compute the wait time inside the lock (cheap), sleep outside it.

 4. Added batch-backdrop submission, mirroring iPosterXDownloadThread.py's
    set_batch_poster_queue_fn — ZapContext already computes the full list
    of missing posters per zap; backdrops can ride the same list since
    they key off the same clean_title.
"""

from __future__ import absolute_import

import json
import os
import random
import re
import sys
import threading
import time

PY3 = sys.version_info[0] >= 3

if PY3:
    import queue as _queue
    from urllib.parse import quote as urlquote
else:
    import Queue as _queue
    from urllib import quote as urlquote

try:
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry

    http_session = requests.Session()

    retry_strategy = Retry(
        total=3,
        backoff_factor=0.5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"]
    )

    adapter = HTTPAdapter(
        pool_connections=10,
        pool_maxsize=10,
        max_retries=retry_strategy
    )
    http_session.mount("http://", adapter)
    http_session.mount("https://", adapter)

    REQUESTS_OK = True
except Exception:
    requests = None
    http_session = None
    REQUESTS_OK = False

# ============================================================================
# ENABLE/DISABLE FLAG
# ============================================================================

_BACKDROPX_ENABLED = True

def set_backdropx_enabled(enabled):
    global _BACKDROPX_ENABLED
    _BACKDROPX_ENABLED = bool(enabled)
    log("BackdropX downloader %s" % ("enabled" if enabled else "disabled"))

def is_backdropx_enabled():
    return _BACKDROPX_ENABLED

# ============================================================================
# STORAGE PATHS
# ============================================================================

from .iConverlibr import (
    BACKDROP_FOLDER as path_folder,
    queue_gui_callback,
    set_batch_backdrop_queue_fn,
    get_cached_search,
    set_cached_search,
)
from .iDebugTrace import trace, timed_block  # DEBUG TRACE - remove this line + trace/timed_block calls when done diagnosing

BACKDROP_STATE_FILE = os.path.join(path_folder, "scan_state.json")

# ============================================================================
# API CONFIGURATION
# ============================================================================

TMDB_API_KEY = "3c3efcf47c3577558812bb9d64019d65"
TMDB_SEARCH = "https://api.themoviedb.org/3/search/multi"
TMDB_IMG_BASE = "https://image.tmdb.org/t/p/w342"
IMDB_SUGGEST = "https://v2.sg.media-imdb.com/suggestion/{letter}/{query}.json"

T_CONN = 1.5
T_READ = 2.0
T_IMG = 4
MIN_BYTES = 4096

MAX_RETRIES = 2
RETRY_DELAY_S = 300
STATE_VERSION = "3"

STATUS_FOUND = "found"
STATUS_NOT_FOUND = "not_found"
STATUS_SAVE_FAIL = "save_fail"

WORKER_COUNT = 6

_queue_high_water_mark = 0
_queue_high_water_lock = threading.Lock()

# V6.9.2 PATCH: API rate limiting - prevent 429 errors
_api_request_times = []
_api_request_lock = threading.Lock()
_API_RATE_LIMIT = 10  # max requests per second
_API_RATE_WINDOW = 1.0  # window in seconds


def _wait_for_api_rate_limit():
    """Wait if we're exceeding API rate limits.

    Fix: the sleep itself now happens OUTSIDE _api_request_lock. Computing
    whether/how long to wait, and recording this request's timestamp, are
    both cheap and stay under the lock — but actually sleeping while
    holding the lock meant every other worker calling this function had
    to wait for that same sleep to finish before they could even check
    whether THEY needed to wait, serializing all workers' API calls
    through a single bottleneck every time the limit was hit."""
    global _api_request_times
    sleep_time = 0
    with _api_request_lock:
        now = time.time()
        _api_request_times = [t for t in _api_request_times if now - t < _API_RATE_WINDOW]
        if len(_api_request_times) >= _API_RATE_LIMIT:
            sleep_time = _API_RATE_WINDOW - (now - _api_request_times[0])
        _api_request_times.append(now)
    if sleep_time > 0:
        time.sleep(sleep_time + 0.05)

# ============================================================================
# CALLBACK REGISTRATION
# ============================================================================

_pending_callbacks = {}
_callback_lock = threading.Lock()

def register_renderer_callback(clean_title, renderer_obj):
    if not clean_title or renderer_obj is None:
        return
    with _callback_lock:
        if clean_title not in _pending_callbacks:
            _pending_callbacks[clean_title] = []
        if renderer_obj not in _pending_callbacks[clean_title]:
            _pending_callbacks[clean_title].append(renderer_obj)

def unregister_renderer(clean_title, renderer_obj):
    with _callback_lock:
        if clean_title in _pending_callbacks:
            try:
                _pending_callbacks[clean_title].remove(renderer_obj)
            except Exception:
                pass
            if not _pending_callbacks[clean_title]:
                del _pending_callbacks[clean_title]

def _notify_download_success(clean_title, saved_path):
    """Called from a worker thread. Does NOT touch any renderer directly —
    backdrop_download_completed() ends up calling self.instance / GUI
    widget operations, which must run on the GUI thread. queue_gui_callback()
    marshals the actual call there (same mechanism iPosterXDownloadThread.py
    uses for poster_download_completed). Calling renderer methods directly
    from a worker thread was the original cause of the system-wide
    "fine for a few zaps, then jams" failure: Enigma2's GUI/EPG core is
    not thread-safe."""
    if not clean_title or not saved_path or not os.path.exists(saved_path):
        return
    with _callback_lock:
        renderers = _pending_callbacks.pop(clean_title, None)
    if not renderers:
        return
    for renderer in renderers:
        queue_gui_callback(renderer.backdrop_download_completed, clean_title, saved_path)

# ============================================================================
# QUEUES
# ============================================================================

live_queue = _queue.LifoQueue(maxsize=250)
prefetch_queue = _queue.LifoQueue(maxsize=500)

_pending = set()
_pending_lock = threading.Lock()

# ============================================================================
# LOGGING
# ============================================================================

LOG_FILE = "/tmp/iBackdropX.log"
_log_lock = threading.Lock()

def log_event(source, channel, raw_title, clean_title, status, provider, msg):
    try:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        line = "[%s] | [%s] | %s | %s | %s | %s | %s | %s\n" % (
            timestamp, str(source).upper(), str(channel or "-"),
            str(raw_title or "-"), str(clean_title or "-"),
            str(status).upper(), str(provider or "-"), str(msg or ""))
        with _log_lock:
            with open(LOG_FILE, "a") as f:
                f.write(line)
    except Exception:
        pass

def log(msg, level="INFO"):
    log_event("SYSTEM", "-", "-", "-", level, "-", msg)

# ============================================================================
# STATE PERSISTENCE
# ============================================================================

_state = {}
_state_lock = threading.Lock()
_dirty = False
_dirty_count = 0
_FLUSH_EVERY = 50
_write_lock = threading.Lock()
_flush_ev = threading.Event()
_last_cleanup = [0]
CLEANUP_INTERVAL_S = 6 * 3600

_negative_cache = set()
_negative_cache_lock = threading.Lock()
_negative_cache_expiry = 12 * 3600

# ============================================================================
# QUEUE STATS & WORKER CONFIG
# ============================================================================

def get_queue_stats():
    global _queue_high_water_mark
    
    with _queue_high_water_lock:
        high_water = _queue_high_water_mark
    with _pending_lock:
        pending_count = len(_pending)
    return {
        'qsize': live_queue.qsize(),
        'prefetch_qsize': prefetch_queue.qsize(),
        'pending': pending_count,
        'high_water': high_water,
        'max': live_queue.maxsize,
        'workers': WORKER_COUNT,
    }

def set_worker_count(count):
    global WORKER_COUNT
    try:
        count = int(count)
        if 1 <= count <= 12:
            WORKER_COUNT = count
            log("Backdrop worker count set to %d" % WORKER_COUNT, "INFO")
            return True
    except Exception:
        pass
    return False

def get_worker_count():
    return WORKER_COUNT

# ============================================================================
# STATE FUNCTIONS
# ============================================================================

def _set_state(title, status):
    global _dirty, _dirty_count
    
    with _state_lock:
        _state[title] = {"status": status, "last_scan": int(time.time())}
        _dirty = True
        _dirty_count += 1
        if _dirty_count >= _FLUSH_EVERY:
            _flush_ev.set()

def _write_state_if_needed(force=False):
    """Writes (and fsyncs) BACKDROP_STATE_FILE.

    Fix: previously called unconditionally from _process()'s `finally`
    block on every single job — _dirty being True was enough to trigger a
    full write, and _set_state() sets _dirty=True on every call, so this
    fired every time regardless of _FLUSH_EVERY. _FLUSH_EVERY only ever
    armed the SEPARATE flush-loop thread's event; it never gated this
    direct call. Measured in iPosterXDownloadThread.py's trace log: this
    exact pattern cost 65-1021ms per call (fsync on slow flash/storage).
    Now this only actually writes when forced (the periodic flush loop,
    every 60s) or when the dirty count has crossed _FLUSH_EVERY — the
    threshold this file already had but wasn't using."""
    global _dirty, _dirty_count
    if not force:
        with _state_lock:
            if _dirty_count < _FLUSH_EVERY:
                return
    if not _dirty and not force:
        return
    with _write_lock:
        try:
            with _state_lock:
                snapshot = dict(_state)
                if not snapshot:
                    _dirty = False
                    _dirty_count = 0
                    return
            tmp = BACKDROP_STATE_FILE + ".tmp"
            _t0 = time.time()  # DEBUG TRACE
            data = {"_version": STATE_VERSION, "entries": snapshot}
            with open(tmp, "w") as f:
                json.dump(data, f)
                f.flush()
                _write_done_ms = int((time.time() - _t0) * 1000)  # DEBUG TRACE
                _t_fsync = time.time()  # DEBUG TRACE
                os.fsync(f.fileno())
                _fsync_ms = int((time.time() - _t_fsync) * 1000)  # DEBUG TRACE
            os.replace(tmp, BACKDROP_STATE_FILE)
            with _state_lock:
                _dirty = False
                _dirty_count = 0
            log("Backdrop state saved (%d entries)" % len(snapshot), "INFO")
            trace("WriteState", "done", "entries=%d write=%dms fsync=%dms" % (  # DEBUG TRACE
                len(snapshot), _write_done_ms, _fsync_ms))
        except Exception as e:
            log("Backdrop state write error: %s" % e, "WARN")
            trace("WriteState", "EXCEPTION", str(e))  # DEBUG TRACE
            try:
                if os.path.exists(BACKDROP_STATE_FILE + ".tmp"):
                    os.remove(BACKDROP_STATE_FILE + ".tmp")
            except Exception:
                pass

def _load_state():
    global _state
    try:
        if not os.path.exists(BACKDROP_STATE_FILE):
            return
        with open(BACKDROP_STATE_FILE, "r") as f:
            raw = json.load(f)
        entries = raw.get("entries", raw) if isinstance(raw, dict) else {}
        if isinstance(entries, dict):
            _state = entries
            log("Loaded backdrop state: %d entries" % len(_state), "INFO")
    except Exception as e:
        log("Backdrop state load error: %s" % e, "WARN")

def _should_download(title, backdrop_path):
    if os.path.exists(backdrop_path):
        return False
    with _negative_cache_lock:
        if title in _negative_cache:
            return False
    with _state_lock:
        st = _state.get(title)
    if st is None:
        return True
    return st.get("status") not in ("ok", "failed")

def _mark_found(title):
    _set_state(title, "ok")
    with _negative_cache_lock:
        _negative_cache.discard(title)

def _mark_not_found(title):
    _set_state(title, "failed")
    with _negative_cache_lock:
        _negative_cache.add(title)

def _clean_old_entries():
    global _dirty, _dirty_count
    
    now = time.time()
    to_delete = []
    with _state_lock:
        for title, entry in _state.items():
            last_scan = entry.get("last_scan", 0)
            status = entry.get("status", "")
            if status == "failed" and (now - last_scan > 7 * 24 * 3600):
                to_delete.append(title)
            elif status == "ok" and (now - last_scan > 180 * 24 * 3600):
                to_delete.append(title)
        for title in to_delete:
            del _state[title]
            _dirty = True
            _dirty_count += 1
    with _negative_cache_lock:
        if len(_negative_cache) > 1000:
            _negative_cache.clear()
    if to_delete:
        _write_state_if_needed(force=True)

# ============================================================================
# QUEUE MANAGEMENT
# ============================================================================

def _release(title):
    with _pending_lock:
        _pending.discard(title)

def queue_live(clean_title, canal):
    global _queue_high_water_mark
    
    if not clean_title:
        return False
    dest = "%s/%s.jpg" % (path_folder, clean_title)
    if os.path.exists(dest):
        trace("Queue", "already-on-disk", "title=%s" % clean_title)  # DEBUG TRACE
        return False
    with _pending_lock:
        if clean_title in _pending:
            trace("Queue", "already-pending", "title=%s" % clean_title)  # DEBUG TRACE
            return False
        _pending.add(clean_title)
    try:
        raw = canal[5] if canal and len(canal) > 5 else clean_title
        ch = canal[0] if canal and len(canal) > 0 else "-"
        live_queue.put_nowait((clean_title, raw, ch))
        qsize = live_queue.qsize()
        with _queue_high_water_lock:
            if qsize > _queue_high_water_mark:
                _queue_high_water_mark = qsize
        trace("Queue", "enqueued", "title=%s qsize=%d" % (clean_title, qsize))  # DEBUG TRACE
        return True
    except _queue.Full:
        _release(clean_title)
        trace("Queue", "full-dropped", "title=%s" % clean_title)  # DEBUG TRACE
        return False

# ============================================================================
# METADATA PROVIDERS
# ============================================================================

_UA = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Firefox/115.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/114.0",
]

def _ua():
    return random.choice(_UA)

def _tmdb_search(title):
    if not REQUESTS_OK or not title:
        return STATUS_NOT_FOUND, None
    try:
        # V6.9.2 PATCH: Rate limit API calls
        _wait_for_api_rate_limit()
        
        resp = http_session.get(
            TMDB_SEARCH,
            params={"api_key": TMDB_API_KEY, "language": "en", "query": title},
            headers={"User-Agent": _ua()},
            timeout=(T_CONN, T_READ),
            verify=False,
        )
        if not resp.ok:
            return STATUS_NOT_FOUND, None
        for item in resp.json().get("results", []):
            if item.get("media_type") not in ("movie", "tv"):
                continue
            backdrop = item.get("backdrop_path")
            if backdrop:
                return STATUS_FOUND, TMDB_IMG_BASE + backdrop
        return STATUS_NOT_FOUND, None
    except Exception:
        return STATUS_NOT_FOUND, None

def _imdb_search(title):
    if not REQUESTS_OK or not title:
        return STATUS_NOT_FOUND, None
    try:
        # V6.9.2 PATCH: Rate limit API calls
        _wait_for_api_rate_limit()
        
        letter = title[0].lower() if title[0].isalpha() else "a"
        url = IMDB_SUGGEST.format(letter=letter, query=urlquote(title))
        resp = http_session.get(url, headers={"User-Agent": _ua(),
                                              "Accept": "application/json"},
                                timeout=(T_CONN, T_READ))
        if not resp.ok:
            return STATUS_NOT_FOUND, None
        for item in resp.json().get("d", []):
            img = item.get("i")
            url = None
            if isinstance(img, dict):
                url = img.get("imageUrl", "")
            elif isinstance(img, (list, tuple)) and img:
                url = img[0]
            if url and url.startswith("http"):
                return STATUS_FOUND, url
        return STATUS_NOT_FOUND, None
    except Exception:
        return STATUS_NOT_FOUND, None

def _find_url(title, source):
    # Check shared cache first — the poster downloader may have already
    # searched this title and stored both poster_url AND backdrop_url.
    # This is what eliminates the duplicate concurrent TMDB calls confirmed
    # in the trace log: 14/29 jobs were being searched by both a poster
    # worker and a backdrop worker simultaneously.
    cached = get_cached_search(title)
    if cached is not None:
        trace("Worker", "search-cache-hit", "title=%s" % title)  # DEBUG TRACE
        if cached.get('status') == STATUS_FOUND:
            backdrop_url = cached.get('backdrop_url', '')
            if backdrop_url:
                return STATUS_FOUND, backdrop_url, cached.get('provider', 'TMDB')
            # Cache hit but no backdrop URL — either TMDB didn't have one
            # or the cache came from an IMDB-only result. Fall through to
            # our own search below so we at least try.
        else:
            return STATUS_NOT_FOUND, None, "-"

    status, url = _tmdb_search(title)
    if status == STATUS_FOUND:
        set_cached_search(title, {'status': STATUS_FOUND, 'backdrop_url': url, 'provider': 'TMDB'})
        return STATUS_FOUND, url, "TMDB"
    if source == "live":
        status, url = _imdb_search(title)
        if status == STATUS_FOUND:
            set_cached_search(title, {'status': STATUS_FOUND, 'backdrop_url': url, 'provider': 'IMDB'})
            return STATUS_FOUND, url, "IMDB"
    m = re.search(r"^(.*?)\s+\d+$", title)
    if m:
        base = m.group(1).strip()
        if len(base) >= 3:
            status, url = _tmdb_search(base)
            if status == STATUS_FOUND:
                set_cached_search(title, {'status': STATUS_FOUND, 'backdrop_url': url, 'provider': 'TMDB'})
                return STATUS_FOUND, url, "TMDB"
    set_cached_search(title, {'status': STATUS_NOT_FOUND})
    return STATUS_NOT_FOUND, None, "-"

# ============================================================================
# DOWNLOAD & SAVE
# ============================================================================

def _save_backdrop(url, dest):
    if not REQUESTS_OK:
        return STATUS_SAVE_FAIL
    tmp = dest + ".part"
    try:
        # V6.9.2 PATCH: Rate limit image downloads
        _wait_for_api_rate_limit()
        
        resp = http_session.get(url, headers={"User-Agent": _ua()},
                                timeout=(T_CONN, T_IMG), verify=False)
        if not resp.ok:
            return STATUS_SAVE_FAIL
        data = resp.content
        if not data or len(data) < MIN_BYTES:
            return STATUS_SAVE_FAIL
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, dest)
        return STATUS_FOUND if os.path.exists(dest) else STATUS_SAVE_FAIL
    except Exception:
        return STATUS_SAVE_FAIL
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass

# ============================================================================
# WORKER PROCESSING
# ============================================================================

def _process(item, source):
    clean_title, raw, ch = item
    _t_job_start = time.time()  # DEBUG TRACE
    trace("Worker", "process-start", "title=%s thread=%s" % (clean_title, threading.current_thread().name))  # DEBUG TRACE
    try:
        dest = "%s/%s.jpg" % (path_folder, clean_title)
        if not _should_download(clean_title, dest):
            trace("Worker", "process-end", "title=%s reason=should-not-download took=%dms" % (  # DEBUG TRACE
                clean_title, int((time.time() - _t_job_start) * 1000)))
            return
        with timed_block("Worker", "find-url", "title=%s" % clean_title):  # DEBUG TRACE
            status, url, provider = _find_url(clean_title, source)
        if status == STATUS_FOUND and url:
            with timed_block("Worker", "save-backdrop", "title=%s" % clean_title):  # DEBUG TRACE
                save_status = _save_backdrop(url, dest)
            if save_status == STATUS_FOUND:
                _mark_found(clean_title)
                log_event(source, ch, raw, clean_title, "FOUND", provider, "saved")
                _notify_download_success(clean_title, dest)
            else:
                log_event(source, ch, raw, clean_title, "SAVE_FAIL", provider, "save error")
                _mark_not_found(clean_title)
        else:
            log_event(source, ch, raw, clean_title, "NOT_FOUND", "-", "not found")
            _mark_not_found(clean_title)
        trace("Worker", "process-end", "title=%s status=%s took=%dms" % (  # DEBUG TRACE
            clean_title, status, int((time.time() - _t_job_start) * 1000)))
    except Exception as e:
        log("Process error: %s" % e, "ERROR")
        trace("Worker", "process-EXCEPTION", "title=%s err=%s" % (clean_title, e))  # DEBUG TRACE
    finally:
        _release(clean_title)
        # Gated by _FLUSH_EVERY inside _write_state_if_needed() now — this
        # call itself is cheap (just checks _dirty_count under the lock)
        # when the threshold hasn't been hit, so calling it here on every
        # job is fine; the fsync it used to do unconditionally is what was
        # expensive, and that's now properly gated.
        _write_state_if_needed()

# ============================================================================
# FLUSH LOOP
# ============================================================================

def _flush_loop():
    while True:
        _flush_ev.wait(timeout=60)
        _flush_ev.clear()
        _write_state_if_needed(force=True)
        if time.time() - _last_cleanup[0] > CLEANUP_INTERVAL_S:
            _clean_old_entries()
            _last_cleanup[0] = time.time()

# ============================================================================
# WORKER THREAD
# ============================================================================

class iBackdropXDownloadThread(threading.Thread):
    def __init__(self, allow_prefetch=False):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        self.allow_prefetch = allow_prefetch

    def run(self):
        while True:
            if not _BACKDROPX_ENABLED:
                time.sleep(1)
                continue
            try:
                # Always try the live queue first (LIFO — most recent
                # zap's request gets processed first, better UX than FIFO)
                try:
                    item = live_queue.get(timeout=0.5)
                    _process(item, "live")
                    continue
                except _queue.Empty:
                    pass
                # For workers that also drain prefetch, try that queue
                if self.allow_prefetch:
                    try:
                        item = prefetch_queue.get(timeout=0.5)
                        _process(item, "prefetch")
                        continue
                    except _queue.Empty:
                        pass
                # Non-prefetch workers had a busy spin (sleep 0.001 + loop)
                # here — replaced with a real blocking wait on the live
                # queue so the thread is fully parked when there's nothing
                # to do, instead of spinning at 1000 iterations/second.
                else:
                    try:
                        item = live_queue.get(timeout=1.0)
                        _process(item, "live")
                    except _queue.Empty:
                        pass
            except Exception as e:
                log("Worker error: %s" % e, "WARN")
                trace("Worker", "worker-loop-EXCEPTION", "err=%s" % e)  # DEBUG TRACE
                time.sleep(0.05)

# ============================================================================
# INITIALIZATION
# ============================================================================

def _async_initialize():
    if not _BACKDROPX_ENABLED:
        log("BackdropX downloader DISABLED — workers not started")
        return
    _load_state()
    for idx in range(WORKER_COUNT):
        allow_prefetch = (idx >= 4)
        t = iBackdropXDownloadThread(allow_prefetch=allow_prefetch)
        t.start()
        log("Worker %d started (%s)" % (idx, "PREFETCH" if allow_prefetch else "LIVE"))
    t_flush = threading.Thread(target=_flush_loop)
    t_flush.setDaemon(True)
    t_flush.start()
    log("BackdropX initialized: %d workers + flush/cleanup loop running" % WORKER_COUNT, "INFO")

_init_thread = threading.Thread(target=_async_initialize)
_init_thread.setDaemon(True)
_init_thread.start()

# Register queue_live as the batch-backdrop handler. After this, every
# ZapContext rebuild submits missing backdrops alongside missing posters
# in one pass, instead of each iBackdropX widget separately discovering
# and queueing its own title. queue_live() already guards against
# duplicate/already-pending/already-on-disk titles, so this is safe even
# though iBackdropX.changed() may still call it itself as a fallback.
set_batch_backdrop_queue_fn(queue_live)