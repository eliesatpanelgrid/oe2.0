#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iDownloadThread.py - XDREAMY SKIN V7.1
Python 3 only. Priority queue, inline pre-decode, backpressure eviction.
"""

import os
import random
import re
import threading
import time
import queue as _queue
import math

try:
    from PIL import Image
except Exception:
    Image = None

try:
    import requests
    http_session = requests.Session()
    try:
        adapter = requests.adapters.HTTPAdapter(pool_connections=4, pool_maxsize=4)
        http_session.mount("http://", adapter)
        http_session.mount("https://", adapter)
    except Exception:
        pass
    REQUESTS_OK = True
except Exception:
    requests = None
    http_session = None
    REQUESTS_OK = False

from enigma import loadJPG, loadPNG
from .iConverlibr import (
    get_cfg, get_poster_folder, get_backdrop_folder, get_logo_folder,
    get_state_store, get_cached_search, set_cached_search,
    mark_file_indexed, queue_gui_callback, notify_metadata_ready, set_batch_request_fn,
    widget_present, _zap_ctx, build_meta_dict,
)
from .iDebugger import traced, dbg, warn, err, timed_block, checkpoint, timeline_flush, register_health_probe

TMDB_IMG_BASE = "https://image.tmdb.org/t/p/"

# ============================================================================
# TUNABLES -- adjust these without touching any logic below.
# TMDB size tokens (must be one it actually serves):
#   poster:   w92, w154, w185, w342, w500, w780, original
#   backdrop: w300, w780, w1280, original
#   logo:     w45, w92, w154, w185, w300, w500, original
# ============================================================================
TMDB_POSTER_SIZE   = "w342"   # was hardcoded w500 -- smaller = faster download + decode
TMDB_BACKDROP_SIZE = "w780"
TMDB_LOGO_SIZE     = "w300"

# Hard pixel-width caps enforced locally after download (belt-and-suspenders
# in case TMDB_*_SIZE above is later set to "original" or a larger token).
# Set any of these to 0 to disable local resizing for that kind entirely.
POSTER_MAX_WIDTH   = 400
BACKDROP_MAX_WIDTH = 960
LOGO_MAX_WIDTH     = 400

# Local config values still take priority if set (BACKDROP_SIZE/LOGO_SIZE in
# xdreamy.cfg), falling back to the tunables above.
def _poster_size():
    return get_cfg("POSTER_SIZE") or TMDB_POSTER_SIZE

def _backdrop_size():
    return get_cfg("BACKDROP_SIZE") or TMDB_BACKDROP_SIZE

def _logo_size():
    return get_cfg("LOGO_SIZE") or TMDB_LOGO_SIZE

T_CONN = 1.5
T_READ = 3
T_IMG_PIC  = 8
T_IMG_LOGO = 4
MIN_BYTES_POSTER = 4096
MIN_BYTES_LOGO   = 512

GENRES_MAP = {
    28: "Action", 12: "Adventure", 16: "Animation", 35: "Comedy",
    80: "Crime", 99: "Documentary", 18: "Drama", 10751: "Family",
    14: "Fantasy", 36: "History", 27: "Horror", 10402: "Music",
    9648: "Mystery", 10749: "Romance", 878: "Sci-Fi", 10770: "TV Movie",
    53: "Thriller", 10752: "War", 37: "Western",
}

STATUS_FOUND, STATUS_NOT_FOUND, STATUS_NETWORK = "found", "not_found", "network"
ASSET_KINDS = ("poster", "backdrop", "logo")

# ---------- Priority Queue ----------
class PriorityJob(object):
    __slots__ = ("job", "priority")
    def __init__(self, job, priority):
        self.job = job
        self.priority = priority  # lower = higher priority
    def __lt__(self, other):
        return self.priority < other.priority

work_queue = _queue.PriorityQueue()  # No maxsize – backpressure via pending set
_MAX_PENDING = 200  # Evict oldest if exceeded
_pending = {}
_pending_lock = threading.Lock()
_callbacks = {}
_callback_lock = threading.Lock()

# ---------- Pre‑decode cache ----------
_predecode_cache = {}
_predecode_lock = threading.Lock()
_PREDECODE_CACHE_MAX = 20  # keep small for low‑RAM boxes

def get_predecoded_pixmap(path):
    """Return pre‑decoded pixmap if available, else None."""
    with _predecode_lock:
        return _predecode_cache.get(path)

def _decode_and_cache_pixmap(path, kind):
    try:
        if kind in ("poster", "backdrop"):
            pix = loadJPG(path)
        else:
            pix = loadPNG(path)
        if pix:
            with _predecode_lock:  # Lock around ALL dict ops
                _predecode_cache[path] = pix
                if len(_predecode_cache) > _PREDECODE_CACHE_MAX:
                    _predecode_cache.pop(next(iter(_predecode_cache)))
    except Exception as e:
        dbg("iDownloadThread", "predecode-error", "%s: %s" % (path, e))

_UA = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Firefox/115.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/114.0",
]

def _ua():
    return random.choice(_UA)

# ----------------------------------------------------------------------------
# CALLBACK REGISTRY (unchanged)
# ----------------------------------------------------------------------------
def register_asset_callback(kind, clean_title, renderer_obj):
    if not clean_title or renderer_obj is None:
        return
    key = (kind, clean_title)
    with _callback_lock:
        bucket = _callbacks.setdefault(key, [])
        if renderer_obj not in bucket:
            bucket.append(renderer_obj)

def unregister_asset_callback(kind, clean_title, renderer_obj):
    key = (kind, clean_title)
    with _callback_lock:
        bucket = _callbacks.get(key)
        if not bucket:
            return
        try:
            bucket.remove(renderer_obj)
        except ValueError:
            return
        if not bucket:
            del _callbacks[key]

def _notify_asset_ready(kind, clean_title, path):
    if not clean_title or not path or not os.path.exists(path):
        return
    key = (kind, clean_title)
    with _callback_lock:
        renderers = _callbacks.pop(key, None)
    if not renderers:
        return
    for r in renderers:
        queue_gui_callback(r.on_asset_ready, kind, clean_title, path)

def _notify_asset_unavailable(kind, clean_title):
    key = (kind, clean_title)
    with _callback_lock:
        renderers = _callbacks.pop(key, None)
    if not renderers:
        return
    for r in renderers:
        queue_gui_callback(r.on_asset_unavailable, kind, clean_title)

# ----------------------------------------------------------------------------
# DOWNLOAD NOTIFICATIONS -- pluggable, no UI coupling here.
# Anything (plugin.py, a status widget, etc.) can register a callback to
# hear about batch download progress without this module deciding how or
# whether to show it on screen.
# ----------------------------------------------------------------------------
_download_stats = {"ok": 0, "fail": 0, "network": 0}
_download_notify_callbacks = []
_download_notify_lock = threading.Lock()

def register_download_notify(callback):
    """callback(kind, clean_title, status, stats) is invoked (via
    queue_gui_callback, so it's safe to touch GUI/config from it) every
    time an individual asset download finishes, where status is one of
    'ok', 'fail', 'network' and stats is a dict of running totals since
    plugin start: {'ok': int, 'fail': int, 'network': int}."""
    with _download_notify_lock:
        if callback not in _download_notify_callbacks:
            _download_notify_callbacks.append(callback)

def unregister_download_notify(callback):
    with _download_notify_lock:
        try:
            _download_notify_callbacks.remove(callback)
        except ValueError:
            pass

def _notify_download_result(kind, clean_title, status):
    with _download_notify_lock:
        if status in _download_stats:
            _download_stats[status] += 1
        stats = dict(_download_stats)
        callbacks = list(_download_notify_callbacks)
    for cb in callbacks:
        try:
            queue_gui_callback(cb, kind, clean_title, status, stats)
        except Exception as e:
            dbg("iDownloadThread", "notify-error", str(e))

def get_download_stats():
    with _download_notify_lock:
        return dict(_download_stats)

# ----------------------------------------------------------------------------
# NETWORK STATUS – exponential backoff per host
# ----------------------------------------------------------------------------
_host_failures = {}
_HOST_BASE_BACKOFF = 2
_HOST_MAX_BACKOFF = 60

def network_available(host="api.themoviedb.org"):
    now = time.time()
    fail_info = _host_failures.get(host)
    if fail_info:
        last_fail, backoff = fail_info
        if now - last_fail < backoff:
            return False
        else:
            del _host_failures[host]
    return True

def mark_network_error(host="api.themoviedb.org", reason=""):
    now = time.time()
    fail_info = _host_failures.get(host)
    if fail_info:
        last_fail, backoff = fail_info
        new_backoff = min(backoff * 2, _HOST_MAX_BACKOFF)
    else:
        new_backoff = _HOST_BASE_BACKOFF
    _host_failures[host] = (now, new_backoff)
    dbg("iDownloadThread", "network-cooldown", f"{host} backoff {new_backoff}s")

def mark_network_ok(host="api.themoviedb.org"):
    _host_failures.pop(host, None)

def _is_net_exc(e):
    if requests is None:
        return True
    try:
        return isinstance(e, (requests.exceptions.Timeout,
                               requests.exceptions.ConnectionError,
                               requests.exceptions.RequestException))
    except Exception:
        return True

def _is_net_status(code):
    try:
        code = int(code)
    except Exception:
        return False
    return code in (408, 429) or code >= 500

# ----------------------------------------------------------------------------
# LOGGING
# ----------------------------------------------------------------------------
LOG_FILE = "/tmp/XDREAMY_downloads.log"
LOG_MAX_BYTES = 1024 * 1024

def log_event(raw_name, clean_title, status, poster="", backdrop="", logo="", meta="", source="TMDB"):
    try:
        line = "%s | %-10s | %-5s | %-40s | %-40s | P:%-3s B:%-3s L:%-3s M:%-3s\n" % (
            time.strftime("%Y-%m-%d %H:%M:%S"),
            status.upper(),
            source or "-",
            (raw_name or "-")[:40],
            (clean_title or "-")[:40],
            "yes" if poster else "-",
            "yes" if backdrop else "-",
            "yes" if logo else "-",
            "yes" if meta else "-",
        )
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX_BYTES:
            with open(LOG_FILE, "rb") as f:
                f.seek(-(LOG_MAX_BYTES // 2), os.SEEK_END)
                tail = f.read()
            with open(LOG_FILE, "wb") as f:
                f.write(tail)
        with open(LOG_FILE, "a") as f:
            f.write(line)
    except Exception:
        pass

# ----------------------------------------------------------------------------
# TMDB SEARCH – unchanged (batched)
# ----------------------------------------------------------------------------
def _unique(items):
    return list(dict.fromkeys(str(x).strip() for x in items or [] if str(x).strip()))

@traced("iDownloadThread")
def _tmdb_search_full(clean_title, candidates, needed):
    want_detail   = widget_present("info")
    want_parental = widget_present("info") or widget_present("parental")
    want_logo     = "logo" in needed

    cached = get_cached_search(clean_title)
    if cached == "NOT_FOUND":
        return None
    if cached is not None:
        return cached

    if not REQUESTS_OK or not network_available():
        return "NETWORK"

    tries = _unique(candidates or [clean_title])[:8]
    poster_size = _poster_size()
    backdrop_size = _backdrop_size()

    for query in tries:
        try:
            with timed_block("iDownloadThread", "tmdb-search-multi", query):
                resp = http_session.get(
                    "https://api.themoviedb.org/3/search/multi",
                    params={"api_key": get_cfg("TMDB_API_KEY"), "language": get_cfg("TMDB_LANGUAGE"),
                            "include_adult": "false", "query": query},
                    headers={"User-Agent": _ua()}, timeout=(T_CONN, T_READ), verify=False)
        except Exception as e:
            if _is_net_exc(e):
                mark_network_error(reason=str(e))
                return "NETWORK"
            continue
        if not resp.ok:
            if _is_net_status(resp.status_code):
                mark_network_error()
                return "NETWORK"
            continue
        mark_network_ok()
        results = resp.json().get("results", [])
        if not results:
            continue

        exact = None
        for item in results:
            if (item.get("title") or item.get("name") or "").strip().lower() == query.lower():
                exact = item
                break
        candidates_items = [exact] if exact else results[:5]

        for item in candidates_items:
            media_type = item.get("media_type")
            if media_type not in ("movie", "tv"):
                continue
            poster_path = item.get("poster_path")
            backdrop_path = item.get("backdrop_path")
            if not poster_path and not backdrop_path:
                continue

            media_id = item.get("id")

            append_parts = []
            if want_detail:
                append_parts.append("credits")
            if want_parental:
                append_parts.append("release_dates" if media_type == "movie" else "content_ratings")
            if want_logo:
                append_parts.append("images")
            append_str = ",".join(append_parts) if append_parts else ""

            detail_url = f"https://api.themoviedb.org/3/{media_type}/{media_id}?api_key={get_cfg('TMDB_API_KEY')}&language={get_cfg('TMDB_LANGUAGE')}&append_to_response={append_str}"
            try:
                detail_resp = http_session.get(detail_url, headers={"User-Agent": _ua()}, timeout=(T_CONN, T_READ), verify=False)
            except Exception as e:
                if _is_net_exc(e):
                    mark_network_error()
                    return "NETWORK"
                continue
            if not detail_resp.ok:
                if _is_net_status(detail_resp.status_code):
                    mark_network_error()
                    return "NETWORK"
                continue
            detail = detail_resp.json()

            director = cast_str = country = ""
            if want_detail:
                credits = detail.get("credits", {})
                for crew in credits.get("crew", []):
                    if crew.get("job") == "Director":
                        director = crew.get("name", "")
                        break
                cast_str = ", ".join(m.get("name", "") for m in credits.get("cast", [])[:10])
                prod = detail.get("production_countries", [])
                if prod:
                    country = ", ".join(c.get("name", "") for c in prod[:2])

            parental = ""
            if want_parental:
                if media_type == "movie":
                    results = detail.get("release_dates", {}).get("results", [])
                    for country_obj in results:
                        if country_obj.get("iso_3166_1") == "US":
                            for rd in country_obj.get("release_dates", []):
                                cert = rd.get("certification", "")
                                if cert:
                                    parental = cert
                                    break
                            break
                else:
                    results = detail.get("content_ratings", {}).get("results", [])
                    for country_obj in results:
                        if country_obj.get("iso_3166_1") == "US":
                            parental = country_obj.get("rating", "")
                            break

            logo_url = ""
            if want_logo:
                logos = detail.get("images", {}).get("logos", [])
                if logos:
                    logos_sorted = sorted(logos, key=lambda x: (0 if x.get("iso_639_1") == "en" else 1, -x.get("vote_count", 0)))
                    size = _logo_size()
                    for logo in logos_sorted:
                        fp = logo.get("file_path", "")
                        if fp and fp.endswith(".png"):
                            logo_url = f"{TMDB_IMG_BASE}{size}{fp}"
                            break

            result = {
                "status": STATUS_FOUND,
                "poster_url": (TMDB_IMG_BASE + poster_size + poster_path) if poster_path else "",
                "backdrop_url": (TMDB_IMG_BASE + backdrop_size + backdrop_path) if backdrop_path else "",
                "logo_url": logo_url,
                "vote_average": item.get("vote_average", 0),
                "parental_rating": parental,
                "genres": ", ".join(GENRES_MAP[g] for g in item.get("genre_ids", []) if g in GENRES_MAP),
                "year": (item.get("release_date") or item.get("first_air_date") or "")[:4],
                "overview": item.get("overview", ""),
                "director": director,
                "cast": cast_str,
                "country": country,
                "title": item.get("title") or item.get("name") or "",
                "_media_id": media_id,
                "_media_type": media_type,
            }
            set_cached_search(clean_title, result)
            return result

    set_cached_search(clean_title, "NOT_FOUND")
    return None

# ----------------------------------------------------------------------------
# IMAGE SAVING – inline pre‑decode (no new thread)
# ----------------------------------------------------------------------------
_MAX_WIDTH_BY_KIND = {"poster": POSTER_MAX_WIDTH, "backdrop": BACKDROP_MAX_WIDTH, "logo": LOGO_MAX_WIDTH}

def _cap_image_width(path, kind):
    """If the saved image is wider than the configured cap, downscale it in
    place. Runs on the background download worker thread only -- never
    touches the GUI thread. A no-op if PIL isn't available or the cap for
    this kind is 0 (disabled)."""
    max_w = _MAX_WIDTH_BY_KIND.get(kind, 0)
    if not max_w or Image is None:
        return
    try:
        img = Image.open(path)
        w, h = img.size
        if w <= max_w:
            img.close()
            return
        new_h = max(1, round(h * (max_w / w)))
        resized = img.resize((max_w, new_h), Image.LANCZOS)
        fmt = "PNG" if kind == "logo" else "JPEG"
        save_kwargs = {"optimize": True} if fmt == "JPEG" else {}
        resized.save(path, fmt, **save_kwargs)
        img.close()
    except Exception as e:
        dbg("iDownloadThread", "resize-error", "%s: %s" % (path, e))

def _save_image(url, dest, min_bytes, kind, img_timeout=T_IMG_PIC):
    if not REQUESTS_OK or not url or not network_available():
        return "network"
    tmp = dest + ".part"
    try:
        with timed_block("iDownloadThread", "save-image", dest):
            resp = http_session.get(url, headers={"User-Agent": _ua()}, timeout=(T_CONN, img_timeout), verify=False)
    except Exception as e:
        if _is_net_exc(e):
            mark_network_error(str(e))
            return "network"
        return "fail"
    if not resp.ok:
        if _is_net_status(resp.status_code):
            mark_network_error()
            return "network"
        return "fail"
    mark_network_ok()
    data = resp.content
    if not data or len(data) < min_bytes:
        return "fail"
    with open(tmp, "wb") as f:
        f.write(data)
    if Image is not None and len(data) < min_bytes * 2:
        try:
            img = Image.open(tmp)
            img.verify()
            img.close()
        except Exception:
            return "fail"
    os.replace(tmp, dest)
    if os.path.exists(dest):
        _cap_image_width(dest, kind)
        _decode_and_cache_pixmap(dest, kind)
        return "ok"
    return "fail"

# ----------------------------------------------------------------------------
# JOB PROCESSING – priority aware
# ----------------------------------------------------------------------------
def _release(clean_title):
    with _pending_lock:
        _pending.pop(clean_title, None)

@traced("iDownloadThread")
def _process(job):
    clean_title = job["title"]
    raw = job["raw"]
    candidates = job["candidates"]
    emc_mode = job["emc_mode"]
    pending_key = job.get("_pending_key", clean_title)

    with _pending_lock:
        job["_dequeued"] = True
        job["_snapshot_kinds"] = set(job["kinds"])
    needed = job["_snapshot_kinds"]

    store = get_state_store(emc_mode)
    checkpoint(clean_title, "dequeued")

    existing_record = store.get(clean_title) or {}

    pdest = os.path.join(get_poster_folder(),   clean_title + ".jpg") if "poster"   in needed else None
    bdest = os.path.join(get_backdrop_folder(), clean_title + ".jpg") if "backdrop" in needed else None
    ldest = os.path.join(get_logo_folder(),     clean_title + ".png") if "logo"     in needed else None

    _folders = {"poster": get_poster_folder(), "backdrop": get_backdrop_folder(), "logo": get_logo_folder()}
    _fnames  = {"poster": clean_title + ".jpg", "backdrop": clean_title + ".jpg", "logo": clean_title + ".png"}

    already_ok = {"poster": False, "backdrop": False, "logo": False}
    still_needed = set()

    for kind, dest in (("poster", pdest), ("backdrop", bdest), ("logo", ldest)):
        if dest is None:
            continue
        asset_ok_key = f"{kind}_ok"

        if existing_record.get(asset_ok_key):
            if os.path.exists(dest):
                already_ok[kind] = True
                _notify_asset_ready(kind, clean_title, dest)
                continue
            else:
                store.set_record(clean_title, **{asset_ok_key: False})

        if not store.should_download(clean_title, asset_ok_key):
            _notify_asset_unavailable(kind, clean_title)
            continue

        if os.path.exists(dest):
            already_ok[kind] = True
            store.set_record(clean_title, **{asset_ok_key: True})
            mark_file_indexed(_folders[kind], _fnames[kind])
            _notify_asset_ready(kind, clean_title, dest)
        else:
            still_needed.add(kind)

    need_metadata = not store.is_ok(clean_title)

    if not still_needed and not need_metadata:
        _release(pending_key)
        return

    try:
        if not network_available():
            for kind in still_needed:
                _notify_asset_unavailable(kind, clean_title)
            _release(pending_key)
            return

        result = _tmdb_search_full(clean_title, candidates, needed)
        checkpoint(clean_title, "searched")

        if result == "NETWORK":
            for kind in still_needed:
                _notify_asset_unavailable(kind, clean_title)
            timeline_flush(clean_title)
            _release(pending_key)
            return

        if result is None:
            store.mark_not_found(clean_title)
            log_event(raw, clean_title, "not_found")
            for kind in still_needed:
                _notify_asset_unavailable(kind, clean_title)
            timeline_flush(clean_title)
            _release(pending_key)
            return

        poster_ok = already_ok["poster"] or bool(existing_record.get("poster_ok"))
        backdrop_ok = already_ok["backdrop"] or bool(existing_record.get("backdrop_ok"))
        logo_ok = already_ok["logo"] or bool(existing_record.get("logo_ok"))

        if "poster" in still_needed and result.get("poster_url"):
            st = _save_image(result["poster_url"], pdest, MIN_BYTES_POSTER, "poster", T_IMG_PIC)
            _notify_download_result("poster", clean_title, st)
            if st == "ok":
                poster_ok = True
                mark_file_indexed(_folders["poster"], _fnames["poster"])
            elif st != "network":
                _notify_asset_unavailable("poster", clean_title)

        if "backdrop" in still_needed and result.get("backdrop_url"):
            st = _save_image(result["backdrop_url"], bdest, MIN_BYTES_POSTER, "backdrop", T_IMG_PIC)
            _notify_download_result("backdrop", clean_title, st)
            if st == "ok":
                backdrop_ok = True
                mark_file_indexed(_folders["backdrop"], _fnames["backdrop"])
            elif st != "network":
                _notify_asset_unavailable("backdrop", clean_title)

        if "logo" in still_needed and result.get("logo_url"):
            st = _save_image(result["logo_url"], ldest, MIN_BYTES_LOGO, "logo", T_IMG_LOGO)
            _notify_download_result("logo", clean_title, st)
            if st == "ok":
                logo_ok = True
                mark_file_indexed(_folders["logo"], _fnames["logo"])
            elif st != "network":
                _notify_asset_unavailable("logo", clean_title)

        store.set_record(
            clean_title, status="ok",
            vote_average=result["vote_average"], parental_rating=result["parental_rating"],
            genres=result["genres"], year=result["year"], overview=result["overview"],
            director=result["director"], cast=result["cast"], country=result["country"],
            title=result["title"],
            poster_ok=poster_ok, backdrop_ok=backdrop_ok, logo_ok=logo_ok,
        )

        meta_dict = build_meta_dict(store.get(clean_title) or {})
        from .iConverlibr import _zap_ctx, _zap_ctx_lock
        with _zap_ctx_lock:
            if _zap_ctx is not None:
                _zap_ctx.update_slot_metadata(clean_title, meta_dict)
                if poster_ok and pdest:
                    _zap_ctx.update_slot_asset(clean_title, "poster", pdest)
                if backdrop_ok and bdest:
                    _zap_ctx.update_slot_asset(clean_title, "backdrop", bdest)
                if logo_ok and ldest:
                    _zap_ctx.update_slot_asset(clean_title, "logo", ldest)

        checkpoint(clean_title, "saved")
        notify_metadata_ready(clean_title)

        if poster_ok:
            _notify_asset_ready("poster", clean_title, pdest)
        if backdrop_ok:
            _notify_asset_ready("backdrop", clean_title, bdest)
        if logo_ok:
            _notify_asset_ready("logo", clean_title, ldest)

        checkpoint(clean_title, "notified")
        timeline_flush(clean_title)

        log_event(raw, clean_title, "found",
                  poster=poster_ok, backdrop=backdrop_ok, logo=logo_ok, meta=True)

        if not poster_ok and not backdrop_ok and not logo_ok:
            store.mark_not_found(clean_title)

    except Exception as e:
        err("iDownloadThread", "process-EX", "%s: %s" % (clean_title, e))
        for kind in still_needed:
            _notify_asset_unavailable(kind, clean_title)
    finally:
        _release(pending_key)

def _worker(worker_id):
    while True:
        try:
            priority_job = work_queue.get(timeout=1.0)
            if priority_job is None:
                continue
            _process(priority_job.job)
        except _queue.Empty:
            continue
        except Exception as e:
            err("iDownloadThread", "worker-EX", "id=%d err=%s" % (worker_id, e))

# ----------------------------------------------------------------------------
# PUBLIC API – with priority and backpressure
# ----------------------------------------------------------------------------
@traced("iDownloadThread")
def request_asset(clean_title, kind, raw_name=None, candidates=None, emc_mode=False, priority=5):
    if not clean_title or kind not in ASSET_KINDS:
        return False
    enabled_key = {"poster": "POSTERX_ENABLED", "backdrop": "BACKDROPX_ENABLED", "logo": "LOGOX_ENABLED"}[kind]
    if not get_cfg(enabled_key):
        return False
    return _enqueue(clean_title, {kind}, raw_name, candidates, emc_mode, priority)

def request_batch(items, kinds=None, emc_mode=False, priority=5):
    if kinds is None:
        kinds = set()
        if widget_present("poster") and get_cfg("POSTERX_ENABLED"):
            kinds.add("poster")
        if widget_present("backdrop") and get_cfg("BACKDROPX_ENABLED"):
            kinds.add("backdrop")
        if widget_present("logo") and get_cfg("LOGOX_ENABLED"):
            kinds.add("logo")
        if not kinds:
            return
    for clean, raw, candidates in items:
        _enqueue(clean, kinds, raw, candidates, emc_mode, priority)

def _enqueue(clean_title, kinds, raw_name, candidates, emc_mode, priority=5):
    raw = raw_name or clean_title
    cand_list = _unique(candidates or [clean_title]) or [clean_title]
    with _pending_lock:
        # Backpressure: evict oldest if too many pending
        if len(_pending) >= _MAX_PENDING:
            oldest = next(iter(_pending))
            _pending.pop(oldest, None)
            warn("iDownloadThread", "backpressure", "evicted %s" % oldest)

        if clean_title in _pending:
            existing = _pending[clean_title]
            existing["kinds"].update(kinds)
            dbg("iDownloadThread", "merged", "title=%s kinds=%s" % (clean_title, kinds))

            if existing.get("_dequeued"):
                # The in-flight worker already snapshotted its kind set before
                # this merge landed, so it won't service these -- without this
                # check they'd sit until the ~3-5s deadman timeout forces a
                # retry. Instead, spin up an immediate follow-up job for just
                # the kinds that got missed, under a distinct pending key so
                # it doesn't collide with the job still running.
                missed = kinds - existing.get("_snapshot_kinds", set())
                if missed:
                    followup_key = clean_title + "\x00followup"
                    if followup_key not in _pending:
                        followup = {
                            "title": clean_title, "raw": raw, "candidates": cand_list,
                            "emc_mode": emc_mode, "kinds": set(missed),
                            "_pending_key": followup_key,
                            "_dequeued": False, "_snapshot_kinds": set(),
                        }
                        _pending[followup_key] = followup
                        try:
                            work_queue.put_nowait(PriorityJob(followup, priority))
                            dbg("iDownloadThread", "followup-enqueued",
                                "title=%s kinds=%s" % (clean_title, missed))
                        except _queue.Full:
                            _pending.pop(followup_key, None)
            return True

        job = {
            "title": clean_title,
            "raw": raw,
            "candidates": cand_list,
            "emc_mode": emc_mode,
            "kinds": set(kinds),
            "_pending_key": clean_title,
            "_dequeued": False,
            "_snapshot_kinds": set(),
        }
        _pending[clean_title] = job
        checkpoint(clean_title, "requested")
        try:
            work_queue.put_nowait(PriorityJob(job, priority))
            dbg("iDownloadThread", "enqueued", "title=%s kinds=%s priority=%d" % (clean_title, kinds, priority))
            return True
        except _queue.Full:
            with _pending_lock:
                _pending.pop(clean_title, None)
            warn("iDownloadThread", "queue-full", clean_title)
            return False

# ----------------------------------------------------------------------------
# INIT
# ----------------------------------------------------------------------------
def _init():
    try:
        cpu_count = os.cpu_count() or 2
        n = min(max(2, cpu_count // 2), get_cfg("WORKER_THREADS") or 3)
    except Exception:
        n = 3
    for i in range(n):
        t = threading.Thread(target=_worker, args=(i,))
        t.daemon = True
        t.start()
    dbg("iDownloadThread", "initialized", "%d workers" % n)

def _health_stats():
    return {
        "queue_depth": work_queue.qsize(),
        "inflight_titles": len(_pending),
        "waiting_callbacks": len(_callbacks),
        "predecode_cache": len(_predecode_cache),
    }

register_health_probe("Downloader", _health_stats)

set_batch_request_fn(lambda missing: request_batch(missing, emc_mode=False))
threading.Thread(target=_init, daemon=True).start()