#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iInfoEvents.py - XDREAMY SKIN V6.9.0
INFO EVENTS RENDERER - Displays metadata with callback support

V6.9.0: added generation-based dedup (skip get_zap_context()'s downstream
work when nothing changed since our last full evaluation) and dynamic
nxts-slot registration.

V6.8.1 fix (still in effect): the pending-metadata registration used to
stay locked onto whichever title was first seen. Fixed by keying the
pending registration to whatever clean_title is currently on screen.

<!-- iInfoEvents - Full Metadata Display -->
<widget source="ServiceEvent" render="iInfoEvents"
    position="1030,580" size="400,400" font="Regular;20"
    labelcolor="#ffcc00" valuecolor="#ffffff" titlecolor="#ffffff"
    zPosition="5"/>

<!-- Single Field Examples -->
<widget source="ServiceEvent" render="iInfoEvents" field="title"
    position="1030,580" size="400,30" font="Regular;24"
    valuecolor="#ffffff" zPosition="5"/>

<widget source="ServiceEvent" render="iInfoEvents" field="year"
    position="1030,620" size="100,30" font="Regular;20"
    valuecolor="#ffffff" zPosition="5"/>

<widget source="ServiceEvent" render="iInfoEvents" field="country"
    position="1030,650" size="300,30" font="Regular;20"
    valuecolor="#ffffff" zPosition="5"/>

<widget source="ServiceEvent" render="iInfoEvents" field="genre"
    position="1030,680" size="300,30" font="Regular;20"
    valuecolor="#ffffff" zPosition="5"/>

<widget source="ServiceEvent" render="iInfoEvents" field="director"
    position="1030,710" size="300,30" font="Regular;20"
    valuecolor="#ffffff" zPosition="5"/>

<widget source="ServiceEvent" render="iInfoEvents" field="cast"
    position="1030,740" size="350,60" font="Regular;18"
    valuecolor="#ffffff" zPosition="5"/>

<widget source="ServiceEvent" render="iInfoEvents" field="rated"
    position="1030,810" size="100,30" font="Regular;20"
    valuecolor="#ffffff" zPosition="5"/>

<widget source="ServiceEvent" render="iInfoEvents" field="imdb"
    position="1030,840" size="150,30" font="Regular;20"
    valuecolor="#ffcc00" zPosition="5"/>

<widget source="ServiceEvent" render="iInfoEvents" field="plot"
    position="1030,870" size="400,100" font="Regular;16"
    valuecolor="#aaaaaa" zPosition="5"/>
"""

from __future__ import absolute_import

from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText
from enigma import eLabel
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance

from .iConverlibr import (
    get_zap_context,
    clean_name,
    convtext,
    register_metadata_callback,
    unregister_metadata_callback,
    register_nxts_slot,
)
from .iDebugTrace import trace  # DEBUG TRACE - remove this line + trace(...) calls when done diagnosing


class iInfoEvents(Renderer, VariableText):
    GUI_WIDGET = eLabel

    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)
        self.nxts = 0
        self.field = None
        self.old_key = None
        self._label_color = "\c00ffcc00"
        self._value_color = "\c00ffffff"
        self._title_color = "\c00ffffff"
        self._pending_title = None
        self._pending_callback = None
        self._last_ref = None
        self._last_generation = -1

    def destroy(self):
        self._clear_pending()
        Renderer.destroy(self)

    def applySkin(self, desktop, screen):
        for attrib, value in self.skinAttributes:
            if attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except:
                    self.nxts = 0
            elif attrib == 'field':
                self.field = str(value).lower()
            elif attrib == "labelcolor":
                try:
                    hex_val = value.strip().lstrip("#")
                    if len(hex_val) == 6:
                        self._label_color = "\c00%s" % hex_val.lower()
                except:
                    pass
            elif attrib == "valuecolor":
                try:
                    hex_val = value.strip().lstrip("#")
                    if len(hex_val) == 6:
                        self._value_color = "\c00%s" % hex_val.lower()
                except:
                    pass
            elif attrib == "titlecolor":
                try:
                    hex_val = value.strip().lstrip("#")
                    if len(hex_val) == 6:
                        self._title_color = "\c00%s" % hex_val.lower()
                except:
                    pass
        register_nxts_slot(self.nxts)
        return Renderer.applySkin(self, desktop, screen)

    def _get_service_ref(self):
        src = self.source
        stype = type(src)
        
        if stype is ServiceEvent:
            return src.getCurrentService()
        if stype is CurrentService:
            return src.getCurrentServiceRef()
        if stype is EventInfo:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if stype is Event:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return None

    def _on_metadata_ready(self, for_title):
        # Only repaint if we're still actually waiting on THIS title — if
        # the user zapped away, _pending_title has since moved on (or been
        # cleared) and this stale callback must not touch the widget.
        trace("iInfoEvents", "metadata-ready-fired", "nxts=%d field=%s title=%s still_waiting=%s" % (  # DEBUG TRACE
            self.nxts, self.field, for_title, self._pending_title == for_title))
        if self._pending_title == for_title and self.instance:
            self.old_key = None
            self._pending_title = None
            self._pending_callback = None
            self.changed((self.CHANGED_DEFAULT,))

    def _display_data(self, data):
        if not self.instance:
            return

        lc = self._label_color
        vc = self._value_color
        tc = self._title_color

        if self.field:
            if self.field == "title":
                val = data.get('title', '')
            elif self.field == "year":
                val = data.get('year', '')
            elif self.field == "country":
                val = data.get('country', '')
            elif self.field == "genre":
                val = data.get('genres', '')
            elif self.field == "director":
                val = data.get('director', '')
            elif self.field == "cast":
                val = data.get('cast', '')
                if len(val) > 100:
                    val = val[:97] + "..."
            elif self.field == "rated":
                val = data.get('rated', '') or data.get('parental', '')
            elif self.field == "imdb":
                val = data.get('imdb', '')
                if val and val not in ("0", "0.0"):
                    val = "%s/10" % val
                else:
                    val = ""
            elif self.field == "plot":
                val = data.get('plot', '') or data.get('overview', '')
                if len(val) > 200:
                    val = val[:197] + "..."
            else:
                val = ""
            
            if val:
                self.text = "%s%s" % (vc, val)
            else:
                self.text = ""
            return

        lines = []
        
        title = data.get('title', '')
        if title:
            lines.append("%s%s" % (tc, title))
            lines.append("%s%s" % (tc, "-" * min(len(title), 40)))
            lines.append("")
        
        year = data.get('year', '')
        if year:
            lines.append("%s%-10s%s%s" % (lc, "Year:", vc, year))
        
        country = data.get('country', '')
        if country:
            lines.append("%s%-10s%s%s" % (lc, "From:", vc, country))
        
        genre = data.get('genres', '')
        if genre:
            genre_display = genre.replace(', ', ' • ')
            lines.append("%s%-10s%s%s" % (lc, "Genre:", vc, genre_display))
        
        director = data.get('director', '')
        if director:
            lines.append("%s%-10s%s%s" % (lc, "Dir:", vc, director))
        
        cast = data.get('cast', '')
        if cast:
            if len(cast) > 60:
                cast = cast[:57] + "..."
            lines.append("%s%-10s%s%s" % (lc, "Cast:", vc, cast))
        
        rated = data.get('rated', '') or data.get('parental', '')
        if rated:
            lines.append("%s%-10s%s%s" % (lc, "Rated:", vc, rated))
        
        imdb = data.get('imdb', '')
        if imdb and imdb not in ("0", "0.0"):
            lines.append("%s%-10s%s%s/10" % (lc, "IMDb:", vc, imdb))
        
        plot = data.get('plot', '') or data.get('overview', '')
        if plot:
            lines.append("")
            if len(plot) > 400:
                plot = plot[:397] + "..."
            lines.append("%s%s" % (vc, plot))
        
        self.text = "\n".join(lines)

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._clear_pending()
            self.old_key = None
            self._last_ref = None
            self._last_generation = -1
            self.text = ""
            return

        trace("iInfoEvents", "changed-enter", "nxts=%d field=%s" % (self.nxts, self.field))  # DEBUG TRACE

        try:
            service = self._get_service_ref()
            if service is None:
                self.text = ""
                return
            
            ctx = get_zap_context(service)
            if ctx is None:
                self.text = ""
                return

            # Generation dedup — see iPosterX.py for the full rationale.
            ref_str = ctx.ref_str
            if ref_str == self._last_ref and ctx.generation == self._last_generation:
                trace("iInfoEvents", "changed-exit", "nxts=%d reason=same-generation" % self.nxts)  # DEBUG TRACE
                return
            self._last_ref = ref_str
            self._last_generation = ctx.generation

            slot = ctx.get_slot(self.nxts)
            
            if not slot or slot.get('skip'):
                self._clear_pending()
                self.text = ""
                trace("iInfoEvents", "changed-exit", "nxts=%d reason=no-slot-or-skip" % self.nxts)  # DEBUG TRACE
                return

            cur_key = slot.get('event_key', '')
            if cur_key and cur_key == self.old_key:
                trace("iInfoEvents", "changed-exit", "nxts=%d reason=dedup-same-key" % self.nxts)  # DEBUG TRACE
                return
            self.old_key = cur_key

            clean_title = slot.get('clean_title', '')
            
            title = slot.get('title', '')
            
            if title:
                self._clear_pending()
                self._display_data(slot)
                trace("iInfoEvents", "changed-exit", "nxts=%d reason=data-shown title=%s" % (self.nxts, clean_title))  # DEBUG TRACE
                return
            
            if clean_title:
                # Switch the pending registration to whatever title is on
                # screen NOW — same fix as iStarX.py/iParental.py. Previously
                # this was "if clean_title and not self._pending_title",
                # which got stuck on the first unknown title seen and
                # silently skipped registering for any later title zapped
                # to while that first lookup was still in flight — exactly
                # the "works for N zaps, then blank until re-zap" symptom.
                if clean_title != self._pending_title:
                    self._clear_pending()
                    self._pending_title = clean_title
                    cb = lambda t=clean_title: self._on_metadata_ready(t)
                    self._pending_callback = cb
                    register_metadata_callback(clean_title, cb)
                    trace("iInfoEvents", "changed-exit", "nxts=%d reason=registered-pending title=%s" % (self.nxts, clean_title))  # DEBUG TRACE
                else:
                    trace("iInfoEvents", "changed-exit", "nxts=%d reason=already-pending-same-title title=%s" % (self.nxts, clean_title))  # DEBUG TRACE
            else:
                self._clear_pending()
                trace("iInfoEvents", "changed-exit", "nxts=%d reason=no-clean-title" % self.nxts)  # DEBUG TRACE
            
            if not self.field:
                self.text = "\c00ff9900Loading..."
            else:
                self.text = ""
            
        except Exception:
            self.text = ""

    def _clear_pending(self):
        if self._pending_title and self._pending_callback:
            unregister_metadata_callback(self._pending_title, self._pending_callback)
        self._pending_title = None
        self._pending_callback = None