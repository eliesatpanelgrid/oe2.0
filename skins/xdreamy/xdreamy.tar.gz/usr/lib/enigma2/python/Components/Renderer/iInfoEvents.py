#!/usr/init/python
# -*- coding: utf-8 -*-

"""
iInfoEvents.py - XDREAMY SKIN V7.1
Info panel renderer – stable native Enigma2 formatting.
"""

from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText
from enigma import eLabel, eTimer

from .iConverlibr import format_overview, is_activated
from .iRendererBase import RendererMixin, parse_nxts_attribute
from .iDebugger import traced

try:
    from skin import parseColor
except ImportError:
    parseColor = None


class iInfoEvents(RendererMixin, Renderer, VariableText):
    GUI_WIDGET = eLabel

    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)
        RendererMixin.__init__(self)
        self.field = None
        self._label_color = "\\c00ffcc00"
        self._value_color = "\\c00ffffff"
        self._title_color = "\\c00ffff00"

        self._plot_lines = []
        self._scroll_offset = 0
        self._visible_lines = 0
        self._scroll_timer = None
        self._scroll_enabled = False
        self._scroll_speed = 3000

    def destroy(self):
        self._stop_scroll()
        self.mixin_destroy()
        Renderer.destroy(self)

    def applySkin(self, desktop, screen):
        self.nxts = parse_nxts_attribute(self.skinAttributes)
        color_map = {
            "yellow": "ffff00",
            "white": "ffffff",
            "green": "00ff00",
            "red": "ff0000",
            "cyan": "00ffff",
            "magenta": "ff00ff",
            "blue": "0000ff",
            "black": "000000",
            "orange": "ffa500",
            "gray": "808080",
            "grey": "808080",
        }
        for attrib, value in self.skinAttributes:
            if attrib == "field":
                self.field = str(value).lower()
            elif attrib in ("labelcolor", "valuecolor", "titlecolor"):
                try:
                    val_str = str(value).strip().lower()
                    hexval = ""
                    if val_str in color_map:
                        hexval = color_map[val_str]
                    else:
                        clean_val = val_str.lstrip("#")
                        if len(clean_val) == 6 and all(c in "0123456789abcdef" for c in clean_val):
                            hexval = clean_val
                        elif parseColor:
                            try:
                                col = parseColor(value)
                                if hasattr(col, "argb"):
                                    hexval = "%06x" % (col.argb() & 0xffffff)
                                elif isinstance(col, int):
                                    hexval = "%06x" % (col & 0xffffff)
                            except Exception:
                                pass

                    if len(hexval) == 6:
                        attr_key = "_%s_color" % {"labelcolor": "label", "valuecolor": "value", "titlecolor": "title"}[attrib]
                        setattr(self, attr_key, "\\c00%s" % hexval.lower())
                except Exception:
                    pass
            elif attrib == "scroll":
                self._scroll_enabled = value.lower() == "true"
            elif attrib == "speed":
                try:
                    self._scroll_speed = int(value)
                except Exception:
                    pass
        self.mixin_apply_skin("info")
        return Renderer.applySkin(self, desktop, screen)

    def _start_scroll(self):
        if not self._scroll_enabled or self._scroll_timer is not None:
            return
        if len(self._plot_lines) <= self._visible_lines:
            return
        self._scroll_offset = 0
        self._scroll_timer = eTimer()
        self._scroll_timer.callback.append(self._scroll_down)
        self._scroll_timer.start(self._scroll_speed, True)

    def _stop_scroll(self):
        if self._scroll_timer:
            self._scroll_timer.stop()
            self._scroll_timer = None
        self._plot_lines = []
        self._scroll_offset = 0

    def _scroll_down(self):
        if not self._plot_lines or not self.instance:
            self._stop_scroll()
            return
        self._scroll_offset += 1
        if self._scroll_offset > len(self._plot_lines) - self._visible_lines:
            self._scroll_offset = 0
        self._update_scroll_display()
        if self._scroll_timer:
            self._scroll_timer.start(self._scroll_speed, True)

    def _update_scroll_display(self):
        if not self._plot_lines:
            return
        end = min(self._scroll_offset + self._visible_lines, len(self._plot_lines))
        visible = self._plot_lines[self._scroll_offset:end]
        if len(self._plot_lines) > self._visible_lines and self._scroll_offset > 0 and end < len(self._plot_lines):
            visible.append("...")
        self.text = "\n".join(visible)

    @traced("iInfoEvents")
    def changed(self, what):
        if not self.instance:
            return
        if not is_activated():
            self.text = ""
            return

        if what[0] == self.CHANGED_CLEAR:
            self._stop_scroll()
            self.mixin_clear()
            self.text = ""
            return

        branch, payload = self.resolve_slot()
        if branch == "same":
            return

        if branch == "media":
            self._handle_media(payload)
            return

        if branch == "no_service":
            self.text = ""
            return

        slot = payload
        if not slot:
            self.text = ""
            return

        data = self.resolve_and_display_metadata(slot, emc_mode=False)
        if data is None:
            self.text = ""
            return
        self._display_data(data)

    def _handle_media(self, media):
        clean_title = media.get("clean_title", "")
        slot = {
            "clean_title": clean_title,
            "raw_name": clean_title.replace("_", " ").title() if clean_title else "",
            "description": "",
            "event_key": "",
            "skip": False,
        }
        data = self.resolve_and_display_metadata(slot, emc_mode=True)
        if data is None:
            self.text = ""
            return
        self._display_data(data)

    def _display_data(self, data):
        if not self.instance:
            return
        lc, vc, tc = self._label_color, self._value_color, self._title_color

        # Field-specific mode
        if self.field:
            f = self.field
            val = ""
            if f == "title":
                val = data.get("title", "")
            elif f == "year":
                val = data.get("year", "")
            elif f == "country":
                val = data.get("country", "")
            elif f == "genre":
                val = data.get("genres", "")
            elif f == "director":
                val = data.get("director", "")
            elif f == "cast":
                val = data.get("cast", "")
                if len(val) > 100:
                    val = val[:97] + "..."
            elif f == "rated":
                val = data.get("rated", "") or data.get("parental", "")
            elif f == "imdb":
                v = data.get("imdb", "")
                val = "%s/10" % v if v and v not in ("0", "0.0") else ""
            elif f == "plot":
                val = data.get("plot", "") or data.get("overview", "")
                if val:
                    val = format_overview(val)
                    self._plot_lines = val.split("\n") if "\n" in val else [val]
                    try:
                        self._visible_lines = max(1, self.instance.size().height() // 22)
                    except Exception:
                        self._visible_lines = 5
                    if len(self._plot_lines) <= self._visible_lines:
                        self._stop_scroll()
                        self.text = val
                        return
                    self._start_scroll()
                    self._update_scroll_display()
                    return
            self.text = "%s%s" % (vc, val) if val else ""
            return

        # ---------- Full panel mode (Native Enigma2 Safe Layout) ----------
        lines = []

        # 1. Title
        title = data.get("title", "")
        if title:
            lines.append("%s%s" % (tc, title.upper()))
            lines.append("%s%s" % (tc, "-" * min(len(title), 40)))
            lines.append("")

        # 2. Year
        year = data.get("year", "")
        if year:
            lines.append("%sYear:\t%s%s" % (lc, vc, year))

        # 3. Rated
        rated = data.get("rated", "") or data.get("parental", "")
        if rated:
            lines.append("%sRated:\t%s%s" % (lc, vc, rated))

        # 4. IMDb
        imdb = data.get("imdb", "")
        if imdb and imdb not in ("0", "0.0"):
            lines.append("%sIMDb:\t%s%s/10" % (lc, vc, imdb))

        # 5. Genre
        genre = data.get("genres", "")
        if genre:
            lines.append("%sGenre:\t%s%s" % (lc, vc, genre.replace(", ", " \u2022 ")))

        # 6. Director
        director = data.get("director", "")
        if director:
            lines.append("%sDir:\t%s%s" % (lc, vc, director))

        # 7. Country
        country = data.get("country", "")
        if country:
            parts = [c.strip() for c in country.split(",") if c.strip()]
            lines.append("%sFrom:\t%s%s" % (lc, vc, ", ".join(parts[:3])))

        # 8. Cast
        cast = data.get("cast", "")
        if cast:
            parts = [c.strip() for c in cast.split(",") if c.strip()]
            lines.append("%sCast:\t%s%s" % (lc, vc, ", ".join(parts[:3])))

        # 9. Plot
        plot = data.get("plot", "") or data.get("overview", "")
        if plot:
            lines.append("")
            plot = format_overview(plot)
            self._plot_lines = plot.split("\n") if "\n" in plot else [plot]
            lines.append("%s%s" % (vc, plot))

        self.text = "\n".join(lines)

        # Handle scroll for long plot
        if self._scroll_enabled and self._plot_lines:
            try:
                self._visible_lines = max(1, self.instance.size().height() // 22)
            except Exception:
                self._visible_lines = 5
            if len(self._plot_lines) > self._visible_lines:
                self._start_scroll()
                self._update_scroll_display()