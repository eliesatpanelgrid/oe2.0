#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iInfoEvents.py - XDREAMY SKIN V6.9.0
INFO EVENTS RENDERER - Uses ZapContext (same pattern as iParental/iStarX)

SKIN XML EXAMPLES:
   <widget source="ServiceEvent" render="iInfoEvents" field="genre"
            position="1030,580" size="400,30" font="Regular;22"
            valuecolor="#ffcc00" zPosition="5"/>
   
   <widget source="ServiceEvent" render="iInfoEvents" 
            position="1030,580" size="400,360" font="Regular;22"
            labelcolor="#ffcc00" valuecolor="#ffffff" zPosition="5"/>
"""

from __future__ import absolute_import

from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText
from enigma import eLabel
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance
from ServiceReference import ServiceReference

from .iConverlibr import (
    get_zap_context,
    clean_name,
    convtext,
)


class iInfoEvents(Renderer, VariableText):
    GUI_WIDGET = eLabel

    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)
        self.nxts = 0
        self.field = None
        self.old_key = None
        self._label_color = "\c00ffcc00"
        self._value_color = "\c00ffffff"

    def applySkin(self, desktop, screen):
        for attrib, value in self.skinAttributes:
            if attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except Exception:
                    self.nxts = 0
            elif attrib == 'field':
                self.field = str(value).lower()
            elif attrib == "labelcolor":
                try:
                    hex_val = value.strip().lstrip("#")
                    if len(hex_val) == 6:
                        self._label_color = "\c00%s" % hex_val.lower()
                except Exception:
                    pass
            elif attrib == "valuecolor":
                try:
                    hex_val = value.strip().lstrip("#")
                    if len(hex_val) == 6:
                        self._value_color = "\c00%s" % hex_val.lower()
                except Exception:
                    pass
        return Renderer.applySkin(self, desktop, screen)

    def _get_service_ref(self):
        src = self.source
        stype = type(src)
        
        if stype is ServiceEvent:
            return src.getCurrentService()
        if stype is CurrentService:
            return src.getCurrentServiceRef()
        if stype is EventInfo:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if stype is Event:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return None

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self.old_key = None
            self.text = ""
            return

        try:
            service = self._get_service_ref()
            if service is None:
                self.text = ""
                return
            
            ctx = get_zap_context(service)
            if ctx is None:
                self.text = ""
                return
            
            slot = ctx.get_slot(self.nxts)
            
            if slot is None and type(self.source) is Event and self.nxts == 0:
                try:
                    evt = self.source.event
                    if evt:
                        raw = clean_name(evt.getEventName())
                        clean = convtext(raw)
                        for n in range(10):
                            test_slot = ctx.get_slot(n)
                            if test_slot and test_slot.get('clean_title') == clean:
                                slot = test_slot
                                break
                except Exception:
                    pass
            
            if not slot or slot.get('skip'):
                self.text = ""
                return

            cur_key = slot.get('event_key', '')
            if cur_key and cur_key == self.old_key:
                return
            self.old_key = cur_key

            lc = self._label_color
            vc = self._value_color

            # Single field mode
            if self.field:
                if self.field == "title":
                    val = slot.get('title', '')
                elif self.field == "year":
                    val = slot.get('year', '')
                elif self.field == "country":
                    val = slot.get('country', '')
                elif self.field == "genre":
                    val = slot.get('genres', '')
                elif self.field == "director":
                    val = slot.get('director', '')
                elif self.field == "cast":
                    val = slot.get('cast', '')
                    if len(val) > 100:
                        val = val[:97] + "..."
                elif self.field == "rated":
                    val = slot.get('rated', '') or slot.get('parental', '')
                elif self.field == "imdb":
                    val = slot.get('imdb', '')
                    if val and val not in ("0", "0.0"):
                        val = "%s/10" % val
                    else:
                        val = ""
                elif self.field == "plot":
                    val = slot.get('plot', '') or slot.get('overview', '')
                    if len(val) > 200:
                        val = val[:197] + "..."
                else:
                    val = ""
                
                if val:
                    self.text = "%s%s" % (vc, val)
                else:
                    self.text = ""
                return

            # Full display mode
            lines = []
            
            title = slot.get('title', '')
            if title:
                lines.append("%s%s" % (vc, title))
                lines.append("")
            
            year = slot.get('year', '')
            if year:
                lines.append("%sYear:      %s%s" % (lc, vc, year))
            
            country = slot.get('country', '')
            if country:
                lines.append("%sCountry:   %s%s" % (lc, vc, country))
            
            genre = slot.get('genres', '')
            if genre:
                lines.append("%sGenre:     %s%s" % (lc, vc, genre))
            
            director = slot.get('director', '')
            if director:
                lines.append("%sDirector:  %s%s" % (lc, vc, director))
            
            cast = slot.get('cast', '')
            if cast:
                if len(cast) > 60:
                    cast = cast[:57] + "..."
                lines.append("%sCast:      %s%s" % (lc, vc, cast))
            
            rated = slot.get('rated', '') or slot.get('parental', '')
            if rated:
                lines.append("%sRated:     %s%s" % (lc, vc, rated))
            
            imdb = slot.get('imdb', '')
            if imdb and imdb not in ("0", "0.0"):
                lines.append("%sIMDb:      %s%s/10" % (lc, vc, imdb))
            
            plot = slot.get('plot', '') or slot.get('overview', '')
            if plot:
                lines.append("")
                if len(plot) > 500:
                    plot = plot[:497] + "..."
                lines.append("%s%s" % (vc, plot))
            
            self.text = "\n".join(lines)
            
        except Exception:
            self.text = ""