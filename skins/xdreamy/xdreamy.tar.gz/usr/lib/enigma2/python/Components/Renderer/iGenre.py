#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iGenre.py - XDREAMY SKIN V6.5.2
GENRE TEXT RENDERER
"""

from __future__ import absolute_import

import os
import sys
import json
import re

from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText
from enigma import eLabel, eEPGCache
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance
from ServiceReference import ServiceReference

from .iConverlibr import get_cached_clean_title, clean_name, format_genres

epgcache = eEPGCache.getInstance()
if epgcache:
    epgcache.load()

path_folder = "/tmp/XDREAMY/poster"
for _mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
    test_path = os.path.join(_mount, "XDREAMY/poster")
    if os.path.exists(test_path):
        path_folder = test_path
        break

SCAN_STATE_FILE = os.path.join(path_folder, "scan_state.json")

# Genre keywords for EPG parsing
GENRE_KEYWORDS = {
    "Action": ["action", "aksi"],
    "Adventure": ["adventure", "aventura"],
    "Comedy": ["comedy", "komedia", "comédie"],
    "Crime": ["crime", "crimen", "krimi"],
    "Documentary": ["documentary", "dokumentation"],
    "Drama": ["drama", "dramat"],
    "Horror": ["horror", "terreur", "terror"],
    "Sci-Fi": ["sci-fi", "scifi", "science fiction"],
    "Thriller": ["thriller", "suspense"],
}


def parse_genres_from_description(description):
    if not description:
        return []
    
    desc_lower = description.lower()
    found = []
    
    # Pattern: [Genre: Action, Comedy]
    match = re.search(r'\[genre:\s*([^\]]+)\]', desc_lower)
    if match:
        for g in match.group(1).split(','):
            g = g.strip().title()
            if g in GENRE_KEYWORDS:
                found.append(g)
        return found[:3]
    
    # Pattern: (Drama)
    for match in re.findall(r'\((\w+)\)', desc_lower):
        candidate = match.title()
        if candidate in GENRE_KEYWORDS:
            found.append(candidate)
    
    if found:
        return found[:3]
    
    # Keyword matching
    for genre, keywords in GENRE_KEYWORDS.items():
        for kw in keywords:
            if kw in desc_lower:
                found.append(genre)
                break
    
    # Remove duplicates
    seen = set()
    unique = []
    for g in found:
        if g not in seen:
            seen.add(g)
            unique.append(g)
    
    return unique[:3]


def get_genres_from_tmdb(clean_title):
    try:
        if not os.path.exists(SCAN_STATE_FILE):
            return None
        with open(SCAN_STATE_FILE, 'r') as f:
            data = json.load(f)
        entries = data.get('entries', data) if isinstance(data, dict) else {}
        entry = entries.get(clean_title, {})
        if entry.get('status') not in ['ok', 'found']:
            return None
        genres = entry.get('genres', '')
        if genres:
            return format_genres(genres)
        return None
    except Exception:
        return None


class iGenre(Renderer, VariableText):
    GUI_WIDGET = eLabel

    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)
        self.nxts = 0
        self.old_key = None

    def applySkin(self, desktop, screen):
        for attrib, value in self.skinAttributes:
            if attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except:
                    self.nxts = 0
        return Renderer.applySkin(self, desktop, screen)

    def _read_canal(self):
        source = self.source
        source_type = type(source)
        service = None
        canal = [None] * 6

        try:
            if source_type is ServiceEvent:
                service = source.getCurrentService()
            elif source_type is CurrentService:
                service = source.getCurrentServiceRef()
            elif source_type is EventInfo:
                service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
            elif source_type is Event:
                if self.nxts:
                    service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                else:
                    if getattr(source, "event", None) is None:
                        return None
                    event = source.event
                    bt = event.getBeginTime()
                    if bt is not None:
                        canal[1] = bt
                    event_name = event.getEventName()
                    if not event_name:
                        return None
                    if sys.version_info[0] >= 3:
                        event_name = event_name.replace('\xc2\x86', '').replace('\xc2\x87', '')
                    else:
                        event_name = event_name.replace('\xc2\x86', '').replace('\xc2\x87', '').encode('utf-8')
                    canal[2] = event_name
                    canal[3] = event.getExtendedDescription()
                    canal[4] = event.getShortDescription()
                    canal[5] = event_name
                    return canal
            else:
                return None

            if service is not None:
                service_str = service.toString()
                events = epgcache.lookupEvent(['IBOCTESX', (service_str, 0, -1, -1)])
                if not events or len(events) <= self.nxts:
                    return None
                service_name = ServiceReference(service).getServiceName()
                if service_name:
                    service_name = clean_name(service_name)
                canal[0] = service_name
                canal[1] = events[self.nxts][1]
                canal[2] = clean_name(events[self.nxts][4])
                canal[3] = events[self.nxts][5] if len(events[self.nxts]) > 5 else None
                canal[4] = events[self.nxts][6] if len(events[self.nxts]) > 6 else None
                canal[5] = canal[2]
                return canal
        except Exception:
            return None
        return None

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self.old_key = None
            self.text = ""
            return

        canal = self._read_canal()
        if not canal or not canal[5]:
            self.text = ""
            return

        cur_key = "%s-%s" % (self.nxts, canal[5])
        if cur_key == self.old_key:
            return

        self.old_key = cur_key
        
        # Try EPG description first
        description = canal[3] or canal[4] or ""
        if description:
            genres = parse_genres_from_description(description)
            if genres:
                self.text = " • ".join(genres)
                return
        
        # Fallback to TMDB
        clean_title = get_cached_clean_title(canal[5])
        if clean_title:
            genres = get_genres_from_tmdb(clean_title)
            if genres:
                self.text = genres
                return
        
        self.text = ""