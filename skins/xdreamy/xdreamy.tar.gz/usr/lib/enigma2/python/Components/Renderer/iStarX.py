#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iStarX.py - XDREAMY SKIN V7.1.0
STAR RATING RENDERER - improved EPG retry
"""

from __future__ import absolute_import

import json

from Components.Renderer.Renderer import Renderer
from Components.VariableValue import VariableValue
from enigma import eSlider, eTimer
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance

from .iConverlibr import (
    get_zap_context,
    register_metadata_callback,
    unregister_metadata_callback,
    register_nxts_slot,
    get_event_source_metadata,
    _load_json_once,
    _has_useful_metadata,
    _zap_ctx,
    invalidate_zap_context,
)
from .iDebugTrace import trace


class iStarX(VariableValue, Renderer):
    GUI_WIDGET = eSlider

    def __init__(self):
        Renderer.__init__(self)
        VariableValue.__init__(self)
        self.__start = 0
        self.__end = 100
        self.nxts = 0
        self.old_key = None
        self._pending_title = None
        self._pending_callback = None
        self._last_ref = None
        self._last_generation = -1
        self._epg_retry_timer = None
        self._epg_retry_count = 0

    def destroy(self):
        self._clear_pending()
        self._stop_epg_retry()
        Renderer.destroy(self)

    def applySkin(self, desktop, screen):
        for attrib, value in self.skinAttributes:
            if attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except Exception:
                    self.nxts = 0
        register_nxts_slot(self.nxts)
        return Renderer.applySkin(self, desktop, screen)

    def postWidgetCreate(self, instance):
        instance.setRange(self.__start, self.__end)

    def _get_service_ref(self):
        src = self.source
        stype = type(src)
        if stype is ServiceEvent:
            return src.getCurrentService()
        if stype is CurrentService:
            return src.getCurrentServiceRef()
        if stype is EventInfo:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if stype is Event:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return None

    def _on_metadata_ready(self, for_title):
        if self._pending_title == for_title and self.instance:
            self.old_key = None
            self._pending_title = None
            self._pending_callback = None
            self._last_ref = None
            self._last_generation = -1
            self.changed((self.CHANGED_DEFAULT,))

    def _show_zero(self):
        try:
            self.instance.setRange(0, 100)
            self.instance.setValue(0)
            self.instance.show()
        except Exception:
            pass

    def _fallback_load_rating(self, clean_title):
        if not clean_title:
            return None
        try:
            data = _load_json_once({clean_title})
            entry = data.get(clean_title, {})
            if entry and (entry.get('vote_average') or entry.get('title')):
                rv = entry.get('vote_average', 0)
                try:
                    return float(rv) if rv else 0
                except:
                    return 0
        except Exception:
            pass
        return None

    def _stop_epg_retry(self):
        if self._epg_retry_timer:
            self._epg_retry_timer.stop()
            self._epg_retry_timer = None
        self._epg_retry_count = 0

    def _start_epg_retry(self):
        self._stop_epg_retry()
        if self._epg_retry_count >= 3:
            return
        self._epg_retry_count += 1
        self._epg_retry_timer = eTimer()
        self._epg_retry_timer.callback.append(self._epg_retry_timer_cb)
        self._epg_retry_timer.start(1000, True)

    def _epg_retry_timer_cb(self):
        self._epg_retry_timer = None
        if not self.instance:
            return
        ctx = _zap_ctx
        if ctx is None or ctx._slot_count == 0:
            invalidate_zap_context(force=True)
        self.changed((self.CHANGED_DEFAULT,))

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._clear_pending()
            self._stop_epg_retry()
            self.old_key = None
            self._last_ref = None
            self._last_generation = -1
            self.instance.hide()
            return

        try:
            cur_key = None
            rating = None

            if type(self.source) is Event:
                slot = get_event_source_metadata(self.source)
                if not slot or slot.get('skip'):
                    self._clear_pending()
                    self._stop_epg_retry()
                    self._show_zero()
                    return
                cur_key = slot.get('event_key', '')
                if cur_key and cur_key == self.old_key:
                    return
                self.old_key = None
                self._last_ref = None
                self._last_generation = -1
                rating = slot.get('rating', 0)
                if (rating == 0 and (not slot.get('metadata_resolved') or not slot.get('title'))) and slot.get('clean_title'):
                    rating = self._fallback_load_rating(slot.get('clean_title', ''))
                self._stop_epg_retry()
            else:
                service = self._get_service_ref()
                if service is None:
                    self._show_zero()
                    return
                ctx = get_zap_context(service)
                if ctx is None:
                    self._show_zero()
                    return
                ref_str = ctx.ref_str
                if ref_str != self._last_ref:
                    self.old_key = None
                if ref_str == self._last_ref and ctx.generation == self._last_generation:
                    return
                self._last_ref = ref_str
                self._last_generation = ctx.generation
                slot = ctx.get_slot(self.nxts)
                if not slot or slot.get('skip'):
                    self._clear_pending()
                    self._show_zero()
                    if self._epg_retry_count < 3:
                        self._start_epg_retry()
                    return
                cur_key = slot.get('event_key', '')
                if cur_key and cur_key == self.old_key:
                    return
                rating = slot.get('rating', 0)
                if (rating == 0 and (not slot.get('metadata_resolved') or not slot.get('title'))) and slot.get('clean_title'):
                    rating = self._fallback_load_rating(slot.get('clean_title', ''))
                self._stop_epg_retry()

            if rating and rating > 0:
                self._clear_pending()
                try:
                    rating = float(rating)
                    self.instance.setRange(0, 100)
                    self.instance.setValue(int(rating * 10))
                    self.instance.show()
                    self.old_key = cur_key
                    return
                except Exception:
                    pass

            if slot and slot.get('metadata_resolved'):
                self._clear_pending()
                self._show_zero()
                self.old_key = cur_key
                return

            clean_title = slot.get('clean_title', '') if slot else ''
            if clean_title:
                if clean_title != self._pending_title:
                    self._clear_pending()
                    self._pending_title = clean_title
                    cb = lambda t=clean_title: self._on_metadata_ready(t)
                    self._pending_callback = cb
                    register_metadata_callback(clean_title, cb)
            else:
                self._clear_pending()

            self._show_zero()

        except Exception:
            self._show_zero()

    def _clear_pending(self):
        if self._pending_title and self._pending_callback:
            unregister_metadata_callback(self._pending_title, self._pending_callback)
        self._pending_title = None
        self._pending_callback = None