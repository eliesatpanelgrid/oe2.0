#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iStarX.py - XDREAMY SKIN V6.5.2
STAR RATING RENDERER
"""

from __future__ import absolute_import

import os
import sys
import json

from Components.Renderer.Renderer import Renderer
from Components.VariableValue import VariableValue
from enigma import eSlider, eEPGCache
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance
from ServiceReference import ServiceReference

from .iConverlibr import get_cached_clean_title, clean_name

epgcache = eEPGCache.getInstance()
if epgcache:
    epgcache.load()

path_folder = "/tmp/XDREAMY/poster"
for _mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
    test_path = os.path.join(_mount, "XDREAMY/poster")
    if os.path.exists(test_path):
        path_folder = test_path
        break

SCAN_STATE_FILE = os.path.join(path_folder, "scan_state.json")


class iStarX(VariableValue, Renderer):
    GUI_WIDGET = eSlider

    def __init__(self):
        Renderer.__init__(self)
        VariableValue.__init__(self)
        self.__start = 0
        self.__end = 100
        self.nxts = 0
        self.old_key = None

    def applySkin(self, desktop, screen):
        for attrib, value in self.skinAttributes:
            if attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except:
                    self.nxts = 0
        return Renderer.applySkin(self, desktop, screen)

    def _get_rating(self, clean_title):
        try:
            if not os.path.exists(SCAN_STATE_FILE):
                return None
            with open(SCAN_STATE_FILE, 'r') as f:
                data = json.load(f)
            entries = data.get('entries', data) if isinstance(data, dict) else {}
            entry = entries.get(clean_title, {})
            if entry.get('status') in ['ok', 'found']:
                rating = entry.get('vote_average', 0)
                return float(rating) if rating else None
            return None
        except Exception:
            return None

    def _read_canal(self):
        source = self.source
        source_type = type(source)
        service = None
        canal = [None] * 6

        try:
            if source_type is ServiceEvent:
                service = source.getCurrentService()
            elif source_type is CurrentService:
                service = source.getCurrentServiceRef()
            elif source_type is EventInfo:
                service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
            elif source_type is Event:
                if self.nxts:
                    service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                else:
                    if getattr(source, "event", None) is None:
                        return None
                    event = source.event
                    bt = event.getBeginTime()
                    if bt is not None:
                        canal[1] = bt
                    event_name = event.getEventName()
                    if not event_name:
                        return None
                    if sys.version_info[0] >= 3:
                        event_name = event_name.replace('\xc2\x86', '').replace('\xc2\x87', '')
                    else:
                        event_name = event_name.replace('\xc2\x86', '').replace('\xc2\x87', '').encode('utf-8')
                    canal[2] = event_name
                    canal[5] = event_name
                    return canal
            else:
                return None

            if service is not None:
                service_str = service.toString()
                events = epgcache.lookupEvent(['IBOCTESX', (service_str, 0, -1, -1)])
                if not events or len(events) <= self.nxts:
                    return None
                service_name = ServiceReference(service).getServiceName()
                if service_name:
                    service_name = clean_name(service_name)
                canal[0] = service_name
                canal[1] = events[self.nxts][1]
                canal[2] = clean_name(events[self.nxts][4])
                canal[5] = canal[2]
                return canal
        except Exception:
            return None
        return None

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self.old_key = None
            self.instance.hide()
            return

        canal = self._read_canal()
        if not canal or not canal[5]:
            self.instance.hide()
            return

        cur_key = "%s-%s" % (self.nxts, canal[5])
        if cur_key == self.old_key:
            return

        self.old_key = cur_key
        clean_title = get_cached_clean_title(canal[5])

        if clean_title:
            rating = self._get_rating(clean_title)
            if rating is not None and rating > 0:
                value = int(10 * rating)
                self.instance.setRange(0, 100)
                self.instance.setValue(value)
                self.instance.show()
                return

        self.instance.setRange(0, 100)
        self.instance.setValue(0)
        self.instance.show()

    def postWidgetCreate(self, instance):
        instance.setRange(self.__start, self.__end)

    def setRange(self, range):
        (self.__start, self.__end) = range
        if self.instance is not None:
            self.instance.setRange(self.__start, self.__end)

    def getRange(self):
        return self.__start, self.__end