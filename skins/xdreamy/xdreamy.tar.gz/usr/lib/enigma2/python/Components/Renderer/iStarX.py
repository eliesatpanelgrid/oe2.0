#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iStarX.py - XDREAMY SKIN V6.9.0
STAR RATING RENDERER - Reads from ZapContext only

V6.9.0: added generation-based dedup (skip the whole get_zap_context()
round trip's downstream work when nothing changed since our last full
evaluation of this exact channel+generation) and dynamic nxts-slot
registration (register_nxts_slot) so ZapContext's EPG-event cap is driven
by what this skin actually uses instead of a fixed constant.

V6.8.1 fix (still in effect): the pending-metadata registration used to
stay locked onto whichever title was first seen. Fixed by keying the
pending registration to whatever clean_title is currently on screen.
"""

from __future__ import absolute_import

from Components.Renderer.Renderer import Renderer
from Components.VariableValue import VariableValue
from enigma import eSlider
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance

from .iConverlibr import (
    get_zap_context,
    clean_name,
    convtext,
    register_metadata_callback,
    unregister_metadata_callback,
    register_nxts_slot,
)
from .iDebugTrace import trace  # DEBUG TRACE - remove this line + trace(...) calls when done diagnosing


class iStarX(VariableValue, Renderer):
    GUI_WIDGET = eSlider

    def __init__(self):
        Renderer.__init__(self)
        VariableValue.__init__(self)
        self.__start = 0
        self.__end = 100
        self.nxts = 0
        self.old_key = None
        self._pending_title = None
        self._pending_callback = None
        self._last_ref = None
        self._last_generation = -1

    def destroy(self):
        self._clear_pending()
        Renderer.destroy(self)

    def applySkin(self, desktop, screen):
        for attrib, value in self.skinAttributes:
            if attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except:
                    self.nxts = 0
        register_nxts_slot(self.nxts)
        return Renderer.applySkin(self, desktop, screen)

    def postWidgetCreate(self, instance):
        instance.setRange(self.__start, self.__end)

    def _get_service_ref(self):
        src = self.source
        stype = type(src)
        
        if stype is ServiceEvent:
            return src.getCurrentService()
        if stype is CurrentService:
            return src.getCurrentServiceRef()
        if stype is EventInfo:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if stype is Event:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return None

    def _on_metadata_ready(self, for_title):
        # Only repaint if we're still actually waiting on THIS title — if
        # the user zapped away, _pending_title has since moved on (or been
        # cleared) and this stale callback must not touch the widget.
        trace("iStarX", "metadata-ready-fired", "nxts=%d title=%s still_waiting=%s" % (  # DEBUG TRACE
            self.nxts, for_title, self._pending_title == for_title))
        if self._pending_title == for_title and self.instance:
            self.old_key = None
            self._pending_title = None
            self._pending_callback = None
            self.changed((self.CHANGED_DEFAULT,))

    def _show_zero(self):
        try:
            self.instance.setRange(0, 100)
            self.instance.setValue(0)
            self.instance.show()
        except:
            pass

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._clear_pending()
            self.old_key = None
            self._last_ref = None
            self._last_generation = -1
            self.instance.hide()
            return

        trace("iStarX", "changed-enter", "nxts=%d" % self.nxts)  # DEBUG TRACE

        try:
            service = self._get_service_ref()
            if service is None:
                self._show_zero()
                return
            
            ctx = get_zap_context(service)
            if ctx is None:
                self._show_zero()
                return

            # Generation dedup — see iPosterX.py for the full rationale
            # (confirmed in the trace log: most changed() calls were
            # re-evaluating a context that hadn't changed at all). Safe
            # here too: any time new metadata arrives for a pending title,
            # invalidate_zap_context() runs first, so the next changed()
            # call (fired by the dispatcher) always sees a genuinely new
            # generation, never a stale repeat.
            ref_str = ctx.ref_str
            if ref_str == self._last_ref and ctx.generation == self._last_generation:
                trace("iStarX", "changed-exit", "nxts=%d reason=same-generation" % self.nxts)  # DEBUG TRACE
                return
            self._last_ref = ref_str
            self._last_generation = ctx.generation

            slot = ctx.get_slot(self.nxts)
            
            if not slot or slot.get('skip'):
                self._clear_pending()
                self._show_zero()
                trace("iStarX", "changed-exit", "nxts=%d reason=no-slot-or-skip" % self.nxts)  # DEBUG TRACE
                return

            cur_key = slot.get('event_key', '')
            if cur_key and cur_key == self.old_key:
                trace("iStarX", "changed-exit", "nxts=%d reason=dedup-same-key" % self.nxts)  # DEBUG TRACE
                return
            self.old_key = cur_key

            rating = slot.get('rating', 0)
            
            if rating > 0:
                self._clear_pending()
                try:
                    rating = float(rating)
                    self.instance.setRange(0, 100)
                    self.instance.setValue(int(rating * 10))
                    self.instance.show()
                    trace("iStarX", "changed-exit", "nxts=%d reason=rating-shown rating=%.1f" % (self.nxts, rating))  # DEBUG TRACE
                    return
                except:
                    pass

            if slot.get('metadata_resolved'):
                # Already looked up and confirmed there's no rating for
                # this title (e.g. a talk show/news segment TMDB doesn't
                # rate) — don't register for a callback that will never
                # bring a rating. Confirmed in the trace log: some titles
                # were re-registering on every single zap back to them,
                # forever, for no possible benefit.
                self._clear_pending()
                self._show_zero()
                trace("iStarX", "changed-exit", "nxts=%d reason=resolved-no-rating" % self.nxts)  # DEBUG TRACE
                return
            
            clean_title = slot.get('clean_title', '')
            if clean_title:
                # Switch the pending registration to whatever title is on
                # screen NOW. If we were waiting on a different (now stale)
                # title from a previous zap, drop that registration instead
                # of silently keeping it and never registering for this one.
                if clean_title != self._pending_title:
                    self._clear_pending()
                    self._pending_title = clean_title
                    cb = lambda t=clean_title: self._on_metadata_ready(t)
                    self._pending_callback = cb
                    register_metadata_callback(clean_title, cb)
                    trace("iStarX", "changed-exit", "nxts=%d reason=registered-pending title=%s" % (self.nxts, clean_title))  # DEBUG TRACE
                else:
                    trace("iStarX", "changed-exit", "nxts=%d reason=already-pending-same-title title=%s" % (self.nxts, clean_title))  # DEBUG TRACE
            else:
                self._clear_pending()
                trace("iStarX", "changed-exit", "nxts=%d reason=no-clean-title" % self.nxts)  # DEBUG TRACE
            
            self._show_zero()
                
        except:
            self._show_zero()

    def _clear_pending(self):
        if self._pending_title and self._pending_callback:
            unregister_metadata_callback(self._pending_title, self._pending_callback)
        self._pending_title = None
        self._pending_callback = None