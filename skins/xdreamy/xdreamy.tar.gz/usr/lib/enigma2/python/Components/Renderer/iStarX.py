#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iStarX.py - XDREAMY SKIN V7.1
Python 3 only. Star rating renderer.
"""

from Components.Renderer.Renderer import Renderer
from Components.VariableValue import VariableValue
from enigma import eSlider

from .iRendererBase import RendererMixin, parse_nxts_attribute
from .iDebugger import traced
from .iConverlibr import is_activated


class iStarX(RendererMixin, VariableValue, Renderer):
    GUI_WIDGET = eSlider

    def __init__(self):
        Renderer.__init__(self)
        VariableValue.__init__(self)
        RendererMixin.__init__(self)
        self.__start = 0
        self.__end = 100

    def destroy(self):
        self.mixin_destroy()
        Renderer.destroy(self)

    def applySkin(self, desktop, screen):
        self.nxts = parse_nxts_attribute(self.skinAttributes)
        self.mixin_apply_skin(None)
        return Renderer.applySkin(self, desktop, screen)

    def postWidgetCreate(self, instance):
        instance.setRange(self.__start, self.__end)

    @traced("iStarX")
    def changed(self, what):
        if not self.instance:
            return
        if not is_activated():
            self._show(0)
            return

        if what[0] == self.CHANGED_CLEAR:
            self.mixin_clear()
            self._show(0)
            return

        branch, payload = self.resolve_slot()
        if branch == "same":
            return

        if branch == "media":
            self._handle_media(payload)
            return

        if branch == "no_service":
            self._show(0)
            return

        slot = payload
        if not slot:
            self._show(0)
            return

        data = self.resolve_and_display_metadata(slot, emc_mode=False)
        if data is None:
            self._show(0)
            return
        rating = data.get("rating", 0)
        if rating and rating > 0:
            self._show(rating)
            self.mark_shown(slot.get("event_key", ""))
        else:
            self._show(0)

    def _handle_media(self, media):
        clean_title = media.get("clean_title", "")
        slot = {
            "clean_title": clean_title,
            "raw_name": clean_title.replace("_", " ").title() if clean_title else "",
            "description": "",
            "event_key": "",
            "skip": False,
        }
        data = self.resolve_and_display_metadata(slot, emc_mode=True)
        if data is None:
            self._show(0)
            return
        rating = data.get("rating", 0)
        self._show(rating if rating > 0 else 0)

    def _show(self, rating):
        try:
            self.instance.setValue(int(float(rating) * 10))
            self.instance.show()
        except Exception:
            pass
