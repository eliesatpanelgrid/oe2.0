#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iParental.py - XDREAMY SKIN V6.6.0
PARENTAL RATING ICON RENDERER - Uses unified helpers from iConverlibr
"""

from __future__ import absolute_import

import os
import sys
import json

from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, loadPNG, eEPGCache
from Components.config import config
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance
from ServiceReference import ServiceReference

from .iConverlibr import get_cached_clean_title, clean_name

epgcache = eEPGCache.getInstance()
if epgcache:
    epgcache.load()

path_folder = "/tmp/XDREAMY/poster"
for _mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
    test_path = os.path.join(_mount, "XDREAMY/poster")
    if os.path.exists(test_path):
        path_folder = test_path
        break

SCAN_STATE_FILE = os.path.join(path_folder, "scan_state.json")

DEFAULT_RATING = 'UN'

RATING_MAP = {
    'TV-Y': '0', 'TV-Y7': '6', 'TV-G': '0', 'TV-PG': '12',
    'TV-14': '16', 'TV-MA': '18', 'G': '0', 'PG': '6',
    'PG-13': '12', 'R': '16', 'NC-17': '18', 'PEGI-3': '0',
    'PEGI-7': '6', 'PEGI-12': '12', 'PEGI-16': '16', 'PEGI-18': '18',
    'FSK 0': '0', 'FSK 6': '6', 'FSK 12': '12', 'FSK 16': '16', 'FSK 18': '18',
    '0': '0', '6': '6', '12': '12', '16': '16', '18': '18',
    'U': '0', 'U/A': '12', 'A': '16', '': DEFAULT_RATING, 'UN': DEFAULT_RATING
}


def get_icon_path(rating_code):
    try:
        cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
        test_path = "/usr/share/enigma2/{}/parental/FSK_{}.png".format(cur_skin, rating_code)
        if os.path.exists(test_path):
            return test_path
    except:
        pass
    default_path = "/usr/share/enigma2/skin_default/parental/FSK_{}.png".format(rating_code)
    if os.path.exists(default_path):
        return default_path
    return None


class iParental(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.nxts = 0
        self.old_key = None

    def applySkin(self, desktop, screen):
        for attrib, value in self.skinAttributes:
            if attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except:
                    self.nxts = 0
        return Renderer.applySkin(self, desktop, screen)

    def _get_parental_rating(self, clean_title):
        try:
            if not os.path.exists(SCAN_STATE_FILE):
                return None
            with open(SCAN_STATE_FILE, 'r') as f:
                data = json.load(f)
            entries = data.get('entries', data) if isinstance(data, dict) else {}
            entry = entries.get(clean_title, {})
            if entry.get('status') in ['ok', 'found']:
                return entry.get('parental_rating', '')
            return None
        except Exception:
            return None

    def _show_icon(self, icon_path):
        try:
            if not self.instance:
                return
            if icon_path and os.path.exists(icon_path):
                pixmap = loadPNG(icon_path)
                if pixmap:
                    self.instance.setPixmap(pixmap)
                    self.instance.show()
                else:
                    self.instance.hide()
            else:
                self.instance.hide()
        except:
            self.instance.hide()

    def _read_canal(self):
        source = self.source
        source_type = type(source)
        service = None
        canal = [None] * 6

        try:
            if source_type is ServiceEvent:
                service = source.getCurrentService()
            elif source_type is CurrentService:
                service = source.getCurrentServiceRef()
            elif source_type is EventInfo:
                service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
            elif source_type is Event:
                if self.nxts:
                    service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                else:
                    if getattr(source, "event", None) is None:
                        return None
                    event = source.event
                    bt = event.getBeginTime()
                    if bt is not None:
                        canal[1] = bt
                    event_name = event.getEventName()
                    if not event_name:
                        return None
                    if sys.version_info[0] >= 3:
                        event_name = event_name.replace('\xc2\x86', '').replace('\xc2\x87', '')
                    else:
                        event_name = event_name.replace('\xc2\x86', '').replace('\xc2\x87', '').encode('utf-8')
                    canal[2] = event_name
                    canal[5] = event_name
                    return canal
            else:
                return None

            if service is not None:
                service_str = service.toString()
                events = epgcache.lookupEvent(['IBOCTESX', (service_str, 0, -1, -1)])
                if not events or len(events) <= self.nxts:
                    return None
                service_name = ServiceReference(service).getServiceName()
                if service_name:
                    service_name = clean_name(service_name)
                canal[0] = service_name
                canal[1] = events[self.nxts][1]
                canal[2] = clean_name(events[self.nxts][4])
                canal[5] = canal[2]
                return canal
        except Exception:
            return None
        return None

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self.old_key = None
            self.instance.hide()
            return

        canal = self._read_canal()
        if not canal or not canal[5]:
            self.instance.hide()
            return

        cur_key = "%s-%s" % (self.nxts, canal[5])
        if cur_key == self.old_key:
            return

        self.old_key = cur_key
        clean_title = get_cached_clean_title(canal[5])

        if clean_title:
            parental = self._get_parental_rating(clean_title)
            if parental:
                code = RATING_MAP.get(parental.upper(), DEFAULT_RATING)
                icon = get_icon_path(code)
                if icon:
                    self._show_icon(icon)
                    return

        default_icon = get_icon_path(DEFAULT_RATING)
        self._show_icon(default_icon)