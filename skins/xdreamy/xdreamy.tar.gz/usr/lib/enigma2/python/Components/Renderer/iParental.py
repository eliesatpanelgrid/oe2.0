#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iParental.py - XDREAMY SKIN V6.9.0
PARENTAL RATING ICON RENDERER - Reads from ZapContext only

V6.9.0: added generation-based dedup, dynamic nxts-slot registration, and
an in-memory icon cache for the FSK rating PNGs (there are only a handful
of distinct rating codes, so loadPNG() doesn't need to re-hit disk on
every single changed() call — same idea already applied to noposter.jpg
in iPosterX.py).

V6.8.1 fix (still in effect): the pending-metadata registration used to
stay locked onto whichever title was first seen. Fixed by keying the
pending registration to whatever clean_title is currently on screen.
"""

from __future__ import absolute_import

import os
import threading

from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, loadPNG
from Components.config import config
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance

from .iConverlibr import (
    get_zap_context,
    clean_name,
    convtext,
    register_metadata_callback,
    unregister_metadata_callback,
    register_nxts_slot,
)
from .iDebugTrace import trace  # DEBUG TRACE - remove this line + trace(...) calls when done diagnosing

DEFAULT_RATING = 'UN'

RATING_MAP = {
    'TV-Y': '0', 'TV-Y7': '6', 'TV-G': '0', 'TV-PG': '12',
    'TV-14': '16', 'TV-MA': '18', 'G': '0', 'PG': '6',
    'PG-13': '12', 'R': '16', 'NC-17': '18',
    'PEGI-3': '0', 'PEGI-7': '6', 'PEGI-12': '12',
    'PEGI-16': '16', 'PEGI-18': '18',
    'FSK 0': '0', 'FSK 6': '6', 'FSK 12': '12',
    'FSK 16': '16', 'FSK 18': '18',
    '0': '0', '6': '6', '12': '12', '16': '16', '18': '18',
    'U': '0', 'U/A': '12', 'A': '16',
    '': DEFAULT_RATING, 'UN': DEFAULT_RATING,
}

def _get_icon_path(rating_code):
    try:
        cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
        skin_path = "/usr/share/enigma2/%s/parental/FSK_%s.png" % (cur_skin, rating_code)
        if os.path.exists(skin_path):
            return skin_path
    except:
        pass
    default = "/usr/share/enigma2/skin_default/parental/FSK_%s.png" % rating_code
    return default if os.path.exists(default) else None

# In-memory pixmap cache, keyed by resolved icon path. There are only a
# handful of distinct FSK rating codes (0/6/12/16/18/UN), so the full set
# of pixmaps this skin will ever need gets loaded at most once each and
# reused for the rest of the session — same pattern as noposter.jpg in
# iPosterX.py. Guarded by a lock since multiple iParental widgets
# (different nxts) can all be loading the same icon in quick succession.
_icon_pixmap_cache = {}
_icon_cache_lock = threading.Lock()


def _get_cached_pixmap(icon_path):
    if not icon_path:
        return None
    pix = _icon_pixmap_cache.get(icon_path)
    if pix is not None:
        return pix
    with _icon_cache_lock:
        pix = _icon_pixmap_cache.get(icon_path)
        if pix is None:
            try:
                if os.path.exists(icon_path):
                    pix = loadPNG(icon_path)
                    if pix:
                        _icon_pixmap_cache[icon_path] = pix
            except Exception:
                pix = None
    return pix

class iParental(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.nxts = 0
        self.old_key = None
        self._pending_title = None
        self._pending_callback = None
        self._last_ref = None
        self._last_generation = -1

    def destroy(self):
        self._clear_pending()
        Renderer.destroy(self)

    def applySkin(self, desktop, screen):
        for attrib, value in self.skinAttributes:
            if attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except:
                    self.nxts = 0
        register_nxts_slot(self.nxts)
        return Renderer.applySkin(self, desktop, screen)

    def _get_service_ref(self):
        src = self.source
        stype = type(src)
        
        if stype is ServiceEvent:
            return src.getCurrentService()
        if stype is CurrentService:
            return src.getCurrentServiceRef()
        if stype is EventInfo:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if stype is Event:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return None

    def _on_metadata_ready(self, for_title):
        # Only repaint if we're still actually waiting on THIS title — if
        # the user zapped away, _pending_title has since moved on (or been
        # cleared) and this stale callback must not touch the widget.
        trace("iParental", "metadata-ready-fired", "nxts=%d title=%s still_waiting=%s" % (  # DEBUG TRACE
            self.nxts, for_title, self._pending_title == for_title))
        if self._pending_title == for_title and self.instance:
            self.old_key = None
            self._pending_title = None
            self._pending_callback = None
            self.changed((self.CHANGED_DEFAULT,))

    def _show_icon(self, icon_path):
        pix = _get_cached_pixmap(icon_path)
        if pix:
            try:
                self.instance.setPixmap(pix)
                self.instance.show()
                return
            except:
                pass
        try:
            self.instance.hide()
        except:
            pass

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._clear_pending()
            self.old_key = None
            self._last_ref = None
            self._last_generation = -1
            self.instance.hide()
            return

        trace("iParental", "changed-enter", "nxts=%d" % self.nxts)  # DEBUG TRACE

        try:
            service = self._get_service_ref()
            if service is None:
                self.instance.hide()
                return
            
            ctx = get_zap_context(service)
            if ctx is None:
                self.instance.hide()
                return

            # Generation dedup — see iPosterX.py for the full rationale.
            ref_str = ctx.ref_str
            if ref_str == self._last_ref and ctx.generation == self._last_generation:
                trace("iParental", "changed-exit", "nxts=%d reason=same-generation" % self.nxts)  # DEBUG TRACE
                return
            self._last_ref = ref_str
            self._last_generation = ctx.generation

            slot = ctx.get_slot(self.nxts)
            
            if not slot or slot.get('skip'):
                self._clear_pending()
                self.instance.hide()
                trace("iParental", "changed-exit", "nxts=%d reason=no-slot-or-skip" % self.nxts)  # DEBUG TRACE
                return

            cur_key = slot.get('event_key', '')
            if cur_key and cur_key == self.old_key:
                trace("iParental", "changed-exit", "nxts=%d reason=dedup-same-key" % self.nxts)  # DEBUG TRACE
                return
            self.old_key = cur_key

            parental = slot.get('parental', '')
            
            if parental:
                self._clear_pending()
                code = RATING_MAP.get(parental.upper(), DEFAULT_RATING)
                icon = _get_icon_path(code)
                if icon:
                    self._show_icon(icon)
                    trace("iParental", "changed-exit", "nxts=%d reason=rating-shown code=%s" % (self.nxts, code))  # DEBUG TRACE
                    return

            if slot.get('metadata_resolved'):
                # Already looked up and confirmed there's no parental
                # rating for this title — don't keep registering for a
                # callback that will never bring one. Same fix as iStarX.
                self._clear_pending()
                self._show_icon(_get_icon_path(DEFAULT_RATING))
                trace("iParental", "changed-exit", "nxts=%d reason=resolved-no-rating" % self.nxts)  # DEBUG TRACE
                return
            
            clean_title = slot.get('clean_title', '')
            if clean_title:
                # Switch the pending registration to whatever title is on
                # screen NOW — same fix as iStarX.py. Previously this was
                # "if clean_title and not self._pending_title", which got
                # stuck on the first unknown title seen and silently
                # skipped registering for any later title zapped to while
                # that first lookup was still in flight — exactly the
                # "works for N zaps, then blank until re-zap" symptom.
                if clean_title != self._pending_title:
                    self._clear_pending()
                    self._pending_title = clean_title
                    cb = lambda t=clean_title: self._on_metadata_ready(t)
                    self._pending_callback = cb
                    register_metadata_callback(clean_title, cb)
                    trace("iParental", "changed-exit", "nxts=%d reason=registered-pending title=%s" % (self.nxts, clean_title))  # DEBUG TRACE
                else:
                    trace("iParental", "changed-exit", "nxts=%d reason=already-pending-same-title title=%s" % (self.nxts, clean_title))  # DEBUG TRACE
            else:
                self._clear_pending()
                trace("iParental", "changed-exit", "nxts=%d reason=no-clean-title" % self.nxts)  # DEBUG TRACE
            
            self._show_icon(_get_icon_path(DEFAULT_RATING))
            
        except:
            self.instance.hide()

    def _clear_pending(self):
        if self._pending_title and self._pending_callback:
            unregister_metadata_callback(self._pending_title, self._pending_callback)
        self._pending_title = None
        self._pending_callback = None