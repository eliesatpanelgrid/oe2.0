#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iParental.py - XDREAMY SKIN V7.1
Python 3 only. Parental rating icon renderer.
"""

import os

from Components.Renderer.Renderer import Renderer
from Components.config import config
from enigma import ePixmap, loadPNG

from .iRendererBase import RendererMixin, parse_nxts_attribute
from .iDebugger import traced
from .iConverlibr import is_activated

DEFAULT_RATING = "UN"
_NO_ICON = object()

RATING_MAP = {
    "TV-Y": "0", "TV-Y7": "6", "TV-G": "0", "TV-PG": "12",
    "TV-14": "16", "TV-MA": "18", "G": "0", "PG": "6",
    "PG-13": "12", "R": "16", "NC-17": "18",
    "0": "0", "6": "6", "12": "12", "16": "16", "18": "18",
    "": DEFAULT_RATING, "UN": DEFAULT_RATING,
}

_icon_path_cache = {}
_icon_cache = {}


def _get_icon_path(rating_code):
    cached = _icon_path_cache.get(rating_code)
    if cached is not None:
        return cached if cached != _NO_ICON else None
    path = None
    try:
        cur_skin = config.skin.primary_skin.value.replace("/skin.xml", "")
        skin_path = "/usr/share/enigma2/%s/parental/FSK_%s.png" % (cur_skin, rating_code)
        if os.path.exists(skin_path):
            path = skin_path
    except Exception:
        pass
    if path is None:
        default = "/usr/share/enigma2/skin_default/parental/FSK_%s.png" % rating_code
        if os.path.exists(default):
            path = default
    _icon_path_cache[rating_code] = path if path is not None else _NO_ICON
    return path


def _get_icon_pixmap(rating_code):
    icon_path = _get_icon_path(rating_code)
    if not icon_path:
        return None
    pix = _icon_cache.get(icon_path)
    if pix is not None:
        return pix
    try:
        pix = loadPNG(icon_path)
        if pix:
            _icon_cache[icon_path] = pix
    except Exception:
        pix = None
    return pix


class iParental(RendererMixin, Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        RendererMixin.__init__(self)

    def destroy(self):
        self.mixin_destroy()
        Renderer.destroy(self)

    def applySkin(self, desktop, screen):
        self.nxts = parse_nxts_attribute(self.skinAttributes)
        self.mixin_apply_skin("parental")
        return Renderer.applySkin(self, desktop, screen)

    @traced("iParental")
    def changed(self, what):
        if not self.instance:
            return
        if not is_activated():
            self._show(None)
            return

        if what[0] == self.CHANGED_CLEAR:
            self.mixin_clear()
            self._show(DEFAULT_RATING)
            return

        branch, payload = self.resolve_slot()
        if branch == "same":
            return

        if branch == "media":
            self._handle_media(payload)
            return

        if branch == "no_service":
            self._show(None)
            return

        slot = payload
        if not slot:
            self._show(None)
            return

        data = self.resolve_and_display_metadata(slot, emc_mode=False)
        if data is None:
            self._show(None)
            return
        parental = data.get("parental", "")
        self._show(parental if parental else DEFAULT_RATING)
        self.mark_shown(slot.get("event_key", ""))

    def _handle_media(self, media):
        clean_title = media.get("clean_title", "")
        slot = {
            "clean_title": clean_title,
            "raw_name": clean_title.replace("_", " ").title() if clean_title else "",
            "description": "",
            "event_key": "",
            "skip": False,
        }
        data = self.resolve_and_display_metadata(slot, emc_mode=True)
        if data is None:
            self._show(None)
            return
        parental = data.get("parental", "")
        self._show(parental if parental else DEFAULT_RATING)

    def _show(self, rating):
        code = RATING_MAP.get((rating or "").upper(), DEFAULT_RATING)
        pix = _get_icon_pixmap(code)
        try:
            if pix:
                self.instance.setPixmap(pix)
                self.instance.show()
            else:
                self.instance.hide()
        except Exception:
            pass
