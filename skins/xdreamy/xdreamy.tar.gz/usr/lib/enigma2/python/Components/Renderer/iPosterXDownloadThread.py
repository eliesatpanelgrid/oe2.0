#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                          iPosterXDownloadThread.py                           ║
║                         XDREAMY SKIN V6.6.0 - 2026-06-08                     ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  HIGH-PERFORMANCE, BANDWIDTH-AWARE POSTER DOWNLOAD WORKER POOL               ║
║  ARCHITECTURE: 6 Workers (4 Live + 2 Prefetch)                               ║
║  FLAG SYSTEM: Instant enable/disable - NO CLASS RENAMING NEEDED              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from __future__ import absolute_import

import json
import os
import random
import re
import sys
import threading
import time

PY3 = sys.version_info[0] >= 3

if PY3:
    import queue as _queue
    from urllib.parse import quote as urlquote
else:
    import Queue as _queue
    from urllib import quote as urlquote

try:
    from PIL import Image
except Exception:
    Image = None

try:
    import requests
    http_session = requests.Session()
    try:
        adapter = requests.adapters.HTTPAdapter(pool_connections=6, pool_maxsize=6)
        http_session.mount("http://", adapter)
        http_session.mount("https://", adapter)
    except Exception:
        pass
    REQUESTS_OK = True
except Exception:
    requests = None
    http_session = None
    REQUESTS_OK = False

# ============================================================================
# POSTERX ENABLE/DISABLE FLAG (INSTANT CONTROL - NO CLASS RENAMING)
# ============================================================================

_POSTERX_ENABLED = True

def set_posterx_enabled(enabled):
    """
    Enable or disable PosterX downloader - instant effect, no restart needed.
    Call this from your plugin when user toggles the setting.
    """
    global _POSTERX_ENABLED
    _POSTERX_ENABLED = enabled
    log("PosterX downloader {}".format("enabled" if enabled else "disabled"))


def is_posterx_enabled():
    """Check if PosterX downloader is enabled."""
    return _POSTERX_ENABLED


# ---------------------------------------------------------------------------
# Storage Path Configuration
# ---------------------------------------------------------------------------

path_folder = "/tmp/XDREAMY/poster"
for _mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
    try:
        if os.path.exists(_mount) and os.access(_mount, os.W_OK):
            path_folder = os.path.join(_mount, "XDREAMY/poster")
            break
    except Exception:
        pass

try:
    if not os.path.exists(path_folder):
        os.makedirs(path_folder)
except Exception:
    pass

SCAN_STATE_FILE = os.path.join(path_folder, "scan_state.json")


# ---------------------------------------------------------------------------
# API Configuration & Limits
# ---------------------------------------------------------------------------

TMDB_API_KEY = "3c3efcf47c3577558812bb9d64019d65"
TMDB_SEARCH_MULTI = "https://api.themoviedb.org/3/search/multi"
TMDB_IMG_BASE = "https://image.tmdb.org/t/p/w185"
IMDB_SUGGEST = "https://v2.sg.media-imdb.com/suggestion/{letter}/{query}.json"

# Timeouts (seconds)
T_CONN = 1.5      # Connection timeout
T_READ = 3        # Read timeout
T_IMG = 6         # Image download timeout
MIN_BYTES = 4096  # Minimum valid image size

# Retry configuration - OPTIMIZED V6.5.2
MAX_RETRIES = 2
RETRY_DELAY_S = 7200  # CHANGED: 24 hours → 2 hours for faster recovery
FLUSH_EVERY = 50
STATE_VERSION = "5"  # UPDATED: New version with genre/year/overview
NETWORK_COOLDOWN_SECONDS = 10

# Status constants
STATUS_FOUND = "found"
STATUS_NOT_FOUND = "not_found"
STATUS_NETWORK = "network"
STATUS_SAVE_FAIL = "save_fail"

# Cache settings - OPTIMIZED V6.5.2
_negative_cache = {}
_negative_cache_expiry = 12 * 3600  # CHANGED: 48 hours → 12 hours
_pending_callbacks = {}
_callback_lock = threading.Lock()
_network_lock = threading.Lock()
_network_down_until = [0]

# GENRES MAP - For genre name mapping (restored for V6.5.2)
GENRES_MAP = {
    28: "Action", 12: "Adventure", 16: "Animation", 35: "Comedy",
    80: "Crime", 99: "Documentary", 18: "Drama", 10751: "Family",
    14: "Fantasy", 36: "History", 27: "Horror", 10402: "Music",
    9648: "Mystery", 10749: "Romance", 878: "Sci-Fi", 10770: "TV Movie",
    53: "Thriller", 10752: "War", 37: "Western", 10759: "Action & Adventure",
    10762: "Kids", 10763: "News", 10764: "Reality", 10765: "Sci-Fi & Fantasy",
    10766: "Soap", 10767: "Talk", 10768: "War & Politics"
}


# ---------------------------------------------------------------------------
# QUEUES WITH PREEMPTIVE OVERFLOW
# ---------------------------------------------------------------------------
live_queue = _queue.LifoQueue(maxsize=250)
prefetch_queue = _queue.LifoQueue(maxsize=500)

# Preemptive overflow settings
PREEMPTIVE_THRESHOLD = 180    # Trigger when live queue reaches 180
PREEMPTIVE_BATCH_SIZE = 100   # Move 100 items to prefetch

_pending = {}
_pending_expiry = 60
_pending_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Callback Registration System
# ---------------------------------------------------------------------------

def register_renderer_callback(clean_title, renderer_obj):
    """
    Register a renderer to be notified when poster download completes.
    
    Args:
        clean_title (str): Normalized title for callback lookup
        renderer_obj (object): Renderer with poster_download_completed method
    
    Returns:
        None
    """
    if not clean_title or renderer_obj is None:
        return
    with _callback_lock:
        if clean_title not in _pending_callbacks:
            _pending_callbacks[clean_title] = []
        if renderer_obj not in _pending_callbacks[clean_title]:
            _pending_callbacks[clean_title].append(renderer_obj)


def unregister_renderer(clean_title, renderer_obj):
    """
    Unregister a renderer from notifications.
    
    Args:
        clean_title (str): Normalized title
        renderer_obj (object): Renderer to remove
    
    Returns:
        None
    """
    with _callback_lock:
        if clean_title in _pending_callbacks:
            try:
                _pending_callbacks[clean_title].remove(renderer_obj)
            except Exception:
                pass
            if not _pending_callbacks[clean_title]:
                del _pending_callbacks[clean_title]


def _notify_download_success(clean_title, saved_path):
    """
    Internal: Notify registered renderers of successful download.
    
    Args:
        clean_title (str): Normalized title
        saved_path (str): Path to downloaded poster file
    
    Returns:
        None
    """
    if not clean_title or not saved_path or not os.path.exists(saved_path):
        return
    with _callback_lock:
        renderers = _pending_callbacks.pop(clean_title, None)
    if renderers:
        for renderer in renderers:
            try:
                renderer.poster_download_completed(clean_title, saved_path)
            except Exception:
                try:
                    renderer.poster_download_completed(saved_path)
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# Logging System
# ---------------------------------------------------------------------------

LOG_FILE = "/tmp/iPosterX.log"
LOG_MAX_BYTES = 1024 * 1024  # 1MB
_log_lock = threading.Lock()


def log_event(source, channel, raw_title, clean_title, status, provider, msg):
    """
    Write structured log entry for tracking poster downloads.
    
    Args:
        source (str): "live", "prefetch", or "SYSTEM"
        channel (str): Channel name or "-"
        raw_title (str): Original title before cleaning
        clean_title (str): Normalized title
        status (str): FOUND, NOT_FOUND, NETWORK, SAVE_FAIL, etc.
        provider (str): "TMDB", "IMDB", or "-"
        msg (str): Additional message/details
    
    Returns:
        None
    """
    try:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        line = "[%s] | [%s] | %s | %s | %s | %s | %s | %s\n" % (
            timestamp,
            str(source).upper(),
            str(channel or "-"),
            str(raw_title or "-"),
            str(clean_title or "-"),
            str(status).upper(),
            str(provider or "-"),
            str(msg or "")
        )
        with _log_lock:
            try:
                if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX_BYTES:
                    with open(LOG_FILE, "rb") as f:
                        f.seek(-(LOG_MAX_BYTES // 2), os.SEEK_END)
                        tail = f.read()
                    with open(LOG_FILE, "wb") as f:
                        f.write(tail)
            except Exception:
                pass
            with open(LOG_FILE, "a") as f:
                f.write(line)
    except Exception:
        pass


def log(msg, level="INFO"):
    """
    Simple log wrapper for system messages.
    
    Args:
        msg (str): Message to log
        level (str): Log level (INFO, WARN, ERROR)
    
    Returns:
        None
    """
    log_event("SYSTEM", "-", "-", "-", level, "-", msg)


# ---------------------------------------------------------------------------
# Network Status Management
# ---------------------------------------------------------------------------

def _now():
    """Return current Unix timestamp."""
    return int(time.time())


def network_available():
    """
    Check if network is available (not in cooldown).
    
    Returns:
        bool: True if network available, False if in cooldown
    """
    with _network_lock:
        return _now() >= int(_network_down_until[0])


def network_cooldown_left():
    """
    Get remaining network cooldown time.
    
    Returns:
        int: Seconds left in cooldown, 0 if none
    """
    with _network_lock:
        left = int(_network_down_until[0]) - _now()
    return left if left > 0 else 0


def mark_network_error(reason=None):
    """
    Mark network as failed, starting cooldown period.
    
    Args:
        reason (str, optional): Reason for network error
    
    Returns:
        None
    """
    with _network_lock:
        _network_down_until[0] = _now() + NETWORK_COOLDOWN_SECONDS
    if reason:
        log_event("NETWORK", "-", "-", "-", "COOLDOWN", "-", reason)


def mark_network_ok():
    """Clear network cooldown, marking network as available."""
    with _network_lock:
        _network_down_until[0] = 0


def _is_network_exception(err):
    """
    Check if exception is network-related.
    
    Args:
        err (Exception): Exception to check
    
    Returns:
        bool: True if network error
    """
    if requests is None:
        return True
    try:
        return isinstance(err, (
            requests.exceptions.Timeout,
            requests.exceptions.ConnectionError,
            requests.exceptions.RequestException,
        ))
    except Exception:
        return True


def _is_network_status(code):
    """
    Check if HTTP status code indicates network issue.
    
    Args:
        code (int): HTTP status code
    
    Returns:
        bool: True if network-related status
    """
    try:
        code = int(code)
    except Exception:
        return False
    return code == 408 or code == 429 or code >= 500


# ---------------------------------------------------------------------------
# State Cache Persistence (Central Database)
# ---------------------------------------------------------------------------

_state = {}
_state_lock = threading.Lock()
_dirty = [0]
_flush_ev = threading.Event()


def _set_state(title, status, retries=0, next_scan=0, vote_average=0, parental_rating="", genres="", year="", overview=""):
    """
    Central state storage - single source of truth for all poster data.
    
    Args:
        title (str): Normalized title
        status (str): "ok", "failed", or "pending"
        retries (int): Number of retry attempts
        next_scan (int): Unix timestamp for next scan attempt
        vote_average (float): TMDB rating (0-10)
        parental_rating (str): Certification (PG-13, R, etc.)
        genres (str): Comma-separated genre list
        year (str): Release year
        overview (str): Plot summary
    """
    with _state_lock:
        _state[title] = {
            "status": status,
            "retries": int(retries),
            "last_scan": int(time.time()),
            "next_scan": int(next_scan),
            "vote_average": float(vote_average),
            "parental_rating": str(parental_rating) if parental_rating else "",
            "genres": str(genres) if genres else "",
            "year": str(year) if year else "",
            "overview": str(overview) if overview else ""
        }
        _dirty[0] += 1
        if _dirty[0] >= FLUSH_EVERY:
            _flush_ev.set()


def _write_state():
    """
    Persist state dictionary to JSON file.
    
    Returns:
        None
    """
    try:
        if SCAN_STATE_FILE is None:
            return
        
        tmp = SCAN_STATE_FILE + ".tmp"
        data = {"_version": STATE_VERSION, "entries": _state}
        
        with open(tmp, "w") as f:
            json.dump(data, f)
            f.flush()
            os.fsync(f.fileno())
        
        if os.path.exists(tmp) and os.path.getsize(tmp) > 0:
            try:
                with open(tmp, "r") as f:
                    json.load(f)
            except Exception:
                log("Temp file invalid, skipping write", "WARN")
                return
            
            if os.path.exists(SCAN_STATE_FILE):
                os.remove(SCAN_STATE_FILE)
            os.rename(tmp, SCAN_STATE_FILE)
            _dirty[0] = 0
        else:
            log("Temp file empty, skipping write", "WARN")
            
    except Exception as e:
        log("Scan state write error: %s" % e, "WARN")


def _load_state():
    """
    Load state dictionary from JSON file.
    
    Returns:
        None
    """
    global _state
    try:
        if not os.path.exists(SCAN_STATE_FILE):
            return
        
        if os.path.getsize(SCAN_STATE_FILE) == 0:
            log("Scan state file is empty, skipping load", "WARN")
            return
            
        with open(SCAN_STATE_FILE, "r") as f:
            raw = json.load(f)
            
        entries = raw.get("entries", raw) if isinstance(raw, dict) else {}
        if not isinstance(entries, dict):
            return
            
        _state = entries
        
    except json.JSONDecodeError as e:
        log("Scan state JSON decode error: %s - file may be corrupted, will recreate" % e, "WARN")
        try:
            backup = SCAN_STATE_FILE + ".corrupted"
            os.rename(SCAN_STATE_FILE, backup)
            log("Backed up corrupted file to %s" % backup, "INFO")
        except Exception:
            pass
        _state = {}
    except Exception as e:
        log("Scan state load error: %s" % e, "WARN")
        _state = {}


def state_is_ok(title):
    """
    Check if poster already exists in state as "ok".
    
    Args:
        title (str): Normalized title
    
    Returns:
        bool: True if poster exists and status is ok
    """
    with _state_lock:
        st = _state.get(title)
        return st is not None and st.get("status") == "ok"


def _mark_found(title, vote_average=0, parental_rating="", genres="", year="", overview=""):
    """
    Mark title as successfully downloaded with rating and metadata.
    
    Args:
        title (str): Normalized title
        vote_average (float): TMDB rating
        parental_rating (str): Certification rating
        genres (str): Comma-separated genres
        year (str): Release year
        overview (str): Plot summary
    """
    _set_state(title, "ok", 0, 0, vote_average, parental_rating, genres, year, overview)
    try:
        if title in _negative_cache:
            del _negative_cache[title]
    except Exception:
        pass


def _mark_not_found(title):
    """
    Mark title as not found (failed after retries).
    
    Args:
        title (str): Normalized title
    
    Returns:
        None
    """
    with _state_lock:
        old = _state.get(title, {})
        retries = int(old.get("retries", 0)) + 1
    if retries >= MAX_RETRIES:
        _set_state(title, "failed", retries, 0, 0, "", "", "", "")
        _negative_cache[title] = time.time()
    else:
        _set_state(title, "failed", retries, int(time.time()) + RETRY_DELAY_S, 0, "", "", "", "")


def _should_download(title, poster_path):
    """
    Determine if poster should be downloaded based on state and cache.
    
    Args:
        title (str): Normalized title
        poster_path (str): Destination file path
    
    Returns:
        bool: True if download needed
    """
    if os.path.exists(poster_path):
        if not state_is_ok(title):
            _mark_found(title, 0, "", "", "", "")
        return False

    if title in _negative_cache:
        cache_time = _negative_cache[title]
        if time.time() - cache_time < _negative_cache_expiry:
            return False
        else:
            del _negative_cache[title]

    with _state_lock:
        st = _state.get(title)

    if st is None:
        return True

    status = st.get("status", "pending")
    retries = int(st.get("retries", 0))
    next_sc = int(st.get("next_scan", 0))

    if status == "ok":
        return False
    if status == "failed":
        if retries >= MAX_RETRIES:
            return False
        return time.time() >= next_sc
    return True


# ---------------------------------------------------------------------------
# Parental Rating Fetching
# ---------------------------------------------------------------------------

def _fetch_parental_rating(media_id, media_type):
    """
    Fetch certification/parental rating from TMDB.
    
    Args:
        media_id (str/int): TMDB media ID
        media_type (str): "movie" or "tv"
    
    Returns:
        str: Rating like "PG-13", "R", or empty string if not found
    """
    if not REQUESTS_OK or not network_available():
        return ""
    
    try:
        if media_type == "movie":
            url = "https://api.themoviedb.org/3/movie/%s/release_dates?api_key=%s" % (media_id, TMDB_API_KEY)
        else:
            url = "https://api.themoviedb.org/3/tv/%s/content_ratings?api_key=%s" % (media_id, TMDB_API_KEY)
        
        resp = http_session.get(url, headers={"User-Agent": _ua()}, timeout=(T_CONN, T_READ), verify=False)
        
        if not resp.ok:
            return ""
        
        data = resp.json()
        
        if media_type == "movie":
            for country in data.get("results", []):
                iso = country.get("iso_3166_1", "")
                if iso == "US":
                    for rd in country.get("release_dates", []):
                        cert = rd.get("certification", "")
                        if cert:
                            return cert
                elif iso in ["GB", "DE", "FR", "IT", "ES"]:
                    for rd in country.get("release_dates", []):
                        cert = rd.get("certification", "")
                        if cert:
                            return cert
        else:
            for country in data.get("results", []):
                iso = country.get("iso_3166_1", "")
                if iso == "US":
                    for rt in country.get("ratings", []):
                        cert = rt.get("rating", "")
                        if cert:
                            return cert
                elif iso in ["GB", "DE", "FR", "IT", "ES"]:
                    for rt in country.get("ratings", []):
                        cert = rt.get("rating", "")
                        if cert:
                            return cert
        
        return ""
    except Exception as e:
        return ""


# ---------------------------------------------------------------------------
# Queue Management with Preemptive Overflow
# ---------------------------------------------------------------------------

def _release(title):
    """Remove title from pending tasks."""
    with _pending_lock:
        if title in _pending:
            del _pending[title]


def _cleanup_stale_pending():
    """Remove pending tasks older than expiry time."""
    now = time.time()
    with _pending_lock:
        stale = [t for t, ts in _pending.items() if now - ts > _pending_expiry]
        for s in stale:
            del _pending[s]


def _unique_items(items):
    """
    Deduplicate list while preserving order.
    
    Args:
        items (list): List of strings to deduplicate
    
    Returns:
        list: Deduplicated list
    """
    out = []
    seen = set()
    for item in items or []:
        if not item:
            continue
        try:
            value = item.strip()
        except Exception:
            value = str(item).strip()
        key = value.lower()
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(value)
    return out


def _queue_common(clean_title, canal, q, source, candidates=None):
    """
    Core queue logic with preemptive overflow protection.
    
    Args:
        clean_title (str): Normalized title
        canal (list): Channel info [name, ...]
        q (Queue): Target queue (live_queue or prefetch_queue)
        source (str): "live" or "prefetch"
        candidates (list, optional): Alternative search titles
    
    Returns:
        bool: True if queued successfully
    """
    if not clean_title:
        return False
    
    dest = "%s/%s.jpg" % (path_folder, clean_title)
    if os.path.exists(dest):
        return False
    
    _cleanup_stale_pending()
    
    with _pending_lock:
        if clean_title in _pending:
            return False
        _pending[clean_title] = time.time()
    
    try:
        raw = canal[5] if canal and len(canal) > 5 else clean_title
        ch = canal[0] if canal and len(canal) > 0 else "-"
        tries = _unique_items(candidates or [clean_title])
        if not tries:
            tries = [clean_title]
        
        # =========================================================
        # PREEMPTIVE OVERFLOW - Proactive queue management
        # When live_queue reaches threshold, move batch to prefetch
        # This prevents queue from ever becoming full
        # =========================================================
        if q is live_queue and q.qsize() >= PREEMPTIVE_THRESHOLD:
            moved = 0
            for _ in range(PREEMPTIVE_BATCH_SIZE):
                try:
                    oldest = q.get_nowait()
                    prefetch_queue.put_nowait(oldest)
                    moved += 1
                except (_queue.Empty, _queue.Full):
                    break
            if moved > 0:
                log_event("LIVE", "-", "-", "-", "PREEMPTIVE_OVERFLOW", "-", 
                         f"moved {moved} items to prefetch (queue was {q.qsize() + moved}, now {q.qsize()})")
        
        q.put_nowait((clean_title, raw, ch, tries))
        return True
        
    except _queue.Full:
        _release(clean_title)
        return False


def queue_live(clean_title, canal, candidates=None):
    """
    Queue a title for high-priority live (UI) processing.
    
    Args:
        clean_title (str): Normalized title
        canal (list): Channel info
        candidates (list, optional): Alternative search titles
    
    Returns:
        bool: True if queued successfully
    """
    return _queue_common(clean_title, canal, live_queue, "live", candidates)


def queue_prefetch(clean_title, canal, candidates=None):
    """
    Queue a title for low-priority background prefetch processing.
    
    Args:
        clean_title (str): Normalized title
        canal (list): Channel info
        candidates (list, optional): Alternative search titles
    
    Returns:
        bool: True if queued successfully
    """
    return _queue_common(clean_title, canal, prefetch_queue, "prefetch", candidates)


# ---------------------------------------------------------------------------
# Metadata Providers (TMDB, IMDB)
# ---------------------------------------------------------------------------

_UA = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Firefox/115.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/114.0",
]


def _ua():
    """Return random User-Agent string."""
    return random.choice(_UA)


def _tmdb_search(title):
    """
    Search TMDB for poster, rating, parental rating, genres, year, overview.
    
    Args:
        title (str): Movie/TV show title to search
    
    Returns:
        tuple: (status, url, vote_average, parental_rating, genres, year, overview)
    """
    if not REQUESTS_OK or not title or not network_available():
        return STATUS_NETWORK, None, 0, "", "", "", ""
    
    try:
        resp = http_session.get(
            TMDB_SEARCH_MULTI,
            params={"api_key": TMDB_API_KEY, "language": "en", "include_adult": "false", "query": title},
            headers={"User-Agent": _ua()},
            timeout=(T_CONN, T_READ),
            verify=False,
        )
        if not resp.ok:
            if _is_network_status(resp.status_code):
                return STATUS_NETWORK, None, 0, "", "", "", ""
            return STATUS_NOT_FOUND, None, 0, "", "", "", ""
        
        mark_network_ok()
        results = resp.json().get("results", [])
        
        for item in results:
            media_type = item.get("media_type")
            if media_type not in ("movie", "tv"):
                continue
            
            poster_path = item.get("poster_path")
            if not poster_path:
                continue
            
            media_id = item.get("id")
            vote_average = item.get("vote_average", 0)
            
            # Fetch parental rating
            parental_rating = _fetch_parental_rating(media_id, media_type)
            
            # Extract genres
            genre_names = []
            for gid in item.get("genre_ids", []):
                if gid in GENRES_MAP:
                    genre_names.append(GENRES_MAP[gid])
            genres = ", ".join(genre_names)
            
            # Extract year
            year = (item.get("release_date") or item.get("first_air_date") or "")[:4]
            
            # Extract overview
            overview = item.get("overview", "")
            
            return STATUS_FOUND, TMDB_IMG_BASE + poster_path, vote_average, parental_rating, genres, year, overview
        
        return STATUS_NOT_FOUND, None, 0, "", "", "", ""
        
    except Exception as e:
        if _is_network_exception(e):
            return STATUS_NETWORK, None, 0, "", "", "", ""
        return STATUS_NOT_FOUND, None, 0, "", "", "", ""


def _imdb_search(title):
    """
    Search IMDB for poster (fallback when TMDB fails).
    
    Args:
        title (str): Movie/TV show title to search
    
    Returns:
        tuple: (status, url, vote_average)
    """
    if not REQUESTS_OK or not title or not network_available():
        return STATUS_NETWORK, None, 0
    
    try:
        letter = title[0].lower() if title[0].isalpha() else "a"
        url = IMDB_SUGGEST.format(letter=letter, query=urlquote(title))
        resp = http_session.get(
            url,
            headers={"User-Agent": _ua(), "Accept": "application/json"},
            timeout=(T_CONN, T_READ),
        )
        if not resp.ok:
            if _is_network_status(resp.status_code):
                return STATUS_NETWORK, None, 0
            return STATUS_NOT_FOUND, None, 0
        
        mark_network_ok()
        for item in resp.json().get("d", []):
            img = item.get("i")
            url = None
            if isinstance(img, dict):
                url = img.get("imageUrl", "")
            elif isinstance(img, (list, tuple)) and img:
                url = img[0]
            if url and url.startswith("http"):
                return STATUS_FOUND, url, 0
        
        return STATUS_NOT_FOUND, None, 0
        
    except Exception as e:
        if _is_network_exception(e):
            return STATUS_NETWORK, None, 0
        return STATUS_NOT_FOUND, None, 0


def _find_url(title, source, candidates=None):
    """
    Master search function coordinating TMDB and IMDB lookups.
    
    Args:
        title (str): Normalized title to search
        source (str): "live" or "prefetch"
        candidates (list, optional): Alternative titles to try
    
    Returns:
        tuple: (status, url, vote_average, parental_rating, genres, year, overview, provider)
    """
    provider = "TMDB"
    tries = _unique_items(candidates or [title])
    if source == "prefetch":
        tries = tries[:2]   # Prefetch tries fewer variations
    else:
        tries = tries[:4]   # Live tries more variations
    
    if not tries:
        tries = [title]

    for candidate in tries:
        status, url, vote_average, parental_rating, genres, year, overview = _tmdb_search(candidate)
        if status == STATUS_FOUND:
            return STATUS_FOUND, url, vote_average, parental_rating, genres, year, overview, provider
        if status == STATUS_NETWORK:
            return STATUS_NETWORK, None, 0, "", "", "", "", provider

    # Fallback to IMDB for live requests only
    if source == "live":
        status, url, vote_average = _imdb_search(tries[0])
        provider = "IMDB"
        if status == STATUS_FOUND:
            return STATUS_FOUND, url, vote_average, "", "", "", "", provider
        if status == STATUS_NETWORK:
            return STATUS_NETWORK, None, 0, "", "", "", "", provider

    # Smart fallback: Try stripping numbers from title (e.g., "Rod smoka 12" -> "Rod smoka")
    fallback_match = re.search(r"^(.*?)\s+(\d+)$", tries[0])
    if fallback_match:
        try:
            number = int(fallback_match.group(2))
        except Exception:
            number = 0
        base_title = fallback_match.group(1).strip()
        if number > 10 and len(base_title) >= 3:
            status, url, vote_average, parental_rating, genres, year, overview = _tmdb_search(base_title)
            provider = "TMDB"
            if status == STATUS_FOUND:
                return STATUS_FOUND, url, vote_average, parental_rating, genres, year, overview, provider
            if status == STATUS_NETWORK:
                return STATUS_NETWORK, None, 0, "", "", "", "", provider

    return STATUS_NOT_FOUND, None, 0, "", "", "", "", provider


# ---------------------------------------------------------------------------
# Poster Download & Save
# ---------------------------------------------------------------------------

def _save_poster(url, dest):
    """
    Download poster from URL and save to disk.
    
    Args:
        url (str): Poster image URL
        dest (str): Destination file path
    
    Returns:
        str: STATUS_FOUND, STATUS_NETWORK, or STATUS_SAVE_FAIL
    """
    if not REQUESTS_OK or not network_available():
        return STATUS_NETWORK
    tmp = dest + ".part"
    try:
        resp = http_session.get(
            url,
            headers={"User-Agent": _ua()},
            timeout=(T_CONN, T_IMG),
            verify=False,
            stream=False
        )
        if not resp.ok:
            if _is_network_status(resp.status_code):
                return STATUS_NETWORK
            return STATUS_SAVE_FAIL
        data = resp.content
        if not data or len(data) < MIN_BYTES:
            return STATUS_SAVE_FAIL
        with open(tmp, "wb") as f:
            f.write(data)
        if Image is not None:
            try:
                img = Image.open(tmp)
                img.verify()
                img.close()
            except Exception:
                return STATUS_SAVE_FAIL
        try:
            os.rename(tmp, dest)
        except Exception:
            if os.path.exists(dest):
                try:
                    os.remove(dest)
                except Exception:
                    pass
            os.rename(tmp, dest)
        if os.path.exists(dest):
            mark_network_ok()
            return STATUS_FOUND
        return STATUS_SAVE_FAIL
    except Exception as e:
        if _is_network_exception(e):
            return STATUS_NETWORK
        return STATUS_SAVE_FAIL
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Worker Processing Logic
# ---------------------------------------------------------------------------

def _process(item, source):
    """
    Main processing logic for each queued item.
    
    Args:
        item (tuple): (clean_title, raw, ch, candidates)
        source (str): "live" or "prefetch"
    
    Returns:
        None
    """
    if len(item) >= 4:
        clean_title, raw, ch, candidates = item
    else:
        clean_title, raw, ch = item
        candidates = [clean_title]
    t0 = time.time()
    try:
        dest = "%s/%s.jpg" % (path_folder, clean_title)

        if not _should_download(clean_title, dest):
            if os.path.exists(dest):
                _notify_download_success(clean_title, dest)
            return

        if not network_available():
            log_event(source, ch, raw, clean_title, "SKIP", "-", "network cooldown %ds" % network_cooldown_left())
            return

        status, url, vote_average, parental_rating, genres, year, overview, provider = _find_url(clean_title, source, candidates)

        if status == STATUS_NETWORK:
            mark_network_error("search failed for %s" % clean_title)
            log_event(source, ch, raw, clean_title, "NETWORK", provider, "search/network error")
            return

        if status == STATUS_FOUND and url:
            save_status = _save_poster(url, dest)
            if save_status == STATUS_FOUND:
                # Store everything in central database
                _mark_found(clean_title, vote_average, parental_rating, genres, year, overview)
                elapsed = round(time.time() - t0, 2)
                log_event(source, ch, raw, clean_title, "FOUND", provider, 
                         "saved in %ss rating=%.1f parental=%s genres=%s year=%s" % (elapsed, vote_average, parental_rating, genres, year))
                _notify_download_success(clean_title, dest)
            elif save_status == STATUS_NETWORK:
                mark_network_error("download failed for %s" % clean_title)
                log_event(source, ch, raw, clean_title, "NETWORK", provider, "download/network error")
            else:
                log_event(source, ch, raw, clean_title, "SAVE_FAIL", provider, "save/verify error")
                _mark_not_found(clean_title)
        else:
            _mark_not_found(clean_title)
            log_event(source, ch, raw, clean_title, "NOT_FOUND", "-", "not found")
    except Exception as e:
        log("Process error: %s" % e, "ERROR")
    finally:
        _release(clean_title)


# ---------------------------------------------------------------------------
# Worker Thread Class
# ---------------------------------------------------------------------------

class iPosterXDownloadThread(threading.Thread):
    """
    Worker thread for processing poster download queues.
    
    Architecture V6.5.2:
    - Workers 0-3: allow_prefetch=False (LIVE only)
    - Workers 4-5: allow_prefetch=True (PREFETCH capable)
    
    Attributes:
        allow_prefetch (bool): If True, can process prefetch_queue when live is empty
    """
    
    def __init__(self, allow_prefetch=True):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        self.allow_prefetch = allow_prefetch

class iPosterXDownloadThread(threading.Thread):
    """
    Worker thread for processing poster download queues.
    
    Architecture V6.5.2:
    - Workers 0-3: allow_prefetch=False (LIVE only)
    - Workers 4-5: allow_prefetch=True (PREFETCH capable)
    
    Attributes:
        allow_prefetch (bool): If True, can process prefetch_queue when live is empty
    """
    
    def __init__(self, allow_prefetch=True):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        self.allow_prefetch = allow_prefetch

    def run(self):
        """
        Main worker loop with OPTIMIZED timing and FLAG CHECK.
        When disabled, workers sleep and don't process any downloads.
        """
        while True:
            # ============================================================
            # CHECK FLAG BEFORE PROCESSING - Exit if disabled
            # ============================================================
            if not _POSTERX_ENABLED:
                time.sleep(1)  # Wait and check again
                continue
            
            try:
                # Process live queue first (always high priority)
                try:
                    item = live_queue.get(timeout=0.5)
                    _process(item, "live")
                    continue
                except _queue.Empty:
                    pass

                # Process prefetch queue if this worker allows it
                if self.allow_prefetch:
                    try:
                        item = prefetch_queue.get(timeout=0.5)
                        _process(item, "prefetch")
                        continue
                    except _queue.Empty:
                        pass
                else:
                    # Live-only worker: minimal sleep to prevent CPU spinning
                    time.sleep(0.005)
            except Exception:
                time.sleep(0.1)


# ---------------------------------------------------------------------------
# Initialization (Start Worker Pool) - WITH FLAG CHECK
# ---------------------------------------------------------------------------

def _flush_loop():
    """Background thread for periodic state flushing."""
    while True:
        _flush_ev.wait(timeout=60)
        _flush_ev.clear()
        with _state_lock:
            if _dirty[0] > 0:
                _write_state()


def _async_initialize():
    """
    Initialize worker pool and load persisted state.
    
    V6.5.2 Worker Architecture (4 Live + 2 Prefetch):
    ┌─────────────────────────────────────────────────────────────────┐
    │ Worker 0: allow_prefetch=False  → LIVE only (UI critical)       │
    │ Worker 1: allow_prefetch=False  → LIVE only (UI critical)       │
    │ Worker 2: allow_prefetch=False  → LIVE only (UI critical)       │
    │ Worker 3: allow_prefetch=False  → LIVE only (UI critical)       │
    │ Worker 4: allow_prefetch=True   → PREFETCH capable              │
    │ Worker 5: allow_prefetch=True   → PREFETCH capable              │
    └─────────────────────────────────────────────────────────────────┘
    
    Benefits:
    - 4 dedicated live workers ensure UI responsiveness
    - 2 prefetch workers handle background loading
    - Prefetch workers also help with live queue when idle
    - Optimized timing values for maximum performance
    """
    # ================================================================
    # FLAG CHECK: If disabled, don't start any workers!
    # ================================================================
    if not _POSTERX_ENABLED:
        log("PosterX downloader is DISABLED - workers not started")
        # Still start flush loop? No, because _state never changes
        return
    
    _load_state()
    
    # Start 6 worker threads (4 Live + 2 Prefetch for V6.5.2):
    # - Workers 0-3: Live ONLY (4 workers dedicated to UI-critical tasks)
    # - Workers 4-5: Prefetch capable (2 workers for background tasks)
    for _idx in range(6):
        # First 4 workers (0-3) are LIVE ONLY (prefetch=False)
        # Workers 4-5 are PREFETCH capable (prefetch=True)
        allow_prefetch = (_idx >= 4)  # Workers 4 and 5 can do prefetch
        t = iPosterXDownloadThread(allow_prefetch=allow_prefetch)
        t.start()
        log(f"Worker {_idx} started ({'PREFETCH' if allow_prefetch else 'LIVE'})")

    t_flush = threading.Thread(target=_flush_loop)
    t_flush.setDaemon(True)
    t_flush.start()


# Start initialization in background thread (non-blocking)
_init_thread = threading.Thread(target=_async_initialize)
_init_thread.setDaemon(True)
_init_thread.start()