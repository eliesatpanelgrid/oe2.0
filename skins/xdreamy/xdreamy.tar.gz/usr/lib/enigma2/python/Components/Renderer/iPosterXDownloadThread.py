#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iPosterXDownloadThread.py - XDREAMY SKIN V7.1.0
FIX: added missing file_exists_cached import.
"""

from __future__ import absolute_import

import json
import os
import random
import re
import threading
import time
import queue as _queue

try:
    from PIL import Image
except Exception:
    Image = None

try:
    import requests
    http_session = requests.Session()
    try:
        adapter = requests.adapters.HTTPAdapter(pool_connections=4, pool_maxsize=4)
        http_session.mount("http://", adapter)
        http_session.mount("https://", adapter)
    except Exception:
        pass
    REQUESTS_OK = True
except Exception:
    requests = None
    http_session = None
    REQUESTS_OK = False

from .iConverlibr import (
    SCAN_STATE_FILE,
    get_poster_folder,
    get_logo_folder,
    get_cfg,
    notify_metadata_callbacks,
    queue_gui_callback,
    set_batch_poster_queue_fn,
    set_batch_logo_queue_fn,
    set_state_overlay_fn,
    get_cached_search,
    set_cached_search,
    invalidate_file_cache,
    file_exists_cached,          # <-- FIX: added missing import
    clean_name,
    convtext,
)
from .iDebugTrace import trace, timed_block

# ============================================================================
# CONSTANTS
# ============================================================================

TMDB_SEARCH_MULTI = "https://api.themoviedb.org/3/search/multi"
TMDB_IMG_W185     = "https://image.tmdb.org/t/p/w185"
TMDB_IMG_ORIG     = "https://image.tmdb.org/t/p/original"
IMDB_SUGGEST      = "https://v2.sg.media-imdb.com/suggestion/{letter}/{query}.json"

T_CONN = 1.5
T_READ = 3
T_IMG  = 6
MIN_BYTES = 4096

MAX_RETRIES   = 2
RETRY_DELAY_S = 7200
FLUSH_EVERY   = 50
STATE_VERSION = "7"
NET_COOLDOWN  = 10

CLEANUP_DAYS_FAILED  = 7
CLEANUP_DAYS_EMPTY   = 2
CLEANUP_DAYS_SUCCESS = 180
CLEANUP_INTERVAL_S   = 6 * 3600

STATUS_FOUND     = "found"
STATUS_NOT_FOUND = "not_found"
STATUS_NETWORK   = "network"
STATUS_SAVE_FAIL = "save_fail"

GENRES_MAP = {
    28: "Action", 12: "Adventure", 16: "Animation", 35: "Comedy",
    80: "Crime", 99: "Documentary", 18: "Drama", 10751: "Family",
    14: "Fantasy", 36: "History", 27: "Horror", 10402: "Music",
    9648: "Mystery", 10749: "Romance", 878: "Sci-Fi", 10770: "TV Movie",
    53: "Thriller", 10752: "War", 37: "Western", 10759: "Action & Adventure",
    10762: "Kids", 10763: "News", 10764: "Reality", 10765: "Sci-Fi & Fantasy",
    10766: "Soap", 10767: "Talk", 10768: "War & Politics",
}

_EMPTY13 = (STATUS_NOT_FOUND, None, 0, "", "", "", "", "", "", "", "", "-", "")
_NET13   = (STATUS_NETWORK,   None, 0, "", "", "", "", "", "", "", "", "-", "")

# ============================================================================
# BACKDROP URL CACHE (shared with backdrop downloader)
# ============================================================================

_backdrop_cache = {}
_backdrop_cache_lock = threading.Lock()
_BACKDROP_CACHE_TTL = 120  # 2 minutes

def set_backdrop_url(clean_title, url):
    with _backdrop_cache_lock:
        _backdrop_cache[clean_title] = (url, time.time())

def get_backdrop_url(clean_title):
    with _backdrop_cache_lock:
        entry = _backdrop_cache.get(clean_title)
        if entry:
            url, ts = entry
            if time.time() - ts < _BACKDROP_CACHE_TTL:
                return url
            else:
                del _backdrop_cache[clean_title]
        return None

# ============================================================================
# WORK QUEUE
# ============================================================================

work_queue    = _queue.Queue(maxsize=200)
_pending      = {}
_pending_lock = threading.Lock()

# ============================================================================
# CALLBACK REGISTRATION
# ============================================================================

_poster_callbacks = {}
_logo_callbacks   = {}
_poster_cb_lock   = threading.Lock()
_logo_cb_lock     = threading.Lock()

def register_renderer_callback(clean_title, renderer_obj):
    if not clean_title or renderer_obj is None:
        return
    with _poster_cb_lock:
        bucket = _poster_callbacks.setdefault(clean_title, [])
        if renderer_obj not in bucket:
            bucket.append(renderer_obj)

def unregister_renderer(clean_title, renderer_obj):
    with _poster_cb_lock:
        bucket = _poster_callbacks.get(clean_title)
        if not bucket:
            return
        try:
            bucket.remove(renderer_obj)
        except ValueError:
            return
        if not bucket:
            del _poster_callbacks[clean_title]

def register_logo_callback(clean_title, renderer_obj):
    if not clean_title or renderer_obj is None:
        return
    with _logo_cb_lock:
        bucket = _logo_callbacks.setdefault(clean_title, [])
        if renderer_obj not in bucket:
            bucket.append(renderer_obj)

def unregister_logo_renderer(clean_title, renderer_obj):
    with _logo_cb_lock:
        bucket = _logo_callbacks.get(clean_title)
        if not bucket:
            return
        try:
            bucket.remove(renderer_obj)
        except ValueError:
            return
        if not bucket:
            del _logo_callbacks[clean_title]

def _notify_poster_success(clean_title, saved_path):
    if not clean_title or not saved_path or not os.path.exists(saved_path):
        return
    invalidate_file_cache(saved_path)
    with _poster_cb_lock:
        renderers = _poster_callbacks.pop(clean_title, None)
    if not renderers:
        return
    for r in renderers:
        queue_gui_callback(r.poster_download_completed, clean_title, saved_path)

def _notify_logo_success(clean_title, saved_path):
    if not clean_title or not saved_path or not os.path.exists(saved_path):
        return
    invalidate_file_cache(saved_path)
    with _logo_cb_lock:
        renderers = _logo_callbacks.pop(clean_title, None)
    if not renderers:
        return
    for r in renderers:
        queue_gui_callback(r.logo_download_completed, clean_title, saved_path)

# ============================================================================
# LOGGING
# ============================================================================

LOG_FILE      = "/tmp/iPosterX.log"
LOG_MAX_BYTES = 1024 * 1024

def log_event(source, ch, raw, clean, status, provider, msg):
    try:
        line = "[%s] | [%s] | %s | %s | %s | %s | %s | %s\n" % (
            time.strftime("%Y-%m-%d %H:%M:%S"), str(source).upper(),
            ch or "-", raw or "-", clean or "-",
            str(status).upper(), provider or "-", msg or "")
        try:
            if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX_BYTES:
                with open(LOG_FILE, "rb") as f:
                    f.seek(-(LOG_MAX_BYTES // 2), os.SEEK_END)
                    tail = f.read()
                with open(LOG_FILE, "wb") as f:
                    f.write(tail)
        except Exception:
            pass
        with open(LOG_FILE, "a") as f:
            f.write(line)
    except Exception:
        pass

def log(msg, level="INFO"):
    log_event("SYSTEM", "-", "-", "-", level, "-", msg)

# ============================================================================
# NETWORK STATUS
# ============================================================================

_net_down_until = [0]

def _now():
    return int(time.time())

def network_available():
    return _now() >= _net_down_until[0]

def mark_network_error(reason=None):
    _net_down_until[0] = _now() + NET_COOLDOWN

def mark_network_ok():
    _net_down_until[0] = 0

def _is_net_exc(err):
    if requests is None:
        return True
    try:
        return isinstance(err, (requests.exceptions.Timeout,
                                requests.exceptions.ConnectionError,
                                requests.exceptions.RequestException))
    except Exception:
        return True

def _is_net_status(code):
    try:
        code = int(code)
    except Exception:
        return False
    return code in (408, 429) or code >= 500

# ============================================================================
# STATE PERSISTENCE
# ============================================================================

_state        = {}
_state_lock   = threading.Lock()
_write_lock   = threading.Lock()
_dirty        = [0]
_flush_ev     = threading.Event()
_last_cleanup = [0]
_neg_cache    = {}
_neg_expiry   = 12 * 3600

def _get_state_snapshot():
    with _state_lock:
        return dict(_state)

def _normalize_parental(rating):
    if not rating:
        return ""
    rating = rating.upper().strip()
    mapping = {"T": "TV-14", "VM14": "TV-14", "VM18": "TV-MA",
               "14+": "TV-14", "16+": "TV-MA", "18+": "R",
               "M": "PG-13", "MA15+": "TV-MA"}
    if rating in mapping:
        return mapping[rating]
    valid = ["R", "PG-13", "PG", "G", "TV-MA", "TV-14", "TV-PG", "TV-Y7", "TV-Y"]
    return rating if rating in valid else ""

def _has_useful_data(entry):
    return any([
        entry.get("vote_average", 0) > 0,
        entry.get("parental_rating", ""),
        entry.get("genres", ""),
        entry.get("year", ""),
        entry.get("director", ""),
        entry.get("cast", ""),
        len(entry.get("overview", "")) > 50,
        entry.get("title", ""),
    ])

def _set_state(title, status, retries=0, next_scan=0, vote_average=0,
               parental_rating="", genres="", year="", overview="",
               director="", cast="", country="", item_title=""):
    with _state_lock:
        _state[title] = {
            "status": status,
            "retries": int(retries),
            "last_scan": int(time.time()),
            "next_scan": int(next_scan),
            "vote_average": float(vote_average),
            "parental_rating": str(parental_rating) if parental_rating else "",
            "genres": str(genres) if genres else "",
            "year": str(year) if year else "",
            "overview": str(overview) if overview else "",
            "director": str(director) if director else "",
            "cast": str(cast) if cast else "",
            "country": str(country) if country else "",
            "title": str(item_title) if item_title else "",
        }
        _dirty[0] += 1
        if _dirty[0] >= FLUSH_EVERY:
            _flush_ev.set()

def _write_state():
    with _write_lock:
        try:
            with _state_lock:
                snapshot = dict(_state)
            if not snapshot:
                return
            scan_file = SCAN_STATE_FILE()
            tmp = scan_file + ".tmp"
            with open(tmp, "w") as f:
                f.write('{"_version":"%s","_updated":"%s","entries":{' % (
                    STATE_VERSION, time.strftime("%Y-%m-%d %H:%M:%S")))
                items = list(snapshot.items())
                for idx, (key, value) in enumerate(items):
                    f.write('"%s":%s' % (
                        key.replace('"', '\\"'),
                        json.dumps(value, separators=(",", ":"))))
                    if idx < len(items) - 1:
                        f.write(",")
                f.write("}}")
                f.flush()
            os.replace(tmp, scan_file)
            with _state_lock:
                _dirty[0] = 0
        except Exception as e:
            log("State write error: %s" % e, "WARN")

def _load_state():
    global _state
    scan_file = SCAN_STATE_FILE()
    try:
        if not os.path.exists(scan_file) or os.path.getsize(scan_file) == 0:
            return
        with open(scan_file, "r") as f:
            raw = json.load(f)
        if isinstance(raw, dict):
            _state = raw.get("entries", raw)
        else:
            _state = {}
        _last_cleanup[0] = time.time()
    except Exception as e:
        log("State load error: %s" % e, "WARN")
        _state = {}

def state_is_ok(title):
    with _state_lock:
        st = _state.get(title)
        return st is not None and st.get("status") == "ok"

def _mark_found(title, vote_average=0, parental_rating="", genres="", year="",
                overview="", director="", cast="", country="", item_title=""):
    parental_rating = _normalize_parental(parental_rating)
    _set_state(title, "ok", 0, 0, vote_average, parental_rating, genres,
               year, overview, director, cast, country, item_title)
    _neg_cache.pop(title, None)

    try:
        notify_metadata_callbacks(title)
    except Exception as e:
        log("Metadata callback error: %s" % str(e), "WARN")

    poster_path = os.path.join(get_poster_folder(), title + ".jpg")
    if os.path.exists(poster_path):
        _notify_poster_success(title, poster_path)

    with _state_lock:
        dirty = _dirty[0]
    if dirty >= FLUSH_EVERY:
        _write_state()

def _mark_not_found(title):
    with _state_lock:
        retries = int(_state.get(title, {}).get("retries", 0)) + 1
    if retries >= MAX_RETRIES:
        with _state_lock:
            _state.pop(title, None)
            _dirty[0] += 1
        _neg_cache[title] = time.time()
    else:
        _set_state(title, "failed", retries, int(time.time()) + RETRY_DELAY_S)


def _should_download(title, dest):
    if os.path.exists(dest):
        with _state_lock:
            st = _state.get(title)
        if st and st.get('status') == 'ok' and _has_useful_data(st):
            return False
        return True

    if title in _neg_cache:
        if time.time() - _neg_cache[title] < _neg_expiry:
            return False
        del _neg_cache[title]
    with _state_lock:
        st = _state.get(title)
    if st is None:
        return True
    status  = st.get("status", "pending")
    retries = int(st.get("retries", 0))
    next_sc = int(st.get("next_scan", 0))
    if status == "ok":
        return False
    if status == "failed":
        return retries < MAX_RETRIES and time.time() >= next_sc
    return True

def _clean_old_entries():
    now = time.time()
    to_del = []
    with _state_lock:
        for title, entry in _state.items():
            ls  = entry.get("last_scan", 0)
            st  = entry.get("status", "")
            ret = entry.get("retries", 0)
            if st == "failed" and ret >= MAX_RETRIES and now - ls > CLEANUP_DAYS_FAILED * 86400:
                to_del.append(title)
            elif st == "ok" and not _has_useful_data(entry) and now - ls > CLEANUP_DAYS_EMPTY * 86400:
                to_del.append(title)
            elif st == "ok" and _has_useful_data(entry) and now - ls > CLEANUP_DAYS_SUCCESS * 86400:
                to_del.append(title)
        for t in to_del:
            del _state[t]
            _dirty[0] += 1
    if to_del:
        _write_state()
    cutoff = now - _neg_expiry
    for t in [k for k, v in list(_neg_cache.items()) if v < cutoff]:
        _neg_cache.pop(t, None)

# ============================================================================
# USER-AGENT
# ============================================================================

_UA = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Firefox/115.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/114.0",
]

def _ua():
    return random.choice(_UA)

# ============================================================================
# TMDB FUNCTIONS
# ============================================================================

def _fetch_parental_rating(media_id, media_type):
    if not REQUESTS_OK or not network_available():
        return ""
    try:
        if media_type == "movie":
            url = "https://api.themoviedb.org/3/movie/%s/release_dates?api_key=%s" % (
                media_id, get_cfg("TMDB_API_KEY"))
        else:
            url = "https://api.themoviedb.org/3/tv/%s/content_ratings?api_key=%s" % (
                media_id, get_cfg("TMDB_API_KEY"))
        resp = http_session.get(url, headers={"User-Agent": _ua()},
                                timeout=(T_CONN, T_READ), verify=False)
        if not resp.ok:
            return ""
        data     = resp.json()
        priority = ["US", "GB", "DE", "FR", "IT", "ES"]
        if media_type == "movie":
            for iso in priority:
                for country in data.get("results", []):
                    if country.get("iso_3166_1") == iso:
                        for rd in country.get("release_dates", []):
                            cert = rd.get("certification", "")
                            if cert:
                                return cert
        else:
            for iso in priority:
                for country in data.get("results", []):
                    if country.get("iso_3166_1") == iso:
                        cert = country.get("rating", "")
                        if cert:
                            return cert
        return ""
    except Exception:
        return ""

def _fetch_logo_url(media_id, media_type):
    if not REQUESTS_OK or not media_id or not network_available():
        return ""
    try:
        url = ("https://api.themoviedb.org/3/%s/%s/images"
               "?api_key=%s&include_image_language=en,null" % (
                   media_type, media_id, get_cfg("TMDB_API_KEY")))
        resp = http_session.get(url, headers={"User-Agent": _ua()},
                                timeout=(T_CONN, T_READ), verify=False)
        if not resp.ok:
            return ""
        logos = resp.json().get("logos", [])
        if not logos:
            return ""
        logos_sorted = sorted(
            logos,
            key=lambda x: (0 if x.get("iso_639_1") == "en" else 1,
                           -x.get("vote_count", 0)))
        logo_size = get_cfg("LOGO_SIZE") or "w300"
        for logo in logos_sorted:
            fp = logo.get("file_path", "")
            if fp and fp.endswith(".png"):
                return f"https://image.tmdb.org/t/p/{logo_size}{fp}"
        return ""
    except Exception:
        return ""

def _tmdb_search(title):
    if not REQUESTS_OK or not title or not network_available():
        return _NET13

    queries = [title]

    for query in queries:
        try:
            resp = http_session.get(
                TMDB_SEARCH_MULTI,
                params={
                    "api_key":       get_cfg("TMDB_API_KEY"),
                    "language":      get_cfg("TMDB_LANGUAGE"),
                    "include_adult": "false",
                    "query":         query,
                },
                headers={"User-Agent": _ua()},
                timeout=(T_CONN, T_READ),
                verify=False,
            )
            if not resp.ok:
                if _is_net_status(resp.status_code):
                    mark_network_error("search failed: %s" % query)
                    return _NET13
                continue

            mark_network_ok()
            data = resp.json()
            results = data.get("results", [])
            if not results:
                continue

            exact_match = None
            for item in results:
                item_title = (item.get("title") or item.get("name") or "").strip()
                if item_title.lower() == query.lower():
                    exact_match = item
                    break

            if exact_match:
                items_to_process = [exact_match]
            else:
                items_to_process = results[:5]

            for item in items_to_process:
                media_type = item.get("media_type")
                if media_type not in ("movie", "tv"):
                    continue
                poster_path = item.get("poster_path")
                if not poster_path:
                    continue

                media_id        = item.get("id")
                vote_average    = item.get("vote_average", 0)
                parental_rating = _fetch_parental_rating(media_id, media_type)

                genres = ", ".join(GENRES_MAP[g] for g in item.get("genre_ids", []) if g in GENRES_MAP)
                year   = (item.get("release_date") or item.get("first_air_date") or "")[:4]
                overview     = item.get("overview", "")
                backdrop_path = item.get("backdrop_path", "")

                detail_url = (
                    "https://api.themoviedb.org/3/%s/%s"
                    "?api_key=%s&language=%s&append_to_response=credits"
                ) % (media_type, media_id, get_cfg("TMDB_API_KEY"), get_cfg("TMDB_LANGUAGE"))
                detail_resp = http_session.get(detail_url, headers={"User-Agent": _ua()},
                                               timeout=(T_CONN, T_READ), verify=False)
                director = cast_str = country = ""
                if detail_resp.ok:
                    detail = detail_resp.json()
                    credits = detail.get("credits", {})
                    for crew in credits.get("crew", []):
                        if crew.get("job") == "Director":
                            director = crew.get("name", "")
                            break
                    cast_str = ", ".join(m.get("name", "") for m in credits.get("cast", [])[:10])
                    prod = detail.get("production_countries", [])
                    if prod:
                        country = ", ".join(c.get("name", "") for c in prod[:2])

                item_title   = item.get("title") or item.get("name") or ""
                backdrop_url = (TMDB_IMG_W185 + backdrop_path) if backdrop_path else ""
                logo_url     = _fetch_logo_url(media_id, media_type)

                return (STATUS_FOUND, TMDB_IMG_W185 + poster_path, vote_average,
                        parental_rating, genres, year, overview, director, cast_str,
                        country, item_title, backdrop_url, logo_url)

            return _EMPTY13

        except Exception as e:
            if _is_net_exc(e):
                mark_network_error(str(e))
                return _NET13

    return _EMPTY13

def _imdb_search(title):
    if not REQUESTS_OK or not title or not network_available():
        return STATUS_NETWORK, None, 0
    try:
        letter = title[0].lower() if title[0].isalpha() else "a"
        url = IMDB_SUGGEST.format(letter=letter, query=title.replace(" ", "%20"))
        resp = http_session.get(url, headers={"User-Agent": _ua(), "Accept": "application/json"},
                                timeout=(T_CONN, T_READ))
        if not resp.ok:
            if _is_net_status(resp.status_code):
                mark_network_error("imdb: %s" % title)
                return STATUS_NETWORK, None, 0
            return STATUS_NOT_FOUND, None, 0
        mark_network_ok()
        for item in resp.json().get("d", []):
            img = item.get("i")
            url_img = None
            if isinstance(img, dict):
                url_img = img.get("imageUrl", "")
            elif isinstance(img, (list, tuple)) and img:
                url_img = img[0]
            if url_img and url_img.startswith("http"):
                return STATUS_FOUND, url_img, 0
        return STATUS_NOT_FOUND, None, 0
    except Exception as e:
        if _is_net_exc(e):
            mark_network_error(str(e))
            return STATUS_NETWORK, None, 0
        return STATUS_NOT_FOUND, None, 0

def _unique_items(items):
    out, seen = [], set()
    for item in (items or []):
        try:
            v = str(item).strip()
        except Exception:
            continue
        k = v.lower()
        if k and k not in seen:
            seen.add(k)
            out.append(v)
    return out

def _find_url(title, source, candidates=None):
    cached = get_cached_search(title)
    if cached is not None:
        if cached.get("status") == STATUS_FOUND:
            return (STATUS_FOUND,
                    cached.get("url", ""),
                    cached.get("vote_average", 0),
                    cached.get("parental_rating", ""),
                    cached.get("genres", ""),
                    cached.get("year", ""),
                    cached.get("overview", ""),
                    cached.get("director", ""),
                    cached.get("cast", ""),
                    cached.get("country", ""),
                    cached.get("item_title", ""),
                    cached.get("provider", "TMDB"),
                    cached.get("logo_url", ""))
        return _EMPTY13

    tries = _unique_items(candidates or [title])
    tries = tries[:4] if source == "live" else tries[:2]
    if not tries:
        tries = [title]

    for candidate in tries:
        result = _tmdb_search(candidate)
        status = result[0]
        if status == STATUS_FOUND:
            (_, url, vote_avg, parental, genres, year, overview,
             director, cast, country, item_title, backdrop_url, logo_url) = result
            cache_entry = {
                "status": STATUS_FOUND, "url": url, "vote_average": vote_avg,
                "parental_rating": parental, "genres": genres, "year": year,
                "overview": overview, "director": director, "cast": cast,
                "country": country, "item_title": item_title,
                "provider": "TMDB", "backdrop_url": backdrop_url,
                "logo_url": logo_url,
            }
            set_cached_search(title, cache_entry)
            return (STATUS_FOUND, url, vote_avg, parental, genres, year, overview,
                    director, cast, country, item_title, "TMDB", logo_url)
        if status == STATUS_NETWORK:
            return _NET13

    if source == "live":
        st, url_img, va = _imdb_search(tries[0])
        if st == STATUS_FOUND:
            set_cached_search(title, {"status": STATUS_FOUND, "url": url_img,
                                      "vote_average": va, "provider": "IMDB"})
            return (STATUS_FOUND, url_img, va, "", "", "", "", "", "", "", "", "IMDB", "")
        if st == STATUS_NETWORK:
            return _NET13

    m = re.search(r"^(.*?)\s+(\d+)$", tries[0])
    if m:
        try:
            num = int(m.group(2))
        except Exception:
            num = 0
        base = m.group(1).strip()
        if num > 10 and len(base) >= 3:
            result = _tmdb_search(base)
            if result[0] == STATUS_FOUND:
                (_, url, va, parental, genres, year, overview,
                 director, cast, country, item_title, backdrop_url, logo_url) = result
                cache_entry = {
                    "status": STATUS_FOUND, "url": url, "vote_average": va,
                    "parental_rating": parental, "genres": genres, "year": year,
                    "overview": overview, "director": director, "cast": cast,
                    "country": country, "item_title": item_title,
                    "provider": "TMDB", "backdrop_url": backdrop_url, "logo_url": logo_url,
                }
                set_cached_search(title, cache_entry)
                return (STATUS_FOUND, url, va, parental, genres, year, overview,
                        director, cast, country, item_title, "TMDB", logo_url)
            if result[0] == STATUS_NETWORK:
                return _NET13

    set_cached_search(title, {"status": STATUS_NOT_FOUND})
    return _EMPTY13

# ============================================================================
# FILE SAVE
# ============================================================================

def _save_jpg(url, dest):
    if not REQUESTS_OK or not network_available():
        return STATUS_NETWORK
    tmp = dest + ".part"
    try:
        resp = http_session.get(url, headers={"User-Agent": _ua()},
                                timeout=(T_CONN, T_IMG), verify=False, stream=False)
        if not resp.ok:
            if _is_net_status(resp.status_code):
                mark_network_error("jpg download failed")
                return STATUS_NETWORK
            return STATUS_SAVE_FAIL
        mark_network_ok()
        data = resp.content
        if not data or len(data) < MIN_BYTES:
            return STATUS_SAVE_FAIL
        with open(tmp, "wb") as f:
            f.write(data)
        if Image is not None:
            try:
                img = Image.open(tmp)
                img.verify()
                img.close()
            except Exception:
                return STATUS_SAVE_FAIL
        os.replace(tmp, dest)
        return STATUS_FOUND if os.path.exists(dest) else STATUS_SAVE_FAIL
    except Exception as e:
        if _is_net_exc(e):
            mark_network_error(str(e))
            return STATUS_NETWORK
        return STATUS_SAVE_FAIL
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass

def _save_png(url, dest):
    if not REQUESTS_OK or not url or not network_available():
        return False
    tmp = dest + ".part"
    try:
        resp = http_session.get(url, headers={"User-Agent": _ua()},
                                timeout=(T_CONN, T_IMG), verify=False)
        if not resp.ok:
            return False
        mark_network_ok()
        data = resp.content
        if not data or len(data) < 512:
            return False
        with open(tmp, "wb") as f:
            f.write(data)
        if Image is not None:
            try:
                img = Image.open(tmp)
                img.verify()
                img.close()
            except Exception:
                return False
        os.replace(tmp, dest)
        return os.path.exists(dest)
    except Exception:
        return False
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass

# ============================================================================
# PROCESSING
# ============================================================================

def _release(title):
    with _pending_lock:
        _pending.pop(title, None)

def _process(item, source):
    if len(item) >= 4:
        clean_title, raw, ch, candidates = item
    else:
        clean_title, raw, ch = item[:3]
        candidates = [clean_title]

    pfolder = get_poster_folder()
    lfolder = get_logo_folder()
    dest    = os.path.join(pfolder, clean_title + ".jpg")
    dest_exists = os.path.exists(dest)

    trace("Worker", "process-start", "title=%s" % clean_title)

    try:
        if dest_exists:
            with _state_lock:
                st = _state.get(clean_title)
            if st and st.get('status') == 'ok' and _has_useful_data(st):
                _notify_poster_success(clean_title, dest)
                return
        else:
            if not _should_download(clean_title, dest):
                return

        if not network_available():
            log_event(source, ch, raw, clean_title, "SKIP", "-", "network cooldown")
            return

        with timed_block("Worker", "find-url", "title=%s" % clean_title):
            (status, url, vote_avg, parental, genres, year, overview,
             director, cast, country, item_title, provider, logo_url) = _find_url(
                clean_title, source, candidates)

        if status == STATUS_NETWORK:
            mark_network_error("search failed: %s" % clean_title)
            log_event(source, ch, raw, clean_title, "NETWORK", provider, "search error")
            return

        if status == STATUS_FOUND and url:
            save_st = STATUS_FOUND
            if not dest_exists:
                with timed_block("Worker", "save-poster", "title=%s" % clean_title):
                    save_st = _save_jpg(url, dest)
            else:
                pass

            if save_st == STATUS_FOUND:
                # Cache the backdrop URL for the backdrop downloader
                cached = get_cached_search(clean_title)
                if cached:
                    backdrop_url = cached.get("backdrop_url")
                    if backdrop_url:
                        set_backdrop_url(clean_title, backdrop_url)

                _mark_found(clean_title, vote_avg, parental, genres, year,
                            overview, director, cast, country, item_title)
                log_event(source, ch, raw, clean_title, "FOUND", provider,
                          "rating=%.1f parental=%s" % (vote_avg, parental))

                if logo_url and get_cfg("LOGOX_ENABLED"):
                    logo_dest = os.path.join(lfolder, clean_title + ".png")
                    if not os.path.exists(logo_dest):
                        if _save_png(logo_url, logo_dest):
                            _notify_logo_success(clean_title, logo_dest)
            elif save_st == STATUS_NETWORK:
                mark_network_error("download failed: %s" % clean_title)
                log_event(source, ch, raw, clean_title, "NETWORK", provider, "download error")
                _mark_not_found(clean_title)
            else:
                log_event(source, ch, raw, clean_title, "SAVE_FAIL", provider, "save error")
                _mark_not_found(clean_title)
        else:
            _mark_not_found(clean_title)
            log_event(source, ch, raw, clean_title, "NOT_FOUND", "-", "not found")

    except Exception as e:
        log("Process error: %s" % e, "ERROR")
    finally:
        _release(clean_title)

# ============================================================================
# WORKER
# ============================================================================

def _worker(worker_id):
    while True:
        try:
            item = work_queue.get(timeout=1.0)
            if item is None:
                continue
            _process(item, "live")
        except _queue.Empty:
            continue
        except Exception as e:
            log("Worker %d error: %s" % (worker_id, e), "WARN")

# ============================================================================
# QUEUE_LIVE
# ============================================================================

def queue_live(clean_title, raw_name=None, candidates=None):
    """Queue a title for download. raw_name is the original EPG title."""
    if not clean_title:
        return False
    if not get_cfg("POSTERX_ENABLED"):
        return False
    pfolder = get_poster_folder()
    dest    = os.path.join(pfolder, clean_title + ".jpg")
    if file_exists_cached(dest):          # <-- uses imported function
        return False
    with _pending_lock:
        if clean_title in _pending:
            return False
        _pending[clean_title] = time.time()
    raw   = raw_name or clean_title
    tries = _unique_items(candidates or [clean_title]) or [clean_title]
    try:
        work_queue.put_nowait((clean_title, raw, "-", tries))
        return True
    except _queue.Full:
        _release(clean_title)
        log("Queue full, dropping: %s" % clean_title, "WARN")
        return False

# ============================================================================
# FLUSH + INIT
# ============================================================================

def _flush_loop():
    while True:
        _flush_ev.wait(timeout=60)
        _flush_ev.clear()
        with _state_lock:
            dirty = _dirty[0]
        if dirty > 0:
            _write_state()
        if time.time() - _last_cleanup[0] > CLEANUP_INTERVAL_S:
            _clean_old_entries()
            _last_cleanup[0] = time.time()

def _async_initialize():
    _load_state()
    try:
        n = int(get_cfg("WORKER_THREADS") or 6)
    except Exception:
        n = 6
    for i in range(n):
        t = threading.Thread(target=_worker, args=(i,))
        t.daemon = True
        t.start()
    t = threading.Thread(target=_flush_loop)
    t.daemon = True
    t.start()
    log("PosterX initialized: %d workers" % n, "INFO")

set_batch_poster_queue_fn(queue_live)
set_batch_logo_queue_fn(queue_live)
set_state_overlay_fn(_get_state_snapshot)

threading.Thread(target=_async_initialize, daemon=True).start()