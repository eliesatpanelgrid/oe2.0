#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                          iPosterXDownloadThread.py                           ║
║                         XDREAMY SKIN V6.8.0 - 2026-06-17                     ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  FIX: workers used to call get_zap_context() (EPG + GUI-side lock) after    ║
║  every successful download. That raced the GUI thread on _zap_ctx_lock     ║
║  and on eEPGCache itself, and got worse the more zaps/downloads piled up — ║
║  this was the "fine for 5 zaps then jams" bug. Workers now ONLY invalidate ║
║  the context; the next renderer changed() call rebuilds it lazily on the   ║
║  GUI thread, where it belongs. Networking timeouts/retry knobs untouched.  ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from __future__ import absolute_import

import json
import os
import random
import re
import threading
import time
import queue as _queue

try:
    from PIL import Image
except Exception:
    Image = None

try:
    import requests
    http_session = requests.Session()
    try:
        adapter = requests.adapters.HTTPAdapter(pool_connections=4, pool_maxsize=4)
        http_session.mount("http://", adapter)
        http_session.mount("https://", adapter)
    except Exception:
        pass
    REQUESTS_OK = True
except Exception:
    requests = None
    http_session = None
    REQUESTS_OK = False

# ============================================================================
# STORAGE PATHS
# ============================================================================

from .iConverlibr import (
    SCAN_STATE_FILE, POSTER_FOLDER,
    notify_metadata_callbacks,
    invalidate_zap_context,
    queue_gui_callback,
    set_batch_poster_queue_fn,
    set_state_overlay_fn,
    get_cached_search,
    set_cached_search,
)
from .iDebugTrace import trace, timed_block  # DEBUG TRACE - remove this line + trace/timed_block calls when done diagnosing

path_folder = POSTER_FOLDER

# ============================================================================
# API CONFIGURATION  (unchanged — do not touch, keeps download speed as-is)
# ============================================================================

TMDB_API_KEY = "3c3efcf47c3577558812bb9d64019d65"
TMDB_SEARCH_MULTI = "https://api.themoviedb.org/3/search/multi"
TMDB_IMG_BASE = "https://image.tmdb.org/t/p/w185"
IMDB_SUGGEST = "https://v2.sg.media-imdb.com/suggestion/{letter}/{query}.json"

T_CONN = 1.5
T_READ = 3
T_IMG = 6
MIN_BYTES = 4096

MAX_RETRIES = 2
RETRY_DELAY_S = 7200
FLUSH_EVERY = 50
STATE_VERSION = "7"
NETWORK_COOLDOWN_SECONDS = 10

CLEANUP_DAYS_FAILED = 7
CLEANUP_DAYS_EMPTY = 2
CLEANUP_DAYS_SUCCESS = 180
CLEANUP_INTERVAL_S = 6 * 3600  # periodic sweep so _state/_negative_cache never grow unbounded

STATUS_FOUND = "found"
STATUS_NOT_FOUND = "not_found"
STATUS_NETWORK = "network"
STATUS_SAVE_FAIL = "save_fail"

GENRES_MAP = {
    28: "Action", 12: "Adventure", 16: "Animation", 35: "Comedy",
    80: "Crime", 99: "Documentary", 18: "Drama", 10751: "Family",
    14: "Fantasy", 36: "History", 27: "Horror", 10402: "Music",
    9648: "Mystery", 10749: "Romance", 878: "Sci-Fi", 10770: "TV Movie",
    53: "Thriller", 10752: "War", 37: "Western", 10759: "Action & Adventure",
    10762: "Kids", 10763: "News", 10764: "Reality", 10765: "Sci-Fi & Fantasy",
    10766: "Soap", 10767: "Talk", 10768: "War & Politics"
}

# ============================================================================
# WORK QUEUE
# ============================================================================

work_queue = _queue.Queue(maxsize=200)
_pending = {}
_pending_lock = threading.Lock()
_pending_expiry = 60

# ============================================================================
# CALLBACK REGISTRATION (for posters)
# ============================================================================

_pending_callbacks = {}
_callback_lock = threading.Lock()

def register_renderer_callback(clean_title, renderer_obj):
    if not clean_title or renderer_obj is None:
        return
    with _callback_lock:
        bucket = _pending_callbacks.setdefault(clean_title, [])
        if renderer_obj not in bucket:
            bucket.append(renderer_obj)

def unregister_renderer(clean_title, renderer_obj):
    with _callback_lock:
        bucket = _pending_callbacks.get(clean_title)
        if not bucket:
            return
        try:
            bucket.remove(renderer_obj)
        except ValueError:
            return
        if not bucket:
            del _pending_callbacks[clean_title]

def _notify_download_success(clean_title, saved_path):
    """Called from a worker thread. Does NOT touch any renderer directly —
    renderer.poster_download_completed() ends up calling self.instance /
    self._show_file(), which are GUI widget operations and must run on the
    GUI thread. queue_gui_callback() marshals the actual call there."""
    if not clean_title or not saved_path or not os.path.exists(saved_path):
        return
    with _callback_lock:
        renderers = _pending_callbacks.pop(clean_title, None)
    if not renderers:
        return
    for renderer in renderers:
        queue_gui_callback(renderer.poster_download_completed, clean_title, saved_path)

# ============================================================================
# LOGGING
# ============================================================================

LOG_FILE = "/tmp/iPosterX.log"
LOG_MAX_BYTES = 1024 * 1024
_log_lock = threading.Lock()

def log_event(source, channel, raw_title, clean_title, status, provider, msg):
    try:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        line = "[%s] | [%s] | %s | %s | %s | %s | %s | %s\n" % (
            timestamp, str(source).upper(), str(channel or "-"),
            str(raw_title or "-"), str(clean_title or "-"),
            str(status).upper(), str(provider or "-"), str(msg or ""))
        with _log_lock:
            try:
                if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX_BYTES:
                    with open(LOG_FILE, "rb") as f:
                        f.seek(-(LOG_MAX_BYTES // 2), os.SEEK_END)
                        tail = f.read()
                    with open(LOG_FILE, "wb") as f:
                        f.write(tail)
            except Exception:
                pass
            with open(LOG_FILE, "a") as f:
                f.write(line)
    except Exception:
        pass

def log(msg, level="INFO"):
    log_event("SYSTEM", "-", "-", "-", level, "-", msg)

# ============================================================================
# NETWORK STATUS
# ============================================================================

_network_lock = threading.Lock()
_network_down_until = [0]

def _now():
    return int(time.time())

def network_available():
    with _network_lock:
        return _now() >= int(_network_down_until[0])

def mark_network_error(reason=None):
    with _network_lock:
        _network_down_until[0] = _now() + NETWORK_COOLDOWN_SECONDS
    if reason:
        log_event("NETWORK", "-", "-", "-", "COOLDOWN", "-", reason)

def mark_network_ok():
    with _network_lock:
        _network_down_until[0] = 0

def _is_network_exception(err):
    if requests is None:
        return True
    try:
        return isinstance(err, (requests.exceptions.Timeout,
                                requests.exceptions.ConnectionError,
                                requests.exceptions.RequestException))
    except Exception:
        return True

def _is_network_status(code):
    try:
        code = int(code)
    except Exception:
        return False
    return code == 408 or code == 429 or code >= 500

# ============================================================================
# STATE PERSISTENCE (Thread-Safe)
# ============================================================================

_state = {}
_state_lock = threading.Lock()
_write_lock = threading.Lock()
_dirty = [0]
_flush_ev = threading.Event()
_last_cleanup = [0]


def _get_state_snapshot():
    """Returns a shallow copy of _state for ZapContext's JSON overlay (see
    iConverlibr.py's set_state_overlay_fn). Called from the GUI thread via
    _load_json_once(); the lock here is only ever held briefly for a dict
    copy, never for I/O, so this can't reintroduce the lock-contention
    problem fixed in an earlier round."""
    with _state_lock:
        return dict(_state)

def _normalize_parental_rating(rating):
    if not rating:
        return ""
    rating = rating.upper().strip()
    mapping = {
        'T': 'TV-14', 'VM14': 'TV-14', 'VM18': 'TV-MA',
        '14+': 'TV-14', '16+': 'TV-MA', '18+': 'R',
        'M': 'PG-13', 'MA15+': 'TV-MA',
    }
    if rating in mapping:
        return mapping[rating]
    valid = ['R', 'PG-13', 'PG', 'G', 'TV-MA', 'TV-14', 'TV-PG', 'TV-Y7', 'TV-Y']
    if rating in valid:
        return rating
    return ""

def _has_useful_data(entry):
    return any([
        entry.get('vote_average', 0) > 0,
        entry.get('parental_rating', ''),
        entry.get('genres', ''),
        entry.get('year', ''),
        entry.get('director', ''),
        entry.get('cast', ''),
        entry.get('country', ''),
        len(entry.get('overview', '')) > 50
    ])

def _clean_old_entries():
    """Sweep _state for stale entries. Runs at startup and periodically
    from the flush loop (see CLEANUP_INTERVAL_S) so long-uptime boxes don't
    grow scan_state.json (and therefore every disk read/write of it)
    without bound."""
    now = time.time()
    to_delete = []
    with _state_lock:
        for title, entry in _state.items():
            last_scan = entry.get("last_scan", 0)
            status = entry.get("status", "")
            retries = entry.get("retries", 0)

            if status == "failed" and retries >= MAX_RETRIES:
                if now - last_scan > CLEANUP_DAYS_FAILED * 24 * 3600:
                    to_delete.append(title)
            elif status == "ok" and not _has_useful_data(entry):
                if now - last_scan > CLEANUP_DAYS_EMPTY * 24 * 3600:
                    to_delete.append(title)
            elif status == "ok" and _has_useful_data(entry):
                if now - last_scan > CLEANUP_DAYS_SUCCESS * 24 * 3600:
                    to_delete.append(title)

        for title in to_delete:
            del _state[title]
            _dirty[0] += 1

    if to_delete:
        _write_state()

    # Also sweep the in-memory negative cache here, piggybacking on the
    # same periodic pass instead of a separate timer/thread.
    cutoff = now - _negative_cache_expiry
    stale_neg = [t for t, ts in _negative_cache.items() if ts < cutoff]
    for t in stale_neg:
        _negative_cache.pop(t, None)

def _set_state(title, status, retries=0, next_scan=0, vote_average=0,
               parental_rating="", genres="", year="", overview="",
               director="", cast="", country="", item_title=""):
    with _state_lock:
        _state[title] = {
            "status": status,
            "retries": int(retries),
            "last_scan": int(time.time()),
            "next_scan": int(next_scan),
            "vote_average": float(vote_average),
            "parental_rating": str(parental_rating) if parental_rating else "",
            "genres": str(genres) if genres else "",
            "year": str(year) if year else "",
            "overview": str(overview) if overview else "",
            "director": str(director) if director else "",
            "cast": str(cast) if cast else "",
            "country": str(country) if country else "",
            "title": str(item_title) if item_title else "",
        }
        _dirty[0] += 1
        if _dirty[0] >= FLUSH_EVERY:
            _flush_ev.set()

def _write_state():
    _t_lockwait_start = time.time()  # DEBUG TRACE
    with _write_lock:
        _lockwait_ms = int((time.time() - _t_lockwait_start) * 1000)  # DEBUG TRACE
        try:
            with _state_lock:
                snapshot = dict(_state)

            if not snapshot:
                return

            tmp = SCAN_STATE_FILE + ".tmp"
            _t_write_start = time.time()  # DEBUG TRACE
            with open(tmp, "w") as f:
                f.write('{"_version":"%s","_updated":"%s","entries":{' % (
                    STATE_VERSION, time.strftime("%Y-%m-%d %H:%M:%S")))
                count = len(snapshot)
                for idx, (key, value) in enumerate(snapshot.items()):
                    escaped_key = key.replace('"', '\\"')
                    entry_json = json.dumps(value, separators=(',', ':'))
                    f.write('"%s":%s' % (escaped_key, entry_json))
                    if idx < count - 1:
                        f.write(',')
                f.write('}}')
                f.flush()
                _write_done_ms = int((time.time() - _t_write_start) * 1000)  # DEBUG TRACE
                _t_fsync_start = time.time()  # DEBUG TRACE
                os.fsync(f.fileno())
                _fsync_ms = int((time.time() - _t_fsync_start) * 1000)  # DEBUG TRACE

            os.replace(tmp, SCAN_STATE_FILE)
            with _state_lock:
                _dirty[0] = 0

            log("State saved to %s (%d entries)" % (SCAN_STATE_FILE, len(snapshot)), "INFO")
            # This is the single most useful line for diagnosing "slow flash
            # storage" theories: if fsync_ms grows with entry count or is
            # consistently large, the periodic flush (every FLUSH_EVERY
            # dirty writes, or every successful download once FLUSH_EVERY
            # is hit) is genuinely slow at the OS/storage level, which
            # would explain a recurring "saturate, pause while it catches
            # up, recover" cycle independent of anything in Python.
            trace("WriteState", "done", "entries=%d lockwait=%dms write=%dms fsync=%dms" % (  # DEBUG TRACE
                len(snapshot), _lockwait_ms, _write_done_ms, _fsync_ms))
        except Exception as e:
            log("State write error: %s" % e, "WARN")
            trace("WriteState", "EXCEPTION", str(e))  # DEBUG TRACE
            try:
                if os.path.exists(SCAN_STATE_FILE + ".tmp"):
                    os.remove(SCAN_STATE_FILE + ".tmp")
            except Exception:
                pass

def _load_state():
    global _state
    try:
        if not os.path.exists(SCAN_STATE_FILE):
            log("No state file found, starting fresh", "INFO")
            return
        if os.path.getsize(SCAN_STATE_FILE) == 0:
            log("State file empty, skipping load", "WARN")
            return
        with open(SCAN_STATE_FILE, "r") as f:
            raw = json.load(f)
        if isinstance(raw, dict):
            if "entries" in raw:
                _state = raw.get("entries", {})
                log("Loaded %d entries from version %s" % (len(_state), raw.get("_version", "unknown")), "INFO")
            else:
                _state = raw
                log("Loaded %d entries from legacy format" % len(_state), "INFO")
        else:
            _state = {}
        _clean_old_entries()
        _last_cleanup[0] = time.time()
    except Exception as e:
        log("State load error: %s" % e, "WARN")
        _state = {}

def state_is_ok(title):
    with _state_lock:
        st = _state.get(title)
        return st is not None and st.get("status") == "ok"

def _mark_found(title, vote_average=0, parental_rating="", genres="", year="",
                overview="", director="", cast="", country="", item_title=""):
    _t0 = time.time()  # DEBUG TRACE
    parental_rating = _normalize_parental_rating(parental_rating)

    has_useful = any([
        vote_average > 0,
        parental_rating,
        genres,
        year,
        director,
        cast,
        len(overview) > 50
    ])

    if not has_useful:
        log("Skipping save for %s - no useful data" % title, "INFO")
        trace("MarkFound", "skipped-no-useful-data", "title=%s" % title)  # DEBUG TRACE
        return

    # 1. Update IN-MEMORY state only — this is the part the GUI actually
    #    needs. _set_state() just updates the _state dict and bumps the
    #    dirty counter; it does NOT touch disk.
    _set_state(title, "ok", 0, 0, vote_average, parental_rating, genres,
               year, overview, director, cast, country, item_title)
    _negative_cache.pop(title, None)

    # 2. Invalidate ZapContext only — DO NOT rebuild it here. Rebuilding
    #    means an eEPGCache lookup, which must happen on the GUI thread.
    #    The next renderer changed() (poster/star/parental/info, whichever
    #    fires next) will call get_zap_context() itself and rebuild lazily
    #    with this fresh data already in place. This is the fix for the
    #    "5 zaps then jams" issue: workers no longer fight the GUI thread
    #    for the zap-context lock or hit the EPG cache concurrently with it.
    try:
        invalidate_zap_context()
    except Exception as e:
        log("ZapContext invalidation error: %s" % str(e), "WARN")

    # 3. Notify renderers FIRST, before touching disk. The trace log
    #    (Worker-thread, 04:09:39) showed fsync() regularly costing
    #    65-1021ms and workers queueing over 600ms behind _write_lock —
    #    all of it happening BEFORE this notification used to fire. Since
    #    the GUI only needs the in-memory _state (already updated above),
    #    there is no reason to make it wait for a disk fsync first.
    poster_path = os.path.join(path_folder, title + ".jpg")
    _notify_download_success(title, poster_path)

    try:
        notify_metadata_callbacks(title)
    except Exception as e:
        log("Metadata callback error: %s" % str(e), "WARN")

    # 4. Persist to disk LAST, and respect the existing FLUSH_EVERY
    #    batching instead of forcing a write+fsync on every single
    #    success. _set_state() already incremented _dirty[0] and will have
    #    set _flush_ev if the threshold was hit (handled by the flush loop
    #    on its own schedule, off the critical path for display). This is
    #    the single biggest latency source found in the trace log — saving
    #    metadata for one title doesn't need to immediately fsync the
    #    entire _state dict (which only grows over a session) before the
    #    next title can be shown.
    _t_before_write = time.time()  # DEBUG TRACE
    with _state_lock:
        dirty_now = _dirty[0]
    if dirty_now >= FLUSH_EVERY:
        _write_state()
    _write_took_ms = int((time.time() - _t_before_write) * 1000)  # DEBUG TRACE

    trace("MarkFound", "done", "title=%s write_state_took=%dms total_took=%dms" % (  # DEBUG TRACE
        title, _write_took_ms, int((time.time() - _t0) * 1000)))

def _mark_not_found(title):
    with _state_lock:
        old = _state.get(title, {})
        retries = int(old.get("retries", 0)) + 1
    if retries >= MAX_RETRIES:
        with _state_lock:
            if title in _state:
                del _state[title]
                _dirty[0] += 1
        _negative_cache[title] = time.time()
        log("Removed failed entry after %d retries: %s" % (MAX_RETRIES, title), "INFO")
    else:
        _set_state(title, "failed", retries, int(time.time()) + RETRY_DELAY_S)

_negative_cache = {}
_negative_cache_expiry = 12 * 3600

def _should_download(title, poster_path):
    if os.path.exists(poster_path):
        if not state_is_ok(title):
            _mark_found(title)
        return False
    if title in _negative_cache:
        if time.time() - _negative_cache[title] < _negative_cache_expiry:
            return False
        del _negative_cache[title]
    with _state_lock:
        st = _state.get(title)
    if st is None:
        return True
    status = st.get("status", "pending")
    retries = int(st.get("retries", 0))
    next_sc = int(st.get("next_scan", 0))
    if status == "ok":
        return False
    if status == "failed":
        return retries < MAX_RETRIES and time.time() >= next_sc
    return True

# ============================================================================
# USER-AGENT
# ============================================================================

_UA = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Firefox/115.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/114.0",
]

def _ua():
    return random.choice(_UA)

# ============================================================================
# TMDB FUNCTIONS  (network behavior/timeouts unchanged)
# ============================================================================

def _fetch_parental_rating(media_id, media_type):
    if not REQUESTS_OK or not network_available():
        return ""
    try:
        if media_type == "movie":
            url = "https://api.themoviedb.org/3/movie/%s/release_dates?api_key=%s" % (media_id, TMDB_API_KEY)
        else:
            url = "https://api.themoviedb.org/3/tv/%s/content_ratings?api_key=%s" % (media_id, TMDB_API_KEY)
        resp = http_session.get(url, headers={"User-Agent": _ua()}, timeout=(T_CONN, T_READ), verify=False)
        if not resp.ok:
            return ""
        data = resp.json()
        priority = ["US", "GB", "DE", "FR", "IT", "ES"]
        if media_type == "movie":
            for iso in priority:
                for country in data.get("results", []):
                    if country.get("iso_3166_1") == iso:
                        for rd in country.get("release_dates", []):
                            cert = rd.get("certification", "")
                            if cert:
                                return cert
        else:
            for iso in priority:
                for country in data.get("results", []):
                    if country.get("iso_3166_1") == iso:
                        cert = country.get("rating", "")
                        if cert:
                            return cert
        return ""
    except Exception:
        return ""

def _tmdb_search(title):
    if not REQUESTS_OK or not title or not network_available():
        return STATUS_NETWORK, None, 0, "", "", "", "", "", "", "", "", ""

    try:
        resp = http_session.get(
            TMDB_SEARCH_MULTI,
            params={"api_key": TMDB_API_KEY, "language": "en", "include_adult": "false", "query": title},
            headers={"User-Agent": _ua()},
            timeout=(T_CONN, T_READ),
            verify=False,
        )
        if not resp.ok:
            if _is_network_status(resp.status_code):
                mark_network_error("search failed: %s" % title)
                return STATUS_NETWORK, None, 0, "", "", "", "", "", "", "", "", ""
            return STATUS_NOT_FOUND, None, 0, "", "", "", "", "", "", "", "", ""

        mark_network_ok()
        results = resp.json().get("results", [])

        for item in results:
            media_type = item.get("media_type")
            if media_type not in ("movie", "tv"):
                continue

            poster_path = item.get("poster_path")
            if not poster_path:
                continue

            media_id = item.get("id")
            vote_average = item.get("vote_average", 0)
            parental_rating = _fetch_parental_rating(media_id, media_type)

            genre_names = []
            for gid in item.get("genre_ids", []):
                if gid in GENRES_MAP:
                    genre_names.append(GENRES_MAP[gid])
            genres = ", ".join(genre_names)

            year = (item.get("release_date") or item.get("first_air_date") or "")[:4]
            overview = item.get("overview", "")

            # Also capture backdrop_path from the same search result so the
            # backdrop downloader can reuse it from the shared search cache
            # without making a second TMDB API call. This is what eliminates
            # the 14/29 duplicate-job problem confirmed in the trace log.
            backdrop_path = item.get("backdrop_path", "")

            detail_url = "https://api.themoviedb.org/3/%s/%s?api_key=%s&language=en&append_to_response=credits,release_dates" % (
                media_type, media_id, TMDB_API_KEY)
            detail_resp = http_session.get(detail_url, headers={"User-Agent": _ua()}, timeout=(T_CONN, T_READ), verify=False)

            director = ""
            cast = []
            country = ""
            cast_str = ""

            if detail_resp.ok:
                detail = detail_resp.json()
                credits = detail.get("credits", {})
                for crew in credits.get("crew", []):
                    if crew.get("job") == "Director":
                        director = crew.get("name", "")
                        break
                for cast_member in credits.get("cast", [])[:3]:
                    cast.append(cast_member.get("name", ""))
                cast_str = ", ".join(cast)
                countries = detail.get("production_countries", [])
                if countries:
                    country = countries[0].get("name", "")
                    if len(countries) > 1:
                        country = ", ".join([c.get("name", "") for c in countries[:2]])

            item_title = item.get("title") or item.get("name") or ""
            backdrop_url = (TMDB_IMG_BASE + backdrop_path) if backdrop_path else ""

            return (STATUS_FOUND, TMDB_IMG_BASE + poster_path, vote_average, parental_rating,
                    genres, year, overview, director, cast_str, country, item_title,
                    backdrop_url)

        return STATUS_NOT_FOUND, None, 0, "", "", "", "", "", "", "", "", ""

    except Exception as e:
        if _is_network_exception(e):
            mark_network_error(str(e))
            return STATUS_NETWORK, None, 0, "", "", "", "", "", "", "", "", ""
        return STATUS_NOT_FOUND, None, 0, "", "", "", "", "", "", "", "", ""

def _imdb_search(title):
    if not REQUESTS_OK or not title or not network_available():
        return STATUS_NETWORK, None, 0
    try:
        letter = title[0].lower() if title[0].isalpha() else "a"
        url = IMDB_SUGGEST.format(letter=letter, query=title.replace(" ", "%20"))
        resp = http_session.get(url, headers={"User-Agent": _ua(), "Accept": "application/json"},
                                timeout=(T_CONN, T_READ))
        if not resp.ok:
            if _is_network_status(resp.status_code):
                mark_network_error("imdb search failed: %s" % title)
                return STATUS_NETWORK, None, 0
            return STATUS_NOT_FOUND, None, 0
        mark_network_ok()
        for item in resp.json().get("d", []):
            img = item.get("i")
            url = None
            if isinstance(img, dict):
                url = img.get("imageUrl", "")
            elif isinstance(img, (list, tuple)) and img:
                url = img[0]
            if url and url.startswith("http"):
                return STATUS_FOUND, url, 0
        return STATUS_NOT_FOUND, None, 0
    except Exception as e:
        if _is_network_exception(e):
            mark_network_error(str(e))
            return STATUS_NETWORK, None, 0
        return STATUS_NOT_FOUND, None, 0

def _unique_items(items):
    out, seen = [], set()
    for item in (items or []):
        if not item:
            continue
        try:
            value = item.strip()
        except Exception:
            value = str(item).strip()
        key = value.lower()
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(value)
    return out

def _find_url(title, source, candidates=None):
    # Check shared cache first — backdrop worker may have already searched
    # this same title (or vice versa). The trace log showed 14/29 jobs
    # being processed concurrently by poster + backdrop threads, each
    # making full TMDB API calls for the same movie.
    cached = get_cached_search(title)
    if cached is not None:
        trace("Worker", "search-cache-hit", "title=%s" % title)  # DEBUG TRACE
        if cached.get('status') == STATUS_FOUND:
            return (STATUS_FOUND, cached.get('url'), cached.get('vote_average', 0),
                    cached.get('parental_rating', ''), cached.get('genres', ''),
                    cached.get('year', ''), cached.get('overview', ''),
                    cached.get('director', ''), cached.get('cast', ''),
                    cached.get('country', ''), cached.get('item_title', ''),
                    cached.get('provider', 'TMDB'))
        return (STATUS_NOT_FOUND, None, 0, "", "", "", "", "", "", "", "", "-")

    provider = "TMDB"
    tries = _unique_items(candidates or [title])
    tries = tries[:4] if source == "live" else tries[:2]
    if not tries:
        tries = [title]

    for candidate in tries:
        (status, url, vote_average, parental_rating, genres, year, overview,
         director, cast, country, item_title, backdrop_url) = _tmdb_search(candidate)
        if status == STATUS_FOUND:
            result = {'status': STATUS_FOUND, 'url': url, 'vote_average': vote_average,
                      'parental_rating': parental_rating, 'genres': genres, 'year': year,
                      'overview': overview, 'director': director, 'cast': cast,
                      'country': country, 'item_title': item_title, 'provider': provider,
                      'backdrop_url': backdrop_url}
            set_cached_search(title, result)
            return (STATUS_FOUND, url, vote_average, parental_rating, genres,
                    year, overview, director, cast, country, item_title, provider)
        if status == STATUS_NETWORK:
            return (STATUS_NETWORK, None, 0, "", "", "", "", "", "", "", "", provider)

    if source == "live":
        status, url, vote_average = _imdb_search(tries[0])
        if status == STATUS_FOUND:
            result = {'status': STATUS_FOUND, 'url': url, 'vote_average': vote_average,
                      'provider': 'IMDB'}
            set_cached_search(title, result)
            return (STATUS_FOUND, url, vote_average, "", "", "", "", "", "", "", "", "IMDB")
        if status == STATUS_NETWORK:
            return (STATUS_NETWORK, None, 0, "", "", "", "", "", "", "", "", "IMDB")

    m = re.search(r"^(.*?)\s+(\d+)$", tries[0])
    if m:
        try:
            num = int(m.group(2))
        except Exception:
            num = 0
        base = m.group(1).strip()
        if num > 10 and len(base) >= 3:
            (status, url, vote_average, parental_rating, genres, year, overview,
             director, cast, country, item_title, backdrop_url) = _tmdb_search(base)
            if status == STATUS_FOUND:
                result = {'status': STATUS_FOUND, 'url': url, 'vote_average': vote_average,
                          'parental_rating': parental_rating, 'genres': genres, 'year': year,
                          'overview': overview, 'director': director, 'cast': cast,
                          'country': country, 'item_title': item_title, 'provider': 'TMDB',
                          'backdrop_url': backdrop_url}
                set_cached_search(title, result)
                return (STATUS_FOUND, url, vote_average, parental_rating, genres,
                        year, overview, director, cast, country, item_title, "TMDB")
            if status == STATUS_NETWORK:
                return (STATUS_NETWORK, None, 0, "", "", "", "", "", "", "", "", "TMDB")

    set_cached_search(title, {'status': STATUS_NOT_FOUND})
    return (STATUS_NOT_FOUND, None, 0, "", "", "", "", "", "", "", "", "-")

# ============================================================================
# QUEUE MANAGEMENT
# ============================================================================

def _release(title):
    with _pending_lock:
        _pending.pop(title, None)

def _cleanup_stale_pending():
    now = time.time()
    with _pending_lock:
        stale = [t for t, ts in _pending.items() if now - ts > _pending_expiry]
        for s in stale:
            del _pending[s]

# ============================================================================
# POSTER DOWNLOAD
# ============================================================================

def _save_poster(url, dest):
    if not REQUESTS_OK or not network_available():
        return STATUS_NETWORK
    tmp = dest + ".part"
    try:
        resp = http_session.get(url, headers={"User-Agent": _ua()},
                                timeout=(T_CONN, T_IMG), verify=False, stream=False)
        if not resp.ok:
            if _is_network_status(resp.status_code):
                mark_network_error("img download failed")
                return STATUS_NETWORK
            return STATUS_SAVE_FAIL
        mark_network_ok()
        data = resp.content
        if not data or len(data) < MIN_BYTES:
            return STATUS_SAVE_FAIL
        with open(tmp, "wb") as f:
            f.write(data)
        if Image is not None:
            try:
                img = Image.open(tmp)
                img.verify()
                img.close()
            except Exception:
                return STATUS_SAVE_FAIL
        os.replace(tmp, dest)
        if os.path.exists(dest):
            return STATUS_FOUND
        return STATUS_SAVE_FAIL
    except Exception as e:
        if _is_network_exception(e):
            mark_network_error(str(e))
            return STATUS_NETWORK
        return STATUS_SAVE_FAIL
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass

# ============================================================================
# PROCESSING
# ============================================================================

def _process(item, source):
    if len(item) >= 4:
        clean_title, raw, ch, candidates = item
    else:
        clean_title, raw, ch = item
        candidates = [clean_title]

    dest = os.path.join(path_folder, clean_title + ".jpg")
    _t_job_start = time.time()  # DEBUG TRACE
    trace("Worker", "process-start", "title=%s thread=%s" % (clean_title, threading.current_thread().name))  # DEBUG TRACE

    try:
        if not _should_download(clean_title, dest):
            if os.path.exists(dest):
                _notify_download_success(clean_title, dest)
            trace("Worker", "process-end", "title=%s reason=should-not-download took=%dms" % (  # DEBUG TRACE
                clean_title, int((time.time() - _t_job_start) * 1000)))
            return

        if not network_available():
            log_event(source, ch, raw, clean_title, "SKIP", "-",
                      "network cooldown")
            trace("Worker", "process-end", "title=%s reason=network-cooldown took=%dms" % (  # DEBUG TRACE
                clean_title, int((time.time() - _t_job_start) * 1000)))
            return

        with timed_block("Worker", "find-url", "title=%s" % clean_title):  # DEBUG TRACE
            (status, url, vote_average, parental_rating, genres, year, overview,
             director, cast, country, item_title, provider) = _find_url(clean_title, source, candidates)

        if status == STATUS_NETWORK:
            mark_network_error("search failed for %s" % clean_title)
            log_event(source, ch, raw, clean_title, "NETWORK", provider, "search error")
            trace("Worker", "process-end", "title=%s reason=network-error took=%dms" % (  # DEBUG TRACE
                clean_title, int((time.time() - _t_job_start) * 1000)))
            return

        if status == STATUS_FOUND and url:
            with timed_block("Worker", "save-poster", "title=%s" % clean_title):  # DEBUG TRACE
                save_status = _save_poster(url, dest)
            if save_status == STATUS_FOUND:
                _mark_found(clean_title, vote_average, parental_rating, genres,
                            year, overview, director, cast, country, item_title)
                log_event(source, ch, raw, clean_title, "FOUND", provider,
                          "saved rating=%.1f parental=%s" % (vote_average, parental_rating))
            elif save_status == STATUS_NETWORK:
                mark_network_error("download failed for %s" % clean_title)
                log_event(source, ch, raw, clean_title, "NETWORK", provider, "download error")
                _mark_not_found(clean_title)
            else:
                log_event(source, ch, raw, clean_title, "SAVE_FAIL", provider, "save error")
                _mark_not_found(clean_title)
        else:
            _mark_not_found(clean_title)
            log_event(source, ch, raw, clean_title, "NOT_FOUND", "-", "not found")
        trace("Worker", "process-end", "title=%s status=%s took=%dms" % (  # DEBUG TRACE
            clean_title, status, int((time.time() - _t_job_start) * 1000)))
    except Exception as e:
        log("Process error: %s" % e, "ERROR")
        trace("Worker", "process-EXCEPTION", "title=%s err=%s took=%dms" % (  # DEBUG TRACE
            clean_title, e, int((time.time() - _t_job_start) * 1000)))
    finally:
        _release(clean_title)

# ============================================================================
# WORKER THREAD
# ============================================================================

def _worker(worker_id):
    while True:
        try:
            _t_wait_start = time.time()  # DEBUG TRACE
            item = work_queue.get(timeout=1.0)
            if item is None:
                continue
            _wait_ms = int((time.time() - _t_wait_start) * 1000)  # DEBUG TRACE
            if _wait_ms > 50:  # DEBUG TRACE - only log if it actually had to wait, to keep idle workers quiet
                trace("Worker", "picked-up-job", "worker=%d waited=%dms qsize=%d" % (  # DEBUG TRACE
                    worker_id, _wait_ms, work_queue.qsize()))
            _process(item, "live")
        except _queue.Empty:
            continue
        except Exception as e:
            log("Worker %d error: %s" % (worker_id, str(e)), "WARN")
            trace("Worker", "worker-loop-EXCEPTION", "worker=%d err=%s" % (worker_id, e))  # DEBUG TRACE

# ============================================================================
# QUEUE_LIVE
# ============================================================================

def queue_live(clean_title, canal, candidates=None):
    if not clean_title:
        return False

    dest = os.path.join(path_folder, clean_title + ".jpg")
    if os.path.exists(dest):
        trace("Queue", "already-on-disk", "title=%s" % clean_title)  # DEBUG TRACE
        return False

    _cleanup_stale_pending()
    with _pending_lock:
        if clean_title in _pending:
            trace("Queue", "already-pending", "title=%s pending_count=%d" % (clean_title, len(_pending)))  # DEBUG TRACE
            return False
        _pending[clean_title] = time.time()

    try:
        raw = canal[5] if canal and len(canal) > 5 else clean_title
        ch = canal[0] if canal and len(canal) > 0 else "-"
        tries = _unique_items(candidates or [clean_title]) or [clean_title]

        work_queue.put_nowait((clean_title, raw, ch, tries))
        # qsize() is approximate per Python docs but good enough to see
        # whether the queue is actually backing up over a session — if
        # this number keeps climbing instead of staying low, workers are
        # not draining as fast as zaps are enqueuing, which is exactly
        # the "saturation" you're describing.
        trace("Queue", "enqueued", "title=%s qsize=%d pending_count=%d" % (  # DEBUG TRACE
            clean_title, work_queue.qsize(), len(_pending)))
        return True
    except _queue.Full:
        _release(clean_title)
        log("Queue full, dropping: %s" % clean_title, "WARN")
        return False

# ============================================================================
# FLUSH LOOP + PERIODIC CLEANUP + INITIALIZATION
# ============================================================================

def _flush_loop():
    while True:
        _flush_ev.wait(timeout=60)
        _flush_ev.clear()
        with _state_lock:
            dirty = _dirty[0]
        if dirty > 0:
            _write_state()
        if time.time() - _last_cleanup[0] > CLEANUP_INTERVAL_S:
            _clean_old_entries()
            _last_cleanup[0] = time.time()

def _async_initialize():
    if not _POSTERX_ENABLED:
        log("PosterX downloader DISABLED - workers not started")
        return
    _load_state()

    for i in range(6):
        t = threading.Thread(target=_worker, args=(i,))
        t.daemon = True
        t.start()

    t_flush = threading.Thread(target=_flush_loop)
    t_flush.daemon = True
    t_flush.start()
    log("PosterX initialized: 6 workers + flush/cleanup loop running", "INFO")

# ============================================================================
# ENABLE/DISABLE FLAG
# Note: this only gates the *initial* worker startup in _async_initialize().
# Once the 6 workers + flush loop are running, set_posterx_enabled(False)
# does not stop them mid-flight — it is a pre-start guard, not a kill switch.
# ============================================================================

_POSTERX_ENABLED = True

def set_posterx_enabled(enabled):
    global _POSTERX_ENABLED
    _POSTERX_ENABLED = enabled
    log("PosterX downloader {}".format("enabled" if enabled else "disabled"))

def is_posterx_enabled():
    return _POSTERX_ENABLED

# Register queue_live as the batch-poster handler. After this, every
# ZapContext rebuild submits all of a zap's missing posters in one pass
# (right after _build() already computed the full list), instead of each
# iPosterX widget separately calling queue_live() one title at a time —
# the trace log showed posters from the same zap being queued 1-17ms
# apart through independent per-widget calls. queue_live() already guards
# against duplicate/already-pending/already-on-disk titles, so calling it
# here is safe even though iPosterX.changed() may also still call it
# itself as a fallback (e.g. for the nxts=0 Event-source direct-read path,
# which doesn't go through ZapContext at all).
set_batch_poster_queue_fn(queue_live)

# Register the in-memory state overlay (see set_state_overlay_fn's
# docstring in iConverlibr.py for the full rationale). Closes the gap
# where a title is fully resolved in memory but scan_state.json on disk
# hasn't been flushed yet — without this, the metadata renderers
# (iStarX/iParental/iInfoEvents) could re-register for the same
# already-ready title forever, since their only data source was the file.
set_state_overlay_fn(_get_state_snapshot)

_init_thread = threading.Thread(target=_async_initialize)
_init_thread.daemon = True
_init_thread.start()
