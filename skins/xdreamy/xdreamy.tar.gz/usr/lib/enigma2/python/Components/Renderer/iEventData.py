# -*- coding: utf-8 -*-

"""
iEventData.py
-------------
Enigma2 converter targeting a single database file: iEventData.json
Configured using the central BASE_PATH to ensure compatibility.
"""

from __future__ import absolute_import
import os
import json
import threading
import sys
from Components.Converter.Converter import Converter
from Components.Element import cached

# Import central base path for system-wide consistency
try:
    from .iConverlibr import BASE_PATH
except ImportError:
    BASE_PATH = "/media/hdd/XDREAMY"

PY3 = sys.version_info[0] >= 3

# ---------------------------------------------------------------------------
# Dynamic Path Settings
# ---------------------------------------------------------------------------
PATH_FOLDER = os.path.join(BASE_PATH, "poster")
CENTRAL_JSON_FILE = "iEventData.json"

# ---------------------------------------------------------------------------
# Fallback Import for Title Cleaning Engine
# ---------------------------------------------------------------------------
try:
    from Components.Renderer.iConverlibr import convtext
except ImportError:
    try:
        from .iConverlibr import convtext
    except ImportError:
        def convtext(text):
            return text or u""

# Global RAM cache variables to maximize speed
_meta_cache = {}
_meta_cache_lowercase = {}
_last_mtime = 0
_meta_cache_lock = threading.Lock()


def get_metadata_cached(clean_title, json_dir_path):
    """
    Reads the data directly from the central database.
    Caches everything in RAM so changing channels remains instant.
    """
    global _meta_cache, _meta_cache_lowercase, _last_mtime
    json_path = os.path.join(json_dir_path, CENTRAL_JSON_FILE)
    
    with _meta_cache_lock:
        try:
            if os.path.exists(json_path):
                current_mtime = os.path.getmtime(json_path)
                # Reload file into memory if it changed on disk or if cache is empty
                if current_mtime != _last_mtime or not _meta_cache:
                    with open(json_path, "r") as f:
                        loaded_data = json.load(f)
                        if isinstance(loaded_data, dict):
                            _meta_cache = loaded_data
                            # Match lowercase keys to bypass spacing or upper/lower case differences
                            _meta_cache_lowercase = {str(k).lower().strip(): v for k, v in loaded_data.items()}
                        else:
                            _meta_cache = {}
                            _meta_cache_lowercase = {}
                    _last_mtime = current_mtime
        except Exception:
            pass

        if isinstance(_meta_cache_lowercase, dict):
            search_title = str(clean_title).lower().strip()
            return _meta_cache_lowercase.get(search_title)
                
    return None


class iEventData(Converter, object):
    RATING   = 0
    GENRE    = 1
    YEAR     = 2
    OVERVIEW = 3

    def __init__(self, type):
        Converter.__init__(self, type)
        if type == "Rating":
            self.type = self.RATING
        elif type == "Genre":
            self.type = self.GENRE
        elif type == "Year":
            self.type = self.YEAR
        else:
            self.type = self.OVERVIEW

    @cached
    def getText(self):
        event = self.source.event
        if event is None:
            return ""

        event_name = event.getEventName()
        if not event_name:
            return ""

        try:
            if not PY3 and isinstance(event_name, str):
                event_name = event_name.decode('utf-8', 'ignore')
            clean_title = convtext(event_name)
        except Exception:
            clean_title = event_name

        # Query the explicit, exact folder path location
        data = get_metadata_cached(clean_title, PATH_FOLDER)

        if not data or not isinstance(data, dict):
            return ""

        try:
            # Standardize internal file values to lowercase
            data_lower = {str(k).lower().strip(): v for k, v in data.items()}

            if self.type == self.RATING:
                rating = data_lower.get("rating") or data_lower.get("rate") or "0.0"
                if rating not in ["0.0", "N/A", "0", ""]:
                    return u"★ %s/10" % rating
                return ""

            elif self.type == self.GENRE:
                return data_lower.get("genres") or data_lower.get("genre") or data_lower.get("genrelist") or ""

            elif self.type == self.YEAR:
                year = data_lower.get("year") or data_lower.get("date") or "----"
                if year not in ["----", ""]:
                    return str(year)
                return ""

            elif self.type == self.OVERVIEW:
                return data_lower.get("overview") or data_lower.get("plot") or data_lower.get("description") or ""

        except Exception:
            pass

        return ""

    text = property(getText)