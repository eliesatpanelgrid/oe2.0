# -*- coding: utf-8 -*-
# ============================================================================
#  iAccess.py  -  XDREAMY Access/CAID/ECM/Emu/CryptoBar converter (v9.2)
#  - Lock-free atomic data swaps, O(1) CAID caching, optimized OS calls.
# ============================================================================

from __future__ import absolute_import
from Components.Converter.Converter import Converter
from enigma import iServiceInformation, iPlayableService
import NavigationInstance
from Components.config import config
import os
import re
import time
import threading
from collections import deque

# ----------------------------------------------------------------------------
#  Debug
# ----------------------------------------------------------------------------
MODULE_NAME = "iAccess"
LOGFILE = "/tmp/%s_Debug.log" % MODULE_NAME

_debug_cache = {"enabled": False, "time": 0}
_DEBUG_CACHE_TTL = 1.0

def _debug_enabled():
    now = time.time()
    if now - _debug_cache["time"] < _DEBUG_CACHE_TTL:
        return _debug_cache["enabled"]
    try:
        xd = config.plugins.xDreamy
        enabled = bool(xd.debug_master.value) and bool(getattr(xd, "dbg_%s" % MODULE_NAME).value)
    except Exception:
        enabled = False
    _debug_cache["enabled"] = enabled
    _debug_cache["time"] = now
    return enabled

def dbg(tag, msg):
    if _debug_enabled():
        line = "[%s][%s] %s" % (MODULE_NAME, tag, msg)
        try:
            print(line)
        except Exception:
            pass
        try:
            with open(LOGFILE, "a") as f:
                f.write(line + "\n")
        except Exception:
            pass

try:
    from enigma import eConsoleAppContainer
except Exception:
    eConsoleAppContainer = None

# --- Language Translation Fallback -----------------------------------------
try:
    from Components.Language import language
    _ = language.getText
except Exception:
    def _(txt):
        return txt

# --- eBitrateCalculator (optional) -----------------------------------------
_BITRATECALC_PATHS = (
    "/usr/lib/enigma2/python/Components/Converter/bitratecalc.so",
)
_BITRATECALC_AVAILABLE = any(os.path.isfile(p) for p in _BITRATECALC_PATHS)
eBitrateCalculator = None
if _BITRATECALC_AVAILABLE:
    try:
        from bitratecalc import eBitrateCalculator
    except Exception:
        try:
            from Components.Converter.bitratecalc import eBitrateCalculator
        except Exception:
            eBitrateCalculator = None
            _BITRATECALC_AVAILABLE = False

# --- opbitrate integration ------------------------------------------------
_OPBITRATE_PATH = None
try:
    import platform
    _is_arm_platform = platform.machine().lower().startswith(("arm", "aarch"))
except Exception:
    _is_arm_platform = True

if _is_arm_platform:
    for p in ("/usr/bin/opbitrate", "/usr/local/bin/opbitrate"):
        try:
            if os.path.isfile(p) and os.access(p, os.X_OK):
                _OPBITRATE_PATH = p
                break
        except Exception:
            pass

_OPBITRATE_STUCK_TIMEOUT = 5.0
_OPBITRATE_AVERAGE_WINDOW = 5

# ============================================================================
#  XDREAMY gate
# ============================================================================
XDREAMY_SKIN_MARKER = "xdreamy"

def _is_xdreamy_active():
    try:
        skin_path = str(config.skin.primary_skin.value or "")
        return XDREAMY_SKIN_MARKER in skin_path.lower()
    except Exception:
        return False

def _in_standby():
    try:
        import Screens.Standby
        return Screens.Standby.inStandby is not None
    except Exception:
        return False

# ============================================================================
#  CAID TABLE & O(1) CACHED LOOKUP
# ============================================================================
cainfo = [
    ("0002", "0002", "18Crypt"), ("0100", "01FF", "Seca"), ("0200", "02FF", "CCETT"),
    ("0300", "03FF", "Kabel Deutschland"), ("0400", "04FF", "Eurodec"),
    ("0500", "05FF", "Viaccess"), ("0600", "06FF", "Irdeto"), ("0700", "07FF", "DigiChiper"),
    ("0800", "08FF", "Matra"), ("0900", "09FF", "NDS/Videoguard"), ("0A00", "0AFF", "Nokia"),
    ("0B00", "0BFF", "Conax"), ("0C00", "0CFF", "NTL"), ("0D00", "0DFF", "Cryptoworks"),
    ("0E00", "0EFF", "PowerVu"), ("0F00", "0FFF", "Sony"), ("1000", "10FF", "Tandberg"),
    ("1100", "11FF", "Thomson"), ("1200", "12FF", "TV/Com"), ("1300", "14FF", "HRT"),
    ("1500", "15FF", "IBM"), ("1600", "16FF", "Nera"), ("1702", "1702", "Betacrypt"),
    ("1722", "1722", "Betacrypt"), ("1762", "1762", "Betacrypt"), ("1700", "1701", "Verimatrix"),
    ("1703", "1721", "Verimatrix"), ("1723", "1761", "Verimatrix"), ("1763", "17FF", "Verimatrix"),
    ("1800", "18FF", "Nagravision"), ("1900", "19FF", "Titan"), ("1E00", "1E07", "Alticast"),
    ("1EA0", "1EA0", "Monacrypt"), ("1EB0", "1EB0", "TeleCast"), ("1EC0", "1EC2", "Cryptoguard"),
    ("1ED0", "1ED1", "Monacrypt"), ("2000", "20FF", "Telefonica Servicios Audiovisuales"),
    ("2100", "21FF", "Stendor"), ("2200", "22FF", "Codicrypt"), ("2300", "23FF", "Barco"),
    ("2400", "24FF", "StarGuide"), ("2500", "25FF", "Mentor"), ("2600", "2601", "Biss"),
    ("2602", "26FF", "Biss2"), ("2700", "2711", "ExSet"), ("2712", "2712", "Derincrypt"),
    ("2713", "2714", "Wuhan"), ("2715", "2715", "Network Broadcast"), ("2716", "2716", "Bromteck"),
    ("2717", "2718", "LogiWays"), ("2719", "2719", "S-Curious"), ("27A0", "27A4", "ByDesign India"),
    ("2800", "2809", "LCS LLC"), ("2810", "2810", "DeltaSat"), ("4347", "4347", "Crypton"),
    ("4348", "4348", "Secure TV"), ("44A0", "44A0", "Russkiy Mir"), ("4700", "47FF", "General Instrument/Motorola"),
    ("4825", "4825", "ChinaEPG"), ("4855", "4856", "Intertrust"), ("4800", "48FF", "AccessGate/Telemann"),
    ("4900", "49FF", "Cryptoworks China"), ("4A10", "4A1F", "EasyCas"), ("4A20", "4A2F", "AlphaCrypt"),
    ("4A30", "4A3F", "DVN Holdings"), ("4A40", "4A4F", "ADT"), ("4A50", "4A5F", "Shenzhen Kingsky"),
    ("4A60", "4A6F", "@Sky"), ("4A70", "4A7F", "DreamCrypt"), ("4A80", "4A8F", "THALESCrypt"),
    ("4A90", "4A9F", "Runcom"), ("4AA0", "4AAF", "SIDSA"), ("4AB0", "4ABF", "Beijing Compunicate"),
    ("4AC0", "4ACF", "Latens"), ("4AD0", "4AD1", "XCrypt"), ("4AD2", "4AD3", "Beijing Digital"),
    ("4AD4", "4AD5", "Widevine"), ("4AD6", "4AD7", "SK Telecom"), ("4AD8", "4AD9", "Enigma"),
    ("4ADA", "4ADA", "Wyplay"), ("4ADB", "4ADB", "Jinan Taixin"), ("4ADC", "4ADC", "LogiWays"),
    ("4ADD", "4ADD", "ATSC SRM"), ("4ADE", "4ADE", "CerberCrypt"), ("4ADF", "4ADF", "Caston"),
    ("4AE0", "4AE1", "DreCrypt"), ("4AE2", "4AE3", "Microsoft"), ("4AE4", "4AE4", "Coretrust"),
    ("4AE5", "4AE5", "IK SATPROF"), ("4AE6", "4AE6", "SypherMedia"), ("4AE7", "4AE7", "Guangzhou Ewider"),
    ("4AE8", "4AE8", "FG Digital"), ("4AE9", "4AE9", "Dreamer-i"), ("4AEA", "4AEA", "Cryptoguard"),
    ("4AEB", "4AEB", "Abel"), ("4AEC", "4AEC", "FTS DVL SRL"), ("4AED", "4AED", "Unitend"),
    ("4AEE", "4AEE", "Bulcrypt"), ("4AEF", "4AEF", "NetUP"), ("4AF0", "4AF0", "ABV"),
    ("4AF1", "4AF2", "China DTV"), ("4AF3", "4AF3", "Baustem"), ("4AF4", "4AF4", "Marlin"),
    ("4AF5", "4AF5", "SecureMedia"), ("4AF6", "4AF6", "Tongfang"), ("4AF7", "4AF7", "MSA"),
    ("4AF8", "4AF8", "Griffin"), ("4AF9", "4AFA", "Beijing Topreal"), ("4AFB", "4AFB", "NST"),
    ("4AFC", "4AFC", "PanAccess"), ("4AFD", "4AFD", "Comteza"), ("4B00", "4B02", "Tongfang"),
    ("4B03", "4B03", "DuoCrypt"), ("4B04", "4B04", "Great Wall"), ("4B05", "4B06", "Digicap"),
    ("4B07", "4B07", "Wuhan"), ("4B08", "4B08", "Philips"), ("4B09", "4B09", "Ambernetas"),
    ("4B0A", "4B0F", "Beijing Sumavision"), ("4B10", "4B10", "Exterity"), ("4B11", "4B12", "Merlin/Advanced Digital"),
    ("4B13", "4B14", "Microsoft"), ("4B19", "4B19", "RidSys"), ("4B20", "4B22", "DeltaSat"),
    ("4B23", "4B23", "SkyNLand"), ("4B24", "4B24", "Prowill"), ("4B25", "4B25", "SureSoft"),
    ("4B26", "4B26", "Unitend"), ("4B30", "4B31", "VTC"), ("4B3A", "4B3A", "ipanel"),
    ("4B3B", "4B3B", "Jinggangshan"), ("4B40", "4B41", "ExCaf"), ("4B42", "4B43", "CI Plus"),
    ("4B4A", "4B4A", "Topwell"), ("4B4B", "4B4D", "ABV"), ("4B50", "4B53", "Safeview India"),
    ("4B54", "4B54", "Telelynx"), ("4B60", "4B60", "KiwiSat"), ("4B61", "4B61", "O2 Czech"),
    ("4B62", "4B62", "GMA"), ("4B63", "4B63", "redCrypter"), ("4B64", "4B64", "Samsung/TV Key"),
    ("4B65", "4B67", "CryptoWorks"), ("4B68", "4B7F", "Verimatrix"), ("4B80", "4B9F", "Sichuan"),
    ("4BA0", "4BBF", "Viewscenes"), ("5605", "5608", "Viewscenes/Power On"), ("56A0", "56A0", "Laxmi"),
    ("56A1", "56A1", "C-Dot"), ("56B0", "56B0", "Laxmi"), ("56D0", "56D1", "redCrypter"),
    ("7AC8", "7AC8", "Gospell VisionCrypt"), ("7BE0", "7BE1", "DreCrypt"), ("AA00", "AA01", "Best CAS"),
    ("0001", "0001", "IPDC SPP"), ("0004", "0006", "OMA"), ("0007", "0007", "Open IPTV"),
    ("0008", "0008", "Open Mobile Alliance"), ("5347", "5347", "GkWare/StreamGuru"), ("5448", "5449", "Gospell VisionCrypt"),
    ("5501", "5580", "Griffin"), ("5581", "55FF", "Bulcrypt"), ("5601", "5604", "Verimatrix"),
    ("5605", "5606", "Sichuan"), ("5607", "5608", "Viewscenes"), ("5609", "5609", "Power On"),
    ("56A0", "56A0", "Laxmi"), ("56A1", "56A1", "C-Dot"), ("56B0", "56B0", "Laxmi"),
    ("56D0", "56D1", "redCrypter"), ("6448", "6449", "Gospell VisionCrypt"), ("A100", "A1FF", "RusCrypt"),
    ("0000", "0000", "no or unknown")
]

_caid_ranges = []
for entry in cainfo:
    try:
        start = int(entry[0], 16)
        end = int(entry[1], 16)
        name = entry[2]
        _caid_ranges.append((start, end, name))
    except Exception:
        pass
_caid_ranges.sort()

# Pre-cache mapping for instant lookup
_caid_cache = {}

def _lookup_caid_name(caid_hex):
    if not caid_hex or len(caid_hex) < 4:
        return ""
    
    # O(1) Cache Hit
    if caid_hex in _caid_cache:
        return _caid_cache[caid_hex]

    try:
        caid_int = int(caid_hex[:4], 16)
    except Exception:
        return ""

    best = None
    best_span = None
    for start, end, name in _caid_ranges:
        if start <= caid_int <= end:
            span = end - start
            if best_span is None or span < best_span:
                best, best_span = name, span

    resolved_name = best or ""
    _caid_cache[caid_hex] = resolved_name
    return resolved_name


# ============================================================================
#  BACKGROUND DATA READER (Singleton) - LOCK FREE
# ============================================================================
class _BackgroundReader:
    _instance = None
    _init_lock = threading.Lock()

    def __new__(cls):
        if not cls._instance:
            with cls._init_lock:
                if not cls._instance:
                    cls._instance = super(_BackgroundReader, cls).__new__(cls)
                    cls._instance._initialize()
        return cls._instance

    def _initialize(self):
        # We drop the threading data_lock. Dictionary assignment is atomic in Python. 
        # This gives 100% lock-free reads to the UI thread.
        self.ecm_data = {}
        self.cam_name = "N/A"

        self._ecm_mtime = 0
        self._ecm_path = None
        self._cam_name_cache = "N/A"
        self._cam_last_check = 0

        self._current_service_ref = None
        self._stop_event = threading.Event()
        self._force_update_event = threading.Event()

        self._ecm_paths = (
            "/tmp/ecm7.info", "/tmp/ecm6.info", "/tmp/ecm5.info", "/tmp/ecm4.info",
            "/tmp/ecm3.info", "/tmp/ecm2.info", "/tmp/ecm1.info", "/tmp/ecm.info"
        )

        self._thread = threading.Thread(target=self._thread_loop)
        self._thread.daemon = True
        self._thread.start()

    def stop(self):
        self._stop_event.set()
        self._force_update_event.set()

    def get_data(self):
        # Read-only return without locks
        return self.ecm_data, self.cam_name

    def force_update(self):
        self._force_update_event.set()

    def _parse_ecm_file(self, path):
        info = {}
        if not path:
            return info
        try:
            # Combine exists and size check into one stat call (faster IO)
            fstat = os.stat(path)
            if fstat.st_size == 0:
                return info
            with open(path, "r") as ecmf:
                ecm = ecmf.readlines()
        except Exception:
            return info

        for line in ecm:
            try:
                x = line.lower().find("msec")
                if x != -1:
                    info["ecm time"] = line[0:x+4]
                else:
                    item = line.split(":", 1)
                    if len(item) > 1:
                        key = item[0].strip().lower()
                        val = item[1].strip()
                        if key == "provider":
                            key = "prov"
                            val = val[2:] if len(val) > 2 else val
                        elif key == "ecm pid":
                            key = "pid"
                        elif key == "response time":
                            info["source"] = "net"
                            it_tmp = val.split(" ")
                            info["ecm time"] = "%s msec" % it_tmp[0]
                            last_part = it_tmp[-1]
                            y = last_part.find("[")
                            if y != -1:
                                info["server"] = last_part[:y]
                                info["protocol"] = last_part[y+1:-1]
                            y = last_part.find("(")
                            if y != -1:
                                info["server"] = last_part.split("(")[-1].split(":")[0]
                                info["port"] = last_part.split("(")[-1].split(":")[-1].rstrip(")")
                            elif y == -1:
                                key = "source"
                                val = "sci"
                            if any(k in last_part for k in ("emu", "card", "biss", "tb")):
                                key = "source"
                                val = "emu"
                        elif key == "hops":
                            val = val.strip("\n")
                        elif key == "from":
                            val = val.strip("\n")
                        elif key == "system":
                            val = val.strip("\n")
                        elif key == "provider":
                            val = val.strip("\n")
                        elif key.startswith("cw") and key not in ("cw0", "cw1"):
                            continue
                        elif key == "cw0":
                            info["cw0"] = val.strip("\n")
                        elif key == "cw1":
                            info["cw1"] = val.strip("\n")
                        elif key in ("chid", "service"):
                            continue
                        elif key == "source":
                            if val.startswith("net"):
                                it_tmp = val.split(" ")
                                if len(it_tmp) > 1:
                                    info["protocol"] = it_tmp[1].lstrip("(")
                                if ":" in it_tmp[-1]:
                                    info["server"] = it_tmp[-1].split(":", 1)[0]
                                    info["port"] = it_tmp[-1].split(":", 1)[1].rstrip(")")
                                val = "net"
                        elif key == "prov":
                            y = val.find(",")
                            if y != -1:
                                val = val[:y]
                        elif key == "reader":
                            if val == "emu":
                                key = "source"
                        elif key == "protocol":
                            if val in ("emu", "constcw"):
                                val = "emu"
                                key = "source"
                            elif val == "internal":
                                val = "sci"
                                key = "source"
                            else:
                                info["source"] = "net"
                                key = "server"
                        elif key == "provid":
                            key = "prov"
                        elif key == "using":
                            if val in ("emu", "sci"):
                                key = "source"
                            else:
                                info["source"] = "net"
                                key = "protocol"
                        elif key == "address":
                            tt = val.find(":")
                            if tt != -1:
                                info["server"] = val[:tt].strip()
                                key = "port"
                                val = val[tt+1:]
                        info[key] = val
                    else:
                        if "caid" not in info:
                            x = line.lower().find("caid")
                            if x != -1:
                                y = line.find(",")
                                if y != -1:
                                    info["caid"] = line[x+5:y].strip()
                        if "pid" not in info:
                            x = line.lower().find("pid")
                            if x != -1:
                                y = line.find(" =")
                                z = line.find(" *")
                                if y != -1:
                                    info["pid"] = line[x+4:y].strip()
                                elif z != -1:
                                    info["pid"] = line[x+4:z].strip()
            except Exception:
                continue
        return info

    def _clean_cam_version(self, line):
        raw = line.split("@", 1)[0].split(":", 1)[-1].strip()
        nums = re.findall(r"\d{3,}", raw)
        if len(nums) >= 2:
            return "%s - %s" % (nums[0], nums[1])
        if len(nums) == 1:
            return nums[0]
        return re.sub(r"\s+", " ", raw)

    def _detect_cam_name(self, force=False):
        now = time.time()
        # Increased to 15s to eliminate unnecessary module imports during zap
        if not force and (now - self._cam_last_check < 15.0):
            return self._cam_name_cache

        try:
            if os.path.exists("/etc/clist.list") and any(os.path.exists(p) for p in (
                "/usr/lib/enigma2/python/Plugins/Extensions/pManager/camrestart.py",
                "/usr/lib/enigma2/python/Plugins/Extensions/pManager/camrestart.pyo",
                "/usr/lib/enigma2/python/Plugins/Extensions/pManager/camrestart.pyc"
            )):
                with open("/etc/clist.list", "r") as f:
                    line = f.readline().strip()
                    if line:
                        self._cam_name_cache = line
                        self._cam_last_check = now
                        return line

            from Tools.Directories import resolveFilename, SCOPE_PLUGINS
            if os.path.exists(resolveFilename(SCOPE_PLUGINS, "Extensions/AlternativeSoftCamManager/plugin.py")):
                if config.plugins.AltSoftcam.actcam.value != "none":
                    self._cam_name_cache = config.plugins.AltSoftcam.actcam.value
                    self._cam_last_check = now
                    return self._cam_name_cache

            if os.path.exists(resolveFilename(SCOPE_PLUGINS, "SystemPlugins/ViX/SoftcamManager.pyo")) or \
               os.path.exists(resolveFilename(SCOPE_PLUGINS, "SystemPlugins/ViX/SoftcamManager.pyc")):
                for softcamcheck in config.softcammanager.softcams_autostart.value:
                    self._cam_name_cache = softcamcheck.replace("/usr/softcams/", "").replace("\n", "")
                    self._cam_last_check = now
                    return self._cam_name_cache

            if os.path.exists(resolveFilename(SCOPE_PLUGINS, "Bp/geminimain/lib/libgeminimain.so")):
                from Plugins.Bp.geminimain.plugin import GETCAMDLIST
                from Plugins.Bp.geminimain.lib import libgeminimain
                for x in libgeminimain.getPyList(GETCAMDLIST):
                    if x[1] == 1:
                        self._cam_name_cache = x[2]
                        self._cam_last_check = now
                        return self._cam_name_cache

            if os.path.exists(resolveFilename(SCOPE_PLUGINS, "GP4/geminicamswitch/gscamScreen.pyo")) or \
               os.path.exists(resolveFilename(SCOPE_PLUGINS, "GP4/geminicamswitch/gscamScreen.pyc")):
                from Plugins.GP4.geminicamswitch.gscamtools import gpconfset
                if gpconfset.gcammanager.currentbinary.value:
                    self._cam_name_cache = gpconfset.gcammanager.currentbinary.value
                    self._cam_last_check = now
                    return self._cam_name_cache

            if os.path.exists(resolveFilename(SCOPE_PLUGINS, "newnigma2/eCamdCtrl/eCamdctrl.pyo")) or \
               os.path.exists(resolveFilename(SCOPE_PLUGINS, "newnigma2/eCamdCtrl/eCamdctrl.pyc")):
                if config.plugins.camdname.skin.value:
                    from Plugins.newnigma2.eCamdCtrl.eCamdctrl import runningcamd
                    self._cam_name_cache = runningcamd.getCamdCurrent()
                    self._cam_last_check = now
                    return self._cam_name_cache

            if os.path.exists(resolveFilename(SCOPE_PLUGINS, "newnigma2/camdctrl/camdctrl.pyo")) or \
               os.path.exists(resolveFilename(SCOPE_PLUGINS, "newnigma2/camdctrl/camdctrl.pyc")):
                if config.plugins.camdname.skin.value:
                    self._cam_name_cache = config.usage.emu_name.value
                    self._cam_last_check = now
                    return self._cam_name_cache
        except Exception:
            pass

        cam1, cam2 = "", ""
        camdname = []

        if (os.path.exists("/etc/init.d/softcam") and not os.path.exists("/etc/image-version")) or \
           (os.path.exists("/etc/init.d/cardserver") and not os.path.exists("/etc/image-version")):
            try:
                with open("/etc/init.d/softcam", "r") as f:
                    for line in f:
                        if line.startswith("CAMNAME="):
                            cam1 = line.split('"')[1]
                        elif "echo" in line:
                            camdname.append(line)
                if len(camdname) > 1:
                    cam2 = camdname[1].split('"')[1]
                self._cam_name_cache = cam1 if cam1 else cam2
                self._cam_last_check = now
                return self._cam_name_cache
            except Exception:
                pass

        if os.path.exists("/etc/image-version"):
            try:
                with open("/etc/image-version", "r") as f:
                    content = f.read()
                if any(img in content for img in ("=openATV", "=teamBlue", "=openvix", "=openbh", "=egamimod", "=opendroid")):
                    try:
                        if hasattr(config, "softcam") and hasattr(config.softcam, "actCam") and config.softcam.actCam.value:
                            cam1 = config.softcam.actCam.value
                            if " CAM 1" in cam1 or "no cam" in cam1:
                                cam1 = "No CAM active"
                        if hasattr(config, "softcam") and hasattr(config.softcam, "actCam2") and config.softcam.actCam2.value:
                            cam2 = config.softcam.actCam2.value
                            if " CAM 2" in cam2 or "no cam" in cam2 or " CAM" in cam2:
                                cam2 = ""
                            else:
                                cam2 = "+" + cam2
                    except Exception:
                        pass
                    if os.path.exists("/tmp/.oscam/oscam.version"):
                        try:
                            with open("/tmp/.oscam/oscam.version", "r") as f:
                                for line in f:
                                    if line.startswith("Version:"):
                                        cam1 = "OSCAM %s" % self._clean_cam_version(line)
                                        break
                        except Exception:
                            pass
                    elif os.path.exists("/tmp/.ncam/ncam.version"):
                        try:
                            with open("/tmp/.ncam/ncam.version", "r") as f:
                                for line in f:
                                    if line.startswith("Version:"):
                                        cam1 = "NCAM %s" % self._clean_cam_version(line)
                                        break
                        except Exception:
                            pass
                    self._cam_name_cache = "%s%s" % (cam1, cam2) if cam1 else cam2
                    self._cam_last_check = now
                    return self._cam_name_cache
            except Exception:
                pass

        for f in ("/etc/CurrentDelCamName", "/etc/CurrentBhCamName", "/tmp/egami.inf", "/tmp/cam.info", "/tmp/ucm_cam.info"):
            if os.path.exists(f):
                try:
                    with open(f, "r") as fp:
                        content = fp.read().strip()
                        if content:
                            if "Current emulator" in content:
                                for line in content.splitlines():
                                    if "Current emulator" in line:
                                        self._cam_name_cache = line.split(":", 1)[-1].strip()
                                        self._cam_last_check = now
                                        return self._cam_name_cache
                            self._cam_name_cache = content.splitlines()[0].strip()
                            self._cam_last_check = now
                            return self._cam_name_cache
                except Exception:
                    pass

        self._cam_last_check = now
        return self._cam_name_cache

    def _check_service_change(self):
        try:
            if NavigationInstance.instance is None:
                return False
            ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
            if ref is None:
                return False
            ref_str = ref.toString()
            if ref_str != self._current_service_ref:
                self._current_service_ref = ref_str
                return True
        except Exception:
            pass
        return False

    def _thread_loop(self):
        self._do_update(force=True)
        while not self._stop_event.is_set():
            try:
                if _in_standby():
                    self._stop_event.wait(1.0)
                    continue
                if self._check_service_change():
                    self._force_update_event.set()
                if self._force_update_event.is_set():
                    self._do_update(force=True)
                    self._force_update_event.clear()
                else:
                    self._do_update(force=False)
            except Exception as e:
                dbg("thread_loop", "unexpected error, continuing: %r" % e)
            self._stop_event.wait(0.2)

    def _do_update(self, force=False):
        current_path = None
        mtime = 0
        
        # Single stat call to find active ECM file quickly
        for p in self._ecm_paths:
            try:
                fstat = os.stat(p)
                current_path = p
                mtime = fstat.st_mtime
                break
            except OSError:
                pass

        ecm_changed = False
        if current_path:
            if mtime != self._ecm_mtime or force:
                self._ecm_mtime = mtime
                self._ecm_path = current_path
                ecm_changed = True
        else:
            if self._ecm_path is not None:
                ecm_changed = True
                self._ecm_path = None
                self._ecm_mtime = 0

        cam_changed = False
        new_cam = self._detect_cam_name(force=False)
        if new_cam != self.cam_name:
            cam_changed = True

        # Assign new dictionary directly (atomic swap on GIL)
        if ecm_changed:
            new_ecm = self._parse_ecm_file(self._ecm_path) if self._ecm_path else {}
            self.ecm_data = new_ecm
        elif force and self._ecm_path:
            new_ecm = self._parse_ecm_file(self._ecm_path)
            self.ecm_data = new_ecm

        if cam_changed:
            self.cam_name = new_cam

_background_reader = _BackgroundReader()


# ============================================================================
#  iAccess Converter
# ============================================================================
class iAccess(Converter):
    CAID = 0
    PID = 1
    BETACAS = 2
    IRDCAS = 3
    SECACAS = 4
    VIACAS = 5
    NAGRACAS = 6
    CRWCAS = 7
    NDSCAS = 8
    CONAXCAS = 9
    DRCCAS = 10
    BISSCAS = 11
    BULCAS = 12
    VMXCAS = 13
    PWVCAS = 14
    TBGCAS = 15
    TGFCAS = 16
    PANCAS = 17
    EXSCAS = 18
    CGDCAS = 19
    VCRCAS = 20
    BETAECM = 21
    IRDECM = 22
    SECAECM = 23
    VIAECM = 24
    NAGRAECM = 25
    CRWECM = 26
    NDSECM = 27
    CONAXECM = 28
    DRCECM = 29
    BISSECM = 30
    BULECM = 31
    VMXECM = 32
    PWVECM = 33
    TBGECM = 34
    TGFECM = 35
    PANECM = 36
    EXSECM = 37
    CGDECM = 38
    VCRECM = 39
    RUSCAS = 40
    CODICAS = 41
    AGTCAS = 42
    SAMCAS = 43
    CAIDINFO = 44
    PROV = 45
    NET = 46
    EMU = 47
    CRD = 48
    CRDTXT = 49
    FTA = 50
    CACHE = 51
    CRYPTINFO = 52
    CAMNAME = 53
    ADDRESS = 54
    ECMTIME = 55
    FORMAT = 56
    ECMINFO = 57
    SHORTINFO = 58
    CASINFO = 59
    ISCRYPTED = 60
    VIDEOBITRATE = 61
    AUDIOBITRATE = 62
    VTYPE = 63
    CW0 = 64
    CW1 = 65
    OPBITRATE = 66
    STREAMURL = 67
    SMARTACCESS = 68
    ECMINFOSHORT2 = 69
    SERVERADDRESS = 70
    PROVIDERNAME = 71
    CAIDSHORT = 72
    CAIDFULL = 73
    ECMTIMESHORT = 74
    CRYPTOBAR = 75

    def __init__(self, type):
        Converter.__init__(self, type)

        if type and ("%V" in type or "%A" in type):
            self.type = self.OPBITRATE
            self._init_opbitrate(type)
            return

        type_map = {
            "CaID": self.CAID, "Pid": self.PID, "BetaCaS": self.BETACAS, "IrdCaS": self.IRDCAS,
            "SecaCaS": self.SECACAS, "ViaCaS": self.VIACAS, "NagraCaS": self.NAGRACAS, "CrwCaS": self.CRWCAS,
            "NdsCaS": self.NDSCAS, "ConaxCaS": self.CONAXCAS, "DrcCaS": self.DRCCAS, "BissCaS": self.BISSCAS,
            "BulCaS": self.BULCAS, "VmxCaS": self.VMXCAS, "PwvCaS": self.PWVCAS, "TbgCaS": self.TBGCAS,
            "TgfCaS": self.TGFCAS, "PanCaS": self.PANCAS, "ExsCaS": self.EXSCAS, "RusCaS": self.RUSCAS,
            "BetaEcm": self.BETAECM, "IrdEcm": self.IRDECM, "SecaEcm": self.SECAECM, "ViaEcm": self.VIAECM,
            "NagraEcm": self.NAGRAECM, "CrwEcm": self.CRWECM, "NdsEcm": self.NDSECM, "ConaxEcm": self.CONAXECM,
            "DrcEcm": self.DRCECM, "BissEcm": self.BISSECM, "BulEcm": self.BULECM, "VmxEcm": self.VMXECM,
            "PwvEcm": self.PWVECM, "TbgEcm": self.TBGECM, "TgfEcm": self.TGFECM, "PanEcm": self.PANECM,
            "ExsEcm": self.EXSECM, "CgdEcm": self.CGDECM, "VcrEcm": self.VCRECM, "CodiCaS": self.CODICAS,
            "CgdCaS": self.CGDCAS, "VcrCaS": self.VCRCAS, "AgtCaS": self.AGTCAS, "SamCaS": self.SAMCAS,
            "CaidInfo": self.CAIDINFO, "ProvID": self.PROV, "Net": self.NET, "Emu": self.EMU,
            "Crd": self.CRD, "CrdTxt": self.CRDTXT, "Fta": self.FTA, "Cache": self.CACHE,
            "CryptInfo": self.CRYPTINFO, "CamName": self.CAMNAME, "Address": self.ADDRESS,
            "EcmTime": self.ECMTIME, "IsCrypted": self.ISCRYPTED, "ShortInfo": self.SHORTINFO,
            "CasInfo": self.CASINFO, "EcmInfo": self.ECMINFO, "Default": self.ECMINFO, "": self.ECMINFO,
            "Ecm": self.ECMINFO, "emuname": self.CAMNAME, "emuFullName": self.CAMNAME, "VType": self.VTYPE,
            "CW0": self.CW0, "Cw0": self.CW0, "CW1": self.CW1, "Cw1": self.CW1, "StreamUrl": self.STREAMURL,
            "SmartAccess": self.SMARTACCESS, "VideoBitrate": self.VIDEOBITRATE, "AudioBitrate": self.AUDIOBITRATE,
            "CaidShort": self.CAIDSHORT, "CaidFull": self.CAIDFULL, "EcmTimeShort": self.ECMTIMESHORT,
            "EcmInfoShort2": self.ECMINFOSHORT2, "ServerAddress": self.SERVERADDRESS, "ProviderName": self.PROVIDERNAME,
            "BetaCrypt": self.BETACAS, "ConaxCrypt": self.CONAXCAS, "CrwCrypt": self.CRWCAS, "DreamCrypt": self.DRCCAS,
            "ExsCrypt": self.EXSCAS, "IrdCrypt": self.IRDCAS, "NagraCrypt": self.NAGRACAS, "NdsCrypt": self.NDSCAS,
            "SecaCrypt": self.SECACAS, "ViaCrypt": self.VIACAS, "PwuCrypt": self.PWVCAS, "VrmCrypt": self.VMXCAS,
            "TanCrypt": self.TBGCAS, "BetaEcm2": self.BETAECM, "ConaxEcm2": self.CONAXECM, "Delay": self.ECMTIME,
            "Host": self.ADDRESS, "Short": self.SHORTINFO, "IS_FTA": self.FTA, "IS_CRYPTED": self.ISCRYPTED,
            "CryptoBar": self.CRYPTOBAR
        }

        if type in type_map:
            self.type = type_map[type]
        else:
            self.type = self.FORMAT
            self.sfmt = type[:] if type else ""

        self.video_bitrate_calc = None
        self.audio_bitrate_calc = None
        self._bitrate_video_val = 0
        self._bitrate_audio_val = 0
        self._bitrate_init_timer = None
        if self.type in (self.VIDEOBITRATE, self.AUDIOBITRATE):
            if _BITRATECALC_AVAILABLE:
                try:
                    from enigma import eTimer
                    self._bitrate_init_timer = eTimer()
                    self._bitrate_init_timer.callback.append(self._init_bitrate_calc)
                except Exception:
                    pass

    def _init_bitrate_calc(self):
        try:
            service = self.source.service if hasattr(self, "source") and self.source else None
            if not service or eBitrateCalculator is None:
                return
            serviceInfo = service.info()
            if not serviceInfo:
                return
            vpid = serviceInfo.getInfo(iServiceInformation.sVideoPID)
            apid = serviceInfo.getInfo(iServiceInformation.sAudioPID)
            tsid = serviceInfo.getInfo(iServiceInformation.sTSID)
            onid = serviceInfo.getInfo(iServiceInformation.sONID)
            dvbnamespace = serviceInfo.getInfo(iServiceInformation.sNamespace)
            if self.type == self.VIDEOBITRATE and vpid and vpid > 0:
                self.video_bitrate_calc = eBitrateCalculator(vpid, dvbnamespace, tsid, onid, 1000, 1024 * 1024)
                self.video_bitrate_calc.callback.append(self._got_video_bitrate)
            elif self.type == self.AUDIOBITRATE and apid and apid > 0:
                self.audio_bitrate_calc = eBitrateCalculator(apid, dvbnamespace, tsid, onid, 1000, 64 * 1024)
                self.audio_bitrate_calc.callback.append(self._got_audio_bitrate)
        except Exception:
            pass

    def _got_video_bitrate(self, value, status):
        self._bitrate_video_val = value if status else 0
        if not status:
            self.video_bitrate_calc = None
        self.changed((self.CHANGED_POLL,))

    def _got_audio_bitrate(self, value, status):
        self._bitrate_audio_val = value if status else 0
        if not status:
            self.audio_bitrate_calc = None
        self.changed((self.CHANGED_POLL,))

    def _clear_bitrate_calc(self):
        self.video_bitrate_calc = None
        self.audio_bitrate_calc = None
        self._bitrate_video_val = 0
        self._bitrate_audio_val = 0

    def destroy(self):
        self.video_bitrate_calc = None
        self.audio_bitrate_calc = None
        self._bitrate_init_timer = None
        try:
            if getattr(self, "_ob_container", None) is not None:
                self._ob_container.kill()
                self._ob_container = None
        except Exception:
            pass
        try:
            Converter.destroy(self)
        except Exception:
            pass

    def _init_opbitrate(self, raw_type):
        self.poll_interval = 1000
        self.poll_enabled = True
        self.sfmt = raw_type
        self._ob_retval = raw_type.replace("%V", "N/A").replace("%A", "N/A")
        self._ob_running = False
        self._ob_exec_started_at = 0
        self._ob_current_pids = None
        self._ob_container = None
        self._ob_video_history = deque(maxlen=_OPBITRATE_AVERAGE_WINDOW)
        self._ob_last_audio = None
        self._ob_current_apid = -1
        if _OPBITRATE_PATH is None or eConsoleAppContainer is None:
            return
        try:
            self._ob_container = eConsoleAppContainer()
            self._ob_container.dataAvail.append(self._ob_dataAvail)
            self._ob_container.appClosed.append(self._ob_onAppClosed)
        except Exception:
            self._ob_container = None

    def _ob_dataAvail(self, data):
        try:
            if isinstance(data, bytes):
                data_str = data.decode("utf-8", errors="replace").strip()
            else:
                data_str = str(data).strip()
            parts = data_str.split()
            if len(parts) != 2:
                return
            video_val = float(parts[0])
            audio_val = float(parts[1])

            self._ob_video_history.append(video_val)
            avg_v = sum(self._ob_video_history) / len(self._ob_video_history) if self._ob_video_history else 0
            video_str = "%.1f" % avg_v

            if self._ob_current_apid == -1:
                audio_str = "N/A"
            else:
                if audio_val > 0:
                    self._ob_last_audio = audio_val
                audio_str = "%.1f" % self._ob_last_audio if self._ob_last_audio is not None else "N/A"

            self._ob_retval = self.sfmt.replace("%A", audio_str).replace("%V", video_str)
            self.changed((self.CHANGED_POLL,))
        except Exception:
            pass

    def _ob_onAppClosed(self, retval):
        self._ob_running = False
        self._ob_current_pids = None

    def _ob_isActuallyRunning(self):
        if not self._ob_running:
            return False
        if self._ob_container is not None and hasattr(self._ob_container, "running"):
            try:
                if not self._ob_container.running():
                    self._ob_running = False
                    self._ob_current_pids = None
                    return False
            except Exception:
                pass
        if time.time() - self._ob_exec_started_at > _OPBITRATE_STUCK_TIMEOUT:
            try:
                self._ob_container.kill()
            except Exception:
                pass
            self._ob_running = False
            self._ob_current_pids = None
            return False
        return True

    def _opbitrate_text(self):
        if _OPBITRATE_PATH is None or self._ob_container is None:
            return self._ob_retval
        try:
            service_obj = getattr(self.source, "service", None)
            if not service_obj:
                if NavigationInstance.instance is not None:
                    ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                    if ref:
                        service_obj = NavigationInstance.instance.getService(ref)
            if not service_obj:
                return self._ob_retval
            serviceInfo = service_obj.info()
            if not serviceInfo:
                return self._ob_retval
            vpid = serviceInfo.getInfo(iServiceInformation.sVideoPID)
            apid = serviceInfo.getInfo(iServiceInformation.sAudioPID)
            stream = service_obj.stream()
            adapter, demux = 0, 0
            if stream:
                streamdata = stream.getStreamingData()
                if streamdata:
                    demux = streamdata.get("demux", 0)
                    adapter = streamdata.get("adapter", 0)
        except Exception:
            return self._ob_retval

        pids = (adapter, demux, vpid, apid)
        if self._ob_isActuallyRunning():
            if pids == self._ob_current_pids:
                return self._ob_retval
            try:
                self._ob_container.kill()
            except Exception:
                pass
            self._ob_running = False

        self._ob_current_apid = apid
        self._ob_video_history.clear()
        self._ob_last_audio = None

        cmd = "{} {} {} {} {}".format(_OPBITRATE_PATH, adapter, demux, vpid, apid)
        self._ob_running = True
        self._ob_exec_started_at = time.time()
        self._ob_current_pids = pids
        try:
            ret = self._ob_container.execute(cmd)
            if ret != 0:
                self._ob_running = False
                self._ob_current_pids = None
        except Exception:
            self._ob_running = False
            self._ob_current_pids = None

        return self._ob_retval

    def ecmfile(self):
        data, _ = _background_reader.get_data()
        return data

    def CamName(self):
        _, cam = _background_reader.get_data()
        return cam

    def int2hex(self, val):
        return "%x" % val

    def Caids(self):
        caids = []
        try:
            service = None
            if hasattr(self, "source") and self.source and hasattr(self.source, "service"):
                service = self.source.service
            elif NavigationInstance.instance is not None:
                ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                if ref:
                    service = NavigationInstance.instance.getService(ref)
            if service:
                info = service.info()
                if info:
                    caids = list(set(info.getInfoObject(iServiceInformation.sCAIDs)))
        except Exception:
            pass
        return sorted(caids)

    def CaidList(self):
        try:
            caids = self.Caids()
            if not caids:
                return ""
            if len(caids) > 1:
                return ", ".join(("{:04x}".format(x) for x in caids)).upper()
            return self.int2hex(caids[0]).upper().zfill(4)
        except Exception:
            return ""

    def CaidName(self):
        try:
            ecm_info = self.ecmfile()
            if ecm_info and "caid" in ecm_info:
                caidr = ("%0.4X" % int(ecm_info.get("caid", ""), 16))[:4]
                return _lookup_caid_name(caidr)
        except Exception:
            pass
        return ""

    def CaidNames(self):
        try:
            caids = [c.strip() for c in self.CaidList().split(",") if c.strip()]
            if not caids:
                return ""
            names = []
            for caid in caids:
                name = _lookup_caid_name(caid)
                if name:
                    names.append(name)
            return ", ".join(names)
        except Exception:
            return ""

    def CaidTxtList(self):
        try:
            caidnames = self.CaidNames()
            if not caidnames:
                return ""
            caid_list = [c.strip() for c in caidnames.split(",")]
            seen = []
            for ca in caid_list:
                if ca and ca not in seen:
                    seen.append(ca)
            if len(seen) > 1:
                return ", ".join(seen[:-1]) + " & " + seen[-1]
            elif seen:
                return seen[0]
        except Exception:
            pass
        return ""

    def CaidInfo(self):
        try:
            caids = self.CaidList()
            caidnames = self.CaidNames()
            if caids and caidnames:
                caidlist = "%s (%s)" % (caids, caidnames)
                try:
                    if config.osd.language.value == "el_GR":
                        return "Συστήματα κωδικοποίησης: " + caidlist
                except Exception:
                    pass
                return "Coding systems: " + caidlist
            try:
                if config.osd.language.value == "el_GR":
                    return "Χωρίς κωδικοποίηση ή αναγνωριστικό"
            except Exception:
                pass
            return "Free to air or no descriptor"
        except Exception:
            return "Free to air or no descriptor"

    def ecmpath(self):
        for p in ("/tmp/ecm7.info", "/tmp/ecm6.info", "/tmp/ecm5.info", "/tmp/ecm4.info",
                  "/tmp/ecm3.info", "/tmp/ecm2.info", "/tmp/ecm1.info", "/tmp/ecm.info"):
            if os.path.exists(p):
                return p
        return None

    def _prettify_camname(self, raw):
        try:
            name = str(raw).strip() if raw else ""
            if name and name != "N/A":
                return name
            return "N/A"
        except Exception:
            return str(raw or "N/A")

    def getBoolean(self):
        try:
            if not _is_xdreamy_active():
                return False
            return self._getBoolean_impl()
        except Exception:
            return False

    def _getBoolean_impl(self):
        if self.type in (self.OPBITRATE, self.SMARTACCESS):
            return False
        ecm_info = self.ecmfile()
        protocol = str(ecm_info.get("protocol", ""))
        caids = [c.strip() for c in self.CaidList().split(",") if c.strip()]

        if self.type == self.FTA:
            if not caids and not ecm_info:
                return True
            elif ecm_info and "fta" in protocol:
                return True
            return False

        if self.type == self.ISCRYPTED:
            return bool(caids)

        if caids or ecm_info:
            cas_map = {
                self.BETACAS: lambda c: c in ("1702", "1722", "1762"),
                self.IRDCAS: lambda c: "0600" <= c <= "06FF",
                self.SECACAS: lambda c: "0100" <= c <= "01FF",
                self.VIACAS: lambda c: "0500" <= c <= "05FF",
                self.NAGRACAS: lambda c: "1800" <= c <= "18FF",
                self.CRWCAS: lambda c: "0D00" <= c <= "0DFF",
                self.NDSCAS: lambda c: "0900" <= c <= "09FF",
                self.CONAXCAS: lambda c: "0B00" <= c <= "0BFF",
                self.DRCCAS: lambda c: ("4A00" <= c <= "4AE9") or ("5000" <= c <= "50FF") or ("7BE0" <= c <= "7BE1") or ("0700" <= c <= "07FF") or ("4700" <= c <= "47FF"),
                self.BISSCAS: lambda c: "2600" <= c <= "26FF",
                self.BULCAS: lambda c: c in ("4AEE", "4AF8") or ("5581" <= c <= "55FF"),
                self.VMXCAS: lambda c: ("5600" <= c <= "5604") or ("1700" <= c <= "1701") or ("1703" <= c <= "1721") or ("1723" <= c <= "1761") or ("1763" <= c <= "17FF"),
                self.PWVCAS: lambda c: "0E00" <= c <= "0EFF",
                self.TBGCAS: lambda c: "1000" <= c <= "10FF",
                self.TGFCAS: lambda c: ("4B00" <= c <= "4B09") or c == "4AF6",
                self.PANCAS: lambda c: c == "4AFC",
                self.EXSCAS: lambda c: "2700" <= c <= "27FF",
                self.RUSCAS: lambda c: ("A100" <= c <= "A1FF") or c == "44A0",
                self.CODICAS: lambda c: "2200" <= c <= "22FF",
                self.CGDCAS: lambda c: c == "4AEA" or ("1EC0" <= c <= "1ECF"),
                self.VCRCAS: lambda c: c in ("5448", "7AC8"),
                self.AGTCAS: lambda c: "4800" <= c <= "48FF",
                self.SAMCAS: lambda c: c == "4B64"
            }
            if self.type in cas_map:
                check_fn = cas_map[self.type]
                for caid in caids:
                    if check_fn(caid):
                        return True
                return False

            if ecm_info:
                try:
                    caid = ("%0.4X" % int(ecm_info.get("caid", ""), 16))[:4]
                except Exception:
                    caid = ""
                ecm_cas_map = {
                    self.BETAECM: lambda c: c in ("1702", "1722", "1762"),
                    self.IRDECM: lambda c: "0600" <= c <= "06FF",
                    self.SECAECM: lambda c: "0100" <= c <= "01FF",
                    self.VIAECM: lambda c: "0500" <= c <= "05FF",
                    self.NAGRAECM: lambda c: "1800" <= c <= "18FF",
                    self.CRWECM: lambda c: ("0D00" <= c <= "0DFF") or ("4900" <= c <= "49FF"),
                    self.NDSECM: lambda c: "0900" <= c <= "09FF",
                    self.CONAXECM: lambda c: "0B00" <= c <= "0BFF",
                    self.DRCECM: lambda c: ("4A00" <= c <= "4AE9") or ("5000" <= c <= "50FF") or ("7BE0" <= c <= "7BE1") or ("0700" <= c <= "07FF") or ("4700" <= c <= "47FF"),
                    self.BISSECM: lambda c: "2600" <= c <= "26FF",
                    self.BULECM: lambda c: c in ("4AEE", "4AF8") or ("5581" <= c <= "55FF"),
                    self.VMXECM: lambda c: ("5600" <= c <= "5604") or ("1700" <= c <= "1701") or ("1703" <= c <= "1721") or ("1723" <= c <= "1761") or ("1763" <= c <= "17FF"),
                    self.PWVECM: lambda c: "0E00" <= c <= "0EFF",
                    self.TBGECM: lambda c: "1000" <= c <= "10FF",
                    self.TGFECM: lambda c: ("4B00" <= c <= "4B09") or c == "4AF6",
                    self.PANECM: lambda c: c == "4AFC",
                    self.EXSECM: lambda c: "2700" <= c <= "27FF",
                    self.CGDECM: lambda c: c == "4AEA" or ("1EC0" <= c <= "1ECF"),
                    self.VCRECM: lambda c: c in ("5448", "7AC8")
                }
                if self.type in ecm_cas_map:
                    return bool(caid and ecm_cas_map[self.type](caid))

                reader = str(ecm_info.get("reader", ""))
                frm = str(ecm_info.get("from", ""))
                using = str(ecm_info.get("using", ""))
                source = str(ecm_info.get("source", ""))
                try:
                    show_crypto = int(config.usage.show_cryptoinfo.value) > 0
                except Exception:
                    show_crypto = True

                if show_crypto:
                    if self.type == self.CRD:
                        return source == "sci" or (source != "cache" and source != "net" and "emu" not in source)
                    if self.type == self.CACHE:
                        return source == "cache" or reader == "Cache" or "cache" in frm
                    if self.type == self.EMU:
                        return (using == "emu" or source == "emu" or source == "card" or reader == "emu" or
                                "card" in source or "emu" in source or "biss" in source or "tb" in source or
                                "constant_cw" in reader or "constcw" in protocol or "static" in protocol)
                    if self.type == self.NET:
                        return (source == "net" and "unsupported" not in protocol and "cache" not in frm and
                                "static" not in protocol and "fta" not in protocol)
        return False

    boolean = property(getBoolean)

    def getText(self):
        try:
            if not _is_xdreamy_active():
                return ""
            return self._getText_impl()
        except Exception:
            return ""

    def _getText_impl(self):
        if self.type == self.CRYPTOBAR:
            return self._format_cryptobar_data()

        if self.type == self.OPBITRATE:
            return self._opbitrate_text()
        if self.type in (self.VIDEOBITRATE, self.AUDIOBITRATE):
            return self.getBitrate()
        if self.type == self.VTYPE:
            return self._vtype()
        if self.type == self.STREAMURL:
            return self._streamurl()
        if self.type == self.SMARTACCESS:
            return self._smartaccess()

        ecm_info = self.ecmfile()
        if self.type == self.CAIDSHORT:
            if ecm_info:
                try:
                    return ("%0.4X" % int(ecm_info.get("caid", ""), 16))[:4]
                except Exception:
                    pass
            return ""
        if self.type == self.CAIDFULL:
            caid = ""
            if ecm_info:
                try:
                    caid = ("%0.4X" % int(ecm_info.get("caid", ""), 16))[:4]
                except Exception:
                    pass
            name = _lookup_caid_name(caid) if caid else ""
            if caid and name:
                return "CAID: %s (%s)" % (caid, name)
            return "CAID: %s" % caid if caid else ""
        if self.type == self.ECMTIMESHORT:
            if ecm_info:
                ecm_time = ecm_info.get("ecm time", "")
                if "msec" in ecm_time:
                    return ecm_time.replace("msec", "ms").strip()
                return ecm_time.strip()
            return ""
        if self.type == self.ECMINFOSHORT2:
            if ecm_info:
                try:
                    caid = ("%0.4X" % int(ecm_info.get("caid", ""), 16))[:4]
                    prov = ("%0.6X" % int(ecm_info.get("prov", ""), 16))[:6] if ecm_info.get("prov") else ""
                    ecm_time = ecm_info.get("ecm time", "").replace("msec", "ms").strip()
                    return "%s:%s - %s" % (caid, prov, ecm_time)
                except Exception:
                    pass
            return ""
        if self.type == self.SERVERADDRESS:
            if ecm_info:
                server = ecm_info.get("server", "")
                port = ecm_info.get("port", "")
                if server and port:
                    return "%s:%s" % (server, port)
                return server or ""
            return ""
        if self.type == self.PROVIDERNAME:
            if ecm_info:
                return ecm_info.get("provider", "")
            return ""

        caidlist = self.CaidList()
        caidtxt = "hidden or custom"
        caidname = self.CaidName()
        ecmpath = self.ecmpath()
        service = self.source.service if hasattr(self, "source") and self.source else None

        if service:
            info = service.info() if service else None
            if self.type == self.CRYPTINFO:
                if ecmpath and os.path.exists(ecmpath):
                    return caidname if caidname else "Unknown CA Info"
                return "CA Info not available"
            if info:
                caids = list(set(info.getInfoObject(iServiceInformation.sCAIDs)))
                if self.type == self.CAMNAME:
                    return self._prettify_camname(self.CamName())
                if self.type == self.CAIDINFO:
                    return self.CaidInfo()
                if caids or ecm_info:
                    if len(caids) > 0:
                        caidtxt = self.CaidTxtList()
                    if ecm_info:
                        try:
                            caid = "%0.4X" % int(ecm_info.get("caid", ""), 16)
                        except Exception:
                            caid = ""
                        if self.type == self.CAID:
                            return caid
                        try:
                            pid = "%0.4X" % int(ecm_info.get("pid", ""), 16)
                        except Exception:
                            pid = ""
                        if self.type == self.PID:
                            return pid
                        try:
                            prov = "%0.6X" % int(ecm_info.get("prov", ""), 16)
                        except Exception:
                            prov = ecm_info.get("prov", "")
                        if self.type == self.PROV:
                            return prov

                        ecm_time_raw = ecm_info.get("ecm time", "")
                        if "msec" in ecm_time_raw:
                            ecm_time = ecm_time_raw.replace("msec", "ms")
                        else:
                            ecm_time = "%s ms" % ecm_time_raw.replace(".", "").lstrip("0")
                        if self.type == self.ECMTIME:
                            return ecm_time

                        csi = "Service with %s encryption" % caidtxt
                        casi = "Service with %s encryption (%s)" % (caidtxt, caidlist)
                        protocol = ecm_info.get("protocol", "")
                        port = ecm_info.get("port", "")
                        source = ecm_info.get("source", "")
                        server = ecm_info.get("server", "")
                        hops = ecm_info.get("hops", "")
                        if hops:
                            hops = " Hops: %s" % hops if hops > "0" else ""
                        system = ecm_info.get("system", "")
                        frm = ecm_info.get("from", "")
                        if len(frm) > 36:
                            frm = "%s..." % frm[:35]
                        provider = ecm_info.get("provider", "")
                        if provider:
                            provider = "Prov: " + provider
                        reader = ecm_info.get("reader", "")
                        if len(reader) > 36:
                            reader = "%s..." % reader[:35]
                        cw0 = ecm_info.get("cw0", "")
                        cw1 = ecm_info.get("cw1", "")

                        if self.type == self.CW0:
                            return cw0
                        if self.type == self.CW1:
                            return cw1
                        if self.type == self.CRDTXT:
                            if source == "sci" or (source != "cache" and source != "net" and "emu" not in source):
                                return "True"
                            return "False"
                        if self.type == self.ADDRESS:
                            return server
                        if self.type == self.FORMAT:
                            ecminfo = ""
                            params = self.sfmt.split(" ")
                            for param in params:
                                if param:
                                    if param[0] != "%":
                                        ecminfo += param
                                    elif param == "%S":
                                        ecminfo += server
                                    elif param == "%H":
                                        ecminfo += hops
                                    elif param == "%SY":
                                        ecminfo += system
                                    elif param == "%PV":
                                        ecminfo += provider
                                    elif param == "%SP":
                                        ecminfo += port
                                    elif param == "%PR":
                                        ecminfo += protocol
                                    elif param == "%C":
                                        ecminfo += caid
                                    elif param == "%P":
                                        ecminfo += pid
                                    elif param == "%p":
                                        ecminfo += prov
                                    elif param == "%O":
                                        ecminfo += source
                                    elif param == "%R":
                                        ecminfo += reader
                                    elif param == "%FR":
                                        ecminfo += frm
                                    elif param == "%T":
                                        ecminfo += ecm_time
                                    elif param == "%cw0":
                                        ecminfo += cw0
                                    elif param == "%cw1":
                                        ecminfo += cw1
                                    elif param == "%t":
                                        ecminfo += "\t"
                                    elif param == "%n":
                                        ecminfo += "\n"
                                    elif param[1:].isdigit():
                                        ecminfo = ecminfo.ljust(len(ecminfo) + int(param[1:]))
                                    if ecminfo and ecminfo[-1] not in ("\t", "\n"):
                                        ecminfo += " "
                            return ecminfo[:-1]

                        try:
                            show_crypto = int(config.usage.show_cryptoinfo.value) > 0
                        except Exception:
                            show_crypto = True

                        if self.type == self.ECMINFO:
                            if "fta" in protocol:
                                return "FTA service"
                            if show_crypto:
                                if source == "emu":
                                    return "CA: %s:%s  PID: %s  Source: %s@%s  Ecm Time: %s" % (caid, prov, pid, source, frm, ecm_time)
                                if reader and source == "net" and port:
                                    return "CA: %s:%s  PID: %s  Reader: %s@%s  Prtc: %s (%s)  Source: %s:%s %s  Ecm Time: %s  %s" % (caid, prov, pid, reader, frm, protocol, source, server, port, hops, ecm_time, provider)
                                if reader and source == "net" and "fta" not in protocol:
                                    return "CA: %s:%s  PID: %s  Reader: %s@%s  Prtc: %s (%s)  Source: %s %s  Ecm Time: %s  %s" % (caid, prov, pid, reader, frm, protocol, source, server, hops, ecm_time, provider)
                                if reader and source != "net":
                                    return "CA: %s:%s  PID: %s  Reader: %s@%s  Prtc: %s (local) - %s %s  Ecm Time: %s  %s" % (caid, prov, pid, reader, frm, protocol, source, hops, ecm_time, provider)
                                if not server and not port and protocol:
                                    return "CA: %s:%s  PID: %s  Prtc: %s (%s) %s Ecm Time: %s" % (caid, prov, pid, protocol, source, hops, ecm_time)
                                if not server and not port and not protocol:
                                    return "CA: %s:%s  PID: %s  Source: %s  Ecm Time: %s" % (caid, prov, pid, source, ecm_time)
                                return "CA: %s:%s  PID: %s  Addr: %s:%s  Prtc: %s (%s) %s  Ecm Time: %s  %s" % (caid, prov, pid, server, port, protocol, source, hops, ecm_time, provider)
                            return casi

                        if self.type == self.SHORTINFO:
                            if "fta" in protocol:
                                return "FTA service"
                            if show_crypto:
                                if source == "emu":
                                    return "%s:%s - %s - %s" % (caid, prov, source, caidname)
                                if not server and not port:
                                    return "%s:%s - %s - %s" % (caid, prov, source, ecm_time)
                                target = frm if reader else server
                                return "%s:%s - %s - %s" % (caid, prov, target, ecm_time)
                            return csi

                        if self.type == self.CASINFO:
                            if "fta" in protocol:
                                return "FTA service"
                            if show_crypto:
                                target = reader if reader else server
                                target_str = "%s@%s" % (target, hops.strip()) if hops.strip() else target
                                if source == "emu" or (not server and not port):
                                    return "%s [%s:%s - %s - %s]" % (csi, caid, prov, source, ecm_time)
                                return "%s [%s:%s - %s - %s]" % (csi, caid, prov, target_str, ecm_time)
                            return csi
                    elif self.type in (self.ECMINFO, self.SHORTINFO, self.CASINFO):
                        return "Service with %s encryption" % caidtxt
                elif self.type in (self.ECMINFO, self.SHORTINFO, self.CASINFO):
                    return "FTA service"
        return ""

    text = property(getText)

    def _format_cryptobar_data(self):
        try:
            from Tools.Hex2strColor import Hex2strColor
            from skin import parameters as skin_parameters
        except Exception:
            return ""

        ecm_data, _ = _background_reader.get_data()
        caid_str = ecm_data.get("caid", "0")
        current_caid = int(caid_str, 16) if caid_str else 0

        service = self.source.service if hasattr(self, "source") and self.source else None
        avail_caids = []
        if service:
            info = service.info()
            if info:
                avail_caids = info.getInfoObject(iServiceInformation.sCAIDs) or []

        colors = skin_parameters.get("PliExtraInfoColors", (0x0000FF00, 0x00FF0000, 0x00FFFFFF, 0x007F7F7F))
        col_active = Hex2strColor(colors[0])
        col_avail = Hex2strColor(colors[1])
        col_unavail = Hex2strColor(colors[2])
        col_reset = Hex2strColor(colors[3])

        res = []
        for cmin, cmax, name, short, longn, always in CAID_DATA:
            color = col_unavail
            if cmin <= current_caid <= cmax:
                color = col_active
            else:
                for caid in avail_caids:
                    if cmin <= caid <= cmax:
                        color = col_avail
                        break
            if color != col_unavail or always:
                res.append(color + short)

        return " ".join(res) + col_reset if res else ""

    def getBitrate(self):
        try:
            if not _BITRATECALC_AVAILABLE:
                return ""
            service = self.source.service if hasattr(self, "source") and self.source else None
            if not service:
                return ""
            calc = self.video_bitrate_calc if self.type == self.VIDEOBITRATE else self.audio_bitrate_calc
            if calc is None:
                if self._bitrate_init_timer is not None:
                    try:
                        self._bitrate_init_timer.start(500, True)
                    except Exception:
                        pass
                return ""
            val = self._bitrate_video_val if self.type == self.VIDEOBITRATE else self._bitrate_audio_val
            if val and val > 0:
                return "%.2f Mbit/s" % (val / 1000.0)
        except Exception:
            pass
        return ""

    def _streamurl(self):
        try:
            if NavigationInstance.instance is None:
                return ""
            playref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
            if not playref:
                return ""
            refstr = playref.toString()
            if "%3a" not in refstr:
                return ""
            decoded = refstr.replace("%3a", ":")
            idx = decoded.find("http://")
            if idx == -1:
                idx = decoded.find("https://")
            if idx == -1:
                return ""
            url = (decoded[idx:]
                   .replace("http://", "").replace("https://", "")
                   .split("/1:0:")[0].split("/")[0].split("@")[-1])
            if not url or url in ("", "0"):
                return ""
            if len(url) > 80:
                url = "%s..." % url[:79]
            return url
        except Exception:
            return ""

    def _smartaccess(self):
        try:
            service = self.source.service if hasattr(self, "source") and self.source else None
            info = service and service.info() if service else None
            is_crypted = bool(info and info.getInfo(iServiceInformation.sIsCrypted) == 1)

            if not is_crypted:
                return _("Free To Air")

            ecm_info = self.ecmfile()
            reader = str(ecm_info.get("reader", ""))
            frm = str(ecm_info.get("from", ""))
            using = str(ecm_info.get("using", ""))
            source = str(ecm_info.get("source", ""))
            protocol = str(ecm_info.get("protocol", ""))
            ecm_time = (ecm_info.get("ecm time", "") or "").replace("msec", "ms")
            caidname = self.CaidName()

            if source == "sci":
                return "%s %s" % (_("Local Card:"), caidname or _("Unknown"))

            if source == "cache" or reader == "Cache" or "cache" in frm:
                parts = [p for p in (_("Cached"), caidname) if p]
                return " | ".join(parts)

            if (using == "emu" or source == "emu" or source == "card" or reader == "emu"
                    or "card" in source or "emu" in source or "biss" in source or "tb" in source
                    or "constant_cw" in reader or "constcw" in protocol or "static" in protocol):
                name = self._prettify_camname(self.CamName())
                parts = [p for p in (name, caidname, ("%s" % ecm_time if ecm_time else "")) if p]
                return " | ".join(parts) if parts else _("Local Emulator")

            if source == "net":
                server = str(ecm_info.get("server", "")) or reader.split("@")[-1]
                parts = [p for p in (server, caidname, ("%s" % ecm_time if ecm_time else "")) if p]
                return " | ".join(parts) if parts else _("Network Server")

            return caidname or _("No Info")
        except Exception:
            return _("No Info")

    _VTYPE_MAP = {
        -1: "N/A", 0: "MPEG2", 1: "AVC", 2: "H263", 3: "VC1", 4: "MPEG4-VC",
        5: "VC1-SM", 6: "MPEG1", 7: "HEVC", 8: "VP8", 9: "VP9", 10: "XVID",
        11: "N/A", 12: "N/A", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5",
        16: "AVS", 17: "N/A", 18: "VP6", 19: "N/A", 20: "N/A", 21: "SPARK",
    }

    def _vtype(self):
        try:
            service = self.source.service if hasattr(self, "source") and self.source else None
            info = service and service.info() if service else None
            if not info:
                return " "
            return self._VTYPE_MAP.get(info.getInfo(iServiceInformation.sVideoType), "N/A")
        except Exception:
            return " "

    def changed(self, what):
        try:
            if what[0] == self.CHANGED_SPECIFIC:
                if what[1] in (iPlayableService.evStart, iPlayableService.evUpdatedInfo):
                    _background_reader.force_update()

            if self.type in (self.VIDEOBITRATE, self.AUDIOBITRATE) and self._bitrate_init_timer is not None:
                if what[0] == self.CHANGED_SPECIFIC and what[1] in (iPlayableService.evStart, iPlayableService.evUpdatedInfo):
                    self._bitrate_init_timer.start(500, True)
                elif what[0] == self.CHANGED_SPECIFIC and what[1] == iPlayableService.evEnd:
                    self._clear_bitrate_calc()

            Converter.changed(self, (self.CHANGED_POLL,))
        except Exception:
            pass

CAID_DATA = (
    (0x0100, 0x01FF, "Seca", "S", "SECA", True),
    (0x0500, 0x05FF, "Via", "V", "VIA", True),
    (0x0600, 0x06FF, "Irdeto", "I", "IRD", True),
    (0x0900, 0x09FF, "NDS", "Nd", "NDS", True),
    (0x0B00, 0x0BFF, "Conax", "Co", "CONAX", True),
    (0x0D00, 0x0DFF, "CryptoW", "Cw", "CRW", True),
    (0x0E00, 0x0EFF, "PowerVU", "P", "PV", False),
    (0x1000, 0x10FF, "Tandberg", "TB", "TAND", False),
    (0x1700, 0x17FF, "Beta", "B", "BETA", True),
    (0x1800, 0x18FF, "Nagra", "N", "NAGRA", True),
    (0x2600, 0x2600, "Biss", "Bi", "BiSS", False),
    (0x2700, 0x2710, "Dre3", "D3", "DRE3", False),
    (0x4AE0, 0x4AE1, "Dre", "D", "DRE", False),
    (0x4AEE, 0x4AEE, "BulCrypt", "B1", "BUL", False),
    (0x5581, 0x5581, "BulCrypt", "B2", "BUL", False),
    (0x4AF4, 0x4AF4, "PanAccess", "Pa", "PAN", False),
)