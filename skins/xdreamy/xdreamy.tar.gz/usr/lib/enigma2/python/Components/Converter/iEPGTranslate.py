# -*- coding: utf-8 -*-
# ============================================================================
#  iEPGTranslate.py  -  XDREAMY EPG translation converter (v8.8)
#  FIXED: _flush_batch() unpacking and inflight clearing.
#  ENHANCED: full EMC support – extracts both title and description.
# ============================================================================

import os
import time
import json
import sqlite3
import threading
import traceback
from collections import OrderedDict
from Components.Converter.Converter import Converter
from enigma import eTimer, iPlayableService

try:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode, quote
    from urllib.error import URLError, HTTPError
except ImportError:
    from urllib2 import Request, urlopen, URLError, HTTPError
    from urllib import urlencode, quote

# --- Debug ---
MODULE_NAME = "iEPGTranslate"
LOGFILE = "/tmp/%s_Debug.log" % MODULE_NAME

_debug_cache = {"enabled": False, "time": 0}
_DEBUG_CACHE_TTL = 1.0

def _debug_enabled():
    now = time.time()
    if now - _debug_cache["time"] < _DEBUG_CACHE_TTL:
        return _debug_cache["enabled"]
    try:
        from Components.config import config
        xd = config.plugins.xDreamy
        enabled = bool(xd.debug_master.value) and bool(getattr(xd, "dbg_%s" % MODULE_NAME).value)
    except Exception:
        enabled = False
    _debug_cache["enabled"] = enabled
    _debug_cache["time"] = now
    return enabled

def dbg(tag, msg):
    if _debug_enabled():
        line = "[iEPGTranslate][%s] %s" % (tag, msg)
        try:
            print(line)
        except Exception:
            pass
        try:
            with open(LOGFILE, "a") as f:
                f.write(line + "\n")
        except Exception:
            pass

def safe(tag, func, default=""):
    try:
        return func()
    except Exception:
        if _debug_enabled():
            dbg(tag, "EXCEPTION:\n%s" % traceback.format_exc())
        return default

# --- XDREAMY gate ---
XDREAMY_SKIN_MARKER = "xdreamy"
_xdreamy_cache = {"active": False, "time": 0}
_XDREAMY_TTL = 30.0

def _is_xdreamy_active():
    now = time.time()
    if now - _xdreamy_cache["time"] < _XDREAMY_TTL:
        return _xdreamy_cache["active"]
    try:
        from Components.config import config
        skin_path = str(config.skin.primary_skin.value or "")
        active = XDREAMY_SKIN_MARKER in skin_path.lower()
    except Exception:
        active = False
    _xdreamy_cache["active"] = active
    _xdreamy_cache["time"] = now
    return active

# --- Config loader ---
def _get_config():
    try:
        from Plugins.Extensions.xDreamy import plugin as xdreamy
        return xdreamy.config.plugins.xDreamy
    except Exception:
        return None

def _get_db_path():
    try:
        from Components.Renderer.iConverlibr import get_cache_path
        return get_cache_path("iMetaDataTranslate.db")
    except Exception:
        pass
    try:
        from Plugins.Extensions.xDreamy.plugin import _resolve_storage_path
        return os.path.join(_resolve_storage_path(), "iMetaDataTranslate.db")
    except Exception:
        return "/tmp/iMetaDataTranslate.db"

# ============================================================================
#  Tiny LRU cache (max 20 entries)
# ============================================================================
class _TinyLRU(object):
    def __init__(self, maxsize=20):
        self._cache = OrderedDict()
        self._maxsize = maxsize

    def get(self, key):
        if key not in self._cache:
            return None
        self._cache.move_to_end(key)
        return self._cache[key]

    def set(self, key, value):
        if key in self._cache:
            self._cache.move_to_end(key)
        elif len(self._cache) >= self._maxsize:
            self._cache.popitem(last=False)
        self._cache[key] = value

    def clear(self):
        self._cache.clear()

# ============================================================================
#  Main-thread result dispatcher
# ============================================================================
# NOTE: _flush_batch() fires from an eTimer callback, which runs on the main
# GUI thread - and the old code then called urlopen(...) SYNCHRONOUSLY right
# there (Google path), or did nothing at all (every other provider, via the
# _batch_individual() stub). Both problems are fixed by the same mechanism:
# the actual network request now always runs in a short-lived background
# thread. That thread must never touch Enigma2 GUI objects directly (this
# codebase has already hit "Enigma2 silently ignores UI calls off the main
# thread" before, in the renderer system) - so results are pushed onto a
# plain thread-safe queue instead, and a single dispatcher eTimer (created
# here, on the main thread, at import time - imports always happen on the
# main thread) drains that queue on its own tick and does the actual
# _save_translation()+redraw-notify work safely on the main thread.
_dispatch_queue = []
_dispatch_lock = threading.Lock()

def _dispatch_result(key, translated_text):
    with _dispatch_lock:
        _dispatch_queue.append((key, translated_text))

def _drain_dispatch_queue():
    with _dispatch_lock:
        if not _dispatch_queue:
            return
        items = _dispatch_queue[:]
        _dispatch_queue[:] = []
    any_saved = False
    for key, translated_text in items:
        if translated_text:
            iEPGTranslate._save_translation(key, translated_text)
            any_saved = True
    if any_saved:
        iEPGTranslate._notify_all_redraw()

_dispatch_timer = eTimer()
_dispatch_timer.callback.append(_drain_dispatch_queue)
_dispatch_timer.start(150, False)

# Quota cooldown for Gemini - avoids hammering a rate-limited endpoint with
# every subsequent EPG event once it's told us it's out of quota.
_gemini_cooldown_until = 0

# ============================================================================
#  RTL language support
# ============================================================================
# Enigma2's Label rendering doesn't always apply the full Unicode
# Bidirectional Algorithm correctly for mixed-direction text - a translated
# Arabic/Hebrew string that embeds a Latin channel name, a number, or
# punctuation can render with those fragments in the wrong visual position
# even though the underlying text is correct. Prepending U+200F (RIGHT-TO-
# LEFT MARK) is the standard, minimal fix: it tells the renderer the
# paragraph's base direction is RTL without altering the actual text
# content, so it round-trips through the cache/DB cleanly (stored raw,
# mark added only at display time - see getText()).
_RTL_LANG_CODES = frozenset(("ar", "he", "iw", "fa", "ur", "ps", "sd", "ug", "yi", "dv", "ku"))
_RTL_MARK = u"\u200f"

def _is_rtl_lang(lang):
    if not lang:
        return False
    try:
        return lang.strip().lower().split("-")[0] in _RTL_LANG_CODES
    except Exception:
        return False

def _apply_rtl_mark(text, lang):
    if not text or not _is_rtl_lang(lang):
        return text
    if text.startswith(_RTL_MARK):
        return text
    return _RTL_MARK + text

# ============================================================================
#  Main converter class – per‑instance timer
# ============================================================================
class iEPGTranslate(Converter):
    _db_conn = None
    _db_lock = threading.Lock()
    _ttl_seconds = 24 * 3600
    _tiny_cache = _TinyLRU(maxsize=20)
    _live_instances = []
    _live_lock = threading.Lock()
    _inflight = set()
    _inflight_lock = threading.Lock()

    # NOTE: batching state is CLASS-level (shared across every widget
    # instance), not per-instance. A live EPG grid can have dozens of
    # iEPGTranslate widgets on screen at once (title+description across many
    # rows). With per-instance batching, EACH widget fired its own
    # independent flush -> its own separate HTTP request to Google, even
    # though many of those texts could have been combined into one request.
    # Google's free translate endpoint allows roughly 5 requests/second - a
    # single busy-grid redraw could burst past that, and since nothing
    # backed off from Google specifically (only Gemini had a cooldown),
    # every subsequent flush kept hammering it the same way once rate-
    # limited. This is the documented, community-known cause of "EPG
    # translate stops working after a while" for Google-backed Enigma2
    # translators. Coalescing every instance into one shared batch means one
    # flush cycle combines everything currently pending, globally, into far
    # fewer and larger requests.
    _batch_pending = {}
    _batch_lock = threading.Lock()
    _batch_timer = None
    _timer_running = False
    _google_cooldown_until = 0

    def __init__(self, type):
        Converter.__init__(self, type)
        self.target_lang = None
        self.field = "name"
        self._redraw_timer = None
        self._cached_text = None
        self._cached_valid = False

        _xdreamy_ok_at_init = _is_xdreamy_active()
        if type:
            parts = type.split('|')
            if len(parts) > 0 and parts[0]:
                self.target_lang = parts[0]
            if len(parts) > 1 and parts[1]:
                self.field = parts[1]
        if _xdreamy_ok_at_init:
            self._redraw_timer = eTimer()
            self._redraw_timer.callback.append(self._onRedrawTimer)
            with self._live_lock:
                self._live_instances.append(self)

    # ---------- Live instance management ----------
    @classmethod
    def _notify_all_redraw(cls):
        with cls._live_lock:
            for inst_ref in cls._live_instances[:]:
                try:
                    if inst_ref._redraw_timer is not None:
                        inst_ref._redraw_timer.start(100, True)
                except Exception:
                    try:
                        cls._live_instances.remove(inst_ref)
                    except ValueError:
                        pass

    def destroy(self):
        try:
            self._redraw_timer.stop()
        except Exception:
            pass
        with self._live_lock:
            try:
                self._live_instances.remove(self)
            except ValueError:
                pass
        Converter.destroy(self)

    # ---------- Database helpers ----------
    @classmethod
    def _get_conn(cls):
        if cls._db_conn is None:
            path = _get_db_path()
            cls._db_conn = sqlite3.connect(path, timeout=10, check_same_thread=False)
            cls._db_conn.execute("PRAGMA journal_mode=WAL")
            cls._db_conn.execute("PRAGMA synchronous=NORMAL")
            cls._db_conn.execute(
                "CREATE TABLE IF NOT EXISTS translations ("
                "cache_key TEXT PRIMARY KEY, translated TEXT, timestamp REAL)")
            cls._db_conn.execute("PRAGMA wal_autocheckpoint=100")
            cls._db_conn.commit()
        return cls._db_conn

    @classmethod
    def _get_translation(cls, key):
        try:
            with cls._db_lock:
                conn = cls._get_conn()
                cur = conn.execute("SELECT translated, timestamp FROM translations WHERE cache_key=?", (key,))
                row = cur.fetchone()
                if row:
                    trans, ts = row
                    now = time.time()
                    if now - ts < cls._ttl_seconds:
                        cls._tiny_cache.set(key, trans)
                        return trans
                    else:
                        conn.execute("DELETE FROM translations WHERE cache_key=?", (key,))
                        conn.commit()
                        return None
                return None
        except Exception as e:
            dbg("db_lookup", "error for %s: %s" % (key, e))
            return None

    @classmethod
    def _save_translation(cls, key, translated_text):
        try:
            with cls._db_lock:
                conn = cls._get_conn()
                conn.execute(
                    "INSERT OR REPLACE INTO translations (cache_key, translated, timestamp) VALUES (?,?,?)",
                    (key, translated_text, time.time()))
                conn.commit()
                cls._tiny_cache.set(key, translated_text)
                dbg("db_save", "saved: %s" % key[:40])
        except Exception as e:
            dbg("db_save", "error: %s" % e)

    # ---------- Event handling ----------
    def changed(self, what):
        self._cached_valid = False
        if what[0] == self.CHANGED_SPECIFIC and what[1] == iPlayableService.evStart:
            with self._inflight_lock:
                self._inflight.clear()
        Converter.changed(self, what)

    # ---------- Enhanced event extraction for EMC and file services ----------
    def _get_emc_event_info(self, service):
        """
        Try to extract a human‑readable event name, short description,
        and extended description from an EMC‑like service object.
        Returns (name, short_desc, extended_desc) – each may be empty string.
        """
        name = ""
        short = ""
        extended = ""

        # Helper to safely call a method and return a non‑'<' string
        def safe_get(method_name):
            try:
                if hasattr(service, method_name):
                    val = getattr(service, method_name)()
                    if isinstance(val, str) and val and not val.startswith('<'):
                        return val
            except Exception:
                pass
            return ""

        # Try various methods for name
        for meth in ('getEventName', 'getName', 'getTitle', 'getDisplayName'):
            val = safe_get(meth)
            if val:
                name = val
                break

        # If we still don't have a name, try to extract from file path
        if not name:
            try:
                if hasattr(service, 'getPath'):
                    path = service.getPath()
                elif hasattr(service, 'toString'):
                    path = service.toString()
                else:
                    path = str(service)
                if path and (path.startswith('/') or path.startswith('file://') or path.startswith('movie:')):
                    if path.startswith('file://'):
                        path = path[7:]
                    elif path.startswith('movie:'):
                        path = path[6:]
                    basename = os.path.basename(path)
                    name, ext = os.path.splitext(basename)
                    name = name.strip().replace('_', ' ')
            except Exception:
                pass

        # Try to get short description
        for meth in ('getShortDescription', 'getDescription', 'getSubtitle', 'getSynopsis'):
            val = safe_get(meth)
            if val:
                short = val
                break

        # Try to get extended description
        for meth in ('getExtendedDescription', 'getLongDescription', 'getFullDescription'):
            val = safe_get(meth)
            if val:
                extended = val
                break

        # If we have an 'event' attribute, try to get description from it
        try:
            event = getattr(service, 'event', None)
            if event is not None:
                if not short:
                    if hasattr(event, 'getShortDescription'):
                        short = event.getShortDescription() or ""
                if not extended:
                    if hasattr(event, 'getExtendedDescription'):
                        extended = event.getExtendedDescription() or ""
        except Exception:
            pass

        # If short is empty but extended isn't, use extended as short (or vice versa)
        if not short and extended:
            short = extended
        elif not extended and short:
            extended = short

        # Strip any '<' strings
        if name and name.startswith('<'):
            name = ""
        if short and short.startswith('<'):
            short = ""
        if extended and extended.startswith('<'):
            extended = ""

        dbg("emc_info", "name='%s' short='%s' extended='%s'" % (name, short[:40], extended[:40]))
        return name, short, extended

    def _get_event(self):
        src = self.source
        if src is None:
            return None

        # --- Try to get full event info from EMC/file service ---
        name, short, extended = self._get_emc_event_info(src)
        if name:
            # Build a dummy event that provides all three fields
            class DummyEvent:
                def getEventName(self):
                    return name
                def getShortDescription(self):
                    return short
                def getExtendedDescription(self):
                    return extended
            return DummyEvent()

        # --- Standard event detection ---
        event = getattr(src, 'event', None)
        if event is not None:
            return event
        if hasattr(src, 'getEventName'):
            return src

        # Fallback to navigation instance
        try:
            from NavigationInstance import instance as nav_instance
            service = None
            if hasattr(src, 'getCurrentServiceEnhanced'):
                service = src.getCurrentServiceEnhanced()
            elif nav_instance is not None:
                service = nav_instance.getCurrentService()
            if service is not None:
                info = service.info()
                if info is not None:
                    return info.getEvent(0)
        except Exception:
            pass
        return None

    def _onRedrawTimer(self):
        try:
            self.changed((self.CHANGED_ALL,))
        except Exception as e:
            dbg("redraw", "failed: %s" % e)

    # ---------- Language detection ----------
    def _detect_language(self, text):
        if not text:
            return "en"
        for ch in text[:200]:
            code = ord(ch)
            if 0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F:
                return "ar"
            if 0x0400 <= code <= 0x04FF or 0x0500 <= code <= 0x052F:
                return "ru"
            if 0x4E00 <= code <= 0x9FFF or 0x3400 <= code <= 0x4DBF:
                return "zh"
            if 0x3040 <= code <= 0x309F or 0x30A0 <= code <= 0x30FF:
                return "ja"
            if 0xAC00 <= code <= 0xD7AF or 0x1100 <= code <= 0x11FF:
                return "ko"
            if 0x0590 <= code <= 0x05FF:
                return "he"
            if 0x0370 <= code <= 0x03FF:
                return "el"
            if 0x0100 <= code <= 0x017F or 0x0180 <= code <= 0x024F:
                return "pl"
            if 0x0E00 <= code <= 0x0E7F:
                return "th"
        return "en"

    # ---------- Batch translation ----------
    @classmethod
    def _flush_batch(cls):
        # This runs on the main GUI thread (eTimer callback). It must do
        # nothing but hand the work off - see the module-level dispatcher
        # note above for why the actual requests happen in a background
        # thread instead of here.
        cls._timer_running = False
        with cls._batch_lock:
            if not cls._batch_pending:
                return
            items = list(cls._batch_pending.items())
            cls._batch_pending.clear()

        t = threading.Thread(target=cls._run_batch_worker, args=(items,))
        t.daemon = True
        t.start()

    @classmethod
    def _run_batch_worker(cls, items):
        # Runs entirely in a background thread. No Enigma2 GUI object is
        # touched here - results go through _dispatch_result() into the
        # thread-safe queue the main-thread timer drains.
        # items is a list of (key, (text, target_lang, provider, callback))
        groups = {}
        for key, (text, target_lang, provider, callback) in items:
            groups.setdefault((provider, target_lang), []).append((key, text, callback))

        for (provider, target_lang), batch in groups.items():
            if provider == "google":
                cls._batch_google(batch, target_lang)
            elif provider == "gemini":
                for key, text, callback in batch:
                    cls._batch_gemini(key, text, target_lang)
            elif provider == "groq":
                for key, text, callback in batch:
                    cls._batch_groq(key, text, target_lang)
            else:
                dbg("batch_worker", "unknown provider %r - no translation performed" % provider)

        with cls._inflight_lock:
            for key, _ in items:   # each item is (key, value)
                cls._inflight.discard(key)

    @classmethod
    def _batch_google(cls, batch, target_lang):
        # NOTE: Google's free translate endpoint allows roughly 5 req/s.
        # Previously nothing backed off here (only Gemini had a cooldown),
        # so once a busy screen tripped the rate limit, every subsequent
        # flush kept hammering the same endpoint the same way - this is the
        # confirmed, community-documented cause of "translation stops
        # working after a while" for Google-backed EPG translators. Shared
        # class-level batching (see class docstring above) already reduces
        # how often this can happen; this cooldown handles it gracefully
        # the rest of the time.
        now = time.time()
        if now < cls._google_cooldown_until:
            dbg("batch_google", "in rate-limit cooldown for %.0fs more - skipping" % (cls._google_cooldown_until - now))
            return
        params = [('client', 'gtx'), ('sl', 'auto'), ('tl', target_lang), ('dt', 't')]
        for _, text, _ in batch:
            params.append(('q', text))
        data = urlencode(params).encode('utf-8')
        try:
            req = Request("https://translate.googleapis.com/translate_a/single", data=data,
                          headers={"User-Agent": "Mozilla/5.0",
                                   "Content-Type": "application/x-www-form-urlencoded"})
            resp = urlopen(req, timeout=10)
            raw = resp.read().decode('utf-8')
            json_data = json.loads(raw)
            translations = []
            for item in json_data[0]:
                if isinstance(item, list) and len(item) > 0 and item[0]:
                    translations.append(item[0])
            for (key, _, _), trans in zip(batch, translations):
                if trans:
                    _dispatch_result(key, trans)
        except HTTPError as e:
            if e.code == 429:
                cls._google_cooldown_until = time.time() + 60
                dbg("batch_google", "rate-limited (429) - cooling down 60s")
            else:
                dbg("batch_google", "HTTP %s" % e.code)
        except URLError as e:
            dbg("batch_google", "Network: %s" % e.reason)
        except Exception as e:
            dbg("batch_google", "Unexpected: %s" % e)

    @classmethod
    def _batch_gemini(cls, key, text, target_lang):
        # NOTE: this used to route through _batch_individual(), a stub that
        # only logged a debug line and discarded the in-flight marker - no
        # request was ever made. This is a real implementation.
        cfg = _get_config()
        if cfg is None:
            return
        try:
            api_key = (cfg.epg_translate_gemini_api_key.value or "").strip()
        except Exception:
            api_key = ""
        if not api_key:
            dbg("batch_gemini", "no API key configured - skipping")
            return

        global _gemini_cooldown_until
        now = time.time()
        if now < _gemini_cooldown_until:
            dbg("batch_gemini", "in quota cooldown for %.0fs more - skipping" % (_gemini_cooldown_until - now))
            return

        try:
            model = cfg.epg_translate_gemini_model.value or "gemini-1.5-flash"
        except Exception:
            model = "gemini-1.5-flash"

        try:
            url = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s" % (model, quote(api_key))
            prompt = ("Translate the following text to language code '%s'. "
                      "Output ONLY the translation, no explanations, no quotes:\n\n%s" % (target_lang, text))
            body = json.dumps({"contents": [{"parts": [{"text": prompt}]}]}).encode('utf-8')
            req = Request(url, data=body, headers={"Content-Type": "application/json"})
            resp = urlopen(req, timeout=10)
            data = json.loads(resp.read().decode('utf-8'))
            translated = data["candidates"][0]["content"]["parts"][0]["text"].strip()
            if translated:
                _dispatch_result(key, translated)
        except HTTPError as e:
            if e.code == 429:
                # Quota exceeded - back off for a while instead of hammering
                # a rate-limited endpoint on every subsequent EPG event.
                _gemini_cooldown_until = time.time() + 60
                dbg("batch_gemini", "quota exceeded (429) - cooling down 60s")
            else:
                dbg("batch_gemini", "HTTP %s" % e.code)
        except URLError as e:
            dbg("batch_gemini", "Network: %s" % e.reason)
        except Exception as e:
            dbg("batch_gemini", "Unexpected: %s" % e)

    @classmethod
    def _batch_groq(cls, key, text, target_lang):
        # NOTE: same as Gemini above - previously routed through the
        # _batch_individual() stub and never actually called Groq.
        cfg = _get_config()
        if cfg is None:
            return
        try:
            api_key = (cfg.epg_translate_groq_api_key.value or "").strip()
        except Exception:
            api_key = ""
        if not api_key:
            dbg("batch_groq", "no API key configured - skipping")
            return
        try:
            model = cfg.epg_translate_groq_model.value or "llama-3.1-8b-instant"
        except Exception:
            model = "llama-3.1-8b-instant"

        try:
            body = json.dumps({
                "model": model,
                "messages": [
                    {"role": "system", "content": "You are a translation engine. Translate the user's text to language code '%s'. Output only the translation, nothing else." % target_lang},
                    {"role": "user", "content": text},
                ],
                "temperature": 0.2,
            }).encode('utf-8')
            req = Request("https://api.groq.com/openai/v1/chat/completions", data=body, headers={
                "Content-Type": "application/json",
                "Authorization": "Bearer %s" % api_key,
                # Groq's API sits behind Cloudflare, which blocks the
                # default urllib User-Agent - a real browser UA is required
                # or every request gets rejected before it reaches Groq.
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
            })
            resp = urlopen(req, timeout=10)
            data = json.loads(resp.read().decode('utf-8'))
            translated = data["choices"][0]["message"]["content"].strip()
            if translated:
                _dispatch_result(key, translated)
        except HTTPError as e:
            dbg("batch_groq", "HTTP %s" % e.code)
        except URLError as e:
            dbg("batch_groq", "Network: %s" % e.reason)
        except Exception as e:
            dbg("batch_groq", "Unexpected: %s" % e)

    # ---------- getText ----------
    def getText(self):
        if not _is_xdreamy_active():
            return ""

        cfg = _get_config()
        if cfg is None:
            return self._get_original_text()

        try:
            enabled = cfg.epg_translate_enabled.value
        except Exception:
            return self._get_original_text()

        if not enabled:
            return self._get_original_text()

        if self._cached_valid:
            return self._cached_text

        event = self._get_event()
        if event is None:
            return ""
        raw_text = self._extract_text(event)
        if not raw_text:
            return ""

        provider = cfg.epg_translate_provider.value
        target_lang = self.target_lang or cfg.epg_translate_target_lang.value

        # No "auto"
        if not target_lang or target_lang == "auto":
            return raw_text

        ttl_hours = int(cfg.epg_translate_cache_ttl.value or 24)
        self._ttl_seconds = ttl_hours * 3600

        cache_key = "{}_{}_{}".format(provider, target_lang, raw_text)

        # 1. Tiny LRU
        cached = self._tiny_cache.get(cache_key)
        if cached is not None:
            self._cached_text = _apply_rtl_mark(cached, target_lang)
            self._cached_valid = True
            return self._cached_text

        # 2. SQLite
        cached = self._get_translation(cache_key)
        if cached is not None:
            self._cached_text = _apply_rtl_mark(cached, target_lang)
            self._cached_valid = True
            return self._cached_text

        # 3. Queue for translation
        self._start_translate(cache_key, raw_text, target_lang, provider, cfg)
        return raw_text

    def _start_translate(self, cache_key, text, target_lang, provider, cfg):
        cls = iEPGTranslate
        with cls._inflight_lock:
            if cache_key in cls._inflight:
                return
            cls._inflight.add(cache_key)

        with cls._batch_lock:
            cls._batch_pending[cache_key] = (text, target_lang, provider, None)

        if not cls._timer_running:
            cls._timer_running = True
            if cls._batch_timer is None:
                # Created lazily on first use rather than in __init__ - this
                # runs from getText(), always on the main GUI thread, so
                # it's safe to construct the eTimer here.
                cls._batch_timer = eTimer()
                cls._batch_timer.callback.append(cls._flush_batch)
            cls._batch_timer.start(200, True)

    def _get_original_text(self):
        event = self._get_event()
        if event is None:
            return ""
        return self._extract_text(event)

    def _extract_text(self, event):
        if self.field == "name":
            return event.getEventName() or ""
        elif self.field == "description":
            return event.getShortDescription() or ""
        elif self.field == "extended":
            return event.getExtendedDescription() or ""
        elif self.field == "full":
            name = event.getEventName() or ""
            desc = event.getShortDescription() or event.getExtendedDescription() or ""
            if name and desc:
                return "{}. {}".format(name, desc)
            return name or desc
        else:
            return event.getEventName() or ""

    text = property(getText)