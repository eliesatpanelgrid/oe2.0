#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iRendererBase.py - XDREAMY SKIN V7.1
Python 3 only. MIXIN for all renderers – shared context cache, reduced timeouts.
"""

import os
import threading

from enigma import eTimer, loadJPG, loadPNG
from Components.Sources.Event import Event

from .iConverlibr import (
    get_service_ref, detect_media, get_zap_context,
    get_event_source_metadata, register_nxts_slot, unregister_nxts_slot,
    register_widget_present, unregister_widget_present, register_metadata_callback,
    unregister_metadata_callback, get_state_store, has_useful_metadata,
    build_meta_dict, get_sidecar_path, file_exists_indexed,
)
from .iDownloadThread import (
    register_asset_callback, unregister_asset_callback, request_asset,
)
from .iDebugger import traced, warn

def parse_nxts_attribute(skin_attributes, default=0):
    """Shared parser for the 'nexts' skin attribute -- every renderer used
    to carry its own identical try/except int(value) block in applySkin."""
    for attrib, value in skin_attributes:
        if attrib == "nexts":
            try:
                return int(value)
            except Exception:
                return default
    return default

class PixmapCache(object):
    """Small capped pixmap cache shared by any renderer that needs to load
    JPG/PNG files from disk. Replaces near-identical per-file cache dicts
    that used to be duplicated in iPosterX.py and iBackdropX.py."""
    __slots__ = ("_cache", "_lock", "_max")

    def __init__(self, max_entries=50):
        self._cache = {}
        self._lock = threading.Lock()
        self._max = max_entries

    def get(self, path, is_png=False):
        if not path:
            return None
        with self._lock:
            pix = self._cache.get(path)
            if pix is not None:
                return pix
            try:
                pix = loadPNG(path) if is_png else loadJPG(path)
                if pix:
                    if len(self._cache) >= self._max:
                        self._cache.pop(next(iter(self._cache)))
                    self._cache[path] = pix
            except Exception:
                pix = None
            return pix

# ---------- REDUCED TIMEOUTS ----------
# These must comfortably exceed the worst-case legitimate round trip this
# timer actually covers: search (T_CONN+T_READ) -> detail fetch
# (T_CONN+T_READ) -> image download (T_CONN+T_IMG_PIC/LOGO), sequential,
# all defined in iDownloadThread.py. Poster/backdrop worst case is roughly
# 4.5+4.5+9.5=18.5s; logo roughly 4.5+4.5+5.5=14.5s. A shorter deadman
# doesn't make things feel faster -- the fallback image already shows
# immediately regardless of this timer -- it just means a legitimately
# slow (not broken) connection gets its in-flight request torn down and
# re-requested from scratch before it could ever finish, which is exactly
# the retry-storm failure mode this timer exists to prevent.
ASSET_DEADMAN_MS        = 20000
ASSET_DEADMAN_MS_BY_KIND = {
    "poster":   20000,
    "backdrop": 20000,
    "logo":     15000,
}

_sidecar_cache = {}
_SIDECAR_CACHE_MAX = 200
_SIDECAR_NONE = object()

# ---------- SHARED CONTEXT RESOLUTION CACHE ----------
_zap_resolution_cache = {}
_zap_resolution_lock = threading.Lock()
_zap_resolution_ref = None

def _get_cached_resolution(service, nxts):
    ref_str = service.toString() if service else None
    with _zap_resolution_lock:
        cache_key = (ref_str, nxts)
        cached = _zap_resolution_cache.get(cache_key)
        if cached:
            ctx, slot, gen = cached
            if ctx and ctx.is_valid_for(ref_str) and ctx.generation == gen:
                return ("epg", slot)
        return None

def _set_cached_resolution(service, nxts, ctx, slot):
    ref_str = service.toString() if service else None
    with _zap_resolution_lock:
        global _zap_resolution_ref
        if _zap_resolution_ref != ref_str:
            _zap_resolution_cache.clear()
            _zap_resolution_ref = ref_str
        _zap_resolution_cache[(ref_str, nxts)] = (ctx, slot, ctx.generation if ctx else -1)

class RendererMixin(object):

    def __init__(self):
        self.nxts = 0
        self._old_key = None
        self._last_ref = None
        self._last_generation = -1

        # Single timer reused for asset-wait timeout
        self._timer = eTimer()
        self._timer.callback.append(self._timer_callback)
        self._timer_active = False
        self._timer_callback_data = None

        self._waiting = {}

        self._pending_meta_title = None
        self._pending_meta_cb = None

        self._registered_widget_kind = None
        self._registered_nxts_value = None

    def mixin_apply_skin(self, widget_kind=None):
        register_nxts_slot(self.nxts)
        self._registered_nxts_value = self.nxts
        if widget_kind:
            register_widget_present(widget_kind)
            self._registered_widget_kind = widget_kind

    def mixin_destroy(self):
        self._stop_timer()
        self._clear_all_waiting()
        self._clear_pending_metadata()
        if self._registered_nxts_value is not None:
            unregister_nxts_slot(self._registered_nxts_value)
            self._registered_nxts_value = None
        if self._registered_widget_kind:
            unregister_widget_present(self._registered_widget_kind)
            self._registered_widget_kind = None

    def mixin_clear(self):
        self._stop_timer()
        self._clear_all_waiting()
        self._clear_pending_metadata()
        self._old_key = None
        self._last_ref = None
        self._last_generation = -1

    def get_service_ref(self):
        return get_service_ref(self.source)

    def get_media_info(self):
        return detect_media(self.source)

    @traced("RendererMixin")
    def resolve_slot(self):
        # CRITICAL FIX: Check shared cache first
        service = self.get_service_ref()
        cached = _get_cached_resolution(service, self.nxts)
        if cached:
            return cached

        media = self.get_media_info()
        if media["is_media"]:
            result = ("media", media)
            _set_cached_resolution(service, self.nxts, None, media)
            return result

        if type(self.source) is Event and self.nxts == 0:
            slot = get_event_source_metadata(self.source)
            _set_cached_resolution(service, self.nxts, None, slot)
            return ("epg", slot)

        service = self.get_service_ref()
        if service is None:
            return ("no_service", None)

        ctx = get_zap_context(service)
        if ctx is None:
            return ("no_service", None)

        ref_str = ctx.ref_str
        if ref_str != self._last_ref:
            self._old_key = None
        if ref_str == self._last_ref and ctx.generation == self._last_generation:
            return ("same", None)
        self._last_ref = ref_str
        self._last_generation = ctx.generation

        slot = ctx.get_slot(self.nxts)
        if slot is None:
            if ctx.schedule_retry():
                # Retry scheduled – we'll get called again
                return ("epg", None)
            return ("no_service", None)

        _set_cached_resolution(service, self.nxts, ctx, slot)
        return ("epg", slot)

    def is_dedup(self, event_key):
        return bool(event_key) and self._old_key is not None and event_key == self._old_key

    def mark_shown(self, event_key):
        self._old_key = event_key

    def epg_slot_preamble(self, slot):
        """Common first steps every image-asset renderer does with an EPG
        slot before touching its own asset kind: skip check, dedup check,
        clean_title check. Returns (event_key, clean_title) on success, or
        None if the caller should show its empty/fallback state instead.
        The sport/news skip is already folded into slot['skip'] by
        ZapContext once per zap -- not re-derived here per widget."""
        if not slot or slot.get("skip"):
            return None
        event_key = slot.get("event_key", "")
        if self.is_dedup(event_key):
            return "same"
        clean_title = slot.get("clean_title", "")
        if not clean_title:
            return None
        return (event_key, clean_title)

    def priority_for(self, base_priority):
        """Scale a kind's base download priority by how far this widget's
        slot is from 'now' (self.nxts). A multi-event grid can have many
        widgets at different nxts values all requesting assets around the
        same time -- without this they'd all compete equally in the queue,
        so a background 'event 5 slots from now' item could delay the
        primary/current-event poster. Lower nxts means closer to what the
        user is actually looking at, so it keeps the caller's base
        priority; farther-out slots are pushed back, capped so a very deep
        grid doesn't starve entirely."""
        return base_priority + min(self.nxts, 4)

    # -------------------------------------------------------------------------
    # Shared timer management
    # -------------------------------------------------------------------------
    def _stop_timer(self):
        if self._timer_active:
            self._timer.stop()
            self._timer_active = False
            self._timer_callback_data = None

    def _schedule_timer(self, callback_data, delay_ms):
        self._stop_timer()
        self._timer_callback_data = callback_data
        self._timer_active = True
        self._timer.start(delay_ms, True)

    def _timer_callback(self):
        self._timer_active = False
        data = self._timer_callback_data
        self._timer_callback_data = None
        if not data:
            return
        kind, title = data if isinstance(data, tuple) else (data, None)
        if kind in ASSET_DEADMAN_MS_BY_KIND:
            if title and self._waiting.get(kind) == title:
                warn("RendererMixin", "asset-timeout", "kind=%s title=%s" % (kind, title))
                self._clear_waiting(kind)
                self.changed((self.CHANGED_DEFAULT,))

    # -------------------------------------------------------------------------
    # ASSET resolution – with priority
    # -------------------------------------------------------------------------
    def resolve_asset_for_display(self, slot, slot_key, folder_fn, ext, kind, clean_title, event_key, priority=1):
        path = slot.get(slot_key)
        folder = folder_fn()
        fname = clean_title + ext
        if path and not file_exists_indexed(folder, fname):
            path = None
            slot[slot_key] = None

        if not path:
            if file_exists_indexed(folder, fname):
                path = os.path.join(folder, fname)

        if path:
            if not slot.get(slot_key):
                slot[slot_key] = path
                store = get_state_store(False)
                store.set_record(clean_title, **{f"{kind}_ok": True})
            self.mark_shown(event_key)
            return path

        self.request_and_wait(kind, clean_title, slot.get("raw_name", ""),
                               slot.get("search_candidates"), emc_mode=False, priority=priority)
        return None

    def request_and_wait(self, kind, clean_title, raw_name, candidates, emc_mode=False, priority=5):
        if self._waiting.get(kind) == clean_title:
            return
        self._clear_waiting(kind)
        self._waiting[kind] = clean_title
        register_asset_callback(kind, clean_title, self)
        queued = request_asset(clean_title, kind, raw_name=raw_name,
                                candidates=candidates, emc_mode=emc_mode, priority=priority)
        if queued:
            delay = ASSET_DEADMAN_MS_BY_KIND.get(kind, ASSET_DEADMAN_MS)
            self._schedule_timer((kind, clean_title), delay)
        else:
            self._clear_waiting(kind)

    def on_asset_unavailable(self, kind, clean_title):
        if self._waiting.get(kind) == clean_title:
            self._clear_waiting(kind)

    def _clear_waiting(self, kind):
        title = self._waiting.pop(kind, None)
        if title:
            unregister_asset_callback(kind, title, self)
        if self._timer_active and self._timer_callback_data and self._timer_callback_data[0] == kind:
            self._stop_timer()

    def _clear_all_waiting(self):
        for kind in list(self._waiting.keys()):
            self._clear_waiting(kind)

    def handle_asset_ready(self, kind, clean_title, path):
        if self._waiting.get(kind) != clean_title:
            return False
        self._clear_waiting(kind)
        self._old_key = None
        self._last_ref = None
        self._last_generation = -1
        return True

    # -------------------------------------------------------------------------
    # METADATA handling
    # -------------------------------------------------------------------------
    def _clear_pending_metadata(self):
        if self._pending_meta_title:
            unregister_metadata_callback(self._pending_meta_title, self)
        self._pending_meta_title = None
        self._pending_meta_cb = None

    def wait_for_metadata(self, clean_title, on_ready):
        if clean_title == self._pending_meta_title:
            return
        self._clear_pending_metadata()
        self._pending_meta_title = clean_title
        register_metadata_callback(clean_title, self, "changed")

    def get_metadata_for(self, clean_title, emc_mode=False):
        if not clean_title:
            return None
        store = get_state_store(emc_mode)
        entry = store.get(clean_title) or {}
        if has_useful_metadata(entry):
            return build_meta_dict(entry)
        return None

    def get_sidecar_if_valid(self, movie_path, ext=".jpg", min_size=100):
        if not movie_path:
            return None
        key = (movie_path, ext)
        cached = _sidecar_cache.get(key)
        if cached is not None:
            return cached if cached != _SIDECAR_NONE else None
        sidecar = get_sidecar_path(movie_path, ext)
        result = None
        if sidecar and os.path.exists(sidecar):
            try:
                if os.path.getsize(sidecar) > min_size:
                    result = sidecar
            except Exception:
                pass
        if len(_sidecar_cache) >= _SIDECAR_CACHE_MAX:
            _sidecar_cache.pop(next(iter(_sidecar_cache)))
        _sidecar_cache[key] = result if result is not None else _SIDECAR_NONE
        return result

    # -------------------------------------------------------------------------
    # OPTIMIZED METADATA RESOLUTION
    # -------------------------------------------------------------------------
    def resolve_and_display_metadata(self, slot, emc_mode=False):
        if not slot or slot.get("skip"):
            return None

        clean_title = slot.get("clean_title", "")
        if not clean_title:
            return None

        if not emc_mode and slot.get("metadata_resolved"):
            return {
                "title": slot.get("title", ""),
                "parental": slot.get("parental", ""),
                "rating": slot.get("rating", 0),
                "plot": slot.get("plot", ""),
                "overview": slot.get("overview", ""),
                "year": slot.get("year", ""),
                "genres": slot.get("genres", ""),
                "director": slot.get("director", ""),
                "cast": slot.get("cast", ""),
                "country": slot.get("country", ""),
                "rated": slot.get("rated", ""),
                "imdb": slot.get("imdb", ""),
            }

        meta = self.get_metadata_for(clean_title, emc_mode)
        if meta:
            if not slot.get("metadata_resolved"):
                slot["metadata_resolved"] = True
                slot.update(meta)
            self.mark_shown(slot.get("event_key", ""))
            return meta

        self.wait_for_metadata(clean_title, None)
        return {
            "title": slot.get("raw_name", ""),
            "parental": "",
            "rating": 0,
            "plot": slot.get("description", ""),
            "overview": slot.get("description", ""),
            "year": "",
            "genres": "",
            "director": "",
            "cast": "",
            "country": "",
            "rated": "",
            "imdb": "",
        }
