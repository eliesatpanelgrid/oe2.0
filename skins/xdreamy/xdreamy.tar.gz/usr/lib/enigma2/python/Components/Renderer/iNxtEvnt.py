#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                              iNxtEvnt.py                                     ║
║                         XDREAMY SKIN V6.5.2 - 2026-01-20                     ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  EPG NEXT EVENTS DISPLAY RENDERER                                           ║
║  • Class-level EPG cache (shared across ALL widgets)                        ║
║  • Direct display, no timer                                                 ║
║  • Full color support                                                       ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  SKIN XML EXAMPLES:                                                          ║
║  <widget source="ServiceEvent" render="iNxtEvnt" nxtEvents="5"              ║
║           font="Regular;20" position="933,705" size="240,80" />             ║
║  <widget source="ServiceEvent" render="iNxtEvnt" snglEvent="1"              ║
║           font="Regular;20" position="933,705" size="240,80" />             ║
║  <widget source="ServiceEvent" render="iNxtEvnt" nxtEvents="5"              ║
║           timeColor="yellow" font="Regular;20" position="100,500"           ║
║           size="400,150" />                                                 ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from __future__ import absolute_import

from time import localtime, time
import threading

from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText
from enigma import eLabel, eEPGCache

EPG_LOOKUP = "IBDCT"
EPG_MINUTES = 1200


class iNxtEvnt(Renderer, VariableText):
    GUI_WIDGET = eLabel

    _epg_cache = {}
    _epg_cache_lock = threading.Lock()
    _epg_cache_time = 0
    _epg_cache_ref = None
    _epg_cache_ttl = 2
    _epg = eEPGCache.getInstance()

    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)
        self.nxEvnt = "0"
        self.snglEvnt = ""
        self.timeColor = ""
        self.currentColor = ""
        self.nextColor = ""

    @classmethod
    def _get_epg_events(cls, ref):
        if not ref:
            return []
        current_time = time()
        with cls._epg_cache_lock:
            if (cls._epg_cache_ref == ref and 
                current_time - cls._epg_cache_time < cls._epg_cache_ttl and 
                cls._epg_cache):
                return cls._epg_cache
        try:
            events = cls._epg.lookupEvent([EPG_LOOKUP, (ref.toString(), 0, -1, EPG_MINUTES)])
            if events:
                with cls._epg_cache_lock:
                    cls._epg_cache = events
                    cls._epg_cache_time = current_time
                    cls._epg_cache_ref = ref
                return events
        except:
            pass
        return []

    def applySkin(self, desktop, parent):
        attribs = self.skinAttributes[:]
        for attrib, value in self.skinAttributes:
            if attrib == 'nxtEvents':
                self.nxEvnt = value
            elif attrib == 'snglEvent':
                self.snglEvnt = value
            elif attrib == 'timeColor':
                self.timeColor = value.replace('0x', '')
            elif attrib == 'currentColor':
                self.currentColor = value.replace('0x', '')
            elif attrib == 'nextColor':
                self.nextColor = value.replace('0x', '')
        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    def _color(self, text, color):
        if not color or not text:
            return text
        return '#%s%s#%s' % (color, text, color)

    def changed(self, what):
        self.text = ''
        try:
            ref = self.source.service
            if not ref:
                return
            events = self._get_epg_events(ref)
            if not events:
                return

            if self.snglEvnt != "":
                idx = int(self.snglEvnt)
                if idx < len(events):
                    evnts = events[idx][4]
                    bt = localtime(events[idx][1])
                    time_str = "%02d:%02d" % (bt[3], bt[4])
                    colored_time = self._color(time_str, self.timeColor)
                    colored_title = self._color(evnts, self.currentColor if idx == 0 else self.nextColor)
                    self.text = "%s - %s\n" % (colored_time, colored_title)
                return

            if self.nxEvnt != "0":
                for i in range(int(self.nxEvnt)):
                    evnts = events[i+1][4]
                    bt = localtime(events[i+1][1])
                    time_str = "%02d:%02d" % (bt[3], bt[4])
                    colored_time = self._color(time_str, self.timeColor)
                    colored_title = self._color(evnts, self.nextColor)
                    self.text += "%s - %s\n" % (colored_time, colored_title)
                return

            if len(events) > 1:
                evnts = events[1][4]
                bt = localtime(events[1][1])
                time_str = "%02d:%02d" % (bt[3], bt[4])
                colored_time = self._color(time_str, self.timeColor)
                self.text = "%s - %s\n" % (colored_time, evnts)

        except Exception:
            self.text = ''