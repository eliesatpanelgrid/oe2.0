#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                              iNxtEvnt.py                                     ║
║                         XDREAMY SKIN V6.6.0 - 2026-06-08                     ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  EPG NEXT EVENTS DISPLAY RENDERER                                            ║
║  • Completely INDEPENDENT - No dependencies on iPosterX                      ║
║  • Uses built-in EPG cache (one lookup per channel)                          ║
║  • Direct EPG read - no title cleaning, no JSON                              ║
║  • Full color support (timeColor, currentColor, nextColor)                   ║
║  • Works even when iPosterX is disabled                                      ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from __future__ import absolute_import

from time import localtime
import threading
import time

from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText
from enigma import eLabel, eEPGCache


class iNxtEvnt(Renderer, VariableText):
    GUI_WIDGET = eLabel
    
    # ========================================================================
    # CLASS-LEVEL EPG CACHE (Shared across ALL iNxtEvnt widgets)
    # ========================================================================
    _epg_cache = {}
    _epg_cache_lock = threading.Lock()
    _epg_cache_time = 0
    _epg_cache_ref = None
    _epg_cache_ttl = 2  # 2 seconds cache
    _epg = eEPGCache.getInstance()
    
    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)
        self.nxEvnt = "0"
        self.snglEvnt = ""
        self.timeColor = ""
        self.currentColor = ""
        self.nextColor = ""

    @classmethod
    def _get_epg_events(cls, service_ref):
        """
        Get EPG events with class-level caching.
        ALL iNxtEvnt widgets share this cache - ONE EPG lookup per channel.
        Completely independent - uses only built-in eEPGCache.
        """
        if not service_ref:
            return []
        
        current_time = time.time()
        
        with cls._epg_cache_lock:
            # Return cached data if still fresh
            if (cls._epg_cache_ref == service_ref and 
                current_time - cls._epg_cache_time < cls._epg_cache_ttl and 
                cls._epg_cache):
                return cls._epg_cache
        
        # Cache miss - do fresh EPG lookup
        try:
            if cls._epg:
                events = cls._epg.lookupEvent(['IBOCTESX', (service_ref.toString(), 0, -1, -1)])
                if events:
                    with cls._epg_cache_lock:
                        cls._epg_cache = events
                        cls._epg_cache_time = current_time
                        cls._epg_cache_ref = service_ref
                    return events
        except Exception:
            pass
        
        return []

    def applySkin(self, desktop, parent):
        attribs = self.skinAttributes[:]
        for attrib, value in self.skinAttributes:
            if attrib == 'nxtEvents':
                self.nxEvnt = value
            elif attrib == 'snglEvent':
                self.snglEvnt = value
            elif attrib == 'timeColor':
                self.timeColor = value.replace('0x', '')
            elif attrib == 'currentColor':
                self.currentColor = value.replace('0x', '')
            elif attrib == 'nextColor':
                self.nextColor = value.replace('0x', '')
        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    def _color(self, text, color):
        if not color or not text:
            return text
        return '#%s%s#%s' % (color, text, color)

    def changed(self, what):
        """Main renderer entry point - displays EPG events from cache"""
        self.text = ''
        
        try:
            # Get service reference
            ref = self.source.service
            if not ref:
                return
            
            # Get EPG events (cached at class level)
            events = self._get_epg_events(ref)
            if not events:
                return

            # ============================================================
            # SINGLE EVENT MODE (snglEvent)
            # ============================================================
            if self.snglEvnt != "":
                idx = int(self.snglEvnt)
                if idx < len(events):
                    # Extract event data
                    event_title = events[idx][4]
                    begin_time = localtime(events[idx][1])
                    time_str = "%02d:%02d" % (begin_time[3], begin_time[4])
                    
                    # Apply colors
                    colored_time = self._color(time_str, self.timeColor)
                    if idx == 0:
                        colored_title = self._color(event_title, self.currentColor)
                    else:
                        colored_title = self._color(event_title, self.nextColor)
                    
                    self.text = colored_time + " - " + colored_title
                return

            # ============================================================
            # MULTIPLE EVENTS MODE (nxtEvents)
            # ============================================================
            if self.nxEvnt != "0":
                count = int(self.nxEvnt)
                lines = []
                
                # Start from index 1 (skip current event)
                for i in range(1, min(count + 1, len(events))):
                    event_title = events[i][4]
                    begin_time = localtime(events[i][1])
                    time_str = "%02d:%02d" % (begin_time[3], begin_time[4])
                    
                    # Apply colors
                    colored_time = self._color(time_str, self.timeColor)
                    colored_title = self._color(event_title, self.nextColor)
                    
                    lines.append(colored_time + " - " + colored_title)
                
                if lines:
                    self.text = "\n".join(lines)
                return

            # ============================================================
            # DEFAULT MODE (show next event only)
            # ============================================================
            if len(events) > 1:
                event_title = events[1][4]
                begin_time = localtime(events[1][1])
                time_str = "%02d:%02d" % (begin_time[3], begin_time[4])
                
                colored_time = self._color(time_str, self.timeColor)
                self.text = colored_time + " - " + event_title

        except Exception:
            self.text = ''