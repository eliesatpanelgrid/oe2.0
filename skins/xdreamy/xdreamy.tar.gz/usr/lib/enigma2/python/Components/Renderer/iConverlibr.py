#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                              iConverlibr.py                                  ║
║                         XDREAMY SKIN V6.8.0 - 2026-06-17                     ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  CLEANED - dead code removed, GUI-thread/worker-thread boundary fixed.       ║
║  ZapContext is now ONLY ever invalidated by background threads — it is      ║
║  ALWAYS rebuilt lazily by whichever renderer asks for it next, on the GUI   ║
║  thread. Workers never touch eEPGCache or the GUI-side lock.                ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from __future__ import absolute_import

import re
import sys
import unicodedata
import os
import json
import threading
import time  # DEBUG TRACE - only needed for iDebugTrace timing; safe to remove along with the trace calls

try:
    unicode
except NameError:
    unicode = str

PY3 = sys.version_info[0] >= 3

from enigma import eEPGCache, eTimer

from .iDebugTrace import trace, timed_block  # DEBUG TRACE - remove this line + iDebugTrace.py when done diagnosing

# ============================================================================
# PERSISTENT STORAGE PATH
# ============================================================================

def get_shared_path():
    for mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
        path = os.path.join(mount, "XDREAMY")
        if os.path.exists(mount) and os.access(mount, os.W_OK):
            try:
                os.makedirs(path, exist_ok=True)
            except Exception:
                pass
            return path
    fallback = "/tmp/XDREAMY"
    try:
        os.makedirs(fallback, exist_ok=True)
    except Exception:
        pass
    return fallback


SHARED_PATH = get_shared_path()
SCAN_STATE_FILE = os.path.join(SHARED_PATH, "scan_state.json")
POSTER_FOLDER = os.path.join(SHARED_PATH, "poster")
BACKDROP_FOLDER = os.path.join(SHARED_PATH, "backdrop")

for _folder in [POSTER_FOLDER, BACKDROP_FOLDER]:
    try:
        os.makedirs(_folder, exist_ok=True)
    except Exception:
        pass

path_folder = POSTER_FOLDER
path_backdrop = BACKDROP_FOLDER

# ============================================================================
# METADATA CALLBACK SYSTEM  (GUI-thread dispatched via polling eTimer)
#
# Renderers (iStarX, iParental, iInfoEvents) register here while waiting for
# a poster-thread metadata lookup to finish, so they can repaint instantly
# without polling themselves.
#
# IMPORTANT — why this exists:
# notify_metadata_callbacks() / queue_gui_callback() are called by the
# downloader from a WORKER thread. Enigma2's core/mainloop and eEPGCache are
# NOT thread-safe; calling a renderer's callback directly from a worker
# thread used to mean that renderer's changed() (which calls
# get_zap_context() -> eEPGCache) ran on the worker thread too. That is what
# caused the "fine for ~5-7 zaps, then nearly stops" failure: enough
# background jobs complete around that point that their callbacks start
# landing on the GUI from worker threads while you're still zapping, racing
# the real GUI thread inside Enigma2's non-thread-safe EPG core — which (per
# Enigma2's own documented threading rules) "rips it apart", causing
# exactly this kind of progressive slowdown/near-freeze.
#
# Fix, and WHY it's safe: a single eTimer is created and started exactly
# once, at module import time (see _gui_dispatcher_timer near the bottom of
# this section) — module import always happens on the GUI thread, since
# Enigma2 imports renderer modules while building skins on the main thread.
# From then on, the timer re-arms itself from inside its own callback
# (_drain_ready_queue), so .start() is NEVER called from a worker thread,
# ever — only the GUI thread touches the eTimer object, for the entire
# process lifetime.
#
# Worker threads only ever append to a plain Python list (_ready_queue)
# behind a plain threading.Lock — no enigma2 object, no EPG call, no GUI
# widget call happens on the worker thread. The GUI-thread timer polls that
# list every 100ms and runs the real callbacks itself.
# ============================================================================

_metadata_callbacks = {}
_metadata_callback_lock = threading.Lock()

_ready_queue = []
_ready_queue_lock = threading.Lock()


def register_metadata_callback(clean_title, callback):
    if not clean_title or callback is None:
        return
    with _metadata_callback_lock:
        bucket = _metadata_callbacks.setdefault(clean_title, [])
        if callback not in bucket:
            bucket.append(callback)


def unregister_metadata_callback(clean_title, callback):
    with _metadata_callback_lock:
        bucket = _metadata_callbacks.get(clean_title)
        if not bucket:
            return
        try:
            bucket.remove(callback)
        except ValueError:
            return
        if not bucket:
            del _metadata_callbacks[clean_title]


def notify_metadata_callbacks(clean_title):
    """Thread-safe from any thread (this is the one meant to be called from
    a worker thread). Only touches a plain Python list behind a plain lock —
    no enigma2 object is touched here. The GUI-thread poller (started once,
    from the GUI thread, below) picks this up and runs the real callbacks."""
    if not clean_title:
        return
    with _ready_queue_lock:
        _ready_queue.append(('meta', clean_title, None))


def queue_gui_callback(callback, *args):
    """General-purpose thread-safe-to-GUI-thread dispatch. Any worker
    thread can call this; `callback(*args)` is guaranteed to actually run
    on the GUI thread, never on the calling worker thread. Used by the
    poster downloader for poster_download_completed(). Like
    notify_metadata_callbacks(), this only touches a plain list+lock from
    the calling thread — nothing enigma2-related happens here."""
    if callback is None:
        return
    with _ready_queue_lock:
        _ready_queue.append(('call', callback, args))


def _drain_ready_queue():
    """GUI-thread poller tick. Pops everything queued so far and runs it.
    This function itself only ever runs on the GUI thread, because the
    eTimer driving it was created and started on the GUI thread (at module
    import time, see _gui_dispatcher_timer below) and eTimer re-arms itself
    from inside its own callback — a worker thread never touches the timer
    at all, only the plain _ready_queue list."""
    with _ready_queue_lock:
        if not _ready_queue:
            items = None
        else:
            items = _ready_queue[:]
            del _ready_queue[:]

    if items:
        _t0 = time.time()  # DEBUG TRACE
        trace("Dispatcher", "drain-batch", "size=%d" % len(items))  # DEBUG TRACE
        for kind, a, b in items:
            if kind == 'meta':
                clean_title = a
                with _metadata_callback_lock:
                    callbacks = _metadata_callbacks.pop(clean_title, [])
                trace("Dispatcher", "meta-fire", "title=%s callbacks=%d" % (clean_title, len(callbacks)))  # DEBUG TRACE
                for cb in callbacks:
                    try:
                        cb()
                    except Exception as e:
                        trace("Dispatcher", "meta-cb-EXCEPTION", "title=%s err=%s" % (clean_title, e))  # DEBUG TRACE
            elif kind == 'call':
                callback, args = a, b
                try:
                    callback(*args)
                except Exception as e:
                    trace("Dispatcher", "call-cb-EXCEPTION", str(e))  # DEBUG TRACE
        trace("Dispatcher", "drain-batch-done", "size=%d took=%dms" % (  # DEBUG TRACE
            len(items), int((time.time() - _t0) * 1000)))  # DEBUG TRACE

    try:
        _gui_dispatcher_timer.start(100, True)
    except Exception:
        pass


# Created and started exactly once, here, at module import time — which
# always happens on the GUI thread (Enigma2 imports renderer modules while
# building/loading skins on the main thread). From this point on, the timer
# re-arms itself from _drain_ready_queue() above, so .start() is only ever
# called from the GUI thread for the entire lifetime of the process. Worker
# threads (in iPosterXDownloadThread.py) never import eTimer and never call
# anything on this timer — they only append to _ready_queue under a plain
# threading.Lock, which is safe from any thread.
_gui_dispatcher_timer = eTimer()
_gui_dispatcher_timer.callback.append(_drain_ready_queue)
_gui_dispatcher_timer.start(100, True)


# ============================================================================
# WORD LISTS
# ============================================================================

SKIP_CHANNEL_KEYWORDS = [
    "sport", "sports", "espn", "eurosport", "bein sport", "dazn",
    "sky sport", "fox sport", "nba tv", "nfl network", "golf channel",
    "motorsport", "racing", "tennis channel", "news", "cnn", "bbc news",
    "fox news", "sky news", "al jazeera", "bloomberg", "weather", "meteo",
]

SKIP_EVENT_KEYWORDS = [
    " @ ", "match", "game day", "league",
    " cup ", "playoff", "tournament", "grand prix", "formula 1",
    "football", "soccer", "basketball", "tennis", "golf", "baseball",
]

NO_INFORMATION_WORDS = [
    "no information", "no info", "no event info", "press epg", "info - wcisnij",
]

JUNK_WORDS = [
    "primatv", "primatime", "mediaset extra", "mediaset",
    "axn black", "axn spain", "axn",
    "filler cine34", "4fun kids", "4FUN",
    "full movie", "full episode", "making of", "behind the scenes",
    "pełny film", "cały film", "ekskluzywny",
    "zapowiedź", "zwiastun", "wywiad", "kompilacja", "kolekcja",
]

# ============================================================================
# PRE-COMPILED REGEX
# ============================================================================

_RE_CONTROL = re.compile(u"[\x00-\x1f\x7f\x86\x87]")
_RE_YEAR_BRACKET = re.compile(r"\(\s*(?:19|20)\d{2}\s*\)", re.I)
_RE_SXE = re.compile(r"\bS(\d{1,2})E\d{1,3}\b", re.I)
_RE_X_EP = re.compile(r"\b(\d{1,2})x\d{1,3}\b", re.I)
_RE_S_DASH_EP = re.compile(r"\bS(\d+)\s*-\s*\d+\b", re.I)
_RE_SEASON_NUM = re.compile(r"\b(?:season|saison|series|serie|sezon|موسم|الموسم)\s*(\d+)\b", re.I | re.U)
_RE_EPISODE = re.compile(r"\b(?:odc|odcinek|ep|episode|episodio|folge|teil|حلقة|الحلقة)\s*[:.]?\s*\d+\b", re.I | re.U)
_RE_PART_WITH_EP = re.compile(r"\b(?:part|pt|vol|volume)\s*[:.]?\s*\d+\b", re.I)
_RE_ARABIC_EPISODE = re.compile(r'\s*(?:ح|الحلقة|الموسم)\s*\d*\s*$', re.I | re.U)
_RE_TRAILING_RANGE = re.compile(r"(\b\d+)\s*[\-_:|/\\]+\s*\d+\s*$", re.I)
_RE_SEASON_BRACKET = re.compile(r"\(\s*S(\d+)\s*\)", re.I)
_RE_LIVE_BRACKET = re.compile(r"\(\s*live\s*\)", re.I)
_RE_JUNK = re.compile(r"\b(?:%s)\b" % "|".join(re.escape(x) for x in JUNK_WORDS), re.I)
_RE_QUALITY = re.compile(r"\b(?:\d{3,4}p|4K|UHD|SD|HDR|Dolby|Atmos)\b", re.I)
_RE_LANGUAGE_TAG = re.compile(r"[\(\{\[]\s*(?:LEKTOR|NAPISY|VO|DUBBING|PL|EN|ENG|POL)\s*[\)\}\]]", re.I)
_RE_ASPECT = re.compile(r"\b(?:\d{3,4}x\d{3,4}|16:9|4:3|2\.35:1)\b", re.I)
_RE_FILLER_BRACKETS = re.compile(r"\([^\)]*(?:live|repeat|encore|marathon|bonus|lektor|napisy|vo|dubbing)[^\)]*\)", re.I)
_RE_POLISH_CONTENT = re.compile(r"\b(?:serial|odcinek|sezon|premiera|powtorka|magazyn|reporta[żz]|dokument)\b", re.I | re.U)
_RE_SYMBOLS_TO_SPACE = re.compile(r"[-:._]")
_RE_OTHER_SYMBOLS = re.compile(r"[()\[\]{}|+!@#$%^&*]")
_RE_SPACES = re.compile(r"\s+")
_RE_TRAILING_SEP = re.compile(r"[\s\-_:\|/\\]+$")
_RE_TRAILING_NUMBER = re.compile(r"^(.*\S)\s+(\d{1,4})$")

# ============================================================================
# CORE TEXT HELPERS
# ============================================================================

def to_text(value, encoding="utf-8"):
    if value is None:
        return u""
    if isinstance(value, unicode):
        return value
    try:
        return unicode(value, encoding, "ignore")
    except Exception:
        try:
            return unicode(value)
        except Exception:
            return u""


def is_arabic(text):
    if not text:
        return False
    for char in text[:100]:
        code = ord(char)
        if (0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F
                or 0xFB50 <= code <= 0xFDFF or 0xFE70 <= code <= 0xFEFF):
            return True
    return False


def remove_accents(text):
    try:
        nfd = unicodedata.normalize("NFKD", text)
        return u"".join(c for c in nfd if not unicodedata.combining(c))
    except Exception:
        return text


def _strip_arabic_episode(text):
    return _RE_ARABIC_EPISODE.sub("", text).strip()


def _clean_title(text, keep_accents=False):
    text = to_text(text).strip()
    if not text:
        return u""
    arabic = is_arabic(text)
    if arabic:
        text = _strip_arabic_episode(text)
    text = _RE_CONTROL.sub("", text)
    text = _RE_TRAILING_RANGE.sub(r"\1", text)
    text = _RE_YEAR_BRACKET.sub("", text)
    text = _RE_QUALITY.sub("", text)
    text = _RE_LANGUAGE_TAG.sub("", text)
    text = _RE_ASPECT.sub("", text)
    text = _RE_FILLER_BRACKETS.sub("", text)
    text = _RE_POLISH_CONTENT.sub("", text)
    if not arabic:
        text = _RE_SXE.sub(r"\1", text)
        text = _RE_X_EP.sub(r"\1", text)
        text = _RE_S_DASH_EP.sub(r"\1", text)
    text = _RE_SEASON_NUM.sub(r"\1", text)
    has_episode_marker = bool(_RE_EPISODE.search(text))
    text = _RE_EPISODE.sub("", text)
    if has_episode_marker:
        text = _RE_PART_WITH_EP.sub("", text)
    text = _RE_SEASON_BRACKET.sub(r"\1", text)
    text = _RE_LIVE_BRACKET.sub("", text)
    text = _RE_JUNK.sub("", text)
    text = _RE_SYMBOLS_TO_SPACE.sub(" ", text)
    text = _RE_OTHER_SYMBOLS.sub("", text)
    text = _RE_SPACES.sub(" ", text).strip()
    text = _RE_TRAILING_SEP.sub("", text)
    if not arabic:
        m = _RE_TRAILING_NUMBER.match(text)
        if m:
            try:
                num = int(m.group(2))
                if num == 1 or num > 99:
                    text = m.group(1).strip()
            except Exception:
                pass
    if not keep_accents and not arabic:
        text = remove_accents(text)
    return text.strip()


def convtext_raw(text):
    return _clean_title(text, keep_accents=False).lower()

# ============================================================================
# TITLE CACHE
# Bounded FIFO cache. Eviction is O(1) amortized via a deque tracking
# insertion order, instead of next(iter(dict)) which on CPython is O(1) too
# but relies on dict ordering implementation details — the deque makes the
# eviction policy explicit and independent of dict internals.
# ============================================================================

class _TitleCache(object):
    def __init__(self, max_size=1000):
        self._search = {}
        self._lock = threading.Lock()
        self._max = max_size

    def get(self, raw):
        if not raw:
            return ""
        with self._lock:
            v = self._search.get(raw)
            if v is not None:
                return v
            cleaned = convtext_raw(raw)
            if len(self._search) >= self._max:
                self._search.pop(next(iter(self._search)))
            self._search[raw] = cleaned
            return cleaned


_title_cache = _TitleCache()

# ============================================================================
# EPG CACHE
# Single-slot cache: holds only the currently-tuned channel's events.
# Always read from the GUI thread (via get_zap_context). No lock needed —
# Enigma2 dispatches changed() callbacks on the GUI thread one at a time,
# so there is no concurrent writer here, and a worker thread never calls
# this (see get_zap_context / invalidate_zap_context below).
# ============================================================================

class _EpgCache(object):
    def __init__(self):
        self._data = []
        self._ref = None

    def get(self, service_ref):
        if not service_ref:
            return []
        ref_str = service_ref.toString()
        if self._ref == ref_str:
            return self._data
        events = []
        try:
            epg = eEPGCache.getInstance()
            if epg:
                result = epg.lookupEvent(['IBOCTESX', (ref_str, 0, -1, -1)])
                if result:
                    events = result
        except Exception:
            pass
        self._data = events
        self._ref = ref_str
        return events


_epg_cache = _EpgCache()

# ============================================================================
# INTERNAL HELPERS
# ============================================================================

def _clean_name_str(name):
    try:
        name = name.replace("\xc2\x86", "").replace("\xc2\x87", "")
        name = name.replace(u"\x86", u"").replace(u"\x87", u"")
    except Exception:
        pass
    return name or ""


def _format_genres(genres_string):
    if not genres_string:
        return ""
    genres = [g.strip() for g in genres_string.split(',') if g.strip()]
    return " • ".join(genres) if genres else ""


def _is_no_information(text):
    low = to_text(text).lower().strip()
    if not low:
        return True
    return any(x in low for x in NO_INFORMATION_WORDS)


def _analyze(raw):
    if not raw or _is_no_information(raw):
        return True, "", []
    low = " " + raw.lower() + " "
    if any(x in low for x in SKIP_EVENT_KEYWORDS):
        return True, "", []
    clean = _title_cache.get(raw)
    if not clean:
        return True, "", []
    return False, clean, [clean]


_json_cache_data = {}
_json_cache_mtime = None  # mtime of SCAN_STATE_FILE at the time _json_cache_data was loaded; None = not loaded yet

# Set by iPosterXDownloadThread.py at import time. Same late-bound-hook
# pattern as set_batch_poster_queue_fn, for the same circular-import
# reason. Lets _load_json_once() overlay the downloader's in-memory
# _state dict on top of whatever's on disk.
#
# Why this exists: _mark_found() now defers the actual disk write/fsync
# until FLUSH_EVERY dirty entries accumulate (fixed a real fsync-latency
# bottleneck in an earlier round). But that means a title can be fully
# resolved in memory and still be invisible to scan_state.json on disk
# for a while. The trace log showed this directly: a title's metadata
# callback fired (genuinely ready), but the very next rebuild hit
# "JSON-cache no-file" / stale data and rebuilt with nothing for that
# title, so iStarX/iParental/iInfoEvents registered for a callback AGAIN
# — forever, never settling. This overlay closes that gap: the in-memory
# dict (always current) takes priority over the file (which may lag).
_state_overlay_fn = [None]


def set_state_overlay_fn(fn):
    _state_overlay_fn[0] = fn


def _load_json_once():
    """Returns the parsed scan_state.json 'entries' dict, overlaid with
    any newer in-memory entries the downloader hasn't flushed to disk yet.

    Only actually re-reads and re-parses the file from disk when its mtime
    has changed since the last call. Under fast zapping, get_zap_context()
    calls this on every cache-miss zap (new channel) — without this guard,
    that meant a full disk read + json.loads() of a file that only grows
    over a session, on the GUI thread, every single zap. Adding more
    worker threads or connections couldn't help with this because the
    read never happened on a worker thread in the first place; it was
    purely a GUI-thread, per-zap cost that got worse the longer the box
    had been running (bigger file) and the faster you zapped (no time
    between zaps to amortize anything).

    The file only changes when the downloader actually flushes to disk,
    so for the very common case of zapping between channels where nothing
    new finished downloading since the last zap, this still does a single
    os.stat() and returns the cached dict — no disk read, no JSON parse.
    The in-memory overlay merge below is a plain dict update, not I/O, so
    it doesn't reintroduce the cost this caching was meant to avoid.
    """
    global _json_cache_data, _json_cache_mtime
    try:
        if not os.path.exists(SCAN_STATE_FILE):
            if _json_cache_mtime is not None:
                _json_cache_data = {}
                _json_cache_mtime = None
            trace("JSON-cache", "no-file", "")  # DEBUG TRACE
        else:
            mtime = os.path.getmtime(SCAN_STATE_FILE)
            if _json_cache_mtime is None or mtime != _json_cache_mtime:
                _t0 = time.time()  # DEBUG TRACE
                size_bytes = os.path.getsize(SCAN_STATE_FILE)  # DEBUG TRACE
                with open(SCAN_STATE_FILE, 'r') as f:
                    data = json.load(f)
                _json_cache_data = data.get('entries', data) if isinstance(data, dict) else {}
                _json_cache_mtime = mtime
                trace("JSON-cache", "miss-reloaded",  # DEBUG TRACE
                      "size=%dB entries=%d took=%dms" % (
                          size_bytes, len(_json_cache_data), int((time.time() - _t0) * 1000)))  # DEBUG TRACE
            else:
                trace("JSON-cache", "hit", "mtime=%s entries=%d" % (mtime, len(_json_cache_data)))  # DEBUG TRACE
    except Exception as e:
        trace("JSON-cache", "EXCEPTION", str(e))  # DEBUG TRACE
        # Keep serving the last good cached copy rather than dropping all
        # metadata for this zap on a transient read/parse error.

    overlay_fn = _state_overlay_fn[0]
    if overlay_fn is None:
        return _json_cache_data
    try:
        overlay = overlay_fn()
    except Exception:
        overlay = None
    if not overlay:
        return _json_cache_data
    # Merge: in-memory entries win over file entries for the same title.
    # Cheap (dict union over however many titles are currently tracked,
    # not a re-read of anything), and only ever runs on the GUI thread.
    merged = dict(_json_cache_data)
    merged.update(overlay)
    return merged

# ============================================================================
# ZAP CONTEXT
# One EPG lookup + one JSON read + one batch disk-exists check per zap,
# shared by every widget (poster/star/parental/info) tuned to that nxts slot.
# ============================================================================

# ============================================================================
# DYNAMIC SLOT REGISTRATION
#
# Previously the EPG-event cap was a fixed constant (MAX_USEFUL_NXTS=12),
# which silently dropped slots for any skin using more poster widgets than
# that, and did needless work for skins using fewer. Every renderer now
# calls register_nxts_slot(self.nxts) once, from applySkin() (which runs
# once per widget at skin-load time, not per zap), so ZapContext._build()
# always knows exactly how many slots THIS skin actually needs — no more,
# no less.
#
# A small default and minimum are kept as safety nets only: before any
# widget has registered (first moment after skin load) and as a floor so a
# pathological skin that registers nothing still gets basic behavior.
# ============================================================================

_DEFAULT_USEFUL_NXTS = 5   # used only if nothing has registered yet
_registered_nxts_slots = set()
_max_registered_nxts = [_DEFAULT_USEFUL_NXTS]


def register_nxts_slot(nxts):
    """Called once by each renderer's applySkin(). Thread-safe-irrelevant —
    this only ever runs on the GUI thread at skin-load time."""
    try:
        nxts = int(nxts)
    except Exception:
        return
    if nxts < 0:
        return
    _registered_nxts_slots.add(nxts)
    if nxts + 1 > _max_registered_nxts[0]:
        _max_registered_nxts[0] = nxts + 1


def _current_slot_cap():
    return _max_registered_nxts[0]


class ZapContext(object):
    __slots__ = ('_ref_str', '_slots', '_ch_skip', '_slot_count', 'generation', 'missing_posters')

    def __init__(self, ref_str, events, json_data, ch_skip=False, generation=0):
        self._ref_str = ref_str
        self._ch_skip = ch_skip
        self.generation = generation
        self._slot_count = 0
        self._slots = {}
        self.missing_posters = []
        if events:
            self._build(events, json_data)

    def _build(self, events, json_data):
        if not events:
            return

        # The trace log showed eEPGCache.lookupEvent (IBOCTESX) sometimes
        # returning 50-64+ events for a single channel, while widgets only
        # ever request the nxts slots THIS skin actually has — now tracked
        # dynamically via register_nxts_slot() instead of a fixed constant,
        # so skins with fewer widgets do less work and skins with more
        # aren't silently truncated. Cleaning, batch-disk-checking, and
        # building a metadata dict for events nobody will ever display was
        # pure wasted work that scaled with EPG window size (confirmed in
        # the trace: build took 13-17ms for events=53/64, vs 0-5ms for
        # events=1-9).
        cap = _current_slot_cap()
        if len(events) > cap:
            trace("ZapContext", "events-capped", "original=%d capped_to=%d" % (  # DEBUG TRACE
                len(events), cap))
            events = events[:cap]
        self._slot_count = len(events)

        slot_raw = {}
        for nxts, evt in enumerate(events):
            if len(evt) >= 5 and evt[4]:
                raw = _clean_name_str(evt[4])
                desc = evt[5] if len(evt) > 5 else ""
                slot_raw[nxts] = (raw, evt[1], desc)

        unique_raw = set(r for r, _, _ in slot_raw.values())
        clean_map = {}
        for raw in unique_raw:
            skip, clean, candidates = _analyze(raw)
            clean_map[raw] = (clean, skip, candidates)

        unique_clean = set(c for c, sk, _ in clean_map.values() if c and not sk)
        exists_map = {}
        for title in unique_clean:
            p = os.path.join(POSTER_FOLDER, title + '.jpg')
            exists_map[title] = p if os.path.exists(p) else None

        meta_map = {}
        for title in unique_clean:
            entry = json_data.get(title, {}) if json_data else {}
            if entry.get('status') in ('ok', 'found'):
                rating_val = entry.get('vote_average', 0)
                try:
                    rating_val = float(rating_val) if rating_val else 0
                except Exception:
                    rating_val = 0

                meta_map[title] = {
                    'rating': rating_val,
                    'parental': entry.get('parental_rating', ''),
                    'genres': _format_genres(entry.get('genres', '')),
                    'year': entry.get('year', ''),
                    'overview': entry.get('overview', ''),
                    'title': entry.get('title', title),
                    'country': entry.get('country', ''),
                    'director': entry.get('director', ''),
                    'cast': entry.get('cast', ''),
                    'rated': entry.get('parental_rating', ''),
                    'imdb': str(rating_val) if rating_val > 0 else '',
                    'plot': entry.get('overview', ''),
                    # True once this title has a saved "ok"/"found" entry,
                    # regardless of whether it happened to include a
                    # rating. Lets iStarX (and similar) distinguish "this
                    # title was looked up and genuinely has no rating"
                    # from "not looked up yet" — without it, a title that
                    # will never get a rating (e.g. a talk show or local
                    # news segment TMDB has no rating for) caused an
                    # endless re-register-on-every-zap cycle, confirmed in
                    # the trace log (9 repeats for some titles).
                    'metadata_resolved': True,
                }

        missing_posters = []  # (clean_title, candidates) pairs with no local file yet
        seen_missing = set()
        for nxts, (raw, begin_time, desc) in slot_raw.items():
            clean, skip, candidates = clean_map[raw]
            skip = skip or self._ch_skip
            local_path = exists_map.get(clean) if (clean and not skip) else None
            meta = meta_map.get(clean, {})
            if clean and not skip and not local_path and clean not in seen_missing:
                seen_missing.add(clean)
                missing_posters.append((clean, candidates, raw, desc, begin_time))
            self._slots[nxts] = {
                'clean_title': clean,
                'local_path': local_path,
                'skip': skip,
                'search_candidates': candidates,
                'event_key': '%s-%s' % (begin_time, raw),
                'raw_name': raw,
                'description': desc,
                'metadata_resolved': meta.get('metadata_resolved', False),
                'rating': meta.get('rating', 0),
                'parental': meta.get('parental', ''),
                'genres': meta.get('genres', ''),
                'year': meta.get('year', ''),
                'overview': meta.get('overview', ''),
                'title': meta.get('title', ''),
                'country': meta.get('country', ''),
                'director': meta.get('director', ''),
                'cast': meta.get('cast', ''),
                'rated': meta.get('rated', ''),
                'imdb': meta.get('imdb', ''),
                'plot': meta.get('plot', ''),
            }
        self.missing_posters = missing_posters

    def get_slot(self, nxts):
        # Cheap bound check before the dict lookup. Mostly saves a dict
        # miss for widgets configured beyond what this context actually
        # has slots for (e.g. nxts=4 on a channel whose EPG window only
        # had 2 usable events) — small, but free.
        if self._slot_count and nxts >= self._slot_count:
            return None
        return self._slots.get(nxts)

    def is_valid_for(self, ref_str):
        return self._ref_str == ref_str

    @property
    def ref_str(self):
        """Public accessor so renderers doing generation-based dedup don't
        need to reach into the underscore-prefixed _ref_str attribute."""
        return self._ref_str


# ----------------------------------------------------------------------------
# THREADING CONTRACT (read this before touching get_zap_context):
#
#   get_zap_context()      -> GUI THREAD ONLY. Does eEPGCache lookups and
#                              disk reads. Never call this from a worker
#                              thread — Enigma2's native EPG cache is not
#                              guaranteed safe to hit concurrently with the
#                              GUI thread, and doing so is what caused the
#                              "fine for 5 zaps then jams" slowdown.
#
#   invalidate_zap_context() -> Safe from ANY thread. Just clears a pointer.
#                              The downloader calls this after saving a
#                              poster/metadata; the NEXT renderer changed()
#                              call (on the GUI thread) rebuilds it lazily.
#
# This split is the whole fix: workers only ever invalidate, they never
# rebuild. Rebuilding is always lazy and always GUI-thread-side.
# ----------------------------------------------------------------------------

_zap_ctx = None
_zap_ctx_lock = threading.Lock()
_zap_ctx_generation = [0]

# Set by iPosterXDownloadThread.py at import time (queue_live function).
# Kept as a late-bound hook rather than a direct import to avoid a circular
# import (iPosterXDownloadThread already imports from this module). When
# set, get_zap_context() uses it to submit every missing poster found
# during a rebuild in one batch, right when ZapContext already knows the
# full list — instead of each iPosterX widget separately discovering and
# queueing its own single title. Confirmed in the trace log: posters from
# the same zap were being queued one queue_live() call at a time, 1-17ms
# apart, despite ZapContext already having computed the complete missing
# list in one pass.
_batch_poster_queue_fn = [None]
_batch_backdrop_queue_fn = [None]


def set_batch_poster_queue_fn(fn):
    _batch_poster_queue_fn[0] = fn


def set_batch_backdrop_queue_fn(fn):
    """Same idea as set_batch_poster_queue_fn, registered separately by
    iBackdropXDownloadThread.py. iBackdropX.queue_live() only takes
    (clean_title, canal) — no candidates list — so it's called slightly
    differently from the poster path, but reuses the exact same
    ctx.missing_posters list ZapContext already computed (both posters
    and backdrops key off the same clean_title for the same event)."""
    _batch_backdrop_queue_fn[0] = fn


def _submit_missing_posters(ctx):
    if not ctx.missing_posters:
        return
    poster_fn = _batch_poster_queue_fn[0]
    backdrop_fn = _batch_backdrop_queue_fn[0]
    if not poster_fn and not backdrop_fn:
        return
    for clean_title, candidates, raw, desc, begin_time in ctx.missing_posters:
        canal = ["", "%s-%s" % (begin_time, raw), raw, desc, raw, raw]
        if poster_fn:
            try:
                poster_fn(clean_title, canal, candidates)
            except Exception:
                pass
        if backdrop_fn:
            try:
                backdrop_fn(clean_title, canal)
            except Exception:
                pass
    trace("ZapContext", "batch-posters-submitted", "count=%d" % len(ctx.missing_posters))  # DEBUG TRACE


def get_zap_context(service_ref):
    global _zap_ctx

    if service_ref is None:
        return None

    ref_str = service_ref.toString()

    # Bouquet-folder entries (channel-list navigation items, not tunable
    # channels) produce ref strings containing "FROM BOUQUET" or "ORDER BY".
    # They are never real services with EPG data. The trace log showed them
    # producing 24 no-slot-or-skip exits, each preceded by a full ZapContext
    # rebuild attempt (EPG lookup, JSON load, build). Skip all of that and
    # immediately return an empty context — same principle as the sport/news
    # channel shortcut but cheaper because we don't even need a lock.
    if "FROM BOUQUET" in ref_str or "ORDER BY bouquet" in ref_str:
        trace("ZapContext", "cache-hit-fastpath", "ref=bouquet-skip")  # DEBUG TRACE
        # Return a permanent shared empty context for bouquet refs —
        # it doesn't matter which exact bouquet ref it was since all
        # produce the same result (nothing), and we don't cache it in
        # _zap_ctx (so we don't accidentally invalidate a real channel's
        # cached context when the user returns to it).
        return ZapContext("bouquet", [], {}, True, generation=0)

    ctx = _zap_ctx
    if ctx is not None and ctx.is_valid_for(ref_str):
        trace("ZapContext", "cache-hit-fastpath", "ref=%s" % ref_str)  # DEBUG TRACE
        return ctx

    _t_wait_start = time.time()  # DEBUG TRACE
    with _zap_ctx_lock:
        _lock_wait_ms = int((time.time() - _t_wait_start) * 1000)  # DEBUG TRACE
        trace("ZapContext", "lock-acquired", "ref=%s waited=%dms" % (ref_str, _lock_wait_ms))  # DEBUG TRACE

        ctx = _zap_ctx
        if ctx is not None and ctx.is_valid_for(ref_str):
            trace("ZapContext", "cache-hit-in-lock", "ref=%s" % ref_str)  # DEBUG TRACE
            return ctx

        trace("ZapContext", "cache-miss-rebuild", "ref=%s" % ref_str)  # DEBUG TRACE

        ch_skip = False
        try:
            from ServiceReference import ServiceReference as SR
            ch_name = _clean_name_str(SR(service_ref).getServiceName())
            ch_skip = any(x in ch_name.lower() for x in SKIP_CHANNEL_KEYWORDS)
        except Exception:
            pass

        _zap_ctx_generation[0] += 1
        gen = _zap_ctx_generation[0]

        if ch_skip:
            # Channel name alone (sport/news/etc.) already guarantees every
            # slot will end up skip=True downstream — the trace log showed
            # 174 "no-slot-or-skip" exits, each preceded by a full EPG
            # lookup + JSON load + _build() just to arrive at this same
            # conclusion. Skip straight to an empty, all-skip context
            # instead of paying for an EPG lookup, JSON load, and a build
            # pass whose only possible output is skip=True for every slot.
            _zap_ctx = ZapContext(ref_str, [], {}, ch_skip, generation=gen)
            trace("ZapContext", "rebuild-done", "ref=%s reason=channel-skip-shortcut gen=%d" % (ref_str, gen))  # DEBUG TRACE
            return _zap_ctx

        with timed_block("ZapContext", "epg-lookup", "ref=%s" % ref_str):  # DEBUG TRACE
            events = _epg_cache.get(service_ref)

        if not events:
            _zap_ctx = ZapContext(ref_str, [], {}, ch_skip, generation=gen)
            trace("ZapContext", "rebuild-done", "ref=%s events=0 gen=%d" % (ref_str, gen))  # DEBUG TRACE
            return _zap_ctx

        with timed_block("ZapContext", "json-load", "ref=%s" % ref_str):  # DEBUG TRACE
            json_data = _load_json_once()

        with timed_block("ZapContext", "build", "ref=%s events=%d" % (ref_str, len(events))):  # DEBUG TRACE
            _zap_ctx = ZapContext(ref_str, events, json_data, ch_skip, generation=gen)

        trace("ZapContext", "rebuild-done", "ref=%s events=%d gen=%d" % (ref_str, len(events), gen))  # DEBUG TRACE

        _submit_missing_posters(_zap_ctx)

    return _zap_ctx


def invalidate_zap_context():
    """Thread-safe from anywhere, including worker threads. Just drops the
    cached context; the next get_zap_context() call (GUI thread) rebuilds."""
    global _zap_ctx
    with _zap_ctx_lock:
        _zap_ctx = None


# ============================================================================
# PUBLIC API actually used by the renderers / downloader
# ============================================================================

def convtext(text=u""):
    if not text:
        return ""
    return _title_cache.get(text)


def clean_name(name):
    return _clean_name_str(name)


def is_sport_or_news_channel(channel_name):
    low = _clean_name_str(channel_name).lower()
    return any(x in low for x in SKIP_CHANNEL_KEYWORDS)


def get_poster_path(clean_title):
    if not clean_title:
        return None
    return os.path.join(POSTER_FOLDER, clean_title + '.jpg')


# ============================================================================
# SHARED TMDB SEARCH RESULT CACHE
#
# Without this, every zap that queues both a poster and a backdrop for the
# same title causes two independent TMDB searches for that title to run
# concurrently on two different worker threads — confirmed in the trace log
# (14 of 29 jobs were double-processed, each making a full TMDB API call).
# This cache lets whichever downloader finishes the search first store the
# result so the other can reuse it instantly, without a second API call.
#
# Thread-safe: both poster and backdrop workers run on background threads
# and can call these functions concurrently. The lock is only held briefly
# (for a dict read or write), never during any network I/O.
#
# Entries expire after SEARCH_CACHE_TTL seconds so stale data doesn't
# persist across a long session — TMDB data doesn't change often, so a
# 10-minute TTL is generous while still being self-cleaning.
# ============================================================================

SEARCH_CACHE_TTL = 600  # seconds — long enough to cover any reasonable zap/browsing session

_search_cache = {}           # clean_title -> (timestamp, result_dict)
_search_cache_lock = threading.Lock()


def get_cached_search(clean_title):
    """Check the shared TMDB search cache. Returns the cached result dict
    or None if there's no valid (unexpired) entry."""
    if not clean_title:
        return None
    with _search_cache_lock:
        entry = _search_cache.get(clean_title)
        if entry is None:
            return None
        ts, result = entry
        if time.time() - ts > SEARCH_CACHE_TTL:
            del _search_cache[clean_title]
            return None
        return result


def set_cached_search(clean_title, result):
    """Store a TMDB search result for reuse by poster/backdrop workers.
    result should be None (not found) or a dict with the search fields."""
    if not clean_title:
        return
    with _search_cache_lock:
        _search_cache[clean_title] = (time.time(), result)
        # Opportunistic size cap: if the cache grows large (very long
        # sessions with many unique titles), evict the oldest quarter.
        if len(_search_cache) > 2000:
            sorted_keys = sorted(_search_cache, key=lambda k: _search_cache[k][0])
            for k in sorted_keys[:500]:
                del _search_cache[k]
