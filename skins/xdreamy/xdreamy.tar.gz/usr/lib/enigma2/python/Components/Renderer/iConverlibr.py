#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                              iConverlibr.py                                  ║
║                         XDREAMY SKIN V6.5.2 - 2026-01-20                     ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  CENTRAL HELPER - All shared functions for all renderers                    ║
║  • Title cleaning with cache                                                ║
║  • Sport/news detection                                                     ║
║  • Batch poster helper (ONE JSON read for multiple events)                  ║
║  • Name cleaning and path helpers                                           ║
║  • Genre formatting                                                         ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from __future__ import absolute_import

import re
import sys
import unicodedata
import os
import json
import threading

try:
    unicode
except NameError:
    unicode = str

PY3 = sys.version_info[0] >= 3

if PY3:
    from urllib.parse import quote_plus
else:
    from urllib import quote_plus

# ---------------------------------------------------------------------------
# SKIP / JUNK WORD DEFINITIONS
# ---------------------------------------------------------------------------
SKIP_CHANNEL_KEYWORDS = [
    "sport", "sports", "espn", "eurosport", "bein sport", "dazn",
    "sky sport", "fox sport", "nba tv", "nfl network", "golf channel",
    "motorsport", "racing", "tennis channel", "news", "cnn", "bbc news",
    "fox news", "sky news", "al jazeera", "bloomberg", "weather", "meteo"
]

SKIP_EVENT_KEYWORDS = [
    " vs ", " v ", " @ ", "match", "game day", "league",
    " cup ", "playoff", "tournament", "grand prix", "formula 1",
    "football", "soccer", "basketball", "tennis", "golf", "baseball"
]

NO_INFORMATION_WORDS = [
    "no information", "no info", "no event info", "press epg", "info - wcisnij"
]

JUNK_WORDS = [
    "primatv", "primatime", "mediaset extra", "mediaset", "axn black",
    "axn spain", "axn", "premiere", "hd", "filler cine34", "4fun kids", "4FUN"
]

# ---------------------------------------------------------------------------
# PRE-COMPILED REGEX CONSTANTS
# ---------------------------------------------------------------------------
_RE_CONTROL = re.compile(u"[\x00-\x1f\x7f\x86\x87]")
_RE_YEAR_BRACKET = re.compile(r"\(\s*(?:19|20)\d{2}\s*\)", re.I)
_RE_SXE = re.compile(r"\bS\d{1,2}E\d{1,3}\b", re.I)
_RE_X_EP = re.compile(r"\b\d{1,2}x\d{1,3}\b", re.I)
_RE_S_DASH_EP = re.compile(r"\bS(\d+)\s*-\s*\d+\b", re.I)
_RE_SEASON_NUM = re.compile(
    r"\b(?:season|saison|series|serie|sezon|موسم|الموسم)\s*(\d+)\b",
    re.I | re.U
)
_RE_EPISODE = re.compile(
    r"\b(?:odc|odcinek|ep|episode|episodio|part|pt|folge|teil|حلقة|الحلقة)\s*[:.]?\s*\d+\b",
    re.I | re.U
)
_RE_ARABIC_EPISODE = re.compile(r'\s*(?:ح|الحلقة|الموسم)\s*\d*\s*$', re.I | re.U)
_RE_TRAILING_RANGE = re.compile(r"(\b\d+)\s*[\-_:|/\\]+\s*\d+\s*$", re.I)
_RE_JUNK = re.compile(
    r"\b(?:%s)\b" % "|".join(re.escape(x) for x in JUNK_WORDS), re.I
)
_RE_SEASON_KEYWORD = re.compile(r"\b(?:season|saison|series|serie|sezon)\s*(\d+)\b", re.I)
_RE_SEASON_BRACKET = re.compile(r"\(\s*S(\d+)\s*\)", re.I)
_RE_LIVE_BRACKET = re.compile(r"\(\s*live\s*\)", re.I)
_RE_SYMBOLS_TO_SPACE = re.compile(r"[-:./_]")
_RE_OTHER_SYMBOLS = re.compile(r"[()\[\]{}|+!@#$%^&*]")
_RE_SPACES = re.compile(r"\s+")
_RE_TRAILING_NUMBER = re.compile(r"^(.*\S)\s+(\d{2,5})$")

# ---------------------------------------------------------------------------
# BASE HELPER FUNCTIONS
# ---------------------------------------------------------------------------
def to_text(value, encoding="utf-8"):
    if value is None:
        return u""
    if isinstance(value, unicode):
        return value
    try:
        return unicode(value, encoding, "ignore")
    except Exception:
        try:
            return unicode(value)
        except Exception:
            return u""

def str_encode(value, encoding="utf-8"):
    if PY3:
        return value
    if isinstance(value, unicode):
        return value.encode(encoding)
    return value

def is_arabic(text):
    if not text:
        return False
    for char in text[:100]:
        code = ord(char)
        if 0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F or 0xFB50 <= code <= 0xFDFF or 0xFE70 <= code <= 0xFEFF:
            return True
    return False

def remove_accents(text):
    try:
        nfd = unicodedata.normalize("NFKD", text)
        return u"".join(c for c in nfd if not unicodedata.combining(c))
    except Exception:
        return text

def quoteEventName(eventName):
    text = to_text(eventName)
    try:
        if PY3:
            return quote_plus(text, safe="+")
        return quote_plus(text.encode("utf-8"), safe="+")
    except Exception:
        return quote_plus(str(eventName), safe="+")

# ---------------------------------------------------------------------------
# SPORT/NEWS DETECTION
# ---------------------------------------------------------------------------
def is_sport_or_news_channel(channel_name):
    low = to_text(channel_name).lower()
    return any(x in low for x in SKIP_CHANNEL_KEYWORDS)

def is_sport_or_news_event(event_name):
    low = " " + to_text(event_name).lower() + " "
    return any(x in low for x in SKIP_EVENT_KEYWORDS)

def _is_no_information(text):
    low = to_text(text).lower().strip()
    if not low:
        return True
    return any(x in low for x in NO_INFORMATION_WORDS)

def _strip_arabic_episode(text):
    return _RE_ARABIC_EPISODE.sub("", text).strip()

def _clean_title(text, keep_accents=False):
    text = to_text(text).strip()
    if not text:
        return u""
    
    arabic = is_arabic(text)
    if arabic:
        text = _strip_arabic_episode(text)
    
    text = _RE_TRAILING_RANGE.sub(r"\1", text)
    text = _RE_CONTROL.sub("", text)
    text = _RE_YEAR_BRACKET.sub("", text)
    
    if not arabic:
        text = _RE_SXE.sub("", text)
        text = _RE_X_EP.sub("", text)
        text = _RE_S_DASH_EP.sub(r"\1", text)
    
    text = _RE_SEASON_NUM.sub(r"\1", text)
    text = _RE_EPISODE.sub("", text)
    text = _RE_SEASON_BRACKET.sub(r"\1", text)
    text = _RE_LIVE_BRACKET.sub("", text)
    text = _RE_SEASON_KEYWORD.sub(r"\1", text)
    text = _RE_JUNK.sub("", text)
    text = _RE_SYMBOLS_TO_SPACE.sub(" ", text)
    text = _RE_OTHER_SYMBOLS.sub("", text)
    text = _RE_SPACES.sub(" ", text).strip()
    
    if not arabic:
        trailing_num = _RE_TRAILING_NUMBER.match(text)
        if trailing_num:
            try:
                num = int(trailing_num.group(2))
                if num > 50:
                    text = trailing_num.group(1).strip()
            except Exception:
                pass
    
    if not keep_accents and not arabic:
        text = remove_accents(text)
    
    return text.strip()

# ---------------------------------------------------------------------------
# TITLE CLEANING WITH CACHE
# ---------------------------------------------------------------------------
_convtext_cache = {}
_CACHE_MAX_SIZE = 512

def convtext(text=u""):
    if not text:
        return ""
    cache_key = to_text(text)
    if not PY3:
        cache_key = str(cache_key)
    if cache_key in _convtext_cache:
        return _convtext_cache[cache_key]
    try:
        result = _clean_title(text, keep_accents=False).lower()
        if len(_convtext_cache) >= _CACHE_MAX_SIZE:
            _convtext_cache.clear()
        _convtext_cache[cache_key] = result
        return result
    except Exception:
        return to_text(text).lower()

def convtext_display(text=u""):
    try:
        return _clean_title(text, keep_accents=True)
    except Exception:
        return convtext(text)

# ---------------------------------------------------------------------------
# CENTRAL CLEANING CACHE (Shared across ALL renderers)
# ---------------------------------------------------------------------------
_clean_cache = {}
_CLEAN_CACHE_MAX = 1000

def get_cached_clean_title(raw_title):
    """Get cleaned title with caching - ALL renderers share this"""
    if not raw_title:
        return ""
    if raw_title in _clean_cache:
        return _clean_cache[raw_title]
    cleaned = convtext(raw_title)
    if len(_clean_cache) < _CLEAN_CACHE_MAX:
        _clean_cache[raw_title] = cleaned
    return cleaned

# ---------------------------------------------------------------------------
# EVENT NAME ANALYSIS
# ---------------------------------------------------------------------------
def analyze_event_name(text=u""):
    raw = to_text(text).strip()
    result = {"raw": str_encode(raw), "cache_title": "", "search_candidates": [], "skip": False, "skip_reason": None}
    if not raw:
        result["skip"] = True
        result["skip_reason"] = "empty"
        return result
    if _is_no_information(raw):
        result["skip"] = True
        result["skip_reason"] = "no_information"
        return result
    if is_sport_or_news_event(raw):
        result["skip"] = True
        result["skip_reason"] = "sport_news_event"
        return result
    primary = _clean_title(raw, keep_accents=True)
    if not primary:
        result["skip"] = True
        result["skip_reason"] = "empty_after_clean"
        return result
    result["cache_title"] = str_encode(primary.lower())
    result["search_candidates"] = [str_encode(primary.lower())]
    return result

# ---------------------------------------------------------------------------
# NAME CLEANING (Shared)
# ---------------------------------------------------------------------------
def clean_name(name):
    """Sanitize event/channel names - ALL renderers use this"""
    try:
        name = name.replace("\xc2\x86", "").replace("\xc2\x87", "")
        name = name.replace(u"\x86", u"").replace(u"\x87", u"")
    except Exception:
        pass
    return name or ""

def direct_poster_path(clean_title, folder):
    """Build file path - ALL renderers use this"""
    if not clean_title:
        return None
    return "%s/%s.jpg" % (folder, clean_title)

# ---------------------------------------------------------------------------
# GENRE FORMATTING
# ---------------------------------------------------------------------------
def format_genres(genres_string):
    if not genres_string:
        return ""
    genres = [g.strip() for g in genres_string.split(',') if g.strip()]
    if not genres:
        return ""
    return " • ".join(genres)

# ---------------------------------------------------------------------------
# BATCH POSTER HELPER
# ---------------------------------------------------------------------------
def _find_scan_state_path():
    for path in [
        "/tmp/XDREAMY/poster/scan_state.json",
        "/media/hdd/XDREAMY/poster/scan_state.json",
        "/media/usb/XDREAMY/poster/scan_state.json",
        "/media/mmc/XDREAMY/poster/scan_state.json"
    ]:
        if os.path.exists(path):
            return path
    return None

_SCAN_PATH_CACHE = _find_scan_state_path()

def get_batch_poster_data(event_titles):
    if not event_titles or not isinstance(event_titles, list):
        return {}
    valid_titles = [t for t in event_titles if t and isinstance(t, str)]
    if not valid_titles:
        return {}
    scan_path = _SCAN_PATH_CACHE
    if not scan_path or not os.path.exists(scan_path):
        scan_path = _find_scan_state_path()
        if not scan_path:
            return {}
    try:
        with open(scan_path, 'r') as f:
            data = json.load(f)
        entries = data.get('entries', data) if isinstance(data, dict) else {}
        if not isinstance(entries, dict):
            return {}
        poster_folder = os.path.dirname(scan_path)
        results = {}
        for title in valid_titles:
            entry = entries.get(title, {})
            if entry.get('status') in ['ok', 'found']:
                results[title] = {
                    'poster_path': os.path.join(poster_folder, title + '.jpg'),
                    'rating': entry.get('vote_average', 0),
                    'parental': entry.get('parental_rating', ''),
                    'genres': format_genres(entry.get('genres', '')),
                    'year': entry.get('year', ''),
                    'overview': entry.get('overview', '')
                }
        return results
    except Exception:
        return {}

def get_single_poster_data(clean_title):
    if not clean_title:
        return None
    batch = get_batch_poster_data([clean_title])
    return batch.get(clean_title)