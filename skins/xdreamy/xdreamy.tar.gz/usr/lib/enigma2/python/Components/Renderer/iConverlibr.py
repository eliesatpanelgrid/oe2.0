#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iConverlibr.py - XDREAMY SKIN V7.1.0
Safe optimisations: dynamic event cap, file cache, filtered JSON load.
Overlay merged in _load_json_once. Timer 20ms.
FIXES:
 - metadata_resolved only set if useful data present
 - get_zap_context no longer loads full JSON
 - fallback functions use per‑title JSON load
 - EPG cache refreshes after 1s if empty (fixes missing info on zap)
 - Improved cleaning order: raw, stripped, cleaned, cleaned&stripped
 - Expanded skip lists to reduce unnecessary API calls
 - BACKDROP_SIZE config (w300, w500, w780, w1280, original)
"""

from __future__ import absolute_import

import os
import re
import sys
import json
import threading
import time
import unicodedata

try:
    unicode
except NameError:
    unicode = str

from enigma import eEPGCache, eTimer
from .iDebugTrace import trace, timed_block

# ============================================================================
# RUNTIME CONFIGURATION
# ============================================================================

_runtime_cfg = {
    "TMDB_LANGUAGE":     "en",
    "POSTERX_ENABLED":   True,
    "BACKDROPX_ENABLED": True,
    "LOGOX_ENABLED":     False,
    "STORAGE_PATH":      None,
    "WORKER_THREADS":    6,
    "TMDB_API_KEY":      "3c3efcf47c3577558812bb9d64019d65",
    "RTL_OVERVIEW":      True,
    "BACKDROP_SIZE":     "w500",          # w300, w500, w780, w1280, original
}

def get_cfg(key):
    return _runtime_cfg.get(key, None)

def apply_plugin_config(plugin_cfg):
    def _v(attr, default):
        try:
            return getattr(plugin_cfg, attr).value
        except Exception:
            return default

    _runtime_cfg["TMDB_LANGUAGE"]     = _v("tmdb_language",       "en")
    _runtime_cfg["POSTERX_ENABLED"]   = _v("posterx_enabled",     True)
    _runtime_cfg["BACKDROPX_ENABLED"] = _v("backdropx_enabled",   True)
    _runtime_cfg["LOGOX_ENABLED"]     = _v("logox_enabled",       False)
    _runtime_cfg["WORKER_THREADS"]    = int(_v("worker_threads",  "6"))
    _runtime_cfg["TMDB_API_KEY"]      = _v("tmdb_api_key",        "3c3efcf47c3577558812bb9d64019d65")
    _runtime_cfg["RTL_OVERVIEW"]      = _v("rtl_overview",        True)
    _runtime_cfg["BACKDROP_SIZE"]     = _v("backdrop_size",       "w500")

    mode = _v("storage_mode", "auto")
    if mode == "custom":
        _runtime_cfg["STORAGE_PATH"] = _v("storage_custom_path", "/media/hdd/XDREAMY").rstrip("/")
    else:
        _runtime_cfg["STORAGE_PATH"] = None

    _init_folders()
    invalidate_zap_context(force=True)

# ============================================================================
# STORAGE PATHS – ALWAYS LIVE
# ============================================================================

def _get_base_path():
    custom = _runtime_cfg.get("STORAGE_PATH")
    if custom:
        try:
            os.makedirs(custom, exist_ok=True)
        except OSError:
            pass
        if os.path.basename(custom) == "XDREAMY":
            base = custom
        else:
            base = os.path.join(custom, "XDREAMY")
        try:
            os.makedirs(base, exist_ok=True)
        except OSError:
            pass
        if os.path.isdir(base):
            return base

    for mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
        if os.path.exists(mount) and os.access(mount, os.W_OK):
            path = os.path.join(mount, "XDREAMY")
            try:
                os.makedirs(path, exist_ok=True)
            except OSError:
                pass
            return path

    fallback = "/tmp/XDREAMY"
    try:
        os.makedirs(fallback, exist_ok=True)
    except OSError:
        pass
    return fallback

def _init_folders():
    base = _get_base_path()
    for sub in ["poster", "backdrop", "logo", "backup"]:
        try:
            os.makedirs(os.path.join(base, sub), exist_ok=True)
        except OSError:
            pass
    return base

_BASE = _init_folders()

def get_scan_state_file():
    return os.path.join(_get_base_path(), "scan_state.json")

def get_poster_folder():
    return os.path.join(_get_base_path(), "poster")

def get_backdrop_folder():
    return os.path.join(_get_base_path(), "backdrop")

def get_logo_folder():
    return os.path.join(_get_base_path(), "logo")

def get_backup_folder():
    return os.path.join(_get_base_path(), "backup")

# Legacy aliases – functions for live path
def SHARED_PATH():      return _get_base_path()
def SCAN_STATE_FILE():  return get_scan_state_file()
def POSTER_FOLDER():    return get_poster_folder()
def BACKDROP_FOLDER():  return get_backdrop_folder()
def LOGO_FOLDER():      return get_logo_folder()

# ============================================================================
# FILE EXISTENCE CACHE (5s TTL)
# ============================================================================

_file_cache = {}
_file_cache_lock = threading.RLock()
_FILE_CACHE_TTL = 5

def file_exists_cached(path):
    with _file_cache_lock:
        now = time.time()
        if path in _file_cache:
            ts, exists = _file_cache[path]
            if now - ts < _FILE_CACHE_TTL:
                return exists
        exists = os.path.exists(path)
        _file_cache[path] = (now, exists)
        return exists

def invalidate_file_cache(path=None):
    with _file_cache_lock:
        if path is None:
            _file_cache.clear()
        else:
            _file_cache.pop(path, None)

# ============================================================================
# WIDGET PRESENCE FLAGS (only backdrop and logo – metadata is always built)
# ============================================================================

_backdrop_slots_registered = [False]
_logo_slots_registered     = [False]

def register_backdrop_slot(nxts=0):
    _backdrop_slots_registered[0] = True

def register_logo_slot(nxts=0):
    _logo_slots_registered[0] = True

def backdrop_widget_present():
    return _backdrop_slots_registered[0]

def logo_widget_present():
    return _logo_slots_registered[0]

# ============================================================================
# RTL TEXT HELPER
# ============================================================================

_RTL_RE = re.compile(
    u"[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF"
    u"\u0590-\u05FF\uFB00-\uFB4F]",
    re.UNICODE)
_RTL_WRAP = 70

def _is_rtl(text):
    if not text:
        return False
    sample = text[:120]
    return len(_RTL_RE.findall(sample)) > len(sample) * 0.25

def _wrap_rtl(text, width=_RTL_WRAP):
    words, lines, line, length = text.split(), [], [], 0
    for w in words:
        wl = len(w)
        if length + wl + (1 if line else 0) > width and line:
            lines.append(" ".join(line))
            line, length = [w], wl
        else:
            line.append(w)
            length += wl + (1 if len(line) > 1 else 0)
    if line:
        lines.append(" ".join(line))
    return "\n".join(lines)

def format_overview(text):
    if not text:
        return text
    if _runtime_cfg.get("RTL_OVERVIEW", True) and _is_rtl(text):
        return _wrap_rtl(text)
    return text

# ============================================================================
# METADATA CALLBACK SYSTEM – immediate dispatch
# ============================================================================

_metadata_callbacks     = {}
_metadata_callback_lock = threading.Lock()
_ready_queue            = []
_ready_queue_lock       = threading.Lock()

def register_metadata_callback(clean_title, callback):
    if not clean_title or callback is None:
        return
    with _metadata_callback_lock:
        bucket = _metadata_callbacks.setdefault(clean_title, [])
        if callback not in bucket:
            bucket.append(callback)

def unregister_metadata_callback(clean_title, callback):
    with _metadata_callback_lock:
        bucket = _metadata_callbacks.get(clean_title)
        if not bucket:
            return
        try:
            bucket.remove(callback)
        except ValueError:
            return
        if not bucket:
            del _metadata_callbacks[clean_title]

def notify_metadata_callbacks(clean_title):
    if not clean_title:
        return
    with _ready_queue_lock:
        _ready_queue.append(("meta", clean_title, None))
    _trigger_drain()

def queue_gui_callback(callback, *args):
    if callback is None:
        return
    with _ready_queue_lock:
        _ready_queue.append(("call", callback, args))
    _trigger_drain()

def _trigger_drain():
    try:
        from enigma import eApp
        if eApp.isGuiThread():
            _drain_ready_queue()
        else:
            _gui_dispatcher_timer.start(20, True)
    except Exception:
        _gui_dispatcher_timer.start(20, True)

def _drain_ready_queue():
    with _ready_queue_lock:
        if not _ready_queue:
            return
        items = _ready_queue[:]
        del _ready_queue[:]

    for kind, a, b in items:
        if kind == "meta":
            with _metadata_callback_lock:
                cbs = _metadata_callbacks.pop(a, [])
            for cb in cbs:
                try:
                    cb()
                except Exception as e:
                    trace("Dispatcher", "meta-EXCEPTION", "title=%s err=%s" % (a, e))
        elif kind == "call":
            try:
                a(*b)
            except Exception as e:
                trace("Dispatcher", "call-EXCEPTION", str(e))

    try:
        _gui_dispatcher_timer.start(20, True)
    except Exception:
        pass

_gui_dispatcher_timer = eTimer()
_gui_dispatcher_timer.callback.append(_drain_ready_queue)
_gui_dispatcher_timer.start(20, True)

# ============================================================================
# WORD LISTS, TITLE CLEANING
# ============================================================================

SKIP_CHANNEL_KEYWORDS = [
    "sport", "sports", "espn", "eurosport", "bein sport", "dazn", "sky sport", "fox sport", "nba tv", "nfl network", "golf channel", "motorsport", "racing", "tennis channel", "news", "cnn", "bbc news", "fox news", "sky news", "al jazeera", "bloomberg", "weather", "meteo", "axn spin", "axn black", "axn white",
]

SKIP_EVENT_KEYWORDS = [
    " @ ", "match", "game day", "zakończenie programu", " cup ", "playoff", "tournament", "grand prix", "formula 1", "football", "soccer", "basketball", "tennis", "golf", "baseball", "piłka", "coppa del mondo",
]

NO_INFORMATION_WORDS = [
    "no information", "no info", "no event info", "press epg", "info - wcisnij", "blok promocyjny axn spin", "blok promocyjny axn black", "blok promocyjny axn white", "zakończenie programu", "blok promocyjny", "previsioni sulla viabilità", "tg4 - ultima ora", "1mattina news", "studio aperto - la giornata", "info - wciśnij przycisk", "telezakupy", "serwis info", "sottovoce e dintorni", "o anche no", "la promesa - pałac tajemnic", "eska tv info", "4 di sera", "podwójna gorąca 20", "frigo fregoli", "kołowrotek", "dorwać tuńczyka", "zelig - editing", "santo subito", "koncert wielkanocny", "superludzie extra", "przed ekranem", "gimnastyka dla smyka", "uczę się angielskiego", "i nie opuscisz mnie az do smierci", "komisarz cassandre", "italian beauty", "geo magazine", "doc - serre calabresi", "zagadka tygodnia", "na dobre i na złe", "remont na 5", "aukcja w ciemno", "kabaretowe hity", "seriaale", "ukryta prawda", "najgorsi kierowcy świata", "senza sconti", "la nostra africa", "ii wojna światowa - jednostki specjalne", "dzieciaki rządzą", "króliczek bing", "w papierowej krainie", "hej, duggee", "staś da radę", "numeraki", "teta rahiba", "eyoon al sakr", "saaet rida", "kolohom awladi", "pełna chata", "malanowski i partnerzy", "migotki", "przeboje dla dzieci", "zasypiamy", "domisie", "najbardziej luksusowe", "satoshi", "smieszniej nie bedzie", "top gear", "za murami piekła", "milczaca odwaga", "kabaretowa ekstraklasa", "kabaret letnią porą", "kabaretowy śmiech", "mistrzowie kabaretu", "hitler", "boccaccio", "la sai l'ultima?", "criminal minds", "wild cards", "fire country", "coroner", "via dei matti", "overland", "doc nelle tue mani", "candice renoir", "un medico in famiglia", "re_mind", "po pierwsze kino", "gigi e vanessa", "paradisi naturali", "inzynierowie hitlera", "czołgi", "sekrety zbrodni", "influencerzy śmierci", "notti mondiali", "lato z radiem", "om kolthoum", "saha w nos", "nikhil i jay", "dobranocny ogrod", "cudowny świat mikiego", "kroniki seryjnych mordercow", "pracoholicy", "zdrady", "strzelnica navala", "grono nie-pedagogiczne", "the daily show", "tv okazje", "63. kfpp w opolu", "hity wszech czasów", "koło fortuny", "drive up summer edition", "sport mediaset", "maldives", "motyw mordercy", "نأنأة", "زي السكر", "أميرة في المطبخ", "زعفران و فانيلا", "سفرة المونديال", "حكايتى", "يوم ورا يوم", "ست ستات", "جديد وسريع", "على قد الإيد", "عرب وود",
]

JUNK_WORDS = [
    "primatv", "primatime", "mediaset extra", "mediaset", "axn black", "axn spain", "axn", "filler cine34", "4fun kids", "4FUN KIDS", "4FUN", "full movie", "full episode", "making of", "behind the scenes", "pełny film", "cały film", "ekskluzywny", "zapowiedź", "zwiastun", "wywiad", "kompilacja", "kolekcja", "RAINEWS24", "حلقه مجمعه", "مسلسل",
]

_CHINESE_PATTERNS_RAW = [
    r'^(?:陪伴剧场|长江剧场|下午茶剧场|温情剧场|郁金香剧场|索芙特剧场|阳光剧场|'
    r'偶像独播剧场|偶像剧场|英雄剧场|爱家剧场|花雨剧场|真情剧场|情感剧场|上午剧场|'
    r'下午剧场|白天剧场|雄关剧场|红石榴剧场|百姓剧场|午夜剧场|经典剧场第\d{1,4}集|'
    r'传奇剧场|经典剧场|幸福剧场|中国龙剧场|北方剧场|海豚第一剧场|丝路长安剧场|'
    r'金鹰独播剧场|东南剧苑|第一挑战剧场|黄金剧场|民生剧场|花漾剧场|精彩赏析|'
    r'本集提要:|电视剧场|中国蓝剧场|金牌剧场|院线上新|美丽剧场|活力剧场|'
    r'精彩音乐汇-|五星剧场-|品质剧场|HD_|【本台首播】|【星光首映场】|'
    r'未央影院：|万象剧场：|电视剧场 <|动作导视)[\s:：、]*',
    r'[\s\-—]*第[一二三四五六七八九十\d]+[季部集][\s\-—]*',
    r'[\s\-—]*\d{1,4}集[\s\-—]*',
    r'[\s\-—]*\d+[/\-]\d+[\s\-—]*$',
    r'[（\(\[].*?[）\)\]]',
    r'[《》〈〉「」『』【】〖〗\u201c\u201d\u2018\u2019]',
]
_CHINESE_PAT = [re.compile(p, re.IGNORECASE | re.UNICODE) for p in _CHINESE_PATTERNS_RAW]

def _is_chinese(text):
    for ch in text:
        cp = ord(ch)
        if 0x4E00 <= cp <= 0x9FFF or 0x3400 <= cp <= 0x4DBF:
            return True
    return False

def _apply_chinese_cleaning(text):
    if not text or not _is_chinese(text):
        return text
    for pat in _CHINESE_PAT:
        text = pat.sub("", text)
    for sep in [u"：", u":"]:
        if sep in text:
            parts = text.split(sep, 1)
            if len(parts[0].strip()) > 2:
                text = parts[0].strip()
                break
    text = re.sub(r'[-,?!/\.":\|]', " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"\s\d{4}$", "", text)
    return text

# ============================================================================
# REGEX, TEXT HELPERS (unchanged)
# ============================================================================

_RE_CTRL        = re.compile(u"[\x00-\x1f\x7f\x86\x87]")
_RE_YEAR_BRKT   = re.compile(r"\(\s*(?:19|20)\d{2}\s*\)", re.I)
_RE_SXE         = re.compile(r"\bS(\d{1,2})E\d{1,3}\b", re.I)
_RE_XEP         = re.compile(r"\b(\d{1,2})x\d{1,3}\b", re.I)
_RE_SDASH       = re.compile(r"\bS(\d+)\s*-\s*\d+\b", re.I)
_RE_SEASON      = re.compile(r"\b(?:season|saison|series|serie|sezon|موسم|الموسم)\s*(\d+)\b", re.I | re.U)
_RE_EPISODE     = re.compile(r"\b(?:odc|odcinek|ep|episode|episodio|folge|teil|حلقة|الحلقة)\s*[:.]?\s*\d+\b", re.I | re.U)
_RE_PART        = re.compile(r"\b(?:part|pt|vol|volume)\s*[:.]?\s*\d+\b", re.I)
_RE_AR_EP       = re.compile(r"\s*(?:ح|الحلقة|الموسم)\s*\d*\s*$", re.I | re.U)
_RE_TRAIL_RANGE = re.compile(r"(\b\d+)\s*[\-_:|/\\]+\s*\d+\s*$", re.I)
_RE_SBRKT       = re.compile(r"\(\s*S(\d+)\s*\)", re.I)
_RE_LIVE        = re.compile(r"\(\s*live\s*\)", re.I)
_RE_JUNK        = re.compile(r"\b(?:%s)\b" % "|".join(re.escape(x) for x in JUNK_WORDS), re.I)
_RE_QUALITY     = re.compile(r"\b(?:\d{3,4}p|4K|UHD|SD|HDR|Dolby|Atmos)\b", re.I)
_RE_LANG_TAG    = re.compile(r"[\(\{\[]\s*(?:LEKTOR|NAPISY|VO|DUBBING|PL|EN|ENG|POL)\s*[\)\}\]]", re.I)
_RE_ASPECT      = re.compile(r"\b(?:\d{3,4}x\d{3,4}|16:9|4:3|2\.35:1)\b", re.I)
_RE_FILL_BRKT   = re.compile(r"\([^\)]*(?:live|repeat|encore|marathon|bonus|lektor|napisy|vo|dubbing)[^\)]*\)", re.I)
_RE_POLISH      = re.compile(r"(?:^|\s)(?:serial|sezon|premiera|powtorka|magazyn|reporta[żz])\b|(?:^|\s)(?:odcinek)\s+\d+", re.I | re.U)
_RE_SYM2SPC     = re.compile(r"[-:._]")
_RE_OTHER_SYM   = re.compile(r"[()\[\]{}|+!@#$%^&*]")
_RE_SPACES      = re.compile(r"\s+")
_RE_TRAIL_SEP   = re.compile(r"[\s\-_:\|/\\]+$")
_RE_TRAIL_NUM   = re.compile(r"^(.*\S)\s+(\d{1,4})$")

def to_text(value, encoding="utf-8"):
    if value is None:
        return u""
    if isinstance(value, unicode):
        return value
    try:
        return unicode(value, encoding, "ignore")
    except Exception:
        try:
            return unicode(value)
        except Exception:
            return u""

def is_arabic(text):
    if not text:
        return False
    for ch in text[:100]:
        code = ord(ch)
        if (0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F
                or 0xFB50 <= code <= 0xFDFF or 0xFE70 <= code <= 0xFEFF):
            return True
    return False

def remove_accents(text):
    try:
        nfd = unicodedata.normalize("NFKD", text)
        return u"".join(c for c in nfd if not unicodedata.combining(c))
    except Exception:
        return text

def _clean_title(text, keep_accents=False):
    text = to_text(text).strip()
    if not text:
        return u""
    text = _apply_chinese_cleaning(text)
    if not text:
        return u""
    arabic = is_arabic(text)
    if arabic:
        text = _RE_AR_EP.sub("", text).strip()
    text = _RE_CTRL.sub("", text)
    text = _RE_TRAIL_RANGE.sub(r"\1", text)
    text = _RE_YEAR_BRKT.sub("", text)
    text = _RE_QUALITY.sub("", text)
    text = _RE_LANG_TAG.sub("", text)
    text = _RE_ASPECT.sub("", text)
    text = _RE_FILL_BRKT.sub("", text)
    text = _RE_POLISH.sub("", text)
    if not arabic:
        text = _RE_SXE.sub(r"\1", text)
        text = _RE_XEP.sub(r"\1", text)
        text = _RE_SDASH.sub(r"\1", text)
    text = _RE_SEASON.sub(r"\1", text)
    has_ep = bool(_RE_EPISODE.search(text))
    text = _RE_EPISODE.sub("", text)
    if has_ep:
        text = _RE_PART.sub("", text)
    text = _RE_SBRKT.sub(r"\1", text)
    text = _RE_LIVE.sub("", text)
    text = _RE_JUNK.sub("", text)
    text = _RE_SYM2SPC.sub(" ", text)
    text = _RE_OTHER_SYM.sub("", text)
    text = _RE_SPACES.sub(" ", text).strip()
    text = _RE_TRAIL_SEP.sub("", text)
    if not arabic:
        m = _RE_TRAIL_NUM.match(text)
        if m:
            try:
                num = int(m.group(2))
                if num == 1 or num > 99:
                    text = m.group(1).strip()
            except Exception:
                pass
    if not keep_accents and not arabic:
        text = remove_accents(text)
    return text.strip()

def convtext_raw(text):
    return _clean_title(text, keep_accents=False).lower()

# ============================================================================
# TITLE CACHE
# ============================================================================

class _TitleCache(object):
    def __init__(self, maxsize=1000):
        self._d   = {}
        self._max = maxsize

    def get(self, raw):
        if not raw:
            return ""
        v = self._d.get(raw)
        if v is not None:
            return v
        cleaned = convtext_raw(raw)
        if len(self._d) >= self._max:
            self._d.pop(next(iter(self._d)))
        self._d[raw] = cleaned
        return cleaned

_title_cache = _TitleCache()

def convtext(text=u""):
    if not text:
        return ""
    return _title_cache.get(text)

def clean_name(name):
    return _clean_name_str(name)

# ============================================================================
# EPG CACHE – WITH REFRESH ON EMPTY
# ============================================================================

class _EpgCache(object):
    def __init__(self):
        self._data = []
        self._ref  = None
        self._last_fetch = 0

    def get(self, service_ref):
        if not service_ref:
            return []
        ref_str = service_ref.toString()
        now = time.time()
        if self._ref == ref_str and self._data and (now - self._last_fetch < 2.0):
            return self._data
        if self._ref == ref_str and not self._data and (now - self._last_fetch < 1.0):
            return self._data
        events = []
        try:
            epg = eEPGCache.getInstance()
            if epg:
                result = epg.lookupEvent(["IBOCTESX", (ref_str, 0, -1, -1)])
                if result:
                    events = result
        except Exception:
            pass
        self._data = events
        self._ref  = ref_str
        self._last_fetch = now
        return events

_epg_cache = _EpgCache()

# ============================================================================
# HELPERS
# ============================================================================

def _clean_name_str(name):
    try:
        name = name.replace("\xc2\x86", "").replace("\xc2\x87", "")
        name = name.replace(u"\x86", u"").replace(u"\x87", u"")
    except Exception:
        pass
    return name or ""

def _format_genres(genres_string):
    if not genres_string:
        return ""
    parts = [g.strip() for g in genres_string.split(",") if g.strip()]
    return u" \u2022 ".join(parts)

def _is_no_info(text):
    low = to_text(text).lower().strip()
    if not low:
        return True
    for word in NO_INFORMATION_WORDS:
        if word.lower() in low:
            return True
    return False

def _analyze(raw):
    if not raw or _is_no_info(raw):
        return True, "", []
    if any(x in (" " + raw.lower() + " ") for x in SKIP_EVENT_KEYWORDS):
        return True, "", []

    clean = _title_cache.get(raw)
    if not clean:
        return True, "", []

    candidates = [raw]

    stripped_raw = raw
    stripped_raw = re.sub(r'\s+\d{1,2}\s*$', '', stripped_raw)
    stripped_raw = re.sub(r'\s*[Ss](\d+)\s*', '', stripped_raw)
    stripped_raw = re.sub(r'\s*odc\.?\s*\d+', '', stripped_raw, flags=re.I)
    stripped_raw = re.sub(r'\s*sezon\s*\d+', '', stripped_raw, flags=re.I)
    stripped_raw = re.sub(r'\s*[\(\[]\s*odc\.?\s*\d+\s*[\)\]]', '', stripped_raw, flags=re.I)
    stripped_raw = re.sub(r'[:\-]\s*odc\.?\s*\d+', '', stripped_raw, flags=re.I)
    stripped_raw = re.sub(r'\s*episode\s*\d+', '', stripped_raw, flags=re.I)
    stripped_raw = re.sub(r'\s*[Ss]aison\s*\d+', '', stripped_raw, flags=re.I)
    stripped_raw = re.sub(r'\s*part\s*\d+', '', stripped_raw, flags=re.I)
    stripped_raw = re.sub(r'[:\-]\s*$', '', stripped_raw)
    stripped_raw = stripped_raw.strip()
    if stripped_raw and stripped_raw != raw:
        candidates.append(stripped_raw)

    if clean != raw:
        candidates.append(clean)

    stripped_clean = clean
    stripped_clean = re.sub(r'\s+\d{1,2}\s*$', '', stripped_clean)
    stripped_clean = re.sub(r'\s*[Ss](\d+)\s*', '', stripped_clean)
    stripped_clean = re.sub(r'\s*odc\.?\s*\d+', '', stripped_clean, flags=re.I)
    stripped_clean = re.sub(r'\s*sezon\s*\d+', '', stripped_clean, flags=re.I)
    stripped_clean = re.sub(r'\s*[\(\[]\s*odc\.?\s*\d+\s*[\)\]]', '', stripped_clean, flags=re.I)
    stripped_clean = re.sub(r'[:\-]\s*odc\.?\s*\d+', '', stripped_clean, flags=re.I)
    stripped_clean = re.sub(r'\s*episode\s*\d+', '', stripped_clean, flags=re.I)
    stripped_clean = re.sub(r'\s*[Ss]aison\s*\d+', '', stripped_clean, flags=re.I)
    stripped_clean = re.sub(r'\s*part\s*\d+', '', stripped_clean, flags=re.I)
    stripped_clean = re.sub(r'[:\-]\s*$', '', stripped_clean)
    stripped_clean = stripped_clean.strip()
    if stripped_clean and stripped_clean != clean:
        candidates.append(stripped_clean)

    candidates = list(dict.fromkeys(candidates))[:4]

    return False, clean, candidates

# ============================================================================
# JSON STATE – FILTERED LOOKUP (with overlay)
# ============================================================================

_json_cache_data  = {}
_json_cache_mtime = None
_state_overlay_fn = [None]

def set_state_overlay_fn(fn):
    _state_overlay_fn[0] = fn

def _load_json_once(needed_titles=None):
    global _json_cache_data, _json_cache_mtime
    scan_file = get_scan_state_file()
    try:
        if not os.path.exists(scan_file):
            if _json_cache_mtime is not None:
                _json_cache_data  = {}
                _json_cache_mtime = None
        else:
            mtime = os.path.getmtime(scan_file)
            if _json_cache_mtime is None or mtime != _json_cache_mtime:
                with open(scan_file, "r") as f:
                    raw = json.load(f)
                _json_cache_data  = raw.get("entries", raw) if isinstance(raw, dict) else {}
                _json_cache_mtime = mtime
    except Exception as e:
        trace("JSON-cache", "EXCEPTION", str(e))

    fn = _state_overlay_fn[0]
    if fn is not None:
        try:
            overlay = fn()
            if overlay:
                _json_cache_data.update(overlay)
        except Exception:
            pass

    if needed_titles:
        return {t: _json_cache_data.get(t, {}) for t in needed_titles}
    return _json_cache_data

# ============================================================================
# METADATA USEFULNESS CHECK
# ============================================================================

def _has_useful_metadata(entry):
    if not entry:
        return False
    if entry.get('status') not in ('ok', 'found'):
        return False
    if entry.get('vote_average', 0) > 0:
        return True
    if entry.get('parental_rating'):
        return True
    if entry.get('genres'):
        return True
    if entry.get('year'):
        return True
    if entry.get('director'):
        return True
    if entry.get('cast'):
        return True
    if len(entry.get('overview', '')) > 50:
        return True
    if entry.get('title'):
        return True
    return False

# ============================================================================
# ZAP CONTEXT – SINGLE BATCH, SMART CACHING
# ============================================================================

_registered_nxts = set()
_max_nxts        = [5]

def register_nxts_slot(nxts):
    try:
        nxts = int(nxts)
    except Exception:
        return
    if nxts < 0:
        return
    _registered_nxts.add(nxts)
    if nxts + 1 > _max_nxts[0]:
        _max_nxts[0] = nxts + 1

class ZapContext(object):
    __slots__ = ("_ref_str", "_slots", "_ch_skip", "_slot_count",
                 "generation", "created_at", "missing_posters",
                 "missing_backdrops", "missing_logos")

    def __init__(self, ref_str, events, json_data, ch_skip=False, generation=0):
        self._ref_str          = ref_str
        self._ch_skip          = ch_skip
        self.generation        = generation
        self.created_at        = time.time()
        self._slot_count       = 0
        self._slots            = {}
        self.missing_posters   = []
        self.missing_backdrops = []
        self.missing_logos     = []
        if events:
            self._build(events, json_data)

    def _build(self, events, json_data):
        cap = _max_nxts[0]
        if len(events) > cap:
            events = events[:cap]
        self._slot_count = len(events)

        slot_raw = {}
        for nxts, evt in enumerate(events):
            if len(evt) >= 5 and evt[4]:
                raw  = _clean_name_str(evt[4])
                desc = evt[5] if len(evt) > 5 else ""
                slot_raw[nxts] = (raw, evt[1], desc)

        unique_raw = set(r for r, _, _ in slot_raw.values())
        clean_map  = {raw: _analyze(raw) for raw in unique_raw}
        unique_clean = set(c for _, c, _ in clean_map.values() if c)

        pfolder  = get_poster_folder()
        bfolder  = get_backdrop_folder()
        lfolder  = get_logo_folder()

        exists_p = {}
        exists_b = {}
        exists_l = {}
        for title in unique_clean:
            p = os.path.join(pfolder, title + ".jpg")
            if file_exists_cached(p):
                exists_p[title] = p

            if _backdrop_slots_registered[0]:
                b = os.path.join(bfolder, title + ".jpg")
                if file_exists_cached(b):
                    exists_b[title] = b

            if _logo_slots_registered[0]:
                l = os.path.join(lfolder, title + ".png")
                if file_exists_cached(l):
                    exists_l[title] = l

        needed_titles = set(unique_clean)
        json_filtered = _load_json_once(needed_titles)

        meta_map = {}
        for title in unique_clean:
            entry = json_filtered.get(title, {})
            if _has_useful_metadata(entry):
                rv = entry.get('vote_average', 0)
                try:
                    rv = float(rv) if rv else 0
                except Exception:
                    rv = 0
                ov = entry.get('overview', '') or ''
                meta_map[title] = {
                    "rating":            rv,
                    "parental":          entry.get('parental_rating', ''),
                    "genres":            _format_genres(entry.get('genres', '')),
                    "year":              entry.get('year', ''),
                    "overview":          format_overview(ov),
                    "plot":              format_overview(ov),
                    "title":             entry.get('title', title),
                    "country":           entry.get('country', ''),
                    "director":          entry.get('director', ''),
                    "cast":              entry.get('cast', ''),
                    "rated":             entry.get('parental_rating', ''),
                    "imdb":              str(rv) if rv > 0 else '',
                    "metadata_resolved": True,
                }
            else:
                meta_map[title] = {
                    "rating": 0, "parental": "", "genres": "", "year": "",
                    "overview": "", "plot": "", "title": "", "country": "",
                    "director": "", "cast": "", "rated": "", "imdb": "",
                    "metadata_resolved": False,
                }

        missing_p, missing_b, missing_l = [], [], []
        seen = set()

        for nxts, (raw, begin_time, desc) in slot_raw.items():
            skip, clean, candidates = clean_map[raw]
            skip = skip or self._ch_skip
            meta = meta_map.get(clean, {})

            if clean and not skip and clean not in seen:
                seen.add(clean)
                if clean not in exists_p:
                    missing_p.append((clean, candidates, raw, desc, begin_time))
                if _backdrop_slots_registered[0] and clean not in exists_b:
                    missing_b.append((clean, candidates, raw, desc, begin_time))
                if _logo_slots_registered[0] and clean not in exists_l:
                    missing_l.append((clean, candidates, raw, desc, begin_time))

            self._slots[nxts] = {
                "clean_title":       clean,
                "local_path":        exists_p.get(clean),
                "backdrop_path":     exists_b.get(clean),
                "logo_path":         exists_l.get(clean),
                "skip":              skip,
                "search_candidates": candidates,
                "event_key":         "%s-%s" % (begin_time, raw),
                "raw_name":          raw,
                "description":       desc,
                "metadata_resolved": meta.get("metadata_resolved", False),
                "rating":            meta.get("rating", 0),
                "parental":          meta.get("parental", ""),
                "genres":            meta.get("genres", ""),
                "year":              meta.get("year", ""),
                "overview":          meta.get("overview", ""),
                "plot":              meta.get("plot", ""),
                "title":             meta.get("title", ""),
                "country":           meta.get("country", ""),
                "director":          meta.get("director", ""),
                "cast":              meta.get("cast", ""),
                "rated":             meta.get("rated", ""),
                "imdb":              meta.get("imdb", ""),
            }

        self.missing_posters   = missing_p
        self.missing_backdrops = missing_b
        self.missing_logos     = missing_l

    def get_slot(self, nxts):
        if self._slot_count and nxts >= self._slot_count:
            return None
        return self._slots.get(nxts)

    def is_valid_for(self, ref_str):
        return self._ref_str == ref_str

    @property
    def ref_str(self):
        return self._ref_str


# ============================================================================
# ZAP CONTEXT MANAGER – SMART INVALIDATION
# ============================================================================

_zap_ctx     = None
_zap_ctx_lock = threading.Lock()
_zap_ctx_gen  = [0]
_current_service_ref = [None]
_current_ref_lock = threading.Lock()

def set_current_service_ref(ref_str):
    with _current_ref_lock:
        _current_service_ref[0] = ref_str

def get_current_service_ref():
    with _current_ref_lock:
        return _current_service_ref[0]

def invalidate_zap_context(force=False, for_title=None):
    if force:
        global _zap_ctx
        with _zap_ctx_lock:
            _zap_ctx = None
        return

    current_ref = get_current_service_ref()
    if not current_ref:
        return
    ctx = _zap_ctx
    if ctx is None or not ctx.is_valid_for(current_ref):
        return

    if for_title:
        for slot in ctx._slots.values():
            if slot.get("clean_title") == for_title:
                with _zap_ctx_lock:
                    _zap_ctx = None
                return
    else:
        with _zap_ctx_lock:
            _zap_ctx = None

_batch_poster_fn   = [None]
_batch_backdrop_fn = [None]
_batch_logo_fn     = [None]

def set_batch_poster_queue_fn(fn):
    _batch_poster_fn[0] = fn

def set_batch_backdrop_queue_fn(fn):
    _batch_backdrop_fn[0] = fn

def set_batch_logo_queue_fn(fn):
    _batch_logo_fn[0] = fn

def _submit_missing(ctx):
    pfn = _batch_poster_fn[0]
    bfn = _batch_backdrop_fn[0]
    lfn = _batch_logo_fn[0]

    if pfn:
        for clean, candidates, raw, desc, bt in ctx.missing_posters:
            canal = ["", "%s-%s" % (bt, raw), raw, desc, raw, raw]
            try:
                pfn(clean, canal, candidates)
            except Exception:
                pass

    if bfn and _backdrop_slots_registered[0] and get_cfg("BACKDROPX_ENABLED"):
        for clean, candidates, raw, desc, bt in ctx.missing_backdrops:
            canal = ["", "%s-%s" % (bt, raw), raw, desc, raw, raw]
            try:
                bfn(clean, canal)
            except Exception:
                pass

    if lfn and _logo_slots_registered[0] and get_cfg("LOGOX_ENABLED"):
        for clean, candidates, raw, desc, bt in ctx.missing_logos:
            canal = ["", "%s-%s" % (bt, raw), raw, desc, raw, raw]
            try:
                lfn(clean, canal, candidates)
            except Exception:
                pass


def get_zap_context(service_ref):
    global _zap_ctx
    if service_ref is None:
        return None

    ref_str = service_ref.toString()
    set_current_service_ref(ref_str)

    if "FROM BOUQUET" in ref_str or "ORDER BY bouquet" in ref_str:
        return ZapContext("bouquet", [], {}, True, generation=0)

    ctx = _zap_ctx
    if ctx is not None and ctx.is_valid_for(ref_str):
        return ctx

    with _zap_ctx_lock:
        ctx = _zap_ctx
        if ctx is not None and ctx.is_valid_for(ref_str):
            return ctx

        ch_skip = False
        try:
            from ServiceReference import ServiceReference as SR
            ch_name = _clean_name_str(SR(service_ref).getServiceName())
            ch_skip = any(x in ch_name.lower() for x in SKIP_CHANNEL_KEYWORDS)
        except Exception:
            pass

        _zap_ctx_gen[0] += 1
        gen = _zap_ctx_gen[0]

        if ch_skip:
            _zap_ctx = ZapContext(ref_str, [], {}, True, generation=gen)
            return _zap_ctx

        events = _epg_cache.get(service_ref)
        if not events:
            _zap_ctx = ZapContext(ref_str, [], {}, ch_skip, generation=gen)
            return _zap_ctx

        _zap_ctx = ZapContext(ref_str, events, {}, ch_skip, generation=gen)
        _submit_missing(_zap_ctx)

    return _zap_ctx


# ============================================================================
# PUBLIC API
# ============================================================================

def is_sport_or_news_channel(channel_name):
    return any(x in _clean_name_str(channel_name).lower() for x in SKIP_CHANNEL_KEYWORDS)

def get_poster_path(clean_title):
    if not clean_title:
        return None
    return os.path.join(get_poster_folder(), clean_title + ".jpg")


def get_event_source_metadata(event_source):
    try:
        evt = event_source.event
        if not evt:
            return None
        raw = _clean_name_str(evt.getEventName())
        if not raw or _is_no_info(raw):
            return None
        skip, clean, candidates = _analyze(raw)
        if skip or not clean:
            return None
        begin_time = evt.getBeginTime() or 0
        event_key  = "%s-%s" % (begin_time, raw)
        json_data  = _load_json_once({clean})
        entry      = json_data.get(clean, {})
        if _has_useful_metadata(entry):
            rv = entry.get('vote_average', 0)
            try:
                rv = float(rv) if rv else 0
            except Exception:
                rv = 0
            ov = entry.get('overview', '') or ''
            base = {
                "clean_title":       clean,
                "local_path":        None,
                "skip":              False,
                "search_candidates": candidates,
                "event_key":         event_key,
                "raw_name":          raw,
                "description":       evt.getExtendedDescription() or "",
                "metadata_resolved": True,
                "rating":    rv,
                "parental":  entry.get('parental_rating', ''),
                "genres":    _format_genres(entry.get('genres', '')),
                "year":      entry.get('year', ''),
                "overview":  format_overview(ov),
                "plot":      format_overview(ov),
                "title":     entry.get('title', clean),
                "country":   entry.get('country', ''),
                "director":  entry.get('director', ''),
                "cast":      entry.get('cast', ''),
                "rated":     entry.get('parental_rating', ''),
                "imdb":      str(rv) if rv > 0 else '',
            }
        else:
            base = {
                "clean_title":       clean,
                "local_path":        None,
                "skip":              False,
                "search_candidates": candidates,
                "event_key":         event_key,
                "raw_name":          raw,
                "description":       evt.getExtendedDescription() or "",
                "metadata_resolved": False,
                "rating": 0, "parental": "", "genres": "", "year": "",
                "overview": "", "plot": "", "title": "", "country": "",
                "director": "", "cast": "", "rated": "", "imdb": "",
            }
        return base
    except Exception:
        return None


# ============================================================================
# SHARED TMDB SEARCH CACHE
# ============================================================================

_SEARCH_TTL   = 600
_search_cache = {}
_search_lock  = threading.Lock()

def get_cached_search(clean_title):
    if not clean_title:
        return None
    with _search_lock:
        entry = _search_cache.get(clean_title)
        if entry is None:
            return None
        ts, result = entry
        if time.time() - ts > _SEARCH_TTL:
            del _search_cache[clean_title]
            return None
        return result

def set_cached_search(clean_title, result):
    if not clean_title:
        return
    with _search_lock:
        _search_cache[clean_title] = (time.time(), result)
        if len(_search_cache) > 2000:
            for k in sorted(_search_cache, key=lambda k: _search_cache[k][0])[:500]:
                del _search_cache[k]