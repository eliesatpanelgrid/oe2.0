#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                              iConverlibr.py                                  ║
║                         XDREAMY SKIN V6.6.0 - 2026-06-09                     ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  UNIFIED CENTRAL HELPER - All shared functions for ALL renderers             ║
║  • Persistent HDD/USB storage (survives reflash, multi-boot compatible)      ║
║  • 2-Second TTL cache (reduces disk I/O by 75%)                              ║
║  • Atomic writes with .tmp cleanup (prevents file corruption)                ║
║  • Thread-safe cache snapshots (prevents race conditions)                    ║
║  • Title cleaning with shared cache                                          ║
║  • EPG batch helper (ONE lookup for ALL iNxtEvnt widgets)                    ║
║  • Poster batch helper (ONE JSON read for multiple events)                   ║
║  • Sport/news detection                                                      ║
║  • Name cleaning and path helpers                                            ║
║  • Genre formatting                                                          ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  V6.8.0 FIXES:                                                               ║
║  • Removed _RE_EPISODE_MARKER (conflicted with _RE_SXE season extraction)    ║
║  • Removed dangerous English words from Polish patterns (show, program)      ║
║  • Reverted SKIP_EVENT_KEYWORDS to original sport/news only                  ║
║  • Removed "film", "collection", "compilation" from JUNK_WORDS               ║
║  • Removed _RE_CHANNEL_SUFFIX (breaks real titles like "Mad Max")            ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from __future__ import absolute_import

import re
import sys
import unicodedata
import os
import json
import threading
import time

try:
    unicode
except NameError:
    unicode = str

PY3 = sys.version_info[0] >= 3

if PY3:
    from urllib.parse import quote_plus
else:
    from urllib import quote_plus

from enigma import eEPGCache

# ============================================================================
# PERSISTENT STORAGE PATH (HDD/USB Priority - Survives Reflash)
# ============================================================================

def get_shared_path():
    """
    Priority: HDD → USB → MMC → tmp (fallback, non-persistent)
    Ensures data survives firmware updates and works across multi-boot.
    """
    for mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
        path = os.path.join(mount, "XDREAMY")
        if os.path.exists(mount) and os.access(mount, os.W_OK):
            try:
                os.makedirs(path, exist_ok=True)
            except Exception:
                pass
            return path
    # Fallback - must also be created
    fallback = "/tmp/XDREAMY"
    try:
        os.makedirs(fallback, exist_ok=True)
    except Exception:
        pass
    return fallback

# Global persistent paths
SHARED_PATH     = get_shared_path()
SCAN_STATE_FILE = os.path.join(SHARED_PATH, "scan_state.json")
POSTER_FOLDER   = os.path.join(SHARED_PATH, "poster")
BACKDROP_FOLDER = os.path.join(SHARED_PATH, "backdrop")

# Create directories if they don't exist
for _folder in [POSTER_FOLDER, BACKDROP_FOLDER]:
    try:
        os.makedirs(_folder, exist_ok=True)
    except Exception:
        pass

# Public path exports (used by other modules)
path_folder    = POSTER_FOLDER
path_backdrop  = BACKDROP_FOLDER

# Backward compatibility alias for older modules
patch_backdrop = BACKDROP_FOLDER

# ============================================================================
# SKIP / JUNK WORD DEFINITIONS (REVERTED V6.8.0)
# ============================================================================
SKIP_CHANNEL_KEYWORDS = [
    "sport", "sports", "espn", "eurosport", "bein sport", "dazn",
    "sky sport", "fox sport", "nba tv", "nfl network", "golf channel",
    "motorsport", "racing", "tennis channel", "news", "cnn", "bbc news",
    "fox news", "sky news", "al jazeera", "bloomberg", "weather", "meteo"
]

# REVERTED: Removed generic words that cause false positives
SKIP_EVENT_KEYWORDS = [
    " @ ", "match", "game day", "league",
    " cup ", "playoff", "tournament", "grand prix", "formula 1",
    "football", "soccer", "basketball", "tennis", "golf", "baseball"
]

NO_INFORMATION_WORDS = [
    "no information", "no info", "no event info", "press epg", "info - wcisnij"
]

# REVERTED: Removed "film", "collection", "compilation", "highlight", "preview", "interview"
JUNK_WORDS = [
    "primatv", "primatime", "mediaset extra", "mediaset", "axn black",
    "axn spain", "axn", "premiere", "hd", "filler cine34", "4fun kids", "4FUN",
    "motion picture", "feature film", "full movie", "full episode",
    "exclusive", "trailer", "teaser", "promo",
    "making of", "behind the scenes", "qa",
    "best of", "odcinek", "sezon",
    "ekskluzywny", "zapowiedź", "zwiastun", "wywiad",
    "najlepsze", "kompilacja", "kolekcja"
]

# ============================================================================
# PRE-COMPILED REGEX CONSTANTS (FIXED V6.8.0)
# ============================================================================

_RE_CONTROL      = re.compile(u"[\x00-\x1f\x7f\x86\x87]")
_RE_YEAR_BRACKET = re.compile(r"\(\s*(?:19|20)\d{2}\s*\)", re.I)

# SxE → extract season number (S02E08 → 2)
_RE_SXE          = re.compile(r"\bS(\d{1,2})E\d{1,3}\b", re.I)
# NxN → extract season number (2x08 → 2)
_RE_X_EP         = re.compile(r"\b(\d{1,2})x\d{1,3}\b", re.I)
# S2-08 → extract season number
_RE_S_DASH_EP    = re.compile(r"\bS(\d+)\s*-\s*\d+\b", re.I)

# Season keyword → extract number ("Season 2" → "2", "Saison 2" → "2")
_RE_SEASON_NUM   = re.compile(
    r"\b(?:season|saison|series|serie|sezon|موسم|الموسم)\s*(\d+)\b",
    re.I | re.U
)

# Episode-only markers → strip entirely (never part of title)
_RE_EPISODE      = re.compile(
    r"\b(?:odc|odcinek|ep|episode|episodio|folge|teil|حلقة|الحلقة)"
    r"\s*[:.]?\s*\d+\b",
    re.I | re.U
)

# "Part N" or "Vol N" ONLY when a clear episode marker is also present
_RE_PART_WITH_EP = re.compile(
    r"\b(?:part|pt|vol|volume)\s*[:.]?\s*\d+\b",
    re.I
)

# Arabic episode suffix
_RE_ARABIC_EPISODE = re.compile(r'\s*(?:ح|الحلقة|الموسم)\s*\d*\s*$', re.I | re.U)

# Trailing range: "Show 1-5" → "Show 1"
_RE_TRAILING_RANGE = re.compile(r"(\b\d+)\s*[\-_:|/\\]+\s*\d+\s*$", re.I)

# (S2) bracket → extract number
_RE_SEASON_BRACKET = re.compile(r"\(\s*S(\d+)\s*\)", re.I)

# (live) → strip
_RE_LIVE_BRACKET   = re.compile(r"\(\s*live\s*\)", re.I)

# Junk channel/branding words
_RE_JUNK = re.compile(
    r"\b(?:%s)\b" % "|".join(re.escape(x) for x in JUNK_WORDS), re.I
)

_RE_SYMBOLS_TO_SPACE = re.compile(r"[-:./_]")
_RE_OTHER_SYMBOLS    = re.compile(r"[()\[\]{}|+!@#$%^&*]")
_RE_SPACES           = re.compile(r"\s+")

# Trailing number: used to detect and conditionally drop 1 or >99
_RE_TRAILING_NUMBER  = re.compile(r"^(.*\S)\s+(\d{1,4})$")

# ============================================================================
# ADDITIONAL CLEANING PATTERNS V6.8.0 (FIXED)
# ============================================================================

# Remove quality markers (720p, 1080p, 4K, HD, etc.)
_RE_QUALITY = re.compile(r"\b(?:\d{3,4}p|4K|UHD|HD|SD|HDR|Dolby|Atmos)\b", re.I)

# Remove language indicators [LEKTOR], (VO), {NAPISY}
_RE_LANGUAGE_TAG = re.compile(r"[\(\{\[]\s*(?:LEKTOR|NAPISY|VO|DUBBING|PL|EN|ENG|POL)\s*[\)\}\]]", re.I)

# Remove aspect ratios
_RE_ASPECT = re.compile(r"\b(?:\d{3,4}x\d{3,4}|16:9|4:3|2.35:1)\b", re.I)

# REMOVED: _RE_CHANNEL_SUFFIX (breaks real titles like "Mad Max")
# REMOVED: _RE_EPISODE_MARKER (conflicts with _RE_SXE season extraction)

# Remove brackets containing known filler words
_RE_FILLER_BRACKETS = re.compile(r"\([^\)]*(?:live|repeat|premiere|encore|marathon|special|bonus|extra|lektor|napisy|vo|dubbing)[^\)]*\)", re.I)

# Remove trailing separators and punctuation
_RE_TRAILING_SEP = re.compile(r"[\s\-_:\|/\\]+$")

# Polish content-word patterns (SAFE: only purely Polish words, no English)
_POLISH_CONTENT_PATTERNS = [
    r"\bserial\b", r"\bodcinek\b", r"\bsezon\b", r"\bpremiera\b",
    r"\bpowtorka\b", r"\bmagazyn\b", r"\breportaż\b", r"\bdokument\b",
]
_RE_POLISH_CONTENT = re.compile("|".join(_POLISH_CONTENT_PATTERNS), re.I)

# ============================================================================
# UNIFIED CACHE MANAGER (Singleton Pattern)
# ============================================================================

class CacheManager(object):
    """
    Central cache manager for ALL renderers.

    Features:
    - Persistent HDD/USB storage (survives reflash, multi-boot compatible)
    - 2-second TTL cache (reduces disk I/O by 75%)
    - Atomic writes with .tmp cleanup (prevents file corruption)
    - Thread-safe cache snapshots
    - Singleton pattern (single instance shared across all renderers)
    """

    _instance = None
    _lock     = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(CacheManager, cls).__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self.max_size = 1000
        self.ttl      = 2   # seconds

        # Title cache (with lock for thread safety)
        self._title_cache = {}
        self._title_lock = threading.Lock()
        self._display_cache = {}
        self._display_lock = threading.Lock()

        # EPG cache
        self._epg_cache      = []
        self._epg_cache_time = 0
        self._epg_cache_ref  = None   # stored as string via .toString()

        # JSON cache (scan_state.json, 2-second TTL)
        self._json_cache      = None
        self._json_cache_time = 0
        self._json_path       = SCAN_STATE_FILE
        self._json_lock       = threading.Lock()

        # Statistics
        self._stats = {
            'title_hits': 0, 'title_misses': 0,
            'display_hits': 0, 'display_misses': 0,
            'epg_hits':   0, 'epg_misses':   0,
            'json_hits':  0, 'json_misses':  0,
        }

        self._initialized = True

    # ========================================================================
    # JSON DATA ACCESS (Persistent HDD + 2-Second TTL Cache)
    # ========================================================================

    def _get_json_data(self):
        """
        NO CACHE - Direct disk read.
        JSON file is small (~200KB), direct read takes 5-10ms.
        Faster than cache logic (no dict copy, no TTL check, no lock contention).
        """
        try:
            if not os.path.exists(self._json_path):
                return {}
            with open(self._json_path, 'r') as f:
                data = json.load(f)
            return data.get('entries', data) if isinstance(data, dict) else {}
        except Exception:
            return {}

    def atomic_write_json(self, full_data):
        """
        Atomic write — writes to .tmp then replaces, preventing corruption.
        Always cleans up .tmp file even on failure.
        """
        tmp_file = self._json_path + ".tmp"
        try:
            with open(tmp_file, 'w') as f:
                json.dump(full_data, f)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_file, self._json_path)
            with self._json_lock:
                self._json_cache_time = 0
            return True
        except Exception:
            # Clean up the tmp file so it doesn't accumulate
            try:
                if os.path.exists(tmp_file):
                    os.remove(tmp_file)
            except Exception:
                pass
            return False

    def get_rating(self, clean_title):
        if not clean_title:
            return None
        entry = self._get_json_data().get(clean_title, {})
        if entry.get('status') in ('ok', 'found'):
            rating = entry.get('vote_average', 0)
            return float(rating) if rating else None
        return None

    def get_parental_rating(self, clean_title):
        if not clean_title:
            return None
        entry = self._get_json_data().get(clean_title, {})
        if entry.get('status') in ('ok', 'found'):
            return entry.get('parental_rating', '')
        return None

    def get_genres(self, clean_title):
        if not clean_title:
            return None
        entry = self._get_json_data().get(clean_title, {})
        if entry.get('status') in ('ok', 'found'):
            return self.format_genres(entry.get('genres', ''))
        return None

    def get_poster_path(self, clean_title):
        """Return the expected poster file path for a cleaned title."""
        if not clean_title:
            return None
        return os.path.join(POSTER_FOLDER, clean_title + '.jpg')

    def force_json_refresh(self):
        """No longer needed - but keep as pass for compatibility"""
        pass

    def get_json_cache_stats(self):
        """Return zeros since no cache"""
        return {'hits': 0, 'misses': 0, 'hit_ratio': 0}

    # ========================================================================
    # TITLE CACHE (Thread-safe)
    # ========================================================================

    def get_clean_title(self, raw_title):
        """Clean and cache a title — ONE cache shared across ALL renderers."""
        if not raw_title:
            return ""

        with self._title_lock:
            if raw_title in self._title_cache:
                self._stats['title_hits'] += 1
                return self._title_cache[raw_title]

            self._stats['title_misses'] += 1
            cleaned = convtext_raw(raw_title)

            if len(self._title_cache) >= self.max_size:
                # Remove oldest (FIFO)
                oldest = next(iter(self._title_cache))
                del self._title_cache[oldest]

            self._title_cache[raw_title] = cleaned
            return cleaned

    def get_title_cache_stats(self):
        total = self._stats['title_hits'] + self._stats['title_misses']
        return {
            'hits':      self._stats['title_hits'],
            'misses':    self._stats['title_misses'],
            'size':      len(self._title_cache),
            'hit_ratio': round(self._stats['title_hits'] / max(1, total) * 100, 2),
        }

    # ========================================================================
    # DISPLAY CACHE (for convtext_display)
    # ========================================================================

    def get_display_title(self, raw_title):
        """Clean title for display - preserves accents, uses separate cache."""
        if not raw_title:
            return ""

        with self._display_lock:
            if raw_title in self._display_cache:
                self._stats['display_hits'] += 1
                return self._display_cache[raw_title]

            self._stats['display_misses'] += 1
            cleaned = _clean_title(raw_title, keep_accents=True)

            if len(self._display_cache) >= self.max_size:
                oldest = next(iter(self._display_cache))
                del self._display_cache[oldest]

            self._display_cache[raw_title] = cleaned
            return cleaned

    def get_display_cache_stats(self):
        total = self._stats['display_hits'] + self._stats['display_misses']
        return {
            'hits':      self._stats['display_hits'],
            'misses':    self._stats['display_misses'],
            'size':      len(self._display_cache),
            'hit_ratio': round(self._stats['display_hits'] / max(1, total) * 100, 2),
        }

    # ========================================================================
    # EPG CACHE (Thread-safe, caches empty results)
    # ========================================================================

    def get_epg_events(self, service_ref):
        """ONE EPG lookup per 2 seconds — shared across ALL iNxtEvnt widgets."""
        if not service_ref:
            return []

        ref_str      = service_ref.toString()
        current_time = time.time()

        if (self._epg_cache_ref == ref_str
                and current_time - self._epg_cache_time < self.ttl):
            self._stats['epg_hits'] += 1
            return self._epg_cache  # Could be [] if no events

        self._stats['epg_misses'] += 1
        try:
            epg = eEPGCache.getInstance()
            if epg:
                events = epg.lookupEvent(['IBOCTESX', (ref_str, 0, -1, -1)]) or []
                self._epg_cache      = events
                self._epg_cache_time = current_time
                self._epg_cache_ref  = ref_str
                return events
        except Exception:
            pass

        # Cache empty result so we don't hammer EPG on dead channels
        self._epg_cache      = []
        self._epg_cache_time = current_time
        self._epg_cache_ref  = ref_str
        return []

    def clear_epg_cache(self):
        self._epg_cache_time = 0
        self._epg_cache_ref  = None
        self._epg_cache      = []

    def get_epg_cache_stats(self):
        total = self._stats['epg_hits'] + self._stats['epg_misses']
        return {
            'hits':      self._stats['epg_hits'],
            'misses':    self._stats['epg_misses'],
            'hit_ratio': round(self._stats['epg_hits'] / max(1, total) * 100, 2),
        }

    # ========================================================================
    # POSTER DATA (Batch Helper — ONE JSON read for multiple events)
    # ========================================================================

    def get_poster_data(self, clean_title):
        if not clean_title:
            return None
        return self.get_batch_poster_data([clean_title]).get(clean_title)

    def get_batch_poster_data(self, event_titles):
        """Get poster data for multiple events in ONE JSON read (2-sec TTL)."""
        if not event_titles or not isinstance(event_titles, list):
            return {}

        valid_titles = [t for t in event_titles if t and isinstance(t, str)]
        if not valid_titles:
            return {}

        data = self._get_json_data()
        if not data:
            return {}

        results = {}
        for title in valid_titles:
            entry = data.get(title, {})
            if entry.get('status') in ('ok', 'found'):
                results[title] = {
                    'poster_path': os.path.join(POSTER_FOLDER, title + '.jpg'),
                    'rating':      entry.get('vote_average', 0),
                    'parental':    entry.get('parental_rating', ''),
                    'genres':      self.format_genres(entry.get('genres', '')),
                    'year':        entry.get('year', ''),
                    'overview':    entry.get('overview', ''),
                }
        return results

    # ========================================================================
    # UTILITY HELPERS
    # ========================================================================

    def format_genres(self, genres_string):
        """Format "Action, Drama" → "Action • Drama"."""
        if not genres_string:
            return ""
        genres = [g.strip() for g in genres_string.split(',') if g.strip()]
        return " • ".join(genres) if genres else ""

    def clean_name(self, name):
        """Remove control characters from channel/event names."""
        try:
            name = name.replace("\xc2\x86", "").replace("\xc2\x87", "")
            name = name.replace(u"\x86", u"").replace(u"\x87", u"")
        except Exception:
            pass
        return name or ""

    def direct_poster_path(self, clean_title, folder):
        """Build file path for poster or backdrop."""
        if not clean_title:
            return None
        return "%s/%s.jpg" % (folder, clean_title)

    def is_sport_or_news_channel(self, channel_name):
        low = self.clean_name(channel_name).lower()
        return any(x in low for x in SKIP_CHANNEL_KEYWORDS)

    def is_sport_or_news_event(self, event_name):
        low = " " + (event_name or "").lower() + " "
        return any(x in low for x in SKIP_EVENT_KEYWORDS)

    def is_no_information(self, text):
        """Check if text is a "no information" placeholder."""
        low = to_text(text).lower().strip()
        if not low:
            return True
        return any(x in low for x in NO_INFORMATION_WORDS)

    def analyze_event_name(self, text):
        """Return skip flag, cache key, and search candidates for an event."""
        raw    = (text or "").strip()
        result = {"cache_title": "", "search_candidates": [], "skip": False}

        if not raw or self.is_no_information(raw):
            result["skip"] = True
            return result

        if self.is_sport_or_news_event(raw):
            result["skip"] = True
            return result

        clean = self.get_clean_title(raw)
        if clean:
            result["cache_title"]       = clean
            result["search_candidates"] = [clean]

        return result

    def get_all_stats(self):
        return {
            'title_cache':   self.get_title_cache_stats(),
            'display_cache': self.get_display_cache_stats(),
            'epg_cache':     self.get_epg_cache_stats(),
            'json_cache':    self.get_json_cache_stats(),
        }


# ============================================================================
# SINGLETON INSTANCE
# ============================================================================

_cache_manager = CacheManager()


# ============================================================================
# CORE TEXT HELPERS
# ============================================================================

def to_text(value, encoding="utf-8"):
    if value is None:
        return u""
    if isinstance(value, unicode):
        return value
    try:
        return unicode(value, encoding, "ignore")
    except Exception:
        try:
            return unicode(value)
        except Exception:
            return u""

def str_encode(value, encoding="utf-8"):
    if PY3:
        return value
    if isinstance(value, unicode):
        return value.encode(encoding)
    return value

def is_arabic(text):
    if not text:
        return False
    for char in text[:100]:
        code = ord(char)
        if (0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F
                or 0xFB50 <= code <= 0xFDFF or 0xFE70 <= code <= 0xFEFF):
            return True
    return False

def remove_accents(text):
    try:
        nfd = unicodedata.normalize("NFKD", text)
        return u"".join(c for c in nfd if not unicodedata.combining(c))
    except Exception:
        return text

def _is_no_information(text):
    """Internal - kept for backward compatibility."""
    return _cache_manager.is_no_information(text)


def _strip_arabic_episode(text):
    return _RE_ARABIC_EPISODE.sub("", text).strip()


# ============================================================================
# TITLE CLEANING PIPELINE (UPDATED V6.8.0 - FIXED)
# ============================================================================

def _clean_title(text, keep_accents=False):
    """
    Normalize an EPG event name to a TMDb-searchable key.

    Season rules:
      S01E08  → base title (trailing 1 dropped)
      S02E08  → title + "2"
      (S2)    → title + "2"
      Season 2 → title + "2"
      2x08    → title + "2"

    Part/Vol rules:
      "Kill Bill Vol 2"         → kept  (no episode marker present)
      "Show Ep5 Part 2"         → "show" (episode marker present → Part stripped)

    Trailing number rules:
      trailing 1   → drop   (Season 1 = base poster)
      trailing 2-99 → keep  (sequel / season discriminator)
      trailing >99  → drop  (episode artifact)
    """
    text = to_text(text).strip()
    if not text:
        return u""

    arabic = is_arabic(text)
    if arabic:
        text = _strip_arabic_episode(text)

    # 1 — control characters (FIRST)
    text = _RE_CONTROL.sub("", text)

    # 2 — trailing ranges  ("Show 1-5" → "Show 1")
    text = _RE_TRAILING_RANGE.sub(r"\1", text)

    # 3 — year brackets  ("Show (2023)" → "Show")
    text = _RE_YEAR_BRACKET.sub("", text)

    # 4 — remove quality markers (720p, 4K, HD, etc.)
    text = _RE_QUALITY.sub("", text)

    # 5 — remove language tags [LEKTOR], (VO), etc.
    text = _RE_LANGUAGE_TAG.sub("", text)

    # 6 — remove aspect ratios
    text = _RE_ASPECT.sub("", text)

    # 7 — remove filler brackets (live, repeat, premiere, etc.)
    text = _RE_FILLER_BRACKETS.sub("", text)

    # 8 — remove Polish content words (serial, odcinek, sezon, etc.)
    text = _RE_POLISH_CONTENT.sub("", text)

    if not arabic:
        # 9 — SxE → extract season  (S02E08 → 2)
        text = _RE_SXE.sub(r"\1", text)
        # 10 — NxN → extract season  (2x08 → 2)
        text = _RE_X_EP.sub(r"\1", text)
        # 11 — S2-08 → extract season  (S2-08 → 2)
        text = _RE_S_DASH_EP.sub(r"\1", text)

    # 12 — season keywords → extract number  ("Season 2" → "2")
    text = _RE_SEASON_NUM.sub(r"\1", text)

    # 13 — episode markers → strip entirely; record whether one was present
    has_episode_marker = bool(_RE_EPISODE.search(text))
    text = _RE_EPISODE.sub("", text)

    # 14 — Part/Vol: only strip when an episode marker confirmed EPG noise
    if has_episode_marker:
        text = _RE_PART_WITH_EP.sub("", text)

    # 15 — (S2) bracket → extract number
    text = _RE_SEASON_BRACKET.sub(r"\1", text)

    # 16 — (live) → strip
    text = _RE_LIVE_BRACKET.sub("", text)

    # 17 — junk branding words
    text = _RE_JUNK.sub("", text)

    # 18 — symbols → space, strip remaining punctuation
    text = _RE_SYMBOLS_TO_SPACE.sub(" ", text)
    text = _RE_OTHER_SYMBOLS.sub("", text)

    # 19 — collapse whitespace
    text = _RE_SPACES.sub(" ", text).strip()

    # 20 — trailing separators
    text = _RE_TRAILING_SEP.sub("", text)

    # 21 — trailing number normalisation
    #       1    → drop  (Season 1 = base poster, no suffix needed)
    #       2-99 → keep  (sequel / season discriminator)
    #       >99  → drop  (episode artifact)
    if not arabic:
        m = _RE_TRAILING_NUMBER.match(text)
        if m:
            try:
                num = int(m.group(2))
                if num == 1 or num > 99:
                    text = m.group(1).strip()
            except Exception:
                pass

    # 22 — remove accents
    if not keep_accents and not arabic:
        text = remove_accents(text)

    return text.strip()


def convtext_raw(text):
    """Cleaning entry-point called by CacheManager — returns lowercase key."""
    return _clean_title(text, keep_accents=False).lower()


# ============================================================================
# PUBLIC API  (used by all renderers)
# ============================================================================

def convtext(text=u""):
    """Return cleaned, cached title key for poster/TMDb lookup."""
    if not text:
        return ""
    return _cache_manager.get_clean_title(text)


# Alias for backward compatibility
get_cached_clean_title = convtext


def convtext_display(text=u""):
    """Like convtext but preserves accents (for on-screen display)."""
    if not text:
        return ""
    return _cache_manager.get_display_title(text)


def get_epg_events(service_ref):
    return _cache_manager.get_epg_events(service_ref)


def get_batch_poster_data(event_titles):
    return _cache_manager.get_batch_poster_data(event_titles)


def get_single_poster_data(clean_title):
    return _cache_manager.get_poster_data(clean_title)


def format_genres(genres_string):
    return _cache_manager.format_genres(genres_string)


def clean_name(name):
    return _cache_manager.clean_name(name)


def direct_poster_path(clean_title, folder):
    return _cache_manager.direct_poster_path(clean_title, folder)


def is_sport_or_news_channel(channel_name):
    return _cache_manager.is_sport_or_news_channel(channel_name)


def is_sport_or_news_event(event_name):
    return _cache_manager.is_sport_or_news_event(event_name)


def analyze_event_name(text=u""):
    return _cache_manager.analyze_event_name(text)


def get_cache_stats():
    return _cache_manager.get_all_stats()


def clear_epg_cache():
    _cache_manager.clear_epg_cache()


def force_json_refresh():
    _cache_manager.force_json_refresh()


def atomic_write_json(data):
    return _cache_manager.atomic_write_json(data)


def get_rating(clean_title):
    return _cache_manager.get_rating(clean_title)


def get_parental_rating(clean_title):
    return _cache_manager.get_parental_rating(clean_title)


def get_genres(clean_title):
    return _cache_manager.get_genres(clean_title)


def get_poster_path(clean_title):
    return _cache_manager.get_poster_path(clean_title)


def is_no_information(text):
    """Public wrapper for checking "no information" placeholders."""
    return _cache_manager.is_no_information(text)


def quoteEventName(eventName):
    text = to_text(eventName)
    try:
        if PY3:
            return quote_plus(text, safe="+")
        return quote_plus(text.encode("utf-8"), safe="+")
    except Exception:
        return quote_plus(str(eventName), safe="+")