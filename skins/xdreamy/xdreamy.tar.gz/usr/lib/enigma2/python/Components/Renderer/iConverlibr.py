#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iConverlibr.py - XDREAMY SKIN V7.1
Python 3 only. Single-source storage paths, folder indexing, and
multi-language title cleaning. Trimmed to one caching layer per concern.
"""

import os
import re
import json
import sqlite3
import threading
import time
import unicodedata
import weakref
from collections import OrderedDict
from functools import lru_cache

from enigma import eTimer, loadJPG
from Components.Sources.CurrentService import CurrentService
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance
from Components.config import config

from .iDebugger import traced, dbg, warn, err, timed_block, is_debug, register_health_probe

# ============================================================================
# 0. SKIN ACTIVATION GATE
# ============================================================================
# NOTE: no TTL cache here on purpose. config.skin.primary_skin.value is a
# plain in-memory attribute read (not I/O), so caching it just adds a
# stale-for-up-to-1s window and a dict/time.time() call for zero real gain.
XDREAMY_SKIN_MARKER = "xdreamy"

def is_activated():
    try:
        return XDREAMY_SKIN_MARKER in str(config.skin.primary_skin.value or "").lower()
    except Exception:
        return False

# ============================================================================
# 1. RUNTIME CONFIGURATION
# ============================================================================
_runtime_cfg = {
    "TMDB_LANGUAGE":     "en",
    "POSTERX_ENABLED":   True,
    "BACKDROPX_ENABLED": True,
    "LOGOX_ENABLED":     False,
    "STORAGE_PATH":      None,
    "WORKER_THREADS":    3,
    "TMDB_API_KEY":      "3c3efcf47c3577558812bb9d64019d65",
    "RTL_OVERVIEW":      True,
    "BACKDROP_SIZE":     "w500",
    "LOGO_SIZE":         "w300",
}

def get_cfg(key):
    return _runtime_cfg.get(key)

def _bootstrap_storage_from_saved_config():
    try:
        xd = config.plugins.xDreamy
        mode = xd.storage_mode.value
        if mode == "custom":
            _runtime_cfg["STORAGE_PATH"] = xd.storage_custom_path.value.rstrip("/")
    except Exception:
        pass

_bootstrap_storage_from_saved_config()

@traced("iConverlibr")
def apply_plugin_config(plugin_cfg):
    def _v(attr, default):
        try:
            return getattr(plugin_cfg, attr).value
        except Exception:
            return default
    _runtime_cfg["TMDB_LANGUAGE"]     = _v("tmdb_language",      "en")
    _runtime_cfg["POSTERX_ENABLED"]   = _v("posterx_enabled",    True)
    _runtime_cfg["BACKDROPX_ENABLED"] = _v("backdropx_enabled",  True)
    _runtime_cfg["LOGOX_ENABLED"]     = _v("logox_enabled",      False)
    _runtime_cfg["WORKER_THREADS"]    = int(_v("worker_threads", "3"))
    _runtime_cfg["TMDB_API_KEY"]      = _v("tmdb_api_key",       "3c3efcf47c3577558812bb9d64019d65")
    _runtime_cfg["RTL_OVERVIEW"]      = _v("rtl_overview",       True)
    _runtime_cfg["BACKDROP_SIZE"]     = _v("backdrop_size",      "w500")
    _runtime_cfg["LOGO_SIZE"]         = _v("logo_size",          "w300")
    mode = _v("storage_mode", "auto")
    _runtime_cfg["STORAGE_PATH"] = (
        _v("storage_custom_path", "/media/hdd/XDREAMY").rstrip("/")
        if mode == "custom" else None
    )
    _cached_base_path[0] = None
    _cached_base_is_fallback[0] = False
    _init_folders()
    invalidate_zap_context(force=True)
    dbg("iConverlibr", "config-applied", "workers=%s" % _runtime_cfg["WORKER_THREADS"])

# ============================================================================
# 2. STORAGE PATHS
# ============================================================================
_cached_base_path = [None]
_cached_base_is_fallback = [False]

def _ensure_dir(path):
    try:
        os.makedirs(path)
    except OSError:
        if not os.path.isdir(path):
            raise

def _fstab_mount_targets():
    targets = set()
    try:
        with open("/etc/fstab", "r") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                if len(parts) >= 2:
                    targets.add(parts[1].rstrip("/"))
    except Exception:
        pass
    try:
        with open("/proc/mounts", "r") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    targets.add(parts[1].rstrip("/"))
    except Exception:
        pass
    return targets

def _is_ready_storage_candidate(mount, fstab_targets):
    try:
        if os.path.ismount(mount):
            return True
        if mount.rstrip("/") in fstab_targets:
            return False
        return os.path.exists(mount) and os.access(mount, os.W_OK)
    except Exception:
        return False

def _get_base_path():
    cached = _cached_base_path[0]
    if cached is not None and not _cached_base_is_fallback[0]:
        return cached
    custom = _runtime_cfg.get("STORAGE_PATH")
    if custom:
        try:
            _ensure_dir(custom)
        except OSError:
            pass
        base = custom if os.path.basename(custom) == "XDREAMY" else os.path.join(custom, "XDREAMY")
        try:
            _ensure_dir(base)
        except OSError:
            pass
        if os.path.isdir(base):
            _cached_base_path[0] = base
            _cached_base_is_fallback[0] = False
            return base
    fstab_targets = _fstab_mount_targets()
    for mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
        if _is_ready_storage_candidate(mount, fstab_targets):
            path = os.path.join(mount, "XDREAMY")
            try:
                _ensure_dir(path)
            except OSError:
                pass
            _cached_base_path[0] = path
            _cached_base_is_fallback[0] = False
            return path
    fallback = "/tmp/XDREAMY"
    try:
        _ensure_dir(fallback)
    except OSError:
        pass
    if cached != fallback:
        warn("iConverlibr", "path-fallback",
             "no writable mount found yet (or configured mounts haven't "
             "attached), using provisional %s - will keep "
             "retrying real mounts on next access" % fallback)
    _cached_base_path[0] = fallback
    _cached_base_is_fallback[0] = True
    return fallback

def _init_folders():
    base = _get_base_path()
    for sub in ["poster", "backdrop", "logo", "backup"]:
        try:
            _ensure_dir(os.path.join(base, sub))
        except OSError:
            pass
    return base

def get_base_path():
    return _get_base_path()

_init_folders()

def get_poster_folder():         return os.path.join(_get_base_path(), "poster")
def get_backdrop_folder():       return os.path.join(_get_base_path(), "backdrop")
def get_logo_folder():           return os.path.join(_get_base_path(), "logo")
def get_backup_folder():         return os.path.join(_get_base_path(), "backup")
def get_cache_path(filename):    return os.path.join(_get_base_path(), filename)
def get_metadata_db_path():      return os.path.join(_get_base_path(), "iMetaData.db")

# ============================================================================
# 3. FOLDER INDEXING (single file-existence mechanism)
# ============================================================================
# NOTE: there used to be a second, separate TTL-based file_exists_cached()
# cache layered on top of this. It overlapped with nothing meaningful --
# folder scans go through the index below, and the one-off sidecar check
# (get_sidecar_if_valid in iRendererBase) already has its own permanent
# per-title cache. Removed to cut one lock + one stale-for-5s window.
class _FolderIndex(object):
    __slots__ = ("folder", "_files", "_lock", "_loaded", "_mtime")
    def __init__(self, folder):
        self.folder = folder
        self._files = set()
        self._lock = threading.Lock()
        self._loaded = False
        self._mtime = None
    def _ensure_loaded(self):
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            try:
                self._files = set(os.listdir(self.folder))
                self._mtime = os.stat(self.folder).st_mtime
            except Exception as e:
                self._files = set()
                warn("FolderIndex", "listdir-error", "%s: %s" % (self.folder, e))
            self._loaded = True
    def exists(self, filename):
        self._ensure_loaded()
        return filename in self._files
    def add(self, filename):
        self._ensure_loaded()
        with self._lock:
            self._files.add(filename)
            try:
                self._mtime = os.stat(self.folder).st_mtime
            except Exception:
                pass
    def remove(self, filename):
        with self._lock:
            self._files.discard(filename)
            try:
                self._mtime = os.stat(self.folder).st_mtime
            except Exception:
                pass
    def refresh(self):
        # Cheap check first: a directory's mtime changes when entries are
        # added/removed. If nothing external touched this folder since our
        # own add()/remove() calls last updated _mtime, skip the full
        # listdir entirely -- this turns the hourly refresh from "list
        # every file in every asset folder" into "one stat() call" for the
        # common case where nothing changed outside the app.
        try:
            current_mtime = os.stat(self.folder).st_mtime
        except Exception:
            return
        with self._lock:
            if self._loaded and current_mtime == self._mtime:
                return
        try:
            files = set(os.listdir(self.folder))
        except Exception:
            files = set()
        with self._lock:
            self._files = files
            self._mtime = current_mtime
            self._loaded = True

_folder_indexes = {}
_folder_index_lock = threading.Lock()

def _get_index(folder):
    idx = _folder_indexes.get(folder)
    if idx is None:
        with _folder_index_lock:
            idx = _folder_indexes.get(folder)
            if idx is None:
                idx = _FolderIndex(folder)
                _folder_indexes[folder] = idx
    return idx

def file_exists_indexed(folder, filename):
    return _get_index(folder).exists(filename)

def resolve_asset_paths(clean_title, want_poster=True, want_backdrop=True, want_logo=True):
    """Single lookup point for the poster/backdrop/logo triad -- replaces
    three near-identical inline blocks that used to live separately in
    _build_slot() and get_event_source_metadata()."""
    result = {"local_path": None, "backdrop_path": None, "logo_path": None}
    if not clean_title:
        return result
    if want_poster:
        folder = get_poster_folder()
        fname = clean_title + ".jpg"
        if file_exists_indexed(folder, fname):
            result["local_path"] = os.path.join(folder, fname)
    if want_backdrop:
        folder = get_backdrop_folder()
        fname = clean_title + ".jpg"
        if file_exists_indexed(folder, fname):
            result["backdrop_path"] = os.path.join(folder, fname)
    if want_logo:
        folder = get_logo_folder()
        fname = clean_title + ".png"
        if file_exists_indexed(folder, fname):
            result["logo_path"] = os.path.join(folder, fname)
    return result

def mark_file_indexed(folder, filename):
    _get_index(folder).add(filename)

def unmark_file_indexed(folder, filename):
    _get_index(folder).remove(filename)

_REFRESH_INTERVAL = 3600
_last_refresh = [0]

def refresh_all_indexes():
    now = time.time()
    if now - _last_refresh[0] < _REFRESH_INTERVAL:
        return
    _last_refresh[0] = now
    for idx in list(_folder_indexes.values()):
        idx.refresh()

# ============================================================================
# 4. TITLE / FILENAME CLEANING (enhanced)
# ============================================================================
SKIP_CHANNEL_KEYWORDS = [
    "sport", "sports", "espn", "eurosport", "bein sport", "dazn",
    "sky sport", "fox sport", "nba tv", "nfl network", "golf channel",
    "motorsport", "racing", "tennis channel", "news", "cnn", "bbc news",
    "fox news", "sky news", "al jazeera", "bloomberg", "weather", "meteo",
    "tg1", "tg2", "tg3", "tg4", "tg5", "rainews", "tvp info", "tvp sport",
    "polsat sport", "canal+ sport", "eurosport", "sportklub",
]

_NO_INFO_WORDS = [
    "no information", "no info", "no event info", "press epg",
    "brak informacji", "brak danych", "informacja niedostępna",
    "wciśnij przycisk", "press button", "info -", "epg -",
    "info wciśnij", "info press", "brak tytułu", "no title",
    "niedostępne", "unavailable", "not available", "epg not available",
    "program nieznany", "unknown program", "zakończenie programu",
    "koniec programu", "end of program", "programmende",
    "fine programma", "fin de programme", "نهاية البرنامج",
]
_NO_INFO_RE = re.compile("|".join(re.escape(w) for w in _NO_INFO_WORDS), re.IGNORECASE | re.UNICODE)

_SKIP_EVENT_KEYWORDS = [
    " @ ", "match", "game day", "zakończenie programu", " cup ",
    "playoff", "tournament", "grand prix", "formula 1", "football",
    "soccer", "basketball", "tennis", "golf", "baseball", "hockey",
    "volleyball", "boxing", "wrestling", "ufc", "mma", "racing",
    "piłka", "mecz", "mecze", "liga", "mistrzostwa", "puchar", "turniej",
    "zawody", "siatkówka", "koszykówka", "piłka nożna", "hokej", "żużel",
    "walka", "gal", "kolarstwo", "narciarstwo", "skoki", "formuła 1",
    "telegiornale", "studio aperto", "tg1", "tg2", "tg3", "tg4", "tg5",
    "tg regione", "tg parlamento", "rai news", "rainews", "rai parlamento",
    "agorà", "fuori orario", "spaziolibero", "elisir", "studi aperti",
    "le journal", "journal de", "météo", "meteo", "tour de france",
    "championnat", "coupe du monde", "ligue ", "programmes de la nuit",
    "rediffusion", "redif", "replay", "en direct",
    "informacyjny", "wiadomości", "newsroom", "fakty", "panorama",
    "teleexpress", "kronika", "dziennik", "serwis", "kurier", "pogoda",
    "prognoza", "meteo", "wstęp", "wstep", "przerwa", "break",
    "أخبار", "نشرة", "رياضة", "مباراة", "بطولة", "كأس", "تجريبية",
    "قناة تجريبية", "test channel",
    "live", "en direct", "in diretta", "na żywo", "direct", "diretta",
    "wciśnij przycisk", "press button", "info -", "epg -",
    "info wciśnij", "info press", "brak tytułu", "no title",
    "4fun kids", "4fun tv", "eska tv", "polsat news", "tvp info", "tvp sport",
    "tvn24", "tvn 24", "polsat news", "wpolsce", "republika", "warszawa",
    "msza święta", "transmisja mszy", "nabożeństwo", "koronka do",
    "modlitwa", "kazanie", "nabożeństwo",
    "tv okazje", "telezakupy", "shopping", "teleshopping", "promocja",
    "blok promocyjny", "promo block", "promotional block",
    "renewal of broadcasts", "programmes de la nuit", "programmes de",
    "previsioni", "viabilità", "traffic", "trafic", "meteo", "weather",
    "1mattina", "mattina", "notte", "sera", "mattino", "mattina",
    "usa - polska", "usa - ", " - usa", "polska - ", "mężczyzn", "kobiet",
]
_SKIP_EVENT_RE = re.compile("|".join(re.escape(k) for k in _SKIP_EVENT_KEYWORDS), re.IGNORECASE | re.UNICODE)

JUNK_WORDS = [
    "primatv", "primatime", "mediaset extra", "mediaset", "axn black",
    "axn spain", "axn", "full movie", "full episode", "making of",
    "behind the scenes",
    "powtórki", "repeat", "encore", "visione", "rai", "mediaset",
    "la giornata", "ultima ora", "notte", "sera", "post",
    "storie", "dossier", "mizar", "speciale",
    "rediffusion", "redif", "intégrale", "best of", "replay",
    "wiederholung", "wdh", "komplette",
    "تلفزيون", "قناة", "إعادة", "حلقة كاملة",
    "odc.", "odcinek", "część", "part", "pt.", "vol.", "volume",
    "odc ", " cz ", " część ", " odc ",
    "sezon", "season", "saison", "serie", "series", "stagione",
    "episode", "ep.", "ep ", "folge", "teil", "puntata", "capitolo",
    "info", "informacja", "informations",
    "rano", "po południu", "wieczorem", "nocą",
    "hd", "full hd", "4k", "uhd",
]

GENERIC_PREFIXES = {
    "the ", "a ", "an ",
    "les ", "la ", "le ", "l'", "un ", "une ",
    "il ", "la ", "lo ", "i ", "gli ", "le ", "un ", "una ",
    "el ", "la ", "los ", "las ", "un ", "una ",
    "der ", "die ", "das ", "den ", "dem ", "des ", "ein ", "eine ", "einer ", "einen ", "einem ", "eines ",
    "te ", "to ", "ta ", "ten ", "ta ", "ci ", "co ",
    "ال",
}

_RE_CTRL        = re.compile(u"[\x00-\x1f\x7f\x86\x87]")
_RE_YEAR_BRKT   = re.compile(r"\(\s*(?:19|20)\d{2}\s*\)", re.I)
_RE_SXE         = re.compile(r"\bS(\d{1,2})E\d{1,3}\b", re.I)
_RE_XEP         = re.compile(r"\b(\d{1,2})x(\d{1,3})\b", re.I)
_RE_SDASH       = re.compile(r"\bS(\d+)\s*-\s*\d+\b", re.I)
_RE_SEASON      = re.compile(
    r"\b(?:season|saison|series|serie|sezon|جزء|موسم|ج|stagione|temporada|série|temporada|temporada)\s*\d+\b",
    re.I | re.U
)
_RE_EPISODE     = re.compile(
    r"(?:\()?\b(?:odc|odcinek|ep|episode|episodio|folge|teil|حلقة|حلقه|ح|puntata|p\.?|capitolo|épisode|chapitre|capítulo|bölüm|dizi)\s*[:.]?\s*\d+\b(?:\()?",
    re.I | re.U
)
_RE_EPISODE_TAIL = re.compile(
    r"\b(?:odc|odcinek|ep|episode|episodio|folge|teil|حلقة|حلقه|ح|puntata|p\.?|capitolo|épisode|chapitre|capítulo|bölüm|dizi)\s*[:.]?\s*\d+\b.*$",
    re.I | re.U
)
_RE_PART        = re.compile(r"\b(?:part|pt|vol|volume|parte|partie|parte|część|czesc|bölüm)\s*[:.]?\s*\d+\b", re.I)
_RE_TRAIL_RANGE = re.compile(r"(\b\d+)\s*[\-_:|/\\]+\s*\d+\s*$", re.I)
_RE_SBRKT       = re.compile(r"\(\s*S(\d+)\s*\)", re.I)
_RE_LIVE        = re.compile(r"\(\s*live\s*\)", re.I)
_RE_JUNK        = re.compile(r"\b(?:%s)\b" % "|".join(re.escape(x) for x in JUNK_WORDS), re.I)
_RE_QUALITY     = re.compile(r"\b(?:\d{3,4}p|4K|UHD|SD|HDR|Dolby|Atmos)\b", re.I)
_RE_LANG_TAG    = re.compile(r"[\(\{\[]\s*(?:LEKTOR|NAPISY|VO|DUBBING|PL|EN|ENG|POL|VF|VOSTFR|SUB|DUB)\s*[\)\}\]]", re.I)
_RE_ASPECT      = re.compile(r"\b(?:\d{3,4}x\d{3,4}|16:9|4:3|2\.35:1)\b", re.I)
_RE_FILL_BRKT   = re.compile(r"\([^\)]*(?:live|repeat|encore|marathon|bonus|lektor|napisy|vo|dubbing|powtórki|rediffusion|redif|wiederholung)[^\)]*\)", re.I)
_RE_SYM2SPC     = re.compile(r"[-:._]")
_RE_OTHER_SYM   = re.compile(r'[()\[\]{}|+!@#$%^&*,?";<>`~=]')
_RE_SPACES      = re.compile(r"\s+")
_RE_TRAIL_SEP   = re.compile(r"[\s\-_:\|/\\]+$")
_RE_TRAIL_NUM   = re.compile(r"^(.*\S)\s+(\d{1,4})$")
_RE_BROADCAST_MARKER = re.compile(
    r"(?:\d+\^?\s*(?:visione|rai|mediaset|replica|powtórki|repeat|encore|rediffusion|wiederholung))",
    re.I
)
_RE_DATE_PREFIX = re.compile(
    r"^\d{8}\s+\d{4}\s*[-–]\s*(?:[A-Z0-9]+\s+)?(?:HD|SD|UHD|4K)?\s*[-–]\s*",
    re.I
)
# FIXED: Define both Polish season+episode patterns
_RE_POLISH_SEASON_EP = re.compile(
    r'^(.*?)\s+(\d+)\s*:\s*odc\.?\s*\d+',
    re.I | re.U
)
_RE_POLISH_SEASON_EP_PAREN = re.compile(
    r"^(.*?)\s+\d+\s*\(\s*odc\.?\s*\d+\s*\)",
    re.I | re.U
)
_RE_ITALIAN_SERIE_EP = re.compile(
    r"^(.*?)\s+(?:serie|stagione)\s+\d+\s+(?:ep|episodio|puntata)\.?\s*\d+",
    re.I | re.U
)

_RE_YEAR_IN_TITLE = re.compile(r"\b(19\d{2}|20\d{2})\b")
_RE_YEAR_SUFFIX = re.compile(r"\b.+\s+(19\d{2}|20\d{2})$")

_RE_ARABIC_EP_MARKER = re.compile(r'\s+ح\s*\d+\s*$')
_RE_ARABIC_SEASON_MARKER = re.compile(r'\s+ج\s*\d+\s*$')
_RE_ARABIC_FULL_EP = re.compile(r'\s+حلقة\s*\d+\s*$')
_RE_ARABIC_FULL_SEASON = re.compile(r'\s+(?:موسم|جزء)\s*\d+\s*$')

def to_text(value, encoding="utf-8"):
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, bytes):
        try:
            return value.decode(encoding, "ignore")
        except Exception:
            return ""
    try:
        return str(value)
    except Exception:
        return ""

def is_arabic(text):
    if not text:
        return False
    arabic_chars = 0
    total_chars = 0
    for ch in text:
        if ch.isalpha():
            total_chars += 1
            code = ord(ch)
            if (0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F or 
                0xFB50 <= code <= 0xFDFF or 0xFE70 <= code <= 0xFEFF):
                arabic_chars += 1
    if total_chars > 0 and arabic_chars / total_chars > 0.3:
        return True
    for ch in text[:100]:
        code = ord(ch)
        if 0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F or 0xFB50 <= code <= 0xFDFF or 0xFE70 <= code <= 0xFEFF:
            return True
    return False

def remove_accents(text):
    try:
        nfd = unicodedata.normalize("NFKD", text)
        return u"".join(c for c in nfd if not unicodedata.combining(c))
    except Exception:
        return text

def _clean_title(text, strip_accents=False):
    text = to_text(text).strip()
    if not text:
        return u""
    if text.replace(' ', '').isalnum():
        return text.strip().lower()
    arabic = is_arabic(text)
    text = _RE_CTRL.sub("", text)
    text = _RE_TRAIL_RANGE.sub(r"\1", text)
    text = _RE_DATE_PREFIX.sub("", text)
    text = _RE_YEAR_BRKT.sub("", text)
    text = _RE_QUALITY.sub("", text)
    text = _RE_LANG_TAG.sub("", text)
    text = _RE_ASPECT.sub("", text)
    text = _RE_FILL_BRKT.sub("", text)
    text = _RE_BROADCAST_MARKER.sub("", text)

    polish_season_ep = _RE_POLISH_SEASON_EP.match(text)
    if polish_season_ep:
        text = polish_season_ep.group(1)
    polish_season_ep_paren = _RE_POLISH_SEASON_EP_PAREN.match(text)
    if polish_season_ep_paren:
        text = polish_season_ep_paren.group(1)
    italian_serie_ep = _RE_ITALIAN_SERIE_EP.match(text)
    if italian_serie_ep:
        text = italian_serie_ep.group(1)

    if arabic:
        text = _RE_ARABIC_FULL_EP.sub("", text)
        text = _RE_ARABIC_FULL_SEASON.sub("", text)
        text = _RE_ARABIC_EP_MARKER.sub("", text)
        text = _RE_ARABIC_SEASON_MARKER.sub("", text)

    if not arabic:
        real_xep = any(m.group(1) != m.group(2) for m in _RE_XEP.finditer(text))
        had_sxe_or_sdash_or_xep = bool(_RE_SXE.search(text)) or real_xep or bool(_RE_SDASH.search(text))
        text = _RE_SXE.sub("", text)
        text = _RE_XEP.sub(lambda m: "" if m.group(1) != m.group(2) else m.group(0), text)
        text = _RE_SDASH.sub("", text)
    else:
        had_sxe_or_sdash_or_xep = False

    text = _RE_SEASON.sub("", text)
    has_ep = had_sxe_or_sdash_or_xep or bool(_RE_EPISODE.search(text))
    if has_ep:
        text = _RE_EPISODE_TAIL.sub("", text)
    else:
        text = _RE_EPISODE.sub("", text)

    if has_ep:
        text = _RE_PART.sub("", text)
        text = re.sub(r'\s+\d+\s*$', '', text)

    text = _RE_SBRKT.sub(r"\1", text)
    text = _RE_LIVE.sub("", text)
    text = _RE_JUNK.sub("", text)
    text = _RE_SYM2SPC.sub(" ", text)
    text = _RE_OTHER_SYM.sub("", text)
    text = _RE_SPACES.sub(" ", text).strip()
    text = _RE_TRAIL_SEP.sub("", text)

    if not arabic:
        m = _RE_TRAIL_NUM.match(text)
        if m:
            try:
                num = int(m.group(2))
                base = m.group(1).strip()
                word_count = len(base.split())
                if 1900 <= num <= 2030:
                    pass
                elif has_ep:
                    text = base
                elif num <= 5 and word_count >= 2:
                    pass
                elif num > 20 and word_count >= 2:
                    text = base
                elif num <= 20 and word_count >= 2:
                    text = base
            except Exception:
                pass
        if strip_accents:
            text = remove_accents(text)

    return text.strip().lower()

class _TitleCache(object):
    def __init__(self, maxsize=5000):
        self._d = OrderedDict()
        self._max = maxsize
        self._lock = threading.Lock()
    def get(self, raw):
        if not raw:
            return ""
        with self._lock:
            if raw in self._d:
                self._d.move_to_end(raw)
                return self._d[raw]
            cleaned = _clean_title(raw)
            self._d[raw] = cleaned
            if len(self._d) > self._max:
                self._d.popitem(last=False)
            return cleaned

_title_cache = _TitleCache()

def convtext(text=u""):
    return _title_cache.get(text) if text else ""

def clean_name(name):
    try:
        name = name.replace(u"\x86", u"").replace(u"\x87", u"")
    except Exception:
        pass
    return name or ""

def is_sport_or_news_channel(channel_name):
    return any(x in clean_name(channel_name).lower() for x in SKIP_CHANNEL_KEYWORDS)

def _is_no_info(text):
    low = to_text(text).strip()
    if not low:
        return True
    return bool(_NO_INFO_RE.search(low))

_ANALYZE_CACHE_MAX = 1000
_analyze_cache = OrderedDict()
_analyze_cache_lock = threading.Lock()

_STRIP_EP = re.compile(
    r"\s+\d{1,3}\s*$"
    r"|\s+(?:i|ii|iii|iv|v|vi|vii|viii|ix|x|xi|xii|xiii|xiv|xv|xvi|xvii|xviii|xix|xx)\s*$"
    r"|\s*[Ss]\d{1,2}[Ee]\d+"
    r"|\s*odc\.?\s*\d+"
    r"|\s*sezon\s*\d+"
    r"|\s*episode\s*\d+"
    r"|\s*[Ss]aison\s*\d+"
    r"|[:\-]\s*$"
    r"|\s*ح\s*\d+"
    r"|\s*حلقة\s*\d+"
    r"|\s*جزء\s*\d+"
    r"|\s*موسم\s*\d+"
    r"|\s*ج\s*\d+"
    r"|\s*p\.?\s*\d+"
    r"|\s*ep\.?\s*\d+"
    r"|\s*puntata\s*\d+"
    r"|\s*pt\.?\s*\d+"
    r"|\s*part\.?\s*\d+"
    r"|\s*vol\.?\s*\d+"
    r"|\s*cap\.?\s*\d+"
    r"|\s*capitolo\s*\d+"
    r"|\s*folge\s*\d+"
    r"|\s*teil\s*\d+"
    r"|\s*bölüm\s*\d+"
    r"|\s*dizi\s*\d+"
    r"|\s*épisode\s*\d+"
    r"|\s*chapitre\s*\d+"
    r"|\s*capítulo\s*\d+"
    r"|\s*część\s*\d+"
    r"|\s*czesc\s*\d+"
    r"|\s*\(\s*\d+\s*\)\s*$"
    r"|\s*\d+\s*(?:of|z|de|di|sur)\s*\d+\s*$"
    r"|\s*-\s*\d+\s*$"
    r"|\s+\d+\s*\.\s*seria\s*$"
    r"|\s+\d+\s*\.\s*season\s*$"
)

def _strip_ep(text):
    result = _STRIP_EP.sub("", text).strip()
    return result if result != text else None

_ROMAN_TO_ARABIC = {
    "i": "1", "ii": "2", "iii": "3", "iv": "4", "v": "5",
    "vi": "6", "vii": "7", "viii": "8", "ix": "9", "x": "10",
    "xi": "11", "xii": "12", "xiii": "13", "xiv": "14", "xv": "15",
    "xvi": "16", "xvii": "17", "xviii": "18", "xix": "19", "xx": "20",
}
_ARABIC_TO_ROMAN = {v: k.upper() for k, v in _ROMAN_TO_ARABIC.items()}
_RE_TRAIL_WORD = re.compile(r"^(.*\S)\s+(\S+)$")

def numeral_variant_candidate(clean_title):
    m = _RE_TRAIL_WORD.match(clean_title)
    if not m:
        return None
    base, last = m.group(1), m.group(2).lower()
    if last in _ROMAN_TO_ARABIC:
        return "%s %s" % (base, _ROMAN_TO_ARABIC[last])
    if last in _ARABIC_TO_ROMAN:
        return "%s %s" % (base, _ARABIC_TO_ROMAN[last])
    return None

_RE_ROMAN_MIDDLE_TOKEN = re.compile(
    r"^(?:ii|iii|iv|v|vi|vii|viii|ix|x|xi|xii|xiii|xiv|xv|xvi|xvii|xviii|xix|xx)$", re.I)

def strip_middle_roman_numeral(clean_title):
    words = clean_title.split()
    if len(words) < 3:
        return None
    out = []
    changed = False
    for i, w in enumerate(words):
        if i > 0 and _RE_ROMAN_MIDDLE_TOKEN.match(w):
            changed = True
            continue
        out.append(w)
    if not changed:
        return None
    return " ".join(out)

def _split_on_colon_or_dash(text):
    for sep in [':', '–', '-']:
        if sep in text:
            parts = text.split(sep, 1)
            if len(parts) == 2:
                before = parts[0].strip()
                after = parts[1].strip()
                if len(before) >= 5 and len(before) > len(after) * 0.6:
                    return before
    return None

@traced("iConverlibr")
def analyze_epg_title(raw):
    with _analyze_cache_lock:
        cached = _analyze_cache.get(raw)
        if cached is not None:
            _analyze_cache.move_to_end(raw)
            return cached

    if not raw or _is_no_info(raw):
        result = (True, "", [])
    elif _SKIP_EVENT_RE.search(raw.lower()):
        result = (True, "", [])
    else:
        clean = _title_cache.get(raw)
        if not clean:
            result = (True, "", [])
        else:
            is_truncated = len(raw) >= 38 and not raw.endswith(('.', ')', ']', '}', '"', "'")) and raw.count('(') != raw.count(')')
            if is_truncated:
                truncated_clean = clean
                if len(clean) > 3 and clean[-1] not in 'aeiouyąęóśłżźćń' and clean[-2] in 'aeiouyąęóśłżźćń':
                    last_space = clean.rfind(' ')
                    if last_space > 10:
                        truncated_clean = clean[:last_space]
            else:
                truncated_clean = None

            candidates = [clean]
            if truncated_clean and truncated_clean != clean and len(truncated_clean) >= 8:
                candidates.append(truncated_clean)
            if raw.lower() != clean:
                candidates.append(raw)
            stripped = _strip_ep(clean)
            if stripped and stripped != clean:
                candidates.append(stripped)
            no_accent = remove_accents(clean)
            if no_accent != clean:
                candidates.append(no_accent)
            numeral_variant = numeral_variant_candidate(clean)
            if numeral_variant and numeral_variant != clean:
                candidates.append(numeral_variant)

            main_part = None
            for text in (raw, clean):
                for sep in [':', '–', '-']:
                    if sep in text:
                        before, after = text.split(sep, 1)
                        before = before.strip()
                        after = after.strip()
                        if before and after:
                            before_lower = before.lower()
                            is_pure_generic = any(before_lower.startswith(p) and len(before) <= len(p) + 4 for p in GENERIC_PREFIXES)
                            if is_pure_generic:
                                after_clean = _clean_title(after)
                                if after_clean and after_clean not in candidates:
                                    candidates.insert(0, after_clean)
                            if len(before) >= 5 and len(before) > len(after) * 0.6:
                                main_part = before
                            break
                if main_part is not None:
                    break

            if main_part:
                main_clean = _clean_title(main_part)
                if main_clean and main_clean not in candidates:
                    candidates.append(main_clean)
            if not main_part:
                main_part = _split_on_colon_or_dash(raw) or _split_on_colon_or_dash(clean)
                if main_part and main_part not in candidates:
                    main_clean = _clean_title(main_part)
                    if main_clean and main_clean not in candidates:
                        candidates.append(main_clean)

            no_part = _RE_PART.sub("", clean)
            no_part = _RE_SPACES.sub(" ", no_part).strip()
            if no_part and no_part != clean:
                candidates.append(no_part)
            no_middle_roman = strip_middle_roman_numeral(clean)
            if no_middle_roman and no_middle_roman not in candidates:
                candidates.append(no_middle_roman)
            if any(c in 'ąćęłńóśźż' for c in clean):
                ascii_variant = remove_accents(clean)
                if ascii_variant != clean and ascii_variant not in candidates:
                    candidates.append(ascii_variant)

            seen = set()
            unique = []
            for c in candidates:
                if c and c not in seen:
                    seen.add(c)
                    unique.append(c)
            candidates = unique[:8]
            result = (False, clean, candidates)

    with _analyze_cache_lock:
        if len(_analyze_cache) >= _ANALYZE_CACHE_MAX:
            for _ in range(200):
                if _analyze_cache:
                    _analyze_cache.popitem(last=False)
                else:
                    break
        _analyze_cache[raw] = result
    return result

# ---- Media file (EMC) filename cleaning ----
_VIDEO_EXTS = ('.mkv', '.avi', '.mp4', '.ts', '.mov', '.iso', '.m2ts', '.m4v', '.mpeg', '.mpg', '.wmv')

def is_video_file(path):
    if not path:
        return False
    return any(str(path).lower().endswith(ext) for ext in _VIDEO_EXTS)

def is_emc_episode(filename):
    text = str(filename or "")
    if re.search(r"\bS\s*\d{1,2}[\s._-]*E\s*\d{1,3}\b", text, re.I):
        return True
    if re.search(r"\b\d{1,2}x\d{1,3}\b", text, re.I):
        return True
    if re.search(r"\bseason[\s._-]*\d+\b", text, re.I):
        return True
    if re.search(r"\bepisode[\s._-]*\d+\b", text, re.I):
        return True
    return False

def extract_emc_year(filename):
    text = str(filename or "")
    m = re.search(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)", text)
    return m.group(1) if m else ""

_GARBAGE_PATTERNS = [
    r"\b(480p|576p|720p|1080p|2160p|4K)\b",
    r"\b(WEBRip|WEB[\- ]DL|WEB|BluRay|BRRip|BRRiP|BDRip|DVDRip|DvDrip|HDRip|HDTV|CAM|TS|TC|SCR|AMZN)\b",
    r"\b(x264|x265|h264|h265|H264|H265|HEVC|AVC|XViD|XviD|XVID)\b",
    r"\b(8bit|10bit|10bits|12bit)\b",
    r"\b(HDR|HDR10|DV|Dolby Vision)\b",
    r"\b(AAC|AC3|EAC3|DD|DDP|DTS|TRUEHD|Atmos|MP3)\b",
    r"\b(REPACK|PROPER|INTERNAL|EXTENDED|REMASTERED|UNRATED|REMUX|LIMITED)\b",
    r"\b(\d+(?:\.\d+)?\s*(?:GB|MB))\b",
    r"\b(YTS|PSA|RARBG|GECKOS|DRONES|COCAIN|SPARKS|DiAMOND|FGT|ION10|RUSTED|ETRG)\b",
    r"\b(mp4|mkv|avi)\b",
]
_GARBAGE_RE = [re.compile(p, re.I) for p in _GARBAGE_PATTERNS]
_CHANNEL_PREFIX_RE = re.compile(
    r'^(?:[A-Z]{2,}\s*[A-Z0-9]*|BBC|ZDF|CNN|RAI|TVP|RTL|Vox|ProSieben|SAT\.?1|HBO|Sky|Canal\+)\s*[–\-]\s*', re.I)
_SCENE_GROUP_RE = re.compile(
    r"^(COCAIN|GECKOS|DRONES|SPARKS|DiAMOND|FGT|ION10|RARBG|YIFY|YTS|ETRG|XVID|RUSTED|WAR|GETiT)-", re.I)

_filename_cache = OrderedDict()
_FILENAME_CACHE_MAX = 500
_filename_cache_lock = threading.Lock()

@traced("iConverlibr")
def _clean_filename_uncached(raw):
    if not raw or not is_video_file(raw):
        return "", "", False, ""
    name = os.path.splitext(os.path.basename(raw))[0]
    name = re.sub(r'^\d{8}\s+\d{4}\s*[-–]\s*', '', name)
    name = _SCENE_GROUP_RE.sub("", name)
    name = _CHANNEL_PREFIX_RE.sub('', name)

    is_ep = is_emc_episode(name)
    ep_marker = ""
    if is_ep:
        m = re.search(r"\bS\s*(\d{1,2})[\s._-]*E\s*(\d{1,3})\b", name, re.I)
        if m:
            ep_marker = "S%02dE%02d" % (int(m.group(1)), int(m.group(2)))
        else:
            m = re.search(r"\b(\d{1,2})x(\d{1,3})\b", name, re.I)
            if m:
                ep_marker = "S%02dE%02d" % (int(m.group(1)), int(m.group(2)))
        name = re.sub(r"\bS\d{1,2}E\d{1,3}\b.*$", "", name, re.I)
        name = re.sub(r"\b\d{1,2}x\d{1,3}\b.*$", "", name, re.I)
        name = re.sub(r"\bseason[\s._-]*\d+\b.*$", "", name, re.I)
        name = re.sub(r"\bepisode[\s._-]*\d+\b.*$", "", name, re.I)

    name = re.sub(r"[\[\(]\s*((?:19|20)\d{2})\s*[\]\)]", r" \1 ", name)
    name = name.replace("_", " ").replace(".", " ")
    name = re.sub(r"\[[^\]]+\]", " ", name)
    name = re.sub(r"\([^\)]*\)", " ", name)
    name = re.sub(r"\{[^\}]+\}", " ", name)
    name = re.sub(r"\s{2,}", " ", name).strip()

    year = extract_emc_year(name)
    if year:
        year_match = re.search(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)", name)
        if year_match:
            title_part = name[:year_match.start()].strip(" -._")
            title_part = re.sub(r"\s{2,}", " ", title_part).strip(" -._")
            name = "{} {}".format(title_part, year).strip()
    else:
        for pat in _GARBAGE_RE:
            name = pat.sub(" ", name)

    name = re.sub(r"\s+-\s+", " ", name)
    name = name.replace("-", " ")
    name = re.sub(r"\s{2,}", " ", name).strip(" -._")

    clean_title = re.sub(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)$", "", name).strip()
    clean_title = re.sub(r"\s{2,}", " ", clean_title).strip()

    if not clean_title or clean_title.lower() in ("", "rarbg", "com", "www", "sample", "trailer", "yts", "psa"):
        return "", "", is_ep, ep_marker

    return clean_title, year, is_ep, ep_marker

def clean_filename(raw):
    if not raw:
        return "", "", False, ""
    with _filename_cache_lock:
        if raw in _filename_cache:
            _filename_cache.move_to_end(raw)
            return _filename_cache[raw]
    result = _clean_filename_uncached(raw)
    with _filename_cache_lock:
        _filename_cache[raw] = result
        if len(_filename_cache) > _FILENAME_CACHE_MAX:
            _filename_cache.popitem(last=False)
    return result

def build_emc_candidates(filename):
    clean, year, is_ep, _ = clean_filename(filename)
    if not clean:
        return []
    candidates = []
    if year and not is_ep:
        candidates.append("{} {}".format(clean, year))
    candidates.append(clean)
    numeral_variant = numeral_variant_candidate(clean)
    if numeral_variant and numeral_variant != clean:
        candidates.append(numeral_variant)
    raw_name = os.path.splitext(os.path.basename(filename))[0]
    raw_name = re.sub(r'[._\-]+', ' ', raw_name)
    raw_name = re.sub(r'\s+', ' ', raw_name).strip()
    if raw_name and raw_name not in candidates:
        candidates.append(raw_name)
    return candidates

def get_sidecar_path(video_path, ext=".jpg"):
    if not video_path:
        return None
    base, _ = os.path.splitext(video_path)
    return base + ext

# ============================================================================
# 5. SHARED SOURCE / MEDIA EXTRACTION
# ============================================================================
def get_service_ref(source):
    if source is None:
        return None
    if hasattr(source, 'toString') and not hasattr(source, 'getCurrentService'):
        return source
    if isinstance(source, ServiceEvent):
        return source.getCurrentService()
    if isinstance(source, CurrentService):
        return source.getCurrentServiceRef()
    if isinstance(source, (EventInfo, Event)):
        return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
    class_name = source.__class__.__name__
    if class_name in ("EMCServiceEvent", "Service"):
        if hasattr(source, "service"):
            return source.service
        elif hasattr(source, "getCurrentService"):
            return source.getCurrentService()
    return NavigationInstance.instance.getCurrentlyPlayingServiceReference()

def get_movie_path(source):
    if source is None:
        return None
    if hasattr(source, "getPath"):
        return source.getPath()
    if hasattr(source, "service") and hasattr(source.service, "getPath"):
        return source.service.getPath()
    if hasattr(source, "getCurrentService"):
        svc = source.getCurrentService()
        if svc and hasattr(svc, "getPath"):
            return svc.getPath()
    if isinstance(source, ServiceEvent):
        svc = source.getCurrentService()
        if svc and hasattr(svc, "getPath"):
            return svc.getPath()
    if isinstance(source, CurrentService):
        svc = source.getCurrentServiceRef()
        if svc and hasattr(svc, "getPath"):
            return svc.getPath()
    return None

def detect_media(source):
    movie_path = get_movie_path(source)
    is_media = bool(movie_path and is_video_file(movie_path))
    if not is_media:
        return {"is_media": False, "movie_path": None, "clean_title": "",
                "year": "", "is_episode": False, "ep_marker": ""}
    clean_title, year, is_ep, ep_marker = clean_filename(movie_path)
    return {"is_media": True, "movie_path": movie_path, "clean_title": clean_title,
            "year": year, "is_episode": is_ep, "ep_marker": ep_marker}

# ============================================================================
# 6. SQLITE-BACKED STATE STORE (with async flush)
# ============================================================================
MAX_RETRIES   = 2
RETRY_DELAY_S = 7200
CLEANUP_DAYS_FAILED  = 7
CLEANUP_DAYS_SUCCESS = 180
CLEANUP_INTERVAL_S   = 6 * 3600

class StateStore(object):
    TABLE_SCHEMA = """CREATE TABLE IF NOT EXISTS {table} (
        title TEXT PRIMARY KEY,
        status TEXT,
        retries INTEGER DEFAULT 0,
        next_scan INTEGER DEFAULT 0,
        last_scan INTEGER DEFAULT 0,
        poster_ok INTEGER DEFAULT 0,
        backdrop_ok INTEGER DEFAULT 0,
        logo_ok INTEGER DEFAULT 0,
        data TEXT DEFAULT '{{}}'
    )"""

    def __init__(self, emc_mode):
        self.emc_mode = emc_mode
        self.table = "emc" if emc_mode else "epg"
        self._data = {}
        self._lock = threading.Lock()
        self._write_lock = threading.Lock()
        self._dirty_keys = set()
        self._deleted_keys = set()
        self._last_cleanup = 0
        self._flush_requested = threading.Event()
        self._conn = None
        self._load()
        if len(self._data) > 2000:
            sorted_items = sorted(self._data.items(), key=lambda kv: kv[1].get("last_scan", 0), reverse=True)
            self._data = dict(sorted_items[:2000])

    def _connect(self):
        if self._conn is None:
            path = get_metadata_db_path()
            self._conn = sqlite3.connect(path, timeout=10, check_same_thread=False)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.execute(self.TABLE_SCHEMA.format(table=self.table))
            self._conn.commit()
        return self._conn

    @traced("StateStore")
    def _load(self):
        try:
            conn = self._connect()
            cur = conn.execute("SELECT title, status, retries, next_scan, last_scan, "
                                "poster_ok, backdrop_ok, logo_ok, data FROM %s" % self.table)
            loaded = {}
            for row in cur:
                title, status, retries, next_scan, last_scan, poster_ok, backdrop_ok, logo_ok, data_json = row
                try:
                    record = json.loads(data_json) if data_json else {}
                except Exception:
                    record = {}
                record["status"] = status
                record["retries"] = retries
                record["next_scan"] = next_scan
                record["last_scan"] = last_scan
                record["poster_ok"] = bool(poster_ok)
                record["backdrop_ok"] = bool(backdrop_ok)
                record["logo_ok"] = bool(logo_ok)
                loaded[title] = record
            self._data = loaded
            dbg("StateStore", "loaded", "emc=%s entries=%d (sqlite)" % (self.emc_mode, len(self._data)))
        except Exception as e:
            warn("StateStore", "load-error", str(e))
            self._data = {}

    def flush(self, force=False):
        import threading
        if threading.current_thread().name == 'MainThread' and not force:
            self._flush_requested.set()
            return

        with self._write_lock:
            with self._lock:
                if not force and not self._dirty_keys and not self._deleted_keys:
                    return
                dirty = {k: dict(self._data[k]) for k in self._dirty_keys if k in self._data}
                deleted = list(self._deleted_keys)
                self._dirty_keys = set()
                self._deleted_keys = set()
            if not dirty and not deleted:
                return
            t0 = time.time()
            try:
                conn = self._connect()
                rows = []
                for title, record in dirty.items():
                    extra = {k: v for k, v in record.items()
                             if k not in ("status", "retries", "next_scan", "last_scan",
                                          "poster_ok", "backdrop_ok", "logo_ok")}
                    rows.append((
                        title,
                        record.get("status"),
                        int(record.get("retries", 0)),
                        int(record.get("next_scan", 0)),
                        int(record.get("last_scan", 0)),
                        1 if record.get("poster_ok") else 0,
                        1 if record.get("backdrop_ok") else 0,
                        1 if record.get("logo_ok") else 0,
                        json.dumps(extra, separators=(",", ":")),
                    ))
                if rows:
                    conn.executemany(
                        "INSERT OR REPLACE INTO %s "
                        "(title, status, retries, next_scan, last_scan, poster_ok, backdrop_ok, logo_ok, data) "
                        "VALUES (?,?,?,?,?,?,?,?,?)" % self.table, rows)
                if deleted:
                    conn.executemany("DELETE FROM %s WHERE title=?" % self.table,
                                      [(t,) for t in deleted])
                conn.commit()
                dt_ms = (time.time() - t0) * 1000
                level_fn = warn if dt_ms > 200 else dbg
                level_fn("StateStore", "flush", "emc=%s upserts=%d deletes=%d %.0fms" % (
                    self.emc_mode, len(rows), len(deleted), dt_ms))
            except Exception as e:
                warn("StateStore", "write-error", str(e))
                with self._lock:
                    self._dirty_keys.update(dirty.keys())
                    self._deleted_keys.update(deleted)

    def get(self, title):
        with self._lock:
            return self._data.get(title)

    def get_many(self, titles):
        with self._lock:
            return {t: self._data.get(t, {}) for t in titles}

    def is_ok(self, title):
        entry = self.get(title)
        return entry is not None and entry.get("status") == "ok"

    def set_record(self, key, **fields):
        with self._lock:
            record = self._data.setdefault(key, {})
            record.update(fields)
            record["last_scan"] = int(time.time())
            self._dirty_keys.add(key)
        self._flush_requested.set()

    def mark_not_found(self, title):
        with self._lock:
            retries = int(self._data.get(title, {}).get("retries", 0)) + 1
        self.set_record(title, status="failed", retries=retries,
                         next_scan=int(time.time()) + RETRY_DELAY_S)

    def should_download(self, title, kind_key):
        entry = self.get(title)
        if entry is None:
            return True
        if entry.get(kind_key):
            return False
        status = entry.get("status", "pending")
        retries = int(entry.get("retries", 0))
        next_sc = int(entry.get("next_scan", 0))
        if status == "failed":
            return retries < MAX_RETRIES and time.time() >= next_sc
        return True

    def cleanup(self, force=False):
        now = time.time()
        if not force and now - self._last_cleanup < CLEANUP_INTERVAL_S:
            return
        self._last_cleanup = now
        to_del = []
        with self._lock:
            for title, entry in self._data.items():
                ls = entry.get("last_scan", 0)
                status = entry.get("status", "")
                retries = entry.get("retries", 0)
                if status == "failed" and retries >= MAX_RETRIES and now - ls > CLEANUP_DAYS_FAILED * 86400:
                    to_del.append(title)
                elif status == "ok" and now - ls > CLEANUP_DAYS_SUCCESS * 86400:
                    to_del.append(title)
            for t in to_del:
                del self._data[t]
                self._dirty_keys.discard(t)
                self._deleted_keys.add(t)
        if to_del:
            self.flush(force=True)
            dbg("StateStore", "cleanup", "emc=%s removed=%d" % (self.emc_mode, len(to_del)))

_epg_store = StateStore(emc_mode=False)
_emc_store = StateStore(emc_mode=True)

def get_state_store(emc_mode):
    return _emc_store if emc_mode else _epg_store

def reset_asset_ok_flags(kind):
    field = "%s_ok" % kind
    total = 0
    for store in (_epg_store, _emc_store):
        with store._lock:
            for title, record in store._data.items():
                if record.get(field):
                    record[field] = False
                    store._dirty_keys.add(title)
                    total += 1
        store.flush(force=True)
    dbg("iConverlibr", "reset_asset_ok_flags", "kind=%s cleared=%d" % (kind, total))
    return total

def _persist_loop(store, name):
    while True:
        store._flush_requested.wait(timeout=30)
        store._flush_requested.clear()
        store.flush()

def _maintenance_loop():
    while True:
        time.sleep(300)
        _epg_store.cleanup()
        _emc_store.cleanup()
        refresh_all_indexes()

for _store, _name in ((_epg_store, "epg"), (_emc_store, "emc")):
    _t = threading.Thread(target=_persist_loop, args=(_store, _name))
    _t.daemon = True
    _t.start()

_maint_thread = threading.Thread(target=_maintenance_loop)
_maint_thread.daemon = True
_maint_thread.start()

def _store_health_stats():
    return {
        "epg_entries": len(_epg_store._data), "epg_dirty": len(_epg_store._dirty_keys),
        "emc_entries": len(_emc_store._data), "emc_dirty": len(_emc_store._dirty_keys),
        "search_cache": len(_search_cache),
        "folder_indexes": {f: len(idx._files) for f, idx in _folder_indexes.items()},
    }

register_health_probe("StateStore", _store_health_stats)

# ============================================================================
# 6b. METADATA CALLBACK / GUI DISPATCHER (unchanged)
# ============================================================================
_metadata_callbacks = {}
_metadata_callback_lock = threading.Lock()
_ready_queue = []
_ready_queue_lock = threading.Lock()
_gui_dispatcher_timer = eTimer()

def register_metadata_callback(clean_title, renderer_ref, method_name="changed"):
    if not clean_title or renderer_ref is None:
        return
    with _metadata_callback_lock:
        bucket = _metadata_callbacks.setdefault(clean_title, [])
        entry = (weakref.ref(renderer_ref), method_name)
        for existing in bucket:
            if existing[0]() == renderer_ref and existing[1] == method_name:
                return
        bucket.append(entry)

def unregister_metadata_callback(clean_title, renderer_obj):
    if not clean_title or renderer_obj is None:
        return
    with _metadata_callback_lock:
        bucket = _metadata_callbacks.get(clean_title)
        if not bucket:
            return
        bucket[:] = [entry for entry in bucket if entry[0]() != renderer_obj]
        if not bucket:
            del _metadata_callbacks[clean_title]

def notify_metadata_ready(clean_title):
    if not clean_title:
        return
    with _ready_queue_lock:
        _ready_queue.append(("meta", clean_title, None))
    _schedule_drain()

def queue_gui_callback(callback, *args):
    if callback is None:
        return
    with _ready_queue_lock:
        _ready_queue.append(("call", callback, args))
    _schedule_drain()

def _schedule_drain():
    try:
        _gui_dispatcher_timer.start(0, True)
    except Exception:
        pass

@traced("iConverlibr")
def _drain_ready_queue():
    with _ready_queue_lock:
        if not _ready_queue:
            return
        items = _ready_queue[:]
        del _ready_queue[:]
    for kind, a, b in items:
        if kind == "meta":
            clean_title = a
            with _metadata_callback_lock:
                raw = _metadata_callbacks.pop(clean_title, [])
                alive = [entry for entry in raw if entry[0]() is not None]
                if alive:
                    _metadata_callbacks[clean_title] = alive
                    for weakref_obj, method_name in alive:
                        renderer = weakref_obj()
                        if renderer and hasattr(renderer, method_name):
                            try:
                                getattr(renderer, method_name)((renderer.CHANGED_DEFAULT,))
                            except Exception as e:
                                err("Dispatcher", "meta-callback-EX", "title=%s err=%s" % (clean_title, e))
                else:
                    pass
        elif kind == "call":
            try:
                a(*b)
            except Exception as e:
                err("Dispatcher", "gui-callback-EX", str(e))
    with _ready_queue_lock:
        has_more = bool(_ready_queue)
    if has_more:
        _schedule_drain()

_gui_dispatcher_timer.callback.append(_drain_ready_queue)

# ============================================================================
# 7. TMDB SEARCH CACHE
# ============================================================================
_SEARCH_TTL   = 1800
_SEARCH_CACHE_MAX = 500
_search_cache = OrderedDict()
_search_lock  = threading.Lock()

def get_cached_search(clean_title):
    if not clean_title:
        return None
    with _search_lock:
        entry = _search_cache.get(clean_title)
        if entry is None:
            return None
        ts, result = entry
        if time.time() - ts > _SEARCH_TTL:
            del _search_cache[clean_title]
            return None
        _search_cache.move_to_end(clean_title)
        return result

def set_cached_search(clean_title, result):
    if not clean_title or not result:
        return
    with _search_lock:
        _search_cache[clean_title] = (time.time(), result)
        _search_cache.move_to_end(clean_title)
        if len(_search_cache) > _SEARCH_CACHE_MAX:
            _search_cache.popitem(last=False)

# ============================================================================
# 8. ZAP CONTEXT – LAZY BUILD + ASYNC FILE CHECKS
# ============================================================================
_registered_nxts = set()
_nxts_refcounts = {}
_widget_refcounts = {"poster": 0, "backdrop": 0, "logo": 0, "info": 0, "parental": 0}

def register_nxts_slot(nxts):
    try:
        nxts = int(nxts)
    except Exception:
        return
    if nxts < 0:
        return
    _registered_nxts.add(nxts)
    _nxts_refcounts[nxts] = _nxts_refcounts.get(nxts, 0) + 1

def unregister_nxts_slot(nxts):
    try:
        nxts = int(nxts)
    except Exception:
        return
    if nxts in _nxts_refcounts:
        _nxts_refcounts[nxts] = max(0, _nxts_refcounts[nxts] - 1)

def _current_max_nxts():
    live = [n for n, c in _nxts_refcounts.items() if c > 0]
    return (max(live) + 1) if live else 1

def register_widget_present(kind):
    if kind in _widget_refcounts:
        _widget_refcounts[kind] += 1

def unregister_widget_present(kind):
    if kind in _widget_refcounts:
        _widget_refcounts[kind] = max(0, _widget_refcounts[kind] - 1)

def widget_present(kind):
    return _widget_refcounts.get(kind, 0) > 0

def _format_genres(genres_string):
    if not genres_string:
        return ""
    parts = [g.strip() for g in genres_string.split(",") if g.strip()]
    return u" \u2022 ".join(parts)

_RTL_RE = re.compile(u"[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF\u0590-\u05FF]", re.UNICODE)

@lru_cache(maxsize=500)
def cached_format_overview(text):
    if not text:
        return text
    sample = text[:120]
    if len(_RTL_RE.findall(sample)) <= len(sample) * 0.25:
        return text
    words, lines, line, length = text.split(), [], [], 0
    for w in words:
        wl = len(w)
        if length + wl + (1 if line else 0) > 70 and line:
            lines.append(" ".join(line))
            line, length = [w], wl
        else:
            line.append(w)
            length += wl + (1 if len(line) > 1 else 0)
    if line:
        lines.append(" ".join(line))
    return "\n".join(lines)

def format_overview(text):
    if not text or not _runtime_cfg.get("RTL_OVERVIEW", True):
        return text
    return cached_format_overview(text)

def has_useful_metadata(entry):
    if not entry or entry.get("status") not in ("ok", "found"):
        return False
    return bool(
        entry.get("vote_average", 0) > 0 or entry.get("parental_rating") or
        entry.get("genres") or entry.get("year") or entry.get("director") or
        entry.get("cast") or len(entry.get("overview", "")) > 50 or entry.get("title"))

def build_meta_dict(entry):
    rv = entry.get("vote_average", 0)
    try:
        rv = float(rv) if rv else 0
    except Exception:
        rv = 0
    ov = entry.get("overview", "") or ""
    formatted = format_overview(ov)
    return {
        "rating": rv, "parental": entry.get("parental_rating", ""),
        "genres": _format_genres(entry.get("genres", "")), "year": entry.get("year", ""),
        "overview": formatted,
        "plot": formatted,
        "title": entry.get("title", ""), "country": entry.get("country", ""),
        "director": entry.get("director", ""), "cast": entry.get("cast", ""),
        "rated": entry.get("parental_rating", ""), "imdb": str(rv) if rv > 0 else "",
        "metadata_resolved": True,
    }

# ----- Async file check queue -----
_file_check_queue = []
_file_check_lock = threading.Lock()
_file_check_thread = None
_file_check_event = threading.Event()

def _async_file_check_worker():
    while True:
        _file_check_event.wait(timeout=0.1)
        _file_check_event.clear()
        with _file_check_lock:
            if not _file_check_queue:
                continue
            batch = _file_check_queue[:50]
            del _file_check_queue[:len(batch)]
        for ctx_ref, nxts, kind, folder, fname in batch:
            ctx = ctx_ref()
            if ctx is None:
                continue
            path = os.path.join(folder, fname) if file_exists_indexed(folder, fname) else None
            ctx.apply_async_file_results(nxts, kind, path)

def _schedule_async_file_checks(ctx):
    with _file_check_lock:
        pending = list(ctx._file_check_pending)
        ctx._file_check_pending.clear()
        for item in pending:
            _file_check_queue.append((weakref.ref(ctx),) + item)
    _file_check_event.set()
    global _file_check_thread
    if _file_check_thread is None or not _file_check_thread.is_alive():
        _file_check_thread = threading.Thread(target=_async_file_check_worker, daemon=True)
        _file_check_thread.start()

# ----- SHARED FALLBACK PRELOADER -----
_fallback_pixmaps = {}
_fallback_loaded = threading.Event()
_fallback_loading = False
_fallback_lock = threading.Lock()

def _ensure_fallbacks_loaded():
    global _fallback_loading
    if _fallback_loaded.is_set():
        return
    with _fallback_lock:
        if _fallback_loaded.is_set() or _fallback_loading:
            return
        _fallback_loading = True
    
    def _load():
        global _fallback_pixmaps
        try:
            cur_skin = str(config.skin.primary_skin.value.replace("/skin.xml", ""))
        except Exception:
            cur_skin = "default"
        for name in ["noposter.jpg", "nobackdrop.jpg"]:
            for path in ["/usr/share/enigma2/%s/main/%s" % (cur_skin, name),
                        "/usr/share/enigma2/skin_default/main/%s" % name,
                        "/tmp/%s" % name]:
                if os.path.exists(path):
                    try:
                        _fallback_pixmaps[name] = loadJPG(path)
                    except Exception:
                        pass
                    break
        _fallback_loaded.set()
    
    threading.Thread(target=_load, daemon=True).start()

def get_fallback_pixmap(name):
    _ensure_fallbacks_loaded()
    if not _fallback_loaded.is_set():
        return None
    return _fallback_pixmaps.get(name)

# ----- ZapContext (with __weakref__) -----
class ZapContext(object):
    __slots__ = ("_ref_str", "_slots", "_ch_skip", "_slot_count", "generation", "missing",
                 "_lock", "_analyzed_cache", "_events_raw", "_slot_0_built", "_slots_built",
                 "_file_check_pending", "_epg_retry_count", "_epg_retry_timer", "__weakref__")

    def __init__(self, ref_str, events, ch_skip=False, generation=0):
        self._ref_str = ref_str
        self._ch_skip = ch_skip
        self.generation = generation
        self._slot_count = 0
        self._slots = {}
        self.missing = []
        self._lock = threading.Lock()
        self._analyzed_cache = {}
        self._events_raw = events if events else []
        self._slot_0_built = False
        self._slots_built = set()
        self._file_check_pending = set()
        self._epg_retry_count = 0
        self._epg_retry_timer = None
        # Build only slot 0 immediately
        self._build_slot(0)

    def _build_slot(self, nxts):
        events = self._events_raw
        if not events or nxts >= len(events):
            return
        evt = events[nxts]
        if len(evt) < 5 or not evt[4]:
            return
        raw = clean_name(evt[4])
        desc = evt[5] if len(evt) > 5 else ""
        begin_time = evt[1] if len(evt) > 1 else 0
        if raw not in self._analyzed_cache:
            self._analyzed_cache[raw] = analyze_epg_title(raw)
        skip, clean, candidates = self._analyzed_cache[raw]
        skip = skip or self._ch_skip

        pfolder = get_poster_folder()
        bfolder = get_backdrop_folder()
        lfolder = get_logo_folder()

        json_data = _epg_store.get(clean) or {}

        store_has_poster = json_data.get("poster_ok", False)
        store_has_backdrop = json_data.get("backdrop_ok", False)
        store_has_logo = json_data.get("logo_ok", False)

        assets = resolve_asset_paths(
            clean,
            want_poster=store_has_poster,
            want_backdrop=store_has_backdrop,
            want_logo=store_has_logo,
        ) if clean else {"local_path": None, "backdrop_path": None, "logo_path": None}
        exists_p = assets["local_path"]
        exists_b = assets["backdrop_path"]
        exists_l = assets["logo_path"]

        if clean:
            if not exists_p:
                self._file_check_pending.add((nxts, "poster", pfolder, clean + ".jpg"))
            if not exists_b:
                self._file_check_pending.add((nxts, "backdrop", bfolder, clean + ".jpg"))
            if not exists_l:
                self._file_check_pending.add((nxts, "logo", lfolder, clean + ".png"))

        meta = None
        if clean and has_useful_metadata(json_data):
            meta = build_meta_dict(json_data)

        slot = {
            "clean_title": clean,
            "local_path": exists_p,
            "backdrop_path": exists_b,
            "logo_path": exists_l,
            "skip": skip,
            "search_candidates": candidates,
            "event_key": "%s-%s" % (begin_time, raw),
            "raw_name": raw,
            "description": desc,
        }
        if meta:
            slot.update(meta)
        else:
            slot.update({"metadata_resolved": False, "rating": 0, "parental": "",
                         "genres": "", "year": "", "overview": "", "plot": "",
                         "title": "", "country": "", "director": "", "cast": "",
                         "rated": "", "imdb": ""})

        with self._lock:
            self._slots[nxts] = slot
            self._slot_count = max(self._slot_count, nxts + 1)
            if nxts == 0:
                self._slot_0_built = True
            self._slots_built.add(nxts)

        if self._file_check_pending:
            _schedule_async_file_checks(self)

        if clean and not skip:
            needs_poster = not exists_p
            needs_backdrop = not exists_b
            needs_logo = not exists_l
            if needs_poster or needs_backdrop or needs_logo:
                with self._lock:
                    existing = [m[0] for m in self.missing]
                    if clean not in existing:
                        self.missing.append((clean, raw, candidates))

    def apply_async_file_results(self, nxts, kind, path):
        key = {"poster": "local_path", "backdrop": "backdrop_path", "logo": "logo_path"}.get(kind)
        if not key:
            return
        with self._lock:
            slot = self._slots.get(nxts)
            if slot is None:
                return
            slot[key] = path
            self.generation += 1
        clean = slot.get("clean_title", "")
        if clean:
            notify_metadata_ready(clean)

    def get_slot(self, nxts):
        with self._lock:
            if nxts in self._slots:
                return self._slots[nxts]
        if nxts < len(self._events_raw):
            self._build_slot(nxts)
        with self._lock:
            return self._slots.get(nxts)

    def update_slot_metadata(self, clean_title, meta_dict):
        with self._lock:
            changed = False
            for slot in self._slots.values():
                if slot.get("clean_title") == clean_title:
                    slot.update(meta_dict)
                    changed = True
            if changed:
                self.generation += 1

    def update_slot_asset(self, clean_title, kind, path):
        key = {"poster": "local_path", "backdrop": "backdrop_path", "logo": "logo_path"}.get(kind)
        if not key:
            return
        with self._lock:
            for slot in self._slots.values():
                if slot.get("clean_title") == clean_title:
                    slot[key] = path
            self.generation += 1

    def is_valid_for(self, ref_str):
        return self._ref_str == ref_str

    @property
    def ref_str(self):
        return self._ref_str

    def schedule_retry(self):
        if self._epg_retry_count >= 3:
            return False
        self._epg_retry_count += 1
        if self._epg_retry_timer is None:
            self._epg_retry_timer = eTimer()
            self._epg_retry_timer.callback.append(self._do_retry)
        delay = min(500 * (2 ** self._epg_retry_count), 2000)
        self._epg_retry_timer.start(delay, True)
        return True

    def _do_retry(self):
        self.generation += 1
        for nxts in self._slots_built:
            slot = self._slots.get(nxts)
            if slot:
                clean = slot.get("clean_title", "")
                if clean:
                    notify_metadata_ready(clean)

class _EpgCache(object):
    __slots__ = ("_data", "_ref", "_last_fetch")
    def __init__(self):
        self._data = []
        self._ref = None
        self._last_fetch = 0
    def get(self, service_ref):
        if not service_ref:
            return []
        ref_str = service_ref.toString()
        now = time.time()
        age = now - self._last_fetch
        if self._ref == ref_str:
            if self._data and age < 2.0:
                return self._data
            if not self._data and age < 1.0:
                return self._data
        events = []
        try:
            from enigma import eEPGCache
            epg = eEPGCache.getInstance()
            if epg:
                result = epg.lookupEvent(["IBOCTESX", (ref_str, 0, -1, -1)])
                if result:
                    events = result
        except Exception:
            pass
        self._data, self._ref, self._last_fetch = events, ref_str, now
        return events

_epg_cache = _EpgCache()
_zap_ctx = None
_zap_ctx_lock = threading.Lock()
_zap_ctx_gen = [0]
_current_ref = [None]
_batch_request_fn = [None]

def set_batch_request_fn(fn):
    _batch_request_fn[0] = fn

def invalidate_zap_context(force=False, for_title=None):
    global _zap_ctx
    with _zap_ctx_lock:
        if force:
            _zap_ctx = None
            return
        ctx = _zap_ctx
        if ctx is None:
            return
        cur = _current_ref[0]
        if not cur or not ctx.is_valid_for(cur):
            return
        if for_title:
            for slot in ctx._slots.values():
                if slot.get("clean_title") == for_title:
                    _zap_ctx = None
                    return
        else:
            _zap_ctx = None

@traced("iConverlibr")
def get_event_source_metadata(event_source):
    try:
        evt = event_source.event
        if not evt:
            return None
        raw = clean_name(evt.getEventName())
        if not raw or _is_no_info(raw):
            return None
        skip, clean, candidates = analyze_epg_title(raw)
        if skip or not clean:
            return None
        begin_time = evt.getBeginTime() or 0
        event_key = "%s-%s" % (begin_time, raw)

        assets = resolve_asset_paths(clean)

        entry = _epg_store.get(clean) or {}
        slot = {
            "clean_title": clean,
            "local_path": assets["local_path"],
            "backdrop_path": assets["backdrop_path"],
            "logo_path": assets["logo_path"],
            "skip": False, "search_candidates": candidates,
            "event_key": event_key, "raw_name": raw,
            "description": evt.getExtendedDescription() or "",
        }
        if has_useful_metadata(entry):
            slot.update(build_meta_dict(entry))
        else:
            slot.update({"metadata_resolved": False, "rating": 0, "parental": "",
                          "genres": "", "year": "", "overview": "", "plot": "",
                          "title": "", "country": "", "director": "", "cast": "",
                          "rated": "", "imdb": ""})
        return slot
    except Exception as e:
        warn("iConverlibr", "event-source-metadata-EX", str(e))
        return None

@traced("iConverlibr")
def get_zap_context(service_ref):
    global _zap_ctx
    if service_ref is None:
        return None
    ref_str = service_ref.toString()
    _current_ref[0] = ref_str

    if "FROM BOUQUET" in ref_str or "ORDER BY bouquet" in ref_str:
        return ZapContext("bouquet", [], True, generation=0)

    with _zap_ctx_lock:
        ctx = _zap_ctx
        if ctx is not None and ctx.is_valid_for(ref_str):
            return ctx

        ch_skip = False
        try:
            from ServiceReference import ServiceReference as SR
            ch_name = clean_name(SR(service_ref).getServiceName())
            ch_skip = any(x in ch_name.lower() for x in SKIP_CHANNEL_KEYWORDS)
        except Exception:
            pass

        _zap_ctx_gen[0] += 1
        gen = _zap_ctx_gen[0]

        if ch_skip:
            _zap_ctx = ZapContext(ref_str, [], True, generation=gen)
            return _zap_ctx

        events = _epg_cache.get(service_ref)
        _zap_ctx = ZapContext(ref_str, events or [], ch_skip, generation=gen)
        if events and _zap_ctx.missing and _batch_request_fn[0]:
            try:
                _batch_request_fn[0](_zap_ctx.missing)
            except Exception as e:
                err("iConverlibr", "batch-request-EX", str(e))

    return _zap_ctx

# ============================================================================
# Startup cleanup
# ============================================================================
def _startup_cleanup():
    _epg_store.cleanup(force=True)
    _emc_store.cleanup(force=True)
    refresh_all_indexes()

threading.Thread(target=_startup_cleanup, daemon=True).start()