#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iBackdropX.py - XDREAMY SKIN V6.10.0
BACKDROP DISPLAY RENDERER

V6.9: Uses get_zap_context() — ONE EPG per zap shared by ALL renderers.
      Zero independent EPG lookups.

V6.9.1 PATCHES:
 - Fixed callback registration race (register BEFORE setting _waiting_key)
 - Added stale waiting timeout (_waiting_since, _waiting_timeout)
 - Fixed lock-free nobackdrop access (_nobackdrop_loaded flag)
 - Added proper destroy() with cleanup
 - Added _check_stale_pending() for timeout handling

V6.10.0 — brought up to parity with iPosterX.py:
 - Dynamic nxts-slot registration (register_nxts_slot) instead of relying
   on whatever cap posters happened to register — backdrops and posters
   share the same EPG-window slots, so this also makes sure a skin using
   MORE backdrop widgets than poster widgets isn't silently truncated.
 - Generation-based dedup: skip the whole get_zap_context() round trip's
   downstream work when nothing has changed since our last full
   evaluation of this exact channel+generation (same fix applied to
   iPosterX/iStarX/iParental/iInfoEvents after the trace log showed most
   changed() calls were re-deriving an unchanged result).
 - Removed a stale changelog line referencing a "MAX_LINES display limit"
   that was never actually implemented in this file.
"""

from __future__ import absolute_import, print_function

import os
import threading
import time

from Components.Renderer.Renderer import Renderer
from Components.Sources.CurrentService import CurrentService
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.ServiceEvent import ServiceEvent
from Components.config import config
from ServiceReference import ServiceReference
from enigma import ePixmap, loadJPG
import NavigationInstance

from .iConverlibr import (
    get_zap_context,
    is_sport_or_news_channel,
    clean_name,
    convtext,
    register_nxts_slot,
)
from .iBackdropXDownloadThread import (
    queue_live,
    path_folder,
    log,
    register_renderer_callback,
    unregister_renderer,
)
from .iDebugTrace import trace  # DEBUG TRACE - remove this line when done diagnosing

# ── no-backdrop image ─────────────────────────────────────────────────────────
try:
    _cur_skin = config.skin.primary_skin.value.replace("/skin.xml", "")
except Exception:
    _cur_skin = "default"

nobackdrop = None
for _name in ["nobackdrop.jpg", "noposter.jpg"]:
    for _path in [
        "/usr/share/enigma2/%s/main/%s" % (_cur_skin, _name),
        "/usr/share/enigma2/skin_default/main/%s" % _name,
        "/tmp/%s" % _name,
    ]:
        if os.path.exists(_path):
            nobackdrop = _path
            break
    if nobackdrop:
        break

# V6.9.1 PATCH: Lock-free fast path for nobackdrop pixmap
_nobackdrop_pixmap = None
_nobackdrop_lock   = threading.Lock()


def _get_nobackdrop_pixmap():
    global _nobackdrop_pixmap
    if _nobackdrop_pixmap is None:
        with _nobackdrop_lock:
            if _nobackdrop_pixmap is None and nobackdrop and os.path.exists(nobackdrop):
                try:
                    _nobackdrop_pixmap = loadJPG(nobackdrop)
                except Exception:
                    pass
    return _nobackdrop_pixmap


class iBackdropX(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.nxts = 0
        self.path = path_folder
        self._old_key = None
        self._waiting_key = None
        # V6.9.1 PATCH: Stale waiting timeout
        self._waiting_since = 0
        self._waiting_timeout = 30  # seconds
        # V6.10.0: generation-based dedup — see iPosterX.py for the full
        # rationale. Skips get_zap_context()'s downstream work entirely
        # when nothing has changed since our last full evaluation.
        self._last_ref = None
        self._last_generation = -1

    def destroy(self):
        """V6.9.1 PATCH: Proper cleanup on widget destruction"""
        self._cleanup()
        Renderer.destroy(self)

    def applySkin(self, desktop, parent):
        keep = []
        for attrib, value in self.skinAttributes:
            if attrib == "nexts":
                try:
                    self.nxts = int(value)
                except Exception:
                    self.nxts = 0
            elif attrib == "path":
                self.path = str(value)
            keep.append((attrib, value))
        self.skinAttributes = keep
        register_nxts_slot(self.nxts)
        return Renderer.applySkin(self, desktop, parent)

    # ── service ref resolution ────────────────────────────────────────────────

    def _get_service_ref(self):
        src = self.source
        stype = type(src)
        if stype is Event and self.nxts:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        if stype is ServiceEvent:
            return src.getCurrentService()
        if stype is CurrentService:
            return src.getCurrentServiceRef()
        if stype is EventInfo:
            return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return None

    def _read_from_event_source(self):
        """Direct read for nxts=0 Event source — no EPG lookup."""
        try:
            evt = self.source.event
            if not evt:
                return None
            raw = clean_name(evt.getEventName())
            clean = convtext(raw)
            if not clean:
                return None
            local_path = os.path.join(self.path, clean + '.jpg')
            return {
                'clean_title': clean,
                'local_path': local_path if os.path.exists(local_path) else None,
                'skip': False,
                'search_candidates': [clean],
                'event_key': '%s-%s' % (evt.getBeginTime(), raw),
                'raw_name': raw,
            }
        except Exception:
            return None

    # ── V6.9.1 PATCH: Check for stale pending downloads ─────────────────────

    def _check_stale_pending(self):
        """Check if waiting for a download that has timed out"""
        if self._waiting_key and self._waiting_since:
            if time.time() - self._waiting_since > self._waiting_timeout:
                trace("iBackdropX", "stale-timeout", "nxts=%d title=%s" % (self.nxts, self._waiting_key))
                unregister_renderer(self._waiting_key, self)
                self._waiting_key = None
                self._waiting_since = 0
                return True
        return False

    # ── main changed() ────────────────────────────────────────────────────────

    def changed(self, what):
        if not self.instance:
            return

        if what[0] == self.CHANGED_CLEAR:
            self._cleanup()
            self._old_key = None
            self._last_ref = None
            self._last_generation = -1
            self._show_nobackdrop()
            return

        trace("iBackdropX", "changed-enter", "nxts=%d" % self.nxts)  # DEBUG TRACE

        # V6.9.1 PATCH: Check for stale pending downloads
        self._check_stale_pending()

        # ── resolve slot ──────────────────────────────────────────────────────
        slot = None
        service = None

        if type(self.source) is Event and self.nxts == 0:
            slot = self._read_from_event_source()
        else:
            try:
                service = self._get_service_ref()
                if service is None:
                    self._show_nobackdrop()
                    return
                ctx = get_zap_context(service)
                if ctx is None:
                    self._show_nobackdrop()
                    return

                # Generation dedup — see iPosterX.py for the full
                # rationale. Safe here too: any time a backdrop download
                # completes for a pending title, invalidate_zap_context()
                # runs first (in iPosterXDownloadThread.py's _mark_found,
                # shared across posters/backdrops/metadata), so the next
                # changed() call always sees a genuinely new generation.
                ref_str = ctx.ref_str
                if ref_str == self._last_ref and ctx.generation == self._last_generation:
                    trace("iBackdropX", "changed-exit", "nxts=%d reason=same-generation" % self.nxts)  # DEBUG TRACE
                    return
                self._last_ref = ref_str
                self._last_generation = ctx.generation

                slot = ctx.get_slot(self.nxts)
            except Exception as e:
                log("[iBackdropX] context error: %s" % e, "WARN")
                self._show_nobackdrop()
                return

        if not slot or slot.get('skip'):
            self._cleanup()
            self._old_key = None
            self._show_nobackdrop()
            trace("iBackdropX", "changed-exit", "nxts=%d reason=no-slot-or-skip" % self.nxts)  # DEBUG TRACE
            return

        # ── dedup guard ───────────────────────────────────────────────────────
        event_key = slot.get('event_key', '')
        if event_key == self._old_key:
            trace("iBackdropX", "changed-exit", "nxts=%d reason=dedup-same-key" % self.nxts)  # DEBUG TRACE
            return

        self._cleanup()
        self._old_key = event_key

        # ── sport/news channel check ──────────────────────────────────────────
        try:
            if service is None:
                service = self._get_service_ref()
            if service:
                ch = clean_name(ServiceReference(service).getServiceName())
                if is_sport_or_news_channel(ch):
                    self._show_nobackdrop()
                    trace("iBackdropX", "changed-exit", "nxts=%d reason=sport-news-skip" % self.nxts)  # DEBUG TRACE
                    return
        except Exception:
            pass

        clean_title = slot.get('clean_title', '')
        if not clean_title:
            self._show_nobackdrop()
            trace("iBackdropX", "changed-exit", "nxts=%d reason=no-clean-title" % self.nxts)  # DEBUG TRACE
            return

        # ── backdrop on disk ──────────────────────────────────────────────────
        local_path = os.path.join(self.path, clean_title + '.jpg')
        if os.path.exists(local_path):
            self._show_file(local_path)
            trace("iBackdropX", "changed-exit", "nxts=%d title=%s reason=shown-from-disk" % (self.nxts, clean_title))  # DEBUG TRACE
            return

        # ── not on disk: queue download ───────────────────────────────────────
        self._show_nobackdrop()

        # V6.9.1 PATCH: Register BEFORE setting _waiting_key to avoid race
        register_renderer_callback(clean_title, self)
        self._waiting_key = clean_title
        self._waiting_since = time.time()  # V6.9.1 PATCH: Track when we started waiting

        canal = [
            "",
            slot.get('event_key', ''),
            slot.get('raw_name', ''),
            "",
            slot.get('raw_name', ''),
            slot.get('raw_name', ''),
        ]
        queued = queue_live(clean_title, canal)

        # V6.9.1 PATCH: If queue failed, unregister immediately
        if not queued:
            unregister_renderer(clean_title, self)
            self._waiting_key = None
            self._waiting_since = 0

        trace("iBackdropX", "changed-exit", "nxts=%d title=%s reason=queued-download queued=%s" % (  # DEBUG TRACE
            self.nxts, clean_title, queued))

    # ── download callbacks ────────────────────────────────────────────────────

    def backdrop_download_completed(self, clean_title, path=None):
        if path is None:
            path = clean_title
            clean_title = self._waiting_key
        if not clean_title or clean_title != self._waiting_key:
            trace("iBackdropX", "download-completed-IGNORED", "nxts=%d title=%s waiting_for=%s" % (  # DEBUG TRACE
                self.nxts, clean_title, self._waiting_key))
            return
        if not self.instance:
            self._waiting_key = None
            self._waiting_since = 0
            return
        if not path or not os.path.exists(path):
            return
        self._waiting_key = None
        self._waiting_since = 0
        trace("iBackdropX", "download-completed-SHOWING", "nxts=%d title=%s" % (self.nxts, clean_title))  # DEBUG TRACE
        self._show_file(path)

    def poster_download_completed(self, clean_title, path=None):
        self.backdrop_download_completed(clean_title, path)

    # ── internal ──────────────────────────────────────────────────────────────

    def _cleanup(self):
        """V6.9.1 PATCH: Proper cleanup with timeout reset"""
        if self._waiting_key:
            unregister_renderer(self._waiting_key, self)
            self._waiting_key = None
            self._waiting_since = 0

    def _show_file(self, path):
        try:
            if not path or not os.path.exists(path):
                self._show_nobackdrop()
                return
            self.instance.setPixmap(loadJPG(path))
            self.instance.setScale(1)
            self.instance.show()
        except Exception as e:
            log("[iBackdropX] loadJPG error: %s" % e, "WARN")
            self._show_nobackdrop()

    def _show_nobackdrop(self):
        pix = _get_nobackdrop_pixmap()
        if pix:
            try:
                self.instance.setPixmap(pix)
                self.instance.setScale(1)
                self.instance.show()
                return
            except Exception:
                pass
        if nobackdrop and os.path.exists(nobackdrop):
            try:
                self.instance.setPixmap(loadJPG(nobackdrop))
                self.instance.setScale(1)
                self.instance.show()
                return
            except Exception:
                pass
        try:
            self.instance.show()
        except Exception:
            pass