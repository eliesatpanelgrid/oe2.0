#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
iBackdropX.py - XDREAMY SKIN V7.1
Python 3 only. Backdrop display. Shared cache, skin-attr parsing, and
EPG-slot preamble now live in iRendererBase -- this file only does the
backdrop-specific work.
"""

import os

from Components.Renderer.Renderer import Renderer
from enigma import ePixmap

from .iConverlibr import get_backdrop_folder, file_exists_indexed, build_emc_candidates, is_activated, get_fallback_pixmap
from .iRendererBase import RendererMixin, PixmapCache, parse_nxts_attribute
from .iDownloadThread import get_predecoded_pixmap as _get_predecoded
from .iDebugger import traced, dbg

_pixmap_cache = PixmapCache(max_entries=50)

class iBackdropX(RendererMixin, Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        RendererMixin.__init__(self)

    def destroy(self):
        self.mixin_destroy()
        Renderer.destroy(self)

    def applySkin(self, desktop, parent):
        self.nxts = parse_nxts_attribute(self.skinAttributes)
        self.mixin_apply_skin("backdrop")
        return Renderer.applySkin(self, desktop, parent)

    @traced("iBackdropX")
    def changed(self, what):
        if not self.instance:
            return
        if not is_activated():
            self._show_empty()
            return

        if what[0] == self.CHANGED_CLEAR:
            self.mixin_clear()
            self._show_empty()
            return

        branch, payload = self.resolve_slot()
        if branch == "same":
            return
        if branch == "media":
            self._handle_media(payload)
            return
        if branch == "no_service":
            self._show_empty()
            return

        preamble = self.epg_slot_preamble(payload)
        if preamble is None:
            self._show_empty()
            return
        if preamble == "same":
            return
        event_key, clean_title = preamble

        backdrop_path = self.resolve_asset_for_display(
            payload, "backdrop_path", get_backdrop_folder, ".jpg", "backdrop", clean_title, event_key,
            priority=self.priority_for(1))
        if backdrop_path:
            self._show_file(backdrop_path)
            return
        self._show_empty()

    def _handle_media(self, media):
        movie_path = media["movie_path"]
        clean_title = media["clean_title"]
        sidecar = self.get_sidecar_if_valid(movie_path, ".jpg")
        if sidecar:
            self._show_file(sidecar)
            return
        if not clean_title:
            self._show_empty()
            return
        bfolder = get_backdrop_folder()
        fname = clean_title + ".jpg"
        dest = os.path.join(bfolder, fname)
        if file_exists_indexed(bfolder, fname):
            self._show_file(dest)
            return
        candidates = build_emc_candidates(movie_path)
        self.request_and_wait("backdrop", clean_title, os.path.basename(movie_path), candidates, emc_mode=True, priority=1)
        self._show_empty()

    def on_asset_ready(self, kind, clean_title, path):
        if kind != "backdrop":
            return
        if not self.handle_asset_ready(kind, clean_title, path):
            return
        if not self.instance:
            return
        dbg("iBackdropX", "asset-ready", "title=%s" % clean_title)
        self._show_file(path)

    def _show_file(self, path):
        try:
            if not path:
                self._show_empty()
                return
            pix = _get_predecoded(path) or _pixmap_cache.get(path, is_png=False)
            if pix:
                self.instance.setPixmap(pix)
                self.instance.setScale(1)
                self.instance.show()
            else:
                self._show_empty()
        except Exception as e:
            dbg("iBackdropX", "load-error", str(e))
            self._show_empty()

    def _show_empty(self):
        pix = get_fallback_pixmap("nobackdrop.jpg")
        try:
            if pix:
                self.instance.setPixmap(pix)
                self.instance.setScale(1)
                self.instance.show()
            else:
                self.instance.show()
        except Exception:
            pass
