# -*- coding: utf-8 -*-
# XDREAMY SKIN PLUGIN - V6.6.0
# Cleaned - Removed: API keys, Weather plugins, EliSatPanel, NCam, MultiCamManager

import os
import random
import sys
import shutil
import glob
import re
import gettext
import locale

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import (
    configfile,
    ConfigOnOff,
    NoSave,
    ConfigText,
    ConfigSelection,
    ConfigSubsection,
    ConfigYesNo,
    config,
    getConfigListEntry,
    ConfigNothing,
)
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer, loadPic
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Tools.Directories import fileExists, SCOPE_PLUGINS, resolveFilename
from Tools.Downloader import downloadWithProgress
from Screens.ChoiceBox import ChoiceBox
from urllib.request import Request, urlopen

# Localization
plugin_name = "xDreamy"
locale_path = resolveFilename(SCOPE_PLUGINS, f"Extensions/{plugin_name}/locale")
gettext.bindtextdomain(plugin_name, locale_path)
gettext.textdomain(plugin_name)
_ = gettext.gettext

# Plugin version
version = "6.6.0"
cur_skin = config.skin.primary_skin.value.replace('xDreamy/skin.xml', '')
mvi = '/usr/share/'
bootlog = '/usr/lib/enigma2/python/Plugins/Extensions/xDreamy/bootlogos/'
logopath = '/etc/enigma2/'


# ============================================================================
# PATH FUNCTIONS
# ============================================================================
def isMountedInRW(path):
    testfile = os.path.join(path, 'tmp-rw-test')
    try:
        with open(testfile, 'w') as f:
            f.write('test')
        os.remove(testfile)
        return True
    except Exception:
        return False


# Paths for poster images
path_poster = "/tmp/XDREAMY/poster"
if os.path.exists("/media/hdd") and isMountedInRW("/media/hdd"):
    path_poster = "/media/hdd/XDREAMY/poster"
elif os.path.exists("/media/usb") and isMountedInRW("/media/usb"):
    path_poster = "/media/usb/XDREAMY/poster"
elif os.path.exists("/media/mmc") and isMountedInRW("/media/mmc"):
    path_poster = "/media/mmc/XDREAMY/poster"


def removePng():
    for folder in [path_poster]:
        if os.path.exists(folder):
            for ext in ["*.png", "*.jpg"]:
                for file in glob.glob(os.path.join(folder, ext)):
                    try:
                        os.remove(file)
                    except Exception:
                        pass


# ============================================================================
# CONFIGURATION
# ============================================================================
config.plugins.xDreamy = ConfigSubsection()
config.plugins.xDreamy.ShowInExtensions = ConfigYesNo(default=False)
config.plugins.xDreamy.png = NoSave(ConfigYesNo(default=False))
config.plugins.xDreamy.bootlogos = ConfigOnOff(default=False)
config.plugins.xDreamy.enablePosterX = ConfigYesNo(default=True)

# Plugin installation list
plugin_names = [
    "ajpanel", "linuxsatpanel", "CiefpPlugins", "smartpanel", "magicpanel", "keyadder",
    "xklass", "youtube", "e2iplayer", "transmission", "multistalkerpro",
    "subssupport", "historyzapselector", "newvirtualkeyboard", "raedquicksignal"
]
for plugin in plugin_names:
    setattr(config.plugins.xDreamy, f"install_{plugin}", NoSave(ConfigYesNo(default=False)))

# Color Templates
TEMPLATES = {
    'Blue': ('#caf0f8', '#023e8a', '#0003045e'),
    'Green': ('#b7e4c7', '#1b4332', '#00081c15'),
    'Red': ('#ffba08', '#6a040f', '#00370617'),
    'Purple': ('#97dffc', '#613dc1', '#004e148c'),
    'Grey': ('#ced4da', '#495057', '#00212529'),
}

# SKIN GENERAL SETUP
config.plugins.xDreamy.head = ConfigSelection(default='head', choices=[('head', _('Default'))])
config.plugins.xDreamy.skinSelector = ConfigSelection(default='base', choices=[('base', _('Default'))])
config.plugins.xDreamy.skinTemplate = ConfigSelection(default='templates', choices=[
    ('templates', _('Default')), ('templates1', _('Style1')), ('templates2', _('Style2')),
    ('templates3', _('Style3')), ('templates4', _('Style4')), ('templates5', _('Style5')),
    ('templates6', _('Style6')), ('templates7', _('Style7')), ('templates8', _('Style8'))])

config.plugins.xDreamy.KeysStyle = ConfigSelection(default='keys', choices=[
    ('keys', _('Default')), ('keys1', _('Keys1')), ('keys2', _('Keys2')),
    ('keys3', _('Keys3')), ('keys4', _('Keys4')), ('keys5', _('Keys5')), ('keys6', _('Keys6'))])

config.plugins.xDreamy.clockFormat = ConfigSelection(default="DigitalClock", choices=[
    ('DigitalClock', _('23:59 (24 hrs)')), ('DigitalClock1', _('23:59:33 (24 hrs)')),
    ('DigitalClock2', _('12:59 (12 hrs)')), ('DigitalClock3', _('12:59 AM (12 hrs)')),
    ('DigitalClock4', _('12:59 AM (12 hrs- MultiSize)')), ('DigitalClock5', _('12:59:33 (12 hrs- MultiSize)'))])

config.plugins.xDreamy.dateFormat = ConfigSelection(default="%d %B %Y", choices=[
    ("%d %B %Y", "01 January 2025"), ("%d %B %y", "01 January 25"),
    ("%d %b %Y", "01 Jan 2025"), ("%d %b %y", "01 Jan 25"),
    ("%d-%m-%Y", "01-01-2025"), ("%d-%m-%y", "01-01-25"),
    ("%Y-%m-%d", "2025-01-01"), ("%y-%m-%d", "25-01-01"),
    ("%m/%d/%Y", "01/01/2025"), ("%m/%d/%y", "01/01/25"),
    ("%d/%m/%Y", "01/01/2025"), ("%d/%m/%y", "01/01/25"),
    ("%Y/%m/%d %A", "2025/01/01 Monday"), ("%Y/%m/%d %a", "2025/01/01 Mon"),
    ("%Y.%m.%d", "2025.01.01"), ("%y.%m.%d", "25.01.01"),
    ("%A, %d %B %Y", "Monday, 01 January 2025"), ("%a, %d %b %Y", "Mon, 01 Jan 2025"),
    ("%A %d %B %Y", "Monday 01 January 2025"), ("%a %d %b %Y", "Mon 01 Jan 2025"),
    ("%d %B, %Y", "01 January, 2025"), ("%d %b, %Y", "01 Jan, 2025"),
    ("%B %d, %Y", "January 01, 2025"), ("%b %d, %Y", "Jan 01, 2025"),
    ("%Y %B %d", "2025 January 01"), ("%Y %b %d", "2025 Jan 01"),
    ("%y %B %d", "25 January 01"), ("%y %b %d", "25 Jan 01"),
    ("%d.%m.%Y", "01.01.2025"), ("%d.%m.%y", "01.01.25"),
    ("%d %m %Y", "01 01 2025"), ("%A, %d %m %Y", "Monday, 01 01 2025"),
    ("%a, %d %m %Y", "Mon, 01 01 2025"), ("%d %m %y", "01 01 25")])

# Colors
config.plugins.xDreamy.colorSelector = ConfigSelection(default='default-color', choices=[
    ('default-color', _('Default')), ('color23_Custom', _('Custom'))])

config.plugins.xDreamy.BasicColorTemplates = ConfigSelection(default='Blue', choices=[(key, _(key)) for key in TEMPLATES.keys()])
config.plugins.xDreamy.BasicColor = ConfigSelection(default='#ffffff')
config.plugins.xDreamy.WhiteColor = ConfigSelection(default='#ffffff')
config.plugins.xDreamy.SelectionColor = ConfigSelection(default='#1e88e5')
config.plugins.xDreamy.BackgroundColor = ConfigSelection(default='#00000000')
config.plugins.xDreamy.transparency = ConfigSelection(default="00", choices=[
    ("00", _("Opaque")), ("05", _("5%")), ("10", _("10%")), ("15", _("15%")),
    ("20", _("20%")), ("25", _("25%")), ("30", _("30%")), ("35", _("35%")),
    ("40", _("40%")), ("45", _("45%")), ("50", _("50%")), ("55", _("55%")),
    ("60", _("60%")), ("65", _("65%")), ("70", _("70%")), ("75", _("75%")),
    ("80", _("80%")), ("85", _("85%")), ("90", _("90%")), ("95", _("95%")), ("99", _("Transparent"))])

# Fonts
config.plugins.xDreamy.FontStyle = ConfigSelection(default='default', choices=[('default', _('Default')), ('basic', _('Custom'))])
config.plugins.xDreamy.FontName = ConfigSelection(default='Verdana.ttf')
config.plugins.xDreamy.FontScale = ConfigSelection(default="100", choices=[
    ('100', _('Default')), ('105', _('5%')), ('110', _('10%')), ('115', _('15%')),
    ('120', _('20%')), ('125', _('25%')), ('130', _('30%')), ('135', _('35%')),
    ('95', _('-5%')), ('90', _('-10%')), ('85', _('-15%')), ('80', _('-20%')), ('75', _('-25%'))])

# Screen Layouts
config.plugins.xDreamy.InfobarStyle = ConfigSelection(default='InfoBar-1P', choices=[
    ('InfoBar-1P', _('Default')), ('InfoBar-2P', _('InfoBar-2P')), ('InfoBar-NP', _('InfoBar1-NP')),
    ('InfoBar2-NP', _('InfoBar2-NP')), ('InfoBar2-1P', _('InfoBar2-1P')), ('InfoBar2-2P', _('InfoBar2-2P')),
    ('InfoBar2-1PW', _('InfoBar2-1PW')), ('InfoBar-HMF', _('Custom - InfoBar'))])

config.plugins.xDreamy.InfobarH = ConfigSelection(default='No Header', choices=[
    ('No Header', _('Default- No Header')), ('InfoBar H0', _('H00- Clock & Date')),
    ('InfoBar H1', _('H01- EMU/Network/Card')), ('InfoBar H2', _('H02- Three Days Weather')),
    ('InfoBar H3', _('H03- One RAW Header')), ('InfoBar H4', _('H04- Clock, Date & Weather'))])

config.plugins.xDreamy.InfobarM = ConfigSelection(default='No Middle', choices=[
    ('No Middle', _('Default- No Middle')), ('InfoBar M0', _('M00- ')), ('InfoBar M1', _('M01- ')),
    ('InfoBar M2', _('M02- ')), ('InfoBar M3', _('M03- ')), ('InfoBar M4', _('M04- '))])

config.plugins.xDreamy.InfobarF = ConfigSelection(default='No Footer', choices=[
    ('No Footer', _('Default- No Footer')), ('InfoBar F0', _('F00')), ('InfoBar F1', _('F01')),
    ('InfoBar F2', _('F02')), ('InfoBar F3', _('F03')), ('InfoBar F4', _('F04')),
    ('InfoBar F5', _('F05')), ('InfoBar F6', _('F06'))])

config.plugins.xDreamy.SecondInfobar = ConfigSelection(default='SecondInfobar-2P', choices=[
    ('SecondInfobar-2P', _('Default')), ('SecondInfobar-NP', _('SecondInfobar-NP')),
    ('SecondInfobar-2PN', _('SecondInfobar-2PN')), ('SecondInfobar-2PN2', _('SecondInfobar-2PN2')),
    ('SecondInfobar-HF', _('Custom - SecondInfobar'))])

config.plugins.xDreamy.SecondInfobarH = ConfigSelection(default='SecondInfobarH01', choices=[
    ('SecondInfobarH01', _('Default')), ('SecondInfobarH02', _('S.InfobarH S1-2E-2P')),
    ('SecondInfobarH03', _('S.InfobarH S2-2E-NP')), ('SecondInfobarH04', _('S.InfobarH S2-2E-2P')),
    ('SecondInfobarH05', _('S.InfobarH H-2E-NP')), ('SecondInfobarH06', _('S.InfobarH H-2E-2P')),
    ('SecondInfobarH07', _('S.InfobarH V-2E-NP')), ('SecondInfobarH08', _('S.InfobarH V-2E-2P')),
    ('SecondInfobarH09', _('S.InfobarH V-2E-2BD'))])

config.plugins.xDreamy.SecondInfobarF = ConfigSelection(default='SecondInfobarF', choices=[
    ('SecondInfobarF', _('Default')), ('SecondInfobarF1', _('S.InfobarF F1')), ('SecondInfobarF2', _('S.InfobarF F2'))])

config.plugins.xDreamy.ChannSelector = ConfigSelection(default='C01-MTV-1P', choices=[
    ('C01-MTV-1P', _('Default')), ('C02-MTV-2P', _('C02-MTV-2P')), ('C03-MTV-7P', _('C03-MTV-7P')),
    ('C04-MTV-13P', _('C04-MTV-13P')), ('C05-MTV-NP', _('C05-MTV-NP')), ('C06-MTV-NP', _('C06-MTV-NP')),
    ('C07-MTV-1P', _('C07-MTV-1P')), ('C08-NP', _('C08-NP')), ('C09-NP', _('C09-NP')),
    ('C10-1P', _('C10-1P')), ('C11-2P', _('C11-2P')), ('C12-2P-NBG', _('C12-2P-NBG')),
    ('C13-7P', _('C13-7P')), ('C14-13P', _('C14-13P')), ('C15-14P', _('C15-14P'))])

config.plugins.xDreamy.ChannSelectorGrid = ConfigSelection(default='G01-MTV-NP', choices=[
    ('G01-MTV-NP', _('G01-MTV-NP')), ('G02-1Raw-1P', _('G02-1Raw-1P')), ('G03-1Raw-2P', _('G03-1Raw-2P')),
    ('G04-1Raw-1P-Top', _('G04-1Raw-1P-Top')), ('G05-Color-2P', _('G05-Color-2P')),
    ('G06-Background-NP', _('G06-Background-NP')), ('G07-Transparent-NP', _('G07-Transparent-NP')),
    ('G08-Color-2P', _('G08-Color-2P')), ('G09-Backdrop', _('G09-Backdrop'))])

config.plugins.xDreamy.EventView = ConfigSelection(default='EventView', choices=[
    ('EventView', _('Default')), ('EventView1', _('EventV-01 BD')), ('EventView2', _('EventV-02 Big')),
    ('EventView3', _('EventV-03 7P')), ('EventView4', _('EventV-04 11P-FSB')), ('EventView5', _('EventV-05 1P-FSB'))])

config.plugins.xDreamy.PluginBrowser = ConfigSelection(default='PluginBrowser', choices=[
    ('PluginBrowser', _('Default')), ('PluginBrowser1', _('PluginBrowser-01')), ('PluginBrowser2', _('PluginBrowser-02')),
    ('PluginBrowser3', _('PluginBrowser-03')), ('PluginBrowser4', _('PluginBrowser-04')), ('PluginBrowser4GHT', _('PluginBrowser-04 GHT')),
    ('PluginBrowser4GHM', _('PluginBrowser-04 GHM')), ('PluginBrowser4GHB', _('PluginBrowser-04 GHB')),
    ('PluginBrowser5GVL', _('PluginBrowser-05 GVL')), ('PluginBrowser5GVR', _('PluginBrowser-05 GVR'))])

config.plugins.xDreamy.VolumeBar = ConfigSelection(default='volume1', choices=[
    ('volume1', _('Default')), ('volume2', _('volume2')), ('volume3', _('volume3')),
    ('volume4', _('volume4')), ('volume5', _('volume5'))])

config.plugins.xDreamy.VirtualKeyboard = ConfigSelection(default='VirtualKeyBoard', choices=[
    ('VirtualKeyBoard', _('Default')), ('VirtualKeyBoard1', _('Black - Keyboard')), ('VirtualKeyBoard2', _('Color - Keyboard'))])

config.plugins.xDreamy.NewVirtualKeyboard = ConfigSelection(default='NewVirtualKeyBoard0', choices=[
    ('NewVirtualKeyBoard0', _('Default')), ('NewVirtualKeyBoard1', _('NV.KeyBoard1')),
    ('NewVirtualKeyBoard2', _('NV.KeyBoard2')), ('NewVirtualKeyBoard3', _('NV.KeyBoard3')),
    ('NewVirtualKeyBoard4', _('NV.KeyBoard4'))])

config.plugins.xDreamy.HistoryZapSelector = ConfigSelection(default='HistoryZapSelector0', choices=[
    ('HistoryZapSelector0', _('Default')), ('HistoryZapSelector1', _('HistoryZap1-NP')),
    ('HistoryZapSelector2', _('HistoryZap2-NP')), ('HistoryZapSelector3', _('HistoryZap3-NP'))])

config.plugins.xDreamy.EPGMultiSelection = ConfigSelection(default='EPGMultiSelection', choices=[
    ('EPGMultiSelection', _('Default')), ('EPGMultiSelection1', _('EPGMultiSelection1'))])

config.plugins.xDreamy.E2Player = ConfigSelection(default='E2Player', choices=[
    ('E2Player', _('Default')), ('E2Player1', _('E2Player1')), ('E2Player2', _('E2Player2'))])

config.plugins.xDreamy.EnhancedMovieCenter = ConfigSelection(default='EnhancedMovieCenter', choices=[
    ('EnhancedMovieCenter', _('Default')), ('EnhancedMovieCenter1', _('E.MovieCenter1')),
    ('EnhancedMovieCenter2', _('E.MovieCenter2')), ('EnhancedMovieCenter3', _('E.MovieCenter3'))])

config.plugins.xDreamy.ChannelListBackground = ConfigSelection(default='Black', choices=[
    ('Black', _('Default- Black')), ('Color', _('Skin Color')), ('Background', _('Background')),
    ('Background1', _('Background1')), ('Background2', _('Background2')), ('Background3', _('Background3')),
    ('Background4', _('Background4')), ('Background5', _('Background5')), ('Background6', _('Background6')),
    ('Background7', _('Background7')), ('Background8', _('Background8')), ('Background9', _('Background9')),
    ('Background10', _('Background10')), ('Background11', _('Background11')), ('Background12', _('Background12')),
    ('Background13', _('Background13')), ('Background14', _('Background14')), ('Background15', _('Background15')),
    ('Background16', _('Background16'))])

config.plugins.xDreamy.TurnOff = ConfigSelection(default='Background', choices=[
    ('Background', _('Background')), ('Background1', _('Background1')), ('Background2', _('Background2')),
    ('Background3', _('Background3')), ('Background4', _('Background4')), ('Background5', _('Background5')),
    ('Background6', _('Background6')), ('Background7', _('Background7')), ('Background8', _('Background8')),
    ('Background9', _('Background9')), ('Background10', _('Background10')), ('Background11', _('Background11')),
    ('Background12', _('Background12')), ('Background13', _('Background13')), ('Background14', _('Background14')),
    ('Background15', _('Background15')), ('Background16', _('Background16'))])

config.plugins.xDreamy.BitrateSource = ConfigSelection(default='BitrateRenderer', choices=[
    ('BitrateRenderer', _('Default-BitrateRenderer')), ('BitratePlugin', _('Bitrate Plugin'))])

config.plugins.xDreamy.SubtitlesClock = ConfigSelection(default='SC', choices=[
    ('SC', _('Default- No Clock')), ('SC1', _('DSC-Bottom Right')), ('SC2', _('DSC-Bottom Left')),
    ('SC3', _('DSC-Top Right')), ('SC4', _('DSC-Top Left'))])

config.plugins.xDreamy.RatingStars = ConfigSelection(default='NRS', choices=[
    ('NRS', _('Default-Disable')), ('RS', _('Enable'))])

config.plugins.xDreamy.CamName = ConfigSelection(default='Access', choices=[
    ('Access', _('Default')), ('CaidInfo2', _('CaidInfo')), ('CamdRAED', _('CamdRAED')),
    ('CryptoInfo', _('CryptoInfo')), ('EcmInfo', _('EcmInfo'))])

config.plugins.xDreamy.channelnamecolor = ConfigSelection(default="CLC", choices=[
    ("CLC", _("White - White")), ("CLC1", _("White - Color")),
    ("CLC2", _("Color - White")), ("CLC3", _("Color - Color"))])

config.plugins.xDreamy.menufontcolor = ConfigSelection(default='MC', choices=[
    ('MC', _('Default- White')), ('MC1', _('Skin Color'))])

config.plugins.xDreamy.crypt = ConfigSelection(default='Cryptoname', choices=[
    ('Cryptoname', _('Default-Name')), ('Cryptobar', _('Crypt-Bar'))])

config.plugins.xDreamy.posters = ConfigSelection(default='iPosterX', choices=[('iPosterX', _('Default'))])
config.plugins.xDreamy.posterRemovalInterval = ConfigSelection(default="31536000", choices=[
    ("86400", _("1 Day")), ("432000", _("5 Days")), ("864000", _("10 Days")),
    ("1296000", _("15 Days")), ("2592000", _("30 Days")), ("5184000", _("2 Months")),
    ("10368000", _("4 Months")), ("15552000", _("6 Months")), ("31536000", _("12 Months")),
    ("63072000", _("2 Years"))])


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================
def applyDateFormat():
    skinFiles = [
        "/usr/share/enigma2/xDreamy/sample/head-head.xml",
        "/usr/share/enigma2/xDreamy/skin.xml"
    ]
    new_format = config.plugins.xDreamy.dateFormat.value
    for skinFile in skinFiles:
        if not os.path.exists(skinFile):
            continue
        try:
            with open(skinFile, "r") as file:
                skin_data = file.read()
            start_tag = '<convert type="ClockToText">Format '
            end_tag = '</convert>'
            start_index = skin_data.find(start_tag)
            end_index = skin_data.find(end_tag, start_index) if start_index != -1 else -1
            if start_index != -1 and end_index != -1:
                old_convert_tag = skin_data[start_index:end_index + len(end_tag)]
                new_convert_tag = f'{start_tag}{new_format}{end_tag}'
                updated_skin_data = skin_data.replace(old_convert_tag, new_convert_tag)
                if updated_skin_data != skin_data:
                    with open(skinFile, "w") as file:
                        file.write(updated_skin_data)
        except Exception:
            pass


config.plugins.xDreamy.dateFormat.addNotifier(lambda _: applyDateFormat())


def apply_template(template_name):
    if template_name in TEMPLATES:
        ltbluette_value, bluette_value, header_value = TEMPLATES[template_name]
        update_colors_in_file(
            '/usr/share/enigma2/xDreamy/sample/C-default-color.xml',
            ltbluette_value, None, bluette_value, header_value
        )


def update_individual_colors(ltbluette_value=None, white_value=None, bluette_value=None, header_value=None):
    update_colors_in_file(
        '/usr/share/enigma2/xDreamy/sample/C-color23_Custom.xml',
        ltbluette_value, white_value, bluette_value, header_value
    )


def update_colors_in_file(file_path, ltbluette_value=None, white_value=None, bluette_value=None, header_value=None):
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
        transparency_value = config.plugins.xDreamy.transparency.value
        with open(file_path, 'w') as file:
            for line in lines:
                if '<color name="ltbluette"' in line and ltbluette_value is not None:
                    line = f'<color name="ltbluette" value="{ltbluette_value}"/>\n'
                elif '<color name="white"' in line and white_value is not None:
                    line = f'<color name="white" value="{white_value}"/>\n'
                elif '<color name="bluette"' in line and bluette_value is not None:
                    line = f'<color name="bluette" value="{bluette_value}"/>\n'
                elif '<color name="header"' in line and header_value is not None:
                    if header_value.startswith("#") and len(header_value) == 9:
                        new_color = f"#{transparency_value}{header_value[3:]}"
                        line = f'<color name="header" value="{new_color}"/>\n'
                file.write(line)
    except Exception:
        pass


def update_font_settings(font_name=None, font_scale=None):
    font_file_path = '/usr/share/enigma2/xDreamy/sample/font-basic.xml'
    try:
        with open(font_file_path, 'r') as file:
            lines = file.readlines()
        with open(font_file_path, 'w') as file:
            for line in lines:
                if '<font name="Regular"' in line:
                    line = f'<font name="Regular" filename="/usr/share/enigma2/xDreamy/fonts/{font_name}" scale="{font_scale}" />\n'
                file.write(line)
    except Exception:
        pass


def update_renderer_status(enable):
    files = [
        '/usr/lib/enigma2/python/Components/Renderer/iPosterX.py',
        '/usr/lib/enigma2/python/Components/Renderer/iPosterXDownloadThread.py',
        '/usr/lib/enigma2/python/Components/Renderer/iBackdropX.py',
        '/usr/lib/enigma2/python/Components/Renderer/iBackdropXDownloadThread.py',
    ]
    target_classes = ['iPosterX', 'iPosterXDownloadThread', 'iBackdropX', 'iBackdropXDownloadThread']
    for file_path in files:
        if not os.path.exists(file_path):
            continue
        try:
            with open(file_path, 'r') as file:
                content = file.read()
            new_content = content
            for class_name in target_classes:
                if enable:
                    off_class = 'OFF_' + class_name[1:]
                    new_content = new_content.replace(f'class {off_class}', f'class {class_name}')
                else:
                    off_class = 'OFF_' + class_name[1:]
                    new_content = new_content.replace(f'class {class_name}', f'class {off_class}')
            if new_content != content:
                with open(file_path, 'w') as file:
                    file.write(new_content)
        except Exception:
            pass


config.plugins.xDreamy.enablePosterX.addNotifier(lambda config: update_renderer_status(config.value))


def update_removal_time(removal_time):
    try:
        posterx_file_path = '/usr/lib/enigma2/python/Components/Renderer/iPosterX.py'
        with open(posterx_file_path, 'r') as file:
            lines = file.readlines()
        with open(posterx_file_path, 'w') as file:
            for line in lines:
                if 'elif diff_tm > 31536000:' in line:
                    indentation = line[:line.find('elif')]
                    line = f"{indentation}elif diff_tm > {removal_time}:\n"
                file.write(line)
    except Exception:
        pass


config.plugins.xDreamy.posterRemovalInterval.addNotifier(lambda config: update_removal_time(config.value))


def check_plugin_installed(plugin_name):
    plugin_paths = {
        "AJPanel": resolveFilename(SCOPE_PLUGINS, "Extensions/AJPan"),
        "LinuxsatPanel": resolveFilename(SCOPE_PLUGINS, "Extensions/LinuxsatPanel"),
        "CiefpPlugins": resolveFilename(SCOPE_PLUGINS, "Extensions/CiefpPlugins"),
        "SmartPanel": resolveFilename(SCOPE_PLUGINS, "Extensions/SmartAddonspanel"),
        "MagicPanel": resolveFilename(SCOPE_PLUGINS, "Extensions/MagicPanel"),
        "KeyAdder": resolveFilename(SCOPE_PLUGINS, "Extensions/KeyAdder"),
        "XKlass": resolveFilename(SCOPE_PLUGINS, "Extensions/XKlass"),
        "YouTube": resolveFilename(SCOPE_PLUGINS, "Extensions/YouTube"),
        "E2iPlayer": resolveFilename(SCOPE_PLUGINS, "Extensions/IPTVPlayer"),
        "Transmission": resolveFilename(SCOPE_PLUGINS, "Extensions/Transmission"),
        "MultiStalkerPro": resolveFilename(SCOPE_PLUGINS, "Extensions/MultiStalkerPro"),
        "SubsSupport": resolveFilename(SCOPE_PLUGINS, "Extensions/SubsSupport"),
        "HistoryZapSelector": resolveFilename(SCOPE_PLUGINS, "Extensions/HistoryZapSelector"),
        "NewVirtualKeyboard": resolveFilename(SCOPE_PLUGINS, "SystemPlugins/NewVirtualKeyBoard"),
        "RaedQuickSignal": resolveFilename(SCOPE_PLUGINS, "Extensions/RaedQuickSignal"),
    }
    return os.path.isdir(plugin_paths.get(plugin_name, ""))


def update_plugin_install_status():
    plugin_configs = {
        "AJPanel": config.plugins.xDreamy.install_ajpanel,
        "LinuxsatPanel": config.plugins.xDreamy.install_linuxsatpanel,
        "CiefpPlugins": config.plugins.xDreamy.install_CiefpPlugins,
        "SmartPanel": config.plugins.xDreamy.install_smartpanel,
        "MagicPanel": config.plugins.xDreamy.install_magicpanel,
        "KeyAdder": config.plugins.xDreamy.install_keyadder,
        "XKlass": config.plugins.xDreamy.install_xklass,
        "YouTube": config.plugins.xDreamy.install_youtube,
        "E2iPlayer": config.plugins.xDreamy.install_e2iplayer,
        "Transmission": config.plugins.xDreamy.install_transmission,
        "MultiStalkerPro": config.plugins.xDreamy.install_multistalkerpro,
        "SubsSupport": config.plugins.xDreamy.install_subssupport,
        "HistoryZapSelector": config.plugins.xDreamy.install_historyzapselector,
        "NewVirtualKeyboard": config.plugins.xDreamy.install_newvirtualkeyboard,
        "RaedQuickSignal": config.plugins.xDreamy.install_raedquicksignal,
    }
    for plugin_name, config_entry in plugin_configs.items():
        if check_plugin_installed(plugin_name):
            config_entry.setValue(True)


# ============================================================================
# AUTOSTART
# ============================================================================
def autostart(reason, **kwargs):
    if reason == 0:
        if cur_skin == 'xDreamy' and config.plugins.xDreamy.bootlogos.value:
            if not fileExists(mvi + 'bootlogoBack.mvi'):
                shutil.copy(mvi + 'bootlogo.mvi', mvi + 'bootlogoBack.mvi')
            for f in ['bootlogo.mvi', 'backdrop.mvi', 'bootlogo_wait.mvi']:
                if fileExists(logopath + f):
                    os.remove(logopath + f)
            if fileExists(bootlog + 'bootlogo1.mvi') and os.listdir(bootlog):
                newscreen = random.choice(os.listdir(bootlog))
                shutil.copy(bootlog + newscreen, mvi + 'bootlogo.mvi')
                shutil.copy(bootlog + newscreen, mvi + 'backdrop.mvi')
        elif fileExists(mvi + 'bootlogoBack.mvi'):
            shutil.copy(mvi + 'bootlogoBack.mvi', mvi + 'bootlogo.mvi')
            os.remove(mvi + 'bootlogoBack.mvi')


# ============================================================================
# MAIN SETUP SCREEN
# ============================================================================
class xDreamySetup(ConfigListScreen, Screen):
    skin = '''
    <screen name="xDreamySetup" position="center,center" size="1000,640" title="XDREAMY skin customization">
        <eLabel font="Regular; 24" foregroundColor="#00ff4A3C" halign="center" position="20,598" size="120,26" text="Cancel"/>
        <eLabel font="Regular; 24" foregroundColor="#0056C856" halign="center" position="220,598" size="120,26" text="Save"/>
        <widget name="Preview" position="997,690" size="498,280" zPosition="1"/>
        <widget name="config" font="Regular; 24" itemHeight="40" position="5,5" scrollbarMode="showOnDemand" size="990,550"/>
        <widget name="helpText" font="Regular; 22" position="5,560" size="990,30" foregroundColor="white" backgroundColor="black" transparent="1" zPosition="2" halign="left" valign="center"/>
    </screen>
    '''

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.skinFile = '/usr/share/enigma2/xDreamy/skin.xml'
        self.previewFiles = '/usr/share/enigma2/xDreamy/sample/'
        self.setup_title = f"XDREAMY SKIN v{version}"

        self['Preview'] = Pixmap()
        self['helpText'] = Label('')
        self['yellow'] = Label(_('Check for Update'))
        self['blue'] = Label(_('Version'))

        ConfigListScreen.__init__(self, [], session=self.session, on_change=self.changedEntry)

        self.setupActionMaps()
        self.onLayoutFinish.append(self.createSetup)
        self.onLayoutFinish.append(self.ShowPicture)
        self.onLayoutFinish.append(self.__layoutFinished)

        self.timerx = eTimer()
        self.timerx.callback.append(self.checkforUpdate)
        self.timerx.start(5000, True)

        update_plugin_install_status()

    def setupActionMaps(self):
        self["actions"] = ActionMap(["SetupActions"], {
            'ok': self.keyOK,
            "cancel": self.keyCancel,
            "save": self.keySave,
        }, -2)
        self['actions'] = ActionMap(['OkCancelActions', 'DirectionActions', 'InputActions',
                                      'VirtualKeyboardActions', 'MenuActions', 'NumberActions',
                                      'InfoActions', 'ColorActions'], {
            'showVirtualKeyboard': self.KeyText,
            'left': self.keyLeft,
            'right': self.keyRight,
            'down': self.keyDown,
            'up': self.keyUp,
            'red': self.keyExit,
            'green': self.keySave,
            'yellow': self.checkforUpdate,
            'blue': self.info,
            'cancel': self.keyExit,
            'ok': self.keyRun
        }, -1)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def updateHelpText(self):
        current = self["config"].getCurrent()
        if current and len(current) > 2:
            self['helpText'].setText(current[2])
        else:
            self['helpText'].setText('')

    def changedEntry(self):
        self.updateHelpText()
        self.ShowPicture()

    def ShowPicture(self):
        if not self["Preview"].instance:
            return
        size = self['Preview'].instance.size()
        if size.isNull():
            size.setWidth(498)
            size.setHeight(280)

        default_image = "/usr/share/enigma2/xDreamy/screens/default.png"
        current = self["config"].getCurrent()
        if current and len(current) > 1:
            item_name = str(current[1].value).lower().replace(" ", "").replace("-", "")
            image_path = f"/usr/share/enigma2/xDreamy/screens/{item_name}.png"
            if os.path.exists(image_path):
                pixmapx = image_path
            else:
                pixmapx = default_image
        else:
            pixmapx = default_image

        if os.path.exists(pixmapx):
            png = loadPic(pixmapx, size.width(), size.height(), 0, 0, 0, 1)
            self["Preview"].instance.setPixmap(png)

    def info(self):
        message = _(
            "Experience Enigma2 skin like never before with XDREAMY\n\n"
            f"Version: {version}\n"
            "Mahmoud Hussein"
        )
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=10)

    def keyRun(self):
        current = self["config"].getCurrent()
        if not current or len(current) < 2:
            return
        sel = current[1]

        if sel == config.plugins.xDreamy.png:
            self.removPng()
        elif isinstance(sel, ConfigSelection):
            self.openSelectionPopup(current)
        elif sel in [getattr(config.plugins.xDreamy, f"install_{p}") for p in plugin_names]:
            self.handlePluginInstallation(sel)

    def openSelectionPopup(self, current):
        sel = current[1]
        if hasattr(sel, "choices"):
            options = [(str(opt), opt) for opt in sel.choices]
            self.session.openWithCallback(
                lambda choice: self.selectionMade(choice, sel),
                ChoiceBox, title=_("Select option for: ") + current[0], list=options
            )

    def selectionMade(self, choice, configItem):
        if choice:
            configItem.value = choice[1]
            self.createSetup()

    def handlePluginInstallation(self, sel):
        plugin_map = {}
        for pid in plugin_names:
            plugin_map[getattr(config.plugins.xDreamy, f"install_{pid}")] = pid
        plugin_id = plugin_map.get(sel)
        if not plugin_id:
            return
        plugin_name = plugin_id.capitalize()
        is_installed = sel.value

        if is_installed:
            choices = [(_("Open"), "open"), (_("Remove"), "remove"), (_("Cancel"), "cancel")]
            self.session.openWithCallback(
                lambda r: self.runPluginAction(r, plugin_id, plugin_name),
                ChoiceBox, title=_("%s is installed. What to do?" % plugin_name), list=choices
            )
        else:
            self.session.openWithCallback(
                lambda r: self.runPluginAction(r, plugin_id, plugin_name),
                MessageBox, _("%s is not installed. Install now?" % plugin_name), MessageBox.TYPE_YESNO
            )

    def runPluginAction(self, result, plugin_id, plugin_name):
        if not result or result == "cancel":
            return
        if result == "open":
            self.session.open(MessageBox, _("Opening %s...") % plugin_name, MessageBox.TYPE_INFO, timeout=2)
        elif result == "remove" or result is True:
            cmd = f"opkg remove --autoremove enigma2-plugin-extensions-{plugin_id.lower()}"
            self.session.open(Console, _('Removing %s') % plugin_name, [cmd])

    def removPng(self):
        self.session.openWithCallback(
            self.removPngCallback,
            MessageBox,
            _("This will remove all cached poster images.\nContinue?"),
            MessageBox.TYPE_YESNO
        )

    def removPngCallback(self, result):
        if result:
            removePng()
            self.session.open(MessageBox, _("Image cache cleared!"), MessageBox.TYPE_INFO, timeout=3)

    def KeyText(self):
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        sel = self["config"].getCurrent()
        if sel and len(sel) > 1:
            self.session.openWithCallback(self.VirtualKeyBoardCallback, VirtualKeyBoard, title=sel[0], text=sel[1].value)

    def VirtualKeyBoardCallback(self, callback=None):
        if callback is not None and len(callback):
            self["config"].getCurrent()[1].value = callback
            self["config"].invalidate(self["config"].getCurrent())

    def createSetup(self):
        list = []

        # SKIN GENERAL SETUP
        list.append(getConfigListEntry('\\c00289496' + _('SKIN GENERAL SETUP') + '_' * 58))
        list.append(getConfigListEntry(_('Skin Style:'), config.plugins.xDreamy.skinTemplate))
        list.append(getConfigListEntry(_('Keys Style:'), config.plugins.xDreamy.KeysStyle))
        list.append(getConfigListEntry(_('Font Style:'), config.plugins.xDreamy.FontStyle))
        if config.plugins.xDreamy.FontStyle.value == 'basic':
            list.append(getConfigListEntry(_('      - Font Type:'), config.plugins.xDreamy.FontName))
            list.append(getConfigListEntry(_('      - Font Size:'), config.plugins.xDreamy.FontScale))
        list.append(getConfigListEntry(_("Date Format:"), config.plugins.xDreamy.dateFormat))
        list.append(getConfigListEntry(_("Clock Format:"), config.plugins.xDreamy.clockFormat))
        list.append(getConfigListEntry(_('Show in Extensions:'), config.plugins.xDreamy.ShowInExtensions))

        list.append(getConfigListEntry(' '))

        # SKIN COLORS
        list.append(getConfigListEntry('\\c00289496' + _('SKIN COLORS') + '_' * 72))
        list.append(getConfigListEntry(_('Skin Color Scheme:'), config.plugins.xDreamy.colorSelector))
        if config.plugins.xDreamy.colorSelector.value == 'default-color':
            list.append(getConfigListEntry(_('      - Color Templates:'), config.plugins.xDreamy.BasicColorTemplates))
            list.append(getConfigListEntry(_('      - Background Transparency:'), config.plugins.xDreamy.transparency))
        if config.plugins.xDreamy.colorSelector.value == 'color23_Custom':
            list.append(getConfigListEntry(_('      - Titles Color:'), config.plugins.xDreamy.BasicColor))
            list.append(getConfigListEntry(_('      - Text Color:'), config.plugins.xDreamy.WhiteColor))
            list.append(getConfigListEntry(_('      - Selection Color:'), config.plugins.xDreamy.SelectionColor))
            list.append(getConfigListEntry(_('      - Background Color:'), config.plugins.xDreamy.BackgroundColor))
            list.append(getConfigListEntry(_('      - Background Transparency:'), config.plugins.xDreamy.transparency))
        list.append(getConfigListEntry(_('Menu Font Color:'), config.plugins.xDreamy.menufontcolor))
        list.append(getConfigListEntry(_('Channel Names Color:'), config.plugins.xDreamy.channelnamecolor))

        list.append(getConfigListEntry(' '))

        # SCREEN LAYOUTS
        list.append(getConfigListEntry('\\c00289496' + _('SCREEN LAYOUTS') + '_' * 68))
        list.append(getConfigListEntry(_('InfoBar Style:'), config.plugins.xDreamy.InfobarStyle))
        if config.plugins.xDreamy.InfobarStyle.value == 'InfoBar-HMF':
            list.append(getConfigListEntry(_('      - Infobar Header'), config.plugins.xDreamy.InfobarH))
            list.append(getConfigListEntry(_('      - Infobar Middle'), config.plugins.xDreamy.InfobarM))
            list.append(getConfigListEntry(_('      - Infobar Footer'), config.plugins.xDreamy.InfobarF))
        list.append(getConfigListEntry(_('SecondInfoBar Style:'), config.plugins.xDreamy.SecondInfobar))
        if config.plugins.xDreamy.SecondInfobar.value == 'SecondInfobar-HF':
            list.append(getConfigListEntry(_('      - SecondInfoBar Header:'), config.plugins.xDreamy.SecondInfobarH))
            list.append(getConfigListEntry(_('      - SecondInfoBar Footer:'), config.plugins.xDreamy.SecondInfobarF))
        list.append(getConfigListEntry(_('Channels List Style:'), config.plugins.xDreamy.ChannSelector))
        list.append(getConfigListEntry(_('Channels List Grid:'), config.plugins.xDreamy.ChannSelectorGrid))
        list.append(getConfigListEntry(_('EventView Style:'), config.plugins.xDreamy.EventView))
        list.append(getConfigListEntry(_('Volume Bar Style:'), config.plugins.xDreamy.VolumeBar))
        list.append(getConfigListEntry(_('Plugin Browser Style:'), config.plugins.xDreamy.PluginBrowser))
        list.append(getConfigListEntry(_('History Zap Selector Style:'), config.plugins.xDreamy.HistoryZapSelector))

        list.append(getConfigListEntry(' '))

        # PLUGIN SCREENS
        list.append(getConfigListEntry('\\c00289496' + _('PLUGIN SCREENS') + '_' * 68))
        list.append(getConfigListEntry(_('E2Player Style:'), config.plugins.xDreamy.E2Player))
        list.append(getConfigListEntry(_('New Virtual Keyboard Style:'), config.plugins.xDreamy.NewVirtualKeyboard))
        list.append(getConfigListEntry(_('Enhanced Movie Center Style:'), config.plugins.xDreamy.EnhancedMovieCenter))

        list.append(getConfigListEntry(' '))

        # SYSTEM INTEGRATION
        list.append(getConfigListEntry('\\c00289496' + _('SYSTEM INTEGRATION') + '_' * 60))
        list.append(getConfigListEntry(_('ShutDown Background:'), config.plugins.xDreamy.TurnOff))
        list.append(getConfigListEntry(_('Channels List Background:'), config.plugins.xDreamy.ChannelListBackground))
        list.append(getConfigListEntry(_('Virtual Keyboard Style:'), config.plugins.xDreamy.VirtualKeyboard))
        list.append(getConfigListEntry(_('Bitrate Source:'), config.plugins.xDreamy.BitrateSource))
        list.append(getConfigListEntry(_('Rating & Stars:'), config.plugins.xDreamy.RatingStars))
        list.append(getConfigListEntry(_('Subtitles Clock:'), config.plugins.xDreamy.SubtitlesClock))
        list.append(getConfigListEntry(_('SoftCam Name:'), config.plugins.xDreamy.CamName))
        list.append(getConfigListEntry(_('Crypt Display:'), config.plugins.xDreamy.crypt))
        list.append(getConfigListEntry(_('Bootlogos Random:'), config.plugins.xDreamy.bootlogos))

        list.append(getConfigListEntry(' '))

        # POSTERS
        list.append(getConfigListEntry('\\c00289496' + _('POSTER CONFIGURATION') + '_' * 60))
        list.append(getConfigListEntry(_('Poster Display:'), config.plugins.xDreamy.enablePosterX))
        if config.plugins.xDreamy.enablePosterX.value:
            list.append(getConfigListEntry(_('Poster Removal Interval:'), config.plugins.xDreamy.posterRemovalInterval))
            list.append(getConfigListEntry(_('Remove all Posters:'), config.plugins.xDreamy.png))

        list.append(getConfigListEntry(' '))

        # PLUGIN INSTALLATION
        list.append(getConfigListEntry('\\c00289496' + _('PLUGIN INSTALLATION') + '_' * 60))
        list.append(getConfigListEntry('\\c0056c856' + _('Management Panels:')))
        for pid, name in [('ajpanel', 'AJ Panel'), ('linuxsatpanel', 'LinuxSat Panel'),
                          ('smartpanel', 'Smart Panel'), ('magicpanel', 'Magic Panel')]:
            cfg = getattr(config.plugins.xDreamy, f"install_{pid}")
            list.append(getConfigListEntry(f'      - {name}:', cfg))

        list.append(getConfigListEntry('\\c0056c856' + _('Media Players:')))
        for pid, name in [('xklass', 'XKlass'), ('youtube', 'YouTube'), ('e2iplayer', 'E2iPlayer'),
                          ('transmission', 'Transmission'), ('multistalkerpro', 'MultiStalkerPro')]:
            cfg = getattr(config.plugins.xDreamy, f"install_{pid}")
            list.append(getConfigListEntry(f'      - {name}:', cfg))

        list.append(getConfigListEntry('\\c0056c856' + _('Utility Plugins:')))
        for pid, name in [('keyadder', 'Key Adder'), ('subssupport', 'SubsSupport'),
                          ('historyzapselector', 'HistoryZapSelector'), ('newvirtualkeyboard', 'NewVirtualKeyboard'),
                          ('raedquicksignal', 'RaedQuickSignal')]:
            cfg = getattr(config.plugins.xDreamy, f"install_{pid}")
            list.append(getConfigListEntry(f'      - {name}:', cfg))

        self["config"].setList(list)

    def keySave(self):
        try:
            if config.plugins.xDreamy.colorSelector.value == "default-color":
                apply_template(config.plugins.xDreamy.BasicColorTemplates.value)
            else:
                update_individual_colors(
                    ltbluette_value=config.plugins.xDreamy.BasicColor.value,
                    white_value=config.plugins.xDreamy.WhiteColor.value,
                    bluette_value=config.plugins.xDreamy.SelectionColor.value,
                    header_value=config.plugins.xDreamy.BackgroundColor.value
                )

            if config.plugins.xDreamy.FontStyle.value == 'basic':
                update_font_settings(
                    config.plugins.xDreamy.FontName.value,
                    config.plugins.xDreamy.FontScale.value
                )

            applyDateFormat()

            for x in self["config"].list:
                if len(x) > 1:
                    x[1].save()
            configfile.save()

            self.session.openWithCallback(
                self.restartGUI,
                MessageBox,
                _('GUI needs a restart to apply changes.\nRestart now?'),
                MessageBox.TYPE_YESNO
            )
        except Exception as e:
            self.session.open(MessageBox, _('Error saving settings! ') + str(e), MessageBox.TYPE_ERROR)

    def restartGUI(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    def checkforUpdate(self):
        try:
            destr = '/tmp/xDreamyv.txt'
            req = Request('https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/xDreamyv.txt')
            req.add_header('User-Agent', 'Mozilla/5.0')
            fp = urlopen(req)
            fp = fp.read().decode('utf-8')
            with open(destr, 'w') as f:
                f.write(fp)
            if os.path.exists(destr):
                with open(destr, 'r') as cc:
                    s1 = cc.readline()
                    if '#' in s1:
                        vers = s1.split('#')[0]
                        url = s1.split('#')[1]
                        version_server = vers.strip()
                        self.updateurl = url.strip()
                        if str(version_server) > str(version):
                            self.session.openWithCallback(
                                self.update,
                                MessageBox,
                                _('Update available!\nServer: {server}\nYour: {local}\nUpdate now?').format(
                                    server=version_server, local=version
                                ),
                                MessageBox.TYPE_YESNO
                            )
        except Exception:
            pass

    def update(self, answer):
        if answer:
            self.session.open(xDreamyUpdater, self.updateurl)

    def keyExit(self):
        self.close()

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.createSetup()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.createSetup()

    def keyDown(self):
        self['config'].instance.moveSelection(self['config'].instance.moveDown)
        self.createSetup()

    def keyUp(self):
        self['config'].instance.moveSelection(self['config'].instance.moveUp)
        self.createSetup()

    def keyOK(self):
        current = self["config"].getCurrent()
        if current and len(current) > 1:
            sel = current[1]
            if isinstance(sel, ConfigText):
                self.KeyText()
            elif isinstance(sel, ConfigSelection):
                self.openSelectionPopup(current)

    def keyCancel(self):
        self.close()


# ============================================================================
# UPDATER SCREEN
# ============================================================================
class xDreamyUpdater(Screen):
    skin = '''
    <screen name="xDreamyUpdater" position="center,center" size="840,260" flags="wfBorder" backgroundColor="background">
        <widget name="status" position="20,10" size="800,70" font="Regular; 40" valign="center" halign="left" noWrap="1"/>
        <widget source="progress" render="Progress" position="20,120" size="800,20" borderWidth="0" foregroundColor="white" backgroundColor="background"/>
        <widget source="progresstext" render="Label" position="209,164" font="Regular; 28" halign="center" size="400,70" foregroundColor="foreground" backgroundColor="background"/>
    </screen>
    '''

    def __init__(self, session, updateurl):
        Screen.__init__(self, session)
        self.session = session
        self.updateurl = updateurl
        self['status'] = Label()
        self['progress'] = Progress()
        self['progresstext'] = StaticText()
        self.last_recvbytes = 0
        self.startUpdate()

    def startUpdate(self):
        self['status'].setText(_('Downloading XDREAMY Skin...'))
        self.dlfile = '/tmp/xDreamy.ipk'
        self.download = downloadWithProgress(self.updateurl, self.dlfile)
        self.download.addProgress(self.downloadProgress)
        self.download.start().addCallback(self.downloadFinished).addErrback(self.downloadFailed)

    def downloadFinished(self, string=''):
        self['status'].setText(_('Installing updates...'))
        os.system('opkg install --force-reinstall --force-overwrite /tmp/xDreamy.ipk')
        os.system('rm -f /tmp/xDreamy.ipk')
        self.session.openWithCallback(self.restartGUI, MessageBox, _('Update complete! Restart GUI now?'), MessageBox.TYPE_YESNO)

    def downloadFailed(self, failure_instance=None, error_message=''):
        self['status'].setText(_('Error downloading files!'))

    def downloadProgress(self, recvbytes, totalbytes):
        self.last_recvbytes = recvbytes
        if totalbytes:
            self['progress'].value = int(100 * recvbytes / totalbytes)
            self['progresstext'].text = _('{recv} of {total} KB').format(recv=recvbytes // 1024, total=totalbytes // 1024)

    def restartGUI(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()


# ============================================================================
# PLUGIN DESCRIPTOR
# ============================================================================
def main(session, **kwargs):
    session.open(xDreamySetup)


def Plugins(**kwargs):
    pluginList = [
        PluginDescriptor(
            name=_("XDREAMY"),
            description=_('Customization tool for XDREAMY Skin'),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon='plugin.png',
            fnc=main
        ),
        PluginDescriptor(
            name=_("XDREAMY BOOT"),
            description=_("XDREAMY BOOT LOGO"),
            where=PluginDescriptor.WHERE_AUTOSTART,
            fnc=autostart
        )
    ]
    if config.plugins.xDreamy.ShowInExtensions.value:
        pluginList.append(
            PluginDescriptor(
                name=_("XDREAMY Skin Settings"),
                description=_("Customization tool for XDREAMY Skin"),
                where=PluginDescriptor.WHERE_EXTENSIONSMENU,
                fnc=main
            )
        )
    return pluginList