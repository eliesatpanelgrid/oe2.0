#!/bin/sh
LOGFILE="/tmp/xDreamy_depends.log"
echo "" > "$LOGFILE"

log() {
    echo "$(date '+%H:%M:%S') - $1" | tee -a "$LOGFILE"
}

log "🔧 Starting dependency installation..."

# 🌍 Internet check
log "🌐 Checking internet connection..."
ping -q -c 2 -W 2 8.8.8.8 >/dev/null 2>&1
if [ $? -ne 0 ]; then
    log "❌ No internet connection. Skipping dependencies."
    exit 0
else
    log "✅ Internet is Connected..."
fi

# 🔄 opkg update
log "📡 Updating package list..."
opkg update >> "$LOGFILE" 2>&1 || log "⚠️ opkg update failed. Continuing..."

# 🐍 Detect python version
if command -v python3 >/dev/null 2>&1; then
    PY="python3"
else
    PY="python"
fi

# 🔧 Install dependencies one by one
for dep in wget curl "$PY-requests" "$PY-pillow" "$PY-imaging" "$PY-image" "$PY-urllib3"
do
    if opkg list-installed | grep -q "$dep"; then
        log "✅ Already installed: $dep"
    else
        log "📦 Installing: $dep"
        opkg install --force-reinstall "$dep" >> "$LOGFILE" 2>&1 || log "⚠️ opkg failed for $dep"
    fi
done

# 🔍 Check core Python modules manually
for mod in requests PIL urllib3; do
    $PY -c "import $mod" 2>/dev/null
    if [ $? -ne 0 ]; then
        log "⚠️ Python module missing: $mod — attempting pip install..."
        if command -v "$PY-pip" >/dev/null 2>&1; then
            "$PY-pip" install "$mod" >> "$LOGFILE" 2>&1 || log "❌ pip failed for $mod"
        else
            log "➕ Installing pip..."
            opkg install "$PY-pip" >> "$LOGFILE" 2>&1 && \
            "$PY-pip" install "$mod" >> "$LOGFILE" 2>&1 || log "❌ pip install failed for $mod"
        fi
    else
        log "✅ Python module available: $mod"
    fi
done

log "✅ Dependency installation complete."
exit 0