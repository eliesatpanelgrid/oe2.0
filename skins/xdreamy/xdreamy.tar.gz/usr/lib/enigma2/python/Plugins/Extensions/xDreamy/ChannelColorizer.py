# -*- coding: utf-8 -*-
# ============================================================================
#  ChannelColorizer.py  –  v2.5  Fixed: Enigma2 Cache Update for Channel List
#  Fixes:
#   • Forced eListbox to drop cached names via setRoot() reload
#   • Stricter Hex regex matching to prevent tag parsing errors
#   • Python 2.7 / 3.x literal string backslash safety for .tv files
#   • Added active skin check (only runs when XDREAMY skin is active)
# ============================================================================

from __future__ import print_function
import os
import re
import json
import time
import threading
import hashlib
from enigma import eTimer, iServiceInformation, eDVBDB
from Components.config import config
from Screens.InfoBar import InfoBar
from ServiceReference import ServiceReference
import NavigationInstance

# ═══════════════════════════════════════════════════════════════════════════
# SECTION 1: CONFIGURATION & PATHS
# ═══════════════════════════════════════════════════════════════════════════

def get_json_path():
    try:
        from Components.Renderer import iConverlibr
        base = iConverlibr.get_server_channels_json_path()
        if base and os.path.isdir(os.path.dirname(base)):
            return base
    except (ImportError, AttributeError):
        pass

    for mount in ["/media/hdd", "/media/usb", "/media/mmc", "/hdd", "/usb", "/mmc"]:
        path = os.path.join(mount, "XDREAMY", "ServerChannels.json")
        if os.path.isfile(path) or os.path.isdir(os.path.dirname(path)):
            return path
    return "/etc/enigma2/ServerChannels.json"

BOUQUET_DIR = "/etc/enigma2"
DEBUG_LEVEL = 2

# ═══════════════════════════════════════════════════════════════════════════
# SECTION 2: DEBUG LOGGING WITH TIMING
# ═══════════════════════════════════════════════════════════════════════════

_DEBUG_LOG = []
_MAX_LOG_LINES = 500

def log(msg, level=1):
    if level > DEBUG_LEVEL:
        return
    timestamp = time.strftime("%H:%M:%S.") + "%03d" % ((time.time() % 1) * 1000)
    line = "[%s] [CCv2] %s" % (timestamp, msg)
    try:
        print(line)
        _DEBUG_LOG.append(line)
        if len(_DEBUG_LOG) > _MAX_LOG_LINES:
            _DEBUG_LOG.pop(0)
        with open("/tmp/channelcolorizer.log", "a") as f:
            f.write(line + "\n")
    except Exception:
        pass

def log_time(label, start_time, level=2):
    elapsed = (time.time() - start_time) * 1000
    log("⏱  %s took %.2f ms" % (label, elapsed), level)

# ═══════════════════════════════════════════════════════════════════════════
# SECTION 3: COLOR CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

DEFAULT_COLORS = {
    "local":   "00FF00",
    "emu":     "FFFF00",
    "cccam":   "FFA500",
    "biss":    "0000FF",
    "network": "FF4040",
    "ncam":    "FF00FF",
    "wicardd": "00FFFF",
    "gbox":    "FFD700",
    "mgcamd":  "C0C0C0",
    "newcamd": "FF69B4",
    "cs378x":  "D2691E",
}

def get_color_hex(source_key):
    try:
        val = getattr(config.plugins.xDreamy, "color_%s" % source_key).value
    except (AttributeError, Exception):
        val = None

    if not val:
        return DEFAULT_COLORS.get(source_key, "FFFFFF")

    named = {
        "red": "FF0000", "green": "00FF00", "blue": "0000FF", "yellow": "FFFF00",
        "cyan": "00FFFF", "magenta": "FF00FF", "orange": "FFA500", "purple": "800080",
        "pink": "FFC0CB", "brown": "A52A2A", "gray": "808080", "grey": "808080",
        "silver": "C0C0C0", "gold": "FFD700", "lime": "00FF00", "navy": "000080",
        "white": "FFFFFF", "black": "000000",
    }

    val = str(val).strip().lower()
    if val in named:
        return named[val]

    clean = val.lstrip("#").replace("0x", "").replace("0X", "")
    if len(clean) == 6 and all(c in "0123456789ABCDEFabcdef" for c in clean):
        return clean.upper()

    return DEFAULT_COLORS.get(source_key, "FFFFFF")

# ═══════════════════════════════════════════════════════════════════════════
# SECTION 4: JSON I/O (Thread-Safe with Caching)
# ═══════════════════════════════════════════════════════════════════════════

_json_cache = None
_json_cache_time = 0
_JSON_CACHE_TTL = 2

def load_json(force=False):
    global _json_cache, _json_cache_time
    if not force and _json_cache is not None:
        if (time.time() - _json_cache_time) < _JSON_CACHE_TTL:
            return _json_cache.copy()

    path = get_json_path()
    if not os.path.isfile(path):
        _json_cache = {}
        _json_cache_time = time.time()
        return {}

    t0 = time.time()
    try:
        with open(path, "r") as f:
            data = json.load(f)
        _json_cache = data
        _json_cache_time = time.time()
        log_time("JSON load", t0, 2)
        return data.copy()
    except Exception as e:
        return {}

def save_json(data):
    global _json_cache, _json_cache_time
    path = get_json_path()
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.isdir(dir_path):
        try: os.makedirs(dir_path)
        except Exception: pass

    t0 = time.time()
    tmp = path + ".tmp"
    try:
        with open(tmp, "w") as f:
            json.dump(data, f, indent=2, sort_keys=True)
        os.rename(tmp, path)
        _json_cache = data.copy()
        _json_cache_time = time.time()
        log_time("JSON save", t0, 2)
        return True
    except Exception as e:
        return False

# ═══════════════════════════════════════════════════════════════════════════
# SECTION 5: SOFTCAM LOG DISCOVERY & PARSING
# ═══════════════════════════════════════════════════════════════════════════

LOG_PATHS = [
    "/tmp/ecm.info", "/tmp/ecm0.info", "/tmp/ecm1.info", "/tmp/ecm2.info",
    "/tmp/oscam.log", "/var/log/oscam.log", "/tmp/oscam/oscam.log", 
    "/etc/tuxbox/config/oscam/oscam.log", "/etc/tuxbox/config/oscam-emu/oscam.log",
    "/tmp/ncam.log", "/var/log/ncam.log", "/tmp/ncam/ncam.log",
    "/etc/tuxbox/config/ncam/ncam.log",
    "/tmp/cccam.log", "/var/log/cccam.log", "/etc/CCcam.log",
    "/tmp/wicardd.log", "/var/log/wicardd.log",
    "/tmp/gbox.log", "/tmp/mgcamd.log",
]

def find_ecm_file():
    t0 = time.time()
    result = None
    for n in range(20, -1, -1):
        p = "/tmp/ecm%d.info" % n
        if os.path.isfile(p):
            result = p
            break
    if not result:
        for p in LOG_PATHS:
            if os.path.isfile(p):
                result = p
                break
    log_time("Log discovery", t0, 2)
    return result

def parse_ecm_info(path):
    t0 = time.time()
    result = {}
    try:
        with open(path, "r") as f:
            for line in f:
                line = line.strip()
                if ":" not in line: continue
                k, v = line.split(":", 1)
                result[k.strip().lower()] = v.strip()
    except Exception: pass
    log_time("ECM parse", t0, 2)
    return result

def parse_softcam_log(path, cam_type):
    t0 = time.time()
    if not os.path.isfile(path): return None
    try:
        with open(path, "r") as f:
            lines = f.readlines()
        search_lines = lines[-200:] if len(lines) > 200 else lines

        for line in reversed(search_lines):
            line_low = line.lower()
            if cam_type in ("oscam", "ncam"):
                if "found (" in line_low and "by " in line_low:
                    m = re.search(r"by\s+([^\s(]+)", line)
                    reader = m.group(1).strip() if m else ""
                    proto = cam_type
                    if "cccam" in line_low: proto = "cccam"
                    elif "cs378x" in line_low: proto = "cs378x"
                    elif "newcamd" in line_low: proto = "newcamd"
                    log_time("Softcam log parse (%s)" % cam_type, t0, 2)
                    return {"reader": reader, "protocol": proto, "source": "net", "raw": line.strip()}
            elif cam_type == "cccam":
                if "ecm" in line_low and "by" in line_low:
                    m = re.search(r"by\s+([^\s,]+)", line, re.I)
                    if m:
                        log_time("Softcam log parse (cccam)", t0, 2)
                        return {"reader": m.group(1).strip(), "protocol": "cccam", "source": "net"}
    except Exception: pass
    return None

def detect_source_from_fields(fields):
    reader = fields.get("reader", "").lower()
    frm = fields.get("from", "").lower()
    protocol = fields.get("protocol", "").lower()
    src = fields.get("source", "").lower()
    caid = fields.get("caid", "").lower().replace("0x", "")

    if caid == "2600" or "biss" in reader or "biss" in protocol: return "biss"
    emu_inds = ["emu", "emulator", "constcw", "softcam", "keys", "wicardd"]
    if any(i in reader for i in emu_inds) or any(i in protocol for i in emu_inds): return "emu"
    loc_inds = ["sci", "internal", "smartreader", "pcsc", "phoenix", "mouse", "card"]
    if src == "sci" or any(i in frm for i in loc_inds) or any(i in protocol for i in loc_inds): return "local"
    
    if "cccam" in frm or "cccam" in reader or "cccam" in protocol: return "cccam"
    if "cs378x" in protocol or "cs378x" in reader: return "cs378x"
    if "newcamd" in protocol or "newcamd" in reader: return "newcamd"
    if "ncam" in protocol or "ncam" in reader: return "ncam"
    
    if ":" in frm and any(c.isdigit() for c in frm): return "network"
    if protocol in DEFAULT_COLORS: return protocol
    return "network"

def get_current_service_info():
    try:
        if not InfoBar.instance or not InfoBar.instance.session: return None, None
        nav = InfoBar.instance.session.nav
        if not nav: return None, None
        ref = nav.getCurrentlyPlayingServiceReference()
        if not ref: return None, None
        name = ServiceReference(ref).getServiceName()
        if not name:
            service = nav.getCurrentService()
            if service and service.info():
                try: name = service.info().getInfo(0)
                except Exception: pass
        return ref.toString(), name or "Unknown"
    except Exception: return None, None

def get_current_decryption_info():
    log_path = find_ecm_file()
    if not log_path: return None
    fields = {}
    log_lower = log_path.lower()
    if log_path.endswith(".info"): fields = parse_ecm_info(log_path)
    elif "oscam" in log_lower: fields = parse_softcam_log(log_path, "oscam") or {}
    elif "ncam" in log_lower: fields = parse_softcam_log(log_path, "ncam") or {}
    elif "cccam" in log_lower: fields = parse_softcam_log(log_path, "cccam") or {}

    if not fields: return None
    source_key = detect_source_from_fields(fields)
    ref, name = get_current_service_info()
    if ref and name:
        log("Detected: %s -> %s (source: %s)" % (name, ref, source_key), 2)
        return ref, name, source_key
    return None

# ═══════════════════════════════════════════════════════════════════════════
# SECTION 8: COLOR TAG HELPERS (Strict Regex & Backslash Protection)
# ═══════════════════════════════════════════════════════════════════════════

_COLOR_TAG_RE = re.compile(r'\\c00[0-9a-fA-F]{6}')

def strip_color_tags(text):
    return _COLOR_TAG_RE.sub('', text)

def add_color_prefix(text, hex_color):
    # Double backslash ensures the .tv file receives a literal "\c00" tag
    return "\\c00%s%s" % (hex_color, text)

def extract_color_from_text(text):
    m = _COLOR_TAG_RE.search(text)
    if m:
        # \c00FFA500 -> indexes 4 to 10 is 'FFA500'
        return m.group(0)[4:10].upper()
    return None

# ═══════════════════════════════════════════════════════════════════════════
# SECTION 9: SMART BATCH UPDATER
# ═══════════════════════════════════════════════════════════════════════════

_processed_refs = set()
_batch_lock = threading.Lock()
_pending_batch = False

def get_all_colored_refs():
    data = load_json()
    all_refs = {}
    for ref, entry in data.items():
        if not isinstance(entry, dict) or "source" not in entry: continue
        hex_color = get_color_hex(entry["source"])
        all_refs[ref] = {"name": entry.get("name", "Unknown"), "source": entry["source"], "hex_color": hex_color}
    return all_refs

def get_pending_refs():
    global _processed_refs
    data = load_json()
    if not data: return {}, set()
    pending, changed = {}, set()
    for ref, entry in data.items():
        if not isinstance(entry, dict) or "source" not in entry: continue
        hex_color = get_color_hex(entry["source"])
        current_signature = "%s|%s|%s" % (ref, entry.get("name", ""), hex_color)
        sig_hash = hashlib.md5(current_signature.encode('utf-8')).hexdigest()
        if sig_hash not in _processed_refs:
            pending[ref] = {"name": entry.get("name", "Unknown"), "hex_color": hex_color, "sig_hash": sig_hash}
            changed.add(sig_hash)
    return pending, changed

def background_batch_task(force_full=False):
    global _processed_refs, _pending_batch
    with _batch_lock:
        if _pending_batch: return
        _pending_batch = True

    try:
        all_refs = get_all_colored_refs()
        if not all_refs: return
        
        if force_full:
            pending = all_refs
            for ref, entry in pending.items():
                entry["sig_hash"] = hashlib.md5(("%s|%s|%s" % (ref, entry["name"], entry["hex_color"])).encode('utf-8')).hexdigest()
            new_hashes = set(entry["sig_hash"] for entry in pending.values())
            _processed_refs.clear()
        else:
            pending, new_hashes = get_pending_refs()
            if not pending: return

        try:
            tv_files = [os.path.join(BOUQUET_DIR, f) for f in os.listdir(BOUQUET_DIR) if f.endswith(".tv")]
        except Exception: return

        modified_files = []
        for path in tv_files:
            if not os.path.isfile(path): continue
            try:
                with open(path, "r") as f: lines = f.readlines()
            except Exception: continue

            new_lines, changed, i = [], False, 0
            while i < len(lines):
                line = lines[i].rstrip('\n')
                if line.startswith("#SERVICE "):
                    new_lines.append(line)
                    parts = line.split(" ", 1)
                    if len(parts) >= 2:
                        ref = parts[1].strip()
                        entry = all_refs.get(ref)
                        if entry:
                            hex_color = entry["hex_color"]
                            next_line = lines[i + 1].rstrip('\n') if (i + 1) < len(lines) else ""
                            if next_line.startswith("#DESCRIPTION "):
                                desc_content = next_line[len("#DESCRIPTION "):].strip()
                                clean_name = strip_color_tags(desc_content)
                                name_to_use = entry["name"] or clean_name or "Unknown"
                                existing_color = extract_color_from_text(desc_content)
                                if existing_color == hex_color and clean_name == name_to_use:
                                    new_lines.append(next_line)
                                else:
                                    new_lines.append("#DESCRIPTION %s" % add_color_prefix(name_to_use, hex_color))
                                    changed = True
                                i += 1
                            else:
                                new_lines.append("#DESCRIPTION %s" % add_color_prefix(entry["name"], hex_color))
                                changed = True
                        else:
                            next_line = lines[i + 1].rstrip('\n') if (i + 1) < len(lines) else ""
                            if next_line.startswith("#DESCRIPTION "):
                                new_lines.append(next_line)
                                i += 1
                    else:
                        if (i + 1) < len(lines) and lines[i + 1].startswith("#DESCRIPTION "):
                            new_lines.append(lines[i + 1].rstrip('\n'))
                            i += 1
                else:
                    new_lines.append(line)
                i += 1

            if changed:
                try:
                    tmp = path + ".tmp"
                    with open(tmp, "w") as f: f.write("\n".join(new_lines) + "\n")
                    os.rename(tmp, path)
                    modified_files.append(os.path.basename(path))
                except Exception: pass

        if not force_full: _processed_refs.update(new_hashes)
        if modified_files:
            log("Modified %d files, triggering UI refresh..." % len(modified_files), 2)
            _gui_reloader.trigger()

    finally:
        with _batch_lock: _pending_batch = False

# ═══════════════════════════════════════════════════════════════════════════
# SECTION 10: THREAD-SAFE UI RELOADER (INSTANT CACHE DROP)
# ═══════════════════════════════════════════════════════════════════════════

class SmartReloader:
    def __init__(self):
        self.timer = eTimer()
        self.timer.callback.append(self._do_reload)
        self._pending = False
        self._last_reload = 0
        self._min_interval = 2.0

    def trigger(self):
        now = time.time()
        if now - self._last_reload < self._min_interval: return
        if self._pending: return
        self._pending = True
        self.timer.start(500, True)

    def _do_reload(self):
        self._pending = False
        try:
            # 1. Reload DB structures in C++
            if hasattr(eDVBDB.getInstance(), 'reloadServicelist'):
                eDVBDB.getInstance().reloadServicelist()
            eDVBDB.getInstance().reloadBouquets()

            # 2. Force Enigma2 C++ Listbox to Drop Cache and Re-Fetch #DESCRIPTION
            if InfoBar.instance and hasattr(InfoBar.instance, 'servicelist') and InfoBar.instance.servicelist:
                cs = InfoBar.instance.servicelist
                
                if hasattr(cs, 'servicelist') and hasattr(cs, 'getRoot') and hasattr(cs, 'setCurrentSelection'):
                    root = cs.getRoot()
                    if root:
                        # Save the current channel cursor so it doesn't jump to the top
                        current_ref = cs.getCurrentSelection()
                        
                        # CRITICAL: This tells the C++ List to re-query eDVBDB (Grabs new colors)
                        if hasattr(cs.servicelist, 'setRoot'):
                            cs.servicelist.setRoot(root)
                        
                        # Restore user's cursor position instantly
                        if current_ref:
                            cs.setCurrentSelection(current_ref)
                        
                        # Force visual repaint on the newly fetched data
                        if hasattr(cs.servicelist, 'instance') and hasattr(cs.servicelist.instance, 'invalidate'):
                            cs.servicelist.instance.invalidate()

            self._last_reload = time.time()
            log("Bouquets and Channel List UI instantly refreshed.", 2)
        except Exception as e:
            log("Reload error: %s" % e, 1)

_gui_reloader = SmartReloader()

# ═══════════════════════════════════════════════════════════════════════════
# SECTION 11: POLLING & HOOKS
# ═══════════════════════════════════════════════════════════════════════════

_channel_list_open = False
_ui_hooks_installed = False

def on_channel_list_opened():
    global _channel_list_open
    _channel_list_open = True
    log("Channel list OPENED", 2)

def on_channel_list_closed():
    global _channel_list_open
    _channel_list_open = False
    log("Channel list CLOSED - triggering refresh", 2)
    threading.Thread(target=lambda: background_batch_task(force_full=True)).start()

def check_and_install_ui_hooks():
    global _ui_hooks_installed
    if _ui_hooks_installed: return
    try:
        if InfoBar.instance and hasattr(InfoBar.instance, 'servicelist') and InfoBar.instance.servicelist:
            cs = InfoBar.instance.servicelist
            if hasattr(cs, 'onShow') and hasattr(cs, 'onHide'):
                if on_channel_list_opened not in cs.onShow: cs.onShow.append(on_channel_list_opened)
                if on_channel_list_closed not in cs.onHide: cs.onHide.append(on_channel_list_closed)
                _ui_hooks_installed = True
                log("Native Enigma2 Channel List UI Hooks Installed", 1)
    except Exception: pass

_poll_timer = None
_last_ref = None
_consecutive_same = 0

def poll():
    global _last_ref, _consecutive_same
    
    # ─── Skin check: only run when XDREAMY skin is active ──────────────
    try:
        if "xdreamy" not in str(config.skin.primary_skin.value or "").lower():
            # If skin is not active, we can stop polling to avoid useless work
            # But we let the timer continue; we just return early.
            return
    except Exception:
        # If skin check fails, assume active to avoid breaking old configs
        pass
    
    check_and_install_ui_hooks()
    try:
        enabled = config.plugins.xDreamy.channelcolor_enabled.value
    except AttributeError:
        enabled = False
    if not enabled:
        return

    ref, name = get_current_service_info()
    if not ref:
        return

    if ref == _last_ref:
        _consecutive_same += 1
        if _consecutive_same < 6:
            return
        _consecutive_same = 0
    else:
        _consecutive_same = 0
    _last_ref = ref

    try:
        infobar = InfoBar.instance
        if infobar and infobar.session and infobar.session.nav:
            service = infobar.session.nav.getCurrentService()
            if service:
                info = service.info()
                is_crypted = info.getInfo(iServiceInformation.sIsCrypted) == 1 if info else True
            else:
                is_crypted = True
        else:
            is_crypted = True
    except Exception:
        is_crypted = True
    if not is_crypted:
        return

    info = get_current_decryption_info()
    if not info:
        return

    ref_str, name, source_key = info
    data = load_json()
    existing = data.get(ref_str)
    if existing and existing.get("source") == source_key and existing.get("name") == name:
        return

    data[ref_str] = {"name": name, "source": source_key, "time": int(time.time())}
    if save_json(data):
        try:
            threading.Timer(1.0, lambda: background_batch_task(force_full=False)).start()
        except Exception:
            import thread
            thread.start_new_thread(lambda: background_batch_task(force_full=False), ())

def start_polling():
    global _poll_timer
    if _poll_timer is None:
        _poll_timer = eTimer()
        _poll_timer.callback.append(poll)
        _poll_timer.start(5000, False)

def stop_polling():
    global _poll_timer
    if _poll_timer:
        _poll_timer.stop()
        _poll_timer = None

def hook_infobar_zap():
    try:
        from Screens.InfoBarGenerics import InfoBarChannelSelection
        original_zapDown = InfoBarChannelSelection.zapDown
        original_zapUp = InfoBarChannelSelection.zapUp

        def wrapped_zapDown(self):
            result = original_zapDown(self)
            _schedule_poll_now()
            return result

        def wrapped_zapUp(self):
            result = original_zapUp(self)
            _schedule_poll_now()
            return result

        InfoBarChannelSelection.zapDown = wrapped_zapDown
        InfoBarChannelSelection.zapUp = wrapped_zapUp

        if hasattr(InfoBarChannelSelection, 'switchToService'):
            original_switchToService = InfoBarChannelSelection.switchToService
            def wrapped_switchToService(self, service):
                result = original_switchToService(self, service)
                _schedule_poll_now()
                return result
            InfoBarChannelSelection.switchToService = wrapped_switchToService
    except Exception as e:
        pass

def _schedule_poll_now():
    try:
        threading.Timer(1.0, poll).start()
    except Exception:
        pass

# ═══════════════════════════════════════════════════════════════════════════
# SECTION 12: INITIALIZATION
# ═══════════════════════════════════════════════════════════════════════════

def init():
    log("ChannelColorizer v2.5 initializing...", 1)
    
    # ─── Skin check: only start when XDREAMY skin is active ──────────────
    try:
        if "xdreamy" not in str(config.skin.primary_skin.value or "").lower():
            log("xDreamy skin not active, ChannelColorizer will not start.", 1)
            return
    except Exception:
        # If skin check fails, assume active to avoid breaking old configs
        pass

    try:
        enabled = config.plugins.xDreamy.channelcolor_enabled.value
    except AttributeError:
        enabled = False

    if enabled:
        start_polling()
        hook_infobar_zap()
        try:
            threading.Timer(5.0, lambda: background_batch_task(force_full=True)).start()
        except Exception:
            import thread
            thread.start_new_thread(lambda: background_batch_task(force_full=True), ())
        log("ChannelColorizer v2.5 STARTED", 1)
    else:
        log("ChannelColorizer disabled in config.", 1)

def stop():
    stop_polling()