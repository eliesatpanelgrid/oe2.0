#!/bin/sh
SKINDIR='/usr/share/enigma2/xDreamy'
SETTINGS='/etc/enigma2/settings'
LOGFILE='/tmp/xDreamy_postinstall.log'
OPBITRATE_SRC='/usr/bin/opbitrate'
OPBITRATE_DEST='/usr/bin/opbitrate'

echo "" > "$LOGFILE"

log() {
    echo "$(date '+%H:%M:%S') - $1" | tee -a "$LOGFILE"
}

log "🎬 Starting post-installation setup for XDREAMY..."

# 🧠 Copy optbitrate if not already present
if [ -f "$OPBITRATE_DEST" ]; then
    log "ℹ️ opbitrate already exists. Skipping copy."
else
    if [ -f "$OPBITRATE_SRC" ]; then
        cp "$OPBITRATE_SRC" "$OPBITRATE_DEST" && chmod 755 "$OPBITRATE_DEST"
        log "✅ Installed opbitrate to $OPBITRATE_DEST"
    else
        log "⚠️ opbitrate source file missing. Skipping."
    fi
fi

# 🎨 Detect image and apply logo
declare -A images=(
    ["openatv"]="OpenATV"
    ["egami"]="EGAMI"
    ["pure2"]="Pure2"
    ["openspa"]="OpenSPA"
    ["opendroid"]="Opendroid"
    ["openbh"]="OpenBH"
    ["openpli"]="OpenPLi"
    ["openvix"]="OpenViX"
    ["openhdf"]="OpenHDF"
    ["nonsolosat"]="NonSoloSat"
    ["satlodge"]="SatLodge"
    ["GCC"]="FoxBob"
    ["TNAP"]="TNAP"
    ["Hyperion"]="Hyperion"
    ["teamblue"]="TeamBlue"
)

log "🔍 Detecting image..."
image_detected=false

# Read files safely, ignore missing files
file_image_version=$(tr '[:upper:]' '[:lower:]' < /etc/image-version 2>/dev/null)
file_issue=$(tr '[:upper:]' '[:lower:]' < /etc/issue 2>/dev/null)

for key in "${!images[@]}"; do
    key_lower=$(echo "$key" | tr '[:upper:]' '[:lower:]')

    # Check if key exists in either file
    if [[ "$file_image_version" == *"$key_lower"* ]] || [[ "$file_issue" == *"$key_lower"* ]]; then
        IMAGE="$key"
        image_detected=true
        break
    fi
done

# Apply the logo
if [ "$image_detected" = true ] && [ -f "$SKINDIR/image_logo/$IMAGE/imagelogo.png" ]; then
    cp "$SKINDIR/image_logo/$IMAGE/imagelogo.png" "$SKINDIR/imagelogo.png"
    log "✅ Applied logo for image: $IMAGE"
elif [ -f "/usr/share/enigma2/distro-logo.png" ]; then
    cp "/usr/share/enigma2/distro-logo.png" "$SKINDIR/imagelogo.png"
    log "✅ Applied generic distro logo"
else
    cp "$SKINDIR/image_logo/default/imagelogo.png" "$SKINDIR/imagelogo.png"
    log "✅ Applied default logo"
fi


# 💻 Box detection
box_model=$(head -n 1 /etc/hostname)
if [ -f "/usr/share/enigma2/$box_model.png" ]; then
    cp "/usr/share/enigma2/$box_model.png" "$SKINDIR/boximage.png"
    log "✅ Box model logo applied: $box_model"
else
    log "⚠️ No logo found for box model: $box_model"
fi

# 🧹 Cleanup image_logo folder
rm -rf "$SKINDIR/image_logo" && log "🧹 Removed image_logo directory"

# 🎯 Set xDreamy as default skin using awk
log "🎯 Setting xDreamy as default skin..."
if grep -q "^config.skin.primary_skin=" "$SETTINGS"; then
    awk '{if ($0 ~ /^config\.skin\.primary_skin=/) print "config.skin.primary_skin=xDreamy/skin.xml"; else print $0}' "$SETTINGS" > "${SETTINGS}.tmp" && mv "${SETTINGS}.tmp" "$SETTINGS"
    log "✅ Updated existing skin setting to xDreamy"
else
    echo "config.skin.primary_skin=xDreamy/skin.xml" >> "$SETTINGS"
    log "✅ Appended skin setting for xDreamy"
fi

# 🧭 Fix OpenSPA initial channel selection issue
if grep -q "^config.misc.initialchannelselection=True" "$SETTINGS"; then
    awk '{if ($0 ~ /^config\.misc\.initialchannelselection=True/) print "config.misc.initialchannelselection=False"; else print $0}' "$SETTINGS" > "${SETTINGS}.tmp" && mv "${SETTINGS}.tmp" "$SETTINGS"
    log "✅ Forced channel selection to False"
fi

# ✅ Done
log "✅ Post-install setup complete!"
log "🔁 Restarting GUI..."
sleep 2
init 4 && sleep 4 && init 3
