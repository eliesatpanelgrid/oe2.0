# -*- coding: utf-8 -*-
# ============================================================================
#  ListColorizer.py  -  Production Version
#  Colors channel names based on ECM source for InfoBar and compatible screens
#  NOTE: Main channel list (eListboxServiceContent) cannot be colored from Python
# ============================================================================

from Components.config import config, ConfigSubsection, ConfigText, ConfigYesNo
from enigma import eServiceReference, eServiceCenter, iServiceInformation, eTimer
from Screens.InfoBar import InfoBar
import json
import os
import time
import traceback
import re

# ============================================================================
#  LOGGING
# ============================================================================
FORCE_LOG_FILE = "/tmp/xdreamy_colorizer.log"

def force_log(msg):
    line = "[ListColorizer] %s" % msg
    try:
        print(line)
    except Exception:
        pass
    try:
        with open(FORCE_LOG_FILE, "a") as f:
            f.write(line + "\n")
    except Exception:
        pass

# ============================================================================
#  CONFIGURATION
# ============================================================================
if not hasattr(config.plugins, "xDreamy"):
    config.plugins.xDreamy = ConfigSubsection()
if not hasattr(config.plugins.xDreamy, "color_local"):
    config.plugins.xDreamy.color_local = ConfigText(default="00FF00", fixed_size=False)
if not hasattr(config.plugins.xDreamy, "color_emu"):
    config.plugins.xDreamy.color_emu = ConfigText(default="FFFF00", fixed_size=False)
if not hasattr(config.plugins.xDreamy, "color_cccam"):
    config.plugins.xDreamy.color_cccam = ConfigText(default="FFA500", fixed_size=False)
if not hasattr(config.plugins.xDreamy, "color_network"):
    config.plugins.xDreamy.color_network = ConfigText(default="FF4040", fixed_size=False)
if not hasattr(config.plugins.xDreamy, "channelcolor_enabled"):
    config.plugins.xDreamy.channelcolor_enabled = ConfigYesNo(default=False)
if not hasattr(config.plugins.xDreamy, "debug_master"):
    config.plugins.xDreamy.debug_master = ConfigYesNo(default=False)

def _resolve_color(key):
    mapping = {
        "local": config.plugins.xDreamy.color_local.value,
        "emu": config.plugins.xDreamy.color_emu.value,
        "cccam": config.plugins.xDreamy.color_cccam.value,
        "network": config.plugins.xDreamy.color_network.value,
    }
    val = mapping.get(key, "")
    if not val:
        return None
    try:
        clean = val.strip().lstrip("#").replace("0x", "").replace("0X", "")
        rgb = int(clean, 16) & 0xFFFFFF
        return 0xFF000000 | rgb
    except Exception:
        return None

# ============================================================================
#  JSON CACHE
# ============================================================================
JSON_DIR = "/hdd/XDREAMY/"
JSON_PATH = os.path.join(JSON_DIR, "ServerChannels.json")

try:
    if not os.path.exists(JSON_DIR):
        os.makedirs(JSON_DIR)
        force_log("Created directory: %s" % JSON_DIR)
except Exception as e:
    force_log("Could not create directory %s: %s" % (JSON_DIR, e))

_cache = {}
_cache_mtime = 0

def load_color_cache():
    global _cache, _cache_mtime
    try:
        current_mtime = os.path.getmtime(JSON_PATH) if os.path.isfile(JSON_PATH) else 0
        if current_mtime == _cache_mtime and _cache:
            return _cache
        _cache_mtime = current_mtime
    except Exception:
        pass

    force_log("load_color_cache: loading JSON from %s" % JSON_PATH)
    new_cache = {}
    try:
        if not os.path.isfile(JSON_PATH):
            force_log("load_color_cache: JSON file NOT FOUND")
            _cache = {}
            return _cache
        with open(JSON_PATH, "r") as f:
            data = json.load(f)
        for key, entry in data.items():
            source = entry.get("source")
            if not source:
                continue
            color = _resolve_color(source)
            if color is None:
                continue
            new_cache[key] = color
            if not key.startswith("name:"):
                name = entry.get("name")
                if name:
                    new_cache["name:%s" % name] = color
        _cache = new_cache
        force_log("load_color_cache: loaded %d entries." % len(_cache))
    except Exception as e:
        force_log("load_color_cache: EXCEPTION\n%s" % traceback.format_exc())
        _cache = {}
    return _cache

def get_color(ref, name):
    cache = load_color_cache()
    if ref:
        ref_str = ref.toString() if hasattr(ref, 'toString') else str(ref)
        if ref_str in cache:
            return cache[ref_str]
    if name:
        name_key = "name:%s" % name
        if name_key in cache:
            return cache[name_key]
    return None

# ============================================================================
#  PATCH: eServiceReference.getName() - Works for InfoBar and eLabel widgets
# ============================================================================
_original_getName = None

def patched_getName(self):
    name = _original_getName(self)
    if not name:
        return name
    
    color = get_color(self, name)
    if color:
        hex_color = "%06x" % (color & 0xFFFFFF)
        # Enigma2 color escape format for eLabel widgets
        colored = "\\c00%s%s\\c00ffffff" % (hex_color, name)
        return colored
    
    return name

def patch_getName():
    global _original_getName
    try:
        if not hasattr(eServiceReference, 'getName'):
            force_log("eServiceReference has no getName method")
            return False
        
        if _original_getName is not None:
            return True
        
        _original_getName = eServiceReference.getName
        eServiceReference.getName = patched_getName
        force_log("Patched eServiceReference.getName() - colors active for InfoBar")
        return True
    except Exception as e:
        force_log("patch_getName failed: %s" % traceback.format_exc())
        return False

# ============================================================================
#  ECM MONITOR
# ============================================================================
_previous_ref = None

def _find_ecmpath():
    for n in (7, 6, 5, 4, 3, 2, 1):
        higher = "/tmp/ecm%d.info" % (n + 1)
        this = "/tmp/ecm%d.info" % n
        if os.path.isfile(this) and (n == 7 or not os.path.isfile(higher)):
            return this
    if os.path.isfile("/tmp/ecm.info"):
        return "/tmp/ecm.info"
    return None

def _ecm_source_fields():
    result = {"source": "", "from": "", "reader": "", "using": "", "protocol": ""}
    ecmfile = _find_ecmpath()
    if not ecmfile:
        return result
    try:
        with open(ecmfile, "r") as f:
            for line in f:
                line = line.strip()
                if not line or ":" not in line:
                    continue
                key, _, val = line.partition(":")
                key = key.strip().lower()
                val = val.strip()
                if key in result:
                    result[key] = val
    except Exception:
        pass
    return result

def _detect_color_key(info, fields):
    if info.getInfo(iServiceInformation.sIsCrypted) != 1:
        return None
    source = fields["source"]
    frm = fields["from"]
    reader = fields["reader"]
    using = fields["using"]
    protocol = fields["protocol"]
    if source == "sci":
        return "local"
    if (using == "emu" or source in ("emu", "card") or reader == "emu"
            or "card" in source or "emu" in source or "biss" in source or "tb" in source
            or "constant_cw" in reader or "constcw" in protocol or "static" in protocol):
        return "emu"
    if source == "net":
        if "cccam" in frm.lower() or "cccam" in reader.lower():
            return "cccam"
        return "network"
    return None

OSCAM_LOG_CANDIDATES = (
    "/tmp/.oscam/oscam.log",
    "/tmp/.oscam/log/oscam.log",
    "/var/tmp/oscam.log",
    "/tmp/oscam.log",
)
OSCAM_LOG_TAIL_BYTES = 300 * 1024
OSCAM_SCAN_MIN_INTERVAL = 60.0
_READER_INIT_RE = re.compile(r"\(reader\)\s+(\S+)\s+\[(\w+)\]\s+proxy initialized,\s+server\s+(\S+)")
_READER_EMU_RE = re.compile(r"\(reader\)\s+(\S+)\s+\[(\w+)\]\s+card detected")
_ECM_RESULT_RE = re.compile(r"\(ecm\)\s+\S+\s+\(P:\s*([0-9A-Fa-f]+)[^)]*\):\s*(found|rejected)\s*\((\d+)\s*ms\)\s*by\s+"
                            r"(\S+)(?:\s*\([^)]*\))?\s*-\s*(.+?)\s*$", re.MULTILINE)
_oscam_log_path = None
_oscam_last_scan = 0.0

def _find_oscam_log():
    global _oscam_log_path
    if _oscam_log_path and os.path.isfile(_oscam_log_path):
        return _oscam_log_path
    for p in OSCAM_LOG_CANDIDATES:
        if os.path.isfile(p):
            _oscam_log_path = p
            return p
    return None

def _tail_read(path, max_bytes):
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as f:
            if size > max_bytes:
                f.seek(size - max_bytes)
                f.readline()
            data = f.read()
        return data.decode("utf-8", "ignore")
    except Exception:
        return ""

def _save_json_entry(service_ref, name, source_key, extra=""):
    force_log("_save_json_entry: %s -> %s" % (name, source_key))
    try:
        data = {}
        if os.path.isfile(JSON_PATH):
            with open(JSON_PATH, "r") as f:
                data = json.load(f)
        key = service_ref if service_ref else "name:%s" % name
        old = data.get(key, {})
        new = {"name": name, "source": source_key, "extra": extra, "last_seen": int(time.time())}
        if old.get("name") == new["name"] and old.get("source") == new["source"]:
            force_log("_save_json_entry: no change, skipping.")
            return
        data[key] = new
        tmp = JSON_PATH + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=1)
        os.rename(tmp, JSON_PATH)
        force_log("_save_json_entry: saved.")
    except Exception as e:
        force_log("_save_json_entry: EXCEPTION\n%s" % traceback.format_exc())

def _scan_oscam_log(force=False):
    global _oscam_last_scan
    now = time.time()
    if not force and (now - _oscam_last_scan) < OSCAM_SCAN_MIN_INTERVAL:
        return
    _oscam_last_scan = now
    path = _find_oscam_log()
    if not path:
        force_log("_scan_oscam_log: no OSCam log found.")
        return
    text = _tail_read(path, OSCAM_LOG_TAIL_BYTES)
    if not text:
        return
    reader_color = {}
    for m in _READER_INIT_RE.finditer(text):
        line_name, kind, server = m.group(1), m.group(2), m.group(3)
        if kind.lower() == "cccam":
            reader_color[line_name] = ("cccam", server)
        else:
            reader_color[line_name] = ("network", server)
    for m in _READER_EMU_RE.finditer(text):
        line_name, kind = m.group(1), m.group(2)
        if kind.lower() == "emu":
            reader_color[line_name] = ("emu", line_name)
    found_count = 0
    for m in _ECM_RESULT_RE.finditer(text):
        caid, status, ms, reader_line, channel_name = m.groups()
        if status != "found":
            continue
        channel_name = channel_name.strip()
        if not channel_name:
            continue
        color_key, server = reader_color.get(reader_line, ("network", reader_line))
        _save_json_entry(None, channel_name, color_key,
                         "OSCam: %s | CAID %s | %s ms" % (server, caid, ms))
        found_count += 1
    force_log("_scan_oscam_log: scanned %s, found %d entries." % (path, found_count))

def on_service_changed():
    if not config.plugins.xDreamy.channelcolor_enabled.value:
        force_log("on_service_changed: channelcolor_enabled is OFF, skipping.")
        return
    try:
        infobar = InfoBar.instance
        if not infobar or not infobar.session:
            return
        nav = infobar.session.nav
        if not nav:
            return
        ref = nav.getCurrentlyPlayingServiceReference()
        if not ref:
            return
        ref_str = ref.toString()
        global _previous_ref
        if ref_str == _previous_ref:
            return
        _previous_ref = ref_str
        service = nav.getCurrentService()
        if not service:
            return
        info = service.info()
        if not info:
            return
        if info.getInfo(iServiceInformation.sIsCrypted) != 1:
            return
        fields = _ecm_source_fields()
        color_key = None
        if fields.get("source"):
            color_key = _detect_color_key(info, fields)
        if not color_key:
            _scan_oscam_log(force=True)
        if color_key:
            name = info.getInfo(iServiceInformation.sName) or ""
            if name:
                extra = "%s | %s" % (fields.get("from", ""), fields.get("reader", ""))
                _save_json_entry(ref_str, name, color_key, extra)
                force_log("on_service_changed: saved from ECM.")
    except Exception as e:
        force_log("on_service_changed: EXCEPTION\n%s" % traceback.format_exc())

def connect_service_changed():
    try:
        infobar = InfoBar.instance
        if not infobar or not infobar.session:
            return
        nav = infobar.session.nav
        if not nav:
            return
        if hasattr(nav, 'event') and hasattr(nav.event, 'append'):
            nav.event.append(on_service_changed)
            force_log("connect_service_changed: connected via nav.event.")
        else:
            force_log("connect_service_changed: no nav.event found.")
    except Exception as e:
        force_log("connect_service_changed: failed: %s" % e)

# ============================================================================
#  SKIN GATE
# ============================================================================
XDREAMY_SKIN_MARKER = "xdreamy"

def _is_xdreamy_active():
    try:
        skin_path = str(config.skin.primary_skin.value or "")
        return XDREAMY_SKIN_MARKER in skin_path.lower()
    except Exception:
        return False

# ============================================================================
#  PUBLIC INIT
# ============================================================================
def init():
    force_log("========================================")
    force_log("ListColorizer init called")
    if not _is_xdreamy_active():
        force_log("XDREAMY skin not active, skipping.")
        return
    force_log("XDREAMY skin active, proceeding.")
    
    load_color_cache()
    
    if patch_getName():
        force_log("eServiceReference.getName() patched successfully.")
        force_log("Colors will appear in: InfoBar, Service Info, and eLabel widgets.")
        force_log("NOTE: Main channel list uses C++ renderer - cannot color from Python.")
    else:
        force_log("Failed to patch eServiceReference.getName()")
    
    connect_service_changed()
    force_log("ListColorizer init complete.")
    force_log("========================================")