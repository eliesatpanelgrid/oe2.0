# -*- coding: utf-8 -*-
# ============================================================
#  XDREAMY Skin Customization Plugin
#  Author   : Inspiron / M.Hussein
#  Version  : 7.0.0
#  FIXED: Instant skin reload (ReloadSkin / eSkin fallback)
# ============================================================

from __future__ import absolute_import
import os
import random
import shutil
import glob
import json
import threading
import time
import zipfile

# ─── Logging Setup ──────────────────────────────────────────────────────────
import logging
from logging.handlers import RotatingFileHandler

_log_file = '/tmp/XDREAMY_Plugin.log'
_log_handler = RotatingFileHandler(_log_file, maxBytes=1024 * 1024, backupCount=3)
_log_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
logger = logging.getLogger('xDreamy')
logger.setLevel(logging.DEBUG)
if not logger.handlers:
    logger.addHandler(_log_handler)

logger.info("=" * 60)
logger.info("xDreamy Plugin loading – version 7.0.5")
logger.info("=" * 60)

# ─── Enigma2 / E2 Imports ────────────────────────────────────────────────────
try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import (
    configfile,
    ConfigOnOff,
    NoSave,
    ConfigText,
    ConfigSelection,
    ConfigSubsection,
    ConfigYesNo,
    ConfigNumber,
    ConfigBoolean,
    config,
    getConfigListEntry,
)
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.Progress import Progress
from Components.Sources.StaticText import StaticText
from enigma import eTimer, loadPic
try:
    from enigma import ReloadSkin
    from enigma import eSkin
except ImportError:
    ReloadSkin = None
    eSkin = None

from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Tools.Directories import fileExists, SCOPE_PLUGINS, resolveFilename
from Tools.Downloader import downloadWithProgress
from Screens.ChoiceBox import ChoiceBox

# ─── File Browser ────────────────────────────────────────────────────────────
try:
    from Screens.LocationBox import LocationBox
    _HAS_LOCATIONBOX = True
except ImportError:
    _HAS_LOCATIONBOX = False

# ─── Localisation ────────────────────────────────────────────────────────────
try:
    from Components.Language import language
    lang = language.getLanguage()
    if lang:
        import gettext
        locale_dir = resolveFilename(SCOPE_PLUGINS, 'Extensions/xDreamy/locale')
        # Try full locale first, fallback to base language (e.g., zh_CN → zh)
        if not os.path.exists(os.path.join(locale_dir, lang, 'LC_MESSAGES')):
            base_lang = lang.split('_')[0]
            if base_lang != lang and os.path.exists(os.path.join(locale_dir, base_lang, 'LC_MESSAGES')):
                lang = base_lang
        gettext.bindtextdomain('XDREAMY', locale_dir)
        gettext.textdomain('XDREAMY')
        _ = gettext.gettext
    else:
        def _(txt):
            return txt
except Exception:
    def _(txt):
        return txt

# ─── PIL / Pillow ────────────────────────────────────────────────────────────
try:
    from PIL import Image as PILImage
    _HAS_PIL = True
except ImportError:
    try:
        import Image as PILImage
        _HAS_PIL = True
    except ImportError:
        PILImage = None
        _HAS_PIL = False

# ─── Constants ───────────────────────────────────────────────────────────────
VERSION = "7.0.0"
SKIN_NAME = "xDreamy"

try:
    cur_skin = config.skin.primary_skin.value.replace('xDreamy/skin.xml', '')
except Exception:
    cur_skin = ''

MVI_PATH = '/usr/share/'
BOOTLOG_PATH = '/usr/lib/enigma2/python/Plugins/Extensions/xDreamy/bootlogos/'
LOGOPATH = '/etc/enigma2/'
SAMPLE_PATH = '/usr/share/enigma2/xDreamy/sample/'
SKIN_FILE = '/usr/share/enigma2/xDreamy/skin.xml'

# ─── TMDB Language Choices ──────────────────────────────────────────────────
TMDB_LANGUAGES = [
    ('en', _('English')),
    ('zh-CN', _('Chinese (Simplified)')),
    ('ar', _('Arabic')),
    ('de', _('German')),
    ('fr', _('French')),
    ('it', _('Italian')),
    ('es', _('Spanish')),
    ('tr', _('Turkish')),
    ('pl', _('Polish')),
    ('ru', _('Russian')),
    ('ja', _('Japanese')),
    ('ko', _('Korean')),
    ('pt', _('Portuguese')),
    ('nl', _('Dutch')),
]

# ─── Storage Paths for Posters/Backdrops ────────────────────────────────────
def _best_storage_base():
    try:
        if config.plugins.xDreamy.storage_mode.value == "custom":
            custom_path = config.plugins.xDreamy.storage_custom_path.value.rstrip("/")
            if custom_path and os.path.isdir(os.path.dirname(custom_path) or "/"):
                return custom_path
    except Exception:
        pass
    for mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
        if os.path.exists(mount) and os.access(mount, os.W_OK):
            return os.path.join(mount, "XDREAMY")
    return "/tmp/XDREAMY"

# ─── COLOUR TEMPLATES ───────────────────────────────────────────────────────
TEMPLATES = {
    # (light text, medium selection, dark background with 00 alpha)
    'Pharaoh':          ('#D6E5F5', '#3B5998', '#001A2A40'),
    'Pyramids':         ('#E8EEF2', '#5D6D7E', '#001A2A2A'),
    'Nile':             ('#D5F5F2', '#148F77', '#000A1A1A'),
    'Sphinx':           ('#E8D5F5', '#7D3C98', '#001A0A2A'),
    'Anubis':           ('#F2F4F4', '#5D6D7E', '#001A1A1A'),
    'Horus':            ('#D6EAF8', '#2E86C1', '#000A1A2A'),
    'Isis':             ('#D5F5E3', '#27AE60', '#000A1A0A'),
    'Osiris':           ('#F0F3F4', '#7F8C8D', '#001A1A1A'),
    'Cleopatra':        ('#F4E8F8', '#8E44AD', '#001A0A1A'),
    'Ra':               ('#F5EDD6', '#B7950B', '#001A1A00'),
    'Sekhmet':          ('#F5D6D6', '#943126', '#001A0A0A'),
    'Kemet':            ('#D6E0F5', '#283747', '#000A1A2A'),
    'Scarab':           ('#D1F2EB', '#17A589', '#000A1A1A'),
    'Nefertiti':        ('#F0E8F5', '#6C3483', '#001A0A1A'),
    'Thoth':            ('#D4E6F1', '#1ABC9C', '#000A1A1A'),
    'Bastet':           ('#F5EAE0', '#A04000', '#001A0A00'),
    'Hathor':           ('#F5DEE8', '#8E44AD', '#001A0A1A'),
    'Sobek':            ('#E8F0D6', '#6E7B28', '#001A1A00'),
    'Akhenaten':        ('#F5E0D5', '#935116', '#001A0A00'),
    'Ramses':           ('#E8D6F5', '#6C3483', '#001A0A2A'),
    'Tutankhamun':      ('#F5ECD6', '#7D6608', '#001A1A00'),
    'Luxor':            ('#D6EAF8', '#138D75', '#000A1A1A'),
    'Karnak':           ('#ECF0F1', '#5D6D7E', '#001A2A2A'),
    'Giza':             ('#F5EDE0', '#784212', '#001A0A00'),
    'Memphis':          ('#D5E8F0', '#2E86C1', '#000A1A2A'),
    'Thebes':           ('#E8D5F5', '#512E5F', '#001A0A1A'),
    'Heliopolis':       ('#EBF5FB', '#3498DB', '#000A1A2A'),
    'Alexandria':       ('#D6EAF8', '#2471A3', '#000A1A2A'),
}

# ─── LIGHT TEXT COLOURS ──────────────────────────────────────────────────────
_COLOR_NAMES = [
    ('Pharaoh Light',        '#D6E5F5'),
    ('Pyramids Light',       '#E8EEF2'),
    ('Nile Light',           '#D5F5F2'),
    ('Sphinx Light',         '#E8D5F5'),
    ('Anubis Light',         '#F2F4F4'),
    ('Horus Light',          '#D6EAF8'),
    ('Isis Light',           '#D5F5E3'),
    ('Osiris Light',         '#F0F3F4'),
    ('Cleopatra Light',      '#F4E8F8'),
    ('Ra Light',             '#F5EDD6'),
    ('Sekhmet Light',        '#F5D6D6'),
    ('Kemet Light',          '#D6E0F5'),
    ('Scarab Light',         '#D1F2EB'),
    ('Nefertiti Light',      '#F0E8F5'),
    ('Thoth Light',          '#D4E6F1'),
    ('Bastet Light',         '#F5EAE0'),
    ('Hathor Light',         '#F5DEE8'),
    ('Sobek Light',          '#E8F0D6'),
    ('Akhenaten Light',      '#F5E0D5'),
    ('Ramses Light',         '#E8D6F5'),
    ('Tutankhamun Light',    '#F5ECD6'),
    ('Luxor Light',          '#D6EAF8'),
    ('Karnak Light',         '#ECF0F1'),
    ('Giza Light',           '#F5EDE0'),
    ('Memphis Light',        '#D5E8F0'),
    ('Thebes Light',         '#E8D5F5'),
    ('Heliopolis Light',     '#EBF5FB'),
    ('Alexandria Light',     '#D6EAF8'),
]

# ─── MEDIUM SELECTION COLOURS ────────────────────────────────────────────────
_SELECTION_NAMES = [
    ('Pharaoh Med',          '#3B5998'),
    ('Pyramids Med',         '#5D6D7E'),
    ('Nile Med',             '#148F77'),
    ('Sphinx Med',           '#7D3C98'),
    ('Anubis Med',           '#5D6D7E'),
    ('Horus Med',            '#2E86C1'),
    ('Isis Med',             '#27AE60'),
    ('Osiris Med',           '#7F8C8D'),
    ('Cleopatra Med',        '#8E44AD'),
    ('Ra Med',               '#B7950B'),
    ('Sekhmet Med',          '#943126'),
    ('Kemet Med',            '#283747'),
    ('Scarab Med',           '#17A589'),
    ('Nefertiti Med',        '#6C3483'),
    ('Thoth Med',            '#1ABC9C'),
    ('Bastet Med',           '#A04000'),
    ('Hathor Med',           '#8E44AD'),
    ('Sobek Med',            '#6E7B28'),
    ('Akhenaten Med',        '#935116'),
    ('Ramses Med',           '#6C3483'),
    ('Tutankhamun Med',      '#7D6608'),
    ('Luxor Med',            '#138D75'),
    ('Karnak Med',           '#5D6D7E'),
    ('Giza Med',             '#784212'),
    ('Memphis Med',          '#2E86C1'),
    ('Thebes Med',           '#512E5F'),
    ('Heliopolis Med',       '#3498DB'),
    ('Alexandria Med',       '#2471A3'),
]

# ─── DARK BACKGROUND COLOURS ────────────────────────────────────────────────
# All hex values start with "00" so transparency is applied via the plugin UI.
_BACKGROUND_NAMES = [
    ('Pharaoh Dark',         '#001A2A40'),
    ('Pyramids Dark',        '#001A2A2A'),
    ('Nile Dark',            '#000A1A1A'),
    ('Sphinx Dark',          '#001A0A2A'),
    ('Anubis Dark',          '#001A1A1A'),
    ('Horus Dark',           '#000A1A2A'),
    ('Isis Dark',            '#000A1A0A'),
    ('Osiris Dark',          '#001A1A1A'),
    ('Cleopatra Dark',       '#001A0A1A'),
    ('Ra Dark',              '#001A1A00'),
    ('Sekhmet Dark',         '#001A0A0A'),
    ('Kemet Dark',           '#000A1A2A'),
    ('Scarab Dark',          '#000A1A1A'),
    ('Nefertiti Dark',       '#001A0A1A'),
    ('Thoth Dark',           '#000A1A1A'),
    ('Bastet Dark',          '#001A0A00'),
    ('Hathor Dark',          '#001A0A1A'),
    ('Sobek Dark',           '#001A1A00'),
    ('Akhenaten Dark',       '#001A0A00'),
    ('Ramses Dark',          '#001A0A2A'),
    ('Tutankhamun Dark',     '#001A1A00'),
    ('Luxor Dark',           '#000A1A1A'),
    ('Karnak Dark',          '#001A2A2A'),
    ('Giza Dark',            '#001A0A00'),
    ('Memphis Dark',         '#000A1A2A'),
    ('Thebes Dark',          '#001A0A1A'),
    ('Heliopolis Dark',      '#000A1A2A'),
    ('Alexandria Dark',      '#000A1A2A'),
]

# Helper: get hex value from color name
def _get_hex_from_name(name, choices):
    for display, hex_val in choices:
        if display == name:
            return hex_val
    return name if name.startswith('#') else '#FFFFFF'

# ─── CONFIGURATION ──────────────────────────────────────────────────────────
config.plugins.xDreamy = ConfigSubsection()

# General
config.plugins.xDreamy.ShowInExtensions = ConfigYesNo(default=False)

# Poster/Backdrop/Logo Manager
config.plugins.xDreamy.posterx_enabled  = ConfigBoolean(default=True)
config.plugins.xDreamy.backdropx_enabled = ConfigBoolean(default=True)
config.plugins.xDreamy.logox_enabled     = ConfigBoolean(default=False)
config.plugins.xDreamy.tmdb_language    = ConfigSelection(default="en", choices=TMDB_LANGUAGES)
config.plugins.xDreamy.tmdb_api_key     = ConfigText(default="3c3efcf47c3577558812bb9d64019d65", fixed_size=False)
config.plugins.xDreamy.storage_mode     = ConfigSelection(default="auto", choices=[
    ("auto",   _("Auto-detect (hdd/usb/mmc)")),
    ("custom", _("Custom path")),
])
config.plugins.xDreamy.storage_custom_path = ConfigText(default="/media/hdd/XDREAMY", fixed_size=False)
config.plugins.xDreamy.auto_remove_enabled = ConfigBoolean(default=False)
config.plugins.xDreamy.auto_remove_days    = ConfigNumber(default=90)
config.plugins.xDreamy.worker_threads      = ConfigSelection(default="6", choices=[
    ("2", "2"), ("4", "4"), ("6", _("6 (default)")), ("8", "8"), ("10", "10"),
])

# Temporary / no-save helpers
config.plugins.xDreamy.png            = NoSave(ConfigYesNo(default=False))
config.plugins.xDreamy.backup_action  = NoSave(ConfigYesNo(default=False))
config.plugins.xDreamy.restore_action = NoSave(ConfigYesNo(default=False))

# Boot logos
config.plugins.xDreamy.bootlogos = ConfigOnOff(default=False)

# ─── SKIN GENERAL ────────────────────────────────────────────────────────────
config.plugins.xDreamy.head          = ConfigSelection(default='head', choices=[('head', _('Default'))])
config.plugins.xDreamy.skinSelector  = ConfigSelection(default='base', choices=[('base', _('Default'))])
config.plugins.xDreamy.skinTemplate  = ConfigSelection(default='templates', choices=[
    ('templates',  _('Default')),
    ('templates1', _('Style 1')),
    ('templates2', _('Style 2')),
    ('templates3', _('Style 3')),
    ('templates4', _('Style 4')),
    ('templates5', _('Style 5')),
    ('templates6', _('Style 6')),
    ('templates7', _('Style 7')),
    ('templates8', _('Style 8')),
])

config.plugins.xDreamy.KeysStyle = ConfigSelection(default='keys', choices=[
    ('keys',  _('Default')),
    ('keys1', _('Keys 1')),
    ('keys2', _('Keys 2')),
    ('keys3', _('Keys 3')),
    ('keys4', _('Keys 4')),
    ('keys5', _('Keys 5')),
    ('keys6', _('Keys 6')),
])

config.plugins.xDreamy.clockFormat = ConfigSelection(default="DigitalClock", choices=[
    ('DigitalClock',  _('23:59 – 24 hr')),
    ('DigitalClock1', _('23:59:33 – 24 hr with seconds')),
    ('DigitalClock2', _('12:59 – 12 hr')),
    ('DigitalClock3', _('12:59 AM – 12 hr with period')),
    ('DigitalClock4', _('12:59 AM – 12 hr multi-size')),
    ('DigitalClock5', _('12:59:33 – 12 hr multi-size with seconds')),
])

config.plugins.xDreamy.dateFormat = ConfigSelection(default="%d %B %Y", choices=[
    ("%d %B %Y",      "01 January 2025"),
    ("%d %B %y",      "01 January 25"),
    ("%d %b %Y",      "01 Jan 2025"),
    ("%d %b %y",      "01 Jan 25"),
    ("%d-%m-%Y",      "01-01-2025"),
    ("%d-%m-%y",      "01-01-25"),
    ("%Y-%m-%d",      "2025-01-01"),
    ("%m/%d/%Y",      "01/01/2025"),
    ("%d/%m/%Y",      "01/01/2025"),
    ("%A, %d %B %Y",  "Monday, 01 January 2025"),
    ("%a, %d %b %Y",  "Mon, 01 Jan 2025"),
    ("%A %d %B %Y",   "Monday 01 January 2025"),
    ("%B %d, %Y",     "January 01, 2025"),
    ("%b %d, %Y",     "Jan 01, 2025"),
    ("%d.%m.%Y",      "01.01.2025"),
    ("%d.%m.%y",      "01.01.25"),
    ("%Y.%m.%d",      "2025.01.01"),
    ("%d %m %Y",      "01 01 2025"),
    ("%A, %d %m %Y",  "Monday, 01 01 2025"),
])

# ─── COLOURS ─────────────────────────────────────────────────────────────────
# FIX: Stored value is the internal key, display name is human-readable
config.plugins.xDreamy.colorSelector = ConfigSelection(default='default-color', choices=[
    ('default-color',   _('Template (predefined colour set)')),
    ('color23_Custom',  _('Custom (pick each colour manually)')),
])

config.plugins.xDreamy.BasicColorTemplates = ConfigSelection(
    default='Blue',
    choices=[(k, _(k)) for k in sorted(TEMPLATES.keys())]
)

# FIX: ConfigSelection choices are (display_name, stored_value)
# display_name is the color name shown in UI, stored_value is also the name
# The actual hex is looked up when applying colors
config.plugins.xDreamy.BasicColor      = ConfigSelection(default='White', choices=[(name, name) for name, hex_val in _COLOR_NAMES])
config.plugins.xDreamy.WhiteColor      = ConfigSelection(default='White', choices=[(name, name) for name, hex_val in _COLOR_NAMES])
config.plugins.xDreamy.SelectionColor  = ConfigSelection(default='Sky Blue', choices=[(name, name) for name, hex_val in _SELECTION_NAMES])
config.plugins.xDreamy.BackgroundColor = ConfigSelection(default='Black (solid)', choices=[(name, name) for name, hex_val in _BACKGROUND_NAMES])

config.plugins.xDreamy.transparency = ConfigSelection(default="00", choices=[
    ("00", _("Opaque")),      ("05", _("5%")),   ("10", _("10%")),
    ("15", _("15%")),         ("20", _("20%")),  ("25", _("25%")),
    ("30", _("30%")),         ("35", _("35%")),  ("40", _("40%")),
    ("45", _("45%")),         ("50", _("50%")),  ("55", _("55%")),
    ("60", _("60%")),         ("65", _("65%")),  ("70", _("70%")),
    ("75", _("75%")),         ("80", _("80%")),  ("85", _("85%")),
    ("90", _("90%")),         ("95", _("95%")),  ("99", _("Fully transparent")),
])

# ─── FONTS ──────────────────────────────────────────────────────────────────
config.plugins.xDreamy.FontStyle = ConfigSelection(default='default', choices=[
    ('default', _('Default - font')),
    ('basic',   _('Custom font & scale')),
])

config.plugins.xDreamy.FontName = ConfigSelection(default='Verdana.ttf', choices=[
    ('Verdana.ttf',              _('Verdana (Default)')),
    ('Andlso.ttf',               _('Andlso')),
    ('Beiruti-Regular.ttf',      _('Beiruti')),
    ('BonaNovaSC-Regular.ttf',   _('Bona Nova SC')),
    ('Dubai-REGULAR.ttf',        _('Dubai')),
    ('ElMessiri-Regular.ttf',    _('El Messiri')),
    ('Fustat-Regular.ttf',       _('Fustat')),
    ('Lucida.ttf',               _('Lucida')),
    ('Majalla.ttf',              _('Majalla')),
    ('Mvboli.ttf',               _('MV Boli')),
    ('NaskhArabic-Regular.ttf',  _('Naskh Arabic')),
    ('Nmsbd.ttf',                _('Nmsbd')),
    ('PlexSansArabic-Regular.ttf', _('Plex Sans Arabic')),
    ('ReadexPro-Regular.ttf',    _('Readex Pro')),
    ('Rubik-Regular.ttf',        _('Rubik')),
    ('Tajawal-Regular.ttf',      _('Tajawal')),
    ('Zain-Regular.ttf',         _('Zain')),
])

config.plugins.xDreamy.FontScale = ConfigSelection(default="100", choices=[
    ('75',  _('-25%')), ('80',  _('-20%')), ('85',  _('-15%')),
    ('90',  _('-10%')), ('95',  _('-5%')),  ('100', _('Default (100%)')),
    ('105', _('5%')),   ('110', _('10%')),  ('115', _('15%')),
    ('120', _('20%')),  ('125', _('25%')),  ('130', _('30%')),
])

# ─── INFOBAR ─────────────────────────────────────────────────────────────────
config.plugins.xDreamy.InfobarStyle = ConfigSelection(default='InfoBar-1P', choices=[
    ('InfoBar-1P',   _('Default – 1 Poster')),
    ('InfoBar-2P',   _('InfoBar – 2 Posters')),
    ('InfoBar-NP',   _('InfoBar 1 – No Poster')),
    ('InfoBar2-NP',  _('InfoBar 2 – No Poster')),
    ('InfoBar2-1P',  _('InfoBar 2 – 1 Poster')),
    ('InfoBar2-2P',  _('InfoBar 2 – 2 Posters')),
    ('InfoBar2-1PW', _('InfoBar 2 – 1 Poster Wide')),
    ('InfoBar-HMF',  _('Custom – Header / Middle / Footer')),
])

config.plugins.xDreamy.InfobarH = ConfigSelection(default='No Header', choices=[
    ('No Header',   _('Default – No Header')),
    ('InfoBar H0',  _('H00 – Clock & Date')),
    ('InfoBar H1',  _('H01 – EMU / Network / Card')),
    ('InfoBar H2',  _('H02 – Three-day Weather')),
    ('InfoBar H3',  _('H03 – One Row Header')),
    ('InfoBar H4',  _('H04 – Clock, Date & Weather')),
])

config.plugins.xDreamy.InfobarM = ConfigSelection(default='No Middle', choices=[
    ('No Middle',  _('Default – No Middle')),
    ('InfoBar M0', _('M00')), ('InfoBar M1', _('M01')),
    ('InfoBar M2', _('M02')), ('InfoBar M3', _('M03')),
    ('InfoBar M4', _('M04')),
])

config.plugins.xDreamy.InfobarF = ConfigSelection(default='No Footer', choices=[
    ('No Footer',  _('Default – No Footer')),
    ('InfoBar F0', _('F00')), ('InfoBar F1', _('F01')),
    ('InfoBar F2', _('F02')), ('InfoBar F3', _('F03')),
    ('InfoBar F4', _('F04')), ('InfoBar F5', _('F05')),
    ('InfoBar F6', _('F06')),
])

# ─── SECOND INFOBAR ──────────────────────────────────────────────────────────
config.plugins.xDreamy.SecondInfobar = ConfigSelection(default='SecondInfobar-2P', choices=[
    ('SecondInfobar-2P',  _('Default – 2 Posters')),
    ('SecondInfobar-NP',  _('No Poster')),
    ('SecondInfobar-2PN', _('2 Posters (N)')),
    ('SecondInfobar-2PN2', _('2 Posters (N2)')),
    ('SecondInfobar-HF',  _('Custom – Header / Footer')),
])

config.plugins.xDreamy.SecondInfobarH = ConfigSelection(default='SecondInfobarH01', choices=[
    ('SecondInfobarH01', _('Default')),
    ('SecondInfobarH02', _('S1 – 2E – 2P')),
    ('SecondInfobarH03', _('S2 – 2E – No Poster')),
    ('SecondInfobarH04', _('S2 – 2E – 2P')),
    ('SecondInfobarH05', _('H – 2E – No Poster')),
    ('SecondInfobarH06', _('H – 2E – 2P')),
    ('SecondInfobarH07', _('V – 2E – No Poster')),
    ('SecondInfobarH08', _('V – 2E – 2P')),
    ('SecondInfobarH09', _('V – 2E – 2 Backdrop')),
])

config.plugins.xDreamy.SecondInfobarF = ConfigSelection(default='SecondInfobarF', choices=[
    ('SecondInfobarF',  _('Default')),
    ('SecondInfobarF1', _('Footer 1')),
    ('SecondInfobarF2', _('Footer 2')),
])

# ─── CHANNEL LIST ────────────────────────────────────────────────────────────
config.plugins.xDreamy.ChannSelector = ConfigSelection(default='C00-MTV-5P', choices=[
    ('C00-MTV-5P',  _('Default – 5 Posters')),
    ('C01-MTV-1P',  _('C01 – 1 Poster')),
    ('C02-MTV-2P',  _('C02 – 2 Posters')),
    ('C03-MTV-7P',  _('C03 – 7 Posters')),
    ('C04-MTV-13P', _('C04 – 13 Posters')),
    ('C05-MTV-NP',  _('C05 – No Poster')),
    ('C06-MTV-NP',  _('C06 – No Poster (Alt)')),
    ('C07-MTV-1P',  _('C07 – 1 Poster (Alt)')),
    ('C08-NP',      _('C08 – No Poster')),
    ('C09-NP',      _('C09 – No Poster (Alt)')),
    ('C10-1P',      _('C10 – 1 Poster')),
    ('C11-2P',      _('C11 – 2 Posters')),
    ('C12-2P-NBG',  _('C12 – 2 Posters (No BG)')),
    ('C13-7P',      _('C13 – 7 Posters')),
    ('C14-13P',     _('C14 – 13 Posters')),
    ('C15-14P',     _('C15 – 14 Posters')),
])

config.plugins.xDreamy.ChannSelectorGrid = ConfigSelection(default='G01-MTV-NP', choices=[
    ('G01-MTV-NP',    _('G01 – MTV No Poster')),
    ('G02-1Raw-1P',   _('G02 – 1 Row 1 Poster')),
    ('G03-1Raw-2P',   _('G03 – 1 Row 2 Posters')),
    ('G04-1Raw-1P-Top', _('G04 – 1 Row 1 Poster (Top)')),
    ('G05-Color-2P',  _('G05 – Coloured 2 Posters')),
    ('G06-Background-NP', _('G06 – Background No Poster')),
    ('G07-Transparent-NP', _('G07 – Transparent No Poster')),
    ('G08-Color-2P',  _('G08 – Coloured 2 Posters (Alt)')),
    ('G09-Backdrop',  _('G09 – Backdrop')),
])

config.plugins.xDreamy.ChannelListBackground = ConfigSelection(default='Black', choices=[
    ('Black', _('Default – Black')), ('Color', _('Skin Color'))] +
    [('Background{}'.format(i), _('Background {}'.format(i))) for i in range(17)]
)

# ─── OTHER SCREENS ──────────────────────────────────────────────────────────
config.plugins.xDreamy.EventView = ConfigSelection(default='EventView', choices=[
    ('EventView',  _('Default')),
    ('EventView1', _('Event View 1 – Backdrop')),
    ('EventView2', _('Event View 2 – Big')),
    ('EventView3', _('Event View 3 – 7 Posters')),
    ('EventView4', _('Event View 4 – 11P Full Screen')),
    ('EventView5', _('Event View 5 – 1P Full Screen')),
])

config.plugins.xDreamy.PluginBrowser = ConfigSelection(default='PluginBrowser', choices=[
    ('PluginBrowser',      _('Default')),
    ('PluginBrowser1',     _('Plugin Browser 1')),
    ('PluginBrowser2',     _('Plugin Browser 2')),
    ('PluginBrowser3',     _('Plugin Browser 3')),
    ('PluginBrowser4',     _('Plugin Browser 4')),
    ('PluginBrowser4GHT',  _('Plugin Browser 4 – Grid Top')),
    ('PluginBrowser4GHM',  _('Plugin Browser 4 – Grid Middle')),
    ('PluginBrowser4GHB',  _('Plugin Browser 4 – Grid Bottom')),
    ('PluginBrowser5GVL',  _('Plugin Browser 5 – Grid Left')),
    ('PluginBrowser5GVR',  _('Plugin Browser 5 – Grid Right')),
])

config.plugins.xDreamy.VolumeBar = ConfigSelection(default='volume1', choices=[
    ('volume{}'.format(i), _('Volume Bar {}'.format(i))) for i in range(1, 6)
])

config.plugins.xDreamy.VirtualKeyboard = ConfigSelection(default='VirtualKeyBoard', choices=[
    ('VirtualKeyBoard',  _('Default – Skin Colour')),
    ('VirtualKeyBoard1', _('Black Background')),
    ('VirtualKeyBoard2', _('Colour Background')),
])

config.plugins.xDreamy.NewVirtualKeyboard = ConfigSelection(default='NewVirtualKeyBoard0', choices=[
    ('NewVirtualKeyBoard{}'.format(i), _('New VKB {}'.format(i))) for i in range(5)
])

config.plugins.xDreamy.HistoryZapSelector = ConfigSelection(default='HistoryZapSelector0', choices=[
    ('HistoryZapSelector0', _('Default')),
    ('HistoryZapSelector1', _('History Zap 1 – No Poster')),
    ('HistoryZapSelector2', _('History Zap 2 – No Poster')),
    ('HistoryZapSelector3', _('History Zap 3 – No Poster')),
])

config.plugins.xDreamy.EPGMultiSelection = ConfigSelection(default='EPGMultiSelection', choices=[
    ('EPGMultiSelection',  _('Default')),
    ('EPGMultiSelection1', _('EPG Multi Selection 1')),
])

config.plugins.xDreamy.E2Player = ConfigSelection(default='E2Player', choices=[
    ('E2Player',  _('Default')),
    ('E2Player1', _('E2 Player 1')),
    ('E2Player2', _('E2 Player 2')),
])

config.plugins.xDreamy.EnhancedMovieCenter = ConfigSelection(default='EnhancedMovieCenter', choices=[
    ('EnhancedMovieCenter',  _('Default')),
    ('EnhancedMovieCenter1', _('Enhanced Movie Center 1')),
    ('EnhancedMovieCenter2', _('Enhanced Movie Center 2')),
    ('EnhancedMovieCenter3', _('Enhanced Movie Center 3')),
])

config.plugins.xDreamy.TurnOff = ConfigSelection(default='Background', choices=[
    ('Background{}'.format(i), _('Background {}'.format(i))) for i in range(17)
])

# ─── DATA SOURCES ────────────────────────────────────────────────────────────
config.plugins.xDreamy.WeatherSource = ConfigSelection(default='OAWeatherPlugin', choices=[
    ('OAWeatherPlugin',  _('OA Weather (Default)')),
    ('MSNWeatherPlugin', _('MSN Weather')),
])

config.plugins.xDreamy.BitrateSource = ConfigSelection(default='BitrateRenderer', choices=[
    ('BitrateRenderer', _('Skin Renderer (Default)')),
    ('BitratePlugin',   _('Bitrate Plugin')),
])

config.plugins.xDreamy.SubtitlesClock = ConfigSelection(default='SC', choices=[
    ('SC',  _('Disabled (Default)')),
    ('SC1', _('Bottom Right')),
    ('SC2', _('Bottom Left')),
    ('SC3', _('Top Right')),
    ('SC4', _('Top Left')),
])

config.plugins.xDreamy.RatingStars = ConfigSelection(default='NRS', choices=[
    ('NRS', _('Disabled (Default)')),
    ('RS',  _('Enabled')),
])

config.plugins.xDreamy.CamName = ConfigSelection(default='Access', choices=[
    ('Access',     _('Default (Access)')),
    ('CaidInfo2',  _('CaidInfo')),
    ('CamdRAED',   _('CamdRAED')),
    ('CryptoInfo', _('CryptoInfo')),
    ('EcmInfo',    _('ECM Info')),
])

config.plugins.xDreamy.channelnamecolor = ConfigSelection(default="CLC", choices=[
    ("CLC",  _("White name – White number")),
    ("CLC1", _("White name – Skin colour number")),
    ("CLC2", _("Skin colour name – White number")),
    ("CLC3", _("Skin colour name – Skin colour number")),
])

config.plugins.xDreamy.menufontcolor = ConfigSelection(default='MC', choices=[
    ('MC',  _('White (Default)')),
    ('MC1', _('Skin Colour')),
])

config.plugins.xDreamy.crypt = ConfigSelection(default='Cryptoname', choices=[
    ('Cryptoname', _('Crypto Name (Default)')),
    ('Cryptobar',  _('Crypto Bar')),
])

# ─── PLUGIN INSTALLER ENTRIES ───────────────────────────────────────────────
_PLUGIN_IDS = [
    "ajpanel", "linuxsatpanel", "CiefpPlugins", "smartpanel", "magicpanel",
    "keyadder", "xklass", "youtube", "e2iplayer", "ipaudiopro", "transmission",
    "EPGGrabber", "subssupport", "subssupportpro", "historyzapselector",
    "newvirtualkeyboard", "raedquicksignal",
]
for _pid in _PLUGIN_IDS:
    setattr(config.plugins.xDreamy, "install_{}".format(_pid), NoSave(ConfigYesNo(default=False)))

# ─────────────────────────────────────────────────────────────────────────────
#  SETTINGS APPLIED WITHOUT RESTART
# ─────────────────────────────────────────────────────────────────────────────

def apply_date_format():
    new_fmt = config.plugins.xDreamy.dateFormat.value
    skin_files = [
        "/usr/share/enigma2/xDreamy/sample/head-head.xml",
        SKIN_FILE,
    ]
    start_tag = '<convert type="ClockToText">Format '
    end_tag = '</convert>'

    for path in skin_files:
        if not os.path.exists(path):
            continue
        try:
            with open(path, 'r') as fh:
                data = fh.read()
            idx = data.find(start_tag)
            if idx == -1:
                continue
            end_idx = data.find(end_tag, idx)
            if end_idx == -1:
                continue
            old_tag = data[idx:end_idx + len(end_tag)]
            new_tag = '{}{}{}'.format(start_tag, new_fmt, end_tag)
            if old_tag == new_tag:
                continue
            with open(path, 'w') as fh:
                fh.write(data.replace(old_tag, new_tag))
        except Exception as exc:
            logger.error("apply_date_format error (%s): %s", path, exc)

config.plugins.xDreamy.dateFormat.addNotifier(lambda _: apply_date_format())


def apply_colors_to_file(file_path, ltbluette=None, white=None, bluette=None, header=None):
    """Write colour values into an XML sample file."""
    transparency = config.plugins.xDreamy.transparency.value

    # Convert color names to hex values
    if ltbluette:
        ltbluette = _get_hex_from_name(ltbluette, _COLOR_NAMES)
    if white:
        white = _get_hex_from_name(white, _COLOR_NAMES)
    if bluette:
        bluette = _get_hex_from_name(bluette, _SELECTION_NAMES)
    if header:
        header = _get_hex_from_name(header, _BACKGROUND_NAMES)

    try:
        with open(file_path, 'r') as fh:
            lines = fh.readlines()
        out = []
        for line in lines:
            if ltbluette and '<color name="ltbluette"' in line:
                line = '<color name="ltbluette" value="{}"/>\n'.format(ltbluette)
            elif white and '<color name="white"' in line:
                line = '<color name="white" value="{}"/>\n'.format(white)
            elif bluette and '<color name="bluette"' in line:
                line = '<color name="bluette" value="{}"/>\n'.format(bluette)
            elif header and '<color name="header"' in line:
                if header.startswith('#') and len(header) == 9:
                    header_patched = '#{}{}'.format(transparency, header[3:])
                else:
                    header_patched = header
                line = '<color name="header" value="{}"/>\n'.format(header_patched)
            out.append(line)
        with open(file_path, 'w') as fh:
            fh.writelines(out)
        os.system("sync")
    except Exception as exc:
        logger.error("apply_colors_to_file error: %s", exc)


def apply_template(template_name):
    if template_name not in TEMPLATES:
        return
    lt, bl, hd = TEMPLATES[template_name]
    apply_colors_to_file(
        os.path.join(SAMPLE_PATH, 'C-default-color.xml'),
        ltbluette=lt, bluette=bl, header=hd
    )


def apply_custom_colors():
    apply_colors_to_file(
        os.path.join(SAMPLE_PATH, 'C-color23_Custom.xml'),
        ltbluette=config.plugins.xDreamy.BasicColor.value,
        white=config.plugins.xDreamy.WhiteColor.value,
        bluette=config.plugins.xDreamy.SelectionColor.value,
        header=config.plugins.xDreamy.BackgroundColor.value
    )


def update_font_settings(font_name, font_scale):
    font_file = os.path.join(SAMPLE_PATH, 'font-basic.xml')
    try:
        with open(font_file, 'r') as fh:
            lines = fh.readlines()
        out = []
        for line in lines:
            if '<font name="Regular"' in line:
                line = (
                    '<font name="Regular" '
                    'filename="/usr/share/enigma2/xDreamy/fonts/{fn}" '
                    'scale="{sc}" />\n'
                ).format(fn=font_name, sc=font_scale)
            out.append(line)
        with open(font_file, 'w') as fh:
            fh.writelines(out)
        os.system("sync")
    except Exception as exc:
        logger.error("update_font_settings error: %s", exc)


def apply_renderer_config():
    try:
        from Components.Renderer.iConverlibr import apply_plugin_config

        class _Wrap(object):
            pass

        def _attr(val):
            o = _Wrap()
            o.value = val
            return o

        cfg = _Wrap()
        cfg.tmdb_language        = _attr(config.plugins.xDreamy.tmdb_language.value)
        cfg.posterx_enabled      = _attr(config.plugins.xDreamy.posterx_enabled.value)
        cfg.backdropx_enabled    = _attr(config.plugins.xDreamy.backdropx_enabled.value)
        cfg.logox_enabled        = _attr(config.plugins.xDreamy.logox_enabled.value)
        cfg.worker_threads       = _attr(config.plugins.xDreamy.worker_threads.value)
        cfg.tmdb_api_key         = _attr(config.plugins.xDreamy.tmdb_api_key.value)
        cfg.storage_mode         = _attr(config.plugins.xDreamy.storage_mode.value)
        cfg.storage_custom_path  = _attr(config.plugins.xDreamy.storage_custom_path.value)

        apply_plugin_config(cfg)
        logger.info("Renderer config applied")
    except Exception as e:
        logger.warning("Could not apply renderer config: %s", e)


config.plugins.xDreamy.tmdb_language.addNotifier(lambda _: apply_renderer_config())
config.plugins.xDreamy.posterx_enabled.addNotifier(lambda _: apply_renderer_config())
config.plugins.xDreamy.backdropx_enabled.addNotifier(lambda _: apply_renderer_config())
config.plugins.xDreamy.logox_enabled.addNotifier(lambda _: apply_renderer_config())
config.plugins.xDreamy.storage_mode.addNotifier(lambda _: apply_renderer_config())
config.plugins.xDreamy.storage_custom_path.addNotifier(lambda _: apply_renderer_config())
config.plugins.xDreamy.worker_threads.addNotifier(lambda _: apply_renderer_config())
config.plugins.xDreamy.tmdb_api_key.addNotifier(lambda _: apply_renderer_config())

# ─────────────────────────────────────────────────────────────────────────────
#  POSTER/BACKDROP/LOGO MANAGEMENT HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _resolve_storage_path():
    if config.plugins.xDreamy.storage_mode.value == "custom":
        return config.plugins.xDreamy.storage_custom_path.value.rstrip("/")
    for mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
        if os.path.exists(mount) and os.access(mount, os.W_OK):
            return os.path.join(mount, "XDREAMY")
    return "/tmp/XDREAMY"


def _count_files(folder):
    try:
        return sum(1 for f in os.listdir(folder) if f.endswith(".jpg") or f.endswith(".png"))
    except Exception:
        return 0


def _folder_size_mb(folder):
    try:
        total = sum(
            os.path.getsize(os.path.join(folder, f))
            for f in os.listdir(folder)
            if os.path.isfile(os.path.join(folder, f))
        )
        return total / (1024.0 * 1024.0)
    except Exception:
        return 0.0


def _disk_free_gb(path):
    try:
        root = path
        while not os.path.exists(root):
            parent = os.path.dirname(root)
            if parent == root:
                break
            root = parent
        st = os.statvfs(root)
        return (st.f_bavail * st.f_frsize) / (1024.0 ** 3)
    except Exception:
        return 0.0


def _state_entries(path):
    try:
        with open(path, "r") as f:
            data = json.load(f)
        entries = data.get("entries", data) if isinstance(data, dict) else {}
        return len(entries)
    except Exception:
        return 0


def _queue_size(kind):
    try:
        if kind == "poster":
            from Components.Renderer.iPosterXDownloadThread import work_queue
            return work_queue.qsize()
        elif kind == "backdrop":
            from Components.Renderer.iBackdropXDownloadThread import live_queue
            return live_queue.qsize()
    except Exception:
        return 0


def remove_cached_images():
    logger.info("remove_cached_images() called")
    root = _resolve_storage_path()
    for folder in [os.path.join(root, "poster"), os.path.join(root, "backdrop"), os.path.join(root, "logo")]:
        if not os.path.exists(folder):
            continue
        for f in glob.glob(os.path.join(folder, "*.jpg")):
            try:
                os.remove(f)
            except Exception as e:
                logger.error("Failed to remove %s: %s", f, e)
        for f in glob.glob(os.path.join(folder, "*.png")):
            try:
                os.remove(f)
            except Exception as e:
                logger.error("Failed to remove %s: %s", f, e)
    for state_file in [
        os.path.join(root, "scan_state.json"),
        os.path.join(root, "backdrop", "scan_state.json"),
    ]:
        try:
            if os.path.exists(state_file):
                os.remove(state_file)
        except Exception:
            pass


# ─── BACKUP / RESTORE ─────────────────────────────────────────────────────────

def _backup_dir():
    """Return the backup directory under XDREAMY folder."""
    base = _resolve_storage_path()
    backup_dir = os.path.join(base, "backup")
    try:
        os.makedirs(backup_dir)
    except OSError:
        pass
    return backup_dir


def do_backup():
    """Backup skin.xml to /XDREAMY/backup/"""
    try:
        backup_dir = _backup_dir()
        
        # Check free space on the backup drive
        free_gb = _disk_free_gb(backup_dir)
        if free_gb < 0.01:  # less than ~10 MB
            return False, "Not enough space on storage drive (%.0f MB free)." % (free_gb * 1024)

        if not os.path.exists(SKIN_FILE):
            return False, "skin.xml not found at:\n%s" % SKIN_FILE

        ts = time.strftime("%Y%m%d_%H%M%S")
        dest = os.path.join(backup_dir, "XDREAMY_backup_%s.zip" % ts)

        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(SKIN_FILE, "skin.xml")

        size_kb = os.path.getsize(dest) / 1024.0
        return True, "Backup saved to:\n%s\n\n1 file  |  %.1f KB" % (dest, size_kb)
    except Exception as e:
        return False, "Backup failed:\n%s" % str(e)


def do_restore(zip_path):
    """Restore skin.xml from backup zip."""
    try:
        if not os.path.exists(zip_path):
            return False, "Zip file not found:\n%s" % zip_path

        tmp_dir = "/tmp/xdreamy_restore_%s" % time.strftime("%H%M%S")

        with zipfile.ZipFile(zip_path, "r") as zf:
            names = zf.namelist()
            if "skin.xml" not in names:
                return False, "No skin.xml found in backup.\nContents: %s" % ", ".join(names[:5])
            zf.extract("skin.xml", tmp_dir)

        src = os.path.join(tmp_dir, "skin.xml")
        if not os.path.exists(src):
            return False, "Restore failed: extracted file not found."

        shutil.copy2(src, SKIN_FILE)
        os.system("sync")

        try:
            shutil.rmtree(tmp_dir)
        except Exception:
            pass

        return True, "Restore complete from:\n%s\n\nA GUI restart is needed." % os.path.basename(zip_path)
    except Exception as e:
        return False, "Restore failed:\n%s" % str(e)


def _find_latest_backup():
    """Return the most recent XDREAMY backup zip from /XDREAMY/backup/, or None."""
    backup_dir = _backup_dir()
    try:
        files = [
            f for f in os.listdir(backup_dir)
            if f.startswith("XDREAMY_backup_") and f.endswith(".zip")
        ]
        if not files:
            return None
        files.sort(reverse=True)
        return os.path.join(backup_dir, files[0])
    except Exception:
        return None


def run_auto_remove():
    if not config.plugins.xDreamy.auto_remove_enabled.value:
        return
    days   = int(config.plugins.xDreamy.auto_remove_days.value)
    cutoff = time.time() - days * 86400
    root   = _resolve_storage_path()
    removed = 0
    for sub in ["poster", "backdrop", "logo"]:
        folder = os.path.join(root, sub)
        try:
            for fname in os.listdir(folder):
                if not (fname.endswith(".jpg") or fname.endswith(".png")):
                    continue
                fpath = os.path.join(folder, fname)
                if os.path.getmtime(fpath) < cutoff:
                    os.remove(fpath)
                    removed += 1
        except Exception:
            pass
    if removed:
        logger.info("Auto-removed %d files older than %d days", removed, days)

# ─────────────────────────────────────────────────────────────────────────────
#  PLUGIN INSTALLER HELPERS
# ─────────────────────────────────────────────────────────────────────────────

_PLUGIN_PATHS = {
    "AJPanel":            resolveFilename(SCOPE_PLUGINS, "Extensions/AJPan"),
    "LinuxsatPanel":      resolveFilename(SCOPE_PLUGINS, "Extensions/LinuxsatPanel"),
    "CiefpPlugins":       resolveFilename(SCOPE_PLUGINS, "Extensions/CiefpPlugins"),
    "SmartPanel":         resolveFilename(SCOPE_PLUGINS, "Extensions/SmartAddonspanel"),
    "MagicPanel":         resolveFilename(SCOPE_PLUGINS, "Extensions/MagicPanel"),
    "KeyAdder":           resolveFilename(SCOPE_PLUGINS, "Extensions/KeyAdder"),
    "XKlass":             resolveFilename(SCOPE_PLUGINS, "Extensions/XKlass"),
    "YouTube":            resolveFilename(SCOPE_PLUGINS, "Extensions/YouTube"),
    "E2iPlayer":          resolveFilename(SCOPE_PLUGINS, "Extensions/IPTVPlayer"),
    "Transmission":       resolveFilename(SCOPE_PLUGINS, "Extensions/Transmission"),
    "IPAudioPro":         resolveFilename(SCOPE_PLUGINS, "Extensions/IPAudioPro"),
    "EPGGrabber":         resolveFilename(SCOPE_PLUGINS, "Extensions/EPGGrabber"),
    "SubsSupport":        resolveFilename(SCOPE_PLUGINS, "Extensions/SubsSupport"),
    "SubsSupportPro":     resolveFilename(SCOPE_PLUGINS, "Extensions/SubsSupportPro"),
    "HistoryZapSelector": resolveFilename(SCOPE_PLUGINS, "Extensions/HistoryZapSelector"),
    "NewVirtualKeyboard": resolveFilename(SCOPE_PLUGINS, "SystemPlugins/NewVirtualKeyBoard"),
    "RaedQuickSignal":    resolveFilename(SCOPE_PLUGINS, "Extensions/RaedQuickSignal"),
}

_PLUGIN_URLS = {
    "AJPanel":            "https://raw.githubusercontent.com/AMAJamry/AJPanel/main/installer.sh",
    "LinuxsatPanel":      "https://raw.githubusercontent.com/Belfagor2005/LinuxsatPanel/main/installer.sh",
    "CiefpPlugins":       "https://raw.githubusercontent.com/ciefp/CiefpPlugins/main/installer.sh",
    "SmartPanel":         "https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/SmartAddonspanel/smart-Panel.sh",
    "MagicPanel":         "https://gitlab.com/h-ahmed/Panel/-/raw/main/MagicPanel-install.sh",
    "KeyAdder":           "https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh",
    "XKlass":             "https://gitlab.com/MOHAMED_OS/dz_store/-/raw/main/XKlass/online-setup",
    "YouTube":            "https://raw.githubusercontent.com/fairbird/Youtube-Opensource-DreamOS/master/installer.sh",
    "E2iPlayer":          "https://gitlab.com/eliesat/extensions/-/raw/main/e2iplayer/e2iplayer-main.sh",
    "Transmission":       "http://dreambox4u.com/dreamarabia/Transmission_e2/Transmission_e2.sh",
    "IPAudioPro":         "https://raw.githubusercontent.com/biko-73/ipaudio/main/ipaudio_pro.sh",
    "EPGGrabber":         "https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh",
    "SubsSupport":        "https://github.com/popking159/ssupport/raw/main/subssupport-install.sh",
    "SubsSupportPro":     "https://github.com/popking159/SubsSupportPro/raw/main/subssupportpro-install.sh",
    "HistoryZapSelector": "https://raw.githubusercontent.com/biko-73/History_Zap_Selector/main/installer.sh",
    "NewVirtualKeyboard": "https://raw.githubusercontent.com/fairbird/NewVirtualKeyBoard/main/installer.sh",
    "RaedQuickSignal":    "https://raw.githubusercontent.com/fairbird/RaedQuickSignal/main/installer.sh",
}


def check_plugin_installed(name):
    path = _PLUGIN_PATHS.get(name, "")
    return bool(path and os.path.isdir(path))


def update_plugin_install_status():
    mapping = {
        "AJPanel":            config.plugins.xDreamy.install_ajpanel,
        "LinuxsatPanel":      config.plugins.xDreamy.install_linuxsatpanel,
        "CiefpPlugins":       config.plugins.xDreamy.install_CiefpPlugins,
        "SmartPanel":         config.plugins.xDreamy.install_smartpanel,
        "MagicPanel":         config.plugins.xDreamy.install_magicpanel,
        "KeyAdder":           config.plugins.xDreamy.install_keyadder,
        "XKlass":             config.plugins.xDreamy.install_xklass,
        "YouTube":            config.plugins.xDreamy.install_youtube,
        "E2iPlayer":          config.plugins.xDreamy.install_e2iplayer,
        "Transmission":       config.plugins.xDreamy.install_transmission,
        "IPAudioPro":         config.plugins.xDreamy.install_ipaudiopro,
        "EPGGrabber":         config.plugins.xDreamy.install_EPGGrabber,
        "SubsSupport":        config.plugins.xDreamy.install_subssupport,
        "SubsSupportPro":     config.plugins.xDreamy.install_subssupportpro,
        "HistoryZapSelector": config.plugins.xDreamy.install_historyzapselector,
        "NewVirtualKeyboard": config.plugins.xDreamy.install_newvirtualkeyboard,
        "RaedQuickSignal":    config.plugins.xDreamy.install_raedquicksignal,
    }
    for name, cfg_entry in mapping.items():
        cfg_entry.setValue(check_plugin_installed(name))

update_plugin_install_status()

# ─────────────────────────────────────────────────────────────────────────────
#  AUTOSTART
# ─────────────────────────────────────────────────────────────────────────────

def autostart(reason, **kwargs):
    if reason != 0:
        return
    logger.info("autostart: Enigma2 boot detected")

    run_auto_remove()

    try:
        apply_renderer_config()
    except Exception as e:
        logger.warning("autostart: could not apply renderer config: %s", e)

    if cur_skin == 'xDreamy':
        if config.plugins.xDreamy.bootlogos.value:
            if not fileExists(MVI_PATH + 'bootlogoBack.mvi'):
                try:
                    shutil.copy(MVI_PATH + 'bootlogo.mvi', MVI_PATH + 'bootlogoBack.mvi')
                except Exception as e:
                    logger.error("autostart: copy bootlogo backup: %s", e)
            for fname in ('bootlogo.mvi', 'backdrop.mvi', 'bootlogo_wait.mvi'):
                full = LOGOPATH + fname
                if fileExists(full):
                    try:
                        os.remove(full)
                    except Exception as e:
                        logger.error("autostart: remove %s: %s", full, e)
            if fileExists(BOOTLOG_PATH + 'bootlogo1.mvi'):
                chosen = random.choice(os.listdir(BOOTLOG_PATH))
                src = BOOTLOG_PATH + chosen
                try:
                    shutil.copy(src, MVI_PATH + 'bootlogo.mvi')
                    shutil.copy(src, MVI_PATH + 'backdrop.mvi')
                    logger.info("autostart: boot logo → %s", chosen)
                except Exception as e:
                    logger.error("autostart: copy boot logo: %s", e)
        else:
            backup = MVI_PATH + 'bootlogoBack.mvi'
            if fileExists(backup):
                try:
                    shutil.copy(backup, MVI_PATH + 'bootlogo.mvi')
                    os.remove(backup)
                    logger.info("autostart: restored original boot logo")
                except Exception as e:
                    logger.error("autostart: restore bootlogo: %s", e)

    apply_date_format()
    logger.info("autostart: complete")


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN PLUGIN FUNCTION
# ─────────────────────────────────────────────────────────────────────────────

def main(session, **kwargs):
    session.open(xDreamySetup)


def Plugins(**kwargs):
    plugins = [
        PluginDescriptor(
            name=_("XDREAMY Skin"),
            description=_("Customization tool for XDREAMY Skin"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon='plugin.png',
            fnc=main
        ),
        PluginDescriptor(
            name=_("XDREAMY Boot"),
            description=_("XDREAMY random boot logo manager"),
            where=PluginDescriptor.WHERE_AUTOSTART,
            fnc=autostart
        ),
    ]
    if config.plugins.xDreamy.ShowInExtensions.value:
        plugins.append(PluginDescriptor(
            name=_("XDREAMY Skin Settings"),
            description=_("Customization tool for XDREAMY Skin"),
            where=[PluginDescriptor.WHERE_EXTENSIONSMENU],
            fnc=main
        ))
    return plugins


# ─────────────────────────────────────────────────────────────────────────────
#  XDREAMY ACTION MENU
# ─────────────────────────────────────────────────────────────────────────────

class XDREAMYActionMenu(Screen):
    skin = '''
        <screen name="XDREAMYActionMenu" position="center,center"
                size="550,350" title="XDREAMY Actions">
            <widget name="menu" position="10,10" size="530,310"
                    scrollbarMode="showOnDemand"/>
        </screen>
    '''

    def __init__(self, session, root, refresh_cb):
        Screen.__init__(self, session)
        self.session    = session
        self.root       = root
        self.refresh_cb = refresh_cb
        latest          = _find_latest_backup()
        restore_label   = ("Restore from: %s" % os.path.basename(latest)) if latest else "Restore (no backup found)"

        from Components.MenuList import MenuList
        self._choices = [
            ("Clear all poster images",   self._clear_posters),
            ("Clear all backdrop images", self._clear_backdrops),
            ("Clear all logo images",     self._clear_logos),
            ("Backup skin.xml",           self._backup),
            (restore_label,               self._restore),
            ("Clear ALL cached images",   self._clear_all),
        ]
        self["menu"] = MenuList([c[0] for c in self._choices])
        self["actions"] = ActionMap(
            ["OkCancelActions"],
            {"ok": self._ok, "cancel": self.close},
            -1,
        )

    def _ok(self):
        idx = self["menu"].getSelectedIndex()
        self._choices[idx][1]()

    def _clear_posters(self):
        self.session.openWithCallback(
            self._do_clear_posters, MessageBox,
            "Delete ALL poster images and state cache?\nThis cannot be undone.",
            MessageBox.TYPE_YESNO, default=False,
        )

    def _do_clear_posters(self, confirmed):
        if not confirmed:
            return
        folder  = os.path.join(self.root, "poster")
        removed = 0
        try:
            for f in os.listdir(folder):
                if f.endswith(".jpg"):
                    os.remove(os.path.join(folder, f))
                    removed += 1
        except Exception:
            pass
        try:
            os.remove(os.path.join(self.root, "scan_state.json"))
        except Exception:
            pass
        self.refresh_cb()
        self.session.open(MessageBox, "Removed %d poster files." % removed, MessageBox.TYPE_INFO, timeout=3)
        self.close()

    def _clear_backdrops(self):
        self.session.openWithCallback(
            self._do_clear_backdrops, MessageBox,
            "Delete ALL backdrop images and state cache?\nThis cannot be undone.",
            MessageBox.TYPE_YESNO, default=False,
        )

    def _do_clear_backdrops(self, confirmed):
        if not confirmed:
            return
        folder  = os.path.join(self.root, "backdrop")
        removed = 0
        try:
            for f in os.listdir(folder):
                if f.endswith(".jpg"):
                    os.remove(os.path.join(folder, f))
                    removed += 1
        except Exception:
            pass
        try:
            os.remove(os.path.join(folder, "scan_state.json"))
        except Exception:
            pass
        self.refresh_cb()
        self.session.open(MessageBox, "Removed %d backdrop files." % removed, MessageBox.TYPE_INFO, timeout=3)
        self.close()

    def _clear_logos(self):
        self.session.openWithCallback(
            self._do_clear_logos, MessageBox,
            "Delete ALL logo images?\nThis cannot be undone.",
            MessageBox.TYPE_YESNO, default=False,
        )

    def _do_clear_logos(self, confirmed):
        if not confirmed:
            return
        folder  = os.path.join(self.root, "logo")
        removed = 0
        try:
            for f in os.listdir(folder):
                if f.endswith(".png"):
                    os.remove(os.path.join(folder, f))
                    removed += 1
        except Exception:
            pass
        self.refresh_cb()
        self.session.open(MessageBox, "Removed %d logo files." % removed, MessageBox.TYPE_INFO, timeout=3)
        self.close()

    def _clear_all(self):
        self.session.openWithCallback(
            self._do_clear_all, MessageBox,
            "Delete ALL poster, backdrop and logo images and state caches?\nThis cannot be undone.",
            MessageBox.TYPE_YESNO, default=False,
        )

    def _do_clear_all(self, confirmed):
        if not confirmed:
            return
        remove_cached_images()
        self.refresh_cb()
        self.session.open(MessageBox, "All cached images removed.", MessageBox.TYPE_INFO, timeout=3)
        self.close()

    def _backup(self):
        ok, msg = do_backup()
        self.session.open(
            MessageBox, msg,
            MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR,
            timeout=6,
        )
        self.refresh_cb()
        self.close()

    def _restore(self):
        latest = _find_latest_backup()
        if not latest:
            self.session.open(MessageBox,
                "No backup file found in /XDREAMY/backup/\n"
                "Please create a backup first.",
                MessageBox.TYPE_ERROR)
            return
        self.session.openWithCallback(
            lambda confirmed: self._do_restore(confirmed, latest),
            MessageBox,
            "Restore from:\n%s\n\nThis will overwrite your current skin.xml." % os.path.basename(latest),
            MessageBox.TYPE_YESNO, default=False,
        )

    def _do_restore(self, confirmed, zip_path):
        if not confirmed:
            return
        ok, msg = do_restore(zip_path)
        self.session.open(
            MessageBox, msg,
            MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR,
            timeout=5,
        )
        self.refresh_cb()
        self.close()


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN SETUP SCREEN
# ─────────────────────────────────────────────────────────────────────────────

class xDreamySetup(ConfigListScreen, Screen):
    skin = '''
        <screen name="xDreamySetup" position="center,center" size="1050,680"
                title="XDREAMY Skin Customisation">
            <eLabel font="Regular; 24" foregroundColor="#00ff4A3C"
                    halign="center" position="20,650" size="120,26" text="Cancel"/>
            <eLabel font="Regular; 24" foregroundColor="#0056C856"
                    halign="center" position="220,650" size="120,26" text="Save"/>
            <widget name="Preview" position="997,720" size="498,280" zPosition="1"/>
            <widget name="config" font="Regular; 23" itemHeight="38"
                    position="5,5" scrollbarMode="showOnDemand" size="1040,580"/>
            <widget name="helpText" font="Regular; 22" position="5,595"
                    size="1040,30" foregroundColor="#00ffffff" backgroundColor="#000000"
                    transparent="1" zPosition="2" halign="left" valign="center"/>
            <widget name="status_title" position="1050,10" size="370,26"
                    font="Regular;20" foregroundColor="#ffcc00" transparent="1"/>
            <widget name="status_body" position="1050,42" size="370,500"
                    font="Regular;17" foregroundColor="#ffffff" transparent="1"/>
            <widget name="key_red" position="20,650" size="120,28"
                    font="Regular;18" foregroundColor="#ff4444" transparent="1" halign="center"/>
            <widget name="key_green" position="220,650" size="120,28"
                    font="Regular;18" foregroundColor="#44ff44" transparent="1" halign="center"/>
            <widget name="key_yellow" position="420,650" size="120,28"
                    font="Regular;18" foregroundColor="#ffcc00" transparent="1" halign="center"/>
            <widget name="key_blue" position="620,650" size="120,28"
                    font="Regular;18" foregroundColor="#4488ff" transparent="1" halign="center"/>
        </screen>
    '''

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session      = session
        self.skinFile     = SKIN_FILE
        self.previewFiles = SAMPLE_PATH
        self.setup_title  = "XDREAMY SKIN v {}".format(VERSION)

        self['Preview']      = Pixmap()
        self['helpText']     = Label('')
        self['status_title'] = Label("── Status ─────────────────────")
        self['status_body']  = Label("Loading…")
        self['key_red']    = Label(_('Cancel'))
        self['key_green']  = Label(_('Save'))
        self['key_yellow'] = Label(_('Actions'))
        self['key_blue']   = Label(_('Info'))

        self.editListEntry = None
        ConfigListScreen.__init__(self, [], session=self.session, on_change=self.changedEntry)
        self.onChangedEntry = []

        self['actions'] = ActionMap(
            ['OkCancelActions', 'DirectionActions', 'InputActions',
             'VirtualKeyboardActions', 'ColorActions', 'InfoActions'],
            {
                'showVirtualKeyboard': self.keyText,
                'left':    self.keyLeft,
                'right':   self.keyRight,
                'down':    self.keyDown,
                'up':      self.keyUp,
                'red':     self.keyExit,
                'green':   self.keySave,
                'yellow':  self.keyYellowAction,
                'blue':    self.showInfo,
                'cancel':  self.keyExit,
                'ok':      self.keyOK,
            }, -1)

        self._update_timer = eTimer()
        if fileExists('/var/lib/dpkg/status'):
            self._update_timer_conn = self._update_timer.timeout.connect(self.checkForUpdate)
        else:
            self._update_timer.callback.append(self.checkForUpdate)
        self._update_timer.start(5000, True)

        self._refresh_timer = eTimer()
        self._refresh_timer.callback.append(self._update_status)
        self._refresh_timer.start(5000, False)

        self.onLayoutFinish.append(self.__layoutFinished)
        self.onLayoutFinish.append(self.createSetup)
        self.onLayoutFinish.append(self.showPicture)
        self.onLayoutFinish.append(self._update_status)
        update_plugin_install_status()
        apply_renderer_config()

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    # ─── Status Update ──────────────────────────────────────────────────────

    def _update_status(self):
        root    = _resolve_storage_path()
        p_dir   = os.path.join(root, "poster")
        b_dir   = os.path.join(root, "backdrop")
        l_dir   = os.path.join(root, "logo")
        p_state = os.path.join(root, "scan_state.json")
        b_state = os.path.join(b_dir, "scan_state.json")

        n_p     = _count_files(p_dir)
        n_b     = _count_files(b_dir)
        n_l     = _count_files(l_dir)
        sz_p    = _folder_size_mb(p_dir)
        sz_b    = _folder_size_mb(b_dir)
        sz_l    = _folder_size_mb(l_dir)
        free_gb = _disk_free_gb(root)
        se_p    = _state_entries(p_state)
        se_b    = _state_entries(b_state)
        q_p     = _queue_size("poster")
        q_b     = _queue_size("backdrop")
        latest_bk = _find_latest_backup()

        lines = [
            "Path: %s" % root,
            "",
            "Posters:",
            "  Files:   %d   (%.1f MB)" % (n_p, sz_p),
            "  State:   %d entries" % se_p,
            "  Queue:   %d pending" % q_p,
            "",
            "Backdrops:",
            "  Files:   %d   (%.1f MB)" % (n_b, sz_b),
            "  State:   %d entries" % se_b,
            "  Queue:   %d pending" % q_b,
            "",
            "Logos:",
            "  Files:   %d   (%.1f MB)" % (n_l, sz_l),
            "",
            "Total used: %.1f MB" % (sz_p + sz_b + sz_l),
            "Disk free:  %.1f GB" % free_gb,
        ]
        if latest_bk:
            lines += ["", "Latest backup:", "  %s" % os.path.basename(latest_bk)]

        self["status_body"].setText("\n".join(lines))

    # ─── Help Text ──────────────────────────────────────────────────────────

    def updateHelpText(self):
        current = self['config'].getCurrent()
        if current and len(current) > 2:
            self['helpText'].setText(current[2])
        else:
            self['helpText'].setText('')

    # ─── Navigation ──────────────────────────────────────────────────────────

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self._handlePngReset()
        self.createSetup()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self._handlePngReset()
        self.createSetup()

    def keyDown(self):
        self['config'].instance.moveSelection(self['config'].instance.moveDown)
        self.updateHelpText()
        self.showPicture()

    def keyUp(self):
        self['config'].instance.moveSelection(self['config'].instance.moveUp)
        self.updateHelpText()
        self.showPicture()

    def keyOK(self):
        current = self['config'].getCurrent()
        if not current or len(current) < 2:
            return
        sel   = current[1]
        label = current[0]

        if isinstance(sel, ConfigText):
            self.keyText()
        elif isinstance(sel, ConfigSelection):
            self._openSelectionPopup(current)
        elif label == "Clear Poster Cache (OK)" or sel == config.plugins.xDreamy.png:
            self._doPngRemove()
        elif label == "Backup current settings (OK)" or sel == config.plugins.xDreamy.backup_action:
            self._do_backup()
        elif label == "Restore a backup (OK)" or sel == config.plugins.xDreamy.restore_action:
            self._do_restore()
        else:
            ConfigListScreen.keyOK(self)

    def keyExit(self):
        self._refresh_timer.stop()
        self.close()

    def _handlePngReset(self):
        current = self['config'].getCurrent()
        if current and len(current) > 1:
            if current[1] == config.plugins.xDreamy.png:
                config.plugins.xDreamy.png.setValue(False)
                self._doPngRemove()

    def _doPngRemove(self):
        remove_cached_images()
        self._update_status()
        self.session.open(MessageBox,
                          'All cached poster, backdrop and logo images have been removed.',
                          MessageBox.TYPE_INFO, timeout=4)

    # ─── Storage Path Browser ────────────────────────────────────────────────

    def _browseStoragePath(self):
        if _HAS_LOCATIONBOX:
            current_path = config.plugins.xDreamy.storage_custom_path.value or "/media/hdd"
            self.session.openWithCallback(
                self._storagePathChosen,
                LocationBox,
                text=_("Select XDREAMY storage folder"),
                filename="XDREAMY",
                currDir=os.path.dirname(current_path.rstrip("/")) + "/",
                bookmarks=None,
                autoAdd=False,
                editDir=True,
                inhibitDirs=["/proc", "/sys", "/dev", "/etc"],
                minFree=None,
            )
        else:
            self.keyText()

    def _storagePathChosen(self, path):
        if path:
            config.plugins.xDreamy.storage_custom_path.value = path.rstrip("/")
            self.createSetup()

    # ─── Selection Popup ────────────────────────────────────────────────────

    def _openSelectionPopup(self, current):
        sel = current[1]
        if not hasattr(sel, 'choices'):
            return
        options = [(str(c), c) for c in sel.choices]
        self.session.openWithCallback(
            lambda choice: self._selectionMade(choice, sel),
            ChoiceBox,
            title="Select: " + current[0],
            list=options
        )

    def _selectionMade(self, choice, cfg_item):
        if choice:
            cfg_item.value = choice[1]
            self.createSetup()

    # ─── Virtual Keyboard ────────────────────────────────────────────────────

    def keyText(self):
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        sel = self['config'].getCurrent()
        if sel and len(sel) > 1:
            self.session.openWithCallback(
                self._vkbCallback, VirtualKeyBoard,
                title=sel[0], text=sel[1].value)

    def _vkbCallback(self, value=None):
        if value:
            current = self['config'].getCurrent()
            if current and len(current) > 1:
                current[1].value = value
                self['config'].invalidate(current)

    # ─── Setup List Builder ─────────────────────────────────────────────────

    def createSetup(self):
        try:
            lst = []

            def section(label, colour='\\c00ffc107'):
                return getConfigListEntry(colour + label)

            def spacer():
                return getConfigListEntry('\\c00ffc107' + '  ')

            # ─── General ──────────────────────────────────────────────────
            lst.append(section('SKIN GENERAL SETUP  ' + '─' * 50))
            lst.append(getConfigListEntry(
                'Skin Template:', config.plugins.xDreamy.skinTemplate,
                'Choose the main layout template.'))
            lst.append(getConfigListEntry(
                'Keys Style:', config.plugins.xDreamy.KeysStyle,
                'Select the coloured key graphics.'))
            lst.append(getConfigListEntry(
                'Font Style:', config.plugins.xDreamy.FontStyle,
                'Use "Default" or select "Custom" for your own font.'))
            if config.plugins.xDreamy.FontStyle.value == 'basic':
                lst.append(getConfigListEntry(
                    '  ↳ Font Type:', config.plugins.xDreamy.FontName,
                    'Select a font family.'))
                lst.append(getConfigListEntry(
                    '  ↳ Font Scale:', config.plugins.xDreamy.FontScale,
                    'Adjust all font sizes as a percentage.'))
            lst.append(getConfigListEntry(
                'Date Format:', config.plugins.xDreamy.dateFormat,
                'Choose how dates are displayed.'))
            lst.append(getConfigListEntry(
                'Clock Format:', config.plugins.xDreamy.clockFormat,
                'Select 12-hour or 24-hour time display.'))
            lst.append(getConfigListEntry(
                'Show in Extensions Menu:', config.plugins.xDreamy.ShowInExtensions,
                'When enabled, this plugin appears in Extensions menu.'))

            lst.append(spacer())

            # ─── Colours ──────────────────────────────────────────────────
            lst.append(section('SKIN COLOUR SETTINGS  ' + '─' * 48))
            lst.append(getConfigListEntry(
                'Colour Mode:', config.plugins.xDreamy.colorSelector,
                'Choose "Template" for coordinated set, or "Custom" individually.'))
            if config.plugins.xDreamy.colorSelector.value == 'default-color':
                lst.append(getConfigListEntry(
                    '  ↳ Colour Template:', config.plugins.xDreamy.BasicColorTemplates,
                    'Select a predefined colour theme.'))
                lst.append(getConfigListEntry(
                    '  ↳ Background Transparency:', config.plugins.xDreamy.transparency,
                    'Set how transparent the background panels are.'))
            else:
                lst.append(getConfigListEntry(
                    '  ↳ Title Colour:', config.plugins.xDreamy.BasicColor,
                    'Colour used for section headers.'))
                lst.append(getConfigListEntry(
                    '  ↳ Text Colour:', config.plugins.xDreamy.WhiteColor,
                    'Colour used for general text.'))
                lst.append(getConfigListEntry(
                    '  ↳ Selection Colour:', config.plugins.xDreamy.SelectionColor,
                    'Colour used for selected items.'))
                lst.append(getConfigListEntry(
                    '  ↳ Background Colour:', config.plugins.xDreamy.BackgroundColor,
                    'Dark background colour for panels.'))
                lst.append(getConfigListEntry(
                    '  ↳ Background Transparency:', config.plugins.xDreamy.transparency,
                    'Overrides the alpha channel of the background.'))
            lst.append(getConfigListEntry(
                'Menu Font Colour:', config.plugins.xDreamy.menufontcolor,
                'Choose the text colour for main menu entries.'))
            lst.append(getConfigListEntry(
                'Channel Name Colour:', config.plugins.xDreamy.channelnamecolor,
                'Control the colour of channel names and numbers.'))

            lst.append(spacer())

            # ─── InfoBar ──────────────────────────────────────────────────
            lst.append(section('INFOBAR  ' + '─' * 57))
            lst.append(getConfigListEntry(
                'InfoBar Style:', config.plugins.xDreamy.InfobarStyle,
                'Select the InfoBar layout.'))
            if config.plugins.xDreamy.InfobarStyle.value == 'InfoBar-HMF':
                lst.append(getConfigListEntry(
                    '  ↳ Header Section:', config.plugins.xDreamy.InfobarH,
                    'Top part of your custom InfoBar.'))
                lst.append(getConfigListEntry(
                    '  ↳ Middle Section:', config.plugins.xDreamy.InfobarM,
                    'Middle portion of your custom InfoBar.'))
                lst.append(getConfigListEntry(
                    '  ↳ Footer Section:', config.plugins.xDreamy.InfobarF,
                    'Bottom part of your custom InfoBar.'))

            lst.append(spacer())
            lst.append(section('SECOND INFOBAR  ' + '─' * 51))
            lst.append(getConfigListEntry(
                'SecondInfoBar Style:', config.plugins.xDreamy.SecondInfobar,
                'Select the SecondInfoBar layout.'))
            if config.plugins.xDreamy.SecondInfobar.value == 'SecondInfobar-HF':
                lst.append(getConfigListEntry(
                    '  ↳ Header Section:', config.plugins.xDreamy.SecondInfobarH,
                    'Top section of your custom SecondInfoBar.'))
                lst.append(getConfigListEntry(
                    '  ↳ Footer Section:', config.plugins.xDreamy.SecondInfobarF,
                    'Bottom section of your custom SecondInfoBar.'))

            lst.append(spacer())

            # ─── Channel List ──────────────────────────────────────────────
            lst.append(section('CHANNEL LIST  ' + '─' * 53))
            lst.append(getConfigListEntry(
                'Channel List Style:', config.plugins.xDreamy.ChannSelector,
                'Choose the standard channel list layout.'))
            lst.append(getConfigListEntry(
                'Channel Grid Style:', config.plugins.xDreamy.ChannSelectorGrid,
                'Select the grid-style channel list.'))

            lst.append(spacer())

            # ─── Other Screens ─────────────────────────────────────────────
            lst.append(section('SCREEN STYLES  ' + '─' * 51))
            lst.append(getConfigListEntry(
                'Event View Style:', config.plugins.xDreamy.EventView,
                'Choose the Event Details screen layout.'))
            lst.append(getConfigListEntry(
                'Volume Bar Style:', config.plugins.xDreamy.VolumeBar,
                'Select the appearance of the volume bar.'))
            lst.append(getConfigListEntry(
                'Plugin Browser Style:', config.plugins.xDreamy.PluginBrowser,
                'Select the grid layout for the Plugin Browser.'))
            lst.append(getConfigListEntry(
                'EPG Multi-Selection Style:', config.plugins.xDreamy.EPGMultiSelection,
                'Choose the layout for EPG Multi-Selection.'))
            lst.append(getConfigListEntry(
                'History Zap Selector Style:', config.plugins.xDreamy.HistoryZapSelector,
                'Select the style for the channel-history zap selector.'))

            lst.append(spacer())

            # ─── User Plugin Screens ──────────────────────────────────────
            lst.append(section('USER PLUGIN SCREENS  ' + '─' * 46))
            lst.append(getConfigListEntry(
                'E2Player Style:', config.plugins.xDreamy.E2Player,
                'Select the style for E2Player.'))
            lst.append(getConfigListEntry(
                'New Virtual Keyboard Style:', config.plugins.xDreamy.NewVirtualKeyboard,
                'Choose the appearance for New Virtual Keyboard.'))
            lst.append(getConfigListEntry(
                'Enhanced Movie Center Style:', config.plugins.xDreamy.EnhancedMovieCenter,
                'Select the style for Enhanced Movie Center.'))

            lst.append(spacer())

            # ─── Backgrounds ───────────────────────────────────────────────
            lst.append(section('BACKGROUNDS & BOOT  ' + '─' * 47))
            lst.append(getConfigListEntry(
                'Shutdown / Restart Wallpaper:', config.plugins.xDreamy.TurnOff,
                'Choose the background image for shutdown screens.'))
            lst.append(getConfigListEntry(
                'Random Boot Logos:', config.plugins.xDreamy.bootlogos,
                'Enable random boot logo on each reboot.'))
            lst.append(getConfigListEntry(
                'Virtual Keyboard Style:', config.plugins.xDreamy.VirtualKeyboard,
                'Choose the look of the virtual keyboard.'))
            lst.append(getConfigListEntry(
                'Channel List Background:', config.plugins.xDreamy.ChannelListBackground,
                'Choose the wallpaper behind the channel list.'))

            lst.append(spacer())

            # ─── Data Sources ──────────────────────────────────────────────
            lst.append(section('DATA SOURCES  ' + '─' * 53))
            lst.append(getConfigListEntry(
                'Bitrate Source:', config.plugins.xDreamy.BitrateSource,
                'Select where bitrate values are read from.'))
            lst.append(getConfigListEntry(
                'Rating Stars:', config.plugins.xDreamy.RatingStars,
                'Enable or disable star-rating display.'))
            lst.append(getConfigListEntry(
                'Subtitles Clock Position:', config.plugins.xDreamy.SubtitlesClock,
                'Show a small clock overlay while subtitles are active.'))
            lst.append(getConfigListEntry(
                'SoftCam Name Format:', config.plugins.xDreamy.CamName,
                'Select how the active SoftCam is identified.'))
            lst.append(getConfigListEntry(
                'Crypt Display (InfoBar):', config.plugins.xDreamy.crypt,
                'Choose CAM name or graphical bar.'))

            lst.append(spacer())

            # ─── Weather ───────────────────────────────────────────────────
            lst.append(section('WEATHER  ' + '─' * 57))
            lst.append(getConfigListEntry(
                'Weather Plugin:', config.plugins.xDreamy.WeatherSource,
                'Select the plugin that provides weather data.'))

            lst.append(spacer())

            # ─── Posters / Backdrops / Logos ─────────────────────────────
            lst.append(section('POSTERS, BACKDROPS & LOGOS  ' + '─' * 40))
            lst.append(getConfigListEntry(
                'Enable Poster Downloads:', config.plugins.xDreamy.posterx_enabled,
                'Enable or disable live poster downloads.'))
            lst.append(getConfigListEntry(
                'Enable Backdrop Downloads:', config.plugins.xDreamy.backdropx_enabled,
                'Enable or disable live backdrop downloads.'))
            lst.append(getConfigListEntry(
                'Enable Logo Downloads:', config.plugins.xDreamy.logox_enabled,
                'Enable or disable live logo downloads.'))
            lst.append(getConfigListEntry(
                'TMDB Language:', config.plugins.xDreamy.tmdb_language,
                'Language for TMDB metadata. Changes apply to new downloads.'))
            lst.append(getConfigListEntry(
                'TMDB API Key:', config.plugins.xDreamy.tmdb_api_key,
                'TMDB API key for metadata lookups.'))
            lst.append(getConfigListEntry(
                'Storage Mode:', config.plugins.xDreamy.storage_mode,
                'Auto-detect storage or specify a custom path.'))
            if config.plugins.xDreamy.storage_mode.value == "custom":
                lst.append(getConfigListEntry(
                    '  ↳ Custom Path (Yellow=Browse):', config.plugins.xDreamy.storage_custom_path,
                    'Press Yellow to browse, or OK to type path manually.'))
            lst.append(getConfigListEntry(
                'Worker Threads:', config.plugins.xDreamy.worker_threads,
                'Number of download threads.'))
            lst.append(getConfigListEntry(
                'Auto-Remove Old Files:', config.plugins.xDreamy.auto_remove_enabled,
                'Automatically remove old poster/backdrop/logo files.'))
            if config.plugins.xDreamy.auto_remove_enabled.value:
                lst.append(getConfigListEntry(
                    '  ↳ Remove After (days):', config.plugins.xDreamy.auto_remove_days,
                    'Number of days to keep files before auto-removal.'))
            lst.append(getConfigListEntry(
                'Clear Poster Cache (OK):', config.plugins.xDreamy.png,
                'Press OK to immediately delete all cached images.'))

            lst.append(spacer())

            # ─── Backup / Restore ──────────────────────────────────────────
            lst.append(section('BACKUP & RESTORE  ' + '─' * 47))
            lst.append(getConfigListEntry(
                'Backup current settings (OK)', config.plugins.xDreamy.backup_action,
                'Press OK to backup skin.xml to /XDREAMY/backup/'))
            lst.append(getConfigListEntry(
                'Restore a backup (OK)', config.plugins.xDreamy.restore_action,
                'Press OK to restore skin.xml from /XDREAMY/backup/'))

            lst.append(spacer())

            # ─── Tools Box ──────────────────────────────────────────────────
            lst.append(getConfigListEntry('\\c00ffc107' + '=' * 65))
            lst.append(getConfigListEntry('\\c00ff5400' + '                            XDREAMY TOOLS BOX              '))
            lst.append(getConfigListEntry('\\c00ffc107' + '=' * 65))

            lst.append(getConfigListEntry('\\c0056c856' + '  Panel Plugins:'))
            lst.append(getConfigListEntry("    AJPanel",             config.plugins.xDreamy.install_ajpanel,        'AJPanel control panel.'))
            lst.append(getConfigListEntry("    Linuxsat Panel",      config.plugins.xDreamy.install_linuxsatpanel,  'LinuxsatPanel management tool.'))
            lst.append(getConfigListEntry("    Ciefp Plugins",       config.plugins.xDreamy.install_CiefpPlugins,   'Ciefp Plugins Panel.'))
            lst.append(getConfigListEntry("    SmartAddons Panel",   config.plugins.xDreamy.install_smartpanel,     'SmartPanel.'))
            lst.append(getConfigListEntry("    Magic Panel",         config.plugins.xDreamy.install_magicpanel,     'MagicPanel.'))

            lst.append(spacer())
            lst.append(getConfigListEntry('\\c0056c856' + '  SoftCam Plugins:'))
            lst.append(getConfigListEntry("    KeyAdder",            config.plugins.xDreamy.install_keyadder,       'KeyAdder for SoftCam key updates.'))

            lst.append(spacer())
            lst.append(getConfigListEntry('\\c0056c856' + '  Media Plugins:'))
            lst.append(getConfigListEntry("    X-Klass",             config.plugins.xDreamy.install_xklass,         'X-Klass IPTV streaming plugin.'))
            lst.append(getConfigListEntry("    YouTube",             config.plugins.xDreamy.install_youtube,        'YouTube plugin.'))
            lst.append(getConfigListEntry("    E2iPlayer",           config.plugins.xDreamy.install_e2iplayer,      'E2iPlayer IPTV player.'))
            lst.append(getConfigListEntry("    Transmission",        config.plugins.xDreamy.install_transmission,   'Transmission BitTorrent client.'))

            lst.append(spacer())
            lst.append(getConfigListEntry('\\c0056c856' + '  Utility Plugins:'))
            lst.append(getConfigListEntry("    IPAudioPro",          config.plugins.xDreamy.install_ipaudiopro,        'IPAudioPro audio tracks plugin.'))
            lst.append(getConfigListEntry("    EPG Grabber",         config.plugins.xDreamy.install_EPGGrabber,        'EPG Grabber.'))
            lst.append(getConfigListEntry("    SubsSupport",         config.plugins.xDreamy.install_subssupport,       'SubsSupport subtitle plugin.'))
            lst.append(getConfigListEntry("    SubsSupport Pro",     config.plugins.xDreamy.install_subssupportpro,    'SubsSupport Pro.'))
            lst.append(getConfigListEntry("    HistoryZapSelector",  config.plugins.xDreamy.install_historyzapselector, 'HistoryZapSelector.'))
            lst.append(getConfigListEntry("    New Virtual Keyboard",config.plugins.xDreamy.install_newvirtualkeyboard, 'New Virtual Keyboard.'))
            lst.append(getConfigListEntry("    RaedQuickSignal",     config.plugins.xDreamy.install_raedquicksignal,   'RaedQuickSignal signal monitor.'))

            self['config'].list = lst
            self['config'].l.setList(lst)
            self.updateHelpText()
            self.showPicture()

        except Exception as exc:
            logger.error("createSetup error: %s", exc)

    # ─── Picture Preview ────────────────────────────────────────────────────

    def _getPicturePath(self):
        default = '/usr/share/enigma2/xDreamy/screens/default.png'
        current = self['config'].getCurrent()
        if not current or len(current) < 2:
            return default
        val = current[1].value if hasattr(current[1], 'value') else None
        if not isinstance(val, str):
            return default
        candidate = '/usr/share/enigma2/xDreamy/screens/{}.png'.format(val)
        if fileExists(candidate):
            return candidate
        return default

    def showPicture(self, _=None):
        if not self['Preview'].instance:
            return
        size = self['Preview'].instance.size()
        if size.isNull():
            size.setWidth(498)
            size.setHeight(280)
        path = self._getPicturePath()
        if fileExists(path):
            png = loadPic(path, size.width(), size.height(), 0, 0, 0, 1)
            self['Preview'].instance.setPixmap(png)
        self.updateHelpText()

    # ─── Changed Entry ──────────────────────────────────────────────────────

    def changedEntry(self):
        for cb in self.onChangedEntry:
            cb()
        try:
            current = self['config'].getCurrent()
            if current and len(current) > 1:
                if isinstance(current[1], (ConfigOnOff, ConfigYesNo, ConfigSelection)):
                    self.createSetup()
        except Exception as exc:
            logger.error("changedEntry: %s", exc)

    def getCurrentEntry(self):
        c = self['config'].getCurrent()
        return c[0] if c else ''

    def getCurrentValue(self):
        c = self['config'].getCurrent()
        return str(c[1].getText()) if (c and len(c) > 1) else ''

    def createSummary(self):
        from Screens.Setup import SetupSummary
        return SetupSummary

    # ─── Backup/Restore Actions ──────────────────────────────────────────────

    def _do_backup(self):
        backup_dir = _backup_dir()
        self.session.openWithCallback(
            self._backup_done, MessageBox,
            "This will backup your current skin.xml file to:\n%s\n\nContinue?" % backup_dir,
            MessageBox.TYPE_YESNO, default=False,
        )

    def _backup_done(self, confirmed):
        if not confirmed:
            return
        ok, msg = do_backup()
        self.session.open(
            MessageBox, msg,
            MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR,
            timeout=10,
        )
        self._update_status()

    def _do_restore(self):
        latest = _find_latest_backup()
        if not latest:
            self.session.open(MessageBox,
                "No backup file found in /XDREAMY/backup/\n"
                "Please create a backup first.",
                MessageBox.TYPE_ERROR)
            return
        self.session.openWithCallback(
            lambda confirmed: self._do_restore_confirm(confirmed, latest),
            MessageBox,
            "Restore from:\n%s\n\nThis will overwrite your current skin.xml." % os.path.basename(latest),
            MessageBox.TYPE_YESNO, default=False,
        )

    def _do_restore_confirm(self, confirmed, zip_path):
        if not confirmed:
            return
        ok, msg = do_restore(zip_path)
        self.session.open(
            MessageBox, msg,
            MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR,
            timeout=5,
        )
        self._update_status()

    # ─── Yellow Key: Actions Menu  ──────────────────────────────────────────

    def keyYellowAction(self):
        """Yellow key: open the storage-path browser when the custom-path
        entry is focused; otherwise open the full actions menu."""
        current = self['config'].getCurrent()
        if (current and len(current) > 1
                and current[1] == config.plugins.xDreamy.storage_custom_path):
            self._browseStoragePath()
            return

        root = _resolve_storage_path()
        self.session.open(XDREAMYActionMenu, root, self._update_status)

    # ─── Info Box ───────────────────────────────────────────────────────────

    def showInfo(self):
        msg = (
            "XDREAMY Skin v{version}\n\n"
            "A fully customisable Enigma2 skin created by Inspiron.\n"
            "Rework and enhancements by M.Hussein.\n\n"
            "Features:\n"
            "- TMDB metadata in your preferred language\n"
            "- Automatic poster and backdrop downloads\n"
            "- Smart storage management\n"
            "- Backup and restore\n\n"
            "Supported images:\n"
            "Egami, OpenATV, OpenSPA, PurE2, OpenDroid, OpenBH, Alliance,\n"
            "OpenPLi, OpenVIX, OpenHDF, OpenTR, Foxbob, TNAP, PLi-based images.\n\n"
            "Forum support: https://web.telegram.org/a/#-1002526851239"
        ).format(version=VERSION)
        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=12)

    # ─── Save ───────────────────────────────────────────────────────────────

    def keySave(self):
        try:
            # ─── Phase 1: Save configuration ──────────────────────────────
            # Bootlogo backup
            if config.plugins.xDreamy.bootlogos.value:
                if not fileExists(MVI_PATH + 'bootlogoBack.mvi'):
                    shutil.copy(MVI_PATH + 'bootlogo.mvi', MVI_PATH + 'bootlogoBack.mvi')
            else:
                if fileExists(MVI_PATH + 'bootlogoBack.mvi'):
                    shutil.copy(MVI_PATH + 'bootlogoBack.mvi', MVI_PATH + 'bootlogo.mvi')
                    os.remove(MVI_PATH + 'bootlogoBack.mvi')

            # Fonts
            if config.plugins.xDreamy.FontStyle.value == 'basic':
                update_font_settings(
                    config.plugins.xDreamy.FontName.value,
                    config.plugins.xDreamy.FontScale.value
                )

            # Colours
            if config.plugins.xDreamy.colorSelector.value == 'default-color':
                apply_template(config.plugins.xDreamy.BasicColorTemplates.value)
            else:
                apply_custom_colors()

            apply_date_format()
            apply_renderer_config()

            for entry in self['config'].list:
                if len(entry) > 1:
                    try:
                        entry[1].save()
                    except Exception:
                        pass
            configfile.save()
            os.system("sync")
            logger.info("keySave: config saved")

        except Exception as exc:
            logger.error("keySave (phase 1): %s", exc)

        # ─── Phase 2: Rebuild skin.xml ─────────────────────────────────────
        try:
            skin_parts = [
                'head-{}.xml'.format(config.plugins.xDreamy.head.value),
                'font-{}.xml'.format(config.plugins.xDreamy.FontStyle.value),
                'C-{}.xml'.format(config.plugins.xDreamy.colorSelector.value),
                'DC-{}.xml'.format(config.plugins.xDreamy.clockFormat.value),
                'TP-{}.xml'.format(config.plugins.xDreamy.skinTemplate.value),
                'keys-{}.xml'.format(config.plugins.xDreamy.KeysStyle.value),
                'infobar-{}.xml'.format(config.plugins.xDreamy.InfobarStyle.value),
                'secondinfobar-{}.xml'.format(config.plugins.xDreamy.SecondInfobar.value),
                'CHL-{}.xml'.format(config.plugins.xDreamy.ChannSelector.value),
                'CHLG-{}.xml'.format(config.plugins.xDreamy.ChannSelectorGrid.value),
                'CLB-{}.xml'.format(config.plugins.xDreamy.ChannelListBackground.value),
                'CLB1-{}.xml'.format(config.plugins.xDreamy.TurnOff.value),
                'EV-{}.xml'.format(config.plugins.xDreamy.EventView.value),
                'vol-{}.xml'.format(config.plugins.xDreamy.VolumeBar.value),
                'VKB-{}.xml'.format(config.plugins.xDreamy.VirtualKeyboard.value),
                'NVKB-{}.xml'.format(config.plugins.xDreamy.NewVirtualKeyboard.value),
                'PB-{}.xml'.format(config.plugins.xDreamy.PluginBrowser.value),
                'HZS-{}.xml'.format(config.plugins.xDreamy.HistoryZapSelector.value),
                'EPG-{}.xml'.format(config.plugins.xDreamy.EPGMultiSelection.value),
                'E2Player-{}.xml'.format(config.plugins.xDreamy.E2Player.value),
                'EMC-{}.xml'.format(config.plugins.xDreamy.EnhancedMovieCenter.value),
                'BS-{}.xml'.format(config.plugins.xDreamy.BitrateSource.value),
                'SC-{}.xml'.format(config.plugins.xDreamy.SubtitlesClock.value),
                'RS-{}.xml'.format(config.plugins.xDreamy.RatingStars.value),
                'MC-{}.xml'.format(config.plugins.xDreamy.menufontcolor.value),
                'CRY-{}.xml'.format(config.plugins.xDreamy.crypt.value),
                'WS-{}.xml'.format(config.plugins.xDreamy.WeatherSource.value),
                'CC-{}.xml'.format(config.plugins.xDreamy.channelnamecolor.value),
                'CA-{}.xml'.format(config.plugins.xDreamy.CamName.value),
            ]
            if config.plugins.xDreamy.InfobarStyle.value == 'InfoBar-HMF':
                skin_parts += [
                    'IH-{}.xml'.format(config.plugins.xDreamy.InfobarH.value),
                    'IM-{}.xml'.format(config.plugins.xDreamy.InfobarM.value),
                    'IF-{}.xml'.format(config.plugins.xDreamy.InfobarF.value),
                ]
            if config.plugins.xDreamy.SecondInfobar.value == 'SecondInfobar-HF':
                skin_parts += [
                    'SIH-{}.xml'.format(config.plugins.xDreamy.SecondInfobarH.value),
                    'SIF-{}.xml'.format(config.plugins.xDreamy.SecondInfobarF.value),
                ]

            lines = []
            missing = []
            for fname in skin_parts:
                fpath = os.path.join(self.previewFiles, fname)
                if os.path.isfile(fpath):
                    with open(fpath, 'r') as fh:
                        lines.extend(fh.readlines())
                else:
                    missing.append(fname)

            base_key = config.plugins.xDreamy.skinSelector.value
            base_fname = (
                'base{}.xml'.format(base_key[-1])
                if base_key.startswith('base') and base_key not in ('base', 'base0')
                else 'base.xml'
            )
            base_path = os.path.join(self.previewFiles, base_fname)
            if os.path.isfile(base_path):
                with open(base_path, 'r') as fh:
                    lines.extend(fh.readlines())

            if not lines:
                raise RuntimeError("No skin content assembled – check sample directory.")

            with open(self.skinFile, 'w') as fh:
                fh.writelines(lines)
            os.system("sync")
            logger.info("keySave: skin.xml rebuilt (%d lines)", len(lines))

            warn = ''
            if missing:
                warn = '\n\n⚠ Missing parts (skipped):\n' + '\n'.join(missing)

            # ─── RELOAD SKIN INSTANTLY ────────────────────────────────────
            reloaded = False
            if ReloadSkin is not None:
                try:
                    ReloadSkin()
                    reloaded = True
                    logger.info("keySave: skin reloaded via ReloadSkin()")
                except Exception as e:
                    logger.warning("keySave: ReloadSkin() failed: %s", e)

            if not reloaded and eSkin is not None:
                try:
                    eSkin.getSkin().load()
                    reloaded = True
                    logger.info("keySave: skin reloaded via eSkin.getSkin().load()")
                except Exception as e:
                    logger.warning("keySave: eSkin.getSkin().load() failed: %s", e)

            if reloaded:
                msg = 'Skin saved and reloaded instantly.{warn}\n\nYou can continue without restart.'.format(warn=warn)
            else:
                msg = 'Skin saved successfully.{warn}\n\nA GUI restart is needed to apply the new skin.\nRestart now?'.format(warn=warn)

            self.session.openWithCallback(
                self._restartGUI,
                MessageBox,
                msg,
                MessageBox.TYPE_YESNO
            )

        except Exception as exc:
            logger.error("keySave (phase 2 – skin rebuild): %s", exc)
            self.session.open(
                MessageBox,
                'Error building skin.xml:\n{}'.format(str(exc)),
                MessageBox.TYPE_ERROR
            )

    def _restartGUI(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    # ─── Update Check ──────────────────────────────────────────────────────

    def checkForUpdate(self):
        ver_url = ('https://raw.githubusercontent.com/Insprion80/Skins/'
                   'main/xDreamy/xDreamyv.txt')
        try:
            req = Request(ver_url)
            req.add_header('User-Agent', 'Mozilla/5.0 (compatible; xDreamy/{})'.format(VERSION))
            raw = urlopen(req, timeout=8).read().decode('utf-8').strip()
            logger.info("checkForUpdate: server response: %r", raw)

            if '#' not in raw:
                logger.warning("checkForUpdate: unexpected format: %r", raw)
                return

            server_ver, update_url = raw.split('#', 1)
            server_ver        = server_ver.strip()
            self._update_url  = update_url.strip()

            if server_ver > VERSION:
                self.session.openWithCallback(
                    self._doUpdate,
                    MessageBox,
                    'Update available!\n\nServer version : {sv}\nYour version  : {lv}\n\n'
                    'Download and install now?'.format(sv=server_ver, lv=VERSION),
                    MessageBox.TYPE_YESNO
                )
            elif server_ver == VERSION:
                logger.info("checkForUpdate: already up to date")
            else:
                self.session.open(
                    MessageBox,
                    'You are running a development version ({}).'.format(VERSION),
                    MessageBox.TYPE_INFO, timeout=4
                )

        except Exception as exc:
            logger.error("checkForUpdate error: %s", exc)

    def _doUpdate(self, answer):
        if answer:
            self.session.open(xDreamyUpdater, self._update_url)


# ─────────────────────────────────────────────────────────────────────────────
#  UPDATER SCREEN
# ─────────────────────────────────────────────────────────────────────────────

class xDreamyUpdater(Screen):

    skin = '''
        <screen name="xDreamyUpdater" position="center,center" size="840,280"
                flags="wfBorder" backgroundColor="background">
            <widget name="status" position="20,10" size="800,70" transparent="1"
                    font="Regular; 38" foregroundColor="foreground"
                    backgroundColor="background" valign="center" halign="left"/>
            <widget source="progress" render="Progress"
                    position="20,120" size="800,22" transparent="1"
                    borderWidth="0" foregroundColor="white" backgroundColor="background"/>
            <widget source="progresstext" render="Label"
                    position="200,160" size="440,60" zPosition="2"
                    font="Regular; 26" halign="center" transparent="1"
                    foregroundColor="foreground" backgroundColor="background"/>
        </screen>
    '''

    def __init__(self, session, update_url):
        Screen.__init__(self, session)
        self.session  = session
        self._url     = update_url
        self._dlfile  = '/tmp/xDreamy.ipk'
        self._dl      = None

        self['status']       = Label('Starting download…')
        self['progress']     = Progress()
        self['progresstext'] = StaticText()

        self.onLayoutFinish.append(self._startDownload)

    def _startDownload(self):
        logger.info("xDreamyUpdater: downloading %s → %s", self._url, self._dlfile)
        self['status'].setText('Downloading XDREAMY Skin update…')
        self._dl = downloadWithProgress(self._url, self._dlfile)
        self._dl.addProgress(self._onProgress)
        self._dl.start().addCallback(self._onFinished).addErrback(self._onFailed)

    def _onProgress(self, recv, total):
        if total > 0:
            pct = int(100 * recv / float(total))
            self['progress'].value = pct
            self['progresstext'].text = (
                '{recv:.1f} KB of {total:.1f} KB  ({pct}%)'
            ).format(recv=recv / 1024, total=total / 1024, pct=pct)

    def _onFinished(self, _=''):
        logger.info("xDreamyUpdater: download complete, installing…")
        self['status'].setText('Installing update, please wait…')
        ret = os.system(
            'opkg install --force-reinstall --force-overwrite "{}"'.format(self._dlfile)
        )
        os.system('sync')
        try:
            os.remove(self._dlfile)
        except Exception:
            pass

        if ret == 0:
            self.session.openWithCallback(
                self._restartGUI,
                MessageBox,
                'XDREAMY has been updated successfully!\nRestart the GUI now?',
                MessageBox.TYPE_YESNO
            )
        else:
            self.session.open(
                MessageBox,
                'Installation failed (opkg exit code {}).\n'
                'Please try again or install manually.'.format(ret),
                MessageBox.TYPE_ERROR
            )

    def _onFailed(self, failure=None, error_msg=''):
        if failure:
            error_msg = failure.getErrorMessage()
        logger.error("xDreamyUpdater: download failed: %s", error_msg)
        self['status'].setText('Download failed: {}'.format(error_msg))

    def _restartGUI(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()