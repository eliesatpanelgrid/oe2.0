# -*- coding: utf-8 -*-
# ============================================================
#  XDREAMY Skin Customization Plugin
#  Author   : Inspiron / M.Hussein
#  Version  : 7.2.0
#  Changes  :
#    - Title & Text colors now have group selector (Light/Medium)
#    - Green button always "Apply & Exit" (fast reload aware)
#    - TMDB master switch (UI only)
#    - Restart detection for renderer/converter settings
#    - Toolbox plugin installation via OK
#    - Debug logging with live toggles
#    - Extended Light/Medium groups to Menu & Channel custom text colors
# ============================================================

from __future__ import absolute_import
import os
import re
import random
import shutil
import glob
import json
import threading
import time
import zipfile
from . import ListColorizer

# ─── Logging Setup ──────────────────────────────────────────────────────────
import logging
from logging.handlers import RotatingFileHandler

_log_file    = '/tmp/XDREAMY_Plugin.log'
_log_handler = RotatingFileHandler(_log_file, maxBytes=1024 * 1024, backupCount=3)
_log_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
logger = logging.getLogger('xDreamy')
logger.setLevel(logging.DEBUG)
if not logger.handlers:
    logger.addHandler(_log_handler)

logger.info("=" * 60)
logger.info("xDreamy Plugin loading – version 7.2.0")
logger.info("=" * 60)

# ─── Enigma2 / E2 Imports ───────────────────────────────────────────────────
try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen

from Components.ActionMap     import ActionMap
from Components.ConfigList    import ConfigListScreen
from Components.config        import (
    configfile, ConfigOnOff, NoSave, ConfigText, ConfigSelection,
    ConfigSubsection, ConfigYesNo, ConfigNumber, ConfigBoolean,
    config, getConfigListEntry,
)
from Components.Label         import Label
from Components.PluginComponent import plugins
from Components.Pixmap        import Pixmap
from Components.Sources.Progress   import Progress
from Components.Sources.StaticText import StaticText
from enigma                   import eTimer, loadPic
from Plugins.Plugin           import PluginDescriptor
from Screens.ChoiceBox        import ChoiceBox
from Screens.Console          import Console
from Screens.MessageBox       import MessageBox
from Screens.Screen           import Screen
from Screens.Standby          import TryQuitMainloop
from Tools.Directories        import fileExists, SCOPE_PLUGINS, resolveFilename
from Tools.Downloader         import downloadWithProgress

# ─── File Browser ───────────────────────────────────────────────────────────
try:
    from Screens.LocationBox import LocationBox
    _HAS_LOCATIONBOX = True
except ImportError:
    _HAS_LOCATIONBOX = False

# ─── Localisation ───────────────────────────────────────────────────────────
try:
    from Components.Language import language
    lang = language.getLanguage()
    if lang:
        import gettext
        locale_dir = resolveFilename(SCOPE_PLUGINS, 'Extensions/xDreamy/locale')
        if not os.path.exists(os.path.join(locale_dir, lang, 'LC_MESSAGES')):
            base_lang = lang.split('_')[0]
            if base_lang != lang and os.path.exists(
                    os.path.join(locale_dir, base_lang, 'LC_MESSAGES')):
                lang = base_lang
        gettext.bindtextdomain('XDREAMY', locale_dir)
        gettext.textdomain('XDREAMY')
        _ = gettext.gettext
    else:
        def _(txt): return txt
except Exception:
    def _(txt): return txt

# ─── PIL / Pillow ───────────────────────────────────────────────────────────
try:
    from PIL import Image as PILImage
    _HAS_PIL = True
except ImportError:
    try:
        import Image as PILImage
        _HAS_PIL = True
    except ImportError:
        PILImage = None
        _HAS_PIL = False

# ─── SKIN DETECTION (built‑in, no external file needed) ──────────────────
REQUIRED_SKIN = "xDreamy"

def is_xdreamy_active():
    """True only when XDREAMY is the currently active/primary skin - checked
    LIVE, every single call, with NO caching."""
    try:
        current_skin = str(config.skin.primary_skin.value or "")
        return REQUIRED_SKIN.lower() in current_skin.lower()
    except Exception:
        return False

# ─── Constants ──────────────────────────────────────────────────────────────
VERSION      = "7.2.0"
SKIN_NAME    = "xDreamy"
MVI_PATH     = '/usr/share/'
BOOTLOG_PATH = '/usr/lib/enigma2/python/Plugins/Extensions/xDreamy/bootlogos/'
LOGOPATH     = '/etc/enigma2/'
SAMPLE_PATH  = '/usr/share/enigma2/xDreamy/sample/'
SKIN_FILE    = '/usr/share/enigma2/xDreamy/skin.xml'
SCREEN_PREVIEW_PATH = '/usr/share/enigma2/xDreamy/screens/'

# ─── TMDB Language Choices ──────────────────────────────────────────────────
TMDB_LANGUAGES = [
    # Most spoken / widely used
    ('en',    _('English')),
    ('ar',    _('Arabic')),
    ('es',    _('Spanish')),
    ('fr',    _('French')),
    ('de',    _('German')),
    ('it',    _('Italian')),
    ('pt',    _('Portuguese')),
    ('ru',    _('Russian')),
    ('hi',    _('Hindi')),           # added
    ('bn',    _('Bengali')),         # added (widely spoken)
    
    # Asian languages
    ('zh-CN', _('Chinese (Simplified)')),
    ('zh-TW', _('Chinese (Traditional)')),  # added (often requested)
    ('ja',    _('Japanese')),
    ('ko',    _('Korean')),
    ('th',    _('Thai')),            # added
    ('vi',    _('Vietnamese')),      # added
    ('id',    _('Indonesian')),      # added

    # European (more)
    ('nl',    _('Dutch')),           # already there
    ('sv',    _('Swedish')),         # added
    ('da',    _('Danish')),          # added
    ('no',    _('Norwegian')),       # added
    ('fi',    _('Finnish')),         # added
    ('el',    _('Greek')),           # added
    ('cs',    _('Czech')),           # added
    ('hu',    _('Hungarian')),       # added
    ('ro',    _('Romanian')),        # added
    ('pl',    _('Polish')),          # already there
    ('uk',    _('Ukrainian')),       # already there
    ('tr',    _('Turkish')),         # already there

    # Middle Eastern / others
    ('he',    _('Hebrew')),          # added
    ('fa',    _('Persian')),         # added
]

# ─── Storage Path Helper ────────────────────────────────────────────────────
def _import_iconverlibr():
    try:
        return __import__('iConverlibr', globals(), locals(), ['*'], 1)
    except Exception as e:
        last_exc = e
    for spec in ("Plugins.Extensions.xDreamy.iConverlibr",
                 "Components.Renderer.iConverlibr",
                 "iConverlibr"):
        try:
            return __import__(spec, fromlist=["*"])
        except Exception as e:
            last_exc = e
    raise last_exc


def _resolve_storage_path():
    try:
        return _import_iconverlibr().get_base_path()
    except Exception as e:
        logger.warning("_resolve_storage_path: could not reach iConverlibr.get_base_path (%s), using fallback", e)
        try:
            if config.plugins.xDreamy.storage_mode.value == "custom":
                custom_path = config.plugins.xDreamy.storage_custom_path.value.rstrip("/")
                if custom_path and os.path.isdir(os.path.dirname(custom_path) or "/"):
                    return custom_path
        except Exception:
            pass
        for mount in ["/media/hdd", "/media/usb", "/media/mmc"]:
            if os.path.exists(mount) and os.access(mount, os.W_OK):
                return os.path.join(mount, "XDREAMY")
        return "/tmp/XDREAMY"

# ─── Color TEMPLATES ───────────────────────────────────────────────────────
TEMPLATES = {
    # Ancient Egyptian Inspired
    'Akhenaten':    ('#F5E0D5', '#935116', '#001A0A00'),
    'Alexandria':   ('#D6EAF8', '#2471A3', '#000A1A2A'),
    'Anubis':       ('#F2F4F4', '#5D6D7E', '#001A1A1A'),
    'Bastet':       ('#F5EAE0', '#A04000', '#001A0A00'),
    'Cleopatra':    ('#F4E8F8', '#8E44AD', '#001A0A1A'),
    'Giza':         ('#F5EDE0', '#784212', '#001A0A00'),
    'Hathor':       ('#F5DEE8', '#CB4E8A', '#001A0A1A'),
    'Horus':        ('#D6EAF8', '#2E86C1', '#000A1A2A'),
    'Isis':         ('#D5F5E3', '#27AE60', '#000A1A0A'),
    'Nefertiti':    ('#F0E8F5', '#6C3483', '#001A0A1A'),
    'Nile':         ('#D5F5F2', '#148F77', '#000A1A1A'),
    'Osiris':       ('#F0F3F4', '#7F8C8D', '#001A1A1A'),
    'Pharaoh':      ('#D6E5F5', '#3B5998', '#001A2A40'),
    'Ra':           ('#F5EDD6', '#B7950B', '#001A1A00'),
    'Ramses':       ('#E8D6F5', '#7D3C98', '#001A0A2A'),
    'Sekhmet':      ('#F5D6D6', '#943126', '#001A0A0A'),
    'Sobek':        ('#E8F0D6', '#6E7B28', '#001A1A00'),
    'Tutankhamun':  ('#F5ECD6', '#7D6608', '#001A1A00'),

    # Modern Luxury & Cold
    'Midnight':     ('#E8EAF6', '#3F51B5', '#000D0D1A'),
    'Emerald':      ('#E0F2F1', '#00897B', '#000A1A18'),
    'RoyalGold':    ('#FFFDE7', '#FBC02D', '#001A1808'),
    'Crimson':      ('#FFEBEE', '#E53935', '#001A0808'),
    'Ocean':        ('#E1F5FE', '#039BE5', '#0008181A'),
    'Forest':       ('#E8F5E9', '#43A047', '#000A1A0B'),
    'Sunset':       ('#FFF3E0', '#FB8C00', '#001A1208'),
    'Lavender':     ('#F3E5F5', '#8E24AA', '#001A0D1A'),
    'Steel':        ('#CFD8DC', '#546E7A', '#00181A1B'),
    'RoseGold':     ('#FCE4EC', '#D81B60', '#001A0812'),
    'Copper':       ('#EFEBE9', '#6D4C41', '#001A1513'),
    'Slate':        ('#ECEFF1', '#455A64', '#000F1214'),
    'Electric':     ('#E0F7FA', '#00ACC1', '#0008181A'),
    'Amethyst':     ('#EDE7F6', '#5E35B1', '#000F0B1A'),
    'Sandstone':    ('#FAFAFA', '#8D6E63', '#001A1918'),
    'Sky':          ('#E3F2FD', '#1E88E5', '#0008121A'),
    'Mint':         ('#E0F2F1', '#009688', '#00081A18'),
    'Bronze':       ('#FBE9E7', '#BF360C', '#001A120B'),
    'Azure':        ('#E0E0E0', '#1565C0', '#000A101A'),
    'Charcoal':     ('#EEEEEE', '#616161', '#00121212'),
    'Moss':         ('#F1F8E9', '#558B2F', '#000B1A09'),
    'Indigo':       ('#E8EAF6', '#3949AB', '#000D0E1A'),
    'Ruby':         ('#FFCDD2', '#C62828', '#001A0A0A'),
    'Sapphire':     ('#BBDEFB', '#1565C0', '#000A101A'),
    'Olive':        ('#F9FBE7', '#9E9D24', '#001A1A0A'),
    'Platinum':     ('#FAFAFA', '#9E9E9E', '#00141414'),
    'Merlot':       ('#F8BBD0', '#880E4F', '#001A0810'),
    'ForestDeep':   ('#C8E6C9', '#2E7D32', '#00081A08'),
    'Beige':         ('#F5F5DC', '#D2B48C', '#001A1810'),
    'Taupe':         ('#E5E1DA', '#958A78', '#001A1612'),
    'Mocha':         ('#D7CCC8', '#6D4C41', '#00120E0A'),
    'Champagne':     ('#F8F4E3', '#C5A059', '#001A1810'),
    'Stone':         ('#E0E0E0', '#9E9E9E', '#00141414'),
    'Sand':          ('#F9F1E0', '#D4AC0D', '#001A1608'),
    'SlateGrey':     ('#CFD8DC', '#546E7A', '#000E1012'),
    'Cream':         ('#FFFDD0', '#E6C200', '#001A1608'),
    'Espresso':      ('#D7CCC8', '#4E342E', '#000E0A08'),
    'Silver':        ('#F5F5F5', '#757575', '#00121212'),
    'Latte':         ('#F0E6D2', '#BCAAA4', '#001A1410'),
    'Suede':         ('#E0D6C8', '#A1887F', '#001A1410'),
    'Graphite':      ('#EEEEEE', '#424242', '#000A0A0A'),
    'Khaki':         ('#F5F5DC', '#BDB76B', '#001A180C'),
    'Smoke':         ('#ECEFF1', '#78909C', '#000C1012'),
    'Sepia':         ('#EFEBE9', '#8D6E63', '#001A1410'),
    'Ivory':         ('#FFFFF0', '#BDB76B', '#0018160A'),
    'Driftwood':     ('#D7CCC8', '#795548', '#00120E0A'),
    'Zinc':          ('#E0E0E0', '#607D8B', '#000E1012'),
    'Oatmeal':       ('#F5E6CA', '#D7CCC8', '#001A1612'),
    'SageLuxury':    ('#E8F5E9', '#81C784', '#00081208'),
    'Terra':         ('#FBE9E7', '#FF8A65', '#001A1008'),
    'Willow':        ('#F1F8E9', '#9CCC65', '#000C1208'),
    'SlateBlue':     ('#E3F2FD', '#7986CB', '#000A0C16'),
    'Quartz':        ('#F5F5F5', '#B0BEC5', '#00121214'),
    'Cinder':        ('#ECEFF1', '#455A64', '#000A0E10'),
    'GoldenTan':     ('#FFF9C4', '#D4E157', '#00181608'),
    'Ash':           ('#FAFAFA', '#616161', '#00101010'),
    'Flax':          ('#FFF8E1', '#DCE775', '#001A1808'),
    'Mushroom':      ('#D7CCC8', '#A1887F', '#0012100E'),
}

# ─── Color CHOICE LISTS ────────────────────────────────────────────────────
_COLOR_NAMES = sorted(
    [('{} Light'.format(k), v[0]) for k, v in TEMPLATES.items()],
    key=lambda x: x[0]
)
_SELECTION_NAMES = sorted(
    [('{} Med'.format(k), v[1]) for k, v in TEMPLATES.items()],
    key=lambda x: x[0]
)
_BACKGROUND_NAMES = sorted(
    [('{} Dark'.format(k), v[2]) for k, v in TEMPLATES.items()],
    key=lambda x: x[0]
)

# ─── Color helpers ─────────────────────────────────────────────────────────
def _get_hex_from_name(name, choices):
    for display, hex_val in choices:
        if display == name:
            return hex_val
    return name if (name and name.startswith('#')) else '#FFFFFF'


def _hex_to_rgb_str(hex_str, fallback='#FFFFFF'):
    try:
        h = (hex_str or '').lstrip('#')
        if len(h) == 8:
            h = h[2:]
        if len(h) != 6:
            return fallback
        int(h, 16)
        return '#' + h
    except Exception:
        return fallback


def _version_tuple(v):
    try:
        return tuple(int(x) for x in str(v).strip().split('.'))
    except Exception:
        return (0,)

# ─── CONFIGURATION ──────────────────────────────────────────────────────────
config.plugins.xDreamy = ConfigSubsection()

# General
config.plugins.xDreamy.ShowInExtensions = ConfigYesNo(default=False)

# Poster / Backdrop / Logo Manager
config.plugins.xDreamy.tmdb_enabled        = ConfigYesNo(default=True)   # UI only
config.plugins.xDreamy.posterx_enabled      = ConfigBoolean(default=True)
config.plugins.xDreamy.backdropx_enabled    = ConfigBoolean(default=True)
config.plugins.xDreamy.logox_enabled        = ConfigBoolean(default=False)
config.plugins.xDreamy.tmdb_language        = ConfigSelection(default="en",  choices=TMDB_LANGUAGES)
config.plugins.xDreamy.tmdb_api_key         = ConfigText(default="3c3efcf47c3577558812bb9d64019d65", fixed_size=False)
config.plugins.xDreamy.storage_mode         = ConfigSelection(default="auto", choices=[
    ("auto",   _("Auto-detect (hdd/usb/mmc)")),
    ("custom", _("Custom path")),
])
config.plugins.xDreamy.storage_custom_path  = ConfigText(default="/media/hdd/XDREAMY", fixed_size=False)
config.plugins.xDreamy.auto_remove_enabled  = ConfigBoolean(default=False)
config.plugins.xDreamy.auto_remove_days     = ConfigNumber(default=90)
config.plugins.xDreamy.worker_threads       = ConfigSelection(default="6", choices=[
    ("2", "2"), ("4", "4"), ("6", _("6 (default)")), ("8", "8"), ("10", "10"),
])

# EPG Translate
config.plugins.xDreamy.epg_translate_enabled = ConfigYesNo(default=False)
config.plugins.xDreamy.epg_translate_provider = ConfigSelection(default="google", choices=[
    ("google", _("Google Translate")),
    ("gemini", _("Google Gemini")),
    ("groq",   _("Groq")),
])
config.plugins.xDreamy.epg_translate_target_lang = ConfigSelection(default="en", choices=TMDB_LANGUAGES)
config.plugins.xDreamy.epg_translate_cache_ttl = ConfigSelection(default="24", choices=[
    ("6", _("6 hours")), ("12", _("12 hours")), ("24", _("24 hours (default)")),
    ("72", _("3 days")), ("168", _("7 days")),
])
config.plugins.xDreamy.epg_translate_google_api_key = ConfigText(default="", fixed_size=False)
config.plugins.xDreamy.epg_translate_gemini_api_key = ConfigText(default="", fixed_size=False)
config.plugins.xDreamy.epg_translate_groq_api_key   = ConfigText(default="", fixed_size=False)
config.plugins.xDreamy.epg_translate_google_key_import = NoSave(ConfigYesNo(default=False))
config.plugins.xDreamy.epg_translate_gemini_key_import = NoSave(ConfigYesNo(default=False))
config.plugins.xDreamy.epg_translate_groq_key_import   = NoSave(ConfigYesNo(default=False))

# ─── Channel Server-Color settings (iChannelColor.py) ───────────────────────
config.plugins.xDreamy.channelcolor_enabled = ConfigYesNo(default=False)
config.plugins.xDreamy.color_local   = ConfigText(default="00FF00", fixed_size=False)   # local smartcard
config.plugins.xDreamy.color_emu     = ConfigText(default="FFFF00", fixed_size=False)   # local emulator (oscam/ncam)
config.plugins.xDreamy.color_cccam   = ConfigText(default="FFA500", fixed_size=False)   # cccam network sharing
config.plugins.xDreamy.color_network = ConfigText(default="FF4040", fixed_size=False)   # other network sharing

# ─── Centralized Debug Logging ──────────────────────────────────────────────
DEBUG_MODULES = [
    "iAccess", "iBase", "iBoxInfo", "iChannelColor", "iEPGTranslate",
    "iConverlibr", "iDownloadThread", "iStarX", "iBackdropX", "iParental",
    "iPosterX", "iInfoEvents", "iRendererBase", "plugin", "ListColorizer",
]
config.plugins.xDreamy.debug_master = ConfigYesNo(default=False)
for _dbg_name in DEBUG_MODULES:
    _attr = "dbg_%s" % _dbg_name
    if not hasattr(config.plugins.xDreamy, _attr):
        setattr(config.plugins.xDreamy, _attr, ConfigYesNo(default=False))


def _sync_plugin_log_level(configElement=None):
    try:
        enabled = bool(config.plugins.xDreamy.debug_master.value) and bool(config.plugins.xDreamy.dbg_plugin.value)
        logger.setLevel(logging.DEBUG if enabled else logging.WARNING)
    except Exception:
        pass


config.plugins.xDreamy.debug_master.addNotifier(_sync_plugin_log_level, initial_call=True)
config.plugins.xDreamy.dbg_plugin.addNotifier(_sync_plugin_log_level, initial_call=True)

# ============================================================================
#  REQUIREMENTS CHECK
# ============================================================================
config.plugins.xDreamy.deps_checked = ConfigYesNo(default=False)

REQUIRED_MODULES = [
    ("SQLite3 (metadata database)", "sqlite3", "python3-sqlite3"),
    ("Requests (poster/backdrop/EPG downloads)", "requests", "python3-requests"),
]
REQUIRED_BINARIES = [
    ("wget (used by some helper scripts)", "wget", "wget"),
]


def _module_available(name):
    try:
        __import__(name)
        return True
    except Exception:
        return False


def _binary_available(name):
    try:
        for d in os.environ.get("PATH", "/usr/bin:/bin").split(":"):
            if os.path.isfile(os.path.join(d, name)):
                return True
    except Exception:
        pass
    return False


def check_requirements():
    missing = []
    for display, module_name, pkg in REQUIRED_MODULES:
        if not _module_available(module_name):
            missing.append((display, pkg))
    for display, binary_name, pkg in REQUIRED_BINARIES:
        if not _binary_available(binary_name):
            missing.append((display, pkg))
    return missing


def _opkg_install(pkg):
    try:
        os.system("opkg update >/dev/null 2>&1")
        rc = os.system("opkg install %s >/tmp/xdreamy_opkg_%s.log 2>&1" % (pkg, pkg))
        return rc == 0
    except Exception as e:
        logger.error("opkg install %s failed: %s", pkg, e)
        return False


def install_missing_requirements(missing):
    results = []
    all_ok = True
    for display, pkg in missing:
        ok = _opkg_install(pkg)
        results.append((display, ok))
        if not ok:
            all_ok = False
    return all_ok, results


def run_requirements_flow(session, on_done):
    missing = check_requirements()

    if not missing:
        config.plugins.xDreamy.deps_checked.value = True
        config.plugins.xDreamy.deps_checked.save()
        session.openWithCallback(
            lambda *a: on_done(),
            MessageBox, _("All required components are installed."),
            MessageBox.TYPE_INFO, timeout=4)
        return

    names = "\n".join(" - %s" % d for d, _pkg in missing)
    msg = _("XDREAMY needs the following components, which aren't currently "
            "installed on this image:\n\n%s\n\nInstall them now?") % names

    def _after_confirm(confirmed):
        if not confirmed:
            session.openWithCallback(
                lambda *a: on_done(),
                MessageBox, _("Skipped. Some features (posters/backdrops/EPG "
                               "translation/metadata) may not work until these "
                               "are installed - you can re-check this any time "
                               "from the setup screen."),
                MessageBox.TYPE_WARNING, timeout=8)
            return

        def _do_install(*a):
            all_ok, results = install_missing_requirements(missing)
            config.plugins.xDreamy.deps_checked.value = True
            config.plugins.xDreamy.deps_checked.save()
            lines = ["%s %s" % (("[OK]" if ok else "[FAILED]"), display) for display, ok in results]
            summary = "\n".join(lines)
            if all_ok:
                result_msg = _("Installed successfully:\n\n%s\n\nA GUI restart is "
                               "recommended for the changes to take effect. "
                               "Restart now?") % summary

                def _after_restart_confirm(do_restart):
                    if do_restart:
                        try:
                            from enigma import quitMainloop
                            quitMainloop(3)
                            return
                        except Exception:
                            pass
                    on_done()

                session.openWithCallback(_after_restart_confirm, MessageBox, result_msg,
                                          MessageBox.TYPE_YESNO, timeout=15, default=True)
            else:
                result_msg = _("Some components failed to install (check this "
                               "image's package feed / internet connection, or "
                               "install manually via telnet):\n\n%s") % summary
                session.openWithCallback(lambda *a: on_done(), MessageBox, result_msg,
                                          MessageBox.TYPE_WARNING, timeout=12)

        session.openWithCallback(_do_install, MessageBox, _("Installing, please wait..."),
                                  MessageBox.TYPE_INFO, timeout=1)

    session.openWithCallback(_after_confirm, MessageBox, msg, MessageBox.TYPE_YESNO, default=True)

# Temporary / no-save action helpers
config.plugins.xDreamy.png            = NoSave(ConfigYesNo(default=False))
config.plugins.xDreamy.backup_action  = NoSave(ConfigYesNo(default=False))
config.plugins.xDreamy.restore_action = NoSave(ConfigYesNo(default=False))
config.plugins.xDreamy.check_requirements_action = NoSave(ConfigYesNo(default=False))

# Boot logos
config.plugins.xDreamy.bootlogos = ConfigOnOff(default=False)

# ─── SKIN GENERAL ────────────────────────────────────────────────────────────
config.plugins.xDreamy.head         = ConfigSelection(default='head', choices=[('head', _('Default'))])
config.plugins.xDreamy.skinSelector = ConfigSelection(default='base', choices=[('base', _('Default'))])
config.plugins.xDreamy.skinTemplate = ConfigSelection(default='templates', choices=[
    ('templates',  _('Default')),
    ('templates1', _('Style 1')),
    ('templates2', _('Style 2')),
    ('templates3', _('Style 3')),
    ('templates4', _('Style 4')),
    ('templates5', _('Style 5')),
    ('templates6', _('Style 6')),
    ('templates7', _('Style 7')),
    ('templates8', _('Style 8')),
])
config.plugins.xDreamy.KeysStyle = ConfigSelection(default='0', choices=[
    ('0', _('Default')),
    ('1',       _('Style 1')),
    ('2',       _('Style 2')),
    ('3',       _('Style 3')),
    ('4',       _('Style 4')),
    ('5',       _('Style 5')),
])

config.plugins.xDreamy.clockFormat = ConfigSelection(default="%H:%M", choices=[
    ("%H:%M",       _("23:59 – 24 hr")),
    ("%H:%M:%S",    _("23:59:33 – 24 hr with seconds")),
    ("%I:%M",       _("11:59 – 12 hr")),
    ("%I:%M %p",    _("11:59 PM – 12 hr with period")),
    ("%I:%M:%S %p", _("11:59:33 PM – 12 hr with seconds")),
])
config.plugins.xDreamy.clockMode = ConfigSelection(default='default', choices=[
    ('default', _('Default')),
    ('custom',  _('Custom (Color / size / font)')),
])
config.plugins.xDreamy.clockColor = ConfigSelection(
    default='Horus Light',
    choices=[(name, name) for name, _hex in _COLOR_NAMES]
)
config.plugins.xDreamy.clockSize = ConfigSelection(default='60', choices=[
    (str(s), '{} px'.format(s)) for s in (30, 40, 50, 60, 70, 80, 90, 100)
])
config.plugins.xDreamy.clockFont = ConfigSelection(default='Regular', choices=[
    ('Regular',            _('Regular (Default)')),
    ('Eurofighteroutital', _('Eurofighter Outital')),
])
config.plugins.xDreamy.dateFormat = ConfigSelection(default="%d %B %Y", choices=[
        # ─── ISO / Year‑first (best for sorting) ───
        ("%Y-%m-%d",     "2025-01-01"),
        ("%Y/%m/%d",     "2025/01/01"),
        ("%Y.%m.%d",     "2025.01.01"),
        ("%Y%m%d",       "20250101"),           # new – no separators

        # ─── European numeric (day‑month‑year) ───
        ("%d-%m-%Y",     "01-01-2025"),
        ("%d-%m-%y",     "01-01-25"),
        ("%d/%m/%Y",     "01/01/2025"),
        ("%d/%m/%y",     "01/01/25"),           # new
        ("%d.%m.%Y",     "01.01.2025"),
        ("%d.%m.%y",     "01.01.25"),
        ("%d %m %Y",     "01 01 2025"),
        ("%d %m %y",     "01 01 25"),           # new

        # ─── US numeric (month‑day‑year) ───
        ("%m/%d/%Y",     "01/01/2025"),
        ("%m/%d/%y",     "01/01/25"),           # new
        ("%m-%d-%Y",     "01-01-2025"),         # new
        ("%m-%d-%y",     "01-01-25"),           # new
        ("%m.%d.%Y",     "01.01.2025"),         # new
        ("%m.%d.%y",     "01.01.25"),           # new

        # ─── Short textual (abbreviated month) ───
        ("%d %b %Y",     "01 Jan 2025"),
        ("%d %b %y",     "01 Jan 25"),
        ("%b %d, %Y",    "Jan 01, 2025"),
        ("%b %d, %y",    "Jan 01, 25"),         # new
        ("%b %d %Y",     "Jan 01 2025"),        # new
        ("%d-%b-%Y",     "01-Jan-2025"),        # new
        ("%d-%b-%y",     "01-Jan-25"),          # new

        # ─── Full textual (full month name) ───
        ("%d %B %Y",     "01 January 2025"),
        ("%d %B %y",     "01 January 25"),
        ("%B %d, %Y",    "January 01, 2025"),
        ("%B %d, %y",    "January 01, 25"),     # new
        ("%B %d %Y",     "January 01 2025"),    # new
        ("%d-%B-%Y",     "01-January-2025"),    # new
        ("%d-%B-%y",     "01-January-25"),      # new

        # ─── With weekday (abbreviated) ───
        ("%a, %d %b %Y", "Mon, 01 Jan 2025"),
        ("%a, %d %b %y", "Mon, 01 Jan 25"),     # new
        ("%a, %B %d, %Y","Mon, January 01, 2025"),  # new
        ("%Y/%d/%m %a",  "2025/01/01 Wed"),     # your existing one

        # ─── With weekday (full) ───
        ("%A, %d %B %Y", "Monday, 01 January 2025"),
        ("%A, %d %B %y", "Monday, 01 January 25"),  # new
        ("%A, %B %d, %Y","Monday, January 01, 2025"),  # new
        ("%A %d %B %Y",  "Monday 01 January 2025"),
        ("%A, %d %m %Y", "Monday, 01 01 2025"),  # your existing one
        ("%Y/%d/%m %A",  "2025/01/01 Wednesday"), # your existing one

        # ─── Extra: RFC / sortable with time (just date part) ───
        ("%a, %d %b %Y %H:%M:%S", "Mon, 01 Jan 2025 00:00:00"),  # new (RFC‑style)
        ("%Y-%m-%dT%H:%M:%S",      "2025-01-01T00:00:00"),       # new (ISO‑8601)
])

# ─── ColorS ─────────────────────────────────────────────────────────────────
config.plugins.xDreamy.colorSelector = ConfigSelection(default='default-color', choices=[
    ('default-color',  _('Color Templates')),
    ('color23_Custom', _('Custom (pick each Color manually)')),
])
config.plugins.xDreamy.BasicColorTemplates = ConfigSelection(
    default='Horus',
    choices=[(k, _(k)) for k in sorted(TEMPLATES.keys())]
)
# OLD configs kept for migration (but hidden in UI)
config.plugins.xDreamy.BasicColor      = ConfigSelection(
    default='Horus Light',
    choices=[(name, name) for name, _ in _COLOR_NAMES]
)
config.plugins.xDreamy.WhiteColor      = ConfigSelection(
    default='Horus Light',
    choices=[(name, name) for name, _ in _COLOR_NAMES]
)
# NEW two-step configs for Title and Text colors
config.plugins.xDreamy.title_color_group = ConfigSelection(default="light", choices=[
    ("light", _("Light")),
    ("medium", _("Medium")),
])
config.plugins.xDreamy.title_color_value = ConfigSelection(default="Horus Light", choices=_COLOR_NAMES)
config.plugins.xDreamy.text_color_group = ConfigSelection(default="light", choices=[
    ("light", _("Light")),
    ("medium", _("Medium")),
])
config.plugins.xDreamy.text_color_value = ConfigSelection(default="Horus Light", choices=_COLOR_NAMES)

# Existing selection and background (remain as is)
config.plugins.xDreamy.SelectionColor  = ConfigSelection(
    default='Horus Med',
    choices=[(name, name) for name, _ in _SELECTION_NAMES]
)
config.plugins.xDreamy.BackgroundColor = ConfigSelection(
    default='Horus Dark',
    choices=[(name, name) for name, _ in _BACKGROUND_NAMES]
)
config.plugins.xDreamy.transparency = ConfigSelection(default="00", choices=[
    ("00", _("Opaque")),      ("05", _("5%")),   ("10", _("10%")),
    ("15", _("15%")),         ("20", _("20%")),  ("25", _("25%")),
    ("30", _("30%")),         ("35", _("35%")),  ("40", _("40%")),
    ("45", _("45%")),         ("50", _("50%")),  ("55", _("55%")),
    ("60", _("60%")),         ("65", _("65%")),  ("70", _("70%")),
    ("75", _("75%")),         ("80", _("80%")),  ("85", _("85%")),
    ("90", _("90%")),         ("95", _("95%")),  ("99", _("Fully transparent")),
])

# ─── FONTS ──────────────────────────────────────────────────────────────────
config.plugins.xDreamy.FontStyle = ConfigSelection(default='default', choices=[
    ('default', _('Default - font')),
    ('basic',   _('Custom font & scale')),
])
config.plugins.xDreamy.FontName  = ConfigSelection(default='Verdana.ttf', choices=[
    ('Verdana.ttf',               _('Verdana (Default)')),
    ('Andlso.ttf',                _('Andlso')),
    ('Beiruti-Regular.ttf',       _('Beiruti')),
    ('BonaNovaSC-Regular.ttf',    _('Bona Nova SC')),
    ('Dubai-REGULAR.ttf',         _('Dubai')),
    ('ElMessiri-Regular.ttf',     _('El Messiri')),
    ('Fustat-Regular.ttf',        _('Fustat')),
    ('Lucida.ttf',                _('Lucida')),
    ('Majalla.ttf',               _('Majalla')),
    ('Mvboli.ttf',                _('MV Boli')),
    ('NaskhArabic-Regular.ttf',   _('Naskh Arabic')),
    ('Nmsbd.ttf',                 _('Nmsbd')),
    ('PlexSansArabic-Regular.ttf',_('Plex Sans Arabic')),
    ('ReadexPro-Regular.ttf',     _('Readex Pro')),
    ('Rubik-Regular.ttf',         _('Rubik')),
    ('Tajawal-Regular.ttf',       _('Tajawal')),
    ('Zain-Regular.ttf',          _('Zain')),
])
config.plugins.xDreamy.FontScale = ConfigSelection(default="100", choices=[
    ('75',  _('-25%')), ('80',  _('-20%')), ('85',  _('-15%')),
    ('90',  _('-10%')), ('95',  _('-5%')),  ('100', _('Default (100%)')),
    ('105', _('+5%')),  ('110', _('+10%')), ('115', _('+15%')),
    ('120', _('+20%')), ('125', _('+25%')), ('130', _('+30%')),
])

# ─── INFOBAR ─────────────────────────────────────────────────────────────────
config.plugins.xDreamy.InfobarStyle = ConfigSelection(default='InfoBar-1P', choices=[
    ('InfoBar-1P',   _('Default – 1 Poster')),
    ('InfoBar-2P',   _('InfoBar – 2 Posters')),
    ('InfoBar-NP',   _('InfoBar 1 – No Poster')),
    ('InfoBar2-NP',  _('InfoBar 2 – No Poster')),
    ('InfoBar2-1P',  _('InfoBar 2 – 1 Poster')),
    ('InfoBar2-2P',  _('InfoBar 2 – 2 Posters')),
    ('InfoBar2-1PW', _('InfoBar 2 – 1 Poster Wide')),
    ('InfoBar-HMF',  _('Custom – Header / Middle / Footer')),
])
config.plugins.xDreamy.InfobarH = ConfigSelection(default='No Header', choices=[
    ('No Header',  _('Default – No Header')),
    ('InfoBar H0', _('H00 – Clock & Date')),
    ('InfoBar H1', _('H01 – EMU / Network / Card')),
    ('InfoBar H2', _('H02 – Three-day Weather')),
    ('InfoBar H3', _('H03 – One Row Header')),
    ('InfoBar H4', _('H04 – Clock, Date & Weather')),
])
config.plugins.xDreamy.InfobarM = ConfigSelection(default='No Middle', choices=[
    ('No Middle',  _('Default – No Middle')),
    ('InfoBar M0', _('M00')), ('InfoBar M1', _('M01')),
    ('InfoBar M2', _('M02')), ('InfoBar M3', _('M03')),
    ('InfoBar M4', _('M04')),
])
config.plugins.xDreamy.InfobarF = ConfigSelection(default='No Footer', choices=[
    ('No Footer',  _('Default – No Footer')),
    ('InfoBar F0', _('F00')), ('InfoBar F1', _('F01')),
    ('InfoBar F2', _('F02')), ('InfoBar F3', _('F03')),
    ('InfoBar F4', _('F04')), ('InfoBar F5', _('F05')),
    ('InfoBar F6', _('F06')),
])

# ─── SECOND INFOBAR ──────────────────────────────────────────────────────────
config.plugins.xDreamy.SecondInfobar = ConfigSelection(default='SecondInfobar-2P', choices=[
    ('SecondInfobar-2P',   _('Default – 2 Posters')),
    ('SecondInfobar-NP',   _('No Poster')),
    ('SecondInfobar-2PN',  _('2 Posters (N)')),
    ('SecondInfobar-2PN2', _('2 Posters (N2)')),
    ('SecondInfobar-HF',   _('Custom – Header / Footer')),
])
config.plugins.xDreamy.SecondInfobarH = ConfigSelection(default='SecondInfobarH01', choices=[
    ('SecondInfobarH01', _('Default')),
    ('SecondInfobarH02', _('S1 – 2E – 2P')),
    ('SecondInfobarH03', _('S2 – 2E – No Poster')),
    ('SecondInfobarH04', _('S2 – 2E – 2P')),
    ('SecondInfobarH05', _('H – 2E – No Poster')),
    ('SecondInfobarH06', _('H – 2E – 2P')),
    ('SecondInfobarH07', _('V – 2E – No Poster')),
    ('SecondInfobarH08', _('V – 2E – 2P')),
    ('SecondInfobarH09', _('V – 2E – 2 Backdrop')),
])
config.plugins.xDreamy.SecondInfobarF = ConfigSelection(default='SecondInfobarF', choices=[
    ('SecondInfobarF',  _('Default')),
    ('SecondInfobarF1', _('Footer 1')),
    ('SecondInfobarF2', _('Footer 2')),
])

# ─── CHANNEL LIST ────────────────────────────────────────────────────────────
config.plugins.xDreamy.ChannSelector = ConfigSelection(default='C00-MTV-5P', choices=[
    ('C00-MTV-5P',  _('Default – 5 Posters')),
    ('C0-LMTV-1P',  _('C00 – 1 Poster')),
    ('C01-MTV-1P',  _('C01 – 1 Poster')),
    ('C02-MTV-2P',  _('C02 – 2 Posters')),
    ('C03-MTV-7P',  _('C03 – 7 Posters')),
    ('C04-MTV-13P', _('C04 – 13 Posters')),
    ('C05-MTV-NP',  _('C05 – No Poster')),
    ('C06-MTV-NP',  _('C06 – No Poster (Alt)')),
    ('C07-MTV-1P',  _('C07 – 1 Poster (Alt)')),
    ('C08-NP',      _('C08 – No Poster')),
    ('C09-NP',      _('C09 – No Poster (Alt)')),
    ('C10-1P',      _('C10 – 1 Poster')),
    ('C11-2P',      _('C11 – 2 Posters')),
    ('C12-2P-NBG',  _('C12 – 2 Posters (No BG)')),
    ('C13-7P',      _('C13 – 7 Posters')),
    ('C14-13P',     _('C14 – 13 Posters')),
    ('C15-14P',     _('C15 – 14 Posters')),
])
config.plugins.xDreamy.ChannSelectorGrid = ConfigSelection(default='G01-MTV-NP', choices=[
    ('G01-MTV-NP',       _('G01 – MTV No Poster')),
    ('G02-1Raw-1P',      _('G02 – 1 Row 1 Poster')),
    ('G03-1Raw-2P',      _('G03 – 1 Row 2 Posters')),
    ('G04-1Raw-1P-Top',  _('G04 – 1 Row 1 Poster (Top)')),
    ('G05-Color-2P',     _('G05 – Colored 2 Posters')),
    ('G06-Background-NP',_('G06 – Background No Poster')),
    ('G07-Transparent-NP',_('G07 – Transparent No Poster')),
    ('G08-Color-2P',     _('G08 – Colored 2 Posters (Alt)')),
    ('G09-Backdrop',     _('G09 – Backdrop')),
])
config.plugins.xDreamy.ChannelListBackground = ConfigSelection(default='Black', choices=[
    ('Black', _('Default – Black')), ('Color', _('Skin Color')), ('Gradient Color', _('Gradient Color'))] +
    [('Background{}'.format(i), _('Background {}'.format(i))) for i in range(17)]
)

# ─── OTHER SCREENS ───────────────────────────────────────────────────────────
config.plugins.xDreamy.EventView = ConfigSelection(default='EventView', choices=[
    ('EventView',  _('Default')),
    ('EventView1', _('Event View 1 – Backdrop')),
    ('EventView2', _('Event View 2 – Big')),
    ('EventView3', _('Event View 3 – 7 Posters')),
    ('EventView4', _('Event View 4 – 11P Full Screen')),
    ('EventView5', _('Event View 5 – 1P Full Screen')),
])
config.plugins.xDreamy.PluginBrowser = ConfigSelection(default='PluginBrowser', choices=[
    ('PluginBrowser',      _('Default')),
    ('PluginBrowser1',     _('Plugin Browser 1')),
    ('PluginBrowser2',     _('Plugin Browser 2')),
    ('PluginBrowser3',     _('Plugin Browser 3')),
    ('PluginBrowser4',     _('Plugin Browser 4')),
    ('PluginBrowser4GHT',  _('Plugin Browser 4 – Grid Top')),
    ('PluginBrowser4GHM',  _('Plugin Browser 4 – Grid Middle')),
    ('PluginBrowser4GHB',  _('Plugin Browser 4 – Grid Bottom')),
    ('PluginBrowser5GVL',  _('Plugin Browser 5 – Grid Left')),
    ('PluginBrowser5GVR',  _('Plugin Browser 5 – Grid Right')),
])
config.plugins.xDreamy.VolumeBar = ConfigSelection(default='volume1', choices=[
    ('volume{}'.format(i), _('Volume Bar {}'.format(i))) for i in range(1, 6)
])
config.plugins.xDreamy.VirtualKeyboard = ConfigSelection(default='VirtualKeyBoard', choices=[
    ('VirtualKeyBoard',  _('Default – Skin Color')),
    ('VirtualKeyBoard1', _('Black Background')),
    ('VirtualKeyBoard2', _('Color Background')),
])
config.plugins.xDreamy.NewVirtualKeyboard = ConfigSelection(default='NewVirtualKeyBoard0', choices=[
    ('NewVirtualKeyBoard{}'.format(i), _('New VKB {}'.format(i))) for i in range(5)
])
config.plugins.xDreamy.HistoryZapSelector = ConfigSelection(default='HistoryZapSelector0', choices=[
    ('HistoryZapSelector0', _('Default')),
    ('HistoryZapSelector1', _('History Zap 1 – No Poster')),
    ('HistoryZapSelector2', _('History Zap 2 – No Poster')),
    ('HistoryZapSelector3', _('History Zap 3 – No Poster')),
])
config.plugins.xDreamy.EPGMultiSelection = ConfigSelection(default='EPGMultiSelection', choices=[
    ('EPGMultiSelection',  _('Default')),
    ('EPGMultiSelection1', _('EPG Multi Selection 1')),
])
config.plugins.xDreamy.E2Player = ConfigSelection(default='E2Player', choices=[
    ('E2Player',  _('Default')),
    ('E2Player1', _('E2 Player 1')),
    ('E2Player2', _('E2 Player 2')),
])
config.plugins.xDreamy.EnhancedMovieCenter = ConfigSelection(default='EnhancedMovieCenter', choices=[
    ('EnhancedMovieCenter',  _('Default')),
    ('EnhancedMovieCenter1', _('Enhanced Movie Center 1')),
    ('EnhancedMovieCenter2', _('Enhanced Movie Center 2')),
    ('EnhancedMovieCenter3', _('Enhanced Movie Center 3')),
])
config.plugins.xDreamy.TurnOff = ConfigSelection(default='Background0', choices=[
    ('Background{}'.format(i), _('Background {}'.format(i))) for i in range(17)
])

# ─── DATA SOURCES ─────────────────────────────────────────────────────────────
config.plugins.xDreamy.WeatherSource = ConfigSelection(default='OAWeatherPlugin', choices=[
    ('OAWeatherPlugin',  _('Default -OA Weather')),
    ('MSNWeatherPlugin', _('MSN Weather')),
])

config.plugins.xDreamy.SubtitlesClock = ConfigSelection(default='SC', choices=[
    ('SC',  _('Default- Disabled')),
    ('SC1', _('Bottom Right')),
    ('SC2', _('Bottom Left')),
    ('SC3', _('Top Right')),
    ('SC4', _('Top Left')),
])

config.plugins.xDreamy.RatingStars = ConfigSelection(default='NRS', choices=[
    ('NRS', _('Default -Disabled')),
    ('RS',  _('Enabled')),
])

config.plugins.xDreamy.channelTextMode = ConfigSelection(default='default', choices=[
    ('default', _('Default')),
    ('custom',  _('Custom')),
])
# MODIFIED: replaced _COLOR_NAMES with _SELECTION_NAMES for channel text colors
# These are kept for compatibility, but we now use group+value configs when custom is on.
config.plugins.xDreamy.channelNameColor = ConfigSelection(default='white', choices=[
    ('white', _('Default - White'))] + [(name, name) for name, _hex in _SELECTION_NAMES]
)
config.plugins.xDreamy.channelNameFontSize = ConfigSelection(default='30', choices=[
    (str(s), str(s)) for s in range(10, 51, 2)
])
config.plugins.xDreamy.eventDescColor = ConfigSelection(default='white', choices=[
    ('white', _('White (Default)'))] + [(name, name) for name, _hex in _SELECTION_NAMES]
)
config.plugins.xDreamy.eventDescFontSize = ConfigSelection(default='30', choices=[
    (str(s), str(s)) for s in range(10, 51, 2)
])
config.plugins.xDreamy.progressBarColor = ConfigSelection(default='white', choices=[
    ('white', _('White (Default)'))] + [(name, name) for name, _hex in _SELECTION_NAMES]
)

# ─── NEW two-step configs for Menu and Channel custom text colors ─────────
# Menu text (unselected)
config.plugins.xDreamy.menu_text_color_group = ConfigSelection(default="light", choices=[
    ("light", _("Light")),
    ("medium", _("Medium")),
])
config.plugins.xDreamy.menu_text_color_value = ConfigSelection(default="Horus Light", choices=_COLOR_NAMES)
# Menu text (selected)
config.plugins.xDreamy.menu_text_selected_color_group = ConfigSelection(default="light", choices=[
    ("light", _("Light")),
    ("medium", _("Medium")),
])
config.plugins.xDreamy.menu_text_selected_color_value = ConfigSelection(default="Horus Light", choices=_COLOR_NAMES)
# Channel name
config.plugins.xDreamy.channel_name_color_group = ConfigSelection(default="light", choices=[
    ("light", _("Light")),
    ("medium", _("Medium")),
])
config.plugins.xDreamy.channel_name_color_value = ConfigSelection(default="Horus Light", choices=_COLOR_NAMES)
# Event description
config.plugins.xDreamy.event_desc_color_group = ConfigSelection(default="light", choices=[
    ("light", _("Light")),
    ("medium", _("Medium")),
])
config.plugins.xDreamy.event_desc_color_value = ConfigSelection(default="Horus Light", choices=_COLOR_NAMES)

# ─── MENU (unchanged) ──────────────────────────────────────────────────────
config.plugins.xDreamy.menuTextMode = ConfigSelection(default='default', choices=[
    ('default', _('Default')),
    ('custom',  _('Custom')),
])
# MODIFIED: replaced _COLOR_NAMES with _SELECTION_NAMES for menu text colors
config.plugins.xDreamy.menuTextColor = ConfigSelection(default='grey', choices=[
    ('grey', _('Grey (Default)'))] + [(name, name) for name, _hex in _SELECTION_NAMES]
)
config.plugins.xDreamy.menuTextSelectedColor = ConfigSelection(default='white', choices=[
    ('white', _('White (Default)'))] + [(name, name) for name, _hex in _SELECTION_NAMES]
)
config.plugins.xDreamy.menuBackgroundSelectedColor = ConfigSelection(default='bluette', choices=[
    ('bluette', _('Bluette (Default)'))] + [(name, name) for name, _hex in _SELECTION_NAMES]
)

config.plugins.xDreamy.crypt = ConfigSelection(default='Cryptoname', choices=[
    ('Cryptoname', _('Default - Crypto Name')),
    ('Cryptobar',  _('Crypto Bar')),
])

# ─── PLUGIN INSTALLER ENTRIES ────────────────────────────────────────────────
_PLUGIN_IDS = [
    "ajpanel", "linuxsatpanel", "CiefpPlugins", "smartpanel", "magicpanel",
    "keyadder", "xklass", "youtube", "e2iplayer", "ipaudiopro", "transmission",
    "EPGGrabber", "subssupport", "subssupportpro", "historyzapselector",
    "newvirtualkeyboard", "raedquicksignal",
]
for _pid in _PLUGIN_IDS:
    setattr(config.plugins.xDreamy, "install_{}".format(_pid),
            NoSave(ConfigYesNo(default=False)))


# ─────────────────────────────────────────────────────────────────────────────
#  SETTINGS APPLIED AT SAVE TIME
# ─────────────────────────────────────────────────────────────────────────────

def _fast_skin_reload_supported():
    try:
        if not (hasattr(config.usage, 'fastSkinReload')
                and hasattr(config.usage.fastSkinReload, 'value')):
            return False
        from skin import reloadSkins
        return True
    except Exception:
        return False


def _fast_skin_reload_active():
    return _fast_skin_reload_supported() and bool(config.usage.fastSkinReload.value)


def apply_date_format():
    new_fmt = config.plugins.xDreamy.dateFormat.value
    head_file = os.path.join(
        SAMPLE_PATH,
        'head-{}.xml'.format(config.plugins.xDreamy.head.value)
    )
    if not os.path.isfile(head_file):
        logger.warning("apply_date_format: head file not found: %s", head_file)
        return

    fmt_pattern = re.compile(r'(<convert type="ClockToText">Format)[: ]([^<]*)(</convert>)')

    def _swap(body):
        return fmt_pattern.sub(
            lambda m: '{}:{}{}'.format(m.group(1), new_fmt, m.group(3)),
            body
        )

    changed = _patch_screen_block(head_file, 'p800_Date', _swap)
    logger.info("apply_date_format: set %r in %s changed=%s",
                new_fmt, os.path.basename(head_file), changed)


def _patch_screen_block(file_path, screen_name, transform_fn):
    try:
        with open(file_path, 'r') as fh:
            content = fh.read()
        pattern = re.compile(
            r'(<screen\s+name="{}"[^>]*>)(.*?)(</screen>)'.format(re.escape(screen_name)),
            re.DOTALL
        )
        m = pattern.search(content)
        if not m:
            logger.warning("_patch_screen_block: screen %r not found in %s", screen_name, file_path)
            return False
        open_tag, body, close_tag = m.group(1), m.group(2), m.group(3)
        new_body = transform_fn(body)
        if new_body == body:
            logger.warning("_patch_screen_block: %r found but transform_fn made no change", screen_name)
            return True
        new_content = content[:m.start()] + open_tag + new_body + close_tag + content[m.end():]
        with open(file_path, 'w') as fh:
            fh.write(new_content)
        return True
    except Exception as exc:
        logger.error("_patch_screen_block(%s, %s): %s", file_path, screen_name, exc)
        return False


def _resolve_named_color(value, choice_list=_COLOR_NAMES, literal_default=None):
    literal_names = ('white', 'grey', 'bluette', 'header', 'ltbluette', 'black', 'red', 'yellow')
    if value in literal_names:
        return value
    return _get_hex_from_name(value, choice_list)


def apply_keys_style():
    head_file = os.path.join(SAMPLE_PATH, 'head-{}.xml'.format(config.plugins.xDreamy.head.value))
    if not os.path.isfile(head_file):
        logger.warning("apply_keys_style: head file not found: %s", head_file)
        return

    style = config.plugins.xDreamy.KeysStyle.value

    def _swap(body):
        for color in ('red', 'green', 'yellow', 'blue'):
            target = '{}panel.png'.format(color) if style == '0' else '{}{}.png'.format(color, style)
            body = re.sub(
                r'buttons/{}(?:panel|\d+)\.png'.format(color),
                'buttons/' + target,
                body
            )
        return body

    changed = False
    for screen_name in ('m_RGYB', 's_RGYB', 's_RGYB1', 'SI_RGYB'):
        changed = _patch_screen_block(head_file, screen_name, _swap) or changed
    logger.info("apply_keys_style: style=%s changed=%s", style, changed)


def apply_clock_format():
    head_file = os.path.join(SAMPLE_PATH, 'head-{}.xml'.format(config.plugins.xDreamy.head.value))
    if not os.path.isfile(head_file):
        logger.warning("apply_clock_format: head file not found: %s", head_file)
        return

    fmt_value = config.plugins.xDreamy.clockFormat.value
    custom    = (config.plugins.xDreamy.clockMode.value == 'custom')

    ORIGINAL_COLOR = 'ltbluette'
    ORIGINAL_SIZES = {
        'BarClock_Template':   '60',
        'CHLClock_Template':   '70',
        'IBAR1Clock_Template': '90',
        'IBAR2Clock_Template': '60',
    }

    if custom:
        color_val = _resolve_named_color(config.plugins.xDreamy.clockColor.value)
        font_val  = config.plugins.xDreamy.clockFont.value or 'Regular'
        size_val  = config.plugins.xDreamy.clockSize.value
    else:
        color_val = ORIGINAL_COLOR
        font_val  = 'Regular'
        size_val  = None

    fmt_pattern = re.compile(r'(<convert type="ClockToText">Format)[: ]([^<]*)(</convert>)')

    def _make_swap(screen_name):
        sz = size_val or ORIGINAL_SIZES.get(screen_name, '60')

        def _swap(body):
            body = fmt_pattern.sub(
                lambda m: '{}:{}{}'.format(m.group(1), fmt_value, m.group(3)),
                body
            )
            body = re.sub(r'foregroundColor="[^"]*"',
                           'foregroundColor="{}"'.format(color_val), body, count=1)
            body = re.sub(r'font="[^"]*"',
                           'font="{};{}"'.format(font_val, sz), body, count=1)
            return body
        return _swap

    changed = False
    for screen_name in ('BarClock_Template', 'CHLClock_Template',
                        'IBAR1Clock_Template', 'IBAR2Clock_Template'):
        changed = _patch_screen_block(head_file, screen_name, _make_swap(screen_name)) or changed
    logger.info("apply_clock_format: fmt=%s custom=%s changed=%s", fmt_value, custom, changed)


def apply_channel_text_style():
    head_file = os.path.join(SAMPLE_PATH, 'head-{}.xml'.format(config.plugins.xDreamy.head.value))
    if not os.path.isfile(head_file):
        logger.warning("apply_channel_text_style: head file not found: %s", head_file)
        return

    custom = (config.plugins.xDreamy.channelTextMode.value == 'custom')
    if custom:
        # Use new group+value configs
        name_group = config.plugins.xDreamy.channel_name_color_group.value
        name_val = config.plugins.xDreamy.channel_name_color_value.value
        if name_group == "light":
            name_color = _get_hex_from_name(name_val, _COLOR_NAMES)
        else:
            name_color = _get_hex_from_name(name_val, _SELECTION_NAMES)

        desc_group = config.plugins.xDreamy.event_desc_color_group.value
        desc_val = config.plugins.xDreamy.event_desc_color_value.value
        if desc_group == "light":
            desc_color = _get_hex_from_name(desc_val, _COLOR_NAMES)
        else:
            desc_color = _get_hex_from_name(desc_val, _SELECTION_NAMES)

        # Progress bar still uses the old direct medium selection
        bar_color = _resolve_named_color(config.plugins.xDreamy.progressBarColor.value, choice_list=_SELECTION_NAMES)
        name_size = config.plugins.xDreamy.channelNameFontSize.value
        desc_size = config.plugins.xDreamy.eventDescFontSize.value
    else:
        name_color = '#F4E8F8'
        name_size  = '30'
        desc_color = '#F5ECD6'
        desc_size  = '20'
        bar_color  = 'ltbluette'

    def _swap(body):
        body = re.sub(r'serviceNameFont="[^"]*"',
                       'serviceNameFont="Regular;{}"'.format(name_size), body)
        body = re.sub(r'serviceInfoFont="[^"]*"',
                       'serviceInfoFont="Regular;{}"'.format(desc_size), body)
        body = re.sub(r'(?<!Selected)foregroundColor="[^"]*"',
                       'foregroundColor="{}"'.format(name_color), body, count=1)
        body = re.sub(r'colorServiceDescription="[^"]*"',
                       'colorServiceDescription="{}"'.format(desc_color), body, count=1)
        body = re.sub(r'scrollbarForegroundColor="[^"]*"',
                       'scrollbarForegroundColor="{}"'.format(bar_color), body, count=1)
        return body

    changed = False
    for screen_name in ('CLC', 'CLC1'):
        changed = _patch_screen_block(head_file, screen_name, _swap) or changed
    logger.info("apply_channel_text_style: custom=%s changed=%s", custom, changed)


def apply_menu_text_style():
    head_file = os.path.join(SAMPLE_PATH, 'head-{}.xml'.format(config.plugins.xDreamy.head.value))
    if not os.path.isfile(head_file):
        logger.warning("apply_menu_text_style: head file not found: %s", head_file)
        return

    custom = (config.plugins.xDreamy.menuTextMode.value == 'custom')
    if custom:
        # Use new group+value configs for text and selected text
        text_group = config.plugins.xDreamy.menu_text_color_group.value
        text_val = config.plugins.xDreamy.menu_text_color_value.value
        if text_group == "light":
            text_color = _get_hex_from_name(text_val, _COLOR_NAMES)
        else:
            text_color = _get_hex_from_name(text_val, _SELECTION_NAMES)

        sel_group = config.plugins.xDreamy.menu_text_selected_color_group.value
        sel_val = config.plugins.xDreamy.menu_text_selected_color_value.value
        if sel_group == "light":
            text_sel_color = _get_hex_from_name(sel_val, _COLOR_NAMES)
        else:
            text_sel_color = _get_hex_from_name(sel_val, _SELECTION_NAMES)

        # Selected background still uses the old direct medium selection
        bg_sel_color = _resolve_named_color(config.plugins.xDreamy.menuBackgroundSelectedColor.value,
                                            choice_list=_SELECTION_NAMES)
    else:
        text_color     = 'grey'
        text_sel_color = 'white'
        bg_sel_color   = 'bluette'

    try:
        scale_pct = int(config.plugins.xDreamy.FontScale.value)
    except Exception:
        scale_pct = 100
    base_font_size = 38
    new_font_size = max(10, int(base_font_size * scale_pct / 100.0))

    def _swap(body):
        widget_pattern = re.compile(r'(<widget\s+source="menu"[^>]*>)', re.DOTALL)
        m = widget_pattern.search(body)
        if not m:
            logger.warning("apply_menu_text_style: widget source='menu' not found in MenuTemplate")
            return body

        tag = m.group(1)
        new_tag = tag

        def set_attr(tag_str, attr_name, new_value):
            pattern = re.compile(r'{}\s*=\s*["\']([^"\']*)["\']'.format(re.escape(attr_name)))
            if pattern.search(tag_str):
                return pattern.sub(r'{}="{}"'.format(attr_name, new_value), tag_str)
            else:
                return tag_str.replace('>', ' {}="{}">'.format(attr_name, new_value), 1)

        new_tag = set_attr(new_tag, 'foregroundColor', text_color)
        new_tag = set_attr(new_tag, 'foregroundColorSelected', text_sel_color)
        new_tag = set_attr(new_tag, 'backgroundColorSelected', bg_sel_color)

        convert_pattern = re.compile(r'(<convert[^>]*>)(.*?)(</convert>)', re.DOTALL)
        convert_m = convert_pattern.search(body, m.end())
        if convert_m:
            convert_open, convert_body, convert_close = convert_m.group(1), convert_m.group(2), convert_m.group(3)
            convert_body = re.sub(r'gFont\("Regular",\s*\d+\)',
                                  'gFont("Regular", {})'.format(new_font_size),
                                  convert_body)
            new_convert = convert_open + convert_body + convert_close
            body = body[:convert_m.start()] + new_convert + body[convert_m.end():]

        if new_tag != tag:
            body = body[:m.start(1)] + new_tag + body[m.end(1):]
            logger.info("apply_menu_text_style: widget tag updated – new colors: fg=%s, fg_sel=%s, bg_sel=%s",
                        text_color, text_sel_color, bg_sel_color)
        else:
            logger.warning("apply_menu_text_style: widget tag unchanged – check attribute names")

        return body

    changed = _patch_screen_block(head_file, 'MenuTemplate', _swap)
    logger.info("apply_menu_text_style: custom=%s changed=%s", custom, changed)


def apply_colors_to_file(file_path, ltbluette=None, white=None,
                          bluette=None, header=None):
    transparency = config.plugins.xDreamy.transparency.value
    if ltbluette:
        ltbluette = _get_hex_from_name(ltbluette, _COLOR_NAMES)
    if white:
        white     = _get_hex_from_name(white,     _COLOR_NAMES)
    if bluette:
        bluette   = _get_hex_from_name(bluette,   _SELECTION_NAMES)
    if header:
        header    = _get_hex_from_name(header,    _BACKGROUND_NAMES)
    try:
        with open(file_path, 'r') as fh:
            lines = fh.readlines()
        out = []
        for line in lines:
            if ltbluette and '<color name="ltbluette"' in line:
                line = '<color name="ltbluette" value="{}"/>\n'.format(ltbluette)
            elif white and '<color name="white"' in line:
                line = '<color name="white" value="{}"/>\n'.format(white)
            elif bluette and '<color name="bluette"' in line:
                line = '<color name="bluette" value="{}"/>\n'.format(bluette)
            elif header and '<color name="header"' in line:
                if header.startswith('#') and len(header) == 9:
                    header_patched = '#{}{}'.format(transparency, header[3:])
                else:
                    header_patched = header
                line = '<color name="header" value="{}"/>\n'.format(header_patched)
            out.append(line)
        with open(file_path, 'w') as fh:
            fh.writelines(out)
        os.system("sync")
    except Exception as exc:
        logger.error("apply_colors_to_file error: %s", exc)


def apply_template(template_name):
    if template_name not in TEMPLATES:
        logger.warning("apply_template: unknown template %r", template_name)
        return
    head_file = os.path.join(SAMPLE_PATH, 'head-{}.xml'.format(config.plugins.xDreamy.head.value))
    lt, bl, hd = TEMPLATES[template_name]
    apply_colors_to_file(head_file, ltbluette=lt, bluette=bl, header=hd)


def apply_custom_colors():
    head_file = os.path.join(SAMPLE_PATH, 'head-{}.xml'.format(config.plugins.xDreamy.head.value))
    # Determine title color based on group and value
    title_group = config.plugins.xDreamy.title_color_group.value
    title_value = config.plugins.xDreamy.title_color_value.value
    if title_group == "light":
        title_hex = _get_hex_from_name(title_value, _COLOR_NAMES)
    else:
        title_hex = _get_hex_from_name(title_value, _SELECTION_NAMES)

    text_group = config.plugins.xDreamy.text_color_group.value
    text_value = config.plugins.xDreamy.text_color_value.value
    if text_group == "light":
        text_hex = _get_hex_from_name(text_value, _COLOR_NAMES)
    else:
        text_hex = _get_hex_from_name(text_value, _SELECTION_NAMES)

    # Selection and background remain as before (medium and dark)
    selection_hex = _get_hex_from_name(config.plugins.xDreamy.SelectionColor.value, _SELECTION_NAMES)
    bg_hex = _get_hex_from_name(config.plugins.xDreamy.BackgroundColor.value, _BACKGROUND_NAMES)

    apply_colors_to_file(
        head_file,
        ltbluette=title_hex,    # title color
        white=text_hex,         # text color
        bluette=selection_hex,  # selection
        header=bg_hex           # background
    )


def update_font_settings(font_name, font_scale):
    font_file = os.path.join(SAMPLE_PATH, 'head-{}.xml'.format(config.plugins.xDreamy.head.value))
    try:
        with open(font_file, 'r') as fh:
            lines = fh.readlines()
        out = []
        for line in lines:
            if '<font name="Regular"' in line:
                line = (
                    '<font name="Regular" '
                    'filename="/usr/share/enigma2/xDreamy/fonts/{fn}" '
                    'scale="{sc}" />\n'
                ).format(fn=font_name, sc=font_scale)
            out.append(line)
        with open(font_file, 'w') as fh:
            fh.writelines(out)
        os.system("sync")
    except Exception as exc:
        logger.error("update_font_settings error: %s", exc)


def apply_renderer_config():
    try:
        apply_plugin_config = _import_iconverlibr().apply_plugin_config

        class _Wrap(object): pass
        def _attr(val):
            o = _Wrap(); o.value = val; return o

        cfg = _Wrap()
        cfg.posterx_enabled     = _attr(config.plugins.xDreamy.posterx_enabled.value)
        cfg.backdropx_enabled   = _attr(config.plugins.xDreamy.backdropx_enabled.value)
        cfg.logox_enabled       = _attr(config.plugins.xDreamy.logox_enabled.value)
        cfg.worker_threads      = _attr(config.plugins.xDreamy.worker_threads.value)
        cfg.tmdb_api_key        = _attr(config.plugins.xDreamy.tmdb_api_key.value)
        cfg.tmdb_language       = _attr(config.plugins.xDreamy.tmdb_language.value)
        cfg.storage_mode        = _attr(config.plugins.xDreamy.storage_mode.value)
        cfg.storage_custom_path = _attr(config.plugins.xDreamy.storage_custom_path.value)
        apply_plugin_config(cfg)
        logger.info("apply_renderer_config: done")
    except Exception as e:
        logger.warning("apply_renderer_config: could not reach iConverlibr (%s)", e)


# Notifiers – tmdb_enabled is NOT included (UI only)
config.plugins.xDreamy.tmdb_language.addNotifier(      lambda _: apply_renderer_config(), initial_call=True)
config.plugins.xDreamy.posterx_enabled.addNotifier(    lambda _: apply_renderer_config(), initial_call=True)
config.plugins.xDreamy.backdropx_enabled.addNotifier(  lambda _: apply_renderer_config(), initial_call=True)
config.plugins.xDreamy.logox_enabled.addNotifier(      lambda _: apply_renderer_config(), initial_call=True)
config.plugins.xDreamy.storage_mode.addNotifier(       lambda _: apply_renderer_config(), initial_call=True)
config.plugins.xDreamy.storage_custom_path.addNotifier(lambda _: apply_renderer_config(), initial_call=True)
config.plugins.xDreamy.worker_threads.addNotifier(     lambda _: apply_renderer_config())
config.plugins.xDreamy.tmdb_api_key.addNotifier(       lambda _: apply_renderer_config())

# Notifiers to update choices of title_color_value and text_color_value when group changes
def _update_title_color_choices(*args):
    group = config.plugins.xDreamy.title_color_group.value
    if group == "light":
        choices = _COLOR_NAMES
        default = "Horus Light"
    else:
        choices = _SELECTION_NAMES
        default = "Horus Med"
    # Ensure the current value is valid; if not, set to default
    current = config.plugins.xDreamy.title_color_value.value
    valid = any(d[0] == current for d in choices)
    if not valid:
        config.plugins.xDreamy.title_color_value.value = default
    config.plugins.xDreamy.title_color_value.setChoices(choices)

def _update_text_color_choices(*args):
    group = config.plugins.xDreamy.text_color_group.value
    if group == "light":
        choices = _COLOR_NAMES
        default = "Horus Light"
    else:
        choices = _SELECTION_NAMES
        default = "Horus Med"
    current = config.plugins.xDreamy.text_color_value.value
    valid = any(d[0] == current for d in choices)
    if not valid:
        config.plugins.xDreamy.text_color_value.value = default
    config.plugins.xDreamy.text_color_value.setChoices(choices)

config.plugins.xDreamy.title_color_group.addNotifier(_update_title_color_choices, initial_call=True)
config.plugins.xDreamy.text_color_group.addNotifier(_update_text_color_choices, initial_call=True)

# ─── Notifiers for new menu/channel group+value choices ───────────────────
def _update_menu_text_color_choices(*args):
    group = config.plugins.xDreamy.menu_text_color_group.value
    if group == "light":
        choices = _COLOR_NAMES
        default = "Horus Light"
    else:
        choices = _SELECTION_NAMES
        default = "Horus Med"
    current = config.plugins.xDreamy.menu_text_color_value.value
    valid = any(d[0] == current for d in choices)
    if not valid:
        config.plugins.xDreamy.menu_text_color_value.value = default
    config.plugins.xDreamy.menu_text_color_value.setChoices(choices)

def _update_menu_text_selected_color_choices(*args):
    group = config.plugins.xDreamy.menu_text_selected_color_group.value
    if group == "light":
        choices = _COLOR_NAMES
        default = "Horus Light"
    else:
        choices = _SELECTION_NAMES
        default = "Horus Med"
    current = config.plugins.xDreamy.menu_text_selected_color_value.value
    valid = any(d[0] == current for d in choices)
    if not valid:
        config.plugins.xDreamy.menu_text_selected_color_value.value = default
    config.plugins.xDreamy.menu_text_selected_color_value.setChoices(choices)

def _update_channel_name_color_choices(*args):
    group = config.plugins.xDreamy.channel_name_color_group.value
    if group == "light":
        choices = _COLOR_NAMES
        default = "Horus Light"
    else:
        choices = _SELECTION_NAMES
        default = "Horus Med"
    current = config.plugins.xDreamy.channel_name_color_value.value
    valid = any(d[0] == current for d in choices)
    if not valid:
        config.plugins.xDreamy.channel_name_color_value.value = default
    config.plugins.xDreamy.channel_name_color_value.setChoices(choices)

def _update_event_desc_color_choices(*args):
    group = config.plugins.xDreamy.event_desc_color_group.value
    if group == "light":
        choices = _COLOR_NAMES
        default = "Horus Light"
    else:
        choices = _SELECTION_NAMES
        default = "Horus Med"
    current = config.plugins.xDreamy.event_desc_color_value.value
    valid = any(d[0] == current for d in choices)
    if not valid:
        config.plugins.xDreamy.event_desc_color_value.value = default
    config.plugins.xDreamy.event_desc_color_value.setChoices(choices)

config.plugins.xDreamy.menu_text_color_group.addNotifier(_update_menu_text_color_choices, initial_call=True)
config.plugins.xDreamy.menu_text_selected_color_group.addNotifier(_update_menu_text_selected_color_choices, initial_call=True)
config.plugins.xDreamy.channel_name_color_group.addNotifier(_update_channel_name_color_choices, initial_call=True)
config.plugins.xDreamy.event_desc_color_group.addNotifier(_update_event_desc_color_choices, initial_call=True)


# ─────────────────────────────────────────────────────────────────────────────
#  POSTER / BACKDROP / LOGO MANAGEMENT HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _count_files(folder):
    try:
        return sum(1 for f in os.listdir(folder) if f.endswith((".jpg", ".png")))
    except Exception:
        return 0


def _folder_size_mb(folder):
    try:
        total = sum(os.path.getsize(os.path.join(folder, f)) for f in os.listdir(folder) if os.path.isfile(os.path.join(folder, f)))
        return total / (1024.0 * 1024.0)
    except Exception:
        return 0.0


def _disk_free_gb(path):
    try:
        root = path
        while not os.path.exists(root):
            parent = os.path.dirname(root)
            if parent == root:
                break
            root = parent
        st = os.statvfs(root)
        return (st.f_bavail * st.f_frsize) / (1024.0 ** 3)
    except Exception:
        return 0.0


def _state_entries_db(kind):
    """Counts how many titles have {kind}_ok set, across BOTH the epg and
    emc tables in iMetaData.db."""
    field = "%s_ok" % kind
    total = 0
    try:
        import sqlite3
        db_path = os.path.join(_resolve_storage_path(), "iMetaData.db")
        if not os.path.isfile(db_path):
            return 0
        conn = sqlite3.connect(db_path, timeout=5)
        try:
            for table in ("epg", "emc"):
                try:
                    cur = conn.execute("SELECT COUNT(*) FROM %s WHERE %s=1" % (table, field))
                    total += cur.fetchone()[0]
                except Exception:
                    pass
        finally:
            conn.close()
    except Exception:
        pass
    return total


def _queue_size(kind):
    try:
        if kind == "poster":
            from Components.Renderer.iPosterXDownloadThread import work_queue
            return work_queue.qsize()
        elif kind == "backdrop":
            from Components.Renderer.iBackdropXDownloadThread import live_queue
            return live_queue.qsize()
    except Exception:
        pass
    return 0


def remove_cached_images():
    logger.info("remove_cached_images() called")
    root = _resolve_storage_path()
    for folder in [
        os.path.join(root, "poster"),
        os.path.join(root, "backdrop"),
        os.path.join(root, "logo"),
    ]:
        if not os.path.exists(folder):
            continue
        for pattern in ("*.jpg", "*.png"):
            for f in glob.glob(os.path.join(folder, pattern)):
                try:
                    os.remove(f)
                except Exception as e:
                    logger.error("remove_cached_images: could not remove %s: %s", f, e)
    for state_file in [
        os.path.join(root, "iMetaData.db"),
        os.path.join(root, "iMetaData.db-wal"),
        os.path.join(root, "iMetaData.db-shm"),
        os.path.join(root, "scan_state.json"),
        os.path.join(root, "backdrop", "scan_state.json"),
    ]:
        try:
            if os.path.exists(state_file):
                os.remove(state_file)
        except Exception:
            pass


# ─── BACKUP / RESTORE ──────────────────────────────────────────────────────
def _backup_dir():
    base = _resolve_storage_path()
    backup_dir = os.path.join(base, "backup")
    try:
        os.makedirs(backup_dir)
    except OSError:
        pass
    return backup_dir


def do_backup():
    try:
        backup_dir = _backup_dir()
        free_gb = _disk_free_gb(backup_dir)
        if free_gb < 0.01:
            return False, "Not enough space on storage drive (%.0f MB free)." % (free_gb * 1024)
        if not os.path.exists(SKIN_FILE):
            return False, "skin.xml not found at:\n%s" % SKIN_FILE
        ts   = time.strftime("%Y%m%d_%H%M%S")
        dest = os.path.join(backup_dir, "XDREAMY_backup_%s.zip" % ts)
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(SKIN_FILE, "skin.xml")
            config_dict = {}
            for key, val in config.plugins.xDreamy.content.items.items():
                if hasattr(val, 'value') and not getattr(val, 'noSave', False):
                    config_dict[key] = val.value
            zf.writestr("plugin_config.json", json.dumps(config_dict, indent=2))
        size_kb = os.path.getsize(dest) / 1024.0
        return True, "Backup saved to:\n%s\n\nskin.xml + plugin config | %.1f KB" % (dest, size_kb)
    except Exception as e:
        return False, "Backup failed:\n%s" % str(e)


def do_restore(zip_path):
    try:
        if not os.path.exists(zip_path):
            return False, "Zip file not found:\n%s" % zip_path
        tmp_dir = "/tmp/xdreamy_restore_%s" % time.strftime("%H%M%S")
        with zipfile.ZipFile(zip_path, "r") as zf:
            names = zf.namelist()
            if "skin.xml" not in names:
                return False, "No skin.xml found in backup.\nContents: %s" % ", ".join(names[:5])
            zf.extract("skin.xml", tmp_dir)
            if "plugin_config.json" in names:
                config_data = json.loads(zf.read("plugin_config.json").decode('utf-8'))
                for key, value in config_data.items():
                    if hasattr(config.plugins.xDreamy, key):
                        cfg = getattr(config.plugins.xDreamy, key)
                        if hasattr(cfg, 'value') and not getattr(cfg, 'noSave', False):
                            cfg.value = value
                configfile.save()
        src = os.path.join(tmp_dir, "skin.xml")
        if not os.path.exists(src):
            return False, "Restore failed: extracted file not found."
        shutil.copy2(src, SKIN_FILE)
        os.system("sync")
        try:
            shutil.rmtree(tmp_dir)
        except Exception:
            pass
        return True, "Restore complete from:\n%s\n\nskin.xml + plugin settings restored. A GUI restart is needed." % os.path.basename(zip_path)
    except Exception as e:
        return False, "Restore failed:\n%s" % str(e)


def _find_latest_backup():
    backup_dir = _backup_dir()
    try:
        files = [f for f in os.listdir(backup_dir) if f.startswith("XDREAMY_backup_") and f.endswith(".zip")]
        if not files:
            return None
        files.sort(reverse=True)
        return os.path.join(backup_dir, files[0])
    except Exception:
        return None


def run_auto_remove():
    if not config.plugins.xDreamy.auto_remove_enabled.value:
        return
    days   = int(config.plugins.xDreamy.auto_remove_days.value)
    cutoff = time.time() - days * 86400
    root   = _resolve_storage_path()
    removed = 0
    for sub in ["poster", "backdrop", "logo"]:
        folder = os.path.join(root, sub)
        try:
            for fname in os.listdir(folder):
                if not (fname.endswith(".jpg") or fname.endswith(".png")):
                    continue
                fpath = os.path.join(folder, fname)
                if os.path.getmtime(fpath) < cutoff:
                    os.remove(fpath)
                    removed += 1
        except Exception:
            pass
    if removed:
        logger.info("Auto-removed %d files older than %d days", removed, days)


# ─── PLUGIN INSTALLER HELPERS ──────────────────────────────────────────────
_PLUGIN_PATHS = {
    "AJPanel":            resolveFilename(SCOPE_PLUGINS, "Extensions/AJPan"),
    "LinuxsatPanel":      resolveFilename(SCOPE_PLUGINS, "Extensions/LinuxsatPanel"),
    "CiefpPlugins":       resolveFilename(SCOPE_PLUGINS, "Extensions/CiefpPlugins"),
    "SmartPanel":         resolveFilename(SCOPE_PLUGINS, "Extensions/SmartAddonspanel"),
    "MagicPanel":         resolveFilename(SCOPE_PLUGINS, "Extensions/MagicPanel"),
    "KeyAdder":           resolveFilename(SCOPE_PLUGINS, "Extensions/KeyAdder"),
    "XKlass":             resolveFilename(SCOPE_PLUGINS, "Extensions/XKlass"),
    "YouTube":            resolveFilename(SCOPE_PLUGINS, "Extensions/YouTube"),
    "E2iPlayer":          resolveFilename(SCOPE_PLUGINS, "Extensions/IPTVPlayer"),
    "Transmission":       resolveFilename(SCOPE_PLUGINS, "Extensions/Transmission"),
    "IPAudioPro":         resolveFilename(SCOPE_PLUGINS, "Extensions/IPAudioPro"),
    "EPGGrabber":         resolveFilename(SCOPE_PLUGINS, "Extensions/EPGGrabber"),
    "SubsSupport":        resolveFilename(SCOPE_PLUGINS, "Extensions/SubsSupport"),
    "SubsSupportPro":     resolveFilename(SCOPE_PLUGINS, "Extensions/SubsSupportPro"),
    "HistoryZapSelector": resolveFilename(SCOPE_PLUGINS, "Extensions/HistoryZapSelector"),
    "NewVirtualKeyboard": resolveFilename(SCOPE_PLUGINS, "SystemPlugins/NewVirtualKeyBoard"),
    "RaedQuickSignal":    resolveFilename(SCOPE_PLUGINS, "Extensions/RaedQuickSignal"),
}

_PLUGIN_URLS = {
    "AJPanel":            "https://raw.githubusercontent.com/AMAJamry/AJPanel/main/installer.sh",
    "LinuxsatPanel":      "https://raw.githubusercontent.com/Belfagor2005/LinuxsatPanel/main/installer.sh",
    "CiefpPlugins":       "https://raw.githubusercontent.com/ciefp/CiefpPlugins/main/installer.sh",
    "SmartPanel":         "https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/SmartAddonspanel/smart-Panel.sh",
    "MagicPanel":         "https://gitlab.com/h-ahmed/Panel/-/raw/main/MagicPanel-install.sh",
    "KeyAdder":           "https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh",
    "XKlass":             "https://gitlab.com/MOHAMED_OS/dz_store/-/raw/main/XKlass/online-setup",
    "YouTube":            "https://raw.githubusercontent.com/fairbird/Youtube-Opensource-DreamOS/master/installer.sh",
    "E2iPlayer":          "https://gitlab.com/eliesat/extensions/-/raw/main/e2iplayer/e2iplayer-main.sh",
    "Transmission":       "http://dreambox4u.com/dreamarabia/Transmission_e2/Transmission_e2.sh",
    "IPAudioPro":         "https://raw.githubusercontent.com/biko-73/ipaudio/main/ipaudio_pro.sh",
    "EPGGrabber":         "https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh",
    "SubsSupport":        "https://github.com/popking159/ssupport/raw/main/subssupport-install.sh",
    "SubsSupportPro":     "https://github.com/popking159/SubsSupportPro/raw/main/subssupportpro-install.sh",
    "HistoryZapSelector": "https://raw.githubusercontent.com/biko-73/History_Zap_Selector/main/installer.sh",
    "NewVirtualKeyboard": "https://raw.githubusercontent.com/fairbird/NewVirtualKeyBoard/main/installer.sh",
    "RaedQuickSignal":    "https://raw.githubusercontent.com/fairbird/RaedQuickSignal/main/installer.sh",
}

_TOOLBOX_LABEL_TO_KEY = {
    "AJPanel":              "AJPanel",
    "Linuxsat Panel":       "LinuxsatPanel",
    "Ciefp Plugins":        "CiefpPlugins",
    "SmartAddons Panel":    "SmartPanel",
    "Magic Panel":          "MagicPanel",
    "KeyAdder":             "KeyAdder",
    "X-Klass":              "XKlass",
    "YouTube":               "YouTube",
    "E2iPlayer":             "E2iPlayer",
    "Transmission":          "Transmission",
    "IPAudioPro":            "IPAudioPro",
    "EPG Grabber":           "EPGGrabber",
    "SubsSupport":           "SubsSupport",
    "SubsSupport Pro":       "SubsSupportPro",
    "HistoryZapSelector":    "HistoryZapSelector",
    "New Virtual Keyboard":  "NewVirtualKeyboard",
    "RaedQuickSignal":       "RaedQuickSignal",
}


def check_plugin_installed(name):
    path = _PLUGIN_PATHS.get(name, "")
    return bool(path and os.path.isdir(path))


def update_plugin_install_status():
    mapping = {
        "AJPanel":            config.plugins.xDreamy.install_ajpanel,
        "LinuxsatPanel":      config.plugins.xDreamy.install_linuxsatpanel,
        "CiefpPlugins":       config.plugins.xDreamy.install_CiefpPlugins,
        "SmartPanel":         config.plugins.xDreamy.install_smartpanel,
        "MagicPanel":         config.plugins.xDreamy.install_magicpanel,
        "KeyAdder":           config.plugins.xDreamy.install_keyadder,
        "XKlass":             config.plugins.xDreamy.install_xklass,
        "YouTube":            config.plugins.xDreamy.install_youtube,
        "E2iPlayer":          config.plugins.xDreamy.install_e2iplayer,
        "Transmission":       config.plugins.xDreamy.install_transmission,
        "IPAudioPro":         config.plugins.xDreamy.install_ipaudiopro,
        "EPGGrabber":         config.plugins.xDreamy.install_EPGGrabber,
        "SubsSupport":        config.plugins.xDreamy.install_subssupport,
        "SubsSupportPro":     config.plugins.xDreamy.install_subssupportpro,
        "HistoryZapSelector": config.plugins.xDreamy.install_historyzapselector,
        "NewVirtualKeyboard": config.plugins.xDreamy.install_newvirtualkeyboard,
        "RaedQuickSignal":    config.plugins.xDreamy.install_raedquicksignal,
    }
    for name, cfg_entry in mapping.items():
        cfg_entry.setValue(check_plugin_installed(name))

update_plugin_install_status()

# ─────────────────────────────────────────────────────────────────────────────
#  AUTOSTART
# ─────────────────────────────────────────────────────────────────────────────

def autostart(reason, **kwargs):
    if reason != 0:
        return
    if not is_xdreamy_active():
        logger.info("autostart: xDreamy skin not active, skipping")
        return

    logger.info("autostart: Enigma2 boot detected")
    try:
        run_auto_remove()
    except Exception as e:
        logger.error("autostart: auto_remove failed: %s", e)
    try:
        apply_renderer_config()
    except Exception as e:
        logger.warning("autostart: could not apply renderer config: %s", e)

    try:
        if config.plugins.xDreamy.bootlogos.value:
            if not fileExists(MVI_PATH + 'bootlogoBack.mvi'):
                try:
                    shutil.copy(MVI_PATH + 'bootlogo.mvi', MVI_PATH + 'bootlogoBack.mvi')
                except Exception as e:
                    logger.error("autostart: copy bootlogo backup: %s", e)
            for fname in ('bootlogo.mvi', 'backdrop.mvi', 'bootlogo_wait.mvi'):
                full = LOGOPATH + fname
                if fileExists(full):
                    try:
                        os.remove(full)
                    except Exception as e:
                        logger.error("autostart: remove %s: %s", full, e)
            if fileExists(BOOTLOG_PATH + 'bootlogo1.mvi'):
                chosen = random.choice(os.listdir(BOOTLOG_PATH))
                src = BOOTLOG_PATH + chosen
                try:
                    shutil.copy(src, MVI_PATH + 'bootlogo.mvi')
                    shutil.copy(src, MVI_PATH + 'backdrop.mvi')
                    logger.info("autostart: boot logo → %s", chosen)
                except Exception as e:
                    logger.error("autostart: copy boot logo: %s", e)
        else:
            backup = MVI_PATH + 'bootlogoBack.mvi'
            if fileExists(backup):
                try:
                    shutil.copy(backup, MVI_PATH + 'bootlogo.mvi')
                    os.remove(backup)
                    logger.info("autostart: restored original boot logo")
                except Exception as e:
                    logger.error("autostart: restore bootlogo: %s", e)
    except Exception as e:
        logger.error("autostart: bootlogo handling failed: %s", e)

    try:
        apply_date_format()
    except Exception as e:
        logger.error("autostart: apply_date_format failed: %s", e)

    ListColorizer.init()
    logger.info("autostart: complete")


# ─── MAIN PLUGIN FUNCTION ──────────────────────────────────────────────────
def main(session, **kwargs):
    if not is_xdreamy_active():
        session.open(MessageBox,
                     _("XDREAMY Skin is not active.\nPlease select it in the Skin Settings."),
                     MessageBox.TYPE_ERROR, timeout=5)
        return
    # Migration for new color configs: if old BasicColor/WhiteColor have non-default values,
    # copy them to new configs. This ensures existing custom color settings survive.
    old_basic = config.plugins.xDreamy.BasicColor.value
    old_white = config.plugins.xDreamy.WhiteColor.value
    # Set title group to light (since old values are from light list)
    if config.plugins.xDreamy.title_color_value.value == "Horus Light" and old_basic != "Horus Light":
        config.plugins.xDreamy.title_color_group.value = "light"
        config.plugins.xDreamy.title_color_value.value = old_basic
    if config.plugins.xDreamy.text_color_value.value == "Horus Light" and old_white != "Horus Light":
        config.plugins.xDreamy.text_color_group.value = "light"
        config.plugins.xDreamy.text_color_value.value = old_white
    # Save migration if needed
    if config.plugins.xDreamy.title_color_value.isChanged() or config.plugins.xDreamy.text_color_value.isChanged():
        configfile.save()
    if not config.plugins.xDreamy.deps_checked.value:
        run_requirements_flow(session, lambda: session.open(xDreamySetup))
        return
    session.open(xDreamySetup)


def Plugins(**kwargs):
    plugins = [
        PluginDescriptor(
            name=_("XDREAMY Skin"),
            description=_("Customization tool for XDREAMY Skin"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon='plugin.png',
            fnc=main
        ),
        PluginDescriptor(
            name=_("XDREAMY Boot"),
            description=_("XDREAMY random boot logo manager"),
            where=PluginDescriptor.WHERE_AUTOSTART,
            fnc=autostart
        ),
    ]
    if config.plugins.xDreamy.ShowInExtensions.value:
        plugins.append(PluginDescriptor(
            name=_("XDREAMY Skin Settings"),
            description=_("Customization tool for XDREAMY Skin"),
            where=[PluginDescriptor.WHERE_EXTENSIONSMENU],
            fnc=main
        ))
    return plugins


# ─────────────────────────────────────────────────────────────────────────────
#  XDREAMY ACTION MENU
# ─────────────────────────────────────────────────────────────────────────────

class XDREAMYActionMenu(Screen):
    skin = '''
        <screen name="XDREAMYActionMenu" position="center,center"
                size="550,350" title="XDREAMY Actions">
            <widget name="menu" position="10,10" size="530,310"
                    scrollbarMode="showOnDemand"/>
        </screen>
    '''

    def __init__(self, session, root, refresh_cb):
        Screen.__init__(self, session)
        self.root       = root
        self.refresh_cb = refresh_cb
        latest        = _find_latest_backup()
        restore_label = (
            "Restore: %s" % os.path.basename(latest)
            if latest else "Restore (no backup found)"
        )
        from Components.MenuList import MenuList
        self._choices = [
            ("Clear all poster images",   lambda: self._clear_assets("poster")),
            ("Clear all backdrop images", lambda: self._clear_assets("backdrop")),
            ("Clear all logo images",     lambda: self._clear_assets("logo")),
            ("Backup skin.xml",           self._backup),
            (restore_label,               self._restore),
            ("Clear ALL cached images",   self._clear_all),
        ]
        self["menu"] = MenuList([c[0] for c in self._choices])
        self["actions"] = ActionMap(
            ["OkCancelActions"],
            {"ok": self._ok, "cancel": self.close},
            -1,
        )

    def _ok(self):
        idx = self["menu"].getSelectedIndex()
        self._choices[idx][1]()

    def _clear_assets(self, kind):
        labels = {'poster': 'poster images', 'backdrop': 'backdrop images', 'logo': 'logo images'}
        self.session.openWithCallback(
            lambda confirmed: self._do_clear_assets(confirmed, kind),
            MessageBox,
            "Delete ALL %s and state cache?\nThis cannot be undone." % labels.get(kind, kind),
            MessageBox.TYPE_YESNO, default=False,
        )

    def _do_clear_assets(self, confirmed, kind):
        if not confirmed:
            return
        folder = os.path.join(self.root, kind)
        removed = 0
        try:
            for f in os.listdir(folder):
                if f.endswith((".jpg", ".png")):
                    os.remove(os.path.join(folder, f))
                    removed += 1
        except Exception:
            pass
        try:
            from Components.Renderer.iConverlibr import reset_asset_ok_flags
            reset_asset_ok_flags(kind)
        except Exception:
            pass
        self.refresh_cb()
        self.session.open(MessageBox, "Removed %d %s files." % (removed, kind),
                          MessageBox.TYPE_INFO, timeout=3)
        self.close()

    def _clear_all(self):
        self.session.openWithCallback(
            self._do_clear_all, MessageBox,
            "Delete ALL poster, backdrop and logo images and state caches?\nThis cannot be undone.",
            MessageBox.TYPE_YESNO, default=False,
        )

    def _do_clear_all(self, confirmed):
        if not confirmed:
            return
        remove_cached_images()
        self.refresh_cb()
        self.session.open(MessageBox, "All cached images removed.",
                          MessageBox.TYPE_INFO, timeout=3)
        self.close()

    def _backup(self):
        ok, msg = do_backup()
        self.session.open(
            MessageBox, msg,
            MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR,
            timeout=6,
        )
        self.refresh_cb()
        self.close()

    def _restore(self):
        latest = _find_latest_backup()
        if not latest:
            self.session.open(MessageBox,
                "No backup file found in /XDREAMY/backup/\n"
                "Please create a backup first.",
                MessageBox.TYPE_ERROR)
            return
        self.session.openWithCallback(
            lambda confirmed: self._do_restore(confirmed, latest),
            MessageBox,
            "Restore from:\n%s\n\nThis will overwrite your current skin.xml." % os.path.basename(latest),
            MessageBox.TYPE_YESNO, default=False,
        )

    def _do_restore(self, confirmed, zip_path):
        if not confirmed:
            return
        ok, msg = do_restore(zip_path)
        self.session.open(
            MessageBox, msg,
            MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR,
            timeout=5,
        )
        self.refresh_cb()
        self.close()

    def _check_requirements(self):
        run_requirements_flow(self.session, self.refresh_cb)


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN SETUP SCREEN (with live preview)
# ─────────────────────────────────────────────────────────────────────────────

class xDreamySetup(ConfigListScreen, Screen):
    skin = '''
        <screen name="xDreamySetup" position="center,center" size="1050,680"
                title="XDREAMY Skin Customisation">

            <widget name="config" font="Regular; 23" itemHeight="38"
                    position="5,5" scrollbarMode="showOnDemand" size="625,580"/>

            <widget name="helpText" font="Regular; 22" position="5,592"
                    size="625,30" foregroundColor="#00ffffff" backgroundColor="#000000"
                    transparent="1" zPosition="2" halign="left" valign="center"/>

            <widget name="status_title" position="640,5"  size="405,26"
                    font="Regular;20" foregroundColor="#ffcc00" transparent="1"/>
            <widget name="status_body"  position="640,36" size="405,330"
                    font="Regular;17" foregroundColor="#ffffff" transparent="1"/>

            <widget name="Preview" position="640,372" size="405,150"
                    zPosition="1" alphatest="blend"/>

            <widget name="color_title" position="640,530" size="405,24"
                    font="Regular;18" foregroundColor="#ffcc00" transparent="1"/>
            <widget name="swatch_ltbluette" position="640,558" size="125,60"
                    zPosition="1" backgroundColor="#FFFFFF"/>
            <widget name="swatch_ltbluette_lbl" position="640,558" size="125,60"
                    font="Regular;15" foregroundColor="#000000" backgroundColor="#FFFFFF"
                    transparent="0" halign="center" valign="center"/>
            <widget name="swatch_bluette" position="775,558" size="125,60"
                    zPosition="1" backgroundColor="#FFFFFF"/>
            <widget name="swatch_bluette_lbl" position="775,558" size="125,60"
                    font="Regular;15" foregroundColor="#000000" backgroundColor="#FFFFFF"
                    transparent="0" halign="center" valign="center"/>
            <widget name="swatch_header" position="910,558" size="135,60"
                    zPosition="1" backgroundColor="#FFFFFF"/>
            <widget name="swatch_header_lbl" position="910,558" size="135,60"
                    font="Regular;15" foregroundColor="#000000" backgroundColor="#FFFFFF"
                    transparent="0" halign="center" valign="center"/>

            <widget name="key_red"    position="20,650"  size="120,26"
                    font="Regular;18" foregroundColor="#ff4444" transparent="1" halign="center"/>
            <widget name="key_green"  position="220,650" size="120,26"
                    font="Regular;18" foregroundColor="#44ff44" transparent="1" halign="center"/>
            <widget name="key_yellow" position="420,650" size="120,26"
                    font="Regular;18" foregroundColor="#ffcc00" transparent="1" halign="center"/>
            <widget name="key_blue"   position="620,650" size="120,26"
                    font="Regular;18" foregroundColor="#4488ff" transparent="1" halign="center"/>
        </screen>
    '''

    def __init__(self, session):
        Screen.__init__(self, session)
        self.skinFile     = SKIN_FILE
        self.previewFiles = SAMPLE_PATH
        self.setup_title  = "XDREAMY SKIN v {}".format(VERSION)
        self._update_url  = ''
        self._update_result = None

        # Snapshot of config that requires restart
        self._config_snapshot = {}
        self._capture_config_snapshot()

        self['helpText']     = Label('')
        self['status_title'] = Label("── Status ─────────────────────")
        self['status_body']  = Label("Loading…")
        self['key_red']      = Label(_('Cancel'))
        # ─── Green button always shows "Apply & Exit" ───────────────────────
        self['key_green']    = Label(_('Apply & Exit'))
        self['key_yellow']   = Label(_('Actions'))
        self['key_blue']     = Label(_('Info'))

        self['Preview'] = Pixmap()

        self['color_title']         = Label("───────────── Color Preview ────────────")
        self['swatch_ltbluette']    = Pixmap()
        self['swatch_ltbluette_lbl']= Label("Text")
        self['swatch_bluette']      = Pixmap()
        self['swatch_bluette_lbl']  = Label("Select")
        self['swatch_header']       = Pixmap()
        self['swatch_header_lbl']   = Label("Background")

        ConfigListScreen.__init__(self, [], session=self.session,
                                  on_change=self.changedEntry)

        # ── For live preview ──
        self._preview_mode = 'template'  # 'template', 'menu', 'channel'

        self['actions'] = ActionMap(
            ['OkCancelActions', 'DirectionActions', 'InputActions',
             'VirtualKeyboardActions', 'ColorActions', 'InfoActions'],
            {
                'showVirtualKeyboard': self.keyText,
                'left':   self.keyLeft,
                'right':  self.keyRight,
                'down':   self.keyDown,
                'up':     self.keyUp,
                'red':    self.keyExit,
                'green':  self.keySave,
                'yellow': self.keyYellowAction,
                'blue':   self.showInfo,
                'cancel': self.keyExit,
                'ok':     self.keyOK,
            }, -1)

        self._update_timer = eTimer()
        self._update_timer.callback.append(self.checkForUpdate)
        self._update_timer.start(5000, True)

        self._refresh_timer = eTimer()
        self._refresh_timer.callback.append(self._update_status)
        self._refresh_timer.start(5000, False)

        self._font_preview_timer = eTimer()
        self._font_preview_timer.callback.append(self._showFontPreview)
        self._registered_preview_fonts = set()
        self._closed = False

        self.onLayoutFinish.append(self.__layoutFinished)
        self.onLayoutFinish.append(self.createSetup)
        self.onLayoutFinish.append(self._update_status)
        self.onLayoutFinish.append(self.showPicture)
        self.onLayoutFinish.append(self.updateColorSwatches)
        update_plugin_install_status()
        apply_renderer_config()

    def _capture_config_snapshot(self):
        restart_keys = (
            'posterx_enabled', 'backdropx_enabled', 'logox_enabled',
            'tmdb_language', 'tmdb_api_key', 'storage_mode', 'storage_custom_path',
            'worker_threads', 'channelcolor_enabled',
            'debug_master',
            'epg_translate_enabled', 'epg_translate_provider',
            'epg_translate_target_lang', 'epg_translate_cache_ttl',
            'epg_translate_google_api_key', 'epg_translate_gemini_api_key',
            'epg_translate_groq_api_key',
            'color_local', 'color_emu', 'color_cccam', 'color_network',
        )
        for mod in DEBUG_MODULES:
            restart_keys += ('dbg_%s' % mod,)
        self._config_snapshot = {}
        for key in restart_keys:
            if hasattr(config.plugins.xDreamy, key):
                cfg = getattr(config.plugins.xDreamy, key)
                if hasattr(cfg, 'value'):
                    self._config_snapshot[key] = cfg.value

    def _check_restart_required(self):
        for key, old_val in self._config_snapshot.items():
            if hasattr(config.plugins.xDreamy, key):
                cfg = getattr(config.plugins.xDreamy, key)
                if hasattr(cfg, 'value'):
                    if cfg.value != old_val:
                        return True
        return False

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    # ─── Status Update ──────────────────────────────────────────────────────

    def _update_status(self):
        root    = _resolve_storage_path()
        p_dir   = os.path.join(root, "poster")
        b_dir   = os.path.join(root, "backdrop")
        l_dir   = os.path.join(root, "logo")

        n_p  = _count_files(p_dir);   sz_p  = _folder_size_mb(p_dir)
        n_b  = _count_files(b_dir);   sz_b  = _folder_size_mb(b_dir)
        n_l  = _count_files(l_dir);   sz_l  = _folder_size_mb(l_dir)
        free = _disk_free_gb(root)
        se_p = _state_entries_db("poster")
        se_b = _state_entries_db("backdrop")
        q_p  = _queue_size("poster")
        q_b  = _queue_size("backdrop")
        bk   = _find_latest_backup()

        lines = [
            "Path: %s" % root, "",
            "Posters:",
            "  Files: %d  (%.1f MB)" % (n_p, sz_p),
            "  State: %d entries" % se_p,
            "  Queue: %d pending" % q_p, "",
            "Backdrops:",
            "  Files: %d  (%.1f MB)" % (n_b, sz_b),
            "  State: %d entries" % se_b,
            "  Queue: %d pending" % q_b, "",
            "Logos:",
            "  Files: %d  (%.1f MB)" % (n_l, sz_l), "",
            "Total:     %.1f MB" % (sz_p + sz_b + sz_l),
            "Disk free: %.1f GB" % free,
        ]
        if bk:
            lines += ["", "Latest Backup:", "  %s" % os.path.basename(bk)]
        self["status_body"].setText("\n".join(lines))

    # ─── Help Text ──────────────────────────────────────────────────────────

    def updateHelpText(self):
        current = self['config'].getCurrent()
        if not current or len(current) < 2:
            self._font_preview_timer.stop()
            self['helpText'].setText('')
            return

        sel = current[1]
        if sel in (config.plugins.xDreamy.FontName, config.plugins.xDreamy.FontScale):
            self['helpText'].setText(_('Loading preview...'))
            self._font_preview_timer.start(150, True)
        else:
            self._font_preview_timer.stop()
            self['helpText'].setText(current[2] if len(current) > 2 else '')

    def _showFontPreview(self):
        sample = '“Those who live today will die tomorrow, those who die tomorrow will be born again; Those who live MAAT will not die.  - الذين يعيشون اليوم سيموتون غداً، والذين يموتون غداً سيولدون من جديد؛ أما الذين يحيوْن "ماعت" فلن يموتوا.'
        font_name = config.plugins.xDreamy.FontName.value
        try:
            scale_pct = int(config.plugins.xDreamy.FontScale.value)
        except Exception:
            scale_pct = 100
        base_size = 22
        preview_size = max(10, int(base_size * scale_pct / 100.0))

        self['helpText'].setText(sample)
        try:
            font_path = os.path.join('/usr/share/fonts', font_name)
            if not os.path.isfile(font_path):
                font_path = '/usr/share/enigma2/xDreamy/fonts/{}'.format(font_name)
            if not (self['helpText'].instance and os.path.isfile(font_path)):
                return

            alias = 'XDreamyPreview_' + re.sub(r'[^A-Za-z0-9]+', '_', font_name)
            from enigma import gFont, addFont
            if alias not in self._registered_preview_fonts:
                addFont(font_path, alias, 100, 0)
                self._registered_preview_fonts.add(alias)
            self['helpText'].instance.setFont(gFont(alias, preview_size))
        except Exception as exc:
            logger.debug("_showFontPreview: could not apply live font (%s)", exc)

    # ─── Color Preview with live update ──────────────────────────────────

    def _get_preview_colors_for_entry(self, entry):
        if entry is None or len(entry) < 2:
            return None, None, None
        cfg = entry[1]

        # Menu colors (new group+value or old direct)
        if cfg in (config.plugins.xDreamy.menu_text_color_group,
                   config.plugins.xDreamy.menu_text_color_value,
                   config.plugins.xDreamy.menu_text_selected_color_group,
                   config.plugins.xDreamy.menu_text_selected_color_value,
                   config.plugins.xDreamy.menuBackgroundSelectedColor):
            # Resolve using current custom setting
            text_group = config.plugins.xDreamy.menu_text_color_group.value
            text_val = config.plugins.xDreamy.menu_text_color_value.value
            if text_group == "light":
                c1 = _get_hex_from_name(text_val, _COLOR_NAMES)
            else:
                c1 = _get_hex_from_name(text_val, _SELECTION_NAMES)

            sel_group = config.plugins.xDreamy.menu_text_selected_color_group.value
            sel_val = config.plugins.xDreamy.menu_text_selected_color_value.value
            if sel_group == "light":
                c2 = _get_hex_from_name(sel_val, _COLOR_NAMES)
            else:
                c2 = _get_hex_from_name(sel_val, _SELECTION_NAMES)

            c3 = _resolve_named_color(config.plugins.xDreamy.menuBackgroundSelectedColor.value, _SELECTION_NAMES)
            labels = ('Menu Text', 'Menu Sel. Text', 'Menu Sel. BG')
            return 'menu', (c1, c2, c3), labels

        # Channel colors (new group+value or old direct)
        if cfg in (config.plugins.xDreamy.channel_name_color_group,
                   config.plugins.xDreamy.channel_name_color_value,
                   config.plugins.xDreamy.event_desc_color_group,
                   config.plugins.xDreamy.event_desc_color_value,
                   config.plugins.xDreamy.progressBarColor):
            name_group = config.plugins.xDreamy.channel_name_color_group.value
            name_val = config.plugins.xDreamy.channel_name_color_value.value
            if name_group == "light":
                c1 = _get_hex_from_name(name_val, _COLOR_NAMES)
            else:
                c1 = _get_hex_from_name(name_val, _SELECTION_NAMES)

            desc_group = config.plugins.xDreamy.event_desc_color_group.value
            desc_val = config.plugins.xDreamy.event_desc_color_value.value
            if desc_group == "light":
                c2 = _get_hex_from_name(desc_val, _COLOR_NAMES)
            else:
                c2 = _get_hex_from_name(desc_val, _SELECTION_NAMES)

            c3 = _resolve_named_color(config.plugins.xDreamy.progressBarColor.value, _SELECTION_NAMES)
            labels = ('Channel Name', 'Event Desc', 'Progress Bar')
            return 'channel', (c1, c2, c3), labels

        # Title/Text custom colors (already present)
        if cfg in (config.plugins.xDreamy.title_color_group, config.plugins.xDreamy.title_color_value,
                   config.plugins.xDreamy.text_color_group, config.plugins.xDreamy.text_color_value):
            t_group = config.plugins.xDreamy.title_color_group.value
            t_val = config.plugins.xDreamy.title_color_value.value
            if t_group == "light":
                t_hex = _get_hex_from_name(t_val, _COLOR_NAMES)
            else:
                t_hex = _get_hex_from_name(t_val, _SELECTION_NAMES)

            txt_group = config.plugins.xDreamy.text_color_group.value
            txt_val = config.plugins.xDreamy.text_color_value.value
            if txt_group == "light":
                txt_hex = _get_hex_from_name(txt_val, _COLOR_NAMES)
            else:
                txt_hex = _get_hex_from_name(txt_val, _SELECTION_NAMES)

            sel_hex = _get_hex_from_name(config.plugins.xDreamy.SelectionColor.value, _SELECTION_NAMES)
            bg_hex = _get_hex_from_name(config.plugins.xDreamy.BackgroundColor.value, _BACKGROUND_NAMES)
            labels = ('Title (ltbluette)', 'Text (white)', 'Selection (bluette)')
            return 'custom', (t_hex, txt_hex, sel_hex, bg_hex), labels

        return None, None, None

    def _updatePreviewForCurrentEntry(self):
        current = self['config'].getCurrent()
        if current and len(current) > 1:
            mode, colors, labels = self._get_preview_colors_for_entry(current)
            if mode:
                if mode == 'custom':
                    self._paintSwatch('swatch_ltbluette_lbl', colors[0], 'Title')
                    self._paintSwatch('swatch_bluette_lbl', colors[1], 'Text')
                    self._paintSwatch('swatch_header_lbl', colors[3], 'Background')
                    self['color_title'].setText('─── Custom Color Preview ───')
                    self._preview_mode = 'custom'
                else:
                    self._paintSwatch('swatch_ltbluette_lbl', colors[0], labels[0])
                    self._paintSwatch('swatch_bluette_lbl', colors[1], labels[1])
                    self._paintSwatch('swatch_header_lbl', colors[2], labels[2])
                    if mode == 'menu':
                        self['color_title'].setText('─── Menu Colors Preview ───')
                    else:
                        self['color_title'].setText('── Channel Colors Preview ──')
                    self._preview_mode = mode
                return

        if self._preview_mode != 'template':
            self.updateColorSwatches()
            self['color_title'].setText('───────────── Color Preview ────────────')
            self._preview_mode = 'template'

    def updateColorSwatches(self):
        if config.plugins.xDreamy.colorSelector.value == 'default-color':
            tpl = config.plugins.xDreamy.BasicColorTemplates.value
            lt, bl, hd = TEMPLATES.get(tpl, ('#FFFFFF', '#3498DB', '#001A1A1A'))
        else:
            # Use the new two-step configs
            t_group = config.plugins.xDreamy.title_color_group.value
            t_val = config.plugins.xDreamy.title_color_value.value
            if t_group == "light":
                lt = _get_hex_from_name(t_val, _COLOR_NAMES)
            else:
                lt = _get_hex_from_name(t_val, _SELECTION_NAMES)

            txt_group = config.plugins.xDreamy.text_color_group.value
            txt_val = config.plugins.xDreamy.text_color_value.value
            if txt_group == "light":
                white_hex = _get_hex_from_name(txt_val, _COLOR_NAMES)
            else:
                white_hex = _get_hex_from_name(txt_val, _SELECTION_NAMES)

            bl = _get_hex_from_name(config.plugins.xDreamy.SelectionColor.value, _SELECTION_NAMES)
            hd = _get_hex_from_name(config.plugins.xDreamy.BackgroundColor.value, _BACKGROUND_NAMES)
            # We use lt for title, white_hex for text, but we only have three slots.
            # We'll set ltbluette = title (lt), bluette = selection (bl), header = background (hd).
            # For the text color, we don't have a dedicated slot in the swatch preview, but we show it in help?
            # We'll just keep the original mapping: ltbluette, bluette, header.
            # We'll keep lt as ltbluette, bl as bluette, hd as header.
            # Text color is not shown in swatches, but it's used in the preview for menu/channel.
            # We'll keep it as is.

        self._paintSwatch('swatch_ltbluette_lbl', lt, 'Title' if config.plugins.xDreamy.colorSelector.value != 'default-color' else 'Text')
        self._paintSwatch('swatch_bluette_lbl', bl, 'Select')
        self._paintSwatch('swatch_header_lbl', hd, 'Background')
        self['color_title'].setText('───────────── Color Preview ────────────')
        self._preview_mode = 'template'

    def _paintSwatch(self, label_name, hex_color, label_text):
        try:
            widget = self[label_name]
        except Exception:
            return
        clean = _hex_to_rgb_str(hex_color)
        try:
            r, g, b = int(clean[1:3], 16), int(clean[3:5], 16), int(clean[5:7], 16)
        except Exception:
            r, g, b = 255, 255, 255
        luma = 0.299 * r + 0.587 * g + 0.114 * b
        text_rgb = (0, 0, 0) if luma > 140 else (255, 255, 255)

        try:
            from enigma import gRGB
            inst = self[label_name].instance
            if inst:
                inst.setBackgroundColor(gRGB(r, g, b))
                inst.setForegroundColor(gRGB(*text_rgb))
                inst.setTransparent(0)
            self[label_name].setText('{}\n{}'.format(label_text, clean))
        except Exception as exc:
            logger.debug("_paintSwatch(%s): %s", label_name, exc)

    # ─── Picture Preview ────────────────────────────────────────────────────

    def _find_case_insensitive(self, base_name):
        if not os.path.isdir(SCREEN_PREVIEW_PATH):
            return None
        try:
            for fname in os.listdir(SCREEN_PREVIEW_PATH):
                name, ext = os.path.splitext(fname)
                if ext.lower() in ('.png', '.jpg', '.jpeg') and name.lower() == base_name.lower():
                    return os.path.join(SCREEN_PREVIEW_PATH, fname)
        except Exception as exc:
            logger.debug("_find_case_insensitive: %s", exc)
        return None

    def _getPicturePath(self):
        default = None
        for ext in ('.png', '.jpg', '.jpeg'):
            p = os.path.join(SCREEN_PREVIEW_PATH, 'default' + ext)
            if fileExists(p):
                default = p
                break

        current = self['config'].getCurrent()
        if not current or len(current) < 2:
            return default
        sel = current[1]
        val = sel.value if hasattr(sel, 'value') else None

        if isinstance(val, str):
            for ext in ('.png', '.jpg', '.jpeg'):
                candidate = os.path.join(SCREEN_PREVIEW_PATH, val + ext)
                if fileExists(candidate):
                    return candidate
            found = self._find_case_insensitive(val)
            if found:
                return found
            return default

        label = (current[0] or '').strip()
        plugin_key = _TOOLBOX_LABEL_TO_KEY.get(label)
        if not plugin_key:
            for possible in _TOOLBOX_LABEL_TO_KEY:
                if possible.strip() == label:
                    plugin_key = _TOOLBOX_LABEL_TO_KEY[possible]
                    break
        if plugin_key:
            for ext in ('.png', '.jpg', '.jpeg'):
                candidate = os.path.join(SCREEN_PREVIEW_PATH, plugin_key + ext)
                if fileExists(candidate):
                    return candidate
            found = self._find_case_insensitive(plugin_key)
            if found:
                return found
        return default

    def showPicture(self, _=None):
        if not self['Preview'].instance:
            return
        size = self['Preview'].instance.size()
        if size.isNull():
            size.setWidth(498)
            size.setHeight(280)
        path = self._getPicturePath()
        if path and fileExists(path):
            png = loadPic(path, size.width(), size.height(), 0, 0, 0, 1)
            if png:
                self['Preview'].instance.setPixmap(png)

    # ─── Navigation ──────────────────────────────────────────────────────────

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.createSetup()
        self.updateColorSwatches()
        self._updatePreviewForCurrentEntry()
        self.showPicture()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.createSetup()
        self.updateColorSwatches()
        self._updatePreviewForCurrentEntry()
        self.showPicture()

    def keyDown(self):
        self['config'].instance.moveSelection(self['config'].instance.moveDown)
        self.updateHelpText()
        self._updatePreviewForCurrentEntry()
        self.showPicture()

    def keyUp(self):
        self['config'].instance.moveSelection(self['config'].instance.moveUp)
        self.updateHelpText()
        self._updatePreviewForCurrentEntry()
        self.showPicture()

    def keyOK(self):
        current = self['config'].getCurrent()
        if not current or len(current) < 2:
            return
        sel = current[1]

        # ---- Toolbox plugin installation entries ----
        if self._is_plugin_install_entry(sel):
            self._install_plugin_from_entry(current)
            return

        if isinstance(sel, ConfigText):
            self.keyText()
        elif isinstance(sel, ConfigSelection):
            self._openSelectionPopup(current)
        elif sel is config.plugins.xDreamy.png:
            self._doPngRemove()
        elif sel is config.plugins.xDreamy.backup_action:
            self._do_backup()
        elif sel is config.plugins.xDreamy.restore_action:
            self._do_restore()
        elif sel is config.plugins.xDreamy.check_requirements_action:
            self._check_requirements()
        elif sel is config.plugins.xDreamy.epg_translate_google_key_import:
            self._browseApiKeyFile(config.plugins.xDreamy.epg_translate_google_api_key)
        elif sel is config.plugins.xDreamy.epg_translate_gemini_key_import:
            self._browseApiKeyFile(config.plugins.xDreamy.epg_translate_gemini_api_key)
        elif sel is config.plugins.xDreamy.epg_translate_groq_key_import:
            self._browseApiKeyFile(config.plugins.xDreamy.epg_translate_groq_api_key)
        else:
            ConfigListScreen.keyOK(self)

    def _is_plugin_install_entry(self, sel):
        for pid in _PLUGIN_IDS:
            if sel is getattr(config.plugins.xDreamy, "install_%s" % pid, None):
                return True
        return False

    def _install_plugin_from_entry(self, current):
        label = current[0].strip()
        plugin_key = _TOOLBOX_LABEL_TO_KEY.get(label)
        if not plugin_key:
            for pid in _PLUGIN_IDS:
                if getattr(config.plugins.xDreamy, "install_%s" % pid, None) is current[1]:
                    plugin_key = pid
                    break
        if not plugin_key or plugin_key not in _PLUGIN_URLS:
            self.session.open(MessageBox, _("No installation URL found for this plugin."),
                              MessageBox.TYPE_ERROR)
            return

        url = _PLUGIN_URLS[plugin_key]
        if check_plugin_installed(plugin_key):
            self.session.open(MessageBox, _("Plugin is already installed."),
                              MessageBox.TYPE_INFO, timeout=3)
            return

        self.session.openWithCallback(
            lambda confirmed: self._do_install_plugin(plugin_key, url) if confirmed else None,
            MessageBox,
            _("Install {} from:\n{}\n\nContinue?").format(plugin_key, url),
            MessageBox.TYPE_YESNO, default=True
        )

    def _do_install_plugin(self, plugin_key, url):
        from Screens.Console import Console
        cmd = "wget -qO- {} | sh".format(url)
        self.session.openWithCallback(
            self._install_finished,
            Console,
            title=_("Installing {}...".format(plugin_key)),
            cmdlist=[cmd],
        )

    def _install_finished(self, retval):
        if retval == 0:
            update_plugin_install_status()
            self.createSetup()
            self.session.open(MessageBox, _("Installation completed successfully."),
                              MessageBox.TYPE_INFO, timeout=5)
        else:
            self.session.open(MessageBox, _("Installation failed. Please check your network and try again."),
                              MessageBox.TYPE_ERROR)

    def keyExit(self):
        self._closed = True
        self._refresh_timer.stop()
        self._font_preview_timer.stop()
        if hasattr(self, '_update_check_timer'):
            self._update_check_timer.stop()
        self.close()

    # ─── Cache Clear ────────────────────────────────────────────────────────

    def _doPngRemove(self):
        self.session.openWithCallback(
            self._confirmPngRemove, MessageBox,
            'Delete all cached poster, backdrop and logo images?\nThis cannot be undone.',
            MessageBox.TYPE_YESNO, default=False,
        )

    def _confirmPngRemove(self, confirmed):
        if not confirmed:
            return
        remove_cached_images()
        self._update_status()
        self.session.open(MessageBox,
                          'All cached images have been removed.',
                          MessageBox.TYPE_INFO, timeout=4)

    # ─── Storage Path Browser ────────────────────────────────────────────────

    def _browseStoragePath(self):
        if _HAS_LOCATIONBOX:
            current_path = config.plugins.xDreamy.storage_custom_path.value or "/media/hdd"
            self.session.openWithCallback(
                self._storagePathChosen, LocationBox,
                text=_("Select XDREAMY storage folder"),
                filename="XDREAMY",
                currDir=os.path.dirname(current_path.rstrip("/")) + "/",
                bookmarks=None, autoAdd=False, editDir=True,
                inhibitDirs=["/proc", "/sys", "/dev", "/etc"],
                minFree=None,
            )
        else:
            self.keyText()

    def _storagePathChosen(self, path):
        if path:
            config.plugins.xDreamy.storage_custom_path.value = path.rstrip("/")
            self.createSetup()

    # ─── API Key Import from File ───────────────────────────────────────────

    _API_KEY_SEARCH_DIRS = [
        "/media/hdd/", "/media/usb/", "/media/mmc/",
        "/media/hdd/XDREAMY/", "/tmp/",
    ]

    def _browseApiKeyFile(self, target_config_text):
        found = []
        for d in self._API_KEY_SEARCH_DIRS:
            if not os.path.isdir(d):
                continue
            try:
                for fname in sorted(os.listdir(d)):
                    if fname.lower().endswith('.txt'):
                        full = os.path.join(d, fname)
                        if os.path.isfile(full):
                            found.append(full)
            except Exception as exc:
                logger.debug("_browseApiKeyFile: could not list %s: %s", d, exc)

        if not found:
            searched = '\n'.join(self._API_KEY_SEARCH_DIRS)
            self.session.open(MessageBox,
                'No .txt files found in:\n{}\n\n'
                'Copy your key file to one of these folders and try again, '
                'or press OK on the key field itself to type it manually.'.format(searched),
                MessageBox.TYPE_ERROR, timeout=8)
            return

        options = [("{}  ({})".format(os.path.basename(p), os.path.dirname(p)), p) for p in found]

        self.session.openWithCallback(
            lambda choice: self._apiKeyFileChosen(choice[1] if choice else None, target_config_text),
            ChoiceBox,
            title=_("Select the .txt file containing the API key"),
            list=options
        )

    def _apiKeyFileChosen(self, path, target_config_text):
        if not path or not os.path.isfile(path):
            return
        try:
            with open(path, 'r') as fh:
                for line in fh:
                    key = line.strip()
                    if key:
                        target_config_text.value = key
                        self.createSetup()
                        self.session.open(MessageBox,
                                          'API key imported from:\n{}'.format(path),
                                          MessageBox.TYPE_INFO, timeout=3)
                        return
            self.session.open(MessageBox,
                              'File was empty -- no key imported:\n{}'.format(path),
                              MessageBox.TYPE_ERROR)
        except Exception as exc:
            logger.error("_apiKeyFileChosen: %s", exc)
            self.session.open(MessageBox,
                              'Could not read file:\n{}'.format(exc),
                              MessageBox.TYPE_ERROR)

    # ─── Selection Popup ────────────────────────────────────────────────────

    def _openSelectionPopup(self, current):
        sel = current[1]
        if not hasattr(sel, 'choices'):
            return
        try:
            options = self._buildChoiceOptions(sel)
            if not options:
                return
            self.session.openWithCallback(
                lambda choice: self._selectionMade(choice, sel),
                ChoiceBox,
                title="Select: " + current[0],
                list=options
            )
        except Exception as exc:
            logger.error("_openSelectionPopup crash prevented for %r: %s", current[0], exc)
            self.session.open(MessageBox,
                              'Could not open the selection list for this entry.\n'
                              'You can still change it with LEFT/RIGHT.\n\n{}'.format(exc),
                              MessageBox.TYPE_ERROR, timeout=5)

    def _buildChoiceOptions(self, sel):
        desc_map = {}
        for attr in ('description', 'descriptions'):
            d = getattr(sel, attr, None)
            if isinstance(d, dict):
                desc_map = d
                break

        values = []
        try:
            values = list(sel.choices)
        except Exception as exc:
            logger.debug("_buildChoiceOptions: list(sel.choices) failed (%s), "
                         "falling back to raw choices list", exc)
            raw = getattr(sel.choices, 'choices', None)
            if raw:
                for item in raw:
                    values.append(item[0] if isinstance(item, tuple) else item)

        options = []
        for c in values:
            c_str = str(c)
            label = desc_map.get(c, desc_map.get(c_str, c_str))
            options.append((str(label), c_str))
        return options

    def _selectionMade(self, choice, cfg_item):
        if not choice:
            return
        try:
            cfg_item.value = choice[1]
            self.createSetup()
            self.updateColorSwatches()
            self._updatePreviewForCurrentEntry()
        except Exception as exc:
            logger.error("_selectionMade: could not apply choice %r: %s", choice, exc)

    # ─── Virtual Keyboard ────────────────────────────────────────────────────

    def keyText(self):
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        sel = self['config'].getCurrent()
        if sel and len(sel) > 1:
            self.session.openWithCallback(
                self._vkbCallback, VirtualKeyBoard,
                title=sel[0], text=sel[1].value)

    def _vkbCallback(self, value=None):
        if value:
            current = self['config'].getCurrent()
            if current and len(current) > 1:
                current[1].value = value
                self['config'].invalidate(current)

    # ─── Setup List Builder ─────────────────────────────────────────────────

    def createSetup(self):
        try:
            lst = []

            def section(label, color='\\c00ffc107'):
                return getConfigListEntry(color + label)

            def spacer():
                return getConfigListEntry('\\c00ffc107' + '  ')

            # ── General ───────────────────────────────────────────────────
            lst.append(section('SKIN GENERAL SETUP  ' + '─' * 50))
            lst.append(getConfigListEntry(
                'Skin Template:', config.plugins.xDreamy.skinTemplate,
                'Choose the main layout template.'))
            lst.append(getConfigListEntry(
                'Keys Style:', config.plugins.xDreamy.KeysStyle,
                'Select the Colored key graphics (redN.png/greenN.png/etc). Applied on Save.'))
            lst.append(getConfigListEntry(
                'Font Style:', config.plugins.xDreamy.FontStyle,
                'Use "Default" or select "Custom" for your own font.'))
            if config.plugins.xDreamy.FontStyle.value == 'basic':
                lst.append(getConfigListEntry(
                    '  ↳ Font Type:', config.plugins.xDreamy.FontName,
                    'Select a font family.'))
                lst.append(getConfigListEntry(
                    '  ↳ Font Scale:', config.plugins.xDreamy.FontScale,
                    'Adjust all font sizes as a percentage.'))
            lst.append(getConfigListEntry(
                'Date Style:', config.plugins.xDreamy.dateFormat,
                'Choose how dates are displayed. Applied on Save.'))
            lst.append(getConfigListEntry(
                'Clock Style:', config.plugins.xDreamy.clockFormat,
                'Select 12-hour or 24-hour time display. Applied on Save.'))
            lst.append(getConfigListEntry(
                '  ↳ Clock Mode:', config.plugins.xDreamy.clockMode,
                '"Default" keeps the skin\'s built-in clock Color/size/font.'))
            if config.plugins.xDreamy.clockMode.value == 'custom':
                lst.append(getConfigListEntry(
                    '    ↳ Clock Color:', config.plugins.xDreamy.clockColor,
                    'Color of the clock text.'))
                lst.append(getConfigListEntry(
                    '    ↳ Clock Size:', config.plugins.xDreamy.clockSize,
                    'Font size of the clock text.'))
                lst.append(getConfigListEntry(
                    '    ↳ Clock Font:', config.plugins.xDreamy.clockFont,
                    'Registered font family used for the clock.'))
            lst.append(getConfigListEntry(
                'Show in Extensions Menu:', config.plugins.xDreamy.ShowInExtensions,
                'When enabled, this plugin also appears in the Extensions menu.'))

            lst.append(spacer())

            # ── Colors ───────────────────────────────────────────────────
            lst.append(section('SKIN COLOR SETTINGS  ' + '─' * 48))
            lst.append(getConfigListEntry(
                'Color Mode:', config.plugins.xDreamy.colorSelector,
                'Choose "Template" for a coordinated set, or "Custom" individually.'))
            if config.plugins.xDreamy.colorSelector.value == 'default-color':
                lst.append(getConfigListEntry(
                    '  ↳ Color Template:', config.plugins.xDreamy.BasicColorTemplates,
                    'Select a predefined Color theme.'))
                lst.append(getConfigListEntry(
                    '  ↳ Background Transparency:', config.plugins.xDreamy.transparency,
                    'Set how transparent the background panels are.'))
            else:
                # NEW custom color entries: two-step for title and text
                lst.append(getConfigListEntry(
                    '  ↳ Title Color Group:', config.plugins.xDreamy.title_color_group,
                    'Choose Light or Medium for the Title/Header color.'))
                lst.append(getConfigListEntry(
                    '    ↳ Title Color Value:', config.plugins.xDreamy.title_color_value,
                    'Select the actual color for the Title/Header.'))
                lst.append(getConfigListEntry(
                    '  ↳ Text Color Group:', config.plugins.xDreamy.text_color_group,
                    'Choose Light or Medium for the main Text color.'))
                lst.append(getConfigListEntry(
                    '    ↳ Text Color Value:', config.plugins.xDreamy.text_color_value,
                    'Select the actual color for the main Text.'))
                lst.append(getConfigListEntry(
                    '  ↳ Selection Color:', config.plugins.xDreamy.SelectionColor,
                    'Color used for selected items (bluette).'))
                lst.append(getConfigListEntry(
                    '  ↳ Background Color:', config.plugins.xDreamy.BackgroundColor,
                    'Dark background Color for panels (header).'))
                lst.append(getConfigListEntry(
                    '  ↳ Background Transparency:', config.plugins.xDreamy.transparency,
                    'Overrides the alpha channel of the background Color.'))

            # ── Menu Style ────────────────────────────────────────────────
            lst.append(spacer())
            lst.append(section('MENU STYLE  ' + '─' * 54))
            lst.append(getConfigListEntry(
                'Menu Style:', config.plugins.xDreamy.menuTextMode,
                '"Default" keeps the skin\'s built-in menu text Colors.'))
            if config.plugins.xDreamy.menuTextMode.value == 'custom':
                lst.append(getConfigListEntry(
                    '  ↳ Menu Text Color Group:', config.plugins.xDreamy.menu_text_color_group,
                    'Choose Light or Medium for unselected menu text color.'))
                lst.append(getConfigListEntry(
                    '    ↳ Menu Text Color Value:', config.plugins.xDreamy.menu_text_color_value,
                    'Select the actual color for unselected menu text.'))
                lst.append(getConfigListEntry(
                    '  ↳ Menu Selected Text Color Group:', config.plugins.xDreamy.menu_text_selected_color_group,
                    'Choose Light or Medium for selected menu text color.'))
                lst.append(getConfigListEntry(
                    '    ↳ Menu Selected Text Value:', config.plugins.xDreamy.menu_text_selected_color_value,
                    'Select the actual color for selected menu text.'))
                lst.append(getConfigListEntry(
                    '  ↳ Selected Background:', config.plugins.xDreamy.menuBackgroundSelectedColor,
                    'Background Color behind the selected menu entry.'))

            # ── Channels List Style ──────────────────────────────────────
            lst.append(spacer())
            lst.append(section('CHANNELS LIST STYLE  ' + '─' * 48))
            lst.append(getConfigListEntry(
                'Channels List Style:', config.plugins.xDreamy.channelTextMode,
                '"Default" keeps the skin\'s built-in channel list text style.'))
            if config.plugins.xDreamy.channelTextMode.value == 'custom':
                lst.append(getConfigListEntry(
                    '  ↳ Channel Name Color Group:', config.plugins.xDreamy.channel_name_color_group,
                    'Choose Light or Medium for channel name color.'))
                lst.append(getConfigListEntry(
                    '    ↳ Channel Name Color Value:', config.plugins.xDreamy.channel_name_color_value,
                    'Select the actual color for channel names.'))
                lst.append(getConfigListEntry(
                    '  ↳ Channels Font Size:', config.plugins.xDreamy.channelNameFontSize,
                    'Font size of the channel name text.'))
                lst.append(getConfigListEntry(
                    '  ↳ Event Description Color Group:', config.plugins.xDreamy.event_desc_color_group,
                    'Choose Light or Medium for event description color.'))
                lst.append(getConfigListEntry(
                    '    ↳ Event Description Color Value:', config.plugins.xDreamy.event_desc_color_value,
                    'Select the actual color for event descriptions.'))
                lst.append(getConfigListEntry(
                    '  ↳ Event Description Size:', config.plugins.xDreamy.eventDescFontSize,
                    'Font size of the current-event description text.'))
                lst.append(getConfigListEntry(
                    '  ↳ Progress Bar Color:', config.plugins.xDreamy.progressBarColor,
                    'Color of the event progress bar.'))

            lst.append(spacer())

            # ── InfoBar ───────────────────────────────────────────────────
            lst.append(section('INFOBAR  ' + '─' * 57))
            lst.append(getConfigListEntry(
                'InfoBar Style:', config.plugins.xDreamy.InfobarStyle,
                'Select the InfoBar layout.'))
            if config.plugins.xDreamy.InfobarStyle.value == 'InfoBar-HMF':
                lst.append(getConfigListEntry(
                    '  ↳ Header Section:', config.plugins.xDreamy.InfobarH,
                    'Top part of your custom InfoBar.'))
                lst.append(getConfigListEntry(
                    '  ↳ Middle Section:', config.plugins.xDreamy.InfobarM,
                    'Middle portion of your custom InfoBar.'))
                lst.append(getConfigListEntry(
                    '  ↳ Footer Section:', config.plugins.xDreamy.InfobarF,
                    'Bottom part of your custom InfoBar.'))

            lst.append(spacer())
            lst.append(section('SECOND INFOBAR  ' + '─' * 51))
            lst.append(getConfigListEntry(
                'SecondInfoBar Style:', config.plugins.xDreamy.SecondInfobar,
                'Select the SecondInfoBar layout.'))
            if config.plugins.xDreamy.SecondInfobar.value == 'SecondInfobar-HF':
                lst.append(getConfigListEntry(
                    '  ↳ Header Section:', config.plugins.xDreamy.SecondInfobarH,
                    'Top section of your custom SecondInfoBar.'))
                lst.append(getConfigListEntry(
                    '  ↳ Footer Section:', config.plugins.xDreamy.SecondInfobarF,
                    'Bottom section of your custom SecondInfoBar.'))

            lst.append(spacer())

            # ── Channel List ──────────────────────────────────────────────
            lst.append(section('CHANNEL LIST LAYOUT  ' + '─' * 49))
            lst.append(getConfigListEntry(
                'Channels List Style:', config.plugins.xDreamy.ChannSelector,
                'Choose the standard channels list layout.'))
            lst.append(getConfigListEntry(
                'Channels Grid Style:', config.plugins.xDreamy.ChannSelectorGrid,
                'Select the grid-style channels list.'))

            lst.append(spacer())

            # ── Other Screens ─────────────────────────────────────────────
            lst.append(section('OTHER SCREEN STYLES  ' + '─' * 51))
            lst.append(getConfigListEntry(
                'Event View Style:', config.plugins.xDreamy.EventView,
                'Choose the Event Details screen layout.'))
            lst.append(getConfigListEntry(
                'Plugin Browser Style:', config.plugins.xDreamy.PluginBrowser,
                'Select the grid layout for the Plugin Browser.'))
            lst.append(getConfigListEntry(
                'EPG Multi-Selection Style:', config.plugins.xDreamy.EPGMultiSelection,
                'Choose the layout for EPG Multi-Selection.'))
            lst.append(getConfigListEntry(
                'Virtual Keyboard Style:', config.plugins.xDreamy.VirtualKeyboard,
                'Choose the look of the virtual keyboard.'))
            lst.append(getConfigListEntry(
                'Volume Bar Style:', config.plugins.xDreamy.VolumeBar,
                'Select the appearance of the volume bar.'))

            lst.append(spacer())

            # ── Plugin Screens ──────────────────────────────────────────────
            lst.append(section('PLUGIN SCREENS  ' + '─' * 46))
            lst.append(getConfigListEntry(
                'E2Player Style:', config.plugins.xDreamy.E2Player,
                'Select the style for E2Player.'))
            lst.append(getConfigListEntry(
                'History Zap Selector:', config.plugins.xDreamy.HistoryZapSelector,
                'Select the style for the channel-history zap selector.'))
            lst.append(getConfigListEntry(
                'New Virtual Keyboard Style:', config.plugins.xDreamy.NewVirtualKeyboard,
                'Choose the appearance for New Virtual Keyboard.'))
            lst.append(getConfigListEntry(
                'Enhanced Movie Center Style:', config.plugins.xDreamy.EnhancedMovieCenter,
                'Select the style for Enhanced Movie Center.'))

            lst.append(spacer())

            # ── Backgrounds & Boot ────────────────────────────────────────
            lst.append(section('BACKGROUNDS & BOOTLOGO  ' + '─' * 47))
            lst.append(getConfigListEntry(
                'Channels List Background:', config.plugins.xDreamy.ChannelListBackground,
                'Choose the wallpaper behind the channel list.'))
            lst.append(getConfigListEntry(
                'Shutdown / Restart Wallpaper:', config.plugins.xDreamy.TurnOff,
                'Choose the background image for shutdown screens.'))
            lst.append(getConfigListEntry(
                'Random Boot Logos:', config.plugins.xDreamy.bootlogos,
                'Enable random boot logo on each reboot.'))

            lst.append(spacer())

            # ── Data Sources ──────────────────────────────────────────────
            lst.append(section('DATA SOURCES  ' + '─' * 53))
            lst.append(getConfigListEntry(
                'Rating & Parental:', config.plugins.xDreamy.RatingStars,
                'Enable or disable star-rating display.'))
            lst.append(getConfigListEntry(
                'ON Screen Clock:', config.plugins.xDreamy.SubtitlesClock,
                'Show a small clock overlay while subtitles are active.'))
            lst.append(getConfigListEntry(
                'Crypt Display (InfoBar):', config.plugins.xDreamy.crypt,
                'Choose CAM name or graphical bar.'))

            lst.append(spacer())

            # ── EPG Translate ────────────────────────────────────────────
            lst.append(section('EPG TRANSLATE  ' + '─' * 51))
            lst.append(getConfigListEntry(
                'Enable EPG Translation:', config.plugins.xDreamy.epg_translate_enabled,
                'Translate EPG event names/descriptions using an online provider.'))
            if config.plugins.xDreamy.epg_translate_enabled.value:
                lst.append(getConfigListEntry(
                    '  ↳ Provider:', config.plugins.xDreamy.epg_translate_provider,
                    'Translation service to use.'))
                lst.append(getConfigListEntry(
                    '  ↳ Target Language:', config.plugins.xDreamy.epg_translate_target_lang,
                    'Language to translate EPG text into.'))
                lst.append(getConfigListEntry(
                    '  ↳ Cache Duration:', config.plugins.xDreamy.epg_translate_cache_ttl,
                    'How long a translated string is reused before re-translating.'))
                provider = config.plugins.xDreamy.epg_translate_provider.value
                if provider == 'google':
                    lst.append(getConfigListEntry(
                        '  ↳ Google API Key (optional):', config.plugins.xDreamy.epg_translate_google_api_key,
                        'Leave blank to use the free (rate-limited) Google Translate endpoint.'))
                    lst.append(getConfigListEntry(
                        '    ↳ Import Key from File (OK):', config.plugins.xDreamy.epg_translate_google_key_import,
                        'Press OK to browse for a .txt file containing the key on its first line.'))
                elif provider == 'gemini':
                    lst.append(getConfigListEntry(
                        '  ↳ Gemini API Key:', config.plugins.xDreamy.epg_translate_gemini_api_key,
                        'Required for the Gemini provider.'))
                    lst.append(getConfigListEntry(
                        '    ↳ Import Key from File (OK):', config.plugins.xDreamy.epg_translate_gemini_key_import,
                        'Press OK to browse for a .txt file containing the key on its first line.'))
                elif provider == 'groq':
                    lst.append(getConfigListEntry(
                        '  ↳ Groq API Key:', config.plugins.xDreamy.epg_translate_groq_api_key,
                        'Required for the Groq provider.'))
                    lst.append(getConfigListEntry(
                        '    ↳ Import Key from File (OK):', config.plugins.xDreamy.epg_translate_groq_key_import,
                        'Press OK to browse for a .txt file containing the key on its first line.'))

#            lst.append(spacer())
#
#            # ── CHANNEL SERVER-COLOR ─────────────────────────────────────
#            lst.append(section('COLOR SERVER CHANNELS  ' + '─' * 42))
#            lst.append(getConfigListEntry(
#                'Color Decrypt Channel (Under Processing):', config.plugins.xDreamy.channelcolor_enabled,
#                'Colors the currently-playing channel name based on how it is being decrypted '
#                '(local card / local emulator / cccam / other network sharing) and records '
#                'confirmed channels to ServerChannels.json.'))
#            if config.plugins.xDreamy.channelcolor_enabled.value:
#                lst.append(getConfigListEntry(
#                    '  ↳ Local Smartcard Color:', config.plugins.xDreamy.color_local,
#                    'Hex color (RRGGBB) for channels decrypted by a local smartcard reader.'))
#                lst.append(getConfigListEntry(
#                    '  ↳ Local Emulator Color:', config.plugins.xDreamy.color_emu,
#                    'Hex color (RRGGBB) for channels decrypted by a local emulator (OSCam/NCam/etc).'))
#                lst.append(getConfigListEntry(
#                    '  ↳ CCcam Network Color:', config.plugins.xDreamy.color_cccam,
#                    'Hex color (RRGGBB) for channels decrypted via CCcam network sharing.'))
#                lst.append(getConfigListEntry(
#                    '  ↳ Other Network Color:', config.plugins.xDreamy.color_network,
#                    'Hex color (RRGGBB) for channels decrypted via any other network sharing method.'))

            lst.append(spacer())

            # ── TMDB LANGUAGE & API ───────────────────────────────────────
            lst.append(section('TMDB LANGUAGE & API  ' + '─' * 40))
            lst.append(getConfigListEntry(
                'Show TMDB Options:', config.plugins.xDreamy.tmdb_enabled,
                'Toggle visibility of TMDB language and API key sub-options. Does NOT affect downloads.'))
            if config.plugins.xDreamy.tmdb_enabled.value:
                lst.append(getConfigListEntry(
                    '  ↳ TMDB Language:', config.plugins.xDreamy.tmdb_language,
                    'Language for TMDB metadata. Applied instantly.'))
                lst.append(getConfigListEntry(
                    '  ↳ TMDB API Key:', config.plugins.xDreamy.tmdb_api_key,
                    'TMDB API key for metadata lookups.'))

            lst.append(spacer())

            # ── Posters / Backdrops / Logos ───────────────────────────────
            lst.append(section('POSTERS, BACKDROPS & LOGOS  ' + '─' * 40))
            lst.append(getConfigListEntry(
                'Enable Poster Downloads:', config.plugins.xDreamy.posterx_enabled,
                'Enable or disable live poster downloads.'))
            lst.append(getConfigListEntry(
                'Enable Backdrop Downloads:', config.plugins.xDreamy.backdropx_enabled,
                'Enable or disable live backdrop downloads.'))
            lst.append(getConfigListEntry(
                'Enable Logo Downloads:', config.plugins.xDreamy.logox_enabled,
                'Enable or disable live logo downloads.'))
            lst.append(getConfigListEntry(
                'Storage Mode:', config.plugins.xDreamy.storage_mode,
                'Auto-detect storage or specify a custom path.'))
            if config.plugins.xDreamy.storage_mode.value == "custom":
                lst.append(getConfigListEntry(
                    '  ↳ Custom Path (press Yellow):', config.plugins.xDreamy.storage_custom_path,
                    'Press Yellow to browse, or OK to type path manually.'))
            lst.append(getConfigListEntry(
                'Worker Threads:', config.plugins.xDreamy.worker_threads,
                'Number of parallel download threads.'))
            lst.append(getConfigListEntry(
                'Auto-Remove Old Files:', config.plugins.xDreamy.auto_remove_enabled,
                'Automatically remove old poster/backdrop/logo files.'))
            if config.plugins.xDreamy.auto_remove_enabled.value:
                lst.append(getConfigListEntry(
                    '  ↳ Remove After (days):', config.plugins.xDreamy.auto_remove_days,
                    'Number of days to keep files before auto-removal.'))
            lst.append(getConfigListEntry(
                'Clear Image Cache (OK):', config.plugins.xDreamy.png,
                'Press OK to delete all cached images (with confirmation).'))

            lst.append(spacer())

            # ── Backup / Restore ──────────────────────────────────────────
            lst.append(section('BACKUP & RESTORE  ' + '─' * 47))
            lst.append(getConfigListEntry(
                'Backup current settings (OK)', config.plugins.xDreamy.backup_action,
                'Press OK to backup skin.xml to /XDREAMY/backup/'))
            lst.append(getConfigListEntry(
                'Restore a backup (OK)', config.plugins.xDreamy.restore_action,
                'Press OK to restore skin.xml from /XDREAMY/backup/'))

            lst.append(spacer())

            # ── Debug Logging ────────────────────────────────────────────
            lst.append(section('DEBUG LOGGING  ' + '─' * 49))
            lst.append(getConfigListEntry(
                'Enable Debug Logging:', config.plugins.xDreamy.debug_master,
                'Master switch. Must be ON for any of the per-module toggles below '
                'to actually produce a log file. Each enabled module writes to its '
                'own file in /tmp/, e.g. /tmp/iAccess_Debug.log - send these to the '
                'developer when reporting an issue.'))
            if config.plugins.xDreamy.debug_master.value:
                for _dbg_name in DEBUG_MODULES:
                    lst.append(getConfigListEntry(
                        '  \u21b3 %s' % _dbg_name, getattr(config.plugins.xDreamy, "dbg_%s" % _dbg_name),
                        'Writes /tmp/%s_Debug.log while this and the master switch above are both ON.' % _dbg_name))

            lst.append(getConfigListEntry(
                'Check Dependences (OK)', config.plugins.xDreamy.check_requirements_action,
                'Re-checks sqlite3/requests/wget and offers to install anything missing - '
                'useful after a fresh image flash or if downloads have stopped working.'))

            lst.append(spacer())

            # ── Tools Box ─────────────────────────────────────────────────
            lst.append(getConfigListEntry('\\c00ffc107' + '=' * 65))
            lst.append(getConfigListEntry('\\c00ff5400' + '                        XDREAMY TOOLS BOX              '))
            lst.append(getConfigListEntry('\\c00ffc107' + '=' * 65))

            lst.append(getConfigListEntry('\\c0056c856' + '  Panel Plugins:'))
            lst.append(getConfigListEntry("    AJPanel",           config.plugins.xDreamy.install_ajpanel,        'AJPanel control panel.'))
            lst.append(getConfigListEntry("    Linuxsat Panel",    config.plugins.xDreamy.install_linuxsatpanel,  'LinuxsatPanel management tool.'))
            lst.append(getConfigListEntry("    Ciefp Plugins",     config.plugins.xDreamy.install_CiefpPlugins,   'Ciefp Plugins Panel.'))
            lst.append(getConfigListEntry("    SmartAddons Panel", config.plugins.xDreamy.install_smartpanel,     'SmartPanel.'))
            lst.append(getConfigListEntry("    Magic Panel",       config.plugins.xDreamy.install_magicpanel,     'MagicPanel.'))
            lst.append(getConfigListEntry("    KeyAdder",          config.plugins.xDreamy.install_keyadder,       'KeyAdder for SoftCam key updates.'))

            lst.append(spacer())
            lst.append(getConfigListEntry('\\c0056c856' + '  Media Plugins:'))
            lst.append(getConfigListEntry("    X-Klass",           config.plugins.xDreamy.install_xklass,         'X-Klass IPTV streaming plugin.'))
            lst.append(getConfigListEntry("    YouTube",           config.plugins.xDreamy.install_youtube,        'YouTube plugin.'))
            lst.append(getConfigListEntry("    E2iPlayer",         config.plugins.xDreamy.install_e2iplayer,      'E2iPlayer IPTV player.'))
            lst.append(getConfigListEntry("    Transmission",      config.plugins.xDreamy.install_transmission,   'Transmission BitTorrent client.'))

            lst.append(spacer())
            lst.append(getConfigListEntry('\\c0056c856' + '  Utility Plugins:'))
            lst.append(getConfigListEntry("    IPAudioPro",           config.plugins.xDreamy.install_ipaudiopro,        'IPAudioPro audio tracks plugin.'))
            lst.append(getConfigListEntry("    EPG Grabber",          config.plugins.xDreamy.install_EPGGrabber,        'EPG Grabber.'))
            lst.append(getConfigListEntry("    SubsSupport",          config.plugins.xDreamy.install_subssupport,       'SubsSupport subtitle plugin.'))
            lst.append(getConfigListEntry("    SubsSupport Pro",      config.plugins.xDreamy.install_subssupportpro,    'SubsSupport Pro.'))
            lst.append(getConfigListEntry("    HistoryZapSelector",   config.plugins.xDreamy.install_historyzapselector,'HistoryZapSelector.'))
            lst.append(getConfigListEntry("    New Virtual Keyboard", config.plugins.xDreamy.install_newvirtualkeyboard,'New Virtual Keyboard.'))
            lst.append(getConfigListEntry("    RaedQuickSignal",      config.plugins.xDreamy.install_raedquicksignal,   'RaedQuickSignal signal monitor.'))

            self['config'].list = lst
            self['config'].l.setList(lst)
            self.updateHelpText()
            self._updatePreviewForCurrentEntry()

        except Exception as exc:
            logger.error("createSetup error: %s", exc)

    # ─── Changed Entry ──────────────────────────────────────────────────────

    def changedEntry(self):
        try:
            current = self['config'].getCurrent()
            if current and len(current) > 1:
                if isinstance(current[1], (ConfigOnOff, ConfigYesNo, ConfigSelection)):
                    self.createSetup()
                    self._updatePreviewForCurrentEntry()
        except Exception as exc:
            logger.error("changedEntry: %s", exc)

    def getCurrentEntry(self):
        c = self['config'].getCurrent()
        return c[0] if c else ''

    def getCurrentValue(self):
        c = self['config'].getCurrent()
        return str(c[1].getText()) if (c and len(c) > 1) else ''

    def createSummary(self):
        from Screens.Setup import SetupSummary
        return SetupSummary

    # ─── Backup / Restore Actions ────────────────────────────────────────────

    def _do_backup(self):
        backup_dir = _backup_dir()
        self.session.openWithCallback(
            self._backup_done, MessageBox,
            "This will backup your current skin.xml file to:\n%s\n\nContinue?" % backup_dir,
            MessageBox.TYPE_YESNO, default=False,
        )

    def _backup_done(self, confirmed):
        if not confirmed:
            return
        ok, msg = do_backup()
        self.session.open(
            MessageBox, msg,
            MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR,
            timeout=10,
        )
        self._update_status()

    def _do_restore(self):
        latest = _find_latest_backup()
        if not latest:
            self.session.open(MessageBox,
                "No backup file found in /XDREAMY/backup/\n"
                "Please create a backup first.",
                MessageBox.TYPE_ERROR)
            return
        self.session.openWithCallback(
            lambda confirmed: self._do_restore_confirm(confirmed, latest),
            MessageBox,
            "Restore from:\n%s\n\nThis will overwrite your current skin.xml." % os.path.basename(latest),
            MessageBox.TYPE_YESNO, default=False,
        )

    def _do_restore_confirm(self, confirmed, zip_path):
        if not confirmed:
            return
        ok, msg = do_restore(zip_path)
        self.session.open(
            MessageBox, msg,
            MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR,
            timeout=5,
        )
        self._update_status()

    def _check_requirements(self):
        run_requirements_flow(self.session, self._update_status)

    # ─── Yellow Key ──────────────────────────────────────────────────────────

    def keyYellowAction(self):
        current = self['config'].getCurrent()
        if (current and len(current) > 1
                and current[1] is config.plugins.xDreamy.storage_custom_path):
            self._browseStoragePath()
            return
        root = _resolve_storage_path()
        self.session.open(XDREAMYActionMenu, root, self._update_status)

    # ─── Info Box ────────────────────────────────────────────────────────────

    def showInfo(self):
        msg = (
            "XDREAMY Skin v{version}\n\n"
            "A fully customisable Enigma2 skin created by Inspiron.\n"
            "Rework and enhancements by M.Hussein.\n\n"
            "Features:\n"
            "- TMDB metadata in your preferred language\n"
            "- Automatic poster and backdrop downloads\n"
            "- Smart storage management\n"
            "- Backup and restore\n\n"
            "Supported images:\n"
            "Egami, OpenATV, OpenSPA, PurE2, OpenDroid, OpenBH, Alliance,\n"
            "OpenPLi, OpenVIX, OpenHDF, OpenTR, Foxbob, TNAP, PLi-based images.\n\n"
            "Forum support: https://web.telegram.org/a/#-1002526851239"
        ).format(version=VERSION)
        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=12)

    # ─── Save ────────────────────────────────────────────────────────────────

    def keySave(self):
        try:
            # ── Phase 1: Apply settings to source files ───────────────────
            if config.plugins.xDreamy.bootlogos.value:
                if not fileExists(MVI_PATH + 'bootlogoBack.mvi'):
                    shutil.copy(MVI_PATH + 'bootlogo.mvi', MVI_PATH + 'bootlogoBack.mvi')
            else:
                if fileExists(MVI_PATH + 'bootlogoBack.mvi'):
                    shutil.copy(MVI_PATH + 'bootlogoBack.mvi', MVI_PATH + 'bootlogo.mvi')
                    os.remove(MVI_PATH + 'bootlogoBack.mvi')

            if config.plugins.xDreamy.FontStyle.value == 'basic':
                update_font_settings(
                    config.plugins.xDreamy.FontName.value,
                    config.plugins.xDreamy.FontScale.value
                )
            else:
                update_font_settings('Verdana.ttf', '100')

            if config.plugins.xDreamy.colorSelector.value == 'default-color':
                apply_template(config.plugins.xDreamy.BasicColorTemplates.value)
            else:
                apply_custom_colors()

            apply_date_format()
            apply_keys_style()
            apply_clock_format()
            apply_channel_text_style()
            apply_menu_text_style()
            apply_renderer_config()

            for entry in self['config'].list:
                if len(entry) > 1:
                    try:
                        entry[1].save()
                    except Exception:
                        pass
            configfile.save()
            os.system("sync")
            logger.info("keySave: config saved")

        except Exception as exc:
            logger.error("keySave (phase 1): %s", exc)

        # ── Phase 2: Rebuild skin.xml from source parts ───────────────────
        try:
            skin_parts = [
                'head-{}.xml'.format(config.plugins.xDreamy.head.value),
                'TP-{}.xml'.format(config.plugins.xDreamy.skinTemplate.value),
                'infobar-{}.xml'.format(config.plugins.xDreamy.InfobarStyle.value),
                'secondinfobar-{}.xml'.format(config.plugins.xDreamy.SecondInfobar.value),
                'CHL-{}.xml'.format(config.plugins.xDreamy.ChannSelector.value),
                'CHLG-{}.xml'.format(config.plugins.xDreamy.ChannSelectorGrid.value),
                'CLB-{}.xml'.format(config.plugins.xDreamy.ChannelListBackground.value),
                'CLB1-{}.xml'.format(config.plugins.xDreamy.TurnOff.value),
                'EV-{}.xml'.format(config.plugins.xDreamy.EventView.value),
                'vol-{}.xml'.format(config.plugins.xDreamy.VolumeBar.value),
                'VKB-{}.xml'.format(config.plugins.xDreamy.VirtualKeyboard.value),
                'NVKB-{}.xml'.format(config.plugins.xDreamy.NewVirtualKeyboard.value),
                'PB-{}.xml'.format(config.plugins.xDreamy.PluginBrowser.value),
                'HZS-{}.xml'.format(config.plugins.xDreamy.HistoryZapSelector.value),
                'EPG-{}.xml'.format(config.plugins.xDreamy.EPGMultiSelection.value),
                'E2Player-{}.xml'.format(config.plugins.xDreamy.E2Player.value),
                'EMC-{}.xml'.format(config.plugins.xDreamy.EnhancedMovieCenter.value),
                'SC-{}.xml'.format(config.plugins.xDreamy.SubtitlesClock.value),
                'RS-{}.xml'.format(config.plugins.xDreamy.RatingStars.value),
                'CRY-{}.xml'.format(config.plugins.xDreamy.crypt.value),
                'WS-{}.xml'.format(config.plugins.xDreamy.WeatherSource.value),
            ]
            if config.plugins.xDreamy.InfobarStyle.value == 'InfoBar-HMF':
                skin_parts += [
                    'IH-{}.xml'.format(config.plugins.xDreamy.InfobarH.value),
                    'IM-{}.xml'.format(config.plugins.xDreamy.InfobarM.value),
                    'IF-{}.xml'.format(config.plugins.xDreamy.InfobarF.value),
                ]
            if config.plugins.xDreamy.SecondInfobar.value == 'SecondInfobar-HF':
                skin_parts += [
                    'SIH-{}.xml'.format(config.plugins.xDreamy.SecondInfobarH.value),
                    'SIF-{}.xml'.format(config.plugins.xDreamy.SecondInfobarF.value),
                ]

            lines   = []
            missing = []
            for fname in skin_parts:
                fpath = os.path.join(self.previewFiles, fname)
                if os.path.isfile(fpath):
                    with open(fpath, 'r') as fh:
                        lines.extend(fh.readlines())
                else:
                    missing.append(fname)

            base_key   = config.plugins.xDreamy.skinSelector.value
            base_fname = (
                'base{}.xml'.format(base_key[-1])
                if base_key.startswith('base') and base_key not in ('base', 'base0')
                else 'base.xml'
            )
            base_path = os.path.join(self.previewFiles, base_fname)
            if os.path.isfile(base_path):
                with open(base_path, 'r') as fh:
                    lines.extend(fh.readlines())

            if not lines:
                raise RuntimeError("No skin content assembled – check sample directory.")

            with open(self.skinFile, 'w') as fh:
                fh.writelines(lines)
            os.system("sync")
            logger.info("keySave: skin.xml rebuilt (%d lines) from parts: %s", len(lines), skin_parts)

            warn = ''
            if missing:
                warn = '\n\n⚠ Missing parts (skipped):\n' + '\n'.join(missing)

            # Check if restart is required
            restart_required = self._check_restart_required()

            if _fast_skin_reload_active() and not restart_required:
                try:
                    from skin import reloadSkins
                    reloadSkins()
                    for plugin in plugins.getPlugins(PluginDescriptor.WHERE_SKINCHANGE):
                        try:
                            plugin(session=self.session)
                        except Exception as e:
                            logger.debug("keySave: WHERE_SKINCHANGE plugin notify failed: %s", e)
                    self.session.reloadDialogs()
                    logger.info("keySave: skin applied instantly via reloadSkins()")
                    self.session.openWithCallback(
                        lambda _: self.close(),
                        MessageBox,
                        'Skin saved and applied instantly.{}'.format(warn),
                        MessageBox.TYPE_INFO,
                        timeout=5,
                    )
                except Exception as e:
                    logger.error("keySave: reloadSkins() failed, falling back to restart prompt: %s", e)
                    self.session.openWithCallback(
                        self._restartGUI,
                        MessageBox,
                        'Skin saved.{}\n\nInstant apply failed -- a GUI restart is needed.\nRestart now?'.format(warn),
                        MessageBox.TYPE_YESNO
                    )
            else:
                restart_msg = 'A GUI restart is needed to apply all changes.'
                if restart_required:
                    restart_msg = 'Changes to renderers/converters require a GUI restart.'
                self.session.openWithCallback(
                    self._restartGUI,
                    MessageBox,
                    'Skin saved.{}\n\n{}\nRestart now?'.format(warn, restart_msg),
                    MessageBox.TYPE_YESNO
                )

        except Exception as exc:
            logger.error("keySave (phase 2 – skin rebuild): %s", exc)
            self.session.open(
                MessageBox,
                'Error building skin.xml:\n{}'.format(str(exc)),
                MessageBox.TYPE_ERROR
            )

    def _restartGUI(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    # ─── Update Check (non-blocking) ─────────────────────────────────────────

    def checkForUpdate(self):
        self._update_result = None
        t = threading.Thread(target=self._fetchUpdateInfo, name='xDreamy-UpdateCheck')
        t.daemon = True
        t.start()
        self._update_check_timer = eTimer()
        self._update_check_timer.callback.append(self._processUpdateResult)
        self._update_check_timer.start(12000, True)

    def _fetchUpdateInfo(self):
        ver_url = ('https://raw.githubusercontent.com/Insprion80/Skins/'
                   'main/xDreamy/xDreamyv.txt')
        try:
            req = Request(ver_url)
            req.add_header('User-Agent',
                           'Mozilla/5.0 (compatible; xDreamy/{})'.format(VERSION))
            raw = urlopen(req, timeout=8).read().decode('utf-8').strip()
            if '#' not in raw:
                logger.warning("checkForUpdate: unexpected format: %r", raw)
                return
            server_ver, update_url = raw.split('#', 1)
            self._update_result = (server_ver.strip(), update_url.strip())
            logger.info("checkForUpdate: server=%s", server_ver.strip())
        except Exception as exc:
            logger.error("checkForUpdate error: %s", exc)

    def _processUpdateResult(self):
        if getattr(self, '_closed', False):
            return
        if not self._update_result:
            return
        server_ver, update_url = self._update_result
        self._update_url = update_url
        if _version_tuple(server_ver) > _version_tuple(VERSION):
            self.session.openWithCallback(
                self._doUpdate,
                MessageBox,
                'Update available!\n\nServer version : {sv}\nYour version  : {lv}\n\n'
                'Download and install now?'.format(sv=server_ver, lv=VERSION),
                MessageBox.TYPE_YESNO
            )
        elif _version_tuple(server_ver) == _version_tuple(VERSION):
            logger.info("checkForUpdate: already up to date (%s)", VERSION)
        else:
            self.session.open(
                MessageBox,
                'You are running a development version ({}).'.format(VERSION),
                MessageBox.TYPE_INFO, timeout=4
            )

    def _doUpdate(self, answer):
        if answer:
            self.session.open(xDreamyUpdater, self._update_url)


# ─────────────────────────────────────────────────────────────────────────────
#  UPDATER SCREEN
# ─────────────────────────────────────────────────────────────────────────────

class xDreamyUpdater(Screen):

    skin = '''
        <screen name="xDreamyUpdater" position="center,center" size="840,280"
                flags="wfBorder" backgroundColor="background">
            <widget name="status" position="20,10" size="800,70" transparent="1"
                    font="Regular; 38" foregroundColor="foreground"
                    backgroundColor="background" valign="center" halign="left"/>
            <widget source="progress" render="Progress"
                    position="20,120" size="800,22" transparent="1"
                    borderWidth="0" foregroundColor="white" backgroundColor="background"/>
            <widget source="progresstext" render="Label"
                    position="200,160" size="440,60" zPosition="2"
                    font="Regular; 26" halign="center" transparent="1"
                    foregroundColor="foreground" backgroundColor="background"/>
        </screen>
    '''

    def __init__(self, session, update_url):
        Screen.__init__(self, session)
        self._url    = update_url
        self._dlfile = '/tmp/xDreamy.ipk'
        self._dl     = None

        self['status']       = Label('Starting download…')
        self['progress']     = Progress()
        self['progresstext'] = StaticText()

        self.onLayoutFinish.append(self._startDownload)

    def _startDownload(self):
        logger.info("xDreamyUpdater: downloading %s → %s", self._url, self._dlfile)
        self['status'].setText('Downloading XDREAMY Skin update…')
        self._dl = downloadWithProgress(self._url, self._dlfile)
        self._dl.addProgress(self._onProgress)
        self._dl.start().addCallback(self._onFinished).addErrback(self._onFailed)

    def _onProgress(self, recv, total):
        if total > 0:
            pct = int(100 * recv / float(total))
            self['progress'].value = pct
            self['progresstext'].text = (
                '{recv:.1f} KB of {total:.1f} KB  ({pct}%)'
            ).format(recv=recv / 1024, total=total / 1024, pct=pct)

    def _onFinished(self, _=''):
        logger.info("xDreamyUpdater: download complete, installing…")
        self['status'].setText('Installing update, please wait…')
        ret = os.system(
            'opkg install --force-reinstall --force-overwrite "{}"'.format(self._dlfile)
        )
        os.system('sync')
        try:
            os.remove(self._dlfile)
        except Exception:
            pass
        if ret == 0:
            self.session.openWithCallback(
                self._restartGUI,
                MessageBox,
                'XDREAMY has been updated successfully!\nRestart the GUI now?',
                MessageBox.TYPE_YESNO
            )
        else:
            self.session.open(
                MessageBox,
                'Installation failed (opkg exit code {}).\n'
                'Please try again or install manually.'.format(ret),
                MessageBox.TYPE_ERROR
            )

    def _onFailed(self, failure=None, error_msg=''):
        if failure:
            error_msg = failure.getErrorMessage()
        logger.error("xDreamyUpdater: download failed: %s", error_msg)
        self['status'].setText('Download failed: {}'.format(error_msg))

    def _restartGUI(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()