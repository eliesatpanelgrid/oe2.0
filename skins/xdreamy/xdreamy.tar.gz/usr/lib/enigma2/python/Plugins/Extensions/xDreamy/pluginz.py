# -*- coding: utf-8 -*-
# mod by Lululla
# mod by M.Hussein using AI
# Revised and corrected version

import os
import random
import sys
import time
import shutil
import glob
import re
import gettext
import locale
import xml.etree.ElementTree as ET
from urllib.request import Request, urlopen
from . import _
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import (
    configfile,
    ConfigOnOff,
    NoSave,
    ConfigText,
    ConfigSelection,
    ConfigSubsection,
    ConfigYesNo,
    config,
    getConfigListEntry,
    ConfigNothing,
)
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.Progress import Progress
from Components.Sources.StaticText import StaticText
from enigma import eTimer, loadPic
try:
    from PIL import Image
except ImportError:
    import Image  # ✅ Fixed import fallback
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Tools.Directories import fileExists, SCOPE_PLUGINS, resolveFilename
from Tools.Downloader import downloadWithProgress
from Screens.ChoiceBox import ChoiceBox
from Screens.LocationBox import LocationBox
from enigma import gFont
import logging
from logging.handlers import RotatingFileHandler

# Add missing imports for network requests with timeout support
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

# Set up logging
log_file = '/tmp/XDREAMY_Plugin.log'
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        RotatingFileHandler(log_file, maxBytes=1024*1024, backupCount=5),  # 1MB per file, max 5 files
        logging.StreamHandler()  # Also log to console
    ]
)
logger = logging.getLogger(__name__)

# Update the localization setup
plugin_name = "xDreamy"
locale_path = resolveFilename(SCOPE_PLUGINS, f"Extensions/{plugin_name}/locale")
gettext.bindtextdomain(plugin_name, locale_path)
gettext.textdomain(plugin_name)
_ = gettext.gettext

# Check if running on Python 3
PY3 = sys.version_info.major >= 3

# Plugin version
version = "6.3.0"  # New Merge
my_cur_skin = False
cur_skin = config.skin.primary_skin.value.replace('xDreamy/skin.xml', '')

# ✅ Fixed paths using os.path.join for better cross-platform compatibility
OAWeather = resolveFilename(SCOPE_PLUGINS, "Extensions/OAWeather")
weatherz = resolveFilename(SCOPE_PLUGINS, "Extensions/WeatherPlugin")
mvi = '/usr/share/'
bootlog = os.path.join(resolveFilename(SCOPE_PLUGINS, "Extensions/xDreamy"), "bootlogos")
logopath = '/etc/enigma2/'

# ✅ Fixed API key paths using os.path.join
tmdb_skin = os.path.join(mvi, "enigma2", cur_skin, "apikey")
tmdb_api = "3c3efcf47c3577558812bb9d64019d65"
omdb_skin = os.path.join(mvi, "enigma2", cur_skin, "omdbkey")
omdb_api = "cb1d9f55"
thetvdb_skin = os.path.join(mvi, "enigma2", cur_skin, "thetvdbkey")
thetvdb_api = "a99d487bb3426e5f3a60dea6d3d3c7ef"
fanart_skin = os.path.join(mvi, "enigma2", cur_skin, "fanartkey")
fanart_api = "6d231536dea4318a88cb2520ce89473b"

# ✅ Improved API key loading with better error handling
def load_api_keys():
    """Load API keys from skin paths with improved error handling."""
    global my_cur_skin, tmdb_api, omdb_api, thetvdb_api, fanart_api
    
    try:
        if not my_cur_skin:
            skin_paths = {
                "tmdb_api": os.path.join("/usr/share/enigma2", cur_skin, "apikey"),
                "omdb_api": os.path.join("/usr/share/enigma2", cur_skin, "omdbkey"),
                "thetvdb_api": os.path.join("/usr/share/enigma2", cur_skin, "thetvdbkey"),
                "fanart_api": os.path.join("/usr/share/enigma2", cur_skin, "fanartkey"),
            }
            
            for key, path in skin_paths.items():
                if fileExists(path):
                    try:
                        with open(path, "r") as f:
                            value = f.read().strip()
                            if value and len(value) > 10:  # Basic validation
                                if key == "tmdb_api":
                                    tmdb_api = value
                                    config.plugins.xDreamy.api.setValue(True)
                                elif key == "omdb_api":
                                    omdb_api = value
                                    config.plugins.xDreamy.api2.setValue(True)
                                elif key == "thetvdb_api":
                                    thetvdb_api = value
                                    config.plugins.xDreamy.api3.setValue(True)
                                elif key == "fanart_api":
                                    fanart_api = value
                                    config.plugins.xDreamy.api4.setValue(True)
                    except IOError as e:
                        logger.error(_("Error reading API key from {path}: {error}").format(path=path, error=e))
            my_cur_skin = True
    except Exception as e:
        logger.error(_("Error loading API keys: {error}").format(error=e))
        my_cur_skin = False

# Load API keys on import
load_api_keys()

def isMountedInRW(path):
    """Check if the given path is mounted in read-write mode."""
    if not os.path.exists(path):
        return False
        
    testfile = os.path.join(path, 'tmp-rw-test')
    try:
        with open(testfile, 'w') as f:
            f.write('test')
        os.remove(testfile)
        return True
    except Exception as e:
        logger.error(_("Error checking RW mount for {path}: {error}").format(path=path, error=e))
        return False

# ✅ Improved path selection logic
def get_optimal_storage_path():
    """Get the best available storage path for poster/backdrop cache."""
    storage_options = [
        "/media/hdd/XDREAMY",
        "/media/usb/XDREAMY", 
        "/media/mmc/XDREAMY",
        "/tmp/XDREAMY"
    ]
    
    for base_path in storage_options:
        parent_dir = os.path.dirname(base_path)
        if os.path.exists(parent_dir) and isMountedInRW(parent_dir):
            return base_path
    
    return "/tmp/XDREAMY"  # Fallback

# Get optimal paths
optimal_path = get_optimal_storage_path()
path_poster = os.path.join(optimal_path, "poster")
patch_backdrop = os.path.join(optimal_path, "backdrop")

# Create directories if they don't exist
for directory in [path_poster, patch_backdrop]:
    try:
        os.makedirs(directory, exist_ok=True)
    except OSError as e:
        logger.error(_("Failed to create directory {directory}: {error}").format(directory=directory, error=e))

def removePng():
    """Remove all PNG and JPG files from the poster and backdrop directories."""
    logger.info(_('Removing PNG and JPG files...'))
    for folder in [path_poster, patch_backdrop]:
        if os.path.exists(folder):
            for ext in ["*.png", "*.jpg", "*.jpeg"]:  # Added JPEG
                files = glob.glob(os.path.join(folder, ext))
                for file in files:
                    try:
                        os.remove(file)
                        logger.debug(_("Removed: {file}").format(file=file))
                    except Exception as e:
                        logger.error(_("Error removing {file}: {error}").format(file=file, error=e))
        else:
            logger.warning(_("Folder {folder} does not exist.").format(folder=folder))

# Configuration settings for the plugin
config.plugins.xDreamy = ConfigSubsection()
config.plugins.xDreamy.ShowInExtensions = ConfigYesNo(default=False)
config.plugins.xDreamy.png = NoSave(ConfigYesNo(default=False))
config.plugins.xDreamy.header = NoSave(ConfigNothing())
config.plugins.xDreamy.weather = NoSave(ConfigSelection(['-> Ok']))
config.plugins.xDreamy.oaweather = NoSave(ConfigSelection(['-> Ok']))
config.plugins.xDreamy.city = ConfigText(default='', visible_width=50, fixed_size=False)
config.plugins.xDreamy.actapi = NoSave(ConfigOnOff(default=False))
config.plugins.xDreamy.data = NoSave(ConfigOnOff(default=False))
config.plugins.xDreamy.api = ConfigYesNo(default=False)
config.plugins.xDreamy.txtapi = ConfigText(default=tmdb_api, visible_width=50, fixed_size=False)
config.plugins.xDreamy.data2 = NoSave(ConfigOnOff(default=False))
config.plugins.xDreamy.api2 = ConfigYesNo(default=False)
config.plugins.xDreamy.txtapi2 = ConfigText(default=omdb_api, visible_width=50, fixed_size=False)
config.plugins.xDreamy.data3 = NoSave(ConfigOnOff(default=False))
config.plugins.xDreamy.api3 = ConfigYesNo(default=False)
config.plugins.xDreamy.txtapi3 = ConfigText(default=thetvdb_api, visible_width=50, fixed_size=False)
config.plugins.xDreamy.data4 = NoSave(ConfigOnOff(default=False))
config.plugins.xDreamy.api4 = ConfigYesNo(default=False)
config.plugins.xDreamy.txtapi4 = ConfigText(default=fanart_api, visible_width=50, fixed_size=False)
config.plugins.xDreamy.bootlogos = ConfigOnOff(default=False)
config.plugins.xDreamy.enablePosterX = ConfigYesNo(default=True)

# Add new config entries for plugin installations
plugin_names = [
    "ajpanel", "linuxsatpanel", "CiefpPlugins", "smartpanel", "elisatpanel", "magicpanel",
    "msnweather", "oaweather", "multicammanager", "NCam", "keyadder",
    "xklass", "youtube", "e2iplayer", "ipaudiopro", "transmission",
    "multistalkerpro", "EPGGrabber", "subssupport", "historyzapselector",
    "newvirtualkeyboard", "raedquicksignal"
]
for plugin in plugin_names:
    setattr(config.plugins.xDreamy, f"install_{plugin}", NoSave(ConfigYesNo(default=False)))

# ✅ Cleaned up TEMPLATES dictionary - removed duplicates
TEMPLATES = {
    # Classic Base Colors
    'Blue': ('#caf0f8', '#023e8a', '#0003045e'),
    'Blue1': ('#9eb3c2', '#1b3b6f', '#0021295c'),
    'Blue2': ('#aecbeb', '#145c9e', '#00044389'),
    'Brown': ('#d7f75b', '#7d451b', '#00472c1b'),
    'Brown1': ('#ffdcc2', '#8f3e00', '#00522500'),
    'Brown2': ('#d19c1d', '#7d451b', '#00472c1b'),
    'Brown3': ('#f3e9dc', '#c08552', '#005e3023'),
    'Grey': ('#ced4da', '#495057', '#00212529'),
    'Grey1': ('#f8f4e3', '#706c61', '#002a2b2a'),
    'Grey2': ('#f3f3f4', '#6d6a75', '#0034312d'),
    'Green': ('#b7e4c7', '#1b4332', '#00081c15'),
    'Green1': ('#dad7cd', '#386641', '#00344e41'),
    'Green2': ('#bce784', '#415d43', '#00415d43'),
    'Green3': ('#aad576', '#245501', '#00143601'),
    'Red': ('#ffba08', '#6a040f', '#00370617'),
    'Red1': ('#fff3b0', '#9e2a2b', '#00540b0e'),
    'Red2': ('#ffccd5', '#800f2f', '#004f000b'),
    'Pink': ('#fdbdc4', '#f51b5c', '#00950646'),
    'Purple': ('#97dffc', '#613dc1', '#004e148c'),
    'Purple1': ('#c2f8cb', '#8367c7', '#005603ad'),
    'Purple2': ('#dc97ff', '#5a108f', '#00310055'),
    'Purple3': ('#caa8f5', '#8332ac', '#004a0d67'),
    'Olive': ('#d8d174', '#424b1e', '#002f380f'),
    'Olive1': ('#e9f5db', '#344e41', '#00132a13'),
    'Turquoise': ('#6fffe9', '#1c2541', '#000b132b'),
    'Turquoise1': ('#b5f8fe', '#326771', '#0028464b'),
    # Material Design Colors
    'Material Blue': ('#bbdefb', '#2196f3', '#000d47a1'),
    'Material Brown': ('#d7ccc8', '#795548', '#003e2723'),
    'Material Green': ('#a5d6a7', '#43a047', '#001b5e20'),
    'Material Grey': ('#e0e0e0', '#9e9e9e', '#00424242'),
    'Material Cyan': ('#80deea', '#00acc1', '#00006064'),
    'Material Gold': ('#ffecb3', '#ffc107', '#00ffa000'),
    'Material Maroon': ('#ef9a9a', '#d32f2f', '#00880e4f'),
    'Material Magenta': ('#f48fb1', '#e91e63', '#00880e4f'),
    'Material Navy': ('#90caf9', '#1565c0', '#000d47a1'),
    'Material Orange': ('#ffcc80', '#fb8c00', '#00e65100'),
    'Material Teal': ('#80cbc4', '#009688', '#00004d40'),
    'Material Violet': ('#b39ddb', '#7e57c2', '#004527a0'),
    'Material Lime': ('#dce775', '#cddc39', '#00827717'),
    'Material Salmon': ('#ffab91', '#ff7043', '#00bf360c'),
    'Material Crimson': ('#ffcdd2', '#e53935', '#00b71c1c'),
    'Material Sun': ('#fff8e1', '#fbc02d', '#00f57f17'),
    # Egyptian Theme Colors
    'Egypt Blue': ('#0049bbff', '#1b3c85', '#20000000'),
    'Egypt Sunset': ('#FF8C00', '#A0522D', '#104E3B31'),
    'Egypt Dunes': ('#D6CDAF', '#A67C3D', '#107A5B2A'),
    'Egypt Classic': ('#BFBFBF', '#4B4B4B', '#101C1C1C'),
    'Egypt Jungle': ('#A3C9A8', '#6B8E23', '#101B3A1A'),
    'Egypt Forest': ('#D9CBA0', '#A67C2D', '#104E3B31'),
    'Egypt Pyramids': ('#ffb703', '#fb8500', '#10023047'),
    'Egypt Kemet': ('#fff3b0', '#e09f3e', '#109e2a2b'),
    'Egypt Sand': ('#fb8b24', '#e09f3e', '#10335c67'),
    'Egypt Sun': ('#c9cba3', '#c9cba3', '#10e26d5c'),
    # Cold Theme Colors
    'Arctic Breeze': ('#e0f7fa', '#00bcd4', '#0000b46f'),
    'Frosted Lavender': ('#e1bee7', '#9c27b0', '#00006a82'),
    'Icy Storm': ('#bbdefb', '#1e88e5', '#000d47a1'),
    'Glacial Mint': ('#b2dfdb', '#009688', '#00004d40'),
    'Blue Ice': ('#e3f2fd', '#1976d2', '#000d47a1'),
    'Northern Lights': ('#d1c4e9', '#673ab7', '#00003179'),
    'Midnight Fog': ('#b0bec5', '#607d8b', '#00003131'),
    'Frozen Sky': ('#c5cae9', '#3f51b5', '#00001e46'),
    'Transparent': ('#ced4da', '#343a40', '#50000000')
}

# SKIN GENERAL SETUP
config.plugins.xDreamy.head = ConfigSelection(default='head', choices=[('head', _('Default'))])
config.plugins.xDreamy.skinSelector = ConfigSelection(default='base', choices=[('base', _('Default'))])
config.plugins.xDreamy.skinTemplate = ConfigSelection(default='templates', choices=[
    ('templates', _('Default')),
    ('templates1', _('Style1')),
    ('templates2', _('Style2')),
    ('templates3', _('Style3')),
    ('templates4', _('Style4')),
    ('templates5', _('Style5')),
    ('templates6', _('Style6')),
    ('templates7', _('Style7')),
    ('templates8', _('Style8'))])

config.plugins.xDreamy.KeysStyle = ConfigSelection(default='keys', choices=[
    ('keys', _('Default')),
    ('keys1', _('Keys1')),
    ('keys2', _('Keys2')),
    ('keys3', _('Keys3')),
    ('keys4', _('Keys4')),
    ('keys5', _('Keys5')),
    ('keys6', _('Keys6'))])

config.plugins.xDreamy.clockFormat = ConfigSelection(default="DigitalClock", choices=[
    ('DigitalClock', _('23:59 (24 hrs)')),
    ('DigitalClock1', _('23:59:33 (24 hrs)')),
    ('DigitalClock2', _('12:59 (12 hrs)')),
    ('DigitalClock3', _('12:59 AM (12 hrs)')),
    ('DigitalClock4', _('12:59 AM (12 hrs- MultiSize)')),
    ('DigitalClock5', _('12:59:33 (12 hrs- MultiSize)'))])

config.plugins.xDreamy.dateFormat = ConfigSelection(default="%d %B %Y", choices=[
    ("%d %B %Y", "01 January 2025"),
    ("%d %B %y", "01 January 25"),
    ("%d %b %Y", "01 Jan 2025"),
    ("%d %b %y", "01 Jan 25"),
    ("%d-%m-%Y", "01-01-2025"),
    ("%d-%m-%y", "01-01-25"),
    ("%Y-%m-%d", "2025-01-01"),
    ("%y-%m-%d", "25-01-01"),
    ("%m/%d/%Y", "01/01/2025"),
    ("%m/%d/%y", "01/01/25"),
    ("%d/%m/%Y", "01/01/2025"),
    ("%d/%m/%y", "01/01/25"),
    ("%Y/%m/%d %A", "2025/01/01 Monday"),
    ("%Y/%m/%d %a", "2025/01/01 Mon"),
    ("%Y.%m.%d", "2025.01.01"),
    ("%y.%m.%d", "25.01.01"),
    ("%A, %d %B %Y", "Monday, 01 January 2025"),
    ("%a, %d %b %Y", "Mon, 01 Jan 2025"),
    ("%A %d %B %Y", "Monday 01 January 2025"),
    ("%a %d %b %Y", "Mon 01 Jan 2025"),
    ("%d %B, %Y", "01 January, 2025"),
    ("%d %b, %Y", "01 Jan, 2025"),
    ("%B %d, %Y", "January 01, 2025"),
    ("%b %d, %Y", "Jan 01, 2025"),
    ("%Y %B %d", "2025 January 01"),
    ("%Y %b %d", "2025 Jan 01"),
    ("%y %B %d", "25 January 01"),
    ("%y %b %d", "25 Jan 01"),
    ("%d.%m.%Y", "01.01.2025"),
    ("%d.%m.%y", "01.01.25"),
    ("%d %m %Y", "01 01 2025"),
    ("%A, %d %m %Y", "Monday, 01 01 2025"),
    ("%a, %d %m %Y", "Mon, 01 01 2025"),
    ("%d %m %y", "01 01 25")])

# Color configuration
config.plugins.xDreamy.colorSelector = ConfigSelection(default='default-color', choices=[
    ('default-color', _('Default')),
    ('color23_Custom', _('Custom'))])

config.plugins.xDreamy.BasicColorTemplates = ConfigSelection(default='Blue',
    choices=[(key, _(key)) for key in TEMPLATES.keys()])

# Color selections with improved organization
basic_colors = [
    ('#FFFFFF', _('Default White')),
    ('#B3E5FC', _('Sky Blue')),
    ('#D7CCC8', _('Earth Brown')),
    ('#B2EBF2', _('Aqua Cyan')),
    ('#FFE082', _('Pyramids Gold')),
    ('#C8E6C9', _('Mint Green')),
    ('#E0E0E0', _('Silver Grey')),
    ('#EF9A9A', _('Nile Maroon')),
    ('#F48FB1', _('Rose Magenta')),
    ('#90CAF9', _('Deep Navy')),
    ('#FFCC80', _('Desert Orange')),
    ('#F0F4C3', _('Olive Branch')),
    ('#F8BBD0', _('Peach Pink')),
    ('#CE93D8', _('Royal Purple')),
    ('#B2DFDB', _('Cyber Teal')),
    ('#D1C4E9', _('Violet Dream')),
    ('#E6EE9C', _('Lime Juice')),
    ('#FFAB91', _('Salmon Skin')),
    ('#A7FFEB', _('Turquoise Sea')),
    ('#FFCDD2', _('Crimson Flame')),
    ('#FFF8E1', _('Egyptian Sand'))
]

config.plugins.xDreamy.BasicColor = ConfigSelection(default='#ffffff', choices=basic_colors)
config.plugins.xDreamy.WhiteColor = ConfigSelection(default='#ffffff', choices=basic_colors)

selection_colors = [
    ('#2196F3', _('Sky Blue')),
    ('#8D6E63', _('Earth Brown')),
    ('#00BCD4', _('Aqua Cyan')),
    ('#FFC107', _('Pyramids Gold')),
    ('#4CAF50', _('Mint Green')),
    ('#9E9E9E', _('Silver Grey')),
    ('#D32F2F', _('Nile Maroon')),
    ('#E91E63', _('Rose Magenta')),
    ('#1976D2', _('Deep Navy')),
    ('#FF9800', _('Desert Orange')),
    ('#C0CA33', _('Olive Branch')),
    ('#EC407A', _('Peach Pink')),
    ('#9C27B0', _('Royal Purple')),
    ('#009688', _('Cyber Teal')),
    ('#673AB7', _('Violet Dream')),
    ('#CDDC39', _('Lime Juice')),
    ('#FF7043', _('Salmon Skin')),
    ('#1DE9B6', _('Turquoise Sea')),
    ('#E53935', _('Crimson Flame')),
    ('#FBC02D', _('Egyptian Sand'))
]

config.plugins.xDreamy.SelectionColor = ConfigSelection(default='#1e88e5', choices=selection_colors)

background_colors = [
    ('#00000000', _('Black')),
    ('#20000000', _('Transparent 1')),
    ('#40000000', _('Transparent 2')),
    ('#60000000', _('Transparent 3')),
    ('#000D47A1', _('Sky Blue')),
    ('#004E342E', _('Earth Brown')),
    ('#00006064', _('Aqua Cyan')),
    ('#00FFA000', _('Pyramids Gold')),
    ('#001B5E20', _('Mint Green')),
    ('#00424242', _('Silver Grey')),
    ('#00880E4F', _('Nile Maroon')),
    ('#00E65100', _('Desert Orange')),
    ('#00827717', _('Olive Branch')),
    ('#004A148C', _('Royal Purple')),
    ('#00004D40', _('Cyber Teal'))
]

config.plugins.xDreamy.BackgroundColor = ConfigSelection(default='#00000000', choices=background_colors)

config.plugins.xDreamy.transparency = ConfigSelection(default="00", choices=[
    ("00", _("Opaque")),
    ("05", _("5%")),
    ("10", _("10%")),
    ("15", _("15%")),
    ("20", _("20%")),
    ("25", _("25%")),
    ("30", _("30%")),
    ("35", _("35%")),
    ("40", _("40%")),
    ("45", _("45%")),
    ("50", _("50%")),
    ("55", _("55%")),
    ("60", _("60%")),
    ("65", _("65%")),
    ("70", _("70%")),
    ("75", _("75%")),
    ("80", _("80%")),
    ("85", _("85%")),
    ("90", _("90%")),
    ("95", _("95%")),
    ("99", _("Transparent"))])

# Font configuration
config.plugins.xDreamy.FontStyle = ConfigSelection(default='default', choices=[
    ('default', _('Default')),
    ('basic', _('Custom'))])

config.plugins.xDreamy.FontName = ConfigSelection(default='Verdana.ttf', choices=[
    ('Verdana.ttf', _('Default')),
    ('Andlso.ttf', _('Andlso')),
    ('Beiruti-Regular.ttf', _('Beiruti')),
    ('BonaNovaSC-Regular.ttf', _('BonaNovaSC')),
    ('Dubai-REGULAR.ttf', _('Dubai')),
    ('ElMessiri-Regular.ttf', _('ElMessiri')),
    ('Fustat-Regular.ttf', _('Fustat')),
    ('Nmsbd.ttf', _('Nmsbd')),
    ('Lucida.ttf', _('Lucida')),
    ('Majalla.ttf', _('Majalla')),
    ('Mvboli.ttf', _('Mvboli')),
    ('NaskhArabic-Regular.ttf', _('Naskh')),
    ('PlexSansArabic-Regular.ttf', _('PlexSans')),
    ('ReadexPro-Regular.ttf', _('ReadexPro')),
    ('Rubik-Regular.ttf', _('Rubik')),
    ('Tajawal-Regular.ttf', _('Tajawal')),
    ('Zain-Regular.ttf', _('Zain'))])

config.plugins.xDreamy.FontScale = ConfigSelection(default="100", choices=[
    ('100', _('Default')),
    ('105', _('5%')),
    ('110', _('10%')),
    ('115', _('15%')),
    ('120', _('20%')),
    ('125', _('25%')),
    ('130', _('30%')),
    ('135', _('35%')),
    ('95', _('-5%')),
    ('90', _('-10%')),
    ('85', _('-15%')),
    ('80', _('-20%')),
    ('75', _('-25%'))])

# InfoBar configuration
config.plugins.xDreamy.InfobarStyle = ConfigSelection(default='InfoBar-1P', choices=[
    ('InfoBar-1P', _('Default')),
    ('InfoBar-2P', _('InfoBar-2P')),
    ('InfoBar-NP', _('InfoBar1-NP')),
    ('InfoBar2-NP', _('InfoBar2-NP')),
    ('InfoBar2-1P', _('InfoBar2-1P')),
    ('InfoBar2-2P', _('InfoBar2-2P')),
    ('InfoBar2-1PW', _('InfoBar2-1PW')),
    ('InfoBar-HMF', _('Custom - InfoBar'))])

config.plugins.xDreamy.InfobarH = ConfigSelection(default='No Header', choices=[
    ('No Header', _('Default- No Header')),
    ('InfoBar H0', _('H00- Clock & Date')),
    ('InfoBar H1', _('H01- EMU/Network/Card')),
    ('InfoBar H2', _('H02- Three Days Weather')),
    ('InfoBar H3', _('H03- One RAW Header')),
    ('InfoBar H4', _('H04- Clock, Date & Weather'))])

config.plugins.xDreamy.InfobarM = ConfigSelection(default='No Middle', choices=[
    ('No Middle', _('Default- No Middle')),
    ('InfoBar M0', _('M00')),
    ('InfoBar M1', _('M01')),
    ('InfoBar M2', _('M02')),
    ('InfoBar M3', _('M03')),
    ('InfoBar M4', _('M04'))])

config.plugins.xDreamy.InfobarF = ConfigSelection(default='No Footer', choices=[
    ('No Footer', _('Default- No Footer')),
    ('InfoBar F0', _('F00')),
    ('InfoBar F1', _('F01')),
    ('InfoBar F2', _('F02')),
    ('InfoBar F3', _('F03')),
    ('InfoBar F4', _('F04')),
    ('InfoBar F5', _('F05')),
    ('InfoBar F6', _('F06'))])

# SecondInfoBar configuration
config.plugins.xDreamy.SecondInfobar = ConfigSelection(default='SecondInfobar-2P', choices=[
    ('SecondInfobar-2P', _('Default')),
    ('SecondInfobar-NP', _('SecondInfobar-NP')),
    ('SecondInfobar-2PN', _('SecondInfobar-2PN')),
    ('SecondInfobar-2PN2', _('SecondInfobar-2PN2')),
    ('SecondInfobar-HF', _('Custom - SecondInfobar'))])

config.plugins.xDreamy.SecondInfobarH = ConfigSelection(default='SecondInfobarH01', choices=[
    ('SecondInfobarH01', _('Default')),
    ('SecondInfobarH02', _('S.InfobarH S1-2E-2P')),
    ('SecondInfobarH03', _('S.InfobarH S2-2E-NP')),
    ('SecondInfobarH04', _('S.InfobarH S2-2E-2P')),
    ('SecondInfobarH05', _('S.InfobarH H-2E-NP')),
    ('SecondInfobarH06', _('S.InfobarH H-2E-2P')),
    ('SecondInfobarH07', _('S.InfobarH V-2E-NP')),
    ('SecondInfobarH08', _('S.InfobarH V-2E-2P')),
    ('SecondInfobarH09', _('S.InfobarH V-2E-2BD'))])

config.plugins.xDreamy.SecondInfobarF = ConfigSelection(default='SecondInfobarF', choices=[
    ('SecondInfobarF', _('Default')),
    ('SecondInfobarF1', _('S.InfobarF F1')),
    ('SecondInfobarF2', _('S.InfobarF F2'))])

# Channels List configuration
config.plugins.xDreamy.ChannSelector = ConfigSelection(default='C01-MTV-1P', choices=[
    ('C01-MTV-1P', _('Default')),
    ('C02-MTV-2P', _('C02-MTV-2P')),
    ('C03-MTV-7P', _('C03-MTV-7P')),
    ('C04-MTV-13P', _('C04-MTV-13P')),
    ('C05-MTV-NP', _('C05-MTV-NP')),
    ('C06-MTV-NP', _('C06-MTV-NP')),
    ('C07-MTV-1P', _('C07-MTV-1P')),
    ('C08-NP', _('C08-NP')),
    ('C09-NP', _('C09-NP')),
    ('C10-1P', _('C10-1P')),
    ('C11-2P', _('C11-2P')),
    ('C12-2P-NBG', _('C12-2P-NBG')),
    ('C13-7P', _('C13-7P')),
    ('C14-13P', _('C14-13P')),
    ('C15-14P', _('C15-14P'))])

config.plugins.xDreamy.ChannSelectorGrid = ConfigSelection(default='G01-MTV-NP', choices=[
    ('G01-MTV-NP', _('G01-MTV-NP')),
    ('G02-1Raw-1P', _('G02-1Raw-1P')),
    ('G03-1Raw-2P', _('G03-1Raw-2P')),
    ('G04-1Raw-1P-Top', _('G04-1Raw-1P-Top')),
    ('G05-Color-2P', _('G05-Color-2P')),
    ('G06-Background-NP', _('G06-Background-NP')),
    ('G07-Transparent-NP', _('G07-Transparent-NP')),
    ('G08-Color-2P', _('G08-Color-2P')),
    ('G09-Backdrop', _('G09-Backdrop'))])

# Other screens configuration
config.plugins.xDreamy.EventView = ConfigSelection(default='EventView', choices=[
    ('EventView', _('Default')),
    ('EventView1', _('EventV-01 BD')),
    ('EventView2', _('EventV-02 Big')),
    ('EventView3', _('EventV-03 7P')),
    ('EventView4', _('EventV-04 11P-FSB')),
    ('EventView5', _('EventV-05 1P-FSB'))])

config.plugins.xDreamy.PluginBrowser = ConfigSelection(default='PluginBrowser', choices=[
    ('PluginBrowser', _('Default')),
    ('PluginBrowser1', _('PluginBrowser-01')),
    ('PluginBrowser2', _('PluginBrowser-02')),
    ('PluginBrowser3', _('PluginBrowser-03')),
    ('PluginBrowser4', _('PluginBrowser-04')),
    ('PluginBrowser4GHT', _('PluginBrowser-04 GHT')),
    ('PluginBrowser4GHM', _('PluginBrowser-04 GHM')),
    ('PluginBrowser4GHB', _('PluginBrowser-04 GHB')),
    ('PluginBrowser5GVL', _('PluginBrowser-05 GVL')),
    ('PluginBrowser5GVR', _('PluginBrowser-05 GVR'))])

config.plugins.xDreamy.VolumeBar = ConfigSelection(default='volume1', choices=[
    ('volume1', _('Default')),
    ('volume2', _('volume2')),
    ('volume3', _('volume3')),
    ('volume4', _('volume4')),
    ('volume5', _('volume5'))])

config.plugins.xDreamy.VirtualKeyboard = ConfigSelection(default='VirtualKeyBoard', choices=[
    ('VirtualKeyBoard', _('Default')),
    ('VirtualKeyBoard1', _('Black - Keyboard')),
    ('VirtualKeyBoard2', _('Color - Keyboard'))])

config.plugins.xDreamy.NewVirtualKeyboard = ConfigSelection(default='NewVirtualKeyBoard0', choices=[
    ('NewVirtualKeyBoard0', _('Default')),
    ('NewVirtualKeyBoard1', _('NV.KeyBoard1')),
    ('NewVirtualKeyBoard2', _('NV.KeyBoard2')),
    ('NewVirtualKeyBoard3', _('NV.KeyBoard3')),
    ('NewVirtualKeyBoard4', _('NV.KeyBoard4'))])

config.plugins.xDreamy.HistoryZapSelector = ConfigSelection(default='HistoryZapSelector0', choices=[
    ('HistoryZapSelector0', _('Default')),
    ('HistoryZapSelector1', _('HistoryZap1-NP')),
    ('HistoryZapSelector2', _('HistoryZap2-NP')),
    ('HistoryZapSelector3', _('HistoryZap3-NP'))])

config.plugins.xDreamy.EPGMultiSelection = ConfigSelection(default='EPGMultiSelection', choices=[
    ('EPGMultiSelection', _('Default')),
    ('EPGMultiSelection1', _('EPGMultiSelection1'))])

config.plugins.xDreamy.E2Player = ConfigSelection(default='E2Player', choices=[
    ('E2Player', _('Default')),
    ('E2Player1', _('E2Player1')),
    ('E2Player2', _('E2Player2'))])

config.plugins.xDreamy.EnhancedMovieCenter = ConfigSelection(default='EnhancedMovieCenter', choices=[
    ('EnhancedMovieCenter', _('Default')),
    ('EnhancedMovieCenter1', _('E.MovieCenter1')),
    ('EnhancedMovieCenter2', _('E.MovieCenter2')),
    ('EnhancedMovieCenter3', _('E.MovieCenter3'))])

# Background and appearance settings
config.plugins.xDreamy.ChannelListBackground = ConfigSelection(default='Black', choices=[
    ('Black', _('Default- Black')),
    ('Color', _('Skin Color')),
    ('Background', _('Background')),
    ('Background1', _('Background1')),
    ('Background2', _('Background2')),
    ('Background3', _('Background3')),
    ('Background4', _('Background4')),
    ('Background5', _('Background5')),
    ('Background6', _('Background6')),
    ('Background7', _('Background7')),
    ('Background8', _('Background8')),
    ('Background9', _('Background9')),
    ('Background10', _('Background10')),
    ('Background11', _('Background11')),
    ('Background12', _('Background12')),
    ('Background13', _('Background13')),
    ('Background14', _('Background14')),
    ('Background15', _('Background15')),
    ('Background16', _('Background16'))])

config.plugins.xDreamy.TurnOff = ConfigSelection(default='Background', choices=[
    ('Background', _('Background')),
    ('Background1', _('Background1')),
    ('Background2', _('Background2')),
    ('Background3', _('Background3')),
    ('Background4', _('Background4')),
    ('Background5', _('Background5')),
    ('Background6', _('Background6')),
    ('Background7', _('Background7')),
    ('Background8', _('Background8')),
    ('Background9', _('Background9')),
    ('Background10', _('Background10')),
    ('Background11', _('Background11')),
    ('Background12', _('Background12')),
    ('Background13', _('Background13')),
    ('Background14', _('Background14')),
    ('Background15', _('Background15')),
    ('Background16', _('Background16'))])

# Weather and other plugin settings
config.plugins.xDreamy.WeatherSource = ConfigSelection(default='OAWeatherPlugin', choices=[
    ('OAWeatherPlugin', _('Default-OAWeatherPlugin')),
    ('MSNWeatherPlugin', _('MSNWeatherPlugin'))])

config.plugins.xDreamy.BitrateSource = ConfigSelection(default='BitrateRenderer', choices=[
    ('BitrateRenderer', _('Default-BitrateRenderer')),
    ('BitratePlugin', _('Bitrate Plugin'))])

config.plugins.xDreamy.SubtitlesClock = ConfigSelection(default='SC', choices=[
    ('SC', _('Default- No Clock')),
    ('SC1', _('DSC-Bottom Right')),
    ('SC2', _('DSC-Bottom Left')),
    ('SC3', _('DSC-Top Right')),
    ('SC4', _('DSC-Top Left'))])

config.plugins.xDreamy.RatingStars = ConfigSelection(default='NRS', choices=[
    ('NRS', _('Default-Disable')),
    ('RS', _('Enable'))])

config.plugins.xDreamy.CamName = ConfigSelection(default='Access', choices=[
    ('Access', _('Default')),
    ('CaidInfo2', _('CaidInfo')),
    ('CamdRAED', _('CamdRAED')),
    ('CryptoInfo', _('CryptoInfo')),
    ('EcmInfo', _('EcmInfo'))])

config.plugins.xDreamy.channelnamecolor = ConfigSelection(default="CLC", choices=[
    ("CLC", _("White - White")),
    ("CLC1", _("White - Color")),
    ("CLC2", _("Color - White")),
    ("CLC3", _("Color - Color"))])

config.plugins.xDreamy.menufontcolor = ConfigSelection(default='MC', choices=[
    ('MC', _('Default- White')),
    ('MC1', _('Skin Color'))])

config.plugins.xDreamy.crypt = ConfigSelection(default='Cryptoname', choices=[
    ('Cryptoname', _('Default-Name')),
    ('Cryptobar', _('Crypt-Bar'))])

config.plugins.xDreamy.posterRemovalInterval = ConfigSelection(default="31536000", choices=[
    ("86400", _("1 Day")),
    ("432000", _("5 Days")),
    ("864000", _("10 Days")),
    ("1296000", _("15 Days")),
    ("2592000", _("30 Days")),
    ("5184000", _("2 Months")),
    ("10368000", _("4 Months")),
    ("15552000", _("6 Months")),
    ("31536000", _("12 Months")),
    ("63072000", _("2 Years"))])

config.plugins.xDreamy.posters = ConfigSelection(default='iPosterX', choices=[
    ('iPosterX', _('Default'))])

# ✅ Improved date format application function
def applyDateFormat():
    """Apply date format to skin files with better error handling."""
    skinFiles = [
        "/usr/share/enigma2/xDreamy/sample/head-head.xml",
        "/usr/share/enigma2/xDreamy/skin.xml"
    ]

    new_format = config.plugins.xDreamy.dateFormat.value
    changes_made = False

    for skinFile in skinFiles:
        try:
            if not os.path.exists(skinFile):
                logger.warning(_("Skin file not found: {skinFile}").format(skinFile=skinFile))
                continue

            # Create backup before making changes
            backup_file = f"{skinFile}.backup"
            if not os.path.exists(backup_file):
                shutil.copy2(skinFile, backup_file)

            with open(skinFile, "r", encoding='utf-8') as file:
                skin_data = file.read()

            logger.debug(_("Checking file: {skinFile}").format(skinFile=skinFile))

            # Define the start and end of the convert tag
            start_tag = '<convert type="ClockToText">Format '
            end_tag = '</convert>'

            start_index = skin_data.find(start_tag)
            end_index = skin_data.find(end_tag, start_index) if start_index != -1 else -1

            if start_index != -1 and end_index != -1:
                old_convert_tag = skin_data[start_index:end_index + len(end_tag)]
                new_convert_tag = f'{start_tag}{new_format}{end_tag}'

                updated_skin_data = skin_data.replace(old_convert_tag, new_convert_tag)

                if updated_skin_data != skin_data:
                    try:
                        with open(skinFile, "w", encoding='utf-8') as file:
                            file.write(updated_skin_data)
                        logger.info(_("Updated date format to: {new_format} in {skinFile}").format(
                            new_format=new_format, skinFile=skinFile))
                        changes_made = True
                    except IOError as e:
                        logger.error(_("Failed to write to {skinFile}: {error}").format(
                            skinFile=skinFile, error=e))
            else:
                logger.warning(_("No convert tag found in {skinFile}!").format(skinFile=skinFile))

        except Exception as e:
            logger.error(_("Error updating {skinFile}: {error}").format(skinFile=skinFile, error=e))

    if changes_made:
        logger.info(_("Date format updated in skin templates."))
    else:
        logger.warning(_("No changes detected in skin templates."))

# Apply date format when setting changes
config.plugins.xDreamy.dateFormat.addNotifier(lambda _: applyDateFormat())

# ✅ Improved color application functions
def apply_template(template_name):
    """Apply a template with improved error handling."""
    if template_name not in TEMPLATES:
        logger.warning(_("Template '{template_name}' not found.").format(template_name=template_name))
        return False

    ltbluette_value, bluette_value, header_value = TEMPLATES[template_name]
    transparency_value = config.plugins.xDreamy.transparency.value

    # Apply transparency to header value
    if header_value.startswith("#") and len(header_value) == 9:
        header_value = f"#{transparency_value}{header_value[3:]}"

    success = update_colors_in_file(
        '/usr/share/enigma2/xDreamy/sample/C-default-color.xml',
        ltbluette_value, None, bluette_value, header_value
    )

    if success:
        logger.info(_("Template '{template_name}' applied successfully.").format(template_name=template_name))
    return success

def update_individual_colors(ltbluette_value=None, white_value=None, bluette_value=None, header_value=None):
    """Update individual colors with validation."""
    success = update_colors_in_file(
        '/usr/share/enigma2/xDreamy/sample/C-color23_Custom.xml',
        ltbluette_value, white_value, bluette_value, header_value
    )

    if success:
        logger.info(_("Individual colors updated successfully."))
    return success

def update_colors_in_file(file_path, ltbluette_value=None, white_value=None, bluette_value=None, header_value=None):
    """Update colors in file with comprehensive error handling."""
    if not os.path.exists(file_path):
        logger.error(_("Color file not found: {file_path}").format(file_path=file_path))
        return False

    try:
        # Create backup
        backup_path = f"{file_path}.backup"
        if not os.path.exists(backup_path):
            shutil.copy2(file_path, backup_path)

        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()

        updated_lines = []
        transparency_value = config.plugins.xDreamy.transparency.value
        changes_made = False

        for line in lines:
            original_line = line
            
            if '<color name="ltbluette" ' in line and ltbluette_value is not None:
                line = f'<color name="ltbluette" value="{ltbluette_value}"/>\n'
                changes_made = True
            elif '<color name="white"' in line and white_value is not None:
                line = f'<color name="white" value="{white_value}"/>\n'
                changes_made = True
            elif '<color name="bluette"' in line and bluette_value is not None:
                line = f'<color name="bluette" value="{bluette_value}"/>\n'
                changes_made = True
            elif '<color name="header"' in line and header_value is not None:
                if header_value.startswith("#") and len(header_value) == 9:
                    new_color = f"#{transparency_value}{header_value[3:]}"
                    line = f'<color name="header" value="{new_color}"/>\n'
                    changes_made = True
            updated_lines.append(line)

        if changes_made:
            with open(file_path, 'w', encoding='utf-8') as file:
                file.writelines(updated_lines)
            # Sync filesystem
            try:
                os.sync()
            except AttributeError:
                # os.sync() not available on all systems
                pass
            logger.info(_("Colors updated in {file_path}").format(file_path=file_path))
            return True

        # ✅ Improved font settings function
        def update_font_settings(font_name=None, font_scale=None):
            """Update font settings with validation."""
            font_file_path = '/usr/share/enigma2/xDreamy/sample/font-basic.xml'
            if not os.path.exists(font_file_path):
                logger.error(_("Font file not found: {font_file_path}").format(font_file_path=font_file_path))
                return False
    
            try:
                # Create backup
                backup_path = f"{font_file_path}.backup"
                if not os.path.exists(backup_path):
                    shutil.copy2(font_file_path, backup_path)
                
                with open(font_file_path, 'r', encoding='utf-8') as file:
                    lines = file.readlines()
                
                with open(font_file_path, 'w', encoding='utf-8') as file:
                    for line in lines:
                        if '<font name="Regular"' in line and font_name and font_scale:
                            font_path = f"/usr/share/enigma2/xDreamy/fonts/{font_name}"
                            line = f'<font name="Regular" filename="{font_path}" scale="{font_scale}" />\n'
                        file.write(line)
        
                # Sync filesystem
                try:
                    os.sync()
                except AttributeError:
                    pass
                
                logger.info(_("Font settings updated: {font_name}, scale={font_scale}").format(
                    font_name=font_name, font_scale=font_scale))
                return True

            except Exception as e:
                logger.error(_("Error updating font settings: {error}").format(error=e))
                return False

        # ✅ Improved network request function
        def safe_request(url, timeout=10):
            """Make HTTP request with timeout and proper error handling."""
            if not REQUESTS_AVAILABLE:
                logger.warning(_("Requests library not available"))
                return None
    
            try:
                response = requests.get(url, timeout=timeout, verify=False)
                response.raise_for_status()
                return response
            except requests.exceptions.RequestException as e:
                logger.error(_("Request failed for {url}: {error}").format(url=url, error=e))
                return None

        # ✅ Improved plugin installation check
        def check_plugin_installed(plugin_name):
            """Check if a plugin is installed with multiple methods."""
            try:
                # Check common plugin paths
                plugin_paths = [
                    f"/usr/lib/enigma2/python/Plugins/Extensions/{plugin_name}",
                    f"/usr/lib/enigma2/python/Plugins/SystemPlugins/{plugin_name}",
                    f"/usr/lib/enigma2/python/Plugins/Extensions/{plugin_name.lower()}",
                    f"/usr/lib/enigma2/python/Plugins/SystemPlugins/{plugin_name.lower()}"
                ]
                
                for path in plugin_paths:
                    if os.path.exists(path):
                        return True
                
                # Check via opkg if available
                if os.path.exists("/usr/bin/opkg"):
                    import subprocess
                    try:
                        result = subprocess.run(
                            ["opkg", "list-installed"],
                            capture_output=True, text=True, timeout=10
                        )
                        if result.returncode == 0:
                            installed_packages = result.stdout.lower()
                            return plugin_name.lower() in installed_packages
                    except (subprocess.TimeoutExpired, subprocess.SubprocessError) as e:
                        logger.warning(_("Failed to check opkg packages: {error}").format(error=e))
        
            except Exception as e:
                logger.error(_("Error checking plugin {plugin_name}: {error}").format(
                    plugin_name=plugin_name, error=e))
    
            return False

        def update_plugin_install_status():
            """Update plugin installation status for all configured plugins."""
            for plugin in plugin_names:
                is_installed = check_plugin_installed(plugin)
                config_attr = getattr(config.plugins.xDreamy, f"install_{plugin}", None)
                if config_attr:
                    config_attr.setValue(is_installed)

        # ✅ Improved renderer update function
        def update_renderer_status(enable, files_to_update=None):
            """Enable or disable renderer with better error handling."""
            if files_to_update is None:
                files_to_update = [
                    '/usr/lib/enigma2/python/Components/Renderer/iPosterX.py',
                    '/usr/lib/enigma2/python/Components/Renderer/iPosterXDownloadThread.py',
                    '/usr/lib/enigma2/python/Components/Renderer/iBackdropX.py',
                    '/usr/lib/enigma2/python/Components/Renderer/iBackdropXDownloadThread.py',
                ]
    
            success_count = 0
            total_files = len(files_to_update)
    
            for file_path in files_to_update:
                if not os.path.exists(file_path):
                    logger.warning(_("File not found: {file_path}").format(file_path=file_path))
                    continue
        
                try:
                    # Create backup
                    backup_path = f"{file_path}.backup"
                    if not os.path.exists(backup_path):
                        shutil.copy2(file_path, backup_path)
            
                    with open(file_path, 'r', encoding='utf-8') as file:
                        lines = file.readlines()
            
                    with open(file_path, 'w', encoding='utf-8') as file:
                        for line in lines:
                            if enable:
                                line = line.replace("OFF_", "i")
                            else:
                                line = line.replace("class i", "class OFF_")
                            file.write(line)
            
                    success_count += 1
                    logger.info(_("Updated {file_path} to {'enable' if enable else 'disable'} renderer.").format(
                        file_path=file_path, enable=enable))
        
                except Exception as e:
                    logger.error(_("Error updating {file_path}: {error}").format(file_path=file_path, error=e))
    
            # Sync filesystem
            try:
                os.sync()
            except AttributeError:
                pass
    
            if success_count == total_files:
                logger.info(_("Renderer {'enabled' if enable else 'disabled'} successfully."))
                return True
            else:
                logger.warning(_("Renderer update completed with {success_count}/{total_files} files updated.").format(
                    success_count=success_count, total_files=total_files))
                return False

        # Add notifier for PosterX
        config.plugins.xDreamy.enablePosterX.addNotifier(lambda config: update_renderer_status(config.value))

        def update_removal_time(removal_time):
            """Update the auto-removal interval for posters with validation."""
            posterx_file_path = '/usr/lib/enigma2/python/Components/Renderer/iPosterX.py'
            if not os.path.exists(posterx_file_path):
                logger.warning(_("iPosterX file not found: {posterx_file_path}").format(posterx_file_path=posterx_file_path))
                return False
    
            try:
                # Create backup
                backup_path = f"{posterx_file_path}.backup"
                if not os.path.exists(backup_path):
                    shutil.copy2(posterx_file_path, backup_path)
        
                with open(posterx_file_path, 'r', encoding='utf-8') as file:
                    lines = file.readlines()
        
                changes_made = False
                with open(posterx_file_path, 'w', encoding='utf-8') as file:
                    for line in lines:
                        if 'elif diff_tm > 31536000:' in line:
                            # Preserve the indentation of the original line
                            indentation = line[:line.find('elif')]
                            line = f"{indentation}elif diff_tm > {removal_time}:\n"
                            changes_made = True
                        file.write(line)
        
                if changes_made:
                    # Sync filesystem
                    try:
                        os.sync()
                    except AttributeError:
                        pass
                    logger.info(_("Poster removal time updated to: {removal_time} seconds").format(removal_time=removal_time))
                    return True
                else:
                    logger.warning(_("No removal time pattern found in iPosterX.py"))
                    return False
    
            except Exception as e:
                logger.error(_("Error updating poster removal time: {error}").format(error=e))
                return False

        config.plugins.xDreamy.posterRemovalInterval.addNotifier(lambda config: update_removal_time(config.value))

        # ✅ Improved image processing functions
        def convert_image(image_path):
            """Convert image to PNG format safely with proper resource management."""
            if not os.path.exists(image_path):
                logger.warning(_("Image file not found: {image_path}").format(image_path=image_path))
                return image_path
    
            try:
                with Image.open(image_path) as img:
                    # Convert to RGB if necessary
                    if img.mode in ("RGBA", "LA", "P"):
                        img = img.convert("RGB")
                    img.save(image_path, "PNG", optimize=True)
                logger.debug(_("Successfully converted {image_path} to PNG").format(image_path=image_path))
                return image_path
            except Exception as e:
                logger.error(_("Error converting image {image_path}: {error}").format(image_path=image_path, error=e))
                return image_path

        def remove_exif(image_path):
            """Remove EXIF data from image safely."""
            if not os.path.exists(image_path):
                logger.warning(_("Image file not found: {image_path}").format(image_path=image_path))
                return
    
            try:
                with Image.open(image_path) as img:
                    # Create new image without EXIF data
                    data = list(img.getdata())
                    image_without_exif = Image.new(img.mode, img.size)
                    image_without_exif.putdata(data)
                    image_without_exif.save(image_path, "PNG", optimize=True)
                logger.debug(_("EXIF data removed from {image_path}").format(image_path=image_path))
            except Exception as e:
                logger.error(_("Error removing EXIF from {image_path}: {error}").format(image_path=image_path, error=e))

        # ✅ Improved autostart function
        def autostart(reason, **kwargs):
            """Autostart function with improved error handling."""
            if reason != 0:  # Only run on startup
                return
    
            try:
                if cur_skin == 'xDreamy':
                    if config.plugins.xDreamy.bootlogos.value:
                        # Handle bootlogo backup and rotation
                        bootlogo_original = os.path.join(mvi, 'bootlogo.mvi')
                        bootlogo_backup = os.path.join(mvi, 'bootlogoBack.mvi')
                
                        # Create backup if it doesn't exist
                        if not fileExists(bootlogo_backup) and fileExists(bootlogo_original):
                            shutil.copy2(bootlogo_original, bootlogo_backup)
                        
                        # Clean up existing bootlogos
                        logo_files = ['bootlogo.mvi', 'backdrop.mvi', 'bootlogo_wait.mvi']
                        for logo_file in logo_files:
                            logo_path = os.path.join(logopath, logo_file)
                            if fileExists(logo_path):
                                try:
                                    os.remove(logo_path)
                                except OSError as e:
                                    logger.warning(_("Could not remove {logo_path}: {error}").format(
                                        logo_path=logo_path, error=e))
                        
                        # Apply random bootlogo if available
                        if os.path.exists(bootlog) and os.listdir(bootlog):
                            try:
                                bootlogo_files = [f for f in os.listdir(bootlog) if f.endswith('.mvi')]
                                if bootlogo_files:
                                    selected_bootlogo = random.choice(bootlogo_files)
                                    source_path = os.path.join(bootlog, selected_bootlogo)
                                    
                                    # Copy to both locations
                                    shutil.copy2(source_path, bootlogo_original)
                                    backdrop_path = os.path.join(mvi, 'backdrop.mvi')
                                    shutil.copy2(source_path, backdrop_path)
                                    
                                    logger.info(_("Applied random bootlogo: {selected_bootlogo}").format(
                                        selected_bootlogo=selected_bootlogo))
                            except Exception as e:
                                logger.error(_("Error applying random bootlogo: {error}").format(error=e))
                else:
                    # Restore original bootlogo if not using xDreamy skin
                    bootlogo_backup = os.path.join(mvi, 'bootlogoBack.mvi')
                    bootlogo_original = os.path.join(mvi, 'bootlogo.mvi')
            
                    if fileExists(bootlogo_backup):
                        try:
                            shutil.copy2(bootlogo_backup, bootlogo_original)
                            os.remove(bootlogo_backup)
                            logger.info(_("Restored original bootlogo"))
                        except Exception as e:
                            logger.error(_("Error restoring bootlogo: {error}").format(error=e))
    
            except Exception as e:
                logger.error(_("Error in autostart function: {error}").format(error=e))

        def onEnigmaStart(reason, **kwargs):
            """Function to run after Enigma2 starts."""
            if reason == 0:  # Runs only on full Enigma2 startup
                logger.info(_("Enigma2 Startup Detected - Applying configurations"))
                try:
                    applyDateFormat()
                    update_plugin_install_status()
                except Exception as e:
                    logger.error(_("Error in onEnigmaStart: {error}").format(error=e))

        # ✅ Plugin descriptor function
        def Plugins(**kwargs):
            """Plugin descriptor with improved structure."""
            pluginList = [
                PluginDescriptor(
                    name=_("XDREAMY"),
                    description=_('Customization tool for XDREAMY Skin'),
                    where=PluginDescriptor.WHERE_PLUGINMENU,
                    icon='plugin.png',
                    fnc=main
                ),
                PluginDescriptor(
                    name=_("XDREAMY BOOT"),
                    description=_("XDREAMY BOOT LOGO"),
                    where=PluginDescriptor.WHERE_AUTOSTART,
                    fnc=autostart
                )
            ]
            
            # Add to Extensions menu if enabled
            if config.plugins.xDreamy.ShowInExtensions.value:
                pluginList.append(
                    PluginDescriptor(
                        name=_("XDREAMY Skin Settings"),
                        description=_("Customization tool for XDREAMY Skin"),
                        where=[PluginDescriptor.WHERE_EXTENSIONSMENU],
                        fnc=main
                    )
                )
    
            return pluginList

        # ✅ Improved poster render switching function
        def switch_poster_render():
            """Switch between iPosterX and xtraEvent in XML skin files."""
            base_path = "/usr/share/enigma2/xDreamy/sample/"
            if not os.path.exists(base_path):
                logger.error(_("Sample path not found: {base_path}").format(base_path=base_path))
                return False
    
            try:
                target_files = [f for f in os.listdir(base_path) if f.startswith(("infobar-", "secondinfobar-", "CHL-", "CHLG-")) and f.endswith(".xml")]
            except OSError as e:
                logger.error(_("Error listing files in {base_path}: {error}").format(base_path=base_path, error=e))
                return False
    
            selected_render = config.plugins.xDreamy.posters.value
    
            # Define replacement mappings
            replacements = {
                'iPosterX': 'xtraPoster',
                'iBackdropX': 'xtraBackdrop'
            } if selected_render == 'xtraEvent' else {
                'xtraPoster': 'iPosterX',
                'xtraBackdrop': 'iBackdropX'
            }
            
            success_count = 0
    
            for filename in target_files:
                file_path = os.path.join(base_path, filename)
                try:
                    # Create backup
                    backup_path = f"{file_path}.backup"
                    if not os.path.exists(backup_path):
                        shutil.copy2(file_path, backup_path)
            
                    with open(file_path, 'r', encoding='utf-8') as file:
                        content = file.read()
            
                    # Apply replacements
                    original_content = content
                    for old, new in replacements.items():
                        content = content.replace(old, new)
            
                    # Write back if changes were made
                    if content != original_content:
                        with open(file_path, 'w', encoding='utf-8') as file:
                            file.write(content)
                        success_count += 1
                        logger.debug(_("Updated poster rendering in {filename}").format(filename=filename))
        
                except Exception as e:
                    logger.error(_("Error processing {filename}: {error}").format(filename=filename, error=e))
    
                    logger.info(_("Updated poster rendering in {success_count} files ({selected_render})").format(
                    success_count=success_count, selected_render=selected_render))
                return success_count > 0

    def main(session, **kwargs):
        """Main entry point for the plugin."""
        try:
            session.open(xDreamySetup)
        except Exception as e:
            logger.error(_("Error opening xDreamySetup: {error}").format(error=e))
            session.open(MessageBox, _("Error starting XDREAMY plugin: {error}").format(error=str(e)), 
                        MessageBox.TYPE_ERROR)

# ✅ Main Setup Class with comprehensive improvements
class xDreamySetup(ConfigListScreen, Screen):
    skin = '''
    <screen name="xDreamySetup" position="center,center" size="1000,640" title="XDREAMY skin customization plugin">
        <eLabel font="Regular; 24" foregroundColor="#00ff4A3C" halign="center" position="20,598" size="120,26" text="Cancel"/>
        <eLabel font="Regular; 24" foregroundColor="#0056C856" halign="center" position="220,598" size="120,26" text="Save"/>
        <widget name="Preview" position="997,690" size="498, 280" zPosition="1"/>
        <widget name="config" font="Regular; 24" itemHeight="40" position="5,5" scrollbarMode="showOnDemand" size="990,550"/>
        <widget name="city" font="Regular; 26" position="564,571" size="420,60" foregroundColor="#00ff4A3C" backgroundColor="#000000" transparent="1" zPosition="4" halign="center" valign="bottom"/>
        <widget name="helpText" font="Regular; 22" position="5,560" size="990,30" foregroundColor="#00ffffff" backgroundColor="#000000" transparent="1" zPosition="2" halign="left" valign="center"/>
    </screen>
    '''

    def __init__(self, session):
        self.version = f'xDreamy v{version}'
        Screen.__init__(self, session)
        self.session = session
        self.skinFile = '/usr/share/enigma2/xDreamy/skin.xml'
        self.previewFiles = '/usr/share/enigma2/xDreamy/sample/'
        
        # Initialize widgets
        self['Preview'] = Pixmap()
        self['city'] = Label('')
        self['helpText'] = Label('')
        self['yellow'] = Label(_('Check for Update'))
        self['blue'] = Label(_('Version'))
        
        self.setup_title = f"XDREAMY SKIN v{version}"
        self.activeComponents = []
        
        # Initialize configuration list
        list = []
        ConfigListScreen.__init__(self, list, session=self.session, on_change=self.changedEntry)
        self.onChangedEntry = []
        self.editListEntry = None
        
        # Setup action maps
        self.setupActionMaps()
        
        # Setup timers
        self.setupTimers()
        
        # Layout finish callbacks
        self.onLayoutFinish.append(self.createSetup)
        self.onLayoutFinish.append(self.ShowPicture)
        self.onLayoutFinish.append(self.__layoutFinished)
        
        # Add notifiers
        config.plugins.xDreamy.InfobarStyle.addNotifier(self.onInfobarStyleChange)
        
        # Update plugin install status
        try:
            update_plugin_install_status()
        except Exception as e:
            logger.error(_("Error updating plugin status: {error}").format(error=e))

    def setupActionMaps(self):
        """Setup action maps with error handling."""
        try:
            self["actions"] = ActionMap(["SetupActions"], {
                'ok': self.keyOK,
                "cancel": self.keyCancel,
                "save": self.keySave,
            }, -2)
            
            self['actions'] = ActionMap(['OkCancelActions',
                                       'DirectionActions',
                                       'InputActions',
                                       'VirtualKeyboardActions',
                                       'MenuActions',
                                       'NumberActions',
                                       'InfoActions',
                                       'ColorActions'], {
                'showVirtualKeyboard': self.KeyText,
                'left': self.keyLeft,
                'right': self.keyRight,
                'down': self.keyDown,
                'up': self.keyUp,
                'red': self.keyExit,
                'green': self.keySave,
                'yellow': self.checkforUpdate,
                'blue': self.info,
                'cancel': self.keyExit,
                'ok': self.keyRun
            }, -1)
        except Exception as e:
            logger.error(_("Error setting up action maps: {error}").format(error=e))

    def setupTimers(self):
        """Setup timers with proper connection handling."""
        try:
            self.timerx = eTimer()
            if fileExists('/var/lib/dpkg/status'):
                self.timerx_conn = self.timerx.timeout.connect(self.checkforUpdate)
            else:
                self.timerx.callback.append(self.checkforUpdate)
            self.timerx.start(5000, True)
        except Exception as e:
            logger.error(_("Error setting up timers: {error}").format(error=e))

    def __layoutFinished(self):
        """Layout finished callback with error handling."""
        try:
            self['city'].setText(str(config.plugins.xDreamy.city.value))
            self.setTitle(self.setup_title)
        except Exception as e:
            logger.error(_("Error in layout finished: {error}").format(error=e))

    def updateHelpText(self):
        """Update help text with current selection."""
        try:
            current = self["config"].getCurrent()
            if current:
                help_text = current[2] if len(current) > 2 else ''
                self['helpText'].setText(help_text)
        except Exception as e:
            logger.debug(_("Error updating help text: {error}").format(error=e))

    def changedEntry(self):
        """Handle configuration entry changes."""
        try:
            self.updateHelpText()
            self.ShowPicture()
        except Exception as e:
            logger.debug(_("Error in changedEntry: {error}").format(error=e))

    def onInfobarStyleChange(self, configElement):
        """Handle InfoBar style changes."""
        try:
            self.createSetup()
        except Exception as e:
            logger.error(_("Error in InfoBar style change: {error}").format(error=e))

    def ShowPicture(self):
        """Show preview picture with error handling."""
        try:
            current = self["config"].getCurrent()
            if current and len(current) > 1:
                item_name = str(current[1].value)
                preview_path = self.getImagePath(item_name)
                
                if os.path.exists(preview_path):
                    self['Preview'].instance.setPixmapFromFile(preview_path)
                else:
                    # Try default preview
                    default_preview = os.path.join(self.previewFiles, "default.png")
                    if os.path.exists(default_preview):
                        self['Preview'].instance.setPixmapFromFile(default_preview)
        except Exception as e:
            logger.debug(_("Error showing picture: {error}").format(error=e))

    def getImagePath(self, item_name):
        """Get image path for preview with validation."""
        try:
            base_dir = "/usr/share/enigma2/xDreamy/screens/"
            if not os.path.exists(base_dir):
                return ""
                
            # Clean item name
            clean_name = item_name.lower().replace(" ", "").replace("-", "")
            image_path = os.path.join(base_dir, f"{clean_name}.png")
            
            return image_path if os.path.exists(image_path) else ""
        except Exception as e:
            logger.debug(_("Error getting image path: {error}").format(error=e))
            return ""

    def info(self):
        """Show info dialog."""
        try:
            self.mesInfo()
        except Exception as e:
            logger.error(_("Error showing info: {error}").format(error=e))

    def mesInfo(self):
        """Display plugin information."""
        message = _(
            "Experience Enigma2 skin like never before with XDREAMY\n\n"
            "XDREAMY skin is a new vision, created by Inspiron.\n"
            "Users can fully customize their interface, and change layout,\n"
            "colors, fonts, and screens to suit their preferences.\n"
            "Drawing inspiration from Dreamy and oDreamy skins,\n"
            "XDREAMY incorporates cutting-edge rendering technology,\n"
            "including the efficient PosterX component recoded by M.Hussein using AI.\n\n"
            "Supported Images\n"
            "-----------------\n"
            "Egami, OpenATV, OpenSpa, PurE2, OpenDroid, OpenBH & Alliance Based Images.\n"
            "OpenPLi, OpenVIX, OpenHDF, OpenTR, Satlodge, NonSoloSat, Foxbob & PLi Base Images.\n\n"
            "Forum support: Linuxsat-support.com\n"
            f"Version: {version}\n"
            "Mahmoud Hussein"
        )
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=10)

    def checkforUpdate(self):
        """Check for updates with error handling."""
        try:
            # Implement update checking logic here
            logger.info(_("Checking for updates..."))
            # This would typically check a remote server for updates
        except Exception as e:
            logger.error(_("Error checking for updates: {error}").format(error=e))

    def createSetup(self):
        """Create the configuration setup with comprehensive options."""
        try:
            self.editListEntry = None
            list = []
            
            # General Setup Section
            section = '\\c00289496' + _('SKIN GENERAL SETUP') + '_' * 58
            list.append(getConfigListEntry(section))
            
            list.append(getConfigListEntry(
                _('Skin Style:'), 
                config.plugins.xDreamy.skinTemplate, 
                _('Choose the overall visual theme for your interface. This affects layouts and graphical elements.')
            ))
            
            list.append(getConfigListEntry(
                _('Keys Style:'), 
                config.plugins.xDreamy.KeysStyle, 
                _('Select the design style for on-screen buttons and key prompts.')
            ))
            
            list.append(getConfigListEntry(
                _('Font Style:'), 
                config.plugins.xDreamy.FontStyle, 
                _('Set the default font scheme. Choose "Custom" for advanced font control.')
            ))
            
            # Font customization options
            if config.plugins.xDreamy.FontStyle.value == 'basic':
                list.append(getConfigListEntry(
                    _('      - Font Type:'), 
                    config.plugins.xDreamy.FontName, 
                    _('Select your preferred font family. Verdana is the default for optimal readability.')
                ))
                list.append(getConfigListEntry(
                    _('      - Font Size:'), 
                    config.plugins.xDreamy.FontScale, 
                    _('Adjust text size in 5% increments. 100% is standard size.')
                ))
            
            list.append(getConfigListEntry(
                _("Date Format:"), 
                config.plugins.xDreamy.dateFormat, 
                _("Customize how dates are displayed throughout the interface.")
            ))
            
            list.append(getConfigListEntry(
                _("Clock Format:"), 
                config.plugins.xDreamy.clockFormat, 
                _("Select between 12-hour (AM/PM) or 24-hour time format.")
            ))
            
            list.append(getConfigListEntry(
                _('Show in Extensions:'), 
                config.plugins.xDreamy.ShowInExtensions, 
                _('Toggle visibility of xDreamy in the Extensions menu.')
            ))

            # Spacer
            list.append(getConfigListEntry('\\c00289496' + ' ' * 90))

            # Colors Section
            section = '\\c00289496' + _('SKIN COLORS') + '_' * 72
            list.append(getConfigListEntry(section))
            
            list.append(getConfigListEntry(
                _('Color Scheme:'), 
                config.plugins.xDreamy.colorSelector, 
                _('Select "Default" for templates or "Custom" for individual color control.')
            ))
            
            # Template-based colors
            if config.plugins.xDreamy.colorSelector.value == 'default-color':
                list.append(getConfigListEntry(
                    _('      - Color Templates:'), 
                    config.plugins.xDreamy.BasicColorTemplates, 
                    _('Select a predefined color template for the entire skin.')
                ))
                list.append(getConfigListEntry(
                    _('      - Background Transparency:'), 
                    config.plugins.xDreamy.transparency, 
                    _('Adjust the transparency level for background elements.')
                ))
            
            # Custom colors
            if config.plugins.xDreamy.colorSelector.value == 'color23_Custom':
                list.append(getConfigListEntry(
                    _('      - Titles Color:'), 
                    config.plugins.xDreamy.BasicColor, 
                    _('Select the color for main titles and headers.')
                ))
                list.append(getConfigListEntry(
                    _('      - Text Color:'), 
                    config.plugins.xDreamy.WhiteColor, 
                    _('Select the color for general text content.')
                ))
                list.append(getConfigListEntry(
                    _('      - Selection Color:'), 
                    config.plugins.xDreamy.SelectionColor, 
                    _('Select the color for highlighted/selected items.')
                ))
                list.append(getConfigListEntry(
                    _('      - Background Color:'), 
                    config.plugins.xDreamy.BackgroundColor, 
                    _('Select the base background color for the skin.')
                ))
                list.append(getConfigListEntry(
                    _('      - Background Transparency:'), 
                    config.plugins.xDreamy.transparency, 
                    _('Adjust the transparency level for background elements.')
                ))
            
            list.append(getConfigListEntry(
                _('Menu Font Color:'), 
                config.plugins.xDreamy.menufontcolor, 
                _('Choose the font color for menu text.')
            ))
            
            list.append(getConfigListEntry(
                _('Channel Names Color:'), 
                config.plugins.xDreamy.channelnamecolor, 
                _('Choose the color scheme for channel name display.')
            ))

            # Spacer
            list.append(getConfigListEntry('\\c00289496' + ' ' * 90))

            # Screen Layouts Section
            section = '\\c00289496' + _('SCREEN LAYOUTS') + '_' * 68
            list.append(getConfigListEntry(section))
            
            # InfoBar configuration
            list.append(getConfigListEntry(
                _('InfoBar Style:'), 
                config.plugins.xDreamy.InfobarStyle, 
                _('Choose the InfoBar layout. Select "Custom" for individual component control.')
            ))
            
            if config.plugins.xDreamy.InfobarStyle.value == 'InfoBar-HMF':
                list.append(getConfigListEntry(
                    _('      - InfoBar Header:'), 
                    config.plugins.xDreamy.InfobarH, 
                    _('Select the header style for your custom InfoBar.')
                ))
                list.append(getConfigListEntry(
                    _('      - InfoBar Middle:'), 
                    config.plugins.xDreamy.InfobarM, 
                    _('Select the middle section style for your custom InfoBar.')
                ))
                list.append(getConfigListEntry(
                    _('      - InfoBar Footer:'), 
                    config.plugins.xDreamy.InfobarF, 
                    _('Select the footer style for your custom InfoBar.')
                ))
            
            # SecondInfoBar configuration
            list.append(getConfigListEntry(
                _('SecondInfoBar Style:'), 
                config.plugins.xDreamy.SecondInfobar, 
                _('Choose the SecondInfoBar layout style.')
            ))
            
            if config.plugins.xDreamy.SecondInfobar.value == 'SecondInfobar-HF':
                list.append(getConfigListEntry(
                    _('      - SecondInfoBar Header:'), 
                    config.plugins.xDreamy.SecondInfobarH, 
                    _('Select the header style for your custom SecondInfoBar.')
                ))
                list.append(getConfigListEntry(
                    _('      - SecondInfoBar Footer:'), 
                    config.plugins.xDreamy.SecondInfobarF, 
                    _('Select the footer style for your custom SecondInfoBar.')
                ))
            
            # Channel List configuration
            list.append(getConfigListEntry(
                _('Channels List Style:'), 
                config.plugins.xDreamy.ChannSelector, 
                _('Choose the layout for the regular channels list.')
            ))
            
            list.append(getConfigListEntry(
                _('Channels Grid Style:'), 
                config.plugins.xDreamy.ChannSelectorGrid, 
                _('Select the grid layout for channels list (supported images only).')
            ))
            
            # Other screen styles
            list.append(getConfigListEntry(
                _('EventView Style:'), 
                config.plugins.xDreamy.EventView, 
                _('Choose the layout for the EventView screen.')
            ))
            
            list.append(getConfigListEntry(
                _('Volume Bar Style:'), 
                config.plugins.xDreamy.VolumeBar, 
                _('Select the visual style for the volume indicator.')
            ))
            
            list.append(getConfigListEntry(
                _('Plugin Browser Style:'), 
                config.plugins.xDreamy.PluginBrowser, 
                _('Choose the layout for the Plugin Browser (supported images).')
            ))

            # Spacer
            list.append(getConfigListEntry('\\c00289496' + ' ' * 90))

            # Plugin Integration Section
            section = '\\c00289496' + _('PLUGIN INTEGRATION') + '_' * 60
            list.append(getConfigListEntry(section))
            
            list.append(getConfigListEntry(
                _('E2Player Style:'), 
                config.plugins.xDreamy.E2Player, 
                _('Select the layout style for E2Player plugin.')
            ))
            
            list.append(getConfigListEntry(
                _('Enhanced Movie Center:'), 
                config.plugins.xDreamy.EnhancedMovieCenter, 
                _('Choose the style for Enhanced Movie Center plugin.')
            ))
            
            list.append(getConfigListEntry(
                _('New Virtual Keyboard:'), 
                config.plugins.xDreamy.NewVirtualKeyboard, 
                _('Select the style for New Virtual Keyboard plugin.')
            ))
            
            list.append(getConfigListEntry(
                _('History Zap Selector:'), 
                config.plugins.xDreamy.HistoryZapSelector, 
                _('Choose the style for History Zap Selector plugin.')
            ))

            # Spacer
            list.append(getConfigListEntry('\\c00289496' + ' ' * 90))

            # System Integration Section
            section = '\\c00289496' + _('SYSTEM INTEGRATION') + '_' * 60
            list.append(getConfigListEntry(section))
            
            list.append(getConfigListEntry(
                _('Random Bootlogos:'), 
                config.plugins.xDreamy.bootlogos, 
                _('Enable random bootlogo rotation on system restart.')
            ))
            
            list.append(getConfigListEntry(
                _('Poster Display:'), 
                config.plugins.xDreamy.enablePosterX, 
                _('Enable or disable poster/backdrop image display.')
            ))
            
            if config.plugins.xDreamy.enablePosterX.value:
                list.append(getConfigListEntry(
                    _('      - Poster Cleanup Interval:'), 
                    config.plugins.xDreamy.posterRemovalInterval, 
                    _('Set how often old poster files are automatically removed.')
                ))
            
            list.append(getConfigListEntry(
                _('Weather Plugin Source:'), 
                config.plugins.xDreamy.WeatherSource, 
                _('Select which weather plugin to use for weather information.')
            ))
            
            list.append(getConfigListEntry(
                _('Bitrate Display Source:'), 
                config.plugins.xDreamy.BitrateSource, 
                _('Choose the source for bitrate information display.')
            ))

            # Spacer
            list.append(getConfigListEntry('\\c00289496' + ' ' * 90))

            # API Configuration Section
            section = '\\c00289496' + _('API CONFIGURATION') + '_' * 63
            list.append(getConfigListEntry(section))
            
            list.append(getConfigListEntry(
                _('TMDB API Status:'), 
                config.plugins.xDreamy.api, 
                _('Toggle TMDB API integration for movie/TV information.')
            ))
            
            if config.plugins.xDreamy.api.value:
                list.append(getConfigListEntry(
                    _('      - TMDB API Key:'), 
                    config.plugins.xDreamy.txtapi, 
                    _('Enter your TMDB API key for movie/TV show data.')
                ))
            
            list.append(getConfigListEntry(
                _('OMDB API Status:'), 
                config.plugins.xDreamy.api2, 
                _('Toggle OMDB API integration for additional movie data.')
            ))
            
            if config.plugins.xDreamy.api2.value:
                list.append(getConfigListEntry(
                    _('      - OMDB API Key:'), 
                    config.plugins.xDreamy.txtapi2, 
                    _('Enter your OMDB API key for movie database access.')
                ))
            
            list.append(getConfigListEntry(
                _('TheTVDB API Status:'), 
                config.plugins.xDreamy.api3, 
                _('Toggle TheTVDB API integration for TV series data.')
            ))
            
            if config.plugins.xDreamy.api3.value:
                list.append(getConfigListEntry(
                    _('      - TheTVDB API Key:'), 
                    config.plugins.xDreamy.txtapi3, 
                    _('Enter your TheTVDB API key for TV series information.')
                ))
            
            list.append(getConfigListEntry(
                _('Fanart API Status:'), 
                config.plugins.xDreamy.api4, 
                _('Toggle Fanart.tv API integration for artwork.')
            ))
            
            if config.plugins.xDreamy.api4.value:
                list.append(getConfigListEntry(
                    _('      - Fanart API Key:'), 
                    config.plugins.xDreamy.txtapi4, 
                    _('Enter your Fanart.tv API key for artwork access.')
                ))

            # Weather Configuration
            if fileExists(OAWeather):
                list.append(getConfigListEntry(
                    _('Weather Location:'), 
                    config.plugins.xDreamy.city, 
                    _('Set your city/location for weather information display.')
                ))

            # Spacer
            list.append(getConfigListEntry('\\c00289496' + ' ' * 90))

            # Plugin Installation Section
            section = '\\c00289496' + _('PLUGIN INSTALLATION') + '_' * 60
            list.append(getConfigListEntry(section))
            
            # Management panels
            subsection = '\\c0056c856' + _('Management Panels:')
            list.append(getConfigListEntry(subsection))
            
            management_plugins = [
                ('ajpanel', _('AJ Panel'), _('Install AJ Panel for system management')),
                ('linuxsatpanel', _('LinuxSat Panel'), _('Install LinuxSat Panel for satellite management')),
                ('CiefpPlugins', _('Ciefp Plugins'), _('Install Ciefp plugin collection')),
                ('smartpanel', _('Smart Panel'), _('Install Smart Panel for advanced system control')),
                ('elisatpanel', _('EliSat Panel'), _('Install EliSat Panel for satellite operations')),
                ('magicpanel', _('Magic Panel'), _('Install Magic Panel with extended features'))
            ]
            
            for plugin_id, plugin_name, description in management_plugins:
                config_attr = getattr(config.plugins.xDreamy, f"install_{plugin_id}")
                list.append(getConfigListEntry(f'      - {plugin_name}:', config_attr, description))

            # Weather plugins
            subsection = '\\c0056c856' + _('Weather Plugins:')
            list.append(getConfigListEntry(subsection))
            
            weather_plugins = [
                ('msnweather', _('MSN Weather'), _('Install MSN Weather plugin for weather information')),
                ('oaweather', _('OA Weather'), _('Install OpenAtv Weather plugin'))
            ]
            
            for plugin_id, plugin_name, description in weather_plugins:
                config_attr = getattr(config.plugins.xDreamy, f"install_{plugin_id}")
                list.append(getConfigListEntry(f'      - {plugin_name}:', config_attr, description))

            # System utilities
            subsection = '\\c0056c856' + _('System Utilities:')
            list.append(getConfigListEntry(subsection))
            
            system_plugins = [
                ('multicammanager', _('MultiCam Manager'), _('Install MultiCam Manager for CAM handling')),
                ('NCam', _('NCam'), _('Install NCam emulator')),
                ('keyadder', _('Key Adder'), _('Install Key Adder for softcam key management')),
                ('transmission', _('Transmission'), _('Install Transmission BitTorrent client'))
            ]
            
            for plugin_id, plugin_name, description in system_plugins:
                config_attr = getattr(config.plugins.xDreamy, f"install_{plugin_id}")
                list.append(getConfigListEntry(f'      - {plugin_name}:', config_attr, description))

            # Media players
            subsection = '\\c0056c856' + _('Media Players:')
            list.append(getConfigListEntry(subsection))
            
            media_plugins = [
                ('xklass', _('XKlass'), _('Install XKlass IPTV player')),
                ('youtube', _('YouTube'), _('Install YouTube player plugin')),
                ('e2iplayer', _('E2iPlayer'), _('Install E2iPlayer for online streaming')),
                ('ipaudiopro', _('IPAudio Pro'), _('Install IPAudio Pro for internet radio'))
            ]
            
            for plugin_id, plugin_name, description in media_plugins:
                config_attr = getattr(config.plugins.xDreamy, f"install_{plugin_id}")
                list.append(getConfigListEntry(f'      - {plugin_name}:', config_attr, description))

            # IPTV and streaming
            subsection = '\\c0056c856' + _('IPTV & Streaming:')
            list.append(getConfigListEntry(subsection))
            
            iptv_plugins = [
                ('multistalkerpro', _('MultiStalker Pro'), _('Install MultiStalker Pro for IPTV')),
                ('EPGGrabber', _('EPG Grabber'), _('Install EPG Grabber for program guide data'))
            ]
            
            for plugin_id, plugin_name, description in iptv_plugins:
                config_attr = getattr(config.plugins.xDreamy, f"install_{plugin_id}")
                list.append(getConfigListEntry(f'      - {plugin_name}:', config_attr, description))

            # Interface enhancements
            subsection = '\\c0056c856' + _('Interface Enhancements:')
            list.append(getConfigListEntry(subsection))
            
            interface_plugins = [
                ('subssupport', _('Subs Support'), _('Install subtitle support plugin')),
                ('historyzapselector', _('History Zap Selector'), _('Install channel history selector')),
                ('newvirtualkeyboard', _('New Virtual Keyboard'), _('Install enhanced virtual keyboard')),
                ('raedquicksignal', _('Raed Quick Signal'), _('Install quick signal analyzer'))
            ]
            
            for plugin_id, plugin_name, description in interface_plugins:
                config_attr = getattr(config.plugins.xDreamy, f"install_{plugin_id}")
                list.append(getConfigListEntry(f'      - {plugin_name}:', config_attr, description))

            # Spacer
            list.append(getConfigListEntry('\\c00289496' + ' ' * 90))

            # Advanced Settings Section
            section = '\\c00289496' + _('ADVANCED SETTINGS') + '_' * 62
            list.append(getConfigListEntry(section))
            
            list.append(getConfigListEntry(
                _('Background Styles:'), 
                config.plugins.xDreamy.ChannelListBackground, 
                _('Select background wallpaper for channel lists.')
            ))
            
            list.append(getConfigListEntry(
                _('Shutdown Background:'), 
                config.plugins.xDreamy.TurnOff, 
                _('Choose background for shutdown/restart screens.')
            ))
            
            list.append(getConfigListEntry(
                _('Virtual Keyboard Style:'), 
                config.plugins.xDreamy.VirtualKeyboard, 
                _('Select the visual style for the virtual keyboard.')
            ))
            
            list.append(getConfigListEntry(
                _('Subtitles Clock Position:'), 
                config.plugins.xDreamy.SubtitlesClock, 
                _('Set the position of clock display during subtitle playback.')
            ))
            
            list.append(getConfigListEntry(
                _('Rating Stars Display:'), 
                config.plugins.xDreamy.RatingStars, 
                _('Enable or disable rating stars in movie/show information.')
            ))
            
            list.append(getConfigListEntry(
                _('CAM Information Source:'), 
                config.plugins.xDreamy.CamName, 
                _('Select the source for CAM/encryption information display.')
            ))
            
            list.append(getConfigListEntry(
                _('Encryption Display:'), 
                config.plugins.xDreamy.crypt, 
                _('Choose how encryption information is displayed.')
            ))
            
            # Maintenance Section
            subsection = '\\c0056c856' + _('Maintenance:')
            list.append(getConfigListEntry(subsection))
            
            list.append(getConfigListEntry(
                _('      - Clear Poster Cache:'), 
                config.plugins.xDreamy.png, 
                _('Remove all cached poster and backdrop images to free space.')
            ))

            # Update the configuration list
            self["config"].setList(list)
            
        except Exception as e:
            logger.error(_("Error creating setup: {error}").format(error=e))
            # Fallback to basic setup
            self["config"].setList([getConfigListEntry(_("Error loading configuration"))])

    def keyRun(self):
        """Handle OK key press with comprehensive error handling."""
        try:
            current = self["config"].getCurrent()
            if not current or len(current) < 2:
                return
            sel = current[1]
            
            # Handle different types of configuration items
            if sel == config.plugins.xDreamy.png:
                self.removPng()
            elif sel == config.plugins.xDreamy.weather:
                self.KeyMenu()
            elif sel == config.plugins.xDreamy.oaweather:
                self.KeyMenu2()
            elif sel == config.plugins.xDreamy.city:
                self.KeyText()
            elif sel in [config.plugins.xDreamy.txtapi, config.plugins.xDreamy.txtapi2, 
                        config.plugins.xDreamy.txtapi3, config.plugins.xDreamy.txtapi4]:
                self.KeyText()
            elif sel == config.plugins.xDreamy.api:
                self.keyApi()
            elif sel == config.plugins.xDreamy.api2:
                self.keyApi2()
            elif sel == config.plugins.xDreamy.api3:
                self.keyApi3()
            elif sel == config.plugins.xDreamy.api4:
                self.keyApi4()
            elif isinstance(sel, ConfigSelection):
                self.openSelectionPopup(current)
            else:
                # Handle plugin installation
                self.handlePluginInstallation(sel)
        except Exception as e:
            logger.error(_("Error in keyRun: {error}").format(error=e))
            self.session.open(MessageBox, _("Error processing selection: {error}").format(error=str(e)), MessageBox.TYPE_ERROR)

    def handlePluginInstallation(self, sel):
        """Handle plugin installation with improved logic."""
        try:
            # Map configuration items to plugin info
            plugin_mapping = {
                config.plugins.xDreamy.install_ajpanel: ("AJPanel", "https://raw.githubusercontent.com/AMAJamry/AJPanel/main/installer.sh"),
                config.plugins.xDreamy.install_linuxsatpanel: ("LinuxsatPanel", "https://raw.githubusercontent.com/Belfagor2005/LinuxsatPanel/main/installer.sh"),
                config.plugins.xDreamy.install_CiefpPlugins: ("CiefpPlugins", "https://raw.githubusercontent.com/ciefp/CiefpPlugins/main/installer.sh"),
                config.plugins.xDreamy.install_smartpanel: ("SmartPanel", "https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/SmartAddonspanel/smart-Panel.sh"),
                config.plugins.xDreamy.install_elisatpanel: ("EliSatPanel", "https://raw.githubusercontent.com/eliesat/eliesatpanel/main/installer.sh"),
                config.plugins.xDreamy.install_magicpanel: ("MagicPanel", "https://gitlab.com/h-ahmed/Panel/-/raw/main/MagicPanel-install.sh"),
                config.plugins.xDreamy.install_msnweather: ("MSNWeather", "https://raw.githubusercontent.com/fairbird/WeatherPlugin/master/installer.sh"),
                config.plugins.xDreamy.install_oaweather: ("OAWeather", "https://gitlab.com/hmeng80/extensions/-/raw/main/oaweather/oaweather.sh"),
                config.plugins.xDreamy.install_multicammanager: ("MultiCamManager", "https://raw.githubusercontent.com/levi-45/Manager/main/installer.sh"),
                config.plugins.xDreamy.install_NCam: ("NCam", "https://raw.githubusercontent.com/biko-73/Ncam_EMU/main/installer.sh"),
                config.plugins.xDreamy.install_keyadder: ("KeyAdder", "https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh"),
                config.plugins.xDreamy.install_xklass: ("XKlass", "https://gitlab.com/MOHAMED_OS/dz_store/-/raw/main/XKlass/online-setup"),
                config.plugins.xDreamy.install_youtube: ("YouTube", "https://raw.githubusercontent.com/fairbird/Youtube-Opensource-DreamOS/master/installer.sh"),
                config.plugins.xDreamy.install_e2iplayer: ("E2iPlayer", "https://gitlab.com/eliesat/extensions/-/raw/main/e2iplayer/e2iplayer-main.sh"),
                config.plugins.xDreamy.install_transmission: ("Transmission", "http://dreambox4u.com/dreamarabia/Transmission_e2/Transmission_e2.sh"),
                config.plugins.xDreamy.install_multistalkerpro: ("MultiStalkerPro", "https://raw.githubusercontent.com/biko-73/Multi-Stalker/main/pro/installer.sh"),
                config.plugins.xDreamy.install_ipaudiopro: ("IPAudioPro", "https://raw.githubusercontent.com/biko-73/ipaudio/main/ipaudio_pro.sh"),
                config.plugins.xDreamy.install_EPGGrabber: ("EPGGrabber", "https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh"),
                config.plugins.xDreamy.install_subssupport: ("SubsSupport", "https://github.com/popking159/ssupport/raw/main/subssupport-install.sh"),
                config.plugins.xDreamy.install_historyzapselector: ("HistoryZapSelector", "https://raw.githubusercontent.com/biko-73/History_Zap_Selector/main/installer.sh"),
                config.plugins.xDreamy.install_newvirtualkeyboard: ("NewVirtualKeyBoard", "https://raw.githubusercontent.com/fairbird/NewVirtualKeyBoard/main/installer.sh"),
                config.plugins.xDreamy.install_raedquicksignal: ("RaedQuickSignal", "https://raw.githubusercontent.com/fairbird/RaedQuickSignal/main/installer.sh")
            }
            
            if sel in plugin_mapping:
                plugin_name, url = plugin_mapping[sel]
                self.installPlugin(plugin_name, url)
        except Exception as e:
            logger.error(_("Error handling plugin installation: {error}").format(error=e))

    def installPlugin(self, plugin_name, url):
        """Install plugin with improved user interaction."""
        try:
            if check_plugin_installed(plugin_name):
                choices = [
                    (_("Open"), "open"),
                    (_("Reinstall"), "reinstall"),
                    (_("Remove"), "remove"),
                    (_("Cancel"), "cancel")
                ]
                self.session.openWithCallback(
                    lambda result: self.runInstallation(result, plugin_name, url),
                    ChoiceBox,
                    title=_("{plugin_name} is already installed. What would you like to do?").format(plugin_name=plugin_name),
                    list=choices
                )
            else:
                self.session.openWithCallback(
                    lambda result: self.runInstallation(result, plugin_name, url),
                    MessageBox,
                    _("{plugin_name} is not installed. Do you want to install it now?").format(plugin_name=plugin_name),
                    MessageBox.TYPE_YESNO
                )
        except Exception as e:
            logger.error(_("Error in installPlugin: {error}").format(error=e))
            self.session.open(MessageBox, _("Error checking plugin status"), MessageBox.TYPE_ERROR)

    def runInstallation(self, result, plugin_name, url):
        """Execute plugin installation removal with validation."""
        try:
            if result == "open":
                self.session.open(MessageBox, _("Opening {plugin_name}...").format(plugin_name=plugin_name), MessageBox.TYPE_INFO, timeout=3)
                # Here you would implement plugin opening logic
            elif result == "reinstall" or result is True:
                # Validate URL before proceeding
                if not url.startswith(('http:', 'https:')):
                    raise ValueError(_("Invalid installation URL"))
                
                command = f"wget -q --no-check-certificate '{url}' -O - | bin sh"
                self.session.open(Console, _('Installing {plugin_name}').format(plugin_name=plugin_name), [command], closeOnSuccess=False)
            elif result == "remove":
                # Multiple removal methods
                remove_commands = [
                    f"opkg remove --autoremove enigma2-plugin-extensions-{plugin_name.lower()}",
                    f"opkg remove --autoremove {plugin_name.lower()}",
                    f"rm -rf /usr/lib/enigma2/python/Plugins/Extensions/{plugin_name}"
                ]
                self.session.open(Console, _('Removing {plugin_name}').format(plugin_name=plugin_name), remove_commands, closeOnSuccess=False)
            else:
                self.session.open(MessageBox, _("Operation cancelled."), MessageBox.TYPE_INFO, timeout=2)
        except Exception as e:
            logger.error(_("Error in runInstallation: {error}").format(error=e))
            self.session.open(MessageBox, _("Installation error: {error}").format(error=str(e)), MessageBox.TYPE_ERROR)

    def removPng(self):
        """Remove PNG files with user confirmation."""
        try:
            self.session.openWithCallback(
                self.removPngCallback,
                MessageBox,
                _("This will remove all cached poster and backdrop images.\nThis may free up storage space but images will need to be downloaded again.\n\nContinue?"),
                MessageBox.TYPE_YESNO
            )
        except Exception as e:
            logger.error(_("Error in removPng: {error}").format(error=e))

    def removPngCallback(self, result):
        """Handle PNG removal confirmation."""
        if result:
            try:
                removePng()
                self.session.open(MessageBox, _("Image cache cleared successfully!"), MessageBox.TYPE_INFO, timeout=3)
            except Exception as e:
                logger.error(_("Error removing PNG files: {error}").format(error=e))
                self.session.open(MessageBox, _("Error clearing image cache: {error}").format(error=str(e)), MessageBox.TYPE_ERROR)

    def KeyMenu(self):
        """Handle weather menu with error handling."""
        try:
            if fileExists(weatherz):
                self.session.open(MessageBox, _("Opening Weather Plugin..."), MessageBox.TYPE_INFO, timeout=2)
                # Here you would open the weather plugin
            else:
                self.session.open(MessageBox, _("Weather Plugin not found!"), MessageBox.TYPE_ERROR, timeout=3)
        except Exception as e:
            logger.error(_("Error in KeyMenu: {error}").format(error=e))

    def KeyMenu2(self):
        """Handle OA weather menu with error handling."""
        try:
            if fileExists(OAWeather):
                self.session.open(MessageBox, _("Opening OA Weather Plugin..."), MessageBox.TYPE_INFO, timeout=2)
                # Here you would open the OA weather plugin
            else:
                self.session.open(MessageBox, _("OA Weather Plugin not found!"), MessageBox.TYPE_ERROR, timeout=3)
        except Exception as e:
            logger.error(_("Error in KeyMenu2: {error}").format(error=e))

    # API key handling methods with improved error handling
    def keyApi(self, answer=None):
        """Handle TMDB API key import with validation."""
        api_file = "/tmp/apikey.txt"
        if answer is None:
            if fileExists(api_file) and os.stat(api_file).st_size > 0:
                self.session.openWithCallback(self.keyApi, MessageBox, 
                                            _("Import TMDB API Key from /tmp/apikey.txt?"))
            else:
                self.session.open(MessageBox, _("API key file not found: {api_file}").format(api_file=api_file), 
                                MessageBox.TYPE_INFO, timeout=4)
        elif answer:
            # Continue with API key import logic here
            pass
        elif answer:
            try:
                with open(api_file, 'r') as f:
                    api_key = f.readline().strip()
                
                if api_key and len(api_key) > 10:  # Basic validation
                    # Create directory if it doesn't exist
                    os.makedirs(os.path.dirname(tmdb_skin), exist_ok=True)
                    
                    with open(tmdb_skin, "w") as t:
                        t.write(api_key)
                    
                    config.plugins.xDreamy.txtapi.setValue(api_key)
                    config.plugins.xDreamy.api.setValue(True)
                    config.plugins.xDreamy.txtapi.save()
                    
                    self.session.open(MessageBox, _("TMDB API Key imported successfully!"), 
                                    MessageBox.TYPE_INFO, timeout=4)
                else:
                    self.session.open(MessageBox, _("Invalid API key format!"), 
                                    MessageBox.TYPE_ERROR, timeout=4)
            except Exception as e:
                logger.error(_("Error importing TMDB API key: {error}").format(error=e))
                self.session.open(MessageBox, _("Error importing API key"), MessageBox.TYPE_ERROR, timeout=4)
        
        self.createSetup()

    def keyApi2(self, answer=None):
        """Handle OMDB API key import with validation."""
        api_file = "/tmp/omdbkey.txt"
        
        if answer is None:
            if fileExists(api_file) and os.stat(api_file).st_size > 0:
                self.session.openWithCallback(self.keyApi2, MessageBox, 
                                            _("Import OMDB API Key from /tmp/omdbkey.txt?"))
            else:
                self.session.open(MessageBox, _("API key file not found: {api_file}").format(api_file=api_file), 
                                MessageBox.TYPE_INFO, timeout=4)
        elif answer:
            try:
                with open(api_file, 'r') as f:
                    api_key = f.readline().strip()
                
                if api_key and len(api_key) > 5:  # OMDB keys are shorter
                    os.makedirs(os.path.dirname(omdb_skin), exist_ok=True)
                    
                    with open(omdb_skin, "w") as t:
                        t.write(api_key)
                    
                    config.plugins.xDreamy.txtapi2.setValue(api_key)
                    config.plugins.xDreamy.api2.setValue(True)
                    config.plugins.xDreamy.txtapi2.save()
                    
                    self.session.open(MessageBox, _("OMDB API Key imported successfully!"), 
                                    MessageBox.TYPE_INFO, timeout=4)
                else:
                    self.session.open(MessageBox, _("Invalid API key format!"), 
                                    MessageBox.TYPE_ERROR, timeout=4)
            except Exception as e:
                logger.error(_("Error importing OMDB API key: {error}").format(error=e))
                self.session.open(MessageBox, _("Error importing API key"), MessageBox.TYPE_ERROR, timeout=4)
        
        self.createSetup()

    def keyApi3(self, answer=None):
        """Handle TheTVDB API key import with validation."""
        api_file = "/tmp/thetvdbkey.txt"
        
        if answer is None:
            if fileExists(api_file) and os.stat(api_file).st_size > 0:
                self.session.openWithCallback(self.keyApi3, MessageBox, 
                                            _("Import TheTVDB API Key from /tmp/thetvdbkey.txt?"))
            else:
                self.session.open(MessageBox, _("API key file not found: {api_file}").format(api_file=api_file), 
                                MessageBox.TYPE_INFO, timeout=4)
        elif answer:
            try:
                with open(api_file, 'r') as f:
                    api_key = f.readline().strip()
                
                if api_key and len(api_key) > 10:
                    os.makedirs(os.path.dirname(thetvdb_skin), exist_ok=True)
                    
                    with open(thetvdb_skin, "w") as t:
                        t.write(api_key)
                    
                    config.plugins.xDreamy.txtapi3.setValue(api_key)
                    config.plugins.xDreamy.api3.setValue(True)
                    config.plugins.xDreamy.txtapi3.save()
                    
                    self.session.open(MessageBox, _("TheTVDB API Key imported successfully!"), 
                                    MessageBox.TYPE_INFO, timeout=4)
                else:
                    self.session.open(MessageBox, _("Invalid API key format!"), 
                                    MessageBox.TYPE_ERROR, timeout=4)
            except Exception as e:
                logger.error(_("Error importing TheTVDB API key: {error}").format(error=e))
                self.session.open(MessageBox, _("Error importing API key"), MessageBox.TYPE_ERROR, timeout=4)
        
        self.createSetup()

    def keyApi4(self, answer=None):
        """Handle Fanart API key import with validation."""
        api_file = "/tmp/fanartkey.txt"
        
        if answer is None:
            if fileExists(api_file) and os.stat(api_file).st_size > 0:
                self.session.openWithCallback(self.keyApi4, MessageBox, 
                                            _("Import Fanart API Key from /tmp/fanartkey.txt?"))
            else:
                self.session.open(MessageBox, _("API key file not found: {api_file}").format(api_file=api_file), 
                                MessageBox.TYPE_INFO, timeout=4)
        elif answer:
            try:
                with open(api_file, 'r') as f:
                    api_key = f.readline().strip()
                
                if api_key and len(api_key) > 10:
                    os.makedirs(os.path.dirname(fanart_skin), exist_ok=True)
                    
                    with open(fanart_skin, "w") as t:
                        t.write(api_key)
                    
                    config.plugins.xDreamy.txtapi4.setValue(api_key)
                    config.plugins.xDreamy.api4.setValue(True)
                    config.plugins.xDreamy.txtapi4.save()
                    
                    self.session.open(MessageBox, _("Fanart API Key imported successfully!"), 
                                    MessageBox.TYPE_INFO, timeout=4)
                else:
                    self.session.open(MessageBox, _("Invalid API key format!"), 
                                    MessageBox.TYPE_ERROR, timeout=4)
            except Exception as e:
                logger.error(_("Error importing Fanart API key: {error}").format(error=e))
                self.session.open(MessageBox, _("Error importing API key"), MessageBox.TYPE_ERROR, timeout=4)
        
        self.createSetup()

    def KeyText(self):
        """Handle virtual keyboard input with validation."""
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            sel = self["config"].getCurrent()
            if sel and len(sel) > 1:
                self.session.openWithCallback(
                    self.VirtualKeyBoardCallback, 
                    VirtualKeyBoard, 
                    title=sel[0], 
                    text=sel[1].value
                )
        except ImportError:
            self.session.open(MessageBox, _("Virtual keyboard not available!"), MessageBox.TYPE_ERROR)
        except Exception as e:
            logger.error(_("Error opening virtual keyboard: {error}").format(error=e))

    def VirtualKeyBoardCallback(self, callback=None):
        """Handle virtual keyboard callback."""
        if callback is not None:
            current = self["config"].getCurrent()
            if current and len(current) > 1:
                current[1].value = callback
                self["config"].invalidate(current)

    def openSelectionPopup(self, current):
        """Open selection popup for ConfigSelection items."""
        try:
            sel = current[1]
            if hasattr(sel, "choices"):
                options = [(str(choice), choice) for choice in sel.choices]
                
                self.session.openWithCallback(
                    lambda choice: self.selectionMade(choice, sel),
                    ChoiceBox,
                    title=_("Select option for: ") + current[0],
                    list=options
                )
        except Exception as e:
            logger.error(_("Error opening selection popup: {error}").format(error=e))

    def selectionMade(self, choice, configItem):
        """Handle selection from popup."""
        if choice:
            configItem.value = choice[1]
            self.createSetup()

    def openCitySelection(self):
        """Open city selection dialog."""
        try:
            self.session.openWithCallback(
                self.citySelected, 
                LocationBox, 
                _("Select weather city"), 
                text=config.plugins.xDreamy.city.value
            )
        except Exception as e:
            logger.error(_("Error opening city selection: {error}").format(error=e))
            self.session.open(MessageBox, _("City selection not available"), MessageBox.TYPE_ERROR)

    def citySelected(self, result):
        """Handle city selection result."""
        if result:
            config.plugins.xDreamy.city.setValue(result)
            config.plugins.xDreamy.city.save()
            self['city'].setText(result)

    def keyLeft(self):
        """Handle left key press."""
        ConfigListScreen.keyLeft(self)
        self.handleSpecialConfigs()
        self.createSetup()

    def keyRight(self):
        """Handle right key press."""
        ConfigListScreen.keyRight(self)
        self.handleSpecialConfigs()
        self.createSetup()

    def keyUp(self):
        """Handle up key press."""
        ConfigListScreen.keyUp(self)
        self.ShowPicture()

    def keyDown(self):
        """Handle down key press."""
        ConfigListScreen.keyDown(self)
        self.ShowPicture()

    def handleSpecialConfigs(self):
        """Handle special configuration items that need immediate action."""
        current = self["config"].getCurrent()
        if current and len(current) > 1:
            sel = current[1]
        
            # Handle png removal config
            if sel == config.plugins.xDreamy.png:
                config.plugins.xDreamy.png.setValue(False)
            
            # Handle API configs
            api_configs = [
                config.plugins.xDreamy.api,
                config.plugins.xDreamy.api2, 
                config.plugins.xDreamy.api3,
                config.plugins.xDreamy.api4
            ]
            
            if sel in api_configs:
                sel.setValue(False)

    def keyExit(self):
        """Handle exit with confirmation."""
        self.session.openWithCallback(
            self.exitConfirmed,
            MessageBox,
            _("Close without saving changes?"),
            MessageBox.TYPE_YESNO
        )

    def exitConfirmed(self, answer):
        """Handle exit confirmation."""
        if answer:
            self.close()

    def getCurrentEntry(self):
        """Get current configuration entry."""
        current = self["config"].getCurrent()
        return current[0] if current else ""

    def getCurrentValue(self):
        """Get current configuration value."""
        current = self["config"].getCurrent()
        if current and len(current) > 1:
            return str(current[1].getText())
        return ""

    def createSummary(self):
        """Create setup summary."""
        from Screens.Setup import SetupSummary
        return SetupSummary
