#!/bin/sh
# XDREAMY dependency installer
# Logs everything to /tmp/XDREAMY_Installation.log

LOGFILE="/tmp/XDREAMY_Installation.log"
DEPS="wget curl python3-requests python3-pillow python3-imaging"

timestamp() {
    date +"%H:%M:%S"
}

log() {
    echo "$(timestamp) - $1" | tee -a "$LOGFILE"
}

header() {
    echo "" | tee -a "$LOGFILE"
    echo "===========================================================" | tee -a "$LOGFILE"
    echo "        ★ XDREAMY Dependency Installation Script ★          " | tee -a "$LOGFILE"
    echo "===========================================================" | tee -a "$LOGFILE"
}

update_feeds() {
    log "==> Updating package feeds..."
    tries=0
    while [ $tries -lt 3 ]; do
        if opkg update >>"$LOGFILE" 2>&1; then
            log "    • Package feeds updated successfully [✔]"
            return 0
        else
            tries=$((tries + 1))
            log "    • opkg update failed (try $tries)... retrying in 5s"
            sleep 5
        fi
    done
    log "    • Failed to update package feeds after 3 attempts [✘]"
    return 1
}

install_deps() {
    log "==> Installing dependencies..."
    for pkg in $DEPS; do
        if opkg list-installed | grep -q "^$pkg "; then
            log "    • $pkg already installed [skipped]"
        else
            log "    • Installing $pkg..."
            if opkg install "$pkg" >>"$LOGFILE" 2>&1; then
                log "      → $pkg installed successfully [✔]"
            else
                log "      → Failed to install $pkg [✘]"
            fi
        fi
    done
}

footer() {
    echo "" | tee -a "$LOGFILE"
    echo "===========================================================" | tee -a "$LOGFILE"
    echo "        XDREAMY dependency installation complete!           " | tee -a "$LOGFILE"
    echo "      Full log: $LOGFILE" | tee -a "$LOGFILE"
    echo "===========================================================" | tee -a "$LOGFILE"
}

# ------------------- MAIN ------------------- #
header
update_feeds
install_deps
footer
exit 0
