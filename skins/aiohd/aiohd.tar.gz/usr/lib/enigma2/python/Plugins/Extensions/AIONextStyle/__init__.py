# AIOHD NEXT style settings.
