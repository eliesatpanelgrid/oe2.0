# -*- coding: utf-8 -*-

from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import eEPGCache, eServiceReference
from time import localtime, strftime, mktime, time
from datetime import datetime, timedelta
import logging

# Configure the logger
logger = logging.getLogger("EventListLogger")
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)


class AglareEventList(Converter, object):
    def __init__(self, type):
        Converter.__init__(self, type)
        self.epgcache = eEPGCache.getInstance()
        self.primetime = 0
        self.eventcount = 0
        self.beginOnly = False

        # Parse the input arguments
        if len(type):
            args = type.split(',')
            i = 0
            while i <= len(args) - 1:
                type_c, value = args[i].split('=')
                if type_c == "eventcount":
                    self.eventcount = int(value)
                elif type_c == "primetime":
                    if value == "yes":
                        self.primetime = 1
                elif type_c == "beginOnly":
                    if value == "yes":
                        self.beginOnly = True
                i += 1

    @cached
    def getContent(self):
        contentList = []
        seen_begins = set()  # Track event start times to prevent duplicates
        
        ref = self.source.service
        info = ref and self.source.info
        if info is None:
            return []

        if not self.epgcache:
            return contentList

        # Bulk fetch all upcoming EPG events for this service (immune to minor time gaps)
        events = self.epgcache.lookupEvent(["IBDCT", (ref.toString(), 0, -1, -1)])
        
        if events:
            count = 0
            for e in events:
                if count >= self.eventcount:
                    break
                
                begin = e[1]
                dur = e[2]
                title = e[4] or ""
                
                if begin is None or dur is None:
                    continue
                    
                if begin not in seen_begins:
                    # Format time string based on 'beginOnly' setting
                    if self.beginOnly:
                        event_time = "%s" % (strftime("%H:%M", localtime(begin)))
                    else:
                        end = begin + dur
                        event_time = "%s - %s" % (
                            strftime("%H:%M", localtime(begin)),
                            strftime("%H:%M", localtime(end)),
                        )
                    duration = "%d min" % (dur / 60)
                    
                    contentList.append((event_time, title, duration))
                    seen_begins.add(begin)
                    count += 1

        # Primetime logic (Keep as fallback specific lookup)
        if self.primetime == 1:
            now = localtime(time())
            dt = datetime(now.tm_year, now.tm_mon, now.tm_mday, 20, 15)
            if time() > mktime(dt.timetuple()):
                dt += timedelta(days=1)  # Skip to the next day...
            primeTime = int(mktime(dt.timetuple()))

            event = self.epgcache.lookupEventTime(
                eServiceReference(ref.toString()), primeTime
            )
            
            if event:
                bt = event.getBeginTime()
                if bt is not None and bt <= primeTime and bt not in seen_begins:
                    contentList.append(self.getEventTuple(event))

        return contentList

    def getEventTuple(self, event):
        try:
            begin = event.getBeginTime()
            dur = event.getDuration()

            if begin is None or dur is None:
                return ("", "", "")

            if self.beginOnly:
                event_time = "%s" % (strftime("%H:%M", localtime(begin)))
            else:
                end = begin + dur
                event_time = "%s - %s" % (
                    strftime("%H:%M", localtime(begin)),
                    strftime("%H:%M", localtime(end)),
                )

            title = event.getEventName() or ""
            duration = "%d min" % (dur / 60)
            return (event_time, title, duration)
        except Exception as e:
            logger.error("Error in getEventTuple: %s", e)
            return ("Error", "Error retrieving event", "")

    def changed(self, what):
        if what[0] != self.CHANGED_SPECIFIC:
            Converter.changed(self, what)

"""
<widget source="ServiceEvent" render="AglareEventListDisplay" position="100,700" size="800,200" 
        backgroundColor="#FF000000" transparent="1" zPosition="50"
        rowHeight="40" primetimeoffset="15"
        column0="0,150,yellow,Regular,32,0,0" 
        column1="160,500,white,Regular,32,0,1"
        column2="670,130,grey,Regular,28,2,2">
    <convert type="AglareEventList">beginOnly=yes,primetime=yes,eventcount=4</convert>
</widget>
"""