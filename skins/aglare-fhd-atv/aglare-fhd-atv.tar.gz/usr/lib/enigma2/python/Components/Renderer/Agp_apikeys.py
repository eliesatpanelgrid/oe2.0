#!/usr/bin/python
# -*- coding: utf-8 -*-
###################################
# # __author__ = "Lululla"      # #
# # __copyright__ = "AGP Team"  # #
# # __modified_by__ = "MNASR"   # #
###################################
from __future__ import absolute_import, print_function
# Standard library imports
from Components.config import config
from pathlib import Path
from threading import Lock

# Initialize thread lock for API access synchronization
api_lock = Lock()

# Pre-define globals so imports never fail even if config loading crashes
tmdb_api = "3c3efcf47c3577558812bb9d64019d65"
omdb_api = "cb1d9f55"
thetvdb_api = "a99d487bb3426e5f3a60dea6d3d3c7ef"
fanart_api = "6d231536dea4318a88cb2520ce89473b"

API_KEYS = {
    "tmdb_api": tmdb_api,
    "omdb_api": omdb_api,
    "thetvdb_api": thetvdb_api,
    "fanart_api": fanart_api,
}


def _load_api_keys():
    global tmdb_api, omdb_api, thetvdb_api, fanart_api
    try:
        cur_skin = config.skin.primary_skin.value.replace("/skin.xml", "")
        skin_path = Path(f"/usr/share/enigma2/{cur_skin}")

        # Map API key names to the physical file paths in Aglare
        key_files = {
            "tmdb_api": skin_path / "tmdbkey",
            "omdb_api": skin_path / "omdbkey",
            "thetvdb_api": skin_path / "thetvdbkey",
            "fanart_api": skin_path / "fanartkey"
        }

        plugin_cfg = config.plugins.Aglare

        # Safe fetch config parameters to avoid AttributeErrors
        plugin_keys = {
            "tmdb_api": (getattr(plugin_cfg, "tmdb", getattr(plugin_cfg, "actapi", None)), getattr(plugin_cfg, "tmdb_api", getattr(plugin_cfg, "txtapi", None))),
            "omdb_api": (getattr(plugin_cfg, "omdb", getattr(plugin_cfg, "actapi", None)), getattr(plugin_cfg, "omdb_api", getattr(plugin_cfg, "txtapi2", None))),
            "thetvdb_api": (getattr(plugin_cfg, "thetvdb", getattr(plugin_cfg, "actapi", None)), getattr(plugin_cfg, "thetvdb_api", None)),
            "fanart_api": (getattr(plugin_cfg, "fanart", getattr(plugin_cfg, "actapi", None)), getattr(plugin_cfg, "fanart_api", None)),
        }

        keys_loaded = False
        with api_lock:
            for key_name in key_files:
                enabled_cfg, key_cfg = plugin_keys.get(key_name, (None, None))

                # Check plugin configuration prioritization
                enabled = enabled_cfg.value if enabled_cfg else False
                key_value = key_cfg.value if key_cfg else ""

                if enabled and key_value and key_value.strip():
                    API_KEYS[key_name] = key_value.strip()
                    keys_loaded = True
                    continue

                # Fallback to checking skin directory files
                file_path = key_files[key_name]
                if file_path.exists():
                    try:
                        with open(file_path, "r") as f:
                            key_val = f.read().strip()
                        if key_val:
                            API_KEYS[key_name] = key_val
                            keys_loaded = True
                            if key_cfg:
                                key_cfg.value = key_val
                    except Exception:
                        pass

        # Explicitly assign loaded API keys to global variables
        tmdb_api = API_KEYS["tmdb_api"]
        omdb_api = API_KEYS["omdb_api"]
        thetvdb_api = API_KEYS["thetvdb_api"]
        fanart_api = API_KEYS["fanart_api"]

        # Save to persist updates fetched from .txt files
        try:
            plugin_cfg.save()
        except Exception:
            pass

        return keys_loaded

    except Exception as e:
        print(f"[API Config] Critical error loading keys: {str(e)}")
        return False

# Trigger initialization


if not _load_api_keys():
    print("[API Config] Using default API keys")
