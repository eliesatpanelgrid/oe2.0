# -*- coding: utf-8 -*-
# Universal Multi-Image & Multi-Python Enigma2 Native Loader
# Auto-detects receiver CPU and Python version at runtime (OpenATV, OpenPLi, Egami, OpenBH, etc.)
import os
import sys
import platform
import traceback

_curr_dir = os.path.dirname(os.path.abspath(__file__))
if _curr_dir and _curr_dir not in sys.path:
    sys.path.insert(0, _curr_dir)

def _detect_arch():
    try:
        machine = platform.machine().lower()
    except Exception:
        machine = ""
    is_64 = sys.maxsize > 2**32
    if "aarch64" in machine or (("arm" in machine) and is_64):
        return "aarch64"
    elif "arm" in machine:
        return "arm"
    elif "mips" in machine:
        return "mips"
    elif "x86_64" in machine or "amd64" in machine:
        return "x86_64"
    try:
        import os
        u = os.uname()[4].lower()
        if "aarch64" in u: return "aarch64"
        if "arm" in u: return "arm"
        if "mips" in u: return "mips"
        if "x86_64" in u: return "x86_64"
    except Exception:
        pass
    if os.path.exists("/proc/cpuinfo"):
        try:
            with open("/proc/cpuinfo", "r") as _f_cpu:
                _c_info = _f_cpu.read().lower()
                if "mips" in _c_info or "bcm73" in _c_info or "bcm74" in _c_info or "broadcom" in _c_info:
                    return "mips"
                elif "aarch64" in _c_info or "armv8" in _c_info:
                    return "aarch64"
                elif "arm" in _c_info:
                    return "arm"
        except Exception:
            pass
    return "arm"

_arch = _detect_arch()
_py_major = sys.version_info[0]
_py_minor = sys.version_info[1]

# Candidate search paths in priority order
_candidates = []
# 1. Exact arch + exact py version: arch/arm/py3.13/core_plugin.so
_candidates.append(os.path.join(_curr_dir, "arch", _arch, "py%d.%d" % (_py_major, _py_minor), "auto_sync_engine.so"))

# 2. Same-version fallback only: a Cython .so compiled for a different Python
#    minor version MUST NOT be loaded (it corrupts memory and crashes the receiver
#    with SIGILL/Fatal Signal 4). We therefore only accept the exact version match.
if _py_major == 3:
    _exact = "py%d.%d" % (_py_major, _py_minor)
    _candidates.append(os.path.join(_curr_dir, "arch", _arch, _exact, "auto_sync_engine.so"))

# 3. Direct arch folder: arch/arm/core_plugin.so
_candidates.append(os.path.join(_curr_dir, "arch", _arch, "auto_sync_engine.so"))
# 4. Root dir fallback
_candidates.append(os.path.join(_curr_dir, "auto_sync_engine.so"))

_so_path = None
for _c in _candidates:
    if os.path.isfile(_c):
        _so_path = _c
        break

if not _so_path:
    _err_msg = "[Enigma2 Universal Loader] No compatible binary found for Arch: %s, Python: %d.%d in paths:\n" % (_arch, _py_major, _py_minor)
    _err_msg += "\n".join(_candidates)
    sys.stderr.write(_err_msg + "\n")
    raise ImportError(_err_msg)

_target_file = os.path.join(_curr_dir, "auto_sync_engine.py")
_mod = None
if _py_major >= 3:
    import importlib.util
    _pkg = __name__.rpartition('.')[0]
    _mod_name = "auto_sync_engine" if not _pkg else f"{_pkg}.auto_sync_engine"
    _spec = importlib.util.spec_from_file_location(_mod_name, _so_path)
    if _spec and _spec.loader:
        _temp_mod = importlib.util.module_from_spec(_spec)
        sys.modules[_spec.name] = _temp_mod
        try:
            _temp_mod.__file__ = _target_file
            _temp_mod.__dict__['__file__'] = _target_file
        except Exception:
            pass
        try:
            _spec.loader.exec_module(_temp_mod)
            _mod = _temp_mod
        except Exception as _e_exec:
            sys.modules.pop(_spec.name, None)
            raise
else:
    import imp
    _mod = imp.load_dynamic("auto_sync_engine", _so_path)

if _mod is not None:
    try:
        _mod.__file__ = _target_file
        _mod.__dict__['__file__'] = _target_file
    except Exception:
        pass
    _cur_mod = sys.modules.get(__name__)
    if _cur_mod is not None:
        _cur_mod.__file__ = _target_file
    for _k in dir(_mod):
        if not _k.startswith('__'):
            _v = getattr(_mod, _k)
            globals()[_k] = _v
            if _cur_mod is not None:
                setattr(_cur_mod, _k, _v)
    if hasattr(_mod, 'Plugins'):
        _p_fn = getattr(_mod, 'Plugins')
        globals()['Plugins'] = _p_fn
        if _cur_mod is not None:
            setattr(_cur_mod, 'Plugins', _p_fn)
