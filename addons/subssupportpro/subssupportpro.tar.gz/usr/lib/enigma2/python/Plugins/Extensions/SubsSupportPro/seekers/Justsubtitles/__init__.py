# -*- coding: utf-8 -*-
from __future__ import absolute_import
# Dummy file to make this directory a package.
from . import service as justsubtitles
