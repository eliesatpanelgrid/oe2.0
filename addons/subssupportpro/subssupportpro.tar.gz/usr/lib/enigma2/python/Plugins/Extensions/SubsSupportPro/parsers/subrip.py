# -*- coding: utf-8 -*-
from __future__ import absolute_import
import re

from .baseparser import BaseParser, ParseError, HEX_COLORS


class SubRipParser(BaseParser):
    format = "SubRip"
    parsing = ('.srt', '.sub')

    def _parse(self, text, fps):
        return self._srt_to_dict(text)

    def _removeTags(self, text):
        lines = text.split('\n')
        cleaned_lines = []
        for line in lines:
            line = re.sub('<[^>]*>', '', line)
            line = re.sub(r'\{.*?\}', '', line)
            line = line.strip()
            cleaned_lines.append(line)
        return '\n'.join(filter(None, cleaned_lines))

    def _getColor(self, text, color):
        newColor = color
        if color:
            if color != 'default':
                if text.find('</font>') != -1 or text.find('</Font>') != -1:
                    newColor = 'default'
            else:
                colorMatch = re.search(
                    '<[Ff]ont [Cc]olor=(.+?)>', text, re.DOTALL)
                colorText = colorMatch and colorMatch.group(1)
                colorText = colorText and colorText.replace(
                    "'", "").replace('"', '')
                if text.find('</font>') != -1 or text.find('</Font>') != -1:
                    newColor = 'default'
                else:
                    newColor = color
        else:
            color = 'default'
            colorMatch = re.search('<[Ff]ont [Cc]olor=(.+?)>', text, re.DOTALL)
            colorText = colorMatch and colorMatch.group(1) or color
            colorText = colorText.replace("'", "").replace('"', '')

        if colorText:
            hexColor = re.search(r"(\#[0-9,a-f,A-F]{6})", colorText)
            if hexColor:
                color = hexColor.group(1)[1:]
            else:
                try:
                    color = HEX_COLORS[colorText.lower()][1:]
                except KeyError:
                    pass
        return color, newColor

    def _getStyle(self, text, style):
        newStyle = style
        endTag = False
        if not style:
            if self.italicStart(text):
                style = 'italic'
                newStyle = style
                endTag = self.italicEnd(text)
            elif self.boldStart(text):
                style = 'bold'
                newStyle = style
                endTag = self.boldEnd(text)
            elif self.underlineStart(text):
                style = 'regular'
                newStyle = style
        else:
            if style == 'italic':
                endTag = self.italicEnd(text)
            elif style == 'bold':
                endTag = self.boldEnd(text)
            elif style == 'underline':
                endTag = True
            else:
                if self.italicStart(text):
                    style = 'italic'
                    newStyle = style
                    endTag = self.italicEnd(text)
                elif self.boldStart(text):
                    style = 'bold'
                    newStyle = style
                    endTag = self.boldEnd(text)
                elif self.underlineStart(text):
                    style = 'regular'
                    newStyle = style

        if endTag:
            newStyle = 'regular'
        return style, newStyle

    def _srt_to_dict(self, srtText):
        subs = []

        # 1. Strictly strip the BOM (Byte Order Mark) if present
        if srtText.startswith(u'\ufeff') or srtText.startswith('\ufeff'):
            srtText = srtText[1:]

        # 2. Strip any weird zero-width non-joiners or directional markers
        control_chars = (u"\u200B", u"\u200C", u"\u200D", u"\u200E",
                         u"\u200F", u"\u202A", u"\u202B", u"\u202C", u"\u202D", u"\u202E")
        for char in control_chars:
            srtText = srtText.replace(char, '')

        # Standardize line endings and split by blank lines to isolate every block
        srtText = srtText.replace('\r\n', '\n').strip()
        blocks = re.split(r'\n\s*\n', srtText)

        for block in blocks:
            block = block.strip()
            if not block:
                continue

            lines = block.split('\n')
            if len(lines) < 2:
                continue

            # Find which line has the timestamp '-->'
            time_line_idx = -1
            for i, line in enumerate(lines):
                if '-->' in line:
                    time_line_idx = i
                    break

            if time_line_idx == -1:
                continue

            time_line = lines[time_line_idx]
            text_lines = lines[time_line_idx + 1:]

            # Target just the timestamps, ignoring formatting errors
            m = re.search(
                r'(\d+):(\d+):(\d+),(\d+)\s*-->\s*(\d+):(\d+):(\d+),(\d+)', time_line)
            if m:
                try:
                    shour, smin, ssec, smsec = map(int, m.groups()[0:4])
                    ehour, emin, esec, emsec = map(int, m.groups()[4:8])

                    start_time = int(
                        (shour * 3600 + smin * 60 + ssec) * 1000 + smsec)
                    end_time = int(
                        (ehour * 3600 + emin * 60 + esec) * 1000 + emsec)

                    sub_text = '\n'.join(text_lines).strip()
                    subs.append(self.createSub(sub_text, start_time, end_time))
                except Exception:
                    # If a block fails, silently skip it and keep going!
                    continue

        if not subs:
            raise ParseError("No valid subtitles found in file.")

        return subs

    def italicStart(self, text):
        return text.lower().find('<i>') != -1

    def italicEnd(self, text):
        return text.lower().find('</i>') != -1

    def boldStart(self, text):
        return text.lower().find('<b>') != -1

    def boldEnd(self, text):
        return text.lower().find('</b>') != -1

    def underlineStart(self, text):
        return text.lower().find('<u>') != -1

    def underlineEnd(self, text):
        return text.lower().find('</u>') != -1


parserClass = SubRipParser
