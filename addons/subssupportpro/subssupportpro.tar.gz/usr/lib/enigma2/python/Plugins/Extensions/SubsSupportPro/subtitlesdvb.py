# -*- coding: utf-8 -*-
'''
Created on Sep 16, 2014

@author: marko
'''
from __future__ import absolute_import
from __future__ import print_function
import os
import time
import json
from . import _

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

from Components.ActionMap import ActionMap, HelpableActionMap
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.config import (
    config, ConfigSubsection, getConfigListEntry, ConfigSelection,
    ConfigOnOff, ConfigText, ConfigNothing
)
from Components.ConfigList import ConfigListScreen
from Components.config import configfile
from Screens.HelpMenu import HelpableScreen
from .compat import MessageBox, eConnectCallback
from Screens.Screen import Screen
from Components.MenuList import MenuList
from .e2_utils import getFps, fps_float, BaseProMenuScreen, is4K, is2K, isFullHD, load_subskin
from enigma import eTimer, eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, eConsoleAppContainer
from .parsers.baseparser import ParseError
from .process import LoadError, DecodeError, ParserNotFoundError
from skin import parseColor
from .subtitles import (
    SubsProChooser, initSubsProSettings, SubsScreen,
    SubsLoader, PARSERS, ALL_LANGUAGES_ENCODINGS, ENCODINGS,
    warningMessage
)
from Components.MultiContent import MultiContentEntryText
from Components.Sources.StaticText import StaticText
from .utils import toString, toUnicode

config.plugins.subsSupportPro = ConfigSubsection()
config.plugins.subsSupportPro.dvb = ConfigSubsection()
config.plugins.subsSupportPro.dvb.autoSync = ConfigOnOff(default=True)
config.plugins.subsSupportPro.dvb.fpsDriftEnable = ConfigOnOff(default=False)
config.plugins.subsSupportPro.dvb.fpsRatio_23_976 = ConfigText(
    default="1.0000", fixed_size=False)
config.plugins.subsSupportPro.dvb.fpsRatio_24_000 = ConfigText(
    default="1.0000", fixed_size=False)
config.plugins.subsSupportPro.dvb.fpsRatio_25_000 = ConfigText(
    default="1.0000", fixed_size=False)
config.plugins.subsSupportPro.dvb.fpsRatio_29_970 = ConfigText(
    default="1.0000", fixed_size=False)
config.plugins.subsSupportPro.dvb.fpsRatio_30_000 = ConfigText(
    default="1.0000", fixed_size=False)
config.plugins.subsSupportPro.dvb.fpsRatio_50_000 = ConfigText(
    default="1.0000", fixed_size=False)
config.plugins.subsSupportPro.dvb.fpsRatio_59_940 = ConfigText(
    default="1.0000", fixed_size=False)

# Define available TTS languages
TTS_LANGUAGES = [
    ("en", _("English")),
    ("ar", _("Arabic")),
    ("fr", _("French")),
    ("de", _("German")),
    ("es", _("Spanish")),
    ("it", _("Italian")),
    ("tr", _("Turkish")),
    ("ru", _("Russian")),
]

# FIX: Attached correctly to config.plugins.subsSupportPro
config.plugins.subsSupportPro.ttsLanguage = ConfigSelection(
    default="en", choices=TTS_LANGUAGES)
config.plugins.subsSupportPro.ttsEnabled = ConfigOnOff(default=False)


def _play_tts_async(text, url, target_duration, container, mp3_path):
    import requests
    import subprocess
    import threading
    import os
    from twisted.internet import reactor

    def _worker():
        try:
            # 1. Download the MP3 (with headers to bypass Google blocks)
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Referer": "https://translate.google.com/"
            }
            res = requests.get(url, headers=headers, timeout=5)
            
            with open(mp3_path, "wb") as f:
                f.write(res.content)

            # Abort if Google blocked it (tiny HTML error file instead of MP3)
            if not os.path.exists(mp3_path) or os.path.getsize(mp3_path) < 1000:
                print("[SubsSupportPro] TTS Download failed or file too small.")
                return

            # 2. Probe the actual duration of the MP3
            orig_dur = None
            try:
                out = subprocess.check_output([
                    'ffprobe', '-v', 'error', '-show_entries', 'format=duration',
                    '-of', 'default=noprint_wrappers=1:nokey=1', mp3_path
                ])
                orig_dur = float(out.strip())
            except Exception:
                pass

            # 3. Fallback approximation if ffprobe is not installed (~14 chars per sec)
            if orig_dur is None:
                orig_dur = max(len(text) / 14.0, 1.0)

            # 4. Calculate the speed ratio needed to fit the visual line time
            ratio = orig_dur / target_duration if target_duration > 0 else 1.0
            ratio = max(1.0, min(ratio, 2.0))

            # 5. Build the tempo filter flag for ffmpeg
            atempo_str = "-af atempo=%.2f" % ratio if ratio > 1.05 else ""

            # 6. Execute the playback
            # We use a flat OR chain without subshells to prevent DreamOS parsing errors.
            # gst-launch requires 'file://' with an absolute path (e.g., file:///tmp/subs.mp3)
            file_uri = "file://" + mp3_path
            cmd = (
                'ffplay -nodisp -autoexit -loglevel quiet {atempo} {mp3} || '
                'ffmpeg -loglevel quiet -i {mp3} {atempo} -f alsa default || '
                'gst-launch-1.0 playbin uri="{uri}"'
            ).format(atempo=atempo_str, mp3=mp3_path, uri=file_uri)

            # 7. Push the execution back to the Enigma2 main thread safely
            reactor.callFromThread(_play_cmd, cmd)
            
        except Exception as e:
            print("[SubsSupportPro] TTS Worker Error:", str(e))

    def _play_cmd(cmd):
        try:
            container.execute(cmd)
        except Exception as e:
            print("[SubsSupportPro] Container Execute Error:", str(e))

    # Launch in a non-blocking thread
    threading.Thread(target=_worker).start()


class SubsProSetupDVBPlayer(BaseProMenuScreen):
    def __init__(self, session, dvbSettings):
        BaseProMenuScreen.__init__(self, session, _("DVB player settings"))
        self.dvbSettings = dvbSettings

        # --- FIX FOR CUSTOM SKINS (Ostende, etc.) ---
        from Components.Pixmap import Pixmap
        from Components.Label import Label
        self["HelpWindow"] = Pixmap()
        self["HelpWindow"].hide()
        self["VKeyIcon"] = Pixmap()
        self["VKeyIcon"].hide()
        self["description"] = Label("")
        self["description"].hide()
        # ---------------------------------------------

    def buildMenu(self):
        lst = []
        lst.append(getConfigListEntry(
            _("Auto sync to current event"), self.dvbSettings.autoSync))
        lst.append(getConfigListEntry(_("Text-to-Speech audio language"),
                   config.plugins.subsSupportPro.ttsLanguage))
        lst.append(getConfigListEntry(" ", ConfigNothing()))

        lst.append(getConfigListEntry(
            _("Try to correct FPS drift with FPS ratio"),
            config.plugins.subsSupportPro.dvb.fpsDriftEnable
        ))

        if config.plugins.subsSupportPro.dvb.fpsDriftEnable.value:
            lst.append(getConfigListEntry(
                _("Subtitles late: Decrease Ratio. Subtitles rush: Increase Ratio"),
                ConfigNothing()
            ))
            lst.append(getConfigListEntry(_("Override Ratio for 23.976 (Standard is 1.0000)"),
                                          config.plugins.subsSupportPro.dvb.fpsRatio_23_976))
            lst.append(getConfigListEntry(_("Override Ratio for 24.000 (Standard is 1.0000)"),
                                          config.plugins.subsSupportPro.dvb.fpsRatio_24_000))
            lst.append(getConfigListEntry(_("Override Ratio for 25.000 (Standard is 1.0000)"),
                                          config.plugins.subsSupportPro.dvb.fpsRatio_25_000))
            lst.append(getConfigListEntry(_("Override Ratio for 29.970 (Standard is 1.0000)"),
                                          config.plugins.subsSupportPro.dvb.fpsRatio_29_970))
            lst.append(getConfigListEntry(_("Override Ratio for 30.000 (Standard is 1.0000)"),
                                          config.plugins.subsSupportPro.dvb.fpsRatio_30_000))
            lst.append(getConfigListEntry(_("Override Ratio for 50.000 (Standard is 1.0000)"),
                                          config.plugins.subsSupportPro.dvb.fpsRatio_50_000))
            lst.append(getConfigListEntry(_("Override Ratio for 59.940 (Standard is 1.0000)"),
                                          config.plugins.subsSupportPro.dvb.fpsRatio_59_940))

        self["config"].setList(lst)

    def _rebuildIfToggle(self):
        cur = self["config"].getCurrent()
        if not cur:
            return
        cfg = cur[1]
        if cfg is config.plugins.subsSupportPro.dvb.fpsDriftEnable:
            self.buildMenu()

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self._rebuildIfToggle()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self._rebuildIfToggle()

    def keyOK(self):
        try:
            ConfigListScreen.keyOK(self)
        except Exception:
            pass
        self._rebuildIfToggle()


class SubsProSupportDVB(object):
    def __init__(self, session):
        self.session = session
        self.subsProSettings = initSubsProSettings()
        session.openWithCallback(self.subsChooserCB, SubsProChooser, self.subsProSettings,
                                 searchSupport=True, historySupport=True, titleList=self.getTitleList())

    def getTitleList(self):
        eventList = []
        eventNow = self.session.screen["Event_Now"].getEvent()
        eventNext = self.session.screen["Event_Next"].getEvent()
        if eventNow:
            eventList.append(eventNow.getEventName())
        if eventNext:
            eventList.append(eventNext.getEventName())

        if not eventList:
            try:
                service = self.session.nav.getCurrentService()
                info = service and service.info()
                if info:
                    channel_name = info.getName()
                    if channel_name:
                        eventList.append(channel_name)
            except Exception:
                pass

        return eventList

    def subsChooserCB(self, subfile=None, embeddedSubtitle=None, forceReload=False):
        if subfile is not None:
            subsLoader = SubsLoader(PARSERS, ALL_LANGUAGES_ENCODINGS +
                                    ENCODINGS[self.subsProSettings.encodingsGroup.getValue()])
            try:
                subsList, subsEnc = subsLoader.load(
                    subfile, fps=getFps(self.session))
            except LoadError:
                warningMessage(self.session, _(
                    "Cannot load subtitles. Invalid path"))
            except DecodeError:
                warningMessage(self.session, _(
                    "Cannot decode subtitles. Try another encoding group"))
            except ParserNotFoundError:
                warningMessage(self.session, _(
                    "Cannot parse subtitles. Not supported subtitles format"))
            except ParseError:
                warningMessage(self.session, _(
                    "Cannot parse subtitles. Invalid subtitles format"))
            else:
                self.subsScreen = self.session.instantiateDialog(
                    SubsScreen, self.subsProSettings.external)
                subsEngine = SubsEngineDVB(
                    self.session, self.subsProSettings.engine, self.subsScreen)
                subsEngine.setSubsList(subsList)
                self.session.openWithCallback(
                    self.subsControllerCB,
                    SubsProControllerDVB,
                    subsEngine,
                    config.plugins.subsSupportPro.dvb.autoSync.value,
                    False,
                    None,
                    self.subsProSettings.external
                )

    def subsControllerCB(self):
        self.session.deleteDialog(self.subsScreen)


class SubtitleProPicker(Screen):
    def __init__(self, session, subsList, currentIndex):
        self.subsList = subsList or []
        try:
            self.currentIndex = int(currentIndex)
        except Exception:
            self.currentIndex = 0

        self._configure_layout()
        Screen.__init__(self, session)

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions",
                "DirectionActions", "SubtitleProPickerActions"],
            {
                "ok": self.selectSubtitle,
                "green": self.selectSubtitle,
                "cancel": self.close,
                "red": self.close,
                "yellow": self.playAudioLine,  # TTS Listen Button
                "firstSubtitle": self.firstSubtitle,
                "lastSubtitle": self.lastSubtitle,
            },
            5
        )

        self["subList"] = MenuList(
            [], enableWrapAround=True, content=eListboxPythonMultiContent)
            
        # Perfectly safe on both OS versions because content is eListboxPythonMultiContent
        self["subList"].l.setItemHeight(self.row_height)
        self["subList"].l.setFont(0, gFont("Regular", self.row_font_size))

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Select"))
        self["key_yellow"] = StaticText(_("Listen"))

        self.updateSubtitleList()
        self.onLayoutFinish.append(self.setInitialSelection)

    def _configure_layout(self):
        """Build a conservative picker layout for SD, HD and Full-HD skins."""
        try:
            _is4k = is4K()
            _is2k = is2K()
            _isfhd = isFullHD()
        except Exception:
            _is4k = _is2k = _isfhd = False

        if _is4k:
            skin_id = "SubtitleProPicker_4k"
            self.list_height = 1400
            self.row_height = 140
            self.row_font_size = 42
            self.number_width = 260
            self.time_width = 680
            self.subtitle_width = 2300
        elif _is2k:
            skin_id = "SubtitleProPicker_2k"
            self.list_height = 933
            self.row_height = 93
            self.row_font_size = 28
            self.number_width = 173
            self.time_width = 453
            self.subtitle_width = 1533
        elif _isfhd:
            skin_id = "SubtitleProPicker_fhd"
            self.list_height = 700
            self.row_height = 70
            self.row_font_size = 21
            self.number_width = 130
            self.time_width = 340
            self.subtitle_width = 1150
        else:
            skin_id = "SubtitleProPicker_hd"
            self.list_height = 460
            self.row_height = 46
            self.row_font_size = 14
            self.number_width = 86
            self.time_width = 226
            self.subtitle_width = 766

        self.number_x = 0
        self.time_x = self.number_width
        self.subtitle_x = self.number_width + self.time_width
        self.skin = load_subskin(skin_id)

    def playAudioLine(self):
        index = self["subList"].getSelectedIndex()
        if not (0 <= index < len(self.subsList)):
            return

        sub = self.subsList[index]
        text = self.clean_display_text(sub.get("text", ""))
        text = text.replace('\n', ' ').strip()
        if not text:
            return

        # Calculate exact duration of the subtitle block in seconds
        target_duration = float(sub.get("end", 0)) - float(sub.get("start", 0))

        try:
            try:
                from urllib.parse import quote
            except ImportError:
                from urllib import quote
            safe_text = quote(text.encode('utf-8'))
        except Exception:
            safe_text = quote(str(text))

        tts_lang = config.plugins.subsSupportPro.ttsLanguage.value
        url = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=%s&q=%s" % (
            tts_lang, safe_text)

        # --- THE FIX: Clean up old container and create a fresh one ---
        if hasattr(self, "audio_container") and self.audio_container is not None:
            self.audio_container.kill()  # Explicitly kill the old audio process
            self.audio_container = None

        self.audio_container = eConsoleAppContainer()
        
        # Bind a dummy callback so DreamOS doesn't garbage collect it prematurely
        def _audio_finished(retval=None):
            pass
            
        try:
            from compat import eConnectCallback
            self.audio_container_conn = eConnectCallback(self.audio_container.appClosed, _audio_finished)
        except Exception:
            try:
                self.audio_container.appClosed.append(_audio_finished)
            except Exception:
                pass
        # --------------------------------------------------------------

        _play_tts_async(text, url, target_duration,
                        self.audio_container, "/tmp/subs_tts.mp3")

    def firstSubtitle(self):
        if self.subsList:
            self["subList"].moveToIndex(0)

    def lastSubtitle(self):
        if self.subsList:
            self["subList"].moveToIndex(len(self.subsList) - 1)

    def selectSubtitle(self):
        index = self["subList"].getSelectedIndex()
        if 0 <= index < len(self.subsList):
            self.close(index)

    def _picker_text(self, value):
        try:
            return toString(value)
        except Exception:
            return ""

    def _picker_unicode(self, value):
        import six
        try:
            return toUnicode(value)
        except Exception:
            try:
                return six.text_type(value)
            except Exception:
                return u""

    def updateSubtitleList(self):
        self.setTitle("Select Subtitle Line - Total: %d" % len(self.subsList))
        menu_items = []
        vertical_padding = 6
        single_line_y = max(0, int((self.row_height - self.row_font_size) / 2))

        for subtitle in self.subsList:
            try:
                caption_number = "%d" % (int(subtitle.get("index", 0)) + 1)
            except Exception:
                caption_number = "?"

            timestamp = self.format_time(subtitle.get("start", 0))
            subtitle_text = self.clean_display_text(subtitle.get("text") or "")
            display_text = self._limit_display_lines(
                subtitle_text, max_lines=2)

            row = [
                subtitle,
                MultiContentEntryText(
                    pos=(self.number_x + 6, single_line_y),
                    size=(self.number_width - 10, self.row_font_size + 6),
                    font=0,
                    text=self._picker_text(caption_number),
                    flags=RT_HALIGN_LEFT
                ),
                MultiContentEntryText(
                    pos=(self.time_x + 6, single_line_y),
                    size=(self.time_width - 10, self.row_font_size + 6),
                    font=0,
                    text=self._picker_text(timestamp),
                    flags=RT_HALIGN_LEFT
                ),
                MultiContentEntryText(
                    pos=(self.subtitle_x + 6, vertical_padding),
                    size=(self.subtitle_width - 12,
                          self.row_height - (vertical_padding * 2)),
                    font=0,
                    text=self._picker_text(display_text),
                    flags=RT_HALIGN_LEFT
                ),
            ]
            menu_items.append(row)

        self["subList"].l.setItemHeight(self.row_height)
        self["subList"].l.setList(menu_items)
        self["subList"].l.invalidate()

    def _limit_display_lines(self, text, max_lines=2):
        text = self._picker_unicode(text)
        lines = [line.strip() for line in text.replace(
            u"\r", u"").split(u"\n") if line.strip()]
        if not lines:
            return u""
        if len(lines) <= max_lines:
            return u"\n".join(lines)
        visible = lines[:max_lines]
        visible[-1] = visible[-1] + u" ..."
        return u"\n".join(visible)

    def clean_display_text(self, text):
        text = self._picker_unicode(text)
        control_chars = (
            u"\u202B", u"\u202C", u"\u202A", u"\u202D", u"\u202E", u"\u200F", u"\u200E"
        )
        for char in control_chars:
            text = text.replace(char, u"")
        return text.strip()

    def setInitialSelection(self):
        if not self.subsList:
            return
        index = min(max(self.currentIndex, 0), len(self.subsList) - 1)
        self["subList"].moveToIndex(index)

    def format_time(self, seconds):
        try:
            seconds = float(seconds)
        except Exception:
            seconds = 0.0
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        millisecs = int(round((seconds - int(seconds)) * 1000))
        if millisecs >= 1000:
            secs += 1
            millisecs = 0
        return "%02d:%02d:%02d,%03d" % (hours, minutes, secs, millisecs)


class DVBExternalStyleProScreen(Screen, ConfigListScreen, HelpableScreen):
    def __init__(self, session, externalSettings, apply_cb):
        try:
            if is4K():
                skin_id = "DVBExternalStyleProScreen_4k"
            elif is2K():
                skin_id = "DVBExternalStyleProScreen_2k"
            elif isFullHD():
                skin_id = "DVBExternalStyleProScreen_fhd"
            else:
                skin_id = "DVBExternalStyleProScreen_hd"
        except Exception:
            skin_id = "DVBExternalStyleProScreen_hd"

        self.skin = load_subskin(skin_id)
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        self.externalSettings = externalSettings
        self.apply_cb = apply_cb

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["key_yellow"] = StaticText(_("Apply now"))

        ConfigListScreen.__init__(self, [], session=session)

        self["actions"] = HelpableActionMap(self, "OkCancelActions", {
            "cancel": (self.keyCancel, _("cancel")),
            "ok": (self.keyOk, _("ok")),
        }, -1)

        self["coloractions"] = HelpableActionMap(self, "ColorActions", {
            "red": (self.keyCancel, _("cancel")),
            "green": (self.keySave, _("save")),
            "yellow": (self.keyApply, _("apply now")),
        }, -1)

        self.onLayoutFinish.append(self.buildMenu)

    def buildMenu(self):
        from .subtitles import SubsProSetupExternal
        from Components.config import getConfigListEntry

        configList = SubsProSetupExternal.getConfigList(self.externalSettings)

        # Add the Auto-Speech Toggle
        configList.append(getConfigListEntry(
            _("Auto Text-to-Speech"), config.plugins.subsSupportPro.ttsEnabled))

        # Only show the Language selector if Auto-Speech is ON
        if config.plugins.subsSupportPro.ttsEnabled.value:
            configList.append(getConfigListEntry(
                _("Text-to-Speech audio language"), config.plugins.subsSupportPro.ttsLanguage))

        self["config"].setList(configList)

    def _apply_live(self):
        if callable(self.apply_cb):
            self.apply_cb()

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        cur = self["config"].getCurrent()
        if cur and cur[1] in (
            self.externalSettings.shadow.enabled,
            self.externalSettings.shadow.type,
            self.externalSettings.background.enabled,
            self.externalSettings.background.type,
            self.externalSettings.translate.mode,
            # <--- Triggers menu rebuild on Left/Right
            config.plugins.subsSupportPro.ttsEnabled,
        ):
            self.buildMenu()
        self._apply_live()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        cur = self["config"].getCurrent()
        if cur and cur[1] in (
            self.externalSettings.shadow.enabled,
            self.externalSettings.shadow.type,
            self.externalSettings.background.enabled,
            self.externalSettings.background.type,
            self.externalSettings.translate.mode,
            # <--- Triggers menu rebuild on Left/Right
            config.plugins.subsSupportPro.ttsEnabled,
        ):
            self.buildMenu()
        self._apply_live()

    def keyOk(self):
        try:
            ConfigListScreen.keyOK(self)
        except Exception:
            pass
        self._apply_live()

    def keyApply(self):
        self._apply_live()

    def keySave(self):
        for x in self["config"].list:
            x[1].save()
        configfile.save()
        self._apply_live()
        self.close(True)

    def keyCancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close(False)


class SubsProHelpScreen(Screen):
    def __init__(self, session, help_text):
        try:
            if is4K():
                skin_id = "SubsProHelpScreen_4k"
            elif is2K():
                skin_id = "SubsProHelpScreen_2k"
            elif isFullHD():
                skin_id = "SubsProHelpScreen_fhd"
            else:
                skin_id = "SubsProHelpScreen_hd"
            self.skin = load_subskin(skin_id)
        except Exception:
            pass

        Screen.__init__(self, session)
        self.setTitle(_("SubsSupportPro Controls Help"))
        self["text"] = ScrollLabel(help_text)
        self["key_red"] = Label(_("Close"))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.close,
            "cancel": self.close,
            "red": self.close,
            "up": self.pageUp,
            "down": self.pageDown,
            "left": self.pageUp,
            "right": self.pageDown,
            "pageUp": self.pageUp,
            "pageDown": self.pageDown
        }, -1)

    def pageUp(self):
        self["text"].pageUp()

    def pageDown(self):
        self["text"].pageDown()


class SubsShiftOSD(Screen):
    skin = """
        <screen position="40,40" size="350,60" flags="wfNoBorder" zPosition="10" backgroundColor="#40000000">
            <widget name="message" position="10,0" size="330,60" font="Regular;26" halign="left" valign="center" foregroundColor="#ffffff" backgroundColor="#40000000" transparent="1" />
        </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self["message"] = Label("")


class SubsProControllerDVB(Screen, HelpableScreen):
    fpsChoices = ["23.976", "23.980", "24.000", "25.000", "29.970", "30.000"]

    def __init__(self, session, engine, autoSync=False, setSubtitlesFps=False, subtitlesFps=None, externalSettings=None):
        try:
            if is4K():
                skin_id = "SubsProControllerDVB_4k"
            elif is2K():
                skin_id = "SubsProControllerDVB_2k"
            elif isFullHD():
                skin_id = "SubsProControllerDVB_fhd"
            else:
                skin_id = "SubsProControllerDVB_hd"
        except Exception:
            skin_id = "SubsProControllerDVB_hd"

        self.skin = load_subskin(skin_id)
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)

        self.engine = engine
        self.engine.onRenderSub.append(self.onRenderSub)
        self.engine.onHideSub.append(self.onHideSub)
        self.engine.onPositionUpdate.append(self.onUpdateSubPosition)

        subtitlesFps = subtitlesFps and fps_float(subtitlesFps)
        if subtitlesFps and str(subtitlesFps) in self.fpsChoices:
            self.providedSubtitlesFps = subtitlesFps
        else:
            self.providedSubtitlesFps = None

        self.externalSettings = externalSettings

        self.shiftOSD = self.session.instantiateDialog(SubsShiftOSD)
        self.shiftOSD.hide()
        self.shiftTimer = eTimer()
        self.shiftTimer_conn = eConnectCallback(
            self.shiftTimer.timeout, self.hideShiftOSD)
        self._burst_shift = 0
        self.onClose.append(self.cleanupShiftOSD)

        self.hideTimer = eTimer()
        self.hideTimer_conn = eConnectCallback(
            self.hideTimer.timeout, self.hideStatus)
        self.hideTimerDelay = 5000

        self.eventTimer = eTimer()
        self.eventTimer_conn = eConnectCallback(
            self.eventTimer.timeout, self.updateEventStatus)

        self.subtitlesTimer = eTimer()
        self.subtitlesTimer_conn = eConnectCallback(
            self.subtitlesTimer.timeout, self.updateSubtitlesTime)
        self.subtitlesTimerStep = 500
        self._baseTime = 0
        self._accTime = 0
        self.statusLocked = False

        self["instruction"] = Label(
            _("Press RED to open subtitle picker - Press OK to hide/unhide - Press MENU to open Subtitle display - Press INFO to open help screen"))
        self['subtitle'] = Label()
        self['subtitlesPosition'] = Label(_("Subtitles Position") + ":")
        self['subtitlesTime'] = Label(_("Subtitles Time") + ":")
        self['subtitlesFps'] = Label(_("Subtitles FPS") + ":")
        self["eventName"] = Label(_("Event Name") + ":")
        self["eventTime"] = Label(_("Event Time") + ":")
        self["eventDuration"] = Label(_("Event Duration") + ":")

        self["actions"] = HelpableActionMap(self, "SubtitlesDVBActions", {
            # "closePlugin": (self.close, _("close plugin")),
            "showHideStatus": (self.showHideStatus, _("show/hide subtitles status")),
            "playPauseSub": (self.playPause, _("play/pause subtitles playback")),
            "pauseSub": (self.pause, _("pause subtitles playback")),
            "resumeSub": (self.resume, _("resumes subtitles playback")),
            "restartSub": (self.restart, _("restarts current subtitle")),
            "nextSub": (self.nextSkip, _("skip to next subtitle")),
            "nextSubMinute": (self.nextMinuteSkip, _("skip to next subtitle (minute jump)")),
            "nextSubManual": (self.nextManual, _("skip to next subtitle by setting time in minutes")),
            "prevSub": (self.previousSkip, _("skip to previous subtitle")),
            "prevSubMinute": (self.previousMinuteSkip, _("skip to previous subtitle (minute jump)")),
            "prevSubManual": (self.previousManual, _("skip previous subtitle by setting time in minutes")),
            "eventSync": (self.eventSync, _("skip subtitle to current event position")),
            "changeFps": (self.changeFps, _("change subtitles fps")),
            "openSubtitleProPicker": (self.openSubtitleProPicker, _("open Subtitle Picker")),
            "applySavedDelay": (self.applySavedDelay, _("apply Saved Delay")),
            "saveCurrentDelay": (self.saveCurrentDelay, _("save current delay for this channel")),
            "delayPlus": (self.delayPlus, _("delay subtitles +1s")),
            "delayMinus": (self.delayMinus, _("advance subtitles -1s")),
            # <--- ADD THIS
            "openShiftSelector": (self.openShiftSelector, _("open shift selector list")),
            "speakCurrentSub": (self.speakCurrentSub, _("speak current subtitle line")),
            "showHelp": (self.showHelp, _("show help")),
            "confirmClose": (self.confirmClose, _("exit (confirm)")),
            "externalStyle": (self.externalStyle, _("External style")),
        }, -1)

        try:
            from Screens.InfoBar import InfoBar
            InfoBar.instance.subtitle_window.hide()
        except Exception:
            pass

        self.onLayoutFinish.append(self.hideStatus)
        self.onLayoutFinish.append(self.engine.start)
        self.onLayoutFinish.append(self.startEventTimer)
        self.onLayoutFinish.append(self.startSubtitlesTimer)
        self.onLayoutFinish.append(self.showStatusWithTimer)
        if setSubtitlesFps and self.providedSubtitlesFps:
            self.onFirstExecBegin.append(self.setProvidedSubtitlesFps)

        self.autoSyncEnabled = autoSync
        self.onFirstExecBegin.append(self.autoApplySavedDelay)

        self.onClose.append(self.engine.close)
        self.onClose.append(self.delTimers)

    def hideShiftOSD(self):
        self.shiftTimer.stop()
        self.shiftOSD.hide()
        self._burst_shift = 0

    def cleanupShiftOSD(self):
        if hasattr(self, 'shiftOSD') and self.shiftOSD:
            self.session.deleteDialog(self.shiftOSD)
            self.shiftOSD = None

    def applyExternalStyleNow(self):
        r = self.engine.renderer
        try:
            r.hideSubtitle()
        except Exception:
            pass
        if hasattr(r, "reloadSettings"):
            r.reloadSettings()
        self.engine.renderSub()

    def externalStyle(self):
        if self.externalSettings is None:
            self.session.openMessageBox(
                _("External settings not provided!"), MessageBox.TYPEERROR, timeout=3)
            return
        self.session.open(DVBExternalStyleProScreen,
                          self.externalSettings, self.applyExternalStyleNow)

    def confirmClose(self):
        def cb(answer):
            if answer:
                self.close()
        self.session.openWithCallback(cb, MessageBox, _(
            "Exit SubsSupportPro DVB player?"), MessageBox.TYPE_YESNO)

    def showHelp(self):
        txt = "\n".join([
            _("Controls:"),
            "",
            _("RED: Open Subtitle Picker"),
            _("YELLOW: Sync subtitle to current event"),
            _("BLUE: Change subtitles FPS"),
            _("OK: Show/Hide status panel"),
            _("LEFT: Previous subtitle"),
            _("RIGHT: Next subtitle"),
            _("UP/DOWN: Restart current subtitle"),
            _("PREV/REWIND (short): -1 minute"),
            _("NEXT/FF (short): +1 minute"),
            _("PREV (long): Manual -minutes jump"),
            _("NEXT (long): Manual +minutes jump"),
            _("1: delay minus (-1s)"),
            _("2: Open shift selector list"),
            _("3: delay plus (+1s)"),
            _("5: Apply saved delay"),
            _("6: Save current delay for this channel"),
            _("7: Speak current subtitle line"),
            _("EXIT: Exit (confirm)"),
            _("MENU: Show subtitle Style Settings"),
            _("INFO: Show this help"),
        ])
        self.session.open(SubsProHelpScreen, txt)

    def openSubtitleProPicker(self):
        try:
            subtitleList = self.engine.getSubtitlesList()
            currentIndex = self.engine.getPosition()
            if not subtitleList:
                return
            self.session.openWithCallback(
                self.onSubtitlePicked, SubtitleProPicker, subtitleList, currentIndex)
        except Exception as e:
            print('[SubsSupportPro] Error opening picker:', e)

    def startEventTimer(self):
        self.eventTimer.start(500)

    def startSubtitlesTimer(self):
        self.subtitlesTimer.start(self.subtitlesTimerStep)

    def setProvidedSubtitlesFps(self):
        self.engine.setSubsFps(self.providedSubtitlesFps)
        self.updateSubtitlesFps()

    def onUpdateSubPosition(self, position):
        self.updateSubtitlesPosition(position)

    def onRenderSub(self, sub):
        if self['subtitle'].visible:
            self.updateSubtitle(sub, True)
        if self['subtitlesTime'].visible:
            self.updateSubtitlesTime(sub)

        # Automatically trigger speech if the feature is enabled
        if config.plugins.subsSupportPro.ttsEnabled.value:
            self.speakSub(sub)

    def speakCurrentSub(self):
        """Manual trigger for the currently active subtitle line."""
        self.speakSub(self.engine.getCurrentSub())

    def speakSub(self, sub):
        """Core TTS execution method handling both manual and auto requests."""
        if not sub:
            return

        if 'rows' in sub:
            text = " ".join([row.get('text', '') for row in sub['rows']])
        else:
            text = sub.get('text', '')

        text = text.replace('\n', ' ').strip()
        if not text:
            return

        # Convert DVB ticks (90k/sec) to exact floating-point seconds
        target_duration = (float(sub.get("end", 0)) -
                           float(sub.get("start", 0))) / 90000.0

        try:
            from urllib.parse import quote
        except ImportError:
            from urllib import quote

        try:
            safe_text = quote(text.encode('utf-8'))
        except Exception:
            safe_text = quote(str(text))

        tts_lang = config.plugins.subsSupportPro.ttsLanguage.value
        url = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=%s&q=%s" % (
            tts_lang, safe_text)

        if not hasattr(self, "live_tts_container"):
            self.live_tts_container = eConsoleAppContainer()

        _play_tts_async(text, url, target_duration,
                        self.live_tts_container, "/tmp/subs_live_tts.mp3")

    def onHideSub(self, sub):
        if sub == self.engine.subsList[-1]:
            self.subtitlesTimer.stop()
        if self['subtitle'].visible:
            nextSubIdx = self.engine.subsList.index(sub) + 1
            if nextSubIdx >= len(self.engine.subsList) - 1:
                nextSub = None
            else:
                nextSub = self.engine.subsList[nextSubIdx]
            self.updateSubtitle(nextSub, active=False)

    def showStatusWithTimer(self):
        self.showStatus(True)

    def showStatus(self, withTimer=False):
        sub = self.engine.getCurrentSub()
        active = self.engine.renderer.subShown
        self.updateSubtitle(sub, active)
        self.updateSubtitlesFps()
        self.updateSubtitlesPosition()
        self.updateEventStatus()
        self['instruction'].visible = True
        self['subtitle'].visible = True
        self['subtitlesPosition'].visible = True
        self['subtitlesTime'].visible = True
        self['subtitlesFps'].visible = True
        self['eventName'].visible = True
        self['eventTime'].visible = True
        self['eventDuration'].visible = True
        if withTimer and not self.statusLocked:
            self.hideTimer.start(self.hideTimerDelay, True)

    def hideStatus(self):
        self['instruction'].visible = False
        self['subtitle'].visible = False
        self['subtitlesPosition'].visible = False
        self['subtitlesTime'].visible = False
        self['subtitlesFps'].visible = False
        self['eventName'].visible = False
        self['eventTime'].visible = False
        self['eventDuration'].visible = False

    def updateSubtitle(self, sub, active):
        if sub is None:
            self['subtitle'].setText("")
            return
        st = sub['start'] * self.engine.fpsRatio / 90000
        et = sub['end'] * self.engine.fpsRatio / 90000
        stStr = "%d:%02d:%02d" % (st / 3600, (st % 3600) / 60, st % 60)
        etStr = "%d:%02d:%02d" % (et / 3600, (et % 3600) / 60, et % 60)
        if active:
            self['subtitle'].instance.setForegroundColor(parseColor("#F7A900"))
        else:
            self['subtitle'].instance.setForegroundColor(parseColor("#aaaaaa"))
        self['subtitle'].setText("%s ----> %s" % (stStr, etStr))

    def updateSubtitlesPosition(self, position=None):
        if position is None:
            position = self.engine.subsList.index(self.engine.getCurrentSub())
        self['subtitlesPosition'].setText(
            "%s: %d / %d" % (_("Subtitles Position"), position, len(self.engine.subsList) - 1))

    def updateSubtitlesTime(self, sub=None):
        if not self.engine.subsList:
            return

        video_time = self.engine.getVideoTime()
        effective_time = video_time - self.engine.sync_offset_ms
        st = max(0, effective_time / 1000.0)

        time_str = "%02d:%02d:%02d" % (st / 3600, (st % 3600) / 60, st % 60)
        self['subtitlesTime'].setText(
            "%s: %s" % (_("Subtitles Time"), time_str))

        if not self.engine.paused:
            self.subtitlesTimer.start(self.subtitlesTimerStep, True)

    def updateSubtitlesFps(self):
        subsFps = self.engine.getSubsFps()
        videoFps = getFps(self.session, True)
        if subsFps is None or videoFps is None:
            self['subtitlesFps'].setText(
                "%s: %s" % (_("Subtitles FPS"), _("unknown")))
            return
        if subsFps == videoFps:
            if self.providedSubtitlesFps is not None and self.providedSubtitlesFps != videoFps:
                self['subtitlesFps'].setText("%s: %s (%s)" % (
                    _("Subtitles FPS"), _("original"), str(self.providedSubtitlesFps)))
            else:
                self['subtitlesFps'].setText(
                    "%s: %s" % (_("Subtitles FPS"), _("original")))
        else:
            if self.providedSubtitlesFps is not None:
                self['subtitlesFps'].setText("%s: %s (%s)" % (
                    _("Subtitles FPS"), str(subsFps), str(self.providedSubtitlesFps)))
            else:
                self['subtitlesFps'].setText(
                    "%s: %s" % (_("Subtitles FPS"), str(subsFps)))

    def updateEventStatus(self):
        event = self.session.screen["Event_Now"].getEvent()
        if event is not None:
            eventName = event.getEventName()
            if eventName:
                if self["eventName"].getText() != eventName:
                    self["eventName"].setText("%s" % eventName)
            else:
                self["eventName"].setText("%s" % (_("unknown")))
            eventStartTime = event.getBeginTime()
            if eventStartTime:
                ep = int(time.time()) - eventStartTime
                self["eventTime"].setText("%s: %d:%02d:%02d" % (
                    _("Time"), ep / 3600, (ep % 3600) / 60, ep % 60))
            else:
                self["eventTime"].setText(
                    "%s: %s" % (_("Event Time"), "0:00:00"))
            eventDuration = event.getDuration()
            if eventDuration:
                if eventStartTime:
                    eventProgress = int(time.time()) - eventStartTime
                    ed = 0 if eventProgress > eventDuration else eventDuration
                else:
                    ed = eventDuration
                self["eventDuration"].setText("%s: %d:%02d:%02d" % (
                    _("Duration"), ed / 3600, (ed % 3600) / 60, ed % 60))
            else:
                self["eventDuration"].setText(
                    "%s: %s" % (_("Event Duration"), "0:00:00"))
        else:
            self["eventName"].setText("")
            self["eventTime"].setText("")
            self["eventDuration"].setText("")

    def changeFps(self):
        subsFps = self.engine.getSubsFps()
        if subsFps is None:
            return
        currIdx = self.fpsChoices.index(str(subsFps))
        nextIdx = 0 if currIdx == len(self.fpsChoices) - 1 else currIdx + 1
        self.engine.setSubsFps(fps_float(self.fpsChoices[nextIdx]))
        self.updateSubtitlesFps()
        sub = self.engine.getCurrentSub()
        self.updateSubtitle(sub, self.engine.renderer.subShown)
        self.updateSubtitlesPosition()
        self.showStatus(True)

    def showHideStatus(self):
        if self['subtitle'].visible:
            self.statusLocked = False
            self.hideStatus()
        else:
            self.statusLocked = True
            self.showStatus()

    def playPause(self):
        if self.engine.isPaused():
            self.resume()
        else:
            self.pause()

    def pause(self):
        self.engine.pause()
        self.subtitlesTimer.stop()
        self.showStatus()

    def resume(self):
        self.engine.resume()
        self.startSubtitlesTimer()
        self.showStatus(True)

    def restart(self):
        self.engine.pause()
        self.engine.resume()
        self.showStatus(True)

    def nextSkip(self):
        self.engine.toNextSub()
        self.showStatus(True)

    def nextMinuteSkip(self):
        self.engine.seekRelative(60 * 1000)
        self.showStatus(True)

    def nextManual(self):
        from .e2_utils import MinuteInput

        def nextManualCB(minutes):
            if minutes > 0:
                self.engine.seekRelative(minutes * 60 * 1000)
                self.showStatus(True)
        self.session.openWithCallback(nextManualCB, MinuteInput)

    def previousSkip(self):
        self.engine.toPrevSub()
        self.showStatus(True)

    def previousMinuteSkip(self):
        self.engine.seekRelative(-60 * 1000)
        self.showStatus(True)

    def previousManual(self):
        from .e2_utils import MinuteInput

        def previousManualCB(minutes):
            if minutes > 0:
                self.engine.seekRelative(-minutes * 60 * 1000)
                self.showStatus(True)
        self.session.openWithCallback(previousManualCB, MinuteInput)

    def openShiftSelector(self):
        from Screens.ChoiceBox import ChoiceBox
        choices = []
        for sec in range(-120, 121):
            text = "0.0 s" if sec == 0 else (
                "+%d.0 s" % sec if sec > 0 else "%d.0 s" % sec)
            choices.append((text, sec * 1000))
        self.session.openWithCallback(self.shiftSelectorCB, ChoiceBox, title=_(
            "Select Sync Shift"), list=choices, selection=120)

    def shiftSelectorCB(self, choice):
        if choice and choice[1] != 0:
            self._update_osd(choice[1])

    def delayPlus(self):
        self._update_osd(1000)

    def delayMinus(self):
        self._update_osd(-1000)

    def _update_osd(self, ms_offset):
        self._burst_shift += ms_offset
        self.engine.shiftSync(ms_offset)

        sign = "+" if self._burst_shift > 0 else ""
        self.shiftOSD["message"].setText(
            _("Shifted: %s%.1f s") % (sign, self._burst_shift / 1000.0))
        self.shiftOSD.show()

        self.shiftTimer.start(3000, True)
        self.showStatus(True)

    def onSubtitlePicked(self, index=None):
        if index is not None:
            self.engine.syncToSubtitleIndex(index)
            self.showStatus(True)

    def eventSync(self):
        event = self.session.screen["Event_Now"].getEvent()
        if event is not None:
            self.engine.sync_offset_ms = 0
            self.engine.seekTo(self.engine.getVideoTime())
        else:
            self.session.open(MessageBox, _(
                "Cannot sync to event, event is not available"), MessageBox.TYPE_INFO, simple=True, timeout=3)

    def _applySyncShift(self, ms_offset):
        self._burst_shift += ms_offset
        self.updateSubtitlesTime()
        current_time = self._subtitlesTime

        self.engine.shiftTimestamps(ms_offset)
        self.engine.seekTo(current_time)

        sign = "+" if self._burst_shift > 0 else ""
        self.shiftOSD["message"].setText(
            _("Shifted: %s%.1f s") % (sign, self._burst_shift / 1000.0))
        self.shiftOSD.show()

        self.shiftTimer.start(3000, True)
        self.showStatus(True)

    def delTimers(self):
        self.hideTimer.stop()
        del self.hideTimer_conn
        del self.hideTimer
        self.eventTimer.stop()
        del self.eventTimer_conn
        del self.eventTimer
        self.subtitlesTimer.stop()
        del self.subtitlesTimer_conn
        del self.subtitlesTimer

    def saveCurrentDelay(self):
        event = self.session.screen["Event_Now"].getEvent()
        if not event:
            self.session.open(MessageBox, _(
                "Cannot save delay - event information unavailable"), MessageBox.TYPE_INFO, simple=True, timeout=2)
            return

        self.engine.saveMainDelayToJson()
        self.session.open(MessageBox, _("Sync Saved!\nOffset: %.1f s") % (
            self.engine.sync_offset_ms / 1000.0), MessageBox.TYPE_INFO, simple=True, timeout=2)

    def autoApplySavedDelay(self):
        event = self.session.screen["Event_Now"].getEvent()
        if not event:
            if self.autoSyncEnabled:
                self.eventSync()
            return

        success, offset = self.engine.applySavedDelay()
        if success:
            self.session.open(MessageBox, _("Saved Sync Auto-Applied!\nOffset: %.1f s") %
                              (offset / 1000.0), MessageBox.TYPE_INFO, simple=True, timeout=2)
            self.showStatus(True)
        elif self.autoSyncEnabled:
            self.eventSync()

    def applySavedDelay(self):
        event = self.session.screen["Event_Now"].getEvent()
        if not event:
            self.session.open(MessageBox, _(
                "Cannot apply delay - event info unavailable"), MessageBox.TYPE_INFO, simple=True, timeout=2)
            return

        success, offset = self.engine.applySavedDelay()
        if success:
            self.session.open(MessageBox, _("Saved Sync Applied!\nOffset: %.1f s") % (
                offset / 1000.0), MessageBox.TYPE_INFO, simple=True, timeout=2)
            self.showStatus(True)
        else:
            self.session.open(MessageBox, _(
                "No saved sync found for this channel"), MessageBox.TYPE_INFO, simple=True, timeout=2)


class SubsEngineDVB(object):
    def __init__(self, session, engineSettings, renderer):
        self.session = session
        self.renderer = renderer
        self.json_path = "/tmp/subsProSupport_delays.json"
        if not os.path.exists(os.path.dirname(self.json_path)):
            os.makedirs(os.path.dirname(self.json_path))

        self.sync_offset_ms = 0
        self.paused_video_time = 0
        self.channel_reference = self.getCurrentChannelReference()

        self.__position = 0
        self.fpsRatio = 1
        self.subsList = None
        self.paused = True

        self.waitTimer = eTimer()
        self.waitTimer_conn = eConnectCallback(
            self.waitTimer.timeout, self.doWait)
        self.hideTimer = eTimer()
        self.hideTimer_conn = eConnectCallback(
            self.hideTimer.timeout, self.hideTimerCallback)

        self.onRenderSub = []
        self.onHideSub = []
        self.onPositionUpdate = []

    def getSubtitlesList(self):
        result = []
        for idx, sub in enumerate(self.subsList):
            if 'rows' in sub:
                text = u'\n'.join([toUnicode(row.get('text', ''))
                                  for row in sub['rows']])
            else:
                text = toUnicode(sub.get('text', ''))

            result.append({
                "index": idx,
                "text": text,
                "start": sub["start"] / 90000,
                "end": sub["end"] / 90000,
            })
        return result

    def setSubsList(self, subsList):
        self.subsList = subsList

    def setSubsFps(self, subsFps):
        videoFps = getFps(self.session, True)
        if videoFps is not None:
            self.waitTimer.stop()
            self.hideTimer.stop()
            base = subsFps / float(videoFps)
            override = self.getFpsDriftOverride()
            self.fpsRatio = base * override

            if not self.paused:
                self.seekTo(self.getVideoTime())

    def setPosition(self, position):
        if position > len(self.subsList) - 1:
            return
        self.__position = position
        for f in self.onPositionUpdate:
            f(self.__position)

    def getPosition(self):
        return self.__position

    position = property(getPosition, setPosition)

    def getSubsFps(self):
        videoFps = getFps(self.session, True)
        if videoFps is None:
            return None
        return fps_float(self.fpsRatio * videoFps)

    def getCurrentSub(self):
        if self.subsList and 0 <= self.position < len(self.subsList):
            return self.subsList[self.position]
        return None

    def _safeRatio(self, cfg, default=1.0):
        try:
            s = str(cfg.value).strip().replace(",", ".")
            v = float(s)
            if v < 0.80 or v > 1.20:
                return default
            return v
        except Exception:
            return default

    def getFpsDriftOverride(self):
        if not config.plugins.subsSupportPro.dvb.fpsDriftEnable.value:
            return 1.0

        videoFps = getFps(self.session, True)
        if videoFps is None:
            return 1.0

        vf = "%.3f" % float(videoFps)
        m = {
            "23.976": config.plugins.subsSupportPro.dvb.fpsRatio_23_976,
            "24.000": config.plugins.subsSupportPro.dvb.fpsRatio_24_000,
            "25.000": config.plugins.subsSupportPro.dvb.fpsRatio_25_000,
            "29.970": config.plugins.subsSupportPro.dvb.fpsRatio_29_970,
            "30.000": config.plugins.subsSupportPro.dvb.fpsRatio_30_000,
            "50.000": config.plugins.subsSupportPro.dvb.fpsRatio_50_000,
            "59.940": config.plugins.subsSupportPro.dvb.fpsRatio_59_940,
        }
        cfg = m.get(vf)
        return self._safeRatio(cfg, 1.0) if cfg else 1.0

    # --- TIME & UNIFIED OFFSET LOGIC ---
    def getVideoTime(self):
        import time
        # Primary: True DVB Broadcast Time
        try:
            event = self.session.screen["Event_Now"].getEvent()
            if event and event.getBeginTime():
                return (time.time() - event.getBeginTime()) * 1000
        except Exception:
            pass

        # Fallback: Internal Engine Time
        if self.paused:
            return self.paused_video_time

        elapsed = (time.time() * 1000) - \
            getattr(self, 'reftime', time.time() * 1000)
        ref_sub_time = (self.subsList[getattr(
            self, 'refposition', 0)]['start'] / 90 * self.fpsRatio) + self.sync_offset_ms
        return ref_sub_time + elapsed

    def shiftSync(self, ms_offset):
        """Unified method for all + / - adjustments."""
        self.sync_offset_ms += ms_offset
        self.seekTo(self.getVideoTime())

    def syncToSubtitleIndex(self, index):
        """Anchors the selected subtitle perfectly to the current video time."""
        if not self.subsList or index < 0 or index >= len(self.subsList):
            return

        video_time_ms = self.getVideoTime()
        sub_time_ms = self.subsList[index]['start'] / 90 * self.fpsRatio

        self.sync_offset_ms = video_time_ms - sub_time_ms
        self.seekTo(video_time_ms)

    def seekTo(self, video_time_ms):
        self.waitTimer.stop()
        self.hideTimer.stop()

        if not self.subsList:
            return

        effective_time = video_time_ms - self.sync_offset_ms
        firstSub = self.subsList[0]
        lastSub = self.subsList[-1]

        if effective_time > lastSub['end'] / 90 * self.fpsRatio:
            self.position = len(self.subsList) - 1
        elif effective_time < firstSub['start'] / 90 * self.fpsRatio:
            self.position = 0
        else:
            for i, sub in enumerate(self.subsList):
                if effective_time <= sub['end'] / 90 * self.fpsRatio:
                    self.position = i
                    break

        sub_start = self.subsList[self.position]['start'] / 90 * self.fpsRatio
        sub_end = self.subsList[self.position]['end'] / 90 * self.fpsRatio

        import time
        self.reftime = time.time() * 1000
        self.refposition = self.position

        if effective_time >= sub_start and effective_time <= sub_end:
            # Inside a subtitle line
            self.renderSub()
            if not self.paused:
                remaining = sub_end - effective_time
                self.hideTimer.start(int(remaining), True)
        else:
            # In a gap before a subtitle line
            self.hideSub()
            if not self.paused:
                diff = sub_start - effective_time
                self.waitTimer.start(int(diff), True)

    def seekRelative(self, time_val):
        self.shiftSync(time_val)

    def toNextSub(self):
        if self.position < len(self.subsList) - 1:
            self.syncToSubtitleIndex(self.position + 1)

    def toPrevSub(self):
        if self.position > 0:
            self.syncToSubtitleIndex(self.position - 1)

    def hideTimerCallback(self):
        self.hideTimer.stop()
        self.hideSub()

        if self.position >= len(self.subsList) - 1:
            return

        self.position += 1

        import time
        self.reftime = time.time() * 1000
        self.refposition = self.position

        video_time = self.getVideoTime()
        sub_start_effective = (
            self.subsList[self.position]['start'] / 90 * self.fpsRatio) + self.sync_offset_ms
        diff = sub_start_effective - video_time

        if diff > 50:
            self.waitTimer.start(int(diff), True)
        else:
            self.renderSub()
            dur = (self.subsList[self.position]['end'] -
                   self.subsList[self.position]['start']) / 90 * self.fpsRatio
            self.hideTimer.start(int(dur), True)

    def doWait(self):
        self.waitTimer.stop()
        self.renderSub()
        dur = (self.subsList[self.position]['end'] -
               self.subsList[self.position]['start']) / 90 * self.fpsRatio
        self.hideTimer.start(int(dur), True)

    def renderSub(self):
        for f in self.onRenderSub:
            f(self.subsList[self.position])

        if 'rows' in self.subsList[self.position]:
            combined_text = '\n'.join(
                [row['text'] for row in self.subsList[self.position]['rows']])
            temp_sub = self.subsList[self.position].copy()
            temp_sub['text'] = combined_text
            self.renderer.setSubtitle(temp_sub)
        else:
            self.renderer.setSubtitle(self.subsList[self.position])

    def hideSub(self):
        for f in self.onHideSub:
            f(self.subsList[self.position])
        self.renderer.hideSubtitle()

    def start(self):
        self.renderer.show()
        self.resume()

    def pause(self):
        if not self.paused:
            self.paused_video_time = self.getVideoTime()
            self.paused = True
            self.waitTimer.stop()
            self.hideTimer.stop()

    def resume(self):
        if self.paused:
            self.paused = False
            self.seekTo(self.paused_video_time)

    # --- PERFECT SAVE & RESTORE ---
    def getCurrentChannelReference(self):
        try:
            service = self.session.nav.getCurrentlyPlayingServiceReference()
            if service:
                return service.toString()
        except Exception:
            pass
        return "unknown_channel"

    def getSyncKey(self):
        """Bind sync offsets perfectly to the Channel AND Movie Title."""
        ref = self.getCurrentChannelReference()
        event_name = "unknown_event"
        try:
            event = self.session.screen["Event_Now"].getEvent()
            if event:
                import re
                event_name = re.sub(r'\W+', '_', event.getEventName().strip())
        except Exception:
            pass
        return "%s___%s" % (ref, event_name)

    def _loadDelayFile(self):
        if os.path.exists(self.json_path):
            try:
                with open(self.json_path, "r") as fh:
                    return json.load(fh)
            except Exception:
                pass
        return {}

    def _saveDelayFile(self, data):
        try:
            with open(self.json_path, "w") as fh:
                json.dump(data, fh, indent=4)
        except Exception:
            pass

    def saveMainDelayToJson(self, subs_fps=None):
        if subs_fps is None:
            subs_fps = self.getSubsFps() or 0

        data = self._loadDelayFile()
        sync_key = self.getSyncKey()

        data[sync_key] = {
            "offset_ms": self.sync_offset_ms,
            "fps": str(subs_fps),
            "saved_at": time.time()
        }
        self._saveDelayFile(data)

    def applySavedDelay(self):
        data = self._loadDelayFile()
        sync_key = self.getSyncKey()

        # Priority: Exact Event Match. Fallback: Generic Channel ID.
        record = data.get(sync_key) or data.get(self.channel_reference)

        if not record:
            return False, 0

        self.sync_offset_ms = record.get("offset_ms", record.get(
            "delay_ms", record.get("delay", 0) * 1000))

        saved_fps = record.get("fps")
        if saved_fps and float(saved_fps) > 0:
            self.setSubsFps(float(saved_fps))

        self.seekTo(self.getVideoTime())
        return True, self.sync_offset_ms

    def close(self):
        self.waitTimer.stop()
        del self.waitTimer_conn
        self.hideTimer.stop()
        del self.hideTimer_conn
