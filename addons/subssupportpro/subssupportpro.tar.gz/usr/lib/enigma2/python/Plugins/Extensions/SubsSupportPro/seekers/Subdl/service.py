# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import print_function
import requests
import os
import re
import six  # type: ignore
from six.moves.urllib.parse import quote_plus, urlsplit, urlunsplit  # type: ignore
from ..user_agents import get_api_user_agent, get_random_ua
from ..seeker import SubtitlesDownloadError, SubtitlesErrors

SEARCH_URL = "https://api.subdl.com/api/v1/subtitles"
DOWNLOAD_URL = "https://dl.subdl.com"
API_TIMEOUT = 10
DOWNLOAD_TIMEOUT = 30

# Comprehensive mapping for all 111 SubDL supported languages
# Languages supported both by SubDL and SubsSupportPro's flag assets
SUBDL_LANGUAGES = {
    "ar": "Arabic",
    "bg": "Bulgarian",
    "bs": "Bosnian",
    "ca": "Catalan",
    "cs": "Czech",
    "da": "Danish",
    "de": "German",
    "el": "Greek",
    "en": "English",
    "es": "Spanish",
    "et": "Estonian",
    "fa": "Persian",
    "fi": "Finnish",
    "fr": "French",
    "fy": "Western Frisian",
    "he": "Hebrew",
    "hi": "Hindi",
    "hr": "Croatian",
    "hu": "Hungarian",
    "id": "Indonesian",
    "is": "Icelandic",
    "it": "Italian",
    "ku": "Kurdish",
    "lt": "Lithuanian",
    "lv": "Latvian",
    "ne": "Nepali",
    "nl": "Dutch",
    "no": "Norwegian",
    "pl": "Polish",
    "pt": "Portuguese",
    "pt-br": "Brazilian Portuguese",
    "ro": "Romanian",
    "ru": "Russian",
    "sk": "Slovak",
    "sl": "Slovenian",
    "sr": "Serbian",
    "sv": "Swedish",
    "th": "Thai",
    "tr": "Turkish",
    "uk": "Ukrainian",
    "vi": "Vietnamese",
    "zh": "Chinese",
}

LANGUAGE_ALIASES = {
    "cz": "cs",
    "ua": "uk",
    "pt_br": "pt-br",
    "pt_pt": "pt",
    "pb": "pt-br",
    "brazilian": "pt-br",
    "nb": "no",
    "nb_no": "no",
    "no_no": "no",
    "farsi": "fa",
    "persian": "fa",
    "zh_cn": "zh",
    "zh_hk": "zh",
    "zh-cn": "zh",
    "zh-tw": "zh",
}


def get_language_info(language_query):
    """Resolve language input by name or code for SubDL API."""
    if not language_query:
        return {"name": "English", "2et": "en"}

    clean_query = str(language_query).strip().lower().replace("_", "-")

    # Map aliases (e.g. 'cz' -> 'cs', 'ua' -> 'uk', 'pt_br' -> 'pt-br')
    target_code = LANGUAGE_ALIASES.get(clean_query, clean_query)

    # 1. Match code directly
    if target_code in SUBDL_LANGUAGES:
        return {"name": SUBDL_LANGUAGES[target_code], "2et": target_code}

    # 2. Match full name
    for code, name in SUBDL_LANGUAGES.items():
        if clean_query == name.lower():
            return {"name": name, "2et": code}

    # Fallback to English if the queried language has no asset representation
    return {"name": "English", "2et": "en"}


def build_api_headers():
    """Return headers for SubDL REST API requests."""
    return {
        "User-Agent": get_api_user_agent(),
        "Accept": "application/json",
    }


def build_download_headers(include_api_key=False):
    """Return browser-like headers for SubDL CDN downloads."""
    headers = {
        "User-Agent": get_random_ua(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,application/octet-stream,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://subdl.com/",
        "Connection": "keep-alive",
    }
    if include_api_key:
        api_key = get_subdl_api()
        if api_key:
            headers["x-api-key"] = api_key
    return headers


def _to_text(value):
    """Python 2/3 safe string normalizer."""
    if value is None:
        return ""
    try:
        return six.ensure_text(value, errors="replace")
    except Exception:
        try:
            return str(value)
        except Exception:
            return ""


def _strip_download_archive_extension(url):
    """Return the SubDL download URL without a trailing archive extension."""
    url = _to_text(url).strip()
    if not url:
        return url
    try:
        parts = urlsplit(url)
        path = re.sub(r'\.(?:zip|rar)$', '', parts.path, flags=re.I)
        return urlunsplit((parts.scheme, parts.netloc, path, parts.query, parts.fragment))
    except Exception:
        return re.sub(r'\.(?:zip|rar)(?=([?#]|$))', '', url, flags=re.I)


def build_download_url(subtitle_id):
    """Return a valid SubDL download URL."""
    subtitle_id = _to_text(subtitle_id).strip()
    if subtitle_id.startswith("http://") or subtitle_id.startswith("https://"):
        return subtitle_id
    return DOWNLOAD_URL.rstrip("/") + "/" + subtitle_id.lstrip("/")


def build_download_urls(subtitle_id):
    """Return download URL candidates (extensionless first, followed by original)."""
    original_url = build_download_url(subtitle_id)
    extensionless_url = _strip_download_archive_extension(original_url)
    urls = []
    for candidate in (extensionless_url, original_url):
        if candidate and candidate not in urls:
            urls.append(candidate)
    return urls


def _append_api_key_to_url(url, api_key):
    """Append api_key parameter to download URL."""
    url = _to_text(url).strip()
    api_key = _to_text(api_key).strip()
    if not url or not api_key:
        return url
    separator = "&" if "?" in url else "?"
    return url + separator + "api_key=" + quote_plus(api_key)


def build_download_attempts(subtitle_id):
    """Return prioritized download attempts, forcing API downloads first if available."""
    attempts = []
    api_key = get_subdl_api()

    if api_key:
        # Direct API-authenticated downloads bypass the anonymous CDN limits.
        for url in build_download_urls(subtitle_id):
            attempts.append((_append_api_key_to_url(url, api_key),
                            build_download_headers(False), "api_key-query"))
        for url in build_download_urls(subtitle_id):
            attempts.append(
                (url, build_download_headers(True), "x-api-key-header"))
    else:
        # Fall back to anonymous only if no API key is configured by the user.
        for url in build_download_urls(subtitle_id):
            attempts.append((url, build_download_headers(False), "anonymous"))

    unique = []
    seen = set()
    for url, headers, mode in attempts:
        key = (url, mode)
        if url and key not in seen:
            unique.append((url, headers, mode))
            seen.add(key)
    return unique


def _safe_local_tmp_file(zip_subs, tmp_sub_dir, fallback_name):
    """Keep temp files safely inside tmp_sub_dir without path traversal."""
    name = os.path.basename(_to_text(zip_subs).replace("\\", "/")).strip()
    if not name:
        name = fallback_name
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", name).strip(" ._")
    if not name:
        name = fallback_name
    return os.path.join(tmp_sub_dir, name)


def _raise_download_error(message):
    raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, message)


def get_subdl_api():
    try:
        api_key = settings_provider.getSetting("Subdl_API_KEY")
        if api_key:
            return api_key
    except Exception:
        pass
    print("Error: SubDL API key is missing.")
    return None


def get_subtitles_list_movie(searchstring, title, languageshort, languagelong, subtitles_list):
    """Fetches movie subtitles from the SubDL API."""
    if not searchstring:
        return

    api_key = get_subdl_api()
    if not api_key:
        return

    try:
        params = {
            "api_key": api_key,
            "film_name": searchstring,
            "type": "movie",
            "imdb_id": None,
            "languages": languageshort,
            "subs_per_page": 50
        }

        response = requests.get(SEARCH_URL, params=params,
                                headers=build_api_headers(), timeout=API_TIMEOUT)
        response.raise_for_status()

        json_data = response.json()
        if json_data.get("status", False):
            for item in json_data.get("subtitles", []):
                try:
                    lang = item.get("lang")
                    filename = item.get("release_name")
                    sub_url = item.get("url")
                    if lang and filename and sub_url:
                        subtitles_list.append({
                            'filename': filename,
                            'sync': True,
                            'id': sub_url,
                            'language_flag': languageshort,
                            'language_name': languagelong
                        })
                except Exception as sub_err:
                    print('[SubDL] Error parsing item: {}'.format(sub_err))
    except Exception as err:
        print('[SubDL] Error in get_subtitles_list_movie: {}'.format(err))


def get_subtitles_list_tv(searchstring, tvshow, season, episode, languageshort, languagelong, subtitles_list):
    """Fetches TV episode subtitles from the SubDL API."""
    if not searchstring:
        return

    api_key = get_subdl_api()
    if not api_key:
        return

    try:
        params = {
            "api_key": api_key,
            "file_name": searchstring,
            "type": "tv",
            "imdb_id": None,
            "season_number": season,
            "episode_number": episode,
            "languages": languageshort,
            "subs_per_page": 50
        }

        response = requests.get(SEARCH_URL, params=params,
                                headers=build_api_headers(), timeout=API_TIMEOUT)
        response.raise_for_status()

        json_data = response.json()
        if json_data.get("status", False):
            for item in json_data.get("subtitles", []):
                try:
                    lang = item.get("lang")
                    filename = item.get("release_name")
                    sub_url = item.get("url")
                    if lang and filename and sub_url:
                        subtitles_list.append({
                            'filename': filename,
                            'sync': True,
                            'id': sub_url,
                            'language_flag': languageshort,
                            'language_name': languagelong
                        })
                except Exception as sub_err:
                    print('[SubDL] Error parsing item: {}'.format(sub_err))
    except Exception as err:
        print('[SubDL] Error in get_subtitles_list_tv: {}'.format(err))


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    subtitles_list = []
    msg = ""

    # Parse primary language
    lang_info = get_language_info(lang1)
    languagelong = lang_info['name']
    languageshort = lang_info['2et']

    if not title and not tvshow and not file_original_path:
        return subtitles_list, "", msg

    try:
        # Extract title from filename if title is missing
        if not title and not tvshow and file_original_path:
            try:
                filename = os.path.basename(file_original_path)
                match = re.match(
                    r'^(.*?)(?:\.\d{4}|\.S\d{2}E\d{2}|\.\d{3,4}p|\.\w{2,3})?\.\w+$', filename)
                if match:
                    title = match.group(1).replace('.', ' ').strip()
            except Exception as match_err:
                print('[SubDL] Error extracting title: {}'.format(match_err))

        if len(tvshow) == 0 and year:  # Movie with year
            searchstring = "%s (%s)" % (title, year)
            get_subtitles_list_movie(
                searchstring, title, languageshort, languagelong, subtitles_list)
        elif len(tvshow) > 0 and title == tvshow:  # Movie/Show title identical
            searchstring = "%s" % (tvshow)
            get_subtitles_list_tv(searchstring, tvshow, season,
                                  episode, languageshort, languagelong, subtitles_list)
        elif len(tvshow) > 0:  # TV Show with season/episode
            searchstring = "%s S%#02dE%#02d" % (
                tvshow, int(season), int(episode))
            get_subtitles_list_tv(searchstring, tvshow, season,
                                  episode, languageshort, languagelong, subtitles_list)
        elif title:  # Title only
            searchstring = title.replace(' ', '+').replace("'", "").lower()
            get_subtitles_list_movie(
                searchstring, title, languageshort, languagelong, subtitles_list)

    except Exception as err:
        print('[SubDL] Error in search_subtitles: {}'.format(err))
        return subtitles_list, "", str(err)

    return subtitles_list, "", msg


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    subtitle_id = subtitles_list[pos]["id"]
    language = subtitles_list[pos]["language_name"]

    if not os.path.exists(tmp_sub_dir):
        os.makedirs(tmp_sub_dir)

    response = None
    used_download_url = None
    download_errors = []

    for candidate_url, headers, mode in build_download_attempts(subtitle_id):
        try:
            response = requests.get(
                candidate_url,
                headers=headers,
                stream=True,
                timeout=DOWNLOAD_TIMEOUT,
                allow_redirects=True
            )
            response.raise_for_status()
            used_download_url = candidate_url
            break
        except requests.RequestException as error:
            download_errors.append("%s [%s]: %s" %
                                   (candidate_url, mode, error))

    if response is None or used_download_url is None:
        _raise_download_error(
            "SubDL download failed from all candidates: %s" % " | ".join(download_errors))

    local_tmp_file = _safe_local_tmp_file(
        zip_subs, tmp_sub_dir, "subdl_subtitle")
    packed = False
    subs_file = ""

    with open(local_tmp_file, 'wb') as outfile:
        for chunk in response.iter_content(chunk_size=1024):
            if chunk:
                outfile.write(chunk)

    if not os.path.isfile(local_tmp_file) or os.path.getsize(local_tmp_file) == 0:
        _raise_download_error(
            "SubDL downloaded an empty subtitle file from %s" % used_download_url)

    with open(local_tmp_file, "rb") as sub_f:
        header = sub_f.read(2)
        if header.startswith(b'R'):
            packed = True
            subs_file = "rar"
        elif header.startswith(b'P'):
            packed = True
            subs_file = "zip"
        else:
            subs_file = local_tmp_file

    return packed, language, subs_file
