# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import print_function
import requests
import json
import re, os
from bs4 import BeautifulSoup
from six.moves.urllib.parse import quote_plus
from .YtssubsUtilities import geturl, get_language_info
from ..utilities import log
import base64

# Explicit relative structure for cross-version compatibility
from ..user_agents import get_session_ua

# Bind this provider to a single stable browser signature for its lifecycle
PROVIDER_SESSION_KEY = "yifysubtitles"
SESSION_UA = get_session_ua(PROVIDER_SESSION_KEY)

# Initialize the persistent session object
session = requests.Session()
session.headers.update({
    "User-Agent": SESSION_UA,
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "accept-language": "en-US,en;q=0.9",
    "Referer": "https://yifysubtitles.ch",
    "priority": "u=1, i"
})

BASE_URL = "https://yifysubtitles.ch"
debug_pretext = ""

def prepare_search_string(s):
    s = s.replace("'", "").strip()
    s = re.sub(r'\(\d\d\d\d\)$', '', s)  # remove year from title
    s = s.replace(" :",":").replace(".", " ")
    print("s_title", s)
    return s

def getallsubs(html_content, allowed_languages, filename=""):
    """ Extract subtitle links from YIFYSubtitles.ch subtitle page with multiple filenames """
    subtitles = []
    
    soup = BeautifulSoup(html_content, "html.parser")
    subtitle_rows = soup.select("tr[data-id]")  # Select subtitle rows
    
    for row in subtitle_rows:
        try:
            # Extract language
            language = row.select_one("td.flag-cell span.sub-lang").text.strip()

            # Extract download page link
            subtitle_link_tag = row.select_one("td a[href^='/subtitles/']")
            if not subtitle_link_tag:
                continue  # Skip if no valid link

            subtitle_page_link = subtitle_link_tag["href"]
            
            # Ensure correct `<br>` splitting, even if first two names are joined
            subtitle_names = re.split(r"<br\s*/?>", subtitle_link_tag.decode_contents(), flags=re.IGNORECASE)

            # Match language to the correct format
            language_info = get_language_info(language)
            if not language_info or language_info["name"] not in allowed_languages:
                continue

            # Add each subtitle variant separately
            for subtitle_name in subtitle_names:
                subtitle_name = BeautifulSoup(subtitle_name, "html.parser").text.strip()  # Clean HTML tags
                subtitle_name = re.sub(r"^subtitle\s*", "", subtitle_name, flags=re.IGNORECASE)  # Remove "subtitle" only at the start
                subtitle_name = re.sub(r"^\.+", "", subtitle_name)  # Remove leading dots (e.g., ".Moana" -> "Moana")

                if subtitle_name:
                    subtitles.append({
                        "filename": subtitle_name,
                        "sync": True,  # No sync info available
                        "link": BASE_URL + subtitle_page_link,
                        "language_name": language_info["name"],
                        "lang": language_info
                    })

        except Exception as e:
            print("Skipping subtitle due to error: {}".format(e))
            continue

    return subtitles

def split_movie_title(movie_entry):
    """Extracts movie name and year from the API response."""
    movie_title = movie_entry.get("movie", "").strip()
    match = re.search(r"^(.*)\s+(\d{4})$", movie_title)  # Match "Title YYYY"

    if match:
        return match.group(1).strip(), match.group(2)  # (Movie Name, Year)
    return movie_title, None  # Return title as-is if no year found

def search_movie(title, year, languages, filename):
    """ Search for a movie on YIFYSubtitles.ch and retrieve subtitles """
    movie_title = prepare_search_string(title)
    try:
        # Prepare search URL
        search_url = "https://yifysubtitles.ch/ajax/search/?mov={}".format(movie_title)
        
        # We explicitly request with our unified cookie/UA session
        response = session.get(search_url, timeout=10)

        if response.status_code != 200:
            print("Error: Failed to fetch search results for '{}'".format(movie_title))
            return []

        movies = response.json()
        if not movies:
            print("No results found for '{}'".format(movie_title))
            return []

        # Try to find an exact year match
        best_match = None
        for movie in movies:
            movie_name, movie_year = split_movie_title(movie)
            if movie_year and movie_year == str(year):  # Exact match
                best_match = movie
                break  # Stop at first perfect match

        if not best_match:
            print("No exact year match found, selecting first result.")
            best_match = movies[0]  # Fallback to the first result if no exact match

        imdb_code = best_match.get("imdb")
        if not imdb_code:
            print("No IMDb code found for '{}'".format(movie_title))
            return []

        # Fetch subtitles for the selected movie
        movie_url = "https://yifysubtitles.ch/movie-imdb/{}".format(imdb_code)
        movie_page = session.get(movie_url, timeout=10)

        if movie_page.status_code != 200:
            print("Error: Failed to fetch subtitle page for '{}'".format(movie_title))
            return []

        # Pass .content instead of .text for safe auto-decoding in Python 2 & 3
        return getallsubs(movie_page.content, languages, filename)

    except Exception as error:
        print("Error in search_movie: {}".format(error))
        return []

def search_tvshow(title, season, episode, languages, filename):
    """ Search for a movie on YTS-Subs and retrieve subtitles """
    tv_title = prepare_search_string(title)
    try:
        search_url = "{}/search/ajax/{}".format(BASE_URL, tv_title)
        response = session.get(search_url, timeout=10)

        if response.status_code != 200:
            print("Error: Failed to fetch search results for '{}'".format(tv_title))
            return []

        movies = response.json()
        if not movies:
            print("No results found for '{}'".format(tv_title))
            return []

        # Select the best-matching movie (first result)
        selected_movie = movies[0]
        imdb_code = selected_movie.get("mov_imdb_code")
        if not imdb_code:
            print("No IMDb code found for '{}'".format(tv_title))
            return []

        # Fetch subtitles for the selected movie
        movie_url = "{}/movie-imdb/{}".format(BASE_URL, imdb_code)
        movie_page = session.get(movie_url, timeout=10)

        if movie_page.status_code != 200:
            print("Error: Failed to fetch subtitle page for '{}'".format(tv_title))
            return []

        # Pass .content instead of .text for safe auto-decoding in Python 2 & 3
        return getallsubs(movie_page.content, languages, filename)

    except Exception as error:
        print("Error in search_movie: {}".format(error))
        return []

def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):  # standard input
    log(__name__, "%s Search_subtitles = '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'" %
         (debug_pretext, file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack))
    if lang1 == 'Farsi':
        lang1 = 'Persian'
    if lang2 == 'Farsi':
        lang2 = 'Persian'
    if lang3 == 'Farsi':
        lang3 = 'Persian'
    if tvshow:
        sublist = search_tvshow(tvshow, season, episode, [lang1, lang2, lang3], file_original_path)
    elif title:
        sublist = search_movie(title, year, [lang1, lang2, lang3], file_original_path)
    else:
        try:
          sublist = search_manual(title, [lang1, lang2, lang3], file_original_path)
        except:
            print("error")
    return sublist, "", ""

def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    """ Download selected subtitle (ZIP/RAR) from scraped link """
    try:
        subtitle = subtitles_list[pos]
        subtitle_page_url = subtitle["link"]  # Page containing the download link
        language = subtitle["language_name"]

        print("subtitle_page_url", subtitle_page_url)

        # Fetches page utilizing persistent cookies and identical session user-agent
        response = session.get(subtitle_page_url, timeout=10)
        if response.status_code != 200:
            print("Error: Failed to fetch subtitle page {}".format(subtitle_page_url))
            return False, "", ""

        # Parse HTML from .content (bytes) for safety across Python environments
        soup = BeautifulSoup(response.content, "html.parser")
        download_button = soup.select_one("a.btn-icon.download-subtitle")

        if not download_button:
            print("Error: Could not find the download button.")
            return False, "", ""

        download_link = download_button.get("href")
        if not download_link:
            print("Error: No download link found.")
            return False, "", ""

        # Convert relative link to absolute URL while maintaining query token arguments intact
        if not download_link.startswith("http"):
            download_link = BASE_URL + download_link

        print("download_link", download_link)

        # Core execution: download file stream using exact same session/cookie signature
        subtitle_response = session.get(download_link, timeout=10, stream=True)
        if subtitle_response.status_code != 200:
            print("Error: Failed to download subtitle from {}".format(download_link))
            return False, "", ""

        # Save subtitle file as ZIP/RAR
        if not os.path.exists(tmp_sub_dir):
            try:
                os.makedirs(tmp_sub_dir)
            except OSError:
                pass
        
        local_tmp_file = zip_subs

        with open(local_tmp_file, "wb") as f:
            for chunk in subtitle_response.iter_content(chunk_size=1024):
                if chunk:
                    f.write(chunk)

        # Detect file format (RAR/ZIP/SRT)
        packed = False
        subs_file = ""

        with open(local_tmp_file, "rb") as f:
            header = f.read(2)
            if header.startswith(b'R'):
                packed = True
                subs_file = "rar"
            elif header.startswith(b'P'):
                packed = True
                subs_file = "zip"
            else:
                subs_file = local_tmp_file  # Assume SRT if neither ZIP nor RAR

        return packed, language, subs_file

    except Exception as e:
        print("Error downloading subtitle: {}".format(e))
        return False, "", ""