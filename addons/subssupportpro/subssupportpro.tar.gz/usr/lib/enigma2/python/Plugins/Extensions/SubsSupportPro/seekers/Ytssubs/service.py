# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import print_function
import requests
import json
import re
import os
from bs4 import BeautifulSoup
from six.moves.urllib.parse import quote_plus, quote
from .YtssubsUtilities import geturl, get_language_info
from ..utilities import log

from ..user_agents import get_session_ua

# Bind this provider to a single stable browser signature for its lifecycle
PROVIDER_SESSION_KEY = "yifysubtitles"
SESSION_UA = get_session_ua(PROVIDER_SESSION_KEY)

# Initialize the persistent session object
session = requests.Session()
session.headers.update({
    "User-Agent": SESSION_UA,
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "accept-language": "en-US,en;q=0.9",
    "Referer": "https://yifysubtitles.ch",
    "priority": "u=1, i"
})

BASE_URL = "https://yifysubtitles.ch"
debug_pretext = ""

ALLOWED_TITLE_TYPES = {
    "movie", "tvMovie", "tvSeries", "tvMiniSeries",
    "tvSpecial", "tvEpisode", "short", "video"
}


def get_imdb_info(query_string, target_year):
    """
    Uses IMDb's CDN endpoint to resolve fuzzy/misspelled titles to exact titles and IDs.
    Returns: (imdb_id, exact_title)
    """
    query = (query_string or "").strip().lower()
    if len(query) < 2:
        return None, query_string

    first_char = query[0]
    if not first_char.isalnum():
        first_char = 'a'

    url = "https://v3.sg.media-imdb.com/suggestion/{}/{}.json".format(
        first_char, quote(query, safe=""))

    try:
        resp = requests.get(
            url, headers={"User-Agent": SESSION_UA, "Accept": "application/json"}, timeout=6)
        if resp.status_code == 200:
            payload = resp.json()
            raw_items = payload.get("d", []) or []

            # 1. Try to match exact year first
            if target_year and str(target_year).isdigit():
                for item in raw_items:
                    if not isinstance(item, dict):
                        continue
                    imdb_id = str(item.get("id") or "")
                    title_type = str(item.get("qid") or "")
                    exact_title = str(item.get("l") or "").strip()

                    if imdb_id.startswith("tt") and exact_title and title_type in ALLOWED_TITLE_TYPES:
                        if str(item.get("y")) == str(target_year):
                            return imdb_id, exact_title

            # 2. Fallback to first valid title
            for item in raw_items:
                if not isinstance(item, dict):
                    continue
                imdb_id = str(item.get("id") or "")
                title_type = str(item.get("qid") or "")
                exact_title = str(item.get("l") or "").strip()

                if imdb_id.startswith("tt") and exact_title and title_type in ALLOWED_TITLE_TYPES:
                    return imdb_id, exact_title

    except Exception as e:
        print("[YIFY] IMDb Resolver Error:", e)

    return None, query_string


def getallsubs(html_content, requested_2et_list, filename=""):
    """ Extracts subtitle entries from HTML with robust language resolution """
    subtitles = []
    soup = BeautifulSoup(html_content, "html.parser")

    for tr in soup.find_all("tr", attrs={"data-id": True}):
        try:
            rating_cell = tr.find("td", class_="rating-cell")
            rating_text = rating_cell.get_text(
                strip=True) if rating_cell else "0"
            try:
                rating_val = int(rating_text)
            except ValueError:
                rating_val = 0

            # Raw language extracted directly from website HTML
            lang_cell = tr.find("span", class_="sub-lang")
            raw_lang = lang_cell.get_text(strip=True) if lang_cell else ""

            # Extract title strings
            link_tag = None
            for a in tr.find_all("a", href=True):
                if "/subtitles/" in a["href"]:
                    link_tag = a
                    break

            if not link_tag:
                continue

            href = link_tag["href"]
            full_link = BASE_URL + href if href.startswith("/") else href

            title_strings = []
            for s in link_tag.stripped_strings:
                if s.lower() != "subtitle":
                    clean_s = re.sub(r"^\.+", "", s).strip()
                    if clean_s:
                        title_strings.append(clean_s)

            # Heuristic detection for Farsi/Persian releases mislabeled as Arabic
            if raw_lang.lower() == "arabic":
                for ts in title_strings:
                    ts_low = ts.lower()
                    if "farsi" in ts_low or "persian" in ts_low or ".fa." in ts_low or ".pe." in ts_low:
                        raw_lang = "farsi_persian"
                        break

            # Resolve language dynamically
            lang_info = get_language_info(raw_lang)
            if not lang_info:
                continue

            # Compare ISO-639-1 code ('es', 'ar', 'fa', etc.)
            if lang_info["2et"].lower() not in requested_2et_list:
                continue

            for title_text in title_strings:
                sync = False
                if filename:
                    base_file = os.path.basename(filename).lower()
                    if base_file.replace(".mkv", "").replace(".mp4", "").replace(".avi", "") in title_text.lower():
                        sync = True

                subtitles.append({
                    "filename": title_text,
                    "sync": sync,
                    "link": full_link,
                    "language_name": lang_info["name"],
                    "lang": lang_info,
                    "rating": rating_val
                })

        except Exception as e:
            print("[YIFY] Parse row error: {}".format(e))
            continue

    try:
        subtitles.sort(key=lambda x: x.get("rating", 0), reverse=True)
    except Exception:
        pass

    return subtitles


def search_yify_by_name(exact_title):
    """Fallback search using YIFY's AJAX endpoint if IMDb direct fetch fails."""
    url = "{}/ajax/search/?mov={}".format(BASE_URL, quote_plus(exact_title))
    try:
        page_headers = session.headers.copy()
        page_headers["X-Requested-With"] = "XMLHttpRequest"
        resp = session.get(url, headers=page_headers, timeout=10)
        if resp.status_code == 200:
            return resp.json()
    except Exception as e:
        print("[YIFY] AJAX Search Error:", e)
    return []


def search_movie(title, year, languages, filename):
    """ Search for a movie on YIFYSubtitles.ch using IMDb ID directly """

    # 1. Resolve exact title and IMDb ID
    imdb_id, exact_title = get_imdb_info(title, year)
    print("[YIFY] Resolved IMDb ID: {} | Title: {}".format(imdb_id, exact_title))

    movie_page_content = None

    # 2. Try direct IMDb ID fetch
    if imdb_id:
        url = "{}/movie-imdb/{}".format(BASE_URL, imdb_id)
        try:
            page_headers = session.headers.copy()
            page_headers.pop("X-Requested-With", None)
            resp = session.get(url, headers=page_headers, timeout=10)
            if resp.status_code == 200:
                movie_page_content = resp.content
        except Exception as e:
            print("[YIFY] Direct IMDb fetch failed:", e)

    # 3. Fallback to AJAX Search if direct fetch failed or IMDb ID was missing
    if not movie_page_content:
        print("[YIFY] Falling back to AJAX search...")
        movies = search_yify_by_name(exact_title)
        if not movies:
            return []

        best_match = movies[0]
        if year and str(year).isdigit():
            for m in movies:
                m_title = m.get("movie", "")
                if str(year) in m_title:
                    best_match = m
                    break

        yify_imdb = best_match.get("imdb")
        if not yify_imdb:
            return []

        url = "{}/movie-imdb/{}".format(BASE_URL, yify_imdb)
        try:
            page_headers = session.headers.copy()
            page_headers.pop("X-Requested-With", None)
            resp = session.get(url, headers=page_headers, timeout=10)
            if resp.status_code == 200:
                movie_page_content = resp.content
        except Exception as e:
            print("[YIFY] AJAX ID fetch failed:", e)
            return []

    if movie_page_content:
        return getallsubs(movie_page_content, languages, filename)

    return []


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    log(__name__, "%s Search_subtitles = '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'" %
        (debug_pretext, file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack))

    if tvshow:
        return [], "", ""

    # Normalize Enigma2 inputs (whether 'ar', 'es', or 'Arabic') into lowercase 2et ISO codes
    requested_codes = set()
    for l in [lang1, lang2, lang3]:
        if not l:
            continue
        info = get_language_info(l)
        if info and info.get("2et"):
            requested_codes.add(info["2et"].lower())
        else:
            requested_codes.add(str(l).strip().lower())

    if title:
        sublist = search_movie(title, year, list(
            requested_codes), file_original_path)
    else:
        sublist = []

    return sublist, "", ""


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    """ Download selected subtitle (ZIP/RAR) from scraped link """
    try:
        subtitle = subtitles_list[pos]
        subtitle_page_url = subtitle["link"]
        language = subtitle["language_name"]

        page_headers = session.headers.copy()
        page_headers.pop("X-Requested-With", None)

        response = session.get(
            subtitle_page_url, headers=page_headers, timeout=10)
        if response.status_code != 200:
            print("Error: Failed to fetch subtitle page {}".format(subtitle_page_url))
            return False, "", ""

        soup = BeautifulSoup(response.content, "html.parser")
        download_btn = soup.find("a", class_="download-subtitle")

        if not download_btn or not download_btn.get("href"):
            print("Error: Could not find the download button.")
            return False, "", ""

        href = download_btn["href"]
        download_link = BASE_URL + href if href.startswith("/") else href

        subtitle_response = session.get(
            download_link, headers=page_headers, timeout=15, stream=True)
        if subtitle_response.status_code != 200:
            print("Error: Failed to download subtitle from {}".format(download_link))
            return False, "", ""

        if not os.path.exists(tmp_sub_dir):
            try:
                os.makedirs(tmp_sub_dir)
            except OSError:
                pass

        local_tmp_file = zip_subs

        with open(local_tmp_file, "wb") as f:
            for chunk in subtitle_response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)

        packed = False
        subs_file = ""

        with open(local_tmp_file, "rb") as f:
            header = f.read(2)
            if header.startswith(b'R'):
                packed = True
                subs_file = "rar"
            elif header.startswith(b'P'):
                packed = True
                subs_file = "zip"
            else:
                subs_file = local_tmp_file

        return packed, language, subs_file

    except Exception as e:
        print("Error downloading subtitle: {}".format(e))
        return False, "", ""
