# -*- coding: utf-8 -*-

import os
import glob
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, getDesktop

from . import _, __version__

_plugindir = os.path.dirname(os.path.abspath(__file__))

try:
    from skin import loadSkin
    _desk_w = getDesktop(0).size().width()
    if _desk_w >= 2560:
        loadSkin(os.path.join(_plugindir, "skin_2560.xml"))
    elif _desk_w >= 1920:
        loadSkin(os.path.join(_plugindir, "skin_1920.xml"))
    else:
        loadSkin(os.path.join(_plugindir, "skin.xml"))
except Exception:
    pass

# Game constants
COLS = 7
ROWS = 6

COLOR_EMPTY  = "#888888"
COLOR_P1     = "#f23d21"
COLOR_P2     = "#e6bd00"
COLOR_WIN    = "#00ff99"


def generate_board_svg(cw, ch, board, cursor_col, current_player, winner_cells, filepath,
                       anim_col=-1, anim_row=-1, anim_player=0):
    pad = max(2, min(cw, ch) // 9)
    r_min = max(3, int(min(cw, ch) / 2.0 - pad))
    W = COLS * cw
    H = (ROWS + 1) * ch

    lines = []
    lines.append('<?xml version="1.0" encoding="UTF-8"?>')
    lines.append('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (W, H))

    # Top row (cursor / drop area)
    for col in range(COLS):
        cx = col * cw + cw / 2.0
        cy = ch / 2.0
        if col == cursor_col and cursor_col >= 0:
            color = COLOR_P1 if current_player == 1 else COLOR_P2
            lines.append('  <circle cx="%f" cy="%f" r="%d" fill="%s"/>' % (cx, cy, r_min, color))
        else:
            lines.append('  <circle cx="%f" cy="%f" r="%d" fill="#212121"/>' % (cx, cy, r_min))

    # Separator line
    lines.append('  <line x1="0" y1="%d" x2="%d" y2="%d" stroke="rgba(255,255,255,0.10)" stroke-width="1"/>' % (ch, W, ch))

    # Game board
    for row in range(ROWS):
        for col in range(COLS):
            cx = col * cw + cw / 2.0
            cy = ch + row * ch + ch / 2.0
            v = board[row][col]
            if v == 0:
                lines.append('  <circle cx="%f" cy="%f" r="%d" fill="%s"/>' % (cx, cy, r_min, COLOR_EMPTY))
            else:
                is_winner = winner_cells and (row, col) in winner_cells
                color = COLOR_WIN if is_winner else (COLOR_P1 if v == 1 else COLOR_P2)
                lines.append('  <circle cx="%f" cy="%f" r="%d" fill="%s"/>' % (cx, cy, r_min, color))
                if is_winner:
                    lines.append('  <circle cx="%f" cy="%f" r="%d" fill="none" stroke="%s" stroke-width="2" opacity="0.85"/>' % (
                        cx, cy, r_min + 2, COLOR_WIN))

    # Vertical lines
    for col in range(1, COLS):
        lines.append('  <line x1="%d" y1="%d" x2="%d" y2="%d" stroke="rgba(255,255,255,0.06)" stroke-width="1"/>' % (
            col * cw, ch, col * cw, H))

    # Animation piece (falling)
    if anim_col >= 0 and anim_player > 0:
        acx = anim_col * cw + cw / 2.0
        acy = anim_row * ch + ch / 2.0
        acolor = COLOR_P1 if anim_player == 1 else COLOR_P2
        lines.append('  <circle cx="%f" cy="%f" r="%d" fill="%s"/>' % (acx, acy, r_min, acolor))

    lines.append('</svg>')
    with open(filepath, 'w') as f:
        f.write('\n'.join(lines))


def check_winner(board):
    """Check if there is a winner on the board."""
    def check_line(cells):
        for r, c in cells:
            if r < 0 or r >= ROWS or c < 0 or c >= COLS:
                return False
        vals = [board[r][c] for r, c in cells]
        return vals[0] != 0 and len(set(vals)) == 1

    directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
    for row in range(ROWS):
        for col in range(COLS):
            if board[row][col] == 0:
                continue
            for dr, dc in directions:
                cells = [(row + i*dr, col + i*dc) for i in range(4)]
                if check_line(cells):
                    return board[row][col], cells
    return 0, []


def board_full(board):
    """Check if the board is full (draw)."""
    return all(board[0][c] != 0 for c in range(COLS))


class ConnectFourScreen(Screen):
    """Main game screen."""

    def __init__(self, session, num_players=2):
        Screen.__init__(self, session)

        self._num_players = num_players
        self._cw = 60
        self._ch = 60
        self._draws = 0
        self._wins = [0, 0]

        self["bg"] = Pixmap()
        self["w_status"] = Label("")
        self["w_p1_name"] = Label("")
        self["w_p2_name"] = Label("")
        self["w_p1_score"] = Label("")
        self["w_p2_score"] = Label("")
        self["w_draws"] = Label("")
        self["w_draws_label"] = Label("")
        self["w_p1_wins_label"] = Label("")
        self["w_p2_wins_label"] = Label("")
        self["key_red"] = Label(_("Exit"))
        self["key_green"] = Label(_("Reset"))

        # Animation timer
        self._anim_timer = eTimer()
        self._anim_timer.callback.append(self._anim_step)
        self._anim_col = -1
        self._anim_row = 0
        self._anim_target = 0
        self._anim_player = 1
        self._animating = False

        # AI timer
        self._ai_timer = None

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "left": self._left,
                "right": self._right,
                "ok": self._drop,
                "green": self._new_game,
                "red": self._exit,
                "cancel": self._exit,
            }, -1
        )

        self.onClose.append(self._cleanup)
        self.onLayoutFinish.append(self._on_layout)

        self._init_game()

    def _init_game(self, reset_scores=True):
        """Initialize or reset game state."""
        self._board = [[0] * COLS for _ in range(ROWS)]
        self._cursor = COLS // 2
        self._current = 1
        self._winner = 0
        self._winner_cells = []
        self._game_over = False
        if reset_scores:
            self._wins = [0, 0]
            self._draws = 0

    def _on_layout(self):
        """Called after layout is finished."""
        if not self["bg"].instance:
            return
        sz = self["bg"].instance.size()
        self._cw = sz.width() // COLS
        self._ch = sz.height() // (ROWS + 1)
        self._update_names()
        self._render()
        self["w_status"].setText(_("Press OK to drop - Left/Right to move"))

    def _update_names(self):
        """Update player names based on game mode."""
        if self._num_players == 1:
            self["w_p1_name"].setText(_("Player"))
            self["w_p2_name"].setText(_("Enigma"))
        else:
            self["w_p1_name"].setText(_("Player 1"))
            self["w_p2_name"].setText(_("Player 2"))
        self["w_p1_wins_label"].setText(_("Wins:"))
        self["w_p2_wins_label"].setText(_("Wins:"))
        self["w_draws_label"].setText(_("Draws:"))
        self._update_hud()

    def _update_hud(self):
        """Update score display."""
        self["w_p1_score"].setText(str(self._wins[0]))
        self["w_p2_score"].setText(str(self._wins[1]))
        self["w_draws"].setText(str(self._draws))

    def _left(self):
        """Move cursor left."""
        if self._game_over or self._animating:
            return
        if self._num_players == 1 and self._current == 2:
            return
        self._cursor = max(0, self._cursor - 1)
        self._render()

    def _right(self):
        """Move cursor right."""
        if self._game_over or self._animating:
            return
        if self._num_players == 1 and self._current == 2:
            return
        self._cursor = min(COLS - 1, self._cursor + 1)
        self._render()

    def _drop(self):
        """Drop a piece in the current column."""
        if self._game_over:
            self._new_round()
            return
        if self._num_players == 1 and self._current == 2:
            return
        self._do_drop(self._cursor)

    def _do_drop(self, col):
        """Execute the drop action."""
        if self._animating:
            return

        # Find lowest empty row
        row = -1
        for r in range(ROWS - 1, -1, -1):
            if self._board[r][col] == 0:
                row = r
                break

        if row == -1:
            if self._num_players == 2 or self._current == 1:
                self["w_status"].setText(_("Column full! Choose another."))
            return

        # Start animation
        self._anim_col = col
        self._anim_target = row
        self._anim_row = 0
        self._anim_player = self._current
        self._animating = True
        self._anim_timer.start(60, False)

    def _anim_step(self):
        """Animation step for falling piece."""
        self._anim_timer.stop()
        if self._anim_row == -1:
            self._animating = False
            self._finish_drop(self._finish_col, self._finish_row)
            return
        if self._anim_row < self._anim_target:
            self._anim_row += 1
            self._render(anim_col=self._anim_col, anim_row=self._anim_row,
                         anim_player=self._anim_player)
            self._anim_timer.start(60, False)
        else:
            self._finish_col = self._anim_col
            self._finish_row = self._anim_target
            self._board[self._anim_target][self._anim_col] = self._anim_player
            self._anim_row = -1
            self._render()
            self._anim_timer.start(100, True)

    def _finish_drop(self, col, row):
        """Finish the drop and check win/draw conditions."""
        winner, cells = check_winner(self._board)
        if winner:
            self._winner = winner
            self._winner_cells = cells
            self._game_over = True
            self._wins[winner - 1] += 1
            if self._num_players == 1:
                if winner == 1:
                    msg = _("You win! Press OK for new game")
                else:
                    msg = _("Enigma wins! Press OK for new game")
            else:
                msg = _("Player %d wins! Press OK for new game") % winner
            self["w_status"].setText(msg)
            self._render(show_cursor=False)
            self._update_hud()
            return

        if board_full(self._board):
            self._game_over = True
            self._draws += 1
            self["w_status"].setText(_("Draw! Press OK for new game"))
            self._render(show_cursor=False)
            self._update_hud()
            return

        # Switch player
        self._current = 2 if self._current == 1 else 1
        self._render()
        self._update_hud()

        # AI move for single player mode
        if self._num_players == 1 and self._current == 2 and not self._game_over:
            self._ai_col = self._ai_move()
            self._ai_timer = eTimer()
            self._ai_timer.callback.append(self._ai_delayed_drop)
            self._ai_timer.start(150, True)

    def _ai_delayed_drop(self):
        """Delayed AI drop."""
        if self._ai_timer:
            self._ai_timer.stop()
        self._do_drop(self._ai_col)

    def _ai_move(self):
        """Calculate best AI move using minimax."""
        col_order = sorted(range(COLS), key=lambda c: abs(c - COLS // 2))
        best_score = -999999
        best_col = COLS // 2

        for col in col_order:
            if self._board[0][col] != 0:
                continue
            board_copy = [row[:] for row in self._board]
            if self._apply_move(board_copy, col, 2):
                score = self._minimax(board_copy, 3, False, -999999, 999999)
                if score > best_score:
                    best_score = score
                    best_col = col

        return best_col

    def _apply_move(self, board, col, player):
        """Apply a move to a board copy."""
        for r in range(ROWS - 1, -1, -1):
            if board[r][col] == 0:
                board[r][col] = player
                return True
        return False

    def _minimax(self, board, depth, maximizing, alpha, beta):
        """Minimax algorithm with alpha-beta pruning."""
        winner, _ = check_winner(board)
        if winner == 2:
            return 1000 + depth
        if winner == 1:
            return -1000 - depth
        if board_full(board) or depth == 0:
            return self._heuristic(board)

        col_order = sorted(range(COLS), key=lambda c: abs(c - COLS // 2))
        if maximizing:
            best = -999999
            for col in col_order:
                if board[0][col] != 0:
                    continue
                b = [row[:] for row in board]
                self._apply_move(b, col, 2)
                val = self._minimax(b, depth - 1, False, alpha, beta)
                best = max(best, val)
                alpha = max(alpha, best)
                if beta <= alpha:
                    break
            return best
        else:
            best = 999999
            for col in col_order:
                if board[0][col] != 0:
                    continue
                b = [row[:] for row in board]
                self._apply_move(b, col, 1)
                val = self._minimax(b, depth - 1, True, alpha, beta)
                best = min(best, val)
                beta = min(beta, best)
                if beta <= alpha:
                    break
            return best

    def _heuristic(self, board):
        """Heuristic evaluation function for AI."""
        score = 0

        # Center column preference
        mid = COLS // 2
        mid_count = sum(1 for r in range(ROWS) if board[r][mid] == 2)
        score += mid_count * 3

        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for row in range(ROWS):
            for col in range(COLS):
                for dr, dc in directions:
                    cells = [(row + i*dr, col + i*dc) for i in range(4)]
                    if any(r < 0 or r >= ROWS or c < 0 or c >= COLS for r, c in cells):
                        continue

                    vals = [board[r][c] for r, c in cells]
                    ai = vals.count(2)
                    hum = vals.count(1)
                    emp = vals.count(0)

                    if hum == 0:
                        if ai == 3 and emp == 1:
                            score += 50
                        elif ai == 2 and emp == 2:
                            score += 10
                    elif ai == 0:
                        if hum == 3 and emp == 1:
                            score -= 80
                        elif hum == 2 and emp == 2:
                            score -= 15

        return score

    def _render(self, show_cursor=True, anim_col=-1, anim_row=-1, anim_player=0):
        """Render the game board as SVG."""
        if not self["bg"].instance:
            return

        svg_path = "/tmp/connect4_scene.svg"
        cursor = self._cursor if show_cursor and not self._game_over and not self._animating else -1
        generate_board_svg(
            self._cw, self._ch,
            self._board,
            cursor,
            self._current,
            self._winner_cells if self._game_over else [],
            svg_path,
            anim_col=anim_col,
            anim_row=anim_row,
            anim_player=anim_player
        )

        px = LoadPixmap(svg_path)
        if px is not None:
            self["bg"].instance.setPixmap(px)

    def _new_round(self):
        """Start a new round without resetting scores."""
        self._init_game(reset_scores=False)
        self._render()
        self._update_hud()
        if self._num_players == 1:
            self["w_status"].setText(_("Your turn - Left/Right and OK"))
        else:
            self["w_status"].setText(_("Player 1 begins - Left/Right and OK"))

    def _new_game(self):
        """Reset everything (scores and board)."""
        self._init_game(reset_scores=True)
        self._render()
        self._update_hud()
        if self._num_players == 1:
            self["w_status"].setText(_("Your turn - Left/Right and OK"))
        else:
            self["w_status"].setText(_("Player 1 begins - Left/Right and OK"))

    def _exit(self):
        """Exit the game."""
        self.close(False)

    def _cleanup(self):
        """Clean up temporary files."""
        try:
            if os.path.exists("/tmp/connect4_scene.svg"):
                os.remove("/tmp/connect4_scene.svg")
            for f in glob.glob("/tmp/connect4_*.svg"):
                try:
                    os.remove(f)
                except Exception:
                    pass
        except Exception:
            pass


class ConnectFourPlayerSelect(Screen):
    """Player selection screen."""

    def __init__(self, session):
        Screen.__init__(self, session)
        self._choice = 1

        self["w_title"] = Label(_("Connect Four"))
        self["w_label"] = Label(_("Mode:"))
        self["w_choice"] = Label("")
        self["key_red"] = Label(_("Exit"))
        self["key_green"] = Label(_("Start"))

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "ok": self._start,
                "green": self._start,
                "left": self._toggle,
                "right": self._toggle,
                "red": self.close,
                "cancel": self.close,
            }, -1
        )

        self._update()

    def _toggle(self):
        """Toggle between 1 and 2 players."""
        self._choice = 1 if self._choice == 2 else 2
        self._update()

    def _update(self):
        """Update the choice label."""
        if self._choice == 1:
            self["w_choice"].setText(_("< 1 Player vs Enigma >"))
        else:
            self["w_choice"].setText(_("< 2 Players >"))

    def _start(self):
        """Start the game with selected mode."""
        self.session.openWithCallback(
            self._game_closed,
            ConnectFourScreen,
            num_players=self._choice
        )

    def _game_closed(self, close_all=None, *args):
        """Callback when game is closed."""
        if close_all is False:
            self.close()


def main(session, **kwargs):
    session.open(ConnectFourPlayerSelect)


def Plugins(**kwargs):
    from Plugins.Plugin import PluginDescriptor
    return PluginDescriptor(
        name=_("Connect Four"),
        description=_("Connect Four v.%s") % __version__,
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="connect4.svg",
        fnc=main
    )
