from __future__ import division
import time
import requests
from collections import namedtuple

try:
    from statistics import mean
except ImportError:
    def mean(lst):
        if not lst:
            return 0.0
        return sum(lst) / len(lst)

from ..__version__ import __title__, __version__


class TestType(object):
    Down = "GET"
    Up = "POST"

TestSpec = namedtuple('TestSpec', ['size', 'iterations', 'name', 'type'])

@property
def _test_spec_bits(self):
    return self.size * 8
TestSpec.bits = _test_spec_bits


DOWNLOAD_TESTS = (
    TestSpec(100000, 10, "100kB", TestType.Down),
    TestSpec(1000000, 8, "1MB", TestType.Down),
    TestSpec(10000000, 6, "10MB", TestType.Down),
)
UPLOAD_TESTS = (
    TestSpec(100000, 8, "100kB", TestType.Up),
    TestSpec(1000000, 6, "1MB", TestType.Up),
    TestSpec(10000000, 4, "10MB", TestType.Up),
)
LATENCY_TEST = (
    TestSpec(1, 20, "latency", TestType.Down),
)

DEFAULT_TESTS = LATENCY_TEST + DOWNLOAD_TESTS + UPLOAD_TESTS


class TestResult(object):
    def __init__(self, value, timestamp=None):
        self.value = value
        self.time = timestamp if timestamp is not None else time.time()


class TestTimers(object):
    def __init__(self, full, server, request):
        self.full = full
        self.server = server
        self.request = request

    def to_speeds(self, test):
        if test.type == TestType.Up:
            return [
                int(test.bits / st) if st > 0 else int(test.bits / max(ft, 1e-6))
                for st, ft in zip(self.server, self.full)
            ]
        return [
            int(test.bits / (ft - st)) if (ft - st) > 0 else int(test.bits / max(ft, 1e-6))
            for ft, st in zip(self.full, self.server)
        ]

    def to_latencies(self):
        return [
            (request_time - server_time) * 1e3
            for request_time, server_time in zip(self.request, self.server)
        ]

    @staticmethod
    def jitter_from(latencies):
        if len(latencies) < 2:
            return None
        return mean(
            [
                abs(latencies[i] - latencies[i - 1])
                for i in range(1, len(latencies))
            ]
        )


TestMetadata = namedtuple('TestMetadata', ['ip', 'isp', 'location_code', 'region', 'city', 'country'])


def _calculate_percentile(data, percentile):
    data = sorted(data)
    idx = (len(data) - 1) * percentile
    rem = idx % 1

    if rem == 0:
        return data[int(idx)]

    low_edge = data[int(idx)]
    high_edge = data[int(idx) + 1]
    return low_edge + (high_edge - low_edge) * rem


class CloudflareSpeedtest(object):
    """Suite of speedtests"""

    def __init__(self, results=None, tests=DEFAULT_TESTS, timeout=(10, 25)):
        self.results = results or {}
        self.results.setdefault("tests", {})
        self.results.setdefault("meta", {})

        self.tests = tests
        self.request_sess = requests.Session()
        self.request_sess.headers.update(
            {
                "Referer": "https://cloudflare.com",
                "User-Agent": "{}/{}".format(__title__, __version__),
            }
        )
        self.timeout = timeout

    def metadata(self):
        """Retrieve test location code, IP address, ISP, city, and region.
        """
        response = self.request_sess.get(
            "https://speed.cloudflare.com/meta", timeout=self.timeout
        )
        response.raise_for_status()
        result_data = response.json()
        return TestMetadata(
            result_data.get("clientIp", 'N/A'),
            result_data.get("asOrganization", 'N/A'),
            result_data.get("countryCode", 'N/A'),
            result_data.get("region", 'N/A'),
            result_data.get("city", 'N/A'),
            result_data.get("country", 'N/A'),
        )

    def run_test(self, test):
        """Run a test specification iteratively and collect timers."""
        coll = TestTimers([], [], [])
        url = "https://speed.cloudflare.com/__down?bytes={}".format(test.size)
        data = None

        if test.type == TestType.Up:
            url = "https://speed.cloudflare.com/__up"
            data = b"\x00" * test.size

        for _ in range(test.iterations):
            start = time.time()
            r = self.request_sess.request(
                test.type, url, data=data, timeout=self.timeout
            )
            r.raise_for_status()
            coll.full.append(time.time() - start)
            try:
                coll.server.append(
                    float(r.headers["Server-Timing"].split("=")[1].split(";")[0]) / 1e3
                )
            except:
                 coll.server.append(0.0)

            coll.request.append(
                r.elapsed.seconds + r.elapsed.microseconds / 1e6
            )
        return coll


    def _sprint(self, label, result, meta=False):
        save_to = self.results["meta"] if meta else self.results["tests"]
        save_to[label] = result

    def run_all(self, megabits=False):
        # type: (bool) -> dict
        """Run the full test suite and calculate percentiles.
        """
        meta = self.metadata()
        self._sprint("ip", TestResult(meta.ip), meta=True)
        self._sprint("isp", TestResult(meta.isp))
        self._sprint("location_code", TestResult(meta.location_code), meta=True)
        self._sprint("location_city", TestResult(meta.city), meta=True)
        self._sprint("location_region", TestResult(meta.region), meta=True)
        self._sprint("location_country", TestResult(meta.country), meta=True)

        data = {"down": [], "up": []}

        for test in self.tests:
            timers = self.run_test(test)

            if test.name == "latency":
                latencies = timers.to_latencies()
                jitter = timers.jitter_from(latencies)
                if jitter:
                    jitter = round(jitter, 2)
                self._sprint("latency", TestResult(round(mean(latencies), 2)))
                self._sprint("jitter", TestResult(jitter))
                continue

            speeds = timers.to_speeds(test)

            type_name = "up" if test.type == TestType.Up else "down"
            data[type_name].extend(speeds)

            mean_speed = int(mean(speeds))
            label_suffix = "bps"
            if megabits:
                mean_speed = round(mean_speed / 1000000.0, 2)
                label_suffix = "mbps"

            self._sprint(test.name, TestResult("{} {}".format(mean_speed, label_suffix)))

        for direction in ("down", "up"):
            speeds_list = data[direction]
            key_name = "90th_percentile_{}_bps".format(direction)
            if speeds_list:
                p90_speed = int(_calculate_percentile(speeds_list, 0.90))

                if megabits:
                    p90_speed = round(p90_speed / 1000000.0, 2)

                self._sprint(key_name, TestResult(p90_speed))
            else:
                self._sprint(key_name, TestResult(0))

        return self.results

    @staticmethod
    def results_to_dict(results):
        # type: (dict) -> dict
        """Convert the test results to a full dictionary.
        """
        try:
            items_iterator = results.iteritems
        except AttributeError:
            items_iterator = results.items

        res = {}
        for k, v in items_iterator():
            sub_res = {}

            try:
                sub_items = v.iteritems
            except AttributeError:
                sub_items = v.items

            for sk, sv in sub_items():
                sub_res[sk] = {
                    "value": sv.value,
                    "time": sv.time
                }
            res[k] = sub_res

        return res
