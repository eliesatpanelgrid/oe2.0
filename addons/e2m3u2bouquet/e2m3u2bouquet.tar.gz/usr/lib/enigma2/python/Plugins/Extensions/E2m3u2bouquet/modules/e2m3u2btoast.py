# -*- coding: utf-8 -*-
from __future__ import division
from datetime import timedelta
from enigma import ePoint, eSize
from Components.Label import Label
from Screens.Screen import Screen
from skin import parseColor
from .. import getSkin, initTimer
from ..log import logger


class Toast(Screen):
    DURATION_SHORT = 5
    DURATION_MEDIUM = 10
    DURATION_LONG = 30
    DURATION_VERY_LONG = 60

    def __init__(self, session, text, duration, color, toastTimer):
        Screen.__init__(self, session)
        self.skinName = 'E2m3u2b_Toast'
        self.skin = getSkin(self.skinName)
        self.duration = duration
        self.color = color
        self.timer = toastTimer
        self["text"] = Label(text)
        self.onLayoutFinish.append(self._onLayoutFinish)

    def _onLayoutFinish(self):
        if not self.instance or not self["text"].instance:
            return

        try:
            orgwidth = int(self.instance.size().width())
            orgpos = self.instance.position()
            textsize = self["text"].getSize()
            if not textsize or textsize[0] <= 0 or textsize[1] <= 0:
                textsize = (600, 80)
            text_w = int(textsize[0] + 20)
            text_h = int(textsize[1] + 15)
            self["text"].instance.setZPosition(99)
            self.instance.resize(eSize(text_w, text_h))
            self["text"].instance.resize(eSize(text_w, text_h))
            if self.color:
                try:
                    self["text"].instance.setForegroundColor(parseColor(self.color))
                except Exception:
                    pass

            newwidth = text_w
            move_x = int(orgpos.x() + (orgwidth - newwidth) / 2)
            if move_x < 0:
                move_x = 10

            self.instance.move(ePoint(move_x, int(orgpos.y())))
        except Exception as err:
            try: logger.debug("[Toast Geometry] Layout finish warning: %s" % err)
            except Exception: pass


class ToastManager(object):
    def __init__(self, session):
        self._session = session
        self._queue = []
        self._deleteQueue = []
        self._currentToast = None
        self._toastTimer, self._toastTimer_conn = initTimer(self._onTimeout)
        self.onClose = lambda: self.close()

    def showToast(self, text, duration=Toast.DURATION_SHORT, color=None):
        if self._session is None:
            return None
        try:
            screen = self._session.instantiateDialog(Toast, text, duration, color, self._toastTimer)
            self.show(screen)
            return screen
        except Exception as err:
            try: logger.error("[ToastManager] instantiateDialog failed: %s" % err)
            except Exception: pass
            return None

    def show(self, screen):
        if screen:
            self._queue.append(screen)
            self._processQueue()

    def hide(self, screen):
        if not screen:
            return
        if screen == self._currentToast:
            self._onTimeout()
        elif screen in self._queue:
            self._queue.remove(screen)
        else:
            try: logger.debug("Screen is not a toast or already about to be deleted %s" % (screen,))
            except Exception: pass

    def _onTimeout(self):
        if self._currentToast:
            self._deleteQueue.append(self._currentToast)
            try:
                self._currentToast.hide()
                self._currentToast.onHide.append(self._processQueue)
            except Exception:
                pass
            self._currentToast = None
        self._processQueue()

    def _processQueue(self):
        unfinished = []
        active_delete_queue = list(self._deleteQueue)

        for toast in active_delete_queue:
            is_active = False
            try:
                if toast.timer and hasattr(toast.timer, 'isActive'):
                    is_active = toast.timer.isActive()
            except Exception:
                pass

            if not is_active:
                #Removing expired toast safely
                try:
                    if self._processQueue in toast.onHide:
                        toast.onHide.remove(self._processQueue)
                    self._session.deleteDialog(toast)
                except Exception:
                    pass
            else:
                unfinished.append(toast)
        self._deleteQueue = unfinished

        if self._currentToast or not self._queue:
            return
        self._currentToast = self._queue.pop(0)
        try:
            self._currentToast.show()
            self._toastTimer.startLongTimer(self._currentToast.duration)
        except Exception:
            pass

    def close(self):
        """Explicitly cleans up C++ timers and connections to prevent RAM leaks"""
        try:
            if self._toastTimer:
                self._toastTimer.stop()
        except Exception:
            pass

        if self._toastTimer_conn is not None:
            try:
                self._toastTimer_conn = None
            except Exception:
                pass

        self._queue = []
        self._deleteQueue = []
        self._currentToast = None
