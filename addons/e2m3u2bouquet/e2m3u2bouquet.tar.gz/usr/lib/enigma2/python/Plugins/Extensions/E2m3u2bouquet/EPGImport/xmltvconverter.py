# -*- coding: utf-8 -*-
import sys
import re
from datetime import datetime
from .. import xml_unescape
from .EPGConfig import enumerateXML, get_histtimings, td2str, compress, pairwise
from .EPGImport import ISO639
from ..log import logger
from collections import OrderedDict
from functools import partial

parental = re.compile(r'(?:^|\D)(?P<rating>\d{1,2})(?:\+|AP|$)')
EPOCH_ORD = datetime(1970, 1, 1)
histseconds, timespan = get_histtimings()
tags = ['title', 'sub-title', 'desc', 'rating', 'credits']

if sys.version_info >= (3, 0):
    def get_dict_values(d): return d.values()
else:
    def get_dict_values(d): return d.viewvalues()

def get_event_data(lang, valid, elem, unescape=xml_unescape, iso_get=ISO639.get):
	"""
	The priority given to event data with the preffered language, if an event with this language
	is not found in the "programme" node, then "eng" is taken, if it is not there, then the first one found
	"""
	try:
		pr, cr = None, None
		local_xmltv = {}

		for node in elem:
			tag = node.tag
			if tag not in valid:
				continue

			if tag == 'rating':
				pr = node.find('./value')
			elif tag == 'credits':
				cr = list(node)
			else:
				node_lang = iso_get(node.get('lang', '').lower(), 'eng')
				if node_lang not in local_xmltv:
					local_xmltv[node_lang] = OrderedDict((t, '') for t in tags[:-2])
				local_xmltv[node_lang][tag] = unescape(node.text or '')

		if not local_xmltv:
			raise Exception("no values were found for given tags")

		if lang in local_xmltv:
			ret = local_xmltv[lang]
		elif 'eng' in local_xmltv:
			lang = 'eng'
			ret = local_xmltv['eng']
		else:
			lang, ret = local_xmltv.popitem()

		ret['category'] = 0
		ret['id'] = 0

		if pr:
			pr_text = pr.text or ''
			pr_match = parental.search(pr_text) or parental.search('\n'.join(tags[:-2]))
			rating_val = max(0, int(pr_match.group('rating')) - 3) if pr_match else 0
			ret['rating'] = ((lang.upper(), rating_val),)
		else:
			ret['rating'] = ((lang.upper(), 0),)

		if cr:
			credits_str = ', '.join('%s (%s)' % (xml_unescape(e.text or ''), e.tag) for e in cr)
			desc = ret.get('desc', '')
			ret['desc'] = (desc + '\n\n' + credits_str).lstrip() if desc else credits_str

		return iter(get_dict_values(ret))


	except Exception as err:
		func_name = sys._getframe().f_code.co_name
		logger.debug("XMLTVConverter: %s -> %s" % (func_name, err))
		return iter(['']*3)


def timestamp_utc(offset, xmltv_date):
	"""Calculate Unix timestamp from XMLTV time format '20180920140000 +0300'
	"""
	try:
		seconds = (datetime(
				int(xmltv_date[:4]),   # Year
				int(xmltv_date[4:6]),  # Month
				int(xmltv_date[6:8]),  # Day
				int(xmltv_date[8:10]), # Hour
				int(xmltv_date[10:12]) # Minute
			) - EPOCH_ORD).total_seconds()

		xml_tz_str = xmltv_date[15:]
		xml_tz = int(xml_tz_str) if xml_tz_str and xml_tz_str.strip() else 0
		seconds -= 3600 * ((xml_tz // 100) + offset)

		return int(seconds)

	except Exception as err:
		func_name = sys._getframe().f_code.co_name
		logger.debug("XMLTVConverter: %s -> %s" % (func_name, err))
		return 0


def getDataTuple(event_timestamp, event_data, now_timestamp_utc, elem):
	"""here we get an event tuple of tuples or None

	ETSI EN 300 468
	0. start time (long)
	1. duration (long)
	2. event title (string)
	3. short description (string) -> 6.2.37 Short event descriptor
	4. extended description (string) -> 6.2.15 Extended event descriptor
	5. event type (byte - uint8_t) or list or tuple of event types -> 6.2.9 Content descriptor
	6. optional event ID (int - uint16_t), if not supplied, it will default to 0, which implies an
	   an auto-generated ID based on the start time.
	7. optional list or tuple of tuples
	   (country[string 3 bytes], parental_rating [byte - u_char]) -> 6.2.28 Parental rating descriptor
	"""
	start_str = elem.get('start', '').strip()
	stop_str = elem.get('stop', '').strip()

	if not(start_str and stop_str):
		return None

	t_start = event_timestamp(start_str)
	t_stop = event_timestamp(stop_str)

	if (t_start and t_stop and t_stop > t_start) and t_start <= timespan and now_timestamp_utc <= t_stop:
		duration = t_stop - t_start

		try:
			if not (0 < duration <= 86400):
				raise Exception("%s has an unexpected 'duration' value: %s sec" % (elem.get('channel'), duration))

			l = [t_start, duration]
			l.extend(event_data(elem))
			title = l[2]
			if not title:
				raise Exception("%s has an empty value of 'title', it's not allowed" % elem.get("channel"))

			# Safely truncate the name to 220 bytes (Enigma2 limit)
			if len(title) > 70:
				title_bytes = title.encode('utf-8')[:220]
				l[2] = title_bytes.decode('utf-8', errors='ignore' if PY3 else 'ignore')

			return tuple(l)

		except Exception as err:
			func_name = sys._getframe().f_code.co_name
			logger.debug("XMLTVConverter: %s -> %s" % (func_name, err))
			return None


class XMLTVConverter(object):

	@classmethod
	def enumFile(cls, xmltv, source):
		"""Here we yield a tuple consisting of a list of services and a tuple of event tuples or None.
		Return a None object to give up time to the reactor.
		"""
		if not source.channels.items:
			logger.warn("['%s'] Nothing to process. The channels table is empty" % source.description)
			return

		now_timestamp_utc = (datetime.utcnow() - EPOCH_ORD).total_seconds()
		if histseconds:
			now_timestamp_utc -= histseconds
			logger.info("[%s]: Keep outdated EPG events to -%s" % (source.description,td2str(histseconds)))

		binary_mask = [int(x) for x in bin(source.parsing)[2:].zfill(len(tags))]
		valid = list(compress(tags, binary_mask))
		lang = ISO639.get(source.lang[:2], 'eng')   # Preferred EPG language
		event_timestamp = partial(timestamp_utc, source.epgoffset)
		event_data = partial(get_event_data, lang, valid)
		elem2tuple = partial(getDataTuple, event_timestamp, event_data, int(now_timestamp_utc))
		get_id = lambda el: el.get('channel', '') if el is not None else ''
		logger.info("[%s]: Processing events information ..." % source.description)

		count = 0
		unescape = xml_unescape
		services, events, curr_id = [], [], None
		for elem, next_elem in pairwise(enumerateXML(xmltv, tag='programme')):
			if curr_id is None:
				curr_id = get_id(elem)
				services = source.channels.items[unescape(curr_id.lower())]
				if services:
					services = list(services)
				else:
					curr_id = None
					continue

			processed_elem = elem2tuple(elem)
			next_id = get_id(next_elem)

			if processed_elem:
				events.append(processed_elem)
				if next_id == curr_id:
					continue
				yield services, tuple(events)

			elif next_id == curr_id:
				continue
			elif events:
				yield services, tuple(events)

			events, curr_id = [], None
			count += 1
			if count % 2000 == 0:
				yield None

		if services and events:
			yield services, tuple(events)
