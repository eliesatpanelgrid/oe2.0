# -*- coding: utf-8 -*-
import re
import time
import struct
from datetime import datetime
from collections import deque
import sys

from .EPGConfig import Timer, get_histtimings, ram_guard_flush
from .. import isDreamOS
from ..log import logger
from ..modules.six import PY3, ensure_str, ensure_text
from ..modules.six.moves import range, zip, filter


PATTERN = re.compile(r'''\.(?=(?:[^'"]|'[^']*'|"[^"]*")*$)''')
EPOCH_AS_FILETIME = 116444736000000000  # January 1, 1970 as MS file time
HUNDREDS_OF_NANOSECONDS = 10000000
histseconds, timespan = get_histtimings()

def utc_offset():
    timestamp = time.time()
    utime = datetime.utcfromtimestamp(timestamp)
    btime = datetime.fromtimestamp(timestamp)
    return (btime - utime).total_seconds()

utc_offset = utc_offset()

def MSfiletime_to_timestamp(MStimestamp):
    timestamp, _ = divmod((MStimestamp - EPOCH_AS_FILETIME), HUNDREDS_OF_NANOSECONDS)
    return int(timestamp - utc_offset)

def parse_events(data_bytes):
    if not data_bytes or len(data_bytes) < 2:
        return []

    view = memoryview(data_bytes)
    events_num = struct.unpack('<H', view[:2].tobytes() if PY3 else view[:2])[0] * 12
    events_view = view[2:2+events_num]

    if PY3 and hasattr(struct, 'iter_unpack'):
        return [
            MSfiletime_to_timestamp(fmt_entry[1])
            for fmt_entry in struct.iter_unpack('<hqH', events_view)
        ]

    pack_len = 12
    unpacked_events = []
    events_view_bytes = events_view.tobytes() if PY3 else events_view

    for i in range(0, len(events_view_bytes), pack_len):
        try:
            chunk = events_view_bytes[i:i+pack_len]
            if len(chunk) == pack_len:
                unpacked_events.append(MSfiletime_to_timestamp(struct.unpack('<hqH', chunk)[1]))
        except Exception:
            pass
    return unpacked_events

def parse_titles(data_bytes, encoding):
    """Streams parsed titles utilizing pure index address
    """
    if not data_bytes or len(data_bytes) < 26:
        return

    if data_bytes[:26] != b'\x4a\x54\x56\x20\x33\x2e\x78\x20\x54\x56\x20\x50\x72\x6f\x67\x72\x61\x6d\x20\x44\x61\x74\x61\x0a\x0a\x0a':
        raise Exception('Invalid JTV 3.x TV Programm Data format')

    view = memoryview(data_bytes)
    offset = 26
    total_len = len(view)

    while offset < total_len:
        try:

            title_length = struct.unpack('<H', view[offset:offset+2].tobytes() if PY3 else view[offset:offset+2])[0]
            offset += 2

            if offset + title_length <= total_len:
                title_bytes = view[offset:offset+title_length].tobytes() if PY3 else view[offset:offset+title_length]
                yield title_bytes.decode(encoding, 'ignore')
                offset += title_length
            else:
                break
        except Exception:
            break

class JTVConverter(object):

    @classmethod
    def enumFile(cls, zipobj, source, jtv_encoding="cp1251"):
        if not source.channels or len(source.channels) == 0:
            logger.warn("[%s] JTVConverter is nothing to enumerate. The channels lookup table is empty" % source.description)
            return

        now_timestamp_utc = time.time()
        if histseconds:
            now_timestamp_utc -= histseconds
            logger.info("[%s] Keep outdated EPG events to -%s" % (source.description, time.strftime("%H:%M:%S", time.gmtime(histseconds))))
        now_timestamp_utc = int(now_timestamp_utc)
        LANG_FLAG = 0x800    # bit 11 indicates UTF-8 for filenames

        with Timer() as timer:
            logger.info("[%s] Processing events information ..." % source.description)
            for zinfo in filter(lambda x: x.filename.endswith('.pdt'), zipobj.infolist()):
                filename = zinfo.filename
                if zinfo.flag_bits & LANG_FLAG == 0:
                    if PY3:
                        filename = bytes(filename, encoding='cp437')
                    unicode_fname = filename.decode('cp866', 'replace')
                else:
                    unicode_fname = filename

                if PY3:
                    channel_id = ensure_str('%s' % unicode_fname[0:-4]).replace('_', ' ').lower()
                else:
                    channel_id = ensure_text('%s' % unicode_fname[0:-4]).replace('_', ' ').lower().encode('utf-8')

                channels_map_target = source.channels.get(channel_id, None)
                if not channels_map_target:
                    continue
                try:
                    with zipobj.open(zinfo.filename) as f:
                        titles = list(parse_titles(f.read(), jtv_encoding))
                except Exception as err:
                    logger.warn("[%s] JTVConverter failed to process titles in %s: %s" % (source.description, zinfo.filename, err))
                    continue
                try:
                    events_fname = zinfo.filename[:-4] + '.ndx'
                    with zipobj.open(events_fname) as f:
                        events = parse_events(f.read())
                    events = deque(zip(events[:-1], events[1:]))
                except Exception as err:
                    logger.warn("[%s] JTVConverter failed to process events in %s: %s" % (source.description, events_fname, err))
                    continue

                events_list_accumulator = []

                for title in titles:
                    timer.counter += 1
                    if not events:
                        break
                    try:
                        t = list(events.popleft())
                        if '.' in title:
                            try: title, descr = [s.strip() for s in title.split('.', 1)]
                            except: title, descr = title.strip(), ''
                        else:
                            title, descr = title.strip(), ''

                        title_str = ensure_str(title)
                        descr_str = ensure_str(descr)

                        if t[0] <= timespan and now_timestamp_utc <= t[1] >= t[0]:
                            t[1] -= t[0]
                            if t[1] >= 86400:
                                raise IndexError(t)

                            events_list_accumulator.append(tuple(t + [title_str, '', descr_str, 0]))

                    except IndexError:
                        pass
                    except Exception as err:
                        pass
                    finally:
                        if timer.counter % 20000 == 0 and timer.counter > 0:
                            logger.info("[{}]: Processed {:,} events ...".format(source.description, timer.counter))
                            ram_guard_flush(f=None, dict_obj=None, mem_limit_mb=35, sleep_time=1.0)
                if events_list_accumulator:
                    yield list(channels_map_target), tuple(events_list_accumulator)

            timer.msg = 'Total processed {:,} events in {} or ~{:,.0f} per sec'.format(timer.counter, time.strftime("%H:%M:%S", time.gmtime(timer.elapsed)), timer.counter/timer.elapsed)
