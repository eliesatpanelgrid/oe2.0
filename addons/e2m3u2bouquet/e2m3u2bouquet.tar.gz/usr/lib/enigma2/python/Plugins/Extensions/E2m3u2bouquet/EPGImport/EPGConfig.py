# -*- coding: utf-8 -*-
from __future__ import division
import os
import gc
import sys
import gzip
import zipfile
import shutil
import time
import subprocess
import threading
from datetime import timedelta
from collections import defaultdict
from functools import wraps
try:
    from contextlib import suppress
except ImportError:
    from contextlib import contextmanager
    @contextmanager
    def suppress(*exceptions):
        try:
            yield
        except exceptions:
            pass
try:
    from itertools import compress
except ImportError:
    def compress(data, selectors):
        return (datum for datum, selector in zip(data, selectors) if selector)
try:
     from itertools import pairwise
except ImportError:  # Python < 3.10
     def pairwise(iterable):
         iterator = iter(iterable)
         a = next(iterator, None)
         for b in iterator:
             yield a, b
             a = b

from tempfile import SpooledTemporaryFile, gettempdir
from glob import glob
from .. import xml_unescape, isDreamOS, getMemInfo, medialist, isDreamOS
from ..log import logger
from ..modules.slugify import slugify
from ..modules.six import PY3
from ..modules.six.moves.urllib.parse import urlparse
from ..modules.six.moves.urllib.request import url2pathname
from ..modules.six.moves import filter
try:
    from lxml.etree import iterparse
except ImportError:
    if PY3:
        from xml.etree.ElementTree import iterparse
    else:
        try:
            from xml.etree.cElementTree import iterparse
        except ImportError:
            from xml.etree.ElementTree import iterparse
try:
    if PY3:
        import lzma
    else:
        from backports import lzma
    HAS_LZMA = True
except ImportError:
    try:
        import lzma
        HAS_LZMA = True
    except ImportError:
        lzma = None
        HAS_LZMA = False

from Components.config import config

FILE_SIGNATURES = [
    ('PNG',  [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], 0),   # PNG
    ('M3U',  [0x23, 0x45, 0x58, 0x54, 0x4d, 0x33, 0x55], 0),         # #EXTM3U
    ('M3U',  [0xef, 0xbb, 0xbf, 0x23, 0x45, 0x58, 0x54, 0x4d, 0x33, 0x55], 0), # UTF-8 BOM + #EXTM3U
    ('XML',  [0x3c, 0x3f, 0x78, 0x6d, 0x6c, 0x20], 0),               # XML
    ('GZIP', [0x1f, 0x8b], 0),                                       # GZIP
    ('XZ',   [0xfd, 0x37, 0x7a, 0x58, 0x5a, 0x00], 0),               # XZ
    ('ZIP',  [0x50, 0x4b, 0x03, 0x04], 0),                           # ZIP
    ('TAR',  [0x75, 0x73, 0x74, 0x61, 0x72], 257),                   # TAR
]

channelCache = {}
get_list = lambda elem, tag: [xml_unescape(e.text) for e in elem.findall(tag) if e.text]


def install_pkg(pkg_name):
    pkg_manager = "apt-get" if isDreamOS else "opkg"
    devnull = open(os.devnull, 'w')
    up_cmd = [pkg_manager, "update"] if not isDreamOS else [pkg_manager, "update", "-q"]
    subprocess.Popen(up_cmd, stdout=devnull, stderr=devnull, shell=False).wait()
    inst_cmd = [pkg_manager, "install", "-y", "-q", pkg_name] if isDreamOS else [pkg_manager, "install", "--force-depends", "--force-overwrite", pkg_name]
    subprocess.Popen(inst_cmd, stdout=devnull, stderr=devnull, shell=False).wait()
    devnull.close()


def _async_package_installer():
    global lzma, HAS_LZMA
    time.sleep(5.0)

    if PY3:
        pkg_name = "python3-lzma"
    else:
        pkg_name = "python-lzma" if not isDreamOS else "python-backports-lzma"

    logger.info("Missing LZMA dependency detected. Starting installation for %s ..." % pkg_name)

    try:
        install_pkg(pkg_name)
        try:
            if PY3:
                import lzma
                globals()['lzma'] = lzma
            else:
                from backports import lzma
                globals()['lzma'] = lzma
        except ImportError:
            try:
                import lzma
                globals()['lzma'] = lzma
            except ImportError:
                raise

        HAS_LZMA = True
        logger.info("Package %s successfully installed and loaded" % pkg_name)

    except Exception as err:
        logger.error("Package %s installation aborted. Error: %s" % (pkg_name, err))


def get_thread_target_name(thread_obj):
    if thread_obj is None:
        return "None"
    target_func = getattr(thread_obj, '_target', None)
    if target_func is None:
        return getattr(thread_obj, 'name', str(thread_obj))

    try:
        if hasattr(target_func, '__name__'):
            return str(target_func.__name__)
        if hasattr(target_func, 'im_func'):
            return str(target_func.im_func.__name__)
        if hasattr(target_func, 'func') and hasattr(target_func.func, '__name__'):
            return str(target_func.func.__name__)
    except Exception:
        pass
    return str(target_func)


def dispatch_package_installer(target):
    try:
        t = threading.Thread(target=target)
        t.daemon = True
        t.start()
    except Exception as thread_err:
        logger.error("Thread invocation for %s failed: %s" % (get_thread_target_name(target), thread_err))


if not HAS_LZMA:
    dispatch_package_installer(_async_package_installer)


def ram_guard_flush(f=None, dict_obj=None, threshold=50000, mem_limit_mb=25, sleep_time=1.0):
    """Flushes file buffer, calls getMemInfo directly, and executes emergency database dump
    utilizing clean object proxy if available system free memory drops below safe threshold.
    """
    if f is not None:
        try:
            f.flush()
        except Exception:
            pass

    free_ram_mb = 0
    try:
        mem_data = getMemInfo()
        free_ram_mb = int(mem_data['MemFree'].value) // 1024
    except Exception:
        try:
            free_ram_mb = int(mem_data['MemAvailable'].value) // 1024
        except Exception:
            free_ram_mb = 0

    if free_ram_mb < mem_limit_mb or free_ram_mb == 0:
        try:
            if dict_obj is not None and hasattr(dict_obj, 'flush_cache'):
                logger.warning("[RAM Guard]: MemFree critical: %d MB! Activating emergency storage flush..." % free_ram_mb)
                dict_obj.flush_cache(threshold=0)

            gc.collect()
            time.sleep(sleep_time)
        except Exception:
            pass


def get_histtimings():
    histseconds = 10800  # 3 hours ago
    timespan = int(time.time() + 86400 * 7)  # 7 days ahead
    try:
        histseconds = int(config.epg.histminutes.value) * 60
    except:
        with suppress(Exception):
            histseconds = int(config.misc.epgcache_outdated_timespan.value) * 3600
            timespan = int(time.time() + int(config.misc.epgcache_timespan.value) * 86400)
    return histseconds, timespan


def td2str(sec):
    try:
        safe_sec = max(0.0, float(sec))
        t = str(timedelta(seconds=safe_sec)).split('.')
        if len(t) > 1:
            return '%s.%s' % (t[0], t[1][:3])
        return '%s' % t[0]
    except Exception:
        return "0:00:00"


def isLocalFile(filename):
    if not filename:
        return False
    if not PY3:
        try:
            if isinstance(filename, unicode):
                filename = filename.encode('utf-8', errors='ignore')
        except Exception:
            pass
    try:
        url_parsed = urlparse(filename)
        if url_parsed.scheme in ('file', ''):
            if url_parsed.scheme == 'file':
                clean_path = url2pathname(url_parsed.path)
            else:
                clean_path = url_parsed.path
            if clean_path and os.path.exists(clean_path):
                return True
    except Exception:
        pass

    return False


def human_size(num, units=None):
    """A human readable string representation of bytes.
    """
    if units is None:
        units = [" bytes", " KB", " MB", " GB", " TB", " PB", " EB", " ZB", " YB"]
    try:
        num = int(num)
    except (TypeError, ValueError):
        return "0" + units[0]

    if num < 0:
        return "0" + units[0]

    for unit in units[:-1]:
        if num < 1024:
            return "%d%s" % (num, unit)
        num >>= 10

    return "%d%s" % (num, units[-1])


def bigStorage(minFree, default=None, *candidates):
    """Safely detects the storage mount with the maximum free space available.
    """
    def free_space_available(dirname):
        if not dirname or not os.path.isdir(dirname):
            return 0
        with suppress(Exception):
            st = os.statvfs(dirname)
            return st.f_bavail * st.f_frsize
        return 0

    if default is None:
        try:
            default = gettempdir()
        except:
            default = "/tmp"

    valid_candidates = [x for x in candidates if x and os.path.isdir(x)]
    valid_candidates.append(default)
    if "/tmp" not in valid_candidates:
        valid_candidates.append("/tmp")
    sorted_candidates = sorted(valid_candidates, key=free_space_available, reverse=True)
    candidate = sorted_candidates[0] if sorted_candidates else "/tmp"
    free = free_space_available(candidate)
    if free < minFree:
        logger.warning("[RAM Guard]: %s free space on %s is critically small" % (human_size(free), candidate))

    return candidate


def temp_spooled():
    """Safely initializes SpooledTemporaryFile with dynamic RAM calculation.
    """
    try:
        free_m = getMemInfo()['MemFree'].value * 1024
    except NameError:
        free_m = 32 * 1024 * 1024  # 32MB fallback

    logger.debug('[RAM Guard]: %s free RAM detected' % human_size(free_m))
    free_m = free_m // 4

    try:
        storage_dir = bigStorage(free_m, *medialist)
    except NameError:
        storage_dir = "/tmp"

    fd = SpooledTemporaryFile(max_size=free_m, dir=storage_dir, mode='w+b')
    if not PY3:
        fd.seekable = lambda: True
    return fd


def getChannels(path, name=None):
    """ Retrieves or initializes an EPGChannel from cache or calculates its path.
    """
    global channelCache
    if name and name in channelCache:
        return channelCache[name]
    dirname, filename = os.path.split(path)
    if name:
        if isLocalFile(name):
            name = os.path.join(dirname, name)
    else:
        base_name = filename.split('.', 1)[0]
        name = os.path.join(dirname, base_name + '.channels.xml')
    return channelCache.setdefault(name, EPGChannel(name))


def ftype_detect(func):
    """
    Attempts to detect file format from the content by converting chunk to byte integers.
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        first_arg = args[0]
        is_file_like = hasattr(first_arg, 'seek') and hasattr(first_arg, 'read')
        fd = first_arg if is_file_like else open(first_arg, "rb")
        raw_bs = fd.read(265)
        fd.seek(0)

        if PY3:
            bs = list(raw_bs)
        else:
            bs = [ord(c) for c in raw_bs] if isinstance(raw_bs, str) else list(raw_bs)

        ftype = None
        for name, signature, offset in FILE_SIGNATURES:
            sig_len = len(signature)
            chunk_slice = bs[offset : offset + sig_len]
            if chunk_slice == signature:
                ftype = name
                break

        return func(fd, ftype, *args[1:], **kwargs)
    return wrapper


def enumerateXML(fd, tag=None, events=('start', 'end')):
    """Enumerates ElementTree nodes from file object 'fd'"""
    try:    #LXML
        doc = iterparse(
            fd, events=events, encoding='utf-8', remove_blank_text=True, recover=True, huge_tree=True
        )
    except TypeError:    #XML
        doc = iterparse(fd, events=events)

    _, root = doc.__next__() if hasattr(doc, '__next__') else doc.next()

    msg = {'supplier': 'playlist configs', 'programme': 'events', 'channel': 'channel IDs', 'category': 'categories',
           'groupe': 'categories of channels', 'group': 'additional xmltv sources'}.get(tag, 'elements')

    is_lxml = hasattr(root, 'getparent')

    if is_lxml:
        def _clear(elem):
            if elem is not None:
                elem.clear()
                parent = elem.getparent()
                if parent is not None:
                    parent.remove(elem)
    else:
        def _clear(elem):
            if elem is not None:
                elem.clear()

    clear_el = _clear
    prev_1 = None
    prev_2 = None
    depth = count = 0
    last_logged_milestone = 0

    with Timer() as timer:
        for event, element in doc:

            if event == 'start':
                if tag is None or element.tag == tag:
                    if timer.counter % 20000 == 0 and timer.counter > 0:
                        logger.info("[XML parser]: Processed: {:,} {}".format(timer.counter, msg))

            elif event == 'end' and tag == 'channel' and count >= 300:
                break

            if tag is None:
                timer.counter += 1
                count = 0
                yield event, element

                if event == 'start':
                    depth += 1
                elif event == 'end':
                    depth -= 1
                    if depth == 0:
                        clear_el(element)
            else:
                if element.tag == tag:
                    if event == 'start':
                        depth += 1
                    elif event == 'end':
                        depth -= 1
                        if depth == 0:
                            timer.counter += 1
                            count = 0

                            clear_el(prev_2)
                            prev_2 = prev_1
                            prev_1 = element

                            yield element
                            continue

                count += 1

                if depth == 0 and event == 'end':
                     clear_el(element)

            if depth == 0:
                root.clear()

            count += 1

        clear_el(prev_1)
        clear_el(prev_2)
        root.clear()

        timer.msg = '[XML parser]: Total processed {:,} {} in {} or ~{:,.0f} per sec'.format(timer.counter, msg, td2str(timer.elapsed), timer.counter//timer.elapsed)


@ftype_detect
def openStream(fd, ftype=None):
    """Safely extracts GZIP, XZ, TAR, and ZIP. Looking for XML, M3U, PNG
    """
    try:
        logger.debug("Processing data type: %s" % str(ftype))

        if ftype == 'GZIP':
            fd = gzip.GzipFile(fileobj=fd, mode='rb')

        elif ftype == 'XZ':
            if not HAS_LZMA:
                raise Exception("python-lzma not found. XZ zipped EPG can't be imported")
            fd = lzma.LZMAFile(fd, 'rb')

        elif ftype == 'ZIP':
            zip_obj = zipfile.ZipFile(fd, 'r')
            members = zip_obj.infolist()
            if len(members) > 1:
                if next(filter(lambda x: x.filename.endswith(('.pdt', '.ndx')), members), None):
                    return zip_obj
                else:
                    zip_obj.close()
                    raise Exception("unsupported EPG file type")
            target_member = members.pop()
            fd_buffer = temp_spooled()
            shutil.copyfileobj(zip_obj.open(target_member), fd_buffer)
            fd_buffer.seek(0, 0)
            zip_obj.close()
            fd = fd_buffer

        elif ftype == 'TAR':
            try:
                import tarfile
            except ImportError:
                raise Exception("'%s' archives are not supported by the image used" % ftype)

            with tarfile.open(fileobj=fd, mode='r') as tar:
                members = tar.getmembers()
                if len(members) > 1:
                    raise Exception("'%s' archive must contain only one file" % ftype)
                else:
                    extracted_file = tar.extractfile(members.pop())
                    fd_buffer = temp_spooled()
                    shutil.copyfileobj(extracted_file, fd_buffer)
                    fd_buffer.seek(0, 0)
                    fd = fd_buffer

        elif ftype in ('XML', 'M3U', 'PNG'):
            return fd

        else:
            raise Exception("unsupported archive type or file content")
        return openStream(fd)

    except Exception as err:
        func_name = sys._getframe().f_code.co_name
        logger.error("[EPGConfig]: %s -> %s" % (func_name, err))
        return None


class Timer(object):
    """Universal non-blocking context manager for benchmarking parsing operations.
    """
    def __init__(self):
        self._msg = ''
        self._start = time.time()
        self._counter = 0

    def __enter__(self):
        self._start = time.time()
        self._counter = 0
        return self

    def __exit__(self, exc_type=None, exc_val=None, exc_tb=None):
        if self.msg:
            try:
                logger.info(self.msg)
            except  Exception as err:
                func_name = sys._getframe().f_code.co_name
                logger.error("[EPGConfig]: %s -> %s" % (func_name, err))

        self.close()
        return False

    def __del__(self):
        try:
            if hasattr(self, 'close') and callable(self.close):
                self.close()
        except Exception:
            pass

    @property
    def start(self):
        return self._start

    @start.setter
    def start(self, start):
        self._start = start

    @property
    def elapsed(self):
        return time.time() - self.start

    @property
    def msg(self):
        return self._msg

    @msg.setter
    def msg(self, msg):
        self._msg = msg

    @property
    def counter(self):
        return self._counter

    @counter.setter
    def counter(self, cnt):
        self._counter = cnt

    def close(self):
        """Called when exiting the context manager or when manually finishing."""
        pass


class EPGChannel(object):
    """Manages IPTV channel reference lookup tables for XMLTV EPG assignment.
    """
    def __init__(self, filename, urls=None):
        self.mtime = None
        self.name = filename
        self.urls = [filename] if urls is None else urls
        self.items = defaultdict(set)


    def update_channels(func):
        @wraps(func)
        def wrapper(self, fp=None):
            if fp is not None:
                self.mtime = time.time()
                return func(self, fp)
            elif len(self.urls) == 1 and isLocalFile(self.urls[0]):
                mtime = os.path.getmtime(self.urls[0])
                if (self.mtime is None) or (self.mtime < mtime):
                    self.mtime = mtime
                    with open(self.urls[0], "rb") as local_fd:
                        return func(self, local_fd)
        return wrapper


    @update_channels
    def parse(self, fp=None):
        """parse *****_channels.xml lookup table file securely without descriptor leakage."""
        self.items = defaultdict(set)
        fd = openStream(fp)
        if fd is None:
            return

        try:
            iterator = enumerateXML(fd, tag='channel')
            for elem in iterator:
                try:
                    channel_id = xml_unescape(elem.get('id', '')).lower()
                    service_ref = xml_unescape(elem.text or '')
                    if channel_id and service_ref:
                        self.items[channel_id].add(service_ref)
                except:
                    continue
        finally:
            if hasattr(fd, 'seek'):
                try: fd.seek(0)
                except: pass

    @property
    def downloadables(self):
        is_local = len(self.urls) == 1 and isLocalFile(self.urls[0])
        if not is_local:
            if (self.mtime is None) or (time.time() - self.mtime >= 3599):
                return self.urls
        return []

    def __repr__(self):
        items_count = len(self.items) if self.items else 0
        return "EPGChannel(urls=%s, channels=%d, mtime=%s)" % (self.urls, items_count, self.mtime)


class EPGSource(object):
    def __init__(self, sourcefile, elem, category=None):
        self.parser = elem.get('type', 'gen_xmltv')
        self.nocheck = int(elem.get('nocheck', 0))
        self.urls = get_list(elem, 'url')
        self.url = self.urls.pop()
        self.lang = xml_unescape(elem.findtext('lang')) or 'en_EN'
        self.parsing = int(elem.findtext('parsing') or '28')
        self.threads = int(elem.findtext('threads') or '5')
        self.epgoffset = int(elem.findtext('offset') or 0)
        self.description = xml_unescape(elem.findtext('description')) or self.url
        self.category = category
        self.channels = getChannels(sourcefile, elem.get('channels'))


def enumSourcesFile(sourcefile, categories=False):
    """ Parses XML source configuration files.
    """
    global channelCache
    category = None
    try:
        with openStream(sourcefile) as fd:
            for event, elem in enumerateXML(fd):
                if event == 'start':
                    if elem.tag == 'sourcecat':
                        category = xml_unescape(elem.get('sourcecatname') or '')
                        cat_parts = category.split('/')
                        log_name = cat_parts[1] if len(cat_parts) > 1 else cat_parts[0]
                        logger.info("[%s]: Parsing EPG data settings ..." % log_name)
                        if categories:
                            yield category

                elif event == 'end':
                    if elem.tag == 'source':
                        yield EPGSource(sourcefile, elem, category)
                    elif elem.tag == 'channel':
                        name = xml_unescape(elem.get('name') or '')
                        urls = get_list(elem, 'url')
                        channel = channelCache.setdefault(name, EPGChannel(name, urls))
                        channel.urls = urls

                    elif elem.tag == 'sourcecat':
                        category = None

    except Exception as err:
        func_name = sys._getframe().f_code.co_name
        logger.error("[EPGConfig]: %s -> %s" % (func_name, err))


def enumSources(path, filter, categories=False):
    """
    Enumerates sources from files matching specific filters.
    Preserves the original order of filters.
    """
    try:
        seen = set()
        for e in filter:
            if e in seen:
                continue
            seen.add(e)
            slug = slugify(e)
            pattern = os.path.join(path, '*' + slug + '.sources.*')
            for file in glob(pattern):
                for s in enumSourcesFile(file, categories):
                    yield s

    except Exception as err:
        func_name = sys._getframe().f_code.co_name
        logger.error("[EPGConfig]: %s -> %s" % (func_name, err))
