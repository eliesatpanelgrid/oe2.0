# -*- coding: utf-8 -*-
import sys
import time
import zlib
import json
from .. import isDreamOS, PluginLanguageDomain
from ..e2m3u2bouquet import url_validate, HEADERS, worker_init, worker
from ..log import logger
from ..modules.cache import lru_cache
from ..modules.six import iteritems
from ..modules.six.moves.urllib.parse import urlparse
from .EPGConfig import openStream, Timer, isLocalFile, temp_spooled, suppress
from twisted.internet import reactor, threads, ssl, defer
from twisted.internet.protocol import Protocol
from twisted.web.client import (Agent, BrowserLikeRedirectAgent, readBody, ResponseDone,
				ContentDecoderAgent, GzipDecoder, _GzipProtocol)
try:
	from twisted.web.client import BrowserLikePolicyForHTTPS as IgnoreHTTPSContextFactory
except ImportError:
	# for twisted < 14 backward compatibility
	from twisted.web.client import WebClientContextFactory as IgnoreHTTPSContextFactory
from twisted.web.http_headers import Headers
from twisted.python.failure import Failure
from functools import wraps
from collections import namedtuple
from base64 import b64encode
from Components.config import config


@lru_cache(maxsize=16)
def _load_parser_class_cached(parser_key, package_prefix):
	"""Internal helper that dynamically loads the parser class and caches it via LRU.
	"""
	name, cls = PARSERS[parser_key]
	module_full_path = package_prefix + name
	imported_module = __import__(module_full_path, fromlist=[cls])
	return getattr(imported_module, cls)


def getParser(source):
	"""Returns the required EPG parser class.
	"""
	parser_key = getattr(source, 'parser', None)
	if not parser_key:
		raise ValueError("EPGImport: Source parser config is empty")

	try:
		current_name = __name__
		dot_idx = current_name.rfind('.')
		package_prefix = current_name[:dot_idx + 1] if dot_idx != -1 else ''
		return _load_parser_class_cached(parser_key, package_prefix)

	except Exception as err:
		func_name = sys._getframe().f_code.co_name
		logger.error("EPGImport: %s -> %s" % (func_name, err))
		raise

def pop_default(input_list, index=-1, default_value=None):
	"""Safely pops an item from a list by index with a fallback default value.
	"""
	if not input_list or not hasattr(input_list, 'pop'):
		return default_value

	try:
		return input_list.pop(index)
	except IndexError:
		return default_value

# for twisted < 16.0 backward compatibility instead of standart addTimeout
def timeout(secs):
	"""Decorator to add timeout to Deferred calls.
	"""
	def wrap(func):
		@defer.inlineCallbacks
		@wraps(func)
		def _timeout(*args, **kwargs):
			raw_d = func(*args, **kwargs)
			if not isinstance(raw_d, defer.Deferred):
				defer.returnValue(raw_d)

			timeout_d = defer.Deferred()
			times_up = reactor.callLater(secs, timeout_d.callback, None)

			try:
				result_tuple = yield defer.DeferredList(
					[raw_d, timeout_d],
					fireOnOneCallback=True,
					fireOnOneErrback=True,
					consumeErrors=True
				)
			except defer.FirstError as e:
				times_up.cancel()
				e.subFailure.raiseException()
			else:
				if timeout_d.called:
					raw_d.cancel()
					raise Exception("downloadTimeout -> %s secs have expired" % secs)

				times_up.cancel()
				if isinstance(result_tuple, tuple):
					raw_result = result_tuple[0]
				elif isinstance(result_tuple, list) and len(result_tuple) > 0:
					raw_result = result_tuple[0][1]
				else:
					raw_result = None

				defer.returnValue(raw_result)

		return _timeout
	return wrap


class _Accumulator(Protocol):
	"""Accumulates streaming data into a spooled temporary file.
	"""
	def __init__(self, finished):
		self.finished = finished
		self.data = temp_spooled()

	def dataReceived(self, chunk):
		self.data.write(chunk)

	def connectionLost(self, failure):
		if failure.check(ResponseDone):
			self.data.seek(0, 0)
			self.finished.callback(openStream(self.data))
		else:
			if isinstance(failure, Failure):
				self.finished.errback(failure)
			else:
				self.finished.errback(Failure(failure))


class IgnoreHTTPS(IgnoreHTTPSContextFactory):
	def creatorForNetloc(self, hostname, port):
		try:
			return ssl.optionsForClientTLS(hostname.decode('utf-8'), trustRoot=None)
		except AttributeError:
			from twisted.internet import _sslverify
			options = ssl.CertificateOptions(verify=False)
			return _sslverify.ClientTLSOptions(hostname, options.getContext())


class _GzipDecoder(GzipDecoder):
	"""Custom Gzip decoder"""
	def deliverBody(self, protocol):
		body_receiver = GzipProtocol(protocol, self.original, 'gzip')
		self.original.deliverBody(body_receiver)


class _DeflateDecoder(GzipDecoder):
	"""Custom Deflate decoder"""
	def deliverBody(self, protocol):
		body_receiver = GzipProtocol(protocol, self.original, 'deflate')
		self.original.deliverBody(body_receiver)


class GzipProtocol(_GzipProtocol):
	"""Optimized streaming decompressor protocol for gzip/deflate.
	"""
	def __init__(self, protocol, response, enc):
		_GzipProtocol.__init__(self, protocol, response)
		self.original = protocol
		self._response = response
		if enc == 'gzip':
			self._zlibDecompress = zlib.decompressobj(zlib.MAX_WBITS | 16)
		elif enc == 'deflate':
			self._zlibDecompress = zlib.decompressobj(-zlib.MAX_WBITS)
		else:
			raise ValueError("Unsupported encoding: %s" % enc)


class _DummySource(object):
	"""A lightweight dummy object to bypass heavy namedtuple initialization.
	"""
	def __init__(self, parser_name):
		self.parser = parser_name

class OudeisImporter(object):
	"""Wrapper to convert original patch to new one that accepts multiple services.
	"""
	def __init__(self, epgcache):
		self.epgcache = epgcache

	def importEvents(self, services, events):
		if not services or not events:
			return

		cache = self.epgcache
		connection = getattr(cache, 'connection', None)

		if connection is not None:
			lock = getattr(cache, '_lock', None)
			if lock is None:
				import threading
				lock = threading.Lock()

			import_event_method = cache.importEvent
			with lock:
				with connection:
					for service in services:
						try:
							import_event_method(service, events)
						except Exception as cell_err:
							logger.debug("OudeisImporter cell skip: %s" % cell_err)
							continue
		else:
			import_event_method = cache.importEvent
			for service in services:
				import_event_method(service, events)


class EPGImport(object):
	"""Simple Class to import EPGData"""
	try:
		HDD_EPG_DAT = config.misc.epgcache_filename.value if hasattr(config.misc, 'epgcache_filename') else config.misc.epgcachefilename.value
	except:
		HDD_EPG_DAT = '/etc/enigma2/epg.db' if isDreamOS else '/etc/enigma2/epg.dat'

	def __init__(self, epgcache):
		self.epgcache = epgcache
		self.storage = None
		self.timer = Timer()
		self.sources = []
		self.source = None
		self.onDone = None
		self.pool, self.work, self.finished = [None]*3

	@timeout(6)
	def beginImport(self):
		d = agent.request(b'GET', b'https://pastebin.com/raw/2wRuJh8z', headers, None)
		d.addCallback(readBody)
		d.addErrback(lambda err: logger.warn("Failed to load ISO639 codes: %s" % err.getErrorMessage()))
		d.addCallback(self.start)
		return d

	def init_sql(self):
		"""Initializes the SQL EPG database backend and wraps it into OudeisImporter.
		"""
		try:
			dummy_source = _DummySource('sql')
			parser_class = getParser(dummy_source)
			epg_db_instance = parser_class(PluginLanguageDomain, 99, self.HDD_EPG_DAT)
			return OudeisImporter(epg_db_instance)
		except Exception as err:
			func_name = sys._getframe().f_code.co_name
			logger.error("EPGImport: %s -> %s" % (func_name, err))
			return None

	def cacheStateChanged(self, state):
		"""0 = started, 1 = stopped, 2 = aborted, 3 = deferred, 4 = load_finished, 5 = save_finished"""
		if state.state == 4:
			if self.timer:
				self.timer.__exit__()
			self.storage = None
			self.source = None
			if self.onDone:
				self.onDone(reboot=False, epgfile=None)
		elif state.state == 5:
			self.storage = self.init_sql()
			if self.storage is None:
				self.finish()
				return
			self.nextImport()

	def saveEPGCache(self):
		logger.info("Saving the eEPGCache into %s ..." % self.HDD_EPG_DAT)
		self.epgcache.save()

	def start(self, data=None):
		global ISO639
		with suppress(Exception):
			ISO639 = {x["alpha2"]:x["alpha3-b"] for x in json.loads(data)}
		self.timer.counter = 0
		self.timer.start = time.time()
		attr = dir(self.epgcache)
		if not all(p in attr for p in ('save', 'load')) and (any('ImportEvent' in x for x in attr) if not isDreamOS else True):
			logger.error("EPG import is not possible. The E2 image being used does not have all the needed eEPGCache methods")
			self.finish()
			return
		elif isDreamOS:
			logger.info("DreamOS detected ...")
			self.cacheState_conn = self.epgcache.cacheState.connect(self.cacheStateChanged)
			if not config.plugins.e2m3u2b.epg_flush.value:
				self.saveEPGCache()
				return
			else:
				self.storage = self.init_sql()
				if self.storage is None:
					self.finish()
					return

		elif 'importEvents' in attr:
			self.storage = self.epgcache
		elif 'importEvent' in attr:
			self.storage = OudeisImporter(self.epgcache)

		if config.plugins.e2m3u2b.epg_flush.value and (hasattr(self.epgcache, 'flushEPG') or isDreamOS):
			logger.info("Clearing the EPG %s..." % self.HDD_EPG_DAT)
			if isDreamOS:
				self.storage.epgcache.flushEPG()
			else:
				self.epgcache.flushEPG()

		self.nextImport()


	def _finalize_import(self):
		"""Internal helper to safely finalize the database and finish the import process.
		"""
		if isDreamOS:
			storage = getattr(self, 'storage', None)
			if storage and hasattr(storage, 'epgcache'):
				storage.epgcache.finish_db()
		self.finish()


	def nextImport(self, failure=None):
		"""Dispatches the next EPG source in the queue.
		"""
		msg = "EPG data processing has"
		if failure:
			if hasattr(self, 'finished') and self.finished is not None:
				self.finished.set()
			if hasattr(self, 'pool') and self.pool is not None:
				self.pool.shutdown()
			source_desc = self.source.description if hasattr(self, 'source') else 'Unknown'
			logger.info("[%s]: %s finished" % (source_desc, msg))

		try:
			self.source = self.sources.pop()
			self.pool, self.work, self.finished = worker_init(
				worker,
				self.importEvents,
				self.source.threads
				)
			self.channelFiles = self.source.channels.downloadables

		except IndexError:
			self._finalize_import()

		except Exception as err:
			func_name = sys._getframe().f_code.co_name
			logger.debug("EPGImport: %s -> %s" % (func_name, err))
			self._finalize_import()
		else:
			logger.info("[%s]: %s started" % (self.source.description, msg))
			self.doDownload(pop_default(self.channelFiles)).addCallbacks(self.afterChannelDownload, self.channelDownloadFail)


	def afterChannelDownload(self, data=None):
		"""Callback triggered after successful EPG channel file download.
		"""
		source_desc = self.source.description
		msg_type = 'Channel table'

		try:
			logger.info("[%s]: %s processing ..." % (source_desc, msg_type))
			self.source.channels.parse(data)
		except Exception as err:
			self.channelDownloadFail(Failure(err))
		else:
			channels_count = len(self.source.channels.items)
			logger.info("[{}]: {} for {:,} id has been formed".format(source_desc, msg_type, channels_count))
			self.doDownload(self.source.url).addCallbacks(self.afterDownload, self.downloadFail)
		finally:
			if data is not None and hasattr(data, 'close'):
				data.close()

	def afterDownload(self, data=None):
		"""Callback triggered after successful EPG events file download.
		"""
		if data is None:
			self.downloadFail(Failure(Exception("No EPG data received")))
			return

		source = self.source

		logger.info('[{0}]: Import of EPG events has been started ({1} threads using) ...'.format(
			getattr(source, 'description', 'Unknown'),
			getattr(source, 'threads', 1)
			))

		try:
			parser = getParser(source)
			epg_generator = parser.enumFile(data, source)
			threads.deferToThread(self.doThreadRead, epg_generator).addCallbacks(self.nextImport, self.downloadFail)

		except Exception as err:
			with suppress(Exception):
				data.close()
			self.downloadFail(Failure(err))


	def importEvents(self, data):
		"""Imports single channel data pack into storage
		"""
		try:
			self.storage.importEvents(*data)
			if len(data) > 1 and hasattr(data[1], '__len__'):
				self.timer.counter += len(data[1])
		except Exception as err:
			func_name = sys._getframe().f_code.co_name
			logger.error("EPGImport: %s -> %s" % (func_name, err))
		finally:
			with suppress(Exception):
				del data


	def doThreadRead(self, it):
		""" Background thread worker
		"""
		local_work = self.work
		max_threads = int(getattr(self.source, 'threads', 4))
		append = local_work.appendleft

		while True:
			while len(local_work) >= max_threads:
				time.sleep(0.002)
			try:
				channel_data = next(it)
				if channel_data is not None:
					append(channel_data)
			except StopIteration:
				return True
			except Exception as err:
            			raise


	def channelDownloadFail(self, failure):
		"""Handles failures during channels table download and tries alternatives.
		"""
		source_desc = getattr(self.source, 'description', 'Unknown')
		error_msg = failure.getErrorMessage() if hasattr(failure, 'getErrorMessage') else str(failure)
		logger.warn("[%s]: Channels table process failed: %s" % (source_desc, error_msg))
		if hasattr(failure, 'getTraceback'):
			logger.debug('%s' % failure.getTraceback())

		msg_label = "alternatives for the channels table"
		try:
			logger.info("[%s]: Attempting %s" % (source_desc, msg_label))
			self.doDownload(self.channelFiles.pop()).addCallbacks(self.afterChannelDownload, self.channelDownloadFail)
		except IndexError:
			logger.info("[%s]: No more %s" % (source_desc, msg_label))
			self.nextImport(failure)


	def downloadFail(self, failure):
		"""Handles failures during EPG events download and tries alternative source URLs.
		"""
		source_desc = getattr(self.source, 'description', 'Unknown')
		error_msg = failure.getErrorMessage() if hasattr(failure, 'getErrorMessage') else str(failure)
		logger.warn("[%s]: Processed EPG failed: %s" % (source_desc, error_msg))
		if hasattr(failure, 'getTraceback'):
			logger.debug('%s' % failure.getTraceback())

		msg_label = "alternative url's for EPG"
		try:
			logger.info("[%s]: Attempting %s" % (source_desc, msg_label))
			self.doDownload(self.source.urls.pop()).addCallbacks(self.afterDownload, self.downloadFail)
		except IndexError:
			logger.info("[%s]: No more %s" % (source_desc, msg_label))
			self.nextImport(failure)


	def finish(self):
		if self.timer.counter:
			if isDreamOS:
				logger.info("Loading the %s into eEPGCache ..." % self.HDD_EPG_DAT)
				self.epgcache.load()
			else:
				self.saveEPGCache()

			self.timer.msg = 'Total imported {:,} events in {}'.format(self.timer.counter, time.strftime("%H:%M:%S", time.gmtime(self.timer.elapsed)))
		else:
			logger.info('#### No events to import! ####')
			if isDreamOS:
				self.cacheStateChanged(namedtuple('state', 'state')(4))
		if not isDreamOS:
			self.cacheStateChanged(namedtuple('state', 'state')(4))

	@property
	def eventCount(self):
		return self.timer.counter

	@property
	def isImportRunning(self):
		return self.source is not None


	@timeout(int(config.plugins.e2m3u2b.download_timeout.value))
	@defer.inlineCallbacks
	def doDownload(self, link):
		"""Downloads EPG data from remote link or opens a local file.
		"""
		if not link:
			defer.returnValue(None)
		logger.info("[%s]: Fetching EPG data: %s" % (self.source.description, link))
		if not (url_validate(link) or isLocalFile(link)):
			raise Exception("unsupported or not valid link -> %s" % link)
		parsed_url = urlparse(link)

		def callback(response):
			if response.code != 200:
				raise Exception("server response code received -> %s" % response.code)
			finished = defer.Deferred()
			response.deliverBody(_Accumulator(finished))
			return finished

		if isLocalFile(link):
			stream = openStream(parsed_url.path)
			defer.returnValue(stream)
		else:
			current_headers = headers.copy() if hasattr(headers, 'copy') else headers

			if "@" in parsed_url.netloc:
				auth, netloc = parsed_url.netloc.split('@', 1)
				link = parsed_url._replace(netloc=netloc).geturl()
				current_headers.removeHeader(b"authorization")
				auth_bytes = auth.encode('utf-8') if isinstance(auth, str) else auth
				b64_auth = b64encode(auth_bytes)
				current_headers.addRawHeader(b"authorization", b"Basic " + b64_auth)

			link_bytes = link.encode('utf-8') if isinstance(link, str) else link
			response = yield agent.request(b'GET', link_bytes, current_headers, None)
			result_stream = yield callback(response)
			defer.returnValue(result_stream)


ISO639 = {}
headers = Headers({k.encode('utf-8'):[v.encode('utf-8')] for k,v in iteritems(HEADERS)})

base_agent = Agent(
	reactor,
	connectTimeout=int(config.plugins.e2m3u2b.connection_timeout.value),
	contextFactory=IgnoreHTTPS()
)

redirect_agent = BrowserLikeRedirectAgent(base_agent)
agent = ContentDecoderAgent(
	redirect_agent,
		[
			(b'gzip', _GzipDecoder),
			(b'deflate', _DeflateDecoder)
		]
)

PARSERS = {
		'xmltv': ['xmltvconverter', 'XMLTVConverter'],
		'gen_xmltv': ['xmltvconverter', 'XMLTVConverter'],
		'jtv': ['jtvconverter', 'JTVConverter'],
		'gen_jtv': ['jtvconverter', 'JTVConverter'],
		'sql': ['epgdb', 'sql_epg'],
}
