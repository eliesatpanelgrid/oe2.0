'''
SPDX-License-Identifier: GPL-2.0
Copyright (C) 2020-present Dorik1972 aka Pepsik =)

Wrapper for DreamOS
Prevents a green screen crash when using any unused methods or attributes in skin.xml on DreamOS
'''

from __future__ import print_function
import skin
from Tools.LoadPixmap import LoadPixmap
from enigma import eSize, gPixmapPtr

class AttributeParser(object):
	def __init__(self, guiObject, desktop, scale=((1, 1), (1, 1))):
		self.guiObject = guiObject
		self.desktop = desktop
		self.scaleTuple = scale

	def applyOne(self, attrib, value):
		try:
			getattr(self, attrib)(value)
		except AttributeError:
			print("[Skin_Patcher] Attribute '%s' (with value of '%s') in object of type '%s' is not implemented!" % (attrib, value, self.guiObject.__class__.__name__))
		except skin.SkinError as err:
			print("[Skin_Patcher]  Error: %s" % str(err))
		except Exception:
			print("[Skin_Patcher] Attribute '%s' with wrong (or unknown) value '%s' in object of type '%s'!" % (attrib, value, self.guiObject.__class__.__name__))

	def font(self, value):
		self.guiObject.setFont(skin.parseFont(value, self.scaleTuple))

	def scrollbarWidth(self, value):
		 self.guiObject.setScrollbarWidth(int(value))

	def pixmap(self, value):
		self.guiObject.setPixmap(self.loadPixmap(value, self.desktop, self.guiObject.size().width(), self.guiObject.size().height()))

	@staticmethod
	def loadPixmap(path, desktop, width=0, height=0):
		option = path.find("#")
		if option != -1:
			path = path[:option]
		pixmap = LoadPixmap(path, desktop, None, eSize(width, height))
		if pixmap is None:
			raise SkinError("Pixmap file '%s' not found" % path)
		return pixmap or gPixmapPtr()


def _applySingleAttribute(fn):
	def _fn(*args):
		guiObject, desktop, attrib, value, scale = args
		if attrib in ('font', 'scrollbarWidth', 'pixmap'):
			return AttributeParser(guiObject, desktop, scale).applyOne(attrib, value)
		else:
			return fn(*args)
	return _fn


try:
	skin.applySingleAttribute = _applySingleAttribute(skin.applySingleAttribute)
except skin.SkinError as err:
	print('[Skin_Patcher] Error: skin.py of the used image has no attribute "applySingleAttribute"' % repr(err))
