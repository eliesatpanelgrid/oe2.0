import struct

class xxh32(object):
    """An optimized, dependency-free XXH32 hash object.
    """
    block_size = 16
    digest_size = 4
    name = "xxh32"

    _UNPACK_16B = struct.Struct('<4I').unpack_from
    _M32 = 0xFFFFFFFF

    def __init__(self, data=None, seed=0):
        if seed < 0 or seed > 0xFFFFFFFF:
            raise ValueError("Seed must be a 32-bit unsigned integer.")

        self._P1 = 0x9E3779B1
        self._P2 = 0x85EBCA77
        self._P3 = 0xC2B2AE3D
        self._P4 = 0x27D4EB2F
        self._P5 = 0x165667B1

        self._s0 = (seed + 0x9E3779B1 + 0x85EBCA77) & 0xFFFFFFFF
        self._s1 = (seed + 0x85EBCA77) & 0xFFFFFFFF
        self._s2 = seed & 0xFFFFFFFF
        self._s3 = (seed - 0x9E3779B1) & 0xFFFFFFFF

        self._total_length = 0
        self._buffer = b""

        if data is not None:
            self.update(data)

    def update(self, data):
        """Update the state of the hash object with new data."""
        if not data:
            return

        if not isinstance(data, (bytes, bytearray)):
            data = data.encode('utf-8') if hasattr(data, 'encode') else bytes(data)

        self._total_length += len(data)

        if self._buffer:
            data = self._buffer + data

        length = len(data)
        limit = length & ~15

        if limit > 0:
            s0, s1, s2, s3 = self._s0, self._s1, self._s2, self._s3
            p1, p2, mask32 = self._P1, self._P2, 0xFFFFFFFF
            unpack_16 = self._UNPACK_16B

            for offset in range(0, limit, 16):
                b0, b1, b2, b3 = unpack_16(data, offset)

                v0 = (s0 + b0 * p2) & mask32
                s0 = (((v0 << 13) | (v0 >> 19)) * p1) & mask32

                v1 = (s1 + b1 * p2) & mask32
                s1 = (((v1 << 13) | (v1 >> 19)) * p1) & mask32

                v2 = (s2 + b2 * p2) & mask32
                s2 = (((v2 << 13) | (v2 >> 19)) * p1) & mask32

                v3 = (s3 + b3 * p2) & mask32
                s3 = (((v3 << 13) | (v3 >> 19)) * p1) & mask32

            self._s0, self._s1, self._s2, self._s3 = s0, s1, s2, s3
            self._buffer = data[limit:]
        else:
            self._buffer = data

    def intdigest(self):
        """Return the hash digest as a 32-bit unsigned integer."""
        mask32 = 0xFFFFFFFF

        if self._total_length >= 16:
            v0, v1, v2, v3 = self._s0, self._s1, self._s2, self._s3
            output = (
                ((v0 << 1) | (v0 >> 31)) +
                ((v1 << 7) | (v1 >> 25)) +
                ((v2 << 12) | (v2 >> 20)) +
                ((v3 << 18) | (v3 >> 14))
            ) & mask32
        else:
            output = (self._s2 + self._P5) & mask32

        output = (output + self._total_length) & mask32

        buffer_len = len(self._buffer)
        if buffer_len > 0:
            offset = 0
            p1, p3, p4, p5 = self._P1, self._P3, self._P4, self._P5

            while offset <= buffer_len - 4:
                b = struct.unpack_from('<I', self._buffer, offset)[0]
                v = (output + b * p3) & mask32
                output = (((v << 17) | (v >> 15)) * p4) & mask32
                offset += 4

            if offset < buffer_len:
                remainder = self._buffer[offset:]

                bytes_iterator = (b if isinstance(b, int) else ord(b) for b in remainder)
                for b in bytes_iterator:
                    v = (output + b * p5) & mask32
                    output = (((v << 11) | (v >> 21)) * p1) & mask32

        output ^= output >> 15
        output = (output * self._P2) & mask32
        output ^= output >> 13
        output = (output * self._P3) & mask32
        output ^= output >> 16

        return output

    def digest(self):
        """Return the hash digest as a bytes object (Big-Endian)."""
        return struct.pack(">I", self.intdigest())

    def hexdigest(self):
        """Return the hash digest as a hexadecimal string."""
        return '{:08x}'.format(self.intdigest())

    def copy(self):
        """Return a clone of the hash object."""
        cp = self.__class__.__new__(self.__class__)
        cp._P1, cp._P2, cp._P3, cp._P4, cp._P5 = self._P1, self._P2, self._P3, self._P4, self._P5
        cp._s0, cp._s1, cp._s2, cp._s3 = self._s0, self._s1, self._s2, self._s3
        cp._total_length = self._total_length
        cp._buffer = self._buffer
        return cp
