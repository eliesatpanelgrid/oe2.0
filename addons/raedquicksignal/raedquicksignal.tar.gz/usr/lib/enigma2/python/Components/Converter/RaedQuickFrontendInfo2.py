#!/usr/bin/python
# -*- coding: utf-8 -*-
# by 2boom 2011-14
# last update 25.07.2026 by RAED

from Components.Converter.Converter import Converter
from Components.Element import cached

class RaedQuickFrontendInfo2(Converter, object):
	BER = 0
	SNR = 1
	AGC = 2
	LOCK = 3
	SNRdB = 4
	SLOT_NUMBER = 5
	TUNER_TYPE = 6
	SNR_ANALOG = 7
	AGC_ANALOG = 8

	def __init__(self, type):
		Converter.__init__(self, type)
		if type == "BER":
			self.type = self.BER
		elif type == "SNR":
			self.type = self.SNR
		elif type == "SNRdB":
			self.type = self.SNRdB
		elif type == "AGC":
			self.type = self.AGC
		elif type == "NUMBER":
			self.type = self.SLOT_NUMBER
		elif type == "TYPE":
			self.type = self.TUNER_TYPE
		elif type == "SNR_ANALOG":
			self.type = self.SNR_ANALOG
		elif type == "AGC_ANALOG":
			self.type = self.AGC_ANALOG
		else:
			self.type = self.LOCK

	def getAGC(self):
		agc = self.source.agc
		# Si2166D/Si2169D frontends report a small bogus non-zero AGC
		# value (seen: 89-124) instead of None, ignore it and fall
		# through to the SNR-based estimate below
		if agc and agc > 255:
			return agc

		# Some frontends do not expose signal strength through either
		# DTV_STAT_SIGNAL_STRENGTH or FE_READ_SIGNAL_STRENGTH.  Keep using
		# the driver's value when available and estimate a display value
		# from signal quality only as a fallback.
		snr = self.source.snr
		if not snr:
			return agc
		snr_percent = float(snr) * 100.0 / 65535.0
		if snr_percent < 35:
			agc_percent = snr_percent * 1.8
		elif snr_percent < 70:
			agc_percent = 63 + ((snr_percent - 35) * 0.8)
		else:
			agc_percent = 91 + ((snr_percent - 70) * 0.3)
		return int(round(min(100, agc_percent) * float(self.range) / 100.0))

	@cached
	def getText(self):
		assert self.type not in (self.LOCK, self.SLOT_NUMBER), "the text output of FrontendInfo cannot be used for lock info"
		percent = None
		if self.type == self.BER: # as count
			count = self.source.ber
			if count is not None:
				return str(count)
			else:
				return "N/A"
		elif self.type == self.AGC:
			percent = self.getAGC()
		elif self.type == self.SNR:
			percent = self.source.snr
		elif self.type == self.SNRdB:
			if self.source.snr_db is not None:
				# --- CHANGE IS HERE (from %3.01f to %3.02f) ---
				return "%3.02f dB" % (self.source.snr_db / 100.0)
			elif self.source.snr is not None: #fallback to normal SNR
				# --- AND HERE (from %3.01f to %3.02f) ---
				return "%3.02f dB" % (0.32 *((self.source.snr * 100) /65536.0) / 2)
		elif self.type == self.TUNER_TYPE:
			return self.source.frontend_type and self.frontend_type or "Unknown"
		if percent is None:
			return "N/A"
		return "%d %%" % (percent * 100 / 65536.0)

	@cached
	def getBool(self):
		assert self.type in (self.LOCK, self.BER), "the boolean output of FrontendInfo can only be used for lock or BER info"
		if self.type == self.LOCK:
			lock = self.source.lock
			if lock is None:
				lock = False
			return lock
		else:
			ber = self.source.ber
			if ber is None:
				ber = 0
			return ber > 0

	text = property(getText)

	boolean = property(getBool)

	@cached
	def getValue(self):
		assert self.type != self.LOCK, "the value/range output of FrontendInfo can not be used for lock info"
		_local = 0
		if self.type == self.AGC:
			return self.getAGC() or 0
		elif self.type == self.AGC_ANALOG:
			if self.getAGC() is None:
				return 50
			_local = int(((self.getAGC() * 60) / 65536.0) / 3)
			if _local < 10:
				return _local + 50
			elif _local >= 10:
				return _local - 10
		elif self.type == self.SNR:
			return self.source.snr or 0
		elif self.type == self.SNR_ANALOG:
			if self.source.snr is None:
				return 50
			_local = int(((self.source.snr * 60) / 65536.0) / 3)
			if _local < 10:
				return _local + 50
			elif _local >= 10:
				return _local - 10
		elif self.type == self.BER:
			if self.BER < self.range:
				return self.BER or 0
			else:
				return self.range
		elif self.type == self.TUNER_TYPE:
			type = self.source.frontend_type
			if type == 'DVB-S':
				return 0
			elif type == 'DVB-C':
				return 1
			elif type == 'DVB-T':
				return 2
			return -1
		elif self.type == self.SLOT_NUMBER:
			num = self.source.slot_number
			return num is None and -1 or num

	range = 65536
	value = property(getValue)
