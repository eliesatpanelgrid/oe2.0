# -*- coding: utf-8 -*-
#
#  BitrateMonitorProPixmapBar — pixmap fill bar renderer
#  =====================================================
#  Renders the skin-supplied pixmap (absolute path, e.g. the
#  bar_snr_fill.png / bar_agc_fill.png gradients) and CLIPS it
#  horizontally to the converter percentage — no stretching,
#  the gradient keeps its true proportions.
#
#  Skin usage:
#    <widget source="session.FrontendStatus"
#            render="BitrateMonitorProPixmapBar"
#            position="..." size="150,14"
#            pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BitrateMonitorPro/assets/bar_snr_fill.png"
#            alphatest="blend">
#      <convert type="FrontendInfo">SNR</convert>
#    </widget>
#
#  Author: Simokof
#  License: GPLv2
#

from enigma import ePixmap, eSize, loadPNG
from Components.Renderer.Renderer import Renderer


class BitrateMonitorProPixmapBar(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.pct = 0
        self.full_w = 0
        self.full_h = 0
        self.pixmap_ptr = None

    def postWidgetCreate(self, instance):
        try:
            w = instance.size().width()
            if w > self.full_w:
                self.full_w = w
                self.full_h = instance.size().height()
        except Exception:
            pass
        # Self-load the fill pixmap from our own skin attributes —
        # does NOT rely on skin.py applying "pixmap"/"alphatest" to
        # renderer widgets (not guaranteed on every image).
        if self.pixmap_ptr is None and getattr(self, "skinAttributes", None):
            for attr, value in self.skinAttributes:
                if attr == "pixmap":
                    try:
                        ptr = loadPNG(value)
                        if ptr:
                            self.pixmap_ptr = ptr
                            instance.setPixmap(ptr)
                            instance.setAlphatest(2)  # blend
                    except Exception:
                        pass
                    break

    def changed(self, what):
        if what[0] == self.CHANGED_CLEAR:
            self.pct = 0
        else:
            value = self.source.value or 0
            rng = self.source.range or 100
            self.pct = int(min(max(value, 0), rng) * 100 // rng) if rng else 0

        inst = self.instance
        if inst is None:
            return
        try:
            # widget may have been laid out after the first push — re-capture
            cur_w = inst.size().width()
            if cur_w > self.full_w:
                self.full_w = cur_w
                self.full_h = inst.size().height()
        except Exception:
            return
        if not self.full_w:
            return
        try:
            inst.resize(eSize(max(1, self.full_w * self.pct // 100), self.full_h))
        except Exception:
            pass
