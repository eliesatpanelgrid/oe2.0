# -*- coding: utf-8 -*-
#
#  BitrateMonitorPro — measurement engine as an Enigma2 Source
#  ==========================================================
#  Owns the DMX reader (every 200 ms), the statistics and the
#  service metadata, and PUBLISHES ready-to-render strings.
#  Skin widgets read them through the BitrateMonitorProInfo
#  converter — the screen never calls setText().
#
#  Same self-updating pattern as the stock FrontendStatus /
#  Clock sources: an internal eTimer drives everything and a
#  CHANGED_ALL push refreshes every connected renderer.
#
#  Author: Simokof
#  License: GPLv2
#

from Components.Sources.Source import Source
from enigma import eTimer, iServiceInformation
import os
import struct
import fcntl
import select
import time
import glob

# ─────────────────────────────────────────────────────────────
# DMX ioctl constants (Linux DVB API v5)
# ─────────────────────────────────────────────────────────────
DMX_START = 0x6f29
DMX_STOP = 0x6f2a
DMX_SET_BUFFER_SIZE = 0x6f2d

DMX_OUT_DECODER     = 0
DMX_OUT_TAP         = 1
DMX_OUT_TS_TAP      = 2
DMX_OUT_TSDEMUX_TAP = 3

DMX_IN_FRONTEND     = 0
DMX_PES_VIDEO0      = 0
DMX_PES_AUDIO0      = 1
DMX_PES_OTHER       = 20
DMX_IMMEDIATE_START = 0x04

_FILTER_STRUCT_FMT = 'HHiiii'
_FILTER_STRUCT_SIZE = struct.calcsize(_FILTER_STRUCT_FMT)

_IOC_WRITE = 1
DMX_SET_PES_FILTER = (_IOC_WRITE << 30) | (_FILTER_STRUCT_SIZE << 16) | (0x6f << 8) | 0x2c
DMX_SET_PES_FILTER_64 = (_IOC_WRITE << 30) | (40 << 16) | (0x6f << 8) | 0x2c
_FILTER_STRUCT_FMT_64 = 'H6xqqqi4x'

DMX_BUFFER_SIZES = [
    8 * 1024 * 1024,
    4 * 1024 * 1024,
    2 * 1024 * 1024,
    1 * 1024 * 1024,
    512 * 1024,
    256 * 1024,
]
READ_BUFFER_SIZE = 2 * 1024 * 1024

READ_INTERVAL_MS = 200
READS_PER_DISPLAY = 5          # 5 x 200ms = 1s display cycle
SELECT_TIMEOUT = 0.01

_OUTPUT_MODES = [DMX_OUT_TAP, DMX_OUT_TSDEMUX_TAP, DMX_OUT_TS_TAP]

VIDEO_CODEC_MAP = {
    -1: "N/A", 0: "MPEG2", 1: "H.264", 2: "MPEG1",
    3: "MPEG4-VC", 4: "VC1", 5: "VC1-SM", 6: "HEVC",
    7: "VP8", 8: "VP9", 9: "VVC", 10: "AV1",
}

AUDIO_CODEC_MAP = {
    -1: "N/A", 0: "MP2", 1: "AC3", 2: "DTS", 3: "AAC", 4: "AAC-HE",
    5: "E-AC3", 6: "AC4", 7: "WMA", 8: "LPCM", 9: "DRA", 10: "OPUS", 11: "MP3",
}


class BitrateMonitorPro(Source):
    """Self-updating bitrate monitor source (DMX engine + stats)."""

    def __init__(self, navcore):
        Source.__init__(self)
        self.navcore = navcore

        # ── published fields (read by the converter) ─────────
        self.video = "0 Kb/s"
        self.video_avg = "0 Kb/s"
        self.video_max = "0 Kb/s"
        self.video_min = "--- Kb/s"
        self.audio = "0 Kb/s"
        self.audio_avg = "0 Kb/s"
        self.audio_max = "0 Kb/s"
        self.audio_min = "--- Kb/s"
        self.total = "0 Kb/s"
        self.total_avg = "avg 0 Kb/s"
        self.samples = "0 samples | 0s"
        self.dmx = "Waiting..."
        self.dmx_ok = False
        self.video_info = "---"
        self.audio_codec = "---"
        self.lang = "---"
        self.band = "---"
        self.snr = "--%"
        self.agc = "--%"
        self.snr_value = 0
        self.agc_value = 0
        self._signal_probe = {"snr": -1, "agc": -1}

        # ── DMX state ────────────────────────────────────────
        self._video_fds = {}
        self._audio_fds = {}
        self._video_pid = -1
        self._audio_pid = -1
        self._dmx_info = ""

        # ── accumulation / statistics ────────────────────────
        self._video_bytes_acc = 0
        self._audio_bytes_acc = 0
        self._read_count = 0
        self._last_calc_time = time.time()
        self._video_total = 0
        self._audio_total = 0
        self._video_max_val = 0
        self._video_min_val = -1
        self._audio_max_val = 0
        self._audio_min_val = -1
        self._sample_count = 0
        self._start_time = time.time()

        # ── polling timer (the screen never touches it) ──────
        self.poll_timer = eTimer()
        self.poll_timer.callback.append(self.poll)
        self.poll_timer.start(READ_INTERVAL_MS, False)

    # ─────────────────────────────────────────────────────────
    # DMX engine
    # ─────────────────────────────────────────────────────────

    def _tryOpenDemux(self, demux_path, pid, output_mode, pes_type):
        fd = -1
        try:
            fd = os.open(demux_path, os.O_RDONLY | os.O_NONBLOCK)

            # Try progressively smaller buffer sizes
            buf_ok = False
            for buf_sz in DMX_BUFFER_SIZES:
                try:
                    fcntl.ioctl(fd, DMX_SET_BUFFER_SIZE, buf_sz)
                    buf_ok = True
                    break
                except OSError:
                    continue
            if not buf_ok:
                os.close(fd)
                return -1, ""

            ioctl_ok = False
            arch = "32-bit"
            method = ""

            # Attempt 1: 32-bit struct with IMMEDIATE_START
            try:
                params = struct.pack(
                    _FILTER_STRUCT_FMT,
                    pid, 0, DMX_IN_FRONTEND, output_mode, pes_type, DMX_IMMEDIATE_START,
                )
                fcntl.ioctl(fd, DMX_SET_PES_FILTER, params)
                ioctl_ok = True
                method = "32bit+IMM"
            except OSError:
                pass

            # Attempt 2: 64-bit struct with IMMEDIATE_START
            if not ioctl_ok:
                try:
                    params64 = struct.pack(
                        _FILTER_STRUCT_FMT_64,
                        pid, DMX_IN_FRONTEND, output_mode, pes_type, DMX_IMMEDIATE_START,
                    )
                    fcntl.ioctl(fd, DMX_SET_PES_FILTER_64, params64)
                    ioctl_ok = True
                    arch = "64-bit"
                    method = "64bit+IMM"
                except OSError:
                    pass

            # Attempt 3: 32-bit struct without IMMEDIATE_START + explicit START
            if not ioctl_ok:
                try:
                    params_no_flag = struct.pack(
                        _FILTER_STRUCT_FMT,
                        pid, 0, DMX_IN_FRONTEND, output_mode, pes_type, 0,
                    )
                    fcntl.ioctl(fd, DMX_SET_PES_FILTER, params_no_flag)
                    fcntl.ioctl(fd, DMX_START)
                    ioctl_ok = True
                    arch = "32-bit"
                    method = "32bit+START"
                except OSError:
                    pass

            # Attempt 4: 64-bit struct without IMMEDIATE_START + explicit START
            if not ioctl_ok:
                try:
                    params64_no_flag = struct.pack(
                        _FILTER_STRUCT_FMT_64,
                        pid, DMX_IN_FRONTEND, output_mode, pes_type, 0,
                    )
                    fcntl.ioctl(fd, DMX_SET_PES_FILTER_64, params64_no_flag)
                    fcntl.ioctl(fd, DMX_START)
                    ioctl_ok = True
                    arch = "64-bit"
                    method = "64bit+START"
                except OSError:
                    pass

            if ioctl_ok:
                out_name = {0: "DECODER", 1: "TAP", 2: "TS_TAP", 3: "TSDEMUX_TAP"}.get(output_mode, str(output_mode))
                pes_name = {0: "VID0", 1: "AUD0", 20: "OTHER"}.get(pes_type, str(pes_type))
                return fd, f"{os.path.basename(demux_path)} | {out_name} | {pes_name} | {arch} | {method}"

            os.close(fd)
            return -1, ""
        except Exception:
            if fd >= 0:
                try:
                    os.close(fd)
                except Exception:
                    pass
            return -1, ""

    def _openDemuxAll(self, pid, pes_type=DMX_PES_OTHER):
        opened = {}
        # Primary: standard DVB demux paths
        paths = sorted(glob.glob("/dev/dvb/adapter*/demux*"))
        # Fallback: legacy/alternative demux naming
        if not paths:
            paths = sorted(glob.glob("/dev/demux*"))
        if not paths:
            paths = sorted(glob.glob("/dev/dvb/adapter*/dvr*"))
        if not paths:
            return opened

        # PES type fallback chain: OTHER first (universal), then specific
        # On Egami, AUDIO0/VIDEO0 may open but get no data; OTHER always works
        if pes_type == DMX_PES_OTHER:
            pes_types = [DMX_PES_OTHER]
        else:
            pes_types = [DMX_PES_OTHER, pes_type]

        for path in paths:
            if not os.path.exists(path):
                continue
            for pt in pes_types:
                for mode in _OUTPUT_MODES:
                    fd, info = self._tryOpenDemux(path, pid, mode, pt)
                    if fd >= 0:
                        opened[fd] = info
                        break  # mode
                if opened:
                    break  # pes_type
            if opened:
                break  # path
        return opened

    def _closeFd(self, fd):
        if fd >= 0:
            try:
                fcntl.ioctl(fd, DMX_STOP)
            except Exception:
                pass
            try:
                os.close(fd)
            except Exception:
                pass

    def _closeAllDemux(self):
        for fd in self._video_fds:
            self._closeFd(fd)
        for fd in self._audio_fds:
            self._closeFd(fd)
        self._video_fds = {}
        self._audio_fds = {}
        self._video_pid = -1
        self._audio_pid = -1

    def _drainFds(self, fds_dict):
        if not fds_dict:
            return 0, -1
        total = 0
        active_fd = -1
        try:
            ready, _, _ = select.select(list(fds_dict.keys()), [], [], SELECT_TIMEOUT)
            for fd in ready:
                fd_bytes = 0
                while True:
                    try:
                        chunk = os.read(fd, READ_BUFFER_SIZE)
                        if not chunk:
                            break
                        fd_bytes += len(chunk)
                        if len(chunk) < READ_BUFFER_SIZE:
                            break
                    except (BlockingIOError, OSError):
                        break
                if fd_bytes > 0:
                    total += fd_bytes
                    if active_fd < 0:
                        active_fd = fd
        except Exception:
            pass
        return total, active_fd

    def _pruneInactiveFds(self, fds_dict, active_fd, dmx_info_ref):
        if active_fd < 0 or len(fds_dict) <= 1:
            return dmx_info_ref
        for fd in [fd for fd in fds_dict if fd != active_fd]:
            self._closeFd(fd)
        active_info = fds_dict.get(active_fd, "")
        fds_dict.clear()
        fds_dict[active_fd] = active_info
        return active_info

    # ─────────────────────────────────────────────────────────
    # Service metadata (published fields)
    # ─────────────────────────────────────────────────────────

    @staticmethod
    def _infoStr(info, attr):
        try:
            key = getattr(iServiceInformation, attr, None)
            if key is None:
                return ""
            return info.getInfoString(key) or ""
        except Exception:
            return ""

    def _getAudioPidFallback(self, service, info):
        """Try alternative methods to get the audio PID when sAudioPID returns -1.
        This happens on some images (Egami) for encrypted channels."""
        # Method 1: getInfoString as integer
        try:
            apid_str = info.getInfoString(iServiceInformation.sAudioPID)
            if apid_str and apid_str.isdigit():
                val = int(apid_str)
                if val > 0:
                    return val
        except Exception:
            pass

        # Method 2: audioTracks() interface → getPID()
        try:
            audio = service.audioTracks()
            if audio and audio.getNumberOfTracks() > 0:
                current = audio.getCurrentTrack()
                if current >= 0:
                    track = audio.getTrackInfo(current)
                    # Try getPID() if available (some images)
                    try:
                        pid = track.getPID()
                        if pid and pid > 0:
                            return pid
                    except Exception:
                        pass
        except Exception:
            pass

        # Method 3: Parse PMT via section filter (raw TS read)
        try:
            pmt_pid = info.getInfo(iServiceInformation.sPMTPID)
            if pmt_pid and pmt_pid > 0:
                pid = self._parsePmtForAudioPid(pmt_pid)
                if pid > 0:
                    return pid
        except Exception:
            pass

        # Method 4: Read from /proc/stb if available
        try:
            for f in ("/proc/stb/audio/apid", "/proc/stb/vmpeg/0/apid"):
                if os.path.exists(f):
                    val = int(open(f).read().strip())
                    if val > 0:
                        return val
        except Exception:
            pass

        return -1

    def _parsePmtForAudioPid(self, pmt_pid):
        """Try to read PMT section and extract first audio PID.
        Uses DVR device for raw TS, then parses PMT."""
        try:
            # Try reading raw TS from DVR device on the PMT PID
            # We use PES filter with DMX_OUT_TAP on PMT PID
            paths = sorted(glob.glob("/dev/dvb/adapter*/demux*"))
            audio_types = (0x03, 0x04, 0x0F, 0x11, 0x81, 0x83, 0x84, 0x87, 0xAC)
            for path in paths:
                fd = -1
                try:
                    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
                    try:
                        fcntl.ioctl(fd, DMX_SET_BUFFER_SIZE, 2 * 1024 * 1024)
                    except OSError:
                        pass
                    params = struct.pack(
                        _FILTER_STRUCT_FMT,
                        pmt_pid, 0, DMX_IN_FRONTEND,
                        DMX_OUT_TS_TAP, DMX_PES_OTHER, DMX_IMMEDIATE_START,
                    )
                    try:
                        fcntl.ioctl(fd, DMX_SET_PES_FILTER, params)
                    except OSError:
                        try:
                            fcntl.ioctl(fd, DMX_SET_PES_FILTER_64, struct.pack(
                                _FILTER_STRUCT_FMT_64,
                                pmt_pid, DMX_IN_FRONTEND,
                                DMX_OUT_TS_TAP, DMX_PES_OTHER, DMX_IMMEDIATE_START,
                            ))
                        except OSError:
                            os.close(fd)
                            continue
                    # Wait and read
                    import select as _sel
                    _sel.select([fd], [], [], 1.0)
                    data = b""
                    for _ in range(10):
                        try:
                            chunk = os.read(fd, 65536)
                            if not chunk:
                                break
                            data += chunk
                            if len(data) > 131072:
                                break
                        except (BlockingIOError, OSError):
                            break
                    fcntl.ioctl(fd, DMX_STOP)
                    os.close(fd)
                    # Parse PMT in the raw data
                    if len(data) > 12:
                        for offset in range(len(data) - 12):
                            if data[offset] != 0x02:
                                continue
                            section_len = ((data[offset + 1] & 0x0F) << 8) | data[offset + 2]
                            if section_len < 9 or section_len > 1021:
                                continue
                            section = data[offset:offset + section_len + 3]
                            if len(section) < section_len + 3:
                                continue
                            prog_info_len = ((section[10] & 0x0F) << 8) | section[11]
                            pos = 12 + prog_info_len
                            while pos + 5 <= len(section):
                                stream_type = section[pos]
                                es_pid = ((section[pos + 1] & 0x1F) << 8) | section[pos + 2]
                                es_info_len = ((section[pos + 3] & 0x0F) << 8) | section[pos + 4]
                                if stream_type in audio_types and es_pid > 0:
                                    return es_pid
                                pos += 5 + es_info_len
                except Exception:
                    if fd >= 0:
                        try:
                            os.close(fd)
                        except Exception:
                            pass
        except Exception:
            pass
        return -1

    def _updateBand(self, service):
        freq = 0
        try:
            feinfo = service.frontendInfo()
            tp = (feinfo.getTransponderData(True) or {}) if feinfo else {}
            freq = int(tp.get("frequency") or 0)
        except Exception:
            freq = 0
        if freq > 50000:
            freq //= 1000
        if 3400 <= freq < 7000:
            self.band = "C"
        elif 10700 <= freq <= 13400:
            self.band = "Ku"
        elif freq > 13400:
            self.band = "Ka"
        else:
            self.band = "---"

    def _updateServiceInfo(self, service):
        """Refresh metadata fields. Returns (vpid, apid)."""
        if not service:
            self.video_info = "---"
            self.audio_codec = "---"
            self.lang = "---"
            self.band = "---"
            return -1, -1

        info = service.info()
        if not info:
            self.video_info = "---"
            self.audio_codec = "---"
            return -1, -1

        vpid = info.getInfo(iServiceInformation.sVideoPID)
        apid = info.getInfo(iServiceInformation.sAudioPID)
        vpid = vpid if vpid and vpid > 0 else -1
        apid = apid if apid and apid > 0 else -1

        # ── Fallback: get audio PID from alternative sources ──
        # On some images (Egami), sAudioPID returns -1 for encrypted
        # channels even though audio is playing. Try alternatives.
        if apid <= 0:
            apid = self._getAudioPidFallback(service, info)

        xres = info.getInfo(iServiceInformation.sVideoWidth)
        yres = info.getInfo(iServiceInformation.sVideoHeight)
        fps_val = info.getInfo(iServiceInformation.sFrameRate)
        try:
            codec_val = info.getInfo(iServiceInformation.sVideoType)
            vcodec = VIDEO_CODEC_MAP.get(codec_val, f"Type {codec_val}")
        except Exception:
            vcodec = "N/A"
        xres = xres if xres and xres > 0 else 0
        yres = yres if yres and yres > 0 else 0
        fps = (fps_val // 1000) if fps_val and fps_val > 0 else 0
        if xres > 0 and yres > 0:
            self.video_info = f"{vcodec} {xres}x{yres}" + (f"@{fps}" if fps > 0 else "")
        else:
            self.video_info = vcodec

        try:
            acodec_val = info.getInfo(iServiceInformation.sAudioType)
            acodec = AUDIO_CODEC_MAP.get(acodec_val, "")
        except Exception:
            acodec = ""
        if not acodec:
            acodec = self._infoStr(info, "sAudioType") or ""
        self.audio_codec = acodec if acodec and acodec != "N/A" else "---"

        self.lang = self._infoStr(info, "sAudioLang") or "---"
        self._updateBand(service)
        return vpid, apid

    # ─────────────────────────────────────────────────────────
    # SNR / AGC — 3-source fallback (method / dict / proc)
    # ─────────────────────────────────────────────────────────

    def _sigMethod(self, service, kind):
        fe = service.frontendInfo()
        m = getattr(fe, "getSNR" if kind == "snr" else "getAGC", None)
        return int(m()) if m else 0

    def _sigDict(self, service, kind):
        fe = service.frontendInfo()
        d = fe.getFrontendInfo()
        if isinstance(d, dict):
            for key in ("snr_percentage", "agc_percentage"):
                if key.startswith(kind):
                    v = d.get(key)
                    if isinstance(v, (int, float)):
                        return int(v)
        return 0

    def _sigProc(self, service, kind):
        for fe_dir in sorted(glob.glob("/proc/stb/frontend/*")):
            path = os.path.join(fe_dir, kind)
            if os.path.exists(path):
                raw = open(path).read().strip()
                for base in (10, 16):
                    try:
                        return int(raw, base)
                    except ValueError:
                        continue
        return 0

    @staticmethod
    def _scalePct(val):
        if val <= 0:
            return 0
        if val <= 100:
            return val
        if val <= 65535:
            return val * 100 // 65535
        return 100

    def _readSignal(self, service, kind):
        """Sticks with the first source that yields a value."""
        probes = (self._sigMethod, self._sigDict, self._sigProc)
        idx = self._signal_probe.get(kind, -1)
        if 0 <= idx < len(probes):
            try:
                val = probes[idx](service, kind)
            except Exception:
                val = 0
            if val > 0:
                return val
            self._signal_probe[kind] = -1
        for i, fn in enumerate(probes):
            try:
                val = fn(service, kind)
            except Exception:
                continue
            if val > 0:
                self._signal_probe[kind] = i
                return val
        return 0

    def _updateSignal(self, service):
        if not service:
            self.snr = "--%"
            self.agc = "--%"
            self.snr_value = 0
            self.agc_value = 0
            return
        self.snr_value = self._scalePct(self._readSignal(service, "snr"))
        self.agc_value = self._scalePct(self._readSignal(service, "agc"))
        self.snr = f"{self.snr_value}%"
        self.agc = f"{self.agc_value}%"

    # ─────────────────────────────────────────────────────────
    # Main loop (200 ms) — engine + 1 s publish
    # ─────────────────────────────────────────────────────────

    def poll(self):
        service = self.navcore.getCurrentService()
        vpid, apid = self._updateServiceInfo(service)

        if vpid != self._video_pid:
            for fd in list(self._video_fds.keys()):
                self._closeFd(fd)
            self._video_pid = vpid
            self._video_bytes_acc = 0
            self._video_fds = self._openDemuxAll(vpid, DMX_PES_VIDEO0) if vpid > 0 else {}

        if apid != self._audio_pid:
            for fd in list(self._audio_fds.keys()):
                self._closeFd(fd)
            self._audio_pid = apid
            self._audio_bytes_acc = 0
            self._audio_fds = self._openDemuxAll(apid, DMX_PES_AUDIO0) if apid > 0 else {}

        v_bytes, v_active = self._drainFds(self._video_fds)
        self._video_bytes_acc += v_bytes
        if v_active >= 0 and len(self._video_fds) > 1:
            self._dmx_info = self._pruneInactiveFds(self._video_fds, v_active, self._dmx_info)

        a_bytes, a_active = self._drainFds(self._audio_fds)
        self._audio_bytes_acc += a_bytes
        if a_active >= 0 and len(self._audio_fds) > 1:
            dmx = self._pruneInactiveFds(self._audio_fds, a_active, self._dmx_info)
            if not self._video_fds:
                self._dmx_info = dmx

        if not self._video_fds and not self._audio_fds:
            self._dmx_info = "DMX FAIL"
            self.dmx_ok = False
        else:
            self.dmx_ok = True
        self.dmx = self._dmx_info or "Waiting..."
        self._updateSignal(service)

        self._read_count += 1
        if self._read_count >= READS_PER_DISPLAY:
            now = time.time()
            elapsed = now - self._last_calc_time
            self._last_calc_time = now
            if elapsed <= 0:
                elapsed = 1.0
            elif elapsed < 0.2:
                elapsed = 0.2

            vbr = self._video_bytes_acc / elapsed * 8   # bytes → bits/s
            abr = self._audio_bytes_acc / elapsed * 8
            self._video_bytes_acc = 0
            self._audio_bytes_acc = 0
            self._read_count = 0
            self._publish(vbr, abr)

    # ─────────────────────────────────────────────────────────
    # Publishing
    # ─────────────────────────────────────────────────────────

    @staticmethod
    def _format_kb(kb_val):
        return f"{kb_val:,} Kb/s"

    @staticmethod
    def _format_total(kb_val):
        # 1 Mb/s threshold — total stays in Mb/s (no format flicker around 10k)
        if kb_val >= 1000:
            return f"{kb_val / 1000:.1f} Mb/s"
        return f"{kb_val:,} Kb/s"

    def _publish(self, vbr, abr):
        vkb = int(vbr / 1000)
        akb = int(abr / 1000)

        self._sample_count += 1
        self._video_total += vkb
        self._audio_total += akb
        if vkb > self._video_max_val:
            self._video_max_val = vkb
        if self._video_min_val < 0 or (vkb < self._video_min_val and vkb > 0):
            self._video_min_val = vkb
        if akb > self._audio_max_val:
            self._audio_max_val = akb
        if self._audio_min_val < 0 or (akb < self._audio_min_val and akb > 0):
            self._audio_min_val = akb

        v_avg = self._video_total // self._sample_count
        a_avg = self._audio_total // self._sample_count

        self.video = self._format_kb(vkb)
        self.video_avg = self._format_kb(v_avg)
        self.video_max = self._format_kb(self._video_max_val)
        self.video_min = self._format_kb(self._video_min_val) if self._video_min_val >= 0 else "--- Kb/s"
        self.audio = self._format_kb(akb)
        self.audio_avg = self._format_kb(a_avg)
        self.audio_max = self._format_kb(self._audio_max_val)
        self.audio_min = self._format_kb(self._audio_min_val) if self._audio_min_val >= 0 else "--- Kb/s"
        self.total = self._format_total(vkb + akb)
        self.total_avg = f"avg {self._format_total(v_avg + a_avg)}"

        elapsed_total = int(time.time() - self._start_time)
        mins, secs = divmod(elapsed_total, 60)
        time_str = f"{mins}m {secs}s" if mins > 0 else f"{secs}s"
        self.samples = f"{self._sample_count} samples | {time_str}"

        self.changed((self.CHANGED_ALL,))

    # ─────────────────────────────────────────────────────────
    # Public API (OK key) + teardown
    # ─────────────────────────────────────────────────────────

    def resetStats(self):
        self._video_total = 0
        self._audio_total = 0
        self._video_max_val = 0
        self._video_min_val = -1
        self._audio_max_val = 0
        self._audio_min_val = -1
        self._sample_count = 0
        self._start_time = time.time()
        self._video_bytes_acc = 0
        self._audio_bytes_acc = 0
        self._read_count = 0
        self._last_calc_time = time.time()

        self.video = "0 Kb/s"
        self.video_avg = "0 Kb/s"
        self.video_max = "0 Kb/s"
        self.video_min = "--- Kb/s"
        self.audio = "0 Kb/s"
        self.audio_avg = "0 Kb/s"
        self.audio_max = "0 Kb/s"
        self.audio_min = "--- Kb/s"
        self.total = "0 Kb/s"
        self.total_avg = "avg 0 Kb/s"
        self.samples = "0 samples | 0s | RESET"
        self.changed((self.CHANGED_ALL,))

    def destroy(self):
        self.poll_timer.stop()
        try:
            self.poll_timer.callback.remove(self.poll)
        except Exception:
            pass
        self._closeAllDemux()
        Source.destroy(self)
