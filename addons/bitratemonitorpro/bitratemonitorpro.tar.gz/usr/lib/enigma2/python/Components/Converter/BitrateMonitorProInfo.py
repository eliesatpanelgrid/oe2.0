# -*- coding: utf-8 -*-
#
#  BitrateMonitorProInfo — converter for the BitrateMonitorPro source
#  ==================================================================
#  Exposes every published field of the BitrateMonitorPro source as
#  skin text. Usage:
#
#    <widget source="Bitrate" render="Label" ...>
#      <convert type="BitrateMonitorProInfo">video</convert>
#    </widget>
#
#  Fields: video, video_avg, video_max, video_min,
#          audio, audio_avg, audio_max, audio_min,
#          total, total_avg, samples, dmx,
#          dmx_ok, dmx_fail (colored dot via skin foregroundColor),
#          video_info, audio_codec, lang, band
#
#  Author: Simokof
#  License: GPLv2
#

from Components.Converter.Converter import Converter
from Components.Element import cached


class BitrateMonitorProInfo(Converter):
    FIELDS = (
        "video", "video_avg", "video_max", "video_min",
        "audio", "audio_avg", "audio_max", "audio_min",
        "total", "total_avg", "samples", "dmx",
        "dmx_ok", "dmx_fail",
        "video_info", "audio_codec", "lang", "band",
        "snr", "agc", "snr_bar", "agc_bar",
    )

    def __init__(self, type):
        Converter.__init__(self, type)
        self.field = str(type).strip()
        if self.field not in self.FIELDS:
            self.field = "dmx"

    @cached
    def getText(self):
        source = self.source
        if source is None:
            return ""
        try:
            if self.field == "dmx_ok":
                return "\u25cf" if source.dmx_ok else ""
            if self.field == "dmx_fail":
                return "" if source.dmx_ok else "\u25cf"
            return str(getattr(source, self.field, "") or "")
        except Exception:
            return ""

    text = property(getText)

    @cached
    def getValue(self):
        source = self.source
        if source is None:
            return 0
        field = self.field[:-4] if self.field.endswith("_bar") else self.field
        try:
            return int(getattr(source, field + "_value", 0) or 0)
        except Exception:
            return 0

    value = property(getValue)

    @cached
    def getRange(self):
        return 100

    range = property(getRange)
