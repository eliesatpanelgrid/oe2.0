# -*- coding: utf-8 -*-
#
#  BitrateMonitorPro Plugin v1.0 — Premium skin-native design
#  ==========================================================
#  The screen speaks the design language of the Premium-FHD skin
#  family (Blue/Black), using ONLY its palette names, fonts and
#  widget vocabulary — nothing invented:
#
#    • panel:   screen-level cornerRadius + backgroundColor
#               "background3" (like the reference plugin screens)
#    • fonts:   "Regularn" (DejaVuSans) + "calibri" for the title
#    • colors:  chselfg, foreground2, cyan1, hellgreen, grey,
#               grdd7, progbg, background3 (skin palette names —
#               the screen adapts to whichever Premium variant)
#    • bars:    render="Progress" + foregroundGradient
#               "red,yellow,green,horizontal" + cornerRadius —
#               the exact SNR/AGC construction the skin itself uses
#    • accents: gradient separator lines (grdd→grdl) like the skin
#
#  Architecture (unchanged, pure pipeline):
#    session.CurrentService → BitrateMonitorProServiceName2 / CryptInfo
#    session.FrontendStatus → FrontendInfo (SNR/AGC) → Progress
#    global.CurrentTime     → BitrateMonitorProClockToText
#    Bitrate (local source) → BitrateMonitorProInfo (all measurements)
#
#  Controls:
#    EXIT  — Close      OK — Reset stats (source.resetStats)
#
#  Author: DEV/DESIGNED BY MOHAMED ATEBROUR [KOFSIMO-SIMO-OCK]
#  License: GPLv2
#

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Sources.BitrateMonitorPro import BitrateMonitorPro
from enigma import getDesktop
from Plugins.Plugin import PluginDescriptor

_INSTALL_ASSETS = "/usr/lib/enigma2/python/Plugins/Extensions/BitrateMonitorPro/assets"

CREDITS_TEXT = "DEV/DESIGNED BY MOHAMED ATEBROUR [KOFSIMO-SIMO-OCK]"


def _getDesktopSize():
    try:
        desk = getDesktop(0)
        return desk.size().width(), desk.size().height()
    except Exception:
        return 1280, 720


# ─────────────────────────────────────────────────────────────
# Adaptive skin — Premium design language (FHD 1100x466 / HD
# 780x418). Same layout grid as before, native vocabulary now.
# ─────────────────────────────────────────────────────────────
def _buildSkin():
    w, h = _getDesktopSize()
    is_fhd = w >= 1920

    SVC2 = "BitrateMonitorProServiceName2"
    CRYPT = "BitrateMonitorProCryptInfo"
    XT = "BitrateMonitorProServiceInfoXT"
    BMI = "BitrateMonitorProInfo"

    if is_fhd:
        scr_w, scr_target = 1270, 760          # matches bg_panel_fhd.png
        title_font, dmx_font = 38, 22
        info_lbl_font, info_val_font = 17, 21
        section_font = 28
        current_font = 52
        stats_lbl_font, stats_val_font = 18, 22
        total_lbl_font, total_val_font = 28, 40
        signal_font = 20
        footer_font, credits_font = 20, 14
        margin, sep_h = 44, 4
        head_h = 68
        info_h = 56
        sec_head_h, current_h, stats_h = 42, 72, 44
        total_h, signal_h, footer_h, credits_h = 56, 68, 44, 18
        stat_lbl_w = 64
        bar_w, bar_h = 420, 32
        pct_w = 80
        key_img_w, key_img_h, key_png = 150, 44, "btn_key.png"
        samples_w = 300
        clock_w = 150
        f_close, f_ok, f_reset, f_reset_w = 156, 262, 418, 180
        g_after_header, g_sep_to_sections = 14, 14
        g_sep_to_total, g_signal_to_sep, g_sep_to_footer = 14, 14, 14
        rows = [
            [("Channel", "svc", SVC2, "Name", 380),
             ("Provider", "svc", SVC2, "Provider", 300),
             ("Video", "br", BMI, "video_info", 340),
             ("Audio", "svc", XT, "atype", 162)],
            [("Video PID", "svc", CRYPT, "VideoPID", 250),
             ("Audio PID", "svc", CRYPT, "AudioPID", 250),
             ("Lang", "svc", XT, "AudioLanguage", 380),
             ("SID", "svc", CRYPT, "%SID", 302)],
            [("Sat", "svc", SVC2, "OrbitalPos", 190),
             ("Freq", "svc", SVC2, "%F %p", 290),
             ("Band", "br", BMI, "band", 130),
             ("System", "svc", SVC2, "%s %M", 260),
             ("FEC/SR", "svc", SVC2, "%f %Y", 312)],
        ]
    else:
        scr_w, scr_target = 900, 483            # matches bg_panel_hd.png
        title_font, dmx_font = 26, 15
        info_lbl_font, info_val_font = 13, 16
        section_font = 19
        current_font = 34
        stats_lbl_font, stats_val_font = 13, 15
        total_lbl_font, total_val_font = 19, 28
        signal_font = 17
        footer_font, credits_font = 14, 10
        margin, sep_h = 30, 3
        head_h = 42
        info_h = 34
        sec_head_h, current_h, stats_h = 28, 44, 28
        total_h, signal_h, footer_h, credits_h = 36, 40, 26, 12
        stat_lbl_w = 46
        bar_w, bar_h = 270, 20
        pct_w = 60
        key_img_w, key_img_h, key_png = 100, 28, "btn_key_hd.png"
        samples_w = 210
        clock_w = 100
        f_close, f_ok, f_reset, f_reset_w = 106, 226, 328, 140
        g_after_header, g_sep_to_sections = 8, 8
        g_sep_to_total, g_signal_to_sep, g_sep_to_footer = 8, 8, 8
        rows = [
            [("Channel", "svc", SVC2, "Name", 330),
             ("Video", "br", BMI, "video_info", 290),
             ("Audio", "svc", XT, "atype", 220)],
            [("V-PID", "svc", CRYPT, "VideoPID", 230),
             ("A-PID", "svc", CRYPT, "AudioPID", 230),
             ("SID", "svc", CRYPT, "%SID", 380)],
            [("Sat", "svc", SVC2, "OrbitalPos", 250),
             ("Freq", "svc", SVC2, "%F %p", 320),
             ("System", "svc", SVC2, "%s %M", 270)],
        ]

    # Premium palette (names resolve inside the active Premium skin)
    SRCMAP = {"svc": "session.CurrentService", "br": "Bitrate"}

    S = []

    def sep(yy):
        # gradient accent line — the skin's glowing separator style
        S.append(f'  <eLabel position="{margin},{yy}" size="{scr_w - margin * 2},{sep_h}" '
                 f'backgroundGradient="grdd,grdl,horizontal" cornerRadius="{max(1, sep_h // 2)}" />')

    def conv_widget(source, render, conv, arg, pos, size, extra=""):
        S.append(f'  <widget source="{source}" render="{render}" position="{pos}" size="{size}"{extra}>')
        S.append(f'    <convert type="{conv}">{arg}</convert>')
        S.append('  </widget>')

    # ── Header ────────────────────────────────────────────
    y = sep_h + 6
    S.append(f'  <eLabel position="{margin},{y}" size="{scr_w // 2 - margin - 40},{head_h}" '
             f'text="Bitrate Monitor Pro" font="calibri; {title_font}" '
             f'foregroundColor="chselfg" transparent="1" halign="left" valign="center" />')

    dot_x = scr_w - margin - 320
    conv_widget("Bitrate", "Label", BMI, "dmx_ok", f"{dot_x},{y}", f"26,{head_h}",
                f' font="Regularn; {dmx_font + 12}" foregroundColor="hellgreen" transparent="1" valign="center"')
    conv_widget("Bitrate", "Label", BMI, "dmx_fail", f"{dot_x},{y}", f"26,{head_h}",
                f' font="Regularn; {dmx_font + 12}" foregroundColor="unff0000" transparent="1" valign="center"')
    conv_widget("Bitrate", "Label", BMI, "dmx", f"{dot_x + 30},{y}", f"{scr_w - dot_x - 30 - margin},{head_h}",
                f' font="Regularn; {dmx_font}" foregroundColor="foreground2" transparent="1" halign="right" valign="center"')
    y += head_h + 4
    sep(y)
    y += sep_h + g_after_header

    # ── Info rows ─────────────────────────────────────────
    # per-column label width, like real skins: sized to the label text
    for row in rows:
        for idx, (lbl_text, sk, conv, arg, col_w) in enumerate(row):
            x = margin + sum(c[4] for c in row[:idx])
            lw = len(lbl_text) * (info_lbl_font * 11 // 20) + 12
            S.append(f'  <eLabel position="{x},{y}" size="{lw},{info_h}" '
                     f'text="{lbl_text}" font="Regularn; {info_lbl_font}" foregroundColor="grey" transparent="1" valign="center" />')
            conv_widget(SRCMAP[sk], "Label", conv, arg,
                        f"{x + lw + 6},{y}", f"{max(1, col_w - lw - 6)},{info_h}",
                        f' font="Regularn; {info_val_font}" foregroundColor="grdd7" transparent="1" valign="center"')
        y += info_h + 2
    y += 4
    sep(y)
    y += sep_h + g_sep_to_sections

    # ── Video / Audio sections ────────────────────────────
    col1_x = margin
    col1_w = scr_w // 2 - margin - 10
    col2_x = scr_w // 2 + 30
    col2_w = scr_w - margin - col2_x

    def section(col_x, col_w, pfx, head_color):
        nonlocal y
        S.append(f'  <eLabel position="{col_x},{y}" size="{col_w},{sec_head_h}" '
                 f'text="{pfx.upper()}" font="Regularn; {section_font}" foregroundColor="{head_color}" transparent="1" valign="center" />')
        yy = y + sec_head_h + 4
        conv_widget("Bitrate", "Label", BMI, pfx, f"{col_x},{yy}", f"{col_w},{current_h}",
                    f' font="Regularn; {current_font}" foregroundColor="{head_color}" transparent="1" valign="center"')
        yy += current_h + 4
        stat_w = (col_w - 16) // 3
        for i, (lbl_text, color) in enumerate([("Avg", "grdd7"), ("Max", "unffc000"), ("Min", "grdd7")]):
            sx = col_x + i * (stat_w + 8)
            S.append(f'  <eLabel position="{sx},{yy}" size="{stat_lbl_w},{stats_h}" '
                     f'text="{lbl_text}" font="Regularn; {stats_lbl_font}" foregroundColor="grey" transparent="1" valign="center" />')
            conv_widget("Bitrate", "Label", BMI, f"{pfx}_{lbl_text.lower()}",
                        f"{sx + stat_lbl_w + 2},{yy}", f"{stat_w - stat_lbl_w - 2},{stats_h}",
                        f' font="Regularn; {stats_val_font}" foregroundColor="{color}" transparent="1" valign="center"')
        return yy + stats_h

    video_end = section(col1_x, col1_w, "video", "cyan1")
    audio_end = section(col2_x, col2_w, "audio", "foreground2")
    y = max(video_end, audio_end) + 6
    sep(y)
    y += sep_h + g_sep_to_total

    # ── Total row ─────────────────────────────────────────
    S.append(f'  <eLabel position="{margin},{y}" size="110,{total_h}" '
             f'text="TOTAL" font="Regularn; {total_lbl_font}" foregroundColor="grey" transparent="1" valign="center" />')
    conv_widget("Bitrate", "Label", BMI, "total", f"{margin + 120},{y}", f"{scr_w // 2 - margin - 130},{total_h}",
                f' font="Regularn; {total_val_font}" foregroundColor="hellgreen" transparent="1" valign="center"')
    conv_widget("Bitrate", "Label", BMI, "total_avg", f"{col2_x},{y}", f"{col2_w},{total_h}",
                f' font="Regularn; {info_val_font}" foregroundColor="grey" transparent="1" halign="right" valign="center"')
    y += total_h + 6

    # ── SNR / AGC — EXACTLY the user's working example:
    #    stock Progress renderer with a pixmap fill + FrontendInfo
    bar_y = y + (signal_h - bar_h) // 2
    group_w = 46 + 4 + bar_w + 10 + pct_w       # label + bar + %
    sig_gap = 60 if is_fhd else 40
    sig_x0 = (scr_w - (2 * group_w + sig_gap)) // 2   # horizontally centered
    for lbl_text, conv_arg, fill_png, ax in [
        ("SNR", "SNR", f"{_INSTALL_ASSETS}/bar_snr_fill.png", sig_x0),
        ("AGC", "AGC", f"{_INSTALL_ASSETS}/bar_agc_fill.png", sig_x0 + group_w + sig_gap),
    ]:
        S.append(f'  <eLabel position="{ax},{y}" size="46,{signal_h}" '
                 f'text="{lbl_text}" font="Regularn; {signal_font}" foregroundColor="grey" transparent="1" valign="center" />')
        S.append(f'  <widget source="session.FrontendStatus" render="Progress" position="{ax + 50},{bar_y}" size="{bar_w},{bar_h}" '
                 f'pixmap="{fill_png}" backgroundColor="black" transparent="1" zPosition="5">')
        S.append(f'    <convert type="FrontendInfo">{conv_arg}</convert>')
        S.append('  </widget>')
        S.append(f'  <widget source="session.FrontendStatus" render="Label" position="{ax + 50 + bar_w + 10},{y}" size="70,{signal_h}" '
                 f'font="Regularn; {signal_font}" foregroundColor="green" transparent="1" valign="center">')
        S.append(f'    <convert type="FrontendInfo">{conv_arg}</convert>')
        S.append('  </widget>')
    y += signal_h + g_signal_to_sep
    sep(y)
    y += sep_h + g_sep_to_footer

    # ── Footer ────────────────────────────────────────────
    S.append(f'  <ePixmap position="{margin},{y}" size="{key_img_w},{key_img_h}" '
             f'pixmap="{_INSTALL_ASSETS}/{key_png}" alphatest="blend" zPosition="1" />')
    S.append(f'  <eLabel position="{margin},{y}" size="{key_img_w},{key_img_h}" '
             f'text="[EXIT]" font="Regularn; {footer_font - 2}" foregroundColor="grdd7" transparent="1" halign="center" valign="center" zPosition="2" />')
    S.append(f'  <eLabel position="{margin + f_close},{y}" size="{f_ok - f_close - 5},{footer_h}" '
             f'text="Close" font="Regularn; {footer_font}" foregroundColor="grey" transparent="1" valign="center" />')
    S.append(f'  <ePixmap position="{margin + f_ok},{y}" size="{key_img_w},{key_img_h}" '
             f'pixmap="{_INSTALL_ASSETS}/{key_png}" alphatest="blend" zPosition="1" />')
    S.append(f'  <eLabel position="{margin + f_ok},{y}" size="{key_img_w},{key_img_h}" '
             f'text="[OK]" font="Regularn; {footer_font - 2}" foregroundColor="grdd7" transparent="1" halign="center" valign="center" zPosition="2" />')
    S.append(f'  <eLabel position="{margin + f_reset},{y}" size="{f_reset_w},{footer_h}" '
             f'text="Reset Stats" font="Regularn; {footer_font}" foregroundColor="grey" transparent="1" valign="center" />')
    conv_widget("global.CurrentTime", "Label", "BitrateMonitorProClockToText", "Default",
                f"{scr_w - margin - samples_w - clock_w - 20},{y}", f"{clock_w},{footer_h}",
                f' font="Regularn; {footer_font}" foregroundColor="foreground2" transparent="1" valign="center"')
    conv_widget("Bitrate", "Label", BMI, "samples", f"{scr_w - margin - samples_w},{y}", f"{samples_w},{footer_h}",
                f' font="Regularn; {footer_font}" foregroundColor="grey" transparent="1" halign="right" valign="center"')
    y += footer_h + 4

    # ── Credits ───────────────────────────────────────────
    S.append(f'  <eLabel position="{margin},{y}" size="{scr_w - margin * 2},{credits_h}" '
             f'text="{CREDITS_TEXT}" font="Regularn; {credits_font}" foregroundColor="grey2" transparent="1" halign="center" valign="center" />')

    scr_h = scr_target                       # exact match to the bg PNG
    S.append(f'  <ePixmap position="0,0" size="{scr_w},{scr_h}" '
             f'pixmap="{_INSTALL_ASSETS}/bg_panel_{"fhd" if is_fhd else "hd"}.png" '
             f'alphatest="blend" zPosition="-10" />')

    skin = (f'<screen name="BitrateMonitorProScreen" position="center,center" size="{scr_w},{scr_h}" '
            f'title="Bitrate Monitor Pro" backgroundColor="background3" flags="wfNoBorder" cornerRadius="22">\n')
    skin += '\n'.join(S)
    skin += '\n</screen>'
    return skin


# ─────────────────────────────────────────────────────────────
# Screen — pure declaration (no data logic)
# ─────────────────────────────────────────────────────────────

class BitrateMonitorProScreen(Screen):
    def __init__(self, session):
        self.skin = _buildSkin()
        Screen.__init__(self, session)
        self.setTitle("Bitrate Monitor Pro")

        self["Bitrate"] = BitrateMonitorPro(session.nav)

        self["actions"] = ActionMap(
            ["OkCancelActions"],
            {
                "cancel": self.close,
                "ok": self._resetStats,
            },
            -1,
        )

    def _resetStats(self):
        try:
            self["Bitrate"].resetStats()
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────
# Plugin Descriptor
# ─────────────────────────────────────────────────────────────

def main(session, **kwargs):
    session.open(BitrateMonitorProScreen)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Bitrate Monitor Pro",
            description="Real-time Video/Audio bitrate monitor with statistics",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="assets/plugin.png",
            fnc=main,
        ),
        PluginDescriptor(
            name="Bitrate Monitor Pro",
            description="Real-time Video/Audio bitrate monitor with statistics",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main,
        ),
    ]
