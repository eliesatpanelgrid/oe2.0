#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#  Bitrate Monitor Pro — CLI / Telnet Edition
#  =================================================
#  Standalone bitrate monitor that runs from a Telnet or SSH session.
#  No GUI required — displays real-time bitrate in the terminal.
#
#  Usage:
#    python /usr/lib/enigma2/python/Plugins/Extensions/BitrateMonitorPro/bitrate-cli.py
#    python .../bitrate-cli.py --once     # single snapshot
#    python .../bitrate-cli.py --interval 500   # custom interval (ms)
#
#  Controls (interactive mode):
#    Ctrl+C  — Exit
#    r       — Reset statistics
#
#  Author: DEV/DESIGNED BY MOHAMED ATEBROUR [KOFSIMO-SIMO-OCK]
#  License: GPLv2
#

import os
import sys
import struct
import fcntl
import select
import time
import glob
import signal
import argparse

# ─────────────────────────────────────────────────────────────
# DMX ioctl constants (Linux DVB API v5)
# ─────────────────────────────────────────────────────────────
DMX_START = 0x6f29
DMX_STOP = 0x6f2a
DMX_SET_BUFFER_SIZE = 0x6f2d

DMX_OUT_TAP         = 1
DMX_OUT_TS_TAP      = 2
DMX_OUT_TSDEMUX_TAP = 3

DMX_IN_FRONTEND     = 0
DMX_PES_VIDEO0      = 0
DMX_PES_AUDIO0     = 1
DMX_PES_OTHER       = 20
DMX_IMMEDIATE_START = 0x04

_FILTER_STRUCT_FMT = 'HHiiii'
_FILTER_STRUCT_SIZE = struct.calcsize(_FILTER_STRUCT_FMT)

_IOC_WRITE = 1
DMX_SET_PES_FILTER = (_IOC_WRITE << 30) | (_FILTER_STRUCT_SIZE << 16) | (0x6f << 8) | 0x2c
DMX_SET_PES_FILTER_64 = (_IOC_WRITE << 30) | (40 << 16) | (0x6f << 8) | 0x2c
_FILTER_STRUCT_FMT_64 = 'H6xqqqi4x'

DMX_BUFFER_SIZES = [
    8 * 1024 * 1024,
    4 * 1024 * 1024,
    2 * 1024 * 1024,
    1 * 1024 * 1024,
    512 * 1024,
    256 * 1024,
]
READ_BUFFER_SIZE = 2 * 1024 * 1024

SELECT_TIMEOUT = 0.01

_OUTPUT_MODES = [DMX_OUT_TAP, DMX_OUT_TSDEMUX_TAP, DMX_OUT_TS_TAP]

# ─────────────────────────────────────────────────────────────
# Codec maps
# ─────────────────────────────────────────────────────────────
VIDEO_CODEC_MAP = {
    -1: "N/A", 0: "MPEG2", 1: "H.264", 2: "MPEG1",
    3: "MPEG4-VC", 4: "VC1", 5: "VC1-SM", 6: "HEVC",
    7: "VP8", 8: "VP9", 9: "VVC", 10: "AV1",
}

AUDIO_CODEC_MAP = {
    -1: "N/A", 0: "MP2", 1: "AC3", 2: "AAC", 3: "DTS",
    4: "AAC-HE", 5: "E-AC3", 6: "AC4", 7: "WMA",
}


# ─────────────────────────────────────────────────────────────
# Service info reader (reads from enigma2 service list)
# ─────────────────────────────────────────────────────────────
def get_current_service():
    """Try to read current service info via enigma2 dbus or /proc."""
    info = {
        "name": "Unknown",
        "vpid": -1,
        "apid": -1,
        "vcodec": "N/A",
        "acodec": "N/A",
        "resolution": "---",
    }

    # Method 1: Try enigma2 Python API (if running on the box)
    try:
        from enigma import iServiceInformation
        from Screens.InfoBar import InfoBar
        infobar = InfoBar.instance
        if infobar and infobar.session:
            service = infobar.session.nav.getCurrentService()
            if service:
                sinfo = service.info()
                if sinfo:
                    info["name"] = sinfo.getName() or "Unknown"
                    vpid = sinfo.getInfo(iServiceInformation.sVideoPID)
                    apid = sinfo.getInfo(iServiceInformation.sAudioPID)
                    if vpid and vpid > 0:
                        info["vpid"] = vpid
                    if apid and apid > 0:
                        info["apid"] = apid
                    else:
                        # Fallback for encrypted channels on some images (Egami etc.)
                        try:
                            apid_str = sinfo.getInfoString(iServiceInformation.sAudioPID)
                            if apid_str and apid_str.isdigit():
                                info["apid"] = int(apid_str)
                        except Exception:
                            pass
                        if info["apid"] <= 0:
                            try:
                                audio = service.audioTracks()
                                if audio and audio.getNumberOfTracks() > 0:
                                    cur = audio.getCurrentTrack()
                                    if cur >= 0:
                                        track = audio.getTrackInfo(cur)
                                        try:
                                            pid = track.getPID()
                                            if pid and pid > 0:
                                                info["apid"] = pid
                                        except Exception:
                                            pass
                            except Exception:
                                pass
                        if info["apid"] <= 0:
                            try:
                                for pf in ("/proc/stb/audio/apid", "/proc/stb/vmpeg/0/apid"):
                                    if os.path.exists(pf):
                                        info["apid"] = int(open(pf).read().strip())
                                        if info["apid"] > 0:
                                            break
                            except Exception:
                                pass
    except Exception:
        pass

    # Method 2: Read from /proc/enigma2 or similar
    try:
        proc_path = "/proc/enigma2/service"
        if os.path.exists(proc_path):
            with open(proc_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("name="):
                        info["name"] = line.split("=", 1)[1]
                    elif line.startswith("vpid="):
                        info["vpid"] = int(line.split("=", 1)[1])
                    elif line.startswith("apid="):
                        info["apid"] = int(line.split("=", 1)[1])
    except Exception:
        pass

    # Method 3: Try reading from the current service reference file
    try:
        sref_path = "/proc/stb/frontend/0/current_service"
        if os.path.exists(sref_path):
            with open(sref_path, "r") as f:
                content = f.read()
                # Parse if available
                info["name"] = content.strip() or info["name"]
    except Exception:
        pass

    return info


# ─────────────────────────────────────────────────────────────
# DMX helpers
# ─────────────────────────────────────────────────────────────

def try_open_demux(demux_path, pid, output_mode, pes_type=20):
    """Attempt to open DMX with specific parameters."""
    fd = -1
    try:
        fd = os.open(demux_path, os.O_RDONLY | os.O_NONBLOCK)

        # Try progressively smaller buffer sizes
        buf_ok = False
        for buf_sz in DMX_BUFFER_SIZES:
            try:
                fcntl.ioctl(fd, DMX_SET_BUFFER_SIZE, buf_sz)
                buf_ok = True
                break
            except OSError:
                continue
        if not buf_ok:
            os.close(fd)
            return -1

        ioctl_ok = False

        # Attempt 1: 32-bit struct with IMMEDIATE_START
        try:
            params = struct.pack(
                _FILTER_STRUCT_FMT,
                pid, 0, DMX_IN_FRONTEND, output_mode, pes_type, DMX_IMMEDIATE_START,
            )
            fcntl.ioctl(fd, DMX_SET_PES_FILTER, params)
            ioctl_ok = True
        except OSError:
            pass

        # Attempt 2: 64-bit struct with IMMEDIATE_START
        if not ioctl_ok:
            try:
                params64 = struct.pack(
                    _FILTER_STRUCT_FMT_64,
                    pid, DMX_IN_FRONTEND, output_mode, pes_type, DMX_IMMEDIATE_START,
                )
                fcntl.ioctl(fd, DMX_SET_PES_FILTER_64, params64)
                ioctl_ok = True
            except OSError:
                pass

        # Attempt 3: 32-bit struct without IMMEDIATE_START + explicit START
        if not ioctl_ok:
            try:
                params_no_flag = struct.pack(
                    _FILTER_STRUCT_FMT,
                    pid, 0, DMX_IN_FRONTEND, output_mode, pes_type, 0,
                )
                fcntl.ioctl(fd, DMX_SET_PES_FILTER, params_no_flag)
                fcntl.ioctl(fd, DMX_START)
                ioctl_ok = True
            except OSError:
                pass

        # Attempt 4: 64-bit struct without IMMEDIATE_START + explicit START
        if not ioctl_ok:
            try:
                params64_no_flag = struct.pack(
                    _FILTER_STRUCT_FMT_64,
                    pid, DMX_IN_FRONTEND, output_mode, pes_type, 0,
                )
                fcntl.ioctl(fd, DMX_SET_PES_FILTER_64, params64_no_flag)
                fcntl.ioctl(fd, DMX_START)
                ioctl_ok = True
            except OSError:
                pass

        if ioctl_ok:
            return fd
        os.close(fd)
        return -1
    except Exception:
        if fd >= 0:
            try:
                os.close(fd)
            except Exception:
                pass
        return -1


def open_demux_all(pid, pes_type=20):
    """Open DMX on all available adapters/demuxes."""
    opened = []
    # Primary: standard DVB demux paths
    paths = sorted(glob.glob("/dev/dvb/adapter*/demux*"))
    # Fallback: legacy/alternative paths
    if not paths:
        paths = sorted(glob.glob("/dev/demux*"))
    if not paths:
        paths = sorted(glob.glob("/dev/dvb/adapter*/dvr*"))
    if not paths:
        return opened

    # PES type fallback: OTHER first (universal), then specific
    if pes_type == DMX_PES_OTHER:
        pes_types = [DMX_PES_OTHER]
    else:
        pes_types = [DMX_PES_OTHER, pes_type]

    for path in paths:
        if not os.path.exists(path):
            continue
        for pt in pes_types:
            for mode in _OUTPUT_MODES:
                fd = try_open_demux(path, pid, mode, pt)
                if fd >= 0:
                    opened.append(fd)
                    break  # mode
            if opened:
                break  # pes_type
        if opened:
            break  # path
    return opened


def close_fd(fd):
    """Stop and close a DMX fd."""
    if fd >= 0:
        try:
            fcntl.ioctl(fd, DMX_STOP)
        except Exception:
            pass
        try:
            os.close(fd)
        except Exception:
            pass


def drain_fds(fds):
    """Drain all fds, return total bytes and active fd."""
    if not fds:
        return 0, -1
    total = 0
    active_fd = -1
    try:
        ready, _, _ = select.select(fds, [], [], SELECT_TIMEOUT)
        for fd in ready:
            fd_bytes = 0
            while True:
                try:
                    chunk = os.read(fd, READ_BUFFER_SIZE)
                    if not chunk:
                        break
                    fd_bytes += len(chunk)
                    if len(chunk) < READ_BUFFER_SIZE:
                        break
                except (BlockingIOError, OSError):
                    break
            if fd_bytes > 0:
                total += fd_bytes
                if active_fd < 0:
                    active_fd = fd
    except Exception:
        pass
    return total, active_fd


# ─────────────────────────────────────────────────────────────
# Formatting
# ─────────────────────────────────────────────────────────────

def format_bitrate(kb_val):
    """Format bitrate: Kb/s up to 9999, Mb/s from 10000."""
    if kb_val >= 10000:
        return f"{kb_val / 1000:.1f} Mb/s"
    return f"{kb_val} Kb/s"


def format_bar(pct, width=20):
    """Create a text progress bar."""
    filled = int(pct / 100 * width)
    return "[" + "=" * filled + " " * (width - filled) + "]"


# ─────────────────────────────────────────────────────────────
# Terminal output
# ─────────────────────────────────────────────────────────────

ANSI_RESET = "\033[0m"
ANSI_BOLD = "\033[1m"
ANSI_GREEN = "\033[32m"
ANSI_ORANGE = "\033[33m"
ANSI_YELLOW = "\033[93m"
ANSI_GRAY = "\033[90m"
ANSI_CYAN = "\033[36m"
ANSI_RED = "\033[31m"
ANSI_CLEAR = "\033[2J\033[H"

BANNER = r"""

  Real-time Bitrate Monitor — CLI/Telnet Edition
"""


def print_header(channel_name):
    """Print the monitor header."""
    if sys.stdout.isatty():
        print(ANSI_CLEAR, end="")

    print(ANSI_BOLD + ANSI_CYAN + BANNER + ANSI_RESET)
    print(f"  {ANSI_BOLD}Channel:{ANSI_RESET} {channel_name}")
    print(f"  {ANSI_BOLD}Time:{ANSI_RESET}    {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  {'─' * 56}")

    # Column headers
    print(f"  {ANSI_BOLD}{'STREAM':<8} {'CURRENT':>12} {'AVERAGE':>12} {'PEAK':>12} {'MIN':>12}{ANSI_RESET}")
    print(f"  {'─' * 56}")


def print_stats(v_cur, v_avg, v_max, v_min, a_cur, a_avg, a_max, a_min,
                total_cur, total_avg, samples, elapsed_str, dmx_ok):
    """Print the stats table."""
    if sys.stdout.isatty():
        # Move cursor to stats area (header occupies lines 1-13)
        print("\033[14;0H", end="")

    status = f"{ANSI_GREEN}● DMX OK{ANSI_RESET}" if dmx_ok else f"{ANSI_RED}● DMX FAIL{ANSI_RESET}"

    print(f"  {ANSI_BOLD}VIDEO{ANSI_RESET}   "
          f"{ANSI_GREEN}{format_bitrate(v_cur):>12}{ANSI_RESET}  "
          f"{ANSI_GRAY}{format_bitrate(v_avg):>12}{ANSI_RESET}  "
          f"{ANSI_ORANGE}{format_bitrate(v_max):>12}{ANSI_RESET}  "
          f"{ANSI_GRAY}{format_bitrate(v_min):>12}{ANSI_RESET}")

    print(f"  {ANSI_BOLD}AUDIO{ANSI_RESET}   "
          f"{ANSI_GREEN}{format_bitrate(a_cur):>12}{ANSI_RESET}  "
          f"{ANSI_GRAY}{format_bitrate(a_avg):>12}{ANSI_RESET}  "
          f"{ANSI_ORANGE}{format_bitrate(a_max):>12}{ANSI_RESET}  "
          f"{ANSI_GRAY}{format_bitrate(a_min):>12}{ANSI_RESET}")

    print(f"  {ANSI_BOLD}TOTAL{ANSI_RESET}   "
          f"{ANSI_GREEN}{format_bitrate(total_cur):>12}{ANSI_RESET}  "
          f"{ANSI_GRAY}{format_bitrate(total_avg):>12}{ANSI_RESET}")

    print(f"  {'─' * 56}")
    print(f"  {ANSI_BOLD}DMX:{ANSI_RESET}     {status}")
    print(f"  {ANSI_BOLD}Stats:{ANSI_RESET}   {samples} samples | {elapsed_str}")
    print(f"  {'─' * 56}")
    print(f"  {ANSI_GRAY}Press Ctrl+C to exit | 'r' to reset{ANSI_RESET}")


# ─────────────────────────────────────────────────────────────
# Main monitor
# ─────────────────────────────────────────────────────────────

class BitrateMonitor:
    def __init__(self, interval_ms=1000, once=False):
        self.interval = interval_ms
        self.once = once
        self.running = True
        self.reset_stats()

        # Signal handler for clean exit
        signal.signal(signal.SIGINT, self._signal_handler)

    def _signal_handler(self, signum, frame):
        self.running = False
        print(f"\n{ANSI_YELLOW}Exiting...{ANSI_RESET}")

    def reset_stats(self):
        self.v_total = 0
        self.a_total = 0
        self.v_max = 0
        self.v_min = -1
        self.a_max = 0
        self.a_min = -1
        self.sample_count = 0
        self.start_time = time.time()
        self.v_bytes_acc = 0
        self.a_bytes_acc = 0
        self.last_calc_time = time.time()

    def run(self):
        channel_name = "Unknown"
        vpid = -1
        apid = -1
        v_fds = []
        a_fds = []
        dmx_ok = False

        # Try to get service info
        svc = get_current_service()
        channel_name = svc.get("name", "Unknown")
        vpid = svc.get("vpid", -1)
        apid = svc.get("apid", -1)

        print_header(channel_name)

        if vpid <= 0 and apid <= 0:
            print(f"\n  {ANSI_RED}No active service detected.{ANSI_RESET}")
            print(f"  {ANSI_GRAY}Make sure a channel is tuned before running this tool.{ANSI_RESET}")
            if not self.once:
                print(f"  {ANSI_GRAY}Waiting for service... (Ctrl+C to exit){ANSI_RESET}")

        while self.running:
            # Re-check service info every few seconds
            if self.sample_count > 0 and self.sample_count % 10 == 0:
                svc = get_current_service()
                new_name = svc.get("name", "Unknown")
                new_vpid = svc.get("vpid", -1)
                new_apid = svc.get("apid", -1)

                if new_vpid != vpid:
                    for fd in v_fds:
                        close_fd(fd)
                    v_fds = []
                    vpid = new_vpid
                    channel_name = new_name
                    self.v_bytes_acc = 0
                    print_header(channel_name)

                if new_apid != apid:
                    for fd in a_fds:
                        close_fd(fd)
                    a_fds = []
                    apid = new_apid
                    self.a_bytes_acc = 0

            # Open DMX if needed
            if vpid > 0 and not v_fds:
                v_fds = open_demux_all(vpid, DMX_PES_VIDEO0)
            if apid > 0 and not a_fds:
                a_fds = open_demux_all(apid, DMX_PES_AUDIO0)

            # Drain and accumulate
            v_bytes, _ = drain_fds(v_fds)
            self.v_bytes_acc += v_bytes

            a_bytes, _ = drain_fds(a_fds)
            self.a_bytes_acc += a_bytes

            dmx_ok = bool(v_fds or a_fds)

            # Calculate and display
            now = time.time()
            elapsed = now - self.last_calc_time

            if elapsed >= (self.interval / 1000.0):
                if elapsed <= 0:
                    elapsed = 1.0

                vbr = self.v_bytes_acc * 8
                abr = self.a_bytes_acc * 8
                self.v_bytes_acc = 0
                self.a_bytes_acc = 0
                self.last_calc_time = now

                vkb = int(vbr / 1000)
                akb = int(abr / 1000)

                self.sample_count += 1
                self.v_total += vkb
                self.a_total += akb

                if vkb > self.v_max:
                    self.v_max = vkb
                if self.v_min < 0 or (vkb < self.v_min and vkb > 0):
                    self.v_min = vkb
                if akb > self.a_max:
                    self.a_max = akb
                if self.a_min < 0 or (akb < self.a_min and akb > 0):
                    self.a_min = akb

                v_avg = self.v_total // self.sample_count if self.sample_count > 0 else 0
                a_avg = self.a_total // self.sample_count if self.sample_count > 0 else 0

                elapsed_total = int(time.time() - self.start_time)
                mins, secs = divmod(elapsed_total, 60)
                time_str = f"{mins}m {secs}s" if mins > 0 else f"{secs}s"

                print_stats(
                    vkb, v_avg, self.v_max, self.v_min if self.v_min >= 0 else 0,
                    akb, a_avg, self.a_max, self.a_min if self.a_min >= 0 else 0,
                    vkb + akb, v_avg + a_avg,
                    self.sample_count, time_str, dmx_ok
                )

                if self.once:
                    break

            if not self.once:
                time.sleep(0.2)

        # Cleanup
        for fd in v_fds:
            close_fd(fd)
        for fd in a_fds:
            close_fd(fd)

        print(f"\n{ANSI_GREEN}Monitor stopped.{ANSI_RESET}")


# ─────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Bitrate Monitor Pro — CLI/Telnet Edition",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                    Run in interactive mode (default 1s interval)
  %(prog)s --once             Single snapshot, then exit
  %(prog)s --interval 500     Update every 500ms
  %(prog)s --interval 2000    Update every 2s

Run via Telnet:
  telnet <box-ip>
  python /usr/lib/enigma2/python/Plugins/Extensions/BitrateMonitorPro/bitrate-cli.py

Run via SSH:
  ssh root@<box-ip>
  python /usr/lib/enigma2/python/Plugins/Extensions/BitrateMonitorPro/bitrate-cli.py
        """,
    )
    parser.add_argument(
        "--once", action="store_true",
        help="Single snapshot, then exit (useful for scripts)"
    )
    parser.add_argument(
        "--interval", type=int, default=1000,
        help="Update interval in milliseconds (default: 1000)"
    )
    args = parser.parse_args()

    monitor = BitrateMonitor(interval_ms=args.interval, once=args.once)
    monitor.run()


if __name__ == "__main__":
    main()
