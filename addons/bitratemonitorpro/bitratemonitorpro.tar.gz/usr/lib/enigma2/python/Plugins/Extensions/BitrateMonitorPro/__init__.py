#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#  Simokof BitRate Monitor Pro — Plugin Installer for __init__.py
#
#  This file ensures the plugin module is recognized by Enigma2.
#
#  Author: Simokof
#  License: GPLv2
#

# Enigma2 will import plugin.py from this directory.
# No additional __init__.py content is needed — Enigma2 discovers
# the PluginDescriptor via Plugins() in plugin.py.
