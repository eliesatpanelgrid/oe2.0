"""Portal list screen extracted from ui.py without changing class behavior."""

from . import _
import hashlib
import json
import os
import queue
import re
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox
from Screens.ChoiceBox import ChoiceBox
try:
    from Screens.VirtualKeyBoard import VirtualKeyBoard
except Exception:
    VirtualKeyBoard = None
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer
from skin import parseColor

from .ui_async import AsyncScreenMixin
from .ui_image_loader import ImageLoaderMixin
from .ui_transition import TransitionMixin
from .ui_dynamic_chrome import _build_dynamic_settings_episode_rows
from .ui_dynamic_palette import _dynamic_palette
from .ui_helpers import _lift_dynamic_accent
from .log import diagnostic_failure

MAIN_SKIN = ""
_plugin_original_service_getter = lambda: None
_plugin_service_captured_getter = lambda: False

def configure_portal_list(**deps):
    globals().update(deps)
    # Portal selection now deliberately shares the approved Settings Test8
    # visual shell instead of the legacy portal-specific full-page skin.
    try:
        scaler=deps.get("font_scale_skin")
        PortalListScreen.skin = scaler(PORTAL_SELECTION_SETTINGS_SKIN) if callable(scaler) else PORTAL_SELECTION_SETTINGS_SKIN
        PortalLibraryListScreen.skin = PortalListScreen.skin
        PortalManagerPremiumScreen.skin = scaler(PORTAL_MANAGER_PREMIUM_SKIN) if callable(scaler) else PORTAL_MANAGER_PREMIUM_SKIN
    except Exception as exc:
        optional_failure("ui.portal_skin_config",exc)



PORTAL_MANAGER_PREMIUM_SKIN = """<screen name="PortalManagerPremiumScreen" position="center,center" size="1920,1080" backgroundColor="#02070b" flags="wfNoBorder">
 <widget name="ambient_bg" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="1"/>
 <widget name="hero_backdrop" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="2"/>
 <ePixmap position="48,12" size="300,96" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/brand_header_full.png" alphatest="blend" scale="1" zPosition="6"/>
 <widget name="list" position="50,110" size="430,880" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/portal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="7"/>
 <widget name="status" position="60,1028" size="1800,34" font="Regular;18" halign="center" valign="center" foregroundColor="#b7d9eb" shadowColor="#000000" shadowOffset="1,1" transparent="1" zPosition="9"/>
</screen>"""


PORTAL_SELECTION_SETTINGS_SKIN = """<screen name="PortalListScreen" position="center,center" size="1920,1080" backgroundColor="#02070b" flags="wfNoBorder">
 <widget name="ambient_bg" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="1"/>
 <widget name="hero_backdrop" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="2"/>
 <ePixmap position="48,12" size="300,96" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/brand_header_full.png" alphatest="blend" scale="1" zPosition="6"/>
 <widget name="list" position="50,110" size="430,880" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/portal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="7"/>
 <widget name="source_badges" position="1390,760" size="430,240" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/portal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="7"/>
 <widget name="portal_page" position="60,1002" size="1800,28" font="Regular;17" halign="center" valign="center" foregroundColor="#9fc6df" transparent="1" zPosition="8"/>
 <widget name="status" position="60,1034" size="1800,30" font="Regular;18" halign="center" valign="center" foregroundColor="#b7d9eb" shadowColor="#000000" shadowOffset="1,1" transparent="1" zPosition="9"/>
</screen>"""


class PortalManagerPremiumScreen(Screen):
    """Premium Portal Manager using the approved Settings Test8 row grammar.

    This screen is deliberately presentation-only for the existing portal tools:
    selecting a normal action returns the exact legacy action token to
    PortalListScreen._portal_tool_selected().  Multi-select deletion is the only
    new behavior and it reuses permanently_delete_profile() for every target.
    """
    skin = PORTAL_MANAGER_PREMIUM_SKIN
    ROW_W = 430
    ROW_H = 80

    _ACTIONS = (
        ("Free Portal Library", "portal_library", "Browse the bundled Portal catalog and import selected entries", "settings_icons/web_access.png"),
        ("Free Xtream Library", "xtream_library", "Browse the bundled Xtream catalog and import selected entries", "settings_icons/channel_list.png"),
        ("Check all portals", "check_all", "Health check for every enabled portal", "settings_icons/diagnostics.png"),
        ("Re-enable disabled portal", "enable_disabled", "Restore a disabled portal", "settings_icons/recovery.png"),
        ("Rename portal", "rename", "Rename the selected portal", "settings_icons/advanced.png"),
        ("Edit URL / MAC", "edit", "Edit portal address or MAC", "settings_icons/web_access.png"),
        ("MAG device profile", "device_profile", "Choose the MAG device profile", "settings_icons/playback.png"),
        ("Export Live bouquet + EPG", "export_bouquet", "Create Live bouquet and EPG source", "settings_icons/epg.png"),
        ("Remove exported bouquet + EPG", "unexport_bouquet", "Remove the exported Live integration", "settings_icons/clean.png"),
        ("Duplicate with another MAC", "duplicate", "Clone this portal with another MAC", "settings_icons/backup.png"),
        ("Move up", "move_up", "Move the selected portal up", "settings_icons/auto_switch.png"),
        ("Move down", "move_down", "Move the selected portal down", "settings_icons/auto_switch.png"),
        ("Disable portal", "disable", "Disable the selected portal", "settings_icons/lock.png"),
        ("Clear portal data", "purge_data", "Clear plugin-owned data but keep portal", "settings_icons/cache.png"),
        ("Delete permanently", "delete_permanent", "Delete this portal and related plugin data", "settings_icons/clean.png"),
        ("Diagnostics", "diagnostics", "Open diagnostics for the selected portal", "settings_icons/diagnostics.png"),
        ("Select portals", "select_portals", "Select multiple portals for one permanent delete", "settings_icons/multi_search.png"),
    )

    def __init__(self, session, parent):
        Screen.__init__(self, session)
        self.parent = parent
        self._mode = "actions"
        self._visual_index = -1
        self._rebuilding = False
        self._row_asset = asset("series_floating_row.png")
        self._row_selected_asset = asset("series_floating_row_selected.png")
        self._value_color = int("74d8ff", 16)
        self._multi_profiles = []
        self._multi_selected = set()
        self._confirm_targets = []
        self._last_summary = ""
        self["ambient_bg"] = Pixmap()
        self["hero_backdrop"] = Pixmap()
        self["list"] = IconMenuList([], width=self.ROW_W, item_height=self.ROW_H, icon_size=40, primary_font=21, secondary_font=15, row_style="settings_episode")
        self["status"] = Label("")
        self["list"].onSelectionChanged.append(self._selection_changed)
        actions = {
            "cancel": self._cancel, "ok": self._ok, "menu": self._cancel,
            "up": lambda: self._move("up"), "down": lambda: self._move("down"),
            "left": lambda: self._move("left"), "right": lambda: self._move("right"),
            "red": self._red, "green": self._green, "yellow": self._yellow, "blue": self._blue,
            "1": lambda: self._number(1), "2": lambda: self._number(2), "3": lambda: self._number(3),
            "4": lambda: self._number(4), "5": lambda: self._number(5), "6": lambda: self._number(6),
            "7": lambda: self._number(7), "8": lambda: self._number(8), "9": lambda: self._number(9),
            "0": lambda: self._number(0),
        }
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "MenuActions", "NumberActions", "DirectionActions"], actions, -1)
        self.onLayoutFinish.append(self._layout_ready)
        self.onClose.append(self._cleanup)
        self._render_actions(0)

    def _cleanup(self):
        try:
            callbacks = self["list"].onSelectionChanged
            if self._selection_changed in callbacks:
                callbacks.remove(self._selection_changed)
        except Exception as exc:
            optional_failure("ui.portal_manager_cleanup", exc)

    def _hero_visuals(self):
        hero = {}
        try:
            with open(HOME_HERO_FILE, "r", encoding="utf-8") as handle:
                state = json.load(handle)
            hero = state.get("hero") if isinstance(state, dict) and isinstance(state.get("hero"), dict) else {}
        except Exception:
            hero = {}
        mood = hero.get("home_mood") if isinstance(hero.get("home_mood"), dict) else {}
        prepared = str(hero.get("prepared") or "")
        ambient = str(mood.get("ambient") or "")
        if not (prepared and os.path.isfile(prepared)):
            prepared = asset("nova_browser_bg.png")
        if not (ambient and os.path.isfile(ambient)):
            ambient = ""
        return prepared, ambient

    def _layout_ready(self):
        prepared, ambient = self._hero_visuals()
        try:
            if ambient:
                self["ambient_bg"].instance.setPixmapFromFile(ambient); self["ambient_bg"].show()
            else:
                self["ambient_bg"].hide()
        except Exception as exc:
            optional_failure("ui.portal_manager_ambient", exc)
        try:
            if prepared and os.path.isfile(prepared):
                self["hero_backdrop"].instance.setPixmapFromFile(prepared); self["hero_backdrop"].show()
        except Exception as exc:
            optional_failure("ui.portal_manager_backdrop", exc)
        try:
            stamp = int(os.path.getmtime(prepared)) if prepared and os.path.isfile(prepared) else 0
            key = hashlib.sha1((str(prepared) + "|" + str(stamp) + "|settings-episode-row-v1").encode("utf-8", "ignore")).hexdigest()[:18]
            chrome = _build_dynamic_settings_episode_rows(prepared, key) or {}
            normal = str(chrome.get("normal") or "")
            selected = str(chrome.get("selected") or "")
            if normal and os.path.isfile(normal):
                self._row_asset = normal
            if selected and os.path.isfile(selected):
                self._row_selected_asset = selected
            accent = chrome.get("value_color")
            if not accent and prepared and os.path.isfile(prepared):
                primary, _secondary = _dynamic_palette(prepared)
                accent = _lift_dynamic_accent(primary, 0.48, 0.46)
            if isinstance(accent, (tuple, list)) and len(accent) >= 3:
                self._value_color = (int(accent[0]) << 16) | (int(accent[1]) << 8) | int(accent[2])
        except Exception as exc:
            optional_failure("ui.portal_manager_material", exc)
        try:
            if self["list"].instance is not None:
                self["list"].instance.setSelectionEnable(0)
                self["list"].instance.setTransparent(1)
                self["list"].instance.setScrollbarMode(2)
        except Exception as exc:
            optional_failure("ui.portal_manager_list_native", exc)
        # Repaint once so the dynamic Settings assets replace the safe fallback.
        if self._mode == "actions":
            self._render_actions(self._safe_index())
        elif self._mode == "multi":
            self._render_multi(self._safe_index())

    def _safe_index(self):
        try:
            return int(self["list"].getSelectedIndex() or 0)
        except Exception:
            return 0

    def _move(self, direction):
        try:
            if direction == "up": self["list"].wrap_up()
            elif direction == "down": self["list"].wrap_down()
            elif direction == "left": self["list"].page_left()
            elif direction == "right": self["list"].page_right()
        except Exception as exc:
            optional_failure("ui.portal_manager_nav", exc)

    def _selected_portal(self):
        try:
            idx = self.parent._index()
            if idx is not None and 0 <= idx < len(self.parent.profiles):
                return self.parent.profiles[idx]
        except Exception as exc:
            optional_failure("ui.portal_selected",exc)
        return None

    @staticmethod
    def _portal_name(profile, index=0):
        p = profile if isinstance(profile, dict) else {}
        if str(p.get("source_type") or "").lower() == "m3u":
            return str(p.get("name") or ("M3U Playlist %d" % (index + 1)))
        return str(p.get("name") or ("Portal Server %d" % (index + 1)))

    def _action_value(self, action):
        profile = self._selected_portal() or {}
        if action == "check_all": return "%d enabled" % len(getattr(self.parent, "profiles", []) or [])
        if action == "enable_disabled":
            try: return "%d disabled" % len(load_disabled_profiles())
            except Exception: return "Disabled portals"
        if action == "rename": return self._portal_name(profile) if profile else "No portal selected"
        if action == "edit":
            raw = str(profile.get("portal") or "")
            return raw[:30] if raw else "No portal selected"
        if action == "device_profile": return str(profile.get("device_profile") or "Auto").upper() if profile else "No portal selected"
        if action == "select_portals": return "%d portals • Multi-delete" % len(getattr(self.parent, "profiles", []) or [])
        return ""

    @staticmethod
    def _settings_icon(icon_rel):
        """Use the exact 40x40 icon copies used by Settings Test8.

        Enigma2 MultiContent clips pixmaps instead of scaling them; handing it
        the authored 256x256 source icon is why Test30 looked icon-less on the
        receiver.
        """
        try:
            base = os.path.basename(str(icon_rel or ""))
            compact = asset("settings_icons_40/" + base) if base else ""
            if compact and os.path.isfile(compact):
                return compact
        except Exception as exc:
            optional_failure("ui.portal_icon_compact",exc)
        try:
            return asset(icon_rel)
        except Exception:
            return ""

    def _render_actions(self, selected=0):
        self._mode = "actions"
        entries = list(self._ACTIONS)
        selected = max(0, min(int(selected or 0), max(0, len(entries) - 1))) if entries else 0
        rows = []
        for idx, (title, action, desc, icon_rel) in enumerate(entries):
            value = self._action_value(action)
            meta = {
                "selected": bool(idx == selected), "value": value,
                "center_title": not bool(value),
                "row_asset": self._row_asset, "row_selected_asset": self._row_selected_asset,
                "value_color": self._value_color,
            }
            rows.append((_(title), self._settings_icon(icon_rel), action, meta))
        self._rebuilding = True
        try:
            self["list"].set_icon_rows(rows)
            if rows: self["list"].moveToIndex(selected)
        finally:
            self._rebuilding = False
        self._visual_index = selected
        self._update_status()

    def _render_multi(self, selected=0):
        self._mode = "multi"
        self._multi_profiles = list(load_profiles())
        valid = set(range(len(self._multi_profiles)))
        self._multi_selected.intersection_update(valid)
        selected = max(0, min(int(selected or 0), max(0, len(self._multi_profiles) - 1))) if self._multi_profiles else 0
        rows = []
        for idx, profile in enumerate(self._multi_profiles):
            picked = idx in self._multi_selected
            is_m3u = str(profile.get("source_type") or "").lower() == "m3u"
            identity = str(profile.get("mac") or "M3U")
            value = (("SELECTED • " if picked else "") + identity)[:32]
            meta = {
                "selected": bool(idx == selected), "value": value,
                "row_asset": self._row_asset, "row_selected_asset": self._row_selected_asset,
                "value_color": self._value_color,
            }
            icon_rel = "settings_icons/multi_search.png" if picked else ("settings_icons/web_access.png" if not is_m3u else "settings_icons/channel_list.png")
            rows.append((self._portal_name(profile, idx), self._settings_icon(icon_rel), profile, meta))
        self._rebuilding = True
        try:
            self["list"].set_icon_rows(rows)
            if rows: self["list"].moveToIndex(selected)
        finally:
            self._rebuilding = False
        self._visual_index = selected
        self._update_status()

    def _render_confirm(self):
        self._mode = "confirm"
        count = len(self._confirm_targets)
        rows = []
        specs = [
            (_("Delete %d selected portals") % count, "delete", _("PERMANENT"), "settings_icons/clean.png"),
            (_("Cancel"), "cancel", _("Keep all portals"), "settings_icons/recovery.png"),
        ]
        for idx, (title, token, value, icon_rel) in enumerate(specs):
            meta = {
                "selected": bool(idx == 0), "value": value,
                "row_asset": self._row_asset, "row_selected_asset": self._row_selected_asset,
                "value_color": self._value_color,
            }
            rows.append((title, self._settings_icon(icon_rel), token, meta))
        self._rebuilding = True
        try:
            self["list"].set_icon_rows(rows); self["list"].moveToIndex(0)
        finally:
            self._rebuilding = False
        self._visual_index = 0
        self._update_status()

    def _selection_changed(self):
        if self._rebuilding:
            return
        idx = self._safe_index()
        if idx != self._visual_index:
            old = self._visual_index
            self._visual_index = idx
            # Only repaint the two affected rows.  Do not rebuild the whole list
            # on remote navigation; this is the same light interaction contract
            # used elsewhere after the restart/double-key work.
            if self._mode == "actions":
                entries = list(self._ACTIONS)
                for j in set((old, idx)):
                    if 0 <= j < len(entries):
                        title, action, _desc, icon_rel = entries[j]
                        value = self._action_value(action)
                        meta = {"selected": j == idx, "value": value, "center_title": not bool(value), "row_asset": self._row_asset, "row_selected_asset": self._row_selected_asset, "value_color": self._value_color}
                        self["list"].update_icon_row(j, (_(title), self._settings_icon(icon_rel), action, meta))
            elif self._mode == "multi":
                for j in set((old, idx)):
                    if 0 <= j < len(self._multi_profiles):
                        profile = self._multi_profiles[j]; picked = j in self._multi_selected
                        is_m3u = str(profile.get("source_type") or "").lower() == "m3u"
                        value = (("SELECTED • " if picked else "") + str(profile.get("mac") or "M3U"))[:32]
                        meta = {"selected": j == idx, "value": value, "row_asset": self._row_asset, "row_selected_asset": self._row_selected_asset, "value_color": self._value_color}
                        icon_rel = "settings_icons/multi_search.png" if picked else ("settings_icons/web_access.png" if not is_m3u else "settings_icons/channel_list.png")
                        self["list"].update_icon_row(j, (self._portal_name(profile, j), self._settings_icon(icon_rel), profile, meta))
            elif self._mode == "confirm":
                self._render_confirm_selection(old, idx)
        self._update_status()

    def _render_confirm_selection(self, old, idx):
        count = len(self._confirm_targets)
        specs = [
            (_("Delete %d selected portals") % count, "delete", _("PERMANENT"), "settings_icons/clean.png"),
            (_("Cancel"), "cancel", _("Keep all portals"), "settings_icons/recovery.png"),
        ]
        for j in set((old, idx)):
            if 0 <= j < len(specs):
                title, token, value, icon_rel = specs[j]
                meta = {"selected": j == idx, "value": value, "row_asset": self._row_asset, "row_selected_asset": self._row_selected_asset, "value_color": self._value_color}
                self["list"].update_icon_row(j, (title, self._settings_icon(icon_rel), token, meta))

    def _update_status(self):
        if self._mode == "multi":
            self["status"].setText(_("Select Portals • %d selected • OK Toggle • YELLOW Select all • RED Clear • BLUE Delete selected • BACK Portal Manager") % len(self._multi_selected))
            return
        if self._mode == "confirm":
            self["status"].setText(_("Permanent delete • %d portals selected • OK Confirm • BACK Return") % len(self._confirm_targets))
            return
        idx = self._safe_index()
        entries = list(self._ACTIONS)
        desc = _(entries[idx][2]) if 0 <= idx < len(entries) else _("Choose a portal tool")
        selected = self._selected_portal()
        portal_name = self._portal_name(selected) if selected else _("No portal selected")
        suffix = (" • " + self._last_summary) if self._last_summary else ""
        self["status"].setText(_("Portal Manager • %s • %s • ARROWS Navigate • OK Select • BACK Portals%s") % (portal_name, desc, suffix))

    def _ok(self):
        idx = self._safe_index()
        if self._mode == "actions":
            entries = list(self._ACTIONS)
            if not (0 <= idx < len(entries)):
                return
            title, action, _desc, _icon = entries[idx]
            if action == "portal_library":
                self.session.open(PortalLibraryListScreen, "portal")
                return
            if action == "xtream_library":
                self.session.open(PortalLibraryListScreen, "xtream")
                return
            if action == "select_portals":
                self._multi_selected = set(); self._render_multi(0); return
            self.close((title, action))
            return
        if self._mode == "multi":
            if not (0 <= idx < len(self._multi_profiles)):
                return
            if idx in self._multi_selected: self._multi_selected.remove(idx)
            else: self._multi_selected.add(idx)
            self._render_multi_row(idx)
            self._update_status()
            return
        if self._mode == "confirm":
            if idx == 0: self._delete_selected_confirmed()
            else: self._render_multi(0)

    def _render_multi_row(self, idx):
        if not (0 <= idx < len(self._multi_profiles)):
            return
        profile = self._multi_profiles[idx]; picked = idx in self._multi_selected
        is_m3u = str(profile.get("source_type") or "").lower() == "m3u"
        value = (("SELECTED • " if picked else "") + str(profile.get("mac") or "M3U"))[:32]
        meta = {"selected": idx == self._safe_index(), "value": value, "row_asset": self._row_asset, "row_selected_asset": self._row_selected_asset, "value_color": self._value_color}
        icon_rel = "settings_icons/multi_search.png" if picked else ("settings_icons/web_access.png" if not is_m3u else "settings_icons/channel_list.png")
        self["list"].update_icon_row(idx, (self._portal_name(profile, idx), self._settings_icon(icon_rel), profile, meta))

    def _cancel(self):
        if self._mode == "confirm":
            self._render_multi(0); return
        if self._mode == "multi":
            self._multi_selected = set(); self._render_actions(len(self._ACTIONS) - 1); return
        self.close(None)

    def _blue(self):
        if self._mode != "multi":
            return
        if not self._multi_selected:
            self._last_summary = "No portals selected"; self._update_status(); return
        self._confirm_targets = [self._multi_profiles[i] for i in sorted(self._multi_selected) if 0 <= i < len(self._multi_profiles)]
        if self._confirm_targets:
            self._render_confirm()

    def _yellow(self):
        if self._mode == "multi":
            self._multi_selected = set(range(len(self._multi_profiles))); self._render_multi(self._safe_index())

    def _red(self):
        if self._mode == "multi":
            self._multi_selected = set(); self._render_multi(self._safe_index())
        elif self._mode == "actions":
            self.close(None)

    def _green(self):
        if self._mode == "multi":
            self._ok()

    def _number(self, digit):
        if self._mode != "actions":
            return
        # Preserve the old ChoiceBox shortcut contract: 1..9 select rows 1..9,
        # 0 selects row 10.  Actions beyond ten remain available by scrolling.
        idx = 9 if int(digit) == 0 else int(digit) - 1
        if 0 <= idx < min(10, len(self._ACTIONS)):
            try: self["list"].moveToIndex(idx)
            except Exception as exc: optional_failure("ui.portal_manager_number", exc)
            self._ok()

    def _delete_selected_confirmed(self):
        targets = list(self._confirm_targets)
        if not targets:
            self._render_multi(0); return
        deleted = 0; warnings = 0; failed = 0
        for profile in targets:
            try:
                result = permanently_delete_profile(profile, session=self.session, purge_related=True) or {}
                if result.get("deleted"):
                    deleted += 1
                    cleanup = result.get("cleanup") or {}
                    if any(str(k).endswith("_error") and v for k, v in cleanup.items()): warnings += 1
                else:
                    failed += 1
            except Exception as exc:
                failed += 1; optional_failure("ui.portal_manager_bulk_delete", exc)
        try:
            self.parent.profiles = load_profiles(); self.parent.refresh(); self.parent._selection_changed()
        except Exception as exc:
            optional_failure("ui.portal_manager_parent_refresh", exc)
        self._multi_selected = set(); self._confirm_targets = []
        self._last_summary = "%d deleted" % deleted
        if warnings: self._last_summary += " • %d cleanup warnings" % warnings
        if failed: self._last_summary += " • %d failed" % failed
        self._render_actions(len(self._ACTIONS) - 1)


class PortalListScreen(Screen, AsyncScreenMixin, ImageLoaderMixin, TransitionMixin):
    skin = PORTAL_SELECTION_SETTINGS_SKIN
    PORTAL_ROW_W = 430
    PORTAL_ROW_H = 80

    def __init__(self, session):
        Screen.__init__(self, session)
        self._async_init()
        self.onClose.append(self._stop_async)
        self.onClose.append(self._image_stop)
        self.profiles = load_profiles()
        # A brand-new plugin session must start content grids from page 1.
        # Test69 Lean: navigation reset is session-RAM scoped by begin_plugin_launch().
        # Do NOT rewrite + fsync one state JSON per portal every time the plugin opens.
        # Persistent favorites/resume/home state remain untouched and Grid navigation
        # cannot leak across launches because its key includes current_plugin_launch().
        self._portal_old_service = _plugin_original_service_getter() if _plugin_service_captured_getter() else None
        try:self.session.nav.stopService()
        except Exception as exc:optional_failure("ui",exc)
        self.onClose.append(self._restore_background_service)
        self["title"] = Label("")
        self["clock"] = Label(_("SELECT PORTAL"))
        initial_warning = _("Ready")
        self["status"] = Label(initial_warning)
        self["page_bg"] = Pixmap()
        self["ambient_bg"] = Pixmap()
        self["hero_backdrop"] = Pixmap()
        self["list"] = IconMenuList([], width=self.PORTAL_ROW_W, item_height=self.PORTAL_ROW_H, icon_size=40, primary_font=21, secondary_font=15, row_style="settings_episode")
        self["source_badges"] = IconMenuList([], width=self.PORTAL_ROW_W, item_height=self.PORTAL_ROW_H, icon_size=40, primary_font=21, secondary_font=15, row_style="settings_episode")
        self["portal_page"] = Label("")
        self._portal_row_asset = asset("series_floating_row.png")
        self._portal_row_selected_asset = asset("series_floating_row_selected.png")
        self._portal_value_color = int("74d8ff", 16)
        self["list_bg"] = Label("")
        self["list_top"] = Label("")
        self["list_bottom"] = Label("")
        self["list_left"] = Label("")
        self["list_right"] = Label("")
        self._portal_page_size = 11
        self._portal_page = 1
        self["preview"] = Pixmap()
        self["detail_url_card"] = Pixmap()
        self["detail_mac_card"] = Pixmap()
        self["detail_status_card"] = Pixmap()
        self["detail_expiry_card"] = Pixmap()
        # Four fixed portal-detail icons. Keep the approved geometry exactly
        # as-is, but expose them as real Pixmap widgets so OpenBH cannot drop
        # the static ePixmap layer during adaptive glass redraws.
        self["detail_url_icon"] = Pixmap()
        self["detail_mac_icon"] = Pixmap()
        self["detail_status_icon"] = Pixmap()
        self["detail_expiry_icon"] = Pixmap()
        self["detail_bg"] = Label("")
        self["detail_top"] = Label("")
        self["detail_bottom"] = Label("")
        self["detail_left"] = Label("")
        self["detail_right"] = Label("")
        for _prefix in ("detail_url", "detail_mac", "detail_status", "detail_expiry", "footer"):
            self[_prefix + "_bg"] = Label("")
            self[_prefix + "_top"] = Label("")
            self[_prefix + "_bottom"] = Label("")
            self[_prefix + "_left"] = Label("")
            self[_prefix + "_right"] = Label("")
        self["profile_name"] = Label(_("Portal server"))
        self["profile_url"] = Label("-")
        self["profile_mac"] = Label("-")
        self["profile_status"] = Label(_("UNKNOWN"))
        self["profile_expiry"] = Label("-")
        self._portal_visual_index = 0
        self._portal_rebuilding = False
        # compatibility labels retained but visually de-emphasized
        self["profile_info"] = Label("")
        self["profile_state"] = Label("")
        self["red"] = Label(_("Disable"))
        self["green"] = Label(_("Rename"))
        self["yellow"] = Label(_("Check All"))
        self["blue"] = Label(_("Edit Order"))
        self._reorder_mode = False
        self._portal_progress_jobs = queue.Queue()
        self._portal_progress_timer = eTimer()
        self._portal_progress_conn = None
        try:
            self._portal_progress_conn = self._portal_progress_timer.timeout.connect(self._drain_portal_progress)
        except Exception:
            self._portal_progress_timer.callback.append(self._drain_portal_progress)
        try:self._portal_progress_timer.start(300, False)
        except Exception as exc:optional_failure("ui.portal_progress",exc)
        self.onClose.append(self._stop_portal_progress)
        self.onClose.append(self._stop_portal_ui_hooks)
        self._image_init("preview", (310, 245), {"portal": ""}, None)
        self.onLayoutFinish.append(self._layout_ready)
        try:self.onShown.append(self._portal_list_shown)
        except Exception as exc:optional_failure("ui",exc)
        self["list"].onSelectionChanged.append(self._selection_changed)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "MenuActions", "NumberActions", "InfoActions", "DirectionActions"], {
            "cancel": self._portal_cancel, "green": self.rename_selected_portal, "red": self.delete_portal,
            "yellow": self.check_all_portals, "blue": self.toggle_reorder_mode, "ok": self._portal_ok,
            "up": self._portal_up, "down": self._portal_down, "left": self._portal_prev_page, "right": self._portal_next_page,
            "menu": self.open_portal_tools, "info": self.open_diagnostics,
        }, -1)
        self.refresh()

    def _stop_portal_progress(self):
        try:self._portal_progress_timer.stop()
        except Exception as exc:optional_failure("ui.portal_progress_stop",exc)
        try:
            if self._portal_progress_conn is not None:self._portal_progress_conn.disconnect()
        except Exception as exc:optional_failure("ui.portal_progress_stop",exc)
        try:
            if self._drain_portal_progress in self._portal_progress_timer.callback:self._portal_progress_timer.callback.remove(self._drain_portal_progress)
        except Exception as exc:optional_failure("ui.portal_progress_callback",exc)

    def _stop_portal_ui_hooks(self):
        try:
            while True:self._portal_progress_jobs.get_nowait()
        except queue.Empty:
            pass
        except Exception as exc:
            optional_failure("ui.portal_progress_queue_drain",exc)
        for hook_name, callback in (
            ("onLayoutFinish", self._layout_ready),
            ("onShown", self._portal_list_shown),
        ):
            try:
                hooks=getattr(self,hook_name,None)
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:
                optional_failure("ui.portal_hook_cleanup",exc)
        try:
            callbacks=self["list"].onSelectionChanged
            if self._selection_changed in callbacks:callbacks.remove(self._selection_changed)
        except Exception as exc:
            optional_failure("ui.portal_selection_cleanup",exc)

    def _drain_portal_progress(self):
        if getattr(self, "_screen_closed", False):
            return
        latest = None
        while True:
            try:latest = self._portal_progress_jobs.get_nowait()
            except queue.Empty:break
        if latest:
            done,total,name,success = latest
            mark = _("OK") if success else _("FAILED")
            self["status"].setText(_("Checking %d/%d  •  %s  •  %s") % (done,total,str(name)[:34],mark))

    def _portal_cancel(self):
        if self._reorder_mode:
            self._set_reorder_mode(False)
            return
        self.close()

    def _portal_ok(self):
        if self._reorder_mode:
            self._set_reorder_mode(False)
            return
        self.open_portal()

    def rename_selected_portal(self):
        idx = self._index()
        if idx is None or self._busy:
            return
        self._editing_profile = self.profiles[idx]
        current_name = str(self._editing_profile.get("name") or "Portal Server %d" % (idx + 1))
        if VirtualKeyBoard is not None:
            try:
                self.session.openWithCallback(self._portal_renamed, VirtualKeyBoard, title=_("Portal name"), text=current_name)
                return
            except Exception as exc:
                optional_failure("ui.portal_rename_keyboard", exc)
        self.session.openWithCallback(
            self._portal_renamed, InputBox, title=_("Portal name"), text=current_name, maxSize=80
        )

    def _set_reorder_mode(self, enabled):
        self._reorder_mode = bool(enabled and self.profiles and not self._busy)
        self["blue"].setText(_("Done") if self._reorder_mode else _("Edit Order"))
        if self._reorder_mode:
            self["status"].setText(_("Edit order  •  UP/DOWN moves the selected portal  •  BLUE/OK saves"))
        else:
            self["status"].setText(_("Portal order saved"))

    def toggle_reorder_mode(self):
        if self._busy or not self.profiles:
            return
        self._set_reorder_mode(not self._reorder_mode)

    def _portal_up(self):
        if self._reorder_mode:
            self._move_selected_portal(-1)
            return
        try:self["list"].wrap_up()
        except Exception as exc:optional_failure("ui.portal_nav",exc)

    def _portal_down(self):
        if self._reorder_mode:
            self._move_selected_portal(1)
            return
        try:self["list"].wrap_down()
        except Exception as exc:optional_failure("ui.portal_nav",exc)

    def _portal_change_page(self, delta):
        if self._reorder_mode or not self.profiles:
            return
        idx = self._index()
        if idx is None:
            idx = 0
        row = idx % self._portal_page_size
        pages = max(1, (len(self.profiles) + self._portal_page_size - 1) // self._portal_page_size)
        current = idx // self._portal_page_size
        target_page = max(0, min(pages - 1, current + int(delta)))
        if target_page == current:
            return
        target = min(len(self.profiles) - 1, target_page * self._portal_page_size + row)
        self["list"].moveToIndex(target)
        self._selection_changed()

    def _portal_prev_page(self):
        if self._reorder_mode or not self.profiles:
            return
        # Use the exact same list navigation primitive as every other scrolling
        # Ultra Stalker list: preserve row between pages; first-page LEFT -> #1.
        try:self["list"].page_left()
        except Exception as exc:optional_failure("ui.portal_page_left",exc)
        self._selection_changed()

    def _portal_next_page(self):
        if self._reorder_mode or not self.profiles:
            return
        # Same-row page jump; final-page RIGHT -> actual final item.
        try:self["list"].page_right()
        except Exception as exc:optional_failure("ui.portal_page_right",exc)
        self._selection_changed()

    def _move_selected_portal(self, delta):
        idx = self._index()
        if idx is None or not self.profiles:
            return
        target = max(0, min(len(self.profiles)-1, idx + int(delta)))
        if target == idx:
            self["status"].setText(_("Already at the top") if delta < 0 else _("Already at the bottom"))
            return
        previous = list(self.profiles)
        self.profiles[idx], self.profiles[target] = self.profiles[target], self.profiles[idx]
        try:
            save_profiles(self.profiles)
        except Exception as exc:
            self.profiles = previous
            self.refresh()
            self["status"].setText(_("Order save failed: %s") % exc)
            return
        self._render_portal_rows(target)
        self._selection_changed()
        self["status"].setText(_("Moved to position %d of %d  •  BLUE/OK when done") % (target+1, len(self.profiles)))

    def _portal_list_shown(self):
        # External edits to portals.txt must become visible the first time the
        # user returns to this screen. Reloading this tiny local config is cheap
        # and deliberately does not touch channel/VOD/artwork caches.
        try:
            current_key=None
            idx=self._index()
            if idx is not None and self.profiles:
                p=self.profiles[idx];current_key=(str(p.get("portal") or "").rstrip("/").lower(),str(p.get("mac") or "").upper())
            fresh=load_profiles()
            if fresh != self.profiles:
                self.profiles=fresh
                target=0
                if current_key:
                    for pos,p in enumerate(self.profiles):
                        if (str(p.get("portal") or "").rstrip("/").lower(),str(p.get("mac") or "").upper())==current_key:
                            target=pos;break
                self._render_portal_rows(target)
                if self.profiles:self["list"].moveToIndex(target)
            elif self.profiles:
                self["list"].moveToIndex(max(0,min(getattr(self,"_portal_visual_index",0),len(self.profiles)-1)))
        except Exception as exc:optional_failure("ui.portal_fresh_import",exc)
        try:self._selection_changed()
        except Exception as exc:optional_failure("ui",exc)

    def _restore_background_service(self):
        restore_plugin_service(self.session)

    def open_diagnostics(self):
        idx = self._index()
        profile = self.profiles[idx] if idx is not None else None
        self.session.open(DiagnosticsScreen, profile)

    def open_portal_tools(self):
        # Premium Test8-style Portal Manager.  The screen returns the exact same
        # action tuple as the legacy ChoiceBox, so all proven portal operations
        # below remain untouched.
        self.session.openWithCallback(self._portal_tool_selected, PortalManagerPremiumScreen, self)

    def _portal_tool_selected(self,choice):
        if not choice:return
        action=choice[1];idx=self._index();profile=self.profiles[idx] if idx is not None else None
        if action=="check_all":return self.check_all_portals()
        if action=="enable_disabled":return self._choose_disabled_portal()
        if not profile:return
        if action=="rename":
            self._editing_profile=profile;self.session.openWithCallback(self._portal_renamed,InputBox,title=_("Portal name"),text=str(profile.get("name") or "Portal Server"),maxSize=80)
        elif action=="edit":
            self._editing_profile=profile;self.session.openWithCallback(self._portal_edit_url,InputBox,title=_("Portal / M3U URL"),text=str(profile.get("portal") or "https://"),maxSize=250)
        elif action=="tls_mode":
            self["status"].setText(_("TLS verification is locked to strict mode in this hardened build"))
        elif action=="http_fallback":
            self["status"].setText(_("HTTP fallback is disabled in this hardened build"))
        elif action=="device_profile":
            self._editing_profile=profile
            self.session.openWithCallback(self._portal_device_selected,ChoiceBox,title=_("MAG device profile"),list=[("Auto","auto"),("MAG250","mag250"),("MAG254","mag254"),("MAG256","mag256")])
        elif action=="export_bouquet":
            self._export_live_integration(profile)
        elif action=="unexport_bouquet":
            try:
                result=unexport_live_integration(profile,reload=True)
                self["status"].setText(_("Exported bouquet and EPG removed"))
            except Exception as exc:
                self["status"].setText(_("Remove export failed: %s")%exc)
        elif action=="duplicate":
            self._duplicating_profile=profile;self.session.openWithCallback(self._portal_duplicate_mac,InputBox,title=_("MAC for duplicate"),text="00:1A:79:",maxSize=17)
        elif action in ("move_up","move_down"):
            self.profiles=reorder_profile(profile,-1 if action=="move_up" else 1);self.refresh();self["status"].setText(_("Portal order saved"))
        elif action=="disable":self.delete_portal()
        elif action=="purge_data":
            self._purge_profile=profile;self.session.openWithCallback(self._purge_profile_confirmed,MessageBox,_("Clear plugin-owned data for this portal?\n\nThis removes its exported bouquet/EPG, matching recording refresh jobs/timers, Favorites, History and Resume data, but keeps the portal itself."),MessageBox.TYPE_YESNO)
        elif action=="delete_permanent":
            self._permanent_profile=profile;self.session.openWithCallback(self._permanent_delete_confirmed,MessageBox,_("Permanently delete this portal and its plugin-owned data?\n\nThis removes its exported bouquet/EPG, recording refresh jobs, Favorites, History and Resume data. Any matching Stalker recording timers will also be removed."),MessageBox.TYPE_YESNO)
        elif action=="diagnostics":self.session.open(DiagnosticsScreen,profile)

    def _export_live_integration(self, profile):
        if self._busy:
            return
        self["status"].setText(_("Exporting full Live bouquet..."))
        cfg=load_settings()
        def work(handle):
            client=_client_from_profile(profile,cfg.get("timeout",10))
            try:
                channels=client.ordered_all("itv","*",1,max_pages=cfg.get("search_max_pages",250),max_items=25000,cancel_event=handle.cancel_event)
                if handle.cancelled(): return {}
                return export_live_integration(profile,channels,cfg.get("service_type",4097))
            finally:
                client.close()
        def ok(result):
            server=start_proxy_server();reload_bouquets()
            if server is None:
                self["status"].setText(_("Bouquet export failed: dynamic proxy is not running"))
                self.session.open(MessageBox,_("The files were written but the dynamic bouquet proxy could not start. Remove/re-export the bouquet after resolving the port conflict."),MessageBox.TYPE_ERROR,timeout=12)
                return
            count=int((result or {}).get("channels") or 0)
            self["status"].setText(_("Bouquet exported • %d channels • proxy %s")%(count,(result or {}).get("proxy_port") or ""))
            self.session.open(
                MessageBox,
                _("Live bouquet exported with dynamic Stalker links.\n\n%d channels\n\nAn EPGImport source was also created. Open EPG-Importer, enable the Ultra Stalker source, then run an import.")%count,
                MessageBox.TYPE_INFO,timeout=15
            )
        self._run_async(work,ok,lambda e:self["status"].setText(_("Bouquet export failed: %s")%e))

    def _portal_tls_selected(self,choice):
        if not choice:return
        old=getattr(self,"_editing_profile",None) or {};new=dict(old)
        new["tls_mode"]="strict";new["tls_fallback_accepted"]=False
        try:
            changed = (str(old.get("tls_mode") or "auto") != str(new.get("tls_mode") or "auto") or bool(old.get("tls_fallback_accepted",False)) != bool(new.get("tls_fallback_accepted",False)))
            replace_profile(old,new,session=self.session)
            if changed:
                StalkerClient.clear_persisted_tls_pins(new.get("portal"), new.get("mac"))
            self.profiles=load_profiles();self.refresh();self["status"].setText(_("TLS security preference saved"))
        except Exception as exc:self["status"].setText(_("TLS mode save failed: %s")%exc)

    def _portal_http_fallback_selected(self,choice):
        if not choice:return
        old=getattr(self,"_editing_profile",None) or {};new=dict(old)
        new["allow_http_fallback"]=False
        new["http_fallback_accepted"]=False
        try:replace_profile(old,new,session=self.session);self.profiles=load_profiles();self.refresh();self["status"].setText(_("HTTP fallback disabled by hardened build"))
        except Exception as exc:self["status"].setText(_("HTTP fallback save failed: %s")%exc)

    def _portal_device_selected(self,choice):
        if not choice:return
        old=getattr(self,"_editing_profile",None) or {};new=dict(old);new["device_profile"]=choice[1]
        try:replace_profile(old,new,session=self.session);self.profiles=load_profiles();self.refresh();self["status"].setText(_("MAG profile saved: %s")%choice[1])
        except Exception as exc:self["status"].setText(_("MAG profile save failed: %s")%exc)

    def _portal_renamed(self,value):
        if value is None:return
        old=getattr(self,"_editing_profile",None) or {};new=dict(old);new["name"]=str(value or "").strip()[:80]
        try:replace_profile(old,new,session=self.session);self.profiles=load_profiles();self.refresh();self["status"].setText(_("Portal renamed"))
        except Exception as exc:self["status"].setText(_("Rename failed: %s")%exc)

    def _portal_edit_url(self,value):
        if not value:return
        self._edited_url=str(value).strip();old=getattr(self,"_editing_profile",{})
        self._edited_source_type="m3u" if _looks_like_m3u_url(self._edited_url) else "stalker"
        if requires_http_consent(self._edited_url):
            self.session.openWithCallback(self._portal_edit_http_confirmed,MessageBox,http_warning_for(self._edited_url),MessageBox.TYPE_YESNO)
            return
        if self._edited_source_type=="m3u":self._portal_edit_m3u_save()
        else:self.session.openWithCallback(self._portal_edit_mac,InputBox,title=_("MAC address"),text=str(old.get("mac") or "00:1A:79:"),maxSize=17)

    def _portal_edit_http_confirmed(self,answer):
        if not answer:
            self["status"].setText(_("HTTP portal update cancelled"))
            return
        old=getattr(self,"_editing_profile",{})
        if getattr(self,"_edited_source_type","stalker")=="m3u":self._portal_edit_m3u_save()
        else:self.session.openWithCallback(self._portal_edit_mac,InputBox,title=_("MAC address"),text=str(old.get("mac") or "00:1A:79:"),maxSize=17)

    def _portal_edit_m3u_save(self):
        old=getattr(self,"_editing_profile",None) or {};new=dict(old)
        new["portal"]=getattr(self,"_edited_url",old.get("portal"));new["source_type"]="m3u";new["mac"]="";new["account_state"]="M3U PLAYLIST";new["state"]="M3U • Not checked"
        new=mark_http_consent(new,True)
        try:
            _validate_profile_client(new);replace_profile(old,new,session=self.session)
            self.profiles=load_profiles();self.refresh();self["status"].setText(_("M3U source updated"))
        except Exception as exc:self.session.open(MessageBox,_("Update failed: %s")%exc,MessageBox.TYPE_ERROR,timeout=7)

    def _portal_edit_mac(self,value):
        if not value:return
        old=getattr(self,"_editing_profile",None) or {};new=dict(old);new["portal"]=getattr(self,"_edited_url",old.get("portal"));new["mac"]=str(value).strip().upper();new["source_type"]="stalker";new=mark_http_consent(new,True)
        if str(new.get("portal") or "").strip() != str(old.get("portal") or "").strip():
            new["allow_http_fallback"]=False;new["http_fallback_accepted"]=False;new["tls_fallback_accepted"]=False
        try:
            _validate_profile_client(new);replace_profile(old,new,session=self.session);self.profiles=load_profiles();self.refresh();self["status"].setText(_("Portal updated"))
        except Exception as exc:self.session.open(MessageBox,_("Update failed: %s")%exc,MessageBox.TYPE_ERROR,timeout=7)

    def _portal_duplicate_mac(self,value):
        if not value:return
        base=getattr(self,"_duplicating_profile",None) or {};clone=duplicate_profile(base);clone["mac"]=str(value).strip().upper();clone["state"]="Not checked";clone["health"]="unknown"
        try:
            _validate_profile_client(clone);rows=load_profiles();rows.append(clone);save_profiles(rows);enable_profile(clone);self.profiles=load_profiles();self.refresh();self["status"].setText(_("Portal duplicated"))
        except Exception as exc:self.session.open(MessageBox,_("Duplicate failed: %s")%exc,MessageBox.TYPE_ERROR,timeout=7)

    def _choose_disabled_portal(self):
        rows=load_disabled_profiles()
        if not rows:self.session.open(MessageBox,_("No disabled portals."),MessageBox.TYPE_INFO,timeout=5);return
        choices=[]
        for row in rows:
            label=(row.get("name") or row.get("portal") or "Portal")+"  •  "+str(row.get("mac") or "")
            choices.append((label,row))
        self.session.openWithCallback(self._disabled_portal_selected,ChoiceBox,title=_("Re-enable portal"),list=choices)

    def _disabled_portal_selected(self,choice):
        if not choice:return
        try:enable_profile(choice[1]);self.profiles=load_profiles();self.refresh();self["status"].setText(_("Portal enabled"))
        except Exception as exc:self["status"].setText(_("Enable failed: %s")%exc)

    def _purge_profile_confirmed(self,answer):
        if not answer:return
        try:
            cleanup=purge_profile_data(getattr(self,"_purge_profile",{}),session=self.session,remove_timers=True)
            errors=[str(v) for k,v in cleanup.items() if str(k).endswith("_error") and v]
            if errors:
                self["status"].setText(_("Portal data cleared with warnings: %s")%errors[0])
            else:
                self["status"].setText(_("Portal data cleared; portal profile kept"))
        except Exception as exc:self["status"].setText(_("Clear portal data failed: %s")%exc)

    def _permanent_delete_confirmed(self,answer):
        if not answer:return
        try:
            result=permanently_delete_profile(getattr(self,"_permanent_profile",{}),session=self.session,purge_related=True)
            self.profiles=load_profiles();self.refresh()
            cleanup=(result or {}).get("cleanup") or {};errors=[str(v) for k,v in cleanup.items() if str(k).endswith("_error") and v]
            self["status"].setText(_("Portal deleted with cleanup warning: %s")%errors[0] if errors else _("Portal and related plugin data permanently deleted"))
        except Exception as exc:self["status"].setText(_("Delete failed: %s")%exc)

    def choose_theme(self):
        choices = [(name.replace("_", " ").title(), name) for name in THEMES]
        self.session.openWithCallback(self._theme_selected, ChoiceBox, title=_("Choose visual theme"), list=choices, selection=THEMES.index(_active_theme()) if _active_theme() in THEMES else 0)

    def _theme_selected(self, choice):
        if not choice:
            return
        try:
            save_theme(choice[1])
            global _ACTIVE_THEME_CACHE
            _ACTIVE_THEME_CACHE = choice[1]
            self.session.open(MessageBox, _("Theme saved. Restart Enigma2 to apply: %s") % choice[0], MessageBox.TYPE_INFO, timeout=8)
        except Exception as exc:
            self.session.open(MessageBox, _("Theme save failed: %s") % exc, MessageBox.TYPE_ERROR, timeout=8)


    def _portal_hero_visuals(self):
        hero = {}
        try:
            with open(HOME_HERO_FILE, "r", encoding="utf-8") as handle:
                state = json.load(handle)
            hero = state.get("hero") if isinstance(state, dict) and isinstance(state.get("hero"), dict) else {}
        except Exception:
            hero = {}
        mood = hero.get("home_mood") if isinstance(hero.get("home_mood"), dict) else {}
        prepared = str(hero.get("prepared") or "")
        ambient = str(mood.get("ambient") or "")
        if not (prepared and os.path.isfile(prepared)):
            prepared = asset("nova_browser_bg.png")
        if not (ambient and os.path.isfile(ambient)):
            ambient = ""
        return prepared, ambient

    @staticmethod
    def _portal_settings_icon(name):
        try:
            compact = asset("settings_icons_40/" + str(name or ""))
            if compact and os.path.isfile(compact):
                return compact
        except Exception as exc:
            optional_failure("ui.portal_settings_icon",exc)
        return asset("home_settings.png")

    def _apply_portal_settings_materials(self):
        prepared, ambient = self._portal_hero_visuals()
        try:
            if ambient:
                self["ambient_bg"].instance.setPixmapFromFile(ambient); self["ambient_bg"].show()
            else:
                self["ambient_bg"].hide()
        except Exception as exc:
            optional_failure("ui.portal_settings_ambient", exc)
        try:
            if prepared and os.path.isfile(prepared):
                self["hero_backdrop"].instance.setPixmapFromFile(prepared); self["hero_backdrop"].show()
        except Exception as exc:
            optional_failure("ui.portal_settings_backdrop", exc)
        try:
            stamp = int(os.path.getmtime(prepared)) if prepared and os.path.isfile(prepared) else 0
            key = hashlib.sha1((str(prepared) + "|" + str(stamp) + "|settings-episode-row-v1").encode("utf-8", "ignore")).hexdigest()[:18]
            chrome = _build_dynamic_settings_episode_rows(prepared, key) or {}
            normal = str(chrome.get("normal") or "")
            selected = str(chrome.get("selected") or "")
            if normal and os.path.isfile(normal):
                self._portal_row_asset = normal
            if selected and os.path.isfile(selected):
                self._portal_row_selected_asset = selected
            accent = chrome.get("value_color")
            if not accent and prepared and os.path.isfile(prepared):
                primary, _secondary = _dynamic_palette(prepared)
                accent = _lift_dynamic_accent(primary, 0.48, 0.46)
            if isinstance(accent, (tuple, list)) and len(accent) >= 3:
                self._portal_value_color = (int(accent[0]) << 16) | (int(accent[1]) << 8) | int(accent[2])
        except Exception as exc:
            optional_failure("ui.portal_settings_material", exc)
        for name in ("list", "source_badges"):
            try:
                if self[name].instance is not None:
                    self[name].instance.setSelectionEnable(0)
                    self[name].instance.setTransparent(1)
                    self[name].instance.setScrollbarMode(2)
            except Exception as exc:
                optional_failure("ui.portal_settings_list_native", exc)

    def _layout_ready(self):
        self._image_layout_ready()
        self._apply_portal_settings_materials()
        # Test69 Lean: profiles were already loaded in __init__. Repainting is
        # enough; avoid a second synchronous disk parse during first layout.
        self.refresh()
        notices = consume_recovery_notices()
        if notices:
            self["status"].setText(_("Recovered malformed data safely • %s") % notices[-1])

    @staticmethod
    def _portal_display_parts(profile):
        p = profile if isinstance(profile, dict) else {}
        health = str(p.get("health") or "unknown").lower()
        raw_state = str(p.get("state") or "Not checked").strip()
        explicit = str(p.get("account_state") or "").strip()
        if str(p.get("source_type") or "").lower()=="m3u":
            if health in ("online","excellent"):status="M3U • ONLINE"
            elif health=="slow":status="M3U • SLOW"
            elif health=="offline":status="M3U • OFFLINE"
            else:status="M3U • READY"
        elif explicit:
            status = explicit
        elif health in ("online", "excellent"):
            status = "ONLINE"
        elif health == "slow":
            status = "SLOW"
        elif health == "offline":
            status = "OFFLINE"
        else:
            status = "NOT CHECKED"
        expiry = str(p.get("expiry") or "").strip()
        if not expiry and "/" in raw_state:
            parts = [x.strip() for x in raw_state.split("/") if x.strip()]
            for part in parts[1:]:
                if "INSECURE HTTP" not in part.upper():
                    expiry = part
                    break
        if not expiry:
            expiry = "No expiry date"
        return status[:18], expiry[:38]

    @staticmethod
    def _portal_card_expiry(expiry):
        text = " ".join(str(expiry or "").split())
        if not text:
            return "No expiry"
        text = re.sub(r",?\s*\d{1,2}:\d{2}\s*(?:am|pm)$", "", text, flags=re.I).strip(" ,")
        return text[:24]

    def _portal_row_value(self, profile):
        p = profile if isinstance(profile, dict) else {}
        status, _expiry = self._portal_display_parts(p)
        is_m3u = str(p.get("source_type") or "").lower() == "m3u"
        if is_m3u:
            return str(status or "M3U • READY")[:38]
        mac = str(p.get("mac") or "").strip()
        if mac:
            return (str(status or "PORTAL") + " • " + mac)[:38]
        return str(status or "PORTAL")[:38]

    @staticmethod
    def _portal_status_text(profile):
        p = profile if isinstance(profile, dict) else {}
        health = str(p.get("health") or "unknown").strip().lower()
        explicit = str(p.get("account_state") or "").strip().upper()
        is_m3u = str(p.get("source_type") or "").lower() == "m3u"
        if health in ("online", "excellent"):
            return "ONLINE"
        if health == "slow":
            return "SLOW"
        if health == "offline":
            return "OFFLINE"
        if explicit in ("ONLINE", "CONNECTED", "ACTIVE", "ENABLED"):
            return "ONLINE"
        if explicit in ("OFFLINE", "DISABLED", "EXPIRED", "BLOCKED"):
            return explicit[:12]
        if is_m3u:
            return "READY"
        return (explicit or "NOT CHECKED")[:12]

    def _portal_status_color(self, profile):
        status = self._portal_status_text(profile)
        if status == "ONLINE":
            # Deliberately vivid neon green so a working source is obvious at a
            # glance even against blue/cyan adaptive portal chrome.
            return 0x39FF88
        if status == "SLOW":
            return 0xFFD166
        if status in ("OFFLINE", "DISABLED", "EXPIRED", "BLOCKED"):
            return 0xFF6677
        return self._portal_value_color

    def _portal_row_tuple(self, index, selected_idx):
        p = self.profiles[index]
        is_m3u = str(p.get("source_type") or "").lower() == "m3u"
        name = p.get("name") or (("M3U Playlist %d" % (index + 1)) if is_m3u else ("Portal Server %d" % (index + 1)))
        identity = "M3U" if is_m3u else str(p.get("mac") or "").strip()
        meta = {
            "selected": bool(index == selected_idx),
            "status_text": self._portal_status_text(p),
            "status_color": self._portal_status_color(p),
            "identity_text": identity,
            "server_text": "",
            "server_color": 0xEEF6FB,
            "row_asset": self._portal_row_asset,
            "row_selected_asset": self._portal_row_selected_asset,
            "value_color": self._portal_value_color,
        }
        icon = self._portal_settings_icon("channel_list.png" if is_m3u else "web_access.png")
        return (name, icon, index, meta)

    def _render_source_badges(self, selected_idx=None):
        if selected_idx is None:
            selected_idx = self._index()
        current = self.profiles[selected_idx] if selected_idx is not None and 0 <= selected_idx < len(self.profiles) else {}
        current_m3u = str(current.get("source_type") or "").lower() == "m3u"
        portal_count = sum(1 for p in self.profiles if str((p or {}).get("source_type") or "").lower() != "m3u")
        m3u_count = len(self.profiles) - portal_count
        specs = (
            ("PORTAL", "web_access.png", portal_count, not current_m3u),
            ("M3U", "channel_list.png", m3u_count, current_m3u),
        )
        rows = []
        for title, icon_name, count, active in specs:
            meta = {
                "selected": bool(active and bool(self.profiles)),
                "value": "%d sources" % int(count),
                "row_asset": self._portal_row_asset,
                "row_selected_asset": self._portal_row_selected_asset,
                "value_color": self._portal_value_color,
            }
            rows.append((title, self._portal_settings_icon(icon_name), title.lower(), meta))
        try:
            self["source_badges"].set_icon_rows(rows)
        except Exception as exc:
            optional_failure("ui.portal_source_badges", exc)

    def _render_portal_rows(self, selected_idx=None):
        if selected_idx is None:
            selected_idx = self._index()
        if selected_idx is None:
            selected_idx = 0
        if self.profiles:
            selected_idx = max(0, min(int(selected_idx), len(self.profiles) - 1))
            rows = [self._portal_row_tuple(i, selected_idx) for i in range(len(self.profiles))]
        else:
            meta = {
                "selected": True, "value": "Add a Portal or M3U source",
                "row_asset": self._portal_row_asset, "row_selected_asset": self._portal_row_selected_asset,
                "value_color": self._portal_value_color,
            }
            rows = [("No profiles found", self._portal_settings_icon("web_access.png"), None, meta)]
        self._portal_rebuilding = True
        try:
            self["list"].set_icon_rows(rows)
            if self.profiles:
                self["list"].moveToIndex(selected_idx)
        finally:
            self._portal_rebuilding = False
        self._portal_visual_index = selected_idx
        self._render_source_badges(selected_idx if self.profiles else None)

    def _load_category_chrome(self):
        try:
            with open(HOME_HERO_FILE,"r",encoding="utf-8") as h: state=json.load(h)
            hero=state.get("hero") if isinstance(state,dict) else {}
            src=(hero or {}).get("display_backdrop_local") or (hero or {}).get("backdrop_local") or (hero or {}).get("prepared")
            if not src or not os.path.isfile(src): return {}
            key=hashlib.sha1((src+"|category176").encode("utf-8","ignore")).hexdigest()[:16]
            self._category_chrome=_build_category_adaptive_chrome(src,key,getattr(self,"media_type","") or "")
            card=self._category_chrome.get("info")
            if card and os.path.isfile(card):
                for n in ("info_card1","info_card2","info_card3"):
                    self[n].instance.setPixmapFromFile(card); self[n].show()
            return self._category_chrome
        except Exception as exc:
            optional_failure("ui.category_chrome_load",exc); return {}

    def _render_genre_rows(self):
        if self.level != "genres": return
        chrome=self._category_chrome or self._load_category_chrome()
        try: selected=self["list"].getSelectedIndex()
        except Exception: selected=0
        cfg=load_settings(); pinned=set(cfg.get("pinned_categories",{}).get(self.media_type,[])); protected=set(cfg.get("protected_categories",{}).get(self.media_type,[])); words=cfg.get("adult_keywords",[])
        rows=[]
        for i,e in enumerate(self.content_items):
            gid=str(e.get("id") or e.get("genre_id") or e.get("name") or e.get("title") or "")
            raw=e.get("title") or e.get("name") or e.get("id") or "Category"
            title=premium_title(raw,cfg.get("clean_titles",True))
            if gid in pinned:title="★  "+title
            sensitive=(gid in protected or any(w in str(e.get("name") or e.get("title") or "").casefold() for w in words))
            if cfg.get("parental_lock") and cfg.get("parental_mode","pin")=="pin" and sensitive:title="[PIN]  "+title
            details={"selected":i==selected,"row_asset":chrome.get("row"),"row_selected_asset":chrome.get("row_selected")}
            rows.append((title,asset("us89_folder_yellow_42.png"),e,details))
        self["list"].set_icon_rows(rows)
        try:self["list"].moveToIndex(max(0,min(selected,len(rows)-1)))
        except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _selection_changed(self):
        if getattr(self, "_portal_rebuilding", False):
            return
        idx = self._index()
        if idx is None:
            self["portal_page"].setText(_("No Portal / M3U sources"))
            self["status"].setText(_("MENU Portal Manager  •  Add a Portal or M3U source to begin"))
            self._render_source_badges(None)
            return

        old = getattr(self, "_portal_visual_index", idx)
        if idx != old:
            self._portal_visual_index = idx
            for j in set((old, idx)):
                if 0 <= j < len(self.profiles):
                    try:
                        self["list"].update_icon_row(j, self._portal_row_tuple(j, idx))
                    except Exception as exc:
                        optional_failure("ui.portal_settings_row_update", exc)

        total = len(self.profiles)
        try:
            nav_page_size = max(1, int(self["list"]._visible_page_rows()))
        except Exception:
            nav_page_size = 10
        pages = max(1, (total + nav_page_size - 1) // nav_page_size)
        page = (idx // nav_page_size) + 1
        p = self.profiles[idx]
        is_m3u = str(p.get("source_type") or "").lower() == "m3u"
        name = p.get("name") or (("M3U Playlist %d" % (idx + 1)) if is_m3u else ("Portal Server %d" % (idx + 1)))
        status, _expiry = self._portal_display_parts(p)
        self["portal_page"].setText(_("Page %d / %d  •  Source %d / %d  •  %s") % (page, pages, idx + 1, total, "M3U" if is_m3u else _("PORTAL")))
        self["status"].setText(_("%s  •  %s  •  ARROWS Navigate  •  OK Open  •  MENU Portal Manager") % (str(name)[:38], str(status)[:20]))
        self._render_source_badges(idx)

    def refresh(self):
        current = self._index()
        if current is None:
            current = getattr(self, "_portal_visual_index", 0)
        self._render_portal_rows(current)
        self._selection_changed()

    def _index(self):
        if not self.profiles:
            return None
        i = self["list"].getSelectedIndex()
        return i if 0 <= i < len(self.profiles) else None

    def reload_text_file(self):
        self.profiles = load_profiles(); self.refresh(); self["status"].setText(_("Profiles reloaded"))

    def add_portal(self):
        if not self._busy:
            self.session.openWithCallback(self._got_portal, InputBox, title=_("Portal / M3U URL"), text="https://")

    def _got_portal(self, portal):
        if portal:
            self._new_portal = str(portal).strip()
            if requires_http_consent(self._new_portal):
                self.session.openWithCallback(self._got_portal_http_confirmed,MessageBox,http_warning_for(self._new_portal),MessageBox.TYPE_YESNO)
                return
            self._route_new_source()

    def _got_portal_http_confirmed(self,answer):
        if answer:
            self._route_new_source()
        else:
            self["status"].setText(_("HTTP source was not added"))

    def _route_new_source(self):
        raw=str(getattr(self,"_new_portal","") or "").strip()
        if not raw:return
        if _looks_like_m3u_url(raw):
            self._new_source_type="m3u"
            self._save_m3u_profile()
            return
        self._new_source_type="detecting"
        self["status"].setText(_("Checking source type…"))
        def work(handle):
            return _probe_m3u_url(raw,timeout=min(int(load_settings().get("timeout",10) or 10),8),
                                  cancel_event=getattr(handle,"cancel_event",None))
        def ok(is_m3u):
            if is_m3u:
                self._new_source_type="m3u";self._save_m3u_profile()
            else:
                self._new_source_type="stalker"
                self["status"].setText(_("Stalker portal detected"))
                self.session.openWithCallback(self._got_mac,InputBox,title=_("MAC address"),text="00:1A:79:")
        def failed(exc):
            # A Stalker endpoint commonly rejects a playlist-style probe.  Do
            # not treat that as an add failure; continue with the normal MAC flow.
            self._new_source_type="stalker"
            self["status"].setText(_("Enter MAC for Stalker portal"))
            self.session.openWithCallback(self._got_mac,InputBox,title=_("MAC address"),text="00:1A:79:")
        if not self._run_async(work,ok,failed):
            failed(RuntimeError(_("Source probe unavailable")))

    def _save_m3u_profile(self):
        try:
            raw_portal=str(getattr(self,"_new_portal","") or "").strip()
            new_profile={"portal":raw_portal,"mac":"","source_type":"m3u","state":"M3U • READY",
                         "account_state":"M3U PLAYLIST","health":"unknown","source":"saved",
                         "allow_http_fallback":False,"http_fallback_accepted":False,
                         "tls_fallback_accepted":False,"tls_mode":"strict","device_profile":"auto"}
            new_profile=mark_http_consent(new_profile,True)
            _validate_profile_client(new_profile)

            rows=load_profiles()
            wanted=raw_portal.rstrip("/").casefold()
            replaced=False
            for idx,row in enumerate(rows):
                if (str(row.get("portal") or "").rstrip("/").casefold()==wanted and
                    str(row.get("source_type") or "").lower()=="m3u"):
                    rows[idx]=new_profile;replaced=True;break
            if not replaced:rows.append(new_profile)

            enable_profile(new_profile)
            save_profiles(rows)

            loaded=load_profiles()
            found=None
            for row in loaded:
                if str(row.get("source_type") or "").lower()!="m3u":continue
                saved_url=str(row.get("portal") or "").rstrip("/").casefold()
                if saved_url==wanted or saved_url.endswith(wanted):
                    found=row;break
            if found is None:
                raise RuntimeError(_("Playlist was written but did not survive profile reload"))

            self.profiles=loaded;self.refresh()
            try:
                idx=self.profiles.index(found)
                self["list"].moveToIndex(idx)
                self._portal_visual_index=idx
                self._selection_changed()
            except Exception as exc: diagnostic_failure("ui.portallist.failsoft", exc)
            self["status"].setText(_("M3U playlist added"))
        except Exception as exc:
            self.profiles=load_profiles()
            self.refresh()
            self.session.open(MessageBox,_("M3U add failed: %s")%exc,MessageBox.TYPE_ERROR,timeout=8)

    def _got_mac(self, mac):
        if not mac:
            return
        try:
            raw_portal = self._new_portal.strip()
            allow_fallback = not raw_portal.lower().startswith(("http://", "https://"))
            _validate_profile_client({"portal": raw_portal, "mac": mac.strip().upper(), "allow_http_fallback": False, "http_fallback_accepted": False})
            new_profile = {"portal": raw_portal, "mac": mac.strip().upper(), "source_type":"stalker", "state": "Not checked",
                           "allow_http_fallback": False, "http_fallback_accepted": False,
                           "tls_fallback_accepted": False, "tls_mode": "auto", "device_profile": "auto"}
            new_profile = mark_http_consent(new_profile, True)
            enable_profile(new_profile)
            self.profiles.append(new_profile)
            try:
                save_profiles(self.profiles)
            except Exception as exc:
                self.profiles.pop()
                self.session.open(MessageBox, _("Save failed: %s") % exc, MessageBox.TYPE_ERROR, timeout=7)
                return
            self.refresh()
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR, timeout=6)

    def delete_portal(self):
        idx = self._index()
        if idx is None or self._busy:
            return
        self._delete_index = idx
        self.session.openWithCallback(
            self._delete_confirmed,
            MessageBox,
            _("Permanently delete selected portal?\n\nIt will be removed from saved profiles, all portal import files, cached sessions and plugin-owned data."),
            MessageBox.TYPE_YESNO
        )

    def _delete_confirmed(self, answer):
        if not answer:
            return
        idx = getattr(self, "_delete_index", None)
        if idx is not None and 0 <= idx < len(self.profiles):
            old = self.profiles[idx]
            try:
                result = permanently_delete_profile(old, session=self.session, purge_related=True)
                self.profiles = load_profiles()
                self["status"].setText(_("Portal permanently deleted") if result.get("deleted") else _("Portal delete failed"))
            except Exception as exc:
                self["status"].setText(_("Delete failed: %s") % exc)
            self.refresh()

    def check_portal(self):
        idx = self._index()
        if idx is None or self._busy:
            return
        p = self.profiles[idx]; self["status"].setText(_("Checking portal..."))
        def work(handle):
            if handle.cancelled():return None
            started = time.monotonic(); client = _client_from_profile(p)
            try:
                info = client.account_info()
                if handle.cancelled():return None
                if handle.cancelled():return None
                return (info, int((time.monotonic() - started) * 1000),
                        client.health_snapshot(), client.security_warning)
            finally:
                client.close()
        def ok(result):
            info, latency, health_data, security_warning = result
            expiry = info.get("phone") or info.get("end_date") or info.get("expire_billing_date") or ""
            state = info.get("status") or info.get("account_status") or "ONLINE"
            warning = security_warning
            p["state"] = "%s%s%s" % (state, (" / " + str(expiry)) if expiry else "", (" / INSECURE HTTP" if warning else ""))
            p["account_state"] = str(state)
            p["expiry"] = str(expiry or "")
            p["latency_ms"] = health_data.get("latency_ms") or latency
            p["health"] = health_data.get("health") or ("online" if latency < 1500 else "slow")
            p.pop("active_connections", None)
            p.pop("max_connections", None)
            p.pop("connections_source", None)
            p["last_success"] = int(time.time()); p.pop("last_error", None)
            try:
                save_profiles(self.profiles)
                save_note = ""
            except Exception as exc:
                save_note = " (state not saved: %s)" % exc
            self.refresh()
            self["status"].setText((security_warning or "Handshake OK") + save_note)
        def fail(exc):
            p["state"]="OFFLINE"; p["health"]="offline"; p["last_error"]=str(exc)[:240]; p.pop("latency_ms", None)
            p.pop("active_connections", None); p.pop("max_connections", None); p.pop("connections_source", None)
            try: save_profiles(self.profiles)
            except Exception as exc: optional_failure("ui",exc)
            self.refresh(); self["status"].setText(_friendly_portal_error(exc))
        self._run_async(work, ok, fail)

    def check_all_portals(self):
        if self._busy or not self.profiles:
            return
        snapshot = list(self.profiles)
        self["status"].setText(_("Checking %d portals...") % len(snapshot))

        def work(handle):
            total = len(snapshot)
            cancel_event = getattr(handle, "cancel_event", None)

            def probe_one(profile):
                client = None
                try:
                    started = time.monotonic()
                    # Bulk check is deliberately health-first and bounded. The
                    # expensive EStalker VOD/create_link/player_api fallback stays
                    # on the explicit single-portal check where it belongs.
                    client = _client_from_profile(profile, timeout=4)
                    if str(profile.get("source_type") or "").lower() == "m3u" and hasattr(client, "probe"):
                        client.probe(cancel_event=cancel_event)
                        info = client.account_info()
                    else:
                        info = client.account_info()
                    latency = client.health_snapshot().get("latency_ms") or int((time.monotonic() - started) * 1000)
                    expiry = info.get("phone") or info.get("end_date") or info.get("expire_billing_date") or ""
                    state = info.get("status") or info.get("account_status") or "ONLINE"
                    warning = getattr(client, "security_warning", "")
                    label = "%s%s%s" % (state, (" / " + str(expiry)) if expiry else "", (" / INSECURE HTTP" if warning else ""))
                    return (profile, True, label, latency, str(expiry or ""), str(state))
                except Exception as exc:
                    return (profile, False, "OFFLINE: %s" % str(exc)[:100], 0, "", "OFFLINE")
                finally:
                    if client is not None:
                        try: client.close()
                        except Exception as exc: optional_failure("ui.portal_check_close", exc)

            results = []
            workers = max(1, min(4, total))
            with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="us-portal-check") as pool:
                future_map = {pool.submit(probe_one, profile): profile for profile in snapshot}
                done = 0
                for future in as_completed(future_map):
                    if handle.cancelled():
                        break
                    profile = future_map[future]
                    try:
                        result = future.result()
                    except Exception as exc:
                        result = (profile, False, "OFFLINE: %s" % str(exc)[:100], 0, "", "OFFLINE")
                    results.append(result)
                    done += 1
                    if not getattr(self, "_screen_closed", False):
                        try:
                            self._portal_progress_jobs.put((done, total, profile.get("name") or profile.get("portal") or "Portal", bool(result[1])))
                        except Exception as exc:
                            optional_failure("ui.portal_progress_queue", exc)
            return results

        def ok(results):
            failed = []
            for profile, success, state, latency, expiry, account_state in results:
                profile["state"] = state
                profile["account_state"] = account_state
                profile["expiry"] = expiry
                profile["health"] = ("excellent" if latency < 700 else ("online" if latency < 1500 else "slow")) if success else "offline"
                if latency:
                    profile["latency_ms"] = latency
                else:
                    profile.pop("latency_ms", None)
                if success:
                    profile.pop("active_connections", None)
                    profile.pop("max_connections", None)
                    profile.pop("connections_source", None)
                    profile["last_success"] = int(time.time())
                    profile.pop("last_error", None)
                else:
                    profile["last_error"] = state[:240]
                    failed.append(profile)
            try:
                save_profiles(self.profiles)
            except Exception as exc:
                self["status"].setText(_("Checks done; save failed: %s") % exc)
                self.refresh()
                return
            self.refresh()
            if not failed:
                self["status"].setText(_("All %d portals are working") % len(results))
                self.session.open(MessageBox, _("All portals passed the check."), MessageBox.TYPE_INFO, timeout=5)
                return
            self._failed_profiles = failed
            self["status"].setText(_("Check complete  •  %d working / %d failed") % (len(results)-len(failed), len(failed)))
            self.session.open(
                MessageBox,
                _("%d portal(s) working.  %d failed.\n\nFailed portals were NOT disabled; use RED if you want to disable one.") % (len(results)-len(failed), len(failed)),
                MessageBox.TYPE_INFO, timeout=8
            )

        self._run_async(work, ok, lambda e:self["status"].setText(_("Bulk check failed: %s") % e))

    def _delete_failed_confirmed(self, answer):
        failed = getattr(self, "_failed_profiles", [])
        self._failed_profiles = []
        if not answer or not failed:
            return
        failed_keys = set((p.get("portal", "").rstrip("/").lower(), p.get("mac", "").upper()) for p in failed)
        kept = [p for p in self.profiles if (p.get("portal", "").rstrip("/").lower(), p.get("mac", "").upper()) not in failed_keys]
        try:
            disable_profiles(failed)
            save_profiles(kept)
            self.profiles = kept
            self.refresh()
            self["status"].setText(_("Disabled %d failed portal(s)") % len(failed))
        except Exception as exc:
            self["status"].setText(_("Disabling failed portals failed: %s") % exc)

    def _portal_open_http_confirmed(self, answer):
        idx = getattr(self, "_http_open_index", None)
        self._http_open_index = None
        if not answer:
            self["status"].setText(_("HTTP portal was not opened"))
            return
        if idx is None or idx < 0 or idx >= len(self.profiles):
            return
        profile = mark_http_consent(self.profiles[idx], True)
        self.profiles[idx] = profile
        try:
            save_profiles(self.profiles)
        except Exception as exc:
            self.session.open(MessageBox, _("Could not save HTTP consent: %s") % exc, MessageBox.TYPE_ERROR, timeout=7)
            return
        try:
            self["list"].moveToIndex(idx)
        except Exception as exc:
            optional_failure("ui.http_consent_selection", exc)
        self.open_portal()

    def open_portal(self):
        idx = self._index()
        if idx is None or self._busy:
            return
        profile=self.profiles[idx]
        # Legacy/imported HTTP profiles may predate the explicit transport
        # consent field.  Require a one-time UI acknowledgement before the
        # first connection, then persist it so normal opens are not noisy.
        if requires_http_consent(profile.get("portal")) and not bool(profile.get("explicit_http_accepted", False)):
            self._http_open_index = idx
            self.session.openWithCallback(
                self._portal_open_http_confirmed, MessageBox,
                http_warning_for(profile.get("portal")), MessageBox.TYPE_YESNO
            )
            return
        try:
            _validate_profile_client(profile)
        except Exception as exc:
            self.session.open(MessageBox, _("Invalid profile: %s") % exc, MessageBox.TYPE_ERROR, timeout=7)
            return

        if str(profile.get("source_type") or "").lower()=="m3u":
            # Large get.php playlists can take minutes to download. Opening a
            # source must never block on a full catalogue parse/probe. Home and
            # the category screens load only what the user actually opens.
            self["status"].setText(_("Opening M3U playlist…"))
            self.session.openWithCallback(self._portal_home_closed, PortalHomeScreen, profile)
            return

        self.session.openWithCallback(self._portal_home_closed, PortalHomeScreen, profile)

    def _portal_home_closed(self, result=None):
        # Home can discover fresher account/expiry state than PortalList had at
        # construction time. Reload persisted profiles while preserving selection.
        try:
            idx=self._index()
            self.profiles=load_profiles()
            self.refresh()
            if idx is not None and self.profiles:
                try:self["list"].moveToIndex(max(0,min(int(idx),len(self.profiles)-1)))
                except Exception as exc: diagnostic_failure("ui.portallist.failsoft", exc)
            self._selection_changed()
        except Exception as exc:
            optional_failure("ui.portal_home_refresh", exc)



class PortalLibraryListScreen(PortalListScreen):
    """Passive bundled library rendered through the exact PortalListScreen shell.

    The normal Portal screen remains untouched.  This subclass only swaps its
    data source and key actions after the proven PortalListScreen constructor has
    built the native renderer/chrome.
    """

    def __init__(self, session, kind="portal"):
        self.library_kind = "xtream" if str(kind or "").lower() == "xtream" else "portal"
        self._library_selected = set()
        PortalListScreen.__init__(self, session)
        # Swap only the data source. No server check/initialization/network work
        # is performed by load_server_library().
        self._reload_library_profiles()
        self._portal_visual_index = 0
        self._portal_rebuilding = False
        self._reorder_mode = False
        # Exact PortalListScreen renderer, library-specific controls only.
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "cancel": self.close,
            "ok": self._library_toggle,
            "green": self._library_import,
            "red": self._library_clear,
            "yellow": self._library_select_all,
            "blue": self._library_clear,
            "up": self._portal_up,
            "down": self._portal_down,
            "left": self._portal_prev_page,
            "right": self._portal_next_page,
        }, -1)
        self.refresh()

    def _reload_library_profiles(self):
        # The native PortalListScreen refresh hooks normally reload the user's
        # saved profiles.  A library screen must stay pinned to the bundled
        # passive catalog instead, otherwise onLayoutFinish/onShown replaces
        # the catalog with the user's own Portal list.
        self.profiles = list(load_server_library(self.library_kind))

    def _layout_ready(self):
        # Keep the *exact* native Portal visual/material setup, but do not call
        # PortalListScreen._layout_ready() because its final two lines reload
        # load_profiles().  Reproduce only the proven visual half, then repaint
        # the passive library catalog.
        self._image_layout_ready()
        self._apply_portal_settings_materials()
        self._reload_library_profiles()
        self.refresh()

    def _portal_list_shown(self):
        # Native PortalListScreen intentionally reloads load_profiles() every
        # time it is shown.  For the Free Library this would overwrite the
        # bundled catalog with the user's own profiles.  Re-read only the
        # passive local catalog instead.
        try:
            idx = self._index()
            current = 0 if idx is None else idx
            self._reload_library_profiles()
            if self.profiles:
                current = max(0, min(int(current), len(self.profiles) - 1))
            else:
                current = 0
            self._render_portal_rows(current)
            if self.profiles:
                self["list"].moveToIndex(current)
            self._portal_visual_index = current
            self._selection_changed()
        except Exception as exc:
            optional_failure("ui.portal_library_shown", exc)

    def _portal_row_tuple(self, index, selected_idx):
        row = PortalListScreen._portal_row_tuple(self, index, selected_idx)
        try:
            title, icon, payload, meta = row
            meta = dict(meta or {})
            if index in self._library_selected:
                meta["status_text"] = "SELECTED"
                meta["status_color"] = 0x39FF88
            else:
                meta["status_text"] = "AVAILABLE"
                meta["status_color"] = self._portal_value_color
            return (title, icon, payload, meta)
        except Exception:
            return row

    def _selection_changed(self):
        if getattr(self, "_portal_rebuilding", False):
            return
        idx = self._index()
        if idx is None:
            title = "Xtream Library" if self.library_kind == "xtream" else "Portal Library"
            self["portal_page"].setText(_("%s • Library is empty") % title)
            self["status"].setText(_("BACK Portal Manager"))
            self._render_source_badges(None)
            return
        old = getattr(self, "_portal_visual_index", idx)
        if idx != old:
            self._portal_visual_index = idx
            for j in set((old, idx)):
                if 0 <= j < len(self.profiles):
                    try:
                        self["list"].update_icon_row(j, self._portal_row_tuple(j, idx))
                    except Exception as exc:
                        optional_failure("ui.portal_library_row_update", exc)
        total = len(self.profiles)
        try:
            nav_page_size = max(1, int(self["list"]._visible_page_rows()))
        except Exception:
            nav_page_size = 10
        pages = max(1, (total + nav_page_size - 1) // nav_page_size)
        page = (idx // nav_page_size) + 1
        title = "Xtream Library" if self.library_kind == "xtream" else "Portal Library"
        self["portal_page"].setText(_("%s  •  Page %d / %d  •  Source %d / %d") % (title, page, pages, idx + 1, total))
        self["status"].setText(_("%d selected  •  OK Select  •  GREEN Import Selected  •  YELLOW Select All  •  RED Clear  •  BACK Portal Manager") % len(self._library_selected))
        self._render_source_badges(idx)

    def _library_toggle(self):
        idx = self._index()
        if idx is None:
            return
        if idx in self._library_selected:
            self._library_selected.remove(idx)
        else:
            self._library_selected.add(idx)
        try:
            self["list"].update_icon_row(idx, self._portal_row_tuple(idx, idx))
        except Exception:
            self.refresh()
        self._selection_changed()

    def _library_clear(self):
        if not self._library_selected:
            return
        self._library_selected.clear()
        self.refresh()

    def _library_select_all(self):
        self._library_selected = set(range(len(self.profiles)))
        self.refresh()

    def _library_import(self):
        if not self._library_selected:
            self["status"].setText(_("Nothing selected  •  OK Select  •  GREEN Import Selected  •  BACK Portal Manager"))
            return
        chosen = [self.profiles[i] for i in sorted(self._library_selected) if 0 <= i < len(self.profiles)]
        try:
            result = import_server_library_profiles(chosen) or {}
        except Exception as exc:
            optional_failure("ui.portal_library_import", exc)
            self["status"].setText(_("Import failed  •  BACK Portal Manager"))
            return
        added = int(result.get("added", 0) or 0)
        dup = int(result.get("duplicates", 0) or 0)
        self._library_selected.clear()
        self.refresh()
        self["status"].setText(_("Import complete  •  %d added  •  %d already existed  •  no server checks were run") % (added, dup))
