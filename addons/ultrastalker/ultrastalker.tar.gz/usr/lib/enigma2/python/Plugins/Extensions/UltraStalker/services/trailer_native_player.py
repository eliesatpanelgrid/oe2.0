# -*- coding: utf-8 -*-
"""Stock Enigma2 MoviePlayer wrapper for TMDb trailers.

R126 keeps the working R124 TMBD-style 4097 + suburi playback path.
The important lifecycle fix is that Enigma maps STOP to ``leavePlayer`` but
EXIT to ``leavePlayerOnExit`` on many images.  R125 only intercepted STOP, so
EXIT could bypass trailer cleanup and leave the suburi audio service alive.
R126 routes both actions through the same explicit stop-and-close path.
"""
from __future__ import absolute_import

from enigma import eServiceReference
from Components.ActionMap import ActionMap, HelpableActionMap
from Screens.Screen import Screen

try:
    from Screens.InfoBar import InfoBar, MoviePlayer as _EnigmaMoviePlayer
except Exception:
    InfoBar = None
    _EnigmaMoviePlayer = None


def _service_ref(stream_url,title):
    ref=eServiceReference(4097,0,str(stream_url or "").strip())
    try:ref.setName(str(title or "Trailer"))
    except Exception:pass
    return ref


if _EnigmaMoviePlayer is not None:
    class NativeTrailerPlayer(_EnigmaMoviePlayer):
        ALLOW_SUSPEND=True

        def __init__(self,session,stream_url,title="Trailer"):
            self._ultra_ref=_service_ref(stream_url,title)
            try:
                _EnigmaMoviePlayer.__init__(self,session,self._ultra_ref)
            except TypeError:
                try:_EnigmaMoviePlayer.__init__(self,session,self._ultra_ref,None,None)
                except TypeError:_EnigmaMoviePlayer.__init__(self,session,self._ultra_ref,None)
            self.skinName='MoviePlayer'
            try:self.servicelist=InfoBar.instance and InfoBar.instance.servicelist
            except Exception:self.servicelist=None
            self["ultraTrailerActions"]=HelpableActionMap(
                self,"MoviePlayerActions",
                {
                    "leavePlayer":(self.leavePlayer,"leave trailer player"),
                    "leavePlayerOnExit":(self.leavePlayerOnExit,"leave trailer player"),
                },-1000
            )
            self["ultraTrailerBackActions"]=ActionMap(
                ["WizardActions","OkCancelActions"],
                {"back":self.leavePlayer,"cancel":self.leavePlayer},-1000
            )
            try:self.setTitle(str(title or "Trailer"))
            except Exception:pass
            self._ultra_stopped=False
            try:self.onClose.append(self._ultra_cleanup_on_close)
            except Exception:pass

        def _ultra_same_service(self):
            try:
                current=self.session.nav.getCurrentlyPlayingServiceReference()
                if current is None:return False
                try:return current.toString()==self._ultra_ref.toString()
                except Exception:return current==self._ultra_ref
            except Exception:
                return True

        def _ultra_stop_trailer(self,force=False):
            if self._ultra_stopped and not force:return
            try:
                if force or self._ultra_same_service():
                    self.session.nav.stopService()
            except Exception:
                pass
            self._ultra_stopped=True

        def _ultra_cleanup_on_close(self):
            # Safety net only.  Do not stop a different service if the image
            # has already restored one while closing MoviePlayer.
            try:
                if self._ultra_same_service():self.session.nav.stopService()
            except Exception:
                pass

        def leavePlayer(self,*args,**kwargs):
            # STOP key path.
            self._ultra_stop_trailer(force=True)
            self.close()

        def leavePlayerOnExit(self,*args,**kwargs):
            # EXIT/ESC has a distinct MoviePlayerActions action on Enigma2.
            # Route it through the same service stop instead of the stock
            # hide/quit policy, which was the source of R124/R125 background audio.
            self._ultra_stop_trailer(force=True)
            self.close()

        def doEofInternal(self,playing):
            self._ultra_stop_trailer(force=True)
            self.close()

        def showMovies(self):
            pass

        def openServiceList(self):
            try:
                if hasattr(self,'toggleShow'):self.toggleShow()
            except Exception:pass
else:
    class NativeTrailerPlayer(Screen):
        skin='''<screen name="NativeTrailerPlayer" position="0,0" size="1920,1080" backgroundColor="#000000" flags="wfNoBorder"></screen>'''
        ALLOW_SUSPEND=True
        def __init__(self,session,stream_url,title="Trailer"):
            Screen.__init__(self,session)
            self.session=session
            self._ref=_service_ref(stream_url,title)
            self["actions"]=ActionMap(
                ["WizardActions","OkCancelActions","MoviePlayerActions"],
                {"back":self.leavePlayer,"cancel":self.leavePlayer,"leavePlayer":self.leavePlayer,"leavePlayerOnExit":self.leavePlayer},-1000
            )
            self._ultra_stopped=False
            self.onShown.append(self._start)
            try:self.onClose.append(self._cleanup)
            except Exception:pass
        def _start(self):
            try:self.session.nav.playService(self._ref)
            except Exception:self.close()
        def _cleanup(self):
            if self._ultra_stopped:return
            try:self.session.nav.stopService()
            except Exception:pass
            self._ultra_stopped=True
        def leavePlayer(self,*args,**kwargs):
            self._cleanup()
            self.close()
