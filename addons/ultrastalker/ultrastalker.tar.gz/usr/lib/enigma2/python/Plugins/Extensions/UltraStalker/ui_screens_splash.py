"""Splash screen extracted from ui.py without changing behavior."""

from . import _
import os
import re
import threading

from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from enigma import eTimer, ePoint, getDesktop

from .storage import load_settings, load_theme, THEMES
from .log import optional_failure

FirstRunWizardScreen = None
PortalListScreen = None
WIZARD_DONE_FILE = ""
_schedule_startup_cache_maintenance = None
restore_plugin_service = None

# Splash.skin is evaluated when this module is imported, before ui.py can inject
# runtime callbacks. Keep the original asset/theme and scaling semantics local
# so importing the extracted screen is safe and visually identical.
ASSET_DIR = os.path.join(os.path.dirname(__file__), "assets_fhd")
_ACTIVE_THEME_CACHE = None
_ACTIVE_THEME_LOCK = threading.RLock()

def _active_theme():
    """Resolve the configured theme lazily; importing ui.py performs no config I/O."""
    global _ACTIVE_THEME_CACHE
    if _ACTIVE_THEME_CACHE in THEMES:
        return _ACTIVE_THEME_CACHE
    with _ACTIVE_THEME_LOCK:
        if _ACTIVE_THEME_CACHE in THEMES:
            return _ACTIVE_THEME_CACHE
        try:
            value = load_theme(readonly=True)
        except Exception:
            value = "nova_fhd"
        _ACTIVE_THEME_CACHE = value if value in THEMES else "nova_fhd"
        return _ACTIVE_THEME_CACHE

def asset(name):
    themed = os.path.join(ASSET_DIR, "themes", _active_theme(), name)
    return themed if os.path.exists(themed) else os.path.join(ASSET_DIR, name)

def _scale_skin(xml):
    try:
        desktop = getDesktop(0).size()
        width, height = int(desktop.width()), int(desktop.height())
    except Exception:
        return xml
    if width == 1920 and height == 1080:
        return xml
    sx, sy = width / 1920.0, height / 1080.0
    def pair(match):
        return '%s="%d,%d"' % (match.group(1), round(int(match.group(2))*sx), round(int(match.group(3))*sy))
    xml = re.sub(r'(position|size)="(\d+),(\d+)"', pair, xml)
    xml = re.sub(r'font="([^;]+);(\d+)"', lambda m: 'font="%s;%d"' % (m.group(1), max(14, round(int(m.group(2))*sy))), xml)
    return xml

def configure_splash_screen(
    first_run_wizard_screen,
    portal_list_screen,
    wizard_done_file,
    scale_skin,
    schedule_startup_cache_maintenance,
    asset_func,
    restore_plugin_service_func,
):
    global FirstRunWizardScreen, PortalListScreen, WIZARD_DONE_FILE
    global _schedule_startup_cache_maintenance, restore_plugin_service
    FirstRunWizardScreen = first_run_wizard_screen
    PortalListScreen = portal_list_screen
    WIZARD_DONE_FILE = wizard_done_file
    _schedule_startup_cache_maintenance = schedule_startup_cache_maintenance
    restore_plugin_service = restore_plugin_service_func

class SplashScreen(Screen):
    # V6.5.56: keep the exact V6.5.55 premium entry geometry, but use a
    # transparent-cutout copy of the original packaged master logo. Only the
    # external black canvas is removed; the badge itself remains native 600x240.
    # This prevents the black rectangle around the logo on the splash screen.
    skin = _scale_skin("""<screen name="SplashScreen" position="center,center" size="1920,1080" backgroundColor="#01040a" flags="wfNoBorder"><ePixmap position="0,0" size="1920,1080" pixmap="%s" alphatest="blend" zPosition="1"/><ePixmap position="660,292" size="600,240" pixmap="%s" alphatest="blend" scale="0" zPosition="5"/><widget name="status" position="510,600" size="900,42" font="Regular;24" halign="center" valign="center" foregroundColor="#d5e4ee" backgroundColor="#000000" transparent="1" zPosition="10"/><ePixmap position="580,670" size="760,14" pixmap="%s" alphatest="blend" zPosition="6"/><widget name="progress" position="586,675" size="748,4" borderWidth="0" backgroundColor="#0b1a27" foregroundColor="#6fd8ff" zPosition="7"/><widget name="progress_glow" position="557,656" size="86,42" pixmap="%s" alphatest="blend" transparent="1" zPosition="9"/><widget name="edition" position="710,722" size="500,30" font="Regular;17" halign="center" valign="center" foregroundColor="#66859a" backgroundColor="#000000" transparent="1" zPosition="10"/></screen>""" % (asset("splash_bg_premium.png"), asset("splash_logo_ultra_transparent.png"), asset("splash_premium_track.png"), asset("splash_premium_glow.png")))
    def __init__(self, session):
        Screen.__init__(self, session)
        self["status"] = Label(_("Preparing your experience"))
        self["edition"] = Label("ULTRA STALKER  •  PREMIUM")
        self["progress"] = ProgressBar(); self["progress"].setRange((0,100)); self["progress"].setValue(8)
        self["progress_glow"] = Pixmap()
        self._stage = 0
        self._runtime_loaded = False
        self._timer = eTimer(); self._conn = None
        try: self._conn = self._timer.timeout.connect(self._go)
        except Exception:
            try: self._timer.callback.append(self._go)
            except Exception as exc: optional_failure("ui",exc)
        self.onLayoutFinish.append(self._start_splash_timer)
        self.onClose.append(self._stop)
        self.onClose.append(self._safe_restore_service)

    def _safe_restore_service(self):
        try:
            if callable(restore_plugin_service):
                restore_plugin_service(self.session)
        except Exception as exc:
            optional_failure("ui.splash_restore", exc)

    def _ensure_runtime(self):
        if self._runtime_loaded and PortalListScreen is not None:
            return True
        try:
            from . import ui as runtime_ui
            try:
                runtime_ui.begin_plugin_launch(self.session)
            except Exception as exc:
                optional_failure("ui.splash_begin_launch", exc)
            self._runtime_loaded = bool(PortalListScreen is not None)
            if self._runtime_loaded and callable(_schedule_startup_cache_maintenance):
                try:_schedule_startup_cache_maintenance()
                except Exception as exc:optional_failure("ui.splash_maintenance_schedule", exc)
            return self._runtime_loaded
        except Exception as exc:
            optional_failure("ui.splash_lazy_runtime", exc)
            self["status"].setText(_("Ultra Stalker failed to initialize"))
            return False

    def _start_splash_timer(self):
        self._set_splash_progress(8)
        try:self._timer.start(20, True)
        except Exception:self._go()

    def _set_splash_progress(self, pct):
        pct=max(0,min(100,int(pct)))
        try:self["progress"].setValue(pct)
        except Exception as exc:optional_failure("ui", exc)
        try:
            desktop=getDesktop(0).size(); sx=float(desktop.width())/1920.0; sy=float(desktop.height())/1080.0
            bar_x, bar_w, glow_w = 586, 748, 86
            x=bar_x + int(round((bar_w * pct) / 100.0)) - glow_w//2
            x=max(bar_x-glow_w//2, min(bar_x+bar_w-glow_w//2, x))
            self["progress_glow"].instance.move(ePoint(int(round(x*sx)), int(round(656*sy))))
        except Exception as exc:optional_failure("ui", exc)

    def _stop(self):
        try:self._timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._conn is not None:self._conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._go in self._timer.callback:self._timer.callback.remove(self._go)
        except Exception as exc:optional_failure("ui.splash_timer_callback",exc)

    def _go(self):
        # Use short yielded stages before the expensive runtime import.  This lets
        # Enigma2 actually paint each state instead of freezing on one frame.
        if self._stage == 0:
            self._stage = 1
            self["status"].setText(_("Preparing interface")); self._set_splash_progress(24)
            try:self._timer.start(15, True)
            except Exception:self._go()
            return
        if self._stage == 1:
            self._stage = 2
            self["status"].setText(_("Loading Ultra Stalker")); self._set_splash_progress(46)
            try:self._timer.start(15, True)
            except Exception:self._go()
            return
        if self._stage == 2:
            self._stage = 3
            if not self._ensure_runtime():
                self._set_splash_progress(100)
                try:self._timer.start(1200, True)
                except Exception:self.close()
                return
            self["status"].setText(_("Preparing your library")); self._set_splash_progress(88)
            try:self._timer.start(20, True)
            except Exception:self._go()
            return
        if self._stage == 3:
            self._stage = 4
            self["status"].setText(_("Ready")); self._set_splash_progress(100)
            try:self._timer.start(25, True)
            except Exception:self._go()
            return
        if not self._runtime_loaded or PortalListScreen is None:
            self.close(); return
        self._stop()
        next_screen = PortalListScreen  # V7.0.17: welcome/first-run wizard permanently disabled
        try:self.session.openWithCallback(self._next_screen_closed, next_screen)
        except Exception:self.close()

    def _next_screen_closed(self, *args, **kwargs):
        self.close()
