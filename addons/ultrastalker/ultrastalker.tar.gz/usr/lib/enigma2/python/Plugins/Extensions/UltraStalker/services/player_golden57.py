# -*- coding: utf-8 -*-
"""Native Ultra Stalker player.

The screen lifecycle, InfoBar mixins, service-reference creation, engine
switching and resume behaviour are adapted from the user-supplied reference implementation
1.42 player. All paths, classes, settings and state remain independent inside
UltraStalker.
"""
from __future__ import absolute_import, print_function

from ..core.image_budget import image_budgeted
from .. import _

import hashlib
import json
import gc
import ctypes
import os
import signal
import time
import queue
import re
import threading
import unicodedata

try:
    from PIL import Image as _PILImage, ImageDraw as _ImageDraw, ImageFilter as _ImageFilter, ImageEnhance as _ImageEnhance
except Exception:
    _PILImage = None; _ImageDraw = None; _ImageFilter = None

from ..securefs import secure_private_dir
from ..persistent_cache import ROOT as PERSISTENT_CACHE_ROOT, GENERATED as PERSISTENT_GENERATED_DIR, persistent_write_gate
from ..ultra import (
    remember_content_quality,
)
from ..client import StalkerClient
from ..storage import add_recently_played, touch_recently_played, load_settings, save_settings
from ..title_clean import catalogue_title as _catalogue_title
from ..ui_artwork_helpers import _fit_live_picon_canvas
from .subtitles_online_golden57 import cached_subtitle, search_language, download_candidate, parse_srt
from ..core.recovery import runtime_interruption_action, smart_recovery_allowed
from ..core.runtime_log import breadcrumb as runtime_breadcrumb
from ..log import get_logger, optional_failure
from ..core.executor import LazyThreadPoolExecutor
from .player_runtime import _matching_external_player_pids, _descendant_pids, _all_external_player_pids

try:
    from urllib.parse import unquote, urlparse
except ImportError:
    from urllib import unquote
    from urlparse import urlparse

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
try:
    from Components.MultiContent import MultiContentEntryPixmapAlphaBlend
except Exception:
    MultiContentEntryPixmapAlphaBlend = MultiContentEntryPixmapAlphaTest
from Components.ProgressBar import ProgressBar
try:
    from Components.ScrollLabel import ScrollLabel
except Exception:
    ScrollLabel = Label
from Components.Pixmap import MultiPixmap, Pixmap
from Components.ServiceEventTracker import ServiceEventTracker
try:
    from Components.ServiceEventTracker import InfoBarBase
except Exception:
    class InfoBarBase(object):
        def __init__(self, *args, **kwargs):
            pass
from enigma import ePicLoad, ePoint, eSize, getDesktop, eServiceReference, eTimer, iPlayableService, iServiceInformation, gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, loadPNG
from skin import parseColor
try:
    from enigma import eDVBVolumecontrol
except Exception:
    eDVBVolumecontrol = None
from Screens.MessageBox import MessageBox
try:
    from Screens.SubtitleDisplay import SubtitleDisplay
except Exception:
    SubtitleDisplay = None
try:
    from Screens.ChoiceBox import ChoiceBox
except Exception:
    ChoiceBox = None
from Screens.Screen import Screen
from Tools.BoundFunction import boundFunction

LOG = get_logger()
# Beta59: player visuals and the native player share one progress-frame worker.
from .player_visuals import _PROGRESS_FRAME_EXECUTOR, _PROGRESS_FRAME_PENDING, _PROGRESS_FRAME_LOCK

# Stage-1 player split: helpers are imported back into this module so external
# callers keep the exact historical player_golden57 API surface.
from .player_core import (
    _PLAYER_BG_EXECUTOR, _process_rss_kb, _malloc_trim, force_session_silence,
    _optional_infobar, InfoBarAudioSelection, InfoBarMoviePlayerSummarySupport, eAVSwitch,
    InfoBarNotifications, InfoBarSeek, InfoBarSubtitleSupport, InfoBarSummarySupport,
    shutdown_player_workers, ASPECT_RATIOS, ENGINE_NAMES, _engine_label, _extension, _quality,
    _meta_text, _next_meta, _available_engines,
)
from .player_artwork import (
    _fallback_player_frames, _adaptive_player_frames, _progress_neon_frame,
    _schedule_progress_neon_frame, _asset, _player_asset, _letter_logo,
    _image_value, _adaptive_info_frames, _cached_poster,
    _prepare_player_poster_fill, _prepare_live_picon, _player_title_logo_source,
    _prepare_player_title_logo_cache_path, _prepare_player_title_logo,
    _apply_player_font_scale, PLUGIN_DIR, ASSET_DIR, PLAYER_ASSET_DIR,
    PLAYER_FALLBACK_INFOBAR_DIR, PLAYER_PROGRESS_X, PLAYER_PROGRESS_Y,
    PLAYER_PROGRESS_W, PLAYER_CRYSTAL_SIZE, PLAYER_CRYSTAL_Y, IMAGE_CACHE_DIR,
)
from .player_overlays import (
    ONLINE_SUBTITLE_SKIN, OnlineSubtitleOverlay, SUBTITLE_STYLE_COLORS, SUBTITLE_POSITION_PRESETS,
    _subtitle_color_name, _subtitle_position_name, _subtitle_glass_assets,
    SubtitleGlassList, SUBTITLE_GLASS_SKIN, SubtitleGlassChoiceScreen,
    PLAYER_INFO_SKIN, PlayerInformationOverlay, LIVE_ZAP_SKIN,
    _clean_live_name, _zap_palette, _zap_assets, _fit_zap_picon, UltraStalkerLiveZapList,
    IPTVInfoBarShowHide, NEXT_EPISODE_SKIN, UltraStalkerNextEpisodePrompt,
)

# Session-scoped switch intentionally remains owned by the main player module
# because UltraStalkerPlayer mutates it with ``global`` during playback.
NEXT_EPISODE_AUTOPLAY_SESSION = True

PLAYER_SKIN = """
<screen name="UltraStalkerPlayer" position="0,0" size="1920,1080" backgroundColor="#ff000000" flags="wfNoBorder">
    <widget name="resume_mask" position="0,0" size="1920,1080" font="Regular;1" foregroundColor="#000000" backgroundColor="#000000" transparent="0" zPosition="100" />

    <widget name="adaptive_main" position="60,792" size="1800,200" alphatest="blend" transparent="1" zPosition="5" />

    <!-- VOD/episode poster: separate oversized neon layer fixes Enigma2 clipping. -->
    <widget name="logo" position="60,617" size="250,375" alphatest="blend" scale="1" backgroundColor="#07111d" transparent="0" zPosition="7" />
    <widget name="poster_neon_halo" position="30,597" size="310,415" alphatest="blend" transparent="1" zPosition="9" />
    <widget name="adaptive_poster" position="50,607" size="270,395" alphatest="blend" transparent="1" zPosition="10" />
    <!-- Live-only 220x132 picon card, centered and aspect-safe. -->
    <!-- Adaptive frame stays behind the actual picon. The picon is the lit foreground subject. -->
    <widget name="adaptive_live_picon" position="97,828" size="240,152" alphatest="blend" transparent="1" zPosition="9" />
    <widget name="live_picon" position="107,838" size="220,132" alphatest="blend" scale="1" transparent="1" zPosition="12" />

    <!-- Live retains its original compact labels. VOD/episodes use the centered premium title area below. -->
    <widget name="channel" position="350,802" size="1010,46" font="Regular;29" halign="left" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="1" zPosition="6" />
    <widget name="category" position="1480,808" size="120,32" font="Regular;18" foregroundColor="#ffffff" backgroundColor="#132633" halign="center" valign="center" transparent="1" zPosition="6" />
    <widget name="quality" position="1615,808" size="110,32" font="Regular;18" foregroundColor="#d8e8ef" backgroundColor="#132633" halign="center" valign="center" transparent="1" zPosition="6" />
    <widget name="episode_marker" position="370,808" size="170,28" font="Regular;22" halign="left" valign="center" foregroundColor="#dce8ed" backgroundColor="#000000" transparent="1" zPosition="8" noWrap="1" />
    <widget name="vod_title" position="430,804" size="1220,72" font="Regular;52" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="1" zPosition="8" noWrap="1" />
    <widget name="title_logo" position="430,804" size="1220,72" alphatest="blend" scale="1" transparent="1" zPosition="9" />

    <!-- Clock/date live inside the main Player panel at its far right. -->
    <widget source="global.CurrentTime" render="Label" position="1725,804" size="110,38" font="Regular;31" halign="right" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="1" zPosition="10">
        <convert type="ClockToText">Format:%%H:%%M</convert>
    </widget>
    <widget source="global.CurrentTime" render="Label" position="1705,844" size="130,22" font="Regular;14" halign="right" valign="center" foregroundColor="#d7dee2" backgroundColor="#000000" transparent="1" zPosition="10">
        <convert type="ClockToText">Format:%%a %%d %%b %%Y</convert>
    </widget>

    <widget name="skip_hint" position="370,850" size="265,28" font="Regular;16" foregroundColor="#7fe8ff" backgroundColor="#000000" transparent="1" zPosition="8" />
    <widget name="now" position="650,850" size="525,28" font="Regular;18" foregroundColor="#d4dde3" backgroundColor="#000000" halign="center" transparent="1" zPosition="6" />
    <widget name="connection" position="1190,850" size="530,28" font="Regular;16" foregroundColor="#e0eef2" backgroundColor="#000000" halign="right" transparent="1" zPosition="7" />

    <widget source="session.CurrentService" render="Progress" position="370,890" size="1350,8" borderWidth="0" foregroundColor="#203542" backgroundColor="#203542" zPosition="5">
        <convert type="ServicePosition">Position</convert>
    </widget>
    <widget name="adaptive_progress_track" position="370,890" size="1350,8" alphatest="blend" transparent="1" zPosition="6" />
    <widget name="watched_progress_glow" position="0,0" size="1,1" borderWidth="0" foregroundColor="#000000" backgroundColor="#000000" transparent="1" zPosition="1" />
    <widget name="watched_progress" position="0,0" size="1,1" borderWidth="0" foregroundColor="#000000" backgroundColor="#000000" transparent="1" zPosition="1" />
    <widget name="progress_neon" position="370,877" size="1350,34" alphatest="blend" transparent="1" zPosition="9" />
    <widget name="progress_crystal" position="0,0" size="1,1" pixmap="%(blank)s" alphatest="blend" zPosition="1" />
    <widget source="session.CurrentService" render="Label" position="370,901" size="170,24" font="Regular;16" foregroundColor="#d8e0e5" backgroundColor="#000000" transparent="1" zPosition="6">
        <convert type="ServicePosition">Position,ShowHours</convert>
    </widget>
    <widget source="session.CurrentService" render="Label" position="1550,901" size="170,24" font="Regular;16" foregroundColor="#d8e0e5" backgroundColor="#000000" halign="right" transparent="1" zPosition="6">
        <convert type="ServicePosition">Length,ShowHours</convert>
    </widget>

    <!-- Adaptive bordered technical cards. -->
    <widget name="chip_video_quality" position="370,934" size="150,42" alphatest="blend" transparent="1" zPosition="5"/>
    <widget name="video_quality" position="370,934" size="150,42" font="Regular;17" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" />
    <widget name="chip_video_codec" position="570,934" size="130,42" alphatest="blend" transparent="1" zPosition="5"/>
    <widget name="video_codec" position="570,934" size="130,42" font="Regular;17" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" />
    <widget name="chip_audio_codec" position="750,934" size="120,42" alphatest="blend" transparent="1" zPosition="5"/>
    <widget name="audio_codec" position="750,934" size="120,42" font="Regular;17" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" />
    <widget name="chip_stream" position="920,934" size="150,42" alphatest="blend" transparent="1" zPosition="5"/>
    <widget name="extension" position="920,934" size="150,42" font="Regular;17" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" />
    <widget name="chip_audio" position="1120,934" size="150,42" alphatest="blend" transparent="1" zPosition="5"/>
    <widget name="audio_tag" position="1120,934" size="150,42" font="Regular;17" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" />
    <widget name="chip_subtitles" position="1320,934" size="170,42" alphatest="blend" transparent="1" zPosition="5"/>
    <widget name="subtitle_tag" position="1320,934" size="170,42" font="Regular;17" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" />
    <widget name="chip_engine" position="1540,934" size="210,42" alphatest="blend" transparent="1" zPosition="5"/>
    <widget name="engine" position="1540,934" size="210,42" font="Regular;16" foregroundColor="#d5e2e8" halign="center" valign="center" transparent="1" zPosition="6" />

    <!-- Runtime compatibility widgets. -->
    <widget name="brand" position="0,0" size="1,1" font="Regular;1" transparent="1" />
    <widget name="section" position="0,0" size="1,1" font="Regular;1" transparent="1" />
    <widget name="state" position="0,0" size="1,1" font="Regular;1" transparent="1" />
    <widget name="statusicon" position="0,0" size="1,1" alphatest="blend" pixmaps="%(play)s,%(pause)s,%(stop)s,%(ff)s,%(rw)s,%(slow)s,%(blank)s" />
    <widget name="speed" position="0,0" size="1,1" font="Regular;1" transparent="1" />
    <widget name="format_tag" position="0,0" size="1,1" font="Regular;1" transparent="1" />
    <widget name="transport_hint" position="0,0" size="1,1" font="Regular;1" transparent="1" />
    <widget name="media_meta" position="0,0" size="1,1" font="Regular;1" transparent="1" />
    <widget name="next_header" position="0,0" size="1,1" font="Regular;1" transparent="1" />
    <widget name="next" position="0,0" size="1,1" font="Regular;1" transparent="1" />
    <widget name="next_meta" position="0,0" size="1,1" font="Regular;1" transparent="1" />
    <widget name="description" position="0,0" size="1,1" font="Regular;1" transparent="1" />
    <widget name="online_subtitle" position="170,805" size="1580,150" font="Regular;38" halign="center" valign="bottom" foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="3,3" transparent="1" zPosition="4" />

    <!-- Premium key bar aligns directly under the main Player panel; buttons only. -->
    <widget name="adaptive_keybar" position="320,1002" size="1540,58" alphatest="blend" transparent="1" zPosition="5" />
    <ePixmap pixmap="%(cinred)s" position="385,1010" size="170,42" alphatest="blend" scale="1" zPosition="7" />
    <widget name="key_red" position="393,1010" size="154,42" font="Regular;22" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" />
    <ePixmap pixmap="%(cingreen)s" position="765,1010" size="170,42" alphatest="blend" scale="1" zPosition="7" />
    <widget name="key_green" position="773,1010" size="154,42" font="Regular;19" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" />
    <ePixmap pixmap="%(cinyellow)s" position="1145,1010" size="170,42" alphatest="blend" scale="1" zPosition="7" />
    <widget name="key_yellow" position="1153,1010" size="154,42" font="Regular;22" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" />
    <ePixmap pixmap="%(cinblue)s" position="1525,1010" size="170,42" alphatest="blend" scale="1" zPosition="7" />
    <widget name="key_blue" position="1533,1010" size="154,42" font="Regular;19" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" />
    <widget name="hint" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
</screen>
""" % {
    "mainpanel": _player_asset("us90_player_main_clean.png"),
    "posterframe": _player_asset("us8_player_poster_9_6_4_night.png"),
    "keybar": _player_asset("us8_player_keys_9_6_4_opaque_night.png"),
    "cinplay": _player_asset("cinematic_play.png"),
    "redkey": _player_asset("key_red_dot.png"),
    "greenkey": _player_asset("key_green_dot.png"),
    "yellowkey": _player_asset("key_yellow_dot.png"),
    "bluekey": _player_asset("key_blue_dot.png"),
    "cinred": _asset("us6521_key_red_170x42.png"),
    "cingreen": _asset("us6521_key_green_170x42.png"),
    "cinyellow": _asset("us6521_key_yellow_170x42.png"),
    "cinblue": _asset("us6521_key_blue_170x42.png"),
    "actionred": _asset("us15_action_red.png"),
    "actiongreen": _asset("us15_action_green.png"),
    "actionyellow": _asset("us15_action_yellow.png"),
    "actionblue": _asset("us15_action_blue.png"),
    "play": _player_asset("state_play.png"),
    "pause": _player_asset("state_pause.png"),
    "stop": _player_asset("state_stop.png"),
    "ff": _player_asset("state_ff.png"),
    "rw": _player_asset("state_rw.png"),
    "slow": _player_asset("state_slow.png"),
    "blank": _player_asset("state_blank.png"),
    "crystal": _player_asset("progress_crystal.png"),
}


PLAYER_SKIN=_apply_player_font_scale(PLAYER_SKIN)

def _capture_receiver_aspect_ratio():
    current_ar = None
    try:
        aspect_path = "/proc/stb/video/aspect"
        policy_path = "/proc/stb/video/policy"
        if os.path.exists(aspect_path) and os.path.exists(policy_path):
            with open(aspect_path, "r") as handle:
                aspect = handle.read().strip()
            with open(policy_path, "r") as handle:
                policy = handle.read().strip()
            if aspect == "4:3":
                if policy == "letterbox": current_ar = 0
                elif policy == "panscan": current_ar = 1
            elif aspect == "16:9":
                if policy == "letterbox": current_ar = 6
                elif policy == "panscan": current_ar = 3
                else: current_ar = 2
            elif aspect == "16:10":
                if policy == "letterbox": current_ar = 4
                elif policy == "panscan": current_ar = 5
    except Exception as exc:
        optional_failure("player.aspect_capture_proc", exc)
    if current_ar is None and eAVSwitch is not None:
        try:
            inst = eAVSwitch.getInstance()
            if hasattr(inst, "getAspectRatio"):
                current_ar = int(inst.getAspectRatio())
        except Exception as exc:
            optional_failure("player.aspect_capture_switch", exc)
    return current_ar

def _restore_receiver_aspect_ratio(value):
    if value is None or eAVSwitch is None:
        return False
    try:
        eAVSwitch.getInstance().setAspectRatio(int(value))
        return True
    except Exception as exc:
        optional_failure("player.aspect_restore", exc)
        return False

class UltraStalkerPlayer(
    InfoBarBase,
    IPTVInfoBarShowHide,
    InfoBarAudioSelection,
    InfoBarSeek,
    InfoBarNotifications,
    InfoBarSummarySupport,
    InfoBarSubtitleSupport,
    InfoBarMoviePlayerSummarySupport,
    Screen,
):
    """Full-screen live/VOD player with reference implementation-style InfoBar behaviour."""

    skin = PLAYER_SKIN
    ALLOW_SUSPEND = True

    def __init__(self, session, streamurl, name, media_type="itv", servicetype=4097, item=None, reuse_current=False):
        Screen.__init__(self, session)
        self.session = session
        self._return_aspect_ratio = _capture_receiver_aspect_ratio()
        self.streamurl = str(streamurl or "").strip()
        self.media_type = str(media_type or "itv")
        _raw_name = str(name or "Ultra Stalker stream")
        self.name = _clean_live_name(_raw_name) if self.media_type in ("itv","live") else (_catalogue_title(_raw_name) or _raw_name)
        self.item = item if isinstance(item, dict) else {}
        self._return_service_ref_string=str(self.item.get("_return_service_ref_string") or "")
        self._service_handoff_done=False
        self.reuse_current = bool(reuse_current and self.media_type in ("itv","live"))
        _zap_snapshot=list(self.item.get("_live_folder_channels") or []) if self.media_type in ("itv","live") else []
        self._zap_page_loader=self.item.get("_live_page_loader") if callable(self.item.get("_live_page_loader")) else None
        try:self._zap_page_size=max(1,int(self.item.get("_live_page_size") or len(_zap_snapshot) or 10))
        except Exception:self._zap_page_size=max(1,len(_zap_snapshot) or 10)
        try:self._zap_total=max(len(_zap_snapshot),int(self.item.get("_live_folder_total") or 0))
        except Exception:self._zap_total=len(_zap_snapshot)
        try:self._zap_index=max(0,int(self.item.get("_live_absolute_index") or 0))
        except Exception:self._zap_index=0
        try:_zap_page=max(1,int(self.item.get("_live_folder_page") or (self._zap_index//self._zap_page_size+1)))
        except Exception:_zap_page=max(1,self._zap_index//self._zap_page_size+1)
        if self.media_type in ("itv","live") and self._zap_total:
            self._zap_channels=[None]*self._zap_total
            _zap_base=max(0,(_zap_page-1)*self._zap_page_size)
            for _i,_row in enumerate(_zap_snapshot):
                _pos=_zap_base+_i
                if _pos<len(self._zap_channels) and isinstance(_row,dict):self._zap_channels[_pos]=_row
        else:
            self._zap_channels=_zap_snapshot
        self._zap_title=str(self.item.get("_live_folder_title") or "Live Channels")
        self._zap_last_ok=0.0
        self._zap_open=False
        self._zap_infobar_armed=False
        for mixin in (
            InfoBarBase,
            IPTVInfoBarShowHide,
            InfoBarAudioSelection,
            InfoBarSeek,
            InfoBarNotifications,
            InfoBarSummarySupport,
            InfoBarSubtitleSupport,
            InfoBarMoviePlayerSummarySupport,
        ):
            try:
                mixin.__init__(self)
            except Exception as exc:
                LOG.warning("Player mixin init failed (%s): %s", mixin, exc)

        cfg = load_settings()
        # Stage-4: Player settings are a session snapshot. The settings screen is
        # not reachable inside this Player, so repeatedly deep-copying the full
        # settings/API-key structure during timers and playback events adds I/O/CPU
        # without changing runtime behaviour. Keep the one normalized snapshot and
        # precompute hot-path values used by progress, resume and recovery logic.
        self._cfg_resume_behavior = str(cfg.get("resume_behavior", "always") or "always").lower()
        self._cfg_crash_safe_progress = bool(cfg.get("crash_safe_progress", True))
        self._cfg_progress_interval_ms = (int(cfg.get("progress_save_seconds", 10)) if self._cfg_crash_safe_progress else 10) * 1000
        self._cfg_next_episode_countdown = int(cfg.get("next_episode_countdown", 10) or 10)
        self._cfg_timeout = max(8.0, float(cfg.get("timeout", 10) or 10) + 5.0)
        self._cfg_diagnostic_logging = bool(cfg.get("diagnostic_logging", False))
        self._cfg_completion_threshold = max(80, min(99, int(cfg.get("completion_threshold", 93)))) / 100.0
        self._cfg_completion_remaining_pts = max(30, min(900, int(cfg.get("completion_remaining_seconds", 180)))) * 90000
        self._cfg_auto_remove_completed = bool(cfg.get("auto_remove_completed", True))
        self._history_profile = {"portal": self.item.get("_portal", ""), "mac": self.item.get("_mac", "")}
        self._history_item = self.item.get("_history_item") if isinstance(self.item.get("_history_item"), dict) else self.item
        try:configured_engine=int(cfg.get("service_type",servicetype))
        except Exception:configured_engine=int(servicetype or 4097)
        if configured_engine not in (1,4097,5001,5002,8193):configured_engine=4097
        self._cfg_service_type = configured_engine
        self.engines = [configured_engine]
        self.engine_index = 0
        self.servicetype = configured_engine
        self._engine_locked_to_settings = True
        self.reference = None
        self._owned_reference_string = ""
        self.started = False
        self.start_attempt = 0.0
        self.failed = False
        self.restored = False
        self.resume_prompted = False
        self._resume_target = 0
        self._resume_verify_attempts = 0
        self._resume_grace_until = 0.0
        self._watch_started_at = 0.0
        self._history_save_min_seconds = 10
        self._last_manual_seek_at = 0.0
        self._manual_seek_target_pts = None
        self._manual_seek_target_at = 0.0
        self._early_eof_pending = False
        self._startup_guard_until = 0.0
        self._startup_guard_checks = 0
        self._startup_guard_last_position = -1
        self._startup_guard_reason = ""
        self._last_progress_position = 0
        self._last_progress_duration = 0
        self._hard_stop_attempts = 0
        self._hard_stop_pending_result = None
        self._hard_stop_closing = False
        self._closing_playback = False
        self._owned_external_pids = set()
        self._external_player_baseline = set(_all_external_player_pids())
        self._resume_seek_count = 0
        self._resume_verify_cycles = 0
        self._resume_prepared = False
        self._resume_prompt_open = False
        self._native_resume_started = False
        self._resume_audio_guard = False
        self._resume_was_muted = None
        self._resume_started_at = 0.0
        self._observed_quality = ""
        self._observed_width = 0
        self._observed_height = 0
        # Stage-2: decoder quality is persistent metadata. The receiver may report
        # the same dimensions every second; persist only when that tuple changes.
        self._last_quality_persist_signature = None
        self._static_episode_marker = None
        self._video_guard_misses = 0
        self._video_guard_last_engine = None
        self._engine_video_confirmed = False
        self._next_episode_prompted = False
        self._subtitle_user_override = False
        self._subtitle_disable_attempts = 0
        # Embedded subtitles are supplied by the active Enigma2 service, not
        # SubDL. Some ServiceApp/ExtePlayer engines publish their subtitle list
        # a little after video starts, so keep a short non-blocking probe state
        # instead of deciding that the stream has no tracks on the first read.
        self._embedded_subtitle_probe_pending = False
        self._embedded_subtitle_probe_attempts = 0
        self._embedded_subtitle_probe_started = 0.0
        self._recovery_attempts = 0
        self._recovery_inflight = False
        self._recovery_queue = queue.Queue()
        self._recovery_cancel = threading.Event()
        self._recovery_thread = None
        self._recovery_client_lock = threading.RLock()
        self._recovery_client = None
        self._runtime_reconnects = 0
        self._last_network_activity = 0.0
        self._event_suppress_until = 0.0
        self._play_generation = 0
        self._memory_fuse_level = 0
        self._memory_fuse_last_rss = 0
        self._memory_fuse_emergency = False
        # Stage-3: visual/status pollers run at full cadence only while the
        # InfoBar is visible. Playback/resume/progress persistence are separate.
        self._player_infobar_visible = True
        self._zap_switch_generation = 0
        self._zap_switch_queue = queue.Queue()
        self._zap_switch_inflight = False
        self._zap_switch_started_at = 0.0
        # Stage-3: keep the current async job handle so queued work can be
        # cancelled when the Player closes. Running workers are written to avoid
        # retaining the Screen object and may finish harmlessly in the background.
        self._zap_switch_future = None
        self.ar_id_player = -1
        runtime_breadcrumb("player_open",media_type=self.media_type,engine=int(self.servicetype or 0))

        self["resume_mask"] = Label("")
        self["brand"] = Label(_("Ultra Stalker"))
        self["section"] = Label(_("Live TV / Movies / Series"))
        self["connection"] = Label(_("PREPARING STREAM"))
        self["logo"] = Pixmap();self["live_picon"] = Pixmap();self["adaptive_main"] = Pixmap();self["poster_neon_halo"] = Pixmap();self["adaptive_poster"] = Pixmap();self["adaptive_live_picon"] = Pixmap()
        self["adaptive_progress_track"] = Pixmap(); self["adaptive_keybar"] = Pixmap(); self["watched_progress_glow"] = ProgressBar(); self["watched_progress_glow"].setRange((0,100)); self["watched_progress_glow"].setValue(0); self["watched_progress"] = ProgressBar(); self["watched_progress"].setRange((0,100)); self["watched_progress"].setValue(0)
        self["chip_video_quality"] = Pixmap(); self["chip_video_codec"] = Pixmap(); self["chip_audio_codec"] = Pixmap()
        self["chip_stream"] = Pixmap(); self["chip_audio"] = Pixmap(); self["chip_subtitles"] = Pixmap(); self["chip_engine"] = Pixmap()
        self["channel"] = Label(self.name[:120])
        self["vod_title"] = Label(self.name[:180])
        self["episode_marker"] = Label("")
        self["title_logo"] = Pixmap()
        self._player_title_logo_token=0
        self._player_title_logo_queue=queue.Queue()
        self._player_title_logo_pending=False
        self._player_title_logo_path=""
        self._player_title_logo_future=None
        self["state"] = Label(_("PLAY"))
        self["speed"] = Label("")
        self["statusicon"] = MultiPixmap()
        self["now"] = Label(self._now_text())
        self["next_header"] = Label(_("NEXT"))
        self["next"] = Label(self._next_text())
        self["next_meta"] = Label(_next_meta(self.item, self.media_type))
        # Static catalogue metadata does not change during one Player lifetime.
        # Build it once instead of re-walking the item dictionary/regex fields.
        _static_meta = _meta_text(self.item, self.media_type)
        self._static_quality = _quality(self.item, self.name)
        description = self.item.get("description") or self.item.get("descr") or self.item.get("plot") or ""
        self["description"] = Label(str(description)[:92])
        self["category"] = Label(self._category_label())
        self["engine"] = Label(_engine_label(self.servicetype))
        self["extension"] = Label(_("STREAM"))
        self["quality"] = Label(_("AUTO"))
        self["media_meta"] = Label(_static_meta[:12])
        self["video_quality"] = Label(self._static_quality)
        self["video_codec"] = Label(_("VIDEO"))
        self["audio_codec"] = Label(_("AUDIO"))
        self["skip_hint"] = Label("")
        self["progress_crystal"] = Pixmap(); self["progress_neon"] = Pixmap(); self._adaptive_accent_neon = "#55b9ff"; self._progress_neon_value = -1
        # Stage-4 runtime caches: avoid rescanning sysfs and avoid repainting
        # identical stream-info labels on every status poll.
        self._network_rx_paths = ()
        self._network_rx_paths_refresh_at = 0.0
        self._stream_info_text_cache = {}
        self["audio_tag"] = Label(_("AUDIO"))
        self["subtitle_tag"] = Label(_("SUBTITLES"))
        self["online_subtitle"] = Label("")
        self._online_subtitle_cues = []
        self._online_subtitle_active = False
        self._online_subtitle_index = 0
        self._online_subtitle_path = ""
        self._online_subtitle_searching = False
        self._online_subtitle_queue = queue.Queue()
        self._online_subtitle_generation = 0
        self._online_subtitle_cancel = threading.Event()
        self._online_subtitle_future = None
        self._online_subtitle_offset_ms = 0
        self._online_subtitle_scale = 1.0
        self._online_subtitle_overlay = None
        self._online_subtitle_display = None
        self._online_subtitle_current_text = ""
        _sub_cfg=cfg
        self._subtitle_style={
            "color":str(_sub_cfg.get("subtitle_color") or "#FFFFFF"),
            "background":bool(_sub_cfg.get("subtitle_background",False)),
            "position":max(-260,min(260,int(_sub_cfg.get("subtitle_position",0) or 0))),
        }
        self._media_info_open = False
        self["format_tag"] = Label(_static_meta[13:35] or "STREAM INFO")
        self["transport_hint"] = Label(_("<< Rewind   >> Forward   0 Restart"))
        self["key_red"] = Label(_("Exit"))
        self["key_green"] = Label(_("Aspect Ratio"))
        self["key_yellow"] = Label(_("Subtitles"))
        self["key_blue"] = Label(_("Engine Locked"))
        self["hint"] = Label("")

        try:
            self["statusicon"].setPixmapNum(6)
        except Exception as exc:
            optional_failure("player", exc)
        self["player_actions"] = ActionMap(
            ["UltraStalkerPlayerActions", "OkCancelActions", "ColorActions", "InfobarActions", "NumberActions"],
            {
                "cancel": self.back,
                "stop": self.back,
                "red": self.back,
                "ok": self.OKButton,
                "info": self.show_media_info,
                "blue": self.toggleStreamType,
                "tv": self.toggleStreamType,
                "green": self.nextAR,
                "yellow": self.subtitleSelection,
                "0": self.restartStream,
                # Numeric trick-play: keep the receiver's familiar 10-second
                # jumps, but never route 3 to the old Skip Credits feature.
                "1": self.seekBack10,
                "3": self.seekForward10,
            },
            -2,
        )

        # Test68: direct Live fullscreen channel stepping. UP/DOWN never opens
        # the drawer and never leaves fullscreen; it switches only inside the
        # current Live folder snapshot, lazily loading the target portal page
        # when the next/previous channel is not in RAM yet.  OK/Back semantics
        # remain exactly as before.
        self["live_channel_step_actions"] = ActionMap(
            ["DirectionActions"],
            {"up": lambda: self._quickZap(-1), "down": lambda: self._quickZap(1)},
            -1500,
        )
        try:self["live_channel_step_actions"].setEnabled(self.media_type in ("itv","live"))
        except Exception:pass

        # us132: native-style decisive EXIT lifecycle.  OpenBH InfoBar
        # mixins can bind OkCancelActions too, so keep a dedicated, very-high
        # priority exit map whose only job is to reach our hard-stop path.
        # The normal player map remains responsible for all other keys.
        self["hard_exit_actions"] = ActionMap(
            ["UltraStalkerPlayerActions", "OkCancelActions"],
            {"cancel": self.back, "stop": self.back},
            -10000,
        )

        # OE-A/OpenBH InfoBar mixins also bind Yellow. Keep our Nova information
        # overlay on a dedicated higher-priority ColorActions map so the legacy
        # "Information (n)" popup can never steal the key.
        self["nova_yellow_actions"] = ActionMap(["ColorActions"], {"yellow": self.subtitleSelection}, -1000)
        self["online_subtitle_actions"] = ActionMap(
            ["InfobarSubtitleSelectionActions"],
            {"subtitleSelection": self.subtitleSelection},
            -1200,
        )
        self["subtitle_volume_watch_actions"] = ActionMap(
            ["VolumeActions"],
            {"volumeUp":self._subtitle_volume_osd_event,
             "volumeDown":self._subtitle_volume_osd_event,
             "volumeMute":self._subtitle_volume_osd_event},
            -1100,
        )

        eventmap = {iPlayableService.evStart: self._service_started}
        _ev_updated=getattr(iPlayableService,"evUpdatedInfo",None)
        if _ev_updated is not None:eventmap[_ev_updated]=self._native_resume_updated
        for event_name, callback in (("evTuneFailed", self._service_failed), ("evEOF", self._service_eof)):
            event_value = getattr(iPlayableService, event_name, None)
            if event_value is not None:
                eventmap[event_value] = callback
        self.__event_tracker = ServiceEventTracker(screen=self, eventmap=eventmap)
        try:
            # Always paint receiver-safe neutral glass first. Adaptive chrome
            # then replaces it on the same layout pass when artwork is ready.
            self.onLayoutFinish.append(self._apply_adaptive_player_chrome)
            self.onLayoutFinish.append(self._init_online_subtitle_display)
        except Exception as exc:optional_failure("player.optional_guard",exc)

        self.startup_timer = eTimer()
        try:
            self.startup_timer_conn = self.startup_timer.timeout.connect(self._startup_timeout)
        except Exception:
            self.startup_timer.callback.append(self._startup_timeout)


        # Proven native-style resume timer: wait briefly after evStart, then
        # issue exactly one absolute seekTo() against the live seek interface.
        self.resume_timer = eTimer()
        self.resume_timer_conn = None
        try:
            self.resume_timer_conn = self.resume_timer.timeout.connect(self._reference_resume)
        except Exception:
            self.resume_timer.callback.append(self._reference_resume)

        self.resume_verify_timer = eTimer()
        try:
            self.resume_verify_timer_conn = self.resume_verify_timer.timeout.connect(self._verify_resume_position)
        except Exception:
            self.resume_verify_timer.callback.append(self._verify_resume_position)


        self.subtitle_default_timer = eTimer()
        try:
            self.subtitle_default_timer_conn = self.subtitle_default_timer.timeout.connect(self._enforce_default_subtitles_off)
        except Exception:
            self.subtitle_default_timer.callback.append(self._enforce_default_subtitles_off)

        # Native embedded-track discovery is intentionally separate from the
        # online subtitle timers. It only runs after the user chooses Embedded
        # subtitles and stops as soon as the receiver exposes real tracks.
        self.embedded_subtitle_probe_timer = eTimer()
        self.embedded_subtitle_probe_timer_conn = None
        try:
            self.embedded_subtitle_probe_timer_conn = self.embedded_subtitle_probe_timer.timeout.connect(self._embedded_subtitle_probe_tick)
        except Exception:
            self.embedded_subtitle_probe_timer.callback.append(self._embedded_subtitle_probe_tick)

        self.online_subtitle_timer = eTimer()
        try:
            self.online_subtitle_timer_conn = self.online_subtitle_timer.timeout.connect(self._online_subtitle_tick)
        except Exception:
            self.online_subtitle_timer.callback.append(self._online_subtitle_tick)
        self.online_subtitle_result_timer = eTimer()
        try:
            self.online_subtitle_result_timer_conn = self.online_subtitle_result_timer.timeout.connect(self._drain_online_subtitle_result)
        except Exception:
            self.online_subtitle_result_timer.callback.append(self._drain_online_subtitle_result)

        self.subtitle_volume_restore_timer=eTimer();self.subtitle_volume_restore_timer_conn=None
        try:self.subtitle_volume_restore_timer_conn=self.subtitle_volume_restore_timer.timeout.connect(self._restore_subtitle_after_volume_osd)
        except Exception:self.subtitle_volume_restore_timer.callback.append(self._restore_subtitle_after_volume_osd)

        self.progress_timer = eTimer()
        try:
            self.progress_timer_conn = self.progress_timer.timeout.connect(self._periodic_progress_save)
        except Exception:
            self.progress_timer.callback.append(self._periodic_progress_save)

        self.crystal_timer = eTimer()
        try:
            self.crystal_timer_conn = self.crystal_timer.timeout.connect(self._update_progress_crystal)
        except Exception:
            self.crystal_timer.callback.append(self._update_progress_crystal)

        self.hard_stop_timer = eTimer()
        try:
            self.hard_stop_timer_conn = self.hard_stop_timer.timeout.connect(self._verify_hard_stop)
        except Exception:
            self.hard_stop_timer.callback.append(self._verify_hard_stop)

        # Some ServiceApp/ExtePlayer builds emit a transient EOF one or two
        # seconds after evStart while the same service keeps playing. Do not
        # immediately restart the movie; verify actual playback first.
        self.eof_guard_timer = eTimer()
        try:
            self.eof_guard_timer_conn = self.eof_guard_timer.timeout.connect(self._verify_early_eof)
        except Exception:
            self.eof_guard_timer.callback.append(self._verify_early_eof)

        self.recovery_timer = eTimer()
        try:
            self.recovery_timer_conn = self.recovery_timer.timeout.connect(self._drain_recovery_result)
        except Exception:
            self.recovery_timer.callback.append(self._drain_recovery_result)

        self.zap_switch_timer = eTimer()
        try:
            self.zap_switch_timer_conn = self.zap_switch_timer.timeout.connect(self._drain_zap_switch_result)
        except Exception:
            self.zap_switch_timer.callback.append(self._drain_zap_switch_result)

        # A stream must stay healthy for a while before retry budgets are reset.
        # This prevents a flapping channel from creating an endless reconnect loop.
        self.stable_timer = eTimer()
        try:
            self.stable_timer_conn = self.stable_timer.timeout.connect(self._mark_stream_stable)
        except Exception:
            self.stable_timer.callback.append(self._mark_stream_stable)

        # reference implementation-style aspect-preserving poster decoder.
        self.PicLoad = ePicLoad()
        self.PicLoad_conn = None
        self._poster_path = None
        try:
            self.PicLoad.PictureData.get().append(self._decode_poster)
        except Exception:
            try:
                self.PicLoad_conn = self.PicLoad.PictureData.connect(self._decode_poster)
            except Exception:
                self.PicLoad_conn = None

        # Poll actual service data after playback starts. This affects labels only;
        # the proven playback and MAG workflow remains untouched.
        self.stream_info_timer = eTimer()
        self.stream_info_timer_conn = None
        try:
            self.stream_info_timer_conn = self.stream_info_timer.timeout.connect(self._update_stream_info)
        except Exception:
            self.stream_info_timer.callback.append(self._update_stream_info)

        self.player_title_logo_timer=eTimer();self.player_title_logo_timer_conn=None
        try:self.player_title_logo_timer_conn=self.player_title_logo_timer.timeout.connect(self._drain_player_title_logo)
        except Exception:self.player_title_logo_timer.callback.append(self._drain_player_title_logo)

        # Last-resort memory fuse. This does not restart playback. Its job is to
        # shed optional UI memory long before Broadcom's OOM killer reaches the
        # ~600 MB RSS failure zone observed on the target receiver.
        self.memory_fuse_timer=eTimer();self.memory_fuse_timer_conn=None
        try:
            self.memory_fuse_timer_conn=self.memory_fuse_timer.timeout.connect(self._memory_fuse_tick)
        except Exception:
            self.memory_fuse_timer.callback.append(self._memory_fuse_tick)

        try:
            self.onPlayStateChanged.append(self._play_state_changed)
        except Exception as exc:
            optional_failure("player", exc)
        self.onLayoutFinish.append(self._layout_ready)
        try:self.onShow.append(self._restore_player_chrome_after_show)
        except Exception as exc:optional_failure("player.chrome_show_hook",exc)
        try:
            self.onShow.append(self._resume_hidden_visual_timers)
            self.onHide.append(self._pause_hidden_visual_timers)
        except Exception as exc:optional_failure("player.visual_timer_hooks",exc)
        self.onFirstExecBegin.append(self._begin_playback)
        self.onClose.append(self._cleanup)

    def _layout_ready(self):
        try:
            if not self._resume_prepared:
                self["resume_mask"].hide()
        except Exception as exc:
            optional_failure("player.resume_mask_layout", exc)
        artwork=_cached_poster(self.item, self.name, self.media_type)
        if self.media_type in ("itv","live"):
            try:self["vod_title"].hide();self["title_logo"].hide();self["episode_marker"].hide()
            except Exception:pass
            self._load_live_picon(artwork)
        else:
            self._configure_vod_title_area()
            self._load_poster(artwork)
        self._update_stream_info()

    @staticmethod
    def _player_fallback_title(item, name, media_type):
        """Clean text used only when the persistent Player title logo is absent.

        Prefer catalogue metadata (and a parent-series title for episodes), then
        remove filename-style separators, episode tokens and common stream tags.
        Playback identity and title-logo lookup remain untouched.
        """
        data=item if isinstance(item,dict) else {}
        mt=str(media_type or "").lower()
        candidates=[]
        if mt in ("series","episode","tv"):
            candidates.extend((data.get("_series_title"),data.get("series_title"),data.get("series_name")))
        candidates.extend((data.get("title"),data.get("name"),name))
        raw=""
        for value in candidates:
            text=str(value or "").strip()
            if text and text.lower() not in ("none","null"):
                raw=text;break
        if not raw:return str(name or "").strip()
        text=re.sub(r"\.(?:mkv|mp4|avi|mov|ts|m2ts|wmv|flv|webm)$","",raw,flags=re.I)
        text=re.sub(r"(?i)(?:^|[._\-\s])S\d{1,2}E\d{1,3}(?=$|[._\-\s])"," ",text)
        text=re.sub(r"(?i)(?:^|[._\-\s])\d{1,2}x\d{1,3}(?=$|[._\-\s])"," ",text)
        text=re.sub(r"(?i)(?:^|[._\-\s])Season[._\-\s]*\d{1,2}[._\-\s]*Episode[._\-\s]*\d{1,3}(?=$|[._\-\s])"," ",text)
        text=re.sub(r"[._]+"," ",text)
        # Player-only filename noise. Keep this deliberately narrow so real title
        # words survive while common release/stream tags do not leak on-screen.
        text=re.sub(r"(?i)(?:^|\s)(?:2160p|1080p|720p|576p|480p|4k|uhd|hdr10\+?|hdr|dv|dolby[ ._-]*vision|web[ ._-]*dl|webrip|bluray|blu[ ._-]*ray|brrip|bdremux|remux|hdtv|x264|x265|h\.?264|h\.?265|hevc|av1|aac(?:2\.?0|5\.?1)?|ddp?5\.?1|eac3|ac3|dts(?:[ ._-]*hd)?)(?=$|\s)"," ",text)
        text=re.sub(r"\s+"," ",text).strip(" -_|:.")
        cleaned=_catalogue_title(text) or text
        cleaned=re.sub(r"\s+"," ",str(cleaned or "")).strip(" -_|:.")
        return cleaned or str(name or "").strip()

    @staticmethod
    def _player_title_font_size(text):
        value=str(text or "").strip()
        units=max(1.0,sum(1.32 if ord(ch)>127 else 1.0 for ch in value))
        if units<=16:return 58
        if units<=28:return 52
        if units<=40:return 44
        if units<=54:return 36
        if units<=70:return 30
        # 1220px title area: continue shrinking instead of freezing at 26px.
        return max(18,min(26,int(1180.0/(units*0.57))))

    @staticmethod
    def _player_fit_title(text):
        value=str(text or "").strip()
        if not value:return "",58
        size=UltraStalkerPlayer._player_title_font_size(value)
        def units_of(v):return sum(1.32 if ord(ch)>127 else 1.0 for ch in v)
        max_units=1180.0/(max(18,size)*0.57)
        if units_of(value)<=max_units:return value,size
        out=[];used=0.0
        budget=max(1.0,max_units-3.0)
        for ch in value:
            u=1.32 if ord(ch)>127 else 1.0
            if used+u>budget:break
            out.append(ch);used+=u
        fitted=("".join(out).rstrip()+"…") if out else value[:1]
        return fitted,size

    @staticmethod
    def _episode_display_number(item):
        item=item if isinstance(item,dict) else {}
        for key in ("_episode_number","episode_number","episode","number","episode_num","episode_id"):
            value=item.get(key)
            text=str(value or "").strip()
            if not text or text.lower() in ("none","null"):
                continue
            match=re.search(r"\d+", text)
            if not match:
                continue
            try:return str(int(match.group(0)))
            except Exception:return match.group(0)
        return ""

    def _episode_marker_text(self):
        cached=getattr(self,"_static_episode_marker",None)
        if cached is not None:return cached
        if self.media_type not in ("series","episode"):
            self._static_episode_marker="";return ""
        number=self._episode_display_number(self.item)
        self._static_episode_marker=("Episode %s" % number) if number else ""
        return self._static_episode_marker

    def _configure_vod_title_area(self):
        """VOD/episode Player: one centered title, logo-first and text fallback."""
        try:
            for name in ("channel","category","quality","connection","now"):
                try:self[name].hide()
                except Exception:pass
            title=self._player_fallback_title(self.item,self.name,self.media_type)
            title,title_font=self._player_fit_title(title)
            try:
                if self["vod_title"].instance is not None:
                    self["vod_title"].instance.setFont(gFont("Regular",title_font))
            except Exception:pass
            marker=self._episode_marker_text()
            if marker:
                try:self["episode_marker"].setText(marker);self["episode_marker"].show()
                except Exception:pass
            else:
                try:self["episode_marker"].hide()
                except Exception:pass
            self["vod_title"].setText(title[:180]);self["vod_title"].show();self["title_logo"].hide()
            source=_player_title_logo_source(self.item,title,self.media_type)
            if not source:return
            target=_prepare_player_title_logo_cache_path(source,(1220,72))
            if target and os.path.isfile(target) and os.path.getsize(target)>256:
                if self["title_logo"].instance is not None:self["title_logo"].instance.setPixmapFromFile(target)
                self["title_logo"].show();self["vod_title"].hide();self._player_title_logo_path=target;return
            self._player_title_logo_token+=1;token=self._player_title_logo_token
            if self._player_title_logo_pending:return
            self._player_title_logo_pending=True
            result_queue=self._player_title_logo_queue
            def worker():
                path=""
                try:path=_prepare_player_title_logo(source,(1220,72))
                except Exception:pass
                try:result_queue.put((token,path))
                except Exception:pass
            try:
                self._player_title_logo_future=_PLAYER_BG_EXECUTOR.submit(worker)
                self.player_title_logo_timer.start(90,True)
            except Exception:
                self._player_title_logo_pending=False
                future=getattr(self,"_player_title_logo_future",None)
                if future is not None:
                    try:future.cancel()
                    except Exception:pass
                self._player_title_logo_future=None
        except Exception as exc:optional_failure("player.vod_title_area",exc)

    def _drain_player_title_logo(self):
        try:self.player_title_logo_timer.stop()
        except Exception:pass
        applied=False
        while True:
            try:token,path=self._player_title_logo_queue.get_nowait()
            except queue.Empty:break
            self._player_title_logo_pending=False
            self._player_title_logo_future=None
            if token!=self._player_title_logo_token or self.restored or self._closing_playback:continue
            try:
                if path and os.path.isfile(path) and os.path.getsize(path)>256 and self["title_logo"].instance is not None:
                    self["title_logo"].instance.setPixmapFromFile(path);self["title_logo"].show();self["vod_title"].hide();self._player_title_logo_path=path;applied=True
            except Exception as exc:optional_failure("player.title_logo_apply",exc)
        if self._player_title_logo_pending and not applied:
            try:self.player_title_logo_timer.start(90,True)
            except Exception:pass


    def _load_live_picon(self, path):
        prepared=_prepare_live_picon(path,(220,132))
        try:
            self["logo"].hide();self["poster_neon_halo"].hide();self["adaptive_poster"].hide()
            if prepared and os.path.isfile(prepared) and self["live_picon"].instance is not None:
                self["live_picon"].instance.setPixmapFromFile(prepared);self["live_picon"].show()
        except Exception as exc:optional_failure("player.live_picon_apply",exc)

    def _resume_bookmark(self):
        try:
            position = max(0, int(self.item.get("_resume_position") or 0))
            duration = max(0, int(self.item.get("_resume_duration") or 0))
        except Exception:
            position = 0; duration = 0
        # Ignore only trivial starts and bookmarks that meet the same configured
        # completion policy used by history/Continue Watching.  Older builds had
        # a hard-coded four-minute tail here, so a perfectly valid bookmark could
        # be stored yet silently refused on the next open.
        if position < (10 * 90000):
            return 0
        if duration and (position >= duration or max(0,duration-position) <= 10*90000):
            return 0
        return position

    def _begin_playback(self):
        """Start playback first, then resume from evStart like the proven native player.

        Resume persistence is already stable-ID based in Ultra Stalker.  The only
        part borrowed here is the working playback lifecycle: playService(), wait
        for evStart, pause 900 ms, obtain the current seek interface and seekTo().
        """
        self._resume_target = 0
        self._resume_seek_count = 0
        self._resume_verify_attempts = 0
        self._resume_verify_cycles = 0
        self._resume_prepared = False
        self._resume_prompt_open = False
        self._native_resume_started = False
        behavior = self._cfg_resume_behavior
        self.resume_prompted = bool(behavior == "start")
        if self.reuse_current:
            try:
                current=self.session.nav.getCurrentlyPlayingServiceReference()
                if current is not None:
                    self.reference=current
                    try:self._owned_reference_string=current.toString()
                    except Exception:self._owned_reference_string=""
                    self.started=True;self.failed=False;self._watch_started_at=time.time()
                    self.start_attempt=time.time();self._last_network_activity=time.monotonic()
                    self._runtime_reconnects=0;self._recovery_attempts=0
                    self["connection"].setText(_("PLAYING  •  %s") % _engine_label(self.servicetype))
                    runtime_breadcrumb("player_adopt_current",media_type=self.media_type,engine=int(self.servicetype or 0))
                    try:self.stable_timer.stop();self.stable_timer.start(30000,True)
                    except Exception as exc:optional_failure("player.optional_guard",exc)
                    try:self.stream_info_timer.start(700,True)
                    except Exception as exc:optional_failure("player.optional_guard",exc)
                    return
            except Exception as exc:
                optional_failure("player.adopt_current",exc)
        self.playStream(self.servicetype, self.streamurl)

    def _resume_before_start_answer(self, answer, bookmark):
        self._resume_prompt_open = False
        self.resume_prompted = True
        if answer:
            self._prepare_instant_resume(bookmark)
        self.playStream(self.servicetype, self.streamurl)

    def _prepare_instant_resume(self, position):
        self._resume_target = max(0, int(position or 0))
        if not self._resume_target:
            return
        self._resume_prepared = True
        self._resume_started_at = time.time()
        self._resume_verify_attempts = 0
        self._resume_seek_count = 0
        self._resume_verify_cycles = 0
        self._resume_grace_until = time.time() + 16.0
        # Keep playback lifecycle native. We wait only for seekability and then
        # issue one absolute bookmark seek, matching the proven reference flow.
        self["connection"].setText(_("RESUMING  •  preparing bookmark"))

    def _set_resume_audio_guard(self, enabled):
        if eDVBVolumecontrol is None:
            return
        try:
            volume = eDVBVolumecontrol.getInstance()
            if volume is None:
                return
            if enabled:
                if not self._resume_audio_guard:
                    try:
                        self._resume_was_muted = bool(volume.isMuted())
                    except Exception:
                        self._resume_was_muted = False
                    if not self._resume_was_muted:
                        volume.setMuted(True)
                    self._resume_audio_guard = True
            elif self._resume_audio_guard:
                if self._resume_was_muted is False:
                    volume.setMuted(False)
                self._resume_audio_guard = False
        except Exception as exc:
            optional_failure("player.resume_audio_guard", exc)

    def _release_resume_shield(self):
        self._resume_prepared = False
        try:
            self["resume_mask"].hide()
        except Exception as exc:
            optional_failure("player.resume_mask_hide", exc)
        self._set_resume_audio_guard(False)

    def _connect_picload(self):
        self.PicLoad_conn = None
        try:
            self.PicLoad.PictureData.get().append(self._decode_poster)
        except Exception:
            try:
                self.PicLoad_conn = self.PicLoad.PictureData.connect(self._decode_poster)
            except Exception:
                self.PicLoad_conn = None

    def _load_poster(self, path):
        """Fill the poster card exactly, using a high-quality center crop."""
        prepared=_prepare_player_poster_fill(path,(250,375))
        self._poster_path = prepared or path
        try:self["live_picon"].hide();self["adaptive_live_picon"].hide()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        try:
            if prepared and os.path.isfile(prepared) and self["logo"].instance is not None:
                self["logo"].instance.setPixmapFromFile(prepared)
                self["logo"].show()
                return
        except Exception as exc:
            optional_failure("player.poster_direct",exc)
        try:
            self.PicLoad.setPara([242, 330, 1, 1, 0, 1, "FF000000"])
            result = self.PicLoad.startDecode(self._poster_path)
            if result:
                try:
                    callbacks=self.PicLoad.PictureData.get()
                    if self._decode_poster in callbacks:callbacks.remove(self._decode_poster)
                except Exception as exc:optional_failure("player.optional_guard",exc)
                try:
                    if self.PicLoad_conn is not None:self.PicLoad_conn.disconnect()
                except Exception as exc:optional_failure("player.optional_guard",exc)
                self.PicLoad = ePicLoad()
                self._connect_picload()
                self.PicLoad.setPara([242, 330, 1, 1, 0, 1, "FF000000"])
                self.PicLoad.startDecode(self._poster_path)
        except Exception:
            try:
                self["logo"].instance.setPixmapFromFile(self._poster_path)
                self["logo"].show()
            except Exception as exc:
                optional_failure("player", exc)
    def _decode_poster(self, pic_info=None):
        try:
            ptr = self.PicLoad.getData()
            if ptr is not None and self["logo"].instance:
                self["logo"].instance.setPixmap(ptr)
                self["logo"].show()
        except Exception:
            try:
                if self._poster_path:
                    self["logo"].instance.setPixmapFromFile(self._poster_path)
                    self["logo"].show()
            except Exception as exc:
                optional_failure("player", exc)
    @staticmethod
    def _read_proc_number(paths, base=10):
        for pathname in paths:
            try:
                if os.path.exists(pathname):
                    value = open(pathname, "r").read().strip()
                    if value:
                        return int(value, base)
            except Exception as exc:
                optional_failure("player", exc)
        return None

    @staticmethod
    def _info_number(info, name, default=None):
        try:
            key = getattr(iServiceInformation, name)
            value = info.getInfo(key)
            if value == -2:
                raw = info.getInfoString(key)
                return int(str(raw).strip())
            if value is not None and value >= 0:
                return int(value)
        except Exception as exc:
            optional_failure("player", exc)
        return default

    @staticmethod
    def _video_codec_text(info):
        for pathname in ("/proc/stb/vmpeg/0/codec", "/proc/stb/vmpeg/0/vcodec"):
            try:
                if os.path.exists(pathname):
                    raw = open(pathname, "r").read().strip()
                    if raw:
                        return raw.upper().replace("HEVC", "H.265").replace("AVC", "H.264")[:12]
            except Exception as exc:
                optional_failure("player", exc)
        value = UltraStalkerPlayer._info_number(info, "sVideoType", None)
        return {
            0: "MPEG2", 1: "H.264", 2: "H.263", 3: "VC-1",
            4: "MPEG4", 5: "VC-1", 6: "MPEG1", 7: "H.265",
            8: "VP8", 9: "VP9", 10: "XVID", 12: "AVS",
            13: "AVS2", 16: "AV1",
        }.get(value, "VIDEO")

    @staticmethod
    def _audio_codec_text(service, info):
        try:
            tracks = service.audioTracks()
            if tracks and tracks.getNumberOfTracks() > 0:
                current = tracks.getCurrentTrack()
                if current < 0:
                    current = 0
                desc = str(tracks.getTrackInfo(current).getDescription() or "").strip()
                if desc:
                    token = desc.split()[0].upper()
                    aliases = {"AC-3": "AC3", "AC3+": "E-AC3", "HE-AAC": "AAC"}
                    return aliases.get(token, token)[:12]
        except Exception as exc:
            optional_failure("player", exc)
        try:
            key = getattr(iServiceInformation, "sAudioType")
            raw = info.getInfoString(key)
            if raw:
                return str(raw).upper()[:12]
        except Exception as exc:
            optional_failure("player", exc)
        return "AUDIO"

    def _set_stream_info_text(self, widget_name, value):
        text=str(value or "")
        cache=self._stream_info_text_cache
        if cache.get(widget_name)==text:return False
        self[widget_name].setText(text);cache[widget_name]=text
        return True

    def _update_stream_info(self):
        if getattr(self, "restored", False):
            return
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if info:
                # Read the actual active video dimensions from every reliable
                # Enigma2/decoder source and keep the largest sane pair. Some
                # ServiceApp paths briefly expose a scaled viewport (for example
                # ~950x534) while the service info already knows the source frame.
                # Never print those transient numeric heights as a quality label.
                proc_width = self._read_proc_number(("/proc/stb/vmpeg/0/xres",), 16) or 0
                proc_height = self._read_proc_number(("/proc/stb/vmpeg/0/yres",), 16) or 0
                info_width = self._info_number(info, "sVideoWidth", 0) or 0
                info_height = self._info_number(info, "sVideoHeight", 0) or 0
                candidates=[]
                for cw,ch in ((proc_width,proc_height),(info_width,info_height)):
                    try:
                        cw=int(cw or 0); ch=int(ch or 0)
                    except Exception:
                        continue
                    if 160 <= cw <= 8192 and 120 <= ch <= 4320:
                        candidates.append((cw*ch,cw,ch))
                if candidates:
                    _area,width,height=max(candidates,key=lambda row:row[0])
                else:
                    width=height=0
                if width >= 3200 or height >= 1800:
                    quality = "4K UHD"
                elif width >= 1700 or height >= 1000:
                    quality = "FHD"
                elif width >= 1200 or height >= 700:
                    quality = "HD"
                elif width > 0 and height > 0:
                    quality = "SD"
                else:
                    quality = "AUTO"
                self._set_stream_info_text("video_quality",quality[:15])
                self._observed_quality = quality
                self._observed_width = int(width or 0)
                self._observed_height = int(height or 0)
                if (width or height) and not self._engine_video_confirmed:
                    self._engine_video_confirmed=True;self._video_guard_misses=0
                # Deterministic playback: stream-info probes are informational only.
                # They must never restart/refresh the active service.
                # Persist the decoder-observed resolution for the catalogue
                # details screen. This is deliberately written only when the
                # receiver reports a real width/height, never from AUTO guesses.
                if (width or height) and self.media_type in ("vod","series","episode"):
                    try:
                        signature=(str(quality),int(width or 0),int(height or 0))
                        if signature != self._last_quality_persist_signature:
                            profile=self._history_profile
                            persisted=bool(remember_content_quality(profile,self.media_type,self.item,quality,width,height))
                            # Episode playback should also teach the parent series
                            # when the payload carries a stable series id/title.
                            if self.media_type=="episode":
                                parent=self.item.get("_quality_parent_item") if isinstance(self.item,dict) else None
                                if isinstance(parent,dict) and parent:
                                    persisted=bool(remember_content_quality(profile,"series",parent,quality,width,height)) and persisted
                            if persisted:self._last_quality_persist_signature=signature
                    except Exception as exc:optional_failure("player.quality_cache_write",exc)
                self._set_stream_info_text("video_codec",self._video_codec_text(info))
                self._set_stream_info_text("audio_codec",self._audio_codec_text(service, info))
        except Exception as exc:
            optional_failure("player", exc)
        # Live continuity is driven by real Enigma2 EOF/tune-failed events.
        # Do not synthesize a stall from a timestamp that is not backed by actual
        # socket receive counters; that old watchdog could restart healthy Live TV.
        try:
            self.stream_info_timer.stop()
            interval=1000 if getattr(self,"_player_infobar_visible",True) else 5000
            self.stream_info_timer.start(interval, True)
        except Exception as exc:
            optional_failure("player", exc)
    def _memory_fuse_release_visuals(self, aggressive=False):
        # Playback service is deliberately left untouched. Only optional native
        # graphics/decoder helpers are released.
        # Never shed the core InfoBar glass.  With large portal libraries RSS can
        # already be above the old 430 MB threshold when Player opens; the old
        # fuse therefore stripped adaptive_main/keybar/chips a few seconds later
        # and left naked labels over video.  Only artwork/decorative layers are
        # disposable while playback continues.
        # Keep the core VOD/episode identity surfaces resident. They are small
        # compared with the video decoder and must survive InfoBar hide/show.
        # Only genuinely disposable live/progress pixmaps are shed here.
        for name in (
            "live_picon","adaptive_live_picon","progress_crystal","progress_neon"
        ):
            try:
                widget=self[name]
                if widget.instance is not None:widget.instance.setPixmap(None)
                try:widget.hide()
                except Exception as exc:optional_failure("player.silent_guard",exc)
            except Exception as exc:optional_failure("player.silent_guard",exc)
        if aggressive:
            try:self.PicLoad.PictureData.get().remove(self._decode_poster)
            except Exception as exc:optional_failure("player.silent_guard",exc)
            try:self.stream_info_timer.stop()
            except Exception as exc:optional_failure("player.silent_guard",exc)
        try:
            with _PROGRESS_FRAME_LOCK:_PROGRESS_FRAME_PENDING.clear()
        except Exception as exc:optional_failure("player.silent_guard",exc)
        try:gc.collect()
        except Exception as exc:optional_failure("player.silent_guard",exc)
        _malloc_trim()

    def _memory_fuse_tick(self):
        if self.restored or self._closing_playback:
            try:self.memory_fuse_timer.stop()
            except Exception as exc:optional_failure("player.silent_guard",exc)
            return
        rss=_process_rss_kb();self._memory_fuse_last_rss=rss
        if not rss:return
        # 430 MB: shed decorative native pixmaps and Python garbage.
        if rss >= 430*1024 and self._memory_fuse_level < 1:
            self._memory_fuse_level=1
            runtime_breadcrumb("player_memory_fuse",level=1,rss_kb=int(rss))
            self._memory_fuse_release_visuals(False)
        # 510 MB: stop all non-essential player image polling/decoding.
        if rss >= 510*1024 and self._memory_fuse_level < 2:
            self._memory_fuse_level=2
            runtime_breadcrumb("player_memory_fuse",level=2,rss_kb=int(rss))
            self._memory_fuse_release_visuals(True)
            try:self["connection"].setText(_("MEMORY PROTECTION  •  playback preserved"))
            except Exception as exc:optional_failure("player.silent_guard",exc)
        # 555 MB: protect Enigma2 itself. Better to leave the current Player
        # cleanly than let the kernel kill the entire GUI around 600 MB.
        if rss >= 555*1024 and not self._memory_fuse_emergency:
            self._memory_fuse_emergency=True
            runtime_breadcrumb("player_memory_fuse",level=3,rss_kb=int(rss))
            try:self["connection"].setText(_("MEMORY SAFETY EXIT"))
            except Exception as exc:optional_failure("player.silent_guard",exc)
            try:self._save_history_progress(force=True)
            except Exception as exc:optional_failure("player.silent_guard",exc)
            self._close_player(save_progress=False)

    def _pause_hidden_visual_timers(self):
        """Throttle purely visual/status polling while the InfoBar is hidden."""
        self._player_infobar_visible=False
        try:self.crystal_timer.stop()
        except Exception as exc:optional_failure("player.hidden_crystal_stop",exc)
        # Stream metadata is informational only. Keep a slow hidden refresh so
        # adaptive resolution changes are still learned without 1 Hz GUI I/O.
        if self.started and self._memory_fuse_level < 2 and not self.restored and not self._closing_playback:
            try:self.stream_info_timer.stop();self.stream_info_timer.start(5000,True)
            except Exception as exc:optional_failure("player.hidden_stream_info_throttle",exc)

    def _resume_hidden_visual_timers(self):
        """Restore normal visual/status cadence as soon as the InfoBar is shown."""
        self._player_infobar_visible=True
        if self.restored or self._closing_playback or not self.started:return
        if self._memory_fuse_level < 2:
            try:self.stream_info_timer.stop();self._update_stream_info()
            except Exception as exc:optional_failure("player.visible_stream_info_resume",exc)
        if self.media_type in ("vod","series","episode","catchup"):
            try:
                self.crystal_timer.stop();self._update_progress_crystal();self.crystal_timer.start(1000,False)
            except Exception as exc:optional_failure("player.visible_crystal_resume",exc)

    def _restore_player_chrome_after_show(self):
        """Re-bind the exact glass pixmaps after every InfoBar show.

        Enigma2 can drop native pixmap surfaces while a Screen is hidden even
        though the Python widgets survive. Rebinding cached files is cheap and
        avoids regenerating adaptive artwork on every OK press.
        """
        if getattr(self,"restored",False) or getattr(self,"_closing_playback",False):return
        # Live picons can arrive asynchronously after playback starts. The old
        # InfoBar kept the neutral blue frames created at init forever, while the
        # later-opened Mini List already saw the real picon palette. Refresh from
        # the now-cached picon before rebinding the InfoBar. Generated frames are
        # persistent/cached, so subsequent OK presses do not redo image work.
        if self.media_type in ("itv","live"):
            try:
                palette_item=self.item
                if 0<=int(getattr(self,"_zap_index",0))<len(getattr(self,"_zap_channels",[]) or []):
                    row=(getattr(self,"_zap_channels",[]) or [])[int(self._zap_index)]
                    if isinstance(row,dict):palette_item=row
                live_art=_cached_poster(palette_item,self.name,self.media_type)
                self._load_live_picon(live_art)
                self._apply_adaptive_player_chrome()
            except Exception as exc:optional_failure("player.live_infobar_adaptive_refresh",exc)
        frames=dict(getattr(self,"_player_chrome_frames",{}) or _fallback_player_frames())
        mapping=(("main","adaptive_main"),("track","adaptive_progress_track"),("keybar","adaptive_keybar"),
                 ("chip_quality","chip_video_quality"),("chip_video","chip_video_codec"),
                 ("chip_audio_codec","chip_audio_codec"),
                 ("chip_stream","chip_stream"),("chip_audio","chip_audio"),
                 ("chip_subtitles","chip_subtitles"),("chip_engine","chip_engine"))
        for key,name in mapping:
            try:
                path=frames.get(key)
                if path and os.path.isfile(path) and self[name].instance is not None:
                    self[name].instance.setPixmapFromFile(path);self[name].show()
            except Exception as exc:optional_failure("player.chrome_reshow",exc)
        # Artwork-specific chrome is restored without touching playback.
        try:
            if self.media_type in ("itv","live"):
                p=frames.get("live_picon")
                if p and os.path.isfile(p) and self["adaptive_live_picon"].instance is not None:
                    self["adaptive_live_picon"].instance.setPixmapFromFile(p);self["adaptive_live_picon"].show()
            else:
                # Poster is the bottom layer; both existing chrome layers sit above it.
                poster_path=str(getattr(self,"_poster_path","") or _cached_poster(self.item,self.name,self.media_type) or "")
                if poster_path and os.path.isfile(poster_path) and self["logo"].instance is not None:
                    self["logo"].instance.setPixmapFromFile(poster_path);self["logo"].show()
                p=frames.get("poster_halo")
                if p and os.path.isfile(p) and self["poster_neon_halo"].instance is not None:
                    self["poster_neon_halo"].instance.setPixmapFromFile(p);self["poster_neon_halo"].show()
                p=frames.get("poster")
                if p and os.path.isfile(p) and self["adaptive_poster"].instance is not None:
                    self["adaptive_poster"].instance.setPixmapFromFile(p);self["adaptive_poster"].show()
        except Exception as exc:optional_failure("player.chrome_reshow_art",exc)
        if self.media_type not in ("itv","live"):
            try:
                for name in ("channel","category","quality","connection","now"):
                    try:self[name].hide()
                    except Exception:pass
                marker=self._episode_marker_text()
                if marker:
                    try:self["episode_marker"].setText(marker);self["episode_marker"].show()
                    except Exception:pass
                else:
                    try:self["episode_marker"].hide()
                    except Exception:pass
                logo=str(getattr(self,"_player_title_logo_path","") or "")
                if logo and os.path.isfile(logo) and self["title_logo"].instance is not None:
                    self["title_logo"].instance.setPixmapFromFile(logo);self["title_logo"].show();self["vod_title"].hide()
                else:
                    self["title_logo"].hide();self["vod_title"].show()
            except Exception as exc:optional_failure("player.title_reshow",exc)

    def _apply_adaptive_player_chrome(self):
        try:
            palette_item=self.item
            if self.media_type in ("itv","live"):
                try:
                    if 0<=int(getattr(self,"_zap_index",0))<len(getattr(self,"_zap_channels",[]) or []):
                        row=(getattr(self,"_zap_channels",[]) or [])[int(self._zap_index)]
                        if isinstance(row,dict):palette_item=row
                except Exception:pass
            source=_cached_poster(palette_item,self.name,self.media_type)
            fallback=_fallback_player_frames()
            adaptive=_adaptive_player_frames(source)
            # Per-frame merge is deliberate.  A partially generated adaptive
            # set must never remove an otherwise valid neutral glass layer.
            frames=dict(fallback)
            if isinstance(adaptive,dict):
                for key,value in adaptive.items():
                    if value:
                        frames[key]=value
            self._player_chrome_frames=dict(frames)
            for key,name in (("main","adaptive_main"),("poster_halo","poster_neon_halo"),("poster","adaptive_poster"),("live_picon","adaptive_live_picon"),("track","adaptive_progress_track"),("keybar","adaptive_keybar"),
                             ("chip_quality","chip_video_quality"),("chip_video","chip_video_codec"),
                             ("chip_audio_codec","chip_audio_codec"),
                             ("chip_stream","chip_stream"),("chip_audio","chip_audio"),
                             ("chip_subtitles","chip_subtitles"),("chip_engine","chip_engine")):
                path=frames.get(key)
                if path and os.path.isfile(path) and self[name].instance is not None:
                    self[name].instance.setPixmapFromFile(path);self[name].show()
                else:
                    # Only poster-specific decoration may disappear. Core glass
                    # should always exist from the bundled fallback assets.
                    if key in ("poster_halo","poster","live_picon"):
                        self[name].hide()
            try:
                if self.media_type in ("itv","live"):
                    self["poster_neon_halo"].hide(); self["adaptive_poster"].hide();self["adaptive_live_picon"].show()
                else:
                    # VOD/episode layering is explicit and stable:
                    # real poster first, then the unchanged halo/frame layers above it.
                    self["adaptive_live_picon"].hide()
                    poster_path=str(getattr(self,"_poster_path","") or _cached_poster(self.item,self.name,self.media_type) or "")
                    if poster_path and os.path.isfile(poster_path) and self["logo"].instance is not None:
                        self["logo"].instance.setPixmapFromFile(poster_path);self["logo"].show()
                    self["poster_neon_halo"].show()
                    self["adaptive_poster"].show()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            accent=frames.get("accent") or "#b14b45"
            accent_soft=frames.get("accent_soft") or accent
            self._adaptive_accent_neon=frames.get("accent_neon") or accent_soft
            self._progress_neon_value=-1
            try:
                color=parseColor(accent)
                # Two-layer neon beam: a wide translucent aura plus a narrow white-hot
                # adaptive core.  No separate target/dot at the current position.
                hexrgb = accent.lstrip("#")
                self["watched_progress_glow"].instance.setForegroundColor(parseColor("#66" + hexrgb))
                self["watched_progress"].instance.setForegroundColor(parseColor(accent_soft))
                # Status text follows the poster palette instead of fixed cyan.
                self["connection"].instance.setForegroundColor(parseColor(accent_soft))
                self["quality"].instance.setForegroundColor(parseColor(accent_soft))
            except Exception as exc: optional_failure("player.adaptive_colors",exc)
            glow=frames.get("glow")
            if glow and os.path.isfile(glow) and self["progress_crystal"].instance is not None:
                self["progress_crystal"].instance.setPixmapFromFile(glow)
        except Exception as exc:optional_failure("player.adaptive_apply",exc)

    def _now_text(self):
        # The compact InfoBar is for playback state, not a duplicate channel name.
        # For Live, center text is reserved for real EPG only.
        if self.media_type in ("vod", "series", "episode", "catchup"):
            return ""
        text = self.item.get("now") or self.item.get("program") or self.item.get("epg_title") or ""
        text = str(text or "").strip()
        if not text:
            return ""
        try:
            if _clean_live_name(text).casefold() == _clean_live_name(self.name).casefold():
                return ""
        except Exception:
            if text.casefold() == str(self.name or "").casefold():
                return ""
        return text[:62]

    def _next_text(self):
        text = self.item.get("next") or self.item.get("next_program")
        if not text:
            if self.media_type in ("vod", "series", "episode", "catchup"):
                text = "Seek, audio tracks, subtitles and resume are available when supported by the stream"
            else:
                text = "Press BLUE to switch playback engine if the channel does not start"
        return str(text)[:56]

    def _init_online_subtitle_overlay(self):
        return

    def _init_online_subtitle_display(self):
        if self._online_subtitle_display is not None or SubtitleDisplay is None:
            return
        try:
            maker=getattr(self.session,"instantiateDialog",None)
            if callable(maker):
                self._online_subtitle_display=maker(SubtitleDisplay)
                self._online_subtitle_display.hideScreen()
                self._apply_subtitle_style_native()
        except Exception as exc:
            optional_failure("player.native_online_subtitle_init",exc)
            self._online_subtitle_display=None

    def _player_infobar_shown(self):
        return

    def _player_infobar_hidden(self):
        return

    def _set_online_subtitle_text(self,text):
        text=str(text or "")
        self._online_subtitle_current_text=text
        display=self._online_subtitle_display
        if display is None:
            # Safe fallback only; normal OpenBH path uses SubtitleDisplay.
            try:self["online_subtitle"].setText(text)
            except Exception:pass
            return
        try:
            if text:
                display.showSubtitles(text)
                self._apply_subtitle_style_native()
            else:
                display.hideSubtitles()
        except Exception as exc:
            optional_failure("player.native_online_subtitle_text",exc)

    def _subtitle_volume_osd_event(self):
        if self._online_subtitle_active and self._online_subtitle_current_text:
            try:self._set_online_subtitle_text(self._online_subtitle_current_text)
            except Exception:pass
            try:self.subtitle_volume_restore_timer.stop();self.subtitle_volume_restore_timer.start(80,True)
            except Exception:pass
        # Let the receiver's normal VolumeActions continue unchanged.
        return 0

    def _restore_subtitle_after_volume_osd(self):
        if not self._online_subtitle_active or not self._online_subtitle_current_text:return
        try:
            self._set_online_subtitle_text(self._online_subtitle_current_text)
            display=self._online_subtitle_display
            if display is not None:
                try:display.show()
                except Exception:pass
        except Exception as exc:optional_failure("player.subtitle_volume_restore",exc)

    def subtitleSelection(self,preselect_action=None):
        """One subtitle entry point: embedded tracks or exact online Arabic."""
        self._subtitle_user_override = True
        try:
            self.subtitle_default_timer.stop()
        except Exception as exc:
            optional_failure("player", exc)
        if ChoiceBox is None:
            return self._open_native_subtitles()
        choices=[
            (_("Embedded subtitles"), "embedded"),
            (_("Arabic Online • SubDL"), "online_AR"),
            (_("English Online • SubDL"), "online_EN"),
            (_("Turkish Online • SubDL"), "online_TR"),
            (_("French Online • SubDL"), "online_FR"),
            (_("Subtitle Color • %s")%_(_subtitle_color_name(self._subtitle_style.get("color"))), "style_color"),
            (_("Subtitle Background • %s")%(_("Black") if self._subtitle_style.get("background") else _("Off")), "style_background"),
            (_("Subtitle Position • %s")%_(_subtitle_position_name(self._subtitle_style.get("position"))), "style_position"),
        ]
        if self._online_subtitle_active:
            choices += [
                (_("Auto Sync • lightweight"), "auto_sync"),
                (_("Subtitle delay -0.5 sec"), "delay_minus"),
                (_("Subtitle delay +0.5 sec"), "delay_plus"),
                (_("Reset subtitle sync"), "sync_reset"),
            ]
        choices.append((_("Disable subtitles"), "disable"))
        try:
            source=str(getattr(self,"_poster_path","") or _cached_poster(self.item,self.name,self.media_type) or "")
            selected=0
            if preselect_action:
                for idx,row in enumerate(choices):
                    if isinstance(row,(tuple,list)) and len(row)>1 and row[1]==preselect_action:
                        selected=idx;break
            self.session.openWithCallback(
                self._subtitle_menu_selected,
                SubtitleGlassChoiceScreen,
                title=_("Ultra Stalker • Subtitles"),
                choices=choices,
                source_path=source,
                selected=selected,
            )
            return 1
        except Exception as exc:
            optional_failure("player.subtitle_menu",exc)
            return self._open_native_subtitles()

    def _native_subtitle_track_list(self):
        """Return the current service's real embedded subtitle list.

        ``None`` means this image/engine does not expose ``getSubtitleList``
        through the public subtitle interface, in which case the stock Enigma2
        selector remains the authority. An empty list means the interface is
        available but tracks have not been published yet (or truly do not
        exist).
        """
        try:
            service=self.session.nav.getCurrentService()
            subtitle=service.subtitle() if service else None
            if subtitle is None:
                return []
            getter=getattr(subtitle,"getSubtitleList",None)
            if not callable(getter):
                return None
            tracks=getter()
            if tracks is None:
                return []
            try:
                return list(tracks)
            except TypeError:
                return [tracks] if tracks else []
        except Exception as exc:
            optional_failure("player.embedded_subtitle_probe",exc)
            return []

    def _open_native_subtitle_selector_now(self):
        """Open OpenBH's real subtitle screen without the InfoBar pre-gate.

        InfoBarSubtitleSupport.subtitleSelection() first checks getSubtitleList()
        and silently returns when ServiceApp has not published the list at that
        exact instant. Our probe has already done the readiness check, so calling
        that wrapper here can make the user fall straight back to the player.
        Open the stock SubtitleSelection screen itself instead. The UI and track
        handling remain 100% native Enigma2/OpenBH.
        """
        self._embedded_subtitle_probe_pending=False
        try:self.embedded_subtitle_probe_timer.stop()
        except Exception:pass
        try:self.selected_subtitle=None
        except Exception:pass
        try:
            from Screens.AudioSelection import SubtitleSelection as _NativeSubtitleSelection
            self.session.open(_NativeSubtitleSelection, infobar=self)
            return 1
        except Exception as exc:
            optional_failure("player.native_subtitle_screen",exc)
        # Last-resort compatibility path for images with a non-standard
        # AudioSelection module.
        try:
            return InfoBarSubtitleSupport.subtitleSelection(self)
        except Exception as exc:
            optional_failure("player.native_subtitleSelection", exc)
            return 0

    def _embedded_subtitle_probe_tick(self):
        if not self._embedded_subtitle_probe_pending:
            return 0
        if self.restored or self._closing_playback:
            self._embedded_subtitle_probe_pending=False
            return 0
        self._embedded_subtitle_probe_attempts += 1
        tracks=self._native_subtitle_track_list()
        # If the image does not expose getSubtitleList(), do not second-guess
        # it. Open the receiver's own selector immediately.
        if tracks is None:
            return self._open_native_subtitle_selector_now()
        if tracks:
            return self._open_native_subtitle_selector_now()
        # ServiceApp/ExtePlayer can publish subtitle PIDs several seconds after
        # picture/audio are already running. Give the service a real window to
        # finish metadata discovery without blocking the GUI.
        if self._embedded_subtitle_probe_attempts < 12:
            try:
                self["connection"].setText(_("WAITING  •  EMBEDDED SUBTITLES"))
            except Exception:pass
            try:
                self.embedded_subtitle_probe_timer.stop()
                self.embedded_subtitle_probe_timer.start(450,True)
                return 1
            except Exception as exc:
                optional_failure("player.embedded_subtitle_timer",exc)
                return self._open_native_subtitle_selector_now()
        self._embedded_subtitle_probe_pending=False
        try:self["connection"].setText(_("PLAYING  •  %s") % _engine_label(self.servicetype))
        except Exception:pass
        try:
            self.session.open(MessageBox,_("No embedded subtitles were reported by this stream."),MessageBox.TYPE_INFO,timeout=5)
        except Exception:pass
        return 0

    def _open_native_subtitles(self):
        """Open the receiver's native embedded-subtitle screen immediately.

        This is an explicit user action, so do not hide the native screen behind
        InfoBarSubtitleSupport's subtitle-list readiness gate. OpenBH's
        SubtitleSelection screen already listens for service-info updates and can
        populate tracks as ServiceApp publishes them.
        """
        self._disable_online_subtitles()
        self._subtitle_user_override=True
        try:self.subtitle_default_timer.stop()
        except Exception:pass
        try:self.embedded_subtitle_probe_timer.stop()
        except Exception:pass
        self._embedded_subtitle_probe_pending=False
        return self._open_native_subtitle_selector_now()

    def _subtitle_menu_selected(self, choice=None):
        if not choice:
            return
        action=choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else choice
        if action=="embedded":
            self._open_native_subtitles()
        elif action=="disable":
            self._disable_online_subtitles()
            self._disable_native_subtitles()
            try:self["connection"].setText(_("PLAYING  •  SUBTITLES OFF"))
            except Exception:pass
        elif str(action).startswith("online_"):
            self._start_online_subtitles(str(action).split("_",1)[1])
        elif action=="style_color":
            self._open_subtitle_color_menu()
        elif action=="style_background":
            self._open_subtitle_background_menu()
        elif action=="style_position":
            self._open_subtitle_position_menu()
        elif action=="delay_minus":
            self._adjust_subtitle_delay(-500)
            self.subtitleSelection("delay_minus")
        elif action=="delay_plus":
            self._adjust_subtitle_delay(500)
            self.subtitleSelection("delay_plus")
        elif action=="sync_reset":
            self._online_subtitle_offset_ms=0;self._online_subtitle_scale=1.0;self._save_subtitle_sync()
            self.subtitleSelection("sync_reset")
        elif action=="auto_sync":
            self._auto_sync_subtitle()

    def _subtitle_picker_source(self):
        return str(getattr(self,"_poster_path","") or _cached_poster(self.item,self.name,self.media_type) or "")

    def _persist_subtitle_style(self):
        try:
            save_settings({
                "subtitle_color": str(self._subtitle_style.get("color") or "#FFFFFF"),
                "subtitle_background": bool(self._subtitle_style.get("background", False)),
                "subtitle_position": max(-260, min(260, int(self._subtitle_style.get("position", 0) or 0))),
            })
        except Exception as exc:optional_failure("player.subtitle_style_save",exc)

    def _apply_subtitle_style_native(self):
        """Style the stock OpenBH SubtitleDisplay in-place.

        No replacement Screen, no alternate subtitle lifecycle. The receiver still
        owns show/hide/timing; Ultra only changes the existing label presentation.
        """
        display=self._online_subtitle_display
        if display is None:return
        try:
            label=display["subtitles"]
            inst=getattr(label,"instance",None)
            if inst is None:return
            inst.setForegroundColor(parseColor(str(self._subtitle_style.get("color") or "#FFFFFF")))
            background=bool(self._subtitle_style.get("background",False))
            try:inst.setBackgroundColor(parseColor("#000000"))
            except Exception:pass
            try:inst.setTransparent(0 if background else 1)
            except Exception:pass

            # Native showSubtitles has already measured the cue. Reposition that
            # same label, without replacing SubtitleDisplay or its timers.
            try:
                size=label.getSize()
                width=max(100,int(size[0])+36);height=max(48,int(size[1])+16)
                desktop=getDesktop(0).size()
                offset=max(-260,min(260,int(self._subtitle_style.get("position",0) or 0)))
                x=max(0,(desktop.width()-width)//2)
                y=max(20,min(desktop.height()-height-18,desktop.height()-height-32-offset))
                inst.resize(eSize(width,height));inst.move(ePoint(x,y))
            except Exception as exc:optional_failure("player.subtitle_style_position",exc)
        except Exception as exc:
            optional_failure("player.subtitle_style_native",exc)

    def _refresh_online_subtitle_style(self):
        self._persist_subtitle_style()
        if self._online_subtitle_active and self._online_subtitle_current_text:
            # Re-render the currently visible cue through the proven native path.
            self._set_online_subtitle_text(self._online_subtitle_current_text)
        else:
            self._apply_subtitle_style_native()

    def _open_subtitle_color_menu(self):
        current=str(self._subtitle_style.get("color") or "#FFFFFF").upper()
        choices=[(("✓ " if value.upper()==current else "")+_(name),value) for name,value in SUBTITLE_STYLE_COLORS]
        self.session.openWithCallback(self._subtitle_color_selected,SubtitleGlassChoiceScreen,
            title=_("Subtitle Color"),choices=choices,source_path=self._subtitle_picker_source())

    def _subtitle_color_selected(self,choice=None):
        if not choice:return
        value=str(choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else choice or "").upper()
        valid={v.upper() for _n,v in SUBTITLE_STYLE_COLORS}
        if value not in valid:return
        self._subtitle_style["color"]=value;self._refresh_online_subtitle_style()
        self.subtitleSelection("style_color")

    def _open_subtitle_background_menu(self):
        enabled=bool(self._subtitle_style.get("background",False))
        choices=[(("✓ " if not enabled else "")+_("Off • text only"),False),
                 (("✓ " if enabled else "")+_("Black • behind subtitle text"),True)]
        self.session.openWithCallback(self._subtitle_background_selected,SubtitleGlassChoiceScreen,
            title=_("Subtitle Background"),choices=choices,source_path=self._subtitle_picker_source())

    def _subtitle_background_selected(self,choice=None):
        if not choice:return
        self._subtitle_style["background"]=bool(choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else False)
        self._refresh_online_subtitle_style()
        self.subtitleSelection("style_background")

    def _open_subtitle_position_menu(self):
        current=int(self._subtitle_style.get("position",0) or 0)
        choices=[(("✓ " if int(offset)==current else "")+_(name),int(offset)) for name,offset in SUBTITLE_POSITION_PRESETS]
        self.session.openWithCallback(self._subtitle_position_selected,SubtitleGlassChoiceScreen,
            title=_("Subtitle Position"),choices=choices,source_path=self._subtitle_picker_source())

    def _subtitle_position_selected(self,choice=None):
        if not choice:return
        try:value=int(choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else 0)
        except Exception:return
        self._subtitle_style["position"]=max(-260,min(260,value));self._refresh_online_subtitle_style()
        self.subtitleSelection("style_position")

    def _disable_native_subtitles(self):
        try:
            service=self.session.nav.getCurrentService()
            subtitle=service.subtitle() if service else None
            if subtitle is not None:
                window=getattr(self,"subtitle_window",None)
                instance=getattr(window,"instance",None) if window is not None else None
                if instance is not None:
                    subtitle.disableSubtitles(instance)
                else:
                    try:subtitle.disableSubtitles()
                    except TypeError:pass
            window=getattr(self,"subtitle_window",None)
            if window is not None:window.hide()
        except Exception as exc:
            optional_failure("player.disable_native_subtitles",exc)

    def _disable_online_subtitles(self):
        self._online_subtitle_active=False
        self._online_subtitle_searching=False
        self._online_subtitle_generation += 1
        try:self._online_subtitle_cancel.set()
        except Exception:pass
        future=getattr(self,"_online_subtitle_future",None)
        if future is not None:
            try:future.cancel()
            except Exception:pass
        self._online_subtitle_future=None
        self._online_subtitle_cues=[]
        self._online_subtitle_index=0
        self._online_subtitle_path=""
        try:self.online_subtitle_timer.stop()
        except Exception:pass
        try:self.online_subtitle_result_timer.stop()
        except Exception:pass
        try:
            while True:self._online_subtitle_queue.get_nowait()
        except Exception:pass
        try:self._set_online_subtitle_text("")
        except Exception:pass

    def _start_online_subtitles(self, language="AR"):
        language=str(language or "AR").upper()
        language_names={"AR":"Arabic","EN":"English","TR":"Turkish","FR":"French"}
        language_name=language_names.get(language,"Arabic")
        if language not in language_names:
            return
        self._online_subtitle_language=language
        self._online_subtitle_language_name=language_name
        if self.media_type not in ("vod","series","episode"):
            try:self.session.open(MessageBox,_("Online subtitles are available for Movies and Series."),MessageBox.TYPE_INFO,timeout=5)
            except Exception:pass
            return
        if self._online_subtitle_searching:return
        api_key=str(load_settings().get("subdl_api_key") or "").strip()
        if not api_key:
            try:self.session.open(MessageBox,_("SubDL API key is not configured."),MessageBox.TYPE_ERROR,timeout=6)
            except Exception:pass
            return
        self._disable_native_subtitles()
        self._online_subtitle_searching=True
        self._online_subtitle_generation += 1
        generation=self._online_subtitle_generation
        try:self._online_subtitle_cancel.set()
        except Exception:pass
        self._online_subtitle_cancel=threading.Event()
        cancel_token=self._online_subtitle_cancel
        result_queue=self._online_subtitle_queue
        try:
            self["connection"].setText(_("SEARCHING  •  SUBDL %s")%language_name.upper())
            self.show()
        except Exception:pass
        item=dict(self.item);media_type=self.media_type;name=self.name
        def worker():
            try:
                candidates,ident=search_language(api_key,item,media_type,name,language)
                if cancel_token.is_set():return
                result_queue.put(("choices",(candidates,ident,generation)))
            except Exception as exc:
                if cancel_token.is_set():return
                result_queue.put(("error",(str(exc),generation)))
        try:
            self._online_subtitle_future=_PLAYER_BG_EXECUTOR.submit(worker)
            self.online_subtitle_result_timer.start(250,False)
        except Exception as exc:
            self._online_subtitle_searching=False
            cancel_token.set()
            future=getattr(self,"_online_subtitle_future",None)
            if future is not None:
                try:future.cancel()
                except Exception:pass
            self._online_subtitle_future=None
            try:self.session.open(MessageBox,_("Subtitle search failed: %s")%exc,MessageBox.TYPE_ERROR,timeout=7)
            except Exception:pass

    def _drain_online_subtitle_result(self):
        if self.restored or self._closing_playback:
            try:self.online_subtitle_result_timer.stop()
            except Exception:pass
            return
        while True:
            try:kind,payload=self._online_subtitle_queue.get_nowait()
            except queue.Empty:return
            generation=self._online_subtitle_generation
            if kind=="choices" and isinstance(payload,tuple) and len(payload)==3:
                candidates,ident,generation=payload
                if generation!=self._online_subtitle_generation:continue
                payload=(candidates,ident)
            elif kind=="error" and isinstance(payload,tuple) and len(payload)==2:
                message,generation=payload
                if generation!=self._online_subtitle_generation:continue
                payload=message
            elif kind=="downloaded" and isinstance(payload,tuple) and len(payload)==2:
                result,generation=payload
                if generation!=self._online_subtitle_generation:continue
                payload=result
            break
        self._online_subtitle_future=None
        self._online_subtitle_searching=False
        try:self.online_subtitle_result_timer.stop()
        except Exception:pass
        if kind=="downloaded" and isinstance(payload,dict):
            try:
                self._activate_online_subtitle(str(payload.get("path") or ""),str(payload.get("release") or getattr(self,"_online_subtitle_language_name","Arabic")))
                return
            except Exception as exc:
                payload=_("Could not load subtitle: %s")%exc
        if kind=="choices":
            candidates,ident=payload
            self._online_subtitle_candidates=(candidates,ident)
            choices=[]
            for idx,c in enumerate(candidates):
                label=str(c.get("name") or (_("%s subtitle")%getattr(self,"_online_subtitle_language_name","Arabic")))
                if c.get("cached_path"):label="★ "+label
                choices.append((label[:110],idx))
            try:
                source=str(getattr(self,"_poster_path","") or _cached_poster(self.item,self.name,self.media_type) or "")
                self.session.openWithCallback(
                    self._online_subtitle_choice_selected,
                    SubtitleGlassChoiceScreen,
                    title=_("%s subtitles • %d found")%(getattr(self,"_online_subtitle_language_name","Arabic"),len(choices)),
                    choices=choices,
                    source_path=source,
                )
                return
            except Exception as exc:
                payload=_("Could not open subtitle results: %s")%exc
        try:
            self["connection"].setText(_("PLAYING  •  NO %s SUBTITLE")%getattr(self,"_online_subtitle_language_name","Arabic").upper())
            self.session.open(MessageBox,str(payload or (_("No %s subtitle found")%getattr(self,"_online_subtitle_language_name","Arabic"))),MessageBox.TYPE_INFO,timeout=8)
        except Exception:pass

    def _online_subtitle_choice_selected(self,choice=None):
        if not choice:return
        try:idx=int(choice[1])
        except Exception:return
        try:
            candidates,ident=self._online_subtitle_candidates
            candidate=candidates[idx]
        except Exception:return
        self._online_subtitle_searching=True
        self._online_subtitle_generation += 1
        generation=self._online_subtitle_generation
        try:self._online_subtitle_cancel.set()
        except Exception:pass
        self._online_subtitle_cancel=threading.Event()
        cancel_token=self._online_subtitle_cancel
        result_queue=self._online_subtitle_queue
        try:
            self["connection"].setText(_("DOWNLOADING  •  %s SUBTITLE")%getattr(self,"_online_subtitle_language_name","Arabic").upper())
            self.show()
        except Exception:pass
        def worker():
            try:
                result=download_candidate(candidate,ident)
                if cancel_token.is_set():return
                result_queue.put(("downloaded",(result,generation)))
            except Exception as exc:
                if cancel_token.is_set():return
                result_queue.put(("error",(str(exc),generation)))
        try:
            self._online_subtitle_future=_PLAYER_BG_EXECUTOR.submit(worker)
            self.online_subtitle_result_timer.start(250,False)
        except Exception as exc:
            self._online_subtitle_searching=False
            cancel_token.set()
            future=getattr(self,"_online_subtitle_future",None)
            if future is not None:
                try:future.cancel()
                except Exception:pass
            self._online_subtitle_future=None
            try:self.session.open(MessageBox,_("Subtitle download failed: %s")%exc,MessageBox.TYPE_ERROR,timeout=7)
            except Exception:pass

    def _subtitle_sync_file(self):
        path=str(self._online_subtitle_path or "")
        return (path+".sync.json") if path else ""

    def _load_subtitle_sync(self):
        self._online_subtitle_offset_ms=0;self._online_subtitle_scale=1.0
        path=self._subtitle_sync_file()
        if not path:return
        try:
            with open(path,"r",encoding="utf-8") as h:data=json.load(h)
            self._online_subtitle_offset_ms=max(-300000,min(300000,int(data.get("offset_ms") or 0)))
            scale=float(data.get("scale") or 1.0)
            self._online_subtitle_scale=scale if 0.94<=scale<=1.06 else 1.0
        except Exception:pass

    def _save_subtitle_sync(self):
        path=self._subtitle_sync_file()
        if not path:return
        try:
            temp=path+".tmp"
            with open(temp,"w",encoding="utf-8") as h:
                json.dump({"offset_ms":int(self._online_subtitle_offset_ms),"scale":float(self._online_subtitle_scale)},h,separators=(",",":"))
                h.flush();os.fsync(h.fileno())
            os.replace(temp,path)
        except Exception as exc:optional_failure("player.subtitle_sync_save",exc)

    def _adjust_subtitle_delay(self,delta_ms):
        if not self._online_subtitle_active:return
        self._online_subtitle_offset_ms=max(-300000,min(300000,int(self._online_subtitle_offset_ms)+int(delta_ms)))
        self._save_subtitle_sync()
        try:
            self.session.open(MessageBox,_("Subtitle delay: %+.1f sec")%(self._online_subtitle_offset_ms/1000.0),MessageBox.TYPE_INFO,timeout=2)
        except Exception:pass

    def _auto_sync_subtitle(self):
        """Safe lightweight drift correction without an always-running AI model.

        Detect only the two common 23.976<->25fps timing drifts when evidence is
        strong. Constant offsets stay user-adjustable in 0.5s steps.
        """
        if not self._online_subtitle_active or not self._online_subtitle_cues:return
        try:
            service=self.session.nav.getCurrentService();seek=service.seek() if service else None
            length=seek.getLength() if seek else None
            duration_ms=int(length[1] or 0)//90 if length and not length[0] else 0
        except Exception:duration_ms=0
        last_ms=int(self._online_subtitle_cues[-1][1] or 0)
        if duration_ms<=20*60*1000 or last_ms<=15*60*1000:
            try:self.session.open(MessageBox,_("Auto Sync needs a stable movie duration. Use delay +/- for this subtitle."),MessageBox.TYPE_INFO,timeout=5)
            except Exception:pass
            return
        ratio=float(duration_ms)/float(last_ms)
        candidates=(25.0/23.976,23.976/25.0)
        best=min(candidates,key=lambda x:abs(x-ratio))
        # Very conservative: only apply when measured ratio is close to a known
        # PAL/cinema drift and subtitle coverage reaches most of the movie.
        if abs(best-ratio)<=0.008 and last_ms>=int(duration_ms*0.88):
            self._online_subtitle_scale=float(best)
            self._save_subtitle_sync()
            try:self.session.open(MessageBox,_("Auto Sync applied • timing scale %.5f")%best,MessageBox.TYPE_INFO,timeout=4)
            except Exception:pass
        else:
            try:self.session.open(MessageBox,_("No safe automatic drift detected. Use subtitle delay +/- for this release."),MessageBox.TYPE_INFO,timeout=5)
            except Exception:pass

    def _activate_online_subtitle(self,path,release_name="Arabic"):
        cues=parse_srt(path)
        if not cues:
            raise RuntimeError("subtitle file contains no readable cues")
        self._disable_native_subtitles()
        self._online_subtitle_path=path
        self._online_subtitle_cues=cues
        self._online_subtitle_index=0
        self._load_subtitle_sync()
        self._online_subtitle_active=True
        self._subtitle_user_override=True
        try:self["online_subtitle"].hide()
        except Exception:pass
        self._set_online_subtitle_text("")
        self.online_subtitle_timer.start(80,True)
        try:self["connection"].setText(_("PLAYING  •  ARABIC SUBTITLES"))
        except Exception:pass
        return True

    def _online_subtitle_tick(self):
        if not self._online_subtitle_active or self.restored or self._closing_playback:
            try:self["online_subtitle"].setText("")
            except Exception:pass
            return
        try:
            service=self.session.nav.getCurrentService()
            seek=service.seek() if service else None
            pos=seek.getPlayPosition() if seek else None
            if not pos or pos[0]:
                return
            ms=max(0,int(pos[1] or 0)//90)
            scale=float(self._online_subtitle_scale or 1.0)
            timeline_ms=max(0,int((ms-int(self._online_subtitle_offset_ms or 0))/scale))
        except Exception:
            return
        ms=timeline_ms
        cues=self._online_subtitle_cues
        idx=max(0,min(int(self._online_subtitle_index or 0),max(0,len(cues)-1)))
        while idx<len(cues) and cues[idx][1] < ms:
            idx+=1
        while idx>0 and cues[idx-1][0] > ms:
            idx-=1
        self._online_subtitle_index=idx
        text=""
        if idx<len(cues):
            start,end,body=cues[idx]
            if start<=ms<=end:
                text=body
        try:self._set_online_subtitle_text(text)
        except Exception as exc:optional_failure("player.online_subtitle_tick",exc)
        # Wake near the next cue boundary instead of polling the decoder forever
        # every 180/300ms. This keeps subtitle timing responsive without making
        # Enigma2's main loop do constant seek() calls.
        try:
            wait=700
            if idx<len(cues):
                start,end,_body=cues[idx]
                boundary=end if start<=ms<=end else start
                wait=max(90,min(700,int(abs(boundary-ms))))
            self.online_subtitle_timer.start(wait,True)
        except Exception:pass

    def _enforce_default_subtitles_off(self):
        """Block cached/automatic subtitles until the user explicitly opens the selector."""
        if self.restored or self._subtitle_user_override:
            return
        try:
            # A truthy sentinel prevents InfoBarSubtitleSupport.__updatedInfo from
            # auto-enabling getCachedSubtitle() again on the next metadata event.
            self.selected_subtitle = (0, 0, 0, 0)
            service = self.session.nav.getCurrentService()
            subtitle = service.subtitle() if service else None
            if subtitle is not None:
                window = getattr(self, "subtitle_window", None)
                instance = getattr(window, "instance", None) if window is not None else None
                if instance is not None:
                    subtitle.disableSubtitles(instance)
                else:
                    try:
                        subtitle.disableSubtitles()
                    except TypeError:
                        pass
            window = getattr(self, "subtitle_window", None)
            if window is not None:
                window.hide()
        except Exception as exc:
            optional_failure("player.default_subtitles_off", exc)
        self._subtitle_disable_attempts += 1
        if self._subtitle_disable_attempts < 4 and not self._subtitle_user_override:
            try:
                self.subtitle_default_timer.start(900, True)
            except Exception as exc:
                optional_failure("player", exc)

    def _schedule_startup_guard(self, reason):
        """Debounce stale EOF/tune-failed events from ServiceApp/ExtePlayer.

        VOD and episodes sometimes decode a second of video and then emit a stale
        startup event for the previous engine/service. Never restart immediately;
        verify the active reference and advancing play position first.
        """
        if self.media_type not in ("vod", "series", "episode", "catchup"):
            return False
        self._early_eof_pending = True
        self._startup_guard_reason = str(reason or "startup interruption")
        self._startup_guard_checks = 0
        try:
            self.eof_guard_timer.stop()
            self.eof_guard_timer.start(1100, True)
            return True
        except Exception as exc:
            optional_failure("player", exc)
            return False

    def _category_label(self):
        return {
            "itv": "LIVE",
            "live": "LIVE",
            "vod": "MOVIE",
            "series": "SERIES",
            "episode": "EPISODE",
            "catchup": "CATCH-UP",
        }.get(self.media_type, self.media_type.upper()[:10])

    def playStream(self, servicetype, streamurl):
        runtime_breadcrumb("player_start_request",media_type=self.media_type,engine=int(servicetype or 0))
        if self.restored or self._closing_playback:
            return
        if not streamurl:
            self._final_failure("Empty stream URL")
            return

        try:
            service_value = int(servicetype)
        except Exception:
            service_value = 4097
        self.servicetype = service_value
        self._play_generation += 1
        self.started = False
        self.failed = False
        self._early_eof_pending = False
        self._startup_guard_checks = 0
        self._startup_guard_last_position = -1
        self._startup_guard_reason = ""
        self._startup_guard_until = time.time() + (8.0 if self.media_type in ("vod", "series", "episode", "catchup") else 0.0)
        self._video_guard_misses = 0
        self._video_guard_last_engine = int(service_value)
        self._engine_video_confirmed = False
        self._subtitle_user_override = False
        self._subtitle_disable_attempts = 0
        self._embedded_subtitle_probe_pending = False
        self._embedded_subtitle_probe_attempts = 0
        try:
            self.embedded_subtitle_probe_timer.stop()
        except Exception:
            pass
        try:
            self.subtitle_default_timer.stop()
        except Exception as exc:
            optional_failure("player", exc)
        try:
            self.eof_guard_timer.stop()
        except Exception as exc:
            optional_failure("player", exc)
        self.start_attempt = time.time()
        self["engine"].setText(_engine_label(self.servicetype))
        self["connection"].setText(_("CONNECTING  •  %s") % _engine_label(self.servicetype))
        self["extension"].setText(_("STREAM"))

        try:
            self.reference = eServiceReference(self.servicetype, 0, str(streamurl))
            self.reference.setName(self.name)
            try:self._owned_reference_string=self.reference.toString()
            except Exception:self._owned_reference_string=""
            # Match the proven reference implementation lifecycle: replace the current service
            # directly from inside the player screen. Calling stopService first
            # can emit an EOF for the old service and falsely trigger fallback.
            result = self.session.nav.playService(self.reference)
            try: self._owned_external_pids.update(set(_matching_external_player_pids(self.streamurl))-set(self._external_player_baseline))
            except Exception as exc: optional_failure("player.capture_external",exc)
            if result is False:
                raise RuntimeError("service engine rejected the stream")
            self.startup_timer.stop()
            self.startup_timer.start(12000, True)
        except Exception as exc:
            self._try_next_engine("engine %s rejected stream: %s" % (self.servicetype, exc))

    def _service_started(self):
        if self.restored or self._closing_playback:
            return
        already_started = bool(self.started)
        self.started = True
        if not already_started or not self._watch_started_at:
            self._watch_started_at = time.time()
        try:
            self.startup_timer.stop()
        except Exception as exc:
            optional_failure("player", exc)
        self["connection"].setText(_("PLAYING  •  %s") % _engine_label(self.servicetype))
        runtime_breadcrumb("player_started",media_type=self.media_type,engine=int(self.servicetype or 0))
        try:
            self._owned_external_pids.update(set(_all_external_player_pids())-set(self._external_player_baseline))
        except Exception as exc:optional_failure("player.capture_external_started",exc)
        self._last_network_activity = time.monotonic()
        try:
            self.memory_fuse_timer.stop();self.memory_fuse_timer.start(5000,False)
        except Exception as exc:optional_failure("player.silent_guard",exc)
        try:
            self.stable_timer.stop(); self.stable_timer.start(30000, True)
        except Exception as exc:
            optional_failure("player", exc)
        if not already_started:
            try:
                self.subtitle_default_timer.stop(); self.subtitle_default_timer.start(450, True)
            except Exception as exc:
                optional_failure("player", exc)
        self["state"].setText(_("PLAYING"))
        # Last Viewed is intentionally separate from Resume. Touch recency as
        # soon as Enigma2 confirms real playback, while preserving any existing
        # resume point. Progress itself is still saved only after the 45s gate.
        if self.media_type in ("vod","series","episode","catchup"):
            try:
                profile=self._history_profile
                history_item=self._history_item
                touch_recently_played(profile,self.media_type,history_item)
            except Exception as exc:optional_failure("player",exc)
        self._update_stream_info()
        try:
            self["statusicon"].setPixmapNum(0)
        except Exception as exc:
            optional_failure("player", exc)
        if self.media_type in ("vod", "series", "episode", "catchup"):
            try:
                self.progress_timer.stop(); self.progress_timer.start(self._cfg_progress_interval_ms, False)
                self.crystal_timer.stop(); self.crystal_timer.start(1000, False)
            except Exception as exc:
                optional_failure("player", exc)
            if not self.resume_prompted:
                self.resume_prompted=True

    def _suppress_service_events(self, seconds=1.25):
        self._event_suppress_until=max(float(getattr(self,"_event_suppress_until",0.0) or 0.0),time.time()+max(0.0,float(seconds or 0.0)))

    def _event_matches_current_reference(self):
        # stopService() intentionally emits EOF/TuneFailed on several OE-A images.
        # Ignore those stale events briefly; the startup watchdog still catches a
        # genuinely failed replacement service.
        if time.time() < float(getattr(self,"_event_suppress_until",0.0) or 0.0):
            return False
        try:
            current = self.session.nav.getCurrentlyPlayingServiceReference()
            if current is None or self.reference is None:
                return True
            return current.toString() == self.reference.toString()
        except Exception:
            return True

    def _service_failed(self):
        if self.restored or self._closing_playback:
            return
        if not self._event_matches_current_reference():
            return
        elapsed = time.time() - self.start_attempt if self.start_attempt else 999
        if self.media_type in ("vod", "series", "episode", "catchup") and elapsed < 8.0:
            self["connection"].setText(_("PLAYING  •  verifying startup") if self.started else _("CONNECTING  •  verifying startup"))
            self._schedule_startup_guard("transient tune failed")
            return
        if self.started and self.media_type in ("itv", "live"):
            if self._handle_runtime_interruption("tune failed during playback"):
                return
        self._try_next_engine("tune failed")

    def _service_eof(self):
        if self.restored or self._closing_playback:
            return
        if not self._event_matches_current_reference():
            return
        if self._resume_target and time.time() < self._resume_grace_until:
            try:
                self.eof_guard_timer.stop(); self.eof_guard_timer.start(1800, True)
            except Exception as exc:
                optional_failure("player", exc)
            return
        elapsed = time.time() - self.start_attempt if self.start_attempt else 999
        if self.media_type in ("vod", "series", "episode", "catchup") and elapsed < 8.0:
            self["connection"].setText(_("PLAYING  •  stabilizing stream") if self.started else _("CONNECTING  •  stabilizing stream"))
            self._schedule_startup_guard("transient early EOF")
            return
        if not self.started:
            self._try_next_engine("stream ended before playback started")
            return
        if self.media_type in ("itv", "live"):
            if self._handle_runtime_interruption("stream ended during playback"):
                return
        if self.media_type in ("vod", "series", "episode", "catchup"):
            # Natural EOF is different from the user pressing BACK. Freeze the
            # periodic writer so it cannot overwrite the completed state while
            # the 10-second Next Episode prompt is on screen.
            try: self.progress_timer.stop()
            except Exception as exc: optional_failure("player", exc)
            self._save_history_progress(force=True, completed_override=True)
            next_item = self.item.get("_next_episode_item") if self.media_type == "episode" else None
            global NEXT_EPISODE_AUTOPLAY_SESSION
            if isinstance(next_item, dict) and next_item and not self._next_episode_prompted and NEXT_EPISODE_AUTOPLAY_SESSION:
                self._next_episode_prompted = True
                try:
                    self.session.openWithCallback(self._next_episode_answer, UltraStalkerNextEpisodePrompt, next_item, self._cfg_next_episode_countdown)
                    return
                except Exception as exc:
                    optional_failure("player.next_episode_prompt", exc)
            self._close_player(save_progress=False)

    def _mark_stream_stable(self):
        if self.restored or not self.started:
            return
        self._runtime_reconnects = 0
        self._recovery_attempts = 0

    def _handle_runtime_interruption(self, reason):
        if self.restored or self._closing_playback:return False
        try:self.stable_timer.stop()
        except Exception as exc:optional_failure("player.silent_guard",exc)
        # Never tear down/recreate a decoder automatically. Broadcom native
        # allocations were observed accumulating across repeated Stop/Play cycles.
        self.started=False
        self["connection"].setText(_("STREAM INTERRUPTED  •  press 0 to restart"))
        runtime_breadcrumb("player_interruption_no_restart",media_type=self.media_type,reason=str(reason or ""))
        return True


    def _verify_early_eof(self):
        if not self._early_eof_pending or self.restored or self.failed:
            return
        now = time.time()
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
            pos = seekable.getPlayPosition() if seekable else None
            position = abs(int(pos[1])) if pos and not pos[0] else -1
        except Exception:
            position = -1
        ref_ok = self._event_matches_current_reference()
        previous = self._startup_guard_last_position
        self._startup_guard_last_position = position
        self._startup_guard_checks += 1
        # Advancing decoded position is definitive proof that playback survived
        # the stale event; keep the current engine and do not restart.
        if ref_ok and position >= 0 and previous >= 0 and position > previous + 9000:
            self._early_eof_pending = False
            self["connection"].setText(_("PLAYING  •  %s") % _engine_label(self.servicetype))
            return
        if ref_ok and self.started and position > 45000:
            self._early_eof_pending = False
            self["connection"].setText(_("PLAYING  •  %s") % _engine_label(self.servicetype))
            return
        # Never bounce engines during the protected startup window merely because
        # one probe cannot read a seek position yet. External players often expose
        # seek() a few seconds after video begins.
        if ref_ok and now < self._startup_guard_until and self._startup_guard_checks < 7:
            try:
                self.eof_guard_timer.start(1000, True)
            except Exception as exc:
                optional_failure("player", exc)
            return
        self._early_eof_pending = False
        self._try_next_engine(self._startup_guard_reason or "stream stopped during startup verification")

    def _startup_timeout(self):
        if self.restored or self._closing_playback:
            return
        if not self.started:
            self._try_next_engine("startup timeout")

    def _try_next_engine(self, reason):
        if self.restored or self._closing_playback or self.failed:return
        try:self.startup_timer.stop()
        except Exception as exc:optional_failure("player.silent_guard",exc)
        # Engine and service are deterministic. Startup failure is surfaced; it
        # is never converted into a hidden Stop/Play/URL-refresh loop.
        self._final_failure(reason)


    def _begin_smart_recovery(self, reason):
        # Disabled by design on this receiver: refreshing a link previously
        # recreated the native decoder and contributed to unbounded RSS growth.
        return False


    def _cancel_smart_recovery(self):
        self._recovery_inflight = False
        cancel_event = getattr(self, "_recovery_cancel", None)
        if cancel_event is not None:
            try: cancel_event.set()
            except Exception as exc: optional_failure("player.recovery_cancel", exc)
        lock = getattr(self, "_recovery_client_lock", None)
        client = None
        if lock is not None:
            try:
                with lock:
                    client = getattr(self, "_recovery_client", None)
            except Exception as exc:
                optional_failure("player.recovery_cancel", exc)
        if client is not None:
            try: client.cancel_pending_requests()
            except Exception as exc: optional_failure("player.recovery_cancel", exc)

    def _drain_recovery_result(self):
        try:self.recovery_timer.stop()
        except Exception as exc:optional_failure("player.silent_guard",exc)
        self._recovery_inflight=False
        while True:
            try:self._recovery_queue.get_nowait()
            except queue.Empty:break


    def _final_failure(self, reason):
        if self.failed:
            return
        self.failed = True
        self["connection"].setText(_("PLAYBACK FAILED"))
        text = "The stream could not start with the configured Enigma2 engine.\n\n%s\n\nTried: %s" % (
            reason,
            ", ".join(str(x) for x in self.engines),
        )
        try:
            self.session.openWithCallback(lambda answer=None: self.back(), MessageBox, text, MessageBox.TYPE_ERROR, timeout=10)
        except Exception:
            self.back()

    def restartStream(self):
        self._save_history_progress()
        self.playStream(self.servicetype, self.streamurl)

    def toggleStreamType(self):
        try:
            configured=int(self._cfg_service_type)
        except Exception:
            configured=self.servicetype
        self["connection"].setText(_("ENGINE LOCKED  •  %s  •  change it in Settings") % _engine_label(configured))
        try:self.doShow()
        except Exception as exc:optional_failure("player.optional_guard",exc)


    def _remember_manual_title_engine(self, chosen):
        # Engine selection is globally locked to Settings. Kept as a no-op for
        # compatibility with older callbacks that may still reference it.
        return

    def _engine_choice_answer(self, answer):
        try: chosen=int(self._cfg_service_type)
        except (TypeError,ValueError): chosen=int(self.servicetype or 4097)
        if chosen not in (1,4097,5001,5002,8193): chosen=4097
        self.engines=[chosen];self.engine_index=0;self.servicetype=chosen
        self["connection"].setText(_("ENGINE LOCKED  •  %s  •  change it in Settings") % _engine_label(chosen))
        self.playStream(chosen,self.streamurl)
        try:self.doShow()
        except Exception as exc:optional_failure("player.optional_guard",exc)

    def _infobar_is_shown(self):
        try:
            return getattr(self,"_IPTVInfoBarShowHide__state",IPTVInfoBarShowHide.STATE_HIDDEN)==IPTVInfoBarShowHide.STATE_SHOWN
        except Exception:
            return False

    def OKButton(self):
        if self.media_type in ("itv","live") and self._zap_channels:
            # First OK is always reserved for the InfoBar. Only a subsequent OK
            # while that InfoBar is actually visible opens the channel drawer.
            if (not self._zap_infobar_armed) or (not self._infobar_is_shown()):
                self._zap_infobar_armed=True
                try:self.doShow()
                except Exception:IPTVInfoBarShowHide.OkPressed(self)
                return
            self._zap_infobar_armed=False
            self._openZapList()
            return
        IPTVInfoBarShowHide.OkPressed(self)

    def _openZapList(self):
        if self._zap_open or self.media_type not in ("itv","live") or not self._zap_channels:
            return
        self._zap_open=True
        try:self.hideTimer.stop()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        channels=list(self._zap_channels)
        # Resolve the drawer palette from the actual current channel row, not the
        # stale player bootstrap item. This also replaces the generic monitor
        # placeholder with the cached channel picon whenever it is available.
        current_row=None
        try:
            if 0<=int(self._zap_index)<len(channels) and isinstance(channels[int(self._zap_index)],dict):
                current_row=channels[int(self._zap_index)]
        except Exception:
            current_row=None
        picon=_cached_poster(current_row or self.item,self.name,self.media_type)
        if self._zap_total>len(channels):channels.extend([None]*(self._zap_total-len(channels)))
        try:
            self.session.openWithCallback(
                self._onZapSelected, UltraStalkerLiveZapList, channels, self._zap_index,
                self._zap_title, picon, self._zap_page_loader, self._zap_page_size, self._zap_total
            )
        except Exception as exc:
            self._zap_open=False
            optional_failure("player.open_zap_list",exc)
            try:self.doShow()
            except Exception as exc:optional_failure("player.optional_guard",exc)

    def _onZapSelected(self,result=None):
        self._zap_open=False
        self._zap_infobar_armed=False
        if not result:
            try:self.doShow()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            return
        try:index,item=result
        except Exception:return
        self._switchChannel(index,item)

    def _quickZap(self,delta):
        """Switch previous/next Live channel without opening the drawer."""
        if self.media_type not in ("itv","live") or self._zap_open:
            return
        total=max(int(getattr(self,"_zap_total",0) or 0),len(getattr(self,"_zap_channels",[]) or []))
        if total<=1:
            return
        if self._zap_switch_inflight:
            return
        step=-1 if int(delta or 0)<0 else 1
        target=(int(getattr(self,"_zap_index",0) or 0)+step)%total
        self._zap_infobar_armed=False
        channels=getattr(self,"_zap_channels",[]) or []
        row=channels[target] if 0<=target<len(channels) else None
        if isinstance(row,dict):
            self._switchChannel(target,row)
            return
        self._switchChannelByIndex(target)

    def _switchChannelByIndex(self,index):
        """Resolve an unloaded folder row lazily, then reuse the normal zap path."""
        client=self.item.get("_live_client_ref")
        if client is None:
            self["connection"].setText(_("CHANNEL SWITCH UNAVAILABLE"))
            return
        if self._zap_switch_inflight:
            return
        total=max(int(getattr(self,"_zap_total",0) or 0),len(getattr(self,"_zap_channels",[]) or []))
        if total<=0:
            return
        index=max(0,min(int(index),total-1))
        self._zap_switch_generation+=1
        generation=self._zap_switch_generation
        self._zap_switch_inflight=True
        self._zap_switch_started_at=time.monotonic()
        self["connection"].setText(_("SWITCHING CHANNEL..."))
        page_loader=self._zap_page_loader
        page_size=max(1,int(self._zap_page_size or 1))
        channels=getattr(self,"_zap_channels",[]) or []
        cached=channels[index] if 0<=index<len(channels) and isinstance(channels[index],dict) else None
        result_queue=self._zap_switch_queue
        def worker():
            page=0;rows=[];item=dict(cached) if isinstance(cached,dict) else None
            try:
                if item is None and callable(page_loader):
                    page=max(1,index//page_size+1)
                    try:loaded=page_loader(page)
                    except TypeError:loaded=page_loader(page,None)
                    rows=[dict(x) for x in (loaded or []) if isinstance(x,dict)]
                    base=(page-1)*page_size
                    rel=index-base
                    if 0<=rel<len(rows):item=dict(rows[rel])
                if not isinstance(item,dict):
                    raise ValueError("target channel row unavailable")
                url=client.create_link(item,"itv")
                result_queue.put((generation,index,item,str(url or ""),None,page,rows))
            except Exception as exc:
                result_queue.put((generation,index,item or {},"",exc,page,rows))
        try:
            self._zap_switch_future=_PLAYER_BG_EXECUTOR.submit(worker)
            self.zap_switch_timer.start(120,False)
        except Exception as exc:
            self._zap_switch_generation+=1;self._zap_switch_inflight=False;self._zap_switch_started_at=0.0
            future=getattr(self,"_zap_switch_future",None)
            if future is not None:
                try:future.cancel()
                except Exception:pass
            self._zap_switch_future=None
            optional_failure("player.quick_zap_worker_start",exc)
            self["connection"].setText(_("CHANNEL SWITCH FAILED"))

    def _switchChannel(self,index,item):
        if not isinstance(item,dict):
            return
        client=self.item.get("_live_client_ref")
        if client is None:
            self["connection"].setText(_("CHANNEL SWITCH UNAVAILABLE"))
            try:self.doShow()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            return
        if self._zap_switch_inflight:
            self["connection"].setText(_("CHANNEL SWITCH IN PROGRESS..."))
            return
        self._zap_switch_generation += 1
        generation=self._zap_switch_generation
        self._zap_switch_inflight=True
        self._zap_switch_started_at=time.monotonic()
        self["connection"].setText(_("SWITCHING CHANNEL..."))
        result_queue=self._zap_switch_queue
        item_snapshot=dict(item)
        def worker():
            try:
                url=client.create_link(item_snapshot,"itv")
                result_queue.put((generation,index,item_snapshot,str(url or ""),None))
            except Exception as exc:
                result_queue.put((generation,index,item_snapshot,"",exc))
        try:
            self._zap_switch_future=_PLAYER_BG_EXECUTOR.submit(worker)
            self.zap_switch_timer.start(120,False)
        except Exception as exc:
            self._zap_switch_generation+=1;self._zap_switch_inflight=False;self._zap_switch_started_at=0.0
            future=getattr(self,"_zap_switch_future",None)
            if future is not None:
                try:future.cancel()
                except Exception:pass
            self._zap_switch_future=None
            optional_failure("player.zap_worker_start",exc)
            self["connection"].setText(_("CHANNEL SWITCH FAILED"))

    def _drain_zap_switch_result(self):
        if self.restored or self._closing_playback:
            try:self.zap_switch_timer.stop()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            return
        try:
            result=self._zap_switch_queue.get_nowait()
            generation,index,item,url,error=result[:5]
            loaded_page=(result[5] if len(result)>5 else 0)
            loaded_rows=(result[6] if len(result)>6 else [])
        except queue.Empty:
            # A pathological portal/library call must not leave channel switching
            # permanently locked. Invalidate the generation; a late worker result
            # will be ignored safely.
            try:timeout=self._cfg_timeout
            except Exception:timeout=15.0
            if self._zap_switch_inflight and self._zap_switch_started_at and time.monotonic()-self._zap_switch_started_at>timeout:
                self._zap_switch_generation+=1;self._zap_switch_inflight=False;self._zap_switch_started_at=0.0
                try:self.zap_switch_timer.stop()
                except Exception as exc:optional_failure("player.optional_guard",exc)
                self["connection"].setText(_("CHANNEL SWITCH TIMED OUT"))
                try:self.doShow()
                except Exception as exc:optional_failure("player.optional_guard",exc)
            return
        if generation != self._zap_switch_generation:
            return
        self._zap_switch_future=None
        # Quick-zap may have lazily fetched the target portal page. Merge those
        # rows into the player folder snapshot on the GUI thread so subsequent
        # UP/DOWN presses are instant and the drawer sees the same warmed data.
        if loaded_page and loaded_rows:
            try:
                base=(int(loaded_page)-1)*max(1,int(self._zap_page_size or 1))
                if len(self._zap_channels)<self._zap_total:self._zap_channels.extend([None]*(self._zap_total-len(self._zap_channels)))
                for pos,row in enumerate(loaded_rows):
                    absolute=base+pos
                    if 0<=absolute<len(self._zap_channels) and isinstance(row,dict):self._zap_channels[absolute]=row
            except Exception as exc:optional_failure("player.quick_zap_merge_page",exc)
        self._zap_switch_inflight=False
        self._zap_switch_started_at=0.0
        try:self.zap_switch_timer.stop()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        if error or not url:
            self["connection"].setText(_("CHANNEL SWITCH FAILED"))
            try:self.doShow()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            return

        old_url=self.streamurl
        self._suppress_service_events(1.25)
        try:force_session_silence(self.session,old_url,force=True,stop_native=True,exclude_pids=self._external_player_baseline,owned_pids=self._owned_external_pids)
        except Exception as exc:optional_failure("player.zap_stop_owned",exc)
        self._owned_external_pids.clear()

        self._zap_index=max(0,int(index))
        self.item.update(item)
        self.name=_clean_live_name(str(item.get("name") or item.get("title") or "Live channel"))
        self.streamurl=url
        self["channel"].setText(self.name[:120])
        try:self["now"].setText(self._now_text());self["next"].setText(self._next_text());self["category"].setText(self._category_label())
        except Exception as exc:optional_failure("player.optional_guard",exc)
        try:
            engine=int(self._cfg_service_type)
        except (TypeError,ValueError):
            engine=int(self.servicetype or 4097)
        if engine not in (1,4097,5001,5002,8193):engine=4097
        self.engines=[engine];self.engine_index=0;self.servicetype=engine
        self.playStream(engine,url)
        try:self.doShow()
        except Exception as exc:optional_failure("player.optional_guard",exc)

    def _cancel_pending_resume_for_manual_seek(self):
        """A viewer seek permanently cancels any pending automatic Resume seek."""
        self._resume_target=0
        self._resume_grace_until=0.0
        self.resume_prompted=True
        try:self.resume_timer.stop()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        try:self.resume_verify_timer.stop()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        try:self._release_resume_shield()
        except Exception as exc:optional_failure("player.optional_guard",exc)

    def _play_state_changed(self, state):
        try:
            value = state[3] or ""
        except Exception:
            value = ""
        if self.media_type in ("vod","series","episode","catchup"):
            if value.startswith(">>") or value.startswith("<<") or value.startswith("/"):
                # Do not let a delayed Resume seek wake up after the viewer
                # manually rewinds/forwards.  Also avoid saving the transient
                # end-of-file sentinel some ServiceApp builds report during
                # trick-play state changes.
                self._cancel_pending_resume_for_manual_seek()
            elif value in ("||", ">"):
                self._save_history_progress(force=True)
        speed = ""
        icon = 6
        if value == ">":
            icon = 0
        elif value == "||":
            icon = 1
        elif value == "END":
            icon = 2
        elif value.startswith(">>"):
            icon = 3
            parts = value.split()
            speed = parts[1] if len(parts) > 1 else value[2:]
        elif value.startswith("<<"):
            icon = 4
            parts = value.split()
            speed = parts[1] if len(parts) > 1 else value[2:]
        elif value.startswith("/"):
            icon = 5
            speed = value
        label = value
        if value == ">":
            label = "PLAYING"
        elif value == "||":
            label = "PAUSED"
            if self._cfg_crash_safe_progress:
                self._save_history_progress(force=True)
        elif value == "END":
            label = "STOPPED"
        elif value.startswith(">>"):
            label = "FORWARD"
        elif value.startswith("<<"):
            label = "REWIND"
        elif value.startswith("/"):
            label = "SLOW"
        self["state"].setText(label)
        self["speed"].setText(speed)
        try:
            self["statusicon"].setPixmapNum(icon)
        except Exception as exc:
            optional_failure("player", exc)
    def _schedule_resume_probe(self):
        attempt=max(0,int(self._resume_verify_attempts or 0))
        delay=min(1200,50*(2**min(attempt,4)))
        self.resume_verify_timer.stop(); self.resume_verify_timer.start(delay,True)

    def _perform_resume_seek(self):
        """Apply the saved bookmark once, but only after the decoder is truly seekable.

        ServiceApp/ExtePlayer3 can expose service.seek() at evStart before
        seekTo() is actually honoured.  We therefore require a valid length and
        play position, plus a short decoder-settle window, before issuing the
        single absolute seek.
        """
        if not self._resume_target or self.restored or self._closing_playback:return
        if self._resume_seek_count>0:return
        try:
            # Give ServiceApp a moment after evStart to publish a usable
            # iSeekableService. Readiness probes do not count as seek attempts.
            if self._watch_started_at and (time.time()-self._watch_started_at)<0.55:
                self._resume_verify_attempts+=1;self._schedule_resume_probe();return
            service=self.session.nav.getCurrentService();seekable=service.seek() if service else None
            if seekable is None:
                self._resume_verify_attempts+=1
                if self._resume_verify_attempts<14:self._schedule_resume_probe()
                else:self._resume_target=0;self._release_resume_shield()
                return
            native_probe=getattr(self,"isCurrentlySeekable",None)
            if callable(native_probe):
                try:
                    state=native_probe()
                    if isinstance(state,(tuple,list)):
                        state=(not state[0]) and (len(state)<2 or bool(state[1]))
                    if not bool(state):
                        self._resume_verify_attempts+=1;self._schedule_resume_probe();return
                except Exception as exc:optional_failure("player.optional_guard",exc)
            length=seekable.getLength();position=seekable.getPlayPosition()
            length_ok=bool(length and not length[0] and int(length[1] or 0)>30*90000)
            pos_ok=bool(position and not position[0] and int(position[1] or 0)>=0)
            if not (length_ok and pos_ok):
                self._resume_verify_attempts+=1
                if self._resume_verify_attempts<14:self._schedule_resume_probe()
                else:self._resume_target=0;self._release_resume_shield();self["connection"].setText(_("PLAYING  •  resume unavailable"))
                return
            target=min(int(self._resume_target),max(0,int(length[1])-10*90000))
            result=seekable.seekTo(target)
            # Enigma2 implementations commonly return None/0 on success.  What
            # matters is that the command was issued after verified readiness.
            self._resume_seek_count=1
            self._last_progress_position=target
            self["connection"].setText(_("RESUMING  •  %d:%02d")%(target//90000//60,target//90000%60))
            self.resume_verify_timer.stop();self.resume_verify_timer.start(450,True)
        except Exception as exc:
            optional_failure("player.resume_seek",exc)
            self._resume_verify_attempts+=1
            if self._resume_seek_count==0 and self._resume_verify_attempts<14:self._schedule_resume_probe()
            else:
                self._resume_target=0;self._release_resume_shield()

    def _verify_resume_position(self):
        if not self._resume_target or self.restored or self._closing_playback:return
        if self._resume_seek_count==0:
            self._perform_resume_seek();return
        try:
            service=self.session.nav.getCurrentService();seekable=service.seek() if service else None
            pos=seekable.getPlayPosition() if seekable else None
            current=max(0,int(pos[1])) if pos and not pos[0] else 0
        except Exception as exc:
            optional_failure("player.resume_verify",exc);current=0
        tolerance=7*90000
        if current and abs(int(current)-int(self._resume_target))<=tolerance:
            self._last_progress_position=current
            self._resume_target=0;self._resume_grace_until=0.0
            self._release_resume_shield();self["connection"].setText(_("PLAYING  •  %s")%_engine_label(self.servicetype));return
        self._resume_verify_cycles+=1
        if self._resume_verify_cycles<7:
            self.resume_verify_timer.stop();self.resume_verify_timer.start(350,True);return
        # One actual automatic seek only. If the engine ignored it, fail cleanly
        # rather than issuing a late retry that could override a manual seek.
        self._resume_target=0;self._resume_grace_until=0.0;self._release_resume_shield()
        self["connection"].setText(_("PLAYING  •  resume unavailable"))

    def _native_resume_updated(self):
        """Resume through the native CueSheet-style flow.

        evUpdatedInfo is the trigger; once the current service exposes a seek
        interface, read the stored absolute PTS bookmark and issue one seekTo().
        No delayed retry/verification loop is allowed to move playback again.
        """
        if self.restored or self._closing_playback or self.media_type not in ("vod","series","episode","catchup"):
            return
        if getattr(self,"_native_resume_started",False):
            return
        bookmark=self._resume_bookmark()
        if not bookmark:
            self._native_resume_started=True
            return
        try:
            service=self.session.nav.getCurrentService()
            if service is None:return
            seekable=service.seek()
            if seekable is None:return
            length=seekable.getLength() or (None,0)
            total=abs(int(length[1] or 0)) if len(length)>1 else 0
            if bookmark <= 900000:return
            if total and bookmark >= total-900000:
                self._native_resume_started=True
                return
            # Mark immediately before issuing the one and only automatic seek.
            self._native_resume_started=True
            self.resume_prompted=True
            seekable.seekTo(int(bookmark))
            self._last_progress_position=int(bookmark)
            self["connection"].setText(_("PLAYING  •  RESUMED %d:%02d:%02d") % (bookmark//90000//3600,(bookmark//90000%3600)//60,bookmark//90000%60))
        except Exception as exc:
            optional_failure("player.native_resume",exc)

    def _reference_resume(self):
        """Apply the saved stable-ID bookmark using the proven native flow."""
        if self.restored or self._closing_playback or self.resume_prompted:
            return
        self.resume_prompted = True
        bookmark = self._resume_bookmark()
        if not bookmark:
            return
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
            if seekable is None:
                return
            length_result = seekable.getLength()
            length = abs(int(length_result[1])) if length_result and not length_result[0] else 0
        except Exception as exc:
            optional_failure("player.reference_resume_probe", exc)
            return
        if length and bookmark >= length - (10 * 90000):
            return
        behavior = self._cfg_resume_behavior
        if behavior == "start":
            return
        if behavior == "ask":
            seconds = int(bookmark // 90000)
            message = _("Resume playback from %d:%02d:%02d?") % (seconds // 3600, (seconds % 3600) // 60, seconds % 60)
            try:
                self.session.openWithCallback(lambda answer: self._reference_resume_answer(answer, bookmark), MessageBox, message, MessageBox.TYPE_YESNO, timeout=10)
                return
            except Exception as exc:
                optional_failure("player.reference_resume_prompt", exc)
        self._reference_resume_answer(True, bookmark)

    def _reference_resume_answer(self, answer, position):
        if not answer or self.restored or self._closing_playback:
            return
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
            if seekable is not None:
                seekable.seekTo(int(position))
                self._last_progress_position = int(position)
                self._resume_seek_count = 1
                self["connection"].setText(_("PLAYING  •  RESUMED %d:%02d") % (int(position)//90000//60, int(position)//90000%60))
        except Exception as exc:
            optional_failure("player.reference_resume_seek", exc)

    def _periodic_progress_save(self):
        if self.restored or self.media_type not in ("vod", "series", "episode", "catchup"):
            return
        self._save_history_progress()

    def _update_progress_crystal(self):
        if not getattr(self,"_player_infobar_visible",True):
            try:self.crystal_timer.stop()
            except Exception as exc:optional_failure("player.hidden_crystal_guard",exc)
            return
        if self.restored or self.media_type not in ("vod","series","episode","catchup"):
            try:
                self["progress_crystal"].hide(); self["progress_neon"].hide(); self["skip_hint"].setText(""); self["watched_progress"].setValue(0); self["watched_progress_glow"].setValue(0)
            except Exception as exc:
                optional_failure("player.crystal_hide", exc)
            return
        position,duration=self._service_progress_snapshot()
        if duration <= 0:
            self._update_skip_hint(position, duration)
            return
        ratio=max(0.0,min(1.0,float(position)/float(duration)))
        try:
            value=max(0,min(100,int(round(ratio*100.0))))
            # The legacy 1x1 progress bars are initialized to zero once. Avoid
            # redundant GUI writes on every visual poll.
            # Only swap the pixmap when the integer percentage changes. This keeps the
            # one-second timer cheap on the receiver while preserving smooth visual progress.
            if value != self._progress_neon_value:
                hx=str(self._adaptive_accent_neon or "#55b9ff").lstrip("#")
                path=os.path.join(os.path.join(PERSISTENT_GENERATED_DIR,"progress_neon239"),"%s_%03d.png"%(hx,value))
                if os.path.isfile(path) and self["progress_neon"].instance is not None:
                    self["progress_neon"].instance.setPixmapFromFile(path);self["progress_neon"].show();self._progress_neon_value=value
                else:
                    _schedule_progress_neon_frame(self._adaptive_accent_neon,value)
        except Exception as exc:optional_failure("player.watched_progress",exc)
        try:self["progress_crystal"].hide()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        self._update_skip_hint(position, duration)

    def _update_skip_hint(self, position, duration):
        # 1/3 are pure relative seek. Skip Intro/Credits no longer exist.
        try:self["skip_hint"].setText("")
        except Exception as exc:optional_failure("player.optional_guard",exc)

    def _seek_relative_seconds(self, seconds):
        """Reliable repeated numeric seek: 1=-10s, 3=+10s.

        ServiceApp/exteplayer3 can report the PREVIOUS play position for a short
        window after a seek.  A second relative seek then starts from stale PTS
        and appears to jump forward/back to the same place.  Keep a short-lived
        absolute target and accumulate each key press on that target instead.
        """
        seconds = int(seconds or 0)
        if not seconds:
            return False
        now=time.monotonic()
        # Only suppress duplicate key events from the same physical press.  Do
        # not swallow deliberate quick repeated presses.
        if now-float(getattr(self,"_last_manual_seek_at",0.0) or 0.0) < 0.055:
            return False
        self._last_manual_seek_at=now
        self._cancel_pending_resume_for_manual_seek()
        delta=int(seconds*90000)
        try:
            service=self.session.nav.getCurrentService()
            seekable=service.seek() if service else None
            if seekable is None:return False
            check=getattr(seekable,"isCurrentlySeekable",None)
            if callable(check):
                try:
                    if not check():return False
                except Exception as exc:optional_failure("player.optional_guard",exc)

            pos=seekable.getPlayPosition()
            current=int(pos[1]) if pos and not pos[0] else int(getattr(self,"_last_progress_position",0) or 0)
            length=seekable.getLength()
            total=int(length[1]) if length and not length[0] else 0

            cached=getattr(self,"_manual_seek_target_pts",None)
            cached_at=float(getattr(self,"_manual_seek_target_at",0.0) or 0.0)
            # While the decoder is settling, the cached target is the truth.
            # After ~2.5s of no numeric seek, resume from the live position.
            base=int(cached) if cached is not None and (now-cached_at)<2.5 else max(0,current)
            target=max(0,base+delta)
            if total>0:
                target=min(target,max(0,total-90000))

            result=seekable.seekTo(int(target))
            self._manual_seek_target_pts=int(target)
            self._manual_seek_target_at=now
            self._last_progress_position=int(target)
            try:
                self["skip_hint"].setText("+10s" if seconds > 0 else "-10s")
            except Exception as exc:
                optional_failure("player.optional_guard", exc)
            return result in (None,0,True) or True
        except Exception as exc:
            # Receiver fallback for engines that expose relative seek but not a
            # usable absolute play position.  Keep this off the normal path.
            try:
                service=self.session.nav.getCurrentService();seekable=service.seek() if service else None
                if seekable is not None:
                    seekable.seekRelative(1 if seconds>0 else -1,abs(delta));return True
            except Exception:
                pass
            optional_failure("player.numeric_seek_10", exc)
            return False

    def seekBack10(self):
        return self._seek_relative_seconds(-10)

    def seekForward10(self):
        return self._seek_relative_seconds(10)

    def nextAR(self):
        self.ar_id_player += 1
        if self.ar_id_player > 6:
            self.ar_id_player = 0
        try:
            if eAVSwitch is not None:
                eAVSwitch.getInstance().setAspectRatio(self.ar_id_player)
            message = ASPECT_RATIOS.get(self.ar_id_player, "Auto")
        except Exception:
            message = "Aspect-ratio change failed"
        try:
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=1)
        except Exception as exc:
            optional_failure("player", exc)
    def show_media_info(self):
        meta="%s   •   %s   •   %s   •   %s"%(self._category_label(),self["video_quality"].getText(),self["video_codec"].getText(),self["audio_codec"].getText())
        self._media_info_open=True
        try:
            if self._online_subtitle_overlay is not None:self._online_subtitle_overlay.hide()
        except Exception:pass
        try:
            self._set_infobar_visuals(False)
        except Exception as exc:optional_failure("player",exc)
        try:self.session.openWithCallback(self._media_info_closed,PlayerInformationOverlay,self.name,self.item,self.media_type,meta,self._poster_path)
        except Exception as exc:
            LOG.warning("Nova media information overlay failed: %s", exc)
            try:self["connection"].setText(_("MEDIA INFO UNAVAILABLE"))
            except Exception as exc:optional_failure("player",exc)
    def _media_info_closed(self,*args):
        self._media_info_open=False
        try:self.doShow()
        except Exception:
            try:self.show()
            except Exception as exc:optional_failure("player",exc)

    def _service_progress_snapshot(self, raw=False):
        """Read one sane 90kHz PTS snapshot from the active Enigma2 service."""
        try:
            service = self.session.nav.getCurrentService()
            seek = service.seek() if service else None
            pos_result = seek.getPlayPosition() if seek else None
            len_result = seek.getLength() if seek else None
            position = int(pos_result[1]) if pos_result and not pos_result[0] else 0
            duration = int(len_result[1]) if len_result and not len_result[0] else 0
            # Negative values are error/sentinel values on several OE-A builds;
            # never abs() them into a fake positive resume timestamp.
            position = max(0, position)
            duration = max(0, duration)
            if duration and position > duration + (5 * 90000):
                position = 0
            return position, duration
        except Exception as exc:
            try:
                if self._cfg_diagnostic_logging: optional_failure("player.progress_snapshot",exc)
            except Exception as exc:
                optional_failure("player.optional_guard", exc)
            return 0, 0

    def _save_history_progress(self, force=False, completed_override=None):
        if self.media_type not in ("vod","series","episode","catchup"):
            return
        try:
            if not self.started or not self._watch_started_at:
                return
            elapsed = time.time() - float(self._watch_started_at)
            had_resume = int(self.item.get("_resume_position") or 0) >= (10 * 90000)
            # A resumed title must be allowed to update its bookmark even when
            # the viewer watches only a few seconds before pressing BACK.
            if not force and not had_resume and elapsed < float(self._history_save_min_seconds):
                return
        except Exception:
            if not force:
                return

        position, duration = self._service_progress_snapshot()
        if position > 0:
            self._last_progress_position = position
        if duration > 0:
            self._last_progress_duration = duration
        position = position or int(self._last_progress_position or 0)
        duration = duration or int(self._last_progress_duration or 0)
        try:
            existing=max(0,int(self.item.get("_resume_position") or 0))
            elapsed=max(0.0,time.time()-float(self._watch_started_at or time.time()))
            if duration and existing >= 45*90000 and elapsed < 75.0 and position >= int(duration*0.95) and existing < int(duration*0.85):
                position=existing
        except Exception as exc: optional_failure("player.progress_eof_guard",exc)
        minimum = int(self._history_save_min_seconds * 90000)
        if position < minimum and completed_override is not True:
            return
        if duration and position > duration + (5 * 90000):
            return
        try:
            profile=self._history_profile
            history_item=self._history_item
            threshold=self._cfg_completion_threshold
            remaining_limit=self._cfg_completion_remaining_pts
            completed_by_position=bool(duration and (position>=int(duration*threshold) or max(0,duration-position)<=remaining_limit))
            completed = bool(completed_override) if completed_override is not None else bool(self._cfg_auto_remove_completed and completed_by_position)
            add_recently_played(profile,self.media_type,history_item,position,duration,completed,force=bool(force))
        except Exception as exc:
            optional_failure("player", exc)

    def _current_service_is_owned(self):
        try:
            current=self.session.nav.getCurrentlyPlayingServiceReference()
            if current is None:return False
            current_text=current.toString()
            owned=str(getattr(self,"_owned_reference_string","") or "")
            if owned:return current_text==owned
            ref=getattr(self,"reference",None)
            return bool(ref is not None and current_text==ref.toString())
        except Exception:return False

    def _stop_owned_service(self, force_external=False):
        """Hard-stop only the native/external playback owned by this screen."""
        self._cancel_smart_recovery();self._closing_playback=True
        for timer_name in ("startup_timer","resume_verify_timer","subtitle_default_timer","progress_timer","crystal_timer","eof_guard_timer","recovery_timer","zap_switch_timer","stable_timer","stream_info_timer","memory_fuse_timer"):
            timer=getattr(self,timer_name,None)
            if timer is not None:
                try:timer.stop()
                except Exception as exc:optional_failure("player.stop_timer",exc)
        # Unified hard stop: leaving a plugin player always stops the active
        # Enigma2 service first. ServiceApp can wrap/change the reference, so an
        # ownership-string comparison is not sufficient to guarantee silence.
        try:
            nav=getattr(self.session,"nav",None)
            if nav is not None:
                nav.stopService()
        except Exception as exc:optional_failure("player.stopService",exc)
        try:force_session_silence(self.session,self.streamurl,force=bool(force_external),stop_native=True,exclude_pids=self._external_player_baseline,owned_pids=self._owned_external_pids)
        except Exception as exc:optional_failure("player.hard_stop",exc)
        sig=signal.SIGKILL if force_external else signal.SIGTERM
        targets=set(self._owned_external_pids)
        try:targets.update(set(_matching_external_player_pids(self.streamurl))-set(self._external_player_baseline))
        except Exception as exc:optional_failure("player.external_match_stop",exc)
        for pid in list(targets):
            try:os.kill(int(pid),sig)
            except OSError:self._owned_external_pids.discard(pid)
            except Exception as exc:optional_failure("player.owned_external_stop",exc)
        return True

    def _service_still_owned(self):
        """True only while this exact native reference or matching player PID lives."""
        try:
            if self._current_service_is_owned():return True
        except Exception as exc:
            optional_failure("player.hard_stop_probe",exc)
        try:
            alive=[]
            for pid in list(self._owned_external_pids):
                if os.path.exists("/proc/%d"%int(pid)):alive.append(pid)
                else:self._owned_external_pids.discard(pid)
            matched=set(_matching_external_player_pids(self.streamurl))-set(self._external_player_baseline)
            descendants=_descendant_pids(self._owned_external_pids)-set(self._external_player_baseline)
            return bool(alive or matched or descendants)
        except Exception as exc:
            optional_failure("player.hard_stop_process_probe",exc)
            return True

    def _xstreamity_service_handoff(self, restore_service=True):
        """XStreamity-style player exit: stop IPTV, restore pre-plugin service.

        The important part is that Enigma2 owns the transition. We do not keep
        retrying/respawning/killing the decoder from Python. A normal service
        replacement lets ServiceApp and Broadcom release the old playback path.
        """
        self._closing_playback=True
        self._cancel_smart_recovery()
        for timer_name in ("startup_timer","resume_timer","resume_verify_timer","subtitle_default_timer","progress_timer","crystal_timer","hard_stop_timer","eof_guard_timer","recovery_timer","zap_switch_timer","stable_timer","stream_info_timer","memory_fuse_timer","hideTimer"):
            timer=getattr(self,timer_name,None)
            if timer is not None:
                try:timer.stop()
                except Exception as exc:optional_failure("player.silent_guard",exc)
        nav=getattr(self.session,"nav",None)
        if nav is None:return False
        try:nav.stopService()
        except Exception as exc:optional_failure("player.xst_stop_service",exc)
        restored=False
        if restore_service and self._return_service_ref_string:
            try:
                nav.playService(eServiceReference(self._return_service_ref_string))
                restored=True
            except Exception as exc:
                optional_failure("player.xst_restore_service",exc)
        if restore_service:
            _restore_receiver_aspect_ratio(getattr(self,"_return_aspect_ratio",None))
        self._service_handoff_done=True
        try:gc.collect();_malloc_trim()
        except Exception as exc:optional_failure("player.silent_guard",exc)
        return restored

    def _begin_hard_stop_close(self, result):
        # Compatibility entry point used by the rest of Ultra Stalker. Normal
        # EXIT now follows XStreamity's deterministic stop/restore/close flow.
        self._hard_stop_pending_result=result
        self._hard_stop_closing=True
        skip_restore=bool(isinstance(result,dict) and result.get("next_episode"))
        restored=self._xstreamity_service_handoff(restore_service=not skip_restore)
        if isinstance(result,dict):result["service_restored"]=bool(restored)
        self._finalize_player_close()

    def _verify_hard_stop(self):
        # Kept only for compatibility with an already-armed timer. No retry loop.
        if self._hard_stop_closing:self._finalize_player_close()

    def _finalize_player_close(self):
        runtime_breadcrumb("player_close",media_type=self.media_type,engine=int(self.servicetype or 0),handoff=True)
        result=self._hard_stop_pending_result or {"engine":self.servicetype,"started":self.started,"failed":self.failed}
        self._hard_stop_pending_result=None;self._hard_stop_closing=False;self.reference=None
        self.close(result)

    def _close_player(self, extra=None, save_progress=True):
        if self.restored or self._hard_stop_closing:return
        self._closing_playback=True
        if save_progress and self.media_type in ("vod","series","episode","catchup"):
            try:self._save_history_progress(force=True)
            except Exception as exc:optional_failure("player.close_save",exc)
        result={"engine":self.servicetype,"started":self.started,"failed":self.failed}
        if self._observed_quality:
            result["quality"]=self._observed_quality;result["video_width"]=int(self._observed_width or 0);result["video_height"]=int(self._observed_height or 0)
        if isinstance(extra,dict):result.update(extra)
        self.restored=True
        self._suppress_service_events(2.5)
        self._begin_hard_stop_close(result)

    def _next_episode_answer(self, answer):
        global NEXT_EPISODE_AUTOPLAY_SESSION
        next_item = self.item.get("_next_episode_item") if isinstance(self.item, dict) else None
        if answer == "session_off":
            NEXT_EPISODE_AUTOPLAY_SESSION = False
            self._close_player(save_progress=False)
        elif answer and isinstance(next_item, dict) and next_item:
            self._close_player({"next_episode": dict(next_item)}, save_progress=False)
        else:
            self._close_player(save_progress=False)

    def back(self):
        self._close_player(save_progress=True)

    def _cleanup(self):
        runtime_breadcrumb("player_cleanup",media_type=self.media_type,engine=int(self.servicetype or 0))
        try:self._player_title_logo_token+=1;self._player_title_logo_pending=False
        except Exception:pass
        try:self._online_subtitle_generation+=1;self._online_subtitle_cancel.set()
        except Exception:pass
        try:self._zap_switch_generation+=1;self._zap_switch_inflight=False;self._zap_switch_started_at=0.0
        except Exception:pass
        for future_name in ("_player_title_logo_future","_online_subtitle_future","_zap_switch_future"):
            future=getattr(self,future_name,None)
            if future is not None:
                try:future.cancel()
                except Exception as exc:optional_failure("player.future_cancel",exc)
            try:setattr(self,future_name,None)
            except Exception:pass
        # Never leave global receiver audio muted if the screen closes while a
        # resume probe is still in progress.
        try: self._release_resume_shield()
        except Exception as exc: optional_failure("player.resume_cleanup", exc)
        # Final idempotent safety net.  Repeat the complete native + pnav +
        # external stop sequence in case the screen was closed through an
        # unexpected Enigma2 path rather than back().
        if not getattr(self,"_service_handoff_done",False):
            try:
                force_session_silence(self.session, self.streamurl, force=True, stop_native=True, exclude_pids=self._external_player_baseline, owned_pids=self._owned_external_pids)
            except Exception as exc:
                optional_failure("player.cleanup_hard_stop", exc)
        for timer_name in ("startup_timer", "resume_timer", "resume_verify_timer", "subtitle_default_timer", "embedded_subtitle_probe_timer", "online_subtitle_timer", "online_subtitle_result_timer", "subtitle_volume_restore_timer", "progress_timer", "crystal_timer", "hard_stop_timer", "eof_guard_timer", "recovery_timer", "zap_switch_timer", "stable_timer", "stream_info_timer", "player_title_logo_timer", "memory_fuse_timer", "hideTimer"):
            timer = getattr(self, timer_name, None)
            if timer is not None:
                try:
                    timer.stop()
                except Exception as exc:
                    optional_failure("player", exc)
        for conn_name in ("startup_timer_conn", "resume_timer_conn", "resume_verify_timer_conn", "subtitle_default_timer_conn", "embedded_subtitle_probe_timer_conn", "online_subtitle_timer_conn", "online_subtitle_result_timer_conn", "subtitle_volume_restore_timer_conn", "progress_timer_conn", "crystal_timer_conn", "hard_stop_timer_conn", "eof_guard_timer_conn", "recovery_timer_conn", "zap_switch_timer_conn", "stable_timer_conn", "stream_info_timer_conn", "player_title_logo_timer_conn", "memory_fuse_timer_conn", "PicLoad_conn", "hideTimer_conn"):
            conn = getattr(self, conn_name, None)
            if conn is not None:
                try:
                    conn.disconnect()
                except Exception as exc:
                    optional_failure("player", exc)
        callback_map=(
            ("startup_timer",self._startup_timeout),("resume_timer",self._reference_resume),("resume_verify_timer",self._verify_resume_position),
            ("subtitle_default_timer",self._enforce_default_subtitles_off),
            ("embedded_subtitle_probe_timer",self._embedded_subtitle_probe_tick),
            ("online_subtitle_timer",self._online_subtitle_tick),("online_subtitle_result_timer",self._drain_online_subtitle_result),
            ("subtitle_volume_restore_timer",self._restore_subtitle_after_volume_osd),
            ("progress_timer",self._periodic_progress_save),
            ("crystal_timer",self._update_progress_crystal),("hard_stop_timer",self._verify_hard_stop),
            ("eof_guard_timer",self._verify_early_eof),("recovery_timer",self._drain_recovery_result),("zap_switch_timer",self._drain_zap_switch_result),
            ("stable_timer",self._mark_stream_stable),("stream_info_timer",self._update_stream_info),
            ("player_title_logo_timer",self._drain_player_title_logo),("hideTimer",self.doTimerHide),
        )
        for timer_name,callback in callback_map:
            timer=getattr(self,timer_name,None)
            if timer is None:continue
            try:
                if callback in timer.callback:timer.callback.remove(callback)
            except Exception as exc:optional_failure("player.timer_callback_remove",exc)
        try:
            callbacks=self.PicLoad.PictureData.get()
            if self._decode_poster in callbacks:callbacks.remove(self._decode_poster)
        except Exception as exc:optional_failure("player.picload_callback_remove",exc)
        try:
            if self._play_state_changed in self.onPlayStateChanged:self.onPlayStateChanged.remove(self._play_state_changed)
        except Exception as exc:optional_failure("player.playstate_callback_remove",exc)
        for hooks,callback,label in (
            (getattr(self,"onShow",None),self._resume_hidden_visual_timers,"player.show_timer_hook_remove"),
            (getattr(self,"onHide",None),self._pause_hidden_visual_timers,"player.hide_timer_hook_remove"),
        ):
            try:
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:optional_failure(label,exc)
        try:
            if self._online_subtitle_display is not None:
                self._online_subtitle_display.hideScreen()
                deleter=getattr(self.session,"deleteDialog",None)
                if callable(deleter):deleter(self._online_subtitle_display)
                self._online_subtitle_display=None
        except Exception as exc:optional_failure("player.native_online_subtitle_cleanup",exc)
        # Release decoded poster/picon buffers promptly on constrained receivers.
        for widget_name in ("logo","live_picon","adaptive_main","adaptive_poster","adaptive_live_picon","progress_neon"):
            try:
                widget=self[widget_name]
                if widget.instance is not None:widget.instance.setPixmap(None)
            except Exception as exc:optional_failure("player.optional_guard",exc)
