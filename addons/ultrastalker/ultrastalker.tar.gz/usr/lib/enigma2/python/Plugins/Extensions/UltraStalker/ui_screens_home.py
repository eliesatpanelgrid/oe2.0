"""Portal home screen extracted from ui.py without changing class behavior."""

from . import _
import hashlib
import json
import os
import queue
import tempfile
import time
from .core.runtime_log import diagnostic_breadcrumb as _ui_diag
from .log import diagnostic_failure

try:
    from PIL import Image as _PILImage
except Exception:
    _PILImage = None

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from enigma import eTimer, ePoint, eSize, eLabel, gFont, getDesktop, loadPNG
from .services.player_visuals import _progress_neon_frame, _fallback_player_frames, PLAYER_FALLBACK_INFOBAR_DIR

from .ui_async import AsyncScreenMixin
from .ui_image_loader import ImageLoaderMixin
from .ui_transition import TransitionMixin

# Runtime dependencies are injected by ui.py after its shared helpers are ready.
HOME_SKIN = ""
BACKDROP_CACHE_DIR = ""
HOME_HERO_FILE = ""
HOME_HERO_SCHEMA = 0
HOME_HERO_TTL = 0
HOME_RUNTIME_DIR = ""
IMAGE_CACHE_DIR = ""
THUMB_CACHE_DIR = ""
LOG = None
PortalSession = None
TMDBClient = None
UltraStalkerPlayer = None
_CATEGORY_PREFETCH_EXECUTOR = None
_HOME_HERO_LOCK = None
_IMAGE_EXECUTOR = None
_build_home_adaptive_focus = None
_build_home_mood_assets = None
_cleanup_legacy_home_hero_storage = None
_category_cache_get = None
_category_cache_put = None
_clean_display_text = None
_configured_playback_engine = None
_fsync_parent_dir = None
_home_prepare_art = None
_home_cached_art = None
_player_payload = None
_valid_cache_file = None
add_recently_played = None
asset = None
current_plugin_launch = None
load_playback_progress = None
load_profiles = None
load_recently_played = None
load_settings = None
load_ui_state = None
optional_failure = None
premium_title = None
save_profiles = None
save_ui_state = None

# Forward screen references are filled after those classes are defined.
ContentDetailsScreen = None
NovaSettingsScreen = None
PortalBrowserScreen = None
PortalGlobalSearchScreen = None

def configure_home_screen(**deps):
    globals().update(deps)
    if "HOME_SKIN" in deps:
        PortalHomeScreen.skin = deps["HOME_SKIN"]

class PortalHomeScreen(Screen, AsyncScreenMixin, ImageLoaderMixin, TransitionMixin):
    skin = HOME_SKIN
    CARDS = (
        ("Live TV", "Watch live channels", "itv"),("Movies", "Browse movie library", "vod"),("Series", "Explore TV series", "series"),
        ("Catch-up", "Watch past programs", "catchup"),("Favorites", "Your saved content", "favorites"),("Search", "Find content quickly", "search"),("Settings", "Portal & player settings", "settings"),
    )
    CARD_X=(55,313,571,829,1087,1345,1603); RECENT_X=(55,677,1299)

    def __init__(self,session,profile):
        Screen.__init__(self,session);self._async_init();self.onClose.append(self._stop_async);self.onClose.append(self._image_stop)
        self._ui_diag_open_mono=time.monotonic();_ui_diag("ui_open",screen="home")
        self.profile=profile;self.portal_session=PortalSession(profile,timeout=load_settings().get("timeout",10));self.client=self.portal_session.client
        try:
            _desk=getDesktop(0).size();self._home_sx=float(_desk.width())/1920.0;self._home_sy=float(_desk.height())/1080.0
        except Exception:
            self._home_sx=1.0;self._home_sy=1.0
        self.index=0;self.recent_index=0;self.focus_row="menu";self._recent_entries=[None,None,None];self._recent_generation=0;self._recent_futures=set();self._home_jobs=queue.Queue();self._hero_data=None
        self._home_has_shown_once=False;self._home_return_pending=False;self._home_runtime_visible=True
        self["brand"]=Label("")
        self["hero_kicker"]=Label("");self["hero_title"]=Label("");self["hero_subtitle"]=Label("");self["hero_rating"]=Label("")
        state=_clean_display_text(profile.get("state") or _("Portal ready"),82);self["portal_state"]=Label("●  %s"%state)
        self["selection"]=Pixmap();self["recent_selection"]=Pixmap();self["hero_backdrop"]=Pixmap();self["hero_logo"]=Pixmap();self["ambient_bg"]=Pixmap();self["continue_header"]=Label(_("CONTINUE / RECENT"))
        for i in range(7):self["menu_bg%d"%i]=Pixmap()
        for i in range(7):self["menu_icon%d"%i]=Pixmap()
        for i in range(3):self["recent_bg%d"%i]=Pixmap()
        for i,(title,subtitle,_action) in enumerate(self.CARDS):self["card_title%d"%i]=Label(_(title));self["card_sub%d"%i]=Label(_(subtitle))
        for i,label in enumerate(("Last Live","Last Movie","Last Series")):
            self["recent_art%d"%i]=Pixmap();self["recent_label%d"%i]=Label(_(label));self["recent_title%d"%i]=Label(_("Nothing played yet"));self["recent_meta%d"%i]=Label(_("Open something and it will appear here"))
            if i == 0:
                self["recent_progress0"]=ProgressBar();self["recent_progress0"].setRange((0,100));self["recent_progress0"].setValue(0)
            else:
                self["recent_progress_track%d"%i]=Pixmap();self["recent_progress_neon%d"%i]=Pixmap()
        self["status"]=Label(_("LEFT / RIGHT Navigate • DOWN Recent • OK Open • BACK Portals"))
        self._image_init("hero_backdrop",(1920,1080),profile,self.client)
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","MenuActions","InfoActions","ColorActions"],{
            "cancel":self.close,"left":self.move_left,"right":self.move_right,"up":self.move_up,"down":self.move_down,"ok":self.open_selected,"menu":self.open_settings,"info":self.open_account,"yellow":self.refresh_hero},-1)
        # Single-slot Hero: no rotation/fill timer and no automatic Home artwork jobs.
        self._hero_timer=None;self._hero_timer_conn=None;self._hero_fill_running=False
        self.onLayoutFinish.append(self._layout_ready)
        self._home_rebind_timer=eTimer();self._home_rebind_conn=None
        try:self._home_rebind_conn=self._home_rebind_timer.timeout.connect(self._home_delayed_rebind)
        except Exception:self._home_rebind_timer.callback.append(self._home_delayed_rebind)
        self.onClose.append(self._stop_home_rebind_timer)
        # Remote focus state is persisted after a short quiet window instead of
        # rewriting the UI-state JSON on every LEFT/RIGHT keypress.
        self._home_focus_state_pending=None;self._home_focus_state_timer=eTimer();self._home_focus_state_conn=None
        try:self._home_focus_state_conn=self._home_focus_state_timer.timeout.connect(self._flush_home_focus_state)
        except Exception:self._home_focus_state_timer.callback.append(self._flush_home_focus_state)
        self.onClose.append(self._flush_home_focus_state);self.onClose.append(self._stop_home_focus_state_timer)
        self.onClose.append(self._stop_home_background_jobs)
        self.onClose.append(self._stop_home_ui_hooks)
        self.onClose.append(self._ui_diag_home_close)
        try:self.onShown.append(self._home_shown)
        except Exception as exc:optional_failure("ui",exc)
        try:self.onHide.append(self._home_hidden_release)
        except Exception as exc:optional_failure("ui.home_hide_hook",exc)

    def _pause_home_runtime_timers(self):
        self._home_runtime_visible=False
        # Home stays alive underneath child screens. Keep Hero maintenance asleep until Home is shown again.
        for timer in (getattr(self,"_hero_timer",None),):
            if timer is None:continue
            try:timer.stop()
            except Exception as exc:optional_failure("ui.home_runtime_timer_pause",exc)

    def _resume_home_runtime_timers(self):
        if getattr(self,"_screen_closed",False):return
        self._home_runtime_visible=True
        for timer,interval in ((getattr(self,"_hero_timer",None),60000),):
            if timer is None:continue
            try:
                timer.stop();timer.start(interval,False)
            except Exception as exc:optional_failure("ui.home_runtime_timer_resume",exc)

    def _cancel_recent_futures(self):
        futures=getattr(self,"_recent_futures",None)
        if not isinstance(futures,set):
            futures=set();self._recent_futures=futures
        for future in list(futures):
            if future is None or future.done():
                futures.discard(future);continue
            try:future.cancel()
            except Exception as exc:optional_failure("ui.home_recent_future_cancel",exc)
            if future.done():futures.discard(future)

    def _ui_diag_home_close(self):
        try:_ui_diag("ui_close",screen="home",lifetime_ms=int(max(0.0,(time.monotonic()-self._ui_diag_open_mono)*1000.0)))
        except Exception as exc: diagnostic_failure("ui.home.failsoft", exc)

    def _stop_home_ui_hooks(self):
        for hook_name, callback in (
            ("onShown", self._home_shown),
            ("onHide", self._home_hidden_release),
            ("onLayoutFinish", self._layout_ready),
        ):
            try:
                hooks=getattr(self,hook_name,None)
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:
                optional_failure("ui.home_hook_cleanup",exc)

    def _load_menu_icons(self):
        """Load Home icons as live Pixmap widgets above all adaptive layers.

        OpenBH can occasionally drop static ePixmap surfaces after large TMDB
        artwork/cache activity.  These seven navigation icons are core UI, so
        reload them explicitly whenever Home is laid out or shown and keep
        their z-order above adaptive card/focus artwork.
        """
        names=("home_live.png","home_movies.png","home_series.png","home_catchup.png","home_favorites.png","home_search.png","home_settings.png")
        for i,name in enumerate(names):
            try:
                path=asset(name)
                if os.path.isfile(path) and os.path.getsize(path)>256:
                    self["menu_icon%d"%i].instance.setPixmapFromFile(path)
                    self["menu_icon%d"%i].show()
            except Exception as exc:
                optional_failure("ui.home_icon_%d"%i,exc)

    def _stop_home_rebind_timer(self):
        try:self._home_rebind_timer.stop()
        except Exception as exc:optional_failure("ui.home_rebind_timer_stop",exc)
        try:
            if self._home_rebind_conn is not None:self._home_rebind_conn.disconnect()
        except Exception as exc:optional_failure("ui.home_rebind_timer_disconnect",exc)
        try:
            if self._home_delayed_rebind in self._home_rebind_timer.callback:self._home_rebind_timer.callback.remove(self._home_delayed_rebind)
        except Exception as exc:optional_failure("ui.home_rebind_timer_callback",exc)

    def _home_hero_source(self,hero):
        if not isinstance(hero,dict):return None
        for key in ("prepared","display_backdrop_local","backdrop_local","display_poster_local","poster_local"):
            src=str(hero.get(key) or "")
            try:
                if src and os.path.isfile(src) and os.path.getsize(src)>4096:return src
            except Exception as exc:optional_failure("ui.home_source_check",exc)
        return None

    def _ensure_home_visual_materials(self,hero):
        """Guarantee that this exact hero owns valid adaptive 3D files on HDD."""
        if not isinstance(hero,dict):return hero
        src=self._home_hero_source(hero)
        if not src:return hero
        try:
            hid=str(hero.get("id") or hero.get("tmdb_id") or "home")
            stamp=str(int(os.path.getmtime(src)))
            digest=hashlib.sha1((hid+"|"+src+"|"+stamp+"|home-rebind-3d-v2").encode("utf-8","ignore")).hexdigest()

            mood=hero.get("home_mood") if isinstance(hero.get("home_mood"),dict) else {}
            # A manually pinned Hero already owns the adaptive files built from
            # the selected raw backdrop.  Do not reject those valid files just
            # because Home's rebind digest uses a different cache key; doing so
            # rebuilt the palette from the prepared/faded Home composite and
            # made the Home chrome fall back to the old blue look.
            mood_ok=all(mood.get(k) and os.path.isfile(str(mood.get(k))) and os.path.getsize(str(mood.get(k)))>100 for k in ("ambient","menu","recent"))
            if not mood_ok:
                mood=_build_home_mood_assets(src,digest)
                if mood:hero["home_mood"]=mood

            focus=hero.get("adaptive_focus") if isinstance(hero.get("adaptive_focus"),dict) else {}
            focus_ok=all(focus.get(k) and os.path.isfile(str(focus.get(k))) and os.path.getsize(str(focus.get(k)))>100 for k in ("menu","recent"))
            if not focus_ok:
                focus=_build_home_adaptive_focus(src,digest)
                if focus:hero["adaptive_focus"]=focus
        except Exception as exc:optional_failure("ui.home_material_rebuild",exc)
        return hero

    def _force_pixmap_file(self,name,path,show=True):
        if not path or not os.path.isfile(str(path)):return False
        try:
            widget=self[name]
            if widget.instance is None:return False
            try:widget.instance.setPixmap(None)
            except Exception as exc:optional_failure("ui.home_pixmap_clear",exc)
            try:
                pix=loadPNG(str(path))
                if pix is not None:widget.instance.setPixmap(pix)
                else:widget.instance.setPixmapFromFile(str(path))
            except Exception:
                widget.instance.setPixmapFromFile(str(path))
            if show:widget.show()
            return True
        except Exception as exc:
            optional_failure("ui.home_pixmap_force",exc);return False

    def _rebind_home_materials(self,hero):
        """Force native Pixmap surfaces to the hero's real 3D/adaptive files."""
        if not isinstance(hero,dict):return
        mood=hero.get("home_mood") if isinstance(hero.get("home_mood"),dict) else {}
        focus=hero.get("adaptive_focus") if isinstance(hero.get("adaptive_focus"),dict) else {}

        self._force_pixmap_file("ambient_bg",mood.get("ambient"))
        for i in range(7):self._force_pixmap_file("menu_bg%d"%i,mood.get("menu"))
        for i in range(3):self._force_pixmap_file("recent_bg%d"%i,mood.get("recent"))

        menu_focus=focus.get("menu")
        recent_focus=focus.get("recent")
        if not (menu_focus and os.path.isfile(str(menu_focus))):menu_focus=asset("home129_menu_focus.png")
        if not (recent_focus and os.path.isfile(str(recent_focus))):recent_focus=asset("home129_recent_focus.png")
        self._force_pixmap_file("selection",menu_focus,show=(self.focus_row=="menu"))
        self._force_pixmap_file("recent_selection",recent_focus,show=(self.focus_row=="recent"))

        # Hero prepared file is already the exact cinematic Home composite.
        prepared=str(hero.get("prepared") or "")
        if prepared and os.path.isfile(prepared):
            self._force_pixmap_file("hero_backdrop",prepared)

        try:self._load_menu_icons()
        except Exception as exc:optional_failure("ui.home_rebind_icons",exc)

    def _force_home_visual_rebind(self):
        """Restore the exact pre-child Home hero, adaptive mood and 3D glass."""
        if getattr(self,"_screen_closed",False):return
        try:self._image_layout_ready()
        except Exception as exc:optional_failure("ui.home_rebind_layout",exc)

        hero=self._hero_data if isinstance(getattr(self,"_hero_data",None),dict) else None
        if not hero:
            try:hero=self._read_hero_cache()
            except Exception:hero=None
        if isinstance(hero,dict):
            hero=self._ensure_home_visual_materials(dict(hero))
            self._hero_data=hero
            try:self._apply_home_hero(hero)
            except Exception as exc:optional_failure("ui.home_rebind_apply",exc)
            try:self._rebind_home_materials(hero)
            except Exception as exc:optional_failure("ui.home_rebind_native",exc)
        else:
            try:self._load_home_hero(force=False)
            except Exception as exc:optional_failure("ui.home_rebind_fallback",exc)

        try:self._update_focus()
        except Exception as exc:optional_failure("ui.home_rebind_focus",exc)

    def _home_delayed_rebind(self):
        try:self._home_rebind_timer.stop()
        except Exception as exc:optional_failure("ui.home_rebind_timer",exc)
        if getattr(self,"_screen_closed",False):return
        try:self._home_fast_return()
        except Exception as exc:optional_failure("ui.home_delayed_pin_check",exc)
        try:self._force_home_visual_rebind()
        except Exception as exc:optional_failure("ui.home_delayed_rebind",exc)
        # While one explicit single-slot Hero is being prepared, poll only a
        # tiny /tmp marker.  No network/HDD scan/image work occurs here.
        try:
            marker=os.path.join("/tmp","ultrastalker_home_hero_pending")
            if os.path.isfile(marker):
                age=max(0.0,time.time()-os.path.getmtime(marker))
                # release could legitimately need a minute or two on receiver HDD/CPU.
                # Poll only this tiny /tmp marker; no network or image build runs here.
                if age<180.0:self._home_rebind_timer.start(1000,True)
        except Exception as exc:optional_failure("ui.home_single_pin_poll",exc)

    def _home_fast_return(self):
        """Child return: keep warm visuals, but honor a newly pinned Home Hero."""
        if getattr(self,"_screen_closed",False):return
        try:
            state=self._read_hero_state() or {}
            pinned=self._read_hero_cache()
            if pinned:
                pinned=self._ensure_home_visual_materials(dict(pinned))
                self._hero_data=pinned
                self._apply_home_hero(pinned)
                self._rebind_home_materials(pinned)
        except Exception as exc:optional_failure("ui.home_fast_manual_pin",exc)
        try:self._update_focus()
        except Exception as exc:optional_failure("ui.home_fast_focus",exc)


    def _home_shown(self):
        if getattr(self,"_screen_closed",False):return
        self._resume_home_runtime_timers()
        self._home_images_suspended=False
        returning=bool(getattr(self,"_home_return_pending",False) and getattr(self,"_home_has_shown_once",False))
        self._home_return_pending=False
        if returning:
            # Child screens leave all non-hero Home pixmaps bound. Repaint only
            # the hero released by _image_suspend(); a full rebind here was the
            # source of the heavy return-to-Home pause.
            try:self._home_rebind_timer.stop()
            except Exception as exc:optional_failure("ui.home_fast_timer_stop",exc)
            try:self._home_fast_return()
            except Exception as exc:optional_failure("ui.home_fast_return",exc)
            # Manual Home preparation runs off-thread and may finish a fraction
            # after Details closes. One delayed HDD-state check is cheap and lets
            # the ready composite appear without waiting for the 60s hero timer.
            try:
                self._home_rebind_timer.stop();self._home_rebind_timer.start(900,True)
            except Exception as exc:optional_failure("ui.home_pin_ready_recheck",exc)
        else:
            try:self._force_home_visual_rebind()
            except Exception as exc:optional_failure("ui.home_resume_visuals",exc)
            # First presentation only: OpenBH may create native Pixmap surfaces
            # just after onShown, so retain one delayed full bind on cold Home.
            try:
                self._home_rebind_timer.stop()
                self._home_rebind_timer.start(90,True)
            except Exception as exc:optional_failure("ui.home_rebind_schedule",exc)
        self._home_has_shown_once=True
        try:self._load_recent_cards()
        except Exception as exc:optional_failure("ui.home_recent_shown",exc)

    def _home_hidden_release(self):
        if getattr(self,"_screen_closed",False):return
        self._pause_home_runtime_timers()
        self._home_images_suspended=False
        self._home_return_pending=True
        # Keep the fully prepared hero + adaptive Home surfaces bound underneath
        # child screens. This makes Home return behave like a warm poster cache.
        try:self._home_rebind_timer.stop()
        except Exception as exc:optional_failure("ui.home_hide_timer",exc)


    def _layout_ready(self):
        try:_ui_diag("ui_ready",screen="home",elapsed_ms=int((time.monotonic()-self._ui_diag_open_mono)*1000.0))
        except Exception as exc: diagnostic_failure("ui.home.failsoft", exc)
        self._image_layout_ready()
        self._load_menu_icons()
        try:self["selection"].instance.setPixmapFromFile(asset("home129_menu_focus.png"));self["recent_selection"].instance.setPixmapFromFile(asset("home129_recent_focus.png"))
        except Exception as exc:optional_failure("ui",exc)
        self._restore_home_focus();self._load_recent_cards();self._load_account_state();self._load_home_hero()

    def _start_category_prefetch(self):
        """Warm category lists after Home is visible without blocking navigation.

        One low-priority worker reuses the already connected Home client.  Category
        screens can then render from RAM immediately instead of constructing a new
        portal session and waiting several seconds for authorization/categories.
        """
        if getattr(self, "_category_prefetch_started", False):
            return
        self._category_prefetch_started = True
        profile = dict(self.profile or {})
        client = self.client
        def worker():
            # Prioritise Series/Movies because those category screens are usually
            # entered from Home and historically showed the longest cold wait.
            for media in ("series", "vod", "itv"):
                try:
                    if _category_cache_get(profile, media) is not None:
                        continue
                    rows = client.genres(media)
                    if isinstance(rows, list):
                        _category_cache_put(profile, media, rows)
                except Exception as exc:
                    optional_failure("ui.category_prefetch_%s" % media, exc)
        try:
            _CATEGORY_PREFETCH_EXECUTOR.submit(worker)
        except Exception as exc:
            optional_failure("ui.category_prefetch_submit", exc)

    def _stop_home_background_jobs(self):
        self._cancel_recent_futures()
        # AsyncScreenMixin has already marked the Screen closed; discard any
        # artwork payloads that completed in the same event-loop turn.
        try:
            while True:self._home_jobs.get_nowait()
        except queue.Empty:
            pass
        except Exception as exc:optional_failure("ui.home_queue_drain",exc)
        self._hero_data=None

    def _restore_home_focus(self):
        state=load_ui_state(self.profile)
        try:self.index=max(0,min(len(self.CARDS)-1,int(state.get("home_index",self.index))))
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:self.recent_index=max(0,min(2,int(state.get("home_recent_index",self.recent_index))))
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        row=str(state.get("home_focus_row") or self.focus_row or "menu")
        self.focus_row=row if row in ("menu","recent") else "menu"
        self._update_focus()

    def _stop_hero_timer(self):
        return

    def _hero_tick(self):
        # Automatic Home-Hero rotation/loading was removed.  Only an explicit
        # Set as Home Hero action may change the single persistent slot.
        return

    def refresh_hero(self):
        try:self["status"].setText(_("Home Hero changes only from Movie/Series Details MENU"))
        except Exception:pass

    def _queue_home_focus_state(self, **updates):
        self._home_focus_state_pending=dict(updates or {})
        try:self._home_focus_state_timer.stop();self._home_focus_state_timer.start(250,True)
        except Exception:self._flush_home_focus_state()

    def _flush_home_focus_state(self):
        pending=getattr(self,"_home_focus_state_pending",None)
        self._home_focus_state_pending=None
        if not pending:return
        try:save_ui_state(self.profile,**pending)
        except Exception as exc:optional_failure("ui.home_focus_state_flush",exc)

    def _stop_home_focus_state_timer(self):
        try:self._home_focus_state_timer.stop()
        except Exception as exc:optional_failure("ui.home_focus_state_stop",exc)
        try:
            if self._home_focus_state_conn is not None:self._home_focus_state_conn.disconnect()
        except Exception as exc:optional_failure("ui.home_focus_state_disconnect",exc)
        try:
            if self._flush_home_focus_state in self._home_focus_state_timer.callback:self._home_focus_state_timer.callback.remove(self._flush_home_focus_state)
        except Exception as exc:optional_failure("ui.home_focus_state_callback",exc)

    def _update_focus(self):
        try:
            sx=float(getattr(self,"_home_sx",1.0) or 1.0);sy=float(getattr(self,"_home_sy",1.0) or 1.0)
            if self.focus_row=="recent":
                self["selection"].hide();self["recent_selection"].instance.move(ePoint(int((self.RECENT_X[self.recent_index])*sx),int(742*sy)));self["recent_selection"].show()
                label=self["recent_label%d"%self.recent_index].getText() or _("Continue Watching")
                self._queue_home_focus_state(home_index=self.index,home_recent_index=self.recent_index,home_focus_row=self.focus_row)
                self["status"].setText(_("%s • LEFT / RIGHT switch • UP menu • OK resume")%label)
            else:
                self["recent_selection"].hide();self["selection"].instance.move(ePoint(int((self.CARD_X[self.index])*sx),int(532*sy)));self["selection"].show()
                action=self.CARDS[self.index][2]
                self._queue_home_focus_state(home_key=action,home_index=self.index,home_recent_index=self.recent_index,home_focus_row=self.focus_row)
                self["status"].setText(_("%s • DOWN recent • OK open • BACK portals")%_(self.CARDS[self.index][0]))
        except Exception as exc:optional_failure("ui",exc)

    def move_left(self):
        if self.focus_row=="recent":
            target=max(0,self.recent_index-1)
            if target==self.recent_index:return
            self.recent_index=target
        else:
            target=max(0,self.index-1)
            if target==self.index:return
            self.index=target
        self._update_focus()
    def move_right(self):
        if self.focus_row=="recent":
            target=min(2,self.recent_index+1)
            if target==self.recent_index:return
            self.recent_index=target
        else:
            target=min(len(self.CARDS)-1,self.index+1)
            if target==self.index:return
            self.index=target
        self._update_focus()
    def move_down(self):
        if self.focus_row=="menu":self.focus_row="recent";self.recent_index=min(2,max(0,int(round(self.index*2.0/max(1,len(self.CARDS)-1)))));self._update_focus()
    def move_up(self):
        if self.focus_row=="recent":self.focus_row="menu";self.index=min(len(self.CARDS)-1,int(round(self.recent_index*(len(self.CARDS)-1)/2.0)));self._update_focus()

    def _current_category_adaptive_source(self):
        """Return the exact Home hero artwork currently on screen.

        Categories must not guess a different palette by media type.  The first
        working Series implementation inherited the visible Home hero palette;
        pass that same concrete source to Series, Movies and Live so all three
        execute one identical adaptive pipeline.
        """
        hero = self._hero_data if isinstance(getattr(self, "_hero_data", None), dict) else None
        if not hero:
            try: hero = self._read_hero_cache()
            except Exception: hero = None
        if not isinstance(hero, dict):
            return None
        for key in ("display_backdrop_local", "backdrop_local", "prepared", "display_poster_local", "poster_local"):
            src = hero.get(key)
            try:
                if src and os.path.isfile(str(src)) and os.path.getsize(str(src)) > 4096:
                    return str(src)
            except Exception as exc:
                optional_failure("ui.silent_guard",exc)
        return None

    def open_selected(self):
        if self.focus_row=="recent":return self._open_recent(self.recent_index)
        action=self.CARDS[self.index][2]
        if action=="search":self.session.open(PortalGlobalSearchScreen,self.profile,self.client)
        elif action=="settings":self.session.open(NovaSettingsScreen,self.profile,self.client)
        else:self.session.open(PortalBrowserScreen,self.profile,action,self.client,self._current_category_adaptive_source())
    def open_settings(self):self.session.open(NovaSettingsScreen,self.profile,self.client)
    def open_account(self):self.session.open(PortalBrowserScreen,self.profile,"account",self.client,self._current_category_adaptive_source())

    def _recent_for_this_portal(self):
        portal=str(self.profile.get("portal") or "").rstrip("/").lower();mac=str(self.profile.get("mac") or "").upper();out=[None,None,None]
        try:rows=load_recently_played() or []
        except Exception:rows=[]
        for entry in rows:
            if not isinstance(entry,dict):continue
            if str(entry.get("portal") or "").rstrip("/").lower()!=portal:continue
            if entry.get("mac") and str(entry.get("mac") or "").upper()!=mac:continue
            item=entry.get("item") if isinstance(entry.get("item"),dict) else entry;mtype=str(entry.get("media_type") or item.get("_saved_media_type") or "").lower()
            slot=0 if mtype in ("itv","live") else (1 if mtype=="vod" else (2 if mtype in ("series","episode") else -1))
            if slot>=0 and out[slot] is None:out[slot]=(entry,item,mtype)
            if all(out):break
        return out

    def _continue_for_this_portal(self):
        portal=str(self.profile.get("portal") or "").rstrip("/").lower();mac=str(self.profile.get("mac") or "").upper();out=[None,None,None]
        # Home is a LAST-PLAYED surface, not an oldest-incomplete surface.  Earlier
        # builds filled Movie/Series from Continue Watching first, so an unfinished
        # title from days ago could hide the episode/movie the viewer just left.
        # SQLite history is already ordered by updated_at DESC; take the first
        # matching entry per fixed slot and use its saved progress to decide whether
        # to show Resume, percent watched, or Watched/play-again.
        try: recent=load_recently_played() or []
        except Exception: recent=[]
        for entry in recent:
            if not isinstance(entry,dict):continue
            if str(entry.get("portal") or "").rstrip("/").lower()!=portal:continue
            if entry.get("mac") and str(entry.get("mac") or "").upper()!=mac:continue
            item=entry.get("item") if isinstance(entry.get("item"),dict) else entry
            mtype=str(entry.get("media_type") or item.get("_saved_media_type") or "").lower()
            slot=0 if mtype in ("itv","live") else (1 if mtype=="vod" else (2 if mtype in ("series","episode") else -1))
            if slot>=0 and out[slot] is None:out[slot]=(entry,item,mtype)
            if all(out):break
        return out

    def _set_recent_art_geometry(self, slot, empty=False):
        """Keep premium empty-state icons at native proportions; restore media art geometry otherwise."""
        normal=((60,836,220,132),(697,766,190,272),(1319,766,190,272))
        premium=((102,810,136,100),(724,810,136,100),(1346,810,136,100))
        try:
            x,y,w,h=(premium if empty else normal)[int(slot)]
            desk=getDesktop(0).size();sx=float(desk.width())/1920.0;sy=float(desk.height())/1080.0
            inst=self["recent_art%d"%int(slot)].instance
            if inst is not None:
                inst.move(ePoint(int(round(x*sx)),int(round(y*sy))))
                inst.resize(eSize(int(round(w*sx)),int(round(h*sy))))
        except Exception as exc:optional_failure("ui.home_recent_geometry",exc)

    def _recent_identity(self, packed):
        """Stable slot identity so late workers can never paint a newer Recent card."""
        try:
            if not packed:return ""
            entry,item,mtype=packed
            item=item if isinstance(item,dict) else {}
            raw="%s|%s|%s|%s|%s"%(
                str(mtype or ""),str(item.get("tmdb_id") or ""),
                str(item.get("id") or item.get("stream_id") or item.get("series_id") or item.get("episode_id") or ""),
                str(item.get("name") or item.get("title") or item.get("episode_name") or ""),
                str(item.get("year") or item.get("release_date") or ""),
            )
            return hashlib.sha1(raw.encode("utf-8","ignore")).hexdigest()[:20]
        except Exception:
            return ""

    def _set_recent_player_progress(self,slot,value):
        """Reuse the Player's exact progress track + neon renderer on Home Movie/Series cards.

        No alternate recipe lives here: the track is the bundled Player track and the
        watched beam is generated by services.player_visuals._progress_neon_frame.
        Only the existing Home card widget geometry scales those Player pixmaps down.
        """
        if int(slot) not in (1,2):
            return
        try:
            track=os.path.join(PLAYER_FALLBACK_INFOBAR_DIR,"track.png")
            if track and os.path.isfile(track) and self["recent_progress_track%d"%slot].instance is not None:
                self["recent_progress_track%d"%slot].instance.setPixmapFromFile(track);self["recent_progress_track%d"%slot].show()
        except Exception as exc:optional_failure("ui.home_recent_player_track",exc)
        try:
            value=max(0,min(100,int(value or 0)))
            if value <= 0:
                self["recent_progress_neon%d"%slot].hide();return
            accent=str((_fallback_player_frames() or {}).get("accent_neon") or "#69c9f4")
            neon=_progress_neon_frame(accent,value)
            if neon and os.path.isfile(neon) and self["recent_progress_neon%d"%slot].instance is not None:
                self["recent_progress_neon%d"%slot].instance.setPixmapFromFile(neon);self["recent_progress_neon%d"%slot].show()
        except Exception as exc:optional_failure("ui.home_recent_player_neon",exc)

    def _load_recent_cards(self):
        self["continue_header"].setText(_("CONTINUE / RECENT"))
        self._cancel_recent_futures()
        self._recent_generation=int(getattr(self,"_recent_generation",0) or 0)+1
        recent_generation=self._recent_generation
        self._recent_entries=self._continue_for_this_portal()
        art_profile=dict(self.profile or {})
        art_client=self.client
        art_jobs=self._home_jobs
        recent_futures=self._recent_futures
        placeholders=("placeholder_live_x.png","grid_placeholder_movie_921.png","grid_placeholder_series_921.png")
        empty_icons=("home_live.png","home_movies.png","home_series.png")
        fixed_labels=(_("LIVE TV"),_("MOVIE"),_("SERIES"))
        for i,packed in enumerate(self._recent_entries):
            if i == 0:self["recent_progress0"].setValue(0)
            else:self._set_recent_player_progress(i,0)
            self["recent_label%d"%i].setText(fixed_labels[i])
            if not packed:
                self["recent_title%d"%i].setText(_("Nothing played yet"))
                self["recent_meta%d"%i].setText((_("Open a channel and it will appear here"),_("Watch a movie and it will appear here"),_("Watch a series and it will appear here"))[i])
                self._set_recent_art_geometry(i,empty=True)
                try:self["recent_art%d"%i].instance.setPixmapFromFile(asset(empty_icons[i]));self["recent_art%d"%i].show()
                except Exception as exc:optional_failure("ui",exc)
                continue
            self._set_recent_art_geometry(i,empty=False)
            entry,item,mtype=packed;title=premium_title(item.get("name") or item.get("title") or item.get("episode_name") or "Recent",True)
            if i==2 and mtype=="episode" and item.get("_series_title"):
                title="%s  •  %s"%(premium_title(item.get("_series_title"),True),title)
            self["recent_title%d"%i].setText(_clean_display_text(title,44))
            if i==0:
                self["recent_meta%d"%i].setText(_("Live TV • reopen channel"))
            else:
                pos=max(0,int(entry.get("_position") or 0)) if isinstance(entry,dict) else 0
                dur=max(0,int(entry.get("_duration") or 0)) if isinstance(entry,dict) else 0
                completed=bool(entry.get("_completed")) if isinstance(entry,dict) else False
                if not (pos or dur):
                    prog=load_playback_progress(self.profile,mtype,item) or {};pos=max(0,int(prog.get("position") or 0));dur=max(0,int(prog.get("duration") or 0));completed=bool(prog.get("completed"))
                pct=min(99,int(pos*100.0/dur)) if pos and dur else 0
                if completed:meta=_("Watched • play again")
                elif pct:meta=_("%s • %d%% watched")%(_("Movie") if i==1 else _("Episode"),pct)
                elif pos:meta=_("%s • Resume")%(_("Movie") if i==1 else _("Episode"))
                else:meta=_("%s • open")%(_("Movie") if i==1 else _("Series"))
                self["recent_meta%d"%i].setText(meta[:42])
                if i == 0:self["recent_progress0"].setValue(pct)
                else:self._set_recent_player_progress(i,pct)
            ph=placeholders[i]
            # First paint is HDD-only and synchronous.  The old path always sent
            # cards through a worker, so a cache hit sat invisible behind unrelated
            # provider/TMDB queue work for tens of seconds.
            cached=None
            try:cached=_home_cached_art(item,self.profile,((220,132) if i==0 else (190,272)),ph,mtype)
            except Exception as exc:optional_failure("ui.home_recent_fast_cache",exc)
            try:
                if cached and self["recent_art%d"%i].instance is not None:
                    self["recent_art%d"%i].instance.setPixmapFromFile(cached);self["recent_art%d"%i].show()
            except Exception as exc:optional_failure("ui.home_recent_fast_bind",exc)
            # Only a placeholder needs enrichment. Existing HDD art is final for
            # this Home paint and must never wait behind network work.
            placeholder_path=asset(ph)
            if cached and cached!=placeholder_path:
                continue
            recent_identity=self._recent_identity(packed)
            def worker(slot=i,it=dict(item),ph=ph,mt=mtype,generation=recent_generation,identity=recent_identity,profile=art_profile,client=art_client,jobs=art_jobs):
                # Worker owns only immutable request data + the result queue. It
                # never retains the Home Screen while network/artwork work runs.
                path=_home_prepare_art(it,profile,client,((220,132) if slot==0 else (190,272)),ph,mt)
                jobs.put(("recent",slot,path,generation,identity))
            try:
                future=_IMAGE_EXECUTOR.submit(worker,priority=4,_task_key="home-recent:%s:%s"%(str(i),recent_identity))
                recent_futures.add(future)
                future.add_done_callback(lambda done,owned=recent_futures:owned.discard(done))
            except Exception as exc:optional_failure("ui",exc)

    def _open_recent(self,slot):
        packed=self._recent_entries[slot] if 0<=slot<len(self._recent_entries) else None
        if not packed:self["status"].setText(_("Nothing has been played in this section yet"));return
        entry,item,mtype=packed
        if mtype=="series":self.session.openWithCallback(lambda result=None:self._home_shown(),ContentDetailsScreen,self.profile,self.client,"series",item);return
        command=item.get("cmd") or item.get("command") or item.get("url")
        if not command:self["status"].setText(_("Saved item has no stream command"));return
        self["status"].setText(_("Opening %s...")%(_("channel") if mtype in ("itv","live") else _("saved item")))
        episode_id=item.get("id") or item.get("episode_id") or item.get("series") or item.get("number")
        def work():
            if mtype=="episode":return self.client.create_link(item,"series",episode_id)
            return self.client.create_link(item,"itv" if mtype in ("itv","live") else "vod")
        def ok(url):
            if not isinstance(url,str) or not url.strip():self["status"].setText(_("Portal returned an invalid stream link"));return
            name=str(item.get("name") or item.get("title") or item.get("episode_name") or "Saved content")
            mt="itv" if mtype in ("itv","live") else mtype
            if mt=="itv":add_recently_played(self.profile,"itv",item)
            engine=_configured_playback_engine()
            fallback=None
            self.session.openWithCallback(lambda result=None:self._load_recent_cards(),UltraStalkerPlayer,url.strip(),name,mt,engine,_player_payload(item,self.profile,fallback,mt))
        self._run_async(work,ok,lambda e:self["status"].setText(_("Open failed: %s")%e))

    def _read_hero_state(self):
        try:
            if not HOME_HERO_FILE or not os.path.isfile(HOME_HERO_FILE):return {}
            with open(HOME_HERO_FILE,"r",encoding="utf-8") as fh:data=json.load(fh)
            return data if isinstance(data,dict) else {}
        except Exception:
            return {}

    def _read_hero_cache(self):
        data=self._read_hero_state()
        if int(data.get("schema") or 0)!=HOME_HERO_SCHEMA:return None
        hero=data.get("hero") if isinstance(data.get("hero"),dict) else None
        if not hero:return None
        prepared=str(hero.get("prepared") or "")
        try:
            if prepared and os.path.isfile(prepared) and os.path.getsize(prepared)>1024:return hero
        except Exception:pass
        return None

    def _home_backdrop_grid_title_logo(self, hero):
        """Reuse any persistent title-logo master already available on HDD.

        FIX5 unifies Home with Details/Cinematic/Backdrop/Player: Home first uses
        the logo path stored with the pinned Hero, then the shared 432x210 cache,
        then the PGV2/Player 900x125 master.  It never performs network I/O.
        """
        try:
            if _PILImage is None or not isinstance(hero,dict):return ("","")
            tmdb_id=hero.get("tmdb_id")
            media_type=str(hero.get("media_type") or "")
            preferred=str(hero.get("title_logo_lang") or "").lower().strip()
            langs=[]
            if preferred in ("en","ar"):langs.append(preferred)
            for lang in ("en","ar"):
                if lang not in langs:langs.append(lang)

            candidates=[]
            explicit=str(hero.get("title_logo_local") or "").strip()
            if explicit and os.path.isfile(explicit) and os.path.getsize(explicit)>256:
                candidates.append((explicit,preferred if preferred in ("en","ar") else "en"))
            if tmdb_id:
                try:
                    from .title_logo_shared import existing_title_logo_source
                    for lang in langs:
                        source=existing_title_logo_source(media_type,tmdb_id,lang,prefer_legacy=True)
                        if source and all(source!=row[0] for row in candidates):candidates.append((source,lang))
                except Exception as exc:optional_failure("ui.home_title_logo_shared_source",exc)

            for source,lang in candidates:
                try:
                    st=os.stat(source)
                    sig=hashlib.sha1((str(source)+"|%s|%s|home-bd-logo-760x176-v3"%(int(getattr(st,"st_mtime_ns",int(st.st_mtime*1000000000))),int(st.st_size))).encode("utf-8","ignore")).hexdigest()[:20]
                except Exception:
                    sig=hashlib.sha1((str(source)+"|home-bd-logo-760x176-v3").encode("utf-8","ignore")).hexdigest()[:20]
                ident=str(tmdb_id or hashlib.sha1(str(source).encode("utf-8","ignore")).hexdigest()[:12])
                target=os.path.join(HOME_RUNTIME_DIR,"home_bd_title_logo_%s_%s_%s_%s_760x176_v3.png"%("tv" if media_type in ("series","tv") else "movie",ident,lang,sig))
                if target and os.path.isfile(target) and os.path.getsize(target)>256:return (target,lang)
                with _PILImage.open(source) as src:
                    im=src.convert("RGBA")
                    try:
                        box=im.getchannel("A").getbbox()
                        if box:im=im.crop(box)
                    except Exception:pass
                    if im.width<2 or im.height<2:continue
                    max_w,max_h=620,138
                    scale=min(float(max_w)/float(im.width),float(max_h)/float(im.height),1.35)
                    nw=max(1,int(round(im.width*scale)));nh=max(1,int(round(im.height*scale)))
                    if (nw,nh)!=im.size:
                        res=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
                        im=im.resize((nw,nh),res)
                    canvas=_PILImage.new("RGBA",(760,176),(0,0,0,0))
                    canvas.alpha_composite(im,(8,max(0,(176-nh)//2)))
                    os.makedirs(os.path.dirname(target),mode=0o700,exist_ok=True)
                    tmp=target+".tmp.%s"%os.getpid()
                    canvas.save(tmp,"PNG",compress_level=1);os.replace(tmp,target)
                if os.path.isfile(target) and os.path.getsize(target)>256:return (target,lang)
            return ("","")
        except Exception as exc:
            optional_failure("ui.home_backdrop_title_logo",exc);return ("","")

    def _apply_home_hero(self,hero):
        if not isinstance(hero,dict):return
        self._hero_data=hero;overview=str(hero.get("overview") or "Discover a featured movie or series from TMDB.")
        try:self["status"].setText(_("%s • DOWN recent • YELLOW new hero • OK open • BACK portals")%_(self.CARDS[self.index][0]))
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        # Manual Home Hero uses the official TMDB transparent title logo only.
        # There is intentionally no text fallback: if TMDB has no logo, this
        # breathing room stays clean rather than showing a plain work name.
        for _name in ("hero_kicker","hero_title","hero_subtitle","hero_rating"):
            try:self[_name].setText("");self[_name].hide()
            except Exception as exc:optional_failure("ui.home_hero_copy_hide",exc)
        try:
            logo,logo_lang=self._home_backdrop_grid_title_logo(hero)
            if logo and os.path.isfile(logo) and os.path.getsize(logo)>256:
                self["hero_logo"].instance.setPixmapFromFile(logo);self["hero_logo"].show()
            else:self["hero_logo"].hide()
        except Exception as exc:
            optional_failure("ui.home_hero_logo_apply",exc)
            try:self["hero_logo"].hide()
            except Exception:pass
        path=hero.get("prepared");raw=hero.get("backdrop_local");display_raw=hero.get("display_backdrop_local")
        focus=hero.get("adaptive_focus") if isinstance(hero.get("adaptive_focus"),dict) else {}
        mood=hero.get("home_mood") if isinstance(hero.get("home_mood"),dict) else {}
        try:
            # us215: the backdrop is only the upper hero.  The adaptive ambient
            # layer owns the lower half of Home so artwork and glass dissolve into
            # one continuous mood instead of becoming a full-screen wallpaper.
            ambient=mood.get("ambient") if isinstance(mood,dict) else None
            if ambient and os.path.isfile(ambient):
                try:
                    self["ambient_bg"].instance.setPixmapFromFile(ambient)
                    self["ambient_bg"].show()
                except Exception as exc:optional_failure("ui.home_ambient_apply",exc)
            else:
                try:self["ambient_bg"].hide()
                except Exception as exc:optional_failure("ui.silent_guard",exc)
            # Prepared PNGs are already receiver-sized and are the most reliable
            # display path on OpenBH.  Only raw large JPEGs go through ePicLoad.
            if path and os.path.isfile(path) and os.path.getsize(path) > 1024:
                try:
                    self["hero_backdrop"].instance.setPixmapFromFile(path)
                    self["hero_backdrop"].show()
                    self._image_displayed_path = path
                except Exception:
                    self._decode_picture(path)
            elif display_raw and os.path.isfile(display_raw) and os.path.getsize(display_raw) > 1024:
                self._decode_picture(display_raw)
            elif raw and os.path.isfile(raw) and os.path.getsize(raw) > 1024:
                self._decode_picture(raw)
            if mood.get("menu") and os.path.isfile(mood.get("menu")):
                for i in range(7):self["menu_bg%d"%i].instance.setPixmapFromFile(mood.get("menu"));self["menu_bg%d"%i].show()
            if mood.get("recent") and os.path.isfile(mood.get("recent")):
                for i in range(3):self["recent_bg%d"%i].instance.setPixmapFromFile(mood.get("recent"));self["recent_bg%d"%i].show()
        except Exception as exc:optional_failure("ui.home_mood_apply",exc)
        try:self._load_menu_icons()
        except Exception as exc:optional_failure("ui.home_icons_after_mood",exc)
        try:
            menu_focus=focus.get("menu") if isinstance(focus,dict) else None
            recent_focus=focus.get("recent") if isinstance(focus,dict) else None
            if not (menu_focus and os.path.isfile(menu_focus)):menu_focus=asset("home129_menu_focus.png")
            if not (recent_focus and os.path.isfile(recent_focus)):recent_focus=asset("home129_recent_focus.png")
            if menu_focus and os.path.isfile(menu_focus):
                self["selection"].instance.setPixmapFromFile(menu_focus);self["selection"].show()
            if recent_focus and os.path.isfile(recent_focus):
                self["recent_selection"].instance.setPixmapFromFile(recent_focus)
        except Exception as exc:optional_failure("ui.home_focus_apply",exc)
    def _load_home_hero(self,force=False,background_fill=False):
        # Explicit single-slot authority only.  No TMDb featured Hero, no local
        # Hero pool, no auto-download, no rotation and no background fill.
        try:
            if _cleanup_legacy_home_hero_storage is not None:
                _cleanup_legacy_home_hero_storage()
        except Exception as exc:optional_failure("ui.hero_legacy_cleanup_home",exc)
        hero=self._read_hero_cache()
        if hero:
            hero=self._ensure_home_visual_materials(dict(hero))
            self._hero_data=hero
            self._apply_home_hero(hero)
            self._rebind_home_materials(hero)
            return
        # No explicit selection means no dynamic Hero at all.  Keep the stock
        # Home chrome and never resurrect an old cached picture by accident.
        try:self["hero_backdrop"].hide()
        except Exception:pass
        try:self["hero_logo"].hide()
        except Exception:pass
        try:self["ambient_bg"].hide()
        except Exception:pass

    def _load_account_state(self):
        def work():return self.client.account_info()
        def ok(info):
            if not isinstance(info,dict):return
            expiry=info.get("phone") or info.get("end_date") or info.get("expire_billing_date") or ""
            state=info.get("status") or info.get("account_status") or "CONNECTED"
            text="●  "+_("Portal Connected")
            if expiry:text+="   |   "+_("Expires: %s")%str(expiry)[:24]
            elif state:text+="   |   %s"%str(state)[:20]
            self["portal_state"].setText(text)
            # Persist the exact account state Home just proved. PortalList reads
            # these fields, so expiry no longer disappears after leaving Home.
            try:
                self.profile["expiry"]=str(expiry or "")
                self.profile["account_state"]=str(state or "")
                # Preserve exact provider connection telemetry captured by an
                # explicit Portal Check. Home must not erase it merely because
                # this lightweight account refresh does not return those fields.
                if expiry:
                    self.profile["state"]="%s / %s"%(str(state),str(expiry))
                profiles=load_profiles()
                target_portal=str(self.profile.get("portal") or "").rstrip("/").lower()
                target_mac=str(self.profile.get("mac") or "").upper()
                replaced=False
                for row in profiles:
                    if (str(row.get("portal") or "").rstrip("/").lower()==target_portal and
                        str(row.get("mac") or "").upper()==target_mac):
                        row.update({"expiry":self.profile.get("expiry","") ,
                                    "account_state":self.profile.get("account_state",""),
                                    "state":self.profile.get("state","")})
                        # Keep connection telemetry already stored on this row.
                        replaced=True;break
                if not replaced:profiles.append(dict(self.profile))
                save_profiles(profiles)
            except Exception as exc:optional_failure("ui.home_account_persist",exc)
        self._run_async(work,ok,lambda e:None)

    def _drain_jobs(self):
        AsyncScreenMixin._drain_jobs(self)
        if self._screen_closed:return
        self._drain_image_jobs()
        while True:
            try:job=self._home_jobs.get_nowait()
            except queue.Empty:break
            if not job:continue
            if job[0]=="hero":
                # Ignore stale automatic Hero completions that were queued before
                # an explicit Details -> Set as Home Hero action completed.
                # Re-apply the authoritative pinned state instead.
                try:
                    state=self._read_hero_state() or {}
                    if bool(state.get("manual_pin")):
                        pinned=self._read_hero_cache()
                        if pinned:
                            self._apply_home_hero(pinned)
                            continue
                except Exception as exc:optional_failure("ui.home_manual_pin_queue_guard",exc)
                self._apply_home_hero(job[1])
            elif job[0]=="recent":
                _kind,slot,path,generation,identity=job
                try:
                    if int(generation)!=int(getattr(self,"_recent_generation",0) or 0):continue
                    current=self._recent_entries[slot] if 0<=slot<len(self._recent_entries) else None
                    if identity!=self._recent_identity(current):continue
                    if path and self["recent_art%d"%slot].instance is not None:self["recent_art%d"%slot].instance.setPixmapFromFile(path);self["recent_art%d"%slot].show()
                except Exception as exc:optional_failure("ui",exc)

