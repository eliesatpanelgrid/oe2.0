"""Small, dependency-free helpers for exporting Ultra Stalker rows as M3U.

The UI owns provider access and URL resolution.  This module only turns already
resolved playable entries into a standards-friendly UTF-8 M3U file, which keeps
it easy to test without Enigma2 loaded.
"""

from __future__ import absolute_import

import os
import re


def _text(value):
    return str(value or "").replace("\r", " ").replace("\n", " ").strip()


def safe_m3u_filename(value, fallback="category"):
    """Return a filesystem-safe unicode filename stem without destroying Arabic."""
    value = _text(value)
    if not value:
        value = str(fallback or "category")
    # Linux/Enigma2 filesystems are happy with Unicode.  Only strip path/control
    # characters and characters that commonly break removable-media filesystems.
    value = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", value)
    value = re.sub(r"\s+", " ", value).strip(" ._")
    if not value:
        value = str(fallback or "category")
    return value[:120]


def _attr(value):
    return _text(value).replace('"', "'")


def build_extinf(entry, default_group=""):
    entry = entry if isinstance(entry, dict) else {}
    title = _text(entry.get("name") or entry.get("title") or "Stream")
    group = _attr(entry.get("group") or entry.get("group_title") or default_group)
    logo = _attr(entry.get("logo") or entry.get("tvg_logo"))
    tvg_id = _attr(entry.get("tvg_id") or entry.get("epg_id") or entry.get("xmltv_id"))
    tvg_name = _attr(entry.get("tvg_name") or title)
    attrs = []
    if tvg_id:
        attrs.append('tvg-id="%s"' % tvg_id)
    if tvg_name:
        attrs.append('tvg-name="%s"' % tvg_name)
    if logo:
        attrs.append('tvg-logo="%s"' % logo)
    if group:
        attrs.append('group-title="%s"' % group)
    suffix = (" " + " ".join(attrs)) if attrs else ""
    return "#EXTINF:-1%s,%s" % (suffix, title)


def write_m3u(path, entries, default_group=""):
    """Atomically write resolved entries and return the number written."""
    directory = os.path.dirname(os.path.abspath(path))
    if directory and not os.path.isdir(directory):
        os.makedirs(directory)
    tmp = path + ".tmp"
    count = 0
    try:
        with open(tmp, "w", encoding="utf-8", newline="\n") as handle:
            handle.write("#EXTM3U\n")
            for entry in entries or []:
                if not isinstance(entry, dict):
                    continue
                url = _text(entry.get("url"))
                if not url:
                    continue
                handle.write(build_extinf(entry, default_group) + "\n")
                handle.write(url + "\n")
                count += 1
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except Exception:
                pass
        os.replace(tmp, path)
    finally:
        try:
            if os.path.exists(tmp):
                os.unlink(tmp)
        except Exception:
            pass
    return count
