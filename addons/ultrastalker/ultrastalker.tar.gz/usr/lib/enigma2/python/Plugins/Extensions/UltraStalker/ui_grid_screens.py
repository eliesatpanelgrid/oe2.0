"""Poster and Live grid screens extracted from ui.py without changing class behavior."""

from . import _
from .ui_grid_base import PremiumGridBase
from .ui_dynamic_palette import _dynamic_palette
from .ui_helpers import _lift_dynamic_accent
import re
import json
import threading
try:
    from PIL import Image as _PILImage, ImageDraw as _ImageDraw, ImageFilter as _PILImageFilter
except Exception:
    _PILImage = None
    _ImageDraw = None
    _PILImageFilter = None

POSTER_GRID_SKIN = ""
POSTER_GRID_V2_SKIN = ""
LIVE_GRID_SKIN = ""

def configure_grid_screens(**deps):
    globals().update(deps)
    if "POSTER_GRID_SKIN" in deps:
        PremiumPosterGridScreen.skin = deps["POSTER_GRID_SKIN"]
    if "POSTER_GRID_V2_SKIN" in deps:
        PremiumPosterGridV2Screen.skin = deps["POSTER_GRID_V2_SKIN"]
    if "LIVE_GRID_SKIN" in deps:
        PremiumLiveGridScreen.skin = deps["LIVE_GRID_SKIN"]


def _pgv2_clean_title_detached(item):
    raw=(item or {}).get("name") or (item or {}).get("title") or ""
    try:return _clean_display_text(raw,80) or str(raw or "")
    except Exception:return str(raw or "")[:80]


def _pgv2_cinematic_title_detached(media_type,item,row=None):
    try:
        from .ui_cinematic_global import PremiumGlobalCinematicScreen
        proxy=object.__new__(PremiumGlobalCinematicScreen);proxy.media_type=media_type
        return PremiumGlobalCinematicScreen._rail_title(proxy,item,row if isinstance(row,dict) else {}) or ""
    except Exception:
        try:
            from .title_clean import catalogue_title
            return catalogue_title((item or {}).get("name") or (item or {}).get("title") or "") or ""
        except Exception:return ""


def _pgv2_logo_cache_path_detached(media_type,tmdb_id,lang):
    try:
        from .persistent_cache import GENERATED
        mt="tv" if media_type=="series" else "movie"
        return os.path.join(GENERATED,"pgv2_title_logos","%s_%s_%s_900x125_v1.png"%(mt,int(tmdb_id),str(lang or "en")))
    except Exception:return ""


def _pgv2_logo_seal_path_detached(profile,media_type,item):
    try:
        from .persistent_cache import GENERATED,content_cache_key
        key=str(content_cache_key(profile,media_type,item) or "")
        if not key:return ""
        folder=os.path.join(GENERATED,"pgv2_title_logos","ready")
        if not os.path.isdir(folder):os.makedirs(folder,mode=0o700)
        return os.path.join(folder,hashlib.sha1(key.encode("utf-8","ignore")).hexdigest()+".json")
    except Exception:return ""


def _pgv2_read_logo_seal_detached(profile,media_type,item):
    try:
        path=_pgv2_logo_seal_path_detached(profile,media_type,item)
        if not path or not os.path.isfile(path):return {}
        with open(path,"r",encoding="utf-8") as h:data=json.load(h)
        return data if isinstance(data,dict) and data.get("checked") else {}
    except Exception:return {}


def _pgv2_write_logo_seal_detached(profile,media_type,item,row,logo_path):
    try:
        path=_pgv2_logo_seal_path_detached(profile,media_type,item)
        if not path:return False
        payload={"schema":1,"tmdb_id":(row or {}).get("tmdb_id"),"title_logo_local":str(logo_path or ""),"checked":True,"updated_at":int(time.time())}
        tmp=path+".tmp.%s.%s"%(os.getpid(),threading.get_ident())
        with open(tmp,"w",encoding="utf-8") as h:
            json.dump(payload,h,ensure_ascii=False,separators=(",",":"))  # rebuildable title-logo cache seal
        os.chmod(tmp,0o600);os.replace(tmp,path);return True
    except Exception:
        try:
            if "tmp" in locals() and os.path.exists(tmp):os.unlink(tmp)
        except OSError:pass
        return False


def _pgv2_resolve_title_logo_detached(profile,media_type,item,row,cancel_event=None,settings=None):
    """Resolve the V2 title logo without retaining a Poster Grid Screen."""
    try:
        from .storage import load_settings, load_api_keys
        from .tmdb import TMDBClient
        from .fanart import fetch_artwork as _fanart_fetch
        from .artwork_v2 import _download as _artwork_download
        from .persistent_cache import GENERATED
    except Exception:return ("",row)
    fresh=dict(row or {})
    if cancel_event is not None and cancel_event.is_set():return ("",fresh)
    cfg=dict(settings or load_settings() or {})
    credential=str(cfg.get("tmdb_credential") or "").strip();timeout=min(7,max(3,int(cfg.get("timeout",10) or 10)));client=None
    try:
        if cfg.get("tmdb_enabled",True) and credential:
            client=TMDBClient(credential,str(cfg.get("tmdb_language") or "en-US"),timeout)
            if not fresh.get("tmdb_id"):
                if cancel_event is not None and cancel_event.is_set():return ("",fresh)
                enriched=client.enrich(media_type,dict(item or {}),artwork_mode="metadata") or {}
                for k,v in enriched.items():
                    if v not in (None,"",[],{}):fresh[k]=v
    except Exception as exc:optional_failure("ui.pgv2_logo_identity",exc)
    if cancel_event is not None and cancel_event.is_set():return ("",fresh)
    tmdb_id=fresh.get("tmdb_id")
    if not tmdb_id:return ("",fresh)
    visible=_pgv2_clean_title_detached(item)
    try:
        from .title_clean import catalogue_title
        visible=catalogue_title(fresh.get("original_title") or fresh.get("title") or fresh.get("name") or visible) or visible
    except Exception:pass
    logo_lang="ar" if re.search(r"[\u0600-\u06ff]",str(visible or "")) else "en";mt="tv" if media_type=="series" else "movie"
    try:
        hq_dir=os.path.join(GENERATED,"pgv2_title_logos")
        if not os.path.isdir(hq_dir):os.makedirs(hq_dir,mode=0o700)
        target=_pgv2_logo_cache_path_detached(media_type,tmdb_id,logo_lang)
    except Exception:return ("",fresh)
    if os.path.isfile(target) and os.path.getsize(target)>512:return (target,fresh)
    logo_url=""
    try:
        if client is not None:
            if cancel_event is not None and cancel_event.is_set():return ("",fresh)
            payload=client._get("/%s/%s/images"%(mt,int(tmdb_id)),{"include_image_language":(logo_lang if logo_lang=="ar" else "en,null")}) or {}
            logos=payload.get("logos") if isinstance(payload,dict) else []
            logo_path=str(((logos or [{}])[0] or {}).get("file_path") or "") if logos else ""
            logo_url=TMDBClient.image_url(logo_path,"original") if logo_path else ""
        if not logo_url:
            if cancel_event is not None and cancel_event.is_set():return ("",fresh)
            keys=load_api_keys() or {};project=str(keys.get("FANART_API_KEY") or "").strip();personal=str(keys.get("FANART_CLIENT_KEY") or "").strip()
            if project or personal:
                tvdb_id=str(fresh.get("tvdb_id") or fresh.get("thetvdb_id") or fresh.get("tvdb") or "").strip()
                if mt=="tv" and not tvdb_id and client is not None:
                    try:
                        ext=client._get("/tv/%s/external_ids"%int(tmdb_id),{}) or {};tvdb_id=str(ext.get("tvdb_id") or "").strip()
                    except Exception:tvdb_id=""
                fa=_fanart_fetch(project,mt,tmdb_id=tmdb_id,tvdb_id=tvdb_id,timeout=timeout,personal_key=personal,logo_lang=logo_lang) or {}
                logo_url=str(fa.get("title_logo_url") or "").strip()
        if cancel_event is not None and cancel_event.is_set():return ("",fresh)
        if not logo_url or _PILImage is None:return ("",fresh)
        source_target=target+".src_"+hashlib.sha1(str(logo_url).encode("utf-8","ignore")).hexdigest()[:12]
        downloaded=_artwork_download(logo_url,source_target,timeout=timeout) or ""
        if cancel_event is not None and cancel_event.is_set():return ("",fresh)
        if not downloaded or not os.path.isfile(downloaded):return ("",fresh)
        try:
            with _PILImage.open(downloaded) as src:
                im=src.convert("RGBA")
                if im.width<32 or im.height<16:return ("",fresh)
                try:
                    bbox=im.getchannel("A").getbbox()
                    if bbox:im=im.crop(bbox)
                except Exception:pass
                max_w,max_h=860,112
                if im.width<1 or im.height<1:return ("",fresh)
                scale=min(float(max_w)/im.width,float(max_h)/im.height);nw=max(1,int(round(im.width*scale)));nh=max(1,int(round(im.height*scale)))
                res=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
                if (nw,nh)!=im.size:im=im.resize((nw,nh),res)
                bg=_PILImage.new("RGBA",(900,125),(255,255,255,0));bg.paste(im,((900-nw)//2,(125-nh)//2),mask=im)
                tmp=target+".tmp.%s.%s"%(os.getpid(),threading.get_ident());bg.save(tmp,"PNG",compress_level=0);os.replace(tmp,target)
            return (target if os.path.isfile(target) and os.path.getsize(target)>512 else "",fresh)
        finally:
            try:
                if downloaded and os.path.isfile(downloaded):os.remove(downloaded)
            except Exception:pass
    except Exception as exc:
        optional_failure("ui.pgv2_logo_resolve_hq",exc);return ("",fresh)


class PremiumPosterGridScreen(PremiumGridBase):
    skin=POSTER_GRID_SKIN;columns=7;page_size=14;image_size=(206,310);placeholder="grid_placeholder_movie_921.png";selection_asset="poster_card_selected_neutral_small.png"
    card_positions=[(x,y) for y in (137,537) for x in (47,303,559,815,1071,1327,1583)]
    def __init__(self,session,profile,client,media_type,genre,category_title=""):
        self.placeholder="grid_placeholder_series_921.png" if media_type=="series" else "grid_placeholder_movie_921.png"
        self.selection_asset="poster_card_selected_neutral_small.png"
        self._poster_neutral_card_asset="poster_card_full_neutral_small.png"
        # Keep the proven Beta49 catalogue/navigation behavior.  Small-card
        # poster fill is handled by a dedicated thumbnail flag so it cannot
        # change paging/catalogue semantics.
        self._poster_cover_mode=False
        self._poster_small_fill=True
        PremiumGridBase.__init__(self,session,profile,client,media_type,genre,category_title)


class PremiumPosterGridV2Screen(PremiumGridBase):
    # release Poster Grid V2: persistent HQ title logos + Cinematic-style atomic handoff.
    # Catalogue/navigation/cache semantics stay in PremiumGridBase.
    skin=POSTER_GRID_V2_SKIN;columns=9;page_size=27;image_size=(206,309);placeholder="grid_placeholder_movie_921.png";selection_asset="pgv2_selection_exact_206x309.png"
    card_positions=[(x,y) for y in (4,319,634) for x in (9,221,433,645,857,1069,1281,1493,1705)]
    def __init__(self,session,profile,client,media_type,genre,category_title=""):
        self.placeholder="grid_placeholder_series_921.png" if media_type=="series" else "grid_placeholder_movie_921.png"
        self.selection_asset="pgv2_selection_exact_206x309.png"
        self._poster_neutral_card_asset="poster_card_full_neutral_small.png"
        self._poster_cover_mode=False;self._poster_small_fill=True
        self._pgv2_hero_key="";self._pgv2_hero_jobs=queue.Queue();self._pgv2_hero_token=0;self._pgv2_hero_pending=set();self._pgv2_has_committed_hero=False;self._pgv2_material_key="";self._pgv2_material_jobs=queue.Queue();self._pgv2_material_token=0;self._pgv2_material_pending=set()
        self._pgv2_scope="%x"%id(self);self._pgv2_hero_future=None;self._pgv2_material_future=None;self._pgv2_hero_cancel=threading.Event();self._pgv2_material_cancel=threading.Event()
        PremiumGridBase.__init__(self,session,profile,client,media_type,genre,category_title)
        self["pgv2_connected_material"]=Pixmap();self["hero_banner"]=Pixmap();self["hero_logo"]=Pixmap();self["hero_clean_title"]=Label("")
        self._pgv2_timer=eTimer();self._pgv2_timer_conn=None
        try:self._pgv2_timer_conn=self._pgv2_timer.timeout.connect(self._pgv2_drain_hero)
        except Exception:self._pgv2_timer.callback.append(self._pgv2_drain_hero)
        try:self._pgv2_timer.start(180,False)
        except Exception as exc:optional_failure("ui.pgv2_timer_start",exc)
        self.onClose.append(self._pgv2_stop)

    def _pgv2_stop(self):
        try:self._pgv2_timer.stop()
        except Exception:pass
        try:
            self._pgv2_hero_cancel.set();self._pgv2_material_cancel.set()
            for future in (self._pgv2_hero_future,self._pgv2_material_future):
                if future is not None:future.cancel()
        except Exception:pass
        self._pgv2_hero_future=None;self._pgv2_material_future=None
        try:self._pgv2_hero_token+=1;self._pgv2_material_token+=1
        except Exception:pass
        self._pgv2_hero_pending.clear();self._pgv2_material_pending.clear()
        try:
            if self._pgv2_timer_conn is not None:self._pgv2_timer_conn.disconnect()
        except Exception:pass
        self._pgv2_timer_conn=None
        try:
            if self._pgv2_drain_hero in self._pgv2_timer.callback:self._pgv2_timer.callback.remove(self._pgv2_drain_hero)
        except Exception:pass
        for q in (self._pgv2_hero_jobs,self._pgv2_material_jobs):
            try:
                while True:q.get_nowait()
            except queue.Empty:pass
            except Exception:pass

    def _pgv2_clean_title(self,item):
        return _pgv2_clean_title_detached(item)

    def _pgv2_contain_asset(self,source,kind,build=False):
        """Return an exact-size transparent hero canvas without stretching source art."""
        if not source or not os.path.isfile(source):return ""
        try:
            st=os.stat(source);dims=(900,125)
            sig="%s|%s|%s|%s|%sx%s|v84-hq"%(source,int(getattr(st,"st_mtime_ns",int(st.st_mtime*1e9))),int(st.st_size),kind,dims[0],dims[1])
            from .persistent_cache import GENERATED
            target=os.path.join(GENERATED,"pgv2_%s_fit_%s.png"%(kind,hashlib.sha1(sig.encode("utf-8","ignore")).hexdigest()[:24]))
            if os.path.isfile(target) and os.path.getsize(target)>512:return target
            if not build:return ""
            from PIL import Image,ImageOps
            with Image.open(source) as im:
                try:im=ImageOps.exif_transpose(im)
                except Exception:pass
                im=im.convert("RGBA")
                res=getattr(getattr(Image,"Resampling",Image),"LANCZOS",1)
                im.thumbnail(dims,res)
                canvas=Image.new("RGBA",dims,(0,0,0,0))
                canvas.alpha_composite(im,((dims[0]-im.width)//2,(dims[1]-im.height)//2))
                tmp=target+".tmp.%d"%os.getpid();canvas.save(tmp,"PNG",compress_level=3,optimize=False);os.replace(tmp,target)
            return target if os.path.isfile(target) else ""
        except Exception as exc:
            optional_failure("ui.pgv2_contain",exc);return ""

    def _update_header(self,item):
        # V85 atomic hero handoff: arrow navigation never replaces the committed
        # logo/title. The previous hero remains painted until stable focus has
        # prepared the next logo or confirmed the text fallback.
        try:self["title"].setText("")
        except Exception:pass
        try:return PremiumGridBase._update_header(self,item)
        except Exception:return None

    def _apply_debounced_grid_focus(self):
        PremiumGridBase._apply_debounced_grid_focus(self)
        try:self._pgv2_schedule_hero()
        except Exception as exc:optional_failure("ui.pgv2_hero_schedule",exc)
        try:self._pgv2_schedule_connected_material()
        except Exception as exc:optional_failure("ui.pgv2_material_schedule",exc)


    def _pgv2_material_source(self):
        """Local poster only. Stable focus owns this work; navigation never touches HDD/PIL."""
        try:
            path=str((getattr(self,"_grid_palette_sources",{}) or {}).get(self.index) or (getattr(self,"_grid_slot_paths",{}) or {}).get(self.index) or "")
            return path if path and os.path.isfile(path) else ""
        except Exception:
            return ""

    @staticmethod
    def _pgv2_build_connected_material(source,key):
        """Build the connected adaptive wall + exact 206x309 bright focus asset."""
        if _PILImage is None or _ImageDraw is None or not source or not os.path.isfile(source):return ("","")
        try:
            st=os.stat(source)
            sig="%s|%s|%s|pgv2-connected-laser-v76"%(source,int(getattr(st,"st_mtime_ns",int(st.st_mtime*1e9))),int(st.st_size))
            from .persistent_cache import GENERATED
            target=os.path.join(GENERATED,"pgv2_connected_%s.png"%hashlib.sha1(sig.encode("utf-8","ignore")).hexdigest()[:24])
            focus_target=os.path.join(GENERATED,"pgv2_focus_%s.png"%hashlib.sha1((sig+"|focus-exact-206x309-v76").encode("utf-8","ignore")).hexdigest()[:24])
            primary,_secondary=_dynamic_palette(source)
            r,g,b=_lift_dynamic_accent(primary,0.48,0.46)
            W,H=1920,1080

            if not (os.path.isfile(target) and os.path.getsize(target)>512):
                canvas=_PILImage.new("RGBA",(W,H),(0,0,0,0))
                draw=_ImageDraw.Draw(canvas)
                def glass_rect(box,vertical=True):
                    x0,y0,x1,y1=[int(v) for v in box]
                    if x1<=x0 or y1<=y0:return
                    span=max(1,(y1-y0-1) if vertical else (x1-x0-1))
                    for step in range(span+1):
                        t=float(step)/float(span)
                        level=(0.58-0.31*t) if t < 0.76 else (0.29+0.13*(t-0.76)/0.24)
                        rr=int(max(4,min(255,r*level)));gg=int(max(6,min(255,g*level)));bb=int(max(8,min(255,b*level)))
                        if vertical:draw.line((x0,y0+step,x1,y0+step),fill=(rr,gg,bb,246))
                        else:draw.line((x0+step,y0,x0+step,y1),fill=(rr,gg,bb,246))

                wall_bottom=943
                glass_rect((0,0,8,wall_bottom),vertical=False)
                glass_rect((1911,0,1919,wall_bottom),vertical=False)
                glass_rect((0,0,1919,3),vertical=True)
                for c in range(8):
                    x=215+(212*c);glass_rect((x,0,x+5,wall_bottom),vertical=False)
                for y in (313,628):glass_rect((0,y,1919,y+5),vertical=True)

                # V76 Floating Hero: the Poster Wall ends with the last poster row.
                # No footer/glass slab is painted below it. The native dark page background remains visible.
                # Only a very soft adaptive atmosphere sits behind the Hero so Banner/Logo/Title floats naturally.
                hero_fx=_PILImage.new("RGBA",(W,H),(0,0,0,0))
                hx=_ImageDraw.Draw(hero_fx)
                # low-energy adaptive bloom, intentionally without a hard rectangle or visible frame
                hx.rounded_rectangle((545,952,1375,1074),radius=30,fill=(r,g,b,42))
                if _PILImageFilter is not None:hero_fx=hero_fx.filter(_PILImageFilter.GaussianBlur(34.0))
                canvas=_PILImage.alpha_composite(canvas,hero_fx)
                hero_shadow=_PILImage.new("RGBA",(W,H),(0,0,0,0))
                hs=_ImageDraw.Draw(hero_shadow)
                hs.rounded_rectangle((592,966,1328,1078),radius=22,fill=(0,0,0,105))
                if _PILImageFilter is not None:hero_shadow=hero_shadow.filter(_PILImageFilter.GaussianBlur(16.0))
                canvas=_PILImage.alpha_composite(canvas,hero_shadow)

                laser_hot=tuple(min(255,int(v*.48+255*.52)) for v in (r,g,b))
                laser_core=tuple(min(255,int(v*.20+255*.80)) for v in (r,g,b))
                paths=[]
                for c in range(8):
                    x=218+(212*c);paths.append((x,0,x,wall_bottom))
                for y in (316,631):paths.append((0,y,1919,y))
                paths.append((0,946,1919,946))

                bloom=_PILImage.new("RGBA",(W,H),(0,0,0,0));bd=_ImageDraw.Draw(bloom)
                for line in paths:bd.line(line,fill=(r,g,b,170),width=5)
                if _PILImageFilter is not None:bloom=bloom.filter(_PILImageFilter.GaussianBlur(3.2))
                canvas=_PILImage.alpha_composite(canvas,bloom)
                halo=_PILImage.new("RGBA",(W,H),(0,0,0,0));hd=_ImageDraw.Draw(halo)
                for line in paths:hd.line(line,fill=(r,g,b,225),width=3)
                if _PILImageFilter is not None:halo=halo.filter(_PILImageFilter.GaussianBlur(1.35))
                canvas=_PILImage.alpha_composite(canvas,halo)
                d=_ImageDraw.Draw(canvas)
                for line in paths:
                    d.line(line,fill=laser_hot+(245,),width=2)
                    d.line(line,fill=laser_core+(255,),width=1)
                tmp=target+".tmp.%d"%os.getpid();canvas.save(tmp,"PNG",compress_level=3,optimize=False);os.replace(tmp,target)

            if not (os.path.isfile(focus_target) and os.path.getsize(focus_target)>256):
                FW,FH=206,309
                glow=_PILImage.new("RGBA",(FW,FH),(0,0,0,0));gd=_ImageDraw.Draw(glow)
                for inset,width,alpha in ((1,10,155),(2,7,210),(3,4,245)):
                    gd.rounded_rectangle((inset,inset,FW-1-inset,FH-1-inset),radius=8,outline=(r,g,b,alpha),width=width)
                if _PILImageFilter is not None:glow=glow.filter(_PILImageFilter.GaussianBlur(3.0))
                fd=_ImageDraw.Draw(glow)
                hot=tuple(min(255,int(v*.28+255*.72)) for v in (r,g,b))
                core=tuple(min(255,int(v*.10+255*.90)) for v in (r,g,b))
                fd.rounded_rectangle((1,1,FW-2,FH-2),radius=8,outline=hot+(255,),width=4)
                fd.rounded_rectangle((2,2,FW-3,FH-3),radius=7,outline=core+(255,),width=2)
                ftmp=focus_target+".tmp.%d"%os.getpid();glow.save(ftmp,"PNG",compress_level=3,optimize=False);os.replace(ftmp,focus_target)
            return (target if os.path.isfile(target) else "",focus_target if os.path.isfile(focus_target) else "")
        except Exception as exc:
            optional_failure("ui.pgv2_material_build",exc);return ("","")

    def _pgv2_schedule_connected_material(self):
        if self._screen_closed or not self.grid_items:return
        source=self._pgv2_material_source()
        if not source:return
        try:
            from .persistent_cache import content_cache_key
            item=self.grid_items[self.index];key=str(content_cache_key(self.profile,self.media_type,item) or "")
        except Exception:key=str(source)
        if not key:return
        # Only the current stable focus matters. Cancel queued obsolete material
        # jobs so the single worker never spends time painting cards already left.
        try:
            self._pgv2_material_cancel.set()
            if self._pgv2_material_future is not None:self._pgv2_material_future.cancel()
        except Exception:pass
        self._pgv2_material_cancel=threading.Event();cancel=self._pgv2_material_cancel
        self._pgv2_material_pending.clear();self._pgv2_material_token+=1;token=self._pgv2_material_token
        self._pgv2_material_pending.add(key);result_q=self._pgv2_material_jobs;build_material=type(self)._pgv2_build_connected_material
        def worker():
            if cancel.is_set():return
            path,focus_path=build_material(source,key)
            if cancel.is_set():return
            result_q.put((token,key,path,focus_path))
        try:
            future=_PGV2_MATERIAL_EXECUTOR.submit(worker,priority=1,_task_key="pgv2-material:%s:%s"%(self._pgv2_scope,key))
            self._pgv2_material_future=future
            if future.done():
                try:future.result()
                except Exception:self._pgv2_material_pending.discard(key)
        except Exception as exc:
            self._pgv2_material_pending.discard(key);optional_failure("ui.pgv2_material_submit",exc)

    def _pgv2_apply_connected_material(self,token,key,path,focus_path=""):
        if token!=self._pgv2_material_token:return
        if path and os.path.isfile(path):
            try:
                self["pgv2_connected_material"].instance.setPixmapFromFile(path);self["pgv2_connected_material"].show();self._pgv2_material_key=key
            except Exception as exc:optional_failure("ui.pgv2_material_apply",exc)
        if focus_path and os.path.isfile(focus_path):
            try:
                self["selection"].instance.setPixmapFromFile(focus_path);self["selection"].show();self._grid_selection_visual_path=focus_path
                self["selection_adaptive"].hide()
            except Exception as exc:optional_failure("ui.pgv2_focus_apply",exc)

    def _grid_apply_current_selector(self,allow_build=False):
        """Poster Grid V2 owns one exact-size focus; legacy oversized overlay stays disabled."""
        try:self["selection_adaptive"].hide()
        except Exception:pass
        try:
            if not getattr(self,"_grid_selection_visual_path",""):
                neutral=asset(self.selection_asset)
                self["selection"].instance.setPixmapFromFile(neutral);self._grid_selection_visual_path=neutral
            self["selection"].show()
        except Exception as exc:optional_failure("ui.pgv2_selector",exc)

    def _pgv2_cinematic_title(self,item,row=None):
        return _pgv2_cinematic_title_detached(self.media_type,item,row)

    def _pgv2_fit_official_title(self,title):
        title=str(title or "").strip()
        try:self["hero_clean_title"].setText(title)
        except Exception:return
        try:
            n=len(title)
            size=72 if n<=18 else 64 if n<=28 else 56 if n<=42 else 48 if n<=58 else 40
            if globals().get("gFont") is not None and self["hero_clean_title"].instance is not None:
                self["hero_clean_title"].instance.setFont(gFont("Regular",size))
        except Exception:pass

    def _pgv2_logo_cache_path(self,tmdb_id,lang):
        return _pgv2_logo_cache_path_detached(self.media_type,tmdb_id,lang)

    def _pgv2_logo_seal_path(self,item):
        return _pgv2_logo_seal_path_detached(self.profile,self.media_type,item)

    def _pgv2_write_logo_seal(self,item,row,logo_path):
        return _pgv2_write_logo_seal_detached(self.profile,self.media_type,item,row,logo_path)

    def _pgv2_read_logo_seal(self,item):
        return _pgv2_read_logo_seal_detached(self.profile,self.media_type,item)

    def _folder_artwork_ready_hook(self,item,data):
        # BLUE cache treats the V2 title-logo probe as part of the durable item package.
        return bool(self._pgv2_read_logo_seal(item))

    def _folder_artwork_finalize_hook(self,item,poster,backdrop,payload,data,cancel_event=None):
        try:
            from .details_authority import resolve_canonical
            fresh=dict(data or {})
            authoritative=resolve_canonical(self.profile,self.media_type,dict(item),cancel_event=cancel_event,settings=(self._grid_settings or {})) or {}
            for k,v in authoritative.items():
                if v not in (None,"",[],{}):fresh[k]=v
            logo,fresh=self._pgv2_resolve_title_logo(dict(item),fresh)
            self._pgv2_write_logo_seal(item,fresh,logo)
            return True
        except Exception as exc:
            optional_failure("ui.pgv2_blue_logo_finalize",exc);return False

    def _pgv2_resolve_title_logo(self,item,row,cancel_event=None,settings=None):
        return _pgv2_resolve_title_logo_detached(self.profile,self.media_type,item,row,cancel_event=cancel_event,settings=settings)

    def _pgv2_schedule_hero(self):
        """Stable-focus hero handoff with bounded, cancellable background work."""
        if self._screen_closed or not self.grid_items:return
        item=self.grid_items[self.index]
        try:
            from .persistent_cache import content_cache_key
            key=str(content_cache_key(self.profile,self.media_type,item) or "")
        except Exception:key=str(id(item))
        if not key:return

        try:
            self._pgv2_hero_cancel.set()
            if self._pgv2_hero_future is not None:self._pgv2_hero_future.cancel()
        except Exception:pass
        self._pgv2_hero_cancel=threading.Event();cancel=self._pgv2_hero_cancel
        self._pgv2_hero_pending.clear();self._pgv2_hero_token+=1;token=self._pgv2_hero_token

        # First entry may show the clean catalogue title; later navigation keeps
        # the committed hero until this current focus atomically hands off.
        visible=self._pgv2_cinematic_title(item,{})
        if not self._pgv2_has_committed_hero:
            self._pgv2_apply_hero(token,key,item,"","",visible)
        self._pgv2_hero_pending.add(key)

        profile=dict(self.profile or {});media_type=self.media_type;settings=dict(self._grid_settings or {})
        item_copy=dict(item) if isinstance(item,dict) else item;result_q=self._pgv2_hero_jobs
        def worker():
            if cancel.is_set():return
            fresh={};out_logo="";display_title=visible
            try:
                from .artwork_v2 import load_manifest
                art=load_manifest(profile,media_type,item_copy) or {}
                if cancel.is_set():return
                from .details_authority import load_detail_snapshot,resolve_canonical
                detail=load_detail_snapshot(profile,media_type,item_copy) or {}
                fresh=dict(detail);fresh.update(art)
                if cancel.is_set():return
                tmdb_id=(fresh or {}).get("tmdb_id")
                if tmdb_id:
                    visible0=_pgv2_cinematic_title_detached(media_type,item_copy,fresh)
                    lang="ar" if re.search(r"[\u0600-\u06ff]",str(visible0 or "")) else "en"
                    path=_pgv2_logo_cache_path_detached(media_type,tmdb_id,lang)
                    if path and os.path.isfile(path) and os.path.getsize(path)>512:out_logo=path
                if not out_logo and not cancel.is_set():
                    seal=_pgv2_read_logo_seal_detached(profile,media_type,item_copy)
                    path=str((seal or {}).get("title_logo_local") or "")
                    if path and os.path.isfile(path) and os.path.getsize(path)>512:out_logo=path
                display_title=_pgv2_cinematic_title_detached(media_type,item_copy,fresh) or display_title
                if cancel.is_set():return

                authoritative=resolve_canonical(profile,media_type,item_copy,cancel_event=cancel,settings=settings) or {}
                if cancel.is_set():return
                if authoritative:
                    merged=dict(fresh)
                    for k,v in authoritative.items():
                        if v not in (None,"",[],{}):merged[k]=v
                    fresh=merged
                out_logo,fresh=_pgv2_resolve_title_logo_detached(profile,media_type,item_copy,fresh,cancel_event=cancel,settings=settings)
                if cancel.is_set():return
                _pgv2_write_logo_seal_detached(profile,media_type,item_copy,fresh,out_logo)
                try:
                    from .title_clean import catalogue_title
                    display_title=catalogue_title(fresh.get("original_title") or fresh.get("title") or fresh.get("name") or display_title) or display_title
                except Exception:pass
            except Exception as exc:optional_failure("ui.pgv2_cinematic_exact_logo",exc)
            if cancel.is_set():return
            fitted=out_logo if out_logo and os.path.isfile(out_logo) else ""
            result_q.put((token,key,item_copy,"",fitted,display_title))
        try:
            future=_PGV2_HERO_EXECUTOR.submit(worker,priority=0,_task_key="pgv2-hero:%s:%s"%(self._pgv2_scope,key))
            self._pgv2_hero_future=future
            if future.done():
                try:future.result()
                except Exception:self._pgv2_hero_pending.discard(key)
        except Exception as exc:
            self._pgv2_hero_pending.discard(key);optional_failure("ui.pgv2_hero_submit",exc)

    def _pgv2_apply_hero(self,token,key,item,banner,logo,official_title=""):
        if token!=self._pgv2_hero_token:return
        self._pgv2_hero_key=key
        valid_logo=bool(logo and os.path.isfile(logo) and os.path.getsize(logo)>512)
        try:
            # V78 comparison build: Banner is deliberately disabled in Poster Grid.
            self["hero_banner"].hide()
            if valid_logo:
                self["hero_logo"].instance.setPixmapFromFile(logo);self["hero_logo"].show();self["hero_clean_title"].hide()
            else:
                self["hero_logo"].hide();self._pgv2_fit_official_title(official_title or self._pgv2_clean_title(item));self["hero_clean_title"].show()
            self._pgv2_has_committed_hero=True
        except Exception as exc:optional_failure("ui.pgv2_hero_apply",exc)

    def _pgv2_drain_hero(self):
        for _ in range(4):
            try:token,key,item,banner,logo,official_title=self._pgv2_hero_jobs.get_nowait()
            except queue.Empty:break
            except Exception:break
            self._pgv2_hero_pending.discard(key)
            self._pgv2_apply_hero(token,key,item,banner,logo,official_title)
        for _ in range(4):
            try:token,key,path,focus_path=self._pgv2_material_jobs.get_nowait()
            except queue.Empty:break
            except Exception:break
            self._pgv2_material_pending.discard(key)
            self._pgv2_apply_connected_material(token,key,path,focus_path)


class PremiumLiveGridScreen(PremiumGridBase):
    skin=LIVE_GRID_SKIN;columns=1;page_size=12;image_size=(64,36);placeholder="grid_placeholder_live_921.png";selection_asset="us205_live_selection_neutral.png"
    card_positions=[(58,170+i*68) for i in range(12)]
    PREVIEW_RECT=(870,145,900,506)

    def __init__(self,session,profile,client,media_type,genre,category_title=""):
        # Live picons persist on HDD and are reused before any network request.
        self._preview_old_service=None
        try:self._preview_old_service=session.nav.getCurrentlyPlayingServiceReference()
        except Exception as exc:optional_failure("ui",exc)
        self._active_preview_key=None;self._active_preview_url=None;self._active_preview_item=None;self._active_preview_engine=None
        self._preview_token=0;self._preview_jobs=queue.Queue();self._preview_handle=None;self._preview_task_id=None;self._pending_preview_key=None
        self._preview_pending_url=None;self._preview_pending_item=None;self._preview_pending_engine=None;self._preview_engine_candidates=[];self._preview_engine_pos=0
        self._preview_poll_count=0;self._preview_restore_state=None;self._main_preview_reference=None
        PremiumGridBase.__init__(self,session,profile,client,media_type,genre,category_title)
        try:self._last_fullscreen_key=str((_GRID_NAV_STATE.get(self._session_nav_key,{}) or {}).get("last_fullscreen_key") or "")
        except Exception:self._last_fullscreen_key=""
        self._preview_ready_timer=eTimer();self._preview_ready_conn=None
        try:self._preview_ready_conn=self._preview_ready_timer.timeout.connect(self._check_preview_ready)
        except Exception:self._preview_ready_timer.callback.append(self._check_preview_ready)
        self["channel_name"]=Label("");self["current_channel_top"]=Label("");self["date_label"]=Label(time.strftime("%A, %d %B %Y"));self["preview_status"]=Label("")
        self["page_adaptive_bg"]=Pixmap();self["preview_frame"]=Pixmap();self["live_info_bg"]=Pixmap();self["page_label_bg"]=Pixmap();self["current_channel_bg"]=Pixmap();self["clock_glass_bg"]=Pixmap()
        self["tech_bg1"]=Pixmap();self["tech_bg2"]=Pixmap();self["tech_bg3"]=Pixmap();self["tech_bg4"]=Pixmap()
        for _ri in range(self.page_size):self["row_adaptive%d"%_ri]=Pixmap()
        self._live_chrome_jobs=queue.Queue();self._live_chrome_token=0;self._live_chrome_key=None
        self["epg_hint"]=Label(_("NOW / NEXT"));self["tech1"]=Label(_("AUTO"));self["tech2"]=Label(_("LIVE"));self["tech3"]=Label(_("CHANNEL"));self["tech4"]=Label(_("OK Preview"))
        self["now_progress"]=ProgressBar()
        try:self["now_progress"].setValue(0)
        except Exception as exc:optional_failure("ui",exc)
        self.onLayoutFinish.append(self._prepare_preview_window);self.onLayoutFinish.append(self._apply_live_neutral_chrome);self.onClose.append(self._stop_live_preview);self.onClose.append(self._stop_live_grid_hooks)
        self["red"].setText(_("Back"));self["green"].setText(_("Favorite"));self["yellow"].setText(_("Previous page"));self["blue"].setText(_("Next page"));self["brand"].setText("")
        try:force_session_silence(self.session,"",force=False)
        except Exception as exc:optional_failure("ui",exc)

    def _grid_set_local(self,slot,path):
        """Render a normalized row picon on the 12-row Live screen only."""
        render_path=path
        try:
            source=str(path or "")
            is_placeholder=(not source or os.path.basename(source)==os.path.basename(asset(self.placeholder)))
            if not is_placeholder and os.path.isfile(source):
                fitted=_fit_live_row_picon_canvas(source,PERSISTENT_GENERATED_DIR,(64,36))
                if fitted and os.path.isfile(str(fitted)):
                    render_path=fitted
        except Exception as exc:
            optional_failure("ui.live_row_render_fit",exc)
            render_path=path
        return super(PremiumLiveGridScreen,self)._grid_set_local(slot,render_path)

    def _stop_live_grid_hooks(self):
        for result_queue_name in ("_preview_jobs","_live_chrome_jobs"):
            result_queue=getattr(self,result_queue_name,None)
            if result_queue is None:continue
            try:
                while True:result_queue.get_nowait()
            except queue.Empty:
                pass
            except Exception as exc:
                optional_failure("ui.live_grid_queue_cleanup",exc)
        for hook_name,callback in (
            ("onLayoutFinish",self._prepare_preview_window),
            ("onLayoutFinish",self._apply_live_neutral_chrome),
        ):
            try:
                hooks=getattr(self,hook_name,None)
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:
                optional_failure("ui.live_grid_hook_cleanup",exc)

    def _prepare_preview_window(self):
        # session.VideoPicture + Renderer/Pig owns decoder-0 geometry.
        # eVideoWidget applies the preview rectangle when shown and restores full
        # screen automatically when the screen/renderer is hidden.
        try:LOG.info("Live preview Pig renderer ready rect=%s", self.PREVIEW_RECT)
        except Exception as exc:optional_failure("ui",exc)

    def _apply_live_neutral_chrome(self):
        try:
            chrome={"page":asset("us205_live_page_neutral.png"),"selected":asset("us205_live_selection_neutral.png"),"preview":asset("us205_live_preview_glass.png"),"info":asset("us205_live_info_glass.png"),"tech":asset("us205_live_tech_glass.png")}
            # Generate correct-size neutral HUD materials once. This prevents
            # clock/channel/counter glass from disappearing while a picon is pending.
            neutral_source=asset("us205_live_selection_neutral.png")
            neutral_hud=_build_live_adaptive_chrome_211(neutral_source,"live_neutral_hud_v3") if os.path.isfile(neutral_source) else {}
            for _key in ("counter","channel_top","clock","row"):
                _path=(neutral_hud or {}).get(_key)
                if _path and os.path.isfile(_path):chrome[_key]=_path
            if not chrome.get("counter"):chrome["counter"]=chrome["tech"]
            self._apply_live_chrome(chrome)
        except Exception as exc:optional_failure("ui.live211_neutral",exc)

    def _apply_live_chrome(self,chrome):
        if not isinstance(chrome,dict):return
        # Keep the exact last-good files. Rebinding an already-built PNG is
        # virtually free and avoids regenerating adaptive artwork after Player.
        try:self._live_last_chrome=dict(chrome)
        except Exception:self._live_last_chrome={}
        try:
            for key,widget in (("page","page_adaptive_bg"),("selected","selection"),("preview","preview_frame"),("info","live_info_bg"),("counter","page_label_bg"),("channel_top","current_channel_bg"),("clock","clock_glass_bg")):
                path=chrome.get(key)
                if path and os.path.isfile(path):self[widget].instance.setPixmapFromFile(path);self[widget].show()
            tech=chrome.get("tech")
            if tech and os.path.isfile(tech):
                for name in ("tech_bg1","tech_bg2","tech_bg3","tech_bg4"):
                    self[name].instance.setPixmapFromFile(tech);self[name].show()
            rowglass=chrome.get("row")
            if rowglass and os.path.isfile(rowglass):
                for _ri in range(self.page_size):
                    self["row_adaptive%d"%_ri].instance.setPixmapFromFile(rowglass)
                    self["row_adaptive%d"%_ri].show()
            accent=chrome.get("accent")
            if accent:
                color="#%02x%02x%02x"%tuple(accent[:3])
                try:self["now_progress"].instance.setForegroundColor(parseColor(color))
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["channel_name"].instance.setForegroundColor(parseColor(color))
                except Exception as exc:optional_failure("ui.silent_guard",exc)
        except Exception as exc:optional_failure("ui.live211_apply",exc)

    def _force_live_visual_rebind(self):
        """Restore every Live visual surface after returning from Full Screen."""
        if getattr(self,"_screen_closed",False):return

        # Snapshot adaptive state BEFORE painting neutral fallback, because
        # _apply_live_chrome() itself updates _live_last_chrome.
        last=dict(getattr(self,"_live_last_chrome",{}) or {})

        # Neutral assets are guaranteed and give us an immediate complete frame.
        try:self._apply_live_neutral_chrome()
        except Exception as exc:optional_failure("ui.live_force_neutral",exc)

        # Then synchronously re-apply the exact last adaptive material if valid.
        if last:
            try:self._apply_live_chrome(last)
            except Exception as exc:optional_failure("ui.live_force_last_chrome",exc)

        # Re-show visible channel artwork from the retained slot map/cache.
        for slot,path in list((getattr(self,"_grid_slot_paths",{}) or {}).items()):
            if slot >= len(getattr(self,"grid_items",[]) or []):continue
            try:
                ptr=self._grid_cache_get(path) if path else None
                if ptr is not None:self._grid_set_ptr(slot,ptr)
                elif path and os.path.isfile(path):self._grid_set_local(slot,path)
            except Exception as exc:optional_failure("ui.live_force_art",exc)

        # The selection widget must be moved/shown after all background layers.
        try:self._update_selection()
        except Exception as exc:optional_failure("ui.live_force_selection",exc)

        # Force the selected-channel adaptive pass even if its key is unchanged.
        try:
            item=self.grid_items[self.index] if self.grid_items and 0<=self.index<len(self.grid_items) else None
            path=self._live_palette_source_for_item(item,self.index)
            self._schedule_live_chrome(path,force=True,item=item,slot=self.index)
        except Exception as exc:optional_failure("ui.live_force_schedule",exc)

    def _live_palette_source_for_item(self,item=None,slot=None):
        """Resolve palette art from the currently selected channel identity."""
        item=item or (self.grid_items[self.index] if self.grid_items and 0<=self.index<len(self.grid_items) else None)
        slot=self.index if slot is None else int(slot)
        if not isinstance(item,dict):return None
        try:
            raw_url=_image_url(item)
            url=_optimized_artwork_url(self._grid_absolute_url(raw_url,item),False) if raw_url else None
            if url:
                digest=hashlib.sha1(url.encode("utf-8","ignore")).hexdigest()
                thumb=_thumb_path(digest,self._grid_image_size)
                if _valid_cache_file(thumb):return thumb
                original=_find_original_artwork(digest)
                if original and os.path.isfile(original):return original
        except Exception as exc:optional_failure("ui.live_palette_url",exc)
        # Slot path is only a fallback for this exact visible row, never a global last source.
        try:
            path=(getattr(self,"_grid_slot_paths",{}) or {}).get(slot)
            if path and os.path.isfile(path) and "placeholder" not in os.path.basename(path).casefold():
                return path
        except Exception as exc:optional_failure("ui.live_palette_slot",exc)
        return None

    def _schedule_live_chrome(self,path=None,force=False,item=None,slot=None):
        if self._screen_closed:return
        slot=self.index if slot is None else int(slot)
        item=item or (self.grid_items[slot] if self.grid_items and 0<=slot<len(self.grid_items) else None)
        identity=self._preview_key(item) if isinstance(item,dict) else ""
        path=self._live_palette_source_for_item(item,slot) or path
        if not path or not os.path.isfile(path):
            # Never inherit the previous channel colour when the current picon is unresolved.
            self._live_chrome_token+=1
            self._live_chrome_key=None
            self._live_chrome_identity=identity
            self._apply_live_neutral_chrome()
            return
        try:stamp=str(int(os.path.getmtime(path)))
        except Exception:stamp="0"
        key=hashlib.sha1((str(identity)+"|"+path+"|"+stamp+"|livehud3d_v3").encode("utf-8","ignore")).hexdigest()[:18]
        if key==self._live_chrome_key and identity==getattr(self,"_live_chrome_identity","") and not force:return
        self._live_chrome_token+=1;token=self._live_chrome_token
        self._live_chrome_key=key;self._live_chrome_identity=identity
        def worker():
            chrome=_build_live_adaptive_chrome_211(path,key)
            try:self._live_chrome_jobs.put((token,key,identity,path,chrome))
            except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:_GRID_ACCENT_EXECUTOR.submit(worker,_task_key="live-chrome:%x"%id(self),_replace_task_key=True)
        except Exception as exc:optional_failure("ui.live211_submit",exc)

    def _grid_queue_decode(self,generation,slot,path):
        # beta28: Live picons are tiny, already-local display assets. On OpenBH
        # the shared ePicLoad queue used for large posters can complete without a
        # usable Live pixmap callback on some image/provider combinations. Render
        # the prepared local picon directly into artN and keep ePicLoad for VOD/
        # Series only. This also makes the final Live stage deterministic: once
        # download/cache produced a valid file, the row gets that exact file.
        if generation!=getattr(self,"_grid_generation",generation):
            _live_picon_diag("RENDER_STALE slot=%r generation=%r current=%r path=%r"%(slot,generation,getattr(self,"_grid_generation",None),path))
            return
        _live_picon_diag("RENDER_ENTER slot=%r path=%r exists=%r size=%r"%(slot,path,bool(path and os.path.isfile(path)),(os.path.getsize(path) if path and os.path.isfile(path) else -1)))
        if path and os.path.isfile(path):
            try:
                self._grid_slot_paths[slot]=path
                self._grid_palette_sources[slot]=path
                self._grid_set_local(slot,path)
                _live_picon_diag("RENDER_SET_LOCAL_OK slot=%r channel=%r path=%r widget_instance=%r"%(slot,str((self.grid_items[slot] if self.grid_items and 0<=slot<len(self.grid_items) else {}).get("name") or ""),path,getattr(self["art%d"%slot],"instance",None) is not None))
                if self.media_type=="itv":
                    try:LOG.info("Live picon direct render slot=%s channel=%r path=%s",slot,str((self.grid_items[slot] if self.grid_items and 0<=slot<len(self.grid_items) else {}).get("name") or ""),path)
                    except Exception:pass
                if slot==getattr(self,"index",-1):
                    item=self.grid_items[slot] if self.grid_items and 0<=slot<len(self.grid_items) else None
                    self._schedule_live_chrome(path,item=item,slot=slot)
                return
            except Exception as exc:
                optional_failure("ui.live_direct_picon_render",exc)
        # Defensive fallback only; valid Live cache files should never need it.
        PremiumGridBase._grid_queue_decode(self,generation,slot,path)
        if slot==getattr(self,"index",-1):
            item=self.grid_items[slot] if self.grid_items and 0<=slot<len(self.grid_items) else None
            self._schedule_live_chrome(path,item=item,slot=slot)

    @staticmethod
    def _preview_key(item):
        return str((item or {}).get("id") or (item or {}).get("ch_id") or (item or {}).get("cmd") or (item or {}).get("name") or "")

    def _drain_jobs(self):
        PremiumGridBase._drain_jobs(self)
        while True:
            try:token,key,identity,path,chrome=self._live_chrome_jobs.get_nowait()
            except queue.Empty:break
            except Exception:continue
            if self._screen_closed or token!=self._live_chrome_token or key!=self._live_chrome_key:continue
            current_item=self.grid_items[self.index] if self.grid_items and 0<=self.index<len(self.grid_items) else None
            current_identity=self._preview_key(current_item) if isinstance(current_item,dict) else ""
            current_path=self._live_palette_source_for_item(current_item,self.index)
            if identity!=current_identity:continue
            if current_path and os.path.abspath(current_path)!=os.path.abspath(path):continue
            self._apply_live_chrome(chrome)
        if self._screen_closed:return
        while True:
            try:
                job=self._preview_jobs.get_nowait();callback,value,is_error=job[:3];task_id=job[3] if len(job)>3 else None
            except queue.Empty:break
            except Exception:continue
            if task_id is not None and self._preview_task_id is not None and task_id!=self._preview_task_id:continue
            self._preview_handle=None;self._preview_task_id=None
            if callback:
                try:callback(value)
                except Exception:
                    try:self["preview_status"].setText(_("Preview unavailable"))
                    except Exception as exc:optional_failure("ui",exc)
            elif is_error:
                try:self["preview_status"].setText(_("Preview unavailable"))
                except Exception as exc:optional_failure("ui",exc)

    def _cancel_preview_request(self):
        handle=self._preview_handle;self._preview_handle=None;self._preview_task_id=None;self._pending_preview_key=None
        try:self._preview_ready_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        self._preview_pending_url=None;self._preview_pending_item=None;self._preview_pending_engine=None;self._preview_engine_candidates=[];self._preview_engine_pos=0;self._preview_poll_count=0
        if handle is not None:
            try:handle.cancel()
            except Exception as exc:optional_failure("ui",exc)

    def _update_header(self,item):
        PremiumGridBase._update_header(self,item)
        try:
            cid=str(item.get("id") or item.get("ch_id") or "");epg=self._epg_cache.get(cid,{})
            self["now_progress"].setValue(int(epg.get("percent") or 0))
        except Exception as exc:optional_failure("ui",exc)

    def _update_selection(self):
        PremiumGridBase._update_selection(self)
        if not self.grid_items:return
        item=self.grid_items[self.index];raw=item.get("name") or item.get("title") or "Channel"
        clean_name=_clean_display_text(_clean_live_channel_name(raw),80)
        self["channel_name"].setText(clean_name)
        # Responsive one-line title. Keep short names bold/large, reduce only when
        # the actual label gets long enough to risk clipping its 820px card.
        try:
            units=sum(1.65 if ord(ch)>0x2ff else (0.58 if ch in " ilI1|.,:'" else 1.0) for ch in clean_name)
            font_size=32 if units<=26 else (29 if units<=34 else (26 if units<=43 else (23 if units<=53 else 20)))
            if self["channel_name"].instance is not None:self["channel_name"].instance.setFont(gFont("Regular",font_size))
        except Exception as exc:optional_failure("ui.live_title_font",exc)
        q=quality_badges(raw) or _("AUTO");self["tech1"].setText(q[:16])
        self["tech2"].setText(_("Catch-up") if (item.get("allow_archive") or item.get("tv_archive_duration") or item.get("archive")) else _("LIVE"))
        self["tech3"].setText(_("Channel %d")%max(1,(int(self.page or 1)-1)*int(self.page_size or 1)+int(self.index)+1))
        key=self._preview_key(item)
        if self._pending_preview_key:
            self["preview_status"].setText(_("Loading preview..."));self["tech4"].setText(_("Loading...") if key==self._pending_preview_key else _("OK Preview"))
        elif self._active_preview_key:
            self["preview_status"].setText("");self["tech4"].setText(_("OK Full Screen") if key==self._active_preview_key else _("OK Preview"))
        else:
            self["preview_status"].setText("");self["tech4"].setText(_("OK Preview"))
        # Palette source must follow the currently selected picon, not whichever
        # thumbnail path happened to be decoded first. Force is safe because the
        # generated chrome is HDD-cached; it only guarantees a real rebind.
        self["current_channel_top"].setText(clean_name)
        try:
            units=sum(1.65 if ord(ch)>0x2ff else (0.58 if ch in " ilI1|.,:'" else 1.0) for ch in clean_name)
            top_size=25 if units<=28 else (22 if units<=38 else (19 if units<=50 else 16))
            if self["current_channel_top"].instance is not None:self["current_channel_top"].instance.setFont(gFont("Regular",top_size))
        except Exception as exc:optional_failure("ui.live_top_title_font",exc)
        palette=self._live_palette_source_for_item(item,self.index)
        self._schedule_live_chrome(palette,item=item,slot=self.index)

    def _live_nav_total(self):
        try:return max(len(self.grid_items or []),int(self._portal_total or 0))
        except Exception:return len(self.grid_items or [])

    def _live_nav_absolute(self):
        return max(0,(int(self.page or 1)-1)*int(self.page_size or 1)+int(self.index or 0))

    def _live_nav_go_absolute(self,absolute):
        total=self._live_nav_total()
        if total<=0:return
        absolute=max(0,min(total-1,int(absolute)))
        target_page=absolute//self.page_size+1
        target_index=absolute%self.page_size
        if target_page==self.page and self.grid_items:
            self.index=min(target_index,max(0,len(self.grid_items)-1))
            self._update_selection();self._update_page_counter()
        else:
            self.load_page(target_page,target_index)

    def move_up(self):
        """Exact Mini List rule: previous item globally; #1 wraps to final channel."""
        if not self.grid_items or not self._nav_allowed():return
        total=self._live_nav_total()
        if total<=0:return
        current=self._live_nav_absolute()
        self._live_nav_go_absolute((current-1)%total)

    def move_down(self):
        """Exact Mini List rule: next item globally; final channel wraps to #1."""
        if not self.grid_items or not self._nav_allowed():return
        total=self._live_nav_total()
        if total<=0:return
        current=self._live_nav_absolute()
        self._live_nav_go_absolute((current+1)%total)

    def _live_page_shift(self,direction):
        """Exact Mini List LEFT/RIGHT page rule with the same row preserved."""
        if not self.grid_items or not self._nav_allowed():return
        total=self._live_nav_total()
        if total<=0:return
        page_size=max(1,int(self.page_size or 1))
        current_abs=self._live_nav_absolute()
        current_page=current_abs//page_size
        row=current_abs%page_size
        last_page=max(0,(total-1)//page_size)

        if int(direction)<0:
            if current_page<=0:
                target=0
            else:
                target=(current_page-1)*page_size+row
        else:
            if current_page>=last_page:
                target=total-1
            else:
                target=min(total-1,(current_page+1)*page_size+row)
        self._live_nav_go_absolute(target)

    def move_left(self):
        self._live_page_shift(-1)

    def move_right(self):
        self._live_page_shift(1)

    def open_selected(self):
        if self._busy or not self.grid_items:return
        item=self.grid_items[self.index];key=self._preview_key(item)
        if self._active_preview_key==key and self._active_preview_url:
            self._open_preview_fullscreen(item)
        elif key and key==getattr(self,"_last_fullscreen_key",""):
            # Returning to the same folder/channel should not force the viewer
            # through Preview again. Resolve a fresh link and go straight back
            # to Full Screen.
            self._open_direct_fullscreen(item)
        else:
            self._start_preview_request(item)

    def _open_direct_fullscreen(self,item):
        if not isinstance(item,dict) or self._screen_closed:return
        self._preview_token+=1;token=self._preview_token;self._cancel_preview_request()
        self["preview_status"].setText(_("Opening channel..."));self["tech4"].setText(_("Opening..."))
        def work():return self.client.create_link(item,"itv")
        def ok(url):
            if token!=self._preview_token or self._screen_closed:return
            if not isinstance(url,str) or not url.strip():
                self["preview_status"].setText(_("Channel unavailable"));self["tech4"].setText(_("OK Preview"));return
            cfg=load_settings();engine=_configured_playback_engine(cfg)
            self._launch_live_fullscreen(item,url.strip(),engine,False)
        def fail(err):
            if token==self._preview_token:
                self["preview_status"].setText(_("Channel unavailable"));self["tech4"].setText(_("OK Preview"))
        try:
            handle=TASKS.submit(work,self._preview_jobs,ok=ok,fail=fail);self._preview_handle=handle;self._preview_task_id=getattr(handle,"task_id",None) if handle is not None else None
        except Exception:fail(None)

    def _start_preview_request(self,item):
        if not isinstance(item,dict) or self._screen_closed:return
        self._preview_token+=1;token=self._preview_token;self._cancel_preview_request();key=self._preview_key(item);self._pending_preview_key=key
        self["preview_status"].setText(_("Loading preview..."));self["tech4"].setText(_("Loading..."))
        def work():return self.client.create_link(item,"itv")
        def ok(url):
            if token!=self._preview_token or self._screen_closed:return
            if not isinstance(url,str) or not url.strip():
                self._pending_preview_key=None;self["preview_status"].setText(_("Preview unavailable"));self["tech4"].setText(_("OK Preview"));return
            self._begin_preview_video(url.strip(),item,key)
        def fail(err):
            if token==self._preview_token:
                self._pending_preview_key=None
                try:self["preview_status"].setText(_("Preview unavailable"));self["tech4"].setText(_("OK Preview"))
                except Exception as exc:optional_failure("ui",exc)
        try:
            handle=TASKS.submit(work,self._preview_jobs,ok=ok,fail=fail);self._preview_handle=handle;self._preview_task_id=getattr(handle,"task_id",None) if handle is not None else None
        except Exception:fail(None)

    def _preview_main_engines(self,url):
        cfg=load_settings()
        try:engine=int(cfg.get("service_type",4097))
        except Exception:engine=4097
        if engine not in (1,4097,5001,5002,8193):engine=4097
        return [engine]


    def _begin_preview_video(self,url,item,key):
        self._preview_restore_state=(self._active_preview_key,self._active_preview_url,self._active_preview_item,self._active_preview_engine)
        self._preview_pending_url=url;self._preview_pending_item=dict(item);self._pending_preview_key=key;self._preview_engine_candidates=self._preview_main_engines(url);self._preview_engine_pos=0
        self._try_preview_engine()

    def _try_preview_engine(self):
        try:self._preview_ready_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        if self._screen_closed:return
        if self._preview_engine_pos>=len(self._preview_engine_candidates):self._preview_failed_restore();return
        engine=self._preview_engine_candidates[self._preview_engine_pos];self._preview_engine_pos+=1;self._preview_pending_engine=engine;self._preview_poll_count=0
        url=self._preview_pending_url or "";item=self._preview_pending_item or {}
        try:
            ref=eServiceReference(int(engine),0,url);ref.setName(str(item.get("name") or item.get("title") or "Live preview"))
            result=self.session.nav.playService(ref)
            if result is False:raise RuntimeError("engine %s rejected preview"%engine)
            self._main_preview_reference=ref
            self["preview_status"].setText(_("Starting preview..."))
            try:LOG.info("Live preview Pig/decoder0 start engine=%s",engine)
            except Exception as exc:optional_failure("ui",exc)
            self._preview_ready_timer.start(250,True)
        except Exception as exc:
            try:LOG.exception("Live preview decoder0 start failed: %s",exc)
            except Exception as exc:optional_failure("ui",exc)
            self._try_preview_engine()

    @staticmethod
    def _read_decoder_dimension(path):
        try:
            raw=open(path,"r").read().strip().lower()
            if not raw:return 0
            if raw.startswith("0x"):raw=raw[2:]
            try:return int(raw,16)
            except Exception:return int(raw,10)
        except Exception:return 0

    def _main_video_size(self):
        width=height=0
        try:
            current=self.session.nav.getCurrentlyPlayingServiceReference()
            if current is None:return 0,0
            service=self.session.nav.getCurrentService();info=service and service.info()
            if info is not None:
                width=int(info.getInfo(iServiceInformation.sVideoWidth) or 0);height=int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
        except Exception:width=height=0
        if width<=0 or height<=0:
            for base in ("/proc/stb/vmpeg/0","/proc/stb/video/0"):
                w=self._read_decoder_dimension(base+"/xres");h=self._read_decoder_dimension(base+"/yres")
                if w>0 and h>0:width,height=w,h;break
        return width,height

    def _check_preview_ready(self):
        if self._screen_closed:return
        width,height=self._main_video_size()
        current_ok=False
        try:
            cur=self.session.nav.getCurrentlyPlayingServiceReference()
            current_ok=(cur is not None and self._main_preview_reference is not None and cur.toString()==self._main_preview_reference.toString())
        except Exception:current_ok=False
        if current_ok and width>0 and height>0:
            key=self._pending_preview_key;item=self._preview_pending_item or {};url=self._preview_pending_url or ""
            self._active_preview_key=key;self._active_preview_url=url;self._active_preview_item=dict(item);self._active_preview_engine=self._preview_pending_engine
            self._pending_preview_key=None;self._preview_pending_url=None;self._preview_pending_item=None;self._preview_restore_state=None
            self["preview_status"].setText("");current=self.grid_items[self.index] if self.grid_items else {}
            self["tech4"].setText(_("OK Full Screen") if self._preview_key(current)==self._active_preview_key else _("OK Preview"))
            try:LOG.info("Live preview Pig/decoder0 ready %sx%s",width,height)
            except Exception as exc:optional_failure("ui",exc)
            return
        self._preview_poll_count+=1
        if self._preview_poll_count<24:self._preview_ready_timer.start(250,True);return
        try:LOG.warning("Live preview Pig/decoder0 engine %s never reported video",self._preview_pending_engine)
        except Exception as exc:optional_failure("ui",exc)
        self._try_preview_engine()

    def _preview_failed_restore(self):
        # Deterministic preview: one start attempt for the requested channel.
        # Never recreate the previous decoder/service automatically when a new
        # preview fails; repeated hidden restore cycles were visible in dmesg as
        # VIDEO_STOP/VIDEO_PLAY churn and can leak Broadcom native memory.
        self._pending_preview_key=None
        failed_url=self._preview_pending_url or ""
        self._preview_pending_url=None;self._preview_pending_item=None;self._preview_pending_engine=None
        self._preview_restore_state=None;self._main_preview_reference=None
        self._preview_engine_candidates=[];self._preview_engine_pos=0
        self["preview_status"].setText(_("Preview unavailable"));self["tech4"].setText(_("OK Preview"))
        try:force_session_silence(self.session,failed_url,force=True)
        except Exception as exc:optional_failure("ui.preview_failed_stop",exc)


    def _open_preview_fullscreen(self,item):
        url=self._active_preview_url
        if not url:return self._start_preview_request(item)
        cfg=load_settings();engine=_configured_playback_engine(cfg)
        self._launch_live_fullscreen(item,url,engine,True)

    def _launch_live_fullscreen(self,item,url,engine,reuse_current):
        name=str(item.get("name") or item.get("title") or "Live channel")
        add_recently_played(self.profile,"itv",item)
        key=self._preview_key(item);selected_index=self.index
        self._last_fullscreen_key=key
        try:
            _state=dict(_GRID_NAV_STATE.get(self._session_nav_key,{}) or {})
            _state["last_fullscreen_key"]=key
            _GRID_NAV_STATE[self._session_nav_key]=_state
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        def returned(result=None):
            if self._screen_closed:return

            # UltraStalkerPlayer EXIT already hard-stops the owned IPTV service
            # and restores the receiver service captured at the plugin boundary.
            # Do NOT call force_session_silence() here: its native stop would kill
            # that just-restored TV service. Do NOT auto-start the portal preview
            # either: that was recreating the fullscreen channel behind the UI,
            # leaving its audio alive until another service replaced it.
            self._main_preview_reference=None
            self._active_preview_key=None;self._active_preview_url=None;self._active_preview_item=None;self._active_preview_engine=None
            self._pending_preview_key=None;self._preview_pending_url=None;self._preview_pending_item=None
            self._preview_pending_engine=None;self._preview_engine_candidates=[];self._preview_engine_pos=0
            self["preview_status"].setText("");self["tech4"].setText(_("OK Preview"))
            self.index=max(0,min(selected_index,len(self.grid_items)-1)) if self.grid_items else 0

            # The restored receiver TV remains the service shown by the Pig/video
            # window. Rebind all Ultra Stalker adaptive/glass layers around it.
            try:self._force_live_visual_rebind()
            except Exception as exc:optional_failure("ui.live_return_chrome",exc)
        payload=_player_payload(item,self.profile,media_type="itv")
        snapshot=[dict(x) for x in list(self.grid_items or []) if isinstance(x,dict)]
        absolute_index=max(0,(int(self.page)-1)*int(self.page_size)+int(selected_index))
        payload["_live_folder_channels"]=snapshot
        payload["_live_absolute_index"]=absolute_index
        payload["_live_folder_total"]=int(self._portal_total or len(snapshot))
        payload["_live_page_size"]=int(self.page_size)
        payload["_live_folder_page"]=int(self.page)
        payload["_live_folder_title"]=str(self.category_title or "Live Channels")
        payload["_live_page_loader"]=self._grid_page_data
        payload["_live_client_ref"]=self.client
        self.session.openWithCallback(returned,UltraStalkerPlayer,url,name,"itv",engine,payload,bool(reuse_current))

    def _stop_live_preview(self):
        try:self._preview_ready_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._preview_ready_conn is not None:self._preview_ready_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._check_preview_ready in self._preview_ready_timer.callback:self._preview_ready_timer.callback.remove(self._check_preview_ready)
        except Exception as exc:optional_failure("ui.preview_timer_callback",exc)
        preview_url=self._active_preview_url or self._preview_pending_url or ""
        self._preview_token+=1;self._cancel_preview_request()
        self._main_preview_reference=None
        self._active_preview_key=None;self._active_preview_url=None;self._active_preview_item=None;self._active_preview_engine=None
        try:force_session_silence(self.session,preview_url,force=True)
        except Exception as exc:optional_failure("ui.preview_close_stop",exc)


