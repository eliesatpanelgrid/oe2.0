# -*- coding: utf-8 -*-
"""Fresh Backdrop Grid presentation.

Built on the current 6.5.60 Poster Grid catalogue/navigation/artwork stack only.
No legacy Backdrop-Grid module, package, cache schema, or old title-logo path is
used here.  The reference is visual only.
"""
from __future__ import absolute_import
import threading
import hashlib, json, os, queue, re, time, weakref, tempfile, urllib.parse, gc, shutil
try:
    from PIL import Image as _PILImage, ImageDraw as _ImageDraw
except Exception:
    _PILImage=None; _ImageDraw=None
from .core.executor import LazyThreadPoolExecutor
from twisted.internet import reactor
from twisted.web.client import Agent, readBody
from twisted.web.http_headers import Headers
try:
    from twisted.web.client import BrowserLikePolicyForHTTPS
    _bd_title_logo_contextFactory = BrowserLikePolicyForHTTPS()
except ImportError:
    from twisted.web.client import WebClientContextFactory
    _bd_title_logo_contextFactory = WebClientContextFactory()
try:
    from enigma import ePoint, eSize, gFont
except Exception:
    ePoint=eSize=gFont=None

from .ui_grid_screens import PremiumPosterGridScreen
from .ui_cinematic_global import (
    PremiumGlobalCinematicScreen,
    _build_cinematic_backdrop,
    _quality_asset_name,
)
from .artwork_v2 import ArtworkV2, load_manifest, identity_cache_compatible
from .tmdb import TMDBClient
from .fanart import fetch_artwork as _fanart_fetch
from .persistent_cache import GENERATED, load_detail_snapshot, load_detail_snapshot_by_tmdb, save_detail_snapshot
from .storage import load_settings, load_api_keys
from .ui_artwork_helpers import _strip_portal_artwork
from .ui_dynamic_palette import _dynamic_palette
from .ui_helpers import _lift_dynamic_accent
from .title_clean import catalogue_title as _catalogue_title
from .log import optional_failure
from . import _

BACKDROP_GRID_SKIN = ""
_BG_EXECUTOR = LazyThreadPoolExecutor(max_workers=1, thread_name_prefix="ultrastalker-backdrop-grid")
_BG_LOGO_EXECUTOR = LazyThreadPoolExecutor(max_workers=1, thread_name_prefix="ultrastalker-backdrop-logo")
_BG_FOCUS_EXECUTOR = LazyThreadPoolExecutor(max_workers=1, thread_name_prefix="ultrastalker-backdrop-focus")


def configure_backdrop_grid(**deps):
    globals().update(deps)
    if "BACKDROP_GRID_SKIN" in deps:
        PremiumBackdropGridScreen.skin = deps["BACKDROP_GRID_SKIN"]


def _valid_file(path):
    try:
        return bool(path and os.path.isfile(str(path)) and os.path.getsize(str(path)) > 256)
    except Exception:
        return False


def _first_text(*values):
    for value in values:
        if isinstance(value, (list, tuple)):
            value = ", ".join(str(x) for x in value if x not in (None, ""))
        text = str(value or "").strip()
        if text:
            return text
    return ""


def _hex_rgb(value, fallback=(105,201,244)):
    value=str(value or "").strip().lstrip("#")
    if len(value)==6:
        try:return tuple(int(value[i:i+2],16) for i in (0,2,4))
        except Exception:pass
    return fallback


def _nine_slice(source, target, size):
    try:
        if _PILImage is None or not source or not os.path.isfile(source):return ""
        if os.path.isfile(target) and os.path.getsize(target)>256:return target
        tw,th=int(size[0]),int(size[1])
        with _PILImage.open(source) as im:
            im=im.convert("RGBA");sw,sh=im.size
            cx=max(8,min(34,sw//5,tw//5));cy=max(7,min(20,sh//4,th//4))
            left=right=cx;top=bottom=cy
            canvas=_PILImage.new("RGBA",(tw,th),(0,0,0,0))
            sx=(0,left,sw-right,sw);sy=(0,top,sh-bottom,sh)
            dx=(0,left,tw-right,tw);dy=(0,top,th-bottom,th)
            res=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
            for yi in range(3):
                for xi in range(3):
                    tile=im.crop((sx[xi],sy[yi],sx[xi+1],sy[yi+1]))
                    out_size=(dx[xi+1]-dx[xi],dy[yi+1]-dy[yi])
                    if tile.size!=out_size:tile=tile.resize(out_size,res)
                    canvas.alpha_composite(tile,(dx[xi],dy[yi]))
            parent=os.path.dirname(target)
            if parent and not os.path.isdir(parent):os.makedirs(parent)
            tmp=target+".tmp.%s"%os.getpid();canvas.save(tmp,"PNG",compress_level=1);os.replace(tmp,target)
        return target
    except Exception as exc:
        optional_failure("backdrop_grid.nine_slice",exc);return ""


def _mood_overlay(target, accent_hex):
    try:
        if _PILImage is None:return ""
        if os.path.isfile(target) and os.path.getsize(target)>256:return target
        rgb=_hex_rgb(accent_hex);w,h=1920,460
        canvas=_PILImage.new("RGBA",(w,h),(0,0,0,0))
        if _ImageDraw is not None:
            draw=_ImageDraw.Draw(canvas)
            for y in range(h):
                t=float(y)/max(1,h-1);a=int(8+38*(t*t))
                draw.line((0,y,w,y),fill=(rgb[0],rgb[1],rgb[2],a))
        parent=os.path.dirname(target)
        if parent and not os.path.isdir(parent):os.makedirs(parent)
        tmp=target+".tmp.%s"%os.getpid();canvas.save(tmp,"PNG",compress_level=1);os.replace(tmp,target)
        return target
    except Exception as exc:
        optional_failure("backdrop_grid.mood",exc);return ""


def _bd_logo_trace(event, **fields):
    """Tiny credential-free trace for the remaining stubborn title-logo cases."""
    try:
        payload={"ts":int(time.time()),"event":str(event or "")[:64]}
        for key,value in fields.items():
            if value is None:payload[str(key)[:48]]=None
            elif isinstance(value,(bool,int,float)):payload[str(key)[:48]]=value
            else:payload[str(key)[:48]]=str(value)[:240]
        with open("/tmp/UltraStalker_title_logo_trace.log","a",encoding="utf-8") as h:
            h.write(json.dumps(payload,ensure_ascii=False,separators=(",",":"))+"\n")
        try:os.chmod("/tmp/UltraStalker_title_logo_trace.log",0o600)
        except Exception:pass
    except Exception:
        pass


class PremiumBackdropGridScreen(PremiumPosterGridScreen):
    # release shared BLUE artwork completion. Backdrop Grid seals the same
    # persistent artwork-ready marker Cinematic understands, without touching
    # Cinematic rendering/package generation.
    def _shared_blue_lock_path(self,item):
        try:
            key=str(self._page_visual_key(item) or "").strip()
            if not key:return ""
            safe=re.sub(r"[^A-Za-z0-9._-]+","_",key)[:160]
            if not safe:
                safe=hashlib.sha1(key.encode("utf-8","ignore")).hexdigest()[:24]
            return os.path.join(GENERATED,"cinematic_blue_ready_%s.json"%safe)
        except Exception:return ""

    def _folder_artwork_ready_hook(self,item,data):
        row=dict(data or {}) if isinstance(data,dict) else {}
        poster=str(row.get("poster_local") or "")
        backdrop=str(row.get("backdrop_local") or "")
        try:
            from .artwork_v2 import _valid_backdrop
            ready=bool(poster and os.path.isfile(poster) and os.path.getsize(poster)>512 and _valid_backdrop(backdrop))
        except Exception:
            ready=False
        if not ready:return False
        path=self._shared_blue_lock_path(item)
        if not path:return True
        try:
            old={}
            if os.path.isfile(path):
                with open(path,"r",encoding="utf-8") as h:old=json.load(h)
            if isinstance(old,dict) and int(old.get("schema") or 0) in (1,2,3):
                files=old.get("files") or []
                if files and all(os.path.isfile(str(x or "")) and os.path.getsize(str(x or ""))>256 for x in files):
                    return True
        except Exception:pass
        try:
            os.makedirs(os.path.dirname(path),exist_ok=True)
            payload={"schema":2,"visual_key":self._page_visual_key(item),"files":[poster,backdrop],"sealed_at":int(time.time())}
            temp=path+".tmp.%d"%os.getpid()
            with open(temp,"w",encoding="utf-8") as h:
                json.dump(payload,h,ensure_ascii=False,separators=(",",":"))  # rebuildable cache seal: atomic rename is sufficient
            os.replace(temp,path)
        except Exception as exc:
            optional_failure("backdrop.shared_blue_lock_write",exc)
        return True

    def _folder_artwork_finalize_hook(self,item,poster,backdrop,payload,data,cancel_event=None):
        if cancel_event is not None and cancel_event.is_set():return False
        row=dict(data or {}) if isinstance(data,dict) else {}
        if poster and os.path.isfile(str(poster)):row["poster_local"]=str(poster)
        if backdrop and os.path.isfile(str(backdrop)):row["backdrop_local"]=str(backdrop)
        return bool(self._folder_artwork_ready_hook(item,row))
    """One-row poster rail over a current-title adaptive backdrop."""

    skin = BACKDROP_GRID_SKIN
    columns = 8
    page_size = 8
    image_size = (206, 310)
    selection_asset = "poster_card_selected_neutral_small.png"
    card_positions = [(51 + (230 * i), 708) for i in range(8)]

    def __init__(self, session, profile, client, media_type, genre, category_title=""):
        self._bd_jobs = queue.Queue()
        self._bd_token = 0
        self._bd_applied_key = ""
        self._bd_logo_path = ""
        self._bd_closed = False
        self._bd_visual_cache = {}
        self._bd_hud_cache = {}
        self._bd_logo_attempted = set()
        self._bd_pixmap_paths = {}
        # release: once adaptive info chrome is visible, keep it painted while
        # focus moves. The next title replaces it atomically when ready; never
        # flash back to neutral boxes between LEFT/RIGHT presses.
        self._bd_hud_adaptive_active = False
        self._bd_hud_pending = {}
        self._bd_focus_pending = {}
        self._bd_focus_cancel = None
        self._bd_focus_cancel_key = ""
        self._bd_selection_source = ""
        # release: exact Details/XStreamity title-logo transport lives on
        # Backdrop Grid itself.  Movies no longer have a Details screen, so the
        # outside page must own the same request/cache lifecycle directly.
        self._bd_title_logo_token = 0
        self._bd_title_logo_sig = ""
        self._bd_title_logo_deferred = None
        self._bd_title_logo_tmp = None
        self._bd_title_logo_cache_target = ""
        self._bd_title_logo_agent = Agent(reactor, contextFactory=_bd_title_logo_contextFactory)
        PremiumPosterGridScreen.__init__(self, session, profile, client, media_type, genre, category_title)
        # release: Backdrop Grid already owns a full-HD surface plus eight cards.
        # Retaining fourteen decoded poster gPixmaps is unnecessary once BLUE has
        # prepared persistent 206x310 thumbs. Keep only a tiny local decode cache
        # so page flips cannot exhaust the Broadcom accelerated surface pool.
        try:self._grid_decode_cache_limit=2
        except Exception:pass

        # New page-owned surfaces.  Poster cards/navigation remain the current
        # Poster Grid implementation inherited above.
        self["bd_backdrop"] = Pixmap()
        self["bd_bottom_mood"] = Pixmap()
        self["title_logo"] = Pixmap()
        self["bd_title_fallback"] = Label("")
        self["bd_year"] = Label("")
        self["bd_quality"] = Label("")
        self["bd_quality_logo"] = Pixmap()
        self["bd_runtime_icon"] = Pixmap()
        self["bd_runtime"] = Label("")
        self["bd_country"] = Label("")
        self["bd_genre"] = Label("")
        self["bd_overview"] = Label("")
        self["bd_year_bg"] = Pixmap(); self["bd_quality_bg"] = Pixmap(); self["bd_runtime_bg"] = Pixmap(); self["bd_country_bg"] = Pixmap(); self["bd_genre_bg"] = Pixmap(); self["bd_overview_bg"] = Pixmap()

        self.onLayoutFinish.append(self._bd_apply_default_premium_hud)
        self.onLayoutFinish.append(self._bd_force_geometry)
        self.onClose.append(self._stop_backdrop_grid)
        try:
            self["red"].setText(_("Search")); self["green"].setText(_("Favorite")); self["yellow"].setText(_("Default")); self["blue"].setText(_("Check Artwork"))
        except Exception:
            pass
        # Backdrop Grid keeps the proven continuous LEFT/RIGHT rail. UP/DOWN now
        # move by one full rail page while preserving the current poster column.
        # This adds vertical remote navigation without changing rendering, cache,
        # title-logo handoff, direct-play, or Cinematic behavior.
        try:
            self["actions"] = ActionMap(["OkCancelActions","ColorActions","DirectionActions","MenuActions","InfoActions"], {
                "cancel":self.close,"red":self.open_folder_search,"ok":self.open_selected,
                "left":self._bd_move_left,"right":self._bd_move_right,
                "up":self._bd_move_up,"down":self._bd_move_down,
                "green":self.toggle_selected_favorite,"yellow":self.cycle_folder_sort,
                "blue":self.cache_folder_artwork,"menu":self.open_menu,"info":self.show_information},-1)
        except Exception as exc:
            optional_failure("backdrop_grid.actions",exc)

    def open_selected(self):
        """Backdrop Movies play directly; Series retain the existing Details route."""
        if self.media_type=="vod":
            return PremiumGlobalCinematicScreen.open_selected(self)
        return PremiumPosterGridScreen.open_selected(self)

    def _bd_set_pixmap_file(self, name, path, show=True, release_first=True):
        """Set one Backdrop-owned pixmap with a strict native-surface budget.

        Broadcom/OpenBH may need room for the new gPixmap before the old one is
        reclaimed.  Releasing first avoids a transient double-allocation and the
        gAccel/Nexus failure seen while rapidly changing folders.  Reusing the
        same path is a no-op so static HUD chrome is not decoded on every focus.
        """
        path=str(path or "")
        if not _valid_file(path):
            return False
        try:
            widget=self[name]
            if self._bd_pixmap_paths.get(name)==path:
                if show:widget.show()
                return True
            inst=widget.instance
            if inst is None:return False
            if release_first:
                try:inst.setPixmap(None)
                except Exception:pass
            inst.setPixmapFromFile(path)
            self._bd_pixmap_paths[name]=path
            if show:widget.show()
            return True
        except Exception as exc:
            self._bd_pixmap_paths.pop(name,None)
            optional_failure("backdrop_grid.set_pixmap",exc)
            return False

    def _bd_release_owned_pixmaps(self):
        """Drop every native gPixmap owned only by Backdrop Grid immediately."""
        names=(
            "bd_backdrop","bd_bottom_mood","title_logo","bd_quality_logo","bd_runtime_icon",
            "bd_year_bg","bd_quality_bg","bd_runtime_bg","bd_country_bg",
            "bd_genre_bg","bd_overview_bg"
        )
        for name in names:
            try:
                widget=self[name]
                try:widget.hide()
                except Exception:pass
                if widget.instance is not None:widget.instance.setPixmap(None)
            except Exception:pass
        self._bd_pixmap_paths.clear()
        self._bd_logo_path=""
        self._bd_applied_key=""
        self._bd_hud_adaptive_active=False

    def _bd_apply_default_premium_hud(self):
        """Paint neutral glass only before the first adaptive HUD exists.

        V6.5.93 intentionally keeps the previous title's adaptive boxes alive
        while the next title is resolving. This mirrors the persistent adaptive
        selector: no neutral flash, no hide/show blink between focus changes.
        """
        if getattr(self,"_bd_hud_adaptive_active",False):
            return
        mapping = {
            "bd_year_bg": "us6571_bd_year_130x50.png",
            "bd_quality_bg": "us6571_bd_quality_150x50.png",
            "bd_runtime_bg": "us6571_bd_runtime_150x50.png",
            "bd_genre_bg": "us6571_bd_genre_440x50.png",
            "bd_overview_bg": "us6571_bd_overview_440x232.png",
        }
        for widget, filename in mapping.items():
            try:
                path = asset(filename)
                if _valid_file(path):
                    self._bd_set_pixmap_file(widget,path,show=True,release_first=True)
            except Exception as exc:
                optional_failure("backdrop_grid.default_hud", exc)

    def _bd_pin_counter_status(self):
        if ePoint is None or eSize is None:
            return
        try:
            for name,x,y,w,h in (("page_label",55,680,470,28),("status",650,680,620,28)):
                inst=self[name].instance
                if inst is not None:
                    inst.move(ePoint(x,y));inst.resize(eSize(w,h))
        except Exception as exc:
            optional_failure("backdrop_grid.pin_counter",exc)

    def _fit_poster_live_hud(self):
        """Backdrop Grid owns its counter/status geometry.

        The inherited Poster Grid asynchronously reapplies its floating HUD chrome
        after focus changes and used to move page_label back over the poster rail.
        Keep only the Backdrop Grid pin here so no delayed callback can undo it.
        """
        self._bd_pin_counter_status()

    def _update_page_counter(self):
        # Base writes the text only; this page owns the geometry permanently.
        try:
            PremiumPosterGridScreen._update_page_counter(self)
        finally:
            self._bd_pin_counter_status()

    def _update_selection(self):
        # Re-pin the full rail before every focus paint so inherited grid geometry
        # can never split the poster from its chrome/text or selector.
        self._bd_force_geometry()
        PremiumPosterGridScreen._update_selection(self)
        # Backdrop Grid owns ONE selector only: the adaptive poster-sized overlay.
        # Never leave the inherited tall/blue selector visible behind it.
        try:
            self["selection"].hide()
            if self["selection"].instance is not None:self["selection"].instance.setPixmap(None)
        except Exception:pass
        self._bd_pin_counter_status()

    def _bd_total(self):
        try:return max(len(self.grid_items or []), int(self._active_total() or 0))
        except Exception:return len(self.grid_items or [])

    def _bd_absolute(self):
        return max(0, (int(self.page or 1)-1)*int(self.page_size or 1) + int(self.index or 0))

    def _bd_go_absolute(self, absolute):
        total=self._bd_total()
        if total<=0:return
        absolute=int(absolute)%total
        target_page=absolute//self.page_size+1
        target_index=absolute%self.page_size
        if target_page==int(self.page or 1) and self.grid_items:
            self.index=min(target_index,max(0,len(self.grid_items)-1))
            self._update_selection();self._update_page_counter()
        else:
            self.load_page(target_page,target_index)

    def _bd_move_right(self):
        if not self.grid_items or not self._nav_allowed():return
        total=self._bd_total()
        if total<=0:return
        self._bd_go_absolute((self._bd_absolute()+1)%total)

    def _bd_move_left(self):
        if not self.grid_items or not self._nav_allowed():return
        total=self._bd_total()
        if total<=0:return
        self._bd_go_absolute((self._bd_absolute()-1)%total)

    def _bd_move_up(self):
        """Move up one rail page with page-edge wrapping from any poster.

        UP preserves the current poster column.  On the first page, pressing UP
        from *any* poster jumps to the last page in the same column; if the last
        page is short, focus clamps to its final available poster.  This makes
        the vertical loop consistent across the whole rail instead of only the
        first catalogue item.
        """
        if not self.grid_items or not self._nav_allowed():return
        total=self._bd_total()
        if total<=0:return
        page_size=max(1,int(self.page_size or 1))
        current_page=max(1,int(self.page or 1))
        current_index=max(0,int(self.index or 0))
        if current_page<=1:
            total_pages=max(1,(total+page_size-1)//page_size)
            if total_pages<=1:return
            last_page_start=(total_pages-1)*page_size
            target=min(last_page_start+current_index,total-1)
            self._bd_go_absolute(target)
            return
        current=self._bd_absolute()
        self._bd_go_absolute(max(0,current-page_size))

    def _bd_move_down(self):
        """Move down one rail page with page-edge wrapping from any poster.

        DOWN preserves the current poster column.  A short next/last page clamps
        to the nearest available poster.  When already on the last page, DOWN
        from *any* poster jumps to the first page in the same column, completing
        the smart vertical loop across the whole screen.
        """
        if not self.grid_items or not self._nav_allowed():return
        total=self._bd_total()
        if total<=0:return
        page_size=max(1,int(self.page_size or 1))
        current_page=max(1,int(self.page or 1))
        current_index=max(0,int(self.index or 0))
        next_page_start=current_page*page_size
        if next_page_start>=total:
            if total<=page_size:return
            target=min(current_index,total-1)
            self._bd_go_absolute(target)
            return
        target=min(next_page_start+current_index,total-1)
        self._bd_go_absolute(target)

    def _stop_backdrop_grid(self):
        self._bd_closed = True
        cancel=getattr(self,"_bd_focus_cancel",None)
        if cancel is not None:
            try:cancel.set()
            except Exception:pass
        self._bd_focus_cancel=None;self._bd_focus_cancel_key=""
        self._bd_token += 1
        self._bd_title_logo_token += 1
        try:
            if self._bd_title_logo_deferred is not None and not getattr(self._bd_title_logo_deferred,"called",False):
                self._bd_title_logo_deferred.cancel()
        except Exception:
            pass
        self._bd_title_logo_deferred=None
        self._bd_safe_unlink_title_logo(self._bd_title_logo_tmp);self._bd_title_logo_tmp=None
        self._bd_visual_cache.clear()
        self._bd_hud_cache.clear()
        self._bd_logo_attempted.clear()
        self._bd_hud_pending.clear()
        self._bd_focus_pending.clear()
        # Base Poster Grid releases its own cards first; Backdrop owns several
        # additional full/large surfaces, so release them explicitly as well.
        self._bd_release_owned_pixmaps()
        try:
            while True:
                self._bd_jobs.get_nowait()
        except Exception:
            pass

    def _render_grid(self):
        """Release the previous rail page before decoding the next one.

        The 6.5.87 crash log shows repeated gAccel/accelAlloc failures while
        ePicLoad was decoding canonical movie_*.jpg posters.  Do not overlap an
        old page of eight poster/card native surfaces with a new page.  Persistent
        BLUE thumbs make the redraw cheap, so stability wins over retaining stale
        decoded gPixmaps.
        """
        try:
            for pos in range(int(getattr(self,"page_size",8) or 8)):
                for name in ("art%d"%pos,"card_chrome%d"%pos):
                    try:
                        widget=self[name]
                        if widget.instance is not None:widget.instance.setPixmap(None)
                    except Exception:pass
            try:self._grid_decode_cache.clear()
            except Exception:pass
            # Clear only in-process native pixmap references. This does NOT call
            # Linux drop_caches and never touches the persistent HDD artwork.
            try:_native_image_pressure_relief(force=True)
            except Exception:pass
        except Exception as exc:
            optional_failure("backdrop_grid.page_surface_release",exc)
        result=PremiumPosterGridScreen._render_grid(self)
        try:self._bd_apply_fixed_rail_chrome()
        except Exception as exc:optional_failure("backdrop_grid.fixed_rail_after_render",exc)
        return result

    def _bd_apply_fixed_rail_chrome(self):
        """V6.5.90: Backdrop cards stay neutral; only current selection is adaptive.

        One packaged frame is reused for every slot.  The fixed frame sits 4px outside
        the 206x310 poster on every side, so the border breathes instead of touching art.
        No per-title palette/card
        generation is allowed on this screen; title/year/quality already live in
        the page HUD above.
        """
        fixed=asset("poster_frame_neutral_214x318.png")
        fixed_pix = None
        try:
            fixed_pix = cached_png(fixed) if _valid_file(fixed) else None
        except Exception:
            fixed_pix = None
        for pos in range(int(getattr(self,"page_size",8) or 8)):
            try:
                self["item_title%d"%pos].setText("");self["item_title%d"%pos].hide()
                self["item_meta%d"%pos].setText("");self["item_meta%d"%pos].hide()
            except Exception:pass
            try:
                chrome=self["card_chrome%d"%pos]
                if pos < len(getattr(self,"grid_items",[]) or []):
                    if chrome.instance is not None:
                        if fixed_pix is not None:
                            chrome.instance.setPixmap(fixed_pix)
                        else:
                            chrome.instance.setPixmap(None)
                            chrome.instance.setPixmapFromFile(fixed)
                    chrome.show()
                else:
                    chrome.hide()
                    if chrome.instance is not None:chrome.instance.setPixmap(None)
            except Exception as exc:optional_failure("backdrop_grid.fixed_rail_chrome",exc)
        # Keep the one adaptive selector continuously visible across redraws.
        # Its position follows focus synchronously; its colour may update later.

    def _bd_selection_overlay_for_poster(self,path):
        """Return the Backdrop adaptive selector on the exact fixed-frame footprint.

        The neutral rail frame is 214x318, four pixels outside the 206x310
        poster on every side.  Focus must not grow/shrink the card, so the
        adaptive selector uses that exact geometry too.  Only the colour/glow
        changes, and the corners stay square like the fixed frame.
        """
        try:
            if not path or not os.path.isfile(path) or _PILImage is None or _ImageDraw is None:
                return ""
            try:
                st=os.stat(path);stamp="%s|%s"%(int(getattr(st,"st_mtime_ns",int(st.st_mtime*1e9))),int(st.st_size))
            except Exception:
                stamp=str(path)
            key=hashlib.sha1((str(path)+"|"+stamp+"|bdsel-square-214x318-v3").encode("utf-8","ignore")).hexdigest()[:20]
            target=os.path.join(THUMB_CACHE_DIR,"bdsel_%s_square_214x318_v3.png"%key)
            if _valid_file(target):return target

            primary,_secondary=_dynamic_palette(path)
            r,g,b=_lift_dynamic_accent(primary,0.60,0.58)
            canvas=_PILImage.new("RGBA",(214,318),(0,0,0,0))

            # Same strong adaptive lighting, but square and contained inside the
            # exact fixed 214x318 footprint so focus never changes card size.
            glow=_PILImage.new("RGBA",canvas.size,(0,0,0,0));gd=_ImageDraw.Draw(glow)
            gd.rectangle((6,6,207,311),outline=(r,g,b,248),width=11)
            try:
                from PIL import ImageFilter as _ImageFilter
                glow=glow.filter(_ImageFilter.GaussianBlur(6))
            except Exception:
                pass
            canvas=_PILImage.alpha_composite(canvas,glow)

            glow2=_PILImage.new("RGBA",canvas.size,(0,0,0,0));g2=_ImageDraw.Draw(glow2)
            g2.rectangle((4,4,209,313),outline=(min(255,r+42),min(255,g+42),min(255,b+42),236),width=7)
            try:
                from PIL import ImageFilter as _ImageFilter
                glow2=glow2.filter(_ImageFilter.GaussianBlur(3))
            except Exception:
                pass
            canvas=_PILImage.alpha_composite(canvas,glow2)

            d=_ImageDraw.Draw(canvas)
            core=(min(255,r+92),min(255,g+92),min(255,b+92),255)
            d.rectangle((1,1,212,316),outline=core,width=3)

            parent=os.path.dirname(target)
            if parent and not os.path.isdir(parent):os.makedirs(parent)
            tmp=target+".tmp.%s"%os.getpid();canvas.save(tmp,"PNG",optimize=True);os.replace(tmp,target)
            return target if _valid_file(target) else ""
        except Exception as exc:
            optional_failure("backdrop_grid.selection_overlay_square",exc);return ""

    def _grid_schedule_adaptive_selector(self, generation, slot, path):
        """Build adaptive colour ONLY for the currently focused poster.

        V6.5.90 keeps all eight cards fixed/neutral.  The selected poster gets
        one adaptive overlay; non-selected posters never generate or receive
        title-specific chrome.
        """
        if getattr(self,"media_type",None) not in ("vod","series") or slot != getattr(self,"index",-1):
            return
        if not path or not os.path.isfile(path):return
        token=(generation,slot,path,True)
        if token in self._grid_accent_pending:return
        self._grid_accent_pending.add(token)
        def worker():
            result=None
            try:result=self._bd_selection_overlay_for_poster(path)
            except Exception as exc:optional_failure("backdrop_grid.selection_adaptive_build",exc)
            try:self._grid_accent_jobs.put((generation,slot,path,result,None,None))
            except Exception as exc:optional_failure("backdrop_grid.selection_adaptive_queue",exc)
        try:_BG_EXECUTOR.submit(worker,_task_key="bd-selection:%x"%id(self),_replace_task_key=True)
        except Exception:self._grid_accent_pending.discard(token)

    def _grid_drain_adaptive_selector(self):
        changed=False
        while True:
            try:
                job=self._grid_accent_jobs.get_nowait();generation,slot,path,result=job[:4]
            except queue.Empty:break
            except Exception:break
            try:
                self._grid_accent_pending.discard((generation,slot,path,False))
                self._grid_accent_pending.discard((generation,slot,path,True))
            except Exception:pass
            if generation != self._grid_generation or slot != getattr(self,"index",-1):continue
            current=getattr(self,"_grid_palette_sources",{}).get(slot) or self._grid_slot_paths.get(slot)
            if current != path or not result:continue
            try:
                if result != getattr(self,"_grid_selection_adaptive_visual_path",""):
                    self["selection_adaptive"].instance.setPixmapFromFile(result)
                    self._grid_selection_adaptive_visual_path=result
                self["selection_adaptive"].show()
                try:
                    self["selection"].hide()
                    if self["selection"].instance is not None:self["selection"].instance.setPixmap(None)
                except Exception:pass
                self._bd_selection_source=path;changed=True
            except Exception as exc:optional_failure("backdrop_grid.selection_adaptive_apply",exc)
        return changed

    def _grid_apply_current_selector(self, allow_build=False):
        # release: one selector only, and it NEVER disappears during navigation.
        # The inherited/base selector stays disabled.  When focus moves before the
        # new adaptive colour is ready, keep the previous adaptive pixmap visible
        # at the new slot, then swap the colour in-place when the worker completes.
        try:
            self["selection"].hide()
            if self["selection"].instance is not None:self["selection"].instance.setPixmap(None)
            self._grid_selection_visual_path=""
        except Exception as exc:optional_failure("backdrop_grid.selector_base_hide",exc)
        slot=getattr(self,"index",0)
        path=getattr(self,"_grid_palette_sources",{}).get(slot) or self._grid_slot_paths.get(slot)
        have_visual=bool(getattr(self,"_grid_selection_adaptive_visual_path","") and
                         getattr(self["selection_adaptive"],"instance",None) is not None)
        if have_visual:
            try:self["selection_adaptive"].show()
            except Exception:pass
        if not path or not os.path.isfile(path):
            # Keep the current selector visible even while a poster path is still
            # settling.  Never blink the cursor off just because artwork is late.
            return
        if getattr(self,"_bd_selection_source","") == path and have_visual:
            return
        if allow_build:self._grid_schedule_adaptive_selector(self._grid_generation,slot,path)

    def _grid_schedule_page_mood(self,path):
        # Full-page mood from each poster is redundant on a Backdrop screen.
        return

    def _grid_drain_page_mood(self):
        try:
            while True:self._grid_mood_jobs.get_nowait()
        except Exception:pass
        return

    def _prepare_grid_page(self,*args,**kwargs):
        payload=PremiumPosterGridScreen._prepare_grid_page(self,*args,**kwargs)
        try:
            for row in (payload or {}).get("art",[]) or []:
                if isinstance(row,dict):row.pop("card",None)
        except Exception as exc:optional_failure("backdrop_grid.strip_prepared_card",exc)
        return payload

    def _bd_ready_hud_path(self,item,row):
        key=self._focus_key(item,row)
        safe=re.sub(r"[^A-Za-z0-9._-]+","_",str(key or ""))[:160]
        return os.path.join(GENERATED,"backdrop_grid_hud_ready_%s.json"%safe) if safe else ""

    def _bd_save_ready_hud(self,item,row,hud):
        if not isinstance(hud,dict) or not hud:return False
        path=self._bd_ready_hud_path(item,row)
        if not path:return False
        try:
            usable={k:str(v) for k,v in hud.items() if _valid_file(v)}
            if not usable:return False
            tmp=path+".tmp.%s"%os.getpid()
            with open(tmp,"w",encoding="utf-8") as h:json.dump(usable,h,separators=(",",":"))  # rebuildable HUD cache
            os.replace(tmp,path);return True
        except Exception as exc:optional_failure("backdrop_grid.ready_hud_save",exc);return False

    def _bd_load_ready_hud(self,item,row):
        path=self._bd_ready_hud_path(item,row)
        if not path or not os.path.isfile(path):return {}
        try:
            with open(path,"r",encoding="utf-8") as h:data=json.load(h)
            return {k:str(v) for k,v in (data or {}).items() if _valid_file(v)} if isinstance(data,dict) else {}
        except Exception as exc:optional_failure("backdrop_grid.ready_hud_load",exc);return {}

    def _record(self, item):
        """HDD/current-focus record shared with Details/Cinematic.

        V6.5.76 bridges the trusted in-memory TMDB identity produced by the
        selected-card poster hydrator.  Details already receives this identity
        on ``item`` as ``_locked_tmdb_id``; Backdrop Grid previously ignored it
        and therefore could not start title-logo resolution until Details had
        persisted a newer snapshot.
        """
        try:
            art = load_manifest(self.profile, self.media_type, item) or {}
            detail = load_detail_snapshot(self.profile, self.media_type, item) or {}
            if art.get("tmdb_id"):
                direct = load_detail_snapshot_by_tmdb(art.get("media_type") or self.media_type, art.get("tmdb_id")) or {}
                if direct:
                    merged = dict(detail); merged.update(direct); detail = merged
            row = dict(detail); row.update(art)

            # Selected-card hydration resolves identity before Details opens and
            # stores it on the live grid item.  Treat only the internal locked id
            # (or the matching grid item state) as authoritative here; never trust
            # a raw provider tmdb_id that has not passed ArtworkV2 verification.
            if not row.get("tmdb_id") and isinstance(item, dict):
                locked = item.get("_locked_tmdb_id")
                if not locked:
                    try: locked = (getattr(self, "_grid_item_state", {}) or {}).get(id(item), {}).get("tmdb_id")
                    except Exception: locked = None
                if locked:
                    row["tmdb_id"] = locked
                    row["media_type"] = item.get("_locked_tmdb_type") or row.get("media_type") or ("tv" if self.media_type == "series" else "movie")
            return row
        except Exception as exc:
            optional_failure("backdrop_grid.record", exc)
            return {}

    def _bd_details_identity_for_logo(self, item, row):
        """Use the shared Details Authority for the focused title."""
        row=dict(row or {})
        if row.get("tmdb_id") and row.get("_details_authority_ready"):return row
        try:
            from .details_authority import resolve_canonical
            resolved=resolve_canonical(self.profile,self.media_type,item,cancel_event=None,settings=(getattr(self,"_grid_settings",None) or load_settings())) or {}
            if resolved:
                merged=dict(row);merged.update(resolved)
                if isinstance(item,dict) and merged.get("tmdb_id"):
                    item["_locked_tmdb_id"]=merged.get("tmdb_id")
                    item["_locked_tmdb_type"]=merged.get("media_type") or ("tv" if self.media_type=="series" else "movie")
                return merged
        except Exception as exc:optional_failure("backdrop_grid.details_authority",exc)
        return row

    def _rail_title(self, item, row=None):
        row = row or {}
        # The catalogue-visible title owns language.  Foreign titles stay foreign
        # and Arabic titles stay Arabic, matching the current Details/Cinematic rule.
        return _first_text(
            item.get("name") if isinstance(item, dict) else "", item.get("title") if isinstance(item, dict) else "",
            row.get("title"), row.get("name"), row.get("original_title"), row.get("original_name")
        )

    def _format_runtime(self, value):
        try:
            minutes = int(float(value or 0))
            if minutes <= 0:
                return ""
            return "%dh %02dm" % (minutes // 60, minutes % 60) if minutes >= 60 else "%d min" % minutes
        except Exception:
            return ""

    def _quality(self, item, row):
        try:
            explicit = self._explicit_item_quality(item)
            if explicit:
                return explicit
        except Exception:
            pass
        text = _first_text(row.get("quality"), row.get("video_quality"))
        if text:
            return text[:12]
        raw = _first_text(item.get("name") if isinstance(item, dict) else "", item.get("title") if isinstance(item, dict) else "").upper()
        if "4K" in raw or "2160" in raw: return "4K"
        if "FHD" in raw or "1080" in raw: return "FHD"
        if "HD" in raw or "720" in raw: return "HD"
        return "AUTO"

    def _genre_text(self, row, item):
        value = row.get("genres") or row.get("genre") or row.get("genre_names") or ""
        if isinstance(value, list):
            parts=[]
            for x in value:
                if isinstance(x, dict): parts.append(str(x.get("name") or ""))
                elif x: parts.append(str(x))
            value=" / ".join(x for x in parts if x)
        return _first_text(value, item.get("genre") if isinstance(item, dict) else "")[:96]

    def _country_text(self, row, item):
        value = row.get("country") or row.get("origin_country") or row.get("production_countries") or ""
        if isinstance(value, list):
            parts=[]
            for x in value:
                if isinstance(x, dict): parts.append(str(x.get("iso_3166_1") or x.get("name") or ""))
                elif x: parts.append(str(x))
            value=" / ".join(x for x in parts if x)
        return _first_text(value, item.get("country") if isinstance(item, dict) else "")[:16]

    def _overview_text(self, row, item):
        overlay = row.get("item_overlay") if isinstance(row.get("item_overlay"), dict) else {}
        return _first_text(row.get("overview"), row.get("description"), overlay.get("description"), item.get("description") if isinstance(item, dict) else "")[:650]

    def _bd_force_geometry(self):
        """Pin the new page geometry at runtime so inherited grid skin state cannot move it."""
        if ePoint is None or eSize is None:
            return
        try:
            # Counter left, transient BLUE status centered, both immediately above the rail.
            for name,x,y,w,h in (("page_label",55,722,470,28),("status",650,722,620,28)):
                inst=self[name].instance
                if inst is not None:
                    inst.move(ePoint(x,y));inst.resize(eSize(w,h))
            for name,x,y,w,h in (("title_logo",55,95,432,210),("bd_title_fallback",55,121,500,138)):
                inst=self[name].instance
                if inst is not None:
                    inst.move(ePoint(x,y));inst.resize(eSize(w,h))
            # Pin the complete information stack immediately above the counter.
            hud_geometry=(
                ("bd_year_bg",55,315,130,50),("bd_year",100,322,72,36),
                ("bd_quality_bg",198,315,150,50),("bd_quality_logo",212,323,122,34),("bd_quality",214,322,118,36),
                ("bd_runtime_bg",361,315,150,50),("bd_runtime",411,320,88,40),
                ("bd_genre_bg",55,375,440,50),("bd_genre",72,382,406,36),
                ("bd_overview_bg",55,435,440,232),("bd_overview",76,447,398,206),
            )
            for name,gx,gy,gw,gh in hud_geometry:
                inst=self[name].instance
                if inst is not None:
                    inst.move(ePoint(gx,gy));inst.resize(eSize(gw,gh))
            # Move the COMPLETE stable Poster-Grid card as one object: art, chrome, title and meta.
            # Keep the exact proven 206x382 card proportions so no text can fall outside its glass.
            for pos in range(self.page_size):
                x=55+(230*pos)
                geometry=(("art%d"%pos,x,712,206,310),("card_chrome%d"%pos,x-4,708,214,318),
                          ("item_title%d"%pos,2000,0,1,1),("item_meta%d"%pos,2000,0,1,1))
                for name,gx,gy,gw,gh in geometry:
                    inst=self[name].instance
                    if inst is not None:
                        inst.move(ePoint(gx,gy));inst.resize(eSize(gw,gh))
            # Focus uses the exact same 214x318 footprint as the fixed rail frame.
            for name in ("selection","selection_adaptive"):
                inst=self[name].instance
                if inst is not None:
                    inst.move(ePoint(51,708));inst.resize(eSize(214,318))
            self._scaled_card_positions=[(int((51+230*i)*self._grid_sx),int(708*self._grid_sy)) for i in range(self.page_size)]
        except Exception as exc:
            optional_failure("backdrop_grid.force_geometry",exc)

    def _bd_cached_cinematic_package(self,item,row):
        """Read the already-persisted Cinematic package only; never build or fetch here."""
        key=self._focus_key(item,row)
        cached=self._bd_visual_cache.get(key)
        if cached is not None:
            return cached
        safe=re.sub(r"[^A-Za-z0-9._-]+","_",str(key or ""))[:160]
        path=os.path.join(GENERATED,"cinematic_%s_package.json"%safe) if safe else ""
        data={}
        try:
            if path and os.path.isfile(path):
                with open(path,"r",encoding="utf-8") as h:
                    raw=json.load(h)
                if isinstance(raw,dict) and raw.get("complete"):
                    bd=str(raw.get("backdrop") or "")
                    if _valid_file(bd):
                        data=dict(raw)
        except Exception as exc:
            optional_failure("backdrop_grid.cached_package",exc)
        self._bd_visual_cache[key]=data
        return data

    def _bd_hud_from_package(self, package, key):
        """Build Backdrop-Grid-sized glass from the *same* cached Cinematic package.

        This is deliberately local/HDD-only.  Earlier builds returned immediately
        when a cached backdrop existed, so some titles kept the neutral dark first
        paint forever even though their adaptive Cinematic chrome was already on
        disk.  Reuse those exact adaptive assets and only nine-slice them to this
        page's geometry.
        """
        if not isinstance(package,dict) or not package:
            return {}
        mem_key=str(key or "")+"|"+str(package.get("accent") or "")
        cached=self._bd_hud_cache.get(mem_key)
        if isinstance(cached,dict) and cached:
            return cached
        sources={
            "year":package.get("year") or package.get("panel_detail"),
            "quality":package.get("quality") or package.get("panel_detail"),
            "runtime":package.get("runtime") or package.get("panel_detail"),
            "genre":package.get("genre_detail") or package.get("panel_detail"),
            "overview":package.get("overview_detail") or package.get("panel_detail"),
        }
        root=os.path.join(GENERATED,"backdrop_grid_hud_v4")
        try:
            if not os.path.isdir(root):os.makedirs(root)
        except Exception:pass
        out={}
        for name,size in (("year",(130,50)),("quality",(150,50)),("runtime",(150,50)),("genre",(440,50)),("overview",(440,232))):
            source=str(sources.get(name) or "")
            if not _valid_file(source):continue
            try:stamp="%s|%s|%s|%s|pkgv4"%(source,int(os.path.getmtime(source)),size[0],size[1])
            except Exception:stamp="%s|%s|%s|pkgv4"%(source,size[0],size[1])
            target=os.path.join(root,"%s_%s.png"%(name,hashlib.sha1(stamp.encode("utf-8","ignore")).hexdigest()[:18]))
            out[name]=_nine_slice(source,target,size) or source
        accent=str(package.get("accent") or "#69c9f4")
        mood_key=re.sub(r"[^0-9a-fA-F]","",accent)[:6] or "69c9f4"
        out["mood"]=_mood_overlay(os.path.join(root,"mood_%s.png"%mood_key),accent)
        self._bd_hud_cache[mem_key]=out
        return out

    def _bd_apply_cached_package(self,item,row):
        """Instant HDD-only visual handoff used on every LEFT/RIGHT key press."""
        package=self._bd_cached_cinematic_package(item,row)
        if not package:
            return False
        try:
            bd=str(package.get("backdrop") or "")
            if _valid_file(bd):
                if self._bd_set_pixmap_file("bd_backdrop",bd,show=True,release_first=True):
                    self._bd_applied_key=self._focus_key(item,row)
            # Backdrop package owns the background only. Adaptive HUD is poster-
            # driven and follows its own persistent ready-bundle path below.
            return bool(bd)
        except Exception as exc:
            optional_failure("backdrop_grid.apply_cached_package",exc);return False

    def _fit_genre_font(self,text):
        try:
            inst=self["bd_genre"].instance
            if inst is None or gFont is None:return
            text=str(text or "")
            size=20
            # First choose a conservative size by text length, then measure when supported.
            if len(text)>72:size=12
            elif len(text)>58:size=13
            elif len(text)>46:size=14
            elif len(text)>36:size=16
            elif len(text)>28:size=18
            for candidate in range(size,11,-1):
                inst.setFont(gFont("Regular",candidate))
                try:
                    if int(inst.calculateSize().width())<=398:
                        break
                except Exception:
                    break
        except Exception as exc:
            optional_failure("backdrop_grid.genre_fit",exc)

    def _fit_overview_font(self, text):
        try:
            inst = self["bd_overview"].instance
            if inst is None or gFont is None:
                return
            text = str(text or "")
            # Keep 22px when possible; long summaries shrink only enough to use the
            # taller premium box without clipping.
            start = 22
            if len(text) > 520: start = 17
            elif len(text) > 420: start = 18
            elif len(text) > 320: start = 19
            elif len(text) > 240: start = 20
            for candidate in range(start, 16, -1):
                inst.setFont(gFont("Regular", candidate))
                try:
                    size = inst.calculateSize()
                    if int(size.height()) <= 198:
                        break
                except Exception:
                    break
        except Exception as exc:
            optional_failure("backdrop_grid.overview_fit", exc)

    def _update_header(self, item):
        """Zero-work LEFT/RIGHT header path.

        Backdrop Grid keeps the previous title's complete HUD/backdrop alive while
        the cursor is moving.  Only the cheap text fallback changes immediately;
        all HDD/package/logo/font work is deferred to stable focus.
        """
        try:
            # release: arrow navigation is RAM-only. Do NOT read manifests or
            # Details snapshots here; stable focus owns all HDD/network work.
            title=self._rail_title(item,{})
            self["bd_title_fallback"].setText(_catalogue_title(title)[:64])
        except Exception:
            pass

    def _bd_update_header_full(self, item):
        # Paint neutral chrome only before the first adaptive HUD. Once adaptive
        # boxes exist they persist across focus changes until the next set swaps in.
        self._bd_apply_default_premium_hud()
        row = self._record(item)
        title = self._rail_title(item, row)
        try: self["bd_title_fallback"].setText(_catalogue_title(title)[:64])
        except Exception: self["bd_title_fallback"].setText(str(title or "")[:64])
        try: self["bd_year"].setText(_first_text(row.get("year"), item.get("year"))[:4])
        except Exception: self["bd_year"].setText("")
        try:
            quality=self._quality(item,row)
            quality_asset=_quality_asset_name(quality or self._rail_title(item,row))
            if quality_asset:
                path=asset(quality_asset)
                if _valid_file(path) and self._bd_set_pixmap_file("bd_quality_logo",path,show=True,release_first=True):
                    self["bd_quality"].setText("");self["bd_quality"].hide()
                else:
                    self["bd_quality_logo"].hide();self["bd_quality"].setText(quality);self["bd_quality"].show()
            else:
                self["bd_quality_logo"].hide();self["bd_quality"].setText(quality);self["bd_quality"].show()
        except Exception:
            try:self["bd_quality_logo"].hide();self["bd_quality"].setText("AUTO");self["bd_quality"].show()
            except Exception:pass
        try:
            if self.media_type == "series":
                seasons=(row.get("number_of_seasons") or row.get("seasons_count") or row.get("season_count") or
                         item.get("number_of_seasons") or item.get("seasons_count") or item.get("season_count") or 0)
                if isinstance(seasons,(list,tuple)):seasons=len(seasons)
                try:count=int(seasons or 0)
                except Exception:count=0
                text=((_("%d season")%count) if count==1 else ((_("%d seasons")%count) if count>1 else ""))
                self["bd_runtime"].setText(text)
                icon=asset("us89_folder_yellow_34.png")
            else:
                runtime = row.get("runtime") or row.get("duration") or row.get("episode_run_time") or ""
                if isinstance(runtime, list): runtime = runtime[0] if runtime else ""
                self["bd_runtime"].setText(self._format_runtime(runtime))
                icon=asset("us86_episode_40.png")
            if _valid_file(icon):self._bd_set_pixmap_file("bd_runtime_icon",icon,show=True,release_first=True)
            if self.media_type == "series":
                self._bd_fit_series_season_text()
        except Exception:
            self["bd_runtime"].setText("")
        try: self["bd_country"].setText("")
        except Exception: pass
        try:
            genre_text=self._genre_text(row,item)
            self["bd_genre"].setText(genre_text);self._fit_genre_font(genre_text)
        except Exception: self["bd_genre"].setText("")
        try:
            overview_text = self._overview_text(row, item)
            self["bd_overview"].setText(overview_text)
            self._fit_overview_font(overview_text)
        except Exception:
            self["bd_overview"].setText("")

        # First paint from the already-cached canonical Cinematic package. This is HDD-only
        # and makes a previously BLUE-cached title switch instantly after Enigma restart.
        self._bd_apply_cached_package(item,row)
        # The title logo uses the same persistent cache as Details/Cinematic.
        self._show_cached_title_logo(item, row)

    def _show_cached_title_logo(self, item, row):
        try:
            tmdb_id = row.get("tmdb_id")
            if not tmdb_id:
                try:
                    self["title_logo"].hide()
                    if self["title_logo"].instance is not None:self["title_logo"].instance.setPixmap(None)
                except Exception:pass
                self._bd_pixmap_paths.pop("title_logo",None);self._bd_logo_path=""
                self["bd_title_fallback"].show(); return ""
            visible = self._rail_title(item, row)
            lang = "ar" if re.search(r"[\u0600-\u06ff]", str(visible or "")) else "en"
            path = PremiumGlobalCinematicScreen._blue_title_logo_cache_path(self.media_type, tmdb_id, lang)
            if _valid_file(path):
                if self._bd_set_pixmap_file("title_logo",path,show=True,release_first=True):
                    self._bd_logo_path = path; self["bd_title_fallback"].hide(); return path
            try:
                self["title_logo"].hide()
                if self["title_logo"].instance is not None:self["title_logo"].instance.setPixmap(None)
            except Exception:pass
            self._bd_pixmap_paths.pop("title_logo",None);self._bd_logo_path=""
            self["bd_title_fallback"].show(); return ""
        except Exception as exc:
            optional_failure("backdrop_grid.logo_cached", exc)
            try: self["title_logo"].hide(); self["bd_title_fallback"].show()
            except Exception: pass
            return ""

    @staticmethod
    def _bd_safe_unlink_title_logo(path):
        try:
            if path and os.path.exists(path):os.remove(path)
        except Exception:
            pass

    def _bd_current_logo_sig(self,item):
        try:return str(self._page_visual_key(item) or "")
        except Exception:return ""

    def _bd_logo_identity(self,item,row):
        """Validate cached identity exactly like Details before any logo lookup.

        Older builds can leave a stale TMDB pointer behind even when poster/backdrop
        presentation has already been rescued from another source.  Details rejects
        that pointer with ``identity_cache_compatible`` before resolving; Backdrop
        used to trust any non-empty tmdb_id and therefore asked TMDB/Fanart for the
        wrong movie on a small set of stubborn titles.
        """
        resolved_row=dict(row or {})
        src=dict(item or {}) if isinstance(item,dict) else {}
        initial_id=resolved_row.get("tmdb_id")
        if initial_id:
            compatible=False
            try:compatible=bool(identity_cache_compatible(src,resolved_row))
            except Exception:compatible=False
            _bd_logo_trace("identity_cached",title=self._rail_title(src,resolved_row),tmdb_id=initial_id,compatible=compatible,year=resolved_row.get("year") or src.get("year"))
            if compatible:
                return resolved_row
            # Fail closed like Details.  Remove only cache/internal identity evidence;
            # provider-native ids on the catalogue item remain available to ArtworkV2.
            for key in ("tmdb_id","media_type","identity_source","identity_verified","identity_pointer_verified","identity_catalogue_title","logo_url"):
                resolved_row.pop(key,None)
            for key in ("_locked_tmdb_id","_locked_tmdb_type"):
                src.pop(key,None)
            _bd_logo_trace("identity_rejected",title=self._rail_title(src,row or {}),old_tmdb_id=initial_id)
        cfg=getattr(self,"_grid_settings",None) or load_settings() or {}
        credential=str(cfg.get("tmdb_credential") or "").strip()
        if not (cfg.get("tmdb_enabled",True) and credential):
            _bd_logo_trace("identity_no_tmdb",title=self._rail_title(src,resolved_row))
            return resolved_row
        resolver=ArtworkV2(credential,cfg.get("tmdb_language","ar-EG"),min(9,max(4,int(cfg.get("timeout",10) or 10))))
        try:
            first=resolver.resolve_backdrop_only(self.profile,self.media_type,src,cancel_event=None) or {}
            if isinstance(first,dict) and first.get("tmdb_id") and identity_cache_compatible(src,first):
                resolved_row.update({k:v for k,v in first.items() if v not in (None,"",[],{})})
                _bd_logo_trace("identity_resolved_backdrop",title=self._rail_title(src,resolved_row),tmdb_id=resolved_row.get("tmdb_id"))
                return resolved_row
        except Exception as exc:
            optional_failure("backdrop_grid.logo_identity_cinematic",exc)
        clean=dict(src) if src.get("_xtream") else _strip_portal_artwork(src)
        for full in (False,True):
            try:
                found=resolver.resolve(self.profile,self.media_type,clean,full=full,cancel_event=None) or {}
                if isinstance(found,dict) and found.get("tmdb_id") and identity_cache_compatible(src,found):
                    resolved_row.update({k:v for k,v in found.items() if v not in (None,"",[],{})})
                    _bd_logo_trace("identity_resolved_details",title=self._rail_title(src,resolved_row),tmdb_id=resolved_row.get("tmdb_id"),full=full)
                    return resolved_row
            except Exception as exc:
                optional_failure("backdrop_grid.logo_identity_details",exc)
        _bd_logo_trace("identity_unresolved",title=self._rail_title(src,resolved_row),old_tmdb_id=initial_id)
        return resolved_row

    def _schedule_missing_title_logo(self,item,row,key):
        """Use the exact Details/XStreamity source + Twisted Agent transport.

        This intentionally does NOT call Cinematic's `_artwork_download` helper.
        The receiver proved that the Details Agent path is the one that succeeds
        for these logos, so Backdrop owns that same path directly.
        """
        try:
            sig=self._bd_current_logo_sig(item) or str(key or "")
            if not sig:return
            visible=self._rail_title(item,row)
            lang="ar" if re.search(r"[\u0600-\u06ff]",str(visible or "")) else "en"
            tmdb_id=(row or {}).get("tmdb_id")
            if tmdb_id:
                cached=PremiumGlobalCinematicScreen._blue_title_logo_cache_path(self.media_type,tmdb_id,lang)
                if _valid_file(cached):
                    if self._bd_set_pixmap_file("title_logo",cached,show=True,release_first=True):
                        self._bd_logo_path=cached;self["bd_title_fallback"].hide()
                    return
            attempt_key="details-agent:%s:%s"%(sig,lang)
            if attempt_key in self._bd_logo_attempted:return
            self._bd_logo_attempted.add(attempt_key)
            self._bd_title_logo_token += 1
            req_id=self._bd_title_logo_token
            self._bd_title_logo_sig=sig
            try:
                if self._bd_title_logo_deferred is not None and not getattr(self._bd_title_logo_deferred,"called",False):
                    self._bd_title_logo_deferred.cancel()
            except Exception:
                pass
            self._bd_title_logo_deferred=None
            self._bd_safe_unlink_title_logo(self._bd_title_logo_tmp);self._bd_title_logo_tmp=None
            item_copy=dict(item or {});row_copy=dict(row or {});self_ref=weakref.ref(self)
            def source_worker():
                owner=self_ref()
                if owner is None or owner._bd_closed or req_id!=owner._bd_title_logo_token:return
                resolved=dict(row_copy)
                try:
                    resolved=owner._bd_logo_identity(item_copy,resolved) or resolved
                    if owner._bd_closed or req_id!=owner._bd_title_logo_token:return
                    tmdb_id=resolved.get("tmdb_id")
                    if not tmdb_id:
                        _bd_logo_trace("source_no_identity",title=owner._rail_title(item_copy,resolved))
                        owner._bd_logo_attempted.discard(attempt_key);return
                    _bd_logo_trace("source_identity",title=owner._rail_title(item_copy,resolved),tmdb_id=tmdb_id,lang=lang)
                    mt="tv" if owner.media_type=="series" else "movie"
                    owner._bd_title_logo_cache_target=PremiumGlobalCinematicScreen._blue_title_logo_cache_path(owner.media_type,tmdb_id,lang)
                    if _valid_file(owner._bd_title_logo_cache_target):
                        reactor.callFromThread(owner._bd_apply_details_logo_cache,owner._bd_title_logo_cache_target,req_id,sig,tmdb_id,resolved.get("media_type"),attempt_key)
                        return
                    cfg=(getattr(owner,"_grid_settings",None) or load_settings() or {});credential=str(cfg.get("tmdb_credential") or "").strip();timeout=min(7,max(3,int(cfg.get("timeout",10) or 10)));language=str(cfg.get("tmdb_language") or "en-US")
                    client=TMDBClient(credential,language,timeout) if cfg.get("tmdb_enabled",True) and credential else None
                    logo_url=str(resolved.get("logo_url") or "").strip() if lang=="en" else ""
                    if not logo_url and client is not None:
                        payload=client._get("/%s/%s/images"%(mt,int(tmdb_id)),{"include_image_language":(lang if lang=="ar" else "en,null")}) or {}
                        logos=payload.get("logos") if isinstance(payload,dict) else []
                        logo_path=str(((logos or [{}])[0] or {}).get("file_path") or "") if logos else ""
                        logo_url=TMDBClient.image_url(logo_path,"w300") if logo_path else ""
                        _bd_logo_trace("tmdb_logo_probe",title=owner._rail_title(item_copy,resolved),tmdb_id=tmdb_id,count=len(logos or []),hit=bool(logo_url))
                    if not logo_url:
                        try:
                            keys=load_api_keys() or {};project=str(keys.get("FANART_API_KEY") or "").strip();personal=str(keys.get("FANART_CLIENT_KEY") or "").strip()
                            _bd_logo_trace("fanart_keys",title=owner._rail_title(item_copy,resolved),tmdb_id=tmdb_id,project=bool(project),personal=bool(personal))
                            if project or personal:
                                tvdb_id=str(resolved.get("tvdb_id") or resolved.get("thetvdb_id") or resolved.get("tvdb") or "").strip()
                                if mt=="tv" and not tvdb_id and client is not None:
                                    try:
                                        ext=client._get("/tv/%s/external_ids"%int(tmdb_id),{}) or {};tvdb_id=str(ext.get("tvdb_id") or "").strip()
                                    except Exception:tvdb_id=""
                                fa=_fanart_fetch(project,mt,tmdb_id=tmdb_id,tvdb_id=tvdb_id,timeout=timeout,personal_key=personal,logo_lang=lang) or {}
                                logo_url=str(fa.get("title_logo_url") or "").strip()
                                _bd_logo_trace("fanart_logo_probe",title=owner._rail_title(item_copy,resolved),tmdb_id=tmdb_id,tvdb_id=tvdb_id,hit=bool(logo_url),source=fa.get("source"),raw_id=fa.get("raw_id"),rows=fa.get("title_logo_row_count"),langs=fa.get("title_logo_langs"))
                        except Exception as exc:
                            _bd_logo_trace("fanart_error",title=owner._rail_title(item_copy,resolved),tmdb_id=tmdb_id,error=str(exc)[:180])
                            optional_failure("backdrop_grid.details_agent_fanart",exc)
                    if logo_url and req_id==owner._bd_title_logo_token and not owner._bd_closed:
                        _bd_logo_trace("download_start",title=owner._rail_title(item_copy,resolved),tmdb_id=tmdb_id,host=urllib.parse.urlsplit(str(logo_url)).hostname or "")
                        reactor.callFromThread(owner._bd_start_details_title_logo_download,logo_url,req_id,sig,tmdb_id,resolved.get("media_type"),attempt_key)
                    else:
                        _bd_logo_trace("source_miss",title=owner._rail_title(item_copy,resolved),tmdb_id=tmdb_id)
                        owner._bd_logo_attempted.discard(attempt_key)
                except Exception as exc:
                    owner._bd_logo_attempted.discard(attempt_key);optional_failure("backdrop_grid.details_agent_source",exc)
            _BG_LOGO_EXECUTOR.submit(source_worker,_task_key="bd-logo-source:%x"%id(self),_replace_task_key=True)
        except Exception as exc:
            optional_failure("backdrop_grid.details_agent_submit",exc)

    def _bd_apply_details_logo_cache(self,path,req_id,sig,tmdb_id,resolved_media_type,attempt_key):
        try:
            if self._bd_closed or req_id!=self._bd_title_logo_token:return
            if not self.grid_items:return
            current=self.grid_items[self.index]
            if self._bd_current_logo_sig(current)!=sig:return
            if isinstance(current,dict):
                current["_locked_tmdb_id"]=tmdb_id;current["_locked_tmdb_type"]=resolved_media_type or ("tv" if self.media_type=="series" else "movie")
            if self._bd_set_pixmap_file("title_logo",path,show=True,release_first=True):
                self._bd_logo_path=path;self["bd_title_fallback"].hide()
            self._bd_logo_attempted.discard(attempt_key)
        except Exception as exc:
            optional_failure("backdrop_grid.details_agent_cache_apply",exc)

    def _bd_start_details_title_logo_download(self,logo_image,req_id,sig,tmdb_id,resolved_media_type,attempt_key):
        try:
            if self._bd_closed or req_id!=self._bd_title_logo_token:return
            if not logo_image or str(logo_image).lower()=="n/a" or not str(logo_image).startswith(("http://","https://")):
                self._bd_logo_attempted.discard(attempt_key);return
            if not self.grid_items or self._bd_current_logo_sig(self.grid_items[self.index])!=sig:return
            try:
                if self._bd_title_logo_deferred is not None and not getattr(self._bd_title_logo_deferred,"called",False):self._bd_title_logo_deferred.cancel()
            except Exception:pass
            try:url_bytes=str(logo_image).encode("latin-1")
            except (UnicodeEncodeError,UnicodeDecodeError):
                self._bd_logo_attempted.discard(attempt_key);return
            self._bd_title_logo_deferred=self._bd_title_logo_agent.request(
                b"GET",url_bytes,Headers({"User-Agent":[b"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"]})
            )
            self._bd_title_logo_deferred.addCallback(self._bd_title_logo_response,req_id,sig,tmdb_id,resolved_media_type,attempt_key)
            self._bd_title_logo_deferred.addErrback(self._bd_title_logo_error,req_id,attempt_key)
        except Exception as exc:
            self._bd_logo_attempted.discard(attempt_key);optional_failure("backdrop_grid.details_agent_start",exc)

    def _bd_title_logo_response(self,response,req_id,sig,tmdb_id,resolved_media_type,attempt_key):
        if req_id!=self._bd_title_logo_token:return
        code=int(getattr(response,"code",0) or 0)
        _bd_logo_trace("download_response",tmdb_id=tmdb_id,status=code)
        if code==200:
            d=readBody(response);d.addCallback(self._bd_title_logo_body,req_id,sig,tmdb_id,resolved_media_type,attempt_key);return d
        self._bd_logo_attempted.discard(attempt_key)

    def _bd_title_logo_body(self,body,req_id,sig,tmdb_id,resolved_media_type,attempt_key):
        if req_id!=self._bd_title_logo_token:return
        fd,temp=tempfile.mkstemp(prefix="xst_bd_logo_",suffix=".png")
        try:os.close(fd)
        except Exception:pass
        self._bd_title_logo_tmp=temp
        try:
            _bd_logo_trace("download_body",tmdb_id=tmdb_id,bytes=len(body or b""))
            with open(temp,"wb") as f:f.write(body)
        except Exception:
            self._bd_safe_unlink_title_logo(temp);self._bd_title_logo_tmp=None;self._bd_logo_attempted.discard(attempt_key);return
        self._bd_resize_details_title_logo(temp,req_id,sig,tmdb_id,resolved_media_type,attempt_key)

    def _bd_title_logo_error(self,error,req_id=None,attempt_key=""):
        if attempt_key:self._bd_logo_attempted.discard(attempt_key)

    def _bd_resize_details_title_logo(self,preview,req_id,sig,tmdb_id,resolved_media_type,attempt_key):
        if req_id!=self._bd_title_logo_token:
            self._bd_safe_unlink_title_logo(preview);return
        try:
            if not self.grid_items or self._bd_current_logo_sig(self.grid_items[self.index])!=sig:
                self._bd_safe_unlink_title_logo(preview);return
            size=(432,210)
            if self["title_logo"].instance is not None:
                try:size=(self["title_logo"].instance.size().width(),self["title_logo"].instance.size().height())
                except Exception:pass
            from PIL import Image as _LogoImage
            im=_LogoImage.open(preview)
            if im.mode!="RGBA":im=im.convert("RGBA")
            if im.size[0]>size[0] or im.size[1]>size[1]:
                try:im.thumbnail(size,_LogoImage.Resampling.LANCZOS)
                except Exception:im.thumbnail(size,_LogoImage.ANTIALIAS)
            try:
                bbox=im.getchannel("A").getbbox()
                if bbox:im=im.crop(bbox)
            except Exception:pass
            max_w=max(1,int(size[0])-28);max_h=max(1,int(size[1])-24)
            if im.size[0]>0 and im.size[1]>0:
                scale=min(float(max_w)/float(im.size[0]),float(max_h)/float(im.size[1]));nw=max(1,int(round(im.size[0]*scale)));nh=max(1,int(round(im.size[1]*scale)))
                if (nw,nh)!=im.size:
                    try:im=im.resize((nw,nh),_LogoImage.Resampling.LANCZOS)
                    except Exception:im=im.resize((nw,nh),_LogoImage.LANCZOS)
            bg=_LogoImage.new("RGBA",size,(255,255,255,0));left=max(0,(size[0]-im.size[0])//2);top=max(0,(size[1]-im.size[1])//2);bg.paste(im,(left,top),mask=im)
            target=str(self._bd_title_logo_cache_target or PremiumGlobalCinematicScreen._blue_title_logo_cache_path(self.media_type,tmdb_id,"ar" if re.search(r"[\u0600-\u06ff]",str(self._rail_title(self.grid_items[self.index],{}) or "")) else "en"))
            display_path=preview
            if target:
                parent=os.path.dirname(target)
                if parent and not os.path.isdir(parent):os.makedirs(parent)
                tmp_target=target+".tmp.%s"%os.getpid();bg.save(tmp_target,"PNG",compress_level=0);os.replace(tmp_target,target);display_path=target
            current=self.grid_items[self.index]
            if isinstance(current,dict):
                current["_locked_tmdb_id"]=tmdb_id;current["_locked_tmdb_type"]=resolved_media_type or ("tv" if self.media_type=="series" else "movie")
            if self._bd_set_pixmap_file("title_logo",display_path,show=True,release_first=True):
                self._bd_logo_path=display_path;self["bd_title_fallback"].hide()
                _bd_logo_trace("paint_ok",tmdb_id=tmdb_id,path=display_path,size=os.path.getsize(display_path) if os.path.isfile(display_path) else 0)
            else:
                _bd_logo_trace("paint_failed",tmdb_id=tmdb_id,path=display_path)
            self._bd_logo_attempted.discard(attempt_key)
        except Exception as exc:
            self._bd_logo_attempted.discard(attempt_key);optional_failure("backdrop_grid.details_agent_resize",exc)
        self._bd_safe_unlink_title_logo(preview);self._bd_title_logo_tmp=None

    def _focus_key(self, item, row):
        tid = row.get("tmdb_id") if isinstance(row, dict) else None
        if tid:
            return "%s-%s" % ("tv" if self.media_type == "series" else "movie", tid)
        return self._page_visual_key(item)

    def _prepare_adaptive_hud(self,item,row,key,accent):
        out={}
        try:
            bundle=_load_visual_bundle(self.profile,self.media_type,item,row) or {}
            chrome=bundle.get("chrome") if isinstance(bundle.get("chrome"),dict) else {}
        except Exception:
            chrome={}
        if not chrome:
            try:
                source=str(row.get("poster_local") or row.get("backdrop_local") or "")
                if _valid_file(source):
                    # Palette/HUD work is selected-title only. Prefer the tiny BLUE
                    # rail thumb so adaptive boxes never decode a full poster here.
                    try:
                        thumb=self._grid_poster_thumb_path(source) if str(row.get("poster_local") or "")==source else ""
                    except Exception:thumb=""
                    palette_source=thumb if _valid_file(thumb) else source
                    chrome=_build_dynamic_details_chrome(palette_source,"bdgrid_%s"%hashlib.sha1((str(key)+"|"+palette_source).encode("utf-8","ignore")).hexdigest()[:16]) or {}
            except Exception as exc:
                optional_failure("backdrop_grid.dynamic_hud",exc)
        sources={
            "year":(chrome.get("year") if isinstance(chrome,dict) else None) or asset("cinematic_row_glass_premium.png"),
            "quality":(chrome.get("quality") if isinstance(chrome,dict) else None) or asset("cinematic_row_glass_premium.png"),
            "runtime":(chrome.get("runtime") if isinstance(chrome,dict) else None) or asset("cinematic_row_glass_premium.png"),
            "genre":(chrome.get("genre_detail") if isinstance(chrome,dict) else None) or asset("cinematic_row_glass_premium.png"),
            "overview":(chrome.get("overview_detail") if isinstance(chrome,dict) else None) or asset("cinematic_overview_glass_compact.png"),
        }
        root=os.path.join(GENERATED,"backdrop_grid_hud_v3")
        try:
            if not os.path.isdir(root):os.makedirs(root)
        except Exception:pass
        for name,size in (("year",(130,50)),("quality",(150,50)),("runtime",(150,50)),("genre",(440,50)),("overview",(440,232))):
            source=sources.get(name) or ""
            if not _valid_file(source):continue
            try:stamp="%s|%s|%s|%s"%(source,int(os.path.getmtime(source)),size[0],size[1])
            except Exception:stamp="%s|%s|%s"%(source,size[0],size[1])
            target=os.path.join(root,"%s_%s.png"%(name,hashlib.sha1(stamp.encode("utf-8","ignore")).hexdigest()[:18]))
            out[name]=_nine_slice(source,target,size) or source
        # Only the information boxes are adaptive on Backdrop Grid.
        return out

    def _apply_adaptive_hud(self,hud):
        if not isinstance(hud,dict):return
        mapping={"year":"bd_year_bg","quality":"bd_quality_bg","runtime":"bd_runtime_bg","genre":"bd_genre_bg","overview":"bd_overview_bg"}
        painted=False
        for key,widget in mapping.items():
            path=str(hud.get(key) or "")
            if not _valid_file(path):continue
            try:
                if self._bd_set_pixmap_file(widget,path,show=True,release_first=True):painted=True
            except Exception as exc:optional_failure("backdrop_grid.apply_hud",exc)
        if painted:self._bd_hud_adaptive_active=True

    def _schedule_selected_adaptive_hud(self,item,row,key,cancel_event=None):
        """Prepare adaptive info boxes for the current title only.

        This is intentionally independent from the eight poster cards.  A missing
        HUD is built once from the small rail thumb, saved to HDD, and applied only
        if the same title is still focused when the worker completes.
        """
        sig=str(key or "")
        if not sig:return
        pending=self._bd_hud_pending.get(sig)
        if pending is cancel_event and pending is not None:return
        self._bd_hud_pending[sig]=cancel_event
        item_copy=dict(item or {});row_copy=dict(row or {});self_ref=weakref.ref(self)
        def worker():
            owner=self_ref()
            if owner is None or owner._bd_closed or (cancel_event is not None and cancel_event.is_set()):return
            try:
                if not owner.grid_items:return
                cur=owner.grid_items[owner.index];cur_row=owner._record(cur) or {}
                if str(owner._focus_key(cur,cur_row) or "") != sig:return
                if cancel_event is not None and cancel_event.is_set():return
                package=owner._bd_cached_cinematic_package(item_copy,row_copy) or {}
                accent=str(package.get("accent") or row_copy.get("adaptive_accent") or row_copy.get("adaptive_primary") or "#69c9f4")
                # One adaptive authority for Backdrop Grid: poster/Details visual bundle.
                # Never let an old neutral Cinematic package suppress real adaptive chrome.
                if cancel_event is not None and cancel_event.is_set():return
                hud=owner._prepare_adaptive_hud(item_copy,row_copy,sig,accent) or {}
                if not hud and package:hud=owner._bd_hud_from_package(package,sig) or {}
                if cancel_event is not None and cancel_event.is_set():return
                if hud:owner._bd_save_ready_hud(item_copy,row_copy,hud)
                if not owner._bd_closed and not (cancel_event is not None and cancel_event.is_set()):owner._bd_jobs.put({"kind":"hud_only","token":owner._bd_token,"key":sig,"backdrop":"","logo":"","hud":hud})
            except Exception as exc:optional_failure("backdrop_grid.selected_hud_worker",exc)
            finally:
                owner=self_ref()
                if owner is not None and owner._bd_hud_pending.get(sig) is cancel_event:owner._bd_hud_pending.pop(sig,None)
        try:_BG_EXECUTOR.submit(worker,_task_key="bd-hud:%x"%id(self),_replace_task_key=True)
        except Exception:
            if self._bd_hud_pending.get(sig) is cancel_event:self._bd_hud_pending.pop(sig,None)

    def _prefetch_focused_artwork(self):
        """Backdrop Grid owns one Cinematic-style stable-focus hydration lane.

        The inherited Poster Grid worker is deliberately disabled here so an
        uncached title cannot start two independent full artwork resolves at the
        same time. Visible poster-card warming remains handled by the normal
        page prefetch path; this method only replaces the stable-focus full job.
        """
        return

    def _bd_fit_series_season_text(self):
        """Use the exact Details compact-text fitter for the season pill."""
        if self.media_type != "series":
            return
        try:
            from .ui_screens_details import ContentDetailsScreen
            ContentDetailsScreen._fit_compact_text(self,"bd_runtime",max_size=24,min_size=18,padding=4)
        except Exception as exc:
            optional_failure("backdrop_grid.season_details_fit",exc)

    def _bd_fast_backdrop_path(self, source, key, build=True):
        """Return the decoder-ready JPEG twin for a prepared Backdrop Grid surface.

        ``build=False`` is the navigation fast path: it performs filesystem checks
        only and can never invoke Pillow.  BLUE Cache Artwork and the background
        focus worker use ``build=True`` and therefore pay the conversion cost once.
        """
        source=str(source or "")
        if not _valid_file(source):return ""
        try:stamp="%s:%s:%s"%(source,int(os.path.getmtime(source)),int(os.path.getsize(source)))
        except Exception:stamp=source
        digest=hashlib.sha1(("bdgrid-fast-v1|"+str(key or "")+"|"+stamp).encode("utf-8","ignore")).hexdigest()[:20]
        target=os.path.join(GENERATED,"backdrop_grid_fast_%s.jpg"%digest)
        if _valid_file(target):return target
        if not build or _PILImage is None:return ""
        temp=target+".tmp.%d"%os.getpid()
        try:
            parent=os.path.dirname(target)
            if parent and not os.path.isdir(parent):os.makedirs(parent,exist_ok=True)
            with _PILImage.open(source) as im:
                im=im.convert("RGB")
                im.save(temp,"JPEG",quality=90,subsampling=2,optimize=False,progressive=False)
            os.replace(temp,target)
            return target if _valid_file(target) else ""
        except Exception as exc:
            optional_failure("backdrop_grid.fast_backdrop_encode",exc)
            try:
                if os.path.exists(temp):os.unlink(temp)
            except Exception:pass
            return ""

    def _bd_display_surface_path(self, backdrop, key, accent):
        """Canonical prepared Backdrop Grid surface shared by BLUE and focus.

        Older builds used one filename during BLUE and a different filename on
        first focus.  As a result "display-ready N/N" could still cost 4-5s per
        title the first time it was highlighted.  This path is now the single
        persistent presentation identity used by both code paths.
        """
        backdrop=str(backdrop or "")
        if not _valid_file(backdrop):return ""
        try:stamp="%s:%s"%(backdrop,int(os.path.getmtime(backdrop)))
        except Exception:stamp=backdrop
        digest=hashlib.sha1(("bdgrid-display-v1|"+str(key or "")+"|"+stamp+"|"+str(accent or "")).encode("utf-8","ignore")).hexdigest()[:20]
        return os.path.join(GENERATED,"backdrop_grid_display_%s.png"%digest)

    def _bd_prepare_display_surface(self, backdrop, key, accent, build=True):
        """Return the final decoder-ready Backdrop Grid presentation.

        When ``build`` is False this is HDD-only and never converts anything.
        Explicit BLUE and the background focus worker pass True, creating both
        the cinematic PNG and its JPEG decoder twin exactly once.
        """
        target=self._bd_display_surface_path(backdrop,key,accent)
        if not target:return ""
        if not _valid_file(target):
            # Adopt the release BLUE presentation when present instead of making a
            # receiver re-compose artwork it has already paid for once.
            try:
                try:stamp="%s:%s"%(str(backdrop),int(os.path.getmtime(str(backdrop))))
                except Exception:stamp=str(backdrop)
                old_digest=hashlib.sha1(("fresh-bd-grid-v3|"+str(key or "")+"|"+stamp+"|"+str(accent or "")).encode("utf-8","ignore")).hexdigest()[:20]
                old_path=os.path.join(GENERATED,"backdrop_grid_fresh_v2_%s.png"%old_digest)
                if _valid_file(old_path):
                    try:os.link(old_path,target)
                    except Exception:
                        try:shutil.copy2(old_path,target)
                        except Exception:pass
            except Exception:pass
        if not _valid_file(target):
            if not build:return ""
            prepared=_build_cinematic_backdrop(str(backdrop),target,str(accent or "#69c9f4")) or ""
            if not _valid_file(prepared):return ""
            target=prepared
        return self._bd_fast_backdrop_path(target,key,build=build)

    def _bd_schedule_full_focus_prepare(self,item,row,key,cancel_event=None):
        """Cinematic-style cold-title preparation, entirely outside the UI thread.

        Hold the previous backdrop/HUD while the new title resolves.  Poster,
        canonical backdrop, presentation backdrop and adaptive HUD are prepared
        in one worker and swapped only after decoder-ready assets exist.
        """
        sig=str(key or "")
        if not sig:return
        pending=self._bd_focus_pending.get(sig)
        if pending is cancel_event and pending is not None:return
        self._bd_focus_pending[sig]=cancel_event
        item_copy=dict(item or {});row_copy=dict(row or {});self_ref=weakref.ref(self)
        def worker():
            owner=self_ref()
            if owner is None or owner._bd_closed or (cancel_event is not None and cancel_event.is_set()):return
            try:
                resolved=dict(row_copy)
                try:
                    from .details_authority import resolve_canonical
                    # Use the same complete Settings source as native Details.
                    auth=resolve_canonical(owner.profile,owner.media_type,item_copy,cancel_event=cancel_event,settings=(getattr(owner,"_grid_settings",None) or load_settings())) or {}
                    if auth:
                        for k,v in auth.items():
                            if v not in (None,"",[],{}):resolved[k]=v
                except Exception as exc:
                    optional_failure("backdrop_grid.focus_details_authority",exc)

                if cancel_event is not None and cancel_event.is_set():return

                # Prefer an already-built Cinematic package, but never send a
                # heavyweight PNG/raw master to Enigma2.  Make/use a JPEG twin.
                package=owner._bd_cached_cinematic_package(item_copy,resolved) or {}
                presentation=""
                if package:
                    fast=str(package.get("backdrop_fast") or "")
                    if _valid_file(fast):presentation=fast
                    else:
                        src=str(package.get("backdrop") or "")
                        if _valid_file(src):presentation=owner._bd_fast_backdrop_path(src,sig)

                backdrop=str(resolved.get("backdrop_local") or "")
                if not presentation and _valid_file(backdrop):
                    # BLUE and first-focus now share one canonical prepared file.
                    # If BLUE has already reported display-ready, this is an HDD
                    # hit; otherwise this background worker builds it once.
                    accent=str(resolved.get("adaptive_accent") or resolved.get("adaptive_primary") or "#69c9f4")
                    presentation=owner._bd_prepare_display_surface(backdrop,sig,accent,build=True)

                if cancel_event is not None and cancel_event.is_set():return
                hud={}
                try:
                    hud=owner._bd_load_ready_hud(item_copy,resolved) or {}
                    if not hud:
                        hud=owner._prepare_adaptive_hud(item_copy,resolved,sig,str(resolved.get("adaptive_accent") or resolved.get("adaptive_primary") or "#69c9f4")) or {}
                        if hud:owner._bd_save_ready_hud(item_copy,resolved,hud)
                except Exception as exc:optional_failure("backdrop_grid.focus_hud_prepare",exc)

                if not owner._bd_closed and not (cancel_event is not None and cancel_event.is_set()):
                    owner._bd_jobs.put({"kind":"focus_ready","token":owner._bd_token,"key":sig,"backdrop":presentation,"logo":"","hud":hud,"resolved_row":resolved})
            except Exception as exc:
                optional_failure("backdrop_grid.full_focus_prepare",exc)
            finally:
                owner=self_ref()
                if owner is not None and owner._bd_focus_pending.get(sig) is cancel_event:owner._bd_focus_pending.pop(sig,None)
        try:_BG_FOCUS_EXECUTOR.submit(worker,_task_key="bd-focus:%x"%id(self),_replace_task_key=True)
        except Exception:
            if self._bd_focus_pending.get(sig) is cancel_event:self._bd_focus_pending.pop(sig,None)

    def _schedule_backdrop_focus(self):
        """HDD-first, non-blocking Backdrop Grid focus handoff.

        Never decode a raw/full-HD master on the Enigma2 UI thread.  Keep the
        previous title painted until the new title has a decoder-ready backdrop
        and adaptive HUD, then swap them atomically from the job queue.
        """
        if self._bd_closed or not self.grid_items:return
        try:item=dict(self.grid_items[self.index])
        except Exception:return
        row=self._record(item) or {};key=self._focus_key(item,row)
        # Stable-focus cancellation: any unresolved work for the previous title
        # becomes obsolete as soon as focus changes. Cached files already built
        # remain reusable; only stale CPU/HDD/network work is asked to stop.
        if str(getattr(self,"_bd_focus_cancel_key","") or "") != str(key or ""):
            old_cancel=getattr(self,"_bd_focus_cancel",None)
            if old_cancel is not None:
                try:old_cancel.set()
                except Exception:pass
            self._bd_focus_cancel=threading.Event()
            self._bd_focus_cancel_key=str(key or "")
        focus_cancel=self._bd_focus_cancel

        # Existing decoder-ready Cinematic package: instant HDD hit.
        package=self._bd_cached_cinematic_package(item,row) or {}
        fast=str(package.get("backdrop_fast") or "") if package else ""
        if _valid_file(fast):
            try:
                if self._bd_set_pixmap_file("bd_backdrop",fast,show=True,release_first=True):self._bd_applied_key=key
            except Exception as exc:optional_failure("backdrop_grid.fast_package_paint",exc)
            try:
                ready_hud=self._bd_load_ready_hud(item,row)
                if ready_hud:self._apply_adaptive_hud(ready_hud)
                else:self._schedule_selected_adaptive_hud(item,row,key,focus_cancel)
            except Exception as exc:optional_failure("backdrop_grid.ready_hud_apply",exc)
            if not self._show_cached_title_logo(item,row):self._schedule_missing_title_logo(item,row,key)
            # release: visual readiness is NOT metadata readiness.  A cached
            # presentation may exist from BLUE/older focus while the canonical
            # Details record is still incomplete.  Keep the instant visual hit,
            # but let the same off-UI Details Authority lane complete metadata.
            if not (row.get("_details_authority_ready") and row.get("tmdb_id")):
                self._bd_schedule_full_focus_prepare(item,row,key,focus_cancel)
            return

        # No Cinematic package. BLUE Cache Artwork may still have prepared the
        # Backdrop Grid's own decoder-ready presentation. Bind that exact HDD
        # asset immediately; never make the user "teach" all titles by hovering.
        backdrop=str(row.get("backdrop_local") or "")
        accent=str((package or {}).get("accent") or row.get("adaptive_accent") or row.get("adaptive_primary") or "#69c9f4")
        blue_fast=self._bd_prepare_display_surface(backdrop,key,accent,build=False) if _valid_file(backdrop) else ""
        if _valid_file(blue_fast):
            try:
                if self._bd_set_pixmap_file("bd_backdrop",blue_fast,show=True,release_first=True):self._bd_applied_key=key
            except Exception as exc:optional_failure("backdrop_grid.blue_fast_paint",exc)
            try:
                ready_hud=self._bd_load_ready_hud(item,row)
                if ready_hud:self._apply_adaptive_hud(ready_hud)
                else:self._schedule_selected_adaptive_hud(item,row,key,focus_cancel)
            except Exception as exc:optional_failure("backdrop_grid.blue_fast_hud",exc)
            if not self._show_cached_title_logo(item,row):self._schedule_missing_title_logo(item,row,key)
            # Metadata may still need repair, but the backdrop itself is already
            # on screen instantly. The worker is therefore metadata/HUD only from
            # the user's point of view.
            if not (row.get("_details_authority_ready") and row.get("tmdb_id")):
                self._bd_schedule_full_focus_prepare(item,row,key,focus_cancel)
            return

        # No safe presentation yet. Hold the PREVIOUS backdrop + adaptive HUD;
        # cold artwork/presentation work happens entirely in the focus worker.
        self._bd_schedule_full_focus_prepare(item,row,key,focus_cancel)
        # release: cold focus has ONE authority job. focus_ready schedules logo
        # only after canonical identity is ready, avoiding duplicate TMDB work.
        if row.get("tmdb_id") and not self._show_cached_title_logo(item,row):
            self._schedule_missing_title_logo(item,row,key)

    def _cache_folder_artwork_worker(self, rows, cancel_event=None):
        """BLUE prepares Backdrop Grid without per-title poster chrome.

        V6.5.90 keeps all eight poster cards fixed and generates no adaptive
        per-title rail/HUD assets during BLUE. BLUE prepares only poster thumbs
        and display-ready backdrops; selection/HUD adaptive is current-title only.
        """
        result=PremiumPosterGridScreen._cache_folder_artwork_worker(self,rows,cancel_event) or {}
        items=[dict(x) for x in (rows or []) if isinstance(x,dict)]
        total=len(items);ready=0;backdrop_ready=0;rail_ready=0;hud_ready=0
        for pos,item in enumerate(items,1):
            if cancel_event is not None and cancel_event.is_set():break
            this_backdrop=False;this_rail=False;this_hud=False
            try:
                row=self._record(item) or {}
                backdrop=str(row.get("backdrop_local") or "")
                key=self._focus_key(item,row)
                package=self._bd_cached_cinematic_package(item,row) or {}
                accent=str(package.get("accent") or row.get("adaptive_accent") or row.get("adaptive_primary") or "#69c9f4")
                if _valid_file(backdrop):
                    # "display-ready" now means the EXACT decoder-ready asset
                    # navigation will bind after reopening the folder, not merely
                    # an intermediate PNG with a different first-focus filename.
                    prepared_fast=self._bd_prepare_display_surface(backdrop,key,accent,build=True)
                    this_backdrop=_valid_file(prepared_fast)
                    if this_backdrop:backdrop_ready+=1

                # Only the 206x310 thumb is title-specific on the rail now.
                # Fixed chrome/focus assets are packaged once and never generated.
                poster=str(row.get("poster_local") or "")
                if _valid_file(poster):
                    thumb=self._grid_poster_thumb_path(poster) or ""
                    if not _valid_file(thumb):
                        try:
                            if getattr(self,"_poster_small_fill",False) or getattr(self,"_poster_cover_mode",False):
                                _build_cover_thumbnail(poster,thumb,self._grid_image_size)
                            else:
                                _build_thumbnail(poster,thumb,self._grid_image_size)
                        except Exception as exc:optional_failure("backdrop_grid.blue_grid_thumb",exc)
                    this_rail=_valid_file(thumb)
                    if this_rail:rail_ready+=1

                # Adaptive HUD is selected-title only in release. BLUE must not
                # generate per-title HUD/selection assets for a 100-item folder.
                # Existing ready HUD remains reusable, but it is not required for
                # display-ready status.
                try:
                    this_hud=bool(self._bd_load_ready_hud(item,row))
                    if this_hud:hud_ready+=1
                except Exception:pass

                # Logo remains optional: a real title may simply have no logo.
                tmdb_id=row.get("tmdb_id")
                if tmdb_id:
                    visible=self._rail_title(item,row)
                    lang="ar" if re.search(r"[\u0600-\u06ff]",str(visible or "")) else "en"
                    cached=PremiumGlobalCinematicScreen._blue_title_logo_cache_path(self.media_type,tmdb_id,lang)
                    if not _valid_file(cached):
                        try:PremiumGlobalCinematicScreen._cache_title_logo_for_blue(self,item,row,cancel_event)
                        except Exception as exc:optional_failure("backdrop_grid.blue_title_logo_batch",exc)

                if this_backdrop and this_rail:ready+=1
            except Exception as exc:
                optional_failure("backdrop_grid.blue_display_prepare",exc)
            finally:
                try:gc.collect()
                except Exception:pass
                # Give Broadcom/OpenBH a small breather every page-sized batch.
                if pos % 8 == 0:
                    try:time.sleep(0.06)
                    except Exception:pass
                # Presentation pass is intentionally silent. The base BLUE artwork
                # pass owns the user-visible Caching X / N counter; emitting progress
                # here would make the counter restart from 1 after reaching N.
        result=dict(result or {})
        result["presentation_total"]=total
        result["presentation_ready"]=ready
        result["presentation_failed"]=max(0,total-ready)
        result["backdrop_ready"]=backdrop_ready
        result["rail_ready"]=rail_ready
        result["hud_ready"]=hud_ready
        return result

    def _apply_debounced_grid_focus(self):
        # Fast navigation performs no HDD/font/logo work. Once focus is stable,
        # update the full information panel and presentation exactly once.
        try: PremiumPosterGridScreen._apply_debounced_grid_focus(self)
        except Exception as exc: optional_failure("backdrop_grid.base_focus", exc)
        try:
            if self.grid_items:self._bd_update_header_full(self.grid_items[self.index])
        except Exception as exc:optional_failure("backdrop_grid.full_header_debounced",exc)
        self._schedule_backdrop_focus()

    def _drain_jobs(self):
        PremiumPosterGridScreen._drain_jobs(self)

        # release: no HDD/TMDB work in the high-frequency drain loop.
        # Stable focus/focus_ready owns identity, metadata, artwork and logo.

        while True:
            try: job = self._bd_jobs.get_nowait()
            except queue.Empty: break
            except Exception: break
            kind=str(job.get("kind") or "")
            # Logo-only completion is keyed by the CURRENT title, not by the
            # backdrop build token.  This removes the race without allowing a
            # stale title to paint over a different focus item.
            if self._bd_closed or (kind!="logo_only" and int(job.get("token", -1)) != int(self._bd_token)):
                continue
            if not self.grid_items:
                continue
            current = self.grid_items[self.index]
            row = self._record(current)
            job_key=str(job.get("key") or "")
            current_keys={str(self._focus_key(current,row) or ""),str(self._page_visual_key(current) or "")}
            if job_key not in current_keys:
                continue
            resolved_row=job.get("resolved_row") if isinstance(job.get("resolved_row"),dict) else {}
            if resolved_row and isinstance(current,dict):
                try:
                    poster=str(resolved_row.get("poster_local") or "");backdrop_local=str(resolved_row.get("backdrop_local") or "")
                    if _valid_file(poster):
                        current["_ultra_poster_source"]=poster;current["_player_poster"]=poster;current["_adaptive_source_local"]=poster
                        self._grid_palette_sources[self.index]=poster
                    if _valid_file(backdrop_local):current["_backdrop_source_local"]=backdrop_local
                    if resolved_row.get("tmdb_id"):
                        current["_locked_tmdb_id"]=resolved_row.get("tmdb_id")
                        current["_locked_tmdb_type"]=resolved_row.get("media_type") or ("tv" if self.media_type=="series" else "movie")
                except Exception as exc:optional_failure("backdrop_grid.focus_ready_handoff",exc)
                # Details Authority saves the canonical record in the worker.
                # Refresh the HUD text once on the UI thread after that save so
                # runtime/country/genre/overview appear without opening Details.
                if kind=="focus_ready":
                    try:self._bd_update_header_full(current)
                    except Exception as exc:optional_failure("backdrop_grid.focus_ready_metadata_paint",exc)
                    try:
                        if resolved_row.get("tmdb_id") and not self._show_cached_title_logo(current,resolved_row):
                            self._schedule_missing_title_logo(current,resolved_row,job_key)
                    except Exception as exc:optional_failure("backdrop_grid.focus_ready_logo",exc)
            resolved_tmdb_id=job.get("resolved_tmdb_id")
            if resolved_tmdb_id and isinstance(current,dict):
                try:
                    current["_locked_tmdb_id"]=resolved_tmdb_id
                    current["_locked_tmdb_type"]=job.get("resolved_media_type") or ("tv" if self.media_type=="series" else "movie")
                    row["tmdb_id"]=resolved_tmdb_id
                    row["media_type"]=current.get("_locked_tmdb_type")
                except Exception as exc:optional_failure("backdrop_grid.logo_identity_commit",exc)
            path = str(job.get("backdrop") or "")
            if _valid_file(path):
                try:
                    # Keep the exact decoder-ready Backdrop Grid presentation on
                    # the selected item. Details/Home Hero can reuse this HDD file
                    # verbatim; no second download, resize or recompression is needed.
                    if isinstance(current,dict):current["_backdrop_present_local"]=path
                    if self._bd_set_pixmap_file("bd_backdrop",path,show=True,release_first=True):
                        self._bd_applied_key = str(job.get("key") or "")
                except Exception as exc: optional_failure("backdrop_grid.apply_backdrop", exc)
            try:self._apply_adaptive_hud(job.get("hud") or {})
            except Exception as exc:optional_failure("backdrop_grid.apply_hud_job",exc)
            logo = str(job.get("logo") or "")
            attempt_key=str(job.get("attempt_key") or "")
            if _valid_file(logo):
                try:
                    if self._bd_set_pixmap_file("title_logo",logo,show=True,release_first=True):
                        self._bd_logo_path = logo; self["bd_title_fallback"].hide()
                except Exception as exc: optional_failure("backdrop_grid.apply_logo", exc)
            else:
                # A transient Fanart/TMDB transport miss must not poison the
                # screen for the rest of the session. Permit a later focus retry.
                if attempt_key:
                    try:self._bd_logo_attempted.discard(attempt_key)
                    except Exception:pass
                self._show_cached_title_logo(current, row)
