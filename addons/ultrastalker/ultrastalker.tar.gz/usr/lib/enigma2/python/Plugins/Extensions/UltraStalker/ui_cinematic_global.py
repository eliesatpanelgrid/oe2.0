# -*- coding: utf-8 -*-
"""Global-library-only Cinematic presentation for Movies and Series.

Hard rule: this screen never calls TMDB/network resolver.  It is a renderer over
PremiumGridBase catalogue/navigation plus the one persistent Global TMDB Library.
"""
from __future__ import absolute_import
from . import _
from .localization import current_language
import hashlib, json, os, queue, time, threading, shutil, re, tempfile, unicodedata, weakref
from collections import deque
from .core.executor import LazyThreadPoolExecutor
from .core.shared_executors import CATALOGUE_EXECUTOR, METADATA_EXECUTOR
try:
    from PIL import Image as _PILImage, ImageDraw as _ImageDraw, ImageFilter as _ImageFilter
except Exception:
    _PILImage=None;_ImageDraw=None;_ImageFilter=None

from .ui_grid_base import PremiumGridBase
from .ui_async import AsyncScreenMixin
from .artwork_v2 import load_manifest, ArtworkV2, save_manual_rescue_art, _download as _artwork_download
from .tmdb import TMDBClient
from .fanart import fetch_artwork as _fanart_fetch
from .storage import load_settings, load_api_keys
from .persistent_cache import ROOT, GENERATED, INDEX, ensure_persistent_dirs, load_detail_snapshot, load_detail_snapshot_by_tmdb
from .media_library import readiness as _library_readiness, metadata_complete as _metadata_complete
from .core.image_budget import image_budgeted
from .ui_dynamic_chrome import _build_category_extended_backdrop, _build_dynamic_settings_episode_rows, _build_dynamic_details_chrome, _dynamic_palette, _lift_dynamic_accent, _mix_rgb
from .log import optional_failure
from .title_clean import catalogue_title as _catalogue_title
from .ui_icon_menu import IconMenuList
from .services.player_visuals import _adaptive_player_frames, _progress_neon_frame

CINEMATIC_GLOBAL_SKIN=""
_CIN_HYBRID_EXECUTOR=LazyThreadPoolExecutor(max_workers=1, thread_name_prefix="ultrastalker-cinematic-hybrid")
_CIN_PAGE_EXECUTOR=CATALOGUE_EXECUTOR
_CIN_CAST_EXECUTOR=METADATA_EXECUTOR

def configure_cinematic_global(**deps):
    globals().update(deps)
    if "CINEMATIC_GLOBAL_SKIN" in deps:
        PremiumGlobalCinematicScreen.skin=deps["CINEMATIC_GLOBAL_SKIN"]


def _strip_arabic_tashkeel(value):
    """Display-only Arabic diacritic cleanup; stored metadata stays untouched."""
    text=str(value or "")
    return re.sub(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]", "", text)

_CIN_ARAB_CAST_COUNTRY_TOKENS={"EG","LB","SA","AE","KW","QA","BH","OM","JO","SY","IQ","PS","YE","MA","DZ","TN","LY","SD"}

def _cin_person_name_is_latin(value):
    letters=[]
    for ch in str(value or ""):
        try:
            if unicodedata.category(ch).startswith("L"):letters.append(ch)
        except Exception:pass
    if not letters:return False
    for ch in letters:
        try:
            if "LATIN" not in unicodedata.name(ch,""):return False
        except Exception:return False
    return True

def _cin_is_arabic_work(row, item, visible_title=""):
    data={}
    if isinstance(item,dict):data.update(item)
    if isinstance(row,dict):data.update(row)
    if re.search(r"[\u0600-\u06ff]",str(visible_title or "")):return True
    for key in ("original_language","language","lang","audio_language"):
        raw=str(data.get(key) or "").strip().lower().replace("_","-")
        if raw=="ar" or raw.startswith("ar-"):return True
    country=data.get("origin_country") or data.get("country_code") or data.get("country") or data.get("production_countries") or ""
    values=list(country) if isinstance(country,(list,tuple,set)) else [country]
    aliases=("egypt","lebanon","saudi","emirates","kuwait","qatar","bahrain","oman","jordan","syria","iraq","palestine","yemen","morocco","algeria","tunisia","libya","sudan")
    for value in values:
        if isinstance(value,dict):value=value.get("iso_3166_1") or value.get("code") or value.get("name") or ""
        raw=str(value or "").strip();upper=raw.upper();low=raw.casefold()
        if upper in _CIN_ARAB_CAST_COUNTRY_TOKENS or any(x in low for x in aliases):return True
    return False

def _cin_pick_latin_person_name(client, actor):
    if not isinstance(actor,dict):return ""
    for value in (str(actor.get("name") or "").strip(),str(actor.get("original_name") or "").strip()):
        if value and _cin_person_name_is_latin(value):return value
    person_id=actor.get("id")
    if not person_id:return ""
    try:person=client._get("/person/%s"%int(person_id),{"language":"en-US"}) or {}
    except Exception:person={}
    values=[str(person.get("name") or "").strip()]+[str(x or "").strip() for x in (person.get("also_known_as") or [])]
    for value in values:
        if value and _cin_person_name_is_latin(value):return value
    return ""

def _hex_rgb(value, fallback=(202,145,65)):
    value=str(value or "").strip().lstrip("#")
    if len(value)==6:
        try:return tuple(int(value[i:i+2],16) for i in (0,2,4))
        except Exception:pass
    return fallback

@image_budgeted
def _build_cinematic_backdrop(source,target,accent_hex):
    """Build the Cinematic presentation backdrop from the one global HDD image."""
    if _PILImage is None or not source or not os.path.isfile(source):return ""
    if os.path.isfile(target) and os.path.getsize(target)>1024:return target
    if not ensure_persistent_dirs(os.path.dirname(target)):return ""
    temp=target+".tmp.%d"%os.getpid();accent=_hex_rgb(accent_hex,(38,28,18))
    try:
        tw,th=1920,1080;res=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
        with _PILImage.open(source) as src:
            src=src.convert("RGB")
            if src.width<16 or src.height<16:return ""
            scale=max(float(tw)/src.width,float(th)/src.height);nw=max(tw,int(round(src.width*scale)));nh=max(th,int(round(src.height*scale)))
            src=src.resize((nw,nh),res);left=max(0,min(nw-tw,int((nw-tw)*0.58)));top=max(0,(nh-th)//2);src=src.crop((left,top,left+tw,top+th)).convert("RGBA")
        src=_PILImage.alpha_composite(src,_PILImage.new("RGBA",(tw,th),(accent[0]//5,accent[1]//5,accent[2]//5,24)))
        # Premium left rail veil: strong enough to keep the floating rows
        # readable, but feathered so the backdrop never exposes a hard edge.
        left_alpha=[]
        for x in range(780):
            t=float(x)/779.0;left_alpha.append(max(0,min(255,int(236*((1.0-t)**1.85)))))
        la=_PILImage.new("L",(780,1));la.putdata(left_alpha);la=la.resize((780,th))
        veil=_PILImage.new("RGBA",(tw,th),(2,6,10,0));veil.putalpha(_PILImage.new("L",(tw,th),0));veil.alpha_composite(_PILImage.merge("RGBA",(_PILImage.new("L",(780,th),2),_PILImage.new("L",(780,th),6),_PILImage.new("L",(780,th),10),la)),(0,0))
        src=_PILImage.alpha_composite(src,veil)
        # Beta86: match the approved older composition.  The backdrop is strong
        # above the details area, then genuinely fades OUT into a dark adaptive
        # page plane.  Do not merely darken a full-screen wallpaper; the lower
        # area must read as UI background carrying a restrained current-title hue.
        art_alpha=[]
        fade_start,fade_end=470.0,900.0
        for y in range(th):
            if y<=fade_start:a=255
            elif y>=fade_end:a=0
            else:
                tt=(float(y)-fade_start)/(fade_end-fade_start);smooth=tt*tt*(3.0-2.0*tt);a=int(255*(1.0-smooth))
            art_alpha.append(max(0,min(255,a)))
        aa=_PILImage.new("L",(1,th));aa.putdata(art_alpha);aa=aa.resize((tw,th))
        if _ImageFilter is not None:
            try:aa=aa.filter(_ImageFilter.GaussianBlur(radius=9))
            except Exception:pass
        src.putalpha(aa)
        # Beta89: dark adaptive footer, visibly tied to the selected title while still cinematic.
        mood=(max(5,int(accent[0]*0.18)),max(7,int(accent[1]*0.18)),max(10,int(accent[2]*0.18)),255)
        base=_PILImage.new("RGBA",(tw,th),mood)
        # A very subtle vertical lift keeps the footer premium rather than flat.
        md=_ImageDraw.Draw(base) if _ImageDraw is not None else None
        if md is not None:
            lower=(max(4,int(accent[0]*0.12)),max(6,int(accent[1]*0.12)),max(9,int(accent[2]*0.12)),255)
            md.rectangle((0,760,tw,th),fill=lower)
            for yy in range(760,th,12):
                t=(yy-760)/float(max(1,th-760));a=max(0.0,1.0-t)
                col=(max(lower[0],int(accent[0]*(0.16+0.06*a))),
                     max(lower[1],int(accent[1]*(0.16+0.06*a))),
                     max(lower[2],int(accent[2]*(0.16+0.06*a))),255)
                md.rectangle((0,yy,tw,min(th,yy+12)),fill=col)
        src=_PILImage.alpha_composite(base,src)
        src.save(temp,"PNG",compress_level=3);os.replace(temp,target);return target
    except Exception as exc:
        optional_failure("cinematic.backdrop",exc)
        try:
            if os.path.exists(temp):os.unlink(temp)
        except Exception:pass
        return ""

@image_budgeted
def _build_overview_glass(target, accent_hex):
    """Adaptive transparent overview glass derived only from saved adaptive color."""
    if _PILImage is None or _ImageDraw is None:return ""
    if os.path.isfile(target) and os.path.getsize(target)>256:return target
    if not ensure_persistent_dirs(os.path.dirname(target)):return ""
    temp=target+".tmp.%d"%os.getpid();accent=_hex_rgb(accent_hex)
    try:
        w,h=1240,230
        im=_PILImage.new("RGBA",(w,h),(0,0,0,0));d=_ImageDraw.Draw(im)
        # Medium-density adaptive glass: backdrop remains visible through it.
        fill=(max(2,accent[0]//12),max(3,accent[1]//12),max(4,accent[2]//12),132)
        rim=(accent[0],accent[1],accent[2],185)
        d.rounded_rectangle((2,2,w-3,h-3),radius=20,fill=fill,outline=rim,width=2)
        d.rounded_rectangle((5,5,w-6,h-6),radius=17,outline=(255,255,255,34),width=1)
        # Top sheen and bottom mood give depth without turning it into a black slab.
        d.rounded_rectangle((10,7,w-11,48),radius=14,fill=(255,255,255,12))
        d.rounded_rectangle((10,h-58,w-11,h-11),radius=14,fill=(0,0,0,18))
        im.save(temp,"PNG",compress_level=3);os.replace(temp,target);return target
    except Exception as exc:
        optional_failure("cinematic.overview_glass",exc)
        try:
            if os.path.exists(temp):os.unlink(temp)
        except Exception:pass
        return ""


@image_budgeted
def _build_cinematic_exact_chrome(source_path, root, cache_key, accent_override=None):
    """Same adaptive Details material, rendered at Cinematic's exact widget sizes.

    This avoids clipping/scaling the Native Details 1283x142 overview and 815x40
    genre assets into smaller Cinematic widgets, which produced visibly broken
    right edges and jagged rounded corners on the receiver.
    """
    if _PILImage is None or _ImageDraw is None or not source_path or not os.path.isfile(source_path):
        return {}
    try:
        primary,secondary=_dynamic_palette(source_path)
        accent=_lift_dynamic_accent(primary,0.48,0.46)
        override=str(accent_override or "").strip().lstrip("#")
        if len(override)==6:
            try:accent=tuple(int(override[i:i+2],16) for i in (0,2,4))
            except Exception:pass
        accent2=tuple(min(255,int(v*0.78+255*0.22)) for v in accent) if accent_override else _lift_dynamic_accent(secondary,0.42,0.38)
        base=(3,12,20)
        specs={
            "panel":((1325,370),30,"panel"),
            "overview":((965,220),22,"overview"),
            "quality":((150,50),22,"pill"),
            "year":((130,50),22,"pill"),
            "runtime":((150,50),22,"pill"),
            "country":((160,50),22,"pill"),
            "genre":((335,50),22,"pill"),
        }
        result={}
        ensure_persistent_dirs(root)
        for name,(size,radius,kind) in specs.items():
            target=os.path.join(root,"cin89_exact_%s_%s.png"%(cache_key,name))
            if os.path.isfile(target) and os.path.getsize(target)>256:
                result[name]=target;continue
            temp=target+".tmp.%d"%os.getpid();w,h=size
            out=_PILImage.new("RGBA",size,(0,0,0,0))
            glow=_PILImage.new("RGBA",size,(0,0,0,0));gd=_ImageDraw.Draw(glow)
            gd.rounded_rectangle((6,6,w-7,h-7),radius=radius,outline=accent+((92 if kind in ("panel","overview") else 78),),width=3)
            if _ImageFilter is not None:
                try:glow=glow.filter(_ImageFilter.GaussianBlur(radius=7 if kind in ("panel","overview") else 5))
                except Exception:pass
            out=_PILImage.alpha_composite(out,glow);d=_ImageDraw.Draw(out)
            fill=_mix_rgb(base,accent,0.10 if kind in ("panel","overview") else 0.14)
            if kind=="panel":fa,ba=62,174
            elif kind=="overview":fa,ba=82,188
            else:fa,ba=98,196
            d.rounded_rectangle((2,2,w-3,h-3),radius=radius,fill=fill+(fa,),outline=accent+(ba,),width=1)
            inner=_mix_rgb(accent2,(255,255,255),0.46)
            d.rounded_rectangle((7,7,w-8,h-8),radius=max(5,radius-6),outline=inner+(22,),width=1)
            sheen=_PILImage.new("RGBA",size,(0,0,0,0));sd=_ImageDraw.Draw(sheen)
            sd.rounded_rectangle((12,7,w-13,max(14,h//2)),radius=max(5,radius-8),fill=inner+((17 if kind in ("panel","overview") else 13),))
            if _ImageFilter is not None:
                try:sheen=sheen.filter(_ImageFilter.GaussianBlur(radius=4 if kind in ("panel","overview") else 3))
                except Exception:pass
            out=_PILImage.alpha_composite(out,sheen)
            out.save(temp,"PNG",compress_level=3);os.replace(temp,target);result[name]=target
        return result
    except Exception as exc:
        optional_failure("cinematic.exact_chrome",exc);return {}


_COUNTRY_NAMES = {
    "EG":"مصر","LB":"لبنان","SA":"السعودية","AE":"الإمارات","KW":"الكويت","QA":"قطر","BH":"البحرين","OM":"عُمان","JO":"الأردن","SY":"سوريا","IQ":"العراق","PS":"فلسطين","YE":"اليمن","MA":"المغرب","DZ":"الجزائر","TN":"تونس","LY":"ليبيا","SD":"السودان","US":"USA","GB":"UK","FR":"France","DE":"Germany","IT":"Italy","ES":"Spain","TR":"Turkey","IN":"India","KR":"Korea","JP":"Japan","CN":"China","CA":"Canada","MX":"Mexico","BR":"Brazil","AR":"Argentina","RU":"Russia","AU":"Australia"
}
_COUNTRY_CODES_EN = {
    "EG":"EG","LB":"LB","SA":"KSA","AE":"UAE","KW":"KW","QA":"QA","BH":"BH","OM":"OM","JO":"JO","SY":"SY","IQ":"IQ","PS":"PS","YE":"YE","MA":"MA","DZ":"DZ","TN":"TN","LY":"LY","SD":"SD",
    "US":"USA","GB":"UK","FR":"FR","DE":"DE","IT":"IT","ES":"ES","TR":"TR","IN":"IN","KR":"KR","JP":"JP","CN":"CN","CA":"CA","MX":"MX","BR":"BR","AR":"AR","RU":"RU","AU":"AU"
}

def _country_code(value):
    if isinstance(value,(list,tuple,set)):
        for row in value:
            code=_country_code(row)
            if code:return code
        return ""
    if isinstance(value,dict):
        for key in ("iso_3166_1","country_code","code","name"):
            code=_country_code(value.get(key))
            if code:return code
        return ""
    raw=str(value or "").strip()
    if not raw:return ""
    upper=raw.upper().strip()
    aliases={
        "EGYPT":"EG","ARAB REPUBLIC OF EGYPT":"EG","مصر":"EG","جمهورية مصر العربية":"EG",
        "LEBANON":"LB","لبنان":"LB","SAUDI ARABIA":"SA","السعودية":"SA",
        "UNITED ARAB EMIRATES":"AE","UAE":"AE","الإمارات":"AE",
        "UNITED STATES":"US","UNITED STATES OF AMERICA":"US","USA":"US",
        "UNITED KINGDOM":"GB","GREAT BRITAIN":"GB","UK":"GB",
        "TURKEY":"TR","TÜRKIYE":"TR","TURKIYE":"TR",
        "SOUTH KOREA":"KR","REPUBLIC OF KOREA":"KR","KOREA":"KR",
        "NORTH KOREA":"KP","JAPAN":"JP","CHINA":"CN","INDIA":"IN",
        "FRANCE":"FR","GERMANY":"DE","ITALY":"IT","SPAIN":"ES",
        "CANADA":"CA","MEXICO":"MX","BRAZIL":"BR","ARGENTINA":"AR",
        "RUSSIA":"RU","RUSSIAN FEDERATION":"RU","AUSTRALIA":"AU",
        "KUWAIT":"KW","QATAR":"QA","BAHRAIN":"BH","OMAN":"OM",
        "JORDAN":"JO","SYRIA":"SY","IRAQ":"IQ","PALESTINE":"PS",
        "MOROCCO":"MA","ALGERIA":"DZ","TUNISIA":"TN","LIBYA":"LY","SUDAN":"SD"
    }
    if upper in aliases:return aliases[upper]
    for code,name in _COUNTRY_NAMES.items():
        if upper==str(name).upper():return code
    if len(upper)==2 and upper.isalpha():return upper
    return ""

def _normalized_country(value):
    code=_country_code(value);raw=str(value or "").strip()
    if current_language()=="en":
        return _COUNTRY_CODES_EN.get(code,code or (raw[:12] if raw else ""))
    return _COUNTRY_NAMES.get(code,raw[:12] if raw else "")

def _quality_asset_name(value):
    import re
    text=str(value or "").upper()
    if re.search(r"\b(?:4K|UHD|2160P?)\b",text):return "us65_quality_4k_122x34.png"
    if re.search(r"\b(?:FULL[ ._-]?HD|FHD|1080P?)\b",text):return "us65_quality_fullhd_122x34.png"
    if re.search(r"\b(?:HD|720P?)\b",text):return "us65_quality_hd_122x34.png"
    if re.search(r"\b(?:SD|576P?|480P?)\b",text):return "us93_quality_sd_122x34.png"
    return None



@image_budgeted
def _cinematic_row_progress_frame(accent_hex, value, width=300):
    """Exact Player laser grammar rendered at the rail's native width.

    Enigma2 MultiContent clips pixmaps instead of scaling them. The Player asset
    is 1350px wide, so using it inside a 300px rail slot made 7% and 60% look
    almost the same. This keeps the Player drawing algorithm but renders it at
    the row's real width, making beam length mathematically match resume %.
    """
    if _PILImage is None or _ImageDraw is None:return ""
    try:
        value=max(0,min(100,int(value)))
        hx=str(accent_hex or "#55b9ff").lstrip("#")
        if len(hx)!=6:hx="55b9ff"
        accent=tuple(int(hx[i:i+2],16) for i in (0,2,4))
        root=os.path.join(GENERATED,"cinematic_row_progress6560")
        if not ensure_persistent_dirs(root):return ""
        w=max(80,min(600,int(width or 300)));h=34
        target=os.path.join(root,"%s_%03d_%03d.png"%(hx,value,w))
        if os.path.isfile(target) and os.path.getsize(target)>128:return target
        img=_PILImage.new("RGBA",(w,h),(0,0,0,0))
        if value<=0:img.save(target,"PNG");return target
        # release: keep a real end-cap safety zone inside the native pixmap.
        # Older cached 100% frames ended too close to the right edge, so Enigma2's
        # MultiContent clipping visually shaved the flare/dot.  The percentage stays
        # exactly where it is; only the watched beam gets 24px of breathing room.
        end=max(2,min(w-24,int(round((w-28)*value/100.0))));y=h//2
        bloom=_PILImage.new("RGBA",(w,h),(0,0,0,0));bd=_ImageDraw.Draw(bloom)
        bd.line((2,y,end,y),fill=accent+(205,),width=11)
        if _ImageFilter is not None:bloom=bloom.filter(_ImageFilter.GaussianBlur(radius=6))
        img=_PILImage.alpha_composite(img,bloom)
        halo=_PILImage.new("RGBA",(w,h),(0,0,0,0));hd=_ImageDraw.Draw(halo)
        hd.line((2,y,end,y),fill=accent+(245,),width=7)
        if _ImageFilter is not None:halo=halo.filter(_ImageFilter.GaussianBlur(radius=2.8))
        img=_PILImage.alpha_composite(img,halo);d=_ImageDraw.Draw(img)
        hot=tuple(min(255,int(v*.48+255*.52)) for v in accent);core=tuple(min(255,int(v*.20+255*.80)) for v in accent)
        d.line((2,y,end,y),fill=hot+(255,),width=4);d.line((2,y,end,y),fill=core+(255,),width=2)
        flare=_PILImage.new("RGBA",(w,h),(0,0,0,0));fd=_ImageDraw.Draw(flare)
        fd.line((max(2,end-28),y,end+min(16,w-1-end),y),fill=core+(250,),width=5)
        fd.line((end,max(1,y-9),end,min(h-2,y+9)),fill=core+(210,),width=2)
        fd.ellipse((end-5,y-5,end+5,y+5),fill=(255,255,255,250))
        if _ImageFilter is not None:flare=flare.filter(_ImageFilter.GaussianBlur(radius=4.0))
        img=_PILImage.alpha_composite(img,flare);d=_ImageDraw.Draw(img);d.ellipse((end-2,y-2,end+2,y+2),fill=(255,255,255,255))
        temp=target+".tmp.%d"%os.getpid();img.save(temp,"PNG");os.replace(temp,target);return target
    except Exception as exc:
        optional_failure("cinematic.row_progress_frame",exc);return ""

class PremiumGlobalCinematicScreen(PremiumGridBase):
    """Cinematic list presentation over the exact same Global TMDB record."""

    # Cinematic is a vertical Settings/Episodes list, not a poster grid.  The
    # inherited PremiumGridBase constructor calls self._grid_art_init(), so an
    # override here prevents the hidden 1x1 GridArtwork ePicLoad from ever being
    # constructed.  This is intentionally done before PremiumGridBase.__init__
    # runs; stopping it later is too late because OpenBH has already allocated
    # the native decoder/surface.
    def _grid_art_init(self, slot_names, image_size, profile, client):
        self._grid_slot_names=[]
        self._grid_image_size=(0,0)
        self._grid_profile=profile
        self._grid_client=client
        self._grid_generation=0
        self._grid_download_jobs=queue.Queue()
        self._grid_decode_queue=[]
        self._grid_decode_busy=False
        self._grid_decode_active=None
        self._grid_closed=False
        self._grid_decode_cache={}
        self._grid_decode_cache_limit=0
        self._grid_waiting={}
        self._grid_queued=set()
        self._grid_slot_paths={}
        self._grid_palette_sources={}
        self._grid_accent_jobs=queue.Queue()
        self._grid_accent_pending=set()
        self._grid_download_inflight={}
        self._grid_download_futures={}
        self._grid_poster_thumb_pending=set()
        self._grid_download_lock=threading.Lock()
        self._grid_picload=None
        self._grid_pic_connection=None

    def _grid_art_layout_ready(self):
        # No hidden GridArtwork decoder exists in Cinematic.
        return

    def _grid_layout_ready(self):
        # Preserve PremiumGridBase catalogue/navigation startup while skipping
        # its selector/grid-art setup.  This is the only page bootstrap the
        # Cinematic screen needs.
        try:self._update_grid_clock()
        except Exception:pass
        self.load_page(self._restore_page,self._restore_index)

    def _grid_hidden_release(self):
        self._grid_images_suspended=True

    def _cin_release_surfaces_for_child(self):
        """Release only rendered/native Cinematic surfaces before a child opens.

        Canonical poster/backdrop files stay on HDD and their paths are retained.
        This is a gAccel surface-budget handoff, not an artwork/cache eviction.
        Releasing here happens *before* Details is instantiated, which gives the
        receiver room for the child's 1620x620/backdrop/glass allocations.
        """
        saved={}
        try:
            for base in ("cin_backdrop",):
                active=self._cin_active_pixmap.get(base,base)
                path=str(self._cin_pixmap_paths.get(active) or "")
                if path and os.path.isfile(path):saved[base]=path
        except Exception as exc:optional_failure("cinematic.surface_budget_capture",exc)
        # Preserve lightweight chrome paths too, but drop their native gPixmaps.
        try:
            for name,path in dict(getattr(self,"_cin_widget_paths",{}) or {}).items():
                if path and os.path.isfile(str(path)):saved["widget:"+str(name)]=str(path)
        except Exception as exc:optional_failure("cinematic.surface_budget_capture_chrome",exc)
        self._cin_suspended_visual_paths=saved

        # The large backdrop/panel surfaces are the important wins. Small labels
        # remain untouched; only native image surfaces are released.
        heavy=(
            "cin_backdrop","cin_backdrop_stage",
            "panel_bg","overview_bg","quality_pill_bg","year_pill_bg",
            "runtime_pill_bg","country_pill_bg","genre_pill_bg",
            "quality_logo","runtime_icon","country_flag"
        )
        for name in heavy:
            try:_release_pixmap_widget(self,name)
            except Exception as exc:optional_failure("cinematic.surface_budget_release",exc)
        self._cin_pixmap_paths.clear();self._cin_widget_paths.clear()
        self._cin_active_pixmap={"cin_backdrop":"cin_backdrop"}
        try:_native_image_pressure_relief(force=True)
        except Exception as exc:optional_failure("cinematic.surface_budget_relief",exc)

    def _cin_restore_surfaces_after_child(self):
        """HDD-only rebind of the exact visuals released for the child."""
        saved=dict(getattr(self,"_cin_suspended_visual_paths",{}) or {})
        if not saved:return
        try:
            for base in ("cin_backdrop",):
                path=str(saved.get(base) or "")
                if path and os.path.isfile(path) and self[base].instance is not None:
                    self[base].instance.setPixmapFromFile(path);self[base].show()
                    self._cin_pixmap_paths[base]=path;self._cin_active_pixmap[base]=base
            for key,path in saved.items():
                if not str(key).startswith("widget:"):continue
                name=str(key)[7:]
                if not path or not os.path.isfile(path):continue
                try:
                    if self[name].instance is not None:
                        self[name].instance.setPixmapFromFile(path);self[name].show();self._cin_widget_paths[name]=path
                except Exception as exc:optional_failure("cinematic.surface_budget_restore_widget",exc)
        except Exception as exc:optional_failure("cinematic.surface_budget_restore",exc)
        self._cin_suspended_visual_paths={}

    def _cin_force_cached_visual_rebind(self):
        """Rebind only already-cached cinematic pixmaps after Player returns.

        OpenBH can keep the Python path markers while dropping the native gPixmap
        surfaces during video playback.  Clear + bind the exact same HDD files;
        never rebuild artwork, hit TMDb, or change the selected item.
        """
        try:
            for base in ("cin_backdrop",):
                active=self._cin_active_pixmap.get(base,base)
                path=str(self._cin_pixmap_paths.get(active) or "")
                if path and os.path.isfile(path) and self[active].instance is not None:
                    try:self[active].instance.setPixmap(None)
                    except Exception:pass
                    self[active].instance.setPixmapFromFile(path);self[active].show()
            for name,path in dict(getattr(self,"_cin_widget_paths",{}) or {}).items():
                path=str(path or "")
                if not path or not os.path.isfile(path):continue
                try:
                    if self[name].instance is not None:
                        self[name].instance.setPixmap(None)
                        self[name].instance.setPixmapFromFile(path);self[name].show()
                except Exception as exc:optional_failure("cinematic.player_return_rebind_widget",exc)
            logo=str(getattr(self,"_cin_logo_path","") or "")
            if logo and os.path.isfile(logo) and self["title_logo"].instance is not None:
                try:self["title_logo"].instance.setPixmap(None)
                except Exception:pass
                self["title_logo"].instance.setPixmapFromFile(logo);self["title_logo"].show()
        except Exception as exc:optional_failure("cinematic.player_return_rebind",exc)

    def _pause_grid_background_for_child(self):
        # Keep the accepted Fast-Navigation cancellations, then free only native
        # rendered surfaces. No poster/backdrop file is deleted or re-downloaded.
        try:PremiumGridBase._pause_grid_background_for_child(self)
        except Exception as exc:optional_failure("cinematic.child_pause_base",exc)
        self._cin_cancel_focus(enqueue=False);self._cin_cancel_background()
        self._cin_release_surfaces_for_child()

    def _prepare_grid_page(self,target,cancel_event=None):
        """Catalogue-only page preparation for Cinematic.

        PremiumGridBase prepares poster-grid thumbnails/card chrome while it
        builds a page.  On this screen image_size is intentionally 1x1, which
        created gridposter_*_1x1 files and native gSurfaces even though no grid
        exists.  Keep only catalogue/state/text preparation here; all visual
        ownership belongs to the explicit Cinematic pipeline.
        """
        data=self._grid_page_data(target,cancel_event)
        valid=[x for x in data if isinstance(x,dict)] if isinstance(data,list) else []
        if self.media_type in ("vod","series"):
            # Preserve only the direct provider artwork URLs in private fields
            # before the structural Stalker artwork strip. Cinematic may hydrate
            # the *focused* title from these URLs, but the catalogue itself stays
            # clean and no page-wide image engine is re-enabled.
            originals=[dict(x) for x in valid]
            poster_counts={};backdrop_counts={}
            for src in originals:
                try:
                    pv=str(_image_url(src) or "").strip();bv=str(_backdrop_url(src) or "").strip()
                    if pv:poster_counts[pv]=poster_counts.get(pv,0)+1
                    if bv:backdrop_counts[bv]=backdrop_counts.get(bv,0)+1
                except Exception:pass
            rebuilt=[]
            for src in originals:
                try:
                    pv=str(_image_url(src) or "").strip();bv=str(_backdrop_url(src) or "").strip()
                    clean=dict(src) if src.get("_xtream") else _strip_portal_artwork(src)
                    # Repeated page-wide artwork is almost always a provider
                    # placeholder. Do not promote it into a title identity.
                    if pv and poster_counts.get(pv,0)<3:clean["_cin_provider_poster_url"]=pv
                    if bv and backdrop_counts.get(bv,0)<4:clean["_cin_provider_backdrop_url"]=bv
                    rebuilt.append(clean)
                except Exception:
                    rebuilt.append(dict(src))
            valid=rebuilt
        try:states=load_content_states(self.profile,self.media_type,valid) if valid else []
        except Exception:states=[{} for _ in valid]
        try:qualities=load_content_qualities(self.profile,self.media_type,valid) if valid and self.media_type in ("vod","series") else ["" for _ in valid]
        except Exception:qualities=["" for _ in valid]
        cfg=self._grid_settings or {};state_rows=[];titles=[];fitted=[];meta=[]
        for pos,item in enumerate(valid):
            state=states[pos] if pos<len(states) else {};quality=qualities[pos] if pos<len(qualities) else ""
            row=dict(state or {});row["quality"]=quality or "";state_rows.append(row)
            raw=item.get("name") or item.get("title") or item.get("id") or "Item"
            title=_catalogue_title(raw);titles.append(title);fitted.append((title,None))
            bits=[]
            try:
                explicit=self._explicit_item_quality(item);badges=explicit or str(row.get("quality") or "") or quality_badges(raw)
                if badges:bits.append(badges)
            except Exception:pass
            if item.get("year"):bits.append(str(item.get("year"))[:4])
            if row.get("favorite"):bits.append("★")
            if row.get("completed") and cfg.get("show_watched",True):bits.append("WATCHED")
            elif row.get("position") and row.get("duration"):
                try:bits.append("%d%%"%min(99,int(row["position"]*100.0/row["duration"])))
                except Exception:pass
            meta.append("  •  ".join(bits)[:28])
        return {"items":valid,"states":state_rows,"titles":titles,"fitted":fitted,"meta":meta,"art":[{} for _ in valid]}

    # Grid-only background engines must never wake inside Cinematic.  Focused
    # artwork/cache policy is owned exclusively by the _cin_* pipeline below.
    def _poll_visible_poster_cache(self):return
    def _start_visible_poster_watch(self):return
    def _start_progressive_poster_prefetch(self):return
    def _prefetch_visible_page_details(self,*args,**kwargs):return
    def _prefetch_selected_details(self):return
    def _prefetch_selected_series_hierarchy(self):return
    def _warm_idle_grid_page(self):return
    skin=CINEMATIC_GLOBAL_SKIN
    columns=1;page_size=12;image_size=(1,1);placeholder="grid_placeholder_movie_921.png";selection_asset="portal_selection_clear.png"
    card_positions=[(50,130+i*73) for i in range(12)]

    def __init__(self,session,profile,client,media_type,genre,category_title=""):
        self._cin_record_key="";self._cin_visual_key="";self._cin_jobs=queue.Queue();self._cin_pending=set();self._cin_last_record={};self._cin_row_refresh_cursor=0;self._cin_row_complete=set();self._cin_page_records={};self._settings_row_asset=asset("series_floating_row.png");self._settings_row_selected_asset=self._settings_row_asset;self._cin_progress_accent="#69c9f4"
        # Beta103 hybrid policy: only the focused title may hydrate while browsing.
        # Everything completed is persisted as one immutable HDD package and reused forever.
        self._cin_package_schema=4
        self._cin_focus_cancel=None;self._cin_focus_future=None;self._cin_focus_sig=""
        self._cin_background_cancel=None;self._cin_background_future=None
        self._cin_missed=deque();self._cin_missed_keys=set();self._cin_last_focus_item=None
        self._cin_last_nav_at=time.monotonic();self._cin_hidden=False
        self._cin_active_pixmap={"cin_backdrop":"cin_backdrop"};self._cin_pixmap_paths={};self._cin_widget_paths={};self._cin_suspended_visual_paths={}
        # release: page-local trusted package/backdrop index. Navigation must never
        # open package JSON or scan the HDD after an arrow press. The tiny package
        # files are indexed once when the page is painted; only the selected JPEG
        # is decoded on demand.
        self._cin_page_packages={};self._cin_page_backdrops={}
        # release: provider-key aliases point straight at the FINAL prepared Cinematic backdrop.
        self._cin_nav_alias_ram={}
        self._cin_logo_pending=set();self._cin_logo_path=""
        self._cin_cast_pending=set();self._cin_cast_cache={}
        self._folder_artwork_worker_window=1
        self._cin_cache_exclusive=False
        self._folder_artwork_fast_art_only=False
        PremiumGridBase.__init__(self,session,profile,client,media_type,genre,category_title)
        # Beta67: the right side is the native Details information cluster itself.
        # Catalogue/navigation/HDD hydration remain owned by PremiumGridBase.
        self["cin_backdrop"]=Pixmap()
        self["cin_backdrop_stage"]=Pixmap()
        self["title_logo"]=Pixmap()
        self["artwork_status_bg"]=Pixmap()
        for name in ("panel_bg","overview_bg","cast_card_bg","quality_pill_bg","year_pill_bg","runtime_pill_bg","country_pill_bg","genre_pill_bg","quality_logo","runtime_icon","country_flag"):
            self[name]=Pixmap()
        for name in ("name","quality_text","year_text","runtime_text","country_text","genre_text","cast_text","description"):
            self[name]=Label("")
        # Exact Settings / Series-Episodes row component. No Cinematic-specific row widgets remain.
        self["cin_list"]=IconMenuList([], width=430, item_height=73, icon_size=40, primary_font=21, secondary_font=15, row_style="settings_episode")
        self._cin_list_icon=asset("settings_icons/artwork.png")
        self._cin_poll=eTimer();self._cin_poll_conn=None;self._cin_poll_interval=600
        try:self._cin_poll_conn=self._cin_poll.timeout.connect(self._cin_poll_hdd)
        except Exception:self._cin_poll.callback.append(self._cin_poll_hdd)
        self.onLayoutFinish.append(self._cin_layout_ready);self.onClose.append(self._cin_stop)
        try:self.onHide.append(self._cin_hidden_start)
        except Exception:pass
        self["section"].setText("")
        self["blue"].setText(_("Cache Artwork"))
        # Exact SeriesEpisodes direction grammar. PremiumGridBase's grid left/right
        # means adjacent card; Cinematic is a vertical episode-style list, so
        # LEFT/RIGHT must page while UP/DOWN move one row with global wrap.
        self["actions"] = ActionMap(["OkCancelActions","ColorActions","DirectionActions","MenuActions","InfoActions"], {
            "cancel":self.close,"red":self.open_folder_search,"ok":self.open_selected,
            "left":self._cin_page_left,"right":self._cin_page_right,
            "up":self._cin_wrap_up,"down":self._cin_wrap_down,
            "green":self.toggle_selected_favorite,"yellow":self.cycle_folder_sort,
            "blue":self.cache_folder_artwork,"menu":self.open_menu,"info":self.show_information},-1)

    def _cin_sharp_details_overview(self, source):
        """Use the same nine-slice sharpening geometry as Details: 1318x170."""
        try:
            source=str(source or "")
            if not source or not os.path.isfile(source):return ""
            tw,th=1318,170
            with _PILImage.open(source) as probe:sw,sh=probe.size
            if (sw,sh)==(tw,th):return source
            root=os.path.join(THUMB_CACHE_DIR,"cinematic_details_overview_v6532")
            if not os.path.isdir(root):os.makedirs(root,mode=0o700)
            stamp="%s|%s|%s|%s"%(source,os.path.getmtime(source),tw,th)
            out=os.path.join(root,hashlib.sha1(stamp.encode("utf-8","ignore")).hexdigest()[:24]+".png")
            if os.path.isfile(out) and os.path.getsize(out)>256:return out
            with _PILImage.open(source) as im:
                im=im.convert("RGBA");sw,sh=im.size
                cx=max(10,min(38,sw//5,tw//5));cy=max(8,min(22,sh//4,th//4))
                left=right=cx;top=bottom=cy
                canvas=_PILImage.new("RGBA",(tw,th),(0,0,0,0))
                sx=(0,left,sw-right,sw);sy=(0,top,sh-bottom,sh)
                dx=(0,left,tw-right,tw);dy=(0,top,th-bottom,th)
                res=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
                for yi in range(3):
                    for xi in range(3):
                        tile=im.crop((sx[xi],sy[yi],sx[xi+1],sy[yi+1]))
                        size=(dx[xi+1]-dx[xi],dy[yi+1]-dy[yi])
                        if tile.size!=size:tile=tile.resize(size,res)
                        canvas.alpha_composite(tile,(dx[xi],dy[yi]))
                temp=out+".tmp.%s"%os.getpid();canvas.save(temp,"PNG",optimize=True);os.replace(temp,out)
            return out
        except Exception as exc:
            optional_failure("cinematic.details_overview_sharp",exc);return str(source or "")

    def _cin_apply_details_overview(self,item,row):
        """Adopt Native Details chrome only when its exact adaptive files exist.

        Never replace an already-applied adaptive Cinematic/Details cluster with
        neutral fallbacks.  The cold-shell fallback is owned by _cin_layout_ready.
        """
        try:
            bundle=_load_visual_bundle(self.profile,self.media_type,item,row) or {}
            chrome=bundle.get("chrome") if isinstance(bundle.get("chrome"),dict) else {}
            if chrome:self._apply_native_detail_chrome(chrome)
        except Exception as exc:optional_failure("cinematic.details_cluster_apply",exc)

    def _cin_title_logo_signature(self,item,row):
        try:
            tmdb_id=int((row or {}).get("tmdb_id") or 0)
            if not tmdb_id:return ("","")
            title=self._rail_title(item,row) or str((row or {}).get("title") or (row or {}).get("name") or "")
            lang="ar" if re.search(r"[\u0600-\u06ff]",str(title or "")) else "en"
            return ("%s:%s:%s"%(self.media_type,tmdb_id,lang),self._blue_title_logo_cache_path(self.media_type,tmdb_id,lang))
        except Exception:return ("","")

    def _cin_title_logo_display_target(self,source):
        """Return the Cinematic fitted-logo cache path without decoding artwork."""
        try:
            source=str(source or "")
            if not source or not os.path.isfile(source) or os.path.getsize(source)<=256:return ""
            st=os.stat(source)
            stamp="%s|%s"%(int(getattr(st,"st_mtime_ns",int(st.st_mtime*1000000000))),int(st.st_size))
            digest=hashlib.sha1((source+"|"+stamp+"|cinematic-title-logo-420x144-v1").encode("utf-8","ignore")).hexdigest()[:20]
            return os.path.join(THUMB_CACHE_DIR,"title_logos","cinematic_%s_420x144_v1.png"%digest)
        except Exception:return ""

    def _cin_prepare_title_logo_display(self,source):
        """Build the fitted 420x144 Cinematic logo on the background worker only."""
        try:
            source=str(source or "");target=self._cin_title_logo_display_target(source)
            if _PILImage is None or not target:return ""
            if os.path.isfile(target) and os.path.getsize(target)>256:return target
            os.makedirs(os.path.dirname(target),mode=0o700,exist_ok=True)
            with _PILImage.open(source) as src:
                im=src.convert("RGBA")
                try:
                    bbox=im.getchannel("A").getbbox()
                    if bbox:im=im.crop(bbox)
                except Exception:pass
                if im.width<2 or im.height<2:return ""
                max_w,max_h=404,132
                scale=min(float(max_w)/float(im.width),float(max_h)/float(im.height),1.35)
                nw=max(1,int(round(im.width*scale)));nh=max(1,int(round(im.height*scale)))
                if (nw,nh)!=im.size:
                    res=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
                    im=im.resize((nw,nh),res)
                canvas=_PILImage.new("RGBA",(420,144),(0,0,0,0))
                canvas.alpha_composite(im,((420-nw)//2,max(0,(144-nh)//2)))
                tmp=target+".tmp.%s"%os.getpid()
                canvas.save(tmp,"PNG",compress_level=1);os.replace(tmp,target)
            return target if os.path.isfile(target) and os.path.getsize(target)>256 else ""
        except Exception as exc:
            optional_failure("cinematic.title_logo_display_prepare",exc);return ""

    def _cin_show_title_logo(self,item,row):
        """Show the Details title-logo cleanly on Cinematic without aspect stretch."""
        sig,path=self._cin_title_logo_signature(item,row);source_hint=""
        try:
            if path and os.path.isfile(path) and os.path.getsize(path)>256:
                source_hint=path;display_path=self._cin_title_logo_display_target(path)
                if display_path and os.path.isfile(display_path) and os.path.getsize(display_path)>256 and self["title_logo"].instance is not None:
                    if self._cin_logo_path!=display_path:self["title_logo"].instance.setPixmapFromFile(display_path);self._cin_logo_path=display_path
                    self["title_logo"].show()
                    return
            self["title_logo"].hide();self._cin_logo_path=""
        except Exception:pass
        if not sig or sig in self._cin_logo_pending:return
        self._cin_logo_pending.add(sig);item_copy=dict(item or {});row_copy=dict(row or {});source_hint=str(source_hint or "")
        def worker():
            result=""
            try:
                source=source_hint or (self._cache_title_logo_for_blue(item_copy,row_copy,None) or "")
                result=self._cin_prepare_title_logo_display(source) if source else ""
            except Exception as exc:optional_failure("cinematic.title_logo_prepare",exc)
            try:self._cin_jobs.put({"kind":"title_logo","sig":sig,"path":result})
            except Exception:pass
        try:
            _CIN_HYBRID_EXECUTOR.submit(worker);self._cin_kick_poll()
        except Exception:self._cin_logo_pending.discard(sig)

    def _cin_nav_total_pages(self):
        total=int(self._active_total() or 0)
        return max(1,(total+self.page_size-1)//self.page_size) if total else max(1,int(self.page or 1))

    def _cin_prefetch_catalogue_pages(self):
        """Focus-driven runtime: never warm neighbouring catalogue pages."""
        return
        if getattr(self,"_cin_page_warm_running",False):return
        total=int(self._active_total() or 0)
        if total<=self.page_size:return
        total_pages=max(1,(total+self.page_size-1)//self.page_size)
        current=max(1,min(int(self.page or 1),total_pages))
        targets=[]
        for p in (current+1,current-1):
            if 1<=p<=total_pages and p!=current and p not in targets:
                targets.append(p)
        if not targets:return
        self._cin_page_warm_running=True
        def worker():
            try:
                for target in targets:
                    if getattr(self,"_screen_closed",False):break
                    with self._prepared_page_lock:
                        if target in self._prepared_page_cache:continue
                    try:
                        payload=self._prepare_grid_page(target,None)
                        if payload:self._cache_prepared_page(target,payload)
                    except Exception as exc:optional_failure("cinematic.catalogue_page_warm",exc)
            finally:self._cin_page_warm_running=False
        try:_CIN_PAGE_EXECUTOR.submit(worker)
        except Exception as exc:self._cin_page_warm_running=False;optional_failure("cinematic.catalogue_page_warm_submit",exc)

    def _apply_prepared_page(self,target,payload,restore_index=None):
        ok=PremiumGridBase._apply_prepared_page(self,target,payload,restore_index)
        if ok:
            try:self._cin_prefetch_catalogue_pages()
            except Exception as exc:optional_failure("cinematic.catalogue_page_warm_start",exc)
        return ok

    def _cin_wrap_up(self):
        # Copy of SeriesEpisodes wrap_up semantics over provider-backed pages.
        if not self.grid_items or not self._nav_allowed():return
        if self.index>0:
            self.index-=1;self._update_selection();return
        if self.page>1:
            self.load_page(self.page-1,self.page_size-1);return
        total=int(self._active_total() or 0)
        if total>0:
            self.load_page(self._cin_nav_total_pages(),self.page_size-1)
        else:
            self.index=max(0,len(self.grid_items)-1);self._update_selection()

    def _cin_wrap_down(self):
        # Copy of SeriesEpisodes wrap_down semantics: last row -> next page row 1,
        # and the global final item wraps to the very first item.
        if not self.grid_items or not self._nav_allowed():return
        if self.index<len(self.grid_items)-1:
            self.index+=1;self._update_selection();return
        total_pages=self._cin_nav_total_pages()
        if self.page>=total_pages:
            self.load_page(1,0);return
        self.load_page(self.page+1,0)

    def _cin_page_left(self):
        # Exact episode-list page_left grammar: preserve row where possible;
        # LEFT on page 1 resolves to the first item.
        if not self.grid_items or not self._nav_allowed():return
        row=max(0,int(self.index or 0))
        if self.page>1:self.load_page(self.page-1,row)
        else:
            self.index=0;self._update_selection()

    def _cin_page_right(self):
        # Exact episode-list page_right grammar: preserve row where possible;
        # RIGHT on the final page resolves to the final item.
        if not self.grid_items or not self._nav_allowed():return
        row=max(0,int(self.index or 0));last=self._cin_nav_total_pages()
        if self.page<last:self.load_page(self.page+1,row)
        else:
            self.index=max(0,len(self.grid_items)-1);self._update_selection()

    def _cin_layout_ready(self):
        try:self["cin_backdrop_stage"].hide()
        except Exception:pass
        try:self["title_logo"].hide()
        except Exception:pass
        try:
            self._set_native_pixmap("artwork_status_bg","us66_neutral_pill_genre.png")
            self["artwork_status_bg"].hide()
        except Exception:pass
        # Test111: the visual shell is unconditional. Artwork arrival must never
        # decide whether the Details-style cards exist, so a cold folder still
        # opens as a complete, intentional Cinematic page.
        self._apply_native_detail_chrome({})
        for _w,_a in (("panel_bg","us66_neutral_panel.png"),
                      ("quality_pill_bg","us66_neutral_pill_quality.png"),("year_pill_bg","us66_neutral_pill_year.png"),
                      ("runtime_pill_bg","us66_neutral_pill_runtime.png"),("country_pill_bg","us66_neutral_pill_country.png"),
                      ("genre_pill_bg","us66_neutral_pill_genre.png")):
            self._set_native_pixmap(_w,_a)
        self._set_native_pixmap("overview_bg",self._cin_sharp_details_overview(asset("us89_overview_card.png")))
        # Cinematic paints selection entirely inside the Settings/Episodes row
        # renderer. Disable Enigma2's native listbox selection layer, otherwise
        # some OpenBH skins inject the red rectangular slab seen on receiver.
        try:
            if self["cin_list"].instance is not None:self["cin_list"].instance.setSelectionEnable(0)
        except Exception as exc:optional_failure("cinematic.native_selection",exc)
        # Beta75: drain completed HDD visual jobs quickly enough that a ready
        # backdrop does not sit in the queue for half a second after navigation.
        # Re-run the exact Details season/runtime fit only after Enigma has
        # instantiated the label and its real 102px width is available.
        self._cin_fit_runtime_like_details()
        try:self._cin_set_poll_interval(120 if self._cin_poll_has_pending_work() else 600,force=True)
        except Exception as exc:optional_failure("cinematic.poll_start",exc)

    def _set_native_pixmap(self,widget,path):
        try:
            if path and not os.path.isabs(str(path)):path=asset(path)
            path=str(path or "")
            if path and os.path.isfile(path) and self[widget].instance is not None:
                if self._cin_widget_paths.get(widget)==path:
                    self[widget].show();return True
                self[widget].instance.setPixmapFromFile(path);self._cin_widget_paths[widget]=path;self[widget].show();return True
            self._cin_widget_paths.pop(widget,None);self[widget].hide()
        except Exception as exc:optional_failure("cinematic.native_pixmap",exc)
        return False

    def _cin_buffered_handoff(self,base_name,stage_name,path):
        """Decode the new HDD file once into the hidden slot, then release the old slot."""
        try:
            path=str(path or "")
            if not path or not os.path.isfile(path):return False
            active=self._cin_active_pixmap.get(base_name,base_name);inactive=stage_name if active==base_name else base_name
            if self._cin_pixmap_paths.get(active)==path:
                self[active].show();return True
            old=self[active];target=self[inactive]
            if old.instance is None or target.instance is None:return False
            try:target.hide();target.instance.setPixmap(None)
            except Exception:pass
            self._cin_pixmap_paths.pop(inactive,None)
            target.instance.setPixmapFromFile(path);self._cin_pixmap_paths[inactive]=path;target.show()
            old.hide()
            try:old.instance.setPixmap(None)
            except Exception:pass
            self._cin_pixmap_paths.pop(active,None);self._cin_active_pixmap[base_name]=inactive
            return True
        except Exception as exc:optional_failure("cinematic.buffered_handoff",exc);return False

    def _apply_native_detail_chrome(self,chrome):
        # Same chrome keys/fallback assets used by Native Details/SeriesEpisodes.
        self._cin_last_chrome=dict(chrome or {}) if isinstance(chrome,dict) else {}
        mapping={
            "panel_bg":("panel_detail","us66_neutral_panel.png"),
            "overview_bg":("overview_detail","us89_overview_card.png"),
            "cast_card_bg":("cast_detail","us66_neutral_pill_genre.png"),
            "quality_pill_bg":("quality","us66_neutral_pill_quality.png"),
            "year_pill_bg":("year","us66_neutral_pill_year.png"),
            "runtime_pill_bg":("runtime","us66_neutral_pill_runtime.png"),
            "country_pill_bg":("country","us66_neutral_pill_country.png"),
            "genre_pill_bg":("genre_detail","us66_neutral_pill_genre.png"),
        }
        for widget,(key,fallback) in mapping.items():
            path=(chrome or {}).get(key) if isinstance(chrome,dict) else None
            self._set_native_pixmap(widget,path or fallback)

    def _grid_shown_resume(self):
        self._cin_hidden=False
        self._cin_cancel_background()
        # Child screens stop Cinematic's private heartbeat completely.  Resume
        # only when this screen is visible again, using the adaptive cadence.
        try:self._cin_set_poll_interval(120 if self._cin_poll_has_pending_work() else 600,force=True)
        except Exception:pass
        if getattr(self,"_screen_closed",False) or getattr(self,"_grid_closed",False):return
        self._grid_images_suspended=False
        # Restore the exact local visual first so BACK never waits on network or
        # artwork hydration. Selection repaint can then refresh text/chrome only.
        try:self._cin_restore_surfaces_after_child()
        except Exception as exc:optional_failure("cinematic.resume_surface_restore",exc)
        if self.grid_items:
            try:self._update_selection();self._apply_debounced_grid_focus()
            except Exception as exc:optional_failure("cinematic.resume",exc)

    def _cin_hidden_start(self):
        """Child screens are a quiet period, not an automatic cache worker.

        Older builds started hidden folder hydration here while Details was
        allocating its own surfaces. That competed for CPU/HDD and contributed to
        gAccel pressure. Explicit BLUE Cache Artwork remains the only folder-wide
        artwork job.
        """
        if self._screen_closed:return
        self._cin_hidden=True
        try:self._cin_poll.stop()
        except Exception:pass
        self._cin_cancel_focus(enqueue=False);self._cin_cancel_background()

    def _cin_cancel_background(self):
        ev=getattr(self,"_cin_background_cancel",None)
        if ev is not None:
            try:ev.set()
            except Exception:pass
        future=getattr(self,"_cin_background_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception:pass
        self._cin_background_cancel=None
        self._cin_background_future=None

    def _cin_cancel_focus(self,enqueue=True):
        ev=getattr(self,"_cin_focus_cancel",None)
        if ev is not None:
            try:ev.set()
            except Exception:pass
        future=getattr(self,"_cin_focus_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception:pass
        if enqueue and isinstance(getattr(self,"_cin_last_focus_item",None),dict):
            self._cin_enqueue_missed(self._cin_last_focus_item)
        self._cin_focus_cancel=None;self._cin_focus_future=None;self._cin_focus_sig=""

    def _cin_stop(self):
        try:self._cin_poll.stop()
        except Exception:pass
        self._cin_cancel_focus(enqueue=False);self._cin_cancel_background()
        for name in ("cin_backdrop","cin_backdrop_stage","title_logo"):
            try:
                self[name].hide()
                if self[name].instance is not None:self[name].instance.setPixmap(None)
            except Exception:pass
        self._cin_pixmap_paths.clear();self._cin_widget_paths.clear()
        self._cin_pending.clear();self._cin_missed.clear();self._cin_missed_keys.clear();self._cin_logo_pending.clear();self._cin_logo_path=""

    def _prefetch_visible_page_details(self, priority_index=None, max_items=None):
        # Hybrid Cinematic owns hydration itself. PremiumGridBase page warming is
        # deliberately disabled here so no hidden gridposter_1x1 or neighbour
        # TMDB jobs run while the user is navigating.
        return

    def _cin_safe_key(self,key):
        value=str(key or "").strip()
        if not value:return ""
        value=re.sub(r"[^A-Za-z0-9._-]+","_",value)[:160]
        return value or hashlib.sha1(str(key).encode("utf-8","ignore")).hexdigest()[:24]

    def _cin_package_root(self,key):
        # One fixed generated directory. Key belongs in filenames, never folders.
        return GENERATED if self._cin_safe_key(key) else ""

    def _cin_package_path(self,key):
        safe=self._cin_safe_key(key)
        return os.path.join(GENERATED,"cinematic_%s_package.json"%safe) if safe else ""

    def _cin_legacy_roots(self,key):
        safe=str(key or "")
        if not safe:return []
        old_derived=os.path.join(ROOT,"derived")
        old_library=os.path.join(ROOT,"library")
        roots=[
            os.path.join(old_derived,"cinematic_hybrid",safe),
            os.path.join(old_derived,"cinematic_offline",safe),
            os.path.join(old_derived,"cinematic",safe),
        ]
        # Test74-76 may have written package folders under library/movie-id/cinematic.
        if safe.startswith(("movie-","tv-")):
            roots.append(os.path.join(old_library,safe,"cinematic"))
        else:
            roots.append(os.path.join(old_library,"local-"+safe,"cinematic"))
        return roots

    def _cin_store_asset(self,source,root,role,key=""):
        source=str(source or "")
        if not source or not os.path.isfile(source):return ""
        safe=self._cin_safe_key(key) or hashlib.sha1(source.encode("utf-8","ignore")).hexdigest()[:18]
        try:
            # Builders already write into the one fixed GENERATED folder. Keep
            # that exact file instead of duplicating it under another name.
            if os.path.commonpath((os.path.abspath(source),os.path.abspath(GENERATED)))==os.path.abspath(GENERATED):
                return source
        except Exception:pass
        ext=os.path.splitext(source)[1].lower() or ".png"
        if ext not in (".png",".jpg",".jpeg",".webp"):ext=".png"
        target=os.path.join(GENERATED,"cinematic_%s_%s%s"%(safe,role,ext))
        try:
            if not ensure_persistent_dirs(GENERATED):return ""
            if os.path.isfile(target):
                try:
                    if os.path.getsize(target)==os.path.getsize(source) and os.path.getsize(target)>0:return target
                except Exception:pass
            temp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            try:
                if os.path.exists(temp):os.unlink(temp)
                os.link(source,temp)
            except Exception:
                shutil.copy2(source,temp)
            os.replace(temp,target)
            return target if os.path.isfile(target) and os.path.getsize(target)>0 else ""
        except Exception as exc:
            optional_failure("cinematic.flat_store_asset",exc);return ""

    def _cin_nav_alias_path(self,item):
        try:
            visual=self._page_visual_key(item);safe=self._cin_safe_key(visual)
            return os.path.join(GENERATED,"cinematic_nav_%s.json"%safe) if safe else ""
        except Exception:return ""

    def _cin_publish_nav_alias(self,item,row,package):
        """Persist a tiny provider-key -> final prepared backdrop pointer."""
        if not isinstance(package,dict) or not package:return False
        try:
            backdrop=str(package.get("backdrop_fast") or package.get("backdrop") or "")
            if not backdrop or not os.path.isfile(backdrop):return False
            visual=self._page_visual_key(item);path=self._cin_nav_alias_path(item)
            if not visual or not path:return False
            payload={"schema":1,"visual_key":visual,"package_key":str(package.get("key") or self._record_key(row if isinstance(row,dict) else {},item) or ""),"backdrop":backdrop}
            tmp=path+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            with open(tmp,"w",encoding="utf-8") as h:json.dump(payload,h,separators=(",",":"),ensure_ascii=False)
            os.replace(tmp,path);self._cin_nav_alias_ram[visual]=dict(payload);return True
        except Exception as exc:
            optional_failure("cinematic.nav_alias_write",exc)
            try:
                if 'tmp' in locals() and os.path.exists(tmp):os.unlink(tmp)
            except Exception:pass
            return False

    def _cin_load_nav_alias(self,item):
        """RAM/tiny-JSON only. No metadata, adaptive, Pillow or network work."""
        try:
            visual=self._page_visual_key(item)
            if not visual:return {}
            cached=(getattr(self,"_cin_nav_alias_ram",{}) or {}).get(visual) or {}
            bd=str(cached.get("backdrop") or "") if isinstance(cached,dict) else ""
            if bd and os.path.isfile(bd):return cached
            path=self._cin_nav_alias_path(item)
            if not path or not os.path.isfile(path):return {}
            with open(path,"r",encoding="utf-8") as h:data=json.load(h)
            if not isinstance(data,dict) or int(data.get("schema") or 0)!=1:return {}
            bd=str(data.get("backdrop") or "")
            if not bd or not os.path.isfile(bd):return {}
            self._cin_nav_alias_ram[visual]=data;return data
        except Exception:return {}

    def _cin_normalize_legacy_package(self,data):
        if not isinstance(data,dict):return {}
        rows=data.get("settings_rows") if isinstance(data.get("settings_rows"),dict) else {}
        chrome=data.get("chrome") if isinstance(data.get("chrome"),dict) else {}
        out=dict(data)
        if not out.get("row_normal"):out["row_normal"]=rows.get("normal")
        if not out.get("row_selected"):out["row_selected"]=rows.get("selected")
        for name in ("panel","overview","quality","year","runtime","country","genre"):
            if not out.get(name):out[name]=chrome.get(name)
        return out

    def _cin_adopt_legacy_package(self,item,row):
        # release trusted-HDD migration. Older Cache Artwork runs already spent
        # the expensive Pillow/TMDB time; never make the user pay that cost again
        # just because the Cinematic package schema/layout changed. Adoption is
        # JSON + filesystem only: no decode, no resize, no network.
        key=self._record_key(row,item);root=self._cin_package_root(key)
        if not key or not root:return {}
        for legacy_root in self._cin_legacy_roots(key):
            candidates=(os.path.join(legacy_root,"package.json"),os.path.join(legacy_root,"cinematic_package.json"))
            for path in candidates:
                if not os.path.isfile(path):continue
                try:
                    with open(path,"r",encoding="utf-8") as h:data=self._cin_normalize_legacy_package(json.load(h))
                except Exception:
                    continue
                # Accept both old panel/overview chrome and newer Details chrome.
                # Poster halo is deliberately NOT required: Cinematic has no poster.
                roles={
                    "backdrop":"backdrop","row_normal":"row_normal","row_selected":"row_selected",
                    "panel_detail":"panel_detail","overview_detail":"overview_detail","cast_detail":"cast_detail",
                    "panel":"panel","overview":"overview","quality":"quality","year":"year","runtime":"runtime",
                    "country":"country","genre_detail":"genre_detail","genre":"genre",
                }
                adopted={}
                for field,role in roles.items():
                    src=str(data.get(field) or "")
                    if src and os.path.isfile(src):adopted[field]=self._cin_store_asset(src,root,role,key)
                core=all(adopted.get(x) for x in ("backdrop","row_normal","row_selected"))
                chrome_ok=bool((adopted.get("panel_detail") and adopted.get("overview_detail")) or (adopted.get("panel") and adopted.get("overview")))
                if not core or not chrome_ok:continue
                payload={"schema":self._cin_package_schema,"complete":True,"key":key,"signature":self._cin_package_signature(item,row),"accent":str(data.get("accent") or row.get("adaptive_accent") or row.get("adaptive_primary") or "#c99141"),"created_at":int(data.get("created_at") or data.get("completed_at") or time.time())}
                payload.update(adopted)
                if self._cin_write_package(self._cin_package_path(key),payload):
                    # Keep the legacy tree. A migration failure on a later build
                    # must never destroy the user's multi-GB artwork library.
                    return payload
        return {}

    def _cin_file_sig(self,path):
        try:
            if path and os.path.isfile(str(path)):
                st=os.stat(str(path));return "%s:%s:%s"%(str(path),int(st.st_mtime),int(st.st_size))
        except Exception:pass
        return ""

    def _cin_package_signature(self,item,row):
        row=row if isinstance(row,dict) else {}
        raw="|".join((str(self._cin_package_schema),self._record_key(row,item),self._cin_file_sig(row.get("backdrop_local")),str(row.get("adaptive_fingerprint") or "")))
        return hashlib.sha1(raw.encode("utf-8","ignore")).hexdigest()

    def _cin_ensure_fast_backdrop(self,item,row,package):
        """Persist a decoder-friendly JPEG twin of an already-finished Cinematic backdrop.

        This is intentionally a BLUE-cache/finalize operation, never navigation work.
        Enigma2 can take seconds to cold-decode our full-HD composited PNG on first
        display even when every byte is already on HDD.  A JPEG twin preserves the
        approved composition while making first-paint close to subsequent paints.
        """
        if not isinstance(package,dict) or not package:return ""
        fast=str(package.get("backdrop_fast") or "")
        if fast and os.path.isfile(fast) and os.path.getsize(fast)>4096:return fast
        source=str(package.get("backdrop") or "")
        if not source or not os.path.isfile(source) or _PILImage is None:return ""
        key=self._record_key(row if isinstance(row,dict) else {},item)
        safe=self._cin_safe_key(key)
        if not safe:return ""
        target=os.path.join(GENERATED,"cinematic_%s_backdrop_fast.jpg"%safe)
        temp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
        try:
            if os.path.isfile(target) and os.path.getsize(target)>4096:
                package["backdrop_fast"]=target
                return target
            if not ensure_persistent_dirs(os.path.dirname(target)):return ""
            with _PILImage.open(source) as im:
                im=im.convert("RGB")
                # No optimize/progressive pass: cache generation should spend as
                # little CPU as possible.  90 is visually transparent at 1080p
                # for this already-composited presentation surface.
                im.save(temp,"JPEG",quality=90,subsampling=2,optimize=False,progressive=False)
            os.replace(temp,target)
            package["backdrop_fast"]=target
            return target
        except Exception as exc:
            optional_failure("cinematic.fast_backdrop_encode",exc)
            try:
                if os.path.exists(temp):os.unlink(temp)
            except Exception:pass
            return ""

    def _cin_load_canonical_package_fast(self,item,row):
        """Read only the canonical package JSON; never migrate, resolve or build.

        This is the navigation-safe index path used while painting a catalogue
        page.  It intentionally performs no legacy adoption and no artwork work.
        """
        row=row if isinstance(row,dict) else {}
        key=self._record_key(row,item);path=self._cin_package_path(key)
        if not path or not os.path.isfile(path):return {}
        try:
            with open(path,"r",encoding="utf-8") as h:data=json.load(h)
            if not isinstance(data,dict) or int(data.get("schema") or 0)!=self._cin_package_schema or not data.get("complete"):return {}
            backdrop=str(data.get("backdrop_fast") or data.get("backdrop") or "")
            if not backdrop or not os.path.isfile(backdrop):return {}
            return data
        except Exception as exc:
            optional_failure("cinematic.fast_package_index",exc);return {}

    def _cin_instant_cached_backdrop(self,item,row):
        """Swap a cached Cinematic backdrop in the selection callback itself.

        No debounce, worker, resolver, package migration or network is allowed.
        The page painter already indexed the canonical package, so an arrow press
        is dictionary lookup + one native decoder-ready JPEG handoff only.
        """
        try:
            package=(getattr(self,"_cin_page_packages",{}) or {}).get(int(self.index)) or {}
            path=str((getattr(self,"_cin_page_backdrops",{}) or {}).get(int(self.index)) or "")
            if not path:
                alias=self._cin_load_nav_alias(item) or {};path=str(alias.get("backdrop") or "")
            if not path and isinstance(package,dict):path=str(package.get("backdrop_fast") or package.get("backdrop") or "")
            if not path or not os.path.isfile(path):return False
            if not self._cin_buffered_handoff("cin_backdrop","cin_backdrop_stage",path):return False
            self._cin_visual_key=str(package.get("key") or self._record_key(row,item))
            # The final cached Cinematic backdrop is now authoritative UI state.
            # Adaptive/chrome completion must never replace or delay it.
            self._cin_nav_backdrop_ready_key=self._record_key(row,item)
            return True
        except Exception as exc:
            optional_failure("cinematic.instant_cached_backdrop",exc);return False

    def _cin_load_package(self,item,row):
        row=row if isinstance(row,dict) else {}
        key=self._record_key(row,item);path=self._cin_package_path(key)
        def valid(data):
            # Trusted Local Cache Path: a completed canonical package is the
            # authority for presentation. Metadata timestamps/fingerprints may
            # change independently and must never force a cached 5-6GB library
            # back through Pillow/TMDB processing during navigation.
            if not isinstance(data,dict) or int(data.get("schema") or 0)!=self._cin_package_schema or not data.get("complete"):return False
            essential=("backdrop","row_normal","row_selected")
            if data.get("panel_detail") or data.get("overview_detail"):
                essential=essential+("panel_detail","overview_detail")
            else:
                essential=essential+("panel","overview")
            for field in essential:
                fp=str(data.get(field) or "")
                if not fp or not os.path.isfile(fp):return False
            return True
        try:
            if path and os.path.isfile(path):
                with open(path,"r",encoding="utf-8") as h:data=json.load(h)
                if valid(data):return data
            # Canonical miss does NOT mean artwork miss. Try the already-saved
            # pre-V7 package before any resolver/build path is allowed to run.
            adopted=self._cin_adopt_legacy_package(item,row)
            if valid(adopted):return adopted
            return {}
        except Exception as exc:optional_failure("cinematic.canonical_package_load",exc);return {}

    def _cin_write_package(self,path,data):
        temp=""
        try:
            if not ensure_persistent_dirs(os.path.dirname(path)):return False
            temp=path+".tmp.%d"%os.getpid()
            with open(temp,"w",encoding="utf-8") as h:
                json.dump(data,h,ensure_ascii=False,separators=(",",":"))  # derived cinematic cache metadata
            os.replace(temp,path);return True
        except Exception as exc:
            optional_failure("cinematic.hybrid_package_write",exc)
            try:
                if temp and os.path.exists(temp):os.unlink(temp)
            except Exception:pass
            return False

    def _cin_build_package(self,item,row,cancel_event=None):
        """Build Cinematic presentation from backdrop only. No poster is required or decoded."""
        def cancelled():return bool(cancel_event is not None and cancel_event.is_set())
        row=dict(row or {});key=self._record_key(row,item)
        if not key:return {}
        existing=self._cin_load_package(item,row)
        if existing:return existing
        backdrop=str(row.get("backdrop_local") or "")
        if not (backdrop and os.path.isfile(backdrop)):return {}
        root=self._cin_package_root(key);ensure_persistent_dirs(root)
        source=backdrop
        # Native Details owns adaptive identity: its displayed poster is the one
        # authoritative palette source. Cinematic keeps the widescreen backdrop
        # only for the content layer, never for Details-style chrome.
        adaptive_source=str(row.get("poster_local") or "")
        if not (adaptive_source and os.path.isfile(adaptive_source)):
            adaptive_source=source
        fingerprint=str(row.get("adaptive_fingerprint") or "")
        if cancelled():return {}
        settings_key="hy136_rows_%s_%s"%(key,hashlib.sha1((adaptive_source+fingerprint).encode("utf-8","ignore")).hexdigest()[:14])
        settings=_build_dynamic_settings_episode_rows(adaptive_source,settings_key,selected_rim_only=True,cinematic_premium=True) or {}
        normal=str(settings.get("normal") or "");selected=str(settings.get("selected") or "")
        value_color=settings.get("value_color")
        if isinstance(value_color,(tuple,list)) and len(value_color)>=3:
            accent="#%02x%02x%02x"%(int(value_color[0]),int(value_color[1]),int(value_color[2]))
        else:accent=str(row.get("adaptive_accent") or row.get("adaptive_primary") or "#c99141")
        if cancelled():return {}
        bd_hash=hashlib.sha1(("hy136|"+key+backdrop+fingerprint+accent).encode("utf-8","ignore")).hexdigest()[:18]
        bd_target=os.path.join(GENERATED,"cinematic_%s_backdrop_%s.png"%(self._cin_safe_key(key),bd_hash))
        cin_backdrop=_build_cinematic_backdrop(backdrop,bd_target,accent) or ""
        if cancelled():return {}
        chrome_key="cin536_detail_%s"%hashlib.sha1((adaptive_source+fingerprint+accent).encode("utf-8","ignore")).hexdigest()[:16]
        chrome=_build_dynamic_details_chrome(adaptive_source,chrome_key) or {}
        essential=(cin_backdrop,normal,selected,str(chrome.get("panel_detail") or ""),str(chrome.get("overview_detail") or ""))
        if not all(x and os.path.isfile(x) for x in essential):return {}
        canonical={
            "backdrop":self._cin_store_asset(cin_backdrop,root,"backdrop",key),
            "row_normal":self._cin_store_asset(normal,root,"row_normal",key),
            "row_selected":self._cin_store_asset(selected,root,"row_selected",key),
        }
        for name in ("panel_detail","overview_detail","cast_detail","quality","year","runtime","country","genre_detail"):
            src=str(chrome.get(name) or "")
            canonical[name]=self._cin_store_asset(src,root,name,key) if src and os.path.isfile(src) else ""
        if not all(canonical.get(x) for x in ("backdrop","row_normal","row_selected","panel_detail","overview_detail")):return {}
        package={"schema":self._cin_package_schema,"complete":True,"key":key,"signature":self._cin_package_signature(item,row),"accent":accent,"created_at":int(time.time())}
        package.update(canonical)
        path=self._cin_package_path(key)
        if not self._cin_write_package(path,package):return {}
        # Build the decoder-ready twin now, while BLUE/focus build already owns
        # the worker.  Future navigation only opens this JPEG; it never converts.
        if self._cin_ensure_fast_backdrop(item,row,package):self._cin_write_package(path,package)
        self._cin_publish_nav_alias(item,row,package)
        return package

    def _cin_apply_package(self,item,row,package=None):
        package=package if isinstance(package,dict) and package else self._cin_load_package(item,row)
        if not package:return False
        normal=str(package.get("row_normal") or "");selected=str(package.get("row_selected") or "");changed=False
        if normal and normal!=self._settings_row_asset:self._settings_row_asset=normal;changed=True
        if selected and selected!=self._settings_row_selected_asset:self._settings_row_selected_asset=selected;changed=True
        try:
            acc=str(package.get("accent") or "#69c9f4")
            if re.match(r"^#[0-9a-fA-F]{6}$",acc):self._cin_progress_accent=acc
        except Exception:pass
        if changed:
            try:self._render_grid()
            except Exception as exc:optional_failure("cinematic.hybrid_rows",exc)
        package_key=str(package.get("key") or self._record_key(row,item))
        # Backdrop and Adaptive are independent layers. If navigation already
        # painted this title's final cached backdrop, focus/package hydration is
        # forbidden from decoding or replacing it again.
        if str(getattr(self,"_cin_nav_backdrop_ready_key","") or "") != package_key:
            bd=str(package.get("backdrop_fast") or package.get("backdrop") or "")
            if bd and os.path.isfile(bd):
                self._cin_buffered_handoff("cin_backdrop","cin_backdrop_stage",bd)
                self._cin_nav_backdrop_ready_key=package_key
        package_chrome={k:package.get(k) for k in ("panel_detail","overview_detail","cast_detail","quality","year","runtime","country","genre_detail") if package.get(k)}
        # Details is the adaptive visual authority too. Prefer its persisted
        # poster-derived bundle even when an older Cinematic package already
        # contains backdrop-derived chrome. This repairs V42-era packages in
        # place without deleting/rebuilding artwork or changing cache identity.
        details_chrome={}
        try:
            bundle=_load_visual_bundle(self.profile,self.media_type,item,row) or {}
            details_chrome=bundle.get("chrome") if isinstance(bundle.get("chrome"),dict) else {}
        except Exception as exc:optional_failure("cinematic.details_chrome_prefer",exc)
        # release: never flash a neutral/stale package chrome between titles.
        # Keep the currently painted adaptive chrome alive until the newly focused
        # title's poster-derived Details bundle is actually ready, then atomically
        # replace it. On the first title only, package chrome is still allowed as
        # the initial shell so startup never opens blank.
        previous_chrome=(getattr(self,"_cin_last_chrome",{}) or {})
        package_pair_ready=bool(package_chrome.get("panel_detail") and package_chrome.get("overview_detail"))
        if details_chrome:
            chrome=details_chrome
        elif package_pair_ready:
            # The title panel and overview belong to the same persisted Cinematic
            # package. Paint them together immediately so the overview never
            # lags behind the title panel waiting for a later Details-bundle job.
            chrome=package_chrome
        elif previous_chrome:
            # No new adaptive pair is ready yet: hold the previous title's chrome
            # instead of flashing neutral/default material.
            chrome={}
        else:
            chrome=package_chrome
        if chrome:self._apply_native_detail_chrome(chrome)
        # Publish one authoritative local visual identity to Details + Player.
        # These are private runtime handoff fields, not provider metadata.
        try:
            poster=str((row or {}).get("poster_local") or "");backdrop=str((row or {}).get("backdrop_local") or "")
            if poster and os.path.isfile(poster):
                if isinstance(item,dict):
                    item["_cin_provider_poster_local"]=poster
                    item["_ultra_palette_source"]=poster
                    item["_ultra_poster_source"]=poster
                    item["_player_poster"]=poster
                    item["_adaptive_source_local"]=poster
                try:self._grid_palette_sources[self.index]=poster
                except Exception:pass
            if backdrop and os.path.isfile(backdrop) and isinstance(item,dict):
                item["_cin_provider_backdrop_local"]=backdrop
                item["_backdrop_source_local"]=backdrop
        except Exception as exc:optional_failure("cinematic.visual_handoff",exc)
        self._cin_visual_key=str(package.get("key") or self._record_key(row,item))
        return True

    def _cin_resolve_and_package(self,item,cancel_event=None):
        """Consume Details Authority metadata; Cinematic owns presentation only."""
        if cancel_event is not None and cancel_event.is_set():return ({}, {})
        row=self._record(item) or {}
        package=self._cin_load_package(item,row)
        # release: visual-package readiness is NOT metadata readiness. Old BLUE
        # runs may have prepared Cinematic assets from an artwork-only manifest.
        # Keep those visuals, but always let Details Authority complete/read the
        # canonical metadata record before returning the focused row.
        def valid_file(value):
            try:return bool(value and os.path.isfile(str(value)) and os.path.getsize(str(value))>100)
            except Exception:return False
        backdrop=str(row.get("backdrop_local") or "")
        # release: no independent Cinematic TMDB hydration. Stable Focus asks
        # the one Details Authority for this title and consumes its canonical row.
        try:
            from .details_authority import resolve_canonical
            authoritative=resolve_canonical(self.profile,self.media_type,item,cancel_event=cancel_event,settings=(self._grid_settings or {})) or {}
            if authoritative:
                merged=dict(row)
                for key,value in authoritative.items():
                    if value not in (None,"",[],{}):merged[key]=value
                row=merged
        except Exception as exc:optional_failure("cinematic.details_authority",exc)
        if not valid_file(row.get("backdrop_local")) and valid_file(backdrop):row["backdrop_local"]=backdrop
        if cancel_event is not None and cancel_event.is_set():return (row,{})
        if package:return (row,package)
        return (row,self._cin_build_package(item,row,cancel_event))

    def _cin_enqueue_missed(self,item):
        # Focus-driven law: skipped titles are never recovered in background.
        return

    def _cin_schedule_focus(self,item):
        if self._folder_artwork_cache_running:return
        sig=self._page_visual_key(item)
        if not sig:return
        if self._cin_focus_sig==sig and self._cin_focus_future is not None and not self._cin_focus_future.done():return
        self._cin_cancel_background();self._cin_cancel_focus(enqueue=False)
        ev=threading.Event();self._cin_focus_cancel=ev;self._cin_focus_sig=sig
        def worker():
            try:
                row,package=self._cin_resolve_and_package(dict(item),ev)
                if not ev.is_set():self._cin_jobs.put({"kind":"focus","sig":sig,"row":row,"package":package})
            except Exception as exc:optional_failure("cinematic.hybrid_focus",exc)
        self._cin_focus_future=_CIN_HYBRID_EXECUTOR.submit(worker);self._cin_kick_poll()

    def _cin_start_hidden_folder_cache(self,rows):
        self._cin_cancel_background()
        if not self._cin_hidden or self._folder_artwork_cache_running:return
        items=[dict(x) for x in (rows or []) if isinstance(x,dict)]
        if not items:return
        ev=threading.Event();self._cin_background_cancel=ev
        def worker():
            done=0
            for item in items:
                if ev.is_set() or not self._cin_hidden:break
                try:
                    row=self._record(item) or {}
                    if self._cin_load_package(item,row):continue
                    self._cin_resolve_and_package(item,ev);done+=1
                except Exception as exc:optional_failure("cinematic.hidden_fill",exc)
                if ev.is_set():break
            try:self._cin_jobs.put({"kind":"hidden_done","done":done})
            except Exception:pass
        self._cin_background_future=_CIN_HYBRID_EXECUTOR.submit(worker);self._cin_kick_poll()

    @staticmethod
    def _blue_title_logo_cache_path(media_type,tmdb_id,logo_lang="en"):
        try:
            mt="tv" if str(media_type).lower() in ("series","tv") else "movie"
            return os.path.join(THUMB_CACHE_DIR,"title_logos","%s_%s_%s_432x210_v2.png"%(mt,int(tmdb_id),str(logo_lang or "en")))
        except Exception:return ""

    def _cache_title_logo_for_blue(self,item,row,cancel_event=None):
        """Resolve one missing title logo through the current safe cache path.

        Order is fixed: TMDB first, then Fanart.tv only on a real miss.  Both
        sources end in the same bounded download/validate/resize/HDD cache path.
        No UI-thread network work, no retry loop and no legacy title-logo path.
        """
        if cancel_event is not None and cancel_event.is_set():return ""
        tmdb_id=(row or {}).get("tmdb_id")
        if not tmdb_id:return ""
        visible_title=self._rail_title(item,row) or str((row or {}).get("title") or (row or {}).get("name") or "")
        logo_lang="ar" if re.search(r"[\u0600-\u06ff]",str(visible_title or "")) else "en"
        target=self._blue_title_logo_cache_path(self.media_type,tmdb_id,logo_lang)
        if target and os.path.isfile(target) and os.path.getsize(target)>256:return target
        cfg=(getattr(self,"_grid_settings",None) or load_settings());credential=str(cfg.get("tmdb_credential") or "").strip()
        mt="tv" if self.media_type=="series" else "movie"
        timeout=min(7,max(3,int(cfg.get("timeout",10) or 10)))
        logo_url=str((row or {}).get("logo_url") or "").strip() if logo_lang=="en" else ""
        client=None
        try:
            # TMDB keeps first refusal whenever its credential is available.
            if not logo_url and cfg.get("tmdb_enabled",True) and credential:
                client=TMDBClient(credential,str(cfg.get("tmdb_language") or "en-US"),timeout)
                payload=client._get("/%s/%s/images"%(mt,int(tmdb_id)),{"include_image_language":(logo_lang if logo_lang=="ar" else "en,null")}) or {}
                logos=payload.get("logos") if isinstance(payload,dict) else []
                logo_path=str(((logos or [{}])[0] or {}).get("file_path") or "") if logos else ""
                logo_url=TMDBClient.image_url(logo_path,"w300") if logo_path else ""

            # Fanart.tv is second source only.  It stays in this same worker and
            # feeds the exact same cache writer below.  For movies TMDB id is
            # already the Fanart id; TV uses a cached/provider TVDB id first and
            # asks TMDB external_ids only when that lookup is available.
            if not logo_url and not (cancel_event is not None and cancel_event.is_set()):
                try:
                    keys=load_api_keys() or {}
                    project=str(keys.get("FANART_API_KEY") or "").strip();personal=str(keys.get("FANART_CLIENT_KEY") or "").strip()
                    if project or personal:
                        tvdb_id=str((row or {}).get("tvdb_id") or (row or {}).get("thetvdb_id") or (row or {}).get("tvdb") or "").strip()
                        if mt=="tv" and not tvdb_id and client is not None:
                            try:
                                ext=client._get("/tv/%s/external_ids"%int(tmdb_id),{}) or {}
                                tvdb_id=str(ext.get("tvdb_id") or "").strip()
                            except Exception:tvdb_id=""
                        fa=_fanart_fetch(project,mt,tmdb_id=tmdb_id,tvdb_id=tvdb_id,timeout=timeout,personal_key=personal,logo_lang=logo_lang) or {}
                        logo_url=str(fa.get("title_logo_url") or "").strip()
                except Exception as exc:
                    optional_failure("cinematic.blue_title_logo_fanart",exc)

            if not logo_url or cancel_event is not None and cancel_event.is_set():return ""
            if _PILImage is None:return ""
            parent=os.path.dirname(target)
            if parent and not os.path.isdir(parent):os.makedirs(parent)

            # release: use ArtworkV2's hardened artwork transport for BOTH TMDB
            # and Fanart title-logo payloads.  The raw urlopen path in 6.5.74
            # bypassed the receiver-tested HTTPS allowlist/retry path that already
            # permits image.tmdb.org + assets.fanart.tv, so a valid Fanart logo
            # could resolve but never reach the persistent title-logo canvas.
            source_target=target+".src_"+hashlib.sha1(str(logo_url).encode("utf-8","ignore")).hexdigest()[:12]
            downloaded=_artwork_download(logo_url,source_target,timeout=timeout) or ""
            if not downloaded or not os.path.isfile(downloaded):return ""
            if cancel_event is not None and cancel_event.is_set():return ""
            try:
                with _PILImage.open(downloaded) as src:
                    im=src.convert("RGBA")
                    # Reject malformed/non-image payloads before Enigma2 ever sees them.
                    if im.width<32 or im.height<16:return ""
                    try:
                        bbox=im.getchannel("A").getbbox()
                        if bbox:im=im.crop(bbox)
                    except Exception:pass
                    max_w,max_h=404,186
                    if im.width<1 or im.height<1:return ""
                    scale=min(float(max_w)/im.width,float(max_h)/im.height)
                    nw=max(1,int(round(im.width*scale)));nh=max(1,int(round(im.height*scale)))
                    res=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
                    if (nw,nh)!=im.size:im=im.resize((nw,nh),res)
                    bg=_PILImage.new("RGBA",(432,210),(255,255,255,0))
                    bg.paste(im,((432-nw)//2,(210-nh)//2),mask=im)
                    tmp_target=target+".tmp.%s"%os.getpid();bg.save(tmp_target,"PNG",compress_level=0);os.replace(tmp_target,target)
                return target if os.path.isfile(target) and os.path.getsize(target)>256 else ""
            finally:
                try:
                    if downloaded and os.path.isfile(downloaded):os.remove(downloaded)
                except Exception:pass
        except Exception as exc:
            optional_failure("cinematic.blue_title_logo",exc);return ""

    def _details_bundle_ready(self,item,row):
        try:
            bundle=_load_visual_bundle(self.profile,self.media_type,item,row) or {}
            chrome=bundle.get("chrome") if isinstance(bundle.get("chrome"),dict) else {}
            return bool(
                bundle.get("detail_poster") and os.path.isfile(str(bundle.get("detail_poster") or "")) and
                bundle.get("backdrop_present") and os.path.isfile(str(bundle.get("backdrop_present") or "")) and
                bundle.get("theme") and os.path.isfile(str(bundle.get("theme") or "")) and
                chrome.get("panel_detail") and chrome.get("overview_detail")
            )
        except Exception:
            return False

    def _build_details_bundle_for_blue_cache(self,item,row,cin_package=None,cancel_event=None):
        """Build Details presentation only during explicit BLUE Cache Artwork.

        Browsing and opening Details never generate adaptive assets.  The same
        canonical poster/backdrop already cached outside are used once here, on
        user request, then Details becomes HDD-only.
        """
        if cancel_event is not None and cancel_event.is_set():return False
        row=dict(row or {})
        poster=str(row.get("poster_local") or "");backdrop=str(row.get("backdrop_local") or "")
        if not (poster and os.path.isfile(poster) and backdrop and os.path.isfile(backdrop)):return False
        try:self._cache_title_logo_for_blue(item,row,cancel_event)
        except Exception as exc:optional_failure("cinematic.blue_title_logo_prepare",exc)
        if self._details_bundle_ready(item,row):return True
        try:
            stamp=str(os.path.getmtime(poster))
            digest=hashlib.sha1((poster+stamp+"|us125-details").encode("utf-8","ignore")).hexdigest()[:20]
            chrome=_build_dynamic_details_chrome(poster,"us125_"+digest) or {}
            try:
                exact_accent=str((cin_package or {}).get("accent") or row.get("adaptive_accent") or row.get("adaptive_primary") or "").strip()
                if re.match(r"^#[0-9a-fA-F]{6}$",exact_accent):chrome["accent_color"]=exact_accent.lower()
            except Exception:pass
            if cancel_event is not None and cancel_event.is_set():return False
            theme=_build_dynamic_details_gradient(poster,os.path.join(THUMB_CACHE_DIR,"us125_%s_bg.jpg"%digest),(1920,1080)) or ""
            # Details poster focus is now a runtime 2px adaptive trace sampled
            # from the already-cached glass color.  Do not build/carry any
            # poster-frame surface; it was extra CPU/HDD work and wrong geometry.
            detail_poster=_detail_cover_artwork(poster,(352,552)) or ""
            if cancel_event is not None and cancel_event.is_set():return False
            try:bd_stamp=str(os.path.getmtime(backdrop))
            except Exception:bd_stamp="0"
            bd_digest=hashlib.sha1((backdrop+"|"+bd_stamp+"|us198-present").encode("utf-8","ignore")).hexdigest()[:24]
            bd_target=os.path.join(THUMB_CACHE_DIR,"us220_detail_%s_1620x620.png"%bd_digest)
            backdrop_present=_build_integrated_backdrop(backdrop,bd_target,(1620,620)) or ""
            payload={
                "poster":poster,"detail_poster":detail_poster,"backdrop_present":backdrop_present,
                "theme":theme,"chrome":chrome,
            }
            return bool(_save_visual_bundle(self.profile,self.media_type,item,payload,snapshot=row))
        except Exception as exc:
            optional_failure("cinematic.blue_details_bundle",exc);return False

    def _cin_blue_lock_path(self,item):
        """Persistent completed-vault marker for explicit BLUE Cache Artwork.

        The marker is intentionally independent of process/session/version state.
        It records only physical HDD assets that were already completed once.
        Restarting Enigma2 or reopening a folder therefore cannot make a finished
        title expensive again.  A title is repaired only when one of those files
        is genuinely missing/corrupt.
        """
        try:
            safe=self._cin_safe_key(self._page_visual_key(item))
            return os.path.join(GENERATED,"cinematic_blue_ready_%s.json"%safe) if safe else ""
        except Exception:return ""

    @staticmethod
    def _cin_blue_lock_files_valid(files):
        if not isinstance(files,(list,tuple)) or not files:return False
        for path in files:
            try:
                path=str(path or "")
                if not path or not os.path.isfile(path) or os.path.getsize(path)<=256:return False
            except Exception:return False
        return True

    def _cin_read_blue_lock(self,item):
        path=self._cin_blue_lock_path(item)
        if not path or not os.path.isfile(path):return {}
        try:
            with open(path,"r",encoding="utf-8") as h:data=json.load(h)
            # Schema 1 is the older presentation-heavy vault. Schema 2 is the
            # release artwork-only seal. Both stay valid so upgrades never make
            # previously cached titles expensive again.
            if not isinstance(data,dict) or int(data.get("schema") or 0) not in (1,2,3):return {}
            if not self._cin_blue_lock_files_valid(data.get("files")):return {}
            return data
        except Exception:return {}

    def _cin_write_blue_lock(self,item,row,poster=None,backdrop=None,package=None):
        """Persist BLUE completion only after the final Cinematic backdrop exists.

        V7.0.38 keeps Details Authority as the only metadata resolver, then lets
        BLUE build the already-resolved Cinematic presentation once, sequentially,
        while the user explicitly waits for Cache Artwork.  This moves the costly
        first-focus backdrop conversion into BLUE without reintroducing any
        independent Cinematic metadata search.  Older schema-1/2 locks stay
        readable, but a V7.0.38 BLUE pass upgrades them to schema 3.
        """
        try:
            p=str(poster or (row or {}).get("poster_local") or "")
            b=str(backdrop or (row or {}).get("backdrop_local") or "")
            package=dict(package or {}) if isinstance(package,dict) else {}
            final_bd=str(package.get("backdrop_fast") or package.get("backdrop") or "")
            required=[p,b,final_bd]
            if not self._cin_blue_lock_files_valid(required):return False
            path=self._cin_blue_lock_path(item)
            if not path or not ensure_persistent_dirs(os.path.dirname(path)):return False
            payload={
                "schema":3,
                "visual_key":self._page_visual_key(item),
                "files":required,
                "tmdb_id":str((row or {}).get("tmdb_id") or ""),
                "cinematic_key":str(package.get("key") or ""),
                "sealed_at":int(time.time()),
            }
            temp=path+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            with open(temp,"w",encoding="utf-8") as h:
                json.dump(payload,h,ensure_ascii=False,separators=(",",":"))  # rebuildable readiness seal
            os.replace(temp,path);return True
        except Exception as exc:
            optional_failure("cinematic.blue_ready_lock_write",exc)
            try:
                if 'temp' in locals() and os.path.exists(temp):os.unlink(temp)
            except Exception:pass
            return False

    def _folder_artwork_ready_hook(self,item,data):
        """BLUE readiness means artwork AND canonical Details metadata are ready.

        V7.0.38 keeps Details Authority as the only metadata resolver. Once the two
        original HDD artwork masters and canonical metadata exist, BLUE also builds
        the final persisted Cinematic backdrop/package before advancing the folder
        counter. This makes first navigation use the same ready asset as later
        navigation, with no independent Cinematic metadata lookup.
        """
        row=dict(data or {}) if isinstance(data,dict) else {}
        # release shared BLUE contract: an artwork-only seal written by Backdrop
        # Grid is enough to make Cinematic BLUE treat the title as already cached.
        # Cinematic presentation remains lazy and is built only when that mode
        # actually needs it; rendering logic is untouched.
        try:
            if self._cin_read_blue_lock(item):return True
        except Exception:pass
        poster=str(row.get("poster_local") or "")
        backdrop=str(row.get("backdrop_local") or "")
        try:
            from .artwork_v2 import _valid_backdrop
            art_ready=bool(poster and os.path.isfile(poster) and os.path.getsize(poster)>512 and _valid_backdrop(backdrop))
        except Exception:
            art_ready=False
        if not art_ready:return False

        # Artwork is physically ready. Preload metadata through Details Authority
        # only; Cinematic/Backdrop Grid do zero independent metadata searching.
        try:
            from .details_authority import load_canonical, resolve_canonical
            canonical=load_canonical(self.profile,self.media_type,item) or {}
            if not (canonical.get("_details_authority_ready") and canonical.get("tmdb_id")):
                canonical=resolve_canonical(
                    self.profile,self.media_type,item,cancel_event=None,
                    settings=(self._grid_settings or {})
                ) or canonical
            meta_ready=bool(canonical.get("_details_authority_ready") and canonical.get("tmdb_id"))
            if meta_ready:
                merged=dict(row);merged.update(canonical)
                # The remaining ~5 second first-focus cost observed on receiver is
                # the Cinematic final-backdrop/package build.  Build it here only
                # AFTER canonical Details metadata is ready, never before.
                package=self._cin_load_package(item,merged) or {}
                if not package:
                    package=self._cin_build_package(item,merged,None) or {}
                final_bd=str(package.get("backdrop_fast") or package.get("backdrop") or "")
                if final_bd and os.path.isfile(final_bd) and os.path.getsize(final_bd)>256:
                    self._cin_write_blue_lock(item,merged,poster,backdrop,package=package)
                    return True
        except Exception as exc:
            optional_failure("cinematic.blue_details_preload",exc)
        return False

    def _folder_artwork_finalize_hook(self,item,poster,backdrop,payload,data,cancel_event=None):
        """After artwork rescue, preload the same canonical Details record."""
        if cancel_event is not None and cancel_event.is_set():return False
        row=dict(data or {}) if isinstance(data,dict) else {}
        if poster and os.path.isfile(str(poster)):row["poster_local"]=str(poster)
        if backdrop and os.path.isfile(str(backdrop)):row["backdrop_local"]=str(backdrop)
        # Reuse the exact readiness path so both already-cached and newly rescued
        # titles obey one contract: BLUE completes only after Details metadata is
        # persistent. The Cinematic package is built only after Details metadata is canonical; no independent metadata lookup is allowed.
        return bool(self._folder_artwork_ready_hook(item,row))

    def _cin_enter_cache_exclusive(self):
        """Give explicit BLUE Cache Artwork exclusive ownership of the screen.

        While a large folder vault is running, Cinematic must not spend CPU/HDD
        time on focus artwork, title logos, cast, page hydration or periodic
        visual work. The async callback/progress channel remains alive so the BLUE
        counter can move, but every unrelated screen engine is silent.
        """
        self._cin_cache_exclusive=True
        self._folder_artwork_fast_art_only=True
        self._cin_cancel_focus(enqueue=False);self._cin_cancel_background()
        for timer_name in ("_grid_focus_timer","_series_prefetch_timer","_detail_prefetch_timer","_epg_timer","_cin_poll"):
            try:getattr(self,timer_name).stop()
            except Exception:pass
        # Discard any stale visual jobs queued before BLUE took ownership.
        for qname in ("_cin_jobs","_art_prefetch_jobs","_quality_prefetch_jobs","_epg_jobs"):
            q=getattr(self,qname,None)
            if q is None:continue
            try:
                while True:q.get_nowait()
            except Exception:pass

    def _cin_leave_cache_exclusive(self):
        self._folder_artwork_fast_art_only=False
        self._cin_cache_exclusive=False
        if self._screen_closed:return
        # Cinematic poll is normally only a queue-delivery heartbeat. Restore it
        # after BLUE exits, then refresh exactly the currently focused title once.
        try:self._cin_set_poll_interval(120,force=True)
        except Exception:pass
        try:
            if self.grid_items:
                self._grid_focus_timer.stop();self._grid_focus_timer.start(120,True)
        except Exception:pass

    def _drain_jobs(self):
        if getattr(self,"_cin_cache_exclusive",False):
            # Cache-exclusive GUI pump: only the async completion queue and BLUE
            # progress queue are serviced. No poster/adaptive/EPG/cast/page drains.
            if time.monotonic() < float(getattr(self,"_nav_burst_until",0.0) or 0.0):
                return
            AsyncScreenMixin._drain_jobs(self)
            if not self._screen_closed:
                try:self._drain_folder_artwork_progress()
                except Exception as exc:optional_failure("cinematic.blue_progress_only",exc)
            return
        return PremiumGridBase._drain_jobs(self)

    def _cache_folder_artwork_worker(self, rows, cancel_event=None):
        # release: one exclusive BLUE pipeline. ArtworkV2 already resolves the
        # title-logo URL during the artwork pass; do not perform a second folder-
        # wide _record()+logo sweep after posters/backdrops finish. That old pass
        # reopened HDD manifests for every title and could double large-folder time.
        self._folder_artwork_fast_art_only=True
        return PremiumGridBase._cache_folder_artwork_worker(self,rows,cancel_event)

    def _apply_folder_artwork_result(self,result):
        try:return PremiumGridBase._apply_folder_artwork_result(self,result)
        finally:self._cin_leave_cache_exclusive()

    def cache_folder_artwork(self):
        # Status is intentionally text-only: no pill/glass behind Check Artwork.
        try:self["artwork_status_bg"].hide()
        except Exception:pass
        if self._folder_artwork_cache_running:
            try:self["status"].setText(_("Artwork check is already running"))
            except Exception:pass
            return
        self._cin_enter_cache_exclusive()
        result=PremiumGridBase.cache_folder_artwork(self)
        # If catalog startup refused synchronously (empty/unsupported/etc.), do
        # not leave Cinematic in exclusive mode. A real BLUE job sets running.
        if not getattr(self,"_folder_catalog_loading",False) and not getattr(self,"_folder_artwork_cache_running",False):
            self._cin_leave_cache_exclusive()
        return result

    def _item_fallback_title(self,item):
        if not isinstance(item,dict):return ""
        return str(item.get("name") or item.get("title") or item.get("series_name") or "").strip()

    def _item_fallback_year(self,item):
        if not isinstance(item,dict):return ""
        for k in ("year","release_date","first_air_date","added"):
            v=str(item.get(k) or "").strip()
            if len(v)>=4 and v[:4].isdigit():return v[:4]
        return ""

    def _rail_title(self,item,row=None):
        """Always show a clean catalogue title on the left rail, aligned left.

        The visible rail never prefers a localized title merely because TMDB returned
        one.  It first cleans the provider/catalogue name so routing prefixes, quality
        tags and decorative junk cannot leak into either display or identity matching.
        No network work is allowed here.
        """
        row=row if isinstance(row,dict) else {}
        provider=_catalogue_title(self._item_fallback_title(item))
        original=_catalogue_title(row.get("original_title") or "")
        saved=_catalogue_title(row.get("title") or row.get("name") or "")
        return provider or original or saved

    def _quality(self,item):
        try:
            row=self._grid_item_state.get(id(item),{}) or {};q=str(row.get("quality") or "").strip()
            if q:return q
        except Exception:pass
        try:
            badges=str(quality_badges(self._item_fallback_title(item)) or "").strip()
            if badges:return badges.split(" • ")[0]
        except Exception:pass
        name=self._item_fallback_title(item).upper()
        if "4K" in name or "2160" in name:return "4K"
        if "FHD" in name or "1080" in name:return "FHD"
        if "HD" in name or "720" in name:return "HD"
        return "AUTO"

    def _record(self,item):
        """Return the same final HDD state used by Native Details.

        Cinematic never resolves metadata itself.  It merges the global artwork
        manifest with the Details pointer/global snapshot so outside and inside
        cannot disagree about overview, seasons or credits.  Both readers are
        HDD-only and ultimately point at the same TMDB library identity.
        """
        try:
            art=load_manifest(self.profile,self.media_type,item) or {}
            detail=load_detail_snapshot(self.profile,self.media_type,item) or {}
            if art.get("tmdb_id"):
                direct=load_detail_snapshot_by_tmdb(art.get("media_type") or self.media_type,art.get("tmdb_id")) or {}
                if direct:
                    merged=dict(detail);merged.update(direct);detail=merged
            row=dict(detail);row.update(art)
            # Focused provider artwork is a verified local handoff, not a second
            # metadata authority. Keep it visible for this screen lifetime and
            # let Details/Player reuse the same exact HDD files.
            if isinstance(item,dict):
                pp=str(item.get("_cin_provider_poster_local") or item.get("_ultra_poster_source") or item.get("_player_poster") or "")
                pb=str(item.get("_cin_provider_backdrop_local") or item.get("_backdrop_source_local") or "")
                if pp and os.path.isfile(pp):row["poster_local"]=pp
                if pb and os.path.isfile(pb):row["backdrop_local"]=pb
            # Preserve the newest timestamp so the HDD poll notices metadata
            # completed by Native Details while Cinematic remains open.
            try:row["updated_at"]=max(int(detail.get("updated_at") or 0),int(art.get("updated_at") or 0))
            except Exception:pass
            return row
        except Exception as exc:
            optional_failure("cinematic.global_record",exc);return {}

    def _record_key(self,row,item):
        tid=row.get("tmdb_id") if isinstance(row,dict) else None
        if tid:return "%s-%s"%("tv" if self.media_type=="series" else "movie",tid)
        return self._page_visual_key(item)

    def _format_runtime(self,value):
        try:
            m=int(float(value or 0));return "%dh %02dm"%(m//60,m%60) if m>=60 else ("%d min"%m if m else "")
        except Exception:return ""

    def _cin_list_row(self, pos, selected=False, record=None):
        item=self.grid_items[pos]
        record=record if isinstance(record,dict) else self._record(item)
        title=self._rail_title(item,record)
        year=str(record.get("year") or self._item_fallback_year(item))
        q=self._quality(item)
        # Cinematic rail deliberately reserves the entire second line for watched
        # progress. Quality/year already exist in the full Details cluster.
        value=""
        state=self._grid_item_state.get(id(item),{}) or {}
        progress_pct=0
        if self.media_type=="vod":
            try:
                pos=float(state.get("position") or 0);dur=float(state.get("duration") or 0)
                if int(state.get("completed") or 0):progress_pct=100
                elif pos>0 and dur>0:progress_pct=max(1,min(99,int(round((pos*100.0)/dur))))
            except Exception:progress_pct=0
        progress_neon=""
        if progress_pct>0:
            try:progress_neon=_cinematic_row_progress_frame(getattr(self,"_cin_progress_accent","#69c9f4"),progress_pct) or ""
            except Exception as exc:optional_failure("cinematic.row_progress_neon",exc)
        meta={
            "selected":bool(selected),
            "value":value,
            "row_asset":self._settings_row_asset,
            "row_selected_asset":self._settings_row_selected_asset,
            "value_color":0xFFFFFF,
            "watch_progress":progress_pct,
            "watch_progress_neon":progress_neon,
            "watch_progress_full_line":True,
            # Beta81: text-only polish on the stable Beta77 row renderer.
            # Remove the catalogue icon so names start from the left edge,
            # and enable adaptive title sizing without touching row assets.
            "hide_icon":True,
            "adaptive_title":True,
            "compact_row":True,
        }
        return (title,self._cin_list_icon,item,meta)

    def _render_grid(self):
        # Beta86: keep the same Settings/Episodes row grammar in a compact 73px
        # slot and show 12 rows, starting directly beneath the Ultra Stalker header.
        # release additionally indexes the tiny canonical package JSON for every
        # visible row here.  Arrow navigation therefore does zero HDD lookup and
        # can bind the already-cached decoder-ready backdrop immediately.
        self._cin_row_complete.clear();self._cin_page_records={};self._cin_page_packages={};self._cin_page_backdrops={}
        rows=[]
        for pos in range(min(self.page_size,len(self.grid_items))):
            _item=self.grid_items[pos]
            # Backdrop navigation index is independent of metadata/adaptive hydration.
            try:
                _alias=self._cin_load_nav_alias(_item) or {};_abd=str(_alias.get("backdrop") or "")
                if _abd and os.path.isfile(_abd):self._cin_page_backdrops[pos]=_abd
            except Exception as exc:optional_failure("cinematic.page_nav_alias",exc)
            try:self._cin_page_records[pos]=self._record(_item) or {}
            except Exception:self._cin_page_records[pos]={}
            try:
                _pkg=self._cin_load_canonical_package_fast(_item,self._cin_page_records.get(pos,{}) or {}) or {}
                if _pkg:
                    self._cin_page_packages[pos]=_pkg
                    _bd=str(_pkg.get("backdrop_fast") or _pkg.get("backdrop") or "")
                    if _bd and os.path.isfile(_bd):
                        self._cin_page_backdrops[pos]=_bd
                        self._cin_publish_nav_alias(_item,self._cin_page_records.get(pos,{}) or {},_pkg)
            except Exception as exc:optional_failure("cinematic.page_backdrop_index",exc)
            rows.append(self._cin_list_row(pos,selected=(pos==self.index),record=self._cin_page_records.get(pos)))
        try:
            self["cin_list"].set_icon_rows(rows)
            if rows:self["cin_list"].moveToIndex(max(0,min(self.index,len(rows)-1)))
        except Exception as exc:optional_failure("cinematic.settings_list_render",exc)
        self._update_selection()

    def _update_selection(self):
        if not self.grid_items:return
        self.index=max(0,min(self.index,len(self.grid_items)-1));self._remember_grid_state();item=self.grid_items[self.index]
        self._cin_last_nav_at=time.monotonic()
        # Navigation path is deliberately UI-only. Never enqueue skipped titles,
        # reprioritize artwork workers, scan HDD manifests or start network work.
        self._cin_cancel_focus(enqueue=False);self._cin_cancel_background();self._cin_last_focus_item=dict(item)
        # Settings itself repaints selected/previous rows using this exact MultiContent renderer.
        try:
            for pos in range(min(self.page_size,len(self.grid_items))):
                if pos==self.index or pos==getattr(self,"_cin_last_list_index",-1):
                    self["cin_list"].update_icon_row(pos,self._cin_list_row(pos,selected=(pos==self.index),record=self._cin_page_records.get(pos,{})))
            self["cin_list"].moveToIndex(self.index)
            self._cin_last_list_index=int(self.index)
        except Exception as exc:optional_failure("cinematic.settings_list_selection",exc)
        # release: a trusted cached backdrop is UI state, not an artwork job.
        # Swap it in the same selection callback as the highlight. Missing titles
        # still remain behind the 320ms stable-focus gate below.
        if not getattr(self,"_cin_cache_exclusive",False):
            try:self._cin_instant_cached_backdrop(item,self._cin_page_records.get(self.index,{}) or {})
            except Exception as exc:optional_failure("cinematic.nav_backdrop_now",exc)
        if not getattr(self,"_cin_cache_exclusive",False):
            try:
                self._nav_burst_until=time.monotonic()+0.34;self._grid_focus_timer.stop();self._grid_focus_timer.start(320,True)
                if self.media_type=="series":self._series_prefetch_timer.stop();self._series_prefetch_timer.start(900,True)
            except Exception:self._apply_debounced_grid_focus()
        self._update_page_counter()

    def open_selected(self):
        """Movies play directly; Series keep the existing Details/Episodes route."""
        if self._busy or not self.grid_items:return
        if self.media_type!="vod":
            return PremiumGridBase.open_selected(self)
        item=self.grid_items[self.index]
        command=item.get("cmd") or item.get("command") or item.get("url")
        if not command:
            try:self["status"].setText(_("No stream command"))
            except Exception:pass
            return
        try:self["status"].setText(_("Creating stream link..."))
        except Exception:pass
        selected_page=int(self.page or 1);selected_index=int(self.index or 0)
        def ok(url):
            if not isinstance(url,str) or not url.strip():
                try:self["status"].setText(_("Portal returned an invalid stream link"))
                except Exception:pass
                return
            name=str(item.get("name") or item.get("title") or "Ultra Stalker stream")
            try:
                engine=_configured_playback_engine()
                play_item=dict(item) if isinstance(item,dict) else item
                if isinstance(play_item,dict):
                    try:
                        visible_poster=self._visible_player_poster_path(item,self.index)
                        if visible_poster:
                            play_item["_player_poster"]=visible_poster
                            play_item["_ultra_poster_source"]=visible_poster
                            play_item["_adaptive_source_local"]=visible_poster
                    except Exception as exc:optional_failure("cinematic.direct_player_poster_handoff",exc)
                payload=_player_payload(play_item,self.profile,media_type="vod")
                def closed(result=None):
                    try:self["status"].setText("")
                    except Exception:pass
                    # Player persists resume position. Reload only lightweight content state
                    # and repaint the same rail; no Details screen/artwork cycle is involved.
                    try:
                        states=load_content_states(self.profile,self.media_type,self.grid_items) if self.grid_items else []
                        qualities=load_content_qualities(self.profile,self.media_type,self.grid_items) if self.grid_items else []
                        self._grid_item_state={}
                        for it,st,q in zip(self.grid_items,states,qualities):
                            rr=dict(st or {});rr["quality"]=q or "";self._grid_item_state[id(it)]=rr
                    except Exception as exc:optional_failure("cinematic.direct_play_state_reload",exc)
                    if self.page!=selected_page or not self.grid_items:
                        self.load_page(selected_page,selected_index);return
                    self.index=max(0,min(selected_index,len(self.grid_items)-1))
                    try:self["status"].setText("")
                    except Exception:pass
                    try:self._render_grid()
                    except Exception as exc:optional_failure("cinematic.direct_play_repaint",exc)
                    try:self._update_selection()
                    except Exception:pass
                    # Player can invalidate native adaptive/backdrop surfaces while
                    # our cached path markers remain unchanged. Rebind the exact
                    # same cached files once; no image work or network refresh.
                    try:self._cin_force_cached_visual_rebind()
                    except Exception as exc:optional_failure("cinematic.direct_play_cached_rebind",exc)
                try:self["status"].setText("")
                except Exception:pass
                self.session.openWithCallback(closed,UltraStalkerPlayer,str(url).strip(),name,"vod",engine,payload)
            except Exception as exc:
                try:self["status"].setText(_("Player failed: %s")%exc)
                except Exception:pass
        self._run_async(lambda handle:self.client.create_link(item,"vod",cancel_event=handle.cancel_event),ok,lambda e:self["status"].setText(_("Play failed: %s")%e))

    def _cin_fast_backdrop_handoff(self,item,row):
        """Directly bind the decoder-ready HDD surface when present."""
        try:
            package=(getattr(self,"_cin_page_packages",{}) or {}).get(int(self.index)) or self._cin_load_package(item,row) or {}
            path=str(package.get("backdrop_fast") or package.get("backdrop") or "")
            if not path or not os.path.isfile(path):return False
            if not self._cin_buffered_handoff("cin_backdrop","cin_backdrop_stage",path):return False
            self._cin_visual_key=self._record_key(row,item)
            return True
        except Exception as exc:
            optional_failure("cinematic.fast_backdrop_handoff",exc);return False

    def _apply_debounced_grid_focus(self):
        if self._screen_closed or not self.grid_items:return
        item=self.grid_items[self.index]
        # Focus path begins only after navigation settles. Refresh this one title
        # from HDD once, then use the canonical local package before any resolver.
        # The page renderer already loaded this row from HDD once. Reuse that
        # snapshot first; focus must not rescan artwork/detail manifests on every
        # arrow stop. Only fall back to _record() if the page snapshot is absent.
        row=self._cin_page_records.get(self.index,{}) or self._record(item) or {}
        self._cin_page_records[self.index]=row
        # release: never expose the raw 1920x1080 HDD master and then replace it
        # with the prepared cinematic package. That two-stage handoff was the
        # visible full-screen brighten/dim pulse on already-cached titles.
        # BLUE Cache Artwork already persists the final cinematic backdrop,
        # adaptive rows/chrome and title logo. Bind that final package directly.
        self._cin_apply_record(item,row,allow_build=False)
        package=(getattr(self,"_cin_page_packages",{}) or {}).get(int(self.index)) or self._cin_load_package(item,row)
        if package:
            self._cin_apply_package(item,row,package)
            # release: old/cached Cinematic packages may predate the persistent
            # poster-derived Details adaptive bundle.  If that one adaptive bundle
            # is missing, schedule ONLY the lightweight visual worker once.  It
            # samples the already-cached poster, persists the chrome, and never
            # re-fetches artwork/metadata or rebuilds the final backdrop.
            try:
                bundle=_load_visual_bundle(self.profile,self.media_type,item,row) or {}
                bchrome=bundle.get("chrome") if isinstance(bundle.get("chrome"),dict) else {}
                poster=str(row.get("poster_local") or "")
                adaptive_ready=bool(poster and os.path.isfile(poster) and bchrome.get("panel_detail") and bchrome.get("overview_detail"))
                if poster and os.path.isfile(poster) and not adaptive_ready:
                    self._cin_schedule_visuals(item,row)
            except Exception as exc:optional_failure("cinematic.adaptive_bundle_repair_schedule",exc)
            # release repair: cached presentation cannot suppress Details Authority.
            # Existing release BLUE packages stay reusable visually, while a single
            # Stable-Focus job repairs/loads canonical metadata when not ready yet.
            if row.get("_details_authority_ready"):
                return
            self._cin_schedule_focus(item);return
        # Cold/unprepared title: keep the previous prepared surface (or neutral
        # shell on first open) until the final package is complete. Never show
        # the raw master as an intermediate frame.
        self._cin_schedule_focus(item)

    def _cin_set_poll_interval(self,interval_ms,force=False):
        if self._screen_closed:return
        try:
            interval=max(80,int(interval_ms or 600))
            if not force and int(getattr(self,"_cin_poll_interval",0) or 0)==interval:return
            self._cin_poll.stop();self._cin_poll_interval=interval;self._cin_poll.start(interval,False)
        except Exception as exc:optional_failure("cinematic.poll_interval",exc)

    def _cin_poll_has_pending_work(self):
        if self._screen_closed:return False
        try:
            if not self._cin_jobs.empty():return True
        except Exception:pass
        for future in (getattr(self,"_cin_focus_future",None),getattr(self,"_cin_background_future",None)):
            try:
                if future is not None and not future.done():return True
            except Exception:return True
        if getattr(self,"_cin_logo_pending",None):return True
        return bool(self._async_poll_has_pending_work())

    def _cin_kick_poll(self):
        try:self._cin_set_poll_interval(120)
        except Exception:pass

    def _cin_poll_hdd(self):
        # Queue delivery only. No HDD scans, visible-row refresh, missed-title
        # recovery, prefetch or speculative work is permitted in the poll loop.
        if self._screen_closed:return
        self._cin_drain_jobs()
        self._cin_set_poll_interval(120 if self._cin_poll_has_pending_work() else 600)

    def _cin_refresh_one_visible_row(self):
        """Refresh one visible Settings-style row per HDD poll."""
        if not self.grid_items:return
        count=min(self.page_size,len(self.grid_items));pos=None
        for _ in range(count):
            candidate=int(self._cin_row_refresh_cursor or 0)%count;self._cin_row_refresh_cursor=candidate+1
            if candidate not in self._cin_row_complete:pos=candidate;break
        if pos is None:return
        try:
            item=self.grid_items[pos];row=self._record(item) or {}
            self["cin_list"].update_icon_row(pos,self._cin_list_row(pos,selected=(pos==self.index),record=row))
            if _library_readiness(row).get("complete"):self._cin_row_complete.add(pos)
        except Exception as exc:optional_failure("cinematic.row_refresh",exc)

    def _cin_fit_single_line_font(self, widget_name, text, max_size=42, min_size=9):
        """Conservative one-line fitter for very long titles/genres on OpenBH.

        OpenBH's calculateSize() can under-estimate mixed/Arabic glyph runs, so
        use a stronger width estimate first and only allow the native probe to
        reduce the font further.  The goal is simple: never let text escape its
        pill/title box, even for absurdly long provider/TMDB strings.
        """
        value=" ".join(str(text or "").replace("\n"," ").split()).strip()
        try:
            widget=self[widget_name];inst=widget.instance
            if inst is None:return
            width=max(70,int(inst.size().width())-36)
            try:
                if hasattr(inst,"setNoWrap"):inst.setNoWrap(1)
            except Exception as exc:optional_failure("cinematic.title_nowrap",exc)
            units=0.0;has_ar=False;has_latin=False
            for ch in value:
                code=ord(ch)
                if 0x0600<=code<=0x06ff:
                    has_ar=True;units+=0.86
                elif "A"<=ch<="Z":
                    has_latin=True;units+=0.78
                elif "a"<=ch<="z":
                    has_latin=True;units+=0.66
                elif ch.isdigit():units+=0.64
                elif ch.isspace():units+=0.38
                elif ch in ".,:;!?\'`-_/()[]{}":units+=0.42
                else:units+=0.72
            safety=1.34 if has_ar and has_latin else (1.28 if has_ar else 1.22)
            units=max(1.0,units*safety)
            estimated=int(float(width)/units)
            chosen=max(int(min_size),min(int(max_size),estimated))
            for size in range(chosen,int(min_size)-1,-1):
                try:
                    probe=eLabel();probe.setFont(gFont("Regular",size));probe.setText(value)
                    native=int(probe.calculateSize().width())
                except Exception:native=0
                # Keep a 10% OpenBH shaping safety margin.  A zero probe is not
                # treated as proof that the text fits; the conservative estimate
                # above remains authoritative.
                if native>0 and int(native*1.10)>width:
                    chosen=max(int(min_size),size-1);continue
                chosen=size;break
            inst.setFont(gFont("Regular",chosen))
        except Exception as exc:optional_failure("cinematic.title_adaptive_font",exc)

    def _cin_fit_compact_text(self, widget_name, text=None, max_size=22, min_size=8, padding=6):
        """Keep every compact Cinematic metadata value on one adaptive line.

        Short values retain the generous native size. Longer/localized values
        shrink only enough to stay inside the existing pill. This changes text
        rendering only; geometry, metadata and provider/TMDB values are untouched.
        """
        try:
            widget=self[widget_name];inst=widget.instance
            if inst is None:return
            value=" ".join(str(widget.getText() if text is None else text or "").replace("\n"," ").split()).strip()
            if not value:return
            try:
                if hasattr(inst,"setNoWrap"):inst.setNoWrap(1)
            except Exception:pass
            width=max(24,int(inst.size().width())-int(padding))
            units=0.0;has_ar=False
            for ch in value:
                code=ord(ch)
                if 0x0600<=code<=0x06ff:
                    has_ar=True;units+=0.80
                elif "A"<=ch<="Z":units+=0.72
                elif "a"<=ch<="z":units+=0.59
                elif ch.isdigit():units+=0.58
                elif ch.isspace():units+=0.34
                elif ch in ".,:;!?\'`-_/()[]{}•":units+=0.36
                else:units+=0.68
            safety=1.17 if has_ar else 1.10
            estimated=max(int(min_size),min(int(max_size),int(float(width)/max(1.0,units*safety))))
            chosen=int(min_size)
            for size in range(int(max_size),int(min_size)-1,-1):
                if size>estimated+2:continue
                try:
                    probe=eLabel();probe.setFont(gFont("Regular",size));probe.setText(value)
                    native=int(probe.calculateSize().width())
                except Exception:native=0
                painted=max(native,int(units*size*safety)) if native>0 else int(units*size*safety)
                if painted<=width:
                    chosen=size;break
            inst.setFont(gFont("Regular",chosen))
        except Exception as exc:optional_failure("cinematic.compact_adaptive_font",exc)

    def _cin_fit_runtime_like_details(self):
        """Use the native Details compact-text fitter itself for seasons/runtime.

        This deliberately reuses the exact Details implementation instead of a
        Cinematic copy, so receiver font metrics and adaptive sizing stay identical.
        """
        try:
            from .ui_screens_details import ContentDetailsScreen
            ContentDetailsScreen._fit_compact_text(self,"runtime_text",max_size=24,min_size=18,padding=4)
        except Exception as exc:
            optional_failure("cinematic.runtime_details_fit",exc)

    def _cin_fit_description_font(self):
        """Exact Native Details description fitting principle for the larger Cinematic box."""
        try:
            value=str(self["description"].getText() or "").strip();widget=self["description"]
            if widget.instance is None:return
            width=max(200,int(widget.instance.size().width()));height=max(40,int(widget.instance.size().height()))
            is_ar=bool(re.search(r"[\u0600-\u06ff]",value));factor=0.62 if is_ar else 0.55
            chosen=16
            for size in range(26,15,-1):
                chars_per_line=max(12,int(width/max(1.0,size*factor)))
                weighted=len(value)+value.count("\n")*chars_per_line
                lines=max(1,int(math.ceil(float(weighted)/float(chars_per_line))))
                if lines*int(size*1.34)<=height:
                    chosen=size;break
            widget.instance.setFont(gFont("Regular",chosen))
        except Exception as exc:optional_failure("cinematic.description_adaptive_font",exc)

    def _cin_schedule_foreign_english_cast(self,item,row,visible_title,current_cast):
        """Arabic titles keep Arabic cast; all other catalogues use Latin/English TMDB names."""
        if _cin_is_arabic_work(row,item,visible_title):return
        tmdb_id=(row or {}).get("tmdb_id")
        if not tmdb_id:return
        current=[str(x or "").strip() for x in (current_cast or []) if str(x or "").strip()]
        if current and all(_cin_person_name_is_latin(x) for x in current):return
        mt="tv" if self.media_type=="series" else "movie"
        sig="%s:%s"%(mt,int(tmdb_id))
        cached=list((getattr(self,"_cin_cast_cache",{}) or {}).get(sig) or [])
        if cached:
            self["cast_text"].setText(", ".join(cached[:6])[:220])
            self._cin_fit_single_line_font("cast_text",self["cast_text"].getText(),18,11)
            return
        if sig in getattr(self,"_cin_cast_pending",set()):return
        cfg=(getattr(self,"_grid_settings",None) or load_settings());credential=str(cfg.get("tmdb_credential") or "").strip()
        if not cfg.get("tmdb_enabled",True) or not credential:return
        timeout=min(7,max(3,int(cfg.get("timeout",10) or 10)))
        focus_sig=self._page_visual_key(item)
        self._cin_cast_pending.add(sig)
        def worker():
            names=[]
            try:
                client=TMDBClient(credential,"en-US",timeout)
                payload=client._get("/%s/%s/credits"%(mt,int(tmdb_id)),{"language":"en-US"}) or {}
                rows=[x for x in (payload.get("cast") or []) if isinstance(x,dict)]
                for actor in rows:
                    name=_cin_pick_latin_person_name(client,actor)
                    if name and name not in names:names.append(name)
                    if len(names)>=6:break
            except Exception as exc:optional_failure("cinematic.cast_language_fetch",exc)
            self._cin_jobs.put({"kind":"cast_en","cast_sig":sig,"focus_sig":focus_sig,"names":names})
        try:
            future=_CIN_CAST_EXECUTOR.submit(worker,_task_key="cin-cast:%x"%id(self),_replace_task_key=True)
            self_ref=weakref.ref(self)
            def cancelled(done,cast_sig=sig,ref=self_ref):
                owner=ref()
                if owner is not None and done.cancelled():owner._cin_cast_pending.discard(cast_sig)
            future.add_done_callback(cancelled)
        except Exception as exc:self._cin_cast_pending.discard(sig);optional_failure("cinematic.cast_language_submit",exc)

    def _cin_apply_record(self,item,row,allow_build=False):
        row=dict(row or {});new_key=self._record_key(row,item);identity_changed=bool(new_key and new_key!=self._cin_record_key)
        self._cin_last_record=row;self._cin_record_key=new_key
        if identity_changed:
            # Beta86 Instant Poster Handoff: exactly like the backdrop, keep the
            # previous poster visible until the next player's poster_halo is fully
            # prepared on HDD, then swap it atomically in _cin_drain_jobs().
            # Never hide/clear here; that caused the 2-3 second poster blink.
            pass
        # Native Details visible title/metadata, fed only from the one Global Library record.
        title=self._rail_title(item,row) or str(row.get("title") or row.get("name") or "")
        display_title=title[:120]
        self._cin_show_title_logo(item,row)
        self._cin_apply_details_overview(item,row)
        self["name"].setText(display_title)
        self._cin_fit_single_line_font("name",display_title,38,9)
        try:self["cin_list"].update_icon_row(self.index,self._cin_list_row(self.index,selected=True,record=row))
        except Exception:pass
        genres=row.get("genres") or row.get("genre") or []
        if isinstance(genres,str):genres=[genres]
        genre_value=_strip_arabic_tashkeel(" / ".join(str(x) for x in genres[:4])[:96])
        self["genre_text"].setText(genre_value)
        self._cin_fit_single_line_font("genre_text",genre_value,25,12)
        cast=row.get("cast") or row.get("actors") or []
        if isinstance(cast,str):
            cast=[x.strip() for x in re.split(r"[,،|]",cast) if x.strip()]
        names=[]
        for actor in cast[:8]:
            if isinstance(actor,dict):actor=actor.get("name") or actor.get("original_name") or ""
            actor=str(actor or "").strip()
            if actor and actor not in names:names.append(actor)
            if len(names)>=6:break
        arabic_work=_cin_is_arabic_work(row,item,display_title)
        visible_names=list(names) if arabic_work else [x for x in names if _cin_person_name_is_latin(x)]
        cast_value=_strip_arabic_tashkeel(", ".join(visible_names)[:220])
        self["cast_text"].setText(cast_value)
        self._cin_fit_single_line_font("cast_text",cast_value,18,11)
        try:self._cin_schedule_foreign_english_cast(item,row,display_title,names)
        except Exception as exc:optional_failure("cinematic.cast_language_schedule",exc)
        overlay=row.get("item_overlay") if isinstance(row.get("item_overlay"),dict) else {}
        overview=str(row.get("overview") or overlay.get("description") or item.get("description") or item.get("descr") or item.get("plot") or "").strip()
        self["description"].setText(_strip_arabic_tashkeel(overview[:1800]))
        self._cin_fit_description_font()
        q=self._quality(item);year=str(row.get("year") or overlay.get("year") or self._item_fallback_year(item))
        if self.media_type=="series":
            seasons=row.get("number_of_seasons") or overlay.get("number_of_seasons") or item.get("number_of_seasons") or item.get("seasons_count") or 0
            try:seasons=int(seasons or 0)
            except Exception:seasons=0
            runtime=((_("%d season")%seasons) if seasons==1 else ((_("%d seasons")%seasons) if seasons>1 else ""))
        else:
            runtime=self._format_runtime(row.get("runtime") or overlay.get("runtime"))
        self["quality_text"].setText(q[:10]);self["year_text"].setText(year[:8]);self["runtime_text"].setText(runtime[:14])
        self._cin_fit_compact_text("quality_text",q[:10],max_size=20,min_size=9,padding=8)
        self._cin_fit_compact_text("year_text",year[:8],max_size=22,min_size=10,padding=4)
        # release: series season text follows the native Details screen exactly:
        # same 24->18 fit range and 4px breathing room inside the same pill.
        if self.media_type=="series":
            self._cin_fit_runtime_like_details()
        else:
            self._cin_fit_compact_text("runtime_text",runtime[:14],max_size=24,min_size=15,padding=2)
        quality_asset=_quality_asset_name(q or self._item_fallback_title(item))
        if quality_asset:
            self._set_native_pixmap("quality_logo",quality_asset);self["quality_text"].setText("")
        else:self["quality_logo"].hide()
        if runtime:
            self._set_native_pixmap("runtime_pill_bg",(getattr(self,"_cin_last_chrome",{}) or {}).get("runtime") or "us66_neutral_pill_runtime.png")
            self._set_native_pixmap("runtime_icon","us89_folder_yellow_34.png" if self.media_type=="series" else "us86_episode_40.png")
        else:
            self["runtime_icon"].hide()
            # Test111: keep the fixed metadata shell intact while text hydrates.
            self._set_native_pixmap("runtime_pill_bg",(getattr(self,"_cin_last_chrome",{}) or {}).get("runtime") or "us66_neutral_pill_runtime.png")
        countries=row.get("countries") or row.get("country") or []
        raw_country=countries[0] if isinstance(countries,(list,tuple)) and countries else countries
        code=_country_code(raw_country);country_value=_normalized_country(raw_country);self["country_text"].setText(country_value)
        self._cin_fit_compact_text("country_text",country_value,max_size=20,min_size=8,padding=6)
        self._set_native_pixmap("country_flag","flags_iso/%s.png"%code.lower() if code else None)
        if allow_build and row:self._cin_schedule_visuals(item,row)

    def _cin_schedule_visuals(self,item,row):
        key=self._record_key(row,item)
        if not key or key in self._cin_pending:return
        self._cin_pending.add(key);index=int(self.index);backdrop=str(row.get("backdrop_local") or "");accent=str(row.get("adaptive_accent") or row.get("adaptive_primary") or "#c99141")
        fingerprint=str(row.get("adaptive_fingerprint") or "")
        source=str(row.get("poster_local") or "")
        if not (source and os.path.isfile(source)):
            source=backdrop
        if not fingerprint and source and os.path.isfile(source):
            try:
                _st=os.stat(source);fingerprint="%s:%s"%(int(_st.st_mtime),int(_st.st_size))
            except Exception:fingerprint=""
        def worker():
            result={"key":key,"index":index,"row":row,"backdrop":"","chrome":{},"settings_rows":{}}
            try:
                root=os.path.join(GENERATED,"cinematic",key);ensure_persistent_dirs(root)
                # release: never generate an adaptive backdrop during focus.
                # The cached final Cinematic backdrop is the content layer and
                # appears immediately; only rows/chrome may adapt afterwards.
                result["backdrop"]=""
                accent_key=hashlib.sha1((accent+fingerprint).encode("utf-8","ignore")).hexdigest()[:12]
                if source and os.path.isfile(source):
                    # Exact same adaptive Settings/Episodes row material builder.
                    settings_key="cin89_reference_rows_%s_%s"%(key,hashlib.sha1((source+fingerprint).encode("utf-8","ignore")).hexdigest()[:14])
                    result["settings_rows"]=_build_dynamic_settings_episode_rows(source,settings_key,selected_rim_only=True,cinematic_premium=True) or {}
                    chrome_key="cin534_focus_%s_%s"%(key,hashlib.sha1((source+fingerprint).encode("utf-8","ignore")).hexdigest()[:14])
                    result["chrome"]=_build_dynamic_details_chrome(source,chrome_key) or {}
            except Exception as exc:optional_failure("cinematic.visual_worker",exc)
            self._cin_jobs.put(result)
        try:
            future=_GRID_ACCENT_EXECUTOR.submit(worker,_task_key="cin-visual:%x"%id(self),_replace_task_key=True)
            self_ref=weakref.ref(self)
            def cancelled(done,visual_key=key,ref=self_ref):
                owner=ref()
                if owner is not None and done.cancelled():owner._cin_pending.discard(visual_key)
            future.add_done_callback(cancelled)
        except Exception as exc:self._cin_pending.discard(key);optional_failure("cinematic.visual_submit",exc)

    def _cin_drain_jobs(self):
        while True:
            try:r=self._cin_jobs.get_nowait()
            except queue.Empty:break
            except Exception:break
            kind=str(r.get("kind") or "")
            if kind=="hidden_done":continue
            if kind=="title_logo":
                sig=str(r.get("sig") or "");self._cin_logo_pending.discard(sig)
                if self._screen_closed or not self.grid_items:continue
                current=self.grid_items[self.index];row=self._record(current) or {};current_sig,_unused=self._cin_title_logo_signature(current,row)
                if sig!=current_sig:continue
                path=str(r.get("path") or "")
                try:
                    if path and os.path.isfile(path) and self["title_logo"].instance is not None:
                        self["title_logo"].instance.setPixmapFromFile(path);self._cin_logo_path=path;self["title_logo"].show()
                    else:self["title_logo"].hide();self._cin_logo_path=""
                except Exception as exc:optional_failure("cinematic.title_logo_apply",exc)
                continue
            if kind=="cast_en":
                cast_sig=str(r.get("cast_sig") or "");self._cin_cast_pending.discard(cast_sig)
                names=[str(x) for x in (r.get("names") or []) if str(x).strip()]
                if names:self._cin_cast_cache[cast_sig]=names[:6]
                if self._screen_closed or not self.grid_items or not names:continue
                current=self.grid_items[self.index]
                if str(r.get("focus_sig") or "")!=self._page_visual_key(current):continue
                try:
                    value=", ".join(names[:6])[:220]
                    self["cast_text"].setText(value);self._cin_fit_single_line_font("cast_text",value,18,11)
                except Exception as exc:optional_failure("cinematic.cast_language_apply",exc)
                continue
            if kind=="focus":
                if self._screen_closed or not self.grid_items:continue
                current=self.grid_items[self.index];sig=self._page_visual_key(current)
                if str(r.get("sig") or "")!=sig:continue
                row=r.get("row") if isinstance(r.get("row"),dict) else (self._record(current) or {})
                package=r.get("package") if isinstance(r.get("package"),dict) else {}
                # Publish the verified originals even if a presentation derivative
                # failed to build; Details/Player must never lose a good HDD poster.
                try:
                    poster=str(row.get("poster_local") or "");backdrop=str(row.get("backdrop_local") or "")
                    if poster and os.path.isfile(poster):
                        current["_cin_provider_poster_local"]=poster;current["_ultra_palette_source"]=poster
                        current["_ultra_poster_source"]=poster;current["_player_poster"]=poster;current["_adaptive_source_local"]=poster
                        self._grid_palette_sources[self.index]=poster
                    if backdrop and os.path.isfile(backdrop):
                        current["_cin_provider_backdrop_local"]=backdrop;current["_backdrop_source_local"]=backdrop
                except Exception as exc:optional_failure("cinematic.focus_handoff",exc)
                self._cin_apply_record(current,row,allow_build=False)
                if package:self._cin_apply_package(current,row,package)
                continue
            self._cin_pending.discard(str(r.get("key") or ""))
            if self._screen_closed or not self.grid_items:continue
            item=self.grid_items[self.index];row=self._record(item);key=self._record_key(row,item)
            if str(r.get("key") or "")!=key:continue
            # Adaptive completion is decoration-only. Never replace the already
            # visible cached final backdrop; stale/slow adaptive work may update
            # rows and chrome only.
            settings_rows=r.get("settings_rows") if isinstance(r.get("settings_rows"),dict) else {}
            if settings_rows:
                normal=str(settings_rows.get("normal") or "")
                selected=str(settings_rows.get("selected") or "")
                changed=False
                if normal and os.path.isfile(normal) and normal!=self._settings_row_asset:
                    self._settings_row_asset=normal;changed=True
                if selected and os.path.isfile(selected) and selected!=self._settings_row_selected_asset:
                    self._settings_row_selected_asset=selected;changed=True
                if changed:
                    try:self._render_grid()
                    except Exception as exc:optional_failure("cinematic.settings_rows_apply",exc)
            chrome=r.get("chrome") if isinstance(r.get("chrome"),dict) else {}
            if chrome:
                try:
                    # Persist this poster-derived adaptive result as the same
                    # Details visual bundle used everywhere else.  Future visits,
                    # portal changes and cold restarts become HDD-only.
                    try:
                        poster=str((row or {}).get("poster_local") or "")
                        if poster and os.path.isfile(poster):
                            _save_visual_bundle(self.profile,self.media_type,item,{"poster":poster,"chrome":chrome},snapshot=row)
                    except Exception as exc:optional_failure("cinematic.adaptive_bundle_repair_save",exc)
                    self._apply_native_detail_chrome(chrome)
                    # Chrome application may reveal an empty runtime/season pill;
                    # immediately re-apply the same final record so missing values
                    # stay hidden and outside remains identical to Details state.
                    self._cin_apply_record(item,row,allow_build=False)
                except Exception as exc:optional_failure("cinematic.native_chrome_apply",exc)
