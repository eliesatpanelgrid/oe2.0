# -*- coding: utf-8 -*-
"""Backdrop Grid 2: isolated seven-poster variant of the proven Backdrop Grid."""
from __future__ import absolute_import
import hashlib, os, re
try:
    from enigma import ePoint, eSize, gFont
except Exception:
    ePoint=eSize=gFont=None
from . import ui_backdrop_grid as _bg

BACKDROP_GRID2_SKIN = ""

def configure_backdrop_grid2(**deps):
    globals().update(deps)
    if "BACKDROP_GRID2_SKIN" in deps:
        PremiumBackdropGrid2Screen.skin = deps["BACKDROP_GRID2_SKIN"]

class PremiumBackdropGrid2Screen(_bg.PremiumBackdropGridScreen):
    """Same Backdrop Grid behavior, with a seven-card enlarged rail only."""
    skin = BACKDROP_GRID2_SKIN
    columns = 7
    page_size = 7
    image_size = (232, 349)
    card_positions = [(55 + (263 * i), 679) for i in range(7)]

    def _bd_pin_counter_status(self):
        if ePoint is None or eSize is None:
            return
        try:
            for name,x,y,w,h in (("page_label",55,649,470,28),("status",650,649,620,28)):
                inst=self[name].instance
                if inst is not None:
                    inst.move(ePoint(x,y));inst.resize(eSize(w,h))
        except Exception as exc:
            _bg.optional_failure("backdrop_grid2.pin_counter",exc)

    def _bd_force_geometry(self):
        if ePoint is None or eSize is None:
            return
        try:
            for name,x,y,w,h in (("page_label",55,649,470,28),("status",650,649,620,28)):
                inst=self[name].instance
                if inst is not None:
                    inst.move(ePoint(x,y));inst.resize(eSize(w,h))
            for name,x,y,w,h in (("title_logo",55,75,432,210),("bd_title_fallback",55,101,500,138)):
                inst=self[name].instance
                if inst is not None:
                    inst.move(ePoint(x,y));inst.resize(eSize(w,h))
            hud=(
                ("bd_year_bg",55,295,130,50),("bd_year",100,302,72,36),
                ("bd_quality_bg",198,295,150,50),("bd_quality_logo",212,303,122,34),("bd_quality",214,302,118,36),
                ("bd_runtime_bg",361,295,150,50),("bd_runtime_icon",369,300,40,40),("bd_runtime",411,300,88,40),
                ("bd_genre_bg",55,355,440,50),("bd_genre",72,362,406,36),
                ("bd_overview_bg",55,415,456,232),("bd_overview",76,427,414,206),
            )
            for name,x,y,w,h in hud:
                inst=self[name].instance
                if inst is not None:
                    inst.move(ePoint(x,y));inst.resize(eSize(w,h))
            for pos in range(self.page_size):
                x=55+(263*pos)
                for name,gx,gy,gw,gh in (
                    ("art%d"%pos,x,679,232,349),("card_chrome%d"%pos,x,679,232,349),
                    ("item_title%d"%pos,2000,0,1,1),("item_meta%d"%pos,2000,0,1,1)):
                    inst=self[name].instance
                    if inst is not None:
                        inst.move(ePoint(gx,gy));inst.resize(eSize(gw,gh))
            for name in ("selection","selection_adaptive"):
                inst=self[name].instance
                if inst is not None:
                    inst.move(ePoint(55,679));inst.resize(eSize(232,349))
            self._scaled_card_positions=[(int((55+263*i)*self._grid_sx),int(679*self._grid_sy)) for i in range(self.page_size)]
        except Exception as exc:
            _bg.optional_failure("backdrop_grid2.force_geometry",exc)


    def _bd_apply_default_premium_hud(self):
        if getattr(self,"_bd_hud_adaptive_active",False):
            return
        mapping={
            "bd_year_bg":"us6571_bd_year_130x50.png",
            "bd_quality_bg":"us6571_bd_quality_150x50.png",
            "bd_runtime_bg":"us6571_bd_runtime_150x50.png",
            "bd_genre_bg":"us6571_bd_genre_440x50.png",
            "bd_overview_bg":"us8_bd2_overview_456x232.png",
        }
        for widget,filename in mapping.items():
            try:
                path=_bg.asset(filename)
                if _bg._valid_file(path):
                    self._bd_set_pixmap_file(widget,path,show=True,release_first=True)
            except Exception as exc:
                _bg.optional_failure("backdrop_grid2.default_hud",exc)

    def _bd_apply_fixed_rail_chrome(self):
        """Reuse one native rail-frame pixmap across all Backdrop Grid 2 slots.

        Grid 2 intentionally keeps its larger 232x349 geometry, but it must follow
        the proven Grid 1 native-surface lifecycle: decode the packaged neutral
        frame once, share that gPixmap across visible slots, and explicitly release
        the previous surface before any file-load fallback.  This avoids repeated
        gAccel allocations while preserving the exact visual design.
        """
        fixed=_bg.asset("poster_frame_neutral_bd2_232x349.png")
        fixed_pix=None
        try:
            fixed_pix=_bg.cached_png(fixed) if _bg._valid_file(fixed) else None
        except Exception:
            fixed_pix=None
        for pos in range(int(getattr(self,"page_size",7) or 7)):
            try:
                self["item_title%d"%pos].setText("");self["item_title%d"%pos].hide()
                self["item_meta%d"%pos].setText("");self["item_meta%d"%pos].hide()
            except Exception:pass
            try:
                chrome=self["card_chrome%d"%pos]
                if pos < len(getattr(self,"grid_items",[]) or []):
                    if chrome.instance is not None:
                        if fixed_pix is not None:
                            chrome.instance.setPixmap(fixed_pix)
                        else:
                            chrome.instance.setPixmap(None)
                            chrome.instance.setPixmapFromFile(fixed)
                    chrome.show()
                else:
                    chrome.hide()
                    if chrome.instance is not None:chrome.instance.setPixmap(None)
            except Exception as exc:
                _bg.optional_failure("backdrop_grid2.fixed_rail_chrome",exc)

    def _fit_overview_font(self, text):
        try:
            inst=self["bd_overview"].instance
            if inst is None or gFont is None:return
            text=str(text or "")
            start=27
            if len(text)>520:start=22
            elif len(text)>420:start=23
            elif len(text)>320:start=24
            elif len(text)>240:start=25
            elif len(text)>170:start=26
            for candidate in range(start,20,-1):
                inst.setFont(gFont("Regular",candidate))
                try:
                    if int(inst.calculateSize().height())<=198:break
                except Exception:break
        except Exception as exc:
            _bg.optional_failure("backdrop_grid2.overview_fit",exc)

    def _bd_hud_from_package(self, package, key):
        if not isinstance(package,dict) or not package:return {}
        mem_key="bd2|"+str(key or "")+"|"+str(package.get("accent") or "")
        cached=self._bd_hud_cache.get(mem_key)
        if isinstance(cached,dict) and cached:return cached
        sources={
            "year":package.get("year") or package.get("panel_detail"),
            "quality":package.get("quality") or package.get("panel_detail"),
            "runtime":package.get("runtime") or package.get("panel_detail"),
            "genre":package.get("genre_detail") or package.get("panel_detail"),
            "overview":package.get("overview_detail") or package.get("panel_detail"),
        }
        root=os.path.join(_bg.GENERATED,"backdrop_grid2_hud_v1")
        try:
            if not os.path.isdir(root):os.makedirs(root)
        except Exception:pass
        out={}
        for name,size in (("year",(130,50)),("quality",(150,50)),("runtime",(150,50)),("genre",(440,50)),("overview",(456,232))):
            source=str(sources.get(name) or "")
            if not _bg._valid_file(source):continue
            try:stamp="%s|%s|%s|%s|bd2v1"%(source,int(os.path.getmtime(source)),size[0],size[1])
            except Exception:stamp="%s|%s|%s|bd2v1"%(source,size[0],size[1])
            target=os.path.join(root,"%s_%s.png"%(name,hashlib.sha1(stamp.encode("utf-8","ignore")).hexdigest()[:18]))
            out[name]=_bg._nine_slice(source,target,size) or source
        accent=str(package.get("accent") or "#69c9f4")
        mood_key=re.sub(r"[^0-9a-fA-F]","",accent)[:6] or "69c9f4"
        out["mood"]=_bg._mood_overlay(os.path.join(root,"mood_%s.png"%mood_key),accent)
        self._bd_hud_cache[mem_key]=out
        return out

    def _bd_selection_overlay_for_poster(self,path):
        try:
            if not path or not os.path.isfile(path) or _bg._PILImage is None or _bg._ImageDraw is None:return ""
            try:
                st=os.stat(path);stamp="%s|%s"%(int(getattr(st,"st_mtime_ns",int(st.st_mtime*1e9))),int(st.st_size))
            except Exception:stamp=str(path)
            key=hashlib.sha1((str(path)+"|"+stamp+"|bd2-exact-232x349-v1").encode("utf-8","ignore")).hexdigest()[:20]
            target=os.path.join(_bg.THUMB_CACHE_DIR,"bd2sel_%s_exact_232x349_v1.png"%key)
            if _bg._valid_file(target):return target
            primary,_secondary=_bg._dynamic_palette(path)
            r,g,b=_bg._lift_dynamic_accent(primary,0.60,0.58)
            Image=_bg._PILImage; Draw=_bg._ImageDraw
            canvas=Image.new("RGBA",(232,349),(0,0,0,0))
            glow=Image.new("RGBA",canvas.size,(0,0,0,0));gd=Draw.Draw(glow)
            gd.rectangle((5,5,226,343),outline=(r,g,b,245),width=10)
            try:
                from PIL import ImageFilter
                glow=glow.filter(ImageFilter.GaussianBlur(5))
            except Exception:pass
            canvas=Image.alpha_composite(canvas,glow)
            d=Draw.Draw(canvas)
            core=(min(255,r+92),min(255,g+92),min(255,b+92),255)
            d.rectangle((1,1,230,347),outline=core,width=3)
            parent=os.path.dirname(target)
            if parent and not os.path.isdir(parent):os.makedirs(parent)
            tmp=target+".tmp.%s"%os.getpid();canvas.save(tmp,"PNG",optimize=True);os.replace(tmp,target)
            return target if _bg._valid_file(target) else ""
        except Exception as exc:
            _bg.optional_failure("backdrop_grid2.selection_overlay",exc);return ""
