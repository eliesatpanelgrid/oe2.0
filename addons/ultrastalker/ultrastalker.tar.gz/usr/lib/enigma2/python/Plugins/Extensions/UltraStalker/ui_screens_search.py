# -*- coding: utf-8 -*-
"""Clean poster-first global Movies/Series search."""
from __future__ import absolute_import
import hashlib
import os
import queue
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

from . import _
from Screens.Screen import Screen
try:
    from Screens.VirtualKeyBoard import VirtualKeyBoard
except Exception:
    VirtualKeyBoard = None
try:
    from Screens.InputBox import InputBox
except Exception:
    InputBox = None

from .ui_async import AsyncScreenMixin
from .ui_transition import TransitionMixin
from .persistent_cache import load_detail_snapshot, load_shared_detail_snapshot
from .ui_artwork_helpers import _image_url
from . import ui_image_loader as _uil

SEARCH_SKIN = ""
_SEARCH_ART_EXECUTOR = ThreadPoolExecutor(max_workers=2, thread_name_prefix="ultrastalker-search-art")


def configure_search_screen(**deps):
    globals().update(deps)
    if "SEARCH_SKIN" in deps:
        PortalGlobalSearchScreen.skin = deps["SEARCH_SKIN"]


def _valid(path):
    try:
        return bool(path and os.path.isfile(str(path)) and os.path.getsize(str(path)) > 100)
    except Exception:
        return False


class PortalGlobalSearchScreen(Screen, AsyncScreenMixin, TransitionMixin):
    skin = SEARCH_SKIN
    PAGE_SIZE = 7
    POSTER_SIZE = (206, 310)

    def __init__(self, session, profile, client):
        Screen.__init__(self, session)
        self._async_init()
        self.onClose.append(self._stop_async)
        self.profile = profile
        self.client = client
        self.results = []
        self.query = ""
        self.index = 0
        self._search_partial_jobs = queue.Queue()
        self._poster_jobs = queue.Queue()
        self._poster_generation = 0
        self._search_seen = set()
        self._search_errors = []
        self._search_portal_count = 0
        self._search_settings = {}
        self._render_signature = ()
        self["page_adaptive_bg"] = Pixmap()
        self["search_query"] = Label(_("Search"))
        self["search_status"] = Label("")
        self["page_label"] = Label("")
        for i in range(self.PAGE_SIZE):
            self["result_art%d" % i] = Pixmap()
            self["result_sel%d" % i] = Pixmap()
            self["result_title%d" % i] = Label("")
            self["result_meta%d" % i] = Label("")
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "cancel": self.close,
                "red": self.close,
                "green": self.prompt,
                "ok": self.select,
                "left": self.move_left,
                "right": self.move_right,
                "up": self.page_left,
                "down": self.page_right,
            },
            -1,
        )
        self._first_prompt_pending = True
        self._prompt_timer = eTimer()
        self._prompt_timer_conn = None
        try:
            self._prompt_timer_conn = self._prompt_timer.timeout.connect(self._open_first_prompt)
        except Exception:
            self._prompt_timer.callback.append(self._open_first_prompt)
        self.onClose.append(self._stop_prompt_timer)
        self.onClose.append(self._stop_search_hooks)
        self.onLayoutFinish.append(self._ready)
        self.onShown.append(self._shown)

    def _ready(self):
        try:
            hero = {}
            with open(HOME_HERO_FILE, "r", encoding="utf-8") as fh:
                state = json.load(fh)
                hero = state.get("hero") if isinstance(state, dict) else {}
            src = str(
                (hero or {}).get("display_backdrop_local")
                or (hero or {}).get("backdrop_local")
                or (hero or {}).get("prepared")
                or ""
            )
            if _valid(src) and self["page_adaptive_bg"].instance is not None:
                self["page_adaptive_bg"].instance.setPixmapFromFile(src)
                self["page_adaptive_bg"].show()
        except Exception as exc:
            optional_failure("ui.search_clean_bg", exc)
        self._render()

    def _shown(self):
        if not self._first_prompt_pending:
            return
        self._first_prompt_pending = False
        try:
            self.onShown.remove(self._shown)
        except Exception:
            pass
        try:
            self._prompt_timer.start(120, True)
        except Exception:
            self._open_first_prompt()

    def _open_first_prompt(self):
        if not getattr(self, "_screen_closed", False):
            self.prompt()

    def _stop_prompt_timer(self):
        try:
            self._prompt_timer.stop()
        except Exception:
            pass
        try:
            if self._prompt_timer_conn is not None:
                self._prompt_timer_conn.disconnect()
        except Exception:
            pass
        try:
            if self._open_first_prompt in self._prompt_timer.callback:
                self._prompt_timer.callback.remove(self._open_first_prompt)
        except Exception:
            pass

    def _stop_search_hooks(self):
        self._poster_generation += 1
        for q in (self._search_partial_jobs, self._poster_jobs):
            try:
                while True:
                    q.get_nowait()
            except Exception:
                pass
        for i in range(self.PAGE_SIZE):
            try:
                art = self["result_art%d" % i]
                sel = self["result_sel%d" % i]
                if art.instance is not None:
                    art.instance.setPixmap(None)
                if sel.instance is not None:
                    sel.instance.setPixmap(None)
            except Exception:
                pass

    def _drain_jobs(self):
        AsyncScreenMixin._drain_jobs(self)
        if self._screen_closed:
            return
        self._drain_search_partials()
        self._drain_poster_jobs()

    @staticmethod
    def _profile_key(profile):
        return (
            str((profile or {}).get("portal") or "").rstrip("/").lower(),
            str((profile or {}).get("mac") or "").upper(),
        )

    @staticmethod
    def _norm(value):
        return " ".join(str(value or "").casefold().replace("_", " ").replace("-", " ").split())

    def _merge_search_rows(self, rows):
        added = 0
        for item in rows or []:
            if not isinstance(item, dict):
                continue
            p = item.get("_search_profile") or {}
            typ = item.get("_search_media_type") or "vod"
            identity = (
                item.get("id")
                or item.get("movie_id")
                or item.get("series_id")
                or item.get("cmd")
                or item.get("name")
                or item.get("title")
            )
            key = (self._profile_key(p), typ, str(identity))
            if key in self._search_seen:
                continue
            self._search_seen.add(key)
            self.results.append(item)
            added += 1
        return added

    def _fast_client_search(self, client, term, limit, cancel_event):
        if cancel_event is not None and cancel_event.is_set():
            return []
        fn = getattr(client, "search_content_fast", None) or getattr(client, "search_content", None)
        if callable(fn):
            try:
                return fn(
                    term,
                    media_types=("vod", "series"),
                    limit=limit,
                    max_pages=min(40, int((self._search_settings or {}).get("search_max_pages", 40) or 40)),
                    cancel_event=cancel_event,
                    time_budget=min(8, float((self._search_settings or {}).get("search_time_budget", 8) or 8)),
                ) or []
            except TypeError:
                try:
                    return fn(term, media_types=("vod", "series"), limit=limit, cancel_event=cancel_event) or []
                except Exception:
                    pass
            except Exception:
                pass
        out = []
        needle = self._norm(term)
        deadline = time.monotonic() + 8.0
        for typ in ("vod", "series"):
            if len(out) >= limit:
                break
            for page in range(1, 9):
                if time.monotonic() >= deadline or (cancel_event is not None and cancel_event.is_set()):
                    break
                try:
                    payload = client.ordered_page(typ, "*", page, cancel_event=cancel_event) or {}
                except Exception:
                    break
                rows = [x for x in payload.get("items", []) if isinstance(x, dict)]
                if not rows:
                    break
                for raw in rows:
                    hay = self._norm(
                        str(raw.get("name") or raw.get("title") or "")
                        + " "
                        + str(raw.get("description") or raw.get("descr") or "")
                    )
                    if needle and needle in hay:
                        item = dict(raw)
                        item["_search_media_type"] = typ
                        out.append(item)
                        if len(out) >= limit:
                            break
                if len(out) >= limit:
                    break
        return out

    def prompt(self):
        recent = _load_recent_searches()
        title = _("Search Movies & Series")
        if recent:
            title += "  •  " + _("Recent: %s") % ", ".join(recent[:3])
        if VirtualKeyBoard is not None:
            self.session.openWithCallback(self._search, VirtualKeyBoard, title=title, text=self.query)
        elif InputBox is not None:
            self.session.openWithCallback(self._search, InputBox, title=title, text=self.query, maxSize=60)
        else:
            self.session.open(MessageBox, _("Search keyboard is unavailable on this image."), MessageBox.TYPE_ERROR, timeout=5)

    def _search(self, term=None):
        term = one_line(term or "", 60)
        if not term:
            return
        self.query = term
        _save_recent_search(term)
        cfg = load_settings()
        self._search_settings = dict(cfg)
        self.results = []
        self.index = 0
        self._search_seen = set()
        self._search_errors = []
        self._search_portal_count = 0
        try:
            while True:
                self._search_partial_jobs.get_nowait()
        except Exception:
            pass
        self["search_query"].setText(_("Search: %s") % term)
        self["search_status"].setText(_("Searching..."))
        self._render()
        multi = bool(cfg.get("multi_portal_search", True))
        limit = max(20, min(100, int(cfg.get("content_page_size", 50) or 50)))

        def work(handle):
            profiles = load_profiles() if multi else [self.profile]
            current_key = self._profile_key(self.profile)
            profiles = sorted(
                [p for p in profiles if isinstance(p, dict)],
                key=lambda p: 0 if self._profile_key(p) == current_key else 1,
            )
            if not profiles:
                profiles = [self.profile]
            all_rows = []
            errors = []
            portal_count = len(profiles)
            # Current portal first, then the rest sequentially. This avoids a socket storm.
            for pos, p in enumerate(profiles):
                if handle.cancelled():
                    break
                key = self._profile_key(p)
                owned = True
                cl = None
                try:
                    # Search owns a short-timeout client even for the active portal.
                    # This keeps a slow/unsupported search request away from foreground sockets.
                    cl = _client_from_profile(p, timeout=min(5, int(cfg.get("timeout", 10) or 10)))
                    rows = self._fast_client_search(cl, term, limit, handle.cancel_event)
                    tagged = []
                    for row in rows:
                        if not isinstance(row, dict):
                            continue
                        item = dict(row)
                        item["_search_profile"] = dict(p)
                        item["_search_portal_name"] = str(p.get("name") or ("Server %d" % (pos + 1)))
                        tagged.append(item)
                    if not self._screen_closed:
                        self._search_partial_jobs.put((tagged, None, portal_count))
                    all_rows.extend(tagged)
                    if pos == 0 and len(tagged) >= limit:
                        break
                except Exception as exc:
                    err = "%s: %s" % (p.get("name") or p.get("portal") or "Portal", exc)
                    errors.append(err)
                    if not self._screen_closed:
                        self._search_partial_jobs.put(([], err, portal_count))
                finally:
                    if owned and cl is not None:
                        try:
                            cl.close()
                        except Exception:
                            pass
            return all_rows, errors, portal_count

        def ok(result):
            rows, errors, count = result
            self._search_portal_count = count
            self._merge_search_rows(rows)
            self._search_errors = list(dict.fromkeys(self._search_errors + errors))
            self._render()
            self["search_status"].setText(
                (_("%d result(s)") % len(self.results)) if self.results else _("No matching content")
            )

        self._run_async(work, ok, lambda e: self["search_status"].setText(_friendly_error(e)))

    def _drain_search_partials(self):
        changed = False
        while True:
            try:
                rows, error, count = self._search_partial_jobs.get_nowait()
            except queue.Empty:
                break
            except Exception:
                break
            self._search_portal_count = max(self._search_portal_count, int(count or 0))
            if error:
                self._search_errors.append(error)
            if self._merge_search_rows(rows):
                changed = True
        if changed:
            self._render()
            self["search_status"].setText(_("Searching... %d result(s)") % len(self.results))

    def _visible_range(self):
        page = self.index // self.PAGE_SIZE if self.results else 0
        start = page * self.PAGE_SIZE
        return page, start, self.results[start : start + self.PAGE_SIZE]

    def _render(self):
        self["search_query"].setText((_("Search: %s") % self.query) if self.query else _("Search"))
        page, start, rows = self._visible_range()
        pages = max(1, (len(self.results) + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
        self["page_label"].setText(
            (_("Page %d / %d  •  %d result(s)") % (page + 1, pages, len(self.results)))
            if self.results
            else ""
        )
        signature = tuple(self._poster_identity(x) for x in rows)
        reload_art = signature != self._render_signature
        if reload_art:
            self._render_signature = signature
            self._poster_generation += 1
        generation = self._poster_generation
        for slot in range(self.PAGE_SIZE):
            art = self["result_art%d" % slot]
            sel = self["result_sel%d" % slot]
            title = self["result_title%d" % slot]
            meta = self["result_meta%d" % slot]
            if slot >= len(rows):
                if reload_art:
                    try:
                        if art.instance is not None: art.instance.setPixmap(None)
                    except Exception: pass
                art.hide(); sel.hide(); title.setText(""); meta.setText("")
                continue
            item = rows[slot]
            typ = item.get("_search_media_type") or "vod"
            raw = item.get("name") or item.get("title") or _("Result")
            title.setText(premium_title(raw, True)[:34])
            source = str(item.get("_search_portal_name") or "")[:18]
            meta.setText((_("MOVIE") if typ == "vod" else _("SERIES")) + (("  •  " + source) if source else ""))
            if reload_art:
                try:
                    if art.instance is not None:
                        art.instance.setPixmap(None)
                        art.instance.setPixmapFromFile(asset("grid_placeholder_series_921.png" if typ == "series" else "grid_placeholder_movie_921.png"))
                    art.show()
                except Exception: pass
                self._schedule_poster(generation, slot, item)
            absolute = start + slot
            if absolute == self.index: sel.show()
            else: sel.hide()

    def _poster_identity(self, item):
        return "%s:%s:%s" % (
            self._profile_key(item.get("_search_profile") or self.profile),
            item.get("_search_media_type") or "vod",
            item.get("id")
            or item.get("movie_id")
            or item.get("series_id")
            or item.get("name")
            or item.get("title")
            or "",
        )

    def _absolute_art_url(self, value, profile):
        text = str(value or "").strip()
        if not text:
            return ""
        if text.startswith("//"):
            scheme = urllib.parse.urlsplit(str((profile or {}).get("portal") or "http://")).scheme or "http"
            return scheme + ":" + text
        if text.startswith(("http://", "https://")):
            return text
        return urllib.parse.urljoin(
            str((profile or {}).get("portal") or "").rstrip("/") + "/", text.lstrip("/")
        )

    def _local_search_poster(self, item):
        profile = item.get("_search_profile") if isinstance(item.get("_search_profile"), dict) else self.profile
        typ = item.get("_search_media_type") or "vod"
        clean = dict(item)
        clean.pop("_search_profile", None)
        clean.pop("_search_portal_name", None)
        try:
            snap = load_shared_detail_snapshot(profile, typ, clean) if clean.get("_xtream") else load_detail_snapshot(profile, typ, clean)
            p = str((snap or {}).get("poster_local") or "")
            if _valid(p):
                digest = hashlib.sha1((p + "|search206x310").encode("utf-8", "ignore")).hexdigest()
                thumb = os.path.join(_uil.IMAGE_CACHE_DIR, "search_%s_206x310.png" % digest)
                if _valid(thumb):
                    return thumb
                try:
                    return _uil._build_thumbnail(p, thumb, self.POSTER_SIZE) or p
                except Exception:
                    return p
        except Exception:
            pass
        return ""

    def _schedule_poster(self, generation, slot, item):
        ident = self._poster_identity(item)
        local = self._local_search_poster(item)
        if local:
            try:
                self._poster_jobs.put((generation, slot, ident, local))
            except Exception:
                pass
            return
        profile = item.get("_search_profile") if isinstance(item.get("_search_profile"), dict) else self.profile
        url = self._absolute_art_url(_image_url(item), profile)
        try:
            url = _uil._optimized_artwork_url(url, False) if url else ""
        except Exception:
            pass
        if not url:
            return

        def worker():
            temp = None
            try:
                if self._screen_closed or generation != self._poster_generation:
                    return
                digest = hashlib.sha1(url.encode("utf-8", "ignore")).hexdigest()
                thumb = _uil._thumb_path(digest, self.POSTER_SIZE)
                if _uil._valid_cache_file(thumb):
                    path = thumb
                else:
                    original = _uil._find_original_artwork(digest)
                    if original:
                        path = _uil._build_thumbnail(original, thumb, self.POSTER_SIZE) or original
                    else:
                        headers = _uil._safe_image_headers(url, profile, self.client)
                        req = urllib.request.Request(url, headers=headers)
                        opener = _uil._safe_image_opener(url, profile)
                        temp = os.path.join(
                            _uil.IMAGE_CACHE_DIR,
                            "search_%s.download.%d.%d" % (digest, os.getpid(), threading.get_ident()),
                        )
                        total = 0
                        head = b""
                        _uil._persistent_write_require(temp)
                        with opener.open(req, timeout=3.5) as response, open(temp, "wb") as h:
                            ctype = (response.headers.get("Content-Type") or "").lower()
                            while True:
                                if self._screen_closed or generation != self._poster_generation:
                                    return
                                chunk = response.read(64 * 1024)
                                if not chunk:
                                    break
                                if not head:
                                    head = chunk[:16]
                                total += len(chunk)
                                if total > 3 * 1024 * 1024:
                                    raise ValueError("poster too large")
                                h.write(chunk)
                        if total <= 100:
                            return
                        if head.startswith(b"\x89PNG") or "png" in ctype:
                            ext = ".png"
                        elif head[:4] == b"RIFF" or "webp" in ctype:
                            ext = ".webp"
                        else:
                            ext = ".jpg"
                        original = os.path.join(_uil.IMAGE_CACHE_DIR, digest + ext)
                        if not _uil._persistent_write_ok(original):
                            return
                        os.replace(temp, original)
                        temp = None
                        _uil._cache_artwork_path(digest, original)
                        path = _uil._build_thumbnail(original, thumb, self.POSTER_SIZE) or original
                if not self._screen_closed and generation == self._poster_generation:
                    self._poster_jobs.put((generation, slot, ident, path))
            except Exception as exc:
                optional_failure("ui.search_poster", exc)
            finally:
                if temp:
                    try:
                        if os.path.exists(temp):
                            os.unlink(temp)
                    except Exception:
                        pass

        try:
            _SEARCH_ART_EXECUTOR.submit(worker)
        except Exception as exc:
            optional_failure("ui.search_poster_submit", exc)

    def _drain_poster_jobs(self):
        _page, _start, rows = self._visible_range()
        while True:
            try:
                generation, slot, ident, path = self._poster_jobs.get_nowait()
            except queue.Empty:
                break
            except Exception:
                break
            if generation != self._poster_generation or slot >= len(rows) or not _valid(path):
                continue
            if ident != self._poster_identity(rows[slot]):
                continue
            try:
                w = self["result_art%d" % slot]
                if w.instance is not None:
                    w.instance.setPixmapFromFile(path)
                w.show()
            except Exception as exc:
                optional_failure("ui.search_poster_apply", exc)

    def move_left(self):
        if not self.results:
            return
        self.index = (self.index - 1) % len(self.results)
        self._render()

    def move_right(self):
        if not self.results:
            return
        self.index = (self.index + 1) % len(self.results)
        self._render()

    def page_left(self):
        if not self.results:
            return
        self.index = max(0, self.index - self.PAGE_SIZE)
        self._render()

    def page_right(self):
        if not self.results:
            return
        self.index = min(len(self.results) - 1, self.index + self.PAGE_SIZE)
        self._render()

    def _result_context(self, item):
        profile = item.get("_search_profile") if isinstance(item, dict) else None
        if not isinstance(profile, dict):
            profile = self.profile
        owned = self._profile_key(profile) != self._profile_key(self.profile)
        client = self.client if not owned else _client_from_profile(
            profile, timeout=min(8, int(load_settings().get("timeout", 10) or 10))
        )
        return profile, client, owned

    def select(self):
        if not self.results or not (0 <= self.index < len(self.results)):
            return
        if self._busy:
            try:
                self._cancel_active_async()
            except Exception:
                pass
        item = self.results[self.index]
        typ = item.get("_search_media_type") or "vod"
        profile, client, owned = self._result_context(item)
        clean = dict(item)
        clean.pop("_search_profile", None)
        clean.pop("_search_portal_name", None)

        def returned(_result=None):
            if owned:
                try:
                    client.close()
                except Exception:
                    pass
            self._render()

        self.session.openWithCallback(returned, ContentDetailsScreen, profile, client, typ, clean)
