# -*- coding: utf-8 -*-
"""Clean poster-first global Movies/Series search."""
from __future__ import absolute_import
import hashlib
import os
import queue
import threading
import time
import urllib.parse
import urllib.request
from .core.shared_executors import VISIBLE_ARTWORK_EXECUTOR
from collections import OrderedDict
import weakref

from . import _
from Screens.Screen import Screen
try:
    from Screens.VirtualKeyBoard import VirtualKeyBoard
except Exception:
    VirtualKeyBoard = None
try:
    from Screens.InputBox import InputBox
except Exception:
    InputBox = None

from .ui_async import AsyncScreenMixin
from .ui_transition import TransitionMixin
from .persistent_cache import load_detail_snapshot, load_shared_detail_snapshot
from .ui_artwork_helpers import _image_url
from . import ui_image_loader as _uil

SEARCH_SKIN = ""
_SEARCH_ART_EXECUTOR = VISIBLE_ARTWORK_EXECUTOR


def configure_search_screen(**deps):
    globals().update(deps)
    if "SEARCH_SKIN" in deps:
        PortalGlobalSearchScreen.skin = deps["SEARCH_SKIN"]


def _norm_search(value):
    return " ".join(str(value or "").casefold().replace("_", " ").replace("-", " ").split())

def _fast_client_search_detached(client, term, limit, cancel_event, settings, time_budget=5.0, max_pages=16):
    if cancel_event is not None and cancel_event.is_set():return []
    settings=settings if isinstance(settings,dict) else {}
    fn=getattr(client,"search_content_fast",None) or getattr(client,"search_content",None)
    if callable(fn):
        try:
            return fn(term,media_types=("vod","series"),limit=limit,max_pages=min(int(max_pages or 16),int(settings.get("search_max_pages",40) or 40)),cancel_event=cancel_event,time_budget=min(float(time_budget or 5.0),float(settings.get("search_time_budget",8) or 8))) or []
        except TypeError:
            try:return fn(term,media_types=("vod","series"),limit=limit,cancel_event=cancel_event) or []
            except Exception:pass
        except Exception:pass
    out=[];needle=_norm_search(term);deadline=time.monotonic()+max(1.0,float(time_budget or 5.0));max_local_pages=max(1,min(12,int(max_pages or 12)))
    for typ in ("vod","series"):
        if len(out)>=limit:break
        for page in range(1,max_local_pages+1):
            if time.monotonic()>=deadline or (cancel_event is not None and cancel_event.is_set()):break
            try:payload=client.ordered_page(typ,"*",page,cancel_event=cancel_event) or {}
            except Exception:break
            rows=[x for x in payload.get("items",[]) if isinstance(x,dict)]
            if not rows:break
            for raw in rows:
                hay=_norm_search(str(raw.get("name") or raw.get("title") or "")+" "+str(raw.get("description") or raw.get("descr") or ""))
                if needle and needle in hay:
                    item=dict(raw);item["_search_media_type"]=typ;out.append(item)
                    if len(out)>=limit:break
            if len(out)>=limit:break
    return out

def _valid(path):
    try:
        return bool(path and os.path.isfile(str(path)) and os.path.getsize(str(path)) > 100)
    except Exception:
        return False


class PortalGlobalSearchScreen(Screen, AsyncScreenMixin, TransitionMixin):
    skin = SEARCH_SKIN
    PAGE_SIZE = 7
    POSTER_SIZE = (206, 310)

    def __init__(self, session, profile, client):
        Screen.__init__(self, session)
        self._async_init()
        self.onClose.append(self._stop_async)
        self.profile = profile
        self.client = client
        self.results = []
        self.query = ""
        self.index = 0
        self._search_partial_jobs = queue.Queue()
        self._poster_jobs = queue.Queue()
        self._poster_generation = 0
        self._poster_cancel_event = threading.Event()
        self._poster_futures = set()
        self._poster_ready_cache = OrderedDict()
        self._search_seen = set()
        self._search_errors = []
        self._search_portal_count = 0
        self._search_settings = {}
        self._render_signature = ()
        self._render_slot_signatures = [None] * self.PAGE_SIZE
        self._render_art_identities = [None] * self.PAGE_SIZE
        self._render_art_start = None
        self._render_selected_slot = None
        self["page_adaptive_bg"] = Pixmap()
        self["search_query"] = Label(_("Search"))
        self["search_status"] = Label("")
        self["page_label"] = Label("")
        for i in range(self.PAGE_SIZE):
            self["result_art%d" % i] = Pixmap()
            self["result_sel%d" % i] = Pixmap()
            self["result_title%d" % i] = Label("")
            self["result_meta%d" % i] = Label("")
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "cancel": self.close,
                "red": self.close,
                "green": self.prompt,
                "ok": self.select,
                "left": self.move_left,
                "right": self.move_right,
                "up": self.page_left,
                "down": self.page_right,
            },
            -1,
        )
        self._first_prompt_pending = True
        self._prompt_timer = eTimer()
        self._prompt_timer_conn = None
        try:
            self._prompt_timer_conn = self._prompt_timer.timeout.connect(self._open_first_prompt)
        except Exception:
            self._prompt_timer.callback.append(self._open_first_prompt)
        self.onClose.append(self._stop_prompt_timer)
        self.onClose.append(self._stop_search_hooks)
        self.onLayoutFinish.append(self._ready)
        self.onShown.append(self._shown)

    def _ready(self):
        try:
            hero = {}
            with open(HOME_HERO_FILE, "r", encoding="utf-8") as fh:
                state = json.load(fh)
                hero = state.get("hero") if isinstance(state, dict) else {}
            src = str(
                (hero or {}).get("display_backdrop_local")
                or (hero or {}).get("backdrop_local")
                or (hero or {}).get("prepared")
                or ""
            )
            backdrop = src
            if _valid(src):
                try:
                    stamp = str(int(os.path.getmtime(src)))
                except Exception:
                    stamp = "0"
                key = hashlib.sha1((src + "|" + stamp + "|search-hero-v1").encode("utf-8", "ignore")).hexdigest()[:16]
                built = _build_category_extended_backdrop(src, key)
                if _valid(built):
                    backdrop = built
            if _valid(backdrop) and self["page_adaptive_bg"].instance is not None:
                self["page_adaptive_bg"].instance.setPixmapFromFile(backdrop)
                self["page_adaptive_bg"].show()
        except Exception as exc:
            optional_failure("ui.search_clean_bg", exc)
        self._render()

    def _shown(self):
        if not self._first_prompt_pending:
            return
        self._first_prompt_pending = False
        try:
            self.onShown.remove(self._shown)
        except Exception:
            pass
        try:
            self._prompt_timer.start(120, True)
        except Exception:
            self._open_first_prompt()

    def _open_first_prompt(self):
        if not getattr(self, "_screen_closed", False):
            self.prompt()

    def _stop_prompt_timer(self):
        try:
            self._prompt_timer.stop()
        except Exception:
            pass
        try:
            if self._prompt_timer_conn is not None:
                self._prompt_timer_conn.disconnect()
        except Exception:
            pass
        try:
            if self._open_first_prompt in self._prompt_timer.callback:
                self._prompt_timer.callback.remove(self._open_first_prompt)
        except Exception:
            pass

    def _advance_poster_generation(self):
        old_event=getattr(self,"_poster_cancel_event",None)
        if old_event is not None:
            try:old_event.set()
            except Exception:pass
        futures=getattr(self,"_poster_futures",None)
        if not isinstance(futures,set):
            futures=set();self._poster_futures=futures
        for future in list(futures):
            if future is None or future.done():
                futures.discard(future);continue
            try:future.cancel()
            except Exception as exc:optional_failure("ui.search_poster_cancel",exc)
            if future.done():futures.discard(future)
        self._poster_generation += 1
        self._poster_cancel_event = threading.Event()
        try:
            while True:self._poster_jobs.get_nowait()
        except queue.Empty:
            pass
        except Exception as exc:optional_failure("ui.search_poster_queue_drain",exc)
        return self._poster_generation,self._poster_cancel_event

    def _poster_ready_get(self, ident):
        cache=getattr(self,"_poster_ready_cache",None)
        if not isinstance(cache,OrderedDict):return ""
        path=str(cache.get(str(ident)) or "")
        if path and _valid(path):
            try:cache.move_to_end(str(ident))
            except Exception:pass
            return path
        cache.pop(str(ident),None)
        return ""

    def _poster_ready_put(self, ident, path):
        path=str(path or "")
        if not path or not _valid(path):return
        cache=getattr(self,"_poster_ready_cache",None)
        if not isinstance(cache,OrderedDict):
            cache=OrderedDict();self._poster_ready_cache=cache
        key=str(ident);cache[key]=path
        try:cache.move_to_end(key)
        except Exception:pass
        while len(cache)>56:
            try:cache.popitem(last=False)
            except Exception:break

    def _stop_search_hooks(self):
        self._advance_poster_generation()
        for q in (self._search_partial_jobs, self._poster_jobs):
            try:
                while True:
                    q.get_nowait()
            except Exception:
                pass
        for i in range(self.PAGE_SIZE):
            try:
                art = self["result_art%d" % i]
                sel = self["result_sel%d" % i]
                if art.instance is not None:
                    art.instance.setPixmap(None)
                if sel.instance is not None:
                    sel.instance.setPixmap(None)
            except Exception:
                pass

    def _drain_jobs(self):
        AsyncScreenMixin._drain_jobs(self)
        if self._screen_closed:
            return
        self._drain_search_partials()
        self._drain_poster_jobs()

    @staticmethod
    def _profile_key(profile):
        return (
            str((profile or {}).get("portal") or "").rstrip("/").lower(),
            str((profile or {}).get("mac") or "").upper(),
        )

    @staticmethod
    def _norm(value):
        return " ".join(str(value or "").casefold().replace("_", " ").replace("-", " ").split())

    def _merge_search_rows(self, rows):
        added = 0
        for item in rows or []:
            if not isinstance(item, dict):
                continue
            p = item.get("_search_profile") or {}
            typ = item.get("_search_media_type") or "vod"
            identity = (
                item.get("id")
                or item.get("movie_id")
                or item.get("series_id")
                or item.get("cmd")
                or item.get("name")
                or item.get("title")
            )
            key = (self._profile_key(p), typ, str(identity))
            if key in self._search_seen:
                continue
            self._search_seen.add(key)
            self.results.append(item)
            added += 1
        return added

    def _fast_client_search(self, client, term, limit, cancel_event, time_budget=5.0, max_pages=16):
        return _fast_client_search_detached(client,term,limit,cancel_event,self._search_settings,time_budget,max_pages)

    def prompt(self):
        recent = _load_recent_searches()
        title = _("Search Movies & Series")
        if recent:
            title += "  •  " + _("Recent: %s") % ", ".join(recent[:3])
        if VirtualKeyBoard is not None:
            self.session.openWithCallback(self._search, VirtualKeyBoard, title=title, text=self.query)
        elif InputBox is not None:
            self.session.openWithCallback(self._search, InputBox, title=title, text=self.query, maxSize=60)
        else:
            self.session.open(MessageBox, _("Search keyboard is unavailable on this image."), MessageBox.TYPE_ERROR, timeout=5)

    def _search(self, term=None):
        term = one_line(term or "", 60)
        if not term:
            return
        self.query = term
        _save_recent_search(term)
        cfg = load_settings()
        self._search_settings = dict(cfg)
        self.results = []
        self.index = 0
        # Cancel poster work from the previous query immediately. Per-slot
        # identities below then keep partial results on the same page incremental.
        self._advance_poster_generation()
        # Keep the current slot snapshots until the empty render below has
        # actively cleared the previous query from screen. Resetting them here
        # would make the renderer believe old posters/labels were already empty.
        self._render_art_start = None
        self._render_signature = ()
        self._search_seen = set()
        self._search_errors = []
        self._search_portal_count = 0
        try:
            while True:
                self._search_partial_jobs.get_nowait()
        except Exception:
            pass
        self["search_query"].setText(_("Search: %s") % term)
        self["search_status"].setText(_("Searching..."))
        self._render()
        multi = bool(cfg.get("multi_portal_search", True))
        limit = max(20, min(100, int(cfg.get("content_page_size", 50) or 50)))

        search_profile_base=dict(self.profile or {})
        search_settings=dict(self._search_settings or {})
        partial_queue=self._search_partial_jobs
        def profile_key(profile):
            return (str((profile or {}).get("portal") or "").rstrip("/").lower(),str((profile or {}).get("mac") or "").upper())
        def work(handle):
            profiles = load_profiles() if multi else [search_profile_base]
            current_key = profile_key(search_profile_base)
            profiles = sorted(
                [p for p in profiles if isinstance(p, dict)],
                key=lambda p: 0 if profile_key(p) == current_key else 1,
            )
            if not profiles:
                profiles = [search_profile_base]

            all_rows = []
            errors = []
            portal_count = len(profiles)

            def search_profile(p, pos, budget=5.0, pages=16):
                if handle.cancelled():
                    return [], None
                cl = None
                try:
                    cl = _client_from_profile(p, timeout=min(4, int(cfg.get("timeout", 10) or 10)))
                    rows = _fast_client_search_detached(cl, term, limit, handle.cancel_event, search_settings, time_budget=budget, max_pages=pages)
                    tagged = []
                    for row in rows:
                        if not isinstance(row, dict):
                            continue
                        item = dict(row)
                        item["_search_profile"] = dict(p)
                        item["_search_portal_name"] = str(p.get("name") or ("Server %d" % (pos + 1)))
                        tagged.append(item)
                    return tagged, None
                except Exception as exc:
                    return [], "%s: %s" % (p.get("name") or p.get("portal") or "Portal", exc)
                finally:
                    if cl is not None:
                        try: cl.close()
                        except Exception: pass

            # Search the active source first so its matches appear immediately,
            # then continue across every other enabled source. A match on the
            # current portal must never terminate Global Search.
            tagged, err = search_profile(profiles[0], 0, budget=5.0, pages=18)
            if err:
                errors.append(err)
            if tagged:
                all_rows.extend(tagged)
                if not handle.cancelled():
                    partial_queue.put((tagged, None, portal_count))

            if not multi or len(profiles) <= 1 or handle.cancelled():
                return all_rows, errors, portal_count

            # Global continuation: search every other enabled source in a small
            # bounded worker pool. Keep the hard wall-clock budget, but do not
            # stop when one source matches: other portals may carry a better copy.
            jobs = queue.Queue()
            for pos, p in enumerate(profiles[1:], 1):
                jobs.put((pos, p))
            result_lock = threading.RLock()
            stop = threading.Event()
            deadline = time.monotonic() + 16.0

            def worker():
                while not stop.is_set() and not handle.cancelled() and time.monotonic() < deadline:
                    try:
                        pos, p = jobs.get_nowait()
                    except queue.Empty:
                        return
                    tagged, err = search_profile(p, pos, budget=3.5, pages=12)
                    if stop.is_set() or handle.cancelled():
                        return
                    with result_lock:
                        if err:
                            errors.append(err)
                        if tagged:
                            all_rows.extend(tagged)
                            if not handle.cancelled():
                                partial_queue.put((tagged, None, portal_count))

            threads = []
            for idx in range(min(4, jobs.qsize())):
                thread = threading.Thread(target=worker, name="ultrastalker-search-source-%d" % idx, daemon=True)
                thread.start()
                threads.append(thread)

            while time.monotonic() < deadline and not handle.cancelled():
                if not any(t.is_alive() for t in threads):
                    break
                time.sleep(0.05)
            stop.set()
            # Bounded cleanup only. Network clients already have short timeouts,
            # and daemon workers must never hold the UI search completion hostage.
            grace = time.monotonic() + 0.8
            for thread in threads:
                remain = grace - time.monotonic()
                if remain <= 0:
                    break
                thread.join(remain)
            return list(all_rows), list(errors), portal_count

        def ok(result):
            rows, errors, count = result
            self._search_portal_count = count
            self._merge_search_rows(rows)
            self._search_errors = list(dict.fromkeys(self._search_errors + errors))
            self._render()
            self["search_status"].setText(
                (_("%d result(s)") % len(self.results)) if self.results else _("No matching content")
            )

        self._run_async(work, ok, lambda e: self["search_status"].setText(_friendly_error(e)))

    def _drain_search_partials(self):
        changed = False
        while True:
            try:
                rows, error, count = self._search_partial_jobs.get_nowait()
            except queue.Empty:
                break
            except Exception:
                break
            self._search_portal_count = max(self._search_portal_count, int(count or 0))
            if error:
                self._search_errors.append(error)
            if self._merge_search_rows(rows):
                changed = True
        if changed:
            self._render()
            self["search_status"].setText(_("Searching... %d result(s)") % len(self.results))

    def _visible_range(self):
        page = self.index // self.PAGE_SIZE if self.results else 0
        start = page * self.PAGE_SIZE
        return page, start, self.results[start : start + self.PAGE_SIZE]

    @staticmethod
    def _set_label_if_changed(widget, value):
        text = str(value or "")
        try:
            if widget.getText() == text:
                return False
        except Exception:
            pass
        widget.setText(text)
        return True

    def _render(self):
        query_text = (_("Search: %s") % self.query) if self.query else _("Search")
        self._set_label_if_changed(self["search_query"], query_text)
        page, start, rows = self._visible_range()
        pages = max(1, (len(self.results) + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
        page_text = ((_('Page %d / %d  •  %d result(s)') % (page + 1, pages, len(self.results))) if self.results else "")
        self._set_label_if_changed(self["page_label"], page_text)

        # A page change invalidates queued poster downloads; partial results that
        # merely append to the current page do not. The old renderer bumped one
        # global generation whenever the page signature changed, repeatedly
        # cancelling and rescheduling posters already in flight.
        if getattr(self, "_render_art_start", None) != start:
            self._advance_poster_generation()
            self._render_art_start = start
        generation = self._poster_generation

        slot_signatures = list(getattr(self, "_render_slot_signatures", [None] * self.PAGE_SIZE))
        art_identities = list(getattr(self, "_render_art_identities", [None] * self.PAGE_SIZE))
        if len(slot_signatures) != self.PAGE_SIZE:slot_signatures = [None] * self.PAGE_SIZE
        if len(art_identities) != self.PAGE_SIZE:art_identities = [None] * self.PAGE_SIZE

        current_signature=[]
        for slot in range(self.PAGE_SIZE):
            art = self["result_art%d" % slot]
            sel = self["result_sel%d" % slot]
            title = self["result_title%d" % slot]
            meta = self["result_meta%d" % slot]
            if slot >= len(rows):
                current_signature.append("")
                if slot_signatures[slot] is not None or art_identities[slot] is not None:
                    try:
                        if art.instance is not None: art.instance.setPixmap(None)
                    except Exception: pass
                    art.hide(); sel.hide()
                    self._set_label_if_changed(title, "")
                    self._set_label_if_changed(meta, "")
                    slot_signatures[slot] = None
                    art_identities[slot] = None
                continue

            item = rows[slot]
            ident = self._poster_identity(item)
            current_signature.append(ident)
            typ = item.get("_search_media_type") or "vod"
            raw = item.get("name") or item.get("title") or _("Result")
            title_text = premium_title(raw, True)[:34]
            source = str(item.get("_search_portal_name") or "")[:18]
            meta_text = (_("MOVIE") if typ == "vod" else _("SERIES")) + (("  •  " + source) if source else "")
            slot_signature = (ident, title_text, meta_text)
            if slot_signatures[slot] != slot_signature:
                self._set_label_if_changed(title, title_text)
                self._set_label_if_changed(meta, meta_text)
                slot_signatures[slot] = slot_signature

            if art_identities[slot] != ident:
                try:
                    if art.instance is not None:
                        art.instance.setPixmap(None)
                        art.instance.setPixmapFromFile(asset("grid_placeholder_series_921.png" if typ == "series" else "grid_placeholder_movie_921.png"))
                    art.show()
                except Exception: pass
                art_identities[slot] = ident
                self._schedule_poster(generation, slot, item)

        self._render_signature = tuple(current_signature)

        # Selection movement within one search page should touch only the old and
        # new selector widgets. Previously every arrow press called show()/hide()
        # on all seven slots and rewrote every title/meta label.
        selected_slot = self.index - start if start <= self.index < start + len(rows) else None
        old_slot = getattr(self, "_render_selected_slot", None)
        if old_slot != selected_slot:
            if old_slot is not None and 0 <= old_slot < self.PAGE_SIZE:
                try:self["result_sel%d" % old_slot].hide()
                except Exception:pass
            if selected_slot is not None and 0 <= selected_slot < self.PAGE_SIZE:
                try:self["result_sel%d" % selected_slot].show()
                except Exception:pass
            self._render_selected_slot = selected_slot
        elif selected_slot is not None:
            try:self["result_sel%d" % selected_slot].show()
            except Exception:pass
        self._render_slot_signatures = slot_signatures
        self._render_art_identities = art_identities

    def _poster_identity(self, item):
        return "%s:%s:%s" % (
            self._profile_key(item.get("_search_profile") or self.profile),
            item.get("_search_media_type") or "vod",
            item.get("id")
            or item.get("movie_id")
            or item.get("series_id")
            or item.get("name")
            or item.get("title")
            or "",
        )

    def _absolute_art_url(self, value, profile):
        text = str(value or "").strip()
        if not text:
            return ""
        if text.startswith("//"):
            scheme = urllib.parse.urlsplit(str((profile or {}).get("portal") or "http://")).scheme or "http"
            return scheme + ":" + text
        if text.startswith(("http://", "https://")):
            return text
        return urllib.parse.urljoin(
            str((profile or {}).get("portal") or "").rstrip("/") + "/", text.lstrip("/")
        )

    def _local_search_poster(self, item):
        profile = item.get("_search_profile") if isinstance(item.get("_search_profile"), dict) else self.profile
        typ = item.get("_search_media_type") or "vod"
        clean = dict(item)
        clean.pop("_search_profile", None)
        clean.pop("_search_portal_name", None)
        try:
            snap = load_shared_detail_snapshot(profile, typ, clean) if clean.get("_xtream") else load_detail_snapshot(profile, typ, clean)
            p = str((snap or {}).get("poster_local") or "")
            if _valid(p):
                digest = hashlib.sha1((p + "|search206x310").encode("utf-8", "ignore")).hexdigest()
                thumb = os.path.join(_uil.IMAGE_CACHE_DIR, "search_%s_206x310.png" % digest)
                if _valid(thumb):
                    return thumb
                try:
                    return _uil._build_thumbnail(p, thumb, self.POSTER_SIZE) or p
                except Exception:
                    return p
        except Exception:
            pass
        return ""

    def _schedule_poster(self, generation, slot, item):
        ident = self._poster_identity(item)
        ready=self._poster_ready_get(ident)
        if ready:
            try:self._poster_jobs.put((generation,slot,ident,ready))
            except Exception:pass
            return
        local = self._local_search_poster(item)
        if local:
            self._poster_ready_put(ident,local)
            try:
                self._poster_jobs.put((generation, slot, ident, local))
            except Exception:
                pass
            return
        profile = item.get("_search_profile") if isinstance(item.get("_search_profile"), dict) else self.profile
        url = self._absolute_art_url(_image_url(item), profile)
        try:
            url = _uil._optimized_artwork_url(url, False) if url else ""
        except Exception:
            pass
        if not url:
            return

        cancel_event=getattr(self,"_poster_cancel_event",None)
        poster_jobs=self._poster_jobs
        client=self.client
        poster_size=tuple(self.POSTER_SIZE)
        futures=self._poster_futures
        screen_ref=weakref.ref(self)

        def worker():
            temp = None
            try:
                if cancel_event is None or cancel_event.is_set():
                    return
                digest = hashlib.sha1(url.encode("utf-8", "ignore")).hexdigest()
                thumb = _uil._thumb_path(digest, poster_size)
                if _uil._valid_cache_file(thumb):
                    path = thumb
                else:
                    original = _uil._find_original_artwork(digest)
                    if original:
                        path = _uil._build_thumbnail(original, thumb, poster_size) or original
                    else:
                        headers = _uil._safe_image_headers(url, profile, client)
                        req = urllib.request.Request(url, headers=headers)
                        opener = _uil._safe_image_opener(url, profile)
                        temp = os.path.join(
                            _uil.IMAGE_CACHE_DIR,
                            "search_%s.download.%d.%d" % (digest, os.getpid(), threading.get_ident()),
                        )
                        total = 0
                        head = b""
                        _uil._persistent_write_require(temp)
                        with opener.open(req, timeout=3.5) as response, open(temp, "wb") as h:
                            ctype = (response.headers.get("Content-Type") or "").lower()
                            while True:
                                if cancel_event.is_set():
                                    return
                                chunk = response.read(64 * 1024)
                                if not chunk:
                                    break
                                if not head:
                                    head = chunk[:16]
                                total += len(chunk)
                                if total > 3 * 1024 * 1024:
                                    raise ValueError("poster too large")
                                h.write(chunk)
                        if total <= 100 or cancel_event.is_set():
                            return
                        if head.startswith(b"\x89PNG") or "png" in ctype:
                            ext = ".png"
                        elif head[:4] == b"RIFF" or "webp" in ctype:
                            ext = ".webp"
                        else:
                            ext = ".jpg"
                        original = os.path.join(_uil.IMAGE_CACHE_DIR, digest + ext)
                        if not _uil._persistent_write_ok(original):
                            return
                        os.replace(temp, original)
                        temp = None
                        _uil._cache_artwork_path(digest, original)
                        path = _uil._build_thumbnail(original, thumb, poster_size) or original
                if not cancel_event.is_set():
                    poster_jobs.put((generation, slot, ident, path))
            except Exception as exc:
                if cancel_event is None or not cancel_event.is_set():
                    optional_failure("ui.search_poster", exc)
            finally:
                if temp:
                    try:
                        if os.path.exists(temp):
                            os.unlink(temp)
                    except Exception:
                        pass

        try:
            future=_SEARCH_ART_EXECUTOR.submit(worker,_task_key="search-poster:%x:%s:%s:%s"%(id(self),generation,slot,ident))
            futures.add(future)
            def forget(done,owned=futures,ref=screen_ref):
                owned.discard(done)
                screen=ref()
                if screen is not None and getattr(screen,"_screen_closed",False):
                    return
            future.add_done_callback(forget)
        except Exception as exc:
            optional_failure("ui.search_poster_submit", exc)

    def _drain_poster_jobs(self):
        _page, _start, rows = self._visible_range()
        while True:
            try:
                generation, slot, ident, path = self._poster_jobs.get_nowait()
            except queue.Empty:
                break
            except Exception:
                break
            if generation != self._poster_generation or slot >= len(rows) or not _valid(path):
                continue
            if ident != self._poster_identity(rows[slot]):
                continue
            try:
                self._poster_ready_put(ident,path)
                w = self["result_art%d" % slot]
                if w.instance is not None:
                    w.instance.setPixmapFromFile(path)
                w.show()
            except Exception as exc:
                optional_failure("ui.search_poster_apply", exc)

    def move_left(self):
        if not self.results:
            return
        self.index = (self.index - 1) % len(self.results)
        self._render()

    def move_right(self):
        if not self.results:
            return
        self.index = (self.index + 1) % len(self.results)
        self._render()

    def page_left(self):
        if not self.results:
            return
        self.index = max(0, self.index - self.PAGE_SIZE)
        self._render()

    def page_right(self):
        if not self.results:
            return
        self.index = min(len(self.results) - 1, self.index + self.PAGE_SIZE)
        self._render()

    def _result_context(self, item):
        profile = item.get("_search_profile") if isinstance(item, dict) else None
        if not isinstance(profile, dict):
            profile = self.profile
        owned = self._profile_key(profile) != self._profile_key(self.profile)
        client = self.client if not owned else _client_from_profile(
            profile, timeout=min(8, int(load_settings().get("timeout", 10) or 10))
        )
        return profile, client, owned

    def select(self):
        if not self.results or not (0 <= self.index < len(self.results)):
            return
        if self._busy:
            try:
                self._cancel_active_async()
            except Exception:
                pass
        item = self.results[self.index]
        typ = item.get("_search_media_type") or "vod"
        profile, client, owned = self._result_context(item)
        clean = dict(item)
        clean.pop("_search_profile", None)
        clean.pop("_search_portal_name", None)

        def returned(_result=None):
            if owned:
                try:
                    client.close()
                except Exception:
                    pass
            self._render()

        self.session.openWithCallback(returned, ContentDetailsScreen, profile, client, typ, clean)
