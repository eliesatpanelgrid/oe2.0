"""One canonical metadata authority shared by Details, Cinematic and Backdrop Grid."""
import os
from .artwork_v2 import ArtworkV2, save_manifest
from .persistent_cache import load_detail_snapshot, load_detail_snapshot_by_tmdb, save_detail_snapshot
from .storage import load_settings
from .log import optional_failure

def _cancelled(ev):
    try:return bool(ev is not None and ev.is_set())
    except Exception:return False

def _backdrop_ok(path):
    try:
        from .artwork_v2 import _valid_backdrop
        return bool(_valid_backdrop(str(path or "")))
    except Exception:
        try:return bool(path and os.path.isfile(str(path)) and os.path.getsize(str(path))>100)
        except Exception:return False

def _merge(a,b):
    out=dict(a or {})
    if isinstance(b,dict):
        for k,v in b.items():
            if v not in (None,"",[],{}):out[k]=v
    return out

def load_canonical(profile,media_type,item):
    try:
        row=load_detail_snapshot(profile,media_type,item) or {}
        if row.get("tmdb_id"):
            direct=load_detail_snapshot_by_tmdb(row.get("media_type") or media_type,row.get("tmdb_id")) or {}
            row=_merge(row,direct)
        return row
    except Exception as exc:
        optional_failure("details_authority.load",exc);return {}

def resolve_canonical(profile,media_type,item,cancel_event=None,settings=None):
    """Resolve one stable-focus item and persist the single Details record."""
    if _cancelled(cancel_event):return {}
    current=load_canonical(profile,media_type,item)
    if current.get("_details_authority_ready") and current.get("tmdb_id"):return current
    cfg=dict(settings or load_settings() or {})
    credential=str(cfg.get("tmdb_credential") or "").strip()
    if not cfg.get("tmdb_enabled",True) or not credential:return current
    try:
        resolver=ArtworkV2(credential,cfg.get("tmdb_language","ar-EG"),min(7,max(3,int(cfg.get("timeout",10) or 10))))
        src=dict(item or {}) if isinstance(item,dict) else {}
        fast=resolver.resolve(profile,media_type,src,full=False,cancel_event=cancel_event) or {}
        if _cancelled(cancel_event):return current
        row=_merge(current,fast)
        full=resolver.resolve(profile,media_type,src,full=True,cancel_event=cancel_event) or {}
        if _cancelled(cancel_event):return current
        if isinstance(full,dict) and full.get("matched"):row=_merge(row,full)
        if row.get("tmdb_id") and not _backdrop_ok(row.get("backdrop_local")):
            locked=dict(src);locked["_locked_tmdb_id"]=row.get("tmdb_id");locked["_locked_tmdb_type"]=row.get("media_type") or ("tv" if str(media_type)=="series" else "movie")
            row=_merge(row,resolver.resolve_backdrop_only(profile,media_type,locked,cancel_event=cancel_event) or {})
        if _cancelled(cancel_event) or not row.get("tmdb_id"):return row or current
        row["matched"]=bool(row.get("matched",True));row["identity_verified"]=bool(row.get("identity_verified") or row.get("identity_pointer_verified") or row.get("tmdb_id"))
        row["_details_authority_ready"]=True;row["_details_authority_version"]=1
        if _cancelled(cancel_event):return current
        save_detail_snapshot(profile,media_type,src,row)
        try:save_manifest(profile,media_type,src,row)
        except Exception as exc:optional_failure("details_authority.manifest",exc)
        return row
    except Exception as exc:
        optional_failure("details_authority.resolve",exc);return current
