# -*- coding: utf-8 -*-
"""Shared HDD title-logo cache bridge.

The plugin historically has two persistent title-logo canvases:
* ``pgv2_title_logos``: 900x125, used by Poster Grid V2 / Player fallback.
* ``title_logos``: 432x210, used by Details / Cinematic / Backdrop / Home.

A bounded-cache repair can legitimately leave only one representation behind.
This module reuses the surviving HDD master and recreates the other presentation
without network I/O.  It intentionally has no Enigma2 imports and is safe to call
only from existing background workers when a resize is required.
"""
from __future__ import absolute_import

import os
import re
import threading

try:
    from PIL import Image as _PILImage
except Exception:
    _PILImage = None

from .persistent_cache import GENERATED


def _media_tag(media_type):
    return "tv" if str(media_type or "").lower() in ("series", "tv", "episode") else "movie"


def title_logo_language(title):
    return "ar" if re.search(r"[\u0600-\u06ff]", str(title or "")) else "en"


def valid_title_logo(path, min_bytes=256):
    try:
        return bool(path and os.path.isfile(str(path)) and os.path.getsize(str(path)) > int(min_bytes))
    except Exception:
        return False


def pgv2_title_logo_path(media_type, tmdb_id, lang="en"):
    try:
        return os.path.join(
            GENERATED, "pgv2_title_logos",
            "%s_%s_%s_900x125_v1.png" % (_media_tag(media_type), int(tmdb_id), str(lang or "en")),
        )
    except Exception:
        return ""


def legacy_title_logo_path(media_type, tmdb_id, lang="en"):
    try:
        return os.path.join(
            GENERATED, "title_logos",
            "%s_%s_%s_432x210_v2.png" % (_media_tag(media_type), int(tmdb_id), str(lang or "en")),
        )
    except Exception:
        return ""


def existing_title_logo_source(media_type, tmdb_id, lang="en", prefer_legacy=True):
    legacy = legacy_title_logo_path(media_type, tmdb_id, lang)
    pgv2 = pgv2_title_logo_path(media_type, tmdb_id, lang)
    ordered = (legacy, pgv2) if prefer_legacy else (pgv2, legacy)
    for path in ordered:
        if valid_title_logo(path):
            return path
    return ""


def ensure_legacy_from_pgv2(media_type, tmdb_id, lang="en"):
    """Recreate the 432x210 persistent presentation from the 900x125 HDD master.

    No network access occurs here.  The conversion is atomic and idempotent, so
    concurrent screen workers may safely race without producing duplicate names.
    Callers must keep this off navigation/key-repeat hot paths.
    """
    target = legacy_title_logo_path(media_type, tmdb_id, lang)
    if valid_title_logo(target):
        return target
    source = pgv2_title_logo_path(media_type, tmdb_id, lang)
    if _PILImage is None or not valid_title_logo(source, 512):
        return ""
    tmp = ""
    try:
        parent = os.path.dirname(target)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent, mode=0o700, exist_ok=True)
        with _PILImage.open(source) as src:
            im = src.convert("RGBA")
            try:
                bbox = im.getchannel("A").getbbox()
                if bbox:
                    im = im.crop(bbox)
            except Exception:
                pass
            if im.width < 2 or im.height < 2:
                return ""
            max_w, max_h = 404, 186
            scale = min(float(max_w) / float(im.width), float(max_h) / float(im.height))
            nw = max(1, int(round(im.width * scale)))
            nh = max(1, int(round(im.height * scale)))
            if (nw, nh) != im.size:
                res = getattr(getattr(_PILImage, "Resampling", _PILImage), "LANCZOS", 1)
                im = im.resize((nw, nh), res)
            canvas = _PILImage.new("RGBA", (432, 210), (0, 0, 0, 0))
            canvas.alpha_composite(im, ((432 - nw) // 2, max(0, (210 - nh) // 2)))
            tmp = target + ".tmp.%s.%s" % (os.getpid(), threading.get_ident())
            canvas.save(tmp, "PNG", compress_level=1)
            try:
                os.chmod(tmp, 0o600)
            except OSError:
                pass
            os.replace(tmp, target)
        return target if valid_title_logo(target) else ""
    except Exception:
        try:
            if tmp and os.path.exists(tmp):
                os.unlink(tmp)
        except OSError:
            pass
        return ""
