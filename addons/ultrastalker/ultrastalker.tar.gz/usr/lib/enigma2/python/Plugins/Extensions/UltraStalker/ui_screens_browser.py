"""Portal browser screen extracted from ui.py without changing class behavior."""

from . import _
from Screens.Screen import Screen
from .ui_async import AsyncScreenMixin
from .ui_image_loader import ImageLoaderMixin
from .ui_transition import TransitionMixin
import time
import weakref
from .core.runtime_log import diagnostic_breadcrumb as _ui_diag
from .log import diagnostic_failure
from .core.call_compat import call_compatible

BROWSER_SKIN = ""

def configure_browser_screen(**deps):
    globals().update(deps)
    if "BROWSER_SKIN" in deps:
        PortalBrowserScreen.skin = deps["BROWSER_SKIN"]

class PortalBrowserScreen(Screen, AsyncScreenMixin, ImageLoaderMixin, TransitionMixin):
    skin = BROWSER_SKIN
    ALL_MODES = (
        ("Live TV", "itv", "ico_live_x.png"),
        ("Movies", "vod", "ico_movies_x.png"),
        ("Series", "series", "ico_series_x.png"),
        ("Catch-up TV", "catchup", "ico_live_x.png"),
        ("Favorites", "favorites", "ico_check_x.png"),
        ("Continue Watching", "recent", "ico_channel_x.png"),
        ("Account Information", "account", "ico_server_x.png"),
        ("Global Search", "search", "ico_global_search_x.png"),
        ("Settings", "settings", "ico_settings_x.png"),
    )
    MODES = ALL_MODES

    def __init__(self, session, profile, initial_action=None, shared_client=None, adaptive_source=None):
        Screen.__init__(self, session)
        self._async_init(); self.onClose.append(self._stop_async); self.onClose.append(self._image_stop)
        self._ui_diag_open_mono=time.monotonic();_ui_diag("ui_open",screen="browser")
        self.profile = profile
        self.initial_action = initial_action
        self._home_adaptive_source = str(adaptive_source or "")
        self._initial_action_done = False
        self._initial_action_scheduled = False
        self._initial_action_timer=eTimer();self._initial_action_timer_conn=None
        try:self._initial_action_timer_conn=self._initial_action_timer.timeout.connect(self._activate_initial_action)
        except Exception:self._initial_action_timer.callback.append(self._activate_initial_action)
        self.onClose.append(self._stop_initial_action_timer)
        self._home_entry = bool(initial_action)
        initial_cfg=load_settings();self._selection_cfg=self._selection_snapshot(initial_cfg);self._selection_cfg_mono=time.monotonic()
        self.portal_session = None if shared_client is not None else PortalSession(profile, timeout=initial_cfg.get("timeout", 10))
        self.client = shared_client if shared_client is not None else self.portal_session.client
        self._epg_jobs = queue.Queue(); self._epg_token = 0; self._epg_cache = {}; self._epg_future = None
        self._live_picon_cache_progress=queue.Queue();self._live_picon_cache_running=False;self._live_picon_cache_future=None
        self._epg_timer = eTimer(); self._epg_timer_conn = None
        try: self._epg_timer_conn = self._epg_timer.timeout.connect(self._fetch_selected_epg)
        except Exception: self._epg_timer.callback.append(self._fetch_selected_epg)
        self.onClose.append(self._stop_epg_preview)
        self.onClose.append(self._release_browser_pixmaps)
        self.onClose.append(self._stop_browser_ui_hooks)
        self.onClose.append(self._ui_diag_browser_close)
        try:self.onShown.append(self._browser_shown_reset)
        except Exception as exc:optional_failure("ui",exc)
        try:self.onHide.append(self._browser_hidden_release)
        except Exception as exc:optional_failure("ui.browser_hide_hook",exc)
        self.level = "root"; self.media_type = None; self.genre = None; self.content_items = []; self.page = 1; self.catchup_channel = None; self.active_modes = []
        self["brand_header"] = Pixmap()
        self["title"] = Label("")
        self["counter"] = Label(_("Portal sections"))
        self["section"] = Label(profile.get("portal", ""))
        self["top_divider"] = Label("")
        self["list"] = IconMenuList([], width=720, item_height=74, icon_size=58, primary_font=29, secondary_font=19)
        self["category_clean_bg"] = Label(" ")
        self["page_adaptive_bg"] = Pixmap(); self["preview"] = Pixmap(); self["accent_frame"] = Pixmap(); self["info_title"] = Label(_("Choose a section"))
        self["info_card1"] = Pixmap(); self["info_card2"] = Pixmap(); self["info_card3"] = Pixmap()
        self["info_icon1"] = Pixmap(); self["info_icon2"] = Pixmap(); self["info_icon3"] = Pixmap()
        self._category_chrome = {}
        self["info"] = Label(_("Live, Movies, Series, Favorites and Continue Watching"))
        self["status"] = Label(_("Ready"))
        self._favorite_card_index=0;self._favorite_card_entries=[];self._favorite_card_page=0
        for _fi in range(7):
            self["fav_card%d"%_fi]=Pixmap();self["fav_sel%d"%_fi]=Pixmap();self["fav_art%d"%_fi]=Pixmap();self["fav_title%d"%_fi]=Label("");self["fav_meta%d"%_fi]=Label("")
        self["red_bg"] = Pixmap(); self["green_bg"] = Pixmap(); self["yellow_bg"] = Pixmap(); self["blue_bg"] = Pixmap()
        self["red"] = Label(_("Back")); self["green"] = Label(_("Authorize"))
        self["yellow"] = Label(_("Refresh")); self["blue"] = Label(_("Open / Play"))
        self._category_row_card_w = 426
        self._category_title_font = 0
        self._image_init("preview", (530,382), profile, self.client)
        self.onLayoutFinish.append(self._layout_ready)
        self["list"].onSelectionChanged.append(self._selection_changed)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "MenuActions", "DirectionActions", "InfobarAudioSelectionActions", "InfobarSubtitleSelectionActions", "InfobarEPGActions"], {
            "cancel": self.back, "red": self.back, "green": self.reauthorize,
            "yellow": self.refresh_current, "blue": self.blue_action, "ok": self.select,
            "up": lambda: self["list"].wrap_up() if self.level!="favorites_cards" else None, "down": lambda: self["list"].wrap_down() if self.level!="favorites_cards" else None,
            "left": lambda: self._favorite_move(-1) if self.level=="favorites_cards" else self["list"].page_left(), "right": lambda: self._favorite_move(1) if self.level=="favorites_cards" else self["list"].page_right(),
            "menu": self.open_tools, "audioSelection": self.open_audio, "subtitleSelection": self.open_subtitles, "showEventInfo": self.show_selected_epg,
        }, -1)
        if self.initial_action in ("itv", "vod", "series"):
            # Cold-start direct entry from Home.  Never seed the legacy Browser
            # root list, otherwise an uncached category request can expose it for
            # 2-3 seconds after an Enigma2 restart.
            self.media_type = self.initial_action
            self.level = "genres_loading"
            try:self["list"].set_icon_rows([]);self["list"].hide()
            except Exception as exc:optional_failure("ui.category_cold_empty", exc)
            self._set_category_clean_visibility(True)
        elif self.initial_action in ("catchup","favorites"):
            # Beta135: utility pages entered from Home start blank/hero-first.
            # Do not seed the generic Browser root labels/list because OpenBH can
            # paint one frame of Ready/Back/Authorize/Refresh before the utility
            # layout takes over.  Actions stay bound; only transient chrome is
            # suppressed.
            self.level = "utility_loading"
            try:self["list"].set_icon_rows([]);self["list"].hide()
            except Exception as exc:optional_failure("ui.utility_cold_empty",exc)
            for _n in ("title","counter","section","top_divider","info_title","info","status","red","green","yellow","blue"):
                try:self[_n].setText("")
                except Exception:pass
        else:
            self._set_root_rows()

    def _category_surface_active(self):
        return getattr(self, "level", None) in ("genres", "genres_loading")

    def _decode_pending_picture(self):
        """Never let a stale Browser preview decode paint over Categories.

        The Browser root queues its right-side section artwork through ePicLoad.
        On fast cached category opens that decode can fire *after* the screen has
        already switched to ``genres``.  Hiding the preview widget is therefore
        not enough: the delayed decoder callback simply shows it again.

        Categories intentionally have no preview artwork, so drop queued preview
        work while the category rail is active.  Leaving Categories restores the
        normal ImageLoaderMixin path automatically.
        """
        if self._category_surface_active():
            self._image_pending_path = None
            self._image_active_path = None
            self._image_displayed_path = None
            self._image_decode_busy = False
            try:self._image_decode_timer.stop()
            except Exception as exc:optional_failure("ui.category_preview_timer_stop", exc)
            try:
                if self["preview"].instance is not None:
                    self["preview"].instance.setPixmap(None)
                self["preview"].hide()
            except Exception as exc:optional_failure("ui.category_preview_drop", exc)
            return
        return ImageLoaderMixin._decode_pending_picture(self)

    def _picture_ready(self, *args):
        """Drain late ePicLoad completions without revealing them in Categories."""
        if self._category_surface_active():
            try:
                # Consume the completed native pixmap so ePicLoad is left in a
                # clean reusable state, but deliberately never assign/show it.
                self._picload.getData()
            except Exception as exc:optional_failure("ui.category_preview_drain", exc)
            self._image_pending_path = None
            self._image_active_path = None
            self._image_displayed_path = None
            self._image_decode_busy = False
            try:
                if self["preview"].instance is not None:
                    self["preview"].instance.setPixmap(None)
                self["preview"].hide()
            except Exception as exc:optional_failure("ui.category_preview_late_hide", exc)
            return
        return ImageLoaderMixin._picture_ready(self, *args)

    def _release_browser_pixmaps(self):
        # Keep the three tiny right-column identity icons alive across child
        # screens. Enigma2 does not automatically restore a widget's skin pixmap
        # after setPixmap(None), which is why All / Category / Ready vanished.
        for _name in ("page_adaptive_bg","preview","accent_frame","info_card1","info_card2","info_card3"):
            _release_pixmap_widget(self,_name)
        try:self._category_chrome={}
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        _native_image_pressure_relief(force=True)

    def _restore_category_side_identity(self):
        """Keep the clean category page clean after returning from child screens."""
        if not self._category_surface_active() or self.media_type not in ("itv","vod","series"):
            return
        self._set_category_clean_visibility(True)
        try:self["page_adaptive_bg"].show()
        except Exception as exc:optional_failure("ui.category_backdrop_restore",exc)

    def _apply_browser_status_color(self):
        try:
            text=str(self["status"].getText() or "").strip().casefold()
            color="#69e79a" if text=="ready" else "#7fd7ff"
            if self["status"].instance is not None:self["status"].instance.setForegroundColor(parseColor(color))
        except Exception as exc:optional_failure("ui.browser_status_color",exc)

    def _ui_diag_browser_close(self):
        try:_ui_diag("ui_close",screen="browser",level=getattr(self,"level",""),
                     lifetime_ms=int(max(0.0,(time.monotonic()-self._ui_diag_open_mono)*1000.0)))
        except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)

    def _stop_browser_ui_hooks(self):
        for result_queue_name in ("_epg_jobs","_live_picon_cache_progress"):
            result_queue=getattr(self,result_queue_name,None)
            if result_queue is None:continue
            try:
                while True:result_queue.get_nowait()
            except queue.Empty:
                pass
            except Exception as exc:
                optional_failure("ui.browser_queue_cleanup",exc)
        self._epg_pending=None
        self._epg_token += 1
        future=getattr(self,"_epg_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception as exc:optional_failure("ui.browser_epg_future_cancel",exc)
        self._epg_future=None
        for hook_name,callback in (
            ("onShown",self._browser_shown_reset),
            ("onHide",self._browser_hidden_release),
            ("onLayoutFinish",self._layout_ready),
        ):
            try:
                hooks=getattr(self,hook_name,None)
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:
                optional_failure("ui.browser_hook_cleanup",exc)
        try:
            callbacks=self["list"].onSelectionChanged
            if self._selection_changed in callbacks:callbacks.remove(self._selection_changed)
        except Exception as exc:
            optional_failure("ui.browser_selection_cleanup",exc)

    def _selection_snapshot(self, cfg):
        cfg=cfg if isinstance(cfg,dict) else {}
        return {
            "clean_titles":bool(cfg.get("clean_titles",True)),
            "load_images":bool(cfg.get("load_images",True)),
            "parental_lock":bool(cfg.get("parental_lock",False)),
            "parental_mode":str(cfg.get("parental_mode","pin") or "pin"),
            "adult_keywords":list(cfg.get("adult_keywords",[]) or []),
            "pinned_categories":{str(k):list(v or []) for k,v in dict(cfg.get("pinned_categories",{}) or {}).items()},
            "protected_categories":{str(k):list(v or []) for k,v in dict(cfg.get("protected_categories",{}) or {}).items()},
        }

    def _selection_settings(self):
        now=time.monotonic()
        if now-float(getattr(self,"_selection_cfg_mono",0.0) or 0.0)>0.35:
            self._selection_cfg=self._selection_snapshot(load_settings());self._selection_cfg_mono=now
        return self._selection_cfg

    def _refresh_selection_settings(self):
        self._selection_cfg=self._selection_snapshot(load_settings());self._selection_cfg_mono=time.monotonic()
        try:self._image_load_images=bool(self._selection_cfg.get("load_images",True))
        except Exception:pass

    def _browser_shown_reset(self):
        try:self._refresh_selection_settings()
        except Exception as exc:optional_failure("ui.browser_settings_refresh",exc)
        # Do not jump to the first row when a child screen closes.  Enigma2
        # fires onShown again after modal dialogs/players, so moving to index 0
        # here destroyed the user's navigation position.
        try:
            if getattr(self,"_browser_images_suspended",False):
                self._browser_images_suspended=False
                self._image_layout_ready()
        except Exception as exc:optional_failure("ui.browser_resume_image",exc)
        if self._category_surface_active() and self.media_type in ("itv","vod","series"):
            try:
                self._apply_category_portal_geometry()
                self._load_category_backdrop()
                if self.level == "genres":
                    self._load_category_chrome()
                self._restore_category_side_identity()
            except Exception as exc:optional_failure("ui.category_resume_identity",exc)
        try:self._selection_changed()
        except Exception as exc:optional_failure("ui",exc)
        try:self._apply_browser_status_color()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._schedule_initial_action()

    def _browser_hidden_release(self):
        if getattr(self,"_screen_closed",False):return
        self._browser_images_suspended=True
        try:self._image_suspend()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._release_browser_pixmaps()

    def _utility_mode_active(self):
        return self.level in ("catchup_channels","catchup_channels_loading","catchup_programs","catchup_programs_loading","favorites")

    def _apply_utility_glass_mode(self):
        """Static compact glass identity for Catch-up and Favorites."""
        try:
            self._browser_geom("list",62,650,1796,300)
            self["list"].row_width=1796
            self["list"].set_layout(58,40,23,16,"utility_glass")

            # Same authored right column as Settings.
            for name,x,y,w,h in (
                ("preview",1260,132,360,260),
                ("accent_frame",0,0,1,1),
                ("info_card1",1110,438,660,78),
                ("info_card2",1110,532,660,78),
                ("info_card3",1110,626,660,78),
                ("info_icon1",1134,453,48,48),
                ("info_icon2",1134,547,48,48),
                ("info_icon3",1134,641,48,48),
                ("info_title",1200,438,540,78),
                ("info",1200,532,540,78),
                ("status",1200,626,540,78),
            ):
                try:self._browser_geom(name,x,y,w,h)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
            for divider_name in ("divider","separator","midline","vline","vertical_line"):
                try:self[divider_name].hide()
                except Exception as exc:optional_failure("ui.silent_guard",exc)
            if self["list"].instance is not None:
                try:self["list"].instance.setSelectionEnable(0)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setTransparent(1)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setScrollbarMode(2)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setScrollbarMode(2)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
        except Exception as exc:optional_failure("ui.utility_browser_geom",exc)
        try:
            # Favorites/Catch-up share the exact pinned Home Hero identity, just
            # like Movies/Series/Live.  Keep the lower area dark for content.
            self._load_category_backdrop()
            self["page_adaptive_bg"].show()
            for n in ("preview","accent_frame","info_card1","info_card2","info_card3","info_icon1","info_icon2","info_icon3","info_title","info"):
                try:self[n].hide()
                except Exception:pass
        except Exception as exc:optional_failure("ui.utility_hero",exc)
        try:
            if self["accent_frame"].instance is not None:
                self["accent_frame"].instance.setPixmap(None)
            self["accent_frame"].hide()
            self._browser_geom("accent_frame",2000,0,1,1)
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            self._image_size=(360,260)
            self._picload.setPara((360,260,1,1,False,1,"#000000"))
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        chrome=_neutral_utility_glass()
        self._category_chrome=dict(chrome)
        card=chrome.get("side") or chrome.get("info")
        if card and os.path.isfile(card):
            for n in ("info_card1","info_card2","info_card3"):
                try:self[n].instance.setPixmapFromFile(card);self[n].show()
                except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _set_utility_preview_direct(self, filename):
        """Display utility-page hero art directly, bypassing ePicLoad artifacts."""
        try:
            path=asset(filename)
            if self["preview"].instance is not None and os.path.isfile(path):
                self["preview"].instance.setPixmapFromFile(path)
                self["preview"].show()
        except Exception as exc:
            optional_failure("ui.utility_preview_direct",exc)

    def _layout_ready(self):
        try:_ui_diag("ui_ready",screen="browser",elapsed_ms=int((time.monotonic()-self._ui_diag_open_mono)*1000.0))
        except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)
        self._image_layout_ready()

        # Test15 cold-start path: Home already chose Live/Movies/Series.  Keep the
        # Browser root completely unpainted while categories are fetched.  The user
        # sees the final clean hero immediately, then the real rows appear once.
        if self.initial_action in ("catchup","favorites") and not self._initial_action_done:
            # Hero-first utility cold start.  Keep every legacy Browser widget
            # hidden until the requested local/network utility view is ready.
            try:
                self._load_category_backdrop();self["page_adaptive_bg"].show()
            except Exception as exc:optional_failure("ui.utility_cold_hero",exc)
            for _name in ("title","counter","section","top_divider","list","accent_frame","preview","info_card1","info_card2","info_card3","info_icon1","info_icon2","info_icon3","info_title","info","status","red_bg","green_bg","yellow_bg","blue_bg","red","green","yellow","blue"):
                try:self[_name].hide()
                except Exception:pass
            self._schedule_initial_action()
            return

        if self.initial_action in ("itv","vod","series"):
            self.media_type = self.initial_action
            if self.level not in ("genres", "genres_loading"):
                self.level = "genres_loading"
            self._apply_category_portal_geometry()
            self._load_category_backdrop()
            if self.level == "genres":
                # A 1ms onShown timer may beat onLayoutFinish on some images when
                # categories are cached.  Preserve the already-ready final rows.
                self._load_category_chrome()
                self._reveal_browser_content()
            else:
                try:self["list"].hide()
                except Exception as exc:optional_failure("ui.category_cold_list_hide", exc)
            if not self._initial_action_done:
                self._initial_action_done=True
                self._open_media_with_parental(self.initial_action)
            return

        for _name in ("title", "counter", "section", "top_divider", "list", "accent_frame", "preview", "info_card1", "info_card2", "info_card3", "info_icon1", "info_icon2", "info_icon3", "info_title", "info", "status", "red_bg", "green_bg", "yellow_bg", "blue_bg", "red", "green", "yellow", "blue"):
            try:
                self[_name].show()
            except Exception as exc:
                optional_failure("ui", exc)
        self._set_root_rows()
        self._decode_picture(asset("us80_section_live_530x382.png"))
        self._selection_changed()
        # Modal actions still wait for onShown; OpenATV rejects modal opens here.

    def _schedule_initial_action(self):
        if self._initial_action_done or self._initial_action_scheduled or not self.initial_action:return
        self._initial_action_scheduled=True
        try:self._initial_action_timer.start(1,True)
        except Exception:
            self._initial_action_scheduled=False
            self._activate_initial_action()

    def _stop_initial_action_timer(self):
        try:self._initial_action_timer.stop()
        except Exception as exc:optional_failure("ui.browser_initial_timer_stop",exc)
        try:
            if self._initial_action_timer_conn is not None:self._initial_action_timer_conn.disconnect()
        except Exception as exc:optional_failure("ui.browser_initial_timer_disconnect",exc)
        try:
            if self._activate_initial_action in self._initial_action_timer.callback:self._initial_action_timer.callback.remove(self._activate_initial_action)
        except Exception as exc:optional_failure("ui.browser_initial_timer_callback",exc)

    def _activate_initial_action(self):
        self._initial_action_scheduled=False
        if self._initial_action_done or not self.initial_action:
            return
        self._initial_action_done = True
        action = self.initial_action
        if action in ("itv", "vod", "series"):
            self._open_media_with_parental(action)
        elif action == "catchup":
            self.load_catchup_channels()
        elif action == "favorites":
            self._show_saved_entries(load_favorites(), "Favorites")
        elif action == "recent":
            self._show_saved_entries(load_continue_watching(), "Continue Watching")
        elif action == "account":
            self.show_account_info()
        elif action == "settings":
            self.session.open(NovaSettingsScreen, self.profile, self.client)

    def _drain_jobs(self):
        AsyncScreenMixin._drain_jobs(self)
        if not self._screen_closed:
            self._drain_image_jobs(); self._drain_epg_jobs()
            while True:
                try:msg=self._live_picon_cache_progress.get_nowait()
                except queue.Empty:break
                except Exception:break
                try:
                    phase=msg[0]
                    if phase=="scan":
                        _phase,done,total=msg
                        self["blue"].setText("%d / %d"%(done,total))
                        self["status"].setText(_("Scanning Live categories %d / %d")%(done,total))
                    elif phase=="cache":
                        _phase,done,total,cached,downloaded,unavailable=msg
                        self["blue"].setText("%d / %d"%(done,total))
                        self["status"].setText(_("Picons %d/%d • %d cached • %d downloaded • %d failed")%(
                            done,total,cached,downloaded,unavailable))
                    elif phase=="done":
                        _phase,done,total,cached,downloaded,unavailable=msg
                        self._live_picon_cache_running=False
                        self["blue"].setText(_("Cache Picons"))
                        self["status"].setText(_("Picons ready • %d/%d • %d cached • %d downloaded • %d failed")%(
                            done,total,cached,downloaded,unavailable))
                    elif phase=="error":
                        self._live_picon_cache_running=False
                        self["blue"].setText(_("Cache Picons"))
                        self["status"].setText(str(msg[1] if len(msg)>1 else _("Picon cache failed")))
                except Exception as exc:
                    optional_failure("ui.live_picon_cache_progress",exc)

    def _set_list_density(self, mode="root"):
        """Stable per-screen density. Never share cramped geometry across unrelated lists."""
        if mode == "root":
            self["list"].set_layout(72, 56, 31, 20, "double")
        elif mode == "genres":
            self["list"].row_width = max(434, int(getattr(self,"_category_row_card_w",426) or 426) + 8)
            self["list"].set_layout(66, 40, 22, 16, "category_portal")
        elif mode == "itv":
            cfg=getattr(self, "_grid_settings", None) or load_settings(); layout=cfg.get("channel_list_mode","epg")
            if layout == "large": self["list"].set_layout(70, 50, 27, 18, "channel")
            elif layout == "compact": self["list"].set_layout(52, 38, 23, 16, "single")
            else: self["list"].set_layout(62, 44, 24, 16, "channel")
        elif mode == "compact":
            self["list"].set_layout(54, 38, 25, 18, "compact_meta")
        else:
            self["list"].set_layout(56, 40, 26, 18, "compact_meta")


    def _browser_geom(self, name, x, y, w, h):
        """Move/resize one Browser widget using the same 1920x1080 design grid."""
        try:
            desktop=getDesktop(0).size(); sx=float(desktop.width())/1920.0; sy=float(desktop.height())/1080.0
            inst=self[name].instance
            if inst is not None:
                inst.move(ePoint(int(round(x*sx)), int(round(y*sy))))
                inst.resize(eSize(int(round(w*sx)), int(round(h*sy))))
        except Exception as exc:
            optional_failure("ui.browser_geom", exc)

    def _category_display_title(self, entry, cfg=None):
        cfg = cfg or load_settings()
        e = entry if isinstance(entry, dict) else {}
        gid = str(e.get("id") or e.get("genre_id") or e.get("name") or e.get("title") or "")
        raw = e.get("title") or e.get("name") or e.get("category_name") or e.get("genre_name") or e.get("id") or "Category"
        title = _clean_display_text(raw, 100) or "Category"
        pinned = set(cfg.get("pinned_categories", {}).get(self.media_type, []))
        protected = set(cfg.get("protected_categories", {}).get(self.media_type, []))
        words = cfg.get("adult_keywords", [])
        if gid in pinned:
            title = "★  " + title
        sensitive = gid in protected or any(str(w).casefold() in str(e.get("name") or e.get("title") or "").casefold() for w in words)
        if cfg.get("parental_lock") and cfg.get("parental_mode", "pin") == "pin" and sensitive:
            title = "[PIN]  " + title
        return title

    def _category_measure_width(self, text, font_size):
        try:
            fn = globals().get("_settings_text_width_px")
            if fn is not None:
                return max(1, int(fn(str(text or ""), int(font_size))))
        except Exception as exc:
            optional_failure("ui.category_text_measure", exc)
        return max(1, int(len(str(text or "")) * max(1, int(font_size)) * 0.58))

    def _prepare_category_global_geometry(self, entries, cfg=None):
        """Choose one stable row width for the entire category list.

        The width is based on the longest decorated title across every category,
        not just the 14 currently visible rows.  All pages therefore keep the
        exact same rail geometry while UP/DOWN paging.
        """
        cfg = cfg or load_settings()
        titles = [self._category_display_title(e, cfg) for e in (entries or [])]
        if not titles:
            titles = ["Category"]
        chosen_font, chosen_size, chosen_width = 0, 22, 426
        for font_index, font_size in ((0,22),(3,19),(4,17)):
            longest = max([self._category_measure_width(t, font_size) for t in titles] or [260])
            needed = max(426, longest + 110)  # icon + inner spacing + right breathing room
            chosen_font, chosen_size, chosen_width = font_index, font_size, min(860, needed)
            if needed <= 860:
                break
        # Even width gives cleaner scaling/alignment on receivers.
        chosen_width = int(chosen_width)
        if chosen_width % 2:
            chosen_width += 1
        self._category_row_card_w = max(426, min(860, chosen_width))
        self._category_title_font = chosen_font
        return self._category_row_card_w

    def _set_category_clean_visibility(self, active):
        # Categories intentionally keep only the brand, exact Home backdrop and
        # floating rows.  A neutral full-screen underlay covers the Browser's
        # baked divider while the hero is being restored, so neither the old
        # top line nor any right-side Browser furniture can flash through.
        try:
            (self["category_clean_bg"].show() if active else self["category_clean_bg"].hide())
        except Exception as exc:
            optional_failure("ui.category_clean_underlay", exc)
        if active:
            # Category pages are intentionally brand-free.  Do not rely on hide()
            # alone: some Enigma2 images repaint the skin-time pixmap after layout.
            # Clear the native pixmap and move the widget off-screen as well.
            try:
                if self["brand_header"].instance is not None:
                    self["brand_header"].instance.setPixmap(None)
                self["brand_header"].hide()
                self._browser_geom("brand_header",2000,0,1,1)
            except Exception as exc:optional_failure("ui.category_brand_hard_hide",exc)
            # Hard-disable the legacy right-side preview, including any root-page
            # decode that was queued just before cached Categories became ready.
            try:self._image_suspend()
            except Exception as exc:optional_failure("ui.category_preview_suspend", exc)
            try:
                if self["preview"].instance is not None:
                    self["preview"].instance.setPixmap(None)
                self["preview"].hide()
            except Exception as exc:optional_failure("ui.category_preview_clear", exc)
        if not active:
            try:
                self._browser_geom("brand_header",48,12,300,96)
                _brand=asset("brand_header_full.png")
                if self["brand_header"].instance is not None and os.path.isfile(_brand):
                    self["brand_header"].instance.setPixmapFromFile(_brand)
            except Exception as exc:optional_failure("ui.category_brand_restore",exc)
        names=("brand_header","title","section","counter","top_divider","preview","accent_frame",
               "info_card1","info_card2","info_card3","info_icon1","info_icon2","info_icon3",
               "info_title","info","status","red_bg","green_bg","yellow_bg","blue_bg",
               "red","green","yellow","blue")
        for name in names:
            try:
                (self[name].hide() if active else self[name].show())
            except Exception as exc:
                optional_failure("ui.category_clean_visibility", exc)

    def _apply_category_portal_geometry(self):
        """Apply the clean full-height Categories rail.

        The Categories-only brand is hidden and the exact approved 66px row
        grammar is preserved.  Sixteen complete rows fit between 12px top/bottom
        margins, so density increases without shrinking cards or their spacing.
        """
        card_w=max(426,min(860,int(getattr(self,"_category_row_card_w",426) or 426)))
        list_w=card_w+8
        self._browser_geom("list",50,12,list_w,1056)
        try:
            self["list"].row_width=list_w
            if self["list"].instance is not None:
                try:self["list"].instance.setSelectionEnable(0)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setTransparent(1)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setScrollbarMode(2)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
        except Exception as exc:optional_failure("ui.category_settings_list",exc)
        self._set_category_clean_visibility(True)

    def _restore_browser_geometry(self):
        """Restore the normal Browser geometry when leaving Categories."""
        self._set_category_clean_visibility(False)
        try:
            self["page_adaptive_bg"].hide()
        except Exception as exc:
            optional_failure("ui.silent_guard",exc)
        self._browser_geom("list", 78, 190, 754, 720)
        self._browser_geom("preview", 1110, 205, 530, 382)
        self._browser_geom("accent_frame", 1090, 194, 570, 405)
        self._browser_geom("info_card1", 1070, 620, 610, 70)
        self._browser_geom("info_card2", 1070, 708, 610, 70)
        self._browser_geom("info_card3", 1070, 796, 610, 70)
        self._browser_geom("info_icon1", 1090, 634, 42, 42)
        self._browser_geom("info_icon2", 1090, 722, 42, 42)
        self._browser_geom("info_icon3", 1090, 810, 42, 42)
        self._browser_geom("info_title", 1145, 620, 515, 70)
        self._browser_geom("info", 1145, 708, 515, 70)
        self._browser_geom("status", 1145, 796, 515, 70)
        try:
            if self["list"].instance is not None:
                try:self["list"].instance.setSelectionEnable(1)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setScrollbarMode(2)
                except Exception:
                    try:self["list"].instance.setScrollbarMode(2)
                    except Exception as exc:optional_failure("ui.silent_guard",exc)
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            self._image_size=(530,382)
            self._picload.setPara((530,382,1,1,False,1,"#000000"))
        except Exception as exc:optional_failure("ui.silent_guard",exc)


    def _category_mood_source(self):
        """Return the cached source belonging to the exact current Home hero.

        Categories prefer the hero's raw local backdrop so Test15 can retain the
        artwork farther down the screen than Home's intentionally short prepared
        top-hero.  No network lookup is allowed here.
        """
        media = str(getattr(self, "media_type", "") or "").lower()
        hero = {}
        try:
            with open(HOME_HERO_FILE, "r", encoding="utf-8") as h:
                state = json.load(h)
            hero = state.get("hero") if isinstance(state, dict) and isinstance(state.get("hero"), dict) else {}
        except Exception:
            hero = {}
        # Categories need more vertical artwork than Home's prepared TOP hero,
        # whose alpha intentionally reaches zero around y=610.  Prefer the exact
        # raw cached backdrop belonging to that same hero, then build our own
        # receiver-safe long derivative from it.
        for key in ("display_backdrop_local", "backdrop_local"):
            candidate = str(hero.get(key) or "") if isinstance(hero, dict) else ""
            try:
                if candidate and os.path.isfile(candidate) and os.path.getsize(candidate) > 4096:
                    return candidate
            except Exception as exc:
                optional_failure("ui.category_raw_hero", exc)

        direct = str(getattr(self, "_home_adaptive_source", "") or "")
        try:
            if direct and os.path.isfile(direct) and os.path.getsize(direct) > 4096:
                return direct
        except Exception as exc:
            optional_failure("ui.silent_guard",exc)

        prepared = str(hero.get("prepared") or "") if isinstance(hero, dict) else ""
        try:
            if prepared and os.path.isfile(prepared) and os.path.getsize(prepared) > 4096:
                return prepared
        except Exception as exc:
            optional_failure("ui.category_prepared_fallback", exc)

        section_source = {
            "itv": "us80_section_live_530x382.png",
            "vod": "us80_section_movies_530x382.png",
            "series": "us80_section_series_530x382.png",
        }.get(media, "nova_browser_bg.png")
        fallback = asset(section_source)
        return fallback if fallback and os.path.isfile(fallback) else None

    def _category_chrome_source(self):
        """Use the same prepared Home hero palette as Portal List chrome.

        The raw backdrop remains the visual background, while all adaptive glass
        surfaces derive from the prepared hero so Home, Categories and Portal List
        share one accent authority after a Hero change.
        """
        hero = {}
        try:
            with open(HOME_HERO_FILE, "r", encoding="utf-8") as h:
                state = json.load(h)
            hero = state.get("hero") if isinstance(state, dict) and isinstance(state.get("hero"), dict) else {}
        except Exception:
            hero = {}
        for candidate in (str(hero.get("prepared") or ""), str(getattr(self, "_home_adaptive_source", "") or "")):
            try:
                if candidate and os.path.isfile(candidate) and os.path.getsize(candidate) > 4096:
                    return candidate
            except Exception as exc:
                optional_failure("ui.category_chrome_source", exc)
        return self._category_mood_source()

    def _load_category_backdrop(self):
        """Show the clean, lower-reaching Categories hero without building rows."""
        try:
            src = self._category_mood_source()
            if not src:
                return None
            try:
                stamp = str(int(os.path.getmtime(src)))
            except Exception:
                stamp = "0"
            key = hashlib.sha1((src + "|" + stamp + "|category-long-hero-v1").encode("utf-8", "ignore")).hexdigest()[:16]
            backdrop = _build_category_extended_backdrop(src, key)
            if not backdrop or not os.path.isfile(backdrop):
                backdrop = src
            self._browser_geom("page_adaptive_bg", 0, 0, 1920, 1080)
            if self["page_adaptive_bg"].instance is not None and os.path.isfile(backdrop):
                self["page_adaptive_bg"].instance.setPixmapFromFile(backdrop)
                self["page_adaptive_bg"].show()
            self._set_category_clean_visibility(True)
            return backdrop
        except Exception as exc:
            optional_failure("ui.category_long_backdrop", exc)
            return None

    def _load_category_chrome(self):
        try:
            src = self._category_chrome_source()
            if not src:
                self._category_chrome = {}
                return {}
            try:
                stamp = str(int(os.path.getmtime(src)))
            except Exception:
                stamp = "0"
            card_w=max(426,min(860,int(getattr(self,"_category_row_card_w",426) or 426)))
            key = hashlib.sha1((src + "|" + stamp + "|category-settings-v2|" + str(card_w)).encode("utf-8", "ignore")).hexdigest()[:16]
            self._category_chrome = _build_category_adaptive_chrome(
                src, key, getattr(self,"media_type","") or "", card_w
            )

            # The rows and the visible long hero derive from the same cached Home
            # source; Categories simply retain the picture farther down the screen.
            self._load_category_backdrop()
            return self._category_chrome
        except Exception as exc:
            optional_failure("ui.category_chrome_load", exc)
            self._category_chrome = {}
            return {}

    def _render_genre_rows(self):
        if self.level != "genres":
            return
        chrome = self._category_chrome or self._load_category_chrome()
        try:
            selected = self["list"].getSelectedIndex()
        except Exception:
            selected = 0
        cfg = load_settings()
        rows = []
        card_w=max(426,min(860,int(getattr(self,"_category_row_card_w",426) or 426)))
        title_font=int(getattr(self,"_category_title_font",0) or 0)
        for i, e in enumerate(self.content_items):
            title = self._category_display_title(e, cfg)
            details = {
                "selected": i == selected,
                "row_asset": chrome.get("row"),
                "row_selected_asset": chrome.get("row_selected"),
                "card_w": card_w,
                "title_font": title_font,
            }
            rows.append((title, asset("us89_folder_yellow_42.png"), e, details))
        self["list"].set_icon_rows(rows)
        try:
            self["list"].moveToIndex(max(0, min(selected, len(rows) - 1)))
        except Exception as exc:
            optional_failure("ui.silent_guard",exc)

    def _set_root_rows(self):
        try:self._restore_browser_geometry()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._set_list_density("root")
        cfg=load_settings(); self.active_modes=[]
        enabled={"itv":cfg.get("show_live",True),"vod":cfg.get("show_movies",True),"series":cfg.get("show_series",True),"catchup":cfg.get("show_catchup",True)}
        for mode in self.ALL_MODES:
            if mode[1] not in enabled or enabled[mode[1]]: self.active_modes.append(mode)
        self.MODES=tuple(self.active_modes)
        rows=[]
        fav_count = len(load_favorites()); recent_count = len(load_continue_watching())
        health = self.client.health_snapshot() if getattr(self.client, "token", None) else {"health":"ready","latency_ms":0}
        descriptions={"itv":"Professional channel list with lazy Now / Next EPG","vod":"Movies with artwork, details, favorites and watched state","series":"Series, seasons, episodes and resume support","catchup":"Archived programmes and replay TV","favorites":"Your saved content  •  %d items" % fav_count,"recent":"Continue watching  •  %d items" % recent_count,"account":"Subscription and portal health details","search":"One search across Live, Movies and Series","settings":"Themes, lists, Smart Engine, privacy and cache"}
        for title,key,icon in self.MODES: rows.append((_(title),asset(icon),key,_(descriptions[key])))
        self["blue"].setText(_("Open / Play"))
        self["list"].set_icon_rows(rows); self["counter"].setText(_("PORTAL HOME  •  %d sections") % len(rows))
        try:self["list"].moveToIndex(0)
        except Exception as exc:optional_failure("ui",exc)

    def _selection_changed(self):
        try: idx=self["list"].getSelectedIndex()
        except Exception: return
        if self.level == "root" and 0 <= idx < len(self.MODES):
            title,key,_icon=self.MODES[idx]
            self["info_title"].setText(_(title))
            self["info"].setText(_("Press OK to browse %s") % _(title))
            ph={"itv":"us80_section_live_530x382.png","vod":"us80_section_movies_530x382.png","series":"us80_section_series_530x382.png","favorites":"us81_section_favorites_530x382.png","recent":"placeholder_live_x.png","settings":"us81_section_settings_530x382.png","search":"us81_section_search_530x382.png","catchup":"us81_section_catchup_530x382.png","account":"placeholder_server_x.png"}.get(key,"placeholder_server_x.png")
            # Root art is local and authoritative for this focus. Cancel any
            # provider-art request left behind by the previous content row.
            self._image_supersede()
            self._decode_picture(asset(ph))
        elif 0 <= idx < len(self.content_items):
            item=self.content_items[idx]
            if self.level == "genres":
                try:self._restore_category_side_identity()
                except Exception as exc:optional_failure("ui.category_identity_selection",exc)
                try:
                    chrome=self._category_chrome or self._load_category_chrome()
                    cfg=self._selection_settings();card_w=max(426,min(860,int(getattr(self,"_category_row_card_w",426) or 426)));title_font=int(getattr(self,"_category_title_font",0) or 0)
                    for j in set((idx, getattr(self,"_genre_last_idx",idx))):
                        if 0 <= j < len(self.content_items):
                            e=self.content_items[j];title=self._category_display_title(e,cfg)
                            details={"selected":j==idx,"row_asset":chrome.get("row"),"row_selected_asset":chrome.get("row_selected"),"card_w":card_w,"title_font":title_font}
                            self["list"].update_icon_row(j,(title,asset("us89_folder_yellow_42.png"),e,details))
                    # update_icon_row() invalidates only the old/new selected
                    # entries. A full list invalidate here repaints every category
                    # on each arrow press and defeats the incremental renderer.
                    self._genre_last_idx=idx
                except Exception as exc: optional_failure("ui.category_selection",exc)
                # Categories intentionally show no provider preview; invalidate a
                # late item-art worker from the page we just left.
                try:self._image_supersede()
                except Exception as exc:optional_failure("ui.category_preview_supersede",exc)
                return
            raw_title=str(item.get("name") or item.get("title") or item.get("id") or "Content")
            title=(_clean_display_text(item.get("title") or item.get("name") or item.get("category_name") or item.get("genre_name") or item.get("id") or "Category",100) or "Category") if self.level=="genres" else premium_title(raw_title,self._selection_settings().get("clean_titles",True))
            self["info_title"].setText(title[:34])
            if self.media_type=="itv" and self.level=="items": self._schedule_epg_preview(item)
            if self.level == "genres":
                try:self["accent_frame"].hide()
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                self["info"].setText(_("Category folder"))
                section_icon = {
                    "itv": "us80_section_live_530x382.png",
                    "vod": "us80_section_movies_530x382.png",
                    "series": "us80_section_series_530x382.png",
                }.get(self.media_type, "placeholder_folder_x.png")
                self._decode_picture(asset(section_icon))
            else:
                if self._utility_mode_active():
                    try:
                        if self["accent_frame"].instance is not None:
                            self["accent_frame"].instance.setPixmap(None)
                        self["accent_frame"].hide()
                    except Exception as exc:optional_failure("ui.silent_guard",exc)
                else:
                    self._set_accent(title, poster=(self.media_type in ("vod","series") and self.level=="items"))
                meta=[]
                for k in ("year","number","rating","genre"):
                    if item.get(k): meta.append(str(item.get(k)))
                self["info"].setText("  •  ".join(meta)[:58] or self._mode_name(self.media_type))
                if self._utility_mode_active():
                    try:self["preview"].hide()
                    except Exception:pass
                else:
                    ph=(_letter_placeholder(title) if self.media_type=="itv" else ("us81_placeholder_movies_480x345.png" if self.media_type=="vod" else "us81_placeholder_series_480x345.png"))
                    self._load_item_image(item if (self.media_type=="itv" or (isinstance(item,dict) and item.get("_xtream"))) else _strip_portal_artwork(item),ph)

    def _set_accent(self, value, poster=False):
        name = _accent_for(value)
        filename = "accent_poster_%s.png" % name if poster else "accent_logo_%s.png" % name
        try:
            self["accent_frame"].instance.setPixmapFromFile(asset(filename))
            self["accent_frame"].show()
        except Exception as exc: optional_failure("ui",exc)

    def open_tools(self):
        if self.level == "items":
            choices = [(_("Global Search"), "global_search"), (_("EPG for selected channel"), "epg"), (_("Search current list"), "search")]
            if self.media_type in ("itv", "vod", "series"):
                choices += [((_("Send selected to Receiver") if self.media_type != "series" else _("Send selected Series to Receiver")), "send_receiver")]
            if self.media_type == "vod" and self.content_items:
                try: current_state=self._content_state_cache.get(id(self.content_items[self["list"].getSelectedIndex()]),{})
                except Exception: current_state={}
                choices += [(_("Mark selected unwatched"), "mark_current_unwatched")] if current_state.get("completed") else [(_("Mark selected watched"), "mark_current_watched")]
            if self._home_entry and self.initial_action == "recent":
                choices += [(_("Mark selected watched"), "mark_watched"), (_("Mark selected unwatched"), "mark_unwatched"), (_("Remove selected from Continue Watching"), "remove_history"), (_("Clear Continue Watching"), "clear_history")]
            choices += [(_("Hide / unhide current category"), "hide_category"), (_("Audio tracks"), "audio"), (_("Subtitles"), "subtitles"), (_("Next page"), "next"), (_("Previous page"), "prev"), (_("Portal settings"), "settings"), (_("Favorites"), "favorites"), (_("Continue Watching"), "recent")]
        elif self.level == "genres":
            choices = [(_("Global Search"), "global_search")]
            if self.media_type == "itv":
                choices += [(_("Export current Live folder to TV"), "export_live_folder")]
            elif self.media_type == "vod":
                choices += [(_("Export current Movies folder to TV"), "export_media_folder")]
            elif self.media_type == "series":
                choices += [(_("Export current Series folder to TV"), "export_media_folder")]
            choices += [(_("Pin / unpin current category"), "pin_category"), (_("Protect / unprotect category with PIN"), "protect_category"), (_("Hide / unhide current category"), "hide_category"), (_("Portal settings"), "settings"), (_("Favorites"), "favorites"), (_("Continue Watching"), "recent")]
        else:
            choices = [(_("Global Search"), "global_search"), (_("Portal settings"), "settings"), (_("Favorites"), "favorites"), (_("Recently played"), "recent")]
        self.session.openWithCallback(self._tool_selected, ChoiceBox, title=_("Portal tools"), list=choices)

    def _tool_selected(self, choice):
        if not choice:
            return
        action = choice[1]
        if action == "global_search": self.open_global_search()
        elif action == "search": self.open_search()
        elif action == "export_live_folder": self.export_current_live_folder()
        elif action == "export_media_folder": self.export_current_media_folder()
        elif action == "send_receiver": self.send_selected_to_receiver()
        elif action == "pin_category": self.toggle_current_category_pinned()
        elif action == "protect_category": self.toggle_current_category_protected()
        elif action == "hide_category": self.toggle_current_category_hidden()
        elif action == "audio": self.open_audio()
        elif action == "subtitles": self.open_subtitles()
        elif action == "epg": self.show_selected_epg()
        elif action == "favorites": self._show_saved_entries(load_favorites(), "Favorites")
        elif action == "recent": self._show_saved_entries(load_continue_watching(), "Continue Watching")
        elif action == "next" and self.level == "items": self.load_items(self.media_type, self.genre, self.page + 1)
        elif action == "prev" and self.level == "items": self.load_items(self.media_type, self.genre, max(1, self.page - 1))
        elif action == "settings": self.open_playback_settings()
        elif action in ("mark_watched","mark_unwatched","remove_history"):
            self._history_action(action)
        elif action in ("mark_current_watched","mark_current_unwatched"):
            idx=self["list"].getSelectedIndex()
            if 0<=idx<len(self.content_items):
                item=self.content_items[idx];watched=action=="mark_current_watched";mark_watched(self.profile,self.media_type,item,watched);self._render_content_rows(keep_index=idx);self["status"].setText(_("Marked watched") if watched else _("Marked unwatched"))
        elif action == "clear_history":
            self.session.openWithCallback(self._clear_history_confirmed,MessageBox,_("Clear Continue Watching for this portal?"),MessageBox.TYPE_YESNO)

    def _receiver_cached_art(self, media_type, item, client=None, allow_fetch=False):
        """Resolve receiver artwork, fetching only a single selected Live picon when needed."""
        try:
            if media_type == "itv":
                raw = _image_url(item)
                cached = _cached_live_picon_path(raw, self.profile, item) or ""
                if cached or not allow_fetch or not raw:
                    return cached
                try:
                    return _download_live_portal_temp_picon(raw, self.profile, client or self.client, item=item, timeout=4.5) or ""
                except Exception:
                    return _download_public_live_picon(raw, self.profile, item=item, timeout=4.0) or ""
            snap = load_detail_snapshot(self.profile, media_type, item) or {}
            bundle = _load_visual_bundle(self.profile, media_type, item, snap) or {}
            return str(bundle.get("poster") or snap.get("poster_local") or "")
        except Exception as exc:
            optional_failure("ui.receiver_cached_art", exc)
            return ""

    def send_selected_to_receiver(self):
        if self._busy or self.level != "items" or self.media_type not in ("itv", "vod", "series"):
            return
        idx = self["list"].getSelectedIndex()
        if not (0 <= idx < len(self.content_items)):
            return
        item = dict(self.content_items[idx] or {})
        media_type = self.media_type
        cfg = load_settings()
        keep_index = idx
        raw_title = item.get("name") or item.get("title") or "Item"
        title = premium_title(raw_title, load_settings().get("clean_titles", True))
        self["status"].setText(_("Sending to Receiver: %s") % title)

        def work(handle):
            isolated = _new_isolated_source_client(dict(self.profile or {}), timeout=min(6, int(cfg.get("timeout", 10) or 10)))
            try:
                if media_type in ("itv", "vod"):
                    row = dict(item)
                    row["_receiver_name"] = premium_title(row.get("name") or row.get("title") or "Item", cfg.get("clean_titles", True))
                    art = self._receiver_cached_art(media_type, row, client=isolated, allow_fetch=(media_type == "itv"))
                    if art:
                        row["_receiver_picon_local"] = art
                    result = export_receiver_items(
                        self.profile, [row], media_type,
                        "Live Favorites" if media_type == "itv" else "Movies",
                        cfg.get("service_type", 4097),
                    )
                    return result

                # Series title itself is not a playable Enigma2 service. Export
                # its real episodes, keeping them grouped in one receiver bouquet.
                rows = []
                seasons = call_compatible(
                    isolated.series_seasons,
                    (((item,), {"cancel_event": handle.cancel_event}), ((item, handle.cancel_event), {}), ((item,), {})),
                ) or []
                series_name = _clean_display_text(item.get("name") or item.get("title") or "Series", 80)
                poster = self._receiver_cached_art("series", item)
                for season in seasons[:50]:
                    if handle.cancelled():
                        break
                    episodes = call_compatible(
                        isolated.series_episodes,
                        (((item, season), {"cancel_event": handle.cancel_event}), ((item, season, handle.cancel_event), {}), ((item, season), {})),
                    ) or []
                    season_no = int((season or {}).get("season") or (season or {}).get("season_id") or 0 or 0)
                    for pos, episode in enumerate(episodes, 1):
                        if not isinstance(episode, dict):
                            continue
                        row = dict(episode)
                        ep_no = row.get("episode_num") or row.get("episode") or row.get("number") or pos
                        try: ep_no = int(ep_no)
                        except Exception: ep_no = pos
                        try: s_no = int(row.get("season") or season_no or 0)
                        except Exception: s_no = season_no or 0
                        row["_receiver_name"] = "%s - S%02dE%02d" % (series_name, s_no, ep_no)
                        row["_receiver_media_type"] = "episode"
                        if poster:
                            row["_receiver_picon_local"] = poster
                        rows.append(row)
                        if len(rows) >= 1000:
                            break
                    if len(rows) >= 1000:
                        break
                if not rows:
                    raise RuntimeError(_("No playable episodes were found"))
                return export_receiver_items(self.profile, rows, "episode", series_name, cfg.get("service_type", 4097))
            finally:
                try: isolated.close()
                except Exception: pass

        def ok(result):
            try: self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception: pass
            reload_bouquets()
            count = int((result or {}).get("items") or 0)
            self["status"].setText(_("Sent to Receiver • %d item(s)") % count)
            self.session.open(MessageBox, _("Sent to the receiver bouquet list.\n\n%s\n%d item(s)") % (title, count), MessageBox.TYPE_INFO, timeout=8)

        def failed(exc):
            try: self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception: pass
            self["status"].setText(_("Send to Receiver failed: %s") % exc)

        self._run_async(work, ok, failed)

    def export_current_live_folder(self):
        """Export the selected Live category without disturbing category focus."""
        if self._busy or self.level != "genres" or self.media_type != "itv":
            return
        idx = self["list"].getSelectedIndex()
        if not (0 <= idx < len(self.content_items)):
            return
        category = dict(self.content_items[idx] or {})
        category_id = str(category.get("id") or category.get("genre_id") or category.get("name") or category.get("title") or "*")
        category_name = _clean_display_text(category.get("name") or category.get("title") or category_id or "Live", 80)
        keep_index = idx
        self["status"].setText(_("Exporting Live folder: %s") % category_name)
        cfg = load_settings()

        def work(handle):
            isolated = _new_isolated_source_client(dict(self.profile or {}), timeout=cfg.get("timeout", 10))
            try:
                rows = call_compatible(
                    isolated.ordered_all,
                    ((("itv", category_id), {"start_page":1, "max_pages":500, "max_items":25000, "cancel_event":handle.cancel_event}),
                     (("itv", category_id, 1, 500, 25000, handle.cancel_event), {})),
                ) or []
                if handle.cancelled():
                    return {}
                # Live-only export rule: use the same final label as Premium Live
                # and only this channel's already-cached picon. No download, scan,
                # refit, fallback substitution, or second cleanup pass here.
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    raw = row.get("name") or row.get("title") or row.get("id") or "Channel"
                    row["_receiver_name"] = _clean_live_channel_name(raw)
                    try:
                        cached = _cached_live_picon_path(_image_url(row), self.profile, row)
                        if cached:
                            row["_receiver_picon_local"] = cached
                    except Exception:
                        pass
                return export_live_category_bouquet(self.profile, rows, category_name, category_id, cfg.get("service_type", 4097))
            finally:
                try: isolated.close()
                except Exception: pass

        def ok(result):
            # Critical: do NOT call load_genres()/refresh_current() here.  That
            # old path reset the category rail to index 0 after export.
            try:
                self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception:
                pass
            reload_bouquets()
            count = int((result or {}).get("channels") or 0)
            self["status"].setText(_("Live folder exported • %d channels") % count)
            self.session.open(MessageBox, _("Live folder exported to the TV bouquet list.\n\n%s\n%d channels") % (category_name, count), MessageBox.TYPE_INFO, timeout=10)

        def failed(exc):
            try:
                self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception:
                pass
            self["status"].setText(_("Live folder export failed: %s") % exc)

        self._run_async(work, ok, failed)

    def export_current_media_folder(self):
        """Export Movies quickly, or Series as one child bouquet per series."""
        if self._busy or self.level != "genres" or self.media_type not in ("vod", "series"):
            return
        idx = self["list"].getSelectedIndex()
        if not (0 <= idx < len(self.content_items)):
            return
        category = dict(self.content_items[idx] or {})
        category_id = str(category.get("id") or category.get("genre_id") or category.get("name") or category.get("title") or "*")
        category_name = _clean_display_text(category.get("name") or category.get("title") or category_id or "Content", 80)
        media_type = self.media_type
        keep_index = idx
        cfg = load_settings()
        self["status"].setText(_("Exporting %s folder: %s") % (("Movies" if media_type == "vod" else "Series"), category_name))

        def _local_art_only(row):
            # Export must never scan detail snapshots or rebuild artwork. Only reuse
            # a path already present on the resolved row, otherwise skip the picon.
            for key in ("_receiver_picon_local", "poster_local", "cover_local", "image_local", "picon_local", "logo_local"):
                path = str((row or {}).get(key) or "")
                try:
                    if path and os.path.isfile(path):
                        return path
                except Exception:
                    pass
            return ""

        def work(handle):
            isolated = _new_isolated_source_client(dict(self.profile or {}), timeout=min(6, int(cfg.get("timeout", 10) or 10)))
            try:
                items = call_compatible(
                    isolated.ordered_all,
                    (((media_type, category_id), {"start_page":1, "max_pages":500, "max_items":25000, "cancel_event":handle.cancel_event}),
                     ((media_type, category_id, 1, 500, 25000, handle.cancel_event), {})),
                ) or []
                if handle.cancelled():
                    return {}

                if media_type == "vod":
                    rows = []
                    for item in items:
                        if not isinstance(item, dict) or not (item.get("cmd") or item.get("command") or item.get("url")):
                            continue
                        row = dict(item)
                        row["_receiver_name"] = premium_title(row.get("name") or row.get("title") or "Movie", cfg.get("clean_titles", True))
                        art = _local_art_only(row)
                        if art:
                            row["_receiver_picon_local"] = art
                        rows.append(row)
                    if not rows:
                        raise RuntimeError(_("No playable movies were found"))
                    return export_receiver_items(self.profile, rows, "vod", category_name, cfg.get("service_type", 4097))

                # One worker per series (bounded). Each worker owns its client,
                # avoiding the old serial Series -> Season -> Episodes chain.
                series_items = [dict(x) for x in items if isinstance(x, dict)]
                if not series_items:
                    raise RuntimeError(_("No series were found"))

                def fetch_series(series):
                    client = _new_isolated_source_client(dict(self.profile or {}), timeout=min(6, int(cfg.get("timeout", 10) or 10)))
                    try:
                        series_name = premium_title(series.get("name") or series.get("title") or "Series", cfg.get("clean_titles", True))
                        poster = _local_art_only(series)
                        try:
                            seasons = call_compatible(
                                client.series_seasons,
                                (((series,), {"cancel_event":handle.cancel_event}), ((series, handle.cancel_event), {}), ((series,), {})),
                            ) or []
                        except Exception:
                            seasons = []
                        rows = []
                        for season in seasons:
                            if handle.cancelled():
                                break
                            try:
                                episodes = call_compatible(
                                    client.series_episodes,
                                    (((series, season), {"cancel_event":handle.cancel_event}), ((series, season, handle.cancel_event), {}), ((series, season), {})),
                                ) or []
                            except Exception:
                                episodes = []
                            try: season_no = int((season or {}).get("season") or (season or {}).get("season_id") or 0)
                            except Exception: season_no = 0
                            for pos, episode in enumerate(episodes, 1):
                                if not isinstance(episode, dict) or not (episode.get("cmd") or episode.get("command") or episode.get("url")):
                                    continue
                                row = dict(episode)
                                try: ep_no = int(row.get("episode_num") or row.get("episode") or row.get("number") or pos)
                                except Exception: ep_no = pos
                                try: s_no = int(row.get("season") or season_no or 0)
                                except Exception: s_no = season_no or 0
                                row["_receiver_name"] = "%s - S%02dE%02d" % (series_name, s_no, ep_no)
                                row["_receiver_media_type"] = "episode"
                                if poster:
                                    row["_receiver_picon_local"] = poster
                                rows.append(row)
                        return {"name": series_name, "poster": poster, "episodes": rows}
                    finally:
                        try: client.close()
                        except Exception: pass

                groups = []
                workers = max(1, min(4, len(series_items)))
                pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="ultrastalker-series-export")
                try:
                    futures = [pool.submit(fetch_series, series) for series in series_items]
                    for future in as_completed(futures):
                        if handle.cancelled():
                            break
                        try:
                            group = future.result()
                        except Exception:
                            group = None
                        if isinstance(group, dict) and group.get("episodes"):
                            groups.append(group)
                finally:
                    pool.shutdown(wait=False)
                if handle.cancelled():
                    return {}
                if not groups:
                    raise RuntimeError(_("No playable episodes were found"))
                # Preserve the provider/category order rather than completion order.
                order = {premium_title(x.get("name") or x.get("title") or "Series", cfg.get("clean_titles", True)): n for n, x in enumerate(series_items)}
                groups.sort(key=lambda g: order.get(g.get("name"), 999999))
                return export_series_category_bouquets(self.profile, groups, category_name, category_id, cfg.get("service_type", 4097))
            finally:
                try: isolated.close()
                except Exception: pass

        def ok(result):
            try: self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception: pass
            reload_bouquets()
            count = int((result or {}).get("items") or 0)
            series_count = int((result or {}).get("series") or 0)
            if media_type == "series":
                self["status"].setText(_("Series folder sent • %d series") % series_count)
                self.session.open(MessageBox, _("Series folder exported.\n\n%s\n%d series • %d episodes") % (category_name, series_count, count), MessageBox.TYPE_INFO, timeout=10)
            else:
                self["status"].setText(_("Movies folder sent • %d movie(s)") % count)
                self.session.open(MessageBox, _("Movies folder exported.\n\n%s\n%d movie(s)") % (category_name, count), MessageBox.TYPE_INFO, timeout=10)

        def failed(exc):
            try: self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception: pass
            self["status"].setText(_("Folder export failed: %s") % exc)

        self._run_async(work, ok, failed)

    def _history_action(self,action):
        idx=self["list"].getSelectedIndex()
        if not (0<=idx<len(self.content_items)):return
        item=self.content_items[idx];media_type=item.get("_saved_media_type") or self.media_type or "vod"
        clean=dict(item);clean.pop("_saved_media_type",None);clean.pop("_history_position",None);clean.pop("_history_duration",None);clean.pop("_history_completed",None)
        try:
            if action=="remove_history":remove_from_history(self.profile,media_type,clean);message=_("Removed from Continue Watching")
            else:mark_watched(self.profile,media_type,clean,action=="mark_watched");message=_("Marked watched") if action=="mark_watched" else _("Marked unwatched")
            self._show_saved_entries(load_continue_watching(),"Continue Watching");self["status"].setText(message)
        except Exception as exc:self["status"].setText(_("History update failed: %s")%exc)

    def _clear_history_confirmed(self,answer):
        if not answer:return
        try:clear_history(self.profile);self._show_saved_entries([],"Continue Watching");self["status"].setText(_("Continue Watching cleared"))
        except Exception as exc:self["status"].setText(_("Clear failed: %s")%exc)

    def show_selected_epg(self):
        if self.level != "items" or self.media_type != "itv":
            self["status"].setText(_("EPG is available for live channels"))
            return
        idx = self["list"].getSelectedIndex()
        if not (0 <= idx < len(self.content_items)):
            return
        item = self.content_items[idx]
        channel_id = item.get("id") or item.get("ch_id")
        if not channel_id:
            self["status"].setText(_("Channel has no EPG identifier"))
            return
        self._epg_record_channel = dict(item)
        self["status"].setText(_("Loading EPG..."))
        now = int(time.time())
        hours = int(load_settings().get("epg_hours", 4) or 4)
        def ok(rows):
            choices=[]
            for row in rows[:40]:
                if not isinstance(row, dict):
                    continue
                title=_clean_display_text(row.get("name") or row.get("title") or row.get("descr") or "Programme", 100)
                begin,end=event_times(row)
                if begin:
                    stamp=time.strftime("%H:%M",time.localtime(begin))
                    if end:
                        stamp += "–" + time.strftime("%H:%M",time.localtime(end))
                else:
                    stamp=_clean_display_text(row.get("time") or row.get("start") or "",24)
                choices.append(((stamp+"  "+title).strip(), row))
            if not choices:
                self.session.open(MessageBox,_("No EPG data returned"),MessageBox.TYPE_INFO,timeout=8)
                self["status"].setText(_("Ready"))
                return
            self.session.openWithCallback(self._epg_program_selected,ChoiceBox,title=_("EPG • choose a programme"),list=choices)
            self["status"].setText(_("Choose a programme"))
        self._run_async(
            lambda: self.client.full_epg(channel_id, now - 3600, now + (hours * 3600), max_pages=120),
            ok, lambda e: self["status"].setText(_("EPG failed: %s") % e)
        )

    def _epg_program_selected(self, choice):
        if not choice or not isinstance(choice[1], dict):
            self["status"].setText(_("Ready"))
            return
        self._selected_epg_program = dict(choice[1])
        self.session.openWithCallback(
            self._epg_program_action, ChoiceBox, title=str(choice[0])[:120],
            list=[(_("Record this programme"), "record"), (_("Programme details"), "details")],
        )

    def _epg_program_action(self, choice):
        if not choice:
            return
        program=getattr(self,"_selected_epg_program",{}) or {}
        channel=getattr(self,"_epg_record_channel",{}) or {}
        if choice[1] == "details":
            title=str(program.get("name") or program.get("title") or program.get("descr") or "Programme")
            description=str(program.get("description") or program.get("descr") or program.get("plot") or "No programme description")
            self.session.open(MessageBox,title+"\n\n"+description,MessageBox.TYPE_INFO,timeout=15)
            return
        if choice[1] != "record":
            return
        self["status"].setText(_("Preparing recording timer..."))
        cfg=load_settings()
        def work():
            return prepare_portal_recording(self.profile,channel,program,cfg.get("service_type",4097))
        def installed(prepared):
            try:
                timer=install_recording_timer(self.session,prepared)
                begin=int(getattr(timer,"begin",prepared.get("begin",0)) or 0)
                self["status"].setText(_("Recording timer added • %s") % (time.strftime("%H:%M",time.localtime(begin)) if begin else _("scheduled")))
            except Exception as exc:
                self["status"].setText(_("Timer failed: %s") % exc)
        self._run_async(work,installed,lambda e:self["status"].setText(_("Timer failed: %s")%e))

    def open_playback_settings(self):
        cfg = load_settings()
        cache_files = 0
        cache_mb = 0.0
        try:
            names = [os.path.join(IMAGE_CACHE_DIR, x) for x in os.listdir(IMAGE_CACHE_DIR)] if hdd_read_ready(force=True) else []
            cache_files = len([x for x in names if os.path.isfile(x)])
            cache_mb = sum(os.path.getsize(x) for x in names if os.path.isfile(x)) / (1024.0 * 1024.0)
        except Exception as exc:
            optional_failure("ui", exc)
        choices = [
            (_("Playback engine  •  %s") % cfg.get("service_type", 4097), "service"),
            (_("Portal timeout  •  %ss") % cfg.get("timeout", 10), "timeout"),
            (_("EPG window  •  %sh") % cfg.get("epg_hours", 4), "epg"),
            (_("Poster loading  •  %s") % (_("ON") if cfg.get("load_images", True) else _("OFF")), "images"),
            (_("Clear image cache  •  %d files / %.1f MB") % (cache_files, cache_mb), "clear_cache"),
            (_("Visible home sections"), "sections"),
            (_("Live preview  •  %s") % (_("ON") if cfg.get("live_preview", False) else _("OFF")), "preview"),
            (_("Parental lock  •  %s") % (_("ON") if cfg.get("parental_lock", False) else _("OFF")), "parental"),
            (_("Change parental PIN"), "pin"),
            (_("Manage hidden categories"), "hidden"),
            (_("Interface  •  Nova FHD / 1920×1080"), "interface"),
            (_("Clean technical prefixes  •  %s") % (_("ON") if cfg.get("clean_titles",True) else _("OFF")), "clean_titles"),
            (_("Quality badges  •  %s") % (_("ON") if cfg.get("show_quality_badges",True) else _("OFF")), "quality_badges"),
            (_("Channel list  •  %s") % cfg.get("channel_list_mode","epg").upper(), "channel_list_mode"),
            (_("Player Engine Lock  •  ON"), "engine_lock_info"),
        ]
        self.session.openWithCallback(self._premium_setting_selected, ChoiceBox, title=_("Portal settings"), list=choices)

    def _premium_setting_selected(self, choice):
        if not choice:
            return
        action = choice[1]
        if action == "service":
            current = load_settings().get("service_type", 4097)
            choices = [("DVB / native (1)", 1), ("IPTV / GStreamer (4097)", 4097), ("GstPlayer (5001)", 5001), ("ExtePlayer3 (5002)", 5002), ("ServiceApp / DreamOS (8193)", 8193)]
            self.session.openWithCallback(self._service_type_selected, ChoiceBox, title=_("Playback service type (current: %s)") % current, list=choices)
        elif action == "timeout":
            choices = [(_("%d seconds") % x, x) for x in (5, 8, 10, 15, 20, 30)]
            self.session.openWithCallback(lambda c: self._save_numeric_setting("timeout", c), ChoiceBox, title=_("Portal timeout"), list=choices)
        elif action == "epg":
            choices = [(_("%d hours") % x, x) for x in (2, 4, 6, 8, 12, 24)]
            self.session.openWithCallback(lambda c: self._save_numeric_setting("epg_hours", c), ChoiceBox, title=_("EPG window"), list=choices)
        elif action in ("clean_titles", "quality_badges", "remember_location"):
            key = {"quality_badges":"show_quality_badges"}.get(action, action)
            enabled = not bool(load_settings().get(key, True)); save_settings({key: enabled})
            self["status"].setText(_("Setting updated"))
            self.refresh_current()
        elif action == "engine_lock_info":
            self.session.open(MessageBox,_("Playback engine is locked to the value selected under Playback engine. Automatic Smart Engine switching is disabled."),MessageBox.TYPE_INFO,timeout=7)
        elif action == "channel_list_mode":
            modes=[(_("Professional EPG"),"epg"),(_("Compact"),"compact"),(_("Large"),"large")]
            self.session.openWithCallback(self._channel_mode_selected, ChoiceBox, title=_("Channel list layout"), list=modes)
        elif action == "images":
            enabled = not bool(load_settings().get("load_images", True))
            save_settings({"load_images": enabled})
            self._image_load_images=bool(enabled);self._selection_cfg_mono=0.0
            self["status"].setText(_("Poster loading enabled") if enabled else _("Poster loading disabled"))
        elif action == "clear_cache":
            removed = cleanup_image_cache(max_files=0, max_bytes=0)
            try: prune_persistent_cache(0)
            except Exception as exc: optional_failure("cache-prune", exc)
            self["status"].setText(_("Artwork + metadata cache cleaned"))
        elif action == "sections":
            self.open_section_settings()
        elif action == "preview":
            enabled=not bool(load_settings().get("live_preview",False)); save_settings({"live_preview":enabled}); self["status"].setText(_("Live preview enabled") if enabled else _("Live preview disabled"))
        elif action == "parental":
            cfg=load_settings();enabled=not bool(cfg.get("parental_lock",False))
            if enabled and parental_pin_is_default(cfg):
                self.session.openWithCallback(
                    self._save_parental_pin_and_enable,
                    InputBox,
                    title=_("Set parental PIN to enable lock (4-8 digits)"),
                    text="",
                    maxSize=8,
                    type=Input.PIN,
                )
                return
            save_settings({"parental_lock":enabled})
            parental_lock_now()
            self["status"].setText(_("Parental lock enabled") if enabled else _("Parental lock disabled"))
            self.refresh_current()
        elif action == "pin":
            self.session.openWithCallback(self._save_parental_pin, InputBox, title=_("New parental PIN (4-8 digits)"), text="", maxSize=8, type=Input.PIN)
        elif action == "hidden":
            self.show_hidden_categories()
        elif action == "interface":
            self.session.open(MessageBox, _("Nova FHD is the only interface in this build. All plugin screens use the same 1920×1080 design system."), MessageBox.TYPE_INFO, timeout=8)

    def _save_numeric_setting(self, key, choice):
        if choice:
            save_settings({key: int(choice[1])})
            self["status"].setText(_("Setting saved"))

    def _browser_theme_selected(self, choice):
        if choice:
            save_theme(choice[1])
            self["status"].setText(_("Theme saved. Restart Enigma2 to apply"))

    def _channel_mode_selected(self, choice):
        if choice:
            save_settings({"channel_list_mode": choice[1]}); self["status"].setText(_("Channel layout saved: %s") % choice[0])
            self.refresh_current()

    def _service_type_selected(self, choice):
        if choice:
            save_settings({"service_type": int(choice[1])})
            self["status"].setText(_("Playback service type saved: %s") % choice[1])

    def _hide_favorite_cards(self):
        for _fi in range(7):
            for _name in ("fav_card%d"%_fi,"fav_sel%d"%_fi,"fav_art%d"%_fi,"fav_title%d"%_fi,"fav_meta%d"%_fi):
                try:self[_name].hide()
                except Exception:pass

    def _favorite_poster_path(self, media_type, item):
        """Return the exact Poster Grid 206x310 derivative plus its source."""
        try:
            snap=load_detail_snapshot(self.profile,media_type,item) or {}
            bundle=_load_visual_bundle(self.profile,media_type,item,snap) or {}
            poster=str(bundle.get("poster") or snap.get("poster_local") or "")
            thumb=str(bundle.get("grid_thumb") or "")
            if thumb and os.path.isfile(thumb):return thumb,poster or thumb,bundle,snap
            if poster and os.path.isfile(poster):
                key=hashlib.sha1((poster+"|favorite-grid-206x310-v2").encode("utf-8","ignore")).hexdigest()[:20]
                out=os.path.join(IMAGE_CACHE_DIR,"favorite_grid_%s.png"%key)
                if not os.path.isfile(out):_build_cover_thumbnail(poster,out,(206,310))
                if os.path.isfile(out):
                    try:_save_visual_bundle(self.profile,media_type,item,{"grid_thumb":out},snapshot=snap)
                    except Exception:pass
                    return out,poster,bundle,snap
        except Exception as exc:optional_failure("ui.favorite_grid_art",exc)
        ph=asset("grid_placeholder_series_921.png" if media_type=="series" else "grid_placeholder_movie_921.png")
        return ph,ph,{},{}

    def _render_favorite_cards(self):
        entries=list(getattr(self,"_favorite_card_entries",[]) or [])
        total=len(entries)
        if total<=0:self._hide_favorite_cards();return
        self._favorite_card_index=max(0,min(int(self._favorite_card_index),total-1))
        start=(self._favorite_card_index//7)*7;self._favorite_card_page=start
        for slot in range(7):
            pos=start+slot
            if pos>=total:
                for n in ("fav_card%d"%slot,"fav_sel%d"%slot,"fav_art%d"%slot,"fav_title%d"%slot,"fav_meta%d"%slot):
                    try:self[n].hide()
                    except Exception:pass
                continue
            entry=entries[pos];item=entry.get("item") or {};mt=str(entry.get("media_type") or "vod");selected=(pos==self._favorite_card_index)
            art,poster,bundle,snap=self._favorite_poster_path(mt,item)
            try:
                card=str((bundle or {}).get("grid_card") or "")
                if not (card and os.path.isfile(card)) and poster and os.path.isfile(poster) and "placeholder" not in os.path.basename(poster).casefold():
                    card=str(_grid_card_chrome_from_poster(poster,selected=False) or "")
                    if card:
                        try:_save_visual_bundle(self.profile,mt,item,{"grid_card":card},snapshot=snap)
                        except Exception:pass
                if not (card and os.path.isfile(card)):card=asset("poster_card_full_neutral_small.png")
                self["fav_card%d"%slot].instance.setPixmapFromFile(card);self["fav_card%d"%slot].show()
            except Exception:pass
            try:
                if art and os.path.isfile(art):self["fav_art%d"%slot].instance.setPixmapFromFile(art);self["fav_art%d"%slot].show()
            except Exception:pass
            try:
                self["fav_sel%d"%slot].hide()
                if selected and poster and os.path.isfile(poster) and "placeholder" not in os.path.basename(poster).casefold():
                    laser=str((bundle or {}).get("grid_selection") or "")
                    if not (laser and os.path.isfile(laser)):
                        laser=str(_grid_selection_asset_from_poster(poster) or "")
                        if laser:
                            try:_save_visual_bundle(self.profile,mt,item,{"grid_selection":laser},snapshot=snap)
                            except Exception:pass
                    if laser and os.path.isfile(laser):self["fav_sel%d"%slot].instance.setPixmapFromFile(laser);self["fav_sel%d"%slot].show()
            except Exception:pass
            title=_clean_display_text(item.get("name") or item.get("title") or "Item",44);year=str(item.get("year") or item.get("release_date") or item.get("releasedate") or "")[:4]
            try:self["fav_title%d"%slot].setText(title);self["fav_title%d"%slot].show()
            except Exception:pass
            try:self["fav_meta%d"%slot].setText((_("SERIES") if mt=="series" else (_("LIVE") if mt=="itv" else _("MOVIE")))+(" • "+year if year else ""));self["fav_meta%d"%slot].show()
            except Exception:pass
        self["counter"].setText(_("%d items • %d/%d")%(total,self._favorite_card_index+1,total))

    def _favorite_move(self, delta):
        total=len(getattr(self,"_favorite_card_entries",[]) or [])
        if total<=0:return
        self._favorite_card_index=(self._favorite_card_index+int(delta))%total
        self._render_favorite_cards()

    def _open_favorite_card(self):
        entries=list(getattr(self,"_favorite_card_entries",[]) or [])
        if not entries:return
        entry=entries[max(0,min(self._favorite_card_index,len(entries)-1))]
        item=entry.get("item") or {};mt=str(entry.get("media_type") or "vod")
        if mt=="itv":
            old=self.media_type;self.media_type="itv";self.play_item(item);self.media_type=old
        else:
            self.session.openWithCallback(self._favorite_child_returned,ContentDetailsScreen,self.profile,self.client,mt,item)

    def _favorite_child_returned(self, result=None):
        if getattr(self,"level",None)!="favorites_cards":return
        try:self._apply_utility_glass_mode()
        except Exception:pass
        try:self._load_category_backdrop();self["page_adaptive_bg"].show()
        except Exception:pass
        self._render_favorite_cards()

    def _show_saved_entries(self, entries, title):
        if str(title).lower()=="favorites":
            self.level="favorites"
            self._apply_utility_glass_mode()
        self._set_list_density("itv" if (self.media_type == "itv") else "compact")
        portal = str(self.profile.get("portal") or "").rstrip("/").lower()
        matching = [x for x in entries if str(x.get("portal") or "").rstrip("/").lower() == portal and isinstance(x.get("item"), dict)]
        if str(title).lower()=="favorites":
            self._favorite_card_entries=list(matching);self._favorite_card_index=0;self.level="favorites_cards"
            try:self["list"].hide()
            except Exception:pass
            for n in ("preview","accent_frame","info_card1","info_card2","info_card3","info_icon1","info_icon2","info_icon3","info_title","info"):
                try:self[n].hide()
                except Exception:pass
            self["section"].setText(_("Favorites"));self["status"].setText(_("LEFT / RIGHT browse  •  OK open / play"))
            self._render_favorite_cards();return
        self._hide_favorite_cards()
        self.content_items = []
        for entry in matching:
            saved_item = dict(entry["item"])
            saved_item["_saved_media_type"] = entry.get("media_type") or "vod"
            saved_item["_history_position"] = int(entry.get("_position") or 0)
            saved_item["_history_duration"] = int(entry.get("_duration") or 0)
            saved_item["_history_completed"] = bool(entry.get("_completed"))
            self.content_items.append(saved_item)
        self.all_content_items = list(self.content_items)
        self.media_type = matching[0].get("media_type") if matching else "vod"
        self.level = "items"
        rows = []
        for entry in matching:
            item = entry["item"]
            media_type = entry.get("media_type") or "vod"
            title_text = _clean_display_text(item.get("name") or item.get("title") or item.get("id") or "Item", 120)
            icon = "ico_channel_x.png" if media_type == "itv" else ("ico_movies_x.png" if media_type == "vod" else "ico_series_x.png")
            position=int(entry.get("_position") or 0);duration=int(entry.get("_duration") or 0);completed=bool(entry.get("_completed"))
            meta=self._mode_name(media_type)
            if completed: meta += "  •  " + _("WATCHED")
            elif position and duration: meta += "  •  %d%%" % min(99,int(position*100.0/duration))
            elif position: meta += "  •  " + _("RESUME")
            rows.append((title_text, asset(icon), item, meta))
        if not rows:
            rows = [(_("No saved content"), asset("us89_folder_yellow_42.png"), None, {"meta":title,"row_asset":_neutral_utility_glass().get("utility_row"),"row_selected_asset":_neutral_utility_glass().get("utility_selected")})]
        self["list"].set_icon_rows(rows)
        self["section"].setText(title)
        self["counter"].setText(_("%d items") % len(matching))
        self["status"].setText(_("MENU: tools  •  OK: open / play"))
        self._selection_changed()

    def _show_skeleton(self, label="Loading premium content"):
        """Keep browser loading visually clean.

        us199: never render fake category/content rows, the Enigma2 default
        red selection bar or a temporary scrollbar while portal data is still
        arriving.  The premium page stays calm, then the real rows appear in
        one reveal when the request completes.
        """
        self["counter"].setText(_("Loading"))
        try:self["list"].hide()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        for name in ("accent_frame","preview","info_card1","info_card2","info_card3","info_icon1","info_icon2","info_icon3","info_title","info"):
            try:self[name].hide()
            except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _reveal_browser_content(self):
        """Reveal real Browser content after portal rows are ready.

        Categories are intentionally special: only their floating rail is
        revealed.  Re-showing the generic preview/info widgets here was the
        reason the large section icon survived on the right in Test12.
        """
        if self.level == "genres":
            try:self["list"].show()
            except Exception as exc:optional_failure("ui.silent_guard",exc)
            self._set_category_clean_visibility(True)
            try:self["page_adaptive_bg"].show()
            except Exception as exc:optional_failure("ui.silent_guard",exc)
            return
        for name in ("list","preview","info_title","info"):
            try:self[name].show()
            except Exception as exc:optional_failure("ui.silent_guard",exc)

    def open_search(self):
        if self.level != "items" or not self.content_items:
            self["status"].setText(_("Search is available inside content lists"))
            return
        recent = _load_recent_searches()
        prompt = "Search content" + (("  •  Recent: " + ", ".join(recent[:3])) if recent else "")
        self.session.openWithCallback(self._search_done, InputBox, title=prompt, text="", maxSize=60)

    def _search_done(self, term):
        self._set_list_density("itv" if (self.media_type == "itv") else "compact")
        term = str(term or "").strip()
        if not term: return
        _save_recent_search(term)
        q = _search_key(term)
        rows=[]
        icon="ico_channel_x.png" if self.media_type=="itv" else ("ico_movies_x.png" if self.media_type=="vod" else "ico_series_x.png")
        source = getattr(self, "all_content_items", self.content_items)
        indexed = getattr(self, "_content_search_index", None)
        if not indexed or len(indexed) != len(source):
            indexed = [(_search_key(e.get("name") or e.get("title") or ""), e) for e in source]
            self._content_search_index = indexed
        self._filtered_items=[e for key, e in indexed if q in key]
        self.content_items = list(self._filtered_items)
        for e in self._filtered_items:
            title=str(e.get("name") or e.get("title") or e.get("id") or "Item")
            sec=str(e.get("year") or e.get("number") or e.get("genre") or "")
            rows.append((title,asset(icon),e,sec))
        if not rows: rows=[(_("No search results"),asset(icon),None,term)]
        self["list"].set_icon_rows(rows)
        self["counter"].setText(_("%d results") % len(self._filtered_items))
        self["section"].setText(_("%s  /  Search: %s") % (self._mode_name(self.media_type), term[:30]))
        self["status"].setText(_("MENU: new search  •  BLUE: restore list"))

    def back(self):
        # Category loading is asynchronous, but the clean Categories skin hides
        # the normal status label.  Historically BACK was blocked by _busy here,
        # which made a slow/dead portal request look like a frozen receiver.
        # BACK must always be a hard escape from the loading-only Categories
        # surface: cancel only this screen request and return immediately.
        if self._busy and self.level == "genres_loading":
            self._cancel_active_async()
            self.close() if self._home_entry else self._show_root()
            return
        # Catch-up is network-heavy on some portals. BACK is a hard UI escape:
        # cancel the request immediately and never force the viewer to wait for
        # a portal timeout or a multi-page scan to finish.
        if self._busy and str(self.level).startswith("catchup"):
            self._cancel_active_async()
            if self.level in ("catchup_programs_loading","catchup_programs"):
                self.level="catchup_channels"
                if getattr(self,"_catchup_channels_cache",None):
                    valid=list(self._catchup_channels_cache)
                    self.content_items=valid; self.all_content_items=list(valid)
                    menu=[(str(x.get("name") or x.get("title") or _("Channel")),asset("ico_channel_x.png"),x,_('Archive')) for x in valid]
                    self["list"].set_icon_rows(menu);self["section"].setText(_("Catch-up TV  /  Channels"));self["counter"].setText(_("%d channels")%len(valid));self["status"].setText(_("Ready"));self._selection_changed();return
            self.close() if self._home_entry else self._show_root()
            return
        if self._busy: self["status"].setText(_("Please wait")); return
        if self.level=="root": self.close()
        elif self.level=="catchup_programs": self.load_catchup_channels()
        elif self.level=="catchup_channels":
            self.close() if self._home_entry else self._show_root()
        elif self.level=="items":
            if self._home_entry and self.initial_action in ("favorites", "recent"):
                self.close()
            else:
                self.load_genres(self.media_type)
        else:
            self.close() if self._home_entry else self._show_root()

    def _show_root(self):
        self.level="root"; self.media_type=None; self.genre=None; self.content_items=[]
        self._set_root_rows(); self["section"].setText(self.profile.get("portal","")); self["counter"].setText(_("PORTAL HOME  •  %d sections") % len(self.MODES))
        self["info_title"].setText(_("Choose a section")); self["info"].setText(_("Live, Movies, Series, Favorites and Continue Watching"))
        self._decode_picture(asset("placeholder_live_x.png")); self["status"].setText(_("Ready"))

    def reauthorize(self):
        if self._busy: return
        self["status"].setText(_("Reauthorizing..."))
        def work(): self.client.token=None; return self.client.authorize()
        self._run_async(work,lambda _result:self["status"].setText(_("Authorized")),lambda e:self["status"].setText(str(e)))

    def refresh_current(self):
        if self.level=="catchup_programs" and self.catchup_channel: self.load_catchup_programs(self.catchup_channel)
        elif self.level=="catchup_channels": self.load_catchup_channels()
        elif self.level=="genres": self.load_genres(self.media_type)
        elif self.level=="items": self.load_items(self.media_type,self.genre)
        else: self._show_root()

    def blue_action(self):
        if self.level=="genres" and self.media_type=="itv":
            return self.cache_all_live_picons()
        return self.select()

    def cache_all_live_picons(self):
        """Background Live picon cache with persistent failed-only retry.

        First run scans the provider and uses beta39 downloader for missing picons.
        If failures remain, the next blue-button press retries ONLY that persistent
        failed queue; it does not enumerate all Live categories again.
        """
        if self._live_picon_cache_running:
            self["status"].setText(_("Picon cache is already running"))
            return
        self._live_picon_cache_running=True
        profile=dict(self.profile or {})
        progress=self._live_picon_cache_progress

        # Fast path: a previous completed pass left failures. Retry those only.
        retry_rows=_load_live_picon_failed_queue(profile)
        retry_only=bool(retry_rows)
        if retry_only:
            self["blue"].setText("0 / %d"%len(retry_rows))
            self["status"].setText(_("Retrying %d failed picons only")%len(retry_rows))
        else:
            self["blue"].setText(_("Scanning..."))
            self["status"].setText(_("Scanning Live categories..."))

        genres=list(self.content_items or [])

        def work():
            isolated=None
            try:
                if retry_only:
                    rows=list(retry_rows)
                    total=len(rows)
                    _live_restart_trace("bulk_cache_retry_failed_start",total=total)
                else:
                    _live_restart_trace("bulk_cache_start",genres=len(genres))
                    isolated=_new_isolated_source_client(profile,timeout=6)
                    seen_urls=set();rows=[];skipped=0
                    total_genres=max(1,len(genres))
                    for gi,genre in enumerate(genres,1):
                        try:progress.put(("scan",gi,total_genres))
                        except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)
                        gid=str(genre.get("id") or genre.get("genre_id") or genre.get("name") or "*")
                        try:
                            batch=call_compatible(
                                isolated.ordered_all,
                                ((("itv",gid), {"start_page":1,"max_pages":500,"max_items":20000,"cancel_event":None}),
                                 (("itv",gid,1,500,20000,None), {})),
                            ) or []
                        except Exception:
                            batch=[]
                        for item in batch:
                            if not isinstance(item,dict):
                                skipped+=1;continue
                            raw=str(_image_url(item) or "")
                            if not raw:
                                skipped+=1;continue
                            try:
                                resolved=_normalize_provider_image_url(_source_art_url(raw,profile,item))
                                parts=urllib.parse.urlsplit(resolved or "")
                                if parts.scheme not in ("http","https") or not parts.hostname:
                                    skipped+=1;continue
                            except Exception:
                                skipped+=1;continue
                            if resolved in seen_urls:continue
                            seen_urls.add(resolved)
                            rows.append((item,resolved))
                    total=len(rows)

                if not total:
                    _save_live_picon_failed_queue(profile,[])
                    progress.put(("done",0,0,0,0,0))
                    _live_restart_trace("bulk_cache_done",done=0,total=0,cached=0,downloaded=0,failed=0)
                    return

                # TRUE RESUME remains for a normal/full pass. On failed-only retry
                # the visible total is intentionally only the failed queue.
                missing=[];cached=0
                for item,resolved in rows:
                    existing=_cached_live_picon_path(resolved,profile,item)
                    if existing:
                        cached+=1
                    else:
                        missing.append((item,resolved))

                done=cached;downloaded=0;failed=0
                try:progress.put(("cache",done,total,cached,downloaded,failed))
                except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)
                _live_restart_trace("bulk_cache_resume",done=done,total=total,cached=cached,missing=len(missing),retry_only=retry_only)

                if not missing:
                    _save_live_picon_failed_queue(profile,[])
                    progress.put(("done",done,total,cached,downloaded,failed))
                    _live_restart_trace("bulk_cache_done",done=done,total=total,cached=cached,downloaded=0,failed=0,retry_only=retry_only)
                    return

                # IMPORTANT: original beta39 downloader path remains unchanged.
                def one(pair):
                    item,resolved=pair
                    existing=_cached_live_picon_path(resolved,profile,item)
                    if existing:return ("cached",existing,pair)
                    path=_download_public_live_picon(resolved,profile,item=item,timeout=4.0)
                    return ("downloaded",path,pair) if path else ("failed",None,pair)

                failed_rows=[]
                pool=ThreadPoolExecutor(max_workers=2,thread_name_prefix="ultra-picon-cache")
                futures=[pool.submit(one,pair) for pair in missing]
                try:
                    for future in as_completed(futures):
                        pair=None
                        try:
                            state,path,pair=future.result()
                        except Exception:
                            state="failed";path=None
                        if state=="cached":cached+=1
                        elif state=="downloaded":downloaded+=1
                        else:
                            failed+=1
                            if pair is not None: failed_rows.append(pair)
                        done+=1
                        try:progress.put(("cache",done,total,cached,downloaded,failed))
                        except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)
                        if done%100==0 or done==total:
                            _live_restart_trace("bulk_cache_progress",done=done,total=total,cached=cached,downloaded=downloaded,failed=failed,retry_only=retry_only)
                finally:
                    try:pool.shutdown(wait=True,cancel_futures=True)
                    except TypeError:pool.shutdown(wait=True)

                # Persist ONLY unresolved failures. Next press starts here directly.
                _save_live_picon_failed_queue(profile,failed_rows)
                progress.put(("done",done,total,cached,downloaded,failed))
                _live_restart_trace("bulk_cache_done",done=done,total=total,cached=cached,downloaded=downloaded,failed=failed,retry_only=retry_only)
            except Exception as exc:
                _live_restart_trace("bulk_cache_error",error=repr(exc),retry_only=retry_only)
                try:progress.put(("error",_friendly_error(exc)))
                except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)
            finally:
                if isolated is not None:
                    try:isolated.close()
                    except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)

        try:
            self._live_picon_cache_future=_PICON_CACHE_EXECUTOR.submit(work)
        except Exception as exc:
            self._live_picon_cache_running=False
            self["blue"].setText(_("Cache Picons"))
            self["status"].setText(_friendly_error(exc))

    def select(self):
        if self._busy: return
        if self.level=="favorites_cards":return self._open_favorite_card()
        idx=self["list"].getSelectedIndex()
        if self.level=="root" and 0 <= idx < len(self.MODES):
            action = self.MODES[idx][1]
            if action in ("itv", "vod", "series"):
                self._open_media_with_parental(action)
            elif action == "catchup":
                self.load_catchup_channels()
            elif action == "favorites":
                self._show_saved_entries(load_favorites(), "Favorites")
            elif action == "recent":
                self._show_saved_entries(load_continue_watching(), "Continue Watching")
            elif action == "account":
                self.show_account_info()
            elif action == "search":
                self.open_global_search()
            elif action == "settings":
                self.open_playback_settings()
        elif self.level=="genres" and 0 <= idx < len(self.content_items):
            self._open_genre_with_parental(self.content_items[idx], idx)
        elif self.level=="catchup_channels" and 0 <= idx < len(self.content_items):
            self.load_catchup_programs(self.content_items[idx])
        elif self.level=="catchup_programs" and 0 <= idx < len(self.content_items):
            self.play_catchup_program(self.content_items[idx])
        elif self.level=="items" and 0 <= idx < len(self.content_items):
            item=self.content_items[idx]
            selected_type = item.get("_saved_media_type") or self.media_type
            if selected_type=="itv":
                previous_type = self.media_type; self.media_type = selected_type
                self.play_item(item); self.media_type = previous_type
            else: self.session.openWithCallback(lambda result=None:self._restore_current_list_selection(),ContentDetailsScreen,self.profile,self.client,selected_type,item)

    def _restore_current_list_selection(self):
        """Keep the exact list row selected after returning from details."""
        try:self._selection_changed()
        except Exception as exc:optional_failure("ui",exc)

    def _grid_returned(self, result=None):
        """Keep the selected category after leaving its poster/live grid."""
        try:self._selection_changed()
        except Exception as exc:optional_failure("ui",exc)
        # Initial grid loads that exhaust their bounded self-heal return here
        # instead of stranding the viewer on an empty child screen.
        try:
            if isinstance(result,(tuple,list)) and len(result)>=2 and result[0]=="content_load_error":
                self["status"].setText(str(result[1] or _("Content temporarily unavailable. Try again.")))
        except Exception as exc:optional_failure("ui.grid_return_error_status",exc)

    def load_genres(self, media_type):
        if self._busy:return
        # Enter the final Categories surface before any network/cache wait.
        self.media_type = media_type
        self.level = "genres_loading"
        self._apply_category_portal_geometry()
        self._load_category_backdrop()
        try:self["list"].hide()
        except Exception as exc:optional_failure("ui.category_loading_list_hide", exc)
        try:self.client.reset_failure_backoff()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._set_list_density("genres")
        cached = _category_cache_get(self.profile, media_type)
        if cached is None:
            self["status"].setText(_("Loading categories..."))
            self._show_skeleton("Loading categories")
        def ok(genres,persist=True):
            if persist and isinstance(genres, list):
                _category_cache_put(self.profile, media_type, genres)
            valid=[e for e in genres if isinstance(e,dict)] if isinstance(genres, list) else []
            cfg=load_settings(); hidden=set(cfg.get("hidden_categories",{}).get(media_type,[])); protected=set(cfg.get("protected_categories",{}).get(media_type,[])); words=cfg.get("adult_keywords",[])
            def gid(e): return str(e.get("id") or e.get("genre_id") or e.get("name") or e.get("title") or "")
            def adult(e):
                text=str(e.get("name") or e.get("title") or "").casefold();return any(w in text for w in words)
            filtered=[]
            for e in valid:
                if gid(e) in hidden: continue
                sensitive=(gid(e) in protected or adult(e))
                if cfg.get("parental_lock") and cfg.get("parental_mode","pin")=="hide" and sensitive: continue
                if (not cfg.get("parental_lock")) and cfg.get("hide_adult",True) and adult(e): continue
                filtered.append(e)
            valid=filtered
            if not valid:
                if media_type == "itv":
                    screen = PremiumLiveGridScreen
                else:
                    view_key="movies_view_mode" if media_type=="vod" else "series_view_mode"
                    view_mode=str(cfg.get(view_key) or "poster").lower()
                    screen=PremiumGlobalCinematicScreen if view_mode=="cinematic" else (PremiumBackdropGrid2Screen if view_mode=="backdrop2" else (PremiumBackdropGridScreen if view_mode=="backdrop" else (PremiumPosterGridScreen if view_mode=="poster_legacy" else PremiumPosterGridV2Screen)))
                self.session.openWithCallback(self._grid_returned, screen, self.profile, self.client, media_type, "*", self._mode_name(media_type))
                return
            pinned=set(cfg.get("pinned_categories",{}).get(media_type,[])); empty=set(cfg.get("empty_categories",{}).get(media_type,[]))
            if cfg.get("hide_empty_categories",True): valid=[e for e in valid if gid(e) not in empty]
            # Preserve the exact order returned by the portal. Pinned categories
            # keep their visual star but no longer jump ahead of portal order.
            self.media_type=media_type; self.content_items=valid; self.level="genres"
            # One measurement across the complete category list.  Paging through
            # groups of 14 must never change the row width.
            self._prepare_category_global_geometry(valid,cfg)
            # Never reuse adaptive assets from the previously opened media family.
            # Series/Movies/Live must each rebuild/resolve their own page mood.
            self._category_chrome = {}
            self._apply_category_portal_geometry()
            self._load_category_chrome()
            self["section"].setText(_("%s  /  Categories") % self._mode_name(media_type))
            try:self["list"].moveToIndex(0)
            except Exception as exc:optional_failure("ui",exc)
            self._render_genre_rows()
            self._reveal_browser_content()
            self["blue"].setText(_("Cache Picons") if media_type=="itv" else _("Open / Play"))
            self["counter"].setText(_("%d categories") % len(valid)); self["status"].setText(_("Ready")); self._apply_browser_status_color(); self._selection_changed()
        # Last-good categories are first-paint truth.  A stale HDD/RAM row is
        # shown immediately, then refreshed silently in-place; a transient
        # Stalker failure can therefore never replace useful categories with a
        # blank backdrop.  Fresh hot-cache rows need no network request.
        cached_painted = cached is not None
        if cached_painted:
            ok(cached,persist=False)
            # Never mark the screen busy after last-good first paint. Refresh a
            # stale catalogue on an isolated client so OK/navigation remains
            # instant and the shared Portal transport is not disturbed.
            try:
                stale=_category_cache_age(self.profile,media_type) > _CATEGORY_CACHE_TTL
            except Exception:
                stale=False
            if stale:
                profile_copy=dict(self.profile or {});media_copy=str(media_type or "")
                def refresh_last_good():
                    isolated=None
                    try:
                        isolated=_new_isolated_source_client(profile_copy,timeout=6)
                        rows=isolated.genres(media_copy)
                        if isinstance(rows,list) and rows:_category_cache_put(profile_copy,media_copy,rows)
                    except Exception as exc:
                        optional_failure("ui.category_last_good_refresh",exc)
                    finally:
                        try:
                            close_pending=getattr(isolated,"cancel_pending_requests",None)
                            if callable(close_pending):close_pending()
                        except Exception:pass
                try:_CATEGORY_PREFETCH_EXECUTOR.submit(refresh_last_good)
                except Exception as exc:optional_failure("ui.category_last_good_refresh_submit",exc)
            return

        def load_categories_resilient(handle):
            """Recover transient category failures inside the same screen.

            Several MAG/Stalker portals intermittently return HTML/non-JSON or
            drop the first keep-alive request even though the very next manual
            re-entry succeeds.  Requiring the viewer to BACK/enter three or four
            times is pointless.  Keep recovery local to Categories: retry on a
            fresh transport, refresh authorization once, and only expose the
            error screen after all bounded attempts are exhausted.
            """
            cancel_event = getattr(handle, "cancel_event", None)
            last_error = None
            # First try is immediate. Subsequent waits are deliberately short so
            # a healthy portal still feels instant while flaky loaders self-heal.
            retry_delays = (0.0, 0.22, 0.55, 0.90)
            for attempt, delay in enumerate(retry_delays):
                if attempt:
                    if cancel_event is not None and getattr(cancel_event, "wait", lambda _x: False)(delay):
                        raise last_error or Exception("Request cancelled")
                    # A stale keep-alive socket is a common source of one-shot
                    # non-JSON/empty loader responses.  Drop only client transport
                    # state; do not alter portal/profile data or UI state.
                    try:
                        close_pending = getattr(self.client, "cancel_pending_requests", None)
                        if callable(close_pending):
                            close_pending()
                    except Exception as exc:
                        optional_failure("ui.category_retry_transport", exc)
                    try:
                        reset_backoff = getattr(self.client, "reset_failure_backoff", None)
                        if callable(reset_backoff):
                            reset_backoff()
                    except Exception as exc:
                        optional_failure("ui.category_retry_backoff", exc)
                    # Third pass mirrors what users were effectively doing by
                    # leaving/re-entering: establish one fresh authorized portal
                    # session.  M3U/Xtream adapters simply skip this branch.
                    if attempt == 2:
                        try:
                            authorize = getattr(self.client, "authorize", None)
                            if callable(authorize):
                                authorize(cancel_event=cancel_event)
                        except TypeError:
                            try: authorize()
                            except Exception as exc: last_error = exc
                        except Exception as exc:
                            last_error = exc
                try:
                    return self.client.genres(media_type, cancel_event=cancel_event)
                except Exception as exc:
                    last_error = exc
                    low = str(exc).casefold()
                    # Security-consent failures need explicit user approval and
                    # must never be hidden behind automatic retries.
                    if any(marker in low for marker in (
                        "security consent", "fallback is not approved",
                        "certificate verification", "unapproved https"
                    )):
                        raise
                    if attempt >= len(retry_delays) - 1:
                        raise
            raise last_error or Exception("Categories could not be loaded")

        def failed(exc):
            # If a last-good catalogue is already on-screen, this was only a
            # silent refresh. Keep the useful rows and suppress transient portal
            # noise exactly like the M3U path.
            if cached_painted and self.level=="genres" and self.content_items:
                try:self["status"].setText("")
                except Exception:pass
                return
            # Never leave the viewer on a backdrop-only loading surface. Restore
            # normal Browser chrome and show the actual portal error immediately.
            self.level="root"
            self.content_items=[]
            try:self._restore_browser_geometry()
            except Exception as restore_exc:optional_failure("ui.category_error_restore",restore_exc)
            try:
                self["section"].setText(_("Categories unavailable"))
                self["status"].setText(_friendly_error(exc))
                self["counter"].setText("")
                self["list"].set_icon_rows([(_("Categories could not be loaded"),asset("placeholder_folder_x.png"),None,_friendly_error(exc))])
                self["list"].show()
            except Exception as render_exc:optional_failure("ui.category_error_render",render_exc)
        self._run_async(load_categories_resilient,ok,failed)

    def load_items(self, media_type, genre, page=1):
        if self._busy:return
        self._set_list_density("itv" if media_type == "itv" else "compact")
        self["status"].setText(_("Loading content..."))
        self._show_skeleton("Loading content")
        def ok(data):
            valid=[e for e in data if isinstance(e,dict)] if isinstance(data, list) else []
            self.media_type=media_type; self.genre=genre; self.page=max(1, int(page)); self.content_items=valid; self.all_content_items=list(valid); self.level="items"
            if not valid and genre not in (None,"","*"):
                cfg=load_settings(); empty=cfg.get("empty_categories",{}); vals=list(empty.get(media_type,[]))
                if str(genre) not in vals: vals.append(str(genre)); empty[media_type]=vals; save_settings({"empty_categories":empty})
            self._render_content_rows()
            self._reveal_browser_content()
            self["section"].setText(_("%s  /  Content") % self._mode_name(media_type))
            self["counter"].setText(_("Page %d  •  %d items") % (self.page, len(valid))); self["status"].setText(_("Ready") if valid else _("No content"))
            self._selection_changed()
        def load_items_resilient(handle):
            cancel_event=getattr(handle,"cancel_event",None);last_error=None
            delays=(0.0,0.18,0.42,0.75)
            for attempt,delay in enumerate(delays):
                if attempt:
                    if cancel_event is not None and getattr(cancel_event,"wait",lambda _x:False)(delay):
                        raise last_error or Exception("Request cancelled")
                    try:
                        close_pending=getattr(self.client,"cancel_pending_requests",None)
                        if callable(close_pending):close_pending()
                    except Exception as exc:optional_failure("ui.content_retry_transport",exc)
                    try:
                        reset=getattr(self.client,"reset_failure_backoff",None)
                        if callable(reset):reset()
                    except Exception as exc:optional_failure("ui.content_retry_backoff",exc)
                try:
                    return self.client.ordered_list(media_type,genre,page,cancel_event=cancel_event)
                except Exception as exc:
                    last_error=exc;low=str(exc).casefold()
                    if any(marker in low for marker in ("security consent","fallback is not approved","certificate verification","unapproved https")):
                        raise
                    transient=any(marker in low for marker in ("connection","timed out","timeout","non-json","invalid page","temporarily paused","remote end closed","connection reset","broken pipe","http 502","http 503","http 504"))
                    if (not transient) or attempt>=len(delays)-1:raise
            raise last_error or Exception("Content could not be loaded")
        def failed_items(error):
            low=str(error).casefold()
            transient=any(marker in low for marker in ("connection","timed out","timeout","non-json","invalid page","temporarily paused","remote end closed","connection reset","broken pipe","http 502","http 503","http 504"))
            message=_("Content temporarily unavailable. Try again.") if transient else _friendly_error(error)
            # A failed portal request must never leave the Browser on its hidden
            # loading skeleton.  If this was a refresh of an already-painted
            # list, keep that last-good content.  Otherwise reveal one honest
            # error row so the viewer always has a visible, escapable surface.
            if self.level=="items" and getattr(self,"content_items",None):
                try:self._reveal_browser_content()
                except Exception as exc:optional_failure("ui.content_error_reveal_last_good",exc)
                try:self["status"].setText(message)
                except Exception as exc:optional_failure("ui.content_error_status_last_good",exc)
                return
            self.media_type=media_type;self.genre=genre;self.page=max(1,int(page));self.level="items";self.content_items=[];self.all_content_items=[]
            try:
                icon="ico_channel_x.png" if media_type=="itv" else ("ico_movies_x.png" if media_type=="vod" else "ico_series_x.png")
                self["list"].set_icon_rows([(_("Content could not be loaded"),asset(icon),None,message)])
                self["section"].setText(_("%s  /  Content") % self._mode_name(media_type))
                self["counter"].setText("")
                self["status"].setText(message)
                self._reveal_browser_content()
            except Exception as exc:optional_failure("ui.content_error_render",exc)
        self._run_async(load_items_resilient,ok,failed_items)

    def _live_content_row(self, e, pos, cfg, state=None):
        state=state or {}
        raw=e.get("name") or e.get("title") or e.get("id") or "Channel"
        title=premium_title(raw,cfg.get("clean_titles",True))
        cid=str(e.get("id") or e.get("ch_id") or e.get("number") or pos)
        epg=self._epg_cache.get(cid,{})
        number=str(e.get("number") or e.get("num") or pos) if cfg.get("show_channel_numbers",True) else ""
        badges=[]
        if state.get("favorite"): badges.append("★")
        if e.get("allow_archive") or e.get("tv_archive_duration") or e.get("archive"): badges.append(_("CATCH-UP"))
        if epg.get("percent"): badges.append("%d%%"%epg["percent"])
        icon=asset(_letter_placeholder(title))
        try:
            raw_picon=_image_url(e)
            cached=_cached_live_picon_path(raw_picon,self.profile,e) if raw_picon else ""
            if cached:
                fitted=_fit_live_picon_canvas(cached,PERSISTENT_GENERATED_DIR,(60,60))
                if fitted: icon=fitted
        except Exception as exc:
            optional_failure("ui.live_row_picon_fit",exc)
        details={"number":number,"now":epg.get("now") or e.get("epg_title") or e.get("now") or _("No EPG information"),"next":epg.get("next") or "","badges":"  ".join(badges)}
        return (title,icon,e,details)

    def _render_content_rows(self, keep_index=None):
        cfg=load_settings(); rows=[]
        states=load_content_states(self.profile,self.media_type,self.content_items) if self.content_items else []
        self._content_state_cache={id(item):state for item,state in zip(self.content_items,states)}
        if self.media_type=="itv":
            self._set_list_density("itv")
            for pos,e in enumerate(self.content_items,1):
                rows.append(self._live_content_row(e,pos,cfg,self._content_state_cache.get(id(e))))
        else:
            self._set_list_density("compact")
            icon="ico_movies_x.png" if self.media_type=="vod" else "ico_series_x.png"
            for e in self.content_items:
                raw=e.get("name") or e.get("title") or e.get("id") or "Item"
                title=premium_title(raw,cfg.get("clean_titles",True)); meta=[]
                if cfg.get("show_quality_badges",True):
                    badges=quality_badges(raw)
                    if badges: meta.append(badges)
                if e.get("year"): meta.append(str(e.get("year"))[:10])
                state=self._content_state_cache.get(id(e),{})
                if state.get("favorite"): meta.append("★")
                if state.get("completed"): meta.append("WATCHED")
                elif state.get("duration") and state.get("position"):
                    meta.append("%d%%"%min(99,int(state["position"]*100.0/state["duration"])))
                rows.append((title,asset(icon),e,"  •  ".join(meta)[:36]))
        if not rows:
            icon="ico_channel_x.png" if self.media_type=="itv" else ("ico_movies_x.png" if self.media_type=="vod" else "ico_series_x.png")
            rows=[("No content returned",asset(icon),None,"Try another category")]
        self["list"].set_icon_rows(rows)
        if keep_index is not None:
            try:self["list"].moveToIndex(max(0,min(int(keep_index),len(rows)-1)))
            except Exception as exc:optional_failure("ui",exc)

    def _refresh_live_epg_row(self, index):
        if self.media_type!="itv" or not (0<=index<len(self.content_items)):return
        item=self.content_items[index];cfg=load_settings();state=getattr(self,"_content_state_cache",{}).get(id(item),{})
        self["list"].update_icon_row(index,self._live_content_row(item,index+1,cfg,state))

    def _schedule_epg_preview(self, item):
        if self.media_type!="itv" or self.level!="items" or not isinstance(item,dict): return
        cid=str(item.get("id") or item.get("ch_id") or "")
        if not cid or cid in self._epg_cache: return
        self._epg_token+=1; self._epg_pending=(self._epg_token,cid)
        # A focus change makes a queued EPG request obsolete. Running network
        # work is allowed to finish, but it no longer owns this Screen.
        future=getattr(self,"_epg_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception as exc:optional_failure("ui.browser_epg_requeue_cancel",exc)
        self._epg_future=None
        try:self._epg_timer.stop();self._epg_timer.start(350,True)
        except Exception as exc:optional_failure("ui",exc)

    def _fetch_selected_epg(self):
        pending=getattr(self,"_epg_pending",None)
        if not pending:return
        token,cid=pending
        client=self.client
        jobs=self._epg_jobs
        screen_ref=weakref.ref(self)
        def work():
            try:return (token,cid,epg_summary(client.epg(cid,4)),None)
            except Exception as exc:return (token,cid,None,exc)
        def done(fut,ref=screen_ref,result_queue=jobs):
            screen=ref()
            if screen is None or getattr(screen,"_screen_closed",False):return
            try:result_queue.put(fut.result())
            except Exception as exc:optional_failure("ui",exc)
            finally:
                if screen is not None and getattr(screen,"_epg_future",None) is fut:
                    screen._epg_future=None
        try:
            future=_GRID_EPG_EXECUTOR.submit(work)
            self._epg_future=future
            future.add_done_callback(done)
        except Exception as exc:
            self._epg_future=None
            optional_failure("ui.browser_epg_submit",exc)

    def _drain_epg_jobs(self):
        while True:
            try:token,cid,summary,error=self._epg_jobs.get_nowait()
            except queue.Empty:break
            if error is None and summary:
                self._epg_cache[cid]=summary
                try:
                    idx=self["list"].getSelectedIndex(); self._refresh_live_epg_row(idx)
                    if 0<=idx<len(self.content_items):
                        item=self.content_items[idx]; current=str(item.get("id") or item.get("ch_id") or "")
                        if current==cid:
                            now=summary.get("now") or "No current programme"
                            nxt=summary.get("next") or "No next programme"
                            self["info"].setText(("NOW: %s\nNEXT: %s"%(now,nxt))[:118])
                except Exception as exc:optional_failure("ui",exc)

    def _stop_epg_preview(self):
        future=getattr(self,"_epg_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception as exc:optional_failure("ui.browser_epg_stop_cancel",exc)
        self._epg_future=None
        try:self._epg_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._epg_timer_conn is not None:self._epg_timer_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._fetch_selected_epg in self._epg_timer.callback:self._epg_timer.callback.remove(self._fetch_selected_epg)
        except Exception as exc:optional_failure("ui.epg_callback",exc)

    def open_global_search(self):
        self.session.open(PortalGlobalSearchScreen,self.profile,self.client)

    def toggle_current_category_pinned(self):
        if self.level!="genres" or not self.media_type:
            self["status"].setText(_("Open a category list first"));return
        idx=self["list"].getSelectedIndex()
        if not (0<=idx<len(self.content_items)):return
        item=self.content_items[idx]; gid=str(item.get("id") or item.get("genre_id") or item.get("name") or item.get("title") or "")
        cfg=load_settings(); pins=cfg.get("pinned_categories",{}); values=list(pins.get(self.media_type,[]))
        if gid in values: values.remove(gid); state=_("unpinned")
        else: values.append(gid); state=_("pinned")
        pins[self.media_type]=values; save_settings({"pinned_categories":pins}); self["status"].setText(_("Category %s")%state); self.load_genres(self.media_type)

    def toggle_current_category_protected(self):
        if self.level!="genres" or not self.media_type:self["status"].setText(_("Open a category list first"));return
        idx=self["list"].getSelectedIndex()
        if not (0<=idx<len(self.content_items)):return
        item=self.content_items[idx];gid=str(item.get("id") or item.get("genre_id") or item.get("name") or item.get("title") or "")
        cfg=load_settings();protected=cfg.get("protected_categories",{});values=list(protected.get(self.media_type,[]))
        if gid in values:values.remove(gid);state=_("unprotected")
        else:values.append(gid);state=_("protected")
        protected[self.media_type]=values;save_settings({"protected_categories":protected});self["status"].setText(_("Category %s")%state);self.load_genres(self.media_type)

    def _open_media_with_parental(self, media_type):
        # Category-level protection replaces the old all-or-nothing VOD lock.
        # A cancelled Live preview/page request must never poison the next
        # Movies/Series/Live navigation action.
        try:self.client.reset_failure_backoff()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self.load_genres(media_type)

    def _category_sensitive(self, media_type, item):
        cfg=load_settings();gid=str(item.get("id") or item.get("genre_id") or item.get("name") or item.get("title") or "")
        if gid in set(cfg.get("protected_categories",{}).get(media_type,[])):return True
        text=str(item.get("name") or item.get("title") or "").casefold()
        return any(word in text for word in cfg.get("adult_keywords",[]))

    def _open_genre_with_parental(self, item, index=0):
        cfg=load_settings()
        if cfg.get("parental_lock") and cfg.get("parental_mode","pin")=="pin" and self._category_sensitive(self.media_type,item) and not parental_is_unlocked():
            self._pending_genre=(dict(item),int(index),self.media_type)
            self.session.openWithCallback(self._parental_category_pin_done,InputBox,title=_("Parental PIN"),text="",maxSize=8,type=Input.PIN);return
        self._open_genre_direct(item,index,self.media_type)

    def _open_genre_direct(self,g,index,media_type):
        genre_id=str(g.get("id") or g.get("genre_id") or g.get("category_id") or g.get("name") or g.get("title") or "*")
        category_title=_clean_display_text(g.get("title") or g.get("name") or g.get("category_name") or g.get("genre_name") or "Content",100) or "Content"
        if media_type=="itv":
            screen=PremiumLiveGridScreen
        else:
            cfg=load_settings();view_key="movies_view_mode" if media_type=="vod" else "series_view_mode"
            view_mode=str(cfg.get(view_key) or "poster").lower()
            screen=PremiumGlobalCinematicScreen if view_mode=="cinematic" else (PremiumBackdropGrid2Screen if view_mode=="backdrop2" else (PremiumBackdropGridScreen if view_mode=="backdrop" else (PremiumPosterGridScreen if view_mode=="poster_legacy" else PremiumPosterGridV2Screen)))
        self.session.openWithCallback(self._grid_returned,screen,self.profile,self.client,media_type,genre_id,category_title)

    def _parental_category_pin_done(self,value):
        if value is None:
            return
        cfg=load_settings();ok,message=parental_verify_pin(value,cfg)
        if ok:
            pending=getattr(self,"_pending_genre",None)
            if pending:self._open_genre_direct(pending[0],pending[1],pending[2])
            self._pending_genre=None
        else:
            self.session.open(MessageBox,message or _("Incorrect parental PIN"),MessageBox.TYPE_ERROR,timeout=6)

    def _save_parental_pin(self, value):
        value=str(value or "")
        if value.isdigit() and 4 <= len(value) <= 8:
            save_settings(parental_hash_pin(value))
            parental_lock_now()
            self["status"].setText(_("Parental PIN saved securely"))
            self.refresh_current()
        elif value:
            self.session.open(SettingsGlassNoticeScreen,_("Parental PIN"),_("PIN must contain 4-8 digits"),False)

    def _save_parental_pin_and_enable(self, value):
        value=str(value or "")
        if not value:
            self["status"].setText(_("Parental lock remains disabled"))
            self.refresh_current()
            return
        if not (value.isdigit() and 4 <= len(value) <= 8):
            self.session.open(SettingsGlassNoticeScreen,_("Parental PIN"),_("PIN must contain 4-8 digits. Parental Lock was not enabled."),False)
            self.refresh_current()
            return
        payload=parental_hash_pin(value)
        payload["parental_lock"]=True
        save_settings(payload)
        parental_lock_now()
        self["status"].setText(_("Parental PIN saved • Parental lock enabled"))
        self.refresh_current()

    def open_section_settings(self):
        cfg=load_settings(); rows=[]
        for label,key in ((_("Live TV"),"show_live"),(_("Movies"),"show_movies"),(_("Series"),"show_series"),(_("Catch-up TV"),"show_catchup")):
            rows.append(("%s  •  %s"%(label,_("ON") if cfg.get(key,True) else _("OFF")),key))
        self.session.openWithCallback(self._toggle_section,ChoiceBox,title=_("Visible home sections"),list=rows)

    def _toggle_section(self, choice):
        if choice:
            key=choice[1]; save_settings({key:not bool(load_settings().get(key,True))}); self._show_root(); self["status"].setText(_("Section visibility updated"))

    def toggle_current_category_hidden(self):
        if self.level not in ("genres","items") or not self.media_type: self["status"].setText(_("Open a category first")); return
        category=str(self.genre or "")
        if self.level=="genres":
            idx=self["list"].getSelectedIndex()
            if 0 <= idx < len(self.content_items):
                e=self.content_items[idx]; category=str(e.get("id") or e.get("genre_id") or e.get("name") or e.get("title") or "")
        if not category or category=="*": self["status"].setText(_("This category cannot be hidden")); return
        cfg=load_settings(); hidden=cfg.get("hidden_categories",{}); values=list(hidden.get(self.media_type,[]))
        if category in values: values.remove(category); state=_("visible")
        else: values.append(category); state=_("hidden")
        hidden[self.media_type]=values; save_settings({"hidden_categories":hidden}); self["status"].setText(_("Category %s")%state)
        if self.level=="catchup_programs" and self.catchup_channel: self.load_catchup_programs(self.catchup_channel)
        elif self.level=="catchup_channels": self.load_catchup_channels()
        elif self.level=="genres": self.load_genres(self.media_type)

    def show_hidden_categories(self):
        hidden=load_settings().get("hidden_categories",{}); lines=[]
        for typ in ("itv","vod","series"): lines.append("%s: %s"%(self._mode_name(typ),", ".join(hidden.get(typ,[])) or _("None")))
        self.session.open(MessageBox,_("Hidden categories")+"\n\n"+"\n".join(lines)+"\n\n"+_("Use MENU on a category to toggle it."),MessageBox.TYPE_INFO,timeout=15)

    def show_account_info(self):
        self["status"].setText(_("Loading account information..."))
        def ok(info):
            if not isinstance(info,dict): info={"Information":info}
            preferred=("login","phone","fname","lsname","tariff_plan","account_balance","expire_billing_date","end_date","status")
            lines=[]
            for key in preferred:
                if info.get(key) not in (None,""): lines.append("%s: %s"%(key.replace("_"," ").title(),info.get(key)))
            health=self.client.health_snapshot(); lines.extend([_("Portal Health: %s")%health.get("health","unknown"),_("Average Latency: %s ms")%health.get("latency_ms",0)])
            if not lines:
                for key,value in list(info.items())[:18]:
                    if value not in (None,"",[],{}): lines.append("%s: %s"%(str(key).replace("_"," ").title(),value))
            self.session.open(MessageBox,_("Account Information")+"\n\n"+("\n".join(lines) if lines else _("No account data returned")),MessageBox.TYPE_INFO,timeout=20); self["status"].setText(_("Ready"))
        self._run_async(self.client.account_info,ok,lambda e:self["status"].setText(_("Account info failed: %s")%e))

    def load_catchup_channels(self):
        if self._busy:return
        self.level="catchup_channels_loading";self._apply_utility_glass_mode()
        self._set_list_density("itv")
        self["status"].setText(_("Loading catch-up channels...  •  BACK cancels")); self._show_skeleton(_("Loading catch-up"))
        def ok(rows):
            valid=[x for x in rows if isinstance(x,dict)]; self.level="catchup_channels"; self.media_type="itv"; self.content_items=valid; self.all_content_items=list(valid); self._catchup_channels_cache=list(valid)
            menu=[(str(x.get("name") or x.get("title") or _("Channel")),asset("ico_channel_x.png"),x,_('Archive')) for x in valid]
            self["list"].set_icon_rows(menu or [(_("No catch-up channels"),asset("us86_episode_40.png"),None,{"meta":_("No EPG information"),"row_asset":_neutral_utility_glass().get("utility_row"),"row_selected_asset":_neutral_utility_glass().get("utility_selected")})]); self._reveal_browser_content(); self["section"].setText(_("Catch-up TV  /  Channels")); self["counter"].setText(_("%d channels")%len(valid)); self["status"].setText(_("Ready") if valid else _("No catch-up channels")); self._selection_changed()
        self._run_async(lambda handle:self.client.catchup_channels("*",1,max_pages=20,cancel_event=handle.cancel_event),ok,lambda e:self["status"].setText(_("Catch-up failed: %s")%e))

    def load_catchup_programs(self, channel):
        if self._busy:return
        self.level="catchup_programs_loading";self._apply_utility_glass_mode()
        self._set_list_density("compact")
        self.catchup_channel=channel; cid=channel.get("id") or channel.get("ch_id")
        if not cid: self["status"].setText(_("Channel has no archive identifier")); return
        self["status"].setText(_("Loading archive programmes...  •  BACK cancels"))
        def ok(rows):
            valid=[x for x in rows if isinstance(x,dict)]; self.level="catchup_programs"; self.content_items=valid
            menu=[]
            for x in valid:
                title=_clean_display_text(x.get("name") or x.get("title") or x.get("descr") or _("Programme"), 120); start=_clean_display_text(x.get("time") or x.get("start") or x.get("start_timestamp") or "", 30); menu.append((title,asset("ico_live_x.png"),x,start))
            self["list"].set_icon_rows(menu or [(_("No archived programmes"),asset("ico_live_x.png"),None,_("Try another channel"))]); self["section"].setText(_("Catch-up  /  %s")%str(channel.get("name") or _("Channel"))[:45]); self["counter"].setText(_("%d programmes")%len(valid)); self["status"].setText(_("Ready") if valid else _("No archive data")); self._selection_changed()
        hours=load_settings().get("catchup_hours",72)
        self._run_async(lambda handle:self.client.catchup_programs(cid,hours,cancel_event=handle.cancel_event),ok,lambda e:self["status"].setText(_("Archive EPG failed: %s")%e))

    def play_catchup_program(self, program):
        if not self.catchup_channel: return
        self["status"].setText(_("Creating catch-up stream..."))
        def ok(url):
            name=str(program.get("name") or program.get("title") or _("Catch-up programme"))
            if not isinstance(url, str) or not url.strip():
                self["status"].setText(_("Portal returned an invalid catch-up link")); return
            self["status"].setText(_("Opening Ultra Stalker player..."))
            def closed(result=None):
                engine = result.get("engine") if isinstance(result, dict) else load_settings().get("service_type", 4097)
                self["status"].setText(_("Player closed  •  engine %s") % engine)
            engine=_configured_playback_engine()
            self.session.openWithCallback(closed, UltraStalkerPlayer, url.strip(), name, "catchup", engine, _player_payload(program, self.profile, {"_catchup_channel": dict(self.catchup_channel)}, "catchup"))
        self._run_async(lambda handle:self.client.create_catchup_link(self.catchup_channel,program,cancel_event=handle.cancel_event),ok,lambda e:self["status"].setText(_("Catch-up play failed: %s")%e))

    def open_audio(self):
        if AudioSelection is None: self.session.open(MessageBox,_("Audio selection is not available in this image"),MessageBox.TYPE_INFO,timeout=6)
        else:
            try: self.session.open(AudioSelection, infobar=None)
            except Exception as exc: self.session.open(MessageBox,_("Audio selection failed: %s")%exc,MessageBox.TYPE_ERROR,timeout=6)

    def open_subtitles(self):
        try:
            from Screens.AudioSelection import SubtitleSelection
            self.session.open(SubtitleSelection, infobar=None)
        except Exception as exc: self.session.open(MessageBox,_("Subtitle selection is unavailable: %s")%exc,MessageBox.TYPE_INFO,timeout=6)

    def _mode_name(self, media_type):
        for title,key,_icon in self.MODES:
            if key==media_type:return _(title)
        return str(media_type or "Content")

    def play_item(self,item):
        if not isinstance(item,dict) or self._busy:return
        command=item.get("cmd") or item.get("command") or item.get("url")
        if not command:self["status"].setText(_("No stream command"));return
        self["status"].setText(_("Creating stream link..."))
        def work(handle):
            url=self.client.create_link(item,self.media_type or "itv",cancel_event=handle.cancel_event)
            picon=None
            if (self.media_type or "itv") == "itv":
                try:
                    _picon_value=_source_art_url(_image_url(item),self.profile,item)
                    picon=_download_portal_artwork(_picon_value,self.profile,self.client,False,2.8,handle.cancel_event,item=item)
                except Exception as exc:optional_failure("ui.live_player_picon_prefetch",exc)
            return (url,picon)
        def ok(result):
            url,picon=(result if isinstance(result,tuple) and len(result)==2 else (result,None))
            if not isinstance(url, str) or not url.strip():
                self["status"].setText(_("Portal returned an invalid stream link")); return
            name=str(item.get("name") or item.get("title") or "Ultra Stalker stream")
            try:
                add_recently_played(self.profile, self.media_type or "itv", item)
                self["status"].setText(_("Opening player: %s") % name)
                def closed(result=None):
                    if not (isinstance(result,dict) and result.get("service_restored")):
                        try:force_session_silence(self.session,str(url).strip(),force=True)
                        except Exception as exc:optional_failure("ui.detail_return_stop",exc)
                    engine = result.get("engine") if isinstance(result, dict) else load_settings().get("service_type", 4097)
                    self["status"].setText(_("Player closed  •  engine %s") % engine)
                engine=_configured_playback_engine()
                extra={"_player_picon":picon} if picon and os.path.isfile(picon) else None
                self.session.openWithCallback(closed, UltraStalkerPlayer, str(url).strip(), name, self.media_type or "itv", engine, _player_payload(item, self.profile, extra, media_type=self.media_type or "itv"))
            except Exception as exc:self["status"].setText(_("Player failed: %s")%exc)
        self._run_async(work,ok,lambda e:self["status"].setText(_("Play failed: %s")%e))

