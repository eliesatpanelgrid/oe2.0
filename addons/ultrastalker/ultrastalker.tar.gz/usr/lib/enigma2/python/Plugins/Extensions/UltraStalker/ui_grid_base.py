"""Premium grid base extracted from ui.py without changing class behavior."""

from . import _
from Screens.Screen import Screen
from .ui_async import AsyncScreenMixin
from .ui_grid_artwork import GridArtworkMixin
import threading
import time
import json
import tempfile
import gc
from .core.shared_executors import CATALOGUE_EXECUTOR, CACHE_IO_EXECUTOR, VISIBLE_ARTWORK_EXECUTOR, METADATA_EXECUTOR
from .core.runtime_log import diagnostic_breadcrumb as _ui_diag
from .core.call_compat import call_compatible
from .log import diagnostic_failure
from twisted.internet import reactor

def configure_grid_base(**deps):
    globals().update(deps)


# release: one catalogue-only lane shared by Poster Grid screens.  This mirrors
# the lightweight Cinematic page warmer: provider catalogue/state only, never
# artwork/TMDB/Pillow.  One worker keeps portal sockets serialized and RAM calm.
_GRID_PAGE_WARM_EXECUTOR=CATALOGUE_EXECUTOR
_VISIBLE_POSTER_HDD_EXECUTOR=CACHE_IO_EXECUTOR
_VISIBLE_POSTER_EXECUTOR=VISIBLE_ARTWORK_EXECUTOR
_VISIBLE_TMDB_EXECUTOR=METADATA_EXECUTOR

def _progressive_poster_item_detached(profile, media_type, item, cfg, client, cancel_event=None):
    """Resolve one visible poster without retaining a Grid Screen instance."""
    if media_type not in ("vod","series") or not isinstance(item,dict):
        return "",{}
    if cancel_event is not None and cancel_event.is_set():
        return "",{}
    cfg=dict(cfg or {});profile=dict(profile or {})
    credential=str(cfg.get("tmdb_credential") or "").strip()
    if not (cfg.get("tmdb_enabled",True) and cfg.get("load_images",True) and credential):
        return "",{}
    try:
        snap=load_artwork_v2_manifest(profile,media_type,item) or {}
        poster=str(snap.get("poster_local") or "")
        if poster and os.path.isfile(poster) and os.path.getsize(poster)>256:
            return poster,snap
    except Exception:
        snap={}
    if cancel_event is not None and cancel_event.is_set():
        return "",{}
    try:
        data=ArtworkV2(credential,cfg.get("tmdb_language","ar-EG"),min(5,max(3,int(cfg.get("timeout",10) or 10)))).resolve(
            profile,media_type,item,full=False,cancel_event=cancel_event) or {}
        poster=str(data.get("poster_local") or "")
        if poster and os.path.isfile(poster) and os.path.getsize(poster)>256:
            return poster,data
        if data.get("poster_candidate_unavailable"):
            purl=str(item.get("_visible_provider_art_url") or item.get("_rescue_provider_art_url") or "").strip()
            if not purl:
                try:purl=str(_image_url(item) or "").strip()
                except Exception:purl=""
            if purl and not item.get("_generic_provider_art"):
                provider=_download_portal_artwork(purl,profile,client,False,4.5,cancel_event,item=item) or ""
                if provider and os.path.isfile(provider):
                    try:
                        from .artwork_v2 import save_manual_rescue_art
                        saved=save_manual_rescue_art(profile,media_type,item,poster=provider,source="provider_auto_missing") or {}
                        rescued=str(saved.get("poster_local") or "")
                        if rescued and os.path.isfile(rescued):return rescued,saved
                    except Exception as exc:optional_failure("ui.grid_visible_provider_rescue_save",exc)
        return "",data
    except Exception as exc:
        optional_failure("ui.auto_visible_poster",exc)
        return "",{}


def _catalogue_error_kind(exc):
    """Classify catalogue failures without changing provider/client behavior."""
    low=str(exc or "").casefold()
    hard=(
        "security consent", "fallback is not approved", "certificate verification",
        "unapproved https", "unsupported portal transport", "invalid portal url",
    )
    if any(marker in low for marker in hard):
        return "hard"
    transient=(
        "connection", "timed out", "timeout", "non-json", "invalid page",
        "temporarily paused", "remote end closed", "connection reset",
        "broken pipe", "connection aborted", "eof", "http 502", "http 503",
        "http 504", "bad gateway", "service unavailable", "gateway timeout",
    )
    return "transient" if any(marker in low for marker in transient) else "other"


class PremiumGridBase(Screen, AsyncScreenMixin, GridArtworkMixin):
    columns=1; page_size=1; card_positions=[]; image_size=(100,100); placeholder="placeholder_live_x.png"
    selection_asset="grid_live_selected_921.png"

    def __init__(self,session,profile,client,media_type,genre,category_title=""):
        Screen.__init__(self,session);self._async_init();self.onClose.append(self._stop_async)
        self._ui_diag_open_mono=time.monotonic();self._ui_diag_page_request_mono=self._ui_diag_open_mono;self._ui_diag_first_poster_logged=False
        _ui_diag("ui_open",screen="grid",media_type=media_type)
        self.profile=profile;self.client=client;self.media_type=media_type;self.genre=str(genre or "*")
        # Settings are immutable for the lifetime of a grid screen. Reading the
        # JSON file once avoids 12-24 filesystem reads every time a page is
        # rendered while still picking up changes when the screen is reopened.
        self._grid_settings=load_settings()
        self.category_title=_clean_display_text(category_title,70) or ("Live TV" if media_type=="itv" else ("Movies" if media_type=="vod" else "Series"))
        self._nav_key=(str(profile.get("portal") or "").rstrip("/").lower(),str(media_type),self.genre)
        self.page=1;self.grid_items=[];self.index=0;self._grid_item_state={};self._explicit_quality_cache={}
        self._restore_page=1;self._restore_index=0
        # Folder-local Search + Sort view state. Movies/Series only.
        self._folder_catalog=None
        self._folder_catalog_loading=False
        self._folder_catalog_waiters=[]
        self._search_query=""
        self._sort_mode=0
        self._view_items=None
        self._view_active=False
        self._folder_artwork_cache_running=False
        self._folder_artwork_cache_done=0
        self._folder_artwork_cache_total=0
        self._folder_artwork_progress=queue.Queue()
        self._folder_artwork_ui_finalized=False
        self._session_nav_key=(current_plugin_launch(),)+tuple(self._nav_key)
        try:
            _g=_GRID_NAV_STATE.get(self._session_nav_key,{})
            self._restore_page=max(1,int(_g.get("page",1)));self._restore_index=max(0,int(_g.get("index",0)))
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._portal_page_cache=OrderedDict();self._portal_page_size=0;self._portal_total=0
        self._portal_page_cache_limit=6;self._last_nav_at=0.0;self._nav_burst_until=0.0
        self._prepared_page_cache=OrderedDict();self._prepared_page_lock=threading.RLock();self._prepared_page_pending=set();self._prepared_page_cache_limit=4
        self._grid_page_warm_running=False;self._grid_page_warm_token=0
        # Per-screen visual RAM. Keyed by stable content identity, not page
        # number, so revisiting/sorting never blanks cards or re-downloads art.
        self._page_visual_ram=OrderedDict();self._page_visual_ram_limit=512
        self._grid_visual_locks={}
        try:
            _desk=getDesktop(0).size();self._grid_sx=float(_desk.width())/1920.0;self._grid_sy=float(_desk.height())/1080.0
        except Exception:
            self._grid_sx=1.0;self._grid_sy=1.0
        self._scaled_card_positions=[(int(x*self._grid_sx),int(y*self._grid_sy)) for x,y in self.card_positions]
        self._page_load_handle=None; self._pending_page_request=None
        self._page_prefetch_futures=[];self._page_prefetch_future_jobs=queue.Queue()
        self._quality_prefetch_jobs=queue.Queue();self._art_prefetch_jobs=queue.Queue()
        self._epg_cache={};self._epg_jobs=queue.Queue();self._epg_pending=None
        self._epg_timer=eTimer();self._epg_timer_conn=None
        try:self._epg_timer_conn=self._epg_timer.timeout.connect(self._fetch_epg)
        except Exception:self._epg_timer.callback.append(self._fetch_epg)
        self._detail_prefetch_timer=eTimer();self._detail_prefetch_conn=None
        try:self._detail_prefetch_conn=self._detail_prefetch_timer.timeout.connect(self._prefetch_selected_details)
        except Exception:self._detail_prefetch_timer.callback.append(self._prefetch_selected_details)
        # Debounce the expensive adaptive focus work.  Navigation itself stays
        # immediate; palette/chrome/background work only starts when the user
        # pauses briefly on an item.
        self._grid_focus_timer=eTimer();self._grid_focus_timer_conn=None
        try:self._grid_focus_timer_conn=self._grid_focus_timer.timeout.connect(self._apply_debounced_grid_focus)
        except Exception:self._grid_focus_timer.callback.append(self._apply_debounced_grid_focus)
        # beta58: hierarchy warming has its own longer debounce. 300 ms was far
        # too eager for remote-control browsing and created a queue of network calls.
        self._series_prefetch_timer=eTimer();self._series_prefetch_timer_conn=None
        try:self._series_prefetch_timer_conn=self._series_prefetch_timer.timeout.connect(self._prefetch_selected_series_hierarchy)
        except Exception:self._series_prefetch_timer.callback.append(self._prefetch_selected_series_hierarchy)
        self._series_hierarchy_prefetch_cancel=threading.Event()
        self._series_hierarchy_prefetch_token=0
        self._grid_idle_warm_timer=eTimer();self._grid_idle_warm_conn=None;self._grid_full_chrome_warm=False
        try:self._grid_idle_warm_conn=self._grid_idle_warm_timer.timeout.connect(self._warm_idle_grid_page)
        except Exception:self._grid_idle_warm_timer.callback.append(self._warm_idle_grid_page)

        # beta51: HDD-only visible poster watcher. Background jobs may finish after
        # their one-shot UI event became stale due to page/generation timing. This
        # watcher never uses network; it simply notices newly persisted posters
        # for the 12 visible cards and paints them immediately.
        self._visible_poster_watch_timer=eTimer();self._visible_poster_watch_conn=None
        try:self._visible_poster_watch_conn=self._visible_poster_watch_timer.timeout.connect(self._poll_visible_poster_cache)
        except Exception:self._visible_poster_watch_timer.callback.append(self._poll_visible_poster_cache)
        self._page_prefetch_seen=set();self._visible_tmdb_pending=set();self._visible_tmdb_rating_cache={};self._page_quality_seen=set();self._page_art_retry_count={};self._page_prefetch_lock=threading.RLock();self._page_prefetch_generation=0;self._page_prefetch_cancel=threading.Event()
        # beta47: poster-only progressive folder warmer. It never fetches backdrop/details.
        self._progressive_poster_cancel=threading.Event();self._progressive_poster_started=False
        self.onClose.append(self._stop_progressive_poster_prefetch)
        self.onClose.append(self._stop_visible_poster_watch)
        self.onClose.append(self._stop_grid_ui_hooks)
        self.onClose.append(self._grid_art_stop);self.onClose.append(self._stop_grid_epg);self.onClose.append(self._stop_detail_prefetch);self.onClose.append(self._stop_grid_focus_timer);self.onClose.append(self._stop_series_hierarchy_prefetch);self.onClose.append(self._stop_grid_idle_warm_timer);self.onClose.append(self._runtime_grid_close)
        self["brand"]=Label("");self["section"]=Label(((_("Live TV")+"  /  "+self.category_title[:28]) if media_type=="itv" else self.category_title[:48]));self["title"]=Label(self.category_title)
        self["clock"]=Label("");self._grid_clock=None;self._grid_clock_conn=None
        if not getattr(self,"disable_grid_clock",False):
            self["clock"].setText(time.strftime("%H:%M"));self._grid_clock=eTimer()
            try:self._grid_clock_conn=self._grid_clock.timeout.connect(self._update_grid_clock)
            except Exception:self._grid_clock.callback.append(self._update_grid_clock)
            try:self._grid_clock.start(30000,False)
            except Exception as exc:optional_failure("ui",exc)
            self.onClose.append(self._stop_grid_clock)
        self.onClose.append(self._ui_diag_grid_close)
        self["rating"]=Label("");self["meta1"]=Label("");self["meta2"]=Label("")
        self["status"]=Label(_("Loading..."));self["page_label"]=Label(_("Page 1"))
        self["red"]=Label(_("Search") if media_type in ("vod","series") else _("Back"));self["green"]=Label(_("Favorite"))
        self["yellow"]=Label(_("Default") if media_type in ("vod","series") else _("Previous page"));self["blue"]=Label(_("Check Artwork") if media_type in ("vod","series") else _("Next page"))
        self["selection"]=Pixmap()
        if media_type in ("vod","series"):
            self["selection_adaptive"]=Pixmap()
            self["page_adaptive_bg"]=Pixmap()
            self["poster_folder_bg"]=Pixmap();self["poster_title_bg"]=Pixmap();self["poster_clock_bg"]=Pixmap();self["poster_counter_bg"]=Pixmap()
            self["date_label"]=Label(time.strftime("%A, %d %B %Y"))
            self._poster_hud_last={};self._poster_hud_source="";self._poster_hud_pending=set();self._poster_hud_jobs=queue.Queue()
            self._grid_mood_jobs=queue.Queue();self._grid_mood_token=0;self._grid_mood_source="";self._grid_mood_pending=""
        slot_names=[]
        for pos in range(self.page_size):
            name="art%d"%pos;slot_names.append(name);self[name]=Pixmap();self["item_title%d"%pos]=Label("");self["item_meta%d"%pos]=Label("")
            if media_type in ("vod","series"):
                self["card_chrome%d"%pos]=Pixmap()
                # Fixed local rating widgets.  The gold star is a packaged PNG asset,
                # not a font glyph and never participates in poster/network loading.
                self["item_year%d"%pos]=Label("");self["item_star%d"%pos]=Pixmap();self["item_score%d"%pos]=Label("")
        self._grid_art_init(slot_names,self.image_size,profile,client)
        _red_action=self.open_folder_search if media_type in ("vod","series") else self.close
        _yellow_action=self.cycle_folder_sort if media_type in ("vod","series") else self.previous_page
        _blue_action=self.cache_folder_artwork if media_type in ("vod","series") else self.next_page
        self["actions"]=ActionMap(["OkCancelActions","ColorActions","DirectionActions","MenuActions","InfoActions"],{
            "cancel":self.close,"red":_red_action,"ok":self.open_selected,"left":self.move_left,"right":self.move_right,
            "up":self.move_up,"down":self.move_down,"green":self.toggle_selected_favorite,"yellow":_yellow_action,
            "blue":_blue_action,"menu":self.open_menu,"info":self.show_information},-1)
        self.onLayoutFinish.append(self._grid_layout_ready)
        if media_type in ("vod","series"):self.onLayoutFinish.append(self._refresh_search_sort_controls)
        try:self.onHide.append(self._grid_hidden_release)
        except Exception as exc:optional_failure("ui.grid_hide_hook",exc)
        try:self.onShown.append(self._grid_shown_resume)
        except Exception as exc:optional_failure("ui.grid_show_hook",exc)

    def _grid_is_m3u_source(self):
        try:
            source=str((self.profile or {}).get("source_type") or "").lower().strip()
            portal=str((self.profile or {}).get("portal") or "").lower()
            return source=="m3u" or ".m3u" in portal or "type=m3u" in portal or "output=m3u" in portal
        except Exception:
            return False

    def _page_visual_key(self,item):
        try:
            from .persistent_cache import content_cache_key
            return str(content_cache_key(self.profile,self.media_type,item) or "")
        except Exception:
            try:return hashlib.sha1(repr(sorted((item or {}).items())).encode("utf-8","ignore")).hexdigest()
            except Exception:return ""

    def _page_visual_valid_path(self,path):
        value=str(path or "")
        if not value or not os.path.isfile(value):
            return ""
        name=os.path.basename(value).lower()
        if "placeholder" in name or name.startswith(("poster_movie","poster_series","placeholder_live")):
            return ""
        try:
            if os.path.getsize(value)<=100:return ""
        except Exception:return ""
        return value

    def _page_visual_get(self,item):
        if self.media_type not in ("vod","series") or not isinstance(item,dict):
            return {}
        key=self._page_visual_key(item)
        if not key:return {}
        try:
            row=dict(self._page_visual_ram.get(key) or {})
            if not row:return {}
            display=self._page_visual_valid_path(row.get("display"))
            poster=self._page_visual_valid_path(row.get("poster"))
            palette=self._page_visual_valid_path(row.get("palette"))
            card=self._page_visual_valid_path(row.get("card"))
            if not (display or poster):
                self._page_visual_ram.pop(key,None)
                return {}
            out={}
            if display:out["display"]=display
            if poster:out["poster"]=poster
            if palette:out["palette"]=palette
            if card:out["card"]=card
            if row.get("provider_locked"):out["provider_locked"]=True
            self._page_visual_ram.move_to_end(key)
            return out
        except Exception as exc:
            optional_failure("ui.page_visual_get",exc)
            return {}

    def _page_visual_put(self,item,display=None,poster=None,palette=None,card=None,provider_locked=None):
        if self.media_type not in ("vod","series") or not isinstance(item,dict):
            return
        key=self._page_visual_key(item)
        if not key:return
        try:
            row=dict(self._page_visual_ram.get(key) or {})
            for field,value in (("display",display),("poster",poster),("palette",palette),("card",card)):
                valid=self._page_visual_valid_path(value)
                if valid:row[field]=valid
            if provider_locked is not None:
                row["provider_locked"]=bool(provider_locked)
            if not (self._page_visual_valid_path(row.get("display")) or self._page_visual_valid_path(row.get("poster"))):
                return
            self._page_visual_ram[key]=row
            self._page_visual_ram.move_to_end(key)
            while len(self._page_visual_ram)>int(self._page_visual_ram_limit or 512):
                self._page_visual_ram.popitem(last=False)
        except Exception as exc:
            optional_failure("ui.page_visual_put",exc)

    def _remember_grid_visual(self,slot,display=None,poster=None,palette=None,card=None,provider_locked=None):
        try:
            pos=int(slot)
            if pos<0 or pos>=len(self.grid_items):return
            item=self.grid_items[pos]
            if display is None:display=(getattr(self,"_grid_slot_paths",{}) or {}).get(pos)
            if palette is None:palette=(getattr(self,"_grid_palette_sources",{}) or {}).get(pos)
            if card is None:card=(getattr(self,"_grid_card_paths",{}) or {}).get(pos)
            self._page_visual_put(item,display=display,poster=poster,palette=palette,card=card,provider_locked=provider_locked)
        except Exception as exc:
            optional_failure("ui.page_visual_remember",exc)

    def _visible_player_poster_path(self,item=None,index=None):
        """Return the real poster surface already painted for the selected card.

        This is a zero-network direct handoff for Player.  If the user can see a
        real poster before pressing PLAY, Player receives that exact local file
        instead of attempting to rediscover the artwork from metadata/cache.
        """
        try:
            pos=int(self.index if index is None else index)
        except Exception:
            pos=0
        try:
            current=item if isinstance(item,dict) else (self.grid_items[pos] if 0<=pos<len(self.grid_items) else {})
            visual=self._page_visual_get(current) if isinstance(current,dict) else {}
            candidates=[
                (getattr(self,"_grid_slot_paths",{}) or {}).get(pos),
                (visual or {}).get("poster"),
                (visual or {}).get("display"),
                (getattr(self,"_grid_palette_sources",{}) or {}).get(pos),
            ]
            if isinstance(current,dict):
                candidates.extend((current.get("_player_poster"),current.get("_ultra_poster_source"),current.get("_adaptive_source_local")))
            for candidate in candidates:
                path=str(candidate or "").strip()
                if not path or not os.path.isfile(path):continue
                try:
                    if os.path.getsize(path)<=256:continue
                except Exception:
                    continue
                bn=os.path.basename(path).lower()
                if "placeholder" in bn or bn.startswith("poster_movie") or bn.startswith("poster_series"):continue
                return path
        except Exception as exc:
            optional_failure("ui.visible_player_poster",exc)
        return ""

    def _stop_grid_ui_hooks(self):
        for queue_name in (
            "_quality_prefetch_jobs",
            "_art_prefetch_jobs",
            "_epg_jobs",
            "_folder_artwork_progress",
            "_poster_hud_jobs",
            "_grid_mood_jobs",
        ):
            result_queue=getattr(self,queue_name,None)
            if result_queue is None:continue
            try:
                while True:result_queue.get_nowait()
            except queue.Empty:
                pass
            except Exception as exc:
                optional_failure("ui.grid_queue_cleanup",exc)
        self._epg_pending=None
        for hook_name,callback in (
            ("onLayoutFinish",self._grid_layout_ready),
            ("onLayoutFinish",self._refresh_search_sort_controls),
            ("onHide",self._grid_hidden_release),
            ("onShown",self._grid_shown_resume),
        ):
            try:
                hooks=getattr(self,hook_name,None)
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:
                optional_failure("ui.grid_hook_cleanup",exc)

    def _ui_diag_grid_close(self):
        try:
            _ui_diag("ui_close",screen="grid",media_type=getattr(self,"media_type",""),page=getattr(self,"page",0),
                     lifetime_ms=int(max(0.0,(time.monotonic()-float(getattr(self,"_ui_diag_open_mono",time.monotonic())))*1000.0)))
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.161",exc)

    def _grid_layout_ready(self):
        try:_ui_diag("ui_layout",screen="grid",media_type=self.media_type,elapsed_ms=int((time.monotonic()-self._ui_diag_open_mono)*1000.0))
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.165",exc)
        self._grid_art_layout_ready()
        try:
            initial_selector=asset(self.selection_asset)
            self["selection"].instance.setPixmapFromFile(initial_selector);self["selection"].show()
            self._grid_selection_visual_path=initial_selector
            if self.media_type in ("vod","series"):
                self["selection_adaptive"].hide()
                self._grid_selection_adaptive_visual_path=""
        except Exception as exc:optional_failure("ui",exc)
        if not getattr(self,"disable_grid_clock",False):self._update_grid_clock()
        self.load_page(self._restore_page, self._restore_index)

    def _grid_hidden_release(self):
        if getattr(self,"_screen_closed",False) or getattr(self,"_grid_closed",False):return
        self._grid_images_suspended=True

        # Child screens are temporary. Keep all already-decoded poster, chrome,
        # selector and mood pixmaps alive. 10.0.75-78 released every surface here,
        # then raced an async page rebuild on BACK; the selected card returned
        # naked until the next LEFT/RIGHT forced another selection repaint.
        try:self._grid_cancel_queued_downloads()
        except Exception as exc:optional_failure("ui.grid_hide_cancel",exc)
        try:self._grid_focus_timer.stop()
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.186",exc)
        try:self._detail_prefetch_timer.stop()
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.188",exc)
        try:self._grid_idle_warm_timer.stop()
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.190",exc)
        try:
            cancel=getattr(self,"_page_prefetch_cancel",None)
            if cancel is not None:cancel.set()
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.194",exc)
        self._cancel_detached_page_prefetch_futures()
        for future in list(getattr(self,"_page_prefetch_futures",[]) or []):
            try:future.cancel()
            except Exception as exc:diagnostic_failure("ui.grid.failsoft.197",exc)
        self._page_prefetch_futures=[]

    def _grid_shown_resume(self):
        if not getattr(self,"_grid_images_suspended",False):return
        if getattr(self,"_screen_closed",False) or getattr(self,"_grid_closed",False):return
        self._grid_images_suspended=False
        try:self._grid_art_layout_ready()
        except Exception as exc:optional_failure("ui.grid_resume_layout",exc)

        if not getattr(self,"grid_items",None):return
        # Rebind only the current selection/header. All poster/chrome surfaces
        # were preserved, so a full _render_grid() here is wasted work and is the
        # source of the visible blank-card flash on OpenBH.
        try:self._update_selection()
        except Exception as exc:optional_failure("ui.grid_resume_selection",exc)
        try:
            if self.media_type in ("vod","series"):self._grid_apply_current_selector()
            elif self.media_type=="itv" and hasattr(self,"_force_live_visual_rebind"):self._force_live_visual_rebind()
        except Exception as exc:optional_failure("ui.grid_resume_rebind",exc)

    def _cancel_detached_page_prefetch_futures(self):
        """Cancel futures submitted by the detached HDD discovery worker."""
        q=getattr(self,"_page_prefetch_future_jobs",None)
        if q is None:return
        while True:
            try:_generation,_key,future=q.get_nowait()
            except queue.Empty:break
            except Exception:break
            try:future.cancel()
            except Exception:pass

    def _adopt_detached_page_prefetch_futures(self, limit=16):
        q=getattr(self,"_page_prefetch_future_jobs",None)
        if q is None:return
        current=int(getattr(self,"_page_prefetch_generation",0) or 0)
        for _ in range(max(1,int(limit or 1))):
            try:generation,key,future=q.get_nowait()
            except queue.Empty:break
            except Exception:break
            if generation!=current or getattr(self,"_screen_closed",False):
                try:future.cancel()
                except Exception:pass
                continue
            if future.done():
                try:future.result()
                except Exception:
                    try:
                        with self._page_prefetch_lock:self._page_prefetch_seen.discard(key)
                    except Exception:pass
                continue
            self._page_prefetch_futures.append(future)

    def _drain_visible_poster_results(self, limit=1):
        self._adopt_detached_page_prefetch_futures()
        applied=0
        retry_positions=[]
        for _ in range(max(1,int(limit or 1))):
            try:
                _ajob=self._art_prefetch_jobs.get_nowait()
                if len(_ajob)>=4:agen,akey,apath,ameta=_ajob[0],_ajob[1],_ajob[2],_ajob[3]
                else:agen,akey,apath=_ajob;ameta=None
            except queue.Empty:
                break
            if agen != int(getattr(self,"_page_prefetch_generation",0) or 0):
                continue
            matched_pos=None
            for pos,item in enumerate(self.grid_items[:self.page_size]):
                try:
                    from .persistent_cache import content_cache_key
                    ikey=content_cache_key(self.profile,self.media_type,item)
                except Exception:
                    ikey=""
                if ikey==akey:
                    matched_pos=pos
                    break
            if apath=="__RETRY__":
                try:
                    with self._page_prefetch_lock:
                        self._page_prefetch_seen.discard(akey)
                        count=int(self._page_art_retry_count.get(akey,0) or 0)
                        if count<1 and matched_pos is not None:
                            self._page_art_retry_count[akey]=count+1
                            retry_positions.append(matched_pos)
                except Exception as exc:
                    optional_failure("ui.art_retry_state",exc)
                continue
            # release: metadata is independent from poster decode.  A canonical
            # TMDb score may already be present on HDD even when this worker did
            # not return a usable poster path.  Apply identity/rating first so a
            # poster cache miss can never blank the score row.
            if matched_pos is not None and isinstance(ameta,dict):
                try:
                    target_item=self.grid_items[matched_pos]
                    if ameta.get("tmdb_id"):
                        target_item["_locked_tmdb_id"]=ameta.get("tmdb_id")
                        target_item["_locked_tmdb_type"]=ameta.get("media_type") or ("tv" if self.media_type=="series" else "movie")
                        self._grid_item_state.setdefault(id(target_item),{})["tmdb_id"]=ameta.get("tmdb_id")
                    # TMDb full metadata already contains the canonical release/first-air
                    # year.  Keep a valid provider year if present; otherwise publish
                    # TMDb's year onto the live card so Movies and Series render the
                    # same YEAR + star + score row without any extra network request.
                    try:
                        if self._folder_year_value(target_item) <= 0:
                            _tmdb_year=self._folder_year_value(ameta)
                            if _tmdb_year > 0:
                                target_item["year"]=_tmdb_year
                    except Exception as exc:
                        optional_failure("ui.grid_tmdb_year_apply",exc)
                    try:
                        _tmdb_score=float(ameta.get("rating") or ameta.get("vote_average") or 0)
                    except Exception:
                        _tmdb_score=0.0
                    if 0.0 < _tmdb_score <= 10.0:
                        target_item["_tmdb_rating"]=_tmdb_score
                        try:
                            _rk=self._page_visual_key(target_item)
                            if _rk:self._visible_tmdb_rating_cache[_rk]=_tmdb_score
                        except Exception:pass
                    try:self._card_rating_layout(target_item,matched_pos,self._card_meta(target_item,matched_pos))
                    except Exception as exc:optional_failure("ui.grid_tmdb_meta_apply_layout",exc)
                except Exception as exc:
                    optional_failure("ui.grid_tmdb_meta_apply",exc)
            if not apath or not os.path.isfile(str(apath)):
                continue
            if matched_pos is not None:
                try:
                    target_item=self.grid_items[matched_pos]
                    palette_source=str((ameta or {}).get("palette_source") or "") if isinstance(ameta,dict) else ""
                    if palette_source and os.path.isfile(palette_source):
                        self._grid_palette_sources[matched_pos]=palette_source
                    self._grid_queue_decode(self._grid_generation,matched_pos,str(apath))
                    self._remember_grid_visual(
                        matched_pos,
                        display=str(apath),
                        poster=palette_source or str(apath),
                        palette=palette_source or str(apath),
                        provider_locked=bool(isinstance(ameta,dict) and ameta.get("provider_locked")),
                    )
                    applied+=1
                except Exception as exc:
                    optional_failure("ui.art_prefetch_apply",exc)
        for retry_pos in retry_positions[:1]:
            try:self._prefetch_visible_page_details(priority_index=retry_pos,max_items=1)
            except Exception as exc:optional_failure("ui.art_retry_submit",exc)
        return applied

    def _drain_jobs(self):
        # Remote-control movement gets absolute GUI priority. Do not decode or
        # apply posters before checking the navigation burst window.
        if time.monotonic() < float(getattr(self,"_nav_burst_until",0.0) or 0.0):
            return
        if not self._screen_closed and self.media_type in ("vod","series"):
            try:
                self._drain_visible_poster_results(1)
                self._grid_drain_art_jobs(limit=1)
            except Exception as exc:
                optional_failure("ui.poster_micro_drain",exc)
        AsyncScreenMixin._drain_jobs(self)
        if not self._screen_closed:
            self._grid_drain_art_jobs();self._grid_drain_adaptive_selector();self._grid_drain_page_mood();self._drain_grid_epg();self._drain_folder_artwork_progress();self._drain_poster_live_hud()
            while True:
                try:qgen,qkey,qvalue=self._quality_prefetch_jobs.get_nowait()
                except queue.Empty:break
                if qgen != int(getattr(self,"_page_prefetch_generation",0) or 0):continue
                for pos,item in enumerate(self.grid_items[:self.page_size]):
                    try:
                        from .persistent_cache import content_cache_key
                        ikey=content_cache_key(self.profile,self.media_type,item)
                    except Exception:
                        ikey=""
                    if ikey==qkey:
                        self._grid_item_state.setdefault(id(item),{})["quality"]=qvalue
                        try:self["item_meta%d"%pos].setText(self._card_meta(item,pos))
                        except Exception as exc:optional_failure("ui.silent_guard",exc)
                        if pos==self.index:self._update_header(item)
                        break
            # Keep the visual cascade progressive after navigation settles too.
            self._drain_visible_poster_results(2)
            pending=getattr(self,"_pending_page_request",None)
            if pending and not self._busy:
                self._pending_page_request=None
                self.load_page(pending[0], pending[1])

    def _remember_grid_state(self):
        self._restore_page=max(1,int(self.page or 1));self._restore_index=max(0,int(self.index or 0))
        # Search/Sort is a temporary view of this open folder. Preserve it while
        # Details is open, but do not poison the next fresh folder open with a
        # page number that belongs to filtered results.
        if not getattr(self,"_view_active",False):
            try:
                _state=dict(_GRID_NAV_STATE.get(self._session_nav_key,{}) or {})
                _state.update({"page":self._restore_page,"index":self._restore_index})
                _GRID_NAV_STATE[self._session_nav_key]=_state
            except Exception as exc:optional_failure("ui.grid_state",exc)
        return (self._restore_page,self._restore_index)

    _FOLDER_SORT_LABELS=("Default","Top Rated","Newest","Oldest","A-Z","Z-A")

    @staticmethod
    def _folder_search_norm(value):
        text=str(value or "").casefold()
        # Arabic-friendly normalization without changing what is displayed.
        text=re.sub(r"[\u064b-\u065f\u0670\u06d6-\u06ed]","",text)
        text=text.replace("\u0640","")
        text=re.sub(r"[\s._\-–—:/|]+"," ",text)
        return " ".join(text.split())

    @staticmethod
    def _folder_rating_value(item):
        """Return TMDb rating only for poster cards.

        Provider/IMDb ratings are intentionally excluded.  The poster score must
        match the canonical TMDb value used by Details.  `_tmdb_rating` is filled
        by the existing artwork/TMDb hydration lane and is therefore network-free
        on the GUI thread.
        """
        for value in (
            item.get("_tmdb_rating"),item.get("tmdb_rating"),item.get("vote_average"),
        ):
            match=re.search(r"\d+(?:\.\d+)?",str(value or ""))
            if match:
                try:
                    score=float(match.group(0))
                    if 0.0 < score <= 10.0:return score
                except Exception as exc:diagnostic_failure("ui.grid.tmdb_rating",exc)
        return -1.0

    @staticmethod
    def _folder_year_value(item):
        for value in (
            item.get("year"),item.get("released"),item.get("release_date"),
            item.get("releasedate"),item.get("first_air_date"),item.get("create_date"),
        ):
            match=re.search(r"(?:19|20)\d{2}",str(value or ""))
            if match:
                try:return int(match.group(0))
                except Exception as exc:diagnostic_failure("ui.grid.failsoft.353",exc)
        return 0

    def _folder_title_value(self,item):
        raw=item.get("name") or item.get("title") or item.get("original_name") or item.get("original_title") or ""
        try:return _catalogue_title(raw) if self.media_type in ("vod","series") else premium_title(raw,(self._grid_settings or {}).get("clean_titles",True))
        except Exception:return str(raw or "")

    def _folder_item_identity(self,item,index=0):
        for key in ("id","movie_id","series_id","ch_id","cmd","command","url"):
            value=item.get(key)
            if value not in (None,""):return "%s:%s"%(key,value)
        return "title:%s:%d"%(self._folder_search_norm(self._folder_title_value(item)),int(index))

    def _active_total(self):
        if self.media_type in ("vod","series") and self._view_active and isinstance(self._view_items,list):
            return len(self._view_items)
        return int(self._portal_total or 0)

    def _refresh_search_sort_controls(self):
        if self.media_type not in ("vod","series"):return
        label=self._FOLDER_SORT_LABELS[self._sort_mode % len(self._FOLDER_SORT_LABELS)]
        try:self["red"].setText(_("Search"))
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.376",exc)
        try:self["yellow"].setText(label)
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.378",exc)
        try:
            blue_label=str(self["blue"].getText() or "Check Artwork")
            units=sum(1.55 if ord(ch)>0x2ff else (0.60 if ch in " ilI1|.,:'" else 1.0) for ch in blue_label)
            size=22 if units<=11 else (21 if units<=15 else (19 if units<=19 else 17))
            if self["blue"].instance is not None:self["blue"].instance.setFont(gFont("Regular",size))
        except Exception as exc:optional_failure("ui.folder_cache_label_font",exc)
        # The yellow box geometry never changes. Only the font scales, always
        # centered horizontally/vertically by the existing skin.
        try:
            units=sum(1.55 if ord(ch)>0x2ff else (0.60 if ch in " ilI1|.,:'" else 1.0) for ch in label)
            size=22 if units<=10 else (21 if units<=14 else (19 if units<=18 else 17))
            if self["yellow"].instance is not None:self["yellow"].instance.setFont(gFont("Regular",size))
        except Exception as exc:optional_failure("ui.folder_sort_label_font",exc)
        try:
            base=("MOVIES" if self.media_type=="vod" else "SERIES")+"  /  "+self.category_title[:28]
            if self._search_query:
                base+="  •  SEARCH: "+_clean_display_text(self._search_query,28)
            self["section"].setText(base)
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.397",exc)

    def _load_folder_catalog_data(self,cancel_event=None):
        if self.media_type not in ("vod","series"):return []
        first=self._portal_page(1,cancel_event=cancel_event)
        native=max(1,int(self._portal_page_size or len(first) or self.page_size))
        total=max(0,int(self._portal_total or 0))
        max_pages=max(1,min(int((self._grid_settings or {}).get("search_max_pages",250) or 250),500))
        expected_pages=((total+native-1)//native) if total else max_pages
        expected_pages=max(1,min(expected_pages,max_pages))
        rows=[];seen=set();previous_signature=None
        for native_page in range(1,expected_pages+1):
            if cancel_event is not None and cancel_event.is_set():raise _ArtworkCancelled()
            page_rows=first if native_page==1 else self._portal_page(native_page,cancel_event=cancel_event)
            if not page_rows:break
            signature=tuple(self._folder_item_identity(row,pos) for pos,row in enumerate(page_rows[:4]))
            if native_page>1 and signature and signature==previous_signature:
                # Some portals ignore p= and repeat page one forever.
                break
            previous_signature=signature
            added=0
            for pos,row in enumerate(page_rows):
                if not isinstance(row,dict):continue
                # Xtream provider artwork is authoritative. Do not strip cover/backdrop
                # before folder caching/search; Stalker keeps the external-art policy.
                if row.get("_xtream"):
                    item=dict(row)
                else:
                    raw_provider_art="";raw_provider_backdrop="";raw_provider_backdrops=[]
                    try:raw_provider_art=str(_image_url(row) or "").strip()
                    except Exception:raw_provider_art=""
                    try:
                        from .ui_artwork_helpers import _backdrop_url as _manual_backdrop_url, _backdrop_candidates as _manual_backdrop_candidates
                        raw_provider_backdrop=str(_manual_backdrop_url(row) or "").strip()
                        raw_provider_backdrops=[str(x or "").strip() for x in (_manual_backdrop_candidates(row) or []) if str(x or "").strip()]
                    except Exception:raw_provider_backdrop="";raw_provider_backdrops=[]
                    item=_strip_portal_artwork(row)
                    # Preserve every real provider candidate privately for BLUE.
                    # Some Stalker portals expose a dead first screenshot followed
                    # by a valid CDN fanart URL; keeping only candidate #1 caused
                    # an avoidable permanent 'left N' after TMDB had its chance.
                    if raw_provider_art:item["_rescue_provider_art_url"]=raw_provider_art
                    if raw_provider_backdrop:item["_rescue_provider_backdrop_url"]=raw_provider_backdrop
                    if raw_provider_backdrops:item["_rescue_provider_backdrop_candidates"]=raw_provider_backdrops
                identity=self._folder_item_identity(item,len(rows)+pos)
                if identity in seen:continue
                seen.add(identity);rows.append(item);added+=1
                if total and len(rows)>=total:break
            if total and len(rows)>=total:break
            if not added:break
            if not total and len(page_rows)<native:break
        # Reject obvious provider-wide placeholder art from the explicit rescue
        # chain. A repeated list-level icon is not a real missing-title poster.
        try:
            rescue_counts={};backdrop_counts={}
            for item in rows:
                if not isinstance(item,dict):continue
                url=str(item.get("_rescue_provider_art_url") or "").strip()
                burl=str(item.get("_rescue_provider_backdrop_url") or "").strip()
                if url:rescue_counts[url]=rescue_counts.get(url,0)+1
                if burl:backdrop_counts[burl]=backdrop_counts.get(burl,0)+1
            generic_rescue={url for url,count in rescue_counts.items() if count>=3}
            generic_backdrop={url for url,count in backdrop_counts.items() if count>=3}
            if generic_rescue or generic_backdrop:
                for item in rows:
                    if not isinstance(item,dict):continue
                    if str(item.get("_rescue_provider_art_url") or "").strip() in generic_rescue:
                        item["_rescue_provider_art_generic"]=True
                    if str(item.get("_rescue_provider_backdrop_url") or "").strip() in generic_backdrop:
                        item["_rescue_provider_backdrop_generic"]=True
        except Exception as exc:optional_failure("ui.folder_rescue_generic_detect",exc)
        return rows

    def _ensure_folder_catalog(self,callback):
        if self.media_type not in ("vod","series"):return
        if isinstance(self._folder_catalog,list):
            callback(self._folder_catalog);return
        self._folder_catalog_waiters.append(callback)
        if self._folder_catalog_loading:return
        self._folder_catalog_loading=True
        self["status"].setText(_("Loading folder index..."))
        def ok(rows):
            self._folder_catalog_loading=False
            self._folder_catalog=[x for x in (rows or []) if isinstance(x,dict)]
            if not self._portal_total:self._portal_total=len(self._folder_catalog)
            waiters=list(self._folder_catalog_waiters);self._folder_catalog_waiters=[]
            for cb in waiters:
                try:cb(self._folder_catalog)
                except Exception as exc:optional_failure("ui.folder_catalog_waiter",exc)
        def failed(error):
            self._folder_catalog_loading=False
            self._folder_catalog_waiters=[]
            self["status"].setText(_friendly_error(error))
        self._run_async(lambda handle:self._load_folder_catalog_data(handle.cancel_event),ok,failed)

    def _build_folder_view(self):
        rows=list(self._folder_catalog or [])
        query=self._folder_search_norm(self._search_query)
        if query:
            filtered=[]
            for item in rows:
                haystack=" ".join(self._folder_search_norm(item.get(key)) for key in ("name","title","original_name","original_title"))
                if query in haystack:filtered.append(item)
            rows=filtered
        mode=self._sort_mode % len(self._FOLDER_SORT_LABELS)
        if mode==1:
            rows=sorted(rows,key=lambda item:(self._folder_rating_value(item)<0,-self._folder_rating_value(item),self._folder_search_norm(self._folder_title_value(item))))
        elif mode==2:
            rows=sorted(rows,key=lambda item:(self._folder_year_value(item)<=0,-self._folder_year_value(item),self._folder_search_norm(self._folder_title_value(item))))
        elif mode==3:
            rows=sorted(rows,key=lambda item:(self._folder_year_value(item)<=0,self._folder_year_value(item) if self._folder_year_value(item)>0 else 9999,self._folder_search_norm(self._folder_title_value(item))))
        elif mode==4:
            rows=sorted(rows,key=lambda item:self._folder_search_norm(self._folder_title_value(item)))
        elif mode==5:
            rows=sorted(rows,key=lambda item:self._folder_search_norm(self._folder_title_value(item)),reverse=True)
        self._view_items=rows
        self._view_active=True
        return rows

    def _load_folder_view_page(self,page,restore_index=None):
        self._ui_diag_page_request_mono=time.monotonic();self._ui_diag_first_poster_logged=False

        # Folder-view navigation is a real page transition too.  Reset the
        # previous page's poster-prefetch lifecycle exactly like load_page():
        # otherwise _page_prefetch_seen keeps the old card keys and revisiting a
        # page leaves provider-owned cards as permanent placeholders.
        try:
            old_cancel=getattr(self,"_page_prefetch_cancel",None)
            if old_cancel is not None:
                old_cancel.set()
        except Exception as exc:optional_failure("ui.folder_prefetch_cancel",exc)

        self._cancel_detached_page_prefetch_futures()
        for future in list(getattr(self,"_page_prefetch_futures",[]) or []):
            try:future.cancel()
            except Exception as exc:optional_failure("ui.folder_prefetch_future_cancel",exc)
        self._page_prefetch_futures=[]
        self._page_prefetch_cancel=threading.Event()
        try:self._page_prefetch_generation+=1
        except Exception:self._page_prefetch_generation=1
        try:
            with self._page_prefetch_lock:
                self._page_prefetch_seen.clear()
                self._visible_tmdb_pending.clear()
                self._page_quality_seen.clear()
                self._page_art_retry_count.clear()
        except Exception as exc:optional_failure("ui.folder_prefetch_reset",exc)

        rows=self._build_folder_view()
        total=len(rows);total_pages=max(1,(total+self.page_size-1)//self.page_size)
        target=max(1,min(int(page),total_pages))
        start=(target-1)*self.page_size
        valid=rows[start:start+self.page_size]
        self.page=target;self.grid_items=valid
        states=load_content_states(self.profile,self.media_type,self.grid_items) if self.grid_items else []
        qualities=load_content_qualities(self.profile,self.media_type,self.grid_items) if self.grid_items else []
        self._grid_item_state={}
        for item,state,quality in zip(self.grid_items,states,qualities):
            row=dict(state or {});row["quality"]=quality or "";self._grid_item_state[id(item)]=row
        self.index=max(0,min(int(restore_index or 0),len(valid)-1)) if valid else 0
        self._grid_full_chrome_warm=False
        # Folder views used to fall through to _grid_request_art() with no
        # prepared-art map. That forced up to 12 synchronous HDD snapshot /
        # visual-bundle / manifest lookups during the GUI paint itself.
        #
        # Paint the page immediately, then let the existing visible-poster
        # workers fill cards progressively. An explicit empty row is important:
        # _grid_request_art() sees the slot as prepared and never enters its
        # legacy synchronous cold fallback.
        self._prepared_art_for_render=[self._page_visual_get(item) or {} for item in valid]
        self._prepared_titles_for_render=[]
        self._prepared_fitted_for_render=[]
        self._prepared_meta_for_render=[]
        self._render_grid();self._remember_grid_state();self._refresh_search_sort_controls()
        try:_ui_diag("ui_page_ready",screen="grid",media_type=self.media_type,page=self.page,items=len(self.grid_items),
                     folder_view=True,elapsed_ms=int(max(0.0,(time.monotonic()-self._ui_diag_page_request_mono)*1000.0)))
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.496",exc)
        self._update_page_counter()
        if valid:
            self["status"].setText("")
            # Test69 Lean: search/sort views are event-driven too. No idle HDD
            # scanner or neighbour warming is started after first paint.
        else:
            try:self["selection"].hide()
            except Exception as exc:diagnostic_failure("ui.grid.failsoft.507",exc)
            try:self["title"].setText(self.category_title);self["rating"].setText("");self["meta1"].setText("");self["meta2"].setText("")
            except Exception as exc:diagnostic_failure("ui.grid.failsoft.509",exc)
            self["status"].setText(_("No matching content"))

    def _apply_folder_artwork_result(self,result):
        if getattr(self,"_folder_artwork_ui_finalized",False):return
        self._folder_artwork_ui_finalized=True
        self._folder_artwork_cache_running=False
        try:self["blue"].setText(_("Check Artwork"));self._refresh_search_sort_controls()
        except Exception as exc:optional_failure("ui.check_artwork_controls",exc)
        result=result or {};total=int(result.get("total",0) or 0)
        pm=int(result.get("poster_missing",0) or 0);bm=int(result.get("backdrop_missing",0) or 0)
        pr=int(result.get("poster_recovered",0) or 0);br=int(result.get("backdrop_recovered",0) or 0)
        pf=int(result.get("poster_failed",0) or 0);bf=int(result.get("backdrop_failed",0) or 0)
        bu=int(result.get("backdrop_upgraded",0) or 0)
        if not pm and not bm:
            # release: report only physically verified poster/backdrop components.
            # "fully cached" was misleading when Details later rejected a
            # canonical identity handoff and therefore could not present it.
            text="Artwork check • posters %d/%d • backdrops %d/%d • 0 missing"%(total,total,total,total)
            if bu:text += " • %d real backdrop upgrade%s"%(bu,"s" if bu!=1 else "")
            self["status"].setText(text)
        else:
            self["status"].setText(_("Artwork cache • posters %d/%d (left %d) • backdrops %d/%d (left %d)")%(pr,pm,pf,br,bm,bf))
        try:
            pt=int(result.get("presentation_total",0) or 0);prdy=int(result.get("presentation_ready",0) or 0)
            if pt:
                left=max(0,pt-prdy)
                suffix=" • display-ready %d/%d"%(prdy,pt)
                if left:suffix += " • %d not prepared"%left
                self["status"].setText(str(self["status"].getText() or "")+suffix)
        except Exception as exc:optional_failure("ui.check_artwork_display_ready_status",exc)
        self._page_prefetch_seen.clear()
        try:self._poll_visible_poster_cache()
        except Exception as exc:optional_failure("ui.check_artwork_repaint",exc)

    def _drain_folder_artwork_progress(self):
        while True:
            try:event=self._folder_artwork_progress.get_nowait()
            except queue.Empty:break
            except Exception:break
            if isinstance(event,tuple) and len(event)==2 and event[0]=="__complete__":
                try:self._apply_folder_artwork_result(event[1])
                except Exception as exc:optional_failure("ui.check_artwork_terminal",exc)
                continue
            try:done,total=event
            except Exception:continue
            self._folder_artwork_cache_done=int(done or 0)
            self._folder_artwork_cache_total=int(total or 0)
            if self._folder_artwork_cache_running and total:
                try:self["status"].setText(_("Caching %d / %d")%(done,total))
                except Exception as exc:diagnostic_failure("ui.grid.failsoft.521",exc)
                try:
                    self["blue"].setText("%d / %d"%(done,total))
                    if self["blue"].instance is not None:self["blue"].instance.setFont(gFont("Regular",22))
                except Exception as exc:diagnostic_failure("ui.grid.failsoft.525",exc)

    def _blue_resume_path(self):
        try:
            from .persistent_cache import LOOKUP,ensure_persistent_dirs
            raw="%s|%s|%s"%(str(self.profile.get("portal") or "").rstrip("/").lower(),str(self.media_type),str(self.genre))
            key=hashlib.sha1(raw.encode("utf-8","ignore")).hexdigest()
            return os.path.join(LOOKUP,"blue_resume_%s.json"%key)
        except Exception:return ""

    def _blue_item_sig(self,item):
        """Stable category identity; never hash the entire mutable provider dict."""
        row=item if isinstance(item,dict) else {}
        mt=str(self.media_type or "")
        tmdb=row.get("tmdb_id") or row.get("_locked_tmdb_id")
        if tmdb:return "tmdb:%s:%s"%(mt,str(tmdb))
        provider_id=row.get("stream_id") or row.get("series_id") or row.get("movie_id") or row.get("id") or row.get("ch_id")
        title=_catalogue_title(row.get("name") or row.get("title") or "").casefold().strip()
        year=str(row.get("year") or row.get("release_date") or row.get("first_air_date") or "")[:4]
        raw="%s|%s|%s|%s"%(mt,str(provider_id or ""),title,year)
        return hashlib.sha1(raw.encode("utf-8","ignore")).hexdigest()

    def _blue_resume_done_path(self):
        path=self._blue_resume_path()
        return (path+".done") if path else ""

    def _load_blue_resume(self):
        path=self._blue_resume_path()
        if not path or not hdd_read_ready():return []
        try:
            with open(path,"r",encoding="utf-8") as h:row=json.load(h)
            pending=row.get("pending") if isinstance(row,dict) else []
            done=set()
            done_path=self._blue_resume_done_path()
            if done_path and os.path.isfile(done_path):
                with open(done_path,"r",encoding="utf-8") as h:
                    for line in h:
                        sig=line.strip()
                        if sig:done.add(sig)
            return [dict(x) for x in pending if isinstance(x,dict) and self._blue_item_sig(x) not in done]
        except Exception:return []

    def _save_blue_resume(self,pending):
        """Seed or clear Blue resume state without O(N²) list rewrites.

        The full pending list is written once. Each completion is appended as a
        tiny signature journal entry by _mark_blue_resume_done().
        """
        path=self._blue_resume_path()
        if not path:return False
        try:
            from .persistent_cache import ensure_persistent_dirs,persistent_write_gate
            if not ensure_persistent_dirs(os.path.dirname(path)):return False
            done_path=self._blue_resume_done_path()
            if not pending:
                for candidate in (path,done_path):
                    try:
                        if candidate and os.path.isfile(candidate) and persistent_write_gate(candidate):os.unlink(candidate)
                    except OSError:pass
                return True
            # Seed only once for this run. A current catalogue merge in
            # cache_folder_artwork refreshes stale resumes before this worker.
            temp=path+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            if not persistent_write_gate(temp):return False
            with open(temp,"w",encoding="utf-8") as h:
                json.dump({"schema":56,"pending":pending,"updated_at":int(time.time())},h,ensure_ascii=False,separators=(",",":"))  # resumable cache, safe to rebuild
            if not persistent_write_gate(path):return False
            os.replace(temp,path)
            try:
                if done_path and os.path.isfile(done_path) and persistent_write_gate(done_path):os.unlink(done_path)
            except OSError:pass
            return True
        except Exception as exc:optional_failure("ui.blue_resume_save",exc);return False

    def _mark_blue_resume_done(self,item):
        path=self._blue_resume_done_path();sig=self._blue_item_sig(item)
        if not path or not sig:return False
        try:
            from .persistent_cache import ensure_persistent_dirs,persistent_write_gate
            if not ensure_persistent_dirs(os.path.dirname(path)) or not persistent_write_gate(path):return False
            with open(path,"a",encoding="ascii") as h:h.write(sig+"\n")  # completion journal is rebuildable cache state
            return True
        except Exception as exc:optional_failure("ui.blue_resume_done",exc);return False

    def _cache_folder_artwork_worker(self, rows, cancel_event=None):
        # Test110: one artwork engine only. Settings/maintenance uses the exact
        # same TMDB-first, missing-only rescue path as BLUE.
        return self._check_missing_posters_worker(rows,cancel_event)

    def _check_missing_posters_worker(self, rows, cancel_event=None):
        """TMDB-first two-pass artwork audit.

        Pass 1: TMDB gets first chance to fill highest-quality masters.
        Pass 2: provider/Xtream fills any component still physically missing.
        Existing TMDB files are immutable and provider rescue never overwrites them.
        """
        cfg=self._grid_settings or {};profile=self.profile;media_type=self.media_type
        credential=str(cfg.get("tmdb_credential") or "").strip()
        tmdb_available=bool(cfg.get("tmdb_enabled",True) and credential)
        language=cfg.get("tmdb_language","ar-EG");timeout=min(9,max(4,int(cfg.get("timeout",10) or 10)))
        rows=[dict(x) for x in (rows or []) if isinstance(x,dict)]
        trace_path="/media/hdd/UltraStalker/logs/blue_artwork_trace.log"
        def blue_trace(message):
            try:
                parent=os.path.dirname(trace_path)
                if parent and not os.path.isdir(parent):os.makedirs(parent,exist_ok=True)
                with open(trace_path,"a",encoding="utf-8") as fh:
                    fh.write("%s %s\n"%(time.strftime("%Y-%m-%d %H:%M:%S"),str(message or "")))
            except Exception:
                pass
        try:
            parent=os.path.dirname(trace_path)
            if parent and not os.path.isdir(parent):os.makedirs(parent,exist_ok=True)
            with open(trace_path,"w",encoding="utf-8") as fh:
                fh.write("Ultra Stalker BLUE artwork trace FIRST VALID ARTWORK WINS\n")
        except Exception:
            pass
        blue_trace("START media=%s rows=%d tmdb_available=%s genre=%r"%(media_type,len(rows),tmdb_available,str(getattr(self,"genre","") or "")))
        def cancelled():return bool(cancel_event is not None and cancel_event.is_set())
        def valid_file(path,min_size=512):
            try:return bool(path and os.path.isfile(str(path)) and os.path.getsize(str(path))>min_size)
            except Exception:return False
        def backdrop_truth(path):
            # release: a backdrop is cached only when the actual HDD file passes
            # the same landscape/dimension validation used by ArtworkV2. A JSON
            # pointer or any existing JPEG is not enough. This is the single truth
            # used by BLUE for preflight, commit verification and final counting.
            try:
                from .artwork_v2 import _valid_backdrop
                return bool(_valid_backdrop(str(path or "")))
            except Exception:
                return False
        def state(item):
            try:data=load_artwork_v2_manifest(profile,media_type,item) or {}
            except Exception:data={}
            poster=str(data.get("poster_local") or "")
            backdrop=str(data.get("backdrop_local") or "")
            return data,poster,(backdrop if backdrop_truth(backdrop) else "")
        def tmdb_master_state(data):
            """Return canonical TMDB component readiness, ignoring BLUE/provider fallbacks."""
            try:
                tid=(data or {}).get("tmdb_id")
                if not tid:return None,None
                paths=canonical_art_paths((data or {}).get("media_type") or media_type,tid) or {}
                return valid_file(paths.get("poster")),backdrop_truth(paths.get("backdrop"))
            except Exception:return None,None
        def _uniq_urls(values):
            out=[]
            for value in values or []:
                text=str(value or "").strip()
                if text and text not in out:out.append(text)
            return out
        provider_enriched={}
        def provider_candidates(item):
            # BLUE/provider rescue must inspect every provider artwork field, not
            # just _image_url()'s first hit.  Some Stalker rows put a generic
            # placeholder in screenshot_uri/movie_image while the exact cover is
            # present in poster/cover (or only in the richer search row).  Using
            # the first field made a real provider poster effectively invisible.
            posters=[];backs=[]
            if not item.get("_rescue_provider_art_generic"):
                posters.extend((item.get("_rescue_provider_art_url"),item.get("_visible_provider_art_url")))
            if not item.get("_rescue_provider_backdrop_generic"):
                backs.extend(item.get("_rescue_provider_backdrop_candidates") or [])
                backs.extend((item.get("_rescue_provider_backdrop_url"),item.get("_visible_provider_backdrop_url")))
            for key in ("poster","poster_url","cover","cover_url","movie_image","image","img","hd","pic","screenshot_uri","screenshot","stream_icon","logo","logo_url","picon"):
                value=item.get(key)
                values=value if isinstance(value,(list,tuple)) else [value]
                for entry in values:
                    text=str(entry or "").strip()
                    low=text.casefold()
                    if not text or low in ("null","none","[]","{}") or any(tag in low for tag in ("placeholder","noimage","no_image","default_poster","default-cover")):
                        continue
                    posters.append(text)
            try:
                from .ui_artwork_helpers import _backdrop_candidates as _manual_backdrop_candidates
                backs.extend(_manual_backdrop_candidates(item) or [])
            except Exception:pass
            return _uniq_urls(posters),_uniq_urls(backs)
        def enrich_provider(item,need_p,need_b):
            # Provider search is intentionally disabled here. Pass 2 may only
            # reuse artwork already present on the catalogue row.
            return dict(item)
        try:
            from .artwork_v2 import save_manual_rescue_art
        except Exception:
            save_manual_rescue_art=None

        def adopt_existing_hdd(item):
            """Promote already-cached local artwork into the shared master store.

            Old builds can have perfectly usable poster/backdrop files referenced by
            detail snapshots/visual bundles but not yet represented in artwork_v2.
            BLUE must treat those HDD files as hits instead of re-downloading them.
            """
            if not callable(save_manual_rescue_art):
                return False,False
            try:
                data,p,b=state(item)
                need_p=not valid_file(p);need_b=not valid_file(b)
                if not (need_p or need_b):
                    return False,False
                snap=(load_shared_detail_snapshot(self.profile,self.media_type,item)
                      if isinstance(item,dict) and item.get("_xtream")
                      else load_detail_snapshot(self.profile,self.media_type,item))
                bundle=_load_visual_bundle(self.profile,self.media_type,item,snap) or {}
                local_p=str(bundle.get("poster") or "")
                local_b=str(bundle.get("backdrop") or "")
                use_p=local_p if need_p and valid_file(local_p) else None
                use_b=local_b if need_b and backdrop_truth(local_b) else None
                if not (use_p or use_b):
                    return False,False
                saved=save_manual_rescue_art(profile,media_type,item,poster=use_p,backdrop=use_b,source="existing_hdd_adopt") or {}
                got_p=bool(use_p and valid_file(saved.get("poster_local")))
                got_b=bool(use_b and backdrop_truth(saved.get("backdrop_local")))
                blue_trace("HDD_ADOPT title=%r poster=%s backdrop=%s"%(str(item.get("name") or item.get("title") or "")[:120],got_p,got_b))
                return got_p,got_b
            except Exception as exc:
                optional_failure("ui.artwork_existing_hdd_adopt",exc)
                return False,False

        # release diagnostic: force an identity/language trace for Generation War
        # BEFORE the cache preflight.  This deliberately ignores cached/missing
        # state so a false "fully cached" verdict cannot suppress diagnostics.
        try:
            focus_item=None
            for _row in rows:
                _title=str(_row.get("name") or _row.get("title") or "").strip()
                if "generation war" in _title.casefold():
                    focus_item=dict(_row);break
            if focus_item is not None:
                blue_trace("FOCUS_FORCE_BEGIN title=%r"%str(focus_item.get("name") or focus_item.get("title") or "")[:120])
                focus_resolve=dict(focus_item)
                # Provider is consulted for identity/metadata only, mirroring the
                # XStreamity hybrid path.  Artwork URLs are never consumed here.
                if focus_item.get("_xtream") and hasattr(self.client,"enrich_provider_artwork"):
                    try:
                        try:_rich=self.client.enrich_provider_artwork(dict(focus_item),media_type,cancel_event,force=True) or {}
                        except TypeError:_rich=self.client.enrich_provider_artwork(dict(focus_item),media_type,cancel_event) or {}
                        for _k in ("tmdb_id","tmdb","imdb_id","imdb","year","releaseDate","release_date","releasedate",
                                   "_provider_name","original_name","original_title","o_name","english_name","english_title"):
                            _v=_rich.get(_k) if isinstance(_rich,dict) else None
                            if _v not in (None,"",[],{}):focus_resolve[_k]=_v
                        blue_trace("FOCUS_PROVIDER_IDENTITY tmdb_id=%r imdb_id=%r year=%r provider_name=%r original_name=%r original_title=%r english_name=%r"%(
                            focus_resolve.get("tmdb_id") or focus_resolve.get("tmdb"),focus_resolve.get("imdb_id") or focus_resolve.get("imdb"),
                            focus_resolve.get("year") or focus_resolve.get("release_date") or focus_resolve.get("first_air_date"),
                            str(focus_resolve.get("_provider_name") or "")[:120],str(focus_resolve.get("original_name") or "")[:120],
                            str(focus_resolve.get("original_title") or "")[:120],str(focus_resolve.get("english_name") or focus_resolve.get("english_title") or "")[:120]))
                    except Exception as _exc:
                        blue_trace("FOCUS_PROVIDER_IDENTITY_ERROR error=%r"%str(_exc)[:180])
                _fields=("name","title","_raw_name","_provider_name","original_name","original_title","o_name","english_name","english_title","tmdb_id","tmdb","imdb_id","imdb","year","release_date","first_air_date")
                blue_trace("FOCUS_INPUT "+" ".join("%s=%r"%(_k,str(focus_resolve.get(_k))[:160]) for _k in _fields if focus_resolve.get(_k) not in (None,"",[],{})))
                if tmdb_available:
                    _diag=ArtworkV2(credential,language,timeout)
                    try:_diag.trace_cb=blue_trace
                    except Exception:pass
                    _direct=str(focus_resolve.get("tmdb_id") or focus_resolve.get("tmdb") or "").strip()
                    if _direct.isdigit():
                        try:
                            _det=_diag.tmdb._get("/tv/%s"%_direct,{"language":"en-US"}) or {}
                            blue_trace("FOCUS_DIRECT id=%s name=%r original=%r year=%r backdrop=%r poster=%r"%(
                                _direct,str(_det.get("name") or "")[:120],str(_det.get("original_name") or "")[:120],str(_det.get("first_air_date") or "")[:10],
                                str(_det.get("backdrop_path") or "")[:120],str(_det.get("poster_path") or "")[:120]))
                        except Exception as _exc:blue_trace("FOCUS_DIRECT_ERROR id=%s error=%r"%(_direct,str(_exc)[:180]))
                    _queries=[]
                    for _k in ("name","title","_raw_name","_provider_name","original_name","original_title","o_name","english_name","english_title"):
                        _q=str(focus_resolve.get(_k) or "").strip()
                        if _q and _q not in _queries:_queries.append(_q)
                    _yr=str(focus_resolve.get("year") or focus_resolve.get("first_air_date") or focus_resolve.get("release_date") or "")[:4]
                    _langs=[]
                    for _lang in (language,"en-US","de-DE"):
                        if _lang and _lang not in _langs:_langs.append(_lang)
                    for _q in _queries[:10]:
                        for _lang in _langs:
                            try:
                                _params={"query":_q,"language":_lang,"include_adult":"false"}
                                if _yr.isdigit():_params["first_air_date_year"]=_yr
                                _pay=_diag.tmdb._get("/search/tv",_params) or {}
                                _rs=[]
                                for _r in (_pay.get("results") or [])[:5]:
                                    _rs.append("%s:%s|%s|%s|bd=%s|po=%s"%(str(_r.get("id") or ""),str(_r.get("name") or "")[:60],str(_r.get("original_name") or "")[:60],str(_r.get("first_air_date") or "")[:10],bool(_r.get("backdrop_path")),bool(_r.get("poster_path"))))
                                blue_trace("FOCUS_SEARCH q=%r lang=%s year=%r top=%r"%(_q,_lang,_yr,_rs))
                            except Exception as _exc:blue_trace("FOCUS_SEARCH_ERROR q=%r lang=%s error=%r"%(_q,_lang,str(_exc)[:180]))
                    # Probe TMDB alternative titles for the direct ID as another
                    # language-independent identity signal. Diagnostic only.
                    if _direct.isdigit():
                        try:
                            _alt=_diag.tmdb._get("/tv/%s/alternative_titles"%_direct,{}) or {}
                            _titles=[]
                            for _r in (_alt.get("results") or [])[:20]:
                                _titles.append("%s:%s"%(str(_r.get("iso_3166_1") or ""),str(_r.get("title") or "")[:100]))
                            blue_trace("FOCUS_ALIASES id=%s titles=%r"%(_direct,_titles))
                        except Exception as _exc:blue_trace("FOCUS_ALIASES_ERROR id=%s error=%r"%(_direct,str(_exc)[:180]))
                blue_trace("FOCUS_FORCE_END")
        except Exception as _exc:
            blue_trace("FOCUS_FORCE_FATAL error=%r"%str(_exc)[:220])

        # Preflight: immutable existing masters never enter any worker. First
        # adopt artwork that older builds already cached on HDD but never indexed.
        # Keep the initial physical state so the final UI counter can report TMDB
        # recoveries too (older code counted provider rescue only).
        initial_state={}
        missing=[];hot=0
        # release unified BLUE pass. The visible counter belongs to TITLES, not
        # internal stages. A cached title is checked/finalised once here; a title
        # missing artwork is finalised once after its artwork rescue below. This
        # prevents the old 1..N artwork pass followed by another 1..N Cinematic
        # pass that looked like the cache had restarted from zero.
        blue_done=0
        blue_total=len(rows)
        try:self._folder_artwork_progress.put((0,blue_total))
        except Exception:pass

        def _blue_finish_title(item):
            """Finish one title inside the same BLUE lifecycle.

            Poster/backdrop are the hard prerequisites. Optional screen-specific
            presentation hooks (Cinematic final backdrop/adaptive/details) are
            executed here, before this title advances the single folder counter.
            """
            if cancelled():raise _ArtworkCancelled()
            data,p,b=state(item)
            if not (valid_file(p) and backdrop_truth(b)):
                return False
            ready_hook=getattr(self,"_folder_artwork_ready_hook",None)
            if callable(ready_hook):
                try:
                    if ready_hook(item,data):
                        return True
                except Exception as exc:
                    optional_failure("ui.artwork_blue_ready_hook",exc)
            finalize_hook=getattr(self,"_folder_artwork_finalize_hook",None)
            if callable(finalize_hook):
                try:
                    return bool(finalize_hook(item,p,b,data,data,cancel_event))
                except Exception as exc:
                    optional_failure("ui.artwork_blue_finalize_hook",exc)
                    return False
            return True

        for item in rows:
            try:
                _d0,_p0,_b0=state(item)
                initial_state[self._page_visual_key(item)]=(not valid_file(_p0),not valid_file(_b0))
            except Exception:
                initial_state[self._page_visual_key(item)]=(True,True)
            if cancelled():raise _ArtworkCancelled()
            adopt_existing_hdd(item)
            data,p,b=state(item)

            # release persistent BLUE contract: a screen-specific completed vault
            # is authoritative before any TMDB/provider canonical-master retry.
            # Once Cinematic has successfully persisted poster/backdrop/final
            # backdrop/adaptive/details for a title, pressing BLUE again must be
            # a read-only verification. It must never invalidate, rewrite, touch
            # timestamps, resolve identity or re-download that title merely
            # because the canonical TMDB master path differs from the trusted HDD
            # vault. Missing/corrupt physical files still fall through to repair.
            ready_hook=getattr(self,"_folder_artwork_ready_hook",None)
            persistent_ready=False
            if callable(ready_hook):
                try:persistent_ready=bool(ready_hook(item,data))
                except Exception as exc:optional_failure("ui.artwork_blue_persistent_ready",exc)
            if persistent_ready:
                hot+=1
                blue_done+=1
                try:self._folder_artwork_progress.put((blue_done,blue_total))
                except Exception:pass
                continue

            cp,cb=tmdb_master_state(data)
            # If this title has never completed the persistent screen vault, BLUE
            # may still upgrade/repair canonical masters as before.
            needs_art=False
            if cp is not None:
                if cp and cb:hot+=1
                else:needs_art=True
            elif valid_file(p) and backdrop_truth(b):
                hot+=1
            else:
                needs_art=True
            if needs_art:
                missing.append(item)
            else:
                _blue_finish_title(item)
                blue_done+=1
                try:self._folder_artwork_progress.put((blue_done,blue_total))
                except Exception:pass
        # PASS 1: ask TMDB first for every missing title when TMDB is available.
        # If TMDB is disabled/unavailable, continue directly to provider rescue
        # instead of returning with the whole folder still missing.
        # Progress is intentionally NOT reset here. Missing titles continue the
        # same 0..folder-total counter started during preflight.
        tmdb_results={};done=0
        resolver=ArtworkV2(credential,language,timeout) if tmdb_available else None
        if resolver is not None:
            try: resolver.trace_cb=blue_trace
            except Exception: pass
        for item in missing:
            if cancelled():raise _ArtworkCancelled()
            data={}
            resolve_item=dict(item)
            # XStreamity 5.58 behaviour: the native Xtream info endpoint is allowed
            # to contribute IDENTITY/METADATA only before TMDB (tmdb/imdb/year/title
            # aliases).  Provider artwork itself is deliberately ignored here.
            # No provider title search is performed.
            if item.get("_xtream") and hasattr(self.client,"enrich_provider_artwork"):
                try:
                    try: rich=self.client.enrich_provider_artwork(dict(item),media_type,cancel_event,force=True) or {}
                    except TypeError: rich=self.client.enrich_provider_artwork(dict(item),media_type,cancel_event) or {}
                    identity_keys=("tmdb_id","tmdb","imdb_id","imdb","year","releaseDate","release_date","releasedate",
                                   "_provider_name","original_name","original_title","o_name","english_name","english_title")
                    for key in identity_keys:
                        value=rich.get(key) if isinstance(rich,dict) else None
                        if value not in (None,"",[],{}): resolve_item[key]=value
                    blue_trace("IDENTITY_INFO title=%r tmdb_id=%r imdb_id=%r year=%r"%(
                        str(item.get("name") or item.get("title") or "")[:120],resolve_item.get("tmdb_id") or resolve_item.get("tmdb"),
                        resolve_item.get("imdb_id") or resolve_item.get("imdb"),resolve_item.get("year")))
                except Exception as exc:
                    optional_failure("ui.artwork_identity_xtream_info",exc)
                    blue_trace("IDENTITY_INFO_ERROR title=%r error=%r"%(str(item.get("name") or item.get("title") or "")[:120],str(exc)[:140]))
            if resolver is not None:
                # release BLUE turbo mode: explicit Cinematic Cache Artwork is an
                # artwork job, not a full metadata/cast-profile hydration job.  The
                # old full=True path could spend 5-15 seconds per title downloading
                # credits/cast portraits before the next BLUE counter tick.  In
                # exclusive cache mode we resolve identity/poster/logo first, then
                # ask the dedicated backdrop-only path only when the landscape
                # master is still missing.  Existing metadata stays untouched and
                # focused browsing may hydrate it later on demand.
                _blue_fast_art_only=bool(getattr(self,"_folder_artwork_fast_art_only",False))
                # release diagnostic only: for Generation War, record exactly which
                # catalogue/provider identity fields exist and probe TMDB search in
                # both configured locale and English.  These probes DO NOT change
                # the resolver result; they only tell us whether language/alias
                # expansion would find a different identity.
                try:
                    _focus_title=str(item.get("name") or item.get("title") or "").strip()
                    if "generation war" in _focus_title.casefold():
                        _id_fields=("name","title","_raw_name","_provider_name","original_name","original_title","o_name","english_name","english_title","tmdb_id","tmdb","imdb_id","imdb","year","release_date","first_air_date")
                        _parts=[]
                        for _k in _id_fields:
                            _v=resolve_item.get(_k)
                            if _v not in (None,"",[],{}): _parts.append("%s=%r"%(_k,str(_v)[:160]))
                        blue_trace("IDENTITY_FOCUS_INPUT "+" ".join(_parts))
                        _direct=str(resolve_item.get("tmdb_id") or resolve_item.get("tmdb") or "").strip()
                        if _direct.isdigit():
                            try:
                                _det=resolver.tmdb._get("/tv/%s"%_direct,{"language":"en-US"}) or {}
                                blue_trace("IDENTITY_FOCUS_DIRECT id=%s name=%r original=%r year=%r"%(_direct,str(_det.get("name") or "")[:120],str(_det.get("original_name") or "")[:120],str(_det.get("first_air_date") or "")[:10]))
                            except Exception as _exc:
                                blue_trace("IDENTITY_FOCUS_DIRECT_ERROR id=%s error=%r"%(_direct,str(_exc)[:160]))
                        _queries=[]
                        for _k in ("name","title","_raw_name","_provider_name","original_name","original_title","o_name","english_name","english_title"):
                            _q=str(resolve_item.get(_k) or "").strip()
                            if _q and _q not in _queries: _queries.append(_q)
                        _yr=str(resolve_item.get("year") or resolve_item.get("first_air_date") or resolve_item.get("release_date") or "")[:4]
                        for _q in _queries[:8]:
                            for _lang in (language,"en-US"):
                                try:
                                    _params={"query":_q,"language":_lang,"include_adult":"false"}
                                    if _yr.isdigit(): _params["first_air_date_year"]=_yr
                                    _pay=resolver.tmdb._get("/search/tv",_params) or {}
                                    _rs=[]
                                    for _r in (_pay.get("results") or [])[:3]:
                                        _rs.append("%s:%s|%s|%s"%(str(_r.get("id") or ""),str(_r.get("name") or "")[:70],str(_r.get("original_name") or "")[:70],str(_r.get("first_air_date") or "")[:10]))
                                    blue_trace("IDENTITY_FOCUS_SEARCH q=%r lang=%s year=%r top=%r"%(_q,_lang,_yr,_rs))
                                except Exception as _exc:
                                    blue_trace("IDENTITY_FOCUS_SEARCH_ERROR q=%r lang=%s error=%r"%(_q,_lang,str(_exc)[:160]))
                except Exception as _exc:
                    blue_trace("IDENTITY_FOCUS_TRACE_ERROR error=%r"%str(_exc)[:180])
                try:
                    data=resolver.resolve(profile,media_type,resolve_item,full=(not _blue_fast_art_only),cancel_event=cancel_event) or {}
                    if _blue_fast_art_only and not cancelled():
                        # full=False intentionally avoids cast/profile hydration,
                        # but BLUE still promises a real backdrop. Reuse the exact
                        # resolved identity and fetch only that missing component.
                        try:
                            _fresh,_fp,_fb=state(item)
                            if not backdrop_truth(_fb):
                                _back=resolver.resolve_backdrop_only(profile,media_type,resolve_item,cancel_event=cancel_event) or {}
                                if isinstance(_back,dict) and _back:
                                    merged=dict(data);merged.update(_back);data=merged
                        except Exception as _exc:
                            optional_failure("ui.artwork_blue_backdrop_only",_exc)
                except Exception as exc:optional_failure("ui.artwork_tmdb_master",exc);data={}
            tmdb_results[self._page_visual_key(item)]=data
            # resolve() already saves, but re-commit the lightweight per-row pointer
            # after a successful full result. This repairs old localized-title
            # pointers in place without duplicating canonical artwork bytes.
            if isinstance(data,dict) and data.get("matched") and data.get("tmdb_id"):
                try:
                    from .artwork_v2 import save_manifest as _save_artwork_v2_manifest
                    _save_artwork_v2_manifest(profile,media_type,item,data)
                except Exception as exc: optional_failure("ui.artwork_tmdb_pointer_commit",exc)
            try:
                title=str(item.get("name") or item.get("title") or "")[:120]
                _fresh,_fp,_fb=state(item)
                blue_trace("TMDB title=%r matched=%s tmdb_id=%r poster=%s backdrop=%s committed_poster=%s committed_backdrop=%s error=%r"%(title,bool(data.get("matched")),data.get("tmdb_id"),bool(valid_file(data.get("poster_local"))),bool(valid_file(data.get("backdrop_local"))),bool(valid_file(_fp)),bool(backdrop_truth(_fb)),str(data.get("error") or "")[:100]))
            except Exception:pass
            done+=1
            # Do not advance the user-facing title counter yet. This title is not
            # complete until provider rescue (if needed) and the Cinematic/Details
            # finalisation hook have both had their chance.

        # Audit only after the TMDB-first pass. Anything still physically missing
        # may be rescued from the provider/Xtream source. Existing TMDB masters
        # are never replaced because need_p/need_b are based on the shared store.
        rescue=[];poster_missing=0;backdrop_missing=0
        for item in missing:
            data,p,b=state(item);probe=tmdb_results.get(self._page_visual_key(item)) or data or {}
            need_p=not valid_file(p);need_b=not valid_file(b)
            if need_p:poster_missing+=1
            if need_b:backdrop_missing+=1
            # Public rule: TMDB has first refusal. After that pass, every component
            # that is still missing is eligible for provider/Xtream rescue. This
            # also covers identity misses, transient TMDB failures, and catalogues
            # where TMDB has no image. A valid TMDB component is never touched.
            allow_p=bool(need_p)
            allow_b=bool(need_b)
            if allow_p or allow_b:rescue.append((item,allow_p,allow_b))

        # PASS 2: final safety net, matching XStreamity's philosophy. TMDB and
        # Fanart.tv have already had first refusal. Only artwork URLs ALREADY on
        # the catalogue row may be reused here; no provider search/enrichment.
        poster_recovered=0;backdrop_recovered=0
        for item,need_p,need_b in rescue:
            if cancelled():raise _ArtworkCancelled()
            enriched=enrich_provider(item,need_p,need_b)
            purls,burls=provider_candidates(enriched)
            try:
                title=str(item.get("name") or item.get("title") or "")[:120]
                blue_trace("PROVIDER title=%r need_p=%s need_b=%s p_candidates=%d b_candidates=%d xtream=%s"%(title,need_p,need_b,len(purls),len(burls),bool(item.get("_xtream"))))
            except Exception:pass
            provider_p="";provider_b=""
            if need_p:
                for purl in purls:
                    if cancelled():raise _ArtworkCancelled()
                    try:provider_p=_download_portal_artwork(purl,profile,self.client,False,6.0,cancel_event,item=enriched,trace_cb=blue_trace,force_attempt=True) or ""
                    except Exception as exc:optional_failure("ui.artwork_provider_poster_rescue",exc);provider_p=""
                    if valid_file(provider_p):break
                try:blue_trace("PROVIDER_POSTER title=%r success=%s tried=%d"%(str(item.get("name") or item.get("title") or "")[:120],bool(valid_file(provider_p)),len(purls)))
                except Exception:pass
            if need_b:
                for burl in burls:
                    if cancelled():raise _ArtworkCancelled()
                    try:provider_b=_download_portal_artwork(burl,profile,self.client,True,6.5,cancel_event,item=enriched,trace_cb=blue_trace,force_attempt=True) or ""
                    except Exception as exc:optional_failure("ui.artwork_provider_backdrop_rescue",exc);provider_b=""
                    if valid_file(provider_b):break
                try:blue_trace("PROVIDER_BACKDROP title=%r success=%s tried=%d"%(str(item.get("name") or item.get("title") or "")[:120],bool(valid_file(provider_b)),len(burls)))
                except Exception:pass
            if callable(save_manual_rescue_art) and (valid_file(provider_p) or valid_file(provider_b)):
                try:
                    saved=save_manual_rescue_art(profile,media_type,item,
                        poster=(provider_p if need_p and valid_file(provider_p) else None),
                        backdrop=(provider_b if need_b and valid_file(provider_b) else None),
                        source="provider_missing_only") or {}
                    if need_p and valid_file(saved.get("poster_local")):poster_recovered+=1
                    if need_b and valid_file(saved.get("backdrop_local")):backdrop_recovered+=1
                    try:blue_trace("SAVE title=%r poster_saved=%s backdrop_saved=%s"%(str(item.get("name") or item.get("title") or "")[:120],bool(valid_file(saved.get("poster_local"))),bool(valid_file(saved.get("backdrop_local")))))
                    except Exception:pass
                    # The provider downloader is a transport only. Once copied into
                    # fallback_<content-key>.jpg, remove its URL-hash transport file
                    # so there is one persistent master per component, not two.
                    for source,target in ((provider_p,saved.get("poster_local")),(provider_b,saved.get("backdrop_local"))):
                        try:
                            source=str(source or "");target=str(target or "")
                            base=os.path.basename(source)
                            if source and target and source!=target and os.path.isfile(source) and not (base.startswith("movie_") or base.startswith("tv_") or base.startswith("fallback_")):
                                os.unlink(source)
                        except Exception:pass
                except Exception as exc:optional_failure("ui.artwork_provider_rescue_save",exc)

        # Complete every title that entered the missing-art lane, then advance the
        # SAME folder counter exactly once per title. There is no second folder-wide
        # progress pass and no counter restart.
        for item in missing:
            if cancelled():raise _ArtworkCancelled()
            try:_blue_finish_title(item)
            except _ArtworkCancelled:raise
            except Exception as exc:optional_failure("ui.artwork_blue_finish_missing",exc)
            blue_done+=1
            try:self._folder_artwork_progress.put((blue_done,blue_total))
            except Exception:pass

        # Final count from the single shared store; no source is allowed to replace a hit.
        # Count *all* physical recoveries, including TMDB/Fanart, not just provider
        # fallback. This makes the BLUE status agree with what the user can see.
        complete=0;still_p=0;still_b=0;all_p_recovered=0;all_b_recovered=0
        for item in rows:
            data,p,b=state(item)
            p_ok=valid_file(p);b_ok=backdrop_truth(b)
            was_p_missing,was_b_missing=initial_state.get(self._page_visual_key(item),(True,True))
            if was_p_missing and p_ok:all_p_recovered+=1
            if was_b_missing and b_ok:all_b_recovered+=1
            if p_ok and b_ok:
                complete+=1
            else:
                if not p_ok:still_p+=1
                if not b_ok:still_b+=1
        poster_recovered=all_p_recovered
        backdrop_recovered=all_b_recovered
        poster_target=poster_recovered+still_p
        backdrop_target=backdrop_recovered+still_b
        result={"total":len(rows),"done":complete,"work_total":len(missing),"downloaded":poster_recovered+backdrop_recovered,"hot":hot,"failed":still_p+still_b,"poster_missing":poster_target,"backdrop_missing":backdrop_target,"poster_recovered":poster_recovered,"backdrop_recovered":backdrop_recovered,"poster_failed":still_p,"backdrop_failed":still_b,"backdrop_upgrade_candidates":0,"backdrop_upgraded":0,"recovered":poster_recovered}
        try:blue_trace("FINAL total=%d poster_recovered=%d poster_left=%d backdrop_recovered=%d backdrop_left=%d"%(len(rows),poster_recovered,still_p,backdrop_recovered,still_b))
        except Exception:pass
        return result

    def cache_folder_artwork(self):
        if self.media_type not in ("vod","series"):return
        if self._folder_artwork_cache_running:
            self["status"].setText(_("Artwork check is already running"));return
        # A new explicit BLUE run owns a fresh progress/finalisation lifecycle.
        # Drop stale terminal/progress events from an older receiver callback so
        # a completed N/N cannot be overwritten by yesterday's queue state.
        try:
            while True:self._folder_artwork_progress.get_nowait()
        except Exception:
            pass
        self._folder_artwork_ui_finalized=False
        self["blue"].setText(_("Checking..."))
        self["status"].setText(_("Checking current folder for missing artwork..."))

        def catalog_ready(rows):
            rows=[dict(x) for x in (rows or []) if isinstance(x,dict)]
            if not rows:
                self._folder_artwork_ui_finalized=True
                self["blue"].setText(_("Check Artwork"));self["status"].setText(_("Folder is empty"));return
            self._folder_artwork_cache_running=True
            self._folder_artwork_cache_done=0;self._folder_artwork_cache_total=0
            def ok(result):
                # The worker also posts a terminal progress event so Enigma2 can
                # finalise even when the normal async callback is delayed. This
                # helper is idempotent and therefore safe from either path.
                self._apply_folder_artwork_result(result)
            def failed(error):
                if getattr(self,"_folder_artwork_ui_finalized",False):return
                self._folder_artwork_ui_finalized=True
                self._folder_artwork_cache_running=False
                self["blue"].setText(_("Check Artwork"));self._refresh_search_sort_controls()
                self["status"].setText(_friendly_error(error))
            def cache_job(handle):
                # release: BLUE must run the screen-specific cache worker so
                # presentation derivatives are finished before the folder is done.
                result=self._cache_folder_artwork_worker(rows,handle.cancel_event) or {}
                try:self._folder_artwork_progress.put(("__complete__",result))
                except Exception:pass
                return result
            self._run_async(cache_job,ok,failed)
        # Explicit BLUE always inventories the CURRENT folder only.
        self._ensure_folder_catalog(catalog_ready)

    def open_folder_search(self):
        if self.media_type not in ("vod","series"):return
        title=_("Search in %s")%self.category_title
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard as E2VirtualKeyBoard
        except Exception:
            E2VirtualKeyBoard=None
        if E2VirtualKeyBoard is not None:
            self.session.openWithCallback(self._folder_search_entered,E2VirtualKeyBoard,title=title,text=self._search_query)
        else:
            self.session.openWithCallback(self._folder_search_entered,InputBox,title=title,text=self._search_query,maxSize=60)

    def _folder_search_entered(self,term=None):
        if term is None:return
        # VirtualKeyBoard may return non-str text wrappers on some images. Keep
        # the callback fail-soft, then invalidate any older normal-page request
        # before the filtered view is painted. Without this guard a late page
        # callback can overwrite Search and make it look as if OK did nothing.
        try:
            if isinstance(term,bytes):term=term.decode("utf-8","ignore")
            elif isinstance(term,(list,tuple)) and len(term)==1:term=term[0]
        except Exception:pass
        # Empty input intentionally resets Search while preserving the current Sort.
        self._search_query=one_line(term or "",60)
        try:
            pending=getattr(self,"_page_load_handle",None)
            if pending is not None:
                try:pending.cancel()
                except Exception:pass
            self._pending_page_request=None
            old_cancel=getattr(self,"_page_prefetch_cancel",None)
            if old_cancel is not None:old_cancel.set()
            self._page_prefetch_generation=int(getattr(self,"_page_prefetch_generation",0) or 0)+1
        except Exception as exc:optional_failure("ui.folder_search_cancel_stale_page",exc)
        self._refresh_search_sort_controls()
        try:self["status"].setText((_("Searching...") if self._search_query else _("Loading folder...")))
        except Exception:pass
        def ready(_rows):
            self._load_folder_view_page(1,0)
        self._ensure_folder_catalog(ready)

    def cycle_folder_sort(self):
        if self.media_type not in ("vod","series"):return
        next_mode=(self._sort_mode+1)%len(self._FOLDER_SORT_LABELS)
        def ready(_rows):
            self._sort_mode=next_mode
            self._refresh_search_sort_controls()
            self._load_folder_view_page(1,0)
        self._ensure_folder_catalog(ready)

    def _portal_page(self, page, cancel_event=None):
        page=max(1,int(page))
        if cancel_event is not None and cancel_event.is_set():
            raise _ArtworkCancelled()
        if page in self._portal_page_cache:
            items = self._portal_page_cache[page]
            self._portal_page_cache.move_to_end(page)
            return items
        result=self.client.ordered_page(self.media_type,self.genre,page,cancel_event=cancel_event)
        if cancel_event is not None and cancel_event.is_set():
            raise _ArtworkCancelled()
        items=[x for x in result.get("items",[]) if isinstance(x,dict)]
        if (not items and self._grid_is_m3u_source() and self.media_type in ("vod","series")
                and str(getattr(self,"category_title","") or "").strip()
                and str(getattr(self,"category_title","") or "").strip()!=str(self.genre or "").strip()):
            try:
                alt=self.client.ordered_page(self.media_type,str(self.category_title).strip(),page,cancel_event=cancel_event) or {}
                alt_items=[x for x in alt.get("items",[]) if isinstance(x,dict)]
                if alt_items:result=alt;items=alt_items
            except Exception as exc:optional_failure("ui.m3u_category_title_retry",exc)
        self._portal_page_cache[page]=items
        self._portal_page_cache.move_to_end(page)
        while len(self._portal_page_cache) > self._portal_page_cache_limit:
            self._portal_page_cache.popitem(last=False)
        if not self._portal_page_size:
            self._portal_page_size=max(1,int(result.get("page_size") or len(items) or self.page_size))
        self._portal_total=max(self._portal_total,int(result.get("total") or 0))
        return items

    def _runtime_grid_close(self):
        if getattr(self,"media_type",None)=="itv":
            _live_restart_trace("grid_close",page=int(getattr(self,"page",0) or 0),index=int(getattr(self,"index",0) or 0),
                                generation=int(getattr(self,"_grid_generation",0) or 0),
                                inflight=len(getattr(self,"_grid_download_inflight",{}) or {}))
        try:
            cancel=getattr(self,"_page_prefetch_cancel",None)
            if cancel is not None:cancel.set()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:self._cancel_detached_page_prefetch_futures()
        except Exception as exc:optional_failure("ui.grid_detached_future_close",exc)
        _runtime_endurance_log("grid_close",media_type=self.media_type,page=getattr(self,"page",0),items=len(getattr(self,"grid_items",[]) or []))

    def _grid_page_data(self, target, cancel_event=None):
        # The portal's native page size is often 14 while our poster grid is 12
        # and live grid is 24. Stitch native pages before slicing so no item is
        # skipped and the original portal order stays exact.
        target=max(1,int(target))
        if not self._portal_page_size:
            self._portal_page(1,cancel_event=cancel_event)
        native=max(1,self._portal_page_size)
        start=(target-1)*self.page_size;end=start+self.page_size
        if self._portal_total and start>=self._portal_total:
            return []
        first=(start//native)+1;last=((max(start,end-1))//native)+1
        merged=[]
        for native_page in range(first,last+1):
            if cancel_event is not None and cancel_event.is_set():
                raise _ArtworkCancelled()
            merged.extend(self._portal_page(native_page,cancel_event=cancel_event))
        base=(first-1)*native
        return merged[max(0,start-base):max(0,end-base)]

    def _prepare_grid_page(self,target,cancel_event=None):
        """Fetch one page and return first-paint data with zero image generation.

        Test69 Lean contract: catalogue/state reads may happen here, but Pillow,
        adaptive chrome, thumbnail creation and visual-bundle writes never block
        the page becoming visible.  Any missing deterministic derivative is built
        only after the original poster has already painted.
        """
        data=self._grid_page_data(target,cancel_event)
        valid=[x for x in data if isinstance(x,dict)] if isinstance(data,list) else []
        if self.media_type in ("vod","series"):
            prepared_valid=[]
            for x in valid:
                if not isinstance(x,dict):continue
                if x.get("_xtream"):
                    row=dict(x);visible_provider=str(_image_url(row) or "").strip()
                else:
                    raw=dict(x)
                    visible_provider=str(raw.get("_visible_provider_art_url") or raw.get("_rescue_provider_art_url") or _image_url(raw) or "").strip()
                    visible_backdrop=""
                    try:
                        from .ui_artwork_helpers import _backdrop_url as _visible_backdrop_url
                        visible_backdrop=str(raw.get("_visible_provider_backdrop_url") or raw.get("_rescue_provider_backdrop_url") or _visible_backdrop_url(raw) or "").strip()
                    except Exception:
                        visible_backdrop=str(raw.get("_visible_provider_backdrop_url") or raw.get("_rescue_provider_backdrop_url") or "").strip()
                    row=_strip_portal_artwork(raw)
                    if visible_provider:row["_visible_provider_art_url"]=visible_provider
                    if visible_backdrop:row["_visible_provider_backdrop_url"]=visible_backdrop
                prepared_valid.append(row)
            valid=prepared_valid
            try:
                art_counts={}
                for row in valid:
                    value=str(row.get("_visible_provider_art_url") or _image_url(row) or "").strip()
                    if value:art_counts[value]=art_counts.get(value,0)+1
                generic_urls={url for url,count in art_counts.items() if count>=3}
                for row in valid:
                    value=str(row.get("_visible_provider_art_url") or _image_url(row) or "").strip()
                    if value in generic_urls:
                        row["_generic_provider_art"]=True;row["_generic_provider_art_url"]=value
            except Exception as exc:optional_failure("ui.generic_provider_art_detect",exc)

        states=load_content_states(self.profile,self.media_type,valid) if valid else []
        qualities=load_content_qualities(self.profile,self.media_type,valid) if valid and self.media_type in ("vod","series") else ["" for _ in valid]
        state_rows=[];cfg=self._grid_settings or {}
        prepared_titles=[];prepared_fitted=[];prepared_meta=[];prepared_art=[]
        for pos,item in enumerate(valid):
            state=states[pos] if pos<len(states) else {}
            quality=qualities[pos] if pos<len(qualities) else ""
            row=dict(state or {});row["quality"]=quality or "";state_rows.append(row)
            raw=item.get("name") or item.get("title") or item.get("id") or "Item"
            title=_clean_live_channel_name(raw) if self.media_type=="itv" else _catalogue_title(raw)
            prepared_titles.append(title)
            if self.media_type=="itv":
                prepared_fitted.append((one_line(title,36),None));prepared_meta.append(str((target-1)*self.page_size+pos+1))
            else:
                fitted_title,fitted_font=_grid_fit_card_title(title,226)
                prepared_fitted.append((fitted_title,int(fitted_font)))
                bits=[];explicit=self._explicit_item_quality(item)
                badges=explicit or str(row.get("quality") or "") or quality_badges(raw)
                if badges:bits.append(badges)
                if item.get("year"):bits.append(str(item.get("year"))[:4])
                if row.get("favorite"):bits.append("★")
                if row.get("completed") and cfg.get("show_watched",True):bits.append("WATCHED")
                elif row.get("position") and row.get("duration"):bits.append("%d%%"%min(99,int(row["position"]*100.0/row["duration"])))
                prepared_meta.append("  •  ".join(bits)[:28])

            # release Stage 3: page preparation is catalogue/RAM-only.  Do not walk
            # per-title detail snapshots, manifests or generated bundles while a
            # page request is being prepared.  Warm visuals already held in the
            # screen RAM cache are reused immediately; persistent HDD truth is
            # resolved by the bounded visible-card worker after first paint.
            # This keeps page transitions independent of HDD latency even with a
            # large persistent artwork library.
            art_row=self._page_visual_get(item) if self.media_type in ("vod","series") else {}
            prepared_art.append(art_row)
        return {"items":valid,"states":state_rows,"titles":prepared_titles,"fitted":prepared_fitted,"meta":prepared_meta,"art":prepared_art}

    def _cache_prepared_page(self,target,payload):
        if not isinstance(payload,dict):return
        with self._prepared_page_lock:
            self._prepared_page_cache[int(target)]=payload
            self._prepared_page_cache.move_to_end(int(target))
            while len(self._prepared_page_cache)>max(4,int(getattr(self,"_prepared_page_cache_limit",4) or 4)):self._prepared_page_cache.popitem(last=False)
            self._prepared_page_pending.discard(int(target))

    def _stop_progressive_poster_prefetch(self):
        try:self._progressive_poster_cancel.set()
        except Exception as exc:optional_failure("ui.progressive_poster_stop",exc)
        self._progressive_poster_started=False

    def _progressive_poster_item(self,item,cancel_event):
        """Hydrate one visible poster without letting the worker retain this Screen."""
        if self._screen_closed:return "",{}
        return _progressive_poster_item_detached(
            self.profile,self.media_type,item,self._grid_settings or {},self.client,cancel_event)

    def _start_progressive_poster_prefetch(self):
        """Start lazy hydration for the current visible page only."""
        if self._screen_closed or self.media_type not in ("vod","series") or not self.grid_items:
            return
        self._progressive_poster_started=True
        try:self._prefetch_visible_page_details(priority_index=self.index,max_items=self.page_size)
        except Exception as exc:optional_failure("ui.auto_visible_page_start",exc)
        try:self._prefetch_visible_tmdb_metadata()
        except Exception as exc:optional_failure("ui.auto_visible_tmdb_start",exc)


    def _prefetch_visible_tmdb_metadata(self):
        """Hydrate TMDb metadata for all visible cards on a dedicated lane.

        Poster loading keeps its original fast executor and is never queued behind
        TMDb work. Ratings update independently as their results arrive.
        """
        if self._screen_closed or self.media_type not in ("vod","series") or not self.grid_items:
            return
        generation=int(getattr(self,"_page_prefetch_generation",0) or 0)
        cancel_event=getattr(self,"_page_prefetch_cancel",None)
        profile=dict(self.profile or {})
        media_type=str(self.media_type or "")
        cfg=dict(self._grid_settings or {})
        credential=str(cfg.get("tmdb_credential") or "").strip()
        if not (cfg.get("tmdb_enabled",True) and credential):
            return
        result_q=self._art_prefetch_jobs

        for pos,item in enumerate(self.grid_items[:self.page_size]):
            if not isinstance(item,dict):
                continue
            key=self._page_visual_key(item)
            if not key:
                continue
            try:
                existing=float(item.get("_tmdb_rating") or 0)
            except Exception:
                existing=0.0
            if not (0.0 < existing <= 10.0):
                try:
                    existing=float(self._visible_tmdb_rating_cache.get(key) or 0)
                    if 0.0 < existing <= 10.0:
                        item["_tmdb_rating"]=existing
                        self._card_rating_layout(item,pos,self._card_meta(item,pos))
                except Exception:
                    existing=0.0
            if 0.0 < existing <= 10.0:
                continue

            pending_key=(generation,key)
            try:
                with self._page_prefetch_lock:
                    if pending_key in self._visible_tmdb_pending:
                        continue
                    self._visible_tmdb_pending.add(pending_key)
            except Exception:
                pass

            def worker(it=dict(item), k=key, gen=generation, cancel=cancel_event, pk=pending_key):
                try:
                    if cancel is not None and cancel.is_set():
                        return False
                    try:
                        data=ArtworkV2(
                            credential,
                            cfg.get("tmdb_language","ar-EG"),
                            min(5,max(3,int(cfg.get("timeout",10) or 10)))
                        ).resolve(profile,media_type,it,full=True,cancel_event=cancel) or {}
                    except Exception as exc:
                        optional_failure("ui.visible_tmdb_metadata",exc)
                        return False
                    if cancel is not None and cancel.is_set():
                        return False
                    meta={
                        "tmdb_id":data.get("tmdb_id"),
                        "media_type":data.get("media_type") or ("tv" if media_type=="series" else "movie"),
                        "rating":data.get("rating") or data.get("vote_average"),
                        "year":data.get("year") or data.get("release_date") or data.get("first_air_date"),
                        "release_date":data.get("release_date") or data.get("first_air_date") or "",
                        "palette_source":"",
                    }
                    if meta.get("tmdb_id") or meta.get("rating"):
                        result_q.put((gen,k,"",meta))
                        return True
                    return False
                finally:
                    try:
                        with self._page_prefetch_lock:
                            self._visible_tmdb_pending.discard(pk)
                    except Exception:
                        pass

            try:
                future=_VISIBLE_TMDB_EXECUTOR.submit(worker,_task_key="grid-tmdb:%x:%s:%s"%(id(self),generation,key))
                self._page_prefetch_futures.append(future)
            except Exception as exc:
                try:
                    with self._page_prefetch_lock:
                        self._visible_tmdb_pending.discard(pending_key)
                except Exception:
                    pass
                optional_failure("ui.visible_tmdb_metadata_submit",exc)

    def _prefetch_focused_artwork(self):
        """Hydrate poster + real backdrop for the stable focused title only."""
        if self._screen_closed or self.media_type not in ("vod","series") or not self.grid_items:
            return
        try:item=self.grid_items[max(0,min(self.index,len(self.grid_items)-1))]
        except Exception:return
        if not isinstance(item,dict):return
        cfg=self._grid_settings or {};credential=str(cfg.get("tmdb_credential") or "").strip()
        if not (cfg.get("tmdb_enabled",True) and cfg.get("load_images",True) and credential):return
        key=self._page_visual_key(item)
        generation=int(getattr(self,"_page_prefetch_generation",0) or 0)
        cancel_event=getattr(self,"_page_prefetch_cancel",None)
        def hydrate_focus(it=dict(item),k=key,gen=generation,cancel=cancel_event):
            if cancel is not None and cancel.is_set():return False
            try:
                data=ArtworkV2(credential,cfg.get("tmdb_language","ar-EG"),min(6,max(3,int(cfg.get("timeout",10) or 10)))).resolve(
                    self.profile,self.media_type,it,full=True,cancel_event=cancel) or {}
                # Publish a poster repaint too, because a focused title is allowed
                # to overtake the normal visible-card queue.  Details reads the
                # persisted canonical backdrop directly from the same result.
                poster=str(data.get("poster_local") or "")
                if poster and os.path.isfile(poster) and gen==int(getattr(self,"_page_prefetch_generation",0) or 0):
                    self._art_prefetch_jobs.put((gen,k,poster,{
                        "tmdb_id":data.get("tmdb_id"),
                        "media_type":data.get("media_type") or ("tv" if self.media_type=="series" else "movie"),
                        "rating":data.get("rating") or data.get("vote_average"),
                        "year":data.get("year") or data.get("release_date") or data.get("first_air_date"),
                        "release_date":data.get("release_date") or data.get("first_air_date") or "",
                        "palette_source":poster,
                    }))
                return bool(data.get("poster_local") or data.get("backdrop_local"))
            except Exception as exc:
                optional_failure("ui.auto_focused_artwork",exc);return False
        try:_DETAIL_PREFETCH_EXECUTOR.submit(hydrate_focus,priority=0,_task_key="focus-art:%s"%key)
        except Exception as exc:optional_failure("ui.auto_focused_art_submit",exc)

    def _refresh_prepared_m3u_art_from_hdd(self,payload):
        """Refresh a prepared M3U page from HDD only, never network."""
        if not self._grid_is_m3u_source() or self.media_type not in ("vod","series") or not isinstance(payload,dict):
            return payload
        items=list(payload.get("items") or [])
        art=list(payload.get("art") or [])
        while len(art)<len(items):art.append({})
        for pos,item in enumerate(items):
            if not isinstance(item,dict):continue
            row=dict(art[pos] or {})
            if row.get("display") or row.get("poster"):
                row["visual_locked"]=True;art[pos]=row;continue
            try:
                snap=(load_shared_detail_snapshot(self.profile,self.media_type,item)
                      if item.get("_xtream") else load_detail_snapshot(self.profile,self.media_type,item))
                bundle=_load_visual_bundle(self.profile,self.media_type,item,snap) or {}
                display=str(bundle.get("grid_thumb") or bundle.get("poster") or "")
                poster=str(bundle.get("poster") or "")
                if display and os.path.isfile(display):
                    row["display"]=display;row["palette"]=poster or display;row["visual_locked"]=True
                    card=str(bundle.get("grid_card") or "")
                    if card and os.path.isfile(card):row["card"]=card
                elif poster and os.path.isfile(poster):
                    row["poster"]=poster;row["visual_locked"]=True
            except Exception as exc:optional_failure("ui.m3u_prepared_hdd_refresh",exc)
            art[pos]=row
        payload=dict(payload);payload["art"]=art
        return payload

    def _warm_m3u_prepared_page_art(self,payload):
        """Schedule adjacent M3U VOD/Series through the global hydration lane."""
        if not self._grid_is_m3u_source() or self.media_type not in ("vod","series") or not isinstance(payload,dict):return
        cfg=self._grid_settings or {};credential=str(cfg.get("tmdb_credential") or "").strip()
        if not (cfg.get("tmdb_enabled",True) and cfg.get("load_images",True) and credential):return
        for item in [dict(x) for x in (payload.get("items") or []) if isinstance(x,dict)][:self.page_size]:
            if self._screen_closed:return
            def hydrate(it=item):
                try:
                    snap=load_shared_detail_snapshot(self.profile,self.media_type,it) if it.get("_xtream") else load_detail_snapshot(self.profile,self.media_type,it)
                    bundle=_load_visual_bundle(self.profile,self.media_type,it,snap) or {}
                    if str(bundle.get("poster") or "") and os.path.isfile(str(bundle.get("poster") or "")):return True
                    data=ArtworkV2(credential,cfg.get("tmdb_language","ar-EG"),min(5,max(3,int(cfg.get("timeout",10) or 10)))).resolve(self.profile,self.media_type,it,full=True,cancel_event=None) or {}
                    return bool(data.get("matched"))
                except Exception as exc:optional_failure("ui.m3u_adjacent_global_warm",exc);return False
            try:_DETAIL_PREFETCH_EXECUTOR.submit(hydrate,priority=2,_task_key="hydrate:%s"%self._page_visual_key(item))
            except Exception as exc:optional_failure("ui.m3u_adjacent_art_submit",exc)

    def _prefetch_adjacent_pages(self):
        """Test69 Lean: explicit page navigation loads pages on demand."""
        return

    def _warm_poster_grid_catalogue_pages(self):
        """Warm neighbouring Poster Grid pages like Cinematic, without artwork work.

        Only VOD/Series provider catalogue + persisted state are prepared.  No
        poster/backdrop downloads, TMDB calls, Pillow generation or adaptive
        chrome is started here.  The next/previous page therefore enters through
        _prepared_page_cache immediately while card artwork remains cache-first.
        """
        if getattr(self,"_screen_closed",False) or self.media_type not in ("vod","series"):
            return
        if getattr(self,"_view_active",False):
            return
        total=int(self._active_total() or 0)
        if total<=int(self.page_size or 1):
            return
        total_pages=max(1,(total+int(self.page_size or 1)-1)//int(self.page_size or 1))
        current=max(1,min(int(self.page or 1),total_pages))
        # Prioritise the direction users normally browse: next page first, then
        # previous page second. Two prepared pages keep navigation hot without
        # turning provider catalogue work into background contention without turning a large catalogue into a RAM scan.
        targets=[]
        for target in (current+1,current-1):
            if target<1 or target>total_pages or target==current or target in targets:
                continue
            targets.append(target)
        if not targets:
            return
        self._grid_page_warm_token=int(getattr(self,"_grid_page_warm_token",0) or 0)+1
        token=self._grid_page_warm_token
        def worker():
            try:
                for target in targets:
                    if getattr(self,"_screen_closed",False) or token!=int(getattr(self,"_grid_page_warm_token",0) or 0):
                        break
                    with self._prepared_page_lock:
                        if target in self._prepared_page_cache or target in self._prepared_page_pending:
                            continue
                        self._prepared_page_pending.add(target)
                    try:
                        payload=self._prepare_grid_page_resilient(target,None)
                        if payload and token==int(getattr(self,"_grid_page_warm_token",0) or 0):
                            self._cache_prepared_page(target,payload)
                        else:
                            with self._prepared_page_lock:self._prepared_page_pending.discard(target)
                    except Exception as exc:
                        with self._prepared_page_lock:self._prepared_page_pending.discard(target)
                        optional_failure("ui.poster_grid_catalogue_warm",exc)
            finally:
                if token==int(getattr(self,"_grid_page_warm_token",0) or 0):
                    self._grid_page_warm_running=False
        # A newer page transition supersedes an older neighbour plan.  We do not
        # cancel the provider call mid-socket; the token simply prevents stale
        # payloads from taking over the active warm set.
        if getattr(self,"_grid_page_warm_running",False):
            return
        self._grid_page_warm_running=True
        try:_GRID_PAGE_WARM_EXECUTOR.submit(worker)
        except Exception as exc:
            self._grid_page_warm_running=False;optional_failure("ui.poster_grid_catalogue_warm_submit",exc)

    def _apply_prepared_page(self,target,payload,restore_index=None):
        if self._grid_is_m3u_source() and self.media_type in ("vod","series"):
            payload=self._refresh_prepared_m3u_art_from_hdd(payload)
        valid=list((payload or {}).get("items") or [])
        if not valid and target>1:
            self["status"].setText(_("No more items"));return False
        if not valid and target==1:
            # Do not paint an empty child HUD.  After bounded recovery has been
            # exhausted, return to the already-rendered Categories screen with a
            # useful status instead of showing Page 1/1 / Movie 1/1 with no card.
            message=_("No content returned for this category. Try Refresh.")
            try:self["status"].setText(message)
            except Exception:pass
            try:self.close(("content_load_error",message))
            except Exception as exc:optional_failure("ui.grid_initial_empty_close",exc)
            return False
        self.page=target;self.grid_items=valid
        state_rows=list((payload or {}).get("states") or [])
        self._grid_item_state={}
        for item,row in zip(self.grid_items,state_rows):self._grid_item_state[id(item)]=dict(row or {})
        self._prepared_titles_for_render=list((payload or {}).get("titles") or [])
        self._prepared_fitted_for_render=list((payload or {}).get("fitted") or [])
        self._prepared_meta_for_render=list((payload or {}).get("meta") or [])
        self._prepared_art_for_render=list((payload or {}).get("art") or [])
        self.index=max(0,min(int(restore_index or 0),len(valid)-1)) if valid else 0
        self._grid_full_chrome_warm=False
        self._render_grid();self._remember_grid_state()
        try:_ui_diag("ui_page_ready",screen="grid",media_type=self.media_type,page=self.page,items=len(self.grid_items),
                     elapsed_ms=int(max(0.0,(time.monotonic()-float(getattr(self,"_ui_diag_page_request_mono",time.monotonic())))*1000.0)))
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.1171",exc)
        total=int(self._portal_total or 0)
        total_pages=max(1,(total+self.page_size-1)//self.page_size) if total else max(1,self.page)
        absolute=min(total,(self.page-1)*self.page_size+self.index+1) if total else ((self.page-1)*self.page_size+self.index+1)
        kind="Channel" if self.media_type=="itv" else ("Movie" if self.media_type=="vod" else "Series")
        self["status"].setText("")
        self["page_label"].setText(_("Page %d / %d  •  %s %d / %d")%(self.page,total_pages,kind,absolute,total or absolute))
        # release zero-button artwork: first paint remains cache-first, then only
        # the visible cards are queued for poster hydration. No adjacent pages or
        # folder-wide scan is started here.
        try:self._start_progressive_poster_prefetch()
        except Exception as exc:optional_failure("ui.auto_visible_page",exc)
        # release: same catalogue-only neighbour warming that made Cinematic
        # page changes immediate.  It runs after first paint and never touches
        # artwork, so remote-control movement keeps GUI priority.
        try:self._warm_poster_grid_catalogue_pages()
        except Exception as exc:optional_failure("ui.poster_grid_catalogue_warm_start",exc)
        return True

    def load_page(self,page,restore_index=None):
        if self.media_type=="itv":
            _live_restart_trace("page_request",page=int(page or 1),current_page=int(getattr(self,"page",0) or 0),
                                index=int(getattr(self,"index",0) or 0),generation=int(getattr(self,"_grid_generation",0) or 0),
                                inflight=len(getattr(self,"_grid_download_inflight",{}) or {}))
        if self.media_type in ("vod","series") and self._view_active and isinstance(self._folder_catalog,list):
            self._load_folder_view_page(page,restore_index);return
        target=max(1,int(page))
        if self.media_type=="series":
            self._stop_series_hierarchy_prefetch()
        self._ui_diag_page_request_mono=time.monotonic();self._ui_diag_page_target=target;self._ui_diag_first_poster_logged=False
        with self._prepared_page_lock:
            prepared=self._prepared_page_cache.pop(target,None)
        # Never trust a cached empty first page.  An empty portal/API response is
        # indistinguishable from the transient loader/cache miss that previously
        # left a fully drawn but content-less grid on screen.
        if prepared is not None and target==1 and not list((prepared or {}).get("items") or []):
            prepared=None
        if prepared is not None:
            self._apply_prepared_page(target,prepared,restore_index)
            return
        # Page navigation is an explicit user action. Clear only transient
        # breaker state left by cancelled previews/prefetch workers.
        try:self.client.reset_failure_backoff()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        if self._busy:
            self._pending_page_request=(target,restore_index)
            old=getattr(self,"_page_load_handle",None)
            if old is not None:
                try: old.cancel()
                except Exception as exc: optional_failure("ui.page_load_cancel", exc)
            # This screen serializes only its portal page request. The cancelled
            # worker receives its own cancel_event and exits without touching
            # sockets used by other screens.
            self._busy=False
        self._pending_page_request=None
        self["status"].setText(_("Loading page %d...")%target)
        # Cancel the previous page as soon as navigation starts, not only after
        # the next portal response arrives. Downloads already reading data abort
        # at the next chunk boundary and no new external enrichment is started.
        try:
            old_cancel=getattr(self,"_page_prefetch_cancel",None)
            if old_cancel is not None:old_cancel.set()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._cancel_detached_page_prefetch_futures()
        for future in list(getattr(self,"_page_prefetch_futures",[]) or []):
            try:future.cancel()
            except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._page_prefetch_futures=[]
        self._page_prefetch_cancel=threading.Event()
        try:self._page_prefetch_generation+=1
        except Exception:self._page_prefetch_generation=1
        request_generation=self._page_prefetch_generation
        try:
            with self._page_prefetch_lock:
                self._page_prefetch_seen.clear(); self._visible_tmdb_pending.clear(); self._page_quality_seen.clear(); self._page_art_retry_count.clear()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        _runtime_endurance_log("grid_page_request",media_type=self.media_type,page=target,prefetch_generation=request_generation)
        def ok(data):
            if request_generation!=int(getattr(self,"_page_prefetch_generation",0) or 0):return
            # Network result is prepared off the GUI thread before this callback
            # whenever possible. Fallback preparation here is only for page 1 or
            # a cache miss and is still shared with the RAM-prefetch path.
            payload=self._prepare_grid_page(target,None) if not isinstance(data,dict) else data
            self._apply_prepared_page(target,payload,restore_index)
            _runtime_endurance_log("grid_page",media_type=self.media_type,page=self.page,items=len(self.grid_items),prefetch_generation=self._page_prefetch_generation)
        def failed(e):
            if request_generation==int(getattr(self,"_page_prefetch_generation",0) or 0):
                # Silent self-heal owns normal one-shot network failures. Only
                # expose a final error after all bounded attempts really fail.
                # If an older page is still painted, keep it visually clean.
                kind=_catalogue_error_kind(e)
                if kind=="transient" and getattr(self,"grid_items",None):
                    # A page-change failure never destroys the last-good page.
                    self["status"].setText("")
                else:
                    message=_("Content temporarily unavailable. Try again.") if kind=="transient" else _friendly_error(e)
                    self["status"].setText(message)
                    # On an initial category open there is no last-good grid to
                    # preserve.  Do not leave a blank poster/backdrop/cinematic
                    # surface: return to the already-painted Categories screen
                    # and carry the final error back to its status line.
                    if not getattr(self,"grid_items",None):
                        try:self.close(("content_load_error",message))
                        except Exception as exc:optional_failure("ui.grid_initial_error_close",exc)
                _runtime_endurance_log("grid_page_error",media_type=self.media_type,page=target,error_kind=kind)
        self._page_load_handle=self._run_async(lambda handle:self._prepare_grid_page_resilient(target,handle.cancel_event),ok,failed)

    def _prepare_grid_page_resilient(self,target,cancel_event=None):
        """Retry only transient catalogue reads inside the same grid screen.

        This intentionally mirrors the user's successful manual second-arrow /
        BACK-and-enter recovery, but does it without repainting an error between
        attempts. Artwork/TMDB/player work is not retried here.
        """
        last_error=None
        delays=(0.0,0.18,0.42,0.75)
        for attempt,delay in enumerate(delays):
            if cancel_event is not None and cancel_event.is_set():
                raise _ArtworkCancelled()
            if attempt:
                if cancel_event is not None and getattr(cancel_event,"wait",lambda _x:False)(delay):
                    raise _ArtworkCancelled()
                try:
                    close_pending=getattr(self.client,"cancel_pending_requests",None)
                    if callable(close_pending):close_pending()
                except Exception as exc:optional_failure("ui.grid_retry_transport",exc)
                try:
                    reset=getattr(self.client,"reset_failure_backoff",None)
                    if callable(reset):reset()
                except Exception as exc:optional_failure("ui.grid_retry_backoff",exc)
                # Match the proven Categories recovery path.  On the third
                # transient attempt establish one fresh authorized portal
                # session; this is the programmatic equivalent of the manual
                # refresh/re-enter that users report immediately succeeding.
                if attempt==2:
                    try:
                        authorize=getattr(self.client,"authorize",None)
                        if callable(authorize):
                            try:authorize(cancel_event=cancel_event)
                            except TypeError:authorize()
                    except Exception as exc:
                        last_error=exc
                        optional_failure("ui.grid_retry_authorize",exc)
            try:
                payload=self._prepare_grid_page(target,cancel_event)
                if target==1 and not list((payload or {}).get("items") or []):
                    # Successful-but-empty first responses are a known MAG/Xtream
                    # failure mode.  Drop only the per-screen catalogue page
                    # cache and advance this portal's API cache generation once,
                    # then let the existing bounded retry/reauthorize lane run.
                    if attempt < len(delays)-1:
                        try:self._portal_page_cache.clear()
                        except Exception:pass
                        self._portal_page_size=0;self._portal_total=0
                        if not getattr(self,"_grid_empty_generation_bumped",False):
                            try:
                                bump=getattr(self.client,"_bump_content_cache_generation",None)
                                if callable(bump):bump()
                            except Exception as bump_exc:
                                optional_failure("ui.grid_empty_cache_generation",bump_exc)
                            self._grid_empty_generation_bumped=True
                        last_error=Exception("Empty catalogue response")
                        _runtime_endurance_log("grid_page_empty_retry",media_type=self.media_type,page=target,attempt=attempt+1)
                        continue
                return payload
            except _ArtworkCancelled:
                raise
            except Exception as exc:
                last_error=exc
                kind=_catalogue_error_kind(exc)
                _runtime_endurance_log("grid_page_retry",media_type=self.media_type,page=target,attempt=attempt+1,error_kind=kind)
                if kind!="transient" or attempt>=len(delays)-1:
                    raise
        raise last_error or Exception("Catalogue request failed")

    def _render_grid(self):
        if self.media_type=="itv":
            _live_restart_trace("render_begin",page=int(getattr(self,"page",0) or 0),index=int(getattr(self,"index",0) or 0),
                                generation=int(getattr(self,"_grid_generation",0) or 0),
                                items=len(getattr(self,"grid_items",[]) or []),inflight=len(getattr(self,"_grid_download_inflight",{}) or {}))
        self._grid_cancel_queued_downloads()
        self._grid_generation+=1;self._grid_decode_queue=[];self._grid_waiting={};self._grid_queued=set();self._grid_slot_paths={};self._grid_palette_sources={};self._grid_card_paths={};self._grid_display_titles={};self._grid_visual_locks={}
        cfg=self._grid_settings or {}
        self._grid_prepared_art={pos:row for pos,row in enumerate(getattr(self,"_prepared_art_for_render",[]) or [])}
        for pos in range(self.page_size):
            title_widget=self["item_title%d"%pos];meta_widget=self["item_meta%d"%pos];art=self["art%d"%pos]
            if pos>=len(self.grid_items):
                title_widget.setText("");meta_widget.setText("")
                widgets=[art,title_widget,meta_widget]
                if self.media_type in ("vod","series"):
                    for _n in ("item_year%d"%pos,"item_star%d"%pos,"item_score%d"%pos):
                        try:widgets.append(self[_n])
                        except Exception:pass
                try:widgets.append(self["card_chrome%d"%pos])
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                for widget in widgets:
                    try:widget.hide()
                    except Exception as exc:optional_failure("ui",exc)
                continue
            item=self.grid_items[pos];raw=item.get("name") or item.get("title") or item.get("id") or "Item"
            prepared_titles=getattr(self,"_prepared_titles_for_render",[]) or []
            title=prepared_titles[pos] if pos<len(prepared_titles) else (_clean_live_channel_name(raw) if self.media_type=="itv" else _catalogue_title(raw))
            self._grid_display_titles[pos]=title
            prepared_fitted=getattr(self,"_prepared_fitted_for_render",[]) or []
            fitted_row=prepared_fitted[pos] if pos<len(prepared_fitted) else None
            if self.media_type=="itv":
                title_widget.setText((fitted_row[0] if fitted_row else one_line(title,36)))
            else:
                if fitted_row:
                    fitted_title,fitted_font=fitted_row
                else:
                    fitted_title,fitted_font=_grid_fit_card_title(title,226)
                title_widget.setText(fitted_title)
                try:
                    if title_widget.instance is not None:
                        title_widget.instance.setFont(gFont("Regular",int(fitted_font)))
                except Exception as exc:optional_failure("ui.grid_title_autofit",exc)
            prepared_meta=getattr(self,"_prepared_meta_for_render",[]) or []
            _meta_text=prepared_meta[pos] if pos<len(prepared_meta) else self._card_meta(item,pos)
            meta_widget.setText(_meta_text)
            if self.media_type in ("vod","series"):
                self._card_rating_layout(item,pos,_meta_text)
            if self.media_type in ("vod","series"):
                try:
                    chrome=self["card_chrome%d"%pos]
                    if chrome.instance is not None:chrome.instance.setPixmapFromFile(asset(getattr(self,"_poster_neutral_card_asset","poster_card_full_neutral.png")))
                    chrome.show()
                except Exception as exc:optional_failure("ui.grid_neutral_card",exc)
            for widget in (art,title_widget):
                try:widget.show()
                except Exception as exc:optional_failure("ui",exc)
            if self.media_type not in ("vod","series") or (self._folder_rating_value(item)<=0 and self._folder_year_value(item)<=0):
                try:meta_widget.show()
                except Exception as exc:optional_failure("ui",exc)
        visible_art=[]
        selected_row, selected_col = divmod(self.index, self.columns)
        for pos,item in enumerate(self.grid_items[:self.page_size]):
            row, col = divmod(pos, self.columns)
            distance = abs(row - selected_row) + abs(col - selected_col)
            visible_art.append((distance, pos, item))
        visible_art.sort(key=lambda pair: (pair[0], pair[1]))
        for _distance,pos,item in visible_art:
            self._grid_request_art(pos,item,self.placeholder)
        self._update_selection()
        if self.media_type in ("vod","series"):
            try:self._grid_apply_current_selector(allow_build=True)
            except Exception as exc:optional_failure("ui.grid_initial_adaptive",exc)
        if self.media_type=="itv":
            _live_restart_trace("render_end",page=int(getattr(self,"page",0) or 0),index=int(getattr(self,"index",0) or 0),
                                generation=int(getattr(self,"_grid_generation",0) or 0),
                                slots=len(getattr(self,"_grid_slot_paths",{}) or {}),inflight=len(getattr(self,"_grid_download_inflight",{}) or {}))
        self._prepared_titles_for_render=[];self._prepared_fitted_for_render=[];self._prepared_meta_for_render=[];self._prepared_art_for_render=[]

    def _card_rating_layout(self,item,pos,meta_text=None):
        """Render YEAR + packaged gold star + score without touching artwork/network.

        The three widgets are screen-resident, so navigation only changes text/visibility;
        the star pixmap itself is loaded once by the skin and stays stable like a label.
        """
        if self.media_type not in ("vod","series"):
            return False
        try:
            year=int(self._folder_year_value(item) or 0)
            score=float(self._folder_rating_value(item))
        except Exception:
            year=0;score=-1.0
        try:
            meta=self["item_meta%d"%pos];yw=self["item_year%d"%pos];sw=self["item_star%d"%pos];rw=self["item_score%d"%pos]
        except Exception:
            return False
        # Always reset both rendering paths before painting.  This prevents stale
        # Enigma2 surfaces from stacking after returning from Details/Player.
        try:meta.hide()
        except Exception:pass
        for w in (yw,sw,rw):
            try:w.hide()
            except Exception:pass
        try:yw.setText("");rw.setText("")
        except Exception:pass
        has_year=year>0
        has_score=score>0.0
        if has_score and score>10.0:score=10.0
        if has_year:
            try:yw.setText(str(year));yw.show()
            except Exception:pass
        if has_score:
            try:rw.setText("%.1f"%score);sw.show();rw.show()
            except Exception:pass
        if has_year or has_score:
            return True
        if meta_text is not None:
            try:meta.setText(meta_text)
            except Exception:pass
        try:meta.show()
        except Exception:pass
        return False

    def _card_meta(self,item,pos):
        bits=[]
        if self.media_type=="itv":
            absolute=max(1,(int(self.page or 1)-1)*int(self.page_size or 1)+int(pos)+1)
            return str(absolute)
        raw=item.get("name") or item.get("title") or ""
        state=self._grid_item_state.get(id(item),{})
        explicit=self._explicit_item_quality(item)
        cached=str(state.get("quality") or "")
        badges=explicit or cached or quality_badges(raw)
        if badges:bits.append(badges)
        if item.get("year"):bits.append(str(item.get("year"))[:4])
        if state.get("favorite"):bits.append("★")
        if state.get("completed") and (self._grid_settings or {}).get("show_watched",True):bits.append("WATCHED")
        elif state.get("position") and state.get("duration"):bits.append("%d%%"%min(99,int(state["position"]*100.0/state["duration"])))
        return "  •  ".join(bits)[:28]

    def _update_selection(self):
        if not self.grid_items:return
        self.index=max(0,min(self.index,len(self.grid_items)-1))
        # Zero-work navigation rule: never touch poster/chrome pixmaps here.
        # Remember the old focused slot and restore it only after focus settles.
        try:
            prev_slot=int(getattr(self,"_grid_focus_chrome_slot",-1))
            if prev_slot>=0 and prev_slot!=self.index:self._grid_pending_prev_focus=prev_slot
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.1344",exc)
        try:
            # Native coordinates were calculated once when the grid screen opened.
            # No getDesktop(), floating-point scale or geometry calculation per key.
            px,py=self._scaled_card_positions[self.index]
            self["selection"].instance.move(ePoint(px,py))
            self["selection"].show()
            if self.media_type in ("vod","series"):
                self["selection_adaptive"].instance.move(ePoint(px,py))
        except Exception as exc:optional_failure("ui",exc)
        self._remember_grid_state()
        self._update_header(self.grid_items[self.index])
        if self.media_type in ("vod","series"):
            # Beta58: if this title was already queued as a normal visible job,
            # promote that exact queued job to selected priority instead of
            # submitting duplicate TMDB work. This is RAM-only.
            try:
                selected_key=self._page_visual_key(self.grid_items[self.index])
                if selected_key:_FAST_POSTER_EXECUTOR.reprioritize("hydrate:%s"%selected_key,0)
            except Exception as exc:optional_failure("ui.selected_reprioritize",exc)
            # Selection colour follows the newly focused poster immediately.
            # This is cache-only on a warm card; a miss schedules one background
            # overlay build while leaving the previous overlay visible.
            try:self._grid_apply_current_selector()
            except Exception as exc:optional_failure("ui.grid_selector_immediate",exc)
            # Keep the cursor/header synchronous and cheap.  The adaptive
            # background/laser and selected-detail nudge are intentionally
            # delayed so a fast LEFT/RIGHT/UP/DOWN run does not spawn work for
            # every card crossed on the way.
            try:
                self._nav_burst_until=time.monotonic()+0.36
                self._grid_focus_timer.stop();self._grid_focus_timer.start(360,True)
                # Test69 Lean: no speculative Series hierarchy network call.
            except Exception:
                self._apply_debounced_grid_focus()
            try:self._detail_prefetch_timer.stop()
            except Exception as exc:optional_failure("ui",exc)

    def _stop_series_hierarchy_prefetch(self):
        try:self._series_prefetch_timer.stop()
        except Exception as exc:optional_failure("ui.series_prefetch_timer_stop",exc)
        try:self._series_hierarchy_prefetch_cancel.set()
        except Exception as exc:optional_failure("ui.series_prefetch_cancel",exc)
        try:self._series_hierarchy_prefetch_token+=1
        except Exception:self._series_hierarchy_prefetch_token=1

    def _prefetch_selected_series_hierarchy(self):
        """Test69 Lean: Series hierarchy is fetched only when Details/Episodes needs it."""
        return

    def _apply_debounced_grid_focus(self):
        if self._screen_closed or not self.grid_items or self.media_type not in ("vod","series"):
            return
        # Test71: after focus settles, restore the previous card's normal
        # adaptive chrome, then build/apply a selected-clean chrome for the
        # current card. The laser stays a separate OUTER overlay, so the poster
        # itself keeps its full 206x310 geometry with no inner double frame.
        try:
            prev=int(getattr(self,"_grid_pending_prev_focus",-1))
            if prev>=0 and prev!=self.index:
                p=(getattr(self,"_grid_palette_sources",{}).get(prev) or self._grid_slot_paths.get(prev))
                if p and os.path.isfile(p):self._grid_schedule_adaptive_selector(self._grid_generation,prev,p)
        except Exception as exc:optional_failure("ui.grid_restore_prev_chrome",exc)
        self._grid_pending_prev_focus=-1
        self._grid_apply_current_selector(allow_build=True)
        try:self._apply_poster_live_hud(self.grid_items[self.index])
        except Exception as exc:optional_failure("ui.poster_hud_debounced",exc)
        # release: after focus is stable, hydrate this title's poster + real
        # backdrop automatically.  Rapid navigation never reaches this point.
        try:self._prefetch_focused_artwork()
        except Exception as exc:optional_failure("ui.auto_focus_hydrate",exc)

    def _warm_idle_grid_page(self):
        """Adaptive focus has its own debounce; no page-wide idle warming."""
        return

    def _stop_grid_idle_warm_timer(self):
        try:self._grid_idle_warm_timer.stop()
        except Exception as exc:optional_failure("ui.grid_idle_warm_stop",exc)
        try:
            if self._grid_idle_warm_conn is not None:self._grid_idle_warm_conn.disconnect()
        except Exception as exc:optional_failure("ui.grid_idle_warm_disconnect",exc)
        try:
            if self._warm_idle_grid_page in self._grid_idle_warm_timer.callback:self._grid_idle_warm_timer.callback.remove(self._warm_idle_grid_page)
        except Exception as exc:optional_failure("ui.grid_idle_warm_callback",exc)

    def _stop_grid_focus_timer(self):
        try:self._grid_focus_timer.stop()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            if self._grid_focus_timer_conn is not None:self._grid_focus_timer_conn.disconnect()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            if self._apply_debounced_grid_focus in self._grid_focus_timer.callback:self._grid_focus_timer.callback.remove(self._apply_debounced_grid_focus)
        except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _stop_detail_prefetch(self):
        try:self._detail_prefetch_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._detail_prefetch_conn is not None:self._detail_prefetch_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._prefetch_selected_details in self._detail_prefetch_timer.callback:self._detail_prefetch_timer.callback.remove(self._prefetch_selected_details)
        except Exception as exc:optional_failure("ui.prefetch_timer_callback",exc)
        try:
            cancel=getattr(self,"_page_prefetch_cancel",None)
            if cancel is not None:cancel.set()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._cancel_detached_page_prefetch_futures()
        for future in list(getattr(self,"_page_prefetch_futures",[]) or []):
            try:future.cancel()
            except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._page_prefetch_futures=[]

    def _prefetch_selected_details(self):
        # Navigation enrichment is strictly selected-card only. Neighbours are
        # loaded when focus actually reaches them, keeping the GUI thread and HDD
        # quiet while the user moves through a large catalogue.
        self._prefetch_visible_page_details(priority_index=self.index,max_items=1)

    def _explicit_item_quality(self, item):
        cache=getattr(self,"_explicit_quality_cache",None)
        key=id(item)
        if isinstance(cache,dict) and key in cache:return cache[key]
        try:
            values=[]
            def walk(v,depth=0):
                if depth>4:return
                if isinstance(v,dict):
                    for k,x in v.items():
                        if str(k).lower() in ("password","token","cookie"):continue
                        walk(x,depth+1)
                elif isinstance(v,(list,tuple)):
                    for x in v[:40]:walk(x,depth+1)
                elif v is not None: values.append(str(v))
            walk(item if isinstance(item,dict) else {})
            result=normalize_quality(" ".join(values))
            if isinstance(cache,dict):cache[key]=result
            return result
        except Exception:
            if isinstance(cache,dict):cache[key]=""
            return ""

    def _discover_item_quality(self, item, media_type, cancel_event=None):
        """Discover catalogue quality without starting playback.

        Artwork/network failures must never suppress this path.  We inspect the
        full portal rows first, then resolve the first episode/link only as a
        metadata probe.  No service is started.
        """
        q=self._explicit_item_quality(item)
        if q:return q
        def cancelled():
            return bool(cancel_event is not None and getattr(cancel_event,"is_set",lambda:False)())
        try:
            if media_type=="series" and not cancelled():
                seasons=self.client.series_seasons(item,cancel_event=cancel_event) or []
                for season in seasons[:3]:
                    if cancelled():return ""
                    q=self._explicit_item_quality(season)
                    if q:return q
                    episodes=self.client.series_episodes(item,season,cancel_event=cancel_event) or []
                    for ep in episodes[:8]:
                        q=self._explicit_item_quality(ep)
                        if q:return q
                    if episodes and not cancelled():
                        try:
                            link=self.client.create_link(episodes[0],"series",series_id=item.get("id") or item.get("series_id"),cancel_event=cancel_event)
                            q=normalize_quality("%s %s"%(self._explicit_item_quality(episodes[0]),str(link or "")))
                            if q:return q
                        except Exception as exc:optional_failure("ui.series_quality_link_probe",exc)
            elif media_type=="vod" and not cancelled():
                try:
                    link=self.client.create_link(item,"vod",cancel_event=cancel_event)
                    q=normalize_quality(str(link or ""))
                    if q:return q
                except Exception as exc:optional_failure("ui.vod_quality_link_probe",exc)
        except Exception as exc:
            if not cancelled():optional_failure("ui.quality_discovery",exc)
        return ""

    # Portal artwork is completely disabled for VOD/Series. TMDB artwork only.
    def _stop_visible_poster_watch(self):
        try:self._visible_poster_watch_timer.stop()
        except Exception as exc:optional_failure("ui.visible_poster_watch_stop",exc)
        try:
            if self._visible_poster_watch_conn is not None:self._visible_poster_watch_conn.disconnect()
        except Exception as exc:optional_failure("ui.visible_poster_watch_disconnect",exc)
        try:
            if self._poll_visible_poster_cache in self._visible_poster_watch_timer.callback:self._visible_poster_watch_timer.callback.remove(self._poll_visible_poster_cache)
        except Exception as exc:optional_failure("ui.visible_poster_watch_callback",exc)

    def _start_visible_poster_watch(self):
        """Test69 Lean: provider/BLUE queues repaint explicitly; no 120ms HDD scanner."""
        return

    def _poll_visible_poster_cache(self):
        """Paint newly persisted visible posters without any network activity."""
        if self._screen_closed or self.media_type not in ("vod","series"):return
        try:
            generation=int(getattr(self,"_grid_generation",0) or 0)
            current_items=list(self.grid_items[:self.page_size])
            for pos,item in enumerate(current_items):
                if not isinstance(item,dict):continue

                # Already displaying a real local poster: nothing to do.
                existing=str((getattr(self,"_grid_slot_paths",{}) or {}).get(pos) or "")
                if existing and os.path.isfile(existing):
                    # Ignore shipped placeholders; they are local files too.
                    bn=os.path.basename(existing).lower()
                    if not ("placeholder" in bn or bn.startswith("poster_movie") or bn.startswith("poster_series")):
                        continue

                poster=""
                snapshot={}
                try:
                    snapshot=load_artwork_v2_manifest(self.profile,self.media_type,item) or {}
                    candidate=str(snapshot.get("poster_local") or "")
                    if candidate and os.path.isfile(candidate) and os.path.getsize(candidate)>256:
                        poster=candidate
                except Exception:
                    snapshot={}

                if not poster:
                    try:
                        bundle=_load_visual_bundle(self.profile,self.media_type,item,snapshot) or {}
                        candidate=str(bundle.get("poster") or bundle.get("grid_thumb") or "")
                        if candidate and os.path.isfile(candidate) and os.path.getsize(candidate)>256:
                            poster=candidate
                    except Exception as exc:
                        diagnostic_failure("ui.grid.failsoft.poster_bundle",exc)

                if not poster:
                    continue

                display=poster
                try:
                    thumb=self._grid_poster_thumb_path(poster) or ""
                    if thumb and _valid_cache_file(thumb,ttl=0):display=thumb
                except Exception:display=poster

                # Recheck that this same item still occupies this slot.
                if generation!=int(getattr(self,"_grid_generation",0) or 0):return
                if pos>=len(self.grid_items) or self.grid_items[pos] is not item:
                    # Item objects can be copied by some views; compare stable key.
                    try:
                        from .persistent_cache import content_cache_key
                        if content_cache_key(self.profile,self.media_type,self.grid_items[pos]) != content_cache_key(self.profile,self.media_type,item):
                            continue
                    except Exception:
                        continue
                self._grid_palette_sources[pos]=poster
                if display==poster:
                    # No thumb yet: first paint now, thumbnail later. Never run
                    # Pillow synchronously from the 120ms UI watcher.
                    self._grid_use_persistent_poster(generation,pos,poster)
                else:
                    self._grid_queue_decode(generation,pos,display)
                    if pos==getattr(self,"index",-1):self._grid_schedule_page_mood(poster)
                self._remember_grid_visual(pos,display=display,poster=poster,palette=poster)
        except Exception as exc:
            optional_failure("ui.visible_poster_watch",exc)

    def _prefetch_visible_page_details(self, priority_index=None, max_items=None):
        """Hydrate visible posters with a detached, HDD-first page worker.

        The serialized HDD worker and any network miss workers capture only
        immutable/page-local values plus result queues. They never retain the
        Grid Screen, so closing or flipping pages cannot leave a stale Screen
        alive behind slow disk/network work.
        """
        if self._screen_closed or self.media_type not in ("vod","series") or not self.grid_items:return
        generation=int(getattr(self,"_page_prefetch_generation",0) or 0)
        cancel_event=getattr(self,"_page_prefetch_cancel",None)
        rows=list(enumerate(self.grid_items[:self.page_size]))
        if priority_index is None:priority_index=self.index
        try:priority_index=int(priority_index)
        except Exception:priority_index=0
        rows.sort(key=lambda pair:(0 if pair[0]==priority_index else 1,abs(pair[0]-priority_index),pair[0]))
        if max_items is not None:
            try:rows=rows[:max(1,int(max_items))]
            except Exception:pass

        selected=[]
        for pos,item in rows:
            if not isinstance(item,dict):continue
            key=self._page_visual_key(item)
            if not key:continue
            try:
                with self._page_prefetch_lock:
                    if key in self._page_prefetch_seen:continue
                    self._page_prefetch_seen.add(key)
            except Exception:continue
            selected.append((pos,dict(item),key))
        if not selected:return

        profile=dict(self.profile or {});media_type=str(self.media_type or "")
        cfg=dict(self._grid_settings or {});client=self.client
        result_q=self._art_prefetch_jobs;future_q=self._page_prefetch_future_jobs
        selected_index=int(priority_index)

        def submit_miss(pos,it,key):
            if cancel_event is not None and cancel_event.is_set():return
            def hydrate_visible(it=dict(it),k=key,gen=generation,cancel=cancel_event):
                if cancel is not None and cancel.is_set():return False
                poster,data=_progressive_poster_item_detached(profile,media_type,it,cfg,client,cancel)
                if cancel is not None and cancel.is_set():return False
                if poster and os.path.isfile(poster):
                    result_q.put((gen,k,poster,{
                        "tmdb_id":data.get("tmdb_id") if isinstance(data,dict) else None,
                        "media_type":(data.get("media_type") if isinstance(data,dict) else None) or ("tv" if media_type=="series" else "movie"),
                        "rating":(data.get("rating") or data.get("vote_average")) if isinstance(data,dict) else None,
                        "year":(data.get("year") or data.get("release_date") or data.get("first_air_date")) if isinstance(data,dict) else None,
                        "release_date":(data.get("release_date") or data.get("first_air_date") or "") if isinstance(data,dict) else "",
                        "palette_source":poster,
                    }))
                    return True
                # A transient visible-card miss used to leave this key marked as
                # already-prefetched forever.  That made the card stay blank until
                # focus triggered the separate full-artwork path.  Feed the miss
                # into the existing bounded retry lane: it clears the seen marker
                # and retries this one visible slot once, never as a page-wide loop.
                result_q.put((gen,k,"__RETRY__",None))
                return False
            try:
                priority=0 if pos==selected_index else 1
                # release: visible posters have their own small 3-worker lane.
                # This keeps first-open pages fast without contending with the
                # independent TMDb metadata lane or opening 14 downloads at once.
                future=_VISIBLE_POSTER_EXECUTOR.submit(hydrate_visible,_task_key="grid-poster:%x:%s:%s"%(id(self),generation,key))
                future_q.put((generation,key,future))
            except Exception:
                result_q.put((generation,key,"__RETRY__",None))

        def hdd_batch():
            for pos,it,key in selected:
                if cancel_event is not None and cancel_event.is_set():return
                try:
                    snap=load_artwork_v2_manifest(profile,media_type,it) or {}
                    poster=str(snap.get("poster_local") or "")
                    meta={
                        "tmdb_id":snap.get("tmdb_id"),
                        "media_type":snap.get("media_type") or ("tv" if media_type=="series" else "movie"),
                        "rating":snap.get("rating") or snap.get("vote_average"),
                        "year":snap.get("year") or snap.get("release_date") or snap.get("first_air_date"),
                        "release_date":snap.get("release_date") or snap.get("first_air_date") or "",
                        "palette_source":poster if poster and os.path.isfile(poster) else "",
                    }
                    # release: publish cached TMDb metadata even when artwork is
                    # absent/stale.  The GUI drain treats this as a metadata-only
                    # result and the normal miss lane may still resolve artwork.
                    if meta.get("tmdb_id") or meta.get("rating") or meta.get("year"):
                        result_q.put((generation,key,poster if poster and os.path.isfile(poster) and os.path.getsize(poster)>256 else "",meta))
                    if poster and os.path.isfile(poster) and os.path.getsize(poster)>256:
                        continue
                except Exception:pass
                if cancel_event is not None and cancel_event.is_set():return
                submit_miss(pos,it,key)
        try:
            future=_VISIBLE_POSTER_HDD_EXECUTOR.submit(hdd_batch,_task_key="grid-hdd:%x:%s"%(id(self),generation))
            self._page_prefetch_futures.append(future)
        except Exception as exc:
            for _pos,_it,key in selected:
                try:
                    with self._page_prefetch_lock:self._page_prefetch_seen.discard(key)
                except Exception:pass
            optional_failure("ui.visible_hdd_batch_submit",exc)

    def _update_header(self,item):
        raw=item.get("name") or item.get("title") or "Item"
        if self.media_type=="itv":
            title=_clean_live_channel_name(raw)
        else:
            title=(getattr(self,"_grid_display_titles",{}) or {}).get(self.index)
            if title is None:title=_catalogue_title(raw)
        self["title"].setText(_clean_display_text(title,44))
        if self.media_type=="itv":
            cid=str(item.get("id") or item.get("ch_id") or "");epg=self._epg_cache.get(cid,{})
            now=epg.get("now") or item.get("epg_title") or item.get("now") or _("EPG information will appear here")
            nxt=epg.get("next") or ""
            self["rating"].setText(_("NOW  %s")%_clean_display_text(now,90))
            self["meta1"].setText((_("NEXT")+"  "+_clean_display_text(nxt,90)) if nxt else "")
            badges=[]
            if item.get("allow_archive") or item.get("tv_archive_duration") or item.get("archive"):badges.append(_("Catch-up"))
            state=self._grid_item_state.get(id(item),{})
            if state.get("favorite"):badges.append(_("Favorite"))
            self["meta2"].setText("  •  ".join(badges))
            self._schedule_epg(item)
        else:
            # Movies/Series top rating/meta widgets are intentionally hidden in
            # the current HUD. Do not scan quality/metadata or resize glass here.
            # A remote-control arrow must only change the visible title text.
            return

    def _fit_poster_live_hud(self):
        if self.media_type not in ("vod","series"):return
        try:
            sx=float(getDesktop(0).size().width())/1920.0;sy=float(getDesktop(0).size().height())/1080.0
            def fit(bg,label,value,cx,minw,maxw,y,h,fs,pad,minfs):
                value=str(value or "")
                # Better Arabic/Latin width estimate than raw character count.
                units=max(1.0,sum(1.45 if ord(ch)>0x2ff else (0.58 if ch in " ilI1|.,:'" else 1.0) for ch in value))
                usable=max(1.0,float(maxw-24))
                fitted_fs=int(fs)
                expected=units*fitted_fs*0.57
                if expected>usable:
                    fitted_fs=max(int(minfs),min(int(fs),int(usable/(units*0.57))))
                w=max(minw,min(maxw,int(units*fitted_fs*0.57+pad)));x=int(cx-w/2)
                self[bg].instance.move(ePoint(int(x*sx),int(y*sy)));self[bg].instance.resize(eSize(int(w*sx),int(h*sy)))
                self[label].instance.move(ePoint(int((x+12)*sx),int((y+6)*sy)));self[label].instance.resize(eSize(int((w-24)*sx),int((h-12)*sy)))
                try:self[label].instance.setFont(gFont("Regular",fitted_fs))
                except Exception as exc:optional_failure("ui.poster_hud_font_fit",exc)
            fit("poster_folder_bg","section",self["section"].getText(),670,250,650,38,54,18,58,12)
            fit("poster_title_bg","title",self["title"].getText(),1215,250,590,38,54,22,64,13)
            fit("poster_counter_bg","page_label",self["page_label"].getText(),1650,260,430,936,46,18,52,12)
        except Exception as exc:optional_failure("ui.poster_hud_fit",exc)

    def _apply_poster_hud_chrome(self, source, chrome):
        if self.media_type not in ("vod","series") or not isinstance(chrome,dict):return
        # Counter uses the exact same floating glass family as the top folder card.
        for ck,wk in (("counter","poster_folder_bg"),("channel_top","poster_title_bg"),("clock","poster_clock_bg"),("counter","poster_counter_bg")):
            path=chrome.get(ck)
            if path and os.path.isfile(path):
                try:self[wk].instance.setPixmapFromFile(path);self[wk].show()
                except Exception as exc:optional_failure("ui.poster_hud_apply",exc)
        self._poster_hud_last=dict(chrome);self._poster_hud_source=str(source or "")
        self._fit_poster_live_hud()

    def _drain_poster_live_hud(self):
        if self.media_type not in ("vod","series"):return
        while True:
            try:source,chrome=self._poster_hud_jobs.get_nowait()
            except queue.Empty:break
            except Exception:break
            self._poster_hud_pending.discard(source)
            # Only repaint for the currently selected poster. Old jobs may finish
            # after rapid navigation and must never yank the HUD colour backwards.
            pos=max(0,min(int(self.index or 0),len(self.grid_items)-1)) if self.grid_items else 0
            current=str((getattr(self,"_grid_palette_sources",{}) or {}).get(pos) or "")
            if source==current:self._apply_poster_hud_chrome(source,chrome)

    def _apply_poster_live_hud(self, item=None):
        if self.media_type not in ("vod","series"):return
        try:
            pos=max(0,min(int(self.index or 0),len(self.grid_items)-1)) if self.grid_items else 0
            source=str((getattr(self,"_grid_palette_sources",{}) or {}).get(pos) or "")
            if not source or not os.path.isfile(source):
                return
            self._fit_poster_live_hud()
            if source==getattr(self,"_poster_hud_source","") and getattr(self,"_poster_hud_last",None):
                # Same-source is not proof that the native Pixmap is still painted.
                # OpenBH may retain our Python cache marker after a hide/show or
                # child-screen transition while the adaptive glass surface itself
                # is gone. Rebind the already-cached chrome instead of returning.
                self._apply_poster_hud_chrome(source,self._poster_hud_last)
                return
            key="poster_hud_"+hashlib.sha1(source.encode("utf-8","ignore")).hexdigest()[:16]
            expected={
                "counter":os.path.join(THUMB_CACHE_DIR,"posterhud_clean_%s_counter.png"%key),
                "channel_top":os.path.join(THUMB_CACHE_DIR,"posterhud_clean_%s_channel_top.png"%key),
                "clock":os.path.join(THUMB_CACHE_DIR,"posterhud_clean_%s_clock.png"%key),
            }
            if all(_valid_cache_file(p,ttl=0) for p in expected.values()):
                self._apply_poster_hud_chrome(source,expected)
                return

            # beta59: restore the adaptive folder/title/clock/counter HUD without
            # putting Pillow back on the navigation path.  This method is already
            # called only after the 300 ms stable-focus debounce; a single-worker
            # adaptive lane builds one missing HUD family in the background, while
            # rapid LEFT/RIGHT browsing remains cache-only.
            if source in getattr(self,"_poster_hud_pending",set()):
                return
            self._poster_hud_pending.add(source)
            def worker(src=source,hkey=key):
                try:
                    chrome=_build_poster_adaptive_chrome_clean(src,hkey) or {}
                    if chrome:self._poster_hud_jobs.put((src,chrome))
                    else:self._poster_hud_jobs.put((src,{}))
                except Exception as exc:
                    optional_failure("ui.poster_hud_background_build",exc)
                    try:self._poster_hud_jobs.put((src,{}))
                    except Exception as queue_exc:optional_failure("ui.poster_hud_background_queue",queue_exc)
            try:_ADAPTIVE_EXECUTOR.submit(worker)
            except Exception as exc:
                self._poster_hud_pending.discard(source)
                optional_failure("ui.poster_hud_background_submit",exc)
        except Exception as exc:optional_failure("ui.poster_live_hud_cache_only",exc)

    def _nav_allowed(self):
        now=time.monotonic()
        # Give the remote-control path exclusive GUI priority during a key burst.
        self._nav_burst_until=now+0.30
        if now-self._last_nav_at < 0.020:
            return False
        self._last_nav_at=now
        return True

    def _update_page_counter(self):
        total = int(self._active_total() or 0)
        total_pages = max(1, (total + self.page_size - 1) // self.page_size) if total else 1
        absolute = min(total, (self.page - 1) * self.page_size + self.index + 1) if total else (0 if not self.grid_items else ((self.page - 1) * self.page_size + self.index + 1))
        kind = "Channel" if self.media_type == "itv" else ("Movie" if self.media_type == "vod" else "Series")
        try:self["page_label"].setText(_("Page %d / %d  •  %s %d / %d") % (self.page, total_pages, kind, absolute, total or absolute))
        except Exception as exc:optional_failure("ui.silent_guard",exc)

    def move_left(self):
        if self.grid_items and self._nav_allowed():self.index=max(0,self.index-1);self._update_selection();self._update_page_counter()
    def move_right(self):
        if self.grid_items and self._nav_allowed():self.index=min(len(self.grid_items)-1,self.index+1);self._update_selection();self._update_page_counter()
    def move_up(self):
        if not self.grid_items or not self._nav_allowed():
            return
        if self.index >= self.columns:
            self.index -= self.columns
            self._update_selection();self._update_page_counter()
            return
        column=self.index % self.columns
        if self.page > 1:
            # Keep the same column on the previous page's final row.
            self.load_page(self.page - 1, max(0, self.page_size - self.columns + column))
            return
        # Universal vertical wrap: first row of page 1 -> final item/page.
        total=int(self._active_total() or 0)
        if total > 0:
            last_page=max(1,(total+self.page_size-1)//self.page_size)
            self.load_page(last_page,self.page_size-1)
        else:
            self.index=len(self.grid_items)-1;self._update_selection();self._update_page_counter()

    def move_down(self):
        if not self.grid_items or not self._nav_allowed():
            return
        target = self.index + self.columns
        if target < len(self.grid_items):
            self.index = target
            self._update_selection();self._update_page_counter()
            return
        total=int(self._active_total() or 0)
        total_pages=max(1,(total+self.page_size-1)//self.page_size) if total else 0
        if total_pages and self.page >= total_pages:
            # Universal vertical wrap: final row/item -> very first item.
            self.load_page(1,0)
            return
        # Crossing the final visible row naturally advances to the next page.
        column = self.index % self.columns
        self.load_page(self.page + 1, column)

    def next_page(self):
        self.load_page(self.page + 1, self.index % self.columns if self.grid_items else 0)

    def previous_page(self):
        if self.page <= 1:
            return
        column = self.index % self.columns if self.grid_items else 0
        self.load_page(self.page - 1, max(0, self.page_size - self.columns + column))

    def open_selected(self):
        if self._busy or not self.grid_items:return
        item=self.grid_items[self.index]
        if self.media_type=="itv":
            self._play_live(item)
        else:
            self._remember_grid_state()
            self._pause_grid_background_for_child()
            # Carry the exact poster palette source used by the grid into Details.
            # This makes List -> Details one continuous adaptive identity.
            detail_item=dict(item) if isinstance(item,dict) else item
            try:
                palette_source=(getattr(self,"_grid_palette_sources",{}).get(self.index) or self._grid_slot_paths.get(self.index) or "")
                visible_poster=self._visible_player_poster_path(item,self.index)
                if isinstance(detail_item,dict) and visible_poster:
                    detail_item["_player_poster"]=str(visible_poster)
                    detail_item["_ultra_palette_source"]=str(visible_poster)
                    detail_item["_ultra_poster_source"]=str(visible_poster)
                    detail_item["_adaptive_source_local"]=str(visible_poster)
                elif isinstance(detail_item,dict) and palette_source and os.path.isfile(str(palette_source)):
                    detail_item["_ultra_palette_source"]=str(palette_source)
                    detail_item["_ultra_poster_source"]=str(palette_source)
                    detail_item["_player_poster"]=str(palette_source)
                # release instant-open handoff for Series: Details paints first,
                # then its normal async metadata/artwork lanes may enrich in-place.
                # Avoid synchronous HDD snapshot/bundle reads in the constructor.
                if isinstance(detail_item,dict) and self.media_type=="series":
                    detail_item["_ultra_fast_open"]=True
                    fast_bundle={}
                    if palette_source and os.path.isfile(str(palette_source)):
                        fast_bundle["poster"]=str(palette_source)
                    back=str(detail_item.get("_backdrop_source_local") or detail_item.get("_cin_provider_backdrop_local") or "")
                    if back and os.path.isfile(back):
                        fast_bundle["backdrop"]=back
                    detail_item["_ultra_fast_bundle"]=fast_bundle
            except Exception as exc:
                optional_failure("ui.grid_palette_handoff",exc)
            self.session.openWithCallback(self._details_returned,ContentDetailsScreen,self.profile,self.client,self.media_type,detail_item)

    def _pause_grid_background_for_child(self):
        for name in ("_grid_focus_timer","_detail_prefetch_timer","_grid_idle_warm_timer"):
            timer=getattr(self,name,None)
            if timer is not None:
                try:timer.stop()
                except Exception as exc:diagnostic_failure("ui.grid.failsoft.1974",exc)
        try:
            cancel=getattr(self,"_page_prefetch_cancel",None)
            if cancel is not None:cancel.set()
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.1978",exc)
        self._cancel_detached_page_prefetch_futures()
        for future in list(getattr(self,"_page_prefetch_futures",[]) or []):
            try:future.cancel()
            except Exception as exc:diagnostic_failure("ui.grid.failsoft.1981",exc)
        self._page_prefetch_futures=[]

    def _resume_grid_background_after_child(self):
        self._page_prefetch_generation=int(getattr(self,"_page_prefetch_generation",0) or 0)+1
        self._page_prefetch_cancel=threading.Event()
        self._page_prefetch_seen=set()
        self._visible_tmdb_pending=set()
        # No immediate page-wide warm on BACK. Selected-card enrichment is enough;
        # neighbours resolve lazily as the user moves.
        try:self._detail_prefetch_timer.start(700,True)
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.1991",exc)

    def _details_returned(self,result=None):
        # Return to the exact poster and page that opened the details screen.
        target_page=max(1,int(getattr(self,"_restore_page",self.page) or 1))
        target_index=max(0,int(getattr(self,"_restore_index",self.index) or 0))
        if self.page != target_page or not self.grid_items:
            self.load_page(target_page,target_index)
            return
        self.index=max(0,min(target_index,len(self.grid_items)-1)) if self.grid_items else 0
        if self.grid_items:
            states=load_content_states(self.profile,self.media_type,self.grid_items)
            qualities=load_content_qualities(self.profile,self.media_type,self.grid_items) if self.media_type in ("vod","series") else ["" for _ in self.grid_items]
            self._grid_item_state={}
            for item,state,quality in zip(self.grid_items,states,qualities):
                row=dict(state or {});row["quality"]=quality or "";self._grid_item_state[id(item)]=row
            # Refresh text/state in place.  BACK from Details/Player must stay
            # RAM-only: Stage 3 already remembers the exact decoded visual for
            # every hydrated slot in _page_visual_ram.  Older code reopened a
            # detail snapshot + artwork bundle for every visible card here,
            # turning one BACK key into 14/27 synchronous HDD reads.
            for pos,item in enumerate(self.grid_items[:self.page_size]):
                try:
                    _meta=self._card_meta(item,pos)
                    self["item_meta%d"%pos].setText(_meta)
                    if self.media_type in ("vod","series"):
                        self._card_rating_layout(item,pos,_meta)
                except Exception as exc:optional_failure("ui.grid_return_meta",exc)
                try:
                    visual=self._page_visual_get(item) or {}
                    display=str(visual.get("display") or "")
                    poster=str(visual.get("poster") or display or "")
                    palette=str(visual.get("palette") or poster or "")
                    card=str(visual.get("card") or "")
                    if display:
                        self._grid_slot_paths[pos]=display
                        if palette:self._grid_palette_sources[pos]=palette
                        self._grid_visual_locks[pos]=display
                        self._grid_queue_decode(self._grid_generation,pos,display)
                    if card:
                        self._grid_card_paths[pos]=card
                        try:
                            chrome=self["card_chrome%d"%pos]
                            if chrome.instance is not None:chrome.instance.setPixmapFromFile(card)
                            chrome.show()
                        except Exception as card_exc:optional_failure("ui.grid_return_card_ram",card_exc)
                except Exception as exc:optional_failure("ui.grid_return_ram_visual",exc)
            # Enigma2 can leave the previously focused pixmap surface stale
            # after the child screen closes. Rebind/show the selected slot now,
            # instead of waiting for a RIGHT/LEFT key to trigger a repaint.
            try:
                slot=self.index
                for name in ("art%d"%slot,"item_title%d"%slot,"card_chrome%d"%slot):
                    try:self[name].show()
                    except Exception as exc:diagnostic_failure("ui.grid.failsoft.2031",exc)
                try:
                    _meta=self._card_meta(self.grid_items[slot],slot)
                    self["item_meta%d"%slot].setText(_meta)
                    self._card_rating_layout(self.grid_items[slot],slot,_meta)
                except Exception as exc:optional_failure("ui.grid_return_rating_repaint",exc)
                visual=self._page_visual_get(self.grid_items[slot]) or {}
                art_path=str(visual.get("display") or self._grid_slot_paths.get(slot) or "")
                if art_path:
                    art=self["art%d"%slot]
                    if art.instance is not None:art.instance.setPixmapFromFile(art_path)
                    art.show()
                card=str(visual.get("card") or self._grid_card_paths.get(slot) or "")
                if card:
                    chrome=self["card_chrome%d"%slot]
                    if chrome.instance is not None:chrome.instance.setPixmapFromFile(card)
                    chrome.show()
                self._grid_focus_chrome_slot=slot
            except Exception as exc:optional_failure("ui.grid_return_repaint",exc)
            self._update_selection()
            try:self._grid_apply_current_selector()
            except Exception as exc:optional_failure("ui.grid_return_selector",exc)
            self._resume_grid_background_after_child()
        else:
            self._update_selection()
            self._resume_grid_background_after_child()

    def _play_live(self,item):
        command=item.get("cmd") or item.get("command") or item.get("url")
        if not command:self["status"].setText(_("No stream command"));return
        self["status"].setText(_("Creating stream link..."))
        def ok(url):
            if not isinstance(url,str) or not url.strip():self["status"].setText(_("Portal returned an invalid stream link"));return
            name=str(item.get("name") or item.get("title") or "Live channel");add_recently_played(self.profile,"itv",item)
            engine=_configured_playback_engine(self._grid_settings or {})
            selected_page=self.page; selected_index=self.index
            def returned(result=None):
                self["status"].setText(_("Player closed"))
                # Keep the channel selected and make sure no player service is
                # resurrected behind the grid.
                if self.page != selected_page or not self.grid_items:
                    self.load_page(selected_page,selected_index)
                else:
                    self.index=max(0,min(selected_index,len(self.grid_items)-1))
                    self._update_selection()
            self.session.openWithCallback(returned,UltraStalkerPlayer,url.strip(),name,"itv",engine,_player_payload(item,self.profile,media_type="itv"))
        self._run_async(lambda handle:self.client.create_link(item,"itv",cancel_event=handle.cancel_event),ok,lambda e:self["status"].setText(_friendly_error(e)))

    def toggle_selected_favorite(self):
        if not self.grid_items:return
        item=self.grid_items[self.index];state=toggle_favorite(self.profile,self.media_type,item);self["status"].setText(_("Added to favorites") if state else _("Removed from favorites"))
        cached=self._grid_item_state.setdefault(id(item),{'favorite':False,'position':0,'duration':0,'completed':0});cached['favorite']=bool(state)
        try:
            self["item_meta%d" % self.index].setText(self._card_meta(self.grid_items[self.index], self.index))
        except Exception as exc:
            optional_failure("ui", exc)
        self._update_header(self.grid_items[self.index])

    @staticmethod
    def _home_hero_old_generated_paths(hero):
        paths=[]
        if not isinstance(hero,dict):return paths
        value=str(hero.get("prepared") or "")
        if value:paths.append(value)
        for key in ("home_mood","adaptive_focus"):
            block=hero.get(key) if isinstance(hero.get(key),dict) else {}
            for candidate in block.values():
                candidate=str(candidate or "")
                if candidate:paths.append(candidate)
        return paths

    def _selected_cached_backdrop_for_hero(self):
        """Return the current selected item's already-cached HDD backdrop only."""
        if not self.grid_items:return "",{}
        item=self.grid_items[self.index] if 0 <= int(self.index) < len(self.grid_items) else None
        if not isinstance(item,dict):return "",{}
        candidates=[]
        for key in ("_backdrop_source_local","_cin_provider_backdrop_local","backdrop_local","display_backdrop_local","source_backdrop_local"):
            candidates.append(item.get(key))
        # Cinematic keeps the canonical row/package for the focused item in RAM.
        try:
            row=(getattr(self,"_cin_page_records",{}) or {}).get(int(self.index)) or {}
            if isinstance(row,dict):
                candidates.extend([row.get("backdrop_local"),row.get("display_backdrop_local")])
        except Exception:pass
        # HDD manifest is read-only here; MENU must never trigger a network resolve.
        manifest={}
        try:manifest=load_artwork_v2_manifest(self.profile,self.media_type,item) or {}
        except Exception:manifest={}
        if isinstance(manifest,dict):
            candidates.extend([manifest.get("backdrop_local"),manifest.get("display_backdrop_local"),manifest.get("source_backdrop_local")])
        for candidate in candidates:
            try:
                candidate=str(candidate or "")
                if candidate and os.path.isfile(candidate) and os.path.getsize(candidate)>4096:
                    return os.path.realpath(candidate),manifest
            except Exception:pass
        return "",manifest

    def _pin_selected_as_home_hero(self):
        """Pin the focused Cinematic/Backdrop item as Home Hero from cached art only.

        This is the same manual-Hero contract used by Details: no TMDb/network work
        is started by MENU, and only the selected canonical HDD backdrop is used.
        """
        if self.media_type not in ("vod","series") or not self.grid_items:return
        item=self.grid_items[self.index]
        if not isinstance(item,dict):return
        source,manifest=self._selected_cached_backdrop_for_hero()
        if not source:
            try:self["status"].setText(_("Hero not set • selected backdrop is not cached on HDD"))
            except Exception:pass
            return
        item_snapshot=dict(item);media_type=str(self.media_type or "")
        raw_id=str(item_snapshot.get("tmdb_id") or item_snapshot.get("id") or item_snapshot.get("stream_id") or item_snapshot.get("series_id") or "")
        tmdb_id=item_snapshot.get("_locked_tmdb_id") or item_snapshot.get("tmdb_id") or (manifest.get("tmdb_id") if isinstance(manifest,dict) else None)
        title=str(item_snapshot.get("name") or item_snapshot.get("title") or item_snapshot.get("series_name") or "")
        overview=str(item_snapshot.get("plot") or item_snapshot.get("description") or item_snapshot.get("overview") or "")
        try:
            text=self["description"].getText() or ""
            if text:overview=text
        except Exception:pass
        try:
            text=self["bd_overview"].getText() or ""
            if text:overview=text
        except Exception:pass
        title_logo_local=""
        for candidate in (getattr(self,"_cin_logo_path",""),getattr(self,"_bd_logo_path",""),item_snapshot.get("title_logo_local")):
            try:
                candidate=str(candidate or "")
                if candidate and os.path.isfile(candidate) and os.path.getsize(candidate)>256:
                    title_logo_local=os.path.realpath(candidate);break
            except Exception:pass

        request_token=str(int(time.time()*1000000));hero_dir=os.path.dirname(str(HOME_HERO_FILE or ""))
        marker=os.path.join("/tmp","ultrastalker_home_hero_pending")
        try:
            with open(marker,"w",encoding="ascii") as fh:fh.write(request_token)
        except Exception:pass
        try:self["status"].setText(_("Hero selected • preparing adaptive materials…"))
        except Exception:pass

        def token_current():
            try:
                with open(marker,"r",encoding="ascii") as fh:return fh.read().strip()==request_token
            except Exception:return False

        def safe_unlink_generated(path,keep=()):
            try:
                path=str(path or "");base=os.path.basename(path)
                if not path or path in keep or not os.path.isfile(path):return
                if (os.path.realpath(path).startswith(os.path.realpath(hero_dir)+os.sep) or
                    base.startswith("dyn228home_") or base.startswith("dyn280home_")):
                    os.unlink(path)
            except OSError:pass
            except Exception:pass

        def worker():
            temp_home="";created=[]
            try:
                os.makedirs(hero_dir,mode=0o700,exist_ok=True)
                stamp=os.stat(source)
                digest=hashlib.sha1((source+"|%s|%s|manual-hero-v78-contract"%(int(stamp.st_mtime),int(stamp.st_size))).encode("utf-8","ignore")).hexdigest()[:20]
                temp_home=os.path.join(hero_dir,".hero.%s.%s.png"%(os.getpid(),request_token))
                prepared=_prepare_single_home_hero(source,temp_home,(1920,1080))
                if not prepared or not os.path.isfile(prepared) or os.path.getsize(prepared)<=1024:return False
                if not token_current():return False
                adaptive_focus=_build_home_adaptive_focus(source,digest) or {}
                created.extend([str(x or "") for x in adaptive_focus.values()]);gc.collect()
                if not token_current():return False
                home_mood=_build_home_mood_assets(source,digest) or {}
                created.extend([str(x or "") for x in home_mood.values()]);gc.collect()
                if not token_current():return False
                required=[adaptive_focus.get("menu"),adaptive_focus.get("recent"),home_mood.get("ambient"),home_mood.get("menu"),home_mood.get("recent")]
                if not all(x and os.path.isfile(str(x)) and os.path.getsize(str(x))>100 for x in required):return False
                old_hero={}
                try:
                    with open(HOME_HERO_FILE,"r",encoding="utf-8") as fh:
                        old=json.load(fh);old_hero=old.get("hero") if isinstance(old,dict) and isinstance(old.get("hero"),dict) else {}
                except Exception:old_hero={}
                with _HOME_HERO_LOCK:
                    if not token_current():return False
                    final_home=os.path.join(hero_dir,"hero.png")
                    os.replace(temp_home,final_home);temp_home=""
                    hero={
                        "id":"manual-"+(raw_id or digest),"media_type":media_type,"tmdb_id":tmdb_id,
                        "title":title,"overview":overview,"rating":0,"language":"","collection":"ULTRA STALKER",
                        "prepared":final_home,"backdrop_local":source,"display_backdrop_local":source,
                        "source_backdrop_local":source,"adaptive_focus":adaptive_focus,"home_mood":home_mood,
                        "title_logo_local":title_logo_local,"title_logo_lang":"en" if title_logo_local else "",
                        "manual_pin":True,"manual_pin_token":int(request_token),
                    }
                    payload={"schema":HOME_HERO_SCHEMA,"expires":0,"persistent":True,"manual_pin":True,
                             "manual_pin_token":int(request_token),"hero":hero}
                    fd,tmp=tempfile.mkstemp(prefix=".hero-state.",suffix=".tmp",dir=hero_dir)
                    try:
                        with os.fdopen(fd,"w",encoding="utf-8") as fh:
                            json.dump(payload,fh,ensure_ascii=False,separators=(",",":"));fh.flush();os.fsync(fh.fileno())
                        os.chmod(tmp,0o600);os.replace(tmp,HOME_HERO_FILE)
                    finally:
                        if os.path.exists(tmp):
                            try:os.unlink(tmp)
                            except OSError:pass
                keep=set([final_home]+[str(x or "") for x in required])
                for old_path in self._home_hero_old_generated_paths(old_hero):safe_unlink_generated(old_path,keep)
                try:
                    if token_current():os.unlink(marker)
                except OSError:pass
                return True
            except Exception as exc:
                optional_failure("ui.grid_set_home_hero",exc);return False
            finally:
                if temp_home and os.path.exists(temp_home):
                    try:os.unlink(temp_home)
                    except OSError:pass
                if not token_current():
                    for path in created:safe_unlink_generated(path)

        try:
            future=_IMAGE_EXECUTOR.submit(worker)
            def done(_f):
                try:ok=bool(_f.result())
                except Exception:ok=False
                def paint():
                    if getattr(self,"_screen_closed",False):return
                    try:self["status"].setText(_("Hero pinned • active across Ultra Stalker") if ok else _("Hero failed"))
                    except Exception:pass
                try:reactor.callFromThread(paint)
                except Exception:pass
            future.add_done_callback(done)
        except Exception as exc:
            optional_failure("ui.grid_set_home_hero_submit",exc)
            try:self["status"].setText(_("Hero failed: %s")%str(exc)[:90])
            except Exception:pass

    def show_information(self):
        if not self.grid_items:return
        item=self.grid_items[self.index]
        if self.media_type in ("vod","series"):
            detail_item=dict(item) if isinstance(item,dict) else item
            try:
                palette_source=(getattr(self,"_grid_palette_sources",{}).get(self.index) or self._grid_slot_paths.get(self.index) or "")
                if isinstance(detail_item,dict) and palette_source and os.path.isfile(str(palette_source)):
                    detail_item["_ultra_palette_source"]=str(palette_source);detail_item["_ultra_poster_source"]=str(palette_source);detail_item["_player_poster"]=str(palette_source)
                if isinstance(item,dict) and isinstance(detail_item,dict):
                    for key in ("_backdrop_source_local","_cin_provider_backdrop_local","_cin_provider_poster_url","_cin_provider_backdrop_url"):
                        if item.get(key) not in (None,""):detail_item[key]=item.get(key)
            except Exception as exc:optional_failure("ui.grid_info_visual_handoff",exc)
            self.session.open(ContentDetailsScreen,self.profile,self.client,self.media_type,detail_item)
        else:
            cid=str(item.get("id") or item.get("ch_id") or "");epg=self._epg_cache.get(cid,{})
            text=_("%s\n\nNOW: %s\nNEXT: %s")%(self["title"].getText(),epg.get("now") or _("No EPG"),epg.get("next") or _("No EPG"))
            self.session.open(MessageBox,text,MessageBox.TYPE_INFO,timeout=12)

    def open_menu(self):
        choices=[(_("Refresh page"),"refresh"),(_("First page"),"first"),(_("Toggle favorite"),"favorite")]
        if self.media_type=="vod" and self.grid_items:
            state=self._grid_item_state.get(id(self.grid_items[self.index]),{})
            choices.append((_("Mark unwatched") if state.get("completed") else _("Mark watched"),"unwatch" if state.get("completed") else "watch"))
        self.session.openWithCallback(self._menu_selected,ChoiceBox,title=_("Grid options"),list=choices)
    def _menu_selected(self,choice):
        if not choice:return
        if choice[1]=="refresh":
            for item in self.grid_items:
                url = self._grid_absolute_url(_image_url(item))
                if url:
                    _clear_artwork_failure(url)
            self.load_page(self.page)
        elif choice[1]=="first":self.load_page(1)
        elif choice[1]=="favorite":self.toggle_selected_favorite()
        elif choice[1]=="set_home_hero":self._pin_selected_as_home_hero()
        elif choice[1] in ("watch","unwatch") and self.grid_items:
            item=self.grid_items[self.index];watched=choice[1]=="watch";mark_watched(self.profile,self.media_type,item,watched)
            cached=self._grid_item_state.setdefault(id(item),{'favorite':False,'position':0,'duration':0,'completed':0});cached['completed']=1 if watched else 0
            if not watched:cached['position']=0
            try:self["item_meta%d"%self.index].setText(self._card_meta(item,self.index))
            except Exception as exc:optional_failure("ui",exc)
            self._update_header(item);self["status"].setText(_("Marked watched") if watched else _("Marked unwatched"))

    def _update_grid_clock(self):
        try:self["clock"].setText(time.strftime("%H:%M"))
        except Exception as exc:optional_failure("ui",exc)
        if self.media_type in ("vod","series"):
            try:self["date_label"].setText(time.strftime("%A, %d %B %Y"))
            except Exception as exc:optional_failure("ui.poster_grid_date",exc)
    def _stop_grid_clock(self):
        try:self._grid_clock.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._grid_clock_conn is not None:self._grid_clock_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._update_grid_clock in self._grid_clock.callback:self._grid_clock.callback.remove(self._update_grid_clock)
        except Exception as exc:optional_failure("ui",exc)

    def _schedule_epg(self,item):
        if self.media_type!="itv":return
        cid=str(item.get("id") or item.get("ch_id") or "")
        if not cid or cid in self._epg_cache:return
        self._epg_pending=cid
        try:self._epg_timer.stop();self._epg_timer.start(350,True)
        except Exception as exc:optional_failure("ui",exc)
    def _fetch_epg(self):
        cid=self._epg_pending
        if not cid:return
        def work():
            try:return (cid,epg_summary(self.client.epg(cid,4)),None)
            except Exception as exc:return (cid,None,exc)
        def done(fut):
            if getattr(self,"_screen_closed",False):return
            try:self._epg_jobs.put(fut.result())
            except Exception as exc:optional_failure("ui",exc)
        _GRID_EPG_EXECUTOR.submit(work).add_done_callback(done)
    def _drain_grid_epg(self):
        while True:
            try:cid,summary,error=self._epg_jobs.get_nowait()
            except queue.Empty:break
            if not error and summary:
                self._epg_cache[cid]=summary
                if self.grid_items and str(self.grid_items[self.index].get("id") or self.grid_items[self.index].get("ch_id") or "")==cid:self._update_header(self.grid_items[self.index])
    def _stop_grid_epg(self):
        try:self._epg_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._epg_timer_conn is not None:self._epg_timer_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._fetch_epg in self._epg_timer.callback:self._epg_timer.callback.remove(self._fetch_epg)
        except Exception as exc:optional_failure("ui.grid_epg_callback",exc)

