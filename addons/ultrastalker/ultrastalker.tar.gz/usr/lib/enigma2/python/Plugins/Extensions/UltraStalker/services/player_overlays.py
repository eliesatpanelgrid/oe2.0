# -*- coding: utf-8 -*-
"""Player overlay, subtitle-choice and live-zap screens.

Stage-1 extraction only. Screen behaviour and skin XML are moved without
functional changes from player_golden57.
"""
from __future__ import absolute_import, print_function

try:
    import colorsys
except Exception:
    from .. import compat_colorsys as colorsys

import hashlib
import os
import queue
import re
import unicodedata

try:
    from PIL import Image as _PILImage, ImageDraw as _ImageDraw, ImageFilter as _ImageFilter
except Exception:
    _PILImage = None
    _ImageDraw = None
    _ImageFilter = None

from .. import _
from ..core.image_budget import image_budgeted
from ..securefs import secure_private_dir
from ..persistent_cache import GENERATED as PERSISTENT_GENERATED_DIR
from ..log import optional_failure
from .player_core import _PLAYER_BG_EXECUTOR
from .player_artwork import _apply_player_font_scale, _asset, _adaptive_info_frames

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
try:
    from Components.MultiContent import MultiContentEntryPixmapAlphaBlend
except Exception:
    MultiContentEntryPixmapAlphaBlend = MultiContentEntryPixmapAlphaTest
from Components.Pixmap import Pixmap
from Components.ServiceEventTracker import ServiceEventTracker
from Screens.Screen import Screen
from enigma import eTimer, iPlayableService, gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_VALIGN_CENTER, loadPNG

ONLINE_SUBTITLE_SKIN = """
<screen name="UltraStalkerOnlineSubtitleOverlay" position="0,0" size="1920,1080" flags="wfNoBorder">
    <widget name="text" position="170,805" size="1580,150" font="Regular;38" halign="center" valign="bottom"
        foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="3,3" transparent="1" zPosition="1"/>
</screen>
"""
ONLINE_SUBTITLE_SKIN=_apply_player_font_scale(ONLINE_SUBTITLE_SKIN)

class OnlineSubtitleOverlay(Screen):
    skin=ONLINE_SUBTITLE_SKIN
    def __init__(self,session):
        Screen.__init__(self,session)
        self["text"]=Label("")
    def set_text(self,value):
        try:self["text"].setText(str(value or ""))
        except Exception:pass


SUBTITLE_STYLE_COLORS = (
    ("White", "#FFFFFF"), ("Cream", "#FFF1C1"), ("Yellow", "#FFD84D"),
    ("Gold", "#FFB300"), ("Orange", "#FF9A4D"), ("Lime", "#D9FF57"),
    ("Green", "#69F0AE"), ("Mint", "#64FFD8"), ("Cyan", "#5DEBFF"),
    ("Sky Blue", "#63B8FF"), ("Blue", "#7D93FF"), ("Lavender", "#C3A6FF"),
    ("Purple", "#DA9BFF"), ("Pink", "#FF95D8"), ("Coral", "#FF958C"),
)
SUBTITLE_POSITION_PRESETS = (
    ("Very High", 180), ("High", 120), ("Upper", 60), ("Default", 0),
    ("Lower", -60), ("Low", -120), ("Very Low", -180),
)
def _subtitle_color_name(value):
    value=str(value or "#FFFFFF").upper()
    for name,hex_value in SUBTITLE_STYLE_COLORS:
        if hex_value.upper()==value:return name
    return "White"
def _subtitle_position_name(value):
    try:value=int(value or 0)
    except Exception:value=0
    for name,offset in SUBTITLE_POSITION_PRESETS:
        if int(offset)==value:return name
    return ("%+d px"%value) if value else "Default"


@image_budgeted
def _subtitle_glass_assets(source_path, width=1120, row_width=1010, row_height=72):
    """Downloads-style adaptive glass for subtitle picker screens."""
    if _PILImage is None or _ImageDraw is None:
        return {}
    try:
        source=str(source_path or "")
        if source and os.path.isfile(source):
            with _PILImage.open(source) as im:
                im=im.convert("RGB"); im.thumbnail((72,96))
                pixels=[p for p in im.getdata() if 24 < sum(p)/3.0 < 238]
            if pixels:
                pixels.sort(key=lambda p:(max(p)-min(p))+sum(p)/16.0, reverse=True)
                sample=pixels[:max(8,len(pixels)//8)]
                accent=tuple(int(sum(p[i] for p in sample)/len(sample)) for i in range(3))
            else:
                accent=(78,146,196)
        else:
            accent=(78,146,196)

        rr,gg,bb=[v/255.0 for v in accent]
        h,l,s=colorsys.rgb_to_hls(rr,gg,bb)
        s=max(.38,min(.70,s)); l=max(.34,min(.50,l))
        rr,gg,bb=colorsys.hls_to_rgb(h,l,s)
        accent=(int(rr*255),int(gg*255),int(bb*255))
        hot=tuple(min(255,int(v*.30+255*.70)) for v in accent)
        base=(6,10,15)

        stamp="0"
        try: stamp=str(os.path.getmtime(source)) if source else "0"
        except Exception: pass
        cache=os.path.join(PERSISTENT_GENERATED_DIR,"subtitle_glass")
        secure_private_dir(cache)
        key=hashlib.sha1((source+"|"+stamp+"|subtitle-glass-v1|%s|%s|%s"%(width,row_width,row_height)).encode("utf-8","ignore")).hexdigest()[:20]

        def mix(a,b,t):
            return tuple(int(a[i]*(1.0-t)+b[i]*t) for i in range(3))

        specs={
            "frame":(1280,800,30,238),
            "inner":(1180,590,26,238),
            "row":(row_width,row_height,22,244),
            "row_selected":(row_width,row_height,22,244),
        }
        out={}
        for name,(w,hh,radius,alpha) in specs.items():
            target=os.path.join(cache,"%s_%s.png"%(key,name))
            out[name]=target
            if os.path.isfile(target):
                continue
            img=_PILImage.new("RGBA",(w,hh),(0,0,0,0))
            d=_ImageDraw.Draw(img)
            kind=("selected" if name=="row_selected" else ("row" if name=="row" else ("panel" if name=="frame" else "inner")))
            glow=_PILImage.new("RGBA",(w,hh),(0,0,0,0))
            gd=_ImageDraw.Draw(glow)
            ga=118 if kind=="selected" else (58 if kind in ("panel","inner") else 44)
            gw=4 if kind=="selected" else 2
            gd.rounded_rectangle((5,5,w-6,hh-6),radius=radius,outline=accent+(ga,),width=gw)
            if _ImageFilter is not None:
                glow=glow.filter(_ImageFilter.GaussianBlur(7 if kind in ("panel","selected") else 4))
            img=_PILImage.alpha_composite(img,glow)
            d=_ImageDraw.Draw(img)
            mix_value=.085 if kind=="panel" else (.105 if kind=="inner" else (.12 if kind=="row" else .20))
            fill=mix(base,accent,mix_value)
            fill_alpha=238 if kind in ("panel","inner") else 244
            border=236 if kind=="selected" else (150 if kind=="row" else 190)
            bw=2 if kind=="selected" else 1
            d.rounded_rectangle((2,2,w-3,hh-3),radius=radius,fill=fill+(fill_alpha,),outline=accent+(border,),width=bw)
            inner=mix(hot,(255,255,255),.34)
            d.rounded_rectangle((7,7,w-8,hh-8),radius=max(8,radius-6),outline=inner+((86 if kind=="selected" else 50),),width=1)
            sheen=_PILImage.new("RGBA",(w,hh),(0,0,0,0));sd=_ImageDraw.Draw(sheen)
            hi=mix(accent,(255,255,255),.46)
            top=max(24,int(hh*.45))
            for yy in range(8,top,6):
                t=(yy-8.0)/max(1.0,top-8.0)
                a=max(0,int((24 if kind in ("row","selected") else 14)*(1.0-t)**1.5))
                sd.rounded_rectangle((12,yy,w-13,min(hh-12,yy+8)),radius=max(6,radius-8),fill=hi+(a,))
            if _ImageFilter is not None:sheen=sheen.filter(_ImageFilter.GaussianBlur(4))
            img=_PILImage.alpha_composite(img,sheen)
            img.save(target,"PNG")
        return out
    except Exception as exc:
        optional_failure("player.subtitle_glass_assets",exc)
        return {}


class SubtitleGlassList(MenuList):
    def __init__(self, choices=None, width=1010, item_height=72):
        self.row_width=int(width)
        self.row_height=int(item_height)
        self._rows=list(choices or [])
        self._row_asset=""
        self._row_selected_asset=""
        self._rendering=False
        MenuList.__init__(self,[],enableWrapAround=True,content=eListboxPythonMultiContent)
        # Per-row adaptive fonts: each title selects the largest size that fits.
        for idx,size in enumerate((25,23,21,19,17)):
            self.l.setFont(idx,gFont("Regular",size))
        self.l.setItemHeight(self.row_height)

    def _font_index(self,text):
        n=len(str(text or ""))
        if n<=30:return 0
        if n<=44:return 1
        if n<=62:return 2
        if n<=82:return 3
        return 4

    def set_assets(self,row_asset,row_selected_asset):
        self._row_asset=str(row_asset or "")
        self._row_selected_asset=str(row_selected_asset or "")

    def set_choices(self,choices,selected=0):
        self._rows=list(choices or [])
        self._render(selected)

    def _render(self,selected=None):
        if self._rendering:return
        self._rendering=True
        if selected is None:
            selected=self.getSelectedIndex() if self._rows else 0
        rows=[]
        for idx,choice in enumerate(self._rows):
            label=str(choice[0] if isinstance(choice,(tuple,list)) and choice else choice or "")
            payload=choice
            row=[payload]
            frame_path=self._row_selected_asset if idx==selected else self._row_asset
            try:
                png=loadPNG(frame_path) if frame_path and os.path.isfile(frame_path) else None
            except Exception:
                png=None
            if png is not None:
                row.append(MultiContentEntryPixmapAlphaBlend(pos=(0,5),size=(self.row_width,66),png=png))
            font_idx=self._font_index(label)
            row.append(MultiContentEntryText(
                pos=(28,7),size=(self.row_width-56,58),
                font=font_idx,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=label
            ))
            rows.append(row)
        try:
            self.setList(rows)
            if rows:
                try:self.moveToIndex(max(0,min(int(selected),len(rows)-1)))
                except Exception:pass
        finally:
            self._rendering=False

    def selection_changed(self):
        if not self._rendering:self._render(self.getSelectedIndex())

    def selected_choice(self):
        idx=self.getSelectedIndex()
        return self._rows[idx] if 0<=idx<len(self._rows) else None


SUBTITLE_GLASS_SKIN = """
<screen name="SubtitleGlassChoiceScreen" position="0,0" size="1920,1080" backgroundColor="#00000000" flags="wfNoBorder">
    <widget name="frame" position="320,140" size="1280,800" alphatest="blend" transparent="1" zPosition="1"/>
    <widget name="inner" position="370,250" size="1180,590" alphatest="blend" transparent="1" zPosition="2"/>
    <widget name="title" position="390,185" size="1120,54" font="Regular;38" foregroundColor="#ffffff" transparent="1" zPosition="4"/>
    <widget name="list" position="415,268" size="1090,552" scrollbarMode="showNever" transparent="1" zPosition="5"/>
    <widget name="hint" position="390,860" size="1120,34" font="Regular;18" halign="center" foregroundColor="#a9c5d3" transparent="1" zPosition="5"/>
</screen>
"""

class SubtitleGlassChoiceScreen(Screen):
    skin=SUBTITLE_GLASS_SKIN
    def __init__(self,session,title,choices,source_path="",selected=0):
        Screen.__init__(self,session)
        self._choices=list(choices or [])
        self._source_path=str(source_path or "")
        self._selected=max(0,int(selected or 0))
        self["frame"]=Pixmap();self["inner"]=Pixmap()
        self["title"]=Label(str(title or "Subtitles"))
        self["hint"]=Label(_("OK  Select   •   BACK  Close   •   UP / DOWN  Navigate"))
        self["list"]=SubtitleGlassList(self._choices,width=1090,item_height=76)
        self["actions"]=ActionMap(
            ["OkCancelActions","DirectionActions"],
            {"ok":self.accept,"cancel":self.cancel_close,"up":self.up,"down":self.down,
             "left":self.page_up,"right":self.page_down},
            -2,
        )
        self["list"].onSelectionChanged.append(self._selection_changed)
        self.onLayoutFinish.append(self._layout_ready)

    def _layout_ready(self):
        assets=_subtitle_glass_assets(self._source_path,1280,1090,66)
        for name,key in (("frame","frame"),("inner","inner")):
            try:
                path=assets.get(key)
                if path and self[name].instance is not None:
                    self[name].instance.setPixmapFromFile(path);self[name].show()
            except Exception as exc:optional_failure("player.subtitle_glass_panel",exc)
        self["list"].set_assets(assets.get("row"),assets.get("row_selected"))
        try:
            if self["list"].instance is not None:self["list"].instance.setSelectionEnable(0)
        except Exception:pass
        self["list"].set_choices(self._choices,self._selected)

    def _selection_changed(self):
        try:self["list"].selection_changed()
        except Exception as exc:optional_failure("player.subtitle_glass_selection",exc)

    def up(self):
        try:self["list"].up()
        except Exception:pass
    def down(self):
        try:self["list"].down()
        except Exception:pass
    def page_up(self):
        try:self["list"].pageUp()
        except Exception:pass
    def page_down(self):
        try:self["list"].pageDown()
        except Exception:pass

    def accept(self):
        choice=self["list"].selected_choice()
        if choice is not None:self.close(choice)

    def cancel_close(self):
        self.close(None)

PLAYER_INFO_SKIN = """
<screen name="PlayerInformationOverlay" position="0,0" size="1920,1080" backgroundColor="#00000000" flags="wfNoBorder">
 <ePixmap pixmap="%(scrim)s" position="0,0" size="1920,1080" alphatest="blend" zPosition="1"/>
 <widget name="adaptive_main" position="210,175" size="1500,690" alphatest="blend" transparent="1" zPosition="2"/>
 <widget name="adaptive_poster" position="260,225" size="280,400" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="poster" position="275,240" size="250,370" alphatest="blend" scale="1" zPosition="4"/>
 <widget name="title" position="575,220" size="1035,60" font="Regular;38" foregroundColor="#ffffff" transparent="1" zPosition="5"/>
 <widget name="meta" position="575,286" size="1035,34" font="Regular;19" foregroundColor="#9bd9f5" transparent="1" zPosition="5"/>

 <widget name="adaptive_desc" position="555,335" size="1080,270" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="description" position="585,365" size="1020,205" font="Regular;25" foregroundColor="#f7f9fb" transparent="1" valign="top" zPosition="5"/>
 <widget name="page" position="1500,570" size="100,25" font="Regular;16" halign="right" foregroundColor="#9bd9f5" transparent="1" zPosition="5"/>

 <widget name="adaptive_cast" position="555,630" size="520,120" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="cast_label" position="580,648" size="120,28" font="Regular;18" foregroundColor="#9bd9f5" transparent="1" zPosition="5"/>
 <widget name="cast" position="580,678" size="470,55" font="Regular;19" foregroundColor="#ffffff" transparent="1" zPosition="5"/>

 <widget name="adaptive_director" position="1090,630" size="260,120" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="director_label" position="1110,648" size="220,28" font="Regular;18" halign="center" foregroundColor="#9bd9f5" transparent="1" zPosition="5"/>
 <widget name="director" position="1110,680" size="220,50" font="Regular;18" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="5"/>

 <widget name="adaptive_writer" position="1365,630" size="260,120" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="writer_label" position="1385,648" size="220,28" font="Regular;18" halign="center" foregroundColor="#9bd9f5" transparent="1" zPosition="5"/>
 <widget name="writer" position="1385,680" size="220,50" font="Regular;18" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="5"/>

 <widget name="hint" position="575,790" size="1035,34" font="Regular;17" halign="center" foregroundColor="#a9c5d3" transparent="1" zPosition="5"/>
</screen>
""" % {"scrim":_asset("us20_player_info_scrim.png")}

class PlayerInformationOverlay(Screen):
    skin=PLAYER_INFO_SKIN
    def __init__(self,session,name,item,media_type,meta,poster_path=None):
        Screen.__init__(self,session);self.item=item if isinstance(item,dict) else {}
        self["poster"]=Pixmap();self["adaptive_main"]=Pixmap();self["adaptive_poster"]=Pixmap();self["adaptive_desc"]=Pixmap();self["adaptive_cast"]=Pixmap();self["adaptive_director"]=Pixmap();self["adaptive_writer"]=Pixmap()
        self["title"]=Label(str(name or _("Media information"))[:105]);self["meta"]=Label(str(meta or "")[:160])
        desc=self.item.get("description") or self.item.get("descr") or self.item.get("plot") or self.item.get("overview") or _("No additional description is available.")
        self._pages=self._make_pages(desc);self._page=0;self["description"]=Label(self._pages[0]);self["page"]=Label("")
        cast=self.item.get("actors") or self.item.get("cast") or self.item.get("actor") or "";director=self.item.get("director") or self.item.get("directors") or "";writer=self.item.get("writer") or self.item.get("writers") or self.item.get("creator") or ""
        self["cast_label"]=Label(_("Cast") if cast else "");self["cast"]=Label(str(cast)[:135]);self["director_label"]=Label(_("Director") if director else "");self["director"]=Label(str(director)[:68]);self["writer_label"]=Label(_("Writer") if writer else "");self["writer"]=Label(str(writer)[:68]);self["hint"]=Label(_("UP / DOWN  Read description     •     YELLOW / OK / BACK  Close"))
        self._poster_path=poster_path;self.onLayoutFinish.append(self._layout_ready);self._sync_page()
        self["actions"]=ActionMap(["OkCancelActions","ColorActions","DirectionActions"],{"cancel":self.close,"ok":self.close,"yellow":self.close,"up":self.page_up,"down":self.page_down},-1000)
    @staticmethod
    def _make_pages(text,limit=470):
        words=str(text or "").replace("\\n"," ").split();pages=[];buf=[];count=0
        for word in words:
            extra=len(word)+(1 if buf else 0)
            if buf and count+extra>limit:pages.append(" ".join(buf));buf=[word];count=len(word)
            else:buf.append(word);count+=extra
        if buf:pages.append(" ".join(buf))
        return pages or [str(text or "")]
    def _sync_page(self):
        try:self["description"].setText(self._pages[self._page]);self["page"].setText(("%d / %d"%(self._page+1,len(self._pages))) if len(self._pages)>1 else "")
        except Exception as exc:optional_failure("player",exc)
    def _layout_ready(self):
        try:
            if self._poster_path and os.path.isfile(self._poster_path):
                self["poster"].instance.setPixmapFromFile(self._poster_path);self["poster"].show()
                frames=_adaptive_info_frames(self._poster_path)
                for widget_name,key in (("adaptive_main","main"),("adaptive_poster","poster"),("adaptive_desc","desc"),("adaptive_cast","cast"),("adaptive_director","director"),("adaptive_writer","writer")):
                    path=frames.get(key)
                    widget=self[widget_name]
                    if path and os.path.isfile(path) and widget.instance is not None:
                        widget.instance.setPixmapFromFile(path);widget.show()
        except Exception as exc:optional_failure("player.info_layout",exc)
    def page_up(self):
        if self._pages:self._page=(self._page-1)%len(self._pages);self._sync_page()
    def page_down(self):
        if self._pages:self._page=(self._page+1)%len(self._pages);self._sync_page()



LIVE_ZAP_SKIN = """
<screen name="UltraStalkerLiveZapList" position="0,0" size="590,1080" backgroundColor="#02070b" flags="wfNoBorder">
    <widget name="panel" position="0,0" size="590,1080" zPosition="-6" alphatest="blend" />
    <widget name="folder_bg" position="204,18" size="358,46" zPosition="3" alphatest="blend" />
    <widget name="channel_bg" position="204,72" size="358,38" zPosition="3" alphatest="blend" />
    <widget name="picon" position="28,18" size="166,100" zPosition="7" alphatest="blend" />
    <widget name="title" position="218,20" size="330,42" font="Regular;24" foregroundColor="#ffffff" transparent="1" zPosition="8" valign="center" />
    <widget name="subtitle" position="218,73" size="330,36" font="Regular;19" foregroundColor="#e8f6fb" transparent="1" zPosition="8" valign="center" />
    <widget name="bg0" position="18,143" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num0" position="24,143" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row0" position="102,143" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg1" position="18,199" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num1" position="24,199" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row1" position="102,199" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg2" position="18,255" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num2" position="24,255" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row2" position="102,255" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg3" position="18,311" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num3" position="24,311" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row3" position="102,311" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg4" position="18,367" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num4" position="24,367" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row4" position="102,367" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg5" position="18,423" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num5" position="24,423" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row5" position="102,423" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg6" position="18,479" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num6" position="24,479" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row6" position="102,479" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg7" position="18,535" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num7" position="24,535" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row7" position="102,535" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg8" position="18,591" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num8" position="24,591" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row8" position="102,591" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg9" position="18,647" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num9" position="24,647" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row9" position="102,647" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg10" position="18,703" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num10" position="24,703" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row10" position="102,703" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg11" position="18,759" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num11" position="24,759" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row11" position="102,759" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg12" position="18,815" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num12" position="24,815" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row12" position="102,815" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg13" position="18,871" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num13" position="24,871" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row13" position="102,871" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg14" position="18,927" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num14" position="24,927" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row14" position="102,927" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="footer_count_bg" position="18,1000" size="118,42" zPosition="3" alphatest="blend" />
    <widget name="footer_page_bg" position="142,1000" size="126,42" zPosition="3" alphatest="blend" />
    <widget name="footer_play_bg" position="274,1000" size="126,42" zPosition="3" alphatest="blend" />
    <widget name="footer_close_bg" position="406,1000" size="166,42" zPosition="3" alphatest="blend" />
    <widget name="counter" position="22,1001" size="110,40" font="Regular;15" halign="center" valign="center" foregroundColor="#eaf8ff" transparent="1" zPosition="8" />
    <widget name="footer_page" position="146,1001" size="118,40" font="Regular;15" halign="center" valign="center" foregroundColor="#eaf8ff" transparent="1" zPosition="8" />
    <widget name="footer_play" position="278,1001" size="118,40" font="Regular;15" halign="center" valign="center" foregroundColor="#eaf8ff" transparent="1" zPosition="8" />
    <widget name="footer_close" position="410,1001" size="158,40" font="Regular;15" halign="center" valign="center" foregroundColor="#eaf8ff" transparent="1" zPosition="8" />
</screen>
"""

def _clean_live_name(value):
    text=str(value or "").strip()
    try:text=unicodedata.normalize("NFKC",text)
    except Exception as exc:optional_failure("player.optional_guard",exc)
    text=re.sub(r"^\s*#+\s*","",text);text=re.sub(r"\s*#+\s*$","",text)
    text=re.sub(r"^\s*[A-Z]{2,3}\s*[:|•/_-]\s*","",text)
    text=re.sub(r"(?i)\(\s*(?:EVENT\s*ONLY|BACKUP|TEST|VIP)\s*\)"," ",text)
    tokens=("3840P","2160P","1440P","1080P","720P","576P","480P","FULL HD","FULLHD","FHD","ULTRA HD","ULTRAHD","UHD","HDR10+","HDR10","HDR","DOLBY VISION","DOLBYVISION","HEVC","H.265","H265","H.264","H264","60FPS","50FPS","30FPS","8K","4K","RAW")
    for _ in range(5):
        old=text
        for token in sorted(tokens,key=len,reverse=True):
            text=re.sub(r"(?i)(?<![A-Z0-9])"+re.escape(token)+r"(?![A-Z0-9])"," ",text)
        text=re.sub(r"\s*[\[\]{}<>|•·▶►◀◄]+\s*"," ",text)
        text=re.sub(r"\s*[:;,_/\\]+\s*"," ",text)
        text=re.sub(r"\s{2,}"," ",text).strip(" -:|•·_")
        if text==old:break
    return text or str(value or "Channel").strip()

@image_budgeted
def _zap_palette(path):
    if _PILImage is None or not path or not os.path.isfile(str(path)):
        return (52,148,202),(104,210,255)
    try:
        with _PILImage.open(path) as im:
            im=im.convert("RGB"); im.thumbnail((80,80))
            pixels=list(im.getdata())
        useful=[c for c in pixels if max(c)>42 and (max(c)-min(c))>12]
        if not useful:
            return (52,148,202),(104,210,255)
        useful.sort(key=lambda c:(max(c)-min(c))*1.6+sum(c)/3.0,reverse=True)
        top=useful[:max(8,len(useful)//5)]
        accent=tuple(int(sum(c[i] for c in top)/len(top)) for i in range(3))
        hot=tuple(min(255,int(v*.68+255*.32)) for v in accent)
        return accent,hot
    except Exception:
        return (52,148,202),(104,210,255)

def _zap_assets(picon_path):
    cache=os.path.join(PERSISTENT_GENERATED_DIR,"live_zap_seriesglass_1041")
    try:secure_private_dir(cache)
    except Exception:return {}
    try:
        stamp=str(picon_path or "neutral")
        if picon_path and os.path.isfile(str(picon_path)):
            stamp+="|%s"%os.path.getmtime(str(picon_path))
        key=hashlib.sha1((stamp+"|series-glass-1041").encode("utf-8","ignore")).hexdigest()[:16]
        panel=os.path.join(cache,key+"_panel.png")
        folder=os.path.join(cache,key+"_folder.png")
        channel=os.path.join(cache,key+"_channel.png")
        normal=os.path.join(cache,key+"_row.png")
        selected=os.path.join(cache,key+"_selected.png")
        footer_count=os.path.join(cache,key+"_footer_count.png")
        footer_page=os.path.join(cache,key+"_footer_page.png")
        footer_play=os.path.join(cache,key+"_footer_play.png")
        footer_close=os.path.join(cache,key+"_footer_close.png")
        if all(os.path.isfile(x) and os.path.getsize(x)>150 for x in (panel,folder,channel,normal,selected,footer_count,footer_page,footer_play,footer_close)):
            return {"panel":panel,"folder":folder,"channel":channel,"normal":normal,"selected":selected,
                    "footer_count":footer_count,"footer_page":footer_page,"footer_play":footer_play,"footer_close":footer_close}
        if _PILImage is None or _ImageDraw is None:return {}
        accent,_hot=_zap_palette(picon_path)
        base=(4,12,18)
        def mix(a,b,t):
            return tuple(int(a[i]*(1.0-t)+b[i]*t) for i in range(3))

        # Full drawer: same quiet translucent adaptive glass as details panels.
        p=_PILImage.new("RGBA",(590,1080),(0,0,0,0));pd=_ImageDraw.Draw(p)
        pfill=mix((3,10,16),accent,0.08)
        pd.rounded_rectangle((2,2,587,1077),radius=28,fill=pfill+(76,),outline=accent+(158,),width=1)
        inner=mix(accent,(255,255,255),0.40)
        pd.rounded_rectangle((8,8,581,1071),radius=22,outline=inner+(22,),width=1)
        p.save(panel,"PNG")

        # Two compact adaptive glass boxes: folder identity and selected channel.
        for target,size,radius,fill_mix,alpha,border in (
            (folder,(358,46),16,0.14,152,224),
            (channel,(358,38),14,0.18,166,238),
        ):
            w,h=size
            g=_PILImage.new("RGBA",size,(0,0,0,0));gd=_ImageDraw.Draw(g)
            fill=mix((4,12,18),accent,fill_mix)
            gd.rounded_rectangle((2,2,w-3,h-3),radius=radius,fill=fill+(alpha,),outline=accent+(border,),width=2)
            gd.rounded_rectangle((7,7,w-8,h-8),radius=max(7,radius-6),outline=inner+(78,),width=1)
            sheen=_PILImage.new("RGBA",size,(0,0,0,0));sd=_ImageDraw.Draw(sheen)
            sd.rounded_rectangle((12,6,w-13,max(10,int(h*.48))),radius=max(6,radius-8),fill=inner+(18,))
            if _ImageFilter is not None:
                try:sheen=sheen.filter(_ImageFilter.GaussianBlur(radius=3))
                except Exception as exc:optional_failure("player.optional_guard",exc)
            g=_PILImage.alpha_composite(g,sheen);g.save(target,"PNG")

        # Footer controls are the *same material* as the folder/channel glass:
        # identical tint strength, alpha, bright adaptive rim and top sheen.
        for target,size,radius in (
            (footer_count,(118,42),14),(footer_page,(126,42),14),
            (footer_play,(126,42),14),(footer_close,(166,42),14),
        ):
            w,h=size
            g=_PILImage.new("RGBA",size,(0,0,0,0));gd=_ImageDraw.Draw(g)
            fill=mix((4,12,18),accent,0.14)
            gd.rounded_rectangle((2,2,w-3,h-3),radius=radius,fill=fill+(152,),outline=accent+(224,),width=2)
            gd.rounded_rectangle((7,7,w-8,h-8),radius=max(7,radius-6),outline=inner+(78,),width=1)
            sheen=_PILImage.new("RGBA",size,(0,0,0,0));sd=_ImageDraw.Draw(sheen)
            sd.rounded_rectangle((12,6,w-13,max(10,int(h*.48))),radius=max(6,radius-8),fill=inner+(18,))
            if _ImageFilter is not None:
                try:sheen=sheen.filter(_ImageFilter.GaussianBlur(radius=3))
                except Exception as exc:optional_failure("player.optional_guard",exc)
            g=_PILImage.alpha_composite(g,sheen)
            g.save(target,"PNG")

        for target,is_selected in ((normal,False),(selected,True)):
            r=_PILImage.new("RGBA",(554,52),(0,0,0,0));rd=_ImageDraw.Draw(r)
            if is_selected:
                fill=mix((4,13,18),accent,0.18);alpha=126;border=232;width=2
            else:
                fill=mix((4,12,18),accent,0.10);alpha=108;border=130;width=1
            rd.rounded_rectangle((2,2,551,49),radius=17,fill=fill+(alpha,),outline=accent+(border,),width=width)
            # Same series-row rule: single floating card, no inner duplicate rim.
            sheen=_PILImage.new("RGBA",(554,52),(0,0,0,0));sd=_ImageDraw.Draw(sheen)
            sd.rounded_rectangle((12,7,541,25),radius=9,fill=inner+(15 if is_selected else 11,))
            if _ImageFilter is not None:
                try:sheen=sheen.filter(_ImageFilter.GaussianBlur(radius=3))
                except Exception as exc:optional_failure("player.optional_guard",exc)
            r=_PILImage.alpha_composite(r,sheen)
            r.save(target,"PNG")
        return {"panel":panel,"folder":folder,"channel":channel,"normal":normal,"selected":selected,
                "footer_count":footer_count,"footer_page":footer_page,"footer_play":footer_play,"footer_close":footer_close}
    except Exception as exc:
        optional_failure("player.zap_assets",exc)
        return {}

@image_budgeted
def _fit_zap_picon(path):
    if _PILImage is None or not path or not os.path.isfile(str(path)):
        return path
    try:
        cache=os.path.join(PERSISTENT_GENERATED_DIR,"live_zap_glass")
        secure_private_dir(cache)
        stamp="%s|%s|162x96"%(path,os.path.getmtime(path))
        target=os.path.join(cache,hashlib.sha1(stamp.encode("utf-8","ignore")).hexdigest()[:16]+"_picon.png")
        if os.path.isfile(target) and os.path.getsize(target)>100:return target
        with _PILImage.open(path) as im:
            im=im.convert("RGBA")
            im.thumbnail((154,88),getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1))
            canvas=_PILImage.new("RGBA",(162,96),(0,0,0,0))
            x=(162-im.width)//2;y=(96-im.height)//2
            canvas.alpha_composite(im,(x,y))
            canvas.save(target,"PNG")
        return target
    except Exception:
        return path

class UltraStalkerLiveZapList(Screen):
    skin=LIVE_ZAP_SKIN
    VISIBLE=15

    def __init__(self,session,channels,current_index=0,title="Live Channels",picon_path=None,page_loader=None,page_size=10,total=0):
        Screen.__init__(self,session)
        self.channels=list(channels or [])
        self.total=max(len(self.channels),int(total or 0))
        if self.total and len(self.channels)<self.total:self.channels.extend([None]*(self.total-len(self.channels)))
        self.cursor=max(0,min(int(current_index or 0),max(0,len(self.channels)-1))) if self.channels else 0
        self.offset=max(0,min(self.cursor,max(0,len(self.channels)-self.VISIBLE)))
        self.title_text=_clean_live_name(str(title or "Live Channels"))
        self.picon_path=_fit_zap_picon(picon_path)
        self.page_loader=page_loader if callable(page_loader) else None
        self.page_size=max(1,int(page_size or 10))
        self.jobs=queue.Queue();self.loading=False;self._pending_pages=set();self._page_attempts={};self._render_cache={}
        self._page_futures={}
        self["panel"]=Pixmap();self["folder_bg"]=Pixmap();self["channel_bg"]=Pixmap();self["picon"]=Pixmap()
        self["footer_count_bg"]=Pixmap();self["footer_page_bg"]=Pixmap();self["footer_play_bg"]=Pixmap();self["footer_close_bg"]=Pixmap()
        self["title"]=Label(self.title_text);self["subtitle"]=Label("")
        self["counter"]=Label("");self["footer_page"]=Label(_("◀▶  Page"));self["footer_play"]=Label(_("OK  Play"));self["footer_close"]=Label(_("BACK  Close"))
        for i in range(self.VISIBLE):
            self["bg%d"%i]=Pixmap();self["num%d"%i]=Label("");self["row%d"%i]=Label("")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{
            "ok":self.keyOK,"cancel":self._cancel,"up":lambda:self._move(-1),"down":lambda:self._move(1),
            "left":self.page_up,"right":self.page_down,
        },-1000)
        self.timer=eTimer();self.timer_conn=None
        try:self.timer_conn=self.timer.timeout.connect(self._drain)
        except Exception:self.timer.callback.append(self._drain)
        self.onLayoutFinish.append(self._ready);self.onClose.append(self._cleanup)

    def _fit_folder_title_font(self):
        """Fit the complete Live folder name inside the fixed Mini List header."""
        try:
            value=str(self.title_text or "Live Channels")
            # Weighted width estimate: Arabic glyphs are visually wider than
            # narrow Latin punctuation, so raw len() produced oversized headers.
            units=sum(1.28 if ord(ch)>0x2ff else (0.55 if ch in " ilI1|.,:'" else 1.0) for ch in value)
            # Header is 330 px wide. Keep short names premium/large, then scale
            # continuously down to a readable floor for long mixed Arabic/Latin.
            size=int(max(14,min(24,round(24.0*min(1.0,20.5/max(1.0,units))))))
            if self["title"].instance is not None:
                self["title"].instance.setFont(gFont("Regular",size))
        except Exception as exc:
            optional_failure("player.zap_folder_font_fit",exc)

    def _ready(self):
        self._fit_folder_title_font()
        self.assets=_zap_assets(self.picon_path)
        try:
            p=self.assets.get("panel")
            if p:self["panel"].instance.setPixmapFromFile(p);self["panel"].show()
            folder=self.assets.get("folder");channel=self.assets.get("channel")
            if folder:self["folder_bg"].instance.setPixmapFromFile(folder);self["folder_bg"].show()
            if channel:self["channel_bg"].instance.setPixmapFromFile(channel);self["channel_bg"].show()
            for key,name in (("footer_count","footer_count_bg"),("footer_page","footer_page_bg"),
                             ("footer_play","footer_play_bg"),("footer_close","footer_close_bg")):
                path=self.assets.get(key)
                if path and os.path.isfile(path):
                    self[name].instance.setPixmapFromFile(path);self[name].show()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        try:
            if self.picon_path and os.path.isfile(self.picon_path):
                self["picon"].instance.setPixmapFromFile(self.picon_path);self["picon"].show()
            else:self["picon"].hide()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        self._render(force=True);self._load_all()

    def _load_page_for_index(self,index):
        """Load only the page needed by the visible cursor.

        The old drawer fetched every folder page immediately on open and repainted
        all 15 rows every 100ms as pages arrived. That looked like animation and
        competed with playback. Navigation is now local and page fetches are lazy.
        """
        if self.page_loader is None or not self.total:return
        page=max(1,int(index)//self.page_size+1)
        base=(page-1)*self.page_size
        end=min(len(self.channels),base+self.page_size)
        if base<end and all(isinstance(x,dict) for x in self.channels[base:end]):return
        pending=getattr(self,"_pending_pages",set())
        if page in pending:return
        attempts=getattr(self,"_page_attempts",{})
        if int(attempts.get(page,0) or 0)>=2:return
        attempts[page]=int(attempts.get(page,0) or 0)+1;self._page_attempts=attempts
        pending.add(page);self._pending_pages=pending
        page_loader=self.page_loader;jobs=self.jobs
        def worker():
            try:
                try:rows=page_loader(page)
                except TypeError:rows=page_loader(page,None)
                except Exception:rows=[]
                jobs.put((page,[dict(x) for x in (rows or []) if isinstance(x,dict)]))
            finally:
                jobs.put((-page,[]))
        future=None
        try:
            future=_PLAYER_BG_EXECUTOR.submit(worker)
            self._page_futures[page]=future
            try:
                if not self.timer.isActive():self.timer.start(220,False)
            except Exception:self.timer.start(220,False)
        except Exception:
            pending.discard(page);self._page_futures.pop(page,None)
            if future is not None:
                try:future.cancel()
                except Exception:pass

    def _warm_visible_pages(self,include_adjacent=True):
        """Prefetch every portal page needed by the 15 visible drawer rows.

        The drawer viewport can span two portal pages (12-item portal page vs
        15 visible rows).  Loading only the cursor page left lower rows stuck on
        "Loading channel..." until the cursor physically reached them.
        """
        if self.page_loader is None or not self.channels:return
        total=len(self.channels)
        windows=[(self.offset,min(total-1,self.offset+self.VISIBLE-1))]
        if include_adjacent:
            if self.offset>0:
                prev=max(0,self.offset-self.VISIBLE);windows.append((prev,min(total-1,prev+self.VISIBLE-1)))
            nxt=self.offset+self.VISIBLE
            if nxt<total:windows.append((nxt,min(total-1,nxt+self.VISIBLE-1))
            )
        pages=set()
        for start,end in windows:
            if end<start:continue
            first=max(1,start//self.page_size+1);last=max(first,end//self.page_size+1)
            pages.update(range(first,last+1))
        for page in sorted(pages):
            self._load_page_for_index((page-1)*self.page_size)

    def _load_all(self):
        self._warm_visible_pages(include_adjacent=True)

    def _drain(self):
        changed_visible=False
        while True:
            try:page,rows=self.jobs.get_nowait()
            except queue.Empty:break
            if page<0:
                try:self._pending_pages.discard(-page);self._page_futures.pop(-page,None)
                except Exception as exc:optional_failure("player.silent_guard",exc)
                continue
            if page==0:continue
            base=(page-1)*self.page_size
            if rows:
                try:self._page_attempts[page]=99
                except Exception as exc:optional_failure("player.silent_guard",exc)
            for i,row in enumerate(rows):
                pos=base+i
                if 0<=pos<len(self.channels):
                    self.channels[pos]=row
                    if self.offset<=pos<self.offset+self.VISIBLE:changed_visible=True
        if changed_visible:self._render(force=True)
        # Keep the whole current viewport warm even when portal pages arrive out of order.
        if not getattr(self,"_pending_pages",set()):
            self._warm_visible_pages(include_adjacent=True)
        # Stage-3: the drawer poller is demand-driven. Once all visible/adjacent
        # page jobs have drained there is nothing to poll until navigation queues
        # another page, so stop the repeating 220 ms GUI timer completely.
        if not getattr(self,"_pending_pages",set()):
            try:self.timer.stop()
            except Exception as exc:optional_failure("player.zap_timer_idle_stop",exc)

    def _name(self,item,index):
        if not isinstance(item,dict):return "Loading channel %d..."%(index+1)
        return _clean_live_name(item.get("name") or item.get("title") or ("Channel %d"%(index+1)))


    def _render(self,force=False):
        total=len(self.channels)
        item=self.channels[self.cursor] if 0<=self.cursor<total else None
        subtitle=self._name(item,self.cursor)[:64] if total else "No channels"
        counter="%d / %d"%(self.cursor+1,total) if total else "0 / 0"
        cache=self._render_cache
        if force or cache.get("subtitle")!=subtitle:
            self["subtitle"].setText(subtitle)
            try:
                units=sum(1.65 if ord(ch)>0x2ff else (0.58 if ch in " ilI1|.,:'" else 1.0) for ch in subtitle)
                size=19 if units<=27 else (17 if units<=34 else (15 if units<=43 else 13))
                if self["subtitle"].instance is not None:self["subtitle"].instance.setFont(gFont("Regular",size))
            except Exception as exc:optional_failure("player.zap_header_font",exc)
            cache["subtitle"]=subtitle
        if force or cache.get("counter")!=counter:
            self["counter"].setText(counter);cache["counter"]=counter
        normal=(getattr(self,"assets",{}) or {}).get("normal");selected=(getattr(self,"assets",{}) or {}).get("selected")
        for row in range(self.VISIBLE):
            idx=self.offset+row
            label=self._name(self.channels[idx],idx)[:45] if 0<=idx<total else ""
            display=("▶  "+label) if idx==self.cursor and label else label
            number=str(idx+1) if 0<=idx<total else ""
            bg=selected if idx==self.cursor else normal
            state=(idx,display,number,bg)
            if not force and cache.get(("row",row))==state:continue
            self["row%d"%row].setText(display)
            self["num%d"%row].setText(number)
            try:
                if bg and os.path.isfile(bg):
                    self["bg%d"%row].instance.setPixmapFromFile(bg);self["bg%d"%row].show()
                else:self["bg%d"%row].hide()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            cache[("row",row)]=state

    def _move(self,delta):
        if not self.channels:return
        total=len(self.channels)
        old=self.cursor
        if int(delta)>0:
            self.cursor=(self.cursor+1)%total
        else:
            self.cursor=(self.cursor-1)%total
        if self.cursor==0 and old==total-1:
            self.offset=0
        elif self.cursor==total-1 and old==0:
            self.offset=max(0,total-self.VISIBLE)
        elif self.cursor<self.offset:
            self.offset=self.cursor
        elif self.cursor>=self.offset+self.VISIBLE:
            self.offset=max(0,min(self.cursor-self.VISIBLE+1,total-self.VISIBLE))
        self._warm_visible_pages(include_adjacent=True)
        self._render(force=True)

    def _page_shift(self,direction):
        if not self.channels:return
        total=len(self.channels)
        row=max(0,self.cursor-self.offset)
        max_offset=max(0,total-self.VISIBLE)
        if int(direction)>0:
            if self.offset>=max_offset:
                # Final page: RIGHT means the actual final channel.
                self.cursor=total-1
                self.offset=max_offset
            else:
                self.offset=min(max_offset,self.offset+self.VISIBLE)
                self.cursor=min(total-1,self.offset+row)
        else:
            if self.offset<=0:
                # First page: LEFT from any row means channel 1.
                self.offset=0;self.cursor=0
            else:
                self.offset=max(0,self.offset-self.VISIBLE)
                self.cursor=min(total-1,self.offset+row)
        self._warm_visible_pages(include_adjacent=True)
        self._render(force=True)

    def page_up(self):
        self._page_shift(-1)

    def page_down(self):
        self._page_shift(1)

    def keyOK(self):
        if 0<=self.cursor<len(self.channels) and isinstance(self.channels[self.cursor],dict):
            self.close((self.cursor,self.channels[self.cursor]))

    def _cancel(self):
        self.close(None)

    def _cleanup(self):
        try:self.timer.stop()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        for future in list(getattr(self,"_page_futures",{}).values()):
            try:future.cancel()
            except Exception as exc:optional_failure("player.zap_page_future_cancel",exc)
        try:self._page_futures.clear();self._pending_pages.clear()
        except Exception:pass
        try:
            if self.timer_conn is not None:self.timer_conn.disconnect()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        try:
            if self._drain in self.timer.callback:self.timer.callback.remove(self._drain)
        except Exception as exc:optional_failure("player.zap_timer_callback_remove",exc)


class IPTVInfoBarShowHide(object):
    """The same proven show/hide lifecycle used by the reference implementation players."""

    STATE_HIDDEN = 0
    STATE_HIDING = 1
    STATE_SHOWING = 2
    STATE_SHOWN = 3
    skipToggleShow = False

    def __init__(self):
        self.__showhide_tracker = ServiceEventTracker(
            screen=self,
            eventmap={iPlayableService.evStart: self.serviceStarted},
        )
        self.__state = self.STATE_SHOWN
        self.__locked = 0
        self.hideTimer = eTimer()
        try:
            self.hideTimer_conn = self.hideTimer.timeout.connect(self.doTimerHide)
        except Exception:
            self.hideTimer.callback.append(self.doTimerHide)
        self.hideTimer.start(6000, True)
        self.onShow.append(self.__onShow)
        self.onHide.append(self.__onHide)

    def OkPressed(self):
        self.toggleShow()

    def __onShow(self):
        self.__state = self.STATE_SHOWN
        self.startHideTimer()

    def __onHide(self):
        self.__state = self.STATE_HIDDEN

    def serviceStarted(self):
        if getattr(self, "execing", False):
            self.doShow()

    def startHideTimer(self):
        if self.__state == self.STATE_SHOWN and not self.__locked:
            self.hideTimer.stop()
            self.hideTimer.start(6000, True)
        self.skipToggleShow = False

    def doShow(self):
        self.hideTimer.stop()
        self.show()
        self.startHideTimer()

    def doTimerHide(self):
        self.hideTimer.stop()
        if self.__state == self.STATE_SHOWN:
            self.hide()

    def toggleShow(self):
        if self.skipToggleShow:
            self.skipToggleShow = False
            return
        if self.__state == self.STATE_HIDDEN:
            self.show()
            self.hideTimer.stop()
        else:
            self.hide()
            self.startHideTimer()

    def lockShow(self):
        self.__locked += 1
        if getattr(self, "execing", False):
            self.show()
            self.hideTimer.stop()

    def unlockShow(self):
        self.__locked = max(0, self.__locked - 1)
        if getattr(self, "execing", False):
            self.startHideTimer()



NEXT_EPISODE_SKIN = """
<screen name="UltraStalkerNextEpisodePrompt" position="center,center" size="760,250" backgroundColor="#071522" flags="wfNoBorder">
    <eLabel position="0,0" size="760,250" backgroundColor="#071522" />
    <eLabel position="0,0" size="760,5" backgroundColor="#29b7ff" />
    <widget name="title" position="50,32" size="660,45" font="Regular;29" halign="center" foregroundColor="#ffffff" transparent="1" />
    <widget name="episode" position="55,88" size="650,42" font="Regular;22" halign="center" foregroundColor="#b9d7e8" transparent="1" />
    <widget name="countdown" position="55,143" size="650,34" font="Regular;20" halign="center" foregroundColor="#6ed7ff" transparent="1" />
    <widget name="hint" position="55,196" size="650,28" font="Regular;17" halign="center" foregroundColor="#91a9b8" transparent="1" />
</screen>
"""


class UltraStalkerNextEpisodePrompt(Screen):
    """Small cancelable 10-second autoplay prompt shown after a natural episode EOF."""

    skin = NEXT_EPISODE_SKIN

    def __init__(self, session, next_item, seconds=10):
        Screen.__init__(self, session)
        self.remaining = max(1, int(seconds or 10))
        item = next_item if isinstance(next_item, dict) else {}
        title = str(item.get("name") or item.get("title") or item.get("episode_name") or _("Next Episode"))
        number = item.get("episode") or item.get("number") or item.get("episode_id") or ""
        self["title"] = Label(_("Play Next Episode"))
        self["episode"] = Label((_("Episode %s  •  %s") % (number, title))[:70] if number else title[:70])
        self["countdown"] = Label("")
        self["hint"] = Label(_("OK Play now   •   BACK Cancel   •   YELLOW Disable autoplay"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self._accept, "green": self._accept,
            "cancel": self._cancel, "red": self._cancel,
            "yellow": self._disable_session,
        }, -1000)
        self.timer = eTimer()
        self.timer_conn = None
        try:
            self.timer_conn = self.timer.timeout.connect(self._tick)
        except Exception:
            self.timer.callback.append(self._tick)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._cleanup_timer)

    def _start(self):
        self._render()
        try: self.timer.start(1000, False)
        except Exception as exc: optional_failure("player.optional_guard", exc)

    def _render(self):
        self["countdown"].setText(_("Next episode starts in %d seconds") % self.remaining)

    def _tick(self):
        self.remaining -= 1
        if self.remaining <= 0:
            self._accept()
            return
        self._render()

    def _accept(self):
        self._cleanup_timer()
        self.close(True)

    def _cancel(self):
        self._cleanup_timer()
        self.close(False)

    def _disable_session(self):
        self._cleanup_timer()
        self.close("session_off")

    def _cleanup_timer(self):
        try: self.timer.stop()
        except Exception as exc: optional_failure("player.optional_guard", exc)
        try:
            if self.timer_conn is not None: self.timer_conn.disconnect()
        except Exception as exc: optional_failure("player.optional_guard", exc)
        try:
            if self._tick in self.timer.callback:self.timer.callback.remove(self._tick)
        except Exception as exc:optional_failure("player.optional_guard",exc)
