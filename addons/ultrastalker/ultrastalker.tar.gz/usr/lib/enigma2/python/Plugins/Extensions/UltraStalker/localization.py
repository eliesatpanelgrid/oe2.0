# -*- coding: utf-8 -*-
"""Ultra Stalker UI-only localization.

This module deliberately translates only strings explicitly passed through
``translate()`` / ``_()`` by Ultra Stalker's own UI. Provider data (Portal,
M3U, Xtream, category names, channel names, movie/series titles and metadata)
is never routed through this translator.
"""
import gettext
import json
import os
import threading

CONFIG_FILE = "/etc/enigma2/ultrastalker/settings.json"
LOCALE_DIR = os.path.join(os.path.dirname(__file__), "locale")
SUPPORTED_LANGUAGES = ("en", "ar", "fr", "tr")
LANGUAGE_NAMES = {
    "en": "English",
    "ar": "العربية",
    "fr": "Français",
    "tr": "Türkçe",
}

_LOCK = threading.RLock()
_LANG_OVERRIDE = None
_CACHE_SIGNATURE = None
_CACHE_LANGUAGE = "en"
_AR_GETTEXT = None

# Exact, reviewed UI translations. Keep placeholders and punctuation stable.
# Provider-originated strings must never be added here merely because they look
# like an English word; only plugin-owned chrome/status text belongs here.
_T = {
    "Plugin Language": {"ar":"لغة الإضافة","fr":"Langue du plugin","tr":"Eklenti Dili"},
    "Font Size": {"ar":"حجم الخط","fr":"Taille du texte","tr":"Yazı Boyutu"},
    "Normal": {"ar":"عادي","fr":"Normal","tr":"Normal"},
    "Large": {"ar":"كبير","fr":"Grand","tr":"Büyük"},
    "Larger": {"ar":"أكبر","fr":"Plus grand","tr":"Daha Büyük"},
    "Extra Large": {"ar":"كبير جدًا","fr":"Très grand","tr":"Çok Büyük"},
    "Choose the text size used across Ultra Stalker. Restart Enigma2 to apply it everywhere.": {"ar":"اختر حجم النص المستخدم في جميع واجهات Ultra Stalker. أعد تشغيل Enigma2 لتطبيقه في كل مكان.","fr":"Choisissez la taille du texte utilisée dans Ultra Stalker. Redémarrez Enigma2 pour l’appliquer partout.","tr":"Ultra Stalker genelinde kullanılan yazı boyutunu seçin. Her yerde uygulamak için Enigma2'yi yeniden başlatın."},
    "Font size saved. Restart Enigma2 to apply it everywhere.": {"ar":"تم حفظ حجم الخط. أعد تشغيل Enigma2 لتطبيقه في كل مكان.","fr":"Taille du texte enregistrée. Redémarrez Enigma2 pour l’appliquer partout.","tr":"Yazı boyutu kaydedildi. Her yerde uygulamak için Enigma2'yi yeniden başlatın."},
    "Show in Main Menu": {"ar":"إظهار في القائمة الرئيسية","fr":"Afficher dans le menu principal","tr":"Ana Menüde Göster"},
    "Show Ultra Stalker directly in the Enigma2 Main Menu.": {"ar":"أظهر Ultra Stalker مباشرة في القائمة الرئيسية لـ Enigma2.","fr":"Affiche Ultra Stalker directement dans le menu principal Enigma2.","tr":"Ultra Stalker'ı doğrudan Enigma2 Ana Menüsünde gösterir."},
    "Choose the language used by Ultra Stalker menus and controls. Portal, M3U and Xtream content is never translated.": {"ar":"اختر اللغة المستخدمة في قوائم وتحكم Ultra Stalker. محتوى Portal وM3U وXtream لا تتم ترجمته إطلاقًا.","fr":"Choisissez la langue des menus et commandes d’Ultra Stalker. Le contenu Portal, M3U et Xtream n’est jamais traduit.","tr":"Ultra Stalker menüleri ve kontrolleri için dili seçin. Portal, M3U ve Xtream içeriği hiçbir zaman çevrilmez."},
    "Language saved": {"ar":"تم حفظ اللغة","fr":"Langue enregistrée","tr":"Dil kaydedildi"},
    "Settings": {"ar":"الإعدادات","fr":"Paramètres","tr":"Ayarlar"},
    "Portal Settings": {"ar":"إعدادات البوابة","fr":"Paramètres du portail","tr":"Portal Ayarları"},
    "Advanced Settings": {"ar":"الإعدادات المتقدمة","fr":"Paramètres avancés","tr":"Gelişmiş Ayarlar"},
    "Expert controls": {"ar":"خيارات متقدمة","fr":"Contrôles avancés","tr":"Uzman kontrolleri"},
    "Performance, filtering and integration": {"ar":"الأداء والتصفية والتكامل","fr":"Performances, filtrage et intégration","tr":"Performans, filtreleme ve entegrasyon"},
    "Performance, filtering, bouquet/EPG and diagnostic controls.": {"ar":"إعدادات الأداء والتصفية والباقات/EPG والتشخيص.","fr":"Contrôles des performances, du filtrage, des bouquets/EPG et du diagnostic.","tr":"Performans, filtreleme, buket/EPG ve tanılama kontrolleri."},
    "Change only the options you understand. Defaults are safe for most receivers.": {"ar":"غيّر فقط الخيارات التي تعرف تأثيرها. الإعدادات الافتراضية مناسبة لمعظم أجهزة الاستقبال.","fr":"Modifiez uniquement les options que vous comprenez. Les valeurs par défaut conviennent à la plupart des récepteurs.","tr":"Yalnızca ne yaptığını bildiğiniz seçenekleri değiştirin. Varsayılanlar çoğu alıcı için güvenlidir."},
    "Changes are saved immediately": {"ar":"يتم حفظ التغييرات فورًا","fr":"Les modifications sont enregistrées immédiatement","tr":"Değişiklikler hemen kaydedilir"},
    "Choose an option to configure playback, lists and privacy.": {"ar":"اختر إعدادًا لضبط التشغيل والقوائم والخصوصية.","fr":"Choisissez une option pour configurer la lecture, les listes et la confidentialité.","tr":"Oynatma, listeler ve gizlilik için bir seçenek seçin."},
    "ARROWS Navigate  •  OK Select  •  BACK Home": {"ar":"الأسهم للتنقل  •  OK اختيار  •  BACK الرئيسية","fr":"FLÈCHES Naviguer  •  OK Sélectionner  •  BACK Accueil","tr":"OKLAR Gezin  •  OK Seç  •  BACK Ana Sayfa"},
    "Back": {"ar":"رجوع","fr":"Retour","tr":"Geri"},
    "Change": {"ar":"تغيير","fr":"Modifier","tr":"Değiştir"},
    "Select": {"ar":"اختيار","fr":"Sélectionner","tr":"Seç"},
    "Close": {"ar":"إغلاق","fr":"Fermer","tr":"Kapat"},
    "Yes": {"ar":"نعم","fr":"Oui","tr":"Evet"},
    "No": {"ar":"لا","fr":"Non","tr":"Hayır"},
    "Save": {"ar":"حفظ","fr":"Enregistrer","tr":"Kaydet"},
    "Cancel": {"ar":"إلغاء","fr":"Annuler","tr":"İptal"},
    "Done": {"ar":"تم","fr":"Terminé","tr":"Bitti"},
    "Open": {"ar":"فتح","fr":"Ouvrir","tr":"Aç"},
    "OPEN": {"ar":"فتح","fr":"OUVRIR","tr":"AÇ"},
    "START": {"ar":"بدء","fr":"DÉMARRER","tr":"BAŞLAT"},
    "EXPORT": {"ar":"تصدير","fr":"EXPORTER","tr":"DIŞA AKTAR"},
    "TEST": {"ar":"اختبار","fr":"TESTER","tr":"TEST"},
    "CHANGE": {"ar":"تغيير","fr":"MODIFIER","tr":"DEĞİŞTİR"},
    "ON": {"ar":"تشغيل","fr":"ACTIVÉ","tr":"AÇIK"},
    "OFF": {"ar":"إيقاف","fr":"DÉSACTIVÉ","tr":"KAPALI"},
    "EASY": {"ar":"سهل","fr":"FACILE","tr":"KOLAY"},
    "PIN / QR": {"ar":"PIN / QR","fr":"PIN / QR","tr":"PIN / QR"},
    "NOT SET": {"ar":"غير مضبوط","fr":"NON DÉFINI","tr":"AYARLANMADI"},
    "UNKNOWN": {"ar":"غير معروف","fr":"INCONNU","tr":"BİLİNMİYOR"},
    "LOCKED": {"ar":"مقفول","fr":"VERROUILLÉ","tr":"KİLİTLİ"},
    "RUNNING": {"ar":"يعمل","fr":"EN COURS","tr":"ÇALIŞIYOR"},
    "Ready": {"ar":"جاهز","fr":"Prêt","tr":"Hazır"},
    "Categories unavailable": {"ar":"الأقسام غير متاحة","fr":"Catégories indisponibles","tr":"Kategoriler kullanılamıyor"},
    "Categories could not be loaded": {"ar":"تعذر تحميل الأقسام","fr":"Impossible de charger les catégories","tr":"Kategoriler yüklenemedi"},
    "Content temporarily unavailable. Try again.": {"ar":"المحتوى غير متاح مؤقتًا. حاول مرة أخرى.","fr":"Contenu temporairement indisponible. Réessayez.","tr":"İçerik geçici olarak kullanılamıyor. Tekrar deneyin."},
    "Unknown error": {"ar":"خطأ غير معروف","fr":"Erreur inconnue","tr":"Bilinmeyen hata"},
    "Information": {"ar":"معلومات","fr":"Informations","tr":"Bilgi"},
    "Ultra Stalker Information": {"ar":"معلومات Ultra Stalker","fr":"Informations Ultra Stalker","tr":"Ultra Stalker Bilgileri"},
    "Diagnostics": {"ar":"التشخيص","fr":"Diagnostics","tr":"Tanılama"},
    "Support Bundle": {"ar":"حزمة الدعم","fr":"Paquet de support","tr":"Destek Paketi"},
    "About": {"ar":"حول الإضافة","fr":"À propos","tr":"Hakkında"},
    "Version, build identity and runtime information.": {"ar":"معلومات الإصدار والبنية وبيئة التشغيل.","fr":"Informations sur la version, la build et l’environnement d’exécution.","tr":"Sürüm, yapı kimliği ve çalışma zamanı bilgileri."},
    "Visual Theme": {"ar":"المظهر اللوني","fr":"Thème visuel","tr":"Görsel Tema"},
    "Choose visual theme": {"ar":"اختر المظهر اللوني","fr":"Choisir le thème visuel","tr":"Görsel temayı seçin"},
    "Select the visual style": {"ar":"اختر النمط المرئي","fr":"Sélectionnez le style visuel","tr":"Görsel stili seçin"},
    "Nova FHD": {"ar":"نوفا FHD","fr":"Nova FHD","tr":"Nova FHD"},
    "OLED Black": {"ar":"OLED أسود","fr":"OLED Noir","tr":"OLED Siyah"},
    "Midnight Purple": {"ar":"بنفسجي منتصف الليل","fr":"Violet Minuit","tr":"Gece Moru"},
    "Choose Nova FHD, OLED Black, or Midnight Purple. Restart is required.": {"ar":"اختر Nova FHD أو OLED Black أو Midnight Purple. يلزم إعادة التشغيل.","fr":"Choisissez Nova FHD, OLED Black ou Midnight Purple. Un redémarrage est nécessaire.","tr":"Nova FHD, OLED Black veya Midnight Purple seçin. Yeniden başlatma gerekir."},
    "Theme saved. Restart Enigma2 to apply: %s": {"ar":"تم حفظ المظهر. أعد تشغيل Enigma2 لتطبيقه: %s","fr":"Thème enregistré. Redémarrez Enigma2 pour l’appliquer : %s","tr":"Tema kaydedildi. Uygulamak için Enigma2’yi yeniden başlatın: %s"},
    "Theme save failed: %s": {"ar":"فشل حفظ المظهر: %s","fr":"Échec de l’enregistrement du thème : %s","tr":"Tema kaydedilemedi: %s"},

    "Playback Engine": {"ar":"محرك التشغيل","fr":"Moteur de lecture","tr":"Oynatma Motoru"},
    "Choose the Enigma2 playback service used for streams.": {"ar":"اختر خدمة تشغيل Enigma2 المستخدمة للبث.","fr":"Choisissez le service de lecture Enigma2 utilisé pour les flux.","tr":"Yayınlar için kullanılacak Enigma2 oynatma hizmetini seçin."},
    "Player Engine Lock": {"ar":"تثبيت محرك التشغيل","fr":"Verrouillage du moteur de lecture","tr":"Oynatma Motoru Kilidi"},
    "Every Live, movie, series, episode and catch-up stream uses the Playback Engine selected in Settings.": {"ar":"كل بث مباشر أو فيلم أو مسلسل أو حلقة أو Catch-up يستخدم محرك التشغيل المحدد في الإعدادات.","fr":"Tous les flux Live, films, séries, épisodes et Catch-up utilisent le moteur de lecture choisi dans les paramètres.","tr":"Canlı yayın, film, dizi, bölüm ve Catch-up akışlarının tümü Ayarlar’da seçilen Oynatma Motorunu kullanır."},
    "Automatic Engine Switching": {"ar":"التبديل التلقائي للمحرك","fr":"Changement automatique du moteur","tr":"Otomatik Motor Değiştirme"},
    "Smart Engine and per-title engine overrides are disabled to keep playback on the selected engine.": {"ar":"تم تعطيل المحرك الذكي وتجاوزات المحرك لكل عنوان للحفاظ على التشغيل بالمحرك المحدد.","fr":"Le moteur intelligent et les changements de moteur par titre sont désactivés afin de conserver le moteur sélectionné.","tr":"Oynatmayı seçilen motorda tutmak için Akıllı Motor ve başlık bazlı motor geçersiz kılmaları devre dışıdır."},
    "Resume Behavior": {"ar":"سلوك استكمال المشاهدة","fr":"Comportement de reprise","tr":"Devam Etme Davranışı"},
    "Ask, always resume, or always start from the beginning.": {"ar":"اسأل، أو استكمل دائمًا، أو ابدأ دائمًا من البداية.","fr":"Demander, toujours reprendre ou toujours recommencer depuis le début.","tr":"Sor, her zaman devam et veya her zaman baştan başla."},
    "Crash-Safe Progress": {"ar":"حفظ التقدم الآمن","fr":"Progression protégée contre les crashs","tr":"Çökme Güvenli İlerleme"},
    "Save VOD/episode progress frequently and on pause/engine changes.": {"ar":"احفظ تقدم الأفلام/الحلقات بشكل متكرر وعند الإيقاف المؤقت أو تغيير المحرك.","fr":"Enregistre fréquemment la progression VOD/épisode, ainsi qu’en pause ou lors d’un changement de moteur.","tr":"VOD/bölüm ilerlemesini sık sık ve duraklatma/motor değişikliklerinde kaydeder."},
    "Progress Save Interval": {"ar":"فاصل حفظ التقدم","fr":"Intervalle d’enregistrement de la progression","tr":"İlerleme Kayıt Aralığı"},
    "Crash-safe bookmark interval for movies and episodes.": {"ar":"فاصل حفظ موضع المشاهدة الآمن للأفلام والحلقات.","fr":"Intervalle de sauvegarde sécurisé de la position pour les films et épisodes.","tr":"Film ve bölümler için çökme güvenli yer imi aralığı."},
    "Next Episode Countdown": {"ar":"العد التنازلي للحلقة التالية","fr":"Compte à rebours du prochain épisode","tr":"Sonraki Bölüm Geri Sayımı"},
    "Choose the cancelable autoplay countdown after an episode ends.": {"ar":"اختر مدة العد التنازلي القابل للإلغاء للتشغيل التلقائي بعد انتهاء الحلقة.","fr":"Choisissez le compte à rebours annulable avant la lecture automatique après la fin d’un épisode.","tr":"Bölüm bittikten sonra iptal edilebilir otomatik oynatma geri sayımını seçin."},
    "Auto Remove Completed": {"ar":"حذف المكتمل تلقائيًا","fr":"Retirer automatiquement les éléments terminés","tr":"Tamamlananları Otomatik Kaldır"},
    "Automatically remove titles from Continue Watching after the completion threshold.": {"ar":"احذف العناوين تلقائيًا من متابعة المشاهدة بعد بلوغ نسبة الاكتمال.","fr":"Retire automatiquement les titres de Continuer à regarder une fois le seuil de fin atteint.","tr":"Tamamlama eşiğine ulaşıldığında başlıkları İzlemeye Devam’dan otomatik kaldırır."},
    "Completion Threshold": {"ar":"نسبة اكتمال المشاهدة","fr":"Seuil de fin","tr":"Tamamlama Eşiği"},
    "Percentage at which a title is considered completed and removed from Continue Watching.": {"ar":"النسبة التي عندها يعتبر العنوان مكتملًا ويُحذف من متابعة المشاهدة.","fr":"Pourcentage à partir duquel un titre est considéré comme terminé et retiré de Continuer à regarder.","tr":"Bir başlığın tamamlanmış sayılıp İzlemeye Devam’dan kaldırılacağı yüzde."},
    "Completion Remaining Time": {"ar":"الوقت المتبقي للاكتمال","fr":"Temps restant avant fin","tr":"Tamamlanma İçin Kalan Süre"},
    "Also mark a title completed when this little time remains.": {"ar":"اعتبر العنوان مكتملًا أيضًا عندما يتبقى هذا القدر القليل من الوقت.","fr":"Considère également le titre comme terminé lorsqu’il reste aussi peu de temps.","tr":"Bu kadar az süre kaldığında başlığı tamamlanmış olarak da işaretler."},

    "Portal Timeout": {"ar":"مهلة اتصال البوابة","fr":"Délai du portail","tr":"Portal Zaman Aşımı"},
    "Network timeout for portal API calls.": {"ar":"مهلة الشبكة لاتصالات API الخاصة بالبوابة.","fr":"Délai réseau des appels API du portail.","tr":"Portal API çağrıları için ağ zaman aşımı."},
    "EPG Window": {"ar":"نطاق EPG","fr":"Fenêtre EPG","tr":"EPG Aralığı"},
    "How much EPG data to request for live channels.": {"ar":"كمية بيانات EPG المطلوب جلبها للقنوات المباشرة.","fr":"Quantité de données EPG à demander pour les chaînes en direct.","tr":"Canlı kanallar için istenecek EPG verisi miktarı."},
    "Catch-up History": {"ar":"سجل المشاهدة المؤجلة","fr":"Historique Catch-up","tr":"Catch-up Geçmişi"},
    "How far back archive EPG should be collected.": {"ar":"الفترة السابقة التي يتم جمع بيانات EPG المؤرشفة لها.","fr":"Jusqu’où remonter pour collecter l’EPG d’archive.","tr":"Arşiv EPG verisinin ne kadar geriye dönük toplanacağını belirler."},
    "Poster Loading": {"ar":"تحميل الصور","fr":"Chargement des affiches","tr":"Poster Yükleme"},
    "Enable or disable remote poster and logo artwork.": {"ar":"فعّل أو عطّل تحميل البوسترات والشعارات من الشبكة.","fr":"Active ou désactive le chargement distant des affiches et logos.","tr":"Uzak poster ve logo görsellerini açar veya kapatır."},
    "Movies View": {"ar":"عرض الأفلام","fr":"Vue Films","tr":"Film Görünümü"},
    "Series View": {"ar":"عرض المسلسلات","fr":"Vue Séries","tr":"Dizi Görünümü"},
    "CINEMATIC": {"ar":"سينمائي","fr":"CINÉMATIQUE","tr":"SİNEMATİK"},
    "POSTER GRID": {"ar":"شبكة البوسترات","fr":"GRILLE D’AFFICHES","tr":"POSTER IZGARASI"},
    "Choose Poster Grid or the Global-Library Cinematic presentation for Movies.": {"ar":"اختر شبكة البوسترات أو العرض السينمائي للمكتبة العامة للأفلام.","fr":"Choisissez la grille d’affiches ou la présentation Cinématique de la bibliothèque globale pour les films.","tr":"Filmler için Poster Izgarası veya Global Kütüphane Sinematik görünümünü seçin."},
    "Choose Poster Grid or the Global-Library Cinematic presentation for Series.": {"ar":"اختر شبكة البوسترات أو العرض السينمائي للمكتبة العامة للمسلسلات.","fr":"Choisissez la grille d’affiches ou la présentation Cinématique de la bibliothèque globale pour les séries.","tr":"Diziler için Poster Izgarası veya Global Kütüphane Sinematik görünümünü seçin."},
    "Image Cache": {"ar":"ذاكرة الصور","fr":"Cache des images","tr":"Görsel Önbelleği"},
    "Clear downloaded artwork from persistent/temporary storage.": {"ar":"امسح الصور المحمّلة من التخزين الدائم/المؤقت.","fr":"Efface les illustrations téléchargées du stockage permanent/temporaire.","tr":"İndirilen görselleri kalıcı/geçici depolamadan temizler."},
    "Download Disk Reserve": {"ar":"مساحة احتياطية للتنزيل","fr":"Réserve disque pour les téléchargements","tr":"İndirme Disk Rezervi"},
    "Keep this much disk space free while downloads are running.": {"ar":"احتفظ بهذه المساحة فارغة أثناء عمليات التنزيل.","fr":"Conserve cet espace disque libre pendant les téléchargements.","tr":"İndirmeler çalışırken bu kadar disk alanını boş tutar."},
    "Artwork Prefetch": {"ar":"تحميل الصور مسبقًا","fr":"Préchargement des illustrations","tr":"Görsel Ön Yükleme"},
    "Prefetch selected movie/series details and backdrop while browsing.": {"ar":"حمّل مسبقًا تفاصيل وخلفية الفيلم/المسلسل المحدد أثناء التصفح.","fr":"Précharge les détails et l’arrière-plan du film/de la série sélectionné pendant la navigation.","tr":"Gezinirken seçili film/dizi ayrıntılarını ve arka planını önceden yükler."},
    "Preload Current Artwork": {"ar":"تحميل صور المصدر الحالي مسبقًا","fr":"Précharger les illustrations actuelles","tr":"Mevcut Görselleri Önceden Yükle"},
    "Prepare Movies/Series artwork for the current Portal/Xtream source; shared HDD-ready items are skipped.": {"ar":"جهّز صور الأفلام/المسلسلات للمصدر الحالي Portal/Xtream؛ العناصر الجاهزة على الهارد يتم تجاوزها.","fr":"Prépare les illustrations Films/Séries pour la source Portal/Xtream actuelle ; les éléments déjà prêts sur le disque sont ignorés.","tr":"Mevcut Portal/Xtream kaynağı için Film/Dizi görsellerini hazırlar; diskte hazır olan ortak öğeler atlanır."},
    "Watched Badges": {"ar":"علامات تمت المشاهدة","fr":"Badges Vu","tr":"İzlendi Rozetleri"},
    "Show WATCHED state on movie and series cards.": {"ar":"أظهر حالة تمت المشاهدة على بطاقات الأفلام والمسلسلات.","fr":"Affiche l’état VU sur les cartes de films et séries.","tr":"Film ve dizi kartlarında İZLENDİ durumunu gösterir."},
    "Live Preview": {"ar":"المعاينة المباشرة","fr":"Aperçu en direct","tr":"Canlı Önizleme"},
    "Enable portal live-preview behavior where supported.": {"ar":"فعّل المعاينة المباشرة للبوابة حيث تكون مدعومة.","fr":"Active l’aperçu en direct du portail lorsqu’il est pris en charge.","tr":"Desteklenen yerlerde portal canlı önizlemesini etkinleştirir."},

    "Parental Lock": {"ar":"الرقابة الأبوية","fr":"Verrouillage parental","tr":"Ebeveyn Kilidi"},
    "Protect configured/adult content categories.": {"ar":"احمِ أقسام المحتوى المحددة/للبالغين.","fr":"Protège les catégories configurées/de contenu adulte.","tr":"Yapılandırılmış/yetişkin içerik kategorilerini korur."},
    "Parental Mode": {"ar":"وضع الرقابة الأبوية","fr":"Mode parental","tr":"Ebeveyn Modu"},
    "PIN-protect sensitive categories or hide them completely.": {"ar":"احمِ الأقسام الحساسة برقم PIN أو أخفها بالكامل.","fr":"Protège les catégories sensibles par PIN ou masque-les complètement.","tr":"Hassas kategorileri PIN ile korur veya tamamen gizler."},
    "Parental Unlock": {"ar":"مدة فتح الرقابة","fr":"Déverrouillage parental","tr":"Ebeveyn Kilidi Açma"},
    "Keep a correct PIN unlocked for this session duration.": {"ar":"احتفظ بفتح PIN الصحيح طوال مدة الجلسة المحددة.","fr":"Conserve le PIN validé pendant cette durée de session.","tr":"Doğru PIN’i bu oturum süresi boyunca açık tutar."},
    "Parental PIN": {"ar":"الرقم السري للرقابة","fr":"PIN parental","tr":"Ebeveyn PIN’i"},
    "Set a 4–8 digit parental-control PIN.": {"ar":"عيّن رقم PIN للرقابة الأبوية من 4 إلى 8 أرقام.","fr":"Définissez un PIN de contrôle parental de 4 à 8 chiffres.","tr":"4–8 haneli ebeveyn kontrol PIN’i ayarlayın."},
    "Adult Keywords": {"ar":"كلمات محتوى البالغين","fr":"Mots-clés adulte","tr":"Yetişkin Anahtar Kelimeleri"},
    "Comma-separated words used to detect sensitive categories.": {"ar":"كلمات مفصولة بفواصل تُستخدم لاكتشاف الأقسام الحساسة.","fr":"Mots séparés par des virgules utilisés pour détecter les catégories sensibles.","tr":"Hassas kategorileri algılamak için kullanılan virgülle ayrılmış kelimeler."},
    "Lock Parental Session": {"ar":"قفل جلسة الرقابة","fr":"Verrouiller la session parentale","tr":"Ebeveyn Oturumunu Kilitle"},
    "Immediately clear the temporary parental unlock.": {"ar":"ألغِ فورًا فتح الرقابة المؤقت.","fr":"Annule immédiatement le déverrouillage parental temporaire.","tr":"Geçici ebeveyn kilidi açma durumunu hemen temizler."},
    "UNLOCKED %d min": {"ar":"مفتوح %d دقيقة","fr":"DÉVERROUILLÉ %d min","tr":"KİLİT AÇIK %d dk"},

    "Clean Titles": {"ar":"تنظيف العناوين","fr":"Nettoyer les titres","tr":"Başlıkları Temizle"},
    "Remove common technical prefixes from portal titles.": {"ar":"احذف البادئات التقنية الشائعة من عناوين البوابة.","fr":"Supprime les préfixes techniques courants des titres du portail.","tr":"Portal başlıklarındaki yaygın teknik önekleri kaldırır."},
    "Quality Badges": {"ar":"شارات الجودة","fr":"Badges de qualité","tr":"Kalite Rozetleri"},
    "Show 4K/HD and similar quality metadata when detected.": {"ar":"أظهر 4K/HD ومعلومات الجودة المشابهة عند اكتشافها.","fr":"Affiche les indications 4K/HD et autres informations de qualité lorsqu’elles sont détectées.","tr":"Algılandığında 4K/HD ve benzeri kalite bilgilerini gösterir."},
    "Channel List": {"ar":"قائمة القنوات","fr":"Liste des chaînes","tr":"Kanal Listesi"},
    "Choose EPG, compact or large live-channel list density.": {"ar":"اختر نمط قائمة القنوات المباشرة: EPG أو مضغوط أو كبير.","fr":"Choisissez la densité de la liste des chaînes en direct : EPG, compacte ou grande.","tr":"Canlı kanal listesi yoğunluğunu EPG, kompakt veya büyük olarak seçin."},
    "Show Channel Numbers": {"ar":"إظهار أرقام القنوات","fr":"Afficher les numéros de chaîne","tr":"Kanal Numaralarını Göster"},
    "Display channel numbers in Live TV lists.": {"ar":"أظهر أرقام القنوات في قوائم البث المباشر.","fr":"Affiche les numéros des chaînes dans les listes TV en direct.","tr":"Canlı TV listelerinde kanal numaralarını gösterir."},

    "Smart Recovery": {"ar":"الاستعادة الذكية","fr":"Récupération intelligente","tr":"Akıllı Kurtarma"},
    "Refresh an expired stream link after all playback engines fail.": {"ar":"حدّث رابط البث المنتهي بعد فشل جميع محركات التشغيل.","fr":"Actualise un lien de flux expiré après l’échec de tous les moteurs de lecture.","tr":"Tüm oynatma motorları başarısız olduktan sonra süresi dolmuş akış bağlantısını yeniler."},
    "Recovery Retries": {"ar":"محاولات الاستعادة","fr":"Tentatives de récupération","tr":"Kurtarma Denemeleri"},
    "Maximum stream-link refresh cycles after engine fallback.": {"ar":"أقصى عدد لمحاولات تحديث رابط البث بعد فشل المحركات.","fr":"Nombre maximal de cycles d’actualisation du lien après le repli des moteurs.","tr":"Motor geri dönüşünden sonra en fazla akış bağlantısı yenileme döngüsü."},
    "Multi-Portal Search": {"ar":"البحث في عدة بوابات","fr":"Recherche multi-portails","tr":"Çoklu Portal Araması"},
    "Global Search checks every enabled portal, not only the current one.": {"ar":"البحث العام يفحص كل البوابات المفعّلة وليس البوابة الحالية فقط.","fr":"La recherche globale interroge tous les portails activés, pas seulement le portail actuel.","tr":"Global Arama yalnızca mevcut portalı değil, etkin tüm portalları tarar."},
    "Search Limit / Portal": {"ar":"حد النتائج لكل بوابة","fr":"Limite de recherche / portail","tr":"Arama Limiti / Portal"},
    "Maximum Global Search results returned from each portal.": {"ar":"أقصى عدد نتائج البحث العام من كل بوابة.","fr":"Nombre maximal de résultats de recherche globale renvoyés par chaque portail.","tr":"Her portaldan döndürülecek en fazla Global Arama sonucu."},

    "TMDB Metadata": {"ar":"بيانات TMDB","fr":"Métadonnées TMDB","tr":"TMDB Meta Verisi"},
    "Use TMDB to enrich movie/series metadata and artwork.": {"ar":"استخدم TMDB لإثراء بيانات وصور الأفلام والمسلسلات.","fr":"Utilise TMDB pour enrichir les métadonnées et illustrations des films/séries.","tr":"Film/dizi meta verilerini ve görsellerini zenginleştirmek için TMDB kullanır."},
    "TMDB API Key / Token": {"ar":"مفتاح / رمز TMDB","fr":"Clé / jeton API TMDB","tr":"TMDB API Anahtarı / Token"},
    "Stored privately in api_keys.conf; never copied into settings.json.": {"ar":"يُحفظ بشكل خاص في api_keys.conf ولا يُنسخ إلى settings.json.","fr":"Stocké de façon privée dans api_keys.conf ; jamais copié dans settings.json.","tr":"api_keys.conf içinde özel olarak saklanır; settings.json dosyasına asla kopyalanmaz."},
    "TMDB Language": {"ar":"لغة TMDB","fr":"Langue TMDB","tr":"TMDB Dili"},
    "Preferred TMDB metadata language. English is used as fallback for missing overview text.": {"ar":"لغة بيانات TMDB المفضلة. تُستخدم الإنجليزية كبديل عند غياب الملخص.","fr":"Langue préférée des métadonnées TMDB. L’anglais sert de secours si le résumé est absent.","tr":"Tercih edilen TMDB meta veri dili. Özet eksikse İngilizce yedek olarak kullanılır."},
    "TMDB Connection Test": {"ar":"اختبار اتصال TMDB","fr":"Test de connexion TMDB","tr":"TMDB Bağlantı Testi"},
    "Validate the saved TMDB credential against the official API.": {"ar":"تحقق من بيانات اعتماد TMDB المحفوظة باستخدام الـAPI الرسمي.","fr":"Vérifie les identifiants TMDB enregistrés auprès de l’API officielle.","tr":"Kaydedilen TMDB kimlik bilgisini resmi API ile doğrular."},
    "Online Arabic Subtitles": {"ar":"ترجمة عربية أونلاين","fr":"Sous-titres arabes en ligne","tr":"Çevrimiçi Arapça Altyazılar"},
    "SubDL API key for online Arabic movie and episode subtitles.": {"ar":"مفتاح SubDL API للترجمة العربية الأونلاين للأفلام والحلقات.","fr":"Clé API SubDL pour les sous-titres arabes en ligne des films et épisodes.","tr":"Film ve bölümler için çevrimiçi Arapça altyazılarda kullanılan SubDL API anahtarı."},

    "Backup & Restore": {"ar":"النسخ الاحتياطي والاستعادة","fr":"Sauvegarde et restauration","tr":"Yedekleme ve Geri Yükleme"},
    "Backup or restore portals, settings, favorites, history and resume state.": {"ar":"انسخ أو استعد البوابات والإعدادات والمفضلة والسجل وحالة استكمال المشاهدة.","fr":"Sauvegarde ou restaure les portails, paramètres, favoris, historique et état de reprise.","tr":"Portalları, ayarları, favorileri, geçmişi ve devam durumunu yedekler veya geri yükler."},
    "Create a redacted diagnostics ZIP for troubleshooting.": {"ar":"أنشئ ملف ZIP تشخيصيًا منقحًا لاستكشاف الأعطال.","fr":"Crée une archive ZIP de diagnostic expurgée pour le dépannage.","tr":"Sorun giderme için hassas verileri ayıklanmış tanılama ZIP’i oluşturur."},
    "Web Cleaner Access": {"ar":"وصول Web Cleaner","fr":"Accès Web Cleaner","tr":"Web Cleaner Erişimi"},
    "Easy opens directly on the local network; Protected requires pairing.": {"ar":"الوضع السهل يفتح مباشرة على الشبكة المحلية؛ الوضع المحمي يتطلب الاقتران.","fr":"Le mode Facile s’ouvre directement sur le réseau local ; le mode Protégé nécessite un appairage.","tr":"Kolay mod yerel ağda doğrudan açılır; Korumalı mod eşleştirme gerektirir."},
    "Web Cleaner": {"ar":"Web Cleaner","fr":"Web Cleaner","tr":"Web Cleaner"},
    "Start/stop the Premium Web Cleaner and Deep Check service on port 7725.": {"ar":"ابدأ/أوقف خدمة Premium Web Cleaner وDeep Check على المنفذ 7725.","fr":"Démarre/arrête le service Premium Web Cleaner et Deep Check sur le port 7725.","tr":"7725 portundaki Premium Web Cleaner ve Deep Check hizmetini başlatır/durdurur."},
    "View package, database, cache and portal diagnostic information.": {"ar":"اعرض معلومات تشخيص الحزمة وقاعدة البيانات والكاش والبوابة.","fr":"Affiche les informations de diagnostic du paquet, de la base de données, du cache et du portail.","tr":"Paket, veritabanı, önbellek ve portal tanılama bilgilerini görüntüler."},

    "Diagnostic Logging": {"ar":"سجل التشخيص","fr":"Journal de diagnostic","tr":"Tanılama Günlüğü"},
    "Enable verbose rotating diagnostic logs after plugin restart.": {"ar":"فعّل سجلات تشخيص تفصيلية ومتداولة بعد إعادة تشغيل البلجن.","fr":"Active des journaux de diagnostic détaillés avec rotation après redémarrage du plugin.","tr":"Eklenti yeniden başlatıldıktan sonra ayrıntılı dönen tanılama günlüklerini etkinleştirir."},
    "Hide Adult Categories": {"ar":"إخفاء أقسام البالغين","fr":"Masquer les catégories adultes","tr":"Yetişkin Kategorilerini Gizle"},
    "Hide categories matching adult keywords when Parental Lock is disabled.": {"ar":"أخفِ الأقسام المطابقة لكلمات البالغين عند تعطيل الرقابة الأبوية.","fr":"Masque les catégories correspondant aux mots-clés adulte lorsque le verrouillage parental est désactivé.","tr":"Ebeveyn Kilidi kapalıyken yetişkin anahtar kelimeleriyle eşleşen kategorileri gizler."},
    "Hide Empty Categories": {"ar":"إخفاء الأقسام الفارغة","fr":"Masquer les catégories vides","tr":"Boş Kategorileri Gizle"},
    "Hide categories detected as empty after loading.": {"ar":"أخفِ الأقسام التي يتبين أنها فارغة بعد التحميل.","fr":"Masque les catégories détectées comme vides après chargement.","tr":"Yüklendikten sonra boş olduğu belirlenen kategorileri gizler."},
    "Remember Last Location": {"ar":"تذكر آخر موضع","fr":"Mémoriser le dernier emplacement","tr":"Son Konumu Hatırla"},
    "Restore the last Home/content location for each portal.": {"ar":"استعد آخر موضع في الرئيسية/المحتوى لكل بوابة.","fr":"Restaure le dernier emplacement Accueil/contenu pour chaque portail.","tr":"Her portal için son Ana Sayfa/içerik konumunu geri yükler."},
    "Image Cache Limit": {"ar":"حد ذاكرة الصور","fr":"Limite du cache d’images","tr":"Görsel Önbellek Limiti"},
    "Maximum persistent artwork cache size.": {"ar":"أقصى حجم دائم لذاكرة الصور.","fr":"Taille maximale du cache permanent des illustrations.","tr":"Kalıcı görsel önbelleğinin azami boyutu."},
    "Bouquet Proxy Port": {"ar":"منفذ بروكسي الباقات","fr":"Port proxy des bouquets","tr":"Buket Proxy Portu"},
    "Local loopback port used by dynamic bouquet playback and XMLTV integration.": {"ar":"منفذ محلي يستخدم لتشغيل الباقات الديناميكية وتكامل XMLTV.","fr":"Port de boucle locale utilisé pour la lecture des bouquets dynamiques et l’intégration XMLTV.","tr":"Dinamik buket oynatma ve XMLTV entegrasyonunda kullanılan yerel loopback portu."},
    "EPG Refresh Budget": {"ar":"مهلة تحديث EPG","fr":"Budget d’actualisation EPG","tr":"EPG Yenileme Bütçesi"},
    "Maximum background XMLTV refresh time budget.": {"ar":"أقصى مدة مسموحة لتحديث XMLTV في الخلفية.","fr":"Durée maximale allouée à l’actualisation XMLTV en arrière-plan.","tr":"Arka plandaki XMLTV yenilemesi için azami süre bütçesi."},
    "Search Scan Pages": {"ar":"صفحات البحث القصوى","fr":"Pages analysées pour la recherche","tr":"Arama Tarama Sayfaları"},
    "Maximum catalogue pages scanned when native portal search is unavailable.": {"ar":"أقصى عدد صفحات يتم فحصها عند عدم توفر بحث البوابة الأصلي.","fr":"Nombre maximal de pages de catalogue analysées lorsque la recherche native du portail n’est pas disponible.","tr":"Portalın yerel araması yoksa taranacak en fazla katalog sayfası."},
    "Search Time Budget": {"ar":"مهلة البحث","fr":"Budget temps de recherche","tr":"Arama Süre Bütçesi"},
    "Maximum time spent searching one portal before partial results are returned.": {"ar":"أقصى مدة للبحث في بوابة واحدة قبل إرجاع نتائج جزئية.","fr":"Temps maximal passé à rechercher dans un portail avant de renvoyer des résultats partiels.","tr":"Kısmi sonuçlar dönmeden önce tek bir portalda harcanacak en fazla arama süresi."},

    "Portal server": {"ar":"خادم البوابة","fr":"Serveur du portail","tr":"Portal Sunucusu"},
    "SELECT PORTAL": {"ar":"اختر البوابة","fr":"SÉLECTIONNER UN PORTAIL","tr":"PORTAL SEÇ"},
    "Disable": {"ar":"تعطيل","fr":"Désactiver","tr":"Devre Dışı Bırak"},
    "Rename": {"ar":"إعادة تسمية","fr":"Renommer","tr":"Yeniden Adlandır"},
    "Check All": {"ar":"فحص الكل","fr":"Tout vérifier","tr":"Tümünü Kontrol Et"},
    "Edit Order": {"ar":"ترتيب البوابات","fr":"Modifier l’ordre","tr":"Sıralamayı Düzenle"},
    "Checking portal...": {"ar":"جارٍ فحص البوابة...","fr":"Vérification du portail...","tr":"Portal kontrol ediliyor..."},
    "Edit order  •  UP/DOWN moves the selected portal  •  BLUE/OK saves": {"ar":"تعديل الترتيب  •  أعلى/أسفل لتحريك البوابة المحددة  •  الأزرق/OK للحفظ","fr":"Modifier l’ordre  •  HAUT/BAS déplace le portail sélectionné  •  BLEU/OK enregistre","tr":"Sıralamayı düzenle  •  YUKARI/AŞAĞI seçili portalı taşır  •  MAVİ/OK kaydeder"},
    "Moved to position %d of %d  •  BLUE/OK when done": {"ar":"تم النقل إلى الموضع %d من %d  •  اضغط الأزرق/OK عند الانتهاء","fr":"Déplacé à la position %d sur %d  •  BLEU/OK lorsque terminé","tr":"%d / %d konumuna taşındı  •  Bitince MAVİ/OK"},
    "Portal order saved": {"ar":"تم حفظ ترتيب البوابات","fr":"Ordre des portails enregistré","tr":"Portal sıralaması kaydedildi"},
    "Already at the top": {"ar":"موجود بالفعل في الأعلى","fr":"Déjà tout en haut","tr":"Zaten en üstte"},
    "Already at the bottom": {"ar":"موجود بالفعل في الأسفل","fr":"Déjà tout en bas","tr":"Zaten en altta"},
    "Order save failed: %s": {"ar":"فشل حفظ الترتيب: %s","fr":"Échec de l’enregistrement de l’ordre : %s","tr":"Sıralama kaydedilemedi: %s"},
    "Open portal": {"ar":"فتح البوابة","fr":"Ouvrir le portail","tr":"Portalı Aç"},
    "Portal name": {"ar":"اسم البوابة","fr":"Nom du portail","tr":"Portal Adı"},
    "Portal URL (HTTPS preferred)": {"ar":"رابط البوابة (يفضل HTTPS)","fr":"URL du portail (HTTPS recommandé)","tr":"Portal URL’si (HTTPS önerilir)"},
    "MAC address": {"ar":"عنوان MAC","fr":"Adresse MAC","tr":"MAC adresi"},
    "Enter URL": {"ar":"إدخال الرابط","fr":"Saisir l’URL","tr":"URL Gir"},
    "Enter MAC": {"ar":"إدخال MAC","fr":"Saisir le MAC","tr":"MAC Gir"},
    "Portal connection failed: %s": {"ar":"فشل الاتصال بالبوابة: %s","fr":"Échec de connexion au portail : %s","tr":"Portal bağlantısı başarısız: %s"},

    "First-run wizard will start on the next plugin launch.": {"ar":"سيبدأ معالج الإعداد الأول عند تشغيل البلجن مرة أخرى.","fr":"L’assistant de premier démarrage s’ouvrira au prochain lancement du plugin.","tr":"İlk kurulum sihirbazı eklentinin bir sonraki açılışında başlayacak."},
    "Reset wizard": {"ar":"إعادة معالج الإعداد","fr":"Réinitialiser l’assistant","tr":"Sihirbazı Sıfırla"},
    "WELCOME": {"ar":"مرحبًا","fr":"BIENVENUE","tr":"HOŞ GELDİNİZ"},
    "Start setup": {"ar":"بدء الإعداد","fr":"Démarrer la configuration","tr":"Kurulumu Başlat"},
    "Skip wizard": {"ar":"تخطي المعالج","fr":"Ignorer l’assistant","tr":"Sihirbazı Atla"},
    "Retry setup": {"ar":"إعادة المحاولة","fr":"Réessayer la configuration","tr":"Kurulumu Yeniden Dene"},
    "Setup complete. Opening your portal…": {"ar":"اكتمل الإعداد. جارٍ فتح البوابة…","fr":"Configuration terminée. Ouverture du portail…","tr":"Kurulum tamamlandı. Portal açılıyor…"},
    "Testing…": {"ar":"جارٍ الاختبار…","fr":"Test en cours…","tr":"Test ediliyor…"},

    "%d files / %.1f MB": {"ar":"%d ملف / %.1f م.ب","fr":"%d fichiers / %.1f Mo","tr":"%d dosya / %.1f MB"},
    "%d MB": {"ar":"%d م.ب","fr":"%d Mo","tr":"%d MB"},
    "%d min": {"ar":"%d دقيقة","fr":"%d min","tr":"%d dk"},
    "%d options": {"ar":"%d خيار","fr":"%d options","tr":"%d seçenek"},
    "%d seconds": {"ar":"%d ثانية","fr":"%d secondes","tr":"%d saniye"},
    "%d words": {"ar":"%d كلمة","fr":"%d mots","tr":"%d kelime"},
    "%sh": {"ar":"%s س","fr":"%s h","tr":"%s sa"},
    "%ss": {"ar":"%s ث","fr":"%s s","tr":"%s sn"},
    "%s%%": {"ar":"%s%%","fr":"%s%%","tr":"%s%%"},
    "Current: %s": {"ar":"الحالي: %s","fr":"Actuel : %s","tr":"Mevcut: %s"},
    "Setting saved": {"ar":"تم حفظ الإعداد","fr":"Paramètre enregistré","tr":"Ayar kaydedildi"},
    "Setting updated": {"ar":"تم تحديث الإعداد","fr":"Paramètre mis à jour","tr":"Ayar güncellendi"},
    "Proxy port saved. Restart the plugin before exporting bouquets again.": {"ar":"تم حفظ منفذ البروكسي. أعد تشغيل البلجن قبل تصدير الباقات مرة أخرى.","fr":"Port proxy enregistré. Redémarrez le plugin avant d’exporter à nouveau les bouquets.","tr":"Proxy portu kaydedildi. Buketleri yeniden dışa aktarmadan önce eklentiyi yeniden başlatın."},
    "Unable to reset wizard: %s": {"ar":"تعذر إعادة معالج الإعداد: %s","fr":"Impossible de réinitialiser l’assistant : %s","tr":"Sihirbaz sıfırlanamadı: %s"},

    # Main Home / Browser chrome
    "Live TV": {"ar":"البث المباشر","fr":"TV en direct","tr":"Canlı TV"},
    "Watch live channels": {"ar":"شاهد القنوات المباشرة","fr":"Regarder les chaînes en direct","tr":"Canlı kanalları izle"},
    "Movies": {"ar":"الأفلام","fr":"Films","tr":"Filmler"},
    "Browse movie library": {"ar":"تصفح مكتبة الأفلام","fr":"Parcourir la bibliothèque de films","tr":"Film kütüphanesine göz at"},
    "Series": {"ar":"المسلسلات","fr":"Séries","tr":"Diziler"},
    "Explore TV series": {"ar":"استكشف المسلسلات","fr":"Explorer les séries TV","tr":"TV dizilerini keşfet"},
    "Catch-up": {"ar":"المشاهدة المؤجلة","fr":"Catch-up","tr":"Catch-up"},
    "Catch-up TV": {"ar":"المشاهدة المؤجلة","fr":"TV Catch-up","tr":"Catch-up TV"},
    "Watch past programs": {"ar":"شاهد البرامج السابقة","fr":"Regarder les programmes passés","tr":"Geçmiş programları izle"},
    "Favorites": {"ar":"المفضلة","fr":"Favoris","tr":"Favoriler"},
    "Your saved content": {"ar":"المحتوى المحفوظ","fr":"Votre contenu enregistré","tr":"Kaydettiğiniz içerik"},
    "Search": {"ar":"بحث","fr":"Recherche","tr":"Ara"},
    "Global Search": {"ar":"البحث العام","fr":"Recherche globale","tr":"Global Arama"},
    "Find content quickly": {"ar":"اعثر على المحتوى بسرعة","fr":"Trouver rapidement du contenu","tr":"İçeriği hızlıca bul"},
    "Portal & player settings": {"ar":"إعدادات البوابة والمشغل","fr":"Paramètres du portail et du lecteur","tr":"Portal ve oynatıcı ayarları"},
    "Continue Watching": {"ar":"متابعة المشاهدة","fr":"Continuer à regarder","tr":"İzlemeye Devam"},
    "Account Information": {"ar":"معلومات الحساب","fr":"Informations du compte","tr":"Hesap Bilgileri"},
    "CONTINUE / RECENT": {"ar":"متابعة / الأحدث","fr":"CONTINUER / RÉCENT","tr":"DEVAM / SON"},
    "Last Live": {"ar":"آخر بث مباشر","fr":"Dernier direct","tr":"Son Canlı"},
    "Last Movie": {"ar":"آخر فيلم","fr":"Dernier film","tr":"Son Film"},
    "Last Series": {"ar":"آخر مسلسل","fr":"Dernière série","tr":"Son Dizi"},
    "Nothing played yet": {"ar":"لم يتم تشغيل شيء بعد","fr":"Rien n’a encore été lu","tr":"Henüz hiçbir şey oynatılmadı"},
    "Open something and it will appear here": {"ar":"افتح أي محتوى وسيظهر هنا","fr":"Ouvrez un contenu et il apparaîtra ici","tr":"Bir içerik açın, burada görünecek"},
    "Portal sections": {"ar":"أقسام البوابة","fr":"Sections du portail","tr":"Portal Bölümleri"},
    "Choose a section": {"ar":"اختر قسمًا","fr":"Choisissez une section","tr":"Bir bölüm seçin"},
    "Live, Movies, Series, Favorites and Continue Watching": {"ar":"البث المباشر، الأفلام، المسلسلات، المفضلة ومتابعة المشاهدة","fr":"Direct, Films, Séries, Favoris et Continuer à regarder","tr":"Canlı, Filmler, Diziler, Favoriler ve İzlemeye Devam"},
    "Authorize": {"ar":"إعادة التوثيق","fr":"Autoriser","tr":"Yetkilendir"},
    "Refresh": {"ar":"تحديث","fr":"Actualiser","tr":"Yenile"},
    "Open / Play": {"ar":"فتح / تشغيل","fr":"Ouvrir / Lire","tr":"Aç / Oynat"},
    "Portal Manager": {"ar":"إدارة البوابات","fr":"Gestionnaire de portails","tr":"Portal Yöneticisi"},
    "Free Portal Library": {"ar":"مكتبة البوابات المجانية","fr":"Bibliothèque de portails gratuits","tr":"Ücretsiz Portal Kütüphanesi"},
    "Free Xtream Library": {"ar":"مكتبة Xtream المجانية","fr":"Bibliothèque Xtream gratuite","tr":"Ücretsiz Xtream Kütüphanesi"},
    "Import Selected": {"ar":"استيراد المحدد","fr":"Importer la sélection","tr":"Seçilenleri İçe Aktar"},
    "Select All": {"ar":"تحديد الكل","fr":"Tout sélectionner","tr":"Tümünü Seç"},
    "Clear": {"ar":"مسح التحديد","fr":"Effacer","tr":"Temizle"},

    # Details / auxiliary chrome
    "Options": {"ar":"الخيارات","fr":"Options","tr":"Seçenekler"},
    "INFORMATION": {"ar":"معلومات","fr":"INFORMATIONS","tr":"BİLGİ"},
    "OVERVIEW": {"ar":"الملخص","fr":"RÉSUMÉ","tr":"ÖZET"},
    "Cast": {"ar":"طاقم التمثيل","fr":"Distribution","tr":"Oyuncular"},
    "Director": {"ar":"المخرج","fr":"Réalisateur","tr":"Yönetmen"},
    "Writer": {"ar":"الكاتب","fr":"Scénariste","tr":"Yazar"},
    "Downloads": {"ar":"التنزيلات","fr":"Téléchargements","tr":"İndirmeler"},
    "Cancel selected": {"ar":"إلغاء المحدد","fr":"Annuler la sélection","tr":"Seçileni İptal Et"},
    "Retry failed": {"ar":"إعادة محاولة الفاشل","fr":"Réessayer les échecs","tr":"Başarısızları Yeniden Dene"},
    "No description available.": {"ar":"لا يوجد وصف متاح.","fr":"Aucune description disponible.","tr":"Açıklama mevcut değil."},
    "No results": {"ar":"لا توجد نتائج","fr":"Aucun résultat","tr":"Sonuç yok"},
    "No content": {"ar":"لا يوجد محتوى","fr":"Aucun contenu","tr":"İçerik yok"},
    "No seasons": {"ar":"لا توجد مواسم","fr":"Aucune saison","tr":"Sezon yok"},
    "No episodes": {"ar":"لا توجد حلقات","fr":"Aucun épisode","tr":"Bölüm yok"},
    "Choose a season": {"ar":"اختر موسمًا","fr":"Choisissez une saison","tr":"Bir sezon seçin"},
    "SEASONS": {"ar":"المواسم","fr":"SAISONS","tr":"SEZONLAR"},
    "EPISODES": {"ar":"الحلقات","fr":"ÉPISODES","tr":"BÖLÜMLER"},
    "EPISODE DETAILS": {"ar":"تفاصيل الحلقة","fr":"DÉTAILS DE L’ÉPISODE","tr":"BÖLÜM AYRINTILARI"},
    "Cache Artwork": {"ar":"تخزين الصور","fr":"Mettre les illustrations en cache","tr":"Görselleri Önbelleğe Al"},
    "Cache Picons": {"ar":"تخزين شعارات القنوات","fr":"Mettre les picons en cache","tr":"Piconları Önbelleğe Al"},
    "Loading...": {"ar":"جارٍ التحميل...","fr":"Chargement...","tr":"Yükleniyor..."},
    "Loading": {"ar":"جارٍ التحميل","fr":"Chargement","tr":"Yükleniyor"},
    "Please wait": {"ar":"يرجى الانتظار","fr":"Veuillez patienter","tr":"Lütfen bekleyin"},
    "Initializing premium interface": {"ar":"جارٍ تهيئة الواجهة","fr":"Initialisation de l’interface premium","tr":"Premium arayüz başlatılıyor"},

    "Web Cleaner Ready": {"ar":"Web Cleaner جاهز","fr":"Web Cleaner prêt","tr":"Web Cleaner Hazır"},
    "Open this address on the same local network:": {"ar":"افتح هذا العنوان على نفس الشبكة المحلية:","fr":"Ouvrez cette adresse sur le même réseau local :","tr":"Bu adresi aynı yerel ağda açın:"},
    "PAIRING CODE": {"ar":"كود الاقتران","fr":"CODE D’APPAIRAGE","tr":"EŞLEŞTİRME KODU"},
    "Enter the code once. Your browser keeps the secure session until Web Cleaner is stopped.": {"ar":"أدخل الكود مرة واحدة. سيحتفظ المتصفح بالجلسة الآمنة حتى يتم إيقاف Web Cleaner.","fr":"Saisissez le code une fois. Le navigateur conserve la session sécurisée jusqu’à l’arrêt de Web Cleaner.","tr":"Kodu bir kez girin. Web Cleaner durdurulana kadar tarayıcınız güvenli oturumu korur."},
    "Scan QR for instant access": {"ar":"امسح QR للدخول فورًا","fr":"Scannez le QR pour un accès instantané","tr":"Anında erişim için QR’ı tara"},
    "QR unavailable • use the 6-digit code": {"ar":"QR غير متاح • استخدم الكود المكوّن من 6 أرقام","fr":"QR indisponible • utilisez le code à 6 chiffres","tr":"QR kullanılamıyor • 6 haneli kodu kullanın"},
    "EASY ACCESS": {"ar":"دخول سهل","fr":"ACCÈS FACILE","tr":"KOLAY ERİŞİM"},
    "NO PIN": {"ar":"بدون PIN","fr":"SANS PIN","tr":"PIN YOK"},
    "Direct access is limited to devices on the local network. Use Stop Service when finished.": {"ar":"الدخول المباشر متاح فقط للأجهزة على الشبكة المحلية. استخدم إيقاف الخدمة عند الانتهاء.","fr":"L’accès direct est limité aux appareils du réseau local. Utilisez Arrêter le service lorsque vous avez terminé.","tr":"Doğrudan erişim yalnızca yerel ağdaki cihazlarla sınırlıdır. İşiniz bitince Hizmeti Durdur’u kullanın."},
    "PIN / QR protection can be enabled from Settings": {"ar":"يمكن تفعيل حماية PIN / QR من الإعدادات","fr":"La protection PIN / QR peut être activée dans les Paramètres","tr":"PIN / QR koruması Ayarlar’dan etkinleştirilebilir"},

    "SYSTEM DIAGNOSTICS  •  NOVA FHD": {"ar":"تشخيص النظام  •  NOVA FHD","fr":"DIAGNOSTIC SYSTÈME  •  NOVA FHD","tr":"SİSTEM TANILAMA  •  NOVA FHD"},
    "GREEN: refresh  •  YELLOW: support bundle": {"ar":"الأخضر: تحديث  •  الأصفر: حزمة الدعم","fr":"VERT : actualiser  •  JAUNE : paquet de support","tr":"YEŞİL: yenile  •  SARI: destek paketi"},
}


_T.update({
    "Professional channel list with lazy Now / Next EPG": {"ar":"قائمة قنوات احترافية مع EPG الآن/التالي عند الطلب","fr":"Liste de chaînes professionnelle avec EPG Maintenant / Suivant à la demande","tr":"İsteğe bağlı Şimdi / Sonraki EPG’li profesyonel kanal listesi"},
    "Movies with artwork, details, favorites and watched state": {"ar":"أفلام مع الصور والتفاصيل والمفضلة وحالة المشاهدة","fr":"Films avec illustrations, détails, favoris et état de visionnage","tr":"Görseller, ayrıntılar, favoriler ve izlenme durumuyla filmler"},
    "Series, seasons, episodes and resume support": {"ar":"مسلسلات ومواسم وحلقات مع دعم استكمال المشاهدة","fr":"Séries, saisons, épisodes et reprise de lecture","tr":"Diziler, sezonlar, bölümler ve devam desteği"},
    "Archived programmes and replay TV": {"ar":"برامج مؤرشفة وإعادة مشاهدة التلفزيون","fr":"Programmes archivés et TV en replay","tr":"Arşiv programları ve tekrar TV"},
    "Your saved content  •  %d items": {"ar":"المحتوى المحفوظ  •  %d عنصر","fr":"Votre contenu enregistré  •  %d éléments","tr":"Kaydettiğiniz içerik  •  %d öğe"},
    "Continue watching  •  %d items": {"ar":"متابعة المشاهدة  •  %d عنصر","fr":"Continuer à regarder  •  %d éléments","tr":"İzlemeye devam  •  %d öğe"},
    "Subscription and portal health details": {"ar":"تفاصيل الاشتراك وحالة البوابة","fr":"Détails de l’abonnement et état du portail","tr":"Abonelik ve portal durum ayrıntıları"},
    "One search across Live, Movies and Series": {"ar":"بحث واحد في البث المباشر والأفلام والمسلسلات","fr":"Une recherche dans Direct, Films et Séries","tr":"Canlı, Filmler ve Dizilerde tek arama"},
    "Themes, lists, Smart Engine, privacy and cache": {"ar":"المظاهر والقوائم والخصوصية والكاش","fr":"Thèmes, listes, moteur intelligent, confidentialité et cache","tr":"Temalar, listeler, Akıllı Motor, gizlilik ve önbellek"},
    "Press OK to browse %s": {"ar":"اضغط OK لتصفح %s","fr":"Appuyez sur OK pour parcourir %s","tr":"%s göz atmak için OK’a basın"},
    "PORTAL HOME  •  %d sections": {"ar":"الرئيسية  •  %d أقسام","fr":"ACCUEIL PORTAIL  •  %d sections","tr":"PORTAL ANA SAYFA  •  %d bölüm"},
    "Loading content...": {"ar":"جارٍ تحميل المحتوى...","fr":"Chargement du contenu...","tr":"İçerik yükleniyor..."},
    "Loading categories...": {"ar":"جارٍ تحميل الأقسام...","fr":"Chargement des catégories...","tr":"Kategoriler yükleniyor..."},
    "Loading EPG...": {"ar":"جارٍ تحميل EPG...","fr":"Chargement de l’EPG...","tr":"EPG yükleniyor..."},
    "Loading account information...": {"ar":"جارٍ تحميل معلومات الحساب...","fr":"Chargement des informations du compte...","tr":"Hesap bilgileri yükleniyor..."},
    "Loading catch-up channels...  •  BACK cancels": {"ar":"جارٍ تحميل قنوات المشاهدة المؤجلة...  •  BACK للإلغاء","fr":"Chargement des chaînes Catch-up...  •  BACK annule","tr":"Catch-up kanalları yükleniyor...  •  BACK iptal eder"},
    "Loading archive programmes...  •  BACK cancels": {"ar":"جارٍ تحميل البرامج المؤرشفة...  •  BACK للإلغاء","fr":"Chargement des programmes archivés...  •  BACK annule","tr":"Arşiv programları yükleniyor...  •  BACK iptal eder"},
    "Creating stream link...": {"ar":"جارٍ إنشاء رابط البث...","fr":"Création du lien de flux...","tr":"Akış bağlantısı oluşturuluyor..."},
    "Creating catch-up stream...": {"ar":"جارٍ إنشاء بث المشاهدة المؤجلة...","fr":"Création du flux Catch-up...","tr":"Catch-up akışı oluşturuluyor..."},
    "No stream command": {"ar":"لا يوجد أمر تشغيل","fr":"Aucune commande de flux","tr":"Akış komutu yok"},
    "Portal returned an invalid stream link": {"ar":"أعادت البوابة رابط بث غير صالح","fr":"Le portail a renvoyé un lien de flux invalide","tr":"Portal geçersiz akış bağlantısı döndürdü"},
    "Player closed": {"ar":"تم إغلاق المشغل","fr":"Lecteur fermé","tr":"Oynatıcı kapandı"},
    "Reauthorizing...": {"ar":"جارٍ إعادة التوثيق...","fr":"Nouvelle autorisation...","tr":"Yeniden yetkilendiriliyor..."},
    "Authorized": {"ar":"تم التوثيق","fr":"Autorisé","tr":"Yetkilendirildi"},
    "No more items": {"ar":"لا توجد عناصر أخرى","fr":"Aucun autre élément","tr":"Başka öğe yok"},
    "Folder is empty": {"ar":"المجلد فارغ","fr":"Le dossier est vide","tr":"Klasör boş"},
    "No matching content": {"ar":"لا يوجد محتوى مطابق","fr":"Aucun contenu correspondant","tr":"Eşleşen içerik yok"},
    "Search is available inside content lists": {"ar":"البحث متاح داخل قوائم المحتوى","fr":"La recherche est disponible dans les listes de contenu","tr":"Arama içerik listelerinde kullanılabilir"},
    "Searching enabled portals...": {"ar":"جارٍ البحث في البوابات المفعّلة...","fr":"Recherche dans les portails activés...","tr":"Etkin portallarda aranıyor..."},
    "Searching current portal...": {"ar":"جارٍ البحث في البوابة الحالية...","fr":"Recherche dans le portail actuel...","tr":"Mevcut portalda aranıyor..."},
    "Results for: %s": {"ar":"نتائج البحث عن: %s","fr":"Résultats pour : %s","tr":"Şunun için sonuçlar: %s"},
    "Added to favorites": {"ar":"تمت الإضافة إلى المفضلة","fr":"Ajouté aux favoris","tr":"Favorilere eklendi"},
    "Removed from favorites": {"ar":"تمت الإزالة من المفضلة","fr":"Retiré des favoris","tr":"Favorilerden kaldırıldı"},
    "Marked watched": {"ar":"تم التعليم كمُشاهد","fr":"Marqué comme vu","tr":"İzlendi olarak işaretlendi"},
    "Marked unwatched": {"ar":"تم التعليم كغير مُشاهد","fr":"Marqué comme non vu","tr":"İzlenmedi olarak işaretlendi"},
    "Nothing selected  •  OK Select  •  GREEN Import Selected  •  BACK Portal Manager": {"ar":"لا يوجد تحديد  •  OK تحديد  •  الأخضر استيراد المحدد  •  BACK إدارة البوابات","fr":"Aucune sélection  •  OK Sélectionner  •  VERT Importer la sélection  •  BACK Gestionnaire de portails","tr":"Seçim yok  •  OK Seç  •  YEŞİL Seçilenleri İçe Aktar  •  BACK Portal Yöneticisi"},
    "Import complete  •  %d added  •  %d already existed  •  no server checks were run": {"ar":"اكتمل الاستيراد  •  تمت إضافة %d  •  %d موجود بالفعل  •  لم يتم فحص السيرفرات","fr":"Import terminé  •  %d ajoutés  •  %d existaient déjà  •  aucun contrôle serveur effectué","tr":"İçe aktarma tamamlandı  •  %d eklendi  •  %d zaten vardı  •  sunucu kontrolü yapılmadı"},
    "Import failed  •  BACK Portal Manager": {"ar":"فشل الاستيراد  •  BACK إدارة البوابات","fr":"Échec de l’import  •  BACK Gestionnaire de portails","tr":"İçe aktarma başarısız  •  BACK Portal Yöneticisi"},
    "Import failed": {"ar":"فشل الاستيراد","fr":"Échec de l’import","tr":"İçe aktarma başarısız"},
    "Library is empty": {"ar":"المكتبة فارغة","fr":"La bibliothèque est vide","tr":"Kütüphane boş"},
    "BACK Portal Manager": {"ar":"BACK إدارة البوابات","fr":"BACK Gestionnaire de portails","tr":"BACK Portal Yöneticisi"},
    "OK  Select   •   BACK  Cancel": {"ar":"OK اختيار   •   BACK إلغاء","fr":"OK Sélectionner   •   BACK Annuler","tr":"OK Seç   •   BACK İptal"},
    "OK  Save   •   BACK  Cancel": {"ar":"OK حفظ   •   BACK إلغاء","fr":"OK Enregistrer   •   BACK Annuler","tr":"OK Kaydet   •   BACK İptal"},
    "OK  Select   •   BACK  Close   •   UP / DOWN  Navigate": {"ar":"OK اختيار   •   BACK إغلاق   •   أعلى / أسفل للتنقل","fr":"OK Sélectionner   •   BACK Fermer   •   HAUT / BAS Naviguer","tr":"OK Seç   •   BACK Kapat   •   YUKARI / AŞAĞI Gezin"},
    "OK / BACK  Close": {"ar":"OK / BACK إغلاق","fr":"OK / BACK Fermer","tr":"OK / BACK Kapat"},
    "UP / DOWN  Scroll": {"ar":"أعلى / أسفل للتمرير","fr":"HAUT / BAS  Faire défiler","tr":"YUKARI / AŞAĞI  Kaydır"},
    "LEFT / RIGHT Navigate • DOWN Recent • OK Open • BACK Portals": {"ar":"يسار / يمين للتنقل • أسفل للأحدث • OK فتح • BACK البوابات","fr":"GAUCHE / DROITE Naviguer • BAS Récent • OK Ouvrir • BACK Portails","tr":"SOL / SAĞ Gezin • AŞAĞI Son • OK Aç • BACK Portallar"},
    "Featured artwork is still warming on HDD": {"ar":"جارٍ تجهيز الصورة المميزة على الهارد","fr":"L’illustration mise en avant est encore en préparation sur le disque","tr":"Öne çıkan görsel diskte hâlâ hazırlanıyor"},
    "Home Hero pinned • choose another from Movie/Series Details MENU": {"ar":"تم تثبيت صورة الرئيسية • اختر غيرها من MENU داخل تفاصيل الفيلم/المسلسل","fr":"Visuel d’accueil épinglé • choisissez-en un autre via MENU dans les détails Film/Série","tr":"Ana Sayfa Hero sabitlendi • Film/Dizi Ayrıntıları MENU’den başka bir tane seçin"},
    "Nothing has been played in this section yet": {"ar":"لم يتم تشغيل شيء في هذا القسم بعد","fr":"Rien n’a encore été lu dans cette section","tr":"Bu bölümde henüz hiçbir şey oynatılmadı"},
    "Saved item has no stream command": {"ar":"العنصر المحفوظ لا يحتوي على أمر تشغيل","fr":"L’élément enregistré ne contient aucune commande de flux","tr":"Kaydedilen öğede akış komutu yok"},
    "Open failed: %s": {"ar":"فشل الفتح: %s","fr":"Échec de l’ouverture : %s","tr":"Açma başarısız: %s"},
    "Portal Manager • %s • %s • ARROWS Navigate • OK Select • BACK Portals%s": {"ar":"إدارة البوابات • %s • %s • الأسهم للتنقل • OK اختيار • BACK البوابات%s","fr":"Gestionnaire de portails • %s • %s • FLÈCHES Naviguer • OK Sélectionner • BACK Portails%s","tr":"Portal Yöneticisi • %s • %s • OKLAR Gezin • OK Seç • BACK Portallar%s"},
    "Profiles reloaded": {"ar":"تمت إعادة تحميل الملفات الشخصية","fr":"Profils rechargés","tr":"Profiller yeniden yüklendi"},
    "Checking source type…": {"ar":"جارٍ تحديد نوع المصدر…","fr":"Détection du type de source…","tr":"Kaynak türü kontrol ediliyor…"},
    "M3U playlist added": {"ar":"تمت إضافة قائمة M3U","fr":"Playlist M3U ajoutée","tr":"M3U oynatma listesi eklendi"},
    "Portal updated": {"ar":"تم تحديث البوابة","fr":"Portail mis à jour","tr":"Portal güncellendi"},
    "Portal duplicated": {"ar":"تم تكرار البوابة","fr":"Portail dupliqué","tr":"Portal çoğaltıldı"},
    "Portal enabled": {"ar":"تم تفعيل البوابة","fr":"Portail activé","tr":"Portal etkinleştirildi"},
    "Portal permanently deleted": {"ar":"تم حذف البوابة نهائيًا","fr":"Portail supprimé définitivement","tr":"Portal kalıcı olarak silindi"},
    "Portal renamed": {"ar":"تمت إعادة تسمية البوابة","fr":"Portail renommé","tr":"Portal yeniden adlandırıldı"},
    "No Portal / M3U sources": {"ar":"لا توجد مصادر Portal / M3U","fr":"Aucune source Portal / M3U","tr":"Portal / M3U kaynağı yok"},
    "MENU Portal Manager  •  Add a Portal or M3U source to begin": {"ar":"MENU إدارة البوابات  •  أضف مصدر Portal أو M3U للبدء","fr":"MENU Gestionnaire de portails  •  Ajoutez une source Portal ou M3U pour commencer","tr":"MENU Portal Yöneticisi  •  Başlamak için Portal veya M3U kaynağı ekleyin"},
    "Testing TMDB connection...": {"ar":"جارٍ اختبار اتصال TMDB...","fr":"Test de la connexion TMDB...","tr":"TMDB bağlantısı test ediliyor..."},
    "TMDB ready": {"ar":"TMDB جاهز","fr":"TMDB prêt","tr":"TMDB hazır"},
    "Parental PIN saved securely": {"ar":"تم حفظ PIN الرقابة بأمان","fr":"PIN parental enregistré de façon sécurisée","tr":"Ebeveyn PIN’i güvenli şekilde kaydedildi"},
    "Parental session locked": {"ar":"تم قفل جلسة الرقابة","fr":"Session parentale verrouillée","tr":"Ebeveyn oturumu kilitlendi"},
    "Adult keywords saved": {"ar":"تم حفظ كلمات محتوى البالغين","fr":"Mots-clés adulte enregistrés","tr":"Yetişkin anahtar kelimeleri kaydedildi"},
    "Web Cleaner running on port 7725": {"ar":"Web Cleaner يعمل على المنفذ 7725","fr":"Web Cleaner fonctionne sur le port 7725","tr":"Web Cleaner 7725 portunda çalışıyor"},
    "Web Cleaner stopped": {"ar":"تم إيقاف Web Cleaner","fr":"Web Cleaner arrêté","tr":"Web Cleaner durduruldu"},
})


_T.update({
    "%s season": {"ar":"%s موسم","fr":"%s saison","tr":"%s sezon"},
    "%s seasons": {"ar":"%s موسم","fr":"%s saisons","tr":"%s sezon"},
    "Check all portals": {"ar":"فحص كل البوابات","fr":"Vérifier tous les portails","tr":"Tüm portalları kontrol et"},
    "Re-enable disabled portal": {"ar":"إعادة تفعيل بوابة معطلة","fr":"Réactiver un portail désactivé","tr":"Devre dışı portalı yeniden etkinleştir"},
    "Rename portal": {"ar":"إعادة تسمية البوابة","fr":"Renommer le portail","tr":"Portalı yeniden adlandır"},
    "Edit URL / MAC": {"ar":"تعديل URL / MAC","fr":"Modifier URL / MAC","tr":"URL / MAC düzenle"},
    "MAG device profile": {"ar":"ملف جهاز MAG","fr":"Profil appareil MAG","tr":"MAG cihaz profili"},
    "Export Live bouquet + EPG": {"ar":"تصدير باقة البث المباشر + EPG","fr":"Exporter bouquet Live + EPG","tr":"Canlı buketi + EPG dışa aktar"},
    "Remove exported bouquet + EPG": {"ar":"إزالة الباقة المصدرة + EPG","fr":"Supprimer le bouquet exporté + EPG","tr":"Dışa aktarılan buket + EPG’yi kaldır"},
    "Duplicate with another MAC": {"ar":"نسخ باستخدام MAC آخر","fr":"Dupliquer avec un autre MAC","tr":"Başka MAC ile çoğalt"},
    "Move up": {"ar":"تحريك لأعلى","fr":"Monter","tr":"Yukarı taşı"},
    "Move down": {"ar":"تحريك لأسفل","fr":"Descendre","tr":"Aşağı taşı"},
    "Disable portal": {"ar":"تعطيل البوابة","fr":"Désactiver le portail","tr":"Portalı devre dışı bırak"},
    "Clear portal data": {"ar":"مسح بيانات البوابة","fr":"Effacer les données du portail","tr":"Portal verilerini temizle"},
    "Delete permanently": {"ar":"حذف نهائي","fr":"Supprimer définitivement","tr":"Kalıcı olarak sil"},
    "Select portals": {"ar":"تحديد البوابات","fr":"Sélectionner des portails","tr":"Portalları seç"},
    "Browse the bundled Portal catalog and import selected entries": {"ar":"تصفح مكتبة Portal المدمجة واستورد العناصر المحددة","fr":"Parcourir le catalogue Portal intégré et importer les éléments sélectionnés","tr":"Dahili Portal kataloğuna göz at ve seçilenleri içe aktar"},
    "Browse the bundled Xtream catalog and import selected entries": {"ar":"تصفح مكتبة Xtream المدمجة واستورد العناصر المحددة","fr":"Parcourir le catalogue Xtream intégré et importer les éléments sélectionnés","tr":"Dahili Xtream kataloğuna göz at ve seçilenleri içe aktar"},
    "Health check for every enabled portal": {"ar":"فحص حالة كل بوابة مفعلة","fr":"Contrôle de l’état de chaque portail activé","tr":"Etkin tüm portallar için durum kontrolü"},
    "Restore a disabled portal": {"ar":"استعادة بوابة معطلة","fr":"Restaurer un portail désactivé","tr":"Devre dışı portalı geri yükle"},
    "Rename the selected portal": {"ar":"أعد تسمية البوابة المحددة","fr":"Renommer le portail sélectionné","tr":"Seçili portalı yeniden adlandır"},
    "Edit portal address or MAC": {"ar":"عدّل عنوان البوابة أو MAC","fr":"Modifier l’adresse du portail ou le MAC","tr":"Portal adresini veya MAC’i düzenle"},
    "Choose the MAG device profile": {"ar":"اختر ملف جهاز MAG","fr":"Choisir le profil de l’appareil MAG","tr":"MAG cihaz profilini seç"},
    "Create Live bouquet and EPG source": {"ar":"أنشئ باقة بث مباشر ومصدر EPG","fr":"Créer un bouquet Live et une source EPG","tr":"Canlı buket ve EPG kaynağı oluştur"},
    "Remove the exported Live integration": {"ar":"أزل تكامل البث المباشر المُصدّر","fr":"Supprimer l’intégration Live exportée","tr":"Dışa aktarılan Canlı entegrasyonunu kaldır"},
    "Clone this portal with another MAC": {"ar":"انسخ هذه البوابة باستخدام MAC آخر","fr":"Cloner ce portail avec un autre MAC","tr":"Bu portalı başka MAC ile klonla"},
    "Move the selected portal up": {"ar":"حرّك البوابة المحددة لأعلى","fr":"Déplacer le portail sélectionné vers le haut","tr":"Seçili portalı yukarı taşı"},
    "Move the selected portal down": {"ar":"حرّك البوابة المحددة لأسفل","fr":"Déplacer le portail sélectionné vers le bas","tr":"Seçili portalı aşağı taşı"},
    "Disable the selected portal": {"ar":"عطّل البوابة المحددة","fr":"Désactiver le portail sélectionné","tr":"Seçili portalı devre dışı bırak"},
    "Clear plugin-owned data but keep portal": {"ar":"امسح بيانات البلجن مع الاحتفاظ بالبوابة","fr":"Effacer les données du plugin tout en conservant le portail","tr":"Portalı koruyup eklenti verilerini temizle"},
    "Delete this portal and related plugin data": {"ar":"احذف هذه البوابة وبيانات البلجن المرتبطة","fr":"Supprimer ce portail et les données associées du plugin","tr":"Bu portalı ve ilgili eklenti verilerini sil"},
    "Open diagnostics for the selected portal": {"ar":"افتح التشخيص للبوابة المحددة","fr":"Ouvrir les diagnostics du portail sélectionné","tr":"Seçili portal için tanılamayı aç"},
    "Select multiple portals for one permanent delete": {"ar":"حدد عدة بوابات لحذفها نهائيًا دفعة واحدة","fr":"Sélectionner plusieurs portails pour une suppression définitive groupée","tr":"Tek seferde kalıcı silme için birden fazla portal seç"},
    "Choose a portal tool": {"ar":"اختر أداة للبوابة","fr":"Choisissez un outil de portail","tr":"Bir portal aracı seçin"},
    "No portal selected": {"ar":"لا توجد بوابة محددة","fr":"Aucun portail sélectionné","tr":"Portal seçilmedi"},
    "Portal Library": {"ar":"مكتبة البوابات","fr":"Bibliothèque de portails","tr":"Portal Kütüphanesi"},
    "Xtream Library": {"ar":"مكتبة Xtream","fr":"Bibliothèque Xtream","tr":"Xtream Kütüphanesi"},
    "Nothing selected • OK Toggle • GREEN Import Selected • BACK Settings": {"ar":"لا يوجد تحديد • OK تحديد/إلغاء • الأخضر استيراد المحدد • BACK الإعدادات","fr":"Aucune sélection • OK Basculer • VERT Importer la sélection • BACK Paramètres","tr":"Seçim yok • OK Değiştir • YEŞİL Seçilenleri İçe Aktar • BACK Ayarlar"},
    "Import complete • %d added • %d already existed • no server checks were run": {"ar":"اكتمل الاستيراد • تمت إضافة %d • %d موجود بالفعل • لم يتم فحص السيرفرات","fr":"Import terminé • %d ajoutés • %d existaient déjà • aucun contrôle serveur effectué","tr":"İçe aktarma tamamlandı • %d eklendi • %d zaten vardı • sunucu kontrolü yapılmadı"},
    "%s • Library is empty • BACK Settings": {"ar":"%s • المكتبة فارغة • BACK الإعدادات","fr":"%s • bibliothèque vide • BACK Paramètres","tr":"%s • kütüphane boş • BACK Ayarlar"},
    "%s • %d entries • %d selected • OK Toggle • GREEN Import • YELLOW Select all • RED Clear • BACK Settings": {"ar":"%s • %d عنصر • %d محدد • OK تحديد/إلغاء • الأخضر استيراد • الأصفر تحديد الكل • الأحمر مسح • BACK الإعدادات","fr":"%s • %d entrées • %d sélectionnées • OK Basculer • VERT Importer • JAUNE Tout sélectionner • ROUGE Effacer • BACK Paramètres","tr":"%s • %d kayıt • %d seçili • OK Değiştir • YEŞİL İçe Aktar • SARI Tümünü Seç • KIRMIZI Temizle • BACK Ayarlar"},
})


_T.update({
    "Play": {"ar":"تشغيل","fr":"Lire","tr":"Oynat"},
    "Episodes": {"ar":"الحلقات","fr":"Épisodes","tr":"Bölümler"},
    "Resume": {"ar":"استكمال","fr":"Reprendre","tr":"Devam Et"},
    "Favorite": {"ar":"المفضلة","fr":"Favori","tr":"Favori"},
    "Default": {"ar":"افتراضي","fr":"Par défaut","tr":"Varsayılan"},
    "Previous page": {"ar":"الصفحة السابقة","fr":"Page précédente","tr":"Önceki sayfa"},
    "Next page": {"ar":"الصفحة التالية","fr":"Page suivante","tr":"Sonraki sayfa"},
    "Page 1": {"ar":"الصفحة 1","fr":"Page 1","tr":"Sayfa 1"},
    "TMDB rating": {"ar":"تقييم TMDB","fr":"Note TMDB","tr":"TMDB puanı"},
    "Metadata": {"ar":"البيانات","fr":"Métadonnées","tr":"Meta veri"},
    "Provider rating": {"ar":"تقييم المزود","fr":"Note du fournisseur","tr":"Sağlayıcı puanı"},
    "TMDb • portal metadata": {"ar":"TMDb • بيانات البوابة","fr":"TMDb • métadonnées du portail","tr":"TMDb • portal meta verisi"},
    "Server • TMDb enrichment": {"ar":"السيرفر • إثراء TMDb","fr":"Serveur • enrichissement TMDb","tr":"Sunucu • TMDb zenginleştirme"},
    "Server metadata loaded": {"ar":"تم تحميل بيانات السيرفر","fr":"Métadonnées du serveur chargées","tr":"Sunucu meta verisi yüklendi"},
    "Open season": {"ar":"فتح الموسم","fr":"Ouvrir la saison","tr":"Sezonu aç"},
    "Play episode %s": {"ar":"تشغيل الحلقة %s","fr":"Lire l’épisode %s","tr":"%s. bölümü oynat"},
    "OK  Play episode": {"ar":"OK تشغيل الحلقة","fr":"OK  Lire l’épisode","tr":"OK  Bölümü oynat"},
    "%d seasons": {"ar":"%d موسم","fr":"%d saisons","tr":"%d sezon"},
    "%d episodes": {"ar":"%d حلقة","fr":"%d épisodes","tr":"%d bölüm"},
    "%d episode": {"ar":"%d حلقة","fr":"%d épisode","tr":"%d bölüm"},
    "Loading seasons...": {"ar":"جارٍ تحميل المواسم...","fr":"Chargement des saisons...","tr":"Sezonlar yükleniyor..."},
    "Loading episodes...": {"ar":"جارٍ تحميل الحلقات...","fr":"Chargement des épisodes...","tr":"Bölümler yükleniyor..."},
    "Seasons failed: %s": {"ar":"فشل تحميل المواسم: %s","fr":"Échec du chargement des saisons : %s","tr":"Sezonlar yüklenemedi: %s"},
    "Episodes failed: %s": {"ar":"فشل تحميل الحلقات: %s","fr":"Échec du chargement des épisodes : %s","tr":"Bölümler yüklenemedi: %s"},
    "Episode has no stream command": {"ar":"الحلقة لا تحتوي على أمر تشغيل","fr":"L’épisode ne contient aucune commande de flux","tr":"Bölümde akış komutu yok"},
    "Creating episode stream...": {"ar":"جارٍ إنشاء بث الحلقة...","fr":"Création du flux de l’épisode...","tr":"Bölüm akışı oluşturuluyor..."},
    "Portal returned an invalid episode link": {"ar":"أعادت البوابة رابط حلقة غير صالح","fr":"Le portail a renvoyé un lien d’épisode invalide","tr":"Portal geçersiz bölüm bağlantısı döndürdü"},
    "Opening player: %s": {"ar":"جارٍ فتح المشغل: %s","fr":"Ouverture du lecteur : %s","tr":"Oynatıcı açılıyor: %s"},
    "Player closed  •  engine %s": {"ar":"تم إغلاق المشغل  •  المحرك %s","fr":"Lecteur fermé  •  moteur %s","tr":"Oynatıcı kapandı  •  motor %s"},
    "Player failed: %s": {"ar":"فشل المشغل: %s","fr":"Échec du lecteur : %s","tr":"Oynatıcı başarısız: %s"},
    "Play failed: %s": {"ar":"فشل التشغيل: %s","fr":"Échec de la lecture : %s","tr":"Oynatma başarısız: %s"},
    "Open a season first": {"ar":"افتح موسمًا أولًا","fr":"Ouvrez d’abord une saison","tr":"Önce bir sezon açın"},
    "Series UI error: %s": {"ar":"خطأ في واجهة المسلسلات: %s","fr":"Erreur d’interface Séries : %s","tr":"Dizi arayüz hatası: %s"},
    "Preparing...": {"ar":"جارٍ التجهيز...","fr":"Préparation...","tr":"Hazırlanıyor..."},
    "Loading folder index...": {"ar":"جارٍ تحميل فهرس المجلد...","fr":"Chargement de l’index du dossier...","tr":"Klasör dizini yükleniyor..."},
    "Artwork cache is already running": {"ar":"تخزين الصور يعمل بالفعل","fr":"La mise en cache des illustrations est déjà en cours","tr":"Görsel önbellekleme zaten çalışıyor"},
    "Preparing current folder artwork cache...": {"ar":"جارٍ تجهيز كاش صور المجلد الحالي...","fr":"Préparation du cache d’illustrations du dossier actuel...","tr":"Mevcut klasörün görsel önbelleği hazırlanıyor..."},
    "Resuming %d missing titles...": {"ar":"جارٍ استكمال %d عنوان ناقص...","fr":"Reprise de %d titres manquants...","tr":"%d eksik başlık devam ettiriliyor..."},
    "Caching %d / %d": {"ar":"جارٍ التخزين %d / %d","fr":"Mise en cache %d / %d","tr":"Önbelleğe alınıyor %d / %d"},
    "Artwork ready • %d/%d": {"ar":"الصور جاهزة • %d/%d","fr":"Illustrations prêtes • %d/%d","tr":"Görseller hazır • %d/%d"},
    "Loading page %d...": {"ar":"جارٍ تحميل الصفحة %d...","fr":"Chargement de la page %d...","tr":"%d. sayfa yükleniyor..."},
    "Page %d / %d  •  %s %d / %d": {"ar":"الصفحة %d / %d  •  %s %d / %d","fr":"Page %d / %d  •  %s %d / %d","tr":"Sayfa %d / %d  •  %s %d / %d"},
    "NOW  %s": {"ar":"الآن  %s","fr":"MAINTENANT  %s","tr":"ŞİMDİ  %s"},
    "NEXT  ": {"ar":"التالي  ","fr":"SUIVANT  ","tr":"SONRAKİ  "},
})


_T.update({
    "1 / 4\n\nSet up your first portal in a few steps.\nYou will enter the Portal URL and MAC address, then Ultra Stalker will test the connection before saving it.": {"ar":"1 / 4\n\nأعدّ بوابتك الأولى في خطوات بسيطة.\nستدخل رابط البوابة وعنوان MAC، ثم سيختبر Ultra Stalker الاتصال قبل الحفظ.","fr":"1 / 4\n\nConfigurez votre premier portail en quelques étapes.\nVous saisirez l’URL du portail et l’adresse MAC, puis Ultra Stalker testera la connexion avant l’enregistrement.","tr":"1 / 4\n\nİlk portalınızı birkaç adımda kurun.\nPortal URL’sini ve MAC adresini gireceksiniz; ardından Ultra Stalker kaydetmeden önce bağlantıyı test edecek."},
    "2 / 4\n\nEnter the Portal URL. HTTPS is recommended whenever your provider supports it.": {"ar":"2 / 4\n\nأدخل رابط البوابة. يُفضّل استخدام HTTPS إذا كان مزود الخدمة يدعمه.","fr":"2 / 4\n\nSaisissez l’URL du portail. HTTPS est recommandé lorsque votre fournisseur le prend en charge.","tr":"2 / 4\n\nPortal URL’sini girin. Sağlayıcınız destekliyorsa HTTPS kullanmanız önerilir."},
    "3 / 4\n\nEnter the MAG/STB MAC address supplied for this subscription.\nExample: 00:1A:79:XX:XX:XX": {"ar":"3 / 4\n\nأدخل عنوان MAC الخاص بجهاز MAG/STB والمخصص لهذا الاشتراك.\nمثال: 00:1A:79:XX:XX:XX","fr":"3 / 4\n\nSaisissez l’adresse MAC MAG/STB fournie pour cet abonnement.\nExemple : 00:1A:79:XX:XX:XX","tr":"3 / 4\n\nBu abonelik için verilen MAG/STB MAC adresini girin.\nÖrnek: 00:1A:79:XX:XX:XX"},
    "4 / 4\n\nTesting the M3U playlist…\nChecking network access and playlist content.": {"ar":"4 / 4\n\nجارٍ اختبار قائمة M3U…\nيتم فحص اتصال الشبكة ومحتوى القائمة.","fr":"4 / 4\n\nTest de la playlist M3U…\nVérification de l’accès réseau et du contenu de la playlist.","tr":"4 / 4\n\nM3U oynatma listesi test ediliyor…\nAğ erişimi ve liste içeriği kontrol ediliyor."},
    "4 / 4\n\nTesting the portal connection…\nChecking network access, MAG authentication and account response.": {"ar":"4 / 4\n\nجارٍ اختبار اتصال البوابة…\nيتم فحص الشبكة وتوثيق MAG واستجابة الحساب.","fr":"4 / 4\n\nTest de la connexion au portail…\nVérification du réseau, de l’authentification MAG et de la réponse du compte.","tr":"4 / 4\n\nPortal bağlantısı test ediliyor…\nAğ erişimi, MAG kimlik doğrulaması ve hesap yanıtı kontrol ediliyor."},
    "Bouquet proxy port (1024-65535)": {"ar":"منفذ بروكسي الباقات (1024-65535)","fr":"Port proxy des bouquets (1024-65535)","tr":"Buket proxy portu (1024-65535)"},
    "Connection test failed.\n\n%s\n\nPress GREEN to edit the Portal URL and try again, or BLUE to finish setup later from Portal Manager.": {"ar":"فشل اختبار الاتصال.\n\n%s\n\nاضغط الأخضر لتعديل رابط البوابة وإعادة المحاولة، أو الأزرق لإكمال الإعداد لاحقًا من إدارة البوابات.","fr":"Échec du test de connexion.\n\n%s\n\nAppuyez sur VERT pour modifier l’URL du portail et réessayer, ou sur BLEU pour terminer plus tard depuis le Gestionnaire de portails.","tr":"Bağlantı testi başarısız.\n\n%s\n\nPortal URL’sini düzenleyip tekrar denemek için YEŞİL’e, kurulumu daha sonra Portal Yöneticisi’nden tamamlamak için MAVİ’ye basın."},
    "Connection timed out. Check the portal address, internet connection, and server availability.": {"ar":"انتهت مهلة الاتصال. تحقق من رابط البوابة والإنترنت وحالة الخادم.","fr":"Délai de connexion dépassé. Vérifiez l’adresse du portail, la connexion Internet et la disponibilité du serveur.","tr":"Bağlantı zaman aşımına uğradı. Portal adresini, internet bağlantısını ve sunucu durumunu kontrol edin."},
    "Connection worked, but the profile could not be saved: %s": {"ar":"نجح الاتصال لكن تعذر حفظ الملف الشخصي: %s","fr":"La connexion a réussi, mais le profil n’a pas pu être enregistré : %s","tr":"Bağlantı başarılı, ancak profil kaydedilemedi: %s"},
    "Enter a port number between 1024 and 65535.": {"ar":"أدخل رقم منفذ بين 1024 و65535.","fr":"Saisissez un numéro de port compris entre 1024 et 65535.","tr":"1024 ile 65535 arasında bir port numarası girin."},
    "EPG refresh budget": {"ar":"مهلة تحديث EPG","fr":"Budget d’actualisation EPG","tr":"EPG yenileme bütçesi"},
    "FILE ••••": {"ar":"ملف ••••","fr":"FICHIER ••••","tr":"DOSYA ••••"},
    "Image cache limit": {"ar":"حد ذاكرة الصور","fr":"Limite du cache d’images","tr":"Görsel önbellek limiti"},
    "Invalid port": {"ar":"منفذ غير صالح","fr":"Port invalide","tr":"Geçersiz port"},
    "Maximum search scan pages": {"ar":"أقصى عدد صفحات البحث","fr":"Nombre maximal de pages analysées","tr":"Azami arama tarama sayfası"},
    "Search time budget per portal": {"ar":"مهلة البحث لكل بوابة","fr":"Budget temps de recherche par portail","tr":"Portal başına arama süre bütçesi"},
    "Searching": {"ar":"جارٍ البحث","fr":"Recherche","tr":"Aranıyor"},
    "The MAC address is invalid. Use a format such as 00:1A:79:XX:XX:XX.": {"ar":"عنوان MAC غير صحيح. استخدم صيغة مثل 00:1A:79:XX:XX:XX.","fr":"L’adresse MAC est invalide. Utilisez un format tel que 00:1A:79:XX:XX:XX.","tr":"MAC adresi geçersiz. 00:1A:79:XX:XX:XX gibi bir biçim kullanın."},
    "The portal hostname could not be resolved. Check DNS/network settings and the portal address.": {"ar":"تعذر العثور على اسم خادم البوابة. تحقق من DNS والشبكة ورابط البوابة.","fr":"Le nom d’hôte du portail n’a pas pu être résolu. Vérifiez le DNS, le réseau et l’adresse du portail.","tr":"Portal ana makine adı çözümlenemedi. DNS/ağ ayarlarını ve portal adresini kontrol edin."},
    "The portal rejected authentication. Check the MAC address and whether the subscription is active.": {"ar":"رفضت البوابة بيانات الدخول. تحقق من عنوان MAC ومن أن الاشتراك نشط.","fr":"Le portail a refusé l’authentification. Vérifiez l’adresse MAC et que l’abonnement est actif.","tr":"Portal kimlik doğrulamayı reddetti. MAC adresini ve aboneliğin etkin olup olmadığını kontrol edin."},
    "The portal server could not be reached. Check the address, network, and whether the server is online.": {"ar":"تعذر الوصول إلى خادم البوابة. تحقق من الرابط والشبكة وأن الخادم يعمل.","fr":"Le serveur du portail est inaccessible. Vérifiez l’adresse, le réseau et que le serveur est en ligne.","tr":"Portal sunucusuna ulaşılamadı. Adresi, ağı ve sunucunun çevrimiçi olup olmadığını kontrol edin."},
    "TLS certificate validation failed. Verify the portal URL or adjust TLS mode later from Portal Manager.": {"ar":"فشل التحقق من شهادة TLS. تحقق من رابط البوابة أو عدّل وضع TLS لاحقًا من إدارة البوابات.","fr":"Échec de validation du certificat TLS. Vérifiez l’URL du portail ou ajustez le mode TLS plus tard dans le Gestionnaire de portails.","tr":"TLS sertifikası doğrulanamadı. Portal URL’sini kontrol edin veya TLS modunu daha sonra Portal Yöneticisi’nden ayarlayın."},
    "Ultra Stalker": {"ar":"Ultra Stalker","fr":"Ultra Stalker","tr":"Ultra Stalker"},
    "Ultra Stalker failed to start:\n\n%s": {"ar":"فشل تشغيل Ultra Stalker:\n\n%s","fr":"Échec du démarrage d’Ultra Stalker :\n\n%s","tr":"Ultra Stalker başlatılamadı:\n\n%s"},
    "Ultra Stalker requires Pillow for artwork and Adaptive UI.\n\nInstall the required runtime capability, then reopen the plugin.": {"ar":"يتطلب Ultra Stalker مكتبة Pillow للصور والواجهة التكيفية.\n\nثبّت المتطلب اللازم ثم أعد فتح الإضافة.","fr":"Ultra Stalker nécessite Pillow pour les illustrations et l’interface adaptative.\n\nInstallez le composant requis, puis rouvrez le plugin.","tr":"Ultra Stalker görseller ve Uyarlanabilir Arayüz için Pillow gerektirir.\n\nGerekli çalışma zamanı bileşenini kurup eklentiyi yeniden açın."},
    "Version: %s\nBuild: %s\nPython support: 3.12 / 3.13 / 3.14\nInterface: Full HD • Adaptive 3D Glass UI": {"ar":"الإصدار: %s\nالبنية: %s\nدعم Python: 3.12 / 3.13 / 3.14\nالواجهة: Full HD • Adaptive 3D Glass UI","fr":"Version : %s\nBuild : %s\nPython pris en charge : 3.12 / 3.13 / 3.14\nInterface : Full HD • Adaptive 3D Glass UI","tr":"Sürüm: %s\nYapı: %s\nPython desteği: 3.12 / 3.13 / 3.14\nArayüz: Full HD • Adaptive 3D Glass UI"},
})


_T.update({
    "%d season": {"ar":"%d موسم","fr":"%d saison","tr":"%d sezon"},
    "NOW / NEXT": {"ar":"الآن / التالي","fr":"MAINTENANT / SUIVANT","tr":"ŞİMDİ / SONRAKİ"},
    "AUTO": {"ar":"تلقائي","fr":"AUTO","tr":"OTOMATİK"},
    "LIVE": {"ar":"مباشر","fr":"DIRECT","tr":"CANLI"},
    "CHANNEL": {"ar":"القناة","fr":"CHAÎNE","tr":"KANAL"},
    "OK Preview": {"ar":"OK معاينة","fr":"OK Aperçu","tr":"OK Önizleme"},
    "Favorite": {"ar":"المفضلة","fr":"Favori","tr":"Favori"},
    "Previous page": {"ar":"الصفحة السابقة","fr":"Page précédente","tr":"Önceki sayfa"},
    "Next page": {"ar":"الصفحة التالية","fr":"Page suivante","tr":"Sonraki sayfa"},
    "Opening channel...": {"ar":"جارٍ فتح القناة...","fr":"Ouverture de la chaîne...","tr":"Kanal açılıyor..."},
    "Opening...": {"ar":"جارٍ الفتح...","fr":"Ouverture...","tr":"Açılıyor..."},
    "Loading preview...": {"ar":"جارٍ تحميل المعاينة...","fr":"Chargement de l’aperçu...","tr":"Önizleme yükleniyor..."},
    "Preview unavailable": {"ar":"المعاينة غير متاحة","fr":"Aperçu indisponible","tr":"Önizleme kullanılamıyor"},
    "Starting preview...": {"ar":"جارٍ بدء المعاينة...","fr":"Démarrage de l’aperçu...","tr":"Önizleme başlatılıyor..."},
    "Channel unavailable": {"ar":"القناة غير متاحة","fr":"Chaîne indisponible","tr":"Kanal kullanılamıyor"},
    "Preparing recording timer...": {"ar":"جارٍ تجهيز مؤقت التسجيل...","fr":"Préparation de la programmation d’enregistrement...","tr":"Kayıt zamanlayıcısı hazırlanıyor..."},
    "MENU: tools  •  OK: open / play": {"ar":"MENU: أدوات  •  OK: فتح / تشغيل","fr":"MENU : outils  •  OK : ouvrir / lire","tr":"MENU: araçlar  •  OK: aç / oynat"},
    "MENU: new search  •  BLUE: restore list": {"ar":"MENU: بحث جديد  •  الأزرق: استعادة القائمة","fr":"MENU : nouvelle recherche  •  BLEU : restaurer la liste","tr":"MENU: yeni arama  •  MAVİ: listeyi geri yükle"},
    "Continue Watching cleared": {"ar":"تم مسح متابعة المشاهدة","fr":"Continuer à regarder a été vidé","tr":"İzlemeye Devam listesi temizlendi"},
    "EPG is available for live channels": {"ar":"دليل EPG متاح للقنوات المباشرة","fr":"L’EPG est disponible pour les chaînes en direct","tr":"EPG canlı kanallar için kullanılabilir"},
    "Channel has no EPG identifier": {"ar":"لا يوجد معرّف EPG لهذه القناة","fr":"Cette chaîne n’a pas d’identifiant EPG","tr":"Kanalın EPG kimliği yok"},
    "Choose a programme": {"ar":"اختر برنامجًا","fr":"Choisissez un programme","tr":"Bir program seçin"},
    "Theme saved. Restart Enigma2 to apply": {"ar":"تم حفظ المظهر. أعد تشغيل Enigma2 لتطبيقه","fr":"Thème enregistré. Redémarrez Enigma2 pour l’appliquer","tr":"Tema kaydedildi. Uygulamak için Enigma2’yi yeniden başlatın"},
    "LEFT / RIGHT browse  •  OK open / play": {"ar":"LEFT / RIGHT للتصفح  •  OK فتح / تشغيل","fr":"GAUCHE / DROITE parcourir  •  OK ouvrir / lire","tr":"SOL / SAĞ gözat  •  OK aç / oynat"},
    "Picon cache is already running": {"ar":"تخزين Picon يعمل بالفعل","fr":"La mise en cache des picons est déjà en cours","tr":"Picon önbellekleme zaten çalışıyor"},
    "Scanning...": {"ar":"جارٍ الفحص...","fr":"Analyse...","tr":"Taranıyor..."},
    "Scanning Live categories...": {"ar":"جارٍ فحص أقسام البث المباشر...","fr":"Analyse des catégories Live...","tr":"Canlı kategoriler taranıyor..."},
    "Open a category list first": {"ar":"افتح قائمة أقسام أولًا","fr":"Ouvrez d’abord une liste de catégories","tr":"Önce bir kategori listesi açın"},
    "Section visibility updated": {"ar":"تم تحديث ظهور القسم","fr":"Visibilité de la section mise à jour","tr":"Bölüm görünürlüğü güncellendi"},
    "Open a category first": {"ar":"افتح قسمًا أولًا","fr":"Ouvrez d’abord une catégorie","tr":"Önce bir kategori açın"},
    "This category cannot be hidden": {"ar":"لا يمكن إخفاء هذا القسم","fr":"Cette catégorie ne peut pas être masquée","tr":"Bu kategori gizlenemez"},
    "Catch-up TV  /  Channels": {"ar":"Catch-up TV  /  القنوات","fr":"Catch-up TV  /  Chaînes","tr":"Catch-up TV  /  Kanallar"},
    "Channel has no archive identifier": {"ar":"لا يوجد معرّف أرشيف لهذه القناة","fr":"Cette chaîne n’a pas d’identifiant d’archive","tr":"Kanalın arşiv kimliği yok"},
    "Opening Ultra Stalker player...": {"ar":"جارٍ فتح مشغل Ultra Stalker...","fr":"Ouverture du lecteur Ultra Stalker...","tr":"Ultra Stalker oynatıcı açılıyor..."},
    "Portal returned an invalid catch-up link": {"ar":"أعاد الـPortal رابط Catch-up غير صالح","fr":"Le portail a renvoyé un lien Catch-up invalide","tr":"Portal geçersiz bir Catch-up bağlantısı döndürdü"},
    "Category folder": {"ar":"مجلد القسم","fr":"Dossier de catégorie","tr":"Kategori klasörü"},
    "Artwork + metadata cache cleaned": {"ar":"تم تنظيف كاش الصور والبيانات الوصفية","fr":"Cache des illustrations et métadonnées nettoyé","tr":"Görsel ve meta veri önbelleği temizlendi"},
    "Reloading external artwork...": {"ar":"جارٍ إعادة تحميل الصور الخارجية...","fr":"Rechargement des illustrations externes...","tr":"Harici görseller yeniden yükleniyor..."},
    "TMDb match unavailable": {"ar":"لا توجد مطابقة TMDb","fr":"Correspondance TMDb indisponible","tr":"TMDb eşleşmesi kullanılamıyor"},
    "Portal metadata • external match ignored": {"ar":"بيانات الـPortal • تم تجاهل المطابقة الخارجية","fr":"Métadonnées du portail • correspondance externe ignorée","tr":"Portal meta verisi • harici eşleşme yok sayıldı"},
    "Home Hero not set • backdrop is not ready yet": {"ar":"لم يتم تثبيت Home Hero • الـBackdrop غير جاهز بعد","fr":"Home Hero non défini • le backdrop n’est pas encore prêt","tr":"Home Hero ayarlanmadı • backdrop henüz hazır değil"},
    "Home Hero pinned • stays fixed until you choose another": {"ar":"تم تثبيت Home Hero • سيظل ثابتًا حتى تختار غيره","fr":"Home Hero épinglé • reste fixe jusqu’à votre prochain choix","tr":"Home Hero sabitlendi • başka birini seçene kadar değişmez"},
    "Cached • HDD": {"ar":"محفوظ • HDD","fr":"En cache • HDD","tr":"Önbellekte • HDD"},
    "Home Hero not set • backdrop could not be prepared": {"ar":"لم يتم تثبيت Home Hero • تعذر تجهيز الـBackdrop","fr":"Home Hero non défini • impossible de préparer le backdrop","tr":"Home Hero ayarlanmadı • backdrop hazırlanamadı"},
    "Backdrop ready • HDD": {"ar":"الـBackdrop جاهز • HDD","fr":"Backdrop prêt • HDD","tr":"Backdrop hazır • HDD"},
    "Support bundle": {"ar":"حزمة الدعم","fr":"Paquet de support","tr":"Destek paketi"},
    "Live TV • reopen channel": {"ar":"البث المباشر • إعادة فتح القناة","fr":"TV en direct • rouvrir la chaîne","tr":"Canlı TV • kanalı yeniden aç"},
    "Exporting full Live bouquet...": {"ar":"جارٍ تصدير باقة البث المباشر كاملة...","fr":"Export du bouquet Live complet...","tr":"Tam Canlı buketi dışa aktarılıyor..."},
    "TLS security preference saved": {"ar":"تم حفظ إعداد أمان TLS","fr":"Préférence de sécurité TLS enregistrée","tr":"TLS güvenlik tercihi kaydedildi"},
    "HTTP fallback disabled by hardened build": {"ar":"تم تعطيل الرجوع إلى HTTP في هذه البنية المحمية","fr":"Repli HTTP désactivé par cette build renforcée","tr":"HTTP geri dönüşü güçlendirilmiş yapıda devre dışı"},
    "HTTP portal update cancelled": {"ar":"تم إلغاء تحديث Portal عبر HTTP","fr":"Mise à jour du portail HTTP annulée","tr":"HTTP portal güncellemesi iptal edildi"},
    "M3U source updated": {"ar":"تم تحديث مصدر M3U","fr":"Source M3U mise à jour","tr":"M3U kaynağı güncellendi"},
    "HTTP source was not added": {"ar":"لم تتم إضافة مصدر HTTP","fr":"La source HTTP n’a pas été ajoutée","tr":"HTTP kaynağı eklenmedi"},
    "Enter MAC for Stalker portal": {"ar":"أدخل MAC لـStalker Portal","fr":"Saisissez le MAC du portail Stalker","tr":"Stalker portalı için MAC girin"},
    "HTTP portal was not opened": {"ar":"لم يتم فتح Portal عبر HTTP","fr":"Le portail HTTP n’a pas été ouvert","tr":"HTTP portalı açılmadı"},
    "Opening M3U playlist…": {"ar":"جارٍ فتح قائمة M3U…","fr":"Ouverture de la playlist M3U…","tr":"M3U oynatma listesi açılıyor…"},
    "Bouquet export failed: dynamic proxy is not running": {"ar":"فشل تصدير الباقة: البروكسي الديناميكي لا يعمل","fr":"Échec de l’export du bouquet : le proxy dynamique n’est pas actif","tr":"Buket dışa aktarılamadı: dinamik proxy çalışmıyor"},
    "Portal data cleared; portal profile kept": {"ar":"تم مسح بيانات الـPortal مع الاحتفاظ بملفه","fr":"Données du portail effacées ; profil conservé","tr":"Portal verisi temizlendi; portal profili korundu"},
    "Stalker portal detected": {"ar":"تم اكتشاف Stalker Portal","fr":"Portail Stalker détecté","tr":"Stalker portalı algılandı"},
    "TLS verification is locked to strict mode in this hardened build": {"ar":"التحقق من TLS مثبت على الوضع الصارم في هذه البنية المحمية","fr":"La vérification TLS est verrouillée en mode strict dans cette build renforcée","tr":"TLS doğrulaması bu güçlendirilmiş yapıda katı moda kilitlidir"},
    "HTTP fallback is disabled in this hardened build": {"ar":"الرجوع إلى HTTP معطل في هذه البنية المحمية","fr":"Le repli HTTP est désactivé dans cette build renforcée","tr":"HTTP geri dönüşü bu güçlendirilmiş yapıda devre dışıdır"},
    "Exported bouquet and EPG removed": {"ar":"تم حذف الباقة وEPG المصدّرين","fr":"Bouquet et EPG exportés supprimés","tr":"Dışa aktarılan buket ve EPG kaldırıldı"},
    "Current Artwork • opening current source catalog...": {"ar":"الصور الحالية • جارٍ فتح كتالوج المصدر الحالي...","fr":"Illustrations actuelles • ouverture du catalogue de la source...","tr":"Mevcut Görseller • geçerli kaynak kataloğu açılıyor..."},
    "Creating backup…": {"ar":"جارٍ إنشاء النسخة الاحتياطية…","fr":"Création de la sauvegarde…","tr":"Yedek oluşturuluyor…"},
    "Validating and restoring backup…": {"ar":"جارٍ التحقق من النسخة الاحتياطية واستعادتها…","fr":"Validation et restauration de la sauvegarde…","tr":"Yedek doğrulanıyor ve geri yükleniyor…"},
    "Current Artwork preload is already running": {"ar":"تحميل الصور الحالية مسبقًا يعمل بالفعل","fr":"Le préchargement des illustrations actuelles est déjà en cours","tr":"Mevcut görsel ön yükleme zaten çalışıyor"},
    "Current Artwork preload cancelled": {"ar":"تم إلغاء التحميل المسبق للصور الحالية","fr":"Préchargement des illustrations actuelles annulé","tr":"Mevcut görsel ön yükleme iptal edildi"},
    "Artwork + metadata cache cleared": {"ar":"تم مسح كاش الصور والبيانات الوصفية","fr":"Cache des illustrations et métadonnées vidé","tr":"Görsel ve meta veri önbelleği temizlendi"},
    "Series information will appear here": {"ar":"ستظهر معلومات المسلسل هنا","fr":"Les informations de la série apparaîtront ici","tr":"Dizi bilgileri burada görünecek"},
    "EPISODES  %s": {"ar":"الحلقات  %s","fr":"ÉPISODES  %s","tr":"BÖLÜMLER  %s"},
    "YEAR  %s": {"ar":"السنة  %s","fr":"ANNÉE  %s","tr":"YIL  %s"},
    "Season %s": {"ar":"الموسم %s","fr":"Saison %s","tr":"Sezon %s"},
    "%d EPISODES": {"ar":"%d حلقة","fr":"%d ÉPISODES","tr":"%d BÖLÜM"},
    "Ready to browse": {"ar":"جاهز للتصفح","fr":"Prêt à parcourir","tr":"Gözatmaya hazır"},
    "SELECTED": {"ar":"محدد","fr":"SÉLECTIONNÉ","tr":"SEÇİLİ"},
    "No seasons returned": {"ar":"لم يتم العثور على مواسم","fr":"Aucune saison renvoyée","tr":"Sezon bulunamadı"},
    "Episode %s": {"ar":"الحلقة %s","fr":"Épisode %s","tr":"Bölüm %s"},
    "WATCHED": {"ar":"تمت المشاهدة","fr":"VU","tr":"İZLENDİ"},
    "CONTINUE": {"ar":"متابعة","fr":"CONTINUER","tr":"DEVAM"},
    "No episodes returned": {"ar":"لم يتم العثور على حلقات","fr":"Aucun épisode renvoyé","tr":"Bölüm bulunamadı"},
})


_T.update({'Choose an option': {'ar': 'اختر خيارًا', 'fr': 'Choisissez une option', 'tr': 'Bir seçenek seçin'},
 'Current source': {'ar': 'المصدر الحالي', 'fr': 'Source actuelle', 'tr': 'Geçerli kaynak'},
 '%d/%d READY': {'ar': '%d/%d جاهز', 'fr': '%d/%d PRÊT', 'tr': '%d/%d HAZIR'},
 ' • %d MISS': {'ar': ' • %d ناقص', 'fr': ' • %d MANQUANT', 'tr': ' • %d EKSİK'},
 'Current Artwork • %s • %s categories %d/%d • %d titles counted': {'ar': 'الصور الحالية • %s • أقسام %s %d/%d • تم عدّ %d عنوان',
                                                                    'fr': 'Illustrations actuelles • %s • catégories %s %d/%d • %d titres comptés',
                                                                    'tr': 'Mevcut Görseller • %s • %s kategorileri %d/%d • %d başlık sayıldı'},
 'Current Artwork • %s • %s • reading %s page %d • %d titles counted': {'ar': 'الصور الحالية • %s • %s • قراءة %s الصفحة %d • تم عدّ %d عنوان',
                                                                        'fr': 'Illustrations actuelles • %s • %s • lecture de %s page %d • %d titres comptés',
                                                                        'tr': 'Mevcut Görseller • %s • %s • %s sayfa %d okunuyor • %d başlık sayıldı'},
 'Current Artwork • %s • %s catalog pages %d/%d • %d/%d titles counted': {'ar': 'الصور الحالية • %s • كتالوج %s الصفحات %d/%d • تم عدّ %d/%d عنوان',
                                                                          'fr': 'Illustrations actuelles • %s • catalogue %s pages %d/%d • %d/%d titres comptés',
                                                                          'tr': 'Mevcut Görseller • %s • %s kataloğu sayfalar %d/%d • %d/%d başlık sayıldı'},
 'Current Artwork • %s • %s catalog page %d • %d titles counted': {'ar': 'الصور الحالية • %s • كتالوج %s الصفحة %d • تم عدّ %d عنوان',
                                                                   'fr': 'Illustrations actuelles • %s • catalogue %s page %d • %d titres comptés',
                                                                   'tr': 'Mevcut Görseller • %s • %s kataloğu sayfa %d • %d başlık sayıldı'},
 ' • page %d/%d': {'ar': ' • الصفحة %d/%d', 'fr': ' • page %d/%d', 'tr': ' • sayfa %d/%d'},
 ' • page %d': {'ar': ' • الصفحة %d', 'fr': ' • page %d', 'tr': ' • sayfa %d'},
 'Current Artwork • %s • %s categories %d/%d%s • %d titles counted': {'ar': 'الصور الحالية • %s • أقسام %s %d/%d%s • تم عدّ %d عنوان',
                                                                      'fr': 'Illustrations actuelles • %s • catégories %s %d/%d%s • %d titres comptés',
                                                                      'tr': 'Mevcut Görseller • %s • %s kategorileri %d/%d%s • %d başlık sayıldı'},
 'Current Artwork • HDD check %d/%d • Ready %d • Need work %d': {'ar': 'الصور الحالية • فحص HDD %d/%d • جاهز %d • يحتاج تجهيز %d',
                                                                 'fr': 'Illustrations actuelles • vérification HDD %d/%d • prêtes %d • à préparer %d',
                                                                 'tr': 'Mevcut Görseller • HDD kontrolü %d/%d • Hazır %d • İşlem gerekli %d'},
 'Current Artwork • Total %d • Ready on HDD %d • Need work %d': {'ar': 'الصور الحالية • الإجمالي %d • جاهز على HDD %d • يحتاج تجهيز %d',
                                                                 'fr': 'Illustrations actuelles • total %d • prêtes sur HDD %d • à préparer %d',
                                                                 'tr': "Mevcut Görseller • Toplam %d • HDD'de hazır %d • İşlem gerekli %d"},
 'Current Artwork • %d/%d processed • Already ready %d • Downloaded %d • Local build %d • Remaining %d • Unavailable %d': {'ar': 'الصور الحالية • تمت معالجة %d/%d • جاهز مسبقًا %d • تم تنزيله %d • تجهيز محلي %d • متبقٍ %d • غير متاح %d',
                                                                                                                           'fr': 'Illustrations actuelles • %d/%d traitées • déjà prêtes %d • téléchargées %d • générées localement %d • '
                                                                                                                                 'restantes %d • indisponibles %d',
                                                                                                                           'tr': 'Mevcut Görseller • %d/%d işlendi • Önceden hazır %d • İndirilen %d • Yerel oluşturma %d • Kalan %d • '
                                                                                                                                 'Kullanılamayan %d'},
 'Current Artwork already ready • checked %d/%d • everything is on HDD • 0 remaining': {'ar': 'الصور الحالية جاهزة بالفعل • تم فحص %d/%d • كل شيء على HDD • المتبقي 0',
                                                                                        'fr': 'Illustrations actuelles déjà prêtes • %d/%d vérifiées • tout est sur HDD • 0 restante',
                                                                                        'tr': "Mevcut Görseller zaten hazır • %d/%d kontrol edildi • her şey HDD'de • kalan 0"},
 'Current Artwork ready • %d/%d on HDD • %d already ready • %d downloaded • %d local builds • 0 remaining': {'ar': 'الصور الحالية جاهزة • %d/%d على HDD • جاهز مسبقًا %d • تم تنزيله %d • تجهيز محلي %d • المتبقي 0',
                                                                                                             'fr': 'Illustrations actuelles prêtes • %d/%d sur HDD • %d déjà prêtes • %d téléchargées • %d générées localement • 0 restante',
                                                                                                             'tr': "Mevcut Görseller hazır • %d/%d HDD'de • %d önceden hazır • %d indirildi • %d yerel oluşturuldu • kalan 0"},
 'Current Artwork finished • %d/%d ready • %d downloaded • %d local builds • %d unavailable': {'ar': 'اكتملت الصور الحالية • جاهز %d/%d • تم تنزيله %d • تجهيز محلي %d • غير متاح %d',
                                                                                               'fr': 'Illustrations actuelles terminées • %d/%d prêtes • %d téléchargées • %d générées localement • %d indisponibles',
                                                                                               'tr': 'Mevcut Görseller tamamlandı • %d/%d hazır • %d indirildi • %d yerel oluşturuldu • %d kullanılamıyor'},
 'Current Artwork failed: %s': {'ar': 'فشل تجهيز الصور الحالية: %s', 'fr': 'Échec des illustrations actuelles : %s', 'tr': 'Mevcut Görseller başarısız: %s'},
 '%s   •   Current: %s   •   ARROWS Navigate   •   OK Select   •   BACK Home': {'ar': '%s   •   الحالي: %s   •   الأسهم للتنقل   •   OK اختيار   •   BACK الرئيسية',
                                                                                'fr': '%s   •   Actuel : %s   •   FLÈCHES Naviguer   •   OK Sélectionner   •   BACK Accueil',
                                                                                'tr': '%s   •   Geçerli: %s   •   OKLAR Gezin   •   OK Seç   •   BACK Ana Sayfa'},
 'HIDE': {'ar': 'إخفاء', 'fr': 'MASQUER', 'tr': 'GİZLE'},
 'PIN': {'ar': 'PIN', 'fr': 'PIN', 'tr': 'PIN'},
 'EPG': {'ar': 'EPG', 'fr': 'EPG', 'tr': 'EPG'},
 'COMPACT': {'ar': 'مدمج', 'fr': 'COMPACT', 'tr': 'KOMPAKT'},
 'LARGE': {'ar': 'كبير', 'fr': 'GRAND', 'tr': 'BÜYÜK'},
 'ASK': {'ar': 'اسأل', 'fr': 'DEMANDER', 'tr': 'SOR'},
 'ALWAYS': {'ar': 'دائمًا', 'fr': 'TOUJOURS', 'tr': 'HER ZAMAN'},
 'FROM START': {'ar': 'من البداية', 'fr': 'DEPUIS LE DÉBUT', 'tr': 'BAŞTAN'},
 'Playback engine': {'ar': 'محرك التشغيل', 'fr': 'Moteur de lecture', 'tr': 'Oynatma motoru'},
 'Choose the Enigma2 playback service': {'ar': 'اختر خدمة تشغيل Enigma2', 'fr': 'Choisissez le service de lecture Enigma2', 'tr': 'Enigma2 oynatma hizmetini seçin'},
 'Playback is locked to the engine selected in Playback Engine. Smart Engine and per-title engine switching are disabled.': {'ar': 'التشغيل مثبت على المحرك المحدد في محرك التشغيل. تم تعطيل Smart Engine والتبديل حسب العنوان.',
                                                                                                                             'fr': 'La lecture est verrouillée sur le moteur choisi dans Moteur de lecture. Smart Engine et le changement par '
                                                                                                                                   'titre sont désactivés.',
                                                                                                                             'tr': "Oynatma, Oynatma Motoru'nda seçilen motora kilitlidir. Smart Engine ve başlık bazlı motor geçişi devre "
                                                                                                                                   'dışıdır.'},
 'Both views read the same single Global TMDB Library record': {'ar': 'كلا العرضين يقرآن نفس سجل مكتبة TMDB العالمية',
                                                                'fr': 'Les deux vues lisent le même enregistrement de la bibliothèque TMDB globale',
                                                                'tr': 'Her iki görünüm de aynı Global TMDB Library kaydını okur'},
 'Poster Grid': {'ar': 'شبكة البوسترات', 'fr': 'Grille d’affiches', 'tr': 'Poster Izgarası'},
 'Portal timeout': {'ar': 'مهلة اتصال Portal', 'fr': 'Délai du portail', 'tr': 'Portal zaman aşımı'},
 'Resume behavior': {'ar': 'سلوك استكمال المشاهدة', 'fr': 'Comportement de reprise', 'tr': 'Devam etme davranışı'},
 'Ask every time': {'ar': 'اسأل في كل مرة', 'fr': 'Demander à chaque fois', 'tr': 'Her seferinde sor'},
 'Always resume': {'ar': 'استكمل دائمًا', 'fr': 'Toujours reprendre', 'tr': 'Her zaman devam et'},
 'Always start from beginning': {'ar': 'ابدأ دائمًا من البداية', 'fr': 'Toujours recommencer depuis le début', 'tr': 'Her zaman baştan başla'},
 'Progress save interval': {'ar': 'فاصل حفظ التقدم', 'fr': 'Intervalle d’enregistrement de la progression', 'tr': 'İlerleme kayıt aralığı'},
 'Next episode countdown': {'ar': 'العد التنازلي للحلقة التالية', 'fr': 'Compte à rebours du prochain épisode', 'tr': 'Sonraki bölüm geri sayımı'},
 'Completion threshold': {'ar': 'نسبة اكتمال المشاهدة', 'fr': 'Seuil de fin', 'tr': 'Tamamlama eşiği'},
 'Completion remaining time': {'ar': 'الوقت المتبقي للاكتمال', 'fr': 'Temps restant avant fin', 'tr': 'Tamamlanma için kalan süre'},
 '%d hours': {'ar': '%d ساعة', 'fr': '%d heures', 'tr': '%d saat'},
 'EPG window': {'ar': 'نطاق EPG', 'fr': 'Fenêtre EPG', 'tr': 'EPG aralığı'},
 'Catch-up history': {'ar': 'سجل Catch-up', 'fr': 'Historique Catch-up', 'tr': 'Catch-up geçmişi'},
 'Choose ON or OFF': {'ar': 'اختر تشغيل أو إيقاف', 'fr': 'Choisissez ACTIVÉ ou DÉSACTIVÉ', 'tr': 'AÇIK veya KAPALI seçin'},
 'Image cache limit': {'ar': 'حد كاش الصور', 'fr': 'Limite du cache d’images', 'tr': 'Görsel önbellek limiti'},
 'Download disk safety reserve': {'ar': 'المساحة الاحتياطية الآمنة للتنزيل', 'fr': 'Réserve de sécurité du disque pour les téléchargements', 'tr': 'İndirme disk güvenlik payı'},
 'Search results per portal': {'ar': 'نتائج البحث لكل Portal', 'fr': 'Résultats de recherche par portail', 'tr': 'Portal başına arama sonucu'},
 'Smart Recovery retries': {'ar': 'محاولات Smart Recovery', 'fr': 'Tentatives Smart Recovery', 'tr': 'Smart Recovery denemeleri'},
 'Parental mode': {'ar': 'وضع الرقابة الأبوية', 'fr': 'Mode parental', 'tr': 'Ebeveyn modu'},
 'PIN protect': {'ar': 'حماية بـPIN', 'fr': 'Protéger par PIN', 'tr': 'PIN ile koru'},
 'Hide sensitive categories': {'ar': 'إخفاء الأقسام الحساسة', 'fr': 'Masquer les catégories sensibles', 'tr': 'Hassas kategorileri gizle'},
 'Parental unlock duration': {'ar': 'مدة فتح الرقابة الأبوية', 'fr': 'Durée du déverrouillage parental', 'tr': 'Ebeveyn kilidi açma süresi'},
 'One action': {'ar': 'إجراء واحد', 'fr': 'Une action', 'tr': 'Tek işlem'},
 '15 minutes': {'ar': '15 دقيقة', 'fr': '15 minutes', 'tr': '15 dakika'},
 '30 minutes': {'ar': '30 دقيقة', 'fr': '30 minutes', 'tr': '30 dakika'},
 '60 minutes': {'ar': '60 دقيقة', 'fr': '60 minutes', 'tr': '60 dakika'},
 '120 minutes': {'ar': '120 دقيقة', 'fr': '120 minutes', 'tr': '120 dakika'},
 'Adult keywords (comma separated)': {'ar': 'كلمات المحتوى الحساس (مفصولة بفواصل)', 'fr': 'Mots-clés sensibles (séparés par des virgules)', 'tr': 'Yetişkin içerik anahtar kelimeleri (virgülle ayrılmış)'},
 'New parental PIN (4-8 digits)': {'ar': 'PIN أبوي جديد (4-8 أرقام)', 'fr': 'Nouveau PIN parental (4 à 8 chiffres)', 'tr': "Yeni ebeveyn PIN'i (4-8 rakam)"},
 'Channel list layout': {'ar': 'تخطيط قائمة القنوات', 'fr': 'Disposition de la liste des chaînes', 'tr': 'Kanal listesi düzeni'},
 'Professional EPG': {'ar': 'EPG احترافي', 'fr': 'EPG professionnel', 'tr': 'Profesyonel EPG'},
 'Compact': {'ar': 'مدمج', 'fr': 'Compact', 'tr': 'Kompakt'},
 'Large': {'ar': 'كبير', 'fr': 'Grand', 'tr': 'Büyük'},
 'API Keys': {'ar': 'مفاتيح API', 'fr': 'Clés API', 'tr': 'API Anahtarları'},
 'Put long credentials in:\n/etc/enigma2/ultrastalker/api_keys.conf\n\nTMDB_API_KEY=...\nTMDB_READ_TOKEN=...\nIMDB_API_KEY=...\nIMDB_API_ENDPOINT=... (generic mode)\nSUBDL_API_KEY=...\n\nOfficial IMDb/AWS Data Exchange:\nIMDB_ACCESS_KEY_ID=...\nIMDB_SECRET_ACCESS_KEY=...\nIMDB_SESSION_TOKEN=... (optional)\nIMDB_REGION=us-east-1\nIMDB_DATASET_ID=...\nIMDB_REVISION_ID=...\nIMDB_ASSET_ID=...': {'ar': 'ضع '
                                                                                                                                                                                                                                                                                                                                                                                                                 'بيانات '
                                                                                                                                                                                                                                                                                                                                                                                                                 'الاعتماد '
                                                                                                                                                                                                                                                                                                                                                                                                                 'الطويلة '
                                                                                                                                                                                                                                                                                                                                                                                                                 'في:\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 '/etc/enigma2/ultrastalker/api_keys.conf\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'TMDB_API_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'TMDB_READ_TOKEN=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_API_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_API_ENDPOINT=... '
                                                                                                                                                                                                                                                                                                                                                                                                                 '(الوضع '
                                                                                                                                                                                                                                                                                                                                                                                                                 'العام)\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'SUBDL_API_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDb/AWS '
                                                                                                                                                                                                                                                                                                                                                                                                                 'Data '
                                                                                                                                                                                                                                                                                                                                                                                                                 'Exchange '
                                                                                                                                                                                                                                                                                                                                                                                                                 'الرسمي:\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_ACCESS_KEY_ID=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_SECRET_ACCESS_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_SESSION_TOKEN=... '
                                                                                                                                                                                                                                                                                                                                                                                                                 '(اختياري)\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_REGION=us-east-1\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_DATASET_ID=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_REVISION_ID=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_ASSET_ID=...',
                                                                                                                                                                                                                                                                                                                                                                                                           'fr': 'Placez '
                                                                                                                                                                                                                                                                                                                                                                                                                 'les '
                                                                                                                                                                                                                                                                                                                                                                                                                 'identifiants '
                                                                                                                                                                                                                                                                                                                                                                                                                 'longs '
                                                                                                                                                                                                                                                                                                                                                                                                                 'dans '
                                                                                                                                                                                                                                                                                                                                                                                                                 ':\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 '/etc/enigma2/ultrastalker/api_keys.conf\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'TMDB_API_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'TMDB_READ_TOKEN=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_API_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_API_ENDPOINT=... '
                                                                                                                                                                                                                                                                                                                                                                                                                 '(mode '
                                                                                                                                                                                                                                                                                                                                                                                                                 'générique)\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'SUBDL_API_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDb/AWS '
                                                                                                                                                                                                                                                                                                                                                                                                                 'Data '
                                                                                                                                                                                                                                                                                                                                                                                                                 'Exchange '
                                                                                                                                                                                                                                                                                                                                                                                                                 'officiel '
                                                                                                                                                                                                                                                                                                                                                                                                                 ':\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_ACCESS_KEY_ID=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_SECRET_ACCESS_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_SESSION_TOKEN=... '
                                                                                                                                                                                                                                                                                                                                                                                                                 '(facultatif)\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_REGION=us-east-1\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_DATASET_ID=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_REVISION_ID=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_ASSET_ID=...',
                                                                                                                                                                                                                                                                                                                                                                                                           'tr': 'Uzun '
                                                                                                                                                                                                                                                                                                                                                                                                                 'kimlik '
                                                                                                                                                                                                                                                                                                                                                                                                                 'bilgilerini '
                                                                                                                                                                                                                                                                                                                                                                                                                 'şuraya '
                                                                                                                                                                                                                                                                                                                                                                                                                 'yazın:\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 '/etc/enigma2/ultrastalker/api_keys.conf\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'TMDB_API_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'TMDB_READ_TOKEN=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_API_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_API_ENDPOINT=... '
                                                                                                                                                                                                                                                                                                                                                                                                                 '(genel '
                                                                                                                                                                                                                                                                                                                                                                                                                 'mod)\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'SUBDL_API_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'Resmî '
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDb/AWS '
                                                                                                                                                                                                                                                                                                                                                                                                                 'Data '
                                                                                                                                                                                                                                                                                                                                                                                                                 'Exchange:\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_ACCESS_KEY_ID=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_SECRET_ACCESS_KEY=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_SESSION_TOKEN=... '
                                                                                                                                                                                                                                                                                                                                                                                                                 '(isteğe '
                                                                                                                                                                                                                                                                                                                                                                                                                 'bağlı)\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_REGION=us-east-1\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_DATASET_ID=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_REVISION_ID=...\n'
                                                                                                                                                                                                                                                                                                                                                                                                                 'IMDB_ASSET_ID=...'},
 'TMDB API key or Read Access Token': {'ar': 'مفتاح TMDB API أو Read Access Token', 'fr': 'Clé API TMDB ou Read Access Token', 'tr': 'TMDB API anahtarı veya Read Access Token'},
 'TMDB metadata language': {'ar': 'لغة بيانات TMDB', 'fr': 'Langue des métadonnées TMDB', 'tr': 'TMDB meta veri dili'},
 'Arabic (Egypt)': {'ar': 'العربية (مصر)', 'fr': 'Arabe (Égypte)', 'tr': 'Arapça (Mısır)'},
 'English (US)': {'ar': 'الإنجليزية (الولايات المتحدة)', 'fr': 'Anglais (États-Unis)', 'tr': 'İngilizce (ABD)'},
 'SubDL API key': {'ar': 'مفتاح SubDL API', 'fr': 'Clé API SubDL', 'tr': 'SubDL API anahtarı'},
 'TMDB': {'ar': 'TMDB', 'fr': 'TMDB', 'tr': 'TMDB'},
 'Add a TMDB API key or Read Access Token first.': {'ar': 'أضف مفتاح TMDB API أو Read Access Token أولًا.',
                                                    'fr': 'Ajoutez d’abord une clé API TMDB ou un Read Access Token.',
                                                    'tr': 'Önce bir TMDB API anahtarı veya Read Access Token ekleyin.'},
 'TMDB connection successful.': {'ar': 'تم الاتصال بـTMDB بنجاح.', 'fr': 'Connexion TMDB réussie.', 'tr': 'TMDB bağlantısı başarılı.'},
 'TMDB test failed: %s': {'ar': 'فشل اختبار TMDB: %s', 'fr': 'Échec du test TMDB : %s', 'tr': 'TMDB testi başarısız: %s'},
 'TMDB Metadata': {'ar': 'بيانات TMDB', 'fr': 'Métadonnées TMDB', 'tr': 'TMDB Meta Verisi'},
 'This product uses the TMDB API but is not endorsed or certified by TMDB.\n\nTMDB data/images are used only when you configure your own credential.': {'ar': 'يستخدم هذا المنتج TMDB API لكنه غير معتمد أو مصدّق من TMDB.\n'
                                                                                                                                                              '\n'
                                                                                                                                                              'تُستخدم بيانات وصور TMDB فقط عند إعداد بيانات الاعتماد الخاصة بك.',
                                                                                                                                                        'fr': 'Ce produit utilise l’API TMDB, mais n’est ni approuvé ni certifié par TMDB.\n'
                                                                                                                                                              '\n'
                                                                                                                                                              'Les données et images TMDB ne sont utilisées que si vous configurez vos propres '
                                                                                                                                                              'identifiants.',
                                                                                                                                                        'tr': "Bu ürün TMDB API'sini kullanır ancak TMDB tarafından desteklenmez veya "
                                                                                                                                                              'sertifikalandırılmaz.\n'
                                                                                                                                                              '\n'
                                                                                                                                                              'TMDB verileri/görselleri yalnızca kendi kimlik bilginizi yapılandırdığınızda '
                                                                                                                                                              'kullanılır.'},
 'Web Cleaner Access': {'ar': 'الوصول إلى Web Cleaner', 'fr': 'Accès Web Cleaner', 'tr': 'Web Cleaner Erişimi'},
 'Choose how devices on your network open Web Cleaner': {'ar': 'اختر طريقة فتح أجهزة شبكتك لـWeb Cleaner',
                                                         'fr': 'Choisissez comment les appareils de votre réseau ouvrent Web Cleaner',
                                                         'tr': "Ağınızdaki cihazların Web Cleaner'ı nasıl açacağını seçin"},
 'Easy - LAN direct': {'ar': 'سهل - دخول مباشر عبر LAN', 'fr': 'Simple - accès LAN direct', 'tr': 'Kolay - doğrudan LAN'},
 'Protected - PIN / QR': {'ar': 'محمي - PIN / QR', 'fr': 'Protégé - PIN / QR', 'tr': 'Korumalı - PIN / QR'},
 'Easy LAN access': {'ar': 'دخول سهل عبر LAN', 'fr': 'Accès LAN simple', 'tr': 'Kolay LAN erişimi'},
 'PIN / QR protected': {'ar': 'محمي بـPIN / QR', 'fr': 'Protégé par PIN / QR', 'tr': 'PIN / QR korumalı'},
 'Premium Cleaner + Deep Check • %s': {'ar': 'Premium Cleaner + Deep Check • %s', 'fr': 'Premium Cleaner + Deep Check • %s', 'tr': 'Premium Cleaner + Deep Check • %s'},
 'Start / Show Link': {'ar': 'بدء / عرض الرابط', 'fr': 'Démarrer / Afficher le lien', 'tr': 'Başlat / Bağlantıyı Göster'},
 'Stop Service': {'ar': 'إيقاف الخدمة', 'fr': 'Arrêter le service', 'tr': 'Hizmeti Durdur'},
 'STOPPED': {'ar': 'متوقف', 'fr': 'ARRÊTÉ', 'tr': 'DURDU'},
 'RUNNING EASY :7725': {'ar': 'يعمل EASY :7725', 'fr': 'ACTIF EASY :7725', 'tr': 'ÇALIŞIYOR EASY :7725'},
 'RUNNING PIN :7725': {'ar': 'يعمل PIN :7725', 'fr': 'ACTIF PIN :7725', 'tr': 'ÇALIŞIYOR PIN :7725'},
 'Web Cleaner access: %s%s': {'ar': 'وصول Web Cleaner: %s%s', 'fr': 'Accès Web Cleaner : %s%s', 'tr': 'Web Cleaner erişimi: %s%s'},
 ' • service stopped; start again': {'ar': ' • تم إيقاف الخدمة؛ ابدأها من جديد', 'fr': ' • service arrêté ; redémarrez-le', 'tr': ' • hizmet durduruldu; yeniden başlatın'},
 'Service stopped. Port 7725 is closed.': {'ar': 'تم إيقاف الخدمة. المنفذ 7725 مغلق.', 'fr': 'Service arrêté. Le port 7725 est fermé.', 'tr': 'Hizmet durduruldu. 7725 portu kapalı.'},
 'Could not start Web Cleaner:\n%s': {'ar': 'تعذر تشغيل Web Cleaner:\n%s', 'fr': 'Impossible de démarrer Web Cleaner :\n%s', 'tr': 'Web Cleaner başlatılamadı:\n%s'},
 'Setting saved': {'ar': 'تم حفظ الإعداد', 'fr': 'Paramètre enregistré', 'tr': 'Ayar kaydedildi'},
 'PIN must contain 4-8 digits': {'ar': 'يجب أن يحتوي PIN على 4 إلى 8 أرقام', 'fr': 'Le PIN doit contenir de 4 à 8 chiffres', 'tr': 'PIN 4-8 rakam içermelidir'},
 'Backup & Restore': {'ar': 'النسخ الاحتياطي والاستعادة', 'fr': 'Sauvegarde et restauration', 'tr': 'Yedekleme ve Geri Yükleme'},
 'Choose a backup or restore action': {'ar': 'اختر إجراء نسخ احتياطي أو استعادة', 'fr': 'Choisissez une action de sauvegarde ou de restauration', 'tr': 'Bir yedekleme veya geri yükleme işlemi seçin'},
 'Backup API Secrets': {'ar': 'نسخ أسرار API احتياطيًا', 'fr': 'Sauvegarder les secrets API', 'tr': 'API Gizli Bilgilerini Yedekle'},
 'No backups found in /etc/enigma2/ultrastalker/backups or /tmp.': {'ar': 'لم يتم العثور على نسخ احتياطية في /etc/enigma2/ultrastalker/backups أو /tmp.',
                                                                    'fr': 'Aucune sauvegarde trouvée dans /etc/enigma2/ultrastalker/backups ou /tmp.',
                                                                    'tr': '/etc/enigma2/ultrastalker/backups veya /tmp içinde yedek bulunamadı.'},
 'Choose backup to restore': {'ar': 'اختر نسخة احتياطية للاستعادة', 'fr': 'Choisissez la sauvegarde à restaurer', 'tr': 'Geri yüklenecek yedeği seçin'},
 'Available Ultra Stalker backups': {'ar': 'نسخ Ultra Stalker الاحتياطية المتاحة', 'fr': 'Sauvegardes Ultra Stalker disponibles', 'tr': 'Kullanılabilir Ultra Stalker yedekleri'},
 'Backup: %s': {'ar': 'النسخة الاحتياطية: %s', 'fr': 'Sauvegarde : %s', 'tr': 'Yedek: %s'},
 'Backup Created': {'ar': 'تم إنشاء النسخة الاحتياطية', 'fr': 'Sauvegarde créée', 'tr': 'Yedek Oluşturuldu'},
 'Backup created:\n%s': {'ar': 'تم إنشاء النسخة الاحتياطية:\n%s', 'fr': 'Sauvegarde créée :\n%s', 'tr': 'Yedek oluşturuldu:\n%s'},
 'Backup Failed': {'ar': 'فشل النسخ الاحتياطي', 'fr': 'Échec de la sauvegarde', 'tr': 'Yedekleme Başarısız'},
 'Backup failed: %s': {'ar': 'فشل النسخ الاحتياطي: %s', 'fr': 'Échec de la sauvegarde : %s', 'tr': 'Yedekleme başarısız: %s'},
 'Invalid Backup': {'ar': 'نسخة احتياطية غير صالحة', 'fr': 'Sauvegarde invalide', 'tr': 'Geçersiz Yedek'},
 'Invalid backup: %s': {'ar': 'نسخة احتياطية غير صالحة: %s', 'fr': 'Sauvegarde invalide : %s', 'tr': 'Geçersiz yedek: %s'},
 'Restore API secrets?': {'ar': 'استعادة أسرار API؟', 'fr': 'Restaurer les secrets API ?', 'tr': 'API gizli bilgileri geri yüklensin mi?'},
 'Restore state only (keep current api_keys.conf)': {'ar': 'استعادة الحالة فقط (الاحتفاظ بملف api_keys.conf الحالي)',
                                                     'fr': 'Restaurer uniquement l’état (conserver api_keys.conf actuel)',
                                                     'tr': 'Yalnızca durumu geri yükle (mevcut api_keys.conf kalsın)'},
 'Restore state + API secrets': {'ar': 'استعادة الحالة + أسرار API', 'fr': 'Restaurer l’état + les secrets API', 'tr': 'Durum + API gizli bilgilerini geri yükle'},
 'Choose what to restore': {'ar': 'اختر ما تريد استعادته', 'fr': 'Choisissez ce qu’il faut restaurer', 'tr': 'Neyin geri yükleneceğini seçin'},
 ' API secrets will also be replaced.': {'ar': ' سيتم أيضًا استبدال أسرار API.', 'fr': ' Les secrets API seront également remplacés.', 'tr': ' API gizli bilgileri de değiştirilecek.'},
 'Confirm Restore': {'ar': 'تأكيد الاستعادة', 'fr': 'Confirmer la restauration', 'tr': 'Geri Yüklemeyi Onayla'},
 'Restore this backup? A safety backup of the current state will be created first.': {'ar': 'هل تريد استعادة هذه النسخة؟ سيتم أولًا إنشاء نسخة أمان من الحالة الحالية.',
                                                                                      'fr': 'Restaurer cette sauvegarde ? Une sauvegarde de sécurité de l’état actuel sera d’abord créée.',
                                                                                      'tr': 'Bu yedek geri yüklensin mi? Önce mevcut durumun güvenlik yedeği oluşturulacak.'},
 'Restore cancelled before commit': {'ar': 'تم إلغاء الاستعادة قبل تطبيق التغييرات', 'fr': 'Restauration annulée avant validation', 'tr': 'Geri yükleme uygulanmadan önce iptal edildi'},
 'Restore Complete': {'ar': 'اكتملت الاستعادة', 'fr': 'Restauration terminée', 'tr': 'Geri Yükleme Tamamlandı'},
 'Restore complete. Restart Enigma2/plugin before continuing.\n\nRestored: %s': {'ar': 'اكتملت الاستعادة. أعد تشغيل Enigma2/الإضافة قبل المتابعة.\n\nتمت الاستعادة: %s',
                                                                                 'fr': 'Restauration terminée. Redémarrez Enigma2/le plugin avant de continuer.\n\nRestauré : %s',
                                                                                 'tr': 'Geri yükleme tamamlandı. Devam etmeden önce Enigma2/eklentiyi yeniden başlatın.\n\nGeri yüklendi: %s'},
 'Restore Failed': {'ar': 'فشلت الاستعادة', 'fr': 'Échec de la restauration', 'tr': 'Geri Yükleme Başarısız'},
 'Restore failed: %s': {'ar': 'فشلت الاستعادة: %s', 'fr': 'Échec de la restauration : %s', 'tr': 'Geri yükleme başarısız: %s'},
 'Support bundle: %s': {'ar': 'حزمة الدعم: %s', 'fr': 'Paquet de support : %s', 'tr': 'Destek paketi: %s'},
 'Redacted support bundle created:\n%s': {'ar': 'تم إنشاء حزمة دعم منقحة:\n%s', 'fr': 'Paquet de support expurgé créé :\n%s', 'tr': 'Hassas verileri ayıklanmış destek paketi oluşturuldu:\n%s'},
 'Support export failed: %s': {'ar': 'فشل تصدير حزمة الدعم: %s', 'fr': 'Échec de l’export du support : %s', 'tr': 'Destek dışa aktarımı başarısız: %s'},
 'TMDB credential saved privately in api_keys.conf': {'ar': 'تم حفظ بيانات TMDB بشكل خاص في api_keys.conf',
                                                      'fr': 'Identifiant TMDB enregistré de façon privée dans api_keys.conf',
                                                      'tr': 'TMDB kimlik bilgisi api_keys.conf içinde özel olarak kaydedildi'},
 'TMDB credential cleared': {'ar': 'تم مسح بيانات TMDB', 'fr': 'Identifiant TMDB effacé', 'tr': 'TMDB kimlik bilgisi temizlendi'},
 'TMDB credential save failed: %s': {'ar': 'فشل حفظ بيانات TMDB: %s', 'fr': 'Échec de l’enregistrement de l’identifiant TMDB : %s', 'tr': 'TMDB kimlik bilgisi kaydedilemedi: %s'},
 'SubDL API key saved privately in api_keys.conf': {'ar': 'تم حفظ مفتاح SubDL API بشكل خاص في api_keys.conf',
                                                    'fr': 'Clé API SubDL enregistrée de façon privée dans api_keys.conf',
                                                    'tr': 'SubDL API anahtarı api_keys.conf içinde özel olarak kaydedildi'},
 'SubDL API key cleared': {'ar': 'تم مسح مفتاح SubDL API', 'fr': 'Clé API SubDL effacée', 'tr': 'SubDL API anahtarı temizlendi'},
 'Online Subtitles': {'ar': 'الترجمات أونلاين', 'fr': 'Sous-titres en ligne', 'tr': 'Çevrimiçi Altyazılar'},
 'SubDL API key save failed: %s': {'ar': 'فشل حفظ مفتاح SubDL API: %s', 'fr': 'Échec de l’enregistrement de la clé API SubDL : %s', 'tr': 'SubDL API anahtarı kaydedilemedi: %s'},
 'Create backup (portable, no API secrets)': {'ar': 'إنشاء نسخة احتياطية قابلة للنقل (بدون أسرار API)', 'fr': 'Créer une sauvegarde portable (sans secrets API)', 'tr': 'Taşınabilir yedek oluştur (API gizli bilgileri olmadan)'},
 'Create authenticated backup (this receiver)': {'ar': 'إنشاء نسخة احتياطية موثقة (لهذا الريسيفر)', 'fr': 'Créer une sauvegarde authentifiée (ce récepteur)', 'tr': 'Kimlik doğrulamalı yedek oluştur (bu alıcı)'},
 'Create backup including api_keys.conf': {'ar': 'إنشاء نسخة احتياطية تشمل api_keys.conf', 'fr': 'Créer une sauvegarde incluant api_keys.conf', 'tr': 'api_keys.conf içeren yedek oluştur'},
 'Create authenticated backup + api_keys.conf': {'ar': 'إنشاء نسخة احتياطية موثقة + api_keys.conf', 'fr': 'Créer une sauvegarde authentifiée + api_keys.conf', 'tr': 'Kimlik doğrulamalı yedek + api_keys.conf oluştur'},
 'Restore a backup': {'ar': 'استعادة نسخة احتياطية', 'fr': 'Restaurer une sauvegarde', 'tr': 'Bir yedeği geri yükle'},
 'This backup will contain api_keys.conf credentials. The ZIP is protected by filesystem permissions but is NOT encrypted. Create it only on trusted storage.': {'ar': 'ستحتوي هذه النسخة على بيانات اعتماد api_keys.conf. ملف ZIP محمي '
                                                                                                                                                                       'بصلاحيات نظام الملفات لكنه غير مشفر. أنشئه فقط على وحدة تخزين موثوقة.',
                                                                                                                                                                 'fr': 'Cette sauvegarde contiendra les identifiants de api_keys.conf. Le ZIP '
                                                                                                                                                                       'est protégé par les permissions du système de fichiers, mais n’est PAS '
                                                                                                                                                                       'chiffré. Créez-le uniquement sur un stockage de confiance.',
                                                                                                                                                                 'tr': 'Bu yedek api_keys.conf kimlik bilgilerini içerir. ZIP dosya sistemi '
                                                                                                                                                                       'izinleriyle korunur ancak şifreli DEĞİLDİR. Yalnızca güvenilir '
                                                                                                                                                                       'depolamada oluşturun.'}})


_T.update({'%d portal(s) working.  %d failed.\n\nFailed portals were NOT disabled; use RED if you want to disable one.': {'ar': '%d Portal يعمل. فشل %d.\n\nلم يتم تعطيل الـPortals الفاشلة؛ استخدم الزر الأحمر إذا أردت تعطيل أحدها.',
                                                                                                                'fr': '%d portail(s) fonctionnent. %d ont échoué.\n'
                                                                                                                      '\n'
                                                                                                                      'Les portails en échec n’ont PAS été désactivés ; utilisez ROUGE pour en désactiver un.',
                                                                                                                'tr': '%d portal çalışıyor. %d başarısız.\n'
                                                                                                                      '\n'
                                                                                                                      'Başarısız portallar devre dışı bırakılmadı; birini kapatmak isterseniz KIRMIZI tuşu kullanın.'},
 '%s  •  %s  •  ARROWS Navigate  •  OK Open  •  MENU Portal Manager': {'ar': '%s  •  %s  •  الأسهم للتنقل  •  OK فتح  •  MENU إدارة الـPortals',
                                                                       'fr': '%s  •  %s  •  FLÈCHES Naviguer  •  OK Ouvrir  •  MENU Gestion des portails',
                                                                       'tr': '%s  •  %s  •  OKLAR Gezin  •  OK Aç  •  MENU Portal Yöneticisi'},
 'All %d portals are working': {'ar': 'كل الـ%d Portal تعمل', 'fr': 'Les %d portails fonctionnent', 'tr': '%d portalın tamamı çalışıyor'},
 'All portals passed the check.': {'ar': 'اجتازت كل الـPortals الفحص.', 'fr': 'Tous les portails ont réussi la vérification.', 'tr': 'Tüm portallar kontrolden geçti.'},
 'Bouquet export failed: %s': {'ar': 'فشل تصدير الباقة: %s', 'fr': 'Échec de l’export du bouquet : %s', 'tr': 'Buket dışa aktarılamadı: %s'},
 'Bouquet exported • %d channels • proxy %s': {'ar': 'تم تصدير الباقة • %d قناة • بروكسي %s', 'fr': 'Bouquet exporté • %d chaînes • proxy %s', 'tr': 'Buket dışa aktarıldı • %d kanal • proxy %s'},
 'Bulk check failed: %s': {'ar': 'فشل الفحص الجماعي: %s', 'fr': 'Échec de la vérification groupée : %s', 'tr': 'Toplu kontrol başarısız: %s'},
 'Check complete  •  %d working / %d failed': {'ar': 'اكتمل الفحص  •  %d يعمل / %d فشل', 'fr': 'Vérification terminée  •  %d fonctionnent / %d en échec', 'tr': 'Kontrol tamamlandı  •  %d çalışıyor / %d başarısız'},
 'Checking %d/%d  •  %s  •  %s': {'ar': 'جارٍ الفحص %d/%d  •  %s  •  %s', 'fr': 'Vérification %d/%d  •  %s  •  %s', 'tr': 'Kontrol ediliyor %d/%d  •  %s  •  %s'},
 'Checks done; save failed: %s': {'ar': 'اكتمل الفحص؛ فشل الحفظ: %s', 'fr': 'Vérifications terminées ; échec de l’enregistrement : %s', 'tr': 'Kontroller tamamlandı; kayıt başarısız: %s'},
 'Clear plugin-owned data for this portal?\n\nThis removes its exported bouquet/EPG, matching recording refresh jobs/timers, Favorites, History and Resume data, but keeps the portal itself.': {'ar': 'مسح بيانات الإضافة الخاصة بهذا '
                                                                                                                                                                                                       'الـPortal؟\n'
                                                                                                                                                                                                       '\n'
                                                                                                                                                                                                       'سيؤدي ذلك إلى حذف الباقة/EPG المصدّرين '
                                                                                                                                                                                                       'ومهام/مؤقتات تحديث التسجيلات المطابقة '
                                                                                                                                                                                                       'والمفضلة والسجل وبيانات الاستكمال، مع '
                                                                                                                                                                                                       'الاحتفاظ بالـPortal نفسه.',
                                                                                                                                                                                                 'fr': 'Effacer les données du plugin pour ce '
                                                                                                                                                                                                       'portail ?\n'
                                                                                                                                                                                                       '\n'
                                                                                                                                                                                                       'Cela supprime son bouquet/EPG exporté, '
                                                                                                                                                                                                       'les tâches/minuteries de '
                                                                                                                                                                                                       'rafraîchissement d’enregistrement '
                                                                                                                                                                                                       'correspondantes, les favoris, '
                                                                                                                                                                                                       'l’historique et les données de '
                                                                                                                                                                                                       'reprise, tout en conservant le '
                                                                                                                                                                                                       'portail.',
                                                                                                                                                                                                 'tr': 'Bu portal için eklentiye ait veriler '
                                                                                                                                                                                                       'temizlensin mi?\n'
                                                                                                                                                                                                       '\n'
                                                                                                                                                                                                       'Dışa aktarılan buket/EPG, eşleşen '
                                                                                                                                                                                                       'kayıt yenileme '
                                                                                                                                                                                                       'görevleri/zamanlayıcıları, Favoriler, '
                                                                                                                                                                                                       'Geçmiş ve Devam verileri silinir; '
                                                                                                                                                                                                       'portalın kendisi korunur.'},
 'FAILED': {'ar': 'فشل', 'fr': 'ÉCHEC', 'tr': 'BAŞARISIZ'},
 'HTTP fallback save failed: %s': {'ar': 'فشل حفظ إعداد الرجوع إلى HTTP: %s', 'fr': 'Échec de l’enregistrement du repli HTTP : %s', 'tr': 'HTTP geri dönüş ayarı kaydedilemedi: %s'},
 'Live bouquet exported with dynamic Stalker links.\n\n%d channels\n\nAn EPGImport source was also created. Open EPG-Importer, enable the Ultra Stalker source, then run an import.': {'ar': 'تم تصدير باقة البث المباشر بروابط Stalker '
                                                                                                                                                                                             'ديناميكية.\n'
                                                                                                                                                                                             '\n'
                                                                                                                                                                                             '%d قناة\n'
                                                                                                                                                                                             '\n'
                                                                                                                                                                                             'تم أيضًا إنشاء مصدر EPGImport. افتح EPG-Importer '
                                                                                                                                                                                             'وفعّل مصدر Ultra Stalker ثم شغّل الاستيراد.',
                                                                                                                                                                                       'fr': 'Bouquet Live exporté avec des liens Stalker '
                                                                                                                                                                                             'dynamiques.\n'
                                                                                                                                                                                             '\n'
                                                                                                                                                                                             '%d chaînes\n'
                                                                                                                                                                                             '\n'
                                                                                                                                                                                             'Une source EPGImport a également été créée. '
                                                                                                                                                                                             'Ouvrez EPG-Importer, activez la source Ultra '
                                                                                                                                                                                             'Stalker, puis lancez l’import.',
                                                                                                                                                                                       'tr': 'Canlı buket dinamik Stalker bağlantılarıyla dışa '
                                                                                                                                                                                             'aktarıldı.\n'
                                                                                                                                                                                             '\n'
                                                                                                                                                                                             '%d kanal\n'
                                                                                                                                                                                             '\n'
                                                                                                                                                                                             'Bir EPGImport kaynağı da oluşturuldu. '
                                                                                                                                                                                             'EPG-Importer’ı açın, Ultra Stalker kaynağını '
                                                                                                                                                                                             'etkinleştirin ve içe aktarmayı başlatın.'},
 'M3U add failed: %s': {'ar': 'فشلت إضافة M3U: %s', 'fr': 'Échec de l’ajout M3U : %s', 'tr': 'M3U eklenemedi: %s'},
 'MAC for duplicate': {'ar': 'MAC للنسخة المكررة', 'fr': 'MAC pour la duplication', 'tr': 'Kopya için MAC'},
 'MAG profile save failed: %s': {'ar': 'فشل حفظ ملف MAG: %s', 'fr': 'Échec de l’enregistrement du profil MAG : %s', 'tr': 'MAG profili kaydedilemedi: %s'},
 'MAG profile saved: %s': {'ar': 'تم حفظ ملف MAG: %s', 'fr': 'Profil MAG enregistré : %s', 'tr': 'MAG profili kaydedildi: %s'},
 'OK': {'ar': 'OK', 'fr': 'OK', 'tr': 'OK'},
 'PORTAL': {'ar': 'PORTAL', 'fr': 'PORTAIL', 'tr': 'PORTAL'},
 'Page %d / %d  •  Source %d / %d  •  %s': {'ar': 'الصفحة %d / %d  •  المصدر %d / %d  •  %s', 'fr': 'Page %d / %d  •  Source %d / %d  •  %s', 'tr': 'Sayfa %d / %d  •  Kaynak %d / %d  •  %s'},
 'Permanently delete selected portal?\n\nIt will be removed from saved profiles, all portal import files, cached sessions and plugin-owned data.': {'ar': 'حذف الـPortal المحدد نهائيًا؟\n'
                                                                                                                                                          '\n'
                                                                                                                                                          'سيتم حذفه من الملفات المحفوظة وكل ملفات استيراد الـPortal والجلسات المخزنة وبيانات '
                                                                                                                                                          'الإضافة.',
                                                                                                                                                    'fr': 'Supprimer définitivement le portail sélectionné ?\n'
                                                                                                                                                          '\n'
                                                                                                                                                          'Il sera supprimé des profils enregistrés, de tous les fichiers d’import de portail, '
                                                                                                                                                          'des sessions en cache et des données du plugin.',
                                                                                                                                                    'tr': 'Seçili portal kalıcı olarak silinsin mi?\n'
                                                                                                                                                          '\n'
                                                                                                                                                          'Kayıtlı profillerden, tüm portal içe aktarma dosyalarından, önbellek oturumlarından '
                                                                                                                                                          've eklenti verilerinden kaldırılır.'},
 'Permanently delete this portal and its plugin-owned data?\n\nThis removes its exported bouquet/EPG, recording refresh jobs, Favorites, History and Resume data. Any matching Stalker recording timers will also be removed.': {'ar': 'حذف '
                                                                                                                                                                                                                                       'هذا '
                                                                                                                                                                                                                                       'الـPortal '
                                                                                                                                                                                                                                       'وبيانات '
                                                                                                                                                                                                                                       'الإضافة '
                                                                                                                                                                                                                                       'الخاصة '
                                                                                                                                                                                                                                       'به '
                                                                                                                                                                                                                                       'نهائيًا؟\n'
                                                                                                                                                                                                                                       '\n'
                                                                                                                                                                                                                                       'سيتم '
                                                                                                                                                                                                                                       'حذف '
                                                                                                                                                                                                                                       'الباقة/EPG '
                                                                                                                                                                                                                                       'المصدّرين '
                                                                                                                                                                                                                                       'ومهام '
                                                                                                                                                                                                                                       'تحديث '
                                                                                                                                                                                                                                       'التسجيل '
                                                                                                                                                                                                                                       'والمفضلة '
                                                                                                                                                                                                                                       'والسجل '
                                                                                                                                                                                                                                       'وبيانات '
                                                                                                                                                                                                                                       'الاستكمال. '
                                                                                                                                                                                                                                       'كما '
                                                                                                                                                                                                                                       'ستُحذف '
                                                                                                                                                                                                                                       'أي '
                                                                                                                                                                                                                                       'مؤقتات '
                                                                                                                                                                                                                                       'تسجيل '
                                                                                                                                                                                                                                       'Stalker '
                                                                                                                                                                                                                                       'مطابقة.',
                                                                                                                                                                                                                                 'fr': 'Supprimer '
                                                                                                                                                                                                                                       'définitivement '
                                                                                                                                                                                                                                       'ce '
                                                                                                                                                                                                                                       'portail '
                                                                                                                                                                                                                                       'et ses '
                                                                                                                                                                                                                                       'données '
                                                                                                                                                                                                                                       'du '
                                                                                                                                                                                                                                       'plugin '
                                                                                                                                                                                                                                       '?\n'
                                                                                                                                                                                                                                       '\n'
                                                                                                                                                                                                                                       'Cela '
                                                                                                                                                                                                                                       'supprime '
                                                                                                                                                                                                                                       'son '
                                                                                                                                                                                                                                       'bouquet/EPG '
                                                                                                                                                                                                                                       'exporté, '
                                                                                                                                                                                                                                       'les '
                                                                                                                                                                                                                                       'tâches '
                                                                                                                                                                                                                                       'de '
                                                                                                                                                                                                                                       'rafraîchissement '
                                                                                                                                                                                                                                       'd’enregistrement, '
                                                                                                                                                                                                                                       'les '
                                                                                                                                                                                                                                       'favoris, '
                                                                                                                                                                                                                                       'l’historique '
                                                                                                                                                                                                                                       'et les '
                                                                                                                                                                                                                                       'données '
                                                                                                                                                                                                                                       'de '
                                                                                                                                                                                                                                       'reprise. '
                                                                                                                                                                                                                                       'Les '
                                                                                                                                                                                                                                       'minuteries '
                                                                                                                                                                                                                                       'd’enregistrement '
                                                                                                                                                                                                                                       'Stalker '
                                                                                                                                                                                                                                       'correspondantes '
                                                                                                                                                                                                                                       'seront '
                                                                                                                                                                                                                                       'également '
                                                                                                                                                                                                                                       'supprimées.',
                                                                                                                                                                                                                                 'tr': 'Bu '
                                                                                                                                                                                                                                       'portal '
                                                                                                                                                                                                                                       've '
                                                                                                                                                                                                                                       'eklentiye '
                                                                                                                                                                                                                                       'ait '
                                                                                                                                                                                                                                       'verileri '
                                                                                                                                                                                                                                       'kalıcı '
                                                                                                                                                                                                                                       'olarak '
                                                                                                                                                                                                                                       'silinsin '
                                                                                                                                                                                                                                       'mi?\n'
                                                                                                                                                                                                                                       '\n'
                                                                                                                                                                                                                                       'Dışa '
                                                                                                                                                                                                                                       'aktarılan '
                                                                                                                                                                                                                                       'buket/EPG, '
                                                                                                                                                                                                                                       'kayıt '
                                                                                                                                                                                                                                       'yenileme '
                                                                                                                                                                                                                                       'görevleri, '
                                                                                                                                                                                                                                       'Favoriler, '
                                                                                                                                                                                                                                       'Geçmiş '
                                                                                                                                                                                                                                       've '
                                                                                                                                                                                                                                       'Devam '
                                                                                                                                                                                                                                       'verileri '
                                                                                                                                                                                                                                       'silinir. '
                                                                                                                                                                                                                                       'Eşleşen '
                                                                                                                                                                                                                                       'Stalker '
                                                                                                                                                                                                                                       'kayıt '
                                                                                                                                                                                                                                       'zamanlayıcıları '
                                                                                                                                                                                                                                       'da '
                                                                                                                                                                                                                                       'kaldırılır.'},
 'Playlist was written but did not survive profile reload': {'ar': 'تمت كتابة قائمة التشغيل لكنها لم تبقَ بعد إعادة تحميل الملفات',
                                                             'fr': 'La playlist a été écrite mais n’a pas persisté après le rechargement des profils',
                                                             'tr': 'Oynatma listesi yazıldı ancak profil yeniden yüklemesinden sonra kalmadı'},
 'Portal / M3U URL': {'ar': 'رابط Portal / M3U', 'fr': 'URL Portal / M3U', 'tr': 'Portal / M3U URL'},
 'Portal delete failed': {'ar': 'فشل حذف الـPortal', 'fr': 'Échec de la suppression du portail', 'tr': 'Portal silinemedi'},
 'Re-enable portal': {'ar': 'إعادة تفعيل Portal', 'fr': 'Réactiver un portail', 'tr': 'Portalı yeniden etkinleştir'},
 'Remove export failed: %s': {'ar': 'فشل حذف التصدير: %s', 'fr': 'Échec de la suppression de l’export : %s', 'tr': 'Dışa aktarım kaldırılamadı: %s'},
 'Rename failed: %s': {'ar': 'فشل تغيير الاسم: %s', 'fr': 'Échec du renommage : %s', 'tr': 'Yeniden adlandırma başarısız: %s'},
 'Save failed: %s': {'ar': 'فشل الحفظ: %s', 'fr': 'Échec de l’enregistrement : %s', 'tr': 'Kayıt başarısız: %s'},
 'Source probe unavailable': {'ar': 'فحص نوع المصدر غير متاح', 'fr': 'Détection du type de source indisponible', 'tr': 'Kaynak türü algılama kullanılamıyor'},
 'TLS mode save failed: %s': {'ar': 'فشل حفظ وضع TLS: %s', 'fr': 'Échec de l’enregistrement du mode TLS : %s', 'tr': 'TLS modu kaydedilemedi: %s'},
 'The files were written but the dynamic bouquet proxy could not start. Remove/re-export the bouquet after resolving the port conflict.': {'ar': 'تمت كتابة الملفات لكن تعذر تشغيل بروكسي الباقة الديناميكي. احذف الباقة وأعد تصديرها بعد حل '
                                                                                                                                                 'تعارض المنفذ.',
                                                                                                                                           'fr': 'Les fichiers ont été écrits, mais le proxy dynamique du bouquet n’a pas pu démarrer. '
                                                                                                                                                 'Supprimez puis réexportez le bouquet après avoir résolu le conflit de port.',
                                                                                                                                           'tr': 'Dosyalar yazıldı ancak dinamik buket proxy’si başlatılamadı. Port çakışmasını çözdükten '
                                                                                                                                                 'sonra buketi kaldırıp yeniden dışa aktarın.'},
 'Update failed: %s': {'ar': 'فشل التحديث: %s', 'fr': 'Échec de la mise à jour : %s', 'tr': 'Güncelleme başarısız: %s'}})



_T.update({' • %d already queued': {'ar': ' • %d موجود بالفعل في قائمة الانتظار', 'fr': ' • %d déjà en file d’attente', 'tr': ' • %d zaten kuyrukta'},
 '%d%%': {'ar': '%d%%', 'fr': '%d%%', 'tr': '%d%%'},
 'Audio selection failed: %s': {'ar': 'فشل اختيار المسار الصوتي: %s',
                                'fr': 'Échec de la sélection de la piste audio : %s',
                                'tr': 'Ses parçası seçilemedi: %s'},
 'Audio tracks': {'ar': 'المسارات الصوتية', 'fr': 'Pistes audio', 'tr': 'Ses parçaları'},
 'Category %s': {'ar': 'القسم %s', 'fr': 'Catégorie %s', 'tr': 'Kategori %s'},
 'Change parental PIN': {'ar': 'تغيير رمز الرقابة الأبوية', 'fr': 'Modifier le code PIN parental', 'tr': 'Ebeveyn PIN’ini değiştir'},
 'Change the default parental PIN (0000) before enabling Parental Lock.': {'ar': 'غيّر رمز الرقابة الأبوية الافتراضي (0000) قبل تفعيل '
                                                                                 'القفل الأبوي.',
                                                                           'fr': 'Modifiez le code PIN parental par défaut (0000) avant '
                                                                                 'd’activer le verrouillage parental.',
                                                                           'tr': 'Ebeveyn Kilidini etkinleştirmeden önce varsayılan '
                                                                                 'ebeveyn PIN’ini (0000) değiştirin.'},
 'Channel layout saved: %s': {'ar': 'تم حفظ تخطيط قائمة القنوات: %s',
                              'fr': 'Disposition de la liste des chaînes enregistrée : %s',
                              'tr': 'Kanal listesi düzeni kaydedildi: %s'},
 'Channel list  •  %s': {'ar': 'قائمة القنوات  •  %s', 'fr': 'Liste des chaînes  •  %s', 'tr': 'Kanal listesi  •  %s'},
 'Cinematic': {'ar': 'سينمائي', 'fr': 'Cinématique', 'tr': 'Sinematik'},
 'Clean technical prefixes  •  %s': {'ar': 'تنظيف البادئات التقنية  •  %s',
                                     'fr': 'Nettoyer les préfixes techniques  •  %s',
                                     'tr': 'Teknik önekleri temizle  •  %s'},
 'Clear Continue Watching': {'ar': 'مسح متابعة المشاهدة', 'fr': 'Effacer Continuer à regarder', 'tr': 'İzlemeye Devam listesini temizle'},
 'Clear Continue Watching for this portal?': {'ar': 'هل تريد مسح قائمة متابعة المشاهدة لهذا الـPortal؟',
                                              'fr': 'Effacer la liste Continuer à regarder pour ce portail ?',
                                              'tr': 'Bu portal için İzlemeye Devam listesi temizlensin mi?'},
 'Clear failed: %s': {'ar': 'فشل المسح: %s', 'fr': 'Échec de l’effacement : %s', 'tr': 'Temizleme başarısız: %s'},
 'Clear image cache  •  %d files / %.1f MB': {'ar': 'مسح ذاكرة الصور  •  %d ملف / %.1f م.ب',
                                              'fr': 'Vider le cache d’images  •  %d fichiers / %.1f Mo',
                                              'tr': 'Görsel önbelleğini temizle  •  %d dosya / %.1f MB'},
 'Download': {'ar': 'تنزيل', 'fr': 'Téléchargement', 'tr': 'İndirme'},
 'Download Episode': {'ar': 'تنزيل الحلقة', 'fr': 'Télécharger l’épisode', 'tr': 'Bölümü indir'},
 'Download Season': {'ar': 'تنزيل الموسم', 'fr': 'Télécharger la saison', 'tr': 'Sezonu indir'},
 'Downloads Manager': {'ar': 'مدير التنزيلات', 'fr': 'Gestionnaire des téléchargements', 'tr': 'İndirme Yöneticisi'},
 'EPG failed: %s': {'ar': 'فشل تحميل EPG: %s', 'fr': 'Échec du chargement EPG : %s', 'tr': 'EPG yüklenemedi: %s'},
 'EPG for selected channel': {'ar': 'EPG للقناة المحددة', 'fr': 'EPG de la chaîne sélectionnée', 'tr': 'Seçili kanalın EPG’si'},
 'EPG window  •  %sh': {'ar': 'نطاق EPG  •  %s س', 'fr': 'Fenêtre EPG  •  %s h', 'tr': 'EPG aralığı  •  %s sa'},
 'EPG • choose a programme': {'ar': 'EPG • اختر برنامجًا', 'fr': 'EPG • choisir un programme', 'tr': 'EPG • bir program seçin'},
 'First page': {'ar': 'الصفحة الأولى', 'fr': 'Première page', 'tr': 'İlk sayfa'},
 'Grid options': {'ar': 'خيارات الشبكة', 'fr': 'Options de la grille', 'tr': 'Izgara seçenekleri'},
 'Hide / unhide current category': {'ar': 'إخفاء / إظهار القسم الحالي',
                                    'fr': 'Masquer / afficher la catégorie actuelle',
                                    'tr': 'Geçerli kategoriyi gizle / göster'},
 'History update failed: %s': {'ar': 'فشل تحديث سجل المشاهدة: %s',
                               'fr': 'Échec de la mise à jour de l’historique : %s',
                               'tr': 'İzleme geçmişi güncellenemedi: %s'},
 'Incorrect parental PIN': {'ar': 'رمز الرقابة الأبوية غير صحيح', 'fr': 'Code PIN parental incorrect', 'tr': 'Ebeveyn PIN’i yanlış'},
 'Interface  •  Nova FHD / 1920×1080': {'ar': 'الواجهة  •  Nova FHD / 1920×1080',
                                        'fr': 'Interface  •  Nova FHD / 1920×1080',
                                        'tr': 'Arayüz  •  Nova FHD / 1920×1080'},
 'Live preview  •  %s': {'ar': 'المعاينة المباشرة  •  %s', 'fr': 'Aperçu en direct  •  %s', 'tr': 'Canlı önizleme  •  %s'},
 'Live preview disabled': {'ar': 'تم إيقاف المعاينة المباشرة', 'fr': 'Aperçu en direct désactivé', 'tr': 'Canlı önizleme kapatıldı'},
 'Live preview enabled': {'ar': 'تم تفعيل المعاينة المباشرة', 'fr': 'Aperçu en direct activé', 'tr': 'Canlı önizleme etkinleştirildi'},
 'Manage hidden categories': {'ar': 'إدارة الأقسام المخفية', 'fr': 'Gérer les catégories masquées', 'tr': 'Gizli kategorileri yönet'},
 'Mark selected unwatched': {'ar': 'تعيين المحدد كغير مُشاهد',
                             'fr': 'Marquer la sélection comme non vue',
                             'tr': 'Seçileni izlenmedi olarak işaretle'},
 'Mark selected watched': {'ar': 'تعيين المحدد كمُشاهد', 'fr': 'Marquer la sélection comme vue', 'tr': 'Seçileni izlendi olarak işaretle'},
 'Mark unwatched': {'ar': 'تعيين كغير مُشاهد', 'fr': 'Marquer comme non vu', 'tr': 'İzlenmedi olarak işaretle'},
 'Mark watched': {'ar': 'تعيين كمُشاهد', 'fr': 'Marquer comme vu', 'tr': 'İzlendi olarak işaretle'},
 'Mark watched / unwatched': {'ar': 'تبديل حالة مُشاهد / غير مُشاهد',
                              'fr': 'Basculer vu / non vu',
                              'tr': 'İzlendi / izlenmedi durumunu değiştir'},
 'No EPG data returned': {'ar': 'لا توجد بيانات EPG متاحة', 'fr': 'Aucune donnée EPG disponible', 'tr': 'EPG verisi bulunamadı'},
 'Nova FHD is the only interface in this build. All plugin screens use the same 1920×1080 design system.': {'ar': 'Nova FHD هي الواجهة '
                                                                                                                  'الوحيدة في هذا الإصدار. '
                                                                                                                  'جميع شاشات البلجن '
                                                                                                                  'تستخدم نفس نظام التصميم '
                                                                                                                  'بدقة 1920×1080.',
                                                                                                            'fr': 'Nova FHD est la seule '
                                                                                                                  'interface de cette '
                                                                                                                  'version. Tous les '
                                                                                                                  'écrans du plugin '
                                                                                                                  'utilisent le même '
                                                                                                                  'système de design en '
                                                                                                                  '1920×1080.',
                                                                                                            'tr': 'Bu sürümdeki tek arayüz '
                                                                                                                  'Nova FHD’dir. Tüm '
                                                                                                                  'eklenti ekranları aynı '
                                                                                                                  '1920×1080 tasarım '
                                                                                                                  'sistemini kullanır.'},
 'Parental lock  •  %s': {'ar': 'القفل الأبوي  •  %s', 'fr': 'Verrouillage parental  •  %s', 'tr': 'Ebeveyn kilidi  •  %s'},
 'Parental lock disabled': {'ar': 'تم إيقاف القفل الأبوي', 'fr': 'Verrouillage parental désactivé', 'tr': 'Ebeveyn kilidi kapatıldı'},
 'Parental lock enabled': {'ar': 'تم تفعيل القفل الأبوي', 'fr': 'Verrouillage parental activé', 'tr': 'Ebeveyn kilidi etkinleştirildi'},
 'Pin / unpin current category': {'ar': 'تثبيت / إلغاء تثبيت القسم الحالي',
                                  'fr': 'Épingler / désépingler la catégorie actuelle',
                                  'tr': 'Geçerli kategoriyi sabitle / sabitlemeyi kaldır'},
 'Playback Engine Lock': {'ar': 'قفل محرك التشغيل', 'fr': 'Verrouillage du moteur de lecture', 'tr': 'Oynatma Motoru Kilidi'},
 'Playback engine  •  %s': {'ar': 'محرك التشغيل  •  %s', 'fr': 'Moteur de lecture  •  %s', 'tr': 'Oynatma motoru  •  %s'},
 'Playback engine is locked to the value selected under Playback engine. Automatic Smart Engine switching is disabled.': {'ar': 'محرك '
                                                                                                                                'التشغيل '
                                                                                                                                'مقفول على '
                                                                                                                                'القيمة '
                                                                                                                                'المحددة '
                                                                                                                                'في إعداد '
                                                                                                                                'محرك '
                                                                                                                                'التشغيل. '
                                                                                                                                'التبديل '
                                                                                                                                'التلقائي '
                                                                                                                                'عبر Smart '
                                                                                                                                'Engine '
                                                                                                                                'معطل.',
                                                                                                                          'fr': 'Le moteur '
                                                                                                                                'de '
                                                                                                                                'lecture '
                                                                                                                                'est '
                                                                                                                                'verrouillé '
                                                                                                                                'sur la '
                                                                                                                                'valeur '
                                                                                                                                'choisie '
                                                                                                                                'dans '
                                                                                                                                'Moteur de '
                                                                                                                                'lecture. '
                                                                                                                                'Le '
                                                                                                                                'changement '
                                                                                                                                'automatique '
                                                                                                                                'Smart '
                                                                                                                                'Engine '
                                                                                                                                'est '
                                                                                                                                'désactivé.',
                                                                                                                          'tr': 'Oynatma '
                                                                                                                                'motoru, '
                                                                                                                                'Oynatma '
                                                                                                                                'motoru '
                                                                                                                                'ayarında '
                                                                                                                                'seçilen '
                                                                                                                                'değere '
                                                                                                                                'kilitlenmiştir. '
                                                                                                                                'Otomatik '
                                                                                                                                'Smart '
                                                                                                                                'Engine '
                                                                                                                                'geçişi '
                                                                                                                                'devre '
                                                                                                                                'dışıdır.'},
 'Playback service type (current: %s)': {'ar': 'نوع خدمة التشغيل (الحالي: %s)',
                                         'fr': 'Type de service de lecture (actuel : %s)',
                                         'tr': 'Oynatma hizmeti türü (mevcut: %s)'},
 'Playback service type saved: %s': {'ar': 'تم حفظ نوع خدمة التشغيل: %s',
                                     'fr': 'Type de service de lecture enregistré : %s',
                                     'tr': 'Oynatma hizmeti türü kaydedildi: %s'},
 'Player Engine Lock  •  ON': {'ar': 'قفل محرك المشغل  •  تشغيل',
                               'fr': 'Verrouillage du moteur  •  ACTIVÉ',
                               'tr': 'Oynatma Motoru Kilidi  •  AÇIK'},
 'Portal settings': {'ar': 'إعدادات الـPortal', 'fr': 'Paramètres du portail', 'tr': 'Portal ayarları'},
 'Portal timeout  •  %ss': {'ar': 'مهلة الـPortal  •  %s ث', 'fr': 'Délai du portail  •  %s s', 'tr': 'Portal zaman aşımı  •  %s sn'},
 'Portal tools': {'ar': 'أدوات الـPortal', 'fr': 'Outils du portail', 'tr': 'Portal araçları'},
 'Poster loading  •  %s': {'ar': 'تحميل البوسترات  •  %s', 'fr': 'Chargement des affiches  •  %s', 'tr': 'Poster yükleme  •  %s'},
 'Poster loading disabled': {'ar': 'تم إيقاف تحميل البوسترات', 'fr': 'Chargement des affiches désactivé', 'tr': 'Poster yükleme kapatıldı'},
 'Poster loading enabled': {'ar': 'تم تفعيل تحميل البوسترات',
                            'fr': 'Chargement des affiches activé',
                            'tr': 'Poster yükleme etkinleştirildi'},
 'Programme details': {'ar': 'تفاصيل البرنامج', 'fr': 'Détails du programme', 'tr': 'Program ayrıntıları'},
 'Protect / unprotect category with PIN': {'ar': 'حماية / إلغاء حماية القسم برمز PIN',
                                           'fr': 'Protéger / déprotéger la catégorie par PIN',
                                           'tr': 'Kategoriyi PIN ile koru / korumayı kaldır'},
 'Quality badges  •  %s': {'ar': 'شارات الجودة  •  %s', 'fr': 'Badges de qualité  •  %s', 'tr': 'Kalite rozetleri  •  %s'},
 'Queued %d download(s)': {'ar': 'تمت إضافة %d تنزيل إلى قائمة الانتظار',
                           'fr': '%d téléchargement(s) ajouté(s) à la file',
                           'tr': '%d indirme kuyruğa eklendi'},
 'Recently played': {'ar': 'المُشغّل مؤخرًا', 'fr': 'Lus récemment', 'tr': 'Son oynatılanlar'},
 'Record this programme': {'ar': 'تسجيل هذا البرنامج', 'fr': 'Enregistrer ce programme', 'tr': 'Bu programı kaydet'},
 'Recording timer added • %s': {'ar': 'تمت إضافة مؤقت التسجيل • %s',
                                'fr': 'Programmation d’enregistrement ajoutée • %s',
                                'tr': 'Kayıt zamanlayıcısı eklendi • %s'},
 'Refresh page': {'ar': 'تحديث الصفحة', 'fr': 'Actualiser la page', 'tr': 'Sayfayı yenile'},
 'Remove selected from Continue Watching': {'ar': 'إزالة المحدد من متابعة المشاهدة',
                                            'fr': 'Retirer la sélection de Continuer à regarder',
                                            'tr': 'Seçileni İzlemeye Devam’dan kaldır'},
 'Removed from Continue Watching': {'ar': 'تمت الإزالة من متابعة المشاهدة',
                                    'fr': 'Retiré de Continuer à regarder',
                                    'tr': 'İzlemeye Devam’dan kaldırıldı'},
 'Search current list': {'ar': 'البحث في القائمة الحالية', 'fr': 'Rechercher dans la liste actuelle', 'tr': 'Geçerli listede ara'},
 'Subtitle selection is unavailable: %s': {'ar': 'اختيار الترجمة غير متاح: %s',
                                           'fr': 'La sélection des sous-titres est indisponible : %s',
                                           'tr': 'Altyazı seçimi kullanılamıyor: %s'},
 'Subtitles': {'ar': 'الترجمة', 'fr': 'Sous-titres', 'tr': 'Altyazılar'},
 'Timer failed: %s': {'ar': 'فشل مؤقت التسجيل: %s', 'fr': 'Échec de la programmation : %s', 'tr': 'Zamanlayıcı başarısız: %s'},
 'Toggle favorite': {'ar': 'إضافة / إزالة من المفضلة', 'fr': 'Ajouter / retirer des favoris', 'tr': 'Favori durumunu değiştir'},
 'Visible home sections': {'ar': 'أقسام الرئيسية الظاهرة', 'fr': 'Sections visibles de l’accueil', 'tr': 'Görünür ana sayfa bölümleri'},
 'hidden': {'ar': 'مخفي', 'fr': 'masquée', 'tr': 'gizli'},
 'pinned': {'ar': 'مثبّت', 'fr': 'épinglée', 'tr': 'sabitlendi'},
 'protected': {'ar': 'محمي', 'fr': 'protégée', 'tr': 'korumalı'},
 'scheduled': {'ar': 'مجدول', 'fr': 'programmé', 'tr': 'planlandı'},
 'unpinned': {'ar': 'غير مثبّت', 'fr': 'désépinglée', 'tr': 'sabitleme kaldırıldı'},
 'unprotected': {'ar': 'غير محمي', 'fr': 'non protégée', 'tr': 'korumasız'},
 'visible': {'ar': 'ظاهر', 'fr': 'visible', 'tr': 'görünür'}})


_T.update({'%s min': {'ar': '%s دقيقة', 'fr': '%s min', 'tr': '%s dk'},
 'Download Movie': {'ar': 'تنزيل الفيلم', 'fr': 'Télécharger le film', 'tr': 'Filmi indir'},
 'Duration': {'ar': 'المدة', 'fr': 'Durée', 'tr': 'Süre'},
 'Genre': {'ar': 'التصنيف', 'fr': 'Genre', 'tr': 'Tür'},
 'Home Hero failed: %s': {'ar': 'فشل تعيين صورة الرئيسية: %s',
                          'fr': 'Échec de la définition du visuel d’accueil : %s',
                          'tr': 'Ana Sayfa görseli ayarlanamadı: %s'},
 'Loading metadata…': {'ar': 'جارٍ تحميل المعلومات…', 'fr': 'Chargement des métadonnées…', 'tr': 'Meta veriler yükleniyor…'},
 'Loading premium assets': {'ar': 'جارٍ تحميل عناصر الواجهة',
                            'fr': 'Chargement des éléments de l’interface',
                            'tr': 'Arayüz öğeleri yükleniyor'},
 'MOVIE': {'ar': 'فيلم', 'fr': 'FILM', 'tr': 'FİLM'},
 'Movie options': {'ar': 'خيارات الفيلم', 'fr': 'Options du film', 'tr': 'Film seçenekleri'},
 'Preparing portal services': {'ar': 'جارٍ تجهيز خدمات الـPortal',
                               'fr': 'Préparation des services du portail',
                               'tr': 'Portal hizmetleri hazırlanıyor'},
 'Rating': {'ar': 'التقييم', 'fr': 'Note', 'tr': 'Puan'},
 'Reload external artwork': {'ar': 'إعادة تحميل الصور الخارجية',
                             'fr': 'Recharger les illustrations externes',
                             'tr': 'Harici görselleri yeniden yükle'},
 'Resume %d%%': {'ar': 'استكمال %d%%', 'fr': 'Reprendre à %d%%', 'tr': '%d%% konumundan devam et'},
 'SERIES': {'ar': 'مسلسل', 'fr': 'SÉRIE', 'tr': 'DİZİ'},
 'Season': {'ar': 'الموسم', 'fr': 'Saison', 'tr': 'Sezon'},
 'Series options': {'ar': 'خيارات المسلسل', 'fr': 'Options de la série', 'tr': 'Dizi seçenekleri'},
 'Set as Home Hero': {'ar': 'تعيين كصورة الرئيسية', 'fr': 'Définir comme visuel d’accueil', 'tr': 'Ana Sayfa görseli yap'},
 'Starting Ultra Stalker': {'ar': 'جارٍ تشغيل Ultra Stalker', 'fr': 'Démarrage d’Ultra Stalker', 'tr': 'Ultra Stalker başlatılıyor'},
 'Unfavorite': {'ar': 'إزالة من المفضلة', 'fr': 'Retirer des favoris', 'tr': 'Favorilerden çıkar'},
 'Watched': {'ar': 'تمت المشاهدة', 'fr': 'Vu', 'tr': 'İzlendi'},
 'Year': {'ar': 'السنة', 'fr': 'Année', 'tr': 'Yıl'}})


_T.update({'Active threads        %d': {'ar': 'الخيوط النشطة        %d', 'fr': 'Threads actifs        %d', 'tr': 'Etkin iş parçacıkları  %d'},
 'Channel list mode      %s': {'ar': 'وضع قائمة القنوات      %s', 'fr': 'Mode de liste des chaînes %s', 'tr': 'Kanal listesi modu      %s'},
 'Clean titles           %s': {'ar': 'تنظيف العناوين         %s', 'fr': 'Nettoyage des titres    %s', 'tr': 'Başlık temizleme        %s'},
 'Database health       %s': {'ar': 'حالة قاعدة البيانات    %s', 'fr': 'État de la base         %s', 'tr': 'Veritabanı durumu       %s'},
 'Diagnostics refreshed at %s': {'ar': 'تم تحديث التشخيص في %s', 'fr': 'Diagnostics actualisés à %s', 'tr': 'Tanılama %s saatinde yenilendi'},
 'Endurance guard       %s': {'ar': 'حماية الاستمرارية      %s', 'fr': 'Protection d’endurance  %s', 'tr': 'Dayanıklılık koruması   %s'},
 'Export failed: %s': {'ar': 'فشل التصدير: %s', 'fr': 'Échec de l’export : %s', 'tr': 'Dışa aktarma başarısız: %s'},
 'Exported: %s': {'ar': 'تم التصدير: %s', 'fr': 'Exporté : %s', 'tr': 'Dışa aktarıldı: %s'},
 'HTTP performance      %s req • avg %sms • keepalive %s': {'ar': 'أداء HTTP             %s طلب • المتوسط %s ملث • keepalive %s',
                                                            'fr': 'Performances HTTP      %s req • moy. %s ms • keepalive %s',
                                                            'tr': 'HTTP performansı       %s istek • ort. %s ms • keepalive %s'},
 'Image cache           %d files  •  %.1f MB': {'ar': 'ذاكرة الصور            %d ملف  •  %.1f م.ب',
                                                'fr': 'Cache d’images          %d fichiers  •  %.1f Mo',
                                                'tr': 'Görsel önbelleği       %d dosya  •  %.1f MB'},
 'Last portal error     %s': {'ar': 'آخر خطأ Portal         %s', 'fr': 'Dernière erreur portail %s', 'tr': 'Son portal hatası       %s'},
 'Last portal success   %s': {'ar': 'آخر نجاح Portal        %s', 'fr': 'Dernier succès portail  %s', 'tr': 'Son portal başarısı     %s'},
 'Never': {'ar': 'أبدًا', 'fr': 'Jamais', 'tr': 'Hiçbir zaman'},
 'None': {'ar': 'لا يوجد', 'fr': 'Aucun', 'tr': 'Yok'},
 'Persistent cache      %d files  •  %.1f MB  •  %s': {'ar': 'الذاكرة الدائمة        %d ملف  •  %.1f م.ب  •  %s',
                                                       'fr': 'Cache persistant       %d fichiers  •  %.1f Mo  •  %s',
                                                       'tr': 'Kalıcı önbellek        %d dosya  •  %.1f MB  •  %s'},
 'Platform              %s': {'ar': 'المنصة                 %s', 'fr': 'Plateforme             %s', 'tr': 'Platform               %s'},
 'Playback preference   %s': {'ar': 'تفضيل التشغيل          %s', 'fr': 'Préférence de lecture  %s', 'tr': 'Oynatma tercihi        %s'},
 'Plugin version        %s  •  %s': {'ar': 'إصدار البلجن           %s  •  %s',
                                     'fr': 'Version du plugin      %s  •  %s',
                                     'tr': 'Eklenti sürümü         %s  •  %s'},
 'Portal selected       %s': {'ar': 'الـPortal المحدد       %s', 'fr': 'Portail sélectionné     %s', 'tr': 'Seçili portal           %s'},
 'Process health        %s': {'ar': 'حالة العملية           %s', 'fr': 'État du processus       %s', 'tr': 'İşlem durumu            %s'},
 'Python                %s': {'ar': 'Python                %s', 'fr': 'Python                %s', 'tr': 'Python                %s'},
 'Python support        %s': {'ar': 'دعم Python             %s', 'fr': 'Prise en charge Python %s', 'tr': 'Python desteği          %s'},
 'SQLite page state     %s runs • avg %sms': {'ar': 'حالة صفحات SQLite      %s تشغيل • المتوسط %s ملث',
                                              'fr': 'État des pages SQLite   %s exéc. • moy. %s ms',
                                              'tr': 'SQLite sayfa durumu     %s çalışma • ort. %s ms'},
 'Saved backups          %d': {'ar': 'النسخ الاحتياطية       %d', 'fr': 'Sauvegardes enregistrées %d', 'tr': 'Kayıtlı yedekler        %d'},
 'Search performance    %s runs • avg %sms': {'ar': 'أداء البحث             %s تشغيل • المتوسط %s ملث',
                                              'fr': 'Performances recherche %s exéc. • moy. %s ms',
                                              'tr': 'Arama performansı       %s çalışma • ort. %s ms'},
 'Smart engine memories  %s': {'ar': 'ذاكرة Smart Engine      %s', 'fr': 'Mémoires Smart Engine   %s', 'tr': 'Smart Engine kayıtları  %s'},
 'Smart recovery         %s / retries %s': {'ar': 'Smart Recovery          %s / المحاولات %s',
                                            'fr': 'Smart Recovery          %s / tentatives %s',
                                            'tr': 'Smart Recovery          %s / deneme %s'},
 'TLS security          %s': {'ar': 'أمان TLS               %s', 'fr': 'Sécurité TLS            %s', 'tr': 'TLS güvenliği           %s'},
 'Theme                 %s': {'ar': 'المظهر                 %s', 'fr': 'Thème                  %s', 'tr': 'Tema                   %s'},
 'UNVERIFIED / COMPATIBLE': {'ar': 'غير موثّق / متوافق', 'fr': 'NON VÉRIFIÉ / COMPATIBLE', 'tr': 'DOĞRULANMAMIŞ / UYUMLU'},
 'VERIFIED / STRICT-AUTO': {'ar': 'موثّق / STRICT-AUTO', 'fr': 'VÉRIFIÉ / STRICT-AUTO', 'tr': 'DOĞRULANMIŞ / STRICT-AUTO'},
 'unknown': {'ar': 'غير معروف', 'fr': 'inconnu', 'tr': 'bilinmiyor'}})


_T.update({'%d selected  •  OK Select  •  GREEN Import Selected  •  YELLOW Select All  •  RED Clear  •  BACK Portal Manager': {'ar': '%d محدد  •  OK اختيار  '
                                                                                                                           '•  الأخضر استيراد '
                                                                                                                           'المحدد  •  الأصفر تحديد '
                                                                                                                           'الكل  •  الأحمر مسح  •  '
                                                                                                                           'BACK إدارة البوابات',
                                                                                                                     'fr': '%d sélectionné(s)  •  OK '
                                                                                                                           'Sélectionner  •  VERT '
                                                                                                                           'Importer  •  JAUNE Tout '
                                                                                                                           'sélectionner  •  ROUGE '
                                                                                                                           'Effacer  •  BACK '
                                                                                                                           'Gestionnaire de portails',
                                                                                                                     'tr': '%d seçili  •  OK Seç  •  '
                                                                                                                           'YEŞİL Seçileni içe '
                                                                                                                           'aktar  •  SARI Tümünü '
                                                                                                                           'seç  •  KIRMIZI Temizle  '
                                                                                                                           '•  BACK Portal '
                                                                                                                           'Yöneticisi'},
 '%s  •  Page %d / %d  •  Source %d / %d': {'ar': '%s  •  الصفحة %d / %d  •  المصدر %d / %d',
                                            'fr': '%s  •  Page %d / %d  •  Source %d / %d',
                                            'tr': '%s  •  Sayfa %d / %d  •  Kaynak %d / %d'},
 '%s • DOWN recent • YELLOW new hero • OK open • BACK portals': {'ar': '%s • DOWN الأحدث • YELLOW صورة رئيسية جديدة • OK فتح • BACK البوابات',
                                                                 'fr': '%s • BAS récents • JAUNE nouveau visuel • OK ouvrir • BACK portails',
                                                                 'tr': '%s • AŞAĞI son içerikler • SARI yeni ana görsel • OK aç • BACK portallar'},
 '%s • LEFT / RIGHT switch • UP menu • OK resume': {'ar': '%s • LEFT / RIGHT تبديل • UP القائمة • OK استكمال',
                                                    'fr': '%s • GAUCHE / DROITE changer • HAUT menu • OK reprendre',
                                                    'tr': '%s • SOL / SAĞ değiştir • YUKARI menü • OK devam et'},
 '%s • Library is empty': {'ar': '%s • المكتبة فارغة', 'fr': '%s • La bibliothèque est vide', 'tr': '%s • Kütüphane boş'},
 'Checking %d portals...': {'ar': 'جارٍ فحص %d بوابة...', 'fr': 'Vérification de %d portails...', 'tr': '%d portal kontrol ediliyor...'},
 'Clear portal data failed: %s': {'ar': 'فشل مسح بيانات الـPortal: %s',
                                  'fr': 'Échec de l’effacement des données du portail : %s',
                                  'tr': 'Portal verileri temizlenemedi: %s'},
 'Delete failed: %s': {'ar': 'فشل الحذف: %s', 'fr': 'Échec de la suppression : %s', 'tr': 'Silme başarısız: %s'},
 'Disabled %d failed portal(s)': {'ar': 'تم تعطيل %d بوابة فاشلة',
                                  'fr': '%d portail(s) en échec désactivé(s)',
                                  'tr': '%d başarısız portal devre dışı bırakıldı'},
 'Disabling failed portals failed: %s': {'ar': 'فشل تعطيل البوابات غير العاملة: %s',
                                         'fr': 'Échec de la désactivation des portails en échec : %s',
                                         'tr': 'Başarısız portallar devre dışı bırakılamadı: %s'},
 'Duplicate failed: %s': {'ar': 'فشل إنشاء نسخة: %s', 'fr': 'Échec de la duplication : %s', 'tr': 'Kopyalama başarısız: %s'},
 'Enable failed: %s': {'ar': 'فشل التفعيل: %s', 'fr': 'Échec de l’activation : %s', 'tr': 'Etkinleştirme başarısız: %s'},
 'M3U failed: %s': {'ar': 'فشل M3U: %s', 'fr': 'Échec M3U : %s', 'tr': 'M3U başarısız: %s'},
 'M3U playlist could not be opened:\n\n%s': {'ar': 'تعذر فتح قائمة M3U:\n\n%s',
                                             'fr': 'Impossible d’ouvrir la playlist M3U :\n\n%s',
                                             'tr': 'M3U oynatma listesi açılamadı:\n\n%s'},
 'No disabled portals.': {'ar': 'لا توجد بوابات معطلة.', 'fr': 'Aucun portail désactivé.', 'tr': 'Devre dışı portal yok.'},
 'No downloads yet': {'ar': 'لا توجد تنزيلات بعد', 'fr': 'Aucun téléchargement pour le moment', 'tr': 'Henüz indirme yok'},
 'Opening %s...': {'ar': 'جارٍ فتح %s...', 'fr': 'Ouverture de %s...', 'tr': '%s açılıyor...'},
 'Permanent delete • %d portals selected • OK Confirm • BACK Return': {'ar': 'حذف نهائي • تم تحديد %d بوابة • OK تأكيد • BACK رجوع',
                                                                       'fr': 'Suppression définitive • %d portail(s) sélectionné(s) • OK Confirmer • '
                                                                             'BACK Retour',
                                                                       'tr': 'Kalıcı silme • %d portal seçili • OK Onayla • BACK Geri'},
 'Portal and related plugin data permanently deleted': {'ar': 'تم حذف الـPortal وبيانات البلجن المرتبطة به نهائيًا',
                                                        'fr': 'Le portail et les données associées du plugin ont été supprimés définitivement',
                                                        'tr': 'Portal ve ilişkili eklenti verileri kalıcı olarak silindi'},
 'Portal data cleared with warnings: %s': {'ar': 'تم مسح بيانات الـPortal مع تحذيرات: %s',
                                           'fr': 'Données du portail effacées avec avertissements : %s',
                                           'tr': 'Portal verileri uyarılarla temizlendi: %s'},
 'Portal deleted with cleanup warning: %s': {'ar': 'تم حذف الـPortal مع تحذير أثناء التنظيف: %s',
                                             'fr': 'Portail supprimé avec avertissement de nettoyage : %s',
                                             'tr': 'Portal temizleme uyarısıyla silindi: %s'},
 'Portal ready': {'ar': 'الـPortal جاهز', 'fr': 'Portail prêt', 'tr': 'Portal hazır'},
 'Re-open the movie/episode and choose Download again to refresh its portal link.': {'ar': 'أعد فتح الفيلم/الحلقة واختر تنزيل مرة أخرى لتحديث رابط '
                                                                                           'الـPortal.',
                                                                                     'fr': 'Rouvrez le film/l’épisode puis choisissez à nouveau '
                                                                                           'Télécharger pour actualiser son lien portail.',
                                                                                     'tr': 'Portal bağlantısını yenilemek için filmi/bölümü yeniden '
                                                                                           'açın ve tekrar İndir’i seçin.'},
 'Recovered malformed data safely • %s': {'ar': 'تم إصلاح البيانات غير السليمة بأمان • %s',
                                          'fr': 'Données malformées récupérées en toute sécurité • %s',
                                          'tr': 'Bozuk veriler güvenle kurtarıldı • %s'},
 'Select Portals • %d selected • OK Toggle • YELLOW Select all • RED Clear • BLUE Delete selected • BACK Portal Manager': {'ar': 'تحديد البوابات • '
                                                                                                                                 '%d محدد • OK تبديل '
                                                                                                                                 '• الأصفر تحديد '
                                                                                                                                 'الكل • الأحمر مسح '
                                                                                                                                 '• الأزرق حذف '
                                                                                                                                 'المحدد • BACK '
                                                                                                                                 'إدارة البوابات',
                                                                                                                           'fr': 'Sélectionner les '
                                                                                                                                 'portails • %d '
                                                                                                                                 'sélectionné(s) • '
                                                                                                                                 'OK Basculer • '
                                                                                                                                 'JAUNE Tout '
                                                                                                                                 'sélectionner • '
                                                                                                                                 'ROUGE Effacer • '
                                                                                                                                 'BLEU Supprimer • '
                                                                                                                                 'BACK Gestionnaire',
                                                                                                                           'tr': 'Portalları seç • '
                                                                                                                                 '%d seçili • OK '
                                                                                                                                 'Değiştir • SARI '
                                                                                                                                 'Tümünü seç • '
                                                                                                                                 'KIRMIZI Temizle • '
                                                                                                                                 'MAVİ Seçileni sil '
                                                                                                                                 '• BACK Portal '
                                                                                                                                 'Yöneticisi'},
 'channel': {'ar': 'القناة', 'fr': 'la chaîne', 'tr': 'kanal'},
 'saved item': {'ar': 'المحتوى المحفوظ', 'fr': 'l’élément enregistré', 'tr': 'kayıtlı içerik'}})


# Final Browser/utility chrome audit. These are plugin-owned labels only;
# provider names, URLs, credentials, categories and media metadata remain raw.
_T.update({
    "%d categories": {"ar":"%d قسم","fr":"%d catégories","tr":"%d kategori"},
    "%d channels": {"ar":"%d قناة","fr":"%d chaînes","tr":"%d kanal"},
    "%d items": {"ar":"%d عنصر","fr":"%d éléments","tr":"%d öğe"},
    "%d items • %d/%d": {"ar":"%d عنصر • %d/%d","fr":"%d éléments • %d/%d","tr":"%d öğe • %d/%d"},
    "%d programmes": {"ar":"%d برنامج","fr":"%d programmes","tr":"%d program"},
    "%d results": {"ar":"%d نتيجة","fr":"%d résultats","tr":"%d sonuç"},
    "%s  /  Categories": {"ar":"%s  /  الأقسام","fr":"%s  /  Catégories","tr":"%s  /  Kategoriler"},
    "%s  /  Content": {"ar":"%s  /  المحتوى","fr":"%s  /  Contenu","tr":"%s  /  İçerik"},
    "%s  /  Search: %s": {"ar":"%s  /  بحث: %s","fr":"%s  /  Recherche : %s","tr":"%s  /  Arama: %s"},
    "Account info failed: %s": {"ar":"فشل تحميل معلومات الحساب: %s","fr":"Échec du chargement des informations du compte : %s","tr":"Hesap bilgileri yüklenemedi: %s"},
    "Archive": {"ar":"الأرشيف","fr":"Archive","tr":"Arşiv"},
    "Archive EPG failed: %s": {"ar":"فشل تحميل EPG للأرشيف: %s","fr":"Échec du chargement de l’EPG de l’archive : %s","tr":"Arşiv EPG'si yüklenemedi: %s"},
    "Audio selection is not available in this image": {"ar":"اختيار مسار الصوت غير متاح في هذه الـImage","fr":"La sélection de la piste audio n’est pas disponible sur cette image","tr":"Bu imajda ses parçası seçimi kullanılamıyor"},
    "Average Latency: %s ms": {"ar":"متوسط زمن الاستجابة: %s مللي ثانية","fr":"Latence moyenne : %s ms","tr":"Ortalama gecikme: %s ms"},
    "CATCH-UP": {"ar":"مشاهدة مؤجلة","fr":"CATCH-UP","tr":"GERİ İZLE"},
    "Catch-up  /  %s": {"ar":"المشاهدة المؤجلة  /  %s","fr":"Catch-up  /  %s","tr":"Geri İzle  /  %s"},
    "Catch-up failed: %s": {"ar":"فشل تحميل المشاهدة المؤجلة: %s","fr":"Échec du chargement du Catch-up : %s","tr":"Geri izleme yüklenemedi: %s"},
    "Catch-up play failed: %s": {"ar":"فشل تشغيل المشاهدة المؤجلة: %s","fr":"Échec de la lecture Catch-up : %s","tr":"Geri izleme oynatılamadı: %s"},
    "Catch-up programme": {"ar":"برنامج مؤجل","fr":"Programme Catch-up","tr":"Geri izleme programı"},
    "Channel": {"ar":"قناة","fr":"Chaîne","tr":"Kanal"},
    "Hidden categories": {"ar":"الأقسام المخفية","fr":"Catégories masquées","tr":"Gizli kategoriler"},
    "Loading catch-up": {"ar":"جارٍ تحميل المشاهدة المؤجلة","fr":"Chargement du Catch-up","tr":"Geri izleme yükleniyor"},
    "No EPG information": {"ar":"لا تتوفر معلومات EPG","fr":"Aucune information EPG","tr":"EPG bilgisi yok"},
    "No account data returned": {"ar":"لم يتم إرجاع بيانات للحساب","fr":"Aucune donnée de compte reçue","tr":"Hesap verisi alınamadı"},
    "No archive data": {"ar":"لا توجد بيانات أرشيف","fr":"Aucune donnée d’archive","tr":"Arşiv verisi yok"},
    "No archived programmes": {"ar":"لا توجد برامج مؤرشفة","fr":"Aucun programme archivé","tr":"Arşivlenmiş program yok"},
    "No catch-up channels": {"ar":"لا توجد قنوات للمشاهدة المؤجلة","fr":"Aucune chaîne Catch-up","tr":"Geri izleme kanalı yok"},
    "No saved content": {"ar":"لا يوجد محتوى محفوظ","fr":"Aucun contenu enregistré","tr":"Kaydedilmiş içerik yok"},
    "No search results": {"ar":"لا توجد نتائج بحث","fr":"Aucun résultat de recherche","tr":"Arama sonucu yok"},
    "Page %d  •  %d items": {"ar":"صفحة %d  •  %d عنصر","fr":"Page %d  •  %d éléments","tr":"Sayfa %d  •  %d öğe"},
    "Picon cache failed": {"ar":"فشل تخزين Picons مؤقتًا","fr":"Échec de la mise en cache des Picons","tr":"Picon önbelleğe alma başarısız"},
    "Picons %d/%d • %d cached • %d downloaded • %d failed": {"ar":"Picons %d/%d • %d مخزنة مؤقتًا • %d تم تنزيلها • %d فشلت","fr":"Picons %d/%d • %d en cache • %d téléchargés • %d échecs","tr":"Picon %d/%d • %d önbellekte • %d indirildi • %d başarısız"},
    "Picons ready • %d/%d • %d cached • %d downloaded • %d failed": {"ar":"Picons جاهزة • %d/%d • %d مخزنة مؤقتًا • %d تم تنزيلها • %d فشلت","fr":"Picons prêts • %d/%d • %d en cache • %d téléchargés • %d échecs","tr":"Piconlar hazır • %d/%d • %d önbellekte • %d indirildi • %d başarısız"},
    "Portal Health: %s": {"ar":"حالة البوابة: %s","fr":"État du portail : %s","tr":"Portal durumu: %s"},
    "Programme": {"ar":"برنامج","fr":"Programme","tr":"Program"},
    "RESUME": {"ar":"استكمال","fr":"REPRENDRE","tr":"DEVAM ET"},
    "Scanning Live categories %d / %d": {"ar":"جارٍ فحص أقسام البث المباشر %d / %d","fr":"Analyse des catégories Live %d / %d","tr":"Canlı kategoriler taranıyor %d / %d"},
    "Try another channel": {"ar":"جرّب قناة أخرى","fr":"Essayez une autre chaîne","tr":"Başka bir kanal deneyin"},
    "Use MENU on a category to toggle it.": {"ar":"استخدم MENU على القسم لإظهاره أو إخفائه.","fr":"Utilisez MENU sur une catégorie pour l’afficher ou la masquer.","tr":"Bir kategoriyi göstermek veya gizlemek için üzerinde MENU tuşunu kullanın."},
    "Watch-state update failed: %s": {"ar":"فشل تحديث حالة المشاهدة: %s","fr":"Échec de la mise à jour de l’état de visionnage : %s","tr":"İzleme durumu güncellenemedi: %s"},
})


_T.update({
    " • %d portal error(s)": {"ar":" • %d خطأ في البوابات","fr":" • %d erreur(s) de portail","tr":" • %d portal hatası"},
    "%d results • %d portals": {"ar":"%d نتيجة • %d بوابة","fr":"%d résultats • %d portails","tr":"%d sonuç • %d portal"},
    "%s • %d%% watched": {"ar":"%s • تمت مشاهدة %d%%","fr":"%s • %d%% regardé","tr":"%s • %d%% izlendi"},
    "%s • Resume": {"ar":"%s • استكمال","fr":"%s • Reprendre","tr":"%s • Devam et"},
    "%s • open": {"ar":"%s • فتح","fr":"%s • Ouvrir","tr":"%s • Aç"},
    "Episode": {"ar":"حلقة","fr":"Épisode","tr":"Bölüm"},
    "Expires: %s": {"ar":"ينتهي: %s","fr":"Expire : %s","tr":"Bitiş: %s"},
    "Global portal search": {"ar":"البحث الشامل في البوابات","fr":"Recherche globale des portails","tr":"Genel portal araması"},
    "LIVE TV": {"ar":"البث المباشر","fr":"TV EN DIRECT","tr":"CANLI TV"},
    "Movie": {"ar":"فيلم","fr":"Film","tr":"Film"},
    "Open a channel and it will appear here": {"ar":"افتح قناة وستظهر هنا","fr":"Ouvrez une chaîne et elle apparaîtra ici","tr":"Bir kanal açın, burada görünecek"},
    "Portal": {"ar":"بوابة","fr":"Portail","tr":"Portal"},
    "Portal Connected": {"ar":"البوابة متصلة","fr":"Portail connecté","tr":"Portal bağlı"},
    "Recent: %s": {"ar":"الأخيرة: %s","fr":"Récentes : %s","tr":"Son aramalar: %s"},
    "Result": {"ar":"نتيجة","fr":"Résultat","tr":"Sonuç"},
    "Results will appear as portals finish": {"ar":"ستظهر النتائج مع اكتمال بحث البوابات","fr":"Les résultats apparaîtront à mesure que les portails terminent la recherche","tr":"Portallar aramayı tamamladıkça sonuçlar görünecek"},
    "Search keyboard is unavailable on this image.": {"ar":"لوحة مفاتيح البحث غير متاحة في هذه الـImage.","fr":"Le clavier de recherche n’est pas disponible sur cette image.","tr":"Bu imajda arama klavyesi kullanılamıyor."},
    "Searching...": {"ar":"جارٍ البحث...","fr":"Recherche...","tr":"Aranıyor..."},
    "Searching... %d result(s) found": {"ar":"جارٍ البحث... تم العثور على %d نتيجة","fr":"Recherche... %d résultat(s) trouvé(s)","tr":"Aranıyor... %d sonuç bulundu"},
    "Try another term": {"ar":"جرّب عبارة أخرى","fr":"Essayez un autre terme","tr":"Başka bir ifade deneyin"},
    "Watch a movie and it will appear here": {"ar":"شاهد فيلمًا وسيظهر هنا","fr":"Regardez un film et il apparaîtra ici","tr":"Bir film izleyin, burada görünecek"},
    "Watch a series and it will appear here": {"ar":"شاهد مسلسلًا وسيظهر هنا","fr":"Regardez une série et elle apparaîtra ici","tr":"Bir dizi izleyin, burada görünecek"},
    "Watched • play again": {"ar":"تمت المشاهدة • تشغيل مرة أخرى","fr":"Vu • Relire","tr":"İzlendi • Tekrar oynat"},
})


# Final localization completion audit: remaining plugin-owned labels and
# player chrome. Provider-originated Portal/M3U/Xtream data is never routed
# through these keys.
_T.update({
    " • %d portal error(s)": {"ar":" • %d خطأ في البوابات","fr":" • %d erreur(s) de portail","tr":" • %d portal hatası"},
    "%d results • %d portals": {"ar":"%d نتيجة • %d بوابة","fr":"%d résultats • %d portails","tr":"%d sonuç • %d portal"},
    "%s • %d%% watched": {"ar":"%s • تمت مشاهدة %d%%","fr":"%s • %d%% regardé","tr":"%s • %d%% izlendi"},
    "%s • Resume": {"ar":"%s • استكمال","fr":"%s • Reprendre","tr":"%s • Devam Et"},
    "%s • open": {"ar":"%s • فتح","fr":"%s • ouvrir","tr":"%s • aç"},
    "Episode": {"ar":"حلقة","fr":"Épisode","tr":"Bölüm"},
    "Expires: %s": {"ar":"ينتهي: %s","fr":"Expire : %s","tr":"Bitiş: %s"},
    "Global portal search": {"ar":"بحث شامل في البوابات","fr":"Recherche globale des portails","tr":"Genel portal araması"},
    "LIVE TV": {"ar":"البث المباشر","fr":"TV EN DIRECT","tr":"CANLI TV"},
    "Movie": {"ar":"فيلم","fr":"Film","tr":"Film"},
    "Open a channel and it will appear here": {"ar":"افتح قناة وستظهر هنا","fr":"Ouvrez une chaîne et elle apparaîtra ici","tr":"Bir kanal açın; burada görünecektir"},
    "Portal": {"ar":"بوابة","fr":"Portail","tr":"Portal"},
    "Portal Connected": {"ar":"البوابة متصلة","fr":"Portail connecté","tr":"Portal bağlı"},
    "Recent: %s": {"ar":"الأخيرة: %s","fr":"Récent : %s","tr":"Son: %s"},
    "Result": {"ar":"نتيجة","fr":"Résultat","tr":"Sonuç"},
    "Results will appear as portals finish": {"ar":"ستظهر النتائج عند انتهاء كل بوابة","fr":"Les résultats apparaîtront à mesure que les portails terminent","tr":"Portallar tamamlandıkça sonuçlar görünecek"},
    "Search keyboard is unavailable on this image.": {"ar":"لوحة مفاتيح البحث غير متاحة في هذه الـImage.","fr":"Le clavier de recherche n’est pas disponible sur cette image.","tr":"Bu imajda arama klavyesi kullanılamıyor."},
    "Searching...": {"ar":"جارٍ البحث...","fr":"Recherche...","tr":"Aranıyor..."},
    "Searching... %d result(s) found": {"ar":"جارٍ البحث... تم العثور على %d نتيجة","fr":"Recherche... %d résultat(s) trouvé(s)","tr":"Aranıyor... %d sonuç bulundu"},
    "Try another term": {"ar":"جرّب عبارة أخرى","fr":"Essayez un autre terme","tr":"Başka bir terim deneyin"},
    "Watch a movie and it will appear here": {"ar":"شاهد فيلمًا وسيظهر هنا","fr":"Regardez un film et il apparaîtra ici","tr":"Bir film izleyin; burada görünecektir"},
    "Watch a series and it will appear here": {"ar":"شاهد مسلسلًا وسيظهر هنا","fr":"Regardez une série et elle apparaîtra ici","tr":"Bir dizi izleyin; burada görünecektir"},
    "Watched • play again": {"ar":"تمت المشاهدة • تشغيل مرة أخرى","fr":"Vu • relire","tr":"İzlendi • tekrar oynat"},

    "Delete %d selected portals": {"ar":"حذف %d بوابة محددة","fr":"Supprimer %d portails sélectionnés","tr":"Seçili %d portalı sil"},
    "PERMANENT": {"ar":"نهائي","fr":"DÉFINITIF","tr":"KALICI"},
    "Keep all portals": {"ar":"الاحتفاظ بكل البوابات","fr":"Conserver tous les portails","tr":"Tüm portalları koru"},

    "UP / DOWN  Read description     •     YELLOW / OK / BACK  Close": {"ar":"UP / DOWN قراءة الوصف     •     YELLOW / OK / BACK إغلاق","fr":"UP / DOWN Lire la description     •     YELLOW / OK / BACK Fermer","tr":"UP / DOWN Açıklamayı oku     •     YELLOW / OK / BACK Kapat"},
    "◀▶  Page": {"ar":"◀▶  صفحة","fr":"◀▶  Page","tr":"◀▶  Sayfa"},
    "OK  Play": {"ar":"OK  تشغيل","fr":"OK  Lire","tr":"OK  Oynat"},
    "BACK  Close": {"ar":"BACK  إغلاق","fr":"BACK  Fermer","tr":"BACK  Kapat"},
    "Play Next Episode": {"ar":"تشغيل الحلقة التالية","fr":"Lire l’épisode suivant","tr":"Sonraki Bölümü Oynat"},
    "OK Play now   •   BACK Cancel   •   YELLOW Disable autoplay": {"ar":"OK تشغيل الآن   •   BACK إلغاء   •   YELLOW تعطيل التشغيل التلقائي","fr":"OK Lire maintenant   •   BACK Annuler   •   YELLOW Désactiver la lecture auto","tr":"OK Şimdi oynat   •   BACK İptal   •   YELLOW Otomatik oynatmayı kapat"},
    "Live TV / Movies / Series": {"ar":"البث المباشر / الأفلام / المسلسلات","fr":"TV en direct / Films / Séries","tr":"Canlı TV / Filmler / Diziler"},
    "PREPARING STREAM": {"ar":"جارٍ تجهيز البث","fr":"PRÉPARATION DU FLUX","tr":"YAYIN HAZIRLANIYOR"},
    "PLAY": {"ar":"تشغيل","fr":"LIRE","tr":"OYNAT"},
    "NEXT": {"ar":"التالي","fr":"SUIVANT","tr":"SONRAKİ"},
    "STREAM": {"ar":"البث","fr":"FLUX","tr":"YAYIN"},
    "VIDEO": {"ar":"فيديو","fr":"VIDÉO","tr":"VİDEO"},
    "AUDIO": {"ar":"الصوت","fr":"AUDIO","tr":"SES"},
    "Bitrate --": {"ar":"معدل البت --","fr":"Débit --","tr":"Bit hızı --"},
    "SUBTITLES": {"ar":"الترجمة","fr":"SOUS-TITRES","tr":"ALTYAZILAR"},
    "<< Rewind   >> Forward   0 Restart": {"ar":"<< رجوع   >> تقديم   0 إعادة البدء","fr":"<< Retour   >> Avance   0 Recommencer","tr":"<< Geri   >> İleri   0 Baştan"},
    "Exit": {"ar":"خروج","fr":"Quitter","tr":"Çıkış"},
    "Aspect Ratio": {"ar":"نسبة العرض","fr":"Format d’image","tr":"En-Boy Oranı"},
    "Engine Locked": {"ar":"المحرك مثبت","fr":"Moteur verrouillé","tr":"Motor Kilitli"},
    "RESUMING  •  preparing bookmark": {"ar":"جارٍ الاستكمال  •  تجهيز نقطة الحفظ","fr":"REPRISE  •  préparation du signet","tr":"DEVAM EDİLİYOR  •  yer imi hazırlanıyor"},
    "PLAYING": {"ar":"قيد التشغيل","fr":"LECTURE","tr":"OYNATILIYOR"},
    "STREAM INTERRUPTED  •  press 0 to restart": {"ar":"انقطع البث  •  اضغط 0 لإعادة التشغيل","fr":"FLUX INTERROMPU  •  appuyez sur 0 pour recommencer","tr":"YAYIN KESİLDİ  •  yeniden başlatmak için 0'a basın"},
    "PLAYBACK FAILED": {"ar":"فشل التشغيل","fr":"ÉCHEC DE LA LECTURE","tr":"OYNATMA BAŞARISIZ"},
    "SWITCHING CHANNEL...": {"ar":"جارٍ تغيير القناة...","fr":"CHANGEMENT DE CHAÎNE...","tr":"KANAL DEĞİŞTİRİLİYOR..."},
    "PLAYING  •  resume unavailable": {"ar":"قيد التشغيل  •  الاستكمال غير متاح","fr":"LECTURE  •  reprise indisponible","tr":"OYNATILIYOR  •  devam kullanılamıyor"},
    "SEARCHING  •  SUBDL ARABIC": {"ar":"جارٍ البحث  •  SUBDL عربي","fr":"RECHERCHE  •  SUBDL ARABE","tr":"ARANIYOR  •  SUBDL ARAPÇA"},
    "PLAYING  •  NO ARABIC SUBTITLE": {"ar":"قيد التشغيل  •  لا توجد ترجمة عربية","fr":"LECTURE  •  AUCUN SOUS-TITRE ARABE","tr":"OYNATILIYOR  •  ARAPÇA ALTYAZI YOK"},
    "DOWNLOADING  •  ARABIC SUBTITLE": {"ar":"جارٍ التنزيل  •  ترجمة عربية","fr":"TÉLÉCHARGEMENT  •  SOUS-TITRE ARABE","tr":"İNDİRİLİYOR  •  ARAPÇA ALTYAZI"},
    "PLAYING  •  ARABIC SUBTITLES": {"ar":"قيد التشغيل  •  ترجمة عربية","fr":"LECTURE  •  SOUS-TITRES ARABES","tr":"OYNATILIYOR  •  ARAPÇA ALTYAZILAR"},
    "CHANNEL SWITCH UNAVAILABLE": {"ar":"تغيير القناة غير متاح","fr":"CHANGEMENT DE CHAÎNE INDISPONIBLE","tr":"KANAL DEĞİŞTİRME KULLANILAMIYOR"},
    "CHANNEL SWITCH IN PROGRESS...": {"ar":"جارٍ تغيير القناة...","fr":"CHANGEMENT DE CHAÎNE EN COURS...","tr":"KANAL DEĞİŞTİRİLİYOR..."},
    "CHANNEL SWITCH FAILED": {"ar":"فشل تغيير القناة","fr":"ÉCHEC DU CHANGEMENT DE CHAÎNE","tr":"KANAL DEĞİŞTİRME BAŞARISIZ"},
    "MEMORY PROTECTION  •  playback preserved": {"ar":"حماية الذاكرة  •  تم الحفاظ على التشغيل","fr":"PROTECTION MÉMOIRE  •  lecture préservée","tr":"BELLEK KORUMASI  •  oynatma korundu"},
    "MEMORY SAFETY EXIT": {"ar":"خروج لحماية الذاكرة","fr":"SORTIE DE SÉCURITÉ MÉMOIRE","tr":"BELLEK GÜVENLİ ÇIKIŞI"},
    "PLAYING  •  SUBTITLES OFF": {"ar":"قيد التشغيل  •  الترجمة متوقفة","fr":"LECTURE  •  SOUS-TITRES DÉSACTIVÉS","tr":"OYNATILIYOR  •  ALTYAZILAR KAPALI"},
    "CHANNEL SWITCH TIMED OUT": {"ar":"انتهت مهلة تغيير القناة","fr":"DÉLAI DE CHANGEMENT DE CHAÎNE DÉPASSÉ","tr":"KANAL DEĞİŞTİRME ZAMAN AŞIMI"},
    "MEDIA INFO UNAVAILABLE": {"ar":"معلومات الوسائط غير متاحة","fr":"INFORMATIONS MÉDIA INDISPONIBLES","tr":"MEDYA BİLGİSİ KULLANILAMIYOR"},
})


_T.update({
    " • %d recovered": {"ar":" • تم استرجاع %d","fr":" • %d récupéré(s)","tr":" • %d kurtarıldı"},
    "%s\n\nNOW: %s\nNEXT: %s": {"ar":"%s\n\nالآن: %s\nالتالي: %s","fr":"%s\n\nMAINTENANT : %s\nSUIVANT : %s","tr":"%s\n\nŞİMDİ: %s\nSONRAKİ: %s"},
    "Artwork cache • %d/%d attempted • %d already cached • %d pending retry%s": {"ar":"كاش الصور • تمت محاولة %d/%d • %d مخزنة بالفعل • %d بانتظار إعادة المحاولة%s","fr":"Cache des illustrations • %d/%d tentées • %d déjà en cache • %d en attente de nouvel essai%s","tr":"Görsel önbelleği • %d/%d denendi • %d zaten önbellekte • %d yeniden denemeyi bekliyor%s"},
    "Artwork ready • %d/%d • %d already cached • 0 pending%s": {"ar":"الصور جاهزة • %d/%d • %d مخزنة بالفعل • 0 معلقة%s","fr":"Illustrations prêtes • %d/%d • %d déjà en cache • 0 en attente%s","tr":"Görseller hazır • %d/%d • %d zaten önbellekte • 0 beklemede%s"},
    "Caching 0 / %d": {"ar":"جارٍ التخزين 0 / %d","fr":"Mise en cache 0 / %d","tr":"Önbelleğe alınıyor 0 / %d"},
    "Channel %d": {"ar":"القناة %d","fr":"Chaîne %d","tr":"Kanal %d"},
    "EPG information will appear here": {"ar":"ستظهر معلومات EPG هنا","fr":"Les informations EPG apparaîtront ici","tr":"EPG bilgisi burada görünecek"},
    "NOW": {"ar":"الآن","fr":"MAINTENANT","tr":"ŞİMDİ"},
    "No EPG": {"ar":"لا يوجد EPG","fr":"Aucun EPG","tr":"EPG yok"},
    "No expiry": {"ar":"بدون تاريخ انتهاء","fr":"Aucune expiration","tr":"Süre sonu yok"},
    "OK Full Screen": {"ar":"OK ملء الشاشة","fr":"OK Plein écran","tr":"OK Tam Ekran"},
    "Search in %s": {"ar":"بحث في %s","fr":"Rechercher dans %s","tr":"%s içinde ara"},
})


_T.update({
    " • IMDb linked": {"ar":" • مرتبط بـ IMDb","fr":" • lié à IMDb","tr":" • IMDb bağlı"},
    "Could not save HTTP consent: %s": {"ar":"تعذر حفظ موافقة HTTP: %s","fr":"Impossible d’enregistrer l’autorisation HTTP : %s","tr":"HTTP onayı kaydedilemedi: %s"},
    "Invalid profile: %s": {"ar":"ملف تعريف غير صالح: %s","fr":"Profil invalide : %s","tr":"Geçersiz profil: %s"},
    "Portal metadata • HDD": {"ar":"بيانات البوابة • HDD","fr":"Métadonnées du portail • HDD","tr":"Portal meta verisi • HDD"},
    "Retrying %d failed picons only": {"ar":"إعادة محاولة %d من Picons الفاشلة فقط","fr":"Nouvel essai pour les %d Picons en échec uniquement","tr":"Yalnızca başarısız %d Picon yeniden deneniyor"},
    "TMDB • %d%% match": {"ar":"TMDB • تطابق %d%%","fr":"TMDB • correspondance %d%%","tr":"TMDB • %d%% eşleşme"},
    "UI error: %s": {"ar":"خطأ في الواجهة: %s","fr":"Erreur d’interface : %s","tr":"Arayüz hatası: %s"},
})

_T.update({
    "Check Artwork": {"ar":"فحص الصور","fr":"Vérifier les illustrations","tr":"Görselleri Kontrol Et"},
    "Checking...": {"ar":"جارٍ الفحص...","fr":"Vérification...","tr":"Kontrol ediliyor..."},
    "Artwork check is already running": {"ar":"فحص الصور قيد التشغيل بالفعل","fr":"La vérification des illustrations est déjà en cours","tr":"Görsel kontrolü zaten çalışıyor"},
    "Checking current folder for missing posters...": {"ar":"جارٍ فحص المجلد الحالي للبوسترات الناقصة...","fr":"Vérification des affiches manquantes dans le dossier actuel...","tr":"Geçerli klasörde eksik posterler kontrol ediliyor..."},
    "Checking current folder for missing artwork...": {"ar":"جارٍ فحص المجلد الحالي للصور الناقصة...","fr":"Vérification des illustrations manquantes dans le dossier actuel...","tr":"Geçerli klasörde eksik görseller kontrol ediliyor..."},
    "Artwork check • %d/%d fully cached • 0 missing": {"ar":"فحص الصور • %d/%d مكتمل في الكاش • 0 ناقص","fr":"Vérification • %d/%d entièrement en cache • 0 manquante","tr":"Görsel kontrolü • %d/%d tamamen önbellekte • 0 eksik"},
    "Artwork cache • posters %d/%d • backdrops %d/%d • %d still missing": {"ar":"كاش الصور • البوسترات %d/%d • الخلفيات %d/%d • ما زال %d ناقصًا","fr":"Cache images • affiches %d/%d • arrière-plans %d/%d • %d encore manquants","tr":"Görsel önbelleği • posterler %d/%d • arka planlar %d/%d • %d hâlâ eksik"},
    "Artwork cache • posters %d/%d (left %d) • backdrops %d/%d (left %d)": {"ar":"كاش الصور • البوسترات %d/%d (متبقي %d) • الخلفيات %d/%d (متبقي %d)","fr":"Cache images • affiches %d/%d (reste %d) • arrière-plans %d/%d (reste %d)","tr":"Görsel önbelleği • posterler %d/%d (kalan %d) • arka planlar %d/%d (kalan %d)"},
    "Artwork check • %d/%d posters ready • 0 missing": {"ar":"فحص الصور • %d/%d بوستر جاهز • 0 ناقص","fr":"Vérification • %d/%d affiches prêtes • 0 manquante","tr":"Görsel kontrolü • %d/%d poster hazır • 0 eksik"},
    "Artwork rescue • %d/%d missing posters recovered • %d still missing": {"ar":"إنقاذ البوسترات • تم استرجاع %d/%d • ما زال %d ناقصًا","fr":"Récupération • %d/%d affiches manquantes récupérées • %d encore manquantes","tr":"Poster kurtarma • %d/%d eksik poster kurtarıldı • %d hâlâ eksik"},
    "Artwork rescue • %d/%d missing posters recovered • 0 missing": {"ar":"إنقاذ البوسترات • تم استرجاع %d/%d • 0 ناقص","fr":"Récupération • %d/%d affiches manquantes récupérées • 0 manquante","tr":"Poster kurtarma • %d/%d eksik poster kurtarıldı • 0 eksik"},
})

def _settings_signature():
    try:
        st = os.stat(CONFIG_FILE)
        return (getattr(st, "st_mtime_ns", int(st.st_mtime * 1000000000)), st.st_size)
    except OSError:
        return None


def _read_language():
    global _CACHE_SIGNATURE, _CACHE_LANGUAGE
    sig = _settings_signature()
    with _LOCK:
        if _LANG_OVERRIDE in SUPPORTED_LANGUAGES:
            return _LANG_OVERRIDE
        if sig == _CACHE_SIGNATURE:
            return _CACHE_LANGUAGE
        code = "en"
        try:
            if sig and os.path.getsize(CONFIG_FILE) <= 1024 * 1024:
                with open(CONFIG_FILE, "r", encoding="utf-8") as handle:
                    data = json.load(handle)
                candidate = str((data or {}).get("plugin_language") or "en").strip().lower()
                if candidate in SUPPORTED_LANGUAGES:
                    code = candidate
        except Exception:
            code = "en"
        _CACHE_SIGNATURE = sig
        _CACHE_LANGUAGE = code
        return code


def set_plugin_language(code):
    global _LANG_OVERRIDE, _CACHE_LANGUAGE
    code = str(code or "en").strip().lower()
    if code not in SUPPORTED_LANGUAGES:
        code = "en"
    with _LOCK:
        _LANG_OVERRIDE = code
        _CACHE_LANGUAGE = code
    return code


def clear_language_override():
    global _LANG_OVERRIDE, _CACHE_SIGNATURE
    with _LOCK:
        _LANG_OVERRIDE = None
        _CACHE_SIGNATURE = None


def current_language():
    return _read_language()


def language_name(code=None):
    return LANGUAGE_NAMES.get(str(code or _read_language()).lower(), "English")


def _arabic_gettext(text):
    global _AR_GETTEXT
    try:
        if _AR_GETTEXT is None:
            path = os.path.join(LOCALE_DIR, "ar", "LC_MESSAGES", "UltraStalker.mo")
            with open(path, "rb") as handle:
                _AR_GETTEXT = gettext.GNUTranslations(handle)
        value = _AR_GETTEXT.gettext(text)
        return value if value != text else None
    except Exception:
        return None


def translate(text):
    if text is None:
        return ""
    original = str(text)
    code = _read_language()
    if code == "en" or not original:
        return original
    row = _T.get(original)
    if row:
        value = row.get(code)
        if value:
            return value
    if code == "ar":
        value = _arabic_gettext(original)
        if value:
            return value
    return original
