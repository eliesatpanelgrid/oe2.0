from enigma import getDesktop

from Components.ActionMap import ActionMap
from Components.config import config
from Plugins.Plugin import PluginDescriptor

from .GridPluginList import GridPluginList
from .Settings import openSetup


_PATCHED = False
_ORIGINAL_INIT = None
_ORIGINAL_RUN = None
_ORIGINAL_UPDATE = None
_ORIGINAL_MOVE = None


def _is_grid():
    try:
        return config.plugins.OBHPluginBrowserGrid.viewMode.value == "grid"
    except Exception:
        return True


def _full_screen_skin():
    size = getDesktop(0).size()
    w, h = size.width(), size.height()

    # Intentionally push the complete Grid farther to the RIGHT.
    # The right edge stays close to the screen edge.
    #
    # 1920 GUI -> 230px left inset
    # 1280 GUI -> 145px left inset
    # smaller  ->  90px left inset
    left_margin = 210 if w >= 1800 else 130 if w >= 1100 else 80
    right_margin = 22 if w >= 1800 else 16
    top_margin = 18 if h >= 1000 else 13

    title_h = 50 if h >= 1000 else 40
    bottom_h = 64 if h >= 1000 else 52
    gap = 10

    list_y = top_margin + title_h + gap
    list_w = w - left_margin - right_margin
    list_h = h - list_y - bottom_h - top_margin - gap

    font_title = 29 if h >= 1000 else 23
    font_button = 21 if h >= 1000 else 18

    button_gap = 12
    button_w = int((list_w - (button_gap * 2)) / 3)
    by = h - bottom_h - top_margin + 4

    return """
    <screen name="PluginBrowserOBHGrid"
            position="0,0"
            size="{w},{h}"
            flags="wfNoBorder"
            backgroundColor="#0d0f12">

        <widget source="Title" render="Label"
                position="{lx},{ty}"
                size="{lw},{th}"
                font="Regular;{ft}"
                halign="left" valign="center"
                foregroundColor="#f4f4f4"
                backgroundColor="#171a1f"
                transparent="0" />

        <widget name="list"
                position="{lx},{ly}"
                size="{lw},{lh}"
                scrollbarMode="showOnDemand"
                enableWrapAround="1"
                backgroundColor="#0d0f12"
                transparent="0" />

        <widget name="key_red"
                position="{lx},{by}"
                size="{bw},{bh}"
                font="Regular;{fb}"
                halign="center" valign="center"
                backgroundColor="#7f2525"
                foregroundColor="#ffffff" />

        <widget name="key_green"
                position="{gx},{by}"
                size="{bw},{bh}"
                font="Regular;{fb}"
                halign="center" valign="center"
                backgroundColor="#276b39"
                foregroundColor="#ffffff" />

        <widget source="key_menu" render="Label"
                position="{mx},{by}"
                size="{bw},{bh}"
                font="Regular;{fb}"
                halign="center" valign="center"
                backgroundColor="#252a30"
                foregroundColor="#ffffff" />
    </screen>
    """.format(
        w=w, h=h,
        lx=left_margin, ty=top_margin, lw=list_w, th=title_h, ft=font_title,
        ly=list_y, lh=list_h,
        by=by, bw=button_w, bh=bottom_h - 12, fb=font_button,
        gx=left_margin + button_w + button_gap,
        mx=left_margin + (button_w + button_gap) * 2,
    )


def _patched_run(self):
    if not _is_grid():
        return _ORIGINAL_RUN(self)

    item = self["list"].getCurrent()
    if not item:
        return

    try:
        plugin = item[0]
    except Exception:
        return

    if plugin:
        plugin(session=self.session)


def _patched_update(self):
    if not _is_grid():
        return _ORIGINAL_UPDATE(self)

    # Let OpenBH create/sort the canonical plugin entries first.
    _ORIGINAL_UPDATE(self)

    # Convert the flat OpenBH entries into grid rows.
    try:
        self["list"].setList(self.list)
    except Exception as err:
        print("[OBHPluginBrowserGrid] Grid update failed:", err)


def _patched_move(self, direction):
    if not _is_grid():
        return _ORIGINAL_MOVE(self, direction)

    if len(self.list) <= 1:
        return

    currentIndex = self["list"].getSelectionIndex()
    swapIndex = (currentIndex + direction) % len(self.list)

    if currentIndex == 0 and swapIndex != 1:
        self.list = self.list[1:] + [self.list[0]]
    elif swapIndex == 0 and currentIndex != 1:
        self.list = [self.list[-1]] + self.list[:-1]
    else:
        self.list[currentIndex], self.list[swapIndex] = (
            self.list[swapIndex],
            self.list[currentIndex],
        )

    self["list"].setList(self.list)
    self["list"].moveToIndex(swapIndex)

    try:
        plugin_order = [x[0].path[24:] for x in self.list]
        config.misc.pluginbrowser.plugin_order.value = ",".join(plugin_order)
        config.misc.pluginbrowser.plugin_order.save()
    except Exception as err:
        print("[OBHPluginBrowserGrid] Unable to save plugin order:", err)


def _install_patch():
    global _PATCHED, _ORIGINAL_INIT, _ORIGINAL_RUN, _ORIGINAL_UPDATE, _ORIGINAL_MOVE

    if _PATCHED:
        return

    import Screens.PluginBrowser as PB

    _ORIGINAL_INIT = PB.PluginBrowser.__init__
    _ORIGINAL_RUN = PB.PluginBrowser.run
    _ORIGINAL_UPDATE = PB.PluginBrowser.updateList
    _ORIGINAL_MOVE = PB.PluginBrowser.move

    def patched_init(self, *args, **kwargs):
        # LIST mode = exactly the normal OpenBH Plugin Browser.
        if not _is_grid():
            return _ORIGINAL_INIT(self, *args, **kwargs)

        # GRID mode = replace only the installed PluginBrowser's list widget.
        size = getDesktop(0).size()
        w, h = size.width(), size.height()
        columns = 4
        row_height = None

        old_plugin_list = PB.PluginList
        PB.PluginList = lambda entries: GridPluginList(
            entries,
            columns=columns,
            row_height=row_height,
        )
        try:
            _ORIGINAL_INIT(self, *args, **kwargs)
        finally:
            PB.PluginList = old_plugin_list

        self.skin = _full_screen_skin()

        try:
            self["OBHGridNavigation"] = ActionMap(
                ["DirectionActions"],
                {
                    "left": self["list"].left,
                    "right": self["list"].right,
                },
                -5,
            )
        except TypeError:
            self["OBHGridNavigation"] = ActionMap(
                ["DirectionActions"],
                {
                    "left": self["list"].left,
                    "right": self["list"].right,
                },
                prio=-5,
            )

    PB.PluginBrowser.__init__ = patched_init
    PB.PluginBrowser.run = _patched_run
    PB.PluginBrowser.updateList = _patched_update
    PB.PluginBrowser.move = _patched_move

    _PATCHED = True
    print("[OBHPluginBrowserGrid] List/Grid selectable patch enabled.")


def _remove_patch():
    global _PATCHED
    if not _PATCHED:
        return

    try:
        import Screens.PluginBrowser as PB
        if _ORIGINAL_INIT is not None:
            PB.PluginBrowser.__init__ = _ORIGINAL_INIT
        if _ORIGINAL_RUN is not None:
            PB.PluginBrowser.run = _ORIGINAL_RUN
        if _ORIGINAL_UPDATE is not None:
            PB.PluginBrowser.updateList = _ORIGINAL_UPDATE
        if _ORIGINAL_MOVE is not None:
            PB.PluginBrowser.move = _ORIGINAL_MOVE
    except Exception as err:
        print("[OBHPluginBrowserGrid] Restore failed:", err)

    _PATCHED = False


def autostart(reason, **kwargs):
    if reason == 0:
        try:
            _install_patch()
        except Exception as err:
            print("[OBHPluginBrowserGrid] Patch failed:", err)
    elif reason == 1:
        _remove_patch()


def menuStart(menuid, **kwargs):
    if menuid == "mainmenu":
        return [
            (
                "Plugin Browser View",
                openSetup,
                "obhpluginbrowsergrid_setup",
                70,
            )
        ]
    return []


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="OpenBH Plugin Browser Grid",
            description="Choose List or 4-column Grid with rows fitted to MenuList height.",
            where=PluginDescriptor.WHERE_MENU,
            fnc=menuStart,
        ),
        PluginDescriptor(
            name="OpenBH Plugin Browser Grid",
            description="Selectable List/Grid with auto-fitted rows and fully visible large icons.",
            where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART],
            fnc=autostart,
        ),
    ]
