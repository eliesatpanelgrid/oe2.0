from enigma import (
    BT_HALIGN_CENTER,
    BT_KEEP_ASPECT_RATIO,
    BT_SCALE,
    BT_VALIGN_CENTER,
    RT_HALIGN_CENTER,
    RT_VALIGN_CENTER,
    RT_WRAP,
    eListboxPythonMultiContent,
    getDesktop,
    gFont,
)

from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryPixmapAlphaBlend, MultiContentEntryText
from Tools.Directories import SCOPE_CURRENT_SKIN, resolveFilename
from Tools.LoadPixmap import LoadPixmap


class GridPluginList(MenuList):
    """
    Full-screen OpenBH Plugin Browser grid.

    It intentionally uses the normal OpenBH vertical eListbox. Each eListbox
    row contains several plugin cells, so no OpenATV-specific eListbox.orGrid
    support is required.
    """

    def __init__(self, plugin_list=None, columns=None, row_height=None, enableWrapAround=True):
        desktop = getDesktop(0).size()
        dw, dh = desktop.width(), desktop.height()

        if columns is None:
            columns = 4

        # Temporary fallback only. The final rowHeight is calculated from the
        # REAL MenuList widget height in postWidgetCreate().
        if row_height is None:
            row_height = 220 if dh >= 1000 else 180 if dh >= 700 else 150

        self.columns = max(2, int(columns))
        self.rowHeight = max(100, int(row_height))
        self.flatList = []
        self.column = 0
        self._rebuilding = False
        self._defaultIcon = None

        MenuList.__init__(self, [], enableWrapAround, eListboxPythonMultiContent)

        title_font = 25 if dh >= 1000 else 20 if dh >= 700 else 17
        self.l.setFont(0, gFont("Regular", title_font))
        self.l.setItemHeight(self.rowHeight)

        if plugin_list:
            self.setList(plugin_list)

    def _calculateLayoutFromWidget(self):
        """
        Tie the number/height of visible rows directly to the REAL MenuList
        dimensions. We always choose a whole-number row count so Enigma2 never
        shows half of the next row at the bottom.
        """
        try:
            list_h = self.instance.size().height()
            list_w = self.instance.size().width()
        except Exception:
            return

        if list_h <= 100 or list_w <= 100:
            return

        # Prefer large icons/rows. On a typical 1080p PluginBrowser this gives
        # 3 full rows; on HD it normally gives 3 or 4 depending on the skin.
        #
        # The desired minimum row height is resolution-independent because we
        # calculate from the actual widget, not from desktop resolution.
        desired_row_h = 215 if list_h >= 700 else 170 if list_h >= 500 else 135

        visible_rows = max(1, list_h // desired_row_h)

        # Prevent overly dense layouts; this plugin is intentionally designed
        # for large icons. Also never use more rows than plugin rows available.
        visible_rows = min(4, visible_rows)

        if self.flatList:
            plugin_rows = (len(self.flatList) + self.columns - 1) // self.columns
            visible_rows = max(1, min(visible_rows, plugin_rows))

        # Fill the MenuList exactly with WHOLE rows.
        self.rowHeight = max(110, list_h // visible_rows)
        self.l.setItemHeight(self.rowHeight)

    def postWidgetCreate(self, instance):
        MenuList.postWidgetCreate(self, instance)

        # Disable native full-row selection; our selector is icon-only.
        try:
            instance.setSelectionEnable(False)
        except Exception:
            pass

        self._calculateLayoutFromWidget()
        self.l.setItemHeight(self.rowHeight)

        if self.flatList:
            self._rebuild(keep_index=True)


    def _widgetWidth(self):
        try:
            width = self.instance.size().width()
            if width > 100:
                return width
        except Exception:
            pass
        return getDesktop(0).size().width() - 50

    def _icon(self, plugin):
        icon = getattr(plugin, "icon", None)
        if icon:
            return icon
        if self._defaultIcon is None:
            try:
                self._defaultIcon = LoadPixmap(
                    resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png")
                )
            except Exception:
                self._defaultIcon = None
        return self._defaultIcon

    def _rowData(self, row_plugins, row_index, selected_row):
        width = self._widgetWidth()
        cell_w = max(190, width // self.columns)

        # Dynamic selector/icon canvas based on BOTH actual cell width and the
        # row height calculated from MenuList height.
        selector_size = min(
            int(cell_w * 0.62),
            int(self.rowHeight * 0.67),
        )
        selector_size = max(100, selector_size)

        icon_y = max(8, int(self.rowHeight * 0.045))
        border = 5 if selector_size >= 145 else 4

        # Safe padding guarantees that plugin images remain fully visible and
        # never touch/cross the selector border.
        safe_pad = max(11, int(selector_size * 0.09))
        pix_size = max(40, selector_size - (safe_pad * 2))

        text_gap = max(8, int(self.rowHeight * 0.035))
        text_y = icon_y + selector_size + text_gap
        text_h = max(34, self.rowHeight - text_y - 5)

        row = [row_plugins]

        for col in range(self.columns):
            plugin = row_plugins[col] if col < len(row_plugins) else None
            if plugin is None:
                continue

            x = col * cell_w
            icon_x = x + (cell_w - selector_size) // 2
            active = row_index == selected_row and col == self.column

            if active:
                selector_color = 0x0000BFFF

                row.append(
                    MultiContentEntryText(
                        pos=(icon_x, icon_y),
                        size=(selector_size, border),
                        font=0,
                        text="",
                        backcolor=selector_color,
                    )
                )
                row.append(
                    MultiContentEntryText(
                        pos=(icon_x, icon_y + selector_size - border),
                        size=(selector_size, border),
                        font=0,
                        text="",
                        backcolor=selector_color,
                    )
                )
                row.append(
                    MultiContentEntryText(
                        pos=(icon_x, icon_y),
                        size=(border, selector_size),
                        font=0,
                        text="",
                        backcolor=selector_color,
                    )
                )
                row.append(
                    MultiContentEntryText(
                        pos=(icon_x + selector_size - border, icon_y),
                        size=(border, selector_size),
                        font=0,
                        text="",
                        backcolor=selector_color,
                    )
                )

            row.append(
                MultiContentEntryPixmapAlphaBlend(
                    pos=(icon_x + safe_pad, icon_y + safe_pad),
                    size=(pix_size, pix_size),
                    png=self._icon(plugin),
                    flags=BT_SCALE
                    | BT_KEEP_ASPECT_RATIO
                    | BT_HALIGN_CENTER
                    | BT_VALIGN_CENTER,
                )
            )

            row.append(
                MultiContentEntryText(
                    pos=(x + 12, text_y),
                    size=(cell_w - 24, text_h),
                    font=0,
                    flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER | RT_WRAP,
                    text=getattr(plugin, "name", ""),
                    color=0x00FFFFFF,
                )
            )

        return row

    def _makeRows(self):
        plugins = []
        for entry in self.flatList:
            try:
                plugins.append(entry[0])
            except Exception:
                plugins.append(None)

        selected_row = 0
        if self.instance is not None:
            try:
                selected_row = self.instance.getCurrentIndex()
            except Exception:
                selected_row = 0

        rows = []
        row_index = 0
        for start in range(0, len(plugins), self.columns):
            rows.append(
                self._rowData(
                    plugins[start:start + self.columns],
                    row_index,
                    selected_row,
                )
            )
            row_index += 1
        return rows

    def _rebuild(self, keep_index=True):
        if self._rebuilding:
            return

        old_row = 0
        if keep_index and self.instance is not None:
            try:
                old_row = self.instance.getCurrentIndex()
            except Exception:
                pass

        self._rebuilding = True
        try:
            rows = self._makeRows()
            MenuList.setList(self, rows)
            self.l.setItemHeight(self.rowHeight)
            if self.instance is not None and rows:
                self.instance.moveSelectionTo(min(old_row, len(rows) - 1))
        finally:
            self._rebuilding = False

    def setList(self, plugin_list):
        self.flatList = list(plugin_list or [])
        if self.flatList and self.getSelectedIndex() >= len(self.flatList):
            self.column = 0

        if self.instance is not None:
            self._calculateLayoutFromWidget()

        self._rebuild(keep_index=True)

    def getCurrent(self):
        idx = self.getSelectedIndex()
        if 0 <= idx < len(self.flatList):
            return self.flatList[idx]
        return None

    def getSelectionIndex(self):
        return self.getSelectedIndex()

    def getSelectedIndex(self):
        if not self.flatList:
            return 0

        row = 0
        if self.instance is not None:
            try:
                row = self.instance.getCurrentIndex()
            except Exception:
                pass

        return min(row * self.columns + self.column, len(self.flatList) - 1)

    def moveToIndex(self, idx):
        if not self.flatList:
            return

        idx = max(0, min(int(idx), len(self.flatList) - 1))
        self.column = idx % self.columns
        row = idx // self.columns

        self._rebuild(keep_index=True)
        if self.instance is not None:
            self.instance.moveSelectionTo(row)

    def left(self):
        if self.flatList:
            self.moveToIndex(self.getSelectedIndex() - 1)

    def right(self):
        if self.flatList:
            self.moveToIndex(self.getSelectedIndex() + 1)

    # Used by OpenBH's plugin reorder functions after swapping one plugin.
    def up(self):
        if self.flatList:
            self.moveToIndex(self.getSelectedIndex() - 1)

    def down(self):
        if self.flatList:
            self.moveToIndex(self.getSelectedIndex() + 1)

    def selectionChanged(self):
        if self._rebuilding:
            return

        if self.flatList and self.instance is not None:
            try:
                row = self.instance.getCurrentIndex()
                first = row * self.columns
                count = min(self.columns, len(self.flatList) - first)
                if count > 0 and self.column >= count:
                    self.column = count - 1
            except Exception:
                pass

        # Redraw so the icon-width bar follows Up/Down selection as well.
        if self.flatList:
            self._rebuild(keep_index=True)

        for callback in self.onSelectionChanged:
            callback()

