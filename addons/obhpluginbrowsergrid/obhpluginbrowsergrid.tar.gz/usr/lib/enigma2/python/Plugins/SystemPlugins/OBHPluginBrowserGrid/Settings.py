from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.config import (
    ConfigSelection,
    ConfigSubsection,
    config,
    configfile,
    getConfigListEntry,
)
from Screens.Screen import Screen


if not hasattr(config.plugins, "OBHPluginBrowserGrid"):
    config.plugins.OBHPluginBrowserGrid = ConfigSubsection()

if not hasattr(config.plugins.OBHPluginBrowserGrid, "viewMode"):
    config.plugins.OBHPluginBrowserGrid.viewMode = ConfigSelection(
        default="grid",
        choices=[
            ("list", "List"),
            ("grid", "Grid"),
        ],
    )


class PluginBrowserGridSetup(Screen, ConfigListScreen):
    skin = """
        <screen name="PluginBrowserGridSetup"
                position="center,center"
                size="780,330"
                title="Plugin Browser View"
                backgroundColor="#0d0f12">
            <widget name="config"
                    position="30,60"
                    size="720,150"
                    scrollbarMode="showOnDemand"
                    backgroundColor="#171a1f"
                    transparent="0" />

            <widget name="key_red"
                    position="30,245"
                    size="345,58"
                    font="Regular;23"
                    halign="center"
                    valign="center"
                    backgroundColor="#7f2525"
                    foregroundColor="#ffffff" />

            <widget name="key_green"
                    position="405,245"
                    size="345,58"
                    font="Regular;23"
                    halign="center"
                    valign="center"
                    backgroundColor="#276b39"
                    foregroundColor="#ffffff" />
        </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)

        self.list = [
            getConfigListEntry(
                "Plugin Browser display mode",
                config.plugins.OBHPluginBrowserGrid.viewMode,
                "Choose the normal OpenBH List or the full-screen Grid.",
            )
        ]

        ConfigListScreen.__init__(self, self.list, session=session)

        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Save")

        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions", "OkCancelActions"],
            {
                "cancel": self.cancel,
                "red": self.cancel,
                "green": self.save,
                "save": self.save,
                "ok": self.save,
            },
            -2,
        )

    def save(self):
        config.plugins.OBHPluginBrowserGrid.viewMode.save()
        configfile.save()
        self.close(True)

    def cancel(self):
        config.plugins.OBHPluginBrowserGrid.viewMode.cancel()
        self.close(False)


def openSetup(session, **kwargs):
    session.open(PluginBrowserGridSetup)
