# GT IPTV Player Pro Licensing

Copyright (C) 2026 VicTuS59

The publicly distributed GT IPTV Player Pro runtime source code is licensed
under the GNU General Public License version 2 or, at your option, any later
version (`GPL-2.0-or-later`). The complete GPLv2 text is in `LICENSE.txt`.

This notice covers the following original project files:

- Python runtime modules;
- `plugin.svg`;
- PNG theme, player and weather artwork under `skin/images/`, excluding the
  separately identified TMDB logo below;
- localisation catalogs and plugin documentation.

## Artwork audit

No embedded producer, source or copyright notice was found in the PNG files
under `skin/images/`. On 2026-08-20, the project owner confirmed that this
artwork was created for GT IPTV Player Pro and is original project material
owned by the project owner. It is also distributed under
`GPL-2.0-or-later`. The audited files and their digests are recorded in
`ASSET_PROVENANCE.md`.

## External service notices

- Weather data is supplied by Open-Meteo and is attributed in the application
  as “Weather data by Open-Meteo.com — CC BY 4.0”. License:
  https://creativecommons.org/licenses/by/4.0/. Provider:
  https://open-meteo.com/. Forecast data is reformatted for the television
  interface.
- This product uses the TMDB API but is not endorsed or certified by TMDB. The
  TMDB logo on the About screen is an approved TMDB logo, displayed smaller
  than the application branding and solely to identify API use. Source:
  https://www.themoviedb.org/about/logos-attribution.

These notices do not license the Open-Meteo or TMDB brands, APIs or third-party
content as part of the GT IPTV Player Pro source code.

## MAG compatibility reference in the R19 build

The R13 MAG compatibility profile is retained in this test build. Its
development used kiddac/EStalker as a reference. On 2026-09-24, project owner
VicTuS59 confirmed that permission had been obtained from kiddac. See
`PORTAL_COMPATIBILITY_PROVENANCE.md` for the technical scope and
`ESTALKER_PERMISSION.md` for the permission record, the English statement
supplied by the project owner, and the supplied forum post link. The same
statement and link appear beside the MAG profile code in `stalker.py`.
No additional license terms are inferred from the excerpt. This project's
GPL notice does not grant rights in third-party work.
