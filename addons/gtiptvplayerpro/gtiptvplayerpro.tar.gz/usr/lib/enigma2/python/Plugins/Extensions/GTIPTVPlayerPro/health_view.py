# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2026 VicTuS59
# SPDX-License-Identifier: GPL-2.0-or-later
"""Pure presentation helpers for the shared source-health screen."""

from __future__ import absolute_import


HEALTH_SIGNAL_NEUTRAL = "neutral"
HEALTH_SIGNAL_GREEN = "green"
HEALTH_SIGNAL_YELLOW = "yellow"
HEALTH_SIGNAL_RED = "red"

_NEUTRAL_STATUSES = frozenset(
    (
        "",
        "waiting",
        "waiting for test",
        "testing",
        "testing...",
        "cancelled",
        "unknown",
    )
)
_GREEN_STATUSES = frozenset(("online",))
_YELLOW_STATUSES = frozenset(("busy", "disabled", "stale"))
_RED_STATUSES = frozenset(("error", "invalid"))
_YELLOW_ACCOUNT_STATUSES = frozenset(
    ("blocked", "banned", "disabled", "inactive")
)
_RED_ACCOUNT_STATUSES = frozenset(("expired",))


def health_signal(status, account_status=""):
    """Return a colour key without inspecting translated or free-form text."""
    status_key = str(status or "").strip().casefold()
    account_key = str(account_status or "").strip().casefold()
    if status_key in _RED_STATUSES:
        return HEALTH_SIGNAL_RED
    if account_key in _RED_ACCOUNT_STATUSES:
        return HEALTH_SIGNAL_RED
    if account_key in _YELLOW_ACCOUNT_STATUSES:
        return HEALTH_SIGNAL_YELLOW
    if status_key in _GREEN_STATUSES:
        return HEALTH_SIGNAL_GREEN
    if status_key in _YELLOW_STATUSES:
        return HEALTH_SIGNAL_YELLOW
    if status_key in _NEUTRAL_STATUSES:
        return HEALTH_SIGNAL_NEUTRAL
    return HEALTH_SIGNAL_NEUTRAL


def split_health_text(rendered, left_line_count):
    """Split one already-localised health template into two cards and a note."""
    text = str(rendered or "")
    fields, separator, message = text.partition("\n\n")
    lines = fields.splitlines()
    try:
        left_line_count = max(0, int(left_line_count))
    except (TypeError, ValueError, OverflowError):
        left_line_count = 0
    left = "\n".join(lines[:left_line_count]).strip()
    right = "\n".join(lines[left_line_count:]).strip()
    if not separator:
        message = ""
    return left, right, message.strip()


def dashboard_account_text(source_type, display_name, safe_endpoint):
    """Keep the dashboard MAC compact without changing shared display names."""
    source_type = str(source_type or "").strip().casefold()
    display_name = str(display_name or "").strip()
    safe_endpoint = str(safe_endpoint or "").strip()
    if source_type == "stalker" and safe_endpoint:
        return safe_endpoint
    return display_name or safe_endpoint


def health_account_text(
    source_type,
    display_name,
    safe_name,
    safe_endpoint,
):
    """Build a credential-free, de-duplicated identity for the health header."""
    source_type = str(source_type or "").strip().casefold()
    display_name = str(display_name or "").strip()
    safe_name = str(safe_name or "").strip()
    safe_endpoint = str(safe_endpoint or "").strip()
    primary = safe_endpoint if source_type == "stalker" else display_name
    candidates = (primary, safe_name)
    values = []
    seen = set()
    for value in candidates:
        key = value.casefold()
        if not value or key in seen:
            continue
        seen.add(key)
        values.append(value)
    return "  |  ".join(values)
