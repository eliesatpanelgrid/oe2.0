# EStalker attribution and permission record

Project: GT IPTV Player Pro, by VicTuS59.
Build: 1.1.0-r19.
Referenced implementation: EStalker, by kiddac.
Reference: https://github.com/kiddac/EStalker/tree/94f7be4286de7a0cda905bfe21ae78e4ad06d354

## Permission status

Permission received, as confirmed by project owner VicTuS59 on 2026-09-24.
That date records the owner's confirmation, not the date of kiddac's
original authorization message.

## Technical material concerned

The Stalker/Ministra MAG compatibility adaptation in `stalker.py`, including
the handshake/profile exchange, MAG request headers, MAC and token cookies,
device-profile identifiers, signature/prehash fields, and challenge metrics
and their encoding. See `PORTAL_COMPATIBILITY_PROVENANCE.md` for the
development history. Credit for the referenced EStalker implementation
belongs to kiddac.

## Statement and forum source supplied by the project owner

Recorded on 2026-09-24. The following English text was supplied by VicTuS59
and attributed to kiddac. It is reproduced exactly as provided; it is not
presented as a verified transcription of the original-language forum post.

> My EStalker code is open source, not closed source. It's freely available on my GitHub for people to learn from, build on, or even use as a reference source for AI.

Direct forum post link supplied by the owner:

https://www.linuxsat-support.com/thread/163591-iptv-box-by-mike68-a-lightweight-iptv-plugin-for-enigma2-openatv-python-3/?postID=959243#post959243

The original post date was not supplied. The page could not be retrieved
when this record was prepared; the text and source attribution above are
based on the project owner's supplied material. The supplied excerpt does
not name a specific software license or state further conditions; this
record does not add such terms.

## Publication status

The project owner's instruction to defer publication remains in place.
This R19 package is not a public release.
