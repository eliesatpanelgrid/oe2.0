# GT IPTV Player Pro

## v0.9.64 — kompakt ve taşmasız ortak kumanda şeridi

- Bütün menü ve içerik sayfalarındaki ortak kumanda şeridinin tuş ve eylem
  yazıları yaklaşık yüzde 20-25 küçültüldü; 720×405 ekranlarda uzun metinler
  artık komşu alana taşmadan görünür.
- Dar altı bölmeli şeritlerde **MENU** tuşuna güvenli yatay alan ayrıldı; tuş
  adı tek satırda, ortalı ve kırpılmadan çizilir.
- Eylem metinleri sabitlenmedi. Açık ekran yeniden gösterildiğinde cihaz dili
  tekrar okunur; Türkçe, İngilizce, Almanca ve diğer destekli kataloglar aynı
  ortak yerelleştirme yolunu kullanmaya devam eder.

## v0.9.63 — cihaz dilini izleyen tam arayüz yerelleştirmesi

- Menüler, hesap ve sunucu durumları, EPG, oynatıcı, ayarlar, TMDb bilgileri,
  güncelleme aşamaları, hata mesajları ve ortak kumanda şeritleri sabit metin
  taramasından geçirildi; kullanıcıya gösterilen eklenti metinleri cihaz dilini
  izler.
- Enigma2 dili değiştiğinde açık ekrandaki yerelleştirilmiş etiketler yeniden
  çevrilir. Hava durumu şehir araması da cihazın dil koduyla yapılır.
- Dinamik çeviri şablonları hesap sayısı, sürüm, yüzde, çıktı biçimi ve hata
  ayrıntısı gibi gerçek değerleri korur. Kanal/film/dizi, şehir, hesap ve sunucu
  adları ile TS, M3U8, FPS ve Python gibi teknik değerler çevrilmez.
- 47 desteklenen dil ve 44 yerel katalog için sabit yazı, kritik ekran ve
  şablon-değer koruma testleri eklendi.

## v0.9.62 — footer alt konum ve şeffaf tema düzeltmesi

- Eski footer koordinatını çözen XML eşleştirmesi düzeltildi; ortak ikonlu
  kumanda şeridi artık üstteki `0,0` konumuna düşmez ve her sayfada mevcut alt
  panel sınırlarını kullanır.
- Opak footer zemini kaldırıldı. Tema görseli görünür kalır; renkli tuş kutuları
  ile cihaz dilini izleyen eylem yazıları şeffaf alan üzerinde gösterilir.

## v0.9.61 — bütün ekranlarda büyük, ikonlu ve yerelleştirilmiş kumanda çubuğu

- Kullanıcıya kumanda yönlendirmesi gösteren bütün menü, hesap, ayar,
  güncelleme ve içerik liste ekranları aynı renkli tuş kutularını kullanır.
- Yazı boyutları büyütüldü; ok tuşları gerçek yön ikonlarıyla, renk tuşları
  kendi rengiyle gösterilir. Alt çubuk sayfa içeriğini örtmeden mevcut güvenli
  sınırında kalır.
- Eylem açıklamaları cihaz dilini izler ve ekran yeniden gösterildiğinde tekrar
  çevrilir; sabit Türkçe footer bırakılmaz.
- Hoş geldin ekranında **SARI / GÜNCELLEMELERİ TEST ET**, imzalı güncelleme
  kontrol ekranını doğrudan açar.
- Cihaz testi yalnız kaynak `.py` içermeyen korumalı evrensel IPK ile yapılır.

## v0.9.60 — 720×405 üst EPG okunabilirlik düzeltmesi

- Üst EPG başlıkları renkli panel çizgisinin altına indirildi; kanal, program,
  saat ve sıradaki yayın metinleri büyütüldü.
- Üst şeride ek dikey alan verildi. Önizleme 16:9 oranı bozulmadan aşağı
  taşındı; **Bugünün Yayın Akışı** ve **Program Özeti** paneli buna göre
  hizalandı.
- 1920×1080, 1280×720 ve gerçek 720×405 OSD sınırları korunur.
- Cihaz testi yalnız kaynak `.py` içermeyen korumalı evrensel IPK ile yapılır.

## v0.9.59 — Canlı TV EPG şeridi ve bugünün yayın akışı

- Canlı TV kanal listesinin üstündeki hava durumu şeridi, seçili kanalın
  **Şimdi Yayında**, ilerleme/kalan süre, **Sıradaki** ve saat bilgileriyle
  değiştirildi.
- Alt panelde mevcut programla birlikte sonraki iki program gösterilir.
  **Program Özeti** alanı güncel programın açıklamasını; veri yoksa temiz bir
  bilgilendirme mesajını gösterir.
- Yalnız Canlı TV kanal ekranının hava durumu isteği kaldırıldı. Ana hava
  durumu ekranı, ayarlar ve tam ekran oynatıcı özellikleri korunur.
- Cihaz testi yalnız kaynak `.py` içermeyen korumalı evrensel IPK ile yapılır.

## v0.9.58 — hesap bazlı TS / M3U8 çıktı seçimi

- **Hesap Ekle** ekranına kumandayla seçilebilen **TS / M3U8** çıktı satırı
  eklendi.
- Seçim hesapla birlikte `playlists.txt` dosyasına kaydedilir; canlı TV
  önizlemesi ve tam ekran oynatma adresi gerçekten seçilen uzantıyla açılır.
- Mevcut ve çıktı bilgisi bulunmayan hesaplar geriye uyumluluk için TS kullanır.
- Ana hesap kartı ve hesap yönetimi seçilen çıktı biçimini gösterir.
- Cihaz testi yalnız kaynak `.py` içermeyen korumalı evrensel IPK ile yapılır.

## v0.9.57 — anlık ön panel yenilemesi ve kayan başlıklar

- Kanal değişiminde ön panel yeni kanal adına anında geçer; yeni EPG verisi
  geldiğinde program adı, kalan süre ve yüzde doğrudan yenilenir.
- Canlı TV, film ve dizi çubuğu standart bileşen yerine Vu+ LCD/VFD üzerinde
  güvenilir çalışan iki katmanlı dolgu olarak çizilir.
- Başlık ve EPG yazıları büyütülüp ortalanır. Yalnız ekrana sığmayan kanal,
  EPG, film ve dizi/bölüm adları bekledikten sonra sağdan sola kayar; süre ve
  ilerleme çubuğu sabit kalır.
- Cihaz testi yalnız kaynak `.py` içermeyen korumalı evrensel IPK ile yapılır.

## v0.9.56 — Vu+ ön panel EPG ve oynatma ilerlemesi

- Ön panel ekranı bulunan Vu+ ve uyumlu Enigma2 cihazlarda canlı kanal adı,
  güncel EPG programı, kalan süre ve ilerleme çubuğu gösterilir.
- Film ve dizilerde içerik adı, geçen/toplam süre, kalan süre ve ilerleme çubuğu
  cihaz ekranında saniyede bir yenilenir.
- Küçük OLED/VFD ve büyük renkli LCD çözünürlükleri için yerleşim otomatik
  seçilir; ekransız cihazlarda mevcut oynatma ve kumanda davranışı korunur.
- Cihaz testi yalnız kaynak `.py` içermeyen korumalı evrensel IPK ile yapılır.

## v0.9.55 — uzun basışla sarma ve arayüz ayrıntıları

- Sarma modunda SAĞ/SOL tuşu basılı tutulduğunda hedef zaman OpenPLi repeat
  olaylarıyla sürekli değiştirilir.
- Ana paneldeki **KALDIĞIN YERDEN DEVAM** başlığı tek satırda gösterilir.
- Hakkında ekranına cihaz diliyle birlikte **GELİŞTİRİCİ VicTuS59** bilgisi
  eklenir.
- Cihaz testi yalnız kaynak kod içermeyen korumalı evrensel IPK ile yapılır.

## v0.9.47 — özel simge ve ana menü girişi

- Eklenti tarayıcısındaki genel `PLUGIN` görselinin yerine GT IPTV Player Pro
  için hazırlanmış koyu neon 100×60 SVG simgesi gösterilir.
- Eklenti iki yerde bulunur: Eklentiler listesi ve Enigma2 ana menüsü. Ana
  menüdeki **GT IPTV Player Pro** satırı eklentiyi doğrudan açar; eski
  Extensions menüsü kaydı kaldırılmıştır.
- Sürüm önce özel GitHub dalından Device Lab ile kullanıcı testine sunulur;
  kullanıcı onayı olmadan public güncelleme yayınlanmaz.

## v0.9.46 — ayrı güncelleme işçisi staging doğrulaması

- v0.9.45'in ayrı Python güncelleme işçisini gerçek cihazda, public yayın
  yapılmadan imzalı yeni sürüm üzerinden sınamak için kararlı doğrulama
  paketi hazırlandı.
- Paket yine kaynak kodu ve Device Lab köprüsü içermez. İndirme,
  RSA-PSS/SHA-256, ZIP, Python ABI, yedekleme ve atomik etkinleştirme
  kontrolleri v0.9.45'teki resmî işçi tarafından aynen uygulanır.
- Bu sürümün özel staging testi yalnız GT Device Lab Agent v0.6.2 veya
  sonrasında ve
  kullanıcı onayıyla başlar; normal eklenti güncelleme ekranı yalnız resmî
  public kanalı kontrol etmeye devam eder.

## v0.9.45 — bağımsız güncelleme işçisi

- İndirme, RSA-PSS/SHA-256 ve ZIP doğrulaması, güvenli paket açma, mevcut
  eklentiyi yedekleme ve atomik etkinleştirme Enigma2 ana işleminden ayrı bir
  Python yardımcı sürecinde tamamlanır; kabuk veya `wget` kullanılmaz.
- Enigma2 yalnız kalıcı durum dosyasını izleyen ayrı bir ilerleme ekranı
  gösterir. Aşama, yüzde ve indirilen veri görünür; çalışan iş yanlışlıkla
  kapatılamaz. İşçi beklenmedik biçimde durursa duran aşama ve hata kaydedilir,
  mevcut eklenti korunur.
- İş sonucu başarıda da hatada da durum dosyasında kalır ve bu dosya silinmez.
  Kurulum hedefleri eklenti, kendi yedek ve özel geçici klasörleriyle
  sınırlıdır; bootloader, `/boot`, ham MTD/MMC, U-Boot ve açılış zincirine
  erişilmez.

## v0.9.44 — gerçek uzak güncelleme doğrulaması

- v0.9.43'te eklenen yalıtılmış HTTPS yardımcı işleminin gerçek isteğe bağlı
  uzak güncelleme zincirinde sınanması için kararlı doğrulama sürümü hazırlandı.
- Paket indirme, RSA/SHA-256/ZIP kontrolleri ve atomik eklenti değişimi dışında
  sistem, bootloader, `/boot`, ham MTD/MMC veya U-Boot alanlarına erişilmez.

## v0.9.43 — yalıtılmış HTTPS indirme

- Büyük güncelleme ZIP'i Enigma2 ana işlemi içinde indirilmez. Ayrı ve
  gözetlenen bir Python yardımcı işlemi paketi 64 KB HTTPS parçalarıyla özel
  geçici dosyaya yazar; `wget` veya kabuk indiricisi kullanılmaz.
- Yardımcı işlem hata verir, zaman aşımına uğrar veya doğal olmayan biçimde
  kapanırsa Enigma2 çalışmaya devam eder, geçici dosya silinir ve kurulum
  başlamaz. SHA-256, RSA imzası, ZIP ve boot zinciri kontrolleri korunur.

## v0.9.42 — uzaktan güncelleme doğrulaması

- v0.9.41'de eklenen güvenli akış indirmesi, tek disk senkronizasyonu ve boot
  zinciri korumalarının gerçek isteğe bağlı uzaktan güncelleme zincirinde
  doğrulanması için kararlı test sürümü hazırlandı.

## v0.9.41 — Enigma2 indirme kararlılığı

- Güncelleme paketi belleğe alınmadan, yalnız izin verilen HTTPS GitHub
  alanlarında ve her yönlendirme yeniden doğrulanarak sınırlı geçici dosyaya
  parça parça yazılır; imza, SHA-256 ve ZIP doğrulamaları aynen korunur.
- Yavaş Enigma2 flash depolamasında her dosya için ayrı `fsync` yapılmaz;
  kaynak-kodsuz paket tamamen açılıp denetlendikten sonra tek disk
  senkronizasyonu uygulanır.
- İndirme başarısızlığı durum dosyasına kaydedilir ve `pending_version`
  temizlenir; mevcut eklentiye dokunulmaz.
- Bootloader, `/boot`, ham MTD/MMC flash aygıtları ve U-Boot zincirine erişim
  çalışma zamanında açıkça reddedilir; güncelleme yalnız eklenti ve kendi
  yedek/geçici yollarıyla sınırlandırılır.

Bu klasör, GT IPTV Player Pro eklentisinin cihazda çalışan kaynak paketidir.

## v0.9.40 — kesintisiz HTTP hesap akışı

- HTTP hesaplarda kaydetme ve bağlanma sırasında gösterilen bloklayan onay
  penceresi kaldırıldı.
- Yeni hesap formu yeniden `http://` ile başlar; HTTPS destekleyen sunucularda
  kullanıcı adresi `https://` olarak girebilir.
- Hakkında ekranındaki Open-Meteo/TMDb gizlilik ve kaynak bildirimleri korunur.

## v0.9.39 — HTTP onayı, gizlilik ve kaynak bildirimi

- HTTP Xtream hesabı kaydetme ve bağlanma işlemleri, kimlik bilgilerinin ağda
  şifrelenmeden taşınacağını açıklayan ve varsayılanı **Hayır** olan açık onay
  penceresi olmadan çalışmaz. Yeni hesap formunun varsayılanı `https://` oldu.
- Hakkında ekranı Open-Meteo şehir/koordinat ve TMDb başlık/API anahtarı veri
  akışlarını açıklar; IPTV kimlik bilgilerinin bu iki servise gönderilmediğini
  belirtir.
- Weather data by Open-Meteo.com (CC BY 4.0) kaynağı ve zorunlu TMDb kullanım
  bildirimi eklendi. Ayrıntılı açıklama `PRIVACY.md` dosyasındadır.

## v0.9.38 — poster ağı ve yerel dosya güvenliği

- Poster/picon indirmelerinde yalnız public HTTP(S) hedeflerine izin verilir.
  DNS sonuçlarının tamamı ve her yönlendirme yeniden doğrulanır; özel, loopback,
  link-local, ayrılmış ve karma DNS yanıtları ile HTTPS→HTTP düşüşü reddedilir.
  TLS sertifikası gerçek sunucu adına doğrulanırken bağlantı denetlenen IP'ye
  sabitlenir.
- Yanıt boyutu ve sıkıştırma sınırlarına ek olarak görsel genişliği, yüksekliği
  ve toplam piksel sayısı dosya çözümlenmeden önce kontrol edilir.
- Poster önbelleği ile tanılama günlüğü symlink/hardlink, sahiplik ve dosya türü
  kontrolleri kullanır; geçici poster dosyaları tahmin edilemeyen adla ve özel
  izinle oluşturulup atomik olarak etkinleştirilir.

## v0.9.37 — imzalı isteğe bağlı uzak güncelleme

- Oynatıcı ayarlarında SARI tuşla açılan **Güncellemeleri Test Et** ekranı,
  resmî kararlı kanalı kullanıcı isteğiyle kontrol eder. Yeni sürüm olsa bile
  ayrıca OK ve Evet onayı verilmeden paket kurulmaz.
- Manifest ve paket RSA-PSS/SHA-256 ile ayrı ayrı doğrulanır. Sahte/değişmiş,
  süresi dolmuş, geri alınmış, yanlış Python ABI'sine ait, fazla büyük veya
  izinli eklenti klasörü dışına yazan ZIP dosyaları reddedilir.
- Doğrulanan kurulum mevcut eklentiyi tarihli yedeğe alır ve yeni klasörü aynı
  dosya sisteminde atomik olarak etkinleştirir. Hesap, TMDb, hava ve oynatma
  ayarları eklenti klasörü dışında kaldığı için güncellemede korunur.
- Private yayın anahtarı eklentiye, GitHub'a veya ZIP'e girmez; yalnız Device
  Lab'in çalıştığı Windows kullanıcısında DPAPI ile korunur. Eklentide sadece
  imza doğrulamak için gereken RSA public anahtarı bulunur.

## v0.9.36 — korumalı public dağıtım

- Özel Device Lab köprüsü geliştirme kaynağında ayrı modüle taşındı ve public
  paketten tamamen çıkarıldı.
- Forum ZIP'i `.py` kaynak kodu yerine hedef cihazın Python 3.9 yorumlayıcısıyla
  üretilmiş kaynak-kodsuz bytecode taşır. Paket yalnız eşleşen Python ABI'sinde
  kullanılmak üzere etiketlenir.
- Dahili manifest bütün dosyaların SHA-256 değerlerini, sürümü ve Python
  bytecode kimliğini kaydeder. Dağıtım lisansı ve resmî paket bildirimi eklendi.

## v0.9.35 — sessiz EPG ve hava yenilemesi

- Tam ekran canlı yayında EPG sonucu, program sınırı yenilemesi ve hava durumu
  sonucu kapalı infobarı yeniden açmadan arka planda uygulanır.
- Infobar kullanıcı tarafından zaten açılmışsa yeni veri geldiğinde yalnız
  görünme süresi yenilenir. Kanal geçişi ve gerçek yeniden bağlantı uyarıları
  görünür kalmaya devam eder.

## v0.9.34 — yenilenen hava durumu simgeleri

- Açık, parçalı bulutlu, bulutlu, sisli, yağmurlu, karlı ve fırtınalı durumların
  yedi PNG simgesi koyu arayüz için yeniden tasarlandı.
- Şeffaf 128×128 simgeler, küçük bilgi alanlarında okunaklı kalan güçlü
  siluetler ile turkuaz-mor kenar ışığı ve dengeli hacim kullanır.
- Dosya adları ve hava durumu kod eşlemesi korunmuştur; uygulama mantığına veya
  cihazdaki hava önbelleğine geçiş gerektiren bir değişiklik yapılmamıştır.

## v0.9.33 — uzun kullanım kararlılığı ve akıllı yenileme

- Film/dizi kategori ve ayrıntı istekleri 250 ms seçim kararlılığından sonra
  başlar. Üç dakikalık, en fazla üç liste tutan bellek önbelleği ve hesap başına
  iki eşzamanlı API isteği hızlı gezinmede sunucuyu istek yağmurundan korur.
  YEŞİL yenileme ilgili önbelleği temizleyerek güncel veriyi zorlar.
- Canlı kanal önizlemesi ve tam ekran bilgi bandındaki EPG ilerlemesi saniyelik
  güncellenir. Program sınırında şimdi/sonra verileri otomatik yenilenir.
- Donma koruması `0` veya erişilemeyen PTS/konum sayaçlarıyla yanlış yeniden
  bağlantı yapmaz. Gerçek takılma sürerse denemeler 15/30 saniye aralığına
  çekilir; beş ilerleyen örnekten sonra koruma normal başlangıç düzenine döner.
- Poster önbelleği 64 MB / 500 dosya / 14 gün sınırlarıyla otomatik budanır.
  Başarısız poster URL'lerine beş dakikalık kısa olumsuz önbellek uygulanır ve
  bütün görsel indirmeleri ortak dört işçi sınırını paylaşır.
- Open-Meteo yanıtı 512 KiB ile sınırlandı, bağlantı her durumda kapatılıyor ve
  hava önbelleği `0600` izinli atomik yazılıyor. Parola/token gizleyen 256 KiB
  döngüsel tanılama kaydı `/tmp/gtiptvplayerpro.log` altında tutulur.
- Sunucu Sağlığı; gecikmenin yanında protokol, izinli çıkış biçimi, saat dilimi
  ve panel sürümünü gösterir. Eski kullanılmayan tema PNG'leri paketten çıkarıldı.

## v0.9.32 — hızlı ve öncelikli poster yükleme

- Seçili film veya dizinin büyük posteri önce yüklenir; aynı görselin poster
  şeridi için tekrar indirilmesi engellenir.
- Görünen film/dizi posterleri dörde kadar paralel işçiye dağıtılır ve bütün
  sayfayı beklemeden tamamlandıkları anda ekrana uygulanır.
- Aynı URL için eşzamanlı indirmeler tek ağ aktarımında birleştirilir. Hızlı
  gezinmenin oluşturduğu yinelenen işler mevcut indirmeyi ve önbelleği kullanır.
- Farklı TMDb yapım sorguları artık küresel önbellek kilidinde sıra beklemez;
  paralel çalışır. Aynı başlık sorgusu ise güvenli biçimde tekilleştirilir.
- TMDb kullanılabiliyorsa bozuk IPTV poster adresi üç saniyede bırakılıp TMDb
  posterine geçilir; TMDb anahtarı yoksa sağlayıcı için sekiz saniyelik tolerans
  korunur.

## v0.9.31 — TMDb doğrulama ve OpenATV poster uyumluluğu

- Ayarlar ekranında **MAVİ / TMDb Test** işlemi, girilen API anahtarını gerçek
  TMDb yapılandırma isteğiyle doğrular ve sonucu ekranda açıkça gösterir.
- Başlık temizleme/eşleştirme kuralları genişletildi; eski olumsuz eşleşmeler
  yeni önbellek sürümüyle atlanır. Film ve dizi ayrıntısı eşleşme, anahtar ve
  bağlantı hatalarını sessizce yutmak yerine kullanıcıya bildirir.
- TMDb ve sağlayıcı posterleri JPEG/PNG olarak istenir; OpenATV'de sorun çıkaran
  AVIF/WebP dosyaları saklanmaz. İndirme zaman aşımı 8 saniyedir. Sağlayıcının
  poster adresi bozuksa aynı yapımın TMDb posteri otomatik denenir.
- Tam ekran canlı TV'de tek CH+/CH- basışının farklı OpenATV eylem adlarıyla
  gecikmeli iki kez iletilmesi filtrelenir; gerçek ardışık basışlar korunur.

## v0.9.30 — dahili TMDb film/dizi bilgileri

- Sunucunun boş bıraktığı film ve dizi posterleri, puanları, özetleri, türleri
  ve yılları doğrudan TMDb API'sinden tamamlanır; başka bir eklenti ya da haricî
  Python modülü gerekmez.
- Sunucu verisi her zaman önceliklidir. Temizlenmiş başlık ve yayın yılı güvenli
  eşleşmezse yanlış yapımın bilgileri gösterilmez.
- Türkçe veri önceliği, İngilizce özet yedeği, seçili/görünen içerik sorgulama
  ve 30 günlük atomik önbellek sayesinde arayüz bloklanmaz ve API korunur.
- **Ayarlar → TMDb API anahtarı / token** satırında OK ile anahtar girilir.
  Ayar ve önbellek dosyaları cihazda özel `0600` izinleriyle saklanır.

## v0.9.29 — CH+/CH- tek basış düzeltmesi

- Bazı Enigma2/OpenATV kumanda eşlemelerinin aynı fiziksel kanal tuşunu çok
  kısa aralıkla iki kez iletmesi artık ikinci kanala sıçramaya neden olmaz.
- Aynı yönde 140 ms içindeki kopya olay filtrelenir. Gerçek ayrı basışlar,
  hızlı seçim ve v0.9.28 soft-zap davranışı korunur.

## v0.9.28 — hızlı canlı kanal geçişi

- Tam ekran canlı TV'de KANAL+/KANAL- ile geçiş sırasında decoder ve ağ servisi
  önce tamamen kapatılmaz; Enigma2 seçilen servisi doğrudan aynı oynatma
  yuvasında değiştirir.
- 300 ms içinde art arda basılan kanal tuşları birleştirilir. OSD son seçimi
  anında gösterir ve yalnızca son kanal için oynatma isteği başlatılır.
- Donma korumasının gerektiğinde yaptığı tam durdurup yeniden bağlanma korunur.

## v0.9.27 — yatay liste konum imleçleri

- Film poster şeridi, dizi poster şeridi ve sezon sekmeleri koyu ray üzerinde
  hareket eden turkuaz bir yatay konum imleci gösterir.
- İmlecin konumu seçili film, dizi veya sezona; boyu görünen/toplam içerik
  oranına göre hesaplanır.
- Listedeki bütün öğeler tek ekrana sığıyorsa ray ve imleç gizlenir.

## v0.9.26 — codec ayarları ve canlı yayın donma koruması

- Ana paneldeki ve açılış ekranındaki **Ayarlar** işlemi, onaylanan tam ekran
  **Oynatıcı / Codec** arayüzünü açar. Dil sekmesi sonraki sürüm için
  **Yakında** olarak gösterilir.
- Canlı TV, film ve dizi servis tipleri ayrı ayrı seçilip kalıcı biçimde
  kaydedilir. Varsayılan olarak canlı yayınlar `4097` GStreamer, film ve dizi
  bölümleri sarma/devam desteği için `5002` ExtEplayer3 ile açılır.
- Donma koruması açıkken canlı oynatıcı dekoder PTS ilerlemesini izler. Yayın
  seçilen süre boyunca ilerlemezse kanal, EPG ve liste konumu korunarak aynı
  servis arka planda yeniden başlatılır.
- Yeniden bağlanma ve başlangıç tampon toleransı kumandadan ayarlanabilir;
  ayarlar `/etc/enigma2/gtiptvplayerpro-settings.json` dosyasına atomik ve
  `0600` izinli yazılır.

## v0.9.25 — liste konumu ve kaldığın yerden devam

- Canlı TV kategorileri, kanal listesi, film/dizi kategorileri, dizi bölümleri,
  genel içerik ve hesap listeleri sağ kenarda turkuaz konum imleci gösterir.
  İmlecin boyu görünen/toplam satıra, konumu seçili öğeye göre hesaplanır.
- Film ve dizi bölümlerinde EXIT/STOP, ExtEplayer3'ün oynatma saniyesini kaydeder.
  Aynı içerik yeniden seçilince kaldığın yerden devam sorusu açılır; Evet
  kayıtlı zamana sarar, Hayır kaydı temizleyip baştan oynatır.
- Beşinci saniyeden sonraki çıkışlar devam noktası olarak kabul edilir.
- `/etc/enigma2/gtiptvplayerpro-resume.json` dosyası atomik ve `0600` izinli
  yazılır; yayın URL’si veya hesap parolası yerine anonim SHA-256 anahtarı tutar.

## v0.9.24 — modern dizi, sezon ve bölüm kütüphanesi

- Eski düz dizi/sezon listeleri; kategoriler, büyük dizi posteri, dizi şeridi,
  özet, puan, tür, sezon sekmeleri ve bölüm satırlarını aynı ekranda gösteren
  üç panelli TV arayüzüyle değiştirildi.
- Xtream `get_series_info` yanıtındaki dizi bilgisi, sezonlar, bölüm adları,
  süreler ve varsa bölüm görselleri normalize edilir.
- Seçili sezonun bütün bölümleri ExtEplayer3'e birlikte aktarılır. Bölümlerde
  film tarafındaki PLAY/PAUSE, STOP, ±60 saniye kısa atlama ve uzun basışta
  sarma imleci aynen çalışır.
- Sağ/sol ile alan veya sekme, yukarı/aşağı ile satır, OK ile açma/oynatma
  işlemleri kumandaya uygun biçimde düzenlendi.

## v0.9.23 — film süresi ve oynatıcı hava durumu

- Film ve dizi oynatımında ExtEplayer3'ün gerçek oynatma konumu ile toplam
  süresi saniyede bir okunur. Infobarda geçen süre, kalan süre ve konuma bağlı
  ilerleme çubuğu birlikte güncellenir.
- Oynatıcıdaki hava durumu işçisi VOD içeriklerde de başlatılır. Film ekranı
  artık şehir adını gösterip `Hava verisi yükleniyor` durumunda takılı kalmaz.

## v0.9.22 — gerçek OpenATV poster ve sarma düzeltmesi

- Posterler doğrudan `setPixmapFromFile()` yerine gerçek cihazın JPEG/PNG
  çözücüsü `ePicLoad` ile yüklenir. Liste kutuları, büyük film posteri ve
  oynatıcı infobarı aynı asenkron çizim yolunu kullanır.
- Eski sürümlerin yanlış uzantılı veya HTML hata sayfası içeren geçici poster
  dosyaları doğrulanıp otomatik temizlenir.
- Liste yanıtında poster bulunmazsa seçili sayfadaki filmler için
  `get_vod_info` kapağı güvenli arka plan işinde alınır.
- OpenATV `InfobarSeekActions` / `InfobarSeekActionsPTS` keymap bağlamları
  dinlenir. Kısa ileri/geri basışı `seekRelative()` ile tam 60 saniye atlar;
  uzun basış SOL/SAĞ ve OK ile kullanılan sarma imlecini açar.
- Poster ve sarma başarısızlıkları artık `[GTIPTVPlayerPro]` etiketiyle
  Enigma2 loguna yazılır.

## v0.9.21 — çalışan posterler ve kısa/uzun sarma ayrımı

- Film listesi, büyük film ayrıntısı ve film oynatıcı infobarı aynı normalize
  edilmiş poster adresini kullanır. Göreli yollar, `//` adresleri, HTML
  kaçışları ve boşluk içeren adresler güvenli HTTP(S) biçimine çevrilir.
- Poster önbelleği indirilen görselin gerçek JPEG/PNG türünü algılar ve dosyayı
  doğru uzantıyla saklar; OpenATV'nin JPEG içeriği `.png` adı yüzünden
  gösterememesi giderildi.
- İleri/geri sarma tuşuna bir kez basılması filmi anında 60 saniye ileri/geri
  alır; ek onay istemez.
- Aynı tuşa uzun basılması sarma imlecini açar. SOL/SAĞ ile hedef zaman
  değiştirilir, OK ile seçilen yerden devam edilir ve EXIT ile seçim iptal
  edilir.

## v0.9.20 — posterli film kütüphanesi ve gerçek VOD kontrolleri

- Film ekranı solda kategoriler, altta seçilen kategorinin poster sonuçları,
  ortada büyük poster ve sağda film ayrıntıları olacak biçimde yenilendi.
- Seçili filmin puan, özet, yıl, süre, tür, yönetmen ve oyuncu verileri Xtream
  `get_vod_info` yanıtından alınır; eksik alanlar ekran düzenini bozmaz.
- Uzun film adları ayrıntı panelinde iki satıra yayılır, poster şeridinde taşma
  yapmadan üç noktayla kısaltılır.
- Film oynatılırken PLAY/PAUSE, STOP, ileri ve geri sarma kumanda komutları
  ExtEplayer3 servisinin gerçek duraklatma ve seek arayüzlerine bağlandı.
- İleri/geri sarma tuşu alt zaman çizgisini açar; SOL/SAĞ hedef zamanı değiştirir,
  OK seçilen noktadan devam ettirir ve EXIT işlemi iptal eder.
- Sunucu veya kapsayıcı sarma/duraklatmayı desteklemiyorsa kullanıcıya OSD
  üzerinde açıklayıcı bir uyarı gösterilir.

## v0.9.5 — çalışan küçük oynatıcı ve okunabilir EPG paneli

- Küçük canlı oynatıcı OpenATV'nin ana dekoder `VideoWindow` düzenine uygun
  şeffaf video yüzeyi kullanır; siyah OSD katmanı canlı görüntüyü kapatmaz.
- Yayın yüklenirken paket içindeki GT IPTV PLAYER PNG'si gösterilir ve servis
  etkinleştiğinde canlı görüntüyü açmak için otomatik olarak gizlenir.
- Piconlar küçültüldü, kanal paneline `KANAL LİSTESİ` başlığı eklendi ve program
  özeti dört büyük, okunabilir satıra genişletildi.
- Belirsiz karakter çizgisi yerine gerçek dolan ilerleme çubuğu, yüzde ve kalan
  dakika bilgisi gösterilir.
- Tam ekrandan kanal listesine ve kanal listesinden kategori ekranına dönünce
  önceki seçim korunur; liste yeniden yüklenip ilk satıra sıçramaz.

## v0.9.4 — piconlu canlı kanal ekranı

- Kategori kanal sayımı kaldırıldı; Canlı TV kategorileri yalnız kategori
  isteği tamamlanınca hemen gösterilir.
- Kanal listesinde piconlar, sağda küçük canlı önizleme ve günlük EPG bulunur.
- Program özeti uzunsa panel içinde otomatik olarak yukarı kayar.
- İlk OK küçük önizlemeyi, aynı kanaldaki ikinci OK tam ekranı açar.
- Tam ekranda EXIT, izlenen kanal seçili kalacak şekilde listeye döner.

## v0.9.3 — ikonlu hava kartları

- Canlı TV ekranının sağ hava paneli, büyük bugünkü durum kartı ve beş eşit
  günlük tahmin sütunuyla onaylanan tasarıma uyarlandı.
- Açık, parçalı bulutlu, bulutlu, sis, yağmur, kar ve fırtına için eklentiyle
  birlikte gelen şeffaf PNG ikonlar eklendi; harici hava eklentisi gerekmez.
- Open-Meteo'dan güncel nem ve rüzgâr hızı da alınarak panelin alt bilgi
  satırında gösterilir. Eski hava önbellekleri uyumlu biçimde okunmaya devam
  eder.

## v0.9.2 — Canlı TV kategorileri ve beş günlük hava durumu

- Canlı TV kategori ekranı solda simgesiz kategori adları ve gerçek kanal
  sayıları, sağda ise seçilen şehrin beş günlük tahmini olacak biçimde iki
  panolu neon tasarıma geçirildi.
- Hava verisi ek Enigma2 eklentisi veya API anahtarı istemeden Open-Meteo'dan
  alınır. Veri 30 dakika önbellekte tutulur; internet kesilirse son başarılı
  tahmin gösterilir.
- Ana paneldeki **Ayarlar** ekranına hava durumunu açma/kapatma, şehir seçimi,
  °C/°F birimi ve son güncelleme bilgisi eklendi. Şehir, ekran klavyesinden
  girilir ve mevcut ayar değiştirilmeden önce çevrimiçi doğrulanır.
- Film ve dizi tarayıcılarının mevcut görünümü ve çalışma akışı korunur.

## v0.9.1 — sonuç ekranı olmadan doğrudan hesap bağlantısı

- İlk açılıştaki `HESABA BAĞLAN` ve Hesaplar ekranındaki sarı
  `Hesaba Bağlan` işlemleri artık ayrı ONLINE/MEŞGUL sonuç ekranını açmaz.
- Xtream API doğrulaması mevcut ekran üzerinde arka planda çalışır. Başarılı
  sonuçta ek bir OK / İzlemeye Başla onayı beklenmeden ana panel doğrudan açılır.
- Bağlantı başarısızsa kullanıcı aynı ekranda kalır ve güvenli hata açıklamasını
  görür; kullanıcı adı ve parola hiçbir mesaja yazılmaz.
- Hesaplar ekranındaki OK / Otomatik Test bağımsız sunucu sağlığı ekranını
  açmaya devam eder. Bağlantı modu ve ona ait sonuç ekranı tamamen kaldırıldı.

## v0.9.0 — neon hesap listesi ve gerçek sarı tuş bağlantısı

- Hesap yönetimi ekranı, onaylanan koyu lacivert/camgöbeği neon tasarıma
  geçirildi. Sekiz satırlı liste, sayaç rozetleri, sağ seçili hesap kartı ve
  renkli kumanda tuşları gerçek Enigma2 bileşenleriyle çalışır.
- Dekor katmanı yalnız panoları taşır. Hesap adları, hesap/kaynak sayıları,
  seçim çerçevesi ve bağlantı durumu cihazdaki gerçek verilerle çizilir.
- Sarı tuştaki eski `Yenile` işlemi kaldırıldı ve `Hesaba Bağlan` eklendi.
  Seçili hesap Xtream API üzerinden gerçekten doğrulanır; başarılı bağlantı
  sonrasında ana panele ve içeriklere geçilir.
- OK tuşundaki bağımsız otomatik sunucu sağlık testi korunur. Kırmızı hesap
  silme ve EXIT geri dönüş davranışları değişmez.
- Tema 1280x720, 8-bit/256 renk palet PNG olarak paketlenir ve 720x405 Octagon
  OSD sınırları içinde ölçeklenir.

## v0.8.9 — hesap yönetimi ve orta pano hizası

- `HESAPLARI YÖNET` panosunun hareketli camgöbeği çerçevesi, onaylı arka
  plandaki daha geniş orta kartın gerçek sınırlarına oturtuldu.
- Hesap yönetimi ekranındaki eski `Yeni Hesap` kısayolu kaldırıldı; yeni hesap
  yalnız ana ekrandaki ayrı `HESAP EKLE` panosundan oluşturulur.
- Kırmızı tuş seçili hesabı siler. İşlemden önce hesap adıyla evet/hayır onayı
  gösterilir; parola ve kullanıcı adı hiçbir mesajda gösterilmez.
- Silme işlemi yalnız seçili hesap kimliğine ait satırı desteklenen hesap
  dosyalarından atomik olarak kaldırır; diğer hesaplar ve yorumlar korunur.

## v0.8.8 — onaylanan neon hesap merkezi ve OpenATV crash düzeltmesi

- Karşılama ekranı, onaylanan büyük neon hesap kartı, güvenlik kalkanı,
  sunucu simgesi ve üç ikonlu işlem panosunu içeren gerçek bir dekor katmanına
  geçirildi. Değişken hesap, sürüm, cihaz ve kumanda metinleri kodla çizilmeye
  devam eder.
- Dekor katmanı Octagon/OpenATV için 1280x720, 8-bit/256 renk palet PNG olarak
  paketlenir; düz renkli eski hesap ekranına geri düşülmez.
- Camgöbeği dört kenarlı odak çerçevesi üç panonun gerçek sınırları üzerinde
  hareket eder; `HESABA BAĞLAN`, `HESAPLARI YÖNET` ve `HESAP EKLE` işlevleri
  korunur.
- Hesap ekleme formundaki durum listesi artık Enigma2 `Screen.values()`
  metodunu ezmez. Form açılırken veya kapanırken oluşan
  `TypeError: 'list' object is not callable` hatası giderildi.
- Test ortamı gerçek OpenATV ekran kapanışındaki `values()` çağrısını taklit
  eder; aynı isim çakışmasının yeniden oluşması engellenir.

## v0.8.7 — üç panolu hesap merkezi ve ayrı hesap ekleme formu

- Karşılama ekranındaki işlem alanı `HESABA BAĞLAN`, `HESAPLARI YÖNET` ve
  `HESAP EKLE` olmak üzere üç gerçek kumanda panosuna genişletildi.
- YUKARI/AŞAĞI ile camgöbeği neon odak çizgisi üç pano arasında hareket eder;
  sabit resim veya metne gömülü imleç kullanılmaz.
- `HESAPLARI YÖNET` mevcut güvenli hesap listesini açar. `HESAP EKLE` ise
  sunucu URL'si, kullanıcı adı ve parola için üç ayrı alan içeren özel paneli
  açar.
- Her alan OK ile Enigma2 sanal klavyesinde düzenlenir. Parola forma dönünce
  yıldızlanır; ana ekranda veya hesap listesinde hiçbir zaman gösterilmez.
- YEŞİL ile kayıt doğrulanıp eklentinin özel `playlists.txt` dosyasına atomik
  biçimde yazılır; kayıt tamamlanınca ana ekrandaki hesaplar yenilenir.
- Oynatıcı, EPG, bilgi bandı ve v0.8.6'da sabitlenen ana panel değiştirilmez.

## v0.8.6 — Octagon görsel ve menü geometrisi düzeltmesi

- Dekor katmanı 1280x720, 8-bit/256 renk palet PNG biçimine dönüştürüldü;
  futbol, film, dizi ve favori görselleri Octagon/OpenATV dekoderiyle uyumlu
  şekilde yeniden görünür hâle getirildi.
- Altı menü satırının yazısı, hareketli neon alt çizgisi ve sol kenar vurgusu
  artık aynı panel geometrisinden hesaplanır. Çizgi komşu satıra kayıp yazının
  üstüne binemez.
- Canlı TV vitrini ile Filmler, Diziler ve Favoriler kartlarının seçimi izleyen
  dört kenarlı neon parlaması korunur.
- Dinamik başlık/açıklama, güvenli sunucu URL'si, canlı saat ve alt kumanda
  rehberi korunur; sabit `>` imleci geri getirilmez.
- 720x405 Octagon OSD'sinde bütün menü satırları ve alt yardım şeridi ekran
  sınırları içinde kalır.
- Oynatıcı, EPG, bilgi bandı, hesaplar ve `playlists.txt` değiştirilmez.

## v0.8.5 — gerçek, serbest çalışan ana panel

- Ana panel artık yazı, saat, sunucu bilgisi ve seçimi içine gömülmüş sabit bir
  ekran görüntüsü değildir. PNG yalnız futbol, film, dizi ve favori sanatını
  taşır; bütün panolar gerçek Enigma2 bileşenleriyle çalışır.
- YUKARI/AŞAĞI ile neon seçim çizgisi ve sol kenar vurgusu gerçekten satırlar
  arasında hareket eder. Sabit `>` imleci tamamen kaldırıldı.
- Seçim değiştiğinde sağ vitrindeki rozet, başlık ve açıklama anında güncellenir;
  Filmler, Diziler ve Favoriler alt kartlarının dört kenarlı neon parlaması da
  seçimi izler. Canlı TV seçiliyken sağ üst futbol vitrini neon çerçevelenir.
- Üst çubukta hesap adı, parolasız sunucu URL'si, durum ve canlı saat görünür.
  Alt çubukta YUKARI/AŞAĞI, OK, MENÜ ve EXIT kumanda yönlendirmesi bulunur.
- Ana panel cihazın gerçek OSD çözünürlüğünü kullanır. 720x405 bildiren Octagon
  artık zorla 1280x720 tuvale geçirilmez; taşma ve kesilme önlenir.
- Oynatıcı, EPG, bilgi bandı, hesaplar ve `playlists.txt` değiştirilmez.

## v0.8.4 — ana panel kumanda ve görünür odak düzeltmesi

- Ana panelin gerçek `ActionMap` bağlantısı OpenATV kumandalarında kullanılan
  yön, liste, kanal ve sayfa eylemleriyle genişletildi; ekran gösterildiğinde
  kumanda haritası açıkça etkinleştirilir.
- YUKARI/AŞAĞI seçim değiştirir, OK seçilen bölümü açar; EXIT/Geri/Kırmızı ana
  panelden çıkar. Kanal ve sayfa tuşları menü gezinmesi için yedek olarak çalışır.
- Seçim artık sabit PNG parlamasına bağlı değildir: hareket eden ok ve neon alt
  çizgi gerçek seçili satırı gösterir; Film/Dizi/Favoriler alt kart çizgisi de
  seçimle birlikte yanar.
- Onaylanan 1280x720 tasarım, oynatıcı, EPG, bilgi bandı, hesaplar ve
  `playlists.txt` korunur.

## v0.8.3 — onaylanan tasarımın birebir tam ekran uygulanması

- Ana panelde yaklaşık bir arayüz yerine kullanıcının onayladığı futbol vitrini,
  büyük neon sol menü ve Film, Dizi, Favoriler görsel kartlarını içeren tamamlanmış
  tasarım doğrudan kullanılır.
- Octagon/OpenATV 720x405 mantıksal GUI ölçüsü bildirse bile ana panel 1280x720
  OSD tuvalini doldurur; ortada küçük panel olarak kalmaz.
- Büyük PNG, Enigma2 `ePicLoad` ile cihaz çözünürlüğüne açılır. Dekoderin
  kullanılamadığı imajlarda eski ePixmap yolu otomatik yedek olarak korunur.
- Oynatıcı, EPG, bilgi bandı, hesaplar ve `playlists.txt` değiştirilmez.

## v0.8.2 — Octagon neon arka plan düzeltmesi

- Onaylanan tam ekran neon ana panel PNG'si, Octagon/OpenATV'de ePixmap
  oluştuktan sonra ayrıca yüklenir; yalnız skin XML yüklemesine bağlı kalmaz.
- Menü katmanı şeffaflaştırıldığı için futbol vitrini ile Film, Dizi ve
  Favoriler görsellerinin üstü artık koyu kutularla kapatılmaz.
- Octagon'un 720x405 OSD düzleminde başlık, menü, durum ve alt kart yazıları
  uzaktan okunacak ölçüye büyütülür.
- Oynatıcı, EPG, bilgi bandı ve hesap verileri değiştirilmez.

## v0.8.1 — canlı neon ana panel

- Hesaba başarıyla bağlandıktan sonra açılan ana panel, onaylanan koyu lacivert
  neon tasarıma geçirildi; spor vitrini ile Filmler, Diziler ve Favoriler görsel
  kartları hafif bir yerel PNG arka planında gösterilir.
- Soldaki menü Canlı TV, Filmler, Diziler, Favoriler, Ayarlar ve Hakkında olmak
  üzere altı gerçek kumanda seçimine genişletildi; seçili bölüm mor, camgöbeği
  veya pembe odak çerçevesiyle açıkça görünür.
- Üst şeritte hesap adı güvenli biçimde, sunucu durumu ve cihazın canlı saati
  gösterilir; kullanıcı adı ve parola hiçbir zaman yazdırılmaz.
- Vitrin başlığı ile açıklaması seçime göre anında değişir. Canlı TV, Filmler ve
  Diziler mevcut çalışan içerik tarayıcılarına bağlanmaya devam eder.
- Onaylanan 2026 teması için hazırlanan görsel arka plan eklenti paketinin
  içinde bulunur; ağdan görsel indirme veya ağır animasyon kullanılmaz.
- v0.7.3'te doğrulanan ExtEplayer3, CH+/CH-, üç saniyelik bilgi bandı, picon ve
  Şimdi/Sonra EPG akışına dokunulmadı.

## v0.8.0 — modern 2026 arayüzü

- Karşılama ekranı koyu mor-mavi GT temasıyla iki sütunlu düzene geçirildi;
  cihaz bilgisi, seçili hesap ve bağlantı işlemleri artık ayrı ve daha okunaklı
  panellerde gösterilir.
- Ana panel solda kumanda dostu dikey içerik menüsü, sağda seçili Canlı TV /
  Filmler / Diziler için büyük bilgi vitrini olacak şekilde yenilendi.
- Seçili işlem mor odak çizgisi ve açık metin hiyerarşisiyle belirginleştirildi;
  düşük RAM'li cihazlar için yalnız yerel Enigma2 Label/Screen bileşenleri
  kullanıldı, ağır görsel ve animasyon eklenmedi.
- Hesaplar, sunucu sağlığı ve içerik tarayıcı ekranları aynı renk, boşluk ve
  kumanda yardım sistemiyle görsel olarak birleştirildi.
- v0.7.3'te cihazda doğrulanan ExtEplayer3, CH+/CH-, üç saniyelik bilgi bandı,
  picon ve Şimdi/Sonra EPG akışı değiştirilmedi.

## v0.7.3 — sağlayıcı uyumlu Şimdi/Sonra EPG

- Canlı kanal EPG'si önce sağlayıcının çalışan Xtream
  `get_simple_data_table` yolundan alınır; boş veya desteklenmeyen yanıtta
  `get_short_epg` otomatik yedek olarak kullanılır.
- Günlük EPG listesinden kanalın saat itibarıyla gerçekten oynayan ve ardından
  gelecek programı seçilir; Base64 ve düz metin başlık desteği korunur.
- EPG ağdan geç gelse bile bilgi bandı sonuç ekrana yazıldıktan sonra yeniden
  açılır ve tam üç saniye görünür kalır.

## v0.7.2 — görünür kanal bilgi OSD'si ve gerçek CH tuşları

- Kanal bilgi bandı ExtEplayer3 oynatıcı penceresinden ayrılarak OpenATV'nin
  yerel OSD'leri gibi bağımsız, yüksek katmanlı bir pencereye taşındı.
- Kanal açılışında, **CH+ / CH-** ile geçişte ve **OK** tuşunda bant gerçekten
  ekranın üstünde görünür; üç saniye sonra tamamen kapanır.
- OpenATV 7.6'nın fiziksel kanal tuşları için kullandığı `channelUp`,
  `channelDown`, `nextBouquet`, `prevBouquet`, `pageUp` ve `pageDown`
  eylemleri doğrudan bağlandı.
- Picon, kanal adı, çözünürlük, FPS, video/ses codec'i ile Şimdi/Sonra EPG
  alanları aynı onaylı tasarımda korunur.

## v0.7.1 — OpenATV güvenli ekran kapanışı

- İçerik ve oynatıcı ekranlarının OpenATV `Screen.items()` metodunu ezmesi önlendi.
- **EXIT** ile oynatıcıdan veya içerik listesinden çıkarken oluşan
  `TypeError: 'list' object is not callable` mavi ekranı giderildi.
- Kanal listesi, **CH+ / CH-**, ExtEplayer3, bilgi bandı, picon ve otomatik EPG
  davranışı korundu.

## v0.7.0 — canlı yayın bilgi bandı, kanal değiştirme ve otomatik EPG

- Oynatıcı ekranı şeffaf hale getirildi; yayın başladıktan sonra ekranda sabit
  yazı veya siyah arka plan kalmaz.
- Canlı yayında **CH+ / CH-** ile aynı kategorideki kanallar arasında doğrudan
  geçiş yapılır; oynatma servis tipi `5002` ve ExtEplayer3 olarak korunur.
- Kanal açıldığında veya değiştirildiğinde alt bilgi bandı üç saniye görünür,
  ardından otomatik kapanır. **OK** tuşu bandı yeniden gösterir.
- Sağlayıcının kanal piconu solda gösterilir; picon yoksa güvenli GT yer tutucusu
  kullanılır.
- Gerçek oynatma servisinden çözünürlük, kalite sınıfı, FPS, video codec ve ses
  codec bilgileri okunur.
- Xtream `get_short_epg` üzerinden kanalın **Şimdi** ve **Sonra** programları
  otomatik alınır; Base64 ve düz metin EPG başlıkları desteklenir.
- Bilgi bandının başlık, teknik bilgi ve EPG yazıları onaylanan tasarıma göre
  bir kademe küçültüldü.

## v0.6.1 — EXIT / STOP oynatıcı dönüş düzeltmesi

- OpenATV `MoviePlayer` ekranının iç içe eklenti ekranlarında bozduğu modal
  pencere zinciri kaldırıldı.
- Servis tipi `5002` ve ExtEplayer3 oynatma korunarak GT'nin kendi oynatıcı
  ekranı zorunlu hale getirildi.
- **EXIT**, **STOP** veya **KIRMIZI** tuş yayını durdurur, önceki TV servisini
  geri yükler ve kanal/film/bölüm listesine döner.
- OpenATV'nin `Modal open are allowed only from a screen which is modal`
  mavi ekranını oluşturan oynatıcı yolu kapatıldı.

## v0.6.0 — Xtream içerik tarayıcı ve ExtEplayer3 oynatma

- Hesap bağlantısından sonra Canlı TV, Filmler ve Diziler Xtream API'den
  yüklenir.
- Canlı TV ve filmlerde kategori/içerik seçimi, dizilerde kategori/dizi/
  sezon-bölüm seçimi bulunur.
- Canlı yayın, film ve dizi bölümleri Enigma2 servis tipi `5002` ile
  ExtEplayer3 üzerinden oynatılır.
- Liste çağrıları arka planda yürütülür; kullanıcı adı ve parola ekranda veya
  hata metninde gösterilmez.

## v0.5.1 — playlists.txt otomatik hazırlanır

- Device Lab kurulumu `/etc/enigma2/gtiptvplayer/playlists.txt` dosyasını
  otomatik oluşturur; WinSCP'de klasör ve dosya doğrudan görünür.
- Eklenti ilk açılışta dosya silinmişse aynı yolu yeniden hazırlar.
- Klasör `0700`, dosya `0600` izinle oluşturulur.
- Güncellemede mevcut dosya boşaltılmaz veya değiştirilmez; kayıtlı URL'ler
  aynen korunur.

## v0.5.0 — Octagon üzerinden yeni hesap ekleme

- **Hesaplar** ekranında **YEŞİL / Yeni Hesap** ile Enigma2 sanal klavyesi açılır.
- Tam Xtream/M3U URL ve ardından hesap adı kumandayla girilip kaydedilir.
- Kayıt, eklentinin özel `/etc/enigma2/gtiptvplayer/playlists.txt` dosyasına
  atomik biçimde ve yalnız cihaz sahibi tarafından okunabilecek izinlerle yazılır.
- Aynı sunucu ve kullanıcı yeniden eklenirse mükerrer satır oluşturulmaz; hesap
  adı ve parola güncellenir.
- Kaydetme sonrası hesap listesi anında yenilenir ve yeni hesap otomatik seçilir.
- Kullanıcı adı ve parola liste ekranında veya hata mesajlarında gösterilmez.

## v0.4.0 — hesap karşılama ekranı ve yenilenen skin

- Eklenti artık doğrudan içerik kartlarıyla değil, **Hoş geldin** hesabı bağlama
  ekranıyla açılır.
- Kayıtlı hesaplar ilk ekranda sol/sağ tuşlarıyla değiştirilebilir; kullanıcı adı
  ve parola hiçbir zaman gösterilmez.
- **Hesaba Bağlan** seçildiğinde Xtream hesabı ve sunucu sağlığı otomatik
  doğrulanır. Başarılı sonuçtan sonra **OK / İzlemeye Başla** ile ana ekrana
  geçilir.
- İçerik ana ekranı bağlı hesap bilgisini ve `ONLINE` / `MEŞGUL` durumunu
  gösterir; Canlı TV, Filmler ve Diziler artık ayrı üç büyük karttır.
- Hesap bulunamadığında ilk ekran kullanıcıyı doğrudan hesap listesine
  yönlendirir.
- Skin; daha güçlü başlık hiyerarşisi, geniş hesap kartı, belirgin yeşil ana
  işlem düğmesi ve sadeleştirilmiş kumanda yardım çubuğuyla yenilendi.

## v0.3.0 — playlists.txt ve otomatik sunucu sağlığı

- Dashboard içindeki **Hesaplar** kartı artık gerçek hesap listesini açar.
- Önce `/etc/enigma2/gtiptvplayer/playlists.txt`, ardından mevcut XStreamity
  ve JediMakerXtream `playlists.txt` dosyaları okunur.
- Aynı hesap birden fazla listede bulunursa tek kez gösterilir.
- Kullanıcı adı ve parola arayüzde veya hata metinlerinde gösterilmez.
- Hesap ekranında yön tuşlarıyla seçim yapılır; **OK** seçilen sunucunun sağlık
  testini otomatik başlatır.
- Xtream `player_api.php` üzerinden API erişimi, gecikme, hesap durumu,
  aktif/maksimum bağlantı, bitiş tarihi ve sunucu saati ölçülür.
- Bağlantı limiti doluysa **MEŞGUL**; hesap doğrulanmıyorsa **GEÇERSİZ**;
  erişim sağlanamazsa **HATA** durumu gösterilir.
- Ağ kontrolü arka planda çalıştığı için Enigma2 arayüzü test sırasında
  kilitlenmez.
- En fazla 1 MB büyüklüğünde liste ve 50 hesap işlenir.

Liste satırı örneği:

```text
http://sunucu:port/get.php?username=KULLANICI&password=PAROLA&type=m3u_plus&output=ts # Ev
```

Yalnızca size ait veya kontrol etme yetkiniz bulunan hesaplarda kullanın.

Kurulum için proje kökündeki `DEPLOY-GT-IPTV-PLAYER.cmd` kullanılır. Yükleyici
mevcut eklentiyi yedekler, cihaz Python'u ile derleme kontrolü yapar, Enigma2'yi
yeniden başlatır ve sağlık testi başarısız olursa eski sürümü otomatik geri
yükler.
