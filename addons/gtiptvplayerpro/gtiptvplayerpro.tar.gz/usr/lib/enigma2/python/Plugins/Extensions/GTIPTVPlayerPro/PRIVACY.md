# GT IPTV Player Pro — Gizlilik ve dış servisler

GT IPTV Player Pro, hesap bilgilerini cihazdaki
`/etc/enigma2/gtiptvplayer/playlists.txt` dosyasında özel dosya izinleriyle
saklar. Tanılama günlükleri kullanıcı adı, parola ve erişim tokenlerini
maskelemeye çalışır.

## IPTV sunucusu

Eklenti, kullanıcının eklediği Xtream sunucusuna kullanıcı adı ve parola ile
bağlanır. HTTPS bağlantısı aktarımı şifreler. HTTP bağlantısı ise kullanıcı adı,
parola, yayın adresleri ve izleme isteklerini ağ üzerinde şifrelemez. Sunucu
destekliyorsa kullanıcı adresi `https://` olarak girebilir.

## Open-Meteo

Hava durumu etkinse seçilen şehir adı konum araması için, bulunan koordinatlar
ve sıcaklık birimi ise tahmin isteği için Open-Meteo'ya gönderilir. IPTV hesap
bilgileri Open-Meteo'ya gönderilmez.

Weather data by [Open-Meteo.com](https://open-meteo.com/), CC BY 4.0.

## TMDb

TMDb bilgi tamamlama kullanıcı tarafından etkinleştirildiğinde film veya dizi
adı, içerik türü ve kullanıcının girdiği TMDb API anahtarı ya da erişim tokeni
TMDb'ye gönderilir. IPTV kullanıcı adı ve parolası TMDb'ye gönderilmez.

This product uses the TMDB API but is not endorsed or certified by TMDB.

## Güncelleme

Güncelleme kontrolü yalnız kullanıcı **Güncellemeleri Test Et** işlemini
başlattığında resmî GitHub yayın adresine bağlanır. Paket kurulmadan önce
manifest ve ZIP imzaları yerel olarak doğrulanır ve ayrıca kullanıcı onayı
istenir.
