from enigma import eTimer
from Components.Converter.Converter import Converter

class AthanTimesConditionalShowHide(Converter, object):
        def __init__(self, argstr):
                Converter.__init__(self, argstr)
                args = argstr.split(',')
                self.invert = "Invert" in args
                self.blink = "Blink" in args
                if self.blink:
                        self.blinktime = 500
                        self.timer = eTimer()
                        try:
                            self.timer.callback.append(self.blinkFunc)
                        except:
                            self.time_conn = self.timer.timeout.connect(self.blinkFunc)
                else:
                        self.timer = None

        def blinkFunc(self):
                if self.blinking == True:
                        for x in self.downstream_elements:
                                x.visible = not x.visible

        def startBlinking(self):
                self.blinking = True
                self.timer.start(self.blinktime)

        def stopBlinking(self):
                self.blinking = False
                for x in self.downstream_elements:
                        if x.visible:
                                x.hide()
                self.timer.stop()

        def calcVisibility(self):
                b = self.source.boolean
                if b is None:
                        return True
                b ^= self.invert
                return b

        def changed(self, what):
                vis = self.calcVisibility()
                if self.blink:
                        if vis:
                                self.startBlinking()
                        else:
                                self.stopBlinking()
                else:
                        for x in self.downstream_elements:
                                x.visible = vis

        def connectDownstream(self, downstream):
                Converter.connectDownstream(self, downstream)
                vis = self.calcVisibility()
                if self.blink:
                        if vis:
                                self.startBlinking()
                        else:
                                self.stopBlinking()
                else:
                        downstream.visible = self.calcVisibility()

        def destroy(self):
                if self.timer:
                        try:
                            self.timer.callback.remove(self.blinkFunc)
                        except:
                            self.timer.callback_conn = None
