# -*- coding: utf-8 -*-
"""
AutoBiss E2 - Key Analyzer Module
Extracts and logs service information (PIDs, CAIDs, etc.) for offline analysis.
Compatible with Python 2.7 and Python 3.x
"""
from __future__ import absolute_import, print_function, division

from enigma import iServiceInformation
from time import strftime
import os

_DEBUG_PATH = '/tmp/autobiss_debug.log'

def _log(msg):
    try:
        with open(_DEBUG_PATH, 'a') as f:
            f.write("[{}] [key_analyzer] {}\n".format(strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass

def write_service_info(session, base_filepath):
    """
    Write a .txt file next to the .ts recording containing:
    - Service Name & Reference
    - Video / Audio / PCR / PMT / TXT PIDs
    - CAIDs (if any)
    - Encryption status
    Useful for feeding into external BISS/PowerVu key extraction tools.
    """
    try:
        service = session.nav.getCurrentService()
        if not service:
            return
        info = service.info()
        if not info:
            return

        ref = session.nav.getCurrentlyPlayingServiceReference()
        sname = ref.getName() if ref and hasattr(ref, 'getName') else "Unknown"

        txt_path = base_filepath.replace(".ts", ".txt")

        # Gather technical data
        data = {}
        data['Service Name'] = sname
        data['Video PID'] = info.getInfo(iServiceInformation.sVideoPID)
        data['Audio PID'] = info.getInfo(iServiceInformation.sAudioPID)
        data['PCR PID'] = info.getInfo(iServiceInformation.sPCRPID)
        data['PMT PID'] = info.getInfo(iServiceInformation.sPMTPID)
        data['TXT PID'] = info.getInfo(iServiceInformation.sTXTPID)
        data['SID'] = info.getInfo(iServiceInformation.sSID)
        data['TSID'] = info.getInfo(iServiceInformation.sTSID)
        data['ONID'] = info.getInfo(iServiceInformation.sONID)

        # CAIDs list
        try:
            caids = info.getInfoObject(iServiceInformation.sCAIDs)
            if caids:
                data['CAIDs'] = ', '.join(["0x{:04X}".format(c) for c in caids])
            else:
                data['CAIDs'] = 'None (FTA)'
        except Exception:
            data['CAIDs'] = 'Unknown'

        # Encryption flag
        try:
            is_crypted = info.getInfo(iServiceInformation.sIsCrypted)
            data['Encrypted'] = 'Yes' if is_crypted == 1 else 'No'
        except Exception:
            data['Encrypted'] = 'Unknown'

        # Service Reference string (used by many E2 tools)
        data['ServiceReference'] = str(ref) if ref else 'N/A'

        # Build text output
        lines = []
        lines.append("=" * 55)
        lines.append(" AutoBiss E2 - Service Information Log")
        lines.append(" Generated: {}".format(strftime("%Y-%m-%d %H:%M:%S")))
        lines.append("=" * 55)
        lines.append("")
        for key, val in data.items():
            lines.append(" {:20s}: {}".format(key, val))
        lines.append("")
        lines.append("=" * 55)
        lines.append(" Use this information for offline BISS/PowerVu analysis.")
        lines.append("=" * 55)

        # Python 2/3 safe write
        with open(txt_path, 'w') as f:
            f.write('\n'.join(lines))

        _log("Service info saved to: {}".format(txt_path))
    except Exception as e:
        _log("Failed to write service info: {}".format(e))


def is_channel_encrypted(session):
    """Return True if the currently playing service reports as encrypted."""
    try:
        service = session.nav.getCurrentService()
        if not service:
            return False
        info = service.info()
        if not info:
            return False
        return info.getInfo(iServiceInformation.sIsCrypted) == 1
    except Exception:
        return False
