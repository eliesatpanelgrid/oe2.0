# -*- coding: utf-8 -*-
"""AutoBiss notification helper.

Uses Enigma2's NotificationPopup (non-blocking) with graceful fallbacks.
"""
from __future__ import absolute_import, print_function, division

# Feature switch honouring the user setting
_enabled = True


def set_enabled(flag):
    global _enabled
    _enabled = bool(flag)


def is_enabled():
    return _enabled


def _resolve_popup():
    """Return the best available popup class, or None."""
    candidates = (
        ("Screens.MessageBox", "NotificationPopup"),
        ("Components.NotificationPopup", "NotificationPopup"),
    )
    for module, attr in candidates:
        try:
            mod = __import__(module, fromlist=[attr])
            cls = getattr(mod, attr, None)
            if cls:
                return cls
        except Exception:
            continue
    return None


def notify(session, text, title="AutoBiss", timeout=4, kind="info"):
    """Show a non-blocking notification. Never raises."""
    if not _enabled or session is None:
        return False
    try:
        text = str(text)
    except Exception:
        text = "?"
    Popup = _resolve_popup()
    if Popup is None:
        return _fallback(session, text, title, timeout, kind)
    try:
        session.open(Popup, text, title=title, timeout=timeout)
        return True
    except Exception:
        return _fallback(session, text, title, timeout, kind)


def _fallback(session, text, title, timeout, kind):
    """MessageBox with timeout, so behaviour stays close to the old UX."""
    try:
        from Screens.MessageBox import MessageBox
    except Exception:
        return False
    try:
        if kind == "error":
            t = MessageBox.TYPE_ERROR
        elif kind == "warning":
            t = MessageBox.TYPE_WARNING
        else:
            t = MessageBox.TYPE_INFO
        session.open(MessageBox, text, t, timeout=max(1, timeout), title=title)
        return True
    except Exception:
        return False


# Convenience wrappers -------------------------------------------------
def info(session, text, title="AutoBiss", timeout=4):
    return notify(session, text, title, timeout, "info")


def success(session, text, title="AutoBiss", timeout=4):
    return notify(session, text, title, timeout, "info")


def warning(session, text, title="AutoBiss", timeout=5):
    return notify(session, text, title, timeout, "warning")


def error(session, text, title="AutoBiss", timeout=6):
    return notify(session, text, title, timeout, "error")
