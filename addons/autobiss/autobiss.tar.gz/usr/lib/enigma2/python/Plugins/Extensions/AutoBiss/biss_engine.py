# -*- coding: utf-8 -*-
"""
AutoBiss E2 - BISS Engine Module v3.0
Real-time CW extraction from tsdec stderr, SoftCam.Key writer, softcam reloader
Compatible with Python 2.7 and Python 3.x
"""
from __future__ import absolute_import, print_function, division

import os
import re
import json
import base64
import threading
import subprocess
from time import strftime, time

# ------------------------------------------------------------------------------
# Debug helper
# ------------------------------------------------------------------------------
_DEBUG_PATH = '/tmp/autobiss_debug.log'

def log_debug(msg):
    try:
        with open(_DEBUG_PATH, 'a') as f:
            f.write("[{}] [biss_engine] {}\n".format(strftime("%Y-%m-%d %H:%M:%S"), msg))
        try:
            os.chmod(_DEBUG_PATH, 0o600)
        except Exception:
            pass
    except Exception:
        pass

def _mask_cw(cw):
    """Return a partially masked CW for safe logging (first 4 hex chars visible)."""
    if not cw or len(cw) < 4:
        return "****"
    return "{}{}".format(cw[:4], "*" * (len(cw) - 4))

# ------------------------------------------------------------------------------
# Constants
# ------------------------------------------------------------------------------
BISS_CAID = 0x2600
KEYS_FILE = "/media/hdd/biss_keys.txt"
SOFTCAM_KEY = "/etc/tuxbox/config/SoftCam.Key"
OUTPUT_DIR = "/media/hdd/movie/"
TSDEC_CMD = "tsdec"
OSCAM_WEB_PORT = 8888

# ------------------------------------------------------------------------------
# Settings (persisted in /etc/enigma2 so updates never wipe them)
# ------------------------------------------------------------------------------
SETTINGS_FILE = "/etc/enigma2/autobiss_settings.json"
SOFTCAM_CANDIDATES = [
    "/etc/tuxbox/config/SoftCam.Key",
    "/etc/tuxbox/config/oscam-emu/SoftCam.Key",
    "/etc/tuxbox/config/oscam/SoftCam.Key",
    "/usr/keys/SoftCam.Key",
    "/etc/SoftCam.Key",
]

def _detect_emu_config_dir():
    """Parse --config-dir from running oscam/ncam cmdlines via /proc.
    This finds the SoftCam.Key the ACTIVE emulator actually reads."""
    try:
        for pid in os.listdir("/proc"):
            if not pid.isdigit():
                continue
            try:
                with open("/proc/{}/cmdline".format(pid), "rb") as f:
                    raw = f.read().replace(b"\x00", b" ").decode("utf-8", "replace")
            except Exception:
                continue
            low = raw.lower()
            if ("oscam" not in low and "ncam" not in low) or "--config-dir" not in raw:
                continue
            parts = raw.split()
            for i, p in enumerate(parts):
                if p == "--config-dir" and i + 1 < len(parts):
                    d = parts[i + 1].strip()
                    if d:
                        return d
                elif p.startswith("--config-dir="):
                    d = p.split("=", 1)[1].strip()
                    if d:
                        return d
    except Exception as e:
        log_debug("_detect_emu_config_dir error: {}".format(e))
    return None
DEFAULT_SETTINGS = {
    "softcam_path":   "auto",
    "record_duration": 1,
    "cooldown":        60,
    "notifications":   True,
    "last_feed_cursor": "",
}

def load_settings():
    """Load settings dict, merged over DEFAULT_SETTINGS. Never raises."""
    cfg = dict(DEFAULT_SETTINGS)
    try:
        if os.path.isfile(SETTINGS_FILE):
            with open(SETTINGS_FILE, "r") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in data.items():
                    if k in cfg:
                        cfg[k] = v
    except Exception as e:
        log_debug("load_settings error: {}".format(e))
    try:
        cfg["record_duration"] = int(cfg.get("record_duration", 1))
    except Exception:
        cfg["record_duration"] = 1
    if cfg["record_duration"] not in (1, 2, 3, 5):
        cfg["record_duration"] = 1
    try:
        cfg["cooldown"] = int(cfg.get("cooldown", 60))
    except Exception:
        cfg["cooldown"] = 60
    if cfg["cooldown"] not in (30, 60, 120, 300):
        cfg["cooldown"] = 60
    cfg["notifications"] = bool(cfg.get("notifications", True))
    cfg["last_feed_cursor"] = str(cfg.get("last_feed_cursor", "") or "")
    if cfg.get("softcam_path") not in (["auto"] + SOFTCAM_CANDIDATES):
        cfg["softcam_path"] = "auto"
    return cfg

def save_settings(cfg):
    """Persist settings dict. Returns True on success."""
    try:
        clean = {}
        for k in DEFAULT_SETTINGS:
            clean[k] = cfg.get(k, DEFAULT_SETTINGS[k])
        with open(SETTINGS_FILE, "w") as f:
            json.dump(clean, f)
        try:
            os.chmod(SETTINGS_FILE, 0o600)
        except Exception:
            pass
        log_debug("Settings saved: {}".format(clean))
        return True
    except Exception as e:
        log_debug("save_settings error: {}".format(e))
        return False

def get_softcam_path(cfg=None):
    """Resolve SoftCam.Key path.

    Priority: explicit setting > ACTIVE emulator's --config-dir >
    first existing candidate > default.
    """
    try:
        path = (cfg or load_settings()).get("softcam_path", "auto")
        if path and path != "auto" and os.path.isfile(path):
            return path
    except Exception:
        pass
    try:
        emu_dir = _detect_emu_config_dir()
        if emu_dir:
            emu_key = os.path.join(emu_dir, "SoftCam.Key")
            if os.path.isdir(emu_dir):
                log_debug("Emulator config dir detected: {}".format(emu_dir))
                return emu_key
    except Exception as e:
        log_debug("Emu config dir detect error: {}".format(e))
    for cand in SOFTCAM_CANDIDATES:
        try:
            if os.path.isfile(cand):
                return cand
        except Exception:
            pass
    return SOFTCAM_KEY

def remove_autobiss_keys():
    """Delete AutoBiss-written lines from every known SoftCam.Key file."""
    removed = 0
    targets = []
    try:
        targets.append(get_softcam_path())
    except Exception:
        pass
    for cand in SOFTCAM_CANDIDATES:
        if cand not in targets:
            targets.append(cand)
    for path in targets:
        try:
            if not os.path.isfile(path):
                continue
            with open(path, "r") as f:
                lines = f.readlines()
            kept = [l for l in lines if "[AutoBiss]" not in l]
            lost = len(lines) - len(kept)
            if lost > 0:
                with open(path, "w") as f:
                    f.writelines(kept)
                removed += lost
                log_debug("Cleanup: removed {} lines from {}".format(lost, path))
        except Exception as e:
            log_debug("Cleanup error on {}: {}".format(path, e))
    return removed

# ------------------------------------------------------------------------------
# CW Cache
# ------------------------------------------------------------------------------
class CWCache(object):
    """
    In-memory cache of SID -> CW mappings, persisted to biss_keys.txt.

    Format per line (single source of truth for file + UI):
        F <SID> <VPID> <CW_HEX> <CHANNEL_NAME>
    """
    def __init__(self, path=None):
        self._cache = {}   # sid_int -> cw_hex_str
        self._meta = {}    # sid_int -> (vpid, name)
        self._path = path or self._default_path()
        self._load()

    @staticmethod
    def _default_path():
        for base in ("/media/hdd", "/media/usb", "/media/ssd", "/data"):
            try:
                if os.path.isdir(base):
                    return os.path.join(base, "biss_keys.txt")
            except Exception:
                continue
        return KEYS_FILE

    @property
    def path(self):
        return self._path

    def _load(self):
        if not os.path.isfile(self._path):
            log_debug("Keys file not found: {}".format(self._path))
            return
        try:
            with open(self._path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parsed = self._parse_line(line)
                    if parsed:
                        sid, cw, vpid, name = parsed
                        self._cache[sid] = cw
                        self._meta[sid] = (vpid, name)
            log_debug("Loaded {} cached CWs from {}".format(len(self._cache), self._path))
        except Exception as e:
            log_debug("Failed to load keys file: {}".format(e))

    @staticmethod
    def _parse_line(line):
        """Accept the new 'F ...' format and the legacy '=' format."""
        try:
            if line.startswith('F '):
                parts = line.split()
                if len(parts) >= 4:
                    ident = parts[1]
                    # F <IDENT> 00 <CW> ;<name>
                    cw = None
                    if _is_cw(parts[2]):
                        cw = parts[2]
                    elif _is_cw(parts[3]):
                        cw = parts[3]
                    if cw:
                        sid = int(ident[:4], 16)
                        vpid = ident[4:8] if len(ident) >= 8 else ''
                        name = line.split(';', 1)[1] if ';' in line else ''
                        return sid, cw.upper(), vpid, name.replace('[AutoBiss]', '').strip()
                return None
            parts = line.split('=')
            if len(parts) >= 5:
                sid = int(parts[0], 16)
                cw = parts[4].strip().upper()
                if _is_cw(cw):
                    return sid, cw, '', (parts[5].strip() if len(parts) > 5 else '')
        except Exception:
            return None
        return None

    def get(self, sid):
        return self._cache.get(sid, None)

    def meta(self, sid):
        return self._meta.get(sid, ('', 'AutoBiss'))

    def set(self, sid, cw_hex, vpid='', name='AutoBiss'):
        cw_hex = (cw_hex or '').strip().upper()
        if not _is_cw(cw_hex):
            return False
        self._cache[sid] = cw_hex
        self._meta[sid] = (vpid or '', name or 'AutoBiss')
        return self._flush()

    def remove(self, sid):
        if sid in self._cache:
            del self._cache[sid]
            self._meta.pop(sid, None)
            return self._flush()
        return False

    def all(self):
        return [(sid, self._cache[sid], self._meta.get(sid, ('', ''))[0],
                 self._meta.get(sid, ('', ''))[1])
                for sid in sorted(self._cache)]

    def count(self):
        return len(self._cache)

    def reload(self):
        """Re-read the keys file (used by the 24h feed scanner)."""
        self._cache = {}
        self._meta = {}
        self._path = self._default_path()
        self._load()
        return len(self._cache)

    def _flush(self):
        try:
            directory = os.path.dirname(self._path)
            if directory and not os.path.isdir(directory):
                os.makedirs(directory)
            lines = []
            for sid, cw, vpid, name in self.all():
                ident = '{:04X}{}'.format(sid & 0xFFFF, (vpid or '0000').upper())
                if not name:
                    name = 'AutoBiss'
                lines.append("F {} 00 {} ;{} [AutoBiss]\n".format(ident, cw, name))
            with open(self._path, 'w') as f:
                f.writelines(lines)
            try:
                os.chmod(self._path, 0o644)
            except Exception:
                pass
            return True
        except Exception as e:
            log_debug("Failed to write keys file: {}".format(e))
            return False


def _is_cw(cw):
    return bool(cw) and len(cw) == 16 and all(c in '0123456789ABCDEFabcdef' for c in cw)

# ------------------------------------------------------------------------------
# ecm.info Parser (kept for compatibility, but not primary method)
# ------------------------------------------------------------------------------
def _parse_ecm_content(content):
    """Try to extract 16-char hex CW from ecm file content."""
    cw = None
    content_str = content.decode('utf-8', 'replace') if isinstance(content, bytes) else content

    # Pattern 1: cw=1122334455667788
    m = re.search(r'(?:cw|CW)\s*[:=]\s*([0-9A-Fa-f]{16})', content_str, re.IGNORECASE)
    if m:
        cw = m.group(1).upper()
    else:
        # Pattern 2: Two-part CW: cw0=11223344 cw1=55667788
        m0 = re.search(r'(?:cw0|CW0)\s*[:=]\s*([0-9A-Fa-f]{8})', content_str, re.IGNORECASE)
        m1 = re.search(r'(?:cw1|CW1)\s*[:=]\s*([0-9A-Fa-f]{8})', content_str, re.IGNORECASE)
        if m0 and m1:
            cw = (m0.group(1) + m1.group(1)).upper()
        else:
            # Pattern 3: Space-separated bytes
            m = re.search(r'(?<![0-9A-Fa-f])([0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2})', content_str)
            if m:
                raw = m.group(1).replace(' ', '').upper()
                if len(raw) == 16:
                    cw = raw
    return cw

def parse_ecm_info(sid=None):
    """
    Parse softcam CW files to extract the current BISS key.
    Tries multiple file paths and formats.
    Returns the 16-char hex CW string or None.
    Pass sid to reject keys belonging to a different channel.
    """
    candidates = [
        "/tmp/ecm.info",
        "/tmp/ecm0.info",
        "/tmp/.ecm",
        "/tmp/ecm.info.txt",
        "/tmp/ncam.ecm",
        "/tmp/oscam.ecm",
    ]
    for path in candidates:
        if not os.path.isfile(path):
            continue
        try:
            with open(path, 'rb') as f:
                content = f.read()
            # Match SID when the file exposes it, so a stale ecm.info from a
            # previous channel is never assigned to the current one.
            expected = None
            if isinstance(sid, int):
                expected = '{:04X}'.format(sid)
            found_sid = None
            m = re.search(rb'(?:sid|SID)\s*[:=]?\s*0*([0-9A-Fa-f]{1,4})', content)
            if m:
                found_sid = m.group(1).decode('ascii', 'replace').upper()
            if expected and found_sid and found_sid != expected:
                log_debug("Skipping {}: SID {} != current {}".format(path, found_sid, expected))
                continue
            cw = _parse_ecm_content(content)
            if cw:
                log_debug("Parsed CW from {}: {}".format(path, _mask_cw(cw)))
                return cw
        except Exception as e:
            log_debug("Failed to read {}: {}".format(path, e))
    log_debug("No CW found in any softcam ECM file")
    return None

# ------------------------------------------------------------------------------
# Global CWL Helper
# ------------------------------------------------------------------------------
GLOBAL_CWL_PATHS = [
    "/media/hdd/movie/CW_list.cwl",
    "/media/hdd/CW_list.cwl",
    "/media/usb/movie/CW_list.cwl",
    "/tmp/CW_list.cwl",
]

def get_global_cwl():
    """
    Return the path to the first existing global CWL file, or None.
    These files can be very large (GBs) and are never parsed by the plugin.
    """
    for path in GLOBAL_CWL_PATHS:
        if os.path.isfile(path):
            log_debug("Global CWL found: {}".format(path))
            return path
    log_debug("No global CWL file found in standard locations")
    return None

# ------------------------------------------------------------------------------
# tsdec Real-Time CW Extractor
# ------------------------------------------------------------------------------
def parse_tsdec_stderr(stderr_lines):
    """
    Parse tsdec stderr output to find the CW that achieved sync.
    Looks for lines like:
      sync at packet 15. using CW #42 "0 1A 2B 3C 81 4D 5E 6F 1A"
    Returns the 16-char hex CW string or None.
    """
    cw = None
    for line in stderr_lines:
        # Look for sync line with CW pattern
        m = re.search(r'sync at packet\s+\d+\.\s+using CW\s+#\d+\s+"\d\s+([0-9A-Fa-f\s]+)"', line)
        if m:
            raw = m.group(1).replace(' ', '').upper()
            if len(raw) == 16:
                cw = raw
                log_debug("tsdec sync CW found: {}".format(_mask_cw(cw)))
                break
    return cw

def run_tsdec_extract_cw(ts_path, cwl_path, timeout=60, binary_path=None):
    """
    Run tsdec on a .ts file with a .cwl file and extract the CW that achieves sync.
    Returns (cw_hex, tsdec_rc) where cw_hex may be None if sync not found.
    Kills tsdec early once sync is found to save CPU.
    If binary_path is provided, uses that tsdec binary instead of TSDEC_CMD.
    """
    out_path = ts_path.replace(".ts", "_tmp_dec.ts")
    tsdec_bin = binary_path if binary_path else TSDEC_CMD
    # Use list form (shell=False) to prevent shell injection via path metacharacters
    cmd = [tsdec_bin, '-f', cwl_path, '-i', ts_path, '-o', out_path]
    log_debug("tsdec extract CW: {} (binary={})".format(len(cmd) - 1, tsdec_bin))

    cw = None
    rc = -1
    try:
        proc = subprocess.Popen(
            cmd,
            shell=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        stderr_lines = []
        # Read stderr line by line, but enforce a wall-clock deadline so a
        # silent/hung tsdec cannot block the caller indefinitely.
        deadline = time.time() + timeout
        if hasattr(proc.stderr, 'readline'):
            for line in iter(proc.stderr.readline, b''):
                if not line:
                    break
                line_str = line.decode('utf-8', 'replace') if isinstance(line, bytes) else line
                line_str = line_str.strip()
                stderr_lines.append(line_str)
                log_debug("tsdec stderr: {}".format(line_str))

                # Check for sync
                cw = parse_tsdec_stderr([line_str])
                if cw:
                    log_debug("CW found early, killing tsdec")
                    proc.terminate()
                    try:
                        proc.wait(timeout=2)
                    except Exception:
                        proc.kill()
                    break

                if time.time() > deadline:
                    log_debug("tsdec exceeded {}s, killing".format(timeout))
                    proc.kill()
                    try:
                        proc.wait(timeout=2)
                    except Exception:
                        pass
                    rc = -1
                    break
            else:
                # If we didn't break out of the loop, wait for process
                try:
                    rc = proc.wait(timeout=max(1, int(deadline - time.time())))
                except Exception:
                    proc.kill()
                    rc = -1
        else:
            # Fallback: just wait and read all stderr at end
            stdout, stderr = proc.communicate(timeout=timeout)
            rc = proc.returncode
            stderr_str = stderr.decode('utf-8', 'replace') if isinstance(stderr, bytes) else stderr
            stderr_lines = stderr_str.splitlines()
            cw = parse_tsdec_stderr(stderr_lines)

    except Exception as e:
        log_debug("tsdec extract exception: {}".format(e))

    # Clean up temp decrypted file (we don't need it, we only needed the CW)
    try:
        if os.path.exists(out_path):
            os.remove(out_path)
    except Exception:
        pass

    log_debug("tsdec extract result: cw={}, rc={}".format(_mask_cw(cw), rc))
    return cw, rc

# ------------------------------------------------------------------------------
# ECM PID Extractor
# ------------------------------------------------------------------------------
def get_ecm_pid(session):
    """
    Try to get the ECM PID for the current service.
    First tries /tmp/ecm.info, then falls back to common BISS default 0x1FFF.
    Returns hex string (e.g., '1FFF') or '1FFF' as default.
    """
    # Try ecm.info first
    candidates = [
        "/tmp/ecm.info",
        "/tmp/ecm0.info",
        "/tmp/.ecm",
        "/tmp/ncam.ecm",
        "/tmp/oscam.ecm",
    ]
    for path in candidates:
        if not os.path.isfile(path):
            continue
        try:
            with open(path, 'rb') as f:
                content = f.read()
            content_str = content.decode('utf-8', 'replace') if isinstance(content, bytes) else content
            # Look for pid or ECMPID patterns
            m = re.search(r'(?:ecm\s*pid|ECMPID|pid)\s*[:=]?\s*(?:0x)?([0-9A-Fa-f]{1,4})', content_str, re.IGNORECASE)
            if m:
                ecm = m.group(1).upper()
                log_debug("ECM PID from {}: 0x{}".format(path, ecm))
                return ecm
        except Exception as e:
            log_debug("Failed to read {} for ECM PID: {}".format(path, e))
    log_debug("ECM PID not found, defaulting to 1FFF")
    return "1FFF"

# ------------------------------------------------------------------------------
# VPS Decryptor
# ------------------------------------------------------------------------------
def decrypt_via_vps(ts_path, cwl_path, sid_hex, ecm_pid_hex,
                    vps_url="https://tsdec.kingcs.xyz/decrypt",
                    timeout=30,
                    service_ref="", video_pid="", audio_pid="", pcr_pid="",
                    pmt_pid="", txt_pid="", tsid="", onid="", caid=""):
    """
    Upload a TS sample and optional CWL to the remote VPS for decryption.
    Uses the per-device token stored in /etc/autobiss/token (no shared key).
    Service info (SID, PIDs, service_ref, etc.) is sent to enable VPS-side caching.
    Returns (cw_hex, reachable) where reachable is False on network failure.
    """
    # Load per-device token; fall back to legacy shared key while not yet registered
    _LEGACY_KEY = "a1b2c3d4e5f678901234567890abcdef1234567890abcdef"
    token       = None
    use_legacy  = False
    try:
        from Plugins.Extensions.AutoBiss.device import get_token
        token = get_token()
    except Exception:
        pass
    if not token:
        use_legacy = True
        log_debug("decrypt_via_vps: no device token yet — using legacy API key")

    try:
        import urllib2
    except ImportError:
        import urllib.request as urllib2

    try:
        with open(ts_path, "rb") as f:
            ts_data = f.read()
    except Exception as e:
        log_debug("decrypt_via_vps: cannot read ts: {}".format(e))
        return None, False

    ts_b64 = base64.b64encode(ts_data)
    if isinstance(ts_b64, bytes):
        ts_b64 = ts_b64.decode("ascii")

    cwl_b64 = ""
    if cwl_path and os.path.exists(cwl_path):
        try:
            with open(cwl_path, "rb") as f:
                cwl_data = f.read()
            cwl_b64 = base64.b64encode(cwl_data)
            if isinstance(cwl_b64, bytes):
                cwl_b64 = cwl_b64.decode("ascii")
        except Exception as e:
            log_debug("decrypt_via_vps: cannot read cwl: {}".format(e))

    payload = json.dumps({
        "ts_base64": ts_b64,
        "cwl_base64": cwl_b64,
        "sid": sid_hex,
        "ecm_pid": ecm_pid_hex,
        "service_ref": service_ref,
        "video_pid": video_pid,
        "audio_pid": audio_pid,
        "pcr_pid": pcr_pid,
        "pmt_pid": pmt_pid,
        "txt_pid": txt_pid,
        "tsid": tsid,
        "onid": onid,
        "caid": caid
    })

    data = payload.encode("utf-8") if isinstance(payload, str) else payload
    req = urllib2.Request(vps_url, data=data)
    req.add_header("Content-Type", "application/json")
    if use_legacy:
        req.add_header("X-API-Key", _LEGACY_KEY)
    else:
        req.add_header("X-Device-Token", token)

    ssl_ctx = None
    try:
        import ssl
        try:
            ssl_ctx = ssl.create_default_context()   # verify cert chain
        except Exception:
            ssl_ctx = ssl._create_unverified_context()  # old CA store fallback
    except Exception:
        pass

    try:
        if ssl_ctx is not None:
            try:
                response = urllib2.urlopen(req, context=ssl_ctx, timeout=timeout)
            except TypeError:
                response = urllib2.urlopen(req, timeout=timeout)
        else:
            response = urllib2.urlopen(req, timeout=timeout)
        resp_data = response.read()
        if isinstance(resp_data, bytes):
            resp_data = resp_data.decode("utf-8")
        result = json.loads(resp_data)
        if result.get("success") and result.get("cw_hex"):
            log_debug("decrypt_via_vps: CW found: {}".format(_mask_cw(result["cw_hex"])))
            return result["cw_hex"].upper(), True
        log_debug("decrypt_via_vps: no CW in response: {}".format(result.get("message")))
        return None, True
    except Exception as e:
        log_debug("decrypt_via_vps: unreachable: {}".format(e))
        return None, False

# ------------------------------------------------------------------------------
# SoftCam.Key Writer
# ------------------------------------------------------------------------------
def write_softcam_key(sid, vpid, cw_hex, channel_name="AutoBiss", ecm_pid=None):
    """
    Write/update BISS key in SoftCam.Key, FuryBiss-compatible format:
        F <SID><VPID> 00 <CW> ;<Channel> [AutoBiss]
        F <SID><VPID> 01 <CW> ;<Channel> [AutoBiss]
    Both 00 and 01 lines are required — emulators ignore single-line
    entries (the LiveFeed bug). Ident is SID+VPID, NOT SID+ECM_PID.
    Old single-line entries for this SID are removed.
    """
    if not cw_hex or len(cw_hex) != 16:
        log_debug("write_softcam_key: invalid CW")
        return False

    try:
        sid_int = int(sid)
    except Exception:
        log_debug("write_softcam_key: invalid SID")
        return False
    try:
        vpid_int = int(vpid)
    except Exception:
        vpid_int = 0
    sid_str = "{:04X}".format(sid_int & 0xFFFF).upper()
    vpid_str = "{:04X}".format(vpid_int & 0xFFFF).upper()
    key_id = sid_str + vpid_str
    cw_str = cw_hex.upper()
    comment = "{} [AutoBiss]".format(channel_name)
    entry00 = "F {} 00 {} ;{}\n".format(key_id, cw_str, comment)
    entry01 = "F {} 01 {} ;{}\n".format(key_id, cw_str, comment)

    # Legacy ident (SID+ECM_PID single 00 line) — removed on rewrite
    legacy_id = None
    try:
        if ecm_pid:
            ecm_str = str(ecm_pid).upper().replace("0X", "")
            legacy_id = sid_str + ecm_str
    except Exception:
        pass

    softcam_path = get_softcam_path()

    lines = []
    if os.path.isfile(softcam_path):
        try:
            with open(softcam_path, 'r') as f:
                lines = f.readlines()
        except Exception as e:
            log_debug("Failed to read SoftCam.Key: {}".format(e))

    key_pattern = re.compile(r'^F\s+' + re.escape(key_id) + r'\s+', re.IGNORECASE)
    legacy_pattern = None
    if legacy_id and legacy_id != key_id:
        legacy_pattern = re.compile(r'^F\s+' + re.escape(legacy_id) + r'\s+', re.IGNORECASE)

    new_lines = []
    skipped_first = False
    for line in lines:
        if key_pattern.match(line):
            if not skipped_first:
                new_lines.append(entry00)
                new_lines.append(entry01)
                skipped_first = True
            continue
        if legacy_pattern is not None and legacy_pattern.match(line):
            continue
        new_lines.append(line)

    if not skipped_first:
        new_lines.append(entry00)
        new_lines.append(entry01)

    try:
        with open(softcam_path, 'w') as f:
            f.writelines(new_lines)
        log_debug("SoftCam.Key {} updated: {} -> {}".format(softcam_path, key_id, _mask_cw(cw_str)))
        return True
    except Exception as e:
        log_debug("Failed to write SoftCam.Key: {}".format(e))
        return False

# ------------------------------------------------------------------------------
# ECM Info Writer  (/tmp/ecm.info — read by some softcam-aware apps)
# ------------------------------------------------------------------------------
def write_ecm_info(sid, ecm_pid, cw_hex, channel_name="AutoBiss"):
    """
    Write /tmp/ecm.info in the format expected by softcam monitors.
    cw_hex must be 16 hex chars (8 bytes). Both cw0 and cw1 are set
    to the same value (BISS uses a single symmetric CW).
    """
    if not cw_hex or len(cw_hex) != 16:
        log_debug("write_ecm_info: invalid CW length")
        return False
    try:
        # Format CW as space-separated byte pairs: "1A 2B 3C 81 4D 5E 6F 1A "
        cw = cw_hex.upper()
        cw_fmt = ' '.join(cw[i:i+2] for i in range(0, 16, 2)) + ' '

        # Normalise ECM PID to hex int then format
        try:
            pid_int = int(str(ecm_pid).replace('0x','').replace('0X',''), 16)
        except Exception:
            pid_int = 0x1FFF
        pid_str = '0x{:04X}'.format(pid_int)

        content = (
            "system: Biss\n"
            "caid: 0x2600\n"
            "provider: {provider}\n"
            "provid: 0x000000\n"
            "pid: {pid}\n"
            "cw0: {cw}\n"
            "cw1: {cw}\n"
            "using: emu\n"
            "address: local:0\n"
            "hops: 0\n"
            "ecm time: 2\n"
        ).format(provider=channel_name, pid=pid_str, cw=cw_fmt)

        with open('/tmp/ecm.info', 'w') as f:
            f.write(content)
        log_debug("write_ecm_info: written for SID 0x{:04X}".format(sid))
        return True
    except Exception as e:
        log_debug("write_ecm_info error: {}".format(e))
        return False

# ------------------------------------------------------------------------------
# Recording Sidecar Cleanup
# ------------------------------------------------------------------------------
def cleanup_recording_sidecars(ts_path):
    """
    Remove all Enigma2 sidecar files left next to a TS recording:
    .eit, .ts.cuts, .ts.meta, .ts.sc, .ts.ap, and AutoBiss .txt logs.
    """
    if not ts_path:
        return
    movie_dir = os.path.dirname(ts_path)
    base = ts_path  # e.g. /media/hdd/movie/20260531 1325 - Chan - AutoBiss Chan.ts

    # Strip .ts suffix to get the stem
    stem = base[:-3] if base.endswith('.ts') else base

    # Sidecar extensions attached to the stem
    for ext in ('.eit', '.ts.cuts', '.ts.meta', '.ts.sc', '.ts.ap'):
        path = stem + ext if ext.startswith('.ts.') else stem + ext
        # For extensions like .ts.cuts, stem already has no .ts so we need:
        if ext.startswith('.ts.'):
            path = stem + ext          # stem + .ts.cuts → correct
        else:
            path = stem + ext          # stem + .eit
        try:
            if os.path.isfile(path):
                os.remove(path)
                log_debug("Removed sidecar: {}".format(path))
        except Exception as e:
            log_debug("Sidecar remove failed {}: {}".format(path, e))

    # AutoBiss .txt info files for THIS recording only (never touch others)
    try:
        wanted = set()
        for ext in ('.txt', '.log', '.info'):
            wanted.add(os.path.basename(stem) + ext)
        for fname in os.listdir(movie_dir):
            if fname in wanted:
                fpath = os.path.join(movie_dir, fname)
                try:
                    os.remove(fpath)
                    log_debug("Removed AutoBiss txt: {}".format(fpath))
                except Exception as e:
                    log_debug("AutoBiss txt remove failed {}: {}".format(fpath, e))
    except Exception as e:
        log_debug("Sidecar dir scan failed: {}".format(e))

# ------------------------------------------------------------------------------
# Softcam Reloader
# ------------------------------------------------------------------------------
def reload_softcam():
    """
    Reload OSCam/NCam to pick up the new SoftCam.Key.
    Order of preference:
      1. Web API (cleanest, no process disruption)
      2. Targeted pkill -HUP (only hits exact process name)
      3. killall -HUP (last resort, may affect all instances)
    """
    # Quick check: skip if no softcam process found (-f: matches
    # oscam-emu, oscam-master, ncam.*, ... which '-x' misses)
    softcam_found = False
    try:
        import subprocess
        for name in ('oscam', 'ncam'):
            try:
                proc = subprocess.Popen(['pgrep', '-f', name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                stdout, stderr = proc.communicate(timeout=2)
                if hasattr(stdout, 'decode'):
                    stdout = stdout.decode('utf-8', 'replace')
                pids = stdout.strip().split('\n') if stdout else []
                if any(p.strip() for p in pids):
                    softcam_found = True
                    break
            except Exception:
                pass
    except Exception:
        pass
    if not softcam_found:
        log_debug("No softcam to reload")
        return False

    # Method 1: Web API (cleanest)
    try:
        import urllib.request as urllib2  # Python 3
    except ImportError:
        import urllib2  # Python 2

    urls = [
        "http://127.0.0.1:{}/oscamapi.html?part=config&action=reload".format(OSCAM_WEB_PORT),
        "http://127.0.0.1:{}/ncamapi.html?part=config&action=reload".format(OSCAM_WEB_PORT),
        "http://127.0.0.1:{}/oscamapi.html?part=reader&action=reload".format(OSCAM_WEB_PORT),
        "http://127.0.0.1:{}/ncamapi.html?part=reader&action=reload".format(OSCAM_WEB_PORT),
    ]
    for url in urls:
        try:
            response = urllib2.urlopen(url, timeout=5)
            log_debug("Softcam reload via API: {} (status={})".format(url, response.getcode()))
            return True
        except Exception as e:
            log_debug("API reload failed for {}: {}".format(url, e))

    # Method 2: Targeted pkill (full-cmdline match for oscam-emu etc.)
    import subprocess
    for name in ('ncam', 'oscam'):
        try:
            # Check if process exists first
            proc = subprocess.Popen(['pgrep', '-f', name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = proc.communicate(timeout=3)
            pids = stdout.decode('utf-8', 'replace').strip().split('\n') if stdout else []
            pids = [p for p in pids if p.strip()]
            if pids:
                rc = os.system('pkill -HUP -f "{}" 2>/dev/null'.format(name))
                if rc == 0:
                    log_debug("Sent HUP to {} via pkill (rc=0)".format(name))
                    return True
                else:
                    log_debug("pkill {} returned rc={}".format(name, rc))
            else:
                log_debug("pkill: no process named {} found".format(name))
        except Exception as e:
            log_debug("pkill {} exception: {}".format(name, e))

    # Method 3: killall (last resort)
    for name in ('ncam', 'oscam'):
        try:
            rc = os.system('killall -HUP {} 2>/dev/null'.format(name))
            if rc == 0:
                log_debug("Sent HUP to {} via killall (rc=0)".format(name))
                return True
            else:
                log_debug("killall {} returned rc={}".format(name, rc))
        except Exception as e:
            log_debug("killall {} exception: {}".format(name, e))

    log_debug("All softcam reload methods failed")
    return False

# ------------------------------------------------------------------------------
# Key Formatter
# ------------------------------------------------------------------------------
def format_cw_for_display(cw_hex):
    if not cw_hex or len(cw_hex) != 16:
        return "Unknown"
    return "{} {}".format(cw_hex[:8], cw_hex[8:])
