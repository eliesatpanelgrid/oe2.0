# -*- coding: utf-8 -*-
"""
AutoBiss E2 - BISS Engine Module v3.0
Real-time CW extraction from tsdec stderr, SoftCam.Key writer, softcam reloader
Compatible with Python 2.7 and Python 3.x
"""
from __future__ import absolute_import, print_function, division

import os
import re
import json
import base64
import threading
import subprocess
from time import strftime

# ------------------------------------------------------------------------------
# Debug helper
# ------------------------------------------------------------------------------
_DEBUG_PATH = '/tmp/autobiss_debug.log'

def log_debug(msg):
    try:
        with open(_DEBUG_PATH, 'a') as f:
            f.write("[{}] [biss_engine] {}\n".format(strftime("%Y-%m-%d %H:%M:%S"), msg))
        try:
            os.chmod(_DEBUG_PATH, 0o600)
        except Exception:
            pass
    except Exception:
        pass

def _mask_cw(cw):
    """Return a partially masked CW for safe logging (first 4 hex chars visible)."""
    if not cw or len(cw) < 4:
        return "****"
    return "{}{}".format(cw[:4], "*" * (len(cw) - 4))

# ------------------------------------------------------------------------------
# Constants
# ------------------------------------------------------------------------------
BISS_CAID = 0x2600
KEYS_FILE = "/media/hdd/biss_keys.txt"
SOFTCAM_KEY = "/etc/tuxbox/config/SoftCam.Key"
OUTPUT_DIR = "/media/hdd/movie/"
TSDEC_CMD = "tsdec"
OSCAM_WEB_PORT = 8888

# ------------------------------------------------------------------------------
# CW Cache
# ------------------------------------------------------------------------------
class CWCache(object):
    """
    In-memory cache of SID -> CW mappings.
    Loads from /media/hdd/biss_keys.txt at startup.
    Format per line:
        SID=ONID=TSID=CAID=CW_HEX=CHANNEL_NAME
    """
    def __init__(self):
        self._cache = {}  # sid_int -> cw_hex_str
        self._load()

    def _load(self):
        if not os.path.isfile(KEYS_FILE):
            log_debug("Keys file not found: {}".format(KEYS_FILE))
            return
        try:
            with open(KEYS_FILE, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parts = line.split('=')
                    if len(parts) >= 5:
                        try:
                            sid = int(parts[0], 16)
                            cw = parts[4].strip().upper()
                            if len(cw) == 16 and all(c in '0123456789ABCDEF' for c in cw):
                                self._cache[sid] = cw
                                log_debug("Loaded CW for SID 0x{:04X}: {}".format(sid, _mask_cw(cw)))
                        except Exception as e:
                            log_debug("Parse error in keys file: {}".format(e))
        except Exception as e:
            log_debug("Failed to load keys file: {}".format(e))

    def get(self, sid):
        return self._cache.get(sid, None)

    def set(self, sid, cw_hex):
        self._cache[sid] = cw_hex.upper()
        self._append_to_file(sid, cw_hex)

    def _append_to_file(self, sid, cw_hex):
        try:
            with open(KEYS_FILE, 'a') as f:
                f.write("0x{:04X}=0x0000=0x0000=0x2600={}=AutoBiss\n".format(sid, cw_hex.upper()))
            log_debug("Appended CW for SID 0x{:04X} to keys file".format(sid))
        except Exception as e:
            log_debug("Failed to append to keys file: {}".format(e))

    def is_known(self, sid):
        return sid in self._cache

# ------------------------------------------------------------------------------
# ecm.info Parser (kept for compatibility, but not primary method)
# ------------------------------------------------------------------------------
def _parse_ecm_content(content):
    """Try to extract 16-char hex CW from ecm file content."""
    cw = None
    content_str = content.decode('utf-8', 'replace') if isinstance(content, bytes) else content

    # Pattern 1: cw=1122334455667788
    m = re.search(r'(?:cw|CW)\s*[:=]\s*([0-9A-Fa-f]{16})', content_str, re.IGNORECASE)
    if m:
        cw = m.group(1).upper()
    else:
        # Pattern 2: Two-part CW: cw0=11223344 cw1=55667788
        m0 = re.search(r'(?:cw0|CW0)\s*[:=]\s*([0-9A-Fa-f]{8})', content_str, re.IGNORECASE)
        m1 = re.search(r'(?:cw1|CW1)\s*[:=]\s*([0-9A-Fa-f]{8})', content_str, re.IGNORECASE)
        if m0 and m1:
            cw = (m0.group(1) + m1.group(1)).upper()
        else:
            # Pattern 3: Space-separated bytes
            m = re.search(r'(?<![0-9A-Fa-f])([0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2})', content_str)
            if m:
                raw = m.group(1).replace(' ', '').upper()
                if len(raw) == 16:
                    cw = raw
    return cw

def parse_ecm_info():
    """
    Parse softcam CW files to extract the current BISS key.
    Tries multiple file paths and formats.
    Returns the 16-char hex CW string or None.
    """
    candidates = [
        "/tmp/ecm.info",
        "/tmp/ecm0.info",
        "/tmp/.ecm",
        "/tmp/ecm.info.txt",
        "/tmp/ncam.ecm",
        "/tmp/oscam.ecm",
    ]
    for path in candidates:
        if not os.path.isfile(path):
            continue
        try:
            with open(path, 'rb') as f:
                content = f.read()
            cw = _parse_ecm_content(content)
            if cw:
                log_debug("Parsed CW from {}: {}".format(path, _mask_cw(cw)))
                return cw
        except Exception as e:
            log_debug("Failed to read {}: {}".format(path, e))
    log_debug("No CW found in any softcam ECM file")
    return None

# ------------------------------------------------------------------------------
# Global CWL Helper
# ------------------------------------------------------------------------------
GLOBAL_CWL_PATHS = [
    "/media/hdd/movie/CW_list.cwl",
    "/media/hdd/CW_list.cwl",
    "/media/usb/movie/CW_list.cwl",
    "/tmp/CW_list.cwl",
]

def get_global_cwl():
    """
    Return the path to the first existing global CWL file, or None.
    These files can be very large (GBs) and are never parsed by the plugin.
    """
    for path in GLOBAL_CWL_PATHS:
        if os.path.isfile(path):
            log_debug("Global CWL found: {}".format(path))
            return path
    log_debug("No global CWL file found in standard locations")
    return None

# ------------------------------------------------------------------------------
# tsdec Real-Time CW Extractor
# ------------------------------------------------------------------------------
def parse_tsdec_stderr(stderr_lines):
    """
    Parse tsdec stderr output to find the CW that achieved sync.
    Looks for lines like:
      sync at packet 15. using CW #42 "0 1A 2B 3C 81 4D 5E 6F 1A"
    Returns the 16-char hex CW string or None.
    """
    cw = None
    for line in stderr_lines:
        # Look for sync line with CW pattern
        m = re.search(r'sync at packet\s+\d+\.\s+using CW\s+#\d+\s+"\d\s+([0-9A-Fa-f\s]+)"', line)
        if m:
            raw = m.group(1).replace(' ', '').upper()
            if len(raw) == 16:
                cw = raw
                log_debug("tsdec sync CW found: {}".format(_mask_cw(cw)))
                break
    return cw

def run_tsdec_extract_cw(ts_path, cwl_path, timeout=60):
    """
    Run tsdec on a .ts file with a .cwl file and extract the CW that achieves sync.
    Returns (cw_hex, tsdec_rc) where cw_hex may be None if sync not found.
    Kills tsdec early once sync is found to save CPU.
    """
    out_path = ts_path.replace(".ts", "_tmp_dec.ts")
    # Use list form (shell=False) to prevent shell injection via path metacharacters
    cmd = [TSDEC_CMD, '-f', cwl_path, '-i', ts_path, '-o', out_path]
    log_debug("tsdec extract CW: {} files".format(len(cmd) - 1))

    cw = None
    rc = -1
    try:
        proc = subprocess.Popen(
            cmd,
            shell=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        stderr_lines = []
        # Read stderr line by line
        if hasattr(proc.stderr, 'readline'):
            # Python 2/3 compatible line reading
            for line in iter(proc.stderr.readline, b''):
                if not line:
                    break
                line_str = line.decode('utf-8', 'replace') if isinstance(line, bytes) else line
                line_str = line_str.strip()
                stderr_lines.append(line_str)
                log_debug("tsdec stderr: {}".format(line_str))

                # Check for sync
                cw = parse_tsdec_stderr([line_str])
                if cw:
                    log_debug("CW found early, killing tsdec")
                    proc.terminate()
                    try:
                        proc.wait(timeout=2)
                    except Exception:
                        proc.kill()
                    break
            else:
                # If we didn't break out of the loop, wait for process
                try:
                    rc = proc.wait(timeout=timeout)
                except Exception:
                    proc.kill()
                    rc = -1
        else:
            # Fallback: just wait and read all stderr at end
            stdout, stderr = proc.communicate(timeout=timeout)
            rc = proc.returncode
            stderr_str = stderr.decode('utf-8', 'replace') if isinstance(stderr, bytes) else stderr
            stderr_lines = stderr_str.splitlines()
            cw = parse_tsdec_stderr(stderr_lines)

    except Exception as e:
        log_debug("tsdec extract exception: {}".format(e))

    # Clean up temp decrypted file (we don't need it, we only needed the CW)
    try:
        if os.path.exists(out_path):
            os.remove(out_path)
    except Exception:
        pass

    log_debug("tsdec extract result: cw={}, rc={}".format(_mask_cw(cw), rc))
    return cw, rc

# ------------------------------------------------------------------------------
# ECM PID Extractor
# ------------------------------------------------------------------------------
def get_ecm_pid(session):
    """
    Try to get the ECM PID for the current service.
    First tries /tmp/ecm.info, then falls back to common BISS default 0x1FFF.
    Returns hex string (e.g., '1FFF') or '1FFF' as default.
    """
    # Try ecm.info first
    candidates = [
        "/tmp/ecm.info",
        "/tmp/ecm0.info",
        "/tmp/.ecm",
        "/tmp/ncam.ecm",
        "/tmp/oscam.ecm",
    ]
    for path in candidates:
        if not os.path.isfile(path):
            continue
        try:
            with open(path, 'rb') as f:
                content = f.read()
            content_str = content.decode('utf-8', 'replace') if isinstance(content, bytes) else content
            # Look for pid or ECMPID patterns
            m = re.search(r'(?:ecm\s*pid|ECMPID|pid)\s*[:=]?\s*(?:0x)?([0-9A-Fa-f]{1,4})', content_str, re.IGNORECASE)
            if m:
                ecm = m.group(1).upper()
                log_debug("ECM PID from {}: 0x{}".format(path, ecm))
                return ecm
        except Exception as e:
            log_debug("Failed to read {} for ECM PID: {}".format(path, e))
    log_debug("ECM PID not found, defaulting to 1FFF")
    return "1FFF"

# ------------------------------------------------------------------------------
# VPS Decryptor
# ------------------------------------------------------------------------------
def decrypt_via_vps(ts_path, cwl_path, sid_hex, ecm_pid_hex,
                    vps_url="https://tsdec.kingcs.xyz/decrypt",
                    timeout=30,
                    service_ref="", video_pid="", audio_pid="", pcr_pid="",
                    pmt_pid="", txt_pid="", tsid="", onid="", caid=""):
    """
    Upload a TS sample and optional CWL to the remote VPS for decryption.
    Uses the per-device token stored in /etc/autobiss/token (no shared key).
    Service info (SID, PIDs, service_ref, etc.) is sent to enable VPS-side caching.
    Returns (cw_hex, reachable) where reachable is False on network failure.
    """
    # Load per-device token; fall back to legacy shared key while not yet registered
    _LEGACY_KEY = "a1b2c3d4e5f678901234567890abcdef1234567890abcdef"
    token       = None
    use_legacy  = False
    try:
        from Plugins.Extensions.AutoBiss.device import get_token
        token = get_token()
    except Exception:
        pass
    if not token:
        use_legacy = True
        log_debug("decrypt_via_vps: no device token yet — using legacy API key")

    try:
        import urllib2
    except ImportError:
        import urllib.request as urllib2

    try:
        with open(ts_path, "rb") as f:
            ts_data = f.read()
    except Exception as e:
        log_debug("decrypt_via_vps: cannot read ts: {}".format(e))
        return None, False

    ts_b64 = base64.b64encode(ts_data)
    if isinstance(ts_b64, bytes):
        ts_b64 = ts_b64.decode("ascii")

    cwl_b64 = ""
    if cwl_path and os.path.exists(cwl_path):
        try:
            with open(cwl_path, "rb") as f:
                cwl_data = f.read()
            cwl_b64 = base64.b64encode(cwl_data)
            if isinstance(cwl_b64, bytes):
                cwl_b64 = cwl_b64.decode("ascii")
        except Exception as e:
            log_debug("decrypt_via_vps: cannot read cwl: {}".format(e))

    payload = json.dumps({
        "ts_base64": ts_b64,
        "cwl_base64": cwl_b64,
        "sid": sid_hex,
        "ecm_pid": ecm_pid_hex,
        "service_ref": service_ref,
        "video_pid": video_pid,
        "audio_pid": audio_pid,
        "pcr_pid": pcr_pid,
        "pmt_pid": pmt_pid,
        "txt_pid": txt_pid,
        "tsid": tsid,
        "onid": onid,
        "caid": caid
    })

    data = payload.encode("utf-8") if isinstance(payload, str) else payload
    req = urllib2.Request(vps_url, data=data)
    req.add_header("Content-Type", "application/json")
    if use_legacy:
        req.add_header("X-API-Key", _LEGACY_KEY)
    else:
        req.add_header("X-Device-Token", token)

    ssl_ctx = None
    try:
        import ssl
        try:
            ssl_ctx = ssl.create_default_context()   # verify cert chain
        except Exception:
            ssl_ctx = ssl._create_unverified_context()  # old CA store fallback
    except Exception:
        pass

    try:
        if ssl_ctx is not None:
            try:
                response = urllib2.urlopen(req, context=ssl_ctx, timeout=timeout)
            except TypeError:
                response = urllib2.urlopen(req, timeout=timeout)
        else:
            response = urllib2.urlopen(req, timeout=timeout)
        resp_data = response.read()
        if isinstance(resp_data, bytes):
            resp_data = resp_data.decode("utf-8")
        result = json.loads(resp_data)
        if result.get("success") and result.get("cw_hex"):
            log_debug("decrypt_via_vps: CW found: {}".format(_mask_cw(result["cw_hex"])))
            return result["cw_hex"].upper(), True
        log_debug("decrypt_via_vps: no CW in response: {}".format(result.get("message")))
        return None, True
    except Exception as e:
        log_debug("decrypt_via_vps: unreachable: {}".format(e))
        return None, False

# ------------------------------------------------------------------------------
# SoftCam.Key Writer
# ------------------------------------------------------------------------------
def write_softcam_key(sid, ecm_pid, cw_hex, channel_name="AutoBiss"):
    """
    Write or update a BISS key entry in /etc/tuxbox/config/SoftCam.Key.
    Format: F <SID><ECM_PID> <key_number> <CW> ;<ChannelName>
    Example: F 17ED1FFF 00 1A2B3C814D5E6F1A ;1+1 International
    """
    if not cw_hex or len(cw_hex) != 16:
        log_debug("write_softcam_key: invalid CW")
        return False

    sid_str = "{:04X}".format(sid).upper()
    ecm_str = ecm_pid.upper().replace("0X", "").replace("0x", "")
    key_id = sid_str + ecm_str
    cw_str = cw_hex.upper()
    entry = "F {} 00 {} ;{}\n".format(key_id, cw_str, channel_name)

    # Read existing file
    lines = []
    if os.path.isfile(SOFTCAM_KEY):
        try:
            with open(SOFTCAM_KEY, 'r') as f:
                lines = f.readlines()
        except Exception as e:
            log_debug("Failed to read SoftCam.Key: {}".format(e))

    # Remove existing entry for this key_id
    new_lines = []
    found = False
    key_pattern = re.compile(r'^F\s+' + re.escape(key_id) + r'\s+', re.IGNORECASE)
    for line in lines:
        if key_pattern.match(line):
            new_lines.append(entry)
            found = True
        else:
            new_lines.append(line)

    if not found:
        new_lines.append(entry)

    try:
        with open(SOFTCAM_KEY, 'w') as f:
            f.writelines(new_lines)
        log_debug("SoftCam.Key updated with key_id {} -> {}".format(key_id, cw_str))
        return True
    except Exception as e:
        log_debug("Failed to write SoftCam.Key: {}".format(e))
        return False

# ------------------------------------------------------------------------------
# ECM Info Writer  (/tmp/ecm.info — read by some softcam-aware apps)
# ------------------------------------------------------------------------------
def write_ecm_info(sid, ecm_pid, cw_hex, channel_name="AutoBiss"):
    """
    Write /tmp/ecm.info in the format expected by softcam monitors.
    cw_hex must be 16 hex chars (8 bytes). Both cw0 and cw1 are set
    to the same value (BISS uses a single symmetric CW).
    """
    if not cw_hex or len(cw_hex) != 16:
        log_debug("write_ecm_info: invalid CW length")
        return False
    try:
        # Format CW as space-separated byte pairs: "1A 2B 3C 81 4D 5E 6F 1A "
        cw = cw_hex.upper()
        cw_fmt = ' '.join(cw[i:i+2] for i in range(0, 16, 2)) + ' '

        # Normalise ECM PID to hex int then format
        try:
            pid_int = int(str(ecm_pid).replace('0x','').replace('0X',''), 16)
        except Exception:
            pid_int = 0x1FFF
        pid_str = '0x{:04X}'.format(pid_int)

        content = (
            "system: Biss\n"
            "caid: 0x2600\n"
            "provider: {provider}\n"
            "provid: 0x000000\n"
            "pid: {pid}\n"
            "cw0: {cw}\n"
            "cw1: {cw}\n"
            "using: emu\n"
            "address: local:0\n"
            "hops: 0\n"
            "ecm time: 2\n"
        ).format(provider=channel_name, pid=pid_str, cw=cw_fmt)

        with open('/tmp/ecm.info', 'w') as f:
            f.write(content)
        log_debug("write_ecm_info: written for SID 0x{:04X}".format(sid))
        return True
    except Exception as e:
        log_debug("write_ecm_info error: {}".format(e))
        return False

# ------------------------------------------------------------------------------
# Recording Sidecar Cleanup
# ------------------------------------------------------------------------------
def cleanup_recording_sidecars(ts_path):
    """
    Remove all Enigma2 sidecar files left next to a TS recording:
    .eit, .ts.cuts, .ts.meta, .ts.sc, .ts.ap, and AutoBiss .txt logs.
    """
    if not ts_path:
        return
    movie_dir = os.path.dirname(ts_path)
    base = ts_path  # e.g. /media/hdd/movie/20260531 1325 - Chan - AutoBiss Chan.ts

    # Strip .ts suffix to get the stem
    stem = base[:-3] if base.endswith('.ts') else base

    # Sidecar extensions attached to the stem
    for ext in ('.eit', '.ts.cuts', '.ts.meta', '.ts.sc', '.ts.ap'):
        path = stem + ext if ext.startswith('.ts.') else stem + ext
        # For extensions like .ts.cuts, stem already has no .ts so we need:
        if ext.startswith('.ts.'):
            path = stem + ext          # stem + .ts.cuts → correct
        else:
            path = stem + ext          # stem + .eit
        try:
            if os.path.isfile(path):
                os.remove(path)
                log_debug("Removed sidecar: {}".format(path))
        except Exception as e:
            log_debug("Sidecar remove failed {}: {}".format(path, e))

    # AutoBiss .txt info files in the same directory
    try:
        for fname in os.listdir(movie_dir):
            if fname.startswith('AutoBiss') and fname.endswith('.txt'):
                fpath = os.path.join(movie_dir, fname)
                try:
                    os.remove(fpath)
                    log_debug("Removed AutoBiss txt: {}".format(fpath))
                except Exception as e:
                    log_debug("AutoBiss txt remove failed {}: {}".format(fpath, e))
    except Exception as e:
        log_debug("Sidecar dir scan failed: {}".format(e))

# ------------------------------------------------------------------------------
# Softcam Reloader
# ------------------------------------------------------------------------------
def reload_softcam():
    """
    Reload OSCam/NCam to pick up the new SoftCam.Key.
    Order of preference:
      1. Web API (cleanest, no process disruption)
      2. Targeted pkill -HUP (only hits exact process name)
      3. killall -HUP (last resort, may affect all instances)
    """
    # Method 1: Web API (cleanest)
    try:
        import urllib.request as urllib2  # Python 3
    except ImportError:
        import urllib2  # Python 2

    urls = [
        "http://127.0.0.1:{}/oscamapi.html?part=config&action=reload".format(OSCAM_WEB_PORT),
        "http://127.0.0.1:{}/ncamapi.html?part=config&action=reload".format(OSCAM_WEB_PORT),
        "http://127.0.0.1:{}/oscamapi.html?part=reader&action=reload".format(OSCAM_WEB_PORT),
        "http://127.0.0.1:{}/ncamapi.html?part=reader&action=reload".format(OSCAM_WEB_PORT),
    ]
    for url in urls:
        try:
            response = urllib2.urlopen(url, timeout=5)
            log_debug("Softcam reload via API: {} (status={})".format(url, response.getcode()))
            return True
        except Exception as e:
            log_debug("API reload failed for {}: {}".format(url, e))

    # Method 2: Targeted pkill (only exact process name)
    import subprocess
    for name in ('ncam', 'oscam'):
        try:
            # Check if process exists first
            proc = subprocess.Popen(['pgrep', '-x', name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = proc.communicate(timeout=3)
            pids = stdout.decode('utf-8', 'replace').strip().split('\n') if stdout else []
            pids = [p for p in pids if p.strip()]
            if pids:
                rc = os.system('pkill -HUP -x "{}" 2>/dev/null'.format(name))
                if rc == 0:
                    log_debug("Sent HUP to {} via pkill (rc=0)".format(name))
                    return True
                else:
                    log_debug("pkill {} returned rc={}".format(name, rc))
            else:
                log_debug("pkill: no process named {} found".format(name))
        except Exception as e:
            log_debug("pkill {} exception: {}".format(name, e))

    # Method 3: killall (last resort)
    for name in ('ncam', 'oscam'):
        try:
            rc = os.system('killall -HUP {} 2>/dev/null'.format(name))
            if rc == 0:
                log_debug("Sent HUP to {} via killall (rc=0)".format(name))
                return True
            else:
                log_debug("killall {} returned rc={}".format(name, rc))
        except Exception as e:
            log_debug("killall {} exception: {}".format(name, e))

    log_debug("All softcam reload methods failed")
    return False

# ------------------------------------------------------------------------------
# Key Formatter
# ------------------------------------------------------------------------------
def format_cw_for_display(cw_hex):
    if not cw_hex or len(cw_hex) != 16:
        return "Unknown"
    return "{} {}".format(cw_hex[:8], cw_hex[8:])
