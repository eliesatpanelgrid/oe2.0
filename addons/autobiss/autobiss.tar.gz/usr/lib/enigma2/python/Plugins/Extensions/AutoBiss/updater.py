# -*- coding: utf-8 -*-
"""
AutoBiss E2 - Auto-Updater Module
Checks the VPS for a newer version, downloads all plugin files,
verifies each file's SHA-256 hash and the manifest HMAC signature,
backs up the current installation, then atomically replaces the files.
Compatible with Python 2.7 and Python 3.x
"""
from __future__ import absolute_import, print_function, division

import hashlib
import hmac
import json
import os
import shutil
import threading
from time import strftime

# ── Version — single source of truth ─────────────────────────────────────────
VERSION = "3.0"

# ── Configuration ─────────────────────────────────────────────────────────────
INSTALL_DIR  = "/usr/lib/enigma2/python/Plugins/Extensions/AutoBiss"
UPDATE_BASE  = "https://tsdec.kingcs.xyz/autobiss"
BACKUP_DIR   = "/tmp/autobiss_backup"
PLUGIN_FILES = ["__init__.py", "plugin.py", "biss_engine.py", "device.py", "key_analyzer.py", "updater.py"]
_DEBUG_PATH  = "/tmp/autobiss_debug.log"

# HMAC-SHA256 secret shared between the server and this client.
# The server signs manifest.json with this key; the client rejects any
# manifest whose signature does not match — blocking MITM/tampered updates.
# Change this value before deploying and keep it out of public repositories.
_HMAC_SECRET = b"autobiss_27e6b198ec352ab5f6bdfd130049b673754928e9a7d6b5cfb9d90821"

# ── Logging ───────────────────────────────────────────────────────────────────
def _log(msg):
    try:
        with open(_DEBUG_PATH, 'a') as f:
            f.write("[{}] [updater] {}\n".format(strftime("%Y-%m-%d %H:%M:%S"), msg))
        try:
            os.chmod(_DEBUG_PATH, 0o600)
        except Exception:
            pass
    except Exception:
        pass

# ── Helpers ───────────────────────────────────────────────────────────────────
def _version_tuple(v):
    """'1.2.3' → (1, 2, 3) for numeric comparison."""
    try:
        return tuple(int(x) for x in str(v).strip().split('.'))
    except Exception:
        return (0,)

def _to_bytes(v):
    return v.encode('utf-8') if isinstance(v, str) else v

def _build_ssl_ctx():
    """Return an SSL context.  Prefer proper cert verification; fall back only
    if the receiver's CA store is too old to verify modern certificates."""
    try:
        import ssl
        try:
            return ssl.create_default_context()   # verifies certificate chain
        except Exception:
            _log("SSL: CA store outdated, falling back to unverified context")
            return ssl._create_unverified_context()
    except Exception:
        return None

def _fetch(url, ssl_ctx, timeout=20):
    """Download url, return raw bytes.  On SSL cert failure retries once
    with an unverified context so old receivers still work."""
    try:
        import urllib2 as _ul
    except ImportError:
        import urllib.request as _ul

    def _open(ctx):
        req = _ul.Request(url)
        try:
            resp = _ul.urlopen(req, context=ctx, timeout=timeout)
        except TypeError:
            resp = _ul.urlopen(req, timeout=timeout)
        return resp.read()

    try:
        return _open(ssl_ctx)
    except Exception as e:
        err = str(e).upper()
        if ssl_ctx is not None and any(k in err for k in ("CERT", "SSL", "CERTIFICATE")):
            _log("SSL cert error on {}, retrying unverified".format(url))
            try:
                import ssl
                return _open(ssl._create_unverified_context())
            except Exception as e2:
                raise IOError("Fetch {}: {} / fallback: {}".format(url, e, e2))
        raise IOError("Fetch {}: {}".format(url, e))

def _verify_manifest(manifest_bytes, sig_hex):
    """Verify HMAC-SHA256 signature of the manifest JSON bytes.
    Returns True only if the signature is authentic."""
    try:
        sig_hex = sig_hex.strip() if isinstance(sig_hex, str) else sig_hex.decode('utf-8').strip()
        key = _HMAC_SECRET
        msg = _to_bytes(manifest_bytes) if isinstance(manifest_bytes, str) else manifest_bytes
        msg = msg.rstrip(b'\n\r')
        expected = hmac.new(key, msg, hashlib.sha256).hexdigest()
        try:
            return hmac.compare_digest(expected, sig_hex)
        except AttributeError:
            return expected == sig_hex   # Python < 2.7.7 fallback
    except Exception as e:
        _log("Manifest verification error: {}".format(e))
        return False

def _verify_file(data, expected_sha256):
    """Verify SHA-256 hash of a downloaded file.  Returns True if matching."""
    try:
        data = _to_bytes(data) if isinstance(data, str) else data
        actual = hashlib.sha256(data).hexdigest()
        try:
            return hmac.compare_digest(actual, expected_sha256.lower())
        except AttributeError:
            return actual == expected_sha256.lower()
    except Exception as e:
        _log("File hash verification error: {}".format(e))
        return False

# ── Public API ────────────────────────────────────────────────────────────────
def get_version():
    return VERSION

def check_and_apply_update(callback=None):
    """
    Launch a daemon thread that:
      1. Fetches manifest.json + manifest.sig and verifies the HMAC signature
      2. Compares remote version with VERSION
      3. Downloads each plugin file and verifies its SHA-256 hash
      4. Backs up the current install, then atomically replaces all files
      5. Calls callback(new_version) on success
    Never raises; all errors are logged.
    """
    t = threading.Thread(target=_worker, args=(callback,))
    t.daemon = True
    t.start()

# ── Background worker ─────────────────────────────────────────────────────────
def _worker(callback):
    _log("Update check started — current v{}".format(VERSION))
    ssl_ctx = _build_ssl_ctx()

    # ── 1. Fetch and authenticate the manifest ───────────────────────────────
    try:
        manifest_bytes = _fetch("{}/manifest.json".format(UPDATE_BASE), ssl_ctx, timeout=10)
        sig_raw        = _fetch("{}/manifest.sig".format(UPDATE_BASE),  ssl_ctx, timeout=10)
    except Exception as e:
        _log("Manifest fetch failed: {}".format(e))
        return

    if not _verify_manifest(manifest_bytes, sig_raw):
        _log("SECURITY: manifest signature invalid — update aborted")
        return

    try:
        manifest    = json.loads(manifest_bytes.decode('utf-8') if isinstance(manifest_bytes, bytes) else manifest_bytes)
        remote      = str(manifest.get('version', '')).strip()
        file_hashes = manifest.get('files', {})
    except Exception as e:
        _log("Manifest parse error: {}".format(e))
        return

    if not remote or not file_hashes:
        _log("Manifest incomplete — update aborted")
        return

    _log("Remote version: v{}".format(remote))

    if _version_tuple(remote) <= _version_tuple(VERSION):
        _log("Already up to date (v{})".format(VERSION))
        return

    _log("Update v{} → v{} available, downloading…".format(VERSION, remote))

    # ── 2. Download and hash-verify every file ───────────────────────────────
    tmp_dir = "/tmp/autobiss_update"
    try:
        if os.path.exists(tmp_dir):
            shutil.rmtree(tmp_dir)
        os.makedirs(tmp_dir)
    except Exception as e:
        _log("Cannot create tmp dir: {}".format(e))
        return

    downloaded = {}
    for fname in PLUGIN_FILES:
        expected = file_hashes.get(fname)
        if not expected:
            _log("SECURITY: no hash for {} in manifest — update aborted".format(fname))
            return
        try:
            data = _fetch("{}/{}".format(UPDATE_BASE, fname), ssl_ctx, timeout=30)
        except Exception as e:
            _log("Download failed for {}: {}".format(fname, e))
            return
        if not _verify_file(data, expected):
            _log("SECURITY: SHA-256 mismatch for {} — update aborted".format(fname))
            return
        downloaded[fname] = data
        _log("OK  {}  ({} bytes)".format(fname, len(data)))

    # Write verified files to tmp
    for fname, data in downloaded.items():
        dest = os.path.join(tmp_dir, fname)
        try:
            with open(dest, 'wb') as fh:
                fh.write(data)
        except Exception as e:
            _log("Write to tmp failed for {}: {}".format(fname, e))
            return

    # ── 3. Backup existing installation ──────────────────────────────────────
    try:
        if os.path.exists(BACKUP_DIR):
            shutil.rmtree(BACKUP_DIR)
        os.makedirs(BACKUP_DIR)
        for fname in PLUGIN_FILES:
            src = os.path.join(INSTALL_DIR, fname)
            if os.path.exists(src):
                shutil.copy2(src, os.path.join(BACKUP_DIR, fname))
        _log("Backup saved to {}".format(BACKUP_DIR))
    except Exception as e:
        _log("Backup failed: {}".format(e))
        return

    # ── 4. Atomically replace files (stage next to target, then rename) ───────
    applied = []
    staged = []
    try:
        # Stage every file in the install dir first. A failure here leaves the
        # live installation completely untouched.
        for fname in PLUGIN_FILES:
            src = os.path.join(tmp_dir, fname)
            stage = os.path.join(INSTALL_DIR, ".{}.new".format(fname))
            shutil.copy2(src, stage)
            staged.append((stage, os.path.join(INSTALL_DIR, fname)))
        for stage, dst in staged:
            os.rename(stage, dst)
            applied.append(os.path.basename(dst))
            try:
                os.chmod(dst, 0o755)
            except Exception:
                pass
        staged = []
        _log("All files replaced — v{} installed".format(remote))

        # Clear Python bytecode cache so updated .py files are actually loaded
        try:
            pycache = os.path.join(INSTALL_DIR, '__pycache__')
            if os.path.isdir(pycache):
                shutil.rmtree(pycache)
                _log("Cleared __pycache__")
        except Exception as e:
            _log("Warning: could not clear __pycache__: {}".format(e))
    except Exception as e:
        # Remove any leftover staged files, then roll back from backup
        for stage, _dst in staged:
            try:
                if os.path.exists(stage):
                    os.remove(stage)
            except Exception:
                pass
        _log("Replace failed after {} — rolling back: {}".format(applied, e))
        for fname in PLUGIN_FILES:
            bak = os.path.join(BACKUP_DIR, fname)
            dst = os.path.join(INSTALL_DIR, fname)
            if os.path.exists(bak):
                try:
                    shutil.copy2(bak, dst)
                except Exception:
                    pass
        return

    # ── 5. Cleanup tmp ────────────────────────────────────────────────────────
    try:
        shutil.rmtree(tmp_dir)
    except Exception:
        pass

    # ── 6. Notify caller ─────────────────────────────────────────────────────
    _log("Update complete: v{} → v{}".format(VERSION, remote))
    if callback:
        try:
            callback(remote)
        except Exception as e:
            _log("Callback error: {}".format(e))
