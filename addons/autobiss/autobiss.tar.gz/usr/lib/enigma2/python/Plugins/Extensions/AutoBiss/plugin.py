# -*- coding: utf-8 -*-
"""
AutoBiss E2 - Enigma2 Plugin v4.0
Real-time BISS key finder & softcam injector
Professional interface with VPS decryption
Compatible with Python 2.7 and Python 3.x
"""
from __future__ import absolute_import, print_function, division

# CRITICAL: Import error trap - if anything below fails, we log it
import traceback
import os
import sys

# Try to set up logging first
_DEBUG_PATH = '/tmp/autobiss_debug.log'
def _safe_log(msg):
    try:
        from time import strftime
        with open(_DEBUG_PATH, 'a') as f:
            f.write("[{}] [plugin] {}\n".format(strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass

_safe_log("=" * 60)
_safe_log("plugin.py module starting import...")

# CRITICAL: PluginDescriptor must import or Enigma2 will crash at plugin init
try:
    from Plugins.Plugin import PluginDescriptor
    _safe_log("PluginDescriptor imported OK")
except Exception as e:
    _safe_log("FATAL PluginDescriptor import: {}".format(e))
    raise

# Screen - also critical but can be stubbed if fails
try:
    from Screens.Screen import Screen
except Exception:
    Screen = type('Screen', (), {'__init__': lambda s, *a, **k: None})

# MessageBox
try:
    from Screens.MessageBox import MessageBox
except Exception:
    MessageBox = type('MessageBox', (), {'TYPE_INFO': 0, 'TYPE_ERROR': 1})

# ActionMap
try:
    from Components.ActionMap import ActionMap
except Exception:
    ActionMap = type('ActionMap', (), {'__init__': lambda s, *a, **k: None})

# Label
try:
    from Components.Label import Label
except Exception:
    Label = type('Label', (), {'__init__': lambda s, *a, **k: None, 'setText': lambda s, *a, **k: None})

# Pixmap
try:
    from Components.Pixmap import Pixmap
except Exception:
    Pixmap = type('Pixmap', (), {'__init__': lambda s, *a, **k: None, 'setPixmap': lambda s, *a, **k: None})

# ServiceEventTracker
try:
    from Components.ServiceEventTracker import ServiceEventTracker
except Exception:
    ServiceEventTracker = type('ServiceEventTracker', (), {})

# enigma C++ bindings - import each individually for compatibility
try:
    from enigma import eTimer
except Exception:
    _safe_log("WARNING: eTimer not available, using stub")
    eTimer = type('eTimer', (), {'start': lambda s, *a, **k: None, 'stop': lambda s: None, 'callback': type('cb', (), {'append': lambda s, *a, **k: None})()})

try:
    from enigma import iPlayableService
except Exception:
    _safe_log("WARNING: iPlayableService not available, using stub")
    iPlayableService = type('iPlayableService', (), {'evStart': 0, 'evUpdatedInfo': 1})

try:
    from enigma import iServiceInformation
except Exception:
    _safe_log("WARNING: iServiceInformation not available, using stub")
    iServiceInformation = type('iServiceInformation', (), {})

# Some enigma2 builds lack certain iServiceInformation constants
_MISSING_SVC = [('sSID', 3), ('sCAIDs', 15), ('sVideoPID', 6), ('sAudioPID', 7)]
for _name, _val in _MISSING_SVC:
    if not hasattr(iServiceInformation, _name):
        setattr(iServiceInformation, _name, _val)
        _safe_log("WARNING: iServiceInformation.{} missing, using fallback value 0x{:X}".format(_name, _val))

try:
    from enigma import parseColor
except Exception:
    _safe_log("WARNING: parseColor not available, using stub")
    parseColor = lambda c, *a: 0x00ffffff

from time import time, strftime
import re
from threading import Timer

# Import our modules
try:
    from Plugins.Extensions.AutoBiss.key_analyzer import write_service_info
    from Plugins.Extensions.AutoBiss.biss_engine import (
        CWCache, parse_ecm_info, get_global_cwl,
        run_tsdec_extract_cw, write_softcam_key, write_ecm_info,
        cleanup_recording_sidecars, reload_softcam,
        get_ecm_pid, format_cw_for_display, BISS_CAID, OUTPUT_DIR, log_debug,
        decrypt_via_vps,
    )
    _safe_log("AutoBiss modules imported OK")
except Exception as e:
    _safe_log("ERROR importing AutoBiss modules: {}".format(e))
    _safe_log(traceback.format_exc())

# Updater — optional, never crashes the plugin if missing
_PLUGIN_VERSION    = "1.1"
_check_for_update  = None
try:
    from Plugins.Extensions.AutoBiss.updater import (
        VERSION as _PLUGIN_VERSION,
        check_and_apply_update as _check_for_update,
    )
    _safe_log("Updater imported OK — current v{}".format(_PLUGIN_VERSION))
except Exception as e:
    _safe_log("Updater import skipped: {}".format(e))

# Device registration — optional, never crashes the plugin if missing
_device_is_registered = None
_device_register      = None
try:
    from Plugins.Extensions.AutoBiss.device import (
        is_registered as _device_is_registered,
        register      as _device_register,
    )
    _safe_log("Device module imported OK")
except Exception as e:
    _safe_log("Device module import skipped: {}".format(e))

# ------------------------------------------------------------------------------
# Plugin paths
# ------------------------------------------------------------------------------
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/AutoBiss"



# ------------------------------------------------------------------------------
# Utility Functions
# ------------------------------------------------------------------------------
def sanitize_filename(name):
    if name is None:
        return "Unknown"
    clean = re.sub(r'[^\w\s\-]', '_', name)
    clean = re.sub(r'\s+', '_', clean)
    return clean.strip('_')

def get_unique_filepath(base_path):
    if not os.path.exists(base_path):
        return base_path
    directory = os.path.dirname(base_path)
    filename = os.path.basename(base_path)
    name, ext = os.path.splitext(filename)
    counter = 1
    while True:
        new_name = "{}_{}{}".format(name, counter, ext)
        new_path = os.path.join(directory, new_name)
        if not os.path.exists(new_path):
            return new_path
        counter += 1
        if counter > 999:
            break
    return base_path

def ensure_dir(path):
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
            log_debug("Created directory: {}".format(path))
        except Exception as e:
            log_debug("Failed to create directory {}: {}".format(path, e))

# ------------------------------------------------------------------------------
# Import RecordTimer
# ------------------------------------------------------------------------------
_RECORDTIMER_AVAILABLE = False
try:
    from RecordTimer import RecordTimerEntry, AFTEREVENT
    from Navigation import NavigationInstance
    from ServiceReference import ServiceReference as SvcRef
    _RECORDTIMER_AVAILABLE = True
    log_debug("RecordTimer modules imported OK")
except Exception as e:
    log_debug("ERROR importing RecordTimer modules: {}".format(e))

# ------------------------------------------------------------------------------
# Background Service
# ------------------------------------------------------------------------------
class AutoBissBackgroundService(object):
    def __init__(self, session):
        self.session = session
        self.cw_cache = CWCache()
        self._recording_sid = None
        self._cooldown = {}
        self._cooldown_secs = 60
        self._record_duration = 1
        self._timer_entry = None
        self._notify_timer = eTimer()
        self._notify_timer.callback.append(self._on_recording_finished)
        self._debounce_timer = eTimer()
        self._debounce_timer.callback.append(self._debounced_check)
        self._popup_state = {'status': 'idle', 'cw': None, 'channel': ''}
        self._popup_timer = eTimer()
        self._popup_timer.callback.append(self._check_popup_state)

        # Device registration — fires 5 s after startup (before update check)
        self._reg_result     = None   # set by background thread: 'ok' | 'failed'
        self._reg_poll_count = 0
        self._reg_start_timer = eTimer()
        self._reg_start_timer.callback.append(self._start_registration)
        self._reg_start_timer.start(5000, True)
        self._reg_poll_timer = eTimer()
        self._reg_poll_timer.callback.append(self._check_reg_result)

        # Auto-updater — fires 10 s after E2 has fully started
        self._update_pending_version = None
        self._update_poll_count = 0
        self._update_start_timer = eTimer()
        self._update_start_timer.callback.append(self._start_update_check)
        self._update_start_timer.start(10000, True)
        self._update_poll_timer = eTimer()
        self._update_poll_timer.callback.append(self._check_update_result)

        # CWL download — fires 15 s after startup, refreshes every 6 hours
        self._cwl_timer = eTimer()
        self._cwl_timer.callback.append(self._download_cwl)
        self._cwl_timer.start(15000, True)

        self.__event_tracker = ServiceEventTracker(
            screen=self,
            eventmap={
                iPlayableService.evStart: self._service_changed,
                iPlayableService.evUpdatedInfo: self._service_info_updated,
            }
        )
        log_debug("AutoBissBackgroundService initialized")

    def _service_changed(self):
        log_debug("_service_changed triggered")
        if self._recording_sid is not None:
            self._abort_recording("user zapped")
        self._debounce_timer.stop()
        self._debounce_timer.start(1000, True)

    def _service_info_updated(self):
        log_debug("_service_info_updated triggered")
        self._debounce_timer.stop()
        self._debounce_timer.start(800, True)

    def _debounced_check(self):
        log_debug("_debounced_check executing")
        self._check_current_service()

    def _check_popup_state(self):
        state = self._popup_state
        if state['status'] == 'idle':
            return
        if state['status'] == 'searching':
            self.session.open(
                MessageBox,
                "AutoBiss: Searching key...",
                MessageBox.TYPE_INFO,
                timeout=3,
            )
            state['status'] = 'idle'
            return
        if state['status'] == 'success':
            cw_disp = format_cw_for_display(state['cw'])
            self.session.open(
                MessageBox,
                "AutoBiss: {}".format(cw_disp),
                MessageBox.TYPE_INFO,
                timeout=4,
            )
            state['status'] = 'idle'
            return
        if state['status'] == 'failed':
            self.session.open(
                MessageBox,
                "AutoBiss: Key Not Found!",
                MessageBox.TYPE_INFO,
                timeout=4,
            )
            state['status'] = 'idle'
            return

    def _start_registration(self):
        if _device_is_registered is None or _device_register is None:
            log_debug("Device module not available, skipping registration")
            return
        if _device_is_registered():
            log_debug("Device already registered")
            return
        log_debug("Device not registered — starting registration")
        def _on_done(token):
            self._reg_result = 'ok' if token else 'failed'
        try:
            _device_register(callback=_on_done)
            self._reg_poll_timer.start(2000, False)
        except Exception as e:
            log_debug("Registration start error: {}".format(e))

    def _check_reg_result(self):
        self._reg_poll_count += 1
        if self._reg_poll_count > 60:   # 60 × 2 s = 2 min timeout
            self._reg_poll_timer.stop()
            return
        result = self._reg_result
        if result is None:
            return
        self._reg_result = None
        self._reg_poll_timer.stop()
        if result == 'ok':
            log_debug("Device registered — VPS decryption now active")
            try:
                self.session.open(
                    MessageBox,
                    "AutoBiss: Device registered!\nVPS decryption is now active.",
                    MessageBox.TYPE_INFO,
                    timeout=5,
                )
            except Exception as e:
                log_debug("Registration notification error: {}".format(e))
        else:
            log_debug("Device registration failed")
            try:
                self.session.open(
                    MessageBox,
                    "AutoBiss: Registration failed.\nCheck internet connection.\nVPS decryption unavailable.",
                    MessageBox.TYPE_INFO,
                    timeout=6,
                )
            except Exception as e:
                log_debug("Registration failure notification error: {}".format(e))

    def _start_update_check(self):
        if _check_for_update is None:
            log_debug("Updater not available, skipping")
            return
        log_debug("Starting background update check (current v{})".format(_PLUGIN_VERSION))
        def _on_done(new_version):
            self._update_pending_version = new_version
        try:
            _check_for_update(callback=_on_done)
            self._update_poll_timer.start(3000, False)
        except Exception as e:
            log_debug("Update check start error: {}".format(e))

    def _check_update_result(self):
        self._update_poll_count += 1
        # Stop polling after 2 minutes (40 × 3 s) regardless of outcome
        if self._update_poll_count > 40:
            self._update_poll_timer.stop()
            return
        new_version = self._update_pending_version
        if new_version is None:
            return
        self._update_pending_version = None
        self._update_poll_timer.stop()
        log_debug("Update installed — notifying user (v{})".format(new_version))
        try:
            self.session.open(
                MessageBox,
                "AutoBiss updated to v{}!\nRestart the receiver to apply the new version.".format(new_version),
                MessageBox.TYPE_INFO,
                timeout=10,
            )
        except Exception as e:
            log_debug("Update notification error: {}".format(e))

    def _report_cw_to_vps(self, sid, cw_hex, svc_info):
        """Report a locally-found CW to VPS so it gets saved in the channels panel."""
        def _worker():
            try:
                import json as _json
                try:
                    import urllib2 as _ul
                except ImportError:
                    import urllib.request as _ul
                import ssl as _ssl

                _LEGACY_KEY = "a1b2c3d4e5f678901234567890abcdef1234567890abcdef"
                token = None
                try:
                    from Plugins.Extensions.AutoBiss.device import get_token
                    token = get_token()
                except Exception:
                    pass

                payload = _json.dumps({
                    "sid":         "{:04X}".format(sid),
                    "cw_hex":      cw_hex,
                    "service_ref": svc_info.get('service_ref', ''),
                    "video_pid":   svc_info.get('video_pid', ''),
                    "audio_pid":   svc_info.get('audio_pid', ''),
                    "pcr_pid":     svc_info.get('pcr_pid', ''),
                    "pmt_pid":     svc_info.get('pmt_pid', ''),
                    "txt_pid":     svc_info.get('txt_pid', ''),
                    "tsid":        svc_info.get('tsid', ''),
                    "onid":        svc_info.get('onid', ''),
                    "caid":        svc_info.get('caid', ''),
                })
                data = payload.encode('utf-8') if isinstance(payload, str) else payload
                req = _ul.Request("https://tsdec.kingcs.xyz/autobiss/report_cw", data=data)
                req.add_header("Content-Type", "application/json")
                if token:
                    req.add_header("X-Device-Token", token)
                else:
                    req.add_header("X-API-Key", _LEGACY_KEY)
                try:
                    ctx = _ssl.create_default_context()
                except Exception:
                    ctx = _ssl._create_unverified_context()
                try:
                    _ul.urlopen(req, context=ctx, timeout=10)
                except TypeError:
                    _ul.urlopen(req, timeout=10)
                log_debug("_report_cw_to_vps: reported SID 0x{:04X}".format(sid))
            except Exception as e:
                log_debug("_report_cw_to_vps error: {}".format(e))

        import threading as _th
        t = _th.Thread(target=_worker)
        t.daemon = True
        t.start()

    def _download_cwl(self):
        """Download the CWL key file from VPS to /tmp/CW_list.cwl in background.
        Reschedules itself every 6 hours so the file stays fresh."""
        def _worker():
            url = "https://tsdec.kingcs.xyz/autobiss/CW_list.cwl"
            dest = "/tmp/CW_list.cwl"
            tmp  = dest + ".tmp"
            try:
                try:
                    import urllib2 as _ul
                except ImportError:
                    import urllib.request as _ul
                import ssl as _ssl
                try:
                    ctx = _ssl.create_default_context()
                except Exception:
                    ctx = _ssl._create_unverified_context()
                try:
                    resp = _ul.urlopen(url, context=ctx, timeout=30)
                except TypeError:
                    resp = _ul.urlopen(url, timeout=30)
                data = resp.read()
                with open(tmp, 'wb') as f:
                    f.write(data)
                import os as _os
                _os.replace(tmp, dest)
                log_debug("CWL downloaded: {} bytes → {}".format(len(data), dest))
            except Exception as e:
                log_debug("CWL download failed: {}".format(e))
            # Reschedule refresh every 6 hours
            try:
                self._cwl_timer.start(6 * 3600 * 1000, True)
            except Exception:
                pass

        import threading as _th
        t = _th.Thread(target=_worker)
        t.daemon = True
        t.start()

    def _get_service_info(self):
        """Extract all service info (SID, PIDs, service ref, TSID, ONID, CAIDs) from current service."""
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not ref:
                return {}
            service = self.session.nav.getCurrentService()
            if not service:
                return {}
            info = service.info()
            if not info:
                return {}
            return {
                'service_ref': str(ref),
                'sid': "{:04X}".format(info.getInfo(iServiceInformation.sSID)),
                'video_pid': "{:04X}".format(info.getInfo(iServiceInformation.sVideoPID)),
                'audio_pid': "{:04X}".format(info.getInfo(iServiceInformation.sAudioPID)),
                'pcr_pid': "{:04X}".format(info.getInfo(iServiceInformation.sPCRPID) if hasattr(iServiceInformation, 'sPCRPID') else 0),
                'pmt_pid': "{:04X}".format(info.getInfo(iServiceInformation.sPMTPID) if hasattr(iServiceInformation, 'sPMTPID') else 0),
                'txt_pid': "{:04X}".format(info.getInfo(iServiceInformation.sTXTPID) if hasattr(iServiceInformation, 'sTXTPID') else 0),
                'tsid': "{:04X}".format(info.getInfo(iServiceInformation.sTSID) if hasattr(iServiceInformation, 'sTSID') else 0),
                'onid': "{:04X}".format(info.getInfo(iServiceInformation.sONID) if hasattr(iServiceInformation, 'sONID') else 0),
                'caid': "{:04X}".format(info.getInfo(iServiceInformation.sCAIDs) if hasattr(iServiceInformation, 'sCAIDs') else 0),
            }
        except Exception as e:
            log_debug("_get_service_info error: {}".format(e))
            return {}

    def force_update_current(self):
        """Force immediate re-decrypt of current channel (UPDATE button)."""
        log_debug("force_update_current triggered")
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        if not ref:
            log_debug("force_update: no service reference")
            return
        service = self.session.nav.getCurrentService()
        if not service:
            log_debug("force_update: no current service")
            return
        info = service.info()
        if not info:
            log_debug("force_update: no service info")
            return
        sid = info.getInfo(iServiceInformation.sSID)
        log_debug("force_update: SID=0x{:04X}".format(sid))
        # Clear cache and cooldown for this SID
        if sid in self.cw_cache._cache:
            del self.cw_cache._cache[sid]
        if sid in self._cooldown:
            del self._cooldown[sid]
        # Trigger check
        self._check_current_service()

    def _check_current_service(self):
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not ref:
                log_debug("_check: no service reference")
                return
            service = self.session.nav.getCurrentService()
            if not service:
                log_debug("_check: no current service")
                return
            info = service.info()
            if not info:
                log_debug("_check: no service info")
                return
            caids = info.getInfoObject(iServiceInformation.sCAIDs)
            if not caids:
                log_debug("_check: caids is None")
                return
            caid_list = list(caids)
            log_debug("Current CAIDs: {}".format(["0x{:04X}".format(c) for c in caid_list]))
            if BISS_CAID not in caid_list:
                log_debug("_check: BISS CAID 0x2600 not found in caid list")
                return
            sid = info.getInfo(iServiceInformation.sSID)
            log_debug("BISS detected on SID 0x{:04X}".format(sid))
            now = time()
            if sid in self._cooldown:
                elapsed = now - self._cooldown[sid]
                if elapsed < self._cooldown_secs:
                    log_debug("SID 0x{:04X} in cooldown ({}s left)".format(sid, int(self._cooldown_secs - elapsed)))
                    return
                else:
                    del self._cooldown[sid]
            ch_name = info.getName() if info else "AutoBiss"
            ecm_pid = get_ecm_pid(self.session)

            cw = self.cw_cache.get(sid)

            # Fast path: softcam already has the CW in /tmp/ecm.info — no recording needed
            if not cw:
                cw = parse_ecm_info()
                if cw:
                    log_debug("CW from ecm.info for SID 0x{:04X}: {}****".format(sid, cw[:4]))
                    self.cw_cache.set(sid, cw)
                    self._popup_state = {'status': 'success', 'cw': cw, 'channel': ch_name}
                    try:
                        if write_softcam_key(sid, ecm_pid, cw, ch_name):
                            reload_softcam()
                        write_ecm_info(sid, ecm_pid, cw, ch_name)
                    except Exception as e:
                        log_debug("ecm.info inject exception: {}".format(e))
                    # Report to VPS so it gets saved in channels panel
                    svc_info = self._get_service_info()
                    self._report_cw_to_vps(sid, cw, svc_info)
                    self._cooldown[sid] = time()
                    return

            if cw:
                log_debug("CW already known for SID 0x{:04X}: {}****".format(sid, cw[:4]))
                try:
                    if write_softcam_key(sid, ecm_pid, cw, ch_name):
                        reload_softcam()
                    write_ecm_info(sid, ecm_pid, cw, ch_name)
                except Exception as e:
                    log_debug("Re-inject exception: {}".format(e))
                return
            if self._recording_sid is not None:
                log_debug("Recording already in progress for SID 0x{:04X}, skip".format(self._recording_sid))
                return
            self._start_recording(sid, ref, info)
        except Exception as e:
            log_debug("_check_current_service exception: {}".format(e))

    def _abort_recording(self, reason):
        log_debug("_abort_recording: {}".format(reason))
        self._notify_timer.stop()
        if self._timer_entry:
            try:
                NavigationInstance.instance.RecordTimer.removeEntry(self._timer_entry)
            except Exception as e:
                log_debug("removeEntry warning: {}".format(e))
            self._timer_entry = None
        old_sid = self._recording_sid
        self._recording_sid = None
        self._current_ts_path = None
        self._channel_name = None
        if old_sid is not None:
            self._cooldown[old_sid] = time()

    def _start_recording(self, sid, ref, info):
        global _vps_unreachable
        _vps_unreachable = False
        log_debug("_start_recording for SID 0x{:04X}".format(sid))
        ch_name = info.getName() if info else "Unknown"
        self._popup_state = {'status': 'searching', 'cw': None, 'channel': ch_name}
        self._popup_timer.start(200, True)
        ensure_dir(OUTPUT_DIR)
        safe_name = sanitize_filename(ch_name)
        timestamp = strftime("%Y%m%d_%H%M%S")
        basename = "AutoBiss_{}_{}".format(safe_name, timestamp)
        ts_path = os.path.join(OUTPUT_DIR, "{}.ts".format(basename))
        ts_path = get_unique_filepath(ts_path)
        filename_only = os.path.splitext(os.path.basename(ts_path))[0]
        self._recording_sid = sid
        self._current_ts_path = ts_path
        self._safe_name = safe_name
        self._channel_name = ch_name
        log_debug("Target TS: {}".format(ts_path))
        if not _RECORDTIMER_AVAILABLE:
            log_debug("RecordTimer not available, aborting record")
            self._abort_recording("no RecordTimer")
            return
        try:
            serviceref = SvcRef(ref)
            begin = int(time())
            end = begin + self._record_duration
            name = "AutoBiss {}".format(safe_name)
            description = "AutoBiss {}s sample".format(self._record_duration)
            event = None
            try:
                event = info.getEvent(ref)
            except Exception:
                pass
            eit = event.getEventId() if event else -1
            entry = RecordTimerEntry(
                serviceref, begin, end, name, description, eit,
                False, False, AFTEREVENT.NONE, True,
            )
            entry.dirname = OUTPUT_DIR
            if hasattr(entry, 'Filename'):
                entry.Filename = filename_only
            elif hasattr(entry, 'filename'):
                entry.filename = filename_only
            if hasattr(entry, 'dontSave'):
                entry.dontSave = True
            if hasattr(entry, 'descramble'):
                entry.descramble = False
                log_debug("Set descramble=False")
            if hasattr(entry, 'record_ecm'):
                entry.record_ecm = False
            NavigationInstance.instance.RecordTimer.record(entry)
            self._timer_entry = entry
            log_debug("RecordTimer.record() success")
            self._notify_timer.start(self._record_duration * 1000, True)
            try:
                write_service_info(self.session, ts_path)
            except Exception as e:
                log_debug("write_service_info exception: {}".format(e))
        except Exception as e:
            log_debug("_start_recording exception: {}".format(e))
            self._abort_recording("exception")

    def _find_recorded_file(self, expected_path, search_token):
        if os.path.exists(expected_path):
            return expected_path
        try:
            now = time()
            candidates = []
            for f in os.listdir(OUTPUT_DIR):
                if not f.endswith('.ts'):
                    continue
                if '_dec.ts' in f:
                    continue
                full = os.path.join(OUTPUT_DIR, f)
                try:
                    mtime = os.path.getmtime(full)
                    if (now - mtime) < 45 and search_token in f:
                        candidates.append((full, mtime))
                except Exception:
                    pass
            if candidates:
                candidates.sort(key=lambda x: x[1], reverse=True)
                found = candidates[0][0]
                log_debug("Found actual TS file by search: {}".format(found))
                return found
        except Exception as e:
            log_debug("Filesystem search error: {}".format(e))
        log_debug("Could not find any TS file matching '{}'".format(search_token))
        return None

    def _on_recording_finished(self):
        log_debug("_on_recording_finished called")
        sid = self._recording_sid
        ts_path = getattr(self, '_current_ts_path', None)
        safe_name = getattr(self, '_safe_name', '')
        channel_name = getattr(self, '_channel_name', 'AutoBiss')
        if self._timer_entry:
            try:
                NavigationInstance.instance.RecordTimer.removeEntry(self._timer_entry)
            except Exception as e:
                log_debug("removeEntry warning: {}".format(e))
            self._timer_entry = None
        self._recording_sid = None
        if not ts_path or not safe_name:
            log_debug("No ts_path/safe_name stored")
            return
        # Collect service info on main thread NOW — _get_service_info() uses
        # session.nav which is not safe to call from a background thread.
        svc_info = self._get_service_info()
        def _delayed_process():
            search_token = safe_name
            actual_path = self._find_recorded_file(ts_path, search_token)
            if not actual_path:
                log_debug("TS file not found after search: {}".format(ts_path))
                self._cooldown[sid] = time()
                return
            log_debug("TS sample recorded: {}".format(actual_path))
            global _latest_ts_by_sid
            _latest_ts_by_sid[sid] = actual_path
            self._cooldown[sid] = time()
            global _vps_unreachable
            cw = parse_ecm_info()
            if cw:
                log_debug("CW from softcam: {}****".format(cw[:4] if cw else ""))
                self.cw_cache.set(sid, cw)
            if not cw:
                sid_hex = "{:04X}".format(sid)
                ecm_pid = get_ecm_pid(self.session)
                ecm_hex = ecm_pid.upper().replace("0X", "").replace("0x", "")
                log_debug("Trying VPS decrypt for SID {} ECM {}".format(sid_hex, ecm_hex))
                try:
                    global_cwl = get_global_cwl()
                    cw, reachable = decrypt_via_vps(
                        actual_path, global_cwl, sid_hex, ecm_hex,
                        service_ref=svc_info.get('service_ref', ''),
                        video_pid=svc_info.get('video_pid', ''),
                        audio_pid=svc_info.get('audio_pid', ''),
                        pcr_pid=svc_info.get('pcr_pid', ''),
                        pmt_pid=svc_info.get('pmt_pid', ''),
                        txt_pid=svc_info.get('txt_pid', ''),
                        tsid=svc_info.get('tsid', ''),
                        onid=svc_info.get('onid', ''),
                        caid=svc_info.get('caid', '')
                    )
                    if cw:
                        log_debug("CW extracted by VPS: {}****".format(cw[:4]))
                    if not reachable:
                        _vps_unreachable = True
                        log_debug("VPS is unreachable")
                    if not cw and reachable and global_cwl:
                        # Local tsdec fallback — TS file still present here
                        log_debug("VPS returned no CW, falling back to local tsdec")
                        try:
                            cw, rc = run_tsdec_extract_cw(actual_path, global_cwl)
                            if cw:
                                log_debug("CW extracted by local tsdec: {}****".format(cw[:4]))
                            else:
                                log_debug("tsdec could not find CW in CWL (rc={})".format(rc))
                        except Exception as e:
                            log_debug("tsdec extract exception: {}".format(e))
                    # Delete TS after all decryption attempts are done
                    try:
                        if os.path.exists(actual_path):
                            os.remove(actual_path)
                            log_debug("Cleaned up sample TS: {}".format(actual_path))
                    except Exception as e:
                        log_debug("Cleanup warning: {}".format(e))
                except Exception as e:
                    log_debug("decrypt_via_vps exception: {}".format(e))
            if cw:
                self.cw_cache.set(sid, cw)
                ecm_pid = get_ecm_pid(self.session)
                try:
                    if write_softcam_key(sid, ecm_pid, cw, channel_name):
                        reload_softcam()
                    else:
                        log_debug("Failed to write SoftCam.Key")
                    write_ecm_info(sid, ecm_pid, cw, channel_name)
                except Exception as e:
                    log_debug("Softcam injection exception: {}".format(e))
                # Clean up all recording sidecar files
                try:
                    cleanup_recording_sidecars(actual_path)
                except Exception as e:
                    log_debug("Sidecar cleanup exception: {}".format(e))
                # Report locally-found CW to VPS for channels panel
                self._report_cw_to_vps(sid, cw, svc_info)
                self._popup_state = {'status': 'success', 'cw': cw, 'channel': channel_name}
            else:
                if _vps_unreachable:
                    log_debug("No CW found and VPS unreachable. Maintenance mode.")
                else:
                    log_debug("No CW found. Channel will remain encrypted.")
                self._popup_state = {'status': 'failed', 'cw': None, 'channel': channel_name}
            # Safety-net cleanup
            try:
                if os.path.exists(actual_path):
                    os.remove(actual_path)
                    log_debug("Safety cleanup sample TS: {}".format(actual_path))
            except Exception:
                pass
        t = Timer(0.5, _delayed_process)
        t.daemon = True
        t.start()

# ------------------------------------------------------------------------------
# AutoBiss Main Screen (Professional Interface)
# ------------------------------------------------------------------------------
class AutoBissMainScreen(Screen):
    skin = """
    <screen name="AutoBissMainScreen" position="center,center" size="720,420" title="AutoBiss E2">

        <widget name="logo_biss"   position="14,7"   size="52,52"  alphatest="blend" />
        <widget name="title"       position="76,8"   size="484,52" font="Regular;32" halign="left" foregroundColor="#ffffff" />
        <widget name="version_lbl" position="558,20" size="148,28" font="Regular;16" halign="right" foregroundColor="#555555" />

        <ePixmap position="0,67" size="720,2" pixmap="skin_default/div-h.png" />

        <widget name="event_name" position="20,75"  size="680,38" font="Regular;26" halign="center" foregroundColor="#00e5ff" />
        <widget name="pids"       position="20,117" size="680,26" font="Regular;17" halign="center" foregroundColor="#888888" />

        <ePixmap position="0,148" size="720,2" pixmap="skin_default/div-h.png" />

        <widget name="status"   position="20,155"  size="680,30" font="Regular;21" halign="center" foregroundColor="#00ff88" />
        <widget name="cw_label" position="55,198"  size="200,40" font="Regular;22" halign="right"  foregroundColor="#888888" />
        <widget name="cw_value" position="263,193" size="425,50" font="Regular;32" halign="left"   foregroundColor="#ff00ff" />

        <ePixmap position="0,252" size="720,2" pixmap="skin_default/div-h.png" />

        <widget name="vps_status" position="20,259" size="680,26" font="Regular;17" halign="center" foregroundColor="#555555" />

        <ePixmap position="0,358" size="720,2" pixmap="skin_default/div-h.png" />

        <widget name="btn_exit"   position="20,366"  size="190,46" font="Regular;22" halign="center" foregroundColor="#ff3333" />
        <widget name="btn_update" position="264,366" size="192,46" font="Regular;22" halign="center" foregroundColor="#33cc33" />
        <widget name="btn_about"  position="510,366" size="190,46" font="Regular;22" halign="center" foregroundColor="#3399ff" />

    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.skin = AutoBissMainScreen.skin
        self.title = "AutoBiss E2"

        self["logo_biss"]   = Pixmap()
        self["title"]       = Label("AutoBiss E2")
        self["version_lbl"] = Label("v{}".format(_PLUGIN_VERSION))
        self["event_name"]  = Label("---")
        self["pids"]        = Label("---")
        self["status"]      = Label("Ready")
        self["cw_label"]    = Label("CW Key :")
        self["cw_value"]    = Label("---")
        self["vps_status"]  = Label("VPS: Online  |  AutoBiss v{}".format(_PLUGIN_VERSION))
        self["btn_exit"]    = Label("Exit")
        self["btn_update"]  = Label("Update Plugin")
        self["btn_about"]   = Label("About")

        try:
            self["actions"] = ActionMap(
                ["ColorActions", "SetupActions"],
                {
                    "red":    self.close,
                    "green":  self._do_plugin_update,   # GREEN = update plugin
                    "blue":   self._do_about,
                    "ok":     self._do_force_decrypt,   # OK = force CW re-decrypt
                    "cancel": self.close,
                },
                -2,
            )
        except Exception:
            self["actions"] = ActionMap(
                ["SetupActions"],
                {
                    "cancel": self.close,
                    "ok":     self._do_force_decrypt,
                },
                -2,
            )

        self._update_timer = eTimer()
        self._update_timer.callback.append(self._update_display)
        self._update_timer.start(500, False)
        self._update_display()

        self._load_pixmap("logo_biss", "logo_biss_e.png")

    def _update_display(self):
        try:
            global _vps_unreachable
            if _vps_unreachable:
                self["vps_status"].setText("VPS: Maintenance Mode")
            else:
                self["vps_status"].setText("VPS: Online  |  AutoBiss v{}".format(_PLUGIN_VERSION))

            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not ref:
                return
            service = self.session.nav.getCurrentService()
            if not service:
                return
            info = service.info()
            if not info:
                return

            sname = info.getName() if info else "Unknown"
            self["event_name"].setText(sname)

            caids = info.getInfoObject(iServiceInformation.sCAIDs)
            if caids and BISS_CAID in list(caids):
                sid = info.getInfo(iServiceInformation.sSID)

                sid_hex = "{:04X}".format(sid)
                vpid = info.getInfo(iServiceInformation.sVideoPID)
                apid = info.getInfo(iServiceInformation.sAudioPID)
                self["pids"].setText("SID: {}  VPID: {:04X}  APID: {:04X}".format(sid_hex, vpid, apid))

                cw = _get_cached_cw(sid)
                if _vps_unreachable:
                    self["status"].setText("Maintenance  |  SID: 0x{:04X}".format(sid))
                    self["cw_value"].setText("VPS Unreachable")
                    self._set_cw_color("#ff8800")
                elif cw:
                    self["status"].setText("BISS DECRYPTED  |  SID: 0x{:04X}".format(sid))
                    self["cw_value"].setText(format_cw_for_display(cw))
                    self._set_cw_color("#ff00ff")
                else:
                    self["status"].setText("Searching...  |  SID: 0x{:04X}".format(sid))
                    self["cw_value"].setText("---")
                    self._set_cw_color("#ffcc00")
            else:
                self["status"].setText("Not a BISS encrypted channel")
                self["cw_value"].setText("N/A")
                self._set_cw_color("#555555")
                self["pids"].setText("---")

        except Exception as e:
            log_debug("MainScreen update exception: {}".format(e))

    def _set_cw_color(self, color_str):
        try:
            if hasattr(self["cw_value"], "instance") and self["cw_value"].instance:
                self["cw_value"].instance.setForegroundColor(parseColor(color_str))
        except Exception:
            pass

    def _load_pixmap(self, widget_name, filename):
        try:
            path = os.path.join(PLUGIN_PATH, "images", filename)
            widget = self[widget_name]
            if hasattr(widget, "setPixmapFromFile"):
                widget.setPixmapFromFile(path)
            elif hasattr(widget, "instance") and hasattr(widget.instance, "setPixmapFromFile"):
                widget.instance.setPixmapFromFile(path)
        except Exception:
            pass

    def _do_force_decrypt(self):
        """OK button — force CW re-decrypt of current channel."""
        log_debug("FORCE DECRYPT pressed")
        if _background_service:
            _background_service.force_update_current()
            self.session.open(
                MessageBox,
                "AutoBiss: Searching CW key...",
                MessageBox.TYPE_INFO,
                timeout=2,
            )
        else:
            self.session.open(
                MessageBox,
                "AutoBiss: Background service not running",
                MessageBox.TYPE_ERROR,
                timeout=3,
            )

    def _do_plugin_update(self):
        """GREEN button — check for and install plugin update from VPS."""
        log_debug("PLUGIN UPDATE button pressed")

        def _on_update_done(new_version):
            try:
                self.session.open(
                    MessageBox,
                    "AutoBiss updated to v{}!\nRestart receiver to apply.".format(new_version),
                    MessageBox.TYPE_INFO,
                    timeout=10,
                )
            except Exception:
                pass

        started = False
        try:
            from Plugins.Extensions.AutoBiss.updater import check_and_apply_update
            check_and_apply_update(callback=_on_update_done)
            started = True
        except Exception as e:
            log_debug("Plugin update launch error: {}".format(e))

        self.session.open(
            MessageBox,
            "AutoBiss: Checking for updates...\nInstalled: v{}".format(_PLUGIN_VERSION)
            if started else "AutoBiss: Updater not available",
            MessageBox.TYPE_INFO,
            timeout=3,
        )

    def _do_about(self):
        log_debug("ABOUT button pressed")
        self.session.open(AutoBissInfoScreen)

    def close(self):
        self._update_timer.stop()
        Screen.close(self)


# ------------------------------------------------------------------------------
# AutoBiss Info Screen (Read-only settings display)
# ------------------------------------------------------------------------------
class AutoBissInfoScreen(Screen):
    skin = """
    <screen name="AutoBissInfoScreen" position="center,center" size="640,400" title="AutoBiss Info">

        <widget name="title" position="20,12" size="600,40" font="Regular;26" halign="center" foregroundColor="#ffffff" />

        <ePixmap position="0,60" size="640,2" pixmap="skin_default/div-h.png" />

        <widget name="vps_url"    position="20,70"  size="600,26" font="Regular;18" foregroundColor="#cccccc" />
        <widget name="api_key"    position="20,100" size="600,26" font="Regular;18" foregroundColor="#cccccc" />
        <widget name="record_dur" position="20,130" size="600,26" font="Regular;18" foregroundColor="#cccccc" />
        <widget name="cooldown"   position="20,160" size="600,26" font="Regular;18" foregroundColor="#cccccc" />
        <widget name="version"    position="20,190" size="600,26" font="Regular;18" foregroundColor="#cccccc" />

        <ePixmap position="0,224" size="640,2" pixmap="skin_default/div-h.png" />

        <widget name="status"  position="20,231" size="600,28" font="Regular;19" foregroundColor="#00ff88" />

        <ePixmap position="0,268" size="640,2" pixmap="skin_default/div-h.png" />

        <widget name="credits_by"    position="20,278" size="600,24" font="Regular;16" halign="center" foregroundColor="#aaaaaa" />
        <widget name="credits_names" position="20,305" size="600,34" font="Bold;22"    halign="center" foregroundColor="#ffd700" />

        <ePixmap position="0,350" size="640,2" pixmap="skin_default/div-h.png" />

        <widget name="btn_exit" position="225,358" size="190,36" font="Regular;20" halign="center" foregroundColor="#ff3333" />

    </screen>
    """

    def __init__(self, session):
        self.skin = AutoBissInfoScreen.skin
        Screen.__init__(self, session)
        self.session = session
        self.title = "AutoBiss Info"

        self["title"]         = Label("AutoBiss Configuration")
        self["vps_url"]       = Label("  VPS URL:    [Hidden]")
        self["api_key"]       = Label("  API Key:    ••••••••••••••••")
        self["record_dur"]    = Label("  Record:     1 second per sample")
        self["cooldown"]      = Label("  Cooldown:   60 seconds per channel")
        self["version"]       = Label("  Version:    {}".format(_PLUGIN_VERSION))
        self["credits_by"]    = Label("Developed by")
        self["credits_names"] = Label("Kingcs  ·  prof-abdo  ·  abed1988")
        self["btn_exit"]      = Label("Exit")

        global _vps_unreachable
        if _vps_unreachable:
            self["status"] = Label("VPS Status:  UNREACHABLE — Maintenance mode")
        else:
            self["status"] = Label("VPS Status:  Online")

        try:
            self["actions"] = ActionMap(
                ["ColorActions", "SetupActions"],
                {
                    "red":    self.close,
                    "cancel": self.close,
                    "ok":     self.close,
                },
                -2,
            )
        except Exception:
            self["actions"] = ActionMap(
                ["SetupActions"],
                {
                    "cancel": self.close,
                    "ok":     self.close,
                },
                -2,
            )

    def close(self):
        Screen.close(self)


# ------------------------------------------------------------------------------
# Key Screen (Kept as secondary/backup)
# ------------------------------------------------------------------------------
class AutoBissKeyScreen(Screen):
    skin = """
    <screen name="AutoBissKeyScreen" position="center,center" size="620,300" title="AutoBiss E2 - Current Key">
        <widget name="service" position="10,10" size="600,30" font="Regular;22" halign="center" />
        <widget name="status" position="10,50" size="600,30" font="Regular;20" halign="center" foregroundColor="#ffff00" />
        <widget name="cw_label" position="10,100" size="200,30" font="Regular;20" halign="right" />
        <widget name="cw_value" position="220,100" size="380,30" font="Regular;20" halign="left" foregroundColor="#0f0" />
        <widget name="hint" position="10,240" size="600,40" font="Regular;18" halign="center" />
    </screen>
    """

    def __init__(self, session, service=None):
        self.skin = AutoBissKeyScreen.skin
        Screen.__init__(self, session)
        self.title = "AutoBiss E2 - Current Key"
        self.session = session
        self["service"] = Label("No service")
        self["status"] = Label("No BISS channel detected")
        self["cw_label"] = Label("BISS CW:")
        self["cw_value"] = Label("Unknown")
        self["hint"] = Label("Tune to a BISS channel. AutoBiss records automatically in background.")
        self["actions"] = ActionMap(
            ["SetupActions"],
            {
                "cancel": self.close,
                "ok": self.close,
            },
            -2,
        )
        self._update_timer = eTimer()
        self._update_timer.callback.append(self._update_display)
        self._update_timer.start(1000, False)
        self._update_display()

    def _update_display(self):
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not ref:
                return
            service = self.session.nav.getCurrentService()
            if not service:
                return
            info = service.info()
            if not info:
                return
            sname = info.getName() if info else "Unknown"
            self["service"].setText(sname)
            caids = info.getInfoObject(iServiceInformation.sCAIDs)
            if caids and BISS_CAID in list(caids):
                sid = info.getInfo(iServiceInformation.sSID)
                global _vps_unreachable
                if _vps_unreachable:
                    self["status"].setText("Maintenance is running")
                    self["cw_value"].setText("VPS unreachable")
                else:
                    cw = _get_cached_cw(sid)
                    if cw:
                        self["status"].setText("BISS DECRYPTED | SID: 0x{:04X}".format(sid))
                        self["cw_value"].setText(format_cw_for_display(cw))
                    else:
                        self["status"].setText("BISS encrypted | SID: 0x{:04X}".format(sid))
                        self["cw_value"].setText("Searching...")
            else:
                self["status"].setText("Current channel is not BISS encrypted")
                self["cw_value"].setText("N/A")
        except Exception as e:
            log_debug("KeyScreen update exception: {}".format(e))

    def close(self):
        self._update_timer.stop()
        Screen.close(self)


# ------------------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------------------
_background_service = None
_latest_ts_by_sid = {}
_vps_unreachable = False

def _get_cached_cw(sid):
    if _background_service:
        return _background_service.cw_cache.get(sid)
    return None

# ------------------------------------------------------------------------------
# Plugin Entry Points
# ------------------------------------------------------------------------------
def autobiss_start(session, **kwargs):
    global _background_service
    # If WHERE_SESSIONSTART never fired (e.g. after a broken install), create on demand
    if _background_service is None:
        try:
            log_debug("autobiss_start: background service missing, creating on demand")
            _background_service = AutoBissBackgroundService(session)
        except Exception as e:
            log_debug("autobiss_start: on-demand service creation failed: {}".format(e))
    session.open(AutoBissMainScreen)

def autobiss_session_start(reason, session=None):
    if reason == 0 and session is not None:
        log_debug("autobiss_session_start: creating background service")
        global _background_service
        _background_service = AutoBissBackgroundService(session)

def Plugins(**kwargs):
    log_debug("Plugins() registering descriptors")
    descs = []
    # WHERE_PLUGINBROWSER = appears in Menu -> Plugins (not all images have it)
    _where_browser = getattr(PluginDescriptor, 'WHERE_PLUGINBROWSER', None)
    if _where_browser is not None:
        descs.append(PluginDescriptor(
            name="AutoBiss E2",
            description="AutoBiss Professional BISS Interface",
            where=_where_browser,
            fnc=autobiss_start,
        ))
    descs.append(PluginDescriptor(
        name="AutoBiss E2",
        description="AutoBiss Professional BISS Interface",
        where=PluginDescriptor.WHERE_EXTENSIONSMENU,
        fnc=autobiss_start,
    ))
    descs.append(PluginDescriptor(
        name="AutoBiss E2",
        description="AutoBiss background BISS recorder",
        where=PluginDescriptor.WHERE_SESSIONSTART,
        fnc=autobiss_session_start,
    ))
    return descs
