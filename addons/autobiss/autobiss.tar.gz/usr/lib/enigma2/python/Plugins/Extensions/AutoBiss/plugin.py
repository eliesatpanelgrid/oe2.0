# -*- coding: utf-8 -*-
"""
AutoBiss E2 - Enigma2 Plugin vv3.0
Real-time BISS key finder &amp; softcam injector
Professional interface with VPS decryption
Compatible with Python 2.7 and Python 3.x
"""
from __future__ import absolute_import, print_function, division

# CRITICAL: Import error trap - if anything below fails, we log it
import traceback
import os
import sys

# Try to set up logging first
_DEBUG_PATH = '/tmp/autobiss_debug.log'
def _safe_log(msg):
    try:
        from time import strftime
        with open(_DEBUG_PATH, 'a') as f:
            f.write("[{}] [plugin] {}\n".format(strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass

_safe_log("=" * 60)
_safe_log("plugin.py module starting import...")

# CRITICAL: PluginDescriptor must import or Enigma2 will crash at plugin init
try:
    from Plugins.Plugin import PluginDescriptor
    _safe_log("PluginDescriptor imported OK")
except Exception as e:
    _safe_log("FATAL PluginDescriptor import: {}".format(e))
    raise

# Screen - also critical but can be stubbed if fails
try:
    from Screens.Screen import Screen
except Exception:
    Screen = type('Screen', (), {'__init__': lambda s, *a, **k: None})

# MessageBox
try:
    from Screens.MessageBox import MessageBox
except Exception:
    MessageBox = type('MessageBox', (), {'TYPE_INFO': 0, 'TYPE_ERROR': 1})

# ActionMap
try:
    from Components.ActionMap import ActionMap
except Exception:
    ActionMap = type('ActionMap', (), {'__init__': lambda s, *a, **k: None})

# Label
try:
    from Components.Label import Label
except Exception:
    Label = type('Label', (), {'__init__': lambda s, *a, **k: None, 'setText': lambda s, *a, **k: None})

# Pixmap
try:
    from Components.Pixmap import Pixmap
except Exception:
    Pixmap = type('Pixmap', (), {'__init__': lambda s, *a, **k: None, 'setPixmap': lambda s, *a, **k: None})

# ServiceEventTracker
try:
    from Components.ServiceEventTracker import ServiceEventTracker
except Exception:
    ServiceEventTracker = type('ServiceEventTracker', (), {})

# MenuList (for the Control Center menu)
try:
    from Components.MenuList import MenuList
except Exception:
    _safe_log("WARNING: MenuList not available, using Label fallback")
    MenuList = None

# enigma C++ bindings - import each individually for compatibility
try:
    from enigma import eTimer
except Exception:
    _safe_log("WARNING: eTimer not available, using stub")
    eTimer = type('eTimer', (), {'start': lambda s, *a, **k: None, 'stop': lambda s: None, 'callback': type('cb', (), {'append': lambda s, *a, **k: None})()})

try:
    from enigma import iPlayableService
except Exception:
    _safe_log("WARNING: iPlayableService not available, using stub")
    iPlayableService = type('iPlayableService', (), {'evStart': 0, 'evUpdatedInfo': 1})

try:
    from enigma import iServiceInformation
except Exception:
    _safe_log("WARNING: iServiceInformation not available, using stub")
    iServiceInformation = type('iServiceInformation', (), {})

# Some enigma2 builds lack certain iServiceInformation constants
_MISSING_SVC = [('sSID', 3), ('sCAIDs', 15), ('sVideoPID', 6), ('sAudioPID', 7)]
for _name, _val in _MISSING_SVC:
    if not hasattr(iServiceInformation, _name):
        setattr(iServiceInformation, _name, _val)
        _safe_log("WARNING: iServiceInformation.{} missing, using fallback value 0x{:X}".format(_name, _val))

try:
    from enigma import parseColor
except Exception:
    _safe_log("WARNING: parseColor not available, using stub")
    parseColor = lambda c, *a: 0x00ffffff

try:
    from enigma import loadPNG
except Exception:
    _safe_log("WARNING: loadPNG not available, button focus effect disabled")
    loadPNG = None

# Real color parser from Enigma2 skin engine (the enigma-module parseColor
# stub above always returns white on old images — skin.parseColor is real).
try:
    from skin import parseColor as _skin_parseColor
except Exception:
    _skin_parseColor = None

def _parse_color(s, default=0x00ffffff):
    try:
        if _skin_parseColor is not None:
            return _skin_parseColor(s)
    except Exception:
        pass
    try:
        return parseColor(s)
    except Exception:
        return default

from time import time, strftime
import re
from threading import Timer

# Import our modules
# CRITICAL: fallback log_debug in case biss_engine import fails
def log_debug(msg):
    _safe_log(msg)

# Fallbacks for settings helpers (overwritten by real imports below)
_FB_DEFAULTS = {"softcam_path": "auto", "record_duration": 1,
                "cooldown": 60, "notifications": True}
_FB_CANDIDATES = ["/etc/tuxbox/config/SoftCam.Key",
                  "/etc/tuxbox/config/oscam/SoftCam.Key",
                  "/usr/keys/SoftCam.Key",
                  "/etc/SoftCam.Key"]
def _fb_load_settings():
    return dict(_FB_DEFAULTS)
def _fb_save_settings(cfg):
    return False
def _fb_get_softcam_path(cfg=None):
    return "/etc/tuxbox/config/SoftCam.Key"
def _fb_remove_autobiss_keys():
    return 0
load_settings = _fb_load_settings
save_settings = _fb_save_settings
get_softcam_path = _fb_get_softcam_path
remove_autobiss_keys = _fb_remove_autobiss_keys
SOFTCAM_CANDIDATES = _FB_CANDIDATES
DEFAULT_SETTINGS = _FB_DEFAULTS

# Notifier — non-blocking NotificationPopup with MessageBox fallback
try:
    from Plugins.Extensions.AutoBiss.notifier import (
        set_enabled as _notif_set_enabled,
        is_enabled as _notif_is_enabled,
        info as _notif_info,
        warning as _notif_warning,
        error as _notif_error,
    )
    _safe_log("Notifier imported OK")
except Exception as e:
    _safe_log("Notifier import skipped: {}".format(e))
    def _notif_set_enabled(flag):
        pass
    def _notif_is_enabled():
        return True
    def _notif_info(session, text, title="AutoBiss", timeout=4):
        return False
    def _notif_warning(session, text, title="AutoBiss", timeout=5):
        return False
    def _notif_error(session, text, title="AutoBiss", timeout=6):
        return False

try:
    from Plugins.Extensions.AutoBiss.key_analyzer import write_service_info
    from Plugins.Extensions.AutoBiss.biss_engine import (
        CWCache, parse_ecm_info, get_global_cwl,
        run_tsdec_extract_cw, write_softcam_key, write_ecm_info,
        cleanup_recording_sidecars, reload_softcam,
        get_ecm_pid, format_cw_for_display, BISS_CAID, OUTPUT_DIR, log_debug,
        decrypt_via_vps, load_settings, save_settings, get_softcam_path,
        remove_autobiss_keys, SOFTCAM_CANDIDATES, DEFAULT_SETTINGS,
    )
    _safe_log("AutoBiss modules imported OK")
except Exception as e:
    _safe_log("ERROR importing AutoBiss modules: {}".format(e))
    _safe_log(traceback.format_exc())

# --- vv3.0 full screen layout -----------------------------------------------
FS_W, FS_H = 1920, 1080
FS_BG = "#070b12"
FS_PANEL = "#0f1622"
FS_PANEL2 = "#141d2b"
FS_DIV = "#1e2a3a"
FS_TEXT = "#ffffff"
FS_DIM = "#7d8da5"
FS_CYAN = "#00e5ff"
FS_GREEN = "#3fb950"
FS_RED = "#f85149"
FS_ORANGE = "#f0883e"
FS_YELLOW = "#d29922"
FS_BLUE = "#58a6ff"
FS_PINK = "#f778ba"
FS_PURPLE = "#bc8cff"

# Shared full screen skin fragments -------------------------------------------
# NOTE: Enigma2 paints every <widget> label above <eLabel>/<ePixmap> elements,
# and the active skin gives labels a default background. So the whole static
# chrome lives in images/ui_bg.png and every text widget repeats the exact fill
# colour of the panel it sits on.
_FS_IMG = "/usr/lib/enigma2/python/Plugins/Extensions/AutoBiss/images/"

_FS_BG = '<ePixmap position="0,0" size="1920,1080" pixmap="' + _FS_IMG + 'ui_bg.png" alphatest="blend" />'

_FS_HEADER = """
        <ePixmap position="78,36" size="48,48" pixmap="__IMG__logo48.png" alphatest="blend" />
        <widget name="hdr_site"    position="140,36"  size="400,56" font="Bold;30" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1330" />
        <widget name="hdr_sep"     position="552,50"  size="2,32"   backgroundColor="#1c3c6b" />
        <widget name="hdr_vps"     position="572,42"  size="260,48" font="Regular;22" halign="left" foregroundColor="#4ade80" backgroundColor="#0a1330" />
        <widget name="hdr_version" position="852,44"  size="300,44" font="Regular;20" halign="left" foregroundColor="#35c8f0" backgroundColor="#0a1330" />
        <widget name="hdr_clock"   position="1480,26" size="360,56" font="Bold;44" halign="right" foregroundColor="#ffffff" backgroundColor="#0a1330" />
        <widget name="hdr_date"    position="1380,84" size="460,24" font="Regular;18" halign="right" foregroundColor="#35c8f0" backgroundColor="#0a1330" />
"""

_FS_SECTION = """
        <ePixmap position="84,160" size="36,36" pixmap="__IMG__ic_list.png" alphatest="blend" />
        <widget name="sec_left"  position="132,158" size="740,40" font="Bold;24" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1330" />
        <ePixmap position="944,160" size="36,36" pixmap="__IMG__ic_eye.png" alphatest="blend" />
        <widget name="sec_right" position="992,158" size="840,40" font="Bold;24" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1330" />
"""

_FS_FOOTER = """
        <ePixmap position="60,1006" size="40,40" pixmap="__IMG__ic_info.png" alphatest="blend" />
        <widget name="act0" position="108,1010" size="180,34" font="Bold;20" halign="left" foregroundColor="#ffffff" backgroundColor="#040a12" />
        <ePixmap position="317,1006" size="40,40" pixmap="__IMG__ic_dpad.png" alphatest="blend" />
        <widget name="act1" position="365,1010" size="180,34" font="Bold;20" halign="left" foregroundColor="#ffffff" backgroundColor="#040a12" />
        <ePixmap position="574,1006" size="40,40" pixmap="__IMG__ic_ok.png" alphatest="blend" />
        <widget name="act2" position="622,1010" size="180,34" font="Bold;20" halign="left" foregroundColor="#ffffff" backgroundColor="#040a12" />
        <ePixmap position="831,1006" size="40,40" pixmap="__IMG__ic_menu.png" alphatest="blend" />
        <widget name="act3" position="879,1010" size="180,34" font="Bold;20" halign="left" foregroundColor="#ffffff" backgroundColor="#040a12" />
        <ePixmap position="1088,1006" size="40,40" pixmap="__IMG__ic_search.png" alphatest="blend" />
        <widget name="act4" position="1136,1010" size="180,34" font="Bold;20" halign="left" foregroundColor="#f5a623" backgroundColor="#040a12" />
        <ePixmap position="1345,1006" size="40,40" pixmap="__IMG__ic_zap.png" alphatest="blend" />
        <widget name="act5" position="1393,1010" size="180,34" font="Bold;20" halign="left" foregroundColor="#4ade80" backgroundColor="#040a12" />
        <ePixmap position="1602,1006" size="40,40" pixmap="__IMG__ic_power.png" alphatest="blend" />
        <widget name="act6" position="1650,1010" size="180,34" font="Bold;20" halign="left" foregroundColor="#f85149" backgroundColor="#040a12" />
"""

_FS_RIGHT_META = """
        <widget name="meta_icon1"  position="960,800"  size="34,34" backgroundColor="#0d1a2c" />
        <ePixmap position="962,802" size="34,34" pixmap="__IMG__ic_monitor.png" alphatest="blend" />
        <widget name="meta1"       position="1004,800" size="216,38" font="Regular;18" halign="left" foregroundColor="#ffffff" backgroundColor="#0d1a2c" />
        <ePixmap position="1246,802" size="34,34" pixmap="__IMG__ic_palette.png" alphatest="blend" />
        <widget name="meta2"       position="1288,800" size="222,38" font="Regular;18" halign="left" foregroundColor="#ffffff" backgroundColor="#0d1a2c" />
        <ePixmap position="1536,802" size="34,34" pixmap="__IMG__ic_clock.png" alphatest="blend" />
        <widget name="meta3"       position="1578,800" size="252,38" font="Regular;18" halign="left" foregroundColor="#ffffff" backgroundColor="#0d1a2c" />
        <ePixmap position="962,876" size="34,34" pixmap="__IMG__ic_sat.png" alphatest="blend" />
        <widget name="meta4"       position="1004,874" size="216,38" font="Regular;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0d1a2c" />
        <ePixmap position="1246,876" size="34,34" pixmap="__IMG__ic_eye.png" alphatest="blend" />
        <widget name="meta5"       position="1288,874" size="222,38" font="Regular;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0d1a2c" />
        <ePixmap position="1536,876" size="34,34" pixmap="__IMG__ic_key.png" alphatest="blend" />
        <widget name="meta6"       position="1578,874" size="252,38" font="Regular;18" halign="left" foregroundColor="#4ade80" backgroundColor="#0d1a2c" />
"""


# Live channel preview: the active skin (Aglare) renders the running channel
# into a widget through its "Pig" renderer. When that renderer is not
# available we fall back to the framework PiP window instead.
_PIG_VIDEO = (
    '<widget source="session.VideoPicture" render="Pig" '
    'position="940,238" size="900,518" zPosition="20" '
    'backgroundColor="transparent" transparent="0" />'
)
_PIP_FALLBACK_VIDEO = (
    '<widget name="pip_bezel" position="940,238" size="900,518" '
    'foregroundColor="#1c3c6b" borderColor="#1c3c6b" borderWidth="2" />'
)

_FS_PIP = """
        %VIDEO%
        <widget name="pip_live"   position="964,258" size="110,40" font="Bold;20" halign="center" foregroundColor="#ffffff" backgroundColor="#b02a20" zPosition="21" />
        <widget name="pip_channel"  position="956,664" size="868,46" font="Bold;28" halign="left" valign="bottom" foregroundColor="#ffffff" backgroundColor="#000000" zPosition="21" />
        <widget name="pip_provider" position="956,712" size="868,36" font="Regular;18" halign="left" valign="top" foregroundColor="#9aa7bd" backgroundColor="#000000" zPosition="21" />
""" + _FS_RIGHT_META

_pig_renderer = None


def _has_pig_renderer():
    """True when the active skin provides the "Pig" video widget renderer."""
    global _pig_renderer
    if _pig_renderer is None:
        _pig_renderer = False
        try:
            import os as _os
            from Components.config import config
            from Tools.Directories import SCOPE_SKINS, resolveFilename
            skin_file = config.skin.primary_skin.value
            path = resolveFilename(SCOPE_SKINS, skin_file)
            if path and _os.path.exists(path):
                with open(path, "r", errors="ignore") as fh:
                    _pig_renderer = "Pig" in fh.read()
        except Exception as e:
            log_debug("Pig renderer probe failed: {}".format(e))
    return _pig_renderer


def _lift_labels(skin):
    """Put every <widget> above the background/decorative ePixmap layer.

    Enigma2 paints <eLabel>/<ePixmap> elements after the regular widgets, so a
    full screen background image would hide every label. Giving the widgets a
    higher zPosition restores the correct stacking.
    """
    try:
        def _fix(match):
            tag = match.group(0)
            if "zPosition" in tag:
                return tag
            return tag[:-2].rstrip() + ' zPosition="2" />'
        return re.sub(r"<widget\b[^>]*/>", _fix, skin)
    except Exception as e:
        log_debug("label lift error: {}".format(e))
        return skin


def _render_skin(template):
    """Fill the image/video placeholders in a skin template."""
    try:
        video = _PIG_VIDEO if _has_pig_renderer() else _PIP_FALLBACK_VIDEO
        return _lift_labels(
            template.replace("__IMG__", _FS_IMG).replace("%VIDEO%", video))
    except Exception as e:
        log_debug("skin render error: {}".format(e))
        return _lift_labels(template.replace("__IMG__", _FS_IMG))


def _init_header(screen, interval=1000):
    """Header bar widgets: website, VPS state, version, clock and date."""
    try:
        screen["hdr_site"] = Label("AutoBiss E2")
        screen["hdr_sep"] = Label("")
        screen["hdr_vps"] = Label("VPS:  OFFLINE")
        screen["hdr_version"] = Label("v{}".format(_PLUGIN_VERSION))
        screen["hdr_clock"] = Label("")
        screen["hdr_date"] = Label("")
        _tick_clock(screen)
        timer = eTimer()
        timer.callback.append(lambda: _tick_clock(screen))
        timer.start(interval, True)
        return timer
    except Exception as e:
        log_debug("header init error: {}".format(e))
        return None


def _tick_clock(screen):
    """Refresh the header clock/date and the VPS state badge."""
    try:
        import time as _t
        screen["hdr_clock"].setText(_t.strftime("%H:%M"))
        screen["hdr_date"].setText(_t.strftime("%A, %d %b %Y"))
    except Exception:
        pass
    try:
        if _vps_unreachable:
            screen["hdr_vps"].setText("VPS:  OFFLINE")
            screen["hdr_vps"].instance.setForegroundColor(_parse_color("#f85149"))
        else:
            screen["hdr_vps"].setText("VPS:  ONLINE")
            screen["hdr_vps"].instance.setForegroundColor(_parse_color("#4ade80"))
    except Exception:
        pass


def _init_footer(screen, labels):
    """Bottom action bar labels (icon images come from the skin)."""
    for i, txt in enumerate(labels):
        try:
            screen["act{}".format(i)] = Label(txt)
        except Exception:
            pass


def _init_pip_panel(screen, interval=2000):
    """Create the right-hand live channel widgets and keep them refreshed."""
    try:
        screen["pip_live"] = Label("LIVE")
        screen["pip_channel"] = Label("---")
        screen["pip_provider"] = Label("")
        for i in range(1, 7):
            screen["meta{}".format(i)] = Label("")
    except Exception as e:
        log_debug("PiP panel init error: {}".format(e))
    try:
        screen["pip_bezel"] = Label("")
    except Exception:
        pass
    try:
        timer = eTimer()
        timer.callback.append(lambda: _fill_pip_panel(screen))
        timer.start(interval, True)
        return timer
    except Exception as e:
        log_debug("PiP panel timer error: {}".format(e))
        return None


def _pip_show(session):
    """Move the running channel into the PiP mini window.

    Returns the saved service reference when PiP was opened by us,
    otherwise None. Never raises.
    """
    try:
        if session is None:
            return None
        if getattr(session, "pipshown", False):
            return None
        ref = session.nav.getCurrentlyPlayingServiceOrGroup()
        if not ref:
            return None
        from Screens.InfoBar import InfoBar
        ib = InfoBar.instance
        if ib is None or not hasattr(ib, "showPiP"):
            return None
        ib.showPiP()
        return ref
    except Exception as e:
        log_debug("PiP show error: {}".format(e))
        return None


def _pip_restore(session, ref):
    """Bring the running channel back to full screen."""
    try:
        if session is None or ref is None:
            return
        if getattr(session, "pipshown", False):
            session.nav.playService(ref)
    except Exception as e:
        log_debug("PiP restore error: {}".format(e))


def _fill_pip_panel(screen):
    """Refresh the right-hand live channel panel + meta card."""
    try:
        if not hasattr(screen, "session"):
            return
        service = screen.session.nav.getCurrentService()
        if not service:
            return
        info = service.info()
        if not info:
            return
        screen["pip_channel"].setText(info.getName() or "---")
        try:
            screen["pip_provider"].setText(
                "{}  {}".format(
                    info.getProvider() or "", info.getTransponderLocation() or ""
                ).strip()
            )
        except Exception:
            screen["pip_provider"].setText("")
        caids = info.getInfoObject(iServiceInformation.sCAIDs)
        if caids and BISS_CAID in list(caids):
            sid = info.getInfo(iServiceInformation.sSID)
            vpid = info.getInfo(iServiceInformation.sVideoPID)
            apid = info.getInfo(iServiceInformation.sAudioPID)
            cw = _get_cached_cw(sid)
            cw_txt = "BISS " + (cw[:8] if cw else
                                ("VPS offline" if _vps_unreachable else "searching"))
            screen["meta1"].setText("SID {:04X} / VPID {:04X}".format(sid, vpid))
            screen["meta2"].setText("BISS · APID {:04X}".format(apid))
            screen["meta3"].setText("")
            screen["meta4"].setText("")
            screen["meta5"].setText("")
            screen["meta6"].setText(cw_txt)
            _set_fg(screen, "meta6", "#4ade80" if cw else "#f5a623")
        else:
            enc_type = _detect_encryption_type(info) if caids else "FTA"
            screen["meta1"].setText(
                "CAIDs {}".format(
                    " ".join("0x{:04X}".format(c) for c in list(caids)[:2])) if caids else "no CAIDs")
            screen["meta2"].setText(enc_type)
            screen["meta3"].setText("")
            screen["meta4"].setText("")
            screen["meta5"].setText("")
            screen["meta6"].setText("not a BISS channel")
            _set_fg(screen, "meta6", "#8fa6c8")
    except Exception as e:
        log_debug("PiP panel error: {}".format(e))


def _set_fg(screen, name, color):
    """Set a widget's foreground colour, ignoring skins that lack parseColor."""
    try:
        inst = screen[name].instance
        if inst:
            inst.setForegroundColor(_parse_color(color))
    except Exception:
        pass


# Updater — optional, never crashes the plugin if missing
_PLUGIN_VERSION    = "v3.0"
_check_for_update  = None
try:
    from Plugins.Extensions.AutoBiss.updater import (
        VERSION as _PLUGIN_VERSION,
        check_and_apply_update as _check_for_update,
    )
    _safe_log("Updater imported OK — current v{}".format(_PLUGIN_VERSION))
except Exception as e:
    _safe_log("Updater import skipped: {}".format(e))

# Device registration — optional, never crashes the plugin if missing
_device_is_registered = None
_device_register      = None
try:
    from Plugins.Extensions.AutoBiss.device import (
        is_registered as _device_is_registered,
        register      as _device_register,
    )
    _safe_log("Device module imported OK")
except Exception as e:
    _safe_log("Device module import skipped: {}".format(e))

# ------------------------------------------------------------------------------
# Plugin paths
# ------------------------------------------------------------------------------
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/AutoBiss"



# ------------------------------------------------------------------------------
# Utility Functions
# ------------------------------------------------------------------------------
def sanitize_filename(name):
    if name is None:
        return "Unknown"
    clean = re.sub(r'[^\w\s\-]', '_', name)
    clean = re.sub(r'\s+', '_', clean)
    return clean.strip('_')

def get_unique_filepath(base_path):
    if not os.path.exists(base_path):
        return base_path
    directory = os.path.dirname(base_path)
    filename = os.path.basename(base_path)
    name, ext = os.path.splitext(filename)
    counter = 1
    while True:
        new_name = "{}_{}{}".format(name, counter, ext)
        new_path = os.path.join(directory, new_name)
        if not os.path.exists(new_path):
            return new_path
        counter += 1
        if counter > 999:
            break
    return base_path

def ensure_dir(path):
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
            log_debug("Created directory: {}".format(path))
        except Exception as e:
            log_debug("Failed to create directory {}: {}".format(path, e))

def _find_writable_storage(min_free_mb=50):
    """Find writable storage path for TS recordings.

    Requires >= min_free_mb free (statvfs) so tiny tmpfs mounts
    like an unmounted /media/hdd are rejected instead of causing
    'Disque plein' recording errors.
    """
    candidates = [
        "/media/hdd/movie",
        "/media/hdd",
        "/media/usb/movie",
        "/media/usb",
        "/media/usb1",
        "/media/usb2",
        "/media/usb3",
        "/media/ssd",
        "/data/movie",
        "/data",
        "/hdd",
    ]
    for path in candidates:
        if not os.path.isdir(path):
            continue
        try:
            st = os.statvfs(path)
            free_mb = (st.f_bavail * st.f_frsize) // (1024 * 1024)
            if free_mb < min_free_mb:
                log_debug("Storage {} skipped: only {} MB free".format(path, free_mb))
                continue
        except Exception as e:
            log_debug("Storage statvfs failed for {}: {}".format(path, e))
            continue
        test_file = os.path.join(path, ".autobiss_test")
        try:
            with open(test_file, "w") as f:
                f.write("test")
            os.remove(test_file)
            log_debug("Writable storage found: {} ({} MB free)".format(path, free_mb))
            return path
        except Exception:
            continue
    log_debug("No writable storage found!")
    return None

def _detect_softcam():
    """Check if oscam or ncam process is running.

    Substring match (-f): binaries are often named oscam-emu,
    oscam-master, ncam.vusolo4k, ... which 'pgrep -x' misses.
    """
    for name in ('oscam', 'ncam'):
        try:
            import subprocess
            proc = subprocess.Popen(['pgrep', '-f', name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = proc.communicate(timeout=3)
            if hasattr(stdout, 'decode'):
                stdout = stdout.decode('utf-8', 'replace')
            pids = stdout.strip().split('\n') if stdout else []
            pids = [p for p in pids if p.strip()]
            if pids:
                log_debug("Softcam detected: {} (pids {})".format(name, ",".join(pids)))
                return name
        except Exception as e:
            log_debug("Softcam detection error for {}: {}".format(name, e))
    # Fallback: scan /proc cmdlines directly (no pgrep dependency)
    try:
        for pid in os.listdir('/proc'):
            if not pid.isdigit():
                continue
            try:
                with open('/proc/{}/cmdline'.format(pid), 'rb') as f:
                    raw = f.read().replace(b'\x00', b' ').decode('utf-8', 'replace').lower()
            except Exception:
                continue
            if 'oscam' in raw:
                log_debug("Softcam detected via /proc: oscam")
                return 'oscam'
            if 'ncam' in raw:
                log_debug("Softcam detected via /proc: ncam")
                return 'ncam'
    except Exception as e:
        log_debug("Softcam /proc scan error: {}".format(e))
    log_debug("No softcam detected")
    return None

# ------------------------------------------------------------------------------
# tsdec Binary Architecture Management
# ------------------------------------------------------------------------------
ARCH_MAP = {
    'mips': 'mipsel',
    'mipsel': 'mipsel',
    'aarch64': 'aarch64',
    'armv7l': 'armv7l',
    'armv7': 'armv7l',
    'armv6l': 'armv7l',
}

def _detect_arch():
    """Detect receiver CPU architecture from /proc/cpuinfo or uname."""
    try:
        with open('/proc/cpuinfo', 'r') as f:
            cpuinfo = f.read().lower()
        if 'mips' in cpuinfo:
            return 'mipsel'
        if 'aarch64' in cpuinfo:
            return 'aarch64'
        if 'armv7' in cpuinfo or 'cortex' in cpuinfo:
            return 'armv7l'
        if 'armv6' in cpuinfo:
            return 'armv7l'
    except Exception:
        pass
    # Fallback to uname
    try:
        import subprocess
        proc = subprocess.Popen(['uname', '-m'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, _ = proc.communicate(timeout=2)
        if hasattr(stdout, 'decode'):
            stdout = stdout.decode('utf-8', 'replace')
        arch = stdout.strip().lower()
        return ARCH_MAP.get(arch, arch)
    except Exception:
        return 'unknown'

def _get_tsdec_binary():
    """Find or download tsdec binary matching receiver architecture."""
    arch = _detect_arch()
    bin_name = 'tsdec-{}'.format(arch)
    bin_dir = os.path.join(PLUGIN_PATH, 'bin')
    bin_path = os.path.join(bin_dir, bin_name)
    
    if os.path.isfile(bin_path):
        try:
            os.chmod(bin_path, 0o755)
        except Exception:
            pass
        log_debug("Local tsdec found: {}".format(bin_path))
        return bin_path
    
    # Try to download from VPS
    log_debug("Downloading tsdec binary for arch: {}".format(arch))
    try:
        ensure_dir(bin_dir)
        if sys.version_info[0] >= 3:
            import urllib.request as urllib2
        else:
            import urllib2
        url = 'https://tsdec.kingcs.xyz/autobiss/bin/{}'.format(arch)
        req = urllib2.Request(url)
        import ssl
        try:
            ctx = ssl.create_default_context()
        except Exception:
            ctx = ssl._create_unverified_context()
        try:
            resp = urllib2.urlopen(req, context=ctx, timeout=30)
        except TypeError:
            resp = urllib2.urlopen(req, timeout=30)
        data = resp.read()
        with open(bin_path, 'wb') as f:
            f.write(data)
        os.chmod(bin_path, 0o755)
        log_debug("Downloaded tsdec binary: {} ({} bytes)".format(bin_name, len(data)))
        return bin_path
    except Exception as e:
        log_debug("Failed to download tsdec binary: {}".format(e))
        return None

# ------------------------------------------------------------------------------
# Import RecordTimer
# ------------------------------------------------------------------------------
_RECORDTIMER_AVAILABLE = False
try:
    from RecordTimer import RecordTimerEntry, AFTEREVENT
    from Navigation import NavigationInstance
    from ServiceReference import ServiceReference as SvcRef
    _RECORDTIMER_AVAILABLE = True
    log_debug("RecordTimer modules imported OK")
except Exception as e:
    log_debug("ERROR importing RecordTimer modules: {}".format(e))

# ------------------------------------------------------------------------------
# Background Service
# ------------------------------------------------------------------------------
class AutoBissBackgroundService(object):
    def __init__(self, session):
        self.session = session
        self.onClose = []
        self.cw_cache = CWCache()
        self._recording_sid = None
        self._cooldown = {}
        try:
            _cfg = load_settings()
        except Exception:
            _cfg = {}
        self._cooldown_secs = _cfg.get("cooldown", 60)
        self._record_duration = _cfg.get("record_duration", 1)
        self._notify = _cfg.get("notifications", True)
        try:
            log_debug("Settings loaded: cooldown={}s record={}s notify={}".format(
                self._cooldown_secs, self._record_duration, self._notify))
        except Exception:
            pass
        self._timer_entry = None
        self._notify_timer = eTimer()
        self._notify_timer.callback.append(self._on_recording_finished)
        try:
            _notif_set_enabled(self._notify)
        except Exception:
            pass
        self._debounce_timer = eTimer()
        self._debounce_timer.callback.append(self._debounced_check)
        self._popup_state = {'status': 'idle', 'cw': None, 'channel': ''}
        self._popup_timer = eTimer()
        self._popup_timer.callback.append(self._check_popup_state)
        self._notify_timer_stopped = False

        # Device registration — fires 5 s after startup (before update check)
        self._reg_result     = None   # set by background thread: 'ok' | 'failed'
        self._reg_poll_count = 0
        self._reg_start_timer = eTimer()
        self._reg_start_timer.callback.append(self._start_registration)
        self._reg_start_timer.start(5000, False)
        self._reg_poll_timer = eTimer()
        self._reg_poll_timer.callback.append(self._check_reg_result)

        # Auto-updater — fires 10 s after E2 has fully started
        self._update_pending_version = None
        self._update_poll_count = 0
        self._update_start_timer = eTimer()
        self._update_start_timer.callback.append(self._start_update_check)
        self._update_start_timer.start(10000, False)
        self._update_poll_timer = eTimer()
        self._update_poll_timer.callback.append(self._check_update_result)

        # Live-feed poller — first check 2 min after boot, then every 15 min
        # (aligned with the VPS importer). Fires one notification per batch
        # of newly discovered feeds, never a popup storm.
        self._feeds_pending = []
        self._feeds_lock = []
        self._feed_poll = eTimer()
        self._feed_poll.callback.append(self._poll_live_feeds)
        self._feed_poll.start(120000, False)

        # CWL download — fires 15 s after startup, refreshes every 6 hours
        self._cwl_timer = eTimer()
        self._cwl_timer.callback.append(self._download_cwl)
        self._cwl_timer.start(15000, True)

        # Storage detection — check at startup and notify (non-blocking)
        self.storage_path = _find_writable_storage()
        if self.storage_path:
            log_debug("Storage OK: {}".format(self.storage_path))
            _notif_info(self.session, "Storage ready: {}".format(self.storage_path),
                        timeout=2)
        else:
            log_debug("WARNING: No writable storage found at startup")
            _notif_warning(
                self.session,
                "No writable storage found.\nAutoBiss cannot record samples until "
                "a USB/HDD or /data is available.")

        # Softcam detection
        self._softcam_name = _detect_softcam()
        if self._softcam_name:
            log_debug("Softcam running: {}".format(self._softcam_name))
        else:
            log_debug("WARNING: No softcam detected at startup")
            _notif_warning(
                self.session,
                "OSCam/NCam not detected!\nKeys will be found but channels may stay "
                "scrambled until a softcam is running.")

        self.__event_tracker = ServiceEventTracker(
            screen=self,
            eventmap={
                iPlayableService.evStart: self._service_changed,
                iPlayableService.evUpdatedInfo: self._service_info_updated,
            }
        )
        log_debug("AutoBissBackgroundService initialized")

    def _service_changed(self):
        log_debug("_service_changed triggered")
        if self._recording_sid is not None:
            self._abort_recording("user zapped")
        self._debounce_timer.stop()
        self._debounce_timer.start(1000, False)

    def _service_info_updated(self):
        log_debug("_service_info_updated triggered")
        self._debounce_timer.stop()
        self._debounce_timer.start(800, False)

    def _debounced_check(self):
        log_debug("_debounced_check executing")
        self._check_current_service()

    def _check_popup_state(self):
        state = self._popup_state
        if state['status'] == 'idle':
            return
        status = state['status']
        state['status'] = 'idle'
        if status == 'searching':
            _notif_info(self.session, "Searching for key on {}".format(
                state.get('channel') or 'current channel'), timeout=3)
            return
        if status == 'success':
            cw_disp = format_cw_for_display(state['cw'])
            _notif_info(self.session, "Key found: {}\n{}".format(
                state.get('channel') or '', cw_disp), timeout=5)
            return
        if status == 'failed':
            _notif_warning(self.session,
                           "Key not found for {}".format(state.get('channel') or 'channel'),
                           timeout=4)
            return

    def _start_registration(self):
        if _device_is_registered is None or _device_register is None:
            log_debug("Device module not available, skipping registration")
            return
        if _device_is_registered():
            log_debug("Device already registered")
            return
        log_debug("Device not registered — starting registration")
        def _on_done(token):
            self._reg_result = 'ok' if token else 'failed'
        try:
            _device_register(callback=_on_done)
            self._reg_poll_timer.start(2000, False)
        except Exception as e:
            log_debug("Registration start error: {}".format(e))

    def _check_reg_result(self):
        self._reg_poll_count += 1
        if self._reg_poll_count > 60:   # 60 × 2 s = 2 min timeout
            self._reg_poll_timer.stop()
            return
        result = self._reg_result
        if result is None:
            return
        self._reg_result = None
        self._reg_poll_timer.stop()
        if result == 'ok':
            log_debug("Device registered — VPS decryption now active")
            _notif_info(self.session,
                        "Device registered.\nVPS decryption is now active.",
                        timeout=5)
        else:
            log_debug("Device registration failed")
            _notif_error(self.session,
                         "Device registration failed.\nCheck the internet connection.\n"
                         "VPS decryption unavailable.",
                         timeout=6)

    def _start_update_check(self):
        if _check_for_update is None:
            log_debug("Updater not available, skipping")
            return
        log_debug("Starting background update check (current v{})".format(_PLUGIN_VERSION))
        def _on_done(new_version):
            self._update_pending_version = new_version
        try:
            _check_for_update(callback=_on_done)
            self._update_poll_timer.start(3000, False)
        except Exception as e:
            log_debug("Update check start error: {}".format(e))

    def _check_update_result(self):
        self._update_poll_count += 1
        # Stop polling after 2 minutes (40 × 3 s) regardless of outcome
        if self._update_poll_count > 40:
            self._update_poll_timer.stop()
            return
        new_version = self._update_pending_version
        if new_version is None:
            return
        self._update_pending_version = None
        self._update_poll_timer.stop()
        log_debug("Update installed — notifying user (v{})".format(new_version))
        _notif_info(self.session,
                    "Updated to v{}.\nRestart the receiver to apply.".format(new_version),
                    timeout=10)

    # ── Live feed poller ─────────────────────────────────────────────────────
    _FEED_POLL_MS = 15 * 60 * 1000
    _FEED_FIRST_BATCH = True

    def _poll_live_feeds(self):
        """Ask the VPS for feeds discovered since our last check.

        Network I/O runs on a worker thread; the notification is emitted on
        the main thread via _feeds_pending/_feeds_lock.
        """
        since = self._read_feed_cursor()
        first = self._FEED_FIRST_BATCH
        self._FEED_FIRST_BATCH = False

        def _worker():
            new = []
            try:
                # No cursor yet: only seed on boot, otherwise a first run would
                # announce the whole board as "new".
                if first and not since:
                    feeds = _fetch_live_feeds()
                    log_debug("feed poll: seeded cursor, {} feeds on board".format(len(feeds)))
                    if feeds:
                        self._write_feed_cursor(_max_discovered(feeds))
                else:
                    new = _fetch_live_feeds(since=since)
                    log_debug("feed poll: since={} -> {} new".format(
                        since or "none", len(new)))
            except Exception as e:
                log_debug("feed poll error: {}".format(e))
                new = []
            if new:
                try:
                    newest = _max_discovered(new)
                except Exception:
                    newest = since
                if newest:
                    self._write_feed_cursor(newest)
            self._feeds_pending = new
            self._feeds_lock.append(True)

        try:
            import threading as _th
            t = _th.Thread(target=_worker)
            t.daemon = True
            t.start()
        except Exception as e:
            log_debug("feed poll start error: {}".format(e))
            self._feed_poll.start(self._FEED_POLL_MS, False)
            return
        # Reschedule first so a slow/hung worker can never stop the cadence
        self._feed_poll.start(self._FEED_POLL_MS, False)
        # Drain on the main thread
        self._feed_notify_timer = getattr(self, "_feed_notify_timer", None)
        if self._feed_notify_timer is None:
            self._feed_notify_timer = eTimer()
            self._feed_notify_timer.callback.append(self._drain_feed_results)
        self._feed_notify_timer.start(1500, False)

    def _drain_feed_results(self):
        try:
            self._feed_notify_timer.stop()
        except Exception:
            pass
        try:
            if not self._feeds_lock:
                return
            new = self._feeds_pending or []
            self._feeds_pending = []
            self._feeds_lock = []
            if not new:
                return
            log_debug("New live feeds: {}".format(len(new)))
            biss = [f for f in new if _feed_encrypted(f)]
            if self._notify:
                if biss:
                    _notif_info(
                        self.session,
                        "{} new feed(s) — {} encrypted (BISS)\n"
                        "Open AutoBiss > Live Feeds for details.".format(
                            len(new), len(biss)),
                        timeout=6)
                else:
                    _notif_info(
                        self.session,
                        "{} new feed(s) available.\n"
                        "Open AutoBiss > Live Feeds for details.".format(len(new)),
                        timeout=5)
        except Exception as e:
            log_debug("feed notify error: {}".format(e))

    def _read_feed_cursor(self):
        try:
            cfg = load_settings()
            return cfg.get("last_feed_cursor", "") or ""
        except Exception:
            return ""

    def _write_feed_cursor(self, value):
        try:
            cfg = load_settings()
            cfg["last_feed_cursor"] = value
            save_settings(cfg)
        except Exception as e:
            log_debug("feed cursor write error: {}".format(e))

    def _report_cw_to_vps(self, sid, cw_hex, svc_info):
        """Report a locally-found CW to VPS so it gets saved in the channels panel."""
        def _worker():
            try:
                import json as _json
                try:
                    import urllib2 as _ul
                except ImportError:
                    import urllib.request as _ul
                import ssl as _ssl

                _LEGACY_KEY = "a1b2c3d4e5f678901234567890abcdef1234567890abcdef"
                token = None
                try:
                    from Plugins.Extensions.AutoBiss.device import get_token
                    token = get_token()
                except Exception:
                    pass

                payload = _json.dumps({
                    "sid":         "{:04X}".format(sid),
                    "cw_hex":      cw_hex,
                    "service_ref": svc_info.get('service_ref', ''),
                    "video_pid":   svc_info.get('video_pid', ''),
                    "audio_pid":   svc_info.get('audio_pid', ''),
                    "pcr_pid":     svc_info.get('pcr_pid', ''),
                    "pmt_pid":     svc_info.get('pmt_pid', ''),
                    "txt_pid":     svc_info.get('txt_pid', ''),
                    "tsid":        svc_info.get('tsid', ''),
                    "onid":        svc_info.get('onid', ''),
                    "caid":        svc_info.get('caid', ''),
                })
                data = payload.encode('utf-8') if isinstance(payload, str) else payload
                req = _ul.Request("https://tsdec.kingcs.xyz/autobiss/report_cw", data=data)
                req.add_header("Content-Type", "application/json")
                if token:
                    req.add_header("X-Device-Token", token)
                else:
                    req.add_header("X-API-Key", _LEGACY_KEY)
                try:
                    ctx = _ssl.create_default_context()
                except Exception:
                    ctx = _ssl._create_unverified_context()
                try:
                    _ul.urlopen(req, context=ctx, timeout=10)
                except TypeError:
                    _ul.urlopen(req, timeout=10)
                log_debug("_report_cw_to_vps: reported SID 0x{:04X}".format(sid))
            except Exception as e:
                log_debug("_report_cw_to_vps error: {}".format(e))

        import threading as _th
        t = _th.Thread(target=_worker)
        t.daemon = True
        t.start()

    def _download_cwl(self):
        """Download the CWL key file from VPS to /tmp/CW_list.cwl in background.
        Reschedules itself every 6 hours so the file stays fresh."""
        def _worker():
            url = "https://tsdec.kingcs.xyz/autobiss/CW_list.cwl"
            dest = "/tmp/CW_list.cwl"
            tmp  = dest + ".tmp"
            try:
                try:
                    import urllib2 as _ul
                except ImportError:
                    import urllib.request as _ul
                import ssl as _ssl
                try:
                    ctx = _ssl.create_default_context()
                except Exception:
                    ctx = _ssl._create_unverified_context()
                try:
                    resp = _ul.urlopen(url, context=ctx, timeout=30)
                except TypeError:
                    resp = _ul.urlopen(url, timeout=30)
                data = resp.read()
                with open(tmp, 'wb') as f:
                    f.write(data)
                import os as _os
                _os.replace(tmp, dest)
                log_debug("CWL downloaded: {} bytes → {}".format(len(data), dest))
            except Exception as e:
                log_debug("CWL download failed: {}".format(e))
            # Reschedule refresh every 6 hours
            try:
                self._cwl_timer.start(6 * 3600 * 1000, True)
            except Exception:
                pass

        import threading as _th
        t = _th.Thread(target=_worker)
        t.daemon = True
        t.start()

    def _get_service_info(self):
        """Extract all service info (SID, PIDs, service ref, TSID, ONID, CAIDs) from current service."""
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not ref:
                return {}
            service = self.session.nav.getCurrentService()
            if not service:
                return {}
            info = service.info()
            if not info:
                return {}
            return {
                'service_ref': str(ref),
                'sid': "{:04X}".format(info.getInfo(iServiceInformation.sSID)),
                'video_pid': "{:04X}".format(info.getInfo(iServiceInformation.sVideoPID)),
                'audio_pid': "{:04X}".format(info.getInfo(iServiceInformation.sAudioPID)),
                'pcr_pid': "{:04X}".format(info.getInfo(iServiceInformation.sPCRPID) if hasattr(iServiceInformation, 'sPCRPID') else 0),
                'pmt_pid': "{:04X}".format(info.getInfo(iServiceInformation.sPMTPID) if hasattr(iServiceInformation, 'sPMTPID') else 0),
                'txt_pid': "{:04X}".format(info.getInfo(iServiceInformation.sTXTPID) if hasattr(iServiceInformation, 'sTXTPID') else 0),
                'tsid': "{:04X}".format(info.getInfo(iServiceInformation.sTSID) if hasattr(iServiceInformation, 'sTSID') else 0),
                'onid': "{:04X}".format(info.getInfo(iServiceInformation.sONID) if hasattr(iServiceInformation, 'sONID') else 0),
                'caid': "{:04X}".format(info.getInfo(iServiceInformation.sCAIDs) if hasattr(iServiceInformation, 'sCAIDs') else 0),
            }
        except Exception as e:
            log_debug("_get_service_info error: {}".format(e))
            return {}

    def force_update_current(self):
        """Force immediate re-decrypt of current channel (UPDATE button)."""
        log_debug("force_update_current triggered")
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        if not ref:
            log_debug("force_update: no service reference")
            return
        service = self.session.nav.getCurrentService()
        if not service:
            log_debug("force_update: no current service")
            return
        info = service.info()
        if not info:
            log_debug("force_update: no service info")
            return
        sid = info.getInfo(iServiceInformation.sSID)
        log_debug("force_update: SID=0x{:04X}".format(sid))
        # Clear cache and cooldown for this SID
        if sid in self.cw_cache._cache:
            del self.cw_cache._cache[sid]
        if sid in self._cooldown:
            del self._cooldown[sid]
        # Trigger check
        self._check_current_service()

    def _check_current_service(self):
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not ref:
                log_debug("_check: no service reference")
                return
            service = self.session.nav.getCurrentService()
            if not service:
                log_debug("_check: no current service")
                return
            info = service.info()
            if not info:
                log_debug("_check: no service info")
                return
            caids = info.getInfoObject(iServiceInformation.sCAIDs)
            if not caids:
                log_debug("_check: caids is None")
                return
            caid_list = list(caids)
            log_debug("Current CAIDs: {}".format(["0x{:04X}".format(c) for c in caid_list]))
            if BISS_CAID not in caid_list:
                log_debug("_check: BISS CAID 0x2600 not found in caid list")
                return
            sid = info.getInfo(iServiceInformation.sSID)
            log_debug("BISS detected on SID 0x{:04X}".format(sid))
            now = time()
            if sid in self._cooldown:
                elapsed = now - self._cooldown[sid]
                if elapsed < self._cooldown_secs:
                    log_debug("SID 0x{:04X} in cooldown ({}s left)".format(sid, int(self._cooldown_secs - elapsed)))
                    return
                else:
                    del self._cooldown[sid]
            ch_name = info.getName() if info else "AutoBiss"
            ecm_pid = get_ecm_pid(self.session)
            try:
                vpid = info.getInfo(iServiceInformation.sVideoPID)
            except Exception:
                vpid = 0

            cw = self.cw_cache.get(sid)

            # Fast path: softcam already has the CW in /tmp/ecm.info — no recording needed
            if not cw:
                cw = parse_ecm_info(sid)
                if cw:
                    log_debug("CW from ecm.info for SID 0x{:04X}: {}****".format(sid, cw[:4]))
                    self.cw_cache.set(sid, cw, "{:04X}".format(vpid), ch_name)
                    self._popup_state = {'status': 'success', 'cw': cw, 'channel': ch_name}
                    try:
                        if write_softcam_key(sid, vpid, cw, ch_name, ecm_pid):
                            reload_softcam()
                        write_ecm_info(sid, ecm_pid, cw, ch_name)
                    except Exception as e:
                        log_debug("ecm.info inject exception: {}".format(e))
                    # Report to VPS so it gets saved in channels panel
                    svc_info = self._get_service_info()
                    self._report_cw_to_vps(sid, cw, svc_info)
                    self._cooldown[sid] = time()
                    return

            if cw:
                log_debug("CW already known for SID 0x{:04X}: {}****".format(sid, cw[:4]))
                try:
                    if write_softcam_key(sid, vpid, cw, ch_name, ecm_pid):
                        reload_softcam()
                    write_ecm_info(sid, ecm_pid, cw, ch_name)
                except Exception as e:
                    log_debug("Re-inject exception: {}".format(e))
                return
            if self._recording_sid is not None:
                log_debug("Recording already in progress for SID 0x{:04X}, skip".format(self._recording_sid))
                return
            self._start_recording(sid, ref, info)
        except Exception as e:
            log_debug("_check_current_service exception: {}".format(e))

    def _abort_recording(self, reason):
        log_debug("_abort_recording: {}".format(reason))
        self._notify_timer.stop()
        if self._timer_entry:
            try:
                NavigationInstance.instance.RecordTimer.removeEntry(self._timer_entry)
            except Exception as e:
                log_debug("removeEntry warning: {}".format(e))
            self._timer_entry = None
        old_sid = self._recording_sid
        self._recording_sid = None
        self._current_ts_path = None
        self._channel_name = None
        if old_sid is not None:
            self._cooldown[old_sid] = time()

    def _start_recording(self, sid, ref, info):
        global _vps_unreachable
        _vps_unreachable = False
        log_debug("_start_recording for SID 0x{:04X}".format(sid))

        # Guard: require writable storage
        if not self.storage_path:
            log_debug("No writable storage found. Skipping recording.")
            self.session.open(
                MessageBox,
                "USB/HDD not Found! Please plug and mount USB or HDD!",
                MessageBox.TYPE_WARNING,
            )
            return

        ch_name = info.getName() if info else "Unknown"
        self._popup_state = {'status': 'searching', 'cw': None, 'channel': ch_name}
        self._popup_timer.start(200, False)
        record_dir = self.storage_path
        ensure_dir(record_dir)
        safe_name = sanitize_filename(ch_name)
        timestamp = strftime("%Y%m%d_%H%M%S")
        basename = "AutoBiss_{}_{}".format(safe_name, timestamp)
        ts_path = os.path.join(record_dir, "{}.ts".format(basename))
        ts_path = get_unique_filepath(ts_path)
        filename_only = os.path.splitext(os.path.basename(ts_path))[0]
        self._recording_sid = sid
        self._current_ts_path = ts_path
        self._safe_name = safe_name
        self._channel_name = ch_name
        log_debug("Target TS: {}".format(ts_path))
        if not _RECORDTIMER_AVAILABLE:
            log_debug("RecordTimer not available, aborting record")
            self._abort_recording("no RecordTimer")
            return
        try:
            serviceref = SvcRef(ref)
            begin = int(time())
            end = begin + self._record_duration
            name = "AutoBiss {}".format(safe_name)
            description = "AutoBiss {}s sample".format(self._record_duration)
            event = None
            try:
                event = info.getEvent(ref)
            except Exception:
                pass
            eit = event.getEventId() if event else -1
            entry = RecordTimerEntry(
                serviceref, begin, end, name, description, eit,
                False, False, AFTEREVENT.NONE, True,
            )
            entry.dirname = record_dir
            if hasattr(entry, 'Filename'):
                entry.Filename = filename_only
            elif hasattr(entry, 'filename'):
                entry.filename = filename_only
            if hasattr(entry, 'dontSave'):
                entry.dontSave = True
            if hasattr(entry, 'descramble'):
                entry.descramble = False
                log_debug("Set descramble=False")
            if hasattr(entry, 'record_ecm'):
                entry.record_ecm = False
            NavigationInstance.instance.RecordTimer.record(entry)
            self._timer_entry = entry
            log_debug("RecordTimer.record() success")
            self._notify_timer.start(self._record_duration * 1000, False)
            try:
                write_service_info(self.session, ts_path)
            except Exception as e:
                log_debug("write_service_info exception: {}".format(e))
        except Exception as e:
            log_debug("_start_recording exception: {}".format(e))
            self._abort_recording("exception")

    def _find_recorded_file(self, expected_path, search_token):
        if os.path.exists(expected_path):
            return expected_path
        search_dir = self.storage_path or OUTPUT_DIR
        try:
            now = time()
            candidates = []
            for f in os.listdir(search_dir):
                if not f.endswith('.ts'):
                    continue
                if '_dec.ts' in f:
                    continue
                full = os.path.join(search_dir, f)
                try:
                    mtime = os.path.getmtime(full)
                    if (now - mtime) < 45 and search_token in f:
                        candidates.append((full, mtime))
                except Exception:
                    pass
            if candidates:
                candidates.sort(key=lambda x: x[1], reverse=True)
                found = candidates[0][0]
                log_debug("Found actual TS file by search: {}".format(found))
                return found
        except Exception as e:
            log_debug("Filesystem search error: {}".format(e))
        log_debug("Could not find any TS file matching '{}'".format(search_token))
        return None

    def _on_recording_finished(self):
        log_debug("_on_recording_finished called")
        self._notify_timer.stop()
        sid = self._recording_sid
        ts_path = getattr(self, '_current_ts_path', None)
        safe_name = getattr(self, '_safe_name', '')
        channel_name = getattr(self, '_channel_name', 'AutoBiss')
        if self._timer_entry:
            try:
                NavigationInstance.instance.RecordTimer.removeEntry(self._timer_entry)
            except Exception as e:
                log_debug("removeEntry warning: {}".format(e))
            self._timer_entry = None
        self._recording_sid = None
        if not ts_path or not safe_name:
            log_debug("No ts_path/safe_name stored")
            return
        # Collect service info on main thread NOW — _get_service_info() uses
        # session.nav which is not safe to call from a background thread.
        svc_info = self._get_service_info()
        def _delayed_process():
            search_token = safe_name
            actual_path = self._find_recorded_file(ts_path, search_token)
            if not actual_path:
                log_debug("TS file not found after search: {}".format(ts_path))
                self._cooldown[sid] = time()
                return
            log_debug("TS sample recorded: {}".format(actual_path))
            global _latest_ts_by_sid
            _latest_ts_by_sid[sid] = actual_path
            self._cooldown[sid] = time()
            global _vps_unreachable
            cw = parse_ecm_info(sid)
            if cw:
                log_debug("CW from softcam: {}****".format(cw[:4] if cw else ""))
                self.cw_cache.set(sid, cw, '', channel_name)
            if not cw:
                sid_hex = "{:04X}".format(sid)
                ecm_pid = get_ecm_pid(self.session)
                ecm_hex = ecm_pid.upper().replace("0X", "").replace("0x", "")
                global_cwl = get_global_cwl()
                
                # 1. Try LOCAL tsdec binary first (fast, no upload)
                local_tsdec = _get_tsdec_binary()
                if local_tsdec and global_cwl:
                    log_debug("Trying LOCAL tsdec for SID {}".format(sid_hex))
                    try:
                        cw, rc = run_tsdec_extract_cw(actual_path, global_cwl, binary_path=local_tsdec)
                        if cw:
                            log_debug("CW extracted by LOCAL tsdec: {}****".format(cw[:4]))
                        else:
                            log_debug("Local tsdec could not find CW (rc={})".format(rc))
                    except Exception as e:
                        log_debug("Local tsdec exception: {}".format(e))
                
                # 2. If local failed, try VPS decrypt
                if not cw:
                    log_debug("Trying VPS decrypt for SID {} ECM {}".format(sid_hex, ecm_hex))
                    try:
                        cw, reachable = decrypt_via_vps(
                            actual_path, global_cwl, sid_hex, ecm_hex,
                            service_ref=svc_info.get('service_ref', ''),
                            video_pid=svc_info.get('video_pid', ''),
                            audio_pid=svc_info.get('audio_pid', ''),
                            pcr_pid=svc_info.get('pcr_pid', ''),
                            pmt_pid=svc_info.get('pmt_pid', ''),
                            txt_pid=svc_info.get('txt_pid', ''),
                            tsid=svc_info.get('tsid', ''),
                            onid=svc_info.get('onid', ''),
                            caid=svc_info.get('caid', '')
                        )
                        if cw:
                            log_debug("CW extracted by VPS: {}****".format(cw[:4]))
                        if not reachable:
                            _vps_unreachable = True
                            log_debug("VPS is unreachable")
                        if not cw and reachable and global_cwl:
                            # Built-in tsdec fallback (system command)
                            log_debug("VPS returned no CW, falling back to built-in tsdec")
                            try:
                                cw, rc = run_tsdec_extract_cw(actual_path, global_cwl)
                                if cw:
                                    log_debug("CW extracted by built-in tsdec: {}****".format(cw[:4]))
                                else:
                                    log_debug("Built-in tsdec could not find CW (rc={})".format(rc))
                            except Exception as e:
                                log_debug("Built-in tsdec extract exception: {}".format(e))
                    except Exception as e:
                        log_debug("decrypt_via_vps exception: {}".format(e))
                
                # Delete TS after all decryption attempts are done
                try:
                    if os.path.exists(actual_path):
                        os.remove(actual_path)
                        log_debug("Cleaned up sample TS: {}".format(actual_path))
                except Exception as e:
                    log_debug("Cleanup warning: {}".format(e))
            if cw:
                ecm_pid = get_ecm_pid(self.session)
                try:
                    vpid = int(svc_info.get('video_pid', '0'), 16)
                except Exception:
                    vpid = 0
                self.cw_cache.set(sid, cw, "{:04X}".format(vpid), channel_name)
                try:
                    if write_softcam_key(sid, vpid, cw, channel_name, ecm_pid):
                        reload_softcam()
                    else:
                        log_debug("Failed to write SoftCam.Key")
                    write_ecm_info(sid, ecm_pid, cw, channel_name)
                except Exception as e:
                    log_debug("Softcam injection exception: {}".format(e))
                # Clean up all recording sidecar files
                try:
                    cleanup_recording_sidecars(actual_path)
                except Exception as e:
                    log_debug("Sidecar cleanup exception: {}".format(e))
                # Report locally-found CW to VPS for channels panel
                self._report_cw_to_vps(sid, cw, svc_info)
                self._popup_state = {'status': 'success', 'cw': cw, 'channel': channel_name}
            else:
                if _vps_unreachable:
                    log_debug("No CW found and VPS unreachable. Maintenance mode.")
                else:
                    log_debug("No CW found. Channel will remain encrypted.")
                self._popup_state = {'status': 'failed', 'cw': None, 'channel': channel_name}
            # Safety-net cleanup
            try:
                if os.path.exists(actual_path):
                    os.remove(actual_path)
                    log_debug("Safety cleanup sample TS: {}".format(actual_path))
            except Exception:
                pass
        t = Timer(0.5, _delayed_process)
        t.daemon = True
        t.start()

# ------------------------------------------------------------------------------
# AutoBiss Control Center v2.6 (menu-driven interface)
# ------------------------------------------------------------------------------
def _count_cached_keys():
    """Count distinct cached SIDs via the live CWCache (single source of truth)."""
    try:
        if _background_service and getattr(_background_service, 'cw_cache', None):
            return _background_service.cw_cache.count()
    except Exception as e:
        log_debug("_count_cached_keys error: {}".format(e))
    return 0


class AutoBissMainScreen(Screen):
    skin = """
    <screen name="AutoBissMainScreen" position="0,0" size="1920,1080" title="AutoBiss" backgroundColor="#040a12" flags="wfNoBorder">
""" + _FS_BG + _FS_HEADER + _FS_SECTION + """
        <widget name="col_state" position="90,238" size="300,40" font="Bold;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1330" />
        <widget name="col_chan"  position="400,238" size="470,40" font="Bold;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1330" />

        <widget name="now_channel" position="74,292" size="812,50" font="Bold;34" halign="left" foregroundColor="#35c8f0" backgroundColor="#0a1524" />
        <widget name="now_detail"  position="74,348" size="812,28" font="Regular;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />

        <widget name="btn0" position="74,392" size="812,58" font="Regular;22" halign="left" foregroundColor="#4ade80" backgroundColor="#0a1524" />
        <widget name="btn1" position="74,458" size="812,58" font="Regular;22" halign="left" foregroundColor="#f5a623" backgroundColor="#0a1524" />
        <widget name="btn2" position="74,524" size="812,58" font="Regular;22" halign="left" foregroundColor="#58a6ff" backgroundColor="#0a1524" />
        <widget name="btn3" position="74,590" size="812,58" font="Regular;22" halign="left" foregroundColor="#35c8f0" backgroundColor="#0a1524" />
        <widget name="btn4" position="74,656" size="812,58" font="Regular;22" halign="left" foregroundColor="#a78bfa" backgroundColor="#0a1524" />
        <widget name="btn5" position="74,722" size="812,58" font="Regular;22" halign="left" foregroundColor="#f0883e" backgroundColor="#0a1524" />
        <widget name="btn6" position="74,788" size="812,58" font="Regular;22" halign="left" foregroundColor="#f472b6" backgroundColor="#0a1524" />

        <widget name="sysline" position="74,866" size="812,44" font="Regular;16" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
""" + _FS_PIP + _FS_FOOTER + """
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.skin = _render_skin(AutoBissMainScreen.skin)
        self.title = "AutoBiss Control Center"

        self["sec_left"] = Label("Control Center")
        self["sec_right"] = Label("Channel Preview")
        self["col_state"] = Label("STATE")
        self["col_chan"] = Label("CURRENT CHANNEL")
        self["now_channel"] = Label("---")
        self["now_detail"] = Label("---")
        self["btn0"] = Label("")
        self["btn1"] = Label("")
        self["btn2"] = Label("")
        self["btn3"] = Label("")
        self["btn4"] = Label("")
        self["btn5"] = Label("")
        self["btn6"] = Label("")
        self["sysline"] = Label("")
        self._hdr_timer = _init_header(self, 1000)
        _init_footer(self, ["About", "Browse", "Decrypt", "Settings",
                            "Info", "Keys", "Close"])
        self._pip_ref = None
        self._pip_timer = _init_pip_panel(self, 2000)

        self._menu_state = "idle"   # decrypted | searching | maintenance | fta | nobiss | idle
        self._menu_keys = 0
        self._menu_sig = None
        self._btn_idx = 0
        self._btn_colors = ["#4ade80", "#f5a623", "#58a6ff", "#35c8f0", "#a78bfa", "#f0883e", "#f472b6"]
        self._btn_unselected_bg = "#0a1524"
        self._btn_selected_fg = "#0a0f16"
        self._menu_actions = [
            self._do_force_decrypt,
            self._do_channel_info,
            self._do_feed_list,
            self._do_plugin_update,
            self._do_about,
            self._do_settings,
            self._do_live_feeds,
        ]
        self._refresh_buttons()

        try:
            self["actions"] = ActionMap(
                ["OkCancelActions", "ColorActions", "DirectionActions", "NumberActions"],
                {
                    "ok":     self._menu_ok,
                    "cancel": self.close,
                    "red":    self.close,
                    "green":  self._do_force_decrypt,
                    "yellow": self._do_channel_info,
                    "blue":   self._do_feed_list,
                    "up":     self._menu_up,
                    "down":   self._menu_down,
                    "1":      lambda: self._menu_exec(0),
                    "2":      lambda: self._menu_exec(1),
                    "3":      lambda: self._menu_exec(2),
                    "4":      lambda: self._menu_exec(3),
                    "5":      lambda: self._menu_exec(4),
                    "6":      lambda: self._menu_exec(5),
                    "7":      lambda: self._menu_exec(6),
                },
                -2,
            )
        except Exception:
            try:
                self["actions"] = ActionMap(
                    ["ColorActions", "SetupActions"],
                    {
                        "red":    self.close,
                        "green":  self._do_force_decrypt,
                        "yellow": self._do_channel_info,
                        "blue":   self._do_feed_list,
                        "ok":     self._menu_ok,
                        "cancel": self.close,
                    },
                    -2,
                )
            except Exception:
                self["actions"] = ActionMap(
                    ["SetupActions"],
                    {
                        "cancel": self.close,
                        "ok":     self._menu_ok,
                    },
                    -2,
                )

        self._update_timer = eTimer()
        self._update_timer.callback.append(self._update_display)
        self._update_timer.start(500, False)
        self._update_display()

        try:
            self.onFirstExecBegin.append(self._enable_pip)
        except Exception as e:
            log_debug("onFirstExecBegin error: {}".format(e))

    def _enable_pip(self):
        """Show the running channel in the mini window (once).

        With the active skin's preview renderer the channel stays on the
        main video output and is drawn into the right panel widget, so no
        PiP is needed; without it we fall back to the framework PiP.
        """
        if self._pip_ref is not None:
            return
        if _has_pig_renderer():
            log_debug("Pig preview renderer active, PiP not needed")
            return
        self._pip_ref = _pip_show(self.session)
        log_debug("PiP requested, saved ref: {}".format(self._pip_ref is not None))

    # -- buttons ----------------------------------------------------------
    def _btn_keys_text(self):
        return "{} saved BISS keys".format(self._menu_keys)

    def _button_texts(self):
        if self._menu_state == "decrypted":
            s0 = "DECRYPTED"
        elif self._menu_state == "searching":
            s0 = "SEARCHING..."
        elif self._menu_state == "maintenance":
            s0 = "VPS OFFLINE"
        elif self._menu_state in ("fta", "nobiss"):
            s0 = "NO BISS"
        else:
            s0 = "READY"
        return [
            "     Decrypt channel   ·   {}".format(s0),
            "     Channel information",
            "     Saved BISS keys   ·   {}".format(self._menu_keys),
            "     Check for update",
            "     About AutoBiss",
            "     Settings",
            "     Live Feeds",
        ]

    def _set_label_color(self, widget_name, color_str):
        try:
            w = self[widget_name]
            if hasattr(w, "instance") and w.instance:
                w.instance.setForegroundColor(_parse_color(color_str))
        except Exception:
            pass

    def _set_label_bg(self, widget_name, color_str):
        try:
            w = self[widget_name]
            if hasattr(w, "instance") and w.instance:
                w.instance.setBackgroundColor(_parse_color(color_str))
        except Exception as e:
            log_debug("setBackgroundColor failed: {}".format(e))

    def _refresh_buttons(self):
        texts = self._button_texts()
        for i in range(7):
            try:
                selected = (i == self._btn_idx)
                name = "btn{}".format(i)
                self[name].setText(texts[i])
                if selected:
                    self._set_label_bg(name, "#12325c")
                    self._set_label_color(name, "#ffffff")
                else:
                    self._set_label_bg(name, self._btn_unselected_bg)
                    self._set_label_color(name, self._btn_colors[i])
            except Exception as e:
                log_debug("Button refresh error: {}".format(e))

    def _menu_index(self):
        return self._btn_idx

    def _menu_ok(self):
        self._menu_exec(self._menu_index())

    def _menu_exec(self, idx):
        try:
            if 0 <= idx < len(self._menu_actions):
                self._menu_actions[idx]()
        except Exception as e:
            log_debug("Menu exec error: {}".format(e))

    def _menu_up(self):
        self._btn_idx = (self._btn_idx - 1) % 7
        self._refresh_buttons()

    def _menu_down(self):
        self._btn_idx = (self._btn_idx + 1) % 7
        self._refresh_buttons()

    def _do_settings(self):
        """Open Settings screen."""
        log_debug("SETTINGS button pressed")
        self.session.open(AutoBissSettings)

    def _do_live_feeds(self):
        """Open Live Feeds screen."""
        log_debug("LIVE FEEDS button pressed")
        self.session.open(AutoBissLiveFeeds)

    # -- live display ------------------------------------------------------
    def _update_display(self):
        try:
            storage_ok = bool(_background_service and _background_service.storage_path)

            global _vps_unreachable
            if _vps_unreachable:
                vps_txt = "VPS Offline"
            else:
                vps_txt = "VPS Online"
            _tick_clock(self)

            softcam_name = _background_service._softcam_name if _background_service else None
            cam_txt = softcam_name.upper() if softcam_name else "No Softcam"
            store_txt = "Storage OK" if storage_ok else "NO STORAGE"
            self["sysline"].setText(
                "{}  ·  {}  ·  {}  ·  {}".format(store_txt, vps_txt, cam_txt,
                                                 self._btn_keys_text())
            )

            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not ref:
                return
            service = self.session.nav.getCurrentService()
            if not service:
                return
            info = service.info()
            if not info:
                return

            sname = info.getName() if info else "Unknown"
            self["now_channel"].setText(sname)

            caids = info.getInfoObject(iServiceInformation.sCAIDs)
            if caids and BISS_CAID in list(caids):
                sid = info.getInfo(iServiceInformation.sSID)
                sid_hex = "{:04X}".format(sid)
                vpid = info.getInfo(iServiceInformation.sVideoPID)
                apid = info.getInfo(iServiceInformation.sAudioPID)
                cw = _get_cached_cw(sid)
                if _vps_unreachable:
                    self._menu_state = "maintenance"
                    cw_txt = "VPS offline"
                elif cw:
                    self._menu_state = "decrypted"
                    cw_txt = "CW {}...".format(cw[:8])
                else:
                    self._menu_state = "searching"
                    cw_txt = "searching..."
                self["now_detail"].setText(
                    "BISS  |  SID {}  |  VPID {:04X} APID {:04X}  |  {}".format(sid_hex, vpid, apid, cw_txt)
                )
            else:
                enc_type = _detect_encryption_type(info) if caids else "FTA"
                if not caids:
                    self._menu_state = "fta"
                else:
                    self._menu_state = "nobiss"
                self["now_detail"].setText("{}  |  not a BISS channel".format(enc_type))

            self._menu_keys = _count_cached_keys()
            sig = (self._menu_state, self._menu_keys, sname)
            if sig != self._menu_sig:
                self._menu_sig = sig
                self._refresh_buttons()

        except Exception as e:
            log_debug("MainScreen update exception: {}".format(e))

    def _do_force_decrypt(self):
        """OK button — force CW re-decrypt of current channel."""
        log_debug("FORCE DECRYPT pressed")
        if not _background_service:
            _notif_error(self.session, "Background service not running", timeout=3)
            return
        if not _background_service.storage_path:
            _notif_warning(self.session,
                           "No writable storage.\nPlug and mount a USB/HDD "
                           "(or make /data available).", timeout=6)
            return
        if not _background_service._softcam_name:
            _notif_warning(self.session,
                           "No softcam detected.\nSearching anyway — the channel "
                           "may stay scrambled.", timeout=4)
        _background_service.force_update_current()
        _notif_info(self.session, "Searching for the CW key...", timeout=2)

    def _do_plugin_update(self):
        """GREEN button — check for and install plugin update from VPS."""
        log_debug("PLUGIN UPDATE button pressed")

        def _on_update_done(new_version):
            _notif_info(self.session,
                        "Updated to v{}.\nRestart the receiver to apply.".format(new_version),
                        timeout=10)

        started = False
        try:
            from Plugins.Extensions.AutoBiss.updater import check_and_apply_update
            check_and_apply_update(callback=_on_update_done)
            started = True
        except Exception as e:
            log_debug("Plugin update launch error: {}".format(e))

        if started:
            _notif_info(self.session,
                        "Checking for updates (installed v{})...".format(_PLUGIN_VERSION),
                        timeout=3)
        else:
            _notif_error(self.session, "Updater not available", timeout=4)

    def _do_about(self):
        log_debug("ABOUT button pressed")
        self.session.open(AutoBissInfoScreen)

    def _do_channel_info(self):
        """YELLOW button — open Channel Info screen."""
        log_debug("CHANNEL INFO button pressed")
        self.session.open(AutoBissChannelInfo)

    def _do_feed_list(self):
        """BLUE button — open Feed List screen."""
        log_debug("FEED LIST button pressed")
        self.session.open(AutoBissFeedList)

    def close(self, *args, **kwargs):
        self._update_timer.stop()
        try:
            if self._hdr_timer is not None:
                self._hdr_timer.stop()
        except Exception:
            pass
        try:
            if self._pip_timer is not None:
                self._pip_timer.stop()
        except Exception:
            pass
        if self._pip_ref is not None:
            _pip_restore(self.session, self._pip_ref)
            self._pip_ref = None
        return Screen.close(self, *args, **kwargs)


# ------------------------------------------------------------------------------
# v2.6 - About Screen (tagline + hint footer)
# ------------------------------------------------------------------------------
class AutoBissInfoScreen(Screen):
    skin = """
    <screen name="AutoBissInfoScreen" position="0,0" size="1920,1080" title="About AutoBiss" backgroundColor="#040a12" flags="wfNoBorder">
""" + _FS_BG + _FS_HEADER + _FS_SECTION + """
        <widget name="tagline" position="74,292" size="812,30" font="Regular;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />

        <widget name="lbl_vps"      position="74,340" size="300,34" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="vps_url"      position="390,340" size="496,34" font="Regular;20" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="lbl_api"      position="74,386" size="300,34" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="api_key"      position="390,386" size="496,34" font="Regular;20" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="lbl_record"   position="74,432" size="300,34" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="record_dur"   position="390,432" size="496,34" font="Regular;20" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="lbl_cooldown" position="74,478" size="300,34" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="cooldown"     position="390,478" size="496,34" font="Regular;20" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="lbl_version"  position="74,524" size="300,34" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="version"      position="390,524" size="496,34" font="Regular;20" halign="left" foregroundColor="#58a6ff" backgroundColor="#0a1524" />

        <widget name="lbl_softcam"  position="74,570" size="300,34" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="softcam_info" position="390,570" size="496,34" font="Regular;20" halign="left" foregroundColor="#4ade80" backgroundColor="#0a1524" />

        <widget name="status" position="74,630" size="812,40" font="Bold;22" halign="center" foregroundColor="#4ade80" backgroundColor="#0a1524" />

        <widget name="credits_by"    position="74,700" size="812,28" font="Regular;18" halign="center" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="credits_names" position="74,736" size="812,40" font="Bold;26"    halign="center" foregroundColor="#f0883e" backgroundColor="#0a1524" />
""" + _FS_PIP + _FS_FOOTER + """
    </screen>
    """

    def __init__(self, session):
        self.skin = _render_skin(AutoBissInfoScreen.skin)
        Screen.__init__(self, session)
        self.session = session
        self.title = "About AutoBiss"

        self["sec_left"] = Label("About AutoBiss")
        self["sec_right"] = Label("Channel Preview")
        self["tagline"]       = Label("Real-time BISS key finder and softcam injector")
        self["lbl_vps"]       = Label("Plugin")
        self["vps_url"]       = Label("AutoBiss E2")
        self["lbl_api"]       = Label("API Key")
        self["api_key"]       = Label("configured")
        self["lbl_record"]    = Label("Record duration")
        self["record_dur"]    = Label("1 second per sample")
        self["lbl_cooldown"]  = Label("Cooldown")
        self["cooldown"]      = Label("60 seconds per channel")
        self["lbl_version"]   = Label("Version")
        self["version"]       = Label("v{}".format(_PLUGIN_VERSION))
        self["lbl_softcam"]   = Label("Softcam")
        softcam_name = _background_service._softcam_name if _background_service else None
        self["softcam_info"]  = Label(softcam_name.upper() if softcam_name else "Not detected")
        self["credits_by"]    = Label("Developed by")
        self["credits_names"] = Label("Kingcs  ·  prof-abdo  ·  abed1988")
        self._hdr_timer = _init_header(self, 1000)
        _init_footer(self, ["About", "Browse", "Details", "Settings",
                            "Scan", "Zap", "Close"])
        self._pip_timer = _init_pip_panel(self, 2000)

        global _vps_unreachable
        if _vps_unreachable:
            self["status"] = Label("VPS Status:  OFFLINE — Maintenance mode")
            try:
                self["status"].instance.setForegroundColor(parseColor("#f0883e"))
            except Exception:
                pass
        else:
            self["status"] = Label("VPS Status:  Online")

        try:
            self["actions"] = ActionMap(
                ["ColorActions", "SetupActions"],
                {
                    "red":    self.close,
                    "cancel": self.close,
                    "ok":     self.close,
                },
                -2,
            )
        except Exception:
            self["actions"] = ActionMap(
                ["SetupActions"],
                {
                    "cancel": self.close,
                    "ok":     self.close,
                },
                -2,
            )

    def close(self, *args, **kwargs):
        try:
            if self._hdr_timer is not None:
                self._hdr_timer.stop()
        except Exception:
            pass
        try:
            if self._pip_timer is not None:
                self._pip_timer.stop()
        except Exception:
            pass
        return Screen.close(self, *args, **kwargs)


# ------------------------------------------------------------------------------
# Key Screen (Professional Redesign)
# ------------------------------------------------------------------------------
class AutoBissKeyScreen(Screen):
    skin = """
    <screen name="AutoBissKeyScreen" position="0,0" size="1920,1080" title="AutoBiss E2 - Current Key" backgroundColor="#040a12" flags="wfNoBorder">
""" + _FS_BG + _FS_HEADER + _FS_SECTION + """
        <widget name="service"  position="74,292" size="812,46" font="Bold;30" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />
        <widget name="status"   position="74,356" size="812,34" font="Regular;20" halign="left" foregroundColor="#4ade80" backgroundColor="#0a1524" />
        <widget name="cw_label" position="74,430" size="300,30" font="Regular;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="cw_value" position="74,470" size="812,50" font="Bold;32" halign="left" foregroundColor="#a78bfa" backgroundColor="#0a1524" />
        <widget name="hint" position="74,560" size="812,60" font="Regular;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
""" + _FS_PIP + _FS_FOOTER + """
    </screen>
    """

    def __init__(self, session, service=None):
        self.skin = _render_skin(AutoBissKeyScreen.skin)
        Screen.__init__(self, session)
        self.title = "AutoBiss E2 - Current Key"
        self.session = session
        self["sec_left"] = Label("Current BISS Key")
        self["sec_right"] = Label("Channel Preview")
        self["service"] = Label("No service")
        self["status"] = Label("No BISS channel detected")
        self["cw_label"] = Label("BISS CONTROL WORD")
        self["cw_value"] = Label("Unknown")
        self["hint"] = Label("Tune to a BISS channel. AutoBiss records automatically in background.")
        self._hdr_timer = _init_header(self, 1000)
        _init_footer(self, ["About", "Browse", "Details", "Settings",
                            "Scan", "Zap", "Close"])
        self._pip_timer = _init_pip_panel(self, 2000)
        self["actions"] = ActionMap(
            ["SetupActions"],
            {
                "cancel": self.close,
                "ok": self.close,
            },
            -2,
        )
        self._update_timer = eTimer()
        self._update_timer.callback.append(self._update_display)
        self._update_timer.start(1000, False)
        self._update_display()

    def _update_display(self):
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not ref:
                return
            service = self.session.nav.getCurrentService()
            if not service:
                return
            info = service.info()
            if not info:
                return
            sname = info.getName() if info else "Unknown"
            self["service"].setText(sname)
            caids = info.getInfoObject(iServiceInformation.sCAIDs)
            if caids and BISS_CAID in list(caids):
                sid = info.getInfo(iServiceInformation.sSID)
                global _vps_unreachable
                if _vps_unreachable:
                    self["status"].setText("Maintenance is running")
                    self["cw_value"].setText("VPS unreachable")
                else:
                    cw = _get_cached_cw(sid)
                    if cw:
                        self["status"].setText("BISS DECRYPTED | SID: 0x{:04X}".format(sid))
                        self["cw_value"].setText(format_cw_for_display(cw))
                    else:
                        self["status"].setText("BISS encrypted | SID: 0x{:04X}".format(sid))
                        self["cw_value"].setText("Searching...")
            else:
                self["status"].setText("Current channel is not BISS encrypted")
                self["cw_value"].setText("N/A")
        except Exception as e:
            log_debug("KeyScreen update exception: {}".format(e))

    def close(self, *args, **kwargs):
        self._update_timer.stop()
        try:
            if self._pip_timer is not None:
                self._pip_timer.stop()
        except Exception:
            pass
        return Screen.close(self, *args, **kwargs)
# ------------------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------------------
_background_service = None
_latest_ts_by_sid = {}
_vps_unreachable = False

def _get_cached_cw(sid):
    if _background_service:
        return _background_service.cw_cache.get(sid)
    return None

# ------------------------------------------------------------------------------
# v2.6 - Channel Info Screen (sectioned layout)
# ------------------------------------------------------------------------------
class AutoBissChannelInfo(Screen):
    skin = """
    <screen name="AutoBissChannelInfo" position="0,0" size="1920,1080" title="AutoBiss - Channel Info" backgroundColor="#070b12" flags="wfNoBorder">
""" + _FS_BG + _FS_HEADER + _FS_SECTION + """
        <widget name="ch_name" position="74,292" size="520,40" font="Bold;26" halign="left" foregroundColor="#35c8f0" backgroundColor="#0a1524" />
        <widget name="enc_badge"  position="600,292" size="286,40" font="Regular;20" halign="right" foregroundColor="#f5a623" backgroundColor="#0a1524" />

        <widget name="sec_signal" position="74,348" size="812,30" font="Bold;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />

        <widget name="lbl_sat"   position="74,386"  size="300,30" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="val_sat"   position="390,386" size="496,30" font="Regular;20" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="lbl_freq"  position="74,424"  size="300,30" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="val_freq"  position="390,424" size="496,30" font="Regular;20" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="lbl_polar" position="74,462"  size="300,30" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="val_polar" position="390,462" size="496,30" font="Regular;20" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="sec_stream" position="74,516" size="812,30" font="Bold;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />

        <widget name="lbl_sid"   position="74,554"  size="300,30" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="val_sid"   position="390,554" size="496,30" font="Regular;20" halign="left" foregroundColor="#58a6ff" backgroundColor="#0a1524" />

        <widget name="lbl_vpid"  position="74,592"  size="300,30" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="val_vpid"  position="390,592" size="496,30" font="Regular;20" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="lbl_apid"  position="74,630"  size="300,30" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="val_apid"  position="390,630" size="496,30" font="Regular;20" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="lbl_pcr"   position="74,668"  size="300,30" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="val_pcr"   position="390,668" size="496,30" font="Regular;20" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="lbl_caid"  position="74,706"  size="300,30" font="Regular;20" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="val_caid"  position="390,706" size="496,30" font="Regular;20" halign="left" foregroundColor="#4ade80" backgroundColor="#0a1524" />

        <widget name="ch_ref"  position="74,780" size="812,26" font="Regular;14" halign="left" foregroundColor="#5b6b84" backgroundColor="#0a1524" />
""" + _FS_PIP + _FS_FOOTER + """
    </screen>
    """

    def __init__(self, session):
        self.skin = _render_skin(AutoBissChannelInfo.skin)
        Screen.__init__(self, session)
        self.title = "AutoBiss - Channel Info"
        self["sec_left"] = Label("Channel Info")
        self["sec_right"] = Label("Channel Preview")
        self["ch_name"] = Label("---")
        self["enc_badge"] = Label("")
        self["sec_signal"] = Label("SIGNAL")
        self["sec_stream"] = Label("STREAM")
        self["lbl_sat"]  = Label("Satellite")
        self["val_sat"]  = Label("---")
        self["lbl_freq"] = Label("Frequency")
        self["val_freq"] = Label("---")
        self["lbl_polar"] = Label("Polarization")
        self["val_polar"] = Label("---")
        self["lbl_sid"]  = Label("SID:")
        self["val_sid"]  = Label("---")
        self["lbl_vpid"] = Label("Video PID:")
        self["val_vpid"] = Label("---")
        self["lbl_apid"] = Label("Audio PID")
        self["val_apid"] = Label("---")
        self["lbl_pcr"]  = Label("PCR PID")
        self["val_pcr"]  = Label("---")
        self["lbl_caid"] = Label("CAIDs")
        self["val_caid"] = Label("---")
        self["ch_ref"] = Label("")
        self._hdr_timer = _init_header(self, 1000)
        _init_footer(self, ["About", "Browse", "Details", "Settings",
                            "Scan", "Zap", "Close"])
        self._pip_timer = _init_pip_panel(self, 2000)
        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {"cancel": self.close, "ok": self.close, "red": self.close},
            -2,
        )
        self._update_info()

    def _update_info(self):
        try:
            service = self.session.nav.getCurrentService()
            if not service:
                return
            info = service.info()
            if not info:
                return
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            self["ch_name"].setText(info.getName() or "Unknown")
            self["ch_ref"].setText(str(ref) if ref else "---")

            # Satellite info from ref
            if ref:
                ref_str = str(ref)
                parts = ref_str.split(":")
                if len(parts) >= 3:
                    orb = parts[3] if len(parts) > 3 else "?"
                    try:
                        orb_val = int(orb)
                        if orb_val > 1800:
                            sat_name = "{}W".format((3600 - orb_val) // 10)
                        else:
                            sat_name = "{}E".format(orb_val // 10)
                        self["val_sat"].setText(sat_name)
                    except Exception:
                        self["val_sat"].setText("Orb: " + orb)
                if len(parts) >= 4:
                    self["val_freq"].setText("{} MHz".format(parts[3]))
                if len(parts) >= 5:
                    pol_map = {"1": "H", "2": "V", "3": "L", "4": "R"}
                    self["val_polar"].setText(pol_map.get(parts[4], parts[4]))

            self["val_sid"].setText("0x{:04X}".format(info.getInfo(iServiceInformation.sSID)))
            self["val_vpid"].setText("0x{:04X}".format(info.getInfo(iServiceInformation.sVideoPID)))
            self["val_apid"].setText("0x{:04X}".format(info.getInfo(iServiceInformation.sAudioPID)))
            self["val_pcr"].setText("0x{:04X}".format(info.getInfo(iServiceInformation.sPCRPID)))

            caids = info.getInfoObject(iServiceInformation.sCAIDs)
            enc_type = _detect_encryption_type(info) if caids else "FTA"
            try:
                self["enc_badge"].setText(enc_type)
                badge_color = "#3fb950" if enc_type == "BISS" else ("#8b949e" if enc_type == "FTA" else "#f0883e")
                if hasattr(self["enc_badge"], "instance") and self["enc_badge"].instance:
                    self["enc_badge"].instance.setForegroundColor(parseColor(badge_color))
            except Exception:
                pass
            if caids:
                caid_str = ", ".join(["0x{:04X}".format(c) for c in caids])
                self["val_caid"].setText(caid_str)
                if BISS_CAID in list(caids):
                    try:
                        self["val_caid"].instance.setForegroundColor(parseColor("#00ff88"))
                    except Exception:
                        pass
            else:
                self["val_caid"].setText("None (FTA)")
        except Exception as e:
            log_debug("ChannelInfo error: {}".format(e))

    def close(self, *args, **kwargs):
        try:
            if self._pip_timer is not None:
                self._pip_timer.stop()
        except Exception:
            pass
        return Screen.close(self, *args, **kwargs)


# ------------------------------------------------------------------------------
# v2.6 - Feed List Screen (count in title + hint footer)
# ------------------------------------------------------------------------------
class AutoBissFeedList(Screen):
    skin = """
    <screen name="AutoBissFeedList" position="0,0" size="1920,1080" title="AutoBiss - Saved Keys" backgroundColor="#040a12" flags="wfNoBorder">
""" + _FS_BG + _FS_HEADER + _FS_SECTION + """
        <widget name="feedlist" position="74,286" size="812,640" font="Regular;22" itemHeight="44" />

        <widget name="status" position="74,930" size="812,26" font="Regular;16" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
""" + _FS_PIP + _FS_FOOTER + """
    </screen>
    """

    def __init__(self, session):
        self.skin = _render_skin(AutoBissFeedList.skin)
        Screen.__init__(self, session)
        self.title = "AutoBiss - Saved Keys"
        self["sec_left"] = Label("Saved BISS Keys")
        self["sec_right"] = Label("Channel Preview")
        if MenuList is not None:
            self["feedlist"] = MenuList([])
        else:
            from Components.MenuList import MenuList as _ML
            self["feedlist"] = _ML([])
        self["status"] = Label("Loading...")
        self._hdr_timer = _init_header(self, 1000)
        _init_footer(self, ["About", "Browse", "Details", "Settings",
                            "Scan", "Zap", "Close"])
        self._pip_timer = _init_pip_panel(self, 2000)
        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {"cancel": self.close, "ok": self.close, "red": self.close},
            -2,
        )
        self._load_feeds()

    def close(self, *args, **kwargs):
        try:
            if self._hdr_timer is not None:
                self._hdr_timer.stop()
        except Exception:
            pass
        try:
            if self._pip_timer is not None:
                self._pip_timer.stop()
        except Exception:
            pass
        return Screen.close(self, *args, **kwargs)

    def _load_feeds(self):
        try:
            rows = []
            cache = _background_service.cw_cache if _background_service else None
            if cache:
                for sid, cw, vpid, name in cache.all():
                    rows.append("{}  SID {}  {}{}****".format(
                        (name or 'AutoBiss')[:28].ljust(28),
                        "{:04X}".format(sid), (vpid or "...."), cw[:4]))
            if not rows:
                rows = ["No cached BISS keys found.", "",
                        "Keys are auto-cached when AutoBiss",
                        "decrypts a BISS channel."]
                self["sec_left"].setText("Saved BISS Keys")
                self["status"].setText("No keys cached yet")
            else:
                self["sec_left"].setText("Saved BISS Keys  ·  {}".format(len(rows)))
                src = getattr(cache, 'path', '')
                self["status"].setText(
                    "Total cached keys: {}   |   {}".format(len(rows), src))
            if not rows:
                rows = ["No saved BISS keys yet.", "",
                        "Keys are cached automatically when AutoBiss",
                        "decrypts a BISS channel."]
            try:
                self["feedlist"].setList(rows)
            except Exception:
                if MenuList is not None:
                    self["feedlist"] = MenuList(rows)
                else:
                    from Components.MenuList import MenuList as _ML
                    self["feedlist"] = _ML(rows)
        except Exception as e:
            log_debug("FeedList error: {}".format(e))
            self["status"].setText("Error loading feeds: {}".format(e))

    def close(self, *args, **kwargs):
        try:
            if self._hdr_timer is not None:
                self._hdr_timer.stop()
        except Exception:
            pass
        try:
            if self._pip_timer is not None:
                self._pip_timer.stop()
        except Exception:
            pass
        return Screen.close(self, *args, **kwargs)

# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# v2.8 - Live Feeds Screen (VPS feed board + zap)
# ------------------------------------------------------------------------------
def _fetch_live_feeds(since=None):
    """Download active feeds from VPS. Returns list of dicts (possibly empty).

    since: only return feeds discovered after this 'YYYY-MM-DD HH:MM:SS' UTC.
    """
    try:
        try:
            import urllib2 as _ul
        except ImportError:
            import urllib.request as _ul
        import ssl as _ssl
        import json as _json

        _LEGACY_KEY = "a1b2c3d4e5f678901234567890abcdef1234567890abcdef"
        token = None
        try:
            from Plugins.Extensions.AutoBiss.device import get_token
            token = get_token()
        except Exception:
            pass

        url = "https://tsdec.kingcs.xyz/autobiss/feeds"
        if since:
            try:
                from urllib.parse import quote
            except ImportError:
                from urllib import quote
            url += "?since={}".format(quote(since))
        req = _ul.Request(url)
        if token:
            req.add_header("X-Device-Token", token)
        else:
            req.add_header("X-API-Key", _LEGACY_KEY)
        try:
            ctx = _ssl.create_default_context()
        except Exception:
            ctx = _ssl._create_unverified_context()
        try:
            resp = _ul.urlopen(req, context=ctx, timeout=15)
        except TypeError:
            resp = _ul.urlopen(req, timeout=15)
        raw = resp.read()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "replace")
        data = _json.loads(raw)
        if isinstance(data, dict) and data.get("success") and isinstance(data.get("feeds"), list):
            return data["feeds"]
    except Exception as e:
        log_debug("_fetch_live_feeds error: {}".format(e))
    return []


def _feed_encrypted(feed):
    """True when the source marks the feed as encrypted (BISS candidate)."""
    fmt = (feed.get("format") or "").lower()
    return "crypt" in fmt


def _feed_422(feed):
    fmt = (feed.get("format") or "")
    return "4:2:2" in fmt


def _max_discovered(feeds):
    """Newest discovered_at timestamp in a feed list (YYYY-MM-DD HH:MM:SS)."""
    best = ""
    for f in feeds or []:
        try:
            v = (f.get("discovered_at") or f.get("start_time") or "").strip()
            if v and v > best:
                best = v
        except Exception:
            continue
    return best


class AutoBissLiveFeeds(Screen):
    skin = """
    <screen name="AutoBissLiveFeeds" position="0,0" size="1920,1080" title="AutoBiss - Live Feeds" backgroundColor="#040a12" flags="wfNoBorder">
""" + _FS_BG + _FS_HEADER + _FS_SECTION + """
        <widget name="col_time" position="90,238"  size="90,40"  font="Bold;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1330" />
        <widget name="col_sat"  position="196,238" size="120,40" font="Bold;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1330" />
        <widget name="col_tp"   position="330,238" size="280,40" font="Bold;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1330" />
        <widget name="col_id"   position="620,238" size="180,40" font="Bold;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1330" />
        <widget name="mark_box" position="778,164" size="98,38" cornerRadius="10" backgroundColor="#0a1524" />

        <widget name="feedlist" position="74,286" size="812,540" font="Fixed;22" itemHeight="44" />

        <widget name="status" position="74,906" size="812,26" font="Regular;16" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
        <widget name="btn_scan" position="74,848" size="262,44" font="Bold;18" halign="center" cornerRadius="8" foregroundColor="#101010" backgroundColor="#e3b341" />
        <widget name="btn_zap"  position="350,848" size="262,44" font="Bold;18" halign="center" cornerRadius="8" foregroundColor="#071018" backgroundColor="#2ea043" />
        <widget name="btn_exit" position="626,848" size="262,44" font="Bold;18" halign="center" cornerRadius="8" foregroundColor="#ffffff" backgroundColor="#d13b35" />
""" + _FS_PIP + _FS_FOOTER + """
    </screen>
    """

    def __init__(self, session):
        self.skin = _render_skin(AutoBissLiveFeeds.skin)
        Screen.__init__(self, session)
        self.session = session
        self.title = "AutoBiss - Live Feeds"
        self["sec_left"] = Label("Live Feeds")
        self["sec_right"] = Label("Channel Preview")
        self["mark_box"] = Label("")
        self["col_time"] = Label("TIME")
        self["col_sat"] = Label("SAT")
        self["col_tp"] = Label("TP")
        self["col_id"] = Label("FEED")
        # Must be a real MenuList: the skin binds this name to a list widget
        # and calls execBegin on it when the screen is built.
        if MenuList is not None:
            self["feedlist"] = MenuList([])
        else:
            from Components.MenuList import MenuList as _ML
            self["feedlist"] = _ML([])
        self["status"] = Label("Loading feeds from VPS...")
        self["btn_scan"] = Label("Search")
        self["btn_zap"] = Label("Zap")
        self["btn_exit"] = Label("Exit")
        self._hdr_timer = _init_header(self, 1000)
        self._pip_timer = _init_pip_panel(self, 2000)
        _init_footer(self, ["About", "Browse", "Details", "Settings",
                            "Search", "Zap", "Close"])
        self._feeds = []
        self._rows = []
        try:
            self["actions"] = ActionMap(
                ["OkCancelActions", "ColorActions"],
                {
                    "ok": self._details,
                    "cancel": self.close,
                    "red": self.close,
                    "green": self._zap,
                    "yellow": self._scan,
                },
                -2,
            )
        except Exception:
            self["actions"] = ActionMap(
                ["SetupActions", "ColorActions"],
                {"cancel": self.close, "ok": self._details,
                 "red": self.close, "green": self._zap, "yellow": self._scan},
                -2,
            )
        self._load()

    def _load(self):
        # Network I/O happens on a worker thread; UI widgets are only touched
        # from the main thread via _apply_result (Enigma2 requirement).
        def _worker():
            feeds = _fetch_live_feeds()
            self._pending = feeds if isinstance(feeds, list) else []
            self._result_timer.start(0, False)

        self._pending = []
        self._result_timer = eTimer()
        self._result_timer.callback.append(self._apply_result)
        import threading as _th
        t = _th.Thread(target=_worker)
        t.daemon = True
        t.start()

    def _apply_result(self):
        self._result_timer.stop()
        try:
            self._feeds = self._pending or []
            rows = []
            colors = []
            for f in self._feeds:
                try:
                    t = (f.get("start_time") or "")[11:16]
                    sat = (f.get("satellite") or "?").split("(")[0].strip()[:11]
                    freq = f.get("frequency") or "?"
                    pol = f.get("polarization") or "-"
                    sr = f.get("symbolrate") or ""
                    if _feed_422(f):
                        col = "#9e6a03"
                    elif _feed_encrypted(f):
                        col = "#b02a20"
                    else:
                        col = "#1f7a33"
                    colors.append(col)
                    title = (f.get("title") or "Feed")[:26]
                    rows.append("{:<6}{:<11}{:<3}{:<11}{:<26}".format(
                        t or "--:--", sat, pol,
                        "{} {}".format(freq, sr)[:11], title))
                except Exception:
                    continue
            self._rows = colors
            if not rows:
                rows = ["No live feeds right now.", "",
                        "Live feeds are refreshed automatically and",
                        "expire after their scheduled time."]
            # The skin already built the widget: update it in place with
            # setList(). Reassigning self["feedlist"] leaves the rendered
            # list empty because the GUI element is not re-bound.
            try:
                self["feedlist"].setList(rows)
            except Exception:
                if MenuList is not None:
                    self["feedlist"] = MenuList(rows)
                else:
                    from Components.MenuList import MenuList as _ML
                    self["feedlist"] = _ML(rows)
            try:
                from enigma import gFont
                self["feedlist"].l.setFont(0, gFont("Fixed", 22))
                self["feedlist"].l.setItemHeight(44)
            except Exception:
                pass
            # Recolour the row as the selection moves (MenuList owns the keys)
            try:
                if not getattr(self, "_sel_hook", False):
                    self._sel_hook = True
                    self["feedlist"].selectionChanged.append(self._on_sel)
            except Exception:
                pass
            self._on_sel()
            self["sec_left"].setText("Live Feeds  ·  {}".format(len(self._feeds)))
            self["status"].setText(
                "YELLOW: Search   ·   GREEN: Zap if in your list"
                if self._feeds else "Nothing scheduled right now")
        except Exception as e:
            log_debug("LiveFeeds apply error: {}".format(e))
            try:
                self["status"].setText("Error loading feeds")
            except Exception:
                pass

    def _on_sel(self, index=None):
        """Called by MenuList when the highlighted row changes."""
        try:
            if index is None:
                index = self._index()
            self._apply_row_color(index)
            self._fill_meta(index)
        except Exception:
            pass

    def _fill_meta(self, idx):
        """Show the selected feed details in the right hand card."""
        f = None
        if 0 <= idx < len(self._feeds):
            f = self._feeds[idx]
        if not f:
            return
        try:
            self["meta3"].setText((f.get("start_time") or "")[:16])
            self["meta4"].setText((f.get("satellite") or "?")[:24])
            self["meta5"].setText((f.get("creator") or f.get("category") or "")[:22])
            self["meta1"].setText(
                "{} {} {}".format(f.get("frequency") or "?", f.get("polarization") or "",
                                  f.get("symbolrate") or ""))
            self["meta2"].setText((f.get("format") or "?")[:22])
            # single coloured lamp: no status text, colour only
            if _feed_422(f):
                self._set_lamp("#9e6a03")
            elif _feed_encrypted(f):
                self._set_lamp("#b02a20")
            else:
                self._set_lamp("#1f7a33")
        except Exception as e:
            log_debug("meta fill error: {}".format(e))

    def _set_lamp(self, color):
        """Repaint the feed status button (colour only, no label)."""
        try:
            inst = self["mark_box"].instance
            if inst:
                inst.setBackgroundColor(_parse_color(color))
        except Exception as e:
            log_debug("lamp error: {}".format(e))

    def _apply_row_color(self, idx):
        """Keep the feed rows neutral: status is shown by the colour lamp."""
        try:
            self["feedlist"].l.setTextColor(_parse_color("#dbe4f0"))
        except Exception:
            pass

    def close(self, *args, **kwargs):
        try:
            self._result_timer.stop()
        except Exception:
            pass
        try:
            if self._hdr_timer is not None:
                self._hdr_timer.stop()
        except Exception:
            pass
        try:
            if self._pip_timer is not None:
                self._pip_timer.stop()
        except Exception:
            pass
        return Screen.close(self, *args, **kwargs)

    def _index(self):
        try:
            return self["feedlist"].getSelectedIndex()
        except Exception:
            return 0

    def _up(self):
        """MenuList handles navigation natively; kept for compatibility only."""
        pass

    def _down(self):
        """MenuList handles navigation natively; kept for compatibility only."""
        pass

    def _current(self):
        try:
            idx = self._index()
            if 0 <= idx < len(self._feeds):
                return self._feeds[idx]
        except Exception:
            pass
        return None

    def _details(self):
        f = self._current()
        if not f:
            return
        try:
            fmt = f.get("format") or "?"
            if _feed_422(f):
                fmt += "  (not supported by Enigma2)"
            lines = [
                str(f.get("title", "?")),
                "",
                "Satellite : {}".format(f.get("satellite", "?")),
                "Frequency : {} MHz  {}  SR {}".format(
                    f.get("frequency", "?"), f.get("polarization", ""),
                    f.get("symbolrate", "")),
                "Format    : {}".format(fmt),
                "Category  : {}".format(f.get("category") or "?"),
                "Reported  : {}   {}".format(
                    (f.get("start_time") or "?")[:16], f.get("creator") or ""),
            ]
            if f.get("infos"):
                lines.append("Info      : {}".format(f["infos"]))
            self.session.open(MessageBox, "\n".join(lines),
                              MessageBox.TYPE_INFO, timeout=10)
        except Exception as e:
            log_debug("LiveFeeds details error: {}".format(e))

    def _transponder(self):
        """Build an Enigma2 service reference for freq/pol, or None."""
        f = self._current()
        if not f:
            return None
        try:
            freq = str(f.get("frequency") or "").strip()
            pol = str(f.get("polarization") or "H").strip().upper()[:1]
            if not freq or not freq.isdigit():
                return None
            # orbit from the satellite label, e.g. "Eutelsat Hot Bird 13 (13.0E)"
            orb = 0
            sat = f.get("satellite") or ""
            if "(" in sat and ")" in sat:
                inner = sat[sat.rfind("(") + 1:sat.rfind(")")].replace(" ", "")
                try:
                    num = float(inner[:-1])
                    orb = int(round(num * 10))
                    if inner[-1:].upper() == "W":
                        orb = 3600 - orb
                except Exception:
                    orb = 0
            return freq, pol, orb
        except Exception:
            return None

    def _symbol_rate(self):
        """Symbol rate in kbaud from the feed, or None."""
        f = self._current()
        if not f:
            return None
        raw = str(f.get("symbolrate") or "").strip()
        if not raw:
            return None
        raw = raw.replace(" ", "").replace(" ", "")
        for dec in (".", ","):
            if dec in raw[1:]:
                try:
                    return int(round(float(raw.replace(dec, ".")) * 1000))
                except Exception:
                    return None
        digits = "".join(ch for ch in raw if ch.isdigit())
        if not digits:
            return None
        try:
            return int(digits)
        except Exception:
            return None

    def _scan(self):
        """Scan the feed transponder with the native Enigma2 service scan."""
        t = self._transponder()
        if not t:
            _notif_warning(self.session, "This feed has no frequency to scan.",
                           timeout=4)
            return
        freq, pol, orb = t
        sr = self._symbol_rate()
        f = self._current() or {}
        try:
            from enigma import eDVBFrontendParametersSatellite
            from Screens.ServiceScan import ServiceScan
            p = eDVBFrontendParametersSatellite()
            p.frequency = int(round(float(freq) * 1000))
            p.symbol_rate = (sr if sr else 27500) * 1000
            p.polarisation = (
                eDVBFrontendParametersSatellite.Polarisation_Vertical
                if pol == "V"
                else eDVBFrontendParametersSatellite.Polarisation_Horizontal)
            p.fec = eDVBFrontendParametersSatellite.FEC_Auto
            p.inversion = eDVBFrontendParametersSatellite.Inversion_Unknown
            p.orbital_position = orb
            p.system = eDVBFrontendParametersSatellite.System_DVB_S2
            p.modulation = eDVBFrontendParametersSatellite.Modulation_QPSK
            p.rolloff = eDVBFrontendParametersSatellite.RollOff_auto
            p.pilot = eDVBFrontendParametersSatellite.Pilot_Unknown
            p.is_id = eDVBFrontendParametersSatellite.No_Stream_Id_Filter
            p.pls_mode = eDVBFrontendParametersSatellite.PLS_Gold
            p.pls_code = eDVBFrontendParametersSatellite.PLS_Default_Gold_Code
            p.t2mi_plp_id = eDVBFrontendParametersSatellite.No_T2MI_PLP_Id
            p.t2mi_pid = eDVBFrontendParametersSatellite.T2MI_Default_Pid
            _notif_info(
                self.session,
                "SC Search: {} {} {} @ {}\n\n".format(
                    freq, pol, sr if sr else "auto", f.get("satellite") or "?"),
                timeout=3)
            log_debug("LiveFeeds scan start: {} {} SR={} orb={}".format(
                freq, pol, p.symbol_rate, p.orbital_position))
            self.session.open(ServiceScan, [{
                "transponders": [p],
                "feid": 0,
                "flags": 0,
                "networkid": 0,
            }])
        except Exception as e:
            log_debug("LiveFeeds ServiceScan error: {}".format(e))
            log_debug(traceback.format_exc())
            try:
                from Screens.ScanSetup import ScanSetup
                self.session.open(ScanSetup)
            except Exception as e2:
                log_debug("LiveFeeds scan error: {}".format(e2))
                _notif_error(
                    self.session,
                    "SC Search unavailable: {}".format(e2), timeout=5)

    def _zap(self):
        f = self._current()
        if not f:
            return
        ref = (f.get("service_ref") or "").strip()
        if not ref or not ref.startswith("1:0:"):
            t = self._transponder()
            where = "{} {} {}".format(*t) if t else "?"
            _notif_warning(
                self.session,
                "Imported feeds have no service reference.\n\n"
                "Transponder: {}\nSatellite:   {}\n\n"
                "Press YELLOW to open SC Search on it.".format(
                    where, f.get("satellite", "?")),
                timeout=9)
            return
        try:
            from ServiceReference import ServiceReference
            self.session.nav.playService(ServiceReference(ref))
            self.close()
        except Exception as e:
            log_debug("LiveFeeds zap error: {}".format(e))
            _notif_error(self.session, "Zap failed: {}".format(e), timeout=4)


# ------------------------------------------------------------------------------
# v2.7 - Settings Screen
# ------------------------------------------------------------------------------
class AutoBissSettings(Screen):
    skin = """
    <screen name="AutoBissSettings" position="0,0" size="1920,1080" title="AutoBiss Settings" backgroundColor="#040a12" flags="wfNoBorder">
""" + _FS_BG + _FS_HEADER + _FS_SECTION + """
        <widget name="opt0" position="74,320" size="812,66" font="Regular;22" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />
        <widget name="opt1" position="74,396" size="812,66" font="Regular;22" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />
        <widget name="opt2" position="74,472" size="812,66" font="Regular;22" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />
        <widget name="opt3" position="74,548" size="812,66" font="Regular;22" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />
        <widget name="opt4" position="74,624" size="812,66" font="Regular;22" halign="left" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="btn_save"   position="74,730"  size="396,60" font="Bold;22" halign="center" foregroundColor="#ffffff" backgroundColor="#0a1524" />
        <widget name="btn_cancel" position="490,730" size="396,60" font="Bold;22" halign="center" foregroundColor="#ffffff" backgroundColor="#0a1524" />

        <widget name="sysline" position="74,810" size="812,30" font="Regular;18" halign="left" foregroundColor="#8fa6c8" backgroundColor="#0a1524" />
""" + _FS_PIP + _FS_FOOTER + """
    </screen>
    """

    PATHS = ["auto"]
    DURS = [1, 2, 3, 5]
    COOLS = [30, 60, 120, 300]

    def __init__(self, session):
        self.skin = _render_skin(AutoBissSettings.skin)
        Screen.__init__(self, session)
        self.session = session
        self.title = "AutoBiss Settings"

        try:
            self.PATHS = ["auto"] + list(SOFTCAM_CANDIDATES)
        except Exception:
            pass

        self["sec_left"] = Label("Settings")
        self["sec_right"] = Label("Channel Preview")
        self["opt0"] = Label("")
        self["opt1"] = Label("")
        self["opt2"] = Label("")
        self["opt3"] = Label("")
        self["opt4"] = Label("")
        self["btn_save"] = Label("SAVE")
        self["btn_cancel"] = Label("CANCEL")
        self["sysline"] = Label("Settings are stored in /etc/enigma2")
        self._hdr_timer = _init_header(self, 1000)
        _init_footer(self, ["About", "Browse", "Details", "Settings",
                            "Scan", "Zap", "Close"])
        self._pip_timer = _init_pip_panel(self, 2000)

        try:
            cfg = load_settings()
        except Exception:
            cfg = {}
        self._path = cfg.get("softcam_path", "auto")
        self._dur = cfg.get("record_duration", 1)
        self._cool = cfg.get("cooldown", 60)
        self._notif = cfg.get("notifications", True)
        if self._path not in self.PATHS:
            self._path = "auto"
        if self._dur not in self.DURS:
            self._dur = 1
        if self._cool not in self.COOLS:
            self._cool = 60
        self._sel = 0
        self._render()

        try:
            self["actions"] = ActionMap(
                ["OkCancelActions", "ColorActions", "DirectionActions"],
                {
                    "ok":     self._ok,
                    "cancel": self.close,
                    "red":    self.close,
                    "green":  self._save,
                    "up":     self._up,
                    "down":   self._down,
                    "left":   self._left,
                    "right":  self._right,
                },
                -2,
            )
        except Exception:
            self["actions"] = ActionMap(
                ["SetupActions", "ColorActions"],
                {
                    "cancel": self.close,
                    "ok":     self._ok,
                    "red":    self.close,
                    "green":  self._save,
                },
                -2,
            )

    def _rows(self):
        path_txt = "Auto" if self._path == "auto" else self._path
        return [
            "SoftCam path: {}".format(path_txt),
            "Record duration: {} s".format(self._dur),
            "Cooldown: {} s".format(self._cool),
            "Notifications: {}".format("On" if self._notif else "Off"),
            "Cleanup AutoBiss keys",
        ]

    def _render(self):
        rows = self._rows()
        for i in range(5):
            try:
                name = "opt{}".format(i)
                self[name].setText(rows[i])
                inst = self[name].instance
                if inst:
                    if i == self._sel:
                        inst.setBackgroundColor(_parse_color("#00e5ff"))
                        inst.setForegroundColor(_parse_color("#0a0f16"))
                    else:
                        inst.setBackgroundColor(_parse_color("#161e2b"))
                        inst.setForegroundColor(_parse_color("#ffffff"))
            except Exception as e:
                log_debug("Settings render error: {}".format(e))

    def _up(self):
        self._sel = (self._sel - 1) % 5
        self._render()

    def _down(self):
        self._sel = (self._sel + 1) % 5
        self._render()

    def _cycle(self, direction):
        try:
            if self._sel == 0:
                idx = self.PATHS.index(self._path) if self._path in self.PATHS else 0
                self._path = self.PATHS[(idx + direction) % len(self.PATHS)]
            elif self._sel == 1:
                idx = self.DURS.index(self._dur) if self._dur in self.DURS else 0
                self._dur = self.DURS[(idx + direction) % len(self.DURS)]
            elif self._sel == 2:
                idx = self.COOLS.index(self._cool) if self._cool in self.COOLS else 0
                self._cool = self.COOLS[(idx + direction) % len(self.COOLS)]
            elif self._sel == 3:
                self._notif = not self._notif
        except Exception as e:
            log_debug("Settings cycle error: {}".format(e))
        self._render()

    def _left(self):
        self._cycle(-1)

    def _right(self):
        self._cycle(1)

    def _current_dict(self):
        return {
            "softcam_path": self._path,
            "record_duration": self._dur,
            "cooldown": self._cool,
            "notifications": self._notif,
        }

    def _ok(self):
        if self._sel == 4:
            self._cleanup()
        else:
            self._cycle(1)

    def _cleanup(self):
        try:
            n = remove_autobiss_keys()
            try:
                reload_softcam()
            except Exception:
                pass
            _notif_info(self.session,
                        "Removed {} AutoBiss key lines from SoftCam.Key".format(n),
                        timeout=4)
        except Exception as e:
            log_debug("Cleanup action error: {}".format(e))

    def _save(self):
        cfg = self._current_dict()
        ok = False
        try:
            ok = save_settings(cfg)
        except Exception as e:
            log_debug("Settings save error: {}".format(e))
        try:
            global _background_service
            if _background_service is not None:
                _background_service._record_duration = cfg["record_duration"]
                _background_service._cooldown_secs = cfg["cooldown"]
                _background_service._notify = cfg["notifications"]
                try:
                    _notif_set_enabled(cfg["notifications"])
                except Exception:
                    pass
        except Exception as e:
            log_debug("Settings apply error: {}".format(e))
        if ok:
            _notif_info(self.session, "Settings saved", timeout=3)
        else:
            _notif_error(self.session, "Failed to save settings", timeout=4)
        self.close()

    def close(self, *args, **kwargs):
        try:
            if self._pip_timer is not None:
                self._pip_timer.stop()
        except Exception:
            pass
        return Screen.close(self, *args, **kwargs)


# ------------------------------------------------------------------------------
# v2.4 - Feed Scanner (daily auto-scan)
# ------------------------------------------------------------------------------
_FEED_SCAN_INTERVAL = 24 * 60 * 60 * 1000  # 24 hours in ms

def _start_feed_scan_timer(service):
    """Start a 24-hour timer to refresh cached CW keys."""
    try:
        if hasattr(service, '_feed_scan_timer'):
            return
        service._feed_scan_timer = eTimer()
        service._feed_scan_timer.callback.append(lambda: _do_feed_scan(service))
        service._feed_scan_timer.start(_FEED_SCAN_INTERVAL, False)
        log_debug("Feed scan timer started (24h interval)")
    except Exception as e:
        log_debug("Feed scan timer error: {}".format(e))

def _do_feed_scan(service):
    """Refresh CW cache by re-reading the persisted keys file."""
    try:
        log_debug("Feed scan: refreshing CW cache")
        if hasattr(service, 'cw_cache'):
            n = service.cw_cache.reload()
            log_debug("Feed scan: cache refreshed ({} keys)".format(n))
    except Exception as e:
        log_debug("Feed scan error: {}".format(e))


# ------------------------------------------------------------------------------
# v2.4 - Multi-emulator support helper
# ------------------------------------------------------------------------------
def _detect_all_emulators():
    """Detect all running emulators (OSCam, NCam, etc.)."""
    emulators = []
    try:
        import subprocess
        result = subprocess.Popen(
            ["ps", "aux"], stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        out, _ = result.communicate()
        if isinstance(out, bytes):
            out = out.decode('utf-8', errors='replace')
        for line in out.split('\n'):
            lower = line.lower()
            if 'oscam' in lower and 'grep' not in lower:
                emulators.append('OSCam')
            elif 'ncam' in lower and 'grep' not in lower:
                emulators.append('NCam')
    except Exception:
        pass
    return list(set(emulators))


# ------------------------------------------------------------------------------
# v2.4 - Encryption type detection
# ------------------------------------------------------------------------------
def _detect_encryption_type(info):
    """Detect encryption type: BISS, PowerVu, Irdeto, Nagravision, etc."""
    try:
        caids = info.getInfoObject(iServiceInformation.sCAIDs)
        if not caids:
            return "FTA"
        caid_list = list(caids)
        if BISS_CAID in caid_list:
            return "BISS"
        # PowerVu CAIDs
        pvu_caids = [0x0B00, 0x0B01, 0x0B02, 0x0B03, 0x0B04, 0x0B05]
        for c in caid_list:
            if c in pvu_caids:
                return "PowerVu"
        # Nagravision
        if 0x0100 in caid_list or 0x0101 in caid_list:
            return "Nagravision"
        # Irdeto
        if 0x0600 in caid_list or 0x0601 in caid_list or 0x0602 in caid_list:
            return "Irdeto"
        # VideoGuard
        if 0x0900 in caid_list or 0x0960 in caid_list:
            return "VideoGuard"
        # Mediaguard
        if 0x0500 in caid_list:
            return "Mediaguard"
        return "Unknown (CAID: 0x{:04X})".format(caid_list[0])
    except Exception:
        return "Unknown"

# ------------------------------------------------------------------------------
# Plugin Entry Points
# ------------------------------------------------------------------------------
def autobiss_start(session, **kwargs):
    global _background_service
    # If WHERE_SESSIONSTART never fired (e.g. after a broken install), create on demand
    if _background_service is None:
        try:
            log_debug("autobiss_start: background service missing, creating on demand")
            _background_service = AutoBissBackgroundService(session)
        except Exception as e:
            log_debug("autobiss_start: on-demand service creation failed: {}".format(e))
    session.open(AutoBissMainScreen)

def autobiss_session_start(reason, session=None):
    if reason == 0 and session is not None:
        log_debug("autobiss_session_start: creating background service")
        global _background_service
        _background_service = AutoBissBackgroundService(session)

def Plugins(**kwargs):
    log_debug("Plugins() registering descriptors")
    descs = []
    # WHERE_PLUGINMENU = appears in Menu -> Plugins (the GREEN menu)
    try:
        descs.append(PluginDescriptor(
            name="AutoBiss E2",
            description="AutoBiss Professional BISS Interface",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=autobiss_start,
        ))
        log_debug("Registered WHERE_PLUGINMENU")
    except Exception as e:
        log_debug("WHERE_PLUGINMENU not available: {}".format(e))
    descs.append(PluginDescriptor(
        name="AutoBiss E2",
        description="AutoBiss Professional BISS Interface",
        where=PluginDescriptor.WHERE_EXTENSIONSMENU,
        fnc=autobiss_start,
    ))
    descs.append(PluginDescriptor(
        name="AutoBiss E2",
        description="AutoBiss background BISS recorder",
        where=PluginDescriptor.WHERE_SESSIONSTART,
        fnc=autobiss_session_start,
    ))
    return descs
