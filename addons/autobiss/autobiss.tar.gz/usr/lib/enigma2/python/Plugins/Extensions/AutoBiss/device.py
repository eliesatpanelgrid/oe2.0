# -*- coding: utf-8 -*-
"""
AutoBiss E2 - Device Identity & Registration Module
Generates a stable per-device fingerprint, manages the device token,
and handles first-boot registration with the VPS.
Compatible with Python 2.7 and Python 3.x
"""
from __future__ import absolute_import, print_function, division

import hashlib
import json
import os
import threading
from time import strftime

# ── Paths ─────────────────────────────────────────────────────────────────────
# Enigma2 receivers often have a read-only /etc — use the first writable location.
def _find_conf_dir():
    candidates = [
        '/media/hdd/.autobiss',   # internal HDD  (preferred, persistent)
        '/media/usb/.autobiss',   # USB stick      (persistent)
        '/media/cf/.autobiss',    # CF card        (persistent)
        '/hdd/.autobiss',         # alt HDD mount  (persistent)
    ]
    for path in candidates:
        parent = os.path.dirname(path)
        if not os.path.isdir(parent):
            continue
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
            test = os.path.join(path, '.w')
            with open(test, 'w') as f:
                f.write('x')
            os.remove(test)
            return path
        except Exception:
            pass
    # Last resort: /tmp  (volatile — re-registers after reboot, harmless)
    fallback = '/tmp/autobiss'
    try:
        if not os.path.isdir(fallback):
            os.makedirs(fallback)
    except Exception:
        pass
    return fallback

CONF_DIR       = _find_conf_dir()
TOKEN_FILE     = os.path.join(CONF_DIR, 'token')
DEVICE_ID_FILE = os.path.join(CONF_DIR, 'device_id')
REGISTER_URL   = "https://tsdec.kingcs.xyz/autobiss/register"
_DEBUG_PATH    = "/tmp/autobiss_debug.log"

# ── Logging ───────────────────────────────────────────────────────────────────
def _log(msg):
    try:
        with open(_DEBUG_PATH, 'a') as f:
            f.write("[{}] [device] {}\n".format(strftime("%Y-%m-%d %H:%M:%S"), msg))
        try:
            os.chmod(_DEBUG_PATH, 0o600)
        except Exception:
            pass
    except Exception:
        pass

# ── Config directory ──────────────────────────────────────────────────────────
def _ensure_conf_dir():
    if not os.path.isdir(CONF_DIR):
        try:
            os.makedirs(CONF_DIR)
            os.chmod(CONF_DIR, 0o700)
        except Exception as e:
            _log("Cannot create conf dir: {}".format(e))

# ── Device fingerprint ────────────────────────────────────────────────────────
def _collect_hardware_info():
    """
    Gather stable hardware identifiers in priority order.
    Returns a combined string that is unique to this physical receiver.
    """
    parts = []

    # 1. First valid MAC address (most reliable on every Enigma2 box)
    for iface in ['eth0', 'eth1', 'eth2', 'wlan0', 'br0']:
        try:
            with open('/sys/class/net/{}/address'.format(iface)) as f:
                mac = f.read().strip().upper()
            if mac and mac not in ('00:00:00:00:00:00', 'FF:FF:FF:FF:FF:FF'):
                parts.append('mac:{}:{}'.format(iface, mac))
                break
        except Exception:
            pass

    # 2. CPU serial / hardware from /proc/cpuinfo
    try:
        with open('/proc/cpuinfo', 'r') as f:
            for line in f:
                low = line.lower()
                if 'serial' in low or 'hardware' in low:
                    parts.append(line.strip())
    except Exception:
        pass

    # 3. Standard Linux machine-id
    for path in ('/etc/machine-id', '/var/lib/dbus/machine-id'):
        try:
            with open(path) as f:
                mid = f.read().strip()
            if mid:
                parts.append('mid:{}'.format(mid))
                break
        except Exception:
            pass

    # 4. Last resort: persist a random token as the fingerprint seed
    if not parts:
        seed_path = os.path.join(CONF_DIR, '.seed')
        try:
            with open(seed_path) as f:
                seed = f.read().strip()
        except Exception:
            import random
            seed = '{:032x}'.format(random.getrandbits(128))
            _ensure_conf_dir()
            try:
                with open(seed_path, 'w') as f:
                    f.write(seed)
                os.chmod(seed_path, 0o600)
            except Exception:
                pass
        parts.append('seed:{}'.format(seed))
        _log("WARNING: no hardware ID found, using persisted random seed")

    return '|'.join(parts)

def get_device_id():
    """
    Return a stable 64-char hex device ID (SHA-256 of hardware fingerprint).
    Result is cached in DEVICE_ID_FILE so the fingerprint only runs once.
    """
    # Return cached ID if available and valid
    if os.path.isfile(DEVICE_ID_FILE):
        try:
            with open(DEVICE_ID_FILE) as f:
                did = f.read().strip()
            if len(did) == 64 and all(c in '0123456789abcdef' for c in did):
                return did
        except Exception:
            pass

    # Generate from hardware
    raw = _collect_hardware_info()
    device_id = hashlib.sha256(raw.encode('utf-8')).hexdigest()

    # Cache to disk
    _ensure_conf_dir()
    try:
        with open(DEVICE_ID_FILE, 'w') as f:
            f.write(device_id)
        os.chmod(DEVICE_ID_FILE, 0o600)
        _log("Device ID generated and cached")
    except Exception as e:
        _log("Cannot cache device ID: {}".format(e))

    return device_id

# ── Token management ──────────────────────────────────────────────────────────
def get_token():
    """Return the device token string, or None if not registered yet."""
    try:
        with open(TOKEN_FILE) as f:
            token = f.read().strip()
        return token if token else None
    except Exception:
        return None

def save_token(token):
    """Write the device token to disk (root-only, chmod 600). Returns True on success."""
    _ensure_conf_dir()
    try:
        with open(TOKEN_FILE, 'w') as f:
            f.write(token.strip())
        os.chmod(TOKEN_FILE, 0o600)
        _log("Device token saved")
        return True
    except Exception as e:
        _log("Cannot save token: {}".format(e))
        return False

def is_registered():
    """Return True if a device token exists on disk."""
    return get_token() is not None

# ── SSL helper ────────────────────────────────────────────────────────────────
def _build_ssl_ctx():
    try:
        import ssl
        try:
            return ssl.create_default_context()
        except Exception:
            return ssl._create_unverified_context()
    except Exception:
        return None

def _open_url(req, ssl_ctx, timeout):
    try:
        import urllib2 as _ul
    except ImportError:
        import urllib.request as _ul
    try:
        try:
            return _ul.urlopen(req, context=ssl_ctx, timeout=timeout)
        except TypeError:
            return _ul.urlopen(req, timeout=timeout)
    except Exception as e:
        # SSL cert fallback for old receivers
        err = str(e).upper()
        if ssl_ctx is not None and any(k in err for k in ('CERT', 'SSL', 'CERTIFICATE')):
            import ssl as _ssl
            fallback = _ssl._create_unverified_context()
            try:
                return _ul.urlopen(req, context=fallback, timeout=timeout)
            except Exception as e2:
                raise IOError("{} / SSL fallback: {}".format(e, e2))
        raise

# ── Registration ──────────────────────────────────────────────────────────────
def register(callback=None):
    """
    Launch a daemon thread that registers this device with the VPS.
    On success the token is saved to disk and callback(token) is called.
    On failure callback(None) is called.
    """
    t = threading.Thread(target=_register_worker, args=(callback,))
    t.daemon = True
    t.start()

def _register_worker(callback):
    device_id = get_device_id()
    _log("Registering — device_id prefix: {}...".format(device_id[:8]))

    try:
        import urllib.request as _ul
    except ImportError:
        import urllib2 as _ul

    try:
        payload = json.dumps({"device_id": device_id})
        data    = payload.encode('utf-8') if isinstance(payload, str) else payload

        req = _ul.Request(REGISTER_URL, data=data)
        req.add_header("Content-Type", "application/json")

        ssl_ctx  = _build_ssl_ctx()
        response = _open_url(req, ssl_ctx, timeout=15)

        raw = response.read()
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8')
        result = json.loads(raw)

    except Exception as e:
        _log("Registration network error: {}".format(e))
        if callback:
            try:
                callback(None)
            except Exception:
                pass
        return

    if result.get('success') and result.get('token'):
        token = str(result['token'])
        if save_token(token):
            _log("Registration successful")
            if callback:
                try:
                    callback(token)
                except Exception:
                    pass
        else:
            _log("Registration OK but token could not be saved")
            if callback:
                try:
                    callback(None)
                except Exception:
                    pass
    else:
        msg = result.get('message', 'no detail')
        _log("Registration rejected by server: {}".format(msg))
        if callback:
            try:
                callback(None)
            except Exception:
                pass
