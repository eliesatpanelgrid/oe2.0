# -*- coding: utf-8 -*-
# Copyright (C) 2023 jbleyel
#
# OAWeatheriet5 is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# dogtag is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with OAWeatheriet5.  If not, see <https://www.gnu.org/licenses/>.

from Components.Renderer.Renderer import Renderer
from enigma import ePixmap
try:
	from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO, BT_HALIGN_CENTER, BT_VALIGN_CENTER
except ImportError:
	# DreamOS does not export these scaling constants - use safe defaults
	BT_SCALE = 0
	BT_KEEP_ASPECT_RATIO = 0
	BT_HALIGN_CENTER = 0
	BT_VALIGN_CENTER = 0
from os.path import exists
import sys

PY3 = sys.version_info[0] >= 3

try:
	text_type = unicode
except NameError:
	text_type = str


class OAWeatheriet5Pixmap(Renderer):
	def __init__(self):
		Renderer.__init__(self)
		self.iconFileName = ""

	GUI_WIDGET = ePixmap

	def postWidgetCreate(self, instance):
		try:
			if hasattr(instance, "setPixmapScaleFlags"):
				instance.setPixmapScaleFlags(BT_SCALE | BT_KEEP_ASPECT_RATIO | BT_HALIGN_CENTER | BT_VALIGN_CENTER)
		except Exception:
			pass
		self.changed((self.CHANGED_DEFAULT,))

	def _normalize_path(self, value):
		if not value:
			return ""
		if PY3:
			if isinstance(value, bytes):
				try:
					return value.decode("utf-8", "ignore")
				except Exception:
					return ""
			return str(value)
		if isinstance(value, text_type):
			try:
				return value.encode("utf-8")
			except Exception:
				try:
					return str(value)
				except Exception:
					return ""
		try:
			return str(value)
		except Exception:
			return ""

	def changed(self, what):
		if self.instance:
			pngname = ""
			if what[0] != self.CHANGED_CLEAR:
				pngname = self._normalize_path(getattr(self.source, "iconfilename", ""))
			if not pngname or not exists(pngname):
				self.instance.hide()
			else:
				self.instance.show()
				if self.iconFileName != pngname:
					try:
						self.instance.setPixmapFromFile(pngname)
						self.iconFileName = pngname
					except Exception:
						self.instance.hide()
