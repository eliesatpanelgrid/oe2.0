# -*- coding: utf-8 -*-
# Copyright (C) 2023 jbleyel, Mr.Servo
#
# OAWeatheriet5 is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# dogtag is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with OAWeatheriet5.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import print_function, division
import re
import sys
from datetime import datetime, timedelta
from math import pi, floor, cos
from Components.config import config
from Components.Sources.Source import Source
from Plugins.Extensions.OAWeatheriet5.plugin import weatherhandler
from Plugins.Extensions.OAWeatheriet5.plugin_utils import logger
import gettext
_ = gettext.gettext

PY3 = sys.version_info[0] >= 3

try:
	text_type = unicode
except NameError:
	text_type = str

CITY_AREA_FORMAT = "%s, %s"


class OAWeatheriet5(Source):
	YAHOOnightswitch = {
		"3": "47", "4": "47", "11": "45", "12": "45", "13": "46", "14": "46", "15": "46", "16": "46", "28": "27",
		"30": "29", "32": "31", "34": "33", "37": "47", "38": "47", "40": "45", "41": "46", "42": "46", "43": "46"
	}
	METEOnightswitch = {"1": "2", "3": "4", "B": "C", "H": "I", "J": "K"}

	YAHOOdayswitch = {"27": "28", "29": "30", "31": "32", "33": "34", "45": "39", "46": "16", "47": "4"}

	METEOdayswitch = {"2": "1", "3": "4", "C": "B", "I": "H", "K": "J"}

	services = {"MSN": "msn", "OpenMeteo": "omw", "openweather": "owm"}

	def __init__(self):
		Source.__init__(self)
		self.enabledebug = config.plugins.OAWeatheriet5.debug.value
		weatherhandler.onUpdate.append(self.callbackUpdate)
		self.data = weatherhandler.getData() or {}
		self.valid = weatherhandler.getValid()
		self.skydirs = weatherhandler.getSkydirs()
		self.na = _("n/a")
		self.pressunit = self.getVal("pressunit")
		self.tempunit = self.getVal("tempunit")
		self.windunit = self.getVal("windunit")
		self.visibilityunit = self.getVal("visibiliyunit")
		self.precipitationtext = "Precipitation"
		self.humiditytext = "Humidity"
		self.feelsliketext = "Feels like"
		self.logo = self.services.get(config.plugins.OAWeatheriet5.weatherservice.value, "msn")
		self.pluginpath = None
		self.iconpath = None

	def debug(self, text):
		if self.enabledebug:
			print("[OAWeatheriet5] Source DEBUG %s" % text)

	def callbackUpdate(self, data):
		self.debug("callbackUpdate: %s" % str(data))
		self.data = data or {}
		self.valid = weatherhandler.getValid()
		if hasattr(config.plugins, 'OAWeatheriet5'):
			self.logo = self.services.get(config.plugins.OAWeatheriet5.weatherservice.value, "msn")
		self.pressunit = self.getVal("pressunit")
		self.tempunit = self.getVal("tempunit")
		self.windunit = self.getVal("windunit")
		self.visibilityunit = self.getVal("visibiliyunit")
		self.changed((self.CHANGED_ALL,))

	def getValid(self):
		return self.valid

	def getVal(self, key):
		return self.data.get(key, self.na) if self.data else self.na

	def getCurrentVal(self, key, default=_("n/a")):
		self.debug("getCurrentVal:%s" % key)
		val = self.data.get("current", {}).get(key, default)
		self.debug("current key val: %s" % val)
		return val

	def getWeatherSource(self):
		return self.getCurrentVal("source")

	def getCity(self):
		return self.getVal("name")

	def _to_text(self, value):
		if value is None:
			return ""
		if PY3:
			return value.decode("utf-8", "ignore") if isinstance(value, bytes) else str(value)
		if isinstance(value, text_type):
			return value
		try:
			return value.decode("utf-8", "ignore")
		except Exception:
			try:
				return text_type(value)
			except Exception:
				return str(value)

	def _get_observation_components(self, default=_("n/a")):
		value = self.getCurrentVal("observationPoint", default) or default
		return self._to_text(value).split(", ")

	def getCityArea(self, default=_("n/a")):
		components = self._get_observation_components(default)
		len_components = len(components)
		if len_components > 1:
			return CITY_AREA_FORMAT % (components[0], components[1])
		if len_components == 1:
			return "%s" % components[0]
		else:
			return default

	def getCityCountry(self, default=_("n/a")):
		components = self._get_observation_components(default)
		len_components = len(components)
		if len_components > 1:
			return CITY_AREA_FORMAT % (components[0], components[1])
		if len_components == 1:
			return "%s" % components[0]
		else:
			return default

	def CityCountry(self, default=_("n/a")):
		return self.getCityCountry(default)

	def CityCountryArea(self, default=_("n/a")):
		components = self._get_observation_components(default)
		len_components = len(components)
		if len_components > 2:
			return "%s, %s, %s" % (components[0], components[-1], components[1])
		if len_components == 2:
			return "%s, %s" % (components[0], components[-1])
		if len_components == 1:
			return "%s" % components[0]
		else:
			return default

	def getCityAreaCountry(self):
		return self.getCurrentVal("observationPoint")

	def _normalize_iso_datetime(self, value):
		value = self._to_text(value).strip()
		if not value:
			return ""
		value = value.replace("Z", "")
		if "." in value:
			value = value.split(".", 1)[0]
		match = re.search(r"([+-]\d{2}:?\d{2})$", value)
		if match and match.start() > 10:
			value = value[:match.start()]
		return value

	def _parse_datetime(self, val):
		"""Compatible datetime parser for both Python 2.7 and 3.x"""
		val = self._normalize_iso_datetime(val)
		if not val:
			return None

		# Python 3: try fromisoformat if available
		if PY3 and hasattr(datetime, 'fromisoformat'):
			try:
				return datetime.fromisoformat(val)
			except Exception:
				pass

		# Fallback valid for Python 2 and Python 3
		formats = [
			"%Y-%m-%d %H:%M:%S",
			"%Y-%m-%dT%H:%M:%S",
			"%Y-%m-%d %H:%M",
			"%Y-%m-%dT%H:%M",
			"%Y-%m-%d"
		]

		# Python 2 strptime strict byte string requirement
		if not PY3:
			try:
				if isinstance(val, unicode):
					val = val.encode("ascii", "ignore")
				else:
					val = str(val)
			except Exception:
				pass

		for fmt in formats:
			try:
				return datetime.strptime(val, fmt)
			except Exception:
				continue

		return None

	def getObservationTime(self):
		val = self.getCurrentVal("observationTime", "")
		dt = self._parse_datetime(val)
		return dt.strftime("%H:%M") if dt else self.na

	def getSunrise(self):
		val = self.getCurrentVal("sunrise", "")
		dt = self._parse_datetime(val)
		return dt.strftime("%H:%M") if dt else self.na

	def getSunset(self):
		val = self.getCurrentVal("sunset", "")
		dt = self._parse_datetime(val)
		return dt.strftime("%H:%M") if dt else self.na

	def _is_optional_moon_time_unsupported(self, value):
		value = self._to_text(value).strip()
		if value:
			return False
		if not hasattr(config.plugins, 'OAWeatheriet5'):
			return False
		return config.plugins.OAWeatheriet5.weatherservice.value in ("OpenMeteo", "openweather")

	def getMoonrise(self):
		val = self.getCurrentVal("moonrise", "")
		dt = self._parse_datetime(val)
		if dt:
			return dt.strftime("%H:%M")
		return "" if self._is_optional_moon_time_unsupported(val) else self.na

	def getMoonset(self):
		val = self.getCurrentVal("moonset", "")
		dt = self._parse_datetime(val)
		if dt:
			return dt.strftime("%H:%M")
		return "" if self._is_optional_moon_time_unsupported(val) else self.na

	def getDate(self, day):
		val = self.getKeyforDay("date", day, "")
		dt = self._parse_datetime(val)
		return dt.strftime("%d. %b") if dt else self.na

	def getIsNight(self):
		current = self.data.get("current", {}) if self.data else {}
		fallback = str(current.get("isNight", "False")) == "True"
		sunrise = self._parse_datetime(current.get("sunrise", ""))
		sunset = self._parse_datetime(current.get("sunset", ""))
		currtime = (
			self._parse_datetime(current.get("observationTime", "")) or
			self._parse_datetime(current.get("created", "")) or
			datetime.today()
		)
		if sunrise is not None and sunset is not None and currtime is not None:
			result = currtime < sunrise or currtime >= sunset
			try:
				logger.info(
					"Source.getIsNight: obs=%s sunrise=%s sunset=%s fallback=%s result=%s" % (
						self._to_text(current.get("observationTime", current.get("created", ""))),
						self._to_text(current.get("sunrise", "")),
						self._to_text(current.get("sunset", "")),
						str(fallback),
						str(result)
					)
				)
			except Exception:
				pass
			return result
		try:
			logger.info(
				"Source.getIsNight fallback: obs=%s sunrise=%s sunset=%s fallback=%s" % (
					self._to_text(current.get("observationTime", current.get("created", ""))),
					self._to_text(current.get("sunrise", "")),
					self._to_text(current.get("sunset", "")),
					str(fallback)
				)
			)
		except Exception:
			pass
		return fallback

	def getTemperature(self):
		return self._compose_value_unit(self.getCurrentVal("temp"), self.tempunit)

	def getFeeltemp(self, full=False):
		text = "%s " % self.feelsliketext if full else ""
		value = self._compose_value_unit(self.getCurrentVal("feelsLike"), self.tempunit)
		return "%s%s" % (text, value)

	def getHumidity(self, full=False):
		text = "%s " % self.humiditytext if full else ""
		value = self._compose_value_unit(self.getCurrentVal("humidity"), "%")
		return "%s%s" % (text, value)

	def getRainText(self):
		return self.getCurrentVal("raintext", "")

	def _compose_value_unit(self, value, unit):
		value = self._to_text(value).strip() if value is not None else ""
		unit = self._to_text(unit).strip() if unit is not None else ""
		if not value or value.lower() == "n/a":
			return self.na
		if not unit or unit.lower() == "n/a":
			return value
		return "%s %s" % (value, unit)

	def _to_float(self, value):
		value = self._to_text(value).strip() if value is not None else ""
		if not value or value.lower() == "n/a":
			return None
		try:
			return float(value)
		except Exception:
			return None

	def _format_number(self, value):
		if value is None:
			return self.na
		value = round(float(value), 1)
		return str(int(value)) if int(value) == value else str(value)

	def _convert_wind_value(self, value, unit):
		unit = self._to_text(unit).strip() if unit is not None else ""
		numeric = self._to_float(value)
		if numeric is None:
			return self.na, unit
		if unit == "km/h" and hasattr(config.plugins, 'OAWeatheriet5') and config.plugins.OAWeatheriet5.windspeedMetricUnit.value == "m/s":
			numeric /= 3.6
			unit = "m/s"
		return self._format_number(numeric), unit

	def _format_degree_value(self, value):
		value = self._to_text(value).strip() if value is not None else ""
		if not value or value.lower() == "n/a":
			return self.na
		return "%s %s" % (value, u"\u00b0")

	def _wind_dir_parts(self, value):
		value = self._to_text(value).strip() if value is not None else ""
		if not value or value in ("*", "* *"):
			return []
		return [part for part in value.split(" ") if part]

	def getWindSpeed(self):
		windSpeed, windunit = self._convert_wind_value(self.getCurrentVal("windSpeed"), self.getVal("windunit"))
		return self._compose_value_unit(windSpeed, windunit)

	def getWindDir(self):
		return self._format_degree_value(self.getCurrentVal("windDir"))

	def getWindDirSign(self):
		return self.getCurrentVal("windDirSign", "")

	def getWindDirsign(self):
		return self.getWindDirSign()

	def getWindDirName(self):
		parts = self._wind_dir_parts(self.getCurrentVal("windDirSign", ""))
		if len(parts) > 1:
			return self.skydirs.get(parts[1], parts[1])
		if len(parts) == 1:
			return self.skydirs.get(parts[0], parts[0])
		return self.na

	def getWindDirArrow(self):
		parts = self._wind_dir_parts(self.getCurrentVal("windDirSign", ""))
		return parts[0] if parts else ""

	def getWindDirShort(self):
		parts = self._wind_dir_parts(self.getCurrentVal("windDirSign", ""))
		return parts[1] if len(parts) > 1 else (parts[0] if parts else "")

	def getWindGusts(self):
		windGusts, windunit = self._convert_wind_value(self.getCurrentVal("windGusts"), self.windunit)
		return self._compose_value_unit(windGusts, windunit)

	def getUVindex(self):
		return self.getCurrentVal("uvIndex", "")

	def getVisibility(self):
		return self._compose_value_unit(self.getCurrentVal("visibility", self.na), self.visibilityunit)

	def getPressure(self):
		return self._compose_value_unit(self.getCurrentVal("pressure", self.na), self.pressunit)

	def getAveragePressure(self, day):
		return self._compose_value_unit(self.getKeyforDay("pressure", day), self.pressunit)

	def getMaxTemp(self, day):
		return self._compose_value_unit(self.getKeyforDay("maxTemp", day), self.tempunit)

	def getMinTemp(self, day):
		return self._compose_value_unit(self.getKeyforDay("minTemp", day), self.tempunit)

	def getMaxMinTemp(self, day):
		min_temp = self._compose_value_unit(self.getKeyforDay("minTemp", day), "")
		max_temp = self._compose_value_unit(self.getKeyforDay("maxTemp", day), self.tempunit)
		return "%s / %s" % (min_temp, max_temp)

	def getMaxFeelsLike(self, day):
		return self._compose_value_unit(self.getKeyforDay("maxFeelsLike", day), self.tempunit)

	def getMinFeelsLike(self, day):
		return self._compose_value_unit(self.getKeyforDay("minFeelsLike", day), self.tempunit)

	def getMaxWindSpeed(self, day):
		maxwindspeed, windunit = self._convert_wind_value(self.getKeyforDay("maxWindSpeed", day), self.windunit)
		return "%s %s" % (maxwindspeed, windunit)

	def getMinWindSpeed(self, day):
		minwindspeed = self.getKeyforDay("minWindSpeed", day, self.getKeyforDay("maxWindSpeed", day))
		minwindspeed, windunit = self._convert_wind_value(minwindspeed, self.windunit)
		return "%s %s" % (minwindspeed, windunit)

	def getDomWindDir(self, day):
		return self._format_degree_value(self.getKeyforDay("domWindDir", day))

	def getDomWindDirSign(self, day):
		val = self.getKeyforDay("domWindDirSign", day, "")
		return val if val else self.na

	def getDomWindDirName(self, day):
		parts = self._wind_dir_parts(self.getKeyforDay("domWindDirSign", day))
		if len(parts) > 1:
			return self.skydirs.get(parts[1], parts[1])
		if len(parts) == 1:
			return self.skydirs.get(parts[0], parts[0])
		return self.na

	def getDomWindDirArrow(self, day):
		parts = self._wind_dir_parts(self.getKeyforDay("domWindDirSign", day))
		return parts[0] if parts else ""

	def getDomWindDirShort(self, day):
		parts = self._wind_dir_parts(self.getKeyforDay("domWindDirSign", day))
		return parts[1] if len(parts) > 1 else (parts[0] if parts else "")

	def getMaxWindGusts(self, day):
		maxWindGusts, windunit = self._convert_wind_value(self.getKeyforDay("maxWindGusts", day), self.windunit)
		return "%s %s" % (maxWindGusts, windunit)

	def getMaxUvIndex(self, day):
		return "%s" % self.getKeyforDay("maxUvIndex", day, "")

	def getMaxVisibility(self, day):
		return self._compose_value_unit(self.getKeyforDay("maxVisibility", day), self.visibilityunit)

	def getPrecipitation(self, day, full=False):
		text = "%s " % self.precipitationtext if full else ""
		value = self._compose_value_unit(self.getKeyforDay("precipitation", day), self.getVal("precunit"))
		return "%s%s" % (text, value)

	def getYahooCode(self, day):
		iconcode = self.getKeyforDay("yahooCode", day, "")
		is_night = day == 0 and hasattr(config.plugins, 'OAWeatheriet5') and config.plugins.OAWeatheriet5.nighticons.value and self.getIsNight()
		if is_night:
			iconcode = self.YAHOOnightswitch.get(iconcode, iconcode)
		else:
			iconcode = self.YAHOOdayswitch.get(iconcode, iconcode)
		try:
			if day == 0:
				logger.info("Source.getYahooCode day0: resolved=%s raw=%s isNight=%s" % (str(iconcode), str(self.getKeyforDay("yahooCode", day, "")), str(is_night)))
		except Exception:
			pass
		return iconcode

	def getMeteoCode(self, day):
		iconcode = self.getKeyforDay("meteoCode", day, "")
		is_night = day == 0 and hasattr(config.plugins, 'OAWeatheriet5') and config.plugins.OAWeatheriet5.nighticons.value and self.getIsNight()
		if is_night:
			iconcode = self.METEOnightswitch.get(iconcode, iconcode)
		else:
			iconcode = self.METEOdayswitch.get(iconcode, iconcode)
		return iconcode

	def getMoonIllumination(self):
		moonIllum = self.moonIllumination(self.moonPosition(datetime.today()))
		if config.plugins.OAWeatheriet5.trendarrows.value:
			ta = config.plugins.OAWeatheriet5.trendarrows.getText()
			if moonIllum > 0 and ta and len(ta) > 0:
				illumArrow = (str(ta[0]) + " ") if self.moonIllumination(self.moonPosition(datetime.today() - timedelta(hours=1))) < moonIllum else (str(ta[1]) + " ")
			else:
				illumArrow = "● "
		else:
			illumArrow = ""
		return "%s%s %s" % (illumArrow, round(moonIllum, 1), "%")

	def getMoonDistance(self):
		moonDist = self.moonDistance(datetime.today())
		if config.plugins.OAWeatheriet5.trendarrows.value:
			ta = config.plugins.OAWeatheriet5.trendarrows.getText()
			distArrow = (str(ta[0]) + " ") if self.moonDistance(datetime.today() - timedelta(hours=1)) < moonDist else (str(ta[1]) + " ")
		else:
			distArrow = ""
		return "%s%s %s" % (distArrow, round(moonDist), "km")

	def getMoonPixFilename(self):
		moonPhases = ["new_moon", "waxing_crescent", "first_quarter", "waxing_gibbous", "full_moon", "waning_gibbous", "last_quarter", "waning_crescent"]
		return "%s.png" % moonPhases[self.moonPhase(self.moonPosition(datetime.today()))]

	def moonIllumination(self, pos):
		illum = 100 - abs((cos(pi * pos) + 0j) ** 1.7 * 100)
		return abs(illum - 1) / .99 if illum - 1 > 0 else 0.0

	# Author: Sean B. Palmer, Source: https://inamidst.com/code/moonphase.py
	def moonPosition(self, now=None):
		if now is None:
			now = datetime.today()
		diff = now - datetime(2001, 1, 1)
		days = diff.days + diff.seconds / 86400
		lunations = 0.20439731 + days * 0.03386319269
		return lunations % float(1)

	def moonPhase(self, pos):
		index = (pos * float(8)) + float("0.5")
		index = floor(index)
		return int(index) & 7

	# series expansion of the moon orbital elements from Chapront and Chapront-Touzé
	# Sources: htps://de.wikipedia.org/wiki/Mondbahn, https://articles.adsabs.harvard.edu/full/1994A%26A...282..663S
	def moonDistance(self, now=None):
		if now is None:
			now = datetime.today()
		diff = now - datetime(2000, 1, 1, 12, 0, 0)
		t = diff.days + diff.seconds / 86400
		GM = (134.96341138 + 13.064992953630 * t) * pi / 180
		DD = (297.85020420 + 12.190749117502 * t) * pi / 90
		return 385000.5584 - 20905.3550 * cos(GM) - 3699.1109 * cos(DD - GM) - 2955.9676 * cos(DD) - 569.9251 * cos(2 * GM)

	def getKeyforDay(self, key, day, default=_("n/a")):
		self.debug("getKeyforDay key:%s day:%s default:%s" % (key, day, default))
		if day == 0:
			return self.data.get("current", {}).get(key, default) if self.data else default
		else:
			index = day - 1
			val = self.data.get("forecast", {}).get(index, {}).get(key, default)
			self.debug("getKeyforDay key:%s day:%s / val:%s" % (key, day, val))
			return val

	def destroy(self):
		weatherhandler.onUpdate.remove(self.callbackUpdate)
		Source.destroy(self)
