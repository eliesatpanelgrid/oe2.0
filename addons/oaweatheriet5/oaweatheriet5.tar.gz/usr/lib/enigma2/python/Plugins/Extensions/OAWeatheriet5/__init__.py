# -*- coding: utf-8 -*-

from __future__ import print_function
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext
import os


def _get_version():
	try:
		with open(os.path.join(os.path.dirname(__file__), 'version.txt'), 'r') as f:
			return f.read().strip()
	except Exception:
		return "4.1"

def _read_text_file(path, default=""):
	if not os.path.exists(path):
		return default
	try:
		with open(path, "r") as f:
			data = f.read()
	except Exception:
		return default

	try:
		if isinstance(data, bytes):
			return data.decode("utf-8", "ignore")
	except Exception:
		pass

	return data

def _collect_image_probe_text():
	parts = []
	for probe_path in (
		"/etc/image-version",
		"/etc/issue",
		"/etc/os-release",
		"/etc/opkg/all-feed.conf",
		"/etc/opkg/official-feed.conf",
	):
		content = _read_text_file(probe_path, "").strip().lower()
		if content:
			parts.append(content)
	return "\n".join(parts)

def _detect_image_flags():
	"""
	Unified image detection used by the whole plugin.

	Goals:
	- Avoid duplicate/contradicting detection logic.
	- Avoid false Dreambox detection on OpenATV / VTI / OpenPLI images.
	- Keep the conditions explicit so other files can branch safely per image.
	"""
	probe_text = _collect_image_probe_text()

	is_vti = (
		os.path.exists("/etc/vti-version") or
		"vti" in probe_text
	)

	is_openatv = (
		os.path.exists("/etc/openatv-version") or
		"openatv" in probe_text
	)

	is_openpli = "openpli" in probe_text

	dream_markers = (
		"/etc/dpkg/origins/dreambox",
		"/etc/dreambox-image-version",
		"/etc/opkg/dreambox-feed.conf",
	)

	is_dreambox = any(os.path.exists(path) for path in dream_markers)

	if not is_dreambox:
		if any(marker in probe_text for marker in (
			"dreambox",
			"dreamos",
			"dream multimedia",
			"dream property"
		)):
			is_dreambox = True

	# Fallback only when image is not already recognized as OpenATV / VTI / OpenPLI
	if not is_dreambox and not is_openatv and not is_vti and not is_openpli:
		if (
			os.path.exists("/usr/bin/apt-get") and
			(os.path.exists("/etc/apt") or os.path.exists("/var/lib/dpkg/status"))
		):
			is_dreambox = True

	is_open_source_image = bool(not is_dreambox)

	return {
		"isDreambox": bool(is_dreambox),
		"isVTi": bool(is_vti),
		"isOpenATV": bool(is_openatv),
		"isOpenPLI": bool(is_openpli),
		"isOpenSourceImage": is_open_source_image,
	}

__version__ = _get_version()

PluginLanguageDomain = 'OAWeatheriet5'
PluginLanguagePath = 'Extensions/OAWeatheriet5/locale'
PluginLanguageFallbackPath = os.path.join(os.path.dirname(__file__), 'locale')

IMAGE_INFO = _detect_image_flags()
isDreambox = IMAGE_INFO["isDreambox"]
isVTi = IMAGE_INFO["isVTi"]
isOpenATV = IMAGE_INFO["isOpenATV"]
isOpenPLI = IMAGE_INFO["isOpenPLI"]
isOpenSourceImage = IMAGE_INFO["isOpenSourceImage"]

def _get_locale_path():
	try:
		resolved = resolveFilename(SCOPE_PLUGINS, PluginLanguagePath)
	except Exception:
		resolved = ""

	if resolved and os.path.exists(resolved):
		return resolved

	return PluginLanguageFallbackPath


def localeInit():
	try:
		lang = language.getLanguage() or ""
	except Exception:
		lang = ""

	if lang:
		lang_short = lang[:2]
		try:
			if lang_short and lang_short != lang:
				os.environ["LANGUAGE"] = "%s:%s" % (lang, lang_short)
			else:
				os.environ["LANGUAGE"] = lang
		except Exception:
			pass

	try:
		gettext.bindtextdomain(PluginLanguageDomain, _get_locale_path())
	except Exception:
		pass

if isDreambox:
	def _(txt):
		return gettext.dgettext(PluginLanguageDomain, txt) if txt else ""
else:
	def _(txt):
		if not txt:
			return ""
		try:
			translated = gettext.dgettext(PluginLanguageDomain, txt)
			if translated and translated != txt:
				return translated
		except Exception:
			pass
		try:
			return gettext.gettext(txt)
		except Exception:
			return txt

localeInit()

try:
	language.addCallback(localeInit)
except Exception:
	pass