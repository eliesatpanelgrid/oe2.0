# -*- coding: utf-8 -*-
# Ported from TheWeatherIet5 by Antigravity for OAWeatheriet5
# Enhanced with multi-step search strategy for robust city discovery.

import os
import sys
import json
import re
import ast
try:
    import ssl
except Exception:
    ssl = None

PY3 = sys.version_info[0] >= 3
if PY3:
    unicode = str
    from urllib.parse import quote as _urllib_quote
    from urllib.request import Request, urlopen
else:
    unicode = unicode
    from urllib import quote as _urllib_quote
    from urllib2 import Request, urlopen

DEFAULT_HTTP_HEADERS = {
    "User-Agent": "Enigma2-TheWeather", # Matches the working plugin exactly
    "Accept": "application/json,text/plain,*/*",
    "Accept-Encoding": "identity",
    "Connection": "close",
}

LEGACY_COORDS_LOCATION_RE = re.compile(
    r"^\(\s*(?:u)?['\"](?P<label>.+?)['\"]\s*,\s*(?P<lat>-?\d+(?:\.\d+)?)\s*,\s*(?P<lon>-?\d+(?:\.\d+)?)\s*\)$"
)

def _ensure_text(value):
    if value is None:
        return ""
    if PY3:
        if isinstance(value, bytes):
            return value.decode("utf-8", "ignore")
        return str(value)
    if isinstance(value, unicode):
        return value
    try:
        return value.decode("utf-8", "ignore")
    except Exception:
        try:
            return unicode(value)
        except Exception:
            return str(value)

def _format_location_coordinate(value):
    try:
        if value is None: return ""
        text_value = ("%.6f" % float(value)).rstrip("0").rstrip(".")
        if text_value in ("", "-0"):
            return "0"
        return text_value
    except Exception:
        return ""

def _split_precise_location(location_name):
    location_text = " ".join(_ensure_text(location_name).strip().split())
    legacy_match = LEGACY_COORDS_LOCATION_RE.match(location_text)
    if legacy_match:
        label_text = " ".join(_ensure_text(legacy_match.group("label")).strip().split())
        lat_text = _format_location_coordinate(legacy_match.group("lat"))
        lon_text = _format_location_coordinate(legacy_match.group("lon"))
        return label_text, lat_text, lon_text
    if location_text.startswith("(") and location_text.endswith(")"):
        try:
            legacy_value = ast.literal_eval(location_text)
            if isinstance(legacy_value, tuple) and len(legacy_value) >= 3:
                label_text = " ".join(_ensure_text(legacy_value[0]).strip().split())
                lat_text = _format_location_coordinate(legacy_value[1])
                lon_text = _format_location_coordinate(legacy_value[2])
                if label_text and lat_text and lon_text:
                    return label_text, lat_text, lon_text
        except Exception:
            pass
    if "@" not in location_text:
        return "", "", ""
    label_text, coords_text = location_text.rsplit("@", 1)
    if "," not in coords_text:
        return " ".join(_ensure_text(label_text).strip().split()), "", ""
    lat_text, lon_text = coords_text.split(",", 1)
    lat_text = _format_location_coordinate(lat_text.strip())
    lon_text = _format_location_coordinate(lon_text.strip())
    label_text = " ".join(_ensure_text(label_text).strip().split())
    return label_text, lat_text, lon_text

def _quote(value):
    value = _ensure_text(value)
    if PY3:
        return _urllib_quote(value)
    if isinstance(value, unicode):
        value = value.encode("utf-8", "ignore")
    return _urllib_quote(value)

def _urlopen_compat(request, timeout=10, headers=None):
    prepared_headers = dict(DEFAULT_HTTP_HEADERS)
    if isinstance(headers, dict):
        prepared_headers.update(headers)
    if hasattr(request, "get_full_url"):
        prepared_request = request
        request_url = prepared_request.get_full_url()
    else:
        request_url = _ensure_text(request)
        prepared_request = Request(request_url, headers=prepared_headers)

    def _open_with_context(context=None):
        try:
            if context is not None:
                return urlopen(prepared_request, timeout=timeout, context=context)
            return urlopen(prepared_request, timeout=timeout)
        except TypeError:
            return urlopen(prepared_request, None, timeout)

    try:
        return _open_with_context()
    except Exception:
        if ssl is not None and request_url.startswith("https://"):
            try:
                return _open_with_context(ssl._create_unverified_context())
            except Exception:
                pass
        raise

def _read_json_url(request, timeout=10, headers=None):
    response = _urlopen_compat(request, timeout, headers)
    try:
        return json.loads(_ensure_text(response.read()))
    finally:
        try:
            response.close()
        except:
            pass

def _parse_precise_location(location_name):
    label_text, lat_text, lon_text = _split_precise_location(location_name)
    if not lat_text or not lon_text:
        return None, None, label_text
    try:
        display_name = label_text or " ".join(_ensure_text(location_name).strip().split())
        return float(lat_text), float(lon_text), display_name
    except Exception:
        return None, None, label_text

# --- Geocoding Logic Constants ---
GEOCODING_TIMEOUT = 10
GEOCODING_SEARCH_COUNT = 50

COMMON_COUNTRIES = {
    "algeria": "DZ", "algerie": "DZ", "france": "FR", "egypt": "EG", "misr": "EG", 
    "morocco": "MA", "maroc": "MA", "tunisia": "TN", "tunisie": "TN", "libya": "LY", 
    "saudi arabia": "SA", "uea": "AE", "uae": "AE", "qatar": "QA", "kuwait": "KW", 
    "iraq": "IQ", "jordan": "JO", "syria": "SY", "lebanon": "LB", "palestine": "PS", 
    "yemen": "YE", "oman": "OM", "turkey": "TR", "turkiye": "TR", "italy": "IT", 
    "spain": "ES", "germany": "DE", "belgium": "BE", "netherlands": "NL", 
    "ukraine": "UA", "russia": "RU",
    u"\u0627\u0644\u062c\u0632\u0627\u0626\u0631": "DZ",
    u"\u0645\u0635\u0631": "EG",
    u"\u0627\u0644\u0645\u063a\u0631\u0628": "MA",
    u"\u062a\u0648\u0646\u0633": "TN",
    u"\u0644\u064a\u0628\u064a\u0627": "LY",
    u"\u0627\u0644\u0633\u0639\u0648\u062f\u064a\u0629": "SA",
    u"\u0627\u0644\u0627\u0645\u0627\u0631\u0627\u062a": "AE",
    u"\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062a": "AE",
    u"\u0642\u0637\u0631": "QA",
    u"\u0627\u0644\u0643\u0648\u064a\u062a": "KW",
    u"\u0627\u0644\u0639\u0631\u0627\u0642": "IQ",
    u"\u0627\u0644\u0627\u0631\u062f\u0646": "JO",
    u"\u0627\u0644\u0623\u0631\u062f\u0646": "JO",
    u"\u0633\u0648\u0631\u064a\u0627": "SY",
    u"\u0644\u0628\u0646\u0627\u0646": "LB",
    u"\u0641\u0644\u0633\u0637\u064a\u0646": "PS",
    u"\u0627\u0644\u064a\u0645\u0646": "YE",
    u"\u0639\u0645\u0627\u0646": "OM",
    u"\u062a\u0631\u0643\u064a\u0627": "TR",
}

def _is_arabic(text):
    return any(u"\u0600" <= c <= u"\u06FF" for c in _ensure_text(text))

def _parse_location_query(cityname):
    city_text = _ensure_text(cityname).strip()
    country_code = ""
    # Remove coords if they exist
    if "@" in city_text:
        city_text = city_text.split("@", 1)[0].strip()
    
    # Pre-clean: collapse whitespace
    city_text = " ".join(city_text.split())

    if "," in city_text:
        parts = city_text.split(",", 1)
        city_text = parts[0].strip()
        country_part = parts[1].strip().lower()
        if country_part in COMMON_COUNTRIES:
            country_code = COMMON_COUNTRIES[country_part]
        elif len(country_part) == 2:
            country_code = country_part.upper()
            
    if not country_code:
        words = city_text.split()
        if len(words) > 1:
            last_word = words[-1].lower()
            if last_word in COMMON_COUNTRIES:
                country_code = COMMON_COUNTRIES[last_word]
                city_text = " ".join(words[:-1])
            elif len(words) > 2:
                last_two_words = " ".join(words[-2:]).lower()
                if last_two_words in COMMON_COUNTRIES:
                    country_code = COMMON_COUNTRIES[last_two_words]
                    city_text = " ".join(words[:-2])
    return city_text.strip(), country_code

def _append_unique_part(parts, value):
    value = _ensure_text(value).strip()
    if not value: return
    for p in parts:
        if p.lower() == value.lower(): return
    parts.append(value)

def _build_display_name(result, fallback_name=""):
    parts = []
    _append_unique_part(parts, result.get("name", fallback_name))
    _append_unique_part(parts, result.get("admin1", ""))
    _append_unique_part(parts, result.get("country", result.get("country_code", "")))
    if parts:
        return ", ".join(parts)
    return _ensure_text(fallback_name).strip()

def search_locations(cityname, count=GEOCODING_SEARCH_COUNT):
    lat, lon, display_name = _parse_precise_location(cityname)
    if lat is not None and lon is not None:
        return [{"label": display_name or _ensure_text(cityname).strip(), "lon": lon, "lat": lat}]

    city_query, country_code = _parse_location_query(cityname)
    if not city_query:
        return []

    # -- MULTI-STEP SEARCH STRATEGY --
    search_variations = [
        # 1. Exact name + Country Code
        (city_query, country_code),
        # 2. Exact name (no country code)
        (city_query, ""),
        # 3. Hyphenated name + Country Code (e.g. Ech-Chettia)
        (city_query.replace(" ", "-"), country_code) if " " in city_query else (None, None),
    ]

    results_found = []
    for q_name, q_country in search_variations:
        if q_name is None: continue
        
        try:
            url = "https://geocoding-api.open-meteo.com/v1/search?name=%s&count=%s&format=json" % (_quote(q_name), count)
            if q_country:
                url += "&countryCode=%s" % _quote(q_country)
            if _is_arabic(cityname):
                url += "&language=ar"
            
            print("[WeatherSearch] STEP Trying URL: %s" % url)
            res = _read_json_url(url, GEOCODING_TIMEOUT)
            
            if res and "results" in res and res["results"]:
                print("[WeatherSearch] Results found for query: %s" % q_name)
                for result in res["results"]:
                    lat_val = result.get("latitude")
                    lon_val = result.get("longitude")
                    if lat_val is not None and lon_val is not None:
                        d_name = _build_display_name(result, q_name)
                        results_found.append({
                            "label": d_name,
                            "lon": float(lon_val),
                            "lat": float(lat_val)
                        })
                break # Stop at the first step that returns results
        except Exception as e:
            print("[WeatherSearch] Step error: %s" % str(e))

    # If NO results found at all, then and ONLY then fall back to partial name
    if not results_found and len(city_query.split()) > 1:
        print("[WeatherSearch] No results for full name. Falling back to partial name.")
        broad_query = city_query.split()[0] # Try just first word
        return search_locations(broad_query, count)

    return results_found
