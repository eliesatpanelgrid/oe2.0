# -*- coding: utf-8 -*-

from __future__ import print_function

#Created by iet5
import json
import pickle
from time import time
from xml.etree.ElementTree import parse, tostring
from os import chmod, fsync, remove, rename
from os.path import exists, getmtime, isfile, join

from twisted.internet import reactor
from twisted.internet.reactor import callInThread

from enigma import eTimer
from Components.config import ConfigSelection, config
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Tools.Directories import SCOPE_CONFIG, resolveFilename
from Tools.Weatherinfo import Weatherinfo
from .WeatherSearch import search_locations

from . import __version__, _, isDreambox, isOpenATV
from .plugin_utils import (
	CACHEFILE,
	GEODATA,
	MODULE_NAME,
	PLUGINPATH,
	get_iconset_path,
	logger,
	text_type,
	_to_text_compat,
	_to_gui_text_compat,
	_unique_preserve_order_compat,
	PY3,
	_normalize_choice_value_compat
)


def _get_osd_language_compat():
	try:
		language_value = getattr(getattr(config, "osd", None), "language", None)
		language_value = getattr(language_value, "value", language_value)
	except Exception:
		language_value = ""
	language_value = _to_text_compat(language_value).strip().replace("_", "-").lower()
	return language_value or "en-en"


def _register_timer_callback(timer, callback):
	try:
		timer.callback.append(callback)
		return True
	except Exception:
		pass
	try:
		timer.timeout.get().append(callback)
		return True
	except Exception:
		pass
	try:
		timer.timeout.connect(callback)
		return True
	except Exception:
		pass
	return False

class WeatherHelper:
	def __init__(self):
		self.version = __version__
		if isDreambox:
			self.favoritefile = "/etc/enigma2/oaweatheriet5_fav.json"
		else:
			self.favoritefile = self.get_writable_path("oaweatheriet5_fav.json")
		logger.info("Using favorite file: %s" % _to_text_compat(self.favoritefile))
		self.locationDefault = (GEODATA[0], 8.68417, 50.11552)
		self.favoriteList = []

		try:
			self.readFavoriteList()
			self.syncWithConfig()
		except Exception as e:
			logger.error("Initialization error: %s" % _to_text_compat(e))
			self.favoriteList = [self.locationDefault]

			config.plugins.OAWeatheriet5.weathercity.value = self.locationDefault[0]
			config.plugins.OAWeatheriet5.owm_geocode.value = "%s,%s" % (self.locationDefault[1], self.locationDefault[2])
			config.plugins.OAWeatheriet5.weathercity.save()
			config.plugins.OAWeatheriet5.owm_geocode.save()

			self.updateConfigChoices()

	@staticmethod
	def searchLocation(city_name, callback, session):
		"""Static method to search locations safely"""
		def async_search():
			try:
				geodatalist = search_locations(city_name)

				if not geodatalist:
					raise Exception(_("No locations found"))

				results = []
				for item in geodatalist:
					try:
						results.append((_to_text_compat(item["label"]), float(item["lon"]), float(item["lat"])))
					except Exception:
						pass

				if not results:
					raise Exception(_("No valid locations found"))

				def show_results():
					try:
						choice_list = []
						for item in results:
							label = u"%s [lon=%.3f, lat=%.3f]" % (item[0], item[1], item[2])
							choice_list.append((_to_gui_text_compat(label), item))
						session.openWithCallback(
							lambda result: WeatherHelper._safeCallback(callback, _normalize_choice_value_compat(result)),
							ChoiceBox,
							title=_("Select location"),
							list=choice_list
						)
					except Exception as open_error:
						logger.error("ChoiceBox open error: %s" % _to_text_compat(open_error))
						WeatherHelper._safeCallback(callback, None)

				reactor.callFromThread(show_results)

			except Exception as e:
				logger.error("Search error: %s" % _to_text_compat(e))
				reactor.callFromThread(WeatherHelper._safeCallback, callback, None)
				try:
					reactor.callFromThread(session.open, MessageBox, _to_gui_text_compat(e), MessageBox.TYPE_ERROR)
				except Exception:
					pass

		callInThread(async_search)

	@staticmethod
	def _safeCallback(callback, result):
		"""Safely execute callback if it exists"""
		if callable(callback):
			try:
				callback(result)
			except Exception as e:
				logger.error("Callback error: %s" % _to_text_compat(e))

	def normalizeLocation(self, location):
		if isinstance(location, list):
			location = tuple(location)
		if PY3 and isinstance(location, bytes):
			try:
				location = location.decode("utf-8", "ignore")
			except Exception:
				return None
		if isinstance(location, text_type):
			value = location.strip()
			if value.startswith("(") and value.endswith(")"):
				try:
					import ast
					location = ast.literal_eval(value)
				except Exception:
					return None

		# After literal_eval, it might be a list again
		if isinstance(location, list):
			location = tuple(location)

		if not isinstance(location, tuple) or len(location) < 3:
			return None
		try:
			name = _to_text_compat(location[0]).strip()
			return (name, float(location[1]), float(location[2]))
		except Exception:
			return None

	def applyLocationConfig(self, location, save=False, persist=False):
		location = self.normalizeLocation(location)
		if not location:
			return None
		config.plugins.OAWeatheriet5.weatherlocation.value = location
		config.plugins.OAWeatheriet5.weathercity.value = location[0]
		config.plugins.OAWeatheriet5.owm_geocode.value = "%s,%s" % (location[1], location[2])
		if save:
			try:
				config.plugins.OAWeatheriet5.weatherlocation.save()
			except Exception:
				pass
			config.plugins.OAWeatheriet5.weathercity.save()
			config.plugins.OAWeatheriet5.owm_geocode.save()
		if persist:
			try:
				config.plugins.OAWeatheriet5.save()
			except Exception:
				pass
			try:
				config.save()
			except Exception:
				pass
		return location

	def getFavoriteLocation(self, location):
		location = self.normalizeLocation(location)
		if not location:
			return None
		for favorite in self.favoriteList:
			if not self.isDifferentLocation(location, favorite):
				return favorite
		return None

	def _locationFromCityGeocode(self):
		current_city = getattr(config.plugins.OAWeatheriet5.weathercity, "value", "")
		current_geocode = getattr(config.plugins.OAWeatheriet5.owm_geocode, "value", "")
		if not current_city or not current_geocode:
			return None
		try:
			lon, lat = map(float, _to_text_compat(current_geocode).split(","))
		except Exception:
			return None
		return self.normalizeLocation((current_city, lon, lat))

	def resolveConfiguredLocation(self, require_favorite=False):
		candidates = [
			self.normalizeLocation(getattr(config.plugins.OAWeatheriet5.weatherlocation, "value", None)),
			self._locationFromCityGeocode()
		]
		for candidate in candidates:
			if not candidate:
				continue
			favorite = self.getFavoriteLocation(candidate)
			if favorite:
				return favorite
			if not require_favorite:
				return candidate
		return None

	def syncWithConfig(self):
		"""Synchronize config with the preference list"""
		try:
			resolved_location = self.resolveConfiguredLocation(require_favorite=False)
			current_favorite = self.getFavoriteLocation(resolved_location)
			if current_favorite:
				self.updateConfigChoices()
				self.applyLocationConfig(current_favorite, save=True)
				return current_favorite

			if resolved_location and resolved_location != self.locationDefault:
				default_favorite = self.getFavoriteLocation(self.locationDefault)
				if not self.favoriteList or (len(self.favoriteList) == 1 and default_favorite and not self.isDifferentLocation(self.favoriteList[0], default_favorite)):
					self.addFavorite(resolved_location)
					resolved_location = self.getFavoriteLocation(resolved_location) or resolved_location
				logger.info("syncWithConfig: keeping configured location %s" % repr(resolved_location))
				self.updateConfigChoices()
				self.applyLocationConfig(resolved_location, save=True)
				return resolved_location

			self.updateConfigChoices()
			if self.favoriteList:
				fallback_location = self.resolveConfiguredLocation(require_favorite=True) or self.favoriteList[0]
			else:
				self.favoriteList = [self.locationDefault]
				self.updateConfigChoices()
				fallback_location = self.locationDefault
			self.applyLocationConfig(fallback_location, save=True)
			return fallback_location
		except Exception as e:
			logger.error("Error in syncWithConfig: %s" % _to_text_compat(e))
		return None

	def get_writable_path(self, filename):
		# Prioritize /etc/enigma2/ for DreamOS/OpenSource images.
		# AVOID resolveFilename(SCOPE_HDD) and avoid writing .test files if possible
		# as they trigger intrusive 'change storage devices' notifications in Gemini.
		if exists("/etc/enigma2"):
			return "/etc/enigma2/" + filename
		try:
			path = resolveFilename(SCOPE_CONFIG, filename)
			if path:
				return path
		except Exception:
			pass

		# Fallback to /tmp/ which is always writable and safe
		return join("/tmp", filename)

	def saveFavorites(self):
		"""Improved version but with the same name for compatibility"""
		try:
			logger.info("Saving %d favorites to %s" % (len(self.favoriteList), self.favoritefile))

			temp_file = "%s.tmp" % self.favoritefile

			try:
				import codecs
				file_handle = codecs.open(temp_file, "w", "utf-8")
			except Exception as e:
				logger.error("Temp write open error: %s" % _to_text_compat(e))
				return False

			try:
				json.dump(self.favoriteList, file_handle, indent=2, ensure_ascii=False)
				file_handle.flush()
				try:
					fsync(file_handle.fileno())
				except Exception:
					pass
			finally:
				file_handle.close()

			try:
				rename(temp_file, self.favoritefile)
			except Exception as e:
				logger.error("Rename failed: %s" % _to_text_compat(e))
				return False

			try:
				chmod(self.favoritefile, 0o644)
			except Exception:
				pass
			logger.info("Favorites saved successfully")
			return True

		except Exception as e:
			logger.error("Main save error: %s" % _to_text_compat(e))

			try:
				if exists("/etc/enigma2"):
					fallback = "/etc/enigma2/oaweatheriet5_fav.json"
				else:
					fallback = resolveFilename(SCOPE_CONFIG, "oaweatheriet5_fav.json")
				import codecs
				file_handle = codecs.open(fallback, "w", "utf-8")
				try:
					json.dump(self.favoriteList, file_handle, indent=2, ensure_ascii=False)
				finally:
					file_handle.close()

				logger.info("Fallback used: %s" % fallback)
				return True

			except Exception as fallback_error:
				logger.critical("Fallback error: %s" % _to_text_compat(fallback_error))
				return False

	def showFavoriteSelection(self, session, callback):
		choiceList = [(_to_gui_text_compat(item[0]), item) for item in self.favoriteList]
		session.openWithCallback(
			lambda favorite: self.handleFavoriteSelection(favorite, callback) if favorite else None,
			ChoiceBox,
			title=_("Select location"),
			list=choiceList
		)

	def updateConfigChoices(self):
		"""Update choices for weatherlocation"""
		try:
			choices = []
			for item in self.favoriteList:
				item = self.normalizeLocation(item)
				if not item:
					continue
				city_name = _to_text_compat(item[0]).split(",")[0].strip()
				choices.append((item, _to_gui_text_compat(city_name)))

			if not choices:
				choices = [(self.locationDefault, _to_gui_text_compat(self.locationDefault[0]))]

			if not hasattr(config.plugins.OAWeatheriet5, "weatherlocation"):
				config.plugins.OAWeatheriet5.weatherlocation = ConfigSelection(
					default=self.locationDefault,
					choices=choices
				)
				logger.info("Created weatherlocation config")
				return

			config.plugins.OAWeatheriet5.weatherlocation.setChoices(choices)

			current_val = self.normalizeLocation(getattr(config.plugins.OAWeatheriet5.weatherlocation, "value", None))
			valid_choices = [choice[0] for choice in choices]
			matched_choice = self.getFavoriteLocation(current_val) or self.resolveConfiguredLocation(require_favorite=True)

			if matched_choice and matched_choice in valid_choices:
				config.plugins.OAWeatheriet5.weatherlocation.value = matched_choice
			elif current_val and current_val in valid_choices:
				config.plugins.OAWeatheriet5.weatherlocation.value = current_val
			else:
				config.plugins.OAWeatheriet5.weatherlocation.value = choices[0][0]

			logger.info("Updated config choices with %s items" % str(len(choices)))

		except Exception as e:
			logger.error("Error in updateConfigChoices: %s" % _to_text_compat(e))
			try:
				if hasattr(config.plugins.OAWeatheriet5, "weatherlocation"):
					default_choice = [(self.locationDefault, self.locationDefault[0])]
					config.plugins.OAWeatheriet5.weatherlocation.setChoices(default_choice)
			except Exception:
				pass

	def readFavoriteList(self):
		"""Read the favorites list"""
		if exists(self.favoritefile):
			try:
				try:
					with open(self.favoritefile, "r", encoding="utf-8") as file_handle:
						content = file_handle.read().strip()
				except TypeError:
					with open(self.favoritefile, "r") as file_handle:
						content = file_handle.read()
						if isinstance(content, bytes):
							content = content.decode("utf-8", "ignore")
						content = content.strip()

				if not content:
					raise ValueError("Empty file")

				loaded_favorites = json.loads(content)

				if not isinstance(loaded_favorites, list):
					raise ValueError("Invalid favorite list format")

				logger.info("Loaded %s favorites from JSON" % str(len(loaded_favorites)))

				try:
					_py2_string_types = basestring
				except NameError:
					_py2_string_types = str

				valid_favorites = []
				for item in loaded_favorites:
					if (isinstance(item, (list, tuple)) and len(item) >= 3 and
							isinstance(item[0], _py2_string_types) and
							isinstance(item[1], (int, float, _py2_string_types)) and
							isinstance(item[2], (int, float, _py2_string_types))):
						try:
							valid_favorites.append((_to_text_compat(item[0]), float(item[1]), float(item[2])))
						except Exception:
							pass

				self.favoriteList = valid_favorites if valid_favorites else [self.locationDefault]

			except ValueError as e:
				logger.error("Error loading favorites: %s" % _to_text_compat(e))
				self.favoriteList = [self.locationDefault]
				self.saveFavorites()

			except (TypeError, NameError):
				try:
					with open(self.favoritefile, "rb") as file_handle:
						self.favoriteList = pickle.load(file_handle)

					logger.info("Loaded %s favorites from pickle" % str(len(self.favoriteList)))
					self.saveFavorites()

				except Exception as e:
					logger.error("Error loading from pickle: %s" % _to_text_compat(e))
					self.favoriteList = [self.locationDefault]
					self.saveFavorites()

			except Exception as e:
				logger.error("Error loading favorites: %s" % _to_text_compat(e))
				self.favoriteList = [self.locationDefault]
				self.saveFavorites()

		else:
			logger.info("Favorite file not found, creating default")
			self.favoriteList = [self.locationDefault]
			self.saveFavorites()

		self.updateConfigChoices()

	def addFavorite(self, location):
		location = self.normalizeLocation(location)
		if not location:
			return False
		name, lon, lat = location
		normalized = (name, float(lon), float(lat))
		for index, favorite in enumerate(self.favoriteList):
			favorite = self.normalizeLocation(favorite)
			if favorite and not self.isDifferentLocation(normalized, favorite):
				if len(normalized[0]) > len(favorite[0]):
					self.favoriteList[index] = normalized
					logger.info("Updated favorite: %s" % name)
					self.saveFavorites()
				return False

		logger.info("Adding new favorite: %s" % name)
		self.favoriteList.append(normalized)
		try:
			current_location = self.normalizeLocation(config.plugins.OAWeatheriet5.weatherlocation.value)
		except Exception:
			current_location = None
		if current_location and not self.isDifferentLocation(current_location, normalized):
			config.plugins.OAWeatheriet5.weathercity.value = name
			config.plugins.OAWeatheriet5.owm_geocode.value = str(lon) + "," + str(lat)
			config.plugins.OAWeatheriet5.weathercity.save()
			config.plugins.OAWeatheriet5.owm_geocode.save()
		self.saveFavorites()
		return True

	def handleFavoriteSelection(self, favorite, callback=None):
		if favorite is None:
			return

		try:
			location = favorite[1] if isinstance(favorite, tuple) and len(favorite) > 1 else favorite
			location = self.normalizeLocation(location)
			if not location:
				return

			if not any(not self.isDifferentLocation(location, fav) for fav in self.favoriteList):
				self.addFavorite(location)

			self.applyLocationConfig(location, save=True, persist=True)

			logger.info("Location set to: %s" % _to_text_compat(location[0]))

			if callback:
				callInThread(weatherhandler.reset, location, callback)
			else:
				callInThread(weatherhandler.reset, location)

		except Exception as e:
			logger.error("Error handling favorite selection: %s" % _to_text_compat(e))
			raise

	def returnFavoriteChoice(self, favorite):
		if favorite is not None:
			location = self.normalizeLocation(favorite[1] if isinstance(favorite, tuple) and len(favorite) > 1 else favorite)
			if not location:
				return
			self.applyLocationConfig(location, save=True)
			weatherhelper.addFavorite(location)
			callInThread(weatherhandler.reset, location)

	def setFavoriteList(self, favoriteList):
		self.favoriteList = favoriteList

	def reduceCityname(self, weathercity):
		components = _unique_preserve_order_compat(_to_text_compat(weathercity).split(", "))
		len_components = len(components)
		if len_components > 2:
			return "{}, {}, {}".format(components[0], components[1], components[-1])
		return "{}, {}".format(components[0], components[1]) if len_components == 2 else "{}".format(components[0])

	def isolateCityname(self, weathercity):
		return _to_text_compat(weathercity).split(",")[0]

	def isDifferentLocation(self, geodata1, geodata2):
		try:
			dummy_name, lon1, lat1 = self.normalizeLocation(geodata1)
			dummy_name, lon2, lat2 = self.normalizeLocation(geodata2)
			distance = ((lon1 - lon2) ** 2 + (lat1 - lat2) ** 2) ** 0.5
			return distance > 0.02
		except Exception:
			return True

	def convertOldLocation(self):  # deprecated: will be removed at end of 2025
		if config.plugins.OAWeatheriet5.owm_geocode.value and config.plugins.OAWeatheriet5.weathercity.value:
			if config.plugins.OAWeatheriet5.weatherlocation.value == config.plugins.OAWeatheriet5.weatherlocation.default:
				weathercity = config.plugins.OAWeatheriet5.weathercity.value
				geocode_val = _to_text_compat(config.plugins.OAWeatheriet5.owm_geocode.value).strip("()")
				lon, lat = map(float, geocode_val.split(","))
				config.plugins.OAWeatheriet5.weatherlocation.value = (weathercity, lon, lat)
				config.plugins.OAWeatheriet5.weatherlocation.save()
			config.plugins.OAWeatheriet5.owm_geocode.value = config.plugins.OAWeatheriet5.owm_geocode.default
			config.plugins.OAWeatheriet5.owm_geocode.save()
			config.plugins.OAWeatheriet5.weathercity.value = config.plugins.OAWeatheriet5.weathercity.default
			config.plugins.OAWeatheriet5.weathercity.save()

	def loadSkin(self, skinName=""):
		params = {"picpath": join(PLUGINPATH, "Images")}
		skintext = ""
		target_skin_names = [skinName]

		width = 1280
		height = 720
		try:
			from enigma import getDesktop
			size = getDesktop(0).size()
			width = size.width()
			height = size.height()
		except Exception:
			pass

		if skinName == "WeatherSettingsViewNew":
			if width >= 1920 or height >= 1080:
				candidate_files = ["skinfhd.xml", "skin.xml", "skinconfig.xml"]
			else:
				candidate_files = ["skinconfig.xml", "skin.xml", "skinfhd.xml"]
			if isOpenATV and (width >= 1920 or height >= 1080):
				target_skin_names = ["WeatherSettingsViewNewOpenATV", "WeatherSettingsViewNew"]
		elif width >= 1920 or height >= 1080:
			candidate_files = ["skinfhd.xml", "skin.xml", "skinconfig.xml"]
		else:
			candidate_files = ["skin.xml", "skinfhd.xml", "skinconfig.xml"]

		for skin_file in candidate_files:
			skin_path = join(PLUGINPATH, skin_file)
			if not exists(skin_path):
				continue
			try:
				xml = parse(skin_path).getroot()
			except Exception as e:
				logger.error("Error parsing skin file %s: %s" % (skin_file, _to_text_compat(e)))
				continue

			for target_skin_name in target_skin_names:
				for screen in xml.findall("screen"):
					if screen.get("name") != target_skin_name:
						continue
					raw = tostring(screen)
					if isinstance(raw, bytes):
						skintext = raw.decode("utf-8")
					else:
						skintext = raw

					for key in params:
						try:
							skintext = skintext.replace("{%s}" % key, str(params[key]))
						except Exception as e:
							print("%s@key=%s" % (_to_text_compat(e), key))

					logger.info("Using skin '%s' from %s (%sx%s)" % (target_skin_name, skin_file, width, height))
					break
				if skintext:
					break
			if skintext:
				break

		# DreamOS is more fragile here, while OpenATV/OpenSource benefit from a visible scrollbar
		# on long config lists such as the setup screen.
		if isDreambox and skintext:
			skintext = skintext.replace('scrollbarMode="showOnDemand"', 'scrollbarMode="showNever"')
			skintext = skintext.replace('scrollbarMode="showAlways"', 'scrollbarMode="showNever"')

		return skintext


"""
this config goes after helper class!!!
config.plugins.OAWeatheriet5.weatherlocation
It is not a setting that the user changes directly in the UI
It is managed automatically through:
Selecting favorites
Searching for new locations
"""
weatherhelper = WeatherHelper()
# Redundant calls removed: constructor already handles readFavoriteList and updateConfigChoices.


class WeatherHandler(object):
	logger.info("Using WeatherHandler")

	def __init__(self):
		self.session = None
		modes = {"MSN": "msn", "openweather": "owm", "OpenMeteo": "omw"}
		mode = modes.get(config.plugins.OAWeatheriet5.weatherservice.value, "msn")
		self.WI = Weatherinfo(mode, config.plugins.OAWeatheriet5.apikey.value)
		self.geocode = self.getValidGeocode()
		self.currLocation = self.getValidLocation()
		self.weathercity = None
		self.trialcounter = 0
		self.currentWeatherDataValid = 3
		self.refreshTimer = eTimer()
		_register_timer_callback(self.refreshTimer, self.refreshWeatherData)
		self.weatherDict = {}
		self.fullWeatherDict = {}
		self.onUpdate = []
		self.refreshCallback = None
		self._requestSerial = 0
		self._activeRequestSerial = 0
		self._activeRequestLocation = None
		self.skydirs = {"N": _("North"), "NE": _("Northeast"), "E": _("East"), "SE": _("Southeast"), "S": _("South"), "SW": _("Southwest"), "W": _("West"), "NW": _("Northwest")}

	def _is_first_run_pending(self):
		try:
			return bool(getattr(getattr(config, "misc", None), "firstrun", None).value)
		except Exception:
			return False

	def getValidGeocode(self):
		"""Get valid coordinates or use default ones"""
		try:
			parts = _to_text_compat(config.plugins.OAWeatheriet5.owm_geocode.value).split(",")
			if len(parts) == 2:
				return [float(parts[0]), float(parts[1])]
		except Exception:
			pass
		return [8.68417, 50.11552]

	def getValidLocation(self):
		"""Get valid location from config or use default"""
		try:
			location = weatherhelper.resolveConfiguredLocation(require_favorite=False)
			if location:
				return location
		except Exception:
			pass
		return weatherhelper.locationDefault

	def sessionStart(self, session):
		self.session = session
		weatherhelper.updateConfigChoices()
		self.getCacheData()

	def _is_full_weather_data(self, data):
		return isinstance(data, dict) and any(key in data for key in ("responses", "hourly", "list"))

	def _is_reduced_weather_data(self, data):
		return isinstance(data, dict) and "current" in data and "forecast" in data

	def _reduced_cache_is_compatible(self, data):
		if not self._is_reduced_weather_data(data):
			return False
		current = data.get("current", {})
		service = config.plugins.OAWeatheriet5.weatherservice.value
		required_by_service = {
			"MSN": ("observationPoint", "temp", "feelsLike", "humidity", "windSpeed", "windGusts", "visibility", "pressure", "sunrise", "sunset", "moonrise", "moonset"),
			"OpenMeteo": ("observationPoint", "temp", "feelsLike", "humidity", "windSpeed", "windGusts", "visibility", "pressure", "sunrise", "sunset"),
			"openweather": ("observationPoint", "temp", "feelsLike", "humidity", "windSpeed", "windGusts", "visibility", "pressure", "sunrise", "sunset"),
		}
		required = required_by_service.get(service, ("observationPoint", "temp"))
		for key in required:
			value = current.get(key)
			if value in (None, ""):
				return False
		return True

	def writeData(self, data, fulldata=None):
		self.currentWeatherDataValid = 0
		self.weatherDict = data or {}
		if fulldata is not None:
			self.fullWeatherDict = fulldata
		for callback in self.onUpdate:
			try:
				callback(data)
			except Exception:
				pass

		seconds = int(config.plugins.OAWeatheriet5.refreshInterval.value) * 60
		self._safe_timer_start(seconds * 1000, True)

	def getData(self):
		return self.weatherDict

	def getFulldata(self):
		return self.fullWeatherDict

	def getValid(self):
		return self.currentWeatherDataValid

	def getSkydirs(self):
		return self.skydirs

	def _safe_timer_start(self, interval, long_timer=True):
		try:
			reactor.callFromThread(self.refreshTimer.start, interval, long_timer)
		except Exception:
			try:
				self.refreshTimer.start(interval, long_timer)
			except Exception:
				pass

	def _safe_timer_stop(self):
		try:
			reactor.callFromThread(self.refreshTimer.stop)
		except Exception:
			try:
				self.refreshTimer.stop()
			except Exception:
				pass

	def getCacheData(self):
		cacheminutes = int(config.plugins.OAWeatheriet5.cachedata.value)
		if cacheminutes and isfile(CACHEFILE):
			file_age_minutes = (time() - getmtime(CACHEFILE)) // 60
			if cacheminutes > file_age_minutes:
				try:
					with open(CACHEFILE, "rb") as file_handle:
						cache_data = pickle.load(file_handle)
				except Exception as cache_error:
					logger.error("Cache load failed: %s" % _to_text_compat(cache_error))
					try:
						remove(CACHEFILE)
					except Exception:
						pass
					self._safe_timer_start(3000, True)
					return
				if self._is_reduced_weather_data(cache_data) and not self._reduced_cache_is_compatible(cache_data):
					try:
						remove(CACHEFILE)
					except Exception:
						pass
					self._safe_timer_start(3000, True)
					return
				self.fullWeatherDict = cache_data if self._is_full_weather_data(cache_data) else {}
				self.writeData(cache_data)
				return
		self._safe_timer_start(3000, True)

	def getCurrLocation(self):
		return self.currLocation

	def setCurrLocation(self, currLocation):
		self.currLocation = currLocation

	def refreshWeatherData(self, entry=None):
		self._safe_timer_stop()
		if self._is_first_run_pending():
			self._safe_timer_start(600000, True)
			return
		if config.plugins.OAWeatheriet5.enabled.value:
			location = weatherhelper.normalizeLocation(config.plugins.OAWeatheriet5.weatherlocation.value)
			if location and len(location) == 3:
				weathercity, lon, lat = location
				geodata = (weathercity, lon, lat)
			else:
				logger.error("Invalid location configuration, using default. location=%s (type=%s)" % (repr(location), type(location)))
				geodata = weatherhelper.locationDefault

			language = _get_osd_language_compat()
			unit = "imperial" if config.plugins.OAWeatheriet5.tempUnit.value == "Fahrenheit" else "metric"
			self.currLocation = geodata
			self.weathercity = geodata[0]
			self._requestSerial += 1
			request_serial = self._requestSerial
			self._activeRequestSerial = request_serial
			self._activeRequestLocation = geodata
			logger.info("refreshWeatherData: request #%d for %s" % (request_serial, repr(geodata)))

			self.WI.start(
				geodata=geodata,
				cityID=None,
				units=unit,
				scheme=language,
				reduced=False,
				callback=lambda data, error, rs=request_serial, rl=geodata: self.refreshWeatherDataCallback(data, error, rs, rl)
			)

	def refreshWeatherDataCallback(self, data, error, request_serial=None, request_location=None):
		def updateUI():
			logger.info("updateUI running on main thread...")
			current_location = weatherhelper.getFavoriteLocation(config.plugins.OAWeatheriet5.weatherlocation.value) or weatherhelper.normalizeLocation(config.plugins.OAWeatheriet5.weatherlocation.value)
			callback_location = weatherhelper.normalizeLocation(request_location)
			if request_serial is not None and request_serial != self._activeRequestSerial:
				logger.info("Ignoring stale weather callback #%s; active request is #%s" % (str(request_serial), str(self._activeRequestSerial)))
				return
			if callback_location and current_location and weatherhelper.isDifferentLocation(callback_location, current_location):
				logger.info("Ignoring callback for old location %s; current location is %s" % (repr(callback_location), repr(current_location)))
				return
			if error or data is None:
				logger.error("refreshWeatherDataCallback failed silently: error='%s', data is None=%s" % (error, data is None))
				self.trialcounter += 1
				if self.trialcounter < 2:
					print("[%s] lookup for city '%s' paused, try again in 10 secs..." % (MODULE_NAME, self.weathercity))
					self.currentWeatherDataValid = 1
					self._safe_timer_start(10000, True)
				elif self.trialcounter > 5:
					print("[%s] lookup for city '%s' paused 1 h, to many errors..." % (MODULE_NAME, self.weathercity))
					self.currentWeatherDataValid = 2
					self._safe_timer_start(3600000, True)
				else:
					print("[%s] lookup for city '%s' paused 5 mins, to many errors..." % (MODULE_NAME, self.weathercity))
					self.currentWeatherDataValid = 2
					self._safe_timer_start(300000, True)

				if isfile(CACHEFILE):
					try:
						remove(CACHEFILE)
					except Exception:
						pass
				return

			full_data = data if self._is_full_weather_data(data) else {}
			reduced_data = data if self._is_reduced_weather_data(data) else None
			if reduced_data is None:
				try:
					reduced_data = self.WI.getreducedinfo()
				except Exception as reduce_error:
					logger.error("Error building reduced weather data: %s" % _to_text_compat(reduce_error))
					reduced_data = None
			if not reduced_data:
				logger.error("refreshWeatherDataCallback received no usable reduced data")
				self.currentWeatherDataValid = 2
				return

			self.fullWeatherDict = full_data
			self.weatherData = reduced_data
			self.valid = 0
			self.trialcounter = 0
			self.writeData(reduced_data, full_data)
			logger.info("refreshWeatherDataCallback triggered! error: %s, data populated: %s" % (error, bool(data)))

			if isfile(CACHEFILE):
				try:
					remove(CACHEFILE)
				except Exception:
					pass

			if self.refreshCallback:
				callback = self.refreshCallback
				self.refreshCallback = None
				try:
					callback()
				except TypeError:
					try:
						callback(reduced_data)
					except Exception:
						pass
				except Exception:
					pass

			logger.info("updateUI finished cleanly.")

		logger.info("Scheduling updateUI on reactor...")
		try:
			reactor.callFromThread(updateUI)
		except Exception:
			updateUI()

	def reset(self, newLocation=None, callback=None):
		logger.info("WeatherHandler.reset: newLocation=%s" % repr(newLocation))
		self.refreshCallback = callback
		if newLocation:
			normalized_location = weatherhelper.normalizeLocation(newLocation)
			if normalized_location:
				self.currLocation = normalized_location
				self.weathercity = normalized_location[0]
				# Ensure synchronization with config before starting reset
				try:
					weatherhelper.applyLocationConfig(normalized_location, save=True)
				except Exception as e:
					logger.error("Error applying location config in reset: %s" % _to_text_compat(e))
			else:
				self.currLocation = newLocation
		else:
			self.currLocation = weatherhelper.normalizeLocation(config.plugins.OAWeatheriet5.weatherlocation.value) or self.currLocation

		self.currentWeatherDataValid = 3
		self.weatherDict = {}
		self.fullWeatherDict = {}

		self._safe_timer_stop()
		if isfile(CACHEFILE):
			try:
				remove(CACHEFILE)
			except Exception:
				pass

		modes = {"MSN": "msn", "openweather": "owm", "OpenMeteo": "omw"}
		mode = modes.get(config.plugins.OAWeatheriet5.weatherservice.value, "msn")
		self.WI.setmode(mode, config.plugins.OAWeatheriet5.apikey.value)

		self.refreshWeatherData()

		try:
			if self.session:
				self.session.screen["OAWeatheriet5"].iconpath = get_iconset_path(config.plugins.OAWeatheriet5.iconset.value)
		except Exception as e:
			logger.warning("Session screen update failed in reset: %s" % _to_text_compat(e))


weatherhandler = WeatherHandler()