# -*- coding: utf-8 -*-

from __future__ import print_function

# created by iet5
import logging
import re
import sys
from datetime import datetime
from os import listdir
from os.path import exists, isfile, join

# Enigma2 Components
from Components.config import (
	config,
	ConfigElement,
	ConfigSubsection,
	ConfigSelection,
	ConfigText,
	ConfigYesNo
)
from Tools.Directories import SCOPE_CONFIG, SCOPE_PLUGINS, resolveFilename

# Python 2/3 and Image Compatibility
if sys.version_info[0] >= 3:
	try:
		from Tools.Directories import SCOPE_SKINS
	except Exception:
		SCOPE_SKINS = None
else:
	try:
		from Tools.Directories import SCOPE_SKIN
	except Exception:
		SCOPE_SKIN = None

from . import _, isDreambox, isVTi, isOpenATV

try:
	from . import isOpenPLI
except Exception:
	isOpenPLI = False

try:
	from . import isOpenSourceImage
except Exception:
	isOpenSourceImage = False

MODULE_NAME = "OAWeatheriet5"
PY3 = sys.version_info[0] >= 3
CONFIGROOT = "/etc/enigma2"

def _resolve_config_file(filename):
	preferred = join(CONFIGROOT, filename)
	if exists(CONFIGROOT):
		return preferred
	try:
		resolved = resolveFilename(SCOPE_CONFIG, filename)
		if resolved:
			return resolved
	except Exception:
		pass
	return preferred

if isDreambox:
	# Hard-coded safety for DreamOS / Gemini to avoid any resolveFilename side-effects
	CACHEFILE = join(CONFIGROOT, "OAWeatheriet5.dat")
	OAWEATHER_FAV = join(CONFIGROOT, "oaweatheriet5_fav.json")
else:
	CACHEFILE = _resolve_config_file("OAWeatheriet5.dat")
	OAWEATHER_FAV = _resolve_config_file("oaweatheriet5_fav.json")

PLUGINPATH = join(resolveFilename(SCOPE_PLUGINS), "Extensions/OAWeatheriet5")
logger = logging.getLogger(MODULE_NAME)
GEODATA = ("Frankfurt am Main, DE", "8.68417,50.11552")
BUILTIN_ICONROOT = join(PLUGINPATH, "Icons")
BUILTIN_DEFAULT_ICONSET = join(BUILTIN_ICONROOT, "Defult")

try:
	text_type = unicode
except NameError:
	text_type = str

try:
	string_types = (basestring,)
except NameError:
	string_types = (str, bytes)

class OAConfigText(ConfigElement):
	# Compatibility placeholder kept intentionally for older images/builds.
	def __init__(self, default="", fixed_size=False, visible_width=False):
		ConfigElement.__init__(self)
		self.value = default

	def handleKey(self, key):
		pass

	def getText(self):
		return str(self.value)

	def getHTML(self, id):
		return ""

	def from_string(self, value):
		self.value = value

	def to_string(self, value):
		return str(value)


def _iter_items_compat(obj):
	if hasattr(obj, "items"):
		try:
			return obj.items()
		except Exception:
			pass
	if hasattr(obj, "iteritems"):
		try:
			return obj.iteritems()
		except Exception:
			pass
	return []


def _unique_preserve_order_compat(values):
	seen = []
	result = []
	for value in values:
		if value not in seen:
			seen.append(value)
			result.append(value)
	return result

def _to_text_compat(value):
	if value is None:
		return ""
	if PY3:
		return value.decode("utf-8", "ignore") if isinstance(value, bytes) else str(value)
	if isinstance(value, text_type):
		return value
	try:
		return value.decode("utf-8", "ignore")
	except Exception:
		try:
			return text_type(value)
		except Exception:
			return str(value)


def _to_gui_text_compat(value):
	value = _to_text_compat(value)
	if not PY3 and isinstance(value, text_type):
		try:
			return value.encode("utf-8", "ignore")
		except Exception:
			try:
				return str(value)
			except Exception:
				return ""
	return value


def _normalize_iso_datetime(value):
	value = _to_text_compat(value).strip()
	if not value:
		return ""
	value = value.replace("Z", "")
	if "." in value:
		value = value.split(".", 1)[0]
	match = re.search(r"([+-]\d{2}:?\d{2})$", value)
	if match and match.start() > 10:
		value = value[:match.start()]
	return value


def _parse_datetime_compat(value):
	value = _normalize_iso_datetime(value)
	if not value:
		return None
	if PY3 and hasattr(datetime, "fromisoformat"):
		try:
			return datetime.fromisoformat(value)
		except Exception:
			pass
	if not PY3 and isinstance(value, text_type):
		try:
			value = value.encode("ascii", "ignore")
		except Exception:
			pass
	for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d"):
		try:
			return datetime.strptime(value, fmt)
		except Exception:
			continue
	return None


def _isoformat_naive_compat(value):
	dt = value if isinstance(value, datetime) else _parse_datetime_compat(value)
	return dt.isoformat() if dt else ""


def _list_get_compat(values, index, default=None):
	try:
		return values[index]
	except Exception:
		return default


def _first_dict_compat(values, default=None):
	if isinstance(values, dict):
		return values
	if isinstance(values, (list, tuple)) and values and isinstance(values[0], dict):
		return values[0]
	return default if default is not None else {}


def _get_location_name_compat(location):
	if isinstance(location, (list, tuple)) and location:
		return _to_text_compat(location[0])
	return _to_text_compat(location)


def _get_yahoo_code_compat(source_name, code, weather_handler=None):
	if weather_handler is None:
		try:
			from .plugin_weather import weatherhandler as weather_handler
		except Exception:
			weather_handler = None
	if weather_handler is None:
		return "NA"
	try:
		icon_map = weather_handler.WI.convert2icon(source_name, code)
	except Exception:
		icon_map = None
	if not isinstance(icon_map, dict):
		return "NA"
	return icon_map.get("yahooCode", "NA")

def _get_choice_values_compat(config_item):
	choices = getattr(config_item, "choices", [])
	if callable(choices):
		try:
			choices = choices()
		except Exception:
			choices = []
	values = []
	for choice in list(choices or []):
		if isinstance(choice, (list, tuple)) and choice:
			values.append(choice[0])
		else:
			values.append(choice)
	return values


def _normalize_choice_value_compat(value_or_config_item, default=None):
	"""
	Supports:
	1) old behavior: pass config item -> normalize its .value against choices
	2) generic behavior: pass arbitrary value -> unwrap ChoiceBox tuples/lists safely

	Important:
	- ChoiceBox usually returns (label, value)
	- But real weather locations can also be plain tuples like (city, lon, lat)
	  and MUST stay untouched.
	"""
	if hasattr(value_or_config_item, "value") or hasattr(value_or_config_item, "choices"):
		config_item = value_or_config_item
		valid_values = _get_choice_values_compat(config_item)
		current = getattr(config_item, "value", default)
		if current in valid_values:
			return current
		text_value = _to_text_compat(current).strip()
		if text_value in valid_values:
			return text_value
		if text_value:
			try:
				number_value = "%d" % int(float(text_value))
				if number_value in valid_values:
					return number_value
			except Exception:
				pass
		if default in valid_values:
			return default
		return valid_values[0] if valid_values else default

	value = value_or_config_item

	# Real geolocation tuple/list: keep it as-is.
	if isinstance(value, (list, tuple)) and len(value) == 3:
		try:
			float(value[1])
			float(value[2])
			return value
		except Exception:
			pass

	# Standard ChoiceBox result: (label, value)
	if isinstance(value, (list, tuple)) and len(value) == 2:
		first, second = value[0], value[1]
		if isinstance(first, string_types):
			return second
	if isinstance(value, (list, tuple)) and len(value) == 1:
		return value[0]
	return value

def _display_text_compat(value, default=""):
	if value is None:
		value = default
	if isinstance(value, dict):
		for key in ("pvdrCap", "capAbbr", "summary", "description", "text", "value", "name", "title"):
			if key in value:
				text = _display_text_compat(value.get(key), "")
				if text:
					return text
		for _, item in _iter_items_compat(value):
			text = _display_text_compat(item, "")
			if text:
				return text
		return _to_gui_text_compat(default)
	if isinstance(value, (list, tuple)):
		parts = []
		for item in value:
			text = _to_text_compat(_display_text_compat(item, "")).strip()
			if text:
				parts.append(text)
		return _to_gui_text_compat(", ".join(parts) if parts else default)
	text = _to_text_compat(value).strip()
	if not text:
		text = _to_text_compat(default).strip()
	return _to_gui_text_compat(text)


def _build_detail_row(values):
	if not values:
		return []
	row = []
	last_index = len(values) - 1
	for index, value in enumerate(values):
		row.append(value if index == last_index else _display_text_compat(value))
	return row

def _is_valid_iconset_dir(path):
	try:
		return bool(path and isfile(join(path, "0.png")))
	except Exception:
		return False

def _resolve_iconset_root():
	candidates = []

	# Keep the condition explicit per image family to avoid path regressions.
	if isDreambox:
		candidates.append("/usr/share/enigma2/WeatherIconSets")
	elif isVTi:
		if not PY3 and globals().get("SCOPE_SKIN") is not None:
			try:
				candidates.append(join(resolveFilename(SCOPE_SKIN), "WeatherIconSets"))
			except Exception:
				pass
		candidates.append("/usr/share/enigma2/WeatherIconSets")
	elif isOpenATV or isOpenPLI or isOpenSourceImage:
		if PY3 and globals().get("SCOPE_SKINS") is not None:
			try:
				candidates.append(join(resolveFilename(SCOPE_SKINS), "WeatherIconSets"))
			except Exception:
				pass
		if not PY3 and globals().get("SCOPE_SKIN") is not None:
			try:
				candidates.append(join(resolveFilename(SCOPE_SKIN), "WeatherIconSets"))
			except Exception:
				pass
		candidates.append("/usr/share/enigma2/WeatherIconSets")
	else:
		if PY3 and globals().get("SCOPE_SKINS") is not None:
			try:
				candidates.append(join(resolveFilename(SCOPE_SKINS), "WeatherIconSets"))
			except Exception:
				pass
		if not PY3 and globals().get("SCOPE_SKIN") is not None:
			try:
				candidates.append(join(resolveFilename(SCOPE_SKIN), "WeatherIconSets"))
			except Exception:
				pass
		candidates.append("/usr/share/enigma2/WeatherIconSets")

	candidates.append(BUILTIN_ICONROOT)

	for candidate in candidates:
		if candidate and exists(candidate):
			return candidate
	return candidates[0] if candidates else BUILTIN_ICONROOT

config.plugins.OAWeatheriet5 = ConfigSubsection()
config.plugins.OAWeatheriet5.enabled = ConfigYesNo(default=False)

ICONSETS = [("", _("Default"))]
ICONSETROOT = _resolve_iconset_root()
_seen_iconsets = []
for root in _unique_preserve_order_compat([ICONSETROOT, BUILTIN_ICONROOT]):
	if exists(root):
		for iconset in listdir(root):
			iconset_path = join(root, iconset)
			if not _is_valid_iconset_dir(iconset_path) or iconset in _seen_iconsets:
				continue
			if iconset == "Defult":
				_seen_iconsets.append(iconset)
				continue
			ICONSETS.append((iconset, iconset))
			_seen_iconsets.append(iconset)

config.plugins.OAWeatheriet5.iconset = ConfigSelection(default="", choices=ICONSETS)
try:
	if getattr(config.plugins.OAWeatheriet5.iconset, "value", "") == "Defult":
		config.plugins.OAWeatheriet5.iconset.value = ""
except Exception:
	pass

config.plugins.OAWeatheriet5.nighticons = ConfigYesNo(default=True)
config.plugins.OAWeatheriet5.cachedata = ConfigSelection(default="0", choices=[("0", _("Disabled"))] + [("%d" % x, _("%d Minutes") % x) for x in (30, 60, 120)])
config.plugins.OAWeatheriet5.refreshInterval = ConfigSelection(default="120", choices=[("%d" % x, _("%d Minutes") % x) for x in (0, 30, 60, 90, 120, 180, 240, 360, 720, 1440)])
config.plugins.OAWeatheriet5.apikey = ConfigText(default="", visible_width=200, fixed_size=256)
config.plugins.OAWeatheriet5.weathercity = ConfigText(default=GEODATA[0], visible_width=250, fixed_size=False)
config.plugins.OAWeatheriet5.owm_geocode = ConfigText(default=GEODATA[1])
config.plugins.OAWeatheriet5.detailLevel = ConfigSelection(default="default", choices=[("default", _("More Details / Smaller font")), ("reduced", _("Less details / Larger font"))])
config.plugins.OAWeatheriet5.tempUnit = ConfigSelection(default="Celsius", choices=[("Celsius", _("Celsius")), ("Fahrenheit", _("Fahrenheit"))])
config.plugins.OAWeatheriet5.windspeedMetricUnit = ConfigSelection(default="km/h", choices=[("km/h", _("km/h")), ("m/s", _("m/s"))])
config.plugins.OAWeatheriet5.trendarows = ConfigYesNo(default=True)
config.plugins.OAWeatheriet5.weatherservice = ConfigSelection(default="MSN", choices=[("MSN", _("MSN weather")), ("OpenMeteo", _("Open-Meteo Weather")), ("openweather", _("OpenWeatherMap"))])
config.plugins.OAWeatheriet5.debug = ConfigYesNo(default=False)

# Backward compatibility for older code paths that still use the original name.
config.plugins.OAWeatheriet5.trendarrows = config.plugins.OAWeatheriet5.trendarows

def get_iconset_path(iconset_name):
	iconset_name = _to_text_compat(iconset_name).strip()
	if iconset_name:
		for root in _unique_preserve_order_compat([ICONSETROOT, BUILTIN_ICONROOT]):
			candidate = join(root, iconset_name)
			if _is_valid_iconset_dir(candidate):
				return candidate
	if _is_valid_iconset_dir(BUILTIN_DEFAULT_ICONSET):
		return BUILTIN_DEFAULT_ICONSET
	if exists(BUILTIN_ICONROOT):
		return BUILTIN_ICONROOT
	return join(PLUGINPATH, "Icons")


def _auto_night_switch_enabled():
	try:
		plugin_cfg = getattr(getattr(config, "plugins", None), "OAWeatheriet5", None)
		if plugin_cfg is None:
			return False
		if not getattr(getattr(plugin_cfg, "nighticons", None), "value", False):
			return False
	except Exception:
		return False

	# Keep the condition explicit per image family to avoid renderer regressions.
	if isDreambox:
		return True
	if isVTi:
		return True
	if isOpenATV:
		return True
	if isOpenPLI:
		return True
	if isOpenSourceImage:
		return True
	return False


def _compute_is_night_compat(currtime, sunrisestr, sunsetstr, fallback=False):
	curr_dt = currtime if isinstance(currtime, datetime) else _parse_datetime_compat(currtime)
	sunrise_dt = _parse_datetime_compat(sunrisestr)
	sunset_dt = _parse_datetime_compat(sunsetstr)
	if curr_dt is None or sunrise_dt is None or sunset_dt is None:
		return bool(fallback)

	# Compare using full timestamps when available; switch to night exactly at sunset.
	return curr_dt < sunrise_dt or curr_dt >= sunset_dt


def _resolve_weather_icon_code(iconcode, is_night, night_switch_map, day_switch_map, iconpath=None, extension="png"):
	iconcode = _to_text_compat(iconcode).strip()
	if not iconcode:
		return ""

	if not _auto_night_switch_enabled():
		is_night = False

	candidates = []
	if is_night:
		candidates.extend((
			night_switch_map.get(iconcode, iconcode),
			iconcode,
			day_switch_map.get(iconcode, iconcode)
		))
	else:
		candidates.extend((
			day_switch_map.get(iconcode, iconcode),
			iconcode
		))

	ordered_candidates = _unique_preserve_order_compat([candidate for candidate in candidates if candidate])
	if not ordered_candidates:
		return iconcode

	if iconpath:
		extension = _to_text_compat(extension).lstrip(".") or "png"
		for candidate in ordered_candidates:
			iconfile = join(iconpath, "%s.%s" % (candidate, extension))
			if exists(iconfile):
				return candidate

	return ordered_candidates[0]

def setup_logging():
	log_file = "/tmp/OAWeatheriet5.log"
	log_level = logging.DEBUG if config.plugins.OAWeatheriet5.debug.value else logging.INFO
	formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
	logger.setLevel(log_level)
	logger.propagate = False

	if logger.handlers:
		for existing_handler in list(logger.handlers):
			existing_handler.setLevel(log_level)
			existing_handler.setFormatter(formatter)
		return

	try:
		handler = logging.FileHandler(log_file)
		handler.setLevel(log_level)
		handler.setFormatter(formatter)
		logger.addHandler(handler)
	except Exception:
		pass

	try:
		console_handler = logging.StreamHandler()
		console_handler.setLevel(log_level)
		console_handler.setFormatter(formatter)
		logger.addHandler(console_handler)
	except Exception:
		pass

	logger.info("OAWeatheriet5 logging initialized")


setup_logging()