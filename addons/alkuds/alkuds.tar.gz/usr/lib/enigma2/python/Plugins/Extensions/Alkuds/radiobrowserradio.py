# -*- coding: utf-8 -*-
"""Current public Arabic radio directory used to replace stale legacy links."""
from __future__ import unicode_literals

import re

import requests


API = 'https://de1.api.radio-browser.info/json/stations/bycountrycodeexact/'
PAGE_SIZE = 120
ARAB_CODES = ('KW', 'OM', 'SA', 'SD', 'SO', 'YE', 'DZ', 'MA', 'TN', 'EG',
              'AE', 'BH', 'QA', 'JO', 'IQ', 'PS', 'LB', 'SY')
DEAD_ENDPOINTS = ('s3.voscast.com:9966',)

try:
    text_type = unicode
except NameError:
    text_type = str


def _text(value):
    if value is None:
        return u''
    if isinstance(value, text_type):
        return value
    if isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    return text_type(value)


def legacy_groups():
    """The former Alkuds radio headings, kept first and in their familiar order."""
    return [
        {'name': u'اذاعات الكويت', 'source': 'radio_browser', 'codes': ['KW']},
        {'name': u'اذاعات عمان', 'source': 'radio_browser', 'codes': ['OM']},
        {'name': u'السعودية', 'source': 'radio_browser', 'codes': ['SA']},
        {'name': u'اذاعات اسلامية', 'source': 'mytuner', 'code': 'quran'},
        {'name': u'اذاعات السودان', 'source': 'radio_browser', 'codes': ['SD']},
        {'name': u'اذاعات الصومال', 'source': 'radio_browser', 'codes': ['SO']},
        {'name': u'اذاعات اليمن', 'source': 'radio_browser', 'codes': ['YE']},
        {'name': u'tv fm الاخبار', 'source': 'radio_browser',
         'codes': list(ARAB_CODES), 'filter': 'news'},
        {'name': u'اذاعات الجزائر', 'source': 'radio_browser', 'codes': ['DZ']},
        {'name': u'اذاعات المغرب', 'source': 'radio_browser', 'codes': ['MA']},
        {'name': u'اذاعات تونس', 'source': 'radio_browser', 'codes': ['TN']},
        {'name': u'اذاعات مصر', 'source': 'radio_browser', 'codes': ['EG']},
        {'name': u'اذاعات الخليج', 'source': 'radio_browser',
         'codes': ['AE', 'BH', 'KW', 'OM', 'QA', 'SA']},
        {'name': u'اذاعات الاردن', 'source': 'radio_browser', 'codes': ['JO']},
        {'name': u'اذاعات العراق', 'source': 'radio_browser', 'codes': ['IQ']},
        {'name': u'اذاعات فلسطين', 'source': 'radio_browser', 'codes': ['PS']},
        {'name': u'اذاعات لبنان', 'source': 'radio_browser', 'codes': ['LB']},
        {'name': u'اذاعات سورية', 'source': 'radio_browser', 'codes': ['SY']},
    ]


def _get(code, user_agent):
    response = requests.get(
        API + code,
        params={'hidebroken': 'true', 'order': 'votes', 'reverse': 'true', 'limit': 250},
        headers={'User-Agent': user_agent or 'Alkuds-Enigma2/1.98'},
        timeout=(7, 18), verify=False)
    response.raise_for_status()
    value = response.json()
    return value if isinstance(value, list) else []


def items(parent, user_agent, page=1):
    rows, seen = [], set()
    news_only = _text((parent or {}).get('filter')).lower() == 'news'
    for code in (parent or {}).get('codes') or []:
        for station in _get(_text(code), user_agent):
            name = _text(station.get('name')).strip()
            codec = _text(station.get('codec')).strip()
            url = _text(station.get('url_resolved') or station.get('url')).strip()
            if not name or not url.lower().startswith(('http://', 'https://')):
                continue
            if any(endpoint in url.lower() for endpoint in DEAD_ENDPOINTS):
                continue
            if 'h.264' in codec.lower() or 'video' in codec.lower():
                continue
            if news_only and not re.search(u'news|اخبار|أخبار|خبر', name, re.I):
                continue
            signature = (name.lower(), url.split('?', 1)[0].rstrip('/'))
            if signature in seen:
                continue
            seen.add(signature)
            bitrate = int(station.get('bitrate') or 0)
            label = (u'%d kbps' % bitrate) if bitrate else (codec or u'مباشر')
            stream = {'url': url, 'name': label, 'quality': label,
                      'mediatype': 'hls' if '.m3u8' in url.lower() else 'audio',
                      'relay': False,
                      'headers': {'User-Agent': user_agent or 'Alkuds-Enigma2/1.98'}}
            rows.append({'id': station.get('stationuuid'), 'name': name,
                         'image': _text(station.get('favicon')),
                         'description': _text((parent or {}).get('name')),
                         'streams': [stream], 'url': url, 'urls': [url],
                         'headers': stream['headers'], 'is_live': True,
                         'source': 'radio_browser'})
    page = max(1, int(page or 1))
    total = len(rows)
    last_page = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
    page = min(page, last_page)
    start = (page - 1) * PAGE_SIZE
    return {'entries': rows[start:start + PAGE_SIZE], 'page': page,
            'last_page': last_page, 'total': total}
