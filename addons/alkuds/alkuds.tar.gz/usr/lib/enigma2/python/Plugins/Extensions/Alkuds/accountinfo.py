#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Provider account metadata; absent values are never inferred from playback."""
from __future__ import division

import calendar
import datetime
import math
import time
try:
    from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
except ImportError:
    from urlparse import urlparse, parse_qs, urlunparse
    from urllib import urlencode


def account_fields(payload):
    if not isinstance(payload, dict):
        return {}
    result = {}
    aliases = {
        'expiry': ('exp_date', 'expire_date', 'expiry_date', 'expires_at', 'expiration', 'end_date', 'expiry'),
        'active': ('active_cons', 'active_connections', 'active_sessions'),
        'maximum': ('max_connections', 'max_cons', 'max_sessions'),
    }
    for target, keys in aliases.items():
        for key in keys:
            if key in payload and payload[key] not in (None, ''):
                result[target] = payload[key]
                break
    for key in ('js', 'data', 'account_info', 'account', 'subscription', 'user_info'):
        nested = payload.get(key)
        if isinstance(nested, dict):
            result.update(account_fields(nested))
    return result


def _expiry_timestamp(value):
    raw = str(value or '').strip()
    try:
        number = float(raw)
        return number / 1000.0 if number > 100000000000 else number
    except (ValueError, TypeError):
        pass
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%d',
                '%d/%m/%Y', '%d-%m-%Y', '%B %d, %Y', '%b %d, %Y'):
        try:
            parsed = time.strptime(raw, fmt)
            return calendar.timegm(parsed) if raw.endswith('Z') else time.mktime(parsed)
        except (ValueError, OverflowError):
            pass
    return None


def account_text(fields, now=None, compact=False):
    fields = fields or {}
    now = time.time() if now is None else now
    expiry = fields.get('expiry')
    label = 'N/A'
    if expiry is not None:
        if str(expiry).lower().strip() in ('0', 'unlimited', 'never', 'lifetime'):
            label = 'Unlimited'
        else:
            stamp = _expiry_timestamp(expiry)
            if stamp is not None and stamp > 0:
                try:
                    date = datetime.datetime.fromtimestamp(stamp).strftime('%Y-%m-%d')
                    label = '%s (%s)' % (date, '%dd left' % int(math.ceil((stamp - now) / 86400.0)) if stamp > now else 'Expired')
                except (ValueError, OverflowError, OSError):
                    pass
    def count(key):
        try:
            value = int(fields[key])
            return str(value) if value >= 0 else 'N/A'
        except (KeyError, ValueError, TypeError, OverflowError):
            return 'N/A'
    separator = '\n' if compact else '   |   '
    return 'Expiry: %s%sMax: %s   |   Active: %s' % (label, separator, count('maximum'), count('active'))


def xtream_api_from_url(url):
    """Only derive an API URL from an actual Xtream playlist URL, on its host."""
    parts = urlparse(str(url or ''))
    if parts.scheme not in ('http', 'https') or not parts.netloc:
        return ''
    if parts.path.rsplit('/', 1)[-1] not in ('get.php', 'player_api.php'):
        return ''
    query = parse_qs(parts.query)
    if not query.get('username') or not query.get('password'):
        return ''
    path = parts.path.rsplit('/', 1)[0] + '/player_api.php'
    args = urlencode({'username': query['username'][0], 'password': query['password'][0]})
    return urlunparse((parts.scheme, parts.netloc, path, '', args, ''))


def fetch_xtream_account(url, user_agent):
    import requests
    response = requests.get(url, headers={'User-Agent': str(user_agent)}, timeout=(5, 10))
    try:
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, dict) or not isinstance(data.get('user_info'), dict):
            raise ValueError('Account information is unavailable')
        return data
    finally:
        response.close()


class AccountInfoLoader(object):
    """One background request; completion is delivered by the GUI timer."""
    def __init__(self, screen, fetch, complete):
        from enigma import eTimer
        self.fetch, self.complete = fetch, complete
        self.closed, self.running, self.done = False, False, False
        self.timer = eTimer()
        try:
            self.connection = self.timer.timeout.connect(self.poll)
        except Exception:
            self.timer.callback.append(self.poll)
        screen.onClose.append(self.close)

    def start(self):
        if self.closed or self.running:
            return
        import threading
        self.running, self.done = True, False
        worker = threading.Thread(target=self.work)
        worker.daemon = True
        worker.start()
        self.timer.start(100, False)

    def work(self):
        try:
            self.result = self.fetch()
        except Exception:
            self.result = None
        self.done = True

    def poll(self):
        if self.closed or not self.done:
            return
        self.timer.stop()
        self.running = False
        self.complete(self.result)

    def close(self):
        self.closed = True
        self.timer.stop()
