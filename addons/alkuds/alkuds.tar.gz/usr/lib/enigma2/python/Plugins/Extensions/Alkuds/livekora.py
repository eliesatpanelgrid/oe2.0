#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Public match-list adapter for livekora.vip plus cross-source merging."""

from __future__ import print_function

import re

import requests

try:
    from html import unescape
    from urllib.parse import urljoin
except ImportError:
    from HTMLParser import HTMLParser
    from urlparse import urljoin
    unescape = HTMLParser().unescape


LIVEKORA_HOME = "https://www.livekora.vip/"
MAX_HTML = 2 * 1024 * 1024


def _clean(value):
    value = re.sub(r"<[^>]+>", " ", str(value or ""))
    return " ".join(unescape(value).split())


def _get_html(url, user_agent):
    headers = {"User-Agent": str(user_agent or "Mozilla/5.0")}
    with requests.get(url, headers=headers, timeout=(7, 22), stream=True) as response:
        response.raise_for_status()
        chunks, total = [], 0
        for chunk in response.iter_content(16384):
            total += len(chunk)
            if total > MAX_HTML:
                raise RuntimeError("LiveKora page is too large")
            chunks.append(chunk)
        return b"".join(chunks).decode("utf-8", "replace"), str(response.url)


def fetch_livekora_matches(user_agent):
    html, final_url = _get_html(LIVEKORA_HOME, user_agent)
    starts = [match.start() for match in re.finditer(
        r'<a\s+href="[^"]+"[^>]*>\s*<div\s+class="match-container"',
        html, re.I)]
    starts.append(len(html))
    entries, seen = [], set()
    for index in range(len(starts) - 1):
        chunk = html[starts[index]:starts[index + 1]]
        link = re.search(r'<a\s+href="([^"]+)"', chunk, re.I)
        teams = re.findall(
            r'<div\s+class="team-name"[^>]*>(.*?)</div>', chunk, re.I | re.S)
        if not link or len(teams) < 2:
            continue
        page_url = urljoin(final_url, unescape(link.group(1)))
        home, away = _clean(teams[0]), _clean(teams[1])
        identity = (home, away, page_url)
        if identity in seen:
            continue
        seen.add(identity)
        kickoff_match = re.search(
            r'id="match-time"[^>]*>(.*?)</div>', chunk, re.I | re.S)
        score_match = re.search(
            r'class="match-score"[^>]*>(.*?)</div>', chunk, re.I | re.S)
        status_match = re.search(
            r'class="match-status"[^>]*>(.*?)</div>', chunk, re.I | re.S)
        timestamp_match = re.search(
            r'data-start-time="([0-9]+)"', chunk, re.I)
        kickoff = _clean(kickoff_match.group(1)) if kickoff_match else "--:--"
        score = _clean(score_match.group(1)) if score_match else "vs"
        status = _clean(status_match.group(1)) if status_match else u"مجدولة"
        entries.append({
            "id": "livekora:%s" % page_url,
            "name": u"%s  %s  %s" % (home, score, away),
            "home": home,
            "away": away,
            "score": score,
            "status": status,
            "time": kickoff,
            "timestamp": int(timestamp_match.group(1)) if timestamp_match else 0,
            "channel": "LiveKora",
            "league": "",
            "description": u"%s | %s | LiveKora" % (kickoff, status),
            "url": page_url,
            "source": "livekora",
            "provider_label": "LiveKora",
        })
    if not entries:
        raise RuntimeError("LiveKora returned no matches")
    return {"entries": entries, "page": 1, "last_page": 1, "total": len(entries)}


def _team_key(value):
    value = str(value or "").lower()
    for old, new in ((u"أ", u"ا"), (u"إ", u"ا"), (u"آ", u"ا"),
                     (u"ة", u"ه"), (u"ى", u"ي"), (u"ؤ", u"و"), (u"ئ", u"ي")):
        value = value.replace(old, new)
    value = re.sub(u"[\u064b-\u065f\u0670]", "", value)
    return re.sub(r"[^0-9a-z\u0600-\u06ff]+", "", value)


def _same_team(left, right):
    left, right = _team_key(left), _team_key(right)
    if not left or not right:
        return False
    if left == right:
        return True
    shorter, longer = (left, right) if len(left) <= len(right) else (right, left)
    return len(shorter) >= 4 and shorter in longer


def _same_match(left, right):
    direct = (_same_team(left.get("home"), right.get("home")) and
              _same_team(left.get("away"), right.get("away")))
    reverse = (_same_team(left.get("home"), right.get("away")) and
               _same_team(left.get("away"), right.get("home")))
    return direct or reverse


def merge_match_catalogues(*catalogues):
    """Merge duplicate fixtures and retain every provider item as a source."""
    merged = []
    for catalogue in catalogues:
        for raw in list((catalogue or {}).get("entries") or []):
            item = dict(raw)
            item.setdefault("provider_label", "LiveKora" if item.get("source") == "livekora" else "LiveHD")
            item["sources"] = [dict(item)]
            existing = next((candidate for candidate in merged if _same_match(candidate, item)), None)
            if existing is None:
                merged.append(item)
                continue
            existing.setdefault("sources", []).extend(item["sources"])
            labels = []
            for source in existing["sources"]:
                label = source.get("provider_label") or source.get("source") or "Source"
                if label not in labels:
                    labels.append(label)
            existing["providers"] = labels
            existing["channel"] = " + ".join(labels)
            existing["description"] = u"%s | %s | %s" % (
                existing.get("time") or item.get("time") or "--:--",
                existing.get("status") or item.get("status") or u"مجدولة",
                existing["channel"])
    return {"entries": merged, "page": 1, "last_page": 1, "total": len(merged)}
