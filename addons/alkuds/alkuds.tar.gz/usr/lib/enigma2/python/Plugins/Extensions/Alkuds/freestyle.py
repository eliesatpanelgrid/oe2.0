# -*- coding: utf-8 -*-
import os
from Components.Sources.List import List as SourceList
from Tools.LoadPixmap import LoadPixmap
from enigma import addFont

FONT = 'Regular'
try:
    addFont(os.path.join(os.path.dirname(__file__), 'fonts', 'NotoNaskhArabic-Bold.ttf'), 'AlkudsArabic', 100, 0)
    FONT = 'AlkudsArabic'
except Exception:
    pass
_icons = {}


def icon(value):
    name = value if isinstance(value, str) and value in (
        'today_matches', 'watch_matches', 'ostora', 'entertainment', 'syrialive',
        'oscar', 'originaltv', 'elahmad', 'alfajer', 'fajershow', 'movie', 'series', 'live', 'groups') else 'video'
    if name not in _icons:
        try:
            _icons[name] = LoadPixmap(os.path.join(os.path.dirname(__file__), 'common', 'postericons', name + '.png'))
        except Exception:
            _icons[name] = None
    return _icons[name]


def decorate(rows):
    result = []
    for index, row in enumerate(rows or []):
        row = tuple(row)
        if len(row) < 4:
            row += ('', 0x00FFFFFF)[max(0, len(row) - 2):]
        result.append(row[:4] + (0x0012223B if index % 2 == 0 else 0x0022394E,
                                 0x00FFFFFF if index % 2 == 0 else 0x00E0F7FF,
                                 icon(row[1]), ''))
    return result


class StyledList(SourceList):
    def __init__(self, rows=None, *args, **kwargs):
        SourceList.__init__(self, decorate(rows), *args, **kwargs)

    def setList(self, rows):
        SourceList.setList(self, decorate(rows))
