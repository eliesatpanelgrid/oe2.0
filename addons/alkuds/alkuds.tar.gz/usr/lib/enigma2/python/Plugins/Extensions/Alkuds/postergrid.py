# -*- coding: utf-8 -*-
"""Bounded, source-only poster browser. Worker threads never touch Enigma UI."""
import hashlib
import json
import os
import re
import threading
import time
import weakref
try:
    from urllib.request import Request, urlopen
    from urllib.parse import urlparse, urljoin
except ImportError:
    from urllib2 import Request, urlopen
    from urlparse import urlparse, urljoin
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from enigma import eTimer, ePicLoad, getDesktop
from .freestyle import FONT

CACHE = '/tmp/alkuds-posters'
PREFS = '/etc/enigma2/alkuds/poster_views.json'
MAX_BYTES = 512 * 1024


def image_url(value):
    value = (value or '').strip()
    if value.startswith('//'):
        value = 'https:' + value
    parsed = urlparse(value)
    if parsed.scheme not in ('http', 'https'):
        return ''
    if parsed.hostname == 'image.tmdb.org':
        value = re.sub(r'/t/p/(?:original|w\d+)/', '/t/p/w185/', value)
    return value


def _key(url):
    return hashlib.sha256(url.encode('utf-8')).hexdigest()


class PosterCache(object):
    def __init__(self):
        self.condition = threading.Condition()
        self.pending = []
        self.owner = None
        self.failed = {}
        self.samples = []
        self.started = False

    def path(self, url):
        return os.path.join(CACHE, _key(url) + '.jpg')

    def fast(self):
        return len(self.samples) >= 3 and sum(self.samples[-3:]) / 3.0 < .8

    def request(self, owner, urls):
        seen = set()
        urls = [url for url in urls if url and not (url in seen or seen.add(url))][:24]
        with self.condition:
            self.owner = owner
            self.pending = [u for u in urls if u and not os.path.isfile(self.path(u))
                            and time.time() - self.failed.get(u, 0) > 60]
            if not self.started:
                self.started = True
                worker = threading.Thread(target=self._worker)
                worker.daemon = True
                worker.start()
            self.condition.notify()

    def cancel(self, owner):
        with self.condition:
            if self.owner is owner:
                self.pending = []
                self.owner = None

    def _trim(self):
        files = []
        for name in os.listdir(CACHE):
            path = os.path.join(CACHE, name)
            if name.endswith('.jpg') and os.path.isfile(path):
                stat = os.stat(path)
                files.append((stat.st_mtime, stat.st_size, path))
        total = sum(row[1] for row in files)
        for _, size, path in sorted(files):
            if total <= 12 * 1024 * 1024 and len(files) <= 120:
                break
            try:
                os.remove(path)
                total -= size
                files.pop()
            except OSError:
                pass

    def _worker(self):
        while True:
            with self.condition:
                while not self.pending:
                    self.condition.wait()
                url = self.pending.pop(0)
            temporary = self.path(url) + '.part'
            started = time.time()
            try:
                if not os.path.isdir(CACHE):
                    os.makedirs(CACHE)
                response = urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=5)
                try:
                    mime = response.headers.get('Content-Type', '').lower()
                    data = response.read(MAX_BYTES + 1)
                finally:
                    response.close()
                if len(data) > MAX_BYTES or not (data.startswith(b'\xff\xd8') or data.startswith(b'\x89PNG\r\n\x1a\n')):
                    raise ValueError('Unsupported or oversized poster')
                with open(temporary, 'wb') as handle:
                    handle.write(data)
                os.rename(temporary, self.path(url))
                self.samples = (self.samples + [time.time() - started])[-6:]
                self._trim()
            except Exception:
                self.failed[url] = time.time()
                if len(self.failed) > 120:
                    self.failed = {url: time.time()}
                try:
                    os.remove(temporary)
                except OSError:
                    pass


_cache = PosterCache()


def _pref(key, value=None):
    try:
        with open(PREFS, 'r') as handle:
            prefs = json.load(handle)
        if not isinstance(prefs, dict):
            prefs = {}
    except Exception:
        prefs = {}
    if value is None:
        return bool(prefs.get(key))
    prefs[key] = bool(value)
    try:
        folder = os.path.dirname(PREFS)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        with open(PREFS + '.tmp', 'w') as handle:
            json.dump(prefs, handle)
        os.rename(PREFS + '.tmp', PREFS)
    except Exception:
        pass


def rows_for(screen, source='list'):
    rows = screen[source].list or []
    if source == 'main_list':
        return [(row[0], image_url(row[5]) if len(row) > 5 else '', i) for i, row in enumerate(rows)]
    items = getattr(screen, 'entries', None) or getattr(screen, 'channels', [])
    result = []
    for index, row in enumerate(rows):
        try:
            item_index = int(row[1])
            if item_index < 0 or item_index >= len(items):
                continue
            item = items[item_index]
            if isinstance(item, dict):
                picture = next((item.get(k) for k in ('image', 'cover', 'stream_icon', 'logo', 'poster', 'icon') if item.get(k)), '')
                title = item.get('name') or row[0]
            else:
                picture = item[3] if len(item) > 3 else getattr(screen, '_poster_images', {}).get(item[1], '')
                title = item[0]
            if picture and not urlparse(picture).scheme:
                portal = getattr(screen, 'portal', {}) or {}
                picture = urljoin(portal.get('host', '') or portal.get('url', ''), picture)
            result.append((title, image_url(picture), index))
        except (TypeError, ValueError, IndexError, AttributeError):
            continue
    return result


class PosterBinding(object):
    def __init__(self, screen, activate, menu, source):
        self.screen, self.activate, self.original_menu, self.source = screen, activate, menu, source
        self.closed, self.grid = False, None
        self.timer = eTimer()
        try:
            self.connection = self.timer.timeout.connect(self.check)
        except Exception:
            self.timer.callback.append(self.check)
        self.original_set = screen[source].setList
        screen[source].setList = self.set_list
        screen['poster_actions'] = ActionMap(['AlkudsActions'], {'menu': self.menu}, -10)
        screen.onClose.append(self.cleanup)
        screen.onShow.append(self.schedule)

    def key(self):
        return '%s:%s:%s:%s' % (type(self.screen).__name__, getattr(self.screen, 'provider', ''),
                                getattr(self.screen, 'kind', ''), getattr(self.screen, 'level', 'channels'))

    def set_list(self, rows):
        self.original_set(rows)
        self.schedule()

    def schedule(self):
        if not self.closed:
            self.timer.start(200, True)

    def check(self):
        if self.closed:
            return
        if self.grid:
            if getattr(self.screen.session, 'current_dialog', None) is self.grid:
                self.grid.refresh()
        elif getattr(self.screen.session, 'current_dialog', None) is self.screen and _pref(self.key()) and rows_for(self.screen, self.source):
            self.open()

    def menu(self):
        if self.source == 'main_list':
            try:
                if self.screen['menu_actions'].enabled:
                    self.screen.closeChoiceBoxDialog()
                    return
            except (KeyError, AttributeError):
                pass
        self.screen.session.openWithCallback(self.choice, ChoiceBox, title=u'طريقة العرض',
            list=[(u'عرض بوسترات', 'posters'), (u'عرض قائمة', 'list'), (u'خيارات القائمة / المشغّل', 'options')])

    def choice(self, choice):
        if not choice or self.closed:
            return
        if choice[1] == 'options':
            if self.grid and self.source == 'main_list':
                self.grid.close('options')
            elif self.original_menu:
                self.original_menu()
        elif choice[1] == 'list':
            _pref(self.key(), False)
            if self.grid:
                self.grid.close('list')
        else:
            _pref(self.key(), True)
            self.open()

    def open(self):
        if self.closed or self.grid or not rows_for(self.screen, self.source):
            return
        self.grid = self.screen.session.openWithCallback(self.returned, PosterGrid, self)

    def returned(self, result=None):
        self.grid = None
        if result == 'options' and not self.closed:
            if self.original_menu:
                self.original_menu()
            return
        if result == 'back' and not self.closed:
            action = getattr(self.screen, 'back', None) or getattr(self.screen, '_safe_close', None) or self.screen.close
            action()

    def cleanup(self):
        self.closed = True
        self.timer.stop()
        try:
            self.timer.callback.remove(self.check)
        except (AttributeError, ValueError):
            pass
        self.screen[self.source].setList = self.original_set
        if self.schedule in self.screen.onShow:
            self.screen.onShow.remove(self.schedule)
        self.connection = None


def install(screen, activate, menu=None, source='list'):
    if not hasattr(screen, '_poster_binding'):
        screen._poster_binding = PosterBinding(screen, activate, menu, source)


class PosterGrid(Screen):
    def __init__(self, session, binding):
        Screen.__init__(self, session)
        self.binding = binding
        self.closed = False
        self.rows, self.index, self.start = [], 0, -1
        self.decoders, self.decoding, self.displayed = {}, {}, {}
        width, height = getDesktop(0).size().width(), getDesktop(0).size().height()
        self.columns = 6 if width >= 1920 else 5
        self.count = self.columns * 2
        cell_w, cell_h = (width - 48) // self.columns, (height - 150) // 2
        self.image_w = min(185, cell_w - 20)
        self.image_h = cell_h - 66
        xml = ['<screen name="AlkudsPosterGrid" position="0,0" size="%d,%d" backgroundColor="#101b32" flags="wfNoBorder">' % (width, height),
               '<widget name="title" position="24,12" size="%d,45" font="Regular;34" />' % (width - 48)]
        self['title'] = Label('')
        self['footer'] = Label(u'OK فتح | Menu طريقة العرض | CH+/- صفحة | أزرق/أصفر صفحات المصدر | أحمر رجوع')
        for slot in range(self.count):
            x, y = 24 + (slot % self.columns) * cell_w, 68 + (slot // self.columns) * cell_h
            self['image%d' % slot] = Pixmap()
            self['label%d' % slot] = Label('')
            self['empty%d' % slot] = Label(u'بدون صورة')
            image_x = x + (cell_w - self.image_w) // 2
            xml.append('<widget name="empty%d" position="%d,%d" size="%d,%d" font="Regular;20" halign="center" valign="center" backgroundColor="#182744" zPosition="1" />' % (slot, image_x, y, self.image_w, self.image_h))
            xml.append('<widget name="image%d" position="%d,%d" size="%d,%d" alphatest="blend" zPosition="2" />' % (slot, image_x, y, self.image_w, self.image_h))
            xml.append('<widget name="label%d" position="%d,%d" size="%d,58" font="Regular;25" halign="center" valign="center" />' % (slot, x + 5, y + self.image_h + 3, cell_w - 10))
        xml.append('<widget name="footer" position="24,%d" size="%d,52" font="Regular;20" halign="center" valign="center" /></screen>' % (height - 62, width - 48))
        self.skin = ''.join(xml).replace('Regular;', FONT + ';')
        self['actions'] = ActionMap(['AlkudsActions'], {
            'cancel': lambda: self.close('back'), 'red': lambda: self.close('back'),
            'menu': binding.menu, 'ok': self.activate, 'green': self.activate,
            'left': lambda: self.move(-1), 'right': lambda: self.move(1),
            'up': lambda: self.move(-self.columns), 'down': lambda: self.move(self.columns),
            'channelUp': lambda: self.move(-self.count), 'channelDown': lambda: self.move(self.count),
            'blue': lambda: self.source_page('next_or_refresh'),
            'yellow': lambda: self.source_page('previous_page')}, -10)
        self.timer = eTimer()
        try:
            self.connection = self.timer.timeout.connect(self.poll)
        except Exception:
            self.timer.callback.append(self.poll)
        self.onLayoutFinish.append(self.refresh)
        self.onHide.append(self.suspend)
        self.onShow.append(self.resume)
        self.onClose.append(self.cleanup)

    def refresh(self):
        if self.closed:
            return
        self.rows = rows_for(self.binding.screen, self.binding.source)
        if self.start == -1 and self.rows:
            selected = self.binding.screen[self.binding.source].getIndex()
            self.index = next((i for i, row in enumerate(self.rows) if row[2] == selected), self.index)
        self.index = min(self.index, max(0, len(self.rows) - 1))
        self.start = -1
        self.draw()

    def move(self, delta):
        if self.closed or not self.rows:
            return
        self.index = max(0, min(len(self.rows) - 1, self.index + delta))
        self.draw()

    def draw(self):
        start = (self.index // self.count) * self.count
        changed = start != self.start
        self.start = start
        self['title'].setText(u'عرض البوسترات   %d / %d' % (self.index + 1 if self.rows else 0, len(self.rows)))
        for slot in range(self.count):
            index = start + slot
            title = self.rows[index][0] if index < len(self.rows) else ''
            self['label%d' % slot].setText((u'▶ ' if index == self.index else '') + title)
            if changed:
                self['image%d' % slot].hide()
                self['empty%d' % slot].show()
                self['empty%d' % slot].setText(u'جاري التحميل...' if index < len(self.rows) and self.rows[index][1] else u'بدون صورة' if title else '')
        if changed:
            self.displayed = {}
            urls = [row[1] for row in self.rows[start:start + self.count * (2 if _cache.fast() else 1)] if row[1]]
            _cache.request(self, urls)
            self.timer.start(180, False)

    def poll(self):
        if self.closed:
            return
        for slot, row in enumerate(self.rows[self.start:self.start + self.count]):
            url = row[1]
            if not url or self.displayed.get(slot) == url or slot in self.decoding:
                continue
            path = _cache.path(url)
            if not os.path.isfile(path):
                if url in _cache.failed:
                    self['empty%d' % slot].setText(u'الصورة غير متاحة')
                continue
            if len(self.decoding) >= 2:
                break
            decoder = ePicLoad()
            owner = weakref.ref(self)
            callback = lambda info=None, slot=slot, url=url, owner=owner: owner() and owner().decoded(slot, url)
            try:
                connection = decoder.PictureData.connect(callback)
            except Exception:
                decoder.PictureData.get().append(callback)
                connection = None
            self.decoders[slot] = (decoder, connection, callback)
            self.decoding[slot] = url
            decoder.setPara((self.image_w, self.image_h, 1, 1, False, 1, 'FF101B32'))
            try:
                result = decoder.startDecode(path)
                if result:
                    self.decoding.pop(slot, None)
                    self.displayed[slot] = url
                    self['empty%d' % slot].setText(u'تعذّر عرض الصورة')
            except Exception:
                self.decoding.pop(slot, None)
                self.displayed[slot] = url
                self['empty%d' % slot].setText(u'تعذّر عرض الصورة')
        if all(not row[1] or self.displayed.get(slot) == row[1] or row[1] in _cache.failed
               for slot, row in enumerate(self.rows[self.start:self.start + self.count])) and not self.decoding:
            self.timer.stop()

    def decoded(self, slot, url):
        self.decoding.pop(slot, None)
        if self.closed or self.start + slot >= len(self.rows) or self.rows[self.start + slot][1] != url:
            return
        self.displayed[slot] = url
        decoder = self.decoders[slot][0]
        pixmap = decoder.getData()
        if pixmap is not None and self['image%d' % slot].instance:
            self['image%d' % slot].instance.setPixmap(pixmap)
            self['image%d' % slot].show()
            self['empty%d' % slot].hide()
        else:
            self['empty%d' % slot].setText(u'تعذّر عرض الصورة')

    def suspend(self):
        self.timer.stop()
        _cache.cancel(self)

    def resume(self):
        if not self.closed and self.rows:
            self.start = -1
            self.draw()

    def activate(self):
        if self.rows and not self.closed and not getattr(self.binding.screen, '_loading', False):
            self.binding.screen[self.binding.source].setIndex(self.rows[self.index][2])
            self.binding.activate()

    def source_page(self, name):
        action = getattr(self.binding.screen, name, None)
        if action and not getattr(self.binding.screen, '_loading', False):
            action()

    def cleanup(self):
        self.closed = True
        self.timer.stop()
        _cache.cancel(self)
        try:
            self.timer.callback.remove(self.poll)
        except (AttributeError, ValueError):
            pass
        # Retain active decoders until callbacks finish; callbacks check closed
        # before touching any native widget.
        self.connection = None
