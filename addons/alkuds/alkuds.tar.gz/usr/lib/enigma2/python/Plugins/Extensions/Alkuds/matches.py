# -*- coding: utf-8 -*-
import threading
from datetime import datetime
import requests
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from enigma import eTimer
from .xStaticText import StaticText
from .subscriptionui import move_cards
from .matchui import match_skin, fixture_card, message_card
from .matchdata import parse_fixtures


class Alkuds_Matches(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = match_skin()
        self.day = 0
        self.rows = []
        self.loading = False
        self.closed = False
        self.result = None
        self.done = False
        self.error = ""
        self["title"] = StaticText(u"مباريات اليوم - سوريا لايف")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Previous day")
        self["key_yellow"] = StaticText("Next day")
        self["key_blue"] = StaticText("Refresh")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "AlkudsActions"], {
            "cancel": self.close, "red": self.close, "blue": self.load,
            "green": lambda: self.change_day(-1), "yellow": lambda: self.change_day(1),
            "ok": self.details, "info": self.details,
            "up": lambda: move_cards(self, "moveUp"), "down": lambda: move_cards(self, "moveDown"),
            "left": lambda: move_cards(self, "pageUp"), "right": lambda: move_cards(self, "pageDown"),
        }, -2)
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self.poll)
        except Exception:
            self.timer.callback.append(self.poll)
        self.refresh_timer = eTimer()
        try:
            self.refresh_conn = self.refresh_timer.timeout.connect(self.load)
        except Exception:
            self.refresh_timer.callback.append(self.load)
        self.onFirstExecBegin.append(self.load)
        self.onClose.append(self.cleanup)

    def change_day(self, delta):
        if not self.loading:
            self.day = max(-1, min(1, self.day + delta))
            self.rows = []
            self.load()

    def load(self):
        if self.loading or self.closed:
            return
        self.refresh_timer.stop()
        self.loading, self.done = True, False
        self.error, self.result = "", None
        self["title"].setText("Syria Live - %s - Loading..." % {-1:"Yesterday",0:"Today",1:"Tomorrow"}[self.day])
        if not self.rows:
            self["list"].setList([message_card("Loading fixtures...")])
        worker = threading.Thread(target=self.fetch, args=(self.day,))
        worker.daemon = True
        worker.start()
        self.timer.start(150, False)

    def fetch(self, day):
        try:
            page = {-1:"matches-yesterday",0:"matches-today",1:"matches-tomorrow"}[day]
            with requests.get("https://syriashdab.com/" + page + "/", headers={"User-Agent":"Mozilla/5.0"}, timeout=(8,20), stream=True) as response:
                response.raise_for_status()
                chunks, total = [], 0
                for chunk in response.iter_content(16384):
                    if self.closed:
                        return
                    total += len(chunk)
                    if total > 2 * 1024 * 1024:
                        raise ValueError("Page is too large")
                    chunks.append(chunk)
                html = b"".join(chunks).decode("utf-8", "replace")
            self.result = parse_fixtures(html)
            if not self.result:
                self.error = "No fixtures found. The schedule may be empty or the website format has changed."
        except Exception:
            self.error = "Unable to update Syria Live. Check your connection and press BLUE to retry."
        finally:
            self.done = True

    def poll(self):
        if self.closed or not self.done:
            return
        self.timer.stop()
        self.loading = False
        self.refresh_timer.start(60000, True)
        day = {-1:"Yesterday",0:"Today",1:"Tomorrow"}[self.day]
        if self.error:
            self["title"].setText("Syria Live - %s - Update failed" % day)
            if not self.rows:
                self["list"].setList([message_card("Schedule unavailable - BLUE to retry")])
            self.session.open(MessageBox, self.error, MessageBox.TYPE_INFO, timeout=8)
            return
        self.rows = self.result
        cards = []
        for index, row in enumerate(self.rows):
            title = "%s   %s   %s" % (row["names"][0], row["score"], row["names"][1])
            detail = row["label"] + "  |  " + (row["meta"][-1] if row["meta"] else "Syria Live")
            cards.append(fixture_card(row,index))
        self["list"].setList(cards)
        self["title"].setText("Syria Live - %s  /  %d  /  Updated %s" % (day,len(cards),datetime.now().strftime("%H:%M")))

    def details(self):
        current = self["list"].getCurrent()
        if not current or current[1] < 0 or current[1] >= len(self.rows):
            return
        row = self.rows[current[1]]
        text = "%s  %s  %s\n\n%s\n%s\n\n%s\n\nSource: syriashdab.com" % (row["names"][0],row["score"],row["names"][1],row["when"],row["label"],"\n".join(row["meta"]))
        self.session.open(MessageBox,text,MessageBox.TYPE_INFO)

    def cleanup(self):
        self.closed = True
        self.timer.stop()
        self.refresh_timer.stop()
