# -*- coding: utf-8 -*-
"""Country-organized Arabic radio catalogue from World Radio Map."""
from __future__ import unicode_literals

import re

import requests

try:
    from html import unescape as html_unescape
except ImportError:
    from HTMLParser import HTMLParser
    html_unescape = HTMLParser().unescape

try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

try:
    text_type = unicode
except NameError:
    text_type = str


BASE = "https://worldradiomap.com/"
COUNTRIES = (
    ("ps", u"فلسطين", ((u"رام الله", BASE + "ps/ramallah"),)),
    ("lb", u"لبنان", ((u"بيروت", BASE + "lb/beirut"),)),
    ("jo", u"الأردن", ((u"عمّان", BASE + "jo/amman"),)),
    ("sy", u"سوريا", ((u"دمشق", BASE + "sy/dimashq"),)),
    ("iq", u"العراق", ((u"بغداد", BASE + "iq/baghdad"),)),
    ("eg", u"مصر", (
        (u"القاهرة", BASE + "eg/al-qahirah"),
        (u"الإسكندرية", BASE + "eg/al-iskandariyah"),
    )),
)
QURAN = (
    (u"إذاعة القرآن الكريم", u"السعودية", "http://curiosity.shoutca.st:6035/stream"),
)

HEBREW = re.compile(u"[\u0590-\u05ff]")
ANCHOR = re.compile(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', re.I | re.S)
TAG = re.compile(r'<[^>]+>')
MEDIA = re.compile(r'<(?:audio|source)\b[^>]*src=["\']([^"\']+)', re.I)
ABSOLUTE = re.compile(r'https?://[^\s"\'<>]+', re.I)


def _headers(user_agent, referer=BASE + "alarabiya"):
    return {
        "User-Agent": text_type(user_agent or "Alkuds-Enigma2/1.98"),
        "Referer": referer,
        "Accept-Language": "ar,en;q=0.8",
    }


def _clean(value):
    value = TAG.sub(" ", value or "")
    value = html_unescape(value)
    return re.sub(r"\s+", " ", value).strip()


def _country(code):
    for item in COUNTRIES:
        if item[0] == code:
            return item
    return None


def _station_page_url(page_url, href, country_code):
    raw = html_unescape(href or "").strip()
    if raw.startswith(("http://", "https://", "//")):
        return urljoin(page_url, raw)
    match = re.search(r"(?:^|/)([a-z]{2})/play/(.+)$", raw, re.I)
    if match:
        return urljoin(BASE, match.group(1).lower() + "/play/" + match.group(2))
    if raw.lower().startswith("play/"):
        return urljoin(BASE, country_code + "/" + raw)
    return urljoin(page_url + "/", raw)


def _get(url, user_agent, referer=None, allow_redirects=True):
    response = requests.get(
        url,
        headers=_headers(user_agent, referer or BASE + "alarabiya"),
        timeout=(8, 25),
        verify=False,
        allow_redirects=allow_redirects,
    )
    response.raise_for_status()
    if response.encoding in (None, "ISO-8859-1"):
        response.encoding = "utf-8"
    return response


def groups():
    rows = []
    for code, name, cities in COUNTRIES:
        rows.append({
            "name": name,
            "description": u"، ".join(city[0] for city in cities),
            "source": "worldradiomap",
            "code": code,
            "count": 0,
        })
    rows.append({
        "name": u"القرآن الكريم",
        "description": u"إذاعات القرآن الكريم",
        "source": "worldradiomap",
        "code": "quran",
        "count": len(QURAN),
    })
    return rows


def _direct_rows(code, selected, user_agent):
    rows = []
    for index, (name, country, url) in enumerate(selected):
        headers = _headers(user_agent)
        stream = {
            "url": url,
            "name": u"بث مباشر",
            "quality": u"بث مباشر",
            "mediatype": "hls" if ".m3u8" in url.lower() else "audio",
            "relay": False,
            "headers": headers,
        }
        rows.append({
            "id": "wrm:%s:%d" % (code, index),
            "name": name,
            "description": country,
            "image": "",
            "streams": [stream],
            "url": url,
            "urls": [url],
            "headers": headers,
            "is_live": True,
            "source": "worldradiomap",
        })
    return rows


def items(parent, user_agent, page=1):
    code = (parent or {}).get("code")
    if code == "quran":
        rows = _direct_rows(code, QURAN, user_agent)
        return {"entries": rows, "page": 1, "last_page": 1, "total": len(rows)}

    country = _country(code)
    if not country:
        return {"entries": [], "page": 1, "last_page": 1, "total": 0}

    rows = []
    seen = set()
    for city_name, page_url in country[2]:
        response = _get(page_url, user_agent)
        for href, label_html in ANCHOR.findall(response.text):
            station_page = _station_page_url(page_url, href, code)
            lower_page = station_page.lower()
            if "/play/" not in lower_page or "/il/" in lower_page:
                continue
            name = _clean(label_html)
            if not name or HEBREW.search(name) or station_page in seen:
                continue
            seen.add(station_page)
            rows.append({
                "id": "wrm:%s:%d" % (code, len(rows)),
                "name": name,
                "description": city_name,
                "image": "",
                "station_page": station_page,
                "url": station_page,
                "urls": [station_page],
                "headers": _headers(user_agent, page_url),
                "is_live": True,
                "source": "worldradiomap",
            })

    return {"entries": rows, "page": 1, "last_page": 1, "total": len(rows)}


def _playlist_url(url, user_agent, referer):
    lower = url.lower().split("?", 1)[0]
    if not lower.endswith((".m3u", ".pls")):
        return url
    response = _get(url, user_agent, referer=referer)
    for line in response.text.splitlines():
        line = line.strip()
        if line.lower().startswith("file") and "=" in line:
            line = line.split("=", 1)[1].strip()
        if line.startswith(("http://", "https://")):
            return line
    return url


def resolve(item, user_agent):
    station_page = (item or {}).get("station_page")
    if not station_page:
        return item

    response = None
    stream_url = ""
    for unused in range(4):
        response = _get(station_page, user_agent, allow_redirects=False)
        location = response.headers.get("Location", "").strip()
        if not location:
            break
        target = urljoin(station_page, location)
        lowered = target.lower()
        if "/play/" in lowered and ("worldradiomap.com/" in lowered or "radiomap.eu/" in lowered):
            station_page = target
            continue
        stream_url = target
        break

    if not stream_url:
        candidates = MEDIA.findall(response.text)
        if not candidates:
            candidates = ABSOLUTE.findall(response.text)
        for candidate in candidates:
            candidate = html_unescape(candidate).replace("\\/", "/").strip()
            lowered = candidate.lower()
            if (lowered.endswith((".m3u", ".m3u8", ".pls", ".mp3", ".aac", ".ogg"))
                    or "/stream" in lowered or re.search(r":\d{2,5}(?:/|$)", lowered)):
                stream_url = urljoin(station_page, candidate)
                break
    if not stream_url:
        raise ValueError("No playable stream was found")

    stream_url = _playlist_url(stream_url, user_agent, station_page)
    result = dict(item)
    headers = _headers(user_agent, station_page)
    result["url"] = stream_url
    result["urls"] = [stream_url]
    result["headers"] = headers
    result["streams"] = [{
        "url": stream_url,
        "name": u"بث مباشر",
        "quality": u"بث مباشر",
        "mediatype": "hls" if ".m3u8" in stream_url.lower() else "audio",
        "relay": False,
        "headers": headers,
    }]
    return result
