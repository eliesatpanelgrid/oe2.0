# -*- coding: utf-8 -*-
from .subscriptionui import cards_skin
import xml.etree.ElementTree as ET


def match_skin():
    from enigma import getDesktop
    width = getDesktop(0).size().width()
    scale = width / 1280.0
    def n(value):return max(1,int(value*scale))
    root=ET.fromstring(cards_skin("SYRIA LIVE  /  MATCHES TODAY  /  RIYADH UTC+3"))
    template=root.find('.//convert')
    cw=width-2*n(48)
    entries=[]
    for x,y,w,h,font,field,align,color in [
        (24,8,1136,26,2,6,"LEFT","d6b879"),
        (24,42,430,44,0,0,"CENTER","ffffff"),
        (454,36,276,55,1,3,"CENTER","ffffff"),
        (730,42,430,44,0,2,"CENTER","ffffff"),
        (24,100,800,28,2,5,"LEFT","9ddbd7"),
        (824,100,336,28,2,4,"RIGHT","d6b879")]:
        entries.append('MultiContentEntryText(pos=(%d,%d),size=(%d,%d),font=%d,flags=RT_HALIGN_%s|RT_VALIGN_CENTER,text=%d,color=0x00%s)' % (n(x),n(y),n(w),n(h),font,align,field,color))
    template.text='{"template":['+','.join(entries)+'],"fonts":[gFont("Regular",%d),gFont("Regular",%d),gFont("Regular",%d)],"itemHeight":%d}' % (n(25),n(36),n(17),n(140))
    return ET.tostring(root,encoding="unicode")


def fixture_card(row, index):
    return (row["names"][0],index,row["names"][1],row["score"],row["label"],row["when"],row["meta"][-1] if row["meta"] else "Syria Live")


def message_card(message):
    return (message,-1,"","","","","")
