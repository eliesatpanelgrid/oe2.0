# -*- coding: utf-8 -*-
"""Bounded local JSON account import. No network, authentication or telemetry."""
from __future__ import print_function
import hashlib
import io
import json
import os
import re
import tempfile
try:
    from urllib.parse import urlparse, parse_qs, urlencode
except ImportError:
    from urlparse import urlparse, parse_qs
    from urllib import urlencode

STORE = '/etc/enigma2/alkuds/local-import.json'
ROOTS = ('/etc/enigma2', '/media/hdd', '/media/usb', '/media/mmc', '/media/cf')


def read_store(path=STORE):
    try:
        with io.open(path, encoding='utf-8-sig') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, ValueError):
        return {}


def atomic_write(path, text):
    parent = os.path.dirname(path)
    if not os.path.isdir(parent):
        os.makedirs(parent)
    fd, temporary = tempfile.mkstemp(prefix='.alkuds-import-', dir=parent)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, 'wb') as handle:
            handle.write(text.encode('utf-8'))
            handle.flush()
            os.fsync(handle.fileno())
        os.rename(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def identity(kind, record):
    host = str(record.get('host') or record.get('portal') or '').strip().rstrip('/')
    parsed = urlparse(host)
    # URL host is case insensitive; account values and portal paths are not.
    host = parsed.scheme.lower() + '://' + parsed.netloc.lower() + parsed.path
    if kind == 'xtream':
        values = [kind, host, str(record.get('username') or ''), str(record.get('password') or '')]
    else:
        host = re.sub(r'/(?:c|server/load\.php|portal\.php)/?$', '', host.rstrip('/'))
        values = [kind, host.rstrip('/'), str(record.get('mac') or '').upper()]
    return hashlib.sha256(json.dumps(values, ensure_ascii=True).encode('utf-8')).hexdigest()


def records(data, depth=0):
    if depth > 12:
        return
    if isinstance(data, dict):
        yield data
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                for row in records(value, depth + 1):
                    yield row
    elif isinstance(data, list):
        for value in data:
            for row in records(value, depth + 1):
                yield row


def normalise(row):
    host = str(row.get('host') or row.get('portal') or row.get('server') or row.get('url') or row.get('domain') or '').strip()
    if not host or any(c in host for c in ('\n', '\r', '\x00')):
        return None
    if '://' not in host:
        protocol = str(row.get('protocol') or 'http://')
        host = ('https://' if protocol.startswith('https') else 'http://') + host
    try:
        parsed = urlparse(host)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
            return None
        port = parsed.port
    except ValueError:
        return None
    if not port and row.get('port'):
        try:
            port = int(row['port'])
            if port < 1 or port > 65535:
                return None
            host = parsed.scheme + '://' + parsed.netloc + ':' + str(port) + parsed.path
            parsed = urlparse(host)
        except (ValueError, TypeError):
            return None
    name = re.sub(r'[\r\n\x00#]', ' ', str(row.get('name') or parsed.hostname)).strip()
    mac = str(row.get('mac') or row.get('mac_address') or '').strip().replace('-', ':').upper()
    if re.match(r'^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$', mac):
        result = dict(row)
        result.update(host=host, mac=mac, name=name)
        return 'stalker', result
    query = parse_qs(parsed.query, keep_blank_values=True)
    username = str(row.get('username') or row.get('user') or (query.get('username') or [''])[0])
    password = str(row.get('password') or row.get('pass') or (query.get('password') or [''])[0])
    if not username or not password or any(c in username + password for c in ('\r', '\n', '\x00')):
        return None
    output = str(row.get('output') or (query.get('output') or ['ts'])[0])
    output = 'm3u8' if output in ('m3u8', 'hls') else 'ts'
    return 'xtream', dict(host=parsed.scheme + '://' + parsed.netloc,
                          username=username, password=password, name=name, output=output)


def json_paths(roots):
    seen, visited, file_count, byte_count = set(), 0, 0, 0
    for root in roots:
        if not os.path.isdir(root) or os.path.islink(root):
            continue
        for current, dirs, files in os.walk(root, followlinks=False):
            visited += 1
            if visited > 2000:
                return
            depth = os.path.relpath(current, root).count(os.sep) + (current != root)
            dirs[:] = sorted(d for d in dirs if not d.startswith('.') and d not in ('movie', 'timeshift', 'picon', 'epg', 'lost+found') and not os.path.islink(os.path.join(current, d))) if depth < 3 else []
            for name in sorted(files):
                lower = name.lower()
                if not lower.endswith('.json') or lower.startswith(('remote_backup', 'alkuds_ipaudio_telegram', 'local-import')):
                    continue
                path = os.path.join(current, name)
                if path in seen or os.path.islink(path):
                    continue
                seen.add(path)
                try:
                    size = os.path.getsize(path)
                    if size > 8 * 1024 * 1024:
                        continue
                    file_count += 1
                    byte_count += size
                    if file_count > 1000 or byte_count > 64 * 1024 * 1024:
                        return
                except OSError:
                    continue
                yield path


def scan(roots=None, store_path=STORE):
    data = read_store(store_path)
    data.setdefault('xtream', [])
    data.setdefault('stalker', [])
    seen = {kind: set(identity(kind, row) for row in data[kind]) for kind in ('xtream', 'stalker')}
    roots = list(roots if roots is not None else ROOTS)
    if roots == list(ROOTS):
        try:
            roots.extend(os.path.join('/media', name) for name in sorted(os.listdir('/media')) if name not in ('net', 'autofs'))
        except OSError:
            pass
    for path in json_paths(roots):
        if os.path.abspath(path) == os.path.abspath(store_path):
            continue
        try:
            with io.open(path, encoding='utf-8-sig') as handle:
                content = json.load(handle)
        except (IOError, ValueError, UnicodeError):
            continue
        for row in records(content):
            entry = normalise(row)
            if not entry:
                continue
            kind, account = entry
            marker = identity(kind, account)
            if marker not in seen[kind]:
                seen[kind].add(marker)
                data[kind].append(account)
    atomic_write(store_path, json.dumps(data, ensure_ascii=True, indent=2))
    return {kind: len(data[kind]) for kind in ('xtream', 'stalker')}


def apply_xtream(playlist_path, store_path=STORE):
    data = read_store(store_path)
    accounts = data.get('xtream') or []
    if not accounts:
        return
    try:
        with io.open(playlist_path, encoding='utf-8') as handle:
            content = handle.read()
    except IOError:
        content = ''
    existing = set()
    for line in content.splitlines():
        entry = normalise({'url': line.split(' #', 1)[0].strip()})
        if entry and entry[0] == 'xtream':
            existing.add(identity(*entry))
    applied = set(data.get('applied_xtream') or [])
    lines = []
    for account in accounts:
        marker = identity('xtream', account)
        if marker not in existing and marker not in applied:
            query = urlencode({'username': account['username'], 'password': account['password'], 'type': 'm3u_plus', 'output': account['output']})
            lines.append(account['host'] + '/get.php?' + query + ' #' + account['name'])
            existing.add(marker)
        applied.add(marker)
    if lines:
        atomic_write(playlist_path, content.rstrip('\n') + ('\n' if content else '') + '\n'.join(lines) + '\n')
    data['applied_xtream'] = sorted(applied)
    atomic_write(store_path, json.dumps(data, ensure_ascii=True, indent=2))


def is_imported(kind, account, store_path=STORE):
    marker = identity(kind, account)
    return any(identity(kind, row) == marker for row in read_store(store_path).get(kind, []))


if __name__ == '__main__':
    try:
        counts = scan()
        print('Local import: %d Xtream, %d MAC' % (counts['xtream'], counts['stalker']))
    except Exception:
        # Never log subscription URLs, passwords or device identifiers.
        print('Local account import could not finish; existing accounts were kept.')
