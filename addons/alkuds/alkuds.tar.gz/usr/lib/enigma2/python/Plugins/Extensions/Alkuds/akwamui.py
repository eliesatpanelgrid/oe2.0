# -*- coding: utf-8 -*-
import threading
from Screens.MessageBox import MessageBox
from . import akwam
from .freechannels import Alkuds_Egybest_Browser, _list_entry
from .fajershowui import Alkuds_FajerShow_Qualities


class Alkuds_Akwam_Browser(Alkuds_Egybest_Browser):
    def __init__(self, session, section='movies', level='groups', parent=None, page=1):
        self.section = section
        Alkuds_Egybest_Browser.__init__(self, session, 'series' if section == 'series' else 'movie', level, parent, page)
        self.level = level
        self['key_green'].setText(u'فتح')
        self['key_yellow'].setText(u'السابق' if level == 'items' else '')
        self['key_blue'].setText(u'التالي' if level == 'items' else u'تحديث')
        self._update_title()

    def _label(self):
        section = dict(akwam.SECTIONS).get(self.section, u'كل الأقسام')
        return u'أكوام AKWAM' + (u' - ' + section if self.level != 'groups' else '') + (u' - ' + self.parent.get('name', '') if self.parent.get('name') else '')

    def load(self):
        if self._loading or self._closed:
            return
        self._operation, self._loading, self._done = 'load', True, False
        self._result, self._error = None, ''
        self['list'].setList([_list_entry(u'جاري تحميل أكوام...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == 'groups':
                self._result = [{'name': u'بحث في جميع الأقسام', 'action': 'search'}] + [
                    {'name': name, 'section': section} for section, name in akwam.SECTIONS]
            elif self.level == 'filters':
                filters = akwam.fetch_filters(self.section, self.parent.get('params'))
                rows = [{'name': u'بحث في جميع الأقسام', 'action': 'search'}]
                for filt in filters:
                    row = dict(filt)
                    value = str(self.parent.get('params', {}).get(filt['key'], '0'))
                    selected = next((o['name'] for o in filt['options'] if o['value'] == value), '')
                    if value != '0' and selected:
                        row['name'] += u' : ' + selected
                    row['action'] = 'filter'
                    rows.append(row)
                rows.extend([{'name': u'عرض النتائج', 'action': 'results'},
                             {'name': u'إلغاء الفلاتر', 'action': 'reset'}])
                self._result = rows
            elif self.level == 'options':
                self._result = self.parent.get('options', [])
            elif self.level == 'items':
                self._result = akwam.fetch_items(self.section, self.page, self.parent.get('params'), self.parent.get('query', ''))
            else:
                self._result = akwam.fetch_detail(self.parent)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def open_current(self):
        if self._loading or self._closed:
            return
        index = self._index()
        if not 0 <= index < len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        action = item.get('action')
        if action == 'search':
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            self.session.openWithCallback(self._search_done, VirtualKeyBoard, title=u'بحث أكوام في جميع الأقسام', text='')
        elif self.level == 'groups':
            self.session.open(type(self), item['section'], 'filters')
        elif self.level == 'options':
            self.close(item)
        elif action == 'filter':
            self._filter_key = item['key']
            self.session.openWithCallback(self._filter_done, type(self), self.section, 'options', item)
        elif action == 'reset':
            self.parent['params'] = {}
            self.load()
        elif action == 'results':
            self.session.open(type(self), self.section, 'items', {'params': dict(self.parent.get('params', {}))})
        elif self.level == 'items' or action == 'detail':
            self.session.open(type(self), item.get('section', self.section), 'detail', item)
        elif action == 'download':
            self.session.open(MessageBox, u'هذا العنصر ملف تحميل وليس رابط مشاهدة مباشر.\nيمكن تنزيله من صفحة الموقع:\n' + item['url'], MessageBox.TYPE_INFO)
        elif action == 'play':
            self._operation, self._loading, self._done = 'resolve', True, False
            self._result, self._error = None, ''
            self._update_title(u' - جاري تجهيز الفيديو...')
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)

    def _filter_done(self, choice):
        if self._closed or not choice:
            return
        values = dict(self.parent.get('params', {}))
        values[self._filter_key] = choice['value']
        if self._filter_key == 'section':
            values.pop('category', None)
        self.parent['params'] = values
        self.load()

    def _search_done(self, value):
        if self._closed or not value or not value.strip():
            return
        query = value.strip()
        self.session.open(type(self), 'all', 'items', {'query': query, 'name': u'البحث: ' + query}, 1)

    def _resolve_worker(self, item):
        try:
            self._result = akwam.resolve_watch(item)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _start_resolved(self, item):
        self.session.open(Alkuds_FajerShow_Qualities, {'variants': item['streams']},
                          item['name'], 'Series' if self.section == 'series' else 'Movie',
                          self.parent.get('name', ''), item.get('image', ''),
                          'akwam:' + self.parent.get('url', item['url']))
