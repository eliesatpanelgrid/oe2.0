# -*- coding: utf-8 -*-
"""On-demand movies and series for the one selected MAC subscription."""
import threading
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from enigma import eTimer
from .stalker import StalkerClient, Alkuds_Stalker_Genres, _skin
from .subscriptionui import move_cards, safe_name
from .xStaticText import StaticText


def portal_rows(payload):
    if isinstance(payload, list):
        return [r for r in payload if isinstance(r, dict)]
    if isinstance(payload, dict):
        data = payload.get("data", [])
        return [r for r in data if isinstance(r, dict)] if isinstance(data, list) else []
    return []


def catalogue_page(client, kind, level, parent, page):
    if not client.token:
        client.connect()
    params = {"type":kind,"action":"get_categories" if level == "categories" else "get_ordered_list","JsHttpRequest":"1-xml"}
    if level != "categories":
        params.update({"p":str(page),"sortby":"added"})
        if level == "items":
            params["category"] = str(parent.get("id", "*"))
        else:
            params["movie_id"] = str(parent.get("_movie_id") or parent.get("id") or "")
            params["season_id"] = str(parent.get("id") or "0") if level == "episodes" else "0"
            params["episode_id"] = "0"
    js = client._extract_js(client._request(params))
    rows = portal_rows(js)
    pages = page
    if level == "categories":
        # An all-items path is useful for servers with no category names.
        rows = [{"id":"*","title":"All"}] + [r for r in rows if str(r.get("id")) not in ("*","0")]
    elif isinstance(js, dict):
        try:
            per = int(js.get("max_page_items") or len(rows) or 1)
            total = int(js.get("total_items") or len(rows))
            pages = max(page, (total + per - 1) // per) if per > 0 else page
        except (TypeError, ValueError):
            pass
    return rows, pages


def episode_rows(item):
    values = item.get("series")
    if not isinstance(values, list) or not values:
        return []
    rows = []
    for value in values:
        row = dict(value) if isinstance(value, dict) else {"series":str(value),"name":"Episode %s" % value}
        row.setdefault("cmd", item.get("cmd", ""))
        row.setdefault("_movie_id", item.get("_movie_id") or item.get("id"))
        row["_episode"] = row.get("series") or row.get("series_number") or row.get("id") or "0"
        rows.append(row)
    return rows


class Alkuds_MAC_Content(Screen):
    def __init__(self, session, portal):
        Screen.__init__(self, session)
        self.portal = portal
        self.skin = _skin("MAC content", account_info=True)
        self["title"] = StaticText(safe_name(portal.get("name"),(portal.get("mac"),),"MAC subscription"))
        self["account_info"] = StaticText("Choose Live TV, Movies or Series")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["list"] = List([("Live TV","live"),("Movies","vod"),("Series","series")],enableWrapAround=True)
        self["actions"] = ActionMap(["OkCancelActions","ColorActions","AlkudsActions"],{
            "cancel":self.close,"red":self.close,"ok":self.open_current,"green":self.open_current,
            "up":lambda:move_cards(self,"moveUp"),"down":lambda:move_cards(self,"moveDown")},-2)

    def open_current(self):
        current = self["list"].getCurrent()
        if not current:
            return
        if current[1] == "live":
            self.session.open(Alkuds_Stalker_Genres,self.portal)
        else:
            self.session.open(Alkuds_MAC_Catalogue,self.portal,current[1])


class Alkuds_MAC_Catalogue(Screen):
    def __init__(self, session, portal, kind, level="categories", parent=None, client=None, inline=None):
        Screen.__init__(self, session)
        self.skin = _skin("MAC library",account_info=True)
        self.portal,self.kind,self.level = portal,kind,level
        self.parent = dict(parent or {})
        self.client = client or StalkerClient(portal)
        self.inline = inline
        self.page,self.pages = 1,1
        self.rows = []
        self.loading,self.closed,self.done = False,False,False
        self.error,self.result = "",None
        self.operation = "load"
        self["title"] = StaticText("Movies" if kind == "vod" else "Series")
        self["account_info"] = StaticText("")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("Next page")
        self["key_blue"] = StaticText("Refresh")
        self["list"] = List([],enableWrapAround=True)
        self["actions"] = ActionMap(["OkCancelActions","ColorActions","AlkudsActions"],{
            "cancel":self.close,"red":self.close,"ok":self.open_current,"green":self.open_current,
            "blue":self.load,"yellow":lambda:self.change_page(1),
            "channelUp":lambda:self.change_page(-1),"channelDown":lambda:self.change_page(1),
            "up":lambda:move_cards(self,"moveUp"),"down":lambda:move_cards(self,"moveDown"),
            "left":lambda:move_cards(self,"pageUp"),"right":lambda:move_cards(self,"pageDown")},-2)
        self.timer = eTimer()
        try:self.timer_conn = self.timer.timeout.connect(self.poll)
        except Exception:self.timer.callback.append(self.poll)
        self.onFirstExecBegin.append(self.load)
        self.onClose.append(self.cleanup)

    def change_page(self, delta):
        if not self.loading and 1 <= self.page + delta <= self.pages:
            self.page += delta
            self.load()

    def load(self):
        self.start("load")

    def start(self, operation, item=None):
        if self.loading or self.closed:return
        self.loading,self.done,self.operation = True,False,operation
        self.error,self.result,self.selected = "",None,dict(item or {})
        self["account_info"].setText("Loading..." if operation == "load" else "Opening selected item...")
        worker=threading.Thread(target=self.worker);worker.daemon=True;worker.start()
        self.timer.start(150,False)

    def worker(self):
        try:
            if self.operation == "load":
                self.result = (self.inline,1) if self.inline is not None else catalogue_page(self.client,self.kind,self.level,self.parent,self.page)
                if self.page == 1 and not self.client.account_info and self.inline is None:
                    self.client.get_account_info()
            else:
                command=self.selected.get("cmd") or self.selected.get("command") or ""
                if not command:raise ValueError("No playback command")
                episode=self.selected.get("_episode") or self.selected.get("series_number") or self.selected.get("episode_id") or "0"
                if episode == "0" and isinstance(self.selected.get("series"), (int, str)):
                    episode=self.selected["series"]
                self.result=self.client.create_link(command,"vod",episode)
        except Exception:
            # Provider exceptions can contain credentials or signed URLs.
            self.error="This section or item could not be opened. Check your subscription and try Refresh."
        finally:self.done=True

    def poll(self):
        if self.closed or not self.done:return
        self.timer.stop();self.loading=False
        if self.error:
            self["account_info"].setText(self.error)
            if not self.rows:self["list"].setList([("Unavailable - BLUE to retry",-1)])
            return
        from .accountinfo import account_text
        self["account_info"].setText(account_text(self.client.account_info))
        if self.operation == "load":
            self.rows,self.pages=self.result
            self["list"].setList([(r.get("name") or r.get("title") or "Item",i) for i,r in enumerate(self.rows)] or [("No content available for this subscription",-1)])
            label="Movies" if self.kind == "vod" else "Series"
            self["title"].setText("%s / %s / Page %d of %d" % (label,self.parent.get("name") or self.parent.get("title") or "Categories",self.page,self.pages))
        else:
            from .freeplayer import Alkuds_FreeTV_Player
            from .receivercompat import selected_free_service_type
            from .freeproviders import service_stream_url
            # Forward only the established playback user-agent, never portal cookies.
            url=service_stream_url(self.result,{"User-Agent":self.client.headers.get("User-Agent","")})
            self.session.open(Alkuds_FreeTV_Player,[url],selected_free_service_type(),self.selected.get("name") or "Video","Movie" if self.kind=="vod" else "Series",self.selected.get("description") or "")

    def open_current(self):
        if self.loading:return
        current=self["list"].getCurrent()
        if not current or current[1]<0 or current[1]>=len(self.rows):return
        item=dict(self.rows[current[1]])
        if self.level == "categories":
            self.session.open(Alkuds_MAC_Catalogue,self.portal,self.kind,"items",item,self.client)
        elif self.kind == "series" and self.level != "episodes":
            inline=episode_rows(item)
            if inline:
                self.session.open(Alkuds_MAC_Catalogue,self.portal,self.kind,"episodes",item,self.client,inline)
            else:
                level="seasons" if self.level=="items" else "episodes"
                item["_movie_id"]=self.parent.get("_movie_id") or (self.parent.get("id") if self.level=="seasons" else item.get("id"))
                self.session.open(Alkuds_MAC_Catalogue,self.portal,self.kind,level,item,self.client)
        else:self.start("play",item)

    def cleanup(self):
        self.closed=True
        self.timer.stop()
