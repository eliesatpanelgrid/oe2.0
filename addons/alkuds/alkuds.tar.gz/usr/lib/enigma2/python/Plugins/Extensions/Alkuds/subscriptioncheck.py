# -*- coding: utf-8 -*-
"""Check only accounts already saved by the user; persist no credentials here."""
import hashlib
import json
import os
import threading
import time
from .accountinfo import account_fields, account_text, _expiry_timestamp

STORE = '/etc/enigma2/alkuds/subscription_status.json'
LOCK = threading.Lock()


def identity(kind, item):
    info = item.get('playlist_info', {}) if kind == 'xtream' else item
    keys = ('host', 'domain', 'username', 'password') if kind == 'xtream' else ('portal', 'mac')
    raw = json.dumps([kind] + [info.get(k, '') for k in keys], ensure_ascii=True)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def read_all():
    try:
        with open(STORE, 'r') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def record(kind, item, status, fields):
    with LOCK:
        data = read_all()
        key = identity(kind, item)
        previous = data.get(key, {}).get('fields', {})
        previous.update(fields or {})
        data[key] = {'status': status, 'fields': previous, 'checked': int(time.time())}
        parent = os.path.dirname(STORE)
        if not os.path.isdir(parent):
            os.makedirs(parent)
        temporary = STORE + '.tmp'
        with open(temporary, 'w') as handle:
            json.dump(data, handle)
        os.chmod(temporary, 0o600)
        getattr(os, 'replace', os.rename)(temporary, STORE)


def xtream_status(payload):
    info = payload.get('user_info') or {}
    status = str(info.get('status', '')).lower()
    expiry = _expiry_timestamp(info.get('exp_date'))
    if status == 'expired' or (expiry and expiry < time.time()):
        return 'Expired'
    if str(info.get('auth')) in ('1', 'True') and status in ('active', ''):
        return 'Active'
    return 'Inactive'


def details(kind, item):
    entry = read_all().get(identity(kind, item), {})
    status = entry.get('status', 'Not checked')
    fields = entry.get('fields') or account_fields(item)
    expiry = _expiry_timestamp(fields.get('expiry'))
    if status == 'Active' and expiry and expiry < time.time():
        status = 'Expired'
    color = 0x0044dd88 if status == 'Active' else 0x00ef8286 if status in ('Expired', 'Inactive') else 0x00d6b879
    return status + ' | ' + account_text(fields), color


def check_one(kind, item):
    if kind == 'xtream':
        from .accountinfo import fetch_xtream_account
        from .plugin import cfg
        from .remote_backup import backup_xtream_connected
        try:
            from urllib.parse import urlencode
        except ImportError:
            from urllib import urlencode
        info = item.get('playlist_info') or {}
        url = info.get('player_api') or (str(info.get('host', '')).rstrip('/') + '/player_api.php?' +
              urlencode({'username': info.get('username', ''), 'password': info.get('password', '')}))
        payload = fetch_xtream_account(url, cfg.useragent.value)
        status, fields = xtream_status(payload), account_fields(payload)
        if status == 'Active':
            backup_xtream_connected(item)
    else:
        from .stalker import StalkerClient
        from .remote_backup import backup_stalker_connected
        client = StalkerClient(item)
        try:
            client.connect()
            genres = client.get_genres()
            fields = client.get_account_info()
            expiry = _expiry_timestamp(fields.get('expiry'))
            status = 'Expired' if expiry and expiry < time.time() else 'Active' if genres else 'Unconfirmed'
            if status == 'Active':
                backup_stalker_connected(item)
        finally:
            client.session.close()
    record(kind, item, status, fields)
    return status


def show_menu(manager, kind, items):
    from Screens.ChoiceBox import ChoiceBox
    def selected(choice):
        if choice:
            manager.session.openWithCallback(manager.reload, SubscriptionCheck, kind, list(items))
    manager.session.openWithCallback(selected, ChoiceBox, title=u'الاشتراكات',
                                    list=[(u'فحص الاشتراكات', 'check')])


from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from enigma import eTimer


class SubscriptionCheck(Screen):
    skin = '<screen position="center,center" size="650,190" title="Subscription check"><widget name="status" position="20,20" size="610,150" font="Regular;24" /></screen>'

    def __init__(self, session, kind, items):
        Screen.__init__(self, session)
        self.kind, self.items = kind, items
        self.cancelled = threading.Event()
        self.done, self.progress = False, (0, 'Starting')
        self['status'] = Label('')
        self['actions'] = ActionMap(['OkCancelActions'], {'cancel': self.close, 'ok': self.finish}, -2)
        self.timer = eTimer()
        try:
            self.connection = self.timer.timeout.connect(self.poll)
        except Exception:
            self.timer.callback.append(self.poll)
        self.onClose.append(self.cleanup)
        self.onFirstExecBegin.append(self.start)

    def start(self):
        worker = threading.Thread(target=self.run)
        worker.daemon = True
        worker.start()
        self.timer.start(150, False)

    def run(self):
        for index, item in enumerate(self.items):
            if self.cancelled.is_set():
                break
            self.progress = (index, 'Checking account %d' % (index + 1))
            try:
                status = check_one(self.kind, item)
            except Exception:
                status = 'Check failed'
                try:
                    record(self.kind, item, status, {})
                except Exception:
                    status = 'Could not save result'
            self.progress = (index + 1, status)
        self.done = True

    def poll(self):
        count, status = self.progress
        self['status'].setText('%d / %d\n%s\n%s' % (count, len(self.items), status,
            'Finished - OK to return' if self.done else 'BACK to stop after current account'))
        if self.done:
            self.timer.stop()

    def finish(self):
        if self.done:
            self.close()

    def cleanup(self):
        self.cancelled.set()
        self.timer.stop()
