# -*- coding: utf-8 -*-
"""Local, credential-free subscription cards. No account requests."""
import os
import re
from datetime import datetime
try:
    from urllib.parse import urlsplit
except ImportError:
    from urlparse import urlsplit


def safe_host(value):
    try:
        text = str(value or "").strip()
        host = urlsplit(text if "://" in text else "//" + text).hostname or ""
        return host
    except Exception:
        return ""


def safe_name(value, secrets=(), fallback="Subscription"):
    text = str(value or "").strip()
    if not text or any(str(s) and str(s).lower() in text.lower() for s in secrets if s):
        return fallback
    if any(token in text.lower() for token in ("://", "@", "password=", "username=", "get.php")):
        return fallback
    return text[:64]


def cached_details(playlist):
    info = playlist.get("user_info") or {}
    status = str(info.get("status") or "Not checked")
    expiry = info.get("exp_date")
    try:
        expires = datetime.fromtimestamp(int(expiry)).strftime("%Y-%m-%d") if expiry else "Unknown"
    except (ValueError, TypeError, OverflowError, OSError):
        expires = "Unknown"
    return "Saved status: %s   |   Expires: %s" % (status, expires)


def card_row(name, index, subtitle="", details="", kind="xtream", color=0x00acb9cc):
    from Tools.LoadPixmap import LoadPixmap
    from enigma import getDesktop
    target = max(1, int(64 * getDesktop(0).size().width() / 1280.0))
    size = max([n for n in (36, 64, 96, 192) if n <= target] or [36])
    icon = LoadPixmap(path=os.path.join(os.path.dirname(__file__), "icons", "card-%s-%d.png" % (kind, size)), cached=True)
    return (name, index, subtitle, details, icon, color)


def subscription_card(playlist, index):
    info = playlist.get("playlist_info") or {}
    secrets = (info.get("username"), info.get("password"))
    name = safe_name(info.get("name"), secrets, "Xtream %02d" % (index + 1))
    host = safe_host(info.get("host") or info.get("domain"))
    host = safe_name(host, secrets, "Server")
    from .subscriptioncheck import details
    description, color = details('xtream', playlist)
    return card_row(name, index, "XTREAM   |   " + host, description, color=color)


def portal_card(portal, index):
    secret = portal.get("mac") or ""
    name = safe_name(portal.get("name"), (secret,), "Portal %02d" % (index + 1))
    from .subscriptioncheck import details
    description, color = details('mac', portal)
    return card_row(name, index, "MAC PORTAL   |   " + safe_host(portal.get("portal")),
                    description, "mac", color)


def cards_skin(caption="ALKUDS  /  SUBSCRIPTIONS"):
    from enigma import getDesktop
    size = getDesktop(0).size()
    w, h = size.width(), size.height()
    scale = w / 1280.0
    def n(value):
        return max(1, int(value * scale))
    m, top, footer = n(48), n(125), h - n(68)
    cw, rowh = w - 2 * m, n(108)
    body = ('{"template":['
        'MultiContentEntryPixmapAlphaTest(pos=(%d,%d),size=(%d,%d),png=4),'
        'MultiContentEntryText(pos=(%d,%d),size=(%d,%d),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=0),'
        'MultiContentEntryText(pos=(%d,%d),size=(%d,%d),font=1,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=2,color=0x009ddbd7),'
        'MultiContentEntryText(pos=(%d,%d),size=(%d,%d),font=1,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=3,color=0xff000005,color_sel=0xff000005)'
        '],"fonts":[gFont("Regular",%d),gFont("Regular",%d)],"itemHeight":%d}' %
        (n(18),n(22),n(64),n(64), n(102),n(8),cw-n(130),n(32),
         n(102),n(42),cw-n(130),n(25),n(102),n(71),cw-n(130),n(25),n(25),n(18),rowh))
    xml = '<screen name="AlkudsCards" position="0,0" size="%d,%d" backgroundColor="#0b1220" flags="wfNoBorder">' % (w,h)
    xml += '<eLabel position="%d,%d" size="%d,%d" backgroundColor="#44c9bb" />' % (m,n(34),n(5),n(43))
    xml += '<widget source="title" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#0b1220" />' % (m+n(20),n(30),cw-n(20),n(43),n(29))
    xml += '<eLabel text="%s" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#d6b879" backgroundColor="#0b1220" />' % (caption,m+n(20),n(79),cw,n(25),n(16))
    xml += '<widget source="list" render="Listbox" position="%d,%d" size="%d,%d" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" backgroundColor="#121f32" backgroundColorSelected="#23495a" scrollbarMode="showOnDemand" enableWrapAround="1"><convert type="TemplatedMultiContent">%s</convert></widget>' % (m,top,cw,max(rowh,footer-top-n(20)),body)
    for i,(key,color) in enumerate((("red","ef8286"),("green","44c9bb"),("yellow","d6b879"),("blue","80adf5"))):
        xml += '<widget source="key_%s" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#%s" backgroundColor="#0b1220" valign="center" />' % (key,m+i*cw//4,footer,cw//4,n(45),n(20),color)
    return xml + '</screen>'


def move_cards(screen, movement):
    try:
        instance = screen["list"].master.master.instance
        instance.moveSelection(getattr(instance, movement))
    except (AttributeError, TypeError):
        pass
