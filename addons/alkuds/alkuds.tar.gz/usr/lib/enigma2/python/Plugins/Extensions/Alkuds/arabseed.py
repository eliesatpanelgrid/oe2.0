# -*- coding: utf-8 -*-
"""ArabSeed catalogue and public watch-page resolver (Python 2/3)."""
import binascii
import re
import requests
try:
    from html.parser import HTMLParser
    from urllib.parse import urljoin, urlparse
except ImportError:
    from HTMLParser import HTMLParser
    from urlparse import urljoin, urlparse

BASE = 'https://arabseed.college/'
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36')
SECTIONS = [
    ('browse', u'تصفح الموقع', 'home/'),
    ('trend', u'الأكثر مشاهدة', 'trend/'),
    ('recently', u'أضيف حديثاً', 'recently/'),
    ('foreign_movies', u'أفلام أجنبية', u'category/افلام-اجنبي/'),
    ('turkish_movies', u'أفلام تركية', u'category/افلام-تركية/'),
    ('indian_movies', u'أفلام هندية', u'category/افلام-هندي/'),
    ('anime_movies', u'أفلام أنمي', u'category/افلام-انمي/'),
    ('anime_series', u'مسلسلات أنمي', u'category/مسلسلات-انمي/'),
    ('foreign_series', u'مسلسلات أجنبية', u'category/مسلسلات-اجنبي/'),
    ('turkish_series', u'مسلسلات تركية', u'category/مسلسلات-تركية/'),
    ('indian_series', u'مسلسلات هندية', u'category/مسلسلات-هندية/'),
    ('arabic_series', u'مسلسلات عربية', u'category/مسلسلات-عربي/'),
]
SECTION_MAP = dict((key, (name, path)) for key, name, path in SECTIONS)


class Node(object):
    def __init__(self, tag='', attrs=None, parent=None):
        self.tag, self.attrs, self.parent = tag, dict(attrs or []), parent
        self.children, self.parts = [], []

    def find(self, tag=None, css=None):
        result = []
        for child in self.children:
            if ((tag is None or child.tag == tag) and
                    (css is None or css in child.attrs.get('class', '').split())):
                result.append(child)
            result.extend(child.find(tag, css))
        return result

    def text(self):
        value = ''.join(p.text() if isinstance(p, Node) else p for p in self.parts)
        return re.sub(r'\s+', ' ', value).strip()


class Document(HTMLParser):
    def __init__(self, value):
        HTMLParser.__init__(self)
        self.root = Node()
        self.current = self.root
        self.feed(value)
        self.close()

    def handle_starttag(self, tag, attrs):
        child = Node(tag, attrs, self.current)
        self.current.children.append(child)
        self.current.parts.append(child)
        if tag not in ('area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
                       'link', 'meta', 'param', 'source', 'track', 'wbr'):
            self.current = child

    def handle_startendtag(self, tag, attrs):
        child = Node(tag, attrs, self.current)
        self.current.children.append(child)
        self.current.parts.append(child)

    def handle_endtag(self, tag):
        node = self.current
        while node.parent is not None:
            if node.tag == tag:
                self.current = node.parent
                return
            node = node.parent

    def handle_data(self, value):
        self.current.parts.append(value)

    def handle_entityref(self, name):
        try:
            self.handle_data(self.unescape('&%s;' % name))
        except AttributeError:
            from html import unescape
            self.handle_data(unescape('&%s;' % name))

    def handle_charref(self, name):
        self.handle_entityref('#' + name)


def _local(url):
    value = urljoin(BASE, url)
    parsed = urlparse(value)
    if parsed.scheme not in ('http', 'https') or parsed.hostname not in (
            'arabseed.college', 'www.arabseed.college'):
        raise ValueError('Unexpected ArabSeed catalogue address')
    return value


def groups():
    return [{'name': name, 'section': key, 'url': _local(path)}
            for key, name, path in SECTIONS]


def _referer(url):
    return requests.utils.requote_uri((url or BASE).split('#', 1)[0])


def _headers(referer=BASE, local=False):
    headers = {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'ar,en-US;q=0.9,en;q=0.8',
        'Cache-Control': 'no-cache', 'Pragma': 'no-cache',
        'Referer': _referer(referer), 'Upgrade-Insecure-Requests': '1',
    }
    if local:
        headers.update({'Sec-Fetch-Dest': 'document', 'Sec-Fetch-Mode': 'navigate',
                        'Sec-Fetch-Site': 'same-origin'})
    return headers


def _new_session():
    session, response = requests.Session(), None
    try:
        response = session.get(BASE, headers=_headers(BASE, True), timeout=(8, 25))
        response.raise_for_status()
        if 'cf-chl-' in response.text and 'movie__block' not in response.text:
            raise RuntimeError('ArabSeed requires browser verification. Try again later.')
        return session
    except Exception:
        session.close()
        raise
    finally:
        if response is not None:
            response.close()


def _get(session, url, referer=BASE, local=False):
    response = session.get(requests.utils.requote_uri(url), headers=_headers(referer, local),
                           timeout=(8, 35), allow_redirects=True)
    try:
        response.raise_for_status()
        if len(response.content) > 5 * 1024 * 1024:
            raise RuntimeError('ArabSeed page is too large')
        value = response.content.decode('utf-8', 'replace')
        if 'cf-chl-' in value and '<iframe' not in value and 'movie__block' not in value:
            raise RuntimeError('ArabSeed requires browser verification. Try again later.')
        return value, response.url
    finally:
        response.close()


def _image(node):
    images = node.find('img')
    return urljoin(BASE, images[0].attrs.get('data-src') or images[0].attrs.get('src') or '') if images else ''


def _first_text(node, css):
    values = node.find(css=css)
    return values[0].text() if values else ''


def _page_url(url, page):
    page = max(1, int(page or 1))
    if page == 1:
        return url
    parsed = urlparse(url)
    result = '%s://%s%s/page/%d/' % (parsed.scheme, parsed.netloc, parsed.path.rstrip('/'), page)
    return result + (('?' + parsed.query) if parsed.query else '')


def fetch_items(section, page=1):
    if section not in SECTION_MAP:
        raise ValueError('Unknown ArabSeed section')
    name, path = SECTION_MAP[section]
    url = _page_url(_local(path), page)
    session = _new_session()
    try:
        html, page_url = _get(session, url, BASE, True)
    finally:
        session.close()
    root = Document(html).root
    entries, seen = [], set()
    for block in root.find('a', 'movie__block'):
        try:
            item_url = _local(block.attrs.get('href', ''))
        except Exception:
            continue
        if item_url in seen:
            continue
        title = block.attrs.get('title') or _first_text(block, 'post__title') or _first_text(block, 'movie__title')
        if not title:
            headings = block.find('h3') + block.find('h2')
            title = headings[0].text() if headings else block.text()
        title = re.sub(r'\s+', ' ', title or '').strip()
        if not title:
            continue
        seen.add(item_url)
        entries.append({'id': item_url, 'url': item_url, 'name': title,
                        'image': _image(block), 'category': _first_text(block, 'post__category'),
                        'quality': _first_text(block, '__quality') or _first_text(block, 'quality'),
                        'description': _first_text(block, 'post__info'), 'section': section})
    pages = [int(page)]
    for link in root.find('a'):
        match = re.search(r'/page/(\d+)/', link.attrs.get('href', ''))
        if match:
            pages.append(int(match.group(1)))
    return {'entries': entries, 'page': int(page), 'last_page': max(pages),
            'total': len(entries), 'name': name, 'url': page_url}


def _decode_hex(value):
    try:
        raw = binascii.unhexlify(value)
        return raw.decode('utf-8', 'replace') if not isinstance(raw, str) else raw
    except Exception:
        return ''


def _media_type(url):
    path = urlparse(url).path.lower()
    return 'hls' if '.m3u8' in path else ('mp4' if '.mp4' in path else '')


def _resolve_page(session, url, referer, depth=0, visited=None):
    if depth > 4:
        return []
    visited = visited if visited is not None else set()
    url = urljoin(referer, url)
    if url in visited:
        return []
    visited.add(url)
    if _media_type(url):
        return [{'url': url, 'referer': referer, 'mediatype': _media_type(url)}]
    html, final_url = _get(session, url, referer, False)
    found = []
    for value in re.findall(r'\bMohix\s*=\s*["\']([0-9a-fA-F]+)["\']', html, re.I):
        decoded = _decode_hex(value).strip()
        if decoded.startswith(('http://', 'https://')) and _media_type(decoded):
            found.append({'url': decoded, 'referer': final_url, 'mediatype': _media_type(decoded)})
    patterns = [
        r'(?:file|source|src)\s*[:=]\s*["\'](https?[^"\']+\.(?:m3u8|mp4)(?:\?[^"\']*)?)["\']',
        r'["\'](https?[^"\']+\.(?:m3u8|mp4)(?:\?[^"\']*)?)["\']',
    ]
    for pattern in patterns:
        for media_url in re.findall(pattern, html, re.I):
            media_url = media_url.replace('\\/', '/')
            found.append({'url': media_url, 'referer': final_url, 'mediatype': _media_type(media_url)})
    if not found:
        root = Document(html).root
        for iframe in root.find('iframe'):
            source = iframe.attrs.get('src') or iframe.attrs.get('data-src') or ''
            if source:
                try:
                    found.extend(_resolve_page(session, source, final_url, depth + 1, visited))
                except Exception:
                    continue
    result, keys = [], set()
    for stream in found:
        if stream.get('url') and stream['url'] not in keys:
            result.append(stream)
            keys.add(stream['url'])
    return result


def resolve(item):
    session = _new_session()
    try:
        detail_html, detail_url = _get(session, _local(item['url']), BASE, True)
        detail = Document(detail_html).root
        watch_url = ''
        for link in detail.find('a'):
            href = link.attrs.get('href', '')
            if ('watch__btn' in link.attrs.get('class', '').split() or
                    urlparse(href).path.rstrip('/').endswith('/watch')):
                watch_url = _local(href)
                break
        if not watch_url:
            watch_url = _local(item['url'].rstrip('/') + '/watch/')
        watch_html, watch_final = _get(session, watch_url, detail_url, True)
        watch = Document(watch_html).root
        servers = []
        for node in watch.find('li'):
            link = node.attrs.get('data-link') or node.attrs.get('data-url')
            if link:
                servers.append((node.text() or u'مشغل', urljoin(watch_final, link)))
        if not servers:
            for frame in watch.find('iframe'):
                link = frame.attrs.get('src') or frame.attrs.get('data-src')
                if link:
                    servers.append((u'المشغل الرئيسي', urljoin(watch_final, link)))
        streams, seen = [], set()
        for label, server_url in servers:
            try:
                resolved = _resolve_page(session, server_url, watch_final)
            except Exception:
                continue
            for index, stream in enumerate(resolved):
                if stream['url'] in seen:
                    continue
                seen.add(stream['url'])
                stream_name = label if len(resolved) == 1 else u'%s - %d' % (label, index + 1)
                streams.append({'url': stream['url'], 'name': stream_name, 'quality': stream_name,
                                'relay': True, 'mediatype': stream['mediatype'],
                                'headers': {'User-Agent': UA, 'Referer': _referer(stream['referer'])}})
        if not streams:
            raise RuntimeError('ArabSeed did not return a playable video link')
        result = dict(item)
        result['streams'] = streams
        return result
    finally:
        session.close()
