# -*- coding: utf-8 -*-
"""Curated online full-screen Palestine slideshow for Arabic Radio."""
from __future__ import unicode_literals
import hashlib
import math
import os
import random
import threading
import time

import requests
from Components.Pixmap import Pixmap
from enigma import ePicLoad, eTimer, ePoint, eSize, getDesktop


CACHE_DIR = '/tmp/alkuds-radio-backgrounds'
CACHE_LIMIT = 6
CHANGE_SECONDS = 12

# Fixed, visually reviewed Wikimedia Commons files: places only, with no people
# and no political scenes. The photographs stay online and are never packaged.
IMAGE_POOL = (
('Jerusalem-2013-Temple Mount-Dome of the Rock-Detail 01.jpg', 5000, 3460),
    ('Jerusalem Architecture-2 (3556640242).jpg', 2560, 1920),
    ('Jerusalem Architecture-2 (4922961188).jpg', 4000, 3000),
    ('Jerusalem Architecture (3555829537).jpg', 2560, 1920),
    ('Neoclassical Architecture - Jerusalem - Israel (5681333594).jpg', 3456, 2304),
    ('PikiWiki 35937 Architecture of Jerusalem.jpg', 3872, 2592),
    ('Jerusalem panorama early twentieth century2.jpg', 6355, 2329),
    ('Jerusalem panorama from Mount of Olives 07112018.jpg', 11512, 3163),
    ('Panorama Jerozolimy.jpg', 3008, 1152),
    ('Panorama Jerusalem Tempelberg.jpg', 4387, 1274),
    ('Al-Aqsa Mosque (Temple Mount, Jerusalem, 2008).jpg', 4213, 2802),
    ('Al-Aqsa Mosque Summer Pulpit (Minbar al-Sayf) on the Temple Mount (Jerusalem, 2008).jpg', 3279, 2579),
    ('Al-Qibli Chapel 20140816-IMG 0159.jpg', 5616, 3744),
    ('Dome of the Al-Aqsa Mosque (20160).jpg', 4433, 2783),
    ('Jerusalem-2007-Temple Mount-Al-Aqsa Mosque 01.jpg', 4288, 2848),
    ('Jerusalem-2013(2)-Temple Mount-Al-Aqsa Mosque (east exposure).jpg', 6500, 2086),
    ('Jerusalem-2013-Temple Mount-Al-Aqsa Mosque (NE exposure).jpg', 8000, 4299),
    ('View From Mount Of Olives (146394805).jpeg', 2048, 1357),
    ('138722 tel aviv beit shekim on jerusalem boulevard PikiWiki Israel.jpg', 3000, 2824),
    ('138724 tel aviv beit shekim on jerusalem boulevard PikiWiki Israel.jpg', 2842, 2442),
    ('ISR-2013-Aerial-Jaffa-Port of Jaffa.jpg', 7850, 4415),
    ('Jaffa Port Hangars.jpg', 5710, 2710),
    ('OLD JAFFA PORT.jpg', 4761, 3280),
    ('PikiWiki Israel 55621 jaffa port postcards.jpg', 3140, 2036),
    ('Port of Jaffa from the south.jpg', 4624, 3472),
    ('האנגרים נמל יפו - Jaffa Port Hangars.jpg', 4358, 3268),
    ('150410 haifa - engineers house PikiWiki Israel.jpg', 3001, 2001),
    ('90140 haifa - the lower city PikiWiki Israel.jpg', 1600, 731),
    ('90176 haifa - the court PikiWiki Israel.jpg', 1600, 1031),
    ('Haifa (467234).jpg', 6119, 1670),
    ('PikiWiki Israel 33792 Architecture of Israel.JPG', 2000, 1332),
    ('PikiWiki Israel 70329 haifa downtown.jpg', 4272, 3904),
    ('PikiWiki Israel 76666 haifa sailing tower.jpg', 5472, 3648),
    ('Technion – Israel Institute of Technology41.jpg', 4000, 3000),
    ('Haifa (997008136903405171).jpg', 1330, 1289),
    ('Haifa (997008137264405171.jpg', 1873, 1322),
    ('Haifa (997008137264705171.jpg', 1889, 1338),
    ('Haifa (997008137265505171.jpg', 1914, 1346),
    ('Haifa landscape city public domain 26.jpg', 3696, 2448),
    ('Haifa landscape panorama harbour city public domain 27.jpg', 3696, 2448),
    ('Bahai Garden in Haifa Israel.jpg', 5341, 3108),
    ('Bahai gardens, Haifa, Israel.JPG', 2816, 2112),
    ('Bahai gardens 2, Haifa, Israel.JPG', 2816, 2112),
    ('Haifa Bahai Garden.JPG', 4320, 2880),
    ('ISRAEL, Haifa, Gradinile Bahai (2).JPG', 3648, 2736),
    ('ISRAEL, Haifa, Gradinile Bahai (vedere spre Marea Mediterana).JPG', 3648, 2736),
    ('ISRAEL - Haifa - Bahai Gardens (3).JPG', 3648, 2736),
    ('Tiberias-S-790.jpg', 2592, 1695),
    ('123754 the view of mount hermon from kfar vradim PikiWiki Israel.jpg', 2151, 829),
    ('126403 mount hermon - golan heights PikiWiki Israel.jpg', 4000, 1800),
    ('127396 kfar vradim - view of mount hermon PikiWiki Israel.jpg', 4032, 3024),
    ('127397 kfar vradim - view of mount hermon PikiWiki Israel.jpg', 4032, 3024),
    ('127398 kfar vradim - view of mount hermon PikiWiki Israel.jpg', 4032, 3024),
    ('Mount Hermon (997008136639805171).jpg', 1881, 1330),
    ('Mount Hermon Qalaat al-Jandal snow landscape.jpg', 5120, 3840),
    ('Jericho-5959-hisham-palace.jpg', 2592, 1944),
    ('Jericho-5960-hisham-palace.jpg', 2592, 1944),
    ('Jericho-5961-hisham-palace.jpg', 2592, 1944),
    ('Jericho-5964-hisham-palace.jpg', 2592, 1944),
    ('Jericho-5965-hisham-palace.jpg', 2592, 1944),
    ('Jericho-5966-hisham-palace.jpg', 2592, 1944),
    ('Jericho-5968-hisham-palace.jpg', 2592, 1944),
    ('Jericho-5982-hisham-palace.jpg', 2592, 1944),
    ('Auditorium Roundabout, Acre (7 April,2015).MIV.jpg', 4608, 3456),
    ('Auditorium Roundabout, Acre (7 April,2015).MV.jpg', 4608, 3456),
    ('COLOR PHOTO OF SCENERY TAKEN IN THE LATE 19TH CENTURY BY FRENCH PHOTOGRAPHER, BONFILS. THE VILLAGE SHOWN IS SEBASTIA, NABLUS.jpg', 2748, 2037),
    ('The fish harbour colors at the end of the day (50080131752).jpg', 5064, 3468),
    ('Old-City Architecture - Tsfat (Safed) - Galilee - Israel - 01 (5713408785).jpg', 3456, 2304),
    ('Old-City Architecture - Tsfat (Safed) - Galilee - Israel - 03 (5713997600).jpg', 3456, 2304),
    ('Old-City Architecture - Tsfat (Safed) - Galilee - Israel - 05 (5714074362).jpg', 3456, 2304),
    ('Beit-Shean-Khan-al-Ahmar-81.jpg', 1941, 1482),
    ('Beit-Shean-Khan-al-Ahmar-84.jpg', 2020, 1256),
    ('Beit-Shean-Khan-al-Ahmar-85.jpg', 2214, 1551),
    ('Beit-Shean-Khan-al-Ahmar-86.jpg', 2592, 1944),
    ('Beit-Shean-Khan-al-Ahmar-87.jpg', 2592, 1944),
    ('Beit-Shean-Khan-al-Ahmar-89.jpg', 2592, 1944),
    ('Beit-Shean-Khan-al-Ahmar-91.jpg', 2592, 1944),
    ('Beit-Shean-Khan-al-Ahmar-92.jpg', 2371, 1944),
    ('Panorama of ruins by Sebastia 04.jpg', 2989, 2175),
    ('Ruins by Sebastia 02.jpg', 3437, 2189),
    ('Ruins by Sebastia 26.jpg', 2048, 1536),
    ('Sebastia-410.jpg', 2592, 1944),
    ('2012دير مارسابا.jpg', 4288, 2848),
    ('Aerial view of Mar Saba 01.jpg', 3721, 2471),
    ('Aerial view of Mar Saba 02.jpg', 4288, 2848),
    ('Aerial view of Mar Saba 03.jpg', 3572, 2324),
    ('Palestine, Mar Saba Greek Orthodox Monastery (1).jpg', 3648, 2736),
    ('Palestine, Mar Saba Greek Orthodox Monastery (8).jpg', 3648, 2736),
    ('PikiWiki Israel 19530 Mar Saba Monastery.jpg', 4000, 3000),
    ('Nabi Musa, 24.jpg', 4000, 2248),
    ('Nabi Musa - panoramio.jpg', 3776, 2520),
    ('Malha, Jerusalem 1934.jpg', 2000, 1159),
    ('Ein Samia aqueduct.jpg', 4000, 3000),
    ('Tiberiade, Panorama Lae Palestine -363 LACMA M.2008.40.259.jpg', 2100, 1620),
    ('20211122 Landscape at the Dead Sea, Ein Bokek, Israel anagoria.jpg', 9000, 6750),
    ('Bethany, Jericho, Dead Sea, and Jordan. Dead Sea shore. (Castle-like erosion formations) LOC matpc.21992.jpg', 4620, 3486),
    ('Dead Sea 1426 (509724585).jpg', 3264, 2448),
    ('Dead Sea by Mujaddara - panoramio (2919).jpg', 3648, 2432),
    ('Dead Sea by Mujaddara - panoramio (2927).jpg', 3416, 2277),
    ('Dead Sea by Mujaddara - panoramio (2929).jpg', 3648, 2736),
    ('Dead Sea by Mujaddara - panoramio (2933).jpg', 3648, 2736),
    ('Just before sunset in the eastern Mediterranean (14961950399).jpg', 2500, 766),
)


def _get(url, **kwargs):
    try:
        return requests.get(url, **kwargs)
    except requests.exceptions.SSLError:
        kwargs['verify'] = False
        return requests.get(url, **kwargs)


def _image_url(title):
    filename = title.replace(' ', '_').encode('utf-8')
    digest = hashlib.md5(filename).hexdigest()
    encoded = requests.utils.quote(filename, safe='')
    return ('https://thumb.wikimedia.org/wikipedia/commons/thumb/' + digest[0] + '/' +
            digest[:2] + '/' + encoded + '/1280px-' + encoded)


def cover_geometry(width, height, image_width, image_height):
    scale = max(float(width) / image_width, float(height) / image_height)
    w, h = int(math.ceil(image_width * scale)), int(math.ceil(image_height * scale))
    return (width - w) // 2, (height - h) // 2, w, h


class RadioBackground(object):
    def __init__(self, screen):
        self.screen = screen
        self.closed = self.busy = self.downloading = False
        self.pending = None
        self.current_path = None
        self.images = list(IMAGE_POOL)
        random.shuffle(self.images)
        self.image_index = 0
        self.next_change = 0
        screen['radio_background'] = Pixmap()
        self.timer = eTimer()
        self.decoder = ePicLoad()
        self.connections = []
        try:
            self.connections.append(self.timer.timeout.connect(self.tick))
        except Exception:
            self.timer.callback.append(self.tick)
        try:
            self.connections.append(self.decoder.PictureData.connect(self.decoded))
        except Exception:
            self.decoder.PictureData.get().append(self.decoded)
        screen.onLayoutFinish.append(self.start)
        screen.onClose.append(self.cleanup)

    def start(self):
        if self.closed:
            return
        try:
            if not os.path.isdir(CACHE_DIR):
                os.makedirs(CACHE_DIR)
        except Exception:
            pass
        self.timer.start(500, False)
        self._launch_download()

    def tick(self):
        if self.closed:
            return
        pending, self.pending = self.pending, None
        if pending and not self.busy:
            self._show(pending)
        if not self.busy and not self.downloading and time.time() >= self.next_change:
            self._launch_download()

    def _launch_download(self):
        if self.closed or self.downloading:
            return
        self.downloading = True
        worker = threading.Thread(target=self._download_worker)
        worker.daemon = True
        worker.start()

    def _download_worker(self):
        result = None
        temporary = None
        try:
            title, width, height = self.images[self.image_index]
            self.image_index = (self.image_index + 1) % len(self.images)
            url = _image_url(title)
            response = _get(url, headers={'User-Agent': 'Alkuds-Enigma2/1.98'},
                            timeout=18, stream=True)
            response.raise_for_status()
            content_type = response.headers.get('Content-Type', '').lower()
            if 'image/' not in content_type:
                raise ValueError('not an image')
            extension = '.png' if 'png' in content_type else '.jpg'
            name = hashlib.sha1(url.encode('utf-8')).hexdigest() + extension
            path = os.path.join(CACHE_DIR, name)
            temporary = path + '.part'
            total = 0
            with open(temporary, 'wb') as output:
                for chunk in response.iter_content(65536):
                    if not chunk:
                        continue
                    total += len(chunk)
                    if total > 7 * 1024 * 1024:
                        raise ValueError('image is too large')
                    output.write(chunk)
            if total < 8192:
                raise ValueError('image is too small')
            try:
                os.rename(temporary, path)
            except Exception:
                if os.path.exists(path):
                    os.remove(path)
                os.rename(temporary, path)
            result = {'path': path, 'width': width, 'height': height}
            self._trim_cache(path)
        except Exception:
            if temporary:
                try:
                    os.remove(temporary)
                except Exception:
                    pass
        self.pending = result
        self.downloading = False
        if result is None:
            self.next_change = time.time() + 5

    def _trim_cache(self, newest):
        try:
            files = [os.path.join(CACHE_DIR, name) for name in os.listdir(CACHE_DIR)
                     if name.endswith(('.jpg', '.png'))]
            files.sort(key=lambda path: os.path.getmtime(path), reverse=True)
            keep = set(path for path in (newest, self.current_path) if path)
            for path in files:
                if len(keep) >= CACHE_LIMIT:
                    break
                keep.add(path)
            for path in files:
                if path not in keep:
                    os.remove(path)
        except Exception:
            pass

    def _show(self, item):
        size = getDesktop(0).size()
        self.geometry = cover_geometry(size.width(), size.height(), item['width'], item['height'])
        unused_x, unused_y, width, height = self.geometry
        self.decoder.setPara((width, height, 1, 1, False, 1, '#00000000'))
        self.busy = True
        self.current_path = item['path']
        try:
            result = self.decoder.startDecode(item['path'])
            if result not in (None, 0):
                self.busy = False
                self.next_change = time.time() + 3
        except Exception:
            self.busy = False
            self.next_change = time.time() + 3

    def decoded(self, *args):
        self.busy = False
        if self.closed or getattr(self.screen, '_closed', False):
            return
        pointer = self.decoder.getData()
        widget = self.screen['radio_background'].instance
        if pointer is not None and widget is not None:
            x, y, width, height = self.geometry
            widget.move(ePoint(x, y))
            widget.resize(eSize(width, height))
            widget.setPixmap(pointer)
            self.next_change = time.time() + CHANGE_SECONDS

    def cleanup(self):
        if self.closed:
            return
        self.closed = True
        self.timer.stop()
        for connection in self.connections:
            try:
                connection.disconnect()
            except Exception:
                pass
        self.connections = []
        try:
            self.timer.callback.remove(self.tick)
        except Exception:
            pass
        try:
            self.decoder.PictureData.get().remove(self.decoded)
        except Exception:
            pass
