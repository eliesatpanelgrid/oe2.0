# -*- coding: utf-8 -*-
"""Curated online full-screen Palestine slideshow for Arabic Radio."""
from __future__ import unicode_literals
import hashlib
import math
import os
import random
import threading
import time

import requests
from Components.Pixmap import Pixmap
from enigma import ePicLoad, eTimer, ePoint, eSize, getDesktop


CACHE_DIR = '/tmp/alkuds-radio-backgrounds'
CACHE_LIMIT = 10
CHANGE_SECONDS = 8

# Fixed, visually reviewed Wikimedia Commons files: places only, with no people
# and no political scenes. The photographs stay online and are never packaged.
# Only this reviewed set is displayed.  It contains wide landscapes,
# architecture and historic sites without people, flags, slogans or political
# scenes.  Repeated locations intentionally use different old/new viewpoints.
IMAGE_POOL = (
    ('Jerusalem panorama early twentieth century2.jpg', 6355, 2329),
    ('Jerusalem panorama from Mount of Olives 07112018.jpg', 11512, 3163),
    ('Panorama with Dome of the Rock - Temple Mount - Old City - East Jerusalem (5684536532).jpg', 4667, 1080),
    ('Al-Qibli Chapel 20140816-IMG 0159.jpg', 5616, 3744),
    ('Jerusalem-2013-Temple Mount-Al-Aqsa Mosque (NE exposure).jpg', 8000, 4299),
    ('Jerusalem Architecture-2 (3556640242).jpg', 2560, 1920),
    ('Jerusalem Architecture-2 (4922961188).jpg', 4000, 3000),
    ('Panorama Jerozolimy.jpg', 3008, 1152),
    ('Panorama Jerusalem Tempelberg.jpg', 4387, 1274),
    ('ISR-2013-Aerial-Jaffa-Port of Jaffa.jpg', 7850, 4415),
    ('Port of Jaffa from the south.jpg', 4624, 3472),
    ('Jaffa Port Hangars.jpg', 5710, 2710),
    ('Haifa landscape panorama harbour city public domain 27.jpg', 3696, 2448),
    ('Bahai Garden in Haifa Israel.jpg', 5341, 3108),
    ('Mount Hermon Qalaat al-Jandal snow landscape.jpg', 5120, 3840),
    ('Jericho-5959-hisham-palace.jpg', 2592, 1944),
    ('Jericho-5960-hisham-palace.jpg', 2592, 1944),
    ('Jericho-5964-hisham-palace.jpg', 2592, 1944),
    ('Jericho-5968-hisham-palace.jpg', 2592, 1944),
    ('Panorama of ruins by Sebastia 04.jpg', 2989, 2175),
    ('Ruins by Sebastia 02.jpg', 3437, 2189),
    ('Ruins by Sebastia 26.jpg', 2048, 1536),
    ('Aerial view of Mar Saba 01.jpg', 3721, 2471),
    ('Aerial view of Mar Saba 02.jpg', 4288, 2848),
    ('Aerial view of Mar Saba 03.jpg', 3572, 2324),
    ('Ein Samia aqueduct.jpg', 4000, 3000),
    ('Dead Sea by Mujaddara - panoramio (2919).jpg', 3648, 2432),
    ('Dead Sea by Mujaddara - panoramio (2927).jpg', 3416, 2277),
    ('Dead Sea by Mujaddara - panoramio (2929).jpg', 3648, 2736),
    ('Dead Sea by Mujaddara - panoramio (2933).jpg', 3648, 2736),
    ('Wadi Rum 01.jpg', 2078, 1420),
    ('Wadi Rum 03.jpg', 3453, 2100),
    ('Wadi Rum landscape (12465078394).jpg', 3947, 2622),
    ('Wadi Rum landscape (12465264714).jpg', 4288, 2848),
    ('Wadi Rum landscape with smaller hill.jpg', 3664, 2464),
    ('Rocky landscape near Petra, Jordan, wider view.jpg', 3468, 2600),
    ('Rocky landscape near Petra, Jordan.jpg', 3664, 2280),
    ('Amazing view of sky and mountain range in oman.jpg', 4000, 2252),
    ('Contrasting Landscape between the Sharjah sand and the rock Omani Hajar Mountains, 2013.jpg', 5032, 3355),
    ('Landscape view of jabel hatt oman.jpg', 4000, 2252),
    ('Oman east coast (4).jpg', 4368, 2912),
    ('Rub al Khali 002.JPG', 3553, 1987),
    ('Architecture in Medina (Old City) - Rabat - Morocco.jpg', 3456, 2304),
    ('Anraz Ouirgane Atlas Mountains Oct25 A7CR 08751-5 HDR1.jpg', 8756, 5837),
    ('Arhbalou High Atlas Al Haouz Morocco Oct25 A7CR 08381.jpg', 8117, 5073),
    ('Arhbalou Trees High Atlas Al Haouz Morocco Oct25 A7CR 08382.jpg', 9251, 5782),
    ('Djebel Ayachi, Eastern High Atlas, Morocco.jpg', 4614, 3076),
    ('Old Siwa Village.jpg', 4638, 3092),
    ('Siwa Oasis, Aftans Lake.jpg', 6000, 4000),
)


def _get(url, **kwargs):
    try:
        return requests.get(url, **kwargs)
    except requests.exceptions.SSLError:
        kwargs['verify'] = False
        return requests.get(url, **kwargs)


def _image_url(title, source_width=3840):
    filename = title.replace(' ', '_').encode('utf-8')
    digest = hashlib.md5(filename).hexdigest()
    encoded = requests.utils.quote(filename, safe='')
    requested = '3840px-' if int(source_width or 0) >= 3840 else '1280px-'
    return ('https://thumb.wikimedia.org/wikipedia/commons/thumb/' + digest[0] + '/' +
            digest[:2] + '/' + encoded + '/' + requested + encoded)


def cover_geometry(width, height, image_width, image_height):
    scale = max(float(width) / image_width, float(height) / image_height)
    w, h = int(math.ceil(image_width * scale)), int(math.ceil(image_height * scale))
    return (width - w) // 2, (height - h) // 2, w, h


class RadioBackground(object):
    def __init__(self, screen):
        self.screen = screen
        self.closed = self.busy = self.downloading = False
        self.pending = None
        self.current_path = None
        self.images = list(IMAGE_POOL)
        random.shuffle(self.images)
        self.image_index = 0
        self.next_change = 0
        screen['radio_background'] = Pixmap()
        self.timer = eTimer()
        self.decoder = ePicLoad()
        self.connections = []
        try:
            self.connections.append(self.timer.timeout.connect(self.tick))
        except Exception:
            self.timer.callback.append(self.tick)
        try:
            self.connections.append(self.decoder.PictureData.connect(self.decoded))
        except Exception:
            self.decoder.PictureData.get().append(self.decoded)
        screen.onLayoutFinish.append(self.start)
        screen.onClose.append(self.cleanup)

    def start(self):
        if self.closed:
            return
        try:
            if not os.path.isdir(CACHE_DIR):
                os.makedirs(CACHE_DIR)
        except Exception:
            pass
        self.timer.start(500, False)
        self._launch_download()

    def tick(self):
        if self.closed:
            return
        pending, self.pending = self.pending, None
        if pending and not self.busy:
            self._show(pending)
        if not self.busy and not self.downloading and time.time() >= self.next_change:
            self._launch_download()

    def _launch_download(self):
        if self.closed or self.downloading:
            return
        self.downloading = True
        worker = threading.Thread(target=self._download_worker)
        worker.daemon = True
        worker.start()

    def _download_worker(self):
        result = None
        temporary = None
        try:
            title, width, height = self.images[self.image_index]
            self.image_index = (self.image_index + 1) % len(self.images)
            url = _image_url(title, width)
            response = _get(url, headers={'User-Agent': 'Alkuds-Enigma2/1.98'},
                            timeout=18, stream=True)
            response.raise_for_status()
            content_type = response.headers.get('Content-Type', '').lower()
            if 'image/' not in content_type:
                raise ValueError('not an image')
            extension = '.png' if 'png' in content_type else '.jpg'
            name = hashlib.sha1(url.encode('utf-8')).hexdigest() + extension
            path = os.path.join(CACHE_DIR, name)
            temporary = path + '.part'
            total = 0
            with open(temporary, 'wb') as output:
                for chunk in response.iter_content(65536):
                    if not chunk:
                        continue
                    total += len(chunk)
                    if total > 18 * 1024 * 1024:
                        raise ValueError('image is too large')
                    output.write(chunk)
            if total < 8192:
                raise ValueError('image is too small')
            try:
                os.rename(temporary, path)
            except Exception:
                if os.path.exists(path):
                    os.remove(path)
                os.rename(temporary, path)
            result = {'path': path, 'width': width, 'height': height}
            self._trim_cache(path)
        except Exception:
            if temporary:
                try:
                    os.remove(temporary)
                except Exception:
                    pass
        self.pending = result
        self.downloading = False
        if result is None:
            self.next_change = time.time() + 5

    def _trim_cache(self, newest):
        try:
            files = [os.path.join(CACHE_DIR, name) for name in os.listdir(CACHE_DIR)
                     if name.endswith(('.jpg', '.png'))]
            files.sort(key=lambda path: os.path.getmtime(path), reverse=True)
            keep = set(path for path in (newest, self.current_path) if path)
            for path in files:
                if len(keep) >= CACHE_LIMIT:
                    break
                keep.add(path)
            for path in files:
                if path not in keep:
                    os.remove(path)
        except Exception:
            pass

    def _show(self, item):
        size = getDesktop(0).size()
        self.geometry = cover_geometry(size.width(), size.height(), item['width'], item['height'])
        unused_x, unused_y, width, height = self.geometry
        self.decoder.setPara((width, height, 1, 1, False, 1, '#00000000'))
        self.busy = True
        self.current_path = item['path']
        try:
            result = self.decoder.startDecode(item['path'])
            if result not in (None, 0):
                self.busy = False
                self.next_change = time.time() + 3
        except Exception:
            self.busy = False
            self.next_change = time.time() + 3

    def decoded(self, *args):
        self.busy = False
        if self.closed or getattr(self.screen, '_closed', False):
            return
        pointer = self.decoder.getData()
        widget = self.screen['radio_background'].instance
        if pointer is not None and widget is not None:
            x, y, width, height = self.geometry
            widget.move(ePoint(x, y))
            widget.resize(eSize(width, height))
            widget.setPixmap(pointer)
            self.next_change = time.time() + CHANGE_SECONDS

    def cleanup(self):
        if self.closed:
            return
        self.closed = True
        self.timer.stop()
        for connection in self.connections:
            try:
                connection.disconnect()
            except Exception:
                pass
        self.connections = []
        try:
            self.timer.callback.remove(self.tick)
        except Exception:
            pass
        try:
            self.decoder.PictureData.get().remove(self.decoded)
        except Exception:
            pass
