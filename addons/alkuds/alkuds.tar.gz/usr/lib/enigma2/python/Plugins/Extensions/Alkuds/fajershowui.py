# -*- coding: utf-8 -*-
import threading
from . import fajershow
from .freechannels import (Alkuds_Egybest_Browser, Alkuds_QualityChooser,
                           _list_entry, _prepared_stream_urls, _prepared_stream_labels)


class Alkuds_FajerShow_Browser(Alkuds_Egybest_Browser):
    def __init__(self, session, kind='movie', level='groups', parent=None, page=1):
        Alkuds_Egybest_Browser.__init__(self, session, kind, level, parent, page)
        self.level = level
        self['key_green'].setText('Play' if level == 'servers' else 'Open')
        self['key_yellow'].setText('Previous' if level == 'items' else '')
        self['key_blue'].setText('Next' if level == 'items' else 'Refresh')
        self._update_title()

    def _label(self):
        section = u'مسلسلات' if self.kind == 'series' else u'أفلام'
        return u'فجر شو - %s%s' % (section, u' - ' + self.parent.get('name', '') if self.parent else '')

    def load(self):
        if self._loading or self._closed:
            return
        self._operation, self._loading, self._done = 'load', True, False
        self._result, self._error = None, ''
        self['list'].setList([_list_entry(u'جاري تحميل فجر شو...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == 'groups':
                self._result = [{'name': u'أفلام', 'kind': 'movie'}, {'name': u'مسلسلات', 'kind': 'series'}]
            elif self.level == 'sections':
                self._result = [{'name': u'بحث في الأفلام', 'action': 'search'},
                                {'name': u'قائمة السنوات', 'level': 'years'},
                                {'name': u'قائمة الأنواع', 'level': 'genres'},
                                {'name': u'جميع الأفلام', 'level': 'items'}]
            elif self.level in ('genres', 'years'):
                self._result = fajershow.fetch_filters(self.kind, self.level)
                if self.kind == 'series' and self.level == 'genres':
                    self._result.insert(0, {'name': u'بحث في المسلسلات', 'action': 'search'})
            elif self.level == 'items':
                self._result = fajershow.fetch_items(self.kind, self.page, self.parent)
            elif self.level == 'seasons':
                self._result = fajershow.fetch_seasons(self.parent)
            elif self.level == 'episodes':
                self._result = fajershow.fetch_episodes(self.parent)
            else:
                self._result = fajershow.fetch_servers(self.parent)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def open_current(self):
        if self._loading or self._closed:
            return
        index = self._index()
        if not 0 <= index < len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if item.get('action') == 'search':
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            self.session.openWithCallback(
                self._search_done, VirtualKeyBoard,
                title=u'بحث في المسلسلات' if self.kind == 'series' else u'بحث في الأفلام', text='')
            return
        if self.level == 'groups':
            self.session.open(type(self), item['kind'], 'genres' if item['kind'] == 'series' else 'sections')
        elif self.level == 'sections':
            self.session.open(type(self), self.kind, item['level'])
        elif self.level in ('genres', 'years'):
            self.session.open(type(self), self.kind, 'items', item)
        elif self.level == 'items':
            kind = item.get('kind', self.kind)
            self.session.open(type(self), kind, 'seasons' if kind == 'series' else 'servers', item)
        elif self.level == 'seasons':
            self.session.open(type(self), self.kind, 'episodes', item)
        elif self.level != 'servers':
            self.session.open(type(self), self.kind, 'servers', item)
        else:
            self._operation, self._loading, self._done = 'resolve', True, False
            self._result, self._error = None, ''
            self._update_title(u' - جاري تجهيز الفيديو...')
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)

    def _search_done(self, value):
        if self._closed or not value or not value.strip():
            return
        query = value.strip()
        self.session.open(type(self), self.kind, 'items',
                          {'name': u'نتائج البحث: ' + query, 'search_query': query}, 1)

    def _resolve_worker(self, item):
        try:
            self._result = fajershow.resolve_server(item)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _start_resolved(self, item):
        self.session.open(Alkuds_FajerShow_Qualities, {'variants': item['streams']},
                          item['name'], 'Series' if self.kind == 'series' else 'Movie',
                          self.parent.get('name', ''), item.get('image', ''),
                          'fajershow:' + item['url'])


class Alkuds_FajerShow_Qualities(Alkuds_QualityChooser):
    def _load_worker(self):
        if not self._closed:
            self.variants = list(self.stream.get('variants') or [])
            if not self.variants:
                self._error = 'No playable qualities returned by this server'
            self._done = True
