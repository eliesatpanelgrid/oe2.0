# -*- coding: utf-8 -*-
from enigma import getDesktop
from .freestyle import FONT
import xml.etree.ElementTree as ET

def _free_channels_skin():
    size = getDesktop(0).size()
    width, height = size.width(), size.height()
    panel = int(width * .90)
    margin = 24 if width >= 1920 else 16
    top, foot = (110, 76) if height >= 1080 else (82, 60)
    font = 42 if width >= 1920 else 32 if width >= 1280 else 25
    item = 92 if height >= 1080 else 72 if height >= 720 else 58
    row = panel - margin * 2 - 24
    icon_size = 54 if height >= 1080 else 44
    template = '{"template":[MultiContentEntryText(pos=(0,2),size=(%d,%d),font=0,text=7,backcolor=0xff000004,backcolor_sel=0x285F85),MultiContentEntryPixmapAlphaBlend(pos=(14,%d),size=(%d,%d),png=6,flags=1),MultiContentEntryText(pos=(%d,4),size=(%d,%d),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=0,color=0xff000005,color_sel=0xFFFFFF,backcolor=0xff000004,backcolor_sel=0x285F85),MultiContentEntryText(pos=(%d,4),size=(42,%d),font=0,text=2,color=0xff000003,color_sel=0xff000003,flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER)],"fonts":[gFont("%s",%d)],"itemHeight":%d}' % (row,item-4,(item-icon_size)//2,icon_size,icon_size,icon_size+30,row-icon_size-90,item-8,row-46,item-8,FONT,font,item)
    xml = ['<screen name="AlkudsFreeTVList" position="0,0" size="%d,%d" backgroundColor="#ff000000" flags="wfNoBorder">' % (width,height),
           '<eLabel position="0,0" size="%d,%d" backgroundColor="#101B2C" />' % (panel,height),
           '<eLabel position="0,0" size="7,%d" backgroundColor="#D8B56D" zPosition="2" />' % height,
           '<widget source="title" render="Label" position="%d,14" size="%d,%d" font="%s;%d" foregroundColor="#F0D6A0" backgroundColor="#101B2C" valign="center" noWrap="1" zPosition="2" />' % (margin+12,panel-2*margin-24,top-22,FONT,font+6),
           '<widget source="list" render="Listbox" position="%d,%d" size="%d,%d" foregroundColor="#FFFFFF" backgroundColor="#101B2C" backgroundColorSelected="#285F85" scrollbarMode="showOnDemand" enableWrapAround="1" transparent="0" zPosition="2"><convert type="TemplatedMultiContent">%s</convert></widget>' % (margin,top,panel-margin*2,height-top-foot,template)]
    key_w = (panel-margin*2)//4
    for index, (key, color) in enumerate([('red','#FF9292'),('green','#8DE3BA'),('yellow','#F0D6A0'),('blue','#91CFFC')]):
        xml.append('<widget source="key_%s" render="Label" position="%d,%d" size="%d,%d" font="%s;%d" foregroundColor="%s" backgroundColor="#101B2C" valign="center" halign="center" zPosition="2" />' % (key,margin+index*key_w,height-foot,key_w,foot,FONT,max(22,font-9),color))
    return ''.join(xml) + '</screen>'

def subscription_list_skin(account_info=False):
    xml = _free_channels_skin()
    if not account_info:
        return xml
    screen = ET.fromstring(xml)
    listing = next(widget for widget in screen.findall('widget') if widget.get('source') == 'list')
    x, y = [int(v) for v in listing.get('position').split(',')]
    width, height = [int(v) for v in listing.get('size').split(',')]
    info_height = 70 if getDesktop(0).size().height() >= 1080 else 56
    listing.set('position', '%d,%d' % (x, y + info_height))
    listing.set('size', '%d,%d' % (width, height - info_height))
    ET.SubElement(screen, 'widget', {
        'source': 'account_info', 'render': 'Label', 'position': '%d,%d' % (x + 12, y),
        'size': '%d,%d' % (width - 24, info_height), 'font': '%s;%d' % (FONT, 24 if info_height == 70 else 20),
        'foregroundColor': '#F0D6A0', 'backgroundColor': '#101B2C', 'zPosition': '2'})
    return ET.tostring(screen, encoding='unicode')
