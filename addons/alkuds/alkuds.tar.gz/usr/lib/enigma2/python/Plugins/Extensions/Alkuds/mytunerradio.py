# -*- coding: utf-8 -*-
"""Arabic-country radio catalogue statically derived from the supplied myTuner APK."""
from __future__ import unicode_literals

import gzip
import json
import os


_CATALOGUE = None
_PAGE_SIZE = 120


def _load():
    global _CATALOGUE
    if _CATALOGUE is None:
        path = os.path.join(os.path.dirname(__file__), 'mytuner_arabic.json.gz')
        with gzip.open(path, 'rb') as source:
            _CATALOGUE = json.loads(source.read().decode('utf-8'))
    return _CATALOGUE


def groups():
    data = _load()
    rows = [{"name": u"القرآن الكريم", "source": "mytuner", "code": "quran",
             "count": len(data.get("quran") or [])}]
    for country in data.get("countries") or []:
        rows.append({"name": country.get("name") or country.get("code"),
                     "source": "mytuner", "code": country.get("code"),
                     "count": len(country.get("stations") or [])})
    return rows


def _station_rows(parent):
    data = _load()
    code = str((parent or {}).get("code") or "")
    if code == "quran":
        stations = list(data.get("quran") or [])
    else:
        country = next((row for row in data.get("countries") or []
                        if row.get("code") == code), None)
        stations = list((country or {}).get("stations") or [])
    rows = []
    for station in stations:
        streams = []
        for index, source in enumerate(station.get("streams") or []):
            url = str(source.get("url") or "").strip()
            if not url:
                continue
            quality = int(source.get("quality") or 0)
            label = (u"%d kbps" % quality) if quality else (u"مصدر %d" % (index + 1))
            streams.append({"url": url, "name": label, "quality": label,
                            "mediatype": "hls" if ".m3u8" in url.lower() else "audio",
                            "relay": False, "headers": {}})
        if not streams:
            continue
        description = str((parent or {}).get("name") or "")
        country = station.get("country")
        if country:
            description = str(country)
        rows.append({"id": station.get("id"), "name": station.get("name") or u"إذاعة",
                     "image": station.get("image") or "", "description": description,
                     "streams": streams, "url": streams[0]["url"], "urls": [x["url"] for x in streams],
                     "headers": {}, "is_live": True, "source": "mytuner"})
    return rows


def items(parent, page=1):
    rows = _station_rows(parent)
    page = max(1, int(page or 1))
    total = len(rows)
    last_page = max(1, (total + _PAGE_SIZE - 1) // _PAGE_SIZE)
    if page > last_page:
        page = last_page
    start = (page - 1) * _PAGE_SIZE
    return {"entries": rows[start:start + _PAGE_SIZE], "page": page,
            "last_page": last_page, "total": total}
