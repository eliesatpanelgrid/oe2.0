#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Small public-page adapter for the LiveHD match list and HTML5 players."""

from __future__ import print_function

import base64
import re

import requests

try:
    from html import unescape
    from urllib.parse import urljoin, urlparse
except ImportError:
    from HTMLParser import HTMLParser
    from urlparse import urljoin, urlparse
    unescape = HTMLParser().unescape


LIVEHD_HOME = "https://livehd.pro/"
MAX_HTML = 2 * 1024 * 1024
MAX_SERVERS = 16
MAX_PLAYER_DEPTH = 5


def _clean(value):
    value = re.sub(r"<[^>]+>", " ", str(value or ""))
    return " ".join(unescape(value).split())


def _get_html(url, user_agent, referer=""):
    parsed = urlparse(str(url or ""))
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise RuntimeError("Invalid LiveHD page address")
    headers = {"User-Agent": str(user_agent or "Mozilla/5.0")}
    if referer:
        headers["Referer"] = str(referer)
    with requests.get(url, headers=headers, timeout=(7, 22), stream=True) as response:
        response.raise_for_status()
        chunks, total = [], 0
        for chunk in response.iter_content(16384):
            total += len(chunk)
            if total > MAX_HTML:
                raise RuntimeError("LiveHD page is too large")
            chunks.append(chunk)
        html = b"".join(chunks).decode("utf-8", "replace")
        # Some nested players wrap their complete HTML in
        # document.write("\x3c...").  Expanding the hex escapes makes the
        # ordinary iframe/media parser work without running site JavaScript.
        for _unused in range(2):
            expanded = re.sub(
                r"\\x([0-9a-fA-F]{2})",
                lambda match: chr(int(match.group(1), 16)), html)
            if expanded == html:
                break
            html = expanded
        return html, str(response.url)


def _match_chunks(html):
    starts = [match.start() for match in re.finditer(
        r'<div\s+class="[^"]*\bkora-match-card\b', html, re.I)]
    starts.append(len(html))
    return [html[starts[index]:starts[index + 1]]
            for index in range(len(starts) - 1)]


def fetch_livehd_matches(user_agent):
    html, final_url = _get_html(LIVEHD_HOME, user_agent)
    entries, seen = [], set()
    for chunk in _match_chunks(html):
        link = re.search(r'<a\s+class="[^"]*\bkora-card-main\b[^"]*"\s+href="([^"]+)"',
                         chunk, re.I)
        teams = re.findall(r'<img[^>]+alt="([^"]+)"[^>]*class="[^"]*\blazy-load\b',
                           chunk, re.I)
        if not link or len(teams) < 2:
            continue
        page_url = urljoin(final_url, unescape(link.group(1)))
        if page_url in seen:
            continue
        seen.add(page_url)

        def field(class_name, default=""):
            match = re.search(r'<[^>]+class="[^"]*\b%s\b[^"]*"[^>]*>(.*?)</[^>]+>' %
                              re.escape(class_name), chunk, re.I | re.S)
            return _clean(match.group(1)) if match else default

        home, away = _clean(teams[0]), _clean(teams[1])
        status = field("match-status", u"غير معروف")
        score = field("match-score", "vs")
        if status in (u"لم تبدأ بعد", u"بعد قليل") and score in ("0:0", "0 - 0"):
            score = "vs"
        league = field("match-league")
        channel = field("match-channel")
        kickoff = field("match-time")
        entries.append({
            "id": page_url,
            "name": u"%s  %s  %s" % (home, score, away),
            "home": home,
            "away": away,
            "score": score,
            "status": status,
            "time": kickoff,
            "channel": channel,
            "league": league,
            "description": u"%s | %s | %s" % (kickoff, status, channel or league),
            "url": page_url,
            "source": "livehd",
        })
    if not entries:
        raise RuntimeError("LiveHD returned no matches")
    return {"entries": entries, "page": 1, "last_page": 1, "total": len(entries)}


def _server_pages(html, page_url):
    return [(u"السيرفر الرئيسي", url) for url in _iframe_urls(html, page_url)[:1]]


def _embedded_servers(html, embedded_url):
    rows = []
    for href, label in re.findall(
            r'<a\s+class="[^"]*\baplr-link\b[^"]*"\s+href="([^"]+)"[^>]*>(.*?)</a>',
            html, re.I | re.S):
        url = urljoin(embedded_url, unescape(href))
        name = _clean(label) or u"سيرفر %d" % (len(rows) + 1)
        if url not in [row[1] for row in rows]:
            rows.append((name, url))
    # AlbaPlayer's bare URL is normally the same player as ?serv=1.  Adding
    # it as a synthetic row duplicated the first real server and shifted the
    # visible server count, so only the site's own server buttons belong here.
    if not rows:
        rows.append((u"السيرفر الرئيسي", embedded_url))
    return rows[:MAX_SERVERS]


def _media_urls(html, page_url):
    found = []
    # AlbaPlayer's native PLYR mode stores the real URL as base64 in this
    # function call.  It is the visible "main stream" on the web page and is
    # not represented by an iframe.
    for encoded in re.findall(
            r'AlbaPlayerControl\(\s*["\']([A-Za-z0-9+/=_-]+)["\']\s*,\s*["\']plyr["\']',
            html, re.I):
        try:
            padded = encoded + ("=" * ((4 - len(encoded) % 4) % 4))
            value = base64.b64decode(padded).decode("utf-8", "replace")
            url = urljoin(page_url, unescape(value).replace("\\/", "/"))
            if urlparse(url).scheme in ("http", "https") and url not in found:
                found.append(url)
        except Exception:
            pass
    patterns = (
        r'<(?:video|source)\b[^>]*\bsrc="([^"]+)"',
        r"<(?:video|source)\b[^>]*\bsrc='([^']+)'",
        r'\bsource\s*:\s*"([^"]+)"',
        r"\bsource\s*:\s*'([^']+)'",
        r'\b(?:url|videoUrl|streamUrl)\s*=\s*"(https?://[^"<>\s]+(?:proxy\.php\?stream=)[^"<>\s]+)"',
        r"\b(?:url|videoUrl|streamUrl)\s*=\s*'(https?://[^'<>\s]+(?:proxy\.php\?stream=)[^'<>\s]+)'",
        r'["\'](https?://[^"\'<>\s]+\.m3u8(?:\?[^"\'<>\s]*)?)["\']',
    )
    for pattern in patterns:
        for value in re.findall(pattern, html, re.I):
            url = urljoin(page_url, unescape(value).replace("\\/", "/"))
            if urlparse(url).scheme in ("http", "https") and url not in found:
                found.append(url)
    return found


def _is_hls_media(url):
    value = str(url or "").lower()
    path = urlparse(value).path
    return (".m3u8" in path or "proxy.php?stream=" in value or
            ("/live/" in path and path.endswith((".css", ".txt"))))


def _iframe_urls(html, page_url):
    # Embed-code textareas contain examples, not active players. Following
    # these silently selected another server and repeatedly fetched old pages.
    html = re.sub(r'<(textarea|noscript)\b[^>]*>.*?</\1\s*>|<!--.*?-->', '', html, flags=re.I | re.S)
    found = []
    patterns = (
        r'<iframe\b[^>]*\bsrc="([^"]+)"',
        r"<iframe\b[^>]*\bsrc='([^']+)'",
    )
    for pattern in patterns:
        for value in re.findall(pattern, html, re.I):
            url = urljoin(page_url, unescape(value).replace("\\/", "/"))
            parsed = urlparse(url)
            if parsed.scheme in ("http", "https") and url not in found:
                found.append(url)
    return found


def fetch_livehd_servers(item, user_agent):
    """Return every server button advertised by the selected match."""
    match_url = str((item or {}).get("url") or "")
    source_home = "https://www.livekora.vip/" if (item or {}).get("source") == "livekora" else LIVEHD_HOME
    match_html, match_final = _get_html(match_url, user_agent, source_home)
    roots = _server_pages(match_html, match_final)
    if not roots:
        raise RuntimeError("No LiveHD player is available for this match")
    embedded_html, embedded_final = _get_html(roots[0][1], user_agent, match_final)
    servers = _embedded_servers(embedded_html, embedded_final)
    if not servers:
        raise RuntimeError("No LiveHD servers are listed for this match")
    result = dict(item or {})
    result["streams"] = [{
        "name": name,
        "server": name,
        "url": url,
        "page_url": url,
        "headers": {
            "User-Agent": str(user_agent or "Mozilla/5.0"),
            "Referer": embedded_final,
        },
        "mediatype": "resolver",
        "source": "livehd_server",
    } for name, url in servers]
    result["urls"] = [server["url"] for server in result["streams"]]
    result["url"] = result["urls"][0]
    result["is_live"] = True
    return result


def fetch_combined_match_servers(item, user_agent):
    """Collect every server from every provider attached to one fixture."""
    sources = list((item or {}).get("sources") or [item])
    streams, errors = [], []
    for source in sources:
        try:
            resolved = fetch_livehd_servers(source, user_agent)
            provider = source.get("provider_label") or (
                "LiveKora" if source.get("source") == "livekora" else "LiveHD")
            for raw in resolved.get("streams") or []:
                stream = dict(raw)
                stream["provider"] = provider
                stream["name"] = u"%s | %s" % (provider, stream.get("name") or u"سيرفر")
                streams.append(stream)
        except Exception as error:
            errors.append(str(error))
    if not streams:
        raise RuntimeError(errors[0] if errors else "No match servers are available")
    result = dict(item or {})
    result["streams"] = streams
    result["urls"] = [stream.get("url") for stream in streams]
    result["url"] = result["urls"][0]
    result["is_live"] = True
    return result


def _resolve_player_page(page_url, user_agent, referer, depth, visited):
    if depth > MAX_PLAYER_DEPTH or page_url in visited:
        return []
    visited.add(page_url)
    html, final_url = _get_html(page_url, user_agent, referer)
    media = _media_urls(html, final_url)
    if media:
        return [(url, final_url) for url in media]
    resolved = []
    for iframe_url in _iframe_urls(html, final_url):
        host = (urlparse(iframe_url).netloc or "").lower()
        # YouTube embed pages need YouTube's signed playback resolver, which
        # Enigma2 does not provide here. Keep their named server in the menu,
        # but fail it cleanly instead of attempting to play an HTML document.
        if host.endswith("youtube.com") or host.endswith("youtu.be"):
            continue
        try:
            resolved.extend(_resolve_player_page(
                iframe_url, user_agent, final_url, depth + 1, visited))
        except Exception:
            continue
    return resolved


def resolve_livehd_server(server, user_agent):
    """Resolve one selected server through nested player/iframe pages."""
    server = dict(server or {})
    page_url = str(server.get("page_url") or server.get("url") or "")
    referer = str((server.get("headers") or {}).get("Referer") or LIVEHD_HOME)
    media = _resolve_player_page(page_url, user_agent, referer, 0, set())
    if not media:
        raise RuntimeError("This LiveHD server did not expose a playable stream")
    streams = []
    for index, (media_url, media_referer) in enumerate(media):
        stream = {
            "name": server.get("name") or u"سيرفر",
            "server": server.get("server") or server.get("name") or u"سيرفر",
            "url": media_url,
            "headers": {
                "User-Agent": str(user_agent or "Mozilla/5.0"),
                "Referer": media_referer,
            },
            "mediatype": "hls" if _is_hls_media(media_url) else "direct",
            "relay": _is_hls_media(media_url),
            "relay_options": {"live": True, "livehd": True},
            "source": "livehd",
        }
        if len(media) > 1:
            stream["quality"] = u"خيار %d" % (index + 1)
        streams.append(stream)
    result = dict(streams[0])
    result["streams"] = streams
    result["variants"] = streams
    return result


def resolve_livehd_match(item, user_agent):
    # Compatibility name retained for existing callers.  Resolution now
    # happens only after the viewer chooses a server, so every advertised
    # server remains visible even when two buttons share the same media URL.
    return fetch_livehd_servers(item, user_agent)
