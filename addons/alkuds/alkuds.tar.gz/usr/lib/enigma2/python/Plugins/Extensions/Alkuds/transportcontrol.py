# -*- coding: utf-8 -*-
"""Debounced Enigma2 playback controls; no network or disk work on keypress."""
import time
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ProgressBar import ProgressBar
from Screens.Screen import Screen
from enigma import eTimer, getDesktop
from .freestyle import FONT
from .streammonitor import AlkudsStreamInfoBar, _stream_info_skin

STEPS = {0: 10, 1: 30, 2: 60, 3: 120}
clock = getattr(time, 'monotonic', time.time)


def position_value(result):
    if result and len(result) > 1 and result[0] == 0:
        return max(0, int(result[1]))
    return None


def seek_target(position, duration, delta):
    target = max(0, position + int(delta) * 90000)
    if duration:
        target = min(target, max(0, duration - 90000))
    return target


class TransportBar(AlkudsStreamInfoBar):
    def __init__(self, session):
        # Keep the original R91 Xtream information bar dimensions, placement
        # and transparency.  The only added visual element is a four-pixel
        # playback cursor between the programme/time row and stream metrics.
        size = getDesktop(0).size()
        width = int(size.width())
        scale = max(0.75, float(width) / 1280.0)
        seek = ("<widget name='seekprogress' position='%d,%d' size='%d,%d' "
                "foregroundColor='#FFD166' backgroundColor='#273444' />" %
                (int(30 * scale), int(78 * scale), int(1210 * scale),
                 max(2, int(3 * scale))))
        self.skin = _stream_info_skin().replace('</screen>', seek + '</screen>')
        AlkudsStreamInfoBar.__init__(self, session)
        self.onShow.remove(self._shown)
        self._visible = True
        self['seekprogress'] = ProgressBar()
        # Reuse the R91 widgets so all information stays within its original
        # compact footprint: event becomes transport state, and event_time
        # becomes elapsed/total/remaining time.
        self['title'] = self['channel']
        self['status'] = self['event']
        self['position'] = self['event_time']
        self['progress'] = self['seekprogress']
        self['hint'] = Label(u'0: 10 ثوانٍ   |   1: 30 ثانية   |   2: دقيقة   |   3: دقيقتان   |   ◀ ▶')


class TransportControl(object):
    def __init__(self, screen, live=False):
        self.screen, self.live = screen, live
        self.closed = False
        self.step, self.pending, self.armed = 10, 0, False
        self.paused = False
        self.last_pause = -100.0
        self.last_key = -100.0
        self.until = 0
        self.service_ref = None
        self.watch_ref = None
        self.started_at = clock()
        self.preview = None
        self.preview_until = 0
        self.bar = None
        self.connections = []
        self.seek_timer = self._timer(self.flush)
        self.bar_timer = self._timer(self.tick)
        actions = {'left': lambda: self.queue(-1), 'right': lambda: self.queue(1),
                   'pause': self.toggle_pause, 'playpause': self.toggle_pause,
                   'play': lambda: self.set_pause(False), 'info': self.toggle_bar, 'seekBack': lambda: self.queue(-1),
                   'seekFwd': lambda: self.queue(1)}
        for number in STEPS:
            actions[str(number)] = lambda number=number: self.select_step(number)
        if live:
            actions = {key: value for key, value in actions.items() if key in ('play', 'pause', 'playpause', 'info')}
        # The dedicated key context uses make events only: holding an arrow
        # cannot flood service.seekRelative with repeat events.
        screen['transport_actions'] = ActionMap(['AlkudsTransportActions'], actions, -30)
        screen.onClose.append(self.cleanup)
        screen.onHide.append(self.suspend)
        screen.onShow.append(self.present)
        screen.onFirstExecBegin.append(self.present)

    def _timer(self, callback):
        timer = eTimer()
        try:
            self.connections.append(timer.timeout.connect(callback))
        except Exception:
            timer.callback.append(callback)
        return timer

    def valid(self):
        return not self.closed and not getattr(self.screen, '_closed', False)

    def reference(self):
        try:
            ref = self.screen.session.nav.getCurrentlyPlayingServiceReference()
            return ref.toString() if ref else None
        except Exception:
            return None

    def select_step(self, number):
        if not self.valid():
            return
        self.step = STEPS[number]
        self.message(u'القفزة: %d ثانية   ◀ ▶' % self.step)

    def queue(self, direction):
        if not self.valid():
            return
        if self.live:
            self.message(u'التقديم والتأخير متاحان للفيديو المسجّل')
            return
        now = clock()
        if now - self.last_key < .08:
            return
        self.last_key = now
        reference = self.reference()
        if self.armed and reference != self.service_ref:
            self.reset()
        self.service_ref = reference
        self.pending = max(-1200, min(1200, self.pending + direction * self.step))
        self.message(u'%+d ثانية' % self.pending)
        if not self.armed:
            self.armed = True
            self.seek_timer.start(400, True)

    def flush(self):
        self.armed = False
        delta, self.pending = self.pending, 0
        if not self.valid() or not delta or self.reference() != self.service_ref:
            return
        try:
            service = self.screen.session.nav.getCurrentService()
            seek = service.seek() if service else None
            if not seek or not seek.isCurrentlySeekable():
                raise RuntimeError('not seekable')
            position = position_value(seek.getPlayPosition())
            duration = position_value(seek.getLength())
            if position is not None:
                self.preview = seek_target(position, duration, delta)
                self.preview_until = clock() + 2
                result = seek.seekTo(self.preview)
            else:
                result = seek.seekRelative(1 if delta > 0 else -1, abs(delta) * 90000)
            if result not in (None, 0):
                raise RuntimeError('seek failed')
            self.message(u'%+d ثانية | القفزة %d ثانية' % (delta, self.step))
        except Exception:
            self.preview = None
            self.message(u'هذا المصدر أو المشغّل لا يدعم التقديم والتأخير')

    def toggle_pause(self):
        self.set_pause(not self.paused)

    def suspend(self):
        self.seek_timer.stop()
        self.pending, self.armed = 0, False
        self.bar_timer.stop()
        if self.bar:
            self.bar._visible = False
            self.bar.hide()

    def set_pause(self, pause):
        if not self.valid() or clock() - self.last_pause < .45:
            return
        self.last_pause = clock()
        try:
            service = self.screen.session.nav.getCurrentService()
            interface = service.pause() if service else None
            if not interface:
                raise RuntimeError('pause unsupported')
            result = interface.pause() if pause else interface.unpause()
            if result not in (None, 0):
                raise RuntimeError('pause failed')
            self.paused = pause
            # Keep native InfoBarSeek state aligned where that mixin exists.
            if hasattr(self.screen, 'seekstate'):
                state = getattr(self.screen, 'SEEK_STATE_PAUSE' if pause else 'SEEK_STATE_PLAY', None)
                if state is not None:
                    self.screen.seekstate = state
            self.message(u'إيقاف مؤقت' if pause else u'تشغيل')
        except Exception:
            self.message(u'هذا المصدر أو المشغّل لا يدعم الإيقاف المؤقت')

    def message(self, text):
        if not self.valid():
            return
        try:
            if self.bar is None:
                self.bar = self.screen.session.instantiateDialog(TransportBar)
            self.bar['status'].setText(text)
            self.until = clock() + 4
            self.bar._visible = True
            self.bar.show()
            self.tick()
            self.bar_timer.start(1000, False)
        except Exception:
            pass

    def present(self):
        if self.valid():
            self.message(u'بث مباشر' if self.live else u'تشغيل')

    def toggle_bar(self):
        if self.bar and getattr(self.bar, 'shown', False):
            self.suspend()
        else:
            self.present()

    def tick(self):
        if not self.valid() or not self.bar:
            self.bar_timer.stop()
            return
        try:
            ref = self.reference()
            if ref != self.watch_ref:
                self.watch_ref = ref
                self.started_at = clock()
                self.preview = None
                self.bar._traffic.reset()
                self.bar._flow_history = []
            name = getattr(self.screen, 'name', '') or getattr(self.screen, 'channel_name', '')
            try:
                reference = self.screen.session.nav.getCurrentlyPlayingServiceReference()
                if not name and reference:
                    name = reference.getName()
            except Exception:
                pass
            if hasattr(self.screen, '_current'):
                current = self.screen._current()
                if current:
                    name = current[0]
            self.bar['title'].setText(name or (u'القدس | بث مباشر' if self.live else u'القدس | سينما'))
            try:
                self.bar.service_type = int((ref or '').split(':', 1)[0])
            except (ValueError, TypeError):
                self.bar.service_type = getattr(self.screen, 'service_type', getattr(self.screen, 'servicetype', 4097))
            self.bar._update()
            self.bar['total_rate'].setText(u'شبكة الرسيفر | ' + self.bar['total_rate'].getText())
            service = self.screen.session.nav.getCurrentService()
            seek = service.seek() if service else None
            position = position_value(seek.getPlayPosition()) if seek else None
            duration = position_value(seek.getLength()) if seek else None
            def stamp(value):
                seconds = (value or 0) // 90000
                return '%02d:%02d:%02d' % (seconds // 3600, seconds // 60 % 60, seconds % 60)
            if self.live:
                elapsed = int(max(0, clock() - self.started_at)) * 90000
                self.bar['position'].setText(u'مدة المشاهدة  %s    |    مباشر' % stamp(elapsed))
                self.bar['progress'].setValue(0)
                self.bar['hint'].setText(u'بث مباشر  •  لا توجد مدة إجمالية أو وقت متبقٍ')
            else:
                shown_position = position
                if self.pending and position is not None:
                    shown_position = seek_target(position, duration, self.pending)
                elif self.preview is not None and clock() < self.preview_until:
                    shown_position = self.preview
                if duration:
                    remaining = max(0, duration - (shown_position or 0))
                    self.bar['position'].setText(u'مضى  %s     |     المدة  %s     |     المتبقي  %s' % (stamp(shown_position),stamp(duration),stamp(remaining)))
                else:
                    self.bar['position'].setText(u'مضى  %s     |     المدة والمتبقي غير متاحين من المصدر' % stamp(shown_position))
                self.bar['progress'].setValue(min(100, int(100 * (shown_position or 0) // duration)) if duration else 0)
            if clock() >= self.until:
                self.bar['status'].setText(u'إيقاف مؤقت' if self.paused else u'مباشر' if self.live else u'تشغيل  |  القفزة %d ثانية' % self.step)
        except Exception:
            self.bar['position'].setText(u'جاري قراءة وقت التشغيل...')

    def reset(self):
        self.seek_timer.stop()
        self.pending, self.armed, self.paused = 0, False, False
        self.service_ref = None
        self.preview = None

    def cleanup(self):
        if self.closed:
            return
        self.closed = True
        self.reset()
        self.bar_timer.stop()
        for timer, callback in ((self.seek_timer, self.flush), (self.bar_timer, self.tick)):
            try:
                timer.callback.remove(callback)
            except (AttributeError, ValueError):
                pass
        self.screen['transport_actions'].setEnabled(False)
        if self.suspend in self.screen.onHide:
            self.screen.onHide.remove(self.suspend)
        for callbacks in (self.screen.onShow, self.screen.onFirstExecBegin):
            if self.present in callbacks:
                callbacks.remove(self.present)
        if self.bar:
            self.bar.stop()
            try:
                self.screen.session.deleteDialog(self.bar)
            except Exception:
                pass
            self.bar = None
        self.connections = []


def install(screen, live=False):
    if not hasattr(screen, '_transport_control'):
        screen._transport_control = TransportControl(screen, live)
