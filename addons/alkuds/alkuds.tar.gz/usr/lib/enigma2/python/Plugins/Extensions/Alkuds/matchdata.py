# -*- coding: utf-8 -*-
"""Public Syria Live fixture markup; no stream or account handling."""
import re
from datetime import datetime, timedelta
try:
    from html.parser import HTMLParser
except ImportError:
    from HTMLParser import HTMLParser


def kickoff(value):
    match = re.match(r"^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})(?::\d{2})?(Z|[+-]\d{2}:?\d{2})$", value or "")
    if not match:
        return "Date/time unavailable"
    try:
        date, clock, offset = match.groups()
        dt = datetime.strptime(date + " " + clock, "%Y-%m-%d %H:%M")
        minutes = 0 if offset == "Z" else (int(offset[1:3]) * 60 + int(offset[-2:])) * (1 if offset[0] == "+" else -1)
        return (dt + timedelta(minutes=180-minutes)).strftime("%Y-%m-%d  |  %H:%M") + "  Riyadh (UTC+3)"
    except ValueError:
        return "Date/time unavailable"


class FixtureParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.rows = []
        self.row = None
        self.stack = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = attrs.get("class", "").split()
        if self.row is None:
            if "mc" not in classes or not attrs.get("id", "").startswith("m-"):
                return
            self.row = {"id": attrs["id"], "start": attrs.get("data-start", ""),
                        "status": attrs.get("data-status-initial", "unknown"), "names": [], "scores": [], "meta": []}
        if tag in ("img", "br", "hr", "input", "meta", "link", "source", "wbr", "area", "embed", "param"):
            return
        field = "names" if "mt-name" in classes else "scores" if "ms-score" in classes else "meta" if "break-words" in classes else None
        self.stack.append([tag, field, []])

    def handle_data(self, data):
        for tag, field, pieces in self.stack:
            if field:
                pieces.append(data)

    def handle_endtag(self, tag):
        if self.row is None:
            return
        if not any(node[0] == tag for node in self.stack):
            return
        while self.stack:
            node = self.stack.pop()
            if node[1]:
                text = " ".join("".join(node[2]).split())
                if text:
                    self.row[node[1]].append(text)
            if node[0] == tag:
                break
        if not self.stack:
            if len(self.row["names"]) == 2:
                self.rows.append(self.row)
            self.row = None


def parse_fixtures(html):
    parser = FixtureParser()
    parser.feed(html)
    seen, result = set(), []
    for row in parser.rows:
        if row["id"] in seen:
            continue
        seen.add(row["id"])
        row["when"] = kickoff(row["start"])
        row["score"] = " - ".join(row["scores"]) if len(row["scores"]) == 2 else "vs"
        row["label"] = {"live": u"مباشر", "not_started": u"لم تبدأ", "finished": u"انتهت", "ended": u"انتهت", "postponed": u"مؤجلة", "cancelled": u"ملغاة"}.get(row["status"], row["status"] or "Unknown")
        result.append(row)
    return result
