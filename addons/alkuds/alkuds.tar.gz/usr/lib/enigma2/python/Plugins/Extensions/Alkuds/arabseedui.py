# -*- coding: utf-8 -*-
import threading
from . import arabseed
from .freechannels import Alkuds_Egybest_Browser, _list_entry
from .fajershowui import Alkuds_FajerShow_Qualities


class Alkuds_ArabSeed_Browser(Alkuds_Egybest_Browser):
    def __init__(self, session, section='browse', level='groups', parent=None, page=1):
        self.section = section
        Alkuds_Egybest_Browser.__init__(self, session, 'movie', level, parent, page)
        self.level = level
        self['key_green'].setText(u'فتح')
        self['key_yellow'].setText(u'السابق' if level == 'items' else '')
        self['key_blue'].setText(u'التالي' if level == 'items' else u'تحديث')
        self._update_title()

    def _label(self):
        name = arabseed.SECTION_MAP.get(self.section, (u'تصفح الموقع', ''))[0]
        return u'عرب سيد ArabSeed' + (u' - ' + name if self.level != 'groups' else '')

    def load(self):
        if self._loading or self._closed:
            return
        self._operation, self._loading, self._done = 'load', True, False
        self._result, self._error = None, ''
        self['list'].setList([_list_entry(u'جاري تحميل عرب سيد...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            self._result = arabseed.groups() if self.level == 'groups' else arabseed.fetch_items(self.section, self.page)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _set_rows(self):
        rows = []
        for index, item in enumerate(self.entries):
            name = item.get('name') or u'عنصر'
            if self.level == 'items':
                details = u' | '.join(x for x in (item.get('quality'), item.get('category')) if x)
                if details:
                    name += u'   |   ' + details
            rows.append(_list_entry(u'%03d   %s' % (index + 1, name), index))
        self['list'].setList(rows or [_list_entry(u'لا توجد عناصر متاحة حالياً.', -1)])

    def open_current(self):
        if self._loading or self._closed:
            return
        index = self._index()
        if not 0 <= index < len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if self.level == 'groups':
            self.session.open(type(self), item['section'], 'items', item, 1)
            return
        self._operation, self._loading, self._done = 'resolve', True, False
        self._result, self._error = None, ''
        self._update_title(u' - جاري تجهيز الفيديو...')
        worker = threading.Thread(target=self._resolve_worker, args=(item,))
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _resolve_worker(self, item):
        try:
            self._result = arabseed.resolve(item)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _start_resolved(self, item):
        category = 'Series' if self.section.endswith('_series') else 'Movie'
        self.session.open(Alkuds_FajerShow_Qualities, {'variants': item['streams']},
                          item['name'], category, item.get('category', ''),
                          item.get('image', ''), 'arabseed:' + item['url'])
