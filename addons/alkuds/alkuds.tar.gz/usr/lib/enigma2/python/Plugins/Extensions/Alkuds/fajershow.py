# -*- coding: utf-8 -*-
"""Fajer Show public catalogue and direct video sources (Python 2/3)."""
import json
import re
try:
    from html import unescape
    from urllib.parse import urljoin, urlparse, parse_qs, urlencode
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError
except ImportError:
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape
    from urlparse import urljoin, urlparse, parse_qs
    from urllib import urlencode
    from urllib2 import Request, urlopen
    from urllib2 import HTTPError, URLError

BASE = 'https://fajer.show/'
UA = 'Mozilla/5.0'
try:
    string_types = (basestring,)
except NameError:
    string_types = (str, bytes)


def _fetch(url, data=None, referer=None):
    headers = {'User-Agent': UA, 'Referer': referer or BASE}
    if data is not None:
        data = urlencode(data).encode('utf-8')
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
    response = urlopen(Request(url, data=data, headers=headers), timeout=20)
    try:
        return response.read(4 * 1024 * 1024).decode('utf-8', 'replace')
    finally:
        response.close()


def _attr(tag, name):
    match = re.search(r'\b' + re.escape(name) + r'\s*=\s*([\'"])(.*?)\1', tag, re.I | re.S)
    return unescape(match.group(2)) if match else ''


def _text(value):
    return re.sub(r'\s+', ' ', unescape(re.sub(r'<[^>]*>', '', value))).strip()


def _local(url):
    parsed = urlparse(urljoin(BASE, unescape(url)))
    if parsed.hostname not in ('fajer.show', 'show.alfajertv.com'):
        raise ValueError('Unexpected catalogue host')
    return urljoin(BASE, parsed.path) + (('?' + parsed.query) if parsed.query else '')


def parse_cards(text, card_class):
    entries, seen = [], set()
    for tag, body in re.findall(r'(<a\b[^>]*>)(.*?)</a>', text, re.I | re.S):
        if card_class not in _attr(tag, 'class').split():
            continue
        url = _local(_attr(tag, 'href'))
        if url in seen:
            continue
        heading = re.search(r'<h[1-6]\b[^>]*>(.*?)</h[1-6]>', body, re.I | re.S)
        img = re.search(r'<img\b[^>]*>', body, re.I)
        name = _text(heading.group(1)) if heading else _attr(img.group(0), 'alt') if img else _text(body)
        if name:
            entries.append({'id': url, 'url': url, 'name': name,
                            'kind': 'series' if '/tvshows/' in url else 'movie' if '/movies/' in url else 'episode',
                            'image': _attr(img.group(0), 'src') if img else ''})
            seen.add(url)
    return entries


def fetch_filters(kind, filter_type='genres'):
    path = 'tvshows/' if kind == 'series' else 'movies/'
    text = _fetch(urljoin(BASE, path))
    marker = '/release/' if filter_type == 'years' else '/genre/'
    for body in re.findall(r'<select\b[^>]*>(.*?)</select>', text, re.I | re.S):
        if marker not in body:
            continue
        result, seen = [], set()
        for tag, title in re.findall(r'(<option\b[^>]*>)(.*?)</option>', body, re.I | re.S):
            url = _local(_attr(tag, 'value'))
            name = _text(title)
            if kind == 'series' and ('-movies/' in url or u'أفلام' in name):
                continue
            if kind == 'movie' and (u'مسلسلات' in name or '/ramadan' in url):
                continue
            if url not in seen:
                result.append({'name': name, 'catalogue_url': url})
                seen.add(url)
        return result
    raise RuntimeError('The site did not return the requested filters')


def fetch_items(kind, page=1, parent=None):
    parent = parent or {}
    path = 'tvshows/' if kind == 'series' else 'movies/'
    base = _local(parent.get('catalogue_url') or urljoin(BASE, path))
    query = parent.get('search_query')
    if query:
        base = BASE
    parsed = urlparse(base)
    path = re.sub(r'/page/\d+/?$', '/', parsed.path).rstrip('/') + '/'
    url = urljoin(BASE, path + ('page/%d/' % page if page > 1 else ''))
    params = parse_qs(parsed.query)
    params['post_type'] = ['tvshows' if kind == 'series' else 'movies']
    if query:
        params['s'] = [query.encode('utf-8')]
    url += '?' + urlencode(params, doseq=True)
    text = _fetch(url)
    pages = [int(n) for n in re.findall(re.escape(path) + r'page/(\d+)/', text)]
    entries = [item for item in parse_cards(text, 'item-card') if item['kind'] == kind]
    return {'entries': entries, 'page': page,
            'last_page': max([page] + pages)}


def fetch_seasons(item):
    text = _fetch(_local(item['url']))
    result = []
    for number in sorted(set(re.findall(r'id=[\'"]season-(\d+)[\'"]', text)), key=int):
        season = dict(item)
        season.update(name=u'الموسم %s' % number, season=number)
        result.append(season)
    if not result:
        raise RuntimeError('No seasons found on this show page')
    return result


def fetch_episodes(item):
    text = _fetch(_local(item['url']))
    blocks = re.split(r'<div\b[^>]*id=[\'"]season-(\d+)[\'"][^>]*>', text, flags=re.I)
    for index in range(1, len(blocks), 2):
        if blocks[index] == str(item['season']):
            return parse_cards(blocks[index + 1], 'episode-card')
    raise RuntimeError('The selected season is no longer available')


def fetch_servers(item):
    text = _fetch(_local(item['url']))
    post = re.search(r'var\s+postId\s*=\s*(\d+)', text)
    kind = re.search(r'var\s+postType\s*=\s*[\'"]([^\'"]+)', text)
    if not post or not kind:
        raise RuntimeError('The site player format has changed')
    result = []
    for tag, body in re.findall(r'(<button\b[^>]*>)(.*?)</button>', text, re.I | re.S):
        number = _attr(tag, 'data-server')
        if not number.isdigit():
            continue
        label = re.search(r'<span\b[^>]*class=[\'"]server-name[\'"][^>]*>(.*?)</span>', body, re.S)
        server = dict(item)
        server.update(name=_text(label.group(1) if label else body), title=item['name'],
                      post=post.group(1), post_type=kind.group(1), server=number)
        result.append(server)
    if not result:
        raise RuntimeError('No viewing servers are available')
    return result


def _stream(url, referer, quality='Original'):
    return {'url': url, 'quality': quality,
            'headers': {'User-Agent': UA, 'Referer': referer}}


def parse_hls(text, url, referer):
    """Keep every muxed rendition; retain the master for external audio."""
    if not text.lstrip().startswith('#EXTM3U'):
        return []
    result = [_stream(url, referer, 'Auto (HLS)')]
    # Audio-group masters need their audio playlists and cannot be reduced
    # to a bare video playlist on all Enigma2 players.
    if re.search(r'#EXT-X-MEDIA:.*TYPE=AUDIO', text):
        return result
    pending = None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('#EXT-X-STREAM-INF:'):
            pending = line
        elif line and not line.startswith('#') and pending is not None:
            resolution = re.search(r'RESOLUTION=\d+x(\d+)', pending)
            rate = re.search(r'\bBANDWIDTH=(\d+)', pending)
            label = resolution.group(1) + 'p' if resolution else '%s kbps' % (int(rate.group(1)) // 1000) if rate else 'HLS'
            result.append(_stream(urljoin(url, line), referer, label))
            pending = None
    return result


def _hls_streams(url, referer):
    try:
        return parse_hls(_fetch(url, referer=referer), url, referer) or [_stream(url, referer, 'Auto (HLS)')]
    except (HTTPError, URLError, ValueError):
        # The receiver may reach this CDN even when a local probe cannot.
        return [_stream(url, referer, 'Auto (HLS)')]


def parse_streamtape(text, embed):
    # Read only the player's literal string concatenation. Never execute JS.
    match = re.search(r"getElementById\(['\"]robotlink['\"]\)\.innerHTML\s*=\s*(['\"])(.*?)\1\s*\+\s*\(\s*(['\"])(.*?)\3\s*\)((?:\.substring\(\d+\))+)", text)
    if not match:
        raise RuntimeError('ST player format changed or this video was removed')
    suffix = match.group(4)
    for count in re.findall(r'\.substring\((\d+)\)', match.group(5)):
        suffix = suffix[int(count):]
    url = urljoin(embed, unescape(match.group(2) + suffix))
    parsed = urlparse(url)
    if parsed.hostname != urlparse(embed).hostname or parsed.path != '/get_video':
        raise RuntimeError('ST returned an unexpected video URL')
    return [_stream(url, embed)]


def parse_ok(text, embed):
    if 'copyrightsRestricted' in text:
        raise RuntimeError('OK: this video is blocked by the hosting service')
    streams = []
    labels = {'mobile': '144p', 'lowest': '240p', 'low': '360p',
              'sd': '480p', 'hd': '720p', 'full': '1080p', 'quad': '2160p'}
    for tag in re.findall(r'<[^>]+data-options\s*=[^>]+>', text, re.I):
        try:
            options = json.loads(_attr(tag, 'data-options'))
            metadata = options.get('flashvars', {}).get('metadata')
            metadata = json.loads(metadata) if isinstance(metadata, string_types) else metadata
            metadata = metadata or {}
            for video in metadata.get('videos', []):
                if urlparse(video.get('url', '')).scheme in ('http', 'https'):
                    label = video.get('name', '')
                    streams.append(_stream(video['url'], embed, labels.get(label, label or 'Original')))
            hls = metadata.get('ondemandHls') or metadata.get('hlsManifestUrl')
            if isinstance(hls, string_types) and urlparse(hls).scheme in ('http', 'https'):
                streams.extend(_hls_streams(hls, embed))
        except (ValueError, TypeError, AttributeError):
            continue
    return streams


def resolve_server(item):
    text = _fetch(urljoin(BASE, 'wp-admin/admin-ajax.php'),
                  {'action': 'doo_player_ajax', 'post': item['post'],
                   'type': item['post_type'], 'nume': item['server']}, item['url'])
    frame = re.search(r'<iframe\b[^>]*>', text, re.I)
    if not frame:
        raise RuntimeError('The viewing server returned no player')
    embed = urljoin(BASE, _attr(frame.group(0), 'src'))
    parsed = urlparse(embed)
    sources = parse_qs(parsed.query).get('source', [])
    streams = []
    if sources and parsed.hostname in ('show.alfajertv.com', 'fajer.show'):
        source = sources[0]
        if urlparse(source).scheme in ('http', 'https') and re.search(r'\.(mp4|m3u8)(?:[?#]|$)', source, re.I):
            streams.extend(_hls_streams(source, embed) if '.m3u8' in source else [_stream(source, embed)])
    elif parsed.hostname in ('ok.ru', 'www.ok.ru'):
        page = _fetch(embed, referer=item['url'])
        streams = parse_ok(page, embed)
    elif parsed.hostname in ('streamtape.com', 'www.streamtape.com'):
        try:
            streams = parse_streamtape(_fetch(embed, referer=item['url']), embed)
        except HTTPError as error:
            raise RuntimeError('ST: video removed or unavailable (HTTP %s)' % error.code)
    elif parsed.hostname in ('dsvplay.com', 'www.dsvplay.com'):
        raise RuntimeError('DW: this host currently rejects direct access / redirects to an advertising page. Select ST or Palestine.')
    if not streams:
        raise RuntimeError('This host did not return a supported video link. Select ST or Palestine.')
    unique, seen = [], set()
    for stream in streams:
        if stream['url'] not in seen:
            unique.append(stream)
            seen.add(stream['url'])
    result = dict(item)
    result.update(name=item.get('title', item['name']), streams=unique)
    return result
