#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Read-only remote update and announcement status for Alkuds."""
from __future__ import unicode_literals

import json
import os
import re

import requests


STATUS_URL = (
    "https://raw.githubusercontent.com/xximhxx/"
    "Alkuds-ipaudio-MAC-Xtreme-Player/main/alkuds-status.json"
)
STATE_FILE = "/etc/enigma2/alkuds/remote-alerts-state.json"
MAX_STATUS_BYTES = 65536

try:
    text_type = unicode
except NameError:
    text_type = str


def _text(value, maximum=4096):
    if value is None:
        return ""
    try:
        value = text_type(value)
    except Exception:
        value = str(value)
    return value.replace("\x00", "").strip()[:maximum]


def version_key(value):
    value = _text(value, 160).lower()
    date_match = re.search(r"(?:^|[-_])(20\d{6})(?:[-_]|$)", value)
    revision_match = re.search(r"(?:^|[-_])r(\d+)(?:[-_]|$)", value)
    date_value = int(date_match.group(1)) if date_match else 0
    revision_value = int(revision_match.group(1)) if revision_match else 0
    leading = value.split("-", 1)[0]
    numbers = tuple(int(part) for part in re.findall(r"\d+", leading)[:4])
    return date_value, revision_value, numbers


def fetch_status(current_version, user_agent):
    response = requests.get(
        STATUS_URL,
        headers={
            "User-Agent": _text(user_agent, 300) or "Alkuds-Enigma2/1.98",
            "Accept": "application/json",
            "Cache-Control": "no-cache",
        },
        timeout=(5, 12),
        verify=False,
    )
    response.raise_for_status()
    content = response.content
    if not content or len(content) > MAX_STATUS_BYTES:
        raise ValueError("Invalid remote status size")
    try:
        payload = response.json()
    except Exception:
        payload = json.loads(content.decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Invalid remote status format")

    latest = _text(payload.get("latest_version"), 160)
    current = _text(current_version, 160)
    update_available = bool(latest and version_key(latest) > version_key(current))
    notice = payload.get("notice") if isinstance(payload.get("notice"), dict) else {}
    return {
        "current_version": current,
        "latest_version": latest,
        "update_available": update_available,
        "update_title": _text(payload.get("update_title"), 160) or u"تحديث جديد متوفر",
        "update_message": _text(payload.get("update_message"), 2000),
        "notice": {
            "enabled": bool(notice.get("enabled")),
            "id": _text(notice.get("id"), 160),
            "title": _text(notice.get("title"), 160) or u"إشعار القدس",
            "message": _text(notice.get("message"), 3000),
        },
    }


def _load_state():
    try:
        with open(STATE_FILE, "r") as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _save_state(value):
    folder = os.path.dirname(STATE_FILE)
    temporary = STATE_FILE + ".tmp"
    try:
        if not os.path.isdir(folder):
            os.makedirs(folder)
        with open(temporary, "w") as handle:
            json.dump(value, handle, ensure_ascii=False)
        os.rename(temporary, STATE_FILE)
        try:
            os.chmod(STATE_FILE, 0o600)
        except Exception:
            pass
    except Exception:
        try:
            if os.path.exists(temporary):
                os.remove(temporary)
        except Exception:
            pass


def consume_pending_message(status):
    if not isinstance(status, dict):
        return ""
    state = _load_state()
    messages = []
    changed = False

    latest = _text(status.get("latest_version"), 160)
    if status.get("update_available") and latest and state.get("last_update_version") != latest:
        title = _text(status.get("update_title"), 160) or u"تحديث جديد متوفر"
        detail = _text(status.get("update_message"), 2000)
        message = title + "\n" + u"الإصدار المتوفر: " + latest
        if detail:
            message += "\n" + detail
        message += "\n" + u"اضغط الزر الأزرق للتحديث."
        messages.append(message)
        state["last_update_version"] = latest
        changed = True

    notice = status.get("notice") if isinstance(status.get("notice"), dict) else {}
    notice_id = _text(notice.get("id"), 160)
    notice_message = _text(notice.get("message"), 3000)
    if (notice.get("enabled") and notice_id and notice_message
            and state.get("last_notice_id") != notice_id):
        messages.append((_text(notice.get("title"), 160) or u"إشعار القدس") + "\n" + notice_message)
        state["last_notice_id"] = notice_id
        changed = True

    if changed:
        _save_state(state)
    return "\n\n".join(messages)
