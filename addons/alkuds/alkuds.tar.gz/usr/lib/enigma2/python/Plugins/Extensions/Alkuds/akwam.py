# -*- coding: utf-8 -*-
"""AKWAM catalogue, filters and public watch-page sources (Python 2/3)."""
import re
import time
import requests
try:
    from html.parser import HTMLParser
    from urllib.parse import urljoin, urlparse, parse_qs, urlencode
except ImportError:
    from HTMLParser import HTMLParser
    from urlparse import urljoin, urlparse, parse_qs
    from urllib import urlencode

BASE = 'https://akwam.ss/'
UA = 'Mozilla/5.0'
SECTIONS = [('movies', u'أفلام'), ('series', u'مسلسلات'),
            ('shows', u'تلفزيون'), ('mix', u'منوعات')]
FILTERS = ('section', 'category', 'rating', 'year', 'language', 'formats', 'quality')
_cache = {}


class Node(object):
    def __init__(self, tag='', attrs=None, parent=None):
        self.tag, self.attrs, self.parent = tag, dict(attrs or []), parent
        self.children = []
        self.parts = []

    def find(self, tag=None, css=None):
        result = []
        for child in self.children:
            if (tag is None or child.tag == tag) and (css is None or css in child.attrs.get('class', '').split()):
                result.append(child)
            result.extend(child.find(tag, css))
        return result

    def text(self):
        return re.sub(r'\s+', ' ', ''.join(p.text() if isinstance(p, Node) else p for p in self.parts)).strip()


class Document(HTMLParser):
    def __init__(self, text):
        HTMLParser.__init__(self)
        self.root = Node()
        self.current = self.root
        self.feed(text)
        self.close()

    def handle_starttag(self, tag, attrs):
        child = Node(tag, attrs, self.current)
        self.current.children.append(child)
        self.current.parts.append(child)
        if tag not in ('area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'):
            self.current = child

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_endtag(self, tag):
        node = self.current
        while node.parent is not None:
            if node.tag == tag:
                self.current = node.parent
                break
            node = node.parent

    def handle_data(self, text):
        self.current.parts.append(text)

    def handle_entityref(self, name):
        try:
            self.handle_data(self.unescape('&%s;' % name))
        except AttributeError:
            from html import unescape
            self.handle_data(unescape('&%s;' % name))

    def handle_charref(self, name):
        self.handle_entityref('#' + name)


def _local(url):
    url = urljoin(BASE, url)
    parsed = urlparse(url)
    if parsed.scheme not in ('https', 'http') or parsed.hostname not in ('akwam.ss', 'www.akwam.ss'):
        raise ValueError('Unexpected AKWAM catalogue address')
    return url


def _http_referer(url):
    # HTTP header values cannot carry raw Arabic. Percent-encode UTF-8 while
    # preserving existing escapes and query separators; fragments are not sent.
    return requests.utils.requote_uri((url or BASE).split('#', 1)[0])


def _fetch(url, referer=None, cookies=None):
    session = requests.Session()
    if cookies is not None:
        session.cookies.update(cookies)
    response = None
    try:
        local_url = _local(url)
        slow = urlparse(local_url).path.startswith(('/watch/', '/download/'))
        response = session.get(local_url, headers={'User-Agent': UA, 'Referer': _http_referer(referer or BASE)},
                               timeout=(8, 45) if slow else (7, 25))
        response.raise_for_status()
        if len(response.content) > 4 * 1024 * 1024:
            raise RuntimeError('AKWAM page is too large')
        text = response.content.decode('utf-8', 'replace')
        if 'cf-chl-' in text and 'entry-box' not in text and '<video' not in text:
            raise RuntimeError('AKWAM requires browser verification. Try again later.')
        root = Document(text).root
        root.cookies = session.cookies.copy()
        root.page_url = response.url
        return root
    finally:
        if response is not None:
            response.close()
        session.close()


def _image(node):
    imgs = node.find('img')
    return (imgs[0].attrs.get('data-src') or imgs[0].attrs.get('src') or '') if imgs else ''


def _kind(url):
    return {'movie': 'movies', 'series': 'series', 'shows': 'shows', 'mix': 'mix', 'episode': 'series'}.get(urlparse(url).path.strip('/').split('/')[0], '')


def fetch_filters(section, params=None):
    if section not in dict(SECTIONS):
        raise ValueError('Unknown AKWAM section')
    # Section-dependent categories remain dynamic; do not flatten all menus.
    params = {k: v for k, v in (params or {}).items() if k in FILTERS and str(v) != '0'}
    key = section + '?' + urlencode(sorted(params.items()))
    cached = _cache.get(key)
    if cached and time.time() - cached[0] < 300:
        return cached[1]
    root = _fetch(urljoin(BASE, key))
    result = []
    for select in root.find('select'):
        name = select.attrs.get('name')
        if name not in FILTERS:
            continue
        options = [{'name': o.text(), 'value': o.attrs.get('value', '0')} for o in select.find('option')]
        if options:
            result.append({'name': options[0]['name'], 'key': name, 'options': options})
    if not result:
        raise RuntimeError('AKWAM did not return its filters')
    if len(_cache) > 24:
        _cache.clear()
    _cache[key] = (time.time(), result)
    return result


def parse_items(root):
    entries, seen = [], set()
    for box in root.find(css='entry-box'):
        titles = box.find(css='entry-title')
        links = titles[0].find('a') if titles else []
        if not links:
            continue
        url = _local(links[0].attrs.get('href', ''))
        kind = _kind(url)
        if not kind or url in seen:
            continue
        seen.add(url)
        entries.append({'id': url, 'url': url, 'name': links[0].text(),
                        'section': kind, 'image': _image(box)})
    return entries


def fetch_items(section, page=1, params=None, query=''):
    values = {k: v for k, v in (params or {}).items() if k in FILTERS and str(v) != '0'}
    path = section
    if query:
        path = 'search'
        values['q'] = query.encode('utf-8')
    elif section not in dict(SECTIONS):
        raise ValueError('Unknown AKWAM section')
    values['page'] = max(1, int(page))
    root = _fetch(urljoin(BASE, path) + '?' + urlencode(values))
    entries = parse_items(root)
    if not query:
        entries = [item for item in entries if item['section'] == section]
    pages = [int(page)]
    for link in root.find('a'):
        href = urljoin(BASE, link.attrs.get('href', ''))
        parsed = urlparse(href)
        if parsed.path.rstrip('/') == '/' + path:
            value = parse_qs(parsed.query).get('page', [''])[0]
            if value.isdigit():
                pages.append(int(value))
    return {'entries': entries, 'page': int(page), 'last_page': max(pages)}


def fetch_detail(item):
    root = _fetch(item['url'])
    # Series pages already represent a season. Preserve the site's episode order.
    episodes, seen = [], set()
    for link in root.find('a'):
        href = link.attrs.get('href', '')
        if urlparse(item['url']).path.startswith('/episode/') or '/episode/' not in href or not link.text():
            continue
        url = _local(href)
        if url not in seen:
            episode = dict(item)
            episode.update(url=url, id=url, name=link.text(), action='detail')
            episodes.append(episode)
            seen.add(url)
    if episodes:
        return episodes
    labels = {a.attrs.get('href', '')[1:]: a.text() for a in root.find('a') if a.attrs.get('href', '').startswith('#tab-')}
    rows, seen = [], set()
    for link in root.find('a'):
        href = link.attrs.get('href', '')
        if not re.search(r'/(watch|download)/\d+/', href):
            continue
        url = _local(href)
        if url in seen:
            continue
        # Every watch link has a matching download; keep just the watch route.
        if '/download/' in url and any(a.attrs.get('href', '') == href.replace('/download/', '/watch/') for a in root.find('a')):
            continue
        parent = link.parent
        quality = ''
        while parent:
            if parent.attrs.get('id') in labels:
                quality = labels[parent.attrs['id']]
                break
            parent = parent.parent
        row = dict(item)
        playable = '/watch/' in url
        row.update(url=url, action='play' if playable else 'download', title=item['name'],
                   referer=item['url'], cookies=getattr(root, 'cookies', None),
                   download_url=url.replace('/watch/', '/download/', 1) if playable else url,
                   name=(u'مشاهدة - ' + (quality or u'المصدر')) if playable else u'ملف تحميل - ' + link.text(),
                   quality=quality)
        rows.append(row)
        seen.add(url)
    if not rows:
        raise RuntimeError('No episodes or viewing links are currently available for this title')
    return rows


def _resolved_streams(root, item, page_url):
    streams, seen = [], set()
    for video in root.find('video'):
        for source in video.find('source') + [video]:
            url = urljoin(page_url, source.attrs.get('src', '')) if source.attrs.get('src') else ''
            if urlparse(url).scheme not in ('https', 'http') or url in seen:
                continue
            seen.add(url)
            size = source.attrs.get('size', '')
            quality = (size + 'p') if size.isdigit() else item.get('quality') or 'Original'
            headers = {'User-Agent': UA, 'Referer': _http_referer(getattr(root, 'page_url', page_url))}
            # Requests applies cookie domain/path rules; never leak site cookies to an unrelated CDN.
            prepared = requests.Request('GET', url, cookies=getattr(root, 'cookies', None)).prepare()
            if prepared.headers.get('Cookie'):
                headers['Cookie'] = prepared.headers['Cookie']
            # Enigma2 players handle Akwam's ordinary ranged MP4 URL more
            # reliably than the local relay.  Keep the relay as a separately
            # labelled fallback for images whose player needs it.
            streams.append({'url': url, 'name': u'%s مباشر' % quality,
                            'quality': u'%s مباشر' % quality,
                            'relay': False, 'mediatype': 'mp4', 'source': 'video',
                            'headers': headers})
            streams.append({'url': url, 'name': u'%s احتياطي' % quality,
                            'quality': u'%s احتياطي' % quality,
                            'relay': True, 'mediatype': 'mp4',
                            'relay_options': {'media_type': 'mp4'}, 'source': 'video',
                            'headers': headers})
    # The current Akwam flow often leaves <source src=""> and puts the final
    # storage URL on the download page instead. Accept only an external HTTP
    # download host; never feed the Akwam HTML page to the video player.
    for link in root.find('a'):
        raw = link.attrs.get('href', '')
        url = urljoin(page_url, raw) if raw else ''
        parsed = urlparse(url)
        if (parsed.scheme not in ('http', 'https') or '/download/' not in parsed.path.lower()
                or parsed.hostname in ('akwam.ss', 'www.akwam.ss', 'ak.sv', 'www.ak.sv') or url in seen):
            continue
        seen.add(url)
        headers = {'User-Agent': UA, 'Referer': _http_referer(getattr(root, 'page_url', page_url))}
        quality = item.get('quality') or 'Original'
        streams.append({'url': url, 'name': u'%s مباشر' % quality,
                        'quality': u'%s مباشر' % quality,
                        'relay': False, 'mediatype': 'mp4', 'source': 'download',
                        'headers': headers})
        streams.append({'url': url, 'name': u'%s احتياطي' % quality,
                        'quality': u'%s احتياطي' % quality,
                        'relay': True, 'mediatype': 'mp4',
                        'relay_options': {'media_type': 'mp4'}, 'source': 'download',
                        'headers': headers})
    return streams


def resolve_watch(item):
    # The watch page normally contains every quality. Return those immediately;
    # the separate download page is slower and occasionally hangs or returns an
    # already-expired file, so request it only when the watch page has no media.
    selected = []
    try:
        root = _fetch(item['url'], item.get('referer'), item.get('cookies'))
        candidates = _resolved_streams(root, item, item['url'])
        video_streams = [stream for stream in candidates if stream.get('source') == 'video']
        selected = video_streams or candidates
    except Exception:
        # A temporary watch-page failure must not suppress the download route.
        selected = []
    download_url = item.get('download_url') or item['url'].replace('/watch/', '/download/', 1)
    if not selected and download_url != item['url']:
        try:
            fallback_root = _fetch(download_url, item.get('referer'), item.get('cookies'))
            selected = _resolved_streams(fallback_root, item, download_url)
        except Exception:
            selected = []
    streams, seen = [], set()
    for stream in selected:
        stream_key = (stream['url'], bool(stream.get('relay')))
        if stream_key not in seen:
            seen.add(stream_key)
            streams.append(stream)
    if not streams:
        raise RuntimeError('AKWAM storage server did not return a playable link. Try another quality or retry later.')
    return {'name': item.get('title') or item['name'], 'url': streams[0]['url'],
            'streams': streams, 'image': item.get('image', '')}
