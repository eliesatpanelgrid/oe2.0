# -*- coding: utf-8 -*-
# offline__init__.py
#
# Lightweight replacement for __init__.py when running EPGImport offline
# (outside of Enigma2 / Dreambox) for testing and development purposes.
#
# Usage:
#   1. Rename the real __init__.py to x__init__.py (to keep it safe).
#   2. Rename this file to __init__.py.
#   3. Run from parent directory:
#      python -m EPGImport.OfflineImport <source.xml>
#   4. After testing, restore the original __init__.py.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
#
from __future__ import print_function

import sys

# Offline stubs - these replace the real Enigma2 imports for testing
isDreamOS  = False
isDreamos  = False   # backward-compatibility alias
isDreamOs  = False   # backward-compatibility alias

PY3         = sys.version_info[0] >= 3
isPython312 = sys.version_info[:2] >= (3, 12)
isPython313 = sys.version_info[:2] >= (3, 13)
isPython314 = sys.version_info[:2] >= (3, 14)


def _(*args):
    """
    Translation stub for offline use.
    Returns the first argument unchanged (no actual translation).
    """
    return args[0] if args else ''


def getSkin(name):
    """
    Skin stub for offline use.
    Returns an empty string (no actual skin XML available outside Enigma2).
    """
    return ''
