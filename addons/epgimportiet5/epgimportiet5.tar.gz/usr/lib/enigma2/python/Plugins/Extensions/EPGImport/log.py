# -*- coding: utf-8 -*-
# log.py
#
# Simple in-memory log module compatible with Python 2.7 and Python 3.x
# Usage:
#   import log
#   print("Some text", file=log)
#
# The code is completely modified and optimized by Dorik1972
# Further improved for Python 2/3 cross-compatibility by iet5
#
import sys
import threading

# Detect Python major version (2 or 3)
PY3 = (sys.version_info[0] == 3)

# Use io.StringIO for both Python 2 and 3 (unicode-safe on both versions)
# In Python 2, io.StringIO requires unicode strings; we convert if needed.
from io import StringIO

# In-memory logfile (unicode-safe)
logfile = StringIO()

# Thread lock to make logging thread-safe across DreamOS and Open Source images
_lock = threading.Lock()


def _ensure_unicode(data):
    """
    Ensure data is a unicode string for io.StringIO compatibility.
    On Python 2.7, str may be bytes; decode to unicode.
    On Python 3, str is already unicode.
    """
    if PY3:
        # Python 3: str is already unicode; bytes need decoding
        if isinstance(data, bytes):
            return data.decode('utf-8', 'replace')
        return str(data) if not isinstance(data, str) else data
    else:
        # Python 2: unicode is unicode; str (bytes) needs decoding
        if isinstance(data, unicode):  # noqa: F821 (only exists in Py2)
            return data
        try:
            return data.decode('utf-8', 'replace')
        except Exception:
            # Last resort fallback for Python 2
            try:
                return unicode(data, errors='replace')  # noqa: F821
            except Exception:
                return u''


def write(data):
    """Write data to in-memory logfile and stdout safely (thread-safe)."""
    try:
        text = _ensure_unicode(data)
    except Exception:
        text = u''

    with _lock:
        # Circular buffer: reset when log exceeds 50 KB to prevent memory bloat
        if logfile.tell() > 51200:
            logfile.seek(0)
            logfile.truncate(0)
        try:
            logfile.write(text)
        except Exception:
            pass

    # Also output immediately to standard output (visible in serial console)
    try:
        if PY3:
            sys.stdout.write(text)
        else:
            # Python 2: write bytes to stdout
            if isinstance(data, unicode):  # noqa: F821
                sys.stdout.write(data.encode('utf-8', 'replace'))
            else:
                sys.stdout.write(data if isinstance(data, str) else str(data))
    except Exception:
        pass


def getvalue():
    """Return all current log contents as a string (thread-safe)."""
    with _lock:
        # Save current position, read from start, restore position
        pos = logfile.tell()
        logfile.seek(0)
        content = logfile.read(pos)
        logfile.seek(pos)
    # Return str (bytes in Py2, unicode in Py3) for UI display
    if PY3:
        return content
    else:
        try:
            return content.encode('utf-8', 'replace')
        except Exception:
            return str(content)


def clear():
    """Clear the in-memory log without racing active import worker threads."""
    with _lock:
        logfile.seek(0)
        logfile.truncate(0)
