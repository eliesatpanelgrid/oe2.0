# -*- coding: utf-8 -*-
# Epgdeepclean.py
#
# Deep-clean the Enigma2 EPG database (epg.dat and epg.db).
# Stops Enigma2, removes all known EPG files, cleans /tmp cache, then restarts.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS, OpenATV, VTI, Open Source Enigma2, BlackHole, VU+
#
# Compiled / modified by iet5
#
from __future__ import print_function

import os
import time
import glob
import shutil

from . import _, isDreamOS
from Screens.MessageBox import MessageBox
from Tools.Notifications import AddPopup
from enigma import eTimer


class EPGDeepClean(object):
    """
    EPG deep-clean helper.

    Usage:
        cleaner = EPGDeepClean(session)
        cleaner.start()   # opens confirmation dialog first

    CONDITION: eTimer callback binding differs between DreamOS and Open Source images.
    - DreamOS uses signal/slot C++ style (timeout.connect)
    - Open Source uses Python callback list (callback.append)
    """

    def __init__(self, session):
        self.session = session

        # Create a one-shot timer with platform-specific callback binding
        self.timer = eTimer()
        if isDreamOS:
            # CONDITION: DreamOS uses signal/slot connection (C++ style)
            self.timer_conn = self.timer.timeout.connect(self.doClean)
        else:
            # CONDITION: Open Source (OpenATV / VTI / PLi / OE-A / BlackHole): Python callback list
            self.timer.callback.append(self.doClean)

    def start(self):
        """Open a Yes/No confirmation dialog before starting the clean."""
        self.session.openWithCallback(
            self.confirm,
            MessageBox,
            _(
                "EPG DeepClean will stop Enigma2,\n"
                "clean EPG database and restart.\n\n"
                "Continue?"
            ),
            MessageBox.TYPE_YESNO,
            timeout=15
        )

    def confirm(self, answer):
        """Start the clean process after user confirmation."""
        if answer:
            AddPopup(
                _("EPG DeepClean started...\nPlease wait."),
                MessageBox.TYPE_INFO,
                5
            )
            # Short delay (1 s) so the popup is visible before Enigma2 stops
            self.timer.start(1000, True)

    def doClean(self):
        """
        Perform the actual clean:
        1. Stop Enigma2 (init 4)
        2. Remove all known EPG database files
        3. Remove temporary EPG cache files from /tmp
        4. Flush filesystem buffers (sync)
        5. Restart Enigma2 (init 3)
        """
        # Stop Enigma2 gracefully before removing files
        os.system("init 4")
        time.sleep(3)

        # All known EPG database locations for DreamOS, VU+, OpenATV, VTI, Open Source, BlackHole images
        epg_paths = [
            "/etc/enigma2/epg.db",
            "/etc/enigma2/epg.dat",
            "/media/hdd/epg.db",
            "/media/hdd/epg.dat",
            "/media/usb/epg.db",
            "/media/usb/epg.dat",
            "/media/mmc/epg.db",
            "/media/mmc/epg.dat",
            "/media/cf/epg.db",
            "/media/cf/epg.dat",
            "/hdd/epg.dat",
            "/hdd/epg.db",
        ]

        for epg_path in epg_paths:
            try:
                if os.path.exists(epg_path):
                    os.remove(epg_path)
                    print("[EPGDeepClean] Removed: %s" % epg_path)
            except Exception as _e:
                # Non-fatal: log and continue cleaning other paths
                print("[EPGDeepClean] Could not remove %s: %s" % (epg_path, _e))

        # Remove temporary EPG and Enigma2 cache files from /tmp
        for pattern in ("/tmp/epg*", "/tmp/enigma2*"):
            for tmp_path in glob.glob(pattern):
                try:
                    if os.path.isdir(tmp_path):
                        shutil.rmtree(tmp_path, ignore_errors=True)
                    elif os.path.exists(tmp_path):
                        os.remove(tmp_path)
                        print("[EPGDeepClean] Removed temp: %s" % tmp_path)
                except Exception as _e:
                    print("[EPGDeepClean] Could not remove temp %s: %s" % (tmp_path, _e))

        # Ensure all writes are flushed to persistent storage before restart
        os.system("sync")
        time.sleep(2)

        # Restart Enigma2
        os.system("init 3")
