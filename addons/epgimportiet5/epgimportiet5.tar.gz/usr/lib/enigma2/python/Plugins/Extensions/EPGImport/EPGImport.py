#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import print_function
# Hybrid importer for DreamOS and open-source Enigma2 images.

# ===============================
# Standard Library
# ===============================
import random
import subprocess
import os
import traceback
import tempfile
import hashlib
import threading
from time import time, localtime, mktime
from datetime import datetime
from os import statvfs, unlink
from os.path import getsize, join, split, isdir, exists, splitext
from shutil import copy2, copyfileobj
from sys import version_info

# ===============================
# Enigma2 / Components
# ===============================
try:
    from Components.config import config
except ImportError:
    config = None


# ===============================
# Duplicate protection helpers
# ===============================
def _to_text(value):
    """Return a safe text value on Python 2 and Python 3."""
    try:
        text_type = unicode
    except NameError:
        text_type = str
    try:
        if isinstance(value, bytes):
            return value.decode('utf-8', 'ignore')
    except Exception:
        pass
    try:
        return text_type(value)
    except Exception:
        return str(value)


try:
    _text_type = unicode
except NameError:
    _text_type = str
_string_types = (str, _text_type)


def _stop_duplicates_sources_enabled():
    """Return True when duplicate event/source protection is enabled."""
    try:
        return bool(config.plugins.epgimport.stop_duplicates_sources.value)
    except Exception:
        return False


class _ChannelServiceList(list):
    """Service-reference list that also keeps the original XMLTV channel id."""

    pass


def _get_channel_identity(services):
    """Return the original XMLTV channel id when the parser provided it."""
    for attr in ('channel_id', 'xmltv_channel_id', 'epgimport_channel_id'):
        try:
            value = getattr(services, attr)
            if value:
                return value
        except Exception:
            pass
    return None


def _normalise_service_ref_key(ref):
    """Return Enigma2 EPG service id: SID, TSID, ONID and DVB namespace."""
    if not ref:
        return ''
    text = _to_text(ref)
    try:
        parts = text.split(':')
        if len(parts) >= 7:
            return ':'.join((
                '%X' % (int(parts[3], 16) & 0xFFFF),
                '%X' % (int(parts[4], 16) & 0xFFFF),
                '%X' % (int(parts[5], 16) & 0xFFFF),
                parts[6].upper()
            ))
    except Exception:
        pass
    return text


def _attach_channel_identity(services, channel_id):
    """Attach XMLTV channel metadata without changing list-like behaviour."""
    if not channel_id:
        return services
    try:
        if isinstance(services, _ChannelServiceList):
            service_list = services
        elif isinstance(services, _string_types):
            service_list = _ChannelServiceList([services])
        else:
            service_list = _ChannelServiceList(services)
        service_list.channel_id = channel_id
        service_list.xmltv_channel_id = channel_id
        return service_list
    except Exception:
        return services


def _normalise_event_title(title):
    """Normalise titles for stable Python 2/3 duplicate fingerprints."""
    try:
        text = _to_text(title).strip().lower()
    except Exception:
        text = _to_text(title)
    # Ignore Arabic diacritics and tatweel when comparing titles.
    try:
        import re as _re
        text = _re.sub(u'[\u0640\u064b-\u065f]', u'', text)
    except Exception:
        pass
    return text


def _normalise_services_key(services):
    """Build a stable channel service-id part for the duplicate fingerprint.

    The user requested to prioritize the channel service ID (from the provider)
    for duplicate fingerprinting over the mapped service reference.
    """
    channel_id = _get_channel_identity(services)
    if channel_id:
        try:
            return _to_text(channel_id).strip().lower()
        except Exception:
            return _to_text(channel_id)

    try:
        if isinstance(services, _string_types):
            items = [_normalise_service_ref_key(services)]
        else:
            items = sorted([_normalise_service_ref_key(x) for x in list(services)])
    except Exception:
        try:
            items = [_normalise_service_ref_key(services)]
        except Exception:
            items = ['']
    service_key = '|'.join([x for x in items if x])
    if service_key:
        return service_key
    return ''


def _build_event_duplicate_key(services, event_data):
    """Build duplicate key from channel service id, start time, stop time and title."""
    try:
        start_time = int(event_data[0])
    except Exception:
        start_time = event_data[0] if event_data else 0
    try:
        duration = int(event_data[1])
    except Exception:
        duration = 0
    try:
        stop_time = start_time + duration
    except Exception:
        stop_time = event_data[1] if len(event_data) > 1 else 0
    title = event_data[2] if len(event_data) > 2 else ''
    description = event_data[4] if len(event_data) > 4 else (event_data[3] if len(event_data) > 3 else '')
    return (
        _normalise_services_key(services),
        start_time,
        stop_time,
        _normalise_event_title(title),
        _normalise_event_title(description)
    )


def _digest_event_duplicate_key(event_key):
    """Return a compact stable fingerprint without retaining event text."""
    payload = u'\x1f'.join([_to_text(part) for part in event_key])
    try:
        payload = payload.encode('utf-8', 'replace')
    except Exception:
        payload = str(payload)
    return hashlib.sha1(payload).digest()

# ===============================
# lzma support (fallback for old systems)
# ===============================
def _safe_import(module_name):
    try:
        module = __import__(module_name)
        return module, None
    except Exception as import_error:
        return None, import_error


gzip, GZIP_IMPORT_ERROR = _safe_import('gzip')
lzma = None
try:
    import lzma as lzma_module
    lzma = lzma_module
except ImportError:
    try:
        from backports import lzma as lzma_module
        lzma = lzma_module
    except ImportError:
        lzma = None

# ===============================
# Twisted Framework
# ===============================
TWISTED_IMPORT_ERROR = None
TWISTED_WEB_IMPORT_ERROR = None
HAS_TWISTED = True
HAS_TWISTED_WEB = False

try:
    import twisted.python.runtime
    from twisted.internet import reactor, threads
    from twisted.internet import ssl
    from twisted.internet.defer import setDebugging
except Exception as twisted_error:
    HAS_TWISTED = False
    TWISTED_IMPORT_ERROR = twisted_error

    class _ImmediateResult(object):
        def __init__(self, result=None, failure=None):
            self.result = result
            self.failure = failure

        def addCallback(self, callback, *args, **kwargs):
            if self.failure is None and callback is not None:
                try:
                    self.result = callback(self.result, *args, **kwargs)
                except Exception as e:
                    self.failure = e
            return self

        def addErrback(self, callback, *args, **kwargs):
            if self.failure is not None and callback is not None:
                try:
                    self.result = callback(self.failure, *args, **kwargs)
                    self.failure = None
                except Exception as e:
                    self.failure = e
            return self

        def addBoth(self, callback, *args, **kwargs):
            payload = self.failure if self.failure is not None else self.result
            if callback is not None:
                try:
                    self.result = callback(payload, *args, **kwargs)
                    self.failure = None
                except Exception as e:
                    self.failure = e
            return self

    class _ImmediateThreads(object):
        @staticmethod
        def deferToThread(function, *args, **kwargs):
            try:
                return _ImmediateResult(result=function(*args, **kwargs))
            except Exception as e:
                return _ImmediateResult(failure=e)

    class _DummyCallLater(object):
        def __init__(self, callback=None, *args, **kwargs):
            self._active = False
            if callback is not None:
                callback(*args, **kwargs)

        def active(self):
            return self._active

        def cancel(self):
            self._active = False

    class _ImmediateReactor(object):
        @staticmethod
        def callLater(delay, callback, *args, **kwargs):
            return _DummyCallLater(callback, *args, **kwargs)

        @staticmethod
        def callFromThread(callback, *args, **kwargs):
            return callback(*args, **kwargs)

        @staticmethod
        def addReader(reader):
            while True:
                try:
                    reader.doRead()
                except Exception:
                    break

        @staticmethod
        def removeReader(reader):
            return None

    class _DummyRuntimePlatform(object):
        @staticmethod
        def supportsThreads():
            return False

    class _DummyTwistedRuntime(object):
        platform = _DummyRuntimePlatform()

    class _DummyTwisted(object):
        python = type('python', (), {'runtime': _DummyTwistedRuntime()})

    class _DummySSL(object):
        class CertificateOptions(object):
            def __init__(self, verify=False):
                self.verify = verify

            def getContext(self):
                return None

    def setDebugging(flag):
        return None

    twisted = _DummyTwisted()
    reactor = _ImmediateReactor()
    threads = _ImmediateThreads()
    ssl = _DummySSL()
    _sslverify = None
else:
    try:
        from twisted.web.client import (
            Agent,
            BrowserLikeRedirectAgent,
            HTTPConnectionPool,
            readBody,
        )
        from twisted.web.http_headers import Headers
        HAS_TWISTED_WEB = True
    except Exception as twisted_web_error:
        Agent = None
        BrowserLikeRedirectAgent = None
        HTTPConnectionPool = None
        readBody = None
        Headers = None
        HAS_TWISTED_WEB = False
        TWISTED_WEB_IMPORT_ERROR = twisted_web_error

    try:
        from twisted.internet import _sslverify
    except ImportError:
        _sslverify = None

if HAS_TWISTED_WEB:
    try:
        from twisted.web.client import BrowserLikePolicyForHTTPS as IgnoreHTTPSContextFactory
    except ImportError:
        # for twisted < 14 backward compatibility
        from twisted.web.client import WebClientContextFactory as IgnoreHTTPSContextFactory
else:
    class IgnoreHTTPSContextFactory(object):
        pass

# ===============================
# Local Project Imports
# ===============================
from . import log, isDreamOS, isDreamos, isDreamOs, isPython312, isPython313, isPython314
from .EPGConfig import PY3, isLocalFile, openStream

# ===============================
# Python 2 vs 3 Compatibility Handling
# ===============================
if version_info[0] == 3:
    unicode = str
    basestring = str

# ===============================
# DreamOS cache state support
# ===============================
try:
    from enigma import cachestate
except ImportError:
    cachestate = None

# ===============================
# Global constants
# ===============================
EPG_DB_PATH = "/etc/enigma2/epg.dat"
EPG_DAT_PATH = "/hdd/epg.dat"
HDD_EPG_DAT = "/hdd/epg.dat"
PARSERS = {"xmltv": "gen_xmltv", "genxmltv": "gen_xmltv", "gen_xmltv": "gen_xmltv"}

date_format = "%Y-%m-%d"
alloweddelta = 2
CheckFile = "LastUpdate.txt"
ServerStatusList = {}
DEBUG_LOG_PATH = "/tmp/EPGImport_debug.log"
ISO639_associations = {
    'ar': 'ara', 'bg': 'bul', 'ca': 'cat', 'cs': 'ces', 'da': 'dan',
    'de': 'deu', 'el': 'ell', 'en': 'eng', 'es': 'spa', 'et': 'est',
    'fi': 'fin', 'fr': 'fra', 'he': 'heb', 'hr': 'hrv', 'hu': 'hun',
    'it': 'ita', 'ja': 'jpn', 'ko': 'kor', 'lt': 'lit', 'lv': 'lav',
    'nl': 'nld', 'no': 'nor', 'pl': 'pol', 'pt': 'por', 'ro': 'ron',
    'ru': 'rus', 'sk': 'slk', 'sl': 'slv', 'sr': 'srp', 'sv': 'swe',
    'th': 'tha', 'tr': 'tur', 'uk': 'ukr', 'zh': 'zho'
}

if config is not None:
    try:
        if config.misc.epgcache_filename.value:
            HDD_EPG_DAT = config.misc.epgcache_filename.value
        else:
            config.misc.epgcache_filename.setValue(HDD_EPG_DAT)
    except Exception:
        pass


def debug_log(message, reset=False):
    try:
        mode = 'w' if reset else 'a'
        stamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(DEBUG_LOG_PATH, mode) as fd:
            fd.write('[%s] %s\n' % (stamp, message))
    except Exception:
        pass


def _open_gzip_file(filename):
    if gzip is not None:
        return gzip.open(filename, 'rb')

    gzip_binary = '/bin/gzip' if exists('/bin/gzip') else ('/usr/bin/gzip' if exists('/usr/bin/gzip') else None)
    if gzip_binary:
        output = tempfile.TemporaryFile()
        errors = tempfile.TemporaryFile()
        process = subprocess.Popen([gzip_binary, '-d', '-c', filename], stdout=output, stderr=errors)
        process.wait()
        if process.returncode == 0:
            output.seek(0)
            errors.close()
            return output
        errors.seek(0)
        err = errors.read()
        output.close()
        errors.close()
        raise Exception("system gzip failed: %s" % repr(err))

    raise Exception("gzip module is unavailable: %s" % repr(GZIP_IMPORT_ERROR))


class IgnoreHTTPS(IgnoreHTTPSContextFactory):
    def creatorForNetloc(self, hostname, port):
        options = ssl.CertificateOptions(verify=False)
        if _sslverify:
            return _sslverify.ClientTLSOptions(hostname if PY3 else hostname.encode('utf-8'), options.getContext())
        else:
            # Fallback for older Twisted versions
            return options.getContext()


setDebugging(False)

# Use a persistent connection pool when Twisted Web is available.
if HAS_TWISTED_WEB:
    pool = HTTPConnectionPool(reactor, persistent=True)
    pool.maxPersistentPerHost = 1
    pool.cachedConnectionTimeout = 600
    agent = BrowserLikeRedirectAgent(Agent(reactor, pool=pool, contextFactory=IgnoreHTTPS()))
    headers = Headers({'User-Agent': ['Mozilla/5.0 (SmartHub; SMART-TV; U; Linux/SmartTV; Maple2012) AppleWebKit/534.7 (KHTML, like Gecko) SmartTV Safari/534.7']})
else:
    pool = None
    agent = None
    headers = None


def _read_first_line(path):
    try:
        with open(path, 'r') as handle:
            return handle.readline().strip()
    except Exception:
        return ''


def _read_text_file(path):
    try:
        with open(path, 'r') as handle:
            return handle.read().strip()
    except Exception:
        return ''


def _looks_like_vu_model(model_name):
    if not model_name:
        return False
    model_name = model_name.lower()
    vu_prefixes = (
        'vu', 'ultimo', 'uno', 'duo', 'solo', 'zero'
    )
    for prefix in vu_prefixes:
        if model_name.startswith(prefix):
            return True
    return False


def get_runtime_profile(refresh=False):
    """Detect current runtime and return a plugin-compatible profile."""
    if not refresh:
        cached = globals().get('RUNTIME_PROFILE')
        if isinstance(cached, dict) and cached:
            return dict(cached)

    model = _read_first_line('/proc/stb/info/model') or _read_first_line('/proc/stb/info/boxtype')
    vumodel = _read_first_line('/proc/stb/info/vumodel')
    image_info = ' '.join([
        _read_text_file('/etc/image-version'),
        _read_text_file('/etc/issue'),
        _read_text_file('/etc/vtiversion'),
    ]).lower()
    has_opkg = exists('/var/lib/opkg/status') or exists('/etc/opkg') or exists('/usr/bin/opkg')
    has_dpkg = exists('/var/lib/dpkg/status') or exists('/etc/dpkg') or exists('/usr/bin/dpkg')

    image = 'open_source'
    if exists('/etc/vtiversion') or 'vti' in image_info:
        image = 'vti'
    elif 'openatv' in image_info:
        image = 'openatv'
    elif 'openpli' in image_info or exists('/etc/opkg/openpli-feed.conf'):
        image = 'openpli'
    elif any(token in image_info for token in ('openbh', 'openspa', 'openhdf', 'openvision', 'egami', 'openesi')):
        image = 'oea'
    elif isDreamOS:
        image = 'dreamos'

    # Runtime behavior should follow the installed image/system first, not the hardware model.
    family = 'dreambox' if image == 'dreamos' else 'opensource'

    is_vti = image == 'vti'
    is_openatv = image == 'openatv'
    is_openpli = image == 'openpli'
    is_oea = image == 'oea'
    is_dreambox = family == 'dreambox' or image == 'dreamos'
    is_vuplus = bool(vumodel) or _looks_like_vu_model(model)
    uses_epgdb = is_dreambox
    if isDreamOS:
        detection_reason = 'DreamOS system or Dreambox hardware with dpkg'
    elif has_opkg:
        detection_reason = 'opkg/open-source image'
    elif has_dpkg:
        detection_reason = 'dpkg/open-source fallback (no DreamOS marker)'
    else:
        detection_reason = 'no package marker/open-source fallback'

    epg_cache_path = HDD_EPG_DAT
    try:
        if config is not None and getattr(config, 'misc', None) is not None and hasattr(config.misc, 'epgcache_filename'):
            configured_path = config.misc.epgcache_filename.value
            if configured_path:
                epg_cache_path = configured_path
    except Exception:
        pass

    cleanup_candidates = []
    for candidate in (epg_cache_path, HDD_EPG_DAT, EPG_DAT_PATH):
        if candidate and candidate not in cleanup_candidates:
            cleanup_candidates.append(candidate)

    is_openatv_modern_python = is_openatv and version_info[0] == 3 and version_info[1] >= 12
    is_open_source_python_312_plus = family != 'dreambox' and version_info[0] == 3 and version_info[1] >= 12
    is_open_source_python_314_plus = family != 'dreambox' and version_info[0] == 3 and version_info[1] >= 14

    open_source_load_path = HDD_EPG_DAT or EPG_DAT_PATH

    profile = {
        'family': family,
        'image': image,
        'model': vumodel or model or 'unknown',
        'python_major': version_info[0],
        'python_minor': version_info[1],
        'python_micro': version_info[2],
        'supports_threads': twisted.python.runtime.platform.supportsThreads(),
        'is_dreambox': is_dreambox,
        'uses_epgdb': uses_epgdb,
        'epg_backend': 'epg.db' if uses_epgdb else 'epg.dat',
        'detection_reason': detection_reason,
        'is_vuplus': is_vuplus,
        'is_vti': is_vti,
        'is_openatv': is_openatv,
        'is_openatv_python_313': is_openatv_modern_python,
        'is_open_source_python_312_plus': is_open_source_python_312_plus,
        'is_open_source_python_314_plus': is_open_source_python_314_plus,
        'is_openpli': is_openpli,
        'is_oea': is_oea,
        'has_opkg': has_opkg,
        'has_dpkg': has_dpkg,
        'python_version': '%s.%s.%s' % (version_info[0], version_info[1], version_info[2]),
        'epg_dat_path': epg_cache_path if is_dreambox else open_source_load_path,
        'epg_cache_path': epg_cache_path,
        'cleanup_candidates': cleanup_candidates,
    }
    globals()['RUNTIME_PROFILE'] = dict(profile)
    return profile


RUNTIME_PROFILE = get_runtime_profile()


def should_skip_restart(refresh=False):
    """EPG activation is live on all supported images."""
    return True


def get_active_epg_dat_path(profile=None):
    profile = profile or get_runtime_profile()
    return profile.get('epg_dat_path') or HDD_EPG_DAT or EPG_DAT_PATH


def get_active_epg_cache_path(profile=None):
    profile = profile or get_runtime_profile()
    return profile.get('epg_cache_path') or get_active_epg_dat_path(profile)


def get_open_source_epg_targets(profile=None):
    profile = profile or get_runtime_profile()
    targets = []
    for candidate in (
        profile.get('epg_dat_path'),
        profile.get('epg_cache_path'),
        EPG_DAT_PATH,
        HDD_EPG_DAT,
        '/etc/enigma2/epg.dat',
        '/media/hdd/epg.dat',
        '/media/usb/epg.dat',
    ):
        if candidate and candidate not in targets:
            targets.append(candidate)
    return targets


def _is_dream_runtime(profile=None):
    profile = profile or RUNTIME_PROFILE
    return profile.get('family') == 'dreambox' or profile.get('image') == 'dreamos'


def getISO639(text):
    try:
        decoded_text = text.decode('UTF-8')
    except Exception:
        decoded_text = text

    for line in decoded_text.split('\n'):
        parts = line.split('|')
        if len(parts) > 2 and parts[2]:
            ISO639_associations[parts[2]] = parts[0]


def completed(passthrough):
    global timeoutCall
    if timeoutCall is not None:
        try:
            if timeoutCall.active():
                timeoutCall.cancel()
        except Exception:
            pass
    return passthrough


def doRead(response):
    if readBody is None:
        return
    d = readBody(response)
    d.addCallback(getISO639)


# Load ISO639 language codes.
if not HAS_TWISTED and TWISTED_IMPORT_ERROR is not None:
    timeoutCall = None
    print("[EPGImport] Twisted core unavailable, using fallback reactor/threads: %s" % repr(TWISTED_IMPORT_ERROR), file=log)
elif HAS_TWISTED_WEB and agent is not None and headers is not None:
    try:
        d = agent.request(b'GET', b'http://loc.gov/standards/iso639-2/ISO-639-2_utf-8.txt', headers, None)
        d.addCallback(doRead).addErrback(lambda e: print("[EPGImport] Failed to load ISO639 codes: %s" % e, file=log))
        timeoutCall = reactor.callLater(3 * 60, d.cancel)
        d.addBoth(completed)
    except Exception as e:
        timeoutCall = None
        print("[EPGImport] Error loading ISO639 codes: %s" % str(e), file=log)
else:
    timeoutCall = None
    if TWISTED_WEB_IMPORT_ERROR is not None:
        print("[EPGImport] Twisted Web unavailable, skipping ISO639 preload: %s" % repr(TWISTED_WEB_IMPORT_ERROR), file=log)


def relImport(name):
    fullname = __name__.split('.')
    fullname[-1] = name
    mod = __import__('.'.join(fullname))
    for n in fullname[1:]:
        mod = getattr(mod, n)
    return mod


def getParser(name):
    """Support both original parser loading styles."""
    module_name = PARSERS.get(name, name)

    try:
        mod = relImport(module_name)
        if hasattr(mod, 'new'):
            parser = mod.new()
            if hasattr(parser, 'iterator'):
                return parser
        return mod
    except Exception:
        module = __import__(__name__[:__name__.rfind('.') + 1] + module_name, fromlist=[None])
        klass = getattr(module, module_name, None)
        if klass is not None:
            return klass
        return module


def getTimeFromHourAndMinutes(hour, minute):
    # Check if the hour and minute are within valid ranges
    if not (0 <= hour < 24):
        raise ValueError('Hour must be between 0 and 23')
    if not (0 <= minute < 60):
        raise ValueError('Minute must be between 0 and 59')

    now_tm = localtime()
    begin = int(mktime((
        now_tm.tm_year,
        now_tm.tm_mon,
        now_tm.tm_mday,
        hour,
        minute,
        0,
        now_tm.tm_wday,
        now_tm.tm_yday,
        now_tm.tm_isdst
    )))
    return begin


def bigStorage(minFree, default, *candidates):
    """Select storage using the original Dreambox or open source strategy."""
    if _is_dream_runtime():
        try:
            diskstat = statvfs(default)
            free = diskstat.f_bfree * diskstat.f_bsize
            if (free > minFree) and (free > 50000000):
                return default
        except Exception as e:
            print('[EPGImport] Failed to stat %s:' % default, e, file=log)

        try:
            with open('/proc/mounts', 'rb') as handle:
                mounts = handle.readlines()
        except Exception:
            mounts = []

        mountpoints = []
        for item in mounts:
            try:
                line = item.decode('utf-8')
            except Exception:
                line = item
            parts = line.split(' ', 2)
            if len(parts) > 1:
                mountpoints.append(parts[1])

        for candidate in candidates:
            if candidate in mountpoints:
                try:
                    diskstat = statvfs(candidate)
                    free = diskstat.f_bfree * diskstat.f_bsize
                    if free > minFree:
                        return candidate
                except Exception:
                    pass
        return default

    def free_space_available(dirname):
        try:
            st = statvfs(dirname)
            return st.f_bavail * st.f_frsize
        except Exception:
            return 0

    candidates = list(filter(isdir, candidates))
    candidates.append(default)
    try:
        candidate = sorted(candidates, key=lambda x: free_space_available(x), reverse=True)[0]
        free = free_space_available(candidate)
        if free > minFree or free > free_space_available(default):
            return candidate
        raise Exception('Free space is critically small')
    except Exception as e:
        print('[EPGImport] An error occurred in bigStorage detection:', repr(e), file=log)
        return default


class OudeisImporter:
    """Wrapper to convert original patch to new one that accepts multiple services"""

    def __init__(self, epgcache):
        self.epgcache = epgcache

    # difference with old patch is that services is a list or tuple, this
    # wrapper works around it.
    def importEvents(self, services, events):
        for service in services:
            try:
                self.epgcache.importEvent(service, events)
            except Exception as e:
                traceback.print_exc()
                print('[EPGImport][OudeisImporter][importEvents] ### importEvents exception:', e, file=log)


def unlink_if_exists(filename, allow_epg_db=True):
    try:
        unlink(filename)
    except Exception as e:
        if getattr(e, 'errno', None) == 2:
            return
        print("[EPGImport] warning: Could not remove '%s' intermediate" % filename, repr(e), file=log)


class EPGImport(object):
    """Class to import EPGData"""

    # Bound memory without splitting Enigma2 event tuples.
    EVENT_IMPORT_BATCH_SIZE = 250
    THREAD_DELIVERY_BATCH_SIZE = 250

    def __init__(self, epgcache, channelFilter):
        self.eventCount = None
        self.startTime = None
        self.storage = None
        self.sources = []
        self.source = None
        self.fd = None
        self.iterator = None
        self.onDone = None
        self.epgcache = epgcache
        self.channelFilter = channelFilter
        self.runtime_profile = get_runtime_profile()
        self.cacheState_conn = None
        self._reader_temp_filename = None
        self._temp_decompressed_file = None
        self._force_inline_xz_import = False
        self._inline_read_call = None
        self._inline_read_filename = None
        self._do_read_debug_counter = 0
        self.duplicateEventCount = 0
        self._event_batch_services = None
        self._event_batch_data = []
        self._rating_supported = True
        self._seen_event_keys = set()
        self._is_finalizing = False
        # Some images activate the cache asynchronously.
        self._activation_cache_conn = None
        self._activation_watchdog = None
        self._activation_pending = False
        self._activation_label = None
        self._pending_refresh_calls = []

    def isDreamRuntime(self):
        return _is_dream_runtime(self.runtime_profile)

    def isOpenSourceRuntime(self):
        return not self.isDreamRuntime()

    def isModernOpenSourceRuntime(self):
        return (
            self.isOpenSourceRuntime() and
            self.runtime_profile.get('python_major') == 3 and
            self.runtime_profile.get('python_minor', 0) >= 12
        )

    def isOpenSourcePython312PlusRuntime(self):
        return bool(self.runtime_profile.get('is_open_source_python_312_plus'))

    def isOpenSourcePython314PlusRuntime(self):
        return bool(self.runtime_profile.get('is_open_source_python_314_plus'))

    def usesLegacyDreamEventLogic(self):
        """DreamOS/Python 2.7 uses the proven epg.db event path from 3.5."""
        return self.isDreamPython27Runtime()

    def usesLegacyOpenSourceEventLogic(self):
        """Open-source images use the proven direct epg.dat event path from 3.5."""
        return self.isOpenSourceRuntime()

    def isFastOpenSourceXzRuntime(self, sourcefile=None):
        if not self.isOpenSourcePython312PlusRuntime():
            return False
        if sourcefile is None:
            return True
        return self._is_xz_like_source(sourcefile)

    def supportsThreadedParser(self):
        if not twisted.python.runtime.platform.supportsThreads():
            return False
        if self.isDreamRuntime():
            return False
        if self.runtime_profile.get('is_openatv') or self.runtime_profile.get('is_vti') or self.runtime_profile.get('is_openpli') or self.runtime_profile.get('is_oea'):
            return True
        if self.isModernOpenSourceRuntime():
            return True
        return exists('/var/lib/opkg/status')

    def isDreamPython27Runtime(self):
        return (
            self.isDreamRuntime() and
            self.runtime_profile.get('python_major') == 2 and
            self.runtime_profile.get('python_minor') == 7
        )

    def _stream_has_fileno(self):
        if self.fd is None:
            return False
        try:
            if not hasattr(self.fd, 'fileno'):
                return False
            self.fd.fileno()
            return True
        except Exception:
            return False

    def _materialize_stream_for_reader(self):
        path = bigStorage(9000000, '/tmp', '/media/cf', '/media/mmc', '/media/usb', '/media/hdd')
        temp_name = join(path, 'epgimport_reader.tmp')
        debug_log('materialize stream start temp=%s' % temp_name)
        try:
            if self._reader_temp_filename and exists(self._reader_temp_filename):
                unlink_if_exists(self._reader_temp_filename)
        except Exception:
            pass
        try:
            with open(temp_name, 'wb') as outfd:
                copyfileobj(self.fd, outfd)
            try:
                self.fd.close()
            except Exception:
                pass
            self.fd = open(temp_name, 'rb')
            self._reader_temp_filename = temp_name
            debug_log('materialize stream done temp=%s' % temp_name)
        except Exception as e:
            debug_log('materialize stream failed error=%s' % repr(e))
            raise

    def _is_xz_like_source(self, sourcefile):
        if not sourcefile:
            return False
        source_name = _to_text(sourcefile).lower()
        source_name = source_name.split('?', 1)[0].split('#', 1)[0]
        return source_name.endswith('.xz') or source_name.endswith('.lzma')

    def _download_is_xz(self, filename):
        """Recognize compressed feeds even when the downloader uses a .tmp name."""
        candidates = [filename]
        if self.source is not None:
            candidates.append(getattr(self.source, 'url', None))
            candidates.extend(getattr(self.source, 'urls', None) or [])
        if any(self._is_xz_like_source(candidate) for candidate in candidates):
            return True
        return self._file_is_xz(filename)

    def _file_is_xz(self, filename):
        """Recognize a local XZ/LZMA file without consulting the source URL."""
        if self._is_xz_like_source(filename):
            return True
        try:
            with open(filename, 'rb') as handle:
                return handle.read(6) == b'\xfd7zXZ\x00'
        except Exception:
            return False

    def _download_settings(self, validation=False, sourcefile=None):
        fast_open_source_xz = self.isFastOpenSourceXzRuntime(sourcefile)
        settings = {
            'timeout': 180,
            'retries': 3,
            'connect_timeout': 15,
        }

        if validation:
            settings.update({
                'timeout': 12 if fast_open_source_xz else 20,
                'retries': 1 if fast_open_source_xz else 2,
                'connect_timeout': 5 if fast_open_source_xz else 8,
            })
        elif fast_open_source_xz:
            settings.update({
                'timeout': 180,
                'retries': 2,
                'connect_timeout': 8,
            })

        if self.isOpenSourcePython314PlusRuntime():
            settings['connect_timeout'] = min(settings['connect_timeout'], 5 if validation else 6)

        return settings

    def checkValidServer(self, LastTime, dirname, sourcefile, filename, afterDownload, downloadFail):
        try:
            # LastTime may be bytes on Python 2 or text on Python 3.
            last_time_str = _to_text(LastTime).strip().strip('\n')
            FileDate = datetime.strptime(last_time_str, date_format)
        except ValueError:
            raise Exception('checkValidServer: wrong date format in LastUpdate.txt. Rejecting server: %s' % dirname)
        else:
            delta = (datetime.now() - FileDate).days
            if delta <= alloweddelta:
                print('[EPGImport] checkValidServer accept server: %s' % dirname, file=log)
                return True
            else:
                raise Exception('checkValidServer: invalid delta days. Rejecting server: %s' % dirname)

    def _download_with_system_tools(self, url, filename, timeout_seconds=180, retries=3, connect_timeout=15):
        """Download using wget or curl system tools"""
        print('[EPGImport] Attempting download with system tools: %s (timeout=%s retries=%s connect_timeout=%s)' % (url, timeout_seconds, retries, connect_timeout), file=log)

        try:
            print('[EPGImport] Trying wget for: %s' % url, file=log)
            result = subprocess.call([
                'wget',
                '--timeout=%s' % int(timeout_seconds),
                '--tries=%s' % int(retries),
                '--connect-timeout=%s' % int(connect_timeout),
                '-O',
                filename,
                url
            ])
            if result == 0:
                print('[EPGImport] Download successful using wget', file=log)
                return True
        except Exception as e:
            print('[EPGImport] wget failed or not available: %s' % repr(e), file=log)

        try:
            print('[EPGImport] Trying curl for: %s' % url, file=log)
            result = subprocess.call([
                'curl',
                '--max-time', str(int(timeout_seconds)),
                '--retry', str(int(retries)),
                '--connect-timeout', str(int(connect_timeout)),
                '-L',
                '-o',
                filename,
                url
            ])
            if result == 0:
                print('[EPGImport] Download successful using curl', file=log)
                return True
        except Exception as e:
            print('[EPGImport] curl failed or not available: %s' % repr(e), file=log)

        return False

    def _check_server_validity(self, dirname):
        """Check server validity using wget or curl"""
        cache_key = dirname
        check_url = dirname + '/' + CheckFile
        temp_file = '/tmp/LastUpdate.tmp'
        settings = self._download_settings(validation=True, sourcefile=dirname)

        print('[EPGImport] Checking server validity: %s' % check_url, file=log)

        if not self._download_with_system_tools(
            check_url,
            temp_file,
            timeout_seconds=settings['timeout'],
            retries=settings['retries'],
            connect_timeout=settings['connect_timeout']
        ):
            ServerStatusList[cache_key] = False
            return False

        try:
            with open(temp_file, 'r') as handle:
                last_update = handle.read().strip()

            if not last_update:
                print('[EPGImport] LastUpdate.txt is empty', file=log)
                ServerStatusList[cache_key] = False
                return False

            FileDate = datetime.strptime(last_update, date_format)
            delta = (datetime.now() - FileDate).days

            if delta <= alloweddelta:
                print('[EPGImport] Server is valid (delta: %d days)' % delta, file=log)
                ServerStatusList[cache_key] = True
                return True
            else:
                print('[EPGImport] Server rejected (delta: %d days > allowed %d)' % (delta, alloweddelta), file=log)
                ServerStatusList[cache_key] = False
                return False

        except ValueError as e:
            print('[EPGImport] Invalid date format in LastUpdate.txt: %s' % repr(e), file=log)
            ServerStatusList[cache_key] = False
            return False
        except Exception as e:
            print('[EPGImport] Error checking server validity: %s' % repr(e), file=log)
            ServerStatusList[cache_key] = False
            return False
        finally:
            try:
                os.unlink(temp_file)
            except Exception:
                pass

    def cacheStateChanged(self, state):
        """Handle EPG cache state changes"""
        if cachestate is None:
            return
        if state.state == cachestate.save_finished:
            print('[EPGImport] EPGCache save finished', file=log)
            self.startImport()
        elif state.state == cachestate.load_finished:
            print('[EPGImport] EPGCache load finished', file=log)
            print('[EPGImport] #### Finished ####', file=log)
            try:
                del self.cacheState_conn
            except Exception:
                pass

    def _disconnectActivationCacheState(self):
        """Release a cacheState connection on both old and new Enigma2 APIs."""
        connection = self._activation_cache_conn
        self._activation_cache_conn = None
        if connection is not None:
            disconnect = getattr(connection, 'disconnect', None)
            if callable(disconnect):
                try:
                    disconnect()
                except Exception:
                    pass

    def _cancelActivationWatchdog(self):
        watchdog = self._activation_watchdog
        self._activation_watchdog = None
        if watchdog is not None:
            try:
                if watchdog.active():
                    watchdog.cancel()
            except Exception:
                pass

    def _notifyLiveEpgChanged(self, reason):
        """Tell channel/EPG screens to query the newly active cache again."""
        if hasattr(self.epgcache, 'timeUpdated'):
            try:
                self.epgcache.timeUpdated()
                print('[EPGImport] Live EPG views refreshed (%s)' % reason, file=log)
                return True
            except Exception as refresh_error:
                print('[EPGImport] Live EPG refresh failed (%s): %s' % (reason, repr(refresh_error)), file=log)
        return False

    def _finishCacheActivation(self, reason):
        """Complete one load cycle and refresh all live EPG consumers."""
        if not self._activation_pending:
            return
        label = self._activation_label or 'EPG cache'
        self._activation_pending = False
        self._cancelActivationWatchdog()
        self._disconnectActivationCacheState()
        self._activation_label = None
        self._notifyLiveEpgChanged('%s, %s' % (label, reason))

    def _activationCacheStateChanged(self, state):
        """Wait for the native cache load rather than assuming load() is sync."""
        if cachestate is None:
            return
        try:
            state_value = state.state
        except Exception:
            state_value = state
        if state_value == cachestate.load_finished:
            print('[EPGImport] Native EPG cache load finished', file=log)
            self._finishCacheActivation('load_finished')

    def _activationWatchdogExpired(self):
        """Refresh even on images that expose cacheState but omit load_finished."""
        self._activation_watchdog = None
        if self._activation_pending:
            print('[EPGImport] EPG cache load notification timeout; forcing live view refresh', file=log)
            self._finishCacheActivation('fallback timer')

    def _prepareCacheActivation(self, label):
        """Arm load completion handling before calling the native load API."""
        self._cancelActivationWatchdog()
        self._disconnectActivationCacheState()
        self._activation_pending = True
        self._activation_label = label
        if cachestate is not None and hasattr(self.epgcache, 'cacheState'):
            try:
                self._activation_cache_conn = self.epgcache.cacheState.connect(
                    self._activationCacheStateChanged
                )
                print('[EPGImport] Waiting for native EPG cache load completion: %s' % label, file=log)
            except Exception as connection_error:
                self._activation_cache_conn = None
                print('[EPGImport] cacheState load monitoring unavailable: %s' % repr(connection_error), file=log)

    def _cancelPendingRefreshCalls(self):
        """Cancel any outstanding delayed timeUpdated() calls."""
        calls = self._pending_refresh_calls
        self._pending_refresh_calls = []
        for call in calls:
            try:
                if call is not None and call.active():
                    call.cancel()
            except Exception:
                pass

    def _scheduleDelayedRefresh(self, delays_seconds, reason):
        """Refresh views after asynchronous cache writes/loads."""
        self._cancelPendingRefreshCalls()
        for delay in delays_seconds:
            try:
                call = reactor.callLater(delay, self._doDelayedRefresh, reason, delay)
                self._pending_refresh_calls.append(call)
            except Exception as sched_err:
                print('[EPGImport] Could not schedule delayed refresh at %ss: %s' % (delay, repr(sched_err)), file=log)

    def _doDelayedRefresh(self, reason, delay):
        """Execute one delayed live-view refresh and remove it from the list."""
        self._pending_refresh_calls = [
            c for c in self._pending_refresh_calls
            if c is not None and c.active()
        ]
        if self._notifyLiveEpgChanged('%s, delayed +%ss' % (reason, delay)):
            print('[EPGImport] Delayed live EPG refresh fired (+%ss, %s)' % (delay, reason), file=log)

    def _cacheLoadInvoked(self):
        """Finish synchronous loads now; guard asynchronous loads with timeout."""
        if not self._activation_pending:
            return
        if self._activation_cache_conn is None:
            # Older images lack cacheState, so cover slow cache rebuilds.
            label = self._activation_label or 'EPG cache'
            self._finishCacheActivation('load returned (no cacheState)')
            self._scheduleDelayedRefresh([1, 3, 8], '%s delayed refresh' % label)
        else:
            # The watchdog covers vendor builds that never emit load_finished.
            self._activation_watchdog = reactor.callLater(10, self._activationWatchdogExpired)
            self._scheduleDelayedRefresh([2, 5, 10], 'DreamOS cacheState path delayed refresh')


    def _abortCacheActivation(self):
        self._activation_pending = False
        self._activation_label = None
        self._cancelActivationWatchdog()
        self._disconnectActivationCacheState()
        self._cancelPendingRefreshCalls()

    def saveEPGCache(self):
        """Save EPG cache to file"""
        if self.isDreamRuntime() and isDreamOS and hasattr(self.epgcache, 'cacheState') and cachestate is not None:
            try:
                self.cacheState_conn = self.epgcache.cacheState.connect(self.cacheStateChanged)
            except Exception:
                pass
        if config is not None and getattr(config, 'misc', None) is not None and hasattr(config.misc, 'epgcache_filename'):
            print('[EPGImport] Save the EPG cache to database file %s ...' % config.misc.epgcache_filename.value, file=log)
        self.epgcache.save()

    def beginImport(self, longDescUntil=None):
        """Starts importing using Enigma reactor. Set self.sources before calling this."""
        debug_log('beginImport entered longDescUntil=%s sources=%s runtime=%s' % (longDescUntil, len(self.sources), repr(self.runtime_profile)), reset=True)
        self._do_read_debug_counter = 0
        try:
            ServerStatusList.clear()
        except Exception:
            pass
        if hasattr(self.epgcache, 'importEvents'):
            self.storage = self.epgcache
        elif hasattr(self.epgcache, 'importEvent'):
            self.storage = OudeisImporter(self.epgcache)
        elif hasattr(self.epgcache, 'load'):
            print('[EPGImport] Oudeis patch not detected, using eEPGCache.load', file=log)
            try:
                from . import epgdat_importer
            except ImportError:
                import epgdat_importer
            self.storage = epgdat_importer.epgdatclass()
        else:
            print('[EPGImport] No supported EPG import methods found. EPG import not possible', file=log)
            return

        if self.usesLegacyDreamEventLogic():
            print('[EPGImport] Event logic: legacy Dreambox Python 2.7 / epg.db', file=log)
        elif self.usesLegacyOpenSourceEventLogic():
            print('[EPGImport] Event logic: legacy Open Source / epg.dat (Python %s)' % self.runtime_profile.get('python_version'), file=log)
        else:
            print('[EPGImport] Event logic: modern DreamOS fallback', file=log)

        self.longDescUntil = time() + 24 * 3600 * 7 if longDescUntil is None else longDescUntil
        self.eventCount = 0
        self.duplicateEventCount = 0
        self._event_batch_services = None
        self._event_batch_data = []
        self._rating_supported = True
        self._seen_event_keys = set()
        self.startTime = datetime.now()
        self.nextImport()

    def startImport(self):
        """Start the import process"""
        self.eventCount = 0
        self.duplicateEventCount = 0
        self._event_batch_services = None
        self._event_batch_data = []
        self._rating_supported = True
        self._seen_event_keys = set()
        self.startTime = datetime.now()
        self.nextImport()

    def nextImport(self):
        """Process next import source"""
        self._flushEventBatch()
        self.closeReader()
        if not self.sources:
            self.closeImport()
            return

        self.source = self.sources.pop()
        debug_log('nextImport picked source=%s url=%s parser=%s' % (getattr(self.source, 'description', 'n/a'), getattr(self.source, 'url', 'n/a'), getattr(self.source, 'parser', 'n/a')))
        print('[EPGImport] ### start import, source = "%s"' % self.source.description, file=log)
        self.fetchUrl(self.source.url)

    def fetchUrl(self, filename):
        """Fetch URL or local file"""
        debug_log('fetchUrl entered filename=%s' % filename)
        if isLocalFile(filename):
            print('[EPGImport] Local file used: %s' % filename, file=log)
            debug_log('fetchUrl using local file=%s' % filename)
            self.afterDownload(None, filename, deleteFile=False)
        else:
            self.do_download(filename, self.afterDownload, self.downloadFail)

    def getContent(self, response, *args):
        if readBody is None:
            raise Exception('Twisted Web client is not available on this image/runtime')
        if response.code != 200:
            raise Exception('Invalid server response code received: %s' % response.code)
        d = readBody(response)
        d.addCallback(self.writeFile if len(args) < 4 else self.checkValidServer, *args)
        d.addErrback(lambda e: args[-1](repr(e)))
        return d

    def writeFile(self, data, filename, afterDownload, downloadFail):
        try:
            with open(filename, 'wb') as fd:
                fd.write(data)
        except Exception as e:
            raise Exception('unable write data to %s: %s' % (filename, repr(e)))
        else:
            afterDownload(None, filename, True)

    def createIterator(self, filename):
        """
        Create validated iterator for parsing EPG data.

        Event tuples from xmltvconverter
        can have 4, 6, 7, or 8 fields depending on isDreamOS and rating presence:
          - Open source, no rating:   (start, dur, title, subtitle, desc, type)        = 6
          - Open source, with rating: (start, dur, title, subtitle, desc, type, 0, r)  = 8
          - DreamOS, no rating:       (start, dur, title, subtitle, desc, type, lang)  = 7
          - DreamOS, with rating:     (start, dur, title, subtitle, desc, type, lang, r) = 8
        Minimum valid tuple requires at least start, duration, title, subtitle = 4 fields.
        Four-field tuples are valid for basic EPG entries.
        """
        parser = getParser(self.source.parser)
        iterator = parser.iterator(self.fd, self.source.channels.items, getattr(self.source, 'offset', 0))

        # Add data validation wrapper safely for all systems
        def validated_iterator():
            for data in iterator:
                if data and len(data) == 2:
                    channel_ref, event_data = data
                    # Basic EPG entries may contain only four fields.
                    if len(event_data) >= 4:
                        yield data
                    else:
                        print('[EPGImport] Skipping invalid event for %s: only %d data fields' % (str(channel_ref), len(event_data)), file=log)
                else:
                    print('[EPGImport] Skipping malformed data: %s' % str(data), file=log)

        return validated_iterator()

    def _callOnReactorAndWait(self, function, *args):
        """Run an Enigma2 native call on the reactor and wait in the worker."""
        completed_event = threading.Event()
        failure = []

        def invoke():
            try:
                function(*args)
            except Exception as error:
                failure.append(error)
            finally:
                completed_event.set()

        reactor.callFromThread(invoke)
        if not completed_event.wait(30):
            raise Exception('Timed out waiting for Enigma2 reactor call')
        if failure:
            raise failure[0]

    def readEpgDatFile(self, filename, deleteFile=False, marshal_native_calls=False):
        """Read and import EPG.DAT file"""
        if not hasattr(self.epgcache, 'load'):
            print('[EPGImport] Cannot load EPG.DAT files on unpatched enigma, eEPGCache.load required', file=log)
            return

        if self.isDreamRuntime():
            print('[EPGImport] Refusing binary epg.dat on DreamOS; native epg.db is required', file=log)
            return

        target_epg_path = get_active_epg_dat_path(self.runtime_profile)
        temporary_target = target_epg_path + '.epgimport.tmp'
        try:
            unlink_if_exists(temporary_target)
            fd = openStream(filename)
            with fd as fsrc, open(temporary_target, 'wb') as fdst:
                copyfileobj(fsrc, fdst)
            if not self._is_valid_epg_dat(temporary_target):
                raise Exception('Downloaded file is not a valid epg.dat')
            os.rename(temporary_target, target_epg_path)
            print('[EPGImport] Importing %s' % target_epg_path, file=log)
            if self.isOpenSourceRuntime():
                extra_targets = self._install_open_source_epg_targets(target_epg_path)
                if extra_targets:
                    print('[EPGImport] Open source extra EPG targets: %s' % ', '.join(extra_targets), file=log)
            if marshal_native_calls:
                self._callOnReactorAndWait(self.epgcache.load)
            else:
                self.epgcache.load()
            if deleteFile:
                unlink_if_exists(filename)
        except Exception as e:
            unlink_if_exists(temporary_target)
            print('[EPGImport] Failed to import %s:' % filename, repr(e), file=log)

    def do_download(self, sourcefile, afterDownload, downloadFail):
        # Reject malformed sources before parsing their URL scheme.
        if not sourcefile:
            downloadFail('do_download: empty or None URL for source: %s' % getattr(self.source, 'description', 'unknown'))
            return
        scheme = sourcefile.split('/')[0]
        if scheme not in ('http:', 'https:', 'ftp:', 'file:'):
            downloadFail('Unsupported scheme: %s' % scheme)
            return

        if self.isDreamRuntime():
            path = bigStorage(9000000, '/tmp', '/media/DOMExtender', '/media/cf', '/media/mmc', '/media/usb', '/media/hdd')
            filename = join(path, 'epgimport')
            ext = splitext(sourcefile)[1]
            if ext and len(ext) < 6:
                filename += ext
        else:
            path = bigStorage(9000000, '/tmp', '/media/cf', '/media/mmc', '/media/usb', '/media/hdd')
            filename = join(path, 'epgimport.tmp')

        if version_info[0] < 3 and isinstance(sourcefile, unicode):
            sourcefile = sourcefile.encode('utf-8')

        dirname, _unused = split(sourcefile)
        print('[EPGImport] Downloading: %s to local path: %s' % (sourcefile, filename), file=log)
        fast_open_source_xz = self.isFastOpenSourceXzRuntime(sourcefile)
        download_settings = self._download_settings(validation=False, sourcefile=sourcefile)
        validation_required = self.source.nocheck != 1 and not fast_open_source_xz

        def _download_thread_job():
            if not self.source:
                return False
            if self.source.nocheck == 1:
                print('[EPGImport] Not checking the server since nocheck is set for: %s' % sourcefile, file=log)
                if self._download_with_system_tools(sourcefile, filename, timeout_seconds=download_settings['timeout'], retries=download_settings['retries'], connect_timeout=download_settings['connect_timeout']):
                    return True
                return False
            elif fast_open_source_xz:
                # Fast path reference:
                # Open-source Enigma2 images running Python 3.12+ skip the slow
                # LastUpdate.txt pre-check for XZ/LZMA feeds and download directly.
                # Python 3.14+ uses an even lower connect timeout for faster startup.
                print('[EPGImport] Fast open-source XZ path enabled for Python >= 3.12: skipping LastUpdate pre-check for %s' % sourcefile, file=log)
                if self.isOpenSourcePython314PlusRuntime():
                    print('[EPGImport] Python 3.14+ open-source runtime detected, using aggressive connect timeout optimisation', file=log)
                if self._download_with_system_tools(sourcefile, filename, timeout_seconds=download_settings['timeout'], retries=download_settings['retries'], connect_timeout=download_settings['connect_timeout']):
                    ServerStatusList[dirname] = True
                    return True
                else:
                    ServerStatusList[dirname] = False
                    return False
            else:
                print('[EPGImport] Checking server validity for: %s' % sourcefile, file=log)
                if validation_required and self._check_server_validity(dirname):
                    if self._download_with_system_tools(sourcefile, filename, timeout_seconds=download_settings['timeout'], retries=download_settings['retries'], connect_timeout=download_settings['connect_timeout']):
                        return True
                return False

        def _download_thread_callback(success):
            if not self.source:
                return
            if success:
                afterDownload(None, filename, True)
            else:
                downloadFail('Failed to download file or validation failed: %s' % sourcefile)

        if twisted.python.runtime.platform.supportsThreads():
            d = threads.deferToThread(_download_thread_job)
            d.addCallback(_download_thread_callback)
            d.addErrback(lambda failure: downloadFail('Download worker failed: %s' % repr(failure)))
        else:
            _download_thread_callback(_download_thread_job())

    def _decompressXzToTemp(self, filename):
        """Decompress an XZ feed in a worker thread using bounded memory."""
        temp_fd, temp_path = tempfile.mkstemp(suffix='.xml', prefix='epgimport_')
        os.close(temp_fd)
        try:
            try:
                with open(temp_path, 'wb') as outfd:
                    with tempfile.TemporaryFile() as errfd:
                        result = subprocess.call(
                            ['xz', '-d', '-k', '-c', filename],
                            stdout=outfd,
                            stderr=errfd
                        )
                if result != 0:
                    raise Exception('System xz command failed with code: %d' % result)
            except Exception as sys_err:
                debug_log('XZ system decompressor failed, using lzma: %s' % repr(sys_err))
                if lzma is None:
                    raise Exception('lzma module not available and system xz command failed')
                with lzma.open(filename, 'rb') as compressed:
                    with open(temp_path, 'wb') as decompressed:
                        copyfileobj(compressed, decompressed, 1024 * 1024)
            return temp_path
        except Exception:
            unlink_if_exists(temp_path)
            raise

    def _afterXzDecompressed(self, temp_path, filename, deleteFile):
        if not self.source:
            unlink_if_exists(temp_path)
            return
        self._temp_decompressed_file = temp_path
        self.fd = open(temp_path, 'rb')
        debug_log('asynchronous xz decompression ready temp=%s' % temp_path)
        self._finishAfterDownloadOpen(filename, deleteFile)

    def _afterXzDecompressionFailed(self, failure, filename):
        self.downloadFail('XZ decompression failed for %s: %s' % (filename, repr(failure)))

    def _finishAfterDownloadOpen(self, filename, deleteFile):
        if deleteFile and self.source.parser != 'epg.dat':
            print('[EPGImport] unlink %s' % filename, file=log)
            unlink_if_exists(filename)

        self.channelFiles = self.source.channels.downloadables()
        if not self.channelFiles:
            self.afterChannelDownload(None, None, deleteFile=False)
        else:
            filename = self._pop_next_channel_file()
            self.do_download(filename, self.afterChannelDownload, self.channelDownloadFail)

    def afterDownload(self, result, filename, deleteFile=False):
        debug_log('afterDownload entered filename=%s deleteFile=%s' % (filename, deleteFile))
        print('[EPGImport] afterDownload %s' % filename, file=log)

        if self.source.parser == 'epg.dat':
            if twisted.python.runtime.platform.supportsThreads():
                print('[EPGImport] Using worker thread for DAT file preparation', file=log)
                d = threads.deferToThread(self.readEpgDatFile, filename, deleteFile, True)
                d.addCallback(self._threadDatDone)
                d.addErrback(self._threadOperationFailed, 'DAT import')
                return
            self.readEpgDatFile(filename, deleteFile)
            self.nextImport()
            return

        self._force_inline_xz_import = False
        if self._download_is_xz(filename):
            if self.isDreamPython27Runtime():
                self._force_inline_xz_import = True
            if twisted.python.runtime.platform.supportsThreads():
                d = threads.deferToThread(self._decompressXzToTemp, filename)
                d.addCallback(self._afterXzDecompressed, filename, deleteFile)
                d.addErrback(self._afterXzDecompressionFailed, filename)
                return
            try:
                temp_path = self._decompressXzToTemp(filename)
                self._afterXzDecompressed(temp_path, filename, deleteFile)
            except Exception as e:
                self._afterXzDecompressionFailed(e, filename)
            return

        try:
            self.fd = openStream(filename)
            debug_log('afterDownload openStream ok type=%s has_fileno=%s' % (self.fd.__class__.__name__, self._stream_has_fileno()))
            if not self._stream_has_fileno():
                self._materialize_stream_for_reader()
        except Exception as e:
            self.downloadFail('%s' % repr(e))
            return
        self._finishAfterDownloadOpen(filename, deleteFile)

    def _threadDatDone(self, _ignored=None):
        self.nextImport()

    def _threadOperationFailed(self, failure, operation):
        print('[EPGImport] %s failed: %s' % (operation, repr(failure)), file=log)
        self.nextImport()

    def _pop_next_channel_file(self):
        if not self.channelFiles:
            return None
        if self.isDreamRuntime():
            filename = random.choice(self.channelFiles)
            self.channelFiles.remove(filename)
            return filename
        return self.channelFiles.pop()

    def _continue_after_current_file(self):
        # Do not leave the final (possibly smaller) batch pending when a large
        # source file ends or when switching channel mapping files.
        self._flushEventBatch()
        filename = self._pop_next_channel_file()
        if filename is not None:
            self.do_download(filename, self.afterChannelDownload, self.channelDownloadFail)
        else:
            self.nextImport()

    def _install_open_source_epg_targets(self, source_path):
        """Install a completed epg.dat without exposing a partial/dangling file."""
        if not self._is_valid_epg_dat(source_path):
            raise Exception('Refusing to activate an incomplete EPG file: %s' % source_path)

        installed_targets = []
        for target_path in get_open_source_epg_targets(self.runtime_profile):
            if not target_path or target_path == source_path:
                continue
            try:
                # A symlink to the temporary epg_new.dat becomes broken as soon
                # as that source is cleaned up.  Copy beside the destination and
                # rename only after the complete file is safely closed.
                temporary_target = target_path + '.epgimport.tmp'
                unlink_if_exists(temporary_target)
                copy2(source_path, temporary_target)
                if not self._is_valid_epg_dat(temporary_target):
                    raise Exception('temporary EPG copy failed validation')
                os.rename(temporary_target, target_path)
            except Exception as e:
                try:
                    unlink_if_exists(target_path + '.epgimport.tmp')
                except Exception:
                    pass
                print('[EPGImport] open source target install failed %s: %s' % (target_path, repr(e)), file=log)
                continue
            installed_targets.append(target_path)
        return installed_targets

    @staticmethod
    def _is_valid_epg_dat(filename):
        """Check the binary header before asking Enigma2 to replace its cache."""
        try:
            if not filename or not exists(filename) or getsize(filename) < 21:
                return False
            with open(filename, 'rb') as epg_file:
                header = epg_file.read(17)
            return header[4:17] in (b'ENIGMA_EPG_V7', b'ENIGMA_EPG_V8')
        except Exception:
            return False

    def downloadFail(self, failure):
        print('[EPGImport] download failed: %s' % failure, file=log)
        if hasattr(self.source, 'urls') and self.source.urls:
            try:
                if self.source.url in self.source.urls:
                    self.source.urls.remove(self.source.url)
            except Exception:
                pass
            if self.source.urls:
                print('[EPGImport] Attempting alternative URL', file=log)
                self.source.url = random.choice(self.source.urls)
                self.fetchUrl(self.source.url)
                return
        self.nextImport()

    def afterChannelDownload(self, result, filename, deleteFile=True):
        """Callback after channel download completion"""
        debug_log('afterChannelDownload entered filename=%s deleteFile=%s has_fileno=%s' % (filename, deleteFile, self._stream_has_fileno()))
        print('[EPGImport] afterChannelDownload %s' % filename, file=log)
        if not self.source:
            return

        # Python 2 cElementTree cannot consume an LZMAFile object directly.
        # Materialize compressed channel maps in a worker before parsing them.
        if filename is not None and self._file_is_xz(filename):
            if twisted.python.runtime.platform.supportsThreads():
                d = threads.deferToThread(self._decompressXzToTemp, filename)
                d.addCallback(self._afterChannelXzDecompressed, filename, deleteFile)
                d.addErrback(self._afterChannelXzDecompressionFailed, filename, deleteFile)
                return
            try:
                temp_path = self._decompressXzToTemp(filename)
                self._afterChannelXzDecompressed(temp_path, filename, deleteFile)
            except Exception as e:
                self._afterChannelXzDecompressionFailed(e, filename, deleteFile)
            return

        if filename is not None:
            try:
                if not getsize(filename):
                    raise Exception('File is empty')
            except Exception as e:
                self.channelDownloadFail(repr(e))
                return

        try:
            self.source.channels.update(self.channelFilter, filename)
        except Exception as e:
            print('[EPGImport] Error updating channels: %s' % e, file=log)

        if self.fd is None:
            print('[EPGImport] Error: self.fd is None, cannot process EPG data', file=log)
            self.nextImport()
            return

        if self.supportsThreadedParser():
            print('[EPGImport] ### using threaded parser path ###', file=log)
            debug_log('afterChannelDownload using threaded parser path')
            d = threads.deferToThread(self.doThreadRead, filename)
            d.addCallback(self._threadChannelDone)
            d.addErrback(self._threadOperationFailed, 'XMLTV parser')
            deleteFile = False
        elif self._force_inline_xz_import:
            print('[EPGImport] ### using inline dream xz parser path ###', file=log)
            debug_log('afterChannelDownload using inline dream xz parser path')
            self.startInlineRead(filename)
            deleteFile = False
        else:
            print('[EPGImport] ### using reader parser path ###', file=log)
            debug_log('afterChannelDownload using reader parser path')
            self._do_read_debug_counter = 0
            self.iterator = self.createIterator(filename)
            reactor.addReader(self)

        if deleteFile and filename is not None:
            unlink_if_exists(filename)

    def _afterChannelXzDecompressed(self, temp_path, filename, deleteFile):
        if not self.source:
            unlink_if_exists(temp_path)
            if deleteFile:
                unlink_if_exists(filename)
            return
        debug_log('channel xz decompression ready temp=%s' % temp_path)
        if deleteFile:
            unlink_if_exists(filename)
        self.afterChannelDownload(None, temp_path, deleteFile=True)

    def _afterChannelXzDecompressionFailed(self, failure, filename, deleteFile):
        if deleteFile:
            unlink_if_exists(filename)
        self.channelDownloadFail('Channel XZ decompression failed for %s: %s' % (filename, repr(failure)))

    def fileno(self):
        if self.fd is not None:
            return self.fd.fileno()
        return -1

    def _flushEventBatch(self):
        """Send queued complete events to the backend and release their memory."""
        if not self._event_batch_data or self.storage is None:
            return

        services = self._event_batch_services
        events = tuple(self._event_batch_data)
        self._event_batch_services = None
        self._event_batch_data = []

        try:
            self.storage.importEvents(services, events)
        except Exception:
            # Some open-source images reject the optional rating fields. Retry
            # the complete batch using the standard six-field event format.
            if (not self.isDreamRuntime() and self._rating_supported and
                    any(len(event) > 6 for event in events)):
                print('[EPGImport] OpenSource eEPGCache extended tuple rejected, stripping rating...', file=log)
                self._rating_supported = False
                self.storage.importEvents(services, tuple(event[:6] for event in events))
            else:
                raise

    def _queueEvent(self, services, event):
        """Queue one intact event, flushing only between bounded batches."""
        if self._event_batch_data and services != self._event_batch_services:
            self._flushEventBatch()

        if not self._event_batch_data:
            self._event_batch_services = services

        if not self.isDreamRuntime() and not self._rating_supported and len(event) > 6:
            event = event[:6]
        self._event_batch_data.append(event)

        if len(self._event_batch_data) >= self.EVENT_IMPORT_BATCH_SIZE:
            self._flushEventBatch()

    def importEvents(self, data):
        if data is None:
            return

        # Keep the low-memory version-3.5 event path on Dreambox/Python 2.7.
        if self.usesLegacyDreamEventLogic():
            try:
                service_refs, event = data
                channel_id = _get_channel_identity(service_refs)
                try:
                    services = sorted(list(service_refs))
                except Exception:
                    try:
                        services = list(service_refs)
                    except Exception:
                        services = [service_refs] if isinstance(service_refs, _string_types) else service_refs

                if _stop_duplicates_sources_enabled():
                    services = _attach_channel_identity(services, channel_id)

                if len(event) >= 5 and event[0] > self.longDescUntil:
                    event = event[:4] + ('',) + event[5:]
                self.storage.importEvents(services, (event,))
                self.eventCount += 1
            except Exception as e:
                traceback.print_exc()
                print('[EPGImport] ### Dreambox Python 2.7 importEvents exception: %s' % repr(e), file=log)
            return

        # Preserve version-3.5 event semantics on open-source images.
        if self.usesLegacyOpenSourceEventLogic():
            try:
                service_refs, event = data
                channel_id = _get_channel_identity(service_refs)
                try:
                    services = sorted(list(service_refs))
                except Exception:
                    try:
                        services = list(service_refs)
                    except Exception:
                        services = [service_refs] if isinstance(service_refs, _string_types) else service_refs

                if _stop_duplicates_sources_enabled():
                    services = _attach_channel_identity(services, channel_id)

                if not self._rating_supported and len(event) > 6:
                    event = event[:6]
                prepared_event = (
                    event[:4] + ('',) + event[5:]
                    if len(event) >= 5 and event[0] > self.longDescUntil
                    else event
                )
                try:
                    self.storage.importEvents(services, (prepared_event,))
                except Exception:
                    if self._rating_supported and len(event) > 6:
                        print('[EPGImport] OpenSource eEPGCache extended tuple rejected, stripping rating...', file=log)
                        self._rating_supported = False
                        event = event[:6]
                        prepared_event = (
                            event[:4] + ('',) + event[5:]
                            if len(event) >= 5 and event[0] > self.longDescUntil
                            else event
                        )
                        self.storage.importEvents(services, (prepared_event,))
                    else:
                        raise
                self.eventCount += 1
            except Exception as e:
                traceback.print_exc()
                print('[EPGImport] ### OpenSource legacy importEvents exception: %s' % repr(e), file=log)
            return

        try:
            service_refs, event = data
            channel_id = _get_channel_identity(service_refs)

            try:
                services = sorted(list(service_refs))
            except Exception:
                try:
                    services = list(service_refs)
                except Exception:
                    services = [service_refs] if isinstance(service_refs, _string_types) else service_refs

            stop_duplicates = _stop_duplicates_sources_enabled()
            if stop_duplicates:
                services = _attach_channel_identity(services, channel_id)

                event_key = _digest_event_duplicate_key(
                    _build_event_duplicate_key(services, event)
                )
                if event_key in self._seen_event_keys:
                    self.duplicateEventCount += 1
                    return
                self._seen_event_keys.add(event_key)

            if len(event) >= 5 and event[0] > self.longDescUntil:
                event = event[:4] + ('',) + event[5:]

            self._queueEvent(services, event)
            self.eventCount += 1
        except Exception as e:
            traceback.print_exc()
            print('[EPGImport] ### importEvents exception: %s' % repr(e), file=log)

    def channelDownloadFail(self, failure):
        print('[EPGImport] download channel failed: %s' % failure, file=log)
        if self.channelFiles:
            filename = self._pop_next_channel_file()
            self.do_download(filename, self.afterChannelDownload, self.channelDownloadFail)
        else:
            print('[EPGImport] no more alternatives for channels', file=log)
            self.nextImport()

    def _importThreadBatch(self, batch, completed_event):
        """Import a parser batch on the Enigma2 reactor thread."""
        try:
            for data in batch:
                self.importEvents(data)
        finally:
            completed_event.set()

    def _storageRequiresReactor(self):
        """Native Enigma2 cache bindings must only run on the reactor thread."""
        return self.storage is self.epgcache or isinstance(self.storage, OudeisImporter)

    def doThreadRead(self, filename):
        """Parse in a worker, while all Enigma2 cache calls stay on the UI thread."""
        debug_log('doThreadRead start filename=%s' % filename)
        if not self._storageRequiresReactor():
            for data in self.createIterator(filename):
                self.importEvents(data)
            print('### thread finished, source = "%s", events imported: %s' % (self.source.description, self.eventCount), file=log)
            if filename is not None:
                unlink_if_exists(filename)
            return

        batch = []
        for data in self.createIterator(filename):
            batch.append(data)
            if len(batch) >= self.THREAD_DELIVERY_BATCH_SIZE:
                completed_event = threading.Event()
                reactor.callFromThread(self._importThreadBatch, batch, completed_event)
                if not completed_event.wait(30):
                    raise Exception('Timed out delivering parsed EPG events to reactor')
                batch = []
        if batch:
            completed_event = threading.Event()
            reactor.callFromThread(self._importThreadBatch, batch, completed_event)
            if not completed_event.wait(30):
                raise Exception('Timed out delivering final EPG events to reactor')
        print('### thread finished, source = "%s", events imported: %s' % (self.source.description, self.eventCount), file=log)
        if filename is not None:
            unlink_if_exists(filename)

    def startInlineRead(self, filename):
        """Dreambox Python 2.7 path for XZ/LZMA sources with chunked UI updates."""
        debug_log('startInlineRead start filename=%s' % filename)
        try:
            self.iterator = self.createIterator(filename)
            self._inline_read_filename = filename
            self._scheduleInlineRead(0)
        except Exception as e:
            print('[EPGImport] Error in startInlineRead: %s' % e, file=log)
            self.nextImport()

    def _scheduleInlineRead(self, delay=0):
        try:
            self._inline_read_call = reactor.callLater(delay, self.doInlineReadChunk)
        except Exception:
            self._inline_read_call = None
            self.doInlineReadChunk()

    def doInlineReadChunk(self):
        debug_log('doInlineReadChunk entered')
        self._inline_read_call = None
        processed = 0
        chunk_size = 250
        try:
            while processed < chunk_size:
                data = self.iterator.__next__() if PY3 else self.iterator.next()
                self.importEvents(data)
                processed += 1
            self._scheduleInlineRead(0)
        except StopIteration:
            print('[EPGImport] ### inline iterator finished, source = "%s", events imported: %s' % (self.source.description, self.eventCount), file=log)
            if self._inline_read_filename is not None:
                unlink_if_exists(self._inline_read_filename)
            self._inline_read_filename = None
            self.iterator = None
            self._continue_after_current_file()
        except Exception as e:
            print('[EPGImport] Error in doInlineReadChunk: %s' % e, file=log)
            self._inline_read_filename = None
            self.iterator = None
            self.nextImport()

    def _threadChannelDone(self, _ignored=None):
        """Continue with next channel file (threaded mode) or move to next import"""
        try:
            self._continue_after_current_file()
        except Exception as e:
            print('[EPGImport] _threadChannelDone exception: %s' % repr(e), file=log)
            self.nextImport()

    def doRead(self):
        """called from reactor to read some data"""
        self._do_read_debug_counter += 1
        if self._do_read_debug_counter == 1 or self._do_read_debug_counter % 500 == 0:
            debug_log('doRead progress calls=%s events=%s source=%s' % (
                self._do_read_debug_counter,
                self.eventCount,
                getattr(self.source, 'description', 'n/a')
            ))
        try:
            data = self.iterator.__next__() if PY3 else self.iterator.next()
            self.importEvents(data)
        except StopIteration:
            print('[EPGImport] ### iterator finished, source = "%s", events imported: %s' % (self.source.description, self.eventCount), file=log)
            self._continue_after_current_file()
        except Exception as e:
            print('[EPGImport] Error in doRead: %s' % e, file=log)
            self.nextImport()

    def connectionLost(self, failure):
        """called from reactor on lost connection"""
        print('[EPGImport] connectionLost %s' % failure, file=log)

    def logPrefix(self):
        return '[EPGImport]'

    def closeReader(self):
        debug_log('closeReader entered')
        if self._inline_read_call is not None:
            try:
                if self._inline_read_call.active():
                    self._inline_read_call.cancel()
            except Exception:
                pass
            self._inline_read_call = None
        if self.fd is not None:
            # Detach from the reactor before closing the descriptor.
            try:
                reactor.removeReader(self)
            except Exception:
                pass
            try:
                self.fd.close()
            except Exception:
                pass
            self.fd = None
            self.iterator = None
        if self._reader_temp_filename and exists(self._reader_temp_filename):
            try:
                unlink_if_exists(self._reader_temp_filename)
            except Exception:
                pass
            self._reader_temp_filename = None
        if self._temp_decompressed_file and exists(self._temp_decompressed_file):
            try:
                unlink_if_exists(self._temp_decompressed_file)
            except Exception:
                pass
            self._temp_decompressed_file = None
        self._inline_read_filename = None
        self._force_inline_xz_import = False
        return

    def closeImport(self):
        """Close import and clean up resources"""
        debug_log('closeImport entered eventCount=%s' % self.eventCount)
        try:
            self._flushEventBatch()
        except Exception as e:
            print('[EPGImport] Failed to flush final event batch: %s' % repr(e), file=log)
        # Duplicate fingerprints are no longer needed once parsing has ended;
        # release them before the backend builds its final large output file.
        self._seen_event_keys.clear()
        self.iterator = None
        self.source = None
        if hasattr(self.storage, 'epgfile'):
            needLoad = self.storage.epgfile
        else:
            needLoad = None

        storage = self.storage
        if (hasattr(storage, 'epg_done') and not self.isDreamRuntime() and
                twisted.python.runtime.platform.supportsThreads()):
            self._is_finalizing = True
            self.storage = None
            deferred = threads.deferToThread(storage.epg_done)
            deferred.addCallback(self._storageFinalized, needLoad)
            deferred.addErrback(self._storageFinalizationFailed, needLoad)
            return

        if hasattr(storage, 'epg_done'):
            try:
                storage.epg_done()
            except Exception as e:
                print('[EPGImport] Failed to finalize EPG storage: %s' % repr(e), file=log)
                self._abortImportActivation()
                return
        self.storage = None
        self._completeCloseImport(needLoad)

    def _storageFinalized(self, _result, needLoad):
        self._completeCloseImport(needLoad)

    def _storageFinalizationFailed(self, failure, needLoad):
        print('[EPGImport] Failed to finalize EPG storage: %s' % repr(failure), file=log)
        self._abortImportActivation()

    def _abortImportActivation(self):
        """End a failed import without replacing the currently visible EPG."""
        # Restore a backend backup when available; never load a partial cache.
        try:
            storage = self.storage
            if storage is not None and callable(getattr(storage, 'restore_backup', None)):
                restored = storage.restore_backup()
                if restored:
                    print('[EPGImport] Previous EPG database restored after import failure', file=log)
        except Exception as _restore_err:
            print('[EPGImport] restore_backup failed: %s' % repr(_restore_err), file=log)
        self.storage = None
        self.eventCount = None
        self._seen_event_keys.clear()
        self._is_finalizing = False
        self._abortCacheActivation()
        self._cancelPendingRefreshCalls()
        print('[EPGImport] Import activation aborted; previous EPG kept active', file=log)
        print('[EPGImport] #### Finished with errors ####', file=log)
        # Let the caller reset timers and finish any post-import action.
        if self.onDone:
            try:
                self.onDone(reboot=False, epgfile=None)
            except Exception as _abort_done_err:
                print('[EPGImport] onDone callback failed after abort: %s' % repr(_abort_done_err), file=log)

    def _completeCloseImport(self, needLoad):
        """Complete cache activation on the Enigma2 reactor thread."""
        use_dream_epgdb = bool(needLoad) and str(needLoad).lower().endswith('.db')
        active_epg_path = get_active_epg_dat_path(self.runtime_profile)
        if self.eventCount is not None:
            reboot = False
            if self.isDreamRuntime():
                # DreamOS uses native epg.db or the Oudeis direct importer.
                print('[EPGImport] imported %d events' % self.eventCount, file=log)
                if self.duplicateEventCount:
                    print('[EPGImport] skipped %d duplicate events' % self.duplicateEventCount, file=log)
                if self.eventCount:
                    if use_dream_epgdb:
                        print('[EPGImport] DreamOS epg.db import finalized in native database path: %s' % needLoad, file=log)
                        # final_process() has already loaded the database.
                        reboot = False
                    elif needLoad:
                        # Never activate an open-source epg.dat on DreamOS.
                        print('[EPGImport] DreamOS refused unexpected non-DB EPG backend: %s' % needLoad, file=log)
                        self._abortCacheActivation()
                        self._notifyLiveEpgChanged('DreamOS backend guard')
                        reboot = False
                    elif hasattr(self.epgcache, 'save'):
                        # DreamOS saves asynchronously; refresh across its write window.
                        self.epgcache.save()
                        self._notifyLiveEpgChanged('DreamOS direct import path')
                        self._scheduleDelayedRefresh(
                            [1, 3, 8],
                            'DreamOS direct save completion'
                        )
                elif hasattr(self.epgcache, 'timeUpdated'):
                    self._notifyLiveEpgChanged('DreamOS import contained no events')
            elif use_dream_epgdb:
                # Never copy SQLite epg.db over binary epg.dat targets.
                print('[EPGImport] Native epg.db finalized at %s; skipped epg.dat installation' % needLoad, file=log)
                reboot = False
                self._notifyLiveEpgChanged('native epg.db guard')
            else:
                # Open-source images use validated epg.dat or direct imports.
                print('[EPGImport] imported %d events' % self.eventCount, file=log)
                if self.duplicateEventCount:
                    print('[EPGImport] skipped %d duplicate events' % self.duplicateEventCount, file=log)
                if needLoad:
                    reboot = False
                    try:
                        installed_targets = self._install_open_source_epg_targets(needLoad)
                        if needLoad != active_epg_path and active_epg_path not in installed_targets:
                            raise Exception('Active EPG path was not installed safely: %s' % active_epg_path)
                        print('[EPGImport] Open source load target: %s' % active_epg_path, file=log)
                        if installed_targets:
                            print('[EPGImport] Open source installed targets: %s' % ', '.join(installed_targets), file=log)
                        # Loading a missing or invalid file can wipe the live cache.
                        if exists(active_epg_path) and self._is_valid_epg_dat(active_epg_path):
                            print('[EPGImport] eEPGCache.load() importing: %s' % active_epg_path, file=log)
                            self._prepareCacheActivation('Open Source epg.dat')
                            self.epgcache.load()
                            self._cacheLoadInvoked()
                            reboot = False
                            if needLoad != active_epg_path:
                                unlink_if_exists(needLoad)
                        else:
                            print('[EPGImport] Open source: EPG file missing or invalid at %s - skipping load() to preserve live EPG' % active_epg_path, file=log)
                            reboot = False
                    except Exception as e:
                        self._abortCacheActivation()
                        print('[EPGImport] eEPGCache.load() failed: %s' % repr(e), file=log)
                        reboot = False

                if hasattr(self.epgcache, 'save') and not needLoad and self.eventCount:
                    print('[EPGImport] Save the EPG cache to file %s ...' % active_epg_path, file=log)
                    self.epgcache.save()
                if hasattr(self.epgcache, 'timeUpdated') and not needLoad and self.eventCount:
                    self._notifyLiveEpgChanged('Open Source direct import path')

            if self.onDone:
                self.onDone(reboot=reboot, epgfile=needLoad)

        if self.startTime is not None and self.eventCount is not None:
            print('[EPGImport] Total imported %d events per %s' % (self.eventCount, (datetime.now() - self.startTime)), file=log)
        self.eventCount = None
        self._seen_event_keys.clear()
        self._is_finalizing = False
        print('[EPGImport] #### Finished ####', file=log)

    def isImportRunning(self):
        return self.source is not None or self._is_finalizing or self._activation_pending
