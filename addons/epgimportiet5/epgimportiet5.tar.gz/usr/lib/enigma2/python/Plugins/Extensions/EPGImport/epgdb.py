# -*- coding: utf-8 -*-
# epgdb.py
#
# SQLite EPG database writer for DreamOS (Dreambox) images.
# Imports XMLTV EPG data into the native epg.db SQLite database
# used by DreamOS / OE-2.x images.
#
# NOT used on Open Source images (OpenATV / VTI / PLi / OE-A).
# Open Source images use epgdat.py + the binary epg.dat format instead.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
#
# The code modified by Lululla
# The code modified by iet5
#
from __future__ import print_function
from __future__ import division

try:
    from . import connectTimer
except Exception:
    def connectTimer(timer, callback):
        signal = getattr(timer, 'timeout', None)
        connector = getattr(signal, 'connect', None)
        if callable(connector):
            return connector(callback)
        timer.callback.append(callback)
        return None

from os import path as os_path, remove as os_remove
from shutil import copy2
import time
import threading
from sys import version_info
from enigma import eEPGCache, eTimer
from ServiceReference import ServiceReference
from sqlite3 import dbapi2 as sqlite
from Components.config import config

_LEGACY_DREAM_PY2 = version_info[0] == 2 and version_info[1] == 7

# cachestate is only available on DreamOS (OE-2.5 / OE-2.6 Dreambox builds)
try:
    from enigma import cachestate
except ImportError:
    cachestate = None


GREENC = "\033[32m"
ENDC = "\033[m"

def cprint(text):
    print(GREENC + "[EPGDB] " + text + ENDC)

class epgdb_class(object):

    EPG_HEADER1_channel_count = 0
    EPG_TOTAL_EVENTS = 0
    EXCLUDED_SID = []

    # initialize an empty dictionary (Python array)
    # as channel events container before preprocessing

    def __init__(self, provider_name, provider_priority, epgdb_path=None, clear_oldepg=False):
        # Counters and exclusions belong to one import session only.
        self.EPG_HEADER1_channel_count = 0
        self.EPG_TOTAL_EVENTS = 0
        self.EXCLUDED_SID = []
        self.source_name = provider_name
        self.priority = provider_priority
        # get timespan time from system settings defined in days
        # get outdated time from system settings defined in hours
        self.epg_outdated = int(config.misc.epgcache_outdated_timespan.value)
        # subtract the outdated time from current time
        self.epoch_time = int(time.time()) - (self.epg_outdated * 3600)
        # limit (timespan) the number of day to import
        self.epg_timespan = int(config.misc.epgcache_timespan.value)
        self.epg_cutoff_time = int(time.time()) + (self.epg_timespan * 86400)
        self.event_counter_journal = 0
        self.events_in_past_journal = 0
        self.events_in_import_range_journal = 0
        self.epgdb_path = config.misc.epgcache_filename.value if epgdb_path is None else epgdb_path
        self.backup_path = self.epgdb_path + '.epgimport.backup'
        self.backup_created = False
        if os_path.exists(self.epgdb_path):
            try:
                copy2(self.epgdb_path, self.backup_path)
                self.backup_created = True
                cprint("BACKED UP EPG database to %s" % self.backup_path)
            except Exception as backup_error:
                cprint("EPG backup failed: %s" % backup_error)

        # Timer binding differs between DreamOS and open-source images.
        self.events = []   # MUST be instance-level, not class-level (prevents shared-state bugs)
        self._pending_service_batches = []
        self._pending_lock = threading.Lock()
        self._events_lock = threading.RLock()
        self.ProcessingTimer = eTimer()
        self.ProcessingTimer_conn = connectTimer(self.ProcessingTimer, self.start_process)

        self.connection = None

        if clear_oldepg:
            self.create_empty()
            self.size = os_path.getsize(self.epgdb_path)
            self.start_process()
        else:
            self.epginstance = eEPGCache.getInstance()
            self.cacheState_conn = None
            if cachestate is not None and hasattr(self.epginstance, 'cacheState'):
                self.cacheState_conn = self.epginstance.cacheState.connect(self.cacheStateChanged)
            cprint("[EPGDB] Saving EPG to %s" % self.epgdb_path)
            # Keep epg.db in place while save() runs; the backup covers failures.
            self.size = 0
            eEPGCache.save(self.epginstance)
            if self.cacheState_conn is None:
                self.ProcessingTimer.start(1000, True)

    def cacheStateChanged(self, state):
        if cachestate is not None and state.state == cachestate.save_finished:
            cprint("SAVED")
            self.ProcessingTimer.start(5000, True)
            # self.start_process()

    def start_process(self):
        cprint("START PROCESSING")
        if os_path.exists(self.epgdb_path):
            size = os_path.getsize(self.epgdb_path)
            # even empty epg.db has at least 23k size
            min_size = 23 * 1024
            if size < min_size:
                cprint("%s too small" % self.epgdb_path)
                return False
            if size != getattr(self, 'size', 0):
                cprint("SIZE %d >>> %d changed" % (self.size, size))
                self.size = size
                self.ProcessingTimer.start(5000, True)
                return True
            # size is stable, fall through to connect
        else:
            cprint("%s NOT FOUND" % self.epgdb_path)
            return False

        if self.connection is not None:
            cprint("%s CONNECTED ALREADY" % self.epgdb_path)
            return True

        self.events_in_past_journal = 0
        self.events_in_import_range_journal = 0
        self.source_id = None

        try:
            self.connection = sqlite.connect(self.epgdb_path, timeout=20, isolation_level=None, check_same_thread=False)
            self.connection.text_factory = str
            self.cursor = self.connection.cursor()
            self.cursor.execute("PRAGMA synchronous = OFF")
            self.cursor.execute("PRAGMA journal_mode = OFF")
            self.cursor.execute("SELECT id from T_Source WHERE source_name=? and priority=?", (self.source_name, self.priority))
            row = self.cursor.fetchone()
            if row:
                self.source_id = int(row[0])
                cprint("FOUND %s EPG with source_id %d" % (self.source_name, self.source_id))
            else:
                self.cursor.execute("INSERT INTO T_Source (source_name, priority) VALUES (?, ?)", (self.source_name, self.priority))
                self.source_id = self.cursor.lastrowid
                self.connection.commit()
                cprint("ADDED %s EPG with source_id %d" % (self.source_name, self.source_id))
            # begin transaction  ....
            self.cursor.execute("BEGIN")
            cprint("CONNECT %s FINISHED" % self.epgdb_path)
            self._drain_pending_batches()
            return True
        except Exception as error:
            cprint("CONNECT %s FAILED: %s" % (self.epgdb_path, error))
            try:
                if getattr(self, 'cursor', None) is not None:
                    self.cursor.close()
            except Exception:
                pass
            try:
                if self.connection is not None:
                    self.connection.close()
            except Exception:
                pass
            self.connection = None
            self.cursor = None
            return False

    def set_excludedsid(self, exsidlist):
        self.EXCLUDED_SID = exsidlist

    def add_event(self, starttime, duration, title, description, language):
        if _LEGACY_DREAM_PY2:
            self.events.append((starttime, duration, title[:240], description, language))
            return
        with self._events_lock:
            self.events.append((starttime, duration, title[:240], description, language))

    def _drain_pending_batches(self):
        """Write service batches queued while DreamOS was saving epg.db."""
        if self.connection is None:
            return
        with self._pending_lock:
            if not self._pending_service_batches:
                return
            pending = self._pending_service_batches
            self._pending_service_batches = []
        for services, events in pending:
            with self._events_lock:
                self.events = events
                self._preprocess_events_channel_locked(services)

    def preprocess_events_channel(self, services=None):
        with self._events_lock:
            return self._preprocess_events_channel_locked(services)

    def _preprocess_events_channel_locked(self, services=None):
        if self.connection is None:
            cprint("NOT YET CONNECTED")
            if _LEGACY_DREAM_PY2:
                # Preserve the proven version-37 Dreambox behavior.  start_process()
                # normally connects synchronously once the saved epg.db size is
                # stable.  When that succeeds we MUST continue below and write
                # the current service immediately.  Returning unconditionally
                # here leaves its events in self.events; the next service is then
                # appended to the same list and events become shifted/mixed.
                if os_path.exists(self.epgdb_path):
                    self.size = os_path.getsize(self.epgdb_path)
                    self.start_process()
                if self.connection is None:
                    # The database really is not ready yet.  Transfer ownership
                    # of this list to the pending queue (no event-list copy), so
                    # events from the following service can never be mixed into
                    # it while the DreamOS save operation is still finishing.
                    if services is None:
                        self.events = []
                        return
                    with self._pending_lock:
                        self._pending_service_batches.append((list(services), self.events))
                    self.events = []
                    # The save may still be creating/growing epg.db.  Retry on
                    # the Enigma2 main loop until start_process() can connect;
                    # it will drain the service-preserving pending queue.
                    self.ProcessingTimer.start(1000, True)
                    return
                # Connected: fall through exactly like version 37 and commit
                # this service before importEvents() switches to the next one.
            # Non-legacy images, or a legacy image still not connected after
            # its synchronous retry, must queue the complete service batch.
            # Re-check the connection: the Python 2.7 retry above may already
            # have succeeded, in which case we must fall through and write now.
            if self.connection is None:
                if services is None:
                    self.events = []
                    with self._pending_lock:
                        self._pending_service_batches = []
                    return
                with self._pending_lock:
                    self._pending_service_batches.append((list(services), self.events))
                self.events = []
                if os_path.exists(self.epgdb_path):
                    self.size = os_path.getsize(self.epgdb_path)
                    self.start_process()
                return

        if services is None:
            # reset event container
            self.events = []
            return
        # cprint("EVENTS: %d" % len(self.events))
        # one local cursor per table seems to perform slightly better ...
        cursor_service = self.connection.cursor()
        cursor_event = self.connection.cursor()
        cursor_title = self.connection.cursor()
        cursor_short_desc = self.connection.cursor()
        cursor_extended_desc = self.connection.cursor()
        cursor_data = self.connection.cursor()


        # now we go through all the channels we got
        for service in services:
            # prepare and write CHANNEL INFO record
            channel = ServiceReference(str(service)).getServiceName()
            if channel:
                try:
                    if isinstance(channel, type(u'')):
                        channel = channel.encode("ascii", "ignore").decode("ascii")
                    else:
                        channel = channel.decode("utf-8", "ignore").encode("ascii", "ignore").decode("ascii")
                except Exception:
                    pass
            if not channel:
                channel = str(service)

            ssid = service.split(":")
            # cprint("SSID %s" % ssid)
            number_of_events = len(self.events)
            # only add channels where we have events
            if number_of_events > 0 and len(ssid) > 6:
                # convert hex stuff to integer as epg.db likes it to have
                self.sid = int(ssid[3], 16) & 0xFFFF
                self.tsid = int(ssid[4], 16) & 0xFFFF
                self.onid = int(ssid[5], 16) & 0xFFFF
                self.dvbnamespace = int(ssid[6], 16)
                # cprint("%x %x %x %x" % (self.sid,self.tsid,self.onid,self.dvbnamespace))
                # dvb-t fix: EEEExxxx => EEEE0000
                if 4008574976 < self.dvbnamespace < 4008636143:
                    # cprint("FIXING DVB-T")
                    self.dvbnamespace = 4008574976
                if self.dvbnamespace > 2147483647:
                    self.dvbnamespace -= 4294967296

                self.EPG_HEADER1_channel_count += 1

                cursor_service.execute("SELECT id from T_Service WHERE sid=? and tsid=? and onid=? and dvbnamespace=?", 
                                       (self.sid, self.tsid, self.onid, self.dvbnamespace))
                row = cursor_service.fetchone()
                if row:
                    self.service_id = int(row[0])
                else:
                    cursor_service.execute("INSERT INTO T_Service (sid,tsid,onid,dvbnamespace) VALUES(?,?,?,?)", 
                                           (self.sid, self.tsid, self.onid, self.dvbnamespace))
                    self.service_id = cursor_service.lastrowid

                cursor_event.execute("DELETE FROM T_Event WHERE service_id=?", (self.service_id,))

                # now we go through all the events for this channel/service_id and add them ...
                self.event_counter_journal = 0
                for event in self.events:
                    # short description (title)
                    self.short_d = event[2]
                    self.long_d = event[3] if event[3] else event[2]
                    self.extended_d = self.long_d
                    if "\n\n" in self.long_d:
                        sp = self.long_d.split("\n\n")
                        self.long_d = sp[0]
                        self.extended_d = sp[1]
                    # extract date and time
                    self.begin_time = int(event[0])
                    self.duration = max(1, int(event[1]))
                    self.language = event[4]
                    # we need hash values for descriptions, hash is provided by enigma
                    self.short_hash = eEPGCache.getStringHash(self.short_d)
                    self.long_hash = eEPGCache.getStringHash(self.long_d)
                    self.extended_hash = eEPGCache.getStringHash(self.extended_d)
                    # generate an unique dvb event id < 65536
                    self.dvb_event_id = (self.begin_time - int(self.begin_time // 3932160) * 3932160) // 60
                    # cprint("dvb event id: %d" % self.dvb_event_id)
                    if self.short_hash > 2147483647:
                        self.short_hash -= 4294967296
                    if self.long_hash > 2147483647:
                        self.long_hash -= 4294967296
                    # now insert into epg.db what we have
                    self.end_time = self.begin_time + self.duration
                    if self.end_time > self.epoch_time and self.begin_time < self.epg_cutoff_time and self.source_id is not None:
                        cursor_event.execute(
                            "INSERT INTO T_Event (service_id, begin_time, duration, source_id, dvb_event_id) VALUES(?,?,?,?,?)",
                            (self.service_id, self.begin_time, self.duration, self.source_id, self.dvb_event_id)
                        )
                        self.event_id = cursor_event.lastrowid
                        # check if hash already exists on Title
                        cursor_title.execute("SELECT id from T_Title WHERE hash=?", (self.short_hash,))
                        row = cursor_title.fetchone()
                        if row is None:
                            cursor_title.execute("INSERT INTO T_Title (hash, title) VALUES(?,?)", (self.short_hash, self.short_d))
                            self.title_id = cursor_title.lastrowid
                        else:
                            self.title_id = int(row[0])

                        cursor_short_desc.execute("SELECT id from T_Short_Description WHERE hash=?", (self.long_hash,))
                        row = cursor_short_desc.fetchone()
                        if row is None:
                            cursor_short_desc.execute("INSERT INTO T_Short_Description (hash, short_description) VALUES(?,?)", (self.long_hash, self.long_d))
                            self.short_description_id = cursor_short_desc.lastrowid
                        else:
                            self.short_description_id = int(row[0])

                        cursor_extended_desc.execute("SELECT id from T_Extended_Description WHERE hash=?", (self.extended_hash,))
                        row = cursor_extended_desc.fetchone()
                        if row is None:
                            cursor_extended_desc.execute("INSERT INTO T_Extended_Description (hash, extended_description) VALUES(?,?)", (self.extended_hash, self.extended_d))
                            self.extended_description_id = cursor_extended_desc.lastrowid
                        else:
                            self.extended_description_id = int(row[0])

                        cursor_data.execute("INSERT INTO T_Data (event_id, title_id, short_description_id, extended_description_id, iso_639_language_code) VALUES(?,?,?,?,?)",
                                            (self.event_id, self.title_id, self.short_description_id, self.extended_description_id, self.language))
                        # increase journaling counters
                        self.events_in_import_range_journal += 1
                        self.event_counter_journal += 1
                    else:
                        self.events_in_past_journal += 1

            cprint("ADDED %d from %d events for channel %s" % (self.event_counter_journal, number_of_events, channel))
            self.EPG_TOTAL_EVENTS += number_of_events

        # reset event container
        self.events = []
        cursor_service.close()
        cursor_event.close()
        cursor_title.close()
        cursor_short_desc.close()
        cursor_extended_desc.close()
        cursor_data.close()

    def cancel_process(self):
        if self.connection is None:
            cprint("STILL NOT CONNECTED, sorry")
            return
        cprint("IMPORT CANCELED")
        self.cursor.execute("END")
        self.cursor.close()
        self.connection.close()
        self.connection = None

    def final_process(self):
        if self.connection is None:
            if os_path.exists(self.epgdb_path):
                self.size = os_path.getsize(self.epgdb_path)
                self.start_process()
            if self.connection is None:
                raise RuntimeError("EPG database was not ready before finalization")
        if not _LEGACY_DREAM_PY2:
            self._drain_pending_batches()
        cprint("IMPORT FINISHED and from the total available %d events %d were imported." % (self.EPG_TOTAL_EVENTS, self.events_in_import_range_journal))
        cprint("%d Events were outside of the defined timespan(%d hours outdated and timespan %d days)." % (self.events_in_past_journal, self.epg_outdated, self.epg_timespan))
        try:
            self.cursor.execute("END")
        except Exception:
            pass
        try:
            self.cursor.close()
            self.connection.close()
        except Exception:
            pass
        self.connection = None
        try:
            self.ProcessingTimer.stop()
        except Exception:
            pass
        # Do not replace DreamOS's global in-memory EPG with an incomplete or
        # corrupt SQLite database.  A failed load clears every channel and the
        # guide then commonly reappears only after an Enigma2 restart.
        validation = sqlite.connect(self.epgdb_path, timeout=10)
        try:
            validation_cursor = validation.cursor()
            validation_cursor.execute("PRAGMA integrity_check")
            integrity = validation_cursor.fetchone()
            if not integrity or str(integrity[0]).lower() != 'ok':
                raise RuntimeError("EPG database integrity check failed: %s" % (integrity,))
            validation_cursor.execute("SELECT count(*) FROM T_Event")
            event_row = validation_cursor.fetchone()
            event_count = int(event_row[0]) if event_row else 0
            if event_count <= 0:
                raise RuntimeError("EPG database contains no events")
            cprint("VALIDATED EPG database with %d events" % event_count)
        finally:
            try:
                validation_cursor.close()
            except Exception:
                pass
            validation.close()
        self.cacheState_conn = None
        if hasattr(self, 'ProcessingTimer_conn'):
            self.ProcessingTimer_conn = None
        cprint("WRITES EPG database ...")
        epginstance = eEPGCache.getInstance()
        eEPGCache.load(epginstance)
        if self.backup_created and os_path.exists(self.backup_path):
            try:
                os_remove(self.backup_path)
                self.backup_created = False
            except Exception:
                pass

    def restore_backup(self):
        """Restore the pre-import DreamOS database after failed finalization."""
        if not self.backup_created or not os_path.exists(self.backup_path):
            return False
        copy2(self.backup_path, self.epgdb_path)
        os_remove(self.backup_path)
        self.backup_created = False
        cprint("RESTORED previous EPG database after import failure")
        return True

    def create_empty(self):
        cprint("EMPTY EPG database")
        if os_path.exists(self.epgdb_path):
            os_remove(self.epgdb_path)
        connection = sqlite.connect(self.epgdb_path, timeout=10)
        connection.text_factory = str
        cursor = connection.cursor()

        cursor.execute("CREATE TABLE T_Service (id INTEGER PRIMARY KEY, sid INTEGER NOT NULL, tsid INTEGER, onid INTEGER, dvbnamespace INTEGER, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Source (id INTEGER PRIMARY KEY, source_name TEXT NOT NULL, priority INTEGER NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Title (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, title TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Short_Description (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, short_description TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Extended_Description (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, extended_description TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Event (id INTEGER PRIMARY KEY, service_id INTEGER NOT NULL, begin_time INTEGER NOT NULL, duration INTEGER NOT NULL, source_id INTEGER NOT NULL, dvb_event_id INTEGER, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Data (event_id INTEGER NOT NULL, title_id INTEGER, short_description_id INTEGER, extended_description_id INTEGER, iso_639_language_code TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")

        cursor.execute("CREATE INDEX data_event_id ON T_Data (event_id)")
        cursor.execute("CREATE INDEX data_title ON T_Data (title_id)")
        cursor.execute("CREATE INDEX data_shortdescr ON T_Data (short_description_id)")
        cursor.execute("CREATE INDEX data_extdescr ON T_Data (extended_description_id)")
        cursor.execute("CREATE INDEX service_sid ON T_Service (sid)")
        cursor.execute("CREATE INDEX event_service_id_begin_time ON T_Event (service_id, begin_time)")
        cursor.execute("CREATE INDEX event_dvb_id ON T_Event (dvb_event_id)")

        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_event AFTER DELETE ON T_Event FOR EACH ROW BEGIN DELETE FROM T_Data WHERE event_id = OLD.id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_service_t_event AFTER DELETE ON T_Service FOR EACH ROW BEGIN DELETE FROM T_Event WHERE service_id = OLD.id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_title AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE title_id = OLD.title_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Title WHERE id = OLD.title_id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_short_description AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE short_description_id = OLD.short_description_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Short_Description WHERE id = OLD.short_description_id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_extended_description AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE extended_description_id = OLD.extended_description_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Extended_Description WHERE id = OLD.extended_description_id; END")
        cursor.execute("CREATE TRIGGER tr_on_update_cascade_t_data AFTER UPDATE ON T_Data FOR EACH ROW WHEN (OLD.title_id <> NEW.title_id AND ((SELECT event_id FROM T_Data WHERE title_id = OLD.title_id LIMIT 1) ISNULL)) BEGIN DELETE FROM T_Title WHERE id = OLD.title_id; END")

        # insert default sources
        cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('0','Sky Private EPG','0')")
        cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('1','DVB Now/Next Table','0')")
        cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('2','DVB Schedule (same Transponder)','0')")
        cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('3','DVB Schedule Other (other Transponder)','0')")
        cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('4','Viasat','0')")

        connection.commit()
        cursor.close()
        connection.close()

    def check_epgdb(self):
        try:
            import MySQLdb
            print("MySQLdb present")
        except ImportError:
            print("MySQLdb Not present")
            return

        cprint("CHECKS EPG database")
        connection = sqlite.connect(config.misc.epgcache_filename.value, timeout=10)
        connection.text_factory = str
        cursor = connection.cursor()

        try:
            cursor.execute("SELECT count(*) FROM T_Event")
            result = cursor.fetchall()  # Retrieve all rows from the query result
            text_result = ''.join([str(res[0]) for res in result])
        except Exception as e:
            text_result = "[EPGDB] Error [%d]: %s" % (e.args[0], e.args[1])

        cursor.close()
        connection.close()
        cprint("CHECK RESULT %s" % text_result)
        return text_result
