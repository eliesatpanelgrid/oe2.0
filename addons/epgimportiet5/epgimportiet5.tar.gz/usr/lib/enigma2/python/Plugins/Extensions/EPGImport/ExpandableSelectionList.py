# -*- coding: utf-8 -*-
# ExpandableSelectionList.py
#
# Custom expandable list widget for EPGImport source selection screen.
# Uses skin parameters when available; falls back to hardcoded defaults.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS, OpenATV, VTI, OpenSource Enigma2 images
#
# The code modified by iet5
#
from Components.MenuList import MenuList
from Tools.Directories import resolveFilename, SCOPE_CURRENT_SKIN, SCOPE_CURRENT_PLUGIN
from enigma import eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT
from Tools.LoadPixmap import LoadPixmap

from . import PluginLanguageDomain, ScreenWidth, isDreamOS
import skin

# =========================================================
# Icon loading for expandable/expanded categories
# Try the active skin first, fall back to bundled icons.
# =========================================================
expandableIcon = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/expandable.png"))
expandedIcon   = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/expanded.png"))

# If the skin doesn't have these icons, use the ones bundled with the plugin
if not expandableIcon or not expandedIcon:
    expandableIcon = LoadPixmap(
        resolveFilename(SCOPE_CURRENT_PLUGIN, "Extensions/%s/icon/expandable.png" % PluginLanguageDomain)
    )
    expandedIcon = LoadPixmap(
        resolveFilename(SCOPE_CURRENT_PLUGIN, "Extensions/%s/icon/expanded.png" % PluginLanguageDomain)
    )


def get_params(*params):
    """Apply skin scaling if the helper function exists (some images provide it)."""
    if hasattr(skin, "applySkinFactor"):
        return skin.applySkinFactor(*params)
    return params


def loadSettings():
    """
    Load list layout parameters from the skin (or use safe defaults).
    DreamOS uses fixed values; open-source images use skin.parameters when available.
    All values are stored as module-level globals used by category() and entry().
    """
    global cat_desc_loc, entry_desc_loc, cat_icon_loc, entry_icon_loc

    try:
        if isDreamOS:
            # DreamOS: use fixed layout values (skin.parameters may not exist)
            cat_desc_loc  = (50, 3, 700, 30)
            cat_icon_loc  = (10, 5, 30, 30)
            indent = 40   # cat_icon_loc x + w
            entry_desc_loc = (50 + indent, 3, 700 - indent, 30)
            entry_icon_loc = (10 + indent, 5, 30, 30)
        else:
            # Open Source: try to read layout from skin.parameters
            x, y, w, h = skin.parameters.get("ExpandableListDescr", get_params(50, 3, 700, 30))
            cat_desc_loc  = (x, y, w, h)
            x, y, w, h = skin.parameters.get("ExpandableListIcon", get_params(10, 5, 30, 30))
            cat_icon_loc  = (x, y, w, h)
            indent = x + w   # indentation for entry items

            x, y, w, h = skin.parameters.get("SelectionListDescr", get_params(50, 3, 700, 30))
            entry_desc_loc = (x + indent, y, w - indent, h)
            x, y, w, h = skin.parameters.get("SelectionListLock", get_params(10, 5, 30, 30))
            entry_icon_loc = (x + indent, y, w, h)

    except Exception:
        # Safe fallback values for any image / Python version
        cat_desc_loc   = (50,  3, 700, 30)
        cat_icon_loc   = (10,  5,  30, 30)
        entry_desc_loc = (90,  3, 620, 30)
        entry_icon_loc = (50,  5,  30, 30)


def category(description, isExpanded=False):
    """Build a list entry representing a collapsible category header."""
    icon = expandedIcon if isExpanded else expandableIcon
    return [
        (description, isExpanded, []),   # data tuple: (label, expanded_flag, children)
        (eListboxPythonMultiContent.TYPE_TEXT,)         + cat_desc_loc + (0, RT_HALIGN_LEFT, description),
        (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + cat_icon_loc + (icon,),
    ]


def entry(description, value, selected):
    """Build a list entry representing a selectable source item."""
    res = [
        (description, value, selected),  # data tuple
        (eListboxPythonMultiContent.TYPE_TEXT,) + entry_desc_loc + (0, RT_HALIGN_LEFT, description),
    ]
    # Load the lock icon (on = selected, off = not selected) from the current skin
    selectionpng = LoadPixmap(
        cached=True,
        path=resolveFilename(
            SCOPE_CURRENT_SKIN,
            "skin_default/icons/lock_%s.png" % ("on" if selected else "off")
        )
    )
    if selectionpng:
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + entry_icon_loc + (selectionpng,))
    return res


def expand(cat, value=True):
    """Expand or collapse a category item (toggle the icon)."""
    if cat[0][1] != value:
        icon = expandedIcon if value else expandableIcon
        t = cat[0]
        cat[0] = (t[0], value, t[2])
        cat[2] = (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + cat_icon_loc + (icon,)


def isExpanded(cat):
    """Return True when a category item is currently expanded."""
    return cat[0][1]


def isCategory(item):
    """Return True when the list item is a category (has a children list)."""
    return hasattr(item[0][2], "append")


class ExpandableSelectionList(MenuList):
    """
    A MenuList subclass that supports expandable category headers.
    Each category can be collapsed/expanded to show/hide its child entries.
    Font is taken from the skin; setFont is NOT called directly.
    """

    def __init__(self, tree=None, enableWrapAround=False):
        """
        :param tree: list of category items built with category() / entry()
        :param enableWrapAround: whether list wraps around at top/bottom
        """
        MenuList.__init__(self, [], enableWrapAround, content=eListboxPythonMultiContent)

        # Font size based on resolution; use the skin-registered 'EPGImport' font
        fsize = 30 if ScreenWidth == '1080' else 24

        if isDreamOS:
            # DreamOS: use the bundled font directly
            font_name = "EPGImport"
            item_height = 40
        else:
            # Open Source: prefer 'SelectionList' font from skin, fall back to EPGImport
            font_tuple = skin.fonts.get("SelectionList", get_params("EPGImport", fsize, 40))
            font_name   = font_tuple[0]
            fsize       = font_tuple[1] if len(font_tuple) > 1 else fsize
            item_height = font_tuple[2] if len(font_tuple) > 2 else 40

        # Apply font and item height through the list renderer (no setFont)
        self.l.setFont(0, gFont(font_name, fsize))
        self.l.setItemHeight(item_height)

        self.tree = tree or []
        self.flat_list = []
        self.updateFlatList()

    def updateFlatList(self):
        """Rebuild the visible flat list from the category tree."""
        lflat = []
        for cat in self.tree:
            lflat.append(cat)
            if isExpanded(cat):
                for item in cat[0][2]:
                    lflat.append(entry(*item))
        self.flat_list = lflat
        self.setList(lflat)
        self.list = lflat

    def _get_flat_list(self):
        """Return the current flat list safely (may be None if not yet built)."""
        flat_list = getattr(self, 'flat_list', None)
        if flat_list is None:
            flat_list = self.list if hasattr(self, 'list') else []
        return flat_list or []

    def toggleSelection(self):
        """
        Toggle the current item:
        - If it is a category: expand or collapse it.
        - If it is an entry: toggle its selected state (and all entries with the same key).
        """
        idx = self.getSelectedIndex()
        flat_list = list(self._get_flat_list())

        if idx < 0 or idx >= len(flat_list):
            return

        item = flat_list[idx]

        if isCategory(item):
            # Toggle expand / collapse
            expand(item, not item[0][1])
            self.updateFlatList()
            try:
                self.moveToIndex(idx)
            except Exception:
                pass
        else:
            # Toggle selection — multiple entries may share the same key (value)
            i   = item[0]
            key = i[1]
            sel = not i[2]

            # Update visible list
            for list_idx, e in enumerate(flat_list):
                if not isCategory(e) and e[0][1] == key:
                    flat_list[list_idx] = entry(e[0][0], key, sel)

            # Update hidden tree data
            for cat in self.tree:
                for tree_idx, e in enumerate(cat[0][2]):
                    if e[1] == key and e[2] != sel:
                        cat[0][2][tree_idx] = (e[0], e[1], sel)

            self.flat_list = flat_list
            self.setList(flat_list)
            self.list = flat_list

            try:
                self.moveToIndex(idx)
            except Exception:
                pass

    def enumSelected(self):
        """Yield all selected (description, value, True) entries from the tree."""
        for cat in self.tree:
            for ent in cat[0][2]:
                if ent[2]:
                    yield ent


# Initialize layout parameters at module load time
loadSettings()
