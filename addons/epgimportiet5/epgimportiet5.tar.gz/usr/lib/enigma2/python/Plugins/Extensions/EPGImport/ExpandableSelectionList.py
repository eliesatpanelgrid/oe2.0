# -*- coding: utf-8 -*-
# ExpandableSelectionList.py
#
# Custom expandable list widget for EPGImport source selection screen.
# Uses skin parameters when available; falls back to hardcoded defaults.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS, OpenATV, VTI, OpenSource Enigma2 images
#
# The code modified by iet5
#
from Components.MenuList import MenuList
from Tools.Directories import resolveFilename, SCOPE_CURRENT_SKIN, SCOPE_CURRENT_PLUGIN
from enigma import eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT
from Tools.LoadPixmap import LoadPixmap

from . import PluginLanguageDomain, ScreenWidth
import skin

# =========================================================
# Icon loading for expandable/expanded categories
# Try the active skin first, fall back to bundled icons.
# =========================================================
def _load_category_icon(filename):
    """Load an active-skin icon, falling back to the bundled asset."""
    try:
        icon = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/%s" % filename))
        if icon:
            return icon
    except Exception:
        pass
    try:
        return LoadPixmap(resolveFilename(
            SCOPE_CURRENT_PLUGIN,
            "Extensions/%s/icon/%s" % (PluginLanguageDomain, filename)
        ))
    except Exception:
        return None


expandableIcon = _load_category_icon("expandable.png")
expandedIcon = _load_category_icon("expanded.png")


def get_params(*params):
    """Apply skin scaling if the helper function exists (some images provide it)."""
    if hasattr(skin, "applySkinFactor"):
        return skin.applySkinFactor(*params)
    return params


def loadSettings():
    """
    Load list layout parameters from the active skin, with safe defaults.
    """
    global cat_desc_loc, entry_desc_loc, cat_icon_loc, entry_icon_loc

    try:
        parameters = getattr(skin, "parameters", {})
        x, y, w, h = parameters.get("ExpandableListDescr", get_params(50, 3, 700, 30))
        cat_desc_loc = (x, y, w, h)
        x, y, w, h = parameters.get("ExpandableListIcon", get_params(10, 5, 30, 30))
        cat_icon_loc = (x, y, w, h)
        indent = x + w

        x, y, w, h = parameters.get("SelectionListDescr", get_params(50, 3, 700, 30))
        entry_desc_loc = (x + indent, y, max(1, w - indent), h)
        x, y, w, h = parameters.get("SelectionListLock", get_params(10, 5, 30, 30))
        entry_icon_loc = (x + indent, y, w, h)

    except Exception:
        # Safe fallback values for any image / Python version
        cat_desc_loc   = (50,  3, 700, 30)
        cat_icon_loc   = (10,  5,  30, 30)
        entry_desc_loc = (90,  3, 620, 30)
        entry_icon_loc = (50,  5,  30, 30)


def category(description, isExpanded=False):
    """Build a list entry representing a collapsible category header."""
    icon = expandedIcon if isExpanded else expandableIcon
    return [
        (description, isExpanded, []),   # data tuple: (label, expanded_flag, children)
        (eListboxPythonMultiContent.TYPE_TEXT,)         + cat_desc_loc + (0, RT_HALIGN_LEFT, description),
        (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + cat_icon_loc + (icon,),
    ]


def entry(description, value, selected):
    """Build a list entry representing a selectable source item."""
    res = [
        (description, value, selected),  # data tuple
        (eListboxPythonMultiContent.TYPE_TEXT,) + entry_desc_loc + (0, RT_HALIGN_LEFT, description),
    ]
    # Load the lock icon (on = selected, off = not selected) from the current skin
    try:
        selectionpng = LoadPixmap(
            cached=True,
            path=resolveFilename(
                SCOPE_CURRENT_SKIN,
                "skin_default/icons/lock_%s.png" % ("on" if selected else "off")
            )
        )
    except Exception:
        # Some proprietary images do not ship the standard lock icons.
        selectionpng = None
    if selectionpng:
        res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + entry_icon_loc + (selectionpng,))
    return res


def expand(cat, value=True):
    """Expand or collapse a category item (toggle the icon)."""
    if cat[0][1] != value:
        icon = expandedIcon if value else expandableIcon
        t = cat[0]
        cat[0] = (t[0], value, t[2])
        cat[2] = (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND,) + cat_icon_loc + (icon,)


def isExpanded(cat):
    """Return True when a category item is currently expanded."""
    return cat[0][1]


def isCategory(item):
    """Return True when the list item is a category (has a children list)."""
    return hasattr(item[0][2], "append")


class ExpandableSelectionList(MenuList):
    """
    A MenuList subclass that supports expandable category headers.
    Each category can be collapsed/expanded to show/hide its child entries.
    Font is taken from the skin; setFont is NOT called directly.
    """

    def __init__(self, tree=None, enableWrapAround=False):
        """
        :param tree: list of category items built with category() / entry()
        :param enableWrapAround: whether list wraps around at top/bottom
        """
        MenuList.__init__(self, [], enableWrapAround, content=eListboxPythonMultiContent)

        # Prefer list fonts supplied by the active skin on every image.
        fsize = 30 if ScreenWidth == '1080' else 24
        fonts = getattr(skin, "fonts", {})
        font_tuple = fonts.get("SelectionList") or fonts.get("ChoiceList")
        if not isinstance(font_tuple, (tuple, list)) or not font_tuple:
            font_tuple = ("Regular", fsize, 40)
        font_name = font_tuple[0] or "Regular"
        try:
            fsize = max(1, int(font_tuple[1])) if len(font_tuple) > 1 else fsize
        except (TypeError, ValueError):
            pass
        try:
            item_height = max(1, int(font_tuple[2])) if len(font_tuple) > 2 else 40
        except (TypeError, ValueError):
            item_height = 40

        # Apply font and item height through the list renderer (no setFont)
        self.l.setFont(0, gFont(font_name, fsize))
        self.l.setItemHeight(item_height)

        self.tree = tree or []
        self.flat_list = []
        self.updateFlatList()

    def updateFlatList(self):
        """Rebuild the visible flat list from the category tree."""
        lflat = []
        for cat in self.tree:
            lflat.append(cat)
            if isExpanded(cat):
                for item in cat[0][2]:
                    lflat.append(entry(*item))
        self.flat_list = lflat
        self.setList(lflat)
        self.list = lflat

    def _get_flat_list(self):
        """Return the current flat list safely (may be None if not yet built)."""
        flat_list = getattr(self, 'flat_list', None)
        if flat_list is None:
            flat_list = self.list if hasattr(self, 'list') else []
        return flat_list or []

    def toggleSelection(self):
        """
        Toggle the current item:
        - If it is a category: expand or collapse it.
        - If it is an entry: toggle its selected state (and all entries with the same key).
        """
        idx = self.getSelectedIndex()
        flat_list = list(self._get_flat_list())

        if idx < 0 or idx >= len(flat_list):
            return

        item = flat_list[idx]

        if isCategory(item):
            # Toggle expand / collapse
            expand(item, not item[0][1])
            self.updateFlatList()
            try:
                self.moveToIndex(idx)
            except Exception:
                pass
        else:
            # Multiple entries may share the same selection key.
            i   = item[0]
            key = i[1]
            sel = not i[2]

            # Update visible list
            for list_idx, e in enumerate(flat_list):
                if not isCategory(e) and e[0][1] == key:
                    flat_list[list_idx] = entry(e[0][0], key, sel)

            # Update hidden tree data
            for cat in self.tree:
                for tree_idx, e in enumerate(cat[0][2]):
                    if e[1] == key and e[2] != sel:
                        cat[0][2][tree_idx] = (e[0], e[1], sel)

            self.flat_list = flat_list
            self.setList(flat_list)
            self.list = flat_list

            try:
                self.moveToIndex(idx)
            except Exception:
                pass

    def enumSelected(self):
        """Yield all selected (description, value, True) entries from the tree."""
        for cat in self.tree:
            for ent in cat[0][2]:
                if ent[2]:
                    yield ent


# Initialize layout parameters at module load time
loadSettings()
