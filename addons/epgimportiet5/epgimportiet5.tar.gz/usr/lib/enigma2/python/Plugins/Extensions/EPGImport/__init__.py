# -*- coding: utf-8 -*-
# __init__.py
#
# Plugin initialization module for EPGImport
# Handles: language, font, skin, DreamOS detection
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS (Dreambox 920 / VU+ / OpenATV / OpenSource / VTI)
#
from __future__ import absolute_import

import sys
import gettext
from os import environ, path

# =========================================================
# Python version detection flags
# =========================================================
PY3 = sys.version_info[0] >= 3
isPython312 = sys.version_info[:2] >= (3, 12)
isPython313 = sys.version_info[:2] >= (3, 13)
isPython314 = sys.version_info[:2] >= (3, 14)

# =========================================================
# Enigma2 / framework imports
# =========================================================
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import getDesktop, addFont

# Try to import eEnv (only available on DreamOS / some images)
try:
    from enigma import eEnv
except ImportError:
    eEnv = None

# XML parser (cElementTree is faster but deprecated in Py3.3+; fallback to ElementTree)
try:
    from xml.etree.cElementTree import ElementTree, tostring, parse as ET_parse
    import xml.etree.cElementTree as ET
except ImportError:
    from xml.etree.ElementTree import ElementTree, tostring, parse as ET_parse
    import xml.etree.ElementTree as ET

# =========================================================
# DreamOS detection
# Canonical flag used by ALL modules in this plugin.
# Aliases added for backward-compatibility with older code.
# =========================================================
try:
    if eEnv is not None:
        # DreamOS provides eEnv; dpkg presence is the reliable indicator
        isDreamOS = path.isdir(eEnv.resolve("${sysconfdir}/dpkg"))
    else:
        # Fallback for non-DreamOS images (OpenATV, VTI, PLi, OE-A …)
        isDreamOS = path.isdir("/etc/dpkg") or path.exists("/var/lib/dpkg/status")
except Exception:
    isDreamOS = False

# Backward-compatibility aliases (some modules use these spellings)
isDreamos = isDreamOS
isDreamOs = isDreamOS

# =========================================================
# Plugin language domain (folder name = plugin name)
# =========================================================
PluginLanguageDomain = path.split(path.dirname(path.realpath(__file__)))[-1]


def getFullPath(fname):
    """Return absolute path of a file relative to this plugin's folder."""
    return resolveFilename(SCOPE_PLUGINS, path.join('Extensions', PluginLanguageDomain, fname))


def localeInit():
    """
    Initialize plugin translations.
    Sets the LANGUAGE env var and binds the .mo file path.
    Safe for both Python 2.7 and Python 3.x.
    """
    try:
        environ['LANGUAGE'] = language.getLanguage()[:2]
    except Exception:
        pass

    # Tell gettext where to find compiled .mo files
    gettext.bindtextdomain(PluginLanguageDomain, getFullPath('locale'))

    # Force UTF-8 encoding for all translations (prevents mojibake on some images)
    try:
        gettext.bind_textdomain_codeset(PluginLanguageDomain, 'UTF-8')
    except Exception:
        pass

    # Activate our domain so dgettext() works correctly
    try:
        gettext.textdomain(PluginLanguageDomain)
    except Exception:
        pass


# =========================================================
# Screen resolution detection (used for skin selection)
# =========================================================
try:
    ScreenWidth = getDesktop(0).size().width()
except Exception:
    ScreenWidth = 720

# Map pixel width to skin folder name ('1080' or '720')
ScreenWidth = '1080' if ScreenWidth >= 1920 else '720'

# =========================================================
# Skin XML loading
# =========================================================
try:
    plugin_skin = ET_parse(getFullPath('skin/%s.xml' % ScreenWidth)).getroot()
except Exception as _e:
    print("[EPGImport] Error loading skin: %s" % str(_e))
    plugin_skin = None


def getSkin(skinName):
    """
    Retrieve a <screen> element from the bundled skin XML as a string.
    Returns an empty string when the skin or element is not found.
    Safe for Python 2.7 and Python 3.x.
    """
    if plugin_skin is not None:
        try:
            skin_element = plugin_skin.find('.//screen[@name="%s"]' % skinName)
            if skin_element is not None:
                # tostring() with encoding='unicode' returns a str in Py3;
                # with encoding='utf-8' it returns bytes in both Py2 and Py3.
                if PY3:
                    # Python 3: encoding='unicode' gives str directly (no BOM)
                    return ET.tostring(skin_element, encoding='unicode', method='xml')
                else:
                    # Python 2: tostring() returns bytes (str); keep as-is
                    data = ET.tostring(skin_element, encoding='utf-8', method='xml')
                    # Strip the XML declaration that ET adds when encoding is specified
                    if isinstance(data, bytes) and data.startswith(b"<?xml"):
                        data = data[data.find(b'>') + 1:].lstrip()
                    return data
        except Exception as _e:
            print("[EPGImport] Error getting skin %s: %s" % (skinName, str(_e)))
    return ''


# =========================================================
# Translation helper
# =========================================================
def _(txt):
    """
    Translate *txt* using the plugin's own gettext domain.
    Compatible with Python 2.7 (returns bytes/str) and Python 3 (returns str).
    Always returns a safe fallback (original text) on any error.
    """
    if not txt:
        return ''

    try:
        t = gettext.dgettext(PluginLanguageDomain, txt)
    except Exception:
        return txt

    # Python 2: gettext may return bytes or unicode; keep consistent with Enigma2 expectations
    # Python 3: gettext always returns str (unicode)
    return t


# =========================================================
# Font registration
# Use the skin's font rather than setFont to be compatible
# across DreamOS, OpenATV, VTI, and Open Source images.
# NOTE: setFont is NOT used here as per plugin requirements.
# =========================================================
def _register_font():
    """
    Register the bundled EPGImport TrueType font with Enigma2.
    The font is referenced by name 'EPGImport' in all skin definitions.
    Different images expose different addFont() signatures; we try both.
    """
    font_path = getFullPath('skin/epgimport.ttf')
    font_name = 'EPGImport'
    font_scale = 100

    # Primary call (standard Enigma2 / DreamOS / OpenATV / VTI signature)
    try:
        addFont(font_path, font_name, font_scale, False)
        return  # Success — no need for fallback
    except Exception as _e1:
        print("[EPGImport] addFont primary failed: %s" % str(_e1))

    # Fallback call used on some OpenPLi / OE-A builds that add an extra int arg
    try:
        addFont(font_path, font_name, font_scale, False, 0)
        return
    except Exception as _e2:
        print("[EPGImport] addFont fallback also failed: %s" % str(_e2))


_register_font()

# =========================================================
# Activate locale and register language-change callback
# =========================================================
localeInit()
language.addCallback(localeInit)
