#!/usr/bin/python
# -*- coding: utf-8 -*-
#
from Components.config import config
from re import sub
from sys import version_info
from xml.sax.saxutils import unescape

try:
    _basestring = basestring
    _unicode = unicode
except NameError:
    _basestring = str
    _unicode = str

try:
    from six import ensure_str
except ImportError:
    def ensure_str(s, encoding='utf-8', errors='strict'):
        if isinstance(s, _unicode) and version_info[0] < 3:
            return s.encode(encoding, errors)
        elif isinstance(s, bytes) and version_info[0] >= 3:
            return s.decode(encoding, errors)
        return s

try:
    from xml.etree.cElementTree import iterparse
except ImportError:
    from xml.etree.ElementTree import iterparse

PY3 = (version_info[0] == 3)
LEFT_DOUBLE_ANGLE = u"\xab"
RIGHT_DOUBLE_ANGLE = u"\xbb"

global filterCustomChannel

# Check if epgimport configuration is defined
if hasattr(config.plugins, "epgimport") and hasattr(config.plugins.epgimport, "filter_custom_channel"):
    filterCustomChannel = config.plugins.epgimport.filter_custom_channel.value
else:
    filterCustomChannel = False  # Fallback if not defined


def get_xml_rating_string(elem):
    """Get the rating string from an XML element."""
    rating = ""
    try:
        for node in elem.findall("rating"):
            for value_node in node.findall("value"):
                value_text = value_node.text.replace("+", "")
                if not rating:
                    rating = value_text
    except Exception as e:
        print("[XMLTVConverter] get_xml_rating_string error:", e)
    return ensure_str(rating)


def get_xml_string(elem, name):
    """Extract text for a given tag from an XML element."""
    result = ""
    try:
        for node in elem.findall(name):
            text = node.text
            lang = node.get("lang", None)
            if not result and text is not None:
                result = text
            elif lang == "nl":
                result = text
    except Exception as e:
        print("[XMLTVConverter] get_xml_string error:", e)

    result = unescape(result, entities={
        r"&apos;": r"'",
        r"&quot;": r'"',
        r"&#124;": r"|",
        r"&nbsp;": r" ",
        r"&#91;": r"[",
        r"&#93;": r"]",
    })
    return ensure_str(result)


def _normalize_mojibake_quotes(text):
    """Repair common mojibake variants of guillemet characters."""
    replacements = (
        ("Â«", LEFT_DOUBLE_ANGLE),
        ("Â»", RIGHT_DOUBLE_ANGLE),
        ("Ã‚Â«", LEFT_DOUBLE_ANGLE),
        ("Ã‚Â»", RIGHT_DOUBLE_ANGLE),
    )
    for source, target in replacements:
        text = text.replace(source, target)
    return text


def xml_unescape(text):
    """Clean and unescape XML text safely for both Python 2 and 3."""
    if not isinstance(text, _basestring):
        return ""

    text = text if PY3 else text.encode("utf-8") if isinstance(text, _unicode) else text
    cleaned = sub(
        r"&#160;|&nbsp;|\s+",
        " ",
        unescape(
            text.strip(),
            entities={
                r"&laquo;": LEFT_DOUBLE_ANGLE,
                r"&#171;": LEFT_DOUBLE_ANGLE,
                r"&raquo;": RIGHT_DOUBLE_ANGLE,
                r"&#187;": RIGHT_DOUBLE_ANGLE,
                r"&apos;": r"'",
                r"&quot;": r'"',
                r"&#124;": r"|",
                r"&#91;": r"[",
                r"&#93;": r"]",
            }
        )
    )
    return _normalize_mojibake_quotes(cleaned)


def enumerateXML(fp, tag=None):
    """
    Enumerate ElementTree nodes from a file object for a specific tag.

    Args:
        fp: File-like object containing XML data.
        tag: The XML tag to search for. If None, process all nodes.

    Yields:
        ElementTree.Element objects matching the specified tag.
    """
    doc = iterparse(fp, events=("start", "end"))
    _, root = next(doc)
    depth = 0

    for event, element in doc:
        if tag is None or element.tag == tag:
            if event == "start":
                depth += 1
            elif event == "end":
                depth -= 1
                if depth == 0:
                    yield element
                    element.clear()
        elif event == "end":
            root.clear()
