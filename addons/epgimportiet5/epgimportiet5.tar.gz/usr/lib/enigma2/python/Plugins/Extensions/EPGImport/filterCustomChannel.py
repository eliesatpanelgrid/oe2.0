#!/usr/bin/python
# -*- coding: utf-8 -*-
# filterCustomChannel.py
#
# Custom channel filter for EPGImport.
# Parses custom channel XML files and provides XML text extraction helpers.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS (Dreambox 920), VU+ (OpenATV/VTI), OpenSource Enigma2
#
from __future__ import print_function

import sys
from re import sub
from xml.sax.saxutils import unescape

# =========================================================
# Python 2 / 3 compatibility types
# =========================================================
PY3 = (sys.version_info[0] == 3)

try:
    _basestring = basestring   # noqa: F821  (Python 2)
    _unicode    = unicode      # noqa: F821
except NameError:
    _basestring = str          # Python 3
    _unicode    = str

# =========================================================
# six.ensure_str replacement (avoids hard dependency on six)
# =========================================================
try:
    from six import ensure_str
except ImportError:
    def ensure_str(s, encoding='utf-8', errors='strict'):
        """Return a native str on both Python 2 and Python 3."""
        if PY3:
            # Python 3: bytes -> str
            if isinstance(s, bytes):
                return s.decode(encoding, errors)
            return s if isinstance(s, str) else str(s)
        else:
            # Python 2: unicode -> bytes (str)
            if isinstance(s, _unicode):
                return s.encode(encoding, errors)
            return s if isinstance(s, str) else str(s)

# =========================================================
# XML parser (cElementTree faster but deprecated in Py3.3+)
# =========================================================
try:
    from xml.etree.cElementTree import iterparse
except ImportError:
    from xml.etree.ElementTree import iterparse

# =========================================================
# GUI config (optional - may not be available during unit tests)
# =========================================================
try:
    from Components.config import config
    # CONDITION: Check configuration availability before accessing it
    if hasattr(config, 'plugins') and hasattr(config.plugins, 'epgimport') and \
            hasattr(config.plugins.epgimport, 'filter_custom_channel'):
        filterCustomChannel = config.plugins.epgimport.filter_custom_channel.value
    else:
        filterCustomChannel = False
except Exception:
    config = None
    filterCustomChannel = False

# =========================================================
# Unicode constants (guillemet characters)
# =========================================================
LEFT_DOUBLE_ANGLE  = u"\xab"   # «
RIGHT_DOUBLE_ANGLE = u"\xbb"   # »


# =========================================================
# XML helpers
# =========================================================

def get_xml_rating_string(elem):
    """
    Extract the parental rating value from an XML element's <rating> children.
    Returns an empty string when no rating is found.
    Compatible with Python 2.7 and all Python 3.x versions.
    """
    rating = ""
    try:
        for node in elem.findall("rating"):
            for value_node in node.findall("value"):
                text = value_node.text
                if text and not rating:
                    rating = text.replace("+", "")
    except Exception as e:
        print("[filterCustomChannel] get_xml_rating_string error:", e)
    return ensure_str(rating) if rating else ""


def get_xml_string(elem, name):
    """
    Extract text for the first XML child with *name* from *elem*.
    Prefers elements whose 'lang' attribute is 'nl'; otherwise uses the first.

    Returns a safe native str (bytes on Py2, str on Py3).
    Compatible with Python 2.7 and all Python 3.x versions.
    """
    result = ""
    try:
        for node in elem.findall(name):
            text = node.text
            lang = node.get("lang", None)
            if text is not None:
                if not result:
                    result = text
                elif lang == "nl":
                    # Prefer Dutch-language nodes
                    result = text
    except Exception as e:
        print("[filterCustomChannel] get_xml_string error:", e)

    # Unescape common XML / HTML entities
    try:
        result = unescape(result, entities={
            r"&apos;": r"'",
            r"&quot;": r'"',
            r"&#124;": r"|",
            r"&nbsp;": r" ",
            r"&#91;":  r"[",
            r"&#93;":  r"]",
        })
    except Exception:
        pass

    return ensure_str(result) if result else ""


def _normalize_mojibake_quotes(text):
    """
    Repair common mojibake variants of guillemet characters (« and »).
    These appear when UTF-8 bytes are mis-decoded as Latin-1.
    """
    replacements = (
        (u"\xc2\xab",         LEFT_DOUBLE_ANGLE),
        (u"\xc2\xbb",         RIGHT_DOUBLE_ANGLE),
        (u"\xc3\x82\xc2\xab", LEFT_DOUBLE_ANGLE),
        (u"\xc3\x82\xc2\xbb", RIGHT_DOUBLE_ANGLE),
    )
    for source, target in replacements:
        try:
            text = text.replace(source, target)
        except Exception:
            pass
    return text


def xml_unescape(text):
    """
    Clean and unescape XML text safely for Python 2.7 and Python 3.x.

    Steps:
    1. Guard against non-string input.
    2. Normalise encoding (Py2: ensure bytes; Py3: str is already fine).
    3. Unescape HTML/XML entities.
    4. Collapse whitespace.
    5. Repair mojibake guillemet variants.
    """
    if not isinstance(text, _basestring):
        return ""

    # CONDITION: Python 2 - ensure text is bytes before passing to unescape
    if not PY3 and isinstance(text, _unicode):
        try:
            text = text.encode("utf-8")
        except Exception:
            pass

    try:
        cleaned = sub(
            r"&#160;|&nbsp;|\s+",
            " ",
            unescape(
                text.strip(),
                entities={
                    r"&laquo;": LEFT_DOUBLE_ANGLE,
                    r"&#171;":  LEFT_DOUBLE_ANGLE,
                    r"&raquo;": RIGHT_DOUBLE_ANGLE,
                    r"&#187;":  RIGHT_DOUBLE_ANGLE,
                    r"&apos;":  r"'",
                    r"&quot;":  r'"',
                    r"&#124;":  r"|",
                    r"&#91;":   r"[",
                    r"&#93;":   r"]",
                }
            )
        )
    except Exception:
        cleaned = text if isinstance(text, str) else str(text)

    return _normalize_mojibake_quotes(cleaned)


def enumerateXML(fp, tag=None):
    """
    Enumerate ElementTree nodes from a file object for a specific tag.

    :param fp:  File-like object containing XML data.
    :param tag: XML tag to filter; None processes all end-events.

    Yields:
        xml.etree.ElementTree.Element objects matching *tag*.

    Compatible with Python 2.7 and Python 3.x.
    Uses iterparse so only one element at a time is in memory.
    """
    doc = iterparse(fp, events=("start", "end"))
    _, root = next(doc)
    depth = 0

    for event, element in doc:
        if tag is None or element.tag == tag:
            if event == "start":
                depth += 1
            elif event == "end":
                depth -= 1
                if depth == 0:
                    yield element
                    element.clear()
        elif event == "end":
            # Keep root from accumulating child elements in memory
            root.clear()
