# -*- coding: utf-8 -*-
# epgdat_importer.py
#
# Bridge between EPGImport and the correct low-level EPG storage backend:
#   - DreamOS -> epgdb.py  (SQLite / epg.db)
#   - Open Source (OpenATV / VTI / PLi / OE-A) -> epgdat.py (epg.dat binary)
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS, OpenATV, VTI, OpenSource Enigma2 images
#
# The code modified by Lululla
# The code modified by iet5
#
from __future__ import print_function

import traceback
import os
from os.path import join
import tempfile

from . import log, PY3, isPython312, isPython313, isPython314
from .EPGImport import bigStorage, get_runtime_profile

# =========================================================
# Enigma2 eEnv (only available on DreamOS; guarded import)
# =========================================================
try:
    from enigma import eEnv
except ImportError:
    eEnv = None

try:
    from Components.config import config
except ImportError:
    config = None

# =========================================================
# Backend selection: DreamOS uses epgdb; others use epgdat
# =========================================================
_USE_DREAM_BACKEND = bool(get_runtime_profile().get('uses_epgdb'))

if _USE_DREAM_BACKEND:
    from . import epgdb
else:
    from . import epgdat

# =========================================================
# Storage path resolution
# All path lookups are done lazily inside the class to avoid
# crashes caused by eEnv / config being unavailable at module load.
# =========================================================

# Media paths ordered by preference (most reliable first)
_medialist = ['/media/hdd', '/media/usb', '/media/mmc', '/media/cf', '/media/sdcard']


def _resolve_settings_path():
    """
    Resolve the Enigma2 settings directory safely.
    On DreamOS, eEnv provides the canonical path.
    On open-source images, /etc/enigma2 is the standard location.
    """
    if eEnv is not None:
        try:
            return eEnv.resolve("${sysconfdir}/enigma2/")
        except Exception:
            pass
    return '/etc/enigma2/'


class epgdatclass(object):
    """
    Unified EPG data import class.

    Selects the correct storage backend at runtime:
      - DreamOS -> epgdb.epgdb_class  (writes to epg.db SQLite database)
      - Open Source -> epgdat.epgdat_class  (writes binary epg.dat file)

    Handles duplicate event detection and commit-per-service logic.
    """

    def __init__(self):
        self.data = None
        self.services = None
        # Set of event keys already added in current service batch (dedup guard)
        self._service_event_keys = set()
        # Keep routine progress logging at service granularity.  The legacy
        # DreamOS/OpenSource paths may call importEvents() once per event; a
        # log line for every call can therefore flood the circular log and add
        # avoidable I/O on receivers with slow flash storage.
        self._queued_event_count = 0
        self._duplicate_event_count = 0

        # Resolve storage paths at construction time (not at module load)
        tmppath = bigStorage(9000000, tempfile.gettempdir(), *_medialist)
        settingspath = _resolve_settings_path()

        self.is_dream_backend = _USE_DREAM_BACKEND
        if self.is_dream_backend:
            # DreamOS: write to the epg.db SQLite file used natively by Enigma2
            self.epgfile = config.misc.epgcache_filename.value
            self.epg = epgdb.epgdb_class(
                "EPGImport",
                99,
                self.epgfile,
                config.plugins.epgimport.clear_oldepg.value
            )
        else:
            # Open Source: write a binary epg_new.dat that boot.py will activate
            # epgdat_class expects (tmp_path, lamedb_path, epgdat_path).
            # settingspath is a directory like '/etc/enigma2/', so join lamedb filename.
            lamedb_path = join(settingspath.rstrip('/'), 'lamedb')
            self.epgfile = join(tmppath, 'epg_new.dat')
            self.epg = epgdat.epgdat_class(tmppath, lamedb_path, self.epgfile)

        print("[EPGImport] EPG database located at %s" % self.epgfile, file=log)

    def importEvents(self, services, dataTupleList):
        """
        Add events to the EPG backend.
        Called repeatedly for each matching channel.

        :param services: list of service reference strings for this channel.
        :param dataTupleList: iterable of event tuples
                              (start, duration, title, subtitle, desc[, type[, lang[, rating]]])
        """
        # Commit the previous service batch when the channel changes
        if services != self.services:
            self.commitService()
            self.services = services
            self._service_event_keys = set()

        event_count = 0
        duplicate_count = 0

        for program in dataTupleList:
            # Work with a mutable copy
            program = list(program)

            # Combine title and subtitle into the description field if needed:
            #   program[3] = subtitle, program[4] = description
            if len(program) > 4:
                program[3] = '\n'.join(filter(None, program[3:5]))
            elif len(program) > 3 and not program[3]:
                program[3] = program[4] if len(program) > 4 else ''

            # Trim tuple to the length expected by the backend:
            #   DreamOS (epgdb): keep the language field and ignore rating data
            #   Open Source (epgdat): keep first 4 fields only
            if self.is_dream_backend:
                # XMLTV tuples place language at index 6. A rating, when present,
                # is appended after it and must never be written as the SQLite
                # iso_639_language_code value.
                if len(program) > 6:
                    language = program[6]
                else:
                    language = 'eng'
                if not isinstance(language, (str, bytes)):
                    language = 'eng'
                program = program[:4] + [language]
            else:
                program = program[:4]

            # Strict exact-match deduplication per service to protect the EPG backend
            event_key = tuple(program)
            if event_key in self._service_event_keys:
                duplicate_count += 1
                continue
            self._service_event_keys.add(event_key)

            try:
                self.epg.add_event(*program)
                event_count += 1
            except Exception as _e:
                print("[EPGImport] Error adding event: %s" % str(_e), file=log)

        # Do not log here: on the proven legacy import paths this method can be
        # called once for every event.  commitService() emits one useful summary
        # for the complete service instead.
        self._queued_event_count += event_count
        self._duplicate_event_count += duplicate_count

    def commitService(self):
        """
        Flush the accumulated events for the current service to the backend.
        Resets the per-service duplicate-detection set.
        """
        if self.services is not None:
            try:
                self.epg.preprocess_events_channel(self.services)
                self._service_event_keys = set()
                summary = "[EPGImport] Committed %d events for service: %s" % (
                    self._queued_event_count,
                    str(self.services)
                )
                if self._duplicate_event_count:
                    summary += " (skipped %d duplicates)" % self._duplicate_event_count
                print(summary, file=log)
                self._queued_event_count = 0
                self._duplicate_event_count = 0
            except Exception as _e:
                print("[EPGImport] Error in commitService: %s" % str(_e), file=log)
                traceback.print_exc(file=log)
                raise

    def epg_done(self):
        """
        Finalize all EPG data and close the storage backend.
        Must be called once all channels and events have been imported.
        """
        try:
            print("[EPGImport] Starting epg_done, committing final service...", file=log)
            self.commitService()
            print("[EPGImport] Finalizing EPG database...", file=log)
            self.epg.final_process()
            print("[EPGImport] epg_done completed successfully", file=log)
        except Exception as _e:
            print("[EPGImport] Failure in epg_done: %s" % str(_e), file=log)
            traceback.print_exc(file=log)
            try:
                restore_backup = getattr(self.epg, 'restore_backup', None)
                if callable(restore_backup):
                    restore_backup()
            except Exception as restore_error:
                print("[EPGImport] Failed to restore previous EPG database: %s" % str(restore_error), file=log)
            # The caller must not continue with eEPGCache.load() when the
            # replacement file was not finalized.  Loading an incomplete file
            # clears the global EPG cache, so every channel appears empty until
            # Enigma2 is restarted.
            raise
        finally:
            # Release the backend object regardless of success/failure
            self.epg = None

    def __del__(self):
        """Destructor - ensure the backend is released even on abnormal exit.
        NOTE: Do NOT call epg_done() here - it may raise exceptions during
        Python interpreter shutdown when globals may already be None.
        Instead just release the reference so the GC can clean up.
        """
        try:
            if self.epg is not None:
                self.epg = None
        except Exception:
            pass
