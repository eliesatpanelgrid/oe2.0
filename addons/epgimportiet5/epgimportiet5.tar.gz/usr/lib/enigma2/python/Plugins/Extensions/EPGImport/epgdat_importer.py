# -*- coding: utf-8 -*-
# epgdat_importer.py
#
# Bridge between EPGImport and the correct low-level EPG storage backend:
#   - DreamOS -> epgdb.py  (SQLite / epg.db)
#   - Open Source (OpenATV / VTI / PLi / OE-A) -> epgdat.py (epg.dat binary)
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS, OpenATV, VTI, OpenSource Enigma2 images
#
# The code modified by Lululla
# The code modified by iet5
#
from __future__ import print_function

import traceback
import os
from os.path import join
import tempfile

from . import log, isDreamOS, isDreamos, isDreamOs, PY3, isPython312, isPython313, isPython314
from .EPGImport import bigStorage

# =========================================================
# Enigma2 eEnv (only available on DreamOS; guarded import)
# =========================================================
try:
    from enigma import eEnv
except ImportError:
    eEnv = None

try:
    from Components.config import config
except ImportError:
    config = None

# =========================================================
# Backend selection: DreamOS uses epgdb; others use epgdat
# =========================================================
if isDreamOS:
    from . import epgdb
else:
    from . import epgdat

# =========================================================
# Storage path resolution
# All path lookups are done lazily inside the class to avoid
# crashes caused by eEnv / config being unavailable at module load.
# =========================================================

# Media paths ordered by preference (most reliable first)
_medialist = ['/media/hdd', '/media/usb', '/media/mmc', '/media/cf', '/media/sdcard']


def _resolve_settings_path():
    """
    Resolve the Enigma2 settings directory safely.
    On DreamOS, eEnv provides the canonical path.
    On open-source images, /etc/enigma2 is the standard location.
    """
    if eEnv is not None:
        try:
            return eEnv.resolve("${sysconfdir}/enigma2/")
        except Exception:
            pass
    return '/etc/enigma2/'


def _stop_duplicates_sources_enabled():
    """Return True when duplicate event protection is enabled in setup."""
    try:
        return bool(config.plugins.epgimport.stop_duplicates_sources.value)
    except Exception:
        return False


def _to_text(value):
    """Return a safe text value on Python 2 and Python 3."""
    try:
        text_type = unicode
    except NameError:
        text_type = str
    try:
        if isinstance(value, bytes):
            return value.decode('utf-8', 'ignore')
    except Exception:
        pass
    try:
        return text_type(value)
    except Exception:
        return str(value)


try:
    _text_type = unicode
except NameError:
    _text_type = str
_string_types = (str, _text_type)


def _normalise_event_title(title):
    """Normalise titles so duplicate checks are stable."""
    try:
        return _to_text(title).strip().lower()
    except Exception:
        return _to_text(title)


def _get_channel_identity(services):
    """Return the original XMLTV channel id when available."""
    for attr in ('channel_id', 'xmltv_channel_id', 'epgimport_channel_id'):
        try:
            value = getattr(services, attr)
            if value:
                return value
        except Exception:
            pass
    return None


def _normalise_service_ref_key(ref):
    """Return Enigma2 EPG service id: SID, TSID, ONID and DVB namespace."""
    if not ref:
        return ''
    text = _to_text(ref)
    try:
        parts = text.split(':')
        if len(parts) >= 7:
            return ':'.join((
                '%X' % (int(parts[3], 16) & 0xFFFF),
                '%X' % (int(parts[4], 16) & 0xFFFF),
                '%X' % (int(parts[5], 16) & 0xFFFF),
                parts[6].upper()
            ))
    except Exception:
        pass
    return text


def _normalise_services_key(services):
    """Build an EPG key from channel service ids."""
    channel_id = _get_channel_identity(services)
    if channel_id:
        try:
            return _to_text(channel_id).strip().lower()
        except Exception:
            return _to_text(channel_id)

    try:
        if isinstance(services, _string_types):
            items = [_normalise_service_ref_key(services)]
        else:
            items = sorted([_normalise_service_ref_key(x) for x in list(services)])
    except Exception:
        try:
            items = [_normalise_service_ref_key(services)]
        except Exception:
            items = ['']
    service_key = '|'.join([x for x in items if x])
    if service_key:
        return service_key
    return ''


def _build_event_duplicate_key(services, program):
    """Build key from channel service id, start time, stop time and title."""
    try:
        start_time = int(program[0])
    except Exception:
        start_time = program[0] if program else 0
    try:
        duration = int(program[1])
    except Exception:
        duration = 0
    try:
        stop_time = start_time + duration
    except Exception:
        stop_time = program[1] if len(program) > 1 else 0
    title = program[2] if len(program) > 2 else ''
    return (
        _normalise_services_key(services),
        start_time,
        stop_time,
        _normalise_event_title(title)
    )


class epgdatclass(object):
    """
    Unified EPG data import class.

    Selects the correct storage backend at runtime:
      - DreamOS -> epgdb.epgdb_class  (writes to epg.db SQLite database)
      - Open Source -> epgdat.epgdat_class  (writes binary epg.dat file)

    Handles duplicate event detection and commit-per-service logic.
    """

    def __init__(self):
        self.data = None
        self.services = None
        # Set of event keys already added in current service batch (dedup guard)
        self._service_event_keys = set()

        # Resolve storage paths at construction time (not at module load)
        tmppath = bigStorage(9000000, tempfile.gettempdir(), *_medialist)
        settingspath = _resolve_settings_path()

        if isDreamOS:
            # DreamOS: write to the epg.db SQLite file used natively by Enigma2
            self.epgfile = config.misc.epgcache_filename.value
            self.epg = epgdb.epgdb_class(
                "EPGImport",
                99,
                self.epgfile,
                config.plugins.epgimport.clear_oldepg.value
            )
        else:
            # Open Source: write a binary epg_new.dat that boot.py will activate
            # epgdat_class expects (tmp_path, lamedb_path, epgdat_path).
            # settingspath is a directory like '/etc/enigma2/', so join lamedb filename.
            lamedb_path = join(settingspath.rstrip('/'), 'lamedb')
            self.epgfile = join(tmppath, 'epg_new.dat')
            self.epg = epgdat.epgdat_class(tmppath, lamedb_path, self.epgfile)

        print("[EPGImport] EPG database located at %s" % self.epgfile, file=log)

    def importEvents(self, services, dataTupleList):
        """
        Add events to the EPG backend.
        Called repeatedly for each matching channel.

        :param services: list of service reference strings for this channel.
        :param dataTupleList: iterable of event tuples
                              (start, duration, title, subtitle, desc[, type[, lang[, rating]]])
        """
        # Commit the previous service batch when the channel changes
        if services != self.services:
            self.commitService()
            self.services = services
            self._service_event_keys = set()

        event_count = 0
        duplicate_count = 0

        for program in dataTupleList:
            # Work with a mutable copy
            program = list(program)

            # Combine title and subtitle into the description field if needed:
            #   program[3] = subtitle, program[4] = description
            if len(program) > 4:
                program[3] = '\n'.join(filter(None, program[3:5]))
            elif len(program) > 3 and not program[3]:
                program[3] = program[4] if len(program) > 4 else ''

            # Trim tuple to the length expected by the backend:
            #   DreamOS (epgdb): keep up to index 4 + language field (last)
            #   Open Source (epgdat): keep first 4 fields only
            if isDreamOS:
                # Keep (start, dur, title, desc, lang) - index 0-3 + last field
                program = program[:4] + program[-1:] if len(program) > 4 else program[:4]
            else:
                program = program[:4]

            # Strict exact-match deduplication per service to protect the EPG backend
            event_key = tuple(program)
            if event_key in self._service_event_keys:
                duplicate_count += 1
                continue
            self._service_event_keys.add(event_key)

            try:
                self.epg.add_event(*program)
                event_count += 1
            except Exception as _e:
                print("[EPGImport] Error adding event: %s" % str(_e), file=log)

        if event_count > 0:
            print("[EPGImport] Added %d events to queue for service: %s" % (event_count, str(services)), file=log)
        if duplicate_count > 0:
            print("[EPGImport] Skipped %d duplicate events for service: %s" % (duplicate_count, str(services)), file=log)

    def commitService(self):
        """
        Flush the accumulated events for the current service to the backend.
        Resets the per-service duplicate-detection set.
        """
        if self.services is not None:
            try:
                self.epg.preprocess_events_channel(self.services)
                self._service_event_keys = set()
                print("[EPGImport] commitService completed for service: %s" % str(self.services), file=log)
            except Exception as _e:
                print("[EPGImport] Error in commitService: %s" % str(_e), file=log)
                traceback.print_exc(file=log)
                raise

    def epg_done(self):
        """
        Finalize all EPG data and close the storage backend.
        Must be called once all channels and events have been imported.
        """
        try:
            print("[EPGImport] Starting epg_done, committing final service...", file=log)
            self.commitService()
            print("[EPGImport] Finalizing EPG database...", file=log)
            self.epg.final_process()
            print("[EPGImport] epg_done completed successfully", file=log)
        except Exception as _e:
            print("[EPGImport] Failure in epg_done: %s" % str(_e), file=log)
            traceback.print_exc(file=log)
        finally:
            # Release the backend object regardless of success/failure
            self.epg = None

    def __del__(self):
        """Destructor - ensure the backend is finalized even on abnormal exit."""
        if self.epg is not None:
            self.epg_done()
