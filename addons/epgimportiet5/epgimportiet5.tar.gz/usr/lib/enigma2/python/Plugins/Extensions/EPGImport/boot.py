#!/usr/bin/python
# -*- coding: utf-8 -*-
# boot.py
#
# Boot-time EPG file management script.
# Called by Enigma2 early in the boot sequence to:
#   1. Check if the most recent crash was caused by a corrupt epg.dat
#   2. If so, delete the corrupt file
#   3. Replace epg.dat with a newly prepared epg_new.dat (if one exists)
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS (Dreambox 920), VU+ (FionaPlus), OpenATV, VTI, Open Source Enigma2
#
from __future__ import print_function

import os
import time
import shutil

# =========================================================
# All media paths to search for EPG files.
# /tmp is included last as a fallback (usually RAM-only).
# =========================================================
MEDIA = (
    "/media/hdd/",
    "/media/usb/",
    "/media/mmc/",
    "/media/cf/",
    "/tmp",
)


def findEpg():
    """
    Find the most recently created epg.dat file across all media paths.
    Returns the full path to the most recent file, or None if not found.
    """
    candidates = [
        os.path.join(p, "epg.dat")
        for p in MEDIA
        if os.path.isfile(os.path.join(p, "epg.dat"))
    ]
    if candidates:
        # Sort by creation time; return the newest (last after ascending sort)
        candidates.sort(key=lambda f: os.path.getctime(f))
        return candidates[-1]
    return None


def checkCrashLog():
    """
    Inspect recent Enigma2 crash logs to determine whether a crash was
    caused by a corrupt epg.dat file.

    Returns True if a recent crash (< 2 minutes old) contains the
    'FATAL: LINE' marker that indicates an epg.dat parse error.
    """
    for base_path in MEDIA[:-1]:   # Skip /tmp — crash logs are on persistent media
        try:
            for fname in os.listdir(base_path):
                if not fname.startswith('enigma2_crash'):
                    continue

                # The crash filename encodes a Unix timestamp in characters 14–23
                try:
                    crashtime = int(fname[14:24])
                    age_seconds = time.time() - crashtime
                except (ValueError, IndexError):
                    print("[boot] No valid timestamp in crash filename: %s" % fname)
                    continue

                if age_seconds < 120:   # Only consider crashes within the last 2 minutes
                    print("[boot] Recent crash file found: %s (age=%.0fs)" % (fname, age_seconds))
                    crash_path = os.path.join(base_path, fname)
                    try:
                        with open(crash_path, "r") as crash_file:
                            crash_text = crash_file.read()
                    except Exception as _e:
                        print("[boot] Could not read crash file %s: %s" % (crash_path, _e))
                        continue

                    if "FATAL: LINE " in crash_text:
                        print("[boot] Crash caused by corrupt epg.dat — will delete it")
                        return True

        except Exception as _e:
            # Non-fatal: path may not exist or be unreadable
            pass

    return False


def findNewEpg():
    """
    Locate an epg_new.dat file across all media paths.
    epg_new.dat is written by epgdat.py and should replace epg.dat on next boot.
    Returns the full path to the file, or None if not found.
    """
    for base_path in MEDIA:
        candidate = os.path.join(base_path, 'epg_new.dat')
        if os.path.exists(candidate):
            return candidate
    return None


# =========================================================
# Main boot logic — executed when this module is imported
# =========================================================
epg    = findEpg()
newepg = findNewEpg()

print("[boot] epg.dat found at: %s" % epg)
print("[boot] epg_new.dat found at: %s" % newepg)

# Step 1 — Remove epg.dat if the last crash was caused by a corrupt EPG file
if checkCrashLog() and epg:
    try:
        os.unlink(epg)
        print("[boot] Deleted corrupt epg.dat: %s" % epg)
        epg = None   # Mark as deleted so step 2 treats it as missing
    except Exception as _e:
        print("[boot] Error deleting epg.dat: %s" % _e)

# Step 2 — Activate the newly prepared epg_new.dat
if newepg:
    if epg:
        # Replace existing epg.dat with the new one
        print("[boot] Replacing existing epg.dat with epg_new.dat")
        try:
            os.unlink(epg)
            shutil.copy2(newepg, epg)
            print("[boot] Successfully replaced epg.dat at: %s" % epg)
        except Exception as _e:
            print("[boot] Error replacing epg.dat: %s" % _e)
    else:
        # No existing epg.dat — copy new file to the first writable media path
        for base_path in MEDIA:
            target_epg = os.path.join(base_path, 'epg.dat')
            try:
                shutil.copy2(newepg, target_epg)
                print("[boot] Created new epg.dat at: %s" % target_epg)
                break
            except Exception as _e:
                print("[boot] Could not create epg.dat at %s: %s" % (target_epg, _e))
