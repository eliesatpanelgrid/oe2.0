#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function
#
# The code modified by Lululla
# The code modified by iet5 Date Nov 2025
#
# =========================
# Standard library imports
# =========================
import os
import sys
import errno
import glob
import shutil
import subprocess
from os import makedirs, remove, walk
from os.path import exists, join
from time import localtime, mktime, strftime, time, gmtime
from calendar import day_name
from datetime import datetime
import traceback
# =========================
# Enigma2 / framework imports
# =========================
import Components.PluginComponent
import NavigationInstance
import Screens.Standby
from enigma import (
    eEPGCache,
    eServiceCenter,
    eServiceReference,
    eTimer
)
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.Sources.StaticText import StaticText
from Components.config import (
    config,
    configfile,
    ConfigClock,
    ConfigInteger,
    ConfigOnOff,
    ConfigSelection,
    ConfigSubDict,
    ConfigSubsection,
    ConfigText,
    ConfigYesNo,
    NoSave,
    getConfigListEntry
)

from Plugins.Plugin import PluginDescriptor
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools import Notifications
from Tools.Directories import fileExists, SCOPE_PLUGINS, resolveFilename
from Tools.FuzzyDate import FuzzyTime

# =========================
# Local project imports
# =========================
from . import _, log, getSkin, isDreamOS, isDreamos, isDreamOs, PY3, isPython312, isPython313, isPython314, connectTimer, disconnectTimer
try:
    from enigma import eEnv
except ImportError:
    eEnv = None
ExpandableSelectionList = None
filtersServices = None
EPGImport = None
EPGConfig = None
epgimport = None
e2skinpatcher = None
runtime_import_error = None

# Define SOURCE_LINKS for git imports
SOURCE_LINKS = {
    "0": "https://github.com/oe-alliance/EPGimport-Sources/archive/refs/heads/main.tar.gz",
    "1": "https://github.com/Belfagor2005/EPGimport-Sources/archive/refs/heads/main.tar.gz"
}

try:
    from Tools.StbHardware import getFPWasTimerWakeup
except ImportError:
    try:
        from Tools.DreamboxHardware import getFPWasTimerWakeup
    except ImportError:
        def getFPWasTimerWakeup():
            return False

# =======================================
# Functions
# =======================================

def _getAutoTimerClass():
    """Lazy import for AutoTimer (optional dependency)"""
    try:
        return __import__('Plugins.Extensions.AutoTimer.AutoTimer', fromlist=['AutoTimer']).AutoTimer
    except Exception as e:
        print("[EPGImport] AutoTimer import failed:", repr(e), file=log)
        return None


def ensure_runtime_modules():
    global ExpandableSelectionList, filtersServices, EPGImport, EPGConfig, epgimport, e2skinpatcher, runtime_import_error

    try:
        if ExpandableSelectionList is None:
            from . import ExpandableSelectionList as _ExpandableSelectionList
            ExpandableSelectionList = _ExpandableSelectionList
        if filtersServices is None:
            from . import filtersServices as _filtersServices
            filtersServices = _filtersServices
        if EPGImport is None:
            from . import EPGImport as _EPGImport
            EPGImport = _EPGImport
        if EPGConfig is None:
            from . import EPGConfig as _EPGConfig
            EPGConfig = _EPGConfig
        if isDreamOS and e2skinpatcher is None:
            try:
                from . import e2skinpatcher as _e2skinpatcher
                e2skinpatcher = _e2skinpatcher
            except Exception:
                e2skinpatcher = None
        if epgimport is None and EPGImport is not None:
            epgimport = EPGImport.EPGImport(eEPGCache.getInstance(), channelFilter)
        runtime_import_error = None
        return True
    except Exception as e:
        runtime_import_error = e
        print("[EPGImport] Runtime module import failed: %s" % repr(e), file=log)
        traceback.print_exc(file=log)
        return False

def deep_clean_epg_minimal():
    # Never remove both backend formats.  In a multiboot setup those files may
    # belong to different images sharing the same settings or storage device.
    try:
        active_epg_path = getEPGCachePath(refresh=True)
        epg_files = [active_epg_path] if active_epg_path else []
    except Exception:
        epg_files = ["/etc/enigma2/epg.db" if isDreamOS else "/etc/enigma2/epg.dat"]

    # Remove EPG files
    for f in epg_files:
        try:
            if exists(f):
                remove(f)
        except Exception:
            pass

    # Clean temporary cache
    _cleanup_temporary_epg_paths()


def _command_exists(command_name):
    # shutil.which was added in Python 3.3; not available in Python 2.7
    try:
        result = shutil.which(command_name)
        if result is not None:
            return True
    except AttributeError:
        # Python 2.7 / very old Python 3: fall through to manual check
        pass
    except Exception:
        pass
    # Manual fallback: search well-known binary directories
    try:
        for directory in ('/usr/bin', '/bin', '/usr/sbin', '/sbin'):
            candidate = join(directory, command_name)
            if exists(candidate) and os.access(candidate, os.X_OK):
                return True
    except Exception:
        pass
    return False


def _remove_path_safely(pathname):
    if not pathname or not exists(pathname):
        return
    try:
        if os.path.isdir(pathname):
            shutil.rmtree(pathname, ignore_errors=True)
        else:
            remove(pathname)
    except Exception as e:
        print("[EPGImport] Failed to remove temporary path %s: %s" % (pathname, repr(e)), file=log)


def _cleanup_temporary_epg_paths():
    # Never delete generic /tmp/enigma2* runtime files while the GUI is alive.
    tmp_patterns = ["/tmp/epgimport*", "/tmp/epg.dat", "/tmp/epg.db", "/tmp/epg_new.dat"]
    for pattern in tmp_patterns:
        for pathname in glob.glob(pattern):
            _remove_path_safely(pathname)


def _terminate_stuck_import_processes(profile=None):
    used_commands = []
    # Only target downloader/decompressor helpers writing EPGImport temporary
    # files. Never match EPGImport.py itself because it is loaded by Enigma2.
    process_patterns = (
        r'[w]get.*-O.*/epgimport',
        r'[c]url.*-o.*/epgimport',
        r'[x]z.*epgimport',
    )
    if _command_exists("pkill"):
        with open(os.devnull, 'wb') as sink:
            for pattern in process_patterns:
                try:
                    subprocess.Popen(['pkill', '-f', pattern], stdout=sink, stderr=sink)
                    used_commands.append("pkill:%s" % pattern)
                except Exception as error:
                    print("[EPGImport] Failed to start cleanup for %s: %s" % (pattern, error), file=log)
    elif _command_exists("killall"):
        with open(os.devnull, 'wb') as sink:
            try:
                subprocess.Popen(['killall', '-9', 'epgimport'], stdout=sink, stderr=sink)
                used_commands.append("killall:epgimport")
            except Exception as error:
                print("[EPGImport] Failed to start killall cleanup: %s" % error, file=log)

    if used_commands:
        print("[EPGImport] Stuck process cleanup executed using %s" % ", ".join(used_commands), file=log)
    else:
        print("[EPGImport] No supported process cleanup command found for this image", file=log)

# =======================================
# Global variables
# =======================================
autoStartTimer = None
_session = None
BouquetChannelListList = None
serviceIgnoreList = None
filterCounter = 0
isFilterRunning = 0

def extensionsmenu(session, **kwargs):
    main(session, **kwargs)

def setExtensionsmenu(el):
    try:
        if el.value:
            Components.PluginComponent.plugins.addPlugin(extDescriptor)
        else:
            Components.PluginComponent.plugins.removePlugin(extDescriptor)
    except Exception as e:
        print("[EPGImport] Failed to update extensions menu:", e)

# Filter servicerefs that this box can display by starting a fake recording.
def channelFilter(ref):
    if not ensure_runtime_modules():
        return False

    # Reject empty refs; or non-IPTV when import_onlyiptv is set
    if not ref or (config.plugins.epgimport.import_onlyiptv.value and '%3a//' not in ref.lower()):
        return False

    # Normalize SID, TSID and ONID before building eServiceReference.
    # IPTV providers (e.g. Edem) use service IDs > 65535.  Enigma2 masks them to
    # their low 16 bits internally, so we must do the same or the lookup key won't match.
    try:
        ref = EPGConfig._normalize_service_ref_sid(ref)
    except Exception:
        pass  # EPGConfig not yet loaded (very early call) - use ref as-is

    try:
        sref = eServiceReference(ref)
        refnum = getRefNum(sref.toString())
    except Exception as error:
        print("Invalid service reference %s: %s" % (ref, error), file=log)
        return False

    # Apply the user's bouquet filter.
    if config.plugins.epgimport.import_onlybouquet.value:
        global BouquetChannelListList
        if BouquetChannelListList is None:
            BouquetChannelListList = getBouquetChannelList()
        if refnum not in BouquetChannelListList:
            print("Serviceref not in bouquets:", sref.toString(), file=log)
            return False

    # Skip references explicitly excluded by the user.
    global serviceIgnoreList
    if serviceIgnoreList is None:
        serviceIgnoreList = [getRefNum(x) for x in filtersServices.filtersServicesList.servicesList()]
    if refnum in serviceIgnoreList:
        print("Serviceref is in ignore list:", sref.toString(), file=log)
        return False

    # Accept IPTV references without the fake-recording check.
    # Calling recordService() on thousands of IPTV refs one-by-one freezes the UI because
    # it runs on the main thread and requires a tuner handshake.  IPTV streams are always
    # receivable on any image that has the right plugin, so we return True unconditionally.
    if "%3a//" in ref.lower():
        return True

    # DVB/satellite/cable services: verify tuner can actually receive the signal
    navigation = getattr(NavigationInstance, 'instance', None)
    if navigation is None:
        print("Navigation service is not ready for: %s" % ref, file=log)
        return False
    fakeRecService = None
    try:
        fakeRecService = navigation.recordService(sref, True)
        if fakeRecService:
            fakeRecResult = fakeRecService.start(True)
            # -7 (errNoSourceFound) occurs when a tuner is disconnected.
            return fakeRecResult in (0, -5, -7)
    except Exception as error:
        print("Service capability check failed for %s: %s" % (ref, error), file=log)
        return False
    finally:
        if fakeRecService is not None:
            try:
                navigation.stopRecordService(fakeRecService)
            except Exception:
                pass

    print("Invalid serviceref string:", ref, file=log)
    return False


lastImportResult = None

def deletePycPyoFiles():
    """
    Delete .pyc and .pyo files from the plugin directory.

    Use walk() only and collect paths into a
    set before deleting.  The old code ran glob() on the root directory and
    then walk() over the same directory, so every file in the root was added
    to the list twice.  On Python 3 the second remove() raised FileNotFoundError
    and on Python 2.7 it silently logged a spurious error.
    """
    try:
        plugin_path = "/usr/lib/enigma2/python/Plugins/Extensions/EPGImport"
        if not exists(plugin_path):
            return 0
        # Collect into a set first so each path is unique even if walk() or
        # any future code change produces the same path more than once.
        collected = set()
        for root, _dirs, files in walk(plugin_path):
            for fname in files:
                if fname.endswith('.pyc') or fname.endswith('.pyo'):
                    collected.add(join(root, fname))
        deleted_count = 0
        for file_path in collected:
            try:
                remove(file_path)
                deleted_count += 1
            except Exception:
                pass
        return deleted_count
    except Exception:
        return 0

# Get last byte of MAC address for default time offset calculation
def lastMACbyte():
    """
    Return the last byte of the MAC address as an integer (0-255).

    The local Python-version flag is named
    _is_py3 (not PY3) so it does not shadow the module-level PY3 that is
    imported from __init__.py.  Shadowing PY3 here caused confusion when code
    inside the function tried to reference the global flag.
    Compatible with Python 2.7 (range returns a list) and
    Python 3.14.6 (range returns a range object; list() wraps it).
    """
    try:
        from uuid import getnode
        _is_py3 = (sys.version_info[0] == 3)
        range_list = list(range(6)) if _is_py3 else range(6)
        return int(''.join('%02x' % ((getnode() >> 8 * i) & 0xff) for i in reversed(range_list))[-2:], 16)
    except Exception:
        try:
            with open('/sys/class/net/eth0/address', 'r') as address_file:
                return int(address_file.readline().strip()[-2:], 16)
        except Exception:
            return 256
# Calculate default wakeup time based on MAC address
def calcDefaultStarttime():
    try:
        offset = lastMACbyte() * 30
    except Exception:
        offset = 7680
    return (5 * 60 * 60) + offset

# =========================
# Configuration setup
# =========================
config.plugins.epgimport = ConfigSubsection()
config.plugins.epgimport.enabled = ConfigOnOff(default=True)
# Added option to kill stuck processes
config.plugins.epgimport.killstuck = ConfigYesNo(default=False)
config.plugins.epgimport.runboot = ConfigSelection(default="4", choices=[
    ("1", _("always")),
    ("2", _("only manual boot")),
    ("3", _("only automatic boot")),
    ("4", _("never"))
])
config.plugins.epgimport.runboot_restart = ConfigYesNo(default=False)
config.plugins.epgimport.runboot_day = ConfigYesNo(default=False)
config.plugins.epgimport.wakeup = ConfigClock(default=calcDefaultStarttime())
config.plugins.epgimport.showinextensions = ConfigYesNo(default=True)
config.plugins.epgimport.deepstandby = ConfigSelection(default="skip", choices=[
    ("wakeup", _("wake up and import")),
    ("skip", _("skip the import"))
])
config.plugins.epgimport.extra_source = ConfigSelection(
    default="1",
    choices=[
        ("0", "Doglover3920"),
        ("1", "Lululla")
    ]
)
config.plugins.epgimport.standby_afterwakeup = ConfigYesNo(default=False)
config.plugins.epgimport.shutdown = ConfigYesNo(default=False)
# Maximum EPG days: 30 for all image types (DreamOS and Open Source)
_max_epg_days = 30
config.plugins.epgimport.longDescDays = ConfigInteger(5, limits=(0, _max_epg_days))
config.plugins.epgimport.showinmainmenu = ConfigYesNo(default=False)
config.plugins.epgimport.deepstandby_afterimport = NoSave(ConfigYesNo(default=False))
config.plugins.epgimport.parse_autotimer = ConfigYesNo(default=False)
config.plugins.epgimport.import_onlybouquet = ConfigYesNo(default=False)
config.plugins.epgimport.import_onlyiptv = ConfigYesNo(default=False)
# When enabled, duplicate Rytec source entries and duplicate EPG events are skipped safely.
config.plugins.epgimport.stop_duplicates_sources = ConfigYesNo(default=True)
config.plugins.epgimport.clear_oldepg = ConfigYesNo(default=False)
config.plugins.epgimport.day_profile = ConfigSelection(choices=[("1", _("Press OK"))], default="1")
config.plugins.extra_epgimport = ConfigSubsection()
config.plugins.extra_epgimport.last_import = ConfigText(default="0")
config.plugins.extra_epgimport.day_import = ConfigSubDict()
for i in range(7):
    config.plugins.extra_epgimport.day_import[i] = ConfigOnOff(default=True)


def formatLastImport(last_import):
    template = _("Last import: %s events")
    if template.count("%s") == 1 and template.replace("%%", "").count("%") == 1:
        return template % (last_import,)
    return "Last import: %s events" % (last_import,)

# historically located (not a problem, we want to update it)
CONFIG_PATH = '/etc/epgimport'
try:
    makedirs(CONFIG_PATH)
except OSError as e:  # race condition guard
    if e.errno != errno.EEXIST:
        print("Error creating: %s", CONFIG_PATH, file=log)

# ==========================================
# Helper functions for EPG path & image type
# ==========================================
def getRuntimeProfile(refresh=False):
    if not ensure_runtime_modules():
        return {
            "is_dreambox": False,
            "is_vuplus": False,
            "is_vti": False,
            "is_openatv": False,
            "is_openatv_python_313": False,
            "is_open_source_python_312_plus": False,
            "is_open_source_python_314_plus": False,
            "is_openpli": False,
            "is_oea": False,
            "python_version": "%s.%s.%s" % (sys.version_info[0], sys.version_info[1], sys.version_info[2]),
            "epg_dat_path": "/etc/enigma2/epg.dat",
            "epg_cache_path": "/etc/enigma2/epg.dat",
            "cleanup_candidates": ["/etc/enigma2/epg.dat"],
        }
    return EPGImport.get_runtime_profile(refresh=refresh)


def getEPGPath(refresh=False):
    return getRuntimeProfile(refresh=refresh).get("epg_dat_path", EPGImport.HDD_EPG_DAT)


def getEPGCachePath(refresh=False):
    return getRuntimeProfile(refresh=refresh).get("epg_cache_path", getEPGPath(refresh=refresh))


def getCleanupPaths(refresh=False):
    profile = getRuntimeProfile(refresh=refresh)
    return profile.get("cleanup_candidates", [getEPGCachePath(refresh=refresh), getEPGPath(refresh=refresh)])


def isPLiImage():
    return getRuntimeProfile().get("is_openpli", False)


def isOEAImage():
    return getRuntimeProfile().get("is_oea", False)


def isVTIImage():
    return getRuntimeProfile().get("is_vti", False)


def isOpenATVImage():
    return getRuntimeProfile().get("is_openatv", False)


def isOpenATVPython313():
    return getRuntimeProfile().get("is_openatv_python_313", False)

def getAlternatives(service):
    if not service:
        return None
    alternativeServices = eServiceCenter.getInstance().list(service)
    return alternativeServices and alternativeServices.getContent("S", True)

def getRefNum(ref):
    """
    Compute a compact numeric key from a service reference string.

    Enigma2 stores SID / TSID / ONID / DVBnamespace as 16-bit integers
    internally (max 65535).  IPTV providers frequently use service IDs
    larger than 65535 in their channel lists.  When Enigma2 creates an
    eServiceReference from such a string it silently masks each field
    to the low 16 bits.  We must do the same here so the lookup key we
    build matches the key Enigma2 has stored in its EPG cache.

    Format of a service reference (colon-separated fields, 0-indexed):
      [0] type  [1] flags  [2] ?? [3] SID  [4] TSID  [5] ONID  [6] DVBns ...
    """
    parts = ref.split(':')[3:7]
    try:
        sid  = int(parts[0], 16) & 0xFFFF
        tsid = int(parts[1], 16) & 0xFFFF
        onid = int(parts[2], 16) & 0xFFFF
        # DVBnamespace occupies the upper 16 bits of the 4th field
        dvbns_raw = int(parts[3], 16)
        dvbns = (dvbns_raw >> 16) & 0xFFFF
        return sid << 48 | tsid << 32 | onid << 16 | dvbns
    except Exception:
        return None

def _collectBouquetChannelList():
    channels = set()
    global filterCounter
    serviceHandler = eServiceCenter.getInstance()
    if serviceHandler is None:
        return channels
    mask = (eServiceReference.isMarker | eServiceReference.isDirectory)
    alternative_flag = eServiceReference.isGroup
    bouquet_roots = []
    favourite_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet')
    profile = getRuntimeProfile()
    relaxed_bouquet_probe = bool(
        profile.get("is_open_source_python_314_plus") or
        profile.get("is_openatv_python_313")
    )

    if config.usage.multibouquet.value:
        bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
        try:
            bouquet_list = serviceHandler.list(bouquet_root)
        except Exception as error:
            print("[EPGImport] Failed to list bouquets: %s" % error, file=log)
            bouquet_list = None
        if bouquet_list:
            while True:
                s = bouquet_list.getNext()
                if not s.valid():
                    break
                if s.flags & eServiceReference.isDirectory:
                    bouquet_roots.append(s)
                elif relaxed_bouquet_probe:
                    try:
                        clist = serviceHandler.list(s)
                    except Exception:
                        clist = None
                    if clist:
                        bouquet_roots.append(s)
        if relaxed_bouquet_probe and not bouquet_roots:
            bouquet_roots.append(favourite_root)
    else:
        bouquet_roots.append(favourite_root)

    for bouquet_root in bouquet_roots:
        try:
            services_list = serviceHandler.list(bouquet_root)
        except Exception as error:
            print("[EPGImport] Failed to list bouquet services: %s" % error, file=log)
            continue
        if not services_list:
            continue
        while True:
            service = services_list.getNext()
            filterCounter += 1
            if not service.valid():
                break
            if not (service.flags & mask):
                if service.flags & alternative_flag:
                    alt_list = getAlternatives(service)
                    if alt_list:
                        for channel in alt_list:
                            refnum = getRefNum(channel)
                            if refnum:
                                channels.add(refnum)
                else:
                    refnum = getRefNum(service.toString())
                    if refnum:
                        channels.add(refnum)
    return channels


def getBouquetChannelList():
    """Collect bouquet services while always releasing the filter-running flag."""
    global isFilterRunning
    isFilterRunning = 1
    try:
        return _collectBouquetChannelList()
    except Exception as error:
        print("[EPGImport] Failed to collect bouquet services: %s" % error, file=log)
        return set()
    finally:
        isFilterRunning = 0

def startImport():
    try:
        if not ensure_runtime_modules():
            raise Exception("runtime module import failed: %s" % runtime_import_error)
        if epgimport.isImportRunning():
            print("[EPGImport] Import or finalization already running; duplicate start ignored", file=log)
            return
        print("[EPGImport] startImport called", file=log)
        EPGConfig.clear_local_service_maps_cache()
        profile = getRuntimeProfile(refresh=True)
        # Keep the importer instance on the same freshly detected branch.  This
        # is important when selecting DreamOS/epg.db versus Open Source/epg.dat.
        epgimport.runtime_profile = dict(profile)
        EPGImport.HDD_EPG_DAT = profile.get("epg_dat_path", EPGImport.HDD_EPG_DAT)
        active_cache_path = profile.get("epg_cache_path", EPGImport.HDD_EPG_DAT)
        print(
            "[EPGImport] Runtime profile: Dreambox=%s VuPlus=%s VTI=%s OpenATV=%s OpenATV-Py3.13+=%s OpenSource-Py3.12+=%s OpenSource-Py3.14+=%s OpenPLi=%s OE-A=%s Python=%s" % (
                profile.get("is_dreambox"),
                profile.get("is_vuplus"),
                profile.get("is_vti"),
                profile.get("is_openatv"),
                profile.get("is_openatv_python_313"),
                profile.get("is_open_source_python_312_plus"),
                profile.get("is_open_source_python_314_plus"),
                profile.get("is_openpli"),
                profile.get("is_oea"),
                profile.get("python_version")
            ),
            file=log
        )
        print("[EPGImport] Using EPG DAT path: %s" % EPGImport.HDD_EPG_DAT, file=log)
        print("[EPGImport] Active cache path: %s" % active_cache_path, file=log)

        # Clearing current EPG before import
        if config.plugins.epgimport.clear_oldepg.value:
            try:
                from .clean import clear_current_epg
                cleanup_paths = getCleanupPaths(refresh=True)
                clear_name = clear_current_epg(epgimport.epgcache, cleanup_paths)
                if clear_name:
                    print("[EPGImport] Clearing current EPG using %s..." % clear_name, file=log)
                else:
                    print("[EPGImport] Current image has no live EPG clear method; backend replacement will clear it", file=log)
            except Exception as clear_error:
                print("[EPGImport] Failed to clear current EPG: %s" % clear_error, file=log)

        # Override Enigma2 EPG max days limit to prevent Open Source images from dropping events > 7 days
        try:
            if hasattr(config, "epg") and hasattr(config.epg, "maxdays"):
                requested_days = config.plugins.epgimport.longDescDays.value
                if config.epg.maxdays.value < requested_days:
                    print("[EPGImport] Adjusting system config.epg.maxdays from %s to %s to accommodate import" % (config.epg.maxdays.value, requested_days), file=log)
                    config.epg.maxdays.value = requested_days
                    config.epg.maxdays.save()
        except Exception as e:
            print("[EPGImport] Error adjusting config.epg.maxdays: %s" % e, file=log)

        epgimport.onDone = doneImport
        print("[EPGImport] Starting beginImport...", file=log)
        epgimport.beginImport(longDescUntil=config.plugins.epgimport.longDescDays.value * 24 * 3600 + time())
        print("[EPGImport] beginImport completed", file=log)
    except Exception as e:
        print("[EPGImport] Error in startImport:", e, file=log)
        traceback.print_exc(file=log)
        raise

def getVersion():
    """Read the displayed plugin version from version.txt."""
    version_file = join(os.path.dirname(os.path.realpath(__file__)), "version.txt")
    try:
        with open(version_file, "r") as handle:
            version = handle.read().strip()
        if version:
            return version
    except Exception as version_error:
        print("[EPGImport] Could not read version.txt: %s" % repr(version_error), file=log)
    return ""

# ==========================================
# GUI Classes
# ==========================================

class EPGImportConfig(ConfigListScreen, Screen):
    def __init__(self, session):
        ensure_runtime_modules()
        Screen.__init__(self, session)

        # Get version and set title
        version = getVersion()
        title_with_version = _('EPG Import Configuration') + " Ver: " + version
        Screen.setTitle(self, title_with_version)

        self["title"] = self["Title"] = StaticText(title_with_version)
        self.skinName = 'EPGImportConfig'
        self.skin = getSkin(self.skinName)
        self["status"] = Label()
        self["statusbar"] = Label(formatLastImport(config.plugins.extra_epgimport.last_import.value))
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Save"))
        self["key_yellow"] = Button(_("Manual"))
        self["key_blue"] = Button(_("Sources"))
        self["description"] = Label("")
        self["setupActions"] = ActionMap(
            ["SetupActions", "ColorActions", "TimerEditActions", "MovieSelectionActions"],
            {
                "red": self.keyCancel,
                "green": self.keyGreen,
                "yellow": self.doimport,
                "blue": self.dosources,
                "cancel": self.keyCancel,
                "ok": self.keyOk,
                "log": self.keyInfo,
                "contextMenu": self.openMenu,
            }, -1)
        ConfigListScreen.__init__(self, [], session)
        self.lastImportResult = None
        self.prev_onlybouquet = config.plugins.epgimport.import_onlybouquet.value
        self.initConfig()
        self.createSetup()
        self.filterStatusTemplate = _("Filtering: %s Please wait!")
        self.importStatusTemplate = _("Importing: %s %s events")
        self.updateTimer = eTimer()
        self.updateTimer_conn = connectTimer(self.updateTimer, self.updateStatus)
        self.updateTimer.start(2000)
        self.onLayoutFinish.append(self.updateStatus)
        self.onClose.append(self._cleanupScreenTimers)
        self.startTimer = None
        self.startTimer_conn = None

    def _cleanupScreenTimers(self):
        """Stop callbacks so closed configuration screens can be collected."""
        for timer_name in ('updateTimer', 'startTimer'):
            timer = getattr(self, timer_name, None)
            if timer is not None:
                try:
                    timer.stop()
                except Exception:
                    pass
        disconnectTimer(self.updateTimer, self.updateStatus, getattr(self, 'updateTimer_conn', None))
        if self.startTimer is not None:
            disconnectTimer(self.startTimer, self._startImportDelayed, getattr(self, 'startTimer_conn', None))
        self.updateTimer_conn = None
        self.startTimer_conn = None

    def initConfig(self):
        self.EPG = config.plugins.epgimport
        self.cfg_enabled = getConfigListEntry(_("Automatic import EPG"), self.EPG.enabled, _("When enabled, it allows you to schedule an automatic EPG update at the given days and time."))
        # Added the option to kill stuck processes to the settings interface
        self.cfg_killstuck = getConfigListEntry(_("Kill running import on start"), self.EPG.killstuck, _("Kill any stuck EPG import processes before starting new import"))
        self.cfg_source_import = getConfigListEntry(_("Source EPG"), self.EPG.extra_source, _("Specify the source for EPG."))
        self.cfg_wakeup = getConfigListEntry(_("Automatic start time"), self.EPG.wakeup, _("Specify the time for the automatic EPG update."))
        self.cfg_deepstandby = getConfigListEntry(_("When in deep standby"), self.EPG.deepstandby, _("Choose the action to perform when the box is in deep standby and the automatic EPG update should normally start."))
        self.cfg_shutdown = getConfigListEntry(_("Return to deep standby after import"), self.EPG.shutdown, _("This will turn back waked up box into deep-standby after automatic EPG import."))
        self.cfg_standby_afterwakeup = getConfigListEntry(_("Standby at startup"), self.EPG.standby_afterwakeup, _("The waked up box will be turned into standby after automatic EPG import wake up."))
        self.cfg_day_profile = getConfigListEntry(_("Choice days for start import"), self.EPG.day_profile, _("You can select the day(s) when the EPG update must be performed."))
        self.cfg_runboot = getConfigListEntry(_("Start import after booting up"), self.EPG.runboot, _("Specify in which case the EPG must be automatically updated after the box has booted."))
        self.cfg_import_onlybouquet = getConfigListEntry(_("Load EPG only services in bouquets"), self.EPG.import_onlybouquet, _("To save memory you can decide to only load EPG data for the services that you have in your bouquet files."))
        self.cfg_import_onlyiptv = getConfigListEntry(_('Load EPG only for IPTV channels'), self.EPG.import_onlyiptv, _("Load EPG for IPTV broadcasts only"))
        self.cfg_runboot_day = getConfigListEntry(_("Consider setting \"Days Profile\""), self.EPG.runboot_day, _("When you decide to load the EPG after GUI restart mention if the \"days profile\" must be take into consideration or not."))
        self.cfg_runboot_restart = getConfigListEntry(_("Skip import on restart GUI"), self.EPG.runboot_restart, _("When you restart the GUI you can decide to skip or not the EPG data import."))
        self.cfg_showinextensions = getConfigListEntry(_("Show \"EPGImport\" in extensions"), self.EPG.showinextensions, _("Display or not the EPGImport menu in the extension menu."))
        self.cfg_showinmainmenu = getConfigListEntry(_("Show \"EPGImport\" in main menu"), self.EPG.showinmainmenu, _("Display a shortcut \"EPGImport\" on your STB main screen."))
        self.cfg_longDescDays = getConfigListEntry(_("Load long descriptions up to X days"), self.EPG.longDescDays, _("Define the number of days that you want to get the full EPG data, reducing this number can help you to save memory usage on your box. But you are also limited with the EPG provider available data. You will not have 30 days EPG if it only provide 7 days data."))
        self.cfg_parse_autotimer = getConfigListEntry(_("Run AutoTimer after import"), self.EPG.parse_autotimer, _("You can start automatically the plugin AutoTimer after the EPG data update to have it refreshing its scheduling after EPG data refresh."))
        self.cfg_clear_oldepg = getConfigListEntry(_("Clearing current EPG before import"), config.plugins.epgimport.clear_oldepg, _("This will clear the current EPG data in memory before updating the EPG data. This allows you to always have a clean new EPG with the latest EPG data, for example in case of program changes between refresh, otherwise EPG data are cumulative."))
        self.cfg_stop_duplicates_sources = getConfigListEntry(_("Stop Duplicates Sources"), self.EPG.stop_duplicates_sources, _("Skip duplicated Rytec sources and duplicated EPG events during import. Event fingerprint uses channel service id, start time, stop time and title."))

    def createSetup(self):
        self.list = [self.cfg_enabled]
        if self.EPG.enabled.value:
            self.list.append(self.cfg_wakeup)
            self.list.append(self.cfg_deepstandby)
            if self.EPG.deepstandby.value == "wakeup":
                self.list.append(self.cfg_shutdown)
                if not self.EPG.shutdown.value:
                    self.list.append(self.cfg_standby_afterwakeup)
        self.list.append(self.cfg_day_profile)
        self.list.append(self.cfg_source_import)
        self.list.append(self.cfg_runboot)
        if self.EPG.runboot.value != "4":
            self.list.append(self.cfg_runboot_day)
            if self.EPG.runboot.value == "1" or self.EPG.runboot.value == "2":
                self.list.append(self.cfg_runboot_restart)
        self.list.append(self.cfg_showinextensions)
        self.list.append(self.cfg_showinmainmenu)
        # Add the option to kill stuck processes to the menu
        self.list.append(self.cfg_killstuck)
        self.list.append(self.cfg_import_onlybouquet)
        self.list.append(self.cfg_import_onlyiptv)
        self.list.append(self.cfg_stop_duplicates_sources)
        # This is a user preference, so keep it visible on every supported
        # receiver. The selected backend applies it using its safe image-specific
        # implementation.
        self.list.append(self.cfg_clear_oldepg)
        self.list.append(self.cfg_longDescDays)
        if fileExists(resolveFilename(SCOPE_PLUGINS, "Extensions/AutoTimer/plugin.py")):
            try:
                AutoTimer = _getAutoTimerClass()
                if AutoTimer is None:
                    raise ImportError('AutoTimer')
                self.list.append(self.cfg_parse_autotimer)
            except Exception:
                print("[EPGImport] AutoTimer Plugin not installed", file=log)
        self["config"].list = self.list
        self["config"].setList(self.list)

    # for summary:
    def getCurrentDescription(self):
        return self["config"].getCurrent() and len(self["config"].getCurrent()) > 2 and self["config"].getCurrent()[2] or ""

    def getCurrentEntry(self):
        self.updateDescription()
        return ConfigListScreen.getCurrentEntry(self)

    def updateDescription(self):
        self["description"].setText(self.getCurrentDescription())

    def getIndex(self):
        return (self["config"].getCurrentIndex(), len(self["config"].getList()) - 1)

    def keyUp(self):
        idx, length = self.getIndex()
        self["config"].setCurrentIndex(idx - 1 if idx > 0 else length)
        self.updateDescription()

    def keyDown(self):
        idx, length = self.getIndex()
        self["config"].setCurrentIndex(idx + 1 if idx < length else 0)
        self.updateDescription()

    def newConfig(self):
        cur = self["config"].getCurrent()
        if cur in (self.cfg_enabled, self.cfg_shutdown, self.cfg_deepstandby, self.cfg_runboot):
            self.createSetup()

    def keyGreen(self):
        self._cleanupScreenTimers()
        if not fileExists(resolveFilename(SCOPE_PLUGINS, "Extensions/AutoTimer/plugin.py")) and self.EPG.parse_autotimer.value:
            self.EPG.parse_autotimer.value = False
        if self.EPG.shutdown.value:
            self.EPG.standby_afterwakeup.value = False
        self.EPG.save()
        if self.prev_onlybouquet != config.plugins.epgimport.import_onlybouquet.value or (autoStartTimer is not None and autoStartTimer.prev_multibouquet != config.usage.multibouquet.value):
            EPGConfig.channelCache = {}
        self.close(True)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.newConfig()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.newConfig()

    def keyOk(self):
        ConfigListScreen.keyOK(self)
        sel = self["config"].getCurrent()[1]
        if sel and sel == self.EPG.day_profile:
            self.session.open(EPGImportProfile)

    def updateStatus(self):
        text = ""
        if isFilterRunning == 1:
            text = self.filterStatusTemplate % (str(filterCounter))
        elif epgimport is not None and epgimport.isImportRunning():
            src = epgimport.source
            if src and hasattr(src, 'description'):
                text = self.importStatusTemplate % (src.description, epgimport.eventCount or 0)
            else:
                text = "Importing EPG data..."
        self["status"].setText(text)

        if lastImportResult and (lastImportResult != self.lastImportResult):
            start, count = lastImportResult
            # Reject an invalid start timestamp (None, 0, or
            # negative) before passing it to FuzzyTime.  An unguarded call with
            # a bad value raises an exception that the bare 'except' below would
            # swallow silently, hiding the real error from the log.
            try:
                if not start or start <= 0:
                    raise ValueError("invalid start timestamp: %s" % start)
                try:
                    # Some open-source images (OpenPLi, OpenATV,
                    # VTI) accept the inPast keyword; others (Python 2.7
                    # Dreambox) only accept the positional argument.  Catch
                    # only TypeError (wrong kwarg) and fall back silently.
                    d, t = FuzzyTime(start, inPast=True)
                except TypeError:
                    d, t = FuzzyTime(start)
            except Exception as _fuzzy_err:
                print("[EPGImport] FuzzyTime error: %s" % _fuzzy_err, file=log)
                d, t = "?", "?"

            try:
                duration_text = "just completed"

                if hasattr(epgimport, 'startTime'):
                    if isinstance(epgimport.startTime, datetime):
                        start_timestamp = mktime(epgimport.startTime.timetuple())
                    else:
                        start_timestamp = epgimport.startTime
                    duration_seconds = time() - start_timestamp
                    duration_text = strftime('%H:%M:%S', gmtime(duration_seconds))
                else:
                    duration_text = "completed"

            except Exception as e:
                print("[EPGImport] Duration calculation error: " + str(e))
                duration_text = "completed"

            text = _("Last: %s %s, %d events") % (d, t, count) + _("\nCompleted in %s") % duration_text
            self["statusbar"].setText(text)
            self.lastImportResult = lastImportResult

    def keyInfo(self):
        last_import = config.plugins.extra_epgimport.last_import.value
        self.session.open(MessageBox, formatLastImport(last_import), type=MessageBox.TYPE_INFO)

    def doimport(self, one_source=None):
        if epgimport is None or epgimport.isImportRunning():
            print("[EPGImport] Already running, won't start again", file=log)
            self.session.open(MessageBox, _("EPGImport\nImport of epg data is still in progress. Please wait."), MessageBox.TYPE_ERROR, timeout=10, close_on_any_key=True)
            return
        try:
            EPGConfig.channelCache = {}
            if one_source is None:
                cfg = EPGConfig.loadUserSettings()
            else:
                cfg = one_source

            sources = [s for s in EPGConfig.enumSources(CONFIG_PATH, filter=cfg["sources"])]
            if not sources:
                self.session.open(MessageBox, _("No active EPG sources found, nothing to do"), MessageBox.TYPE_INFO, timeout=10, close_on_any_key=True)
                return
            # make it a stack, first on top.
            sources.reverse()
            epgimport.sources = sources
            self.session.openWithCallback(self.do_import_callback, MessageBox, _("EPGImport\nImport of epg data will start.\nThis may take a few minutes.\nIs this ok?"), MessageBox.TYPE_YESNO, timeout=15, default=True)
        except Exception as e:
            print("[EPGImport] Error in doimport:", e, file=log)
            traceback.print_exc(file=log)
            try:
                self.session.open(MessageBox, _("EPGImport Plugin\nError preparing import:\n") + str(e), MessageBox.TYPE_ERROR, timeout=15, close_on_any_key=True)
            except Exception:
                pass

    def do_import_callback(self, confirmed):
        if not confirmed:
            return
        # Use a simple timer to defer the import start - more stable for DreamBox
        self.startTimer = eTimer()
        self.startTimer_conn = connectTimer(self.startTimer, self._startImportDelayed)
        self.startTimer.start(1000, True)  # Start after 1 second
        print("[EPGImport] Scheduled import to start via timer", file=log)
        self.updateStatus()

    def _startImportDelayed(self):
        # This function is called from timer
        try:
            print("[EPGImport] Starting import process (delayed)...", file=log)
            startImport()
            print("[EPGImport] Import process started successfully", file=log)
        except Exception as e:
            print("[EPGImport] Error at start:", e, file=log)
            traceback.print_exc(file=log)
            try:
                self.session.open(MessageBox, _("EPGImport Plugin\nFailed to start:\n") + str(e), MessageBox.TYPE_ERROR, timeout=15, close_on_any_key=True)
            except Exception:
                pass
        finally:
            if hasattr(self, 'startTimer') and self.startTimer is not None:
                self.startTimer.stop()

    def openMenu(self):
        menu = [(_("Show log"), self.showLog), (_("Ignore services list"), self.openIgnoreList), (_("Delete PYC/PYO files"), self.deletePycPyo)]
        text = _("Select action")

        def setAction(choice):
            if choice:
                choice[1]()
        self.session.openWithCallback(setAction, ChoiceBox, title=text, list=menu)

    def deletePycPyo(self):
        """Delete PYC and PYO files"""
        try:
            deleted_count = deletePycPyoFiles()
            if deleted_count > 0:
                self.session.open(MessageBox, _("Deleted %d PYC/PYO files") % deleted_count, MessageBox.TYPE_INFO, timeout=5)
            else:
                self.session.open(MessageBox, _("No PYC/PYO files found to delete"), MessageBox.TYPE_INFO, timeout=5)
        except Exception as e:
            self.session.open(MessageBox, _("Error deleting PYC/PYO files: %s") % str(e), MessageBox.TYPE_ERROR, timeout=5)

    def openIgnoreList(self):
        self.session.open(filtersServices.filtersServicesSetup)

    def showLog(self):
        self.session.open(EPGImportLog)

    def dosources(self):
        # Open the source screen directly; it handles its own result callbacks.
        try:
            self.session.open(EPGImportSources)
        except Exception as e:
            print("[EPGImport] Error opening sources screen:", e, file=log)
            self.session.open(MessageBox, _("Error opening sources: %s") % str(e), MessageBox.TYPE_ERROR, timeout=10)

    def sourcesDone(self, confirmed, sources, cfg):
        # Called with True and list of config items on Okay.
        if cfg is not None:
            self.doimport(one_source=cfg)

class EPGImportSources(Screen):
    skinName = "EPGImportSources"

    def __init__(self, session):
        ensure_runtime_modules()
        self.skin = getSkin(self.skinName)
        Screen.__init__(self, session)
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Save"))
        self["key_yellow"] = Button(_("Import"))
        self["key_blue"] = Button(_("Import from Git"))
        self.container = None
        self.tree = []
        self.giturl = SOURCE_LINKS.get(config.plugins.epgimport.extra_source.value)
        self._source_update_running = False
        self._source_screen_closed = False
        self.onClose.append(self._markSourceScreenClosed)

        cfg = EPGConfig.loadUserSettings()
        filter = cfg["sources"]
        cat = None
        for x in EPGConfig.enumSources(CONFIG_PATH, filter=None, categories=True):
            if hasattr(x, "description"):
                sel = (filter is None) or (x.description in filter)
                entry = (x.description, x.description, sel)
                if cat is None:
                    # If no category defined, use a default one.
                    cat = ExpandableSelectionList.category("[.]")
                    self.tree.append(cat)
                cat[0][2].append(entry)
                if sel:
                    ExpandableSelectionList.expand(cat, True)
            else:
                cat = ExpandableSelectionList.category(x)
                self.tree.append(cat)
        self["list"] = ExpandableSelectionList.ExpandableSelectionList(self.tree, enableWrapAround=True)
        if self.tree:
            self["key_yellow"].show()
        else:
            self["key_yellow"].hide()
        self["setupActions"] = ActionMap(
            [
                "SetupActions",
                "ColorActions",
                "MenuActions"
            ],
            {
                "red": self.cancel,
                "green": self.save,
                "yellow": self.do_import,
                "blue": self.git_import,
                "save": self.save,
                "cancel": self.cancel,
                "menu": self.do_reset,
                "ok": self["list"].toggleSelection
            },
            -2
        )
        self.setTitle(_("EPG Import Sources"))

    def _markSourceScreenClosed(self):
        self._source_screen_closed = True

    def git_import(self):
        self.session.openWithCallback(
            self.install_update,
            MessageBox,
            _("Do you want to update Source now?\n\nWait for the import successful message!"),
            MessageBox.TYPE_YESNO,
            timeout=15
        )

    def install_update(self, answer=False):
        if answer:
            try:
                from . import import_source
                from twisted.internet import threads as twisted_threads
            except Exception as e:
                self.session.open(
                    MessageBox,
                    _("Import failed with error: {}").format(e),
                    MessageBox.TYPE_ERROR,
                    timeout=10,
                    close_on_any_key=True
                )
                return

            if getattr(self, '_source_update_running', False):
                return
            self._source_update_running = True
            self.session.open(
                MessageBox,
                _("Updating EPG sources in the background..."),
                MessageBox.TYPE_INFO,
                timeout=5
            )
            deferred = twisted_threads.deferToThread(import_source.main, self.giturl)
            deferred.addCallback(self._source_update_done)
            deferred.addErrback(self._source_update_failed)

        else:
            self.session.open(
                MessageBox,
                _("Update Aborted!"),
                MessageBox.TYPE_INFO,
                timeout=10
            )

    def _source_update_done(self, _result):
        self._source_update_running = False
        if self._source_screen_closed:
            return
        self.refresh_tree()
        self.session.open(
            MessageBox,
            _("EPG sources updated successfully."),
            MessageBox.TYPE_INFO,
            timeout=8
        )

    def _source_update_failed(self, failure):
        self._source_update_running = False
        if self._source_screen_closed:
            return
        try:
            message = failure.getErrorMessage()
        except Exception:
            message = str(failure)
        self.session.open(
            MessageBox,
            _("Import failed with error: {}" ).format(message),
            MessageBox.TYPE_ERROR,
            timeout=10,
            close_on_any_key=True
        )

    def refresh_tree(self):
        print("Refreshing tree...")
        cfg = EPGConfig.loadUserSettings()
        filter = cfg["sources"]
        self.tree = []
        cat = None
        try:
            sources_list = list(EPGConfig.enumSources(CONFIG_PATH, filter=None, categories=True))
            if not sources_list:
                self.session.open(
                    MessageBox,
                    _("No sources found after update!"),
                    MessageBox.TYPE_WARNING,
                    timeout=10
                )
                return

            for x in sources_list:
                if hasattr(x, "description"):
                    sel = (filter is None) or (x.description in filter)
                    entry = (x.description, x.description, sel)
                    if cat is None:
                        cat = ExpandableSelectionList.category("[.]")
                        self.tree.append(cat)
                    if cat and cat[0] and len(cat[0]) > 2:
                        cat[0][2].append(entry)
                        if sel:
                            ExpandableSelectionList.expand(cat, True)
                else:
                    cat = ExpandableSelectionList.category(x)
                    self.tree.append(cat)

            self["list"].tree = self.tree
            self["list"].updateFlatList()

            if self.tree:
                self["key_yellow"].show()
            else:
                self["key_yellow"].hide()

            msg = _("Sources updated successfully!")
            self.session.open(
                MessageBox,
                msg,
                MessageBox.TYPE_INFO,
                timeout=10
            )

        except Exception as e:
            print("[EPGImport] Error in refresh_tree:", str(e))
            self.session.open(
                MessageBox,
                _("Error refreshing sources: {}").format(str(e)),
                MessageBox.TYPE_ERROR,
                timeout=10
            )

    def save(self):
        """ Make the entries unique through a set """
        sources = list(set([item[1] for item in self["list"].enumSelected()]))
        print("[EPGImport] Selected sources: %s" % sources, file=log)
        EPGConfig.storeUserSettings(sources=sources)
        self.close(True, sources, None)

    def cancel(self):
        self.close(False, None, None)

    def do_import(self):
        if self._source_update_running:
            self.session.open(
                MessageBox,
                _("Please wait until the source update is complete."),
                MessageBox.TYPE_INFO,
                timeout=8
            )
            return
        current = self["list"].getCurrent()
        flat_list = getattr(self["list"], "flat_list", [])
        if current or flat_list:
            try:
                item = current[0] if current else None
                if item is None or hasattr(item[2], "append"):
                    raise Exception("Please select a source entry, not a category")
                source = [item[1] or ""]
                cfg = {"sources": source}
                print("[EPGImport] Selected source: " + str(source), file=log)
            except Exception as e:
                print("[EPGImport] Error at selected source: " + str(e), file=log)
            else:
                # Continue only when at least one source was selected.
                if cfg["sources"]:
                    self.close(False, None, cfg)

    def do_reset(self):
        # DreamOS uses epg.db, so skip the binary epg.dat reset.
        if isDreamOS:
            return
        # config.misc.epgcache_filename is not present on every image.
        # Open Source images (OpenPLi, OpenATV, VTI, Python 3.14.6) do not have
        # this attribute; accessing it raises AttributeError and previously caused
        # an unhandled exception that froze the Sources screen.
        try:
            from .epgdb import epgdb_class
            epgdbfile = config.misc.epgcache_filename.value
        except AttributeError:
            print("[EPGImport] do_reset: config.misc.epgcache_filename not available on this image", file=log)
            self.session.open(MessageBox, _("Reset EPG database is not supported on this image."), MessageBox.TYPE_INFO, timeout=6)
            return
        except Exception as e:
            print("[EPGImport] do_reset: failed to import epgdb or read config: %s" % repr(e), file=log)
            self.session.open(MessageBox, _("Reset EPG failed: %s") % str(e), MessageBox.TYPE_ERROR, timeout=8)
            return
        print("[XMLTVImport] is located at %s" % epgdbfile, file=log)
        provider_name = "Rytec XMLTV"
        provider_priority = 99
        self.epg = epgdb_class(provider_name, provider_priority, epgdbfile)
        self.epg.create_empty()
        print("[XMLTVImport] loading empty epg.db", file=log)
        self.epginstance = eEPGCache.getInstance()
        eEPGCache.load(self.epginstance)
        self.session.open(MessageBox, _("EPG database was emptied"), MessageBox.TYPE_INFO)

class EPGImportProfile(ConfigListScreen, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        Screen.setTitle(self, _("Days Profile"))
        self["Title"] = self["title"] = StaticText(_("Days Profile"))
        self.skinName = 'EPGImportProfile'
        self.skin = getSkin(self.skinName)
        self.list = []
        weekdays = list(day_name)
        for i in range(7):
            self.list.append(getConfigListEntry(weekdays[i], config.plugins.extra_epgimport.day_import[i]))
        ConfigListScreen.__init__(self, self.list)
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Save"))
        self["setupActions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {
                "red": self.keyCancel,
                "green": self.save,
                "save": self.save,
                "cancel": self.keyCancel,
                "ok": self.save,
            }, -2)
        self.onLayoutFinish.append(self.createSummary)

    def save(self):
        if not any(config.plugins.extra_epgimport.day_import[i].value for i in range(0, 7)):
            self.session.open(MessageBox, _("You may not use this settings!\nAt least one day a week should be included!"), MessageBox.TYPE_INFO, timeout=6)
            return
        ConfigListScreen.keySave(self)

class EPGImportLog(Screen):
    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        Screen.setTitle(self, _("EPG Import Log"))
        self["Title"] = self["title"] = StaticText(_("EPG Import Log"))
        self.skinName = 'EPGImportLog'
        self.skin = getSkin(self.skinName)
        self["key_red"] = Button(_("Clear"))
        self["key_green"] = Button()
        self["key_yellow"] = Button()
        self["key_blue"] = Button(_("Save"))
        self["list"] = ScrollLabel(log.getvalue())
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "red": self.clear,
                "green": self.cancel,
                "yellow": self.cancel,
                "save": self.save,
                "blue": self.save,
                "cancel": self.cancel,
                "ok": self.cancel,
                "left": self["list"].pageUp,
                "right": self["list"].pageDown,
                "up": self["list"].pageUp,
                "down": self["list"].pageDown,
                "pageUp": self["list"].pageUp,
                "pageDown": self["list"].pageDown
            }, -2)

        self.timer = eTimer()
        self.timer_conn = connectTimer(self.timer, self.getLog)
        self.timer.start(3000)
        self.onLayoutFinish.append(self.getLog)
        self.onClose.append(self.__onClose)
        self.counter = 0

    def __onClose(self):
        self.timer.stop()
        disconnectTimer(self.timer, self.getLog, getattr(self, 'timer_conn', None))
        self.timer_conn = None

    def getLog(self):
        txt = log.getvalue()
        counter = len(txt)
        if not self.counter:
            self["list"].setText(txt)
        elif counter > self.counter:
            if isDreamOS:
                self["list"].setText(txt)
                self["list"].lastPage()
            else:
                self["list"].setText(txt, showBottom=True)
        self.counter = counter

    def save(self):
        try:
            with open('/tmp/epgimport.log', 'w') as f:
                f.write(log.getvalue())
            self.session.open(MessageBox, _("Write to /tmp/epgimport.log"), MessageBox.TYPE_INFO, timeout=5, close_on_any_key=True)
        except Exception as e:
            self["list"].setText(_("Failed to write /tmp/epgimport.log: %s") % str(e))
        self.close(True)

    def cancel(self):
        self.close(False)

    def clear(self):
        log.clear()
        self.close(False)

class EPGImportDownloader(MessageBox):
    def __init__(self, session):
        MessageBox.__init__(self, session, _("Last import: ") + config.plugins.extra_epgimport.last_import.value + _(" events\n") + _("\nImport of epg data will start.\nThis may take a few minutes.\nIs this ok?"), MessageBox.TYPE_YESNO)
        self.skinName = "MessageBox"

def msgClosed(ret):
    if ret:
        if autoStartTimer is not None and epgimport is not None and not epgimport.isImportRunning():
            print("[EPGImport] Run manual starting import", file=log)
            autoStartTimer.runImport()

def start_import(session, **kwargs):
    session.openWithCallback(msgClosed, EPGImportDownloader)

def main(session, **kwargs):
    if not ensure_runtime_modules():
        session.open(MessageBox, _("EPGImport load error: %s") % str(runtime_import_error), MessageBox.TYPE_ERROR, timeout=15)
        return
    # Clear log at start of plugin operation
    try:
        log.clear()
    except Exception:
        pass
    # Delete pyc/pyo files when plugin starts
    deletePycPyoFiles()
    session.openWithCallback(doneConfiguring, EPGImportConfig)

def run_from_main_menu(menuid, **kwargs):
    if menuid == "mainmenu" and config.plugins.epgimport.showinmainmenu.getValue():
        return [(_("EPGImport"), main, "epgimporter", 45)]
    else:
        return []

def run_from_epg_menu(menuid, **kwargs):
    if menuid == "epg" and config.plugins.epgimport.showinmainmenu.getValue():
        return [(_("EPG-Importer"), main, "epgimporter", 90)]
    else:
        return []

def epgmenu(menuid, **kwargs):
    if menuid == "setup":
        return [(_("EPGImport"), main, "epgimporter", 1002)]
    else:
        return []

def doneConfiguring(retval=False):
    if retval is True:
        if autoStartTimer is not None:
            autoStartTimer.update()

def doneImport(reboot=False, epgfile=None):
    if not ensure_runtime_modules():
        return
    global lastImportResult, BouquetChannelListList, serviceIgnoreList
    BouquetChannelListList = None
    serviceIgnoreList = None
    event_count = epgimport.eventCount if epgimport.eventCount is not None else 0
    lastImportResult = (time(), event_count)

    # Handle different image types
    profile = getRuntimeProfile(refresh=True)
    is_pli = profile.get("is_openpli", False)
    is_oea = profile.get("is_oea", False)
    is_vti = profile.get("is_vti", False)
    is_openatv_py313 = profile.get("is_openatv_python_313", False)

    # All supported backends are activated in-process; restarts are forbidden.
    if EPGImport.should_skip_restart():
        reboot = False
        if profile.get("is_dreambox", False):
            print("[EPGImport] DreamOS detected - reboot forced to False, NO RESTART will occur", file=log)
        elif is_openatv_py313:
            print("[EPGImport] openATV Python 3.13+ detected - NO RESTART needed", file=log)
        elif profile.get("is_open_source_python_312_plus", False):
            # Python 3.12+ open-source images (OpenPLi, OpenATV, VTI,
            # OE-A) and Python 3.14.6 images all share this branch.
            # eEPGCache.load() is called directly after import so no Enigma2
            # restart is needed to make EPG events visible on-screen.
            pyver = profile.get("python_version", "3.12+")
            print("[EPGImport] Open Source Python %s detected - NO RESTART needed (load() used directly)" % pyver, file=log)
        elif is_vti:
            print("[EPGImport] VTI detected - NO RESTART needed", file=log)
        elif is_pli:
            print("[EPGImport] PLi detected - NO RESTART needed", file=log)
        elif is_oea:
            print("[EPGImport] OE-A detected - NO RESTART needed", file=log)
    try:
        start, count = lastImportResult
        localtimes = strftime('%d %b %Y %H:%M:%S', localtime(time()))
        lastimport = "%s, %d" % (localtimes, count)
        print("[EPGImport] Save last import date and count event: %d events" % count, file=log)
        config.plugins.extra_epgimport.last_import.value = lastimport
        config.plugins.extra_epgimport.last_import.save()
    except Exception as e:
        print("[EPGImport] Error to save last import date and count event: %s" % str(e), file=log)

    # Only allow restart on images that need it
    if reboot and not EPGImport.should_skip_restart():
        if Screens.Standby.inStandby:
            print("[EPGImport] Restart enigma2", file=log)
            restartEnigma(True)
        else:
            msg = _("EPG Import finished, %d events") % event_count + "\n" + _("You must restart Enigma2 to load the EPG data,\nis this OK?")
            _session.openWithCallback(restartEnigma, MessageBox, msg, MessageBox.TYPE_YESNO, timeout=15, default=True)
            print("[EPGImport] Need restart enigma2", file=log)
    else:
        print("[EPGImport] No restart needed (reboot=%s)" % reboot, file=log)

    if not reboot:
        if config.plugins.epgimport.parse_autotimer.value and fileExists(resolveFilename(SCOPE_PLUGINS, "Extensions/AutoTimer/plugin.py")):
            try:
                from Plugins.Extensions.AutoTimer.plugin import autotimer
                if autotimer is None:
                    AutoTimer = _getAutoTimerClass()
                    if AutoTimer is None:
                        raise ImportError('AutoTimer')
                    autotimer = AutoTimer()
                autotimer.readXml()
                checkDeepstandby(_session, parse=True)
                autotimer.parseEPGAsync(simulateOnly=False)
                print("[EPGImport] Run start parse autotimers", file=log)
            except Exception:
                print("[EPGImport] Could not start autotimers", file=log)
                checkDeepstandby(_session, parse=False)
        else:
            checkDeepstandby(_session, parse=False)

class checkDeepstandby(object):
    def __init__(self, session, parse=False):
        self.session = session
        if parse:
            self.FirstwaitCheck = eTimer()
            self.FirstwaitCheck_conn = connectTimer(self.FirstwaitCheck, self.runCheckDeepstandby)
            self.FirstwaitCheck.startLongTimer(600)
            print("[EPGImport] Wait for parse autotimers 30 sec.", file=log)
        else:
            self.runCheckDeepstandby()

    def runCheckDeepstandby(self):
        print("[EPGImport] Run check deep standby after import", file=log)
        if config.plugins.epgimport.shutdown.value and config.plugins.epgimport.deepstandby.value == 'wakeup':
            if config.plugins.epgimport.deepstandby_afterimport.value and getFPWasTimerWakeup():
                config.plugins.epgimport.deepstandby_afterimport.value = False
                if Screens.Standby.inStandby and not self.session.nav.getRecordings() and not Screens.Standby.inTryQuitMainloop:
                    print("[EPGImport] Returning to deep standby after wake up for import", file=log)
                    self.session.open(Screens.Standby.TryQuitMainloop, 1)
                else:
                    print("[EPGImport] No return to deep standby, not standby or running recording", file=log)

def restartEnigma(confirmed):
    if not confirmed:
        return
    # Save state of Enigma2 so we can return to the previous standby state
    if Screens.Standby.inStandby:
        try:
            with open('/tmp/enigmastandby', 'wb'):
                pass
        except Exception:
            print("Failed to create /tmp/enigmastandby", file=log)
    else:
        try:
            remove("/tmp/enigmastandby")
        except Exception:
            pass
    # Restart Enigma2 (TryQuitMainloop code 3 = restart)
    _session.open(Screens.Standby.TryQuitMainloop, 3)

##################################
# Autostart section
class AutoStartTimer(object):
    def __init__(self, session):
        self.session = session
        self.prev_onlybouquet = config.plugins.epgimport.import_onlybouquet.value
        self.prev_multibouquet = config.usage.multibouquet.value
        self.timer = eTimer()
        self.pauseAfterFinishImportCheck = eTimer()
        self.timer_conn = connectTimer(self.timer, self.onTimer)
        self.pauseAfterFinishImportCheck_conn = connectTimer(self.pauseAfterFinishImportCheck, self.afterFinishImportCheck)

        self.pauseAfterFinishImportCheck.startLongTimer(30)
        self.update()

    def getWakeTime(self):
        if config.plugins.epgimport.enabled.value:
            clock = config.plugins.epgimport.wakeup.value
            nowt = time()
            now = localtime(nowt)
            return int(mktime((now.tm_year, now.tm_mon, now.tm_mday, clock[0], clock[1], 0, 0, now.tm_yday, now.tm_isdst)))
        else:
            return -1

    def update(self, atLeast=0):
        self.timer.stop()
        wake = self.getWakeTime()
        now_t = time()
        now = int(now_t)
        now_day = localtime(now_t)
        if wake > 0:
            cur_day = int(now_day.tm_wday)
            wakeup_day = WakeupDayOfWeek()
            if wakeup_day == -1:
                print("[EPGImport] wakeup day of week disabled", file=log)
                return -1
            if wake < now + atLeast:
                wake += 86400 * wakeup_day
            else:
                if not config.plugins.extra_epgimport.day_import[cur_day].value:
                    wake += 86400 * wakeup_day
            next = wake - now
            self.timer.startLongTimer(next)
        else:
            wake = -1
        print("[EPGImport] WakeUpTime now set to", strftime('%c', localtime(wake)), "(now=%s)" % strftime('%c', localtime(now)), file=log)
        return wake

    def runImport(self):
        # Start cleanup asynchronously and let Enigma2 continue painting/responding.
        if config.plugins.epgimport.killstuck.value:
            print("[EPGImport] Killing stuck EPG import processes before starting new import", file=log)
            _terminate_stuck_import_processes(getRuntimeProfile(refresh=True))
            self.cleanupDelayTimer = eTimer()
            self.cleanupDelayTimer_conn = connectTimer(self.cleanupDelayTimer, self._runImportAfterCleanup)
            self.cleanupDelayTimer.start(2000, True)
            return

        self._runImportAfterCleanup()

    def _runImportAfterCleanup(self):
        cleanup_timer = getattr(self, 'cleanupDelayTimer', None)
        if cleanup_timer is not None:
            try:
                cleanup_timer.stop()
            except Exception:
                pass

        if epgimport.isImportRunning():
            print("[EPGImport] Scheduled import skipped because another import is active", file=log)
            return

        if self.prev_onlybouquet != config.plugins.epgimport.import_onlybouquet.value or self.prev_multibouquet != config.usage.multibouquet.value:
            self.prev_onlybouquet = config.plugins.epgimport.import_onlybouquet.value
            self.prev_multibouquet = config.usage.multibouquet.value
        EPGConfig.channelCache = {}
        cfg = EPGConfig.loadUserSettings()
        sources = [s for s in EPGConfig.enumSources(CONFIG_PATH, filter=cfg["sources"])]
        if sources:
            sources.reverse()
            epgimport.sources = sources
            startImport()

    def onTimer(self):
        self.timer.stop()
        now = int(time())
        print("[EPGImport] onTimer occured at", strftime('%c', localtime(now)), file=log)
        wake = self.getWakeTime()
        # If we're close enough, we're okay...
        atLeast = 0
        if wake - now < 60:
            self.runImport()
            atLeast = 60
        self.update(atLeast)

    def getSources(self):
        cfg = EPGConfig.loadUserSettings()
        return bool(list(EPGConfig.enumSources(CONFIG_PATH, filter=cfg["sources"])))

    def getStatus(self):
        wake_up = self.getWakeTime()
        now_t = time()
        now = int(now_t)
        now_day = localtime(now_t)
        if wake_up > 0:
            cur_day = int(now_day.tm_wday)
            wakeup_day = WakeupDayOfWeek()
            if wakeup_day == -1:
                print("[EPGImport] wakeup day of week disabled", file=log)
                return -1
            if wake_up < now:
                wake_up += 86400 * wakeup_day
            else:
                if not config.plugins.extra_epgimport.day_import[cur_day].value:
                    wake_up += 86400 * wakeup_day
        else:
            wake_up = -1
        return wake_up

    def afterFinishImportCheck(self):
        if config.plugins.epgimport.deepstandby.value == 'wakeup' and getFPWasTimerWakeup():
            if exists("/tmp/enigmastandby") or exists("/tmp/.EPGImportAnswerBoot"):
                print("[EPGImport] is restart enigma2", file=log)
            else:
                wake = self.getStatus()
                now_t = time()
                now = int(now_t)
                if 0 < wake - now <= 60 * 5:
                    if config.plugins.epgimport.standby_afterwakeup.value:
                        if not Screens.Standby.inStandby:
                            Notifications.AddNotification(Screens.Standby.Standby)
                            print("[EPGImport] Run to standby after wake up", file=log)
                    if config.plugins.epgimport.shutdown.value:
                        if not config.plugins.epgimport.standby_afterwakeup.value:
                            if not Screens.Standby.inStandby:
                                Notifications.AddNotification(Screens.Standby.Standby)
                                print("[EPGImport] Run to standby after wake up for checking", file=log)
                        if not config.plugins.epgimport.deepstandby_afterimport.value:
                            config.plugins.epgimport.deepstandby_afterimport.value = True
                            self.wait_timer = eTimer()
                            self.wait_timer_conn = connectTimer(self.wait_timer, self.startStandby)
                            self.wait_timer.start(10000, True)
                            print("[EPGImport] start wait_timer (10sec) for goto standby", file=log)

    def startStandby(self):
        if Screens.Standby.inStandby:
            print("[EPGImport] add checking standby", file=log)
            try:
                Screens.Standby.inStandby.onClose.append(self.onLeaveStandby)
            except Exception:
                pass

    def onLeaveStandby(self):
        if config.plugins.epgimport.deepstandby_afterimport.value:
            config.plugins.epgimport.deepstandby_afterimport.value = False
            print("[EPGImport] checking standby remove, not deep standby after import", file=log)

def WakeupDayOfWeek():
    start_day = -1
    try:
        now = time()
        now_day = localtime(now)
        cur_day = int(now_day.tm_wday)
    except Exception:
        cur_day = -1
    if cur_day >= 0:
        for i in range(1, 8):
            if config.plugins.extra_epgimport.day_import[(cur_day + i) % 7].value:
                return i
    return start_day

def onBootStartCheck():
    print("[EPGImport] onBootStartCheck", file=log)
    now = int(time())
    wake = autoStartTimer.getStatus()
    print("[EPGImport] now=%d wake=%d wake-now=%d" % (now, wake, wake - now), file=log)
    if (wake < 0) or (wake - now > 600):
        on_start = False
        if config.plugins.epgimport.runboot.value == "1":
            on_start = True
            print("[EPGImport] is boot", file=log)
        elif config.plugins.epgimport.runboot.value == "2" and not getFPWasTimerWakeup():
            on_start = True
            print("[EPGImport] is manual boot", file=log)
        elif config.plugins.epgimport.runboot.value == "3" and getFPWasTimerWakeup():
            on_start = True
            print("[EPGImport] is automatic boot", file=log)
        flag = '/tmp/.EPGImportAnswerBoot'
        if config.plugins.epgimport.runboot_restart.value and config.plugins.epgimport.runboot.value != "3":
            if exists(flag):
                on_start = False
                print("[EPGImport] not starting import - is restart enigma2", file=log)
            else:
                try:
                    with open(flag, 'wb'):
                        pass
                except Exception:
                    print("Failed to create /tmp/.EPGImportAnswerBoot", file=log)
        if config.plugins.epgimport.runboot_day.value:
            now = localtime()
            cur_day = int(now.tm_wday)
            if not config.plugins.extra_epgimport.day_import[cur_day].value:
                on_start = False
                print("[EPGImport] wakeup day of week does not match", file=log)
        if on_start:
            print("[EPGImport] starting import because auto-run on boot is enabled", file=log)
            autoStartTimer.runImport()
    else:
        print("[EPGImport] import to start in less than 10 minutes anyway, skipping...", file=log)

def autostart(reason, session=None, **kwargs):
    "called with reason=1 to during shutdown, with reason=0 at startup?"
    global autoStartTimer
    global _session
    print("[EPGImport] autostart (%s) occured at %s" % (reason, strftime('%c', localtime(time()))), file=log)
    if reason == 0 and _session is None:
        if not ensure_runtime_modules():
            return
        if session is not None:
            _session = session
            if autoStartTimer is None:
                autoStartTimer = AutoStartTimer(session)
            if config.plugins.epgimport.runboot.value != "4":
                onBootStartCheck()
    # If WE caused the reboot, put the box back in standby.
    if reason == 0 and exists("/tmp/enigmastandby"):
        print("[EPGImport] Returning to standby", file=log)
        if not Screens.Standby.inStandby:
            Notifications.AddNotification(Screens.Standby.Standby)
        try:
            remove("/tmp/enigmastandby")
        except Exception:
            pass
    elif reason != 0:
        print("[EPGImport] Stop", file=log)

def getNextWakeup():
    "returns timestamp of next time when autostart should be called"
    if autoStartTimer:
        if config.plugins.epgimport.deepstandby.value == 'wakeup' and autoStartTimer.getSources():
            print("[EPGImport] Will wake up from deep sleep", file=log)
            return autoStartTimer.getStatus()
    return -1


# we need this helper function to identify the descriptor
description = _("Automated EPG Importer")
config.plugins.epgimport.showinextensions.addNotifier(setExtensionsmenu, initial_call=False, immediate_feedback=False)
extDescriptor = PluginDescriptor(name=_("EPGImport"), description=description, where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=extensionsmenu)

def Plugins(**kwargs):
    result = []

    # Add the plugin to the plugins menu (always)
    result.append(
        PluginDescriptor(
            name=_("EPGImport"),
            description=_("Automated EPG Importer"),
            where=[PluginDescriptor.WHERE_PLUGINMENU],
            icon="icon/plugin.png",
            fnc=main,
        )
    )

    # Add the plugin to the main menu if enabled
    if config.plugins.epgimport.showinmainmenu.value:
        result.append(
            PluginDescriptor(
                name=_("EPGImport now"),
                description=_("Start EPG import immediately"),
                where=[PluginDescriptor.WHERE_MENU],
                icon="icon/plugin.png",
                fnc=run_from_main_menu,
            )
        )
        result.append(
            PluginDescriptor(
                name=_("EPGImport"),
                description=_("Automated EPG Importer"),
                where=[PluginDescriptor.WHERE_MENU],
                fnc=run_from_epg_menu,
            )
        )

    # Add the plugin to the setup menu
    result.append(
        PluginDescriptor(
            name=_("EPGImport"),
            description=_("Automated EPG Importer"),
            where=[PluginDescriptor.WHERE_MENU],
            fnc=epgmenu,
        )
    )

    # Add the plugin to the extensions menu if enabled
    if config.plugins.epgimport.showinextensions.value:
        result.append(
            PluginDescriptor(
                name=_("EPGImport"),
                description=_("Automated EPG Importer"),
                where=[PluginDescriptor.WHERE_EXTENSIONSMENU],
                icon="icon/plugin.png",
                fnc=extensionsmenu,
            )
        )

    # Add the plugin for autostart
    result.append(
        PluginDescriptor(
            name=_("EPGImport"),
            description=_("Automated EPG Importer"),
            where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART],
            icon="icon/plugin.png",
            fnc=autostart,
            wakeupfnc=getNextWakeup,
        )
    )

    return result
