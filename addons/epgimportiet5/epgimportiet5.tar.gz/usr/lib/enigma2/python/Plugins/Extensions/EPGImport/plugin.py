#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function
#
# The code modified by Lululla
# The code modified by iet5 Date Nov 2025
#
# =========================
# Standard library imports
# =========================
import os
import sys
import errno
import glob
import shutil
from os import makedirs, remove, walk, system as os_system
from os.path import exists, join
from time import localtime, mktime, strftime, time, gmtime, sleep
from calendar import day_name
from datetime import datetime
import traceback
# =========================
# Enigma2 / framework imports
# =========================
import Components.PluginComponent
import NavigationInstance
import Screens.Standby
from enigma import (
    eEPGCache,
    eServiceCenter,
    eServiceReference,
    eTimer,
    getDesktop
)
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.Sources.StaticText import StaticText
from Components.config import (
    config,
    ConfigClock,
    ConfigInteger,
    ConfigOnOff,
    ConfigSelection,
    ConfigSubDict,
    ConfigSubsection,
    ConfigText,
    ConfigYesNo,
    NoSave,
    getConfigListEntry
)

from Plugins.Plugin import PluginDescriptor
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools import Notifications
from Tools.Directories import fileExists, SCOPE_PLUGINS, resolveFilename
from Tools.FuzzyDate import FuzzyTime

# =========================
# Local project imports
# =========================
from . import _, log, getSkin, isDreamOS, isDreamos, isDreamOs, PY3, isPython312, isPython313, isPython314
try:
    from enigma import eEnv
except ImportError:
    eEnv = None
ExpandableSelectionList = None
filtersServices = None
EPGImport = None
EPGConfig = None
epgimport = None
e2skinpatcher = None
runtime_import_error = None

# Define SOURCE_LINKS for git imports
SOURCE_LINKS = {
    "0": "https://github.com/oe-alliance/EPGimport-Sources/archive/refs/heads/main.tar.gz",
    "1": "https://github.com/Belfagor2005/EPGimport-Sources/archive/refs/heads/main.tar.gz"
}

try:
    from Tools.StbHardware import getFPWasTimerWakeup
except ImportError:
    try:
        from Tools.DreamboxHardware import getFPWasTimerWakeup
    except ImportError:
        def getFPWasTimerWakeup():
            return False

# =======================================
# Functions
# =======================================

def _getAutoTimerClass():
    """Lazy import for AutoTimer (optional dependency)"""
    try:
        return __import__('Plugins.Extensions.AutoTimer.AutoTimer', fromlist=['AutoTimer']).AutoTimer
    except Exception as e:
        print("[EPGImport] AutoTimer import failed:", repr(e), file=log)
        return None


def ensure_runtime_modules():
    global ExpandableSelectionList, filtersServices, EPGImport, EPGConfig, epgimport, e2skinpatcher, runtime_import_error

    try:
        if ExpandableSelectionList is None:
            from . import ExpandableSelectionList as _ExpandableSelectionList
            ExpandableSelectionList = _ExpandableSelectionList
        if filtersServices is None:
            from . import filtersServices as _filtersServices
            filtersServices = _filtersServices
        if EPGImport is None:
            from . import EPGImport as _EPGImport
            EPGImport = _EPGImport
        if EPGConfig is None:
            from . import EPGConfig as _EPGConfig
            EPGConfig = _EPGConfig
        if isDreamOS and e2skinpatcher is None:
            try:
                from . import e2skinpatcher as _e2skinpatcher
                e2skinpatcher = _e2skinpatcher
            except Exception:
                e2skinpatcher = None
        if epgimport is None and EPGImport is not None:
            epgimport = EPGImport.EPGImport(eEPGCache.getInstance(), channelFilter)
        runtime_import_error = None
        return True
    except Exception as e:
        runtime_import_error = e
        print("[EPGImport] Runtime module import failed: %s" % repr(e), file=log)
        traceback.print_exc(file=log)
        return False

def deep_clean_epg_minimal():
    # List of all EPG files
    epg_files = [
        "/etc/enigma2/epg.db",
        "/etc/enigma2/epg.dat",
        "/media/hdd/epg.db",
        "/media/hdd/epg.dat",
        "/media/usb/epg.db",
        "/media/usb/epg.dat"
    ]

    # Remove EPG files
    for f in epg_files:
        try:
            if exists(f):
                remove(f)
        except:
            pass

    # Clean temporary cache
    _cleanup_temporary_epg_paths()


def _command_exists(command_name):
    try:
        return bool(shutil.which(command_name))
    except AttributeError:
        for directory in ('/usr/bin', '/bin', '/usr/sbin', '/sbin'):
            candidate = join(directory, command_name)
            if exists(candidate) and os.access(candidate, os.X_OK):
                return True
    except Exception:
        pass
    return False


def _remove_path_safely(pathname):
    if not pathname or not exists(pathname):
        return
    try:
        if os.path.isdir(pathname):
            shutil.rmtree(pathname, ignore_errors=True)
        else:
            remove(pathname)
    except Exception as e:
        print("[EPGImport] Failed to remove temporary path %s: %s" % (pathname, repr(e)), file=log)


def _cleanup_temporary_epg_paths():
    tmp_patterns = ["/tmp/epg*", "/tmp/enigma2*"]
    for pattern in tmp_patterns:
        for pathname in glob.glob(pattern):
            _remove_path_safely(pathname)


def _terminate_stuck_import_processes(profile=None):
    profile = profile or getRuntimeProfile(refresh=True)
    used_commands = []
    process_patterns = []

    if profile.get("is_dreambox"):
        process_patterns.extend([
            "/Plugins/Extensions/EPGImport/",
            "EPGImport.py",
        ])
    else:
        process_patterns.extend([
            "/Plugins/Extensions/EPGImport/",
            "epgimport_reader.tmp",
        ])
        if profile.get("is_vti") or profile.get("is_openatv") or profile.get("is_openpli") or profile.get("is_oea"):
            process_patterns.append("EPGImport.py")

    if _command_exists("pkill"):
        for pattern in process_patterns:
            os_system("pkill -f \"%s\" >/dev/null 2>&1" % pattern.replace('"', '\\"'))
            used_commands.append("pkill:%s" % pattern)
    elif _command_exists("killall"):
        for process_name in ("epgimport",):
            os_system("killall -9 %s >/dev/null 2>&1" % process_name)
            used_commands.append("killall:%s" % process_name)

    if used_commands:
        print("[EPGImport] Stuck process cleanup executed using %s" % ", ".join(used_commands), file=log)
    else:
        print("[EPGImport] No supported process cleanup command found for this image", file=log)

# =======================================
# Global variables
# =======================================
autoStartTimer = None
_session = None
BouquetChannelListList = None
serviceIgnoreList = None
filterCounter = 0
isFilterRunning = 0

def extensionsmenu(session, **kwargs):
    # Clear log at start of plugin operation
    try:
        log.logfile.truncate(0)
        log.logfile.seek(0)
    except:
        pass
    main(session, **kwargs)

def setExtensionsmenu(el):
    try:
        if el.value:
            Components.PluginComponent.plugins.addPlugin(extDescriptor)
        else:
            Components.PluginComponent.plugins.removePlugin(extDescriptor)
    except Exception as e:
        print("[EPGImport] Failed to update extensions menu:", e)

# Filter servicerefs that this box can display by starting a fake recording.
def channelFilter(ref):
    if not ensure_runtime_modules():
        return False

    # Reject empty refs; or non-IPTV when import_onlyiptv is set
    if not ref or (config.plugins.epgimport.import_onlyiptv.value and '%3a//' not in ref.lower()):
        return False

    # CONDITION: Normalise SID/TSID/ONID to 16-bit BEFORE building eServiceReference.
    # IPTV providers (e.g. Edem) use service IDs > 65535.  Enigma2 masks them to
    # their low 16 bits internally, so we must do the same or the lookup key won't match.
    try:
        ref = EPGConfig._normalize_service_ref_sid(ref)
    except Exception:
        pass  # EPGConfig not yet loaded (very early call) — use ref as-is

    sref = eServiceReference(ref)
    refnum = getRefNum(sref.toString())

    # CONDITION: Bouquet filter — check whether this ref is in the user's bouquets
    if config.plugins.epgimport.import_onlybouquet.value:
        global BouquetChannelListList
        if BouquetChannelListList is None:
            BouquetChannelListList = getBouquetChannelList()
        if refnum not in BouquetChannelListList:
            print("Serviceref not in bouquets:", sref.toString(), file=log)
            return False

    # CONDITION: Ignore list — skip refs the user has explicitly excluded
    global serviceIgnoreList
    if serviceIgnoreList is None:
        serviceIgnoreList = [getRefNum(x) for x in filtersServices.filtersServicesList.servicesList()]
    if refnum in serviceIgnoreList:
        print("Serviceref is in ignore list:", sref.toString(), file=log)
        return False

    # CONDITION: IPTV stream (URL embedded in ref) — accept without fake-recording check.
    # Calling recordService() on thousands of IPTV refs one-by-one freezes the UI because
    # it runs on the main thread and requires a tuner handshake.  IPTV streams are always
    # receivable on any image that has the right plugin, so we return True unconditionally.
    if "%3a//" in ref.lower():
        return True

    # DVB/satellite/cable services: verify tuner can actually receive the signal
    fakeRecService = NavigationInstance.instance.recordService(sref, True)
    if fakeRecService:
        fakeRecResult = fakeRecService.start(True)
        NavigationInstance.instance.stopRecordService(fakeRecService)
        # -7 (errNoSourceFound) occurs when tuner is disconnected.
        return fakeRecResult in (0, -5, -7)

    print("Invalid serviceref string:", ref, file=log)
    return False


lastImportResult = None

def deletePycPyoFiles():
    # Delete pyc and pyo files from plugin folder
    try:
        plugin_path = "/usr/lib/enigma2/python/Plugins/Extensions/EPGImport"
        if exists(plugin_path):
            # Find all pyc and pyo files
            pyc_files = glob.glob(join(plugin_path, "*.pyc"))
            pyo_files = glob.glob(join(plugin_path, "*.pyo"))

            # Also search in subdirectories
            for root, dirs, files in walk(plugin_path):
                for file in files:
                    if file.endswith('.pyc') or file.endswith('.pyo'):
                        full_path = join(root, file)
                        if full_path.endswith('.pyc'):
                            pyc_files.append(full_path)
                        else:
                            pyo_files.append(full_path)

            # Delete files
            deleted_count = 0
            for file_list in [pyc_files, pyo_files]:
                for file_path in file_list:
                    try:
                        remove(file_path)
                        deleted_count += 1
                    except Exception:
                        pass

            return deleted_count
        else:
            return 0
    except Exception:
        return 0

# Get last byte of MAC address for default time offset calculation
def lastMACbyte():
    try:
        from uuid import getnode
        PY3 = (sys.version_info[0] == 3)
        range_list = list(range(6)) if PY3 else range(6)
        return int(''.join('%02x' % ((getnode() >> 8 * i) & 0xff) for i in reversed(range_list))[-2:], 16)
    except:
        try:
            return int(open('/sys/class/net/eth0/address').readline().strip()[-2:], 16)
        except:
            return 256
# Calculate default wakeup time based on MAC address
def calcDefaultStarttime():
    try:
        offset = lastMACbyte() * 30
    except:
        offset = 7680
    return (5 * 60 * 60) + offset

# =========================
# Configuration setup
# =========================
config.plugins.epgimport = ConfigSubsection()
config.plugins.epgimport.enabled = ConfigOnOff(default=True)
# Added option to kill stuck processes
config.plugins.epgimport.killstuck = ConfigYesNo(default=False)
config.plugins.epgimport.runboot = ConfigSelection(default="4", choices=[
    ("1", _("always")),
    ("2", _("only manual boot")),
    ("3", _("only automatic boot")),
    ("4", _("never"))
])
config.plugins.epgimport.runboot_restart = ConfigYesNo(default=False)
config.plugins.epgimport.runboot_day = ConfigYesNo(default=False)
config.plugins.epgimport.wakeup = ConfigClock(default=calcDefaultStarttime())
config.plugins.epgimport.showinextensions = ConfigYesNo(default=True)
config.plugins.epgimport.deepstandby = ConfigSelection(default="skip", choices=[
    ("wakeup", _("wake up and import")),
    ("skip", _("skip the import"))
])
config.plugins.epgimport.extra_source = ConfigSelection(
    default="1",
    choices=[
        ("0", "Doglover3920"),
        ("1", "Lululla")
    ]
)
config.plugins.epgimport.standby_afterwakeup = ConfigYesNo(default=False)
config.plugins.epgimport.shutdown = ConfigYesNo(default=False)
if isDreamOS:
    _max_epg_days = 30
else:
    # Extended to 31 days for Open Source images as requested to match Dreambox
    _max_epg_days = 30
config.plugins.epgimport.longDescDays = ConfigInteger(5, limits=(0, _max_epg_days))
config.plugins.epgimport.showinmainmenu = ConfigYesNo(default=False)
config.plugins.epgimport.deepstandby_afterimport = NoSave(ConfigYesNo(default=False))
config.plugins.epgimport.parse_autotimer = ConfigYesNo(default=False)
config.plugins.epgimport.import_onlybouquet = ConfigYesNo(default=False)
config.plugins.epgimport.import_onlyiptv = ConfigYesNo(default=False)
config.plugins.epgimport.clear_oldepg = ConfigYesNo(default=False)
config.plugins.epgimport.day_profile = ConfigSelection(choices=[("1", _("Press OK"))], default="1")
config.plugins.extra_epgimport = ConfigSubsection()
config.plugins.extra_epgimport.last_import = ConfigText(default="0")
config.plugins.extra_epgimport.day_import = ConfigSubDict()
for i in range(7):
    config.plugins.extra_epgimport.day_import[i] = ConfigOnOff(default=True)

# historically located (not a problem, we want to update it)
CONFIG_PATH = '/etc/epgimport'
try:
    makedirs(CONFIG_PATH)
except OSError as e:  # race condition guard
    if e.errno != errno.EEXIST:
        print("Error creating: %s", CONFIG_PATH, file=log)

# ==========================================
# Helper functions for EPG path & image type
# ==========================================
def getRuntimeProfile(refresh=False):
    if not ensure_runtime_modules():
        return {
            "is_dreambox": False,
            "is_vuplus": False,
            "is_vti": False,
            "is_openatv": False,
            "is_openatv_python_313": False,
            "is_open_source_python_312_plus": False,
            "is_open_source_python_314_plus": False,
            "is_openpli": False,
            "is_oea": False,
            "python_version": "%s.%s.%s" % (sys.version_info[0], sys.version_info[1], sys.version_info[2]),
            "epg_dat_path": "/etc/enigma2/epg.dat",
            "epg_cache_path": "/etc/enigma2/epg.dat",
            "cleanup_candidates": ["/etc/enigma2/epg.dat"],
        }
    return EPGImport.get_runtime_profile(refresh=refresh)


def getEPGPath(refresh=False):
    return getRuntimeProfile(refresh=refresh).get("epg_dat_path", EPGImport.HDD_EPG_DAT)


def getEPGCachePath(refresh=False):
    return getRuntimeProfile(refresh=refresh).get("epg_cache_path", getEPGPath(refresh=refresh))


def getCleanupPaths(refresh=False):
    profile = getRuntimeProfile(refresh=refresh)
    return profile.get("cleanup_candidates", [getEPGCachePath(refresh=refresh), getEPGPath(refresh=refresh)])


def isPLiImage():
    return getRuntimeProfile().get("is_openpli", False)


def isOEAImage():
    return getRuntimeProfile().get("is_oea", False)


def isVTIImage():
    return getRuntimeProfile().get("is_vti", False)


def isOpenATVImage():
    return getRuntimeProfile().get("is_openatv", False)


def isOpenATVPython313():
    return getRuntimeProfile().get("is_openatv_python_313", False)

def getAlternatives(service):
    if not service:
        return None
    alternativeServices = eServiceCenter.getInstance().list(service)
    return alternativeServices and alternativeServices.getContent("S", True)

def getRefNum(ref):
    """
    Compute a compact numeric key from a service reference string.

    Enigma2 stores SID / TSID / ONID / DVBnamespace as 16-bit integers
    internally (max 65535).  IPTV providers frequently use service IDs
    larger than 65535 in their channel lists.  When Enigma2 creates an
    eServiceReference from such a string it silently masks each field
    to the low 16 bits.  We must do the same here so the lookup key we
    build matches the key Enigma2 has stored in its EPG cache.

    Format of a service reference (colon-separated fields, 0-indexed):
      [0] type  [1] flags  [2] ?? [3] SID  [4] TSID  [5] ONID  [6] DVBns ...
    """
    parts = ref.split(':')[3:7]
    try:
        sid  = int(parts[0], 16) & 0xFFFF
        tsid = int(parts[1], 16) & 0xFFFF
        onid = int(parts[2], 16) & 0xFFFF
        # DVBnamespace occupies the upper 16 bits of the 4th field
        dvbns_raw = int(parts[3], 16)
        dvbns = (dvbns_raw >> 16) & 0xFFFF
        return sid << 48 | tsid << 32 | onid << 16 | dvbns
    except Exception:
        return None

def getBouquetChannelList():
    channels = set()
    global isFilterRunning, filterCounter
    isFilterRunning = 1
    serviceHandler = eServiceCenter.getInstance()
    mask = (eServiceReference.isMarker | eServiceReference.isDirectory)
    alternative_flag = eServiceReference.isGroup
    bouquet_roots = []
    favourite_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet')
    profile = getRuntimeProfile()
    relaxed_bouquet_probe = bool(
        profile.get("is_open_source_python_314_plus") or
        profile.get("is_openatv_python_313")
    )

    if config.usage.multibouquet.value:
        bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
        bouquet_list = serviceHandler.list(bouquet_root)
        if bouquet_list:
            while True:
                s = bouquet_list.getNext()
                if not s.valid():
                    break
                if s.flags & eServiceReference.isDirectory:
                    bouquet_roots.append(s)
                elif relaxed_bouquet_probe:
                    try:
                        clist = serviceHandler.list(s)
                    except Exception:
                        clist = None
                    if clist:
                        bouquet_roots.append(s)
        if relaxed_bouquet_probe and not bouquet_roots:
            bouquet_roots.append(favourite_root)
    else:
        bouquet_roots.append(favourite_root)

    for bouquet_root in bouquet_roots:
        services_list = serviceHandler.list(bouquet_root)
        if not services_list:
            continue
        while True:
            service = services_list.getNext()
            filterCounter += 1
            if not service.valid():
                break
            if not (service.flags & mask):
                if service.flags & alternative_flag:
                    alt_list = getAlternatives(service)
                    if alt_list:
                        for channel in alt_list:
                            refnum = getRefNum(channel)
                            if refnum:
                                channels.add(refnum)
                else:
                    refnum = getRefNum(service.toString())
                    if refnum:
                        channels.add(refnum)
    isFilterRunning = 0
    return channels

def startImport():
    try:
        if not ensure_runtime_modules():
            raise Exception("runtime module import failed: %s" % runtime_import_error)
        print("[EPGImport] startImport called", file=log)
        profile = getRuntimeProfile(refresh=True)
        EPGImport.HDD_EPG_DAT = profile.get("epg_dat_path", EPGImport.HDD_EPG_DAT)
        active_cache_path = profile.get("epg_cache_path", EPGImport.HDD_EPG_DAT)
        print(
            "[EPGImport] Runtime profile: Dreambox=%s VuPlus=%s VTI=%s OpenATV=%s OpenATV-Py3.13+=%s OpenSource-Py3.12+=%s OpenSource-Py3.14+=%s OpenPLi=%s OE-A=%s Python=%s" % (
                profile.get("is_dreambox"),
                profile.get("is_vuplus"),
                profile.get("is_vti"),
                profile.get("is_openatv"),
                profile.get("is_openatv_python_313"),
                profile.get("is_open_source_python_312_plus"),
                profile.get("is_open_source_python_314_plus"),
                profile.get("is_openpli"),
                profile.get("is_oea"),
                profile.get("python_version")
            ),
            file=log
        )
        print("[EPGImport] Using EPG DAT path: %s" % EPGImport.HDD_EPG_DAT, file=log)
        print("[EPGImport] Active cache path: %s" % active_cache_path, file=log)

        # Clearing current EPG before import
        if config.plugins.epgimport.clear_oldepg.value:
            deep_clean_epg_minimal()
            cleanup_paths = getCleanupPaths(refresh=True)

            if hasattr(epgimport.epgcache, 'flushEPG'):
                print("[EPGImport] Clearing old EPG data using flushEPG...", file=log)
                for cleanup_path in cleanup_paths:
                    EPGImport.unlink_if_exists(cleanup_path, allow_epg_db=True)
                    EPGImport.unlink_if_exists(cleanup_path + '.backup', allow_epg_db=True)
                epgimport.epgcache.flushEPG()
            elif isOpenATVPython313() or isPLiImage() or isOEAImage() or isVTIImage():
                # Alternative method for openATV Python 3.13+, PLi, OE-A and VTI images
                print("[EPGImport] Clearing old EPG data using alternative method...", file=log)
                for cleanup_path in cleanup_paths:
                    EPGImport.unlink_if_exists(cleanup_path, allow_epg_db=True)
                    EPGImport.unlink_if_exists(cleanup_path + '.backup', allow_epg_db=True)
                try:
                    epgimport.epgcache.clear()
                except:
                    pass

        # Override Enigma2 EPG max days limit to prevent Open Source images from dropping events > 7 days
        try:
            if hasattr(config, "epg") and hasattr(config.epg, "maxdays"):
                requested_days = config.plugins.epgimport.longDescDays.value
                if config.epg.maxdays.value < requested_days:
                    print("[EPGImport] Adjusting system config.epg.maxdays from %s to %s to accommodate import" % (config.epg.maxdays.value, requested_days), file=log)
                    config.epg.maxdays.value = requested_days
                    config.epg.maxdays.save()
        except Exception as e:
            print("[EPGImport] Error adjusting config.epg.maxdays: %s" % e, file=log)

        epgimport.onDone = doneImport
        print("[EPGImport] Starting beginImport...", file=log)
        epgimport.beginImport(longDescUntil=config.plugins.epgimport.longDescDays.value * 24 * 3600 + time())
        print("[EPGImport] beginImport completed", file=log)
    except Exception as e:
        print("[EPGImport] Error in startImport:", e, file=log)
        traceback.print_exc(file=log)
        raise

def getVersion():
    # Read version from version.txt file
    try:
        with open(resolveFilename(SCOPE_PLUGINS, "Extensions/EPGImport/version.txt"), "r") as f:
            version = f.read().strip()
    except:
        version = "Unknown"
    return version

# ==========================================
# GUI Classes
# ==========================================
HD = False
try:
    if getDesktop(0).size().width() >= 1280:
        HD = True
except:
    pass

class EPGImportConfig(ConfigListScreen, Screen):
    def __init__(self, session):
        ensure_runtime_modules()
        Screen.__init__(self, session)

        # Get version and set title
        version = getVersion()
        title_with_version = _('EPG Import Configuration') + " Ver: " + version
        Screen.setTitle(self, title_with_version)

        self["title"] = self["Title"] = StaticText(title_with_version)
        self.skinName = 'EPGImportConfig'
        self.skin = getSkin(self.skinName)
        self["status"] = Label()
        self["statusbar"] = Label(_("Last import: %s events") % config.plugins.extra_epgimport.last_import.value)
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Save"))
        self["key_yellow"] = Button(_("Manual"))
        self["key_blue"] = Button(_("Sources"))
        self["description"] = Label("")
        self["setupActions"] = ActionMap(
            ["SetupActions", "ColorActions", "TimerEditActions", "MovieSelectionActions"],
            {
                "red": self.keyCancel,
                "green": self.keyGreen,
                "yellow": self.doimport,
                "blue": self.dosources,
                "cancel": self.keyCancel,
                "ok": self.keyOk,
                "log": self.keyInfo,
                "contextMenu": self.openMenu,
            }, -1)
        ConfigListScreen.__init__(self, [], session)
        self.lastImportResult = None
        self.prev_onlybouquet = config.plugins.epgimport.import_onlybouquet.value
        self.initConfig()
        self.createSetup()
        self.filterStatusTemplate = _("Filtering: %s Please wait!")
        self.importStatusTemplate = _("Importing: %s %s events")
        self.updateTimer = eTimer()
        if isDreamOS:
            self.updateTimer_conn = self.updateTimer.timeout.connect(self.updateStatus)
        else:
            self.updateTimer.callback.append(self.updateStatus)
        self.updateTimer.start(2000)
        self.onLayoutFinish.append(self.updateStatus)
        self.startTimer = None

    def initConfig(self):
        self.EPG = config.plugins.epgimport
        self.cfg_enabled = getConfigListEntry(_("Automatic import EPG"), self.EPG.enabled, _("When enabled, it allows you to schedule an automatic EPG update at the given days and time."))
        # Added the option to kill stuck processes to the settings interface
        self.cfg_killstuck = getConfigListEntry(_("Kill running import on start"), self.EPG.killstuck, _("Kill any stuck EPG import processes before starting new import"))
        self.cfg_source_import = getConfigListEntry(_("Source EPG"), self.EPG.extra_source, _("Specify the source for EPG."))
        self.cfg_wakeup = getConfigListEntry(_("Automatic start time"), self.EPG.wakeup, _("Specify the time for the automatic EPG update."))
        self.cfg_deepstandby = getConfigListEntry(_("When in deep standby"), self.EPG.deepstandby, _("Choose the action to perform when the box is in deep standby and the automatic EPG update should normally start."))
        self.cfg_shutdown = getConfigListEntry(_("Return to deep standby after import"), self.EPG.shutdown, _("This will turn back waked up box into deep-standby after automatic EPG import."))
        self.cfg_standby_afterwakeup = getConfigListEntry(_("Standby at startup"), self.EPG.standby_afterwakeup, _("The waked up box will be turned into standby after automatic EPG import wake up."))
        self.cfg_day_profile = getConfigListEntry(_("Choice days for start import"), self.EPG.day_profile, _("You can select the day(s) when the EPG update must be performed."))
        self.cfg_runboot = getConfigListEntry(_("Start import after booting up"), self.EPG.runboot, _("Specify in which case the EPG must be automatically updated after the box has booted."))
        self.cfg_import_onlybouquet = getConfigListEntry(_("Load EPG only services in bouquets"), self.EPG.import_onlybouquet, _("To save memory you can decide to only load EPG data for the services that you have in your bouquet files."))
        self.cfg_import_onlyiptv = getConfigListEntry(_('Load EPG only for IPTV channels'), self.EPG.import_onlyiptv, _("Load EPG for IPTV broadcasts only"))
        self.cfg_runboot_day = getConfigListEntry(_("Consider setting \"Days Profile\""), self.EPG.runboot_day, _("When you decide to load the EPG after GUI restart mention if the \"days profile\" must be take into consideration or not."))
        self.cfg_runboot_restart = getConfigListEntry(_("Skip import on restart GUI"), self.EPG.runboot_restart, _("When you restart the GUI you can decide to skip or not the EPG data import."))
        self.cfg_showinextensions = getConfigListEntry(_("Show \"EPGImport\" in extensions"), self.EPG.showinextensions, _("Display or not the EPGImport menu in the extension menu."))
        self.cfg_showinmainmenu = getConfigListEntry(_("Show \"EPGImport\" in main menu"), self.EPG.showinmainmenu, _("Display a shortcut \"EPGImport\" on your STB main screen."))
        self.cfg_longDescDays = getConfigListEntry(_("Load long descriptions up to X days"), self.EPG.longDescDays, _("Define the number of days that you want to get the full EPG data, reducing this number can help you to save memory usage on your box. But you are also limited with the EPG provider available data. You will not have 30 days EPG if it only provide 7 days data."))
        self.cfg_parse_autotimer = getConfigListEntry(_("Run AutoTimer after import"), self.EPG.parse_autotimer, _("You can start automatically the plugin AutoTimer after the EPG data update to have it refreshing its scheduling after EPG data refresh."))
        self.cfg_clear_oldepg = getConfigListEntry(_("Clearing current EPG before import"), config.plugins.epgimport.clear_oldepg, _("This will clear the current EPG data in memory before updating the EPG data. This allows you to always have a clean new EPG with the latest EPG data, for example in case of program changes between refresh, otherwise EPG data are cumulative."))

    def createSetup(self):
        self.list = [self.cfg_enabled]
        if self.EPG.enabled.value:
            self.list.append(self.cfg_wakeup)
            self.list.append(self.cfg_deepstandby)
            if self.EPG.deepstandby.value == "wakeup":
                self.list.append(self.cfg_shutdown)
                if not self.EPG.shutdown.value:
                    self.list.append(self.cfg_standby_afterwakeup)
        self.list.append(self.cfg_day_profile)
        self.list.append(self.cfg_source_import)
        self.list.append(self.cfg_runboot)
        if self.EPG.runboot.value != "4":
            self.list.append(self.cfg_runboot_day)
            if self.EPG.runboot.value == "1" or self.EPG.runboot.value == "2":
                self.list.append(self.cfg_runboot_restart)
        self.list.append(self.cfg_showinextensions)
        self.list.append(self.cfg_showinmainmenu)
        # Add the option to kill stuck processes to the menu
        self.list.append(self.cfg_killstuck)
        self.list.append(self.cfg_import_onlybouquet)
        self.list.append(self.cfg_import_onlyiptv)
        if hasattr(eEPGCache, 'flushEPG') or isDreamOS or isOpenATVPython313() or isPLiImage() or isOEAImage() or isVTIImage():
            self.list.append(self.cfg_clear_oldepg)
        self.list.append(self.cfg_longDescDays)
        if fileExists(resolveFilename(SCOPE_PLUGINS, "Extensions/AutoTimer/plugin.py")):
            try:
                AutoTimer = _getAutoTimerClass()
                if AutoTimer is None:
                    raise ImportError('AutoTimer')
                self.list.append(self.cfg_parse_autotimer)
            except:
                print("[EPGImport] AutoTimer Plugin not installed", file=log)
        self["config"].list = self.list
        self["config"].setList(self.list)

    # for summary:
    def getCurrentDescription(self):
        return self["config"].getCurrent() and len(self["config"].getCurrent()) > 2 and self["config"].getCurrent()[2] or ""

    def getCurrentEntry(self):
        self.updateDescription()
        return ConfigListScreen.getCurrentEntry(self)

    def updateDescription(self):
        self["description"].setText(self.getCurrentDescription())

    def getIndex(self):
        return (self["config"].getCurrentIndex(), len(self["config"].getList()) - 1)

    def keyUp(self):
        idx, length = self.getIndex()
        self["config"].setCurrentIndex(idx - 1 if idx > 0 else length)
        self.updateDescription()

    def keyDown(self):
        idx, length = self.getIndex()
        self["config"].setCurrentIndex(idx + 1 if idx < length else 0)
        self.updateDescription()

    def newConfig(self):
        cur = self["config"].getCurrent()
        if cur in (self.cfg_enabled, self.cfg_shutdown, self.cfg_deepstandby, self.cfg_runboot):
            self.createSetup()

    def keyGreen(self):
        if hasattr(self, 'startTimer') and self.startTimer is not None:
            self.startTimer.stop()
            if isDreamOS and hasattr(self, 'startTimer_conn'):
                del self.startTimer_conn
        self.updateTimer.stop()
        if not fileExists(resolveFilename(SCOPE_PLUGINS, "Extensions/AutoTimer/plugin.py")) and self.EPG.parse_autotimer.value:
            self.EPG.parse_autotimer.value = False
        if self.EPG.shutdown.value:
            self.EPG.standby_afterwakeup.value = False
        self.EPG.save()
        if self.prev_onlybouquet != config.plugins.epgimport.import_onlybouquet.value or (autoStartTimer is not None and autoStartTimer.prev_multibouquet != config.usage.multibouquet.value):
            EPGConfig.channelCache = {}
        self.close(True)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.newConfig()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.newConfig()

    def keyOk(self):
        ConfigListScreen.keyOK(self)
        sel = self["config"].getCurrent()[1]
        if sel and sel == self.EPG.day_profile:
            self.session.open(EPGImportProfile)

    def updateStatus(self):
        text = ""
        if isFilterRunning == 1:
            text = self.filterStatusTemplate % (str(filterCounter))
        elif epgimport.isImportRunning():
            src = epgimport.source
            if src and hasattr(src, 'description'):
                text = self.importStatusTemplate % (src.description, epgimport.eventCount or 0)
            else:
                text = "Importing EPG data..."
        self["status"].setText(text)

        if lastImportResult and (lastImportResult != self.lastImportResult):
            start, count = lastImportResult
            try:
                d, t = FuzzyTime(start, inPast=True)
            except:
                # Not all images have inPast
                d, t = FuzzyTime(start)

            try:
                duration_text = "just completed"

                if hasattr(epgimport, 'startTime'):
                    if isinstance(epgimport.startTime, datetime):
                        start_timestamp = mktime(epgimport.startTime.timetuple())
                    else:
                        start_timestamp = epgimport.startTime
                    duration_seconds = time() - start_timestamp
                    duration_text = strftime('%H:%M:%S', gmtime(duration_seconds))
                else:
                    duration_text = "completed"

            except Exception as e:
                print("[EPGImport] Duration calculation error: " + str(e))
                duration_text = "completed"

            text = _("Last: %s %s, %d events") % (d, t, count) + _("\nCompleted in %s") % duration_text
            self["statusbar"].setText(text)
            self.lastImportResult = lastImportResult

    def keyInfo(self):
        last_import = config.plugins.extra_epgimport.last_import.value
        self.session.open(MessageBox, _("Last import: %s events") % (last_import), type=MessageBox.TYPE_INFO)

    def doimport(self, one_source=None):
        if epgimport.isImportRunning():
            print("[EPGImport] Already running, won't start again", file=log)
            self.session.open(MessageBox, _("EPGImport\nImport of epg data is still in progress. Please wait."), MessageBox.TYPE_ERROR, timeout=10, close_on_any_key=True)
            return
        try:
            EPGConfig.channelCache = {}
            if one_source is None:
                cfg = EPGConfig.loadUserSettings()
            else:
                cfg = one_source

            sources = [s for s in EPGConfig.enumSources(CONFIG_PATH, filter=cfg["sources"])]
            if not sources:
                self.session.open(MessageBox, _("No active EPG sources found, nothing to do"), MessageBox.TYPE_INFO, timeout=10, close_on_any_key=True)
                return
            # make it a stack, first on top.
            sources.reverse()
            epgimport.sources = sources
            self.session.openWithCallback(self.do_import_callback, MessageBox, _("EPGImport\nImport of epg data will start.\nThis may take a few minutes.\nIs this ok?"), MessageBox.TYPE_YESNO, timeout=15, default=True)
        except Exception as e:
            print("[EPGImport] Error in doimport:", e, file=log)
            traceback.print_exc(file=log)
            try:
                self.session.open(MessageBox, _("EPGImport Plugin\nError preparing import:\n") + str(e), MessageBox.TYPE_ERROR, timeout=15, close_on_any_key=True)
            except:
                pass

    def do_import_callback(self, confirmed):
        if not confirmed:
            return
        # Use a simple timer to defer the import start - more stable for DreamBox
        self.startTimer = eTimer()
        if isDreamOS:
            self.startTimer_conn = self.startTimer.timeout.connect(self._startImportDelayed)
        else:
            self.startTimer.callback.append(self._startImportDelayed)
        self.startTimer.start(1000, True)  # Start after 1 second
        print("[EPGImport] Scheduled import to start via timer", file=log)
        self.updateStatus()

    def _startImportDelayed(self):
        # This function is called from timer
        try:
            print("[EPGImport] Starting import process (delayed)...", file=log)
            startImport()
            print("[EPGImport] Import process started successfully", file=log)
        except Exception as e:
            print("[EPGImport] Error at start:", e, file=log)
            traceback.print_exc(file=log)
            try:
                self.session.open(MessageBox, _("EPGImport Plugin\nFailed to start:\n") + str(e), MessageBox.TYPE_ERROR, timeout=15, close_on_any_key=True)
            except:
                pass
        finally:
            if hasattr(self, 'startTimer') and self.startTimer is not None:
                self.startTimer.stop()
                if isDreamOS and hasattr(self, 'startTimer_conn'):
                    del self.startTimer_conn

    def openMenu(self):
        menu = [(_("Show log"), self.showLog), (_("Ignore services list"), self.openIgnoreList), (_("Delete PYC/PYO files"), self.deletePycPyo)]
        text = _("Select action")

        def setAction(choice):
            if choice:
                choice[1]()
        self.session.openWithCallback(setAction, ChoiceBox, title=text, list=menu)

    def deletePycPyo(self):
        """Delete PYC and PYO files"""
        try:
            deleted_count = deletePycPyoFiles()
            if deleted_count > 0:
                self.session.open(MessageBox, _("Deleted %d PYC/PYO files") % deleted_count, MessageBox.TYPE_INFO, timeout=5)
            else:
                self.session.open(MessageBox, _("No PYC/PYO files found to delete"), MessageBox.TYPE_INFO, timeout=5)
        except Exception as e:
            self.session.open(MessageBox, _("Error deleting PYC/PYO files: %s") % str(e), MessageBox.TYPE_ERROR, timeout=5)

    def openIgnoreList(self):
        self.session.open(filtersServices.filtersServicesSetup)

    def showLog(self):
        self.session.open(EPGImportLog)

    def dosources(self):
        # FIX: Use direct session.open instead of openWithCallback to avoid NoneType error
        try:
            self.session.open(EPGImportSources)
        except Exception as e:
            print("[EPGImport] Error opening sources screen:", e, file=log)
            self.session.open(MessageBox, _("Error opening sources: %s") % str(e), MessageBox.TYPE_ERROR, timeout=10)

    def sourcesDone(self, confirmed, sources, cfg):
        # Called with True and list of config items on Okay.
        if cfg is not None:
            self.doimport(one_source=cfg)

FHD = True if getDesktop(0).size().width() >= 1280 else False

class EPGImportSources(Screen):
    # Pick sources from config
    if FHD:
        skin = """
            <screen position="center,center" size="1200,820" title="EPG Import Sources" >
                <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="295,70" />
                <ePixmap pixmap="skin_default/buttons/green.png" position="305,5" size="295,70" />
                <ePixmap pixmap="skin_default/buttons/yellow.png" position="600,5" size="295,70" />
                <ePixmap pixmap="skin_default/buttons/blue.png" position="895,5" size="295,70" />
                <widget backgroundColor="#9f1313" font="Regular;30" halign="center" name="key_red" position="10,5" foregroundColor="white" size="295,70" transparent="1" valign="center" zPosition="1" />
                <widget backgroundColor="#1f771f" font="Regular;30" halign="center" name="key_green" position="305,5" foregroundColor="white" size="295,70" transparent="1" valign="center" zPosition="1" />
                <widget backgroundColor="#a08500" font="Regular;30" halign="center" name="key_yellow" position="600,5" foregroundColor="white" size="295,70" transparent="1" valign="center" zPosition="1" />
                <widget backgroundColor="#18188b" font="Regular;30" halign="center" name="key_blue" position="895,5" foregroundColor="white" size="295,70" transparent="1" valign="center" zPosition="1" />
                <eLabel backgroundColor="grey" position="10,80" size="1180,1" />
                <widget enableWrapAround="1" name="list" position="10,90" size="1180,700" scrollbarMode="showOnDemand" />
            </screen>"""
    else:
        skin = """
            <screen position="center,center" size="820,520" title="EPG Import Sources" >
                <ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40" />
                <ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40" />
                <ePixmap pixmap="skin_default/buttons/yellow.png" position="410,5" size="200,40" />
                <ePixmap pixmap="skin_default/buttons/blue.png" position="610,5" size="200,40" />
                <widget name="key_red" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" foregroundColor="white" backgroundColor="#9f1313" transparent="1"/>
                <widget name="key_green" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" foregroundColor="white" backgroundColor="#1f771f" transparent="1" />
                <widget name="key_yellow" position="410,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" foregroundColor="white" backgroundColor="#a08500" transparent="1" />
                <widget name="key_blue" position="610,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" foregroundColor="white" backgroundColor="#18188b" transparent="1"/>
                <eLabel position="10,50" size="800,1" backgroundColor="grey" />
                <widget name="list" position="10,60" size="800,450" enableWrapAround="1" scrollbarMode="showOnDemand" />
            </screen>"""

    def __init__(self, session):
        ensure_runtime_modules()
        Screen.__init__(self, session)
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Save"))
        self["key_yellow"] = Button(_("Import"))
        self["key_blue"] = Button(_("Import from Git"))
        self.container = None
        self.tree = []
        self.giturl = SOURCE_LINKS.get(config.plugins.epgimport.extra_source.value)

        cfg = EPGConfig.loadUserSettings()
        filter = cfg["sources"]
        cat = None
        for x in EPGConfig.enumSources(CONFIG_PATH, filter=None, categories=True):
            if hasattr(x, "description"):
                sel = (filter is None) or (x.description in filter)
                entry = (x.description, x.description, sel)
                if cat is None:
                    # If no category defined, use a default one.
                    cat = ExpandableSelectionList.category("[.]")
                    self.tree.append(cat)
                cat[0][2].append(entry)
                if sel:
                    ExpandableSelectionList.expand(cat, True)
            else:
                cat = ExpandableSelectionList.category(x)
                self.tree.append(cat)
        self["list"] = ExpandableSelectionList.ExpandableSelectionList(self.tree, enableWrapAround=True)
        if self.tree:
            self["key_yellow"].show()
        else:
            self["key_yellow"].hide()
        self["setupActions"] = ActionMap(
            [
                "SetupActions",
                "ColorActions",
                "MenuActions"
            ],
            {
                "red": self.cancel,
                "green": self.save,
                "yellow": self.do_import,
                "blue": self.git_import,
                "save": self.save,
                "cancel": self.cancel,
                "menu": self.do_reset,
                "ok": self["list"].toggleSelection
            },
            -2
        )
        self.setTitle(_("EPG Import Sources"))

    def git_import(self):
        self.session.openWithCallback(
            self.install_update,
            MessageBox,
            _("Do you want to update Source now?\n\nWait for the import successful message!"),
            MessageBox.TYPE_YESNO,
            timeout=15
        )

    def install_update(self, answer=False):
        if answer:
            try:
                from . import import_source
                import_source.main(self.giturl)
            except Exception as e:
                self.session.open(
                    MessageBox,
                    _("Import failed with error: {}").format(e),
                    MessageBox.TYPE_ERROR,
                    timeout=10,
                    close_on_any_key=True
                )
                return

            self.refresh_tree()

        else:
            self.session.open(
                MessageBox,
                _("Update Aborted!"),
                MessageBox.TYPE_INFO,
                timeout=10
            )

    def refresh_tree(self):
        print("Refreshing tree...")
        cfg = EPGConfig.loadUserSettings()
        filter = cfg["sources"]
        self.tree = []
        cat = None
        try:
            sources_list = list(EPGConfig.enumSources(CONFIG_PATH, filter=None, categories=True))
            if not sources_list:
                self.session.open(
                    MessageBox,
                    _("No sources found after update!"),
                    MessageBox.TYPE_WARNING,
                    timeout=10
                )
                return

            for x in sources_list:
                if hasattr(x, "description"):
                    sel = (filter is None) or (x.description in filter)
                    entry = (x.description, x.description, sel)
                    if cat is None:
                        cat = ExpandableSelectionList.category("[.]")
                        self.tree.append(cat)
                    if cat and cat[0] and len(cat[0]) > 2:
                        cat[0][2].append(entry)
                        if sel:
                            ExpandableSelectionList.expand(cat, True)
                else:
                    cat = ExpandableSelectionList.category(x)
                    self.tree.append(cat)

            self["list"].tree = self.tree
            self["list"].updateFlatList()

            if self.tree:
                self["key_yellow"].show()
            else:
                self["key_yellow"].hide()

            msg = _("Sources updated successfully!")
            self.session.open(
                MessageBox,
                msg,
                MessageBox.TYPE_INFO,
                timeout=10
            )

        except Exception as e:
            print("[EPGImport] Error in refresh_tree:", str(e))
            self.session.open(
                MessageBox,
                _("Error refreshing sources: {}").format(str(e)),
                MessageBox.TYPE_ERROR,
                timeout=10
            )

    def save(self):
        """ Make the entries unique through a set """
        sources = list(set([item[1] for item in self["list"].enumSelected()]))
        log.write("[XMLTVImport] Selected sources: %s" % sources)
        EPGConfig.storeUserSettings(sources=sources)
        self.close(True, sources, None)

    def cancel(self):
        self.close(False, None, None)

    def do_import(self):
        current = self["list"].getCurrent()
        flat_list = getattr(self["list"], "flat_list", [])
        if current or flat_list:
            try:
                item = current[0] if current else None
                if item is None or hasattr(item[2], "append"):
                    raise Exception("Please select a source entry, not a category")
                source = [item[1] or ""]
                cfg = {"sources": source}
                log.write("[EPGImport] Selected source: " + str(source))
            except Exception as e:
                log.write("[EPGImport] Error at selected source: " + str(e))
            else:
                if cfg["sources"] != "":
                    self.close(False, None, cfg)

    def do_reset(self):
        if fileExists("/var/lib/dpkg/status"):
            return
        from .epgdb import epgdb_class
        epgdbfile = config.misc.epgcache_filename.value
        log.write("[XMLTVImport] is located at %s" % epgdbfile)
        provider_name = "Rytec XMLTV"
        provider_priority = 99
        self.epg = epgdb_class(provider_name, provider_priority, epgdbfile)
        self.epg.create_empty()
        log.write("[XMLTVImport] loading empty epg.db")
        self.epginstance = eEPGCache.getInstance()
        """
        if fileExists(config.misc.epgcache_filename.value):
            remove(config.misc.epgcache_filename.value)
        connection = sqlite.connect(config.misc.epgcache_filename.value, timeout=10)
        connection.text_factory = str
        cursor = connection.cursor()
        cursor.execute("CREATE TABLE T_Service (id INTEGER PRIMARY KEY, sid INTEGER NOT NULL, tsid INTEGER, onid INTEGER, dvbnamespace INTEGER, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Source (id INTEGER PRIMARY KEY, source_name TEXT NOT NULL, priority INTEGER NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Title (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, title TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Short_Description (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, short_description TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Extended_Description (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, extended_description TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Event (id INTEGER PRIMARY KEY, service_id INTEGER NOT NULL, begin_time INTEGER NOT NULL, duration INTEGER NOT NULL, source_id INTEGER NOT NULL, dvb_event_id INTEGER, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE TABLE T_Data (event_id INTEGER NOT NULL, title_id INTEGER, short_description_id INTEGER, extended_description_id INTEGER, iso_639_language_code TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
        cursor.execute("CREATE INDEX data_title ON T_Data (title_id)")
        cursor.execute("CREATE INDEX data_shortdescr ON T_Data (short_description_id)")
        cursor.execute("CREATE INDEX data_extdescr ON T_Data (extended_description_id)")
        cursor.execute("CREATE INDEX service_sid ON T_Service (sid)")
        cursor.execute("CREATE INDEX event_service_id_begin_time ON T_Event (service_id, begin_time)")
        cursor.execute("CREATE INDEX event_dvb_id ON T_Event (dvb_event_id)")
        cursor.execute("CREATE INDEX data_event_id ON T_Data (event_id)")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_event AFTER DELETE ON T_Event FOR EACH ROW BEGIN DELETE FROM T_Data WHERE event_id = OLD.id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_service_t_event AFTER DELETE ON T_Service FOR EACH ROW BEGIN DELETE FROM T_Event WHERE service_id = OLD.id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_title AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE title_id = OLD.title_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Title WHERE id = OLD.title_id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_short_description AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE short_description_id = OLD.short_description_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Short_Description WHERE id = OLD.short_description_id; END")
        cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_extended_description AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE extended_description_id = OLD.extended_description_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Extended_Description WHERE id = OLD.extended_description_id; END")
        cursor.execute("CREATE TRIGGER tr_on_update_cascade_t_data AFTER UPDATE ON T_Data FOR EACH ROW WHEN (OLD.title_id <> NEW.title_id AND ((SELECT event_id FROM T_Data WHERE title_id = OLD.title_id LIMIT 1) ISNULL)) BEGIN DELETE FROM T_Title WHERE id = OLD.title_id; END")
        cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('0','Sky Private EPG','0')")
        cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('1','DVB Now/Next Table','0')")
        cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('2','DVB Schedule (same Transponder)','0')")
        cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('3','DVB Schedule Other (other Transponder)','0')")
        cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('4','Viasat','0')")
        connection.commit()
        cursor.close()
        connection.close()
        log.write("[EPGImport] loading empty epg.db")
        """
        eEPGCache.load(self.epginstance)
        self.session.open(MessageBox, _("EPG database was emptied"),  MessageBox.TYPE_INFO)

class EPGImportProfile(ConfigListScreen, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        Screen.setTitle(self, _("Days Profile"))
        self["Title"] = self["title"] = StaticText(_("Days Profile"))
        self.skinName = 'EPGImportProfile'
        self.skin = getSkin(self.skinName)
        self.list = []
        weekdays = list(day_name)
        for i in range(7):
            self.list.append(getConfigListEntry(weekdays[i], config.plugins.extra_epgimport.day_import[i]))
        ConfigListScreen.__init__(self, self.list)
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Save"))
        self["setupActions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {
                "red": self.keyCancel,
                "green": self.save,
                "save": self.save,
                "cancel": self.keyCancel,
                "ok": self.save,
            }, -2)
        self.onLayoutFinish.append(self.createSummary)

    def save(self):
        if not any(config.plugins.extra_epgimport.day_import[i].value for i in range(0, 7)):
            self.session.open(MessageBox, _("You may not use this settings!\nAt least one day a week should be included!"), MessageBox.TYPE_INFO, timeout=6)
            return
        ConfigListScreen.keySave(self)

class EPGImportLog(Screen):
    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        Screen.setTitle(self, _("EPG Import Log"))
        self["Title"] = self["title"] = StaticText(_("EPG Import Log"))
        self.skinName = 'EPGImportLog'
        self.skin = getSkin(self.skinName)
        self["key_red"] = Button(_("Clear"))
        self["key_green"] = Button()
        self["key_yellow"] = Button()
        self["key_blue"] = Button(_("Save"))
        self["list"] = ScrollLabel(log.getvalue())
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "red": self.clear,
                "green": self.cancel,
                "yellow": self.cancel,
                "save": self.save,
                "blue": self.save,
                "cancel": self.cancel,
                "ok": self.cancel,
                "left": self["list"].pageUp,
                "right": self["list"].pageDown,
                "up": self["list"].pageUp,
                "down": self["list"].pageDown,
                "pageUp": self["list"].pageUp,
                "pageDown": self["list"].pageDown
            }, -2)

        self.timer = eTimer()
        if isDreamOS:
            self.timer_conn = self.timer.timeout.connect(self.getLog)
        else:
            self.timer.callback.append(self.getLog)
        self.timer.start(3000)
        self.onLayoutFinish.append(self.getLog)
        self.onClose.append(self.__onClose)
        self.counter = 0

    def __onClose(self):
        self.timer.stop()

    def getLog(self):
        txt = log.getvalue()
        counter = len(txt)
        if not self.counter:
            self["list"].setText(txt)
        elif counter > self.counter:
            if isDreamOS:
                self["list"].setText(txt)
                self["list"].lastPage()
            else:
                self["list"].setText(txt, showBottom=True)
        self.counter = counter

    def save(self):
        try:
            with open('/tmp/epgimport.log', 'w') as f:
                f.write(log.getvalue())
                self.session.open(MessageBox, _("Write to /tmp/epgimport.log"), MessageBox.TYPE_INFO, timeout=5, close_on_any_key=True)
        except Exception as e:
            self["list"].setText("Failed to write /tmp/epgimport.log: " + str(e))
        self.close(True)

    def cancel(self):
        self.close(False)

    def clear(self):
        log.logfile.truncate(0)
        log.logfile.seek(0)
        self.close(False)

class EPGImportDownloader(MessageBox):
    def __init__(self, session):
        MessageBox.__init__(self, session, _("Last import: ") + config.plugins.extra_epgimport.last_import.value + _(" events\n") + _("\nImport of epg data will start.\nThis may take a few minutes.\nIs this ok?"), MessageBox.TYPE_YESNO)
        self.skinName = "MessageBox"

def msgClosed(ret):
    if ret:
        if autoStartTimer is not None and not epgimport.isImportRunning():
            print("[EPGImport] Run manual starting import", file=log)
            autoStartTimer.runImport()

def start_import(session, **kwargs):
    session.openWithCallback(msgClosed, EPGImportDownloader)

def main(session, **kwargs):
    if not ensure_runtime_modules():
        session.open(MessageBox, _("EPGImport load error: %s") % str(runtime_import_error), MessageBox.TYPE_ERROR, timeout=15)
        return
    # Clear log at start of plugin operation
    try:
        log.logfile.truncate(0)
        log.logfile.seek(0)
    except Exception:
        pass
    # Delete pyc/pyo files when plugin starts
    deletePycPyoFiles()
    session.openWithCallback(doneConfiguring, EPGImportConfig)

def run_from_main_menu(menuid, **kwargs):
    if menuid == "mainmenu" and config.plugins.epgimport.showinmainmenu.getValue():
        return [(_("EPGImport"), main, "epgimporter", 45)]
    else:
        return []

def run_from_epg_menu(menuid, **kwargs):
    if menuid == "epg" and config.plugins.epgimport.showinmainmenu.getValue():
        return [(_("EPG-Importer"), main, "epgimporter", 90)]
    else:
        return []

def epgmenu(menuid, **kwargs):
    if menuid == "setup":
        return [(_("EPGImport"), main, "epgimporter", 1002)]
    else:
        return []

def doneConfiguring(retval=False):
    if retval is True:
        if autoStartTimer is not None:
            autoStartTimer.update()

def doneImport(reboot=False, epgfile=None):
    if not ensure_runtime_modules():
        return
    global lastImportResult, BouquetChannelListList, serviceIgnoreList
    BouquetChannelListList = None
    serviceIgnoreList = None
    event_count = epgimport.eventCount if epgimport.eventCount is not None else 0
    lastImportResult = (time(), event_count)

    # Handle different image types
    profile = getRuntimeProfile(refresh=True)
    is_pli = profile.get("is_openpli", False)
    is_oea = profile.get("is_oea", False)
    is_vti = profile.get("is_vti", False)
    is_openatv_py313 = profile.get("is_openatv_python_313", False)

    # openATV Python 3.13+, PLi, OE-A, VTI and DreamOS usually don't need restart
    if EPGImport.should_skip_restart():
        reboot = False
        if profile.get("is_dreambox", False):
            print("[EPGImport] DreamOS detected - reboot forced to False, NO RESTART will occur", file=log)
        elif is_openatv_py313:
            print("[EPGImport] openATV Python 3.13+ detected - NO RESTART needed", file=log)
        elif is_vti:
            print("[EPGImport] VTI detected - NO RESTART needed", file=log)
        elif is_pli:
            print("[EPGImport] PLi detected - NO RESTART needed", file=log)
        elif is_oea:
            print("[EPGImport] OE-A detected - NO RESTART needed", file=log)
    try:
        start, count = lastImportResult
        localtimes = strftime('%d %b %Y %H:%M:%S', localtime(time()))
        lastimport = "%s, %d" % (localtimes, count)
        print("[EPGImport] Save last import date and count event: %d events" % count, file=log)
        config.plugins.extra_epgimport.last_import.value = lastimport
        config.plugins.extra_epgimport.last_import.save()
    except Exception as e:
        print("[EPGImport] Error to save last import date and count event: %s" % str(e), file=log)

    # Only allow restart on images that need it
    if reboot and not EPGImport.should_skip_restart():
        if Screens.Standby.inStandby:
            print("[EPGImport] Restart enigma2", file=log)
            restartEnigma(True)
        else:
            msg = _("EPG Import finished, %d events") % event_count + "\n" + _("You must restart Enigma2 to load the EPG data,\nis this OK?")
            _session.openWithCallback(restartEnigma, MessageBox, msg, MessageBox.TYPE_YESNO, timeout=15, default=True)
            print("[EPGImport] Need restart enigma2", file=log)
    else:
        print("[EPGImport] No restart needed (reboot=%s)" % reboot, file=log)

    if not reboot:
        if config.plugins.epgimport.parse_autotimer.value and fileExists(resolveFilename(SCOPE_PLUGINS, "Extensions/AutoTimer/plugin.py")):
            try:
                from Plugins.Extensions.AutoTimer.plugin import autotimer
                if autotimer is None:
                    AutoTimer = _getAutoTimerClass()
                    if AutoTimer is None:
                        raise ImportError('AutoTimer')
                    autotimer = AutoTimer()
                autotimer.readXml()
                checkDeepstandby(_session, parse=True)
                autotimer.parseEPGAsync(simulateOnly=False)
                print("[EPGImport] Run start parse autotimers", file=log)
            except:
                print("[EPGImport] Could not start autotimers", file=log)
                checkDeepstandby(_session, parse=False)
        else:
            checkDeepstandby(_session, parse=False)

class checkDeepstandby(object):
    def __init__(self, session, parse=False):
        self.session = session
        if parse:
            self.FirstwaitCheck = eTimer()
            if isDreamOS:
                self.FirstwaitCheck_conn = self.FirstwaitCheck.timeout.connect(self.runCheckDeepstandby)
            else:
                self.FirstwaitCheck.callback.append(self.runCheckDeepstandby)
            self.FirstwaitCheck.startLongTimer(600)
            print("[EPGImport] Wait for parse autotimers 30 sec.", file=log)
        else:
            self.runCheckDeepstandby()

    def runCheckDeepstandby(self):
        print("[EPGImport] Run check deep standby after import", file=log)
        if config.plugins.epgimport.shutdown.value and config.plugins.epgimport.deepstandby.value == 'wakeup':
            if config.plugins.epgimport.deepstandby_afterimport.value and getFPWasTimerWakeup():
                config.plugins.epgimport.deepstandby_afterimport.value = False
                if Screens.Standby.inStandby and not self.session.nav.getRecordings() and not Screens.Standby.inTryQuitMainloop:
                    print("[EPGImport] Returning to deep standby after wake up for import", file=log)
                    self.session.open(Screens.Standby.TryQuitMainloop, 1)
                else:
                    print("[EPGImport] No return to deep standby, not standby or running recording", file=log)

def restartEnigma(confirmed):
    if not confirmed:
        return
    # Save state of Enigma2 so we can return to the previous standby state
    if Screens.Standby.inStandby:
        try:
            open('/tmp/enigmastandby', 'wb').close()
        except Exception:
            print("Failed to create /tmp/enigmastandby", file=log)
    else:
        try:
            remove("/tmp/enigmastandby")
        except Exception:
            pass
    # Restart Enigma2 (TryQuitMainloop code 3 = restart)
    _session.open(Screens.Standby.TryQuitMainloop, 3)

##################################
# Autostart section
class AutoStartTimer(object):
    def __init__(self, session):
        self.session = session
        self.prev_onlybouquet = config.plugins.epgimport.import_onlybouquet.value
        self.prev_multibouquet = config.usage.multibouquet.value
        self.timer = eTimer()
        self.pauseAfterFinishImportCheck = eTimer()
        if isDreamOS:
            self.timer_conn = self.timer.timeout.connect(self.onTimer)
            self.pauseAfterFinishImportCheck_conn = self.pauseAfterFinishImportCheck.timeout.connect(self.afterFinishImportCheck)
        else:
            self.timer.callback.append(self.onTimer)
            self.pauseAfterFinishImportCheck.callback.append(self.afterFinishImportCheck)

        self.pauseAfterFinishImportCheck.startLongTimer(30)
        self.update()

    def getWakeTime(self):
        if config.plugins.epgimport.enabled.value:
            clock = config.plugins.epgimport.wakeup.value
            nowt = time()
            now = localtime(nowt)
            return int(mktime((now.tm_year, now.tm_mon, now.tm_mday, clock[0], clock[1], lastMACbyte() // 5, 0, now.tm_yday, now.tm_isdst)))
        else:
            return -1

    def update(self, atLeast=0):
        self.timer.stop()
        wake = self.getWakeTime()
        now_t = time()
        now = int(now_t)
        now_day = localtime(now_t)
        if wake > 0:
            cur_day = int(now_day.tm_wday)
            wakeup_day = WakeupDayOfWeek()
            if wakeup_day == -1:
                print("[EPGImport] wakeup day of week disabled", file=log)
                return -1
            if wake < now + atLeast:
                wake += 86400 * wakeup_day
            else:
                if not config.plugins.extra_epgimport.day_import[cur_day].value:
                    wake += 86400 * wakeup_day
            next = wake - now
            self.timer.startLongTimer(next)
        else:
            wake = -1
        print("[EPGImport] WakeUpTime now set to", strftime('%c', localtime(wake)), "(now=%s)" % strftime('%c', localtime(now)), file=log)
        return wake

    def runImport(self):
        # Adding the option to kill stuck processes before starting import
        if config.plugins.epgimport.killstuck.value:
            print("[EPGImport] Killing stuck EPG import processes before starting new import", file=log)
            _terminate_stuck_import_processes(getRuntimeProfile(refresh=True))
            # Give system time to clean up
            sleep(2)

        if self.prev_onlybouquet != config.plugins.epgimport.import_onlybouquet.value or self.prev_multibouquet != config.usage.multibouquet.value:
            self.prev_onlybouquet = config.plugins.epgimport.import_onlybouquet.value
            self.prev_multibouquet = config.usage.multibouquet.value
        EPGConfig.channelCache = {}
        cfg = EPGConfig.loadUserSettings()
        sources = [s for s in EPGConfig.enumSources(CONFIG_PATH, filter=cfg["sources"])]
        if sources:
            sources.reverse()
            epgimport.sources = sources
            startImport()

    def onTimer(self):
        self.timer.stop()
        now = int(time())
        print("[EPGImport] onTimer occured at", strftime('%c', localtime(now)), file=log)
        wake = self.getWakeTime()
        # If we're close enough, we're okay...
        atLeast = 0
        if wake - now < 60:
            self.runImport()
            atLeast = 60
        self.update(atLeast)

    def getSources(self):
        cfg = EPGConfig.loadUserSettings()
        sources = [s for s in EPGConfig.enumSources(CONFIG_PATH, filter=cfg["sources"])]
        if sources:
            return True
        return False

    def getStatus(self):
        wake_up = self.getWakeTime()
        now_t = time()
        now = int(now_t)
        now_day = localtime(now_t)
        if wake_up > 0:
            cur_day = int(now_day.tm_wday)
            wakeup_day = WakeupDayOfWeek()
            if wakeup_day == -1:
                print("[EPGImport] wakeup day of week disabled", file=log)
                return -1
            if wake_up < now:
                wake_up += 86400 * wakeup_day
            else:
                if not config.plugins.extra_epgimport.day_import[cur_day].value:
                    wake_up += 86400 * wakeup_day
        else:
            wake_up = -1
        return wake_up

    def afterFinishImportCheck(self):
        if config.plugins.epgimport.deepstandby.value == 'wakeup' and getFPWasTimerWakeup():
            if exists("/tmp/enigmastandby") or exists("/tmp/.EPGImportAnswerBoot"):
                print("[EPGImport] is restart enigma2", file=log)
            else:
                wake = self.getStatus()
                now_t = time()
                now = int(now_t)
                if 0 < wake - now <= 60 * 5:
                    if config.plugins.epgimport.standby_afterwakeup.value:
                        if not Screens.Standby.inStandby:
                            Notifications.AddNotification(Screens.Standby.Standby)
                            print("[EPGImport] Run to standby after wake up", file=log)
                    if config.plugins.epgimport.shutdown.value:
                        if not config.plugins.epgimport.standby_afterwakeup.value:
                            if not Screens.Standby.inStandby:
                                Notifications.AddNotification(Screens.Standby.Standby)
                                print("[EPGImport] Run to standby after wake up for checking", file=log)
                        if not config.plugins.epgimport.deepstandby_afterimport.value:
                            config.plugins.epgimport.deepstandby_afterimport.value = True
                            self.wait_timer = eTimer()
                            if isDreamOS:
                                self.wait_timer_conn = self.wait_timer.timeout.connect(self.startStandby)
                            else:
                                self.wait_timer.callback.append(self.startStandby)
                            self.wait_timer.start(10000, True)
                            print("[EPGImport] start wait_timer (10sec) for goto standby", file=log)

    def startStandby(self):
        if Screens.Standby.inStandby:
            print("[EPGImport] add checking standby", file=log)
            try:
                Screens.Standby.inStandby.onClose.append(self.onLeaveStandby)
            except:
                pass

    def onLeaveStandby(self):
        if config.plugins.epgimport.deepstandby_afterimport.value:
            config.plugins.epgimport.deepstandby_afterimport.value = False
            print("[EPGImport] checking standby remove, not deep standby after import", file=log)

def WakeupDayOfWeek():
    start_day = -1
    try:
        now = time()
        now_day = localtime(now)
        cur_day = int(now_day.tm_wday)
    except:
        cur_day = -1
    if cur_day >= 0:
        for i in range(1, 8):
            if config.plugins.extra_epgimport.day_import[(cur_day + i) % 7].value:
                return i
    return start_day

def onBootStartCheck():
    print("[EPGImport] onBootStartCheck", file=log)
    now = int(time())
    wake = autoStartTimer.getStatus()
    print("[EPGImport] now=%d wake=%d wake-now=%d" % (now, wake, wake - now), file=log)
    if (wake < 0) or (wake - now > 600):
        on_start = False
        if config.plugins.epgimport.runboot.value == "1":
            on_start = True
            print("[EPGImport] is boot", file=log)
        elif config.plugins.epgimport.runboot.value == "2" and not getFPWasTimerWakeup():
            on_start = True
            print("[EPGImport] is manual boot", file=log)
        elif config.plugins.epgimport.runboot.value == "3" and getFPWasTimerWakeup():
            on_start = True
            print("[EPGImport] is automatic boot", file=log)
        flag = '/tmp/.EPGImportAnswerBoot'
        if config.plugins.epgimport.runboot_restart.value and config.plugins.epgimport.runboot.value != "3":
            if exists(flag):
                on_start = False
                print("[EPGImport] not starting import - is restart enigma2", file=log)
            else:
                try:
                    open(flag, 'wb').close()
                except:
                    print("Failed to create /tmp/.EPGImportAnswerBoot", file=log)
        if config.plugins.epgimport.runboot_day.value:
            now = localtime()
            cur_day = int(now.tm_wday)
            if not config.plugins.extra_epgimport.day_import[cur_day].value:
                on_start = False
                print("[EPGImport] wakeup day of week does not match", file=log)
        if on_start:
            print("[EPGImport] starting import because auto-run on boot is enabled", file=log)
            autoStartTimer.runImport()
    else:
        print("[EPGImport] import to start in less than 10 minutes anyway, skipping...", file=log)

def autostart(reason, session=None, **kwargs):
    "called with reason=1 to during shutdown, with reason=0 at startup?"
    global autoStartTimer
    global _session
    print("[EPGImport] autostart (%s) occured at %s" % (reason, strftime('%c', localtime(time()))), file=log)
    if reason == 0 and _session is None:
        if not ensure_runtime_modules():
            return
        if session is not None:
            _session = session
            if autoStartTimer is None:
                autoStartTimer = AutoStartTimer(session)
            if config.plugins.epgimport.runboot.value != "4":
                onBootStartCheck()
    # If WE caused the reboot, put the box back in standby.
    if reason == 0 and exists("/tmp/enigmastandby"):
        print("[EPGImport] Returning to standby", file=log)
        if not Screens.Standby.inStandby:
            Notifications.AddNotification(Screens.Standby.Standby)
        try:
            remove("/tmp/enigmastandby")
        except:
            pass
    elif reason != 0:
        print("[EPGImport] Stop", file=log)

def getNextWakeup():
    "returns timestamp of next time when autostart should be called"
    if autoStartTimer:
        if config.plugins.epgimport.deepstandby.value == 'wakeup' and autoStartTimer.getSources():
            print("[EPGImport] Will wake up from deep sleep", file=log)
            return autoStartTimer.getStatus()
    return -1


# we need this helper function to identify the descriptor
description = _("Automated EPG Importer")
config.plugins.epgimport.showinextensions.addNotifier(setExtensionsmenu, initial_call=False, immediate_feedback=False)
extDescriptor = PluginDescriptor(name=_("EPGImport"), description=description, where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=extensionsmenu)

def Plugins(**kwargs):
    result = []

    # Add the plugin to the plugins menu (always)
    result.append(
        PluginDescriptor(
            name=_("EPGImport"),
            description=_("Automated EPG Importer"),
            where=[PluginDescriptor.WHERE_PLUGINMENU],
            icon="icon/plugin.png",
            fnc=main,
        )
    )

    # Add the plugin to the main menu if enabled
    if config.plugins.epgimport.showinmainmenu.value:
        result.append(
            PluginDescriptor(
                name=_("EPGImport now"),
                description=_("Start EPG import immediately"),
                where=[PluginDescriptor.WHERE_MENU],
                icon="icon/plugin.png",
                fnc=run_from_main_menu,
            )
        )
        result.append(
            PluginDescriptor(
                name=_("EPGImport"),
                description=_("Automated EPG Importer"),
                where=[PluginDescriptor.WHERE_MENU],
                fnc=run_from_epg_menu,
            )
        )

    # Add the plugin to the setup menu
    result.append(
        PluginDescriptor(
            name=_("EPGImport"),
            description=_("Automated EPG Importer"),
            where=[PluginDescriptor.WHERE_MENU],
            fnc=epgmenu,
        )
    )

    # Add the plugin to the extensions menu if enabled
    if config.plugins.epgimport.showinextensions.value:
        result.append(
            PluginDescriptor(
                name=_("EPGImport"),
                description=_("Automated EPG Importer"),
                where=[PluginDescriptor.WHERE_EXTENSIONSMENU],
                icon="icon/plugin.png",
                fnc=extensionsmenu,
            )
        )

    # Add the plugin for autostart
    result.append(
        PluginDescriptor(
            name=_("EPGImport"),
            description=_("Automated EPG Importer"),
            where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART],
            icon="icon/plugin.png",
            fnc=autostart,
            wakeupfnc=getNextWakeup,
        )
    )

    return result
