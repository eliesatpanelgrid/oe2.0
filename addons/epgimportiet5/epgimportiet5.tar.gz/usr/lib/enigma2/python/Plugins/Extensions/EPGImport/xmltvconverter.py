# -*- coding: utf-8 -*-
# xmltvconverter.py
#
# XMLTV-format EPG data parser.
# Converts XMLTV programme elements into Enigma2 EPG event tuples.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS, OpenATV, VTI, OpenSource Enigma2 images
#
# The code modified by Lululla
# The code modified by iet5
#
from __future__ import print_function

# Use the shared DreamOS detection to keep event tuple formats consistent.
try:
    from . import isDreamOS as isDreamOS
except ImportError:
    # Fallback for standalone or offline testing.
    try:
        from os import path as _path
        from eEnv import resolve as _eenv_resolve   # only present on DreamOS
        isDreamOS = _path.isdir(_eenv_resolve("${sysconfdir}/dpkg"))
    except Exception:
        isDreamOS = False

# =========================
# Standard library imports
# =========================
import calendar
import os
import re
import time
import sys

# =========================
# Enigma2 / framework imports
# =========================
try:
    # Components may not be present during unit tests; guard with try/except
    from Components.Language import language
    from Components.config import config
except Exception:
    language = None
    config = None

# =========================
# Local project imports
# =========================
# These are expected to be provided by the plugin environment
from . import log
from .EPGConfig import xml_unescape, enumerateXML
from .EPGImport import ISO639_associations

# ===== Fast XML enumerator (5x faster) =====
try:
    from xml.etree.ElementTree import iterparse
    def fastEnumerateXML(fileobj, tag):
        for event, elem in iterparse(fileobj, events=("end",)):
            if elem.tag == tag:
                yield elem
                elem.clear()
except Exception:
    fastEnumerateXML = enumerateXML

# =========================================================
# Module-level constants
# =========================================================

# Active interface language (two-letter ISO code)
# Fall back to English when Components.Language is unavailable.
LANG = language.getLanguage()[:2] if language else 'en'

# Language priority list for get_xml_string().
# When a source contains multiple lang= variants of the same field,
# we pick the best available language in this order:
#
# Arabic remains a fallback for sources that provide no English text.
# The list means: try each language in order; use the first one found.
# If NONE of the preferred languages exist, fall back to whatever text is present.
if LANG == 'ar':
    # Arabic UI: Arabic first, then English, then anything
    _LANG_PRIORITY = ['ar', 'en']
else:
    # English (or other) UI: English first, then Arabic, then anything.
    # Arabic is included so Arabic-only sources are never silently dropped.
    _LANG_PRIORITY = [LANG, 'ar', 'en']

# Remove unwanted whitespace before punctuation (e.g. " ," -> ",")
PATTERN = re.compile(r'\s+(?=(?:[,.?!:;]))')

# Running count of XML elements processed in the current file (used by Timer)
EVENTCOUNTER = 0

# Python version helpers
IS_PY2   = (sys.version_info[0] < 3)
IS_PY314 = (sys.version_info[:2] >= (3, 14))
DISABLE_TIME_FILTER = False

try:
    _text_type = unicode
except NameError:
    _text_type = str
_string_types = (str, _text_type)


class ChannelServiceList(list):
    """Service-reference list with the original XMLTV channel id attached."""

    pass


def _stop_duplicates_sources_enabled():
    # Reuse the module-level configuration in this hot path.
    try:
        return bool(config.plugins.epgimport.stop_duplicates_sources.value)
    except Exception:
        return False


def _services_with_channel_id(services, channel_id):
    """Keep channel_id available for duplicate-event fingerprinting."""
    if not _stop_duplicates_sources_enabled():
        return services
    try:
        if isinstance(services, _string_types):
            service_list = ChannelServiceList([services])
        else:
            service_list = ChannelServiceList(list(services))
    except Exception:
        service_list = ChannelServiceList([services])
    service_list.channel_id = channel_id
    service_list.xmltv_channel_id = channel_id
    return service_list


def _should_bypass_time_filter():
    if DISABLE_TIME_FILTER:
        return True
    # Keep the time-window filtering identical on DreamOS and open-source images.
    # Old events must not be counted as freshly imported events just because the
    # runtime is DreamOS/Python 2.
    return False


BYPASS_TIME_FILTER = _should_bypass_time_filter()

class Timer(object):
    def __enter__(self):
        global EVENTCOUNTER
        self.start = time.time()
        EVENTCOUNTER = 0
        return self

    def __exit__(self, *args):
        elapsed = time.time() - self.start
        # Print processed events, elapsed time and approx rate to the provided log
        try:
            rate = EVENTCOUNTER / elapsed if elapsed > 0 else 0.0
        except Exception:
            rate = 0.0
        try:
            print('Processed {} events in {} or ~{:.0f} per second'.format(
                EVENTCOUNTER,
                time.strftime("%H:%M:%S", time.gmtime(elapsed)),
                rate
            ), file=log)
        except Exception:
            # In case `log` is not writable, silently ignore
            pass


class XMLTVConverter(object):
    def __init__(self, channels_dict, category_dict=None, dateformat='%Y%m%d%H%M%S %Z', offset=0):
        self.channels = channels_dict
        self.categories = category_dict or {}
        self.offset = offset
        self.debug_seen_channels = set()
        self.debug_dca_channels = set()
        self.debug_logged_events = 0
        self.invalid_time_count = 0
        self.filter_bypassed_count = 0
        self.window_filtered_count = 0
        self.parser_error_count = 0
        self.min_event_start = None
        self.max_event_stop = None
        # Fix parsing function to be compatible with Python 2 and 3
        if dateformat.startswith('%Y%m%d%H%M%S'):
            # Keep behavior compatible: we will parse explicit numeric fields below
            # Note: this constructs a struct_time with placeholders where needed
            def _date_parser(x):
                # Ensure string of digits; pad to at least 14 digits
                digits = ''.join(ch for ch in x if ch.isdigit())
                digits = digits[:14].ljust(14, '0')
                try:
                    # year (4 digits) then month, day, hour, minute, second
                    year = int(digits[0:4])
                    month = int(digits[4:6])
                    day = int(digits[6:8])
                    hour = int(digits[8:10])
                    minute = int(digits[10:12])
                    second = int(digits[12:14])
                    return time.struct_time((year, month, day, hour, minute, second, 0, -1, -1))
                except Exception:
                    # fallback
                    return time.struct_time((1970, 1, 1, 0, 0, 0, 0, -1, -1))
            self.dateParser = _date_parser
        else:
            self.dateParser = lambda x: time.strptime(x, dateformat)
        if self.offset:
            print("[XMLTVConverter] Using a custom time offset of %d seconds" % self.offset, file=log)

    def get_xml_string(self, elem, name):
        """Return the best available text using the language priority list."""
        candidates = {}
        first_text = ''   # absolute fallback: very first non-empty text found
        try:
            for node in elem.iter(name):
                value = node.text
                if not value:
                    continue
                value = xml_unescape(value)
                if not value:
                    continue
                lang_code = node.get('lang', '')   # '' means no lang attribute
                if not first_text:
                    first_text = value
                if lang_code not in candidates:
                    candidates[lang_code] = value
        except Exception:
            pass

        # Step 2: pick best language using priority list
        result = ''
        for preferred_lang in _LANG_PRIORITY:
            if preferred_lang in candidates:
                result = candidates[preferred_lang]
                break

        # Fall back to any available text, including entries without lang.
        if not result:
            # Try the empty-lang entry first (some sources omit lang attribute)
            result = candidates.get('', first_text)

        # Remove spurious spaces before punctuation (e.g. " ," -> ",")
        return PATTERN.sub('', result) if result else ''

    def get_xml_rating_string(self, elem):
        """
        Extract the parental rating value from a <rating> element.
        Uses elem.iter() (Python 2.7+ / all Python 3) - getiterator() is removed in Py3.9.
        """
        r = ''
        try:
            # iter() is available from Python 2.7 ElementTree 1.3 onwards
            for node in elem.iter('rating'):
                for val in node.iter('value'):
                    txt = val.text
                    if txt:
                        r = txt.replace("+", "")
                        break
                if r:
                    break
        except Exception:
            pass
        return r

    def get_timestamp_utc(self, xmltv_date):
        try:
            if not xmltv_date:
                return 0
            # normalize whitespace
            xmltv_date = xmltv_date.strip()

            # Accept formats like:
            #  YYYYMMDDHHMMSS
            #  YYYYMMDDHHMMSS+HHMM or YYYYMMDDHHMMSS-HHMM
            #  YYYYMMDDHHMMSS +HHMM (with space) or with timezone missing
            # Extract first 14 digits reliably (pad if needed)
            digits = ''.join(ch for ch in xmltv_date if ch.isdigit())
            date_str = digits[:14].ljust(14, '0')
            # Parse date and time components
            year = int(date_str[0:4])
            month = int(date_str[4:6])
            day = int(date_str[6:8])
            hour = int(date_str[8:10])
            minute = int(date_str[10:12])
            second = int(date_str[12:14])

            # Calculate UTC timestamp from the naive date (treat as local-less time)
            # Use calendar.timegm for consistency (assumes tuple is in UTC)
            timestamp = calendar.timegm((year, month, day, hour, minute, second, 0, 0, 0))

            # Detect timezone offset if present at the end of the original string
            # Look for +HHMM or -HHMM (possibly with space before)
            tz_match = None
            # last 6 characters can be ' +HHMM' or '+HHMM' etc.
            if len(xmltv_date) >= 5:
                tail = xmltv_date[-6:].replace(' ', '')
                if (tail.startswith('+') or tail.startswith('-')) and len(tail) >= 5:
                    sign = tail[0]
                    tz_digits = tail[1:5]
                    if tz_digits.isdigit():
                        tz_match = (sign, tz_digits)
            if tz_match:
                sign, tz_digits = tz_match
                timezone_offset = int(tz_digits)
                total_offset_seconds = (timezone_offset // 100) * 3600 + (timezone_offset % 100) * 60
                if sign == '+':
                    timestamp -= total_offset_seconds
                else:
                    timestamp += total_offset_seconds
            return timestamp
        except Exception:
            return 0

    def format_timestamp_utc(self, timestamp_value):
        try:
            if not timestamp_value:
                return 'n/a'
            return time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime(int(timestamp_value)))
        except Exception:
            return 'n/a'

    def get_category(self, category_name, duration):
        if not category_name or not hasattr(category_name, 'strip'):
            return 0
            
        # Try full match first
        if category_name in self.categories:
            category_value = self.categories[category_name]
            if isinstance(category_value, tuple):
                if len(category_value) > 1:
                    if duration > 60 * category_value[1]:
                        return category_value[0]
                    return 0
                if len(category_value) == 1:
                    return category_value[0]
            return category_value
            
        # Fallback to comma-separated multi-category parsing
        if hasattr(category_name, 'split'):
            categories = category_name.split(',')
            for category in categories:
                category = category.strip()
                if category in self.categories:
                    category_value = self.categories[category]
                    if isinstance(category_value, tuple):
                        if len(category_value) > 1:
                            if duration > 60 * category_value[1]:
                                return category_value[0]
                        elif len(category_value) == 1:
                            return category_value[0]
                    else:
                        return category_value
        return 0

    def enumFile(self, fileobj):
        global EVENTCOUNTER
        if not self.channels:
            return

        try:
            print("[XMLTVConverter] enumFile start: channels=%s isDreamOS=%s py2=%s disable_time_filter=%s bypass=%s" % (len(self.channels), isDreamOS, IS_PY2, DISABLE_TIME_FILTER, BYPASS_TIME_FILTER), file=log)
        except Exception:
            pass

        histseconds = 10800
        try:
            histseconds = int(config.epg.histminutes.value) * 60
        except Exception:
            if isDreamOS:
                try:
                    histseconds = int(config.misc.epgcache_outdated_timespan.value) * 3600
                except Exception:
                    pass

        # 'now_timestamp_utc' will be used as a sliding marker for progress reports
        now_timestamp_utc = int(time.time()) - histseconds
        last_progress_time = int(time.time())   # wall-clock tracker for the 10-second log interval
        found_channels_count = 0
        processed_events = 0

        with Timer():
            for elem in fastEnumerateXML(fileobj, 'programme'):
                EVENTCOUNTER += 1
                data_tuple = None
                try:
                    # channel attribute may be encoded; normalize and lower for lookup
                    channel = xml_unescape(elem.get('channel', '').lower())

                    # DEBUG: Check if channel exists in loaded mapping
                    if channel in self.channels:
                        found_channels_count += 1
                        services = self.channels[channel]
                        try:
                            services_list = sorted(list(services))
                        except Exception:
                            try:
                                services_list = list(services)
                            except Exception:
                                services_list = [str(services)]
                        if channel not in self.debug_seen_channels and len(self.debug_seen_channels) < 12:
                            print("[XMLTVConverter][MATCH] channel_id=%s services=%s" % (channel, services_list[:4]), file=log)
                            self.debug_seen_channels.add(channel)
                        if any(('DCA0000' in str(s).upper()) for s in services_list):
                            if channel not in self.debug_dca_channels and len(self.debug_dca_channels) < 12:
                                print("[XMLTVConverter][MATCH-DCA0000] channel_id=%s services=%s" % (channel, services_list[:4]), file=log)
                                self.debug_dca_channels.add(channel)
                        start_time = self.get_timestamp_utc(elem.get('start', '').strip()) + self.offset
                        stop_time = self.get_timestamp_utc(elem.get('stop', '').strip()) + self.offset
                        has_valid_times = bool(start_time and stop_time and stop_time > start_time)
                        if has_valid_times:
                            if self.min_event_start is None or start_time < self.min_event_start:
                                self.min_event_start = start_time
                            if self.max_event_stop is None or stop_time > self.max_event_stop:
                                self.max_event_stop = stop_time
                        in_window = bool(has_valid_times and stop_time > now_timestamp_utc and start_time < stop_time)
                        if has_valid_times and (in_window or BYPASS_TIME_FILTER):
                            if BYPASS_TIME_FILTER and not in_window:
                                self.filter_bypassed_count += 1
                                if self.filter_bypassed_count <= 8:
                                    print("[XMLTVConverter][BYPASS] channel_id=%s start=%s stop=%s marker=%s services=%s" % (channel, start_time, stop_time, now_timestamp_utc, services_list[:4]), file=log)
                            title = self.get_xml_string(elem, 'title')
                            subtitle = self.get_xml_string(elem, 'sub-title')
                            description = self.get_xml_string(elem, 'desc')
                            category = self.get_xml_string(elem, 'category')

                            # If subtitle exists, add a newline to separate from title in combined fields
                            if subtitle:
                                subtitle += '\n'

                            # Prepare data for return
                            duration = stop_time - start_time
                            event_type = self.get_category(category, duration)

                            try:
                                rating_str = self.get_xml_rating_string(elem)
                                rating = [('eng', int(rating_str) - 3)] if rating_str else None
                            except Exception:
                                rating = None

                            # Build tuple for DreamOS including language code
                            mapped_services = _services_with_channel_id(self.channels[channel], channel)
                            if isDreamOS:
                                language_code = ISO639_associations.get(LANG, 'eng')
                                if rating:
                                    data_tuple = (mapped_services, (start_time, duration, title, subtitle, description, event_type, language_code, rating))
                                else:
                                    data_tuple = (mapped_services, (start_time, duration, title, subtitle, description, event_type, language_code))
                            else:
                                if rating:
                                    data_tuple = (mapped_services, (start_time, duration, title, subtitle, description, event_type, 0, rating))
                                else:
                                    data_tuple = (mapped_services, (start_time, duration, title, subtitle, description, event_type))
                            processed_events += 1
                            if self.debug_logged_events < 8:
                                print("[XMLTVConverter][YIELD] channel_id=%s title=%s start=%s duration=%s services=%s" % (channel, title, start_time, duration, services_list[:4]), file=log)
                                self.debug_logged_events += 1
                        else:
                            if not has_valid_times:
                                self.invalid_time_count += 1
                                if self.invalid_time_count <= 8:
                                    print("[XMLTVConverter][SKIP-INVALID-TIME] channel_id=%s start=%s stop=%s" % (channel, start_time, stop_time), file=log)
                            else:
                                self.window_filtered_count += 1
                                if self.window_filtered_count <= 8:
                                    print("[XMLTVConverter][SKIP-WINDOW] channel_id=%s start=%s stop=%s marker=%s bypass=%s" % (channel, start_time, stop_time, now_timestamp_utc, BYPASS_TIME_FILTER), file=log)
                except Exception as e:
                    self.parser_error_count += 1
                    if self.parser_error_count <= 8:
                        try:
                            print("[XMLTVConverter][ERROR] programme parse failed: %s" % e, file=log)
                        except Exception:
                            pass
                # Log progress every 10 seconds of wall-clock time (uses a separate tracker)
                current_time = int(time.time())
                if current_time - last_progress_time >= 10:
                    last_progress_time = current_time
                    try:
                        print("[XMLTVConverter][PROGRESS] events=%s matches=%s imported=%s" % (EVENTCOUNTER, found_channels_count, processed_events), file=log)
                    except Exception:
                        pass
                # Only yield when a valid event was built (channel matched and time OK)
                if data_tuple is not None:
                    yield data_tuple

        # Final summary
        try:
            current_timestamp = int(time.time())
            print("[XMLTVConverter] RANGE: first_start=%s last_stop=%s now=%s" % (
                self.format_timestamp_utc(self.min_event_start),
                self.format_timestamp_utc(self.max_event_stop),
                self.format_timestamp_utc(current_timestamp)
            ), file=log)
            if self.max_event_stop and self.max_event_stop < current_timestamp:
                age_seconds = current_timestamp - self.max_event_stop
                age_days = age_seconds / 86400.0
                print("[XMLTVConverter][STALE-SOURCE] latest programme stop=%s is older than import time by %.2f days; import may succeed but current EPG views can stay empty." % (
                    self.format_timestamp_utc(self.max_event_stop),
                    age_days
                ), file=log)
            elif self.min_event_start and self.min_event_start > current_timestamp:
                lead_seconds = self.min_event_start - current_timestamp
                lead_days = lead_seconds / 86400.0
                print("[XMLTVConverter][FUTURE-SOURCE] earliest programme start=%s is ahead of import time by %.2f days; current EPG may stay empty until that window starts." % (
                    self.format_timestamp_utc(self.min_event_start),
                    lead_days
                ), file=log)
            print("[XMLTVConverter] FINAL: Total events: %s, Channel matches: %s, Imported events: %s, Bypassed time filter: %s, Invalid time skips: %s, Window skips: %s, Parse errors: %s" % (EVENTCOUNTER, found_channels_count, processed_events, self.filter_bypassed_count, self.invalid_time_count, self.window_filtered_count, self.parser_error_count), file=log)
        except Exception:
            pass
