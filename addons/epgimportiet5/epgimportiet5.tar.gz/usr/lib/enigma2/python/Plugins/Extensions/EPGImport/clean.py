# -*- coding: utf-8 -*-
"""EPG cache cleaning helper used internally by the EPGImport plugin."""

from __future__ import print_function

import glob
import os
import shutil


KNOWN_EPG_FILES = (
    "/etc/enigma2/epg.db",
    "/etc/enigma2/epg.dat",
    "/media/hdd/epg.db",
    "/media/hdd/epg.dat",
    "/media/usb/epg.db",
    "/media/usb/epg.dat",
)


def _remove_path(pathname):
    """Remove one known file or temporary directory without raising."""
    try:
        if os.path.isdir(pathname) and not os.path.islink(pathname):
            shutil.rmtree(pathname, ignore_errors=True)
        elif os.path.lexists(pathname):
            os.unlink(pathname)
    except Exception:
        pass


def _valid_epg_path(pathname):
    """Accept only absolute epg.dat/epg.db paths supplied by the runtime."""
    if not pathname or not os.path.isabs(pathname):
        return False
    return os.path.basename(pathname) in ('epg.dat', 'epg.db')


def clear_current_epg(epgcache, cleanup_paths=None):
    """
    Reproduce the established cleanup sequence before an EPG import.

    Known EPG files, runtime-selected cache files, their legacy backups, and
    temporary EPG paths are removed before the image-provided live-cache API
    is called. Return the method name used, or ``None`` when unavailable.
    """
    paths = list(KNOWN_EPG_FILES)
    for pathname in cleanup_paths or ():
        if _valid_epg_path(pathname):
            if pathname not in paths:
                paths.append(pathname)
            backup_path = pathname + '.backup'
            if backup_path not in paths:
                paths.append(backup_path)

    for pathname in paths:
        _remove_path(pathname)

    # Keep the same temporary cleanup patterns used by the established build.
    for pattern in ('/tmp/epg*', '/tmp/enigma2*'):
        for pathname in glob.glob(pattern):
            _remove_path(pathname)

    if epgcache is not None:
        for method_name in ('flushEPG', 'clear'):
            method = getattr(epgcache, method_name, None)
            if callable(method):
                method()
                return method_name
    return None
