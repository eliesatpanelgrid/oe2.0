#!/usr/bin/python
# -*- coding: utf-8 -*-
# import_source.py
#
# Downloads and installs EPGImport source files from a remote GitHub tarball.
# Handles safe extraction (path-traversal protection) and destination cleanup.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS, OpenATV, VTI, OpenSource Enigma2 images
#
from __future__ import print_function

import os
import ssl
import tarfile
from os import listdir, makedirs, chdir, remove, walk
from os.path import join, isdir, exists
from shutil import rmtree, copyfileobj, copytree, copy2


# =========================================================
# Directory creation helper (Python 2 / 3 safe)
# =========================================================
def make_dirs(directory):
    """Create *directory* and all parents; silently ignore if it already exists."""
    try:
        makedirs(directory)
    except OSError:
        if not isdir(directory):
            raise


# =========================================================
# URL open helper (Python 2 / 3 compatible)
# =========================================================
try:
    import urllib.request as urllib_request   # Python 3

    def url_open(url, context):
        """Open *url* with an SSL *context* (Python 3)."""
        return urllib_request.urlopen(url, context=context)

except ImportError:
    import urllib2 as urllib_request          # Python 2

    def url_open(url, context):              # noqa: F811
        """Open *url* without an SSL context (Python 2 - context arg ignored)."""
        return urllib_request.urlopen(url)


# =========================================================
# Directory tree copy helper (Python 2 / 3 safe)
# =========================================================
def copytree_compat(src, dst):
    """
    Copy a directory tree from *src* to *dst*.
    Removes *dst* first if it already exists (copytree requires a non-existent target).
    """
    if exists(dst):
        rmtree(dst, ignore_errors=True)
    copytree(src, dst)


# =========================================================
# Safe tarball extraction (prevents path-traversal attacks)
# =========================================================
def _is_within_directory(directory, target):
    """
    Return True only when *target* is fully inside *directory*.
    Protects against 'zip-slip' / path-traversal attacks.
    """
    base_dir   = os.path.abspath(directory)
    target_path = os.path.abspath(target)
    return target_path == base_dir or target_path.startswith(base_dir + os.sep)


def safe_extract_tar(tar, destination):
    """
    Extract all members of *tar* into *destination*, raising TarError if
    any member path escapes the destination directory.
    """
    for member in tar.getmembers():
        member_target = os.path.join(destination, member.name)
        if not _is_within_directory(destination, member_target):
            raise tarfile.TarError(
                "Unsafe path in tar archive (path traversal attempt): %s" % member.name
            )
    tar.extractall(path=destination)


# =========================================================
# SSL context helper (Python 2.7 / 3.x safe)
# =========================================================
def get_unverified_context():
    """
    Return an SSL context that skips certificate verification.
    Required for some Enigma2 images that lack up-to-date CA certificates.
    Falls back gracefully on Python 2.7 which may not support all SSL APIs.
    """
    # Primary: Python 2.7.9+ and all Python 3.x versions
    try:
        return ssl._create_unverified_context()
    except AttributeError:
        pass

    # Secondary: older Python 2.7 without _create_unverified_context
    try:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS)
        try:
            context.check_hostname = False
        except Exception:
            pass
        try:
            context.verify_mode = ssl.CERT_NONE
        except Exception:
            pass
        return context
    except Exception:
        pass

    # Last resort: no SSL context (plain HTTP only)
    return None


# =========================================================
# Main installation function
# =========================================================
def main(url):
    """
    Download the EPG sources tarball from *url*, extract it, and install
    the source files to /etc/epgimport.

    Steps:
      1. Create working directories
      2. Download the tarball (HTTP/HTTPS)
      3. Safe-extract the tarball
      4. Remove unwanted .bb build recipe files
      5. Copy source files to /etc/epgimport
      6. Remove the old epgimport.conf so the plugin reloads sources
      7. Sync filesystem
    """
    TMPSources   = "/var/volatile/tmp/EPGimport-Sources-main"
    dest_dir     = "/etc/epgimport"
    SETTINGS_FILE = "/etc/enigma2/epgimport.conf"
    tarball      = "main.tar.gz"

    # Ensure both directories exist
    make_dirs(TMPSources)
    make_dirs(dest_dir)

    # Change to the temp directory so relative paths work correctly
    chdir(TMPSources)

    context = get_unverified_context()

    # Download the tarball from the remote URL
    response = None
    try:
        response = url_open(url, context)
        with open(tarball, "wb") as out_file:
            copyfileobj(response, out_file)
    finally:
        if response is not None:
            try:
                response.close()
            except Exception:
                pass

    # Remove existing files in the destination directory before deploying new ones
    for item in listdir(dest_dir):
        item_path = join(dest_dir, item)
        try:
            if isdir(item_path):
                rmtree(item_path, ignore_errors=True)
            else:
                remove(item_path)
        except Exception as _e:
            print("[import_source] Could not remove %s: %s" % (item_path, _e))

    # Extract the tarball safely (path-traversal protected)
    try:
        with tarfile.open(tarball, "r:gz") as tar:
            safe_extract_tar(tar, TMPSources)
    except tarfile.TarError as _e:
        print("[import_source] Error extracting tar file: %s" % _e)
        return

    extracted_dir = join(TMPSources, "EPGimport-Sources-main")

    # Remove .bb OpenEmbedded build recipe files (not needed on target device)
    for root, _dirs, files in walk(extracted_dir):
        for fname in files:
            if fname.endswith(".bb"):
                try:
                    remove(join(root, fname))
                except Exception:
                    pass

    # Copy all extracted files and folders to the destination directory
    for item in listdir(extracted_dir):
        src_item = join(extracted_dir, item)
        try:
            if isdir(src_item):
                copytree_compat(src_item, join(dest_dir, item))
            else:
                copy2(src_item, dest_dir)
        except Exception as _e:
            print("[import_source] Could not copy %s: %s" % (src_item, _e))

    # Clean up the temporary extraction directory
    rmtree(TMPSources, ignore_errors=True)

    # Remove the old settings file so the plugin reloads and picks up new sources
    if exists(SETTINGS_FILE):
        try:
            remove(SETTINGS_FILE)
        except Exception as _e:
            print("[import_source] Could not remove settings file: %s" % _e)

    # Flush all filesystem buffers to storage (os.sync available on Python 3.3+)
    try:
        from os import sync as _sync
        _sync()
    except ImportError:
        # Python 2.7 and some older builds don't have os.sync; ignore
        pass

    print("[import_source] Sources installed successfully to %s" % dest_dir)


# Example usage (for testing outside the plugin):
# if __name__ == "__main__":
#     url = "https://github.com/Belfagor2005/EPGimport-Sources/archive/refs/heads/main.tar.gz"
#     main(url)
