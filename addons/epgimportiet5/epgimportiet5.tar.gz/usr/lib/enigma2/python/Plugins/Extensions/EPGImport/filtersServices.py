# -*- coding: utf-8 -*-
#
#  The code modified by iet5 Date Nov 2025
#
from __future__ import print_function
from . import _, getSkin, EPGConfig, log
from os import mkdir
from os.path import isdir, join
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from ServiceReference import ServiceReference
from Screens.ChannelSelection import service_types_radio, service_types_tv, ChannelSelectionBase
from enigma import eServiceReference, eServiceCenter
from Components.Sources.StaticText import StaticText
from Components.Sources.List import List
from Components.Label import Label


OFF = 0
EDIT_BOUQUET = 1
EDIT_ALTERNATIVES = 2
try:
    _basestring = basestring
except NameError:
    _basestring = str

SOURCE_PATH = "/etc/epgimport"


def getProviderName(ref):
    """Get the provider name for a given service reference."""
    if ref is None:
        return ""
    typestr = ref.getData(0) in (2, 10) and service_types_radio or service_types_tv
    pos = typestr.rfind(":")
    rootstr = "%s (channelID == %08x%04x%04x) && %s FROM PROVIDERS ORDER BY name" % (
        typestr[:pos + 1], ref.getUnsignedData(4), ref.getUnsignedData(2), ref.getUnsignedData(3), typestr[pos + 1:]
    )
    provider_root = eServiceReference(rootstr)
    serviceHandler = eServiceCenter.getInstance()
    if serviceHandler is None:
        return ""
    providerlist = serviceHandler.list(provider_root)
    if providerlist is not None:
        while True:
            provider = providerlist.getNext()
            if not provider.valid():
                break
            if provider.flags & eServiceReference.isDirectory:
                servicelist = serviceHandler.list(provider)
                if servicelist is not None:
                    while True:
                        service = servicelist.getNext()
                        if not service.valid():
                            break
                        if service == ref:
                            info = serviceHandler.info(provider)
                            return info and info.getName(provider) or "Unknown"
    return ""


class FiltersList(object):
    """Manage the ignore services list."""
    def __init__(self):
        self.services = []
        self.load()

    def loadFrom(self, filename):
        """Load services from a file, ignoring comments."""
        try:
            with open(filename, "r") as cfg:
                for line in cfg:
                    if not line or line[:1] in "#;\n":
                        continue
                    ref = line.strip()
                    if ref not in self.services:
                        self.services.append(ref)
        except Exception as e:
            print("Error loading from", filename, e, file=log)

    def saveTo(self, filename):
        """Save services to a file."""
        try:
            if not isdir(SOURCE_PATH):
                mkdir(SOURCE_PATH)
            with open(filename, "w") as cfg:
                for ref in self.services:
                    cfg.write("%s\n" % (ref))
        except Exception:
            return

    def load(self):
        """Load default ignore.conf file."""
        self.loadFrom(join(SOURCE_PATH, "ignore.conf"))

    def reload(self):
        """Reload services from file."""
        self.services = []
        self.load()

    def servicesList(self):
        return self.services

    def save(self):
        self.saveTo(join(SOURCE_PATH, "ignore.conf"))

    def addService(self, ref):
        if isinstance(ref, _basestring) and ref not in self.services:
            self.services.append(ref)

    def addServices(self, services):
        if isinstance(services, list):
            for s in services:
                if s not in self.services:
                    self.services.append(s)

    def delService(self, ref):
        if isinstance(ref, _basestring) and ref in self.services:
            self.services.remove(ref)

    def delAll(self):
        self.services = []
        self.save()


filtersServicesList = FiltersList()


class filtersServicesSetup(Screen):
    """Screen for managing ignore services list."""
    def __init__(self, session):
        Screen.__init__(self, session)
        self.RefList = filtersServicesList
        self.prev_list = self.RefList.services[:]
        Screen.setTitle(self, _("Ignore services list(press OK to save)"))
        self["Title"] = self["title"] = StaticText(_("Ignore services list(press OK to save)"))
        self.skinName = 'filtersServicesSetup'
        self.skin = getSkin(self.skinName)

        self["list"] = List([])
        self.updateList()

        self["key_red"] = Label("")
        self["key_green"] = Label(_("Add Provider"))
        self["key_yellow"] = Label(_("Add Channel"))
        self["key_blue"] = Label("")
        self.updateButtons()
        self["actions"] = ActionMap(
            [
                "OkCancelActions",
                "ColorActions"
            ],
            {
                "cancel": self.exit,
                "ok": self.keyOk,
                "red": self.keyRed,
                "green": self.keyGreen,
                "yellow": self.keyYellow,
                "blue": self.keyBlue
            },
            -1
        )

    def keyRed(self):
        """Delete selected service."""
        cur = self["list"].getCurrent()
        if cur and len(cur) > 2:
            self.RefList.delService(cur[2])
            self.updateList()
            self.updateButtons()

    def keyGreen(self):
        """Open provider selection."""
        self.session.openWithCallback(self.addServiceCallback, filtersServicesSelection, providers=True)

    def keyYellow(self):
        """Open channel selection."""
        self.session.openWithCallback(self.addServiceCallback, filtersServicesSelection)

    def addServiceCallback(self, *service):
        """Add selected service(s) to the ignore list."""
        if service:
            ref = service[0]
            if isinstance(ref, list):
                self.RefList.addServices(ref)
            else:
                refstr = ":".join(ref.toString().split(":")[:11])
                if any(x in refstr for x in ("1:0:", "4097:0:", "5001:0:", "5002:0:")):
                    self.RefList.addService(refstr)
            self.updateList()
            self.updateButtons()

    def keyBlue(self):
        """Delete all services."""
        if len(self["list"].getList()):
            self.session.openWithCallback(self.removeCallback, MessageBox, _("Really delete all list?"), MessageBox.TYPE_YESNO)

    def removeCallback(self, answer):
        if answer:
            self.RefList.delAll()
            self.updateList()
            self.updateButtons()
            self.prev_list = self.RefList.services[:]

    def keyOk(self):
        """Save list and close screen."""
        self.RefList.save()
        if self.RefList.services != self.prev_list:
            self.RefList.reload()
            EPGConfig.channelCache = {}
        self.close()

    def exit(self):
        """Cancel all changes and restore the previous list without saving."""
        self.RefList.services = self.prev_list[:]
        self.close()

    def updateList(self):
        """Update displayed list with service and provider names."""
        new_list = []
        for service in self.RefList.servicesList():
            if '1:0:' in service:
                try:
                    ref = eServiceReference(service)
                    provname = getProviderName(ref)
                    servname = ServiceReference(service).getServiceName() or "N/A"
                    new_list.append((servname, provname, service))
                except Exception as error:
                    print("Error resolving ignored service", service, error, file=log)
        self["list"].setList(new_list)

    def updateButtons(self):
        """Update action button labels based on list state."""
        current_list = self["list"].getList()
        if len(current_list):
            self["key_red"].setText(_("Delete selected"))
            self["key_blue"].setText(_("Delete all"))
        else:
            self["key_red"].setText("")
            self["key_blue"].setText("")


class filtersServicesSelection(ChannelSelectionBase):
    """Selection screen for channels or providers."""

    def __init__(self, session, providers=False):
        self.providers = providers
        ChannelSelectionBase.__init__(self, session)
        self.bouquet_mark_edit = OFF
        self["Title"] = self["title"] = StaticText(_("Channel Selection"))
        self.skinName = 'filtersServicesSelection'
        self.skin = getSkin(self.skinName)
        self["actions"] = ActionMap(
            ["OkCancelActions", "TvRadioActions"],
            {
                "cancel": self.close,
                "ok": self.channelSelected,
                "keyRadio": self.setModeRadio,
                "keyTV": self.setModeTv
            }
        )
        self.onLayoutFinish.append(self.setModeTv)

    def channelSelected(self):
        """Handle selection of a channel or provider."""
        ref = self.getCurrentSelection()
        if ref is None or not ref.valid():
            return
        if self.providers and (ref.flags & 7) == 7:
            if "provider" in ref.toString():
                menu = [(_("All services provider"), "providerlist")]

                def addAction(choice):
                    if choice is not None:
                        if choice[1] == "providerlist":
                            serviceHandler = eServiceCenter.getInstance()
                            servicelist = serviceHandler.list(ref)
                            if servicelist is not None:
                                providerlist = []
                                while True:
                                    service = servicelist.getNext()
                                    if not service.valid():
                                        break
                                    refstr = ":".join(service.toString().split(":")[:11])
                                    providerlist.append((refstr))
                                if providerlist:
                                    self.close(providerlist)
                                else:
                                    self.close(None)
                self.session.openWithCallback(addAction, ChoiceBox, title=_("Select action"), list=menu)
            else:
                self.enterPath(ref)
        elif (ref.flags & 7) == 7:
            self.enterPath(ref)
        elif 'provider' not in ref.toString() and not self.providers and not (ref.flags & (64 | 128)):
            if ref.valid():
                self.close(ref)

    def setModeTv(self):
        """Set selection mode to TV."""
        self.setTvMode()
        if self.providers:
            self.showProviders()
        else:
            self.showFavourites()

    def setModeRadio(self):
        """Set selection mode to Radio."""
        self.setRadioMode()
        if self.providers:
            self.showProviders()
        else:
            self.showFavourites()
