# -*- coding: utf-8 -*-
# e2skinpatcher.py
#
# SPDX-License-Identifier: GPL-2.0
#
# Wrapper for DreamOS that prevents a green-screen crash when skin.xml
# contains attributes not supported on the current image.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS (Dreambox 920), OpenATV, VTI, Open Source Enigma2
#
from __future__ import print_function

import skin


class AttributeParser(object):
    """
    Safe attribute parser that catches unknown skin attributes.
    Prevents green-screen crashes on DreamOS when skin.xml references
    attributes not implemented in the current firmware.
    """

    def __init__(self, guiObject, desktop, scale=((1, 1), (1, 1))):
        self.guiObject = guiObject
        self.desktop = desktop
        self.scaleTuple = scale

    def applyOne(self, attrib, value):
        """Apply a single skin attribute safely, logging any failure."""
        try:
            getattr(self, attrib)(value)
        except AttributeError:
            # Unknown attribute - log and ignore (do NOT crash)
            print("[Skin_Patcher] Attribute '%s' (with value '%s') in object of type '%s' is not implemented!" %
                  (attrib, value, self.guiObject.__class__.__name__))
        except skin.SkinError as err:
            print("[Skin_Patcher] SkinError: %s" % str(err))
        except Exception:
            print("[Skin_Patcher] Attribute '%s' with wrong (or unknown) value '%s' in object of type '%s'!" %
                  (attrib, value, self.guiObject.__class__.__name__))

    def font(self, value):
        """
        Apply a font attribute using the skin's own font (parseFont).
        NOTE: setFont is intentionally NOT called directly here.
        We use the skin's parseFont so the skin font is respected.
        This is required for compatibility with DreamOS, OpenATV, VTI, and Open Source images.
        """
        # Use skin.parseFont so the skin-defined font is used correctly.
        # This avoids the need for setFont and keeps compatibility across all images.
        self.guiObject.setFont(skin.parseFont(value, self.scaleTuple))


def _applySingleAttribute(fn):
    """
    Decorator / wrapper for skin.applySingleAttribute.
    Intercepts 'font' attribute calls and routes them through AttributeParser
    so they use the skin's own font system instead of a hardcoded font.
    All other attributes are handled by the original function.

    CONDITION: Only intercept 'font' attributes.
    Other attributes pass through unchanged to the original handler.
    """
    def _fn(*args):
        # args order: guiObject, desktop, attrib, value, scale
        guiObject, desktop, attrib, value, scale = args
        if attrib == 'font':
            # Route font handling through our safe parser (uses skin font)
            return AttributeParser(guiObject, desktop, scale).applyOne(attrib, value)
        else:
            # All other attributes use the original Enigma2 handler
            return fn(*args)
    return _fn


# Patch skin.applySingleAttribute if the current image supports it.
# Some older OpenATV / OpenPLi / VTI builds may not have this function.
try:
    skin.applySingleAttribute = _applySingleAttribute(skin.applySingleAttribute)
except AttributeError as err:
    # Non-fatal: older images without applySingleAttribute skip patching
    print('[Skin_Patcher] Note: skin.applySingleAttribute not available on this image: %s' % repr(err))
except Exception as err:
    print('[Skin_Patcher] Error patching skin.applySingleAttribute: %s' % repr(err))
