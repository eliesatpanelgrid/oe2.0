#!/usr/bin/python
# -*- coding: utf-8 -*-
# OfflineImport.py
#
# Offline / command-line EPG importer for testing and development.
# Runs EPGImport outside of Enigma2 (on a PC / Linux system with Twisted).
#
# Usage:
#   1. Rename existing EPGImport/__init__.py to x__init__.py
#      and rename offline__init__.py to __init__.py
#   2. From the PARENT directory of EPGImport, run:
#      python -m EPGImport.OfflineImport <source.xml> [source2.xml ...]
#      e.g.: python -m EPGImport.OfflineImport /etc/rytec.sources.xml
#   3. Reinstate the original __init__.py when finished.
#
# Note: On Python 3, this MUST be run as a module (python -m) because
# relative imports inside the package require a proper package context.
#
# Called modules: EPGImport, EPGConfig
#
# The code is completely modified and optimized by Dorik1972
# Further improved for Python 2/3 cross-compatibility
#
from __future__ import print_function

import sys
import time

from . import EPGConfig, EPGImport

# Override EPG output path for offline testing (writes to current directory)
EPGImport.HDD_EPG_DAT = "./epg.dat.new"


class FakeEnigma(object):
    """
    Fake Enigma2 EPGCache instance for testing outside a Dreambox.
    Provides the minimal interface EPGImport requires:
    - getInstance()  -> self
    - importEvents() (commented out - uncomment for verbose event logging)
    """

    def getInstance(self):
        """Return self to simulate the singleton pattern of eEPGCache."""
        return self

    # Uncomment for verbose event logging during offline testing:
    # def load(self):
    #     print("...load...")
    #
    # def importEvents(self, *args):
    #     print(args)


def importFrom(epgimport, sourceXml):
    """
    Import EPG data from *sourceXml* using *epgimport*.

    CONDITION: On Windows, twisted reactor cannot handle files directly,
    so a FakeReactor that drives doRead() in a loop is used instead.
    On Linux/macOS, the standard twisted reactor is used.
    """
    if sys.platform.startswith("win"):
        # CONDITION: Windows - patch reactor and disable threading
        import twisted.python.runtime
        twisted.python.runtime.platform.supportsThreads = lambda: False

        class FakeReactor(object):
            """
            Minimal reactor stub for Windows offline testing.
            Drives doRead() synchronously so reactor.run() works without
            platform-specific socket support.
            """

            def __init__(self):
                self.r = None

            def addReader(self, r):
                self.r = r

            def removeReader(self, r):
                if self.r is r:
                    self.r = None
                else:
                    raise Exception("removeReader: reader was never added")

            def run(self):
                """Drive the event loop synchronously until no reader is set."""
                while self.r is not None:
                    self.r.doRead()

            def stop(self):
                print("[OfflineImport] FakeReactor stopped")

        EPGImport.reactor = FakeReactor()

    # Enumerate all sources from the XML file (unfiltered)
    sources = [s for s in EPGConfig.enumSourcesFile(sourceXml, filter=None)]

    # Reverse so the first source is processed first (sources is treated as a stack)
    sources.reverse()

    epgimport.sources = sources
    epgimport.onDone = done

    # Begin import with a generous 5-day long description window
    epgimport.beginImport(longDescUntil=time.time() + (5 * 24 * 3600))

    # Run the (fake or real) reactor until done() calls reactor.stop()
    EPGImport.reactor.run()


def done(reboot=False, epgfile=None):
    """
    Callback invoked by EPGImport when all sources have been processed.
    Stops the reactor and reports the output file path.
    """
    EPGImport.reactor.stop()
    print("[OfflineImport] Done. EPG data written to: %s" % epgfile)
    # At this point epg.dat.new is ready.
    # Copy to another destination here if needed (e.g. FTP upload).


if __name__ == '__main__':
    if len(sys.argv) <= 1:
        print("Usage: %s source.xml [source2.xml ...]" % sys.argv[0])
        sys.exit(1)

    epgimport = EPGImport.EPGImport(FakeEnigma(), lambda x: True)

    for xml in sys.argv[1:]:
        importFrom(epgimport, xml)
