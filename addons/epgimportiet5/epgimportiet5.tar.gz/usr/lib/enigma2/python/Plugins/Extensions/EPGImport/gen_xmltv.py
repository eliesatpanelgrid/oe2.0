# -*- coding: utf-8 -*-
# gen_xmltv.py
#
# XMLTV parser factory for EPGImport.
# Creates XMLTVConverter instances and wraps the iterator with safe-yield logic.
#
# Compatible with Python 2.7, 3.12, 3.13, 3.14
# Works on: DreamOS (Dreambox 920), VU+ (OpenATV/VTI), OpenSource Enigma2, BlackHole
#
# The code modified by Lululla
# The code modified by iet5
#
from __future__ import print_function

import sys
import os

# Import xmltvconverter - try relative import first (package mode),
# fall back to absolute import (standalone / test mode).
try:
    from . import xmltvconverter
except ImportError as e:
    print("[gen_xmltv] Relative import failed: %s" % e)
    # Fallback for standalone execution outside the package (testing only)
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        if current_dir and current_dir not in sys.path:
            sys.path.insert(0, current_dir)
        import xmltvconverter
    except ImportError:
        print("[gen_xmltv] Failed to import xmltvconverter - XMLTV parsing unavailable")
        xmltvconverter = None

# XMLTV programme category -> Enigma2 event type mapping
# Used by XMLTVConverter.get_category() to set DVB content type nibbles
date_format = '%Y%m%d%H%M%S'
gen_categories = {
    "Action sports":                                              (0x40, 0),
    "Action":                                                     (0x10, 0),
    "Adult Movie/Drama":                                          (0x18, 0),
    "Adults only":                                                (0x18, 0),
    "Adventure/Western/War":                                      (0x12, 0),
    "Advertisement/Shopping":                                     (0xA6, 0),
    "Aerobics":                                                   (0xA4, 0),
    "Animated":                                                   (0x55, 0),
    "Archery":                                                    (0x46, 0),
    "Arts/Culture":                                               (0x70, 0),
    "Athletics":                                                  (0x46, 0),
    "Ballet":                                                     (0x66, 0),
    "Baseball":                                                   (0x45, 0),
    "Basketball":                                                 (0x45, 0),
    "Bicycle":                                                    (0x40, 0),
    "Billiards":                                                  (0x40, 0),
    "Black & White":                                              (0xB2, 0),
    "Boxing":                                                     (0x40, 0),
    "Broadcasting/Press":                                         (0x78, 0),
    "Cartoons/Puppets":                                           (0x55, 0),
    "Children's/Youth Programme":                                 (0x50, 0),
    "Comedy":                                                     (0x14, 0),
    "Comedy-drama":                                               (0x14, 0),
    "Cooking":                                                    (0xA5, 0),
    "Crime drama":                                                (0x10, 0),
    "Crime/Mystery":                                              (0x10, 85),
    "Detective/Thriller":                                         (0x11, 0),
    "Discussion/Interview/Debate":                                (0x24, 0),
    "Documentary":                                                (0x23, 0),
    "Drama":                                                      (0x10, 0),
    "Economics/Social Advisory":                                  (0x82, 0),
    "Education/Science/Factual":                                  (0x90, 0),
    "Educational":                                                (0x90, 0),
    "Entertainment Programme for 10 to 16":                       (0x53, 0),
    "Entertainment Programme for 6 to 14":                        (0x52, 0),
    "Equestrian":                                                 (0x4A, 0),
    "Experimental Film/Video":                                    (0x77, 0),
    "Fashion":                                                    (0x7B, 0),
    "Film":                                                       (0x10, 0),
    "Film/Cinema":                                                (0x76, 0),
    "Fine Arts":                                                  (0x72, 0),
    "Fitness & Health":                                           (0xA4, 0),
    "Folk/Traditional Music":                                     (0x63, 0),
    "Football/Soccer":                                            (0x43, 0),
    "Foreign Countries/Expeditions":                              (0x94, 0),
    "Further Education":                                          (0x96, 0),
    "Game Show/Quiz/Contest":                                     (0x31, 0),
    "Gardening":                                                  (0xA7, 0),
    "Handicraft":                                                 (0xA2, 0),
    "Hobbies":                                                    (0x30, 0),
    "Informational/Educational/School Programme":                 (0x54, 0),
    "Jazz":                                                       (0x64, 0),
    "Languages":                                                  (0x97, 0),
    "Leisure/Hobbies":                                            (0xA0, 0),
    "Literature":                                                 (0x75, 0),
    "Live Broadcast":                                             (0xB4, 0),
    "Magazine/Report/Documentary":                                (0x81, 0),
    "Martial Sports":                                             (0x4B, 0),
    "Medicine/Physiology/Psychology":                             (0x93, 0),
    "Motor Sport":                                                (0x47, 0),
    "Motoring":                                                   (0xA3, 0),
    "Movie/Drama":                                                (0x10, 0),
    "Music":                                                      (0x60, 0),
    "Music/Ballet/Dance":                                         (0x60, 0),
    "Musical/Opera":                                              (0x65, 0),
    "Nature/Animals/Environment":                                 (0x91, 0),
    "New Media":                                                  (0x79, 0),
    "News Magazine":                                              (0x22, 0),
    "News":                                                       (0x20, 0),
    "News/Current Affairs":                                       (0x20, 0),
    "News/Weather Report":                                        (0x21, 0),
    "Original Language":                                          (0xB1, 0),
    "Paid Programming":                                           (0x54, 0),
    "Performing Arts":                                            (0x71, 0),
    "Popular Culture/Traditional Arts":                           (0x74, 0),
    "Pre-school Children's Programme":                            (0x51, 0),
    "Reality":                                                    (0x34, 0),
    "Religion":                                                   (0x73, 0),
    "Religious":                                                  (0x73, 0),
    "Remarkable People":                                          (0x83, 0),
    "Rock/Pop":                                                   (0x61, 0),
    "Romance":                                                    (0x16, 0),
    "Science Fiction/Fantasy/Horror":                             (0x13, 0),
    "Science/Nature":                                             (0x90, 0),
    "Serious/Classical Music":                                    (0x62, 0),
    "Serious/Classical/Religious/Historical Movie/Drama":         (0x17, 0),
    "Show/Game Show":                                             (0x30, 0),
    "Soap":                                                       (0x15, 0),
    "Soap/Melodrama/Folkloric":                                   (0x15, 0),
    "Social/Political/Economics":                                 (0x80, 0),
    "Social/Spiritual Sciences":                                  (0x95, 0),
    "Special Event":                                              (0x41, 0),
    "Sport Magazine":                                             (0x42, 0),
    "Sports":                                                     (0x40, 0),
    "Standup":                                                    (0x14, 0),
    "Talk Show":                                                  (0x33, 0),
    "Talk":                                                       (0x33, 0),
    "Team Sports":                                                (0x45, 0),
    "Technology/Natural Sciences":                                (0x92, 0),
    "Tennis/Squash":                                              (0x44, 0),
    "Tourism/Travel":                                             (0xA1, 0),
    "Unknown":                                                    (0x00, 0),
    "Unpublished":                                                (0xB3, 0),
    "Variety Show":                                               (0x32, 0),
    "Water Sport":                                                (0x48, 0),
    "Weather":                                                    (0x21, 0),
    "Winter Sports":                                              (0x49, 0),
}


def fast_yield(generator):
    """
    Safe wrapper that filters None values from a generator.
    Prevents None items from reaching the EPG importer and causing crashes.
    """
    for item in generator:
        if item is not None:
            yield item


class gen_xmltv(object):
    """
    XMLTV parser class used by EPGImport.

    CONDITION: Works on all supported images:
    - DreamOS (Dreambox 920)
    - VU+ (FionaPlus / OpenATV / VTI)
    - OpenSource Enigma2
    - OpenATV (Python 3.12, 3.13, 3.14)
    - BlackHole
    """

    @classmethod
    def new(cls):
        """Create a new gen_xmltv instance (class factory method)."""
        return cls()

    @classmethod
    def iterator(cls, fd, channelsDict, offset=0):
        """
        Yield EPG event tuples from an XMLTV file.

        :param fd:           File-like object with XMLTV content.
        :param channelsDict: Dict mapping XMLTV channel IDs to service references.
        :param offset:       UTC offset in seconds to apply to all event times.

        Yields tuples: (services, event_data_tuple)
        Only yields events for channels present in channelsDict.

        CONDITION: Handles corrupted / truncated compressed files gracefully.
        """
        if xmltvconverter is None:
            print("[gen_xmltv] ERROR: xmltvconverter module not available - cannot parse XMLTV")
            return

        try:
            xmltv_parser = xmltvconverter.XMLTVConverter(channelsDict, gen_categories, date_format, offset)
            for r in fast_yield(xmltv_parser.enumFile(fd)):
                yield r

        except EOFError as e:
            # CONDITION: Compressed file truncated or corrupt (e.g. partial .gz/.xz download)
            print("[gen_xmltv] Compressed file error (file may be incomplete): %s" % e)
            # Return without yielding any more items - do NOT yield empty channel stubs
            # as those would cause importEvents to be called with empty data tuples.
            return

        except Exception as e:
            # General parse failure - log and stop iteration cleanly
            print("[gen_xmltv] Error in iterator: %s" % e)

        finally:
            # Ensure the source file is properly closed on all exit paths
            if hasattr(fd, 'close'):
                try:
                    fd.close()
                except Exception:
                    pass

    def __init__(self):
        """Initialize the XMLTV parser (no state needed)."""
        pass


# Module-level new() function for backward compatibility with older plugin code
def new():
    """Return a new gen_xmltv instance."""
    return gen_xmltv()


# For standalone testing / development verification
if __name__ == '__main__':
    print("[gen_xmltv] Module loaded successfully")
    parser = new()
    print("[gen_xmltv] Parser instance created: %s" % parser)
