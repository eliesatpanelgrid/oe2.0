# -*- coding: utf-8 -*-
import os
import json
import socket
import subprocess
import time
import glob
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, getDesktop

from . import _, __version__

# Constants
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
SOCKET_PATH = "/tmp/snake_ctrl.sock"
FRAME_PATH = "/tmp/snake_frame.json"
GRID_W = 30
GRID_H = 20
SVG_PATH = "/tmp/snake_scene.svg"

# Load skin based on resolution
try:
    from skin import loadSkin
    desk_w = getDesktop(0).size().width()
    if desk_w >= 2560:
        loadSkin(os.path.join(PLUGIN_DIR, "skin_2560.xml"))
    elif desk_w >= 1920:
        loadSkin(os.path.join(PLUGIN_DIR, "skin_1920.xml"))
    else:
        loadSkin(os.path.join(PLUGIN_DIR, "skin.xml"))
except Exception:
    pass


def generate_apple_icon_svg(filepath):
    svg = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">\n'
        '  <!-- Sfondo opaco -->\n'
        '  <rect width="40" height="40" fill="#000000" />\n'
        '  <!-- Mela -->\n'
        '  <circle cx="20" cy="24" r="14" fill="#e02020"/>\n'
        '  <circle cx="16" cy="20" r="4" fill="rgba(255,255,255,0.40)"/>\n'
        '  <path d="M20 10 Q25 4 30 8 Q25 12 20 10 Z" fill="#22aa22"/>\n'
        '  <line x1="20" y1="10" x2="20" y2="20" stroke="#5a3010" stroke-width="2" stroke-linecap="round"/>\n'
        '</svg>'
    )
    with open(filepath, 'w') as f:
        f.write(svg)


# Cache for background SVG
_bg_svg = None
_last_cell_size = None


def build_background_svg(cell_w, cell_h):
    """Build static background SVG (checkerboard)."""
    global _bg_svg, _last_cell_size
    if _bg_svg is not None and _last_cell_size == (cell_w, cell_h):
        return _bg_svg
    W = GRID_W * cell_w
    H = GRID_H * cell_h
    lines = ['<?xml version="1.0" encoding="UTF-8"?>']
    lines.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}">')
    for gy in range(GRID_H):
        for gx in range(GRID_W):
            color = "#303d53" if (gx + gy) % 2 == 0 else "#000000"
            x = gx * cell_w
            y = gy * cell_h
            lines.append(f'  <rect x="{x}" y="{y}" width="{cell_w}" height="{cell_h}" fill="{color}"/>')
    lines.append('</svg>')
    _bg_svg = '\n'.join(lines)
    _last_cell_size = (cell_w, cell_h)
    return _bg_svg


def render_frame_svg(cell_w, cell_h, frame):
    """Generate complete SVG for current frame (background + moving elements)."""
    snake = frame.get("snake") or []
    food = frame.get("food")
    snake_dir = tuple(frame.get("dir", [1, 0]))

    # Start with background
    svg = build_background_svg(cell_w, cell_h)
    # Insert before closing </svg>
    lines = svg.splitlines()
    lines = lines[:-1]  # remove last line (</svg>)

    pad = 2
    r_body = max(3, cell_w // 4)

    # Food (apple)
    if food:
        fx, fy = food[0], food[1]
        cx = fx * cell_w + cell_w / 2.0
        cy = fy * cell_h + cell_h / 2.0
        r = max(4.0, min(cell_w, cell_h) / 2.0 - pad - 1)
        lines.append(f'  <circle cx="{cx}" cy="{cy}" r="{r}" fill="#e02020"/>')
        lines.append(f'  <circle cx="{cx - r*0.28}" cy="{cy - r*0.28}" r="{r*0.30}" fill="rgba(255,255,255,0.40)"/>')
        if r > 5:
            lines.append(
                f'  <path d="M{cx} {cy - r} Q{cx + r*0.5} {cy - r*1.5} {cx + r} {cy - r*0.8} '
                f'Q{cx + r*0.5} {cy - r*0.4} {cx} {cy - r} Z" fill="#22aa22"/>'
            )
            lines.append(
                f'  <line x1="{cx}" y1="{cy - r}" x2="{cx}" y2="{cy - r*1.4}" '
                f'stroke="#5a3010" stroke-width="1.5" stroke-linecap="round"/>'
            )

    # Snake body
    for i, (sx, sy) in enumerate(snake):
        green = int(180 - float(i) / max(len(snake)-1, 1) * 80)
        color = f"#00{green:02x}00"
        lines.append(
            f'  <rect x="{sx * cell_w + pad}" y="{sy * cell_h + pad}" '
            f'width="{cell_w - pad*2}" height="{cell_h - pad*2}" '
            f'fill="{color}" rx="{r_body}"/>'
        )

    # Snake head
    if snake:
        hx, hy = snake[0]
        cx = hx * cell_w + cell_w / 2.0
        cy = hy * cell_h + cell_h / 2.0
        hw = cell_w / 2.0 - pad
        hh = cell_h / 2.0 - pad
        if snake_dir == (1, 0):
            rot = 0
        elif snake_dir == (-1, 0):
            rot = 180
        elif snake_dir == (0, 1):
            rot = 90
        else:
            rot = -90
        er = max(2.0, min(hw, hh) * 0.28)
        ey_off = hh * 0.42
        ex_off = hw * 0.35
        tx = hw + pad
        lines.append(f'  <g transform="translate({cx},{cy}) rotate({rot})">')
        lines.append(f'    <rect x="{-hw}" y="{-hh}" width="{hw*2}" height="{hh*2}" fill="#00dd00" rx="{r_body}"/>')
        lines.append(f'    <circle cx="{ex_off}" cy="{-ey_off}" r="{er*1.4}" fill="white"/>')
        lines.append(f'    <circle cx="{ex_off + er*0.4}" cy="{-ey_off}" r="{er*0.8}" fill="#111"/>')
        lines.append(f'    <circle cx="{ex_off}" cy="{ey_off}" r="{er*1.4}" fill="white"/>')
        lines.append(f'    <circle cx="{ex_off + er*0.4}" cy="{ey_off}" r="{er*0.8}" fill="#111"/>')
        lines.append(f'    <line x1="{tx}" y1="0" x2="{tx + er*2}" y2="0" stroke="#ff2244" stroke-width="1.5" stroke-linecap="round"/>')
        lines.append('  </g>')

    lines.append('</svg>')
    return '\n'.join(lines)


class SnakeScreen(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self._proc = None
        self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        self._cell_w = 20
        self._cell_h = 20
        self._last_frame = {}
        self._frame_mtime = None
        self._rendering = False
        self._last_svg_content = None

        self["bg"] = Pixmap()
        self["w_score"] = Label("")
        self["w_hi"] = Label("")
        self["w_status"] = Label("")
        self["apple_icon"] = Pixmap()
        self["apple_count"] = Label("0")

        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions"],
            {
                "left": lambda: self._send_cmd("LEFT"),
                "right": lambda: self._send_cmd("RIGHT"),
                "up": lambda: self._send_cmd("UP"),
                "down": lambda: self._send_cmd("DOWN"),
                "ok": lambda: self._send_cmd("OK"),
                "cancel": self._exit_game,
            }, -1
        )

        self._timer = eTimer()
        self._timer.callback.append(self._render_tick)
        self.onLayoutFinish.append(self._on_layout)
        self.onClose.append(self._cleanup)

    def _on_layout(self):
        # Disable LCD4linux if present
        try:
            import Plugins.Extensions.LCD4linux.plugin as L4L
            self._lcd_state = L4L.LCDon
            L4L.LCDon = False
        except Exception:
            self._lcd_state = None

        # Generate apple icon
        apple_path = "/tmp/snake_apple_icon.svg"
        generate_apple_icon_svg(apple_path)
        if self["apple_icon"].instance:
            self["apple_icon"].instance.setPixmap(LoadPixmap(apple_path))

        if not self["bg"].instance:
            return

        size = self["bg"].instance.size()
        self._cell_w = size.width() // GRID_W
        self._cell_h = size.height() // GRID_H

        # Start worker process
        try:
            self._proc = subprocess.Popen(
                ["python3", os.path.join(PLUGIN_DIR, "snake_worker.py"), str(self._cell_w), str(self._cell_h)],
                close_fds=True
            )
        except Exception as e:
            self["w_status"].setText(_("Error starting game engine: %s") % str(e))
            return

        self["w_status"].setText(_("Press OK to start"))
        self._timer.start(150, False)  # 100ms update interval

    def _cleanup(self):
        self._timer.stop()
        try:
            self._sock.close()
        except Exception:
            pass

        if self._proc is not None:
            try:
                self._proc.terminate()
                self._proc.wait(2)
            except Exception:
                try:
                    self._proc.kill()
                except Exception:
                    pass
            self._proc = None

        try:
            for f in glob.glob("/tmp/snake_*"):
                os.remove(f)
        except Exception:
            pass

        # Restore LCD4linux
        if hasattr(self, '_lcd_state') and self._lcd_state is not None:
            try:
                import Plugins.Extensions.LCD4linux.plugin as L4L
                L4L.LCDon = self._lcd_state
            except Exception:
                pass

    def _send_cmd(self, command):
        try:
            self._sock.sendto(command.encode("utf-8"), SOCKET_PATH)
        except Exception:
            pass

    def _exit_game(self):
        self._send_cmd("QUIT")
        self.close()

    def _render_tick(self):
        if self._rendering:
            return
        self._rendering = True

        try:
            # Read latest frame
            try:
                mtime = os.path.getmtime(FRAME_PATH)
                if mtime != self._frame_mtime:
                    with open(FRAME_PATH, "r", encoding="utf-8") as f:
                        self._last_frame = json.load(f)
                    self._frame_mtime = mtime
                else:
                    # No new frame, skip rendering
                    return
            except Exception:
                return

            frame = self._last_frame
            if not frame:
                return

            score = frame.get("score", 0)
            game_over = frame.get("game_over", False)
            started = frame.get("started", False)
            paused = frame.get("paused", False)

            self["w_score"].setText(_("Score: %d") % score)
            self["w_hi"].setText(_("Highscore: %d") % frame.get("hi", 0))
            self["apple_count"].setText(str(frame.get("apples", 0)))

            if game_over:
                self["w_status"].setText(_("Game Over! Score: %d - Press OK for restart") % score)
            elif paused:
                self["w_status"].setText(_("Pause - Press OK or direction to continue"))
            elif not started:
                self["w_status"].setText(_("Press OK to start"))
            else:
                self["w_status"].setText("")

            # Generate SVG only if something changed
            svg_content = render_frame_svg(self._cell_w, self._cell_h, frame)
            if svg_content != self._last_svg_content:
                # Write SVG to file
                with open(SVG_PATH, "w", encoding="utf-8") as f:
                    f.write(svg_content)
                self._last_svg_content = svg_content
                # Load pixmap (this may be heavy, but only when content changes)
                px = LoadPixmap(SVG_PATH)
                if px is not None and self["bg"].instance:
                    self["bg"].instance.setPixmap(px)

        except Exception:
            # Avoid spamming logs
            pass
        finally:
            self._rendering = False


def main(session, **kwargs):
    session.open(SnakeScreen)


def Plugins(**kwargs):
    from Plugins.Plugin import PluginDescriptor
    return PluginDescriptor(
        name=_("Snake"),
        description=_("Snake v.%s") % __version__,
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="snake.svg",
        fnc=main
    )
