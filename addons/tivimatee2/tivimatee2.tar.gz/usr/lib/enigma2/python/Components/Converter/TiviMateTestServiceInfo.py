# -*- coding: utf-8 -*-
"""Cross-image service information converter for TiviMateE2.

Uses Enigma2 service.info() first, then /proc/stb fallbacks used by images
such as Pure2 where some iServiceInformation values may be unavailable.
"""
from __future__ import absolute_import

import os

from Components.Converter.Converter import Converter
from Components.Element import cached
try:
    from Components.Converter.Poll import Poll
except Exception:
    class Poll(object):
        def __init__(self):
            self.poll_interval = 1000
            self.poll_enabled = False

try:
    from enigma import iServiceInformation
except Exception:
    iServiceInformation = object


class TiviMateTestServiceInfo(Poll, Converter):
    VIDEO_WIDTH = "VideoWidth"
    VIDEO_HEIGHT = "VideoHeight"
    VIDEO_RESOLUTION = "VideoResolution"
    FRAMERATE = "Framerate"
    IS_UHD = "IsUHD"
    IS_FHD = "IsFHD"
    IS_HD = "IsHD"
    IS_SD = "IsSD"
    IS_WIDESCREEN = "IsWidescreen"
    IS_MULTICHANNEL = "IsMultichannel"
    AUDIO_TRACKS = "AudioTracksAvailable"

    def __init__(self, arg):
        Poll.__init__(self)
        Converter.__init__(self, arg)
        self.type = str(arg or "")
        self.poll_interval = 1000
        self.poll_enabled = True

    def _service(self):
        try:
            return self.source.service
        except Exception:
            return None

    def _info(self):
        service = self._service()
        if service is None:
            return None
        try:
            return service.info()
        except Exception:
            return None

    @staticmethod
    def _read_proc(paths):
        for path in paths:
            try:
                if os.path.exists(path):
                    with open(path, "r") as handle:
                        value = handle.read().strip()
                    if value:
                        return value
            except Exception:
                pass
        return ""

    @staticmethod
    def _parse_number(value):
        if value is None:
            return 0
        try:
            if isinstance(value, int):
                return value if value > 0 else 0
        except Exception:
            pass
        text = str(value).strip().lower()
        if not text or text in ("n/a", "none", "-1"):
            return 0
        try:
            if text.startswith("0x"):
                return int(text, 16)
            # proc/stb xres/yres are often hex without 0x (e.g. 780 = 1920)
            if any(c in "abcdef" for c in text):
                return int(text, 16)
            number = int(float(text))
            # Width/height proc values commonly arrive as hex-only digits.
            if len(text) == 3 and number < 1000:
                try:
                    hex_number = int(text, 16)
                    if hex_number >= 480:
                        return hex_number
                except Exception:
                    pass
            return number if number > 0 else 0
        except Exception:
            return 0

    def _info_number(self, names):
        info = self._info()
        if info is None:
            return 0
        for name in names:
            key = getattr(iServiceInformation, name, None)
            if key is None:
                continue
            try:
                value = info.getInfo(key)
                value = self._parse_number(value)
                if value:
                    return value
            except Exception:
                pass
            try:
                value = info.getInfoString(key)
                value = self._parse_number(value)
                if value:
                    return value
            except Exception:
                pass
        return 0

    def _width(self):
        value = self._info_number(("sVideoWidth", "sVideoWidthString"))
        if value:
            return value
        return self._parse_number(self._read_proc((
            "/proc/stb/vmpeg/0/xres",
            "/proc/stb/vmpeg/0/width",
            "/proc/stb/video/videomode_50hz",
        )))

    def _height(self):
        value = self._info_number(("sVideoHeight", "sVideoHeightString"))
        if value:
            return value
        return self._parse_number(self._read_proc((
            "/proc/stb/vmpeg/0/yres",
            "/proc/stb/vmpeg/0/height",
        )))

    def _framerate(self):
        value = self._info_number(("sFrameRate", "sFrameRateString"))
        if not value:
            value = self._parse_number(self._read_proc((
                "/proc/stb/vmpeg/0/framerate",
                "/proc/stb/vmpeg/0/fps",
            )))
        # Enigma2 normally reports milli-fps (25000, 50000, 59940).
        if value >= 1000:
            fps = float(value) / 1000.0
        else:
            fps = float(value)
        if fps <= 0:
            return 0
        rounded = int(round(fps))
        return rounded

    def _aspect_wide(self):
        info = self._info()
        if info is not None:
            for name in ("sAspect", "sAspectRatio"):
                key = getattr(iServiceInformation, name, None)
                if key is None:
                    continue
                try:
                    aspect = info.getInfo(key)
                    if aspect in (1, 2, 3, 4, 5, 6):
                        return aspect in (2, 3, 4, 5, 6)
                except Exception:
                    pass
        aspect_text = self._read_proc((
            "/proc/stb/vmpeg/0/aspect",
            "/proc/stb/vmpeg/0/aspect_ratio",
        )).lower()
        if aspect_text:
            if "16" in aspect_text or "wide" in aspect_text:
                return True
            if "4:3" in aspect_text or aspect_text in ("0", "1"):
                return False
        width, height = self._width(), self._height()
        if width and height:
            return (float(width) / float(height)) >= 1.55
        return False

    def _audio_tracks(self):
        service = self._service()
        if service is None:
            return 0, ""
        try:
            tracks = service.audioTracks()
            count = tracks.getNumberOfTracks()
            current = tracks.getCurrentTrack()
            desc = ""
            if current >= 0:
                try:
                    desc = tracks.getTrackInfo(current).getDescription() or ""
                except Exception:
                    pass
            return count, desc
        except Exception:
            return 0, ""

    @cached
    def getText(self):
        width = self._width()
        height = self._height()
        if self.type == self.VIDEO_WIDTH:
            return str(width) if width else ""
        if self.type == self.VIDEO_HEIGHT:
            return str(height) if height else ""
        if self.type == self.VIDEO_RESOLUTION:
            if width and height:
                return "%dx%d" % (width, height)
            if height:
                return "%dp" % height
            return ""
        if self.type == self.FRAMERATE:
            fps = self._framerate()
            return str(fps) if fps else ""
        return ""

    text = property(getText)

    @cached
    def getBoolean(self):
        width, height = self._width(), self._height()
        if self.type == self.IS_UHD:
            return width >= 3000 or height >= 1600
        if self.type == self.IS_FHD:
            return (width >= 1900 or height >= 1000) and not (width >= 3000 or height >= 1600)
        if self.type == self.IS_HD:
            return (width >= 1200 or height >= 700) and not (width >= 1900 or height >= 1000)
        if self.type == self.IS_SD:
            return bool(width or height) and width < 1200 and height < 700
        if self.type == self.IS_WIDESCREEN:
            return self._aspect_wide()
        if self.type == self.IS_MULTICHANNEL:
            _count, desc = self._audio_tracks()
            desc = desc.lower()
            return any(token in desc for token in ("5.1", "7.1", "ac3", "e-ac3", "dolby", "dts"))
        if self.type == self.AUDIO_TRACKS:
            count, _desc = self._audio_tracks()
            return count > 1
        return False

    boolean = property(getBoolean)

    def changed(self, what):
        Converter.changed(self, what)
