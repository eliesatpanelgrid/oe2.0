class MediaScreen(Screen):
    POSTER_X = [70, 450, 830, 1210, 1590]


    def __init__(self, session, source, kind, initialCategoryId=None, initialCategoryName=None):
        if kind == "live":
            # Live has its own remembered server. Movies and TV Shows continue
            # using the Home/server-manager selection independently.
            # Keep the virtual beIN source selected instead of replacing it with
            # the persisted real provider.  The real provider is refreshed only
            # inside the private beIN wrapper so ChoiceBox selection/check state
            # remains active after opening the new MediaScreen.
            if isinstance(source, dict) and source.get("_virtual_bein"):
                base = _load_live_source(_bein_base_source(source))
                source = _make_bein_virtual_source(base)
            else:
                source = _load_live_source(source)
            # Home skins do not change Live: keep the stable, Picon-enabled list.
            # This layout intentionally has no visible EPG grid.
            self.skin = _live_skin_with_style(_load_channel_settings().get("live_theme", "turquoise"))
        else:
            self.posterViewStyle, _poster_spec = _vod_poster_style_spec(_load_home_appearance().get("poster_style", "original"))
            self.POSTER_X = list(_poster_spec["x"])
            self.posterY = int(_poster_spec["y"])
            self.skin = _vod_skin_with_poster_style(self.posterViewStyle)
        Screen.__init__(self, session)
        self._pageOpenBusy = False
        self.source = source
        self.kind = kind
        self.initialCategoryId = str(initialCategoryId or "")
        self.initialCategoryName = initialCategoryName or ""
        # Title logos are intentionally limited to the large pages opened from
        # Packages, so Home/other media flows remain untouched.
        self.packageTitleLogoEnabled = bool(kind in ("vod", "series") and self.initialCategoryId)
        self.activeCategoryName = self.initialCategoryName
        self.activePackageProvider = self._providerFromPackageName(self.initialCategoryName) if self.initialCategoryName else ""
        self.activeCategoryName = self.initialCategoryName
        self.mediaItems = []
        self.mediaItemsCurrent = []
        self.categories = []
        self.focus = "rail" if kind == "live" else "top"
        self.posterIndex = 0
        self.searchQuery = ""
        self.sortMode = "default"
        self.lastCategoryItems = []
        self.pageStart = 0
        self.downloads = []
        self.picloads = []
        # r264: always initialize poster request tracking before Recent Add/category rendering.
        self._poster_artwork_requests = {}
        self["brand"] = Label("tv")
        self["rail"] = MenuList([("▣  تلفاز", "live"), ("▤  أفلام", "vod"), ("▥  مسلسلات", "series")])
        self["title"] = Label("%s  •  %s" % (source.get("name", "IPTV"), {"live":tr("LIVE TV"), "vod":tr("MOVIES"), "series":tr("TV SHOWS")}.get(kind, kind)))
        self["category"] = LiveCategoryMenuList([]) if kind == "live" else MenuList([])
        if kind != "live":
            self.topNames = [nav_label("Search"), nav_label("Home"), nav_label("Live"), nav_label("Movies"), nav_label("TV Shows"), nav_label("Packages"), nav_label("Continue Watching"), nav_label("Settings")]
            self.topIndex = 3 if kind == "vod" else 4
            self.topX = [40, 225, 410, 595, 780, 965, 1150, 1510]
            self.topW = [175, 175, 175, 175, 175, 175, 350, 175]
            for _i, _name in enumerate(self.topNames):
                self["top%d" % _i] = Label(_name)
            self["topSelector"] = Pixmap()
            self["sectionTitle"] = Label(tr("MOVIE CATEGORIES") if kind == "vod" else tr("TV SHOW CATEGORIES"))
            self["searchIcon"] = Label("⌕")
            self["filterIcon"] = Label("☰")
            self["currentCategory"] = Label("")
            self["titleLogo"] = Pixmap()
            try:
                self["titleLogo"].hide()
            except Exception:
                pass
            self._titleLogoToken = ""
            self._titleLogoLoader = None
        self["channelTitle"] = Label(tr("Select a package") if kind == "live" else tr("Select a category"))
        self["nowLabel"] = Label(tr("CONTENT"))
        self["meta"] = Label("")
        self["desc"] = Label(tr("Loading packages...") if kind == "live" else tr("Loading categories..."))
        if kind == "live":
            self["epgNowTime"] = Label("")
            self["epgNowTitle"] = Label("")
            self["epgNextTime"] = Label("")
            self["epgNextTitle"] = Label("")
            self["epgProgressText"] = Label("")
            from Components.ProgressBar import ProgressBar
            self["liveProgress"] = ProgressBar()
            self["livePoster"] = Pixmap()
            self["list"] = MenuList([])
            self["channelPicon"] = Pixmap()
            self["pageInfo"] = Label("")
            self["styleHint"] = Label("YELLOW  SWITCH SERVER  •  %s" % ("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "SERVER")))
            
            # Small channel-row picons. They load only once per visible 15-row
            # page and use the existing direct_picon cache, so navigation stays fast.
            self.rowPiconLoaders = []
            self.rowPiconPaths = {}
            self.rowPiconPending = False
            self.rowPiconToken = 0
            self.rowPiconPage = -1
            self.rowPiconTimer = eTimer()
            self["clockTitle"] = Label("")
            self["categoryTitle"] = Label(tr("PACKAGES"))
            # Live browsing stays focused on channel lists, logos, and playback.
            self.channelSettings = _load_channel_settings()
            self.zapTimer = eTimer()
            _connect_timer(self.zapTimer, self._autoZapCurrent)
            self.livePiconLoader = ePicLoad()
            try: connect_picture_data(self.livePiconLoader, self._livePiconDecoded, self)
            except Exception: pass
            self.livePiconDownload = None
            self.livePiconToken = 0
            self.livePiconTimer = eTimer()
            _connect_timer(self.livePiconTimer, self._finishLivePicon)
            # TMDb Live poster is isolated from playback/EPG and starts only after a long idle.
            self.livePosterToken = 0
            self.livePosterResult = None
            self.livePosterTimer = eTimer()
            _connect_timer(self.livePosterTimer, self._startLivePosterLookup)
            self.livePosterPoll = eTimer()
            _connect_timer(self.livePosterPoll, self._finishLivePosterLookup)
            self.livePosterLoader = ePicLoad()
            try: connect_picture_data(self.livePosterLoader, self._livePosterDecoded, self)
            except Exception: pass
            self.livePosterPath = ""
            try: self["livePoster"].hide()
            except Exception: pass
            # Test30: provider-direct EPG fallback for every Xtream server.
            self.directEpgToken = 0
            self.directEpgResult = None
            self.directEpgTimer = eTimer()
            _connect_timer(self.directEpgTimer, self._finishDirectEpg)
            self.stalkerEpgDownloadedChannels = set()
            self.stalkerShortEpgResults = {}
            self.stalkerEpgPending = []
            self.stalkerEpgBatchRunning = False
            self.stalkerEpgGeneration = 0
            self.stalkerEpgClient = None
            self.stalkerEpgLock = threading.RLock()
            self.stalkerEpgApplyTimer = eTimer()
            _connect_timer(self.stalkerEpgApplyTimer, self._drainStalkerEpgUpdates)
            # Xtream uses the existing Live selection debounce timer for a
            # Stalker-style visible-page EPG prefetch. No additional timer or
            # selection hook is created. Cache only successful provider rows.
            self.xtreamShortEpgResults = {}
            self.xtreamEpgDownloadedChannels = set()
            self.xtreamEpgBatchRunning = False
            self.xtreamEpgLock = threading.RLock()
            # r446: Xtream EPG uses one provider client/cache path just like
            # Stalker (RAM -> persistent HDD cache -> provider API).
            self.xtreamEpgClient = None
            # r443: the highlighted Xtream channel has its own direct request
            # state.  The visible-page batch only warms the remaining rows.
            # Reuse directEpgTimer as the GUI poller; no extra timer/hook.
            self.xtreamEpgPendingDisplay = None
            self.xtreamDirectEpgInFlight = set()
            self.xtreamDirectEpgResults = {}
            self.xtreamDirectEpgSelected = ""
            self.xtreamDirectEpgFallback = ""
            # r461: Xtream Live renders channels in 15-row lazy batches.
            # The full category stays in RAM, but the MenuList only receives
            # the first 15 rows; another 15 are appended when navigation
            # reaches the end of the currently rendered batch.
            self.xtreamLiveBatchSize = 15
            self.xtreamLiveLoadedCount = 0

            # EStalker 1.45 Live compatibility state.
            self.stalkerLivePageSize = 14
            self.stalkerLiveAdultPageSize = 20
            self.stalkerLiveCategoryId = ""
            self.stalkerLiveTotal = 0
            self.stalkerLiveSlots = []
            self.stalkerLiveLoadedPages = set()
            self.stalkerLivePendingPages = set()
            self.stalkerLivePageResult = None
            self.stalkerLivePageGeneration = 0
            self.stalkerLiveCancelEvent = threading.Event()
            self.stalkerLivePageTimer = eTimer()
            _connect_timer(self.stalkerLivePageTimer, self._finishStalkerLivePage)
            self.onClose.append(self._cancelStalkerCatalogueRequests)
            self.stalkerSelectionEpgTimer = eTimer()
            _connect_timer(self.stalkerSelectionEpgTimer, self._runStalkerSelectionEpg)
            try: self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
            except Exception: self.oldService = None
            self.lastZappedLiveId = None
            self.keepCurrentLiveService = False
            self._playingLiveItem = None
            self._playingLiveUrl = ""
            self.stalkerWatchdogClient = None
            self.stalkerWatchdogPending = False
            self.stalkerWatchdogTimer = eTimer()
            _connect_timer(self.stalkerWatchdogTimer, self._runStalkerWatchdog)
            try:
                shared_id = str((self.source or {}).get("_tivimate_current_live_id") or "").strip()
                if shared_id:
                    self.lastZappedLiveId = shared_id
                    self.keepCurrentLiveService = True
                    _CURRENT_LIVE_CHANNEL["source"] = _source_identity(self.source)
                    _CURRENT_LIVE_CHANNEL["channel"] = shared_id
                elif _CURRENT_LIVE_CHANNEL.get("source") == _source_identity(self.source):
                    self.lastZappedLiveId = _CURRENT_LIVE_CHANNEL.get("channel") or None
                    self.keepCurrentLiveService = bool(self.lastZappedLiveId)
            except Exception:
                pass
            self.stalkerPinUnlockedUntil = 0
            self._pinPendingAction = None
            self._pinFailures = 0
            self._pinBlockedUntil = 0
        else:
            self["backdrop"] = Pixmap()
            self["contentProviderNetflix"] = Pixmap()
            self["contentProviderPrime"] = Pixmap()
            self["contentProviderDisney"] = Pixmap()
            self["contentProviderMax"] = Pixmap()
            self["contentProviderApple"] = Pixmap()
            self["contentProviderParamount"] = Pixmap()
            for i in range(5):
                self["poster%d" % i] = Pixmap()
                self["posterShell%d" % i] = Pixmap()
                try:
                    self["posterShell%d" % i].hide()
                except Exception:
                    pass
                if getattr(self, "posterViewStyle", "original") == "circle":
                    self["posterFocus%d" % i] = Pixmap()
                    try:
                        self["posterFocus%d" % i].hide()
                    except Exception:
                        pass
                self["posterLabel%d" % i] = Label("")
                self["posterRate%d" % i] = Label("")
            self["selector"] = Pixmap()
            self.backdropLoader = None
            self.backdropDownloader = None
            self.infoTimer = eTimer()
            _connect_timer(self.infoTimer, self.loadSelectedInfo)
            self.fullInfoCache = {}
            self.infoProcesses = {}
            self.pendingInfoId = ""
        self.categoryLoadToken = 0
        self.categoryLoadResult = None
        self.catchupPackageActive = False
        self.catchupPackageResult = None
        self.catchupPackageToken = 0
        self.catchupPackageTimer = eTimer()
        _connect_timer(self.catchupPackageTimer, self._finishCatchupPackageLoad)
        self.categoryLoadTimer = eTimer()
        _connect_timer(self.categoryLoadTimer, self._finishCategoryLoad)
        # Catalog requests are independent from category item requests.  This keeps
        # opening any table responsive even when a provider is slow or unavailable.
        self.catalogLoadToken = 0
        self.catalogLoadResult = None
        self.catalogLoadPolls = 0
        self.catalogFirstOpenRetry = 0
        self.catalogRetryTimer = eTimer()
        _connect_timer(self.catalogRetryTimer, self._retryCatalogFirstOpen)
        self.catalogLoadTimer = eTimer()
        _connect_timer(self.catalogLoadTimer, self._finishCatalogLoad)
        self["keys"] = Label(tr("LEFT/RIGHT Navigate    UP/DOWN Pages    OK Select    RED Previous Category    BLUE Next Category    MENU Favorite    GREEN Packages/Categories    YELLOW Sort    EXIT Back")) if kind != "live" else Label("")
        self["guideBar"] = Pixmap()
        if kind == "live": self._updateLiveKeys()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions", "InfoActions", "NumberActions", "ChannelSelectBaseActions", "InfobarChannelSelection"], {
            "ok": self.ok, "cancel": self.cancelAction, "up": self.up, "down": self.down,
            "left": self.left, "right": self.right,
            "red": self.toggleCurrentFavourite if kind == "live" else self.previousCategory,
            "blue": self.openLiveColorMenu if kind == "live" else self.nextCategory,
            "green": self.openLiveFilter if kind == "live" else self.openCategoryMenu,
            "yellow": self.openLiveServerMenu if kind == "live" else self.toggleSort,
            "yellowlong": self.addCurrentFavourite,
            "menu": self.openLiveTools if kind == "live" else self.openFavorites,
            "info": self.openLiveTools if kind == "live" else self.openFavorites,
            "pageUp": self.pageUp, "pageDown": self.pageDown,
            "channelUp": self.liveFastUp, "channelDown": self.liveFastDown,
            "nextBouquet": self.liveFastDown, "prevBouquet": self.liveFastUp,
            "0": self.restartCurrentLiveStream
        }, -1)
        self.onLayoutFinish.append(self._prepareScreen)
        if kind != "live":
            self.onLayoutFinish.append(self._updateServerPackageGridLogo)


    def noAction(self):
        return

    def openBeinSports(self):
        """Open the dedicated beIN SPORTS view from Live without changing servers."""
        if self.kind != "live":
            return
        try:
            self._loadBeinSports()
        except Exception as exc:
            try:
                self["desc"].setText("beIN SPORTS: %s" % exc)
            except Exception:
                pass

    def _liveServerStatusLabel(self, source):
        state = str((source or {}).get("_last_status") or "").strip().lower()
        if state == "busy":
            return u"🟡"
        if state == "online":
            return u"🟢"
        if state == "offline":
            return u"🔴"
        return u"⚪"

    def _compactLiveServerName(self, source):
        name = str((source or {}).get("name") or "").strip()
        url = str((source or {}).get("url") or (source or {}).get("portal") or "").strip()
        # Finder's old post-title names are noisy. Prefer provider host/IP for them.
        noisy = (
            not name or len(name) > 32 or
            "stalker portal mac" in name.lower() or
            "stbemu codes" in name.lower()
        )
        if noisy and url:
            try:
                parsed = urlparse(url if "://" in url else "http://" + url)
                host = parsed.hostname or ""
                port = parsed.port
                if host:
                    return ("%s:%d" % (host, port)) if port else host
            except Exception:
                pass
        return name or url or "SERVER"

    def _sameLiveServer(self, left, right):
        left = left or {}
        right = right or {}
        if str(left.get("type") or "").lower() != str(right.get("type") or "").lower():
            return False

        source_type = str(left.get("type") or "").lower()
        if source_type == "stalker":
            left_mac = str(left.get("mac") or "").strip().upper()
            right_mac = str(right.get("mac") or "").strip().upper()
            if left_mac and right_mac and left_mac != right_mac:
                return False

            def hostport(source):
                raw = str(source.get("url") or source.get("portal") or source.get("host") or "").strip()
                try:
                    parsed = urlparse(raw if "://" in raw else "http://" + raw)
                    host = (parsed.hostname or "").lower()
                    port = parsed.port
                    if not port:
                        port = 443 if parsed.scheme == "https" else 80
                    return host, int(port)
                except Exception:
                    return raw.rstrip("/").lower(), 0

            return hostport(left) == hostport(right) and bool(left_mac or right_mac)

        return _source_identity(left) == _source_identity(right)

    def openLiveServerMenu(self):
        if self.kind != "live":
            return
        sources = get_sources()
        if not sources:
            self.session.open(MessageBox, tr("No server selected • Press SETTINGS"), MessageBox.TYPE_INFO)
            return
        base_current = _bein_base_source(self.source)
        current_key = _source_identity(base_current)
        rows = []
        for candidate in sources:
            selected_here = (
                not self.source.get("_virtual_bein") and
                self._sameLiveServer(candidate, base_current)
            )
            rows.append((dict(candidate), selected_here))
        self.session.openWithCallback(
            self._liveServerSelected, LiveServerChoiceScreen, rows
        )

    def _liveServerSelected(self, selected=None):
        if not selected:
            return
        if isinstance(selected, tuple) and len(selected) == 2 and selected[0] in ("delete", "test"):
            action, source = selected
            if action == "delete":
                try:
                    sources = get_sources()
                    target = _source_identity(source)
                    kept = [item for item in sources if _source_identity(item) != target]
                    if len(kept) != len(sources):
                        set_sources(kept)
                        write_playlists(kept)
                except Exception:
                    pass
                return
            if action == "test":
                try:
                    source_type = source.get("type")
                    if source_type == "stalker":
                        details = StalkerClient(source).test()
                    elif source_type == "xtream":
                        details = XtreamClient(source).test()
                    else:
                        details = get_source_client(source).test()
                    msg = "ONLINE" if details else "Test completed"
                    self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=5)
                except Exception as exc:
                    self.session.open(MessageBox, "Test failed: %s" % exc, MessageBox.TYPE_ERROR, timeout=6)
                return
        if isinstance(selected, dict):
            source = selected
        else:
            try:
                source = selected[1]
            except Exception:
                return
        if not isinstance(source, dict):
            return
        # Persist only a real provider.  beIN SPORTS is a view over that provider.
        if source.get("_virtual_bein"):
            _save_live_source(_bein_base_source(source))
        else:
            _save_live_source(source)
        try:
            self.close()
            self._openPageOnce(MediaScreen, dict(source), "live")
        except Exception:
            pass

    def openLiveTools(self):
        if self.kind != "live":
            self.openFavorites(); return
        choices = [(tr("Favorites"), "favorites")]
        source_type = self.source.get("type")
        if source_type in ("stalker", "xtream"):
            pin_state = _load_stalker_pin(self.source) if source_type == "stalker" else _load_xtream_pin(self.source)
            if self.focus == "category":
                choices.append((tr("Hide this package"), "hide_category"))
                row = self["category"].getCurrent()
                cid = str(row[1] or "") if row else ""
                if cid and not cid.startswith("__"):
                    if cid in pin_state["categories"]:
                        choices.append((tr("Unlock this package"), "unlock_category"))
                    else:
                        choices.append((tr("Lock this package"), "lock_category"))
            elif self.current():
                choices.append((tr("Hide this channel"), "hide_channel"))
                channel_id = _live_item_id(self.current())
                if channel_id in pin_state["channels"]:
                    choices.append((tr("Unlock this channel"), "unlock_channel"))
                else:
                    choices.append((tr("Lock this channel"), "lock_channel"))
            choices.append((tr("Change parental PIN"), "change_pin"))
            choices.append(((tr("Stalker player engines") if source_type == "stalker" else tr("Xtream player engines")), "player_engines"))
            if source_type == "stalker":
                choices.append((tr("Recently watched"), "stalker_recent"))
            state = _load_stalker_hidden(self.source) if source_type == "stalker" else _load_xtream_hidden(self.source)
            if state["categories"]:
                choices.append((tr("Show hidden packages"), "show_hidden_packages"))
            if state["channels"]:
                choices.append((tr("Show hidden channels"), "show_hidden_channels"))
        self.session.openWithCallback(self._liveToolSelected, ChoiceBox, title=tr("Live options"), list=choices)

    def _liveToolSelected(self, selected=None):
        if not selected:
            return
        action = selected[1] if isinstance(selected, (tuple, list)) and len(selected) > 1 else selected
        source_type = self.source.get("type")
        prefix = "stalker" if source_type == "stalker" else "xtream"
        if action == "favorites": self.openFavorites(); return
        if action == "hide_category": self._hideCurrentLiveCategory(prefix); return
        if action == "hide_channel": self._hideCurrentLiveChannel(prefix); return
        if action == "show_hidden_packages": self._showHiddenLiveItems(prefix, "category"); return
        if action == "show_hidden_channels": self._showHiddenLiveItems(prefix, "channel"); return
        if action in ("lock_category", "lock_channel"):
            self._lockCurrentLiveItem(prefix, action == "lock_category"); return
        if action in ("unlock_category", "unlock_channel"):
            self._requestLivePin(prefix, ("unlock", action == "unlock_category")); return
        if action == "change_pin": self._requestLivePin(prefix, ("change_pin", None)); return
        if action == "player_engines":
            return self._openStalkerEngineSettings() if source_type == "stalker" else self._openXtreamEngineSettings()
        if action == "stalker_recent": self._openStalkerRecentlyWatched(); return

    def _liveStateFns(self, prefix):
        if prefix == "stalker":
            return _load_stalker_hidden, _save_stalker_hidden, _load_stalker_pin, _save_stalker_pin
        return _load_xtream_hidden, _save_xtream_hidden, _load_xtream_pin, _save_xtream_pin

    def _hideCurrentLiveCategory(self, prefix):
        row = self["category"].getCurrent()
        if not row: return
        name, cid = row[0], str(row[1] or "")
        if not cid or cid.startswith("__"):
            self.session.open(MessageBox, tr("This package cannot be hidden."), MessageBox.TYPE_INFO); return
        load_hidden, save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source); state["categories"].add(cid); state["category_names"][cid] = str(name or cid); save_hidden(self.source, state)
        rows = [x for x in list(self["category"].list or []) if str(x[1]) != cid]
        self["category"].setList(rows); self["list"].setList([]); self.focus = "category"
        self["desc"].setText(tr("Package hidden. Use MENU to restore it."))

    def _hideCurrentLiveChannel(self, prefix):
        item = self.current()
        if not item: return
        channel_id = _live_item_id(item)
        load_hidden, save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source); state["channels"].add(channel_id); state["channel_names"][channel_id] = str(item.get("name") or item.get("title") or channel_id); save_hidden(self.source, state)
        self.showItems([x for x in self.mediaItemsCurrent if _live_item_id(x) != channel_id])
        self["desc"].setText(tr("Channel hidden. Use MENU to restore it."))

    def _showHiddenLiveItems(self, prefix, kind):
        load_hidden, _save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source)
        choices = []
        if kind == "category":
            for cid in sorted(state["categories"]):
                choices.append((state["category_names"].get(cid, cid), (prefix, "category", cid)))
            title = tr("Show hidden packages")
            empty = tr("No hidden packages.")
        else:
            for chid in sorted(state["channels"]):
                choices.append((state["channel_names"].get(chid, chid), (prefix, "channel", chid)))
            title = tr("Show hidden channels")
            empty = tr("No hidden channels.")
        if not choices:
            self.session.open(MessageBox, empty, MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenLiveItem, ChoiceBox, title=title, list=choices)

    def _restoreHiddenLiveItem(self, selected=None):
        if not selected: return
        try:
            prefix, kind, item_id = selected[1]
        except Exception:
            return
        load_hidden, save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source)
        item_id = str(item_id)
        if kind == "category":
            state["categories"].discard(item_id)
            state["category_names"].pop(item_id, None)
            message = tr("Package restored.")
        else:
            state["channels"].discard(item_id)
            state["channel_names"].pop(item_id, None)
            message = tr("Channel restored.")
        save_hidden(self.source, state)
        try:
            if kind == "category" and hasattr(self, "loadCategories"):
                self.loadCategories()
            elif kind == "channel" and hasattr(self, "loadSelectedCategory"):
                self.loadSelectedCategory()
        except Exception:
            pass
        try: self["desc"].setText(message)
        except Exception: pass

    def _lockCurrentLiveItem(self, prefix, is_category=False):
        _lh,_sh,load_pin,save_pin=self._liveStateFns(prefix); state=load_pin(self.source)
        if is_category:
            row=self["category"].getCurrent(); item_id=str(row[1] or "") if row else ""
            if not item_id or item_id.startswith("__"): return
            state["categories"].add(item_id); state["category_names"][item_id]=str(row[0] or item_id)
        else:
            item=self.current(); item_id=_live_item_id(item) if item else ""
            if not item_id: return
            state["channels"].add(item_id); state["channel_names"][item_id]=str(item.get("name") or item.get("title") or item_id)
        save_pin(self.source,state); self["desc"].setText(tr("Content locked."))

    def _requestLivePin(self, prefix, action):
        self._pinSourcePrefix=prefix; self._pinPendingAction=action
        self.session.openWithCallback(self._livePinEntered, VirtualKeyBoard, title=tr("Enter parental PIN"), text="")

    def _livePinEntered(self, value=None):
        if value is None: return
        prefix=getattr(self,"_pinSourcePrefix","xtream"); _lh,_sh,load_pin,save_pin=self._liveStateFns(prefix); state=load_pin(self.source)
        if str(value).strip()!=str(state.get("pin") or "0000"): self.session.open(MessageBox,tr("Incorrect PIN"),MessageBox.TYPE_ERROR); return
        kind,payload=self._pinPendingAction
        if kind=="unlock":
            is_category=bool(payload)
            if is_category:
                row=self["category"].getCurrent(); item_id=str(row[1] or "") if row else ""; state["categories"].discard(item_id); state["category_names"].pop(item_id,None)
            else:
                item_id=_live_item_id(self.current()); state["channels"].discard(item_id); state["channel_names"].pop(item_id,None)
            save_pin(self.source,state); self["desc"].setText(tr("Lock removed."))
        elif kind=="change_pin":
            self.session.openWithCallback(lambda v,p=prefix:self._liveNewPinEntered(p,v),VirtualKeyBoard,title=tr("Enter new 4-digit PIN"),text="")

    def _liveNewPinEntered(self, prefix, value=None):
        value=str(value or "").strip()
        if not(len(value)==4 and value.isdigit()): self.session.open(MessageBox,tr("PIN must contain exactly 4 digits."),MessageBox.TYPE_ERROR); return
        _lh,_sh,load_pin,save_pin=self._liveStateFns(prefix); state=load_pin(self.source); state["pin"]=value; save_pin(self.source,state); self.session.open(MessageBox,tr("Parental PIN changed."),MessageBox.TYPE_INFO)

    def _openXtreamEngineSettings(self):
        self._xtreamEngineValues=_load_xtream_service_types(self.source); self._chooseXtreamEngine("live")

    def _chooseXtreamEngine(self, kind):
        labels={"live":tr("Xtream Live player"),"vod":tr("Xtream Movies player"),"series":tr("Xtream Series player")}; current=int(self._xtreamEngineValues.get(kind,4097)); choices=[((u"✓ " if v==current else u"")+str(v),v) for v in STALKER_SERVICE_TYPE_CHOICES]
        self.session.openWithCallback(lambda selected,k=kind:self._xtreamEngineSelected(k,selected),ChoiceBox,title=labels[kind],list=choices)

    def _xtreamEngineSelected(self, kind, selected=None):
        if not selected:return
        try:value=int(selected[1])
        except Exception:return
        self._xtreamEngineValues[kind]=value; order=("live","vod","series")
        try:next_kind=order[order.index(kind)+1]
        except Exception:next_kind=None
        if next_kind:return self._chooseXtreamEngine(next_kind)
        _save_xtream_service_types(self.source,self._xtreamEngineValues); self.channelSettings["service_type"]=self._xtreamEngineValues["live"]; _save_channel_settings(self.channelSettings); self.session.open(MessageBox,tr("Xtream player engines saved."),MessageBox.TYPE_INFO,timeout=3)

    def _openXtreamCatchup(self):
        item = self.current()
        if not item:
            return
        if not (item.get("tv_archive") or item.get("archive") or item.get("has_archive") or item.get("tv_archive_duration")):
            self.session.open(MessageBox, tr("This channel does not advertise catch-up support."), MessageBox.TYPE_INFO); return

        self._xtreamCatchupItem = dict(item)
        self._xtreamCatchupResult = None
        try:
            self["desc"].setText(tr("Loading catch-up programmes..."))
        except Exception:
            pass
        source = dict(self.source)
        stream_id = str(item.get("stream_id") or item.get("id") or "")
        epg_id = str(item.get("epg_channel_id") or item.get("epg_id") or "")

        def worker():
            rows, error = [], ""
            try:
                rows = XtreamClient(source).catchup_epg(stream_id, epg_channel_id=epg_id) or []
            except Exception as exc:
                error = str(exc)
            self._xtreamCatchupResult = (rows, error)

        t = threading.Thread(target=worker, name="TiviMateXtreamCatchup")
        t.daemon = True
        t.start()
        self._xtreamCatchupTimer = eTimer()
        _connect_timer(self._xtreamCatchupTimer, self._finishXtreamCatchupLoad)
        try:
            self._xtreamCatchupTimer.start(120, False)
        except Exception:
            pass

    def _parseXtreamCatchupDate(self, value):
        text = str(value or "").strip().replace("T", " ")
        if not text:
            return None
        # XStreamity parses the provider's raw EPG wall-clock value and uses
        # that same wall-clock for the timeshift URL. Do not convert through
        # receiver localtime/UTC here.
        for fmt in (
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H-%M-%S",
            "%Y-%m-%d-%H:%M:%S",
            "%Y-%m-%d %H:%M",
        ):
            try:
                return datetime.strptime(text[:19] if "%S" in fmt else text[:16], fmt)
            except Exception:
                pass
        return None

    def _finishXtreamCatchupLoad(self):
        result = getattr(self, "_xtreamCatchupResult", None)
        if result is None:
            try:
                self._xtreamCatchupTimer.start(120, False)
            except Exception:
                pass
            return
        try:
            self._xtreamCatchupTimer.stop()
        except Exception:
            pass

        self._xtreamCatchupResult = None
        rows, error = result
        now = int(time.time())
        item = getattr(self, "_xtreamCatchupItem", {}) or {}

        # Xtream tv_archive_duration is the provider's archive window in days.
        try:
            archive_days = int(float(str(item.get("tv_archive_duration") or "0")))
        except Exception:
            archive_days = 0
        if archive_days <= 0:
            self.session.open(
                MessageBox,
                tr("This channel has no provider catch-up window."),
                MessageBox.TYPE_INFO
            )
            return

        cutoff = now - (archive_days * 86400)
        choices = []

        for row in rows or []:
            if not isinstance(row, dict):
                continue

            title = self._decodeEpgText(
                row.get("title") or row.get("name") or row.get("programme")
            )
            if not title:
                continue

            begin = self._epgTimestamp(row, True)
            finish = self._epgTimestamp(row, False)

            # Catch-up = a completed historical programme only.
            # Never show current or future EPG rows.
            if not begin or not finish:
                continue
            if finish > now:
                continue
            if begin < cutoff:
                continue
            if finish <= begin:
                continue

            raw_start = row.get("start") or row.get("begin") or ""
            raw_end = row.get("end") or row.get("stop") or ""
            start_dt = self._parseXtreamCatchupDate(raw_start)
            end_dt = self._parseXtreamCatchupDate(raw_end)

            if start_dt:
                catchup_date = start_dt.strftime("%Y-%m-%d:%H-%M")
            else:
                catchup_date = time.strftime(
                    "%Y-%m-%d:%H-%M", time.localtime(begin)
                )

            if start_dt and end_dt and end_dt > start_dt:
                duration = max(
                    1, int((end_dt - start_dt).total_seconds() / 60.0)
                )
            else:
                duration = max(1, int((finish - begin + 59) / 60))

            payload = dict(row)
            payload["_begin"] = begin
            payload["_end"] = finish
            payload["_catchup_date"] = catchup_date
            payload["_catchup_duration"] = duration
            payload["_catchup_raw_start"] = str(raw_start or "")
            payload["_catchup_raw_end"] = str(raw_end or "")

            label = "%s  %s" % (
                time.strftime("%d/%m %H:%M", time.localtime(begin)),
                title
            )
            choices.append((label, payload))

        # Newest archived programme first.
        try:
            choices.sort(
                key=lambda x: int((x[1] or {}).get("_begin") or 0),
                reverse=True
            )
        except Exception:
            pass

        if not choices:
            message = tr("No archived programmes are available inside this channel's catch-up window.")
            if error:
                message += "\n" + error
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
            return

        self.session.openWithCallback(
            self._playXtreamCatchup,
            ChoiceBox,
            title=tr("Catch-up / Archive"),
            list=choices
        )


    def _playXtreamCatchup(self, selected=None):
        if not selected:
            return
        event = dict(selected[1] or {})
        item = getattr(self, "_xtreamCatchupItem", {}) or {}
        try:
            begin = int(event.get("_begin") or self._epgTimestamp(event, True) or 0)
            end = int(event.get("_end") or self._epgTimestamp(event, False) or 0)
            if not begin:
                raise RuntimeError(tr("Programme start time is missing"))
            if not end or end <= begin:
                end = begin + 3600

            # Match XStreamity: duration is minutes and catch-up playback uses
            # the VOD/Series player engine rather than the Live engine.
            duration = int(event.get("_catchup_duration") or 0)
            if duration <= 0:
                duration = max(1, int((end - begin + 59) / 60))
            source = self.source or {}
            base = str(source.get("url") or "").rstrip("/")
            user = str(source.get("username") or "")
            password = str(source.get("password") or "")
            sid = str(item.get("stream_id") or item.get("id") or "").strip()
            if not (base and user and password and sid):
                raise RuntimeError(tr("Xtream archive credentials are incomplete"))

            # XStreamity keeps the final stream component including its real
            # extension. Preserve .ts/.m3u8 from the provider instead of
            # hard-coding .ts.
            stream_name = ""
            for candidate in (
                item.get("url"), item.get("stream_url"), item.get("direct_source"),
                item.get("cmd")
            ):
                candidate = str(candidate or "").strip()
                if candidate and "/live/" in candidate:
                    stream_name = candidate.rsplit("/", 1)[-1].split("?", 1)[0]
                    if stream_name:
                        break

            if not stream_name:
                output = str(
                    source.get("output") or source.get("stream_format") or
                    source.get("format") or "ts"
                ).strip().lstrip(".")
                if not output:
                    output = "ts"
                stream_name = "%s.%s" % (sid, output)

            start_text = str(event.get("_catchup_date") or "").strip()
            if not start_text:
                start_text = time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin))

            # Build conservative fallbacks for provider timezone differences.
            # The first URL is unchanged. Alternatives are tried only if the
            # first one never actually starts playback.
            start_variants = []
            def add_start(value):
                value = str(value or "").strip()
                if value and value not in start_variants:
                    start_variants.append(value)

            add_start(start_text)
            add_start(time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin)))
            add_start(time.strftime("%Y-%m-%d:%H-%M", time.gmtime(begin)))
            try:
                base_dt = datetime.strptime(start_text, "%Y-%m-%d:%H-%M")
                add_start((base_dt - timedelta(hours=1)).strftime("%Y-%m-%d:%H-%M"))
                add_start((base_dt + timedelta(hours=1)).strftime("%Y-%m-%d:%H-%M"))
            except Exception:
                pass

            catchup_urls = []
            for candidate_start in start_variants:
                # Modern/common Xtream path form.
                candidate_url = "%s/timeshift/%s/%s/%d/%s/%s" % (
                    base, user, password, duration, candidate_start, stream_name
                )
                if candidate_url not in catchup_urls:
                    catchup_urls.append(candidate_url)

                # Older/classic Xtream endpoint used by a number of panels.
                # Keep stream as the numeric stream id, not filename.
                try:
                    query_url = (
                        "%s/streaming/timeshift.php?username=%s&password=%s"
                        "&stream=%s&start=%s&duration=%d"
                    ) % (
                        base, user, password, sid,
                        candidate_start.replace(":", "%3A"),
                        duration
                    )
                    if query_url not in catchup_urls:
                        catchup_urls.append(query_url)
                except Exception:
                    pass

            if not catchup_urls:
                raise RuntimeError(tr("Unable to build catch-up URL"))

            # Probe candidates before entering the player. Some providers publish
            # archive metadata but accept only one Xtream timeshift endpoint.
            def candidate_works(candidate):
                try:
                    req = Request(candidate)
                    try:
                        req.add_header("Range", "bytes=0-1023")
                    except Exception:
                        pass
                    response = urlopen(req, timeout=5)
                    try:
                        code = int(getattr(response, "getcode", lambda: 200)() or 200)
                    except Exception:
                        code = 200
                    try:
                        chunk = response.read(1024)
                    finally:
                        try:
                            response.close()
                        except Exception:
                            pass
                    return code in (200, 206) and bool(chunk)
                except Exception:
                    return False

            working_url = ""
            ordered_urls = []
            for candidate in catchup_urls:
                if candidate_works(candidate):
                    working_url = candidate
                    ordered_urls.append(candidate)
                    break

            if working_url:
                for candidate in catchup_urls:
                    if candidate != working_url:
                        ordered_urls.append(candidate)
                catchup_urls = ordered_urls
                url = working_url
            else:
                # Keep player retry as final fallback for unusual servers that
                # reject Range/probe requests but still play through Enigma2.
                url = catchup_urls[0]

            try:
                service_type = int(_load_xtream_service_types(self.source).get("vod", 4097))
            except Exception:
                service_type = 4097

            title = self._decodeEpgText(
                event.get("title") or event.get("name")
            ) or item.get("name") or "Catch-up"

            ref = eServiceReference(service_type, 0, url)
            ref.setName(title)

            play_item = dict(item)
            play_item["_source_type"] = "xtream"
            play_item["_source_key"] = _source_identity(self.source)
            play_item["_kind"] = "vod"
            play_item["_catchup"] = True
            play_item["_catchup_begin"] = begin
            play_item["_catchup_end"] = end
            play_item["_catchup_url"] = url
            play_item["_catchup_candidates"] = catchup_urls
            play_item["_catchup_service_type"] = service_type
            play_item["name"] = title

            self.session.openWithCallback(
                self.playerClosed, TiviMatePlayer, ref, play_item
            )
        except Exception as exc:
            self.session.open(
                MessageBox,
                "%s: %s" % (tr("Unable to play catch-up"), exc),
                MessageBox.TYPE_ERROR
            )


    def _openStalkerRecentlyWatched(self):
        if self.source.get("type") != "stalker":
            return
        rows = _load_stalker_recent(self.source, 30)
        choices = []
        for resume_key, row in rows:
            title = str(row.get("title") or tr("Untitled"))
            position = int(row.get("position", 0) or 0)
            length = int(row.get("length", 0) or 0)
            if length > 0:
                pct = max(0, min(99, int(position * 100 / length)))
                label = "%s  •  %d%%" % (title, pct)
            else:
                label = "%s  •  %02d:%02d" % (title, position // 60, position % 60)
            choices.append((label, (resume_key, row)))
        if not choices:
            self.session.open(MessageBox, tr("No recently watched Stalker items."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerRecentlyWatched, ChoiceBox, title=tr("Recently watched"), list=choices)

    def _playStalkerRecentlyWatched(self, selected=None):
        if not selected:
            return
        try:
            _resume_key_value, row = selected[1]
            item = dict(row.get("item") or {})
            kind = str(row.get("kind") or "vod")
            if kind not in ("vod", "series"):
                kind = "vod"
            item["_source_type"] = "stalker"
            item["_source_key"] = _source_identity(self.source)
            item["_kind"] = kind
            url = StalkerClient(dict(self.source)).stream_url(item, kind)
            if not url:
                raise RuntimeError(tr("Portal returned no playable URL"))
            ref = eServiceReference(_stalker_service_type(self.source, kind), 0, url)
            ref.setName(item.get("name") or item.get("title") or "IPTV")
            self.session.openWithCallback(self.playerClosed, TiviMatePlayer, ref, item)
        except Exception as exc:
            self.session.open(MessageBox, "%s\n%s" % (tr("Unable to play this item."), exc), MessageBox.TYPE_ERROR)

    def _openStalkerEngineSettings(self):
        if self.source.get("type") != "stalker":
            return
        self._stalkerEngineValues = _load_stalker_service_types(self.source)
        self._chooseStalkerEngine("live")

    def _chooseStalkerEngine(self, kind):
        labels = {"live": tr("Stalker Live player"), "vod": tr("Stalker Movies player"), "series": tr("Stalker Series player")}
        current = int(self._stalkerEngineValues.get(kind, 4097))
        choices = []
        for value in STALKER_SERVICE_TYPE_CHOICES:
            choices.append(((u"✓ " if value == current else u"") + str(value), value))
        self.session.openWithCallback(lambda selected, k=kind: self._stalkerEngineSelected(k, selected), ChoiceBox, title=labels.get(kind, kind), list=choices)

    def _stalkerEngineSelected(self, kind, selected=None):
        if not selected:
            return
        try:
            value = int(selected[1])
        except Exception:
            return
        if value not in STALKER_SERVICE_TYPE_CHOICES:
            return
        self._stalkerEngineValues[kind] = value
        order = ("live", "vod", "series")
        try:
            next_kind = order[order.index(kind) + 1]
        except Exception:
            next_kind = None
        if next_kind:
            return self._chooseStalkerEngine(next_kind)
        if _save_stalker_service_types(self.source, self._stalkerEngineValues):
            self.session.open(MessageBox, tr("Stalker player engines saved."), MessageBox.TYPE_INFO, timeout=3)
        else:
            self.session.open(MessageBox, tr("Unable to save Stalker player engines."), MessageBox.TYPE_ERROR)

    def _lockCurrentStalkerItem(self, is_category=False):
        if self.source.get("type") != "stalker":
            return
        state = _load_stalker_pin(self.source)
        if is_category:
            row = self["category"].getCurrent()
            if not row:
                return
            item_id = str(row[1] or "")
            if not item_id or item_id.startswith("__"):
                self.session.open(MessageBox, tr("This package cannot be locked."), MessageBox.TYPE_INFO); return
            state["categories"].add(item_id)
            state["category_names"][item_id] = str(row[0] or item_id)
            message = tr("Package locked.")
        else:
            item = self.current()
            if not item:
                return
            item_id = _live_item_id(item)
            if not item_id:
                return
            state["channels"].add(item_id)
            state["channel_names"][item_id] = str(item.get("name") or item.get("title") or item_id)
            message = tr("Channel locked.")
        _save_stalker_pin(self.source, state)
        try: self["desc"].setText(message)
        except Exception: pass

    def _requestStalkerPin(self, action):
        if time.time() < getattr(self, "_pinBlockedUntil", 0):
            wait = max(1, int(self._pinBlockedUntil - time.time()))
            self.session.open(MessageBox, "%s %s" % (tr("Try again in"), wait), MessageBox.TYPE_ERROR); return
        self._pinPendingAction = action
        self.session.openWithCallback(self._stalkerPinEntered, VirtualKeyBoard, title=tr("Enter parental PIN"), text="")

    def _stalkerPinEntered(self, value=None):
        if value is None:
            self._pinPendingAction = None
            return
        state = _load_stalker_pin(self.source)
        if str(value).strip() != str(state.get("pin") or "0000"):
            self._pinFailures = getattr(self, "_pinFailures", 0) + 1
            if self._pinFailures >= 3:
                self._pinBlockedUntil = time.time() + 30
                self._pinFailures = 0
            self._pinPendingAction = None
            self.session.open(MessageBox, tr("Incorrect PIN"), MessageBox.TYPE_ERROR); return
        self._pinFailures = 0
        action = self._pinPendingAction
        self._pinPendingAction = None
        if not action:
            return
        kind, payload = action
        if kind == "play":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLivePlayerNow()
        if kind == "category":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLockedCategoryNow()
        if kind == "unlock":
            is_category = bool(payload)
            state = _load_stalker_pin(self.source)
            if is_category:
                row = self["category"].getCurrent()
                item_id = str(row[1] or "") if row else ""
                state["categories"].discard(item_id)
                state["category_names"].pop(item_id, None)
            else:
                item_id = _live_item_id(self.current())
                state["channels"].discard(item_id)
                state["channel_names"].pop(item_id, None)
            _save_stalker_pin(self.source, state)
            try: self["desc"].setText(tr("Lock removed."))
            except Exception: pass
            return
        if kind == "change_pin":
            self.session.openWithCallback(self._stalkerNewPinEntered, VirtualKeyBoard, title=tr("Enter new 4-digit PIN"), text="")

    def _stalkerNewPinEntered(self, value=None):
        value = str(value or "").strip()
        if not (len(value) == 4 and value.isdigit()):
            self.session.open(MessageBox, tr("PIN must contain exactly 4 digits."), MessageBox.TYPE_ERROR); return
        state = _load_stalker_pin(self.source)
        state["pin"] = value
        _save_stalker_pin(self.source, state)
        self.stalkerPinUnlockedUntil = time.time() + 300
        self.session.open(MessageBox, tr("Parental PIN changed."), MessageBox.TYPE_INFO)

    def _isCurrentStalkerCategoryLocked(self):
        if self.source.get("type") != "stalker":
            return False
        row = self["category"].getCurrent()
        cid = str(row[1] or "") if row else ""
        return bool(cid and cid in _load_stalker_pin(self.source)["categories"])

    def _isCurrentStalkerChannelLocked(self):
        if self.source.get("type") != "stalker":
            return False
        return _live_item_id(self.current()) in _load_stalker_pin(self.source)["channels"]

    def _hideCurrentStalkerCategory(self):
        row = self["category"].getCurrent()
        if not row:
            return
        name, cid = row[0], str(row[1] or "")
        if not cid or cid.startswith("__"):
            self.session.open(MessageBox, tr("This package cannot be hidden."), MessageBox.TYPE_INFO); return
        state = _load_stalker_hidden(self.source)
        state["categories"].add(cid)
        state["category_names"][cid] = str(name or cid)
        _save_stalker_hidden(self.source, state)
        try:
            rows = [x for x in list(self["category"].list or []) if str(x[1]) != cid]
            self["category"].setList(rows)
            self["list"].setList([])
            self.focus = "category"
            self["desc"].setText(tr("Package hidden. Use MENU to restore it."))
        except Exception:
            pass

    def _hideCurrentStalkerChannel(self):
        item = self.current()
        if not item:
            return
        channel_id = _live_item_id(item)
        if not channel_id:
            return
        state = _load_stalker_hidden(self.source)
        state["channels"].add(channel_id)
        state["channel_names"][channel_id] = str(item.get("name") or item.get("title") or channel_id)
        _save_stalker_hidden(self.source, state)
        self.showItems([x for x in self.mediaItemsCurrent if _live_item_id(x) != channel_id])
        try: self["desc"].setText(tr("Channel hidden. Use MENU to restore it."))
        except Exception: pass

    def _showHiddenStalkerPackages(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["category_names"].get(cid, cid), ("category", cid)) for cid in sorted(state["categories"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden packages."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden packages"), list=choices)

    def _showHiddenStalkerChannels(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["channel_names"].get(chid, chid), ("channel", chid)) for chid in sorted(state["channels"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden channels."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden channels"), list=choices)

    def _restoreHiddenStalkerItem(self, selected=None):
        if not selected:
            return
        try:
            kind, item_id = selected[1]
        except Exception:
            return
        state = _load_stalker_hidden(self.source)
        item_id = str(item_id)
        if kind == "category":
            state["categories"].discard(item_id)
            state["category_names"].pop(item_id, None)
            message = tr("Package restored.")
        else:
            state["channels"].discard(item_id)
            state["channel_names"].pop(item_id, None)
            message = tr("Channel restored.")
        _save_stalker_hidden(self.source, state)
        try:
            if kind == "category" and hasattr(self, "loadCategories"):
                self.loadCategories()
            elif kind == "channel" and hasattr(self, "loadSelectedCategory"):
                self.loadSelectedCategory()
        except Exception:
            pass
        try: self["desc"].setText(message)
        except Exception: pass

    def _openStalkerCatchup(self):
        item = self.current()
        if not item or self.source.get("type") != "stalker":
            return
        self._catchupItem = dict(item)
        self._catchupResult = None
        try: self["desc"].setText(tr("Loading catch-up programmes..."))
        except Exception: pass
        source = dict(self.source)
        channel_id = _live_item_id(item)
        def worker():
            rows, error = [], ""
            try:
                rows = StalkerClient(source).short_epg(channel_id, limit=20, force=True) or []
            except Exception as exc:
                error = str(exc)
            self._catchupResult = (rows, error)
        threading.Thread(target=worker, name="TiviMateStalkerCatchup", daemon=True).start()
        self._catchupTimer = eTimer()
        _connect_timer(self._catchupTimer, self._finishStalkerCatchupLoad)
        try: self._catchupTimer.start(150, False)
        except Exception: pass

    def _finishStalkerCatchupLoad(self):
        result = getattr(self, "_catchupResult", None)
        if result is None:
            try: self._catchupTimer.start(150, False)
            except Exception: pass
            return
        try: self._catchupTimer.stop()
        except Exception: pass
        self._catchupResult = None
        rows, error = result
        now = int(time.time())
        choices = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._epgTimestamp(row, True)
            end = self._epgTimestamp(row, False)
            title = self._decodeEpgText(row.get("title") or row.get("name") or row.get("programme"))
            archive = row.get("has_archive") or row.get("archive") or row.get("allow_archive") or row.get("tv_archive")
            if begin and begin < now and title and (archive not in (0, "0", False) or end <= now):
                label = "%s  %s" % (time.strftime("%d/%m %H:%M", time.localtime(begin)), title)
                choices.append((label, dict(row)))
        if not choices:
            message = tr("No catch-up programmes are available for this channel.")
            if error:
                message += "\n" + error
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerCatchup, ChoiceBox, title=tr("Catch-up / Archive"), list=choices)

    def _playStalkerCatchup(self, selected=None):
        if not selected:
            return
        event = selected[1]
        item = getattr(self, "_catchupItem", {}) or {}
        try:
            client = StalkerClient(dict(self.source))
            url = client.create_catchup_link(item, event)
            if not url:
                raise RuntimeError(tr("Portal returned no archive link"))
            service_type = _stalker_service_type(self.source, "live")
            ref = eServiceReference(service_type, 0, url)
            ref.setName(self._decodeEpgText(event.get("title") or event.get("name")) or item.get("name") or "Catch-up")
            self.session.nav.playService(ref)
            self["meta"].setText(tr("Playing catch-up"))
        except Exception as exc:
            self.session.open(MessageBox, "%s: %s" % (tr("Unable to play catch-up"), exc), MessageBox.TYPE_ERROR)

    def openLiveColorMenu(self):
        if self.kind != "live":
            return
        current = self.channelSettings.get("live_theme", "turquoise")
        choices = []
        for name, value in LIVE_STYLE_CHOICES:
            label = ("✓ " if value == current else "") + name
            choices.append((label, value))
        self.session.openWithCallback(self._liveStyleSelected, ChoiceBox, title="Choose Live style", list=choices)

    def _liveStyleSelected(self, selected=None):
        if not selected:
            return
        try:
            theme = selected[1]
        except Exception:
            return
        if theme not in LIVE_STYLE_PALETTES:
            return
        self.channelSettings["live_theme"] = theme
        self.channelSettings["live_color"] = LIVE_STYLE_PALETTES[theme]["accent"]
        _save_channel_settings(self.channelSettings)
        source = dict(self.source)
        try:
            self.close()
            self._openPageOnce(MediaScreen, source, "live")
        except Exception:
            pass

    def openFavorites(self):
        self.session.open(FavoritesScreen)

    def _moveCategory(self, direction):
        """Move through VOD/series categories without reopening or redesigning the screen."""
        if self.kind == "live":
            return
        try:
            rows = list(self["category"].list or [])
        except Exception:
            rows = []
        if not rows:
            try:
                self["meta"].setText(tr("Loading packages/categories..."))
            except Exception:
                pass
            return
        try:
            current = int(self["category"].getSelectedIndex())
        except Exception:
            current = 0
        target = (current + int(direction)) % len(rows)
        try:
            self["category"].moveToIndex(target)
        except Exception:
            return
        try:
            selected = rows[target]
            self.initialCategoryName = selected[0] or ""
            self.initialCategoryId = str(selected[1] or "")
        except Exception:
            pass
        self.focus = "items"
        self.loadSelectedCategory()

    def previousCategory(self):
        self._moveCategory(-1)

    def nextCategory(self):
        self._moveCategory(1)

    def toggleCurrentFavourite(self):
        # Red toggles the highlighted Live channel: add when absent, remove when saved.
        item = None
        try:
            current_row = self["list"].getCurrent()
            item = current_row[1] if current_row else None
        except Exception:
            item = self.current()
        if not isinstance(item, dict):
            try:
                self["meta"].setText(tr("Open a package, select a channel, then press RED"))
            except Exception:
                pass
            return
        title = item.get("name") or item.get("title") or "Channel"
        try:
            added, saved = toggle_favourite(self.source, "live", item)
            if not saved:
                message = "Unable to update favorites"
            elif added:
                message = "★ Added %s to FAVORITES" % title
            else:
                message = "☆ Removed %s from FAVORITES" % title
                # When the user removes a row while viewing FAVORITES, refresh the
                # local list immediately. The provider package remains untouched.
                try:
                    if self.selectedCategory() == "__favorites__":
                        self.loadSelectedCategory()
                except Exception:
                    pass
            self["meta"].setText(message)
        except Exception as exc:
            try:
                self["meta"].setText("Favorites error: %s" % exc)
            except Exception:
                pass

    def addCurrentFavourite(self):
        # Long yellow is add-only for Movies and TV Shows.  The normal yellow key
        # remains sorting, and the Live action map deliberately stays untouched.
        if self.kind not in ("vod", "series"):
            return
        item = self.current()
        if not item:
            try:
                self["meta"].setText(tr("Select a movie or TV show first"))
            except Exception:
                pass
            return
        if is_favourite(self.source, self.kind, item):
            message = "Item is already in favorites"
        elif add_favourite(self.source, self.kind, item):
            message = "Added to favorites"
        else:
            message = "Unable to save favorite"
        try:
            self["meta"].setText(message)
        except Exception:
            pass


    def _updateTopFocus(self):
        if self.kind == "live":
            return
        try:
            index = max(0, min(self.topIndex, len(self.topX) - 1))
            cell_w = self.topW[index]
            x = self.topX[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(75)))
            self["topSelector"].setVisible(self.focus == "top")
        except Exception:
            pass


    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def _openTopItem(self):
        if self.kind == "live":
            return
        if self.topIndex == 0:
            self._openPageOnce(TiviMateE2Search, self.source); return
        if self.topIndex == 1:
            self._openPageOnce(TiviMateE2Home); return
        if self.topIndex == 2:
            self._openPageOnce(MediaScreen, self.source, "live"); return
        if self.topIndex == 3:
            self._openPageOnce(ContentHomeScreen, self.source, "vod"); return
        if self.topIndex == 4:
            self._openPageOnce(ContentHomeScreen, self.source, "series"); return
        if self.topIndex == 5:
            self._openPageOnce(ContentPackagesScreen, self.source); return
        if self.topIndex == 6:
            self._openPageOnce(ContinueWatchingScreen, self.source); return
        if self.topIndex == 7:
            self._openPageOnce(SettingsDashboard); return

    def openCategoryMenu(self):
        if self.kind == "live":
            return
        try:
            self.session.openWithCallback(
                self._categoryMenuSelected, HomePackageBrowserScreen,
                self.source, self.kind
            )
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open packages:\n%s" % exc, MessageBox.TYPE_ERROR)






    def _categoryMenuSelected(self, selected=None):
        if not selected:
            return
        cid = str(selected.get("id") or "")
        name = selected.get("name") or ""
        self.initialCategoryId = cid
        self.initialCategoryName = name
        self.activeCategoryName = name
        self.activePackageProvider = self._providerFromPackageName(name)
        self._updateServerPackageGridLogo()
        try:
            for pos, row in enumerate(self["category"].list):
                if str(row[1]) == cid:
                    self["category"].moveToIndex(pos)
                    break
        except Exception:
            pass
        self.focus = "items"
        self.loadSelectedCategory()

    def _prepareScreen(self):
        try:
            idx = {"live": 0, "vod": 1, "series": 2}.get(self.kind, 0)
            self["rail"].moveToIndex(idx)
        except Exception:
            pass
        self.updateSectionLabels()
        if self.kind != "live":
            self._updateTopFocus()
        if self.kind in ("vod","series") and self.initialCategoryId in ("__server_netflix__","__server_prime__"):
            provider="netflix" if self.initialCategoryId=="__server_netflix__" else "prime"
            self.activeCategoryName="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
            self.initialCategoryName=self.activeCategoryName
            self.activePackageProvider=provider
            self._updateServerPackageGridLogo()
            self._loadMergedServerProvider(provider)
            return
        if self.kind == "live":
            self._updateLiveClock()
            try: self["styleHint"].setText("YELLOW  SWITCH SERVER  •  %s" % ("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "SERVER")))
            except Exception: pass
            self._startStalkerWatchdog()
        self.loadCategories()

    def currentRailSection(self):
        current = self["rail"].getCurrent()
        return current[1] if current else self.kind

    def updateSectionLabels(self):
        label = {"live": "LIVE TV", "vod": "MOVIES", "series": "TV SHOWS"}.get(self.kind, self.kind)
        self["title"].setText("%s  •  %s" % (("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "IPTV")), label))
        if self.kind != "live":
            self["sectionTitle"].setText(tr("MOVIE CATEGORIES") if self.kind == "vod" else tr("TV SHOW CATEGORIES"))
            self["searchIcon"].setText(tr(""))

    def switchSection(self, section):
        if section == self.kind:
            self.focus = "category"
            return
        if section == "live":
            self._openPageOnce(MediaScreen, self.source, "live")
            return
        # LIVE and VOD/Series use different widget sets/skins.  Do not mutate
        # a LIVE screen into a VOD/Series screen in-place: widgets such as
        # currentCategory/sectionTitle do not exist on the LIVE skin and
        # DreamOS raises KeyError when navigation tries to access them.
        if self.kind == "live":
            # Live has an independent remembered provider.  When leaving Live for
            # Movies/TV Shows, always restore the Home/VOD provider instead of
            # carrying the currently selected Live server into every section.
            fallback = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
            target_source = _load_main_source(fallback)
            self._openPageOnce(MediaScreen, target_source, section)
            return
        self.kind = section
        self.focus = "category"
        self.searchQuery = ""
        self.sortMode = "default"
        self.mediaItems = []
        self.mediaItemsCurrent = []
        self.lastCategoryItems = []
        self.categories = []
        self.pageStart = 0
        self.posterIndex = 0
        try:
            self.infoTimer.stop()
        except Exception:
            pass
        self["category"].setList([])
        self["channelTitle"].setText(tr("Select a category"))
        self["meta"].setText(tr(""))
        self["desc"].setText(tr("Loading categories..."))
        try:
            self["currentCategory"].setText(tr(""))
        except Exception:
            pass
        self.updateSectionLabels()
        self.loadCategories()

    def loadCategories(self):
        """Load provider catalog data outside Enigma2's UI thread.

        Category lists are shared by LIVE, VOD, and Series.  The former direct
        provider calls could block every table while DNS/HTTP/M3U parsing ran.
        r87 shows a lightweight loading message and applies the ready result from
        a timer callback only after the worker has completed.
        """
        # Optional Netflix / Prime packages are true TMDb provider catalogs.
        # They intentionally bypass IPTV-server categories.
        _special_id=str(getattr(self,"initialCategoryId","") or "")
        if _special_id in ("__tmdb_netflix__", "__tmdb_prime__") and self.kind in ("vod","series"):
            self.catalogLoadToken += 1
            token=self.catalogLoadToken
            provider="netflix" if _special_id=="__tmdb_netflix__" else "prime"
            self.activeCategoryName="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
            self.initialCategoryName=self.activeCategoryName
            self.activePackageProvider=provider
            self.catalogLoadResult=None
            try:
                self["desc"].setText("Loading %s from TMDb..." % self.activeCategoryName)
                self["currentCategory"].setText(self.activeCategoryName)
            except Exception:
                pass
            self._updateServerPackageGridLogo()
            def _tmdb_provider_worker():
                try:
                    client=TMDbClient()
                    if not client.configured():
                        result=(token,"tmdb_provider",[],[],"TMDb is not configured",provider)
                    else:
                        items=client.provider_catalog(self.kind,provider,limit=50) or []
                        for _item in items:
                            if isinstance(_item,dict):
                                _item["_tmdb_provider"]=provider
                                _item["_server_package_provider"]=provider
                                _item["_server_package_name"]=self.activeCategoryName
                        result=(token,"tmdb_provider",[],items,"",provider)
                except Exception as exc:
                    result=(token,"tmdb_provider",[],[],str(exc),provider)
                self.catalogLoadResult=result
            threading.Thread(target=_tmdb_provider_worker,name="TiviMateTMDbProvider",daemon=True).start()
            try:self.catalogLoadTimer.start(120,True)
            except Exception:pass
            return

        self.catalogLoadToken += 1
        token = self.catalogLoadToken
        self.catalogLoadPolls = 0
        source = dict(self.source)
        kind = self.kind
        self.catalogLoadResult = None
        try:
            self["category"].setList([])
            self["list"].setList([])
        except Exception:
            pass
        try:
            self["desc"].setText("Loading catalog in background..." if kind == "live" else "Preparing the list in background...")
        except Exception:
            pass

        def worker():
            try:
                source_type = source.get("type")
                if kind == "live" and source.get("_virtual_bein"):
                    cached, fresh, stamp = _load_bein_cache(source)
                    if cached:
                        result = (token, "bein_virtual", [], cached, "", "cache")
                    else:
                        base = _bein_base_source(source)
                        client = get_source_client(base)
                        all_items = client.streams("live", "") or []
                        bein_items = [item for item in all_items if _is_bein_sports_channel(item)]
                        _save_bein_cache(base, bein_items)
                        result = (token, "bein_virtual", [], bein_items, "", "server")
                elif source_type in ("xtream", "stalker"):
                    if kind == "live":
                        # Stalker fast-open: RAM/disk immediately; on a cold cache,
                        # refresh the portal in the background instead of holding the page.
                        # Xtream keeps its existing cold-read behaviour.
                        _wait_live = False if source_type == "stalker" else True
                        categories, origin = get_cached_categories(
                            source, "live", client=None, wait_for_server=_wait_live
                        )
                        result = (token, source_type, categories or [], [], "", origin)
                    else:
                        categories, origin = get_cached_categories(
                            source, kind, get_source_client(source), wait_for_server=True
                        )
                        result = (token, source_type, categories or [], [], "", origin)
                elif source_type == "m3u":
                    entries, origin = get_cached_catalog(source, "live", lambda: M3UClient(source).entries(), wait_for_server=True)
                    result = (token, "m3u", [], entries or [], "", origin)
                elif source_type == "fg":
                    result = (token, "error", [], [], "FG Code test support was removed. Use Xtream, Stalker, or M3U.", "")
                else:
                    entries, origin = get_cached_catalog(source, "live", lambda: StalkerClient(source).channels(), wait_for_server=True)
                    result = (token, "stalker", [], entries or [], "", origin)
            except Exception as exc:
                result = (token, "error", [], [], str(exc), "")
            self.catalogLoadResult = result

        threading.Thread(target=worker, name="TiviMateE2Catalog", daemon=True).start()
        try:
            self.catalogLoadTimer.start(120, True)
        except Exception:
            pass

    def _retryCatalogFirstOpen(self):
        # Xtream/Stalker can be cold on the very first request after plugin start.
        # Retry once inside the same screen instead of forcing the user to Exit and re-enter.
        try:
            self.loadCategories()
        except Exception:
            pass

    def _finishCatalogLoad(self):
        result = self.catalogLoadResult
        if not result:
            try:
                self.catalogLoadTimer.start(120, True)
            except Exception:
                pass
            return
        self.catalogLoadResult = None
        token, mode, categories, items, error, origin = result
        if token != self.catalogLoadToken:
            return
        if mode == "tmdb_provider":
            provider=str(origin or "").strip().lower()
            self.activePackageProvider=provider
            self.activeCategoryName="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
            self.initialCategoryName=self.activeCategoryName
            self._updateServerPackageGridLogo()
            if error:
                try:
                    self["desc"].setText("TMDb error:\n%s" % error)
                    self["currentCategory"].setText(self.activeCategoryName)
                except Exception:
                    pass
                self.mediaItems=[]
                self.mediaItemsCurrent=[]
                return
            self.categories=[]
            self.lastCategoryItems=list(items or [])
            self.mediaItems=list(items or [])
            try:self["currentCategory"].setText(self.activeCategoryName)
            except Exception:pass
            self.focus="items"
            self.showItems(self.lastCategoryItems)
            return
        if mode == "retry_series":
            try:
                self["desc"].setText(tr("Preparing series categories in the background..."))
                self.catalogLoadTimer.start(500, False)
                self.catalogLoadResult = (token, "restart", [], [], "", "")
            except Exception:
                pass
            return
        if mode == "restart":
            self.loadCategories()
            return
        if mode == "error":
            if self.source.get("type") in ("xtream", "stalker") and self.catalogFirstOpenRetry < 1:
                self.catalogFirstOpenRetry += 1
                try:
                    self["desc"].setText(tr("Connecting to server..."))
                    self.catalogRetryTimer.start(700, True)
                except Exception:
                    self._retryCatalogFirstOpen()
                return
            try:
                self["desc"].setText(("Unable to load catalog:\\n%s" % error) if self.kind == "live" else ("خطأ في التحميل:\\n%s" % error))
            except Exception:
                pass
            return
        if mode == "bein_virtual":
            self.mediaItems = items or []
            self.mediaItemsCurrent = items or []
            self.categories = [{"category_name": u"⚽  beIN SPORTS", "category_id": "__bein_virtual__"}]
            self["category"].setList([(u"⚽  beIN SPORTS", "__bein_virtual__")])
            self._applyCategoryItems(items or [], "beIN SPORTS", origin or "cache")
            self.focus = "items"
            if not items:
                self["desc"].setText("No beIN SPORTS channels found in the selected server.")
            return
        if mode in ("xtream", "stalker"):
            allowed_ids = get_allowed_category_ids(self.source, self.kind)
            blocked = {"all", "all movies", "all films", "all vod", "all series", "كل الأفلام", "جميع الأفلام", "كل افلام", "جميع افلام", "كل المسلسلات", "جميع المسلسلات", "كل المحتوى"}
            rows = []
            filtered = []
            for entry in categories:
                name = (entry.get("category_name") or "Other").strip()
                cid = str(entry.get("category_id", ""))
                if allowed_ids is not None and cid not in allowed_ids:
                    continue
                if self.kind == "live" and not _adult_source_enabled(self.source) and _adult_live_name(name):
                    continue
                if self.kind in ("vod", "series") and name.lower() in blocked:
                    continue
                filtered.append(entry)
                rows.append((name, cid))
            if self.kind == "live":
                if self.source.get("type") in ("stalker", "xtream"):
                    hidden_state = _load_stalker_hidden(self.source) if self.source.get("type") == "stalker" else _load_xtream_hidden(self.source)
                    filtered = [entry for entry in filtered if str(entry.get("category_id", "")) not in hidden_state["categories"]]
                special = [
                    {"category_name": u"★  " + tr("FAVORITES"), "category_id": "__favorites__"},
                    {"category_name": u"＋  " + tr("RECENTLY ADDED"), "category_id": "__recent_added__"},
                ]
                if bool((self.source or {}).get("catchup_enabled", False)):
                    special.append({"category_name": u"↶  " + tr("CATCH-UP / ARCHIVE"), "category_id": "__catchup__"})
                filtered = special + filtered
                rows = [(entry.get("category_name") or "", str(entry.get("category_id") or "")) for entry in filtered]
            elif self.kind in ("vod", "series"):
                recent = {"category_name": tr("RECENTLY ADDED"), "category_id": "__recent_added__"}
                filtered = [recent] + filtered
                rows = [(entry.get("category_name") or "", str(entry.get("category_id") or "")) for entry in filtered]
            # Recent keeps the full filtered package list so RED/BLUE can
            # move to previous/next real packages.
            if self.kind in ("vod", "series") and self.initialCategoryId == "__recent_added__":
                pass
            self.categories = filtered
            if rows:
                self.catalogFirstOpenRetry = 0
            try:
                self["category"].setList(rows)
            except Exception:
                return
            if not rows:
                # A cold Stalker Live cache is refreshed by a daemon worker. Keep
                # the GUI responsive and poll briefly for the new disk/RAM cache.
                if mode == "stalker" and self.kind == "live" and origin == "loading" and self.catalogFirstOpenRetry < 8:
                    self.catalogFirstOpenRetry += 1
                    try:
                        self["desc"].setText(tr("Connecting to server...") + " (%d/8)" % self.catalogFirstOpenRetry)
                        self.catalogRetryTimer.start(500, True)
                    except Exception:
                        self._retryCatalogFirstOpen()
                    return
                if self.catalogFirstOpenRetry < 1:
                    self.catalogFirstOpenRetry += 1
                    try:
                        self["desc"].setText(tr("Connecting to server..."))
                        self.catalogRetryTimer.start(700, True)
                    except Exception:
                        self._retryCatalogFirstOpen()
                    return
                if self.source.get("type") == "stalker" and origin == "empty":
                    self["desc"].setText(tr("Stalker returned no packages. Check Portal URL and MAG MAC, then retry."))
                else:
                    self["desc"].setText("No packages available." if self.kind == "live" else "No categories available.")
                return
            had_initial_category = bool(self.initialCategoryId)
            if self.initialCategoryId:
                for pos, row in enumerate(rows):
                    if str(row[1]) == self.initialCategoryId:
                        try:
                            self["category"].moveToIndex(pos)
                        except Exception:
                            pass
                        break
                self.initialCategoryId = ""
            if self.kind == "series" and not had_initial_category:
                self.focus = "category"
                self["channelTitle"].setText(tr("Select a series category"))
                self["desc"].setText(tr("Select the category then press OK. Only this category will be loaded."))
            elif self.kind == "live":
                self.focus = "category"
                self["categoryTitle"].setText(tr("PACKAGES"))
                self["channelTitle"].setText(tr("Select a package"))
                self["desc"].setText(tr("Select a package") + " - OK")
                self._hideRowPicons()
                self._prewarmBeinSportsCache()
            else:
                self.loadSelectedCategory()
                self.focus = "items"
            return
        if mode == "m3u":
            self.mediaItems = items
            groups = sorted(set(entry.get("group", "Other") for entry in self.mediaItems))
            self.categories = [{"category_name": group, "category_id": group} for group in groups]
            rows = [(group, group) for group in groups]
            if self.kind == "live":
                rows = [(u"★  " + tr("FAVORITES"), "__favorites__"), (u"＋  " + tr("RECENTLY ADDED"), "__recent_added__")] + rows
                self.categories = [
                    {"category_name": name, "category_id": cid} for name, cid in rows
                ]
            elif self.kind in ("vod", "series"):
                rows = [(tr("RECENTLY ADDED"), "__recent_added__")] + rows
                self.categories = [{"category_name": name, "category_id": cid} for name, cid in rows]
            if self.kind in ("vod", "series") and self.initialCategoryId == "__recent_added__":
                pass
            self["category"].setList(rows)
            if self.kind == "live" and rows:
                self.focus = "category"
                self["categoryTitle"].setText(tr("PACKAGES"))
                self["channelTitle"].setText(tr("Select a package"))
                self["desc"].setText(tr("Select a package") + " - OK")
                self._hideRowPicons()
                self._prewarmBeinSportsCache()
            elif rows:
                self.loadSelectedCategory()
                self.focus = "items"
            else:
                self["desc"].setText("No packages available." if self.kind == "live" else "No categories available.")
            return
        # Stalker has a single, already-built channel group.
        self.mediaItems = items
        self["category"].setList([("All Channels", "")])
        self.showItems(self.mediaItems)

    def _catchupVerifyCacheKey(self):
        try:
            return hashlib.sha1(_source_identity(self.source or {}).encode("utf-8")).hexdigest()
        except Exception:
            return hashlib.sha1(str(_source_identity(self.source or {})).encode("utf-8")).hexdigest()

    def _loadCatchupVerifyCache(self):
        try:
            if not os.path.isfile(CATCHUP_VERIFY_CACHE_FILE):
                return {}
            with open_text(CATCHUP_VERIFY_CACHE_FILE, "r") as handle:
                payload = json.load(handle) or {}
            row = (payload.get("sources") or {}).get(self._catchupVerifyCacheKey(), {})
            saved = int(row.get("saved") or 0)
            if not saved or int(time.time()) - saved > 43200:
                return {}
            channels = row.get("channels") or {}
            return channels if isinstance(channels, dict) else {}
        except Exception:
            return {}

    def _saveCatchupVerifyCache(self, channels):
        try:
            ensure_dir(os.path.dirname(CATCHUP_VERIFY_CACHE_FILE))
            payload = {}
            if os.path.isfile(CATCHUP_VERIFY_CACHE_FILE):
                try:
                    with open_text(CATCHUP_VERIFY_CACHE_FILE, "r") as handle:
                        payload = json.load(handle) or {}
                except Exception:
                    payload = {}
            sources = payload.get("sources")
            if not isinstance(sources, dict):
                sources = {}
            sources[self._catchupVerifyCacheKey()] = {
                "saved": int(time.time()),
                "channels": channels or {}
            }
            payload["sources"] = sources
            with open_text(CATCHUP_VERIFY_CACHE_FILE, "w") as handle:
                json.dump(payload, handle)
        except Exception:
            pass

    def _verifyXtreamCatchupChannel(self, source, item):
        try:
            days = int(float(str(item.get("tv_archive_duration") or "0")))
        except Exception:
            days = 0
        if str(item.get("tv_archive") or "").strip() != "1" or days <= 0:
            return False

        sid = str(item.get("stream_id") or item.get("id") or "")
        epgid = str(item.get("epg_channel_id") or item.get("epg_id") or "")
        try:
            events = XtreamClient(source).catchup_epg(sid, epg_channel_id=epgid) or []
        except Exception:
            return False

        now = int(time.time())
        cutoff = now - days * 86400
        usable = []
        for event in events:
            if not isinstance(event, dict):
                continue
            begin = self._epgTimestamp(event, True)
            end = self._epgTimestamp(event, False)
            if begin and end and end <= now and begin >= cutoff and end > begin:
                usable.append((begin, event))
        usable.sort(key=lambda x: x[0], reverse=True)

        # Use the same dual-endpoint logic already proven by the player.
        base = str(source.get("url") or "").rstrip("/")
        user = str(source.get("username") or "")
        password = str(source.get("password") or "")
        output = str(source.get("output") or source.get("stream_format") or source.get("format") or "ts").strip().lstrip(".") or "ts"
        stream_name = "%s.%s" % (sid, output)

        for begin, event in usable[:3]:
            finish = self._epgTimestamp(event, False)
            duration = max(1, int((finish - begin + 59) / 60))
            raw_start = event.get("start") or event.get("begin") or ""
            start_dt = self._parseXtreamCatchupDate(raw_start)
            if start_dt:
                primary = start_dt.strftime("%Y-%m-%d:%H-%M")
            else:
                primary = time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin))

            starts = []
            for value in (
                primary,
                time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin)),
                time.strftime("%Y-%m-%d:%H-%M", time.gmtime(begin))
            ):
                if value and value not in starts:
                    starts.append(value)

            for start_text in starts:
                urls = [
                    "%s/timeshift/%s/%s/%d/%s/%s" % (base, user, password, duration, start_text, stream_name),
                    ("%s/streaming/timeshift.php?username=%s&password=%s&stream=%s&start=%s&duration=%d" %
                     (base, user, password, sid, start_text.replace(":", "%3A"), duration))
                ]
                for url in urls:
                    try:
                        req = Request(url)
                        try:
                            req.add_header("Range", "bytes=0-1023")
                        except Exception:
                            pass
                        resp = urlopen(req, timeout=4)
                        try:
                            code = int(getattr(resp, "getcode", lambda: 200)() or 200)
                        except Exception:
                            code = 200
                        try:
                            chunk = resp.read(1024)
                        finally:
                            try:
                                resp.close()
                            except Exception:
                                pass
                        if code in (200, 206) and chunk:
                            return True
                    except Exception:
                        pass
        return False

    def _loadCatchupPackage(self):
        """Show only channels whose Catch-up was confirmed playable."""
        if self.kind != "live" or self.source.get("type") not in ("xtream", "stalker"):
            return

        self.catchupPackageActive = True
        self.catchupPackageToken += 1
        token = self.catchupPackageToken
        source = dict(self.source or {})
        source_type = source.get("type")

        self["channelTitle"].setText(tr("Catch-up / Archive"))
        self["desc"].setText(tr("Checking playable catch-up channels..."))
        try:
            self["list"].setList([])
        except Exception:
            pass
        self.catchupPackageResult = None

        def advertises_archive(row):
            row = row or {}
            if source_type == "xtream":
                try:
                    days = int(float(str(row.get("tv_archive_duration") or "0")))
                except Exception:
                    days = 0
                return str(row.get("tv_archive") or "").strip() == "1" and days > 0
            archive = row.get("tv_archive") or row.get("archive") or row.get("has_archive")
            duration = row.get("tv_archive_duration") or row.get("archive_duration") or 0
            if str(archive or "").strip().lower() in ("1", "true", "yes", "on"):
                return True
            try:
                return int(float(str(duration or "0"))) > 0
            except Exception:
                return False

        def worker():
            rows = []
            error = ""
            try:
                client = get_source_client(source)
                all_rows = list(get_filtered_streams(source, "live", client) or [])
                candidates = [dict(x or {}) for x in all_rows if advertises_archive(x)]

                # Open Catch-up immediately from channels that advertise archive support.
                # Actual programme availability/playback is checked only after the user selects a channel.
                rows = candidates
            except Exception as exc:
                error = str(exc)

            self.catchupPackageResult = (token, rows, error)

        t = threading.Thread(target=worker, name="TiviMateCatchupPackage")
        t.daemon = True
        t.start()

        try:
            self.catchupPackageTimer.stop()
        except Exception:
            pass
        try:
            self.catchupPackageTimer.start(120, True)
        except Exception:
            pass


    def _finishCatchupPackageLoad(self):
        result = self.catchupPackageResult
        if result is None:
            try:
                self.catchupPackageTimer.start(120, True)
            except Exception:
                pass
            return

        self.catchupPackageResult = None
        try:
            self.catchupPackageTimer.stop()
        except Exception:
            pass

        try:
            token, items, error = result
        except Exception:
            return

        if token != self.catchupPackageToken or not self.catchupPackageActive:
            return

        self.mediaItems = list(items or [])
        self.mediaItemsCurrent = list(items or [])
        self.showItems(self.mediaItemsCurrent)
        self.focus = "items"
        self["channelTitle"].setText(tr("Catch-up / Archive"))

        if self.mediaItemsCurrent:
            try:
                self["desc"].setText("%d %s" % (
                    len(self.mediaItemsCurrent), tr("catch-up channels")
                ))
            except Exception:
                pass
        else:
            message = tr("No catch-up channels are available on this server.")
            if error:
                message += "\n" + error
            try:
                self["desc"].setText(message)
            except Exception:
                pass


    def selectedCategory(self):
        # LIVE categories are always selected from the left category widget.
        c = self["category"].getCurrent()
        return c[1] if c else ""


    def _stalkerLivePlaceholder(self, index):
        return {
            "name": "",
            "title": "",
            "number": str(index + 1),
            "stream_id": "",
            "id": "",
            "ch_id": "",
            "stream_icon": "",
            "logo": "",
            "cmd": "",
            "category_id": str(self.stalkerLiveCategoryId or ""),
            "_stalker_live": True,
            "_stalker_placeholder": True,
        }

    def _renderStalkerLiveSlots(self, keep_index=None):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        rows = []
        for index, entry in enumerate(self.stalkerLiveSlots or []):
            entry = entry or self._stalkerLivePlaceholder(index)
            if entry.get("_stalker_placeholder"):
                rows.append((" ", entry))
            else:
                # UI numbering must always be continuous and independent of the
                # provider/MAG channel number.  Some Stalker portals start at 2
                # or reuse numbering on each 14-row page.
                number = str(index + 1)
                name = entry.get("name") or entry.get("title") or "CHANNEL"
                rows.append(("%s   %s" % (number, name), entry))
        self.mediaItemsCurrent = list(self.stalkerLiveSlots or [])
        self["list"].setList(rows)
        if keep_index is None:
            keep_index = 0
        try:
            self["list"].moveToIndex(max(0, min(int(keep_index), max(0, len(rows)-1))))
        except Exception:
            pass
        self.focus = "items"
        try:
            self["pageInfo"].setText("%d / %d" % (
                (int(keep_index) + 1) if rows else 0,
                int(self.stalkerLiveTotal or len(rows))
            ))
        except Exception:
            pass

    def _cancelStalkerCatalogueRequests(self):
        event = getattr(self, "stalkerLiveCancelEvent", None)
        if event is not None:
            try: event.set()
            except Exception: pass
        try: self.stalkerLivePageGeneration += 1
        except Exception: pass
        try: self.stalkerLivePageTimer.stop()
        except Exception: pass
        try: self.stalkerLivePendingPages.clear()
        except Exception: pass
        self.stalkerLivePageResult = None

    def _beginStalkerLiveCategory(self, category_id, name):
        old_event = getattr(self, "stalkerLiveCancelEvent", None)
        if old_event is not None:
            try: old_event.set()
            except Exception: pass
        self.stalkerLiveCancelEvent = threading.Event()
        self.stalkerLivePageGeneration += 1
        generation = self.stalkerLivePageGeneration
        self.stalkerLiveCategoryId = str(category_id or "")
        # Some portals expose Adult bouquet names/categories normally but omit or
        # truncate their channels from get_all_channels.  Only when Adult is enabled
        # and the selected bouquet itself is Adult do we bypass local/full-catalogue
        # pages and ask get_ordered_list directly, matching EStalker behaviour.
        self.stalkerLiveAdultDirect = bool(
            _adult_source_enabled(self.source) and _adult_live_name(name)
        )
        self.stalkerLiveTotal = 0
        self.stalkerLiveSlots = []
        self.stalkerLiveLoadedPages = set()
        self.stalkerLivePendingPages = set()
        self.stalkerLivePageResult = None
        self._resetStalkerVisibleEpg()

        try:
            self["list"].setList([])
            self["channelTitle"].setText(name or tr("Select a channel"))
            self["desc"].setText(tr(""))
        except Exception:
            pass

        # Fast path: if page 1 is already cached, render it synchronously.
        # This avoids clearing the bouquet and then waiting for a worker + timer
        # even when no network request is needed.
        try:
            client = get_source_client(dict(self.source))
            cached_payload = None if self.stalkerLiveAdultDirect else client.live_page_cached(
                self.stalkerLiveCategoryId, 1, sortby="number"
            )
        except Exception:
            cached_payload = None
        if isinstance(cached_payload, dict) and isinstance(cached_payload.get("items"), list):
            self.stalkerLivePageResult = (generation, 1, cached_payload, "")
            self._finishStalkerLivePage()
            return

        if self.stalkerLiveAdultDirect:
            self._requestStalkerAdultFullCategory(generation)
        else:
            self._requestStalkerLivePage(1, generation)

    def _requestStalkerAdultFullCategory(self, generation):
        """Show the first 20 Adult channels quickly, then append the rest.

        Ministra returns 14 channels per MAG page.  We fetch only pages 1 and 2
        before first paint (enough for 20 rows), render those immediately, then
        continue collecting the remaining pages in a background worker.  The
        final list keeps one continuous 1..N numbering and never blocks opening
        the bouquet while all remaining pages are downloaded.
        """
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        source = dict(self.source)
        category_id = str(self.stalkerLiveCategoryId or "")
        cancel_event = getattr(self, "stalkerLiveCancelEvent", None)
        target_first = max(1, int(getattr(self, "stalkerLiveAdultPageSize", 20) or 20))

        def worker():
            first_items = []
            remainder = []
            total = 0
            next_page = 1
            error = ""
            try:
                if cancel_event is not None and cancel_event.is_set():
                    return
                client = get_source_client(source)
                page = 1
                while len(first_items) < target_first:
                    payload = client.live_page(
                        category_id, page, sortby="number", cancel_event=cancel_event,
                        force_network=True
                    ) or {}
                    if cancel_event is not None and cancel_event.is_set():
                        return
                    rows = list(payload.get("items") or [])
                    if not rows:
                        break
                    if not total:
                        try: total = int(payload.get("total_items") or 0)
                        except Exception: total = 0
                    need = max(0, target_first - len(first_items))
                    first_items.extend(rows[:need])
                    if len(rows) > need:
                        remainder.extend(rows[need:])
                    has_more = bool(payload.get("has_more"))
                    page += 1
                    next_page = page
                    if not has_more:
                        break
            except Exception as exc:
                if cancel_event is not None and cancel_event.is_set():
                    return
                try:
                    from .core import classify_stalker_error
                    _kind, error = classify_stalker_error(exc)
                except Exception:
                    error = str(exc)
            if generation != self.stalkerLivePageGeneration:
                return
            payload = {
                "items": list(first_items or []),
                "page": 1,
                "total_items": int(total or len(first_items)),
                "has_more": bool((total and len(first_items) < total) or remainder),
                "_adult_initial": True,
                "_adult_remainder": list(remainder or []),
                "_adult_next_page": int(next_page or 1),
            }
            self.stalkerLivePageResult = (generation, 1, payload, error)

        self.stalkerLivePendingPages.add(1)
        threading.Thread(
            target=worker,
            name="TiviMateAdultFirst20",
            daemon=True
        ).start()
        try:
            self.stalkerLivePageTimer.start(60, False)
        except Exception:
            pass

    def _requestStalkerAdultRemaining(self, generation, start_page, buffered=None, total_hint=0):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        source = dict(self.source)
        category_id = str(self.stalkerLiveCategoryId or "")
        cancel_event = getattr(self, "stalkerLiveCancelEvent", None)
        buffered = list(buffered or [])

        def worker():
            items = list(buffered)
            error = ""
            total = int(total_hint or 0)
            try:
                client = get_source_client(source)
                page = max(1, int(start_page or 1))
                while True:
                    if cancel_event is not None and cancel_event.is_set():
                        return
                    payload = client.live_page(
                        category_id, page, sortby="number", cancel_event=cancel_event,
                        force_network=True
                    ) or {}
                    rows = list(payload.get("items") or [])
                    if not rows:
                        break
                    items.extend(rows)
                    if not total:
                        try: total = int(payload.get("total_items") or 0)
                        except Exception: total = 0
                    if not bool(payload.get("has_more")):
                        break
                    page += 1
            except Exception as exc:
                if cancel_event is not None and cancel_event.is_set():
                    return
                try:
                    from .core import classify_stalker_error
                    _kind, error = classify_stalker_error(exc)
                except Exception:
                    error = str(exc)
            if generation != self.stalkerLivePageGeneration:
                return
            payload = {
                "items": items,
                "page": 2,
                "total_items": int(total or (len(self.stalkerLiveSlots) + len(items))),
                "has_more": False,
                "_adult_append": True,
            }
            self.stalkerLivePageResult = (generation, 2, payload, error)

        self.stalkerLivePendingPages.add(2)
        threading.Thread(
            target=worker,
            name="TiviMateAdultRemaining",
            daemon=True
        ).start()
        try:
            self.stalkerLivePageTimer.start(60, False)
        except Exception:
            pass

    def _requestStalkerLivePage(self, page, generation=None):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        try:
            page = max(1, int(page or 1))
        except Exception:
            page = 1
        if generation is None:
            generation = self.stalkerLivePageGeneration
        if generation != self.stalkerLivePageGeneration:
            return
        if page in self.stalkerLiveLoadedPages or page in self.stalkerLivePendingPages:
            return

        self.stalkerLivePendingPages.add(page)
        source = dict(self.source)
        category_id = str(self.stalkerLiveCategoryId or "")
        cancel_event = getattr(self, "stalkerLiveCancelEvent", None)

        def worker():
            payload = None
            error = ""
            try:
                if cancel_event is not None and cancel_event.is_set():
                    return
                client = get_source_client(source)
                payload = client.live_page(
                    category_id, page, sortby="number", cancel_event=cancel_event,
                    force_network=bool(getattr(self, "stalkerLiveAdultDirect", False))
                )
                if cancel_event is not None and cancel_event.is_set():
                    return
            except Exception as exc:
                if cancel_event is not None and cancel_event.is_set():
                    return
                try:
                    from .core import classify_stalker_error
                    _kind, error = classify_stalker_error(exc)
                except Exception:
                    error = str(exc)
            if generation != self.stalkerLivePageGeneration:
                return
            self.stalkerLivePageResult = (generation, page, payload or {}, error)

        threading.Thread(
            target=worker,
            name="TiviMateEStalkerPage%d" % page,
            daemon=True
        ).start()
        try:
            self.stalkerLivePageTimer.start(60, False)
        except Exception:
            pass

    def _finishStalkerLivePage(self):
        result = self.stalkerLivePageResult
        if not result:
            if self.stalkerLivePendingPages:
                try:
                    self.stalkerLivePageTimer.start(60, False)
                except Exception:
                    pass
            return

        self.stalkerLivePageResult = None
        generation, page, payload, error = result
        self.stalkerLivePendingPages.discard(page)
        if generation != self.stalkerLivePageGeneration:
            return

        if error:
            try:
                self["desc"].setText(tr("Unable to load package:\n%s") % error)
            except Exception:
                pass
            return

        items = list((payload or {}).get("items") or [])
        total = int((payload or {}).get("total_items") or 0)
        has_more = bool((payload or {}).get("has_more"))

        if bool((payload or {}).get("_adult_initial")):
            clean = []
            for index, item in enumerate(items):
                row = dict(item or {})
                row["number"] = str(index + 1)
                clean.append(row)
            self.stalkerLiveSlots = clean
            self.stalkerLiveTotal = max(int(total or 0), len(clean))
            self.stalkerLiveLoadedPages = set([1])
            try:
                current_index = int(self["list"].getSelectedIndex() or 0)
            except Exception:
                current_index = 0
            self._renderStalkerLiveSlots(current_index)
            self.previewLive()
            # Complete the bouquet only after the first 20 rows are already visible.
            remainder = list((payload or {}).get("_adult_remainder") or [])
            next_page = int((payload or {}).get("_adult_next_page") or 1)
            if bool((payload or {}).get("has_more")):
                self._requestStalkerAdultRemaining(
                    generation, next_page, buffered=remainder, total_hint=self.stalkerLiveTotal
                )
            return

        if bool((payload or {}).get("_adult_append")):
            base = [dict(x or {}) for x in list(self.stalkerLiveSlots or [])]
            seen = set()
            for row in base:
                key = str(row.get("ch_id") or row.get("stream_id") or row.get("id") or row.get("cmd") or row.get("name") or "")
                if key:
                    seen.add(key)
            for item in items:
                row = dict(item or {})
                key = str(row.get("ch_id") or row.get("stream_id") or row.get("id") or row.get("cmd") or row.get("name") or "")
                if key and key in seen:
                    continue
                if key:
                    seen.add(key)
                base.append(row)
            for index, row in enumerate(base):
                row["number"] = str(index + 1)
            self.stalkerLiveSlots = base
            self.stalkerLiveTotal = max(int(total or 0), len(base))
            page_size = max(1, int(getattr(self, "stalkerLiveAdultPageSize", 20) or 20))
            page_count = (len(base) + page_size - 1) // page_size
            self.stalkerLiveLoadedPages = set(range(1, page_count + 1))
            try:
                current_index = int(self["list"].getSelectedIndex() or 0)
            except Exception:
                current_index = 0
            self._renderStalkerLiveSlots(current_index)
            self.previewLive()
            return

        if total <= 0:
            total = max(len(self.stalkerLiveSlots), (page - 1) * 14 + len(items))
            if has_more:
                total = max(total, page * 14 + 14)

        if total > len(self.stalkerLiveSlots):
            self.stalkerLiveSlots.extend(
                self._stalkerLivePlaceholder(i)
                for i in range(len(self.stalkerLiveSlots), total)
            )

        start = (page - 1) * 14
        needed = start + len(items)
        if needed > len(self.stalkerLiveSlots):
            self.stalkerLiveSlots.extend(
                self._stalkerLivePlaceholder(i)
                for i in range(len(self.stalkerLiveSlots), needed)
            )

        for offset, item in enumerate(items):
            pos = start + offset
            if pos < len(self.stalkerLiveSlots):
                self.stalkerLiveSlots[pos] = dict(item or {})

        self.stalkerLiveTotal = max(total, needed)
        self.stalkerLiveLoadedPages.add(page)

        try:
            current_index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            current_index = 0

        self._renderStalkerLiveSlots(current_index)
        self.previewLive()

    def _ensureStalkerLiveCurrentPage(self):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        if bool(getattr(self, "stalkerLiveAdultDirect", False)):
            return
        try:
            index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            index = 0
        page = (index // 14) + 1
        if page not in self.stalkerLiveLoadedPages:
            self._requestStalkerLivePage(page)

    def _runStalkerSelectionEpg(self):
        if self.kind != "live":
            return
        item = self.current()
        if item and str(item.get("name") or item.get("title") or "").lstrip().startswith("####"):
            # r523: package/separator rows inside the channel list are display
            # labels only. Never resolve EPG, poster, picon or channel metadata.
            return
        source_type = self.source.get("type")
        if source_type == "stalker":
            # r541: the same selection timer controls every EPG reveal, even
            # when the highlighted channel is already cached.  Do not let a
            # previous/background Stalker batch make later selections appear
            # instantly; reveal the cached/current programme only after the
            # two-second debounce has completed.
            if item:
                fallback = (item.get("plot") or item.get("description") or "").strip()
                if self._applyStalkerShortEpg(item, fallback):
                    self._scheduleLivePoster(item)
            self._prefetchStalkerVisibleEpg()
        elif source_type == "xtream":
            # r462: reuse the existing selection debounce timer for Xtream.
            # Up/Down only moves the list; after scrolling settles, resolve EPG
            # for the currently highlighted channel once. This avoids doing a
            # local lookup/provider fallback on every key repeat.
            if item:
                self._updateLiveEpg(item)
                self._scheduleLivePoster(item)

    def _providerCategoryScore(self, name, provider):
        text=str(name or "").strip().lower()
        compact=re.sub(r"[^a-z0-9]+"," ",text).strip()
        tokens=[x for x in compact.split() if x]
        resolved=package_provider_key(name)
        if provider=="netflix":
            if "netflix" in compact:
                return 500
            if resolved=="netflix":
                return 450
            if "nf" in tokens:
                return 420
            if compact.startswith("nf ") or compact.endswith(" nf"):
                return 400
        elif provider=="prime":
            if "prime video" in compact:
                return 500
            if "amazon prime" in compact:
                return 480
            if resolved=="prime":
                return 450
            if "prime" in tokens:
                return 420
        return -1

    def _tmdbSortServerPackageItems(self, items, package_name, category_id=""):
        forced_provider=""
        try:
            forced_cid=str((self.source or {}).get("_package_provider_category_id") or "")
            if forced_cid and forced_cid==str(category_id or ""):
                forced_provider=str((self.source or {}).get("_package_provider_override") or "").strip().lower()
        except Exception:
            forced_provider=""
        provider=forced_provider or package_provider_key(package_name)
        if provider not in ("netflix","prime"):
            name=str(package_name or "").lower()
            if "netflix" in name or re.search(r"(^|[^a-z0-9])nf([^a-z0-9]|$)",name):
                provider="netflix"
            elif "prime" in name or "amazon" in name:
                provider="prime"
        if provider not in ("netflix","prime"):
            return list(items or [])

        rows=list(items or [])
        if not rows:
            return rows

        try:
            ranked=TMDbClient().provider_catalog(self.kind,provider,limit=200) or []
        except Exception:
            return rows

        def _norm_title(value):
            value=str(value or "").lower()
            value=value.replace("&"," and ")
            # Remove provider/source prefixes and common IPTV decorations.
            value=re.sub(r"\b(?:netflix|nf|prime video|amazon prime|prime)\b"," ",value)
            value=re.sub(r"\b(?:4k|uhd|fhd|hd|sd|hdr|dolby|atmos|hevc|x265|x264)\b"," ",value)
            value=re.sub(r"\b(?:multi|dual|audio|arabic|english|eng|ar|sub|subs|dub|dubbed)\b"," ",value)
            value=re.sub(r"\b(?:19|20)\d{2}\b"," ",value)
            value=re.sub(r"\([^)]*\)|\[[^]]*\]|\{[^}]*\}"," ",value)
            value=re.sub(r"[^a-z0-9]+"," ",value)
            return " ".join(value.split())

        rank_by_id={}
        rank_by_title={}
        ranked_titles=[]
        for pos,row in enumerate(ranked):
            tid=str(row.get("tmdb_id") or row.get("tmdb") or row.get("id") or "").strip()
            if tid and tid not in rank_by_id:
                rank_by_id[tid]=pos
            title=row.get("name") or row.get("title") or row.get("original_name") or row.get("original_title") or ""
            key=_norm_title(title)
            if key and key not in rank_by_title:
                rank_by_title[key]=pos
                ranked_titles.append((key,pos))

        matched=[]
        unmatched=[]
        for original_pos,item in enumerate(rows):
            item=item or {}
            _info=item.get("info") if isinstance(item.get("info"),dict) else {}
            tid=str(
                item.get("tmdb_id") or item.get("tmdb") or item.get("tmdbid") or
                _info.get("tmdb_id") or _info.get("tmdb") or _info.get("tmdbid") or ""
            ).strip()
            score=None
            if tid and tid in rank_by_id:
                score=rank_by_id[tid]
            else:
                title=item.get("name") or item.get("title") or item.get("original_name") or ""
                key=_norm_title(title)
                if key in rank_by_title:
                    score=rank_by_title[key]
                elif key:
                    # Conservative containment fallback for decorated server titles.
                    candidates=[]
                    for rk,rpos in ranked_titles:
                        if len(key)>=6 and len(rk)>=6 and (key in rk or rk in key):
                            candidates.append((abs(len(key)-len(rk)),rpos))
                    if candidates:
                        candidates.sort()
                        score=candidates[0][1]
            if score is None:
                unmatched.append((original_pos,item))
            else:
                matched.append((score,original_pos,item))

        matched.sort(key=lambda x:(x[0],x[1]))
        ordered=[x[2] for x in matched] + [x[1] for x in unmatched]
        # Provider package contract: Netflix / Prime never expose more than
        # 200 items in this curated view, even if the server category has
        # hundreds or thousands of entries.
        return ordered[:200]

    def _loadMergedServerProvider(self, provider):
        provider=str(provider or "").strip().lower()
        label="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
        self.categoryLoadToken += 1
        token=self.categoryLoadToken
        self.categoryLoadResult=None
        source=dict(self.source or {})
        kind=self.kind

        try:self["desc"].setText("Loading %s packages from server..." % label)
        except Exception:pass

        def worker():
            try:
                cats,origin=get_cached_categories(
                    source,kind,get_source_client(source),wait_for_server=True
                )
                cats=filter_categories(source,kind,cats or [])
                matches=[]
                for cat in cats:
                    cname=str(cat.get("category_name") or "")
                    cid=str(cat.get("category_id") or "")
                    score=self._providerCategoryScore(cname,provider)
                    if score>=0 and cid:
                        matches.append((score,cid,cname))
                matches.sort(key=lambda x:x[0],reverse=True)

                merged=[]
                seen=set()
                used_names=[]
                # Merge all matching Netflix/Prime server packages, capped at 200.
                for score,cid,cname in matches:
                    try:
                        package_items,_origin=get_category_streams(
                            source,kind,get_source_client(source),cid,
                            use_cache=True,wait_for_server=(kind!="series")
                        )
                    except Exception:
                        package_items=[]
                    if package_items:
                        used_names.append(cname)
                    for item in list(package_items or []):
                        key=str(
                            (item or {}).get("stream_id") or
                            (item or {}).get("series_id") or
                            (item or {}).get("id") or
                            (item or {}).get("tmdb_id") or
                            ((item or {}).get("name") or (item or {}).get("title") or "")
                        )
                        if key and key in seen:
                            continue
                        if key:
                            seen.add(key)
                        merged.append(item)
                        if len(merged)>=200:
                            break
                    if len(merged)>=200:
                        break

                if merged:
                    merged=self._tmdbSortServerPackageItems(merged,label)
                    result=(token,merged,"server_tmdb_sorted","",label)
                elif matches:
                    result=(token,[],"server_empty","",label)
                else:
                    result=(token,[],"provider_not_found","",label)
            except Exception as exc:
                result=(token,[],"error",str(exc),label)
            self.categoryLoadResult=result

        threading.Thread(target=worker,name="TiviMateProviderMerge",daemon=True).start()
        try:self.categoryLoadTimer.start(120,False)
        except Exception:pass


    def loadSelectedCategory(self):
        cid=self.selectedCategory()
        if cid=="__server_netflix__":
            self._loadMergedServerProvider("netflix")
            return
        if cid=="__server_prime__":
            self._loadMergedServerProvider("prime")
            return
        c = self["category"].getCurrent()
        name = c[0] if c else (self.activeCategoryName or self.initialCategoryName or "")
        if name:
            self.activeCategoryName = name
        if self.kind == "live" and cid == "__favorites__":
            source_key = favourite_source_id(self.source)
            items = []
            for record in list_favourites("live"):
                if record.get("source_id") != source_key:
                    continue
                item = dict(record.get("item") or {})
                if item:
                    items.append(item)
            self._applyCategoryItems(items, tr("FAVORITES"), "local")
            if not items:
                self["desc"].setText(tr("No favorite channels yet. Add channels with the red button."))
            return
        if self.kind == "live" and cid in ("__bein_sports__", "__bein_virtual__"):
            self._loadBeinSports()
            return
        if self.kind == "live" and cid == "__recent_added__":
            self.catchupPackageActive = False
            self._loadRecentlyAdded()
            return
        if self.kind in ("vod", "series") and cid == "__recent_added__":
            self._loadRecentlyAddedMedia()
            return
        if self.kind == "live" and cid == "__catchup__":
            if bool((self.source or {}).get("catchup_enabled", False)):
                self._loadCatchupPackage()
            return
        self.catchupPackageActive = False

        # EStalker 1.45: Stalker Live never downloads the whole package here.
        # Open page 1 (14 rows) and fetch later pages only when selection enters them.
        if self.kind == "live" and self.source.get("type") == "stalker":
            if not cid:
                return
            self._beginStalkerLiveCategory(cid, name)
            return

        if not cid and self.source.get("type") in ("xtream", "stalker"):
            return
        self["desc"].setText(("Loading %s..." % name) if self.kind == "live" else ("جاري تحميل %s..." % name))
        if self.source.get("type") in ("xtream", "stalker") and self.kind in ("live", "vod", "series"):
            self.categoryLoadToken += 1
            token = self.categoryLoadToken
            self.categoryLoadResult = None
            source = dict(self.source)
            kind = self.kind
            def worker():
                try:
                    items, origin = get_category_streams(source, kind, get_source_client(source), cid, use_cache=True, wait_for_server=(kind != "series"))
                    items = self._tmdbSortServerPackageItems(items or [], name, cid)
                    result = (token, items or [], origin, "", name)
                except Exception as exc:
                    result = (token, [], "error", str(exc), name)
                self.categoryLoadResult = result
            threading.Thread(target=worker, name="TiviMateE2Category", daemon=True).start()
            try: self.categoryLoadTimer.start(120, False)
            except Exception: pass
            return
        try:
            if self.source.get("type") in ("xtream", "stalker"): items=get_source_client(self.source).streams(self.kind,cid)
            elif self.source.get("type")=="m3u": items=[x for x in self.mediaItems if x.get("group")==cid]
            else: items=self.mediaItems
            self._applyCategoryItems(items or [], name, "server")
        except Exception as e:
            self.mediaItemsCurrent=[]
            if self.kind=="live": self["list"].setList([])
            self["desc"].setText(("Unable to load package:\n%s" % e) if self.kind == "live" else ("تعذر تحميل التصنيف:\n%s" % e))

    def _prewarmBeinSportsCache(self):
        """Build/refresh the beIN view quietly while the normal Live UI is open."""
        if self.kind != "live" or self.source.get("_virtual_bein"):
            return
        source = _bein_base_source(self.source)
        source_type = source.get("type")
        if source_type == "m3u":
            try:
                items = [item for item in (self.mediaItems or []) if _is_bein_sports_channel(item)]
                _save_bein_cache(source, items)
            except Exception:
                pass
            return
        if source_type not in ("xtream", "stalker"):
            return
        cached, fresh, stamp = _load_bein_cache(source)
        if fresh:
            return
        def worker():
            try:
                client = get_source_client(source)
                all_items = client.streams("live", "") or []
                items = [item for item in all_items if _is_bein_sports_channel(item)]
                _save_bein_cache(source, items)
            except Exception:
                pass
        threading.Thread(target=worker, name="TiviMateE2BeinPrewarm", daemon=True).start()

    def _loadBeinSports(self):
        """Open beIN SPORTS from a fast per-server cache, refreshing in background."""
        source = _bein_base_source(self.source)
        source_type = source.get("type")
        cached, fresh, stamp = _load_bein_cache(source)
        if cached:
            self._applyCategoryItems(cached, "beIN SPORTS", "cache")
            if not fresh:
                self["desc"].setText("beIN SPORTS • cached • refreshing in background")
                self._prewarmBeinSportsCache()
            return
        self["desc"].setText("Loading beIN SPORTS for the first time...")
        if source_type == "m3u":
            items = [item for item in (self.mediaItems or []) if _is_bein_sports_channel(item)]
            _save_bein_cache(source, items)
            self._applyCategoryItems(items, "beIN SPORTS", "local")
            if not items:
                self["desc"].setText("No beIN SPORTS channels found in this source.")
            return
        if source_type not in ("xtream", "stalker"):
            self._applyCategoryItems([], "beIN SPORTS", "local")
            self["desc"].setText("beIN SPORTS is available for Xtream, Stalker and M3U sources.")
            return
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self.categoryLoadResult = None
        def worker():
            try:
                client = get_source_client(source)
                items = client.streams("live", "") or []
                items = [item for item in items if _is_bein_sports_channel(item)]
                _save_bein_cache(source, items)
                result = (token, items, "server", "", "beIN SPORTS")
            except Exception as exc:
                result = (token, [], "error", str(exc), "beIN SPORTS")
            self.categoryLoadResult = result
        threading.Thread(target=worker, name="TiviMateE2BeinSports", daemon=True).start()
        try:
            self.categoryLoadTimer.start(120, False)
        except Exception:
            pass

    def _recentAddedTimestamp(self, item):
        keys = ("last_modified", "added", "added_at", "created_at", "date_added", "timestamp") if self.kind == "series" else ("added", "added_at", "created_at", "date_added", "timestamp")
        for key in keys:
            value = item.get(key)
            if value in (None, ""):
                continue
            try:
                return int(float(value))
            except Exception:
                pass
            try:
                import datetime
                value = str(value).replace("Z", "").split(".")[0]
                return int(time.mktime(datetime.datetime.strptime(value[:19], "%Y-%m-%d %H:%M:%S").timetuple()))
            except Exception:
                pass
        return 0

    def _recentStateKey(self, source):
        raw = "%s|%s|%s|%s" % (
            source.get("type", ""), source.get("url", "").rstrip("/"),
            source.get("username", ""), source.get("mac", ""))
        try:
            raw = raw.encode("utf-8")
        except Exception:
            pass
        return hashlib.sha1(raw).hexdigest()

    def _recentIdentity(self, item, order=0):
        return str(item.get("stream_id") or item.get("id") or item.get("url") or
                   item.get("cmd") or item.get("name") or order)

    def _loadRecentlyAdded(self):
        """Load genuinely recent Live channels for the active server.

        Xtream is fetched in one complete request so category cache gaps cannot
        corrupt the result. Provider ``added`` timestamps are preferred when
        present; snapshot comparison is the fallback for Stalker/M3U providers.
        """
        self["desc"].setText(tr("Loading recently added channels..."))
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self.categoryLoadResult = None
        source = dict(self.source)
        current_items = list(self.mediaItems or [])

        def worker():
            try:
                client = get_source_client(source)
                stype = source.get("type")
                if stype in ("m3u", "fg"):
                    merged = current_items
                elif stype == "xtream":
                    merged = client.streams("live", "") or []
                elif stype == "stalker":
                    try:
                        merged = client.streams("live", "") or []
                    except Exception:
                        merged = client.live_streams("") or []
                else:
                    merged = current_items

                dedup = {}
                ordered_ids = []
                for order, item in enumerate(merged or []):
                    if not isinstance(item, dict):
                        continue
                    key = self._recentIdentity(item, order)
                    if key in dedup:
                        continue
                    dedup[key] = dict(item)
                    ordered_ids.append(key)

                state_path = os.path.join(BASE, "recent_live_state.json")
                all_state = load_json(state_path, {}) or {}
                state_key = self._recentStateKey(source)
                previous = all_state.get(state_key) or {}
                # Schema 2 invalidates snapshots produced by the old category-by-
                # category implementation, which could silently miss channels.
                if int(previous.get("schema", 0) or 0) != 2:
                    previous = {}
                known = set(str(value) for value in (previous.get("known") or []))
                existing_recent = previous.get("recent") or {}
                now = int(time.time())
                max_age = 30 * 24 * 60 * 60
                cutoff = now - max_age

                recent = {}
                # Provider timestamps are the most faithful source for Xtream.
                timestamped = 0
                for key in ordered_ids:
                    stamp = self._recentAddedTimestamp(dedup[key])
                    if stamp > 0:
                        timestamped += 1
                        if stamp >= cutoff and stamp <= now + 86400:
                            recent[key] = stamp

                # Preserve still-valid snapshot additions and detect new IDs on
                # providers that do not publish reliable timestamps.
                for key, seen_at in existing_recent.items():
                    try:
                        seen_at = int(seen_at)
                    except Exception:
                        continue
                    if key in dedup and now - seen_at <= max_age:
                        recent.setdefault(key, seen_at)
                if known:
                    for key in ordered_ids:
                        if key not in known and key not in recent:
                            recent[key] = now

                all_state[state_key] = {
                    "schema": 2,
                    "known": ordered_ids,
                    "recent": recent,
                    "updated": now,
                    "timestamped": timestamped,
                }
                save_json(state_path, all_state)

                recent_ids = [key for key in ordered_ids if key in recent]
                order_map = dict((key, pos) for pos, key in enumerate(ordered_ids))
                recent_ids.sort(key=lambda key: (recent.get(key, 0), order_map.get(key, 0)), reverse=True)
                items = [dedup[key] for key in recent_ids[:50]]
                result = (token, items, "recent_added", "", tr("RECENTLY ADDED"))
            except Exception as exc:
                result = (token, [], "error", str(exc), tr("RECENTLY ADDED"))
            self.categoryLoadResult = result

        threading.Thread(target=worker, name="TiviMateE2RecentAdded", daemon=True).start()
        try:
            self.categoryLoadTimer.start(120, False)
        except Exception:
            pass

    def _loadRecentlyAddedMedia(self):
        """Recent Added: one final result only, newest twenty-five rows.

        No first-package preview and no progressive 5+5 publishing.  Scan the
        enabled package sources, keep only the newest twenty-five, then paint once.
        """
        cached = _load_recent_media_cache(self.source, self.kind)
        if cached:
            cached = list(cached or [])[:25]
            self._applyCategoryItems(cached, tr("RECENTLY ADDED"), "cache")
            try:
                self["desc"].setText(tr("RECENTLY ADDED") + " • cache")
            except Exception:
                pass
            return

        self["desc"].setText(tr("Loading recently added from enabled packages..."))
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self.categoryLoadResult = None
        source = dict(self.source)
        kind = self.kind
        current_items = list(self.mediaItems or [])

        def build_recent25(rows):
            dedup = {}
            for order, item in enumerate(rows or []):
                if not isinstance(item, dict):
                    continue
                key = str(item.get("stream_id") or item.get("series_id") or item.get("vod_id") or item.get("id") or "")
                if not key:
                    key = "%s:%s:%s" % (item.get("name") or item.get("title") or "", item.get("category_id") or item.get("group") or "", order)
                if key not in dedup:
                    dedup[key] = dict(item)
            items = list(dedup.values())
            items.sort(key=lambda row: self._recentAddedTimestamp(row), reverse=True)
            return [row for row in items if self._recentAddedTimestamp(row) > 0][:25]

        def worker():
            try:
                stype = source.get("type")
                allowed_ids = get_allowed_category_ids(source, kind)
                merged = []
                if stype == "stalker":
                    # r146: package browser already treats higher numeric category IDs
                    # as "Latest". Recent Added now follows that same provider order:
                    # start from the newest enabled package, collect only rows that
                    # actually carry an added/date timestamp, and stop as soon as 25
                    # candidates exist. Do not scan the remaining enabled packages.
                    client = get_source_client(source)
                    cats, _origin = get_cached_categories(source, kind, client, wait_for_server=True)
                    cats = filter_categories(source, kind, cats or [])
                    categories = [c for c in cats if str(c.get("category_id") or "") and (allowed_ids is None or str(c.get("category_id") or "") in allowed_ids)]

                    def _latest_package_key(pair):
                        pos, category = pair
                        cid = str(category.get("category_id") or "")
                        try:
                            return (1, int(cid))
                        except Exception:
                            # Same fallback idea as the Packages screen: when IDs are
                            # not numeric, later provider rows are considered newer.
                            return (0, pos)

                    indexed = list(enumerate(categories))
                    indexed.sort(key=_latest_package_key, reverse=True)
                    remaining = 25
                    for _pos, category in indexed:
                        if token != self.categoryLoadToken or remaining <= 0:
                            break
                        cid = str(category.get("category_id") or "")
                        if not cid:
                            continue
                        try:
                            rows, _ = get_category_streams(source, kind, client, cid, use_cache=True, wait_for_server=(kind != "series"))
                        except Exception:
                            continue
                        dated = []
                        for row in list(rows or []):
                            if not isinstance(row, dict):
                                continue
                            stamp = self._recentAddedTimestamp(row)
                            if stamp > 0:
                                dated.append((stamp, row))
                        if not dated:
                            continue
                        dated.sort(key=lambda pair: pair[0], reverse=True)
                        for _stamp, row in dated[:remaining]:
                            merged.append(row)
                            remaining -= 1
                            if remaining <= 0:
                                break
                elif stype == "xtream":
                    client = get_source_client(source)
                    cats, _origin = get_cached_categories(source, kind, client, wait_for_server=True)
                    cats = filter_categories(source, kind, cats or [])
                    categories = [c for c in cats if str(c.get("category_id") or "") and (allowed_ids is None or str(c.get("category_id") or "") in allowed_ids)]
                    for category in categories:
                        if token != self.categoryLoadToken:
                            return
                        cid = str(category.get("category_id") or "")
                        if not cid:
                            continue
                        try:
                            rows, _ = get_category_streams(source, kind, client, cid, use_cache=True, wait_for_server=(kind != "series"))
                            merged.extend(rows or [])
                        except Exception:
                            continue
                elif stype == "m3u":
                    merged = current_items
                    if allowed_ids is not None:
                        merged = [row for row in merged if str(row.get("group") or row.get("category_id") or "") in allowed_ids]
                else:
                    merged = current_items
                items = build_recent25(merged)
                _save_recent_media_cache(source, kind, items)
                self.categoryLoadResult = (token, items, "recent_added", "", tr("RECENTLY ADDED"))
            except Exception as exc:
                self.categoryLoadResult = (token, [], "error", str(exc), tr("RECENTLY ADDED"))

        threading.Thread(target=worker, name="TiviMateE2RecentMediaOnly25", daemon=True).start()
        try:
            self.categoryLoadTimer.start(80, False)
        except Exception:
            pass


    def _finishCategoryLoad(self):
        result = self.categoryLoadResult
        if not result:
            try: self.categoryLoadTimer.start(120, False)
            except Exception: pass
            return
        self.categoryLoadResult = None
        token, items, origin, error, name = result
        if token != self.categoryLoadToken:
            return
        if origin == "categories_loading":
            rows, cat_origin = get_cached_categories(self.source, "series")
            if not rows:
                self.categoryLoadResult = (token, [], "categories_loading", "", "")
                try: self.categoryLoadTimer.start(500, False)
                except Exception: pass
                return
            self.categories = rows
            allowed_ids = get_allowed_category_ids(self.source, self.kind)
            blocked = {"all", "all series", "كل المسلسلات", "جميع المسلسلات", "كل المحتوى"}
            menu=[]; filtered=[]
            for x in rows:
                cname=(x.get("category_name") or "Other").strip(); ccid=str(x.get("category_id", ""))
                if allowed_ids is not None and ccid not in allowed_ids: continue
                if self.kind == "live" and not _adult_source_enabled(self.source) and _adult_live_name(cname): continue
                if cname.lower() in blocked: continue
                filtered.append(x); menu.append((cname, ccid))
            if self.kind == "live" and self.source.get("type") == "stalker":
                hidden_state = _load_stalker_hidden(self.source)
                filtered = [x for x in filtered if str(x.get("category_id", "")) not in hidden_state["categories"]]
                menu = [(x.get("category_name") or "Other", str(x.get("category_id", ""))) for x in filtered]
            self.categories=filtered; self["category"].setList(menu)
            self["desc"].setText(tr("Select a series category then press OK.")) if menu else self["desc"].setText(tr("No categories available."))
            return
        if origin == "stalker_search_all":
            self.showItems(items or [])
            try:
                self["meta"].setText("Search All • %d" % len(items or []))
            except Exception:
                pass
            return
        if origin=="provider_not_found":
            self.mediaItemsCurrent=[]
            try:
                self["desc"].setText("%s package was not found on this server." % name)
                self["currentCategory"].setText(name)
            except Exception:pass
            return
        if origin=="server_empty":
            self.mediaItemsCurrent=[]
            try:
                self["desc"].setText("%s packages were found, but they returned no content." % name)
                self["currentCategory"].setText(name)
            except Exception:pass
            return
        if error:
            self.mediaItemsCurrent=[]
            self["desc"].setText(("Unable to load package:\n%s" % error) if self.kind == "live" else ("تعذر تحميل التصنيف:\n%s" % error))
            return
        if self.source.get("type") == "stalker" and origin == "empty":
            self.mediaItemsCurrent=[]
            if self.kind == "live":
                self["list"].setList([])
            self["desc"].setText(tr("Stalker returned no items for this package. Try another package or refresh the source."))
            return
        if origin == "loading" and self.kind == "series":
            cid = self.selectedCategory()
            cached, new_origin = get_category_streams(self.source, "series", get_source_client(self.source), cid, use_cache=True, wait_for_server=False)
            if not cached and new_origin == "loading":
                self["desc"].setText(tr("The category is preparing in the background... the interface will not freeze."))
                self.categoryLoadResult = (token, [], "loading", "", name)
                try: self.categoryLoadTimer.start(500, False)
                except Exception: pass
                return
            items, origin = cached, new_origin
        self._applyCategoryItems(items, name, origin)








    def _applyCategoryItems(self, items, name, origin="server"):
        self.activeCategoryName = name or self.initialCategoryName or ""
        self.activePackageProvider = self._providerFromPackageName(self.activeCategoryName)
        self._updateServerPackageGridLogo()
        items = self._tagPackageProvider(items, self.activeCategoryName)
        self.lastCategoryItems = items or []
        if self.kind != "live":
            try:
                suffix = {"ram":" • ذاكرة", "disk":" • HDD", "stale":" • HDD • تحديث بالخلفية", "server":""}.get(origin, "")
                self["currentCategory"].setText(name + suffix)
            except Exception:
                pass
        if self.searchQuery:
            self.applySearch(self.searchQuery)
        else:
            self.showItems(self.lastCategoryItems)


    def _providerFromPackageName(self, name):
        return package_provider_key(name)

    def _updateServerPackageGridLogo(self):
        if self.kind == "live":
            return
        mapping = {
            "netflix": "contentProviderNetflix",
            "prime": "contentProviderPrime",
            "disney": "contentProviderDisney",
            "max": "contentProviderMax",
            "apple": "contentProviderApple",
            "paramount": "contentProviderParamount",
        }
        provider = str(getattr(self, "activePackageProvider", "") or "").strip().lower()
        if not provider:
            try:
                package_name = str(getattr(self, "activeCategoryName", "") or
                                   getattr(self, "initialCategoryName", "") or "")
                provider = self._providerFromPackageName(package_name)
            except Exception:
                provider = ""
        active = mapping.get(provider, "")
        for widget_name in mapping.values():
            try:
                if widget_name == active:
                    self[widget_name].show()
                else:
                    self[widget_name].hide()
            except Exception:
                pass


    def _tagPackageProvider(self, items, package_name):
        if self.kind == "live":
            return list(items or [])
        provider = str(getattr(self, "activePackageProvider", "") or "").strip().lower()
        if not provider:
            provider = self._providerFromPackageName(package_name)

        tagged = []
        for item in list(items or []):
            if not isinstance(item, dict):
                tagged.append(item)
                continue
            row = dict(item)
            if provider:
                row["_tmdb_provider"] = provider
                row["_server_package_provider"] = provider
                row["_server_package_name"] = str(package_name or "")
            # Explicit source context: detail recommendations/backdrops must not
            # infer their origin from whatever page happens to be visible later.
            try:
                _cid=str(self.selectedCategory() or row.get("category_id") or "").strip()
            except Exception:
                _cid=str(row.get("category_id") or "").strip()
            if _cid:
                row["_source_category_id"]=_cid
            row["_source_scope"]="movies_package" if self.kind=="vod" else "series_package"
            row["_source_server_id"]=_source_identity(self.source)
            tagged.append(row)
        return tagged


    def _renderXtreamLiveBatch(self, keep_index=0, ensure_next=False):
        if self.kind != "live" or self.source.get("type") != "xtream":
            return False
        total = len(self.mediaItemsCurrent or [])
        batch = max(1, int(getattr(self, "xtreamLiveBatchSize", 15) or 15))
        loaded = int(getattr(self, "xtreamLiveLoadedCount", 0) or 0)
        if loaded <= 0:
            loaded = min(batch, total)
        elif ensure_next and loaded < total:
            loaded = min(total, loaded + batch)
        self.xtreamLiveLoadedCount = loaded
        rows = []
        for index, entry in enumerate((self.mediaItemsCurrent or [])[:loaded]):
            name = entry.get("name") or entry.get("title") or "Unnamed Channel"
            rows.append(("%03d   %s" % (index + 1, name), entry))
        self["list"].setList(rows)
        if rows:
            try:
                self["list"].moveToIndex(max(0, min(int(keep_index), len(rows) - 1)))
            except Exception:
                pass
        try:
            shown = (int(keep_index) + 1) if rows else 0
            self["pageInfo"].setText("%d / %d" % (shown, total))
        except Exception:
            pass
        return True

    def _ensureXtreamNextLiveBatch(self):
        if self.kind != "live" or self.source.get("type") != "xtream" or self.focus != "items":
            return False
        total = len(self.mediaItemsCurrent or [])
        loaded = int(getattr(self, "xtreamLiveLoadedCount", 0) or 0)
        if loaded <= 0 or loaded >= total:
            return False
        try:
            index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            index = 0
        # Append only when the user has actually reached the last rendered row.
        if index < max(0, loaded - 1):
            return False
        self._renderXtreamLiveBatch(index, ensure_next=True)
        return True

    def showItems(self, items):
        if self.kind == "live" and self.source.get("type") in ("stalker", "xtream"):
            hidden_state = _load_stalker_hidden(self.source) if self.source.get("type") == "stalker" else _load_xtream_hidden(self.source)
            items = [x for x in (items or []) if _live_item_id(x) not in hidden_state["channels"]]
        elif self.kind in ("vod", "series"):
            # One seen-set for the whole screen list, not one per visual page.
            # This prevents the same title reappearing on page 2/3/4.
            items = _dedupe_content_rows(items or [], self.kind)
        self.mediaItemsCurrent = items or []
        self.pageStart = 0
        self.posterIndex = 0
        if self.kind == "live":
            self._resetStalkerVisibleEpg()
            # r461: Xtream list itself is lazy-rendered in 15-row batches.
            # Do not push the whole bouquet into MenuList at open time.
            if self.source.get("type") == "xtream":
                self.xtreamLiveLoadedCount = 0
                self._renderXtreamLiveBatch(0, ensure_next=False)
            else:
                rows = []
                for index, entry in enumerate(self.mediaItemsCurrent):
                    name = entry.get("name") or entry.get("title") or "Unnamed Channel"
                    rows.append(("%03d   %s" % (index + 1, name), entry))
                self["list"].setList(rows)
                try:
                    self["list"].moveToIndex(0)
                except Exception:
                    pass
            self.focus = "items"
            try:
                current = next((entry for entry in self.categories if str(entry.get("category_id", "")) == str(self.selectedCategory())), None)
                if current:
                    self["categoryTitle"].setText(current.get("category_name") or "القنوات")
                self["pageInfo"].setText("1 / %d" % len(self.mediaItemsCurrent) if self.mediaItemsCurrent else "0 / 0")
            except Exception:
                pass
            self.previewLive()
        else:
            self.renderPosterPage()


    def current(self):
        if self.kind=="live":
            if self.focus != "items": return None
            c=self["list"].getCurrent(); return c[1] if c else None
        idx=self.pageStart+self.posterIndex
        return self.mediaItemsCurrent[idx] if 0 <= idx < len(self.mediaItemsCurrent) else None

    def previewLive(self):
        item = self.current()
        if not item:
            return

        # r523: rows beginning with #### are package/separator labels inside
        # the channel list, not playable channels. Show only their label and
        # suppress all channel information work for that selection.
        item_title = str(item.get("name") or item.get("title") or "")
        if item_title.lstrip().startswith("####"):
            try:
                self.stalkerSelectionEpgTimer.stop()
            except Exception:
                pass
            try:
                self["channelTitle"].setText(item_title)
                self["meta"].setText(tr(""))
                self["desc"].setText(tr(""))
            except Exception:
                pass
            for key in ("epgNowTime", "epgNowTitle", "epgNextTime", "epgNextTitle", "epgProgressText"):
                try:
                    self[key].setText(tr(""))
                except Exception:
                    pass
            try:
                self["liveProgress"].setValue(0)
            except Exception:
                pass
            for key in ("channelPicon", "livePoster"):
                try:
                    self[key].hide()
                except Exception:
                    pass
            return

        # EStalker progressive page load.
        if self.source.get("type") == "stalker":
            self._ensureStalkerLiveCurrentPage()
            if item.get("_stalker_placeholder"):
                try:
                    self["channelTitle"].setText(tr("Loading..."))
                    self["meta"].setText(tr(""))
                    self["desc"].setText(tr(""))
                    self["channelPicon"].hide()
                except Exception:
                    pass
                return

        self["channelTitle"].setText(item.get("name") or item.get("title") or "Unnamed Channel")
        self["meta"].setText(tr(""))

        # EStalker: clear old Picon then debounce current one for 250 ms.
        self._showLivePicon(item)

        if self.source.get("type") == "stalker":
            # r535: never resolve EPG while the selection is moving. Clear the
            # previous row cheaply and wait 5 seconds on the final highlighted
            # channel before doing the existing EPG lookup.
            for key in ("epgNowTime", "epgNowTitle", "epgNextTime", "epgNextTitle", "epgProgressText"):
                try:
                    self[key].setText(tr(""))
                except Exception:
                    pass
            try:
                self["liveProgress"].setValue(0)
            except Exception:
                pass
            try:
                self.stalkerSelectionEpgTimer.stop()
                self.stalkerSelectionEpgTimer.start(2000, True)
            except Exception:
                self._runStalkerSelectionEpg()

            # EStalker does not run TMDb artwork while scrolling Stalker Live.
            try:
                self["livePoster"].hide()
            except Exception:
                pass
        else:
            if self.source.get("type") == "xtream":
                # r462: do not run EPG lookup while Up/Down is moving. Clear the
                # previous channel's programme text cheaply, then let the existing
                # 5-second selection timer resolve only the final highlighted row.
                for key in ("epgNowTime", "epgNowTitle", "epgNextTime", "epgNextTitle", "epgProgressText"):
                    try:
                        self[key].setText(tr(""))
                    except Exception:
                        pass
                try:
                    self["liveProgress"].setValue(0)
                except Exception:
                    pass
                try:
                    self["desc"].setText((item.get("plot") or item.get("description") or "").strip())
                except Exception:
                    pass
                try:
                    self.stalkerSelectionEpgTimer.stop()
                    self.stalkerSelectionEpgTimer.start(2000, True)
                except Exception:
                    self._runStalkerSelectionEpg()
            else:
                self._updateLiveEpg(item)
                self._scheduleLivePoster(item)

        try:
            index = self["list"].getSelectedIndex() + 1
            total = self.stalkerLiveTotal if self.source.get("type") == "stalker" and self.stalkerLiveTotal else len(self.mediaItemsCurrent)
            self["pageInfo"].setText("%d / %d" % (index, total))
        except Exception:
            pass

        try:
            self.zapTimer.stop()
        except Exception:
            pass

    def _resetStalkerVisibleEpg(self):
        if self.kind != "live": return
        self.stalkerEpgGeneration = int(getattr(self, "stalkerEpgGeneration", 0) or 0) + 1
        self.stalkerEpgDownloadedChannels = set()
        self.stalkerShortEpgResults = {}
        self.stalkerEpgPending = []
        self.stalkerEpgBatchRunning = False
        try: self.stalkerEpgApplyTimer.stop()
        except Exception: pass

    def _stalkerEpgChannelId(self, item):
        return str((item or {}).get("ch_id") or (item or {}).get("stream_id") or (item or {}).get("id") or "").strip()

    def _stalkerVisibleChannelIds(self):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return []
        rows = self.mediaItemsCurrent or []
        try:
            current_index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            current_index = 0
        start = (current_index // 14) * 14
        visible = []
        seen = set()
        for item in rows[start:start + 14]:
            if not isinstance(item, dict) or item.get("_stalker_placeholder"):
                continue
            ch_id = str(item.get("id") or item.get("ch_id") or item.get("stream_id") or "")
            if ch_id and ch_id not in seen:
                seen.add(ch_id)
                visible.append(ch_id)
        return visible

    def _stalkerCleanDescription(self, descr):
        value=str(descr or "").replace("\\r\\n","\\n")
        match=re.search(r"Description:\\s*(.+)",value,re.DOTALL)
        if not match: return value.strip()
        description=match.group(1)
        for label in ("Credits:","Director:","Producer:","Actor:","Category:"):
            pos=description.find(label)
            if pos!=-1:
                description=description[:pos]; break
        return description.strip()

    def _stalkerPortalLocalTimestamp(self, value):
        if value in (None,""): return 0
        try:
            if isinstance(value,(int,float)): return int(value)
        except Exception: pass
        raw=str(value or "").strip()
        try: return int(float(raw))
        except Exception: pass
        try: return int(time.mktime(time.strptime(raw[:19],"%Y-%m-%d %H:%M:%S")))
        except Exception: return 0

    def _storeStalkerShortEpg(self, entries):
        grouped={}
        for entry in entries or []:
            if not isinstance(entry,dict): continue
            ch_id=str(entry.get("ch_id") or "").strip()
            if not ch_id or ch_id=="None": continue
            grouped.setdefault(ch_id,[]).append(dict(entry))
        for ch_id,rows in grouped.items():
            self.stalkerShortEpgResults[ch_id]=rows
        return bool(grouped)

    def _stalkerCurrentNext(self, rows):
        now=int(time.time()); events=[]
        for row in rows or []:
            if not isinstance(row,dict): continue
            start=self._stalkerPortalLocalTimestamp(row.get("time") or row.get("start_timestamp") or row.get("start") or row.get("begin"))
            stop=self._stalkerPortalLocalTimestamp(row.get("time_to") or row.get("stop_timestamp") or row.get("stop") or row.get("end"))
            if not stop and start and row.get("duration"):
                try: stop=start+int(float(row.get("duration")))
                except Exception: pass
            if start and stop: events.append((start,stop,row))
        events.sort(key=lambda x:x[0])
        for i,event in enumerate(events):
            if event[0] < now < event[1]:
                return event, events[i+1] if i+1<len(events) else None
        if events:
            for i,event in enumerate(events):
                if event[0]>now:
                    return event, events[i+1] if i+1<len(events) else None
            return events[0], events[1] if len(events)>1 else None
        return None,None

    def _applyStalkerShortEpg(self, item, fallback=""):
        rows=self.stalkerShortEpgResults.get(self._stalkerEpgChannelId(item)) or []
        current,upcoming=self._stalkerCurrentNext(rows)
        if not current: return False
        now=int(time.time()); begin,stop,row=current; duration=max(0,stop-begin)
        title=str(row.get("name") or row.get("title") or "").strip()
        desc=self._stalkerCleanDescription(row.get("descr") or row.get("description") or row.get("desc") or "")
        self["epgNowTime"].setText(str(row.get("t_time") or "").strip() or self._formatEpgTime(begin,duration))
        self["epgNowTitle"].setText(title)
        percent=min(100,max(0,int(((now-begin)*100)/duration))) if duration>0 else 0
        try: self["liveProgress"].setValue(percent)
        except Exception: pass
        self["epgProgressText"].setText("%d%%"%percent)
        self["desc"].setText((desc or fallback or "No programme description.")[:600])
        if upcoming:
            nb,ns,nrow=upcoming; nd=max(0,ns-nb)
            self["epgNextTime"].setText(str(nrow.get("t_time") or "").strip() or self._formatEpgTime(nb,nd))
            self["epgNextTitle"].setText(str(nrow.get("name") or nrow.get("title") or "").strip())
        else:
            self["epgNextTime"].setText(tr("")); self["epgNextTitle"].setText(tr(""))
        return True

    def _queueStalkerEpgUpdate(self, kind, payload, generation):
        try:
            with self.stalkerEpgLock:
                self.stalkerEpgPending.append((kind,payload,generation))
        except Exception: pass

    def _drainStalkerEpgUpdates(self):
        try:
            with self.stalkerEpgLock:
                pending=list(self.stalkerEpgPending); self.stalkerEpgPending[:]=[]
        except Exception: pending=[]
        changed=False; done_seen=False
        for kind,payload,generation in pending:
            if generation != self.stalkerEpgGeneration: continue
            if kind=="partial":
                changed = self._storeStalkerShortEpg((payload or {}).get("js",[])) or changed
            elif kind=="done":
                done_seen=True
                for ch_id in (payload or {}).get("failed_ids",[]):
                    self.stalkerEpgDownloadedChannels.discard(str(ch_id))
                changed = self._storeStalkerShortEpg((payload or {}).get("js",[])) or changed
                self.stalkerEpgBatchRunning=False
        if changed or done_seen:
            # r541: keep downloaded Stalker EPG in cache, but never reveal it
            # here while the selection debounce is still running.  The existing
            # stalkerSelectionEpgTimer is the single point that reveals EPG for
            # every highlighted channel after two seconds.
            try:
                selection_timer_active = bool(self.stalkerSelectionEpgTimer.isActive())
            except Exception:
                selection_timer_active = True
            if not selection_timer_active:
                item=self.current()
                if item and self.source.get("type")=="stalker":
                    fallback=(item.get("plot") or item.get("description") or "").strip()
                    if self._applyStalkerShortEpg(item,fallback):
                        self._scheduleLivePoster(item)
        if done_seen: self._prefetchStalkerVisibleEpg()
        if self.stalkerEpgBatchRunning or self.stalkerEpgPending:
            try: self.stalkerEpgApplyTimer.start(100,True)
            except Exception: pass

    def _prefetchStalkerVisibleEpg(self):
        if self.kind!="live" or self.source.get("type")!="stalker": return False
        if self.stalkerEpgBatchRunning: return True
        visible=self._stalkerVisibleChannelIds()
        fetch=[x for x in visible if x not in self.stalkerEpgDownloadedChannels]
        if not fetch: return bool(visible)
        for x in fetch: self.stalkerEpgDownloadedChannels.add(x)
        if self.stalkerEpgClient is None:
            try: self.stalkerEpgClient=StalkerClient(dict(self.source))
            except Exception: self.stalkerEpgClient=None
        if self.stalkerEpgClient is None:
            for x in fetch: self.stalkerEpgDownloadedChannels.discard(x)
            return False
        generation=self.stalkerEpgGeneration; self.stalkerEpgBatchRunning=True
        def partial(payload): self._queueStalkerEpgUpdate("partial",payload or {},generation)
        def done(payload): self._queueStalkerEpgUpdate("done",payload or {},generation)
        try:
            self.stalkerEpgClient.short_epg_batch(fetch,limit=10,done_callback=done,partial_callback=partial)
            self.stalkerEpgApplyTimer.start(100,True)
            return True
        except Exception:
            self.stalkerEpgBatchRunning=False
            for x in fetch: self.stalkerEpgDownloadedChannels.discard(x)
            return False

    def _xtreamEpgChannelId(self, item):
        return str((item or {}).get("ch_id") or (item or {}).get("stream_id") or (item or {}).get("id") or (item or {}).get("channel_id") or "").strip()

    def _xtreamVisibleItems(self):
        if self.kind != "live" or self.source.get("type") != "xtream":
            return []
        rows = self.mediaItemsCurrent or []
        try:
            current_index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            current_index = 0
        start = (current_index // 15) * 15
        visible = []
        seen = set()
        page_rows = list(rows[start:start + 15])
        # Fetch the highlighted channel first. This mirrors the perceived
        # Stalker behaviour: the row the user is looking at wins priority,
        # while the remaining visible rows warm in the background.
        selected = rows[current_index] if 0 <= current_index < len(rows) else None
        ordered = ([selected] if isinstance(selected, dict) else []) + page_rows
        for item in ordered:
            if not isinstance(item, dict):
                continue
            ch_id = self._xtreamEpgChannelId(item)
            if ch_id and ch_id not in seen:
                seen.add(ch_id)
                visible.append(dict(item))
        return visible

    def _xtreamCachedShortEpg(self, item, max_age=600):
        ch_id = self._xtreamEpgChannelId(item)
        if not ch_id:
            return []
        try:
            with self.xtreamEpgLock:
                cached = self.xtreamShortEpgResults.get(ch_id)
        except Exception:
            cached = None
        if not cached:
            return []
        try:
            stamp, rows = cached
            if max_age is not None and (time.time() - float(stamp or 0)) > float(max_age):
                return []
            return [dict(row) for row in (rows or []) if isinstance(row, dict)]
        except Exception:
            return []

    def _storeXtreamShortEpg(self, item, rows):
        clean = [dict(row) for row in (rows or []) if isinstance(row, dict)]
        if not clean:
            return False
        ch_id = self._xtreamEpgChannelId(item)
        if not ch_id:
            return False
        try:
            with self.xtreamEpgLock:
                self.xtreamShortEpgResults[ch_id] = (time.time(), clean)
                if len(self.xtreamShortEpgResults) > 120:
                    oldest = sorted(self.xtreamShortEpgResults.items(), key=lambda kv: float((kv[1] or (0,))[0] or 0))[:30]
                    for key, _value in oldest:
                        self.xtreamShortEpgResults.pop(key, None)
            return True
        except Exception:
            return False

    def _getXtreamEpgClient(self):
        source = dict(_bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source)
        try:
            client = self.xtreamEpgClient
            if client is not None and getattr(client, "base", "") == str(source.get("url") or "").rstrip("/") and getattr(client, "user", "") == str(source.get("username") or ""):
                return client
        except Exception:
            pass
        try:
            self.xtreamEpgClient = XtreamClient(source)
        except Exception:
            self.xtreamEpgClient = None
        return self.xtreamEpgClient

    def _prefetchXtreamVisibleEpg(self):
        """r460: disabled for Xtream Live.

        Do not batch-fetch the visible 15 rows while the user scrolls. Each
        highlighted channel may use its own non-blocking short_epg fallback;
        the list itself never waits for EPG.
        """
        return False

    def _formatEpgTime(self, begin, duration=0):
        try:
            start = time.strftime("%H:%M", time.localtime(int(begin)))
            if duration:
                end = time.strftime("%H:%M", time.localtime(int(begin) + int(duration)))
                return "%s - %s" % (start, end)
            return start
        except Exception:
            return ""

    def _decodeEpgText(self, value):
        value = value or ""
        if not isinstance(value, str):
            try: value = str(value)
            except Exception: return ""
        # Xtream panels commonly return title/description as base64, but some
        # providers already return plain UTF-8. Decode only when it is valid.
        try:
            raw = value.strip()
            if raw and len(raw) % 4 == 0:
                decoded = base64.b64decode(raw).decode("utf-8", "replace").strip()
                if decoded and any(ch.isalnum() for ch in decoded):
                    return decoded
        except Exception:
            pass
        return value.strip()

    def _epgTimestamp(self, row, start=True):
        keys = ("start_timestamp", "start", "begin_timestamp", "begin") if start else ("stop_timestamp", "end", "end_timestamp", "stop")
        for key in keys:
            value = row.get(key)
            if value in (None, ""):
                continue
            try:
                return int(float(value))
            except Exception:
                try:
                    # Common panel format: 2026-08-02 03:30:00
                    return int(time.mktime(time.strptime(str(value)[:19], "%Y-%m-%d %H:%M:%S")))
                except Exception:
                    pass
        return 0

    def _applyXtreamShortEpgRows(self, rows, fallback="", error=""):
        """Apply Xtream short_epg rows on the GUI thread.

        r441 keeps parsing/display separate from networking so the selected
        channel can consume the same prefetch cache instead of racing a second
        direct request/token.
        """
        now_ts = int(time.time())
        parsed = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._epgTimestamp(row, True)
            end = self._epgTimestamp(row, False)
            duration = max(0, end - begin)
            title = self._decodeEpgText(row.get("title") or row.get("name") or row.get("programme"))
            desc = self._decodeEpgText(row.get("description") or row.get("desc") or row.get("plot"))
            if begin and title:
                parsed.append((begin, duration, title, desc))
        parsed.sort(key=lambda x: x[0])
        current = None
        upcoming = None
        for event in parsed:
            begin, duration, title, desc = event
            finish = begin + duration if duration else begin + 3600
            if begin <= now_ts < finish:
                current = event
            elif begin > now_ts and upcoming is None:
                upcoming = event
        if current is None and parsed:
            current = parsed[0]
            upcoming = parsed[1] if len(parsed) > 1 else upcoming
        if not current:
            return False
        begin, duration, title, desc = current
        self["epgNowTime"].setText(self._formatEpgTime(begin, duration))
        self["epgNowTitle"].setText(title)
        elapsed = max(0, now_ts - begin)
        percent = min(100, max(0, int((elapsed * 100) / duration))) if duration > 0 else 0
        self["epgProgressText"].setText("%d%%" % percent)
        try:
            self["liveProgress"].setValue(percent)
        except Exception:
            pass
        self["desc"].setText((desc or fallback or "No programme description.")[:600])
        if upcoming:
            ub, ud, ut, _ = upcoming
            self["epgNextTime"].setText(self._formatEpgTime(ub, ud))
            self["epgNextTitle"].setText(ut or "")
        else:
            self["epgNextTime"].setText("")
            self["epgNextTitle"].setText("")
        return True

    def _startXtreamSelectedEpg(self, item, fallback=""):
        """Start one priority Xtream short_epg request for the highlighted row.

        r443 deliberately keeps this independent from visible-page prefetch so
        a busy/finishing batch can never prevent the selected channel request.
        Repeated UI refreshes for the same channel reuse the in-flight request.
        """
        ch_id = self._xtreamEpgChannelId(item)
        if not ch_id:
            return False
        self.xtreamDirectEpgSelected = ch_id
        self.xtreamDirectEpgFallback = fallback or ""
        cached = self._xtreamCachedShortEpg(item, max_age=600)
        if cached:
            return self._applyXtreamShortEpgRows(cached, fallback)
        launch = False
        try:
            with self.xtreamEpgLock:
                if ch_id not in self.xtreamDirectEpgInFlight:
                    self.xtreamDirectEpgInFlight.add(ch_id)
                    self.xtreamDirectEpgResults.pop(ch_id, None)
                    launch = True
        except Exception:
            launch = True
        if launch:
            source = dict(_bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source)
            request_item = dict(item)
            def worker():
                rows = []
                error = ""
                try:
                    client = self._getXtreamEpgClient()
                    if client is None:
                        raise RuntimeError("Xtream EPG client unavailable")
                    epg_channel_id = str(request_item.get("epg_channel_id") or request_item.get("tvg_id") or request_item.get("epg_id") or "").strip()
                    rows = client.short_epg(ch_id, limit=10, epg_channel_id=epg_channel_id) or []
                    if not isinstance(rows, list):
                        rows = []
                    if rows:
                        self._storeXtreamShortEpg(request_item, rows)
                except Exception as exc:
                    error = str(exc)
                    rows = []
                try:
                    with self.xtreamEpgLock:
                        self.xtreamDirectEpgResults[ch_id] = (rows, error, request_item, fallback or "")
                        self.xtreamDirectEpgInFlight.discard(ch_id)
                except Exception:
                    self.xtreamDirectEpgResults[ch_id] = (rows, error, request_item, fallback or "")
                    try: self.xtreamDirectEpgInFlight.discard(ch_id)
                    except Exception: pass
            t = threading.Thread(target=worker, name="TiviMateXtreamSelectedEPG")
            t.daemon = True
            t.start()
        try:
            self.directEpgTimer.stop()
            self.directEpgTimer.start(80, True)
        except Exception:
            pass
        return True

    def _startDirectEpg(self, item, fallback=""):
        effective_source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
        source_type = effective_source.get("type")
        if source_type not in ("xtream", "stalker"):
            return False
        stream_id = str(item.get("ch_id") or item.get("stream_id") or item.get("id") or "").strip()
        if not stream_id:
            return False
        self.directEpgToken += 1
        token = self.directEpgToken
        self.directEpgResult = None
        source = dict(effective_source)
        def worker():
            result = []
            error = ""
            try:
                if source_type == "stalker":
                    client = self.stalkerEpgClient
                    if client is None:
                        client = StalkerClient(source)
                        self.stalkerEpgClient = client
                    result = client.short_epg(stream_id, limit=10)
                else:
                    client = self._getXtreamEpgClient()
                    if client is None:
                        client = XtreamClient(source)
                    epg_channel_id = str(item.get("epg_channel_id") or item.get("tvg_id") or "").strip()
                    result = client.short_epg(stream_id, limit=10, epg_channel_id=epg_channel_id)
                if not isinstance(result, list):
                    result = []
            except Exception as exc:
                error = str(exc)
            self.directEpgResult = (token, result, fallback, error)
        threading.Thread(target=worker, name="TiviMateDirectEPG", daemon=True).start()
        try: self.directEpgTimer.start(120, False)
        except Exception: pass
        return True

    def _finishDirectEpg(self):
        # r443: selected Xtream channel is independent from page prefetch.
        # Poll only its direct result; repeated list refreshes do not cancel it.
        if self.source.get("type") == "xtream":
            ch_id = str(getattr(self, "xtreamDirectEpgSelected", "") or "")
            if ch_id:
                result = None
                inflight = False
                try:
                    with self.xtreamEpgLock:
                        result = self.xtreamDirectEpgResults.pop(ch_id, None)
                        inflight = ch_id in self.xtreamDirectEpgInFlight
                except Exception:
                    result = self.xtreamDirectEpgResults.pop(ch_id, None)
                    inflight = ch_id in getattr(self, "xtreamDirectEpgInFlight", set())
                if result is not None:
                    rows, error, request_item, fallback = result
                    # Ignore a late result if the user has already highlighted
                    # another channel, but keep successful rows in RAM cache.
                    if ch_id == str(getattr(self, "xtreamDirectEpgSelected", "") or ""):
                        if rows and self._applyXtreamShortEpgRows(rows, fallback, error):
                            return
                        self["epgNowTitle"].setText(tr("No EPG data"))
                        try: self["liveProgress"].setValue(0)
                        except Exception: pass
                        self["desc"].setText(fallback or tr(""))
                        return
                if inflight:
                    try: self.directEpgTimer.start(100, True)
                    except Exception: pass
                    return
                # No result/in-flight state: leave the neutral UI and let the
                # next selection refresh retry normally.
                return

        result = self.directEpgResult
        if result is None:
            try: self.directEpgTimer.start(120, False)
            except Exception: pass
            return
        self.directEpgResult = None
        token, rows, fallback, error = result
        if token != self.directEpgToken:
            return
        if self._applyXtreamShortEpgRows(rows, fallback, error):
            return
        self["epgNowTitle"].setText(tr("No EPG data"))
        self["desc"].setText(fallback or ("Provider EPG unavailable" if not error else "Provider EPG unavailable"))

    def _applyLocalEpgEvent(self, current, upcoming, fallback=""):
        now_ts = int(time.time())
        begin, duration, title, desc = current
        self["epgNowTime"].setText(self._formatEpgTime(begin, duration))
        self["epgNowTitle"].setText(title or "")
        elapsed = max(0, now_ts - int(begin))
        percent = min(100, max(0, int((elapsed * 100) / duration))) if duration > 0 else 0
        self["epgProgressText"].setText("%d%%" % percent)
        try: self["liveProgress"].setValue(percent)
        except Exception: pass
        self["desc"].setText((desc or fallback or "No programme description.")[:600])
        if upcoming:
            ub, ud, ut, _ = upcoming
            self["epgNextTime"].setText(self._formatEpgTime(ub, ud))
            self["epgNextTitle"].setText(ut or "")

    def _updateLiveEpg(self, item):
        """Provider-specific Live EPG; Stalker follows EStalker 1.45."""
        for key in ("epgNowTime", "epgNowTitle", "epgNextTime", "epgNextTitle", "epgProgressText"):
            try:
                self[key].setText(tr(""))
            except Exception:
                pass
        fallback = (item.get("plot") or item.get("description") or "").strip()

        if self.source.get("type") == "stalker":
            # EStalker uses portal short EPG for Stalker Live.
            if self._applyStalkerShortEpg(item, fallback):
                return
            try:
                self["liveProgress"].setValue(0)
                self["desc"].setText(tr(""))
            except Exception:
                pass
            return

        # r447: Xtream uses TiviMateE2's own HDD/USB XMLTV -> epg.json cache
        # first.  This is completely independent from EPGImport/eEPGCache.
        # r460: lookup is cache-only during Live navigation. It never starts
        # XMLTV download/build work while the user moves through channels.
        if self.source.get("type") == "xtream":
            try:
                current, upcoming = lookup_channel_epg(self.source, item, int(time.time()))
                if current:
                    self._applyLocalEpgEvent(current, upcoming, fallback)
                    return
            except Exception:
                pass
            # Provider-direct short_epg remains only as a compatibility
            # fallback for channels absent from the XMLTV/tvg-id cache.
            try:
                cached = self._xtreamCachedShortEpg(item, max_age=600)
                if cached and self._applyXtreamShortEpgRows(cached, fallback):
                    return
            except Exception:
                pass
            if self._startXtreamSelectedEpg(item, fallback):
                # r449: keep provider-direct refresh in the background, but do
                # not leave channels with no EPG stuck on a Loading state.
                # The existing completion callback will replace this neutral
                # state automatically if provider EPG arrives.
                self["epgNowTitle"].setText(tr("No EPG data"))
                try:
                    self["liveProgress"].setValue(0)
                except Exception:
                    pass
                self["desc"].setText(fallback or tr(""))
                return
        else:
            # Keep the legacy local/eEPG behavior for non-Xtream providers.
            try:
                current, upcoming = lookup_channel_epg(self.source, item, int(time.time()))
                if current:
                    self._applyLocalEpgEvent(current, upcoming, fallback)
                    return
            except Exception:
                pass

            try:
                cache = eEPGCache.getInstance()
                ref_string = epg_reference_string(self.source, item)
                events = ["IBDTEX", (ref_string, -1, -1, -1)]
                rows = [] if cache is None else (cache.lookupEvent(events) or [])
                if rows:
                    def event(row):
                        return (int(row[1] or 0), int(row[2] or 0), row[3] or "", row[4] or "")
                    current = event(rows[0])
                    upcoming = event(rows[1]) if len(rows) > 1 else None
                    self._applyLocalEpgEvent(current, upcoming, fallback)
                    return
            except Exception:
                pass

            if self._startDirectEpg(item, fallback):
                self["epgNowTitle"].setText(tr("Loading EPG..."))
                self["desc"].setText(fallback or tr("Loading programme information from the portal..."))
                return

        self["epgNowTitle"].setText(tr("No EPG data"))
        try:
            self["liveProgress"].setValue(0)
        except Exception:
            pass
        self["desc"].setText(fallback or tr(""))

    def _cleanLiveProgrammeTitle(self, title):
        value = str(title or "").strip()
        value = re.sub(r"\s*[\-–—:]?\s*[Ss]\d{1,2}[Ee]\d{1,3}.*$", "", value)
        value = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", "", value)
        value = re.sub(r"\s+", " ", value).strip(" -:|")
        return value

    def _scheduleLivePoster(self, item):
        self.livePosterToken += 1
        self._livePosterItem = dict(item or {})
        self.livePosterResult = None
        try: self.livePosterTimer.stop()
        except Exception: pass
        try: self.livePosterPoll.stop()
        except Exception: pass
        try: self["livePoster"].hide()
        except Exception: pass
        poster_enabled = str(self.source.get("show_live_poster", "0")).strip().lower() in ("1", "true", "yes", "on", "enabled")
        if not poster_enabled:
            return

        # A known programme must never wait for TMDb again.  Resolve its stable
        # URL from the tiny title index, then decode the already cached file
        # immediately.  Only a first-time title uses the delayed TMDb lookup.
        title = self._cleanLiveProgrammeTitle(self["epgNowTitle"].getText())
        key = _live_poster_key(title)
        poster_index = _load_live_poster_urls()
        url = poster_index.get(key, "") if key else ""
        # The full-screen Live infobar can discover a poster after this module
        # cached the index in RAM.  On a miss, refresh only this tiny JSON file
        # so the Live browser immediately reuses the infobar poster.
        if key and not url:
            try:
                with open_text(LIVE_POSTER_INDEX_FILE, "r") as handle:
                    disk_index = json.load(handle) or {}
                if isinstance(disk_index, dict):
                    fresh = str(disk_index.get(key) or "").strip()
                    if fresh:
                        poster_index[key] = fresh
                        url = fresh
            except Exception:
                pass
        token = self.livePosterToken
        if url:
            cached = cached_artwork(url, "live_tmdb_poster")
            if cached:
                self._showLivePosterPath(cached, token)
                return
            # The URL is known but its file was removed.  Re-fetch directly in
            # the artwork queue without repeating a TMDb search or 12s delay.
            def ready(path):
                self._showLivePosterPath(path, token)
            request_artwork(url, kind="posters", callback=ready, priority=55)
            return

        # First encounter: start the TMDb lookup almost immediately after the
        # EPG title arrives. A short debounce avoids firing requests while the
        # user is rapidly scrolling, but there is no long 12-second wait.
        try: self.livePosterTimer.start(350, True)
        except Exception: self.livePosterTimer.start(350)

    def _startLivePosterLookup(self):
        item = getattr(self, "_livePosterItem", {}) or {}
        title = self._cleanLiveProgrammeTitle(self["epgNowTitle"].getText())
        if not title or title in ("No EPG data", "Loading EPG..."):
            return
        token = self.livePosterToken
        def worker():
            url = ""
            try:
                client = TMDbClient()
                result = client.search_artwork(title, "vod", required_key="poster_path") or client.search_artwork(title, "series", required_key="poster_path")
                path = (result or {}).get("poster_path") or ""
                if path:
                    url = IMAGE_BASE + "w342" + path
            except Exception:
                pass
            self.livePosterResult = (token, url)
        t = threading.Thread(target=worker, name="TiviMateLivePosterTMDb")
        t.daemon = True
        t.start()
        try: self.livePosterPoll.start(250, False)
        except Exception: pass

    def _showLivePosterPath(self, path, token=None):
        if token is not None and token != self.livePosterToken:
            return
        if not path or not os.path.exists(path):
            return
        self.livePosterPath = path
        try:
            self.livePosterLoader.setPara((200, 300, 1, 1, False, 1, "#00000000"))
            self.livePosterLoader.startDecode(path)
        except Exception:
            pass

    def _finishLivePosterLookup(self):
        result = self.livePosterResult
        if result is None:
            try: self.livePosterPoll.start(250, False)
            except Exception: pass
            return
        self.livePosterResult = None
        token, url = result
        if token != self.livePosterToken or not url:
            return
        title = self._cleanLiveProgrammeTitle(self["epgNowTitle"].getText())
        key = _live_poster_key(title)
        if key:
            _save_live_poster_url(key, url)
        def ready(path):
            self._showLivePosterPath(path, token)
        request_artwork(url, kind="posters", callback=ready, priority=55)

    def _livePosterDecoded(self, picInfo=None):
        try:
            ptr = self.livePosterLoader.getData()
            if ptr is not None:
                self["livePoster"].instance.setPixmap(ptr)
                self["livePoster"].show()
        except Exception:
            pass

    def cancelAction(self):
        if self.kind == "live" and self.focus == "items":
            if self.source.get("type") == "stalker":
                self._cancelStalkerCatalogueRequests()
                self.stalkerLiveCancelEvent = threading.Event()
            self.focus = "category"
            self["list"].setList([])
            self["categoryTitle"].setText(tr("PACKAGES"))
            self["channelTitle"].setText(tr("Select a package"))
            self["meta"].setText(tr(""))
            self["desc"].setText(tr("Select a package") + " - OK")
            self._hideRowPicons()
            return
        if self.kind == "live":
            try:
                self.stalkerWatchdogTimer.stop()
            except Exception:
                pass
            self.stalkerWatchdogPending = False
            self.stalkerWatchdogClient = None
        self.close()

    def _hideRowPicons(self):
        return


    def _refreshVisibleRowPicons(self):
        return


    def _finishRowPicons(self):
        return


    def _rowPiconDecoded(self, idx):
        return


    def _updateLiveClock(self):
        try:
            self["clockTitle"].setText(time.strftime("%Y/%m/%d   %H:%M", time.localtime()))
        except Exception:
            pass

    def _visibleLiveItems(self):
        items = self.mediaItemsCurrent or []
        if not items:
            return []
        try:
            idx = self["list"].getSelectedIndex()
        except Exception:
            idx = 0
        start = max(0, min(idx - 4, max(0, len(items) - 10)))
        return items[start:start + 10]

    def _updateLiveKeys(self):
        if self.kind != "live":
            return
        try:
            self["styleHint"].setText("YELLOW  SWITCH SERVER  •  %s" % ("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "SERVER")))
        except Exception:
            pass

    def toggleAutoZap(self):
        if self.kind != "live": return
        self.channelSettings["auto_zap"] = not self.channelSettings.get("auto_zap", True)
        _save_channel_settings(self.channelSettings); self._updateLiveKeys()
        if self.channelSettings["auto_zap"]:
            try: self.zapTimer.stop()
            except Exception: pass
            self._autoZapCurrent()

    def toggleLivePicon(self):
        if self.kind != "live": return
        self.channelSettings["picon"] = not self.channelSettings.get("picon", True)
        _save_channel_settings(self.channelSettings); self._updateLiveKeys(); self.previewLive()

    def _zapLiveItem(self, item, force=False):
        if not item or self.kind != "live":
            return False
        try:
            def channel_identity(row):
                row = row or {}
                return str(
                    row.get("stream_id") or row.get("ch_id") or row.get("id") or
                    row.get("url") or row.get("cmd") or row.get("name") or ""
                ).strip()

            live_id = channel_identity(item)

            # Same currently playing channel = NO OP.
            # Must return before stream_url/create_link/playService.
            if not force and live_id:
                try:
                    shared_id = str((self.source or {}).get("_tivimate_current_live_id") or "").strip()
                    current_id = str(getattr(self, "lastZappedLiveId", "") or "").strip()
                    global_same = (
                        _CURRENT_LIVE_CHANNEL.get("source") == _source_identity(self.source) and
                        _CURRENT_LIVE_CHANNEL.get("channel") == live_id
                    )
                    if shared_id == live_id or current_id == live_id or global_same:
                        if self.session.nav.getCurrentlyPlayingServiceReference() is not None:
                            self.lastZappedLiveId = live_id
                            self.keepCurrentLiveService = True
                            return True
                except Exception:
                    pass

            play_source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
            if play_source.get("type") in ("xtream", "stalker"):
                url = get_source_client(play_source).stream_url(item, "live")
            elif play_source.get("type") in ("m3u", "fg"):
                url = item.get("url", "")
            else:
                url = ""
            if not url:
                return False

            service_type = (
                _xtream_service_type(play_source, "live")
                if play_source.get("type") == "xtream"
                else int(play_source.get("service_type", self.channelSettings.get("service_type", 4097)))
            )
            ref = live_reference(
                play_source, item, service_type, url,
                item.get("name") or item.get("title") or "IPTV"
            )
            self.session.nav.playService(ref)
            self.lastZappedLiveId = live_id
            self._playingLiveItem = dict(item or {})
            self._playingLiveUrl = str(url or "")
            _CURRENT_LIVE_CHANNEL["source"] = _source_identity(self.source)
            _CURRENT_LIVE_CHANNEL["channel"] = live_id
            try:
                self.source["_tivimate_current_live_id"] = live_id
            except Exception:
                pass
            self.keepCurrentLiveService = True
            self["meta"].setText(tr("Channel changed"))
            return True
        except Exception as exc:
            try:
                self["meta"].setText("Unable to change channel: %s" % exc)
            except Exception:
                pass
            return False


    def _stalkerPlaySource(self):
        if self.kind != "live":
            return None
        source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
        return source if isinstance(source, dict) else None

    def _startStalkerWatchdog(self):
        source = self._stalkerPlaySource()
        if not source or source.get("type") != "stalker":
            return
        try:
            self.stalkerWatchdogTimer.stop()
        except Exception:
            pass
        try:
            self.stalkerWatchdogTimer.start(30000, False)
        except Exception:
            pass

    def _runStalkerWatchdog(self):
        source = self._stalkerPlaySource()
        if not source or source.get("type") != "stalker":
            return
        try:
            active = self.session.nav.getCurrentlyPlayingServiceReference() is not None
        except Exception:
            active = False
        if not active or not getattr(self, "keepCurrentLiveService", False):
            try:
                self.stalkerWatchdogTimer.start(30000, False)
            except Exception:
                pass
            return
        if getattr(self, "stalkerWatchdogPending", False):
            try:
                self.stalkerWatchdogTimer.start(30000, False)
            except Exception:
                pass
            return

        self.stalkerWatchdogPending = True
        if self.stalkerWatchdogClient is None:
            try:
                self.stalkerWatchdogClient = get_source_client(source)
            except Exception:
                self.stalkerWatchdogClient = None

        client = self.stalkerWatchdogClient

        def worker():
            try:
                if client is not None:
                    client.watchdog()
            except Exception:
                pass
            self.stalkerWatchdogPending = False

        thread = threading.Thread(target=worker, name="TiviMateStalkerWatchdog")
        thread.daemon = True
        thread.start()
        try:
            self.stalkerWatchdogTimer.start(30000, False)
        except Exception:
            pass

    def restartCurrentLiveStream(self):
        """Manual restart for the active Stalker Live channel."""
        if self.kind != "live":
            return
        source = self._stalkerPlaySource()
        if not source or source.get("type") != "stalker":
            self.openBeinSports()
            return

        item = getattr(self, "_playingLiveItem", None) or self.current()
        if not item:
            try:
                self["meta"].setText(tr("No active channel to restart"))
            except Exception:
                pass
            return

        try:
            self["meta"].setText(tr("Restarting stream..."))
        except Exception:
            pass

        if self._zapLiveItem(dict(item), True):
            try:
                self["meta"].setText(tr("Stream restarted"))
            except Exception:
                pass
        else:
            try:
                self["meta"].setText(tr("Unable to restart stream"))
            except Exception:
                pass


    def _autoZapCurrent(self):
        if not self.channelSettings.get("auto_zap", True):
            return
        if self._isCurrentStalkerChannelLocked() and time.time() >= getattr(self, "stalkerPinUnlockedUntil", 0):
            return
        self._zapLiveItem(self.current(), False)

    def _showLivePicon(self, item):
        """One Live Picon path for every provider."""
        try:
            self._sidePiconReqId = int(getattr(self, "_sidePiconReqId", 0) or 0) + 1
        except Exception:
            self._sidePiconReqId = 1
        req_id = self._sidePiconReqId

        blank = os.path.join(PLUGIN_PATH, "skins", "common/transparent.png")
        try:
            if self["channelPicon"].instance and os.path.exists(blank):
                self["channelPicon"].instance.setPixmapFromFile(blank)
            self["channelPicon"].show()
        except Exception:
            pass

        item = item or {}
        url = str(
            item.get("stream_icon") or
            item.get("logo") or
            item.get("icon") or
            item.get("channel_icon") or
            item.get("picon") or
            ""
        ).strip().replace("\\/", "/")

        # General normalization for providers that return relative logo URLs.
        if url and not url.startswith(("http://", "https://")):
            try:
                base = str(
                    self.source.get("url") or
                    self.source.get("portal") or
                    self.source.get("host") or
                    self.source.get("server") or
                    ""
                ).strip().rstrip("/")

                if url.startswith("//"):
                    scheme = "https" if base.startswith("https://") else "http"
                    url = scheme + ":" + url
                elif url.startswith("/") and base:
                    url = base + url
                elif base:
                    url = base + "/" + url.lstrip("/")
            except Exception:
                pass

        if not url.startswith(("http://", "https://")):
            self._sidePiconPending = None
            return

        self._sidePiconPending = (req_id, url)
        try:
            self.livePiconTimer.stop()
            self.livePiconTimer.start(250, True)
        except Exception:
            self._finishLivePicon()

    def _finishLivePicon(self):
        pending = getattr(self, '_sidePiconPending', None)
        self._sidePiconPending = None
        if not pending:
            return

        req_id, url = pending
        if req_id != int(getattr(self, '_sidePiconReqId', 0) or 0):
            return

        def current_id():
            return int(getattr(self, '_sidePiconReqId', 0) or 0)

        def apply_path(path):
            if req_id != current_id() or not path:
                return
            try:
                if self['channelPicon'].instance:
                    self['channelPicon'].instance.setPixmapFromFile(path)
                    self['channelPicon'].show()
            except Exception:
                pass

        direct_picon(
            url,
            (220, 130),
            req_id,
            current_id,
            apply_path,
            prefix='xst_live_picon_'
        )

    def _livePiconDecoded(self, picInfo=None):
        return



    def renderPosterPage(self):
        self.downloads=[]; self.picloads=[]
        for slot in range(5):
            idx=self.pageStart+slot
            item=self.mediaItemsCurrent[idx] if idx < len(self.mediaItemsCurrent) else None
            self._setVisibleWidget("poster%d"%slot, bool(item))
            # r410: keep card chrome/details hidden until the poster itself is ready.
            # This removes the temporary gray metadata blocks during initial loading.
            self._setVisibleWidget("posterShell%d"%slot, False)
            self._setVisibleWidget("posterLabel%d"%slot, False)
            self._setVisibleWidget("posterRate%d"%slot, False)
            self["posterLabel%d"%slot].setText(((item.get("name") or item.get("title") or "")[:22]) if item else "")
            rate = ""
            if item:
                rate = item.get("rating") or item.get("rating_5based") or ""
                rate = str(rate)[:4]
            self["posterRate%d"%slot].setText(("★ " + rate) if rate else "")
            self._setPlaceholder(slot)
            if item:
                url=item.get("stream_icon") or item.get("cover") or item.get("movie_image") or item.get("poster_path") or ""
                if url:
                    # Package poster grid: reveal disk/RAM cached posters immediately.
                    # Do not send already-cached artwork back through the shared queue;
                    # that made the whole row appear together after a short wait.
                    cached = cached_artwork(url, "posters")
                    if cached:
                        self._poster_artwork_requests[slot] = (url or "").strip().replace("\\/", "/")
                        # r430: a cached provider URL is not proof that the cached
                        # file is a decodable poster. Some IPTV servers return a
                        # tiny error/HTML file which artwork_queue can still cache.
                        # Validate it before decode; if unusable, discard it and
                        # continue through the existing TMDb title fallback.
                        if self._posterFileUsable(cached):
                            self._decodeSlot(slot, cached, item)
                        else:
                            try:
                                if cached and os.path.exists(cached):
                                    os.remove(cached)
                            except Exception:
                                pass
                            self._tmdbPosterSlotFallback(slot, item)
                    else:
                        self._loadPosterSlot(slot, url, item)
                else:
                    self._tmdbPosterSlotFallback(slot, item)
        self._setVisibleWidget("selector", bool(self.mediaItemsCurrent))
        self.moveSelector(); self.previewVod()
        # Poster speed test: after the five visible cards are queued at high
        # priority, prefetch a bounded part of the current category in the
        # background. request_artwork deduplicates existing/running files and
        # keeps only four network transfers active, so navigation stays usable.
        self._prefetchCategoryPosters()

    def _prefetchCategoryPosters(self):
        if self.kind not in ("vod", "series"):
            return
        # Package grids only prefetch a small window around the current page.
        # Prefetching an entire large package can saturate disk/network and delays
        # the five posters the user is actually looking at. Cached files are skipped
        # by prefetch_artwork automatically.
        start = max(0, int(self.pageStart or 0))
        stop = min(len(self.mediaItemsCurrent or []), start + 15)
        urls = []
        for item in list((self.mediaItemsCurrent or [])[start:stop]):
            try:
                url = item.get("stream_icon") or item.get("cover") or item.get("movie_image") or item.get("poster_path") or ""
                if url:
                    urls.append(url)
            except Exception:
                pass
        prefetch_artwork(urls, "posters", priority=2)


    def _setVisibleWidget(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def _setPlaceholder(self, slot):
        try:
            placeholder = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/vod_circle_no_poster_r225.png" if getattr(self, "posterViewStyle", "original") == "circle" else "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_loading_transparent_r410.png"
            self["poster%d"%slot].instance.setPixmapFromFile(placeholder)
            if getattr(self, "posterViewStyle", "original") == "circle":
                try:
                    self["posterFocus%d" % slot].instance.setPixmapFromFile(placeholder)
                except Exception:
                    pass
        except Exception: pass

    def _posterFileUsable(self, path):
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, "rb") as fh:
                head = fh.read(12)
            return head.startswith(b"\xff\xd8\xff") or head.startswith(b"\x89PNG\r\n\x1a\n")
        except Exception:
            return False

    def _tmdbPosterSearchTitles(self, title):
        """Return safe ordered TMDb query variants for small Series/Movie posters.

        Keep the provider title untouched for display.  The full title is always
        searched first.  Some Arabic IPTV catalogs append a descriptive suffix
        such as "القصة الكاملة دراما: لعبة جهنم"; when that very specific
        mid-title marker is present, also try the text before "دراما:".
        Titles where "دراما" is a normal word (for example "دراما الحب")
        or appears at the start are never shortened.
        """
        raw = str(title or "").strip()
        if not raw:
            return []
        out = [raw]
        try:
            match = re.match(r"^(.+?)\s+دراما\s*:\s*(.+)$", raw, flags=re.UNICODE)
            if match:
                base = re.sub(r"\s+", " ", match.group(1)).strip(" -|:/._")
                suffix = re.sub(r"\s+", " ", match.group(2)).strip()
                # Be conservative: require a meaningful multi-word base and suffix.
                if base and suffix and len(base.split()) >= 2 and base not in out:
                    out.append(base)
        except Exception:
            pass
        return out

    def _tmdbPosterSlotFallback(self, slot, item):
        title = (item or {}).get("name") or (item or {}).get("title") or (item or {}).get("original_title") or ""
        if not title:
            return
        token = "%s:%s:%s" % (self.kind, str((item or {}).get("stream_id") or (item or {}).get("series_id") or ""), str(title))
        requests = getattr(self, "_poster_artwork_requests", None)
        if requests is None:
            requests = {}
            self._poster_artwork_requests = requests
        requests[slot] = token
        def worker():
            try:
                raw_year = (item or {}).get("year") or (item or {}).get("releaseDate") or (item or {}).get("releasedate") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                year = match.group(0) if match else None
                found = {}
                client = TMDbClient()
                for search_title in self._tmdbPosterSearchTitles(title):
                    found = client.search_artwork(search_title, self.kind, year, required_key="poster_path") or {}
                    if found.get("poster_path"):
                        break
                path = found.get("poster_path") or ""
                if not path:
                    return
                url = path if str(path).startswith(("http://", "https://")) else "https://image.tmdb.org/t/p/w500" + str(path)
                def apply():
                    if getattr(self, "_poster_artwork_requests", {}).get(slot) != token:
                        return
                    self._loadPosterSlot(slot, url, None)
                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass
        thread = threading.Thread(target=worker, name="TiviMateCategoryPosterTMDB")
        thread.daemon = True
        thread.start()

    def _loadPosterSlot(self, slot, url, fallback_item=None):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            if fallback_item is not None:
                self._tmdbPosterSlotFallback(slot, fallback_item)
            return
        requests = getattr(self, "_poster_artwork_requests", None)
        if requests is None:
            requests = {}
            self._poster_artwork_requests = requests
        requests[slot] = url

        def done(path, s=slot, expected=url, item=fallback_item):
            if getattr(self, "_poster_artwork_requests", {}).get(s) != expected:
                return
            if item is not None and not self._posterFileUsable(path):
                try:
                    if path and os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                self._tmdbPosterSlotFallback(s, item)
                return
            self._decodeSlot(s, path, item)

        def failed(_path, s=slot, item=fallback_item):
            if item is not None:
                self._tmdbPosterSlotFallback(s, item)

        request_artwork(url, "posters", done, priority=55, errback=failed if fallback_item is not None else None)

    def _decodeSlot(self, slot, path, fallback_item=None):
        loader=ePicLoad(); self.picloads.append(loader)
        def ready(_info=None, s=slot, l=loader, item=fallback_item):
            try:
                ptr = l.getData()
                if ptr and self["poster%d" % s].instance:
                    self["poster%d" % s].instance.setPixmap(ptr)
                    # Reveal the normal card shell/rating/title only with real artwork.
                    if getattr(self, "posterViewStyle", "original") != "circle":
                        self._setVisibleWidget("posterShell%d" % s, True)
                    self._setVisibleWidget("posterLabel%d" % s, True)
                    if str(self["posterRate%d" % s].getText() or "").strip():
                        self._setVisibleWidget("posterRate%d" % s, True)
                    if getattr(self, "posterViewStyle", "original") == "circle":
                        try:
                            if self["posterFocus%d" % s].instance:
                                self["posterFocus%d" % s].instance.setPixmap(ptr)
                        except Exception:
                            pass
                elif item is not None:
                    # r430: valid-looking files can still fail Enigma2 image
                    # decoding (unsupported/corrupt payload). Fall back to TMDb
                    # instead of leaving the small poster blank.
                    self._tmdbPosterSlotFallback(s, item)
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        connect_picture_data(loader, ready, self)
        if getattr(self, "posterViewStyle", "original") == "circle":
            # r217: fill the complete round poster surface. Keep aspect handling enabled
            # but use cover-style resize so the circle has no black side bars.
            render_width, render_height = scale_size(222, 222)
            loader.setPara((render_width,render_height,1,0,False,1,"#00000000"))
        else:
            render_width, render_height = scale_size(270, 380)
            # Original view keeps its existing exact-fill behaviour.
            loader.setPara((render_width,render_height,0,0,False,1,"#00000000"))
        loader.startDecode(path)

    def moveSelector(self):
        # r223: base posters never resize. A separate statically round-clipped
        # focused poster (242x242) is shown for the selected slot. This produces
        # a real grow effect without allowing rectangular corners to escape.
        try:
            circle_view = (getattr(self, "posterViewStyle", "original") == "circle")
            if self["selector"].instance:
                if circle_view:
                    x = int(self.POSTER_X[self.posterIndex])
                    y = int(getattr(self, "posterY", 610))
                    self["selector"].instance.move(ePoint(sx(x-18), sy(y-18)))
                    self["selector"].instance.resize(eSize(sx(258), sy(258)))
                else:
                    self["selector"].instance.move(ePoint(sx(self.POSTER_X[self.posterIndex]), sy(getattr(self, "posterY", 525))))
                self["selector"].show()
            for i in range(5):
                try:
                    selected = (i == self.posterIndex)
                    if circle_view:
                        fp = self["posterFocus%d" % i]
                        if selected:
                            fp.show()
                        else:
                            fp.hide()
                    label = self["posterLabel%d" % i].instance
                    if label:
                        label.setFont(gFont("Regular", max(16, sy(25 if selected and circle_view else 20))))
                        label.setForegroundColor(parseColor("#FFFFFF" if selected else "#D8DDE3"))
                    rate = self["posterRate%d" % i].instance
                    if rate:
                        rate.setForegroundColor(parseColor("#FFD34E" if selected else "#E7C85B"))
                except Exception:
                    pass
        except Exception:
            pass

    def scheduleSelectedInfo(self):
        if self.kind not in ("vod", "series") or self.source.get("type") not in ("xtream", "stalker"):
            return
        try: self.infoTimer.stop()
        except Exception: pass
        try: self.infoTimer.start(900, True)
        except Exception: self.loadSelectedInfo()

    def loadSelectedInfo(self):
        if SAFE_TABLE_MODE:
            return
        item = self.current()
        if not item:
            return
        mid = str(item.get("stream_id") or item.get("series_id") or "")
        if not mid:
            self._loadSelectedTmdbInfo(item)
            return
        key = self.kind + ":" + mid
        cached = self.fullInfoCache.get(key)
        if cached is not None:
            self.applySelectedInfo(mid, cached)
            return
        if key in self.infoProcesses:
            return
        try:
            if self.source.get("type") == "stalker":
                self._loadSelectedTmdbInfo(item)
                return
            client = XtreamClient(self.source)
            action = "get_vod_info" if self.kind == "vod" else "get_series_info"
            try:
                from urllib.parse import urlencode
            except ImportError:
                from urllib import urlencode
            url = client.base + "/player_api.php?" + urlencode({
                "username": client.user,
                "password": client.password,
                "action": action,
                ("vod_id" if self.kind == "vod" else "series_id"): mid,
            })
            cache_dir = get_cache_dir("metadata")
            try:
                ensure_dir(cache_dir)
            except Exception:
                pass
            path = os.path.join(cache_dir, "provider_info_" + hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")
            proc = eConsoleAppContainer()
            self.infoProcesses[key] = proc
            self.pendingInfoId = mid
            def done(ret, k=key, m=mid, p=path):
                self.infoProcesses.pop(k, None)
                if ret != 0 or not os.path.exists(p):
                    current = self.current()
                    if current:
                        self._loadSelectedTmdbInfo(current)
                    return
                try:
                    with open_text(p, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    self.fullInfoCache[k] = data or {}
                    self.applySelectedInfo(m, data or {})
                except Exception:
                    pass
            try:
                proc.appClosed.append(done)
            except Exception:
                proc.appClosed.get().append(done)
            proc.execute(PYTHON_EXECUTABLE, PYTHON_COMMAND, INFO_FETCH, url, path)
        except Exception:
            return

    def _loadSelectedTmdbInfo(self, item):
        """Enrich the selected movie/series from title alone when server info is sparse."""
        title = (item or {}).get("name") or (item or {}).get("title") or (item or {}).get("original_title") or ""
        if not title:
            return
        expected = "%s:%s" % (self.kind, title)
        self._tmdb_selected_token = expected
        def worker():
            try:
                raw_year = (item or {}).get("year") or (item or {}).get("releaseDate") or (item or {}).get("releasedate") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                year = match.group(0) if match else None
                client = TMDbClient()
                found = client.search_artwork(title, self.kind, year) or {}
                tid = found.get("id") or (item or {}).get("tmdb_id") or (item or {}).get("tmdb")
                bundle = client.details_bundle(tid, self.kind) if tid else found
                def apply():
                    if getattr(self, "_tmdb_selected_token", "") != expected:
                        return
                    current = self.current() or {}
                    current_title = current.get("name") or current.get("title") or current.get("original_title") or ""
                    if str(current_title) != str(title):
                        return
                    merged = dict(item or {})
                    data = bundle or {}
                    display_title = data.get("title") or data.get("name") or title
                    date = data.get("release_date") or data.get("first_air_date") or merged.get("year") or ""
                    rating = data.get("vote_average") or merged.get("rating") or ""
                    genres = ", ".join(x.get("name", "") for x in (data.get("genres") or [])[:3])
                    runtime = data.get("runtime") or ""
                    self["channelTitle"].setText(str(display_title))
                    self["meta"].setText("   ".join(x for x in [str(date)[:4], ("★ %s" % str(rating)[:4]) if rating else "", str(runtime), genres] if x))
                    self["desc"].setText((data.get("overview") or merged.get("plot") or merged.get("description") or "لا توجد أية معلومات")[:650])
                    back = data.get("backdrop_path") or ""
                    if back:
                        if not str(back).startswith(("http://", "https://")):
                            back = backdrop_url(str(back))
                        self.loadBackdrop(back)
                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass
        thread = threading.Thread(target=worker, name="TiviMateSelectedTMDB")
        thread.daemon = True
        thread.start()

    def applySelectedInfo(self, mid, data):
        current = self.current()
        current_id = str((current or {}).get("stream_id") or (current or {}).get("series_id") or "")
        if current_id != str(mid):
            return
        item = current or {}
        info = (data or {}).get("info") or {}
        movie = (data or {}).get("movie_data") or {}
        merged = {}
        merged.update(item)
        merged.update(movie)
        merged.update(info)
        title = merged.get("name") or merged.get("title") or ""
        year = merged.get("releasedate") or merged.get("releaseDate") or merged.get("year") or ""
        rating = merged.get("rating") or merged.get("rating_5based") or ""
        genre = merged.get("genre") or ""
        duration = merged.get("duration") or merged.get("duration_secs") or ""
        self["channelTitle"].setText(title)
        self["meta"].setText("   ".join(x for x in [str(year), ("★ %s" % rating) if rating else "", str(duration), str(genre)] if x))
        self["desc"].setText((merged.get("plot") or merged.get("description") or merged.get("overview") or "لا توجد أية معلومات")[:650])
        back = merged.get("backdrop_path") or merged.get("backdrop") or merged.get("backdrop_url") or []
        if isinstance(back, list):
            back = back[0] if back else ""
        if isinstance(back, str):
            back = back.strip().replace(chr(92) + "/", "/")
            if back.startswith("["):
                try:
                    arr = json.loads(back)
                    back = arr[0] if arr else ""
                except Exception:
                    pass
            if back.startswith("/") and not back.startswith("//"):
                back = backdrop_url(back)
        if back:
            self.loadBackdrop(back)
        else:
            self._loadSelectedTmdbInfo(merged)

    def _hideTitleLogo(self):
        if self.kind not in ("vod", "series"):
            return
        try:
            self["titleLogo"].hide()
        except Exception:
            pass

    def _tmdbLogoUrl(self, bundle):
        try:
            logos = ((bundle or {}).get("images") or {}).get("logos") or []
        except Exception:
            logos = []
        if not logos:
            return ""
        raster_logos = [x for x in logos if isinstance(x, dict) and str(x.get("file_path") or "").lower().endswith((".png", ".jpg", ".jpeg", ".webp"))]
        if not raster_logos:
            return ""
        wanted = str(getattr(TMDbClient(), "language", "") or "").split("-")[0].lower()
        # Prefer the device/TMDb language, then English, then language-neutral,
        # then any raster logo. TMDb title logos are normally transparent PNGs.
        def score(row):
            lang = str((row or {}).get("iso_639_1") or "").lower()
            ext = str((row or {}).get("file_path") or "").lower()
            raster = 1 if ext.endswith((".png", ".jpg", ".jpeg", ".webp")) else 0
            if lang and wanted and lang == wanted:
                pref = 4
            elif lang == "en":
                pref = 3
            elif not lang:
                pref = 2
            else:
                pref = 1
            vote = float((row or {}).get("vote_average") or 0)
            width = int((row or {}).get("width") or 0)
            return (raster, pref, vote, width)
        try:
            chosen = sorted(raster_logos, key=score, reverse=True)[0]
        except Exception:
            chosen = raster_logos[0] if raster_logos else {}
        path = str((chosen or {}).get("file_path") or "").strip()
        if not path:
            return ""
        if path.startswith(("http://", "https://")):
            return path
        if not path.startswith("/"):
            path = "/" + path
        return "https://image.tmdb.org/t/p/w500" + path

    def _loadSelectedTitleLogo(self, item):
        if self.kind not in ("vod", "series") or not getattr(self, "packageTitleLogoEnabled", False):
            self._hideTitleLogo()
            return
        row = dict(item or {})
        title = row.get("name") or row.get("title") or row.get("original_title") or row.get("original_name") or ""
        if not str(title or "").strip():
            self._titleLogoToken = ""
            self._hideTitleLogo()
            return
        media_id = str(row.get("stream_id") or row.get("series_id") or row.get("vod_id") or row.get("id") or "")
        token = "%s:%s:%s" % (self.kind, media_id, str(title))
        self._titleLogoToken = token
        self._hideTitleLogo()
        snapshot = dict(row)

        def worker():
            try:
                client = TMDbClient()
                tid = snapshot.get("tmdb_id") or snapshot.get("tmdb") or ""
                if not tid:
                    raw_year = " ".join(str(snapshot.get(k) or "") for k in ("year", "releaseDate", "releasedate", "release_date", "first_air_date", "name", "title"))
                    match = re.search(r"\b(?:19|20)\d{2}\b", raw_year)
                    year = match.group(0) if match else None
                    found = client.search_artwork(title, self.kind, year) or {}
                    tid = found.get("id") or ""
                if not tid or getattr(self, "_titleLogoToken", "") != token:
                    return
                bundle = client.details_bundle(tid, self.kind) or {}
                url = self._tmdbLogoUrl(bundle)
                if not url or getattr(self, "_titleLogoToken", "") != token:
                    return

                def downloaded(path, expected=token):
                    if getattr(self, "_titleLogoToken", "") != expected or not path:
                        return
                    self._decodeTitleLogo(path, expected)

                request_artwork(url, "logos", downloaded, priority=110)
            except Exception:
                pass

        thread = threading.Thread(target=worker, name="TiviMateTitleLogoTMDB")
        thread.daemon = True
        thread.start()

    def _decodeTitleLogo(self, path, token):
        if self.kind not in ("vod", "series") or not getattr(self, "packageTitleLogoEnabled", False) or getattr(self, "_titleLogoToken", "") != token:
            return
        loader = ePicLoad()
        self._titleLogoLoader = loader

        def ready(_info=None, expected=token, ref=loader):
            if getattr(self, "_titleLogoToken", "") != expected or self._titleLogoLoader is not ref:
                return
            try:
                ptr = ref.getData()
                if ptr and self["titleLogo"].instance:
                    self["titleLogo"].instance.setPixmap(ptr)
                    self["titleLogo"].show()
            except Exception:
                self._hideTitleLogo()

        connect_picture_data(loader, ready, self)
        width, height = scale_size(430, 180)
        loader.setPara((width, height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def loadBackdrop(self, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        self._media_backdrop_request = url

        def done(path, expected=url):
            if getattr(self, "_media_backdrop_request", "") != expected:
                return
            self.decodeBackdrop(path)

        request_artwork(url, "backdrops", done, priority=115)

    def decodeBackdrop(self, path):
        self.backdropLoader=ePicLoad()
        def ready(_info=None):
            try:
                ptr=self.backdropLoader.getData()
                if ptr and self["backdrop"].instance: self["backdrop"].instance.setPixmap(ptr)
            except Exception: pass
        connect_picture_data(self.backdropLoader, ready, self)
        render_width, render_height = scale_size(1920, 1080)
        self.backdropLoader.setPara((render_width,render_height,0,0,False,1,"#00000000"))
        self.backdropLoader.startDecode(path)

    def previewVod(self):
        item=self.current()
        if not item:
            self._titleLogoToken = ""
            self._hideTitleLogo()
            self["channelTitle"].setText(tr("No content")); self["meta"].setText(tr("")); self["desc"].setText(tr("")); self["nowLabel"].setText(tr("0/0")); return
        self._loadSelectedTitleLogo(item)
        title=item.get("name") or item.get("title") or ""
        year=item.get("releaseDate") or item.get("year") or ""; rating=item.get("rating") or item.get("rating_5based") or ""; genre=item.get("genre") or ""; dur=item.get("duration") or ""; typ=item.get("container_extension") or item.get("stream_type") or ""
        self["channelTitle"].setText(title)
        rating_text = ("★ " + str(rating)) if rating else ""
        self["meta"].setText("  •  ".join(x for x in [str(genre), rating_text, str(year), str(dur)] if x))
        self["desc"].setText((item.get("plot") or item.get("description") or "لا توجد أية معلومات")[:600])
        self["nowLabel"].setText("%d / %d" % (self.pageStart+self.posterIndex+1, len(self.mediaItemsCurrent)))
        self.scheduleSelectedInfo()


    def left(self):
        if self.focus == "top":
            self.topIndex = max(0, self.topIndex - 1)
            self._updateTopFocus()
            return

        if self.kind == "live":
            # LIVE is column-based:
            # Channels -> Packages -> left rail.
            # LEFT must never behave like UP.
            if self.focus == "items":
                self.cancelAction()
                return
            if self.focus == "category":
                self.focus = "rail"
                self._updateTopFocus()
                return
            if self.focus == "rail":
                return
            return

        # Movies / TV Shows: horizontal movement inside the poster row only.
        if self.focus != "items":
            return
        if self.posterIndex > 0:
            self.posterIndex -= 1
            self.moveSelector(); self.previewVod()
        elif self.pageStart >= 5:
            self.pageStart -= 5
            self.posterIndex = 4
            self.renderPosterPage()



    def right(self):
        if self.focus == "top":
            self.topIndex = min(len(self.topNames) - 1, self.topIndex + 1)
            self._updateTopFocus()
            return

        if self.kind == "live":
            # LIVE is column-based:
            # left rail -> Packages -> Channels.
            # RIGHT must never behave like DOWN.
            if self.focus == "rail":
                self.switchSection(self.currentRailSection())
                return
            if self.focus == "category":
                self.loadSelectedCategory()
                self.focus = "items"
                self._updateTopFocus()
                return
            if self.focus == "items":
                return
            return

        # Movies / TV Shows: horizontal movement inside the poster row only.
        if self.focus != "items":
            return
        if self.pageStart + self.posterIndex + 1 >= len(self.mediaItemsCurrent):
            return
        if self.posterIndex < 4:
            self.posterIndex += 1
            self.moveSelector(); self.previewVod()
        else:
            self.pageStart += 5
            self.posterIndex = 0
            self.renderPosterPage()


    def up(self):
        if self.kind == "live":
            if self.focus == "rail":
                self["rail"].up()
            elif self.focus == "category":
                self["category"].up()
            else:
                self["list"].up(); self.previewLive()
            return
        if self.focus == "items":
            self.focus = "top"
            self._updateTopFocus()


    def down(self):
        if self.kind == "live":
            if self.focus == "rail":
                self["rail"].down()
            elif self.focus == "category":
                self["category"].down()
            else:
                if self.source.get("type") == "xtream":
                    self._ensureXtreamNextLiveBatch()
                self["list"].down(); self.previewLive()
            return
        if self.focus == "top":
            self.focus = "items"
            self._updateTopFocus()
            self.moveSelector(); self.previewVod()


    def liveFastUp(self):
        if self.kind != "live":
            return
        widget = self["list"] if self.focus == "items" else self["category"]
        try:
            widget.pageDown()
        except Exception:
            pass
        if self.focus == "items":
            self.previewLive()

    def liveFastDown(self):
        if self.kind != "live":
            return
        widget = self["list"] if self.focus == "items" else self["category"]
        try:
            widget.pageUp()
        except Exception:
            pass
        if self.focus == "items":
            self.previewLive()


    def channelPageUp(self):
        if self.kind != "live" or self.focus != "items":
            return
        try: self["list"].pageUp()
        except Exception:
            for _ in range(10): self["list"].up()
        self.previewLive()

    def channelPageDown(self):
        if self.kind != "live" or self.focus != "items":
            return
        if self.source.get("type") == "xtream":
            self._ensureXtreamNextLiveBatch()
        try: self["list"].pageDown()
        except Exception:
            for _ in range(10): self["list"].down()
        self.previewLive()

    def pageUp(self):
        if self.kind != "live": return
        widget = self["list"] if self.focus == "items" else self["category"]
        try: widget.pageUp()
        except Exception:
            for _ in range(10): widget.up()
        if self.focus == "items": self.previewLive()

    def pageDown(self):
        if self.kind != "live": return
        widget = self["list"] if self.focus == "items" else self["category"]
        if self.focus == "items" and self.source.get("type") == "xtream":
            self._ensureXtreamNextLiveBatch()
        try: widget.pageDown()
        except Exception:
            for _ in range(10): widget.down()
        if self.focus == "items": self.previewLive()

    def openLiveSearch(self):
        if self.kind != "live":
            return
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard,
            title="Search channels", text=self.searchQuery or "")

    def openLiveFilter(self):
        if self.kind != "live":
            return
        self.session.openWithCallback(self._liveFilterClosed, ServerCategoryFilter, self.source)

    def _liveFilterClosed(self, changed=False):
        if not changed or self.kind != "live":
            return
        self.searchQuery = ""
        self.sortMode = "default"
        self.lastCategoryItems = []
        self.mediaItemsCurrent = []
        self.focus = "category"
        try:
            pass
        except Exception:
            pass
        self.loadCategories()

    def toggleLiveSort(self):
        if self.kind != "live":
            return
        modes = ["default", "name", "added"]
        try:
            position = modes.index(self.sortMode)
        except Exception:
            position = 0
        self.sortMode = modes[(position + 1) % len(modes)]
        items = list(self.lastCategoryItems or [])
        if self.searchQuery and not (self.source.get("type") == "stalker"):
            query = self.searchQuery.lower()
            items = [entry for entry in items if query in (entry.get("name") or entry.get("title") or "").lower()]
        if self.sortMode == "name":
            items.sort(key=lambda entry: (entry.get("name") or entry.get("title") or "").lower())
            label = "A-Z"
        elif self.sortMode == "added":
            def added_value(entry):
                try:
                    return int(float(entry.get("added") or entry.get("added_timestamp") or 0))
                except Exception:
                    return 0
            items.sort(key=added_value, reverse=True)
            label = "Added"
        else:
            label = "Original"
        try:
            self["meta"].setText("Sort: %s" % label)
        except Exception:
            pass
        self.showItems(items)


    def toggleSort(self):
        if self.kind == "live":
            self.toggleLiveSort()
            return
        modes = ["default", "name", "rating"]
        try:
            pos = modes.index(self.sortMode)
        except Exception:
            pos = 0
        self.sortMode = modes[(pos + 1) % len(modes)]
        items = list(self.mediaItemsCurrent or self.lastCategoryItems or [])
        if self.sortMode == "name":
            items.sort(key=lambda x: (x.get("name") or x.get("title") or "").lower())
            self["filterIcon"].setText(tr("Name"))
        elif self.sortMode == "rating":
            def rating_value(x):
                try:
                    return float(x.get("rating") or x.get("rating_5based") or 0)
                except Exception:
                    return 0
            items.sort(key=rating_value, reverse=True)
            self["filterIcon"].setText(tr("Rating"))
        else:
            items = list(self.lastCategoryItems or [])
            if self.searchQuery:
                q = self.searchQuery.lower()
                items = [x for x in items if q in (x.get("name") or x.get("title") or "").lower()]
            self["filterIcon"].setText(tr("Filter"))
        self.showItems(items)

    def openSearch(self):
        if self.kind == "live":
            return
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard, title="Search content", text=self.searchQuery or "")

    def searchCallback(self, value=None):
        if value is None:
            return
        value = (value or "").strip()
        self.searchQuery = value
        if not value:
            self.showItems(self.lastCategoryItems)
            return
        self.applySearch(value)

    def applySearch(self, value):
        q = (value or "").strip().lower()
        if self.kind == "live" and self.source.get("type") == "stalker" and q:
            # Match EStalker level-2 Search All: query the portal-wide channel
            # list rather than filtering only the currently opened bouquet.
            self.categoryLoadToken += 1
            token = self.categoryLoadToken
            self.categoryLoadResult = None
            try:
                self["meta"].setText("Search All...")
            except Exception:
                pass
            source = dict(self.source)
            def worker():
                try:
                    rows = StalkerClient(source).search_all_live(q)
                    self.categoryLoadResult = (token, rows, "stalker_search_all", "", "Search All")
                except Exception as exc:
                    self.categoryLoadResult = (token, [], "error", str(exc), "Search All")
            t = threading.Thread(target=worker, name="TiviMateStalkerSearchAll")
            t.daemon = True
            t.start()
            try:
                self.categoryLoadTimer.start(120, False)
            except Exception:
                pass
            return

        items = []
        for x in (self.lastCategoryItems or []):
            name = (x.get("name") or x.get("title") or "").lower()
            plot = (x.get("plot") or x.get("description") or "").lower()
            if q in name or q in plot:
                items.append(x)
        self.showItems(items)
        try:
            caption = self["currentCategory"].getText() or ""
            if q:
                self["currentCategory"].setText((caption.split("  •  ")[0] if "  •  " in caption else caption) + "  •  Search")
        except Exception:
            pass

    def _cleanupLiveTempPicons(self):
        # Live-only exit cleanup: remove only temporary picon files created by
        # Live list / infobar. Persistent picon cache, EPG and all VOD artwork
        # stay untouched.
        prefixes = ("xst_live_picon_", "tivimate_infobar_picon_")
        folders = []
        try:
            folders.append(get_cache_dir("tmp"))
        except Exception:
            pass
        # Older builds used either spelling; keep cleanup compatible without
        # deleting the directory itself or unrelated temporary files.
        folders.extend((
            "/hdd/.tivimatee2_cache/tmp",
            "/media/hdd/.tivimatee2_cache/tmp",
            "/hdd/.tivimatee2-cache/tmp",
            "/media/hdd/.tivimatee2-cache/tmp",
        ))
        seen = set()
        for folder in folders:
            try:
                folder = str(folder or "").strip()
                if not folder:
                    continue
                real = os.path.realpath(folder)
                if real in seen or not os.path.isdir(real):
                    continue
                seen.add(real)
                for name in os.listdir(real):
                    if not any(name.startswith(prefix) for prefix in prefixes):
                        continue
                    path = os.path.join(real, name)
                    if os.path.isfile(path):
                        try:
                            os.remove(path)
                        except Exception:
                            pass
            except Exception:
                pass

    def close(self, *args, **kwargs):
        if self.kind == "live":
            try:
                self.zapTimer.stop(); self.livePiconTimer.stop(); self.rowPiconTimer.stop(); self.directEpgTimer.stop()
                self._cleanupLiveTempPicons()
                if self.oldService: self.session.nav.playService(self.oldService)
            except Exception:
                pass
        return Screen.close(self, *args, **kwargs)

    def livePlayerClosed(self, result=None):
        index = None
        live_id = ""
        try:
            if isinstance(result, (tuple, list)) and len(result) >= 2:
                index = result[0]
                live_id = str(result[1] or "").strip()
            else:
                index = result
        except Exception:
            index = result

        try:
            if self.mediaItemsCurrent:
                # Keep the Live browser on the channel that is actually playing.
                # The full-screen player may move well beyond the first Xtream
                # 15-row lazy batch, so resolve the returned channel identity
                # against the full in-RAM bouquet before restoring the cursor.
                resolved_index = None
                if live_id:
                    for pos, row in enumerate(self.mediaItemsCurrent):
                        row = row or {}
                        row_id = str(
                            row.get("stream_id") or row.get("ch_id") or row.get("id") or
                            row.get("url") or row.get("cmd") or row.get("name") or ""
                        ).strip()
                        if row_id == live_id:
                            resolved_index = pos
                            break
                if resolved_index is None and index is not None:
                    resolved_index = max(0, min(int(index), len(self.mediaItemsCurrent) - 1))
                if resolved_index is not None:
                    index = resolved_index
                    if self.source.get("type") == "xtream":
                        # Rebuild only enough of the existing lazy list to make
                        # the playing channel visible; no new catalogue request.
                        batch = max(1, int(getattr(self, "xtreamLiveBatchSize", 15) or 15))
                        needed = min(len(self.mediaItemsCurrent), ((index // batch) + 1) * batch)
                        if int(getattr(self, "xtreamLiveLoadedCount", 0) or 0) < needed:
                            self.xtreamLiveLoadedCount = needed
                            self._renderXtreamLiveBatch(index, ensure_next=False)
                        else:
                            self["list"].moveToIndex(index)
                    else:
                        self["list"].moveToIndex(index)
                    if not live_id:
                        item = self.mediaItemsCurrent[index] or {}
                        live_id = str(
                            item.get("stream_id") or item.get("ch_id") or item.get("id") or
                            item.get("url") or item.get("cmd") or item.get("name") or ""
                        ).strip()

                self._playingLiveIndex = index
                self._playingLiveId = live_id
                if live_id:
                    self.lastZappedLiveId = live_id
                    self.keepCurrentLiveService = True
                    try:
                        self.source["_tivimate_current_live_id"] = live_id
                        _CURRENT_LIVE_CHANNEL["source"] = _source_identity(self.source)
                        _CURRENT_LIVE_CHANNEL["channel"] = live_id
                    except Exception:
                        pass

                # Refresh only EPG/Picon preview. Same-channel auto-zap is blocked below.
                self.previewLive()
        except Exception:
            pass

        try:
            self.show()
        except Exception:
            pass


    def _openLockedCategoryNow(self):
        self.loadSelectedCategory()
        self.focus = "items"

    def _reopenCurrentLivePlayer(self):
        try:
            index = self["list"].getSelectedIndex()
        except Exception:
            index = 0
        self._playingLiveIndex = index
        try:
            item = self.mediaItemsCurrent[index] or {}
            self._playingLiveId = str(
                item.get("stream_id") or item.get("ch_id") or item.get("id") or
                item.get("url") or item.get("cmd") or item.get("name") or ""
            ).strip()
        except Exception:
            self._playingLiveId = ""
        self.keepCurrentLiveService = True
        try:
            self.zapTimer.stop()
        except Exception:
            pass
        play_source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
        self.session.openWithCallback(
            self.livePlayerClosed, TiviMateLivePlayer,
            play_source, list(self.mediaItemsCurrent or []), index, True
        )

    def _openLivePlayerNow(self):
        try:
            index = self["list"].getSelectedIndex()
        except Exception:
            index = 0
        self._playingLiveIndex = index
        try:
            start_item = self.mediaItemsCurrent[index] or {}
            self._playingLiveId = str(
                start_item.get("stream_id") or start_item.get("ch_id") or start_item.get("id") or
                start_item.get("url") or start_item.get("cmd") or start_item.get("name") or ""
            ).strip()
        except Exception:
            self._playingLiveId = ""
        self.keepCurrentLiveService = True
        try:
            self.zapTimer.stop()
        except Exception:
            pass
        play_source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
        self.session.openWithCallback(self.livePlayerClosed, TiviMateLivePlayer,
                                      play_source, list(self.mediaItemsCurrent or []), index)

    def playerClosed(self, *args):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        try:
            self.show()
        except Exception:
            pass

    def ok(self):
        if self.focus == "top":
            self._openTopItem(); return
        if self.focus == "rail":
            self.switchSection(self.currentRailSection())
            return
        if self.focus=="category":
            if self.kind == "live" and self._isCurrentStalkerCategoryLocked() and time.time() >= getattr(self, "stalkerPinUnlockedUntil", 0):
                self._requestStalkerPin(("category", None)); return
            self.loadSelectedCategory(); self.focus="items"; return
        item=self.current()
        if not item: return
        if self.kind == "live":
            if getattr(self, "catchupPackageActive", False):
                if self.source.get("type") == "stalker":
                    self._openStalkerCatchup()
                elif self.source.get("type") == "xtream":
                    self._openXtreamCatchup()
                return
            if self._isCurrentStalkerChannelLocked() and time.time() >= getattr(self, "stalkerPinUnlockedUntil", 0):
                self._requestStalkerPin(("play", None)); return

            # Explicit OK must always attempt a real channel start.
            # Do not reuse the current service merely because IDs/index match:
            # Enigma2 can still hold a service reference after the stream died.
            self._openLivePlayerNow(); return
        try:
            # Re-detect the platform from the active SERVER package at the
            # exact moment we open details. This guarantees the provider mark
            # survives even if the cached row was created before filtering.
            detail_item = dict(item or {})
            package_name = str(getattr(self, "activeCategoryName", "") or
                               getattr(self, "initialCategoryName", "") or
                               detail_item.get("_server_package_name") or "")
            provider = str(getattr(self, "activePackageProvider", "") or
                           detail_item.get("_server_package_provider") or
                           detail_item.get("_tmdb_provider") or "").strip().lower()
            if not provider:
                provider = self._providerFromPackageName(package_name)
            if provider:
                detail_item["_tmdb_provider"] = provider
                detail_item["_server_package_provider"] = provider
                detail_item["_server_package_name"] = package_name

            if self.kind == "series":
                _series_restart_log("MEDIA_OK_BEFORE_OPEN", detail_item, "category=%s" % str(package_name))
                self.session.open(SeriesDetailsScreen, self.source, detail_item)
                _series_restart_log("MEDIA_OK_AFTER_OPEN", detail_item)
                return

            if self.kind == "vod":
                # Server-package movies now open the SAME rich details page
                # used elsewhere (poster, metadata, actors, recommendations).
                # RECENT ADDED alone uses the user's saved movie-package filter
                # as its random recommendation pool. Normal packages are unchanged.
                _selected_cid=str(self.selectedCategory() or "").strip()
                _is_recent=(_selected_cid == "__recent_added__")
                _cid="" if _is_recent else str(detail_item.get("_source_category_id") or _selected_cid or "").strip()
                _scope="movies_recent_filtered" if _is_recent else "movies_package"
                detail_item["_source_scope"]=_scope
                detail_item["_source_server_id"]=_source_identity(self.source)
                if _cid:
                    detail_item["_source_category_id"]=_cid
                elif _is_recent:
                    detail_item.pop("_source_category_id", None)
                self.session.open(
                    MovieDetailsScreen,
                    self.source,
                    detail_item,
                    list(self.mediaItemsCurrent or []),
                    {"scope":_scope,"category_id":_cid,"items":list(self.mediaItemsCurrent or [])}
                )
                return

            # Non-VOD/Series fallback.
            if self.source.get("type") in ("xtream", "stalker"):
                url=get_source_client(self.source).stream_url(detail_item,self.kind)
            elif self.source.get("type")=="m3u":
                url=detail_item.get("url","")
            else:
                url=""
            if not url:
                raise Exception("لا يوجد رابط تشغيل")
            service_type = _stalker_service_type(self.source, self.kind) if self.source.get("type") == "stalker" else 4097
            service=eServiceReference(service_type,0,url)
            service.setName(detail_item.get("name") or detail_item.get("title") or "IPTV")
            detail_item["_source_type"] = self.source.get("type", "")
            detail_item["_source_key"] = _source_identity(self.source)
            detail_item["_kind"] = self.kind
            self.session.openWithCallback(self.playerClosed, TiviMatePlayer, service, detail_item)
        except Exception as e:
            self.session.open(MessageBox,"تعذر التشغيل:\n%s"%e,MessageBox.TYPE_ERROR)



FAVOURITES_SKIN = '''<screen name="TiviMateFavorites" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#10151D">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#10151D" zPosition="0" />
    <eLabel position="0,0" size="1920,108" backgroundColor="#182330" zPosition="1" />
    <eLabel position="0,107" size="1920,2" backgroundColor="#65D7F3" zPosition="2" />
    <widget name="title" position="72,24" size="600,60" font="Regular;42" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="filter" position="1350,35" size="500,42" font="Regular;25" foregroundColor="#8EE7FF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
    <widget name="featuredTitle" position="75,160" size="1050,54" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="status" position="75,216" size="1725,52" font="Regular;25" foregroundColor="#C7D3DF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="75,278" size="1725,34" text="TIP: ON A MOVIE OR TV SHOW POSTER, HOLD YELLOW TO ADD TO FAVORITES" font="Regular;21" foregroundColor="#FFE383" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="list" position="-20,-20" size="1,1" itemHeight="1" scrollbarMode="showNever" />
    <widget name="poster0" position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle0" position="105,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster1" position="367,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="367,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle1" position="367,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster2" position="629,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="629,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle2" position="629,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster3" position="891,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="891,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle3" position="891,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster4" position="1153,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="1153,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle4" position="1153,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster5" position="1415,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="1415,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle5" position="1415,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="posterSelector" position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/favorites_focus_r121.png" alphatest="blend" zPosition="12" />
    <eLabel position="0,936" size="1920,144" backgroundColor="#182330" zPosition="2" />
    <eLabel position="72,966" size="330,50" text="OK  OPEN / PLAY" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="455,966" size="305,50" text="RED  REMOVE" font="Regular;25" foregroundColor="#FF8A87" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="825,966" size="350,50" text="YELLOW  FILTER" font="Regular;25" foregroundColor="#FFE383" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="1240,966" size="340,50" text="BLUE  REFRESH" font="Regular;25" foregroundColor="#8EE7FF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="1640,966" size="220,50" text="EXIT  BACK" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
    <widget name="keys" position="75,1026" size="1770,34" font="Regular;21" foregroundColor="#9EAFBF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
</screen>'''

FAVOURITES_SKIN = scale_skin(FAVOURITES_SKIN)


class FavoritesScreen(Screen):
    """Full-screen local Favorite library for live channels, movies, and series."""
    skin = FAVOURITES_SKIN
    FILTERS = ((tr("ALL"), ""), (tr("LIVE"), "live"), (tr("MOVIES"), "vod"), (tr("TV SHOWS"), "series"))
    KIND_LABELS = {"live": tr("LIVE"), "vod": tr("MOVIE"), "series": tr("SERIES")}
    POSTER_X = (105, 367, 629, 891, 1153, 1415)
    POSTER_Y = 344
    PAGE_SIZE = 6

    def __init__(self, session):
        Screen.__init__(self, session)
        self.filterIndex = 0
        self.records = []
        self.pageStart = 0
        self.posterIndex = 0
        self.picloads = []
        self._poster_artwork_requests = {}
        self["title"] = Label(tr("Favorite"))
        self["filter"] = Label("")
        self["featuredTitle"] = Label(tr("YOUR SAVED CONTENT"))
        self["list"] = MenuList([])
        self["status"] = Label("")
        self["keys"] = Label(tr("ARROWS  SELECT POSTER     •     HOLD YELLOW ON A MOVIE / TV SHOW POSTER  =  ADD TO FAVORITES"))
        for slot in range(self.PAGE_SIZE):
            self["poster%d" % slot] = Pixmap()
            self["posterTitle%d" % slot] = Label("")
        self["posterSelector"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "ok": self.openCurrent, "cancel": self.close,
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "red": self.removeCurrent, "yellow": self.nextFilter, "blue": self.reload,
            "menu": self.nextFilter
        }, -1)
        self.onLayoutFinish.append(self.reload)

    def _currentRecord(self):
        index = self.pageStart + self.posterIndex
        if 0 <= index < len(self.records):
            return self.records[index]
        return None

    def _setVisible(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def _setPlaceholder(self, slot):
        try:
            self["poster%d" % slot].instance.setPixmapFromFile(
                "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png"
            )
        except Exception:
            pass

    def _recordTitle(self, record):
        item = record.get("item") or {}
        return item.get("name") or record.get("title") or item.get("title") or "IPTV"

    def _recordArtwork(self, record):
        item = record.get("item") or {}
        return item.get("stream_icon") or item.get("cover") or item.get("movie_image") or item.get("cover_big") or ""

    def reload(self):
        label, kind = self.FILTERS[self.filterIndex]
        self.records = list_favourites(kind or None)
        self.pageStart = 0
        self.posterIndex = 0
        rows = [(self._recordTitle(record), record) for record in self.records]
        self["list"].setList(rows)
        self["filter"].setText("%s: %s" % (tr("Filter"), label))
        self.renderPosterPage()

    def renderPosterPage(self):
        for slot in range(self.PAGE_SIZE):
            index = self.pageStart + slot
            record = self.records[index] if index < len(self.records) else None
            self._setVisible("poster%d" % slot, bool(record))
            self._setVisible("posterTitle%d" % slot, bool(record))
            if not record:
                try:
                    self["posterTitle%d" % slot].setText(tr(""))
                except Exception:
                    pass
                continue
            title = self._recordTitle(record)
            kind = self.KIND_LABELS.get(record.get("kind"), "IPTV")
            self["posterTitle%d" % slot].setText(("%s\n%s" % (kind, title))[:42])
            self._setPlaceholder(slot)
            artwork = self._recordArtwork(record)
            if artwork:
                self._loadPoster(slot, artwork)
            else:
                self._loadFavouriteTmdbPoster(slot, record)
        prefetch_artwork([self._recordArtwork(record) for record in list(self.records or []) if self._recordArtwork(record)], "posters", priority=2)
        self._setVisible("posterSelector", bool(self.records))
        self._moveSelector()
        self._updateStatus()

    def _loadFavouriteTmdbPoster(self, slot, record):
        item = (record or {}).get("item") or {}
        title = self._recordTitle(record or {})
        kind = "series" if (record or {}).get("kind") == "series" else "vod"
        if not title:
            return
        token = "tmdb:%s:%s" % (kind, title)
        self._poster_artwork_requests[slot] = token
        def worker():
            try:
                raw_year = item.get("year") or item.get("releaseDate") or item.get("releasedate") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                found = TMDbClient().search_artwork(title, kind, match.group(0) if match else None, required_key="poster_path") or {}
                path = found.get("poster_path") or ""
                if not path:
                    return
                url = path if str(path).startswith(("http://", "https://")) else "https://image.tmdb.org/t/p/w500" + str(path)
                def apply():
                    if self._poster_artwork_requests.get(slot) != token:
                        return
                    self._loadPoster(slot, url)
                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass
        thread = threading.Thread(target=worker, name="TiviMateFavouriteTMDB")
        thread.daemon = True
        thread.start()

    def _loadPoster(self, slot, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        self._poster_artwork_requests[slot] = url
        def done(path, s=slot, expected=url):
            if self._poster_artwork_requests.get(s) != expected:
                return
            self._decodePoster(s, path)
        request_artwork(url, "posters", done, priority=55)

    def _decodePoster(self, slot, path):
        loader = ePicLoad()
        self.picloads.append(loader)
        def ready(_info=None, s=slot, current=loader):
            try:
                ptr = current.getData()
                if ptr and self["poster%d" % s].instance:
                    self["poster%d" % s].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if current in self.picloads:
                    self.picloads.remove(current)
            except Exception:
                pass
        try:
            connect_picture_data(loader, ready, self)
        except Exception:
            try:
                loader.PictureData.connect(ready)
            except Exception:
                pass
        try:
            render_width, render_height = scale_size(230, 300)
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
            loader.startDecode(path)
        except Exception:
            pass

    def _moveSelector(self):
        if not self.records:
            return
        try:
            self["posterSelector"].instance.move(ePoint(sx(self.POSTER_X[self.posterIndex]), sy(self.POSTER_Y)))
            self["posterSelector"].show()
        except Exception:
            pass

    def _updateStatus(self):
        total = len(self.records)
        record = self._currentRecord()
        if not record:
            self["status"].setText(tr("No saved items in this filter. Open a title and choose Add to My List."))
            return
        title = self._recordTitle(record)
        kind = self.KIND_LABELS.get(record.get("kind"), "IPTV")
        self["status"].setText("%s  •  %s     %d / %d" % (kind, title, self.pageStart + self.posterIndex + 1, total))

    def left(self):
        index = self.pageStart + self.posterIndex
        if index <= 0:
            return
        index -= 1
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def right(self):
        index = self.pageStart + self.posterIndex
        if index >= len(self.records) - 1:
            return
        index += 1
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def up(self):
        index = self.pageStart + self.posterIndex
        if index < self.PAGE_SIZE:
            return
        index -= self.PAGE_SIZE
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def down(self):
        index = self.pageStart + self.posterIndex
        if index + self.PAGE_SIZE >= len(self.records):
            return
        index += self.PAGE_SIZE
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def nextFilter(self):
        self.filterIndex = (self.filterIndex + 1) % len(self.FILTERS)
        self.reload()

    def removeCurrent(self):
        record = self._currentRecord()
        if not record:
            return
        if remove_record(record.get("id", "")):
            self.reload()
        else:
            self["status"].setText(tr("Unable to remove this Favorite."))

    def openCurrent(self):
        record = self._currentRecord()
        if not record:
            return
        source = source_for_record(record, get_sources())
        if not source:
            self.session.open(MessageBox, "This item's source no longer exists. Press RED to remove it.", MessageBox.TYPE_INFO); return
        item = dict(record.get("item") or {})
        kind = record.get("kind")
        try:
            if kind == "live":
                self.session.open(TiviMateLivePlayer, source, [item], 0); return
            if kind == "series":
                if source.get("type") != "xtream":
                    raise Exception("Series require an Xtream Codes source")
                self.session.open(SeriesDetailsScreen, source, item); return
            if source.get("type") == "xtream":
                url = XtreamClient(source).stream_url(item, "vod")
            elif source.get("type") in ("m3u", "fg"):
                url = item.get("url", "")
            else:
                url = StalkerClient(source).stream_url(item, "vod")
            if not url:
                raise Exception("No playable URL")
            service_type = int(_media_service_type(source, "vod"))
            service = eServiceReference(service_type, 0, url)
            service.setName(item.get("name") or item.get("title") or "IPTV")
            self.session.open(TiviMatePlayer, service, item); return
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open Favorite:\n%s" % exc, MessageBox.TYPE_ERROR)

