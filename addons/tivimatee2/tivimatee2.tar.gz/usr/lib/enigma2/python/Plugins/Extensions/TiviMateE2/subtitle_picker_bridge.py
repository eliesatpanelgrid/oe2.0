# -*- coding: utf-8 -*-
"""Open the active SubsSupport subtitle-line picker without reopening search.

This bridge intentionally works with the exact SubsSupport object that owns the
currently rendered external subtitle.  It does not create a new subtitle
session, does not restart playback, and does not touch server/player settings.
"""


def _iter_dialogs(session):
    seen = set()
    current = getattr(session, "current_dialog", None)
    if current is not None:
        seen.add(id(current))
        yield current
    for entry in reversed(getattr(session, "dialog_stack", []) or []):
        dialog = entry[0] if isinstance(entry, (tuple, list)) and entry else entry
        if dialog is not None and id(dialog) not in seen:
            seen.add(id(dialog))
            yield dialog


def _try_native_pro_picker(owner, session):
    """Use the active Pro/regular controller that owns the loaded subtitle."""
    candidates = []
    for name in ("_subspro_controller", "_subssupportpro_controller", "_subssupportpro"):
        obj = getattr(owner, name, None)
        if obj is not None:
            candidates.append(obj)
            for child_name in ("controller", "subsController", "subsScreen"):
                child = getattr(obj, child_name, None)
                if child is not None:
                    candidates.append(child)
    candidates.extend(list(_iter_dialogs(session)))

    seen = set()
    for dialog in candidates:
        if dialog is None or id(dialog) in seen:
            continue
        seen.add(id(dialog))
        for name in ("openSubtitleProPicker", "openSubtitlePicker"):
            fn = getattr(dialog, name, None)
            if callable(fn):
                try:
                    fn()
                    return True
                except Exception:
                    pass
    return False


def _regular_engine(support):
    if support is None:
        return None
    # Official SubsSupport 1.8 stores the active engine in this private field.
    engine = getattr(support, "_SubsSupport__subsEngine", None)
    if engine is not None:
        return engine
    # Compatibility aliases used by some image-specific builds.
    for name in ("subsEngine", "_subsEngine", "engine"):
        engine = getattr(support, name, None)
        if engine is not None and hasattr(engine, "subsList"):
            return engine
    return None


def _align_regular_engine(engine, index):
    try:
        index = int(index)
        subs = list(getattr(engine, "subsList", None) or [])
        if index < 0 or index >= len(subs):
            return
        try:
            engine.stopTimers()
        except Exception:
            pass
        engine.position = index
        engine.sub = subs[index]

        def apply_delay():
            try:
                pts = getattr(engine, "_SubsEngine__pts", None)
                if pts is not None:
                    ratio = float(getattr(engine, "subsFpsRatio", 1) or 1)
                    start_pts = int(float(subs[index].get("start", 0)) * ratio)
                    delay_ms = int((int(pts) - start_pts) / 90)
                    engine.setSubsDelay(delay_ms)
                engine.position = index
                engine.sub = subs[index]
                engine.play()
            except Exception:
                try:
                    engine.play()
                except Exception:
                    pass

        getter = getattr(engine, "getPlayPts", None)
        if callable(getter):
            getter(apply_delay)
        else:
            apply_delay()
    except Exception:
        pass


def open_active_subtitle_picker(owner, supports):
    """Open Select Current Subtitle Line for the currently rendered subtitle.

    Returns True when a picker was opened, otherwise False.
    """
    session = getattr(owner, "session", None)
    if session is None:
        return False

    if _try_native_pro_picker(owner, session):
        return True

    for support in supports:
        engine = _regular_engine(support)
        subs = list(getattr(engine, "subsList", None) or []) if engine is not None else []
        if not subs:
            continue
        try:
            from Plugins.Extensions.SubsSupport.subtitlesdvb import SubtitlePicker
            current = int(getattr(engine, "position", 0) or 0)
            current = max(0, min(current, len(subs) - 1))
            session.openWithCallback(
                lambda index=None, e=engine: _align_regular_engine(e, index) if index is not None else None,
                SubtitlePicker,
                subs,
                current,
            )
            return True
        except Exception:
            continue
    return False




def apply_playback_position(owner, elapsed_seconds):
    """Compatibility helper for VOD subtitle engines.

    SubsSupport regular engines follow the movie service PTS themselves. A
    previous implementation converted the complete movie elapsed time into a
    negative subtitle delay; on several images that hid every subtitle line.
    Keep only the safe SubsSupportPro absolute seek path and use the regular
    support object's official playAfterSeek() operation.
    """
    try:
        elapsed_ms = max(0, int(float(elapsed_seconds or 0) * 1000))
    except Exception:
        elapsed_ms = 0
    applied = False
    session = getattr(owner, "session", None)
    candidates = []
    for name in ("_subspro_controller", "_subssupportpro_controller", "_subssupportpro"):
        obj = getattr(owner, name, None)
        if obj is not None:
            candidates.append(obj)
            for child_name in ("controller", "subsController", "subsScreen"):
                child = getattr(obj, child_name, None)
                if child is not None:
                    candidates.append(child)
    if session is not None:
        candidates.extend(list(_iter_dialogs(session)))
    seen = set()
    for obj in candidates:
        if obj is None or id(obj) in seen:
            continue
        seen.add(id(obj))
        engine = getattr(obj, "engine", None) or getattr(obj, "_SubsProSupport__subsEngine", None)
        seek = getattr(engine, "seekTo", None) if engine is not None else None
        if elapsed_ms > 0 and callable(seek) and getattr(engine, "subsList", None):
            try:
                seek(elapsed_ms)
                applied = True
                break
            except Exception:
                pass
    for support_name in ("_external_subs", "_subssupport"):
        support = getattr(owner, support_name, None)
        sync = getattr(support, "playAfterSeek", None) if support is not None else None
        if callable(sync):
            try:
                sync()
                applied = True
            except Exception:
                pass
    return applied

def _apply_live_epg_offset(owner, elapsed_seconds):
    """Align a loaded subtitle to the elapsed time of the current EPG event."""
    try:
        elapsed_ms = max(0, int(float(elapsed_seconds or 0) * 1000))
    except Exception:
        elapsed_ms = 0
    if elapsed_ms <= 0:
        return False

    session = getattr(owner, "session", None)
    applied = False

    # SubsSupportPro DVB controller uses an independent subtitle clock. Seek its
    # engine directly to the elapsed EPG time.
    candidates = []
    for name in ("_subspro_controller", "_subssupportpro_controller", "_subssupportpro"):
        obj = getattr(owner, name, None)
        if obj is not None:
            candidates.append(obj)
            child = getattr(obj, "controller", None)
            if child is not None:
                candidates.append(child)
    if session is not None:
        candidates.extend(list(_iter_dialogs(session)))

    seen = set()
    for obj in candidates:
        if obj is None or id(obj) in seen:
            continue
        seen.add(id(obj))
        engine = getattr(obj, "engine", None)
        if engine is None:
            engine = getattr(obj, "_SubsProSupport__subsEngine", None)
        if engine is not None and getattr(engine, "subsList", None):
            seek = getattr(engine, "seekTo", None)
            if callable(seek):
                try:
                    seek(elapsed_ms)
                    setattr(owner, "_live_epg_offset_applied_ms", elapsed_ms)
                    applied = True
                    break
                except Exception:
                    pass

    # Regular SubsSupport follows playback PTS. A negative delay moves the
    # subtitle timeline forward by the elapsed EPG programme time.
    support = getattr(owner, "_external_subs", None) or getattr(owner, "_subssupport", None)
    engine = _regular_engine(support)
    if engine is not None and getattr(engine, "subsList", None):
        try:
            engine.setSubsDelay(-elapsed_ms)
            updater = getattr(engine, "updateSubPosition", None)
            if callable(updater):
                updater()
            player = getattr(engine, "play", None)
            if callable(player):
                player()
            setattr(owner, "_live_epg_offset_applied_ms", elapsed_ms)
            applied = True
        except Exception:
            pass
    return applied


def _schedule_live_epg_offset(owner, elapsed_seconds):
    """Poll briefly until Pro or regular SubsSupport has loaded the subtitle."""
    try:
        elapsed_ms = max(0, int(float(elapsed_seconds or 0) * 1000))
    except Exception:
        elapsed_ms = 0
    if elapsed_ms <= 0:
        return
    owner._live_epg_offset_target_ms = elapsed_ms
    owner._live_epg_offset_tries = 0
    try:
        from enigma import eTimer
        timer = getattr(owner, "_live_epg_offset_timer", None)
        if timer is None:
            timer = eTimer()
            owner._live_epg_offset_timer = timer

            def tick():
                try:
                    target = int(getattr(owner, "_live_epg_offset_target_ms", 0) or 0)
                    owner._live_epg_offset_tries = int(getattr(owner, "_live_epg_offset_tries", 0) or 0) + 1
                    if _apply_live_epg_offset(owner, target / 1000.0) or owner._live_epg_offset_tries >= 90:
                        timer.stop()
                except Exception:
                    try:
                        timer.stop()
                    except Exception:
                        pass

            try:
                timer.timeout.connect(tick)
            except Exception:
                timer.callback.append(tick)
        timer.stop()
        timer.start(1000)
    except Exception:
        pass

def open_subtitle_search(owner, title=None, elapsed_seconds=0):
    """Open regular SubsSupport only.

    SubsSupportPro is intentionally not used because several receiver images
    treat the VOD service as a new DVB/channel service and lose movie timing.
    Returns "regular" or None.
    """
    session = getattr(owner, "session", None)
    if session is None:
        return None
    try:
        from Plugins.Extensions.SubsSupport.subtitles import SubsSupport
        support = getattr(owner, "_subssupport", None)
        if support is None:
            support = SubsSupport(
                session,
                defaultPath="/tmp",
                forceDefaultPath=False,
                autoLoad=False,
                showGUIInfoMessages=True,
                embeddedSupport=False,
                preferEmbedded=False,
                searchSupport=True,
            )
            owner._subssupport = support
        epg_title = str(title).strip() if title and str(title).strip() else ""
        if epg_title:
            refs = []
            ref = getattr(owner, "current_ref", None)
            if ref is not None:
                refs.append(ref)
            try:
                playing_ref = session.nav.getCurrentlyPlayingServiceReference()
                if playing_ref is not None and playing_ref not in refs:
                    refs.append(playing_ref)
            except Exception:
                pass
            for service_ref in refs:
                try:
                    service_ref.setName(epg_title)
                except Exception:
                    pass
        _schedule_live_epg_offset(owner, elapsed_seconds)
        support.subsMenu()
        return "regular"
    except Exception:
        return None


def open_subtitle_pro(owner, title=None, elapsed_seconds=0):
    """Open SubsSupport Pro when installed, without changing regular SubsSupport."""
    session = getattr(owner, "session", None)
    if session is None:
        return False

    epg_title = str(title).strip() if title and str(title).strip() else ""
    if epg_title:
        refs = []
        ref = getattr(owner, "current_ref", None)
        if ref is not None:
            refs.append(ref)
        try:
            playing_ref = session.nav.getCurrentlyPlayingServiceReference()
            if playing_ref is not None and playing_ref not in refs:
                refs.append(playing_ref)
        except Exception:
            pass
        for service_ref in refs:
            try:
                service_ref.setName(epg_title)
            except Exception:
                pass

    # Known SubsSupport Pro module/class variants used by Enigma2 images.
    candidates = (
        ("Plugins.Extensions.SubsSupportPro.subtitles", "SubsSupportPro"),
        ("Plugins.Extensions.SubsSupportPro.subtitles", "SubsProSupport"),
        ("Plugins.Extensions.SubsSupportPro.plugin", "SubsSupportPro"),
        ("Plugins.Extensions.SubsSupportPro.plugin", "SubsProSupport"),
        ("Plugins.Extensions.SubsSupportPro.plugin", "main"),
        ("Plugins.Extensions.SubsSupportPro.plugin", "openSubsSupportPro"),
        ("Plugins.Extensions.SubsSupportPro.plugin", "openSubsSupportProMenu"),
    )
    for module_name, attr_name in candidates:
        try:
            module = __import__(module_name, fromlist=[attr_name])
            target = getattr(module, attr_name, None)
            if target is None:
                continue
            if attr_name in ("main", "openSubsSupportPro", "openSubsSupportProMenu"):
                try:
                    result = target(session)
                except TypeError:
                    result = target(session=session)
                return result is not False

            controller = getattr(owner, "_subssupportpro", None)
            if controller is None:
                try:
                    controller = target(
                        session,
                        defaultPath="/tmp",
                        forceDefaultPath=False,
                        autoLoad=False,
                        showGUIInfoMessages=True,
                        embeddedSupport=False,
                        preferEmbedded=False,
                        searchSupport=True,
                    )
                except TypeError:
                    try:
                        controller = target(session)
                    except TypeError:
                        controller = target(session=session)
                owner._subssupportpro = controller
                owner._subspro_controller = controller
            for method_name in ("subsMenu", "openMenu", "showMenu", "open"):
                method = getattr(controller, method_name, None)
                if callable(method):
                    method()
                    try:
                        _schedule_live_epg_offset(owner, elapsed_seconds)
                    except Exception:
                        pass
                    return True
        except Exception:
            continue

    # Final fallback: invoke the installed plugin descriptor by name.
    try:
        from Components.PluginComponent import plugins
        from Plugins.Plugin import PluginDescriptor
        for descriptor in plugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU):
            name = str(getattr(descriptor, "name", "") or "").lower().replace(" ", "")
            if "subssupportpro" not in name and "subsupportpro" not in name:
                continue
            try:
                descriptor(session=session)
            except TypeError:
                descriptor(session)
            return True
    except Exception:
        pass
    return False
