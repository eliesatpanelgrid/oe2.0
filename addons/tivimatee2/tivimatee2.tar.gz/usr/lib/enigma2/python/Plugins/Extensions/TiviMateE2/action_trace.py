import os
import time
import traceback
import threading

_LOCK = threading.RLock()
_MAX_BYTES = 256 * 1024
_NAME = "restart_keys.log"


def _log_path():
    try:
        from .cache_manager import get_logs_dir
        root = get_logs_dir()
    except Exception:
        try:
            from .storage import data_path
            root = data_path("logs")
        except Exception:
            root = "/media/hdd/.tivimatee2-cache/logs" if os.path.ismount("/media/hdd") else "/var/tmp/tivimatee2-cache/logs"
    try:
        if not os.path.isdir(root):
            os.makedirs(root)
    except Exception:
        pass
    return os.path.join(root, _NAME)


def _rotate(path):
    try:
        if os.path.isfile(path) and os.path.getsize(path) >= _MAX_BYTES:
            old = path + ".1"
            try:
                if os.path.exists(old):
                    os.remove(old)
            except Exception:
                pass
            try:
                os.rename(path, old)
            except Exception:
                pass
    except Exception:
        pass


def _memory_line():
    # Cheap process-only memory snapshot. Avoids external commands.
    try:
        with open("/proc/self/status", "r") as f:
            vals = {}
            for line in f:
                if line.startswith(("VmRSS:", "VmSize:", "Threads:")):
                    k, v = line.split(":", 1)
                    vals[k] = v.strip()
            return " rss=%s vmsize=%s threads=%s" % (
                vals.get("VmRSS", "?"), vals.get("VmSize", "?"), vals.get("Threads", "?"))
    except Exception:
        return ""


def log_action(action="", contexts=None, callback=None, phase="KEY"):
    try:
        ctx = contexts
        if isinstance(ctx, (list, tuple)):
            ctx = ",".join([str(x) for x in ctx])
        else:
            ctx = str(ctx or "")
        cb = ""
        if callback is not None:
            try:
                cb = getattr(callback, "__name__", "") or repr(callback)
                owner = getattr(callback, "__self__", None)
                if owner is not None:
                    cb = "%s.%s" % (owner.__class__.__name__, cb)
            except Exception:
                cb = "?"
        line = "%s %s action=%s contexts=%s callback=%s%s\n" % (
            time.strftime("%Y-%m-%d %H:%M:%S"), phase, str(action or ""), ctx, cb, _memory_line())
        path = _log_path()
        with _LOCK:
            _rotate(path)
            with open(path, "a") as f:
                f.write(line)
                f.flush()
    except Exception:
        pass


def log_exception(action="", contexts=None, callback=None):
    try:
        log_action(action, contexts, callback, "EXCEPTION")
        path = _log_path()
        text = traceback.format_exc()
        with _LOCK:
            with open(path, "a") as f:
                f.write(text)
                if not text.endswith("\n"):
                    f.write("\n")
                f.flush()
    except Exception:
        pass


def make_traced_actionmap(base_cls):
    class TracedActionMap(base_cls):
        def action(self, *args, **kwargs):
            contexts = None
            action_name = ""
            try:
                if len(args) >= 2:
                    contexts, action_name = args[0], args[1]
                elif len(args) == 1:
                    action_name = args[0]
                callback = None
                try:
                    actions = getattr(self, "actions", None)
                    if isinstance(actions, dict):
                        callback = actions.get(action_name)
                except Exception:
                    callback = None
                log_action(action_name, contexts, callback, "KEY")
                try:
                    return base_cls.action(self, *args, **kwargs)
                except Exception:
                    log_exception(action_name, contexts, callback)
                    raise
            except Exception:
                # Never let diagnostics alter normal key handling.
                try:
                    return base_cls.action(self, *args, **kwargs)
                except Exception:
                    raise
    return TracedActionMap
