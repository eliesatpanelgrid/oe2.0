def _content_dedupe_key(item, kind=""):
    """Stable content identity shared across pages in the same screen.

    Prefer a confirmed TMDb id. Otherwise use cleaned title+year so provider
    duplicates such as FHD/4K copies collapse even when stream ids differ.
    Fall back to provider ids only when title information is unavailable.
    """
    row = item or {}
    try:
        tmdb_id = str(row.get("tmdb_id") or row.get("tmdb") or row.get("tmdbId") or "").strip()
    except Exception:
        tmdb_id = ""
    if tmdb_id and tmdb_id not in ("0", "None", "none"):
        return "tmdb:%s:%s" % (str(kind or row.get("_search_kind") or ""), tmdb_id)
    title = str(row.get("name") or row.get("title") or row.get("original_name") or row.get("original_title") or "").lower().strip()
    # Remove common provider quality/language decorations before comparing.
    title = re.sub(r"[\[\(][^\]\)]*(?:4k|uhd|fhd|full\s*hd|1080p|2160p|720p|hdr|hevc|x265|x264|arabic|english|multi)[^\]\)]*[\]\)]", " ", title, flags=re.I)
    title = re.sub(r"(?<![a-z0-9])(?:4k|uhd|fhd|full\s*hd|1080p|2160p|720p|hdr|hevc|x265|x264)(?![a-z0-9])", " ", title, flags=re.I)
    title = re.sub(r"\s+", " ", re.sub(r"[^a-z0-9\u0600-\u06ff]+", " ", title)).strip()
    year = str(row.get("year") or row.get("release_date") or row.get("releaseDate") or row.get("first_air_date") or "").strip()
    m = re.search(r"(?:19|20)\d{2}", year)
    year = m.group(0) if m else ""
    if title:
        return "title:%s:%s:%s" % (str(kind or row.get("_search_kind") or ""), title, year)
    provider_id = str(row.get("series_id") or row.get("stream_id") or row.get("vod_id") or row.get("id") or "").strip()
    return "id:%s:%s" % (str(kind or row.get("_search_kind") or ""), provider_id) if provider_id else ""


def _dedupe_content_rows(items, kind=""):
    out = []
    seen = set()
    for item in list(items or []):
        key = _content_dedupe_key(item, kind)
        if key and key in seen:
            continue
        if key:
            seen.add(key)
        out.append(item)
    return out


class TiviMateE2Search(Screen):
    skin = SEARCH_SCREEN
    PAGE_SIZE = 10
    GRID_X = [70, 315, 560, 805, 1050]
    GRID_Y = [257, 585]


    def __init__(self, session, source):
        Screen.__init__(self, session)
        # New app session: allow Live picon caching again.
        try:
            from .estalker_picon import set_app_exiting
            set_app_exiting(False)
        except Exception:
            pass
        self._pageOpenBusy = False
        self.source = source
        self.query = ""
        self.results = []
        self.page = 0
        self.index = 0
        self.loaders = []
        self.downloaders = []
        self._artwork_requests = {}
        self._detail_request = None
        self._searchGeneration = 0
        self.topNames = [nav_label("Search"), nav_label("Home"), nav_label("Live"), nav_label("Movies"), nav_label("TV Shows"), nav_label("Packages"), nav_label("Continue Watching"), nav_label("Settings")]
        self.topX = [40, 225, 410, 595, 780, 965, 1150, 1510]
        self.topW = [175, 175, 175, 175, 175, 175, 350, 175]
        self.topIndex = 0
        self.navFocus = "top"
        for i, name in enumerate(self.topNames):
            self["top%d" % i] = Label(name)
        self["topSelector"] = Pixmap()
        self["back"] = Label("‹")
        self["searchText"] = Label(tr("Search for a movie or series..."))
        self["mic"] = Label("◉")
        self["closeIcon"] = Label("×")
        self["moviesTitle"] = Label(tr("Search results"))
        self["showsTitle"] = Label("")
        for i in range(10):
            self["poster%d" % i] = Pixmap()
            self["posterLabel%d" % i] = Label("")
            self["posterRate%d" % i] = Label("")
        self["movieSelector"] = Pixmap()
        self["showSelector"] = Pixmap()
        self["detailPoster"] = Pixmap()
        self["selectedTitle"] = Label("")
        self["selectedMeta"] = Label("")
        self["selectedOverview"] = Label("")
        self["play"] = Label("▷  " + tr("Play"))
        self["favorite"] = Label("☆  " + tr("Add to My List"))
        self["pageInfo"] = Label("")
        self["status"] = Label(tr("Press OK to start searching"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "green": self.openKeyboard, "yellow": self.prevPage, "blue": self.nextPage,
            "yellowlong": self.addCurrentFavourite
        }, -1)
        self.onLayoutFinish.append(self.layoutReady)

    def layoutReady(self):
        self["status"].setText(tr("Press OK to start searching"))
        self._updateSearchTopFocus()
        try:
            self["movieSelector"].hide(); self["showSelector"].hide()
        except Exception:
            pass


    def _updateSearchTopFocus(self):
        try:
            index = max(0, min(self.topIndex, len(self.topX) - 1))
            cell_w = self.topW[index]
            x = self.topX[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(66)))
            self["topSelector"].setVisible(self.navFocus == "top")
        except Exception:
            pass


    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def _openSearchTop(self):
        if self.topIndex == 0:
            self.navFocus = "content"; self._updateSearchTopFocus(); self.openKeyboard(); return
        if self.topIndex == 1:
            self._openPageOnce(TiviMateE2Home); return
        if self.topIndex == 2:
            self._openPageOnce(MediaScreen, self.source, "live"); return
        if self.topIndex == 3:
            self._openPageOnce(ContentHomeScreen, self.source, "vod"); return
        if self.topIndex == 4:
            self._openPageOnce(ContentHomeScreen, self.source, "series"); return
        if self.topIndex == 5:
            self._openPageOnce(ContentPackagesScreen, self.source); return
        if self.topIndex == 6:
            self._openPageOnce(ContinueWatchingScreen, self.source); return
        if self.topIndex == 7:
            self._openPageOnce(SettingsDashboard); return



    def addTmdbKey(self):
        # Import from a local text/key/config file.  The built-in shared key and
        # any previously saved private key are never displayed on screen.
        self.session.openWithCallback(self.tmdbKeyEntered, TMDbKeyImportBrowser, "/")

    def tmdbKeyEntered(self, value=None):
        if value is None:
            return
        self.customTmdbKey.value = (value or "").strip()
        try:
            self["hint"].setText("Custom TMDb key ready. Press GREEN to save.")
        except Exception:
            pass

    def openKeyboard(self):
        try:
            self.session.openWithCallback(self.searchReady, VirtualKeyBoard, title="Search", text=self.query)
        except RuntimeError:
            self["status"].setText(tr("Press OK again to open the search keyboard"))

    def searchReady(self, value=None):
        if value is None:
            if not self.query:
                self.close()
            return
        self.query = (value or "").strip()
        self["searchText"].setText(self.query or tr("Search for a movie or series..."))
        if not self.query:
            return

        # Every search owns a generation id. Older workers are ignored if the
        # user starts another search before they finish.
        self._searchGeneration = int(getattr(self, "_searchGeneration", 0) or 0) + 1
        generation = self._searchGeneration
        query = self.query
        self["status"].setText(tr("Searching..."))
        t = threading.Thread(target=self._worker, args=(generation, query), name="TiviMateSearch")
        t.daemon = True
        t.start()

    def _tag(self, rows, kind):
        out = []
        for item in rows:
            try:
                row = dict(item or {})
            except Exception:
                row = item or {}
            row["_search_kind"] = kind
            out.append(row)
        return out

    def _strictFilteredSearchRows(self, kind, client, source=None):
        """Return rows ONLY from packages explicitly selected for ``source``.

        Movies (vod) and Series have independent filter scopes. There is deliberately
        no provider-wide fallback: an unselected package is never queried by Search.
        ``source`` is explicit so Multi-Portal Search can respect each portal's own
        package filter instead of accidentally reusing the currently-open portal.
        """
        if kind not in ("vod", "series"):
            return []
        src = source or self.source
        allowed = get_allowed_category_ids(src, kind)
        # Strict means explicit selection is required. None/no selection must not
        # silently turn into "search the whole server".
        if not allowed:
            return []

        allowed = set(str(x) for x in allowed if str(x))
        if not allowed:
            return []

        # Preserve the user's filtered package order when category metadata is available.
        ordered_ids = []
        try:
            categories, _origin = get_cached_categories(
                src, kind, client=client, wait_for_server=False
            )
            for row in categories or []:
                cid = str((row or {}).get("category_id") or "")
                if cid and cid in allowed and cid not in ordered_ids:
                    ordered_ids.append(cid)
        except Exception:
            pass
        for cid in allowed:
            if cid not in ordered_ids:
                ordered_ids.append(cid)

        output = []
        seen = set()
        for cid in ordered_ids:
            try:
                rows, _origin = get_category_streams(
                    src, kind, client, cid,
                    use_cache=True, wait_for_server=True
                )
            except Exception:
                rows = []
            for item in rows or []:
                if not isinstance(item, dict):
                    continue
                # Extra guard against broken portals returning cross-package rows.
                item_cid = str(
                    item.get("category_id") or item.get("categoryId") or
                    item.get("genre_id") or item.get("genre-id") or ""
                )
                if item_cid and item_cid not in allowed:
                    continue
                unique = _content_dedupe_key(item, kind)
                if unique and unique in seen:
                    continue
                if unique:
                    seen.add(unique)
                output.append(item)
        return output

    def _searchSourceName(self, source):
        src = source or {}
        return str(src.get("name") or src.get("title") or src.get("portal") or src.get("url") or "Stalker")

    def _attachSearchSource(self, rows, source, kind):
        out = []
        src = dict(source or {})
        src_key = _source_identity(src)
        src_name = self._searchSourceName(src)
        for item in rows or []:
            try:
                row = dict(item or {})
            except Exception:
                continue
            row["_search_kind"] = kind
            row["_search_source"] = src
            row["_search_source_key"] = src_key
            row["_search_source_name"] = src_name
            out.append(row)
        return out

    def _itemSearchSource(self, item):
        src = (item or {}).get("_search_source")
        return src if isinstance(src, dict) and src else self.source

    def _dedupeSearchRows(self, items):
        # Keep one clean copy per portal. The same movie on Portal A and Portal B
        # must remain visible because playback credentials/source are different.
        out = []
        seen = set()
        for item in list(items or []):
            base = _content_dedupe_key(item, (item or {}).get("_search_kind", ""))
            src_key = str((item or {}).get("_search_source_key") or _source_identity(self.source))
            key = "%s|%s" % (src_key, base) if base else "%s|id:%s" % (src_key, id(item))
            if key in seen:
                continue
            seen.add(key)
            out.append(item)
        return out

    def _searchOneStalkerPortal(self, source, query, per_portal_limit=50):
        q = str(query or "").strip().lower()
        client = StalkerClient(source)

        def match(rows):
            return [
                x for x in (rows or [])
                if q in str((x or {}).get("name") or (x or {}).get("title") or "").lower()
            ]

        movie_ids = get_allowed_category_ids(source, "vod") or []
        series_ids = get_allowed_category_ids(source, "series") or []
        movies_native = client.search_filtered_media_native("vod", query, movie_ids, limit=per_portal_limit)
        shows_native = client.search_filtered_media_native("series", query, series_ids, limit=per_portal_limit)
        movies_all = self._strictFilteredSearchRows("vod", client, source) if movies_native is None else movies_native
        shows_all = self._strictFilteredSearchRows("series", client, source) if shows_native is None else shows_native
        movies = match(movies_all)[:per_portal_limit]
        shows = match(shows_all)[:per_portal_limit]
        return self._attachSearchSource(movies, source, "vod") + self._attachSearchSource(shows, source, "series")

    def _worker(self, generation, query):
        try:
            q = str(query or "").strip().lower()
            source_type = self.source.get("type")
            results = []

            if source_type == "stalker":
                # Multi-Portal Search: search every configured Stalker portal,
                # while preserving each portal's own package filters. Run at most
                # three portal requests in parallel to avoid hammering the box or
                # the providers. The current portal is searched first.
                portals = []
                current_key = _source_identity(self.source)
                seen_portals = set()
                candidates = [self.source] + [s for s in (get_sources() or []) if (s or {}).get("type") == "stalker"]
                for src in candidates:
                    key = _source_identity(src)
                    if not key or key in seen_portals:
                        continue
                    seen_portals.add(key)
                    portals.append(dict(src or {}))

                lock = threading.Lock()
                threads = []
                # r152 Endurance Guard: use a fixed three-worker pool instead of
                # creating one blocked thread for every configured portal.  This
                # keeps RAM/thread count flat even with a large server list.
                search_budget = 12.0
                search_deadline = time.monotonic() + search_budget
                accept_results = threading.Event()
                accept_results.set()
                next_portal = [0]

                def portal_worker():
                    while accept_results.is_set():
                        if time.monotonic() >= search_deadline:
                            return
                        with lock:
                            if next_portal[0] >= len(portals):
                                return
                            src = portals[next_portal[0]]
                            next_portal[0] += 1
                        try:
                            rows = self._searchOneStalkerPortal(src, query, per_portal_limit=50)
                        except Exception:
                            rows = []
                        if not accept_results.is_set():
                            return
                        if generation != int(getattr(self, "_searchGeneration", 0) or 0):
                            return
                        with lock:
                            if accept_results.is_set():
                                results.extend(rows)

                worker_count = min(3, len(portals))
                for idx in range(worker_count):
                    t = threading.Thread(target=portal_worker, name="TiviMatePortalSearch-%d" % (idx + 1))
                    t.daemon = True
                    threads.append(t)
                    t.start()
                for t in threads:
                    remaining = search_deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    t.join(remaining)
                accept_results.clear()
                # Work on a stable snapshot; timed-out daemon workers are not
                # allowed to append after Search has already returned.
                with lock:
                    results = list(results)

            elif source_type == "xtream":
                # Xtream search remains unchanged and scoped to the current server.
                client = XtreamClient(self.source)
                movies_all = self._strictFilteredSearchRows("vod", client, self.source)
                shows_all = self._strictFilteredSearchRows("series", client, self.source)
                def match(rows):
                    return [x for x in (rows or []) if q in str((x or {}).get("name") or (x or {}).get("title") or "").lower()]
                results = self._tag(match(movies_all), "vod") + self._tag(match(shows_all), "series")
            else:
                results = []

            results = self._dedupeSearchRows(results)[:500]

            if generation != int(getattr(self, "_searchGeneration", 0) or 0):
                return
            if reactor:
                reactor.callFromThread(self._readySearchGeneration, generation, results)
            else:
                self._readySearchGeneration(generation, results)
        except Exception as exc:
            if generation != int(getattr(self, "_searchGeneration", 0) or 0):
                return
            if reactor:
                reactor.callFromThread(self._failedSearchGeneration, generation, str(exc))
            else:
                self._failedSearchGeneration(generation, str(exc))

    def _readySearchGeneration(self, generation, results):
        if generation != int(getattr(self, "_searchGeneration", 0) or 0):
            return
        self._ready(results)

    def _failedSearchGeneration(self, generation, err):
        if generation != int(getattr(self, "_searchGeneration", 0) or 0):
            return
        self._failed(err)

    def _failed(self, err):
        self["status"].setText("Search failed: %s" % err)

    def short_title(self, item):
        title = str((item or {}).get("name") or (item or {}).get("title") or "").strip()
        return title[:24] + ("…" if len(title) > 24 else "")

    def _ready(self, results):
        self.results = self._dedupeSearchRows(results or [])
        self.page = 0
        self.index = 0
        self.renderPage()

    def pageItems(self):
        start = self.page * self.PAGE_SIZE
        return self.results[start:start + self.PAGE_SIZE]

    def pageCount(self):
        if not self.results:
            return 1
        return (len(self.results) + self.PAGE_SIZE - 1) // self.PAGE_SIZE

    def renderPage(self):
        items = self.pageItems()
        self._artwork_requests = {}
        placeholder = os.path.join(PLUGIN_PATH, "skins", "poster_placeholder.png")
        for i in range(10):
            try:
                self["poster%d" % i].hide()
                self["posterLabel%d" % i].hide()
                self["posterRate%d" % i].hide()
            except Exception:
                pass
        for i, item in enumerate(items):
            try:
                self["poster%d" % i].instance.setPixmapFromFile(placeholder)
                self["poster%d" % i].show()
                self["posterLabel%d" % i].setText(self.short_title(item))
                rating = item.get("rating") or item.get("rating_5based") or item.get("vote_average") or ""
                self["posterRate%d" % i].setText(str(rating)[:4])
                self["posterLabel%d" % i].show()
                self["posterRate%d" % i].show()
            except Exception:
                pass
            self.loadImage(i, item.get("stream_icon") or item.get("cover") or item.get("poster_path") or "", item)
        # Warm every poster already returned by Search in the background.
        prefetch_artwork([
            (row or {}).get("stream_icon") or (row or {}).get("cover") or (row or {}).get("poster_path") or ""
            for row in list(self.results or [])
        ], "posters", priority=2)
        self.index = min(self.index, max(0, len(items) - 1))
        total = len(self.results)
        self["moviesTitle"].setText("%s: %s" % (tr("Search results"), self.query))
        self["showsTitle"].setText("%d %s" % (total, tr("results")))
        self["pageInfo"].setText("‹   %s %d / %d   ›" % (tr("Page"), self.page + 1, self.pageCount()))
        self["status"].setText("%d %s" % (total, tr("results")))
        self.updateSelection()

    def current(self):
        items = self.pageItems()
        return items[self.index] if items and self.index < len(items) else None

    def currentGlobalIndex(self):
        return self.page * self.PAGE_SIZE + self.index

    def updateSelection(self):
        items = self.pageItems()
        if not items:
            try:
                self["movieSelector"].hide(); self["showSelector"].hide()
            except Exception:
                pass
            self["selectedTitle"].setText("")
            self["selectedMeta"].setText("")
            self["selectedOverview"].setText("")
            return
        self.index = min(self.index, len(items) - 1)
        col = self.index % 5
        row = self.index // 5
        x = self.GRID_X[col]
        y = self.GRID_Y[row]
        try:
            self["showSelector"].hide()
            self["movieSelector"].instance.move(ePoint(sx(x), sy(y)))
            self["movieSelector"].show()
        except Exception:
            pass
        item = self.current() or {}
        title = item.get("name") or item.get("title") or ""
        year = item.get("year") or item.get("releaseDate") or item.get("release_date") or item.get("first_air_date") or ""
        if isinstance(year, str) and len(year) >= 4:
            year = year[:4]
        rating = item.get("rating") or item.get("rating_5based") or item.get("vote_average") or "-"
        kind = item.get("_search_kind", "vod")
        kind_label = tr("TV Show") if kind == "series" else (tr("Channel") if kind == "live" else tr("Movie"))
        self["selectedTitle"].setText(str(title))
        result_source = self._itemSearchSource(item)
        source_name = self._searchSourceName(result_source)
        self["selectedMeta"].setText("%s: %s   •   %s\n%s: %s\n%s: %s" % (tr("Type"), kind_label, source_name, tr("Year"), year or "-", tr("Rating"), rating))
        overview = item.get("plot") or item.get("description") or item.get("overview") or ""
        if len(str(overview)) > 220:
            overview = str(overview)[:217] + "..."
        self["selectedOverview"].setText(str(overview))
        self["favorite"].setText(("★  " + tr("Remove from My List")) if is_favourite(result_source, kind, item) else ("☆  " + tr("Add to My List")))
        detail_url = item.get("stream_icon") or item.get("cover") or item.get("poster_path") or ""
        self.loadDetailImage(detail_url, item)

    def left(self):
        if self.navFocus == "top":
            self.topIndex = max(0, self.topIndex - 1)
            self._updateSearchTopFocus()
            return
        if not self.results:
            return
        if self.index > 0:
            self.index -= 1
            self.updateSelection()
        elif self.page > 0:
            self.page -= 1
            self.index = min(self.PAGE_SIZE - 1, len(self.pageItems()) - 1)
            self.renderPage()

    def right(self):
        if self.navFocus == "top":
            self.topIndex = min(len(self.topNames) - 1, self.topIndex + 1)
            self._updateSearchTopFocus()
            return
        items = self.pageItems()
        if not items:
            return
        if self.index < len(items) - 1:
            self.index += 1
            self.updateSelection()
        elif self.page < self.pageCount() - 1:
            self.page += 1
            self.index = 0
            self.renderPage()

    def up(self):
        if self.navFocus == "top":
            return
        if self.index >= 5:
            self.index -= 5
            self.updateSelection()
        else:
            self.navFocus = "top"
            self._updateSearchTopFocus()


    def down(self):
        if self.navFocus == "top":
            self.navFocus = "content"
            self._updateSearchTopFocus()
            return
        items = self.pageItems()
        candidate = self.index + 5
        if candidate < len(items):
            self.index = candidate
            self.updateSelection()


    def prevPage(self):
        if self.page > 0:
            self.page -= 1
            self.index = 0
            self.renderPage()

    def nextPage(self):
        if self.page < self.pageCount() - 1:
            self.page += 1
            self.index = 0
            self.renderPage()

    def toggleFavourite(self):
        item = self.current()
        if not item:
            return
        kind = item.get("_search_kind", "vod")
        result_source = self._itemSearchSource(item)
        added, saved = toggle_favourite(result_source, kind, item)
        if not saved:
            self["status"].setText(tr("Unable to save favorite"))
        elif added:
            self["status"].setText(tr("Added to favorites"))
        else:
            self["status"].setText(tr("Removed from favorites"))
        self.updateSelection()

    def addCurrentFavourite(self):
        item = self.current()
        if not item:
            return
        kind = item.get("_search_kind", "vod")
        if kind not in ("vod", "series"):
            return
        result_source = self._itemSearchSource(item)
        if is_favourite(result_source, kind, item):
            self["status"].setText(tr("Item is already in favorites"))
        elif add_favourite(result_source, kind, item):
            self["status"].setText(tr("Added to favorites"))
        else:
            self["status"].setText(tr("Unable to save favorite"))
        self.updateSelection()

    def ok(self):
        if self.navFocus == "top":
            self._openSearchTop()
            return
        item = self.current()
        if not item:
            self.openKeyboard()
            return
        kind = item.get("_search_kind", "vod")
        result_source = self._itemSearchSource(item)
        if kind == "live":
            rows = [x for x in self.results if x.get("_search_kind") == "live"]
            idx = 0
            try:
                idx = rows.index(item)
            except Exception:
                pass
            self.session.open(TiviMateLivePlayer, result_source, rows, idx)
            return
        if kind == "series":
            self.session.open(SeriesDetailsScreen, result_source, item)
            return
        if result_source.get("type") == "stalker":
            url = StalkerClient(result_source).stream_url(item, "vod")
        else:
            ext = item.get("container_extension") or result_source.get("output", "ts")
            url = "%s/movie/%s/%s/%s.%s" % (result_source.get("url", "").rstrip("/"), result_source.get("username", ""), result_source.get("password", ""), item.get("stream_id", ""), ext)
        if not url:
            self.session.open(MessageBox, "Unable to resolve a playable movie URL.", MessageBox.TYPE_ERROR)
            return
        play_item = dict(item or {})
        play_item["_source_type"] = result_source.get("type", "")
        play_item["_source_key"] = _source_identity(result_source)
        play_item["_kind"] = "vod"
        self.session.open(TiviMatePlayer, eServiceReference(_stalker_service_type(result_source, "vod") if result_source.get("type") == "stalker" else 4097, 0, url), play_item)

    def _searchPosterFileUsable(self, path):
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, "rb") as fh:
                head = fh.read(12)
            return head.startswith(b"\xff\xd8\xff") or head.startswith(b"\x89PNG\r\n\x1a\n")
        except Exception:
            return False

    def _searchPosterFallback(self, slot, item, detail=False):
        item = item or {}
        kind = item.get("_search_kind", "vod")
        if kind not in ("vod", "series"):
            return
        title = item.get("name") or item.get("title") or item.get("original_title") or ""
        if not title:
            return
        token = "tmdb:%s:%s:%s" % (kind, slot, str(title))
        if detail:
            self._detail_request = token
        else:
            self._artwork_requests[slot] = token

        def worker():
            try:
                raw_year = item.get("year") or item.get("releaseDate") or item.get("release_date") or item.get("first_air_date") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                year = match.group(0) if match else None
                found = TMDbClient().search_artwork(title, kind, year, required_key="poster_path") or {}
                poster = found.get("poster_path") or ""
                if not poster:
                    return
                url = poster if str(poster).startswith(("http://", "https://")) else "https://image.tmdb.org/t/p/w500" + str(poster)

                def apply():
                    if detail:
                        if getattr(self, "_detail_request", None) != token:
                            return
                        self.loadDetailImage(url, item, allow_fallback=False)
                    else:
                        if getattr(self, "_artwork_requests", {}).get(slot) != token:
                            return
                        self.loadImage(slot, url, item, allow_fallback=False)

                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass

        t = threading.Thread(target=worker, name="TiviMateSearchPosterTMDB")
        t.daemon = True
        t.start()

    def loadImage(self, slot, url, item=None, allow_fallback=True):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            if allow_fallback and item is not None:
                self._searchPosterFallback(slot, item, detail=False)
            return
        self._artwork_requests[slot] = url

        def done(path, s=slot, expected=url, fallback_item=item):
            if getattr(self, "_artwork_requests", {}).get(s) != expected:
                return
            if not self._searchPosterFileUsable(path):
                if allow_fallback and fallback_item is not None:
                    self._searchPosterFallback(s, fallback_item, detail=False)
                return
            self.decode(s, path)
            try:
                if s == self.index:
                    self._detail_request = expected
                    self.decodeDetail(path)
            except Exception:
                pass

        def failed(_path, s=slot, fallback_item=item):
            if allow_fallback and fallback_item is not None:
                self._searchPosterFallback(s, fallback_item, detail=False)

        request_artwork(url, "posters", done, priority=55, errback=failed)

    def loadDetailImage(self, url, item=None, allow_fallback=True):
        url = (url or "").strip().replace("\\/", "/")
        placeholder = os.path.join(PLUGIN_PATH, "skins", "poster_placeholder.png")
        try:
            self["detailPoster"].instance.setPixmapFromFile(placeholder)
        except Exception:
            pass
        if not url:
            if allow_fallback and item is not None:
                self._searchPosterFallback(self.index, item, detail=True)
            return
        self._detail_request = url

        def done(path, expected=url, fallback_item=item):
            if getattr(self, "_detail_request", None) != expected:
                return
            if not self._searchPosterFileUsable(path):
                if allow_fallback and fallback_item is not None:
                    self._searchPosterFallback(self.index, fallback_item, detail=True)
                return
            self.decodeDetail(path)

        def failed(_path, fallback_item=item):
            if allow_fallback and fallback_item is not None:
                self._searchPosterFallback(self.index, fallback_item, detail=True)

        request_artwork(url, "posters", done, priority=58, errback=failed)

    def decode(self, slot, path):
        loader = ePicLoad()
        self.loaders.append(loader)
        def ready(_=None, s=slot, ll=loader):
            try:
                ptr = ll.getData()
                widget = self["poster%d" % s]
                if ptr and widget.instance:
                    widget.instance.setPixmap(ptr)
                    widget.show()
            except Exception:
                pass
            try:
                if ll in self.loaders:
                    self.loaders.remove(ll)
            except Exception:
                pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(200, 285)
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def decodeDetail(self, path):
        loader = ePicLoad()
        self.loaders.append(loader)
        def ready(_=None, ll=loader):
            try:
                ptr = ll.getData()
                if ptr and self["detailPoster"].instance:
                    self["detailPoster"].instance.setPixmap(ptr)
                    self["detailPoster"].show()
            except Exception:
                pass
            try:
                if ll in self.loaders:
                    self.loaders.remove(ll)
            except Exception:
                pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(215, 305)
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)



HOME_SERVER_POPUP_SKIN = r"""
<screen name="HomeServerPopup" position="600,315" size="720,450" flags="wfNoBorder" backgroundColor="#101820" title="Select Server">
    <ePixmap position="0,0" size="720,450" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_popup_bg_r182.png" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="title" position="42,30" size="636,52" font="Regular;32" foregroundColor="#FFFFFF" backgroundColor="#101820" transparent="1" zPosition="3"/>
    <widget name="subtitle" position="42,83" size="636,34" font="Regular;19" foregroundColor="#AEB9C5" backgroundColor="#101820" transparent="1" zPosition="3"/>
    <widget name="servers" position="42,135" size="636,228" itemHeight="57" font="Regular;25" foregroundColor="#EAF0F5" backgroundColor="#101820" selectionForegroundColor="#FFFFFF" selectionBackgroundColor="#203847" scrollbarMode="showOnDemand" zPosition="4"/>
    <widget name="hint" position="42,386" size="636,34" font="Regular;18" foregroundColor="#91A1AF" backgroundColor="#101820" transparent="1" halign="center" zPosition="3"/>
</screen>
"""

class HomeServerPopup(Screen):
    skin = HOME_SERVER_POPUP_SKIN

    def __init__(self, session, sources, active_source=None):
        Screen.__init__(self, session)
        self.sources = [dict(x or {}) for x in (sources or []) if x]
        self.active_source = dict(active_source or {})
        self["title"] = Label(tr("Select Server"))
        self["subtitle"] = Label(tr("Choose the server for Home"))
        self["hint"] = Label(tr("UP/DOWN  Navigate     OK  Select     EXIT  Cancel"))
        rows = []
        active_key = self._key(self.active_source)
        active_index = 0
        for i, source in enumerate(self.sources):
            name = str(source.get("name") or source.get("server") or source.get("portal") or "IPTV Server")
            stype = str(source.get("type") or "IPTV").upper()
            marker = u"✓  " if self._key(source) == active_key else u"   "
            rows.append(u"%s%s    •    %s" % (marker, name[:34], stype[:12]))
            if self._key(source) == active_key:
                active_index = i
        self["servers"] = MenuList(rows, enableWrapAround=True)
        try:
            self["servers"].moveToIndex(active_index)
        except Exception:
            pass
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.choose, "cancel": self.close,
            "up": self["servers"].up, "down": self["servers"].down,
            "left": self["servers"].pageUp, "right": self["servers"].pageDown,
        }, -1)

    def _key(self, source):
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("url", "").rstrip("/"), source.get("username", ""), source.get("mac", ""))

    def choose(self):
        try:
            index = self["servers"].getSelectionIndex()
        except Exception:
            index = 0
        if 0 <= index < len(self.sources):
            self.close(self.sources[index])
        else:
            self.close(None)


class TiviMateE2Home(Screen):
    skin = HOME_SKIN1
    NAV = ["Search", "Home", "Live", "Movies", "TV Shows", "Packages", "Continue Watching", "Settings"]
    NAV_X = [312, 467, 622, 777, 932, 1087, 1242, 1397]
    NAV_Y = [210] * 8
    POSTER_X = [216, 461, 706, 951, 1196, 1441]
    POSTER_Y = 701
    ACTIVE_FILE = data_path("active_source.json")


    def __init__(self, session):
        self.homeAppearance = _load_home_appearance()
        self.homeSkinName = self.homeAppearance.get("skin", "skin2_dark")
        self.isReferenceHome = self.homeSkinName == "reference_home"
        self.posterSize = (248, 338)
        self.bannerSize = (1704, 454)
        if self.homeSkinName in ("skin2_dark", "skin3_accessibility"):
            self.skin = HOME_SKIN3_ACCESSIBILITY if self.homeSkinName == "skin3_accessibility" else HOME_SKIN2
            self.NAV = ["Search", "Home", "Live", "Movies", "TV Shows", "Packages", "Continue Watching", "Settings"]
            self.NAV_X = [312, 467, 622, 777, 932, 1087, 1242, 1397]
            self.NAV_Y = [79] * 8
            self.POSTER_X = [55, 375, 695, 1015, 1335, 1655]
            self.POSTER_Y = 510
            self.posterSize = (215, 360)
            self.bannerSize = (1920, 370)
        else:
            self.homeSkinName = "reference_home"
            self.isReferenceHome = True
            self.skin = HOME_SKIN1
            self.NAV_X = [312, 467, 622, 777, 932, 1087, 1242, 1397]
            self.NAV_Y = [27] * 8
            self.POSTER_X = [106, 398, 690, 982, 1274, 1566]
            self.POSTER_Y = 676
        Screen.__init__(self, session)
        # r173: a new Home session re-enables artwork writes after the previous
        # explicit Home exit locked every late downloader/callback.
        try:
            from .artwork_queue import set_app_exiting as set_artwork_exiting
            set_artwork_exiting(False)
        except Exception:
            pass
        try:
            from .estalker_picon import set_app_exiting as set_picon_exiting
            set_picon_exiting(False)
        except Exception:
            pass
        self._pageOpenBusy = False
        self.source = self._loadActiveSource()
        self.homeContentMode = _load_home_appearance().get("content", "popular_movies")
        # Home no longer exposes Recent Added. Migrate any stale saved Home mode
        # left by older builds to Popular Movies and persist the correction.
        if self.homeContentMode in ("recent_movies", "recent_series"):
            self.homeContentMode = "popular_movies"
            try:
                cfg = _load_home_appearance()
                _save_home_appearance(cfg.get("skin", "skin2_dark"), "popular_movies")
            except Exception:
                pass
        self.focus = "nav"
        self.navIndex = 1
        self.posterIndex = 0
        self.recent = []
        # Warm VOD index used by Home Popular/Trending movie cards. It is filled
        # in the background while TMDb posters are shown, so WATCH does not start
        # a full server scan after the user opens a movie.
        self.homeMovieServerItems = []
        self.homeMovieIndexLoading = False
        self.imageLoaders = [None] * 7
        self.imageDownloaders = [None] * 7
        self.featureRequestId = 0
        # Every asynchronous Home job belongs to the server generation that
        # created it. Switching server invalidates older workers/callbacks.
        self._sourceGeneration = 1
        self._homeClosed = False
        # The dashboard hero is part of the application identity, never of a specific IPTV source.
        self.globalHero = True
        self["headline"] = Label(tr("TiViMate IPTV EXPERIENCE"))
        self["subheadline"] = Label(tr("Live TV  •  Movies  •  Series  •  beIN SPORTS"))
        self["logo"] = Label(tr("TiviMate E2"))
        self["homeBrandLogo"] = Pixmap()
        self["poweredBy"] = Label("Developed by opesboy")
        for i in range(8): self["nav%d" % i] = Label(nav_label(self.NAV[i]) if i < len(self.NAV) else "")
        self["navSelector"] = Pixmap()
        self["clock"] = Label("")
        self["date"] = Label("")
        self["banner"] = Pixmap()
        self["quality"] = Label(tr("TIVIMATE  •  PREMIUM IPTV"))
        self["featureTitle"] = Label(tr("YOUR ENTERTAINMENT, ONE PLACE"))
        self["featureMeta"] = Label(tr("Browse, discover and enjoy your library in one unified experience."))
        self["featureDesc"] = Label("")
        self["playNow"] = Label(tr("WATCH NOW"))
        self["recentTitle"] = Label(tr("Popular Show"))
        for i in range(6):
            self["poster%d" % i] = Pixmap()
            self["posterMetaTitle%d" % i] = Label("")
            self["posterMetaRate%d" % i] = Label("")
        self["posterSelector"] = Pixmap()
        self["status"] = Label("")
        if self.homeSkinName in ("skin2_dark", "skin3_accessibility"):
            lang = get_language()
            if lang == "ar":
                self["actionLabel0"] = Label("تبديل السيرفر")
                self["actionLabel1"] = Label("الباقات")
                self["actionLabel2"] = Label("اختيار القوائم")
                self["actionLabel3"] = Label("المفضلة")
                self["skin2HelpTitle"] = Label("أزرار الريموت")
                self["skin2HelpBody"] = Label("الأحمر: تبديل السيرفر   الأخضر: الباقات\nالأصفر: اختيار القوائم   الأزرق: المفضلة")
                self["skin2LangTitle"] = Label("اللغة العربية")
                self["skin2LangBody"] = Label("واجهة وقوائم عربية متناسقة وواضحة")
                self["skin2Key5"] = Label("المفتاح 5\nإعدادات الترجمة")
            elif lang == "fr":
                self["actionLabel0"] = Label("CHANGER SERVEUR")
                self["actionLabel1"] = Label("BOUQUETS")
                self["actionLabel2"] = Label("CHOISIR LISTE")
                self["actionLabel3"] = Label("FAVORIS")
                self["skin2HelpTitle"] = Label("Touches de la télécommande")
                self["skin2HelpBody"] = Label("Rouge: Changer serveur   Vert: Bouquets\nJaune: Choisir liste   Bleu: Favoris")
                self["skin2LangTitle"] = Label("Interface française")
                self["skin2LangBody"] = Label("Menus et informations adaptés à la langue")
                self["skin2Key5"] = Label("Touche 5\nRéglages des sous-titres")
            else:
                self["actionLabel0"] = Label("SWITCH SERVER")
                self["actionLabel1"] = Label("PACKAGES")
                self["actionLabel2"] = Label("CHOOSE LISTS")
                self["actionLabel3"] = Label("FAVORITES")
                self["skin2HelpTitle"] = Label("REMOTE SHORTCUTS")
                self["skin2HelpBody"] = Label("Red: Switch server   Green: Packages\nYellow: Choose lists   Blue: Favorites")
                self["skin2LangTitle"] = Label("LANGUAGE")
                self["skin2LangBody"] = Label("Menus and information follow the selected language")
                self["skin2Key5"] = Label("KEY 5\nSubtitle settings")
        # r169: artwork purge is tied only to an explicit BACK/EXIT from the main
        # Home screen. Internal child-screen closes/navigation must never trigger it.
        self._homeExitRequested = False
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "ok": self.ok, "cancel": self._exitFromHome, "menu": self.openFavorites,
            "red": self.openHomeServerPopup, "green": self.openContentPackages, "yellow": self.chooseHomeContent,
            "yellowlong": self.addRecentFavourite, "blue": self.openFavorites
        }, -1)
        self.clockTimer = eTimer()
        _connect_timer(self.clockTimer, self.updateClock)
        self.loadTimer = eTimer()
        _connect_timer(self.loadTimer, self.startLoad)
        # r163: Recent Movies is warmed through the existing bounded content
        # task manager.  No extra worker/thread pool is created.
        self.recentMoviePrefetchTimer = eTimer()
        _connect_timer(self.recentMoviePrefetchTimer, self._queueRecentMoviePrefetch)
        # Stalker/Ministra portals can complete the network request in a worker
        # while a Twisted reactor is unavailable or not integrated with Enigma2.
        # Deliver their Home result through an eTimer, the same UI-thread pattern
        # used by ContentHome.  This remains completely generic: it carries only
        # a source snapshot, a request token, and normalized items.
        self.stalkerRecentToken = 0
        self.stalkerRecentResult = None
        self.stalkerRecentTimer = eTimer()
        _connect_timer(self.stalkerRecentTimer, self._finishStalkerRecentLoad)

        # Update work happens only after the Home screen is visible and always
        # in a background thread, so it never delays loading IPTV content.
        self.updateCheckTimer = eTimer()
        self.updateCheckPollTimer = eTimer()
        self.updateDownloadPollTimer = eTimer()
        _connect_timer(self.updateCheckTimer, self._beginUpdateCheck)
        _connect_timer(self.updateCheckPollTimer, self._pollUpdateCheck)
        _connect_timer(self.updateDownloadPollTimer, self._pollUpdateDownload)
        self._updateCheckPending = None
        self._updateDownloadPending = None
        self._updateCandidate = None
        self._updateInstallProcess = None
        self._updateCheckStarted = False
        try: self.onClose.append(self._stopUpdateTimers)
        except Exception: pass
        try: self.onClose.append(self._stopStalkerRecentTimer)
        except Exception: pass
        try: self.onClose.append(self._stopRecentMoviePrefetchTimer)
        except Exception: pass
        try: self.onClose.append(self._invalidateHomeJobs)
        except Exception: pass
        # r168: leaving TiviMateE2 while INTERNAL cache is selected must leave
        # no artwork behind. Cancel late download writers first, then remove only
        # posters/backdrops/picons/logos; persistent data caches stay intact.
        try: self.onClose.append(self._clearInternalArtworkOnExit)
        except Exception: pass
        self.onLayoutFinish.append(self.layoutReady)

    def _exitFromHome(self):
        # Mark only the real application exit from Home. The onClose hook below
        # may also run for framework-driven closes, which must preserve artwork.
        self._homeExitRequested = True
        self.close()

    def _clearInternalArtworkOnExit(self):
        if not bool(getattr(self, "_homeExitRequested", False)):
            return
        try:
            from .estalker_picon import set_app_exiting
            set_app_exiting(True)
        except Exception:
            pass
        try:
            from .artwork_queue import set_app_exiting as set_artwork_exiting, cancel_all_artwork
            set_artwork_exiting(True)
            cancel_all_artwork()
        except Exception:
            pass
        # r170: on explicit Home exit with INTERNAL storage, purge every generated
        # cache (including all artwork) but retain only the Popular Show row
        # metadata. The poster image files themselves are intentionally deleted.
        try:
            self._purgeInternalCachesKeepPopularShow()
        except Exception:
            pass

    def _purgeInternalCachesKeepPopularShow(self):
        try:
            cfg = get_cache_settings() or {}
            if not is_internal_cache_active():
                return False
        except Exception:
            return False

        import shutil

        # Snapshot ONLY the main Home Popular Show metadata before cache removal.
        tmdb_popular = []
        try:
            tmdb_popular = _home_tmdb_cache_get("popular_movies") or []
        except Exception:
            tmdb_popular = []

        server_popular = {}
        try:
            folder = data_path("home_server_2026")
            if os.path.isdir(folder):
                for name in os.listdir(folder):
                    if not name.endswith(".json"):
                        continue
                    path = os.path.join(folder, name)
                    try:
                        with open(path, "r") as h:
                            payload = json.load(h) or {}
                        row = payload.get("popular_movies") if isinstance(payload, dict) else None
                        if isinstance(row, dict) and isinstance(row.get("items"), list) and row.get("items"):
                            server_popular[name] = {"popular_movies": row}
                    except Exception:
                        pass
        except Exception:
            pass

        # Remove the complete selected INTERNAL cache root: posters, backdrops,
        # picons/logos, metadata, source catalogs and Stalker SQLite/JSON caches.
        # Do NOT recreate the root on exit; it will be created lazily on next launch.
        try:
            cache_root = get_cache_root()
            if cache_root and os.path.realpath(cache_root).startswith("/var/tmp/tivimatee2-cache"):
                shutil.rmtree(cache_root, ignore_errors=True)
        except Exception:
            pass

        # r171 migration cleanup: older TiviMateE2 builds wrote artwork directly
        # under /var/tmp. Remove only files carrying TiviMateE2's own filename
        # prefixes, then remove a legacy folder only when it becomes empty. This
        # avoids touching unrelated Enigma2 plugins that may also use /var/tmp.
        legacy_artwork = {
            "/var/tmp/posters": ("poster_",),
            "/var/tmp/backdrops": ("backdrop_",),
            "/var/tmp/logos": ("logo_",),
            "/var/tmp/picons": ("picon_", "xst_live_picon_"),
        }
        for folder, prefixes in legacy_artwork.items():
            try:
                if not os.path.isdir(folder):
                    continue
                for name in os.listdir(folder):
                    path = os.path.join(folder, name)
                    if os.path.isfile(path) and any(name.startswith(prefix) for prefix in prefixes):
                        try:
                            os.remove(path)
                        except Exception:
                            pass
                try:
                    if not os.listdir(folder):
                        os.rmdir(folder)
                except Exception:
                    pass
            except Exception:
                pass

        # Remove generated data-side caches. User configuration, sources, filters,
        # favourites, resume/history and player settings are deliberately not cache
        # and are therefore preserved.
        transient_files = [
            data_path("home_feeds.json"),
            data_path("title_matches.json"),
            data_path("recent_media_cache.json"),
            data_path("catchup_verified.json"),
            data_path("bein_cache.json"),
            data_path("you_might_like_ratings.json"),
        ]
        transient_dirs = [
            data_path("content_landing"),
            data_path("home"),
            data_path("epg"),
            data_path("home_server_2026"),
        ]
        for path in transient_files:
            try:
                if os.path.isfile(path):
                    os.remove(path)
            except Exception:
                pass
        for path in transient_dirs:
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
            except Exception:
                pass

        # Rebuild ONLY Popular Show metadata caches; no poster/backdrop file is restored.
        try:
            if tmdb_popular:
                _home_tmdb_cache_put("popular_movies", tmdb_popular)
            elif os.path.isfile(HOME_TMDb_CACHE_FILE):
                os.remove(HOME_TMDb_CACHE_FILE)
        except Exception:
            pass
        try:
            folder = data_path("home_server_2026")
            if server_popular:
                ensure_dir(folder)
                for name, payload in server_popular.items():
                    try:
                        path = os.path.join(folder, name)
                        with open(path, "w") as h:
                            json.dump(payload, h, separators=(",", ":"), sort_keys=True)
                    except Exception:
                        pass
        except Exception:
            pass

        # Flush in-memory catalog/filter caches as well, otherwise the next launch
        # in the same Enigma2 process could still reuse data removed from disk.
        try:
            clear_catalog_memory()
        except Exception:
            pass
        try:
            from .filters import clear_source_cache
            clear_source_cache()
        except Exception:
            pass

        # r173 final sweep: cleanup helpers or a just-cancelled Deferred may have
        # briefly recreated the INTERNAL root while shutdown was in progress.
        # The artwork queue is hard-locked at this point, so remove the literal
        # root one final time without calling get_cache_root() (which could mkdir).
        try:
            shutil.rmtree("/var/tmp/tivimatee2-cache", ignore_errors=True)
        except Exception:
            pass
        return True

    def _applyRecentTitleLayout(self):
        """Keep the Home content heading on the right edge only for Arabic.
        Do not mirror the whole screen; only reposition this heading."""
        try:
            widget = self["recentTitle"]
            if not widget or not widget.instance:
                return
            lang = get_language()
            if self.isReferenceHome:
                x, y, w, h = (100, 610, 500, 42)
                if lang == "ar":
                    # Arabic heading sits at the far-right edge above the last poster.
                    x, w = (1650, 220)
            else:
                x, y, w, h = (55, 468, 560, 40)
                if lang == "ar":
                    # Skin 2: keep only this heading RTL-positioned; do not mirror Home.
                    x, w = (1650, 220)
            widget.instance.move(ePoint(sx(x), sy(y)))
            widget.instance.resize(eSize(sx(w), sy(h)))
        except Exception:
            pass

    def layoutReady(self):
        # Both Home skins scale their decoded hero at the Pixmap level.
        # This keeps Skin 1's backdrop stretched across its full panoramic frame.
        try:
            self["banner"].instance.setScale(1)
        except Exception:
            pass
        self.applyGlobalHero()
        self._applyRecentTitleLayout()
        self.updateFocus(); self.updateClock()
        try: self.clockTimer.start(30000, False)
        except Exception: pass
        try: self.loadTimer.start(250, True)
        except Exception: self.startLoad()
        # Give the visible Home request a short head start, then warm only
        # Recent Movies metadata in one of the existing CONTENT_TASKS workers.
        try: self.recentMoviePrefetchTimer.start(1000, True)
        except Exception: self._queueRecentMoviePrefetch()
        # Delay the request slightly so a slow or unavailable update endpoint
        # never affects the first paint of the home interface.
        if _load_update_settings().get("auto_check", True):
            try: self.updateCheckTimer.start(1500, True)
            except Exception: self._beginUpdateCheck()

    def _stopRecentMoviePrefetchTimer(self):
        try:
            self.recentMoviePrefetchTimer.stop()
        except Exception:
            pass

    def _queueRecentMoviePrefetch(self):
        if getattr(self, "_homeClosed", False):
            return
        source = dict(self.source or {})
        if source.get("type") not in ("xtream", "stalker"):
            return
        try:
            key = "recent-movies-prefetch|%s|%s|%s|%s" % (
                source.get("type") or "",
                source.get("url") or source.get("portal") or "",
                source.get("username") or "",
                source.get("mac") or "",
            )
            CONTENT_TASKS.submit(
                prefetch_recent_movies,
                args=(source, 25),
                key=key,
                area="recent_movies_prefetch",
            )
        except Exception:
            pass

    def _stopUpdateTimers(self):
        for timer in (getattr(self, "updateCheckTimer", None),
                      getattr(self, "updateCheckPollTimer", None),
                      getattr(self, "updateDownloadPollTimer", None)):
            try:
                if timer:
                    timer.stop()
            except Exception:
                pass

    def _stopStalkerRecentTimer(self):
        # Invalidate a finishing worker before the screen is destroyed.
        self.stalkerRecentToken = getattr(self, "stalkerRecentToken", 0) + 1
        self.stalkerRecentResult = None
        try:
            self.stalkerRecentTimer.stop()
        except Exception:
            pass

    def _invalidateHomeJobs(self):
        self._homeClosed = True
        self._sourceGeneration = getattr(self, "_sourceGeneration", 0) + 1
        self.featureRequestId = getattr(self, "featureRequestId", 0) + 1
        self.stalkerRecentToken = getattr(self, "stalkerRecentToken", 0) + 1
        self.stalkerRecentResult = None

    def _sourceJobValid(self, generation, source):
        if getattr(self, "_homeClosed", False):
            return False
        if generation != getattr(self, "_sourceGeneration", -1):
            return False
        try:
            return _source_identity(source or {}) == _source_identity(self.source or {})
        except Exception:
            return False

    def _beginUpdateCheck(self):
        if not _load_update_settings().get("auto_check", True):
            return
        if self._updateCheckStarted:
            return
        self._updateCheckStarted = True
        self._updateCheckPending = None

        def worker():
            try:
                self._updateCheckPending = check_for_update()
            except Exception:
                self._updateCheckPending = {}

        try:
            thread = threading.Thread(target=worker)
            thread.daemon = True
            thread.start()
            self.updateCheckPollTimer.start(200, True)
        except Exception:
            self._updateCheckPending = {}

    def _pollUpdateCheck(self):
        if self._updateCheckPending is None:
            try: self.updateCheckPollTimer.start(200, True)
            except Exception: pass
            return
        result = self._updateCheckPending or {}
        self._updateCheckPending = None
        if not result.get("available"):
            return
        self._updateCandidate = result
        version = result.get("version") or "1.0.3"
        revision = result.get("revision") or "?"
        notes = result.get("notes") or ""
        text = "A new TiviMate E2 update is available.\n\nVersion: %s (revision %s)" % (version, revision)
        if notes:
            text += "\n\n" + notes
        text += "\n\nDownload and install it now?"
        try:
            self.session.openWithCallback(self._onUpdatePrompt, MessageBox, text,
                type=MessageBox.TYPE_YESNO, timeout=20, default=False)
        except Exception:
            pass

    def _onUpdatePrompt(self, answer):
        if not answer or not self._updateCandidate:
            return
        package = self._updateCandidate.get("package")
        if not package:
            return
        self._updateDownloadPending = None
        try: self["status"].setText(tr("Downloading TiviMate E2 update..."))
        except Exception: pass

        def worker():
            self._updateDownloadPending = download_package(package)

        try:
            thread = threading.Thread(target=worker)
            thread.daemon = True
            thread.start()
            self.updateDownloadPollTimer.start(200, True)
        except Exception:
            self._updateDownloadPending = {"ok": False, "message": "Unable to start download"}

    def _pollUpdateDownload(self):
        if self._updateDownloadPending is None:
            try: self.updateDownloadPollTimer.start(200, True)
            except Exception: pass
            return
        result = self._updateDownloadPending or {}
        self._updateDownloadPending = None
        if not result.get("ok"):
            try: self["status"].setText(tr(""))
            except Exception: pass
            self._showUpdateMessage("Update download failed.\n\n%s" % (result.get("message") or "Please try again later."))
            return
        command = install_command(result)
        if not command:
            try: self["status"].setText(tr(""))
            except Exception: pass
            self._showUpdateMessage("The verified update package could not be installed.")
            return
        try: self["status"].setText(tr("Installing TiviMate E2 update..."))
        except Exception: pass
        try:
            process = eConsoleAppContainer()
            self._updateInstallProcess = process
            try: process.appClosed.append(self._onUpdateInstallFinished)
            except Exception: process.appClosed.get().append(self._onUpdateInstallFinished)
            process.execute("/bin/sh", "sh", "-c", command)
        except Exception:
            try: self["status"].setText(tr(""))
            except Exception: pass
            self._showUpdateMessage("Unable to start the update installer.")

    def _onUpdateInstallFinished(self, status):
        self._updateInstallProcess = None
        try: self["status"].setText(tr(""))
        except Exception: pass
        if status == 0:
            self._showUpdateMessage("TiviMate E2 was updated successfully.\n\nPlease restart the Enigma2 GUI to use the new version.")
        else:
            self._showUpdateMessage("The update installer returned an error.\n\nYour current TiviMate E2 installation has not been changed.")

    def _showUpdateMessage(self, text):
        try:
            self.session.open(MessageBox, text, type=MessageBox.TYPE_INFO, timeout=12)
        except Exception:
            pass

    def _sourceKey(self, source):
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("url", "").rstrip("/"), source.get("username", ""), source.get("mac", ""))

    def _loadActiveSource(self):
        sources = get_sources()
        if not sources: return None
        try:
            with open_text(self.ACTIVE_FILE, "r") as f: key = json.load(f).get("key", "")
            for source in sources:
                if self._sourceKey(source) == key: return source
        except Exception: pass
        for source in sources:
            if source.get("type") == "xtream": return source
        return sources[0]

    def _saveActiveSource(self):
        try:
            ensure_dir(os.path.dirname(self.ACTIVE_FILE))
            with open_text(self.ACTIVE_FILE, "w") as f: json.dump({"key": self._sourceKey(self.source)}, f)
        except Exception: pass

    def updateClock(self):
        now = time.localtime()
        self["clock"].setText(time.strftime("%H:%M", now))
        self["date"].setText(time.strftime("%d.%m.%Y", now))

    def _heroRating(self, row):
        item = row.get("item") or {}
        raw = row.get("rating") or item.get("rating") or item.get("vote_average") or item.get("rating_5based") or 0
        try:
            value = float(str(raw).replace(",", "."))
            if value > 10.0:
                value = value / 10.0
            return max(0.0, min(10.0, value))
        except Exception:
            return 0.0

    def _heroYear(self, row):
        item = row.get("item") or {}
        raw = " ".join(str(x or "") for x in (
            row.get("year"), item.get("year"), item.get("releaseDate"),
            item.get("release_date"), item.get("first_air_date"), self._title(row)
        ))
        match = re.search(r"\b(19|20)\d{2}\b", raw)
        return match.group(0) if match else ""

    def _heroOverview(self, row):
        item = row.get("item") or {}
        return str(
            row.get("overview") or item.get("plot") or item.get("description") or
            item.get("overview") or ""
        ).strip()

    def _heroGenre(self, row):
        item = row.get("item") or {}
        return str(row.get("genre") or item.get("genre") or "").strip()

    def _enrichHeroAsync(self, key, row):
        generation = self._generation
        title = self._title(row)
        kind = "series" if self._isSeries(row) else "vod"
        item = row.get("item") or {}
        year = self._heroYear(row) or item.get("year") or ""
        def worker():
            try:
                found = TMDbClient().search_artwork(title, kind=kind, year=year) or {}
            except Exception:
                found = {}
            if generation != self._generation or not found:
                return
            data = self._load()
            rec = data.get(key)
            if not isinstance(rec, dict):
                return
            rec["rating"] = found.get("vote_average") or rec.get("rating") or ""
            rec["year"] = str(found.get("release_date") or found.get("first_air_date") or rec.get("year") or "")[:4]
            rec["overview"] = found.get("overview") or rec.get("overview") or ""
            path = found.get("backdrop_path") or ""
            if path and not rec.get("backdrop"):
                rec["backdrop"] = IMAGE_BASE + "w1280" + path
            data[key] = rec
            self._save(data)
            # Update only if this exact item is still selected.
            selected = self._selected()
            if not selected or selected[0] != key or generation != self._generation:
                return
            rating = self._heroRating(rec)
            stars = int(round(rating / 2.0)) if rating else 0
            star_text = ("★" * stars) + ("☆" * (5 - stars)) if rating else "☆☆☆☆☆"
            year_text = self._heroYear(rec)
            self["heroStars"].setText("%s   %.1f/10%s" % (
                star_text, rating, ("  •  " + year_text) if year_text else ""
            ) if rating else star_text)
            overview = self._heroOverview(rec)
            if overview:
                self["heroDesc"].setText(overview[:280])
            backdrop = self._asset(rec)
            if backdrop:
                self._loadArtwork(backdrop, "hero", generation)
        t = threading.Thread(target=worker, name="TiviMateContinueHeroInfo")
        t.daemon = True
        t.start()


    def updateFocus(self):
        if self["navSelector"].instance:
            try:
                if self.homeSkinName in ("skin2_dark", "skin3_accessibility"):
                    widths = [145] * len(self.NAV)
                    x = self.NAV_X[self.navIndex] + ((widths[self.navIndex] - 180) // 2)
                    y = 79
                else:
                    x = self.NAV_X[self.navIndex]
                    y = self.NAV_Y[self.navIndex]
                self["navSelector"].instance.move(ePoint(sx(x), sy(y)))
                self["navSelector"].show() if self.focus == "nav" else self["navSelector"].hide()
            except Exception:
                pass
        if self["posterSelector"].instance:
            selector_x = self.POSTER_X[self.posterIndex]
            selector_y = self.POSTER_Y
            if self.homeSkinName in ("skin2_dark", "skin3_accessibility"):
                selector_x -= 2
                selector_y -= 2
            self["posterSelector"].instance.move(ePoint(sx(selector_x), sy(selector_y)))
            focused = (self.focus == "posters" and bool(self.recent))
            self["posterSelector"].show() if focused else self["posterSelector"].hide()
            if self.homeSkinName in ("skin2_dark", "skin3_accessibility"):
                for i in range(6):
                    try:
                        color = "#111820" if (focused and i == self.posterIndex) else "#F7FBFF"
                        self["posterMetaTitle%d" % i].instance.setForegroundColor(parseColor(color))
                    except Exception:
                        pass


    def left(self):
        if self.focus == "nav":
            self.navIndex = (self.navIndex - 1) % len(self.NAV)
        else:
            self.posterIndex = max(0, self.posterIndex - 1)
            self.updateFeature()
        self.updateFocus()

    def right(self):
        if self.focus == "nav":
            self.navIndex = (self.navIndex + 1) % len(self.NAV)
        else:
            self.posterIndex = min(max(0, len(self.recent) - 1), self.posterIndex + 1)
            self.updateFeature()
        self.updateFocus()

    def up(self):
        self.focus = "nav"
        self.updateFocus()

    def down(self):
        if self.recent:
            self.focus = "posters"
            self.updateFeature()
        self.updateFocus()


    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def ok(self):
        if self.focus == "posters":
            self.playRecent()
            return
        index = self.navIndex
        if index == 0:
            self._openPageOnce(TiviMateE2Search, self.source)
            return
        if index == 1:
            return
        if index == 2:
            self.openMedia("live")
            return
        if index == 3:
            self.openContentHome("vod")
            return
        if index == 4:
            self.openContentHome("series")
            return
        if index == 5:
            self.openContentPackages()
            return
        if index == 6:
            self._openPageOnce(ContinueWatchingScreen, self.source)
            return
        if index == 7:
            self.openSettings()
            return


    def addRecentFavourite(self):
        if self.focus != "posters" or not self.recent:
            self["status"].setText(tr("Select a movie poster first"))
            return
        item = self.recent[min(self.posterIndex, len(self.recent) - 1)]
        if is_favourite(self.source, "vod", item):
            self["status"].setText(tr("Movie is already in favorites"))
        elif add_favourite(self.source, "vod", item):
            self["status"].setText(tr("Movie added to favorites"))
        else:
            self["status"].setText(tr("Unable to save favorite"))

    def openHomeServerPopup(self):
        sources = [x for x in (get_sources() or []) if (x or {}).get("type") in ("xtream", "stalker")]
        if not sources:
            self.session.open(MessageBox, tr("No IPTV servers found."), MessageBox.TYPE_INFO, timeout=3)
            return
        self.session.openWithCallback(self._homeServerPopupClosed, HomeServerPopup, sources, self.source)

    def _homeServerPopupClosed(self, source=None):
        if not source:
            return
        try:
            if self._sourceKey(source) == self._sourceKey(self.source or {}):
                return
        except Exception:
            pass
        self.selectServer(source)

    def openContinueWatching(self):
        self._openPageOnce(ContinueWatchingScreen, self.source)

    def chooseHomeContent(self):
        choices = [
            (tr("Popular Show"), "popular_movies"),
            (tr("Popular TV Shows"), "popular_series"),
            (tr("Movies You Might Like"), "trending_movies"),
            (tr("TV Shows You Might Like"), "trending_series"),
        ]
        def selected(answer):
            if not answer:
                return
            value = answer[1] if isinstance(answer, (tuple, list)) and len(answer) > 1 else None
            if not value:
                return
            self.homeContentMode = value
            try:
                cfg = _load_home_appearance()
                _save_home_appearance(cfg.get("skin", "skin2_dark"), value)
            except Exception:
                pass
            self.globalHero = True
            self.posterIndex = 0
            self.recent = []
            self.resetPosters()
            self.startLoad()
        from Screens.ChoiceBox import ChoiceBox
        self.session.openWithCallback(selected, ChoiceBox, title=tr("Home Content"), list=choices)

    def refreshHome(self):
        # YELLOW must refresh only the current Home feed. Invalidate every older
        # worker first so a late Recent/Trending result cannot overwrite Popular.
        current_mode = getattr(self, "homeContentMode", None)
        if not current_mode:
            try:
                current_mode = _load_home_appearance().get("content", "popular_movies")
            except Exception:
                current_mode = "popular_movies"
        self.homeContentMode = current_mode or "popular_movies"
        self.globalHero = True
        try:
            self._sourceGeneration += 1
        except Exception:
            self._sourceGeneration = 1
        try:
            self.stalkerRecentToken += 1
            self.stalkerRecentResult = None
            self.stalkerRecentTimer.stop()
        except Exception:
            pass
        self.posterIndex = 0
        self.recent = []
        self.resetPosters()
        self.startLoad()

    def openContentHome(self, kind):
        if not self.source:
            self.openSettings()
            return
        source_type = self.source.get("type")
        if source_type in ("xtream", "stalker"):
            self._openPageOnce(ContentHomeScreen, self.source, kind)
            return
        self.session.open(MessageBox, "This section requires a server with Movies and TV Shows.", MessageBox.TYPE_INFO)

    def openMedia(self, kind):
        if not self.source:
            self.openSettings()
            return
        if kind in ("vod", "series") and self.source.get("type") not in ("xtream", "stalker"):
            self.session.open(MessageBox, "This section requires a server with Movies and TV Shows.", MessageBox.TYPE_INFO)
            return
        self._openPageOnce(MediaScreen, self.source, kind)

    def openFavorites(self):
        self.session.open(FavoritesScreen)

    def openLiveTools(self):
        if self.kind != "live":
            self.openFavorites(); return
        choices = [(tr("Favorites"), "favorites")]
        if self.source.get("type") == "stalker":
            pin_state = _load_stalker_pin(self.source)
            if self.focus == "category":
                choices.append((tr("Hide this package"), "hide_category"))
                row = self["category"].getCurrent()
                cid = str(row[1] or "") if row else ""
                if cid and not cid.startswith("__"):
                    if cid in pin_state["categories"]:
                        choices.append((tr("Unlock this package"), "unlock_category"))
                    else:
                        choices.append((tr("Lock this package"), "lock_category"))
            elif self.current():
                choices.append((tr("Hide this channel"), "hide_channel"))
                channel_id = _live_item_id(self.current())
                if channel_id in pin_state["channels"]:
                    choices.append((tr("Unlock this channel"), "unlock_channel"))
                else:
                    choices.append((tr("Lock this channel"), "lock_channel"))
            choices.append((tr("Change parental PIN"), "change_pin"))
            choices.append((tr("Stalker player engines"), "stalker_engines"))
            choices.append((tr("Recently watched"), "stalker_recent"))
            state = _load_stalker_hidden(self.source)
            if state["categories"]:
                choices.append((tr("Show hidden packages"), "show_hidden_packages"))
            if state["channels"]:
                choices.append((tr("Show hidden channels"), "show_hidden_channels"))
        self.session.openWithCallback(self._liveToolSelected, ChoiceBox, title=tr("Live options"), list=choices)

    def _liveToolSelected(self, selected=None):
        if not selected:
            return
        action = selected[1] if isinstance(selected, (tuple, list)) and len(selected) > 1 else selected
        if action == "favorites":
            self.openFavorites(); return
        if action == "hide_category":
            self._hideCurrentStalkerCategory(); return
        if action == "hide_channel":
            self._hideCurrentStalkerChannel(); return
        if action == "show_hidden_packages":
            self._showHiddenStalkerPackages(); return
        if action == "show_hidden_channels":
            self._showHiddenStalkerChannels(); return
        if action == "catchup":
            self._openStalkerCatchup(); return
        if action in ("lock_category", "lock_channel"):
            self._lockCurrentStalkerItem(action == "lock_category"); return
        if action in ("unlock_category", "unlock_channel"):
            self._requestStalkerPin(("unlock", action == "unlock_category")); return
        if action == "change_pin":
            self._requestStalkerPin(("change_pin", None)); return
        if action == "stalker_engines":
            self._openStalkerEngineSettings(); return
        if action == "stalker_recent":
            self._openStalkerRecentlyWatched(); return

    def _openStalkerRecentlyWatched(self):
        if self.source.get("type") != "stalker":
            return
        rows = _load_stalker_recent(self.source, 30)
        choices = []
        for resume_key, row in rows:
            title = str(row.get("title") or tr("Untitled"))
            position = int(row.get("position", 0) or 0)
            length = int(row.get("length", 0) or 0)
            if length > 0:
                pct = max(0, min(99, int(position * 100 / length)))
                label = "%s  •  %d%%" % (title, pct)
            else:
                label = "%s  •  %02d:%02d" % (title, position // 60, position % 60)
            choices.append((label, (resume_key, row)))
        if not choices:
            self.session.open(MessageBox, tr("No recently watched Stalker items."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerRecentlyWatched, ChoiceBox, title=tr("Recently watched"), list=choices)

    def _playStalkerRecentlyWatched(self, selected=None):
        if not selected:
            return
        try:
            _resume_key_value, row = selected[1]
            item = dict(row.get("item") or {})
            kind = str(row.get("kind") or "vod")
            if kind not in ("vod", "series"):
                kind = "vod"
            item["_source_type"] = "stalker"
            item["_source_key"] = _source_identity(self.source)
            item["_kind"] = kind
            url = StalkerClient(dict(self.source)).stream_url(item, kind)
            if not url:
                raise RuntimeError(tr("Portal returned no playable URL"))
            ref = eServiceReference(_stalker_service_type(self.source, kind), 0, url)
            ref.setName(item.get("name") or item.get("title") or "IPTV")
            self.session.openWithCallback(self.playerClosed, TiviMatePlayer, ref, item)
        except Exception as exc:
            self.session.open(MessageBox, "%s\n%s" % (tr("Unable to play this item."), exc), MessageBox.TYPE_ERROR)

    def _openStalkerEngineSettings(self):
        if self.source.get("type") != "stalker":
            return
        self._stalkerEngineValues = _load_stalker_service_types(self.source)
        self._chooseStalkerEngine("live")

    def _chooseStalkerEngine(self, kind):
        labels = {"live": tr("Stalker Live player"), "vod": tr("Stalker Movies player"), "series": tr("Stalker Series player")}
        current = int(self._stalkerEngineValues.get(kind, 4097))
        choices = []
        for value in STALKER_SERVICE_TYPE_CHOICES:
            choices.append(((u"✓ " if value == current else u"") + str(value), value))
        self.session.openWithCallback(lambda selected, k=kind: self._stalkerEngineSelected(k, selected), ChoiceBox, title=labels.get(kind, kind), list=choices)

    def _stalkerEngineSelected(self, kind, selected=None):
        if not selected:
            return
        try:
            value = int(selected[1])
        except Exception:
            return
        if value not in STALKER_SERVICE_TYPE_CHOICES:
            return
        self._stalkerEngineValues[kind] = value
        order = ("live", "vod", "series")
        try:
            next_kind = order[order.index(kind) + 1]
        except Exception:
            next_kind = None
        if next_kind:
            return self._chooseStalkerEngine(next_kind)
        if _save_stalker_service_types(self.source, self._stalkerEngineValues):
            self.session.open(MessageBox, tr("Stalker player engines saved."), MessageBox.TYPE_INFO, timeout=3)
        else:
            self.session.open(MessageBox, tr("Unable to save Stalker player engines."), MessageBox.TYPE_ERROR)

    def _lockCurrentStalkerItem(self, is_category=False):
        if self.source.get("type") != "stalker":
            return
        state = _load_stalker_pin(self.source)
        if is_category:
            row = self["category"].getCurrent()
            if not row:
                return
            item_id = str(row[1] or "")
            if not item_id or item_id.startswith("__"):
                self.session.open(MessageBox, tr("This package cannot be locked."), MessageBox.TYPE_INFO); return
            state["categories"].add(item_id)
            state["category_names"][item_id] = str(row[0] or item_id)
            message = tr("Package locked.")
        else:
            item = self.current()
            if not item:
                return
            item_id = _live_item_id(item)
            if not item_id:
                return
            state["channels"].add(item_id)
            state["channel_names"][item_id] = str(item.get("name") or item.get("title") or item_id)
            message = tr("Channel locked.")
        _save_stalker_pin(self.source, state)
        try: self["desc"].setText(message)
        except Exception: pass

    def _requestStalkerPin(self, action):
        if time.time() < getattr(self, "_pinBlockedUntil", 0):
            wait = max(1, int(self._pinBlockedUntil - time.time()))
            self.session.open(MessageBox, "%s %s" % (tr("Try again in"), wait), MessageBox.TYPE_ERROR); return
        self._pinPendingAction = action
        self.session.openWithCallback(self._stalkerPinEntered, VirtualKeyBoard, title=tr("Enter parental PIN"), text="")

    def _stalkerPinEntered(self, value=None):
        if value is None:
            self._pinPendingAction = None
            return
        state = _load_stalker_pin(self.source)
        if str(value).strip() != str(state.get("pin") or "0000"):
            self._pinFailures = getattr(self, "_pinFailures", 0) + 1
            if self._pinFailures >= 3:
                self._pinBlockedUntil = time.time() + 30
                self._pinFailures = 0
            self._pinPendingAction = None
            self.session.open(MessageBox, tr("Incorrect PIN"), MessageBox.TYPE_ERROR); return
        self._pinFailures = 0
        action = self._pinPendingAction
        self._pinPendingAction = None
        if not action:
            return
        kind, payload = action
        if kind == "play":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLivePlayerNow()
        if kind == "category":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLockedCategoryNow()
        if kind == "unlock":
            is_category = bool(payload)
            state = _load_stalker_pin(self.source)
            if is_category:
                row = self["category"].getCurrent()
                item_id = str(row[1] or "") if row else ""
                state["categories"].discard(item_id)
                state["category_names"].pop(item_id, None)
            else:
                item_id = _live_item_id(self.current())
                state["channels"].discard(item_id)
                state["channel_names"].pop(item_id, None)
            _save_stalker_pin(self.source, state)
            try: self["desc"].setText(tr("Lock removed."))
            except Exception: pass
            return
        if kind == "change_pin":
            self.session.openWithCallback(self._stalkerNewPinEntered, VirtualKeyBoard, title=tr("Enter new 4-digit PIN"), text="")

    def _stalkerNewPinEntered(self, value=None):
        value = str(value or "").strip()
        if not (len(value) == 4 and value.isdigit()):
            self.session.open(MessageBox, tr("PIN must contain exactly 4 digits."), MessageBox.TYPE_ERROR); return
        state = _load_stalker_pin(self.source)
        state["pin"] = value
        _save_stalker_pin(self.source, state)
        self.stalkerPinUnlockedUntil = time.time() + 300
        self.session.open(MessageBox, tr("Parental PIN changed."), MessageBox.TYPE_INFO)

    def _isCurrentStalkerCategoryLocked(self):
        if self.source.get("type") != "stalker":
            return False
        row = self["category"].getCurrent()
        cid = str(row[1] or "") if row else ""
        return bool(cid and cid in _load_stalker_pin(self.source)["categories"])

    def _isCurrentStalkerChannelLocked(self):
        if self.source.get("type") != "stalker":
            return False
        return _live_item_id(self.current()) in _load_stalker_pin(self.source)["channels"]

    def _hideCurrentStalkerCategory(self):
        row = self["category"].getCurrent()
        if not row:
            return
        name, cid = row[0], str(row[1] or "")
        if not cid or cid.startswith("__"):
            self.session.open(MessageBox, tr("This package cannot be hidden."), MessageBox.TYPE_INFO); return
        state = _load_stalker_hidden(self.source)
        state["categories"].add(cid)
        state["category_names"][cid] = str(name or cid)
        _save_stalker_hidden(self.source, state)
        try:
            rows = [x for x in list(self["category"].list or []) if str(x[1]) != cid]
            self["category"].setList(rows)
            self["list"].setList([])
            self.focus = "category"
            self["desc"].setText(tr("Package hidden. Use MENU to restore it."))
        except Exception:
            pass

    def _hideCurrentStalkerChannel(self):
        item = self.current()
        if not item:
            return
        channel_id = _live_item_id(item)
        if not channel_id:
            return
        state = _load_stalker_hidden(self.source)
        state["channels"].add(channel_id)
        state["channel_names"][channel_id] = str(item.get("name") or item.get("title") or channel_id)
        _save_stalker_hidden(self.source, state)
        self.showItems([x for x in self.mediaItemsCurrent if _live_item_id(x) != channel_id])
        try: self["desc"].setText(tr("Channel hidden. Use MENU to restore it."))
        except Exception: pass

    def _showHiddenStalkerPackages(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["category_names"].get(cid, cid), ("category", cid)) for cid in sorted(state["categories"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden packages."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden packages"), list=choices)

    def _showHiddenStalkerChannels(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["channel_names"].get(chid, chid), ("channel", chid)) for chid in sorted(state["channels"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden channels."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden channels"), list=choices)

    def _restoreHiddenStalkerItem(self, selected=None):
        if not selected:
            return
        try:
            kind, item_id = selected[1]
        except Exception:
            return
        state = _load_stalker_hidden(self.source)
        item_id = str(item_id)
        if kind == "category":
            state["categories"].discard(item_id)
            state["category_names"].pop(item_id, None)
            message = tr("Package restored.")
        else:
            state["channels"].discard(item_id)
            state["channel_names"].pop(item_id, None)
            message = tr("Channel restored.")
        _save_stalker_hidden(self.source, state)
        try:
            if kind == "category" and hasattr(self, "loadCategories"):
                self.loadCategories()
            elif kind == "channel" and hasattr(self, "loadSelectedCategory"):
                self.loadSelectedCategory()
        except Exception:
            pass
        try: self["desc"].setText(message)
        except Exception: pass

    def _openStalkerCatchup(self):
        item = self.current()
        if not item or self.source.get("type") != "stalker":
            return
        self._catchupItem = dict(item)
        self._catchupResult = None
        try: self["desc"].setText(tr("Loading catch-up programmes..."))
        except Exception: pass
        source = dict(self.source)
        channel_id = _live_item_id(item)
        def worker():
            rows, error = [], ""
            try:
                rows = StalkerClient(source).short_epg(channel_id, limit=20, force=True) or []
            except Exception as exc:
                error = str(exc)
            self._catchupResult = (rows, error)
        threading.Thread(target=worker, name="TiviMateStalkerCatchup", daemon=True).start()
        self._catchupTimer = eTimer()
        _connect_timer(self._catchupTimer, self._finishStalkerCatchupLoad)
        try: self._catchupTimer.start(150, False)
        except Exception: pass

    def _finishStalkerCatchupLoad(self):
        result = getattr(self, "_catchupResult", None)
        if result is None:
            try: self._catchupTimer.start(150, False)
            except Exception: pass
            return
        try: self._catchupTimer.stop()
        except Exception: pass
        self._catchupResult = None
        rows, error = result
        now = int(time.time())
        choices = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._epgTimestamp(row, True)
            end = self._epgTimestamp(row, False)
            title = self._decodeEpgText(row.get("title") or row.get("name") or row.get("programme"))
            archive = row.get("has_archive") or row.get("archive") or row.get("allow_archive") or row.get("tv_archive")
            channel = getattr(self, "_catchupItem", {}) or {}
            channel_archive = (
                channel.get("has_archive") or channel.get("archive") or
                channel.get("allow_archive") or channel.get("tv_archive") or
                channel.get("archive_duration") or channel.get("tv_archive_duration")
            )
            event_archived = str(archive or "").strip().lower() in ("1", "true", "yes", "on")
            channel_archived = str(channel_archive or "").strip().lower() not in ("", "0", "false", "no", "off")
            if begin and end and end <= now and title and (event_archived or channel_archived):
                payload = dict(row)
                payload["_begin"] = begin
                payload["_end"] = end
                label = "%s  %s" % (time.strftime("%d/%m %H:%M", time.localtime(begin)), title)
                choices.append((label, payload))
        if not choices:
            message = tr("No catch-up programmes are available for this channel.")
            if error:
                message += "\n" + error
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerCatchup, ChoiceBox, title=tr("Catch-up / Archive"), list=choices)

    def _playStalkerCatchup(self, selected=None):
        if not selected:
            return
        event = dict(selected[1] or {})
        item = getattr(self, "_catchupItem", {}) or {}
        try:
            client = StalkerClient(dict(self.source))
            url = client.create_catchup_link(item, event)
            if not url:
                raise RuntimeError(tr("Portal returned no archive link"))

            service_type = _stalker_service_type(self.source, "live")
            title = self._decodeEpgText(event.get("title") or event.get("name")) or item.get("name") or "Catch-up"
            ref = eServiceReference(service_type, 0, url)
            ref.setName(title)

            play_item = dict(item)
            play_item["_source_type"] = "stalker"
            play_item["_source_key"] = _source_identity(self.source)
            play_item["_kind"] = "live"
            play_item["_catchup"] = True
            play_item["name"] = title

            self.session.openWithCallback(
                self.playerClosed, TiviMatePlayer, ref, play_item
            )
        except Exception as exc:
            self.session.open(
                MessageBox,
                "%s: %s" % (tr("Unable to play catch-up"), exc),
                MessageBox.TYPE_ERROR
            )

    def openLiveColorMenu(self):
        if self.kind != "live":
            return
        current = self.channelSettings.get("live_theme", "turquoise")
        choices = []
        for name, value in LIVE_STYLE_CHOICES:
            label = ("✓ " if value == current else "") + name
            choices.append((label, value))
        self.session.openWithCallback(self._liveStyleSelected, ChoiceBox, title="Choose Live style", list=choices)

    def _liveStyleSelected(self, selected=None):
        if not selected:
            return
        try:
            theme = selected[1]
        except Exception:
            return
        if theme not in LIVE_STYLE_PALETTES:
            return
        self.channelSettings["live_theme"] = theme
        self.channelSettings["live_color"] = LIVE_STYLE_PALETTES[theme]["accent"]
        _save_channel_settings(self.channelSettings)
        source = dict(self.source)
        try:
            self.close()
            self._openPageOnce(MediaScreen, source, "live")
        except Exception:
            pass


    def openContentPackages(self):
        if not self.source:
            self.session.open(MessageBox, tr("Add an IPTV source first."), MessageBox.TYPE_INFO, timeout=4)
            return
        if self.source.get("type") not in ("xtream", "stalker"):
            self.session.open(MessageBox, tr("Movies and TV Shows packages are available for Xtream and Stalker sources."), MessageBox.TYPE_INFO, timeout=5)
            return
        self._openPageOnce(ContentPackagesScreen, self.source)

    def openSettings(self):
        self._openPageOnce(SettingsDashboard)

    def selectServer(self, source):
        # r183: a Home server switch is a clean source boundary. Invalidate all
        # old async work and clear only in-memory state; persistent caches stay
        # isolated per source and are reused when switching back.
        self._sourceGeneration = getattr(self, "_sourceGeneration", 0) + 1
        self.featureRequestId = getattr(self, "featureRequestId", 0) + 1
        self.stalkerRecentToken = getattr(self, "stalkerRecentToken", 0) + 1
        self.stalkerRecentResult = None
        try:
            self.stalkerRecentTimer.stop()
        except Exception:
            pass
        self.homeMovieServerItems = []
        self.homeMovieIndexLoading = False
        # Server switching always lands on the Home default feed. This prevents
        # stale legacy Recent Added state from being revived for the new source.
        self.homeContentMode = "popular_movies"
        try:
            cfg = _load_home_appearance()
            _save_home_appearance(cfg.get("skin", "skin2_dark"), "popular_movies")
        except Exception:
            pass
        self.source = dict(source or {})
        self._saveActiveSource()
        self.recent = []
        self.posterIndex = 0
        self.globalHero = True
        self.resetPosters()
        self.startLoad()

    def resetPosters(self):
        for i in range(6):
            try: self["poster%d" % i].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "poster_placeholder.png"))
            except Exception: pass
            try:
                self["posterMetaTitle%d" % i].setText(tr(""))
                self["posterMetaRate%d" % i].setText(tr(""))
            except Exception: pass
        self.applyGlobalHero()

    def applyGlobalHero(self):
        """Render the application hero only until a selected poster supplies its own backdrop."""
        self.featureRequestId += 1
        request_id = self.featureRequestId
        self["quality"].setText(tr("TIVIMATE  •  PREMIUM IPTV"))
        self["featureTitle"].setText(tr("YOUR ENTERTAINMENT, ONE PLACE"))
        self["featureMeta"].setText(tr("Browse, discover and enjoy your library in one unified experience."))
        self["featureDesc"].setText(tr(""))
        self["playNow"].setText(tr("WATCH NOW"))
        # The Home row is never Recent Added anymore. While a feed is loading,
        # show the active Home feed title instead of the removed legacy label.
        home_labels = {
            "popular_movies": tr("Popular Show"),
            "popular_series": tr("Popular TV Shows"),
            "trending_movies": tr("Movies You Might Like"),
            "trending_series": tr("TV Shows You Might Like"),
        }
        self["recentTitle"].setText(home_labels.get(getattr(self, "homeContentMode", "popular_movies"), tr("Popular Show")))
        self._applyRecentTitleLayout()
        hero = os.path.join(PLUGIN_PATH, "skins", "tivimate_global_hero_r70.png")
        try:
            self.decodeImage(6, hero, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        except Exception:
            try: self["banner"].instance.setPixmapFromFile(hero)
            except Exception: pass

    def _homeRecentCacheKey(self, source=None, mode=None):
        mode = str(mode or getattr(self, "homeContentMode", "recent_movies") or "recent_movies")
        raw = "%s|%s" % (_source_identity(source or self.source or {}), mode)
        try:
            return hashlib.sha1(raw.encode("utf-8")).hexdigest()
        except Exception:
            return hashlib.sha1(str(raw).encode("utf-8")).hexdigest()

    def _loadHomeRecentCache(self):
        """Read only the six cached Recent rows for this source/mode."""
        path = _home_recent6_file(self.source or {}, getattr(self, "homeContentMode", "recent_movies"))
        try:
            if not os.path.isfile(path):
                return []
            with open_text(path, "r") as handle:
                payload = json.load(handle) or {}
            items = payload.get("items") or []
            if not isinstance(items, list):
                return []
            return items[:6]
        except Exception:
            return []

    def _saveHomeRecentCache(self, items, source=None):
        """Store only the final six Recent rows; never save a full provider index."""
        source = source or self.source or {}
        mode = getattr(self, "homeContentMode", "recent_movies")
        path = _home_recent6_file(source, mode)
        try:
            ensure_dir(os.path.dirname(path))
            payload = {
                "saved": int(time.time()),
                "mode": str(mode),
                "items": list(items or [])[:6],
            }
            tmp = path + ".tmp"
            with open_text(tmp, "w") as handle:
                json.dump(payload, handle)
            try:
                atomic_replace(tmp, path)
            except Exception:
                os.rename(tmp, path)
        except Exception:
            pass

    def _paintCachedRecent(self):
        cached = self._loadHomeRecentCache()
        if not cached:
            return False
        self._recentReady(cached, save_cache=False, background=False)
        return True

    def _homeMovieIndexCacheKey(self, source=None):
        try:
            return hashlib.sha1(_source_identity(source or self.source or {}).encode("utf-8")).hexdigest()
        except Exception:
            return hashlib.sha1(str(_source_identity(source or self.source or {})).encode("utf-8")).hexdigest()

    def _loadCachedHomeMovieIndex(self):
        try:
            if not os.path.isfile(_home_movie_index_file()):
                return []
            with open_text(_home_movie_index_file(), "r") as handle:
                payload = json.load(handle) or {}
            row = (payload.get("sources") or {}).get(self._homeMovieIndexCacheKey(), {})
            items = row.get("items") or []
            return list(items or [])
        except Exception:
            return []

    def _saveCachedHomeMovieIndex(self, rows, source=None):
        try:
            ensure_dir(os.path.dirname(_home_movie_index_file()))
            payload = {}
            if os.path.isfile(_home_movie_index_file()):
                try:
                    with open_text(_home_movie_index_file(), "r") as handle:
                        payload = json.load(handle) or {}
                except Exception:
                    payload = {}
            sources = payload.get("sources")
            if not isinstance(sources, dict):
                sources = {}
            # Keep enough rows for fast in-memory matching, but not an unlimited catalog.
            sources[self._homeMovieIndexCacheKey(source)] = {
                "saved": int(time.time()),
                "items": list(rows or [])[:2500],
            }
            payload["sources"] = sources
            with open_text(_home_movie_index_file(), "w") as handle:
                json.dump(payload, handle)
        except Exception:
            pass

    def _scheduleHomeMovieIndexWarmup(self):
        # Never block initial Home rendering. Wait briefly until the TMDb cards
        # are already on screen, then warm the provider index in the background.
        def delayed():
            try:
                time.sleep(0.8)
            except Exception:
                pass
            self._preloadHomeMovieIndex()
        t = threading.Thread(target=delayed, name="TiviMateHomeMovieIndexDelay")
        t.daemon = True
        t.start()

    def _preloadHomeMovieIndex(self):
        if not self.source:
            return

        # Paint/use last known index immediately if available.
        if not self.homeMovieServerItems:
            try:
                cached = self._loadCachedHomeMovieIndex()
                if cached:
                    self.homeMovieServerItems = cached
            except Exception:
                pass

        if self.homeMovieIndexLoading:
            return

        self.homeMovieIndexLoading = True
        source = dict(self.source or {})
        generation = getattr(self, "_sourceGeneration", 0)

        def worker():
            rows = []
            try:
                rows = list(get_filtered_streams(source, "vod", get_source_client(source)) or [])
            except Exception:
                rows = []
            def finish():
                self.homeMovieIndexLoading = False
                if self._sourceJobValid(generation, source) and rows:
                    self.homeMovieServerItems = rows
                    try:
                        self._saveCachedHomeMovieIndex(rows, source)
                    except Exception:
                        pass
            try:
                if reactor:
                    reactor.callFromThread(finish)
                else:
                    finish()
            except Exception:
                try:
                    finish()
                except Exception:
                    pass

        t = threading.Thread(target=worker, name="TiviMateHomeMovieIndex")
        t.daemon = True
        t.start()

    def _homeCategoryText(self, category):
        row = category or {}
        return str(
            row.get("category_name") or row.get("name") or
            row.get("title") or row.get("genre") or ""
        ).strip().lower()

    def _homeCategoryAllowed(self, category, kind):
        """Keep Home server rails movie/series-only without doing network work."""
        text = self._homeCategoryText(category)
        if not text:
            return True
        # These are provider packages that are often exposed through VOD even
        # though they are not films/series.  Reject them before fetching rows.
        blocked = (
            "ufc", "efc", "mma", "boxing", "boxer", "fight", "fighting", "combat", "ppv",
            "wwe", "wrestling", "raw", "smackdown", "nxt",
            "sport", "sports", "football", "soccer", "match", "matches", "event", "events",
            "anime", "animation", "cartoon", "kids", "children", "child",
            "theater", "theatre", "plays", "stage",
            "music", "songs", "concert", "karaoke",
            "program", "programs", "xxx", "adult", "18+",
            "مصارعة", "رياضة", "رياضي", "مباريات", "قتال", "ملاكمة",
            "انمي", "أنمي", "كرتون", "اطفال", "أطفال", "مسرح", "مسرحيات",
            "اغاني", "أغاني", "برامج"
        )
        if any(token in text for token in blocked):
            return False
        if kind == "vod":
            wrong = ("series", "tv show", "tvshow", "مسلسل", "مسلسلات")
        else:
            wrong = ("movie", "movies", "film", "films", "cinema", "افلام", "أفلام")
        return not any(token in text for token in wrong)

    def _homeItemAllowed(self, item, kind, category_name=""):
        row = item or {}
        text = " ".join(str(row.get(k) or "") for k in (
            "name", "title", "genre", "category_name", "description"
        )).lower()
        if category_name:
            text += " " + str(category_name).lower()
        blocked = (
            "ufc", "efc", "mma", "boxing", "boxer", "fight", "fighting", "combat", "ppv",
            "wwe", "wrestling", "smackdown", "nxt",
            "sport", "sports", "football", "soccer", "match", "matches",
            "anime", "animation", "cartoon", "kids", "children",
            "theater", "theatre", "stage", "music", "concert", "karaoke",
            "program", "programs", "xxx", "adult",
            "مصارعة", "رياضة", "رياضي", "مباريات", "قتال", "ملاكمة",
            "انمي", "أنمي", "كرتون", "اطفال", "أطفال", "مسرح", "مسرحيات",
            "اغاني", "أغاني", "برامج"
        )
        if any(token in text for token in blocked):
            return False
        if kind == "vod":
            wrong = ("series", "tv show", "tvshow", "مسلسل", "مسلسلات")
        else:
            wrong = ("movie", "movies", "film", "cinema", "افلام", "أفلام")
        return not any(token in text for token in wrong)

    def _homeCanonicalKey(self, item, kind):
        """Collapse the same title across 4K/FHD/language/provider copies."""
        row = item or {}
        tmdb_id = str(row.get("tmdb_id") or row.get("tmdb") or "").strip()
        if tmdb_id and tmdb_id not in ("0", "None", "none"):
            return "tmdb:%s:%s" % (str(kind or "vod"), tmdb_id)
        raw = str(row.get("name") or row.get("title") or row.get("original_title") or row.get("original_name") or "")
        year_text = " ".join(str(row.get(k) or "") for k in (
            "year", "releaseDate", "releasedate", "release_date", "first_air_date", "name", "title"
        ))
        m = re.search(r"\b(?:19|20)\d{2}\b", year_text)
        year = m.group(0) if m else ""
        text = raw.lower()
        text = re.sub(r"\b(?:19|20)\d{2}\b", " ", text)
        text = re.sub(
            r"(?i)\b(?:8k|4k|uhd|fhd|fullhd|hd|sd|2160p|1080p|720p|hdr|hdr10|dv|dolby|atmos|"
            r"hevc|x265|x264|h265|h264|web[- ]?dl|webrip|bluray|blu[- ]?ray|remux|"
            r"nf|netflix|amz|amzn|amazon|prime|prime video|ar|ara|arabic|en|eng|english|fr|french|"
            r"sub|subs|dub|dubbed|multi)\b", " ", text
        )
        text = re.sub(r"[\[\]{}()_.|:+/\\-]+", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        if not text:
            sid = str(row.get("stream_id") or row.get("series_id") or row.get("vod_id") or row.get("id") or "").strip()
            return "id:%s:%s" % (str(kind or "vod"), sid)
        return "%s|%s|%s" % (str(kind or "vod"), text, year)

    def _homeQualityScore(self, item):
        text = " ".join(str((item or {}).get(k) or "") for k in ("name", "title", "quality", "container_extension")).lower()
        score = 0
        if "8k" in text:
            score = 80
        elif "4k" in text or "2160" in text:
            score = 70
        elif "uhd" in text:
            score = 65
        elif "fhd" in text or "1080" in text:
            score = 50
        elif re.search(r"\bhd\b|720", text):
            score = 30
        elif re.search(r"\bsd\b", text):
            score = 10
        # Prefer the copy with richer artwork/metadata when quality is tied.
        meta = sum(1 for k in ("stream_icon", "cover_big", "cover", "movie_image", "poster", "backdrop_path", "rating", "plot") if (item or {}).get(k))
        return score * 100 + meta

    def _homeDeduplicate(self, items, kind):
        best = {}
        order = []
        for raw in list(items or []):
            if not isinstance(raw, dict):
                continue
            row = dict(raw)
            key = self._homeCanonicalKey(row, kind)
            if not key:
                continue
            if key not in best:
                best[key] = row
                order.append(key)
            elif self._homeQualityScore(row) > self._homeQualityScore(best[key]):
                best[key] = row
        return [best[k] for k in order if k in best]

    def _homeStampSource(self, row, source, kind, cid="", category_name=""):
        item = dict(row or {})
        cid = str(cid or item.get("category_id") or item.get("categoryId") or "").strip()
        if cid:
            item["category_id"] = cid
            item["_source_category_id"] = cid
        if category_name:
            item["_source_category_name"] = str(category_name)
        item["_source_scope"] = "home_category" if cid else "home"
        item["_source_server_id"] = _source_identity(source or {})
        item["_tivimate_home_kind"] = kind
        return item

    def _homeContextItems(self, item, kind):
        """Resolve the selected Home item's real package from RAM/disk only."""
        row = dict(item or {})
        cid = str(row.get("_source_category_id") or row.get("category_id") or row.get("categoryId") or "").strip()
        if not cid or not self.source:
            return list(self.recent or [])
        rows = []
        try:
            rows, _origin = get_category_streams(
                self.source, kind, get_source_client(self.source), cid,
                use_cache=True, wait_for_server=False
            )
        except Exception:
            rows = []
        if not rows:
            candidates = list(self.homeMovieServerItems or []) + list(self.recent or [])
            rows = [x for x in candidates if str((x or {}).get("category_id") or (x or {}).get("categoryId") or "").strip() == cid]
        cname = str(row.get("_source_category_name") or "")
        stamped = [self._homeStampSource(x, self.source, kind, cid, cname) for x in list(rows or []) if isinstance(x, dict)]
        return self._homeDeduplicate(stamped, kind) or [row]

    def _startHomeServer2026Rotating(self, mode):
        """Home rows use the exact normal Search path with an internal fixed query: 2026."""
        source = dict(self.source or {})
        generation = getattr(self, "_sourceGeneration", 0)
        mode = str(mode or "popular_movies")
        kind = "series" if mode in ("popular_series", "trending_series") else "vod"
        self.stalkerRecentResult = None

        # Separate cache namespace so older pool/rotation results can never leak in.
        # Popular rows are plain/random from enabled packages only.
        # You Might Like rows are random 2026 matches from enabled packages only.
        if mode in ("popular_movies", "popular_series"):
            base_cache_mode = ("popular_series_seriesonly_v3" if mode == "popular_series" else "%s_any_v2" % mode)
        else:
            base_cache_mode = "exact_search_2026_random_v2_%s" % mode
        cache_mode = _home_server_filter_cache_mode(source, base_cache_mode)
        cached = _home_server_2026_cache_get(source, cache_mode)
        if cached:
            try:
                self._recentReady(cached, save_cache=False)
            except Exception:
                pass
            return

        try:
            self["status"].setText(tr("Loading Home content..."))
        except Exception:
            pass

        def worker():
            try:
                import random
                client = get_source_client(source)
                q = "2026"

                # Exact normal-Search semantics for You Might Like: local title match on 2026.
                # Popular Movies/TV Shows are different by design: any enabled item is eligible.
                # selected package ids only -> cache-backed package streams ->
                # local title/name substring match. No secondary catalog/fallback.
                allowed = get_allowed_category_ids(source, kind)
                if not allowed:
                    raise RuntimeError("No enabled packages are selected")
                allowed = set(str(x) for x in allowed if str(x))
                if not allowed:
                    raise RuntimeError("No enabled packages are selected")

                ordered_ids = []
                category_names = {}
                try:
                    categories, _origin = get_cached_categories(
                        source, kind, client=client, wait_for_server=False
                    )
                    for cat in categories or []:
                        if not isinstance(cat, dict):
                            continue
                        cid = str(cat.get("category_id") or "")
                        if cid:
                            category_names[cid] = str(cat.get("category_name") or cat.get("name") or "")
                        if cid and cid in allowed and cid not in ordered_ids:
                            if mode == "popular_series" and not self._homeCategoryAllowed(cat, "series"):
                                continue
                            ordered_ids.append(cid)
                except Exception:
                    pass
                if mode != "popular_series":
                    if mode != "popular_series":
                        for cid in allowed:
                            if cid not in ordered_ids:
                                ordered_ids.append(cid)

                pool = []
                seen = set()
                target_count = 8

                if mode == "popular_movies":
                    # r139 Popular Show: keep provider/enabled-package order and take
                    # ONE random item from each package. Start with the first 8 enabled
                    # packages; if a package is empty/duplicate, continue to the next
                    # package until eight unique Home items are ready. No year/rating/type
                    # filtering is done here -- speed and package diversity come first.
                    for offset in range(0, len(ordered_ids), 8):
                        batch_ids = ordered_ids[offset:offset + 8]
                        package_batches = get_category_streams_batch(
                            source, kind, client, batch_ids,
                            use_cache=True, wait_for_server=True, max_workers=4
                        )
                        by_cid = dict((str(cid), list(rows or [])) for cid, rows, _origin in package_batches)
                        for cid in batch_ids:
                            candidates = [x for x in by_cid.get(str(cid), []) if isinstance(x, dict)]
                            random.shuffle(candidates)
                            chosen = None
                            for raw in candidates:
                                item_cid = str(
                                    raw.get("category_id") or raw.get("categoryId") or
                                    raw.get("genre_id") or raw.get("genre-id") or ""
                                )
                                if item_cid and item_cid not in allowed:
                                    continue
                                row = self._homeStampSource(raw, source, kind, cid, category_names.get(cid, ""))
                                key = self._homeCanonicalKey(row, kind)
                                if not key or key in seen:
                                    continue
                                seen.add(key)
                                row["_home_server_2026"] = True
                                row["_home_rotation_mode"] = mode
                                chosen = row
                                break
                            if chosen is not None:
                                pool.append(chosen)
                            if len(pool) >= target_count:
                                break
                        if len(pool) >= target_count:
                            break
                else:
                    # Existing Popular TV / You Might Like behavior.
                    if mode == "popular_series":
                        random.shuffle(ordered_ids)
                    batch_size = 4
                    for offset in range(0, len(ordered_ids), batch_size):
                        package_batches = get_category_streams_batch(
                            source, kind, client, ordered_ids[offset:offset + batch_size],
                            use_cache=True, wait_for_server=True, max_workers=4
                        )
                        for cid, rows, _origin in package_batches:
                            for raw in rows or []:
                                if not isinstance(raw, dict):
                                    continue
                                item_cid = str(
                                    raw.get("category_id") or raw.get("categoryId") or
                                    raw.get("genre_id") or raw.get("genre-id") or ""
                                )
                                if item_cid and item_cid not in allowed:
                                    continue
                                title = str(raw.get("name") or raw.get("title") or "")
                                if mode not in ("popular_movies", "popular_series") and q not in title.lower():
                                    continue
                                if mode == "popular_series" and not self._homeItemAllowed(raw, "series", category_names.get(str(cid), "")):
                                    continue
                                row = self._homeStampSource(raw, source, kind, cid, category_names.get(cid, ""))
                                key = self._homeCanonicalKey(row, kind)
                                if not key:
                                    continue
                                if key in seen:
                                    for idx, existing in enumerate(pool):
                                        if self._homeCanonicalKey(existing, kind) == key and self._homeQualityScore(row) > self._homeQualityScore(existing):
                                            pool[idx] = row
                                            break
                                    continue
                                seen.add(key)
                                row["_home_server_2026"] = True
                                row["_home_rotation_mode"] = mode
                                pool.append(row)
                        pool = self._homeDeduplicate(pool, kind)
                        if len(pool) >= target_count:
                            break

                pool = self._homeDeduplicate(pool, kind)
                if not pool:
                    if mode in ("popular_movies", "popular_series"):
                        raise RuntimeError("No content is available in enabled packages")
                    raise RuntimeError("Search 2026 returned no matching content")

                # One final selection only. TMDb must never repaint the row.
                # Final Home selection is random for all four rows.
                # Popular: any enabled content. You Might Like: only 2026 title matches.
                if mode != "popular_movies":
                    random.shuffle(pool)
                rows = pool[:8]

                if not rows:
                    if mode in ("popular_movies", "popular_series"):
                        raise RuntimeError("No usable content is available")
                    raise RuntimeError("Search 2026 returned no usable content")
                _home_server_2026_cache_put(source, cache_mode, rows)
                if self._sourceJobValid(generation, source):
                    self.stalkerRecentResult = (-100, rows, "")
            except Exception as exc:
                if self._sourceJobValid(generation, source):
                    self.stalkerRecentResult = (-100, [], str(exc))

        thread = threading.Thread(target=worker, name="TiviMateHomeExactSearch2026_%s" % mode)
        thread.daemon = True
        thread.start()
        try:
            self.stalkerRecentTimer.start(120, True)
        except Exception:
            pass

    def _warmHomeSecondaryFeeds(self):
        """Prepare the other Home feeds after Popular Movies without downloading artwork.

        This only builds the final server rows/cache for Popular TV Shows and the two
        2026 You Might Like feeds.  Posters/backdrops remain strictly on-demand when
        the user switches to that feed.
        """
        source = dict(self.source or {})
        if not source:
            return
        source_key = _source_identity(source)
        if getattr(self, "_homeSecondaryWarmKey", "") == source_key:
            return
        self._homeSecondaryWarmKey = source_key
        generation = getattr(self, "_sourceGeneration", 0)

        def worker():
            import random
            modes = ("popular_series", "trending_movies", "trending_series")
            for mode in modes:
                if not self._sourceJobValid(generation, source):
                    return
                kind = "series" if mode in ("popular_series", "trending_series") else "vod"
                base_cache_mode = "popular_series_seriesonly_v3" if mode == "popular_series" else ("exact_search_2026_random_v2_%s" % mode)
                cache_mode = _home_server_filter_cache_mode(source, base_cache_mode)
                if _home_server_2026_cache_get(source, cache_mode):
                    continue
                try:
                    client = get_source_client(source)
                    allowed = set(str(x) for x in (get_allowed_category_ids(source, kind) or []) if str(x))
                    if not allowed:
                        continue
                    ordered_ids = []
                    category_names = {}
                    try:
                        categories, _origin = get_cached_categories(source, kind, client=client, wait_for_server=True)
                    except Exception:
                        categories = []
                    for cat in categories or []:
                        if not isinstance(cat, dict):
                            continue
                        cid = str(cat.get("category_id") or "")
                        if cid:
                            category_names[cid] = str(cat.get("category_name") or cat.get("name") or "")
                        if cid and cid in allowed and cid not in ordered_ids:
                            if mode == "popular_series" and not self._homeCategoryAllowed(cat, "series"):
                                continue
                            ordered_ids.append(cid)
                    for cid in allowed:
                        if cid not in ordered_ids:
                            ordered_ids.append(cid)
                    random.shuffle(ordered_ids)
                    pool, seen = [], set()
                    for offset in range(0, len(ordered_ids), 4):
                        batches = get_category_streams_batch(
                            source, kind, client, ordered_ids[offset:offset + 4],
                            use_cache=True, wait_for_server=True, max_workers=4
                        )
                        for cid, rows, _origin in batches:
                            for raw in rows or []:
                                if not isinstance(raw, dict):
                                    continue
                                item_cid = str(raw.get("category_id") or raw.get("categoryId") or raw.get("genre_id") or raw.get("genre-id") or "")
                                if item_cid and item_cid not in allowed:
                                    continue
                                title = str(raw.get("name") or raw.get("title") or "")
                                if mode.startswith("trending_") and "2026" not in title.lower():
                                    continue
                                if mode == "popular_series" and not self._homeItemAllowed(raw, "series", category_names.get(str(cid), "")):
                                    continue
                                row = self._homeStampSource(dict(raw), source, kind, cid, category_names.get(cid, ""))
                                key = self._homeCanonicalKey(row, kind)
                                if not key or key in seen:
                                    continue
                                seen.add(key)
                                row["_home_rotation_mode"] = mode
                                pool.append(row)
                        if len(pool) >= 8:
                            break
                    pool = self._homeDeduplicate(pool, kind)
                    random.shuffle(pool)
                    if pool:
                        _home_server_2026_cache_put(source, cache_mode, pool[:8])
                except Exception:
                    continue

        thread = threading.Thread(target=worker, name="TiviMateHomeMetadataWarm")
        thread.daemon = True
        thread.start()

    def _startHomePopularServer2026(self):
        # Backward-compatible wrapper kept for older internal callers.
        return self._startHomeServer2026Rotating("popular_movies")

    def startLoad(self):
        if not self.source:
            self["status"].setText(tr("No server selected • Press SETTINGS"))
            return

        mode = getattr(self, "homeContentMode", "popular_movies") or "popular_movies"
        # Recent Added is intentionally NOT a Home startup feed anymore.
        # Old saved configs are migrated at runtime without starting any provider scan.
        if mode in ("recent_movies", "recent_series"):
            mode = "popular_movies"
            self.homeContentMode = mode
            try:
                cfg = _load_home_appearance()
                _save_home_appearance(cfg.get("skin", "skin2_dark"), "popular_movies")
            except Exception:
                pass

        # Home rows are server-only. Popular Movies/TV Shows are fully random
        # across enabled packages. You Might Like rows are random 2026 matches.
        # All four feeds remain fixed for 6 hours via the per-server cache.
        if mode in ("popular_movies", "popular_series", "trending_movies", "trending_series"):
            return self._startHomeServer2026Rotating(mode)

        # Legacy TMDb branch retained for compatibility with older/custom modes.
        # Refresh still happens in the background, but cached Home never shows Loading.
        if mode.startswith(("popular_", "trending_")):
            source = dict(self.source or {})
            generation = getattr(self, "_sourceGeneration", 0)
            cached_rows = _home_tmdb_cache_get(mode)
            if not cached_rows and mode != "popular_movies":
                cached_rows = _home_tmdb_cache_get("popular_movies")

            if cached_rows:
                try:
                    self._recentReady(cached_rows[:6], save_cache=False)
                except Exception:
                    pass
            else:
                self["status"].setText(tr("Loading Home content..."))

            def tmdb_worker():
                try:
                    rows = TMDbClient().home_feed(mode, 6)
                    if not rows and mode != "popular_movies":
                        rows = TMDbClient().home_feed("popular_movies", 6)
                    if rows:
                        _home_tmdb_cache_put(mode, rows)
                    if self._sourceJobValid(generation, source):
                        # Repaint only when there was no cache or the feed changed.
                        if (not cached_rows) or rows != cached_rows[:len(rows)]:
                            self.stalkerRecentResult = (-100, rows, "")
                        else:
                            self.stalkerRecentResult = (-101, [], "")
                except Exception as exc:
                    # Keep cached Home visible on transient TMDb failures.
                    if cached_rows:
                        self.stalkerRecentResult = (-101, [], "")
                    else:
                        try:
                            rows = TMDbClient().home_feed("popular_movies", 6)
                            if rows:
                                _home_tmdb_cache_put("popular_movies", rows)
                            self.stalkerRecentResult = (-100, rows, "")
                        except Exception:
                            self.stalkerRecentResult = (-100, [], str(exc))
            thread = threading.Thread(target=tmdb_worker, name="TiviMateHomeTMDb")
            thread.daemon = True
            thread.start()
            try:
                self.stalkerRecentTimer.start(120, True)
            except Exception:
                pass
            return

        # Home has no Recent Added feed. Recent Added remains available only
        # inside the Movies / TV Shows package browser. Any legacy/custom Home
        # mode falls back to Popular Movies instead of starting a Recent scan.
        if mode in ("recent_movies", "recent_series"):
            self.homeContentMode = "popular_movies"
            return self._startHomeServer2026Rotating("popular_movies")

        # Home supports only Popular/Trending feeds. Any unknown/custom legacy
        # mode falls back to Popular Movies; it must never start a Recent scan.
        self.homeContentMode = "popular_movies"
        return self._startHomeServer2026Rotating("popular_movies")

    def _startHomePopularFallback(self):
        self.homeContentMode = "popular_movies"
        source = dict(self.source or {})
        generation = getattr(self, "_sourceGeneration", 0)
        cached_rows = _home_tmdb_cache_get("popular_movies")
        if cached_rows:
            try:
                self._recentReady(cached_rows[:6], save_cache=False)
            except Exception:
                pass
        def worker():
            try:
                rows = TMDbClient().home_feed("popular_movies", 6)
                if rows:
                    _home_tmdb_cache_put("popular_movies", rows)
                if self._sourceJobValid(generation, source):
                    if (not cached_rows) or rows != cached_rows[:len(rows)]:
                        self.stalkerRecentResult = (-100, rows, "")
                    else:
                        self.stalkerRecentResult = (-101, [], "")
            except Exception as exc:
                self.stalkerRecentResult = (-101, [], "") if cached_rows else (-100, [], str(exc))
        t = threading.Thread(target=worker, name="TiviMateHomePopularFallback")
        t.daemon = True
        t.start()
        try:
            self.stalkerRecentTimer.start(120, True)
        except Exception:
            pass

    def _finishStalkerRecentLoad(self):
        result = self.stalkerRecentResult
        if result is None:
            try:
                self.stalkerRecentTimer.start(120, True)
            except Exception:
                pass
            return
        # Do not erase a newer worker result that may have arrived while this
        # UI callback was being scheduled for an older request token.
        if self.stalkerRecentResult is result:
            self.stalkerRecentResult = None
        token, items, error = result
        if token == -101:
            # Background refresh found no visible change; keep current Home untouched.
            return
        if token == -100:
            if error or not items:
                self._recentFailed(error or "TMDb returned no Home content")
                return
            self._recentReady(items, save_cache=False)
            mode = getattr(self, "homeContentMode", "") or ""
            if mode.endswith("_movies") and not any((x or {}).get("_home_server_2026") for x in list(items or [])):
                try:
                    self._scheduleHomeMovieIndexWarmup()
                except Exception:
                    pass
            return
        if token != self.stalkerRecentToken:
            return
        if error or not items:
            self._startHomePopularFallback()
            return
        self._recentReady(items)

    def _recentFailed(self, error):
        self["status"].setText("Unable to load Home content: %s" % error)

    def _recentReady(self, items, save_cache=True, background=True):
        mode = getattr(self, "homeContentMode", "popular_movies")
        home_kind = "series" if mode.endswith("_series") else "vod"
        items = _dedupe_content_rows(items or [], home_kind)[:6]
        if save_cache:
            self._saveHomeRecentCache(items, self.source)
        # If cached content is already visible and the background refresh found
        # exactly the same six entries, keep the existing pixmaps/hero untouched.
        try:
            old_ids = [str((x or {}).get("stream_id") or (x or {}).get("vod_id") or (x or {}).get("name") or "") for x in self.recent]
            new_ids = [str((x or {}).get("stream_id") or (x or {}).get("vod_id") or (x or {}).get("name") or "") for x in items]
            if background and self.recent and old_ids == new_ids:
                return
        except Exception:
            pass
        self.recent = items
        heading = tr("Popular Show")
        status_label = tr("%d Home picks") % len(self.recent)
        mode = getattr(self, "homeContentMode", "popular_movies")
        labels = {
            "popular_movies": tr("Popular Show"),
            "popular_series": tr("Popular TV Shows"),
            "trending_movies": tr("Movies You Might Like"),
            "trending_series": tr("TV Shows You Might Like"),
        }
        heading = labels.get(mode, heading)
        status_label = tr("%d Home picks") % len(self.recent)
        self["recentTitle"].setText(heading)
        self._applyRecentTitleLayout()
        self["status"].setText(tr("Server: %s  •  %s") % (self.source.get("name", "SERVER"), status_label))
        for i, item in enumerate(self.recent[:6]):
            pw, ph = self.posterSize
            poster_url = item.get("stream_icon") or item.get("cover_big") or item.get("cover") or item.get("movie_image") or item.get("poster") or ""
            if poster_url:
                self.loadImage(i, poster_url, "poster%d" % i, pw, ph, fallback_item=item)
            else:
                self._homePosterFallback(item, i, "poster%d" % i, pw, ph)
            title = str(item.get("name") or item.get("title") or "").strip()
            rating = str(item.get("rating") or item.get("rating_5based") or "").strip()
            self["posterMetaTitle%d" % i].setText(title[:22] + ("…" if len(title) > 22 else ""))
            self["posterMetaRate%d" % i].setText(rating[:4])
        # r131 test: the active Home feed already requests its six visible posters
        # above.  Do not mass-prefetch posters/backdrops here.  After the default
        # Popular Movies feed is ready, prepare only the row metadata for the other
        # three Home feeds so switching is fast without background image downloads.
        if mode == "popular_movies":
            try:
                self._warmHomeSecondaryFeeds()
            except Exception:
                pass
            # r137: once default Popular Movies is ready, also prepare only
            # Movies/TV Shows backdrop metadata in the background. No artwork
            # is downloaded here; Content Home keeps ownership of image fetches.
            try:
                src = dict(self.source or {})
                t = threading.Thread(target=warm_backdrop_metadata_from_home, args=(src,), name="TiviMateBackdropMetadataWarm")
                t.daemon = True
                t.start()
            except Exception:
                pass
        self.posterIndex = 0
        self.globalHero = not bool(self.recent)
        if self.globalHero:
            self.applyGlobalHero()
        else:
            self.updateFeature()
        self.updateFocus()

    def updateFeature(self):
        # The selected poster owns the banner once the library row is ready.
        if not self.recent: return
        item = self.recent[min(self.posterIndex, len(self.recent)-1)]
        self["featureTitle"].setText((item.get("name") or item.get("title") or "MOVIE").upper())
        year = str(item.get("year") or item.get("releaseDate") or "")
        rating = str(item.get("rating") or "")
        genre = str(item.get("genre") or "")
        self["featureMeta"].setText("  •  ".join(x for x in [year, ("★ " + rating) if rating else "", genre] if x))
        self["featureDesc"].setText((item.get("plot") or item.get("description") or "From the selected server.")[:180])

        # Use a true backdrop in the middle banner. Do not stretch the poster.
        self.featureRequestId += 1
        request_id = self.featureRequestId
        stream_id = item.get("stream_id") or item.get("vod_id")
        direct_backdrop = self._normaliseBackdrop(item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url"))
        if direct_backdrop:
            self.loadImage(6, direct_backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        elif stream_id:
            source = dict(self.source or {})
            generation = getattr(self, "_sourceGeneration", 0)
            item_snapshot = dict(item or {})
            thread = threading.Thread(target=self._loadFeatureBackdrop, args=(stream_id, request_id, source, generation, item_snapshot), name="TiviMateBackdrop")
            thread.daemon = True
            thread.start()

    def _normaliseBackdrop(self, value):
        if isinstance(value, list):
            value = value[0] if value else ""
        if not isinstance(value, str):
            return ""
        value = value.strip().replace("\\/", "/")
        if value.startswith("["):
            try:
                arr = json.loads(value)
                value = arr[0] if arr else ""
            except Exception:
                pass
        if value.startswith("/") and not value.startswith("//"):
            value = "https://image.tmdb.org/t/p/w1280" + value
        return value if value.startswith(("http://", "https://")) else ""

    def _cleanRecentTitle(self, value):
        import re
        text = str(value or "")
        text = re.sub(r"\b(ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|uhd|fhd|hd|hevc|x265|x264|hdr|web[- ]?dl|bluray|top)\b", " ", text, flags=re.I)
        text = re.sub(r"[\[\]{}()_.|:+-]+", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _recentYear(self, item):
        import re
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        match = re.search(r"\b(?:19|20)\d{2}\b", raw)
        return int(match.group(0)) if match else None

    def _loadFeatureBackdrop(self, stream_id, request_id, source=None, generation=None, item_snapshot=None):
        source = dict(source or self.source or {})
        generation = getattr(self, "_sourceGeneration", 0) if generation is None else generation
        item_snapshot = dict(item_snapshot or {})
        try:
            if not self._sourceJobValid(generation, source):
                return
            data = XtreamClient(source).vod_info(stream_id) or {}
            info = {}
            if isinstance(data.get("movie_data"), dict): info.update(data.get("movie_data") or {})
            if isinstance(data.get("info"), dict): info.update(data.get("info") or {})
            backdrop = self._normaliseBackdrop(
                info.get("backdrop_path") or info.get("backdrop") or info.get("backdrop_url") or
                data.get("backdrop_path") or data.get("backdrop")
            )
            # Home Movies sometimes contains only a poster. Resolve the movie on
            # TMDb and use its true backdrop without changing any other section.
            if not backdrop:
                current = item_snapshot
                tmdb = TMDbClient()
                tid = info.get("tmdb_id") or info.get("tmdb") or current.get("tmdb_id") or current.get("tmdb")
                if not tid:
                    title = info.get("name") or current.get("name") or current.get("title") or ""
                    found = tmdb.search_artwork(title, "vod", self._recentYear(info or current), required_key="backdrop_path") if str(title or "").strip() else None
                    tid = (found or {}).get("id")
                bundle = tmdb.details_bundle(tid, "vod") if tid else {}
                backdrop = self._normaliseBackdrop(bundle.get("backdrop_path"))
            if backdrop and request_id == self.featureRequestId and self._sourceJobValid(generation, source):
                if reactor is not None:
                    reactor.callFromThread(self._applyFeatureBackdropForSource, generation, source, request_id, backdrop)
                else:
                    self._applyFeatureBackdropForSource(generation, source, request_id, backdrop)
        except Exception:
            pass

    def _applyFeatureBackdropForSource(self, generation, source, request_id, backdrop):
        if not self._sourceJobValid(generation, source):
            return
        if request_id != getattr(self, "featureRequestId", -1):
            return
        self.loadImage(6, backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)

    def _homePosterYear(self, item):
        try:
            raw = " ".join(str((item or {}).get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
            match = re.search(r"\b(?:19|20)\d{2}\b", raw)
            return int(match.group(0)) if match else None
        except Exception:
            return None

    def _homePosterKind(self, item):
        marker = str((item or {}).get("_tivimate_home_kind") or "").lower()
        if marker in ("series", "tv", "shows", "tvshows"):
            return "series"
        if (item or {}).get("series_id") is not None and not (item or {}).get("stream_id"):
            return "series"
        return "vod"

    def _homePosterFallback(self, item, slot, widget, width, height, failed_url=""):
        snapshot = dict(item or {})
        source = dict(self.source or {})
        generation = getattr(self, "_sourceGeneration", 0)
        key = (slot, widget)

        def worker():
            try:
                if not self._sourceJobValid(generation, source):
                    return
                title = snapshot.get("name") or snapshot.get("title") or snapshot.get("original_name") or snapshot.get("original_title") or ""
                if not str(title or "").strip():
                    return
                found = TMDbClient().search_artwork(
                    title,
                    self._homePosterKind(snapshot),
                    self._homePosterYear(snapshot),
                    required_key="poster_path"
                ) or {}
                poster = str(found.get("poster_path") or "").strip()
                if not poster:
                    return
                if poster.startswith("/"):
                    poster = "https://image.tmdb.org/t/p/w500" + poster

                def apply():
                    if not self._sourceJobValid(generation, source):
                        return
                    current = getattr(self, "_artwork_requests", {}).get(key)
                    if failed_url and current != (failed_url, None):
                        return
                    self.loadImage(slot, poster, widget, width, height)

                if reactor is not None:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass

        t = threading.Thread(target=worker, name="TiviMateHomePosterFallback")
        t.daemon = True
        t.start()

    def _homePosterFileValid(self, path):
        """Cheap Home-card validation matching the working Movies/Series path."""
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, "rb") as fh:
                head = fh.read(12)
            return bool(head.startswith(b"\xff\xd8\xff") or head.startswith(b"\x89PNG\r\n\x1a\n"))
        except Exception:
            return False

    def loadImage(self, slot, url, widget, width, height, request_id=None, fallback_item=None):
        url = (url or "").strip().replace("\\/", "/")
        if not url or (request_id is not None and request_id != self.featureRequestId):
            return
        # One token per visual slot prevents a prior selection from painting over
        # the current poster or backdrop after the user moves the selection.
        requests = getattr(self, "_artwork_requests", None)
        if requests is None:
            requests = {}
            self._artwork_requests = requests
        token = (slot, widget)
        requests[token] = (url, request_id)
        priority = 120 if widget == "banner" else 75

        def done(path, s=slot, w=widget, x=width, y=height, rid=request_id, expected=(url, request_id), key=token, item=fallback_item):
            if getattr(self, "_artwork_requests", {}).get(key) != expected:
                return
            # Home used to treat HTTP-200 error bodies as posters.  The working
            # Movies/Series cards validate these bytes and immediately fall back
            # to TMDb, so use the exact same policy here.
            if item is not None and rid is None and not self._homePosterFileValid(path):
                try:
                    if path and os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                self._homePosterFallback(item, s, w, x, y, url)
                return
            self.decodeImage(s, path, w, x, y, request_id=rid)

        def failed(_path, s=slot, w=widget, x=width, y=height, expected_url=url, item=fallback_item):
            if item is not None and request_id is None:
                self._homePosterFallback(item, s, w, x, y, expected_url)

        request_artwork(url, "backdrops" if widget == "banner" else "posters", done, priority=priority, errback=failed if fallback_item is not None else None)

    def decodeImage(self, slot, path, widget, width, height, request_id=None):
        if request_id is not None and request_id != self.featureRequestId:
            return
        loader = ePicLoad(); self.imageLoaders[slot] = loader
        def ready(_info=None, slot=slot, widget=widget, request_id=request_id, l=loader):
            try:
                if request_id is not None and request_id != self.featureRequestId:
                    return
                ptr = l.getData()
                if ptr and self[widget].instance: self[widget].instance.setPixmap(ptr)
            except Exception:
                pass
            finally:
                try:
                    if self.imageLoaders[slot] is l:
                        self.imageLoaders[slot] = None
                except Exception:
                    pass
        connect_picture_data(loader, ready, self)
        # A zero aspect ratio makes ePicLoad fill the complete panorama.
        # Both remaining Home skins use this decoding path.
        # so selected movie backdrops cannot be letterboxed with black side areas.
        render_width, render_height = scale_size(width, height)
        if widget == "banner" and self.homeSkinName in ("reference_home", "skin2_dark"):
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        else:
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def playRecent(self):
        if not self.recent or not self.source:
            return
        item = dict(self.recent[self.posterIndex] or {})
        if item.get("_home_tmdb_feed") or item.get("_tmdb"):
            kind = str(item.get("_tivimate_home_kind") or item.get("media_type") or "vod")
            item["_home_tmdb_feed"] = item.get("_home_tmdb_feed") or getattr(self, "homeContentMode", "popular_movies")
            if kind == "series":
                self.session.open(SeriesDetailsScreen, self.source, item)
            else:
                # Home never checks server availability before opening details.
                # The details screen performs the provider search after entry.
                item["_source_scope"] = str(item.get("_source_scope") or "home")
                item["_source_server_id"] = _source_identity(self.source)
                cid = str(item.get("_source_category_id") or item.get("category_id") or "").strip()
                context_items = self._homeContextItems(item, "vod") if cid else list(self.homeMovieServerItems or [])
                self.session.open(
                    MovieDetailsScreen, self.source, item, context_items,
                    {"scope":item.get("_source_scope") or "home", "category_id":cid, "items":list(context_items or [])}
                )
            return

        kind = str(item.get("_tivimate_home_kind") or "vod")
        item["_recent_home"] = True
        if kind == "series":
            self.session.open(SeriesDetailsScreen, self.source, item)
        else:
            item["_source_scope"] = str(item.get("_source_scope") or "home_category")
            item["_source_server_id"] = _source_identity(self.source)
            cid = str(item.get("_source_category_id") or item.get("category_id") or "").strip()
            context_items = self._homeContextItems(item, "vod") if cid else list(self.recent or [])
            self.session.open(
                MovieDetailsScreen, self.source, item, context_items,
                {"scope":item.get("_source_scope") or "home_category", "category_id":cid, "items":list(context_items or [])}
            )

from .tivimate_player import TiviMatePlayer, _load_player_type


class ContinueWatchingScreen(Screen):
    skin = '<screen name="ContinueWatchingScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#181b20">\n<eLabel position="0,0" size="1920,1080" backgroundColor="#181b20" zPosition="0" />\n<widget name="hero" position="0,0" size="1920,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/continue_default_hero.jpg" alphatest="blend" scale="1" zPosition="1" />\n<ePixmap position="0,0" size="1920,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/content_overlay.png" alphatest="blend" zPosition="2" />\n<ePixmap position="46,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="7" />\n<widget name="top0" position="76,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="231,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="7" />\n<widget name="top1" position="261,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="416,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="7" />\n<widget name="top2" position="446,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="601,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="7" />\n<widget name="top3" position="631,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="786,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="7" />\n<widget name="top4" position="816,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="971,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="7" />\n<widget name="top5" position="1001,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="1156,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="7" />\n<widget name="top6" position="1186,32" size="314,52" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="1516,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="7" />\n<widget name="top7" position="1546,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<widget name="topSelector" position="900,88" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_gold.png" alphatest="blend" zPosition="9" />\n<widget name="heroTitle" position="95,142" size="940,82" font="Regular;50" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />\n<widget name="heroMeta" position="100,240" size="940,42" font="Regular;27" foregroundColor="#5ADAF4" backgroundColor="#00000000" transparent="1" zPosition="4" />\n<widget name="heroStars" position="100,278" size="940,34" font="Regular;24" foregroundColor="#FFD34E" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="heroDesc" position="100,322" size="980,70" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />\n<widget name="heroProgress" position="100,418" size="650,12" borderWidth="0" backgroundColor="#38424D" foregroundColor="#FFFFFF" zPosition="5" />\n<widget name="heroPercent" position="770,402" size="130,36" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="5" />\n<widget name="moviesTitle" position="80,468" size="720,38" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="moviesPage" position="1480,470" size="360,34" font="Regular;21" foregroundColor="#9ADFED" backgroundColor="#00000000" transparent="1" halign="right" zPosition="5" />\n<widget name="seriesTitle" position="80,724" size="720,38" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="seriesPage" position="1480,726" size="360,34" font="Regular;21" foregroundColor="#9ADFED" backgroundColor="#00000000" transparent="1" halign="right" zPosition="5" /><widget name="card0" position="82,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="80,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title0" position="94,688" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta0" position="94,711" size="360,20" font="Regular;16" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card1" position="537,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="535,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title1" position="549,688" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta1" position="549,711" size="360,20" font="Regular;16" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card2" position="992,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="990,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title2" position="1004,688" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta2" position="1004,711" size="360,20" font="Regular;16" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card3" position="1447,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="1445,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title3" position="1459,688" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta3" position="1459,711" size="360,20" font="Regular;16" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card4" position="82,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="80,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title4" position="94,933" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta4" position="94,956" size="360,20" font="Regular;16" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card5" position="537,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="535,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title5" position="549,933" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta5" position="549,956" size="360,20" font="Regular;16" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card6" position="992,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="990,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title6" position="1004,933" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta6" position="1004,956" size="360,20" font="Regular;16" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card7" position="1447,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="1445,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title7" position="1459,933" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta7" position="1459,956" size="360,20" font="Regular;16" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="focus" position="80,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_410x210.png" alphatest="blend" scale="1" zPosition="8" />\n<widget name="empty" position="365,620" size="1190,70" font="Regular;28" foregroundColor="#AAB6C2" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />\n\n\n\n<widget name="posterBottomControl" position="730,970" size="460,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/continue_poster_backdrop_menu.png" alphatest="blend" scale="1" zPosition="30" />\n<widget name="backdropBottomControl" position="730,970" size="460,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/continue_poster_backdrop_menu.png" alphatest="blend" scale="1" zPosition="30" />\n</screen>'

    RESUME_FILE = data_path("resume.json")
    VIEW_FILE = data_path("continue_view.json")
    CARD_COUNT = 4
    X = [80, 535, 990, 1445]
    MOVIE_Y = 525
    SERIES_Y = 770


    def __init__(self, session, current_source=None):
        Screen.__init__(self, session)
        self._pageOpenBusy = False
        self.currentSource = dict(current_source or {})
        self["hero"] = Pixmap(); self["heroTitle"] = Label(tr("YOUR STORY CONTINUES HERE")); self["heroMeta"] = Label(tr("Movies  •  TV Shows")); self["heroDesc"] = Label(tr("Start watching and unfinished titles will appear here automatically."))
        self["heroPercent"] = Label(""); self["heroStars"] = Label(""); self["heroProgress"] = ProgressBar(); self["moviesTitle"] = Label(tr("Continue Watching") + "  •  " + tr("Movies")); self["seriesTitle"] = Label(tr("Continue Watching") + "  •  " + tr("TV Shows"))
        self.topNames = [nav_label("Search"), nav_label("Home"), nav_label("Live"), nav_label("Movies"), nav_label("TV Shows"), nav_label("Packages"), nav_label("Continue Watching"), nav_label("Settings")]
        for i, name in enumerate(self.topNames):
            self["top%d" % i] = Label(name)
        self["topSelector"] = Pixmap()
        self["moviesPage"] = Label(""); self["seriesPage"] = Label(""); self["focus"] = Pixmap(); self["empty"] = Label(""); self["posterBottomControl"] = Pixmap(); self["backdropBottomControl"] = Pixmap()
        try: self["heroProgress"].setRange((0,100))
        except Exception: pass
        for i in range(8):
            self["card%d" % i] = Pixmap(); self["title%d" % i] = Label(""); self["meta%d" % i] = Label(""); self["prog%d" % i] = ProgressBar()
            try: self["prog%d" % i].setRange((0,100))
            except Exception: pass
        self.movies=[]; self.series=[]; self.moviePage=0; self.seriesPage=0; self.row=0; self.index=0; self._generation=0; self._heroUrl=""; self._loaders=[]
        self.viewMode = self._loadViewMode()
        self.navFocus = "top"
        self.topIndex = 6
        self.topX = [40, 225, 410, 595, 780, 965, 1150, 1510]
        self.topW = [175, 175, 175, 175, 175, 175, 350, 175]
        self["actions"] = ActionMap(["OkCancelActions","DirectionActions","MenuActions","ColorActions"], {"ok":self.ok,"cancel":self.close,"left":self.left,"right":self.right,"up":self.up,"down":self.down,"menu":self.openOptions,"red":self.removeSelected,"yellow":self.clearAll,"blue":self.toggleViewMode}, -1)
        self.onLayoutFinish.append(self._applyContinueViewLayout); self.onLayoutFinish.append(self._updatePosterBottomControl); self.onLayoutFinish.append(self.reload); self.onLayoutFinish.append(self._updateTopFocus)

    def _loadViewMode(self):
        try:
            with open(self.VIEW_FILE, "r") as h:
                data = json.load(h) or {}
            mode = str(data.get("mode") or "").lower()
            if mode in ("poster", "backdrop"):
                return mode
        except Exception:
            pass
        return "backdrop"

    def _saveViewMode(self):
        try:
            folder = os.path.dirname(self.VIEW_FILE)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = self.VIEW_FILE + ".tmp"
            with open(tmp, "w") as h:
                json.dump({"mode": self.viewMode}, h, separators=(",", ":"))
            os.rename(tmp, self.VIEW_FILE)
        except Exception:
            pass

    def _load(self):
        try:
            with open(self.RESUME_FILE,"r") as h: data=json.load(h)
            return data if isinstance(data,dict) else {}
        except Exception: return {}
    def _save(self,data):
        try:
            folder=os.path.dirname(self.RESUME_FILE)
            if folder and not os.path.isdir(folder): os.makedirs(folder)
            tmp=self.RESUME_FILE+".tmp"
            with open(tmp,"w") as h: json.dump(data,h,separators=(",",":"),sort_keys=True)
            os.rename(tmp,self.RESUME_FILE)
        except Exception: pass
    def _isSeries(self,row):
        item = row.get("item") or {}
        kind = str(row.get("kind") or item.get("_kind") or "").lower()
        if kind in ("series", "tv", "show"):
            return True
        has_episode_identity = bool(
            row.get("episode") not in (None, "") or
            item.get("episode_num") not in (None, "") or
            item.get("episode_number") not in (None, "") or
            item.get("_subdl_episode") not in (None, "") or
            ((row.get("season") not in (None, "") or item.get("season") not in (None, "") or item.get("season_number") not in (None, "")) and
             (item.get("episode") not in (None, "") or row.get("episode") not in (None, "")))
        )
        if kind == "episode":
            return has_episode_identity
        if item.get("_tmdb_kind") == "series" and has_episode_identity:
            return True
        return False

    def _seriesIdentity(self,key,row):
        item = row.get("item") or {}
        # Group Continue Watching by the parent show name first.  Do not use
        # series_id as the primary key: some providers change or duplicate it
        # between episode records, which used to create repeated cards.
        title = (
            row.get("series_title") or item.get("series_name") or
            item.get("_tmdb_title") or row.get("title") or
            item.get("name") or item.get("title") or ""
        )
        value = str(title or "").strip().lower()
        # Strip episode markers and common IPTV decorations so e.g.
        # "AR - Suits - S01E05" and "Suits S01 E05" collapse to "suits".
        value = re.sub(r"(?i)\bS(?:EASON)?\s*\d{1,2}\s*[- .]*E(?:P(?:ISODE)?)?\s*\d{1,3}\b", " ", value)
        value = re.sub(r"(?i)\bS\d{1,2}E\d{1,3}\b", " ", value)
        value = re.sub(r"(?i)\b\d{1,2}X\d{1,3}\b", " ", value)
        value = re.sub(r"(?i)\b(?:4k|uhd|fhd|hd|1080p|720p|amz|amzn|nf|netflix|web[- ]?dl|webrip|ar|ara|arabic|en|eng|english)\b", " ", value)
        value = re.sub(r"[\[\]\(\)\{\}_|:/\-]+", " ", value)
        value = re.sub(r"\s+", " ", value).strip()
        if value:
            return "name:" + value
        sid = str(row.get("series_id") or item.get("series_id") or "").strip().lower()
        return "id:" + sid if sid else "key:" + str(key)
    def _contentIdentity(self, row):
        item = row.get("item") or {}
        series_name = row.get("series_title") or item.get("series_name") or item.get("_tmdb_title") or ""
        title = series_name or row.get("title") or item.get("name") or item.get("title") or ""
        text = str(title or "").lower()
        text = re.sub(r"\b(?:19|20)\d{2}\b", " ", text)
        text = re.sub(r"(?i)\b(?:4k|8k|uhd|fhd|hd|sd|2160p|1080p|720p|amz|amzn|nf|netflix|web[- ]?dl|webrip|bluray|ar|ara|arabic|en|eng|english)\b", " ", text)
        text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
        text = " ".join(text.split())
        season = str(row.get("season") or item.get("season") or item.get("season_number") or "")
        episode = str(row.get("episode") or item.get("episode_num") or item.get("episode_number") or "")
        if self._isSeries(row):
            return "series|%s|s%s|e%s" % (text, season, episode)
        year_raw = " ".join(str(x or "") for x in (item.get("year"), item.get("releaseDate"), item.get("release_date"), row.get("title")))
        m = re.search(r"\b(19|20)\d{2}\b", year_raw)
        return "movie|%s|%s" % (text, m.group(0) if m else "")

    def _serverKeyFromStreamUrl(self, streamurl):
        url = str(streamurl or "").strip()
        if not url:
            return ""
        try:
            parsed = urlparse(url)
            stream_host = (parsed.netloc or "").lower()
            stream_path = parsed.path or ""
        except Exception:
            stream_host = ""
            stream_path = url

        best = ""
        for source in (get_sources() or []):
            try:
                source_key = _source_identity(source)
                base = str(source.get("url") or source.get("portal") or source.get("host") or source.get("server") or "").strip()
                if "://" not in base and base:
                    base = "http://" + base
                bp = urlparse(base)
                source_host = (bp.netloc or "").lower()
                username = str(source.get("username") or "")
                # Exact server host is the strongest direct match.
                if source_host and stream_host and source_host == stream_host:
                    if username and (("/" + username + "/") in stream_path or username in stream_path):
                        return source_key
                    best = source_key
            except Exception:
                pass
        return best

    def _migrateMultiServerRows(self, data):
        groups = {}
        changed = False
        for key, row in list(data.items()):
            if not isinstance(row, dict):
                continue
            ident = str(row.get("content_id") or self._contentIdentity(row))
            if not ident:
                continue
            if ident not in groups:
                groups[ident] = (key, row)
                row["content_id"] = ident
            else:
                keep_key, keep = groups[ident]
                # Newest progress/visuals win.
                if int(row.get("updated") or 0) > int(keep.get("updated") or 0):
                    old_keep_key, old_keep = keep_key, keep
                    keep_key, keep = key, row
                    groups[ident] = (keep_key, keep)
                    donor_key, donor = old_keep_key, old_keep
                else:
                    donor_key, donor = key, row

                keep_servers = dict(keep.get("servers") or {})
                donor_servers = dict(donor.get("servers") or {})
                for skey, sentry in donor_servers.items():
                    if skey:
                        keep_servers[skey] = sentry
                for source_row in (keep, donor):
                    skey = str(source_row.get("source_key") or "")
                    if not skey and source_row.get("streamurl"):
                        skey = self._serverKeyFromStreamUrl(source_row.get("streamurl"))
                        if skey:
                            source_row["source_key"] = skey
                            changed = True
                    if skey and source_row.get("streamurl"):
                        keep_servers[skey] = {
                            "source_key": skey,
                            "source_type": source_row.get("source_type") or "xtream",
                            "streamurl": source_row.get("streamurl"),
                            "service_type": int(source_row.get("service_type") or 4097),
                            "item": dict(source_row.get("item") or {}),
                        }
                keep["servers"] = keep_servers
                keep["content_id"] = ident
                data[keep_key] = keep
                if donor_key in data and donor_key != keep_key:
                    del data[donor_key]
                changed = True

        # Migrate single legacy rows too.
        for key, row in list(data.items()):
            if not isinstance(row, dict):
                continue
            row["content_id"] = str(row.get("content_id") or self._contentIdentity(row))
            servers = dict(row.get("servers") or {})
            skey = str(row.get("source_key") or "")
            if not skey and row.get("streamurl"):
                skey = self._serverKeyFromStreamUrl(row.get("streamurl"))
                if skey:
                    row["source_key"] = skey
                    changed = True
            if skey and row.get("streamurl") and skey not in servers:
                servers[skey] = {
                    "source_key": skey,
                    "source_type": row.get("source_type") or "xtream",
                    "streamurl": row.get("streamurl"),
                    "service_type": int(row.get("service_type") or 4097),
                    "item": dict(row.get("item") or {}),
                }
                row["servers"] = servers
                changed = True
            data[key] = row
        return changed

    def reload(self):
        data = self._load()
        try:
            if self._migrateMultiServerRows(data):
                self._save(data)
        except Exception:
            pass
        rows = sorted(data.items(), key=lambda p: int((p[1] or {}).get("updated", 0) or 0), reverse=True)
        self.movies = []
        self.series = []
        seen = set()
        duplicate_keys = []
        for key, row in rows:
            if not isinstance(row, dict):
                continue
            try:
                pos = int(row.get("position") or 0)
                length = int(row.get("length") or 0)
                if length > 0 and pos >= int(length * 0.95):
                    continue
            except Exception:
                pass
            if self._isSeries(row):
                ident = self._seriesIdentity(key, row)
                if ident in seen:
                    # Keep only the newest unfinished episode/card for a show.
                    duplicate_keys.append(key)
                    continue
                seen.add(ident)
                self.series.append((key, row))
            else:
                self.movies.append((key, row))

        # Also clean duplicate legacy records from disk, so reopening Continue
        # Watching cannot make the same show reappear again.
        if duplicate_keys:
            changed = False
            for key in duplicate_keys:
                if key in data:
                    try:
                        del data[key]
                        changed = True
                    except Exception:
                        pass
            if changed:
                self._save(data)

        if self.row == 0 and not self.movies and self.series:
            self.row = 1
        elif self.row == 1 and not self.series and self.movies:
            self.row = 0
        self.index = 0
        self.renderRows()
        self.updateFocus()
    def _pageRows(self,row=None):
        row=self.row if row is None else row; items=self.movies if row==0 else self.series; page=self.moviePage if row==0 else self.seriesPage; s=page*self.CARD_COUNT
        return items[s:s+self.CARD_COUNT]
    def _pct(self,row):
        try:
            pos=int(row.get("position") or 0); length=int(row.get("length") or 0); return max(0,min(100,int(pos*100.0/length))) if length>0 else 0
        except Exception: return 0
    def _title(self,row):
        item=row.get("item") or {}
        if self._isSeries(row): return str(row.get("series_title") or item.get("series_name") or item.get("_tmdb_title") or row.get("title") or item.get("name") or item.get("title") or tr("TV Show"))
        return str(row.get("title") or item.get("name") or item.get("title") or tr("Movie"))
    def _updatePosterBottomControl(self):
        try:
            if self.viewMode == "poster":
                self["posterBottomControl"].show()
                self["backdropBottomControl"].hide()
            else:
                self["posterBottomControl"].hide()
                self["backdropBottomControl"].show()
        except Exception:
            pass

    def toggleViewMode(self):
        self.viewMode = "poster" if self.viewMode == "backdrop" else "backdrop"
        self._saveViewMode()
        self._updatePosterBottomControl()
        self._applyContinueViewLayout()
        self.renderRows()
        self.updateFocus()

    def _posterAsset(self,row):
        item=row.get("item") or {}
        value=(item.get("stream_icon") or item.get("movie_image") or item.get("cover") or
               item.get("cover_big") or item.get("poster") or item.get("poster_url") or
               item.get("poster_path") or row.get("poster") or "")
        value=str(value or "").strip().replace("\\/","/")
        if value.startswith("/") and not value.startswith("//"):
            return IMAGE_BASE+"w500"+value
        return value

    def _resolvePosterAsync(self, key, row, widget):
        title = self._title(row)
        kind = "series" if self._isSeries(row) else "vod"
        item = row.get("item") or {}
        year = item.get("year") or row.get("year") or ""
        generation = self._generation
        def worker():
            try:
                result = TMDbClient().search_artwork(title, kind=kind, year=year, required_key="poster_path") or {}
                path = result.get("poster_path") or ""
                url = IMAGE_BASE + "w500" + path if path else ""
            except Exception:
                url = ""
            if not url or generation != self._generation:
                return
            data = self._load()
            rec = data.get(key)
            if isinstance(rec, dict):
                rec["poster"] = url
                data[key] = rec
                self._save(data)
            self._loadPosterArtwork(url, widget, generation)
        t = threading.Thread(target=worker, name="TiviMateContinuePoster")
        t.daemon = True
        t.start()

    def _applyContinueViewLayout(self):
        poster = self.viewMode == "poster"
        # The large Continue Watching hero is independent from card view mode.
        # Never hide it when switching Poster/Backdrop.
        try:
            self["hero"].show()
        except Exception:
            pass
        # Cards become portrait in Poster mode.
        for slot in range(8):
            col=slot if slot<4 else slot-4
            base_x=self.X[col]
            base_y=self.MOVIE_Y if slot<4 else self.SERIES_Y
            try:
                w=self["card%d"%slot]
                if poster:
                    w.instance.move(ePoint(sx(base_x+125),sy(base_y+2)))
                    w.instance.resize(eSize(sx(160),sy(205)))
                else:
                    w.instance.move(ePoint(sx(base_x+2),sy(base_y+2)))
                    w.instance.resize(eSize(sx(406),sy(160)))
            except Exception:
                pass

    def _asset(self,row):
        item=row.get("item") or {}; value=row.get("backdrop") or item.get("_player_backdrop") or item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url") or ""
        value=str(value or "").strip().replace("\\/","/")
        if value.startswith("/") and not value.startswith("//"): return IMAGE_BASE+"w1280"+value
        return value
    def _resolveBackdropAsync(self,key,row,widget):
        title=self._title(row); kind="series" if self._isSeries(row) else "vod"; item=row.get("item") or {}; year=item.get("year") or row.get("year") or ""; generation=self._generation
        def worker():
            try:
                result=TMDbClient().search_artwork(title,kind=kind,year=year,required_key="backdrop_path") or {}; path=result.get("backdrop_path") or ""; url=backdrop_url(path) if path else ""
            except Exception: url=""
            if not url or generation!=self._generation: return
            data=self._load(); rec=data.get(key)
            if isinstance(rec,dict): rec["backdrop"]=url; data[key]=rec; self._save(data)
            self._loadArtwork(url,widget,generation)
        t=threading.Thread(target=worker,name="TiviMateContinueBackdrop"); t.daemon=True; t.start()
    def _loadArtwork(self,url,widget,generation):
        if not url: return
        if widget=="hero": self._heroUrl=url
        def done(path,expected=widget,g=generation,u=url):
            if g!=self._generation or not path: return
            if expected=="hero" and u!=self._heroUrl: return
            try:
                w=self[expected]
                if w.instance: w.instance.setPixmapFromFile(path); w.show(); return
            except Exception: pass
            loader=ePicLoad(); self._loaders.append(loader)
            def ready(_=None,ll=loader,name=expected):
                try:
                    ptr=ll.getData(); w=self[name]
                    if ptr and w.instance: w.instance.setPixmap(ptr); w.show()
                except Exception: pass
                try:self._loaders.remove(ll)
                except Exception: pass
            connect_picture_data(loader,ready,self); size=(1920,500) if expected=="hero" else ((160,205) if self.viewMode=="poster" else (406,206)); rw,rh=scale_size(*size); loader.setPara((rw,rh,0,0,False,1,"#00000000")); loader.startDecode(path)
        # Share the exact same backdrop cache used by Movies/TV Shows/details.
        # Same URL => same HDD file; Continue Watching never downloads it twice.
        try: request_artwork(url,"backdrops",done,priority=35)
        except Exception: pass
    def _loadPosterArtwork(self,url,widget,generation):
        if not url:return
        def done(path,expected=widget,g=generation):
            if g!=self._generation or not path or self.viewMode!="poster":return
            try:
                w=self[expected]
                if w.instance:
                    w.instance.setPixmapFromFile(path); w.show()
            except Exception:
                pass
        try:request_artwork(url,"posters",done,priority=40)
        except Exception:pass

    def renderRows(self):
        self._generation+=1; g=self._generation; ph=os.path.join(PLUGIN_PATH,"skins","banner_placeholder.jpg"); m=self._pageRows(0); s=self._pageRows(1)
        mp=((len(self.movies)+3)//4) if self.movies else 0; sp=((len(self.series)+3)//4) if self.series else 0
        self["moviesPage"].setText("%d  •  %d/%d"%(len(self.movies),self.moviePage+1 if self.movies else 0,mp)); self["seriesPage"].setText("%d  •  %d/%d"%(len(self.series),self.seriesPage+1 if self.series else 0,sp))
        for slot in range(8):
            rows=m if slot<4 else s; idx=slot if slot<4 else slot-4; image=self["card%d"%slot]; title=self["title%d"%slot]; meta=self["meta%d"%slot]
            if idx>=len(rows):
                is_movies = slot < 4
                default_path = os.path.join(
                    PLUGIN_PATH, "skins",
                    "continue_default_movies.jpg" if is_movies else "continue_default_series.jpg"
                )
                title.setText("")
                meta.setText("")
                try:
                    if image.instance and os.path.exists(default_path):
                        image.instance.setPixmapFromFile(default_path)
                    image.show()
                except Exception:
                    pass
                continue
            key,row=rows[idx]; title.setText(self._title(row)[:38]); pct=self._pct(row); meta.setText(("%d%%"%pct) if pct else tr("Resume"))
            try:
                image.show()
                if image.instance and os.path.exists(ph): image.instance.setPixmapFromFile(ph)
            except Exception: pass
            if self.viewMode == "poster":
                url = self._posterAsset(row)
                if url:
                    self._loadPosterArtwork(url, "card%d" % slot, g)
                else:
                    self._resolvePosterAsync(key, row, "card%d" % slot)
            else:
                url = self._asset(row)
                if url:
                    self._loadArtwork(url, "card%d" % slot, g)
                else:
                    self._resolveBackdropAsync(key, row, "card%d" % slot)
        all_resume_rows = [row for _key, row in list(self.movies or []) + list(self.series or [])]
        if self.viewMode == "poster":
            prefetch_artwork([self._posterAsset(row) for row in all_resume_rows if self._posterAsset(row)], "posters", priority=2)
        prefetch_artwork([self._asset(row) for row in all_resume_rows if self._asset(row)], "backdrops", priority=1)
        self["empty"].setText(tr("Your unfinished movies and TV shows will appear here.") if not self.movies and not self.series else "")
    def _selected(self):
        rows=self._pageRows(); self.index=min(max(0,self.index),len(rows)-1) if rows else 0; return rows[self.index] if rows else None
    def updateFocus(self):
        rows=self._pageRows()
        if not rows:
            x = self.X[0]
            y = self.MOVIE_Y if self.row == 0 else self.SERIES_Y
            try:
                self["focus"].instance.move(ePoint(sx(x), sy(y)))
                self["focus"].show()
            except Exception:
                pass
            default_hero = os.path.join(PLUGIN_PATH, "skins", "continue_default_hero.jpg")
            try:
                if self["hero"].instance and os.path.exists(default_hero):
                    self["hero"].instance.setPixmapFromFile(default_hero)
                    self["hero"].show()
            except Exception:
                pass
            self["heroTitle"].setText(tr("YOUR STORY CONTINUES HERE"))
            self["heroMeta"].setText(tr("Movies  •  TV Shows"))
            try:
                self["heroStars"].setText("★★★★★")
            except Exception:
                pass
            self["heroDesc"].setText(tr("Pick up where you left off. Your movies and TV shows will appear here automatically."))
            self["heroProgress"].setValue(0)
            self["heroPercent"].setText("")
            return

        self.index=min(max(0,self.index),len(rows)-1)
        x=self.X[self.index]
        y=self.MOVIE_Y if self.row==0 else self.SERIES_Y
        try:
            self["focus"].instance.move(ePoint(sx(x),sy(y)))
            self["focus"].show()
        except Exception:
            pass

        key,row=self._selected()
        pct=self._pct(row)
        self["heroTitle"].setText(self._title(row)[:55])

        try:
            pos=int(row.get("position") or 0)
            total=int(row.get("length") or 0)
        except Exception:
            pos=total=0

        def clock(v):
            h=v//3600
            m=(v%3600)//60
            return ("%dh %02dm"%(h,m)) if h else ("%d min"%m)

        item=row.get("item") or {}
        year=""
        raw_year=" ".join(str(x or "") for x in (
            row.get("year"), item.get("year"), item.get("releaseDate"),
            item.get("release_date"), item.get("first_air_date"), self._title(row)
        ))
        match=re.search(r"\b(19|20)\d{2}\b", raw_year)
        if match:
            year=match.group(0)

        genre=str(row.get("genre") or item.get("genre") or "").strip()
        media_label=tr("TV Show") if self._isSeries(row) else tr("Movie")
        parts=[media_label]
        if year: parts.append(year)
        if genre: parts.append(genre[:38])
        if pos: parts.append(clock(pos))
        if total: parts.append(clock(total))
        self["heroMeta"].setText("  •  ".join(parts))

        raw_rating=row.get("rating") or item.get("rating") or item.get("vote_average") or 0
        try:
            rating=float(str(raw_rating).replace(",", "."))
            if rating>10.0:
                rating=rating/10.0
            rating=max(0.0,min(10.0,rating))
        except Exception:
            rating=0.0
        stars=int(round(rating/2.0)) if rating else 0
        star_text=("★"*stars)+("☆"*(5-stars)) if rating else "☆☆☆☆☆"
        try:
            self["heroStars"].setText(("%s   %.1f/10"%(star_text,rating)) if rating else star_text)
        except Exception:
            pass

        overview=str(row.get("overview") or item.get("plot") or item.get("description") or item.get("overview") or "").strip()
        self["heroDesc"].setText(overview[:280] if overview else tr("OK Play   •   MENU Options"))

        self["heroProgress"].setValue(pct)
        self["heroPercent"].setText("%d%%"%pct if pct else "")
        url=self._asset(row)
        if url:
            self._loadArtwork(url,"hero",self._generation)
        else:
            self._resolveBackdropAsync(key,row,"hero")


    def _updateTopFocus(self):
        try:
            index = max(0, min(self.topIndex, len(self.topX) - 1))
            cell_w = self.topW[index]
            x = self.topX[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(88)))
            self["topSelector"].setVisible(self.navFocus == "top")
        except Exception:
            pass
        try:
            self["focus"].setVisible(self.navFocus != "top")
        except Exception:
            pass


    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def _openTop(self):
        if self.topIndex == 0:
            self._openPageOnce(TiviMateE2Search, self.currentSource); return
        if self.topIndex == 1:
            self._openPageOnce(TiviMateE2Home); return
        if self.topIndex == 2:
            self._openPageOnce(MediaScreen, self.currentSource, "live"); return
        if self.topIndex == 3:
            self._openPageOnce(ContentHomeScreen, self.currentSource, "vod"); return
        if self.topIndex == 4:
            self._openPageOnce(ContentHomeScreen, self.currentSource, "series"); return
        if self.topIndex == 5:
            self._openPageOnce(ContentPackagesScreen, self.currentSource); return
        if self.topIndex == 6:
            self.navFocus = "content"; self._updateTopFocus(); return
        if self.topIndex == 7:
            self._openPageOnce(SettingsDashboard); return


    def left(self):
        if self.navFocus == "top":
            self.topIndex = (self.topIndex - 1) % len(self.topNames)
            self._updateTopFocus()
            return
        rows=self._pageRows()
        if not rows:return
        if self.index>0:self.index-=1
        else:
            page=self.moviePage if self.row==0 else self.seriesPage
            if page>0:
                if self.row==0:self.moviePage-=1
                else:self.seriesPage-=1
                self.index=min(3,len(self._pageRows())-1); self.renderRows()
        self.updateFocus()

    def right(self):
        if self.navFocus == "top":
            self.topIndex = (self.topIndex + 1) % len(self.topNames)
            self._updateTopFocus()
            return
        rows=self._pageRows()
        if not rows:return
        if self.index+1<len(rows):self.index+=1
        else:
            allrows=self.movies if self.row==0 else self.series; page=self.moviePage if self.row==0 else self.seriesPage
            if (page+1)*self.CARD_COUNT<len(allrows):
                if self.row==0:self.moviePage+=1
                else:self.seriesPage+=1
                self.index=0; self.renderRows()
        self.updateFocus()

    def up(self):
        if self.navFocus == "top":
            return
        if self.row == 1:
            self.row = 0
            self.index = min(self.index, max(0, len(self._pageRows()) - 1))
            self.updateFocus()
            return
        self.navFocus = "top"
        self._updateTopFocus(); self.updateFocus()


    def down(self):
        if self.navFocus == "top":
            self.navFocus = "content"
            self.row = 0
            self.index = min(self.index, max(0, len(self._pageRows()) - 1))
            self._updateTopFocus(); self.updateFocus()
            return
        if self.row == 0 and self.series:
            self.row = 1
            self.index = min(self.index, max(0, len(self._pageRows()) - 1))
            self.updateFocus()


    def _sourceForRow(self,row):
        key=str(row.get("source_key") or ((row.get("item") or {}).get("_source_key")) or ""); source_type=str(row.get("source_type") or ((row.get("item") or {}).get("_source_type")) or ""); sources=get_sources() or []
        if key:
            for source in sources:
                try:
                    if _source_identity(source)==key:return source
                except Exception:pass
        if source_type:
            for source in sources:
                if str(source.get("type") or "")==source_type:return source
        return sources[0] if sources else None
    def _normSeriesName(self, value):
        value = str(value or "").strip().lower()
        value = re.sub(r"\b(?:19|20)\d{2}\b", " ", value)
        value = re.sub(r"(?i)\b(?:4k|uhd|fhd|hd|sd|1080p|720p|2160p|amz|amzn|nf|netflix|web[- ]?dl|webrip|bluray|ar|ara|arabic|en|eng|english)\b", " ", value)
        value = re.sub(r"[\[\]\(\)\{\}_\-|:/.]+", " ", value)
        value = re.sub(r"\s+", " ", value).strip()
        return value

    def _seriesIdLooksValid(self, row):
        item = row.get("item") or {}
        sid = str(row.get("series_id") or item.get("series_id") or "").strip()
        return sid if sid else ""

    def _resolveSeriesItemAsync(self, row):
        source = self._sourceForRow(row)
        if not source:
            self.session.open(
                MessageBox, tr("The original server is not available."),
                MessageBox.TYPE_INFO, timeout=5
            )
            return

        current = self._seriesIdLooksValid(row)
        if current:
            self.session.open(SeriesDetailsScreen, source, self._seriesItem(row))
            return

        wanted = self._normSeriesName(self._title(row))
        self["heroDesc"].setText(tr("Finding the series on the server..."))

        def worker():
            match = None
            try:
                client = get_source_client(dict(source))
                rows = get_filtered_streams(source, "series", client, use_cache=True) or []
                best_score = -1
                for candidate in rows:
                    name = candidate.get("name") or candidate.get("title") or ""
                    norm = self._normSeriesName(name)
                    if not norm:
                        continue
                    if norm == wanted:
                        match = candidate
                        best_score = 1000
                        break
                    score = 0
                    if wanted and (wanted in norm or norm in wanted):
                        score = 800 - abs(len(wanted) - len(norm))
                    else:
                        # Token overlap is safer than guessing by episode stream_id.
                        a = set(wanted.split())
                        b = set(norm.split())
                        if a and b:
                            score = int(100.0 * len(a & b) / max(len(a), len(b)))
                    if score > best_score:
                        best_score = score
                        match = candidate
                if best_score < 55:
                    match = None
            except Exception:
                match = None

            def finish():
                if not match:
                    self["heroDesc"].setText(tr("Could not match this series to the server catalog."))
                    return
                data = self._load()
                selected = self._selected()
                key = selected[0] if selected else None
                if key and key in data and isinstance(data[key], dict):
                    rec = data[key]
                    rec["series_id"] = match.get("series_id") or match.get("stream_id") or match.get("id") or ""
                    rec["series_title"] = match.get("name") or match.get("title") or self._title(row)
                    saved_item = dict(rec.get("item") or {})
                    saved_item["series_id"] = rec["series_id"]
                    saved_item["series_name"] = rec["series_title"]
                    rec["item"] = saved_item
                    data[key] = rec
                    self._save(data)
                merged = dict(row)
                merged["series_id"] = match.get("series_id") or match.get("stream_id") or match.get("id") or ""
                merged["series_title"] = match.get("name") or match.get("title") or self._title(row)
                merged_item = dict(merged.get("item") or {})
                merged_item["series_id"] = merged["series_id"]
                merged_item["series_name"] = merged["series_title"]
                merged["item"] = merged_item
                self.session.open(SeriesDetailsScreen, source, self._seriesItem(merged))

            try:
                if reactor:
                    reactor.callFromThread(finish)
                else:
                    finish()
            except Exception:
                pass

        t = threading.Thread(target=worker, name="TiviMateContinueSeriesResolver")
        t.daemon = True
        t.start()

    def _seriesItem(self,row):
        item = dict(row.get("item") or {})
        item["name"] = row.get("series_title") or item.get("series_name") or item.get("_tmdb_title") or self._title(row)
        item["series_name"] = item["name"]
        sid = row.get("series_id") or item.get("series_id") or ""
        item["series_id"] = sid
        # Remove episode-only stream identity so SeriesDetailsScreen can never
        # mistake an episode stream_id for the parent series_id.
        item.pop("stream_id", None)
        item.pop("episode_id", None)
        item["_tmdb_kind"] = "series"
        return item
    def ok(self):
        if self.navFocus == "top":
            self._openTop()
            return
        selected = self._selected()
        if not selected:
            return
        _key, row = selected
        self.playMovie(row)

    def playMovie(self,row):
        try:
            play_vod_exact_continue_path(
                self.session,
                row,
                current_source=dict(self.currentSource or {}),
                callback=lambda *a: self.reload()
            )
        except Exception as exc:
            self.session.open(
                MessageBox,
                "%s\n%s" % (tr("Unable to play this item."), exc),
                MessageBox.TYPE_ERROR
            )

    def removeSelected(self):
        selected=self._selected()
        if not selected:return
        data=self._load(); data.pop(selected[0],None); self._save(data); self.reload()
    def clearAll(self):self.session.openWithCallback(self._clearConfirm,MessageBox,tr("Clear all Continue Watching history?"),MessageBox.TYPE_YESNO)
    def _clearConfirm(self,yes):
        if yes:self._save({}); self.moviePage=0; self.seriesPage=0; self.reload()
    def openOptions(self):
        selected=self._selected(); choices=[]
        if selected: choices.append((tr("Play"),"open")); choices.extend([(tr("Remove from Continue Watching"),"remove"),(tr("Mark as Watched"),"remove")])
        choices.append((tr("Clear Continue Watching"),"clear")); self.session.openWithCallback(self._optionChosen,ChoiceBox,title=tr("Continue Watching"),list=choices)
    def _optionChosen(self,choice):
        if not choice:return
        action=choice[1]
        if action=="open":self.ok()
        elif action=="remove":self.removeSelected()
        elif action=="clear":self.clearAll()



def play_vod_exact_continue_path(session, row, current_source=None, callback=None):
    """Exact Continue Watching VOD playback path shared by Continue and Movies."""
    current_source = dict(current_source or {})
    current_key = ""
    try:
        current_key = _source_identity(current_source)
    except Exception:
        current_key = ""

    servers = dict((row or {}).get("servers") or {})
    selected = None

    # Exact Continue Watching server-selection order.
    if current_key:
        selected = servers.get(current_key)

    if not selected:
        legacy_key = str((row or {}).get("source_key") or "")
        if legacy_key and legacy_key in servers:
            selected = servers.get(legacy_key)

    if not selected:
        for skey, sentry in list(servers.items()):
            if isinstance(sentry, dict) and sentry.get("streamurl"):
                selected = sentry
                break

    if selected:
        item = dict(selected.get("item") or {})
        url = str(selected.get("streamurl") or "")
        source_type = selected.get("source_type") or (row or {}).get("source_type") or current_source.get("type") or "xtream"
        source_key = selected.get("source_key") or (row or {}).get("source_key") or current_key
        saved_service_type = selected.get("service_type") or (row or {}).get("service_type")
    else:
        item = dict((row or {}).get("item") or {})
        url = str((row or {}).get("streamurl") or item.get("_streamurl") or "")
        source_type = (row or {}).get("source_type") or item.get("_source_type") or current_source.get("type") or "xtream"
        source_key = (row or {}).get("source_key") or item.get("_source_key") or ""
        saved_service_type = (row or {}).get("service_type")

    if not url:
        raise RuntimeError("Playback link is not available for this item.")

    # Keep the same payload shape as Continue Watching, but do not force Resume.
    item.pop("_continue_resume", None)
    item.pop("_continue_position", None)
    item["_source_type"] = source_type
    item["_source_key"] = source_key
    item.setdefault("name", (row or {}).get("title") or item.get("title") or "MOVIE")

    # Exact Continue Watching service-type logic.
    try:
        st = int(_load_player_type())
    except Exception:
        try:
            st = int(saved_service_type or 4097)
        except Exception:
            st = 4097

    ref = eServiceReference(st, 0, url)
    ref.setName((row or {}).get("title") or item.get("name") or item.get("title") or "MOVIE")

    if callback is not None:
        session.openWithCallback(callback, TiviMatePlayer, ref, item)
    else:
        session.open(TiviMatePlayer, ref, item)


from .live_player import TiviMateLivePlayer


