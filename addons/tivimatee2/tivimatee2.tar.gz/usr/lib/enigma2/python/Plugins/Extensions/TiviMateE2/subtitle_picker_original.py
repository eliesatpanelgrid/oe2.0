# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Sources.StaticText import StaticText
from Components.MultiContent import MultiContentEntryText
from enigma import eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, getDesktop

def _(text):
    return text

class SubtitlePicker(Screen):
    """
    Responsive subtitle-line picker with aligned columns and fixed-height rows.

    eListboxPythonMultiContent supports only one item height for the complete
    list.  Using a different height for each subtitle row causes misaligned
    columns and clipped entries, because the last processed row silently wins.
    This screen therefore uses one resolution-aware row height and displays up
    to two text lines per subtitle entry.
    """

    def __init__(self, session, subsList, currentIndex):
        self.subsList = subsList or []
        try:
            self.currentIndex = int(currentIndex)
        except Exception:
            self.currentIndex = 0

        self._configure_layout()
        Screen.__init__(self, session)

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions", "SubtitlePickerActions"],
            {
                "ok": self.selectSubtitle,
                "green": self.selectSubtitle,
                "cancel": self.close,
                "red": self.close,
                "left": self.selectSubtitleFineEarlier,
                "right": self.selectSubtitleFineLater,
                "firstSubtitle": self.firstSubtitle,
                "lastSubtitle": self.lastSubtitle,
            },
            -1
        )

        self["subList"] = MenuList(
            [], enableWrapAround=True, content=eListboxPythonMultiContent
        )
        self["subList"].l.setItemHeight(self.row_height)
        self["subList"].l.setFont(0, gFont("Regular", self.row_font_size))

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Select"))

        self.updateSubtitleList()
        self.onLayoutFinish.append(self.setInitialSelection)

    def _configure_layout(self):
        """Build a conservative picker layout for SD, HD and Full-HD skins."""
        desktop = getDesktop(0).size()
        desktop_width = desktop.width()
        desktop_height = desktop.height()

        if desktop_width >= 1920:
            screen_width = min(1540, desktop_width - 120)
            screen_height = min(900, desktop_height - 100)
            self.row_height = 78
            self.row_font_size = 26
            header_font_size = 27
            instruction_font_size = 24
            footer_font_size = 26
            header_height = 42
            instruction_height = 38
            footer_height = 48
        elif desktop_width >= 1280:
            screen_width = min(1120, desktop_width - 80)
            screen_height = min(650, desktop_height - 60)
            self.row_height = 68
            self.row_font_size = 22
            header_font_size = 23
            instruction_font_size = 21
            footer_font_size = 22
            header_height = 38
            instruction_height = 34
            footer_height = 42
        else:
            screen_width = min(700, desktop_width - 20)
            screen_height = min(540, desktop_height - 20)
            self.row_height = 58
            self.row_font_size = 18
            header_font_size = 19
            instruction_font_size = 17
            footer_font_size = 18
            header_height = 34
            instruction_height = 30
            footer_height = 38

        # Always reserve enough vertical space for ten complete subtitle rows.
        # On smaller screens, reduce row height proportionally so the picker
        # remains fully visible while still displaying exactly ten items.
        visible_rows = 10
        padding = 10
        instruction_y = 8
        header_y = instruction_y + instruction_height + 4
        list_y = header_y + header_height + 4
        max_screen_height = max(1, desktop_height - 20)
        fixed_height = list_y + 8 + footer_height + 8
        max_row_height = max(1, int((max_screen_height - fixed_height) / visible_rows))
        self.row_height = min(self.row_height, max_row_height)
        self.row_font_size = max(14, min(self.row_font_size, int((self.row_height - 12) / 2)))
        list_height = self.row_height * visible_rows
        footer_y = list_y + list_height + 8
        screen_height = footer_y + footer_height + 8
        list_width = screen_width - (padding * 2)

        self.number_width = max(64, int(list_width * 0.09))
        self.time_width = max(170, int(list_width * 0.23))
        self.subtitle_width = list_width - self.number_width - self.time_width

        self.number_x = 0
        self.time_x = self.number_width
        self.subtitle_x = self.number_width + self.time_width

        button_width = min(220, int((list_width - 12) / 2))
        green_x = padding + button_width + 12

        self.skin = """
            <screen name="SubtitlePicker" position="center,center" size="%(screen_width)d,%(screen_height)d" title="Select Current Subtitle Line">
                <eLabel position="%(padding)d,%(instruction_y)d" size="%(list_width)d,%(instruction_height)d" font="Regular;%(instruction_font_size)d" valign="center" halign="center" foregroundColor="#FFFFFF" backgroundColor="#303030" text="Press OK to select subtitle line" />
                <eLabel position="%(padding)d,%(header_y)d" size="%(number_width)d,%(header_height)d" font="Regular;%(header_font_size)d" foregroundColor="#FFFFFF" backgroundColor="#202020" text="No." />
                <eLabel position="%(time_header_x)d,%(header_y)d" size="%(time_width)d,%(header_height)d" font="Regular;%(header_font_size)d" foregroundColor="#FFFFFF" backgroundColor="#202020" text="Time" />
                <eLabel position="%(subtitle_header_x)d,%(header_y)d" size="%(subtitle_width)d,%(header_height)d" font="Regular;%(header_font_size)d" foregroundColor="#FFFFFF" backgroundColor="#202020" text="Subtitle" />
                <widget name="subList" position="%(padding)d,%(list_y)d" size="%(list_width)d,%(list_height)d" scrollbarMode="showOnDemand" />
                <widget source="key_red" render="Label" position="%(padding)d,%(footer_y)d" size="%(button_width)d,%(footer_height)d" font="Regular;%(footer_font_size)d" valign="center" halign="center" foregroundColor="#FFFFFF" backgroundColor="#A00000" />
                <widget source="key_green" render="Label" position="%(green_x)d,%(footer_y)d" size="%(button_width)d,%(footer_height)d" font="Regular;%(footer_font_size)d" valign="center" halign="center" foregroundColor="#FFFFFF" backgroundColor="#008000" />
            </screen>
        """ % {
            "screen_width": screen_width,
            "screen_height": screen_height,
            "padding": padding,
            "header_y": header_y,
            "header_height": header_height,
            "header_font_size": header_font_size,
            "instruction_y": instruction_y,
            "instruction_height": instruction_height,
            "instruction_font_size": instruction_font_size,
            "number_width": self.number_width,
            "time_width": self.time_width,
            "subtitle_width": self.subtitle_width,
            "time_header_x": padding + self.time_x,
            "subtitle_header_x": padding + self.subtitle_x,
            "list_y": list_y,
            "list_width": list_width,
            "list_height": list_height,
            "footer_y": footer_y,
            "footer_height": footer_height,
            "footer_font_size": footer_font_size,
            "button_width": button_width,
            "green_x": green_x,
        }

    def firstSubtitle(self):
        """Jump to the first subtitle."""
        if self.subsList:
            self["subList"].moveToIndex(0)

    def lastSubtitle(self):
        """Jump to the final subtitle."""
        if self.subsList:
            self["subList"].moveToIndex(len(self.subsList) - 1)

    def selectSubtitle(self):
        """Return the highlighted subtitle index to the controller."""
        index = self["subList"].getSelectedIndex()
        if 0 <= index < len(self.subsList):
            self.close(index)

    def _selectSubtitleFine(self, offset_ms):
        """Select the highlighted cue with a tiny manual sync correction.

        LEFT/RIGHT intentionally do not change the visual layout.  They are a
        precision variant of OK/green for cases where the chosen line is only
        a fraction of a second early/late.
        """
        index = self["subList"].getSelectedIndex()
        if 0 <= index < len(self.subsList):
            self.close((index, int(offset_ms)))

    def selectSubtitleFineEarlier(self):
        # Move the subtitle 200 ms earlier than the normal line sync.
        self._selectSubtitleFine(-200)

    def selectSubtitleFineLater(self):
        # Move the subtitle 200 ms later than the normal line sync.
        self._selectSubtitleFine(200)

    def updateSubtitleList(self):
        """Populate the picker with aligned fixed-height multi-content rows."""
        menu_items = []
        vertical_padding = 6
        single_line_y = max(0, int((self.row_height - self.row_font_size) / 2))

        for subtitle in self.subsList:
            try:
                caption_number = "%d" % (int(subtitle.get("index", 0)) + 1)
            except Exception:
                caption_number = "?"

            timestamp = self.format_time(subtitle.get("start", 0))
            subtitle_text = self.clean_display_text(subtitle.get("text") or "")
            display_text = self._limit_display_lines(subtitle_text, max_lines=2)

            row = [
                subtitle,
                MultiContentEntryText(
                    pos=(self.number_x + 6, single_line_y),
                    size=(self.number_width - 10, self.row_font_size + 6),
                    font=0,
                    text=caption_number,
                    flags=RT_HALIGN_LEFT
                ),
                MultiContentEntryText(
                    pos=(self.time_x + 6, single_line_y),
                    size=(self.time_width - 10, self.row_font_size + 6),
                    font=0,
                    text=timestamp,
                    flags=RT_HALIGN_LEFT
                ),
                MultiContentEntryText(
                    pos=(self.subtitle_x + 6, vertical_padding),
                    size=(self.subtitle_width - 12, self.row_height - (vertical_padding * 2)),
                    font=0,
                    text=display_text,
                    flags=RT_HALIGN_LEFT
                ),
            ]
            menu_items.append(row)

        self["subList"].l.setItemHeight(self.row_height)
        self["subList"].l.setList(menu_items)
        self["subList"].l.invalidate()

    def _limit_display_lines(self, text, max_lines=2):
        """Keep picker rows uniform while preserving common two-line subtitles."""
        lines = [line.strip() for line in text.replace("\r", "").split("\n") if line.strip()]
        if not lines:
            return ""
        if len(lines) <= max_lines:
            return "\n".join(lines)
        visible = lines[:max_lines]
        visible[-1] = visible[-1] + " ..."
        return "\n".join(visible)

    def clean_display_text(self, text):
        """Remove RTL/LTR control characters that appear as picker artifacts."""
        control_chars = (
            "\u202B",  # RTL embedding
            "\u202C",  # Pop directional formatting
            "\u202A",  # LTR embedding
            "\u202D",  # LTR override
            "\u202E",  # RTL override
            "\u200F",  # RTL mark
            "\u200E",  # LTR mark
        )
        for char in control_chars:
            text = text.replace(char, "")
        return text.strip()

    def setInitialSelection(self):
        """Open the picker on the currently playing subtitle where possible."""
        if not self.subsList:
            return
        index = min(max(self.currentIndex, 0), len(self.subsList) - 1)
        self["subList"].moveToIndex(index)

    def format_time(self, seconds):
        """Convert a subtitle start time to hh:mm:ss,ms."""
        try:
            seconds = float(seconds)
        except Exception:
            seconds = 0.0
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        millisecs = int(round((seconds - int(seconds)) * 1000))
        if millisecs >= 1000:
            secs += 1
            millisecs = 0
        return "%02d:%02d:%02d,%03d" % (hours, minutes, secs, millisecs)
