# -*- coding: utf-8 -*-
"""Safe, optional update checks for TiviMateE2 on Enigma2 images.

The updater retrieves only a small public JSON manifest over HTTPS.  It never
reads playlists, account data, API keys, favourites, or any local settings.
Package installation is started only after the user explicitly confirms it.
"""

import hashlib
import json
import os
import re

from urllib.request import Request, urlopen
from urllib.parse import urlparse

from shlex import quote as shell_quote

text_type = str

PLUGIN_VERSION = "1.0.10"
# Internal update sequence only; the user-facing plugin version is PLUGIN_VERSION.
CURRENT_REVISION = 118
MANIFEST_URL = "https://raw.githubusercontent.com/opesboy/TiviMateE2/main/update.json"
MANIFEST_MAX_BYTES = 64 * 1024
PACKAGE_MAX_BYTES = 100 * 1024 * 1024
REQUEST_TIMEOUT = 10
USER_AGENT = "TiviMateE2/%s" % PLUGIN_VERSION
REPOSITORY_PREFIX = "https://github.com/opesboy/TiviMateE2/"
RAW_REPOSITORY_PREFIX = "https://raw.githubusercontent.com/opesboy/TiviMateE2/"


def _text(value):
    if value is None:
        return ""
    if isinstance(value, text_type):
        return value
    try:
        return value.decode("utf-8")
    except Exception:
        try:
            return text_type(value)
        except Exception:
            return ""


def _clean_message(value, limit=800):
    value = _text(value).replace("\r", " ").replace("\x00", " ")
    value = "\n".join([line.strip() for line in value.split("\n") if line.strip()])
    return value[:limit]


def _read_url(url, maximum):
    request = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    response = urlopen(request, timeout=REQUEST_TIMEOUT)
    try:
        data = response.read(maximum + 1)
    finally:
        try:
            response.close()
        except Exception:
            pass
    if len(data) > maximum:
        raise ValueError("Update response is too large")
    return data


def _normalise_url(value):
    value = _text(value).strip()
    try:
        parsed = urlparse(value)
    except Exception:
        return ""
    if parsed.scheme != "https" or not parsed.netloc:
        return ""
    return value


def _trusted_package_url(value):
    value = _normalise_url(value)
    if not value:
        return ""
    if value.startswith(REPOSITORY_PREFIX) or value.startswith(RAW_REPOSITORY_PREFIX):
        return value
    return ""


def package_type():
    """Return the package format used by the current Enigma2 image."""
    if os.path.exists("/usr/bin/dpkg") or os.path.exists("/bin/dpkg"):
        return "deb"
    if os.path.exists("/usr/bin/opkg") or os.path.exists("/bin/opkg"):
        return "ipk"
    return ""


def _package_from_manifest(manifest, fmt):
    packages = manifest.get("packages") or {}
    package = packages.get(fmt) or {}
    if not isinstance(package, dict):
        return None
    url = _trusted_package_url(package.get("url"))
    checksum = _text(package.get("sha256")).lower().strip()
    if not url or not re.match(r"^[a-f0-9]{64}$", checksum):
        return None
    return {
        "format": fmt,
        "url": url,
        "sha256": checksum,
        "filename": "tivimatee2_update_%s.%s" % (int(manifest["revision"]), fmt),
    }


def check_for_update():
    """Fetch and validate the public manifest without raising user-facing errors."""
    result = {"available": False, "reason": "unavailable"}
    try:
        raw = _read_url(MANIFEST_URL, MANIFEST_MAX_BYTES)
        try:
            raw = raw.decode("utf-8")
        except Exception:
            pass
        manifest = json.loads(raw)
        if not isinstance(manifest, dict):
            return result
        revision = int(manifest.get("revision", 0))
        if revision <= CURRENT_REVISION:
            result["reason"] = "current"
            return result
        fmt = package_type()
        package = _package_from_manifest(manifest, fmt)
        if not package:
            result["reason"] = "no_package"
            return result
        result.update({
            "available": True,
            "reason": "available",
            "revision": revision,
            "version": _clean_message(manifest.get("version") or "1.0.3", 64),
            "notes": _clean_message(manifest.get("notes") or "", 800),
            "package": package,
        })
    except Exception:
        # No popup is shown for transient network, TLS, or server errors.
        pass
    return result


def download_package(package):
    """Download a selected package to /tmp and verify its SHA-256 digest."""
    try:
        if not isinstance(package, dict):
            raise ValueError("Invalid update package")
        url = _trusted_package_url(package.get("url"))
        expected = _text(package.get("sha256")).lower().strip()
        fmt = _text(package.get("format")).lower().strip()
        if not url or fmt not in ("deb", "ipk") or not re.match(r"^[a-f0-9]{64}$", expected):
            raise ValueError("Invalid update package")
        destination = os.path.join("/tmp", "tivimatee2_update.%s" % fmt)
        temporary = destination + ".part"
        try:
            os.unlink(temporary)
        except OSError:
            pass
        request = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/octet-stream"})
        response = urlopen(request, timeout=REQUEST_TIMEOUT)
        digest = hashlib.sha256()
        total = 0
        try:
            handle = open(temporary, "wb")
            try:
                while True:
                    block = response.read(65536)
                    if not block:
                        break
                    total += len(block)
                    if total > PACKAGE_MAX_BYTES:
                        raise ValueError("Update package is too large")
                    handle.write(block)
                    digest.update(block)
            finally:
                handle.close()
        finally:
            try:
                response.close()
            except Exception:
                pass
        if total < 1024 or digest.hexdigest().lower() != expected:
            try:
                os.unlink(temporary)
            except OSError:
                pass
            raise ValueError("Update verification failed")
        try:
            os.unlink(destination)
        except OSError:
            pass
        os.rename(temporary, destination)
        return {"ok": True, "path": destination, "format": fmt}
    except Exception as error:
        return {"ok": False, "message": _clean_message(error, 160) or "Download failed"}


def install_command(result):
    """Create the forced reinstall command for the already verified package."""
    path = _text((result or {}).get("path"))
    fmt = _text((result or {}).get("format")).lower()
    if not path or not os.path.isfile(path):
        return ""
    quoted = shell_quote(path)
    if fmt == "deb":
        return "dpkg -i %s" % quoted
    if fmt == "ipk":
        return "opkg install --force-reinstall %s" % quoted
    return ""
