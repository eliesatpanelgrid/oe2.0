# -*- coding: utf-8 -*-
"""Safe title normalization shared by the independent subtitle providers.

IPTV providers frequently prepend a server tag or append release metadata to a
content name.  The normalizer deliberately keeps an original-title fallback:
it helps a subtitle search ignore noisy names without making a false positive
prefix removal permanently hide a valid movie or series title.
"""

import re

text_type = str


# Only clearly non-title technical labels are removed from a tail.  Human title
# words such as "English" are left alone unless they appear in a compact tag.
_RELEASE_TOKEN_RE = re.compile(
    r"(?i)\b(?:2160p|1080p|720p|576p|480p|4320p|4k|8k|uhd|fhd|hd|sd|"
    r"hdr10(?:\+)?|hdr|dv|dolby[ ._-]*vision|web[ ._-]*(?:dl|rip)|"
    r"blu[ ._-]*ray|brrip|bdremux|remux|dvdrip|hdtv|webrip|"
    r"x[ ._-]?26[45]|h[ ._-]?26[45]|hevc|avc|aac(?:[ ._-]*[25]\.[01])?|"
    r"dts(?:[ ._-]*(?:hd|x))?|truehd|atmos|10bit|8bit|proper|repack|"
    r"extended|unrated|criterion|imax|multi[ ._-]*(?:audio|sub)?|"
    r"dubbed|subbed)\b"
)

_TAG_WORD_RE = re.compile(
    r"(?i)^(?:nf|netflix|amzn|amazon|disney(?:plus)?|hbo(?:max)?|"
    r"apple(?:tv)?|prime|iptv|vod|movie|movies|film|series|tv|"
    r"arabic|english|french|turkish|spanish|german|italian|hindi|"
    r"multi|dubbed|subbed|original|official|web[ ._-]*dl|web[ ._-]*rip|"
    r"blu[ ._-]*ray|hdr|uhd|fhd|hd|sd|4k|8k|[0-9]{3,4}p)$"
)


def _text(value):
    try:
        if isinstance(value, bytes):
            return value.decode("utf-8", "ignore").strip()
        return str(value or "").strip()
    except Exception:
        return ""


def _compact(value):
    return re.sub(r"[^A-Za-z0-9]+", "", _text(value))


def _looks_like_metadata_tag(value):
    value = _text(value).strip(" ._:-|")
    if not value or len(value) > 28:
        return False
    if _TAG_WORD_RE.match(value) or _RELEASE_TOKEN_RE.search(value):
        return True
    compact = _compact(value)
    # Provider tags are commonly short upper-case/digit identifiers.  The
    # original-name fallback protects rare titles such as [REC].
    return bool(compact and len(compact) <= 14 and compact.upper() == compact)


def _strip_leading_tags(value):
    text = _text(value)
    for _unused in range(5):
        before = text
        match = re.match(r"^\s*[\[\{<]([^\]\}>]{1,28})[\]\}>]\s*(?:[-|:._]+\s*)?", text)
        if match and _looks_like_metadata_tag(match.group(1)):
            text = text[match.end():]
        else:
            match = re.match(r"^\s*\(([^)]{1,28})\)\s*(?:[-|:._]+\s*)?", text)
            if match and _looks_like_metadata_tag(match.group(1)):
                text = text[match.end():]
            else:
                # A bare provider prefix can be any short all-caps code, not
                # just a hard-coded list such as NF.  It must have a separator.
                match = re.match(r"^\s*([A-Za-z0-9]{2,14})\s*(?:[-|:._]+\s*)", text)
                if match and _looks_like_metadata_tag(match.group(1)):
                    text = text[match.end():]
        if text == before:
            break
    return text


def _strip_release_tail(value):
    """Drop release data only from the first unambiguous technical token onward."""
    match = _RELEASE_TOKEN_RE.search(value)
    if match:
        prefix = value[:match.start()].rstrip(" ._:-|")
        if prefix:
            return prefix
    return value


def clean_subtitle_title(value):
    """Return the most likely content title after common IPTV naming noise."""
    original = _text(value)
    if not original:
        return ""
    text = original.replace(u"\u2013", "-").replace(u"\u2014", "-").replace(u"\u2212", "-")
    text = _strip_leading_tags(text)
    text = _strip_release_tail(text)
    # Search engines handle spaces more consistently than provider separators.
    text = re.sub(r"[\[\]{}<>|_]+", " ", text)
    text = re.sub(r"\s*[-:.]+\s*", " ", text)
    text = re.sub(r"\s+", " ", text).strip(" ._:-|")
    return text or original


def subtitle_title_candidates(value):
    """Return cleaned title first, then the untouched original as safe fallback."""
    original = _text(value)
    cleaned = clean_subtitle_title(original)
    values = []
    for candidate in (cleaned, original):
        candidate = _text(candidate)
        if candidate and candidate not in values:
            values.append(candidate)
    return values


def subtitle_search_queries(value, year=None, season=None, episode=None):
    """Build deduplicated title queries, preserving content facts when known."""
    result = []
    for title in subtitle_title_candidates(value):
        query = title
        try:
            season_value = int(season) if season is not None else None
            episode_value = int(episode) if episode is not None else None
        except Exception:
            season_value = None
            episode_value = None
        if season_value is not None and episode_value is not None:
            query = "%s S%02dE%02d" % (query, season_value, episode_value)
        elif year is not None:
            try:
                query = "%s %d" % (query, int(year))
            except Exception:
                pass
        query = _text(query)
        if query and query not in result:
            result.append(query)
    return result
