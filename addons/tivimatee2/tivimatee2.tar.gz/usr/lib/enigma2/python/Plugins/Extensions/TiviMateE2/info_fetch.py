# -*- coding: utf-8 -*-
from __future__ import absolute_import

import io
import json
import ssl
import sys

try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen


def _open_url(request, timeout):
    try:
        context = ssl._create_unverified_context()
    except Exception:
        context = None
    try:
        if context is not None:
            return urlopen(request, timeout=timeout, context=context)
        return urlopen(request, timeout=timeout)
    except TypeError:
        return urlopen(request, timeout=timeout)


def main():
    if len(sys.argv) < 3:
        return 2
    url, out = sys.argv[1], sys.argv[2]
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/0.6.3",
        "Accept": "application/json,*/*",
    })
    response = _open_url(request, 10)
    try:
        data = response.read()
    finally:
        try:
            response.close()
        except Exception:
            pass
    parsed = json.loads(data.decode("utf-8", "replace"))
    with io.open(out, "w", encoding="utf-8") as handle:
        json.dump(parsed, handle, ensure_ascii=False)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        raise SystemExit(1)
