# -*- coding: utf-8 -*-
"""TiviMateE2 global RAM governor.

Owns only TiviMateE2 Python caches.  It never drops Linux page cache and never
kills Enigma2 objects. Thresholds are percentages of MemTotal from /proc/meminfo.
"""
from __future__ import absolute_import
import gc
import os
import time

try:
    from enigma import eTimer
except Exception:
    eTimer = None

_TIMER = None
_LAST_LEVEL = -1

LIGHT_PCT = 60.0
STRONG_PCT = 70.0
CRITICAL_PCT = 80.0
INTERVAL_MS = 15000


def _ram_percent():
    try:
        vals = {}
        f = open("/proc/meminfo", "r")
        try:
            for line in f:
                if ":" not in line:
                    continue
                k, v = line.split(":", 1)
                p = v.strip().split()
                if p:
                    vals[k] = int(p[0])
        finally:
            f.close()
        total = float(vals.get("MemTotal", 0))
        if total <= 0:
            return 0.0
        avail = vals.get("MemAvailable")
        if avail is None:
            avail = vals.get("MemFree", 0) + vals.get("Buffers", 0) + vals.get("Cached", 0)
        used = max(0.0, total - float(avail))
        return (used * 100.0) / total
    except Exception:
        return 0.0


def _clear_dict(module, names, strong=False):
    for name in names:
        try:
            obj = getattr(module, name, None)
            if isinstance(obj, dict):
                # light pressure keeps roughly half of generic caches when possible
                if not strong and len(obj) > 4:
                    keys = list(obj.keys())
                    for key in keys[:max(1, len(keys)//2)]:
                        obj.pop(key, None)
                elif strong:
                    obj.clear()
        except Exception:
            pass


def cleanup(level=1):
    """level 1=light, 2=strong, 3=critical."""
    strong = level >= 2
    try:
        from . import core
        core.runtime_memory_cleanup(force_gc=strong)
        if level >= 3:
            try:
                core.clear_catalog_memory()
            except Exception:
                pass
    except Exception:
        pass

    # Filters contains Xtream/M3U/search/category RAM caches.
    try:
        from . import filters
        _clear_dict(filters, (
            "_RAM_STREAM_CACHE", "_RAM_CATALOG_CACHE", "_RAM_CATEGORY_CACHE"
        ), strong=strong)
    except Exception:
        pass

    # Details/Home decoded pixmaps are expensive. At strong pressure release them.
    if strong:
        try:
            from . import content_home
            _clear_dict(content_home, (
                "_DETAILS_PIXMAP_CACHE", "_DETAILS_DATA_CACHE"
            ), strong=True)
        except Exception:
            pass

    # Forced cyclic GC is reserved for strong/critical pressure.
    # Light cleanup (60%) stays non-blocking for Live playback.
    if strong:
        try:
            gc.collect()
        except Exception:
            pass


def _tick():
    global _LAST_LEVEL
    pct = _ram_percent()
    level = 0
    if pct >= CRITICAL_PCT:
        level = 3
    elif pct >= STRONG_PCT:
        level = 2
    elif pct >= LIGHT_PCT:
        level = 1
    if level:
        cleanup(level)
    _LAST_LEVEL = level


def start():
    global _TIMER
    if eTimer is None or _TIMER is not None:
        return
    try:
        _TIMER = eTimer()
        try:
            _TIMER.callback.append(_tick)
        except Exception:
            _TIMER.timeout.connect(_tick)
        _TIMER.start(INTERVAL_MS, False)
    except Exception:
        _TIMER = None


def stop():
    global _TIMER
    try:
        if _TIMER is not None:
            _TIMER.stop()
    except Exception:
        pass
    _TIMER = None
    cleanup(2)
