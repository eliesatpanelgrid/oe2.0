# -*- coding: utf-8 -*-
"""Deterministic player lifecycle guard.

A token identifies the currently owned playback generation. Async callbacks and
retries can cheaply reject work from an older stream after channel/title change
or player close. Stop/restore remains owned by the player itself.
"""
import threading
import time
from .diagnostics import event

class PlayerLifecycleGuard(object):
    def __init__(self):
        self.lock = threading.RLock()
        self.generation = 0
        self.closed = False
        self.state = "idle"
        self.started_at = 0.0

    def begin(self, stream_kind="", service_type=""):
        with self.lock:
            if self.closed:
                self.closed = False
            self.generation += 1
            self.state = "starting"
            self.started_at = time.time()
            token = self.generation
        event("player", "begin", generation=token, kind=stream_kind, service_type=service_type)
        return token

    def valid(self, token):
        with self.lock:
            return (not self.closed) and int(token or 0) == int(self.generation)

    def playing(self, token, service_type=""):
        if not self.valid(token):
            return False
        with self.lock:
            self.state = "playing"
        event("player", "playing", generation=token, service_type=service_type,
              startup_ms=int((time.time() - self.started_at) * 1000))
        return True

    def fail(self, token, reason=""):
        if not self.valid(token):
            return False
        with self.lock:
            self.state = "failed"
        event("player", "failed", generation=token, reason=reason)
        return True

    def invalidate(self, reason="switch"):
        with self.lock:
            self.generation += 1
            token = self.generation
            self.state = "idle"
        event("player", "invalidate", generation=token, reason=reason)
        return token

    def close(self):
        with self.lock:
            if self.closed:
                return self.generation
            self.closed = True
            self.generation += 1
            self.state = "closed"
            token = self.generation
        event("player", "close", generation=token)
        return token
