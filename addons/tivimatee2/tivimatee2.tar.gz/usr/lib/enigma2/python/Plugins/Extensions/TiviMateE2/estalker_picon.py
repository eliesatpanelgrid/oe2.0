# -*- coding: utf-8 -*-
import os
import tempfile
import hashlib
import threading

from PIL import Image
from twisted.web.client import downloadPage
from .cache_manager import get_cache_dir, cleanup_cache

from urllib.parse import urlparse

try:
    from twisted.internet import ssl
    from twisted.internet._sslverify import ClientTLSOptions
    _SSLVERIFY = True
except Exception:
    ssl = None
    ClientTLSOptions = None
    _SSLVERIFY = False


if _SSLVERIFY:
    class SNIFactory(ssl.ClientContextFactory):
        def __init__(self, hostname=None):
            self.hostname = hostname
        def getContext(self):
            ctx = self._contextFactory(self.method)
            if self.hostname:
                ClientTLSOptions(self.hostname, ctx)
            return ctx
else:
    SNIFactory = None


_APP_EXITING = [False]

def set_app_exiting(value=True):
    try:
        _APP_EXITING[0] = bool(value)
    except Exception:
        pass

def is_app_exiting():
    try:
        return bool(_APP_EXITING[0])
    except Exception:
        return False


def _remove(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def direct_picon(url, size, request_id, current_request_id, apply_path, prefix='xst_live_picon_'):
    """Shared Live Picon lifecycle with persistent, storage-aware cache.

    All Xtream/Stalker live picons that use this helper are stored under the
    selected TiviMateE2 cache root in ``picons``.  This makes them participate
    in the same HDD/USB retention and Internal Flash LRU/free-space protection
    as posters/backdrops.  Downloads still use one temporary file and never
    block the GUI while cleanup runs.
    """
    try:
        url = str(url or '').strip().replace('\\/', '/')
    except Exception:
        return None

    if not url or url.lower() == 'n/a' or is_app_exiting():
        return None
    if not url.startswith(('http://', 'https://')):
        return None

    try:
        width, height = int(size[0]), int(size[1])
    except Exception:
        return None

    # One stable file per URL + requested size. Query-string token changes are
    # ignored so provider CDN refresh tokens do not create duplicate picons.
    try:
        clean_url = url.split('?', 1)[0]
        key = ('%s|%sx%s' % (clean_url, width, height)).encode('utf-8')
        digest = hashlib.md5(key).hexdigest()
        cache_root = get_cache_dir('picons')
        cached = os.path.join(cache_root, 'picon_' + digest + '.png')
    except Exception:
        cached = ''

    def _stale():
        try:
            return int(current_request_id()) != int(request_id)
        except Exception:
            return True

    # Fast path: reuse persistent cached picon and touch mtime for LRU.
    try:
        if cached and os.path.isfile(cached) and os.path.getsize(cached) > 128:
            try:
                os.utime(cached, None)
            except Exception:
                pass
            if not _stale():
                apply_path(cached)
            return None
    except Exception:
        pass

    try:
        from .cache_manager import get_cache_dir
        temp_root = get_cache_dir("tmp")
    except Exception:
        temp_root = "/media/hdd/.tivimatee2-cache/tmp" if os.path.ismount("/media/hdd") else "/var/tmp/tivimatee2-cache/tmp"
        try:
            if not os.path.isdir(temp_root):
                os.makedirs(temp_root)
        except Exception:
            pass

    fd = None
    temp = None
    try:
        fd, temp = tempfile.mkstemp(
            prefix=str(prefix or 'xst_live_picon_'),
            suffix='.png',
            dir=temp_root
        )
        try:
            os.close(fd)
        except Exception:
            pass
        fd = None

        parsed = urlparse(url)
        domain = parsed.hostname
        scheme = parsed.scheme

        try:
            dl_url = url.encode('utf-8')
        except Exception:
            dl_url = url

        def _cleanup_temp():
            _remove(temp)

        def _cleanup_images_async():
            def worker():
                try:
                    cleanup_cache()
                except Exception:
                    pass
            try:
                t = threading.Thread(target=worker, name='TiviMatePiconCleanup')
                t.daemon = True
                t.start()
            except Exception:
                pass

        def _resize_and_store():
            if is_app_exiting():
                _cleanup_temp()
                return
            image = None
            bg = None
            try:
                image = Image.open(temp)
                if image.mode != 'RGBA':
                    image = image.convert('RGBA')
                if image.size[0] == 0 or image.size[1] == 0:
                    raise ValueError('Image has zero dimension')

                ratio = min(width / float(image.size[0]), height / float(image.size[1]))
                new_size = (
                    max(1, int(image.size[0] * ratio)),
                    max(1, int(image.size[1] * ratio))
                )
                try:
                    image = image.resize(new_size, Image.Resampling.LANCZOS)
                except Exception:
                    try:
                        image = image.resize(new_size, Image.LANCZOS)
                    except Exception:
                        image = image.resize(new_size, Image.ANTIALIAS)

                bg = Image.new('RGBA', (width, height), (255, 255, 255, 0))
                left = (width - image.size[0]) // 2
                top = (height - image.size[1]) // 2
                bg.paste(image, (left, top), mask=image)

                target = cached or temp
                bg.save(target, 'PNG')
                try:
                    os.utime(target, None)
                except Exception:
                    pass
                if not _stale():
                    apply_path(target)
                if cached:
                    _cleanup_images_async()
            except Exception:
                pass
            finally:
                try:
                    if image is not None:
                        image.close()
                except Exception:
                    pass
                try:
                    if bg is not None:
                        bg.close()
                except Exception:
                    pass
                _cleanup_temp()

        def _ok(_data=None):
            # Even if navigation moved on, keeping the just-fetched picon in the
            # shared cache is useful; only the UI apply step is stale-guarded.
            _resize_and_store()

        def _err(_failure=None):
            _cleanup_temp()

        if scheme == 'https' and _SSLVERIFY and SNIFactory is not None:
            factory = SNIFactory(domain)
            d = downloadPage(dl_url, temp, factory, timeout=2)
        else:
            d = downloadPage(dl_url, temp, timeout=2)

        d.addCallback(_ok)
        d.addErrback(_err)
        return d

    except Exception:
        try:
            if fd:
                os.close(fd)
        except Exception:
            pass
        _remove(temp)
        return None

