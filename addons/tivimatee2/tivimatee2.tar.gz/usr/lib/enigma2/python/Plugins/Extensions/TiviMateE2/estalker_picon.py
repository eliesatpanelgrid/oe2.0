# -*- coding: utf-8 -*-
import os
import tempfile
import hashlib
import threading
import time
import json

from PIL import Image
from twisted.web.client import downloadPage
from .cache_manager import get_cache_dir, cleanup_cache

from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

try:
    from twisted.internet import ssl
    from twisted.internet._sslverify import ClientTLSOptions
    _SSLVERIFY = True
except Exception:
    ssl = None
    ClientTLSOptions = None
    _SSLVERIFY = False


if _SSLVERIFY:
    class SNIFactory(ssl.ClientContextFactory):
        def __init__(self, hostname=None):
            self.hostname = hostname
        def getContext(self):
            ctx = self._contextFactory(self.method)
            if self.hostname:
                ClientTLSOptions(self.hostname, ctx)
            return ctx
else:
    SNIFactory = None

_APP_EXITING = [False]


def _diag_url(value):
    try:
        raw = str(value or "").strip().replace("\\/", "/")
        if not raw:
            return "empty"
        clean = raw.split("?", 1)[0]
        parsed = urlparse(clean)
        host = parsed.hostname or "-"
        tail = "/".join([x for x in parsed.path.split("/") if x][-2:])
        return "len=%d scheme=%s host=%s tail=%s" % (len(raw), parsed.scheme or "-", host, tail[-120:] or "-")
    except Exception:
        return "unparsed"

def _diag(stage, url="", **values):
    return None

def set_app_exiting(value=True):
    try:
        _APP_EXITING[0] = bool(value)
    except Exception:
        pass

def is_app_exiting():
    try:
        return bool(_APP_EXITING[0])
    except Exception:
        return False


def _remove(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def direct_picon(url, size, request_id, current_request_id, apply_path, prefix='xst_live_picon_'):
    """Shared Live Picon lifecycle with persistent, storage-aware cache.

    All Xtream/Stalker live picons that use this helper are stored under the
    selected TiviMateE2 cache root in ``picons``.  This makes them participate
    in the same HDD/USB retention and Internal Flash LRU/free-space protection
    as posters/backdrops.  Downloads still use one temporary file and never
    block the GUI while cleanup runs.
    """
    try:
        url = str(url or '').strip().replace('\\/', '/')
    except Exception:
        return None

    if not url or url.lower() == 'n/a' or is_app_exiting():
        _diag('reject_empty_or_exit', url)
        return None
    if not url.startswith(('http://', 'https://')):
        _diag('reject_non_http', url)
        return None

    try:
        width, height = int(size[0]), int(size[1])
    except Exception:
        return None

    # One stable file per URL + requested size. Query-string token changes are
    # ignored so provider CDN refresh tokens do not create duplicate picons.
    try:
        clean_url = url.split('?', 1)[0]
        key = ('openatv-canonical-v1|%s|%sx%s' % (clean_url, width, height)).encode('utf-8')
        digest = hashlib.md5(key).hexdigest()
        cache_root = get_cache_dir('picons')
        cached = os.path.join(cache_root, 'picon_' + digest + '.png')
    except Exception:
        cached = ''

    def _stale():
        try:
            return int(current_request_id()) != int(request_id)
        except Exception:
            return True

    # Fast path: reuse persistent cached picon and touch mtime for LRU.
    try:
        if cached and os.path.isfile(cached) and os.path.getsize(cached) > 128:
            try:
                os.utime(cached, None)
            except Exception:
                pass
            _diag('cache_hit', url, path=os.path.basename(cached), bytes=os.path.getsize(cached))
            if not _stale():
                apply_path(cached)
            return None
    except Exception:
        pass

    try:
        from .cache_manager import get_cache_dir
        temp_root = get_cache_dir("tmp")
    except Exception:
        temp_root = "/media/hdd/.tivimatee2-cache/tmp" if os.path.ismount("/media/hdd") else "/var/tmp/tivimatee2-cache/tmp"
        try:
            if not os.path.isdir(temp_root):
                os.makedirs(temp_root)
        except Exception:
            pass

    fd = None
    temp = None
    try:
        fd, temp = tempfile.mkstemp(
            prefix=str(prefix or 'xst_live_picon_'),
            suffix='.png',
            dir=temp_root
        )
        try:
            os.close(fd)
        except Exception:
            pass
        fd = None

        parsed = urlparse(url)
        domain = parsed.hostname
        scheme = parsed.scheme

        try:
            dl_url = url.encode('utf-8')
        except Exception:
            dl_url = url

        def _cleanup_temp():
            _remove(temp)

        def _cleanup_images_async():
            def worker():
                try:
                    cleanup_cache()
                except Exception:
                    pass
            try:
                t = threading.Thread(target=worker, name='TiviMatePiconCleanup')
                t.daemon = True
                t.start()
            except Exception:
                pass

        def _resize_and_store():
            if is_app_exiting():
                _cleanup_temp()
                return
            image = None
            bg = None
            try:
                image = Image.open(temp)
                # Force the provider payload to be fully decoded before Enigma2
                # sees it. Some providers return WEBP/JPEG/paletted PNG data behind
                # a .png URL; Pure tolerates more of these directly than OpenATV.
                try:
                    image.seek(0)
                except Exception:
                    pass
                image.load()
                if image.mode != 'RGBA':
                    image = image.convert('RGBA')
                if image.size[0] == 0 or image.size[1] == 0:
                    raise ValueError('Image has zero dimension')

                ratio = min(width / float(image.size[0]), height / float(image.size[1]))
                new_size = (
                    max(1, int(image.size[0] * ratio)),
                    max(1, int(image.size[1] * ratio))
                )
                try:
                    image = image.resize(new_size, Image.Resampling.LANCZOS)
                except Exception:
                    try:
                        image = image.resize(new_size, Image.LANCZOS)
                    except Exception:
                        image = image.resize(new_size, Image.ANTIALIAS)

                bg = Image.new('RGBA', (width, height), (255, 255, 255, 0))
                left = (width - image.size[0]) // 2
                top = (height - image.size[1]) // 2
                bg.paste(image, (left, top), mask=image)

                target = cached or temp
                if cached:
                    # Write a fresh canonical RGBA PNG beside the cache file and
                    # atomically replace it. This prevents OpenATV's pixmap loader
                    # from ever seeing a partially-written image.
                    stage = cached + '.new.%s' % int(request_id)
                    try:
                        _remove(stage)
                        bg.save(stage, 'PNG', optimize=False, compress_level=6)
                        os.replace(stage, cached)
                    finally:
                        _remove(stage)
                else:
                    bg.save(target, 'PNG', optimize=False, compress_level=6)
                try:
                    os.utime(target, None)
                except Exception:
                    pass
                _diag('decode_store_ok', url, path=os.path.basename(target), bytes=os.path.getsize(target) if os.path.exists(target) else 0, mode='RGBA')
                if not _stale():
                    apply_path(target)
                if cached:
                    _cleanup_images_async()
            except Exception as exc:
                _diag('decode_store_error', url, error=repr(exc))
            finally:
                try:
                    if image is not None:
                        image.close()
                except Exception:
                    pass
                try:
                    if bg is not None:
                        bg.close()
                except Exception:
                    pass
                _cleanup_temp()

        def _ok(_data=None):
            try:
                _diag('download_ok', url, bytes=os.path.getsize(temp) if os.path.exists(temp) else 0)
            except Exception:
                _diag('download_ok', url)
            # Even if navigation moved on, keeping the just-fetched picon in the
            # shared cache is useful; only the UI apply step is stale-guarded.
            _resize_and_store()

        def _err(_failure=None):
            try:
                msg = _failure.getErrorMessage() if _failure is not None and hasattr(_failure, 'getErrorMessage') else repr(_failure)
            except Exception:
                msg = 'unknown'
            _diag('download_error', url, error=msg)
            _cleanup_temp()

        _diag('download_start', url, temp=os.path.basename(temp), size='%sx%s' % (width, height), method='urllib-thread')

        # OpenATV can leave Twisted downloadPage() pending indefinitely for
        # some image CDNs (notably imgur), even though the same provider picon
        # works on Pure.  Fetch picons in a short-timeout worker instead so the
        # GUI thread never waits on DNS/TLS.  The existing decode/store/apply
        # pipeline is kept unchanged and is marshalled back to the reactor.
        def _urllib_worker():
            try:
                req = Request(
                    url,
                    headers={
                        'User-Agent': 'Mozilla/5.0 (TiviMateE2; Enigma2)',
                        'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
                        'Connection': 'close',
                    }
                )
                total = 0
                max_bytes = 8 * 1024 * 1024
                with urlopen(req, timeout=4) as response, open(temp, 'wb') as out:
                    while True:
                        chunk = response.read(65536)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > max_bytes:
                            raise ValueError('Picon payload exceeds 8MB')
                        out.write(chunk)
                if total <= 0:
                    raise ValueError('Empty picon payload')
                try:
                    from twisted.internet import reactor
                    reactor.callFromThread(_ok, None)
                except Exception:
                    _ok(None)
            except Exception as exc:
                try:
                    _diag('urllib_error', url, error=repr(exc))
                except Exception:
                    pass

                # Fallback to the original Twisted path only after urllib has
                # failed quickly.  This preserves compatibility with providers
                # that are happier with Enigma2/Twisted TLS handling.
                def _twisted_fallback():
                    try:
                        _cleanup_temp()
                        open(temp, 'wb').close()
                        _diag('fallback_start', url, method='twisted', timeout='3')
                        if scheme == 'https' and _SSLVERIFY and SNIFactory is not None:
                            factory = SNIFactory(domain)
                            d2 = downloadPage(dl_url, temp, factory, timeout=3)
                        else:
                            d2 = downloadPage(dl_url, temp, timeout=3)
                        d2.addCallback(_ok)
                        d2.addErrback(_err)
                    except Exception as fallback_exc:
                        _diag('fallback_error', url, error=repr(fallback_exc))
                        _cleanup_temp()
                try:
                    from twisted.internet import reactor
                    reactor.callFromThread(_twisted_fallback)
                except Exception:
                    _twisted_fallback()

        try:
            t = threading.Thread(target=_urllib_worker, name='TiviMatePiconFetch')
            t.daemon = True
            t.start()
            return t
        except Exception as exc:
            _diag('worker_start_error', url, error=repr(exc))
            _cleanup_temp()
            return None

    except Exception:
        try:
            if fd:
                os.close(fd)
        except Exception:
            pass
        _remove(temp)
        return None
