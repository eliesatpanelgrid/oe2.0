# -*- coding: utf-8 -*-
"""Privacy-safe mapping of playlist replies to local server status.

This module receives only an already-fetched reply.  It never stores, logs, or
renders credentials, endpoints, device IDs, or subscriber information.
"""


def _integer_or_none(value):
    try:
        text = str(value).strip()
        if not text:
            return None
        return int(text)
    except Exception:
        return None


def _xtream_usage(reply):
    """Return provider-reported active/max connections when available."""
    if not isinstance(reply, dict):
        return None, None
    info = reply.get("user_info")
    if not isinstance(info, dict):
        return None, None
    active = _integer_or_none(info.get("active_cons"))
    maximum = _integer_or_none(info.get("max_connections"))
    return active, maximum


def _reply_is_reachable(source_type, reply):
    if isinstance(reply, dict) and "ok" in reply:
        return bool(reply.get("ok"))
    if source_type == "xtream" and isinstance(reply, dict):
        return bool(reply.get("user_info") or reply.get("server_info") or reply.get("available_channels") is not None)
    return bool(reply)


def evaluate_reply(source_type, reply):
    """Map a successful provider reply to online/busy/offline.

    `busy` is returned only for an Xtream response that explicitly reports an
    `active_cons` value greater than zero.  Non-Xtream sources have no standard
    active-user count in this plugin, so they remain online/offline only.
    """
    reachable = _reply_is_reachable(source_type, reply)
    active = None
    maximum = None
    if source_type == "xtream":
        active, maximum = _xtream_usage(reply)

    if not reachable:
        state = "offline"
    elif active is not None and active > 0:
        state = "busy"
    else:
        state = "online"

    return {
        "state": state,
        "active_connections": active,
        "max_connections": maximum,
        "usage_reported": active is not None,
    }
