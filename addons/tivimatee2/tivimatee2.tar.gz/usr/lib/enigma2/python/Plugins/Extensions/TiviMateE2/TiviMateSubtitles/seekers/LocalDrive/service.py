# -*- coding: utf-8 -*-
import os
import re
import shutil

LANGUAGE_MAP = {
    "sq": ("Albanian", "flags/sq.gif"), "ar": ("Arabic", "flags/ar.gif"),
    "hy": ("Armenian", "flags/hy.gif"), "be": ("Belarusian", "flags/be.gif"),
    "bs": ("Bosnian", "flags/bs.gif"), "bg": ("Bulgarian", "flags/bg.gif"),
    "ca": ("Catalan", "flags/ca.gif"), "zh": ("Chinese", "flags/zh.gif"),
    "zh-cn": ("Chinese (Simplified)", "flags/zh-cn.gif"), "zh-tw": ("Chinese (Traditional)", "flags/zh-tw.gif"),
    "hr": ("Croatian", "flags/hr.gif"), "cs": ("Czech", "flags/cs.gif"),
    "da": ("Danish", "flags/da.gif"), "nl": ("Dutch", "flags/nl.gif"),
    "en": ("English", "flags/en.gif"), "et": ("Estonian", "flags/et.gif"),
    "fa": ("Persian", "flags/fa.gif"), "fi": ("Finnish", "flags/fi.gif"),
    "fr": ("French", "flags/fr.gif"), "de": ("German", "flags/de.gif"),
    "el": ("Greek", "flags/el.gif"), "he": ("Hebrew", "flags/he.gif"),
    "hi": ("Hindi", "flags/hi.gif"), "hu": ("Hungarian", "flags/hu.gif"),
    "is": ("Icelandic", "flags/is.gif"), "id": ("Indonesian", "flags/id.gif"),
    "it": ("Italian", "flags/it.gif"), "ja": ("Japanese", "flags/ja.gif"),
    "ko": ("Korean", "flags/ko.gif"), "lv": ("Latvian", "flags/lv.gif"),
    "lt": ("Lithuanian", "flags/lt.gif"), "mk": ("Macedonian", "flags/mk.gif"),
    "ms": ("Malay", "flags/ms.gif"), "no": ("Norwegian", "flags/no.gif"),
    "pl": ("Polish", "flags/pl.gif"), "pt": ("Portuguese", "flags/pt.gif"),
    "pt-br": ("Portuguese (Brazil)", "flags/pt-br.gif"), "pb": ("Portuguese (Brazil)", "flags/pt-br.gif"),
    "ro": ("Romanian", "flags/ro.gif"), "ru": ("Russian", "flags/ru.gif"),
    "sr": ("Serbian", "flags/sr.gif"), "sk": ("Slovak", "flags/sk.gif"),
    "sl": ("Slovenian", "flags/sl.gif"), "es": ("Spanish", "flags/es.gif"),
    "es-la": ("Spanish (Latin America)", "flags/es-la.gif"), "es-es": ("Spanish (Spain)", "flags/es-es.gif"),
    "sv": ("Swedish", "flags/sv.gif"), "th": ("Thai", "flags/th.gif"),
    "tr": ("Turkish", "flags/tr.gif"), "uk": ("Ukrainian", "flags/uk.gif"),
    "vi": ("Vietnamese", "flags/vi.gif"), "ur": ("Urdu", "flags/ur.gif"),
    "ta": ("Tamil", "flags/ta.gif"), "te": ("Telugu", "flags/te.gif"),
    "ml": ("Malayalam", "flags/ml.gif"), "kn": ("Kannada", "flags/kn.gif"),
    "mr": ("Marathi", "flags/mr.gif"), "bn": ("Bengali", "flags/bn.gif"),
    "pa": ("Punjabi", "flags/pa.gif"),
}
SUPPORTED_EXTENSIONS = (".srt", ".ass", ".ssa", ".sub")


def _normalize(value):
    value = os.path.basename(value or "")
    value = re.sub(r"\.(srt|ass|ssa|sub)$", "", value, flags=re.IGNORECASE)
    value = re.sub(r"[^a-z0-9]+", " ", value.lower())
    return " ".join(value.split())


def _language_from_filename(filename):
    base = re.sub(r"\.(srt|ass|ssa|sub)$", "", filename, flags=re.IGNORECASE)
    match = re.search(r"(?:^|[._\- ])([a-zA-Z]{2,3}(?:-[a-zA-Z]{2})?)$", base)
    code = match.group(1).lower() if match else ""
    info = LANGUAGE_MAP.get(code)
    if info:
        return code, info[0], info[1]
    return "", "Unknown", "flags/unknown.gif"


def _selected_language_codes(lang1, lang2, lang3):
    selected = set()
    names = [x for x in (lang1, lang2, lang3) if x]
    for code, data in LANGUAGE_MAP.items():
        if code == "pb":
            continue
        if data[0] in names or code in names:
            selected.add(code)
    return selected


def _release_markers(value):
    text = _normalize(value).replace(" ", "")
    markers = set()
    groups = (
        (("2160p",), "2160p"), (("1080p",), "1080p"), (("720p",), "720p"),
        (("webdl", "web-dl"), "webdl"), (("webrip",), "webrip"),
        (("bluray", "bdrip", "brrip"), "bluray"), (("hdtv",), "hdtv"),
        (("x265", "h265", "hevc"), "hevc"), (("x264", "h264", "avc"), "h264"),
        (("hdr10", "hdr"), "hdr"), (("dv", "dolbyvision"), "dv"),
        (("netflix", "nf"), "nf"), (("amazon", "amzn"), "amzn"),
    )
    for needles, marker in groups:
        if any(n.replace("-", "") in text for n in needles):
            markers.add(marker)
    return markers


def _is_release_match(filename, file_path, title, year, season, episode, tvshow):
    normalized_file = _normalize(filename)
    title_tokens = [t for t in _normalize(tvshow or title).split() if len(t) > 1]
    words = set(normalized_file.split())
    if title_tokens and not all(t in words for t in title_tokens):
        return False

    if tvshow:
        try:
            compact = normalized_file.replace(" ", "")
            if ("s%02de%02d" % (int(season), int(episode))) not in compact:
                return False
        except Exception:
            return False
    elif year:
        years = re.findall(r"(?:19|20)\d{2}", filename or "")
        if years and str(year) not in years:
            return False

    video_markers = _release_markers(file_path)
    sub_markers = _release_markers(filename)
    comparable = video_markers.intersection({"2160p", "1080p", "720p", "webdl", "webrip", "bluray", "hdtv", "hevc", "h264", "hdr", "dv", "nf", "amzn"})
    if video_markers and sub_markers:
        # If both sides advertise a marker in the same category, mismatches are not synchronized.
        categories = (
            ({"2160p", "1080p", "720p"}), ({"webdl", "webrip", "bluray", "hdtv"}),
            ({"hevc", "h264"}), ({"nf", "amzn"}), ({"hdr", "dv"}),
        )
        for category in categories:
            vm = video_markers & category
            sm = sub_markers & category
            if vm and sm and not (vm & sm):
                return False
    return bool(title_tokens)


def search_subtitles(file_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    global settings_provider
    download_path = settings_provider.getSetting("LocalSearchPath")
    search_paths = [download_path, "/tmp/"]
    selected_codes = _selected_language_codes(lang1, lang2, lang3)
    subtitles_list = []
    seen = set()

    print("[LocalDriveSeeker][info] search title=%s filepath=%s langs=%s year=%s" % (title, file_path, [lang1, lang2, lang3], year))
    target_title = tvshow or title
    target_tokens = [t for t in _normalize(target_title).split() if len(t) > 1]

    for path in search_paths:
        if not path or not os.path.isdir(path):
            continue
        for root, _, files in os.walk(path):
            for filename in files:
                ext = os.path.splitext(filename)[1].lower()
                if ext not in SUPPORTED_EXTENSIONS:
                    continue
                full_path = os.path.join(root, filename)
                try:
                    real_path = os.path.realpath(full_path)
                except Exception:
                    real_path = full_path
                # A copied /tmp subtitle with the same normalized name should not be shown twice.
                dedupe_key = (_normalize(filename), os.path.getsize(full_path) if os.path.exists(full_path) else -1)
                if dedupe_key in seen:
                    continue

                normalized = _normalize(filename)
                words = set(normalized.split())
                if target_tokens and not all(t in words for t in target_tokens):
                    continue

                years = re.findall(r"(?:19|20)\d{2}", filename)
                if year and years and str(year) not in years:
                    continue

                if tvshow:
                    try:
                        marker = "s%02de%02d" % (int(season), int(episode))
                        if marker not in normalized.replace(" ", ""):
                            continue
                    except Exception:
                        continue

                lang_code, language_name, language_flag = _language_from_filename(filename)
                if selected_codes and lang_code and lang_code not in selected_codes:
                    # Accept pt-br when Portuguese is selected and vice versa.
                    if not (lang_code.startswith("pt") and any(x.startswith("pt") for x in selected_codes)) and not (lang_code.startswith("es") and any(x.startswith("es") for x in selected_codes)) and not (lang_code.startswith("zh") and any(x.startswith("zh") for x in selected_codes)):
                        continue

                synced = _is_release_match(filename, file_path, title, year, season, episode, tvshow)
                subtitles_list.append({
                    "filename": filename,
                    "path": full_path,
                    "language_name": language_name,
                    "language_flag": language_flag,
                    "sync": synced,
                })
                seen.add(dedupe_key)

    subtitles_list.sort(key=lambda item: bool(item.get("sync", False)), reverse=True)
    print("[LocalDriveSeeker][info] search finished, found %d subtitles" % len(subtitles_list))
    return subtitles_list, "", ""


def remove_language_code(filename):
    root, ext = os.path.splitext(filename)
    root = re.sub(r"([._-][a-zA-Z]{2,3}(?:-[a-zA-Z]{2})?)+$", "", root)
    return root + ext


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    if pos < 0 or pos >= len(subtitles_list):
        return False, "Unknown", None
    subtitle_info = subtitles_list[pos]
    subtitle_path = subtitle_info.get("path")
    subtitle_filename = subtitle_info.get("filename")
    language = subtitle_info.get("language_name", "Unknown")
    if not subtitle_path or not os.path.exists(subtitle_path):
        return False, language, None
    os.makedirs(tmp_sub_dir, exist_ok=True)
    copied_path = os.path.join(tmp_sub_dir, remove_language_code(subtitle_filename))
    try:
        if os.path.realpath(subtitle_path) != os.path.realpath(copied_path):
            shutil.copy(subtitle_path, copied_path)
    except Exception as e:
        print("[LocalDriveSeeker][error] Error copying subtitle: %s" % e)
        return False, language, None
    return False, language, copied_path
