from __future__ import absolute_import
from .compat import atomic_replace, ensure_dir, open_text
import os, json, time, shutil, threading

BASE = "/etc/enigma2/tivimatee2"
SETTINGS_FILE = os.path.join(BASE, "cache_settings.json")
# Cache policy:
# - HDD/USB/MMC may be Unlimited (retention_days = 0).
# - No automatic deletion is ever triggered by cache size.
# - /tmp remains temporary and is naturally cleared by the receiver/system.
DEFAULTS = {"location": "auto", "max_mb": 0, "retention_days": 0}
MIN_RETENTION_DAYS = 0
MAX_RETENTION_DAYS = 3650

# Disk/mount probing involves a real write/delete test.  Reusing the selected
# root for a short interval removes that work from every poster/backdrop request
# while still rechecking removable media regularly.
CACHE_ROOT_TTL = 60
_CACHE_ROOT = ""
_CACHE_ROOT_LOCATION = ""
_CACHE_ROOT_AT = 0.0
_CACHE_ROOT_LOCK = threading.RLock()


def _load():
    try:
        with open_text(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f) or {}
    except Exception:
        data = {}
    out = dict(DEFAULTS)
    out.update(data)
    # max_mb is retained only for backward compatibility with old settings.
    # It is deliberately ignored by cleanup_cache().
    out["max_mb"] = 0
    try:
        out["retention_days"] = max(MIN_RETENTION_DAYS, min(int(out.get("retention_days", DEFAULTS["retention_days"])), MAX_RETENTION_DAYS))
    except Exception:
        out["retention_days"] = DEFAULTS["retention_days"]
    return out


def _invalidate_cache_root():
    global _CACHE_ROOT, _CACHE_ROOT_LOCATION, _CACHE_ROOT_AT
    with _CACHE_ROOT_LOCK:
        _CACHE_ROOT = ""
        _CACHE_ROOT_LOCATION = ""
        _CACHE_ROOT_AT = 0.0


def save_settings(location, max_mb=0, retention_days=0):
    # max_mb is accepted for compatibility, but size never causes deletion.
    try:
        safe_retention = max(MIN_RETENTION_DAYS, min(int(retention_days), MAX_RETENTION_DAYS))
    except Exception:
        safe_retention = DEFAULTS["retention_days"]
    data = {
        "location": str(location or "auto"),
        "max_mb": 0,
        "retention_days": safe_retention,
    }
    try:
        ensure_dir(BASE)
        tmp = SETTINGS_FILE + ".tmp"
        with open_text(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        atomic_replace(tmp, SETTINGS_FILE)
        _invalidate_cache_root()
        return True
    except Exception:
        return False


def get_settings():
    return _load()


def _usable_mount(path):
    try:
        if not os.path.isdir(path):
            return False
        test = os.path.join(path, ".tivimatee2-write-test")
        with open_text(test, "w") as f:
            f.write("1")
        os.remove(test)
        return True
    except Exception:
        return False


def get_cache_root():
    global _CACHE_ROOT, _CACHE_ROOT_LOCATION, _CACHE_ROOT_AT
    cfg = _load()
    location = str(cfg.get("location", "auto") or "auto")
    now = time.time()
    with _CACHE_ROOT_LOCK:
        if (_CACHE_ROOT and _CACHE_ROOT_LOCATION == location and
                now - _CACHE_ROOT_AT < CACHE_ROOT_TTL and
                os.path.isdir(_CACHE_ROOT)):
            return _CACHE_ROOT

        candidates = {
            "hdd": ["/media/hdd"],
            "usb": ["/media/usb", "/media/usb1", "/media/usb2"],
            "mmc": ["/media/mmc"],
            "tmp": ["/tmp"],
        }
        if location == "auto":
            order = ["hdd", "usb", "mmc", "tmp"]
        elif location in ("hdd", "usb", "mmc"):
            # A user-selected persistent device is strict: never redirect new
            # artwork to another mount or /tmp behind the user's back.  This
            # prevents a temporary mount delay from splitting the cache and
            # making the persistent cache appear to shrink or disappear.
            order = [location]
        else:
            order = [location]
        seen = set()
        for key in order:
            if key in seen:
                continue
            seen.add(key)
            for mount in candidates.get(key, []):
                if _usable_mount(mount):
                    root = os.path.join(mount, "tivimatee2-cache") if mount != "/tmp" else "/tmp/tivimatee2"
                    try:
                        ensure_dir(root)
                        _CACHE_ROOT = root
                        _CACHE_ROOT_LOCATION = location
                        _CACHE_ROOT_AT = now
                        return root
                    except Exception:
                        pass
        # Only Auto/tmp may fall back to temporary storage.  For an explicit
        # persistent location keep the configured path stable, even while the
        # mount is temporarily unavailable.  Callers will simply fail to write
        # until the device is mounted; existing HDD/USB/MMC files are untouched.
        explicit_roots = {
            "hdd": "/media/hdd/tivimatee2-cache",
            "usb": "/media/usb/tivimatee2-cache",
            "mmc": "/media/mmc/tivimatee2-cache",
        }
        if location in explicit_roots:
            _CACHE_ROOT = explicit_roots[location]
        else:
            _CACHE_ROOT = "/tmp/tivimatee2"
        _CACHE_ROOT_LOCATION = location
        _CACHE_ROOT_AT = now
        return _CACHE_ROOT


def get_cache_dir(kind="misc"):
    path = os.path.join(get_cache_root(), str(kind or "misc"))
    try:
        ensure_dir(path)
    except Exception:
        pass
    return path


def cache_status():
    root = get_cache_root()
    total = 0
    files = 0
    try:
        for base, _dirs, names in os.walk(root):
            for name in names:
                p = os.path.join(base, name)
                try:
                    total += os.path.getsize(p)
                    files += 1
                except Exception:
                    pass
    except Exception:
        pass
    return root, total, files


def clear_cache():
    root = get_cache_root()
    try:
        if root.startswith(("/media/", "/tmp/tivimatee2")) and os.path.exists(root):
            shutil.rmtree(root)
        ensure_dir(root)
        _invalidate_cache_root()
        return True
    except Exception:
        return False


def cleanup_cache():
    """Delete files only by the selected age policy.

    retention_days == 0 means Unlimited: no automatic deletion.
    Cache size is informational only and never triggers a purge.
    """
    cfg = _load()
    root = get_cache_root()
    retention_days = int(cfg.get("retention_days", DEFAULTS["retention_days"]) or 0)
    if retention_days <= 0:
        # Unlimited on persistent storage. /tmp is still managed by the OS.
        _root, total, _files = cache_status()
        return total
    retention = retention_days * 86400
    now = time.time()
    total = 0
    try:
        for base, _dirs, names in os.walk(root):
            for name in names:
                p = os.path.join(base, name)
                try:
                    st = os.stat(p)
                    if now - st.st_mtime > retention:
                        os.remove(p)
                    else:
                        total += st.st_size
                except Exception:
                    pass
    except Exception:
        pass
    return total
