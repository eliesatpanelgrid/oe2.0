from .storage import get_data_root, data_path, hdd_available
from .compat import atomic_replace, ensure_dir, open_text
import os, json, time, shutil, threading, hashlib
try:
    import sqlite3
except Exception:
    sqlite3 = None

BASE = get_data_root()
SETTINGS_FILE = data_path("cache_settings.json")
# Cache policy:
# - HDD/USB/MMC may be Unlimited (retention_days = 0).
# - No automatic deletion is ever triggered by cache size.
# - /tmp remains temporary and is naturally cleared by the receiver/system.
DEFAULTS = {"location": "auto", "max_mb": 0, "retention_days": 0, "flash_image_limit": 20, "flash_min_free_mb": 30}
MIN_RETENTION_DAYS = 0
MAX_RETENTION_DAYS = 3650

# Disk/mount probing involves a real write/delete test.  Reusing the selected
# root for a short interval removes that work from every poster/backdrop request
# while still rechecking removable media regularly.
CACHE_ROOT_TTL = 86400 * 365
AUTO_CACHE_ROOT_TTL = 10
_CACHE_ROOT = ""
_CACHE_ROOT_LOCATION = ""
_CACHE_ROOT_AT = 0.0
_CACHE_ROOT_LOCK = threading.RLock()

_SETTINGS_MEMORY = None


def _load():
    global _SETTINGS_MEMORY
    if _SETTINGS_MEMORY is not None:
        return dict(_SETTINGS_MEMORY)
    try:
        with open_text(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f) or {}
    except Exception:
        data = {}
    out = dict(DEFAULTS)
    out.update(data)
    # max_mb is retained only for backward compatibility with old settings.
    # It is deliberately ignored by cleanup_cache().
    out["max_mb"] = 0
    try:
        out["retention_days"] = max(MIN_RETENTION_DAYS, min(int(out.get("retention_days", DEFAULTS["retention_days"])), MAX_RETENTION_DAYS))
    except Exception:
        out["retention_days"] = DEFAULTS["retention_days"]
    try:
        out["flash_image_limit"] = max(0, min(int(out.get("flash_image_limit", DEFAULTS["flash_image_limit"])), 500))
    except Exception:
        out["flash_image_limit"] = DEFAULTS["flash_image_limit"]
    try:
        out["flash_min_free_mb"] = max(0, min(int(out.get("flash_min_free_mb", DEFAULTS["flash_min_free_mb"])), 1024))
    except Exception:
        out["flash_min_free_mb"] = DEFAULTS["flash_min_free_mb"]
    _SETTINGS_MEMORY = dict(out)
    return dict(out)


def _invalidate_cache_root():
    global _CACHE_ROOT, _CACHE_ROOT_LOCATION, _CACHE_ROOT_AT, _SETTINGS_MEMORY
    with _CACHE_ROOT_LOCK:
        _CACHE_ROOT = ""
        _CACHE_ROOT_LOCATION = ""
        _CACHE_ROOT_AT = 0.0
        _SETTINGS_MEMORY = None


def save_settings(location, max_mb=0, retention_days=0, flash_image_limit=None, flash_min_free_mb=None):
    # max_mb is accepted for compatibility, but size never causes deletion.
    current = _load()
    try:
        safe_retention = max(MIN_RETENTION_DAYS, min(int(retention_days), MAX_RETENTION_DAYS))
    except Exception:
        safe_retention = DEFAULTS["retention_days"]
    if flash_image_limit is None:
        flash_image_limit = current.get("flash_image_limit", DEFAULTS["flash_image_limit"])
    if flash_min_free_mb is None:
        flash_min_free_mb = current.get("flash_min_free_mb", DEFAULTS["flash_min_free_mb"])
    try:
        safe_flash_limit = max(0, min(int(flash_image_limit), 500))
    except Exception:
        safe_flash_limit = DEFAULTS["flash_image_limit"]
    try:
        safe_flash_free = max(0, min(int(flash_min_free_mb), 1024))
    except Exception:
        safe_flash_free = DEFAULTS["flash_min_free_mb"]
    data = {
        "location": str(location or "auto"),
        "max_mb": 0,
        "retention_days": safe_retention,
        "flash_image_limit": safe_flash_limit,
        "flash_min_free_mb": safe_flash_free,
    }
    try:
        ensure_dir(BASE)
        tmp = SETTINGS_FILE + ".tmp"
        payload = json.dumps(data, ensure_ascii=False, indent=2)
        if not isinstance(payload, str):
            payload = str(payload)
        with open_text(tmp, "w", encoding="utf-8") as f: f.write(payload)
        atomic_replace(tmp, SETTINGS_FILE)
        _invalidate_cache_root()
        return True
    except Exception:
        return False


def get_settings():
    return _load()


def _usable_mount(path):
    """Fast read-only mount check.

    Do not create/delete a test file during normal UI navigation.  Real writes
    are attempted only when a caller actually saves cache content.
    """
    try:
        if not os.path.isdir(path):
            return False
        real = os.path.realpath(path)
        mounted = os.path.ismount(path) or os.path.ismount(real)
        if path == "/tmp":
            mounted = True
        if not mounted:
            return False
        return os.access(path, os.W_OK | os.X_OK)
    except Exception:
        return False


def _selected_root(location):
    """Resolve the configured cache location without overriding explicit choices."""
    location = str(location or "auto").strip().lower()
    candidates = []
    if location == "hdd":
        # Explicit HDD preference with safe fallback: HDD -> USB -> internal.
        candidates = ["/media/hdd", "/media/usb", "/media/usb1", "/media/usb2", "/media/usb3", "/home/root"]
    elif location == "usb":
        # Explicit USB preference with safe fallback: USB -> HDD -> internal.
        candidates = ["/media/usb", "/media/usb1", "/media/usb2", "/media/usb3", "/media/hdd", "/home/root"]
    elif location in ("mmc", "sd", "sdcard"):
        candidates = ["/media/mmc", "/media/sdcard"]
    elif location == "internal":
        candidates = ["/var/tmp"]
    elif location == "tmp":
        candidates = ["/tmp"]
    else:
        # AUTO: real HDD first, then removable USB/MMC, then receiver flash.
        # Never fall through to /tmp: the final fallback is the same protected
        # INTERNAL root used by the explicit Internal setting.
        candidates = ["/media/hdd", "/media/usb", "/media/usb1", "/media/usb2", "/media/usb3", "/media/mmc", "/media/sdcard", "/var/tmp"]
    for mount in candidates:
        if mount == "/var/tmp":
            if os.path.isdir(mount) and os.access(mount, os.W_OK | os.X_OK):
                return os.path.join(mount, "tivimatee2-cache")
        elif _usable_mount(mount):
            return os.path.join(mount, ".tivimatee2-cache")
    return "/var/tmp/tivimatee2-cache"


def get_cache_root():
    """Return the configured persistent cache root, preferring HDD in Auto."""
    global _CACHE_ROOT, _CACHE_ROOT_LOCATION, _CACHE_ROOT_AT
    cfg = _load()
    location = str(cfg.get("location") or "auto").strip().lower()
    now = time.time()
    with _CACHE_ROOT_LOCK:
        # AUTO may re-probe for newly mounted storage. Explicit selections
        # (especially INTERNAL) must never be silently redirected to HDD.
        active_hdd = os.path.realpath(_CACHE_ROOT or "").startswith("/media/hdd/")
        ttl = CACHE_ROOT_TTL if active_hdd else AUTO_CACHE_ROOT_TTL
        cached_ok = (_CACHE_ROOT and _CACHE_ROOT_LOCATION == location and
                     now - _CACHE_ROOT_AT < ttl and os.path.isdir(_CACHE_ROOT))
        if cached_ok:
            real_cached = os.path.realpath(_CACHE_ROOT)
            if location == "internal":
                internal = os.path.realpath("/var/tmp/tivimatee2-cache")
                cached_ok = (real_cached == internal or real_cached.startswith(internal + os.sep))
            elif location == "usb":
                cached_ok = real_cached.startswith("/media/usb")
            elif location == "hdd":
                cached_ok = real_cached.startswith("/media/hdd/")
        if cached_ok:
            return _CACHE_ROOT
        root = _selected_root(location)
        try:
            ensure_dir(root)
        except Exception:
            try:
                # Respect explicit INTERNAL even when HDD is mounted. AUTO/HDD
                # may still prefer HDD according to _selected_root().
                if location == "internal":
                    root = "/var/tmp/tivimatee2-cache"
                elif hdd_available() and location in ("auto", "hdd"):
                    root = os.path.join("/media/hdd", ".tivimatee2-cache")
                else:
                    root = "/var/tmp/tivimatee2-cache"
                ensure_dir(root)
            except Exception:
                pass
        # A mounted HDD is authoritative: remove the plugin's old internal
        # cache tree completely, including empty directories.
        try:
            if hdd_available() and os.path.realpath(root).startswith("/media/hdd/"):
                shutil.rmtree("/var/tmp/tivimatee2-cache", ignore_errors=True)
        except Exception:
            pass
        _CACHE_ROOT = root
        _CACHE_ROOT_LOCATION = location
        _CACHE_ROOT_AT = now
        return root




def is_internal_cache_active():
    """True when the cache is physically using receiver flash.

    This intentionally checks the resolved path, not only the saved setting,
    so AUTO receives the Internal Flash policy whenever no HDD/USB is mounted.
    """
    try:
        root = os.path.realpath(get_cache_root())
        internal = os.path.realpath("/var/tmp/tivimatee2-cache")
        return root == internal or root.startswith(internal + os.sep)
    except Exception:
        return False

def get_cache_dir(kind="misc"):
    path = os.path.join(get_cache_root(), str(kind or "misc"))
    try:
        ensure_dir(path)
    except Exception:
        pass
    return path


def get_logs_dir():
    """Logs follow the user-selected cache/storage root; never force /home/root."""
    return get_cache_dir("logs")

def cleanup_stale_temp_files():
    """No-op: TiviMateE2 no longer creates upgrade backup archives."""
    return

def cache_status():
    root = get_cache_root()
    total = 0
    files = 0
    try:
        for base, _dirs, names in os.walk(root):
            for name in names:
                p = os.path.join(base, name)
                try:
                    total += os.path.getsize(p)
                    files += 1
                except Exception:
                    pass
    except Exception:
        pass
    return root, total, files


def _artwork_dirs(root):
    """Image-cache folders only. Metadata and list/database caches are preserved.

    Includes channel picons so the same retention/LRU/free-space protection
    applies to every persistent image family on the selected cache storage.
    """
    return (
        os.path.join(root, "posters"),
        os.path.join(root, "backdrops"),
        os.path.join(root, "picons"),
        os.path.join(root, "logos"),
    )


def _remove_file(path):
    try:
        if path and os.path.isfile(path):
            os.remove(path)
            return True
    except Exception:
        pass
    return False


def _artwork_files(folder):
    rows = []
    try:
        for name in os.listdir(folder):
            path = os.path.join(folder, name)
            try:
                if not os.path.isfile(path):
                    continue
                st = os.stat(path)
                rows.append((float(st.st_mtime), int(st.st_size), path))
            except Exception:
                pass
    except Exception:
        pass
    rows.sort(key=lambda row: row[0])  # oldest / least recently used first
    return rows


def clear_cache():
    """Clear artwork only; never erase metadata, SQLite/list caches, Recent or TMDb data."""
    root = get_cache_root()
    try:
        for path in _artwork_dirs(root):
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path)
            except Exception:
                pass
        ensure_dir(root)
        _invalidate_cache_root()
        return True
    except Exception:
        return False



def clear_internal_artwork_on_exit():
    """Remove all TiviMateE2 artwork when leaving the app on INTERNAL storage.

    Only posters/backdrops/picons/logos are removed. Metadata, SQLite, Recent,
    TMDb data, packages, logs and other persistent caches are preserved.
    HDD/USB/MMC/TMP selections are intentionally left untouched.
    """
    try:
        cfg = _load()
        location = str(cfg.get("location") or "auto").strip().lower()
        if location not in ("internal", "auto") or not is_internal_cache_active():
            return False
        root = get_cache_root()
        for path in _artwork_dirs(root):
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path)
            except Exception:
                pass
        try:
            ensure_dir(root)
        except Exception:
            pass
        return True
    except Exception:
        return False

def cleanup_cache():
    """Apply image-only retention/protection policy.

    HDD/USB/MMC/TMP:
      - retention_days controls posters + backdrops + channel picons only.
      - 0 means Unlimited.

    Internal flash:
      - keep only the most recently used N posters, N backdrops and N picons
        (default 20 of each),
      - if free flash drops below the selected reserve (default 30 MB), remove the
        oldest artwork until the reserve is restored or no artwork remains.

    No metadata, SQLite, Recent, package, TMDb data or logs are touched here.
    """
    cfg = _load()
    root = get_cache_root()
    location = str(cfg.get("location") or "auto").strip().lower()
    retention_days = int(cfg.get("retention_days", DEFAULTS["retention_days"]) or 0)
    flash_limit = int(cfg.get("flash_image_limit", DEFAULTS["flash_image_limit"]) or 0)
    flash_min_free_mb = int(cfg.get("flash_min_free_mb", DEFAULTS["flash_min_free_mb"]) or 0)
    is_internal = is_internal_cache_active()
    now = time.time()

    # Age policy is image-only. It is mainly intended for HDD/USB; it remains
    # harmless if explicitly enabled on another non-internal storage target.
    if (not is_internal) and retention_days > 0:
        retention = retention_days * 86400
        for folder in _artwork_dirs(root):
            for mtime, _size, path in _artwork_files(folder):
                if now - mtime > retention:
                    _remove_file(path)

    if is_internal:
        # LRU count guard: cached_artwork() touches mtime whenever an image is
        # used, so sorting by mtime preserves the images the user saw most recently.
        if flash_limit > 0:
            for folder in _artwork_dirs(root):
                rows = _artwork_files(folder)
                excess = max(0, len(rows) - flash_limit)
                for _mtime, _size, path in rows[:excess]:
                    _remove_file(path)

        # Free-space reserve guard. Delete oldest artwork across all image families.
        if flash_min_free_mb > 0:
            reserve = int(flash_min_free_mb) * 1024 * 1024
            try:
                st = os.statvfs(root)
                free_bytes = int(st.f_bavail * st.f_frsize)
            except Exception:
                free_bytes = reserve
            if free_bytes < reserve:
                rows = []
                for folder in _artwork_dirs(root):
                    rows.extend(_artwork_files(folder))
                rows.sort(key=lambda row: row[0])
                for _mtime, size, path in rows:
                    if free_bytes >= reserve:
                        break
                    if _remove_file(path):
                        free_bytes += int(size or 0)

    # Return remaining artwork bytes only. This avoids walking unrelated data caches.
    total = 0
    for folder in _artwork_dirs(root):
        for _mtime, size, _path in _artwork_files(folder):
            total += int(size or 0)
    return total

def get_log_path(name):
    """Return a bounded plugin-log path under the user-selected storage root."""
    safe = os.path.basename(str(name or "tivimatee2.log"))
    return os.path.join(get_logs_dir(), safe)


def migrate_legacy_logs():
    """Move only TiviMateE2 legacy logs out of /tmp and /home/root."""
    dst = get_logs_dir()
    try:
        ensure_dir(dst)
    except Exception:
        return
    candidates = [
        "/tmp/tivimatee2_epg_sync.log",
        "/tmp/tivimatee2_epg_local.log",
        "/tmp/tivimatee2_stalker.log",
        "/tmp/tivimatee2_web.log",
        "/tmp/tivimatee2/tmdb.log",
        "/tmp/tivimatee2/poster.log",
        "/tmp/tivimatee2/logs/tmdb.log",
        "/tmp/tivimatee2/logs/poster.log",
    ]
    for src in candidates:
        try:
            if not os.path.isfile(src):
                continue
            target = os.path.join(dst, os.path.basename(src))
            if os.path.exists(target):
                # Append old content once, then remove legacy file.
                with open(src, "rb") as rf, open(target, "ab") as wf:
                    shutil.copyfileobj(rf, wf)
                os.remove(src)
            else:
                shutil.move(src, target)
        except Exception:
            pass


def migrate_legacy_tmp_cache():
    """Move persistent TiviMateE2 cache out of /tmp to the selected storage.

    True runtime scratch files (QR image, subtitle temp files, sockets) are not
    moved.  This runs only when the resolved cache root is persistent.
    """
    src_root = "/tmp/tivimatee2"
    try:
        dst_root = get_cache_root()
    except Exception:
        return
    if not dst_root or dst_root.startswith("/tmp/") or dst_root == src_root:
        return
    if not os.path.isdir(src_root):
        return
    try:
        ensure_dir(dst_root)
    except Exception:
        return
    # Known persistent cache folders.  Leave web_access_qr.png and any unknown
    # runtime scratch content in /tmp.
    persistent_names = (
        "posters", "backdrops", "logos", "picons", "epg",
        "tmdb_search", "tmdb_trending", "details_json",
        "vod", "series", "live", "metadata", "json", "info"
    )
    for name in persistent_names:
        src = os.path.join(src_root, name)
        dst = os.path.join(dst_root, name)
        if not os.path.exists(src):
            continue
        try:
            if os.path.isdir(src):
                ensure_dir(dst)
                for base, dirs, files in os.walk(src):
                    rel = os.path.relpath(base, src)
                    target_base = dst if rel == "." else os.path.join(dst, rel)
                    ensure_dir(target_base)
                    for fn in files:
                        sp = os.path.join(base, fn)
                        dp = os.path.join(target_base, fn)
                        try:
                            if not os.path.exists(dp):
                                shutil.move(sp, dp)
                            else:
                                os.remove(sp)
                        except Exception:
                            pass
                try:
                    shutil.rmtree(src)
                except Exception:
                    pass
            elif os.path.isfile(src):
                dp = os.path.join(dst_root, name)
                if not os.path.exists(dp):
                    shutil.move(src, dp)
                else:
                    os.remove(src)
        except Exception:
            pass
    # Remove empty legacy log/cache directories, but keep /tmp/tivimatee2 itself
    # if runtime scratch files are still present.
    for sub in ("logs",):
        try:
            path = os.path.join(src_root, sub)
            if os.path.isdir(path) and not os.listdir(path):
                os.rmdir(path)
        except Exception:
            pass
    try:
        if os.path.isdir(src_root) and not os.listdir(src_root):
            os.rmdir(src_root)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Persistent key/value cache for Stalker and other network catalogs.
# SQLite/WAL is preferred when python3-sqlite3 is available.  Images that do
# not ship sqlite3 transparently fall back to atomic JSON files on HDD/USB.
# ---------------------------------------------------------------------------
_SQLITE_LOCK = threading.RLock()
_SQLITE_CONN = None
_SQLITE_PATH = ""


def stable_cache_key(namespace, *parts):
    raw = "|".join([str(namespace or "")] + [str(x or "") for x in parts])
    try:
        return hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest()
    except Exception:
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _json_kv_dir():
    path = os.path.join(get_cache_dir("stalker"), "json_kv")
    try:
        ensure_dir(path)
    except Exception:
        pass
    return path


def _json_kv_path(cache_key):
    safe = str(cache_key or "")
    if not safe or any(c not in "0123456789abcdefABCDEF" for c in safe):
        safe = stable_cache_key("fallback", safe)
    return os.path.join(_json_kv_dir(), safe + ".json")


def _json_cache_get(cache_key, default=None):
    path = _json_kv_path(cache_key)
    try:
        with open_text(path, "r", encoding="utf-8") as f:
            row = json.load(f) or {}
        if float(row.get("expires") or 0) <= time.time():
            try: os.remove(path)
            except Exception: pass
            return default
        return row.get("value", default)
    except Exception:
        return default


def _json_cache_set(cache_key, namespace, value, ttl):
    path = _json_kv_path(cache_key)
    tmp = path + ".tmp"
    now = time.time()
    try:
        ttl = max(1, int(ttl or 1))
        row = {
            "namespace": str(namespace or "misc"),
            "created": now,
            "expires": now + ttl,
            "value": value,
        }
        payload = json.dumps(row, ensure_ascii=False, separators=(",", ":"))
        with open_text(tmp, "w", encoding="utf-8") as f:
            f.write(payload)
        atomic_replace(tmp, path)
        return True
    except Exception:
        try:
            if os.path.exists(tmp): os.remove(tmp)
        except Exception:
            pass
        return False


def _sqlite_connection():
    global _SQLITE_CONN, _SQLITE_PATH
    if sqlite3 is None:
        return None
    path = os.path.join(get_cache_dir("stalker"), "persistent_cache.sqlite3")
    with _SQLITE_LOCK:
        if _SQLITE_CONN is not None and _SQLITE_PATH == path:
            return _SQLITE_CONN
        try:
            if _SQLITE_CONN is not None:
                _SQLITE_CONN.close()
        except Exception:
            pass
        try:
            conn = sqlite3.connect(path, timeout=8.0, check_same_thread=False)
            _SQLITE_CONN = conn
            _SQLITE_PATH = path
            cur = conn.cursor()
            try: cur.execute("PRAGMA journal_mode=WAL")
            except Exception: pass
            try: cur.execute("PRAGMA synchronous=NORMAL")
            except Exception: pass
            try: cur.execute("PRAGMA busy_timeout=8000")
            except Exception: pass
            cur.execute("CREATE TABLE IF NOT EXISTS kv_cache (cache_key TEXT PRIMARY KEY, namespace TEXT NOT NULL, created REAL NOT NULL, expires REAL NOT NULL, payload TEXT NOT NULL)")
            cur.execute("CREATE INDEX IF NOT EXISTS kv_cache_expiry ON kv_cache(expires)")
            conn.commit()
            return conn
        except Exception:
            _SQLITE_CONN = None
            _SQLITE_PATH = ""
            return None


def persistent_cache_get(cache_key, default=None):
    now = time.time()
    if sqlite3 is not None:
        try:
            with _SQLITE_LOCK:
                conn = _sqlite_connection()
                if conn is not None:
                    cur = conn.cursor()
                    cur.execute("SELECT expires,payload FROM kv_cache WHERE cache_key=?", (str(cache_key),))
                    row = cur.fetchone()
                    if row:
                        if float(row[0] or 0) <= now:
                            try:
                                cur.execute("DELETE FROM kv_cache WHERE cache_key=?", (str(cache_key),))
                                conn.commit()
                            except Exception:
                                pass
                        else:
                            return json.loads(row[1])
        except Exception:
            pass
    return _json_cache_get(cache_key, default)



def persistent_cache_peek(cache_key, default=None, max_stale=86400):
    """Return (value, fresh) without deleting a recently expired row.

    Used by Stalker stale-while-revalidate so the UI can render cached data
    immediately while a background refresh updates the persistent copy.
    """
    now = time.time()
    try:
        max_stale = max(0, int(max_stale or 0))
    except Exception:
        max_stale = 0

    if sqlite3 is not None:
        try:
            with _SQLITE_LOCK:
                conn = _sqlite_connection()
                if conn is not None:
                    cur = conn.cursor()
                    cur.execute("SELECT expires,payload FROM kv_cache WHERE cache_key=?", (str(cache_key),))
                    row = cur.fetchone()
                    if row:
                        expires = float(row[0] or 0)
                        if expires > now or (max_stale and now - expires <= max_stale):
                            try:
                                return json.loads(row[1]), bool(expires > now)
                            except Exception:
                                pass
        except Exception:
            pass

    path = _json_kv_path(cache_key)
    try:
        with open_text(path, "r", encoding="utf-8") as f:
            row = json.load(f) or {}
        expires = float(row.get("expires") or 0)
        if expires > now or (max_stale and now - expires <= max_stale):
            return row.get("value", default), bool(expires > now)
    except Exception:
        pass
    return default, False

def persistent_cache_set(cache_key, namespace, value, ttl):
    now = time.time()
    try:
        ttl = max(1, int(ttl or 1))
    except Exception:
        ttl = 1
    if sqlite3 is not None:
        try:
            payload = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
            with _SQLITE_LOCK:
                conn = _sqlite_connection()
                if conn is not None:
                    conn.execute("INSERT OR REPLACE INTO kv_cache(cache_key,namespace,created,expires,payload) VALUES(?,?,?,?,?)",
                                 (str(cache_key), str(namespace or "misc"), now, now + ttl, payload))
                    conn.commit()
                    return True
        except Exception:
            pass
    return _json_cache_set(cache_key, namespace, value, ttl)


def persistent_cache_delete(cache_key):
    ok = False
    if sqlite3 is not None:
        try:
            with _SQLITE_LOCK:
                conn = _sqlite_connection()
                if conn is not None:
                    conn.execute("DELETE FROM kv_cache WHERE cache_key=?", (str(cache_key),))
                    conn.commit()
                    ok = True
        except Exception:
            pass
    try:
        path = _json_kv_path(cache_key)
        if os.path.exists(path):
            os.remove(path)
            ok = True
    except Exception:
        pass
    return ok


def persistent_cache_purge_expired(limit=500):
    now = time.time()
    try:
        max_rows = max(1, int(limit or 500))
    except Exception:
        max_rows = 500
    ok = False
    if sqlite3 is not None:
        try:
            with _SQLITE_LOCK:
                conn = _sqlite_connection()
                if conn is not None:
                    conn.execute("DELETE FROM kv_cache WHERE cache_key IN (SELECT cache_key FROM kv_cache WHERE expires<=? LIMIT ?)",
                                 (now, max_rows))
                    conn.commit()
                    ok = True
        except Exception:
            pass
    # Also clean fallback JSON rows, including rows left from a receiver that
    # previously had no sqlite module.
    try:
        folder = _json_kv_dir()
        count = 0
        for name in os.listdir(folder):
            if count >= max_rows:
                break
            if not name.endswith(".json"):
                continue
            path = os.path.join(folder, name)
            try:
                with open_text(path, "r", encoding="utf-8") as f:
                    row = json.load(f) or {}
                if float(row.get("expires") or 0) <= now:
                    os.remove(path)
                count += 1
            except Exception:
                try: os.remove(path)
                except Exception: pass
                count += 1
        ok = True
    except Exception:
        pass
    return ok

