from __future__ import absolute_import
from .compat import atomic_replace, ensure_dir, open_text
import os, json, time, shutil, threading

BASE = "/etc/enigma2/tivimatee2"
SETTINGS_FILE = os.path.join(BASE, "cache_settings.json")
# Receiver-friendly limits: artwork files stay on disk, never as an unlimited
# store.  A bounded cache avoids slow scans and storage growth on small boxes.
DEFAULTS = {"location": "auto", "max_mb": 150, "retention_days": 14}
MIN_CACHE_MB = 50
MAX_CACHE_MB = 150
MIN_RETENTION_DAYS = 7
MAX_RETENTION_DAYS = 30

# Disk/mount probing involves a real write/delete test.  Reusing the selected
# root for a short interval removes that work from every poster/backdrop request
# while still rechecking removable media regularly.
CACHE_ROOT_TTL = 60
_CACHE_ROOT = ""
_CACHE_ROOT_LOCATION = ""
_CACHE_ROOT_AT = 0.0
_CACHE_ROOT_LOCK = threading.RLock()


def _load():
    try:
        with open_text(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f) or {}
    except Exception:
        data = {}
    out = dict(DEFAULTS)
    out.update(data)
    try:
        out["max_mb"] = max(MIN_CACHE_MB, min(int(out.get("max_mb", DEFAULTS["max_mb"])), MAX_CACHE_MB))
    except Exception:
        out["max_mb"] = DEFAULTS["max_mb"]
    try:
        out["retention_days"] = max(MIN_RETENTION_DAYS, min(int(out.get("retention_days", DEFAULTS["retention_days"])), MAX_RETENTION_DAYS))
    except Exception:
        out["retention_days"] = DEFAULTS["retention_days"]
    return out


def _invalidate_cache_root():
    global _CACHE_ROOT, _CACHE_ROOT_LOCATION, _CACHE_ROOT_AT
    with _CACHE_ROOT_LOCK:
        _CACHE_ROOT = ""
        _CACHE_ROOT_LOCATION = ""
        _CACHE_ROOT_AT = 0.0


def save_settings(location, max_mb, retention_days):
    try:
        safe_size = max(MIN_CACHE_MB, min(int(max_mb), MAX_CACHE_MB))
    except Exception:
        safe_size = DEFAULTS["max_mb"]
    try:
        safe_retention = max(MIN_RETENTION_DAYS, min(int(retention_days), MAX_RETENTION_DAYS))
    except Exception:
        safe_retention = DEFAULTS["retention_days"]
    data = {
        "location": str(location or "auto"),
        "max_mb": safe_size,
        "retention_days": safe_retention,
    }
    try:
        ensure_dir(BASE)
        tmp = SETTINGS_FILE + ".tmp"
        with open_text(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        atomic_replace(tmp, SETTINGS_FILE)
        _invalidate_cache_root()
        return True
    except Exception:
        return False


def get_settings():
    return _load()


def _usable_mount(path):
    try:
        if not os.path.isdir(path):
            return False
        test = os.path.join(path, ".tivimatee2-write-test")
        with open_text(test, "w") as f:
            f.write("1")
        os.remove(test)
        return True
    except Exception:
        return False


def get_cache_root():
    global _CACHE_ROOT, _CACHE_ROOT_LOCATION, _CACHE_ROOT_AT
    cfg = _load()
    location = str(cfg.get("location", "auto") or "auto")
    now = time.time()
    with _CACHE_ROOT_LOCK:
        if (_CACHE_ROOT and _CACHE_ROOT_LOCATION == location and
                now - _CACHE_ROOT_AT < CACHE_ROOT_TTL and
                os.path.isdir(_CACHE_ROOT)):
            return _CACHE_ROOT

        candidates = {
            "hdd": ["/media/hdd"],
            "usb": ["/media/usb", "/media/usb1", "/media/usb2"],
            "mmc": ["/media/mmc"],
            "tmp": ["/tmp"],
        }
        if location == "auto":
            order = ["hdd", "usb", "mmc", "tmp"]
        else:
            order = [location, "hdd", "usb", "mmc", "tmp"]
        seen = set()
        for key in order:
            if key in seen:
                continue
            seen.add(key)
            for mount in candidates.get(key, []):
                if _usable_mount(mount):
                    root = os.path.join(mount, "tivimatee2-cache") if mount != "/tmp" else "/tmp/tivimatee2"
                    try:
                        ensure_dir(root)
                        _CACHE_ROOT = root
                        _CACHE_ROOT_LOCATION = location
                        _CACHE_ROOT_AT = now
                        return root
                    except Exception:
                        pass
        _CACHE_ROOT = "/tmp/tivimatee2"
        _CACHE_ROOT_LOCATION = location
        _CACHE_ROOT_AT = now
        return _CACHE_ROOT


def get_cache_dir(kind="misc"):
    path = os.path.join(get_cache_root(), str(kind or "misc"))
    try:
        ensure_dir(path)
    except Exception:
        pass
    return path


def cache_status():
    root = get_cache_root()
    total = 0
    files = 0
    try:
        for base, _dirs, names in os.walk(root):
            for name in names:
                p = os.path.join(base, name)
                try:
                    total += os.path.getsize(p)
                    files += 1
                except Exception:
                    pass
    except Exception:
        pass
    return root, total, files


def clear_cache():
    root = get_cache_root()
    try:
        if root.startswith(("/media/", "/tmp/tivimatee2")) and os.path.exists(root):
            shutil.rmtree(root)
        ensure_dir(root)
        _invalidate_cache_root()
        return True
    except Exception:
        return False


def cleanup_cache():
    cfg = _load()
    root = get_cache_root()
    max_bytes = int(cfg.get("max_mb", DEFAULTS["max_mb"])) * 1024 * 1024
    retention = int(cfg.get("retention_days", DEFAULTS["retention_days"])) * 86400
    now = time.time()
    entries = []
    total = 0
    try:
        for base, _dirs, names in os.walk(root):
            for name in names:
                p = os.path.join(base, name)
                try:
                    st = os.stat(p)
                    if retention > 0 and now - st.st_mtime > retention:
                        os.remove(p)
                        continue
                    total += st.st_size
                    entries.append((st.st_mtime, st.st_size, p))
                except Exception:
                    pass
        if max_bytes > 0 and total > max_bytes:
            entries.sort(key=lambda x: x[0])
            for _mtime, size, p in entries:
                if total <= max_bytes:
                    break
                try:
                    os.remove(p)
                    total -= size
                except Exception:
                    pass
    except Exception:
        pass
    return total
