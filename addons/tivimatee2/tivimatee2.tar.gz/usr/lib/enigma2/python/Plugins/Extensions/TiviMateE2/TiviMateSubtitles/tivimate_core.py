# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function

import bisect
import codecs
import os
import unicodedata

from enigma import eTimer

from .compat import eConnectCallback
from .e2_utils import fps_float, getFps
from .parsers.baseparser import NoSubtitlesParseError, ParseError
from .process import DecodeError, LoadError, ParserNotFoundError
from .seekers.utilities import getFileSize
from .utils import decode, load, toString

try:
    long
except NameError:
    long = int


class TiviMateFastSubsLoader(object):
    """Fast single-path subtitle loader with multilingual encoding detection.

    Detection runs only when a subtitle file is loaded.  It never executes at
    TiviMate startup.  The parser stack and renderer stay unchanged.
    """

    MAX_FILE_SIZE = 2 * 1024 * 1024
    _MOJIBAKE_MARKERS = (
        u'\ufffd', u'Ã', u'Â', u'â€', u'â€™', u'â€œ', u'â€\x9d',
        u'Ø§', u'Ø£', u'Ø¥', u'Ù„', u'Ù…', u'Ð', u'Ñ',
    )

    def __init__(self, parsers_cls, encodings=None):
        self._parsers = [cls() for cls in parsers_cls]
        self._encodings = self._dedupe(encodings or ['utf-8'])
        self._row_parsing = False

    def toggle_row_parsing(self):
        self.set_row_parsing(not self._row_parsing)

    def set_row_parsing(self, value):
        self._row_parsing = bool(value)
        for parser in self._parsers:
            parser.rowParse = self._row_parsing

    def change_encodings(self, encodings):
        self._encodings = self._dedupe(encodings or ['utf-8'])

    @staticmethod
    def _dedupe(encodings):
        out = []
        seen = set()
        for enc in encodings:
            try:
                key = codecs.lookup(enc).name
            except Exception:
                continue
            if key not in seen:
                seen.add(key)
                out.append(enc)
        return out or ['utf-8']

    def change_encoding(self, text, current_encoding):
        """Manual 'Change encoding': keep deterministic next-encoding cycling."""
        encodings = self._encodings
        if not encodings:
            raise DecodeError()
        start = 0
        if current_encoding:
            current_key = self._codec_key(current_encoding)
            for idx, enc in enumerate(encodings):
                if self._codec_key(enc) == current_key:
                    start = (idx + 1) % len(encodings)
                    break
        for step in range(len(encodings)):
            enc = encodings[(start + step) % len(encodings)]
            decoded = self._try_decode(text, enc)
            if decoded is not None:
                return decoded, enc
        raise DecodeError()

    @staticmethod
    def _codec_key(enc):
        try:
            return codecs.lookup(enc).name
        except Exception:
            return str(enc or '').lower()

    def _read(self, subfile):
        size = getFileSize(subfile)
        if size and size > self.MAX_FILE_SIZE:
            raise LoadError('"%s" - not supported subtitles size: "%dKB"' %
                            (toString(os.path.basename(subfile)), size // 1024))
        try:
            return load(subfile)
        except Exception:
            raise LoadError(subfile)

    def _parse(self, text, ext=None, fps=None):
        preferred = []
        fallback = []
        for parser in self._parsers:
            if ext and parser.canParse(ext):
                preferred.append(parser)
            else:
                fallback.append(parser)
        for parser in preferred + fallback:
            try:
                return parser.parse(text, fps)
            except NoSubtitlesParseError:
                continue
            except ParseError:
                continue
        raise ParserNotFoundError(str(ext))

    @staticmethod
    def _bom_encoding(raw):
        if not isinstance(raw, (bytes, bytearray)):
            return None
        data = bytes(raw)
        table = (
            (codecs.BOM_UTF32_LE, 'utf-32-le'),
            (codecs.BOM_UTF32_BE, 'utf-32-be'),
            (codecs.BOM_UTF8, 'utf-8-sig'),
            (codecs.BOM_UTF16_LE, 'utf-16-le'),
            (codecs.BOM_UTF16_BE, 'utf-16-be'),
        )
        for bom, enc in table:
            if bom and data.startswith(bom):
                return enc
        return None

    @staticmethod
    def _looks_utf16_or_32(raw):
        if not raw:
            return False
        sample = bytes(raw[:4096])
        if not sample:
            return False
        return (float(sample.count(b'\x00')) / float(len(sample))) > 0.12

    @staticmethod
    def _try_decode(raw, encoding):
        try:
            if isinstance(raw, str):
                return raw
            return bytes(raw).decode(encoding, 'strict')
        except Exception:
            return None

    @staticmethod
    def _script_counts(text):
        counts = {
            'arabic': 0, 'hebrew': 0, 'cyrillic': 0, 'greek': 0,
            'latin': 0, 'cjk': 0, 'japanese': 0, 'hangul': 0,
            'thai': 0, 'vietnamese': 0,
        }
        for ch in text:
            cp = ord(ch)
            if (0x0600 <= cp <= 0x06FF or 0x0750 <= cp <= 0x077F or
                    0x08A0 <= cp <= 0x08FF or 0xFB50 <= cp <= 0xFDFF or
                    0xFE70 <= cp <= 0xFEFF):
                counts['arabic'] += 1
            elif 0x0590 <= cp <= 0x05FF:
                counts['hebrew'] += 1
            elif 0x0400 <= cp <= 0x052F:
                counts['cyrillic'] += 1
            elif 0x0370 <= cp <= 0x03FF:
                counts['greek'] += 1
            elif 0x0E00 <= cp <= 0x0E7F:
                counts['thai'] += 1
            elif 0x3040 <= cp <= 0x30FF:
                counts['japanese'] += 1
            elif 0xAC00 <= cp <= 0xD7AF or 0x1100 <= cp <= 0x11FF:
                counts['hangul'] += 1
            elif 0x3400 <= cp <= 0x9FFF:
                counts['cjk'] += 1
            elif ('LATIN' in unicodedata.name(ch, '')):
                counts['latin'] += 1
                if (0x0102 <= cp <= 0x01B0 or cp in (0x1EA0, 0x1EF9)):
                    counts['vietnamese'] += 1
        return counts

    def _encoding_script(self, encoding):
        key = self._codec_key(encoding)
        if key in ('cp1256', 'iso8859-6', 'cp864'):
            return 'arabic'
        if key in ('cp1255', 'iso8859-8', 'cp862'):
            return 'hebrew'
        if key in ('cp1251', 'iso8859-5', 'koi8-r', 'koi8-u', 'cp866', 'mac-cyrillic'):
            return 'cyrillic'
        if key in ('cp1253', 'iso8859-7', 'mac-greek'):
            return 'greek'
        if key in ('cp874', 'tis-620'):
            return 'thai'
        if key in ('shift-jis', 'cp932', 'euc-jp'):
            return 'japanese'
        if key in ('euc-kr', 'cp949'):
            return 'hangul'
        if key in ('gb18030', 'gbk', 'big5', 'big5hkscs'):
            return 'cjk'
        if key == 'cp1258':
            return 'vietnamese'
        return 'latin'

    def _quality_score(self, text, encoding):
        if not text:
            return -100000.0
        length = float(max(1, len(text)))
        controls = 0
        printable = 0
        replacement = 0
        weird = 0
        for ch in text:
            cp = ord(ch)
            category = unicodedata.category(ch)
            if ch in '\r\n\t' or category[0] in ('L', 'N', 'P', 'S', 'Z', 'M'):
                printable += 1
            if ch == u'\ufffd':
                replacement += 1
            if category in ('Cc', 'Cs') and ch not in '\r\n\t':
                controls += 1
            if cp == 0 or (0x80 <= cp <= 0x9F):
                weird += 1

        score = 100.0 * (printable / length)
        score -= 220.0 * (controls / length)
        score -= 400.0 * (replacement / length)
        score -= 160.0 * (weird / length)

        marker_hits = sum(text.count(marker) for marker in self._MOJIBAKE_MARKERS)
        score -= min(80.0, marker_hits * 5.0)

        # Subtitle structure is encoding-independent and gives clean files a
        # small boost without allowing garbage to win merely because it decodes.
        if '-->' in text:
            score += 10.0
        if 'Dialogue:' in text or '[Script Info]' in text:
            score += 8.0

        counts = self._script_counts(text)
        letters = float(max(1, sum(counts.values())))
        target = self._encoding_script(encoding)
        target_ratio = counts.get(target, 0) / letters

        # For non-Latin code pages, meaningful native-script output is a strong
        # signal. This is what prevents CP1252/Latin-1 from winning over CP1256,
        # CP1251, Big5, Shift-JIS, etc. simply because both decode successfully.
        if target != 'latin':
            score += 55.0 * target_ratio
            if sum(counts.values()) >= 8 and target_ratio < 0.08:
                score -= 20.0
        else:
            latin_ratio = counts['latin'] / letters
            score += 18.0 * latin_ratio

        # UTF-8 strict is preferred when equally plausible. It is the safest
        # modern subtitle encoding and prevents legacy pages from stealing it.
        if self._codec_key(encoding) in ('utf-8', 'utf-8-sig'):
            score += 14.0
        return score

    def _candidate_encodings(self, raw):
        ordered = []
        bom = self._bom_encoding(raw)
        if bom:
            ordered.append(bom)
        # Always test strict UTF-8 immediately after BOM handling.
        ordered.extend(['utf-8-sig', 'utf-8'])
        allow_wide = bool(bom) or self._looks_utf16_or_32(raw)
        for enc in self._encodings:
            key = self._codec_key(enc)
            if not allow_wide and key.startswith(('utf-16', 'utf-32')):
                continue
            ordered.append(enc)
        return self._dedupe(ordered)

    def _decoded_ranked(self, raw):
        ranked = []
        bom = self._bom_encoding(raw)
        if bom:
            text = self._try_decode(raw, bom)
            if text is not None:
                # A valid BOM is authoritative.
                return [(1000000.0, bom, text)]
        for order, enc in enumerate(self._candidate_encodings(raw)):
            text = self._try_decode(raw, enc)
            if text is None:
                continue
            score = self._quality_score(text, enc)
            # Preserve configured ordering only as a tiny tie-breaker.
            score -= order * 0.001
            ranked.append((score, enc, text))
        ranked.sort(key=lambda item: item[0], reverse=True)
        return ranked

    def _manual_order(self, current_encoding):
        encodings = self._encodings
        if not current_encoding:
            return []
        current_key = self._codec_key(current_encoding)
        idx = -1
        for pos, enc in enumerate(encodings):
            if self._codec_key(enc) == current_key:
                idx = pos
                break
        if idx < 0:
            return encodings
        return encodings[idx + 1:] + encodings[:idx + 1]

    def load(self, subfile, current_encoding=None, fps=None):
        raw = self._read(subfile)
        ext = os.path.splitext(subfile)[1]

        # Manual Change Encoding keeps the old predictable cycling behavior.
        if current_encoding:
            for enc in self._manual_order(current_encoding):
                text = self._try_decode(raw, enc)
                if text is None:
                    continue
                try:
                    rows = self._parse(text, ext, fps)
                    if rows:
                        return rows, enc
                except (NoSubtitlesParseError, ParserNotFoundError, ParseError):
                    continue
            raise DecodeError(subfile)

        # Automatic mode: rank every strict decode by text quality, then accept
        # the highest-quality candidate that also parses into valid subtitle rows.
        ranked = self._decoded_ranked(raw)
        if not ranked:
            raise DecodeError(subfile)
        parsed_any = False
        for score, enc, text in ranked:
            # Extremely poor text is never accepted merely because a parser can
            # extract timestamps from it.
            if score < 25.0:
                continue
            try:
                rows = self._parse(text, ext, fps)
                parsed_any = True
                if rows:
                    print('[TiviMate Encoding] selected %s score=%.2f' % (enc, score))
                    return rows, enc
            except (NoSubtitlesParseError, ParserNotFoundError, ParseError):
                continue
        if parsed_any:
            raise DecodeError(subfile)
        raise ParserNotFoundError(ext)


class TiviMateFastSubsEngine(object):
    """Lean Movie Player subtitle clock.

    Uses one PTS clock, one delay value and the parser timestamps. There is no
    MicroLead, learned render lag, drift estimator, or hidden FPS correction.
    """

    def __init__(self, session, engineSettings, renderer):
        self.session = session
        self.engineSettings = engineSettings
        self.renderer = renderer
        self.subsList = []
        self._starts = []
        self.position = 0
        self.sub = None
        self.subsFpsRatio = 1.0
        self.subsDelay = 0
        self.playerDelay = 0
        self.onSubsFpsChanged = []
        self.onSubsDelayChanged = []
        self.syncDelay = 300
        self.hideInterval = 200 * 90
        self.refreshTimerDelay = 1000
        self.getPlayPtsTimerDelay = 200
        self._seek = None
        self._pts = None
        self._pts_delay = None
        self._pts_callback = None

        self.refreshTimer = eTimer()
        self.refreshTimer_conn = eConnectCallback(self.refreshTimer.timeout, self.play)
        self.hideTimer = eTimer()
        self.hideTimer_conn_array = [
            eConnectCallback(self.hideTimer.timeout, self._after_hide)
        ]
        self.getPlayPtsTimer = eTimer()
        self.getPlayPtsTimer_conn_array = [
            eConnectCallback(self.getPlayPtsTimer.timeout, self._poll_pts)
        ]
        self.resume = self.play
        self.addNotifiers()

    def addNotifiers(self):
        self._notifiers = []
        pairs = [
            (self.engineSettings.expert.hideDelay, self._set_hide_delay),
            (self.engineSettings.expert.playerDelay, self._set_player_delay_setting),
            (self.engineSettings.expert.syncDelay, self._set_sync_delay),
            (self.engineSettings.expert.ptsDelayCheck, self._set_pts_retry),
            (self.engineSettings.expert.refreshDelay, self._set_refresh_delay),
        ]
        for entry, callback in pairs:
            entry.addNotifier(callback)
            self._notifiers.append((entry, callback))

    def removeNotifiers(self):
        for entry, callback in getattr(self, '_notifiers', []):
            try:
                entry.removeNotifier(callback)
            except Exception:
                try:
                    entry.notifiers.remove(callback)
                except Exception:
                    pass
        self._notifiers = []

    def _set_hide_delay(self, configElement):
        self.hideInterval = int(configElement.value) * 90

    def _set_player_delay_setting(self, configElement):
        self.playerDelay = int(configElement.value) * 90

    def _set_sync_delay(self, configElement):
        self.syncDelay = int(configElement.value)

    def _set_pts_retry(self, configElement):
        self.getPlayPtsTimerDelay = int(configElement.value)

    def _set_refresh_delay(self, configElement):
        self.refreshTimerDelay = int(configElement.value)

    def getPlayPts(self, callback, delay=None):
        self.getPlayPtsTimer.stop()
        self._pts_callback = callback
        self._pts_delay = delay
        self._pts = None
        self.getPlayPtsTimer.start(int(1 if delay is None else delay), True)

    def _poll_pts(self):
        try:
            if self._seek is None:
                service = self.session.nav.getCurrentService()
                self._seek = service and service.seek()
            result = self._seek and self._seek.getPlayPosition()
            if result and not result[0]:
                self._pts = long(result[1]) + self.playerDelay
        except Exception:
            self._pts = None
        if self._pts is None:
            delay = self._pts_delay if self._pts_delay is not None else self.getPlayPtsTimerDelay
            self.getPlayPtsTimer.start(int(delay), True)
            return
        callback = self._pts_callback
        if callback:
            callback()

    def setSubsList(self, subslist):
        self.subsList = list(subslist or [])
        self._starts = [int(row.get('start', 0)) for row in self.subsList]
        self.position = 0
        self.sub = None

    def setRenderer(self, renderer):
        self.renderer = renderer

    def setPlayerDelay(self, delayInMs):
        self.playerDelay = int(delayInMs) * 90

    def setSubsFps(self, subsFps):
        videoFps = getFps(self.session, True)
        if videoFps is None:
            return
        self.pause()
        self.subsFpsRatio = float(subsFps) / float(videoFps)
        for callback in list(self.onSubsFpsChanged):
            callback(self.getSubsFps())
        self.resume()

    def getSubsFps(self):
        videoFps = getFps(self.session, True)
        if videoFps is None:
            return None
        return fps_float(self.subsFpsRatio * videoFps)

    def setSubsDelay(self, delayInMs):
        self.pause()
        self.subsDelay = int(round(float(delayInMs))) * 90
        for callback in list(self.onSubsDelayChanged):
            callback(self.getSubsDelay())
        self.resume()

    def getSubsDelay(self):
        return self.subsDelay / 90

    def getSubsPosition(self):
        return self.position

    def _sync_to_index(self, index):
        if not self.subsList:
            return
        index = max(0, min(int(index), len(self.subsList) - 1))
        def apply_delay():
            row = self.subsList[index]
            delay = (self._pts - (row['start'] * self.subsFpsRatio)) / 90.0
            self.position = index
            self.setSubsDelay(delay)
        self.stopTimers()
        self.getPlayPts(apply_delay)

    def setSubsDelayToNextSubtitle(self):
        if not self.subsList:
            return
        index = self.position + (1 if getattr(self.renderer, 'subShown', False) else 0)
        self._sync_to_index(index)

    def setSubsDelayToPrevSubtitle(self):
        if not self.subsList:
            return
        index = self.position - 1
        self._sync_to_index(index)

    def reset(self, position=True):
        self.stopTimers()
        self.hideSub()
        if position:
            self.position = 0
        self._seek = None
        self._pts = None
        self._pts_callback = None
        self.sub = None
        self.subsDelay = 0
        self.subsFpsRatio = 1.0

    def refresh(self):
        self.stopTimers()
        self.hideSub()
        self.refreshTimer.start(int(self.refreshTimerDelay), True)

    def pause(self):
        self.stopTimers()
        self.hideSub()

    def play(self):
        self.stopTimers()
        self.hideSub()
        if self.subsList:
            self.getPlayPts(self._start_from_current_pts)

    def sync(self):
        # One delayed PTS sample is enough after seek; no drift-learning loop.
        self.stopTimers()
        self.hideSub()
        if self.subsList:
            self.getPlayPts(self._start_from_current_pts, self.syncDelay)

    def _start_from_current_pts(self):
        self.updateSubPosition()
        self.doPlay()

    def prePlay(self):
        self._start_from_current_pts()

    def _effective_start(self, row):
        return int(row['start'] * self.subsFpsRatio) + self.subsDelay

    def _effective_end(self, row):
        return int(row['end'] * self.subsFpsRatio) + self.subsDelay

    def updateSubPosition(self):
        if not self.subsList or self._pts is None:
            self.position = 0
            return
        # Binary-search approximate position, then adjust for delay/FPS.
        raw_pts = int((self._pts - self.subsDelay) / max(self.subsFpsRatio, 0.0001))
        index = bisect.bisect_right(self._starts, raw_pts) - 1
        if index < 0:
            index = 0
        while index < len(self.subsList) - 1 and self._effective_end(self.subsList[index]) < self._pts:
            index += 1
        while index > 0 and self._effective_start(self.subsList[index]) > self._pts:
            index -= 1
        self.position = index

    def doPlay(self):
        if not self.subsList:
            return
        if self.position >= len(self.subsList):
            self.position = len(self.subsList) - 1
            return
        self.sub = self.subsList[self.position]
        self.getPlayPts(self.doWait)

    def doWait(self):
        if self.sub is None or self._pts is None:
            return
        start = self._effective_start(self.sub)
        end = self._effective_end(self.sub)
        if self._pts < start:
            wait_ms = max(1, int((start - self._pts) / 90))
            if wait_ms > 50:
                self.getPlayPts(self.doWait, wait_ms)
                return
        elif self._pts > end:
            self.position += 1
            if self.position < len(self.subsList):
                self.doPlay()
            return
        self.renderSub()

    def renderSub(self):
        if self.sub is None:
            return
        self.renderer.setSubtitle(self.sub)
        duration_pts = max(0, self._effective_end(self.sub) - max(self._effective_start(self.sub), self._pts or 0))
        duration_ms = max(1, int(duration_pts / 90))
        self.hideTimer.start(duration_ms, True)

    def _after_hide(self):
        self.hideSub()
        self.position += 1
        if self.position < len(self.subsList):
            self.doPlay()

    def checkHideSub(self):
        self.hideSub()

    def hideSub(self):
        try:
            self.renderer.hideSubtitle()
        except Exception:
            pass

    def incSubPosition(self):
        self.position += 1

    def showDialog(self):
        self.renderer.show()

    def hideSubtitlesDialog(self):
        self.renderer.hide()

    def stopTimers(self):
        for timer in (self.refreshTimer, self.getPlayPtsTimer, self.hideTimer):
            try:
                timer.stop()
            except Exception:
                pass

    def exit(self):
        self.stopTimers()
        self.removeNotifiers()
        try:
            del self.hideTimer_conn_array[:]
            del self.getPlayPtsTimer_conn_array[:]
        except Exception:
            pass
        self.onSubsDelayChanged[:] = []
        self.onSubsFpsChanged[:] = []
