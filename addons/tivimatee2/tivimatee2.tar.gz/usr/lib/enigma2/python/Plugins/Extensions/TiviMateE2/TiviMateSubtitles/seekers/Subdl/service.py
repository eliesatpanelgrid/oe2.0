import requests
import os
import re, json
from urllib.parse import quote_plus, urljoin
from ..utilities import log
from .SubdlUtilities import get_language_info
from ..user_agents import get_api_user_agent, get_random_ua
from ..seeker import SubtitlesDownloadError, SubtitlesErrors

SEARCH_URL = "https://api.subdl.com/api/v1/subtitles"
DOWNLOAD_URL = "https://dl.subdl.com"
API_TIMEOUT = 10
DOWNLOAD_TIMEOUT = 30

def build_api_headers():
    """Return headers for SubDL REST API requests."""
    return {
        "User-Agent": get_api_user_agent(),
        "Accept": "application/json",
    }

def build_download_headers():
    """Return browser-like headers for ordinary SubDL file downloads."""
    return {
        "User-Agent": get_random_ua(),
        "Accept": "application/octet-stream,*/*;q=0.8",
    }



def get_subdl_api():
    global settings_provider  # Ensure we're using the existing instance
    API_KEY = settings_provider.getSetting("Subdl_API_KEY")
    if API_KEY:
        return API_KEY
    print("Error: SubDL API key is missing.")
    return None


def prepare_search_string(s):
    s = s.replace("'", "").strip()
    s = re.sub(r'\(\d\d\d\d\)$', '', s)  # remove year from title
    s = quote_plus(s)
    return s


def get_subtitles_list_movie(searchstring, title, languageshort, languagelong, subtitles_list, year=None):
    """Fetches subtitles from the SubDL API and adds them to subtitles_list."""
    if not searchstring:
        print("Empty search string provided")
        return

    API_KEY = get_subdl_api()
    if not API_KEY:
        print("Error: SubDL API key is missing.")
        return

    try:
        params = {
            "api_key": API_KEY,
            "film_name": searchstring,
            "type": "movie",
            "imdb_id": None,
            "languages": languageshort,
            "subs_per_page": 30,
            "releases": 1,
            "unpack": 1,
            "client": "custom_integration"
        }

        if year:
            params["year"] = int(year)
        response = requests.get(SEARCH_URL, params=params, headers=build_api_headers(), timeout=API_TIMEOUT)
        response.raise_for_status()  # Raises exception for bad status codes
        
        json_data = response.json()
        status = json_data.get("status", False)
        
        if status:
            all_subs_data = json_data.get("subtitles", [])
            for item in all_subs_data:
                try:
                    language = item.get("lang")
                    filename = item.get("release_name")
                    id = item.get("url")
                    if language and filename and id:
                        subtitles_list.append({
                            'filename': filename, 
                            'sync': True, 
                            'id': id, 
                            'language_flag': languageshort, 
                            'language_name': languagelong
                        })
                except Exception as e:
                    print(f"Error processing subtitle item: {e}")
    except Exception as e:
        print(f"Error in get_subtitles_list_movie: {e}")

def get_subtitles_list_tv(searchstring, tvshow, season, episode, languageshort, languagelong, subtitles_list, year=None):
    """Fetches subtitles from the SubDL API and adds them to subtitles_list."""
    if not searchstring:
        print("Empty search string provided")
        return

    API_KEY = get_subdl_api()
    if not API_KEY:
        print("Error: SubDL API key is missing.")
        return

    try:
        params = {
            "api_key": API_KEY,
            "film_name": tvshow,
            "type": "tv",
            "imdb_id": None,
            "season_number": season,
            "episode_number": episode,
            "languages": languageshort,
            "subs_per_page": 30,
            "releases": 1,
            "unpack": 1,
            "client": "custom_integration"
        }

        if year:
            params["year"] = int(year)
        response = requests.get(SEARCH_URL, params=params, headers=build_api_headers(), timeout=API_TIMEOUT)
        response.raise_for_status()  # Raises exception for bad status codes
        
        json_data = response.json()
        status = json_data.get("status", False)
        
        if status:
            all_subs_data = json_data.get("subtitles", [])
            for item in all_subs_data:
                try:
                    language = item.get("lang")
                    filename = item.get("release_name")
                    id = item.get("url")
                    if language and filename and id:
                        subtitles_list.append({
                            'filename': filename, 
                            'sync': True, 
                            'id': id, 
                            'language_flag': languageshort, 
                            'language_name': languagelong
                        })
                except Exception as e:
                    print(f"Error processing subtitle item: {e}")
    except Exception as e:
        print(f"Error in get_subtitles_list_tv: {e}")


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    subtitles_list = []
    msg = ""
    if not title and not tvshow and not file_original_path:
        return subtitles_list, "", msg
    if not title and not tvshow and file_original_path:
        try:
            filename = os.path.basename(file_original_path)
            match = re.match(r'^(.*?)(?:\.\d{4}|\.S\d{2}E\d{2}|\.\d{3,4}p|\.\w{2,3})?\.\w+$', filename)
            if match:
                title = match.group(1).replace('.', ' ').strip()
        except Exception:
            pass
    infos=[]
    seen_lang=set()
    for raw in (lang1,lang2,lang3):
        if not raw: continue
        try:
            info=get_language_info('Persian' if raw=='Farsi' else raw)
        except Exception:
            info=None
        if not info: continue
        code=(info.get('2et') or raw).upper()
        if code in seen_lang: continue
        seen_lang.add(code); infos.append((code,info.get('name') or raw))
    try:
        # SubDL supports comma separated language codes. One request avoids serial waits.
        codes=','.join(x[0] for x in infos)
        display={x[0].lower():x[1] for x in infos}
        API_KEY=get_subdl_api()
        if not API_KEY or not codes:
            return subtitles_list,"",msg
        is_tv=bool(tvshow)
        query=tvshow if is_tv else title
        params={"api_key":API_KEY,"film_name":query,"type":"tv" if is_tv else "movie",
                "languages":codes,"subs_per_page":30,"releases":1,"unpack":1,"client":"custom_integration"}
        if year:
            try: params['year']=int(year)
            except Exception: pass
        if is_tv:
            try: params['season_number']=int(season)
            except Exception: pass
            try: params['episode_number']=int(episode)
            except Exception: pass
        response=requests.get(SEARCH_URL,params=params,headers=build_api_headers(),timeout=API_TIMEOUT)
        response.raise_for_status(); data=response.json() or {}
        seen=set()
        for item in data.get('subtitles') or []:
            lang=(item.get('lang') or item.get('language') or '').lower()
            url=item.get('url') or item.get('download_url')
            if not url: continue
            release=item.get('release_name') or item.get('name') or item.get('file_name') or 'SubDL'
            k=(str(url),str(release).lower(),lang)
            if k in seen: continue
            seen.add(k)
            subtitles_list.append({'filename':release,'sync':bool(item.get('release_name')),'id':url,
                                   'language_flag':lang,'language_name':display.get(lang, lang or 'Unknown')})
    except Exception as e:
        return subtitles_list,"",str(e)
    return subtitles_list,"",msg

def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    subtitle_id = subtitles_list[pos]["id"]
    language = subtitles_list[pos]["language_name"]
    download_url = subtitle_id if str(subtitle_id).startswith(("http://", "https://")) else urljoin(DOWNLOAD_URL + "/", str(subtitle_id).lstrip("/"))
    response = requests.get(download_url, headers=build_download_headers(), stream=True, timeout=DOWNLOAD_TIMEOUT, allow_redirects=True)
    local_tmp_file = zip_subs
    packed = False
    subs_file = ""

    if response.status_code == 200:
        os.makedirs(tmp_sub_dir, exist_ok=True)
        with open(local_tmp_file, 'wb') as file:
            for chunk in response.iter_content(chunk_size=1024):
                if chunk:
                    file.write(chunk)
        
        with open(local_tmp_file, "rb") as f:
            header = f.read(2)
            if header.startswith(b'R'):
                packed = True
                subs_file = "rar"
            elif header.startswith(b'P'):
                packed = True
                subs_file = "zip"
            else:
                subs_file = local_tmp_file
    
    return packed, language, subs_file
