# -*- coding: utf-8 -*-
from __future__ import absolute_import

import json
import os
import re
import threading
try:
    from urllib.parse import urlencode, quote
    from urllib.request import Request, urlopen
except ImportError:
    from urllib import urlencode, quote
    from urllib2 import Request, urlopen

try:
    from xml.sax.saxutils import escape
except Exception:
    def escape(value):
        return value

from .compat import ensure_dir, open_text, atomic_replace
from .live_service import epg_reference_string
from .core import get_source_client
from .filters import get_allowed_category_ids, category_id_for_item

EPGIMPORT_DIR = "/etc/epgimport"
SOURCES_PATH = os.path.join(EPGIMPORT_DIR, "tivimatee2.sources.xml")
CHANNELS_PREFIX = "tivimatee2_"
SYNC_LOG = "/tmp/tivimatee2_epg_sync.log"
SETTINGS_PATH = "/etc/enigma2/tivimatee2_channel_settings.json"
UA = "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/1.0"
_SYNC_LOCK = threading.Lock()
_SYNC_RUNNING = False
EPG_SERVICE_TYPES = (1, 4097, 5002)


def _safe_name(value, fallback="IPTV"):
    value = (value or fallback).strip() or fallback
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_") or fallback


def _xmltv_url(source):
    explicit = (source.get("epg_url") or source.get("xmltv_url") or "").strip()
    if explicit:
        return explicit
    if source.get("type") == "xtream":
        base = (source.get("url") or "").rstrip("/")
        username = source.get("username") or ""
        password = source.get("password") or ""
        if base and username and password:
            return "%s/xmltv.php?%s" % (base, urlencode({"username": username, "password": password}))
    return ""


def _service_type():
    try:
        with open_text(SETTINGS_PATH, "r", encoding="utf-8") as handle:
            data = json.load(handle) or {}
        return int(data.get("service_type", 4097))
    except Exception:
        return 4097


def _service_ref(url, service_type):
    encoded = quote(str(url or ""), safe="/").replace("%3A", "%3a")
    return "%d:0:1:0:0:0:0:0:0:0:%s" % (int(service_type), encoded)


def _fetch_json(url, timeout=20):
    req = Request(url, headers={"User-Agent": UA})
    response = urlopen(req, timeout=timeout)
    try:
        raw = response.read()
    finally:
        try:
            response.close()
        except Exception:
            pass
    if not isinstance(raw, str):
        raw = raw.decode("utf-8", "replace")
    return json.loads(raw)


def _fetch_text(url, timeout=20):
    req = Request(url, headers={"User-Agent": UA})
    response = urlopen(req, timeout=timeout)
    try:
        raw = response.read()
    finally:
        try:
            response.close()
        except Exception:
            pass
    if not isinstance(raw, str):
        raw = raw.decode("utf-8", "replace")
    return raw


def _xtream_mappings(source, service_types=None):
    base = (source.get("url") or "").rstrip("/")
    user = source.get("username") or ""
    password = source.get("password") or ""
    if not (base and user and password):
        return []
    api_url = "%s/player_api.php?%s" % (base, urlencode({
        "username": user,
        "password": password,
        "action": "get_live_streams",
    }))
    rows = []
    allowed_ids = get_allowed_category_ids(source, "live")
    for item in _fetch_json(api_url) or []:
        # Apply the same per-server LIVE package filter used by the UI/local EPG.
        # None means unfiltered; an empty set means no LIVE package is enabled.
        if allowed_ids is not None:
            category_id = str(item.get("category_id") or "").strip()
            if category_id not in allowed_ids:
                continue
        epg_id = str(item.get("epg_channel_id") or item.get("tvg_id") or "").strip()
        stream_id = str(item.get("stream_id") or "").strip()
        if not epg_id or not stream_id:
            continue
        rows.append((epg_id, epg_reference_string(source, item)))
    return rows


def _m3u_mappings(source, service_types=None):
    url = (source.get("url") or "").strip()
    if not url:
        return []
    text = _fetch_text(url)
    rows = []
    allowed_ids = get_allowed_category_ids(source, "live")
    pending_id = ""
    pending_group = ""
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("#EXTINF"):
            match = re.search(r'(?:tvg-id|epg-id)=["\']([^"\']+)["\']', line, re.I)
            group_match = re.search(r'group-title=["\']([^"\']+)["\']', line, re.I)
            pending_id = (match.group(1).strip() if match else "")
            pending_group = (group_match.group(1).strip() if group_match else "")
        elif line and not line.startswith("#"):
            if pending_id and (allowed_ids is None or pending_group in allowed_ids):
                item = {"url": line, "group": pending_group}
                rows.append((pending_id, epg_reference_string(source, item)))
            pending_id = ""
            pending_group = ""
    return rows


def _source_mappings(source, service_types=None):
    stype = source.get("type") or "xtream"
    if stype == "xtream":
        return _xtream_mappings(source, service_types)
    if stype == "m3u":
        return _m3u_mappings(source, service_types)
    return []


def _write_channels(path, mappings):
    # De-duplicate by EPG id + service reference while preserving provider order.
    seen = set()
    lines = ['<?xml version="1.0" encoding="utf-8"?>', '<channels>']
    for epg_id, service_ref in mappings or []:
        key = (epg_id, service_ref)
        if key in seen:
            continue
        seen.add(key)
        lines.append('  <channel id="%s">%s</channel>' % (escape(epg_id, {'"': '&quot;'}), escape(service_ref)))
    lines.extend(['</channels>', ''])
    tmp = path + ".tmp"
    with open_text(tmp, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines))
    atomic_replace(tmp, path)
    return len(seen)


def _prepare_sources(sources):
    prepared = []
    seen = set()
    for index, source in enumerate(sources or []):
        xmltv = _xmltv_url(source)
        if not xmltv:
            continue
        display_name = (source.get("name") or "IPTV").strip() or "IPTV"
        slug = _safe_name(display_name, "server_%d" % (index + 1))
        if slug.lower() in seen:
            slug = "%s_%d" % (slug, index + 1)
        seen.add(slug.lower())
        channels_path = os.path.join(EPGIMPORT_DIR, CHANNELS_PREFIX + slug + ".channels.xml")
        prepared.append((dict(source), display_name, xmltv, channels_path))
    return prepared


def _write_sources_file(prepared):
    rows = []
    for source, display_name, xmltv, channels_path in prepared:
        rows.append(
            '    <source type="gen_xmltv" nocheck="1" channels="%s">\n'
            '      <description>%s</description>\n'
            '      <url><![CDATA[%s]]></url>\n'
            '    </source>' % (escape(channels_path), escape(display_name), xmltv)
        )
    xml = ['<?xml version="1.0" encoding="utf-8"?>', '<sources>', '  <sourcecat sourcecatname="TiviMate E2">']
    xml.extend(rows)
    xml.extend(['  </sourcecat>', '</sources>', ''])
    tmp = SOURCES_PATH + ".tmp"
    with open_text(tmp, "w", encoding="utf-8") as handle:
        handle.write("\n".join(xml))
    atomic_replace(tmp, SOURCES_PATH)


def _sync_worker(prepared):
    global _SYNC_RUNNING
    try:
        active = set()
        for source, display_name, xmltv, channels_path in prepared:
            active.add(channels_path)
            try:
                mappings = _source_mappings(source, EPG_SERVICE_TYPES)
                count = _write_channels(channels_path, mappings)
                try:
                    with open_text(SYNC_LOG, "a", encoding="utf-8") as log:
                        sample = mappings[0] if mappings else ("", "")
                        log.write("%s: %d mappings | %s | %s\n" % (display_name, count, sample[0], sample[1]))
                except Exception:
                    pass
            except Exception:
                # Keep the last valid map if a temporary network error occurs.
                if not os.path.exists(channels_path):
                    _write_channels(channels_path, [])
        try:
            for filename in os.listdir(EPGIMPORT_DIR):
                if filename.startswith(CHANNELS_PREFIX) and filename.endswith(".channels.xml"):
                    path = os.path.join(EPGIMPORT_DIR, filename)
                    if path not in active:
                        try:
                            os.remove(path)
                        except Exception:
                            pass
        except Exception:
            pass
    finally:
        with _SYNC_LOCK:
            _SYNC_RUNNING = False
EPG_SERVICE_TYPES = (1, 4097, 5002)


def sync_epgimport_sources(sources, background=True):
    """Create EPGImport sources and real channel mappings per named server."""
    global _SYNC_RUNNING
    try:
        ensure_dir(EPGIMPORT_DIR)
    except Exception:
        pass
    prepared = _prepare_sources(sources)
    _write_sources_file(prepared)

    if background:
        with _SYNC_LOCK:
            if _SYNC_RUNNING:
                return len(prepared)
            _SYNC_RUNNING = True
        worker = threading.Thread(target=_sync_worker, args=(prepared,), name="TiviMateE2EPGImport")
        try:
            worker.daemon = True
        except Exception:
            pass
        worker.start()
    else:
        _sync_worker(prepared)
    return len(prepared)
