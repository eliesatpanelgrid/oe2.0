# -*- coding: UTF-8 -*-
from __future__ import absolute_import
from __future__ import print_function

#from six.moves.urllib.request import FancyURLopener
from six.moves.urllib.parse import quote_plus, urlencode
import urllib.request
import urllib.parse
import html
import requests, json, re ,random, string, time, warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from six.moves import html_parser
warnings.simplefilter('ignore',InsecureRequestWarning)
import os, os.path
from six.moves.urllib.request import HTTPCookieProcessor, build_opener, install_opener, Request, urlopen
from six.moves import http_cookiejar
from .SubsytsUtilities import get_language_info
from ..utilities import languageTranslate, log, getFileSize
import urllib3
from urllib import request, parse
from urllib.parse import urlencode
import urllib.request
import urllib.parse
import six
from six.moves import urllib
from six.moves import xmlrpc_client

import calendar
from ..seeker import SubtitlesDownloadError, SubtitlesErrors
      
HDT= {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:109.0) Gecko/20100101 Firefox/115.0',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9,*;q=0.5',
      'Upgrade-Insecure-Requests': '1',
      'nel': '{"success_fraction":0,"report_to":"cf-nel","max_age":604800}',
      'Content-Type':'text/html; charset=utf-8',
      'Origin': 'https://yts-subs.com',
      'Host': 'yts-subs.com',
      'Referer': 'https://yts-subs.com/',
      'Connection': 'keep-alive',
      'TE': 'trailers',
      'Upgrade-Insecure-Requests': '1',
      'Accept-Encoding':'gzip, deflate, br'}
      
s = requests.Session()  
 

main_url = "https://yts-subs.com"
main_url2 = "https://yts-subs.com"
debug_pretext = "yts-subs.com"


subsyts_languages = {
    'Chinese BG code': 'Chinese',
    'Brazillian Portuguese': 'Portuguese (Brazil)',
    'Serbian': 'SerbianLatin',
    'Ukranian': 'Ukrainian',
    'Farsi/Persian': 'Persian'
}

def get_file2(downloadlink):
    def __init__(self):
        url = '%s%s' % (main_url2, downloadlink) 
        print(url) 
        log(__name__, 'Downloading file %s' % (url))
        req = Request(url)
        req = self.add_cookies_into_header(req)
        response = urlopen(req, timeout=8)
        if response.headers.get('Set-Cookie'):
            phpsessid = re.search(r'PHPSESSID=(\S+);', response.headers.get('Set-Cookie'), re.IGNORECASE | re.DOTALL)
            if phpsessid:
                log(__name__, "Storing PHPSessionID")
                self.cookies['PHPSESSID'] = phpsessid.group(1)
        content = response.read()
        print(content) 
        log(__name__, 'Done')
        response.close()
        return content
    
def find_movie(content, title, year):
    d = content
    print(d)
    url_found = None
    h = html_parser.HTMLParser()
    for matches in re.finditer(movie_season_pattern, content, re.IGNORECASE | re.DOTALL):
        print((tuple(matches.groups())))
        found_title = matches.group('title')
        found_title = html.unescape(found_title) 
        print(("found_title", found_title))  
        log(__name__, "Found movie on search page: %s (%s)" % (found_title, matches.group('year')))
        if found_title.lower().find(title.lower()) > -1:
            if matches.group('year') == year:
                log(__name__, "Matching movie found on search page: %s (%s)" % (found_title, matches.group('year')))
                url_found = matches.group('link')
                break
    return url_found
        
def get_url(url, referer=None):
    if referer is None:
        headers = {'User-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0'}
    else:
        headers = {'User-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0', 'Referer': referer}
    req = urllib.request.Request(url, None, headers)
    response = urllib.request.urlopen(req, timeout=8)
    content = response.read().decode('utf-8') 
    response.close()
    content = content.replace('\n', '')
    return content


def get_rating(downloads):
    rating = int(downloads)
    if (rating < 50):
        rating = 1
    elif (rating >= 50 and rating < 100):
        rating = 2
    elif (rating >= 100 and rating < 150):
        rating = 3
    elif (rating >= 150 and rating < 200):
        rating = 4
    elif (rating >= 200 and rating < 250):
        rating = 5
    elif (rating >= 250 and rating < 300):
        rating = 6
    elif (rating >= 300 and rating < 350):
        rating = 7
    elif (rating >= 350 and rating < 400):
        rating = 8
    elif (rating >= 400 and rating < 450):
        rating = 9
    elif (rating >= 450):
        rating = 10
    return rating                           


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    subtitles_list = []
    msg = ""
    if len(tvshow) == 0 and year:
        searchstring = "%s (%s)" % (title, year)
    elif len(tvshow) > 0 and title == tvshow:
        searchstring = "%s (%#02d%#02d)" % (tvshow, int(season), int(episode))
    elif len(tvshow) > 0:
        searchstring = "%s S%#02dE%#02d" % (tvshow, int(season), int(episode))
    else:
        searchstring = title
    log(__name__, "%s Search string = %s" % (debug_pretext, searchstring))
    seen = set()
    for languagefound in (lang1, lang2, lang3):
        if not languagefound:
            continue
        try:
            language_info = get_language_info('Persian' if languagefound == 'Farsi' else languagefound)
            if not language_info:
                continue
            before = len(subtitles_list)
            get_subtitles_list(searchstring, title, year, language_info['2et'], language_info['name'], subtitles_list)
            # Remove duplicates from repeated/alias language mappings.
            out = []
            for item in subtitles_list:
                key = (str(item.get('id','')), str(item.get('filename','')), str(item.get('language_name','')).lower())
                if key in seen:
                    continue
                seen.add(key)
                out.append(item)
            subtitles_list[:] = out
        except Exception as e:
            log(__name__, "%s language search failed for %s: %s" % (debug_pretext, languagefound, e))
    return subtitles_list, "", msg

def _subsyts_absolute_url(url):
    url = (url or "").strip()
    if not url:
        return ""
    if url.startswith("//"):
        return "https:" + url
    if url.startswith("http://") or url.startswith("https://"):
        return url
    if not url.startswith("/"):
        url = "/" + url
    return main_url2 + url


def _subsyts_looks_like_html(data, content_type=""):
    probe = (data or b"")[:512].lstrip().lower()
    ctype = (content_type or "").lower()
    return ("text/html" in ctype or "application/xhtml" in ctype or
            probe.startswith(b"<!doctype html") or probe.startswith(b"<html") or
            b"<head" in probe[:256])


def _subsyts_download_candidates(page_html, page_url, legacy_id):
    """Extract real YTS download links and keep the legacy direct ZIP as fallback."""
    candidates = []
    try:
        for href in re.findall(r"href=[\"']([^\"']+)[\"']", page_html or "", re.I):
            full = _subsyts_absolute_url(html.unescape(href))
            low = full.lower()
            if ("/subtitle/" in low or low.endswith(".zip")) and full not in candidates:
                candidates.append(full)
    except Exception:
        pass

    direct = _subsyts_absolute_url(legacy_id)
    if direct and not direct.lower().endswith(".zip"):
        direct += ".zip"
    if direct and direct not in candidates:
        candidates.append(direct)
    return candidates


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    """Download Subsyts safely: preserve cookies and never pass HTML to decoder."""
    try:
        subtitle = subtitles_list[pos]
        language = subtitle.get("language_name", "")
        legacy_id = subtitle.get("id", "")
        if not legacy_id:
            log(__name__, "%s Missing subtitle id" % debug_pretext)
            return False, "", ""

        detail_path = legacy_id
        if detail_path.startswith("/subtitle/"):
            detail_path = "/subtitles/" + detail_path[len("/subtitle/"):]
        detail_url = _subsyts_absolute_url(detail_path)

        page_headers = dict(HDT)
        page_headers.pop("Host", None)
        page_headers["Referer"] = main_url2 + "/"
        page_headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        log(__name__, "%s Opening subtitle detail page: %s" % (debug_pretext, detail_url))
        page = s.get(detail_url, headers=page_headers, timeout=8, verify=False, allow_redirects=True)

        page_html = ""
        if page.status_code == 200:
            try:
                page_html = page.text
            except Exception:
                page_html = ""

        candidates = _subsyts_download_candidates(page_html, page.url or detail_url, legacy_id)
        if not candidates:
            log(__name__, "%s No valid download candidate found" % debug_pretext)
            return False, "", ""

        if not os.path.exists(tmp_sub_dir):
            os.makedirs(tmp_sub_dir)

        last_error = ""
        for downloadlink in candidates:
            try:
                headers = dict(HDT)
                headers.pop("Host", None)
                headers["Referer"] = page.url or detail_url
                headers["Origin"] = main_url2
                headers["Accept"] = "application/zip,application/octet-stream,text/plain,*/*"
                log(__name__, "%s Downloadlink: %s" % (debug_pretext, downloadlink))
                response = s.get(downloadlink, headers=headers, timeout=10, verify=False, allow_redirects=True)
                if response.status_code != 200:
                    last_error = "HTTP %s" % response.status_code
                    continue

                payload = response.content or b""
                if not payload:
                    last_error = "empty response"
                    continue
                if _subsyts_looks_like_html(payload, response.headers.get("Content-Type", "")):
                    last_error = "HTML/challenge page returned instead of subtitle"
                    log(__name__, "%s Rejected non-subtitle HTML response" % debug_pretext)
                    continue

                with open(zip_subs, "wb") as local_file_handle:
                    local_file_handle.write(payload)

                header = payload[:8]
                if header.startswith(b"Rar!"):
                    log(__name__, "%s Discovered RAR archive" % debug_pretext)
                    return True, language, "rar"
                if header.startswith(b"PK"):
                    log(__name__, "%s Discovered ZIP archive" % debug_pretext)
                    return True, language, "zip"

                log(__name__, "%s Discovered direct subtitle file" % debug_pretext)
                return False, language, zip_subs
            except Exception as exc:
                last_error = str(exc)
                continue

        log(__name__, "%s Download failed: %s" % (debug_pretext, last_error or "all candidates failed"))
        return False, "", ""
    except Exception as exc:
        log(__name__, "%s Download exception: %s" % (debug_pretext, exc))
        return False, "", ""

       
def get_subtitles_list(searchstring, title, year, languageshort, languagelong, subtitles_list):
    s = languagelong.strip()
    title = title.strip()
    print(title)
    search_string = title.replace(".", "+")
    print(search_string)
    #print(("getSearchTitle", getSearchTitle))
    #print(s)
    #print(title)
    url = '%s/search/%s' % (main_url, search_string)
    print(url)
    try:
        log(__name__, "%s Getting url: %s" % (debug_pretext, url))
        content = get_url(url,referer=main_url)
        #print(content)        
    except:
        pass
        log(__name__, "%s Failed to get url:%s" % (debug_pretext, url))
        return
    try:
        log( __name__ ,"%s Getting '%s' subs ..." % (debug_pretext, languageshort))
        #print(data) 
        subtitles = re.compile('(<a href="/movie-imdb/.+?</h3>)').findall(content)
        #print(subtitles)
        subtitles = " ".join(subtitles)
        regx = 'alt="'+title+'".+?href="(.+?)">' 
        downloadlink=re.findall(regx,subtitles, re.M|re.I)[0]
        #print(downloadlink)
        link = '%s%s' % (main_url, downloadlink)
        #print(link)
        content = get_url(link,referer=main_url)                   
        #print(content)
        subtitles = re.compile('(<span class="sub-lang">'+s+'</span>.+?download</a>)').findall(content)
        #print(subtitles)
    except:
        log( __name__ ,"%s Failed to get subtitles" % (debug_pretext))
        return
    for subtitle in subtitles:
        try:
            filename = re.compile('subtitle</span> (.+?)</a>').findall(subtitle)[0].replace("<br />","\n")
            filename = filename.strip()
            #print(filename)
            id = re.compile('href="(.+?)"').findall(subtitle)[0].replace("subtitles","subtitle")
            #print(id)
            try:
                downloads = re.compile('<a href="(.+?)">.+?<span').findall(subtitle)[0]
                print(downloads)
                downloads = re.sub(r"\D", "", downloads)
            except:
                pass
            try:
                rating = get_rating(downloads)
                #print(rating)
            except:
                rating = 0
                pass
                
            if not (downloads == 'Εργαστήρι Υποτίτλων' or downloads == 'subs4series'):
                log( __name__ ,"%s Subtitles found: %s (id = %s)" % (debug_pretext, filename, id))
                subtitles_list.append({'rating': str(rating), 'no_files': 1, 'filename': str(filename), 'id': id, 'sync': True, 'language_flag': languageshort, 'language_name': languagelong})

        except:
            pass
    return
