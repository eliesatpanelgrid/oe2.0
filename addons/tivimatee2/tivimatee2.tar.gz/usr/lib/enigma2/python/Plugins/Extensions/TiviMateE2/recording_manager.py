# -*- coding: utf-8 -*-

from .storage import get_data_root, data_path
import json
import os
import re
import shlex
import time

try:
    from enigma import eConsoleAppContainer
except Exception:
    eConsoleAppContainer = None

RECORD_CONFIG = data_path("recording.json")


def _settings():
    try:
        with open(RECORD_CONFIG, "r") as handle:
            data = json.load(handle) or {}
        return {"path": str(data.get("path") or "/media/hdd/movie")}
    except Exception:
        return {"path": "/media/hdd/movie"}


def _safe_name(value):
    text = re.sub(r"[^A-Za-z0-9._()\- ]+", "_", str(value or "IPTV")).strip(" ._")
    return text[:120] or "IPTV"


def _find_http_recorder():
    # Use only one external fallback backend. curl is preferred because it
    # follows redirects and reconnects cleanly; wget is used only when curl
    # is not installed.
    for path, kind in (("/usr/bin/curl", "curl"), ("/bin/curl", "curl"),
                       ("/usr/bin/wget", "wget"), ("/bin/wget", "wget")):
        if os.path.exists(path) and os.access(path, os.X_OK):
            return path, kind
    return "", ""


class LiveRecordingManager(object):
    """Live recorder with one active backend at a time.

    First try Enigma2 RecordService on the 4097 service. If Enigma2 refuses
    that service, use exactly one HTTP-copy fallback (curl, or wget when curl
    is unavailable). ffmpeg is deliberately not used because it is broken or
    dependency-sensitive on several receiver images.
    """

    def __init__(self):
        self.record_service = None
        self.nav = None
        self.process = None
        self.backend = ""
        self.output = ""
        self.channel = ""
        self.started_at = 0
        self.last_error = ""
        self._last_size = 0

    def is_recording(self):
        return self.record_service is not None or self.process is not None

    def _file_size(self):
        candidates = [self.output]
        if self.output and not self.output.endswith(".ts"):
            candidates.append(self.output + ".ts")
        for path in candidates:
            try:
                if path and os.path.exists(path):
                    size = os.path.getsize(path)
                    if size >= 0:
                        self.output = path
                        return size
            except Exception:
                pass
        return 0

    def _prepare_native(self, recorder, filename, channel_name):
        now = int(time.time())
        end = now + (24 * 60 * 60)
        attempts = [
            (filename, now, end, -1, channel_name, "TiviMateE2 Live recording", "", True, False),
            (filename, now, end, -1, channel_name, "TiviMateE2 Live recording", "", True),
            (filename, now, end, -1, channel_name, "TiviMateE2 Live recording", ""),
            (filename, now, end, -1, channel_name, "TiviMateE2 Live recording"),
            (filename, now, end, -1, channel_name),
        ]
        last = None
        for args in attempts:
            try:
                result = recorder.prepare(*args)
                if result in (0, None, True):
                    return True
                last = "prepare returned %s" % result
            except TypeError as exc:
                last = str(exc)
                continue
            except Exception as exc:
                last = str(exc)
                break
        self.last_error = last or "native recorder prepare failed"
        return False

    def _reset(self, keep_output=False):
        self.record_service = None
        self.nav = None
        self.process = None
        self.backend = ""
        self.channel = ""
        self.started_at = 0
        self._last_size = 0
        if not keep_output:
            self.output = ""

    def _start_http_fallback(self, url):
        binary, kind = _find_http_recorder()
        if not binary or eConsoleAppContainer is None:
            return False, "Enigma2 refused 4097 and no HTTP recording fallback is available."

        quoted_url = shlex.quote(str(url))
        quoted_output = shlex.quote(self.output)
        if kind == "curl":
            command = "%s -L --fail --silent --show-error --connect-timeout 15 --retry 3 --retry-delay 1 --output %s %s" % (
                shlex.quote(binary), quoted_output, quoted_url)
        else:
            command = "%s -c -O %s %s" % (shlex.quote(binary), quoted_output, quoted_url)

        try:
            proc = eConsoleAppContainer()
            self.process = proc
            self.backend = "http-%s" % kind

            def _closed(retval):
                # Keep the final file, but clear the running process state.
                self.process = None
                if int(retval or 0) != 0 and self._file_size() <= 0:
                    self.last_error = "%s recording stopped with code %s" % (kind, retval)

            try:
                proc.appClosed.append(_closed)
            except Exception:
                try:
                    proc.appClosed.get().append(_closed)
                except Exception:
                    pass
            result = proc.execute(command)
            if result not in (0, None, True):
                self.process = None
                self.backend = ""
                return False, "%s could not start (code %s)." % (kind, result)
            return True, self.output
        except Exception as exc:
            self.process = None
            self.backend = ""
            return False, "HTTP recording fallback failed: %s" % exc

    def start(self, url, channel_name, session=None, service_ref=None):
        if self.is_recording():
            return False, "A recording is already running."
        if session is None or service_ref is None:
            return False, "Enigma2 4097 recording service is unavailable."

        folder = _settings().get("path", "/media/hdd/movie")
        if not folder or folder.startswith("/tmp"):
            return False, "Recording to /tmp is not allowed. Choose HDD or USB."
        try:
            if not os.path.isdir(folder):
                os.makedirs(folder)
            if not os.access(folder, os.W_OK):
                raise IOError("not writable")
        except Exception:
            return False, "Recording folder is not writable: %s" % folder

        title = _safe_name(channel_name)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        self.output = os.path.join(folder, "%s-%s.ts" % (title, stamp))
        self.channel = title
        self.started_at = int(time.time())
        self.last_error = ""
        self._last_size = 0

        nav = getattr(session, "nav", None)
        native_error = ""
        if nav is not None and hasattr(nav, "recordService"):
            try:
                recorder = nav.recordService(service_ref)
                if recorder is not None:
                    if self._prepare_native(recorder, self.output, title):
                        result = recorder.start()
                        if result in (0, None, True):
                            self.record_service = recorder
                            self.nav = nav
                            self.backend = "enigma2-4097"
                            return True, self.output
                        native_error = "Native recorder start returned %s" % result
                    else:
                        native_error = self.last_error
                    try:
                        nav.stopRecordService(recorder)
                    except Exception:
                        pass
                else:
                    native_error = "Enigma2 refused the 4097 recording service."
            except Exception as exc:
                native_error = "Native 4097 recording failed: %s" % exc
        else:
            native_error = "Native Enigma2 recorder is unavailable."

        # Native failed: activate only one fallback backend.
        ok, message = self._start_http_fallback(url)
        if ok:
            self.last_error = native_error
            return True, message
        error = native_error
        if message:
            error = "%s\n%s" % (error, message) if error else message
        self._reset(keep_output=True)
        return False, error

    def verify(self, minimum_bytes=1880):
        size = self._file_size()
        if size >= int(minimum_bytes):
            # Require growth across checks when possible, preventing a stale or
            # immediately stopped file from being reported as active.
            if self._last_size and size <= self._last_size and not self.is_recording():
                return False, self.last_error or "recording stopped before writing more data"
            self._last_size = size
            return True, self.output
        if not self.is_recording():
            return False, self.last_error or "recording service stopped before writing data"
        self._last_size = size
        return False, "Recording has not written data yet."

    def stop(self):
        output = self.output
        recorder = self.record_service
        nav = self.nav
        proc = self.process

        self.record_service = None
        self.nav = None
        self.process = None
        self.backend = ""
        self.started_at = 0

        if recorder is not None:
            try:
                if nav is not None and hasattr(nav, "stopRecordService"):
                    nav.stopRecordService(recorder)
                else:
                    recorder.stop()
            except Exception as exc:
                self.last_error = str(exc)
                return False, "Could not stop native recording: %s" % exc
            return True, output

        if proc is not None:
            stopped = False
            for name in ("sendCtrlC", "kill"):
                try:
                    method = getattr(proc, name, None)
                    if method is not None:
                        method()
                        stopped = True
                        break
                except Exception:
                    pass
            if not stopped:
                return False, "Could not stop HTTP recording process."
            return True, output

        if output and self._file_size() > 0:
            return True, output
        return False, self.last_error or "No recording is running."


# Keep Xtream and Stalker recording state fully isolated.
# This prevents a failed/finished Stalker backend from changing the Xtream
# recording state, output path, verification timer, or stop operation.
live_recorder = LiveRecordingManager()
stalker_live_recorder = LiveRecordingManager()
