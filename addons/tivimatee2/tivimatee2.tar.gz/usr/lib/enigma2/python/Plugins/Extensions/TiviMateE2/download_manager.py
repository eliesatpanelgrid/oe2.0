# -*- coding: utf-8 -*-
import os, re, json, time, threading, urllib.request, urllib.error, urllib.parse
from collections import OrderedDict

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from enigma import eTimer, ePicLoad
from .artwork_queue import request_artwork
from .resource_guard import ensure_download_capacity, download_reserve_bytes, DOWNLOAD_RECHECK_BYTES

ROOT="/media/hdd/TiviMateE2/Downloads"
STATE_FILE=os.path.join(ROOT,"downloads.json")

def _hdd_ready():
    try:
        real=os.path.realpath("/media/hdd")
        if not os.path.isdir(real): return False
        return os.path.ismount("/media/hdd") or os.stat(real).st_dev != os.stat("/").st_dev
    except Exception:
        return False

def _mkdir(path):
    if not _hdd_ready(): return False
    try:
        os.makedirs(path,exist_ok=True)
        test=os.path.join(path,".tivimate_write_test")
        with open(test,"w") as f:f.write("ok")
        os.unlink(test)
        return True
    except Exception:return False

def _clean(text,fallback="download"):
    text=str(text or "").strip()
    text=re.sub(r'[\\/:*?"<>|\x00-\x1f]+','_',text)
    text=re.sub(r'\s+',' ',text).strip(' ._')
    return (text or fallback)[:140]

def _atomic_json(path,data):
    if not _mkdir(os.path.dirname(path)): raise OSError("Download HDD is unavailable")
    tmp="%s.tmp.%d.%d"%(path,os.getpid(),threading.get_ident())
    with open(tmp,"w") as f:
        json.dump(data,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)

def _bytes_text(value):
    try:value=int(value or 0)
    except Exception:value=0
    if value>=1024**3:return "%.2f GB"%(float(value)/(1024**3))
    if value>=1024**2:return "%.1f MB"%(float(value)/(1024**2))
    if value>=1024:return "%.1f KB"%(float(value)/1024)
    return "%d B"%value

def _job_for(url,item):
    item=dict(item or {})
    kind="episode" if item.get("_kind")=="episode" or item.get("_tmdb_kind")=="series" else "movie"
    if kind=="episode":
        series=_clean(item.get("series_name") or item.get("_series_title") or item.get("_tmdb_title") or "Series")
        sn=item.get("_subdl_season") or item.get("season") or item.get("season_number") or 1
        ep=item.get("_subdl_episode") or item.get("episode_num") or item.get("episode_number") or 1
        try:sn=int(str(sn).split(":")[-1])
        except Exception:sn=1
        try:ep=int(str(ep).split(":")[-1])
        except Exception:ep=1
        title="%s - S%02dE%02d"%(series,sn,ep)
        final=os.path.join(ROOT,"Series",series,"Season %02d"%sn,title+".ts")
        ident=str(item.get("id") or item.get("episode_id") or "%s-%s-%s"%(series,sn,ep))
        jid="episode:"+re.sub(r"\W+","_",ident)[:90]
    else:
        title=_clean(item.get("name") or item.get("title") or "Movie")
        final=os.path.join(ROOT,"Movies",title+".ts")
        ident=str(item.get("id") or item.get("stream_id") or item.get("vod_id") or title)
        jid="movie:"+re.sub(r"\W+","_",ident)[:90]
    poster = (
        item.get("_player_cover") or item.get("stream_icon") or item.get("cover_big") or
        item.get("cover") or item.get("movie_image") or item.get("poster_url") or item.get("poster_path") or ""
    )
    year = item.get("year") or item.get("releaseDate") or item.get("releasedate") or ""
    rating = item.get("rating") or item.get("vote_average") or ""
    return {"id":jid,"kind":kind,"title":title,"path":final,"url":str(url or ""),
            "poster":str(poster or ""),"year":str(year or ""),"rating":str(rating or ""),
            "status":"queued","downloaded":0,"total":0,"created":int(time.time()),"error":""}

class DownloadManager(object):
    def __init__(self):
        self.lock=threading.RLock();self.jobs=OrderedDict();self._wake=threading.Event()
        self._stop=threading.Event();self._active_response=None;self.worker=None;self._load()
    def _load(self):
        if not _hdd_ready():return
        try:
            with open(STATE_FILE,"r") as f:rows=json.load(f)
            for row in rows if isinstance(rows,list) else []:
                if row.get("status") in ("downloading","resolving"):row["status"]="paused"
                self.jobs[str(row.get("id"))]=row
        except Exception:pass
    def _save(self):
        _atomic_json(STATE_FILE,list(self.jobs.values()))
    def snapshot(self):
        with self.lock:return [dict(x) for x in self.jobs.values()]
    def add(self,url,item=None):
        if not _hdd_ready():return(False,"Download HDD is unavailable")
        if not _mkdir(ROOT):return(False,"Download HDD is unavailable")
        job=_job_for(url,item)
        jid=job["id"]
        with self.lock:
            old=self.jobs.get(jid)
            if old and old.get("status") in ("queued","downloading","completed","done"):
                return(False,"Already downloaded" if old.get("status") in ("completed","done") else "Already queued")
            self.jobs[jid]=job
            try:self._save()
            except Exception as exc:
                self.jobs.pop(jid,None);return(False,"Download HDD is unavailable: %s"%exc)
            self._ensure_worker();self._wake.set()
        return(True,"Added to downloads")
    def _ensure_worker(self):
        if self.worker is not None and self.worker.is_alive():return
        self.worker=threading.Thread(target=self._loop,name="TiviMateDownloadManager")
        self.worker.daemon=True;self.worker.start()
    def _next(self):
        with self.lock:
            for jid,row in self.jobs.items():
                if row.get("status") in ("queued","paused") and not row.get("cancel"):
                    row["status"]="resolving";self._save();return jid,row
        return None,None
    def _loop(self):
        if not _mkdir(ROOT):return
        while not self._stop.is_set():
            jid,row=self._next()
            if not row:self._wake.wait(1.0);self._wake.clear();continue
            try:self._download(jid,row)
            except Exception as exc:
                with self.lock:
                    live=self.jobs.get(jid)
                    if live:live["status"]="failed";live["error"]=str(exc)[:220];self._save()
    @staticmethod
    def _content_range_total(headers):
        value=str((headers or {}).get("Content-Range") or "")
        m=re.search(r'\*/(\d+)$',value) or re.search(r'bytes\s+\d+-\d+/(\d+)$',value,re.I)
        return int(m.group(1)) if m else 0
    def _download(self,jid,row):
        url=str(row.get("url") or "").strip()
        if urllib.parse.urlsplit(url).scheme.lower() not in ("http","https"):
            raise RuntimeError("Downloads support HTTP/HTTPS streams only")
        final=os.path.abspath(row.get("path") or "")
        if not final.startswith(os.path.abspath(ROOT)+os.sep):raise RuntimeError("Invalid download path")
        part=final+".part"
        if not _mkdir(os.path.dirname(final)):raise RuntimeError("Download HDD is unavailable")
        reserve = download_reserve_bytes()
        existing=os.path.getsize(part) if os.path.isfile(part) else 0
        # Keep a receiver safety reserve before opening a potentially long VOD write.
        ensure_download_capacity(os.path.dirname(final), 0, reserve)
        response=None
        for attempt in range(2):
            headers={"User-Agent":"Mozilla/5.0 (TiviMateE2/1.0.10)","Accept":"*/*","Connection":"close"}
            if existing>0:headers["Range"]="bytes=%d-"%existing
            try:
                response=urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=18);break
            except urllib.error.HTTPError as exc:
                if exc.code==416 and existing>0:
                    remote=self._content_range_total(getattr(exc,"headers",{}))
                    if remote and remote==existing:
                        os.replace(part,final)
                        with self.lock:
                            live=self.jobs[jid];live["status"]="completed";live["downloaded"]=existing;live["total"]=existing;self._save()
                        return
                    try:os.unlink(part)
                    except OSError:pass
                    existing=0
                    if attempt==0:continue
                raise
        if response is None:raise RuntimeError("Could not open download stream")
        self._active_response=response
        try:
            code=getattr(response,"status",None) or response.getcode()
            if existing and int(code or 0)==200:existing=0
            mode="ab" if existing and int(code or 0)==206 else "wb"
            clen=int(response.headers.get("Content-Length") or 0)
            total=existing+clen if clen else 0
            # If Content-Length is known, reject the job before writing when the
            # remaining payload would consume the receiver safety reserve.
            remaining = max(0, total - existing) if total else 0
            ensure_download_capacity(os.path.dirname(final), remaining, reserve)
            with self.lock:
                live=self.jobs[jid];live["status"]="downloading";live["downloaded"]=existing;live["total"]=total;live["error"]="";self._save()
            last=time.time();downloaded=existing
            capacity_checkpoint=downloaded
            with open(part,mode) as out:
                while not self._stop.is_set():
                    with self.lock:
                        if self.jobs[jid].get("cancel"):
                            self.jobs[jid]["status"]="cancelled";self._save();return
                    chunk=response.read(256*1024)
                    if not chunk:break
                    out.write(chunk);downloaded+=len(chunk)
                    if downloaded-capacity_checkpoint>=DOWNLOAD_RECHECK_BYTES:
                        # Unknown-length streams are checked incrementally as well.
                        ensure_download_capacity(os.path.dirname(final), 0, reserve)
                        capacity_checkpoint=downloaded
                    if time.time()-last>=1:
                        with self.lock:
                            self.jobs[jid]["downloaded"]=downloaded;self.jobs[jid]["total"]=total;self._save()
                        last=time.time()
                out.flush();os.fsync(out.fileno())
            if downloaded<=0:raise RuntimeError("Empty download")
            if total and downloaded<total:raise RuntimeError("Incomplete download")
            os.replace(part,final)
            with self.lock:
                live=self.jobs[jid];live["status"]="completed";live["downloaded"]=downloaded;live["total"]=total or downloaded;live["error"]="";self._save()
        finally:
            self._active_response=None
            try:response.close()
            except Exception:pass
    def cancel(self,jid):
        with self.lock:
            row=self.jobs.get(str(jid))
            if not row:return False
            row["cancel"]=True
            if row.get("status") in ("queued","paused","resolving"):row["status"]="cancelled"
            self._save();self._wake.set();return True
    def retry(self,jid):
        with self.lock:
            row=self.jobs.get(str(jid))
            if not row:return False
            row["status"]="queued";row["cancel"]=False;row["error"]="";self._save()
            self._ensure_worker();self._wake.set();return True
    def remove_finished(self):
        with self.lock:
            self.jobs=OrderedDict((k,v) for k,v in self.jobs.items() if v.get("status") not in ("completed","done","failed","cancelled"))
            self._save()

MANAGER=DownloadManager()

DOWNLOADS_SKIN="""<screen name="TiviMateDownloadsManager" position="160,90" size="1600,900" backgroundColor="#0D141C" flags="wfNoBorder">
<eLabel position="0,0" size="1600,92" backgroundColor="#17232F"/>
<widget name="title" position="46,18" size="940,54" font="Regular;38" foregroundColor="#FFFFFF" transparent="1"/>
<widget name="folder" position="46,96" size="1508,38" font="Regular;20" foregroundColor="#7EDBFF" transparent="1"/>

<eLabel position="38,146" size="960,650" backgroundColor="#121C26"/>
<widget name="list" position="58,168" size="920,606" font="Regular;25" itemHeight="58" scrollbarMode="showOnDemand"/>

<eLabel position="1024,146" size="538,650" backgroundColor="#101922"/>
<widget name="poster" position="1052,172" size="220,330" alphatest="blend"/>
<widget name="itemTitle" position="1294,174" size="240,86" font="Regular;28" foregroundColor="#FFFFFF" transparent="1" valign="top"/>
<widget name="itemMeta" position="1294,270" size="240,40" font="Regular;21" foregroundColor="#8FE7FF" transparent="1"/>
<widget name="itemStatus" position="1294,326" size="240,54" font="Regular;23" foregroundColor="#FFD58A" transparent="1"/>
<widget name="itemProgress" position="1294,392" size="240,74" font="Regular;21" foregroundColor="#D7E4EE" transparent="1"/>
<widget name="detail" position="1052,528" size="482,178" font="Regular;20" foregroundColor="#B8C9D8" transparent="1" valign="top"/>

<widget name="keys" position="46,822" size="1508,50" font="Regular;22" foregroundColor="#C7D3DF" transparent="1" halign="center"/>
</screen>"""

class DownloadsManagerScreen(Screen):
    skin=DOWNLOADS_SKIN
    def __init__(self,session):
        Screen.__init__(self,session)
        self["title"]=Label("Downloads")
        self["folder"]=Label("HDD  •  "+ROOT)
        self["list"]=MenuList([])
        self["poster"]=Pixmap()
        self["itemTitle"]=Label("")
        self["itemMeta"]=Label("")
        self["itemStatus"]=Label("")
        self["itemProgress"]=Label("")
        self["detail"]=Label("")
        self["keys"]=Label("RED Cancel   GREEN Retry / Refresh   BLUE Clear Finished   LEFT / EXIT Back")
        self["actions"]=ActionMap(["OkCancelActions","ColorActions","DirectionActions"],{
            "cancel":self.close,"left":self.close,"red":self.cancelCurrent,"green":self.greenAction,
            "blue":self.clearFinished,"up":self.up,"down":self.down},-1)

        self._rows=[]
        self._posterToken=""
        self._posterPic=ePicLoad()
        try:self._posterPic.PictureData.get().append(self._posterDecoded)
        except Exception:
            try:self._posterPicConn=self._posterPic.PictureData.connect(self._posterDecoded)
            except Exception:self._posterPicConn=None

        self._timer=eTimer()
        try:self._timer.timeout.connect(self.refresh)
        except Exception:self._timer.callback.append(self.refresh)
        self.onLayoutFinish.append(self._prepare)
        self.onClose.append(self._stop)

    def _prepare(self):
        if not _mkdir(ROOT):
            self.session.open(MessageBox,"Real /media/hdd is not mounted or writable.",MessageBox.TYPE_ERROR,timeout=6)
        try:
            self["poster"].hide()
        except Exception:pass
        try:
            self["list"].onSelectionChanged.append(self._updateDetail)
        except Exception:pass
        self.refresh()

    def _stop(self):
        try:self._timer.stop()
        except Exception:pass
        self._posterToken=""

    def refresh(self):
        try:old_index=self["list"].getSelectedIndex()
        except Exception:old_index=0
        rows=MANAGER.snapshot()
        self._rows=rows
        labels=[]
        for row in rows:
            status=str(row.get("status") or "").upper()
            done=int(row.get("downloaded") or 0);total=int(row.get("total") or 0)
            pct=int(done*100/total) if total else 0
            marker="✓" if status in ("COMPLETED","DONE") else ("↓" if status in ("DOWNLOADING","RESOLVING") else "•")
            labels.append("%s  %-11s  %3d%%   %s"%(marker,status,pct,row.get("title") or "Video"))
        self["list"].setList(labels or ["No downloads yet"])
        if rows:
            try:
                self["list"].moveToIndex(max(0,min(old_index,len(rows)-1)))
            except Exception:pass
        self._updateDetail()
        try:self._timer.start(1500,True)
        except Exception:pass

    def _currentRow(self):
        if not getattr(self,"_rows",None):return None
        try:idx=self["list"].getSelectedIndex()
        except Exception:idx=0
        return self._rows[idx] if 0<=idx<len(self._rows) else None

    def _loadPoster(self,row):
        url=str((row or {}).get("poster") or "").strip()
        token=str((row or {}).get("id") or "")+"|"+url
        if token==self._posterToken:return
        self._posterToken=token
        try:self["poster"].hide()
        except Exception:pass
        if not url:return

        def ready(path, expected=token):
            if expected!=self._posterToken or not path or not os.path.exists(path):return
            try:
                self._posterPic.setPara((220,330,1,1,False,1,"#00000000"))
                self._posterPic.startDecode(path)
            except Exception:pass
        try:request_artwork(url,"posters",ready,priority=70)
        except Exception:pass

    def _posterDecoded(self,info=None):
        try:
            ptr=self._posterPic.getData()
            if ptr is None:return
            self["poster"].instance.setPixmap(ptr)
            self["poster"].show()
        except Exception:pass

    def _updateDetail(self):
        row=self._currentRow()
        if not row:
            self["itemTitle"].setText("")
            self["itemMeta"].setText("")
            self["itemStatus"].setText("")
            self["itemProgress"].setText("")
            self["detail"].setText("")
            try:self["poster"].hide()
            except Exception:pass
            return

        title=str(row.get("title") or "Video")
        status=str(row.get("status") or "").upper()
        done=int(row.get("downloaded") or 0);total=int(row.get("total") or 0)
        pct=int(done*100/total) if total else 0
        meta=[]
        if row.get("kind"):meta.append(str(row.get("kind")).upper())
        if row.get("year"):meta.append(str(row.get("year")))
        if row.get("rating"):meta.append("★ "+str(row.get("rating")))
        self["itemTitle"].setText(title)
        self["itemMeta"].setText("  •  ".join(meta))
        self["itemStatus"].setText(status)
        if total:
            self["itemProgress"].setText("%d%%\n%s / %s"%(pct,_bytes_text(done),_bytes_text(total)))
        else:
            self["itemProgress"].setText("%s downloaded"%_bytes_text(done))
        detail=("Error: "+str(row.get("error"))) if row.get("error") else str(row.get("path") or "")
        self["detail"].setText(detail)
        self._loadPoster(row)

    def up(self):
        try:self["list"].up()
        except Exception:pass
        self._updateDetail()

    def down(self):
        try:self["list"].down()
        except Exception:pass
        self._updateDetail()

    def cancelCurrent(self):
        row=self._currentRow()
        if row:MANAGER.cancel(row.get("id"))
        self.refresh()

    def greenAction(self):
        row=self._currentRow()
        if row and row.get("status") in ("failed","cancelled","paused"):MANAGER.retry(row.get("id"))
        self.refresh()

    def clearFinished(self):
        MANAGER.remove_finished()
        self.refresh()

