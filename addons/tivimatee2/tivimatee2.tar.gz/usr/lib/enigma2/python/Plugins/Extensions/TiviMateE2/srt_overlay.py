# -*- coding: utf-8 -*-
"""Small, receiver-safe SRT reader used by TiviMateE2's VOD player.

This module intentionally has no dependency on Enigma2 subtitle-track APIs.
It only turns a local SRT file into timed text cues; the player owns drawing
and synchronization against the current service PTS.
"""
from __future__ import unicode_literals

import re

_TAG_RE = re.compile(r"<[^>]*>|\{\\[^}]*\}")
_TIME_RE = re.compile(
    r"^\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*"
    r"(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})"
)


def _millis(hour, minute, second, millis):
    value = str(millis or "0").ljust(3, "0")[:3]
    return (((int(hour) * 60 + int(minute)) * 60 + int(second)) * 1000) + int(value)


def _decode(raw):
    if isinstance(raw, str):
        return raw
    raw = raw or b""
    for encoding in ("utf-8-sig", "utf-8", "cp1256", "cp1252", "iso-8859-6"):
        try:
            return raw.decode(encoding)
        except Exception:
            pass
    return raw.decode("utf-8", "replace")


def parse_srt_file(path):
    """Return sorted ``(start_ms, end_ms, text)`` SRT cues from a local file."""
    with open(path, "rb") as handle:
        content = _decode(handle.read())
    content = content.replace("\r\n", "\n").replace("\r", "\n")
    cues = []
    for block in re.split(r"\n{2,}", content):
        lines = [line.strip() for line in block.split("\n")]
        while lines and not lines[0]:
            lines.pop(0)
        if lines and lines[0].isdigit():
            lines.pop(0)
        if not lines:
            continue
        match = _TIME_RE.match(lines[0])
        if not match:
            continue
        start = _millis(*match.groups()[:4])
        end = _millis(*match.groups()[4:])
        if end <= start:
            continue
        body = "\n".join(line for line in lines[1:] if line).strip()
        body = _TAG_RE.sub("", body).strip()
        if body:
            cues.append((start, end, body))
    cues.sort(key=lambda cue: (cue[0], cue[1]))
    return cues
