# -*- coding: utf-8 -*-
"""Small persistent TMDb/server rating cache for server-backed recommendation rails.

The hot path never performs network I/O.  Missing ratings can be enriched by a
background worker and become available on the next repaint/open.
"""
import os, json, time, re, threading
from .storage import data_path
from .tmdb_client import TMDbClient

_CACHE_FILE = data_path("you_might_like_ratings.json")
_LOCK = threading.Lock()
_MAX_AGE = 90 * 24 * 3600


def _load():
    try:
        with _LOCK:
            with open(_CACHE_FILE, "r") as h:
                data = json.load(h) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save(data):
    try:
        folder = os.path.dirname(_CACHE_FILE)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = _CACHE_FILE + ".tmp"
        with _LOCK:
            with open(tmp, "w") as h:
                json.dump(data, h, separators=(",", ":"), sort_keys=True)
            try:
                os.replace(tmp, _CACHE_FILE)
            except Exception:
                os.rename(tmp, _CACHE_FILE)
        return True
    except Exception:
        return False


def _title(item):
    return str((item or {}).get("name") or (item or {}).get("title") or
               (item or {}).get("original_title") or (item or {}).get("original_name") or "").strip()


def _year(item):
    raw = " ".join(str((item or {}).get(k) or "") for k in
                   ("year", "releaseDate", "releasedate", "release_date", "first_air_date", "name", "title"))
    m = re.search(r"\b(?:19|20)\d{2}\b", raw)
    return m.group(0) if m else ""


def _key(item, kind):
    title = re.sub(r"\s+", " ", _title(item).lower()).strip()
    return "%s|%s|%s" % (str(kind or "vod"), title, _year(item))


def normalize_rating(item):
    """Return a 0..10 score from server/TMDb fields, or 0 when unknown."""
    item = item or {}
    # Explicit 5-point field first.
    raw5 = item.get("rating_5based")
    if raw5 not in (None, ""):
        try:
            v = float(str(raw5).replace(",", "."))
            if 0 < v <= 5:
                return min(10.0, v * 2.0)
        except Exception:
            pass
    for key in ("vote_average", "rating", "rating_imdb", "imdb_rating", "score"):
        raw = item.get(key)
        if raw in (None, ""):
            continue
        try:
            v = float(str(raw).replace(",", ".").replace("/10", "").strip())
            if v > 10.0 and v <= 100.0:
                v = v / 10.0
            if 0 < v <= 10.0:
                return v
        except Exception:
            continue
    return 0.0


def cached_rating(item, kind):
    direct = normalize_rating(item)
    if direct > 0:
        return direct
    row = _load().get(_key(item, kind)) or {}
    if not isinstance(row, dict):
        return 0.0
    try:
        if int(time.time()) - int(row.get("updated") or 0) > _MAX_AGE:
            return 0.0
        v = float(row.get("rating") or 0.0)
        return v if 0 < v <= 10.0 else 0.0
    except Exception:
        return 0.0


def put_rating(item, kind, rating):
    try:
        rating = float(rating or 0.0)
    except Exception:
        return False
    if rating <= 0 or rating > 10:
        return False
    data = _load()
    data[_key(item, kind)] = {"rating": rating, "updated": int(time.time())}
    return _save(data)


def split_ranked(items, kind, minimum=6.0):
    """Hot path: no network. Returns (qualified_sorted, unknown)."""
    qualified = []
    unknown = []
    for raw in list(items or []):
        if not isinstance(raw, dict):
            continue
        row = dict(raw)
        score = cached_rating(row, kind)
        if score >= float(minimum):
            row["rating"] = "%.1f" % score
            row["_ym_rating"] = score
            qualified.append(row)
        elif score <= 0:
            unknown.append(row)
    qualified.sort(key=lambda x: float(x.get("_ym_rating") or 0.0), reverse=True)
    return qualified, unknown


def enrich_missing(items, kind, minimum=6.0, limit=24):
    """Background-only helper. Resolve missing ratings via TMDb and rank >= minimum."""
    client = TMDbClient()
    enriched = []
    seen = set()
    for raw in list(items or [])[:int(limit or 24)]:
        if not isinstance(raw, dict):
            continue
        row = dict(raw)
        key = _key(row, kind)
        if key in seen:
            continue
        seen.add(key)
        score = cached_rating(row, kind)
        if score <= 0:
            title = _title(row)
            if not title:
                continue
            try:
                found = client.search_artwork(title, kind=kind, year=_year(row) or None) or {}
                score = normalize_rating(found)
                if score > 0:
                    put_rating(row, kind, score)
            except Exception:
                score = 0.0
        if score >= float(minimum):
            row["rating"] = "%.1f" % score
            row["_ym_rating"] = score
            enriched.append(row)
    enriched.sort(key=lambda x: float(x.get("_ym_rating") or 0.0), reverse=True)
    return enriched
