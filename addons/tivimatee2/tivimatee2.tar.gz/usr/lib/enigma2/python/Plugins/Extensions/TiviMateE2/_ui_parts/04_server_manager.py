class ServerManager(Screen):
    skin = SERVER_MANAGER_SKIN
    NAV_X = [450, 603, 756, 909, 1062, 1215]

    def __init__(self, session, selectCallback=None):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        self["settingsSideTitle"].setText(tr("SERVERS & WEB"))
        self["settingsSideText"].setText(tr("Manage IPTV servers,\nStalker / Xtream and\nmobile Web Control."))
        self["settingsSideHint"].setText(tr("Press 4 WEB QR\nPress 7 BACKUP & RESTORE\nPress 8 SETTINGS (NEW)"))
        self.selectCallback = selectCallback
        self.sources = []
        self._serverStates = {}
        self._serverExpiries = {}
        self._statusResult = None
        self._statusToken = 0
        self._statusClosed = False
        self.settingsFocus = "list"
        self.settingsNavIndex = 5
        self.languageIndex = {"en": 0, "ar": 1, "fr": 2}.get(get_language(), 0)
        self["title"] = Label(tr("SETTINGS  •  SERVER MANAGER"))
        self["config"] = ServerStatusList()
        self["languageTitle"] = Label(tr("APPLICATION LANGUAGE"))
        self["languageSelector"] = Pixmap()
        self["language0"] = Label(tr("English"))
        self["language1"] = Label(tr("Arabic"))
        self["language2"] = Label(tr("French"))
        self["languageRadio0"] = Pixmap()
        self["languageRadio1"] = Pixmap()
        self["languageRadio2"] = Pixmap()
        self["serverStatusTitle"] = Label(tr("SERVER STATUS  •  CONNECTION & ACTIVE USE"))
        self["serverStatusText"] = Label(tr("Yellow appears only when the server reports active use."))
        self["statusLegendOnlineIcon"] = Pixmap()
        self["statusLegendOnline"] = Label(tr("ONLINE"))
        self["statusLegendCheckingIcon"] = Pixmap()
        self["statusLegendChecking"] = Label(tr("IN USE"))
        self["statusLegendOfflineIcon"] = Pixmap()
        self["statusLegendOffline"] = Label(tr("OFFLINE"))
        self["hint"] = Label(tr("BLUE  CHOOSE SERVER & FILTER   •   0  TEST SERVER   •   4 WEB QR   •   8 SETTINGS"))
        self["settingsNewButton"] = Label("SETTINGS (NEW)  ▶")
        self["keys"] = Label("")
        self._statusTimer = eTimer()
        _connect_timer(self._statusTimer, self._finishStatusRefresh)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "NumberActions"], {
            "ok": self.ok, "cancel": self.close, "green": self.addSource,
            "yellow": self.editSource, "red": self.delSource, "blue": self.openFilter,
            "menu": self.openTMDb, "0": self.testSource, "1": self.openCacheSettings, "2": self.openAppearanceSettings, "3": self.openUpdateSettings, "4": self.openWebAccess, "5": self.openSubDLSettingsMenu, "6": self.openAppearanceSettings, "7": self.openBackupRestore, "8": self.openSettingsDashboard,
            "up": self.up, "down": self.down, "left": self.left, "right": self.right
        }, -1)
        self.onLayoutFinish.append(self._settingsLayoutReady)
        self.onLayoutFinish.append(self._startStatusRefresh)
        self.onClose.append(self._stopStatusRefresh)
        self.reload()

    def _settingsLayoutReady(self):
        self._statusReady = True
        try:
            self["settingsGuide"].hide()
        except Exception:
            pass
        try:
            self["settingsActionButtons"].show()
        except Exception:
            pass
        self._updateSettingsFocus()

    def _updateSettingsFocus(self):
        try:
            if self["settingsNavSelector"].instance:
                self["settingsNavSelector"].instance.move(ePoint(sx(self.NAV_X[self.settingsNavIndex]), sy(27)))
            self["settingsNavSelector"].show() if self.settingsFocus == "nav" else self["settingsNavSelector"].hide()
        except Exception:
            pass
        try:
            self["settingsNewButton"].setText(
                u"▶  SETTINGS (NEW)  ◀" if self.settingsFocus == "newsettings"
                else u"SETTINGS (NEW)  ▶"
            )
            self["settingsNewButton"].instance.setForegroundColor(
                parseColor("#FFFFFF" if self.settingsFocus == "newsettings" else "#F1C84C")
            )
        except Exception:
            pass
        try:
            if self["languageSelector"].instance:
                self["languageSelector"].instance.move(ePoint(sx(124), sy(492 + (self.languageIndex * 64))))
            self["languageSelector"].show() if self.settingsFocus == "language" else self["languageSelector"].hide()
            radio_on = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/settings/language_radio_on.png"))
            radio_off = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/settings/language_radio_off_r64.png"))
            for i in range(3):
                widget = self["languageRadio%d" % i]
                if widget.instance:
                    widget.instance.setPixmap(radio_on if i == self.languageIndex else radio_off)
        except Exception:
            pass

    def up(self):
        if self.settingsFocus == "newsettings":
            self.settingsFocus = "language"
            self.languageIndex = 2
        elif self.settingsFocus == "language":
            self.languageIndex = (self.languageIndex - 1) % 3
        elif self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex - 1) % len(self.NAV_X)
        else:
            try:
                at_top = self["config"].getSelectedIndex() <= 0
            except Exception:
                at_top = True
            if at_top:
                self.settingsFocus = "nav"
            else:
                self["config"].up()
        self._updateSettingsFocus()

    def down(self):
        if self.settingsFocus == "newsettings":
            self.settingsFocus = "language"
            self.languageIndex = 0
        elif self.settingsFocus == "language":
            if self.languageIndex >= 2:
                self.settingsFocus = "newsettings"
            else:
                self.languageIndex += 1
        elif self.settingsFocus == "nav":
            self.settingsFocus = "list"
        else:
            self["config"].down()
        self._updateSettingsFocus()

    def left(self):
        if self.settingsFocus == "list":
            self.settingsFocus = "language"
        elif self.settingsFocus == "language":
            self.settingsFocus = "newsettings"
        elif self.settingsFocus == "newsettings":
            self.settingsFocus = "language"
        elif self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex - 1) % len(self.NAV_X)
        self._updateSettingsFocus()

    def right(self):
        if self.settingsFocus == "newsettings":
            self.settingsFocus = "language"
        elif self.settingsFocus == "language":
            self.settingsFocus = "list"
        elif self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex + 1) % len(self.NAV_X)
        self._updateSettingsFocus()

    def ok(self):
        if self.settingsFocus == "newsettings":
            self.openSettingsDashboard(); return
        if self.settingsFocus == "language":
            code = ("en", "ar", "fr")[self.languageIndex]
            if save_language(code):
                self.session.open(MessageBox, tr("Language saved. Reopen the app to apply it."), MessageBox.TYPE_INFO, timeout=5); return
            self.session.open(MessageBox, tr("Unable to save settings."), MessageBox.TYPE_ERROR); return
        if self.settingsFocus == "nav":
            self.openTopMenu(); return
        self.select(); return

    def openTopMenu(self):
        index = self.settingsNavIndex
        if index == 5:
            self.settingsFocus = "list"
            self._updateSettingsFocus(); return
        source = self.current()
        if index == 1:
            self.session.open(TiviMateE2Home); return
        if not source:
            self.session.open(MessageBox, "Select a server first.", MessageBox.TYPE_INFO); return
        if index == 0:
            self.session.open(TiviMateE2Search, source); return
        if index == 2 and source.get("type") in ("xtream", "stalker", "m3u", "fg"):
            self.session.open(MediaScreen, source, "live"); return
        if index == 3 and source.get("type") in ("xtream", "stalker"):
            self.session.open(ContentHomeScreen, source, "vod"); return
        if index == 4 and source.get("type") in ("xtream", "stalker"):
            self.session.open(ContentHomeScreen, source, "series"); return
        self.session.open(MessageBox, "The selected source does not provide this section.", MessageBox.TYPE_INFO); return

    def openTMDb(self):
        self.session.open(TMDbSettings)

    def openCacheSettings(self):
        self.session.open(ImageCacheSettings)

    def openAppearanceSettings(self):
        self.session.open(HomeAppearanceSettings)

    def openUpdateSettings(self):
        self.session.open(UpdateSettingsScreen)

    def openWebAccess(self):
        self.session.open(WebAccessScreen)

    def openBackupRestore(self):
        self.session.open(BackupRestoreScreen)

    def openSettingsDashboard(self):
        self.session.open(SettingsDashboard)

    def openSubDLSubtitleLanguage(self):
        self.session.open(SubDLSubtitleLanguageSettings)

    def openServerSubtitleFont(self):
        """Change Enigma2's native/server subtitle font size.

        This writes config.subtitles.subtitle_fontsize, the same receiver-owned
        setting used by InfoBarSubtitleSupport. It does not touch SubsSupport.
        """
        try:
            subtitles = getattr(config, "subtitles", None)
            setting = getattr(subtitles, "subtitle_fontsize", None) if subtitles is not None else None
            if setting is None:
                raise RuntimeError("native subtitle font setting unavailable")

            current = str(getattr(setting, "value", "") or "")
            sizes = []
            try:
                choices = getattr(setting, "choices", None) or []
                for entry in choices:
                    value = entry[0] if isinstance(entry, (tuple, list)) else entry
                    value = str(value)
                    if value.isdigit() and value not in sizes:
                        sizes.append(value)
            except Exception:
                sizes = []
            if not sizes:
                sizes = [str(x) for x in range(16, 50, 2)]

            choices = []
            for value in sizes:
                label = "%s px%s" % (value, "  •  Current" if value == current else "")
                choices.append((label, value))
            self.session.openWithCallback(
                self._serverSubtitleFontSelected,
                ChoiceBox,
                title="SERVER SUBTITLE FONT  •  ENIGMA2",
                list=choices,
            )
        except Exception:
            self.session.open(
                MessageBox,
                "Native Enigma2 subtitle font settings are not available on this image.",
                MessageBox.TYPE_ERROR,
                timeout=6,
            )

    def _serverSubtitleFontSelected(self, choice=None):
        if not choice:
            return
        try:
            value = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
            setting = config.subtitles.subtitle_fontsize
            setting.value = str(value)
            try:
                setting.save()
            except Exception:
                pass
            try:
                configfile.save()
            except Exception:
                pass
            self.session.open(
                MessageBox,
                "Server subtitle font size saved: %s" % value,
                MessageBox.TYPE_INFO,
                timeout=3,
            )
        except Exception:
            self.session.open(
                MessageBox,
                "Could not save the native subtitle font size.",
                MessageBox.TYPE_ERROR,
                timeout=5,
            )

    def openSubDLSubtitleFont(self):
        """Open the external-SRT font configuration owned by SubsSupport."""
        try:
            from Plugins.Extensions.SubsSupport.subtitles import initSubsSettings, SubsSetupExternal
            settings = initSubsSettings()
            external = getattr(settings, "external", None)
            if external is None:
                raise RuntimeError("missing external subtitle settings")
            self.session.open(SubsSetupExternal, external); return
        except ImportError:
            self.session.open(
                MessageBox,
                "Font settings require SubsSupport. Install or update SubsSupport from your receiver plugin feed, then open 5 > Font again.",
                MessageBox.TYPE_INFO,
                timeout=7,
            ); return
        except Exception:
            try:
                from Plugins.Extensions.SubsSupport.plugin import openSubsSupportSettings
                return openSubsSupportSettings(self.session)
            except Exception:
                self.session.open(
                    MessageBox,
                    "Could not open the SubsSupport font settings on this receiver image.",
                    MessageBox.TYPE_ERROR,
                    timeout=7,
                ); return

    def openSubDLSettingsMenu(self):
        """Show the agreed Import, Language and Font actions under settings key 5."""
        current = load_subdl_settings()
        language_code = current.get("language", "ar")
        language_name = dict((code, name) for name, code in SUBDL_LANGUAGE_CHOICES).get(language_code, language_code)
        choices = [
            ("Import SubDL API Key  •  HDD / USB / MMC / etc", "import"),
            ("Subtitle Language  •  %s" % language_name, "language"),
            ("Subtitle Font Size  •  General", "font_unified"),
            ("Subtitle Font Style  •  Advanced", "font_advanced"),
        ]
        self.session.openWithCallback(
            self._subdlSettingsSelected,
            ChoiceBox,
            title="SUBDL SETTINGS  •  IMPORT / LANGUAGE / FONT",
            list=choices,
        )

    def _subdlSettingsSelected(self, choice=None):
        if not choice:
            return
        action = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
        if action == "import":
            return self.importSubDLKey()
        if action == "language":
            return self.openSubDLSubtitleLanguage()
        if action == "font_unified":
            return self.session.open(ImageCacheSettings)
        if action == "font_advanced":
            return self.openSubDLSubtitleFont()

    def importSubDLKey(self):
        """Import the local SubDL key while preserving the chosen language and type."""
        try:
            value = _read_subdl_import_key()
            current = load_subdl_settings()
            save_subdl_settings(
                value,
                current.get("language", "ar"),
                current.get("kind", "standard"),
            )
            removed = _remove_subdl_import_file()
            message = (
                "SubDL key imported and saved locally. Press 5 and choose SubDL Subtitle Language. The temporary file was removed."
                if removed else
                "SubDL key imported and saved locally. Press 5 and choose SubDL Subtitle Language. Remove the imported key file manually to protect your key."
            )
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=6)
        except IOError:
            self.session.open(
                MessageBox,
                "Put one SubDL API key in key.txt on HDD/USB/MMC or /etc/enigma2, then press 5 and choose Import SubDL API Key.",
                MessageBox.TYPE_INFO,
                timeout=7,
            )
        except ValueError:
            self.session.open(
                MessageBox,
                "Invalid SubDL key file. It must contain exactly one SubDL API key.",
                MessageBox.TYPE_ERROR,
                timeout=7,
            )
        except Exception:
            self.session.open(
                MessageBox,
                "Could not import the SubDL key from /tmp/tivimatee2/key.txt.",
                MessageBox.TYPE_ERROR,
                timeout=7,
            )

    def openFilter(self):
        # BLUE always starts by choosing the server. This makes filtering
        # accessible even when focus is on language/nav/new-settings rather
        # than on the server list itself.
        compatible=[]
        current=self.current()
        current_key=self._sourceKey(current) if current else ""
        for source in list(get_sources() or []):
            if not isinstance(source,dict):
                continue
            if str(source.get("type") or "").lower() not in ("xtream","stalker"):
                continue
            name=ServerStatusList._display_name(source)
            stype=str(source.get("type") or "").upper()
            prefix="✓ " if current_key and self._sourceKey(source)==current_key else ""
            compatible.append(("%s%s  [%s]" % (prefix,name,stype),dict(source)))

        if not compatible:
            self.session.open(
                MessageBox,
                "No Xtream or Stalker server is available for filtering.",
                MessageBox.TYPE_INFO,
                timeout=5
            )
            return

        if len(compatible)==1:
            self.session.openWithCallback(
                self._filterClosed,
                ServerCategoryFilter,
                compatible[0][1]
            )
            return

        self.session.openWithCallback(
            self._filterServerSelected,
            ChoiceBox,
            title="SELECT SERVER TO FILTER",
            list=compatible
        )

    def _filterServerSelected(self, choice=None):
        if not choice:
            return
        try:
            source=choice[1]
        except Exception:
            return
        if not isinstance(source,dict):
            return
        self.session.openWithCallback(
            self._filterClosed,
            ServerCategoryFilter,
            source
        )

    def _filterClosed(self, changed=None):
        if not changed:
            return
        # Redraw manager state after filter save; content screens will consume
        # the new allowed-category set on their next load.
        try:
            clear_catalog_memory()
        except Exception:
            pass
        try:
            self.reload()
        except Exception:
            pass

    def _sourceKey(self, source):
        return ServerStatusList._key(source)

    def _displaySources(self):
        """Show only real user servers; SubDL actions live under settings key 5."""
        return list(self.sources)

    def _refreshSourceRows(self):
        """Redraw server status while preserving the selected real server."""
        selected_key = None
        try:
            current = self.current()
            selected_key = self._sourceKey(current) if current else None
        except Exception:
            pass
        display_sources = self._displaySources()
        self["config"].setSources(display_sources, self._serverStates, self._serverExpiries)
        if selected_key:
            for index, source in enumerate(display_sources):
                if self._sourceKey(source) == selected_key:
                    try:
                        self["config"].moveToIndex(index)
                    except Exception:
                        pass
                    break

    def _updateStatusCard(self):
        total = len(self.sources)
        if not total:
            text = "Add a playlist to see connection and active-use status."
        else:
            checking = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source), "checking") == "checking"])
            online = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) == "online"])
            busy = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) == "busy"])
            offline = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) in ("offline", "expired")])
            if checking:
                text = "Checking %d server%s in the background…" % (checking, "" if checking == 1 else "s")
            else:
                text = "%d ready  •  %d in use  •  %d offline  •  BLUE: filter selected server" % (online, busy, offline)
        try:
            self["serverStatusText"].setText(text)
        except Exception:
            pass

    def _connectionTest(self, source):
        """Return privacy-safe server state plus subscription expiry when supplied."""
        try:
            source_type = source.get("type")
            if source_type == "xtream":
                reply = XtreamClient(source).test()
            elif source_type in ("m3u", "fg"):
                reply = M3UClient(source).test()
            else:
                reply = StalkerClient(source).test()
            report = evaluate_reply(source_type, reply)
            expiry = ""
            if source_type == "xtream" and isinstance(reply, dict):
                state, expiry = _xtream_state_from_reply(reply)
                report["state"] = state
            elif source_type == "stalker" and isinstance(reply, dict):
                expiry = reply.get("expiry") or ""
                if _xtream_expiry_is_past(expiry):
                    report["state"] = "expired"
            report["expiry"] = str(expiry or "")
            return report, ""
        except Exception as exc:
            return {"state": "offline", "active_connections": None, "max_connections": None, "usage_reported": False, "expiry": ""}, str(exc)

    def _startStatusRefresh(self):
        if self._statusClosed or self._statusResult is not None:
            return
        self._statusToken += 1
        token = self._statusToken
        sources = [dict(source) for source in self.sources]
        self._serverStates = {self._sourceKey(source): "checking" for source in sources}
        self._refreshSourceRows()
        self._updateStatusCard()
        if not sources:
            return

        def worker():
            states = {}
            expiries = {}
            for source in sources:
                report, _error = self._connectionTest(source)
                key = self._sourceKey(source)
                states[key] = report.get("state", "offline")
                expiries[key] = report.get("expiry") or ""
            self._statusResult = (token, states, expiries)

        thread = threading.Thread(target=worker, name="TiviMateServerStatus")
        thread.daemon = True
        thread.start()
        try:
            self._statusTimer.start(120, False)
        except Exception:
            pass

    def _finishStatusRefresh(self):
        result = self._statusResult
        if not result:
            try:
                self._statusTimer.start(120, False)
            except Exception:
                pass
            return
        self._statusResult = None
        token, states, expiries = result
        if self._statusClosed or token != self._statusToken:
            return
        self._serverStates.update(states)
        self._serverExpiries.update(expiries)
        try:
            changed = False
            for source in self.sources:
                key = self._sourceKey(source)
                if key in states:
                    source["_last_status"] = states.get(key) or "offline"
                    source["_last_status_at"] = int(time.time())
                    new_expiry = str(expiries.get(key) or "").strip()
                    if new_expiry:
                        source["_last_expiry"] = new_expiry
                    changed = True
            if changed:
                set_sources(self.sources)
        except Exception:
            pass
        self._refreshSourceRows()
        self._updateStatusCard()

    def _stopStatusRefresh(self):
        self._statusClosed = True
        self._statusToken += 1
        try:
            self._statusTimer.stop()
        except Exception:
            pass

    def reload(self):
        self.sources = get_sources()
        keys = set([self._sourceKey(source) for source in self.sources])
        self._serverStates = {key: state for key, state in self._serverStates.items() if key in keys}
        self._serverExpiries = {key: value for key, value in self._serverExpiries.items() if key in keys}
        for source in self.sources:
            self._serverStates.setdefault(self._sourceKey(source), "checking")
        self._refreshSourceRows()
        self._updateStatusCard()
        if getattr(self, "_statusReady", False):
            self._startStatusRefresh()

    def current(self):
        row = self["config"].getCurrent()
        return row[0] if row else None

    def select(self):
        source = self.current()
        if not source:
            return
        if self.selectCallback:
            self.selectCallback(source)
            self.close()
            return

        # Selecting a server means selecting ONE Movies / TV Shows source.
        # Never open the old intermediary MOVIES / TV SHOWS screen.
        try:
            active_file = data_path("active_source.json")
            ensure_dir(os.path.dirname(active_file))
            key = "%s|%s|%s|%s" % (
                source.get("type", ""),
                source.get("url", "").rstrip("/"),
                source.get("username", ""),
                source.get("mac", "")
            )
            with open_text(active_file, "w") as handle:
                json.dump({"key": key}, handle)
        except Exception:
            pass
        self.close()

    def addSource(self):
        self.session.openWithCallback(self._chooseSourceType, SourceTypePicker)

    def _chooseSourceType(self, source_type=None):
        if source_type == "xtream":
            self.session.openWithCallback(self._saveNew, PlaylistEditor, None)
        elif source_type == "stalker":
            self.session.openWithCallback(self._saveNew, StalkerPortalEditor, None)
        elif source_type == "m3u":
            self.session.openWithCallback(self._saveNew, M3UPlaylistEditor, None)

    @staticmethod
    def _storageSourceKey(source):
        source = source or {}
        return "%s|%s|%s|%s" % (
            source.get("type", ""),
            (source.get("url") or source.get("path") or source.get("host") or source.get("server") or source.get("portal") or "").rstrip("/"),
            source.get("username", ""),
            source.get("mac", ""),
        )

    def _saveNew(self, source=None):
        if not isinstance(source, dict):
            return
        srcs = get_sources()

        # Group Stalker MACs under an existing portal when possible.
        if source.get("type") == "stalker":
            portal = str(source.get("url") or "").rstrip("/").lower()
            incoming = list(source.get("macs") or [])
            if incoming:
                srcs = [
                    item for item in srcs
                    if not (
                        item.get("type") == "stalker" and
                        str(item.get("url") or "").rstrip("/").lower() == portal
                    )
                ]
                srcs.append(source)
            else:
                srcs.append(source)
        else:
            srcs.append(source)

        set_sources(srcs)
        write_playlists(srcs)
        self.reload()
        self.session.open(MessageBox, "Server saved.", MessageBox.TYPE_INFO, timeout=3)

    def editSource(self):
        source = self.current()
        if not source:
            return
        try:
            source_index = int(self["config"].getSelectedIndex())
        except Exception:
            source_index = -1
        callback = lambda edited=None: self._replaceAt(source_index, source, edited)
        if source.get("type") == "xtream":
            self.session.openWithCallback(callback, PlaylistEditor, source); return
        if source.get("type") == "stalker":
            self.session.openWithCallback(callback, StalkerPortalEditor, source); return
        if source.get("type") == "m3u":
            self.session.openWithCallback(callback, M3UPlaylistEditor, source); return
        self.session.open(MessageBox, "This source type cannot be edited here.", MessageBox.TYPE_INFO); return

    def _replaceAt(self, source_index, old, new=None):
        if not isinstance(new, dict):
            return
        srcs = get_sources()
        replaced_index = -1
        if 0 <= source_index < len(srcs):
            candidate = srcs[source_index]
            if self._storageSourceKey(candidate) == self._storageSourceKey(old) or candidate == old:
                srcs[source_index] = new
                replaced_index = source_index
        if replaced_index < 0:
            old_key = self._storageSourceKey(old)
            for i, item in enumerate(srcs):
                if item == old or self._storageSourceKey(item) == old_key:
                    srcs[i] = new
                    replaced_index = i
                    break
        if replaced_index < 0:
            srcs.append(new)
            replaced_index = len(srcs) - 1
        set_sources(srcs)
        write_playlists(srcs)
        self.reload()
        try:
            self["config"].moveToIndex(replaced_index)
        except Exception:
            pass
        self.session.open(MessageBox, "Name and settings saved.", MessageBox.TYPE_INFO, timeout=3)

    def delSource(self):
        source = self.current()
        if not source:
            return
        srcs = [x for x in get_sources() if x != source]
        set_sources(srcs); write_playlists(srcs)
        self.reload()

    def testSource(self):
        source = self.current()
        if not source:
            return
        key = self._sourceKey(source)
        self._serverStates[key] = "checking"
        self._refreshSourceRows()
        self._updateStatusCard()

        if source.get("type") == "stalker":
            source_copy = dict(source)
            def worker():
                try:
                    details = StalkerClient(source_copy).test()
                except Exception as exc:
                    details = {"ok": False, "error": str(exc), "quick_test": True}

                def done():
                    try:
                        state = "online" if details.get("ok") else "offline"
                        self._serverStates[key] = state
                        self._serverExpiries[key] = details.get("expiry") or ""
                        try:
                            for saved_source in self.sources:
                                if self._sourceKey(saved_source) == key:
                                    saved_source["_last_status"] = state
                                    saved_source["_last_status_detail"] = str(details.get("error") or "")[:160]
                                    saved_source["_last_status_at"] = int(time.time())
                                    if details.get("expiry"):
                                        saved_source["_last_expiry"] = str(details.get("expiry"))
                                    break
                            set_sources(self.sources)
                        except Exception:
                            pass
                        self._refreshSourceRows()
                        self._updateStatusCard()

                        endpoint = details.get("endpoint") or "Not detected"
                        message = "Portal path: %s\nHandshake: %s\nProfile: %s\nLive categories: %s\nLive channels: SKIPPED\nCreate live link: SKIPPED" % (
                            endpoint,
                            "OK" if details.get("handshake") else "FAILED",
                            "OK" if details.get("profile") else "FAILED",
                            int(details.get("categories") or 0),
                        )
                        if details.get("error"):
                            message += "\nError: %s" % details.get("error")
                        message += "\n\nQuick test completed. Channel/link validation runs when Live is opened."
                        self.session.open(
                            MessageBox, message,
                            MessageBox.TYPE_INFO if details.get("ok") else MessageBox.TYPE_ERROR,
                            timeout=15
                        )
                    except Exception:
                        pass

                try:
                    if reactor is not None:
                        reactor.callFromThread(done)
                    else:
                        done()
                except Exception:
                    done()

            thread = threading.Thread(target=worker, name="TiviMateStalkerQuickTest")
            thread.daemon = True
            thread.start()
            return

        report, error = self._connectionTest(source)
        state = report.get("state", "offline")
        self._serverStates[key] = state
        self._serverExpiries[key] = report.get("expiry") or ""
        self._refreshSourceRows()
        self._updateStatusCard()
        if state == "online":
            self.session.open(MessageBox, "Connection successful. No active use was reported by the server.", MessageBox.TYPE_INFO)
        elif state == "busy":
            self.session.open(MessageBox, "Connection successful. The server reports active use for this subscription.", MessageBox.TYPE_INFO)
        elif state == "expired":
            self.session.open(MessageBox, "Connection reached the server, but the subscription is expired.", MessageBox.TYPE_ERROR)
        else:
            self.session.open(MessageBox, "Connection failed.\n%s" % (error or "Please verify the server details."), MessageBox.TYPE_ERROR)


