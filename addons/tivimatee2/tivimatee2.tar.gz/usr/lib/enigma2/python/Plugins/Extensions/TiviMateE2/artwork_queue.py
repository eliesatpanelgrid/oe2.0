
"""Small, UI-safe artwork download queue for Enigma2.

Artwork is always read from the local cache first.  On a cache miss this module
starts the existing helper in a separate process and keeps at most four network
transfers alive at once.  Consequently a list renderer never performs DNS,
HTTP, image conversion, or disk writes on the Enigma2 GUI thread.
"""

import hashlib
import os
import threading
import time

from enigma import eConsoleAppContainer, eTimer

try:
    from twisted.web.client import downloadPage
except Exception:
    downloadPage = None

from .cache_manager import get_cache_dir, get_cache_root, cleanup_cache, get_settings, is_internal_cache_active
from .compat import python_command

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")
PYTHON_EXECUTABLE, PYTHON_COMMAND = python_command()
# Four transfers keep the interface responsive without creating an unbounded
# download burst on compact Enigma2 receivers.  Artwork bytes are never changed.
MAX_CONCURRENT_DOWNLOADS = 4
# Bound the queued artwork metadata/callbacks as well as active transfers. On a
# fast scroll a receiver can otherwise accumulate hundreds of stale poster jobs
# while the network is slower than the UI. Dropped stale jobs are harmless: a
# visible card requests the same cached URL again when rendered.
MAX_PENDING_DOWNLOADS = 64

# R227: one bad/slow artwork response must never freeze the remaining Movies
# poster queue. Each transfer gets one controlled retry and a hard watchdog.
MAX_JOB_RETRIES = 1
JOB_STALL_SECONDS = 11
WATCHDOG_INTERVAL_MS = 1400
_watchdog_timer = [None]

# Global low-priority prefetch feeder. Screens can hand us every artwork URL
# they already know about; the feeder releases them to the normal queue in
# small slices so page rendering never waits for a bulk image burst.
_PREFETCH_FEED_SIZE = 6
_PREFETCH_INTERVAL_MS = 350
_prefetch_pending = []
_prefetch_seen = set()
_prefetch_timer = [None]

MAX_CALLBACKS_PER_JOB = 8
MAX_NOTIFY_TIMERS = 24
MIN_VALID_BYTES = 100

_pending = []
_running = {}
_jobs = {}
_sequence = [0]
_cleanup_count = [0]
_cleanup_running = [False]
_notify_timers = []
_display_sequence = [0]
CLEANUP_EVERY_SUCCESSES = 12

# r173: hard application-exit gate. Once Home exits, no artwork callback,
# retry, prefetch or late network completion may recreate the cache tree.
_APP_EXITING = [False]

def set_app_exiting(value=True):
    try:
        _APP_EXITING[0] = bool(value)
    except Exception:
        pass

def is_app_exiting():
    try:
        return bool(_APP_EXITING[0])
    except Exception:
        return False


def normalise_url(url):
    try:
        return (url or "").strip().replace("\\/", "/")
    except Exception:
        return ""




def _media_cache_kind(kind):
    """Collapse every screen-specific media alias into one shared cache family."""
    value = str(kind or "artwork").strip().lower()
    poster_aliases = {
        "poster", "posters", "contenthome", "search", "home_poster",
        "details_poster", "live_tmdb_poster", "download_poster"
    }
    backdrop_aliases = {
        "backdrop", "backdrops", "hero", "home_backdrop", "details_backdrop",
        "episodes", "episode", "stills"
    }
    logo_aliases = {"logo", "logos", "package_logo", "provider_logo"}
    if value in poster_aliases:
        return "posters"
    if value in backdrop_aliases:
        return "backdrops"
    if value in logo_aliases:
        return "logos"
    return value or "artwork"

def _canonical_tmdb_artwork(url, kind):
    """Return one shared TMDb URL/key for every screen.

    TMDb serves the same file through size-specific URLs (w342/w500/w780/w1280/
    original). Older builds hashed the full URL, so the same poster/backdrop was
    cached once per screen size.  r130-test standardises TMDb artwork to one
    quality per media type and one cache key derived from the TMDb file path.
    """
    url = normalise_url(url)
    kind = _media_cache_kind(kind)
    clean = url.split("?", 1)[0]
    marker = "image.tmdb.org/t/p/"
    lower = clean.lower()
    pos = lower.find(marker)
    if pos < 0:
        return url, ""
    tail = clean[pos + len(marker):].lstrip("/")
    parts = tail.split("/", 1)
    if len(parts) != 2 or not parts[1]:
        return url, ""
    rel = parts[1].lstrip("/")
    # One good-quality file shared by Home, rails, details, search and player.
    # Backdrops use HD w1280; posters use w500 to keep cache weight modest.
    if str(kind or "").lower() == "backdrops":
        size = "w1280"
    elif str(kind or "").lower() == "posters":
        size = "w500"
    else:
        size = parts[0] or "original"
    canonical = "https://image.tmdb.org/t/p/%s/%s" % (size, rel)
    return canonical, rel


def artwork_path(url, kind="artwork"):
    """Return the stable shared cache path for an artwork URL."""
    url = normalise_url(url)
    if not url:
        return ""
    kind = _media_cache_kind(kind)
    canonical_url, tmdb_rel = _canonical_tmdb_artwork(url, kind)
    clean_url = canonical_url.split("?", 1)[0]
    lower_url = clean_url.lower()
    ext = ".png" if lower_url.endswith(".png") else ".jpg"
    if tmdb_rel:
        # Same TMDb image => same filename, regardless of which page requested it.
        digest = hashlib.md5(tmdb_rel.encode("utf-8")).hexdigest()
        prefix = "poster_" if kind == "posters" else ("backdrop_" if kind == "backdrops" else ("logo_" if kind == "logos" else "artwork_"))
        return os.path.join(get_cache_dir(kind), prefix + "tmdb_" + digest + ext)
    # Provider/CDN artwork still deduplicates query-string token changes.
    digest = hashlib.md5(clean_url.encode("utf-8")).hexdigest()
    prefix = "poster_" if kind == "posters" else ("backdrop_" if kind == "backdrops" else ("logo_" if kind == "logos" else "artwork_"))
    return os.path.join(get_cache_dir(kind), prefix + digest + ext)


def cached_artwork(url, kind="artwork"):
    if is_app_exiting():
        return ""
    path = artwork_path(url, kind)
    try:
        if path and os.path.exists(path) and os.path.getsize(path) >= MIN_VALID_BYTES:
            try:
                os.utime(path, None)
            except Exception:
                pass
            return path
    except Exception:
        pass
    return ""


def _valid(path):
    try:
        return bool(path and os.path.exists(path) and os.path.getsize(path) >= MIN_VALID_BYTES)
    except Exception:
        return False


def _schedule_cleanup():
    """Run lightweight artwork-only cleanup when its policy is enabled."""
    if is_app_exiting():
        return
    try:
        cfg = get_settings() or {}
        location = str(cfg.get("location") or "auto").strip().lower()
        try:
            actual_root = os.path.realpath(get_cache_root())
        except Exception:
            actual_root = ""
        on_internal = is_internal_cache_active()
        internal_policy = (on_internal and (
            int(cfg.get("flash_image_limit", 20) or 0) > 0 or
            int(cfg.get("flash_min_free_mb", 30) or 0) > 0
        ))
        age_policy = int(cfg.get("retention_days", 0) or 0) > 0
        if not (internal_policy or age_policy):
            return
    except Exception:
        return
    _cleanup_count[0] += 1
    # Internal flash keeps a tight LRU cap, so trim after each successful image.
    # HDD/USB age cleanup remains batched to avoid unnecessary disk walks.
    threshold = 1 if internal_policy else CLEANUP_EVERY_SUCCESSES
    if _cleanup_count[0] < threshold or _cleanup_running[0]:
        return
    _cleanup_count[0] = 0
    _cleanup_running[0] = True

    def worker():
        try:
            cleanup_cache()
        except Exception:
            pass
        finally:
            _cleanup_running[0] = False

    thread = threading.Thread(target=worker, name="TiviMateArtworkCleanup")
    thread.daemon = True
    thread.start()


def _notify(callbacks, path):
    for callback in list(callbacks or []):
        try:
            callback(path)
        except Exception:
            # A screen may legitimately have closed while an artwork transfer was
            # queued.  One dead callback must not affect another screen/job.
            pass


def _schedule_notify(callbacks, path, delay_ms):
    """Schedule one UI-thread refresh for a completed local artwork file."""
    callbacks = list(callbacks or [])
    if not callbacks:
        return
    timer = eTimer()
    holder = {"timer": timer}

    def fire():
        try:
            _notify(callbacks, path)
        finally:
            try:
                timer.stop()
            except Exception:
                pass
            try:
                _notify_timers.remove(holder)
            except Exception:
                pass

    try:
        holder["connection"] = timer.timeout.connect(fire)
    except Exception:
        try:
            timer.callback.append(fire)
        except Exception:
            timer.timeout.get().append(fire)
    # Keep the short-lived GUI timer list bounded. Oldest timers are only refresh
    # retries; cancelling one cannot cancel the artwork download or disk cache.
    while len(_notify_timers) >= MAX_NOTIFY_TIMERS:
        old = _notify_timers.pop(0)
        try:
            old.get("timer").stop()
        except Exception:
            pass
    _notify_timers.append(holder)
    timer.start(max(1, int(delay_ms)), True)


def _notify_after_write(callbacks, path, delay_ms=90):
    """Reveal completed images progressively on every screen.

    Several Enigma2 images can finish multiple artwork helper processes in the
    same GUI cycle.  Refreshing every slot in that same cycle makes an entire
    row appear at once, and occasionally the first ePicLoad decode is missed
    until the screen is reopened.  Stagger each completed file by a small amount
    and issue one conservative retry.  The callbacks still target individual
    widgets, so this never redraws or blocks the whole page.
    """
    callbacks = list(callbacks or [])
    if not callbacks:
        return
    _display_sequence[0] += 1
    # Spread near-simultaneous completions across four short GUI slots.
    first_delay = int(delay_ms) + ((_display_sequence[0] - 1) % 4) * 85
    _schedule_notify(callbacks, path, first_delay)
    # Pure2/OpenATV may miss the first decoder signal while the file-system
    # rename is still settling. A single later retry fixes that without a page
    # refresh or another network download.
    _schedule_notify(callbacks, path, first_delay + 620)


def _prefetch_key_for_job(job):
    try:
        url = normalise_url((job or {}).get("url") or "")
        kind = str((job or {}).get("kind") or "artwork")
        if not url:
            return None
        return (kind, url.split("?", 1)[0])
    except Exception:
        return None


def _final_job_failure(path, job):
    """Fail one artwork item only; never allow it to stop the queue."""
    _running.pop(path, None)
    _jobs.pop(path, None)
    key = _prefetch_key_for_job(job)
    if key is not None:
        try:
            _prefetch_seen.discard(key)
        except Exception:
            pass
    _notify((job or {}).get("errbacks"), path)


def _retry_or_fail(path, job):
    """Retry a failed/stalled transfer once, then skip only that item."""
    if not job:
        _jobs.pop(path, None)
        _start_next()
        return
    _running.pop(path, None)
    try:
        part = job.get("part") or ""
        if part and os.path.exists(part):
            os.remove(part)
    except Exception:
        pass
    tries = int(job.get("attempt", 0) or 0)
    if tries < MAX_JOB_RETRIES:
        job["attempt"] = tries + 1
        job["started"] = 0
        job.pop("deferred", None)
        job.pop("container", None)
        # Keep the failed item near the front, but preserve visible-card priority.
        _pending.append(job)
        _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
    else:
        _final_job_failure(path, job)
    _start_next()


def _watchdog_tick():
    """Release stuck artwork slots so the rest of Movies continues loading."""
    now = time.time()
    stalled = []
    for path, job in list(_running.items()):
        try:
            started = float(job.get("started", 0) or 0)
        except Exception:
            started = 0
        if started and (now - started) >= JOB_STALL_SECONDS:
            stalled.append((path, job))
    for path, job in stalled:
        # Remove from running first: any late callback becomes harmless.
        if _running.get(path) is not job:
            continue
        _running.pop(path, None)
        try:
            deferred = job.get("deferred")
            if deferred is not None and hasattr(deferred, "cancel"):
                deferred.cancel()
        except Exception:
            pass
        try:
            container = job.get("container")
            if container is not None and hasattr(container, "kill"):
                container.kill()
        except Exception:
            pass
        _retry_or_fail(path, job)
    if _running or _pending:
        _arm_watchdog()


def _arm_watchdog():
    try:
        timer = _watchdog_timer[0]
        if timer is None:
            timer = eTimer()
            _watchdog_timer[0] = timer
            try:
                timer.timeout.connect(_watchdog_tick)
            except Exception:
                try:
                    timer.callback.append(_watchdog_tick)
                except Exception:
                    timer.timeout.get().append(_watchdog_tick)
        timer.start(WATCHDOG_INTERVAL_MS, True)
    except Exception:
        pass


def _finish(path, status):
    job = _running.pop(path, None)
    if job is None:
        return
    if is_app_exiting():
        _jobs.pop(path, None)
        try:
            if path and os.path.isfile(path): os.remove(path)
        except Exception:
            pass
        return
    try:
        success = int(status) == 0
    except Exception:
        success = False
    if success and _valid(path):
        _jobs.pop(path, None)
        _notify_after_write(job.get("callbacks"), path)
        _schedule_cleanup()
        _start_next()
    else:
        _retry_or_fail(path, job)


def _finish_twisted(path, success):
    job = _running.pop(path, None)
    if job is None:
        return
    part = job.get("part") or ""
    if is_app_exiting():
        _jobs.pop(path, None)
        for stale in (part, path):
            try:
                if stale and os.path.isfile(stale): os.remove(stale)
            except Exception:
                pass
        return
    ok = False
    if success and part:
        try:
            if os.path.exists(part) and os.path.getsize(part) >= MIN_VALID_BYTES:
                try:
                    os.replace(part, path)
                except AttributeError:
                    if os.path.exists(path):
                        os.remove(path)
                    os.rename(part, path)
                ok = _valid(path)
        except Exception:
            ok = False
    if not ok:
        try:
            if part and os.path.exists(part):
                os.remove(part)
        except Exception:
            pass
    if ok:
        _jobs.pop(path, None)
        _notify_after_write(job.get("callbacks"), path)
        _schedule_cleanup()
        _start_next()
    else:
        _retry_or_fail(path, job)


def _start_next():
    if is_app_exiting():
        return
    while len(_running) < MAX_CONCURRENT_DOWNLOADS and _pending:
        job = _pending.pop(0)
        path = job.get("path")
        if not path or path in _running:
            continue
        if _valid(path):
            _jobs.pop(path, None)
            _notify(job.get("callbacks"), path)
            continue
        try:
            if is_app_exiting():
                _jobs.pop(path, None)
                continue
            folder = os.path.dirname(path)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            if is_app_exiting():
                _jobs.pop(path, None)
                continue

            # Use the exact same Twisted download path that the VOD player uses.
            # This avoids launching a fresh Python interpreter for each poster and
            # keeps the image transfer inside Enigma2's proven async network stack.
            if downloadPage is not None:
                part = path + ".part"
                try:
                    if os.path.exists(part):
                        os.remove(part)
                except Exception:
                    pass
                job["part"] = part
                job["started"] = time.time()
                _running[path] = job
                _arm_watchdog()
                request_url = job["url"].encode("utf-8") if isinstance(job["url"], str) else job["url"]
                d = downloadPage(request_url, part, timeout=7)
                job["deferred"] = d
                d.addCallback(lambda _r, cache_path=path: _finish_twisted(cache_path, True))
                d.addErrback(lambda _f, cache_path=path: _finish_twisted(cache_path, False))
                continue

            # Compatibility fallback for images without Twisted downloadPage.
            container = eConsoleAppContainer()
            job["container"] = container
            job["started"] = time.time()
            _running[path] = job
            _arm_watchdog()

            def done(status, cache_path=path):
                _finish(cache_path, status)

            try:
                container.appClosed.append(done)
            except Exception:
                container.appClosed.get().append(done)
            container.execute(PYTHON_EXECUTABLE, PYTHON_COMMAND, IMAGE_FETCH, job["url"], path)
        except Exception:
            _running.pop(path, None)
            try:
                tries = int(job.get("attempt", 0) or 0)
            except Exception:
                tries = MAX_JOB_RETRIES
            if tries < MAX_JOB_RETRIES:
                job["attempt"] = tries + 1
                job["started"] = 0
                _pending.append(job)
                _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
            else:
                _final_job_failure(path, job)


def request_artwork(url, kind="artwork", callback=None, priority=0, errback=None):
    """Use cached artwork immediately or enqueue an asynchronous cache refresh.

    ``callback`` receives the completed local path only after the helper has
    written a valid file.  Duplicate requests share one network transfer while
    every interested widget still receives its own completion callback.
    """
    if is_app_exiting():
        return ""
    url = normalise_url(url)
    if not url:
        return ""
    # Normalise TMDb size before both cache lookup and download, so every page
    # shares exactly the same on-disk poster/backdrop file.
    url, _tmdb_rel = _canonical_tmdb_artwork(url, kind)
    path = cached_artwork(url, kind)
    if path:
        if callback:
            _notify([callback], path)
        return path

    path = artwork_path(url, kind)
    job = _jobs.get(path)
    if job is not None:
        if callback:
            callbacks = job.setdefault("callbacks", [])
            callbacks.append(callback)
            if len(callbacks) > MAX_CALLBACKS_PER_JOB:
                del callbacks[:-MAX_CALLBACKS_PER_JOB]
        if errback:
            errbacks = job.setdefault("errbacks", [])
            errbacks.append(errback)
            if len(errbacks) > MAX_CALLBACKS_PER_JOB:
                del errbacks[:-MAX_CALLBACKS_PER_JOB]
        return path

    _sequence[0] += 1
    job = {
        "url": url,
        "path": path,
        "callbacks": [callback] if callback else [],
        "errbacks": [errback] if errback else [],
        "priority": int(priority or 0),
        "sequence": _sequence[0],
        "kind": kind,
        "attempt": 0,
        "started": 0,
    }
    _jobs[path] = job
    _pending.append(job)
    # Highest priority first, then preserve the visual order for equal priority.
    _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
    # RAM guard for long browsing sessions: keep active transfers plus only a
    # small window of pending artwork metadata. Prefer current/high-priority and
    # newer jobs; stale jobs will be requested again if they become visible.
    if len(_pending) > MAX_PENDING_DOWNLOADS:
        overflow = len(_pending) - MAX_PENDING_DOWNLOADS
        candidates = sorted(_pending, key=lambda item: (item.get("priority", 0), item.get("sequence", 0)))
        for stale in candidates[:overflow]:
            try:
                _pending.remove(stale)
            except Exception:
                pass
            stale_path = stale.get("path")
            if stale_path and stale_path not in _running:
                _jobs.pop(stale_path, None)
            stale_key = _prefetch_key_for_job(stale)
            if stale_key is not None:
                try:
                    _prefetch_seen.discard(stale_key)
                except Exception:
                    pass
            try:
                stale["callbacks"] = []
                stale["errbacks"] = []
            except Exception:
                pass
    _start_next()
    return path



def _prefetch_tick():
    """Feed bulk prefetch jobs into the normal queue without blocking the UI."""
    if is_app_exiting():
        return
    timer = _prefetch_timer[0]
    try:
        if timer is not None:
            timer.stop()
    except Exception:
        pass
    fed = 0
    # Leave room for visible/high-priority requests.
    room = max(0, (MAX_PENDING_DOWNLOADS - 12) - len(_pending))
    take = min(_PREFETCH_FEED_SIZE, room, len(_prefetch_pending))
    while take > 0 and _prefetch_pending:
        url, kind, priority, key = _prefetch_pending.pop(0)
        try:
            request_artwork(url, kind, None, priority=priority)
        except Exception:
            pass
        fed += 1
        take -= 1
    if _prefetch_pending:
        try:
            if timer is None:
                timer = eTimer()
                _prefetch_timer[0] = timer
                try:
                    timer.timeout.connect(_prefetch_tick)
                except Exception:
                    try:
                        timer.callback.append(_prefetch_tick)
                    except Exception:
                        timer.timeout.get().append(_prefetch_tick)
            timer.start(_PREFETCH_INTERVAL_MS if fed else 700, True)
        except Exception:
            pass


def prefetch_artwork(urls, kind="artwork", priority=1):
    """Cache every supplied URL progressively in the background.

    This is intentionally separate from visible-card rendering.  It only feeds
    a few low-priority jobs at a time, so content/text can paint immediately
    while poster/backdrop cache fills behind it. Duplicate URLs are ignored.
    """
    if is_app_exiting():
        return 0
    added = 0
    for raw in list(urls or []):
        url = normalise_url(raw)
        if not url:
            continue
        key = (kind, url.split("?", 1)[0])
        if key in _prefetch_seen:
            continue
        if cached_artwork(url, kind):
            _prefetch_seen.add(key)
            continue
        _prefetch_seen.add(key)
        _prefetch_pending.append((url, kind, int(priority or 0), key))
        added += 1
    if added:
        _prefetch_tick()
    return added

def queue_status():
    """Return lightweight diagnostics for support logs and unit tests."""
    return {"pending": len(_pending), "running": len(_running), "limit": MAX_CONCURRENT_DOWNLOADS, "pending_limit": MAX_PENDING_DOWNLOADS, "notify_timers": len(_notify_timers), "prefetch_pending": len(_prefetch_pending)}


def cancel_all_artwork():
    """Cancel every queued/in-flight artwork job for application shutdown/exit."""
    set_app_exiting(True)
    # Stop delayed UI notifications too; none may touch artwork after Home exit.
    try:
        for holder in list(_notify_timers):
            try: holder.get("timer").stop()
            except Exception: pass
        _notify_timers[:] = []
    except Exception:
        pass
    try:
        timer = _prefetch_timer[0]
        if timer is not None:
            try: timer.stop()
            except Exception: pass
    except Exception:
        pass
    try:
        _prefetch_pending[:] = []
        _prefetch_seen.clear()
    except Exception:
        pass
    try:
        timer = _watchdog_timer[0]
        if timer is not None:
            try: timer.stop()
            except Exception: pass
    except Exception:
        pass
    try:
        for path, job in list(_running.items()):
            try:
                d = job.get("deferred")
                if d is not None and hasattr(d, "cancel"):
                    d.cancel()
            except Exception:
                pass
            try:
                c = job.get("container")
                if c is not None and hasattr(c, "kill"):
                    c.kill()
            except Exception:
                pass
            for temp_key in ("part",):
                try:
                    tp = job.get(temp_key)
                    if tp and os.path.isfile(tp): os.remove(tp)
                except Exception:
                    pass
            try:
                job["callbacks"] = []
                job["errbacks"] = []
            except Exception:
                pass
        _running.clear()
        _pending[:] = []
        _jobs.clear()
    except Exception:
        pass
