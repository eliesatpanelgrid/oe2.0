from __future__ import absolute_import

"""Small, UI-safe artwork download queue for Enigma2.

Artwork is always read from the local cache first.  On a cache miss this module
starts the existing helper in a separate process and keeps at most four network
transfers alive at once.  Consequently a list renderer never performs DNS,
HTTP, image conversion, or disk writes on the Enigma2 GUI thread.
"""

import hashlib
import os
import threading

from enigma import eConsoleAppContainer

from .cache_manager import get_cache_dir, cleanup_cache, get_settings
from .compat import python_command

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")
PYTHON_EXECUTABLE, PYTHON_COMMAND = python_command()
# Four transfers keep the interface responsive without creating an unbounded
# download burst on compact Enigma2 receivers.  Artwork bytes are never changed.
MAX_CONCURRENT_DOWNLOADS = 4
MIN_VALID_BYTES = 100

_pending = []
_running = {}
_jobs = {}
_sequence = [0]
_cleanup_count = [0]
_cleanup_running = [False]
CLEANUP_EVERY_SUCCESSES = 12


def normalise_url(url):
    try:
        return (url or "").strip().replace("\\/", "/")
    except Exception:
        return ""


def artwork_path(url, kind="artwork"):
    """Return the stable cache path for an artwork URL without downloading it."""
    url = normalise_url(url)
    if not url:
        return ""
    clean_url = url.split("?", 1)[0]
    lower_url = clean_url.lower()
    # Preserve PNG in the common direct case.  The fetch helper validates the
    # actual content type, so a server that lies about an extension is still safe.
    ext = ".png" if lower_url.endswith(".png") else ".jpg"
    # Expiring CDN tokens often change only the query string.  The binary image
    # itself is the same, so a query-free key prevents unnecessary redownloads.
    digest = hashlib.md5(clean_url.encode("utf-8")).hexdigest()
    return os.path.join(get_cache_dir(kind), digest + ext)


def cached_artwork(url, kind="artwork"):
    path = artwork_path(url, kind)
    try:
        if path and os.path.exists(path) and os.path.getsize(path) >= MIN_VALID_BYTES:
            try:
                os.utime(path, None)
            except Exception:
                pass
            return path
    except Exception:
        pass
    return ""


def _valid(path):
    try:
        return bool(path and os.path.exists(path) and os.path.getsize(path) >= MIN_VALID_BYTES)
    except Exception:
        return False


def _schedule_cleanup():
    """Run age-based trimming only when the user enabled a retention period."""
    try:
        if int(get_settings().get("retention_days", 0) or 0) <= 0:
            # Unlimited means exactly that: no automatic cleanup task is even
            # scheduled, so no background path can remove posters/backdrops.
            return
    except Exception:
        return
    _cleanup_count[0] += 1
    if _cleanup_count[0] < CLEANUP_EVERY_SUCCESSES or _cleanup_running[0]:
        return
    _cleanup_count[0] = 0
    _cleanup_running[0] = True

    def worker():
        try:
            cleanup_cache()
        except Exception:
            pass
        finally:
            _cleanup_running[0] = False

    thread = threading.Thread(target=worker, name="TiviMateArtworkCleanup")
    thread.daemon = True
    thread.start()


def _notify(callbacks, path):
    for callback in list(callbacks or []):
        try:
            callback(path)
        except Exception:
            # A screen may legitimately have closed while an artwork transfer was
            # queued.  One dead callback must not affect another screen/job.
            pass


def _finish(path, status):
    job = _running.pop(path, None)
    if job is None:
        return
    _jobs.pop(path, None)
    try:
        success = int(status) == 0
    except Exception:
        success = False
    if success and _valid(path):
        _notify(job.get("callbacks"), path)
        _schedule_cleanup()
    _start_next()


def _start_next():
    while len(_running) < MAX_CONCURRENT_DOWNLOADS and _pending:
        job = _pending.pop(0)
        path = job.get("path")
        if not path or path in _running:
            continue
        if _valid(path):
            _jobs.pop(path, None)
            _notify(job.get("callbacks"), path)
            continue
        try:
            folder = os.path.dirname(path)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            container = eConsoleAppContainer()
            job["container"] = container
            _running[path] = job

            def done(status, cache_path=path):
                _finish(cache_path, status)

            try:
                container.appClosed.append(done)
            except Exception:
                container.appClosed.get().append(done)
            container.execute(PYTHON_EXECUTABLE, PYTHON_COMMAND, IMAGE_FETCH, job["url"], path)
        except Exception:
            _running.pop(path, None)
            _jobs.pop(path, None)


def request_artwork(url, kind="artwork", callback=None, priority=0):
    """Use cached artwork immediately or enqueue an asynchronous cache refresh.

    ``callback`` receives the completed local path only after the helper has
    written a valid file.  Duplicate requests share one network transfer while
    every interested widget still receives its own completion callback.
    """
    url = normalise_url(url)
    if not url:
        return ""
    path = cached_artwork(url, kind)
    if path:
        if callback:
            _notify([callback], path)
        return path

    path = artwork_path(url, kind)
    job = _jobs.get(path)
    if job is not None:
        if callback:
            job.setdefault("callbacks", []).append(callback)
        return path

    _sequence[0] += 1
    job = {
        "url": url,
        "path": path,
        "callbacks": [callback] if callback else [],
        "priority": int(priority or 0),
        "sequence": _sequence[0],
    }
    _jobs[path] = job
    _pending.append(job)
    # Highest priority first, then preserve the visual order for equal priority.
    _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
    _start_next()
    return path


def queue_status():
    """Return lightweight diagnostics for support logs and unit tests."""
    return {"pending": len(_pending), "running": len(_running), "limit": MAX_CONCURRENT_DOWNLOADS}
