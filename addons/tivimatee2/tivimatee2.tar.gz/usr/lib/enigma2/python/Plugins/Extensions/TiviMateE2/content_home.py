# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, time, json, hashlib, threading
from collections import OrderedDict
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
from enigma import eServiceReference, ePicLoad, eConsoleAppContainer, ePoint, eTimer, eSize
try:
    from twisted.internet import reactor
except Exception:
    reactor = None
from .core import get_source_client
from .tmdb_client import TMDbClient, load_settings
from .filters import get_filtered_streams, get_allowed_category_ids, filter_categories, get_category_streams, get_cached_categories, get_stalker_landing_items
from difflib import SequenceMatcher
import re

from .cache_manager import get_cache_dir
from .artwork_queue import request_artwork
from .display_scale import scale_skin, sx, sy, scale_size
from .i18n import tr, get_language
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")

# Keep recently decoded pixmaps alive in RAM. This avoids ePicLoad decoding again
# when the user reopens the same movie during the current Enigma2 session.
_DETAILS_PIXMAP_CACHE = OrderedDict()
# Decoded pixmaps consume RAM on the receiver.  Keep a small LRU only while a
# details page is open; the full-quality source remains in the disk cache.
_DETAILS_PIXMAP_CACHE_LIMIT = 8
_DETAILS_DATA_CACHE = OrderedDict()
_DETAILS_DATA_CACHE_LIMIT = 12

def _memory_get(cache, key):
    try:
        value = cache.pop(key)
        cache[key] = value
        return value
    except Exception:
        return None

def _memory_put(cache, key, value, limit):
    try:
        if key in cache:
            cache.pop(key)
        cache[key] = value
        while len(cache) > limit:
            cache.popitem(last=False)
    except Exception:
        pass

CONTENT_HOME = '''<screen name="ContentHomeScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#181b20">
<eLabel position="0,0" size="1920,1080" backgroundColor="#181b20" zPosition="0" />
<widget name="hero" position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/content_overlay.png" alphatest="blend" zPosition="2" />
<widget name="top0" position="90,35" size="180,52" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="top1" position="285,35" size="180,52" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="top2" position="480,35" size="180,52" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="top3" position="675,35" size="180,52" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="top4" position="870,35" size="210,52" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="topSelector" position="90,88" size="190,5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/top_selector.png" alphatest="blend" zPosition="5" />
<widget name="clock" position="1640,42" size="190,40" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
<widget name="logoImage" position="95,120" size="560,150" alphatest="blend" zPosition="4" />
<widget name="logoTitle" position="95,145" size="840,100" font="Regular;60" foregroundColor="#F2D36B" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="heroMeta" position="100,265" size="820,40" font="Regular;25" foregroundColor="#E5E7EB" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="heroDesc" position="100,320" size="820,110" font="Regular;24" foregroundColor="#E5E7EB" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="trendingTitle" position="80,500" size="720,45" font="Regular;31" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="trend0" position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" />
<ePixmap position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="92,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate0" position="92,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel0" position="148,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend1" position="535,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" />
<ePixmap position="535,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="547,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate1" position="547,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel1" position="603,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend2" position="990,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" />
<ePixmap position="990,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1002,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate2" position="1002,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel2" position="1058,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend3" position="1445,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" />
<ePixmap position="1445,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1457,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate3" position="1457,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel3" position="1513,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="rank0" position="94,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank1" position="549,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank2" position="1004,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank3" position="1459,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="trendSelector" position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r74_410x210.png" alphatest="blend" zPosition="8" />
	<widget name="latestTitle" position="80,772" size="720,45" font="Regular;31" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
	<widget name="latest0" position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="88,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate0" position="88,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel0" position="142,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest1" position="295,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="295,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="303,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate1" position="303,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel1" position="357,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest2" position="510,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="510,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="518,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate2" position="518,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel2" position="572,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest3" position="725,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="725,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="733,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate3" position="733,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel3" position="787,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest4" position="940,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="940,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="948,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate4" position="948,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel4" position="1002,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest5" position="1155,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1155,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="1163,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate5" position="1163,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel5" position="1217,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest6" position="1370,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1370,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="1378,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate6" position="1378,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel6" position="1432,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest7" position="1585,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1585,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="1593,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate7" position="1593,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel7" position="1647,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latestSelector" position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r74_170x205.png" alphatest="blend" zPosition="8" />
	<widget name="footer" position="85,1042" size="1750,35" font="Regular;20" foregroundColor="#D4D7DD" backgroundColor="#00000000" transparent="1" halign="center" zPosition="3" />
	<widget name="actionButtons" position="85,1041" size="1750,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/content_action_buttons_r115.png" alphatest="blend" zPosition="4" />
</screen>'''

CONTENT_HOME = scale_skin(CONTENT_HOME)

CATEGORY_POPUP = '''<screen name="ServerCategoryList" position="300,120" size="1320,840" flags="wfNoBorder" backgroundColor="#071A2B">
<widget name="panel" position="0,0" size="1320,840" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/category_popup_panel_r67.png" alphatest="blend" zPosition="0" />
<widget name="brand" position="28,28" size="230,48" font="Regular;35" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="brandTagline" position="31,78" size="220,26" font="Regular;15" foregroundColor="#6DD8FF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="sideTitle" position="28,150" size="230,32" font="Regular;21" foregroundColor="#F2D36B" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="sideText" position="28,192" size="230,120" font="Regular;18" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="sectionBadge" position="42,696" size="196,35" font="Regular;19" foregroundColor="#FFFFFF" backgroundColor="#0D324A" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="sideHint" position="40,778" size="200,22" font="Regular;15" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="title" position="350,26" size="700,46" font="Regular;37" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="subtitle" position="350,74" size="650,28" font="Regular;19" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="count" position="1030,38" size="225,34" font="Regular;18" foregroundColor="#F2D36B" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="2" />
<widget name="listHeader" position="367,134" size="400,25" font="Regular;16" foregroundColor="#6DD8FF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="list" position="350,192" size="890,472" font="Regular;27" itemHeight="58" scrollbarMode="showOnDemand" backgroundColor="#0A2134" foregroundColor="#F5F8FC" selectionBackgroundColor="#E8B83F" selectionForegroundColor="#071A2B" zPosition="2" />
<widget name="keys" position="350,720" size="910,62" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="actionButtons" position="350,733" size="910,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/category_popup_buttons_r67.png" alphatest="blend" zPosition="3" />
</screen>'''

CATEGORY_POPUP = scale_skin(CATEGORY_POPUP)

class ServerCategoryList(Screen):
    skin = CATEGORY_POPUP
    def __init__(self, session, source, kind):
        Screen.__init__(self, session)
        self.source, self.kind = source, kind
        self.rows = []
        is_movies = kind == "vod"
        self["panel"] = Pixmap()
        self["brand"] = Label(tr("TiViMate"))
        self["brandTagline"] = Label(tr("IPTV EXPERIENCE"))
        self["sideTitle"] = Label(tr("YOUR LIBRARY"))
        self["sideText"] = Label(tr("Choose a collection\nto browse titles from\nyour selected server."))
        self["sectionBadge"] = Label(tr("MOVIES") if is_movies else tr("TV SHOWS"))
        self["sideHint"] = Label(tr("Press OK to open"))
        self["title"] = Label(tr("MOVIE CATEGORIES") if is_movies else tr("TV SHOW CATEGORIES"))
        self["subtitle"] = Label(tr("Browse the collections available on your server"))
        self["count"] = Label(tr("LOADING COLLECTIONS"))
        self["listHeader"] = Label(tr("AVAILABLE COLLECTIONS"))
        self["list"] = MenuList([])
        self["keys"] = Label("")
        self["actionButtons"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.choose, "cancel": self.close, "up": self.up, "down": self.down,
            "pageUp": self.pageUp, "pageDown": self.pageDown
        }, -1)
        self._categoryLoadToken = 0
        self._categoryLoadResult = None
        self._categoryLoadTimer = eTimer()
        try:
            self._categoryLoadTimer.callback.append(self._finishCategoryLoad)
        except Exception:
            self._categoryLoadTimer.timeout.get().append(self._finishCategoryLoad)
        self.onLayoutFinish.append(self.load)

    def load(self):
        self._categoryLoadToken += 1
        token = self._categoryLoadToken
        source = dict(self.source)
        kind = self.kind
        self._categoryLoadResult = None
        self["count"].setText(tr("LOADING COLLECTIONS"))

        def worker():
            try:
                cats, origin = get_cached_categories(source, kind, get_source_client(source), wait_for_server=True)
                cats = filter_categories(source, kind, cats or [])
                rows = [(entry.get("category_name") or "Other", str(entry.get("category_id") or "")) for entry in cats]
                result = (token, rows, origin, "")
            except Exception as exc:
                result = (token, [], "error", str(exc))
            self._categoryLoadResult = result

        thread = threading.Thread(target=worker, name="TiviMateCategoryPopup")
        thread.daemon = True
        thread.start()
        try:
            self._categoryLoadTimer.start(100, False)
        except Exception:
            pass

    def _finishCategoryLoad(self):
        result = self._categoryLoadResult
        if not result:
            try:
                self._categoryLoadTimer.start(100, False)
            except Exception:
                pass
            return
        self._categoryLoadResult = None
        token, rows, origin, error = result
        if token != self._categoryLoadToken:
            return
        if error:
            self["title"].setText(tr("UNABLE TO LOAD CATEGORIES"))
            self["subtitle"].setText(tr("Check the selected server and try again"))
            self["count"].setText(tr("NO COLLECTIONS"))
            self["keys"].setText(error[:120])
            return
        self.rows = rows or []
        self["list"].setList(self.rows)
        count = len(self.rows)
        self["count"].setText("%d COLLECTION%s" % (count, "" if count == 1 else "S"))
        if not count:
            self["subtitle"].setText(tr("No enabled collections are available for this server"))

    def choose(self):
        current = self["list"].getCurrent()
        if current:
            self.close({"name": current[0], "id": current[1]})

    def up(self): self["list"].up()
    def down(self): self["list"].down()
    def pageUp(self):
        try: self["list"].pageUp()
        except Exception: self["list"].up()
    def pageDown(self):
        try: self["list"].pageDown()
        except Exception: self["list"].down()


MOVIE_DETAILS = '''<screen name="MovieDetailsScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#17191D">
<eLabel position="0,0" size="1920,1080" backgroundColor="#17191D" zPosition="0" />
<widget name="backdrop" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/details_overlay.png" alphatest="blend" zPosition="2" />
<widget name="poster" position="65,55" size="350,525" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
<widget name="title" position="475,70" size="1040,76" font="Regular;52" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="meta" position="480,155" size="1050,42" font="Regular;24" foregroundColor="#D8DDE5" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="desc" position="480,215" size="1000,190" font="Regular;25" foregroundColor="#F2F4F7" backgroundColor="#00000000" transparent="1" zPosition="4" />
	<widget name="watch" position="480,425" size="270,62" font="Regular;27" foregroundColor="#17191D" backgroundColor="#E8B83F" halign="center" valign="center" zPosition="5" />
	<widget name="sources" position="770,425" size="270,62" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#315976" halign="center" valign="center" zPosition="5" />
	<widget name="buttonSelector" position="475,415" size="280,82" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/details_action_selector_r68.png" alphatest="blend" zPosition="6" />
<widget name="actorsTitle" position="475,520" size="500,40" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="actor0" position="480,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="480,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel0" position="445,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor1" position="690,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="690,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel1" position="655,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor2" position="900,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="900,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel2" position="865,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor3" position="1110,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="1110,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel3" position="1075,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor4" position="1320,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="1320,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel4" position="1285,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor5" position="1530,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="1530,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel5" position="1495,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="recommendTitle" position="65,795" size="500,42" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rec0" position="65,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel0" position="65,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="65,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec1" position="430,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel1" position="430,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="430,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec2" position="795,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel2" position="795,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="795,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec3" position="1160,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel3" position="1160,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="1160,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec4" position="1525,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel4" position="1525,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="1525,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_330x198.png" alphatest="blend" zPosition="5" />
	<widget name="recSelector" position="65,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r74_330x198.png" alphatest="blend" zPosition="8" />
</screen>'''

MOVIE_DETAILS = scale_skin(MOVIE_DETAILS)

class MovieDetailsScreen(Screen):
    skin = MOVIE_DETAILS
    REC_X = [65, 430, 795, 1160, 1525]
    def __init__(self, session, source, item, server_items=None):
        Screen.__init__(self, session)
        self.source = source
        self.item = item or {}
        self.server_items = server_items or []
        self.sources_list = []
        self.recommendations = []
        self.focus = "buttons"
        self.button_index = 0
        self.rec_index = 0
        self.downloads, self.picloads = [], []
        self._detail_pixmap_keys = set()
        self._image_requests = {}
        self["backdrop"] = Pixmap(); self["poster"] = Pixmap()
        self["title"] = Label(self.item.get("name") or self.item.get("title") or "Movie")
        self["meta"] = Label(""); self["desc"] = Label(tr("Loading details..."))
        self["watch"] = Label(tr("▶  Watch")); self["sources"] = Label(tr("Other Sources"))
        self["buttonSelector"] = Pixmap(); self["actorsTitle"] = Label(tr("Actors"))
        for i in range(6):
            self["actor%d" % i] = Pixmap()
            self["actorLabel%d" % i] = Label("")
        self["recommendTitle"] = Label(tr("Recommendations"))
        for i in range(5):
            self["rec%d" % i] = Pixmap(); self["recLabel%d" % i] = Label("")
        self["recSelector"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite, "green": self.watchSelected
        }, -1)
        self.onLayoutFinish.append(self.start)
        self.onClose.append(self._releaseArtworkMemory)

    def _releaseArtworkMemory(self):
        # The local widgets are destroyed with the screen; release the LRU refs
        # too so large backdrops never accumulate between detail pages.
        self._image_requests = {}
        self.downloads = []
        self.picloads = []
        for key in list(getattr(self, "_detail_pixmap_keys", set())):
            try:
                _DETAILS_PIXMAP_CACHE.pop(key, None)
            except Exception:
                pass
        self._detail_pixmap_keys = set()

    def start(self):
        self.findSources()
        self.updateFocus()
        t = threading.Thread(target=self.loadDetails, name="TiviMateMovieDetails")
        t.daemon = True; t.start()

    def _norm(self, value, size="w1280"):
        if isinstance(value, list): value = value[0] if value else ""
        if not isinstance(value, str): return ""
        value = value.strip().replace("\\/", "/")
        if value.startswith("/"): value = "https://image.tmdb.org/t/p/%s%s" % (size, value)
        return value

    def _title_norm(self, value):
        # Keep Unicode words so Arabic catalog titles can be matched as reliably as
        # English titles. Strip only release/quality tags, not title words.
        text = str(value or "").lower().replace("&", " and ")
        text = re.sub(r"\[[^\]]*\]|\([^\)]*\)|\{[^\}]*\}", " ", text)
        text = re.sub(r"\b(ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|uhd|fhd|hd|hevc|x265|x264|hdr|web[- ]?dl|bluray|brrip|webrip|remux|top|2160p|1080p|720p|576p|480p)\b", " ", text)
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
        return " ".join(text.split())

    def _year(self, item):
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        m = re.search(r"\b(19|20)\d{2}\b", raw)
        return int(m.group(0)) if m else 0

    def _title_score(self, wanted, candidate):
        """Return a score only for genuinely matching release titles."""
        if not wanted or not candidate:
            return 0.0
        if wanted == candidate:
            return 1.0
        wanted_tokens, candidate_tokens = set(wanted.split()), set(candidate.split())
        if not wanted_tokens or not candidate_tokens:
            return 0.0
        overlap = wanted_tokens & candidate_tokens
        coverage = float(len(overlap)) / float(min(len(wanted_tokens), len(candidate_tokens)))
        union = float(len(wanted_tokens | candidate_tokens))
        jaccard = float(len(overlap)) / union if union else 0.0
        # Partial title containment is safe only when every significant token matches.
        if coverage == 1.0 and min(len(wanted_tokens), len(candidate_tokens)) >= 2:
            return 0.98 if abs(len(wanted_tokens) - len(candidate_tokens)) <= 1 else 0.94
        ratio = SequenceMatcher(None, wanted, candidate).ratio()
        if min(len(wanted_tokens), len(candidate_tokens)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
            return ratio
        return 0.0

    def _playable_item(self):
        if self.item.get("stream_id"):
            return self.item
        return self.sources_list[0] if self.sources_list else None

    def findSources(self):
        title_fields = ("name", "title", "original_title")
        wanted = [self._title_norm(self.item.get(field)) for field in title_fields]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)
        primary_id = str(self.item.get("stream_id") or "")
        matches, seen = [], set()
        for row in self.server_items:
            row_id = str(row.get("stream_id") or "")
            if row_id and row_id == primary_id:
                continue
            if row_id in seen:
                continue
            candidate_titles = [self._title_norm(row.get(field)) for field in title_fields]
            score = max([self._title_score(wanted_title, candidate) for wanted_title in wanted for candidate in candidate_titles] or [0.0])
            if not score:
                continue
            row_year = self._year(row)
            # Avoid a different remake when both source rows identify their year.
            if target_year and row_year and abs(target_year - row_year) > 1:
                continue
            seen.add(row_id)
            matches.append((score, 1 if target_year and row_year == target_year else 0, row))
        matches.sort(key=lambda value: (value[0], value[1]), reverse=True)
        self.sources_list = [value[2] for value in matches[:12]]
        self["sources"].setText("Other Sources (%d)" % len(self.sources_list))

    def loadDetails(self):
        try:
            # Recent Movies entries are often lightweight rows from get_vod_streams.
            # Enrich only that route with get_vod_info before resolving TMDb.
            if self.item.get("_recent_home"):
                sid = self.item.get("stream_id") or self.item.get("vod_id")
                if sid:
                    try:
                        raw = get_source_client(self.source).vod_info(sid) or {}
                        merged = dict(self.item)
                        if isinstance(raw.get("movie_data"), dict): merged.update(raw.get("movie_data") or {})
                        if isinstance(raw.get("info"), dict): merged.update(raw.get("info") or {})
                        # Playback identity must always remain from the original row.
                        merged["stream_id"] = self.item.get("stream_id") or merged.get("stream_id") or sid
                        merged["container_extension"] = self.item.get("container_extension") or merged.get("container_extension") or "mp4"
                        merged["_recent_home"] = True
                        self.item = merged
                    except Exception:
                        pass
            tmdb = TMDbClient()
            tid = self.item.get("tmdb_id") or self.item.get("tmdb")
            if not tid:
                clean_title = self._title_norm(self.item.get("name") or self.item.get("title"))
                found = tmdb.search_title(clean_title or (self.item.get("name") or self.item.get("title")), "vod", self._year(self.item) or None)
                tid = (found or {}).get("id")
            if tid:
                self.item["tmdb_id"] = str(tid)
            mem_key = "vod:%s" % str(tid or self._title_norm(self.item.get("name") or self.item.get("title")))
            data = _memory_get(_DETAILS_DATA_CACHE, mem_key)
            if data is None:
                data = tmdb.details_bundle(tid, "vod") if tid else {}
                if data:
                    _memory_put(_DETAILS_DATA_CACHE, mem_key, data, _DETAILS_DATA_CACHE_LIMIT)
            if reactor: reactor.callFromThread(self.applyDetails, data or {})
            else: self.applyDetails(data or {})
        except Exception:
            if reactor: reactor.callFromThread(self.applyDetails, {})
            else: self.applyDetails({})

    def applyDetails(self, data):
        title = data.get("title") or self.item.get("name") or self.item.get("title") or "Movie"
        year = str(data.get("release_date") or self.item.get("releaseDate") or self.item.get("year") or "")[:4]
        rating = data.get("vote_average") or self.item.get("rating") or ""
        genres = ", ".join(x.get("name", "") for x in (data.get("genres") or [])[:3])
        runtime = data.get("runtime") or ""
        self["title"].setText(title)
        self["meta"].setText("  •  ".join(x for x in [year, ("★ %.1f" % float(rating)) if rating else "", genres, ("%s min" % runtime) if runtime else ""] if x))
        self["desc"].setText((data.get("overview") or self.item.get("plot") or self.item.get("description") or "No description available")[:700])
        poster = self._norm(data.get("poster_path") or self.item.get("stream_icon") or self.item.get("cover"), "w500")
        backdrop = self._norm(data.get("backdrop_path") or self.item.get("backdrop_path") or self.item.get("backdrop"), "w1280")
        if poster: self.loadImage(poster, "poster", 350, 525)
        if backdrop: self.loadImage(backdrop, "backdrop", 1920, 1080)
        cast = ((data.get("credits") or {}).get("cast") or [])[:6]
        for i in range(6):
            if i < len(cast):
                name = cast[i].get("name") or ""
                character = cast[i].get("character") or ""
                self["actorLabel%d" % i].setText((name + ("\n" + character if character else ""))[:45])
                profile = self._norm(cast[i].get("profile_path"), "w185")
                if profile: self.loadImage(profile, "actor%d" % i, 128, 128)
            else:
                self["actorLabel%d" % i].setText(tr(""))
        raw = ((data.get("recommendations") or {}).get("results") or [])[:5]
        if len(raw) < 5: raw += ((data.get("similar") or {}).get("results") or [])[:5-len(raw)]
        self.recommendations = [TMDbClient().convert_public(x, "vod") for x in raw[:5]]
        for i in range(5):
            item = self.recommendations[i] if i < len(self.recommendations) else None
            self["recLabel%d" % i].setText((item.get("name") or "")[:34] if item else "")
            if item:
                url = self._norm(item.get("backdrop_path"), "w780")
                if url: self.loadImage(url, "rec%d" % i, 330, 150)
        self.updateFocus()

    def loadImage(self, url, widget, width, height):
        """Render cached art now and queue a non-blocking refresh on a miss."""
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_image_requests", None)
        if requests is None:
            requests = {}
            self._image_requests = requests
        requests[widget] = url
        priority = 100 if widget in ("poster", "backdrop") else 45

        def done(path, w=widget, x=width, y=height, expected=url):
            # Do not paint a late image into a widget that has since been reused.
            if getattr(self, "_image_requests", {}).get(w) != expected:
                return
            key = "%s|%sx%s" % (path, x, y)
            self.decode(path, w, x, y, key)

        request_artwork(url, "details", done, priority=priority)

    def decode(self,path,widget,width,height,mem_key=None):
        key = mem_key or ("%s|%sx%s" % (path, width, height))
        ptr = _memory_get(_DETAILS_PIXMAP_CACHE, key)
        if ptr is not None:
            try:
                self._detail_pixmap_keys.add(key)
                if self[widget].instance: self[widget].instance.setPixmap(ptr)
                return
            except Exception:
                pass
        l=ePicLoad(); self.picloads.append(l)
        def ready(_=None,loader=l,w=widget,k=key):
            try:
                ptr=loader.getData()
                if ptr:
                    self._detail_pixmap_keys.add(k)
                    _memory_put(_DETAILS_PIXMAP_CACHE, k, ptr, _DETAILS_PIXMAP_CACHE_LIMIT)
                    if self[w].instance: self[w].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if loader in self.picloads:
                    self.picloads.remove(loader)
            except Exception:
                pass
        render_width, render_height = scale_size(width, height)
        l.PictureData.get().append(ready); l.setPara((render_width,render_height,1,1,False,1,"#00000000")); l.startDecode(path)

    def updateFocus(self):
        try:
            self["buttonSelector"].setVisible(self.focus=="buttons")
            self["recSelector"].setVisible(self.focus=="recommend" and bool(self.recommendations))
            if self.focus=="buttons": self["buttonSelector"].instance.move(ePoint(sx(475 if self.button_index==0 else 765), sy(415)))
            if self.focus=="recommend": self["recSelector"].instance.move(ePoint(sx(self.REC_X[self.rec_index]), sy(845)))
        except Exception: pass

    def left(self):
        if self.focus=="buttons": self.button_index=max(0,self.button_index-1)
        elif self.focus=="recommend": self.rec_index=max(0,self.rec_index-1)
        self.updateFocus()
    def right(self):
        if self.focus=="buttons": self.button_index=min(1,self.button_index+1)
        elif self.focus=="recommend": self.rec_index=min(max(0,len(self.recommendations)-1),self.rec_index+1)
        self.updateFocus()
    def up(self):
        self.focus="buttons"; self.updateFocus()
    def down(self):
        if self.recommendations: self.focus="recommend"
        self.updateFocus()
    def ok(self):
        if self.focus=="buttons":
            return self.watchSelected() if self.button_index==0 else self.showSources()
        if self.focus=="recommend" and self.recommendations:
            return self.session.open(MovieDetailsScreen,self.source,self.recommendations[self.rec_index],self.server_items)
    def showSources(self):
        if not self.sources_list:
            return self.session.open(MessageBox,"No exact alternate source is available for this movie.",MessageBox.TYPE_INFO)
        rows = [(x.get("name") or x.get("title") or "Source", x) for x in self.sources_list]
        self.session.openWithCallback(self.sourceChosen, SourceChoiceScreen, rows, "EXACT MATCHING SOURCES")
    def sourceChosen(self,item=None):
        if item: self.playItem(item)
    def toggleFavourite(self):
        item = self._playable_item() or self.item
        try:
            from .favorites import toggle_favourite
            added, saved = toggle_favourite(self.source, "vod", item)
            title = item.get("name") or item.get("title") or "الفيلم"
            if not saved:
                self["meta"].setText(tr("Unable to save favorite"))
            elif added:
                self["meta"].setText("★ تمت إضافة %s إلى المفضلات" % title)
            else:
                self["meta"].setText("☆ تمت إزالة %s من المفضلات" % title)
        except Exception as exc:
            self["meta"].setText("تعذر تحديث المفضلة: %s" % exc)

    def watchSelected(self):
        # Watch always starts the originally selected server item when it is playable.
        # It never opens the alternate-source picker.
        item = self._playable_item()
        if not item:
            return self.session.open(MessageBox,"This movie is not available on the current server.",MessageBox.TYPE_INFO)
        return self.playItem(item)
    def playItem(self,item):
        try:
            from .tivimate_player import TiviMatePlayer
            url=get_source_client(self.source).stream_url(item,"vod")
            service=eServiceReference(4097,0,url); service.setName(item.get("name") or "MOVIE")
            self.session.open(TiviMatePlayer,service,item)
        except Exception as exc:
            self.session.open(MessageBox,"Unable to play:\n%s"%exc,MessageBox.TYPE_ERROR)

SOURCE_CHOICE = '''<screen name="SourceChoiceScreen" position="500,200" size="920,680" flags="wfNoBorder" backgroundColor="#20242A">
<widget name="title" position="40,30" size="840,55" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#20242A" transparent="1" halign="center" />
<widget name="list" position="50,110" size="820,490" font="Regular;27" itemHeight="54" scrollbarMode="showOnDemand" backgroundColor="#20242A" foregroundColor="#FFFFFF" selectionBackgroundColor="#3A414B" selectionForegroundColor="#F2D36B" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="50,612" size="820,52" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/source_choice_guide_r69.png" alphatest="blend" zPosition="3" />
</screen>'''

SOURCE_CHOICE = scale_skin(SOURCE_CHOICE)

class SourceChoiceScreen(Screen):
    skin=SOURCE_CHOICE
    def __init__(self,session,rows,title="EXACT MATCHING SOURCES"):
        Screen.__init__(self,session); self.rows=rows or []
        self["title"]=Label(title)
        self["list"]=MenuList([(x[0],x[1]) for x in self.rows])
        self["keys"]=Label(tr("OK Play     EXIT Back"))
        self["guideBar"]=Pixmap()
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{"ok":self.ok,"cancel":self.close,"up":lambda:self["list"].up(),"down":lambda:self["list"].down()},-1)
    def ok(self):
        c=self["list"].getCurrent()
        if c:self.close(c[1])

class ContentHomeScreen(Screen):
    skin = CONTENT_HOME
    TOP = ["Search", "Home", "Live", "Movies", "TV Shows"]
    TOP_X = [90, 285, 480, 675, 870]
    TREND_X = [80, 535, 990, 1445]
    LATEST_X = [80, 295, 510, 725, 940, 1155, 1370, 1585]

    def __init__(self, session, source, kind):
        Screen.__init__(self, session)
        self.source, self.kind = source, kind
        self.focus = "trending"
        self.topIndex = 3 if kind == "vod" else 4
        self.trending, self.latest = [], []
        self.serverItems, self.categoryItems = [], []
        self.categoriesList = []
        self.categoriesLoaded = False
        self.categoryIndex = -1
        self.categoryName = ""
        self.categoryLoadToken = 0
        # Stalker category requests run in a worker.  Do not rely on Twisted
        # being integrated with Enigma2: the eTimer below is the only route that
        # applies a finished red/blue category request to the GUI thread.
        self.stalkerCategoryLoadResult = None
        self.stalkerCategoryPendingToken = None
        self.stalkerCategoryLoadTimer = eTimer()
        try: self.stalkerCategoryLoadTimer.callback.append(self._finishStalkerCategoryLoad)
        except Exception: self.stalkerCategoryLoadTimer.timeout.get().append(self._finishStalkerCategoryLoad)
        self.sortMode = "default"
        self.trendStart = self.trendIndex = self.latestStart = self.latestIndex = 0
        self.downloads, self.picloads = [], []
        self._image_requests = {}
        # VOD list rows frequently contain only poster art.  Delay the richer
        # backdrop lookup briefly so rapid navigation never starts one network
        # request per key press, then discard every stale result by token.
        self._previewRequestId = 0
        self._previewBackdropPending = None
        self._previewBackdropTimer = eTimer()
        try:
            self._previewBackdropTimer.callback.append(self._beginPreviewBackdropLookup)
        except Exception:
            self._previewBackdropTimer.timeout.get().append(self._beginPreviewBackdropLookup)
        for i, text in enumerate(self.TOP): self["top%d" % i] = Label(tr(text))
        self["topSelector"] = Pixmap(); self["clock"] = Label("")
        self["hero"] = Pixmap(); self["logoImage"] = Pixmap(); self["logoTitle"] = Label(""); self["heroMeta"] = Label(""); self["heroDesc"] = Label("")
        self["trendingTitle"] = Label(tr("Today's Trending Movies") if kind == "vod" else tr("Today's Trending Series"))
        self["latestTitle"] = Label(tr("Latest Movies") if kind == "vod" else tr("Latest Series"))
        for i in range(4):
            self["trend%d" % i] = Pixmap(); self["rank%d" % i] = Label("")
            self["trendLabel%d" % i] = Label(""); self["trendRate%d" % i] = Label("")
        for i in range(8):
            self["latest%d" % i] = Pixmap()
            self["latestLabel%d" % i] = Label(""); self["latestRate%d" % i] = Label("")
        self["trendSelector"] = Pixmap(); self["latestSelector"] = Pixmap()
        self["footer"] = Label(""); self["actionButtons"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "ok": self.ok, "cancel": self.close, "red": self.previousCategory, "green": self.categories, "yellow": self.toggleSort,
            "yellowlong": self.addCurrentFavourite, "blue": self.nextCategory
        }, -1)
        self.onLayoutFinish.append(self._layoutReady)
        self.onClose.append(self._releaseArtworkResources)
        self.onClose.append(self._stopStalkerCategoryLoadTimer)

    def _applyArabicHeadingLayout(self):
        if get_language() != "ar":
            return
        try:
            for name, y in (("trendingTitle", 500), ("latestTitle", 772)):
                widget = self[name]
                if widget and widget.instance:
                    widget.instance.move(ePoint(sx(1110), sy(y)))
                    widget.instance.resize(eSize(sx(730), sy(45)))
                    try:
                        widget.instance.setHAlign(2)
                    except Exception:
                        pass
        except Exception:
            pass

    def _layoutReady(self):
        self._applyArabicHeadingLayout()
        self.start()

    def _releaseArtworkResources(self):
        self._image_requests = {}
        self.downloads = []
        self.picloads = []

    def _stopStalkerCategoryLoadTimer(self):
        # Invalidate workers before screen teardown, so a late portal reply
        # cannot attempt to repaint a screen that no longer exists.
        self.categoryLoadToken = getattr(self, "categoryLoadToken", 0) + 1
        self.stalkerCategoryPendingToken = None
        self.stalkerCategoryLoadResult = None
        try:
            self.stalkerCategoryLoadTimer.stop()
        except Exception:
            pass

    def start(self):
        self["clock"].setText(time.strftime("%H:%M", time.localtime()))
        self.updateFocus()
        t = threading.Thread(target=self.worker, name="TiviMateContentHome"); t.daemon = True; t.start()

    def worker(self):
        # Start optional TMDb Trending immediately rather than waiting for a full
        # server catalog.  Both routes remain off the Enigma2 GUI thread.
        trend_thread = threading.Thread(target=self._loadTrending, name="TiviMateTrending")
        trend_thread.daemon = True
        trend_thread.start()
        self._loadServer()

    def _loadServer(self):
        # Stalker catalogs can be very large.  Its small Packages endpoint is
        # loaded first; titles are fetched only after the user opens one Package.
        try:
            client = get_source_client(self.source)
            if self.source.get("type") == "stalker":
                rows, origin = get_cached_categories(self.source, self.kind, client=client, wait_for_server=True)
                categories = filter_categories(self.source, self.kind, rows or [])
                categories = [c for c in categories if str(c.get("category_id") or "")]
                if not categories:
                    raise RuntimeError("Stalker returned no packages. Check Portal URL and MAG MAC, then retry.")
                # A Stalker portal cannot provide a reliable flat VOD/Series
                # catalog.  Seed this page from one real package instead, using
                # the same cache-aware path that already powers category views.
                latest, landing_category, landing_origin = get_stalker_landing_items(
                    self.source, self.kind, client, categories=categories, limit=32
                )
                if reactor:
                    reactor.callFromThread(self.serverReady, latest, latest, categories, landing_category)
                else:
                    self.serverReady(latest, latest, categories, landing_category)
                return
            # Categories are a small independent endpoint.  Fetch them beside the
            # catalog on a cold cache so the first page has both lists ready sooner.
            category_result = {"rows": [], "origin": "error"}

            def load_categories():
                try:
                    rows, origin = get_cached_categories(
                        self.source, self.kind, client=client, wait_for_server=True
                    )
                    category_result["rows"] = rows or []
                    category_result["origin"] = origin
                except Exception:
                    pass

            category_thread = threading.Thread(target=load_categories, name="TiviMateCategories")
            category_thread.daemon = True
            category_thread.start()
            all_items = get_filtered_streams(self.source, self.kind, client)
            category_thread.join()
            raw_categories = category_result.get("rows") or []
            categories = filter_categories(self.source, self.kind, raw_categories)
            categories = [c for c in categories if str(c.get("category_id") or "")]
            latest = self._sortedItems(all_items)
            if reactor:
                reactor.callFromThread(self.serverReady, latest, all_items, categories)
            else:
                self.serverReady(latest, all_items, categories)
        except Exception as exc:
            reactor.callFromThread(self.serverFailed, str(exc)) if reactor else self.serverFailed(str(exc))

    def _loadTrending(self):
        # Trending is optional and must never blank the server posters.
        try:
            tmdb = TMDbClient()
            if not tmdb.configured():
                raise RuntimeError("TMDb API key is not configured")
            trending = tmdb.trending_2026(self.kind, 8)
            if not trending:
                raise RuntimeError("TMDb returned no 2026 trending results")
            reactor.callFromThread(self.trendingReady, trending) if reactor else self.trendingReady(trending)
        except Exception as exc:
            reactor.callFromThread(self.trendingFailed, str(exc)) if reactor else self.trendingFailed(str(exc))

    def serverReady(self, latest, allItems=None, categories=None, landingCategory=None):
        self.serverItems = list(allItems or [])
        self.categoryItems = []
        self.categoriesList = list(categories or [])
        self.categoriesLoaded = True
        self.categoryIndex = -1
        self.categoryName = ""
        landing_id = str((landingCategory or {}).get("category_id") or "")
        if landing_id:
            for index, category in enumerate(self.categoriesList):
                if str(category.get("category_id") or "") == landing_id:
                    self.categoryIndex = index
                    self.categoryName = category.get("category_name") or "Other"
                    self.categoryItems = list(allItems or [])
                    break
        self.latest = latest or []
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle()
        self.renderLatest()
        if self.source.get("type") == "stalker" and not self.latest:
            self["heroDesc"].setText(tr("Stalker packages are ready. Open Categories and select a package to load its titles."))
        if not self.trending:
            self.focus = "latest" if self.latest else "trending"
            self.preview(); self.updateFocus()

    def trendingReady(self, trending):
        self.trending = trending or []
        self.renderTrending()
        if self.trending:
            self.focus = "trending"
            self.trendStart = self.trendIndex = 0
        self.preview(); self.updateFocus()

    def serverFailed(self, msg):
        self.serverItems, self.categoryItems, self.categoriesList = [], [], []
        self.categoriesLoaded = True
        self.latest = []
        self._updateLatestTitle()
        self["heroDesc"].setText("Unable to load the selected server library: %s" % msg)
        self.renderLatest(); self.updateFocus()

    def trendingFailed(self, msg):
        self.trending = []
        self.renderTrending()
        if self.latest:
            self.focus = "latest"
            self.preview()
            self["heroDesc"].setText("TMDb Trending unavailable. Latest content is loaded from your selected server.\n%s" % msg)
        else:
            self["heroDesc"].setText("Unable to load TMDb Trending: %s" % msg)
        self.updateFocus()

    def current(self):
        arr = self.trending if self.focus == "trending" else self.latest
        idx = self.trendStart + self.trendIndex if self.focus == "trending" else self.latestStart + self.latestIndex
        return arr[idx] if 0 <= idx < len(arr) else None

    def toggleFavourite(self):
        item = self.current()
        if not item:
            return
        target = self.matchServerItem(item) if item.get("_tmdb") else item
        if not target:
            self["footer"].setText(tr("This title is not available on the server and cannot be added to favorites"))
            return
        try:
            from .favorites import toggle_favourite
            added, saved = toggle_favourite(self.source, self.kind, target)
            title = target.get("name") or target.get("title") or "العنصر"
            if not saved:
                self["footer"].setText(tr("Unable to save favorite"))
            elif added:
                self["footer"].setText("تمت إضافة %s إلى المفضلات" % title)
            else:
                self["footer"].setText("تمت إزالة %s من المفضلات" % title)
        except Exception as exc:
            self["footer"].setText("تعذر تحديث المفضلة: %s" % exc)

    def addCurrentFavourite(self):
        item = self.current()
        if not item:
            self["footer"].setText(tr("Select a movie or TV show first"))
            return
        target = self.matchServerItem(item) if item.get("_tmdb") else item
        if not target:
            self["footer"].setText(tr("This title is not available on the server and cannot be added to favorites"))
            return
        try:
            from .favorites import is_favourite, add_favourite
            title = target.get("name") or target.get("title") or "العنصر"
            if is_favourite(self.source, self.kind, target):
                self["footer"].setText("%s موجود بالفعل في المفضلات" % title)
            elif add_favourite(self.source, self.kind, target):
                self["footer"].setText("تمت إضافة %s إلى المفضلات" % title)
            else:
                self["footer"].setText(tr("Unable to save favorite"))
        except Exception as exc:
            self["footer"].setText("Unable to save favorite: %s" % exc)

    def norm(self, value):
        if isinstance(value, list): value = value[0] if value else ""
        if isinstance(value, str):
            value = value.strip().replace("\\/", "/")
            if value.startswith("["):
                try: value = (json.loads(value) or [""])[0]
                except Exception: pass
            if value.startswith("/"): value = "https://image.tmdb.org/t/p/w780" + value
        return value or ""

    def imageUrl(self, item, backdrop=False):
        if backdrop:
            return self.norm(item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url"))
        # Latest posters always come from the connected server, never from TMDb.
        return self.norm(item.get("stream_icon") or item.get("cover_big") or item.get("cover") or item.get("movie_image") or item.get("poster") or "")

    def logoUrl(self, item):
        return self.norm(item.get("logo") or item.get("title_logo") or item.get("logo_path") or item.get("clearlogo") or "")

    def setPlaceholder(self, widget, name):
        try: self[widget].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", name))
        except Exception: pass

    def loadImage(self, url, widget, width, height):
        """Show the placeholder immediately; artwork arrives through a 2-job queue."""
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_image_requests", None)
        if requests is None:
            requests = {}
            self._image_requests = requests
        requests[widget] = url
        if widget == "hero":
            priority = 120
        elif widget == "logoImage":
            priority = 100
        elif widget.startswith("trend"):
            priority = 75
        else:
            priority = 50

        def done(path, w=widget, x=width, y=height, expected=url):
            # Slots are reused when the user pages quickly through content.
            if getattr(self, "_image_requests", {}).get(w) != expected:
                return
            self.decode(path, w, x, y)

        request_artwork(url, "contenthome", done, priority=priority)

    def decode(self, path, widget, width, height):
        loader = ePicLoad(); self.picloads.append(loader)
        def ready(_=None, l=loader, w=widget):
            try:
                ptr = l.getData()
                if ptr and self[w].instance: self[w].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        render_width, render_height = scale_size(width, height)
        loader.PictureData.get().append(ready); loader.setPara((render_width, render_height, 1, 1, False, 1, "#00000000")); loader.startDecode(path)

    def _setCardMeta(self, prefix, slot, item):
        title = str((item or {}).get("name") or (item or {}).get("title") or "").strip()
        rating = str((item or {}).get("rating") or (item or {}).get("rating_5based") or "").strip()
        limit = 30 if prefix == "trend" else 16
        self["%sLabel%d" % (prefix, slot)].setText(title[:limit] + ("…" if len(title) > limit else ""))
        self["%sRate%d" % (prefix, slot)].setText(rating[:4])

    def renderTrending(self):
        for slot in range(4):
            idx = self.trendStart + slot
            item = self.trending[idx] if idx < len(self.trending) else None
            self["rank%d" % slot].setText("#%d" % (idx + 1) if item else "")
            self.setPlaceholder("trend%d" % slot, "banner_placeholder.jpg")
            self._setCardMeta("trend", slot, item)
            if item:
                url = self.imageUrl(item, True)
                if url: self.loadImage(url, "trend%d" % slot, 410, 210)
        self._prefetchCards(self.trending, self.trendStart + 4, 4, True, 10)

    def renderLatest(self):
        for slot in range(8):
            idx = self.latestStart + slot
            item = self.latest[idx] if idx < len(self.latest) else None
            self.setPlaceholder("latest%d" % slot, "poster_placeholder.png")
            self._setCardMeta("latest", slot, item)
            if item:
                url = self.imageUrl(item, False)
                if url: self.loadImage(url, "latest%d" % slot, 170, 205)
        self._prefetchCards(self.latest, self.latestStart + 8, 8, False, 5)

    def _prefetchCards(self, items, start, count, backdrop=False, priority=5):
        """Warm only the next page at a low priority without decoding it yet.

        The queue writes the original JPEG/PNG response to disk, so this changes
        timing only; it never alters image dimensions, compression, or poster art.
        """
        for item in list(items or [])[start:start + count]:
            try:
                url = self.imageUrl(item, backdrop)
                if url:
                    request_artwork(url, "contenthome", None, priority=priority)
            except Exception:
                pass

    def updateFocus(self):
        try:
            self["topSelector"].instance.move(ePoint(sx(self.TOP_X[self.topIndex]), sy(88))); self["topSelector"].setVisible(self.focus == "top")
            self["trendSelector"].instance.move(ePoint(sx(self.TREND_X[self.trendIndex]), sy(555))); self["trendSelector"].setVisible(self.focus == "trending" and bool(self.trending))
            self["latestSelector"].instance.move(ePoint(sx(self.LATEST_X[self.latestIndex]), sy(825))); self["latestSelector"].setVisible(self.focus == "latest" and bool(self.latest))
        except Exception: pass

    def preview(self):
        item = self.current()
        if not item:
            return
        # Every move gets a new token.  It guarantees that a slower lookup for
        # a previous poster cannot overwrite the backdrop of the current movie.
        self._previewRequestId += 1
        request_id = self._previewRequestId
        title = (item.get("name") or item.get("title") or "").upper()[:34]
        logo = self.logoUrl(item)
        if logo:
            self["logoTitle"].setText(tr(""))
            self.loadImage(logo, "logoImage", 560, 150)
        else:
            self["logoTitle"].setText(title)
            try:
                self["logoImage"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "transparent.png"))
            except Exception:
                pass
        year = item.get("year") or item.get("releaseDate") or ""
        rating = item.get("rating") or item.get("rating_5based") or ""
        genre = item.get("genre") or ""
        self["heroMeta"].setText("   •   ".join(x for x in [str(year), ("★ " + str(rating)) if rating else "", str(genre)] if x))
        self["heroDesc"].setText((item.get("plot") or item.get("description") or "")[:260])
        back = self.imageUrl(item, True)
        if back:
            self.loadImage(back, "hero", 1920, 520)
        elif self.kind == "vod":
            # The catalog endpoint may omit VOD backdrop_path.  Look it up only
            # for the selected movie and only after navigation settles.
            self._previewBackdropPending = (dict(item), request_id)
            try:
                self._previewBackdropTimer.stop()
                self._previewBackdropTimer.start(180, True)
            except Exception:
                self._beginPreviewBackdropLookup()

    def _beginPreviewBackdropLookup(self):
        pending = self._previewBackdropPending
        self._previewBackdropPending = None
        if not pending:
            return
        item, request_id = pending
        if request_id != self._previewRequestId:
            return
        worker = threading.Thread(
            target=self._lookupMovieBackdrop,
            args=(item, request_id),
            name="TiviMateMovieBackdrop"
        )
        worker.daemon = True
        worker.start()

    def _movieBackdropUrl(self, data):
        data = data or {}
        return self.norm(
            data.get("backdrop_path") or data.get("backdrop") or
            data.get("backdrop_url") or data.get("movie_backdrop")
        )

    def _lookupMovieBackdrop(self, item, request_id):
        """Resolve a true VOD backdrop without blocking the Enigma2 UI."""
        try:
            stream_id = item.get("stream_id") or item.get("vod_id")
            details = {}
            if stream_id:
                raw = get_source_client(self.source).vod_info(stream_id) or {}
                if isinstance(raw.get("movie_data"), dict):
                    details.update(raw.get("movie_data") or {})
                if isinstance(raw.get("info"), dict):
                    details.update(raw.get("info") or {})
                if not details:
                    details.update(raw)
            backdrop = self._movieBackdropUrl(details)
            if not backdrop:
                tmdb = TMDbClient()
                tmdb_id = details.get("tmdb_id") or details.get("tmdb") or item.get("tmdb_id") or item.get("tmdb")
                if not tmdb_id:
                    found = tmdb.search_title(
                        self._normTitle(details.get("name") or item.get("name") or item.get("title")),
                        "vod", self._year(details or item) or None
                    )
                    tmdb_id = (found or {}).get("id")
                bundle = tmdb.details_bundle(tmdb_id, "vod") if tmdb_id else {}
                backdrop = self._movieBackdropUrl(bundle)
            if not backdrop:
                return
            if reactor:
                reactor.callFromThread(self._applyMovieBackdrop, backdrop, request_id)
            else:
                self._applyMovieBackdrop(backdrop, request_id)
        except Exception:
            # Artwork is optional; a network or metadata failure must never
            # interrupt poster browsing or leave the screen in an error state.
            pass

    def _applyMovieBackdrop(self, backdrop, request_id):
        if request_id != self._previewRequestId:
            return
        self.loadImage(backdrop, "hero", 1920, 520)

    def left(self):
        if self.focus == "top": self.topIndex = max(0, self.topIndex - 1)
        elif self.focus == "trending":
            if self.trendIndex > 0: self.trendIndex -= 1
            elif self.trendStart > 0: self.trendStart = max(0, self.trendStart - 4); self.renderTrending()
        else:
            if self.latestIndex > 0: self.latestIndex -= 1
            elif self.latestStart > 0: self.latestStart = max(0, self.latestStart - 8); self.renderLatest()
        self.updateFocus(); self.preview()

    def right(self):
        if self.focus == "top": self.topIndex = min(4, self.topIndex + 1)
        elif self.focus == "trending":
            if self.trendIndex < 3 and self.trendStart + self.trendIndex + 1 < len(self.trending): self.trendIndex += 1
            elif self.trendStart + 4 < len(self.trending): self.trendStart += 4; self.trendIndex = 0; self.renderTrending()
        else:
            if self.latestIndex < 7 and self.latestStart + self.latestIndex + 1 < len(self.latest): self.latestIndex += 1
            elif self.latestStart + 8 < len(self.latest): self.latestStart += 8; self.latestIndex = 0; self.renderLatest()
        self.updateFocus(); self.preview()

    def up(self):
        self.focus = "top" if self.focus == "trending" else ("trending" if self.focus == "latest" else "top")
        self.updateFocus(); self.preview()
    def down(self):
        self.focus = "trending" if self.focus == "top" else ("latest" if self.focus == "trending" else "latest")
        self.updateFocus(); self.preview()

    def _normTitle(self, value):
        text = (value or "").lower()
        text = re.sub(r"\b(ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|uhd|fhd|hd|hevc|x265|x264|hdr|web[- ]?dl|bluray)\b", " ", text)
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"[^a-z0-9]+", " ", text)
        return " ".join(text.split())

    def _year(self, item):
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        m = re.search(r"\b(19|20)\d{2}\b", raw)
        return int(m.group(0)) if m else 0

    def matchServerItem(self, tmdbItem):
        wanted = [self._normTitle(tmdbItem.get("name")), self._normTitle(tmdbItem.get("original_title"))]
        wanted = [x for x in wanted if x]
        target_year = self._year(tmdbItem)
        best = None; best_score = 0.0
        for item in self.serverItems or []:
            candidate = self._normTitle(item.get("name") or item.get("title"))
            if not candidate:
                continue
            year = self._year(item)
            if target_year and year and abs(target_year - year) > 1:
                continue
            score = max([SequenceMatcher(None, w, candidate).ratio() for w in wanted] or [0.0])
            # Exact normalized containment is a strong signal.
            if any(w == candidate for w in wanted): score = 1.0
            elif any(w in candidate or candidate in w for w in wanted): score = max(score, 0.90)
            if target_year and year == target_year: score += 0.04
            if score > best_score:
                best, best_score = item, score
        return best if best_score >= 0.78 else None

    def playTrendingFromServer(self, item):
        match = self.matchServerItem(item)
        if not match:
            return self.session.open(MessageBox, "هذا العمل غير متوفر على السيرفر الحالي.\n\n%s (%s)" % (item.get("name") or "", item.get("year") or ""), MessageBox.TYPE_INFO)
        if self.kind == "series":
            from .ui import SeriesDetailsScreen
            return self.session.open(SeriesDetailsScreen, self.source, match)
        try:
            from .tivimate_player import TiviMatePlayer
            url = get_source_client(self.source).stream_url(match, "vod")
            service = eServiceReference(4097, 0, url)
            service.setName(match.get("name") or item.get("name") or "MOVIE")
            self.session.open(TiviMatePlayer, service, match)
        except Exception as exc:
            self.session.open(MessageBox, "Unable to play:\n%s" % exc, MessageBox.TYPE_ERROR)

    def ok(self):
        from .ui import TiviMateE2Search, TiviMateE2Home, MediaScreen, SeriesDetailsScreen, ServerManager
        from .tivimate_player import TiviMatePlayer
        if self.focus == "top":
            if self.topIndex == 0: return self.session.open(TiviMateE2Search, self.source)
            if self.topIndex == 1: return self.session.open(TiviMateE2Home)
            if self.topIndex == 2: return self.session.open(MediaScreen, self.source, "live")
            if self.topIndex == 3:
                if self.kind == "vod":
                    self.focus = "trending" if self.trending else "latest"
                    self.updateFocus()
                    return
                return self.session.open(ContentHomeScreen, self.source, "vod")
            if self.topIndex == 4:
                if self.kind == "series":
                    self.focus = "trending" if self.trending else "latest"
                    self.updateFocus()
                    return
                return self.session.open(ContentHomeScreen, self.source, "series")
            return
        item = self.current()
        if not item: return
        if self.kind == "series":
            if item.get("_tmdb"):
                match = self.matchServerItem(item)
                if not match:
                    return self.session.open(MessageBox, "This series is not available on the current server.", MessageBox.TYPE_INFO)
                return self.session.open(SeriesDetailsScreen, self.source, match)
            return self.session.open(SeriesDetailsScreen, self.source, item)
        return self.session.open(MovieDetailsScreen, self.source, item, self.serverItems)

    def _sortLabel(self):
        return {"default": "Latest", "name": "Name", "rating": "Rating"}.get(self.sortMode, "Latest")

    def _addedSortValue(self, item):
        """Return a safe sortable timestamp for numeric and Stalker date values."""
        raw = (item or {}).get("added")
        if raw is None:
            return 0
        try:
            value = float(raw)
            # Some portals send Unix time in milliseconds rather than seconds.
            if value != value or value == float("inf") or value == float("-inf"):
                return 0
            if abs(value) >= 100000000000:
                value = value / 1000.0
            return value
        except Exception:
            pass
        try:
            text = str(raw).strip().replace("T", " ")
        except Exception:
            return 0
        # Stalker commonly returns e.g. "2015-08-21 18:35:31".  Parse the
        # standard date-time part and tolerate an optional time-zone suffix.
        for value, pattern in ((text[:19], "%Y-%m-%d %H:%M:%S"), (text[:10], "%Y-%m-%d")):
            try:
                return time.mktime(time.strptime(value, pattern))
            except Exception:
                pass
        return 0

    def _sortedItems(self, items):
        rows = list(items or [])
        if self.sortMode == "name":
            rows.sort(key=lambda x: (x.get("name") or x.get("title") or "").lower())
        elif self.sortMode == "rating":
            def rating_value(x):
                try: return float(x.get("rating") or x.get("rating_5based") or 0)
                except Exception: return 0
            rows.sort(key=rating_value, reverse=True)
        else:
            rows.sort(key=self._addedSortValue, reverse=True)
        return rows

    def _activeItems(self):
        return self.categoryItems if self.categoryIndex >= 0 else self.serverItems

    def _updateLatestTitle(self):
        parts = [tr("Latest Movies") if self.kind == "vod" else tr("Latest Series")]
        if self.categoryName:
            parts.append(self.categoryName)
        if self.sortMode != "default":
            parts.append(self._sortLabel())
        self["latestTitle"].setText("  •  ".join(parts))

    def _changeCategory(self, direction):
        if not self.categoriesLoaded:
            self["heroDesc"].setText(tr("Categories are loading. Please try again in a moment."))
            return
        if not self.categoriesList:
            self["heroDesc"].setText(tr("No enabled categories are available for this library."))
            return
        if direction < 0 and self.categoryIndex < 0:
            self.categoryIndex = len(self.categoriesList) - 1
        else:
            self.categoryIndex = (self.categoryIndex + direction) % len(self.categoriesList)
        category = self.categoriesList[self.categoryIndex]
        category_id = str(category.get("category_id") or "")
        self.categoryName = category.get("category_name") or "Other"
        if not category_id:
            return
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self.categoryItems, self.latest = [], []
        self.latestStart = self.latestIndex = 0
        self.focus = "latest"
        self._updateLatestTitle(); self.renderLatest(); self.updateFocus()
        self["heroDesc"].setText("Loading %s..." % self.categoryName)
        name = "TiviMateNextCategory" if direction > 0 else "TiviMatePreviousCategory"
        is_stalker = self.source.get("type") == "stalker"
        if is_stalker:
            # Supersede any older unfinished category request.  The worker also
            # checks the token before storing a result, preventing an old reply
            # from overwriting a newer red/blue selection.
            self.stalkerCategoryLoadResult = None
            self.stalkerCategoryPendingToken = token
        t = threading.Thread(target=self._loadCategory, args=(token, category_id), name=name)
        t.daemon = True; t.start()
        if is_stalker:
            try:
                self.stalkerCategoryLoadTimer.start(120, True)
            except Exception:
                pass

    def previousCategory(self):
        self._changeCategory(-1)

    def nextCategory(self):
        self._changeCategory(1)

    def _loadCategory(self, token, category_id):
        source = dict(self.source or {})
        try:
            client = get_source_client(source)
            items, origin = get_category_streams(source, self.kind, client, category_id, use_cache=True)
            if source.get("type") == "stalker":
                # Never call Labels/Pixmaps from a Python worker.  This fixes
                # portal category changes on images where Twisted exists but is
                # not attached to Enigma2's GUI event loop.
                if token == getattr(self, "categoryLoadToken", 0):
                    self.stalkerCategoryLoadResult = (token, list(items or []), origin, "")
                return
            if reactor:
                reactor.callFromThread(self.categoryReady, token, items, origin)
            else:
                self.categoryReady(token, items, origin)
        except Exception as exc:
            if source.get("type") == "stalker":
                if token == getattr(self, "categoryLoadToken", 0):
                    self.stalkerCategoryLoadResult = (token, [], "error", str(exc))
                return
            if reactor:
                reactor.callFromThread(self.categoryFailed, token, str(exc))
            else:
                self.categoryFailed(token, str(exc))

    def _finishStalkerCategoryLoad(self):
        """Apply the newest Stalker category result only on the GUI thread."""
        expected = getattr(self, "stalkerCategoryPendingToken", None)
        if expected is None:
            return
        result = self.stalkerCategoryLoadResult
        if result is None:
            if expected == getattr(self, "categoryLoadToken", 0):
                try:
                    self.stalkerCategoryLoadTimer.start(120, True)
                except Exception:
                    pass
            return
        # A completion can race with this callback; erase only the same object
        # that was observed, never a newer result written by a newer worker.
        if self.stalkerCategoryLoadResult is result:
            self.stalkerCategoryLoadResult = None
        token, items, origin, error = result
        if token != getattr(self, "categoryLoadToken", 0) or token != expected:
            if getattr(self, "stalkerCategoryPendingToken", None) == getattr(self, "categoryLoadToken", 0):
                try:
                    self.stalkerCategoryLoadTimer.start(120, True)
                except Exception:
                    pass
            return
        self.stalkerCategoryPendingToken = None
        if error:
            self.categoryFailed(token, error)
        else:
            self.categoryReady(token, items, origin)

    def categoryReady(self, token, items, origin):
        if token != self.categoryLoadToken:
            return
        self.categoryItems = list(items or [])
        self.latest = self._sortedItems(self.categoryItems)
        self.latestStart = self.latestIndex = 0
        self.focus = "latest"
        self._updateLatestTitle(); self.renderLatest(); self.preview(); self.updateFocus()
        if not self.latest:
            if self.source.get("type") == "stalker" and origin == "empty":
                self["heroDesc"].setText("Stalker returned no items for %s. Try another package or refresh the source." % self.categoryName)
            else:
                self["heroDesc"].setText("No titles are available in %s." % self.categoryName)

    def categoryFailed(self, token, msg):
        if token != self.categoryLoadToken:
            return
        self.categoryItems, self.latest = [], []
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle(); self.renderLatest(); self.updateFocus()
        self["heroDesc"].setText("Unable to load %s: %s" % (self.categoryName, msg))

    def toggleSort(self):
        modes = ["default", "name", "rating"]
        try:
            pos = modes.index(self.sortMode)
        except Exception:
            pos = 0
        self.sortMode = modes[(pos + 1) % len(modes)]
        self.latest = self._sortedItems(self._activeItems())
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle(); self.renderLatest(); self.preview(); self.updateFocus()

    def serverList(self):
        from .ui import ServerManager
        self.session.open(ServerManager)
    def categories(self):
        self.session.openWithCallback(self.categoryChosen, ServerCategoryList, self.source, self.kind)

    def categoryChosen(self, selected=None):
        if not selected:
            return
        from .ui import MediaScreen
        self.session.open(MediaScreen, self.source, self.kind, selected.get("id"), selected.get("name"))
