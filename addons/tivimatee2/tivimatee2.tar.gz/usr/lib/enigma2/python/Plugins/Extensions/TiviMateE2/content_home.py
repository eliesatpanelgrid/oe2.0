# -*- coding: utf-8 -*-
from .storage import get_data_root, data_path
from .package_logos import package_logo_path, package_provider_key, package_logo_for_key
import os, time, json, hashlib, threading, random
from collections import OrderedDict
import queue as _queue
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap as _E2ActionMap
from .action_trace import make_traced_actionmap
ActionMap = make_traced_actionmap(_E2ActionMap)
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
from enigma import eServiceReference, ePicLoad, eConsoleAppContainer, ePoint, eTimer, eSize
try:
    from twisted.internet import reactor
except Exception:
    reactor = None
from .core import get_source_client
from .filters import filter_items as filter_items_for_source
from .tmdb_client import TMDbClient, load_settings, backdrop_url
from .rating_cache import split_ranked, enrich_missing
from .filters import get_filtered_streams, get_allowed_category_ids, filter_categories, get_category_streams, get_category_streams_batch, get_cached_categories, get_stalker_landing_items
from difflib import SequenceMatcher
import re
from urllib.parse import urlparse, quote

from .cache_manager import get_cache_dir
from .artwork_queue import request_artwork, prefetch_artwork, artwork_path
from .picload_compat import connect_picture_data
from .display_scale import scale_skin, sx, sy, scale_size
from .i18n import tr, get_language, nav_label
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"

PACKAGE_DIAG_LOG = "/hdd/tivimatee2_packages.log"
_PACKAGE_DIAG_LOCK = threading.Lock()

def _package_diag(event, **fields):
    """Best-effort package diagnostic log; never changes package loading behavior."""
    try:
        parts = [time.strftime("%Y-%m-%d %H:%M:%S"), str(event)]
        for key in sorted(fields):
            value = fields.get(key)
            try:
                text = str(value)
            except Exception:
                text = "<unprintable>"
            text = text.replace("\n", " ").replace("\r", " ")
            parts.append("%s=%s" % (key, text[:500]))
        line = " | ".join(parts) + "\n"
        with _PACKAGE_DIAG_LOCK:
            with open(PACKAGE_DIAG_LOG, "a") as h:
                h.write(line)
    except Exception:
        pass

CONTENT_LANDING_CACHE_DIR = data_path("content_landing")

TITLE_MATCH_CACHE_FILE = data_path("title_matches.json")

HOME_FEED_CACHE_FILE = data_path("home_feeds.json")
_HOME_FEED_CACHE_LOCK = threading.Lock()
_HOME_FEED_CACHE_MAX_AGE = 7 * 24 * 3600


def _home_feed_cache_load():
    try:
        with _HOME_FEED_CACHE_LOCK:
            with open(HOME_FEED_CACHE_FILE, "r") as h:
                data = json.load(h) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _home_feed_cache_save(data):
    try:
        with _HOME_FEED_CACHE_LOCK:
            folder = os.path.dirname(HOME_FEED_CACHE_FILE)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = HOME_FEED_CACHE_FILE + ".tmp"
            with open(tmp, "w") as h:
                json.dump(data, h, separators=(",", ":"), sort_keys=True)
            os.replace(tmp, HOME_FEED_CACHE_FILE)
        return True
    except Exception:
        return False


def _home_feed_cache_key(mode, source=None):
    source = source or {}
    try:
        from .ui import _source_identity
        source_key = str(_source_identity(source) or "")
    except Exception:
        source_key = str(source.get("name") or source.get("url") or "")
    return "%s|%s" % (str(mode or "popular_movies"), source_key)


def _home_feed_cache_get(mode, source=None, allow_stale=True):
    data = _home_feed_cache_load()
    row = data.get(_home_feed_cache_key(mode, source)) or {}
    if not isinstance(row, dict):
        return []
    try:
        age = int(time.time()) - int(row.get("updated") or 0)
    except Exception:
        age = _HOME_FEED_CACHE_MAX_AGE + 1
    mode_text = str(mode or "")
    if mode_text.startswith("backdrop_filtered_smart_"):
        max_age = 6 * 60 * 60
    elif mode_text.startswith("you_might_like_server_"):
        max_age = 12 * 60 * 60
    else:
        max_age = _HOME_FEED_CACHE_MAX_AGE
    if not allow_stale and age > max_age:
        return []
    items = row.get("items") or []
    return [dict(x) for x in items if isinstance(x, dict)]


def _home_feed_cache_put(mode, source, items):
    rows = [dict(x) for x in (items or []) if isinstance(x, dict)]
    if not rows:
        return False
    data = _home_feed_cache_load()
    data[_home_feed_cache_key(mode, source)] = {
        "updated": int(time.time()),
        "items": rows[:30],
    }
    # Bound persistent cache.
    if len(data) > 100:
        ordered = sorted(
            data.items(),
            key=lambda kv: int((kv[1] or {}).get("updated") or 0),
            reverse=True
        )[:80]
        data = dict(ordered)
    return _home_feed_cache_save(data)


_TITLE_MATCH_CACHE_LOCK = threading.Lock()


def _title_match_cache_load():
    try:
        with _TITLE_MATCH_CACHE_LOCK:
            with open(TITLE_MATCH_CACHE_FILE, "r") as h:
                data = json.load(h) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _title_match_cache_save(data):
    try:
        with _TITLE_MATCH_CACHE_LOCK:
            folder = os.path.dirname(TITLE_MATCH_CACHE_FILE)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = TITLE_MATCH_CACHE_FILE + ".tmp"
            with open(tmp, "w") as h:
                json.dump(data, h, separators=(",", ":"), sort_keys=True)
            os.replace(tmp, TITLE_MATCH_CACHE_FILE)
        return True
    except Exception:
        return False


def _title_match_key(source, item):
    try:
        from .ui import _source_identity
        source_key = str(_source_identity(source or {}) or "")
    except Exception:
        source_key = str((source or {}).get("name") or (source or {}).get("url") or "")
    item = item or {}
    tid = str(item.get("tmdb_id") or item.get("id") or "").strip()
    title = str(item.get("_tmdb_title") or item.get("name") or item.get("title") or item.get("original_title") or "").strip().lower()
    year = str(item.get("year") or item.get("release_date") or item.get("releaseDate") or "")[:4]
    return "%s|%s|%s|%s" % (source_key, tid, title, year)


def _title_match_cache_status(source, item):
    """Return (cached, match).

    cached=True with match=None is a real cached miss. This prevents the same
    unsuccessful automatic title search from running again every time details open.
    """
    key = _title_match_key(source, item)
    data = _title_match_cache_load()
    if key not in data:
        return False, None
    row = data.get(key)
    if not isinstance(row, dict):
        return False, None
    if row.get("miss") is True:
        return True, None
    match = row.get("match")
    if isinstance(match, dict):
        return True, dict(match)
    return False, None


def _title_match_cache_get(source, item):
    cached, match = _title_match_cache_status(source, item)
    return match if cached and isinstance(match, dict) else None


def _title_match_cache_put(source, item, match):
    data = _title_match_cache_load()
    key = _title_match_key(source, item)
    if isinstance(match, dict):
        data[key] = {"match": dict(match), "miss": False, "updated": int(time.time())}
    elif match is None:
        # Cache "not found" too. The poster/details placeholder can therefore stay
        # stable without repeating an expensive server search on every open.
        data[key] = {"match": None, "miss": True, "updated": int(time.time())}
    else:
        return False
    if len(data) > 1200:
        ordered = sorted(data.items(), key=lambda kv: int((kv[1] or {}).get("updated") or 0), reverse=True)[:1000]
        data = dict(ordered)
    return _title_match_cache_save(data)



_SERVER_POSTER_KEYS = (
    "stream_icon", "movie_image", "cover", "cover_big", "poster",
    "poster_url", "poster_path", "screenshot_uri", "image"
)

def _server_asset_url(source, value):
    """Normalize artwork supplied by the IPTV provider, never as a TMDb path."""
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ""
    try:
        value = str(value or "").strip().replace("\\/", "/")
    except Exception:
        return ""
    if not value:
        return ""
    # JSON-encoded one-element artwork arrays are common on Xtream forks.
    if value.startswith("["):
        try:
            decoded = json.loads(value)
            if isinstance(decoded, list) and decoded:
                value = str(decoded[0] or "").strip().replace("\\/", "/")
        except Exception:
            pass
    if not value:
        return ""
    if value.startswith("//"):
        base = str((source or {}).get("url") or (source or {}).get("portal") or "")
        scheme = urlparse(base).scheme or "http"
        return scheme + ":" + value
    if value.startswith(("http://", "https://")):
        return value.replace(" ", "%20")

    source = source or {}
    base = str(source.get("url") or source.get("portal") or "").strip().rstrip("/")
    if not base:
        return value.replace(" ", "%20")
    if "://" not in base:
        base = "http://" + base

    try:
        parsed = urlparse(base)
        scheme = parsed.scheme or "http"
        netloc = parsed.netloc
        # Some saved Xtream sources keep port in a separate field.
        port = str(source.get("port") or "").strip()
        if port and ":" not in netloc.rsplit("@", 1)[-1]:
            netloc = "%s:%s" % (netloc, port)
        origin = "%s://%s" % (scheme, netloc)
        if value.startswith("/"):
            return (origin + value).replace(" ", "%20")
        path = (parsed.path or "").rstrip("/")
        return ("%s%s/%s" % (origin, path, value.lstrip("/"))).replace(" ", "%20")
    except Exception:
        return value.replace(" ", "%20")

def _server_poster_url(source, item, extra=None):
    """Extract provider poster from the row and nested info before TMDb fallback."""
    item = item if isinstance(item, dict) else {}
    extra = extra if isinstance(extra, dict) else {}
    mappings = [item]
    info = item.get("info")
    if isinstance(info, dict):
        mappings.append(info)
    if extra:
        mappings.append(extra)
        extra_info = extra.get("info")
        if isinstance(extra_info, dict):
            mappings.append(extra_info)
    for mapping in mappings:
        for key in _SERVER_POSTER_KEYS:
            value = mapping.get(key)
            if value not in (None, "", [], {}):
                url = _server_asset_url(source, value)
                if url:
                    return url
    return ""

def _content_landing_cache_path(source, kind):
    try:
        raw = "%s|%s|%s|%s|%s" % (
            source.get("type") or "", source.get("url") or source.get("portal") or "",
            source.get("username") or "", source.get("mac") or "", kind or ""
        )
        digest = hashlib.md5(raw.encode("utf-8")).hexdigest()
        return os.path.join(CONTENT_LANDING_CACHE_DIR, digest + ".json")
    except Exception:
        return ""

def _load_content_landing_cache(source, kind):
    path = _content_landing_cache_path(source, kind)
    try:
        if not path or not os.path.exists(path):
            return []
        with open(path, "r") as fh:
            data = json.load(fh)
        return list(data.get("items") or [])[:64] if isinstance(data, dict) else []
    except Exception:
        return []

def _save_content_landing_cache(source, kind, items):
    path = _content_landing_cache_path(source, kind)
    try:
        if not path:
            return
        folder = os.path.dirname(path)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump({"saved": int(time.time()), "items": list(items or [])[:64]}, fh)
        try:
            os.replace(tmp, path)
        except AttributeError:
            if os.path.exists(path):
                os.remove(path)
            os.rename(tmp, path)
    except Exception:
        pass

# Fixed-size background pool for frequent ContentHome artwork/category jobs.
# Navigation can generate requests much faster than slow portals/TMDb can answer;
# a thread-per-keypress design eventually exhausts Enigma2.  Keep only four
# workers and coalesce stale jobs by logical key instead.
_CONTENT_BG_QUEUE = _queue.Queue(maxsize=128)
_CONTENT_BG_LOCK = threading.RLock()
_CONTENT_BG_LATEST = {}
_CONTENT_BG_STARTED = [False]
_CONTENT_BG_WORKERS = 4

def _content_bg_worker(index):
    while True:
        try:
            target, args, key, generation = _CONTENT_BG_QUEUE.get()
        except Exception:
            continue
        try:
            if key is not None:
                try:
                    with _CONTENT_BG_LOCK:
                        if _CONTENT_BG_LATEST.get(key) != generation:
                            continue
                except Exception:
                    pass
            try:
                target(*args)
            except Exception:
                pass
        finally:
            try:
                _CONTENT_BG_QUEUE.task_done()
            except Exception:
                pass

def _ensure_content_bg_workers():
    with _CONTENT_BG_LOCK:
        if _CONTENT_BG_STARTED[0]:
            return
        _CONTENT_BG_STARTED[0] = True
        for index in range(_CONTENT_BG_WORKERS):
            worker = threading.Thread(target=_content_bg_worker, args=(index,), name="TiviMateContentPool-%d" % (index + 1))
            worker.daemon = True
            worker.start()

def _submit_content_bg(target, args=(), key=None):
    _ensure_content_bg_workers()
    generation = 0
    if key is not None:
        with _CONTENT_BG_LOCK:
            generation = int(_CONTENT_BG_LATEST.get(key, 0) or 0) + 1
            _CONTENT_BG_LATEST[key] = generation
    try:
        _CONTENT_BG_QUEUE.put_nowait((target, tuple(args or ()), key, generation))
        return True
    except Exception:
        # A saturated queue is safer than allocating more receiver threads.
        # Visible cards/categories naturally request again on the next user move.
        return False

IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")

# Keep recently decoded pixmaps alive in RAM. This avoids ePicLoad decoding again
# when the user reopens the same movie during the current Enigma2 session.
_DETAILS_PIXMAP_CACHE = OrderedDict()
# Decoded pixmaps consume RAM on the receiver.  Keep a small LRU only while a
# details page is open; the full-quality source remains in the disk cache.
_DETAILS_PIXMAP_CACHE_LIMIT = 8
_DETAILS_DATA_CACHE = OrderedDict()
_DETAILS_DATA_CACHE_LIMIT = 24

def _memory_get(cache, key):
    try:
        value = cache.pop(key)
        cache[key] = value
        return value
    except Exception:
        return None

def _memory_put(cache, key, value, limit):
    try:
        if key in cache:
            cache.pop(key)
        cache[key] = value
        while len(cache) > limit:
            cache.popitem(last=False)
    except Exception:
        pass


HOME_APPEARANCE_FILE = data_path("home_appearance.json")

def _content_default_mode(kind):
    """Movies and TV Shows default to no lower poster feed."""
    try:
        with open(HOME_APPEARANCE_FILE, "r") as handle:
            data = json.load(handle) or {}
        key = "movies_content" if kind == "vod" else "series_content"
        return "none"
    except Exception:
        return "none"


def _content_mode_title(kind, mode):
    is_movies = kind == "vod"
    mode = str(mode or "none").strip().lower()
    if mode == "none":
        return ""
    if mode == "prime":
        return "Prime Video Movies" if is_movies else "Prime Video TV Shows"
    return "Netflix Movies" if is_movies else "Netflix TV Shows"


CONTENT_HOME = '''<screen name="ContentHomeScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#181b20">
<eLabel position="0,0" size="1920,1080" backgroundColor="#181b20" zPosition="0" />
<widget name="hero" position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/content_overlay.png" alphatest="blend" zPosition="2" />
<ePixmap position="48,49" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="7" />
<widget name="top0" position="80,35" size="170,52" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="268,49" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="7" />
<widget name="top1" position="300,35" size="170,52" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="488,49" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="7" />
<widget name="top2" position="520,35" size="170,52" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="708,49" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="7" />
<widget name="top3" position="740,35" size="170,52" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="928,49" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="7" />
<widget name="top4" position="960,35" size="170,52" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="1148,49" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="7" />
<widget name="top5" position="1180,35" size="170,52" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="1368,49" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="7" />
<widget name="top6" position="1400,35" size="170,52" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="1588,49" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="7" />
<widget name="top7" position="1620,35" size="170,52" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="topSelector" position="45,79" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/nav_gold.png" alphatest="blend" zPosition="9" />
<ePixmap position="1500,398" size="300,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/hero_logo_badge_wide.png" alphatest="blend" zPosition="5" />
<widget name="logoHintIcon" position="1522,420" size="44,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/logo_hint_icon.png" alphatest="blend" zPosition="6" />
<widget name="logoHint" position="1580,410" size="190,64" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="logoImage" position="1520,412" size="260,60" alphatest="blend" zPosition="7" />
<widget name="logoTitle" position="95,145" size="840,100" font="Regular;56" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="heroMeta" position="100,265" size="820,40" font="Regular;30" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="heroDesc" position="100,320" size="820,110" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<ePixmap position="100,398" size="254,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/hero_play_c.png" alphatest="blend" zPosition="5" />
<widget name="heroPlay" position="112,410" size="230,64" font="Regular;31" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<ePixmap position="368,398" size="284,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/hero_info_c.png" alphatest="blend" zPosition="5" />
<widget name="heroInfo" position="380,410" size="260,64" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendingTitle" position="80,500" size="720,45" font="Regular;34" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="trend0" position="82,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="92,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate0" position="92,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel0" position="148,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend1" position="537,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="535,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="547,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate1" position="547,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel1" position="603,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend2" position="992,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="990,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1002,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate2" position="1002,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel2" position="1058,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend3" position="1447,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="1445,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1457,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate3" position="1457,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel3" position="1513,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="rank0" position="94,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank1" position="549,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank2" position="1004,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank3" position="1459,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="trendSelector" position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_410x210.png" alphatest="blend" zPosition="8" scale="1" />
	<widget name="latestTitle" position="80,772" size="720,45" font="Regular;32" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="latestCategoryName" position="80,772" size="1000,45" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="8" />
	<widget name="latest0" position="82,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell0" position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge0" position="88,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate0" position="88,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel0" position="142,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest1" position="297,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell1" position="295,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge1" position="303,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate1" position="303,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel1" position="357,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest2" position="512,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell2" position="510,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge2" position="518,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate2" position="518,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel2" position="572,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest3" position="727,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell3" position="725,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge3" position="733,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate3" position="733,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel3" position="787,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest4" position="942,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell4" position="940,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge4" position="948,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate4" position="948,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel4" position="1002,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest5" position="1157,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell5" position="1155,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge5" position="1163,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate5" position="1163,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel5" position="1217,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest6" position="1372,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell6" position="1370,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge6" position="1378,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate6" position="1378,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel6" position="1432,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest7" position="1587,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell7" position="1585,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge7" position="1593,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate7" position="1593,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel7" position="1647,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latestSelector" position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_170x205.png" alphatest="blend" zPosition="8" scale="1" />
	<widget name="footer" position="85,1042" size="1750,35" font="Regular;20" foregroundColor="#D4D7DD" backgroundColor="#00000000" transparent="1" halign="center" zPosition="3" />
	<widget name="actionButtons" position="85,1041" size="1750,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/content_action_buttons_r115.png" alphatest="blend" zPosition="4" />
</screen>'''

CONTENT_HOME = scale_skin(CONTENT_HOME)

# Retired accessibility ContentHome skin removed in r150.

CATEGORY_POPUP = '''<screen name="ServerCategoryList" position="300,120" size="1320,840" flags="wfNoBorder" backgroundColor="#071A2B">
<widget name="panel" position="0,0" size="1320,840" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/category_popup_panel.png" alphatest="blend" zPosition="0" />
<widget name="brand" position="28,28" size="230,48" font="Regular;35" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="brandTagline" position="31,78" size="220,26" font="Regular;15" foregroundColor="#6DD8FF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="sideTitle" position="28,150" size="230,32" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="sideText" position="28,192" size="230,120" font="Regular;24" foregroundColor="#E8EDF3" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="packageLogo" position="30,380" size="220,84" alphatest="blend" zPosition="4" />
<widget name="sectionBadge" position="42,696" size="196,35" font="Regular;19" foregroundColor="#FFFFFF" backgroundColor="#0D324A" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="sideHint" position="40,778" size="200,22" font="Regular;15" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="title" position="350,26" size="700,46" font="Regular;38" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="subtitle" position="350,74" size="650,28" font="Regular;26" foregroundColor="#E8EDF3" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="count" position="1030,38" size="225,34" font="Regular;24" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="2" />
<widget name="listHeader" position="367,134" size="400,25" font="Regular;27" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="list" position="350,192" size="890,472" font="Regular;27" itemHeight="58" scrollbarMode="showOnDemand" backgroundColor="#0A2134" foregroundColor="#F5F8FC" selectionBackgroundColor="#E8B83F" selectionForegroundColor="#071A2B" zPosition="2" />
<widget name="keys" position="350,720" size="910,62" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="actionButtons" position="350,733" size="910,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/category_popup_buttons_r67.png" alphatest="blend" zPosition="3" />
</screen>'''

CATEGORY_POPUP = scale_skin(CATEGORY_POPUP)


# ---------------------------------------------------------------------------
# Content category list
# ---------------------------------------------------------------------------

class ServerCategoryList(Screen):
    skin = CATEGORY_POPUP
    def __init__(self, session, source, kind):
        Screen.__init__(self, session)
        self.source, self.kind = source, kind
        self.rows = []
        is_movies = kind == "vod"
        self["panel"] = Pixmap()
        self["brand"] = Label(tr("TiViMate"))
        self["brandTagline"] = Label(tr("IPTV EXPERIENCE"))
        self["sideTitle"] = Label(tr("YOUR LIBRARY"))
        self["sideText"] = Label(tr("Choose a collection\nto browse titles from\nyour selected server."))
        self["sectionBadge"] = Label(tr("MOVIES") if is_movies else tr("TV SHOWS"))
        self["sideHint"] = Label(tr("Press OK to open"))
        self["packageLogo"] = Pixmap()
        self["title"] = Label(tr("MOVIE CATEGORIES") if is_movies else tr("TV SHOW CATEGORIES"))
        self["subtitle"] = Label(tr("Browse the collections available on your server"))
        self["count"] = Label(tr(""))
        self["listHeader"] = Label(tr("AVAILABLE COLLECTIONS"))
        self["list"] = MenuList([])
        self["keys"] = Label("")
        self["actionButtons"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.choose, "cancel": self.close, "up": self.up, "down": self.down,
            "pageUp": self.pageUp, "pageDown": self.pageDown
        }, -1)
        self._categoryLoadToken = 0
        self._categoryLoadResult = None
        self._categoryLoadTimer = eTimer()
        self._packageLogoTimer = eTimer()
        try:
            self._packageLogoTimer_conn = self._packageLogoTimer.timeout.connect(self._updatePackageLogo)
        except Exception:
            try:
                self._packageLogoTimer.callback.append(self._updatePackageLogo)
            except Exception:
                self._packageLogoTimer.timeout.get().append(self._updatePackageLogo)
        try:
            self._categoryLoadTimer_conn = self._categoryLoadTimer.timeout.connect(self._finishCategoryLoad)
        except Exception:
            try:
                self._categoryLoadTimer.callback.append(self._finishCategoryLoad)
            except Exception:
                self._categoryLoadTimer.timeout.get().append(self._finishCategoryLoad)
        try:
            self["list"].onSelectionChanged.append(self._updatePackageLogo)
        except Exception:
            pass
        self.onLayoutFinish.append(self.load)

    def load(self):
        self._categoryLoadToken += 1
        token = self._categoryLoadToken
        source = dict(self.source)
        kind = self.kind
        self._categoryLoadResult = None
        self["count"].setText(tr(""))

        def worker():
            try:
                cats, origin = get_cached_categories(source, kind, get_source_client(source), wait_for_server=True)
                cats = filter_categories(source, kind, cats or [])
                rows = [(entry.get("category_name") or "Other", str(entry.get("category_id") or "")) for entry in cats]
                result = (token, rows, origin, "")
            except Exception as exc:
                result = (token, [], "error", str(exc))
            self._categoryLoadResult = result

        _submit_content_bg(worker, key=("category-popup", id(self)))
        try:
            self._categoryLoadTimer.start(100, False)
        except Exception:
            pass

    def _finishCategoryLoad(self):
        result = self._categoryLoadResult
        if not result:
            try:
                self._categoryLoadTimer.start(100, False)
            except Exception:
                pass
            return
        self._categoryLoadResult = None
        token, rows, origin, error = result
        if token != self._categoryLoadToken:
            return
        if error:
            self["title"].setText(tr("UNABLE TO LOAD CATEGORIES"))
            self["subtitle"].setText(tr("Check the selected server and try again"))
            self["count"].setText(tr("NO COLLECTIONS"))
            self["keys"].setText(error[:120])
            return
        self.rows = rows or []
        self["list"].setList(self.rows)
        self._updatePackageLogo()
        try:
            self._packageLogoTimer.start(120, True)
        except Exception:
            pass
        count = len(self.rows)
        self["count"].setText("%d COLLECTION%s" % (count, "" if count == 1 else "S"))
        if not count:
            self["subtitle"].setText(tr("No enabled collections are available for this server"))


    def _packageBrand(self, name):
        _key, path = package_provider_key(name), package_logo_path(name)
        return os.path.basename(path) if path else ""

    def _updatePackageLogo(self):
        try:
            current = self["list"].getCurrent()
            name = current[0] if current else ""
            path = package_logo_path(name)
            if not path or not os.path.exists(path):
                self["packageLogo"].hide()
                return

            widget = self["packageLogo"]
            try:
                if widget.instance:
                    widget.instance.setPixmapFromFile(path)
            except Exception:
                pass
            widget.show()
        except Exception:
            try:
                self["packageLogo"].hide()
            except Exception:
                pass


    def choose(self):
        current = self["list"].getCurrent()
        if current:
            self.close({"name": current[0], "id": current[1]})

    def up(self):
        self["list"].up()
        self._updatePackageLogo()

    def down(self):
        self["list"].down()
        self._updatePackageLogo()

    def pageUp(self):
        try: self["list"].pageUp()
        except Exception: self["list"].up()
        self._updatePackageLogo()

    def pageDown(self):
        try: self["list"].pageDown()
        except Exception: self["list"].down()
        self._updatePackageLogo()


MOVIE_DETAILS = '''<screen name="MovieDetailsScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#17191D">
<eLabel position="0,0" size="1920,1080" backgroundColor="#17191D" zPosition="0" />
<widget name="backdrop" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/details_overlay.png" alphatest="blend" zPosition="2" />
<widget name="poster" position="65,55" size="350,525" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" scale="1" />
<widget name="providerLogo" position="115,590" size="250,62" alphatest="blend" zPosition="12" />
<widget name="title" position="475,70" size="1040,76" font="Regular;52" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="meta" position="480,155" size="1050,42" font="Regular;24" foregroundColor="#D8DDE5" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="desc" position="480,215" size="1000,190" font="Regular;25" foregroundColor="#F2F4F7" backgroundColor="#00000000" transparent="1" zPosition="4" />
	<widget name="watch" position="480,425" size="270,62" font="Regular;27" foregroundColor="#17191D" backgroundColor="#E8B83F" halign="center" valign="center" zPosition="5" />
	<widget name="sources" position="770,425" size="270,62" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#315976" halign="center" valign="center" zPosition="5" />
	<widget name="buttonSelector" position="475,415" size="280,82" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/details_action_selector_r68.png" alphatest="blend" zPosition="6" />
<widget name="actorsTitle" position="475,520" size="500,40" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="actor0" position="480,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel0" position="445,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor1" position="690,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel1" position="655,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor2" position="900,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel2" position="865,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor3" position="1110,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel3" position="1075,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor4" position="1320,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel4" position="1285,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor5" position="1530,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel5" position="1495,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="recommendTitle" position="65,795" size="500,42" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rec0" position="65,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel0" position="65,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="65,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec1" position="430,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel1" position="430,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="430,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec2" position="795,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel2" position="795,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="795,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec3" position="1160,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel3" position="1160,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="1160,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec4" position="1525,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel4" position="1525,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="1525,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5" />
	<widget name="recSelector" position="65,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_330x198.png" alphatest="blend" zPosition="8" scale="1" />
</screen>'''

MOVIE_DETAILS = scale_skin(MOVIE_DETAILS)


def _movie_continue_row(source, item):
    """Return a real Continue row for this movie, or build the same row shape once."""
    try:
        from .ui import _source_identity
        source_key = str(_source_identity(source) or "")
    except Exception:
        source_key = ""

    wanted_id = str(
        (item or {}).get("stream_id") or
        (item or {}).get("vod_id") or
        (item or {}).get("id") or ""
    )
    wanted_title = str((item or {}).get("name") or (item or {}).get("title") or "").strip().lower()

    # Prefer the actual Continue Watching record if one exists.
    try:
        with open(data_path("resume.json"), "r") as handle:
            rows = json.load(handle) or {}
    except Exception:
        rows = {}

    if isinstance(rows, dict):
        for row in rows.values():
            if not isinstance(row, dict):
                continue
            saved_item = row.get("item") or {}
            servers = row.get("servers") or {}
            if source_key and isinstance(servers, dict) and source_key in servers:
                candidate = servers.get(source_key) or {}
                saved_item = candidate.get("item") or saved_item

            saved_id = str(
                saved_item.get("stream_id") or
                saved_item.get("vod_id") or
                saved_item.get("id") or ""
            )
            saved_title = str(
                saved_item.get("name") or saved_item.get("title") or row.get("title") or ""
            ).strip().lower()

            same = bool(wanted_id and saved_id and wanted_id == saved_id)
            if not same and wanted_title and saved_title:
                same = wanted_title == saved_title
            if same:
                return dict(row)

    # No Continue record yet: resolve the VOD URL once, then build the exact row shape.
    url = get_source_client(source).stream_url(item, "vod")
    if not url:
        return {}

    play_item = dict(item or {})
    play_item.pop("_continue_resume", None)
    play_item.pop("_continue_position", None)
    play_item["_source_type"] = (source or {}).get("type") or ""
    play_item["_source_key"] = source_key
    play_item["_kind"] = "vod"

    try:
        from .ui import _media_service_type
        service_type = int(_media_service_type(source, "vod"))
    except Exception:
        service_type = 4097

    server_entry = {
        "source_key": source_key,
        "source_type": (source or {}).get("type") or "",
        "streamurl": url,
        "service_type": service_type,
        "item": play_item,
    }
    return {
        "title": play_item.get("name") or play_item.get("title") or "MOVIE",
        "source_key": source_key,
        "source_type": (source or {}).get("type") or "",
        "streamurl": url,
        "service_type": service_type,
        "item": play_item,
        "servers": ({source_key: server_entry} if source_key else {}),
    }



# ---------------------------------------------------------------------------
# Movie details screen
# ---------------------------------------------------------------------------

class MovieDetailsScreen(Screen):
    skin = MOVIE_DETAILS
    REC_X = [65, 430, 795, 1160, 1525]
    def __init__(self, session, source, item, server_items=None, source_context=None):
        Screen.__init__(self, session)
        self.source = source
        self.item = item or {}
        self._serverPackageProvider = str(self.item.get("_server_package_provider") or self.item.get("_tmdb_provider") or "")
        self.server_items = list(server_items or [])
        # Recommendations must never follow whichever page/list happens to be
        # current after the details screen opens. Keep a dedicated immutable
        # source context, separate from the provider-wide catalog used by Watch
        # and Other Sources.
        self.source_context = dict(source_context or {})
        self.recommendation_items = list(self.source_context.get("items") or server_items or [])
        self._recommendationCategoryId = str(
            self.source_context.get("category_id") or
            self.item.get("_source_category_id") or self.item.get("category_id") or ""
        ).strip()
        self._recommendationScope = str(
            self.source_context.get("scope") or self.item.get("_source_scope") or "details"
        ).strip()
        self._sourceTitleIndex = None
        self.sources_list = []
        self.recommendations = []
        self._primaryArtworkReady = False
        self._watchResolveStarted = False
        self._watchReady = bool(self.item.get("stream_id") or self.item.get("vod_id"))
        self._sourcesSearchRunning = False
        self._sourcesSearchDone = False
        self._fastVodRowsCache = None
        self._fullVodRowsCache = None
        self._vodSelectedSource = dict(self.source or {})
        self.focus = "buttons"
        self.button_index = 0
        self.rec_index = 0
        self.downloads, self.picloads = [], []
        self._detail_pixmap_keys = set()
        self._image_requests = {}
        # Worker threads never touch Enigma2 widgets directly.  A small GUI
        # poller drains completed work on the main thread; the workers only
        # append plain Python call records to this queue.  This remains safe on
        # Python 3 Enigma2 and does not depend on Twisted reactor integration.
        self._guiDispatchQueue = []
        self._guiDispatchLock = threading.Lock()
        self._guiDispatchClosed = False
        self._guiDispatchTimer = eTimer()
        try:
            self._guiDispatchTimer_conn = self._guiDispatchTimer.timeout.connect(self._drainGuiDispatch)
        except Exception:
            try:
                self._guiDispatchTimer.callback.append(self._drainGuiDispatch)
            except Exception:
                self._guiDispatchTimer.timeout.get().append(self._drainGuiDispatch)
        self["backdrop"] = Pixmap(); self["poster"] = Pixmap()
        self["providerLogo"] = Pixmap()
        self["title"] = Label(self.item.get("name") or self.item.get("title") or "Movie")
        self["meta"] = Label(""); self["desc"] = Label(tr(""))
        self["watch"] = Label(tr("▶  Watch") if self._watchReady else tr("Searching...")); self["sources"] = Label(tr("Press for Other Sources"))
        self["buttonSelector"] = Pixmap(); self["actorsTitle"] = Label(tr("Actors"))
        for i in range(6):
            self["actor%d" % i] = Pixmap()
            self["actorLabel%d" % i] = Label("")
            try:
                self["actor%d" % i].hide()
            except Exception:
                pass
        self["recommendTitle"] = Label(tr("Recommendations"))
        for i in range(5):
            self["rec%d" % i] = Pixmap(); self["recLabel%d" % i] = Label("")
        self["recSelector"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "green": self.watchSelected
        }, -1)
        self.onLayoutFinish.append(self._startGuiDispatch)
        self.onLayoutFinish.append(self._updateProviderLogo)
        self.onLayoutFinish.append(self.start)
        self.onClose.append(self._stopGuiDispatch)
        self.onClose.append(self._releaseArtworkMemory)


    def _updateProviderLogo(self):
        try:
            provider = str((self.item or {}).get("_server_package_provider") or (self.item or {}).get("_tmdb_provider") or self._serverPackageProvider or "").strip().lower()
            if provider == "prime_video":
                provider = "prime"
            path = package_logo_for_key(provider)
            if path and os.path.exists(path):
                self["providerLogo"].instance.setPixmapFromFile(path)
                self["providerLogo"].show()
            else:
                self["providerLogo"].hide()
        except Exception:
            try: self["providerLogo"].hide()
            except Exception: pass


    def _startGuiDispatch(self):
        self._guiDispatchClosed = False
        try:
            self._guiDispatchTimer.start(40, True)
        except Exception:
            pass

    def _queueGui(self, callback, *args):
        if getattr(self, "_guiDispatchClosed", False):
            return
        try:
            self._guiDispatchLock.acquire()
            self._guiDispatchQueue.append((callback, args))
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass

    def _drainGuiDispatch(self):
        if getattr(self, "_guiDispatchClosed", False):
            return
        pending = []
        try:
            self._guiDispatchLock.acquire()
            pending = self._guiDispatchQueue[:]
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass
        for callback, args in pending:
            try:
                callback(*args)
            except Exception:
                pass
        if not getattr(self, "_guiDispatchClosed", False):
            try:
                self._guiDispatchTimer.start(40, True)
            except Exception:
                pass

    def _stopGuiDispatch(self):
        self._guiDispatchClosed = True
        try:
            self._guiDispatchTimer.stop()
        except Exception:
            pass
        try:
            self._guiDispatchLock.acquire()
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass

    def _releaseArtworkMemory(self):
        # The local widgets are destroyed with the screen; release the LRU refs
        # too so large backdrops never accumulate between detail pages.
        self._image_requests = {}
        self.downloads = []
        self.picloads = []
        for key in list(getattr(self, "_detail_pixmap_keys", set())):
            try:
                _DETAILS_PIXMAP_CACHE.pop(key, None)
            except Exception:
                pass
        self._detail_pixmap_keys = set()


    def _deferredServerMatch(self):
        """Resolve a TMDb discovery movie only after its details screen opens."""
        wanted_id = str(self.item.get("tmdb_id") or self.item.get("id") or "").strip()
        wanted = [self._title_norm(self.item.get(field)) for field in ("name", "title", "original_title")]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)

        def row_tmdb_id(row):
            row = row or {}
            for mapping in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
                for key in ("tmdb_id", "tmdb", "tmdbid"):
                    value = mapping.get(key)
                    if value not in (None, ""):
                        try:
                            return str(int(value))
                        except Exception:
                            value = str(value).strip()
                            if value:
                                return value
            return ""

        def match_rows(rows):
            if wanted_id:
                for row in rows or []:
                    if row_tmdb_id(row) == wanted_id:
                        return dict(row)
            best = None
            best_score = 0.0
            for row in rows or []:
                row_year = self._year(row)
                if target_year and row_year and target_year != row_year:
                    continue
                candidates = [self._title_norm((row or {}).get(field)) for field in ("name", "title", "original_title")]
                score = max([self._title_score(a, b) for a in wanted for b in candidates] or [0.0])
                if target_year and row_year:
                    if score < 0.94:
                        continue
                elif score < 0.98:
                    continue
                if score > best_score:
                    best, best_score = dict(row), score
            return best

        # First use the already loaded full Xtream catalogue / warmed Home index.
        match = match_rows(self.server_items or [])
        if match:
            return match

        source = dict(self._vodSelectedSource or {})
        try:
            client = get_source_client(source)
            if source.get("type") == "xtream":
                rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
                return match_rows(rows)
            if source.get("type") == "stalker":
                categories, _origin = get_cached_categories(source, "vod", client=client, wait_for_server=True)
                categories = filter_categories(source, "vod", categories or [])
                for category in categories:
                    category_id = str((category or {}).get("category_id") or "")
                    if not category_id:
                        continue
                    rows, _origin = get_category_streams(
                        source, "vod", client, category_id,
                        use_cache=True, wait_for_server=True
                    )
                    match = match_rows(rows or [])
                    if match:
                        return match
        except Exception:
            pass
        return None



    def _loadDeferredTmdbMovie(self):
        self.loadDetails()



    def start(self):
        self.applyInitialDetails()
        if self._watchReady:
            self._setWatchReady()
        else:
            self._setWatchSearching()
        self.updateFocus()
        # Artwork/details first. No provider-wide Watch/Sources scan here.
        t = threading.Thread(target=self.loadDetails, name="TiviMateMovieDetails")
        t.daemon = True
        t.start()


    def applyInitialDetails(self):
        title = self.item.get("name") or self.item.get("title") or "Movie"
        year = str(self.item.get("releaseDate") or self.item.get("release_date") or self.item.get("year") or "")[:4]
        rating = self.item.get("rating") or self.item.get("vote_average") or self.item.get("rating_5based") or ""
        genre = self.item.get("genre") or ""
        self["title"].setText(title)
        rating_text = ""
        if rating not in (None, ""):
            try:
                rating_text = "★ %.1f" % float(rating)
            except Exception:
                rating_text = "★ %s" % rating
        self["meta"].setText("  •  ".join(x for x in [year, rating_text, str(genre)] if x))
        self["desc"].setText((self.item.get("plot") or self.item.get("description") or "")[:700])
        poster = self.item.get("_resolved_server_poster") or _server_poster_url(self.source, self.item)
        # Details backdrop: paint one already-resolved/current backdrop immediately
        # and keep it stable for this page. Do not repaint a second, different
        # backdrop when TMDb metadata arrives later.
        backdrop = self._norm(
            self.item.get("_tmdb_backdrop") or self.item.get("backdrop_path") or
            self.item.get("backdrop") or self.item.get("backdrop_url"),
            "w1280"
        )
        self._detailBackdropLocked = bool(backdrop)
        if poster:
            self.loadImage(poster, "poster", 350, 525)
        if backdrop:
            self.loadImage(backdrop, "backdrop", 1920, 1080)

    def _norm(self, value, size="w1280"):
        if isinstance(value, list): value = value[0] if value else ""
        if not isinstance(value, str): return ""
        value = value.strip().replace("\\/", "/")
        if value.startswith("/"): value = "https://image.tmdb.org/t/p/%s%s" % (size, value)
        return value


    def _title_norm(self, value):
        # Normalize movie titles across provider packages. Package branding,
        # quality/language tags and year must never stop the same movie matching.
        text = str(value or "").lower().replace("&", " and ")
        text = re.sub(r"\[[^\]]*\]|\([^\)]*\)|\{[^\}]*\}", " ", text)

        # Strip common platform/package labels first.
        text = re.sub(r"\bamazon\s+prime(?:\s+video)?\b", " ", text)
        text = re.sub(r"\bprime\s+video\b", " ", text)
        text = re.sub(r"\bapple\s+tv\+?\b", " ", text)
        text = re.sub(r"\bdisney\+?\b", " ", text)
        text = re.sub(r"\bhbo\s+max\b", " ", text)
        text = re.sub(r"\bparamount\+?\b", " ", text)
        text = re.sub(r"\bnetflix\b", " ", text)

        text = re.sub(
            r"\b(nf|amz|amzn|ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|8k|uhd|fhd|hd|sd|"
            r"hevc|x265|x264|hdr|web[- ]?dl|bluray|brrip|webrip|remux|top|"
            r"2160p|1080p|720p|576p|480p|vod|movies?)\b",
            " ", text
        )
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
        return " ".join(text.split())


    def _year(self, item):
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        m = re.search(r"\b(19|20)\d{2}\b", raw)
        return int(m.group(0)) if m else 0

    def _title_score(self, wanted, candidate):
        """Return a score only for genuinely matching release titles."""
        if not wanted or not candidate:
            return 0.0
        if wanted == candidate:
            return 1.0
        wanted_tokens, candidate_tokens = set(wanted.split()), set(candidate.split())
        if not wanted_tokens or not candidate_tokens:
            return 0.0
        overlap = wanted_tokens & candidate_tokens
        coverage = float(len(overlap)) / float(min(len(wanted_tokens), len(candidate_tokens)))
        union = float(len(wanted_tokens | candidate_tokens))
        jaccard = float(len(overlap)) / union if union else 0.0
        # Partial title containment is safe only when every significant token matches.
        if coverage == 1.0 and min(len(wanted_tokens), len(candidate_tokens)) >= 2:
            return 0.98 if abs(len(wanted_tokens) - len(candidate_tokens)) <= 1 else 0.94
        ratio = SequenceMatcher(None, wanted, candidate).ratio()
        if min(len(wanted_tokens), len(candidate_tokens)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
            return ratio
        return 0.0

    def _playable_item(self):
        if self.item.get("stream_id"):
            return self.item
        return self.sources_list[0] if self.sources_list else None


    def _fullServerVodCatalog(self):
        """Return the complete movie catalog for Other Sources on this server."""
        source = dict(self._vodSelectedSource or {})
        client = get_source_client(source)
        rows = []

        if source.get("type") == "xtream":
            # One provider-wide request includes every VOD package/category.
            try:
                rows = list(client.streams("vod") or [])
            except Exception:
                rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])

        elif source.get("type") == "stalker":
            # Search every real VOD package. Do not restrict to the package
            # from which the details screen was opened.
            try:
                categories = list(client.categories("vod") or [])
            except Exception:
                categories = []

            for category in categories:
                cid = str((category or {}).get("category_id") or
                          (category or {}).get("id") or "").strip()
                if not cid:
                    continue
                try:
                    cat_rows, _origin = get_category_streams(
                        source, "vod", client, cid,
                        use_cache=True, wait_for_server=True
                    )
                    rows.extend(list(cat_rows or []))
                except Exception:
                    try:
                        rows.extend(list(client.streams("vod", cid) or []))
                    except Exception:
                        pass

            if not rows:
                try:
                    rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
                except Exception:
                    rows = []
        else:
            try:
                rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
            except Exception:
                rows = []

        # Deduplicate provider rows while preserving provider/category order.
        out = []
        seen = set()
        for row in rows:
            if not isinstance(row, dict):
                continue
            sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
            key = sid or (
                self._title_norm(row.get("name") or row.get("title") or ""),
                str(row.get("category_id") or ""),
                str(row.get("container_extension") or "")
            )
            if key in seen:
                continue
            seen.add(key)
            out.append(dict(row))
        return out


    def _matchingServerSources(self, rows, exclude_primary=True):
        title_fields = ("name", "title", "original_title")
        wanted = [self._title_norm(self.item.get(field)) for field in title_fields]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)
        primary_id = str(self.item.get("stream_id") or self.item.get("vod_id") or "")
        matches, seen = [], set()

        for row in rows or []:
            row_id = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
            if exclude_primary and primary_id and row_id and row_id == primary_id:
                continue
            unique = row_id or (
                self._title_norm(row.get("name") or row.get("title") or ""),
                str(row.get("category_id") or ""),
                str(row.get("container_extension") or "")
            )
            if unique in seen:
                continue
            candidate_titles = [self._title_norm(row.get(field)) for field in title_fields]
            score = max([self._title_score(w, c) for w in wanted for c in candidate_titles] or [0.0])
            if score < 0.90:
                continue
            row_year = self._year(row)
            if target_year and row_year and abs(target_year-row_year) > 1:
                continue
            matches.append((score, 1 if target_year and row_year == target_year else 0, dict(row)))
            seen.add(unique)

        matches.sort(key=lambda value: (value[0], value[1]), reverse=True)
        return [value[2] for value in matches]


    def _buildSourceTitleIndex(self):
        """Index server rows by normalized title once, avoiding a full fuzzy scan every time."""
        if self._sourceTitleIndex is not None:
            return self._sourceTitleIndex
        index = {}
        for row in self.server_items:
            try:
                seen = set()
                for field in ("name", "title", "original_title"):
                    norm = self._title_norm(row.get(field))
                    if norm and norm not in seen:
                        seen.add(norm)
                        index.setdefault(norm, []).append(row)
            except Exception:
                continue
        self._sourceTitleIndex = index
        return index


    def findSources(self):
        try:
            rows = self._fullServerVodCatalog()
            sources = self._matchingServerSources(rows)

            # Keep a complete warmed catalog for Watch/Recommendations too.
            if rows:
                self.server_items = list(rows)
                self._sourceTitleIndex = None

            # Other Sources means alternate copies only; current playable item
            # is excluded by _matchingServerSources().
            self._queueGui(self.applySources, sources[:24])
        except Exception:
            self._queueGui(self.applySources, [])





    def applySources(self, sources):
        self.sources_list = list(sources or [])
        count = len(self.sources_list)
        if count:
            self["sources"].setText("Other Sources (%d)" % count)
        else:
            self["sources"].setText(tr("No Other Sources"))


    def _recommendationPool(self):
        """Return rows from the movie's real source context, never the current UI page.

        Other Sources is allowed to warm/replace ``self.server_items`` with the
        whole provider catalog. Recommendations deliberately use the separate
        ``recommendation_items`` snapshot and, when possible, lock it to the
        movie's real category_id.
        """
        rows=[dict(x) for x in list(self.recommendation_items or []) if isinstance(x,dict)]
        cid=str(self._recommendationCategoryId or "").strip()

        # RECENT ADDED (Movies) special rule:
        # 1) Prefer the CURRENT movie package/category first.
        # 2) Resolve that package through the existing per-category disk/RAM cache.
        # 3) Only then add candidates from the user's enabled movie filter.
        # Never expand to the whole provider catalog.
        if self._recommendationScope == "movies_recent_filtered":
            client=None
            preferred=[]
            try:
                client=get_source_client(self.source)
                current_cid=str(
                    self.item.get("category_id") or self.item.get("categoryId") or cid or ""
                ).strip()
                allowed=get_allowed_category_ids(self.source,"vod")
                allowed_set=None if allowed is None else set(str(x) for x in allowed if str(x))
                if current_cid and (allowed_set is None or current_cid in allowed_set):
                    package_rows,_origin=get_category_streams(
                        self.source,"vod",client,current_cid,use_cache=True,wait_for_server=True
                    )
                    for entry in list(package_rows or []):
                        if isinstance(entry,dict):
                            item=dict(entry)
                            item["_recent_same_package"]=True
                            preferred.append(item)
            except Exception:
                preferred=[]

            # Keep the current package first. If it cannot fill the rail, append
            # cached/filter-safe candidates from the user's enabled movie packages.
            try:
                filtered_rows=list(get_filtered_streams(self.source,"vod",client or get_source_client(self.source),use_cache=True) or [])
            except Exception:
                filtered_rows=[]

            combined=[]
            seen=set()
            for entry in preferred + [dict(x) for x in filtered_rows if isinstance(x,dict)]:
                sid=str(entry.get("stream_id") or entry.get("vod_id") or entry.get("id") or "").strip()
                title=self._recommendTitleNorm(entry.get("name") or entry.get("title") or "")
                key=("id:"+sid) if sid else ("title:"+title)
                if not key or key in seen:
                    continue
                seen.add(key)
                combined.append(entry)
            if combined:
                return combined

            # Safe fallback: the already-filtered Recent snapshot, never provider-wide data.
            return rows

        # If Home opened a TMDb card, identify the real server row/category from
        # the warmed catalog once. This removes the old 'Home list = context' bug.
        if not cid and self.server_items:
            try:
                matches=self._matchingServerSources(self.server_items, exclude_primary=False)
                if matches:
                    matched=dict(matches[0] or {})
                    cid=str(matched.get("category_id") or matched.get("categoryId") or "").strip()
                    if cid:
                        self._recommendationCategoryId=cid
                        # Preserve the playable server identity on the current item.
                        for key in ("stream_id","vod_id","container_extension","category_id"):
                            if matched.get(key) not in (None,"") and self.item.get(key) in (None,""):
                                self.item[key]=matched.get(key)
            except Exception:
                pass

        if cid:
            filtered=[r for r in rows if str(r.get("category_id") or r.get("categoryId") or "").strip()==cid]
            if filtered:
                return filtered
            # Context rows may be lightweight Home rows. Fetch only this exact
            # category from cache/server instead of falling back to the current page.
            try:
                client=get_source_client(self.source)
                fetched,_origin=get_category_streams(
                    self.source,"vod",client,cid,use_cache=True,wait_for_server=True
                )
                if fetched:
                    return [dict(x) for x in fetched if isinstance(x,dict)]
            except Exception:
                pass

        return rows


    def _serverOnlyTmdbRecommendations(self, data):
        """Fast recommendations from the item's explicit source context only."""
        import random

        rows=self._recommendationPool()
        if not rows:
            return []

        current_id=str(
            self.item.get("stream_id") or
            self.item.get("vod_id") or
            self.item.get("id") or ""
        ).strip()
        current_title=self._recommendTitleNorm(
            self.item.get("name") or self.item.get("title") or ""
        )

        pool=[]
        seen=set()

        for row in rows:
            sid=str(
                row.get("stream_id") or
                row.get("vod_id") or
                row.get("id") or ""
            ).strip()
            title=self._recommendTitleNorm(
                row.get("name") or row.get("title") or ""
            )

            if current_id and sid and sid==current_id:
                continue
            if not current_id and current_title and title==current_title:
                continue

            unique=("id:"+sid) if sid else ("title:"+title)
            if not unique or unique in seen:
                continue
            seen.add(unique)

            # Same-package server row stays fully playable.
            row["_recommend_server_match"]=True
            pool.append(row)

        if not pool:
            return []

        # Recent Added prefers the selected movie's own package first.
        # Randomness is preserved inside each group, while the enabled-filter
        # pool is used only to fill any remaining recommendation slots.
        if self._recommendationScope == "movies_recent_filtered":
            preferred=[x for x in pool if x.get("_recent_same_package")]
            fallback=[x for x in pool if not x.get("_recent_same_package")]
            random.shuffle(preferred)
            random.shuffle(fallback)
            return (preferred[:5] + fallback[:max(0,5-len(preferred))])[:5]

        # Randomize without mutating the package list used by the main screen.
        random.shuffle(pool)
        return pool[:5]



    def loadDetails(self):
        try:
            # r233: Details are cache-first, identical in spirit to the fast TV
            # Shows path.  Opening More Info must never wait on provider vod_info.
            tmdb = TMDbClient()
            raw_title = self.item.get("name") or self.item.get("title") or self.item.get("original_title") or ""
            item_year = self._year(self.item) or None
            provider_tid = self.item.get("tmdb_id") or self.item.get("tmdb")
            title_key = "vod:title:%s:%s" % (self._title_norm(raw_title), str(item_year or ""))
            id_key = "vod:%s" % str(provider_tid or "") if provider_tid else ""

            cached = _memory_get(_DETAILS_DATA_CACHE, id_key) if id_key else None
            if not cached:
                cached = _memory_get(_DETAILS_DATA_CACHE, title_key)
            if cached:
                data = dict(cached)
                if data.get("id"):
                    self.item["tmdb_id"] = str(data.get("id"))
                self._queueGui(self.applyDetails, data)
                return

            tid = provider_tid
            data = {}
            found = None

            # details_bundle and search_title both have persistent disk caches, so
            # repeated visits normally stay local even after a GUI restart.
            if tid:
                try:
                    data = tmdb.details_bundle(tid, "vod") or {}
                except Exception:
                    data = {}

            # If the lightweight content row has no poster, ask the provider for
            # this one movie only. The player already does this and can therefore
            # see artwork that is absent from the catalog row. Keep this targeted
            # to a missing poster so normal browsing remains cache-first/fast.
            if not _server_poster_url(self.source, self.item):
                try:
                    sid = self.item.get("stream_id") or self.item.get("vod_id") or self.item.get("id")
                    if sid and str((self.source or {}).get("type") or "").lower() == "xtream":
                        provider_data = get_source_client(self.source).vod_info(sid) or {}
                        provider_info = provider_data.get("info") if isinstance(provider_data, dict) else {}
                        provider_movie = provider_data.get("movie_data") if isinstance(provider_data, dict) else {}
                        provider_extra = {}
                        if isinstance(provider_movie, dict):
                            provider_extra.update(provider_movie)
                        if isinstance(provider_info, dict):
                            provider_extra.update(provider_info)
                        provider_poster = _server_poster_url(self.source, self.item, extra=provider_extra)
                        if provider_poster:
                            self._queueGui(self.loadImage, provider_poster, "poster", 350, 525)
                            # Keep the resolved provider artwork on this item so
                            # reopening the details screen does not need another
                            # provider-info request. No cache directory changes.
                            self.item["_resolved_server_poster"] = provider_poster
                except Exception:
                    pass

            useful = bool(
                data.get("poster_path") or data.get("backdrop_path") or data.get("overview") or
                ((data.get("credits") or {}).get("cast") or []) or
                ((data.get("recommendations") or {}).get("results") or []) or
                ((data.get("similar") or {}).get("results") or [])
            )

            if not useful and raw_title:
                found = tmdb.search_title(raw_title, "vod", item_year) or {}
                if not found:
                    found = tmdb.search_title(raw_title, "vod", None) or {}
                resolved = (found or {}).get("id") or (found or {}).get("tmdb_id")
                if resolved:
                    tid = resolved
                    try:
                        data = tmdb.details_bundle(tid, "vod") or {}
                    except Exception:
                        data = {}

            if found:
                seed = dict(found)
                seed.update(data or {})
                data = seed

            # Poster-only recovery: use the same title-cleaning artwork search
            # used by the player when the normal details bundle has no poster.
            # This is especially useful for Arabic/provider-tagged titles.
            if raw_title and not (data or {}).get("poster_path"):
                try:
                    artwork = tmdb.search_artwork(raw_title, kind="vod", year=item_year, required_key="poster_path") or {}
                    if artwork.get("poster_path"):
                        seed = dict(artwork)
                        seed.update(data or {})
                        seed["poster_path"] = artwork.get("poster_path")
                        data = seed
                except Exception:
                    pass

            if tid:
                self.item["tmdb_id"] = str(tid)
            data = dict(data or {})
            if data:
                if tid:
                    _memory_put(_DETAILS_DATA_CACHE, "vod:%s" % str(tid), data, _DETAILS_DATA_CACHE_LIMIT)
                _memory_put(_DETAILS_DATA_CACHE, title_key, data, _DETAILS_DATA_CACHE_LIMIT)

            self._queueGui(self.applyDetails, data)
        except Exception:
            self._queueGui(self.applyDetails, {})


    def _startServerRecommendationResolve(self, data):
        snapshot=dict(data or {})
        token="%s:%s" % (
            str(self.item.get("stream_id") or self.item.get("vod_id") or self.item.get("tmdb_id") or ""),
            str(self.item.get("name") or self.item.get("title") or "")
        )
        self._recommendResolveToken=token

        def worker():
            try:
                recs=self._serverOnlyTmdbRecommendations(snapshot)
            except Exception:
                recs=[]
            self._queueGui(self._applyServerRecommendations,token,recs)

        threading.Thread(
            target=worker,
            name="TiviMateServerRecommendations",
            daemon=True
        ).start()

    def _applyServerRecommendations(self, token, recs):
        if token != getattr(self,"_recommendResolveToken",""):
            return
        self.recommendations=list(recs or [])[:5]
        for i in range(5):
            item=self.recommendations[i] if i<len(self.recommendations) else None
            self["recLabel%d" % i].setText((item.get("name") or item.get("title") or "")[:34] if item else "")
            if item:
                # Backdrop only. Never show poster/cover in recommendation cards.
                # Keep the placeholder until a real backdrop is available.
                url=self._norm(
                    item.get("backdrop_path") or item.get("backdrop") or
                    item.get("backdrop_url"),
                    "w780"
                )
                if url:
                    self.loadImage(url,"rec%d" % i,330,150)
        self.updateFocus()
        # r172: do not make the details screen wait for artwork. Queue all
        # recommendation images immediately; failures never block the rail.
        try:
            for rec in list(self.recommendations or []):
                back = self._norm(
                    rec.get("backdrop_path") or rec.get("backdrop") or rec.get("backdrop_url"),
                    "w780"
                )
                if back:
                    request_artwork(back, "backdrops", None, priority=2)
                poster = _server_poster_url(self.source, rec)
                if poster:
                    request_artwork(poster, "posters", None, priority=1)
        except Exception:
            pass
        self._startRecommendationBackdropResolve(token, self.recommendations)


    def _startRecommendationBackdropResolve(self, token, items):
        # Recommendations are already visible at this point. Resolve only
        # backdrop artwork in the background so this never delays the rail.
        rows=[dict(x) for x in list(items or [])[:5] if isinstance(x,dict)]
        if not rows:
            return

        def worker():
            tmdb=TMDbClient()
            updates=[]
            for index,row in enumerate(rows):
                try:
                    title=str(row.get("name") or row.get("title") or "").strip()
                    if not title:
                        continue
                    tid=str(
                        row.get("tmdb_id") or row.get("tmdb") or
                        row.get("tmdbid") or ""
                    ).strip()

                    backdrop=""
                    resolved_id=tid

                    # Fast path when server already provides TMDb ID.
                    if tid:
                        try:
                            details=tmdb.details_bundle(tid,"vod") or {}
                            backdrop=details.get("backdrop_path") or ""
                        except Exception:
                            backdrop=""

                    # Only when no backdrop exists, search this one title.
                    if not backdrop:
                        try:
                            results=tmdb.search(title,"vod") or []
                        except Exception:
                            results=[]
                        if results:
                            first=results[0] or {}
                            resolved_id=str(
                                first.get("tmdb_id") or first.get("id") or ""
                            ).strip()
                            backdrop=first.get("backdrop_path") or ""
                            if not backdrop and resolved_id:
                                try:
                                    details=tmdb.details_bundle(resolved_id,"vod") or {}
                                    backdrop=details.get("backdrop_path") or ""
                                except Exception:
                                    backdrop=""

                    if backdrop:
                        updates.append((index,backdrop,resolved_id))
                except Exception:
                    pass

            self._queueGui(self._applyRecommendationBackdrops,token,updates)

        threading.Thread(
            target=worker,
            name="TiviMateRecommendationBackdrops",
            daemon=True
        ).start()

    def _applyRecommendationBackdrops(self, token, updates):
        if token != getattr(self,"_recommendResolveToken",""):
            return
        for index,backdrop,tid in list(updates or []):
            if not (0 <= int(index) < len(self.recommendations)):
                continue
            try:
                item=self.recommendations[index]
                item["backdrop_path"]=backdrop
                if tid and not item.get("tmdb_id"):
                    item["tmdb_id"]=tid
                url=self._norm(backdrop,"w780")
                if url:
                    self.loadImage(url,"rec%d" % index,330,150)
            except Exception:
                pass


    def applyDetails(self, data):
        self._tmdb_bundle = dict(data or {})
        server_title = self.item.get("name") or self.item.get("title") or ""
        # Preserve Arabic provider titles on screen. TMDb English/localized title
        # is metadata fallback only and must not replace an existing Arabic name.
        if re.search(r"[\u0600-\u06FF]", str(server_title or "")):
            title = server_title
        else:
            title = data.get("title") or server_title or "Movie"
        year = str(data.get("release_date") or self.item.get("releaseDate") or self.item.get("year") or "")[:4]
        rating = data.get("vote_average") or self.item.get("rating") or ""
        genres = ", ".join(x.get("name", "") for x in (data.get("genres") or [])[:3])
        runtime = data.get("runtime") or ""
        self["title"].setText(title)
        self["meta"].setText("  •  ".join(x for x in [year, ("★ %.1f" % float(rating)) if rating else "", genres, ("%s min" % runtime) if runtime else ""] if x))
        self["desc"].setText((data.get("overview") or self.item.get("plot") or self.item.get("description") or "No description available")[:700])
        tmdb_poster = self._norm(data.get("poster_path"), "w500")
        server_poster = self.item.get("_resolved_server_poster") or _server_poster_url(self.source, self.item)
        tmdb_backdrop = self._norm(data.get("backdrop_path"), "w1280")
        server_backdrop = self._norm(self.item.get("backdrop_path") or self.item.get("backdrop") or self.item.get("backdrop_url"), "w1280")
        # r302: server poster is primary. TMDb is used only when the server
        # poster is missing/unavailable; the player itself performs no network lookup.
        poster = server_poster or tmdb_poster
        backdrop = tmdb_backdrop or server_backdrop
        if poster:
            self.item["_player_cover"] = poster
            self.item["poster_path"] = poster
            try:
                self.item["_player_cover_cache"] = artwork_path(poster, "posters")
            except Exception:
                self.item["_player_cover_cache"] = ""
            try:
                if server_poster and tmdb_poster and server_poster != tmdb_poster:
                    self.item["_player_cover_cache_fallback"] = artwork_path(tmdb_poster, "posters")
                else:
                    self.item["_player_cover_cache_fallback"] = ""
            except Exception:
                self.item["_player_cover_cache_fallback"] = ""
        if backdrop:
            self.item["_tmdb_backdrop"] = backdrop
        if data.get("id"):
            self.item["tmdb_id"] = str(data.get("id"))
        if data.get("title"):
            self.item["_tmdb_title"] = data.get("title")
        if poster:
            self.loadImage(
                poster, "poster", 350, 525,
                fallback_url=(tmdb_poster if server_poster and tmdb_poster and poster == server_poster else "")
            )
        else:
            self._primaryArtworkComplete()
        if backdrop and not getattr(self, "_detailBackdropLocked", False):
            # Only fill the backdrop when the page opened without one. If an
            # initial backdrop is already visible, keep it instead of swapping.
            self._detailBackdropLocked = True
            self.loadImage(backdrop, "backdrop", 1920, 1080, fallback_url=(server_backdrop if backdrop != server_backdrop else ""))
        cast = ((data.get("credits") or {}).get("cast") or [])[:6]
        for i in range(6):
            if i < len(cast):
                name = cast[i].get("name") or ""
                character = cast[i].get("character") or ""
                self["actorLabel%d" % i].setText((name + ("\n" + character if character else ""))[:45])
                profile = self._norm(cast[i].get("profile_path"), "w185")
                if profile:
                    self.loadImage(profile, "actor%d" % i, 120, 120)
                else:
                    try:
                        self["actor%d" % i].hide()
                    except Exception:
                        pass
            else:
                self["actorLabel%d" % i].setText(tr(""))
                try:
                    self["actor%d" % i].hide()
                except Exception:
                    pass
        # Recommendations arrive independently after server matching.
        self.recommendations=[]
        for i in range(5):
            self["recLabel%d" % i].setText("")
        self.updateFocus()
        self._startServerRecommendationResolve(data)

    def loadImage(self, url, widget, width, height, fallback_url="", retry=1):
        """Render detail artwork reliably: primary URL, one retry, then fallback."""
        url = (url or "").strip().replace("\\/", "/")
        fallback_url = (fallback_url or "").strip().replace("\\/", "/")
        if not url:
            if fallback_url:
                return self.loadImage(fallback_url, widget, width, height, fallback_url="", retry=0)
            return
        requests = getattr(self, "_image_requests", None)
        if requests is None:
            requests = {}
            self._image_requests = requests
        token = "%s|%s" % (widget, url)
        requests[widget] = token
        priority = 100 if widget in ("poster", "backdrop") else 45

        def done(path, w=widget, x=width, y=height, expected=token):
            if getattr(self, "_image_requests", {}).get(w) != expected:
                return
            key = "%s|%sx%s" % (path, x, y)
            self.decode(path, w, x, y, key)

        def failed(_path, w=widget, primary=url, fb=fallback_url, retries=retry):
            if getattr(self, "_image_requests", {}).get(w) != token:
                return
            if retries > 0:
                # One controlled retry only. request_artwork keeps cache/dedup logic.
                self.loadImage(primary, w, width, height, fallback_url=fb, retry=retries - 1)
            elif fb and fb != primary:
                self.loadImage(fb, w, width, height, fallback_url="", retry=0)

        
        if widget in ("backdrop", "hero") or str(widget).startswith(("trend", "rec")):
            cache_kind = "backdrops"
        elif widget == "logoImage":
            cache_kind = "logos"
        else:
            cache_kind = "posters"
        request_artwork(url, cache_kind, done, priority=priority, errback=failed)

    def _setWatchSearching(self):
        try:
            self["watch"].setText(tr("Searching..."))
            if self["watch"].instance:
                self["watch"].instance.setBackgroundColor(parseColor("#E8B83F"))
                self["watch"].instance.setForegroundColor(parseColor("#17191D"))
        except Exception:
            pass

    def _setWatchReady(self):
        try:
            self["watch"].setText(tr("▶  Watch"))
            if self["watch"].instance:
                self["watch"].instance.setBackgroundColor(parseColor("#2E9D57"))
                self["watch"].instance.setForegroundColor(parseColor("#FFFFFF"))
        except Exception:
            pass

    def _setWatchUnavailable(self):
        try:
            self["watch"].setText(tr("Watch unavailable"))
            if self["watch"].instance:
                self["watch"].instance.setBackgroundColor(parseColor("#555B63"))
                self["watch"].instance.setForegroundColor(parseColor("#FFFFFF"))
        except Exception:
            pass

    def _setSourcesSearching(self):
        try:
            self["sources"].setText(tr("Searching Sources..."))
        except Exception:
            pass



    def _primaryArtworkComplete(self):
        if self._primaryArtworkReady:
            return
        self._primaryArtworkReady = True
        if self._watchReady:
            self._setWatchReady()
            return
        self._startWatchResolve()




    def _fastSearchMovieRows(self):
        """Fast first pass: use the complete warmed catalog, not cached query results."""
        if self._fastVodRowsCache is not None:
            return list(self._fastVodRowsCache)
        rows = []
        try:
            source = dict(self._vodSelectedSource or {})
            client = XtreamClient(source) if source.get("type") == "xtream" else StalkerClient(source)
            rows = list(get_filtered_streams(source, "vod", client, use_cache=True) or [])
        except Exception:
            rows = []
        self._fastVodRowsCache = list(rows or [])
        return list(self._fastVodRowsCache)


    def _fullServerMovieRowsFallback(self):
        """Filtered-only fallback.

        Never expand a movie search into disabled/hidden packages. Both automatic
        and manual resolution obey exactly the same saved category filter.
        """
        if self._fullVodRowsCache is not None:
            return list(self._fullVodRowsCache)
        rows = []
        try:
            source = dict(self._vodSelectedSource or self.source or {})
            client = get_source_client(source)
            rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
        except Exception:
            rows = []
        self._fullVodRowsCache = list(rows or [])
        return list(self._fullVodRowsCache)


    def _fastTitleCandidates(self, rows):
        raw_title = (
            self.item.get("_tmdb_title") or self.item.get("name") or
            self.item.get("title") or self.item.get("original_title") or ""
        )
        query = self._title_norm(raw_title)
        if not query:
            return []

        exact = []
        loose = []
        qtokens = [x for x in query.split() if len(x) > 1]

        for row in rows or []:
            name = self._title_norm(row.get("name") or row.get("title") or row.get("original_title") or "")
            if not name:
                continue
            if name == query:
                exact.append(row)
                continue
            ntokens = [x for x in name.split() if len(x) > 1]
            if query in name or name in query:
                loose.append(row)
                continue
            if qtokens and ntokens and all(token in ntokens for token in qtokens):
                loose.append(row)

        return exact + loose





    def _cachedServerMatch(self):
        cached = _title_match_cache_get(self._vodSelectedSource or self.source, self.item)
        if cached:
            return cached
        return None

    def _cachedServerMatchStatus(self):
        return _title_match_cache_status(self._vodSelectedSource or self.source, self.item)

    def _mergeResolvedMatch(self, match):
        original = dict(self.item or {})
        match = dict(match or {})
        for key in (
            "tmdb_id", "_tmdb_title", "backdrop_path", "rating",
            "plot", "description", "year", "_home_tmdb_feed",
            "_tmdb_provider", "_server_package_provider"
        ):
            if not match.get(key) and original.get(key):
                match[key] = original.get(key)
        self.item = match
        self._watchReady = True
        self._setWatchReady()
        try:
            self._updateProviderLogo()
        except Exception:
            pass

    def _forceWatchResolve(self):
        """Manual deep search from WATCH after an automatic miss."""
        if self._watchResolveStarted:
            return
        self._watchResolveStarted = True
        self._setWatchSearching()

        def worker():
            match = None
            try:
                # Manual retry may bypass a cached miss, but it must NEVER bypass
                # the user's package/category filter.
                cached, cached_match = self._cachedServerMatchStatus()
                if cached_match is not None:
                    match = cached_match
                else:
                    source = dict(self._vodSelectedSource or self.source or {})
                    client = get_source_client(source)
                    rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]
            except Exception:
                match = None

            def finish():
                self._watchResolveStarted = False
                if not match:
                    self._watchReady = False
                    _title_match_cache_put(self._vodSelectedSource or self.source, self.item, None)
                    try:
                        self["watch"].setText(tr("▶  Watch / Search"))
                        if self["watch"].instance:
                            self["watch"].instance.setBackgroundColor(parseColor("#E8B83F"))
                            self["watch"].instance.setForegroundColor(parseColor("#17191D"))
                    except Exception:
                        pass
                    return
                _title_match_cache_put(self._vodSelectedSource or self.source, self.item, match)
                self._mergeResolvedMatch(match)

            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateWatchForceSearch")
        t.daemon = True
        t.start()


    def _startWatchResolve(self):
        if self._watchResolveStarted or self._watchReady:
            return
        self._watchResolveStarted = True
        self._setWatchSearching()

        def worker():
            match = None
            try:
                # 0. Persistent cache includes both successful matches and real misses.
                # A cached miss stops automatic searching immediately.
                cache_known, cache_match = self._cachedServerMatchStatus()
                match = cache_match

                # 1. Already loaded FILTERED page/package data: essentially free.
                if not cache_known and match is None:
                    rows = list(self.server_items or [])
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]

                # 2. Enabled/filtered VOD catalog used by Search.
                if not cache_known and match is None:
                    rows = self._fastSearchMovieRows()
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]

                # 3. Full server VOD only when the fast filtered paths failed.
                if not cache_known and match is None:
                    rows = self._fullServerMovieRowsFallback()
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]
            except Exception:
                match = None

            def finish():
                self._watchResolveStarted = False
                if not match:
                    self._watchReady = False
                    if not cache_known:
                        _title_match_cache_put(self._vodSelectedSource or self.source, self.item, None)
                    try:
                        self["watch"].setText(tr("▶  Watch / Search"))
                        if self["watch"].instance:
                            self["watch"].instance.setBackgroundColor(parseColor("#E8B83F"))
                            self["watch"].instance.setForegroundColor(parseColor("#17191D"))
                    except Exception:
                        pass
                    return
                _title_match_cache_put(self._vodSelectedSource or self.source, self.item, match)
                self._mergeResolvedMatch(match)

            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateWatchFilteredFirst")
        t.daemon = True
        t.start()




    def _searchSourcesOnDemand(self):
        if self._sourcesSearchRunning:
            return
        if self._sourcesSearchDone:
            self.showSources()
            return

        self._sourcesSearchRunning = True
        self._setSourcesSearching()

        def worker():
            sources = []
            used_rows = []
            try:
                exclude_primary = bool(self.item.get("stream_id") or self.item.get("vod_id"))

                # 1. Existing warmed data.
                rows = list(self.server_items or [])
                if rows:
                    candidates = self._fastTitleCandidates(rows)
                    sources = self._matchingServerSources(
                        candidates, exclude_primary=exclude_primary
                    )[:24]
                    used_rows = rows

                # 2. Filtered/enabled Search catalog.
                if not sources:
                    rows = self._fastSearchMovieRows()
                    candidates = self._fastTitleCandidates(rows)
                    sources = self._matchingServerSources(
                        candidates, exclude_primary=exclude_primary
                    )[:24]
                    used_rows = rows

                # 3. Only if still zero, expand to full server VOD.
                if not sources:
                    rows = self._fullServerMovieRowsFallback()
                    candidates = self._fastTitleCandidates(rows)
                    sources = self._matchingServerSources(
                        candidates, exclude_primary=exclude_primary
                    )[:24]
                    used_rows = rows
            except Exception:
                sources = []

            def finish():
                self._sourcesSearchRunning = False
                self._sourcesSearchDone = True
                if used_rows:
                    self.server_items = list(used_rows)
                    self._sourceTitleIndex = None
                self.applySources(sources)
                self.showSources()

            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateSourcesFilteredFirst")
        t.daemon = True
        t.start()


    def decode(self,path,widget,width,height,mem_key=None):
        key = mem_key or ("%s|%sx%s" % (path, width, height))
        ptr = _memory_get(_DETAILS_PIXMAP_CACHE, key)
        if ptr is not None:
            try:
                self._detail_pixmap_keys.add(key)
                if self[widget].instance: self[widget].instance.setPixmap(ptr)
                if str(widget).startswith("actor"):
                    self[widget].show()
                if widget == "poster":
                    self._primaryArtworkComplete()
                return
            except Exception:
                pass
        l=ePicLoad(); self.picloads.append(l)
        def ready(_=None,loader=l,w=widget,k=key):
            try:
                ptr=loader.getData()
                if ptr:
                    self._detail_pixmap_keys.add(k)
                    _memory_put(_DETAILS_PIXMAP_CACHE, k, ptr, _DETAILS_PIXMAP_CACHE_LIMIT)
                    if self[w].instance: self[w].instance.setPixmap(ptr)
                    if str(w).startswith("actor"):
                        self[w].show()
                    if w == "poster":
                        self._primaryArtworkComplete()
            except Exception:
                pass
            try:
                if loader in self.picloads:
                    self.picloads.remove(loader)
            except Exception:
                pass
        render_width, render_height = scale_size(width, height)
        connect_picture_data(l, ready, self, oneshot=True); l.setPara((render_width,render_height,0,0,False,1,"#00000000")); l.startDecode(path)

    def updateFocus(self):
        try:
            self["buttonSelector"].setVisible(self.focus=="buttons")
            self["recSelector"].setVisible(self.focus=="recommend" and bool(self.recommendations))
            if self.focus=="buttons": self["buttonSelector"].instance.move(ePoint(sx(475 if self.button_index==0 else 765), sy(415)))
            if self.focus=="recommend": self["recSelector"].instance.move(ePoint(sx(self.REC_X[self.rec_index]), sy(845)))
        except Exception: pass

    def left(self):
        if self.focus=="buttons": self.button_index=max(0,self.button_index-1)
        elif self.focus=="recommend": self.rec_index=max(0,self.rec_index-1)
        self.updateFocus()
    def right(self):
        if self.focus=="buttons": self.button_index=min(1,self.button_index+1)
        elif self.focus=="recommend": self.rec_index=min(max(0,len(self.recommendations)-1),self.rec_index+1)
        self.updateFocus()
    def up(self):
        self.focus="buttons"; self.updateFocus()
    def down(self):
        if self.recommendations: self.focus="recommend"
        self.updateFocus()

    def _rowTmdbId(self, row):
        row = row or {}
        for mapping in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
            for key in ("tmdb_id", "tmdb", "tmdbid", "tmdbId"):
                value = mapping.get(key)
                if value not in (None, ""):
                    try:
                        return str(int(value))
                    except Exception:
                        value = str(value).strip()
                        if value:
                            return value
        return ""

    def _recommendTitleNorm(self, value):
        text=str(value or "").lower()
        text=text.replace("&"," and ")
        text=re.sub(r"\b(?:netflix|nf|prime video|amazon prime|prime|amz|amzn)\b"," ",text)
        text=re.sub(r"\b(?:4k|uhd|fhd|fullhd|hd|sd|hdr|dv|dolby|atmos|hevc|x265|x264)\b"," ",text)
        text=re.sub(r"\b(?:multi|dual|audio|arabic|english|eng|ar|sub|subs|dub|dubbed)\b"," ",text)
        text=re.sub(r"\b(?:19|20)\d{2}\b"," ",text)
        text=re.sub(r"\([^)]*\)|\[[^]]*\]|\{[^}]*\}"," ",text)
        text=re.sub(r"[^a-z0-9]+"," ",text)
        return " ".join(text.split())

    def _recommendationMatches(self, target, rows):
        target = target or {}
        wanted_id = str(target.get("tmdb_id") or target.get("id") or "").strip()
        wanted_titles = [
            self._recommendTitleNorm(target.get(field))
            for field in ("name", "title", "original_title")
        ]
        wanted_titles = list(dict.fromkeys(x for x in wanted_titles if x))
        target_year = self._year(target)

        ranked = []
        seen = set()
        for row in rows or []:
            if not isinstance(row, dict):
                continue

            sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
            unique = sid or (
                self._title_norm(row.get("name") or row.get("title") or ""),
                str(row.get("category_id") or ""),
                str(row.get("container_extension") or "")
            )
            if unique in seen:
                continue

            exact_tmdb = bool(wanted_id and self._rowTmdbId(row) == wanted_id)
            candidate_titles = [
                self._recommendTitleNorm(row.get(field))
                for field in ("name", "title", "original_title")
            ]
            score = max(
                [self._title_score(w, c) for w in wanted_titles for c in candidate_titles] or [0.0]
            )

            if score < 0.90:
                for wanted in wanted_titles:
                    wanted_tokens = set(wanted.split())
                    if not wanted_tokens:
                        continue
                    for candidate in candidate_titles:
                        candidate_tokens = set(candidate.split())
                        if not candidate_tokens:
                            continue
                        overlap = wanted_tokens & candidate_tokens
                        coverage = float(len(overlap)) / float(max(1, min(len(wanted_tokens), len(candidate_tokens))))
                        if coverage >= 0.90 and len(overlap) >= 2:
                            score = max(score, 0.91)

            if not exact_tmdb and score < 0.84:
                continue

            row_year = self._year(row)
            exact_year = bool(target_year and row_year and target_year == row_year)
            if target_year and row_year and abs(target_year - row_year) > 1 and not exact_tmdb:
                continue

            ranked.append((1 if exact_tmdb else 0, 1 if exact_year else 0, score, dict(row)))
            seen.add(unique)

        ranked.sort(key=lambda value: (value[0], value[1], value[2]), reverse=True)
        return [value[3] for value in ranked]


    def ok(self):
        if self.focus=="buttons":
            if self.button_index==0:
                self.watchSelected()
            else:
                self._searchSourcesOnDemand()
            return
        if self.focus=="recommend" and self.recommendations:
            next_item=dict(self.recommendations[self.rec_index] or {})
            next_item["_source_scope"]=self._recommendationScope
            if self._recommendationCategoryId:
                next_item["_source_category_id"]=self._recommendationCategoryId
            self.session.open(
                MovieDetailsScreen,self.source,next_item,self.server_items,
                {"scope":self._recommendationScope,"category_id":self._recommendationCategoryId,"items":list(self.recommendation_items or [])}
            )
            return
    def showSources(self):
        if not self.sources_list:
            self.session.open(MessageBox,"No exact alternate source is available for this movie.",MessageBox.TYPE_INFO)
            return
        rows = [(x.get("name") or x.get("title") or "Source", x) for x in self.sources_list]
        self.session.openWithCallback(self.sourceChosen, SourceChoiceScreen, rows, "EXACT MATCHING SOURCES")
    def sourceChosen(self,item=None):
        if item: self.playItem(item)
    def toggleFavourite(self):
        item = self._playable_item() or self.item
        try:
            from .favorites import toggle_favourite
            added, saved = toggle_favourite(self.source, "vod", item)
            title = item.get("name") or item.get("title") or "الفيلم"
            if not saved:
                self["meta"].setText(tr("Unable to save favorite"))
            elif added:
                self["meta"].setText("★ تمت إضافة %s إلى المفضلات" % title)
            else:
                self["meta"].setText("☆ تمت إزالة %s من المفضلات" % title)
        except Exception as exc:
            self["meta"].setText("تعذر تحديث المفضلة: %s" % exc)


    def _resolveHomeMovieForPlay(self):
        if getattr(self, "_homePlayResolving", False):
            return

        cached = self._cachedServerMatch()
        if cached:
            self.sources_list = [cached]
            self.playItem(cached)
            return

        # Home passes a warmed server VOD index. Resolve synchronously in memory
        # first; this avoids the visible search delay for Popular/Trending movies.
        if self.server_items:
            wanted = [self._title_norm(self.item.get(field)) for field in ("name","title","original_title")]
            wanted = list(dict.fromkeys(x for x in wanted if x))
            target_year = self._year(self.item)
            best = None
            best_score = 0.0
            for row in self.server_items:
                candidate_titles = [self._title_norm((row or {}).get(field)) for field in ("name","title","original_title")]
                score = max([self._title_score(a,b) for a in wanted for b in candidate_titles] or [0.0])
                if not score:
                    continue
                row_year = self._year(row or {})
                if target_year and row_year and abs(target_year-row_year) > 1:
                    continue
                if target_year and row_year == target_year:
                    score += 0.02
                if score > best_score:
                    best, best_score = dict(row), score
            if best is not None and best_score >= 0.90:
                for key in ("tmdb_id","_tmdb_title","backdrop_path","stream_icon","cover","rating","plot","description","year"):
                    if not best.get(key) and self.item.get(key):
                        best[key] = self.item.get(key)
                _title_match_cache_put(self._vodSelectedSource or self.source, self.item, best)
                self.sources_list = [best]
                self.playItem(best)
                return

        self._homePlayResolving = True
        # Keep WATCH label stable; the lookup is background-only.
        # This avoids a visible loading/search state for short cache misses.
        wanted = [self._title_norm(self.item.get(field)) for field in ("name","title","original_title")]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)
        source = dict(self.source or {})

        def worker():
            best = None
            best_score = 0.0
            try:
                client = get_source_client(source)
                rows = list(self._fullServerVodCatalog() or [])
                for row in rows:
                    candidate_titles = [self._title_norm(row.get(field)) for field in ("name","title","original_title")]
                    score = max([self._title_score(a,b) for a in wanted for b in candidate_titles] or [0.0])
                    if not score:
                        continue
                    row_year = self._year(row)
                    if target_year and row_year and abs(target_year-row_year)>1:
                        continue
                    bonus = 0.02 if target_year and row_year == target_year else 0.0
                    if score + bonus > best_score:
                        best = dict(row); best_score = score + bonus
                if best_score < 0.90:
                    best = None
            except Exception:
                best = None

            def finish():
                self._homePlayResolving = False
                self["watch"].setText(tr("▶  Watch"))
                if not best:
                    self.session.open(MessageBox, tr("This movie is not available on the current server."), MessageBox.TYPE_INFO)
                    return
                # Keep the rich TMDb artwork/details while provider identity drives playback.
                for key in ("tmdb_id","_tmdb_title","backdrop_path","stream_icon","cover","rating","plot","description","year"):
                    if not best.get(key) and self.item.get(key):
                        best[key] = self.item.get(key)
                self.sources_list = [best]
                self.playItem(best)
            self._queueGui(finish)

        t=threading.Thread(target=worker,name="TiviMateHomeMoviePlayResolve")
        t.daemon=True; t.start()


    def watchSelected(self):
        if not self._watchReady:
            self._forceWatchResolve()
            return
        if not (self.item.get("stream_id") or self.item.get("vod_id")):
            self._forceWatchResolve()
            return
        self.playItem(self.item)


    def playItem(self,item):
        try:
            row = _movie_continue_row(self.source, item)
            if not row:
                raise Exception("No playable URL")
            from .ui import play_vod_exact_continue_path
            play_vod_exact_continue_path(
                self.session,
                row,
                current_source=dict(self.source or {}),
                callback=None
            )
        except Exception as exc:
            self.session.open(MessageBox, "Unable to play:\n%s" % exc, MessageBox.TYPE_ERROR)

SOURCE_CHOICE = '''<screen name="SourceChoiceScreen" position="500,200" size="920,680" flags="wfNoBorder" backgroundColor="#20242A">
<widget name="title" position="40,30" size="840,55" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#20242A" transparent="1" halign="center" />
<widget name="list" position="50,110" size="820,490" font="Regular;27" itemHeight="54" scrollbarMode="showOnDemand" backgroundColor="#20242A" foregroundColor="#FFFFFF" selectionBackgroundColor="#3A414B" selectionForegroundColor="#F2D36B" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="50,612" size="820,52" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/source_choice_guide_r69.png" alphatest="blend" zPosition="3" />
</screen>'''

SOURCE_CHOICE = scale_skin(SOURCE_CHOICE)

class SourceChoiceScreen(Screen):
    skin=SOURCE_CHOICE
    def __init__(self,session,rows,title="EXACT MATCHING SOURCES"):
        Screen.__init__(self,session); self.rows=rows or []
        self["title"]=Label(title)
        self["list"]=MenuList([(x[0],x[1]) for x in self.rows])
        self["keys"]=Label(tr("OK Play     EXIT Back"))
        self["guideBar"]=Pixmap()
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{"ok":self.ok,"cancel":self.close,"up":lambda:self["list"].up(),"down":lambda:self["list"].down()},-1)
    def ok(self):
        c=self["list"].getCurrent()
        if c:self.close(c[1])



def _screen_content_dedupe_key(item, kind=""):
    row = item or {}
    tmdb_id = str(row.get("tmdb_id") or row.get("tmdb") or row.get("tmdbId") or "").strip()
    if tmdb_id and tmdb_id not in ("0", "None", "none"):
        return "tmdb:%s:%s" % (str(kind or ""), tmdb_id)
    title = str(row.get("name") or row.get("title") or row.get("original_name") or row.get("original_title") or "").lower().strip()
    title = re.sub(r"[\[\(][^\]\)]*(?:4k|uhd|fhd|full\s*hd|1080p|2160p|720p|hdr|hevc|x265|x264|arabic|english|multi)[^\]\)]*[\]\)]", " ", title, flags=re.I)
    title = re.sub(r"(?<![a-z0-9])(?:4k|uhd|fhd|full\s*hd|1080p|2160p|720p|hdr|hevc|x265|x264)(?![a-z0-9])", " ", title, flags=re.I)
    title = re.sub(r"\s+", " ", re.sub(r"[^a-z0-9\u0600-\u06ff]+", " ", title)).strip()
    year = str(row.get("year") or row.get("release_date") or row.get("releaseDate") or row.get("first_air_date") or "").strip()
    m = re.search(r"(?:19|20)\d{2}", year)
    year = m.group(0) if m else ""
    if title:
        return "title:%s:%s:%s" % (str(kind or ""), title, year)
    provider_id = str(row.get("series_id") or row.get("stream_id") or row.get("vod_id") or row.get("id") or "").strip()
    return "id:%s:%s" % (str(kind or ""), provider_id) if provider_id else ""


def _screen_dedupe_content(items, kind=""):
    out, seen = [], set()
    for item in list(items or []):
        key = _screen_content_dedupe_key(item, kind)
        if key and key in seen:
            continue
        if key:
            seen.add(key)
        out.append(item)
    return out


def prefetch_recent_movies(source, limit=25):
    """Warm only the lightweight Recent Movies snapshot for Home startup.

    This is intentionally metadata-only: no TMDb, details, poster downloads or
    GUI work.  It reuses the exact r161 Recent path and writes the same caches
    that the Movies Recent page reads before its visible refresh.
    """
    source = dict(source or {})
    if not source or source.get("type") not in ("xtream", "stalker"):
        return []
    try:
        limit = max(1, min(25, int(limit or 25)))
    except Exception:
        limit = 25
    try:
        client = get_source_client(source)
        raw_categories, _origin = get_cached_categories(
            source, "vod", client=client, wait_for_server=True
        )
        filtered = filter_categories(source, "vod", raw_categories or [])
        category_ids = []
        seen_categories = set()
        for row in filtered or []:
            if not isinstance(row, dict):
                continue
            cid = str(row.get("category_id") or row.get("id") or row.get("genre_id") or row.get("group_id") or "").strip()
            if cid and cid not in seen_categories:
                seen_categories.add(cid)
                category_ids.append(cid)
        if not category_ids:
            return []

        merged = []
        if source.get("type") == "xtream":
            try:
                all_rows = list(client.streams("vod", "") or [])
            except Exception:
                all_rows = []
            allowed = set(category_ids)
            for item in all_rows:
                if not isinstance(item, dict):
                    continue
                cid = str(item.get("category_id") or item.get("genre_id") or "")
                if cid in allowed:
                    merged.append(item)
        elif hasattr(client, "recent_media_filtered"):
            try:
                merged = list(client.recent_media_filtered("vod", category_ids, limit) or [])
            except Exception:
                merged = []

        def _added(row):
            try:
                return int(str((row or {}).get("added") or (row or {}).get("last_modified") or "0").strip())
            except Exception:
                return 0
        if any(_added(row) for row in merged):
            merged.sort(key=_added, reverse=True)

        dedup, recent = set(), []
        for pos, item in enumerate(merged):
            if not isinstance(item, dict):
                continue
            key = str(item.get("stream_id") or item.get("vod_id") or item.get("id") or "") or ("%s|%d" % (item.get("name") or item.get("title") or "", pos))
            if key in dedup:
                continue
            dedup.add(key)
            recent.append(item)
            if len(recent) >= limit:
                break
        if recent:
            try:
                _home_feed_cache_put("recent_vod", source, recent)
            except Exception:
                pass
            _save_content_landing_cache(source, "vod", recent)
        return recent
    except Exception:
        return []



# ---------------------------------------------------------------------------
# Content home screen
# ---------------------------------------------------------------------------

class ContentHomeScreen(Screen):
    # Independent fixed limits: top backdrop row is always 12,
    # while Popular/Trending poster content remains 50.
    BACKDROP_ITEM_LIMIT = 12
    POSTER_ITEM_LIMIT = 50

    skin = CONTENT_HOME

    TOP = ["Search", "Home", "Live", "Movies", "TV Shows", "Packages", "Continue Watching", "Settings"]
    TOP_X = [40, 260, 480, 700, 920, 1140, 1360, 1580]
    TOP_W = [210, 210, 210, 210, 210, 210, 210, 210]
    TREND_X = [80, 535, 990, 1445]
    LATEST_X = [80, 295, 510, 725, 940, 1155, 1370, 1585]

    def _title_score(self, wanted, candidate):
        """Strict normalized title score used by Popular/Trending server matching."""
        if not wanted or not candidate:
            return 0.0
        if wanted == candidate:
            return 1.0
        wanted_tokens = set(wanted.split())
        candidate_tokens = set(candidate.split())
        if not wanted_tokens or not candidate_tokens:
            return 0.0
        overlap = wanted_tokens & candidate_tokens
        coverage = float(len(overlap)) / float(min(len(wanted_tokens), len(candidate_tokens)))
        union = float(len(wanted_tokens | candidate_tokens))
        jaccard = float(len(overlap)) / union if union else 0.0

        # Safe containment only when nearly the whole meaningful title matches.
        if coverage == 1.0 and min(len(wanted_tokens), len(candidate_tokens)) >= 2:
            return 0.98 if abs(len(wanted_tokens) - len(candidate_tokens)) <= 1 else 0.94

        ratio = SequenceMatcher(None, wanted, candidate).ratio()
        if min(len(wanted_tokens), len(candidate_tokens)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
            return ratio
        return 0.0



    def __init__(self, session, source, kind, initialMode=None):
        Screen.__init__(self, session)
        self._pageOpenBusy = False
        self.source, self.kind = source, kind
        self.contentGeneration = 0
        self.contentMode = _content_default_mode(kind)

        # Recent has its own request generation and stable last-good result.
        # An old/empty response is never allowed to erase a newer visible row.
        self.recentRequestToken = 0
        self.recentStable = []
        self.focus = "top"
        self.topIndex = 3 if kind == "vod" else 4
        self.trending, self.latest = [], []
        self.serverItems, self.categoryItems = [], []
        self.categoriesList = []
        # Fast package switching: build category indexes once, then every
        # red/blue package change is RAM-only with no timer/network wait.
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        # Complete package responses loaded in this screen only.
        # Key = exact provider category_id, value = full provider response.
        self._fullPackageRows = {}
        self._categorySwitchPreviewNow = False
        self.categoriesLoaded = False
        self.categoryIndex = -1
        self.categoryName = ""
        self._updateLatestTitle()
        self.categoryLoadToken = 0
        # Stalker category requests run in a worker.  Do not rely on Twisted
        # being integrated with Enigma2: the eTimer below is the only route that
        # applies a finished red/blue category request to the GUI thread.
        self.stalkerCategoryLoadResult = None
        self.stalkerCategoryPendingToken = None
        self.stalkerCategoryLoadTimer = eTimer()
        try:
            self._stalkerCategoryLoadTimer_conn = self.stalkerCategoryLoadTimer.timeout.connect(self._finishStalkerCategoryLoad)
        except Exception:
            try:
                self.stalkerCategoryLoadTimer.callback.append(self._finishStalkerCategoryLoad)
            except Exception:
                self.stalkerCategoryLoadTimer.timeout.get().append(self._finishStalkerCategoryLoad)
        self.sortMode = "default"
        self.trendStart = self.trendIndex = self.latestStart = self.latestIndex = 0
        self.downloads, self.picloads = [], []
        self._image_requests = {}
        # One main-thread dispatcher is used for every worker result on Movies
        # and TV Shows.  Network/poster work stays in the background exactly as
        # before; only the final widget update is serialized on Enigma2's GUI
        # thread.  This prevents red/blue/yellow/navigation restarts on images
        # where Twisted exists but is not integrated with the Enigma2 mainloop.
        self._guiDispatchQueue = []
        self._guiDispatchLock = threading.Lock()
        self._guiDispatchClosed = False
        self._guiDispatchTimer = eTimer()
        try:
            self._guiDispatchTimer_conn = self._guiDispatchTimer.timeout.connect(self._drainGuiDispatch)
        except Exception:
            try:
                self._guiDispatchTimer.callback.append(self._drainGuiDispatch)
            except Exception:
                self._guiDispatchTimer.timeout.get().append(self._drainGuiDispatch)
        # VOD list rows frequently contain only poster art.  Delay the richer
        # backdrop lookup briefly so rapid navigation never starts one network
        # request per key press, then discard every stale result by token.
        self._previewRequestId = 0
        self._previewBackdropPending = None
        # r233: Movies metadata uses the same cache-first path as TV Shows.
        # Visible movie cards are warmed quietly so hero/details navigation does
        # not wait for a fresh TMDb search on every key press.
        self._metadataWarmKeys = set()
        self._previewBackdropTimer = eTimer()
        try:
            self._previewBackdropTimer_conn = self._previewBackdropTimer.timeout.connect(self._beginPreviewBackdropLookup)
        except Exception:
            try:
                self._previewBackdropTimer.callback.append(self._beginPreviewBackdropLookup)
            except Exception:
                self._previewBackdropTimer.timeout.get().append(self._beginPreviewBackdropLookup)
        for i, text in enumerate(self.TOP): self["top%d" % i] = Label(nav_label(text))
        self["topSelector"] = Pixmap()
        self["hero"] = Pixmap(); self["logoImage"] = Pixmap(); self["logoHintIcon"] = Pixmap(); self["logoHint"] = Label("LOGO"); self["logoTitle"] = Label(""); self["heroMeta"] = Label(""); self["heroDesc"] = Label("")
        self["heroPlay"] = Label("▶  " + tr("Play")); self["heroInfo"] = Label("ⓘ  More Info")
        # Fixed top hero/trending title. Setting #6 only changes the lower row.
        primary_title = "Movies You Might Like" if kind == "vod" else "TV Shows You Might Like"
        self["trendingTitle"] = Label(tr(primary_title))
        self["latestTitle"] = Label(tr(_content_mode_title(kind, self.contentMode)))
        self["latestCategoryName"] = Label("")
        for i in range(4):
            self["trend%d" % i] = Pixmap(); self["rank%d" % i] = Label("")
            self["trendLabel%d" % i] = Label(""); self["trendRate%d" % i] = Label("")
        for i in range(8):
            self["latest%d" % i] = Pixmap()
            self["latestShell%d" % i] = Pixmap()
            self["latestBadge%d" % i] = Pixmap()
            self["latestLabel%d" % i] = Label(""); self["latestRate%d" % i] = Label("")
        self["trendSelector"] = Pixmap(); self["latestSelector"] = Pixmap()
        self["footer"] = Label(""); self["actionButtons"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "ok": self.ok, "cancel": self.close, "red": self.previousCategory, "green": self.categories, "yellow": self.toggleSort,
            "yellowlong": self.addCurrentFavourite, "blue": self.nextCategory
        }, -1)
        self.onLayoutFinish.append(self._layoutReady)
        self.onClose.append(self._stopGuiDispatch)
        self.onClose.append(self._releaseArtworkResources)
        self.onClose.append(self._stopStalkerCategoryLoadTimer)

    def _startGuiDispatch(self):
        self._guiDispatchClosed = False
        try:
            self._guiDispatchTimer.start(40, True)
        except Exception:
            pass

    def _queueGui(self, callback, *args):
        if getattr(self, "_guiDispatchClosed", False):
            return
        try:
            self._guiDispatchLock.acquire()
            self._guiDispatchQueue.append((callback, args))
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass

    def _drainGuiDispatch(self):
        if getattr(self, "_guiDispatchClosed", False):
            return
        pending = []
        try:
            self._guiDispatchLock.acquire()
            pending = self._guiDispatchQueue[:]
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass
        for callback, args in pending:
            try:
                callback(*args)
            except Exception:
                pass
        if not getattr(self, "_guiDispatchClosed", False):
            try:
                self._guiDispatchTimer.start(40, True)
            except Exception:
                pass

    def _stopGuiDispatch(self):
        self._guiDispatchClosed = True
        try:
            self._guiDispatchTimer.stop()
        except Exception:
            pass
        try:
            self._guiDispatchLock.acquire()
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass

    def _applyArabicHeadingLayout(self):
        if get_language() != "ar":
            return
        try:
            for name, y in (("trendingTitle", 500), ("latestTitle", 772)):
                widget = self[name]
                if widget and widget.instance:
                    widget.instance.move(ePoint(sx(1110), sy(y)))
                    widget.instance.resize(eSize(sx(730), sy(45)))
                    try:
                        widget.instance.setHAlign(2)
                    except Exception:
                        pass
        except Exception:
            pass

    def _layoutReady(self):
        self._applyArabicHeadingLayout()
        self._positionLatestCategoryName()
        self._startGuiDispatch()
        self.start()

    def _releaseArtworkResources(self):
        self._image_requests = {}
        self.downloads = []
        self.picloads = []

    def _stopStalkerCategoryLoadTimer(self):
        # Invalidate workers before screen teardown, so a late portal reply
        # cannot attempt to repaint a screen that no longer exists.
        self.categoryLoadToken = getattr(self, "categoryLoadToken", 0) + 1
        self.stalkerCategoryPendingToken = None
        self.stalkerCategoryLoadResult = None
        try:
            self.stalkerCategoryLoadTimer.stop()
        except Exception:
            pass

    def start(self):
        # Recent opens from a dedicated last-good cache. Keep it visible while
        # the server refresh runs; never blank the row during a second request.
        if self.contentMode == "recent":
            cache_mode = "recent_%s" % self.kind
            cached_latest = _home_feed_cache_get(cache_mode, self.source, allow_stale=True)
            if not cached_latest:
                cached_latest = _load_content_landing_cache(self.source, self.kind)
            if cached_latest:
                self.recentStable = self._sortedItems(cached_latest)
                self.latest = _screen_dedupe_content(self.recentStable, self.kind)
                self.latestStart = self.latestIndex = 0
                self.categoryName = "RECENT ADDED"
                self._updateLatestTitle()
                self.renderLatest()
        self.updateFocus()
        generation = self.contentGeneration
        t = threading.Thread(target=self.worker, args=(generation,), name="TiviMateContentHome"); t.daemon = True; t.start()

    def worker(self, generation=None):
        if generation is None:
            generation = self.contentGeneration
        trend_thread = threading.Thread(target=self._loadTrending, args=(generation,), name="TiviMateTrending")
        trend_thread.daemon = True
        trend_thread.start()
        self._loadServer(generation)

    def _loadServer(self, generation=None):
        if generation is None:
            generation = self.contentGeneration
        source = dict(self.source or {})
        kind = self.kind
        try:
            client = get_source_client(source)

            # FILTER IS AUTHORITATIVE.
            _package_diag("LOAD_SERVER_BEGIN", source=source.get("name") or source.get("url") or "", source_type=source.get("type") or "", kind=kind, mode=self.contentMode)
            raw_categories, _origin = get_cached_categories(
                source, kind, client=client, wait_for_server=True
            )
            filtered = filter_categories(source, kind, raw_categories or [])
            _package_diag("CATEGORIES", kind=kind, origin=_origin, raw_count=len(raw_categories or []), filtered_count=len(filtered or []))

            # Keep provider category rows untouched.  Only accept rows that have
            # a real provider id usable by the same endpoint as the big page.
            categories = []
            seen = set()
            for row in filtered:
                if not isinstance(row, dict):
                    continue
                cid = str(
                    row.get("category_id")
                    or row.get("id")
                    or row.get("genre_id")
                    or row.get("group_id")
                    or ""
                ).strip()
                if not cid or cid in seen:
                    continue
                seen.add(cid)
                entry = dict(row)
                entry["category_id"] = cid
                if not entry.get("category_name"):
                    entry["category_name"] = (
                        entry.get("name")
                        or entry.get("title")
                        or entry.get("genre")
                        or "Other"
                    )
                categories.append(entry)
                _package_diag("CATEGORY_ENABLED", kind=kind, category_id=cid, category_name=entry.get("category_name") or "")

            _package_diag("CATEGORIES_READY", kind=kind, count=len(categories))
            if not categories:
                raise RuntimeError("No enabled packages are available for this library.")

            # Recent Added remains its own setting/feed.  It does not modify the
            # normal package list or package navigation.
            if self.contentMode == "recent":
                # r140: Recent Added is intentionally simple. Build the Recent
                # ordering, keep only the newest twenty-five rows, and resolve TMDb
                # metadata for those twenty-five only. No partial first-package paint,
                # no progressive 5+5 worker, and no metadata work for the rest.
                self.recentRequestToken += 1
                recent_token = self.recentRequestToken

                merged = []
                category_ids = [str(category.get("category_id") or "") for category in categories if str(category.get("category_id") or "")]

                # r161 Recent request reduction for BOTH Movies and TV Shows:
                # Xtream returns one whole catalogue request (VOD or Series), then
                # the enabled-package filter is enforced locally. Stalker asks only
                # for page 1 sorted by added for each enabled package via the shared
                # persistent recent_media_filtered cache. No full package walk here.
                if kind in ("vod", "series") and source.get("type") == "xtream":
                    try:
                        all_rows = list(client.streams(kind, "") or [])
                    except Exception:
                        all_rows = []
                    allowed_ids = set(category_ids)
                    for item in all_rows:
                        if not isinstance(item, dict):
                            continue
                        item_cid = str(item.get("category_id") or item.get("genre_id") or "")
                        if not allowed_ids or item_cid in allowed_ids:
                            merged.append(item)
                elif kind in ("vod", "series") and source.get("type") == "stalker" and hasattr(client, "recent_media_filtered"):
                    try:
                        merged = list(client.recent_media_filtered(kind, category_ids, 25) or [])
                    except Exception:
                        merged = []
                else:
                    for category in categories:
                        cid = str(category.get("category_id") or "")
                        try:
                            rows = list(client.streams(kind, cid) or [])
                        except Exception:
                            rows = []
                        merged.extend(rows)

                dedup = set()
                ordered = []
                for pos, item in enumerate(merged):
                    if not isinstance(item, dict):
                        continue
                    key = str(
                        item.get("stream_id")
                        or item.get("series_id")
                        or item.get("vod_id")
                        or item.get("id")
                        or ""
                    ) or ("%s|%d" % (item.get("name") or item.get("title") or "", pos))
                    if key in dedup:
                        continue
                    dedup.add(key)
                    ordered.append(item)

                recent = self._sortedItems(ordered)[:25]

                # r161 shared Recent fast-path for Movies + TV Shows:
                # Paint the newest 25 from provider rows immediately. Do not block
                # either Recent page on synchronous TMDb/details enrichment. Normal
                # lazy poster/details fallback remains available after the GUI paints.

                self._queueGui(
                    self.recentReady,
                    recent_token, recent, categories, generation, False
                )
                return

            # NORMAL PACKAGES:
            # Open only the first ENABLED package initially.  Fetch the exact,
            # complete provider response; do not use Recent, global catalog, or
            # a category preview as package content.
            first = categories[0]
            first_id = str(first.get("category_id") or "")
            first_name = first.get("category_name") or "Other"
            _package_diag("FIRST_PACKAGE_FETCH_BEGIN", kind=kind, category_id=first_id, category_name=first_name)
            first_items = list(client.streams(kind, first_id) or [])
            _package_diag("FIRST_PACKAGE_FETCH_DONE", kind=kind, category_id=first_id, category_name=first_name, item_count=len(first_items))

            # Pass the full first package to GUI. Other packages are fetched only
            # when Prev/Next selects them.
            self._queueGui(
                self.serverReady,
                first_items, first_items, categories,
                {"category_id": first_id, "category_name": first_name},
                generation
            )
        except Exception as exc:
            _package_diag("LOAD_SERVER_ERROR", kind=kind, error=repr(exc))
            self._queueGui(self.serverFailed, str(exc), generation)


    def _loadTrending(self, generation=None):
        """Fast random Backdrop rail from enabled packages only.

        The rail never leaves the user's active Movies/TV Shows package filter.
        It samples enabled packages in a random order,
        accepts content from any year, removes duplicate titles, limits one
        package from dominating the row, and caches the final random selection
        so normal page opens stay fast.
        """
        if generation is None:
            generation = self.contentGeneration
        kind = self.kind
        source = dict(self.source or {})
        try:
            allowed = get_allowed_category_ids(source, kind)
            if not allowed:
                raise RuntimeError("No enabled packages are selected")
            allowed = set(str(x) for x in allowed if str(x))
            if not allowed:
                raise RuntimeError("No enabled packages are selected")

            filter_sig = hashlib.sha1(("|".join(sorted(allowed))).encode("utf-8")).hexdigest()[:12]
            cache_mode = "backdrop_filtered_smart_v11_providerplus_typehints_rating5_anyyear_%s_%s" % (kind, filter_sig)
            fresh_cached = _home_feed_cache_get(cache_mode, source, allow_stale=False)
            if fresh_cached:
                visible = fresh_cached[:self.BACKDROP_ITEM_LIMIT]
                self._queueGui(self.trendingReady, visible, generation, [])
                self._queueGui(self._warmTrendingMetadataThenArtwork, visible, generation)
                return

            client = get_source_client(source)
            category_names = {}
            category_order = []
            try:
                categories, _origin = get_cached_categories(
                    source, kind, client=client, wait_for_server=False
                )
                for cat in categories or []:
                    if not isinstance(cat, dict):
                        continue
                    cid = str(cat.get("category_id") or "")
                    if not cid or cid not in allowed:
                        continue
                    name = str(
                        cat.get("category_name") or cat.get("name") or
                        cat.get("title") or ""
                    )
                    category_names[cid] = name
                    if cid not in category_order:
                        category_order.append(cid)
            except Exception:
                pass

            # Keep Backdrop rails strict: Movies rail = films only, Series rail = TV series only.
            # Exclude sports, wrestling/UFC, programmes, theatre, music, kids/cartoon/anime
            # and obvious cross-kind packages before any catalogue request.
            blocked_backdrop_tokens = (
                "ufc", "efc", "mma", "boxing", "boxer", "fight", "fighting", "combat", "ppv",
                "wwe", "wrestling", "raw", "smackdown", "nxt",
                "sport", "sports", "football", "soccer", "match", "matches", "event", "events",
                "anime", "animation", "cartoon", "kids", "children", "child",
                "theater", "theatre", "plays", "stage",
                "music", "songs", "concert", "karaoke",
                "program", "programs", "programme", "programmes", "show", "shows",
                "xxx", "adult", "18+",
                "مصارعة", "رياضة", "رياضي", "مباريات", "قتال", "ملاكمة",
                "انمي", "أنمي", "كرتون", "اطفال", "أطفال", "مسرح", "مسرحيات",
                "اغاني", "أغاني", "برامج"
            )

            def backdrop_category_allowed(text):
                text = str(text or "").lower()
                if any(token in text for token in blocked_backdrop_tokens):
                    return False

                # Cumulative package filter: original provider hints PLUS type hints.
                # Disney stays excluded.
                if re.search(r"(?:^|[^a-z0-9])disney\+?(?:$|[^a-z0-9])", text):
                    return False
                provider_match = bool(re.search(r"(?:^|[^a-z0-9])(?:netflix|nf|prime(?:\s+video)?|amazon(?:\s+prime(?:\s+video)?)?)(?:$|[^a-z0-9])", text))
                movie_match = bool(re.search(r"(?:^|[^a-z0-9])(?:movie|movies|film|films)(?:$|[^a-z0-9])", text))
                series_match = bool(re.search(r"(?:^|[^a-z0-9])(?:series|serie|serise|tv\s+series)(?:$|[^a-z0-9])", text))
                if kind == "vod":
                    if series_match and not movie_match:
                        return False
                    return provider_match or movie_match
                if movie_match and not series_match:
                    return False
                return provider_match or series_match

            def backdrop_item_allowed(row, category_name=""):
                row = row or {}
                text = " ".join(str(row.get(k) or "") for k in (
                    "name", "title", "genre", "category_name", "description", "plot"
                )).lower()
                if category_name:
                    text += " " + str(category_name).lower()
                if any(token in text for token in blocked_backdrop_tokens):
                    return False
                if kind == "vod":
                    wrong = ("series", "tv show", "tvshow", "مسلسل", "مسلسلات")
                else:
                    wrong = ("movie", "movies", "film", "films", "cinema", "افلام", "أفلام")
                return not any(token in text for token in wrong)

            def backdrop_rating_value(row):
                """Return a normalized 0-10 rating for Backdrop filtering."""
                row = row or {}
                raw = row.get("rating")
                if raw in (None, "", 0, "0"):
                    raw = row.get("vote_average")
                source_5based = False
                if raw in (None, "", 0, "0"):
                    raw = row.get("rating_5based")
                    source_5based = True
                try:
                    text = str(raw or "").strip().replace(",", ".")
                    match = re.search(r"[-+]?\d+(?:\.\d+)?", text)
                    value = float(match.group(0)) if match else 0.0
                    # Some Xtream providers expose rating_5based on a 0-5 scale.
                    # Normalize it to 0-10 before applying the >=5 filter.
                    if source_5based and 0.0 < value <= 5.0:
                        value *= 2.0
                    return value
                except Exception:
                    return 0.0

            # Use every enabled package that matches the current content type.
            # Movies Backdrop reads only enabled movie packages; Series Backdrop
            # reads only enabled series packages.  No provider-name restriction.
            category_order = [
                cid for cid in category_order
                if backdrop_category_allowed(category_names.get(cid, ""))
            ]

            # Shuffle package traversal once per six-hour cache build. This
            # keeps the result genuinely varied while avoiding a full catalogue
            # scan on every page open.
            ordered_ids = list(category_order)
            random.shuffle(ordered_ids)
            if not ordered_ids:
                raise RuntimeError("No enabled packages for Backdrop")

            target_count = self.BACKDROP_ITEM_LIMIT
            candidate_goal = max(target_count * 3, 24)
            batch_size = 4
            candidates = []
            seen = set()

            # Only ENABLED filtered packages are fetched. Use existing category
            # cache first and small worker batches; stop after a healthy random
            # candidate pool is available to keep first-load latency bounded.
            for offset in range(0, len(ordered_ids), batch_size):
                batch_ids = ordered_ids[offset:offset + batch_size]
                package_batches = get_category_streams_batch(
                    source, kind, client, batch_ids,
                    use_cache=True, wait_for_server=True, max_workers=4
                )
                for cid, rows, _origin in package_batches:
                    cid = str(cid or "")
                    if cid not in allowed:
                        continue
                    for raw in rows or []:
                        if not isinstance(raw, dict):
                            continue
                        item_cid = str(
                            raw.get("category_id") or raw.get("categoryId") or
                            raw.get("genre_id") or raw.get("genre-id") or cid
                        )
                        if item_cid and item_cid not in allowed:
                            continue
                        if not backdrop_item_allowed(raw, category_names.get(cid, "")):
                            continue
                        # Backdrop rail is rating-filtered before selection: keep
                        # only real ratings >= 5.0; 0/missing/invalid never enters.
                        if backdrop_rating_value(raw) < 5.0:
                            continue
                        title = str(raw.get("name") or raw.get("title") or "")
                        if not title:
                            continue
                        row = dict(raw)
                        display_title = self._backdropDisplayTitle(title)
                        dedupe_title = re.sub(r"[^a-z0-9]+", " ", display_title.lower()).strip()
                        if not dedupe_title:
                            dedupe_title = re.sub(r"\s+", " ", display_title.lower()).strip()
                        key = "title:%s" % dedupe_title
                        if not dedupe_title or key in seen:
                            continue
                        seen.add(key)
                        row["_display_title"] = display_title
                        row["_you_might_like"] = True
                        row["_source_category_id"] = cid
                        row["_source_category_name"] = category_names.get(cid, "")
                        try:
                            year_value = str(self._year(raw) or "").strip()[:4]
                        except Exception:
                            year_value = ""
                        if year_value:
                            row["_backdrop_year"] = year_value
                        candidates.append(row)

                # Traverse all matching enabled packages; do not stop after
                # the first productive batch.

            if not candidates:
                raise RuntimeError("No usable content found in enabled provider packages")

            # Randomise items, then cap each package so one enabled bouquet does
            # not take over the whole rail. If the diversity cap leaves gaps,
            # fill them from the remaining valid candidates.
            random.shuffle(candidates)
            selected = []
            leftovers = []
            package_counts = {}
            for row in candidates:
                cid = str(row.get("_source_category_id") or row.get("category_id") or "")
                if package_counts.get(cid, 0) >= 3:
                    leftovers.append(row)
                    continue
                package_counts[cid] = package_counts.get(cid, 0) + 1
                selected.append(row)
                if len(selected) >= target_count:
                    break

            if len(selected) < target_count:
                selected_keys = set(id(x) for x in selected)
                fill = leftovers + [x for x in candidates if id(x) not in selected_keys and x not in leftovers]
                for row in fill:
                    if row in selected:
                        continue
                    selected.append(row)
                    if len(selected) >= target_count:
                        break

            selected = selected[:target_count]
            if not selected:
                raise RuntimeError("No usable random Backdrop content")

            _home_feed_cache_put(cache_mode, source, selected)
            self._queueGui(self.trendingReady, selected, generation, [])
            self._queueGui(self._warmTrendingMetadataThenArtwork, selected, generation)
        except Exception as exc:
            self._queueGui(self.trendingFailed, str(exc), generation)


    def _warmTrendingMetadataThenArtwork(self, items, generation=None):
        """Warm TMDb metadata for the whole Backdrop rail before image prefetch.

        Data first keeps the screen responsive and gives every item a resolved
        TMDb identity/artwork path before low-priority artwork downloads start.
        The actual images are still fetched by the existing bounded artwork
        queue, so visible requests retain priority.
        """
        if generation is not None and generation != self.contentGeneration:
            return
        rows = [row for row in list(items or []) if isinstance(row, dict)]
        if not rows:
            return
        kind = self.kind

        def worker(batch=rows, wanted_generation=generation, wanted_kind=kind):
            try:
                tmdb = TMDbClient()
            except Exception:
                self._queueGui(self._warmTrendingArtwork, batch, wanted_generation)
                return
            for row in batch:
                try:
                    title = str(row.get("name") or row.get("title") or row.get("original_title") or row.get("original_name") or "").strip()
                    if not title:
                        continue
                    year = self._year(row) or None
                    resolved = str(row.get("tmdb_id") or row.get("tmdb") or "").strip()
                    found = {}
                    bundle = {}
                    if not resolved:
                        found = tmdb.search_title(title, wanted_kind, year) or {}
                        if not found:
                            found = tmdb.search_title(title, wanted_kind, None) or {}
                        resolved = str(found.get("id") or found.get("tmdb_id") or "").strip()
                    if resolved:
                        bundle = tmdb.details_bundle(resolved, wanted_kind) or {}
                    merged = dict(found or {})
                    merged.update(bundle or {})
                    if resolved:
                        row["tmdb_id"] = resolved
                    backdrop = self.norm(merged.get("backdrop_path") or "")
                    poster = self.norm(merged.get("poster_path") or "")
                    if backdrop:
                        row["_tmdb_backdrop"] = backdrop
                    if poster:
                        row["_tmdb_poster"] = poster
                    if merged and resolved:
                        norm = self._normTitle(title)
                        _memory_put(_DETAILS_DATA_CACHE, "%s:%s" % (wanted_kind, resolved), merged, _DETAILS_DATA_CACHE_LIMIT)
                        _memory_put(_DETAILS_DATA_CACHE, "%s:title:%s:%s" % (wanted_kind, norm, str(year or "")), merged, _DETAILS_DATA_CACHE_LIMIT)
                except Exception:
                    continue
            self._queueGui(self._warmTrendingArtwork, batch, wanted_generation)

        _submit_content_bg(worker, key=("trending-metadata-then-artwork", id(self), generation, kind))

    def _warmTrendingArtwork(self, items, generation=None):
        """Prefetch all Trending posters/backdrops without blocking content."""
        if generation is not None and generation != self.contentGeneration:
            return
        # The artwork queue already limits active transfers and de-duplicates
        # URLs. Keep these as low-priority cache jobs so visible-card requests
        # can always jump ahead while the rest continues in the background.
        for row in list(items or []):
            try:
                backdrop = self.norm(row.get("_tmdb_backdrop") or "") or self.imageUrl(row, True)
                if backdrop:
                    request_artwork(backdrop, "backdrops", None, priority=2)
            except Exception:
                pass
            try:
                poster = self.norm(row.get("_tmdb_poster") or "") or self.imageUrl(row, False)
                if poster:
                    request_artwork(poster, "posters", None, priority=1)
            except Exception:
                pass

    def _warmRecentMetadataSync(self, items):
        """Resolve TMDb metadata for the Recent batch (max fifteen).

        Runs inside the existing content worker, never downloads artwork, and
        seeds the shared metadata cache so the first visible posters can start
        immediately after the GUI paints.
        """
        try:
            tmdb = TMDbClient()
        except Exception:
            return
        kind = self.kind
        for row in list(items or [])[:15]:
            if not isinstance(row, dict):
                continue
            try:
                title = str(row.get("name") or row.get("title") or "").strip()
                if not title:
                    continue
                year = self._year(row) or None
                resolved = str(row.get("tmdb_id") or row.get("tmdb") or "").strip()
                found = {}
                if not resolved:
                    found = tmdb.search_title(title, kind, year) or tmdb.search_title(title, kind, None) or {}
                    resolved = str(found.get("id") or found.get("tmdb_id") or "").strip()
                if not resolved:
                    continue
                bundle = tmdb.details_bundle(resolved, kind) or {}
                merged = dict(found or {})
                merged.update(bundle)
                row["tmdb_id"] = resolved
                poster = str(merged.get("poster_path") or "").strip()
                backdrop = str(merged.get("backdrop_path") or "").strip()
                if poster:
                    row["_tmdb_poster"] = poster
                if backdrop:
                    row["_tmdb_backdrop"] = backdrop
                norm = self._normTitle(title)
                _memory_put(_DETAILS_DATA_CACHE, "%s:%s" % (kind, resolved), merged, _DETAILS_DATA_CACHE_LIMIT)
                _memory_put(_DETAILS_DATA_CACHE, "%s:title:%s:%s" % (kind, norm, str(year or "")), merged, _DETAILS_DATA_CACHE_LIMIT)
            except Exception:
                continue

    def recentReady(self, token, items, categories=None, generation=None, partial=False):
        # Reject stale page generations and stale Recent requests.
        if generation is not None and generation != self.contentGeneration:
            return
        if token != getattr(self, "recentRequestToken", token):
            return
        if self.contentMode != "recent":
            return

        rows = list(items or [])

        # Empty/error-like refreshes do NOT erase a last-good visible Recent row.
        if not rows:
            if self.recentStable:
                self.latest = _screen_dedupe_content(self.recentStable, self.kind)
                self.latestStart = self.latestIndex = 0
                self.categoryName = "RECENT ADDED"
                self._updateLatestTitle()
                self.renderLatest()
                self.updateFocus()
            return

        if not partial:
            self.recentStable = rows
        self.latest = _screen_dedupe_content(rows, self.kind)
        self.serverItems = list(rows)
        self.categoryItems = list(rows)
        self.categoriesList = list(categories or [])
        self.categoriesLoaded = True
        self.categoryIndex = -1
        self.categoryName = "RECENT ADDED"
        self.latestStart = self.latestIndex = 0

        # Persist only the completed non-empty Recent result.  The Recent rows
        # are intentionally transient so a restart never mistakes a partial
        # batch for the complete Recent feed.
        if not partial:
            try:
                _home_feed_cache_put("recent_%s" % self.kind, self.source, rows)
            except Exception:
                pass
            try:
                _submit_content_bg(
                    _save_content_landing_cache,
                    args=(dict(self.source), self.kind, list(rows)[:64]),
                    key=("landing-cache", id(self), self.kind)
                )
            except Exception:
                pass

        self._updateLatestTitle()
        self.renderLatest()
        self.updateFocus()

    def serverReady(self, latest, allItems=None, categories=None, landingCategory=None, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return
        self.serverItems = list(allItems or [])
        self.categoryItems = []
        self.categoriesList = list(categories or [])

        # Build one in-memory category map once. This removes the repeated
        # full-catalog scan that used to happen on every package key press.
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        if self.source.get("type") == "xtream":
            for row in self.serverItems:
                try:
                    cid = str((row or {}).get("category_id") or (row or {}).get("categoryId") or "")
                    if cid:
                        self._categoryRowsIndex.setdefault(cid, []).append(row)
                except Exception:
                    pass
        self.categoriesLoaded = True
        self.categoryIndex = -1
        self.categoryName = ""
        self._updateLatestTitle()
        landing_id = str((landingCategory or {}).get("category_id") or "")
        landing_name = (landingCategory or {}).get("category_name") or ""
        if landing_id == "__recent_added__":
            self.categoryIndex = -1
            self.categoryName = landing_name or "RECENT ADDED"
            self.categoryItems = list(allItems or [])
            self._updateLatestTitle()
        elif landing_id:
            for index, category in enumerate(self.categoriesList):
                if str(category.get("category_id") or "") == landing_id:
                    self.categoryIndex = index
                    self.categoryName = category.get("category_name") or landing_name or "Other"
                    self._updateLatestTitle()
                    self.categoryItems = list(allItems or [])
                    if landing_id:
                        self._fullPackageRows[landing_id] = list(allItems or [])
                    break
        server_latest = latest or []

        # SERVER/PACKAGE POSTERS ARE A SEPARATE PERMANENT PATH.
        # NONE means: no automatic Netflix/Prime/Trending lower feed.
        # It does NOT disable server packages, Recent Added, or their posters.
        if self.contentMode in ("none", "recent"):
            self.latest = _screen_dedupe_content(server_latest, self.kind)
            self.latestStart = self.latestIndex = 0
            if self.latest:
                _submit_content_bg(_save_content_landing_cache,
                                   args=(dict(self.source), self.kind, list(self.latest)[:64]),
                                   key=("landing-cache", id(self), self.kind))
            self._updateLatestTitle()
            self.renderLatest()
        elif not self.latest:
            # Automatic provider modes are supplied later by TMDb.
            self.latest = []
            self.latestStart = self.latestIndex = 0
            self._updateLatestTitle()
            self.renderLatest()
        if self.source.get("type") == "stalker" and not self.latest:
            self["heroDesc"].setText(tr("Stalker packages are ready. Open Categories and select a package to load its titles."))
        if not self.trending:
            # Keep the opening focus on the top navigation. Once the user presses
            # DOWN, focus goes to Trending first (or Latest only if Trending is unavailable).
            if self.focus != "top":
                self.focus = "trending" if self.trending else ("latest" if self.latest else "trending")
                self.preview()
            self.updateFocus()


    def trendingReady(self, trending, generation=None, lower_items=None):
        if generation is not None and generation != self.contentGeneration:
            return

        # Top backdrop is ALWAYS real Trending: fixed 12 maximum.
        self.trending = _screen_dedupe_content(trending or [], self.kind)[:self.BACKDROP_ITEM_LIMIT]

        # No automatic provider lower row. Server packages remain independent.
        self.renderTrending()
        if self.trending:
            self.trendStart = self.trendIndex = 0
            if self.focus != "top":
                self.focus = "trending"
        if self.focus != "top":
            self.preview()
        self.updateFocus()


    def serverFailed(self, msg, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return

        # Recent is sticky-last-good: a retry/network failure cannot make the
        # row disappear after it was already visible.
        if self.contentMode == "recent" and self.recentStable:
            self.latest = _screen_dedupe_content(self.recentStable, self.kind)
            self.latestStart = self.latestIndex = 0
            self.categoryName = "RECENT ADDED"
            self._updateLatestTitle()
            self.renderLatest()
            self.updateFocus()
            return

        self.serverItems, self.categoryItems, self.categoriesList = [], [], []
        self.categoriesLoaded = True
        self.latest = []
        self._updateLatestTitle()
        self["heroDesc"].setText("Unable to load the selected server library: %s" % msg)
        self.renderLatest(); self.updateFocus()

    def trendingFailed(self, msg, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return
        self.trending = []
        self.renderTrending()
        if self.latest:
            if self.focus != "top":
                self.focus = "latest"
                self.preview()
            self["heroDesc"].setText("TMDb Trending unavailable. Latest content is loaded from your selected server.\n%s" % msg)
        else:
            self["heroDesc"].setText("Unable to load TMDb Trending: %s" % msg)
        self.updateFocus()

    def current(self):
        arr = self.trending if self.focus == "trending" else self.latest
        idx = self.trendStart + self.trendIndex if self.focus == "trending" else self.latestStart + self.latestIndex
        return arr[idx] if 0 <= idx < len(arr) else None

    def toggleFavourite(self):
        item = self.current()
        if not item:
            return
        target = self.matchServerItem(item) if item.get("_tmdb") else item
        if not target:
            self["footer"].setText(tr("This title is not available on the server and cannot be added to favorites"))
            return
        try:
            from .favorites import toggle_favourite
            added, saved = toggle_favourite(self.source, self.kind, target)
            title = target.get("name") or target.get("title") or "العنصر"
            if not saved:
                self["footer"].setText(tr("Unable to save favorite"))
            elif added:
                self["footer"].setText("تمت إضافة %s إلى المفضلات" % title)
            else:
                self["footer"].setText("تمت إزالة %s من المفضلات" % title)
        except Exception as exc:
            self["footer"].setText("تعذر تحديث المفضلة: %s" % exc)

    def addCurrentFavourite(self):
        item = self.current()
        if not item:
            self["footer"].setText(tr("Select a movie or TV show first"))
            return
        target = self.matchServerItem(item) if item.get("_tmdb") else item
        if not target:
            self["footer"].setText(tr("This title is not available on the server and cannot be added to favorites"))
            return
        try:
            from .favorites import is_favourite, add_favourite
            title = target.get("name") or target.get("title") or "العنصر"
            if is_favourite(self.source, self.kind, target):
                self["footer"].setText("%s موجود بالفعل في المفضلات" % title)
            elif add_favourite(self.source, self.kind, target):
                self["footer"].setText("تمت إضافة %s إلى المفضلات" % title)
            else:
                self["footer"].setText(tr("Unable to save favorite"))
        except Exception as exc:
            self["footer"].setText("Unable to save favorite: %s" % exc)

    def norm(self, value):
        if isinstance(value, list): value = value[0] if value else ""
        if isinstance(value, str):
            value = value.strip().replace("\\/", "/")
            if value.startswith("["):
                try: value = (json.loads(value) or [""])[0]
                except Exception: pass
            if value.startswith("/"): value = backdrop_url(value)
        return value or ""

    def imageUrl(self, item, backdrop=False):
        item = item or {}
        if backdrop:
            value = item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url") or item.get("movie_backdrop")
            # Provider/server artwork may be relative to the Xtream/Stalker host.
            # Do not treat every leading slash as a TMDb path; resolve server rows
            # against the active source, while TMDb feed rows keep TMDb semantics.
            if item.get("_tmdb"):
                return self.norm(value)
            return _server_asset_url(self.source, value) if value else ""

        # TMDb provider rows already contain complete TMDb artwork URLs.
        # Do not send them through the connected-server poster resolver.
        if item.get("_tmdb"):
            return self.norm(
                item.get("stream_icon")
                or item.get("cover")
                or item.get("poster")
                or item.get("poster_path")
            )

        # Server/package rows continue to use the server-aware resolver.
        return _server_poster_url(self.source, item)

    def logoUrl(self, item):
        return self.norm(item.get("logo") or item.get("title_logo") or item.get("logo_path") or item.get("clearlogo") or "")

    def setPlaceholder(self, widget, name):
        try: self[widget].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", name))
        except Exception: pass

    def _tmdbTitleCandidates(self, *values):
        """Return safe TMDb title candidates without changing server list labels.

        IPTV providers often prefix names with bouquet/group tags such as
        ``FRI |`` or ``EN |``.  Those labels are useful in the UI but can make
        TMDb return no result.  Only the fallback lookup uses these cleaned
        variants, so the fast server-artwork path remains untouched.
        """
        out = []
        for value in values:
            raw = str(value or "").strip()
            if not raw:
                continue
            variants = [raw]
            if "|" in raw:
                tail = raw.split("|")[-1].strip()
                if tail:
                    variants.insert(0, tail)
            # Remove a leading [GROUP] / (GROUP) tag only for TMDb lookup.
            variants.append(re.sub(r"^\s*[\[(][^\])]{1,16}[\])]\s*", "", raw).strip())
            for candidate in variants:
                clean = self._normTitle(candidate)
                if clean and clean not in out:
                    out.append(clean)
        return out

    def _tmdbSearchArtwork(self, item, extra=None, required_key="poster_path"):
        """One TMDb artwork path for every Movies/TV Shows surface.

        r63: always let the shared TMDb client see the original provider title
        first.  Its global title normalizer handles 4K/NF/language/provider
        prefixes consistently on every server.  Local legacy candidates remain
        only as a final compatibility fallback.
        """
        tmdb = TMDbClient()
        data = dict(item or {})
        if isinstance(extra, dict):
            merged = dict(extra)
            merged.update(data)
            data = merged
        values = [data.get("name"), data.get("title"), data.get("original_title"), data.get("original_name")]
        year = self._year(data) or None
        # A provider TMDb id is the most reliable identity, especially for Arabic
        # titles. Use it before any title search so poster/backdrop fallback cannot
        # miss because of translated/transliterated names.
        resolved_id = str(data.get("tmdb_id") or data.get("tmdb") or data.get("tmdbid") or "").strip()
        if resolved_id:
            try:
                bundle = tmdb.details_bundle(resolved_id, self.kind) or {}
                if bundle.get(required_key):
                    return bundle
            except Exception:
                pass
        seen = set()
        # Original labels first: TMDbClient.search_artwork() owns the canonical
        # all-server normalization introduced in r61.
        for value in values:
            candidate = str(value or "").strip()
            key = candidate.lower()
            if not candidate or key in seen:
                continue
            seen.add(key)
            found = tmdb.search_artwork(candidate, self.kind, year, required_key=required_key) or {}
            if found.get(required_key):
                return found
        # Keep old local variants for unusual bouquet labels, but never make
        # them the primary lookup path.
        for candidate in self._tmdbTitleCandidates(*values):
            key = str(candidate or "").strip().lower()
            if not key or key in seen:
                continue
            seen.add(key)
            found = tmdb.search_artwork(candidate, self.kind, year, required_key=required_key) or {}
            if found.get(required_key):
                return found
        return {}

    def _tmdbBackdropFallback(self, item, widget, width, height, server_fallback=""):
        """Resolve the rail backdrop with the same TMDb match used by More Info.

        r263: the large Backdrop rail must not trust a provider backdrop first.
        Some providers attach the wrong wide image to the correct movie.  Resolve
        TMDb ID/title+year exactly like loadDetails(), cache that resolved ID/path
        on the live item, and use the provider image only if TMDb has no backdrop.
        """
        item = item or {}
        raw_title = str(item.get("name") or item.get("title") or item.get("original_title") or item.get("original_name") or "").strip()
        if not raw_title:
            if server_fallback:
                self.loadImage(server_fallback, widget, width, height)
            return
        token = (raw_title, str(item.get("stream_id") or item.get("series_id") or item.get("id") or ""))
        if not hasattr(self, "_backdrop_fallback_tokens"):
            self._backdrop_fallback_tokens = {}
        self._backdrop_fallback_tokens[widget] = token

        # Reuse an already-resolved TMDb backdrop immediately.
        cached_backdrop = self.norm(item.get("_tmdb_backdrop") or "")
        if cached_backdrop:
            self.loadImage(cached_backdrop, widget, width, height)
            return

        def worker():
            backdrop = ""
            resolved_id = str(item.get("tmdb_id") or item.get("tmdb") or "").strip()
            try:
                tmdb = TMDbClient()
                kind = self.kind
                year = self._year(item) or None
                data = {}

                # Same fast path as More Info: a provider TMDb ID wins when valid.
                if resolved_id:
                    try:
                        data = tmdb.details_bundle(resolved_id, kind) or {}
                    except Exception:
                        data = {}
                    backdrop = self.norm(data.get("backdrop_path") or "")

                # Same title/year resolver as More Info when no useful ID/backdrop.
                if not backdrop:
                    found = {}
                    try:
                        found = tmdb.search_title(raw_title, kind, year) or {}
                    except Exception:
                        found = {}
                    if not found:
                        try:
                            found = tmdb.search_title(raw_title, kind, None) or {}
                        except Exception:
                            found = {}
                    rid = str((found or {}).get("id") or (found or {}).get("tmdb_id") or "").strip()
                    if rid:
                        resolved_id = rid
                        try:
                            data = tmdb.details_bundle(resolved_id, kind) or {}
                        except Exception:
                            data = {}
                    backdrop = self.norm((data or {}).get("backdrop_path") or (found or {}).get("backdrop_path") or "")
            except Exception:
                backdrop = ""

            final_url = backdrop or server_fallback
            if not final_url:
                return

            def apply():
                if getattr(self, "_backdrop_fallback_tokens", {}).get(widget) != token:
                    return
                try:
                    if backdrop:
                        item["_tmdb_backdrop"] = backdrop
                        # Keep provider backdrop untouched; this key makes future
                        # rail renders prefer the exact TMDb artwork without another match.
                        if resolved_id:
                            item["tmdb_id"] = resolved_id
                except Exception:
                    pass
                self.loadImage(final_url, widget, width, height)

            self._queueGui(apply)
            request_artwork(final_url, "backdrops", None, priority=2)

        _submit_content_bg(worker, key=("backdrop-exact-tmdb", id(self), str(widget), token))

    def _tmdbPosterFallback(self, item, widget, width, height, failed_url=""):
        """Find a TMDb poster only when the server poster is missing or failed."""
        # A reused card may already be loading another item. Never let an old
        # server failure replace the artwork of the new card.
        if failed_url and getattr(self, "_image_requests", {}).get(widget) != failed_url:
            return
        def worker():
            try:
                if failed_url and getattr(self, "_image_requests", {}).get(widget) != failed_url:
                    return
                found = self._tmdbSearchArtwork(item or {}, required_key="poster_path")
                poster = self.norm(found.get("poster_path") or "")
                if not poster:
                    return
                def apply():
                    # The slot may have been reused while TMDb was queried.
                    current = getattr(self, "_image_requests", {}).get(widget)
                    if failed_url and current != failed_url:
                        return
                    self.loadImage(poster, widget, width, height)
                self._queueGui(apply)
            except Exception:
                pass
        _submit_content_bg(worker, key=("poster-fallback", id(self), str(widget)))

    def _posterFileValid(self, path):
        """Cheap local validation for server posters before decoding.

        This deliberately does not touch the downloader/queue.  It only catches
        server URLs that return an HTML/error body or a tiny/broken file, so the
        existing TMDb fallback can take over without affecting artwork speed.
        """
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, "rb") as fh:
                head = fh.read(12)
            if head.startswith(b"\xff\xd8\xff"):
                return True
            if head.startswith(b"\x89PNG\r\n\x1a\n"):
                return True
            if head.startswith(b"RIFF") and head[8:12] == b"WEBP":
                return True
            if head.startswith(b"GIF87a") or head.startswith(b"GIF89a"):
                return True
            return False
        except Exception:
            return False

    def loadImage(self, url, widget, width, height, fallback_item=None):
        """Show cached artwork fast; hero backdrops recover through TMDb if needed."""
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_image_requests", None)
        if requests is None:
            requests = {}
            self._image_requests = requests
        requests[widget] = url

        if widget == "hero":
            priority = 120
        elif widget == "logoImage":
            priority = 100
        elif widget.startswith("trend"):
            priority = 75
        elif widget.startswith("latest"):
            priority = 85
        else:
            priority = 50

        def force_hero_tmdb(expected=url):
            if getattr(self, "_image_requests", {}).get("hero") != expected:
                return
            item = self.current()
            if not item:
                return
            self._previewRequestId += 1
            request_id = self._previewRequestId
            # The provider backdrop already failed at download time. Bypass it on
            # this retry; otherwise _lookupPreviewArtwork sees the same non-empty
            # URL and keeps selecting it forever instead of reaching TMDb.
            _submit_content_bg(
                self._lookupPreviewArtwork,
                args=(dict(item), request_id, True, False, True),
                key=("hero-tmdb-fallback", id(self))
            )

        def done(path, w=widget, x=width, y=height, expected=url, item=fallback_item):
            if getattr(self, "_image_requests", {}).get(w) != expected:
                return
            if item is not None and not self._posterFileValid(path):
                try:
                    if path and os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                self._tmdbPosterFallback(item, w, x, y, expected)
                return
            if w == "hero":
                try:
                    if not path or not os.path.exists(path) or os.path.getsize(path) < 1000:
                        try:
                            if path and os.path.exists(path):
                                os.remove(path)
                        except Exception:
                            pass
                        force_hero_tmdb(expected)
                        return
                except Exception:
                    force_hero_tmdb(expected)
                    return
            self.decode(path, w, x, y)

        def failed(_path, w=widget, expected=url, item=fallback_item, x=width, y=height):
            if w == "hero":
                force_hero_tmdb(expected)
                return
            if item is not None:
                self._tmdbPosterFallback(item, w, x, y, expected)

        
        if widget in ("hero", "backdrop") or str(widget).startswith(("trend", "rec")):
            cache_kind = "backdrops"
        elif widget == "logoImage":
            cache_kind = "logos"
        else:
            cache_kind = "posters"
        request_artwork(
            url, cache_kind, done, priority=priority,
            errback=failed if (fallback_item is not None or widget == "hero") else None
        )

    def decode(self, path, widget, width, height):
        loader = ePicLoad(); self.picloads.append(loader)
        def ready(_=None, l=loader, w=widget):
            try:
                ptr = l.getData()
                if ptr and self[w].instance:
                    self[w].instance.setPixmap(ptr)
                    try:
                        self[w].show()
                    except Exception:
                        pass
                    if str(w).startswith("latest") and str(w)[6:].isdigit():
                        _slot = int(str(w)[6:])
                        for _name in ("latestShell%d" % _slot, "latestBadge%d" % _slot,
                                      "latestLabel%d" % _slot):
                            try:
                                self[_name].show()
                            except Exception:
                                try:
                                    self[_name].setVisible(True)
                                except Exception:
                                    pass
                        try:
                            if str(self["latestRate%d" % _slot].getText() or "").strip():
                                self["latestRate%d" % _slot].show()
                        except Exception:
                            pass
                    if w == "logoImage":
                        try:
                            self["logoHintIcon"].setVisible(False)
                            self["logoHint"].setVisible(False)
                        except Exception:
                            pass
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        render_width, render_height = scale_size(width, height)
        connect_picture_data(loader, ready, self, oneshot=True); loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000")); loader.startDecode(path)

    def _setCardMeta(self, prefix, slot, item):
        # Large Movies/TV page: clean provider/quality/language prefixes for
        # every visible card label (Backdrop row and lower poster row) while
        # preserving the original server name inside the item for playback,
        # source matching and TMDb lookup.
        raw_title = str((item or {}).get("_display_title") or (item or {}).get("name") or (item or {}).get("title") or "").strip()
        title = self._backdropDisplayTitle(raw_title) if raw_title else ""
        rating = str((item or {}).get("rating") or (item or {}).get("rating_5based") or "").strip()
        limit = 30 if prefix == "trend" else 16
        self["%sLabel%d" % (prefix, slot)].setText(title[:limit] + ("…" if len(title) > limit else ""))
        self["%sRate%d" % (prefix, slot)].setText(rating[:4])

    def renderTrending(self):
        for slot in range(4):
            idx = self.trendStart + slot
            item = self.trending[idx] if idx < len(self.trending) else None
            # Backdrop ranking badge: #1 .. #12 follows the actual rail order.
            self["rank%d" % slot].setText(("#%d" % (idx + 1)) if item else "")
            self.setPlaceholder("trend%d" % slot, "trend_transparent_placeholder.png")
            self._setCardMeta("trend", slot, item)
            if item:
                # r263: Backdrop rail is TMDb-first, matching More Info exactly.
                # Never paint a known-wrong provider backdrop first and then swap it.
                tmdb_url = self.norm(item.get("_tmdb_backdrop") or "")
                if tmdb_url:
                    self.loadImage(tmdb_url, "trend%d" % slot, 410, 210)
                else:
                    server_url = self.imageUrl(item, True)
                    self._tmdbBackdropFallback(item, "trend%d" % slot, 410, 210, server_fallback=server_url)
        # r131 test: Backdrop rail images are strictly on-demand.  Warm only
        # metadata for the visible Movies cards; never download off-screen
        # backdrops in the background.
        if self.kind == "vod":
            self._prefetchTmdbMetadata(self.trending, self.trendStart, 4)

    def renderLatest(self):
        for slot in range(8):
            idx = self.latestStart + slot
            item = self.latest[idx] if idx < len(self.latest) else None
            # r411: the lower 8-poster rail used static shell/rating artwork, so r410
            # could not hide its gray/black loading blocks. Keep all card chrome
            # invisible until the real poster decode succeeds.
            for _name in ("latestShell%d" % slot, "latestBadge%d" % slot,
                          "latestLabel%d" % slot, "latestRate%d" % slot):
                try:
                    self[_name].hide()
                except Exception:
                    try:
                        self[_name].setVisible(False)
                    except Exception:
                        pass
            self.setPlaceholder("latest%d" % slot, "poster_loading_transparent_r410.png")
            self._setCardMeta("latest", slot, item)
            if item:
                url = self.imageUrl(item, False)
                if url:
                    self.loadImage(url, "latest%d" % slot, 170, 205, fallback_item=item)
                else:
                    self._tmdbPosterFallback(item, "latest%d" % slot, 170, 205)
        # r131 test: visible eight posters load normally above.  Prefetch only
        # the next two cards, instead of the entire Content Home list.
        _next = []
        for _item in list(self.latest or [])[self.latestStart + 8:self.latestStart + 10]:
            _url = self.imageUrl(_item, False)
            if _url:
                _next.append(_url)
        if _next:
            prefetch_artwork(_next, "posters", priority=2)
        if self.kind == "vod":
            # Five visible/nearby movies are enough to keep navigation instant
            # without flooding a small Enigma2 receiver with metadata requests.
            self._prefetchTmdbMetadata(self.latest, self.latestStart, 5)

    def _prefetchTmdbMetadata(self, items, start, count):
        """Warm cache for visible Movies metadata without touching Enigma2 widgets.

        TMDbClient already owns persistent search/details caches.  This method
        only advances those cache hits into the background and mirrors them in
        the small in-session details LRU used by More Info.
        """
        if self.kind != "vod":
            return
        rows = []
        for item in list(items or [])[start:start + max(0, int(count or 0))]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("name") or item.get("title") or item.get("original_title") or "").strip()
            if not title:
                continue
            year = self._year(item) or 0
            tid = str(item.get("tmdb_id") or item.get("tmdb") or "").strip()
            norm = self._normTitle(title)
            key = "%s|%s|%s" % (tid, norm, str(year or ""))
            if not key or key in self._metadataWarmKeys:
                continue
            self._metadataWarmKeys.add(key)
            rows.append((dict(item), title, year, tid, norm))
        if not rows:
            return

        def worker(batch=rows):
            try:
                tmdb = TMDbClient()
            except Exception:
                return
            for row, title, year, tid, norm in batch:
                try:
                    found = {}
                    resolved = tid
                    if not resolved:
                        found = tmdb.search_title(title, "vod", year or None) or {}
                        if not found:
                            found = tmdb.search_title(title, "vod", None) or {}
                        resolved = str(found.get("id") or found.get("tmdb_id") or "").strip()
                    if not resolved:
                        continue
                    bundle = tmdb.details_bundle(resolved, "vod") or {}
                    if found:
                        seeded = dict(found)
                        seeded.update(bundle or {})
                        bundle = seeded
                    if not bundle:
                        continue
                    _memory_put(_DETAILS_DATA_CACHE, "vod:%s" % resolved, bundle, _DETAILS_DATA_CACHE_LIMIT)
                    _memory_put(_DETAILS_DATA_CACHE, "vod:title:%s:%s" % (norm, str(year or "")), bundle, _DETAILS_DATA_CACHE_LIMIT)
                except Exception:
                    continue

        _submit_content_bg(worker, key=("movie-metadata-warm", id(self)))

    def _prefetchCards(self, items, start, count, backdrop=False, priority=5):
        """Warm only the next page at a low priority without decoding it yet.

        The queue writes the original JPEG/PNG response to disk, so this changes
        timing only; it never alters image dimensions, compression, or poster art.
        """
        for item in list(items or [])[start:start + count]:
            try:
                url = self.imageUrl(item, backdrop)
                if url:
                    request_artwork(url, "backdrops" if backdrop else "posters", None, priority=priority)
            except Exception:
                pass


    def _alignTopSelector(self):
        try:
            index = max(0, min(self.topIndex, len(self.TOP_X) - 1))
            cell_w = self.TOP_W[index]
            x = self.TOP_X[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(79)))
        except Exception:
            pass


    def updateFocus(self):
        try:
            self._alignTopSelector(); self["topSelector"].setVisible(self.focus == "top")
            self["trendSelector"].instance.move(ePoint(sx(self.TREND_X[self.trendIndex]), sy(555))); self["trendSelector"].setVisible(self.focus == "trending" and bool(self.trending))
            self["latestSelector"].instance.move(ePoint(sx(self.LATEST_X[self.latestIndex]), sy(825))); self["latestSelector"].setVisible(self.focus == "latest" and bool(self.latest))
        except Exception: pass

    def preview(self):
        item = self.current()
        if not item:
            return
        try:
            self["hero"].show()
        except Exception:
            pass
        # Every move gets a new token.  It guarantees that a slower lookup for
        # a previous poster cannot overwrite the backdrop of the current movie.
        self._previewRequestId += 1
        request_id = self._previewRequestId
        # Display-only cleanup for the selected title too. Do not mutate the
        # original server title used by playback/search.
        raw_title = item.get("name") or item.get("title") or ""
        title = self._backdropDisplayTitle(raw_title).upper()[:34]
        logo = ""  # Always fetch the official transparent TMDb logo.
        self["logoTitle"].setText(title)
        try:
            self["logoHintIcon"].setVisible(True)
            self["logoHint"].setVisible(True)
            self["logoImage"].setVisible(True)
        except Exception:
            pass
        try:
            self["logoImage"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "common/transparent.png"))
        except Exception:
            pass
        if logo:
            self.loadImage(logo, "logoImage", 260, 60)
        year = item.get("year") or item.get("releaseDate") or ""
        rating = item.get("rating") or item.get("rating_5based") or ""
        genre = item.get("genre") or ""
        self["heroMeta"].setText("   •   ".join(x for x in [str(year), ("★ " + str(rating)) if rating else "", str(genre)] if x))
        self["heroDesc"].setText((item.get("plot") or item.get("description") or "")[:260])
        back = self.imageUrl(item, True)
        if back:
            self.loadImage(back, "hero", 1920, 520)
        if not back or not logo:
            self._previewBackdropPending = (dict(item), request_id, True, not bool(logo))
            if getattr(self, "_categorySwitchPreviewNow", False):
                self._categorySwitchPreviewNow = False
                try:
                    self._previewBackdropTimer.stop()
                except Exception:
                    pass
                self._beginPreviewBackdropLookup()
            else:
                try:
                    self._previewBackdropTimer.stop()
                    self._previewBackdropTimer.start(180, True)
                except Exception:
                    self._beginPreviewBackdropLookup()

    def _beginPreviewBackdropLookup(self):
        pending = self._previewBackdropPending
        self._previewBackdropPending = None
        if not pending:
            return
        item, request_id, need_backdrop, need_logo = pending
        if request_id != self._previewRequestId:
            return
        _submit_content_bg(
            self._lookupPreviewArtwork,
            args=(item, request_id, need_backdrop, need_logo),
            key=("preview-artwork", id(self))
        )

    def _movieBackdropUrl(self, data):
        data = data or {}
        return self.norm(
            data.get("backdrop_path") or data.get("backdrop") or
            data.get("backdrop_url") or data.get("movie_backdrop")
        )

    def _bundleLogoUrl(self, data):
        data = data or {}
        images = data.get("images") or {}
        logos = images.get("logos") or []
        if not isinstance(logos, list):
            return ""
        ordered = sorted(logos, key=lambda row: 0 if row.get("iso_639_1") == "en" else (1 if not row.get("iso_639_1") else 2))
        for row in ordered:
            path = row.get("file_path") or ""
            if path:
                return self.norm(path)
        return ""

    def _lookupPreviewArtwork(self, item, request_id, need_backdrop=True, need_logo=True, force_tmdb_backdrop=False):
        """Portal/server first, then TMDb enhancement without holding the UI.

        A server backdrop is applied as soon as it is available. If TMDb search
        provides a backdrop, that is also applied before the slower full details
        request used for transparent logos and richer metadata. Stale requests
        are discarded by request_id, matching EStalker's fast navigation model.
        """
        try:
            if request_id != getattr(self, "_previewRequestId", request_id):
                return
            # r233: do not block Movies hero navigation on provider vod_info().
            # TV Shows were already fast because they went straight from the
            # visible row to TMDb cache. Movies now use that same path. Existing
            # server metadata in the row remains an immediate fallback.
            details = dict(item or {})
            if isinstance(item.get("info"), dict):
                details.update(item.get("info") or {})

            server_backdrop = self._movieBackdropUrl(details) if (need_backdrop and not force_tmdb_backdrop) else ""
            # Resolve relative provider backdrops against the active server.
            if server_backdrop and not item.get("_tmdb"):
                server_backdrop = _server_asset_url(self.source, server_backdrop)
            server_logo = self._bundleLogoUrl(details) if need_logo else ""
            if server_backdrop or server_logo:
                self._queueGui(self._applyPreviewArtwork, server_backdrop, server_logo, request_id)
            if request_id != self._previewRequestId:
                return

            need_tmdb_backdrop = bool(need_backdrop and not server_backdrop)
            need_tmdb_logo = bool(need_logo and not server_logo)

            # Metadata is intentionally independent from artwork. Even when the
            # server already supplied backdrop/logo, Movies/Series metadata must
            # still prefer TMDb and use server fields only as fallback.
            tmdb = TMDbClient()
            tmdb_id = details.get("tmdb_id") or details.get("tmdb") or item.get("tmdb_id") or item.get("tmdb")
            found = {}
            if not tmdb_id:
                raw_title = (details.get("name") or details.get("title") or
                             item.get("name") or item.get("title") or "")
                item_year = self._year(details) or self._year(item) or None
                if raw_title:
                    try:
                        found = tmdb.search_title(raw_title, self.kind, item_year) or {}
                        if not found:
                            found = tmdb.search_title(raw_title, self.kind, None) or {}
                    except Exception:
                        found = {}
                tmdb_id = found.get("id") or found.get("tmdb_id")

            quick_backdrop = self._movieBackdropUrl(found) if need_tmdb_backdrop else ""
            if quick_backdrop:
                self._queueGui(self._applyPreviewArtwork, quick_backdrop, "", request_id)
                need_tmdb_backdrop = False
            if request_id != self._previewRequestId or not tmdb_id:
                return

            try:
                bundle = tmdb.details_bundle(tmdb_id, self.kind) or {}
            except Exception:
                bundle = {}
            if found:
                seed = dict(found)
                seed.update(bundle or {})
                bundle = seed

            # Apply TMDb text/meta first. Missing individual fields remain as the
            # already-visible server values, so a partial TMDb response is safe.
            if bundle:
                self._queueGui(self._applyPreviewMetadata, bundle, request_id)

            backdrop = self._movieBackdropUrl(bundle) if need_tmdb_backdrop else ""
            logo = self._bundleLogoUrl(bundle) if need_tmdb_logo else ""
            if backdrop or logo:
                self._queueGui(self._applyPreviewArtwork, backdrop, logo, request_id)
        except Exception:
            pass

    def _applyPreviewMetadata(self, data, request_id):
        if request_id != self._previewRequestId:
            return
        data = data or {}
        title = data.get("title") or data.get("name") or ""
        release = data.get("release_date") or data.get("first_air_date") or ""
        year = str(release or "")[:4]
        rating = data.get("vote_average")
        genres = data.get("genres") or []
        if isinstance(genres, list):
            genre = ", ".join(str(x.get("name") or "") for x in genres[:3] if isinstance(x, dict) and x.get("name"))
        else:
            genre = str(genres or "")
        overview = data.get("overview") or ""
        if title:
            current = self.current() or {}
            server_title = str(current.get("name") or current.get("title") or "").strip()
            if re.search(r"[\u0600-\u06FF]", server_title):
                self["logoTitle"].setText(self._backdropDisplayTitle(server_title)[:34])
            else:
                self["logoTitle"].setText(str(title).upper()[:34])
        meta = []
        if year:
            meta.append(year)
        if rating not in (None, ""):
            try:
                meta.append("★ %.1f" % float(rating))
            except Exception:
                meta.append("★ " + str(rating))
        if genre:
            meta.append(genre)
        if meta:
            self["heroMeta"].setText("   •   ".join(meta))
        if overview:
            self["heroDesc"].setText(str(overview)[:260])

    def _applyPreviewArtwork(self, backdrop, logo, request_id):
        if request_id != self._previewRequestId:
            return
        if backdrop:
            self.loadImage(backdrop, "hero", 1920, 520)
        if logo:
            self.loadImage(logo, "logoImage", 260, 60)

    def left(self):
        if self.focus == "top": self.topIndex = max(0, self.topIndex - 1)
        elif self.focus == "trending":
            if self.trendIndex > 0: self.trendIndex -= 1
            elif self.trendStart > 0: self.trendStart = max(0, self.trendStart - 4); self.renderTrending()
        else:
            if self.latestIndex > 0: self.latestIndex -= 1
            elif self.latestStart > 0: self.latestStart = max(0, self.latestStart - 8); self.renderLatest()
        self.updateFocus(); self.preview()

    def right(self):
        if self.focus == "top": self.topIndex = min(len(self.TOP) - 1, self.topIndex + 1)
        elif self.focus == "trending":
            if self.trendIndex < 3 and self.trendStart + self.trendIndex + 1 < len(self.trending): self.trendIndex += 1
            elif self.trendStart + 4 < len(self.trending): self.trendStart += 4; self.trendIndex = 0; self.renderTrending()
        else:
            if self.latestIndex < 7 and self.latestStart + self.latestIndex + 1 < len(self.latest): self.latestIndex += 1
            elif self.latestStart + 8 < len(self.latest): self.latestStart += 8; self.latestIndex = 0; self.renderLatest()
        self.updateFocus(); self.preview()

    def up(self):
        if self.focus == "latest":
            self.focus = "trending"
        elif self.focus == "trending":
            self.focus = "top"
        else:
            self.focus = "top"
        self.updateFocus(); self.preview()



    def down(self):
        if self.focus == "top":
            # Trending is always the first content level. If it is still loading,
            # stay on top rather than jumping directly to the lower poster row.
            if self.trending:
                self.focus = "trending"
            elif not self.latest:
                self.focus = "top"
            else:
                # Only fall back when Trending is genuinely unavailable.
                self.focus = "latest"
        elif self.focus == "trending":
            self.focus = "latest" if self.latest else "trending"
        else:
            self.focus = "latest"
        self.updateFocus()
        if self.focus != "top":
            self.preview()


    def _backdropDisplayTitle(self, value):
        """Clean provider tags for Backdrop labels only; never mutate server data."""
        text = str(value or "").strip()
        if not text:
            return ""
        # Repeated leading provider/quality/language tags. Examples:
        # TOP - Title, 4K-NF - Title, AR-SUBS | Title, FHD: Title.
        tag = r"(?:TOP|NEW|RECENT|4K|8K|UHD|FHD|FULL\s*HD|HD|SD|NF|NETFLIX|AMZN|PRIME|DSNP|DISNEY\+?|HULU|HBO|MAX|WEB[- ]?DL|BLURAY|HEVC|X26[45]|HDR|DV|DOLBY|AR|EN|FR|TR|SUBS?|DUB(?:BED)?)"
        # Strip compound prefixes such as '4K-NF - ' or 'AR-SUBS | '.
        for _ in range(4):
            new = re.sub(r"^\s*(?:" + tag + r")(?:\s*[-_|:/+]\s*(?:" + tag + r"))*\s*(?:[-|:/]\s*)+", "", text, flags=re.I)
            if new == text:
                break
            text = new.strip()
        # Also remove bracketed prefix groups like [4K NF] / (TOP).
        text = re.sub(r"^\s*[\[(](?:[^\])]{0,28})[\])]\s*[-|:]?\s*", lambda m: "" if re.search(tag, m.group(0), re.I) else m.group(0), text).strip()
        return text or str(value or "").strip()

    def _normTitle(self, value):
        text = (value or "").lower()
        text = re.sub(r"\b(ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|uhd|fhd|hd|hevc|x265|x264|hdr|web[- ]?dl|bluray)\b", " ", text)
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"[^a-z0-9]+", " ", text)
        return " ".join(text.split())

    def _year(self, item):
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        m = re.search(r"\b(19|20)\d{2}\b", raw)
        return int(m.group(0)) if m else 0

    def _serverTmdbId(self, item):
        item = item or {}
        for key in ("tmdb_id", "tmdb", "tmdbid"):
            value = item.get(key)
            if value not in (None, ""):
                try:
                    return str(int(value))
                except Exception:
                    value = str(value).strip()
                    if value:
                        return value
        info = item.get("info")
        if isinstance(info, dict):
            for key in ("tmdb_id", "tmdb", "tmdbid"):
                value = info.get(key)
                if value not in (None, ""):
                    try:
                        return str(int(value))
                    except Exception:
                        value = str(value).strip()
                        if value:
                            return value
        return ""

    def _strictMatchFromRows(self, tmdbItem, rows):
        tmdbItem = tmdbItem or {}
        target_id = self._serverTmdbId(tmdbItem)
        target_year = self._year(tmdbItem)
        wanted = [
            self._normTitle(tmdbItem.get("name") or tmdbItem.get("title")),
            self._normTitle(tmdbItem.get("original_title") or tmdbItem.get("original_name"))
        ]
        wanted = [x for x in wanted if x]
        if not wanted and not target_id:
            return None

        # 1) Exact TMDb ID is authoritative.
        if target_id:
            for row in rows or []:
                if self._serverTmdbId(row) == target_id:
                    return row

        # 2) Title/year matching is intentionally strict.  A wrong movie is
        # worse than reporting "not available".
        best = None
        best_score = 0.0
        for row in rows or []:
            candidate = self._normTitle((row or {}).get("name") or (row or {}).get("title"))
            if not candidate:
                continue
            row_year = self._year(row)
            if target_year and row_year and target_year != row_year:
                continue

            score = max([self._title_score(w, candidate) for w in wanted] or [0.0])
            if score <= 0.0:
                continue

            # If either side lacks a year, accept only an exact/near-exact
            # normalized title.  This prevents remakes and similarly named films.
            if not (target_year and row_year) and score < 0.98:
                continue

            # With an exact year, still require a strong title identity.
            if target_year and row_year and score < 0.94:
                continue

            if score > best_score:
                best, best_score = row, score
        return best

    def matchServerItem(self, tmdbItem):
        match = self._strictMatchFromRows(tmdbItem, self.serverItems or [])
        if match:
            return match

        # Xtream serverItems already contains the full enabled catalogue.
        # Stalker landing mode contains only one package, so Popular/Trending
        # must search every enabled package before declaring the title absent.
        if self.source.get("type") != "stalker":
            return None
        try:
            client = get_source_client(self.source)
            categories, _origin = get_cached_categories(
                self.source, self.kind, client=client, wait_for_server=True
            )
            categories = filter_categories(self.source, self.kind, categories or [])
            for category in categories:
                category_id = str((category or {}).get("category_id") or "")
                if not category_id:
                    continue
                rows, _origin = get_category_streams(
                    self.source, self.kind, client, category_id,
                    use_cache=True, wait_for_server=True
                )
                match = self._strictMatchFromRows(tmdbItem, rows or [])
                if match:
                    return match
        except Exception:
            pass
        return None

    def playTrendingFromServer(self, item):
        # Server-backed Trending rows already carry their real playback id.
        # Keep the old matcher only as a compatibility fallback for cached rows.
        has_server_id = bool((item or {}).get("stream_id") or (item or {}).get("series_id") or (item or {}).get("vod_id"))
        match = dict(item or {}) if has_server_id else self.matchServerItem(item)
        if not match:
            self.session.open(MessageBox, tr("This title is not available on the current server."), MessageBox.TYPE_INFO)
            return
        if self.kind == "series":
            from .ui import SeriesDetailsScreen
            self.session.open(SeriesDetailsScreen, self.source, match)
            return
        try:
            from .tivimate_player import TiviMatePlayer
            url = get_source_client(self.source).stream_url(match, "vod")
            player_item = dict(match or {})
            try:
                from .ui import _source_identity
                player_item["_source_key"] = _source_identity(self.source)
            except Exception:
                player_item["_source_key"] = ""
            player_item["_source_type"] = self.source.get("type") or ""
            player_item["_kind"] = "vod"
            from .ui import _media_service_type
            service_type = int(_media_service_type(self.source, "vod"))
            service = eServiceReference(service_type, 0, url)
            service.setName(match.get("name") or item.get("name") or "MOVIE")
            self.session.open(TiviMatePlayer, service, player_item)
        except Exception as exc:
            self.session.open(MessageBox, "Unable to play:\n%s" % exc, MessageBox.TYPE_ERROR)

    def _switchContentKind(self, new_kind):
        """Switch Movies/TV Shows inside this same Screen; never stack another ContentHomeScreen."""
        if new_kind == self.kind:
            self.focus = "top"
            self.updateFocus()
            return
        self.contentGeneration += 1
        self.categoryLoadToken += 1
        self.kind = new_kind
        self.contentMode = _content_default_mode(new_kind)
        self.topIndex = 3 if new_kind == "vod" else 4
        self.focus = "top"

        self.trending, self.latest = [], []
        self.serverItems, self.categoryItems = [], []
        self.categoriesList = []
        self.categoriesLoaded = False
        self.categoryIndex = -1
        self.categoryName = ""
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        self.trendStart = self.trendIndex = self.latestStart = self.latestIndex = 0

        # Keep the top hero/trending title fixed while switching content type.
        primary_title = "Movies You Might Like" if new_kind == "vod" else "TV Shows You Might Like"
        self["trendingTitle"].setText(tr(primary_title))
        self._updateLatestTitle()
        self["latestCategoryName"].setText("")
        self["heroDesc"].setText("")
        self["logoTitle"].setText("")
        self["heroMeta"].setText("")
        try:
            # Never hide the hero while switching Movies/TV Shows.
            # Keep a visible placeholder until the new backdrop is decoded.
            self["hero"].show()
            if self["hero"].instance:
                self["hero"].instance.setPixmapFromFile(
                    os.path.join(PLUGIN_PATH, "skins", "home/banner_placeholder.jpg")
                )
            self["logoImage"].hide()
        except Exception:
            pass
        self.renderTrending()
        self.renderLatest()
        self.updateFocus()

        generation = self.contentGeneration
        t = threading.Thread(target=self.worker, args=(generation,), name="TiviMateContentSwitch")
        t.daemon = True
        t.start()

    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def ok(self):
        from .ui import TiviMateE2Search, TiviMateE2Home, MediaScreen, SeriesDetailsScreen, ServerHub, ContinueWatchingScreen, SettingsDashboard
        from .tivimate_player import TiviMatePlayer
        if self.focus == "top":
            if self.topIndex == 0:
                self._openPageOnce(TiviMateE2Search, self.source)
                return
            if self.topIndex == 1:
                self._openPageOnce(TiviMateE2Home)
                return
            if self.topIndex == 2:
                self._openPageOnce(MediaScreen, self.source, "live")
                return
            if self.topIndex == 3:
                self._switchContentKind("vod")
                return
            if self.topIndex == 4:
                self._switchContentKind("series")
                return
            if self.topIndex == 5:
                from .ui import ContentPackagesScreen
                self._openPageOnce(ContentPackagesScreen, self.source)
                return
            if self.topIndex == 6:
                self._openPageOnce(ContinueWatchingScreen, self.source)
                return
            if self.topIndex == 7:
                self._openPageOnce(SettingsDashboard)
                return
            return
        item = self.current()
        if not item:
            return
        if self.kind == "series":
            if item.get("_tmdb"):
                chosen = dict(item)
                chosen["_home_tmdb_feed"] = "content_%s" % self.contentMode
                self.session.open(SeriesDetailsScreen, self.source, chosen)
                return
            self.session.open(SeriesDetailsScreen, self.source, item)
            return
        if item.get("_tmdb"):
            chosen = dict(item)
            chosen["_home_tmdb_feed"] = "content_%s" % self.contentMode
            chosen["_source_scope"]="content_home"
            self.session.open(
                MovieDetailsScreen, self.source, chosen, self.serverItems,
                {"scope":"content_home","category_id":str(chosen.get("category_id") or ""),"items":list(self.serverItems or [])}
            )
            return
        detail_item=dict(item or {})
        detail_item["_source_scope"]="content_home"
        self.session.open(
            MovieDetailsScreen, self.source, detail_item, self.serverItems,
            {"scope":"content_home","category_id":str(detail_item.get("category_id") or ""),"items":list(self.serverItems or [])}
        )
        return

    def _sortLabel(self):
        return {"default": "Date", "name": "Name", "rating": "Rating"}.get(self.sortMode, "Date")

    def _sortBadge(self):
        labels = {
            "default": "[🕒 %s]" % tr("Date"),
            "name": "[A-Z %s]" % tr("Name"),
            "rating": "[★ %s]" % tr("Rating"),
        }
        return labels.get(self.sortMode, labels["default"])

    def _addedSortValue(self, item):
        """Return the provider's real add/update timestamp for Latest rows.

        Movies use ``added``. Series use ``last_modified`` first and then
        ``added`` because many Xtream panels do not publish ``added`` for a
        series. Production year and TMDb release dates are deliberately not
        used here.
        """
        row = item or {}
        if self.kind == "series":
            raw = row.get("last_modified")
            if raw in (None, "", 0, "0"):
                raw = row.get("added")
        else:
            raw = row.get("added")
        if raw is None:
            return 0
        try:
            value = float(raw)
            # Some portals send Unix time in milliseconds rather than seconds.
            if value != value or value == float("inf") or value == float("-inf"):
                return 0
            if abs(value) >= 100000000000:
                value = value / 1000.0
            return value
        except Exception:
            pass
        try:
            text = str(raw).strip().replace("T", " ")
        except Exception:
            return 0
        # Stalker commonly returns e.g. "2015-08-21 18:35:31".  Parse the
        # standard date-time part and tolerate an optional time-zone suffix.
        for value, pattern in ((text[:19], "%Y-%m-%d %H:%M:%S"), (text[:10], "%Y-%m-%d")):
            try:
                return time.mktime(time.strptime(value, pattern))
            except Exception:
                pass
        return 0

    def _sortedItems(self, items):
        rows = list(items or [])
        if self.sortMode == "name":
            rows.sort(key=lambda x: (x.get("name") or x.get("title") or "").lower())
        elif self.sortMode == "rating":
            def rating_value(x):
                try: return float(x.get("rating") or x.get("rating_5based") or 0)
                except Exception: return 0
            rows.sort(key=rating_value, reverse=True)
        else:
            # Sort timestamped entries newest-first. Keep entries for which the
            # provider exposes no usable timestamp in their original server
            # order instead of hiding the whole Series section.
            dated = []
            undated = []
            for position, item in enumerate(rows):
                stamp = self._addedSortValue(item)
                if stamp > 0:
                    dated.append((stamp, position, item))
                else:
                    undated.append((position, item))
            dated.sort(key=lambda entry: (entry[0], -entry[1]), reverse=True)
            rows = [entry[2] for entry in dated] + [entry[1] for entry in undated]
        return rows

    def _activeItems(self):
        return self.categoryItems if self.categoryIndex >= 0 else self.serverItems

    def _positionLatestCategoryName(self):
        """Keep the server package name directly beside the translated mode title."""
        try:
            if not self["latestTitle"].instance or not self["latestCategoryName"].instance:
                return
            lang = get_language()
            if lang == "ar":
                # Arabic heading is right-aligned in the block moved by
                # _applyArabicHeadingLayout. Put the package immediately to its left.
                title_x = 1110
                title_w = 730
                try:
                    rendered = self["latestTitle"].instance.calculateSize().width()
                except Exception:
                    rendered = max(220, min(700, len(self["latestTitle"].getText()) * 18))
                cat_w = 720
                x = max(80, title_x + title_w - rendered - cat_w - 18)
                self["latestCategoryName"].instance.move(ePoint(sx(x), sy(772)))
                self["latestCategoryName"].instance.resize(eSize(sx(cat_w), sy(45)))
                try:
                    self["latestCategoryName"].instance.setHAlign(2)
                except Exception:
                    pass
            else:
                title_x = 80
                try:
                    rendered = self["latestTitle"].instance.calculateSize().width()
                except Exception:
                    rendered = max(180, min(700, len(self["latestTitle"].getText()) * 17))
                x = min(1020, title_x + rendered + 14)
                self["latestCategoryName"].instance.move(ePoint(sx(x), sy(772)))
                self["latestCategoryName"].instance.resize(eSize(sx(820), sy(45)))
                try:
                    self["latestCategoryName"].instance.setHAlign(0)
                except Exception:
                    pass
        except Exception:
            pass

    def _updateLatestTitle(self):
        try:
            self["latestTitle"].setText(tr(_content_mode_title(self.kind, self.contentMode)))
        except Exception:
            pass
        try:
            category = str(getattr(self, "categoryName", "") or "").strip()

            # NONE disables only the optional automatic source label.
            # Keep server/package posters visible, but do not show the orphan
            # Date/Recent sort badge when no explicit package is selected.
            if self.contentMode == "none" and not category:
                self["latestCategoryName"].setText("")
                self._positionLatestCategoryName()
                return

            badge = self._sortBadge()
            if category:
                text = "  •  %s   %s" % (category, badge)
            else:
                text = "  •  %s" % badge
            self["latestCategoryName"].setText(text)
        except Exception:
            pass
        self._positionLatestCategoryName()

    def _changeCategory(self, direction):
        if not self.categoriesLoaded:
            self["heroDesc"].setText("")
            return
        if not self.categoriesList:
            self["heroDesc"].setText(tr("No enabled categories are available for this library."))
            return
        if direction < 0 and self.categoryIndex < 0:
            self.categoryIndex = len(self.categoriesList) - 1
        else:
            self.categoryIndex = (self.categoryIndex + direction) % len(self.categoriesList)
        category = self.categoriesList[self.categoryIndex]
        category_id = str(category.get("category_id") or "")
        self.categoryName = category.get("category_name") or "Other"
        _package_diag("CATEGORY_SWITCH", kind=self.kind, direction=direction, index=self.categoryIndex, category_id=category_id, category_name=self.categoryName)
        self._updateLatestTitle()
        if not category_id:
            return
        self.categoryLoadToken += 1
        token = self.categoryLoadToken

        # Reuse ONLY a package that this screen previously loaded as a full
        # provider response. Never reuse a global/recent/partial category map.
        if category_id in self._fullPackageRows:
            rows = list(self._fullPackageRows.get(category_id) or [])
            _package_diag("PACKAGE_SCREEN_RAM_HIT", kind=self.kind, category_id=category_id, category_name=self.categoryName, item_count=len(rows))
            self.categoryItems = rows
            self.latest = self._sortedItems(rows)
            self.latestStart = self.latestIndex = 0
            self.focus = "latest"
            self._categorySwitchPreviewNow = True
            self._updateLatestTitle()
            self.renderLatest()
            if self.latest:
                self.preview()
            self.updateFocus()
            self["heroDesc"].setText("")
            return

        self.categoryItems, self.latest = [], []
        self.latestStart = self.latestIndex = 0
        self.focus = "latest"
        self._updateLatestTitle(); self.renderLatest(); self.updateFocus()
        self["heroDesc"].setText("")
        name = "TiviMateNextCategory" if direction > 0 else "TiviMatePreviousCategory"
        is_stalker = self.source.get("type") == "stalker"
        if is_stalker:
            # Supersede any older unfinished category request.  The worker also
            # checks the token before storing a result, preventing an old reply
            # from overwriting a newer red/blue selection.
            self.stalkerCategoryLoadResult = None
            self.stalkerCategoryPendingToken = token
        submitted = _submit_content_bg(
            self._loadCategory,
            args=(token, category_id),
            key=("category-load", id(self))
        )
        _package_diag("PACKAGE_WORKER_SUBMIT", kind=self.kind, category_id=category_id, category_name=self.categoryName, token=token, submitted=submitted)
        if not submitted:
            self["heroDesc"].setText(tr("."))
        if is_stalker:
            try:
                self.stalkerCategoryLoadTimer.start(120, True)
            except Exception:
                pass

    def previousCategory(self):
        self._changeCategory(-1)

    def nextCategory(self):
        self._changeCategory(1)

    def _loadCategory(self, token, category_id):
        if token != getattr(self, "categoryLoadToken", token):
            return
        source = dict(self.source or {})
        try:
            client = get_source_client(source)
            cid = str(category_id or "").strip()
            # Package switch: use the per-package RAM/disk cache first.
            # On a real cache miss only, fetch this selected package from the
            # provider in the worker thread and persist it for the next visit.
            # This deliberately avoids the old direct client.streams() path,
            # which bypassed package cache and caused every switch to wait.
            _package_diag("PACKAGE_FETCH_BEGIN", kind=self.kind, category_id=cid, token=token, source_type=source.get("type") or "")
            items, origin = get_category_streams(
                source, self.kind, client, cid, use_cache=True, wait_for_server=True
            )
            _package_diag("PACKAGE_FETCH_DONE", kind=self.kind, category_id=cid, token=token, origin=origin, item_count=len(items or []))
            if source.get("type") == "stalker":
                if token == getattr(self, "categoryLoadToken", 0):
                    self.stalkerCategoryLoadResult = (token, items, origin, "")
                return
            self._queueGui(self.categoryReady, token, items, origin)
        except Exception as exc:
            _package_diag("PACKAGE_FETCH_ERROR", kind=self.kind, category_id=str(category_id or ""), token=token, error=repr(exc))
            if source.get("type") == "stalker":
                if token == getattr(self, "categoryLoadToken", 0):
                    self.stalkerCategoryLoadResult = (token, [], "error", str(exc))
                return
            self._queueGui(self.categoryFailed, token, str(exc))


    def _finishStalkerCategoryLoad(self):
        """Apply the newest Stalker category result only on the GUI thread."""
        expected = getattr(self, "stalkerCategoryPendingToken", None)
        if expected is None:
            return
        result = self.stalkerCategoryLoadResult
        if result is None:
            if expected == getattr(self, "categoryLoadToken", 0):
                try:
                    self.stalkerCategoryLoadTimer.start(120, True)
                except Exception:
                    pass
            return
        # A completion can race with this callback; erase only the same object
        # that was observed, never a newer result written by a newer worker.
        if self.stalkerCategoryLoadResult is result:
            self.stalkerCategoryLoadResult = None
        token, items, origin, error = result
        if token != getattr(self, "categoryLoadToken", 0) or token != expected:
            if getattr(self, "stalkerCategoryPendingToken", None) == getattr(self, "categoryLoadToken", 0):
                try:
                    self.stalkerCategoryLoadTimer.start(120, True)
                except Exception:
                    pass
            return
        self.stalkerCategoryPendingToken = None
        if error:
            self.categoryFailed(token, error)
        else:
            self.categoryReady(token, items, origin)

    def categoryReady(self, token, items, origin):
        if token != self.categoryLoadToken:
            _package_diag("CATEGORY_READY_STALE", kind=self.kind, token=token, current_token=self.categoryLoadToken, origin=origin, item_count=len(items or []))
            return
        self.categoryItems = list(items or [])
        _package_diag("CATEGORY_READY", kind=self.kind, token=token, category_name=self.categoryName, origin=origin, item_count=len(self.categoryItems))

        # Cache only this complete provider response.
        try:
            if 0 <= self.categoryIndex < len(self.categoriesList):
                current_cid = str((self.categoriesList[self.categoryIndex] or {}).get("category_id") or "")
                if current_cid:
                    self._fullPackageRows[current_cid] = list(self.categoryItems)
        except Exception:
            pass

        self.latest = self._sortedItems(self.categoryItems)
        self.latestStart = self.latestIndex = 0
        self.focus = "latest"
        self._updateLatestTitle(); self.renderLatest(); self.preview(); self.updateFocus()
        if not self.latest:
            if self.source.get("type") == "stalker" and origin == "empty":
                self["heroDesc"].setText("Stalker returned no items for %s. Try another package or refresh the source." % self.categoryName)
            else:
                self["heroDesc"].setText("No titles are available in %s." % self.categoryName)

    def categoryFailed(self, token, msg):
        if token != self.categoryLoadToken:
            _package_diag("CATEGORY_FAILED_STALE", kind=self.kind, token=token, current_token=self.categoryLoadToken, error=msg)
            return
        _package_diag("CATEGORY_FAILED", kind=self.kind, token=token, category_name=self.categoryName, error=msg)
        self.categoryItems, self.latest = [], []
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle(); self.renderLatest(); self.updateFocus()
        self["heroDesc"].setText("Unable to load %s: %s" % (self.categoryName, msg))

    def toggleSort(self):
        modes = ["default", "name", "rating"]
        try:
            pos = modes.index(self.sortMode)
        except Exception:
            pos = 0
        self.sortMode = modes[(pos + 1) % len(modes)]
        self.latest = self._sortedItems(self._activeItems())
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle(); self.renderLatest(); self.preview(); self.updateFocus()

    def serverList(self):
        from .ui import ServerManager
        self._openPageOnce(ServerHub)
    def categories(self):
        # Replace the legacy blue Movie/Series Categories screen with the
        # modern package browser; its artwork follows Movies vs Series.
        from .ui import HomePackageBrowserScreen
        self.session.openWithCallback(self.categoryChosen, HomePackageBrowserScreen, self.source, self.kind)

    def categoryChosen(self, selected=None):
        if not selected or not isinstance(selected, dict):
            return
        category_id = str(selected.get("id") or "")
        category_name = selected.get("name") or ""
        if not category_id:
            return
        # Green Packages is a launcher: after choosing a package, open the
        # large package/content page directly for that package. Do not filter
        # this Movies/TV Shows home page in-place.
        from .ui import MediaScreen
        if category_id == "__recent_added__":
            self._openPageOnce(MediaScreen, self.source, self.kind, category_id, category_name)
            return
        self._openPageOnce(MediaScreen, self.source, self.kind, category_id, category_name)

# r137: Home-triggered metadata-only warm for Movies/TV Shows backdrop rails.
def warm_backdrop_metadata_from_home(source):
    """Prepare Movies + TV backdrop rail rows and TMDb metadata without artwork downloads."""
    source = dict(source or {})
    if not source:
        return
    try:
        tmdb = TMDbClient()
    except Exception:
        return
    for kind in ("vod", "series"):
        try:
            allowed = set(str(x) for x in (get_allowed_category_ids(source, kind) or []) if str(x))
            if not allowed:
                continue
            filter_sig = hashlib.sha1(("|".join(sorted(allowed))).encode("utf-8")).hexdigest()[:12]
            cache_mode = "backdrop_filtered_smart_v6_anyyear_warm_%s_%s" % (kind, filter_sig)
            rows = _home_feed_cache_get(cache_mode, source, allow_stale=False)
            if not rows:
                client = get_source_client(source)
                ordered_ids = list(allowed)
                random.shuffle(ordered_ids)
                candidates, seen = [], set()
                for offset in range(0, len(ordered_ids), 4):
                    batches = get_category_streams_batch(source, kind, client, ordered_ids[offset:offset + 4], use_cache=True, wait_for_server=True, max_workers=4)
                    for cid, items, _origin in batches:
                        for raw in items or []:
                            if not isinstance(raw, dict):
                                continue
                            title = str(raw.get("name") or raw.get("title") or "").strip()
                            year = str(raw.get("year") or raw.get("releaseDate") or raw.get("release_date") or "").strip()
                            if not title:
                                continue
                            clean = re.sub(r"[^a-z0-9]+", " ", title.lower()).strip()
                            key = clean
                            if not clean or key in seen:
                                continue
                            seen.add(key)
                            row = dict(raw)
                            m = re.search(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)", year or title)
                            if m:
                                row["_backdrop_year"] = m.group(1)
                            candidates.append(row)
                    if len(candidates) >= 36:
                        break
                random.shuffle(candidates)
                rows = candidates[:12]
                if rows:
                    _home_feed_cache_put(cache_mode, source, rows)
            for row in rows[:12]:
                try:
                    title = str(row.get("name") or row.get("title") or "").strip()
                    if not title:
                        continue
                    year = str(row.get("_backdrop_year") or row.get("year") or "").strip()[:4] or None
                    resolved = str(row.get("tmdb_id") or row.get("tmdb") or "").strip()
                    found = {}
                    if not resolved:
                        found = tmdb.search_title(title, kind, year) or tmdb.search_title(title, kind, None) or {}
                        resolved = str(found.get("id") or found.get("tmdb_id") or "").strip()
                    if not resolved:
                        continue
                    bundle = tmdb.details_bundle(resolved, kind) or {}
                    merged = dict(found or {})
                    merged.update(bundle)
                    row["tmdb_id"] = resolved
                    bd = str(merged.get("backdrop_path") or "").strip()
                    ps = str(merged.get("poster_path") or "").strip()
                    if bd:
                        row["_tmdb_backdrop"] = bd
                    if ps:
                        row["_tmdb_poster"] = ps
                    norm = re.sub(r"[^a-z0-9]+", " ", title.lower()).strip()
                    _memory_put(_DETAILS_DATA_CACHE, "%s:%s" % (kind, resolved), merged, _DETAILS_DATA_CACHE_LIMIT)
                    _memory_put(_DETAILS_DATA_CACHE, "%s:title:%s:%s" % (kind, norm, str(year or "")), merged, _DETAILS_DATA_CACHE_LIMIT)
                except Exception:
                    continue
            if rows:
                _home_feed_cache_put(cache_mode, source, rows[:12])
        except Exception:
            continue
