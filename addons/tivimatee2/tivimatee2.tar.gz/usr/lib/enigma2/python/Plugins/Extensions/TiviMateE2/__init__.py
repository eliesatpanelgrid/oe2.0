# -*- coding: utf-8 -*-
from __future__ import absolute_import

# Compatibility helpers are imported locally by the program modules that need
# them.  No Python builtins or os functions are changed at package import time.
