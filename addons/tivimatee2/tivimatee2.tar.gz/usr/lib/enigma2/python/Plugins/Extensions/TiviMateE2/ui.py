# -*- coding: utf-8 -*-
from __future__ import absolute_import
from .compat import atomic_replace, ensure_dir, open_text, python_command

import os
import hashlib
import shlex
import json
import threading
import time

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.InfoBar import MoviePlayer
try:
    from Screens.AudioSelection import AudioSelection
except Exception:
    AudioSelection = None
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigText, ConfigPassword, ConfigSelection, getConfigListEntry
from enigma import (eServiceReference, ePicLoad, eTimer, eConsoleAppContainer, ePoint,
    eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_VALIGN_CENTER)
from Tools.LoadPixmap import LoadPixmap
from .live_service import live_reference, live_reference_string
try:
    from twisted.internet import reactor
except Exception:
    reactor = None

from .content_home import ContentHomeScreen, MovieDetailsScreen

from .cache_manager import get_cache_dir, get_cache_root, get_settings as get_cache_settings, save_settings as save_cache_settings, clear_cache, cache_status, cleanup_cache
from .artwork_queue import request_artwork
from .display_scale import scale_skin, sx, sy, scale_size

from .core import (
    get_sources, set_sources, write_playlists, PLAYLISTS_FILE,
    XtreamClient, M3UClient, StalkerClient, get_source_client, get_cached_catalog, clear_catalog_memory
)
from .server_status import evaluate_reply

from .artwork_queue import request_artwork
from .tmdb_client import load_settings as load_tmdb_settings, save_settings as save_tmdb_settings
from .subdl_client import (
    load_settings as load_subdl_settings,
    save_settings as save_subdl_settings,
    LANGUAGE_CHOICES as SUBDL_LANGUAGE_CHOICES,
)
from .filters import (source_filter_key as _source_filter_key, load_all_filters as _load_all_filters,
    save_all_filters as _save_all_filters, get_allowed_category_ids, filter_items as filter_items_for_source,
    filter_categories, get_filtered_streams, get_category_streams, prefetch_allowed_series,
    prefetch_selected_categories, get_cached_categories, get_stalker_landing_items, get_stalker_home_items)
from .favorites import (add_favourite, toggle_favourite, is_favourite, list_favourites,
    source_for_record, remove_record, count as favourites_count)
from .update_manager import check_for_update, download_package, install_command

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
SUBDL_IMPORT_FILE = "/tmp/key.txt"
IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")
INFO_FETCH = os.path.join(PLUGIN_PATH, "info_fetch.py")
PYTHON_EXECUTABLE, PYTHON_COMMAND = python_command()


def _read_subdl_import_key():
    """Read one non-empty SubDL key from the agreed temporary file."""
    if not os.path.isfile(SUBDL_IMPORT_FILE):
        raise IOError("missing")
    with open_text(SUBDL_IMPORT_FILE, "rb") as handle:
        raw = handle.read(1025)
    if len(raw) > 1024:
        raise ValueError("too_long")
    try:
        value = raw.decode("utf-8", "ignore")
    except Exception:
        value = str(raw)
    lines = [line.strip() for line in value.replace("\ufeff", "").splitlines() if line.strip()]
    if len(lines) != 1:
        raise ValueError("invalid_content")
    return lines[0]
# Artwork is now processed by artwork_queue with two background transfers.
# Keep this switch false so legacy screen paths can show cached/queued artwork.
SAFE_TABLE_MODE = False
CHANNEL_SETTINGS_FILE = "/etc/enigma2/tivimatee2_channel_settings.json"

def _load_channel_settings():
    # These settings belong strictly to Live playback and the visual interface.
    defaults = {"auto_zap": True, "picon": True, "service_type": 4097}
    try:
        with open_text(CHANNEL_SETTINGS_FILE, "r") as f:
            data = json.load(f) or {}
        defaults.update({k: bool(data.get(k, defaults[k])) for k in ("auto_zap", "picon")})
        try:
            defaults["service_type"] = int(data.get("service_type", 4097))
        except Exception:
            defaults["service_type"] = 4097
    except Exception:
        pass
    return defaults

def _save_channel_settings(data):
    try:
        folder = os.path.dirname(CHANNEL_SETTINGS_FILE)
        if not os.path.isdir(folder): os.makedirs(folder)
        tmp = CHANNEL_SETTINGS_FILE + ".tmp"
        with open_text(tmp, "w") as f:
            json.dump(data, f)
        os.rename(tmp, CHANNEL_SETTINGS_FILE)
        return True
    except Exception:
        return False
HOME_APPEARANCE_FILE = "/etc/enigma2/tivimatee2/home_appearance.json"

def _load_home_appearance():
    # Skin 1 is the default Home on a fresh installation; Skin 2 remains an
    # opt-in cinematic alternative.  Any retired layout value falls back to Skin 1.
    data = {"skin": "reference_home"}
    try:
        with open_text(HOME_APPEARANCE_FILE, "r") as f:
            saved = json.load(f)
        if saved.get("skin") in ("reference_home", "skin2_dark"):
            data["skin"] = saved.get("skin")
    except Exception:
        pass
    return data

def _save_home_appearance(skin_name):
    try:
        folder = os.path.dirname(HOME_APPEARANCE_FILE)
        if not os.path.isdir(folder): os.makedirs(folder)
        tmp = HOME_APPEARANCE_FILE + ".tmp"
        with open_text(tmp, "w") as f:
            json.dump({"skin": skin_name}, f)
        os.rename(tmp, HOME_APPEARANCE_FILE)
        return True
    except Exception:
        return False

UPDATE_SETTINGS_FILE = "/etc/enigma2/tivimatee2/update_settings.json"

def _load_update_settings():
    defaults = {"auto_check": True}
    try:
        with open_text(UPDATE_SETTINGS_FILE, "r") as handle:
            stored = json.load(handle) or {}
        defaults["auto_check"] = bool(stored.get("auto_check", defaults["auto_check"]))
    except Exception:
        pass
    return defaults


def _save_update_settings(auto_check):
    try:
        folder = os.path.dirname(UPDATE_SETTINGS_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = UPDATE_SETTINGS_FILE + ".tmp"
        with open_text(temporary, "w") as handle:
            json.dump({"auto_check": bool(auto_check)}, handle)
        os.rename(temporary, UPDATE_SETTINGS_FILE)
        return True
    except Exception:
        return False

HOME_SKIN1 = '''<screen name="TiviMateE2Home" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#050C14">
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home_reference_v4_bg_r77_1920x1080.png" alphatest="blend" zPosition="0" />
		<widget name="homeBrandLogo" position="62,10" size="300,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="6" />
        <widget name="poweredBy" position="1420,1038" size="360,22" font="Regular;16" foregroundColor="#87CDEE" backgroundColor="#00000000" transparent="1" halign="right" zPosition="7" />
	<ePixmap position="13,320" size="64,273" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/sidebar_classic_icons_v2.png" alphatest="blend" zPosition="6" />
	<widget name="headline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="subheadline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="logo" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="nav0" position="380,27" size="150,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="nav1" position="550,27" size="150,58" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="nav2" position="710,27" size="150,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="nav3" position="870,27" size="150,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="nav4" position="1030,27" size="170,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
	<widget name="nav5" position="1210,27" size="165,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
	<widget name="nav6" position="1390,27" size="160,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
	<widget name="nav7" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
	<widget name="navSelector" position="550,27" size="150,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_reference_v4.png" alphatest="blend" zPosition="3" />
	<widget name="clock" position="1625,35" size="180,32" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
	<widget name="date" position="1625,68" size="180,22" font="Regular;15" foregroundColor="#91A0B4" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />

	<widget name="banner" position="108,120" size="1704,454" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder_v4.jpg" alphatest="blend" scale="1" zPosition="1" />
<ePixmap position="108,120" size="1704,454" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_overlay_v4.png" alphatest="blend" zPosition="2" />
<widget name="quality" position="155,151" size="330,30" font="Regular;20" foregroundColor="#27C8FF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureTitle" position="155,194" size="720,112" font="Regular;56" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureMeta" position="155,324" size="700,36" font="Regular;23" foregroundColor="#DDE5EF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureDesc" position="155,371" size="720,84" font="Regular;22" foregroundColor="#DDE5EF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="playNow" position="155,498" size="240,60" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#187DD8" halign="center" valign="center" zPosition="4" />
<widget name="recentTitle" position="100,610" size="500,42" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="poster0" position="106,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="106,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="116,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate0" position="116,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle0" position="184,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster1" position="398,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="398,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="408,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate1" position="408,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle1" position="476,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster2" position="690,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="690,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="700,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate2" position="700,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle2" position="768,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster3" position="982,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="982,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="992,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate3" position="992,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle3" position="1060,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster4" position="1274,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1274,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="1284,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate4" position="1284,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle4" position="1352,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster5" position="1566,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1566,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="1576,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate5" position="1576,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle5" position="1644,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="posterSelector" position="106,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r74_248x338.png" alphatest="blend" zPosition="8" />
<widget name="status" position="520,1038" size="880,26" font="Regular;17" foregroundColor="#95A2B5" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
</screen>'''

SEARCH_SCREEN = '''<screen name="TiviMateE2Search" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
<eLabel position="0,0" size="1920,1080" backgroundColor="#000000" zPosition="0" />
<widget name="back" position="55,62" size="85,70" font="Regular;44" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<ePixmap position="145,55" size="1510,82" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/search_bar.png" alphatest="blend" zPosition="1" />
<widget name="searchText" position="205,70" size="1325,52" font="Regular;31" foregroundColor="#F3F4F8" backgroundColor="#00000000" transparent="1" valign="center" zPosition="2" />
<widget name="mic" position="1670,55" size="80,82" font="Regular;39" foregroundColor="#F5C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<widget name="closeIcon" position="1775,55" size="80,82" font="Regular;39" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<widget name="moviesTitle" position="85,175" size="600,48" font="Regular;31" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" />
<widget name="showsTitle" position="85,690" size="600,48" font="Regular;31" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" />
<widget name="poster0" position="85,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="85,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="95,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate0" position="95,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel0" position="163,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster1" position="325,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="325,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="335,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate1" position="335,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel1" position="403,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster2" position="565,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="565,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="575,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate2" position="575,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel2" position="643,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster3" position="805,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="805,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="815,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate3" position="815,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel3" position="883,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster4" position="1045,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1045,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="1055,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate4" position="1055,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel4" position="1123,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster5" position="1285,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1285,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="1295,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate5" position="1295,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel5" position="1363,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster6" position="85,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="85,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="95,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate6" position="95,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel6" position="163,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster7" position="325,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="325,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="335,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate7" position="335,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel7" position="403,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster8" position="565,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="565,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="575,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate8" position="575,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel8" position="643,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster9" position="805,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="805,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="815,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate9" position="815,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel9" position="883,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster10" position="1045,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1045,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="1055,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate10" position="1055,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel10" position="1123,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster11" position="1285,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1285,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="1295,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate11" position="1295,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel11" position="1363,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="movieSelector" position="85,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r74_215x360.png" alphatest="blend" zPosition="8" />
<widget name="showSelector" position="85,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r74_215x265.png" alphatest="blend" zPosition="8" />
<ePixmap position="1540,365" size="330,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/search_details.png" alphatest="blend" zPosition="2" />
<widget name="selectedTitle" position="1565,388" size="280,90" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="3" />
<widget name="play" position="1565,492" size="280,64" font="Regular;28" foregroundColor="#111318" backgroundColor="#E2B84B" halign="center" valign="center" zPosition="3" />
<widget name="favorite" position="1565,570" size="280,44" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#343B47" halign="center" valign="center" zPosition="3" />
<widget name="status" position="600,1000" size="850,34" font="Regular;21" foregroundColor="#D2D8E1" backgroundColor="#00000000" transparent="1" halign="center" />
<widget name="guideBar" position="420,1034" size="1080,52" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/search_guide_r69.png" alphatest="blend" zPosition="4" />
</screen>'''

SOURCE_MENU = '''<screen name="TiviMateE2SourceMenu" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#06101D">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_solid_navy_r64.png" alphatest="blend" zPosition="0" />
    <eLabel position="0,0" size="1920,112" backgroundColor="#0A111C" zPosition="1" />
    <ePixmap position="72,14" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="5" />
    <widget name="brand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="side" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="title" position="112,178" size="1120,58" font="Regular;42" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="subtitle" position="115,238" size="600,30" font="Regular;20" foregroundColor="#73D4FF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="108,302" size="1704,498" backgroundColor="#0E1C2D" zPosition="1" />
    <eLabel position="110,304" size="1700,494" backgroundColor="#13243A" zPosition="2" />
    <widget name="menu" position="170,360" size="1450,310" font="Regular;31" itemHeight="64" foregroundColor="#EDF6FF" foregroundColorSelected="#FFFFFF" backgroundColor="#00000000" backgroundColorSelected="#187DB8" scrollbarMode="showOnDemand" zPosition="4" />
    <widget name="info" position="170,710" size="1450,54" font="Regular;22" foregroundColor="#B9C7D8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="keys" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="guideBar" position="420,920" size="1080,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/source_menu_guide_r69.png" alphatest="blend" zPosition="5" />
</screen>'''

EDITOR = '''<screen name="TiviMateE2PlaylistEditor" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#06101D">
    <!-- RGB PNG base: one opaque navy colour, with no alpha channel or panel overlays. -->
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_solid_navy_r64.png" alphatest="blend" zPosition="0" />
    <widget name="settingsLogo" position="78,14" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="5" />
    <widget name="settingsBrand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsTagline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNavSelector" position="1215,27" size="165,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_classic_focus_v5.png" alphatest="blend" zPosition="3" />
    <widget name="settingsNav0" position="450,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav1" position="603,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav2" position="756,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav3" position="909,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav4" position="1062,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav5" position="1215,27" size="165,58" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsClock" position="1430,28" size="160,34" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" zPosition="4" />
    <widget name="settingsDate" position="1430,67" size="190,26" font="Regular;17" foregroundColor="#91A0B4" backgroundColor="#00000000" transparent="1" halign="left" zPosition="4" />
    <widget name="settingsSideTitle" position="126,202" size="250,42" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <widget name="settingsSideText" position="126,284" size="235,150" font="Regular;20" foregroundColor="#B4C8DB" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <widget name="settingsSideHint" position="126,735" size="235,74" font="Regular;19" foregroundColor="#6DD8FF" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <widget name="title" position="500,196" size="1260,52" font="Regular;39" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <widget name="config" position="500,294" size="1230,480" font="Regular;30" itemHeight="68" foregroundColor="#F5F8FC" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" zPosition="3" />
    <widget name="hint" position="500,878" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
    <widget name="settingsGuide" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_guide_keyboard_save_r69.png" alphatest="blend" zPosition="4" />
    <widget name="settingsActionButtons" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_action_buttons_r65.png" alphatest="blend" zPosition="4" />
</screen>'''

# Server Manager keeps the existing menu, navigation and action bar intact.  Only
# the unused lower space becomes a general connection-status card; no account or
# subscriber information is displayed here.
SERVER_MANAGER_SKIN = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="ServerManager"').replace(
    '''    <widget name="config" position="500,294" size="1230,480" font="Regular;30" itemHeight="68" foregroundColor="#F5F8FC" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" zPosition="3" />
    <widget name="hint" position="500,878" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="3" />''',
    '''    <widget name="config" position="500,294" size="1230,380" font="Regular;30" itemHeight="68" foregroundColor="#F5F8FC" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" zPosition="3" />
    <eLabel position="500,792" size="1230,132" backgroundColor="#10233A" zPosition="1" />
    <eLabel position="502,794" size="1226,128" backgroundColor="#142B46" zPosition="2" />
    <ePixmap position="1298,796" size="430,124" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_network_r123.png" alphatest="blend" zPosition="3" />
    <widget name="serverStatusTitle" position="536,808" size="650,28" font="Regular;24" foregroundColor="#F2FBFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="serverStatusText" position="536,844" size="650,26" font="Regular;20" foregroundColor="#B9CDE0" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendOnlineIcon" position="536,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_online_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendOnline" position="562,875" size="170,26" font="Regular;18" foregroundColor="#67E89A" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendCheckingIcon" position="740,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_busy_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendChecking" position="766,875" size="185,26" font="Regular;18" foregroundColor="#FFD669" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendOfflineIcon" position="960,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_offline_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendOffline" position="986,875" size="185,26" font="Regular;18" foregroundColor="#FF8C95" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="hint" position="500,892" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="5" />'''
).replace(
    '''    <widget name="settingsActionButtons" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_action_buttons_r65.png" alphatest="blend" zPosition="4" />
</screen>''',
    '''    <widget name="settingsActionButtons" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_action_buttons_r65.png" alphatest="blend" zPosition="4" />
    <ePixmap position="1480,948" size="250,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_subdl_shortcut_r103.png" alphatest="blend" zPosition="6" />
</screen>'''
)


def _setup_settings_chrome(screen):
    labels = ["Search", "Home", "Live", "Movies", "TV Shows", "Settings"]
    screen["settingsBrand"] = Label("TiViMate")
    screen["settingsTagline"] = Label("IPTV EXPERIENCE")
    screen["settingsLogo"] = Pixmap()
    screen["settingsSideTitle"] = Label("CONTROL CENTER")
    screen["settingsSideText"] = Label("Manage playlists,\nconnections and metadata,\nand appearance settings.")
    screen["settingsSideHint"] = Label("Use the colour keys below\nfor quick actions.")
    screen["settingsNavSelector"] = Pixmap()
    screen["settingsGuide"] = Pixmap()
    screen["settingsActionButtons"] = Pixmap()
    try:
        screen["settingsNavSelector"].hide()
        screen["settingsGuide"].hide()
        screen["settingsActionButtons"].hide()
    except Exception:
        pass
    for index, label in enumerate(labels):
        screen["settingsNav%d" % index] = Label(label)
    now = time.localtime()
    screen["settingsClock"] = Label(time.strftime("%H:%M", now))
    screen["settingsDate"] = Label(time.strftime("%a, %d %b", now))


def _show_settings_guide(screen):
    try:
        screen["settingsGuide"].show()
    except Exception:
        pass



# Skin 2 is the optional cinematic Home dashboard selected in Home Appearance.
# It intentionally preserves every widget TiviMateE2Home manages at runtime.
HOME_SKIN2 = """<screen name="TiviMateE2Home" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#090B1E">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#090B1E" zPosition="0" />
    <eLabel position="0,0" size="1920,114" backgroundColor="#0D1024" zPosition="3" />
    <eLabel position="0,112" size="1920,2" backgroundColor="#7142D0" zPosition="4" />
    <widget name="banner" position="0,114" size="1920,444" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_global_hero_r70.png" alphatest="blend" zPosition="1" />
    <ePixmap position="0,114" size="1920,444" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_hero_overlay.png" alphatest="blend" zPosition="2" />
    <eLabel position="0,558" size="1920,522" backgroundColor="#090B1E" zPosition="1" />

    <widget name="logo" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="homeBrandLogo" position="58,10" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="7" />
    <widget name="headline" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="subheadline" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="nav0" position="340,28" size="142,56" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav1" position="495,28" size="152,56" font="Regular;28" foregroundColor="#E9E5F7" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav2" position="665,28" size="148,56" font="Regular;28" foregroundColor="#E9E5F7" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav3" position="830,28" size="150,56" font="Regular;28" foregroundColor="#E9E5F7" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav4" position="995,28" size="150,56" font="Regular;28" foregroundColor="#E9E5F7" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav5" position="1160,28" size="160,56" font="Regular;28" foregroundColor="#E9E5F7" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav6" position="1335,28" size="160,56" font="Regular;28" foregroundColor="#E9E5F7" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav7" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="navSelector" position="345,93" size="142,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_nav_focus.png" alphatest="blend" zPosition="9" />
    <widget name="clock" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="date" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />

    <widget name="quality" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="featureTitle" position="104,177" size="940,68" font="Regular;43" foregroundColor="#FAF8FF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="7" />
    <widget name="featureMeta" position="104,246" size="990,46" font="Regular;26" foregroundColor="#EAE6F7" backgroundColor="#00000000" transparent="1" valign="center" zPosition="7" />
    <widget name="featureDesc" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="playNow" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />

    <widget name="recentTitle" position="105,519" size="500,38" font="Regular;27" foregroundColor="#F4F0FF" backgroundColor="#00000000" transparent="1" zPosition="8" />
    <widget name="poster0" position="105,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" />
    <ePixmap position="105,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate0" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle0" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="poster1" position="367,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" />
    <ePixmap position="367,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate1" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle1" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="poster2" position="629,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" />
    <ePixmap position="629,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate2" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle2" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="poster3" position="891,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" />
    <ePixmap position="891,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate3" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle3" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="poster4" position="1153,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" />
    <ePixmap position="1153,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate4" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle4" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="poster5" position="1415,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" />
    <ePixmap position="1415,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate5" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle5" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="posterSelector" position="105,570" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_focus.png" alphatest="blend" zPosition="10" />
    <ePixmap position="555,897" size="630,13" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_progress_rail.png" alphatest="blend" zPosition="6" />

    <ePixmap position="195,944" size="1530,92" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_action_buttons.png" alphatest="blend" zPosition="6" />
    <eLabel position="228,962" size="300,52" text="ADD IPTV SOURCE" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />
    <eLabel position="520,965" size="30,30" text="A" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />
    <eLabel position="615,962" size="315,52" text="UPDATE PLAYLIST" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />
    <eLabel position="925,965" size="30,30" text="B" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />
    <eLabel position="1055,962" size="205,52" text="ACCOUNT" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />
    <eLabel position="1280,965" size="30,30" text="X" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />
    <eLabel position="1450,962" size="180,52" text="EXIT" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />
    <eLabel position="1675,965" size="30,30" text="Y" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />
    <eLabel position="690,1040" size="540,28" text="Developed by opesboy" font="Regular;22" foregroundColor="#CDAEFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />
    <widget name="status" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
</screen>"""

LIVE_CLASSIC = """<screen name="MediaScreen" position="0,0" size="1920,1080" backgroundColor="#00000000" flags="wfNoBorder">
    <!-- r106: one edge-to-edge black live surface at 20% opacity (#33) per request; all other Live layout elements remain unchanged. -->
    <eLabel position="0,0" size="1920,1080" backgroundColor="#33000000" zPosition="0" />

    <widget name="brand" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="rail" position="-20,-20" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />
    <widget name="title" position="64,42" size="1280,38" font="Regular;30" foregroundColor="#F5FAFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="5" />
    <widget name="clockTitle" position="1510,44" size="340,30" font="Regular;21" foregroundColor="#D8E0E8" backgroundColor="#00000000" transparent="1" halign="right" zPosition="5" />

    <eLabel position="64,166" size="352,42" text="PACKAGES" font="Regular;22" foregroundColor="#F6F8FC" backgroundColor="#00000000" transparent="1" zPosition="5" />
    <widget name="categoryTitle" position="74,888" size="352,25" font="Regular;17" foregroundColor="#CCD4DD" backgroundColor="#00000000" transparent="1" zPosition="5" />
    <widget name="category" position="70,230" size="360,628" font="Regular;22" itemHeight="56" foregroundColor="#F4F6F8" backgroundColor="#00000000" transparent="1" zPosition="4" />

    <eLabel position="510,166" size="450,42" text="CHANNELS" font="Regular;22" foregroundColor="#F6F8FC" backgroundColor="#00000000" transparent="1" zPosition="5" />
    <widget name="pageInfo" position="1090,174" size="142,28" font="Regular;18" foregroundColor="#CCD4DD" backgroundColor="#00000000" transparent="1" halign="right" zPosition="5" />
    <widget name="list" position="592,236" size="638,608" font="Regular;21" itemHeight="60" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="rowPicon0" position="514,243" size="64,46" alphatest="blend" zPosition="7" />
    <widget name="rowPicon1" position="514,303" size="64,46" alphatest="blend" zPosition="7" />
    <widget name="rowPicon2" position="514,363" size="64,46" alphatest="blend" zPosition="7" />
    <widget name="rowPicon3" position="514,423" size="64,46" alphatest="blend" zPosition="7" />
    <widget name="rowPicon4" position="514,483" size="64,46" alphatest="blend" zPosition="7" />
    <widget name="rowPicon5" position="514,543" size="64,46" alphatest="blend" zPosition="7" />
    <widget name="rowPicon6" position="514,603" size="64,46" alphatest="blend" zPosition="7" />
    <widget name="rowPicon7" position="514,663" size="64,46" alphatest="blend" zPosition="7" />
    <widget name="rowPicon8" position="514,723" size="64,46" alphatest="blend" zPosition="7" />
    <widget name="rowPicon9" position="514,783" size="64,46" alphatest="blend" zPosition="7" />

    <eLabel position="1324,166" size="430,32" text="NOW PLAYING" font="Regular;19" foregroundColor="#F6F8FC" backgroundColor="#00000000" transparent="1" zPosition="5" />
    <widget name="channelPicon" position="1448,220" size="268,152" alphatest="blend" zPosition="6" />
    <widget name="channelTitle" position="1324,396" size="516,74" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
    <widget name="meta" position="1324,481" size="516,29" font="Regular;19" foregroundColor="#D8E0E8" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <widget name="desc" position="1337,542" size="490,268" font="Regular;23" foregroundColor="#EEF1F4" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />

    <!-- r120: retain the Movies-style lower footer while labeling the actual Live shortcuts. -->
    <widget name="guideBar" position="80,1015" size="1760,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live_guide_r120.png" alphatest="blend" zPosition="6" />

    <widget name="nowLabel" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="keys" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
</screen>"""
VOD = '''<screen name="TiviMateE2Vod" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#10151d">
<widget name="backdrop" position="0,0" size="1920,1080" alphatest="blend" zPosition="0" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_overlay.png" alphatest="blend" zPosition="1" />
<widget name="top0" position="90,24" size="180,48" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top1" position="285,24" size="180,48" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top2" position="480,24" size="180,48" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top3" position="675,24" size="180,48" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top4" position="870,24" size="210,48" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="topSelector" position="675,75" size="190,5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/top_selector.png" alphatest="blend" zPosition="7" />
<!-- compatibility widgets kept off-screen: categories are opened through FILTER only -->
<widget name="brand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="rail" position="-10,-10" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />
<widget name="category" position="-10,-10" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />
<widget name="sectionTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="currentCategory" position="80,450" size="700,42" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="searchIcon" position="1650,55" size="85,55" font="Regular;36" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
<widget name="filterIcon" position="1740,55" size="110,55" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
<widget name="title" position="80,92" size="1500,44" font="Regular;27" foregroundColor="#D8E0E8" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="channelTitle" position="80,137" size="1500,70" font="Regular;49" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="meta" position="80,212" size="1470,44" font="Regular;27" foregroundColor="#F1F4F8" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="desc" position="80,272" size="1180,185" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="nowLabel" position="1650,450" size="190,42" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
<widget name="poster0" position="70,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="70,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_270x435.png" alphatest="blend" zPosition="3" />
<ePixmap position="82,916" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="poster1" position="450,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="450,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_270x435.png" alphatest="blend" zPosition="3" />
<ePixmap position="462,916" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="poster2" position="830,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="830,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_270x435.png" alphatest="blend" zPosition="3" />
<ePixmap position="842,916" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="poster3" position="1210,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1210,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_270x435.png" alphatest="blend" zPosition="3" />
<ePixmap position="1222,916" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="poster4" position="1590,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1590,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r74_270x435.png" alphatest="blend" zPosition="3" />
<ePixmap position="1602,916" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate0" position="82,916" size="58,34" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate1" position="462,916" size="58,34" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate2" position="842,916" size="58,34" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate3" position="1222,916" size="58,34" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate4" position="1602,916" size="58,34" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel0" position="146,905" size="183,55" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel1" position="526,905" size="183,55" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel2" position="906,905" size="183,55" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel3" position="1286,905" size="183,55" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel4" position="1666,905" size="183,55" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="selector" position="70,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r74_270x435.png" alphatest="blend" zPosition="8" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="80,1015" size="1760,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/vod_guide_r115.png" alphatest="blend" zPosition="6" />
</screen>'''

SERIES_DETAILS = '''<screen name="TiviMateE2SeriesDetails" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#11151d">
<widget name="backdrop" position="0,0" size="1920,1080" alphatest="blend" zPosition="0" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_overlay.png" alphatest="blend" zPosition="1" />
<widget name="title" position="80,65" size="1450,70" font="Regular;46" foregroundColor="#ffffff" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="rating" position="85,150" size="120,48" font="Regular;28" foregroundColor="#20242c" backgroundColor="#e8edf4" halign="center" valign="center" zPosition="3" />
<widget name="meta" position="230,150" size="1180,48" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="cast" position="85,220" size="1260,100" font="Regular;25" foregroundColor="#e7ebf1" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="desc" position="85,325" size="1260,190" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="seasonInfo" position="1450,565" size="390,52" font="Regular;29" foregroundColor="#ffffff" backgroundColor="#11151d" transparent="1" halign="right" zPosition="3" />
<widget name="episode0" position="80,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode1" position="440,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode2" position="800,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode3" position="1160,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode4" position="1520,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episodeLabel0" position="80,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel1" position="440,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel2" position="800,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel3" position="1160,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel4" position="1520,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeSelector" position="72,632" size="346,282" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_select.png" alphatest="blend" zPosition="5" />
<widget name="episodeInfo" position="85,925" size="1500,58" font="Regular;23" foregroundColor="#dce3eb" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="85,1005" size="1740,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_details_guide_r69.png" alphatest="blend" zPosition="5" />
</screen>'''

# The XML uses a 1920x1080 design canvas.  Convert it once at import time
# when the active Enigma2 desktop is WQHD, before any Screen is constructed.
HOME_SKIN1 = scale_skin(HOME_SKIN1)
HOME_SKIN2 = scale_skin(HOME_SKIN2)
SEARCH_SCREEN = scale_skin(SEARCH_SCREEN)
SOURCE_MENU = scale_skin(SOURCE_MENU)
EDITOR = scale_skin(EDITOR)
SERVER_MANAGER_SKIN = scale_skin(SERVER_MANAGER_SKIN)
LIVE_CLASSIC = scale_skin(LIVE_CLASSIC)
VOD = scale_skin(VOD)
SERIES_DETAILS = scale_skin(SERIES_DETAILS)


class PlaylistEditor(Screen, ConfigListScreen):
    skin = EDITOR

    def __init__(self, session, source=None, callback=None):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.callback = callback
        self.original = source or {}
        self["title"] = Label("ADD XTREAM CODES PLAYLIST")
        self["hint"] = Label("Playlist file: %s" % PLAYLISTS_FILE)
        self["keys"] = Label("OK  KEYBOARD    GREEN  SAVE    RED  CANCEL")
        self.provider = ConfigText(default=self.original.get("name", "IPTV"), fixed_size=False)
        self.protocol = ConfigSelection(default=self._protocol(), choices=[("http://", "http://"), ("https://", "https://")])
        host, port = self._host_port()
        self.server = ConfigText(default=host, fixed_size=False)
        self.port = ConfigText(default=port, fixed_size=False)
        self.username = ConfigText(default=self.original.get("username", ""), fixed_size=False)
        self.password = ConfigPassword(default=self.original.get("password", ""), fixed_size=False)
        self.output = ConfigSelection(default=self.original.get("output", "ts"), choices=[("ts", "TS"), ("m3u8", "M3U8")])
        entries = [
            getConfigListEntry("Playlist Name", self.provider),
            getConfigListEntry("Protocol", self.protocol),
            getConfigListEntry("Server URL", self.server),
            getConfigListEntry("Port", self.port),
            getConfigListEntry("Username", self.username),
            getConfigListEntry("Password", self.password),
            getConfigListEntry("Stream Format", self.output),
        ]
        ConfigListScreen.__init__(self, entries, session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.openKeyboard, "green": self.save, "red": self.close, "cancel": self.close
        }, -1)

    def _protocol(self):
        return "https://" if self.original.get("url", "").startswith("https://") else "http://"

    def _host_port(self):
        url = self.original.get("url", "").replace("http://", "").replace("https://", "").rstrip("/")
        return tuple(url.rsplit(":", 1)) if ":" in url else (url, "")

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if not current:
            return
        cfg = current[1]
        if not isinstance(cfg, (ConfigText, ConfigPassword)):
            return
        self.session.openWithCallback(self.keyboardCallback, VirtualKeyBoard, title=current[0], text=cfg.value or "")

    def keyboardCallback(self, value=None):
        if value is None:
            return
        current = self["config"].getCurrent()
        if current:
            current[1].value = value
            self["config"].invalidateCurrent()

    def save(self):
        host = (self.server.value or "").strip().replace("http://", "").replace("https://", "").rstrip("/")
        port = (self.port.value or "").strip()
        if not host or not self.username.value or not self.password.value:
            return self.session.open(MessageBox, "Enter the server URL, username, and password.", MessageBox.TYPE_ERROR)
        url = self.protocol.value + host + ((":" + port) if port else "")
        src = {
            "type": "xtream", "name": self.provider.value or "IPTV", "url": url,
            "username": self.username.value, "password": self.password.value,
            "output": self.output.value
        }
        if self.callback:
            self.callback(src)
        self.close(src)


class SourceTypePicker(Screen):
    """Choose a source type before opening the matching editor."""
    skin = SOURCE_MENU

    def __init__(self, session):
        Screen.__init__(self, session)
        self["brand"] = Label("TiViMate")
        self["side"] = MenuList([])
        self["title"] = Label("ADD A SOURCE")
        self["subtitle"] = Label("Choose the type of IPTV connection")
        self["menu"] = MenuList([
            ("Xtream Codes", "xtream"),
            ("Stalker Portal  •  Live, Movies & TV Shows", "stalker"),
        ])
        self["info"] = Label("Stalker requires your own Portal URL and MAG MAC address. No portal is included.")
        self["keys"] = Label("OK SELECT    EXIT BACK")
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.choose, "cancel": self.close,
            "up": self["menu"].up, "down": self["menu"].down
        }, -1)

    def choose(self):
        current = self["menu"].getCurrent()
        if current:
            self.close(current[1])


class StalkerPortalEditor(Screen, ConfigListScreen):
    """Private local editor for a user-supplied Stalker/Ministra VOD portal."""
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="StalkerPortalEditor"')

    def __init__(self, session, source=None, callback=None):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.callback = callback
        self.original = source or {}
        self["title"] = Label("STALKER PORTAL  •  LIVE, MOVIES & TV SHOWS")
        self["hint"] = Label("Enter your own Portal URL and MAG MAC address. No portal or account is bundled with TiViMate.")
        self["keys"] = Label("OK  KEYBOARD    GREEN  SAVE    RED  CANCEL")
        self.provider = ConfigText(default=self.original.get("name", "Stalker Portal"), fixed_size=False)
        self.portal = ConfigText(default=self.original.get("url", ""), fixed_size=False)
        self.mac = ConfigText(default=self.original.get("mac", ""), fixed_size=False)
        ConfigListScreen.__init__(self, [
            getConfigListEntry("Portal Name", self.provider),
            getConfigListEntry("Portal URL", self.portal),
            getConfigListEntry("MAG MAC Address", self.mac),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.openKeyboard, "green": self.save, "red": self.close, "cancel": self.close
        }, -1)

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if not current or not isinstance(current[1], ConfigText):
            return
        self.session.openWithCallback(self.keyboardCallback, VirtualKeyBoard, title=current[0], text=current[1].value or "")

    def keyboardCallback(self, value=None):
        if value is None:
            return
        current = self["config"].getCurrent()
        if current:
            current[1].value = value
            self["config"].invalidateCurrent()

    def _normalisePortal(self):
        portal = (self.portal.value or "").strip().rstrip("/")
        if portal and "://" not in portal:
            portal = "http://" + portal
        return portal

    def _normaliseMac(self):
        return (self.mac.value or "").strip().upper().replace("-", ":")

    def save(self):
        portal = self._normalisePortal()
        mac = self._normaliseMac()
        valid_portal = portal.startswith("http://") or portal.startswith("https://")
        parts = mac.split(":")
        try:
            valid_mac = len(parts) == 6 and all(len(part) == 2 and int(part, 16) >= 0 for part in parts)
        except Exception:
            valid_mac = False
        if not valid_portal or not valid_mac:
            return self.session.open(MessageBox, "Enter a valid Portal URL and a MAG MAC address in the format 00:1A:79:12:34:56.", MessageBox.TYPE_ERROR)
        src = {
            "type": "stalker", "name": (self.provider.value or "Stalker Portal").strip() or "Stalker Portal",
            "url": portal, "mac": mac
        }
        if self.callback:
            self.callback(src)
        self.close(src)


class TMDbSettings(Screen, ConfigListScreen):
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="TMDbSettings"')

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = load_tmdb_settings()
        self["title"] = Label("TMDb TRENDING SETTINGS")
        self["hint"] = Label("Enter a TMDb API key. Trending metadata comes from TMDb; playback uses the selected server.")
        self["keys"] = Label("OK KEYBOARD    GREEN SAVE    RED CANCEL")
        self.apiKey = ConfigText(default=cfg.get("api_key", ""), fixed_size=False)
        self.language = ConfigSelection(default=cfg.get("language", "en-US"), choices=[("en-US", "English"), ("ar-AE", "Arabic")])
        ConfigListScreen.__init__(self, [
            getConfigListEntry("TMDb API Key", self.apiKey),
            getConfigListEntry("Metadata language", self.language),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.openKeyboard, "green": self.save, "red": self.close, "cancel": self.close
        }, -1)

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if current and isinstance(current[1], ConfigText):
            self.session.openWithCallback(self.keyboardDone, VirtualKeyBoard, title=current[0], text=current[1].value or "")

    def keyboardDone(self, value=None):
        if value is None: return
        current = self["config"].getCurrent()
        if current:
            current[1].value = value
            self["config"].invalidateCurrent()

    def save(self):
        if not (self.apiKey.value or "").strip():
            return self.session.open(MessageBox, "Enter a TMDb API key.", MessageBox.TYPE_ERROR)
        if save_tmdb_settings(self.apiKey.value, self.language.value):
            self.session.open(MessageBox, "TMDb settings saved.", MessageBox.TYPE_INFO)
            self.close()
        else:
            self.session.open(MessageBox, "Unable to save settings.", MessageBox.TYPE_ERROR)


class ServerCategoryFilter(Screen):
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="ServerCategoryFilter"').replace('settings_guide_keyboard_save_r69.png', 'settings_guide_filter_r69.png')
    ALL_KINDS = [("live", "LIVE TV"), ("vod", "MOVIES"), ("series", "TV SHOWS")]

    def __init__(self, session, source):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.source = source or {}
        # M3U and portal profiles expose a generic LIVE catalogue.  Keep the
        # familiar VOD/series filters for Xtream, while allowing the same LIVE
        # bouquet selector to work for every supported source.
        if self.source.get("type") in ("stalker", "xtream"):
            self.KINDS = list(self.ALL_KINDS)
        else:
            self.KINDS = [("live", "LIVE TV")]
        self.kindIndex = 0
        self.rows = []
        self.selected = {}
        self.loaded = {}
        self["title"] = Label("SERVER CONTENT FILTER")
        self["config"] = MenuList([])
        self["hint"] = Label("Load only the categories you need to keep lists, search, and images fast.")
        self["keys"] = Label("LEFT/RIGHT  SECTION    OK  TOGGLE    GREEN  SAVE    YELLOW  SELECT ALL    BLUE  CLEAR ALL    EXIT  BACK")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.toggle, "cancel": self.close, "green": self.save,
            "yellow": self.selectAll, "blue": self.clearAll,
            "left": self.prevKind, "right": self.nextKind,
            "up": self["config"].up, "down": self["config"].down
        }, -1)
        self.onLayoutFinish.append(self.loadCurrent)

    def _kind(self):
        return self.KINDS[self.kindIndex][0]

    def loadCurrent(self):
        kind, label = self.KINDS[self.kindIndex]
        self["title"].setText("SERVER FILTER  •  %s" % label)
        self["hint"].setText("Loading %s categories..." % label)
        try:
            source_type = self.source.get("type")
            if source_type == "xtream":
                cats = XtreamClient(self.source).categories(kind) or []
                candidates = [(cat.get("category_id", ""), cat.get("category_name") or "Other") for cat in cats]
            elif source_type == "stalker":
                cats = StalkerClient(self.source).categories(kind) or []
                candidates = [(cat.get("category_id", ""), cat.get("category_name") or "Other") for cat in cats]
            else:
                entries = M3UClient(self.source).entries() or []
                candidates = [(entry.get("group", "Other"), entry.get("group", "Other")) for entry in entries]
            clean = []
            seen = set()
            for raw_id, raw_name in candidates:
                cid = str(raw_id or "").strip()
                if not cid or cid in seen:
                    continue
                seen.add(cid)
                clean.append({"id": cid, "name": str(raw_name or "Other").strip()})
            self.loaded[kind] = clean
            if kind not in self.selected:
                configured = get_allowed_category_ids(self.source, kind)
                self.selected[kind] = set(x["id"] for x in clean) if configured is None else set(configured)
            self.render()
        except Exception as exc:
            self.rows = []
            self["config"].setList([])
            self["hint"].setText("Unable to load categories: %s" % exc)

    def render(self):
        kind, label = self.KINDS[self.kindIndex]
        selected = self.selected.get(kind, set())
        self.rows = self.loaded.get(kind, [])
        rows = [("[%s]  %s" % ("✓" if x["id"] in selected else " ", x["name"]), x["id"]) for x in self.rows]
        self["config"].setList(rows)
        self["hint"].setText("%s: %d of %d enabled" % (label, len(selected), len(self.rows)))

    def toggle(self):
        current = self["config"].getCurrent()
        if not current:
            return
        kind = self._kind()
        cid = str(current[1])
        selected = self.selected.setdefault(kind, set())
        if cid in selected:
            selected.remove(cid)
        else:
            selected.add(cid)
        idx = self["config"].getSelectedIndex()
        self.render()
        try: self["config"].moveToIndex(idx)
        except Exception: pass

    def selectAll(self):
        kind = self._kind()
        self.selected[kind] = set(x["id"] for x in self.loaded.get(kind, []))
        self.render()

    def clearAll(self):
        self.selected[self._kind()] = set()
        self.render()

    def prevKind(self):
        self.kindIndex = (self.kindIndex - 1) % len(self.KINDS)
        self.loadCurrent()

    def nextKind(self):
        self.kindIndex = (self.kindIndex + 1) % len(self.KINDS)
        self.loadCurrent()

    def save(self):
        data = _load_all_filters()
        key = _source_filter_key(self.source)
        entry = dict(data.get(key, {}) or {})
        for kind, _label in self.KINDS:
            if kind not in self.selected:
                continue
            selected = set(str(x) for x in self.selected.get(kind, set()))
            available = set(str(x.get("id") or "") for x in self.loaded.get(kind, []))
            # Selecting every category is identical to an unfiltered catalogue.
            # Store no per-category restriction in that case, so the normal
            # aggregate cache is reused instead of downloading each category.
            if available and selected == available:
                entry.pop(kind, None)
            else:
                entry[kind] = sorted(selected)
        if entry:
            data[key] = entry
        else:
            data.pop(key, None)
        if _save_all_filters(data):
            # Newly enabled, cold categories are warmed in the background.  The
            # setting screen closes straight away, and the cached list appears
            # without a synchronous full refresh on the next screen.
            try:
                prefetch_selected_categories(self.source, entry)
            except Exception:
                pass
            self.session.open(MessageBox, "تم حفظ الفلتر بسرعة. يجري تجهيز الفئات الجديدة بالخلفية عند الحاجة.", MessageBox.TYPE_INFO)
            self.close(True)
        else:
            self.session.open(MessageBox, "Unable to save the filter.", MessageBox.TYPE_ERROR)


class ImageCacheSettings(Screen, ConfigListScreen):
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="ImageCacheSettings"').replace('settings_guide_keyboard_save_r69.png', 'settings_guide_cache_r69.png')

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = get_cache_settings()
        self["title"] = Label("IMAGE CACHE")
        self["hint"] = Label("")
        self["keys"] = Label("GREEN  SAVE    BLUE  CLEAR CACHE    YELLOW  CLEAN UP    EXIT  BACK")
        self.location = ConfigSelection(default=str(cfg.get("location", "auto")), choices=[
            ("auto", "Auto: HDD, then USB"),
            ("hdd", "HDD /media/hdd"),
            ("usb", "USB /media/usb"),
            ("mmc", "MMC /media/mmc"),
            ("tmp", "Temporary /tmp"),
        ])
        self.maxSize = ConfigSelection(default=str(cfg.get("max_mb", 150)), choices=[
            ("50", "50 MB"), ("100", "100 MB"), ("150", "150 MB (Recommended)")
        ])
        self.retention = ConfigSelection(default=str(cfg.get("retention_days", 14)), choices=[
            ("7", "7 days"), ("14", "14 days (Recommended)"), ("30", "30 days")
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry("Cache Location", self.location),
            getConfigListEntry("Maximum Size", self.maxSize),
            getConfigListEntry("Delete Images Older Than", self.retention),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "blue": self.clearNow, "yellow": self.cleanNow,
            "red": self.close, "cancel": self.close
        }, -1)
        self.onLayoutFinish.append(self.updateHint)

    def updateHint(self):
        root, size, files = cache_status()
        self["hint"].setText("Current location: %s  •  %.1f MB  •  %d files" % (root, size / 1048576.0, files))

    def save(self):
        if save_cache_settings(self.location.value, int(self.maxSize.value), int(self.retention.value)):
            cleanup_cache()
            self.updateHint()
            self.session.open(MessageBox, "Cache settings saved. New images will use the selected location.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save cache settings.", MessageBox.TYPE_ERROR)

    def clearNow(self):
        if clear_cache():
            try:
                clear_catalog_memory()
            except Exception:
                pass
            self.updateHint()
            self.session.open(MessageBox, "Image and list cache cleared.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to clear image cache.", MessageBox.TYPE_ERROR)

    def cleanNow(self):
        cleanup_cache()
        self.updateHint()
        self.session.open(MessageBox, "Image cache cleaned according to the size and retention settings.", MessageBox.TYPE_INFO)


class HomeAppearanceSettings(Screen, ConfigListScreen):
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="HomeAppearanceSettings"').replace('settings_guide_keyboard_save_r69.png', 'settings_guide_save_back_r69.png')

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        current = _load_home_appearance()
        self.homeSkin = ConfigSelection(default=current.get("skin", "reference_home"), choices=[
            ("reference_home", "Skin 1 — Reference Home (Default)"),
            ("skin2_dark", "Skin 2 — Cinematic Home"),
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry("Home Skin", self.homeSkin)
        ], session=session)
        self["title"] = Label("HOME APPEARANCE")
        self["hint"] = Label("Changes apply to the Home screen only. Restart the app after saving.")
        self["keys"] = Label("GREEN  SAVE    RED  BACK")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "ok": self.save, "red": self.close, "cancel": self.close
        }, -1)

    def save(self):
        if _save_home_appearance(self.homeSkin.value):
            self.session.open(MessageBox, "Home skin saved. Close and reopen the app to apply the design.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save appearance setting.", MessageBox.TYPE_ERROR)


class UpdateSettingsScreen(Screen, ConfigListScreen):
    """Settings and user-confirmed manual update flow for verified packages."""
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="UpdateSettingsScreen"').replace('settings_guide_keyboard_save_r69.png', 'settings_guide_save_back_r69.png')

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = _load_update_settings()
        self.autoCheck = ConfigSelection(default="on" if cfg.get("auto_check", True) else "off", choices=[
            ("on", "On"), ("off", "Off")
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry("Automatic update check", self.autoCheck)
        ], session=session)
        self["title"] = Label("SOFTWARE UPDATES")
        self["hint"] = Label("Automatic checks only read a small verified update manifest. Press YELLOW to check now.")
        self["keys"] = Label("GREEN  SAVE    YELLOW  CHECK NOW    RED  BACK")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "yellow": self.manualCheck, "ok": self.save,
            "red": self.close, "cancel": self.close
        }, -1)
        self._checkPending = None
        self._downloadPending = None
        self._candidate = None
        self._installProcess = None
        self._checkInProgress = False
        self._downloadInProgress = False
        self._checkTimer = eTimer()
        self._downloadTimer = eTimer()
        try:
            self._checkTimer.callback.append(self._pollCheck)
        except Exception:
            self._checkTimer.timeout.get().append(self._pollCheck)
        try:
            self._downloadTimer.callback.append(self._pollDownload)
        except Exception:
            self._downloadTimer.timeout.get().append(self._pollDownload)
        self.onClose.append(self._stopTimers)

    def _stopTimers(self):
        for timer in (getattr(self, "_checkTimer", None), getattr(self, "_downloadTimer", None)):
            try:
                timer.stop()
            except Exception:
                pass

    def save(self):
        enabled = self.autoCheck.value == "on"
        if _save_update_settings(enabled):
            state = "enabled" if enabled else "disabled"
            self["hint"].setText("Automatic update checks are %s. Press YELLOW to check now." % state)
            self.session.open(MessageBox, "Update settings saved.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save update settings.", MessageBox.TYPE_ERROR)

    def manualCheck(self):
        if self._checkInProgress or self._downloadInProgress or self._installProcess:
            return
        self._checkInProgress = True
        self._checkPending = None
        self["hint"].setText("Checking for a verified update...")

        def worker():
            try:
                self._checkPending = check_for_update()
            except Exception:
                self._checkPending = {}

        try:
            thread = threading.Thread(target=worker, name="TiviMateManualUpdateCheck")
            thread.daemon = True
            thread.start()
            self._checkTimer.start(200, True)
        except Exception:
            self._checkPending = {}
            self._pollCheck()

    def _pollCheck(self):
        if self._checkPending is None:
            try:
                self._checkTimer.start(200, True)
            except Exception:
                pass
            return
        result = self._checkPending or {}
        self._checkPending = None
        self._checkInProgress = False
        if not result.get("available"):
            if result.get("reason") == "current":
                self["hint"].setText("TiViMate E2 is already up to date.")
                self.session.open(MessageBox, "No update is available. TiViMate E2 is already up to date.", MessageBox.TYPE_INFO)
            else:
                self["hint"].setText("Unable to verify updates right now. You can try again later.")
                self.session.open(MessageBox, "Unable to check for updates. Please try again later.", MessageBox.TYPE_ERROR)
            return
        self._candidate = result
        version = result.get("version") or "1.0.02"
        revision = result.get("revision") or "?"
        notes = result.get("notes") or ""
        text = "A verified TiviMate E2 update is available.\n\nVersion: %s (revision %s)" % (version, revision)
        if notes:
            text += "\n\n" + notes
        text += "\n\nDownload and install it now?"
        self.session.openWithCallback(self._confirmUpdate, MessageBox, text, type=MessageBox.TYPE_YESNO, default=False)

    def _confirmUpdate(self, answer):
        if not answer or not self._candidate:
            return
        package = self._candidate.get("package")
        if not package:
            return
        self._downloadInProgress = True
        self._downloadPending = None
        self["hint"].setText("Downloading and verifying the update package...")

        def worker():
            self._downloadPending = download_package(package)

        try:
            thread = threading.Thread(target=worker, name="TiviMateManualUpdateDownload")
            thread.daemon = True
            thread.start()
            self._downloadTimer.start(200, True)
        except Exception:
            self._downloadPending = {"ok": False, "message": "Unable to start download"}
            self._pollDownload()

    def _pollDownload(self):
        if self._downloadPending is None:
            try:
                self._downloadTimer.start(200, True)
            except Exception:
                pass
            return
        result = self._downloadPending or {}
        self._downloadPending = None
        self._downloadInProgress = False
        if not result.get("ok"):
            self["hint"].setText("Update download failed.")
            return self.session.open(MessageBox, "Update download failed.\n\n%s" % (result.get("message") or "Please try again later."), MessageBox.TYPE_ERROR)
        command = install_command(result)
        if not command:
            self["hint"].setText("The verified package could not be installed.")
            return self.session.open(MessageBox, "The verified update package could not be installed.", MessageBox.TYPE_ERROR)
        self["hint"].setText("Installing TiViMate E2 update...")
        try:
            process = eConsoleAppContainer()
            self._installProcess = process
            try:
                process.appClosed.append(self._installFinished)
            except Exception:
                process.appClosed.get().append(self._installFinished)
            process.execute("/bin/sh", "sh", "-c", command)
        except Exception:
            self["hint"].setText("Unable to start the update installer.")
            self.session.open(MessageBox, "Unable to start the update installer.", MessageBox.TYPE_ERROR)

    def _installFinished(self, status):
        self._installProcess = None
        if status == 0:
            self["hint"].setText("Update completed. Restart the Enigma2 GUI to use the new version.")
            self.session.open(MessageBox, "TiViMate E2 was updated successfully.\n\nPlease restart the Enigma2 GUI to use the new version.", MessageBox.TYPE_INFO)
        else:
            self["hint"].setText("The update installer returned an error.")
            self.session.open(MessageBox, "The update installer returned an error. Your current installation has not been changed.", MessageBox.TYPE_ERROR)


class SubDLSubtitleLanguageSettings(Screen, ConfigListScreen):
    """Default download language for the YELLOW SubDL subtitle action."""
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="SubDLSubtitleLanguageSettings"').replace(
        'settings_guide_keyboard_save_r69.png', 'settings_guide_save_back_r69.png'
    )

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        current = load_subdl_settings()
        self.targetLanguage = ConfigSelection(
            default=current.get("language", "ar"),
            choices=SUBDL_LANGUAGE_CHOICES,
        )
        ConfigListScreen.__init__(self, [
            getConfigListEntry("Download SubDL subtitles in", self.targetLanguage),
        ], session=session)
        self["title"] = Label("SUBDL SUBTITLE LANGUAGE")
        self["hint"] = Label(
            "This language is used by the YELLOW SubDL button. Import the SubDL API key separately from Server Manager."
        )
        self["keys"] = Label("GREEN  SAVE    RED  BACK")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "ok": self.save, "red": self.close, "cancel": self.close,
        }, -1)

    def save(self):
        try:
            current = load_subdl_settings()
            save_subdl_settings(
                current.get("api_key", ""),
                self.targetLanguage.value,
                current.get("kind", "standard"),
            )
            self.close(True)
        except Exception:
            self.session.open(MessageBox, "Could not save the SubDL subtitle language.", MessageBox.TYPE_ERROR, timeout=5)


class ServerStatusList(MenuList):
    """MenuList that preserves source rows while drawing a local health dot.

    The source dictionary remains the first element of every row, so ServerManager
    keeps the same selection, scrolling, action-key and source-editing behaviour.
    """
    STATUS_PIXMAPS = {
        "online": os.path.join(PLUGIN_PATH, "skins/server_status_online_r123.png"),
        "busy": os.path.join(PLUGIN_PATH, "skins/server_status_busy_r123.png"),
        "checking": os.path.join(PLUGIN_PATH, "skins/server_status_checking_r123.png"),
        "offline": os.path.join(PLUGIN_PATH, "skins/server_status_offline_r123.png"),
    }

    def __init__(self):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 30))
            self.l.setItemHeight(68)
        except Exception:
            pass
        self._pixmaps = {}
        for name, path in self.STATUS_PIXMAPS.items():
            try:
                self._pixmaps[name] = LoadPixmap(path)
            except Exception:
                self._pixmaps[name] = None

    def setSources(self, sources, states):
        rows = [self._makeRow(source, states.get(self._key(source), "checking")) for source in sources]
        self.setList(rows)

    @staticmethod
    def _key(source):
        endpoint = source.get("url") or source.get("host") or source.get("server") or source.get("portal") or ""
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("name", ""), endpoint, source.get("username", ""))

    def _makeRow(self, source, state):
        title = "%s  •  %s" % (source.get("name", "SERVER"), source.get("type", "").upper())
        pixmap = self._pixmaps.get(state) or self._pixmaps.get("checking")
        return [source,
            MultiContentEntryPixmapAlphaBlend(pos=(14, 18), size=(32, 32), png=pixmap),
            MultiContentEntryText(pos=(64, 0), size=(1148, 68), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=title,
                color=0x00F5F8FC, color_sel=0x00FFFFFF)]


class ServerManager(Screen):
    skin = SERVER_MANAGER_SKIN
    NAV_X = [450, 603, 756, 909, 1062, 1215]

    def __init__(self, session, selectCallback=None):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        self.selectCallback = selectCallback
        self.sources = []
        self._serverStates = {}
        self._statusResult = None
        self._statusToken = 0
        self._statusClosed = False
        self.settingsFocus = "list"
        self.settingsNavIndex = 5
        self["title"] = Label("SETTINGS  •  SERVER MANAGER")
        self["config"] = ServerStatusList()
        self["serverStatusTitle"] = Label("SERVER STATUS  •  CONNECTION & ACTIVE USE")
        self["serverStatusText"] = Label("Yellow appears only when the server reports active use.")
        self["statusLegendOnlineIcon"] = Pixmap()
        self["statusLegendOnline"] = Label("ONLINE")
        self["statusLegendCheckingIcon"] = Pixmap()
        self["statusLegendChecking"] = Label("IN USE")
        self["statusLegendOfflineIcon"] = Pixmap()
        self["statusLegendOffline"] = Label("OFFLINE")
        self["hint"] = Label("Press 5 SUBDL for API key import, subtitle language or font. Press 3 for Updates.")
        self["keys"] = Label("")
        self._statusTimer = eTimer()
        try:
            self._statusTimer.callback.append(self._finishStatusRefresh)
        except Exception:
            self._statusTimer.timeout.get().append(self._finishStatusRefresh)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "NumberActions"], {
            "ok": self.ok, "cancel": self.close, "green": self.addSource,
            "yellow": self.editSource, "red": self.delSource, "blue": self.testSource,
            "menu": self.openTMDb, "0": self.openFilter, "1": self.openCacheSettings, "2": self.openAppearanceSettings, "3": self.openUpdateSettings, "5": self.openSubDLSettingsMenu,
            "up": self.up, "down": self.down, "left": self.left, "right": self.right
        }, -1)
        self.onLayoutFinish.append(self._settingsLayoutReady)
        self.onLayoutFinish.append(self._startStatusRefresh)
        self.onClose.append(self._stopStatusRefresh)
        self.reload()

    def _settingsLayoutReady(self):
        self._statusReady = True
        try:
            self["settingsActionButtons"].show()
        except Exception:
            pass
        self._updateSettingsFocus()

    def _updateSettingsFocus(self):
        try:
            if self["settingsNavSelector"].instance:
                self["settingsNavSelector"].instance.move(ePoint(sx(self.NAV_X[self.settingsNavIndex]), sy(27)))
            self["settingsNavSelector"].show() if self.settingsFocus == "nav" else self["settingsNavSelector"].hide()
        except Exception:
            pass

    def up(self):
        if self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex - 1) % len(self.NAV_X)
        else:
            try:
                at_top = self["config"].getSelectedIndex() <= 0
            except Exception:
                at_top = True
            if at_top:
                self.settingsFocus = "nav"
            else:
                self["config"].up()
        self._updateSettingsFocus()

    def down(self):
        if self.settingsFocus == "nav":
            self.settingsFocus = "list"
        else:
            self["config"].down()
        self._updateSettingsFocus()

    def left(self):
        if self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex - 1) % len(self.NAV_X)
            self._updateSettingsFocus()

    def right(self):
        if self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex + 1) % len(self.NAV_X)
            self._updateSettingsFocus()

    def ok(self):
        if self.settingsFocus == "nav":
            return self.openTopMenu()
        return self.select()

    def openTopMenu(self):
        index = self.settingsNavIndex
        if index == 5:
            self.settingsFocus = "list"
            return self._updateSettingsFocus()
        source = self.current()
        if index == 1:
            return self.session.open(TiviMateE2Home)
        if not source:
            return self.session.open(MessageBox, "Select a server first.", MessageBox.TYPE_INFO)
        if index == 0:
            return self.session.open(TiviMateE2Search, source)
        if index == 2 and source.get("type") in ("xtream", "stalker", "m3u"):
            return self.session.open(MediaScreen, source, "live")
        if index == 3 and source.get("type") in ("xtream", "stalker"):
            return self.session.open(ContentHomeScreen, source, "vod")
        if index == 4 and source.get("type") in ("xtream", "stalker"):
            return self.session.open(ContentHomeScreen, source, "series")
        return self.session.open(MessageBox, "The selected source does not provide this section.", MessageBox.TYPE_INFO)

    def openTMDb(self):
        self.session.open(TMDbSettings)

    def openCacheSettings(self):
        self.session.open(ImageCacheSettings)

    def openAppearanceSettings(self):
        self.session.open(HomeAppearanceSettings)

    def openUpdateSettings(self):
        self.session.open(UpdateSettingsScreen)

    def openSubDLSubtitleLanguage(self):
        self.session.open(SubDLSubtitleLanguageSettings)

    def openSubDLSubtitleFont(self):
        """Open the external-SRT font configuration owned by SubsSupport."""
        try:
            from Plugins.Extensions.SubsSupport.subtitles import initSubsSettings, SubsSetupExternal
            settings = initSubsSettings()
            external = getattr(settings, "external", None)
            if external is None:
                raise RuntimeError("missing external subtitle settings")
            return self.session.open(SubsSetupExternal, external)
        except ImportError:
            return self.session.open(
                MessageBox,
                "Font settings require SubsSupport. Install or update SubsSupport from your receiver plugin feed, then open 5 > Font again.",
                MessageBox.TYPE_INFO,
                timeout=7,
            )
        except Exception:
            try:
                from Plugins.Extensions.SubsSupport.plugin import openSubsSupportSettings
                return openSubsSupportSettings(self.session)
            except Exception:
                return self.session.open(
                    MessageBox,
                    "Could not open the SubsSupport font settings on this receiver image.",
                    MessageBox.TYPE_ERROR,
                    timeout=7,
                )

    def openSubDLSettingsMenu(self):
        """Show the agreed Import, Language and Font actions under settings key 5."""
        current = load_subdl_settings()
        language_code = current.get("language", "ar")
        language_name = dict((code, name) for name, code in SUBDL_LANGUAGE_CHOICES).get(language_code, language_code)
        choices = [
            ("Import SubDL API Key  •  /tmp/key.txt", "import"),
            ("SubDL Subtitle Language  •  %s" % language_name, "language"),
            ("SubDL Subtitle Font  •  SubsSupport", "font"),
        ]
        self.session.openWithCallback(
            self._subdlSettingsSelected,
            ChoiceBox,
            title="SUBDL SETTINGS  •  IMPORT / LANGUAGE / FONT",
            list=choices,
        )

    def _subdlSettingsSelected(self, choice=None):
        if not choice:
            return
        action = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
        if action == "import":
            return self.importSubDLKey()
        if action == "language":
            return self.openSubDLSubtitleLanguage()
        if action == "font":
            return self.openSubDLSubtitleFont()

    def importSubDLKey(self):
        """Import the local SubDL key while preserving the chosen language and type."""
        try:
            value = _read_subdl_import_key()
            current = load_subdl_settings()
            save_subdl_settings(
                value,
                current.get("language", "ar"),
                current.get("kind", "standard"),
            )
            removed = False
            try:
                os.remove(SUBDL_IMPORT_FILE)
                removed = True
            except Exception:
                pass
            message = (
                "SubDL key imported and saved locally. Press 5 and choose SubDL Subtitle Language. The temporary file was removed."
                if removed else
                "SubDL key imported and saved locally. Press 5 and choose SubDL Subtitle Language. Remove /tmp/key.txt manually to protect your key."
            )
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=6)
        except IOError:
            self.session.open(
                MessageBox,
                "Create /tmp/key.txt with one SubDL API key, then press 5 and choose Import SubDL API Key.",
                MessageBox.TYPE_INFO,
                timeout=7,
            )
        except ValueError:
            self.session.open(
                MessageBox,
                "Invalid /tmp/key.txt. It must contain exactly one SubDL API key.",
                MessageBox.TYPE_ERROR,
                timeout=7,
            )
        except Exception:
            self.session.open(
                MessageBox,
                "Could not import the SubDL key from /tmp/key.txt.",
                MessageBox.TYPE_ERROR,
                timeout=7,
            )

    def openFilter(self):
        source = self.current()
        if not source:
            return
        if source.get("type") not in ("xtream", "stalker"):
            return self.session.open(MessageBox, "Filtering is available for Xtream Codes and Stalker Portal sources.", MessageBox.TYPE_INFO)
        self.session.open(ServerCategoryFilter, source)

    def _sourceKey(self, source):
        return ServerStatusList._key(source)

    def _displaySources(self):
        """Show only real user servers; SubDL actions live under settings key 5."""
        return list(self.sources)

    def _refreshSourceRows(self):
        """Redraw server status while preserving the selected real server."""
        selected_key = None
        try:
            current = self.current()
            selected_key = self._sourceKey(current) if current else None
        except Exception:
            pass
        display_sources = self._displaySources()
        self["config"].setSources(display_sources, self._serverStates)
        if selected_key:
            for index, source in enumerate(display_sources):
                if self._sourceKey(source) == selected_key:
                    try:
                        self["config"].moveToIndex(index)
                    except Exception:
                        pass
                    break

    def _updateStatusCard(self):
        total = len(self.sources)
        if not total:
            text = "Add a playlist to see connection and active-use status."
        else:
            checking = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source), "checking") == "checking"])
            online = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) == "online"])
            busy = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) == "busy"])
            offline = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) == "offline"])
            if checking:
                text = "Checking %d server%s in the background…" % (checking, "" if checking == 1 else "s")
            else:
                text = "%d ready  •  %d in use  •  %d offline  •  Blue: test selected server" % (online, busy, offline)
        try:
            self["serverStatusText"].setText(text)
        except Exception:
            pass

    def _connectionTest(self, source):
        """Return privacy-safe server state without persisting any provider data."""
        try:
            source_type = source.get("type")
            if source_type == "xtream":
                reply = XtreamClient(source).test()
            elif source_type == "m3u":
                reply = M3UClient(source).test()
            else:
                reply = StalkerClient(source).test()
            return evaluate_reply(source_type, reply), ""
        except Exception as exc:
            return {"state": "offline", "active_connections": None, "max_connections": None, "usage_reported": False}, str(exc)

    def _startStatusRefresh(self):
        if self._statusClosed or self._statusResult is not None:
            return
        self._statusToken += 1
        token = self._statusToken
        sources = [dict(source) for source in self.sources]
        self._serverStates = {self._sourceKey(source): "checking" for source in sources}
        self._refreshSourceRows()
        self._updateStatusCard()
        if not sources:
            return

        def worker():
            states = {}
            for source in sources:
                report, _error = self._connectionTest(source)
                states[self._sourceKey(source)] = report.get("state", "offline")
            self._statusResult = (token, states)

        thread = threading.Thread(target=worker, name="TiviMateServerStatus")
        thread.daemon = True
        thread.start()
        try:
            self._statusTimer.start(120, False)
        except Exception:
            pass

    def _finishStatusRefresh(self):
        result = self._statusResult
        if not result:
            try:
                self._statusTimer.start(120, False)
            except Exception:
                pass
            return
        self._statusResult = None
        token, states = result
        if self._statusClosed or token != self._statusToken:
            return
        self._serverStates.update(states)
        self._refreshSourceRows()
        self._updateStatusCard()

    def _stopStatusRefresh(self):
        self._statusClosed = True
        self._statusToken += 1
        try:
            self._statusTimer.stop()
        except Exception:
            pass

    def reload(self):
        self.sources = get_sources()
        keys = set([self._sourceKey(source) for source in self.sources])
        self._serverStates = {key: state for key, state in self._serverStates.items() if key in keys}
        for source in self.sources:
            self._serverStates.setdefault(self._sourceKey(source), "checking")
        self._refreshSourceRows()
        self._updateStatusCard()
        if getattr(self, "_statusReady", False):
            self._startStatusRefresh()

    def current(self):
        row = self["config"].getCurrent()
        return row[0] if row else None

    def select(self):
        source = self.current()
        if not source:
            return
        if self.selectCallback:
            self.selectCallback(source)
            self.close()
        else:
            self.session.open(SourceMenu, source)

    def addSource(self):
        self.session.openWithCallback(self._chooseSourceType, SourceTypePicker)

    def _chooseSourceType(self, source_type=None):
        if source_type == "xtream":
            self.session.openWithCallback(self._afterEditor, PlaylistEditor, None, self._saveNew)
        elif source_type == "stalker":
            self.session.openWithCallback(self._afterEditor, StalkerPortalEditor, None, self._saveNew)

    def _saveNew(self, source):
        srcs = get_sources(); srcs.append(source); set_sources(srcs); write_playlists(srcs)

    def _afterEditor(self, *args):
        self.reload()

    def editSource(self):
        source = self.current()
        if not source:
            return
        if source.get("type") == "xtream":
            return self.session.openWithCallback(self._afterEditor, PlaylistEditor, source, lambda edited: self._replace(source, edited))
        if source.get("type") == "stalker":
            return self.session.openWithCallback(self._afterEditor, StalkerPortalEditor, source, lambda edited: self._replace(source, edited))
        return self.session.open(MessageBox, "Only Xtream Codes and Stalker Portal sources can be edited here.", MessageBox.TYPE_INFO)

    def _replace(self, old, new):
        srcs = get_sources()
        for i, item in enumerate(srcs):
            if item == old:
                srcs[i] = new; break
        set_sources(srcs); write_playlists(srcs)

    def delSource(self):
        source = self.current()
        if not source:
            return
        srcs = [x for x in get_sources() if x != source]
        set_sources(srcs); write_playlists(srcs)
        self.reload()

    def testSource(self):
        source = self.current()
        if not source:
            return
        key = self._sourceKey(source)
        self._serverStates[key] = "checking"
        self._refreshSourceRows()
        self._updateStatusCard()
        report, error = self._connectionTest(source)
        state = report.get("state", "offline")
        self._serverStates[key] = state
        self._refreshSourceRows()
        self._updateStatusCard()
        if state == "online":
            self.session.open(MessageBox, "Connection successful. No active use was reported by the server.", MessageBox.TYPE_INFO)
        elif state == "busy":
            self.session.open(MessageBox, "Connection successful. The server reports active use for this subscription.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Connection failed.\n%s" % (error or "Please verify the server details."), MessageBox.TYPE_ERROR)


class TiviMateE2Search(Screen):
    skin = SEARCH_SCREEN
    MOVIE_X = [85, 325, 565, 805, 1045, 1285]
    SHOW_X = [85, 325, 565, 805, 1045, 1285]

    def __init__(self, session, source):
        Screen.__init__(self, session)
        self.source = source
        self.query = ""
        self.movies = []
        self.shows = []
        self.row = 0
        self.index = 0
        self.loaders = []
        self.downloaders = []
        self["back"] = Label("‹")
        self["searchText"] = Label("Search for a channel, movie or series...")
        self["mic"] = Label("◉")
        self["closeIcon"] = Label("×")
        self["moviesTitle"] = Label("Movies  0")
        self["showsTitle"] = Label("Shows  0")
        for i in range(12):
            self["poster%d" % i] = Pixmap()
            self["posterLabel%d" % i] = Label("")
            self["posterRate%d" % i] = Label("")
        self["movieSelector"] = Pixmap()
        self["showSelector"] = Pixmap()
        self["selectedTitle"] = Label("")
        self["play"] = Label("▷  Play")
        self["favorite"] = Label("☆  Add to My List")
        self["status"] = Label("Press OK to start searching")
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "yellowlong": self.addCurrentFavourite, "green": self.openKeyboard, "blue": self.openKeyboard
        }, -1)
        self.onLayoutFinish.append(self.layoutReady)

    def layoutReady(self):
        self["status"].setText("Press OK or GREEN to start searching")

    def openKeyboard(self):
        try:
            self.session.openWithCallback(self.searchReady, VirtualKeyBoard, title="Search", text=self.query)
        except RuntimeError as exc:
            self["status"].setText("Press OK again to open the search keyboard")


    def searchReady(self, value=None):
        if value is None:
            if not self.query: self.close()
            return
        self.query = (value or "").strip()
        self["searchText"].setText(self.query or "Search for a channel, movie or series...")
        if not self.query: return
        self["status"].setText("Searching...")
        t = threading.Thread(target=self._worker, name="TiviMateSearch")
        t.daemon = True; t.start()

    def _worker(self):
        try:
            q = self.query.lower()
            source_type = self.source.get("type")
            if source_type == "xtream":
                client = XtreamClient(self.source)
                movies_all = get_filtered_streams(self.source, "vod", client)
                shows_all = get_filtered_streams(self.source, "series", client)
                movies = [x for x in movies_all if q in (x.get("name") or x.get("title") or "").lower()][:6]
                shows = [x for x in shows_all if q in (x.get("name") or x.get("title") or "").lower()][:6]
                mode = "library"
            elif source_type == "stalker":
                client = StalkerClient(self.source)
                movies_all = get_filtered_streams(self.source, "vod", client)
                shows_all = get_filtered_streams(self.source, "series", client)
                movies = [x for x in movies_all if q in (x.get("name") or x.get("title") or "").lower()][:6]
                shows = [x for x in shows_all if q in (x.get("name") or x.get("title") or "").lower()][:6]
                mode = "library"
            else:
                rows, _origin = get_cached_catalog(self.source, "live", lambda: M3UClient(self.source).entries(), wait_for_server=True)
                movies = [x for x in rows if q in (x.get("name") or x.get("title") or "").lower()][:6]
                shows, mode = [], "channels"
            if reactor: reactor.callFromThread(self._ready, movies, shows, mode)
            else: self._ready(movies, shows, mode)
        except Exception as exc:
            if reactor: reactor.callFromThread(self._failed, str(exc))
            else: self._failed(str(exc))

    def _failed(self, err): self["status"].setText("Search failed: %s" % err)

    def short_title(self, item):
        title = str((item or {}).get("name") or (item or {}).get("title") or "").strip()
        return title[:22] + ("…" if len(title) > 22 else "")

    def _ready(self, movies, shows, mode="library"):
        self.searchMode = mode
        self.movies, self.shows = movies, shows
        self.row, self.index = 0, 0
        if self.searchMode == "channels":
            self["moviesTitle"].setText("Channels  %d" % len(movies))
            self["showsTitle"].setText("")
        elif self.searchMode == "movies":
            self["moviesTitle"].setText("Movies  %d" % len(movies))
            self["showsTitle"].setText("")
        else:
            self["moviesTitle"].setText("Movies  %d" % len(movies))
            self["showsTitle"].setText("Shows  %d" % len(shows))
        # Hide all unused slots first. Only real search results are shown.
        for i in range(12):
            try:
                self["poster%d" % i].hide()
                self["posterLabel%d" % i].hide()
                self["posterRate%d" % i].hide()
            except Exception: pass
        placeholder = os.path.join(PLUGIN_PATH, "skins", "poster_placeholder.png")
        for i, item in enumerate(movies):
            try:
                self["poster%d" % i].instance.setPixmapFromFile(placeholder)
                self["poster%d" % i].show()
                self["posterLabel%d" % i].setText(self.short_title(item))
                self["posterRate%d" % i].setText(str(item.get("rating") or item.get("rating_5based") or "")[:4])
                self["posterLabel%d" % i].show()
                self["posterRate%d" % i].show()
            except Exception:
                pass
            self.loadImage(i, item.get("stream_icon") or item.get("cover") or "")
        for j, item in enumerate(shows):
            slot = 6 + j
            try:
                self["poster%d" % slot].instance.setPixmapFromFile(placeholder)
                self["poster%d" % slot].show()
                self["posterLabel%d" % slot].setText(self.short_title(item))
                self["posterRate%d" % slot].setText(str(item.get("rating") or item.get("rating_5based") or "")[:4])
                self["posterLabel%d" % slot].show()
                self["posterRate%d" % slot].show()
            except Exception:
                pass
            self.loadImage(slot, item.get("cover") or item.get("stream_icon") or "")
        if self.searchMode == "channels":
            self["status"].setText("%d channels" % len(movies))
        elif self.searchMode == "movies":
            self["status"].setText("%d movies" % len(movies))
        else:
            self["status"].setText("%d movies • %d shows" % (len(movies), len(shows)))
        self.updateSelection()

    def current(self):
        arr = self.movies if self.row == 0 else self.shows
        return arr[self.index] if arr and self.index < len(arr) else None

    def updateSelection(self):
        arr = self.movies if self.row == 0 else self.shows
        if not arr:
            if self.row == 0 and self.shows: self.row, self.index = 1, 0; arr = self.shows
            elif self.row == 1 and self.movies: self.row, self.index = 0, 0; arr = self.movies
            else:
                try:
                    self["movieSelector"].hide(); self["showSelector"].hide()
                except Exception:
                    pass
                self["selectedTitle"].setText(""); return
        self.index = min(self.index, len(arr)-1)
        x = (self.MOVIE_X if self.row == 0 else self.SHOW_X)[self.index]
        try:
            if self.row == 0:
                self["showSelector"].hide()
                self["movieSelector"].instance.move(ePoint(sx(x), sy(235)))
                self["movieSelector"].show()
            else:
                self["movieSelector"].hide()
                self["showSelector"].instance.move(ePoint(sx(x), sy(750)))
                self["showSelector"].show()
        except Exception:
            pass
        item = self.current() or {}
        title = item.get("name") or item.get("title") or ""
        year = item.get("year") or item.get("releaseDate") or ""
        self["selectedTitle"].setText("%s\n%s" % (title, year))
        kind = "live" if getattr(self, "searchMode", "library") == "channels" else ("series" if self.row == 1 else "vod")
        self["favorite"].setText("★  Remove from My List" if is_favourite(self.source, kind, item) else "☆  Add to My List")

    def left(self): self.index=max(0,self.index-1); self.updateSelection()
    def right(self):
        arr=self.movies if self.row==0 else self.shows
        self.index=min(max(0,len(arr)-1),self.index+1); self.updateSelection()
    def up(self):
        if self.row==1 and self.movies: self.row,self.index=0,min(self.index,len(self.movies)-1)
        else: return self.openKeyboard()
        self.updateSelection()
    def down(self):
        if self.row==0 and self.shows: self.row,self.index=1,min(self.index,len(self.shows)-1); self.updateSelection()

    def toggleFavourite(self):
        item = self.current()
        if not item:
            return
        kind = "live" if getattr(self, "searchMode", "library") == "channels" else ("series" if self.row == 1 else "vod")
        added, saved = toggle_favourite(self.source, kind, item)
        if not saved:
            self["status"].setText("تعذر حفظ المفضلة")
        elif added:
            self["status"].setText("تمت الإضافة إلى المفضلات")
        else:
            self["status"].setText("تمت الإزالة من المفضلات")
        self.updateSelection()

    def addCurrentFavourite(self):
        item = self.current()
        if not item:
            return
        kind = "live" if getattr(self, "searchMode", "library") == "channels" else ("series" if self.row == 1 else "vod")
        if kind not in ("vod", "series"):
            return
        if is_favourite(self.source, kind, item):
            self["status"].setText("العنصر موجود بالفعل في المفضلات")
        elif add_favourite(self.source, kind, item):
            self["status"].setText("تمت الإضافة إلى المفضلات")
        else:
            self["status"].setText("تعذر حفظ المفضلة")
        self.updateSelection()

    def ok(self):
        item = self.current()
        if not item:
            return self.openKeyboard()
        if getattr(self, "searchMode", "library") == "channels":
            rows = list(self.movies or [])
            return self.session.open(TiviMateLivePlayer, self.source, rows, self.index)
        if self.row == 1:
            return self.session.open(SeriesDetailsScreen, self.source, item)
        if self.source.get("type") == "stalker":
            url = StalkerClient(self.source).stream_url(item, "vod")
        else:
            ext = item.get("container_extension") or self.source.get("output", "ts")
            url = "%s/movie/%s/%s/%s.%s" % (self.source.get("url", "").rstrip("/"), self.source.get("username", ""), self.source.get("password", ""), item.get("stream_id", ""), ext)
        if not url:
            return self.session.open(MessageBox, "Unable to resolve a playable movie URL.", MessageBox.TYPE_ERROR)
        self.session.open(TiviMatePlayer, eServiceReference(4097, 0, url), item)

    def loadImage(self, slot, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_artwork_requests", None)
        if requests is None:
            requests = {}
            self._artwork_requests = requests
        requests[slot] = url

        def done(path, s=slot, expected=url):
            if getattr(self, "_artwork_requests", {}).get(s) != expected:
                return
            self.decode(s, path)

        request_artwork(url, "search", done, priority=55)

    def decode(self, slot, path):
        loader = ePicLoad()
        self.loaders.append(loader)
        def ready(_=None, s=slot, ll=loader):
            try:
                ptr = ll.getData()
                widget = self["poster%d" % s]
                if ptr and widget.instance:
                    widget.instance.setPixmap(ptr)
                    widget.show()
            except Exception:
                pass
            try:
                if ll in self.loaders:
                    self.loaders.remove(ll)
            except Exception:
                pass
        loader.PictureData.get().append(ready)
        size = (215, 360) if slot < 6 else (215, 265)
        render_width, render_height = scale_size(size[0], size[1])
        loader.setPara((render_width, render_height, 1, 1, False, 1, "#00000000"))
        loader.startDecode(path)


class TiviMateE2Home(Screen):
    skin = HOME_SKIN1
    NAV = ["Search", "Home", "Live", "Movies", "TV Shows", "Favorite", "Settings"]
    NAV_X = [370, 520, 670, 820, 970, 1120, 1390]
    NAV_Y = [210] * 7
    POSTER_X = [216, 461, 706, 951, 1196, 1441]
    POSTER_Y = 701
    ACTIVE_FILE = "/etc/enigma2/tivimatee2/active_source.json"

    def __init__(self, session):
        self.homeAppearance = _load_home_appearance()
        self.homeSkinName = self.homeAppearance.get("skin", "reference_home")
        self.isReferenceHome = self.homeSkinName == "reference_home"
        self.posterSize = (248, 338)
        self.bannerSize = (1704, 454)
        if self.homeSkinName == "skin2_dark":
            self.skin = HOME_SKIN2
            self.NAV = ["Home", "Live TV", "Movies", "Series", "Search", "Favorite", "Settings"]
            self.NAV_X = [345, 500, 670, 835, 1000, 1165, 1335]
            self.NAV_Y = [93] * 7
            self.POSTER_X = [105, 367, 629, 891, 1153, 1415]
            self.POSTER_Y = 570
            self.posterSize = (230, 300)
            self.bannerSize = (1920, 444)
        else:
            self.homeSkinName = "reference_home"
            self.isReferenceHome = True
            self.skin = HOME_SKIN1
            self.NAV_X = [380, 550, 710, 870, 1030, 1210, 1390]
            self.NAV_Y = [27] * 7
            self.POSTER_X = [106, 398, 690, 982, 1274, 1566]
            self.POSTER_Y = 676
        Screen.__init__(self, session)
        self.source = self._loadActiveSource()
        self.focus = "nav"
        self.navIndex = 0 if self.homeSkinName == "skin2_dark" else 1
        self.posterIndex = 0
        self.recent = []
        self.imageLoaders = [None] * 7
        self.imageDownloaders = [None] * 7
        self.featureRequestId = 0
        # The dashboard hero is part of the application identity, never of a specific IPTV source.
        self.globalHero = True
        self["headline"] = Label("TiViMate IPTV EXPERIENCE")
        self["subheadline"] = Label("Live TV  •  Movies  •  Series  •  beIN SPORTS")
        self["logo"] = Label("TiviMate E2")
        self["homeBrandLogo"] = Pixmap()
        if self.isReferenceHome:
            self["poweredBy"] = Label("Developed by Opesboy")
        for i in range(8): self["nav%d" % i] = Label(self.NAV[i] if i < len(self.NAV) else "")
        self["navSelector"] = Pixmap()
        self["clock"] = Label("")
        self["date"] = Label("")
        self["banner"] = Pixmap()
        self["quality"] = Label("TIVIMATE  •  PREMIUM IPTV")
        self["featureTitle"] = Label("YOUR ENTERTAINMENT, ONE PLACE")
        self["featureMeta"] = Label("Browse, discover and enjoy your library in one unified experience.")
        self["featureDesc"] = Label("")
        self["playNow"] = Label("WATCH NOW")
        self["recentTitle"] = Label("Recently Added")
        for i in range(6):
            self["poster%d" % i] = Pixmap()
            self["posterMetaTitle%d" % i] = Label("")
            self["posterMetaRate%d" % i] = Label("")
        self["posterSelector"] = Pixmap()
        self["status"] = Label("")
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "ok": self.ok, "cancel": self.close, "menu": self.openFavorites,
            "red": self.close, "green": self.openSettings, "yellow": self.refreshHome,
            "yellowlong": self.addRecentFavourite, "blue": self.openFavorites
        }, -1)
        self.clockTimer = eTimer()
        try: self.clockTimer.callback.append(self.updateClock)
        except Exception: self.clockTimer.timeout.get().append(self.updateClock)
        self.loadTimer = eTimer()
        try: self.loadTimer.callback.append(self.startLoad)
        except Exception: self.loadTimer.timeout.get().append(self.startLoad)
        # Stalker/Ministra portals can complete the network request in a worker
        # while a Twisted reactor is unavailable or not integrated with Enigma2.
        # Deliver their Home result through an eTimer, the same UI-thread pattern
        # used by ContentHome.  This remains completely generic: it carries only
        # a source snapshot, a request token, and normalized items.
        self.stalkerRecentToken = 0
        self.stalkerRecentResult = None
        self.stalkerRecentTimer = eTimer()
        try: self.stalkerRecentTimer.callback.append(self._finishStalkerRecentLoad)
        except Exception: self.stalkerRecentTimer.timeout.get().append(self._finishStalkerRecentLoad)
        # Update work happens only after the Home screen is visible and always
        # in a background thread, so it never delays loading IPTV content.
        self.updateCheckTimer = eTimer()
        self.updateCheckPollTimer = eTimer()
        self.updateDownloadPollTimer = eTimer()
        try: self.updateCheckTimer.callback.append(self._beginUpdateCheck)
        except Exception: self.updateCheckTimer.timeout.get().append(self._beginUpdateCheck)
        try: self.updateCheckPollTimer.callback.append(self._pollUpdateCheck)
        except Exception: self.updateCheckPollTimer.timeout.get().append(self._pollUpdateCheck)
        try: self.updateDownloadPollTimer.callback.append(self._pollUpdateDownload)
        except Exception: self.updateDownloadPollTimer.timeout.get().append(self._pollUpdateDownload)
        self._updateCheckPending = None
        self._updateDownloadPending = None
        self._updateCandidate = None
        self._updateInstallProcess = None
        self._updateCheckStarted = False
        try: self.onClose.append(self._stopUpdateTimers)
        except Exception: pass
        try: self.onClose.append(self._stopStalkerRecentTimer)
        except Exception: pass
        self.onLayoutFinish.append(self.layoutReady)

    def layoutReady(self):
        # Both Home skins scale their decoded hero at the Pixmap level.
        # This keeps Skin 1's backdrop stretched across its full panoramic frame.
        try:
            self["banner"].instance.setScale(1)
        except Exception:
            pass
        self.applyGlobalHero()
        self.updateFocus(); self.updateClock()
        try: self.clockTimer.start(30000, False)
        except Exception: pass
        try: self.loadTimer.start(250, True)
        except Exception: self.startLoad()
        # Delay the request slightly so a slow or unavailable update endpoint
        # never affects the first paint of the home interface.
        if _load_update_settings().get("auto_check", True):
            try: self.updateCheckTimer.start(1500, True)
            except Exception: self._beginUpdateCheck()

    def _stopUpdateTimers(self):
        for timer in (getattr(self, "updateCheckTimer", None),
                      getattr(self, "updateCheckPollTimer", None),
                      getattr(self, "updateDownloadPollTimer", None)):
            try:
                if timer:
                    timer.stop()
            except Exception:
                pass

    def _stopStalkerRecentTimer(self):
        # Invalidate a finishing worker before the screen is destroyed.
        self.stalkerRecentToken = getattr(self, "stalkerRecentToken", 0) + 1
        self.stalkerRecentResult = None
        try:
            self.stalkerRecentTimer.stop()
        except Exception:
            pass

    def _beginUpdateCheck(self):
        if not _load_update_settings().get("auto_check", True):
            return
        if self._updateCheckStarted:
            return
        self._updateCheckStarted = True
        self._updateCheckPending = None

        def worker():
            try:
                self._updateCheckPending = check_for_update()
            except Exception:
                self._updateCheckPending = {}

        try:
            thread = threading.Thread(target=worker)
            thread.daemon = True
            thread.start()
            self.updateCheckPollTimer.start(200, True)
        except Exception:
            self._updateCheckPending = {}

    def _pollUpdateCheck(self):
        if self._updateCheckPending is None:
            try: self.updateCheckPollTimer.start(200, True)
            except Exception: pass
            return
        result = self._updateCheckPending or {}
        self._updateCheckPending = None
        if not result.get("available"):
            return
        self._updateCandidate = result
        version = result.get("version") or "1.0.02"
        revision = result.get("revision") or "?"
        notes = result.get("notes") or ""
        text = "A new TiviMate E2 update is available.\n\nVersion: %s (revision %s)" % (version, revision)
        if notes:
            text += "\n\n" + notes
        text += "\n\nDownload and install it now?"
        try:
            self.session.openWithCallback(self._onUpdatePrompt, MessageBox, text,
                type=MessageBox.TYPE_YESNO, timeout=20, default=False)
        except Exception:
            pass

    def _onUpdatePrompt(self, answer):
        if not answer or not self._updateCandidate:
            return
        package = self._updateCandidate.get("package")
        if not package:
            return
        self._updateDownloadPending = None
        try: self["status"].setText("Downloading TiviMate E2 update...")
        except Exception: pass

        def worker():
            self._updateDownloadPending = download_package(package)

        try:
            thread = threading.Thread(target=worker)
            thread.daemon = True
            thread.start()
            self.updateDownloadPollTimer.start(200, True)
        except Exception:
            self._updateDownloadPending = {"ok": False, "message": "Unable to start download"}

    def _pollUpdateDownload(self):
        if self._updateDownloadPending is None:
            try: self.updateDownloadPollTimer.start(200, True)
            except Exception: pass
            return
        result = self._updateDownloadPending or {}
        self._updateDownloadPending = None
        if not result.get("ok"):
            try: self["status"].setText("")
            except Exception: pass
            self._showUpdateMessage("Update download failed.\n\n%s" % (result.get("message") or "Please try again later."))
            return
        command = install_command(result)
        if not command:
            try: self["status"].setText("")
            except Exception: pass
            self._showUpdateMessage("The verified update package could not be installed.")
            return
        try: self["status"].setText("Installing TiviMate E2 update...")
        except Exception: pass
        try:
            process = eConsoleAppContainer()
            self._updateInstallProcess = process
            try: process.appClosed.append(self._onUpdateInstallFinished)
            except Exception: process.appClosed.get().append(self._onUpdateInstallFinished)
            process.execute("/bin/sh", "sh", "-c", command)
        except Exception:
            try: self["status"].setText("")
            except Exception: pass
            self._showUpdateMessage("Unable to start the update installer.")

    def _onUpdateInstallFinished(self, status):
        self._updateInstallProcess = None
        try: self["status"].setText("")
        except Exception: pass
        if status == 0:
            self._showUpdateMessage("TiviMate E2 was updated successfully.\n\nPlease restart the Enigma2 GUI to use the new version.")
        else:
            self._showUpdateMessage("The update installer returned an error.\n\nYour current TiviMate E2 installation has not been changed.")

    def _showUpdateMessage(self, text):
        try:
            self.session.open(MessageBox, text, type=MessageBox.TYPE_INFO, timeout=12)
        except Exception:
            pass

    def _sourceKey(self, source):
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("url", "").rstrip("/"), source.get("username", ""), source.get("mac", ""))

    def _loadActiveSource(self):
        sources = get_sources()
        if not sources: return None
        try:
            with open_text(self.ACTIVE_FILE, "r") as f: key = json.load(f).get("key", "")
            for source in sources:
                if self._sourceKey(source) == key: return source
        except Exception: pass
        for source in sources:
            if source.get("type") == "xtream": return source
        return sources[0]

    def _saveActiveSource(self):
        try:
            ensure_dir(os.path.dirname(self.ACTIVE_FILE))
            with open_text(self.ACTIVE_FILE, "w") as f: json.dump({"key": self._sourceKey(self.source)}, f)
        except Exception: pass

    def updateClock(self):
        now = time.localtime()
        self["clock"].setText(time.strftime("%H:%M", now))
        self["date"].setText(time.strftime("%d.%m.%Y", now))

    def updateFocus(self):
        if self["navSelector"].instance:
            self["navSelector"].instance.move(ePoint(sx(self.NAV_X[self.navIndex]), sy(self.NAV_Y[self.navIndex])))
            self["navSelector"].show() if self.focus == "nav" else self["navSelector"].hide()
        if self["posterSelector"].instance:
            self["posterSelector"].instance.move(ePoint(sx(self.POSTER_X[self.posterIndex]), sy(self.POSTER_Y)))
            self["posterSelector"].show() if (self.focus == "posters" and bool(self.recent)) else self["posterSelector"].hide()

    def left(self):
        if self.focus == "nav":
            self.navIndex = (self.navIndex - 1) % len(self.NAV)
        else:
            self.posterIndex = max(0, self.posterIndex - 1)
            self.updateFeature()
        self.updateFocus()

    def right(self):
        if self.focus == "nav":
            self.navIndex = (self.navIndex + 1) % len(self.NAV)
        else:
            self.posterIndex = min(max(0, len(self.recent) - 1), self.posterIndex + 1)
            self.updateFeature()
        self.updateFocus()

    def up(self):
        self.focus = "nav"
        self.updateFocus()

    def down(self):
        if self.recent:
            self.focus = "posters"
            self.updateFeature()
        self.updateFocus()

    def ok(self):
        if self.focus == "posters": return self.playRecent()
        index = self.navIndex
        if self.homeSkinName == "skin2_dark":
            if index == 0: return
            if index == 1: return self.openMedia("live")
            if index == 2: return self.openContentHome("vod")
            if index == 3: return self.openContentHome("series")
            if index == 4: return self.session.open(TiviMateE2Search, self.source)
            if index == 5: return self.openFavorites()
            if index == 6: return self.openSettings()
            return
        if index == 0: return self.session.open(TiviMateE2Search, self.source)
        if index == 1: return
        if index == 2: return self.openMedia("live")
        if index == 3: return self.openContentHome("vod")
        if index == 4: return self.openContentHome("series")
        if index == 5: return self.openFavorites()
        if index == 6: return self.openSettings()

    def addRecentFavourite(self):
        if self.focus != "posters" or not self.recent:
            self["status"].setText("حدد بوستر فيلم أولاً")
            return
        item = self.recent[min(self.posterIndex, len(self.recent) - 1)]
        if is_favourite(self.source, "vod", item):
            self["status"].setText("الفيلم موجود بالفعل في المفضلات")
        elif add_favourite(self.source, "vod", item):
            self["status"].setText("تمت إضافة الفيلم إلى المفضلات")
        else:
            self["status"].setText("تعذر حفظ المفضلة")

    def refreshHome(self):
        self.globalHero = True
        self.posterIndex = 0
        self.recent = []
        self.resetPosters()
        self.startLoad()

    def openContentHome(self, kind):
        if not self.source:
            return self.openSettings()
        source_type = self.source.get("type")
        if source_type in ("xtream", "stalker"):
            return self.session.open(ContentHomeScreen, self.source, kind)
        return self.session.open(MessageBox, "This section requires a server with Movies and TV Shows.", MessageBox.TYPE_INFO)

    def openMedia(self, kind):
        if not self.source:
            return self.openSettings()
        if kind in ("vod", "series") and self.source.get("type") not in ("xtream", "stalker"):
            return self.session.open(MessageBox, "This section requires a server with Movies and TV Shows.", MessageBox.TYPE_INFO)
        self.session.open(MediaScreen, self.source, kind)

    def openFavorites(self):
        self.session.open(FavoritesScreen)

    def openSettings(self):
        self.session.open(ServerManager, self.selectServer)

    def selectServer(self, source):
        self.source = source; self._saveActiveSource(); self.recent = []; self.posterIndex = 0
        self.globalHero = True
        self.resetPosters(); self.startLoad()

    def resetPosters(self):
        for i in range(6):
            try: self["poster%d" % i].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "poster_placeholder.png"))
            except Exception: pass
            try:
                self["posterMetaTitle%d" % i].setText("")
                self["posterMetaRate%d" % i].setText("")
            except Exception: pass
        self.applyGlobalHero()

    def applyGlobalHero(self):
        """Render the application hero only until a selected poster supplies its own backdrop."""
        self.featureRequestId += 1
        request_id = self.featureRequestId
        self["quality"].setText("TIVIMATE  •  PREMIUM IPTV")
        self["featureTitle"].setText("YOUR ENTERTAINMENT, ONE PLACE")
        self["featureMeta"].setText("Browse, discover and enjoy your library in one unified experience.")
        self["featureDesc"].setText("")
        self["playNow"].setText("WATCH NOW")
        self["recentTitle"].setText("Recently Added")
        hero = os.path.join(PLUGIN_PATH, "skins", "tivimate_global_hero_r70.png")
        try:
            self.decodeImage(6, hero, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        except Exception:
            try: self["banner"].instance.setPixmapFromFile(hero)
            except Exception: pass

    def startLoad(self):
        if not self.source:
            self["status"].setText("No server selected • Press SETTINGS")
            return
        self["status"].setText("Loading from %s ..." % self.source.get("name", "SERVER"))
        if self.source.get("type") not in ("xtream", "stalker"):
            self["status"].setText("Selected server: %s" % self.source.get("name", "SERVER")); return
        # Warm enabled series categories while the user remains on the dashboard.
        # This is fully asynchronous and stale cache remains immediately usable.
        try: prefetch_allowed_series(dict(self.source))
        except Exception: pass
        # Never depend on Twisted being integrated into Enigma2 for Stalker Home.
        # The worker sets a result and the eTimer below applies it on the UI thread.
        if self.source.get("type") == "stalker":
            return self._startStalkerRecentLoad()
        if reactor is None:
            return self._loadWorkerDirect()
        thread = threading.Thread(target=self._loadWorker, name="TiviMateDashboard")
        thread.daemon = True; thread.start()

    def _startStalkerRecentLoad(self):
        self.stalkerRecentToken += 1
        token = self.stalkerRecentToken
        source = dict(self.source or {})
        self.stalkerRecentResult = None

        def worker():
            try:
                result = (token, self._fetchRecentFromSource(source), "")
            except Exception as exc:
                result = (token, [], str(exc))
            self.stalkerRecentResult = result

        thread = threading.Thread(target=worker, name="TiviMateStalkerHome")
        thread.daemon = True
        thread.start()
        try:
            self.stalkerRecentTimer.start(120, True)
        except Exception:
            # Fallback remains safe for images where timers are unavailable.
            pass

    def _finishStalkerRecentLoad(self):
        result = self.stalkerRecentResult
        if result is None:
            try:
                self.stalkerRecentTimer.start(120, True)
            except Exception:
                pass
            return
        # Do not erase a newer worker result that may have arrived while this
        # UI callback was being scheduled for an older request token.
        if self.stalkerRecentResult is result:
            self.stalkerRecentResult = None
        token, items, error = result
        if token != self.stalkerRecentToken:
            return
        if error:
            self._recentFailed(error)
            return
        self._recentReady(items)

    def _loadWorkerDirect(self):
        try: self._recentReady(self._fetchRecent())
        except Exception as exc: self._recentFailed(str(exc))

    def _loadWorker(self):
        try:
            items = self._fetchRecent(); reactor.callFromThread(self._recentReady, items)
        except Exception as exc:
            reactor.callFromThread(self._recentFailed, str(exc))

    def _fetchRecent(self):
        return self._fetchRecentFromSource(self.source)

    def _fetchRecentFromSource(self, source):
        source = dict(source or {})
        client = get_source_client(source)
        if source.get("type") == "stalker":
            # A Stalker Home page is a balanced preview from one usable VOD
            # package and one usable Series package.  The helper has no portal-
            # specific assumptions and falls back to either type when needed.
            return get_stalker_home_items(source, client, limit=6)
        items = list(get_filtered_streams(source, "vod", client) or [])
        items.sort(key=lambda x: int(str(x.get("added") or "0") or "0"), reverse=True)
        return items[:6]

    def _recentFailed(self, error):
        self["status"].setText("Unable to load recently added: %s" % error)

    def _recentReady(self, items):
        self.recent = items or []
        home_kinds = set(str((item or {}).get("_tivimate_home_kind") or "") for item in self.recent)
        if home_kinds == set(("vod", "series")):
            heading = "Latest Movies & TV Shows"
            status_label = "%d Home picks" % len(self.recent)
        elif "series" in home_kinds:
            heading = "Latest TV Shows"
            status_label = "%d recent TV shows" % len(self.recent)
        else:
            heading = "Recently Added"
            status_label = "%d recent movies" % len(self.recent)
        self["recentTitle"].setText(heading)
        self["status"].setText("Server: %s  •  %s" % (self.source.get("name", "SERVER"), status_label))
        for i, item in enumerate(self.recent[:6]):
            pw, ph = self.posterSize
            self.loadImage(i, item.get("stream_icon") or item.get("cover") or "", "poster%d" % i, pw, ph)
            title = str(item.get("name") or item.get("title") or "").strip()
            rating = str(item.get("rating") or item.get("rating_5based") or "").strip()
            self["posterMetaTitle%d" % i].setText(title[:22] + ("…" if len(title) > 22 else ""))
            self["posterMetaRate%d" % i].setText(rating[:4])
        self.posterIndex = 0
        self.globalHero = not bool(self.recent)
        if self.globalHero:
            self.applyGlobalHero()
        else:
            self.updateFeature()
        self.updateFocus()

    def updateFeature(self):
        # The selected poster owns the banner once the library row is ready.
        if not self.recent: return
        item = self.recent[min(self.posterIndex, len(self.recent)-1)]
        self["featureTitle"].setText((item.get("name") or item.get("title") or "MOVIE").upper())
        year = str(item.get("year") or item.get("releaseDate") or "")
        rating = str(item.get("rating") or "")
        genre = str(item.get("genre") or "")
        self["featureMeta"].setText("  •  ".join(x for x in [year, ("★ " + rating) if rating else "", genre] if x))
        self["featureDesc"].setText((item.get("plot") or item.get("description") or "Recently added from the selected server.")[:180])

        # Use a true backdrop in the middle banner. Do not stretch the poster.
        self.featureRequestId += 1
        request_id = self.featureRequestId
        stream_id = item.get("stream_id") or item.get("vod_id")
        direct_backdrop = self._normaliseBackdrop(item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url"))
        if direct_backdrop:
            self.loadImage(6, direct_backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        elif stream_id:
            thread = threading.Thread(target=self._loadFeatureBackdrop, args=(stream_id, request_id), name="TiviMateBackdrop")
            thread.daemon = True
            thread.start()

    def _normaliseBackdrop(self, value):
        if isinstance(value, list):
            value = value[0] if value else ""
        if not isinstance(value, str):
            return ""
        value = value.strip().replace("\\/", "/")
        if value.startswith("["):
            try:
                arr = json.loads(value)
                value = arr[0] if arr else ""
            except Exception:
                pass
        if value.startswith("/") and not value.startswith("//"):
            value = "https://image.tmdb.org/t/p/w1280" + value
        return value if value.startswith(("http://", "https://")) else ""

    def _cleanRecentTitle(self, value):
        import re
        text = str(value or "")
        text = re.sub(r"\b(ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|uhd|fhd|hd|hevc|x265|x264|hdr|web[- ]?dl|bluray|top)\b", " ", text, flags=re.I)
        text = re.sub(r"[\[\]{}()_.|:+-]+", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _recentYear(self, item):
        import re
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        match = re.search(r"\b(?:19|20)\d{2}\b", raw)
        return int(match.group(0)) if match else None

    def _loadFeatureBackdrop(self, stream_id, request_id):
        try:
            data = XtreamClient(self.source).vod_info(stream_id) or {}
            info = {}
            if isinstance(data.get("movie_data"), dict): info.update(data.get("movie_data") or {})
            if isinstance(data.get("info"), dict): info.update(data.get("info") or {})
            backdrop = self._normaliseBackdrop(
                info.get("backdrop_path") or info.get("backdrop") or info.get("backdrop_url") or
                data.get("backdrop_path") or data.get("backdrop")
            )
            # Recent Movies sometimes contains only a poster. Resolve the movie on
            # TMDb and use its true backdrop without changing any other section.
            if not backdrop:
                current = self.recent[min(self.posterIndex, len(self.recent)-1)] if self.recent else {}
                tmdb = TMDbClient()
                tid = info.get("tmdb_id") or info.get("tmdb") or current.get("tmdb_id") or current.get("tmdb")
                if not tid:
                    title = self._cleanRecentTitle(info.get("name") or current.get("name") or current.get("title"))
                    found = tmdb.search_title(title, "vod", self._recentYear(info or current)) if title else None
                    tid = (found or {}).get("id")
                bundle = tmdb.details_bundle(tid, "vod") if tid else {}
                backdrop = self._normaliseBackdrop(bundle.get("backdrop_path"))
            if backdrop and request_id == self.featureRequestId:
                if reactor is not None:
                    reactor.callFromThread(self.loadImage, 6, backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id)
                else:
                    self.loadImage(6, backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        except Exception:
            pass

    def loadImage(self, slot, url, widget, width, height, request_id=None):
        url = (url or "").strip().replace("\\/", "/")
        if not url or (request_id is not None and request_id != self.featureRequestId):
            return
        # One token per visual slot prevents a prior selection from painting over
        # the current poster or backdrop after the user moves the selection.
        requests = getattr(self, "_artwork_requests", None)
        if requests is None:
            requests = {}
            self._artwork_requests = requests
        token = (slot, widget)
        requests[token] = (url, request_id)
        priority = 120 if widget == "banner" else 75

        def done(path, s=slot, w=widget, x=width, y=height, rid=request_id, expected=(url, request_id), key=token):
            if getattr(self, "_artwork_requests", {}).get(key) != expected:
                return
            self.decodeImage(s, path, w, x, y, request_id=rid)

        request_artwork(url, "home", done, priority=priority)

    def decodeImage(self, slot, path, widget, width, height, request_id=None):
        if request_id is not None and request_id != self.featureRequestId:
            return
        loader = ePicLoad(); self.imageLoaders[slot] = loader
        def ready(_info=None, slot=slot, widget=widget, request_id=request_id, l=loader):
            try:
                if request_id is not None and request_id != self.featureRequestId:
                    return
                ptr = l.getData()
                if ptr and self[widget].instance: self[widget].instance.setPixmap(ptr)
            except Exception:
                pass
            finally:
                try:
                    if self.imageLoaders[slot] is l:
                        self.imageLoaders[slot] = None
                except Exception:
                    pass
        loader.PictureData.get().append(ready)
        # A zero aspect ratio makes ePicLoad fill the complete panorama.
        # Both remaining Home skins use this decoding path.
        # so selected movie backdrops cannot be letterboxed with black side areas.
        render_width, render_height = scale_size(width, height)
        if widget == "banner" and self.homeSkinName in ("reference_home", "skin2_dark"):
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        else:
            loader.setPara((render_width, render_height, 1, 1, False, 1, "#00000000"))
        loader.startDecode(path)

    def playRecent(self):
        if not self.recent or not self.source: return
        # Recent Movies must open the full details route first. The details screen
        # resolves server VOD info, TMDb backdrop, cast and recommendations, while
        # the Watch button keeps the original playback behaviour.
        item = dict(self.recent[self.posterIndex] or {})
        item["_recent_home"] = True
        self.session.open(MovieDetailsScreen, self.source, item, self.recent)


class SourceMenu(Screen):
    skin = SOURCE_MENU

    def __init__(self, session, source):
        Screen.__init__(self, session)
        self.source = source
        self["brand"] = Label("tv")
        if source.get("type") == "m3u":
            self["side"] = MenuList([("التلفاز", "live"), ("الإعدادات", "settings")])
            options = [("التلفاز المباشر", "live")]
        else:
            self["side"] = MenuList([("التلفاز", "live"), ("أفلام", "vod"), ("مسلسلات", "series"), ("الإعدادات", "settings")])
            options = [("التلفاز المباشر", "live"), ("الأفلام", "vod"), ("المسلسلات", "series")]
        self["title"] = Label(source.get("name", "TiviMate E2"))
        self["subtitle"] = Label(source.get("type", "").upper())
        self["menu"] = MenuList(options)
        self["info"] = Label("اختَر القسم. تم تعطيل تحميل الصور الثقيلة في هذه النسخة لضمان الاستقرار.")
        self["keys"] = Label("OK فتح    EXIT رجوع")
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.open, "cancel": self.close,
            "up": self.menuUp, "down": self.menuDown,
            "pageUp": self.menuPageUp, "pageDown": self.menuPageDown
        }, -1)

    def menuUp(self):
        self["menu"].up()

    def menuDown(self):
        self["menu"].down()

    def menuPageUp(self):
        try:
            self["menu"].pageUp()
        except Exception:
            self["menu"].up()

    def menuPageDown(self):
        try:
            self["menu"].pageDown()
        except Exception:
            self["menu"].down()

    def open(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        if self.source.get("type") in ("xtream", "stalker") and current[1] in ("vod", "series"):
            return self.session.open(ContentHomeScreen, self.source, current[1])
        self.session.open(MediaScreen, self.source, current[1])


from .tivimate_player import TiviMatePlayer
from .live_player import TiviMateLivePlayer


class SeriesDetailsScreen(Screen):
    skin = SERIES_DETAILS
    EPISODE_X = [80, 440, 800, 1160, 1520]

    def __init__(self, session, source, seriesItem):
        Screen.__init__(self, session)
        self.source = source
        self.seriesItem = seriesItem or {}
        self.seriesData = {}
        self.episodesBySeason = {}
        self.seasonItems = []
        self.episodeItems = []
        self.seasonIndex = 0
        self.episodePage = 0
        self.episodeIndex = 0
        self.downloads = []
        self.picloads = []
        self.backdropLoader = None
        self.backdropDownloader = None
        self.seriesFallbackPoster = ""
        self.seriesBackdrop = ""
        self["backdrop"] = Pixmap()
        self["title"] = Label(self.seriesItem.get("name") or self.seriesItem.get("title") or "مسلسل")
        self["rating"] = Label("")
        self["meta"] = Label("")
        self["cast"] = Label("")
        self["desc"] = Label("جاري تحميل معلومات المسلسل...")
        self["seasonInfo"] = Label("")
        self["episodeInfo"] = Label("")
        for i in range(5):
            self["episode%d" % i] = Pixmap()
            self["episodeLabel%d" % i] = Label("")
        self["episodeSelector"] = Pixmap()
        self["keys"] = Label("يمين/يسار: الحلقات    أعلى/أسفل: تغيير الموسم    OK تشغيل    أحمر مفضلة    EXIT رجوع")
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "yellowlong": self.addSeriesFavourite
        }, -1)
        self.onLayoutFinish.append(self.loadSeries)

    def _normImage(self, value):
        if isinstance(value, list):
            value = value[0] if value else ""
        if isinstance(value, str):
            v = value.strip().replace("\\/", "/")
            if v.startswith("["):
                try:
                    arr = json.loads(v)
                    v = arr[0] if arr else ""
                except Exception:
                    pass
            if v.startswith("/") and not v.startswith("//"):
                v = "https://image.tmdb.org/t/p/w1280" + v
            return v
        return ""

    def loadSeries(self):
        # Network work belongs outside Enigma2's GUI thread.  The visual layout,
        # decoded posters, and backdrop handling are unchanged.
        sid = self.seriesItem.get("series_id") or self.seriesItem.get("stream_id")
        self["desc"].setText("جاري تحميل معلومات المسلسل...")

        def worker():
            try:
                data = get_source_client(dict(self.source)).series_info(sid) or {}
                if reactor:
                    reactor.callFromThread(self._seriesReady, data)
                else:
                    self._seriesReady(data)
            except Exception as exc:
                if reactor:
                    reactor.callFromThread(self._seriesFailed, str(exc))
                else:
                    self._seriesFailed(str(exc))

        thread = threading.Thread(target=worker, name="TiviMateSeriesDetails")
        thread.daemon = True
        thread.start()

    def _seriesReady(self, data):
        try:
            self.seriesData = data or {}
            info = self.seriesData.get("info") or {}
            title = info.get("name") or self.seriesItem.get("name") or "مسلسل"
            year = info.get("releaseDate") or info.get("releasedate") or info.get("year") or ""
            rating = info.get("rating") or info.get("rating_5based") or ""
            genre = info.get("genre") or ""
            cast = info.get("cast") or info.get("actors") or ""
            director = info.get("director") or ""
            self["title"].setText(title)
            self["rating"].setText(str(rating)[:4] if rating else "--")
            self["meta"].setText("  •  ".join(x for x in [str(year), str(genre)] if x))
            cast_text = []
            if cast:
                cast_text.append("طاقم الممثلين: %s" % str(cast)[:150])
            if director:
                cast_text.append("المخرج: %s" % str(director)[:90])
            self["cast"].setText("\n".join(cast_text))
            self["desc"].setText((info.get("plot") or info.get("description") or "لا توجد معلومات")[:720])
            self.seriesFallbackPoster = self._normImage(
                info.get("cover_big") or info.get("cover") or self.seriesItem.get("cover") or
                self.seriesItem.get("stream_icon") or ""
            )
            self.seriesBackdrop = self._normImage(
                info.get("backdrop_path") or info.get("backdrop") or info.get("backdrop_url") or
                self.seriesItem.get("backdrop_path") or self.seriesItem.get("backdrop") or ""
            )
            if not self.seriesBackdrop:
                self.seriesBackdrop = self.seriesFallbackPoster
            if self.seriesBackdrop:
                self.loadBackdrop(self.seriesBackdrop)

            raw = self.seriesData.get("episodes") or {}
            self.episodesBySeason = {str(key): (value or []) for key, value in raw.items() if value}
            seasons = self.seriesData.get("seasons") or []
            self.seasonItems = []
            if seasons:
                for season in seasons:
                    number = str(season.get("season_number") if season.get("season_number") is not None else season.get("season") or "")
                    if self.episodesBySeason.get(number):
                        row = dict(season)
                        row["_num"] = number
                        self.seasonItems.append(row)
            if not self.seasonItems:
                for number in sorted(self.episodesBySeason.keys(), key=lambda value: int(value) if str(value).isdigit() else 999):
                    self.seasonItems.append({"_num": number, "name": "الموسم %s" % number})
            self.seasonIndex = 0
            self.selectSeason()
        except Exception as exc:
            self._seriesFailed(str(exc))

    def _seriesFailed(self, error):
        self["desc"].setText("تعذر تحميل المسلسل\n%s" % error)

    def _setVisible(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def selectSeason(self):
        if not self.seasonItems:
            self.episodeItems = []
            self["seasonInfo"].setText("لا توجد مواسم")
            self.renderEpisodes()
            return
        self.seasonIndex = max(0, min(self.seasonIndex, len(self.seasonItems) - 1))
        season = self.seasonItems[self.seasonIndex]
        num = str(season.get("_num", ""))
        self.episodeItems = self.episodesBySeason.get(num, []) or []
        season_name = season.get("name") or "الموسم %s" % num
        self["seasonInfo"].setText("%s  /  %d حلقة" % (season_name, len(self.episodeItems)))
        self.episodePage = 0
        self.episodeIndex = 0
        self.renderEpisodes()

    def renderEpisodes(self):
        self.downloads = []
        self.picloads = []
        for slot in range(5):
            idx = self.episodePage + slot
            item = self.episodeItems[idx] if idx < len(self.episodeItems) else None
            self._setVisible("episode%d" % slot, bool(item))
            self._setVisible("episodeLabel%d" % slot, bool(item))
            if not item:
                self["episodeLabel%d" % slot].setText("")
                continue
            ep = item.get("episode_num") or item.get("episode_number") or (idx + 1)
            title = item.get("title") or item.get("name") or "الحلقة %s" % ep
            self["episodeLabel%d" % slot].setText("E%s. %s" % (ep, title[:27]))
            self._placeholder(slot)
            inf = item.get("info") or {}
            url = self._normImage(
                item.get("movie_image") or item.get("cover") or item.get("stream_icon") or
                inf.get("movie_image") or inf.get("cover_big") or inf.get("cover") or
                self.seriesBackdrop or self.seriesFallbackPoster
            )
            if url:
                self._loadThumb(slot, url, (330, 186))
        self._setVisible("episodeSelector", bool(self.episodeItems))
        self._moveSelector()
        self.previewEpisode()

    def _placeholder(self, slot):
        try:
            self["episode%d" % slot].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "episode_placeholder.png"))
        except Exception:
            pass

    def _loadThumb(self, slot, url, size):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_episode_artwork_requests", None)
        if requests is None:
            requests = {}
            self._episode_artwork_requests = requests
        requests[slot] = url

        def done(path, s=slot, sz=size, expected=url):
            if getattr(self, "_episode_artwork_requests", {}).get(s) != expected:
                return
            self._decodeThumb(s, path, sz)

        request_artwork(url, "episodes", done, priority=45)

    def _decodeThumb(self, slot, path, size):
        loader = ePicLoad()
        self.picloads.append(loader)
        def ready(_info=None, s=slot, l=loader):
            try:
                ptr = l.getData()
                if ptr and self["episode%d" % s].instance:
                    self["episode%d" % s].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        loader.PictureData.get().append(ready)
        render_width, render_height = scale_size(size[0], size[1])
        loader.setPara((render_width, render_height, 1, 1, False, 1, "#00000000"))
        loader.startDecode(path)

    def _moveSelector(self):
        try:
            self["episodeSelector"].instance.move(ePoint(sx(self.EPISODE_X[self.episodeIndex] - 8), sy(632)))
        except Exception:
            pass

    def left(self):
        idx = self.episodePage + self.episodeIndex
        if idx <= 0:
            return
        if self.episodeIndex > 0:
            self.episodeIndex -= 1
        else:
            self.episodePage = max(0, self.episodePage - 5)
            self.episodeIndex = min(4, len(self.episodeItems) - self.episodePage - 1)
            self.renderEpisodes()
        self._moveSelector()
        self.previewEpisode()

    def right(self):
        idx = self.episodePage + self.episodeIndex
        if idx + 1 >= len(self.episodeItems):
            return
        if self.episodeIndex < 4 and self.episodeIndex + 1 < len(self.episodeItems) - self.episodePage:
            self.episodeIndex += 1
        else:
            self.episodePage += 5
            self.episodeIndex = 0
            self.renderEpisodes()
        self._moveSelector()
        self.previewEpisode()

    def up(self):
        if self.seasonIndex > 0:
            self.seasonIndex -= 1
            self.selectSeason()

    def down(self):
        if self.seasonIndex + 1 < len(self.seasonItems):
            self.seasonIndex += 1
            self.selectSeason()

    def previewEpisode(self):
        idx = self.episodePage + self.episodeIndex
        ep = self.episodeItems[idx] if 0 <= idx < len(self.episodeItems) else None
        if not ep:
            self["episodeInfo"].setText("")
            return
        inf = ep.get("info") or {}
        num = ep.get("episode_num") or ep.get("episode_number") or (idx + 1)
        title = ep.get("title") or ep.get("name") or "الحلقة %s" % num
        duration = inf.get("duration") or ep.get("duration") or ""
        plot = inf.get("plot") or inf.get("description") or ep.get("plot") or ""
        info = "الحلقة %s  •  %s" % (num, title)
        if duration:
            info += "  •  %s" % duration
        if plot:
            info += "    %s" % str(plot)[:180]
        self["episodeInfo"].setText(info)

    def toggleFavourite(self):
        added, saved = toggle_favourite(self.source, "series", self.seriesItem)
        title = self.seriesItem.get("name") or self.seriesItem.get("title") or "المسلسل"
        if not saved:
            self["keys"].setText("تعذر حفظ المفضلة")
        elif added:
            self["keys"].setText("★ تمت إضافة %s إلى المفضلات" % title)
        else:
            self["keys"].setText("☆ تمت إزالة %s من المفضلات" % title)

    def addSeriesFavourite(self):
        if is_favourite(self.source, "series", self.seriesItem):
            self["keys"].setText("المسلسل موجود بالفعل في المفضلات")
        elif add_favourite(self.source, "series", self.seriesItem):
            self["keys"].setText("تمت إضافة المسلسل إلى المفضلات")
        else:
            self["keys"].setText("تعذر حفظ المفضلة")

    def ok(self):
        idx = self.episodePage + self.episodeIndex
        if not (0 <= idx < len(self.episodeItems)):
            return
        ep = dict(self.episodeItems[idx] or {})
        series_title = self.seriesItem.get("name") or self.seriesItem.get("title") or ""
        episode_info = ep.get("info") or {}
        if not isinstance(episode_info, dict):
            episode_info = {}
        episode_cover = self._normImage(
            ep.get("movie_image") or ep.get("cover") or ep.get("stream_icon") or ep.get("poster_path") or
            episode_info.get("movie_image") or episode_info.get("cover_big") or episode_info.get("cover") or
            episode_info.get("poster_path") or self.seriesFallbackPoster
        )
        if episode_cover:
            # The player consumes this normalised value before generic artwork fields.
            ep["_player_cover"] = episode_cover
        ep["_subdl_type"] = "tv"
        ep["_subdl_title"] = series_title
        ep["_subdl_season"] = self.seasonItems[self.seasonIndex].get("_num", "") if self.seasonItems else ""
        ep["_subdl_episode"] = ep.get("episode_num") or ep.get("episode_number") or (idx + 1)
        try:
            if self.source.get("type") == "stalker":
                url = StalkerClient(self.source).stream_url(ep, "series")
            else:
                url = XtreamClient(self.source).episode_url(ep)
            service = eServiceReference(4097, 0, url)
            service.setName(ep.get("title") or ep.get("name") or "حلقة")
            self.session.open(TiviMatePlayer, service, ep)
        except Exception as exc:
            self.session.open(MessageBox, "تعذر تشغيل الحلقة\n%s" % exc, MessageBox.TYPE_ERROR)

    def loadBackdrop(self, url):
        url = self._normImage(url)
        if not url:
            return
        self._series_backdrop_request = url

        def done(path, expected=url):
            if getattr(self, "_series_backdrop_request", "") != expected:
                return
            self.decodeBackdrop(path)

        request_artwork(url, "backdrops", done, priority=115)

    def decodeBackdrop(self, path):
        loader = ePicLoad()
        self.backdropLoader = loader
        def ready(_info=None, l=loader):
            try:
                ptr = l.getData()
                if ptr and self["backdrop"].instance:
                    self["backdrop"].instance.setPixmap(ptr)
            except Exception:
                pass
            finally:
                try:
                    if self.backdropLoader is l:
                        self.backdropLoader = None
                except Exception:
                    pass
        loader.PictureData.get().append(ready)
        render_width, render_height = scale_size(1920, 1080)
        loader.setPara((render_width, render_height, 1, 1, False, 1, "#00000000"))
        loader.startDecode(path)


class MediaScreen(Screen):
    POSTER_X = [70, 450, 830, 1210, 1590]

    def __init__(self, session, source, kind, initialCategoryId=None, initialCategoryName=None):
        if kind == "live":
            # Home skins do not change Live: keep the stable, Picon-enabled list.
            # This layout intentionally has no visible EPG grid.
            self.skin = LIVE_CLASSIC
        else:
            self.skin = VOD
        Screen.__init__(self, session)
        self.source = source
        self.kind = kind
        self.initialCategoryId = str(initialCategoryId or "")
        self.initialCategoryName = initialCategoryName or ""
        self.mediaItems = []
        self.mediaItemsCurrent = []
        self.categories = []
        self.focus = "items"
        self.posterIndex = 0
        self.searchQuery = ""
        self.sortMode = "default"
        self.lastCategoryItems = []
        self.pageStart = 0
        self.downloads = []
        self.picloads = []
        self["brand"] = Label("tv")
        self["rail"] = MenuList([("▣  تلفاز", "live"), ("▤  أفلام", "vod"), ("▥  مسلسلات", "series")])
        self["title"] = Label("%s  •  %s" % (source.get("name", "IPTV"), {"live":"LIVE TV", "vod":"الأفلام", "series":"المسلسلات"}.get(kind, kind)))
        self["category"] = MenuList([])
        if kind != "live":
            self.topNames = ["Search", "Home", "Live", "Movies", "TV Shows"]
            self.topIndex = 3 if kind == "vod" else 4
            self.topX = [90, 285, 480, 675, 870]
            for _i, _name in enumerate(self.topNames):
                self["top%d" % _i] = Label(_name)
            self["topSelector"] = Pixmap()
            self["sectionTitle"] = Label("أقسام الأفلام" if kind == "vod" else "أقسام المسلسلات")
            self["searchIcon"] = Label("⌕")
            self["filterIcon"] = Label("☰")
            self["currentCategory"] = Label("")
        self["channelTitle"] = Label("Select a package" if kind == "live" else "اختر تصنيفاً")
        self["nowLabel"] = Label("CONTENT")
        self["meta"] = Label("")
        self["desc"] = Label("Loading packages..." if kind == "live" else "جاري تحميل التصنيفات...")
        if kind == "live":
            self["list"] = MenuList([])
            self["channelPicon"] = Pixmap()
            self["pageInfo"] = Label("")
            
            self.rowPiconLoaders = []
            self.rowPiconPaths = {}
            self.rowPiconPending = False
            self.rowPiconToken = 0
            for _rp in range(10):
                self["rowPicon%d" % _rp] = Pixmap()
                _loader = ePicLoad()
                try:
                    _loader.PictureData.get().append(lambda info=None, idx=_rp: self._rowPiconDecoded(idx))
                except Exception:
                    pass
                self.rowPiconLoaders.append(_loader)
            self.rowPiconTimer = eTimer()
            try: self.rowPiconTimer.callback.append(self._finishRowPicons)
            except Exception: self.rowPiconTimer.timeout.get().append(self._finishRowPicons)
            self["clockTitle"] = Label("")
            self["categoryTitle"] = Label("PACKAGES")
            # Live browsing stays focused on channel lists, logos, and playback.
            self.channelSettings = _load_channel_settings()
            self.zapTimer = eTimer()
            try: self.zapTimer.callback.append(self._autoZapCurrent)
            except Exception: self.zapTimer.timeout.get().append(self._autoZapCurrent)
            self.livePiconLoader = ePicLoad()
            try: self.livePiconLoader.PictureData.get().append(self._livePiconDecoded)
            except Exception: pass
            self.livePiconDownload = None
            self.livePiconToken = 0
            self.livePiconTimer = eTimer()
            try: self.livePiconTimer.callback.append(self._finishLivePicon)
            except Exception: self.livePiconTimer.timeout.get().append(self._finishLivePicon)
            try: self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
            except Exception: self.oldService = None
            self.lastZappedLiveId = None
            self.keepCurrentLiveService = False
        else:
            self["backdrop"] = Pixmap()
            for i in range(5):
                self["poster%d" % i] = Pixmap()
                self["posterLabel%d" % i] = Label("")
                self["posterRate%d" % i] = Label("")
            self["selector"] = Pixmap()
            self.backdropLoader = None
            self.backdropDownloader = None
            self.infoTimer = eTimer()
            try: self.infoTimer.callback.append(self.loadSelectedInfo)
            except Exception: self.infoTimer.timeout.get().append(self.loadSelectedInfo)
            self.fullInfoCache = {}
            self.infoProcesses = {}
            self.pendingInfoId = ""
        self.categoryLoadToken = 0
        self.categoryLoadResult = None
        self.categoryLoadTimer = eTimer()
        try: self.categoryLoadTimer.callback.append(self._finishCategoryLoad)
        except Exception: self.categoryLoadTimer.timeout.get().append(self._finishCategoryLoad)
        # Catalog requests are independent from category item requests.  This keeps
        # opening any table responsive even when a provider is slow or unavailable.
        self.catalogLoadToken = 0
        self.catalogLoadResult = None
        self.catalogLoadTimer = eTimer()
        try: self.catalogLoadTimer.callback.append(self._finishCatalogLoad)
        except Exception: self.catalogLoadTimer.timeout.get().append(self._finishCatalogLoad)
        self["keys"] = Label("LEFT/RIGHT تنقل    UP/DOWN صفحات    OK اختيار    أحمر التصنيف السابق    أزرق التصنيف التالي    MENU Favorite    أخضر الباقات/التصنيفات    أصفر ترتيب    EXIT رجوع") if kind != "live" else Label("")
        self["guideBar"] = Pixmap()
        if kind == "live": self._updateLiveKeys()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions", "InfoActions"], {
            "ok": self.ok, "cancel": self.cancelAction, "up": self.up, "down": self.down,
            "left": self.left, "right": self.right,
            "red": self.toggleCurrentFavourite if kind == "live" else self.previousCategory,
            "blue": self.openLiveSearch if kind == "live" else self.nextCategory,
            "green": self.openLiveFilter if kind == "live" else self.openCategoryMenu,
            "yellow": self.toggleLiveSort if kind == "live" else self.toggleSort,
            "yellowlong": self.addCurrentFavourite,
            "menu": self.openFavorites,
            "info": self.openFavorites
        }, -1)
        self.onLayoutFinish.append(self._prepareScreen)

    def noAction(self):
        return

    def openFavorites(self):
        self.session.open(FavoritesScreen)

    def _moveCategory(self, direction):
        """Move through VOD/series categories without reopening or redesigning the screen."""
        if self.kind == "live":
            return
        try:
            rows = list(self["category"].list or [])
        except Exception:
            rows = []
        if not rows:
            try:
                self["meta"].setText("جاري تحميل الباقات/التصنيفات…")
            except Exception:
                pass
            return
        try:
            current = int(self["category"].getSelectedIndex())
        except Exception:
            current = 0
        target = (current + int(direction)) % len(rows)
        try:
            self["category"].moveToIndex(target)
        except Exception:
            return
        try:
            selected = rows[target]
            self.initialCategoryName = selected[0] or ""
            self.initialCategoryId = str(selected[1] or "")
        except Exception:
            pass
        self.focus = "items"
        self.loadSelectedCategory()

    def previousCategory(self):
        self._moveCategory(-1)

    def nextCategory(self):
        self._moveCategory(1)

    def toggleCurrentFavourite(self):
        # The Live red key is intentionally add-only: it matches the visible
        # RED FAVORITE label and never removes a channel by accident.
        item = self.current()
        if not item:
            try:
                self["meta"].setText("اختر قناة أولاً")
            except Exception:
                pass
            return
        title = item.get("name") or item.get("title") or "القناة"
        try:
            if is_favourite(self.source, self.kind, item):
                message = "%s موجودة بالفعل في المفضلات" % title
            elif add_favourite(self.source, self.kind, item):
                message = "تمت إضافة %s إلى المفضلات" % title
            else:
                message = "تعذر حفظ المفضلة"
            self["meta"].setText(message)
        except Exception:
            pass

    def addCurrentFavourite(self):
        # Long yellow is add-only for Movies and TV Shows.  The normal yellow key
        # remains sorting, and the Live action map deliberately stays untouched.
        if self.kind not in ("vod", "series"):
            return
        item = self.current()
        if not item:
            try:
                self["meta"].setText("اختر فيلماً أو مسلسلاً أولاً")
            except Exception:
                pass
            return
        if is_favourite(self.source, self.kind, item):
            message = "العنصر موجود بالفعل في المفضلات"
        elif add_favourite(self.source, self.kind, item):
            message = "تمت الإضافة إلى المفضلات"
        else:
            message = "تعذر حفظ المفضلة"
        try:
            self["meta"].setText(message)
        except Exception:
            pass

    def _updateTopFocus(self):
        if self.kind == "live":
            return
        try:
            self["topSelector"].instance.move(ePoint(sx(self.topX[self.topIndex]), sy(75)))
            self["topSelector"].setVisible(self.focus == "top")
        except Exception:
            pass

    def _openTopItem(self):
        if self.kind == "live":
            return
        if self.topIndex == 0:
            return self.session.open(TiviMateE2Search, self.source)
        if self.topIndex == 1:
            return self.session.open(TiviMateE2Home)
        if self.topIndex == 2:
            return self.session.open(MediaScreen, self.source, "live")
        if self.topIndex == 3:
            return self.session.open(ContentHomeScreen, self.source, "vod")
        if self.topIndex == 4:
            return self.session.open(ContentHomeScreen, self.source, "series")

    def openCategoryMenu(self):
        if self.kind == "live":
            return
        try:
            from .content_home import ServerCategoryList
            self.session.openWithCallback(self._categoryMenuSelected, ServerCategoryList, self.source, self.kind)
        except Exception as exc:
            self.session.open(MessageBox, "تعذر فتح قائمة الباقات/التصنيفات:\n%s" % exc, MessageBox.TYPE_ERROR)

    def _categoryMenuSelected(self, selected=None):
        if not selected:
            return
        cid = str(selected.get("id") or "")
        name = selected.get("name") or ""
        self.initialCategoryId = cid
        self.initialCategoryName = name
        try:
            for pos, row in enumerate(self["category"].list):
                if str(row[1]) == cid:
                    self["category"].moveToIndex(pos)
                    break
        except Exception:
            pass
        self.focus = "items"
        self.loadSelectedCategory()

    def _prepareScreen(self):
        try:
            idx = {"live": 0, "vod": 1, "series": 2}.get(self.kind, 0)
            self["rail"].moveToIndex(idx)
        except Exception:
            pass
        self.updateSectionLabels()
        if self.kind != "live":
            self._updateTopFocus()
        if self.kind == "live":
            self._updateLiveClock()
        self.loadCategories()

    def currentRailSection(self):
        current = self["rail"].getCurrent()
        return current[1] if current else self.kind

    def updateSectionLabels(self):
        label = {"live": "LIVE TV", "vod": "الأفلام", "series": "المسلسلات"}.get(self.kind, self.kind)
        self["title"].setText("%s  •  %s" % (self.source.get("name", "IPTV"), label))
        if self.kind != "live":
            self["sectionTitle"].setText("أقسام الأفلام" if self.kind == "vod" else "أقسام المسلسلات")
            self["searchIcon"].setText("")

    def switchSection(self, section):
        if section == self.kind:
            self.focus = "category"
            return
        if section == "live":
            self.session.open(MediaScreen, self.source, "live")
            return
        self.kind = section
        self.focus = "category"
        self.searchQuery = ""
        self.sortMode = "default"
        self.mediaItems = []
        self.mediaItemsCurrent = []
        self.lastCategoryItems = []
        self.categories = []
        self.pageStart = 0
        self.posterIndex = 0
        try:
            self.infoTimer.stop()
        except Exception:
            pass
        self["category"].setList([])
        self["channelTitle"].setText("اختر تصنيفاً")
        self["meta"].setText("")
        self["desc"].setText("جاري تحميل التصنيفات...")
        self["currentCategory"].setText("")
        self.updateSectionLabels()
        self.loadCategories()

    def loadCategories(self):
        """Load provider catalog data outside Enigma2's UI thread.

        Category lists are shared by LIVE, VOD, and Series.  The former direct
        provider calls could block every table while DNS/HTTP/M3U parsing ran.
        r87 shows a lightweight loading message and applies the ready result from
        a timer callback only after the worker has completed.
        """
        self.catalogLoadToken += 1
        token = self.catalogLoadToken
        source = dict(self.source)
        kind = self.kind
        self.catalogLoadResult = None
        try:
            self["category"].setList([])
            self["list"].setList([])
        except Exception:
            pass
        try:
            self["desc"].setText("Loading catalog in background..." if kind == "live" else "جاري تجهيز القائمة بالخلفية...")
        except Exception:
            pass

        def worker():
            try:
                source_type = source.get("type")
                if source_type in ("xtream", "stalker"):
                    categories, origin = get_cached_categories(source, kind, get_source_client(source), wait_for_server=True)
                    result = (token, source_type, categories or [], [], "", origin)
                elif source_type == "m3u":
                    entries, origin = get_cached_catalog(source, "live", lambda: M3UClient(source).entries(), wait_for_server=True)
                    result = (token, "m3u", [], entries or [], "", origin)
                else:
                    entries, origin = get_cached_catalog(source, "live", lambda: StalkerClient(source).channels(), wait_for_server=True)
                    result = (token, "stalker", [], entries or [], "", origin)
            except Exception as exc:
                result = (token, "error", [], [], str(exc), "")
            self.catalogLoadResult = result

        threading.Thread(target=worker, name="TiviMateE2Catalog", daemon=True).start()
        try:
            self.catalogLoadTimer.start(120, False)
        except Exception:
            pass

    def _finishCatalogLoad(self):
        result = self.catalogLoadResult
        if not result:
            try:
                self.catalogLoadTimer.start(120, False)
            except Exception:
                pass
            return
        self.catalogLoadResult = None
        token, mode, categories, items, error, origin = result
        if token != self.catalogLoadToken:
            return
        if mode == "retry_series":
            try:
                self["desc"].setText("جاري تجهيز أقسام المسلسلات بالخلفية...")
                self.catalogLoadTimer.start(500, False)
                self.catalogLoadResult = (token, "restart", [], [], "", "")
            except Exception:
                pass
            return
        if mode == "restart":
            self.loadCategories()
            return
        if mode == "error":
            try:
                self["desc"].setText(("Unable to load catalog:\\n%s" % error) if self.kind == "live" else ("خطأ في التحميل:\\n%s" % error))
            except Exception:
                pass
            return
        if mode in ("xtream", "stalker"):
            allowed_ids = get_allowed_category_ids(self.source, self.kind)
            blocked = {"all", "all movies", "all films", "all vod", "all series", "كل الأفلام", "جميع الأفلام", "كل افلام", "جميع افلام", "كل المسلسلات", "جميع المسلسلات", "كل المحتوى"}
            rows = []
            filtered = []
            bouquet_icons = ("◉", "◆", "●", "✦", "◈", "▣", "❖", "◎")
            for entry in categories:
                name = (entry.get("category_name") or "Other").strip()
                cid = str(entry.get("category_id", ""))
                if allowed_ids is not None and cid not in allowed_ids:
                    continue
                if self.kind in ("vod", "series") and name.lower() in blocked:
                    continue
                filtered.append(entry)
                rows.append((bouquet_icons[len(rows) % len(bouquet_icons)] + "  " + name, cid))
            self.categories = filtered
            try:
                self["category"].setList(rows)
            except Exception:
                return
            if not rows:
                if self.source.get("type") == "stalker" and origin == "empty":
                    self["desc"].setText("Stalker returned no packages. Check Portal URL and MAG MAC, then retry.")
                else:
                    self["desc"].setText("No packages available." if self.kind == "live" else "لا توجد تصنيفات.")
                return
            had_initial_category = bool(self.initialCategoryId)
            if self.initialCategoryId:
                for pos, row in enumerate(rows):
                    if str(row[1]) == self.initialCategoryId:
                        try:
                            self["category"].moveToIndex(pos)
                        except Exception:
                            pass
                        break
                self.initialCategoryId = ""
            if self.kind == "series" and not had_initial_category:
                self.focus = "category"
                self["channelTitle"].setText("اختر قسم المسلسلات")
                self["desc"].setText("اختر القسم ثم اضغط OK. سيتم تحميل هذا القسم فقط.")
            elif self.kind == "live":
                self.focus = "category"
                self["categoryTitle"].setText("PACKAGES")
                self["channelTitle"].setText("Select a package")
                self["desc"].setText("Select a package and press OK.")
                self._hideRowPicons()
            else:
                self.loadSelectedCategory()
                self.focus = "items"
            return
        if mode == "m3u":
            self.mediaItems = items
            groups = sorted(set(entry.get("group", "Other") for entry in self.mediaItems))
            self.categories = [{"category_name": group, "category_id": group} for group in groups]
            rows = [(group, group) for group in groups]
            self["category"].setList(rows)
            if self.kind == "live" and rows:
                self.focus = "category"
                self["categoryTitle"].setText("PACKAGES")
                self["channelTitle"].setText("Select a package")
                self["desc"].setText("Select a package and press OK.")
                self._hideRowPicons()
            elif rows:
                self.loadSelectedCategory()
                self.focus = "items"
            else:
                self["desc"].setText("No packages available." if self.kind == "live" else "لا توجد تصنيفات.")
            return
        # Stalker has a single, already-built channel group.
        self.mediaItems = items
        self["category"].setList([("All Channels", "")])
        self.showItems(self.mediaItems)

    def selectedCategory(self):
        # LIVE categories are always selected from the left category widget.
        c = self["category"].getCurrent()
        return c[1] if c else ""

    def loadSelectedCategory(self):
        cid=self.selectedCategory()
        c = self["category"].getCurrent()
        name=c[0] if c else ""
        if not cid and self.source.get("type") in ("xtream", "stalker"):
            return
        self["desc"].setText(("Loading %s..." % name) if self.kind == "live" else ("جاري تحميل %s..." % name))
        if self.source.get("type") in ("xtream", "stalker") and self.kind in ("live", "vod", "series"):
            self.categoryLoadToken += 1
            token = self.categoryLoadToken
            self.categoryLoadResult = None
            source = dict(self.source)
            kind = self.kind
            def worker():
                try:
                    items, origin = get_category_streams(source, kind, get_source_client(source), cid, use_cache=True, wait_for_server=(kind != "series"))
                    result = (token, items or [], origin, "", name)
                except Exception as exc:
                    result = (token, [], "error", str(exc), name)
                self.categoryLoadResult = result
            threading.Thread(target=worker, name="TiviMateE2Category", daemon=True).start()
            try: self.categoryLoadTimer.start(120, False)
            except Exception: pass
            return
        try:
            if self.source.get("type") in ("xtream", "stalker"): items=get_source_client(self.source).streams(self.kind,cid)
            elif self.source.get("type")=="m3u": items=[x for x in self.mediaItems if x.get("group")==cid]
            else: items=self.mediaItems
            self._applyCategoryItems(items or [], name, "server")
        except Exception as e:
            self.mediaItemsCurrent=[]
            if self.kind=="live": self["list"].setList([])
            self["desc"].setText(("Unable to load package:\n%s" % e) if self.kind == "live" else ("تعذر تحميل التصنيف:\n%s" % e))

    def _finishCategoryLoad(self):
        result = self.categoryLoadResult
        if not result:
            try: self.categoryLoadTimer.start(120, False)
            except Exception: pass
            return
        self.categoryLoadResult = None
        token, items, origin, error, name = result
        if token != self.categoryLoadToken:
            return
        if origin == "categories_loading":
            rows, cat_origin = get_cached_categories(self.source, "series")
            if not rows:
                self.categoryLoadResult = (token, [], "categories_loading", "", "")
                try: self.categoryLoadTimer.start(500, False)
                except Exception: pass
                return
            self.categories = rows
            allowed_ids = get_allowed_category_ids(self.source, self.kind)
            blocked = {"all", "all series", "كل المسلسلات", "جميع المسلسلات", "كل المحتوى"}
            menu=[]; filtered=[]
            for x in rows:
                cname=(x.get("category_name") or "Other").strip(); ccid=str(x.get("category_id", ""))
                if allowed_ids is not None and ccid not in allowed_ids: continue
                if cname.lower() in blocked: continue
                filtered.append(x); menu.append((cname, ccid))
            self.categories=filtered; self["category"].setList(menu)
            self["desc"].setText("اختر قسم المسلسلات ثم اضغط OK.") if menu else self["desc"].setText("لا توجد تصنيفات.")
            return
        if error:
            self.mediaItemsCurrent=[]
            self["desc"].setText(("Unable to load package:\n%s" % error) if self.kind == "live" else ("تعذر تحميل التصنيف:\n%s" % error))
            return
        if self.source.get("type") == "stalker" and origin == "empty":
            self.mediaItemsCurrent=[]
            if self.kind == "live":
                self["list"].setList([])
            self["desc"].setText("Stalker returned no items for this package. Try another package or refresh the source.")
            return
        if origin == "loading" and self.kind == "series":
            cid = self.selectedCategory()
            cached, new_origin = get_category_streams(self.source, "series", get_source_client(self.source), cid, use_cache=True, wait_for_server=False)
            if not cached and new_origin == "loading":
                self["desc"].setText("القسم يجهز بالخلفية... الواجهة لن تتجمد.")
                self.categoryLoadResult = (token, [], "loading", "", name)
                try: self.categoryLoadTimer.start(500, False)
                except Exception: pass
                return
            items, origin = cached, new_origin
        self._applyCategoryItems(items, name, origin)

    def _applyCategoryItems(self, items, name, origin="server"):
        self.lastCategoryItems = items or []
        if self.kind != "live":
            try:
                suffix = {"ram":" • ذاكرة", "disk":" • HDD", "stale":" • HDD • تحديث بالخلفية", "server":""}.get(origin, "")
                self["currentCategory"].setText(name + suffix)
            except Exception:
                pass
        if self.searchQuery:
            self.applySearch(self.searchQuery)
        else:
            self.showItems(self.lastCategoryItems)

    def showItems(self, items):
        self.mediaItemsCurrent = items or []
        self.pageStart = 0
        self.posterIndex = 0
        if self.kind == "live":
            rows = []
            for index, entry in enumerate(self.mediaItemsCurrent):
                name = entry.get("name") or entry.get("title") or "Unnamed Channel"
                rows.append(("%03d   %s" % (index + 1, name), entry))
            self["list"].setList(rows)
            try:
                self["list"].moveToIndex(0)
            except Exception:
                pass
            self.focus = "items"
            try:
                current = next((entry for entry in self.categories if str(entry.get("category_id", "")) == str(self.selectedCategory())), None)
                if current:
                    self["categoryTitle"].setText(current.get("category_name") or "القنوات")
                self["pageInfo"].setText("1 / %d" % len(self.mediaItemsCurrent) if self.mediaItemsCurrent else "0 / 0")
            except Exception:
                pass
            self._refreshVisibleRowPicons()
            self.previewLive()
        else:
            self.renderPosterPage()


    def current(self):
        if self.kind=="live":
            if self.focus != "items": return None
            c=self["list"].getCurrent(); return c[1] if c else None
        idx=self.pageStart+self.posterIndex
        return self.mediaItemsCurrent[idx] if 0 <= idx < len(self.mediaItemsCurrent) else None

    def previewLive(self):
        item = self.current()
        if not item:
            return
        self._refreshVisibleRowPicons()
        self["channelTitle"].setText(item.get("name") or item.get("title") or "Unnamed Channel")
        self["meta"].setText("")
        self["desc"].setText((item.get("plot") or item.get("description") or "No information available.")[:600])
        try:
            index = self["list"].getSelectedIndex() + 1
            self["pageInfo"].setText("%d / %d" % (index, len(self.mediaItemsCurrent)))
        except Exception:
            pass
        self._showLivePicon(item)
        try:
            self.zapTimer.stop()
        except Exception:
            pass

    def cancelAction(self):
        if self.kind == "live" and self.focus == "items":
            self.focus = "category"
            self["list"].setList([])
            self["categoryTitle"].setText("PACKAGES")
            self["channelTitle"].setText("Select a package")
            self["meta"].setText("")
            self["desc"].setText("Select a package and press OK.")
            self._hideRowPicons()
            return
        self.close()

    def _hideRowPicons(self):
        for i in range(10):
            try:
                self["rowPicon%d" % i].hide()
            except Exception:
                pass

    def _refreshVisibleRowPicons(self):
        """Render a Picon for every visible Live row on any IPTV source."""
        if SAFE_TABLE_MODE or self.kind != "live" or self.focus != "items" or not self.channelSettings.get("picon", True):
            self._hideRowPicons()
            return
        self.rowPiconToken += 1
        token = self.rowPiconToken
        items = self._visibleLiveItems()
        fallback = os.path.join(PLUGIN_PATH, "skins", "live_picon_fallback_r103.png")
        self.rowPiconPaths = {}
        self.rowPiconPending = False
        for index in range(10):
            try:
                if index < len(items):
                    self["rowPicon%d" % index].show()
                    self.rowPiconPaths[index] = fallback
                else:
                    self["rowPicon%d" % index].hide()
            except Exception:
                pass
        # Decode the local fallback immediately, so each visible channel has a Picon even
        # when its server omits stream_icon/logo or the network logo request is delayed.
        self._finishRowPicons()
        for index, item in enumerate(items[:10]):
            url = (item.get("stream_icon") or item.get("logo") or "").strip()
            if not url:
                continue
            def ready(path, row=index, expected=token):
                if expected != self.rowPiconToken or not path:
                    return
                self.rowPiconPaths[row] = path
                try:
                    self.rowPiconTimer.start(1, True)
                except Exception:
                    pass
            try:
                request_artwork(url, "logos", ready, priority=max(1, 20 - index))
            except Exception:
                pass

    def _finishRowPicons(self):
        for idx, path in list(self.rowPiconPaths.items()):
            try:
                loader = self.rowPiconLoaders[idx]
                render_width, render_height = scale_size(64, 46)
                loader.setPara((render_width,render_height,1,1,False,1,"#00000000"))
                loader.startDecode(path)
            except Exception:
                pass
        self.rowPiconPaths = {}

    def _rowPiconDecoded(self, idx):
        try:
            ptr = self.rowPiconLoaders[idx].getData()
            if ptr and self["rowPicon%d" % idx].instance:
                self["rowPicon%d" % idx].instance.setPixmap(ptr)
        except Exception: pass

    def _updateLiveClock(self):
        try:
            self["clockTitle"].setText(time.strftime("%Y/%m/%d   %H:%M", time.localtime()))
        except Exception:
            pass

    def _visibleLiveItems(self):
        items = self.mediaItemsCurrent or []
        if not items:
            return []
        try:
            idx = self["list"].getSelectedIndex()
        except Exception:
            idx = 0
        start = max(0, min(idx - 4, max(0, len(items) - 10)))
        return items[start:start + 10]

    def _updateLiveKeys(self):
        if self.kind != "live":
            return
        pass

    def toggleAutoZap(self):
        if self.kind != "live": return
        self.channelSettings["auto_zap"] = not self.channelSettings.get("auto_zap", True)
        _save_channel_settings(self.channelSettings); self._updateLiveKeys()
        if self.channelSettings["auto_zap"]:
            try: self.zapTimer.stop()
            except Exception: pass
            self._autoZapCurrent()

    def toggleLivePicon(self):
        if self.kind != "live": return
        self.channelSettings["picon"] = not self.channelSettings.get("picon", True)
        _save_channel_settings(self.channelSettings); self._updateLiveKeys(); self.previewLive()

    def _zapLiveItem(self, item, force=False):
        if not item or self.kind != "live":
            return False
        try:
            live_id = str(item.get("stream_id") or item.get("id") or item.get("url") or item.get("cmd") or item.get("name") or "")
            if not force and live_id and live_id == self.lastZappedLiveId:
                return True
            if self.source.get("type") in ("xtream", "stalker"):
                url = get_source_client(self.source).stream_url(item, "live")
            elif self.source.get("type") == "m3u":
                url = item.get("url", "")
            else:
                url = ""
            if not url:
                return False
            service_type = int(self.channelSettings.get("service_type", 4097))
            ref = live_reference(self.source, item, service_type, url, item.get("name") or item.get("title") or "IPTV")
            self.session.nav.playService(ref)
            self.lastZappedLiveId = live_id
            self["meta"].setText("Channel changed")
            return True
        except Exception as exc:
            try:
                self["meta"].setText("Unable to change channel: %s" % exc)
            except Exception:
                pass
            return False

    def _autoZapCurrent(self):
        if not self.channelSettings.get("auto_zap", True):
            return
        self._zapLiveItem(self.current(), False)

    def _showLivePicon(self, item):
        """Always render a channel Picon in the neutral preview area.

        Each source can supply stream_icon/logo; when it does not, the built-in
        transparent fallback is decoded immediately.  This is source agnostic.
        """
        try:
            self["channelPicon"].show()
        except Exception:
            pass
        self.livePiconToken += 1
        token = self.livePiconToken
        fallback = os.path.join(PLUGIN_PATH, "skins", "live_picon_fallback_r103.png")
        self.livePiconDownload = (token, fallback)
        try:
            self.livePiconTimer.start(1, True)
        except Exception:
            pass
        url = (item.get("stream_icon") or item.get("logo") or "").strip()
        if not url:
            return
        def ready(path, expected=token):
            if expected != self.livePiconToken or not path:
                return
            self.livePiconDownload = (expected, path)
            try:
                self.livePiconTimer.start(1, True)
            except Exception:
                pass
        try:
            request_artwork(url, "logos", ready, priority=50)
        except Exception:
            pass

    def _finishLivePicon(self):
        result = self.livePiconDownload
        self.livePiconDownload = None
        if not result:
            return
        token, path = result
        if token != self.livePiconToken:
            return
        try:
            render_width, render_height = scale_size(268, 152)
            self.livePiconLoader.setPara((render_width,render_height,1,1,False,1,"#00000000"))
            self.livePiconLoader.startDecode(path)
        except Exception:
            pass

    def _livePiconDecoded(self, picInfo=None):
        try:
            ptr=self.livePiconLoader.getData()
            if ptr and self["channelPicon"].instance: self["channelPicon"].instance.setPixmap(ptr)
        except Exception: pass

    def renderPosterPage(self):
        self.downloads=[]; self.picloads=[]
        for slot in range(5):
            idx=self.pageStart+slot
            item=self.mediaItemsCurrent[idx] if idx < len(self.mediaItemsCurrent) else None
            self._setVisibleWidget("poster%d"%slot, bool(item))
            self._setVisibleWidget("posterLabel%d"%slot, bool(item))
            self._setVisibleWidget("posterRate%d"%slot, bool(item))
            self["posterLabel%d"%slot].setText(((item.get("name") or item.get("title") or "")[:22]) if item else "")
            rate = ""
            if item:
                rate = item.get("rating") or item.get("rating_5based") or ""
                rate = str(rate)[:4]
            self["posterRate%d"%slot].setText(rate if rate else "")
            self._setPlaceholder(slot)
            if item:
                url=item.get("stream_icon") or item.get("cover") or item.get("movie_image") or ""
                if url: self._loadPosterSlot(slot,url)
        self._setVisibleWidget("selector", bool(self.mediaItemsCurrent))
        self.moveSelector(); self.previewVod()

    def _setVisibleWidget(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def _setPlaceholder(self, slot):
        try:
            self["poster%d"%slot].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png")
        except Exception: pass

    def _loadPosterSlot(self, slot, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_poster_artwork_requests", None)
        if requests is None:
            requests = {}
            self._poster_artwork_requests = requests
        requests[slot] = url

        def done(path, s=slot, expected=url):
            if getattr(self, "_poster_artwork_requests", {}).get(s) != expected:
                return
            self._decodeSlot(s, path)

        request_artwork(url, "posters", done, priority=55)

    def _decodeSlot(self, slot, path):
        loader=ePicLoad(); self.picloads.append(loader)
        def ready(_info=None, s=slot, l=loader):
            try:
                ptr = l.getData()
                if ptr and self["poster%d" % s].instance:
                    self["poster%d" % s].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        loader.PictureData.get().append(ready)
        render_width, render_height = scale_size(270, 380)
        loader.setPara((render_width,render_height,1,1,False,1,"#00000000"))
        loader.startDecode(path)

    def moveSelector(self):
        try:
            self["selector"].instance.move(ePoint(sx(self.POSTER_X[self.posterIndex]), sy(525)))
        except Exception: pass

    def scheduleSelectedInfo(self):
        if self.kind not in ("vod", "series") or self.source.get("type") not in ("xtream", "stalker"):
            return
        try: self.infoTimer.stop()
        except Exception: pass
        try: self.infoTimer.start(900, True)
        except Exception: self.loadSelectedInfo()

    def loadSelectedInfo(self):
        if SAFE_TABLE_MODE:
            return
        item = self.current()
        if not item:
            return
        mid = str(item.get("stream_id") or item.get("series_id") or "")
        if not mid:
            return
        key = self.kind + ":" + mid
        cached = self.fullInfoCache.get(key)
        if cached is not None:
            self.applySelectedInfo(mid, cached)
            return
        if key in self.infoProcesses:
            return
        try:
            if self.source.get("type") == "stalker":
                return
            client = XtreamClient(self.source)
            action = "get_vod_info" if self.kind == "vod" else "get_series_info"
            try:
                from urllib.parse import urlencode
            except ImportError:
                from urllib import urlencode
            url = client.base + "/player_api.php?" + urlencode({
                "username": client.user,
                "password": client.password,
                "action": action,
                ("vod_id" if self.kind == "vod" else "series_id"): mid,
            })
            cache_dir = get_cache_dir("info")
            try:
                ensure_dir(cache_dir)
            except Exception:
                pass
            path = os.path.join(cache_dir, hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")
            proc = eConsoleAppContainer()
            self.infoProcesses[key] = proc
            self.pendingInfoId = mid
            def done(ret, k=key, m=mid, p=path):
                self.infoProcesses.pop(k, None)
                if ret != 0 or not os.path.exists(p):
                    return
                try:
                    with open_text(p, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    self.fullInfoCache[k] = data or {}
                    self.applySelectedInfo(m, data or {})
                except Exception:
                    pass
            try:
                proc.appClosed.append(done)
            except Exception:
                proc.appClosed.get().append(done)
            proc.execute(PYTHON_EXECUTABLE, PYTHON_COMMAND, INFO_FETCH, url, path)
        except Exception:
            return

    def applySelectedInfo(self, mid, data):
        current = self.current()
        current_id = str((current or {}).get("stream_id") or (current or {}).get("series_id") or "")
        if current_id != str(mid):
            return
        item = current or {}
        info = (data or {}).get("info") or {}
        movie = (data or {}).get("movie_data") or {}
        merged = {}
        merged.update(item)
        merged.update(movie)
        merged.update(info)
        title = merged.get("name") or merged.get("title") or ""
        year = merged.get("releasedate") or merged.get("releaseDate") or merged.get("year") or ""
        rating = merged.get("rating") or merged.get("rating_5based") or ""
        genre = merged.get("genre") or ""
        duration = merged.get("duration") or merged.get("duration_secs") or ""
        self["channelTitle"].setText(title)
        self["meta"].setText("   ".join(x for x in [str(year), ("★ %s" % rating) if rating else "", str(duration), str(genre)] if x))
        self["desc"].setText((merged.get("plot") or merged.get("description") or merged.get("overview") or "لا توجد أية معلومات")[:650])
        back = merged.get("backdrop_path") or merged.get("backdrop") or merged.get("backdrop_url") or []
        if isinstance(back, list):
            back = back[0] if back else ""
        if isinstance(back, str):
            back = back.strip().replace(chr(92) + "/", "/")
            if back.startswith("["):
                try:
                    arr = json.loads(back)
                    back = arr[0] if arr else ""
                except Exception:
                    pass
            if back.startswith("/") and not back.startswith("//"):
                back = "https://image.tmdb.org/t/p/w1280" + back
        if not back:
            back = merged.get("cover_big") or merged.get("cover") or merged.get("stream_icon") or merged.get("movie_image") or ""
        if back:
            self.loadBackdrop(back)

    def loadBackdrop(self, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        self._media_backdrop_request = url

        def done(path, expected=url):
            if getattr(self, "_media_backdrop_request", "") != expected:
                return
            self.decodeBackdrop(path)

        request_artwork(url, "backdrops", done, priority=115)

    def decodeBackdrop(self, path):
        self.backdropLoader=ePicLoad()
        def ready(_info=None):
            try:
                ptr=self.backdropLoader.getData()
                if ptr and self["backdrop"].instance: self["backdrop"].instance.setPixmap(ptr)
            except Exception: pass
        self.backdropLoader.PictureData.get().append(ready)
        render_width, render_height = scale_size(1920, 1080)
        self.backdropLoader.setPara((render_width,render_height,1,1,False,1,"#00000000"))
        self.backdropLoader.startDecode(path)

    def previewVod(self):
        item=self.current()
        if not item:
            self["channelTitle"].setText("لا يوجد محتوى"); self["meta"].setText(""); self["desc"].setText(""); self["nowLabel"].setText("0/0"); return
        title=item.get("name") or item.get("title") or ""
        year=item.get("releaseDate") or item.get("year") or ""; rating=item.get("rating") or item.get("rating_5based") or ""; genre=item.get("genre") or ""; dur=item.get("duration") or ""; typ=item.get("container_extension") or item.get("stream_type") or ""
        self["channelTitle"].setText(title)
        self["meta"].setText("  •  ".join(x for x in [(str(rating) if rating else ""), str(genre), str(dur), str(year)] if x))
        self["desc"].setText((item.get("plot") or item.get("description") or "لا توجد أية معلومات")[:600])
        self["nowLabel"].setText("%d / %d" % (self.pageStart+self.posterIndex+1, len(self.mediaItemsCurrent)))
        self.scheduleSelectedInfo()

    def left(self):
        if self.focus == "top":
            self.topIndex = max(0, self.topIndex - 1)
            self._updateTopFocus()
            return
        if self.focus == "items":
            if self.kind == "live":
                self.cancelAction()
                return
            if self.posterIndex > 0:
                self.posterIndex -= 1
                self.moveSelector(); self.previewVod()
                return
            if self.pageStart >= 5:
                self.pageStart -= 5
                self.posterIndex = 4
                self.renderPosterPage()
                return
            self.focus = "category"
            self._updateTopFocus()
            return
        if self.focus == "category":
            self.focus = "rail"
            self._updateTopFocus()

    def right(self):
        if self.focus == "top":
            self.topIndex = min(len(self.topNames) - 1, self.topIndex + 1)
            self._updateTopFocus()
            return
        if self.focus == "rail":
            self.switchSection(self.currentRailSection())
            return
        if self.focus == "category":
            self.loadSelectedCategory()
            self.focus = "items"
            self._updateTopFocus()
            if self.kind != "live":
                self.moveSelector(); self.previewVod()
            return
        if self.kind == "live":
            return
        if self.pageStart + self.posterIndex + 1 >= len(self.mediaItemsCurrent):
            return
        if self.posterIndex < 4 and self.pageStart + self.posterIndex + 1 < len(self.mediaItemsCurrent):
            self.posterIndex += 1
            self.moveSelector(); self.previewVod()
        else:
            self.pageStart += 5
            self.posterIndex = 0
            self.renderPosterPage()

    def up(self):
        if self.focus == "top":
            return
        if self.focus == "rail":
            if self.kind != "live":
                self.focus = "top"
                self._updateTopFocus()
                return
            self["rail"].up()
            return
        if self.focus == "category":
            if self.kind == "live":
                self["category"].up()
            else:
                try:
                    if self["category"].getSelectedIndex() <= 0:
                        self.focus = "top"
                        self._updateTopFocus()
                        return
                except Exception:
                    pass
                self["category"].up()
            return
        if self.kind == "live":
            self["list"].up(); self.previewLive()
            return
        if self.pageStart >= 5:
            self.pageStart -= 5
            self.renderPosterPage()
        else:
            self.focus = "top"
            self._updateTopFocus()

    def down(self):
        if self.focus == "top":
            self.focus = "items"
            self._updateTopFocus()
            if self.kind != "live":
                self.moveSelector(); self.previewVod()
            return
        if self.focus == "rail":
            self["rail"].down()
            return
        if self.focus == "category":
            if self.kind == "live":
                self["category"].down()
            else:
                self["category"].down()
            return
        if self.kind == "live":
            self["list"].down(); self.previewLive()
            return
        if self.pageStart + 5 < len(self.mediaItemsCurrent):
            self.pageStart += 5
            self.renderPosterPage()

    def openLiveSearch(self):
        if self.kind != "live":
            return
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard,
            title="Search channels", text=self.searchQuery or "")

    def openLiveFilter(self):
        if self.kind != "live":
            return
        self.session.openWithCallback(self._liveFilterClosed, ServerCategoryFilter, self.source)

    def _liveFilterClosed(self, changed=False):
        if not changed or self.kind != "live":
            return
        self.searchQuery = ""
        self.sortMode = "default"
        self.lastCategoryItems = []
        self.mediaItemsCurrent = []
        self.focus = "category"
        try:
            pass
        except Exception:
            pass
        self.loadCategories()

    def toggleLiveSort(self):
        if self.kind != "live":
            return
        modes = ["default", "name"]
        try:
            position = modes.index(self.sortMode)
        except Exception:
            position = 0
        self.sortMode = modes[(position + 1) % len(modes)]
        items = list(self.lastCategoryItems or [])
        if self.searchQuery:
            query = self.searchQuery.lower()
            items = [entry for entry in items if query in (entry.get("name") or entry.get("title") or "").lower()]
        if self.sortMode == "name":
            items.sort(key=lambda entry: (entry.get("name") or entry.get("title") or "").lower())
            label = "A-Z"
        else:
            label = "Default"
        try:
            self["meta"].setText("Sort: %s" % label)
        except Exception:
            pass
        self.showItems(items)

    def toggleSort(self):
        if self.kind == "live":
            self.toggleLiveSort()
            return
        modes = ["default", "name", "rating"]
        try:
            pos = modes.index(self.sortMode)
        except Exception:
            pos = 0
        self.sortMode = modes[(pos + 1) % len(modes)]
        items = list(self.mediaItemsCurrent or self.lastCategoryItems or [])
        if self.sortMode == "name":
            items.sort(key=lambda x: (x.get("name") or x.get("title") or "").lower())
            self["filterIcon"].setText("الاسم")
        elif self.sortMode == "rating":
            def rating_value(x):
                try:
                    return float(x.get("rating") or x.get("rating_5based") or 0)
                except Exception:
                    return 0
            items.sort(key=rating_value, reverse=True)
            self["filterIcon"].setText("التقييم")
        else:
            items = list(self.lastCategoryItems or [])
            if self.searchQuery:
                q = self.searchQuery.lower()
                items = [x for x in items if q in (x.get("name") or x.get("title") or "").lower()]
            self["filterIcon"].setText("تصفية")
        self.showItems(items)

    def openSearch(self):
        if self.kind == "live":
            return
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard, title="Search content", text=self.searchQuery or "")

    def searchCallback(self, value=None):
        if value is None:
            return
        value = (value or "").strip()
        self.searchQuery = value
        if not value:
            self.showItems(self.lastCategoryItems)
            return
        self.applySearch(value)

    def applySearch(self, value):
        q = (value or "").strip().lower()
        items = []
        for x in (self.lastCategoryItems or []):
            name = (x.get("name") or x.get("title") or "").lower()
            plot = (x.get("plot") or x.get("description") or "").lower()
            if q in name or q in plot:
                items.append(x)
        self.showItems(items)
        try:
            caption = self["currentCategory"].getText() or ""
            if q:
                self["currentCategory"].setText((caption.split("  •  ")[0] if "  •  " in caption else caption) + "  •  Search")
        except Exception:
            pass

    def close(self, *args, **kwargs):
        if self.kind == "live":
            try:
                self.zapTimer.stop(); self.livePiconTimer.stop(); self.rowPiconTimer.stop()
                pass
                if self.oldService: self.session.nav.playService(self.oldService)
            except Exception:
                pass
        return Screen.close(self, *args, **kwargs)

    def livePlayerClosed(self, index=None):
        try:
            if index is not None and self.mediaItemsCurrent:
                index = max(0, min(int(index), len(self.mediaItemsCurrent) - 1))
                self["list"].moveToIndex(index)
                self.previewLive()
        except Exception:
            pass
        try:
            self.show()
        except Exception:
            pass

    def playerClosed(self, *args):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        try:
            self.show()
        except Exception:
            pass

    def ok(self):
        if self.focus == "top":
            return self._openTopItem()
        if self.focus == "rail":
            self.switchSection(self.currentRailSection())
            return
        if self.focus=="category":
            self.loadSelectedCategory(); self.focus="items"; return
        item=self.current()
        if not item: return
        if self.kind == "live":
            try:
                index = self["list"].getSelectedIndex()
            except Exception:
                index = 0
            self.keepCurrentLiveService = True
            try:
                self.zapTimer.stop()
            except Exception:
                pass
            self.session.openWithCallback(self.livePlayerClosed, TiviMateLivePlayer,
                                          self.source, list(self.mediaItemsCurrent or []), index)
            return
        try:
            if self.source.get("type") in ("xtream", "stalker"):
                if self.kind=="series":
                    return self.session.open(SeriesDetailsScreen, self.source, item)
                url=get_source_client(self.source).stream_url(item,self.kind)
            elif self.source.get("type")=="m3u": url=item.get("url","")
            else: url=""
            if not url: raise Exception("لا يوجد رابط تشغيل")
            service=eServiceReference(4097,0,url); service.setName(item.get("name") or item.get("title") or "IPTV")
            self.session.openWithCallback(self.playerClosed, TiviMatePlayer, service, item)
        except Exception as e:
            self.session.open(MessageBox,"تعذر التشغيل:\n%s"%e,MessageBox.TYPE_ERROR)



FAVOURITES_SKIN = '''<screen name="TiviMateFavorites" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#10151D">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#10151D" zPosition="0" />
    <eLabel position="0,0" size="1920,108" backgroundColor="#182330" zPosition="1" />
    <eLabel position="0,107" size="1920,2" backgroundColor="#65D7F3" zPosition="2" />
    <widget name="title" position="72,24" size="600,60" font="Regular;42" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="filter" position="1350,35" size="500,42" font="Regular;25" foregroundColor="#8EE7FF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
    <widget name="featuredTitle" position="75,160" size="1050,54" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="status" position="75,216" size="1725,52" font="Regular;25" foregroundColor="#C7D3DF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="75,278" size="1725,34" text="TIP: ON A MOVIE OR TV SHOW POSTER, HOLD YELLOW TO ADD TO FAVORITES" font="Regular;21" foregroundColor="#FFE383" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="list" position="-20,-20" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />
    <widget name="poster0" position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle0" position="105,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster1" position="367,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="367,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle1" position="367,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster2" position="629,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="629,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle2" position="629,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster3" position="891,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="891,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle3" position="891,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster4" position="1153,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="1153,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle4" position="1153,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster5" position="1415,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="1415,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle5" position="1415,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="posterSelector" position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_focus_r121.png" alphatest="blend" zPosition="12" />
    <eLabel position="0,936" size="1920,144" backgroundColor="#182330" zPosition="2" />
    <eLabel position="72,966" size="330,50" text="OK  OPEN / PLAY" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="455,966" size="305,50" text="RED  REMOVE" font="Regular;25" foregroundColor="#FF8A87" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="825,966" size="350,50" text="YELLOW  FILTER" font="Regular;25" foregroundColor="#FFE383" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="1240,966" size="340,50" text="BLUE  REFRESH" font="Regular;25" foregroundColor="#8EE7FF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="1640,966" size="220,50" text="EXIT  BACK" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
    <widget name="keys" position="75,1026" size="1770,34" font="Regular;21" foregroundColor="#9EAFBF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
</screen>'''

FAVOURITES_SKIN = scale_skin(FAVOURITES_SKIN)


class FavoritesScreen(Screen):
    """Full-screen local Favorite library for live channels, movies, and series."""
    skin = FAVOURITES_SKIN
    FILTERS = (("ALL", ""), ("LIVE", "live"), ("MOVIES", "vod"), ("TV SHOWS", "series"))
    KIND_LABELS = {"live": "LIVE", "vod": "MOVIE", "series": "SERIES"}
    POSTER_X = (105, 367, 629, 891, 1153, 1415)
    POSTER_Y = 344
    PAGE_SIZE = 6

    def __init__(self, session):
        Screen.__init__(self, session)
        self.filterIndex = 0
        self.records = []
        self.pageStart = 0
        self.posterIndex = 0
        self.picloads = []
        self._poster_artwork_requests = {}
        self["title"] = Label("Favorite")
        self["filter"] = Label("")
        self["featuredTitle"] = Label("YOUR SAVED CONTENT")
        self["list"] = MenuList([])
        self["status"] = Label("")
        self["keys"] = Label("ARROWS  SELECT POSTER     •     HOLD YELLOW ON A MOVIE / TV SHOW POSTER  =  ADD TO FAVORITES")
        for slot in range(self.PAGE_SIZE):
            self["poster%d" % slot] = Pixmap()
            self["posterTitle%d" % slot] = Label("")
        self["posterSelector"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "ok": self.openCurrent, "cancel": self.close,
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "red": self.removeCurrent, "yellow": self.nextFilter, "blue": self.reload,
            "menu": self.nextFilter
        }, -1)
        self.onLayoutFinish.append(self.reload)

    def _currentRecord(self):
        index = self.pageStart + self.posterIndex
        if 0 <= index < len(self.records):
            return self.records[index]
        return None

    def _setVisible(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def _setPlaceholder(self, slot):
        try:
            self["poster%d" % slot].instance.setPixmapFromFile(
                "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png"
            )
        except Exception:
            pass

    def _recordTitle(self, record):
        item = record.get("item") or {}
        return item.get("name") or record.get("title") or item.get("title") or "IPTV"

    def _recordArtwork(self, record):
        item = record.get("item") or {}
        return item.get("stream_icon") or item.get("cover") or item.get("movie_image") or item.get("cover_big") or ""

    def reload(self):
        label, kind = self.FILTERS[self.filterIndex]
        self.records = list_favourites(kind or None)
        self.pageStart = 0
        self.posterIndex = 0
        rows = [(self._recordTitle(record), record) for record in self.records]
        self["list"].setList(rows)
        self["filter"].setText("FILTER: %s" % label)
        self.renderPosterPage()

    def renderPosterPage(self):
        for slot in range(self.PAGE_SIZE):
            index = self.pageStart + slot
            record = self.records[index] if index < len(self.records) else None
            self._setVisible("poster%d" % slot, bool(record))
            self._setVisible("posterTitle%d" % slot, bool(record))
            if not record:
                try:
                    self["posterTitle%d" % slot].setText("")
                except Exception:
                    pass
                continue
            title = self._recordTitle(record)
            kind = self.KIND_LABELS.get(record.get("kind"), "IPTV")
            self["posterTitle%d" % slot].setText(("%s\n%s" % (kind, title))[:42])
            self._setPlaceholder(slot)
            artwork = self._recordArtwork(record)
            if artwork:
                self._loadPoster(slot, artwork)
        self._setVisible("posterSelector", bool(self.records))
        self._moveSelector()
        self._updateStatus()

    def _loadPoster(self, slot, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        self._poster_artwork_requests[slot] = url
        def done(path, s=slot, expected=url):
            if self._poster_artwork_requests.get(s) != expected:
                return
            self._decodePoster(s, path)
        request_artwork(url, "posters", done, priority=55)

    def _decodePoster(self, slot, path):
        loader = ePicLoad()
        self.picloads.append(loader)
        def ready(_info=None, s=slot, current=loader):
            try:
                ptr = current.getData()
                if ptr and self["poster%d" % s].instance:
                    self["poster%d" % s].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if current in self.picloads:
                    self.picloads.remove(current)
            except Exception:
                pass
        try:
            loader.PictureData.get().append(ready)
        except Exception:
            try:
                loader.PictureData.connect(ready)
            except Exception:
                pass
        try:
            render_width, render_height = scale_size(230, 300)
            loader.setPara((render_width, render_height, 1, 1, False, 1, "#00000000"))
            loader.startDecode(path)
        except Exception:
            pass

    def _moveSelector(self):
        if not self.records:
            return
        try:
            self["posterSelector"].instance.move(ePoint(sx(self.POSTER_X[self.posterIndex]), sy(self.POSTER_Y)))
            self["posterSelector"].show()
        except Exception:
            pass

    def _updateStatus(self):
        total = len(self.records)
        record = self._currentRecord()
        if not record:
            self["status"].setText("No saved items in this filter. Open a title and choose Add to My List.")
            return
        title = self._recordTitle(record)
        kind = self.KIND_LABELS.get(record.get("kind"), "IPTV")
        self["status"].setText("%s  •  %s     %d / %d" % (kind, title, self.pageStart + self.posterIndex + 1, total))

    def left(self):
        index = self.pageStart + self.posterIndex
        if index <= 0:
            return
        index -= 1
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def right(self):
        index = self.pageStart + self.posterIndex
        if index >= len(self.records) - 1:
            return
        index += 1
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def up(self):
        index = self.pageStart + self.posterIndex
        if index < self.PAGE_SIZE:
            return
        index -= self.PAGE_SIZE
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def down(self):
        index = self.pageStart + self.posterIndex
        if index + self.PAGE_SIZE >= len(self.records):
            return
        index += self.PAGE_SIZE
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def nextFilter(self):
        self.filterIndex = (self.filterIndex + 1) % len(self.FILTERS)
        self.reload()

    def removeCurrent(self):
        record = self._currentRecord()
        if not record:
            return
        if remove_record(record.get("id", "")):
            self.reload()
        else:
            self["status"].setText("Unable to remove this Favorite.")

    def openCurrent(self):
        record = self._currentRecord()
        if not record:
            return
        source = source_for_record(record, get_sources())
        if not source:
            return self.session.open(MessageBox, "This item's source no longer exists. Press RED to remove it.", MessageBox.TYPE_INFO)
        item = dict(record.get("item") or {})
        kind = record.get("kind")
        try:
            if kind == "live":
                return self.session.open(TiviMateLivePlayer, source, [item], 0)
            if kind == "series":
                if source.get("type") != "xtream":
                    raise Exception("Series require an Xtream Codes source")
                return self.session.open(SeriesDetailsScreen, source, item)
            if source.get("type") == "xtream":
                url = XtreamClient(source).stream_url(item, "vod")
            elif source.get("type") == "m3u":
                url = item.get("url", "")
            else:
                url = StalkerClient(source).stream_url(item, "vod")
            if not url:
                raise Exception("No playable URL")
            service = eServiceReference(4097, 0, url)
            service.setName(item.get("name") or item.get("title") or "IPTV")
            return self.session.open(TiviMatePlayer, service, item)
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open Favorite:\n%s" % exc, MessageBox.TYPE_ERROR)

