# -*- coding: utf-8 -*-
from .storage import get_data_root, data_path
from urllib.request import Request, urlopen
from urllib.parse import urlencode, urlparse, quote
import uuid

from .compat import atomic_replace, ensure_dir, open_text, python_command

import os
import sys
import tempfile
import hashlib
import json
import gzip
import base64
import threading
import time
import re
from datetime import datetime, timedelta

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.InfoBar import MoviePlayer
try:
    from Screens.AudioSelection import AudioSelection
except Exception:
    AudioSelection = None
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
try:
    from Components.VideoWindow import VideoWindow
except Exception:
    VideoWindow = None
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigText, ConfigPassword, ConfigSelection, ConfigYesNo, getConfigListEntry, config, configfile
from enigma import (eServiceReference, ePicLoad, eTimer, eConsoleAppContainer, ePoint,
    eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_VALIGN_CENTER, eEPGCache, eSize)
from Tools.LoadPixmap import LoadPixmap
from skin import parseColor
from .live_service import live_reference, live_reference_string, epg_reference_string
from .epg_local import lookup_channel_epg, refresh_source_epg, ensure_source_epg
try:
    from twisted.internet import reactor
except Exception:
    reactor = None

from .content_home import ContentHomeScreen, MovieDetailsScreen, warm_backdrop_metadata_from_home, _server_poster_url, _server_asset_url

HOME_TMDb_CACHE_FILE = data_path("home_tmdb_cache.json")
_HOME_TMDb_CACHE_LOCK = threading.Lock()

# ---------------------------------------------------------------------------
# TiviMateE2 UI source layout
#
# The large UI implementation is split into ordered source fragments under
# _ui_parts/. They are executed in this module namespace so existing imports
# from .ui keep the same public API and class globals without circular imports.
# ---------------------------------------------------------------------------
def _load_ui_part(filename):
    path = os.path.join(os.path.dirname(__file__), "_ui_parts", filename)
    with open(path, "rb") as handle:
        source = handle.read()
    code = compile(source, path, "exec")
    exec(code, globals(), globals())


_UI_PARTS = (
    "01_common_and_skins.py",
    "02_editors_and_tmdb.py",
    "03_packages_and_settings.py",
    "04_server_manager.py",
    "05_search_home_continue.py",
    "06_series_details.py",
    "07_media_and_favorites.py",
)

for _ui_part in _UI_PARTS:
    _load_ui_part(_ui_part)

del _ui_part
