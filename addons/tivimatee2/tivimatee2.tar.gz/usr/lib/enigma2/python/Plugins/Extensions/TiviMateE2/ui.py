# -*- coding: utf-8 -*-
from __future__ import absolute_import
from .compat import atomic_replace, ensure_dir, open_text, python_command

import os
import hashlib
import shlex
import json
import base64
import threading
import time
import re

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.InfoBar import MoviePlayer
try:
    from Screens.AudioSelection import AudioSelection
except Exception:
    AudioSelection = None
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Components.Label import Label
from Components.Pixmap import Pixmap
try:
    from Components.VideoWindow import VideoWindow
except Exception:
    VideoWindow = None
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigText, ConfigPassword, ConfigSelection, ConfigYesNo, getConfigListEntry
from enigma import (eServiceReference, ePicLoad, eTimer, eConsoleAppContainer, ePoint,
    eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_VALIGN_CENTER, eEPGCache, eSize)
from Tools.LoadPixmap import LoadPixmap
from skin import parseColor
from .live_service import live_reference, live_reference_string, epg_reference_string
from .epg_local import lookup_channel_epg, refresh_source_epg
try:
    from twisted.internet import reactor
except Exception:
    reactor = None

from .content_home import ContentHomeScreen, MovieDetailsScreen

from .cache_manager import get_cache_dir, get_cache_root, get_settings as get_cache_settings, save_settings as save_cache_settings, clear_cache, cache_status, cleanup_cache
from .artwork_queue import request_artwork, cached_artwork
from .display_scale import scale_skin, sx, sy, scale_size

from .core import (
    get_sources, set_sources, write_playlists, PLAYLISTS_FILE,
    XtreamClient, M3UClient, StalkerClient, get_source_client, get_cached_catalog, clear_catalog_memory,
    BASE, load_json, save_json
)
from .server_status import evaluate_reply

from .artwork_queue import request_artwork, cached_artwork
from .tmdb_client import load_settings as load_tmdb_settings, save_settings as save_tmdb_settings, TMDbClient, IMAGE_BASE
from .subdl_client import (
    load_settings as load_subdl_settings,
    save_settings as save_subdl_settings,
    LANGUAGE_CHOICES as SUBDL_LANGUAGE_CHOICES,
)
from .filters import (source_filter_key as _source_filter_key, load_all_filters as _load_all_filters,
    save_all_filters as _save_all_filters, get_allowed_category_ids, filter_items as filter_items_for_source,
    filter_categories, get_filtered_streams, get_category_streams, prefetch_allowed_series,
    prefetch_selected_categories, get_cached_categories, get_stalker_landing_items, get_stalker_home_items)
from .favorites import (add_favourite, toggle_favourite, is_favourite, list_favourites,
    source_for_record, remove_record, source_id as favourite_source_id, count as favourites_count)
from .update_manager import check_for_update, download_package, install_command
from .i18n import tr, get_language, save_language

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
SUBDL_IMPORT_FILE = "/tmp/key.txt"
IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")
INFO_FETCH = os.path.join(PLUGIN_PATH, "info_fetch.py")
PYTHON_EXECUTABLE, PYTHON_COMMAND = python_command()


def _read_subdl_import_key():
    """Read one non-empty SubDL key from the agreed temporary file."""
    if not os.path.isfile(SUBDL_IMPORT_FILE):
        raise IOError("missing")
    with open_text(SUBDL_IMPORT_FILE, "rb") as handle:
        raw = handle.read(1025)
    if len(raw) > 1024:
        raise ValueError("too_long")
    try:
        value = raw.decode("utf-8", "ignore")
    except Exception:
        value = str(raw)
    lines = [line.strip() for line in value.replace("\ufeff", "").splitlines() if line.strip()]
    if len(lines) != 1:
        raise ValueError("invalid_content")
    return lines[0]
# Artwork is now processed by artwork_queue with two background transfers.
# Keep this switch false so legacy screen paths can show cached/queued artwork.
SAFE_TABLE_MODE = False
CHANNEL_SETTINGS_FILE = "/etc/enigma2/tivimatee2_channel_settings.json"
LIVE_SOURCE_FILE = "/etc/enigma2/tivimatee2/live_source.json"


def _source_identity(source):
    source = source or {}
    return "%s|%s|%s|%s" % (
        source.get("type", ""),
        (source.get("url") or source.get("host") or source.get("server") or source.get("portal") or "").rstrip("/"),
        source.get("username", ""),
        source.get("mac", ""),
    )


def _load_live_source(fallback=None):
    sources = get_sources()
    if not sources:
        return fallback
    try:
        with open_text(LIVE_SOURCE_FILE, "r") as handle:
            saved_key = (json.load(handle) or {}).get("key", "")
        for candidate in sources:
            if _source_identity(candidate) == saved_key:
                return candidate
    except Exception:
        pass
    fallback_key = _source_identity(fallback)
    for candidate in sources:
        if _source_identity(candidate) == fallback_key:
            return candidate
    return sources[0]


def _save_live_source(source):
    try:
        ensure_dir(os.path.dirname(LIVE_SOURCE_FILE))
        with open_text(LIVE_SOURCE_FILE, "w") as handle:
            json.dump({"key": _source_identity(source)}, handle)
        return True
    except Exception:
        return False

LIVE_POSTER_INDEX_FILE = "/etc/enigma2/tivimatee2_live_poster_index.json"
_LIVE_POSTER_URLS = None

def _load_live_poster_urls():
    global _LIVE_POSTER_URLS
    if isinstance(_LIVE_POSTER_URLS, dict):
        return _LIVE_POSTER_URLS
    data = {}
    try:
        with open_text(LIVE_POSTER_INDEX_FILE, "r") as handle:
            raw = json.load(handle) or {}
        if isinstance(raw, dict):
            data = {str(k): str(v) for k, v in raw.items() if k and v}
    except Exception:
        pass
    _LIVE_POSTER_URLS = data
    return _LIVE_POSTER_URLS

def _save_live_poster_url(key, url):
    if not key or not url:
        return
    data = _load_live_poster_urls()
    if data.get(key) == url:
        return
    data[key] = url
    # Keep the index bounded for compact receivers.
    if len(data) > 1200:
        for old_key in list(data.keys())[:len(data) - 1000]:
            data.pop(old_key, None)
    try:
        tmp = LIVE_POSTER_INDEX_FILE + ".tmp"
        with open_text(tmp, "w") as handle:
            json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
        atomic_replace(tmp, LIVE_POSTER_INDEX_FILE)
    except Exception:
        pass

def _live_poster_key(title):
    return re.sub(r"\s+", " ", str(title or "").strip().lower())

def _load_channel_settings():
    # These settings belong strictly to Live playback and the visual interface.
    defaults = {"auto_zap": True, "picon": True, "service_type": 4097, "live_color": "#008080", "live_theme": "turquoise"}
    try:
        with open_text(CHANNEL_SETTINGS_FILE, "r") as f:
            data = json.load(f) or {}
        defaults.update({k: bool(data.get(k, defaults[k])) for k in ("auto_zap", "picon")})
        try:
            defaults["service_type"] = int(data.get("service_type", 4097))
        except Exception:
            defaults["service_type"] = 4097
        color = str(data.get("live_color", defaults["live_color"]) or defaults["live_color"]).strip()
        if color.startswith("#") and len(color) in (7, 9):
            defaults["live_color"] = color
        theme = str(data.get("live_theme", defaults["live_theme"]) or defaults["live_theme"]).strip().lower()
        if theme in ("turquoise", "blue", "green", "gold", "purple", "silver"):
            defaults["live_theme"] = theme
    except Exception:
        pass
    return defaults

def _save_channel_settings(data):
    try:
        folder = os.path.dirname(CHANNEL_SETTINGS_FILE)
        if not os.path.isdir(folder): os.makedirs(folder)
        tmp = CHANNEL_SETTINGS_FILE + ".tmp"
        with open_text(tmp, "w") as f:
            json.dump(data, f)
        os.rename(tmp, CHANNEL_SETTINGS_FILE)
        return True
    except Exception:
        return False


class LiveCategoryMenuList(MenuList):
    """Live packages list with a permanently gold Favorites star.

    The rest of each row keeps the active skin's normal and selected colors,
    so switching Live styles does not alter the existing icons or theme logic.
    """
    def __init__(self, entries=None):
        MenuList.__init__(self, entries or [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 21))
            self.l.setItemHeight(48)
            self.l.setBuildFunc(self._build_entry)
        except Exception:
            pass

    def _build_entry(self, name, category_id):
        name = str(name or "")
        category_id = str(category_id or "")
        result = [(name, category_id)]
        if category_id == "__favorites__":
            result.append(MultiContentEntryText(
                pos=(4, 0), size=(34, 48), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=u"★", color=0x00FFD700,
                color_sel=0x00FFD700
            ))
            label = name.replace(u"★", "").strip()
            result.append(MultiContentEntryText(
                pos=(42, 0), size=(270, 48), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=label
            ))
        else:
            result.append(MultiContentEntryText(
                pos=(4, 0), size=(308, 48), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=name
            ))
        return result

HOME_APPEARANCE_FILE = "/etc/enigma2/tivimatee2/home_appearance.json"

def _load_home_appearance():
    # Skin 2 is the default Home on a fresh installation. Existing saved user
    # choices remain respected; retired or missing values fall back to Skin 2.
    data = {"skin": "skin2_dark"}
    try:
        with open_text(HOME_APPEARANCE_FILE, "r") as f:
            saved = json.load(f)
        if saved.get("skin") in ("reference_home", "skin2_dark"):
            data["skin"] = saved.get("skin")
    except Exception:
        pass
    return data

def _save_home_appearance(skin_name):
    try:
        folder = os.path.dirname(HOME_APPEARANCE_FILE)
        if not os.path.isdir(folder): os.makedirs(folder)
        tmp = HOME_APPEARANCE_FILE + ".tmp"
        with open_text(tmp, "w") as f:
            json.dump({"skin": skin_name}, f)
        os.rename(tmp, HOME_APPEARANCE_FILE)
        return True
    except Exception:
        return False

UPDATE_SETTINGS_FILE = "/etc/enigma2/tivimatee2/update_settings.json"

def _load_update_settings():
    defaults = {"auto_check": True}
    try:
        with open_text(UPDATE_SETTINGS_FILE, "r") as handle:
            stored = json.load(handle) or {}
        defaults["auto_check"] = bool(stored.get("auto_check", defaults["auto_check"]))
    except Exception:
        pass
    return defaults


def _save_update_settings(auto_check):
    try:
        folder = os.path.dirname(UPDATE_SETTINGS_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = UPDATE_SETTINGS_FILE + ".tmp"
        with open_text(temporary, "w") as handle:
            json.dump({"auto_check": bool(auto_check)}, handle)
        os.rename(temporary, UPDATE_SETTINGS_FILE)
        return True
    except Exception:
        return False

HOME_SKIN1 = '''<screen name="TiviMateE2Home" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#050C14">
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home_reference_v4_bg_r77_1920x1080.png" alphatest="blend" zPosition="0" />
		<widget name="homeBrandLogo" position="62,10" size="300,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="6" />
        <widget name="poweredBy" position="1420,1038" size="360,22" font="Regular;16" foregroundColor="#87CDEE" backgroundColor="#00000000" transparent="1" halign="right" zPosition="7" />
	<ePixmap position="13,320" size="64,273" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/sidebar_classic_icons_v2.png" alphatest="blend" zPosition="6" />
	<widget name="headline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="subheadline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="logo" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="nav0" position="380,27" size="150,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="nav1" position="550,27" size="150,58" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="nav2" position="710,27" size="150,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="nav3" position="870,27" size="150,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="nav4" position="1030,27" size="170,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
	<widget name="nav5" position="1210,27" size="165,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
	<widget name="nav6" position="1390,27" size="160,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
	<widget name="nav7" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
	<widget name="navSelector" position="550,27" size="150,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_reference_v4.png" alphatest="blend" zPosition="3" />
	<widget name="clock" position="1625,35" size="180,32" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
	<widget name="date" position="1625,68" size="180,22" font="Regular;15" foregroundColor="#91A0B4" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />

	<widget name="banner" position="108,120" size="1704,454" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder_v4.jpg" alphatest="blend" scale="1" zPosition="1" />
<ePixmap position="108,120" size="1704,454" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_overlay_v4.png" alphatest="blend" zPosition="2" />
<widget name="quality" position="155,151" size="330,30" font="Regular;20" foregroundColor="#27C8FF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureTitle" position="155,194" size="720,112" font="Regular;56" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureMeta" position="155,324" size="700,36" font="Regular;23" foregroundColor="#DDE5EF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureDesc" position="155,371" size="720,84" font="Regular;22" foregroundColor="#DDE5EF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="playNow" position="155,498" size="240,60" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#24292F" halign="center" valign="center" zPosition="4" />
<widget name="recentTitle" position="100,610" size="500,42" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="poster0" position="106,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="106,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="116,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate0" position="116,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle0" position="184,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster1" position="398,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="398,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="408,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate1" position="408,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle1" position="476,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster2" position="690,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="690,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="700,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate2" position="700,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle2" position="768,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster3" position="982,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="982,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="992,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate3" position="992,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle3" position="1060,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster4" position="1274,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1274,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="1284,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate4" position="1284,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle4" position="1352,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster5" position="1566,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1566,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="1576,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate5" position="1576,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle5" position="1644,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="posterSelector" position="106,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_248x338.png" alphatest="blend" zPosition="8" />
<widget name="status" position="520,1038" size="880,26" font="Regular;17" foregroundColor="#95A2B5" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
</screen>'''

SEARCH_SCREEN = '''<screen name="TiviMateE2Search" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
<eLabel position="0,0" size="1920,1080" backgroundColor="#000000" zPosition="0" />
<widget name="back" position="55,62" size="85,70" font="Regular;44" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<ePixmap position="145,55" size="1510,82" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/search_bar.png" alphatest="blend" zPosition="1" />
<widget name="searchText" position="205,70" size="1325,52" font="Regular;31" foregroundColor="#F3F4F8" backgroundColor="#00000000" transparent="1" valign="center" zPosition="2" />
<widget name="mic" position="1670,55" size="80,82" font="Regular;39" foregroundColor="#F5C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<widget name="closeIcon" position="1775,55" size="80,82" font="Regular;39" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<widget name="moviesTitle" position="85,175" size="600,48" font="Regular;31" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" />
<widget name="showsTitle" position="85,690" size="600,48" font="Regular;31" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" />
<widget name="poster0" position="85,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="85,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="95,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate0" position="95,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel0" position="163,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster1" position="325,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="325,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="335,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate1" position="335,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel1" position="403,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster2" position="565,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="565,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="575,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate2" position="575,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel2" position="643,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster3" position="805,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="805,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="815,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate3" position="815,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel3" position="883,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster4" position="1045,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1045,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="1055,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate4" position="1055,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel4" position="1123,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster5" position="1285,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1285,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="3" />
<ePixmap position="1295,550" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate5" position="1295,550" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel5" position="1363,539" size="127,56" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster6" position="85,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="85,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="95,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate6" position="95,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel6" position="163,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster7" position="325,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="325,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="335,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate7" position="335,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel7" position="403,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster8" position="565,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="565,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="575,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate8" position="575,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel8" position="643,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster9" position="805,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="805,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="815,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate9" position="815,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel9" position="883,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster10" position="1045,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1045,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="1055,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate10" position="1055,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel10" position="1123,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster11" position="1285,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1285,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x265.png" alphatest="blend" zPosition="3" />
<ePixmap position="1295,976" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate11" position="1295,976" size="58,34" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterLabel11" position="1363,971" size="127,44" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="movieSelector" position="85,235" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_215x360.png" alphatest="blend" zPosition="8" />
<widget name="showSelector" position="85,750" size="215,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_215x265.png" alphatest="blend" zPosition="8" />
<ePixmap position="1540,365" size="330,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/search_details.png" alphatest="blend" zPosition="2" />
<widget name="selectedTitle" position="1565,388" size="280,90" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="3" />
<widget name="play" position="1565,492" size="280,64" font="Regular;28" foregroundColor="#111318" backgroundColor="#E2B84B" halign="center" valign="center" zPosition="3" />
<widget name="favorite" position="1565,570" size="280,44" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#343B47" halign="center" valign="center" zPosition="3" />
<widget name="status" position="600,1000" size="850,34" font="Regular;21" foregroundColor="#D2D8E1" backgroundColor="#00000000" transparent="1" halign="center" />
<widget name="guideBar" position="420,1034" size="1080,52" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/search_guide_r69.png" alphatest="blend" zPosition="4" />
</screen>'''

SOURCE_MENU = '''<screen name="TiviMateE2SourceMenu" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#06101D">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_solid_navy_r64.png" alphatest="blend" zPosition="0" />
    <eLabel position="0,0" size="1920,112" backgroundColor="#0A111C" zPosition="1" />
    <ePixmap position="72,14" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="5" />
    <widget name="brand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="side" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="title" position="112,178" size="1120,58" font="Regular;42" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="subtitle" position="115,238" size="600,30" font="Regular;20" foregroundColor="#73D4FF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="108,302" size="1704,498" backgroundColor="#0E1C2D" zPosition="1" />
    <eLabel position="110,304" size="1700,494" backgroundColor="#13243A" zPosition="2" />
    <widget name="menu" position="170,360" size="1450,310" font="Regular;31" itemHeight="64" foregroundColor="#EDF6FF" foregroundColorSelected="#FFFFFF" backgroundColor="#00000000" backgroundColorSelected="#187DB8" scrollbarMode="showOnDemand" zPosition="4" />
    <widget name="info" position="170,710" size="1450,54" font="Regular;22" foregroundColor="#B9C7D8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="keys" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="guideBar" position="420,920" size="1080,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/source_menu_guide_r69.png" alphatest="blend" zPosition="5" />
</screen>'''

EDITOR = '''<screen name="TiviMateE2PlaylistEditor" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#06101D">
    <!-- RGB PNG base: one opaque navy colour, with no alpha channel or panel overlays. -->
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_solid_navy_r64.png" alphatest="blend" zPosition="0" />
    <widget name="settingsLogo" position="78,14" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="5" />
    <widget name="settingsBrand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsTagline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNavSelector" position="1215,27" size="165,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_classic_focus_v5.png" alphatest="blend" zPosition="3" />
    <widget name="settingsNav0" position="450,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav1" position="603,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav2" position="756,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav3" position="909,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav4" position="1062,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav5" position="1215,27" size="165,58" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsClock" position="1430,28" size="160,34" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" zPosition="4" />
    <widget name="settingsDate" position="1430,67" size="190,26" font="Regular;17" foregroundColor="#91A0B4" backgroundColor="#00000000" transparent="1" halign="left" zPosition="4" />
    <widget name="settingsSideTitle" position="92,182" size="330,54" font="Regular;32" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="3" />
    <widget name="settingsSideText" position="98,252" size="318,170" font="Regular;22" foregroundColor="#D6E4F2" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="3" />
    <widget name="settingsSideHint" position="100,736" size="316,78" font="Regular;20" foregroundColor="#6DD8FF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="3" />
    <ePixmap position="110,430" size="286,270" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_card_r64.png" alphatest="blend" zPosition="2" />
    <ePixmap position="130,447" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_globe_r64.png" alphatest="blend" zPosition="4" />
    <widget name="languageTitle" position="170,446" size="205,36" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="languageSelector" position="124,492" size="258,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_row_focus_r64.png" alphatest="blend" zPosition="3" />
    <widget name="language0" position="146,498" size="174,44" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
    <widget name="language1" position="146,562" size="174,44" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
    <widget name="language2" position="146,626" size="174,44" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
    <widget name="languageRadio0" position="334,504" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_radio_off_r64.png" alphatest="blend" zPosition="5" />
    <widget name="languageRadio1" position="334,568" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_radio_off_r64.png" alphatest="blend" zPosition="5" />
    <widget name="languageRadio2" position="334,632" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_radio_off_r64.png" alphatest="blend" zPosition="5" />
    <widget name="title" position="500,196" size="1260,52" font="Regular;39" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />
    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />
    <widget name="config" position="520,312" size="660,350" font="Regular;28" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#3A3020" selectionForegroundColor="#FFFFFF" zPosition="4" />
    <widget name="hint" position="500,878" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
    <widget name="settingsGuide" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_guide_keyboard_save_r69.png" alphatest="blend" zPosition="4" />
    <widget name="settingsActionButtons" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_action_buttons_r65.png" alphatest="blend" zPosition="4" />
</screen>'''

XTREAM_EDITOR_SKIN = EDITOR.replace('    <ePixmap position="500,282" size="700,408" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_list_card_r67.png" alphatest="blend" zPosition="2" />\n    <widget name="config" position="520,312" size="660,350" font="Regular;28" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_row_focus_r67.png" zPosition="3" />', '    <eLabel position="500,255" size="1040,600" backgroundColor="#081A2E" zPosition="2" />\n    <eLabel position="508,263" size="1024,584" backgroundColor="#12385F" zPosition="3" />\n    <widget name="config" position="545,285" size="950,540" font="Regular;30" itemHeight="60" foregroundColor="#FFFFFF" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#3A3020" selectionForegroundColor="#FFFFFF" zPosition="5" />')
STALKER_EDITOR_SKIN = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="StalkerPortalEditor"').replace('    <ePixmap position="500,282" size="700,408" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_list_card_r67.png" alphatest="blend" zPosition="2" />\n    <widget name="config" position="520,312" size="660,350" font="Regular;28" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_row_focus_r67.png" zPosition="3" />', '    <eLabel position="520,270" size="980,430" backgroundColor="#081A2E" zPosition="2" />\n    <eLabel position="528,278" size="964,414" backgroundColor="#12385F" zPosition="3" />\n    <widget name="config" position="565,305" size="890,350" font="Regular;30" itemHeight="68" foregroundColor="#FFFFFF" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#3A3020" selectionForegroundColor="#FFFFFF" zPosition="5" />')

# Server Manager keeps the existing menu, navigation and action bar intact.  Only
# the unused lower space becomes a general connection-status card; no account or
# subscriber information is displayed here.
SERVER_MANAGER_SKIN = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="ServerManager"').replace(
    '''    <widget name="config" position="500,294" size="1230,480" font="Regular;30" itemHeight="68" foregroundColor="#F5F8FC" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" zPosition="3" />
    <widget name="hint" position="500,878" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="3" />''',
    '''    <widget name="config" position="500,294" size="1230,380" font="Regular;30" itemHeight="68" foregroundColor="#F5F8FC" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" zPosition="3" />
    <eLabel position="500,792" size="1230,132" backgroundColor="#10233A" zPosition="1" />
    <eLabel position="502,794" size="1226,128" backgroundColor="#142B46" zPosition="2" />
    <ePixmap position="1298,796" size="430,124" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_network_r123.png" alphatest="blend" zPosition="3" />
    <widget name="serverStatusTitle" position="536,808" size="650,28" font="Regular;24" foregroundColor="#F2FBFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="serverStatusText" position="536,844" size="650,26" font="Regular;20" foregroundColor="#B9CDE0" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendOnlineIcon" position="536,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_online_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendOnline" position="562,875" size="170,26" font="Regular;18" foregroundColor="#67E89A" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendCheckingIcon" position="740,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_busy_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendChecking" position="766,875" size="185,26" font="Regular;18" foregroundColor="#FFD669" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendOfflineIcon" position="960,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_offline_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendOffline" position="986,875" size="185,26" font="Regular;18" foregroundColor="#FF8C95" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="hint" position="500,892" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="5" />'''
).replace(
    '''    <widget name="settingsActionButtons" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_action_buttons_r65.png" alphatest="blend" zPosition="4" />
</screen>''',
    '''    <widget name="settingsActionButtons" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_action_buttons_r65.png" alphatest="blend" zPosition="4" />
    <ePixmap position="1480,948" size="250,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_subdl_shortcut_r103.png" alphatest="blend" zPosition="6" />
</screen>'''
)


# Test73: enlarge only the Server Manager list area. Keep the simple list style
# and leave editors, language card, navigation, and action buttons unchanged.
SERVER_MANAGER_SKIN = SERVER_MANAGER_SKIN.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(
    '<eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />\n'
    '    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />\n'
    '    <widget name="config" position="520,312" size="660,350" font="Regular;28" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#3A3020" selectionForegroundColor="#FFFFFF" zPosition="4" />',
    '<eLabel position="455,252" size="1215,500" backgroundColor="#07121D" zPosition="2" />\n'
    '    <eLabel position="463,260" size="1199,484" backgroundColor="#0D1C2A" zPosition="3" />\n'
    '    <widget name="config" position="495,286" size="1135,410" font="Regular;34" itemHeight="88" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_row_focus_dark_cyan_r126.png" selectionForegroundColor="#FFFFFF" zPosition="4" />'
)

def _setup_settings_chrome(screen):
    labels = [tr("Search"), tr("Home"), tr("Live"), tr("Movies"), tr("TV Shows"), tr("Settings")]
    screen["settingsBrand"] = Label(tr("TiViMate"))
    screen["settingsTagline"] = Label(tr("IPTV EXPERIENCE"))
    screen["settingsLogo"] = Pixmap()
    screen["settingsSideTitle"] = Label(tr("CONTROL CENTER"))
    screen["settingsSideText"] = Label(tr("Manage playlists,\nconnections and metadata,\nand appearance settings."))
    screen["settingsSideHint"] = Label(tr("Use the colour keys below\nfor quick actions."))
    screen["settingsNavSelector"] = Pixmap()
    screen["settingsGuide"] = Pixmap()
    screen["settingsActionButtons"] = Pixmap()
    try:
        screen["settingsNavSelector"].hide()
        screen["settingsGuide"].hide()
        screen["settingsActionButtons"].hide()
    except Exception:
        pass
    for index, label in enumerate(labels):
        screen["settingsNav%d" % index] = Label(label)
    now = time.localtime()
    screen["settingsClock"] = Label(time.strftime("%H:%M", now))
    screen["settingsDate"] = Label(time.strftime("%a, %d %b", now))


def _show_settings_guide(screen):
    try:
        screen["settingsGuide"].show()
    except Exception:
        pass



# Skin 2 is the optional cinematic Home dashboard selected in Home Appearance.
# It intentionally preserves every widget TiviMateE2Home manages at runtime.
HOME_SKIN2 = """<screen name="TiviMateE2Home" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05080D">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#05080D" zPosition="0" />
    <eLabel position="0,0" size="1920,92" backgroundColor="#090D12" zPosition="1" />

    <widget name="banner" position="0,92" size="1920,370" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_global_hero_r70.png" alphatest="blend" scale="1" zPosition="1" />
    <ePixmap position="0,92" size="1920,370" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_cinema_hero_overlay.png" alphatest="blend" zPosition="2" />

    <widget name="logo" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="homeBrandLogo" position="28,10" size="285,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="7" />
    <widget name="headline" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="subheadline" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />

    <widget name="nav0" position="360,15" size="160,64" font="Regular;28" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav1" position="535,15" size="150,64" font="Regular;28" foregroundColor="#DDE5EC" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav2" position="700,15" size="160,64" font="Regular;28" foregroundColor="#DDE5EC" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav3" position="875,15" size="180,64" font="Regular;28" foregroundColor="#DDE5EC" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav4" position="1070,15" size="150,64" font="Regular;28" foregroundColor="#DDE5EC" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav5" position="1235,15" size="185,64" font="Regular;28" foregroundColor="#DDE5EC" transparent="1" halign="center" valign="center" zPosition="7" />
    <widget name="nav6" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="nav7" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="navSelector" position="350,79" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_gold.png" alphatest="blend" zPosition="9" />
    <widget name="clock" position="1595,18" size="210,34" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" halign="right" zPosition="7" />
    <widget name="date" position="1575,56" size="230,24" font="Regular;17" foregroundColor="#A9B3BD" transparent="1" halign="right" zPosition="7" />

    <widget name="quality" position="48,148" size="680,32" font="Regular;21" foregroundColor="#E2B84B" transparent="1" zPosition="7" />
    <widget name="featureTitle" position="48,180" size="760,72" font="Regular;42" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="7" />
    <widget name="featureMeta" position="48,258" size="700,42" font="Regular;24" foregroundColor="#E5EAF0" transparent="1" valign="center" zPosition="7" />
    <widget name="featureDesc" position="48,305" size="680,82" font="Regular;22" foregroundColor="#D5DCE4" transparent="1" zPosition="7" />
    <eLabel position="48,395" size="245,56" backgroundColor="#B7181F" cornerRadius="12" zPosition="6" />
    <widget name="playNow" position="48,395" size="245,56" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="7" />
    <eLabel position="315,395" size="245,56" text="ⓘ  More Info" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#24292F" halign="center" valign="center" cornerRadius="12" zPosition="7" />

    <widget name="recentTitle" position="55,468" size="560,40" font="Regular;28" foregroundColor="#FFFFFF" transparent="1" halign="left" zPosition="8" />

    <widget name="poster0" position="55,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" /><ePixmap position="55,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate0" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle0" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="poster1" position="375,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" /><ePixmap position="375,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate1" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle1" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="poster2" position="695,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" /><ePixmap position="695,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate2" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle2" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="poster3" position="1015,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" /><ePixmap position="1015,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate3" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle3" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="poster4" position="1335,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" /><ePixmap position="1335,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate4" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle4" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="poster5" position="1655,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" /><ePixmap position="1655,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate5" position="-20,-20" size="1,1" font="Regular;1" transparent="1" /><widget name="posterMetaTitle5" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="posterSelector" position="55,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_215x360.png" alphatest="blend" zPosition="10" />

    <eLabel position="45,888" size="1830,74" backgroundColor="#0F151C" zPosition="5" />
    <eLabel position="55,898" size="425,54" backgroundColor="#137A35" cornerRadius="12" zPosition="6" />
    <eLabel position="505,898" size="425,54" backgroundColor="#A87800" cornerRadius="12" zPosition="6" />
    <eLabel position="955,898" size="425,54" backgroundColor="#13568C" cornerRadius="12" zPosition="6" />
    <eLabel position="1405,898" size="425,54" backgroundColor="#A61D24" cornerRadius="12" zPosition="6" />
    <widget name="actionLabel0" position="55,898" size="425,54" font="Regular;24" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />
    <widget name="actionLabel1" position="505,898" size="425,54" font="Regular;24" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />
    <widget name="actionLabel2" position="955,898" size="425,54" font="Regular;24" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />
    <widget name="actionLabel3" position="1405,898" size="425,54" font="Regular;24" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />

    <eLabel position="45,974" size="575,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <eLabel position="645,974" size="620,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <eLabel position="1290,974" size="540,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <widget name="skin2HelpTitle" position="68,985" size="225,28" font="Regular;22" foregroundColor="#E2B84B" transparent="1" zPosition="8" />
    <widget name="skin2HelpBody" position="68,1014" size="520,28" font="Regular;17" foregroundColor="#C4CED8" transparent="1" zPosition="8" />
    <widget name="skin2LangTitle" position="665,985" size="580,28" font="Regular;22" foregroundColor="#E2B84B" transparent="1" halign="center" zPosition="8" />
    <widget name="skin2LangBody" position="665,1014" size="580,28" font="Regular;17" foregroundColor="#C4CED8" transparent="1" halign="center" zPosition="8" />
    <widget name="skin2Key5" position="1310,986" size="500,54" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />
    <widget name="poweredBy" position="1390,1050" size="440,24" font="Regular;18" foregroundColor="#E2B84B" transparent="1" halign="right" zPosition="8" />
    <widget name="status" position="600,1050" size="720,24" font="Regular;18" foregroundColor="#B8C3CD" transparent="1" halign="center" zPosition="8" />
</screen>"""

LIVE_CLASSIC = """<screen name="MediaScreen" position="0,0" size="1920,1080" backgroundColor="#00101214" flags="wfNoBorder">
    <!-- Test10: opaque Live layout with a real receiver PIG preview. -->
    <eLabel position="0,0" size="1920,1080" backgroundColor="#00101214" zPosition="0" />

    <widget name="brand" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="rail" position="-20,-20" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />

    <!-- Header -->
    <widget name="title" position="42,24" size="1180,50" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="10" />
    <widget name="clockTitle" position="1505,26" size="360,42" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="10" />
    <eLabel position="34,84" size="920,3" backgroundColor="#20262D" zPosition="4" />

    <!-- Packages: narrow Aglare-style list -->
    <eLabel position="28,104" size="355,850" backgroundColor="#D8171A1C" cornerRadius="18" zPosition="1" />
    <eLabel position="38,114" size="335,48" backgroundColor="#00131313" cornerRadius="12" zPosition="2" />
    <eLabel position="54,121" size="220,36" text="PACKAGES" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="categoryTitle" position="278,123" size="78,32" font="Regular;17" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="8" />
    <widget name="category" position="42,176" size="327,760" font="Regular;21" itemHeight="48" foregroundColor="#F1F3F5" foregroundColorSelected="#008080" backgroundColor="#00000000" backgroundColorSelected="#00000000" transparent="1" itemGradientSelected="#003F3F3F,#002F2F2F,#003F3F3F,vertical" itemCornerRadius="10" itemCornerRadiusSelected="10" scrollbarMode="showOnDemand" zPosition="7" />

    <!-- Channels: main list, matching ChannelSelection proportions -->
    <eLabel position="402,104" size="610,850" backgroundColor="#D8171A1C" cornerRadius="18" zPosition="1" />
    <eLabel position="412,114" size="590,48" backgroundColor="#00131313" cornerRadius="12" zPosition="2" />
    <eLabel position="430,121" size="300,36" text="CHANNELS" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="pageInfo" position="826,123" size="154,32" font="Regular;17" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="8" />
    <widget name="list" position="478,176" size="510,760" font="Regular;21" itemHeight="50" foregroundColor="#FFFFFF" foregroundColorSelected="#008080" backgroundColor="#00000000" backgroundColorSelected="#00000000" transparent="1" itemGradientSelected="#003F3F3F,#002F2F2F,#003F3F3F,vertical" itemCornerRadius="10" itemCornerRadiusSelected="10" scrollbarMode="showOnDemand" zPosition="7" />

    <!-- Right details area inspired by Aglare ChannelSelectionPIG -->
    <eLabel position="1032,104" size="860,850" backgroundColor="#B8171A1C" cornerRadius="18" zPosition="1" />
    <widget name="channelPicon" position="1100,146" size="118,68" alphatest="blend" zPosition="8" />
    <widget name="channelTitle" position="1242,126" size="608,48" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="meta" position="1242,180" size="608,34" font="Regular;20" foregroundColor="#D4D9DE" backgroundColor="#00000000" transparent="1" zPosition="8" />

    <!-- Real receiver PIG preview window -->
    <widget source="session.VideoPicture" render="Pig" position="1318,232" size="540,306" backgroundColor="transparent" transparent="0" zPosition="8" />
        <eLabel position="1318,548" size="540,9" backgroundColor="#5A5A5A" cornerRadius="4" zPosition="7" />
    <widget name="liveProgress" position="1318,548" size="540,9" borderWidth="0" foregroundColor="#00B77A" backgroundColor="#5A5A5A" zPosition="9" />

    <!-- Current and next EPG from Enigma2 EPG cache -->
    <eLabel position="1060,578" size="798,342" backgroundColor="#85131313" cornerRadius="16" zPosition="2" />
    <eLabel position="1084,600" size="750,3" backgroundColor="#6A6F75" zPosition="4" />
    <widget name="livePoster" position="1084,614" size="150,225" alphatest="blend" zPosition="9" />
    <widget name="epgNowTime" position="1252,614" size="170,34" font="Regular;20" foregroundColor="#00D7C7" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="epgNowTitle" position="1422,610" size="408,42" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="8" />
    <widget name="epgProgressText" position="1680,652" size="150,30" font="Regular;18" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="8" />
    <eLabel position="1084,684" size="750,2" backgroundColor="#4A4F55" zPosition="4" />
    <widget name="epgNextTime" position="1252,696" size="170,34" font="Regular;20" foregroundColor="#E5B243" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="epgNextTitle" position="1422,692" size="408,42" font="Regular;23" foregroundColor="#F0F2F4" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="8" />
    <widget name="desc" position="1252,746" size="578,150" font="Regular;20" foregroundColor="#D8DDE2" backgroundColor="#00000000" transparent="1" valign="top" zPosition="8" />

    <!-- Visible hint so every user knows how to change the full Live style -->
    <widget name="styleHint" position="1580,62" size="280,34" font="Regular;18" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="12" />

    <!-- Keep original plugin footer exactly as-is -->
    <widget name="guideBar" position="80,1015" size="1760,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live_guide_r120.png" alphatest="blend" zPosition="12" />

    <widget name="nowLabel" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="keys" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
</screen>"""
VOD = '''<screen name="TiviMateE2Vod" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#10151d">
<widget name="backdrop" position="0,0" size="1920,1080" alphatest="blend" zPosition="0" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/vod_cinematic_overlay_testF.png" alphatest="blend" zPosition="1" />
<widget name="top0" position="90,24" size="180,48" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top1" position="285,24" size="180,48" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top2" position="480,24" size="180,48" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top3" position="675,24" size="180,48" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top4" position="870,24" size="210,48" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="topSelector" position="675,75" size="190,5" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/top_selector.png" alphatest="blend" zPosition="7" />
<!-- compatibility widgets kept off-screen: categories are opened through FILTER only -->
<widget name="brand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="rail" position="-10,-10" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />
<widget name="category" position="-10,-10" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />
<widget name="sectionTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="currentCategory" position="80,450" size="700,42" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="searchIcon" position="1650,55" size="85,55" font="Regular;36" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
<widget name="filterIcon" position="1740,55" size="110,55" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
<widget name="title" position="80,92" size="1500,44" font="Regular;27" foregroundColor="#D8E0E8" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="channelTitle" position="80,137" size="1500,70" font="Regular;49" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="meta" position="80,212" size="1470,44" font="Regular;27" foregroundColor="#F1F4F8" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="desc" position="80,272" size="1180,185" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="nowLabel" position="1650,450" size="190,42" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
<widget name="poster0" position="70,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="70,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<ePixmap position="82,916" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="poster1" position="450,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="450,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<ePixmap position="462,916" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="poster2" position="830,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="830,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<ePixmap position="842,916" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="poster3" position="1210,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1210,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<ePixmap position="1222,916" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="poster4" position="1590,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1590,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<ePixmap position="1602,916" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterRate0" position="82,916" size="58,34" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate1" position="462,916" size="58,34" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate2" position="842,916" size="58,34" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate3" position="1222,916" size="58,34" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate4" position="1602,916" size="58,34" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel0" position="146,905" size="183,55" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel1" position="526,905" size="183,55" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel2" position="906,905" size="183,55" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel3" position="1286,905" size="183,55" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel4" position="1666,905" size="183,55" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="selector" position="70,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_270x435.png" alphatest="blend" zPosition="8" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="80,1015" size="1760,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/vod_guide_r115.png" alphatest="blend" zPosition="6" />
</screen>'''

SERIES_DETAILS = '''<screen name="TiviMateE2SeriesDetails" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#11151d">
<widget name="backdrop" position="0,0" size="1920,1080" alphatest="blend" zPosition="0" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_overlay.png" alphatest="blend" zPosition="1" />
<widget name="title" position="80,65" size="1450,70" font="Regular;46" foregroundColor="#ffffff" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="rating" position="85,150" size="120,48" font="Regular;28" foregroundColor="#20242c" backgroundColor="#e8edf4" halign="center" valign="center" zPosition="3" />
<widget name="meta" position="230,150" size="1180,48" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="cast" position="85,220" size="1260,100" font="Regular;25" foregroundColor="#e7ebf1" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="desc" position="85,325" size="1260,190" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="seasonInfo" position="1450,565" size="390,52" font="Regular;29" foregroundColor="#ffffff" backgroundColor="#11151d" transparent="1" halign="right" zPosition="3" />
<widget name="episode0" position="80,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode1" position="440,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode2" position="800,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode3" position="1160,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode4" position="1520,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episodeLabel0" position="80,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel1" position="440,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel2" position="800,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel3" position="1160,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel4" position="1520,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeSelector" position="72,632" size="346,282" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_select.png" alphatest="blend" zPosition="5" />
<widget name="episodeInfo" position="85,925" size="1500,58" font="Regular;23" foregroundColor="#dce3eb" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="85,1005" size="1740,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_details_guide_r69.png" alphatest="blend" zPosition="5" />
</screen>'''

# Test74: keep Server Manager simple, use a calmer selected-row colour, and
# make both Edit screens match the manager panel proportions.
SERVER_MANAGER_SKIN = SERVER_MANAGER_SKIN.replace(
    'selectionBackgroundColor="#1E9FDF"',
    'selectionBackgroundColor="#17679E"'
)

_editor_old = """<eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />
    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />
    <widget name="config" position="520,312" size="660,350" font="Regular;28" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#3A3020" selectionForegroundColor="#FFFFFF" zPosition="4" />"""
_editor_new_xtream = """<eLabel position="455,252" size="1215,500" backgroundColor="#07121D" zPosition="2" />
    <eLabel position="463,260" size="1199,484" backgroundColor="#0D1C2A" zPosition="3" />
    <widget name="config" position="495,286" size="1135,410" font="Regular;34" itemHeight="58" foregroundColor="#F5F8FC" backgroundColor="#12385F" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#17679E" selectionForegroundColor="#FFFFFF" zPosition="4" />"""
_editor_new_stalker = _editor_new_xtream.replace('itemHeight="58"', 'itemHeight="70"')

XTREAM_EDITOR_SKIN = XTREAM_EDITOR_SKIN.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(_editor_old, _editor_new_xtream)

STALKER_EDITOR_SKIN = STALKER_EDITOR_SKIN.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(_editor_old, _editor_new_stalker)

# The XML uses a 1920x1080 design canvas.  Convert it once at import time
# when the active Enigma2 desktop is WQHD, before any Screen is constructed.
HOME_SKIN1 = scale_skin(HOME_SKIN1)
HOME_SKIN2 = scale_skin(HOME_SKIN2)
SEARCH_SCREEN = scale_skin(SEARCH_SCREEN)
SOURCE_MENU = scale_skin(SOURCE_MENU)
EDITOR = scale_skin(EDITOR)
XTREAM_EDITOR_SKIN = scale_skin(XTREAM_EDITOR_SKIN)
STALKER_EDITOR_SKIN = scale_skin(STALKER_EDITOR_SKIN)
SERVER_MANAGER_SKIN = scale_skin(SERVER_MANAGER_SKIN)

# Wide dark settings layout used by TMDb, matching the Server Manager content area.
TMDB_SETTINGS_SKIN = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="TMDbSettings"')
TMDB_SETTINGS_SKIN = TMDB_SETTINGS_SKIN.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(
    '<eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />\n'
    '    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />\n'
    '    <widget name="config" position="520,312" size="660,350" font="Regular;28" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#3A3020" selectionForegroundColor="#FFFFFF" zPosition="4" />',
    '<eLabel position="455,252" size="1215,500" backgroundColor="#07121D" zPosition="2" />\n'
    '    <eLabel position="463,260" size="1199,484" backgroundColor="#0D1C2A" zPosition="3" />\n'
    '    <widget name="config" position="495,286" size="1135,410" font="Regular;34" itemHeight="78" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#203648" selectionForegroundColor="#FFFFFF" zPosition="4" />'
)
LIVE_CLASSIC = scale_skin(LIVE_CLASSIC)

LIVE_STYLE_CHOICES = [
    ("تركوازي", "turquoise"),
    ("أزرق", "blue"),
    ("أخضر", "green"),
    ("ذهبي", "gold"),
    ("بنفسجي", "purple"),
    ("فضي", "silver"),
]

LIVE_STYLE_PALETTES = {
    "turquoise": {
        "accent": "#008F95", "bg": "#00101214", "panel": "#D8171A1C", "panel2": "#B8171A1C",
        "header": "#00131313", "line": "#263B40", "progress": "#00BFC7", "soft": "#B8DDE0",
    },
    "blue": {
        "accent": "#168CFF", "bg": "#000B1422", "panel": "#D8101A2B", "panel2": "#B80D1727",
        "header": "#00101D31", "line": "#244C78", "progress": "#168CFF", "soft": "#BBD8FF",
    },
    "green": {
        "accent": "#19C878", "bg": "#000C1712", "panel": "#D812211A", "panel2": "#B80E1C16",
        "header": "#0013231B", "line": "#285D45", "progress": "#19C878", "soft": "#BCEBD4",
    },
    "gold": {
        "accent": "#E5B243", "bg": "#0017130B", "panel": "#D8221B10", "panel2": "#B81D170D",
        "header": "#00261E10", "line": "#6B5525", "progress": "#E5B243", "soft": "#F2DEB0",
    },
    "purple": {
        "accent": "#935CFF", "bg": "#00120D1B", "panel": "#D81C1428", "panel2": "#B8171022",
        "header": "#0020152F", "line": "#5B3A86", "progress": "#935CFF", "soft": "#D8C4FF",
    },
    "silver": {
        "accent": "#E5E7EB", "bg": "#00121315", "panel": "#D81C1E21", "panel2": "#B8181A1D",
        "header": "#00232629", "line": "#5F666D", "progress": "#D8DDE2", "soft": "#E8EAED",
    },
}

def _live_skin_with_style(theme):
    theme = theme if theme in LIVE_STYLE_PALETTES else "turquoise"
    p = LIVE_STYLE_PALETTES[theme]
    skin = LIVE_CLASSIC
    replacements = {
        '#00101214': p['bg'],
        '#D8171A1C': p['panel'],
        '#B8171A1C': p['panel2'],
        '#00131313': p['header'],
        '#20262D': p['line'],
        '#6A6F75': p['line'],
        '#5A5A5A': p['line'],
        '#00B77A': p['progress'],
        '#008080': p['accent'],
        '#BFC7CF': p['soft'],
        '#D4D9DE': p['soft'],
    }
    for old, new in replacements.items():
        skin = skin.replace(old, new)
    return skin

VOD = scale_skin(VOD)
SERIES_DETAILS = scale_skin(SERIES_DETAILS)


class PlaylistEditor(Screen, ConfigListScreen):
    skin = XTREAM_EDITOR_SKIN

    def __init__(self, session, source=None, callback=None):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.callback = callback
        self.original = source or {}
        self["title"] = Label(tr("ADD XTREAM CODES PLAYLIST"))
        self["hint"] = Label("Playlist file: %s" % PLAYLISTS_FILE)
        self["keys"] = Label(tr("OK  KEYBOARD    GREEN  SAVE    RED  CANCEL"))
        self.provider = ConfigText(default=self.original.get("name", "IPTV"), fixed_size=False)
        self.protocol = ConfigSelection(default=self._protocol(), choices=[("http://", "http://"), ("https://", "https://")])
        host, port = self._host_port()
        self.server = ConfigText(default=host, fixed_size=False)
        self.port = ConfigText(default=port, fixed_size=False)
        self.username = ConfigText(default=self.original.get("username", ""), fixed_size=False)
        self.password = ConfigPassword(default=self.original.get("password", ""), fixed_size=False)
        self.output = ConfigSelection(default=self.original.get("output", "ts"), choices=[("ts", "TS"), ("m3u8", "M3U8")])
        self.epgOffset = ConfigSelection(default=str(self.original.get("epg_offset", "-1")), choices=[
            ("auto", "Auto (XMLTV timezone)"), ("0", "No correction"),
            ("-2", "-2 hours"), ("-1", "-1 hour"),
            ("1", "+1 hour"), ("2", "+2 hours")
        ])
        poster_raw = self.original.get("show_live_poster", False)
        poster_enabled = str(poster_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.livePoster = ConfigYesNo(default=bool(poster_enabled))
        entries = [
            getConfigListEntry(tr("Playlist Name"), self.provider),
            getConfigListEntry(tr("Protocol"), self.protocol),
            getConfigListEntry(tr("Server URL"), self.server),
            getConfigListEntry(tr("Port"), self.port),
            getConfigListEntry(tr("Username"), self.username),
            getConfigListEntry(tr("Password"), self.password),
            getConfigListEntry(tr("Stream Format"), self.output),
            getConfigListEntry(tr("EPG Time Offset"), self.epgOffset),
            getConfigListEntry(tr(u"★ TMDb Poster in Live"), self.livePoster),
        ]
        ConfigListScreen.__init__(self, entries, session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.openKeyboard, "green": self.save, "red": self.close, "cancel": self.close,
            "left": self.keyLeft, "right": self.keyRight
        }, -1)

    def keyLeft(self):
        try:
            ConfigListScreen.keyLeft(self)
        except Exception:
            pass

    def keyRight(self):
        try:
            ConfigListScreen.keyRight(self)
        except Exception:
            pass

    def _protocol(self):
        return "https://" if self.original.get("url", "").startswith("https://") else "http://"

    def _host_port(self):
        url = self.original.get("url", "").replace("http://", "").replace("https://", "").rstrip("/")
        return tuple(url.rsplit(":", 1)) if ":" in url else (url, "")

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if not current:
            return
        cfg = current[1]
        if cfg is self.livePoster:
            try:
                cfg.value = not bool(cfg.value)
                cfg.changed()
            except Exception:
                return
            try:
                self["config"].invalidateCurrent()
            except Exception:
                pass
            return
        if not isinstance(cfg, (ConfigText, ConfigPassword)):
            return
        self.session.openWithCallback(self.keyboardCallback, VirtualKeyBoard, title=current[0], text=cfg.value or "")

    def keyboardCallback(self, value=None):
        if value is None:
            return
        current = self["config"].getCurrent()
        if current:
            current[1].value = value
            self["config"].invalidateCurrent()

    def save(self):
        host = (self.server.value or "").strip().replace("http://", "").replace("https://", "").rstrip("/")
        port = (self.port.value or "").strip()
        if not host or not self.username.value or not self.password.value:
            return self.session.open(MessageBox, "Enter the server URL, username, and password.", MessageBox.TYPE_ERROR)
        url = self.protocol.value + host + ((":" + port) if port else "")
        src = dict(self.original or {})
        src.update({
            "type": "xtream", "name": self.provider.value or "IPTV", "url": url,
            "username": self.username.value, "password": self.password.value,
            "output": self.output.value, "epg_offset": self.epgOffset.value,
            "show_live_poster": bool(self.livePoster.value)
        })
        self.close(src)


class SourceTypePicker(Screen):
    """Choose a source type before opening the matching editor."""
    skin = SOURCE_MENU

    def __init__(self, session):
        Screen.__init__(self, session)
        self["brand"] = Label(tr("TiViMate"))
        self["side"] = MenuList([])
        self["title"] = Label(tr("ADD A SOURCE"))
        self["subtitle"] = Label(tr("Choose the type of IPTV connection"))
        self["menu"] = MenuList([
            ("Xtream Codes", "xtream"),
            ("Stalker Portal  •  Live, Movies & TV Shows", "stalker"),
        ])
        self["info"] = Label(tr("Stalker requires your own Portal URL and MAG MAC address. No portal is included."))
        self["keys"] = Label(tr("OK SELECT    EXIT BACK"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.choose, "cancel": self.close,
            "up": self["menu"].up, "down": self["menu"].down
        }, -1)

    def choose(self):
        current = self["menu"].getCurrent()
        if current:
            self.close(current[1])


class StalkerPortalEditor(Screen, ConfigListScreen):
    """Private local editor for a user-supplied Stalker/Ministra VOD portal."""
    skin = STALKER_EDITOR_SKIN

    def __init__(self, session, source=None, callback=None):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.callback = callback
        self.original = source or {}
        self["title"] = Label(tr("STALKER PORTAL  •  LIVE, MOVIES & TV SHOWS"))
        self["hint"] = Label(tr("Enter your own Portal URL and MAG MAC address. No portal or account is bundled with TiViMate."))
        self["keys"] = Label(tr("OK  KEYBOARD    GREEN  SAVE    RED  CANCEL"))
        self.provider = ConfigText(default=self.original.get("name", "Stalker Portal"), fixed_size=False)
        self.portal = ConfigText(default=self.original.get("url", ""), fixed_size=False)
        self.mac = ConfigText(default=self.original.get("mac", ""), fixed_size=False)
        self.epgOffset = ConfigSelection(default=str(self.original.get("epg_offset", "auto")), choices=[
            ("auto", "Auto (portal/XMLTV timezone)"), ("0", "No correction"),
            ("-2", "-2 hours"), ("-1", "-1 hour"),
            ("1", "+1 hour"), ("2", "+2 hours")
        ])
        poster_raw = self.original.get("show_live_poster", False)
        poster_enabled = str(poster_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.livePoster = ConfigYesNo(default=bool(poster_enabled))
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Portal Name"), self.provider),
            getConfigListEntry(tr("Portal URL"), self.portal),
            getConfigListEntry(tr("MAG MAC Address"), self.mac),
            getConfigListEntry(tr("EPG Time Offset"), self.epgOffset),
            getConfigListEntry(tr(u"★ TMDb Poster in Live"), self.livePoster),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.openKeyboard, "green": self.save, "red": self.close, "cancel": self.close,
            "left": self.keyLeft, "right": self.keyRight
        }, -1)

    def keyLeft(self):
        try:
            ConfigListScreen.keyLeft(self)
        except Exception:
            pass

    def keyRight(self):
        try:
            ConfigListScreen.keyRight(self)
        except Exception:
            pass

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if not current:
            return
        cfg = current[1]
        if cfg is self.livePoster:
            try:
                cfg.value = not bool(cfg.value)
                cfg.changed()
            except Exception:
                return
            try:
                self["config"].invalidateCurrent()
            except Exception:
                pass
            return
        if not isinstance(cfg, ConfigText):
            return
        self.session.openWithCallback(self.keyboardCallback, VirtualKeyBoard, title=current[0], text=cfg.value or "")

    def keyboardCallback(self, value=None):
        if value is None:
            return
        current = self["config"].getCurrent()
        if current:
            current[1].value = value
            self["config"].invalidateCurrent()

    def _normalisePortal(self):
        portal = (self.portal.value or "").strip().rstrip("/")
        if portal and "://" not in portal:
            portal = "http://" + portal
        return portal

    def _normaliseMac(self):
        return (self.mac.value or "").strip().upper().replace("-", ":")

    def save(self):
        portal = self._normalisePortal()
        mac = self._normaliseMac()
        valid_portal = portal.startswith("http://") or portal.startswith("https://")
        parts = mac.split(":")
        try:
            valid_mac = len(parts) == 6 and all(len(part) == 2 and int(part, 16) >= 0 for part in parts)
        except Exception:
            valid_mac = False
        if not valid_portal or not valid_mac:
            return self.session.open(MessageBox, "Enter a valid Portal URL and a MAG MAC address in the format 00:1A:79:12:34:56.", MessageBox.TYPE_ERROR)
        src = dict(self.original or {})
        src.update({
            "type": "stalker",
            "name": (self.provider.value or "Stalker Portal").strip() or "Stalker Portal",
            "url": portal,
            "mac": mac,
            "epg_offset": self.epgOffset.value,
            "show_live_poster": bool(self.livePoster.value)
        })
        self.close(src)


class TMDbSettings(Screen, ConfigListScreen):
    skin = TMDB_SETTINGS_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = load_tmdb_settings()
        self["title"] = Label(tr("TMDb TRENDING SETTINGS"))
        self["hint"] = Label(tr("Enter a TMDb API key. Trending metadata comes from TMDb; playback uses the selected server."))
        self["keys"] = Label("OK KEYBOARD    GREEN SAVE    BLUE TEST    RED CANCEL")
        self.mode = ConfigSelection(default=cfg.get("mode", "auto"), choices=[
            ("auto", "Auto (Token, then API Key)"),
            ("v3", "API Key v3"),
            ("v4", "Read Access Token v4"),
            ("disabled", "Disabled"),
        ])
        self.apiKey = ConfigPassword(default=cfg.get("api_key", ""), fixed_size=False)
        self.apiKey2 = ConfigPassword(default=cfg.get("api_key2", ""), fixed_size=False)
        self.accessToken = ConfigPassword(default=cfg.get("access_token", ""), fixed_size=False)
        self.language = ConfigSelection(default=cfg.get("language_setting", cfg.get("language", "auto")), choices=[("auto", "Device language (Auto)"), ("en-US", "English"), ("ar-AE", "Arabic")])
        ConfigListScreen.__init__(self, [
            getConfigListEntry("TMDb Mode", self.mode),
            getConfigListEntry("TMDb API Key 1", self.apiKey),
            getConfigListEntry("TMDb API Key 2", self.apiKey2),
            getConfigListEntry("Read Access Token v4", self.accessToken),
            getConfigListEntry(tr("Metadata language"), self.language),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.openKeyboard, "green": self.save, "blue": self.testConnection,
            "red": self.close, "cancel": self.close
        }, -1)

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if current and isinstance(current[1], ConfigText):
            self.session.openWithCallback(self.keyboardDone, VirtualKeyBoard, title=current[0], text=current[1].value or "")

    def keyboardDone(self, value=None):
        if value is None: return
        current = self["config"].getCurrent()
        if current:
            current[1].value = value
            self["config"].invalidateCurrent()

    def _credentialsValid(self):
        mode = self.mode.value
        if mode == "disabled":
            return True
        if mode == "v3":
            return bool((self.apiKey.value or "").strip() or (self.apiKey2.value or "").strip())
        if mode == "v4":
            return bool((self.accessToken.value or "").strip())
        return bool((self.apiKey.value or "").strip() or (self.apiKey2.value or "").strip() or (self.accessToken.value or "").strip())

    def save(self):
        if not self._credentialsValid():
            return self.session.open(MessageBox, "Enter the credential required by the selected TMDb mode.", MessageBox.TYPE_ERROR)
        if save_tmdb_settings(self.apiKey.value, self.language.value, self.mode.value, self.accessToken.value, self.apiKey2.value):
            self.session.open(MessageBox, "TMDb settings saved.", MessageBox.TYPE_INFO, timeout=4)
            self.close()
        else:
            self.session.open(MessageBox, "Unable to save settings.", MessageBox.TYPE_ERROR)

    def testConnection(self):
        if not self._credentialsValid():
            return self.session.open(MessageBox, "Enter the credential required by the selected TMDb mode.", MessageBox.TYPE_ERROR)
        self["hint"].setText("Testing TMDb connection...")
        mode = self.mode.value
        key = self.apiKey.value
        token = self.accessToken.value
        key2 = self.apiKey2.value
        language = self.language.value
        def worker():
            ok, message = False, ""
            try:
                client = TMDbClient(api_key=key, api_key2=key2, access_token=token, mode=mode,
                    language=None if language == "auto" else language)
                client._get("/configuration", {})
                ok, message = True, "TMDb connection successful."
            except Exception as exc:
                message = "TMDb connection failed: %s" % exc
            def done():
                try:
                    self["hint"].setText(message)
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR, timeout=6)
                except Exception:
                    pass
            try:
                reactor.callFromThread(done) if reactor is not None else done()
            except Exception:
                done()
        t = threading.Thread(target=worker, name="TiviMateTMDbTest")
        t.daemon = True
        t.start()


class ServerCategoryFilter(Screen):
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="ServerCategoryFilter"').replace(
        '    <eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />\n    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />\n    <widget name="config" position="520,312" size="660,350" font="Regular;28" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#3A3020" selectionForegroundColor="#FFFFFF" zPosition="4" />',
        '    <eLabel position="430,220" size="1260,620" backgroundColor="#081A2E" zPosition="2" />\n    <eLabel position="438,228" size="1244,604" backgroundColor="#12385F" zPosition="3" />\n    <widget name="config" position="470,255" size="1180,550" font="Regular;32" itemHeight="72" foregroundColor="#FFFFFF" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#3A3020" selectionForegroundColor="#FFFFFF" zPosition="5" />'
    ).replace('settings_guide_keyboard_save_r69.png', 'settings_guide_filter_r69.png')
    ALL_KINDS = [("live", "LIVE TV"), ("vod", "MOVIES"), ("series", "TV SHOWS")]

    def __init__(self, session, source):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.source = source or {}
        # M3U and portal profiles expose a generic LIVE catalogue.  Keep the
        # familiar VOD/series filters for Xtream, while allowing the same LIVE
        # bouquet selector to work for every supported source.
        if self.source.get("type") in ("stalker", "xtream"):
            self.KINDS = list(self.ALL_KINDS)
        else:
            self.KINDS = [("live", "LIVE TV")]
        self.kindIndex = 0
        self.rows = []
        self.selected = {}
        self.loaded = {}
        self["title"] = Label(tr("SERVER CONTENT FILTER"))
        self["config"] = MenuList([])
        self["hint"] = Label(tr("Load only the categories you need to keep lists, search, and images fast."))
        self["keys"] = Label(tr("LEFT/RIGHT  SECTION    OK  TOGGLE    GREEN  SAVE    YELLOW  SELECT ALL    BLUE  CLEAR ALL    EXIT  BACK"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.toggle, "cancel": self.close, "green": self.save,
            "yellow": self.selectAll, "blue": self.clearAll,
            "left": self.prevKind, "right": self.nextKind,
            "up": self["config"].up, "down": self["config"].down
        }, -1)
        self.onLayoutFinish.append(self.loadCurrent)

    def _kind(self):
        return self.KINDS[self.kindIndex][0]

    def loadCurrent(self):
        kind, label = self.KINDS[self.kindIndex]
        self["title"].setText("SERVER FILTER  •  %s" % label)
        self["hint"].setText("Loading %s categories..." % label)
        try:
            source_type = self.source.get("type")
            if source_type == "xtream":
                cats = XtreamClient(self.source).categories(kind) or []
                candidates = [(cat.get("category_id", ""), cat.get("category_name") or "Other") for cat in cats]
            elif source_type == "stalker":
                cats = StalkerClient(self.source).categories(kind) or []
                candidates = [(cat.get("category_id", ""), cat.get("category_name") or "Other") for cat in cats]
            else:
                entries = M3UClient(self.source).entries() or []
                candidates = [(entry.get("group", "Other"), entry.get("group", "Other")) for entry in entries]
            clean = []
            seen = set()
            for raw_id, raw_name in candidates:
                cid = str(raw_id or "").strip()
                if not cid or cid in seen:
                    continue
                seen.add(cid)
                clean.append({"id": cid, "name": str(raw_name or "Other").strip()})
            self.loaded[kind] = clean
            if kind not in self.selected:
                configured = get_allowed_category_ids(self.source, kind)
                self.selected[kind] = set(x["id"] for x in clean) if configured is None else set(configured)
            self.render()
        except Exception as exc:
            self.rows = []
            self["config"].setList([])
            self["hint"].setText("Unable to load categories: %s" % exc)

    def render(self):
        kind, label = self.KINDS[self.kindIndex]
        selected = self.selected.get(kind, set())
        self.rows = self.loaded.get(kind, [])
        rows = [("[%s]  %s" % ("✓" if x["id"] in selected else " ", x["name"]), x["id"]) for x in self.rows]
        self["config"].setList(rows)
        self["hint"].setText("%s: %d of %d enabled" % (label, len(selected), len(self.rows)))

    def toggle(self):
        current = self["config"].getCurrent()
        if not current:
            return
        kind = self._kind()
        cid = str(current[1])
        selected = self.selected.setdefault(kind, set())
        if cid in selected:
            selected.remove(cid)
        else:
            selected.add(cid)
        idx = self["config"].getSelectedIndex()
        self.render()
        try: self["config"].moveToIndex(idx)
        except Exception: pass

    def selectAll(self):
        kind = self._kind()
        self.selected[kind] = set(x["id"] for x in self.loaded.get(kind, []))
        self.render()

    def clearAll(self):
        self.selected[self._kind()] = set()
        self.render()

    def prevKind(self):
        self.kindIndex = (self.kindIndex - 1) % len(self.KINDS)
        self.loadCurrent()

    def nextKind(self):
        self.kindIndex = (self.kindIndex + 1) % len(self.KINDS)
        self.loadCurrent()

    def save(self):
        data = _load_all_filters()
        key = _source_filter_key(self.source)
        entry = dict(data.get(key, {}) or {})
        for kind, _label in self.KINDS:
            if kind not in self.selected:
                continue
            selected = set(str(x) for x in self.selected.get(kind, set()))
            available = set(str(x.get("id") or "") for x in self.loaded.get(kind, []))
            # Selecting every category is identical to an unfiltered catalogue.
            # Store no per-category restriction in that case, so the normal
            # aggregate cache is reused instead of downloading each category.
            if available and selected == available:
                entry.pop(kind, None)
            else:
                entry[kind] = sorted(selected)
        if entry:
            data[key] = entry
        else:
            data.pop(key, None)
        if _save_all_filters(data):
            # Newly enabled, cold categories are warmed in the background.  The
            # setting screen closes straight away, and the cached list appears
            # without a synchronous full refresh on the next screen.
            try:
                prefetch_selected_categories(self.source, entry)
            except Exception:
                pass
            # Rebuild only this server's EPG cache and refresh EPGImport channel
            # mappings after a package filter change. Both tasks run in the
            # background; Live playback never performs this work.
            try:
                from .epg_local import refresh_source_epg
                refresh_source_epg(self.source, force=True, background=True)
            except Exception:
                pass
            try:
                from .epgimport_sync import sync_epgimport_sources
                sync_epgimport_sources(get_sources(), background=True)
            except Exception:
                pass
            self.session.open(MessageBox, "Packages saved. EPG for selected packages is updating in the background.", MessageBox.TYPE_INFO)
            self.close(True)
        else:
            self.session.open(MessageBox, "Unable to save the filter.", MessageBox.TYPE_ERROR)


class ImageCacheSettings(Screen, ConfigListScreen):
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="ImageCacheSettings"').replace('settings_guide_keyboard_save_r69.png', 'settings_guide_cache_r69.png')

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = get_cache_settings()
        self["title"] = Label(tr("IMAGE CACHE"))
        self["hint"] = Label("")
        self["keys"] = Label(tr("GREEN  SAVE    BLUE  CLEAR CACHE    YELLOW  CLEAN UP    EXIT  BACK"))
        self.location = ConfigSelection(default=str(cfg.get("location", "auto")), choices=[
            ("auto", "Auto: HDD, then USB"),
            ("hdd", "HDD /media/hdd"),
            ("usb", "USB /media/usb"),
            ("mmc", "MMC /media/mmc"),
            ("tmp", "Temporary /tmp"),
        ])
        self.retention = ConfigSelection(default=str(cfg.get("retention_days", 0)), choices=[
            ("0", "Unlimited — Never delete automatically"),
            ("7", "7 days"), ("14", "14 days"), ("30", "30 days"),
            ("60", "60 days"), ("90", "90 days")
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Cache Location"), self.location),
            getConfigListEntry(tr("Automatic Deletion"), self.retention),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "blue": self.clearNow, "yellow": self.cleanNow,
            "red": self.close, "cancel": self.close
        }, -1)
        self.onLayoutFinish.append(self.updateHint)

    def updateHint(self):
        root, size, files = cache_status()
        self["hint"].setText("Current location: %s  •  %.1f MB  •  %d files" % (root, size / 1048576.0, files))

    def save(self):
        if save_cache_settings(self.location.value, 0, int(self.retention.value)):
            cleanup_cache()
            self.updateHint()
            self.session.open(MessageBox, "Cache settings saved. New images will use the selected location.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save cache settings.", MessageBox.TYPE_ERROR)

    def clearNow(self):
        if clear_cache():
            try:
                clear_catalog_memory()
            except Exception:
                pass
            self.updateHint()
            self.session.open(MessageBox, "Image and list cache cleared.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to clear image cache.", MessageBox.TYPE_ERROR)

    def cleanNow(self):
        cleanup_cache()
        self.updateHint()
        self.session.open(MessageBox, "Image cache cleaned according to the selected number of days. Unlimited keeps all files.", MessageBox.TYPE_INFO)


class HomeAppearanceSettings(Screen, ConfigListScreen):
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="HomeAppearanceSettings"').replace('settings_guide_keyboard_save_r69.png', 'settings_guide_save_back_r69.png')

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        current = _load_home_appearance()
        self.homeSkin = ConfigSelection(default=current.get("skin", "skin2_dark"), choices=[
            ("reference_home", "Skin 1 — Reference Home"),
            ("skin2_dark", "Skin 2 — Cinematic Home (Default)"),
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Home Skin"), self.homeSkin)
        ], session=session)
        self["title"] = Label(tr("HOME APPEARANCE"))
        self["hint"] = Label(tr("Changes apply to the Home screen only. Restart the app after saving."))
        self["keys"] = Label(tr("GREEN  SAVE    RED  BACK"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "ok": self.save, "red": self.close, "cancel": self.close
        }, -1)

    def save(self):
        if _save_home_appearance(self.homeSkin.value):
            self.session.open(MessageBox, "Home skin saved. Close and reopen the app to apply the design.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save appearance setting.", MessageBox.TYPE_ERROR)


class UpdateSettingsScreen(Screen, ConfigListScreen):
    """Settings and user-confirmed manual update flow for verified packages."""
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="UpdateSettingsScreen"').replace('settings_guide_keyboard_save_r69.png', 'settings_guide_save_back_r69.png')

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = _load_update_settings()
        self.autoCheck = ConfigSelection(default="on" if cfg.get("auto_check", True) else "off", choices=[
            ("on", "On"), ("off", "Off")
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Automatic update check"), self.autoCheck)
        ], session=session)
        self["title"] = Label(tr("SOFTWARE UPDATES"))
        self["hint"] = Label(tr("Automatic checks only read a small verified update manifest. Press YELLOW to check now."))
        self["keys"] = Label(tr("GREEN  SAVE    YELLOW  CHECK NOW    RED  BACK"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "yellow": self.manualCheck, "ok": self.save,
            "red": self.close, "cancel": self.close
        }, -1)
        self._checkPending = None
        self._downloadPending = None
        self._candidate = None
        self._installProcess = None
        self._checkInProgress = False
        self._downloadInProgress = False
        self._checkTimer = eTimer()
        self._downloadTimer = eTimer()
        try:
            self._checkTimer.callback.append(self._pollCheck)
        except Exception:
            self._checkTimer.timeout.get().append(self._pollCheck)
        try:
            self._downloadTimer.callback.append(self._pollDownload)
        except Exception:
            self._downloadTimer.timeout.get().append(self._pollDownload)
        self.onClose.append(self._stopTimers)

    def _stopTimers(self):
        for timer in (getattr(self, "_checkTimer", None), getattr(self, "_downloadTimer", None)):
            try:
                timer.stop()
            except Exception:
                pass

    def save(self):
        enabled = self.autoCheck.value == "on"
        if _save_update_settings(enabled):
            state = "enabled" if enabled else "disabled"
            self["hint"].setText("Automatic update checks are %s. Press YELLOW to check now." % state)
            self.session.open(MessageBox, "Update settings saved.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save update settings.", MessageBox.TYPE_ERROR)

    def manualCheck(self):
        if self._checkInProgress or self._downloadInProgress or self._installProcess:
            return
        self._checkInProgress = True
        self._checkPending = None
        self["hint"].setText(tr("Checking for a verified update..."))

        def worker():
            try:
                self._checkPending = check_for_update()
            except Exception:
                self._checkPending = {}

        try:
            thread = threading.Thread(target=worker, name="TiviMateManualUpdateCheck")
            thread.daemon = True
            thread.start()
            self._checkTimer.start(200, True)
        except Exception:
            self._checkPending = {}
            self._pollCheck()

    def _pollCheck(self):
        if self._checkPending is None:
            try:
                self._checkTimer.start(200, True)
            except Exception:
                pass
            return
        result = self._checkPending or {}
        self._checkPending = None
        self._checkInProgress = False
        if not result.get("available"):
            if result.get("reason") == "current":
                self["hint"].setText(tr("TiViMate E2 is already up to date."))
                self.session.open(MessageBox, "No update is available. TiViMate E2 is already up to date.", MessageBox.TYPE_INFO)
            else:
                self["hint"].setText(tr("Unable to verify updates right now. You can try again later."))
                self.session.open(MessageBox, "Unable to check for updates. Please try again later.", MessageBox.TYPE_ERROR)
            return
        self._candidate = result
        version = result.get("version") or "1.0.3"
        revision = result.get("revision") or "?"
        notes = result.get("notes") or ""
        text = "A verified TiviMate E2 update is available.\n\nVersion: %s (revision %s)" % (version, revision)
        if notes:
            text += "\n\n" + notes
        text += "\n\nDownload and install it now?"
        self.session.openWithCallback(self._confirmUpdate, MessageBox, text, type=MessageBox.TYPE_YESNO, default=False)

    def _confirmUpdate(self, answer):
        if not answer or not self._candidate:
            return
        package = self._candidate.get("package")
        if not package:
            return
        self._downloadInProgress = True
        self._downloadPending = None
        self["hint"].setText(tr("Downloading and verifying the update package..."))

        def worker():
            self._downloadPending = download_package(package)

        try:
            thread = threading.Thread(target=worker, name="TiviMateManualUpdateDownload")
            thread.daemon = True
            thread.start()
            self._downloadTimer.start(200, True)
        except Exception:
            self._downloadPending = {"ok": False, "message": "Unable to start download"}
            self._pollDownload()

    def _pollDownload(self):
        if self._downloadPending is None:
            try:
                self._downloadTimer.start(200, True)
            except Exception:
                pass
            return
        result = self._downloadPending or {}
        self._downloadPending = None
        self._downloadInProgress = False
        if not result.get("ok"):
            self["hint"].setText(tr("Update download failed."))
            return self.session.open(MessageBox, "Update download failed.\n\n%s" % (result.get("message") or "Please try again later."), MessageBox.TYPE_ERROR)
        command = install_command(result)
        if not command:
            self["hint"].setText(tr("The verified package could not be installed."))
            return self.session.open(MessageBox, "The verified update package could not be installed.", MessageBox.TYPE_ERROR)
        self["hint"].setText(tr("Installing TiViMate E2 update..."))
        try:
            process = eConsoleAppContainer()
            self._installProcess = process
            try:
                process.appClosed.append(self._installFinished)
            except Exception:
                process.appClosed.get().append(self._installFinished)
            process.execute("/bin/sh", "sh", "-c", command)
        except Exception:
            self["hint"].setText(tr("Unable to start the update installer."))
            self.session.open(MessageBox, "Unable to start the update installer.", MessageBox.TYPE_ERROR)

    def _installFinished(self, status):
        self._installProcess = None
        if status == 0:
            self["hint"].setText(tr("Update completed. Restart the Enigma2 GUI to use the new version."))
            self.session.open(MessageBox, "TiViMate E2 was updated successfully.\n\nPlease restart the Enigma2 GUI to use the new version.", MessageBox.TYPE_INFO)
        else:
            self["hint"].setText(tr("The update installer returned an error."))
            self.session.open(MessageBox, "The update installer returned an error. Your current installation has not been changed.", MessageBox.TYPE_ERROR)


class SubDLSubtitleLanguageSettings(Screen, ConfigListScreen):
    """Default download language for the YELLOW SubDL subtitle action."""
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="SubDLSubtitleLanguageSettings"').replace(
        'settings_guide_keyboard_save_r69.png', 'settings_guide_save_back_r69.png'
    )

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        current = load_subdl_settings()
        self.targetLanguage = ConfigSelection(
            default=current.get("language", "ar"),
            choices=SUBDL_LANGUAGE_CHOICES,
        )
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Download SubDL subtitles in"), self.targetLanguage),
        ], session=session)
        self["title"] = Label(tr("SUBDL SUBTITLE LANGUAGE"))
        self["hint"] = Label(tr(
            "This language is used by the YELLOW SubDL button. Import the SubDL API key separately from Server Manager."
        ))
        self["keys"] = Label(tr("GREEN  SAVE    RED  BACK"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "ok": self.save, "red": self.close, "cancel": self.close,
        }, -1)

    def save(self):
        try:
            current = load_subdl_settings()
            save_subdl_settings(
                current.get("api_key", ""),
                self.targetLanguage.value,
                current.get("kind", "standard"),
            )
            self.close(True)
        except Exception:
            self.session.open(MessageBox, "Could not save the SubDL subtitle language.", MessageBox.TYPE_ERROR, timeout=5)


class ServerStatusList(MenuList):
    """MenuList that preserves source rows while drawing a local health dot.

    The source dictionary remains the first element of every row, so ServerManager
    keeps the same selection, scrolling, action-key and source-editing behaviour.
    """
    STATUS_PIXMAPS = {
        "online": os.path.join(PLUGIN_PATH, "skins/server_status_online_r123.png"),
        "busy": os.path.join(PLUGIN_PATH, "skins/server_status_busy_r123.png"),
        "checking": os.path.join(PLUGIN_PATH, "skins/server_status_checking_r123.png"),
        "offline": os.path.join(PLUGIN_PATH, "skins/server_status_offline_r123.png"),
    }

    def __init__(self):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 34))
            self.l.setItemHeight(88)
        except Exception:
            pass
        self._pixmaps = {}
        for name, path in self.STATUS_PIXMAPS.items():
            try:
                self._pixmaps[name] = LoadPixmap(path)
            except Exception:
                self._pixmaps[name] = None

    def setSources(self, sources, states):
        rows = [self._makeRow(source, states.get(self._key(source), "checking")) for source in sources]
        self.setList(rows)

    @staticmethod
    def _key(source):
        endpoint = source.get("url") or source.get("host") or source.get("server") or source.get("portal") or ""
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("name", ""), endpoint, source.get("username", ""))

    def _makeRow(self, source, state):
        title = "%s  •  %s" % (source.get("name", "SERVER"), source.get("type", "").upper())
        pixmap = self._pixmaps.get(state) or self._pixmaps.get("checking")
        return [source,
            MultiContentEntryPixmapAlphaBlend(pos=(0, 8), size=(1000, 78), png=LoadPixmap(os.path.join(PLUGIN_PATH, "skins/server_row_r67.png"))),
            MultiContentEntryPixmapAlphaBlend(pos=(24, 28), size=(32, 32), png=pixmap),
            MultiContentEntryText(pos=(76, 0), size=(900, 88), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=title,
                color=0x00F5F8FC, color_sel=0x00FFFFFF)]


class ServerManager(Screen):
    skin = SERVER_MANAGER_SKIN
    NAV_X = [450, 603, 756, 909, 1062, 1215]

    def __init__(self, session, selectCallback=None):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        self.selectCallback = selectCallback
        self.sources = []
        self._serverStates = {}
        self._statusResult = None
        self._statusToken = 0
        self._statusClosed = False
        self.settingsFocus = "list"
        self.settingsNavIndex = 5
        self.languageIndex = {"en": 0, "ar": 1, "fr": 2}.get(get_language(), 0)
        self["title"] = Label(tr("SETTINGS  •  SERVER MANAGER"))
        self["config"] = ServerStatusList()
        self["languageTitle"] = Label(tr("APPLICATION LANGUAGE"))
        self["languageSelector"] = Pixmap()
        self["language0"] = Label(tr("English"))
        self["language1"] = Label(tr("Arabic"))
        self["language2"] = Label(tr("French"))
        self["languageRadio0"] = Pixmap()
        self["languageRadio1"] = Pixmap()
        self["languageRadio2"] = Pixmap()
        self["serverStatusTitle"] = Label(tr("SERVER STATUS  •  CONNECTION & ACTIVE USE"))
        self["serverStatusText"] = Label(tr("Yellow appears only when the server reports active use."))
        self["statusLegendOnlineIcon"] = Pixmap()
        self["statusLegendOnline"] = Label(tr("ONLINE"))
        self["statusLegendCheckingIcon"] = Pixmap()
        self["statusLegendChecking"] = Label(tr("IN USE"))
        self["statusLegendOfflineIcon"] = Pixmap()
        self["statusLegendOffline"] = Label(tr("OFFLINE"))
        self["hint"] = Label(tr("Press 5 SUBDL for API key import, subtitle language or font. Press 3 for Updates."))
        self["keys"] = Label("")
        self._statusTimer = eTimer()
        try:
            self._statusTimer.callback.append(self._finishStatusRefresh)
        except Exception:
            self._statusTimer.timeout.get().append(self._finishStatusRefresh)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "NumberActions"], {
            "ok": self.ok, "cancel": self.close, "green": self.addSource,
            "yellow": self.editSource, "red": self.delSource, "blue": self.testSource,
            "menu": self.openTMDb, "0": self.openFilter, "1": self.openCacheSettings, "2": self.openAppearanceSettings, "3": self.openUpdateSettings, "5": self.openSubDLSettingsMenu,
            "up": self.up, "down": self.down, "left": self.left, "right": self.right
        }, -1)
        self.onLayoutFinish.append(self._settingsLayoutReady)
        self.onLayoutFinish.append(self._startStatusRefresh)
        self.onClose.append(self._stopStatusRefresh)
        self.reload()

    def _settingsLayoutReady(self):
        self._statusReady = True
        try:
            self["settingsActionButtons"].show()
        except Exception:
            pass
        self._updateSettingsFocus()

    def _updateSettingsFocus(self):
        try:
            if self["settingsNavSelector"].instance:
                self["settingsNavSelector"].instance.move(ePoint(sx(self.NAV_X[self.settingsNavIndex]), sy(27)))
            self["settingsNavSelector"].show() if self.settingsFocus == "nav" else self["settingsNavSelector"].hide()
        except Exception:
            pass
        try:
            if self["languageSelector"].instance:
                self["languageSelector"].instance.move(ePoint(sx(124), sy(492 + (self.languageIndex * 64))))
            self["languageSelector"].show() if self.settingsFocus == "language" else self["languageSelector"].hide()
            radio_on = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/language_radio_on_r64.png"))
            radio_off = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/language_radio_off_r64.png"))
            for i in range(3):
                widget = self["languageRadio%d" % i]
                if widget.instance:
                    widget.instance.setPixmap(radio_on if i == self.languageIndex else radio_off)
        except Exception:
            pass

    def up(self):
        if self.settingsFocus == "language":
            self.languageIndex = (self.languageIndex - 1) % 3
        elif self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex - 1) % len(self.NAV_X)
        else:
            try:
                at_top = self["config"].getSelectedIndex() <= 0
            except Exception:
                at_top = True
            if at_top:
                self.settingsFocus = "nav"
            else:
                self["config"].up()
        self._updateSettingsFocus()

    def down(self):
        if self.settingsFocus == "language":
            self.languageIndex = (self.languageIndex + 1) % 3
        elif self.settingsFocus == "nav":
            self.settingsFocus = "list"
        else:
            self["config"].down()
        self._updateSettingsFocus()

    def left(self):
        if self.settingsFocus == "list":
            self.settingsFocus = "language"
        elif self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex - 1) % len(self.NAV_X)
        self._updateSettingsFocus()

    def right(self):
        if self.settingsFocus == "language":
            self.settingsFocus = "list"
        elif self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex + 1) % len(self.NAV_X)
        self._updateSettingsFocus()

    def ok(self):
        if self.settingsFocus == "language":
            code = ("en", "ar", "fr")[self.languageIndex]
            if save_language(code):
                return self.session.open(MessageBox, tr("Language saved. Reopen the app to apply it."), MessageBox.TYPE_INFO, timeout=5)
            return self.session.open(MessageBox, tr("Unable to save settings."), MessageBox.TYPE_ERROR)
        if self.settingsFocus == "nav":
            return self.openTopMenu()
        return self.select()

    def openTopMenu(self):
        index = self.settingsNavIndex
        if index == 5:
            self.settingsFocus = "list"
            return self._updateSettingsFocus()
        source = self.current()
        if index == 1:
            return self.session.open(TiviMateE2Home)
        if not source:
            return self.session.open(MessageBox, "Select a server first.", MessageBox.TYPE_INFO)
        if index == 0:
            return self.session.open(TiviMateE2Search, source)
        if index == 2 and source.get("type") in ("xtream", "stalker", "m3u"):
            return self.session.open(MediaScreen, source, "live")
        if index == 3 and source.get("type") in ("xtream", "stalker"):
            return self.session.open(ContentHomeScreen, source, "vod")
        if index == 4 and source.get("type") in ("xtream", "stalker"):
            return self.session.open(ContentHomeScreen, source, "series")
        return self.session.open(MessageBox, "The selected source does not provide this section.", MessageBox.TYPE_INFO)

    def openTMDb(self):
        self.session.open(TMDbSettings)

    def openCacheSettings(self):
        self.session.open(ImageCacheSettings)

    def openAppearanceSettings(self):
        self.session.open(HomeAppearanceSettings)

    def openUpdateSettings(self):
        self.session.open(UpdateSettingsScreen)

    def openSubDLSubtitleLanguage(self):
        self.session.open(SubDLSubtitleLanguageSettings)

    def openSubDLSubtitleFont(self):
        """Open the external-SRT font configuration owned by SubsSupport."""
        try:
            from Plugins.Extensions.SubsSupport.subtitles import initSubsSettings, SubsSetupExternal
            settings = initSubsSettings()
            external = getattr(settings, "external", None)
            if external is None:
                raise RuntimeError("missing external subtitle settings")
            return self.session.open(SubsSetupExternal, external)
        except ImportError:
            return self.session.open(
                MessageBox,
                "Font settings require SubsSupport. Install or update SubsSupport from your receiver plugin feed, then open 5 > Font again.",
                MessageBox.TYPE_INFO,
                timeout=7,
            )
        except Exception:
            try:
                from Plugins.Extensions.SubsSupport.plugin import openSubsSupportSettings
                return openSubsSupportSettings(self.session)
            except Exception:
                return self.session.open(
                    MessageBox,
                    "Could not open the SubsSupport font settings on this receiver image.",
                    MessageBox.TYPE_ERROR,
                    timeout=7,
                )

    def openSubDLSettingsMenu(self):
        """Show the agreed Import, Language and Font actions under settings key 5."""
        current = load_subdl_settings()
        language_code = current.get("language", "ar")
        language_name = dict((code, name) for name, code in SUBDL_LANGUAGE_CHOICES).get(language_code, language_code)
        choices = [
            ("Import SubDL API Key  •  /tmp/key.txt", "import"),
            ("SubDL Subtitle Language  •  %s" % language_name, "language"),
            ("SubDL Subtitle Font  •  SubsSupport", "font"),
        ]
        self.session.openWithCallback(
            self._subdlSettingsSelected,
            ChoiceBox,
            title="SUBDL SETTINGS  •  IMPORT / LANGUAGE / FONT",
            list=choices,
        )

    def _subdlSettingsSelected(self, choice=None):
        if not choice:
            return
        action = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
        if action == "import":
            return self.importSubDLKey()
        if action == "language":
            return self.openSubDLSubtitleLanguage()
        if action == "font":
            return self.openSubDLSubtitleFont()

    def importSubDLKey(self):
        """Import the local SubDL key while preserving the chosen language and type."""
        try:
            value = _read_subdl_import_key()
            current = load_subdl_settings()
            save_subdl_settings(
                value,
                current.get("language", "ar"),
                current.get("kind", "standard"),
            )
            removed = False
            try:
                os.remove(SUBDL_IMPORT_FILE)
                removed = True
            except Exception:
                pass
            message = (
                "SubDL key imported and saved locally. Press 5 and choose SubDL Subtitle Language. The temporary file was removed."
                if removed else
                "SubDL key imported and saved locally. Press 5 and choose SubDL Subtitle Language. Remove /tmp/key.txt manually to protect your key."
            )
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=6)
        except IOError:
            self.session.open(
                MessageBox,
                "Create /tmp/key.txt with one SubDL API key, then press 5 and choose Import SubDL API Key.",
                MessageBox.TYPE_INFO,
                timeout=7,
            )
        except ValueError:
            self.session.open(
                MessageBox,
                "Invalid /tmp/key.txt. It must contain exactly one SubDL API key.",
                MessageBox.TYPE_ERROR,
                timeout=7,
            )
        except Exception:
            self.session.open(
                MessageBox,
                "Could not import the SubDL key from /tmp/key.txt.",
                MessageBox.TYPE_ERROR,
                timeout=7,
            )

    def openFilter(self):
        source = self.current()
        if not source:
            return
        if source.get("type") not in ("xtream", "stalker"):
            return self.session.open(MessageBox, "Filtering is available for Xtream Codes and Stalker Portal sources.", MessageBox.TYPE_INFO)
        self.session.open(ServerCategoryFilter, source)

    def _sourceKey(self, source):
        return ServerStatusList._key(source)

    def _displaySources(self):
        """Show only real user servers; SubDL actions live under settings key 5."""
        return list(self.sources)

    def _refreshSourceRows(self):
        """Redraw server status while preserving the selected real server."""
        selected_key = None
        try:
            current = self.current()
            selected_key = self._sourceKey(current) if current else None
        except Exception:
            pass
        display_sources = self._displaySources()
        self["config"].setSources(display_sources, self._serverStates)
        if selected_key:
            for index, source in enumerate(display_sources):
                if self._sourceKey(source) == selected_key:
                    try:
                        self["config"].moveToIndex(index)
                    except Exception:
                        pass
                    break

    def _updateStatusCard(self):
        total = len(self.sources)
        if not total:
            text = "Add a playlist to see connection and active-use status."
        else:
            checking = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source), "checking") == "checking"])
            online = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) == "online"])
            busy = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) == "busy"])
            offline = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) == "offline"])
            if checking:
                text = "Checking %d server%s in the background…" % (checking, "" if checking == 1 else "s")
            else:
                text = "%d ready  •  %d in use  •  %d offline  •  Blue: test selected server" % (online, busy, offline)
        try:
            self["serverStatusText"].setText(text)
        except Exception:
            pass

    def _connectionTest(self, source):
        """Return privacy-safe server state without persisting any provider data."""
        try:
            source_type = source.get("type")
            if source_type == "xtream":
                reply = XtreamClient(source).test()
            elif source_type == "m3u":
                reply = M3UClient(source).test()
            else:
                reply = StalkerClient(source).test()
            return evaluate_reply(source_type, reply), ""
        except Exception as exc:
            return {"state": "offline", "active_connections": None, "max_connections": None, "usage_reported": False}, str(exc)

    def _startStatusRefresh(self):
        if self._statusClosed or self._statusResult is not None:
            return
        self._statusToken += 1
        token = self._statusToken
        sources = [dict(source) for source in self.sources]
        self._serverStates = {self._sourceKey(source): "checking" for source in sources}
        self._refreshSourceRows()
        self._updateStatusCard()
        if not sources:
            return

        def worker():
            states = {}
            for source in sources:
                report, _error = self._connectionTest(source)
                states[self._sourceKey(source)] = report.get("state", "offline")
            self._statusResult = (token, states)

        thread = threading.Thread(target=worker, name="TiviMateServerStatus")
        thread.daemon = True
        thread.start()
        try:
            self._statusTimer.start(120, False)
        except Exception:
            pass

    def _finishStatusRefresh(self):
        result = self._statusResult
        if not result:
            try:
                self._statusTimer.start(120, False)
            except Exception:
                pass
            return
        self._statusResult = None
        token, states = result
        if self._statusClosed or token != self._statusToken:
            return
        self._serverStates.update(states)
        self._refreshSourceRows()
        self._updateStatusCard()

    def _stopStatusRefresh(self):
        self._statusClosed = True
        self._statusToken += 1
        try:
            self._statusTimer.stop()
        except Exception:
            pass

    def reload(self):
        self.sources = get_sources()
        keys = set([self._sourceKey(source) for source in self.sources])
        self._serverStates = {key: state for key, state in self._serverStates.items() if key in keys}
        for source in self.sources:
            self._serverStates.setdefault(self._sourceKey(source), "checking")
        self._refreshSourceRows()
        self._updateStatusCard()
        if getattr(self, "_statusReady", False):
            self._startStatusRefresh()

    def current(self):
        row = self["config"].getCurrent()
        return row[0] if row else None

    def select(self):
        source = self.current()
        if not source:
            return
        if self.selectCallback:
            self.selectCallback(source)
            self.close()
        else:
            self.session.open(SourceMenu, source)

    def addSource(self):
        self.session.openWithCallback(self._chooseSourceType, SourceTypePicker)

    def _chooseSourceType(self, source_type=None):
        if source_type == "xtream":
            self.session.openWithCallback(self._saveNew, PlaylistEditor, None)
        elif source_type == "stalker":
            self.session.openWithCallback(self._saveNew, StalkerPortalEditor, None)

    @staticmethod
    def _storageSourceKey(source):
        source = source or {}
        return "%s|%s|%s|%s" % (
            source.get("type", ""),
            (source.get("url") or source.get("host") or source.get("server") or source.get("portal") or "").rstrip("/"),
            source.get("username", ""),
            source.get("mac", ""),
        )

    def _saveNew(self, source=None):
        if not isinstance(source, dict):
            return
        srcs = get_sources()
        srcs.append(source)
        set_sources(srcs)
        write_playlists(srcs)
        self.reload()
        self.session.open(MessageBox, "Server saved.", MessageBox.TYPE_INFO, timeout=3)

    def editSource(self):
        source = self.current()
        if not source:
            return
        try:
            source_index = int(self["config"].getSelectedIndex())
        except Exception:
            source_index = -1
        callback = lambda edited=None: self._replaceAt(source_index, source, edited)
        if source.get("type") == "xtream":
            return self.session.openWithCallback(callback, PlaylistEditor, source)
        if source.get("type") == "stalker":
            return self.session.openWithCallback(callback, StalkerPortalEditor, source)
        return self.session.open(MessageBox, "Only Xtream Codes and Stalker Portal sources can be edited here.", MessageBox.TYPE_INFO)

    def _replaceAt(self, source_index, old, new=None):
        if not isinstance(new, dict):
            return
        srcs = get_sources()
        replaced_index = -1
        if 0 <= source_index < len(srcs):
            candidate = srcs[source_index]
            if self._storageSourceKey(candidate) == self._storageSourceKey(old) or candidate == old:
                srcs[source_index] = new
                replaced_index = source_index
        if replaced_index < 0:
            old_key = self._storageSourceKey(old)
            for i, item in enumerate(srcs):
                if item == old or self._storageSourceKey(item) == old_key:
                    srcs[i] = new
                    replaced_index = i
                    break
        if replaced_index < 0:
            srcs.append(new)
            replaced_index = len(srcs) - 1
        set_sources(srcs)
        write_playlists(srcs)
        self.reload()
        try:
            self["config"].moveToIndex(replaced_index)
        except Exception:
            pass
        self.session.open(MessageBox, "Name and settings saved.", MessageBox.TYPE_INFO, timeout=3)

    def delSource(self):
        source = self.current()
        if not source:
            return
        srcs = [x for x in get_sources() if x != source]
        set_sources(srcs); write_playlists(srcs)
        self.reload()

    def testSource(self):
        source = self.current()
        if not source:
            return
        key = self._sourceKey(source)
        self._serverStates[key] = "checking"
        self._refreshSourceRows()
        self._updateStatusCard()
        report, error = self._connectionTest(source)
        state = report.get("state", "offline")
        self._serverStates[key] = state
        self._refreshSourceRows()
        self._updateStatusCard()
        if state == "online":
            self.session.open(MessageBox, "Connection successful. No active use was reported by the server.", MessageBox.TYPE_INFO)
        elif state == "busy":
            self.session.open(MessageBox, "Connection successful. The server reports active use for this subscription.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Connection failed.\n%s" % (error or "Please verify the server details."), MessageBox.TYPE_ERROR)


class TiviMateE2Search(Screen):
    skin = SEARCH_SCREEN
    MOVIE_X = [85, 325, 565, 805, 1045, 1285]
    SHOW_X = [85, 325, 565, 805, 1045, 1285]

    def __init__(self, session, source):
        Screen.__init__(self, session)
        self.source = source
        self.query = ""
        self.movies = []
        self.shows = []
        self.row = 0
        self.index = 0
        self.loaders = []
        self.downloaders = []
        self["back"] = Label("‹")
        self["searchText"] = Label(tr("Search for a channel, movie or series..."))
        self["mic"] = Label("◉")
        self["closeIcon"] = Label("×")
        self["moviesTitle"] = Label(tr("Movies  0"))
        self["showsTitle"] = Label(tr("Shows  0"))
        for i in range(12):
            self["poster%d" % i] = Pixmap()
            self["posterLabel%d" % i] = Label("")
            self["posterRate%d" % i] = Label("")
        self["movieSelector"] = Pixmap()
        self["showSelector"] = Pixmap()
        self["selectedTitle"] = Label("")
        self["play"] = Label("▷  " + tr("Play"))
        self["favorite"] = Label("☆  " + tr("Add to My List"))
        self["status"] = Label(tr("Press OK to start searching"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "yellowlong": self.addCurrentFavourite, "green": self.openKeyboard, "blue": self.openKeyboard
        }, -1)
        self.onLayoutFinish.append(self.layoutReady)

    def layoutReady(self):
        self["status"].setText(tr("Press OK to start searching"))

    def openKeyboard(self):
        try:
            self.session.openWithCallback(self.searchReady, VirtualKeyBoard, title="Search", text=self.query)
        except RuntimeError as exc:
            self["status"].setText(tr("Press OK again to open the search keyboard"))


    def searchReady(self, value=None):
        if value is None:
            if not self.query: self.close()
            return
        self.query = (value or "").strip()
        self["searchText"].setText(self.query or "Search for a channel, movie or series...")
        if not self.query: return
        self["status"].setText(tr("Searching..."))
        t = threading.Thread(target=self._worker, name="TiviMateSearch")
        t.daemon = True; t.start()

    def _worker(self):
        try:
            q = self.query.lower()
            source_type = self.source.get("type")
            if source_type == "xtream":
                client = XtreamClient(self.source)
                movies_all = get_filtered_streams(self.source, "vod", client)
                shows_all = get_filtered_streams(self.source, "series", client)
                movies = [x for x in movies_all if q in (x.get("name") or x.get("title") or "").lower()][:6]
                shows = [x for x in shows_all if q in (x.get("name") or x.get("title") or "").lower()][:6]
                mode = "library"
            elif source_type == "stalker":
                client = StalkerClient(self.source)
                movies_all = get_filtered_streams(self.source, "vod", client)
                shows_all = get_filtered_streams(self.source, "series", client)
                movies = [x for x in movies_all if q in (x.get("name") or x.get("title") or "").lower()][:6]
                shows = [x for x in shows_all if q in (x.get("name") or x.get("title") or "").lower()][:6]
                mode = "library"
            else:
                rows, _origin = get_cached_catalog(self.source, "live", lambda: M3UClient(self.source).entries(), wait_for_server=True)
                movies = [x for x in rows if q in (x.get("name") or x.get("title") or "").lower()][:6]
                shows, mode = [], "channels"
            if reactor: reactor.callFromThread(self._ready, movies, shows, mode)
            else: self._ready(movies, shows, mode)
        except Exception as exc:
            if reactor: reactor.callFromThread(self._failed, str(exc))
            else: self._failed(str(exc))

    def _failed(self, err): self["status"].setText("Search failed: %s" % err)

    def short_title(self, item):
        title = str((item or {}).get("name") or (item or {}).get("title") or "").strip()
        return title[:22] + ("…" if len(title) > 22 else "")

    def _ready(self, movies, shows, mode="library"):
        self.searchMode = mode
        self.movies, self.shows = movies, shows
        self.row, self.index = 0, 0
        if self.searchMode == "channels":
            self["moviesTitle"].setText("Channels  %d" % len(movies))
            self["showsTitle"].setText(tr(""))
        elif self.searchMode == "movies":
            self["moviesTitle"].setText("%s  %d" % (tr("Movies"), len(movies)))
            self["showsTitle"].setText(tr(""))
        else:
            self["moviesTitle"].setText("%s  %d" % (tr("Movies"), len(movies)))
            self["showsTitle"].setText("%s  %d" % (tr("TV Shows"), len(shows)))
        # Hide all unused slots first. Only real search results are shown.
        for i in range(12):
            try:
                self["poster%d" % i].hide()
                self["posterLabel%d" % i].hide()
                self["posterRate%d" % i].hide()
            except Exception: pass
        placeholder = os.path.join(PLUGIN_PATH, "skins", "poster_placeholder.png")
        for i, item in enumerate(movies):
            try:
                self["poster%d" % i].instance.setPixmapFromFile(placeholder)
                self["poster%d" % i].show()
                self["posterLabel%d" % i].setText(self.short_title(item))
                self["posterRate%d" % i].setText(str(item.get("rating") or item.get("rating_5based") or "")[:4])
                self["posterLabel%d" % i].show()
                self["posterRate%d" % i].show()
            except Exception:
                pass
            self.loadImage(i, item.get("stream_icon") or item.get("cover") or "")
        for j, item in enumerate(shows):
            slot = 6 + j
            try:
                self["poster%d" % slot].instance.setPixmapFromFile(placeholder)
                self["poster%d" % slot].show()
                self["posterLabel%d" % slot].setText(self.short_title(item))
                self["posterRate%d" % slot].setText(str(item.get("rating") or item.get("rating_5based") or "")[:4])
                self["posterLabel%d" % slot].show()
                self["posterRate%d" % slot].show()
            except Exception:
                pass
            self.loadImage(slot, item.get("cover") or item.get("stream_icon") or "")
        if self.searchMode == "channels":
            self["status"].setText("%d channels" % len(movies))
        elif self.searchMode == "movies":
            self["status"].setText("%d movies" % len(movies))
        else:
            self["status"].setText("%d movies • %d shows" % (len(movies), len(shows)))
        self.updateSelection()

    def current(self):
        arr = self.movies if self.row == 0 else self.shows
        return arr[self.index] if arr and self.index < len(arr) else None

    def updateSelection(self):
        arr = self.movies if self.row == 0 else self.shows
        if not arr:
            if self.row == 0 and self.shows: self.row, self.index = 1, 0; arr = self.shows
            elif self.row == 1 and self.movies: self.row, self.index = 0, 0; arr = self.movies
            else:
                try:
                    self["movieSelector"].hide(); self["showSelector"].hide()
                except Exception:
                    pass
                self["selectedTitle"].setText(tr("")); return
        self.index = min(self.index, len(arr)-1)
        x = (self.MOVIE_X if self.row == 0 else self.SHOW_X)[self.index]
        try:
            if self.row == 0:
                self["showSelector"].hide()
                self["movieSelector"].instance.move(ePoint(sx(x), sy(235)))
                self["movieSelector"].show()
            else:
                self["movieSelector"].hide()
                self["showSelector"].instance.move(ePoint(sx(x), sy(750)))
                self["showSelector"].show()
        except Exception:
            pass
        item = self.current() or {}
        title = item.get("name") or item.get("title") or ""
        year = item.get("year") or item.get("releaseDate") or ""
        self["selectedTitle"].setText("%s\n%s" % (title, year))
        kind = "live" if getattr(self, "searchMode", "library") == "channels" else ("series" if self.row == 1 else "vod")
        self["favorite"].setText(("★  " + tr("Remove from My List")) if is_favourite(self.source, kind, item) else ("☆  " + tr("Add to My List")))

    def left(self): self.index=max(0,self.index-1); self.updateSelection()
    def right(self):
        arr=self.movies if self.row==0 else self.shows
        self.index=min(max(0,len(arr)-1),self.index+1); self.updateSelection()
    def up(self):
        if self.row==1 and self.movies: self.row,self.index=0,min(self.index,len(self.movies)-1)
        else: return self.openKeyboard()
        self.updateSelection()
    def down(self):
        if self.row==0 and self.shows: self.row,self.index=1,min(self.index,len(self.shows)-1); self.updateSelection()

    def toggleFavourite(self):
        item = self.current()
        if not item:
            return
        kind = "live" if getattr(self, "searchMode", "library") == "channels" else ("series" if self.row == 1 else "vod")
        added, saved = toggle_favourite(self.source, kind, item)
        if not saved:
            self["status"].setText(tr("Unable to save favorite"))
        elif added:
            self["status"].setText(tr("Added to favorites"))
        else:
            self["status"].setText(tr("Removed from favorites"))
        self.updateSelection()

    def addCurrentFavourite(self):
        item = self.current()
        if not item:
            return
        kind = "live" if getattr(self, "searchMode", "library") == "channels" else ("series" if self.row == 1 else "vod")
        if kind not in ("vod", "series"):
            return
        if is_favourite(self.source, kind, item):
            self["status"].setText(tr("Item is already in favorites"))
        elif add_favourite(self.source, kind, item):
            self["status"].setText(tr("Added to favorites"))
        else:
            self["status"].setText(tr("Unable to save favorite"))
        self.updateSelection()

    def ok(self):
        item = self.current()
        if not item:
            return self.openKeyboard()
        if getattr(self, "searchMode", "library") == "channels":
            rows = list(self.movies or [])
            return self.session.open(TiviMateLivePlayer, self.source, rows, self.index)
        if self.row == 1:
            return self.session.open(SeriesDetailsScreen, self.source, item)
        if self.source.get("type") == "stalker":
            url = StalkerClient(self.source).stream_url(item, "vod")
        else:
            ext = item.get("container_extension") or self.source.get("output", "ts")
            url = "%s/movie/%s/%s/%s.%s" % (self.source.get("url", "").rstrip("/"), self.source.get("username", ""), self.source.get("password", ""), item.get("stream_id", ""), ext)
        if not url:
            return self.session.open(MessageBox, "Unable to resolve a playable movie URL.", MessageBox.TYPE_ERROR)
        self.session.open(TiviMatePlayer, eServiceReference(4097, 0, url), item)

    def loadImage(self, slot, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_artwork_requests", None)
        if requests is None:
            requests = {}
            self._artwork_requests = requests
        requests[slot] = url

        def done(path, s=slot, expected=url):
            if getattr(self, "_artwork_requests", {}).get(s) != expected:
                return
            self.decode(s, path)

        request_artwork(url, "search", done, priority=55)

    def decode(self, slot, path):
        loader = ePicLoad()
        self.loaders.append(loader)
        def ready(_=None, s=slot, ll=loader):
            try:
                ptr = ll.getData()
                widget = self["poster%d" % s]
                if ptr and widget.instance:
                    widget.instance.setPixmap(ptr)
                    widget.show()
            except Exception:
                pass
            try:
                if ll in self.loaders:
                    self.loaders.remove(ll)
            except Exception:
                pass
        loader.PictureData.get().append(ready)
        size = (215, 360) if slot < 6 else (215, 265)
        render_width, render_height = scale_size(size[0], size[1])
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)


class TiviMateE2Home(Screen):
    skin = HOME_SKIN1
    NAV = ["Search", "Home", "Live", "Movies", "TV Shows", "Favorite", "Settings"]
    NAV_X = [370, 520, 670, 820, 970, 1120, 1390]
    NAV_Y = [210] * 7
    POSTER_X = [216, 461, 706, 951, 1196, 1441]
    POSTER_Y = 701
    ACTIVE_FILE = "/etc/enigma2/tivimatee2/active_source.json"

    def __init__(self, session):
        self.homeAppearance = _load_home_appearance()
        self.homeSkinName = self.homeAppearance.get("skin", "skin2_dark")
        self.isReferenceHome = self.homeSkinName == "reference_home"
        self.posterSize = (248, 338)
        self.bannerSize = (1704, 454)
        if self.homeSkinName == "skin2_dark":
            self.skin = HOME_SKIN2
            self.NAV = ["Home", "Live", "Movies", "TV Shows", "Search", "Settings"]
            self.NAV_X = [350, 525, 690, 865, 1060, 1225]
            self.NAV_Y = [79] * 6
            self.POSTER_X = [55, 375, 695, 1015, 1335, 1655]
            self.POSTER_Y = 510
            self.posterSize = (215, 360)
            self.bannerSize = (1920, 370)
        else:
            self.homeSkinName = "reference_home"
            self.isReferenceHome = True
            self.skin = HOME_SKIN1
            self.NAV_X = [380, 550, 710, 870, 1030, 1210, 1390]
            self.NAV_Y = [27] * 7
            self.POSTER_X = [106, 398, 690, 982, 1274, 1566]
            self.POSTER_Y = 676
        Screen.__init__(self, session)
        self.source = self._loadActiveSource()
        self.focus = "nav"
        self.navIndex = 0 if self.homeSkinName == "skin2_dark" else 1
        self.posterIndex = 0
        self.recent = []
        self.imageLoaders = [None] * 7
        self.imageDownloaders = [None] * 7
        self.featureRequestId = 0
        # The dashboard hero is part of the application identity, never of a specific IPTV source.
        self.globalHero = True
        self["headline"] = Label(tr("TiViMate IPTV EXPERIENCE"))
        self["subheadline"] = Label(tr("Live TV  •  Movies  •  Series  •  beIN SPORTS"))
        self["logo"] = Label(tr("TiviMate E2"))
        self["homeBrandLogo"] = Pixmap()
        self["poweredBy"] = Label(tr("Developed by Opesboy"))
        for i in range(8): self["nav%d" % i] = Label(tr(self.NAV[i]) if i < len(self.NAV) else "")
        self["navSelector"] = Pixmap()
        self["clock"] = Label("")
        self["date"] = Label("")
        self["banner"] = Pixmap()
        self["quality"] = Label(tr("TIVIMATE  •  PREMIUM IPTV"))
        self["featureTitle"] = Label(tr("YOUR ENTERTAINMENT, ONE PLACE"))
        self["featureMeta"] = Label(tr("Browse, discover and enjoy your library in one unified experience."))
        self["featureDesc"] = Label("")
        self["playNow"] = Label(tr("WATCH NOW"))
        self["recentTitle"] = Label(tr("Recently Added"))
        for i in range(6):
            self["poster%d" % i] = Pixmap()
            self["posterMetaTitle%d" % i] = Label("")
            self["posterMetaRate%d" % i] = Label("")
        self["posterSelector"] = Pixmap()
        self["status"] = Label("")
        if self.homeSkinName == "skin2_dark":
            self["actionLabel0"] = Label(tr("ADD IPTV SOURCE"))
            self["actionLabel1"] = Label(tr("UPDATE PLAYLIST"))
            self["actionLabel2"] = Label(tr("Favorites"))
            self["actionLabel3"] = Label(tr("EXIT"))
            lang = get_language()
            if lang == "ar":
                self["skin2HelpTitle"] = Label("أزرار الريموت")
                self["skin2HelpBody"] = Label("الأخضر: إضافة مصدر   الأصفر: تحديث القائمة\nالأزرق: المفضلة   الأحمر: خروج")
                self["skin2LangTitle"] = Label("اللغة العربية")
                self["skin2LangBody"] = Label("واجهة وقوائم عربية متناسقة وواضحة")
                self["skin2Key5"] = Label("المفتاح 5\nإعدادات الترجمة")
            elif lang == "fr":
                self["skin2HelpTitle"] = Label("Touches de la télécommande")
                self["skin2HelpBody"] = Label("Vert: Ajouter source   Jaune: Actualiser\nBleu: Favoris   Rouge: Quitter")
                self["skin2LangTitle"] = Label("Interface française")
                self["skin2LangBody"] = Label("Menus et informations adaptés à la langue")
                self["skin2Key5"] = Label("Touche 5\nRéglages des sous-titres")
            else:
                self["skin2HelpTitle"] = Label("REMOTE SHORTCUTS")
                self["skin2HelpBody"] = Label("Green: Add source   Yellow: Refresh playlist\nBlue: Favorites   Red: Exit")
                self["skin2LangTitle"] = Label("LANGUAGE")
                self["skin2LangBody"] = Label("Menus and information follow the selected language")
                self["skin2Key5"] = Label("KEY 5\nSubtitle settings")
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "ok": self.ok, "cancel": self.close, "menu": self.openFavorites,
            "red": self.close, "green": self.openSettings, "yellow": self.refreshHome,
            "yellowlong": self.addRecentFavourite, "blue": self.openFavorites
        }, -1)
        self.clockTimer = eTimer()
        try: self.clockTimer.callback.append(self.updateClock)
        except Exception: self.clockTimer.timeout.get().append(self.updateClock)
        self.loadTimer = eTimer()
        try: self.loadTimer.callback.append(self.startLoad)
        except Exception: self.loadTimer.timeout.get().append(self.startLoad)
        # Stalker/Ministra portals can complete the network request in a worker
        # while a Twisted reactor is unavailable or not integrated with Enigma2.
        # Deliver their Home result through an eTimer, the same UI-thread pattern
        # used by ContentHome.  This remains completely generic: it carries only
        # a source snapshot, a request token, and normalized items.
        self.stalkerRecentToken = 0
        self.stalkerRecentResult = None
        self.stalkerRecentTimer = eTimer()
        try: self.stalkerRecentTimer.callback.append(self._finishStalkerRecentLoad)
        except Exception: self.stalkerRecentTimer.timeout.get().append(self._finishStalkerRecentLoad)
        # Update work happens only after the Home screen is visible and always
        # in a background thread, so it never delays loading IPTV content.
        self.updateCheckTimer = eTimer()
        self.updateCheckPollTimer = eTimer()
        self.updateDownloadPollTimer = eTimer()
        try: self.updateCheckTimer.callback.append(self._beginUpdateCheck)
        except Exception: self.updateCheckTimer.timeout.get().append(self._beginUpdateCheck)
        try: self.updateCheckPollTimer.callback.append(self._pollUpdateCheck)
        except Exception: self.updateCheckPollTimer.timeout.get().append(self._pollUpdateCheck)
        try: self.updateDownloadPollTimer.callback.append(self._pollUpdateDownload)
        except Exception: self.updateDownloadPollTimer.timeout.get().append(self._pollUpdateDownload)
        self._updateCheckPending = None
        self._updateDownloadPending = None
        self._updateCandidate = None
        self._updateInstallProcess = None
        self._updateCheckStarted = False
        try: self.onClose.append(self._stopUpdateTimers)
        except Exception: pass
        try: self.onClose.append(self._stopStalkerRecentTimer)
        except Exception: pass
        self.onLayoutFinish.append(self.layoutReady)

    def _applyRecentTitleLayout(self):
        """Keep the Recently Added heading on the right edge only for Arabic.
        Do not mirror the whole screen; only reposition this heading."""
        try:
            widget = self["recentTitle"]
            if not widget or not widget.instance:
                return
            lang = get_language()
            if self.isReferenceHome:
                x, y, w, h = (100, 610, 500, 42)
                if lang == "ar":
                    # Arabic heading sits at the far-right edge above the last poster.
                    x, w = (1650, 220)
            else:
                x, y, w, h = (55, 468, 560, 40)
                if lang == "ar":
                    # Skin 2: keep only this heading RTL-positioned; do not mirror Home.
                    x, w = (1650, 220)
            widget.instance.move(ePoint(sx(x), sy(y)))
            widget.instance.resize(eSize(sx(w), sy(h)))
        except Exception:
            pass

    def layoutReady(self):
        # Both Home skins scale their decoded hero at the Pixmap level.
        # This keeps Skin 1's backdrop stretched across its full panoramic frame.
        try:
            self["banner"].instance.setScale(1)
        except Exception:
            pass
        self.applyGlobalHero()
        self._applyRecentTitleLayout()
        self.updateFocus(); self.updateClock()
        try: self.clockTimer.start(30000, False)
        except Exception: pass
        try: self.loadTimer.start(250, True)
        except Exception: self.startLoad()
        # Delay the request slightly so a slow or unavailable update endpoint
        # never affects the first paint of the home interface.
        if _load_update_settings().get("auto_check", True):
            try: self.updateCheckTimer.start(1500, True)
            except Exception: self._beginUpdateCheck()

    def _stopUpdateTimers(self):
        for timer in (getattr(self, "updateCheckTimer", None),
                      getattr(self, "updateCheckPollTimer", None),
                      getattr(self, "updateDownloadPollTimer", None)):
            try:
                if timer:
                    timer.stop()
            except Exception:
                pass

    def _stopStalkerRecentTimer(self):
        # Invalidate a finishing worker before the screen is destroyed.
        self.stalkerRecentToken = getattr(self, "stalkerRecentToken", 0) + 1
        self.stalkerRecentResult = None
        try:
            self.stalkerRecentTimer.stop()
        except Exception:
            pass

    def _beginUpdateCheck(self):
        if not _load_update_settings().get("auto_check", True):
            return
        if self._updateCheckStarted:
            return
        self._updateCheckStarted = True
        self._updateCheckPending = None

        def worker():
            try:
                self._updateCheckPending = check_for_update()
            except Exception:
                self._updateCheckPending = {}

        try:
            thread = threading.Thread(target=worker)
            thread.daemon = True
            thread.start()
            self.updateCheckPollTimer.start(200, True)
        except Exception:
            self._updateCheckPending = {}

    def _pollUpdateCheck(self):
        if self._updateCheckPending is None:
            try: self.updateCheckPollTimer.start(200, True)
            except Exception: pass
            return
        result = self._updateCheckPending or {}
        self._updateCheckPending = None
        if not result.get("available"):
            return
        self._updateCandidate = result
        version = result.get("version") or "1.0.3"
        revision = result.get("revision") or "?"
        notes = result.get("notes") or ""
        text = "A new TiviMate E2 update is available.\n\nVersion: %s (revision %s)" % (version, revision)
        if notes:
            text += "\n\n" + notes
        text += "\n\nDownload and install it now?"
        try:
            self.session.openWithCallback(self._onUpdatePrompt, MessageBox, text,
                type=MessageBox.TYPE_YESNO, timeout=20, default=False)
        except Exception:
            pass

    def _onUpdatePrompt(self, answer):
        if not answer or not self._updateCandidate:
            return
        package = self._updateCandidate.get("package")
        if not package:
            return
        self._updateDownloadPending = None
        try: self["status"].setText(tr("Downloading TiviMate E2 update..."))
        except Exception: pass

        def worker():
            self._updateDownloadPending = download_package(package)

        try:
            thread = threading.Thread(target=worker)
            thread.daemon = True
            thread.start()
            self.updateDownloadPollTimer.start(200, True)
        except Exception:
            self._updateDownloadPending = {"ok": False, "message": "Unable to start download"}

    def _pollUpdateDownload(self):
        if self._updateDownloadPending is None:
            try: self.updateDownloadPollTimer.start(200, True)
            except Exception: pass
            return
        result = self._updateDownloadPending or {}
        self._updateDownloadPending = None
        if not result.get("ok"):
            try: self["status"].setText(tr(""))
            except Exception: pass
            self._showUpdateMessage("Update download failed.\n\n%s" % (result.get("message") or "Please try again later."))
            return
        command = install_command(result)
        if not command:
            try: self["status"].setText(tr(""))
            except Exception: pass
            self._showUpdateMessage("The verified update package could not be installed.")
            return
        try: self["status"].setText(tr("Installing TiviMate E2 update..."))
        except Exception: pass
        try:
            process = eConsoleAppContainer()
            self._updateInstallProcess = process
            try: process.appClosed.append(self._onUpdateInstallFinished)
            except Exception: process.appClosed.get().append(self._onUpdateInstallFinished)
            process.execute("/bin/sh", "sh", "-c", command)
        except Exception:
            try: self["status"].setText(tr(""))
            except Exception: pass
            self._showUpdateMessage("Unable to start the update installer.")

    def _onUpdateInstallFinished(self, status):
        self._updateInstallProcess = None
        try: self["status"].setText(tr(""))
        except Exception: pass
        if status == 0:
            self._showUpdateMessage("TiviMate E2 was updated successfully.\n\nPlease restart the Enigma2 GUI to use the new version.")
        else:
            self._showUpdateMessage("The update installer returned an error.\n\nYour current TiviMate E2 installation has not been changed.")

    def _showUpdateMessage(self, text):
        try:
            self.session.open(MessageBox, text, type=MessageBox.TYPE_INFO, timeout=12)
        except Exception:
            pass

    def _sourceKey(self, source):
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("url", "").rstrip("/"), source.get("username", ""), source.get("mac", ""))

    def _loadActiveSource(self):
        sources = get_sources()
        if not sources: return None
        try:
            with open_text(self.ACTIVE_FILE, "r") as f: key = json.load(f).get("key", "")
            for source in sources:
                if self._sourceKey(source) == key: return source
        except Exception: pass
        for source in sources:
            if source.get("type") == "xtream": return source
        return sources[0]

    def _saveActiveSource(self):
        try:
            ensure_dir(os.path.dirname(self.ACTIVE_FILE))
            with open_text(self.ACTIVE_FILE, "w") as f: json.dump({"key": self._sourceKey(self.source)}, f)
        except Exception: pass

    def updateClock(self):
        now = time.localtime()
        self["clock"].setText(time.strftime("%H:%M", now))
        self["date"].setText(time.strftime("%d.%m.%Y", now))

    def updateFocus(self):
        if self["navSelector"].instance:
            self["navSelector"].instance.move(ePoint(sx(self.NAV_X[self.navIndex]), sy(self.NAV_Y[self.navIndex])))
            self["navSelector"].show() if self.focus == "nav" else self["navSelector"].hide()
        if self["posterSelector"].instance:
            self["posterSelector"].instance.move(ePoint(sx(self.POSTER_X[self.posterIndex]), sy(self.POSTER_Y)))
            self["posterSelector"].show() if (self.focus == "posters" and bool(self.recent)) else self["posterSelector"].hide()

    def left(self):
        if self.focus == "nav":
            self.navIndex = (self.navIndex - 1) % len(self.NAV)
        else:
            self.posterIndex = max(0, self.posterIndex - 1)
            self.updateFeature()
        self.updateFocus()

    def right(self):
        if self.focus == "nav":
            self.navIndex = (self.navIndex + 1) % len(self.NAV)
        else:
            self.posterIndex = min(max(0, len(self.recent) - 1), self.posterIndex + 1)
            self.updateFeature()
        self.updateFocus()

    def up(self):
        self.focus = "nav"
        self.updateFocus()

    def down(self):
        if self.recent:
            self.focus = "posters"
            self.updateFeature()
        self.updateFocus()

    def ok(self):
        if self.focus == "posters": return self.playRecent()
        index = self.navIndex
        if self.homeSkinName == "skin2_dark":
            if index == 0: return
            if index == 1: return self.openMedia("live")
            if index == 2: return self.openContentHome("vod")
            if index == 3: return self.openContentHome("series")
            if index == 4: return self.session.open(TiviMateE2Search, self.source)
            if index == 5: return self.openSettings()
            return
        if index == 0: return self.session.open(TiviMateE2Search, self.source)
        if index == 1: return
        if index == 2: return self.openMedia("live")
        if index == 3: return self.openContentHome("vod")
        if index == 4: return self.openContentHome("series")
        if index == 5: return self.openFavorites()
        if index == 6: return self.openSettings()

    def addRecentFavourite(self):
        if self.focus != "posters" or not self.recent:
            self["status"].setText(tr("Select a movie poster first"))
            return
        item = self.recent[min(self.posterIndex, len(self.recent) - 1)]
        if is_favourite(self.source, "vod", item):
            self["status"].setText(tr("Movie is already in favorites"))
        elif add_favourite(self.source, "vod", item):
            self["status"].setText(tr("Movie added to favorites"))
        else:
            self["status"].setText(tr("Unable to save favorite"))

    def refreshHome(self):
        self.globalHero = True
        self.posterIndex = 0
        self.recent = []
        self.resetPosters()
        self.startLoad()

    def openContentHome(self, kind):
        if not self.source:
            return self.openSettings()
        source_type = self.source.get("type")
        if source_type in ("xtream", "stalker"):
            return self.session.open(ContentHomeScreen, self.source, kind)
        return self.session.open(MessageBox, "This section requires a server with Movies and TV Shows.", MessageBox.TYPE_INFO)

    def openMedia(self, kind):
        if not self.source:
            return self.openSettings()
        if kind in ("vod", "series") and self.source.get("type") not in ("xtream", "stalker"):
            return self.session.open(MessageBox, "This section requires a server with Movies and TV Shows.", MessageBox.TYPE_INFO)
        self.session.open(MediaScreen, self.source, kind)

    def openFavorites(self):
        self.session.open(FavoritesScreen)

    def openLiveColorMenu(self):
        if self.kind != "live":
            return
        current = self.channelSettings.get("live_theme", "turquoise")
        choices = []
        for name, value in LIVE_STYLE_CHOICES:
            label = ("✓ " if value == current else "") + name
            choices.append((label, value))
        self.session.openWithCallback(self._liveStyleSelected, ChoiceBox, title="Choose Live style", list=choices)

    def _liveStyleSelected(self, selected=None):
        if not selected:
            return
        try:
            theme = selected[1]
        except Exception:
            return
        if theme not in LIVE_STYLE_PALETTES:
            return
        self.channelSettings["live_theme"] = theme
        self.channelSettings["live_color"] = LIVE_STYLE_PALETTES[theme]["accent"]
        _save_channel_settings(self.channelSettings)
        source = dict(self.source)
        try:
            self.close()
            self.session.open(MediaScreen, source, "live")
        except Exception:
            pass


    def openSettings(self):
        self.session.open(ServerManager, self.selectServer)

    def selectServer(self, source):
        self.source = source; self._saveActiveSource(); self.recent = []; self.posterIndex = 0
        self.globalHero = True
        self.resetPosters(); self.startLoad()

    def resetPosters(self):
        for i in range(6):
            try: self["poster%d" % i].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "poster_placeholder.png"))
            except Exception: pass
            try:
                self["posterMetaTitle%d" % i].setText(tr(""))
                self["posterMetaRate%d" % i].setText(tr(""))
            except Exception: pass
        self.applyGlobalHero()

    def applyGlobalHero(self):
        """Render the application hero only until a selected poster supplies its own backdrop."""
        self.featureRequestId += 1
        request_id = self.featureRequestId
        self["quality"].setText(tr("TIVIMATE  •  PREMIUM IPTV"))
        self["featureTitle"].setText(tr("YOUR ENTERTAINMENT, ONE PLACE"))
        self["featureMeta"].setText(tr("Browse, discover and enjoy your library in one unified experience."))
        self["featureDesc"].setText(tr(""))
        self["playNow"].setText(tr("WATCH NOW"))
        self["recentTitle"].setText(tr("Recently Added"))
        self._applyRecentTitleLayout()
        hero = os.path.join(PLUGIN_PATH, "skins", "tivimate_global_hero_r70.png")
        try:
            self.decodeImage(6, hero, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        except Exception:
            try: self["banner"].instance.setPixmapFromFile(hero)
            except Exception: pass

    def startLoad(self):
        if not self.source:
            self["status"].setText(tr("No server selected • Press SETTINGS"))
            return
        self["status"].setText("Loading from %s ..." % self.source.get("name", "SERVER"))
        if self.source.get("type") not in ("xtream", "stalker"):
            self["status"].setText("Selected server: %s" % self.source.get("name", "SERVER")); return
        # Warm enabled series categories while the user remains on the dashboard.
        # This is fully asynchronous and stale cache remains immediately usable.
        try: prefetch_allowed_series(dict(self.source))
        except Exception: pass
        # Never depend on Twisted being integrated into Enigma2 for Stalker Home.
        # The worker sets a result and the eTimer below applies it on the UI thread.
        if self.source.get("type") == "stalker":
            return self._startStalkerRecentLoad()
        if reactor is None:
            return self._loadWorkerDirect()
        thread = threading.Thread(target=self._loadWorker, name="TiviMateDashboard")
        thread.daemon = True; thread.start()

    def _startStalkerRecentLoad(self):
        self.stalkerRecentToken += 1
        token = self.stalkerRecentToken
        source = dict(self.source or {})
        self.stalkerRecentResult = None

        def worker():
            try:
                result = (token, self._fetchRecentFromSource(source), "")
            except Exception as exc:
                result = (token, [], str(exc))
            self.stalkerRecentResult = result

        thread = threading.Thread(target=worker, name="TiviMateStalkerHome")
        thread.daemon = True
        thread.start()
        try:
            self.stalkerRecentTimer.start(120, True)
        except Exception:
            # Fallback remains safe for images where timers are unavailable.
            pass

    def _finishStalkerRecentLoad(self):
        result = self.stalkerRecentResult
        if result is None:
            try:
                self.stalkerRecentTimer.start(120, True)
            except Exception:
                pass
            return
        # Do not erase a newer worker result that may have arrived while this
        # UI callback was being scheduled for an older request token.
        if self.stalkerRecentResult is result:
            self.stalkerRecentResult = None
        token, items, error = result
        if token != self.stalkerRecentToken:
            return
        if error:
            self._recentFailed(error)
            return
        self._recentReady(items)

    def _loadWorkerDirect(self):
        try: self._recentReady(self._fetchRecent())
        except Exception as exc: self._recentFailed(str(exc))

    def _loadWorker(self):
        try:
            items = self._fetchRecent(); reactor.callFromThread(self._recentReady, items)
        except Exception as exc:
            reactor.callFromThread(self._recentFailed, str(exc))

    def _fetchRecent(self):
        return self._fetchRecentFromSource(self.source)

    def _fetchRecentFromSource(self, source):
        source = dict(source or {})
        client = get_source_client(source)
        if source.get("type") == "stalker":
            # A Stalker Home page is a balanced preview from one usable VOD
            # package and one usable Series package.  The helper has no portal-
            # specific assumptions and falls back to either type when needed.
            return get_stalker_home_items(source, client, limit=6)
        items = list(get_filtered_streams(source, "vod", client) or [])
        items.sort(key=lambda x: int(str(x.get("added") or "0") or "0"), reverse=True)
        return items[:6]

    def _recentFailed(self, error):
        self["status"].setText("Unable to load recently added: %s" % error)

    def _recentReady(self, items):
        self.recent = items or []
        home_kinds = set(str((item or {}).get("_tivimate_home_kind") or "") for item in self.recent)
        if home_kinds == set(("vod", "series")):
            heading = tr("Latest Movies & TV Shows")
            status_label = tr("%d Home picks") % len(self.recent)
        elif "series" in home_kinds:
            heading = tr("Latest TV Shows")
            status_label = tr("%d recent TV shows") % len(self.recent)
        else:
            heading = tr("Recently Added")
            status_label = tr("%d recent movies") % len(self.recent)
        if get_language() == "ar":
            heading = "المضاف حديثا"
        self["recentTitle"].setText(heading)
        self._applyRecentTitleLayout()
        self["status"].setText(tr("Server: %s  •  %s") % (self.source.get("name", "SERVER"), status_label))
        for i, item in enumerate(self.recent[:6]):
            pw, ph = self.posterSize
            self.loadImage(i, item.get("stream_icon") or item.get("cover") or "", "poster%d" % i, pw, ph)
            title = str(item.get("name") or item.get("title") or "").strip()
            rating = str(item.get("rating") or item.get("rating_5based") or "").strip()
            self["posterMetaTitle%d" % i].setText(title[:22] + ("…" if len(title) > 22 else ""))
            self["posterMetaRate%d" % i].setText(rating[:4])
        self.posterIndex = 0
        self.globalHero = not bool(self.recent)
        if self.globalHero:
            self.applyGlobalHero()
        else:
            self.updateFeature()
        self.updateFocus()

    def updateFeature(self):
        # The selected poster owns the banner once the library row is ready.
        if not self.recent: return
        item = self.recent[min(self.posterIndex, len(self.recent)-1)]
        self["featureTitle"].setText((item.get("name") or item.get("title") or "MOVIE").upper())
        year = str(item.get("year") or item.get("releaseDate") or "")
        rating = str(item.get("rating") or "")
        genre = str(item.get("genre") or "")
        self["featureMeta"].setText("  •  ".join(x for x in [year, ("★ " + rating) if rating else "", genre] if x))
        self["featureDesc"].setText((item.get("plot") or item.get("description") or "Recently added from the selected server.")[:180])

        # Use a true backdrop in the middle banner. Do not stretch the poster.
        self.featureRequestId += 1
        request_id = self.featureRequestId
        stream_id = item.get("stream_id") or item.get("vod_id")
        direct_backdrop = self._normaliseBackdrop(item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url"))
        if direct_backdrop:
            self.loadImage(6, direct_backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        elif stream_id:
            thread = threading.Thread(target=self._loadFeatureBackdrop, args=(stream_id, request_id), name="TiviMateBackdrop")
            thread.daemon = True
            thread.start()

    def _normaliseBackdrop(self, value):
        if isinstance(value, list):
            value = value[0] if value else ""
        if not isinstance(value, str):
            return ""
        value = value.strip().replace("\\/", "/")
        if value.startswith("["):
            try:
                arr = json.loads(value)
                value = arr[0] if arr else ""
            except Exception:
                pass
        if value.startswith("/") and not value.startswith("//"):
            value = "https://image.tmdb.org/t/p/w1280" + value
        return value if value.startswith(("http://", "https://")) else ""

    def _cleanRecentTitle(self, value):
        import re
        text = str(value or "")
        text = re.sub(r"\b(ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|uhd|fhd|hd|hevc|x265|x264|hdr|web[- ]?dl|bluray|top)\b", " ", text, flags=re.I)
        text = re.sub(r"[\[\]{}()_.|:+-]+", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _recentYear(self, item):
        import re
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        match = re.search(r"\b(?:19|20)\d{2}\b", raw)
        return int(match.group(0)) if match else None

    def _loadFeatureBackdrop(self, stream_id, request_id):
        try:
            data = XtreamClient(self.source).vod_info(stream_id) or {}
            info = {}
            if isinstance(data.get("movie_data"), dict): info.update(data.get("movie_data") or {})
            if isinstance(data.get("info"), dict): info.update(data.get("info") or {})
            backdrop = self._normaliseBackdrop(
                info.get("backdrop_path") or info.get("backdrop") or info.get("backdrop_url") or
                data.get("backdrop_path") or data.get("backdrop")
            )
            # Recent Movies sometimes contains only a poster. Resolve the movie on
            # TMDb and use its true backdrop without changing any other section.
            if not backdrop:
                current = self.recent[min(self.posterIndex, len(self.recent)-1)] if self.recent else {}
                tmdb = TMDbClient()
                tid = info.get("tmdb_id") or info.get("tmdb") or current.get("tmdb_id") or current.get("tmdb")
                if not tid:
                    title = self._cleanRecentTitle(info.get("name") or current.get("name") or current.get("title"))
                    found = tmdb.search_title(title, "vod", self._recentYear(info or current)) if title else None
                    tid = (found or {}).get("id")
                bundle = tmdb.details_bundle(tid, "vod") if tid else {}
                backdrop = self._normaliseBackdrop(bundle.get("backdrop_path"))
            if backdrop and request_id == self.featureRequestId:
                if reactor is not None:
                    reactor.callFromThread(self.loadImage, 6, backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id)
                else:
                    self.loadImage(6, backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        except Exception:
            pass

    def loadImage(self, slot, url, widget, width, height, request_id=None):
        url = (url or "").strip().replace("\\/", "/")
        if not url or (request_id is not None and request_id != self.featureRequestId):
            return
        # One token per visual slot prevents a prior selection from painting over
        # the current poster or backdrop after the user moves the selection.
        requests = getattr(self, "_artwork_requests", None)
        if requests is None:
            requests = {}
            self._artwork_requests = requests
        token = (slot, widget)
        requests[token] = (url, request_id)
        priority = 120 if widget == "banner" else 75

        def done(path, s=slot, w=widget, x=width, y=height, rid=request_id, expected=(url, request_id), key=token):
            if getattr(self, "_artwork_requests", {}).get(key) != expected:
                return
            self.decodeImage(s, path, w, x, y, request_id=rid)

        request_artwork(url, "home", done, priority=priority)

    def decodeImage(self, slot, path, widget, width, height, request_id=None):
        if request_id is not None and request_id != self.featureRequestId:
            return
        loader = ePicLoad(); self.imageLoaders[slot] = loader
        def ready(_info=None, slot=slot, widget=widget, request_id=request_id, l=loader):
            try:
                if request_id is not None and request_id != self.featureRequestId:
                    return
                ptr = l.getData()
                if ptr and self[widget].instance: self[widget].instance.setPixmap(ptr)
            except Exception:
                pass
            finally:
                try:
                    if self.imageLoaders[slot] is l:
                        self.imageLoaders[slot] = None
                except Exception:
                    pass
        loader.PictureData.get().append(ready)
        # A zero aspect ratio makes ePicLoad fill the complete panorama.
        # Both remaining Home skins use this decoding path.
        # so selected movie backdrops cannot be letterboxed with black side areas.
        render_width, render_height = scale_size(width, height)
        if widget == "banner" and self.homeSkinName in ("reference_home", "skin2_dark"):
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        else:
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def playRecent(self):
        if not self.recent or not self.source: return
        # Recent Movies must open the full details route first. The details screen
        # resolves server VOD info, TMDb backdrop, cast and recommendations, while
        # the Watch button keeps the original playback behaviour.
        item = dict(self.recent[self.posterIndex] or {})
        item["_recent_home"] = True
        self.session.open(MovieDetailsScreen, self.source, item, self.recent)


class SourceMenu(Screen):
    skin = SOURCE_MENU

    def __init__(self, session, source):
        Screen.__init__(self, session)
        self.source = source
        self["brand"] = Label("tv")
        if source.get("type") == "m3u":
            self["side"] = MenuList([("التلفاز", "live"), ("الإعدادات", "settings")])
            options = [("التلفاز المباشر", "live")]
        else:
            self["side"] = MenuList([("التلفاز", "live"), ("أفلام", "vod"), ("مسلسلات", "series"), ("الإعدادات", "settings")])
            options = [("التلفاز المباشر", "live"), ("MOVIES", "vod"), ("TV SHOWS", "series")]
        self["title"] = Label(source.get("name", "TiviMate E2"))
        self["subtitle"] = Label(source.get("type", "").upper())
        self["menu"] = MenuList(options)
        self["info"] = Label(tr("Choose a section. Heavy image downloads are disabled in this build for stability."))
        self["keys"] = Label(tr("OK Open    EXIT Back"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.open, "cancel": self.close,
            "up": self.menuUp, "down": self.menuDown,
            "pageUp": self.menuPageUp, "pageDown": self.menuPageDown
        }, -1)

    def menuUp(self):
        self["menu"].up()

    def menuDown(self):
        self["menu"].down()

    def menuPageUp(self):
        try:
            self["menu"].pageUp()
        except Exception:
            self["menu"].up()

    def menuPageDown(self):
        try:
            self["menu"].pageDown()
        except Exception:
            self["menu"].down()

    def open(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        if self.source.get("type") in ("xtream", "stalker") and current[1] in ("vod", "series"):
            return self.session.open(ContentHomeScreen, self.source, current[1])
        self.session.open(MediaScreen, self.source, current[1])


from .tivimate_player import TiviMatePlayer
from .live_player import TiviMateLivePlayer


class SeriesDetailsScreen(Screen):
    skin = SERIES_DETAILS
    EPISODE_X = [80, 440, 800, 1160, 1520]

    def __init__(self, session, source, seriesItem):
        Screen.__init__(self, session)
        self.source = source
        self.seriesItem = seriesItem or {}
        self.seriesData = {}
        self.episodesBySeason = {}
        self.seasonItems = []
        self.episodeItems = []
        self.seasonIndex = 0
        self.episodePage = 0
        self.episodeIndex = 0
        self.downloads = []
        self.picloads = []
        self.backdropLoader = None
        self.backdropDownloader = None
        self.seriesFallbackPoster = ""
        self.seriesBackdrop = ""
        self["backdrop"] = Pixmap()
        self["title"] = Label(self.seriesItem.get("name") or self.seriesItem.get("title") or "مسلسل")
        self["rating"] = Label("")
        self["meta"] = Label("")
        self["cast"] = Label("")
        self["desc"] = Label(tr("Loading series details..."))
        self["seasonInfo"] = Label("")
        self["episodeInfo"] = Label("")
        for i in range(5):
            self["episode%d" % i] = Pixmap()
            self["episodeLabel%d" % i] = Label("")
        self["episodeSelector"] = Pixmap()
        self["keys"] = Label(tr("LEFT/RIGHT Episodes    UP/DOWN Change Season    OK Play    RED Favorite    EXIT Back"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "yellowlong": self.addSeriesFavourite
        }, -1)
        self.onLayoutFinish.append(self.loadSeries)

    def _normImage(self, value):
        if isinstance(value, list):
            value = value[0] if value else ""
        if isinstance(value, str):
            v = value.strip().replace("\\/", "/")
            if v.startswith("["):
                try:
                    arr = json.loads(v)
                    v = arr[0] if arr else ""
                except Exception:
                    pass
            if v.startswith("/") and not v.startswith("//"):
                v = "https://image.tmdb.org/t/p/w1280" + v
            return v
        return ""

    def loadSeries(self):
        # Network work belongs outside Enigma2's GUI thread.  The visual layout,
        # decoded posters, and backdrop handling are unchanged.
        sid = self.seriesItem.get("series_id") or self.seriesItem.get("stream_id")
        self["desc"].setText(tr("Loading series details..."))

        def worker():
            try:
                data = get_source_client(dict(self.source)).series_info(sid) or {}
                if reactor:
                    reactor.callFromThread(self._seriesReady, data)
                else:
                    self._seriesReady(data)
            except Exception as exc:
                if reactor:
                    reactor.callFromThread(self._seriesFailed, str(exc))
                else:
                    self._seriesFailed(str(exc))

        thread = threading.Thread(target=worker, name="TiviMateSeriesDetails")
        thread.daemon = True
        thread.start()

    def _seriesReady(self, data):
        try:
            self.seriesData = data or {}
            info = self.seriesData.get("info") or {}
            title = info.get("name") or self.seriesItem.get("name") or "مسلسل"
            year = info.get("releaseDate") or info.get("releasedate") or info.get("year") or ""
            rating = info.get("rating") or info.get("rating_5based") or ""
            genre = info.get("genre") or ""
            cast = info.get("cast") or info.get("actors") or ""
            director = info.get("director") or ""
            self["title"].setText(title)
            self["rating"].setText(str(rating)[:4] if rating else "--")
            self["meta"].setText("  •  ".join(x for x in [str(year), str(genre)] if x))
            cast_text = []
            if cast:
                cast_text.append("طاقم الممثلين: %s" % str(cast)[:150])
            if director:
                cast_text.append("المخرج: %s" % str(director)[:90])
            self["cast"].setText("\n".join(cast_text))
            self["desc"].setText((info.get("plot") or info.get("description") or "لا توجد معلومات")[:720])
            self.seriesFallbackPoster = self._normImage(
                info.get("cover_big") or info.get("cover") or self.seriesItem.get("cover") or
                self.seriesItem.get("stream_icon") or ""
            )
            self.seriesBackdrop = self._normImage(
                info.get("backdrop_path") or info.get("backdrop") or info.get("backdrop_url") or
                self.seriesItem.get("backdrop_path") or self.seriesItem.get("backdrop") or ""
            )
            if not self.seriesBackdrop:
                self.seriesBackdrop = self.seriesFallbackPoster
            if self.seriesBackdrop:
                self.loadBackdrop(self.seriesBackdrop)

            raw = self.seriesData.get("episodes") or {}
            self.episodesBySeason = {str(key): (value or []) for key, value in raw.items() if value}
            seasons = self.seriesData.get("seasons") or []
            self.seasonItems = []
            if seasons:
                for season in seasons:
                    number = str(season.get("season_number") if season.get("season_number") is not None else season.get("season") or "")
                    if self.episodesBySeason.get(number):
                        row = dict(season)
                        row["_num"] = number
                        self.seasonItems.append(row)
            if not self.seasonItems:
                for number in sorted(self.episodesBySeason.keys(), key=lambda value: int(value) if str(value).isdigit() else 999):
                    self.seasonItems.append({"_num": number, "name": "الموسم %s" % number})
            self.seasonIndex = 0
            self.selectSeason()
        except Exception as exc:
            self._seriesFailed(str(exc))

    def _seriesFailed(self, error):
        self["desc"].setText("تعذر تحميل المسلسل\n%s" % error)

    def _setVisible(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def selectSeason(self):
        if not self.seasonItems:
            self.episodeItems = []
            self["seasonInfo"].setText(tr("No seasons"))
            self.renderEpisodes()
            return
        self.seasonIndex = max(0, min(self.seasonIndex, len(self.seasonItems) - 1))
        season = self.seasonItems[self.seasonIndex]
        num = str(season.get("_num", ""))
        self.episodeItems = self.episodesBySeason.get(num, []) or []
        season_name = season.get("name") or "الموسم %s" % num
        self["seasonInfo"].setText("%s  /  %d حلقة" % (season_name, len(self.episodeItems)))
        self.episodePage = 0
        self.episodeIndex = 0
        self.renderEpisodes()

    def renderEpisodes(self):
        self.downloads = []
        self.picloads = []
        for slot in range(5):
            idx = self.episodePage + slot
            item = self.episodeItems[idx] if idx < len(self.episodeItems) else None
            self._setVisible("episode%d" % slot, bool(item))
            self._setVisible("episodeLabel%d" % slot, bool(item))
            if not item:
                self["episodeLabel%d" % slot].setText(tr(""))
                continue
            ep = item.get("episode_num") or item.get("episode_number") or (idx + 1)
            title = item.get("title") or item.get("name") or "الحلقة %s" % ep
            self["episodeLabel%d" % slot].setText("E%s. %s" % (ep, title[:27]))
            self._placeholder(slot)
            inf = item.get("info") or {}
            url = self._normImage(
                item.get("movie_image") or item.get("cover") or item.get("stream_icon") or
                inf.get("movie_image") or inf.get("cover_big") or inf.get("cover") or
                self.seriesBackdrop or self.seriesFallbackPoster
            )
            if url:
                self._loadThumb(slot, url, (330, 186))
        self._setVisible("episodeSelector", bool(self.episodeItems))
        self._moveSelector()
        self.previewEpisode()

    def _placeholder(self, slot):
        try:
            self["episode%d" % slot].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "episode_placeholder.png"))
        except Exception:
            pass

    def _loadThumb(self, slot, url, size):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_episode_artwork_requests", None)
        if requests is None:
            requests = {}
            self._episode_artwork_requests = requests
        requests[slot] = url

        def done(path, s=slot, sz=size, expected=url):
            if getattr(self, "_episode_artwork_requests", {}).get(s) != expected:
                return
            self._decodeThumb(s, path, sz)

        request_artwork(url, "episodes", done, priority=45)

    def _decodeThumb(self, slot, path, size):
        loader = ePicLoad()
        self.picloads.append(loader)
        def ready(_info=None, s=slot, l=loader):
            try:
                ptr = l.getData()
                if ptr and self["episode%d" % s].instance:
                    self["episode%d" % s].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        loader.PictureData.get().append(ready)
        render_width, render_height = scale_size(size[0], size[1])
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def _moveSelector(self):
        try:
            self["episodeSelector"].instance.move(ePoint(sx(self.EPISODE_X[self.episodeIndex] - 8), sy(632)))
        except Exception:
            pass

    def left(self):
        idx = self.episodePage + self.episodeIndex
        if idx <= 0:
            return
        if self.episodeIndex > 0:
            self.episodeIndex -= 1
        else:
            self.episodePage = max(0, self.episodePage - 5)
            self.episodeIndex = min(4, len(self.episodeItems) - self.episodePage - 1)
            self.renderEpisodes()
        self._moveSelector()
        self.previewEpisode()

    def right(self):
        idx = self.episodePage + self.episodeIndex
        if idx + 1 >= len(self.episodeItems):
            return
        if self.episodeIndex < 4 and self.episodeIndex + 1 < len(self.episodeItems) - self.episodePage:
            self.episodeIndex += 1
        else:
            self.episodePage += 5
            self.episodeIndex = 0
            self.renderEpisodes()
        self._moveSelector()
        self.previewEpisode()

    def up(self):
        if self.seasonIndex > 0:
            self.seasonIndex -= 1
            self.selectSeason()

    def down(self):
        if self.seasonIndex + 1 < len(self.seasonItems):
            self.seasonIndex += 1
            self.selectSeason()

    def previewEpisode(self):
        idx = self.episodePage + self.episodeIndex
        ep = self.episodeItems[idx] if 0 <= idx < len(self.episodeItems) else None
        if not ep:
            self["episodeInfo"].setText(tr(""))
            return
        inf = ep.get("info") or {}
        num = ep.get("episode_num") or ep.get("episode_number") or (idx + 1)
        title = ep.get("title") or ep.get("name") or "الحلقة %s" % num
        duration = inf.get("duration") or ep.get("duration") or ""
        plot = inf.get("plot") or inf.get("description") or ep.get("plot") or ""
        info = "الحلقة %s  •  %s" % (num, title)
        if duration:
            info += "  •  %s" % duration
        if plot:
            info += "    %s" % str(plot)[:180]
        self["episodeInfo"].setText(info)

    def toggleFavourite(self):
        added, saved = toggle_favourite(self.source, "series", self.seriesItem)
        title = self.seriesItem.get("name") or self.seriesItem.get("title") or "المسلسل"
        if not saved:
            self["keys"].setText(tr("Unable to save favorite"))
        elif added:
            self["keys"].setText("★ تمت إضافة %s إلى المفضلات" % title)
        else:
            self["keys"].setText("☆ تمت إزالة %s من المفضلات" % title)

    def addSeriesFavourite(self):
        if is_favourite(self.source, "series", self.seriesItem):
            self["keys"].setText(tr("Series is already in favorites"))
        elif add_favourite(self.source, "series", self.seriesItem):
            self["keys"].setText(tr("Series added to favorites"))
        else:
            self["keys"].setText(tr("Unable to save favorite"))

    def ok(self):
        idx = self.episodePage + self.episodeIndex
        if not (0 <= idx < len(self.episodeItems)):
            return
        ep = dict(self.episodeItems[idx] or {})
        series_title = self.seriesItem.get("name") or self.seriesItem.get("title") or ""
        episode_info = ep.get("info") or {}
        if not isinstance(episode_info, dict):
            episode_info = {}
        episode_cover = self._normImage(
            ep.get("movie_image") or ep.get("cover") or ep.get("stream_icon") or ep.get("poster_path") or
            episode_info.get("movie_image") or episode_info.get("cover_big") or episode_info.get("cover") or
            episode_info.get("poster_path") or self.seriesFallbackPoster
        )
        if episode_cover:
            # The player consumes this normalised value before generic artwork fields.
            ep["_player_cover"] = episode_cover
        ep["_subdl_type"] = "tv"
        ep["_subdl_title"] = series_title
        ep["_subdl_season"] = self.seasonItems[self.seasonIndex].get("_num", "") if self.seasonItems else ""
        ep["_subdl_episode"] = ep.get("episode_num") or ep.get("episode_number") or (idx + 1)
        try:
            if self.source.get("type") == "stalker":
                url = StalkerClient(self.source).stream_url(ep, "series")
            else:
                url = XtreamClient(self.source).episode_url(ep)
            service = eServiceReference(4097, 0, url)
            service.setName(ep.get("title") or ep.get("name") or "حلقة")
            self.session.open(TiviMatePlayer, service, ep)
        except Exception as exc:
            self.session.open(MessageBox, "تعذر تشغيل الحلقة\n%s" % exc, MessageBox.TYPE_ERROR)

    def loadBackdrop(self, url):
        url = self._normImage(url)
        if not url:
            return
        self._series_backdrop_request = url

        def done(path, expected=url):
            if getattr(self, "_series_backdrop_request", "") != expected:
                return
            self.decodeBackdrop(path)

        request_artwork(url, "backdrops", done, priority=115)

    def decodeBackdrop(self, path):
        loader = ePicLoad()
        self.backdropLoader = loader
        def ready(_info=None, l=loader):
            try:
                ptr = l.getData()
                if ptr and self["backdrop"].instance:
                    self["backdrop"].instance.setPixmap(ptr)
            except Exception:
                pass
            finally:
                try:
                    if self.backdropLoader is l:
                        self.backdropLoader = None
                except Exception:
                    pass
        loader.PictureData.get().append(ready)
        render_width, render_height = scale_size(1920, 1080)
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)


class MediaScreen(Screen):
    POSTER_X = [70, 450, 830, 1210, 1590]

    def __init__(self, session, source, kind, initialCategoryId=None, initialCategoryName=None):
        if kind == "live":
            # Live has its own remembered server. Movies and TV Shows continue
            # using the Home/server-manager selection independently.
            source = _load_live_source(source)
            # Home skins do not change Live: keep the stable, Picon-enabled list.
            # This layout intentionally has no visible EPG grid.
            self.skin = _live_skin_with_style(_load_channel_settings().get("live_theme", "turquoise"))
        else:
            self.skin = VOD
        Screen.__init__(self, session)
        self.source = source
        self.kind = kind
        self.initialCategoryId = str(initialCategoryId or "")
        self.initialCategoryName = initialCategoryName or ""
        self.mediaItems = []
        self.mediaItemsCurrent = []
        self.categories = []
        self.focus = "items"
        self.posterIndex = 0
        self.searchQuery = ""
        self.sortMode = "default"
        self.lastCategoryItems = []
        self.pageStart = 0
        self.downloads = []
        self.picloads = []
        self["brand"] = Label("tv")
        self["rail"] = MenuList([("▣  تلفاز", "live"), ("▤  أفلام", "vod"), ("▥  مسلسلات", "series")])
        self["title"] = Label("%s  •  %s" % (source.get("name", "IPTV"), {"live":tr("LIVE TV"), "vod":tr("MOVIES"), "series":tr("TV SHOWS")}.get(kind, kind)))
        self["category"] = LiveCategoryMenuList([]) if kind == "live" else MenuList([])
        if kind != "live":
            self.topNames = [tr("Search"), tr("Home"), tr("Live"), tr("Movies"), tr("TV Shows")]
            self.topIndex = 3 if kind == "vod" else 4
            self.topX = [90, 285, 480, 675, 870]
            for _i, _name in enumerate(self.topNames):
                self["top%d" % _i] = Label(_name)
            self["topSelector"] = Pixmap()
            self["sectionTitle"] = Label(tr("MOVIE CATEGORIES") if kind == "vod" else tr("TV SHOW CATEGORIES"))
            self["searchIcon"] = Label("⌕")
            self["filterIcon"] = Label("☰")
            self["currentCategory"] = Label("")
        self["channelTitle"] = Label(tr("Select a package") if kind == "live" else tr("Select a category"))
        self["nowLabel"] = Label(tr("CONTENT"))
        self["meta"] = Label("")
        self["desc"] = Label(tr("Loading packages...") if kind == "live" else tr("Loading categories..."))
        if kind == "live":
            self["epgNowTime"] = Label("")
            self["epgNowTitle"] = Label("")
            self["epgNextTime"] = Label("")
            self["epgNextTitle"] = Label("")
            self["epgProgressText"] = Label("")
            from Components.ProgressBar import ProgressBar
            self["liveProgress"] = ProgressBar()
            self["livePoster"] = Pixmap()
            self["list"] = MenuList([])
            self["channelPicon"] = Pixmap()
            self["pageInfo"] = Label("")
            self["styleHint"] = Label("YELLOW  SWITCH SERVER  •  %s" % self.source.get("name", "SERVER"))
            
            # Test10: channel rows are text-only; no row Picon widgets, decoders or timers.
            self.rowPiconLoaders = []
            self.rowPiconPaths = {}
            self.rowPiconPending = False
            self.rowPiconToken = 0
            self.rowPiconTimer = eTimer()
            self["clockTitle"] = Label("")
            self["categoryTitle"] = Label(tr("PACKAGES"))
            # Live browsing stays focused on channel lists, logos, and playback.
            self.channelSettings = _load_channel_settings()
            self.zapTimer = eTimer()
            try: self.zapTimer.callback.append(self._autoZapCurrent)
            except Exception: self.zapTimer.timeout.get().append(self._autoZapCurrent)
            self.livePiconLoader = ePicLoad()
            try: self.livePiconLoader.PictureData.get().append(self._livePiconDecoded)
            except Exception: pass
            self.livePiconDownload = None
            self.livePiconToken = 0
            self.livePiconTimer = eTimer()
            try: self.livePiconTimer.callback.append(self._finishLivePicon)
            except Exception: self.livePiconTimer.timeout.get().append(self._finishLivePicon)
            # TMDb Live poster is isolated from playback/EPG and starts only after a long idle.
            self.livePosterToken = 0
            self.livePosterResult = None
            self.livePosterTimer = eTimer()
            try: self.livePosterTimer.callback.append(self._startLivePosterLookup)
            except Exception: self.livePosterTimer.timeout.get().append(self._startLivePosterLookup)
            self.livePosterPoll = eTimer()
            try: self.livePosterPoll.callback.append(self._finishLivePosterLookup)
            except Exception: self.livePosterPoll.timeout.get().append(self._finishLivePosterLookup)
            self.livePosterLoader = ePicLoad()
            try: self.livePosterLoader.PictureData.get().append(self._livePosterDecoded)
            except Exception: pass
            self.livePosterPath = ""
            try: self["livePoster"].hide()
            except Exception: pass
            # Test30: provider-direct EPG fallback for every Xtream server.
            self.directEpgToken = 0
            self.directEpgResult = None
            self.directEpgTimer = eTimer()
            try: self.directEpgTimer.callback.append(self._finishDirectEpg)
            except Exception: self.directEpgTimer.timeout.get().append(self._finishDirectEpg)
            except Exception: self.livePiconTimer.timeout.get().append(self._finishLivePicon)
            try: self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
            except Exception: self.oldService = None
            self.lastZappedLiveId = None
            self.keepCurrentLiveService = False
        else:
            self["backdrop"] = Pixmap()
            for i in range(5):
                self["poster%d" % i] = Pixmap()
                self["posterLabel%d" % i] = Label("")
                self["posterRate%d" % i] = Label("")
            self["selector"] = Pixmap()
            self.backdropLoader = None
            self.backdropDownloader = None
            self.infoTimer = eTimer()
            try: self.infoTimer.callback.append(self.loadSelectedInfo)
            except Exception: self.infoTimer.timeout.get().append(self.loadSelectedInfo)
            self.fullInfoCache = {}
            self.infoProcesses = {}
            self.pendingInfoId = ""
        self.categoryLoadToken = 0
        self.categoryLoadResult = None
        self.categoryLoadTimer = eTimer()
        try: self.categoryLoadTimer.callback.append(self._finishCategoryLoad)
        except Exception: self.categoryLoadTimer.timeout.get().append(self._finishCategoryLoad)
        # Catalog requests are independent from category item requests.  This keeps
        # opening any table responsive even when a provider is slow or unavailable.
        self.catalogLoadToken = 0
        self.catalogLoadResult = None
        self.catalogLoadTimer = eTimer()
        try: self.catalogLoadTimer.callback.append(self._finishCatalogLoad)
        except Exception: self.catalogLoadTimer.timeout.get().append(self._finishCatalogLoad)
        self["keys"] = Label(tr("LEFT/RIGHT Navigate    UP/DOWN Pages    OK Select    RED Previous Category    BLUE Next Category    MENU Favorite    GREEN Packages/Categories    YELLOW Sort    EXIT Back")) if kind != "live" else Label("")
        self["guideBar"] = Pixmap()
        if kind == "live": self._updateLiveKeys()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions", "InfoActions", "NumberActions"], {
            "ok": self.ok, "cancel": self.cancelAction, "up": self.up, "down": self.down,
            "left": self.left, "right": self.right,
            "red": self.toggleCurrentFavourite if kind == "live" else self.previousCategory,
            "blue": self.openLiveColorMenu if kind == "live" else self.nextCategory,
            "green": self.openLiveFilter if kind == "live" else self.openCategoryMenu,
            "yellow": self.openLiveServerMenu if kind == "live" else self.toggleSort,
            "yellowlong": self.addCurrentFavourite,
            "menu": self.openFavorites,
            "info": self.openFavorites,
            "0": self.noAction
        }, -1)
        self.onLayoutFinish.append(self._prepareScreen)

    def noAction(self):
        return

    def openLiveServerMenu(self):
        if self.kind != "live":
            return
        sources = get_sources()
        if not sources:
            return self.session.open(MessageBox, tr("No server selected • Press SETTINGS"), MessageBox.TYPE_INFO)
        current_key = _source_identity(self.source)
        choices = []
        for candidate in sources:
            name = candidate.get("name") or candidate.get("url") or candidate.get("portal") or "SERVER"
            label = ("✓ " if _source_identity(candidate) == current_key else "") + name
            choices.append((label, candidate))
        self.session.openWithCallback(
            self._liveServerSelected, ChoiceBox,
            title="Switch Live server", list=choices
        )

    def _liveServerSelected(self, selected=None):
        if not selected:
            return
        try:
            source = selected[1]
        except Exception:
            return
        if not isinstance(source, dict):
            return
        _save_live_source(source)
        try:
            self.close()
            self.session.open(MediaScreen, dict(source), "live")
        except Exception:
            pass

    def openLiveColorMenu(self):
        if self.kind != "live":
            return
        current = self.channelSettings.get("live_theme", "turquoise")
        choices = []
        for name, value in LIVE_STYLE_CHOICES:
            label = ("✓ " if value == current else "") + name
            choices.append((label, value))
        self.session.openWithCallback(self._liveStyleSelected, ChoiceBox, title="Choose Live style", list=choices)

    def _liveStyleSelected(self, selected=None):
        if not selected:
            return
        try:
            theme = selected[1]
        except Exception:
            return
        if theme not in LIVE_STYLE_PALETTES:
            return
        self.channelSettings["live_theme"] = theme
        self.channelSettings["live_color"] = LIVE_STYLE_PALETTES[theme]["accent"]
        _save_channel_settings(self.channelSettings)
        source = dict(self.source)
        try:
            self.close()
            self.session.open(MediaScreen, source, "live")
        except Exception:
            pass

    def openFavorites(self):
        self.session.open(FavoritesScreen)

    def _moveCategory(self, direction):
        """Move through VOD/series categories without reopening or redesigning the screen."""
        if self.kind == "live":
            return
        try:
            rows = list(self["category"].list or [])
        except Exception:
            rows = []
        if not rows:
            try:
                self["meta"].setText(tr("Loading packages/categories..."))
            except Exception:
                pass
            return
        try:
            current = int(self["category"].getSelectedIndex())
        except Exception:
            current = 0
        target = (current + int(direction)) % len(rows)
        try:
            self["category"].moveToIndex(target)
        except Exception:
            return
        try:
            selected = rows[target]
            self.initialCategoryName = selected[0] or ""
            self.initialCategoryId = str(selected[1] or "")
        except Exception:
            pass
        self.focus = "items"
        self.loadSelectedCategory()

    def previousCategory(self):
        self._moveCategory(-1)

    def nextCategory(self):
        self._moveCategory(1)

    def toggleCurrentFavourite(self):
        # Red toggles the highlighted Live channel: add when absent, remove when saved.
        item = None
        try:
            current_row = self["list"].getCurrent()
            item = current_row[1] if current_row else None
        except Exception:
            item = self.current()
        if not isinstance(item, dict):
            try:
                self["meta"].setText(tr("Open a package, select a channel, then press RED"))
            except Exception:
                pass
            return
        title = item.get("name") or item.get("title") or "Channel"
        try:
            added, saved = toggle_favourite(self.source, "live", item)
            if not saved:
                message = "Unable to update favorites"
            elif added:
                message = "★ Added %s to FAVORITES" % title
            else:
                message = "☆ Removed %s from FAVORITES" % title
                # When the user removes a row while viewing FAVORITES, refresh the
                # local list immediately. The provider package remains untouched.
                try:
                    if self.selectedCategory() == "__favorites__":
                        self.loadSelectedCategory()
                except Exception:
                    pass
            self["meta"].setText(message)
        except Exception as exc:
            try:
                self["meta"].setText("Favorites error: %s" % exc)
            except Exception:
                pass

    def addCurrentFavourite(self):
        # Long yellow is add-only for Movies and TV Shows.  The normal yellow key
        # remains sorting, and the Live action map deliberately stays untouched.
        if self.kind not in ("vod", "series"):
            return
        item = self.current()
        if not item:
            try:
                self["meta"].setText(tr("Select a movie or TV show first"))
            except Exception:
                pass
            return
        if is_favourite(self.source, self.kind, item):
            message = "Item is already in favorites"
        elif add_favourite(self.source, self.kind, item):
            message = "Added to favorites"
        else:
            message = "Unable to save favorite"
        try:
            self["meta"].setText(message)
        except Exception:
            pass

    def _updateTopFocus(self):
        if self.kind == "live":
            return
        try:
            self["topSelector"].instance.move(ePoint(sx(self.topX[self.topIndex]), sy(75)))
            self["topSelector"].setVisible(self.focus == "top")
        except Exception:
            pass

    def _openTopItem(self):
        if self.kind == "live":
            return
        if self.topIndex == 0:
            return self.session.open(TiviMateE2Search, self.source)
        if self.topIndex == 1:
            return self.session.open(TiviMateE2Home)
        if self.topIndex == 2:
            return self.session.open(MediaScreen, self.source, "live")
        if self.topIndex == 3:
            return self.session.open(ContentHomeScreen, self.source, "vod")
        if self.topIndex == 4:
            return self.session.open(ContentHomeScreen, self.source, "series")

    def openCategoryMenu(self):
        if self.kind == "live":
            return
        try:
            from .content_home import ServerCategoryList
            self.session.openWithCallback(self._categoryMenuSelected, ServerCategoryList, self.source, self.kind)
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open packages/categories:\n%s" % exc, MessageBox.TYPE_ERROR)

    def _categoryMenuSelected(self, selected=None):
        if not selected:
            return
        cid = str(selected.get("id") or "")
        name = selected.get("name") or ""
        self.initialCategoryId = cid
        self.initialCategoryName = name
        try:
            for pos, row in enumerate(self["category"].list):
                if str(row[1]) == cid:
                    self["category"].moveToIndex(pos)
                    break
        except Exception:
            pass
        self.focus = "items"
        self.loadSelectedCategory()

    def _prepareScreen(self):
        try:
            idx = {"live": 0, "vod": 1, "series": 2}.get(self.kind, 0)
            self["rail"].moveToIndex(idx)
        except Exception:
            pass
        self.updateSectionLabels()
        if self.kind != "live":
            self._updateTopFocus()
        if self.kind == "live":
            self._updateLiveClock()
            try: self["styleHint"].setText("YELLOW  SWITCH SERVER  •  %s" % self.source.get("name", "SERVER"))
            except Exception: pass
        self.loadCategories()

    def currentRailSection(self):
        current = self["rail"].getCurrent()
        return current[1] if current else self.kind

    def updateSectionLabels(self):
        label = {"live": "LIVE TV", "vod": "MOVIES", "series": "TV SHOWS"}.get(self.kind, self.kind)
        self["title"].setText("%s  •  %s" % (self.source.get("name", "IPTV"), label))
        if self.kind != "live":
            self["sectionTitle"].setText(tr("MOVIE CATEGORIES") if self.kind == "vod" else tr("TV SHOW CATEGORIES"))
            self["searchIcon"].setText(tr(""))

    def switchSection(self, section):
        if section == self.kind:
            self.focus = "category"
            return
        if section == "live":
            self.session.open(MediaScreen, self.source, "live")
            return
        self.kind = section
        self.focus = "category"
        self.searchQuery = ""
        self.sortMode = "default"
        self.mediaItems = []
        self.mediaItemsCurrent = []
        self.lastCategoryItems = []
        self.categories = []
        self.pageStart = 0
        self.posterIndex = 0
        try:
            self.infoTimer.stop()
        except Exception:
            pass
        self["category"].setList([])
        self["channelTitle"].setText(tr("Select a category"))
        self["meta"].setText(tr(""))
        self["desc"].setText(tr("Loading categories..."))
        self["currentCategory"].setText(tr(""))
        self.updateSectionLabels()
        self.loadCategories()

    def loadCategories(self):
        """Load provider catalog data outside Enigma2's UI thread.

        Category lists are shared by LIVE, VOD, and Series.  The former direct
        provider calls could block every table while DNS/HTTP/M3U parsing ran.
        r87 shows a lightweight loading message and applies the ready result from
        a timer callback only after the worker has completed.
        """
        self.catalogLoadToken += 1
        token = self.catalogLoadToken
        source = dict(self.source)
        kind = self.kind
        self.catalogLoadResult = None
        try:
            self["category"].setList([])
            self["list"].setList([])
        except Exception:
            pass
        try:
            self["desc"].setText("Loading catalog in background..." if kind == "live" else "Preparing the list in background...")
        except Exception:
            pass

        def worker():
            try:
                source_type = source.get("type")
                if source_type in ("xtream", "stalker"):
                    categories, origin = get_cached_categories(source, kind, get_source_client(source), wait_for_server=True)
                    result = (token, source_type, categories or [], [], "", origin)
                elif source_type == "m3u":
                    entries, origin = get_cached_catalog(source, "live", lambda: M3UClient(source).entries(), wait_for_server=True)
                    result = (token, "m3u", [], entries or [], "", origin)
                else:
                    entries, origin = get_cached_catalog(source, "live", lambda: StalkerClient(source).channels(), wait_for_server=True)
                    result = (token, "stalker", [], entries or [], "", origin)
            except Exception as exc:
                result = (token, "error", [], [], str(exc), "")
            self.catalogLoadResult = result

        threading.Thread(target=worker, name="TiviMateE2Catalog", daemon=True).start()
        try:
            self.catalogLoadTimer.start(120, False)
        except Exception:
            pass

    def _finishCatalogLoad(self):
        result = self.catalogLoadResult
        if not result:
            try:
                self.catalogLoadTimer.start(120, False)
            except Exception:
                pass
            return
        self.catalogLoadResult = None
        token, mode, categories, items, error, origin = result
        if token != self.catalogLoadToken:
            return
        if mode == "retry_series":
            try:
                self["desc"].setText(tr("Preparing series categories in the background..."))
                self.catalogLoadTimer.start(500, False)
                self.catalogLoadResult = (token, "restart", [], [], "", "")
            except Exception:
                pass
            return
        if mode == "restart":
            self.loadCategories()
            return
        if mode == "error":
            try:
                self["desc"].setText(("Unable to load catalog:\\n%s" % error) if self.kind == "live" else ("خطأ في التحميل:\\n%s" % error))
            except Exception:
                pass
            return
        if mode in ("xtream", "stalker"):
            allowed_ids = get_allowed_category_ids(self.source, self.kind)
            blocked = {"all", "all movies", "all films", "all vod", "all series", "كل الأفلام", "جميع الأفلام", "كل افلام", "جميع افلام", "كل المسلسلات", "جميع المسلسلات", "كل المحتوى"}
            rows = []
            filtered = []
            for entry in categories:
                name = (entry.get("category_name") or "Other").strip()
                cid = str(entry.get("category_id", ""))
                if allowed_ids is not None and cid not in allowed_ids:
                    continue
                if self.kind in ("vod", "series") and name.lower() in blocked:
                    continue
                filtered.append(entry)
                rows.append((name, cid))
            if self.kind == "live":
                special = [
                    {"category_name": u"★  " + tr("FAVORITES"), "category_id": "__favorites__"},
                    {"category_name": u"＋  " + tr("RECENTLY ADDED"), "category_id": "__recent_added__"},
                ]
                filtered = special + filtered
                rows = [(entry.get("category_name") or "", str(entry.get("category_id") or "")) for entry in filtered]
            self.categories = filtered
            try:
                self["category"].setList(rows)
            except Exception:
                return
            if not rows:
                if self.source.get("type") == "stalker" and origin == "empty":
                    self["desc"].setText(tr("Stalker returned no packages. Check Portal URL and MAG MAC, then retry."))
                else:
                    self["desc"].setText("No packages available." if self.kind == "live" else "No categories available.")
                return
            had_initial_category = bool(self.initialCategoryId)
            if self.initialCategoryId:
                for pos, row in enumerate(rows):
                    if str(row[1]) == self.initialCategoryId:
                        try:
                            self["category"].moveToIndex(pos)
                        except Exception:
                            pass
                        break
                self.initialCategoryId = ""
            if self.kind == "series" and not had_initial_category:
                self.focus = "category"
                self["channelTitle"].setText(tr("Select a series category"))
                self["desc"].setText(tr("Select the category then press OK. Only this category will be loaded."))
            elif self.kind == "live":
                self.focus = "category"
                self["categoryTitle"].setText(tr("PACKAGES"))
                self["channelTitle"].setText(tr("Select a package"))
                self["desc"].setText(tr("Select a package") + " - OK")
                self._hideRowPicons()
            else:
                self.loadSelectedCategory()
                self.focus = "items"
            return
        if mode == "m3u":
            self.mediaItems = items
            groups = sorted(set(entry.get("group", "Other") for entry in self.mediaItems))
            self.categories = [{"category_name": group, "category_id": group} for group in groups]
            rows = [(group, group) for group in groups]
            if self.kind == "live":
                rows = [(u"★  " + tr("FAVORITES"), "__favorites__"), (u"＋  " + tr("RECENTLY ADDED"), "__recent_added__")] + rows
                self.categories = [
                    {"category_name": name, "category_id": cid} for name, cid in rows
                ]
            self["category"].setList(rows)
            if self.kind == "live" and rows:
                self.focus = "category"
                self["categoryTitle"].setText(tr("PACKAGES"))
                self["channelTitle"].setText(tr("Select a package"))
                self["desc"].setText(tr("Select a package") + " - OK")
                self._hideRowPicons()
            elif rows:
                self.loadSelectedCategory()
                self.focus = "items"
            else:
                self["desc"].setText("No packages available." if self.kind == "live" else "No categories available.")
            return
        # Stalker has a single, already-built channel group.
        self.mediaItems = items
        self["category"].setList([("All Channels", "")])
        self.showItems(self.mediaItems)

    def selectedCategory(self):
        # LIVE categories are always selected from the left category widget.
        c = self["category"].getCurrent()
        return c[1] if c else ""

    def loadSelectedCategory(self):
        cid=self.selectedCategory()
        c = self["category"].getCurrent()
        name=c[0] if c else ""
        if self.kind == "live" and cid == "__favorites__":
            source_key = favourite_source_id(self.source)
            items = []
            for record in list_favourites("live"):
                if record.get("source_id") != source_key:
                    continue
                item = dict(record.get("item") or {})
                if item:
                    items.append(item)
            self._applyCategoryItems(items, tr("FAVORITES"), "local")
            if not items:
                self["desc"].setText(tr("No favorite channels yet. Add channels with the red button."))
            return
        if self.kind == "live" and cid == "__recent_added__":
            self._loadRecentlyAdded()
            return
        if not cid and self.source.get("type") in ("xtream", "stalker"):
            return
        self["desc"].setText(("Loading %s..." % name) if self.kind == "live" else ("جاري تحميل %s..." % name))
        if self.source.get("type") in ("xtream", "stalker") and self.kind in ("live", "vod", "series"):
            self.categoryLoadToken += 1
            token = self.categoryLoadToken
            self.categoryLoadResult = None
            source = dict(self.source)
            kind = self.kind
            def worker():
                try:
                    items, origin = get_category_streams(source, kind, get_source_client(source), cid, use_cache=True, wait_for_server=(kind != "series"))
                    result = (token, items or [], origin, "", name)
                except Exception as exc:
                    result = (token, [], "error", str(exc), name)
                self.categoryLoadResult = result
            threading.Thread(target=worker, name="TiviMateE2Category", daemon=True).start()
            try: self.categoryLoadTimer.start(120, False)
            except Exception: pass
            return
        try:
            if self.source.get("type") in ("xtream", "stalker"): items=get_source_client(self.source).streams(self.kind,cid)
            elif self.source.get("type")=="m3u": items=[x for x in self.mediaItems if x.get("group")==cid]
            else: items=self.mediaItems
            self._applyCategoryItems(items or [], name, "server")
        except Exception as e:
            self.mediaItemsCurrent=[]
            if self.kind=="live": self["list"].setList([])
            self["desc"].setText(("Unable to load package:\n%s" % e) if self.kind == "live" else ("تعذر تحميل التصنيف:\n%s" % e))

    def _recentAddedTimestamp(self, item):
        for key in ("added", "added_at", "created_at", "date_added", "timestamp"):
            value = item.get(key)
            if value in (None, ""):
                continue
            try:
                return int(float(value))
            except Exception:
                pass
            try:
                import datetime
                value = str(value).replace("Z", "").split(".")[0]
                return int(time.mktime(datetime.datetime.strptime(value[:19], "%Y-%m-%d %H:%M:%S").timetuple()))
            except Exception:
                pass
        return 0

    def _recentStateKey(self, source):
        raw = "%s|%s|%s|%s" % (
            source.get("type", ""), source.get("url", "").rstrip("/"),
            source.get("username", ""), source.get("mac", ""))
        try:
            raw = raw.encode("utf-8")
        except Exception:
            pass
        return hashlib.sha1(raw).hexdigest()

    def _recentIdentity(self, item, order=0):
        return str(item.get("stream_id") or item.get("id") or item.get("url") or
                   item.get("cmd") or item.get("name") or order)

    def _loadRecentlyAdded(self):
        """Load genuinely recent Live channels for the active server.

        Xtream is fetched in one complete request so category cache gaps cannot
        corrupt the result. Provider ``added`` timestamps are preferred when
        present; snapshot comparison is the fallback for Stalker/M3U providers.
        """
        self["desc"].setText(tr("Loading recently added channels..."))
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self.categoryLoadResult = None
        source = dict(self.source)
        current_items = list(self.mediaItems or [])

        def worker():
            try:
                client = get_source_client(source)
                stype = source.get("type")
                if stype == "m3u":
                    merged = current_items
                elif stype == "xtream":
                    merged = client.streams("live", "") or []
                elif stype == "stalker":
                    try:
                        merged = client.streams("live", "") or []
                    except Exception:
                        merged = client.live_streams("") or []
                else:
                    merged = current_items

                dedup = {}
                ordered_ids = []
                for order, item in enumerate(merged or []):
                    if not isinstance(item, dict):
                        continue
                    key = self._recentIdentity(item, order)
                    if key in dedup:
                        continue
                    dedup[key] = dict(item)
                    ordered_ids.append(key)

                state_path = os.path.join(BASE, "recent_live_state.json")
                all_state = load_json(state_path, {}) or {}
                state_key = self._recentStateKey(source)
                previous = all_state.get(state_key) or {}
                # Schema 2 invalidates snapshots produced by the old category-by-
                # category implementation, which could silently miss channels.
                if int(previous.get("schema", 0) or 0) != 2:
                    previous = {}
                known = set(str(value) for value in (previous.get("known") or []))
                existing_recent = previous.get("recent") or {}
                now = int(time.time())
                max_age = 30 * 24 * 60 * 60
                cutoff = now - max_age

                recent = {}
                # Provider timestamps are the most faithful source for Xtream.
                timestamped = 0
                for key in ordered_ids:
                    stamp = self._recentAddedTimestamp(dedup[key])
                    if stamp > 0:
                        timestamped += 1
                        if stamp >= cutoff and stamp <= now + 86400:
                            recent[key] = stamp

                # Preserve still-valid snapshot additions and detect new IDs on
                # providers that do not publish reliable timestamps.
                for key, seen_at in existing_recent.items():
                    try:
                        seen_at = int(seen_at)
                    except Exception:
                        continue
                    if key in dedup and now - seen_at <= max_age:
                        recent.setdefault(key, seen_at)
                if known:
                    for key in ordered_ids:
                        if key not in known and key not in recent:
                            recent[key] = now

                all_state[state_key] = {
                    "schema": 2,
                    "known": ordered_ids,
                    "recent": recent,
                    "updated": now,
                    "timestamped": timestamped,
                }
                save_json(state_path, all_state)

                recent_ids = [key for key in ordered_ids if key in recent]
                order_map = dict((key, pos) for pos, key in enumerate(ordered_ids))
                recent_ids.sort(key=lambda key: (recent.get(key, 0), order_map.get(key, 0)), reverse=True)
                items = [dedup[key] for key in recent_ids[:50]]
                result = (token, items, "recent_added", "", tr("RECENTLY ADDED"))
            except Exception as exc:
                result = (token, [], "error", str(exc), tr("RECENTLY ADDED"))
            self.categoryLoadResult = result

        threading.Thread(target=worker, name="TiviMateE2RecentAdded", daemon=True).start()
        try:
            self.categoryLoadTimer.start(120, False)
        except Exception:
            pass

    def _finishCategoryLoad(self):
        result = self.categoryLoadResult
        if not result:
            try: self.categoryLoadTimer.start(120, False)
            except Exception: pass
            return
        self.categoryLoadResult = None
        token, items, origin, error, name = result
        if token != self.categoryLoadToken:
            return
        if origin == "categories_loading":
            rows, cat_origin = get_cached_categories(self.source, "series")
            if not rows:
                self.categoryLoadResult = (token, [], "categories_loading", "", "")
                try: self.categoryLoadTimer.start(500, False)
                except Exception: pass
                return
            self.categories = rows
            allowed_ids = get_allowed_category_ids(self.source, self.kind)
            blocked = {"all", "all series", "كل المسلسلات", "جميع المسلسلات", "كل المحتوى"}
            menu=[]; filtered=[]
            for x in rows:
                cname=(x.get("category_name") or "Other").strip(); ccid=str(x.get("category_id", ""))
                if allowed_ids is not None and ccid not in allowed_ids: continue
                if cname.lower() in blocked: continue
                filtered.append(x); menu.append((cname, ccid))
            self.categories=filtered; self["category"].setList(menu)
            self["desc"].setText(tr("Select a series category then press OK.")) if menu else self["desc"].setText(tr("No categories available."))
            return
        if error:
            self.mediaItemsCurrent=[]
            self["desc"].setText(("Unable to load package:\n%s" % error) if self.kind == "live" else ("تعذر تحميل التصنيف:\n%s" % error))
            return
        if self.source.get("type") == "stalker" and origin == "empty":
            self.mediaItemsCurrent=[]
            if self.kind == "live":
                self["list"].setList([])
            self["desc"].setText(tr("Stalker returned no items for this package. Try another package or refresh the source."))
            return
        if origin == "loading" and self.kind == "series":
            cid = self.selectedCategory()
            cached, new_origin = get_category_streams(self.source, "series", get_source_client(self.source), cid, use_cache=True, wait_for_server=False)
            if not cached and new_origin == "loading":
                self["desc"].setText(tr("The category is preparing in the background... the interface will not freeze."))
                self.categoryLoadResult = (token, [], "loading", "", name)
                try: self.categoryLoadTimer.start(500, False)
                except Exception: pass
                return
            items, origin = cached, new_origin
        self._applyCategoryItems(items, name, origin)

    def _applyCategoryItems(self, items, name, origin="server"):
        self.lastCategoryItems = items or []
        if self.kind != "live":
            try:
                suffix = {"ram":" • ذاكرة", "disk":" • HDD", "stale":" • HDD • تحديث بالخلفية", "server":""}.get(origin, "")
                self["currentCategory"].setText(name + suffix)
            except Exception:
                pass
        if self.searchQuery:
            self.applySearch(self.searchQuery)
        else:
            self.showItems(self.lastCategoryItems)

    def showItems(self, items):
        self.mediaItemsCurrent = items or []
        self.pageStart = 0
        self.posterIndex = 0
        if self.kind == "live":
            rows = []
            for index, entry in enumerate(self.mediaItemsCurrent):
                name = entry.get("name") or entry.get("title") or "Unnamed Channel"
                rows.append(("%03d   %s" % (index + 1, name), entry))
            self["list"].setList(rows)
            try:
                self["list"].moveToIndex(0)
            except Exception:
                pass
            self.focus = "items"
            try:
                current = next((entry for entry in self.categories if str(entry.get("category_id", "")) == str(self.selectedCategory())), None)
                if current:
                    self["categoryTitle"].setText(current.get("category_name") or "القنوات")
                self["pageInfo"].setText("1 / %d" % len(self.mediaItemsCurrent) if self.mediaItemsCurrent else "0 / 0")
            except Exception:
                pass
            self._refreshVisibleRowPicons()
            self.previewLive()
        else:
            self.renderPosterPage()


    def current(self):
        if self.kind=="live":
            if self.focus != "items": return None
            c=self["list"].getCurrent(); return c[1] if c else None
        idx=self.pageStart+self.posterIndex
        return self.mediaItemsCurrent[idx] if 0 <= idx < len(self.mediaItemsCurrent) else None

    def previewLive(self):
        item = self.current()
        if not item:
            return
        self._refreshVisibleRowPicons()
        self["channelTitle"].setText(item.get("name") or item.get("title") or "Unnamed Channel")
        self["meta"].setText(tr(""))
        self._updateLiveEpg(item)
        self._scheduleLivePoster(item)
        try:
            index = self["list"].getSelectedIndex() + 1
            self["pageInfo"].setText("%d / %d" % (index, len(self.mediaItemsCurrent)))
        except Exception:
            pass
        self._showLivePicon(item)
        try:
            self.zapTimer.stop()
        except Exception:
            pass

    def _formatEpgTime(self, begin, duration=0):
        try:
            start = time.strftime("%H:%M", time.localtime(int(begin)))
            if duration:
                end = time.strftime("%H:%M", time.localtime(int(begin) + int(duration)))
                return "%s - %s" % (start, end)
            return start
        except Exception:
            return ""

    def _decodeEpgText(self, value):
        value = value or ""
        if not isinstance(value, str):
            try: value = str(value)
            except Exception: return ""
        # Xtream panels commonly return title/description as base64, but some
        # providers already return plain UTF-8. Decode only when it is valid.
        try:
            raw = value.strip()
            if raw and len(raw) % 4 == 0:
                decoded = base64.b64decode(raw).decode("utf-8", "replace").strip()
                if decoded and any(ch.isalnum() for ch in decoded):
                    return decoded
        except Exception:
            pass
        return value.strip()

    def _epgTimestamp(self, row, start=True):
        keys = ("start_timestamp", "start", "begin_timestamp", "begin") if start else ("stop_timestamp", "end", "end_timestamp", "stop")
        for key in keys:
            value = row.get(key)
            if value in (None, ""):
                continue
            try:
                return int(float(value))
            except Exception:
                try:
                    # Common panel format: 2026-08-02 03:30:00
                    return int(time.mktime(time.strptime(str(value)[:19], "%Y-%m-%d %H:%M:%S")))
                except Exception:
                    pass
        return 0

    def _startDirectEpg(self, item, fallback=""):
        if self.source.get("type") != "xtream":
            return False
        stream_id = str(item.get("stream_id") or "").strip()
        if not stream_id:
            return False
        self.directEpgToken += 1
        token = self.directEpgToken
        self.directEpgResult = None
        source = dict(self.source)
        def worker():
            result = []
            error = ""
            try:
                client = XtreamClient(source)
                payload = client.api("get_short_epg", stream_id=stream_id, limit=4)
                if isinstance(payload, dict):
                    result = payload.get("epg_listings") or payload.get("listings") or payload.get("epg") or []
                elif isinstance(payload, list):
                    result = payload
                if not isinstance(result, list):
                    result = []
            except Exception as exc:
                error = str(exc)
            self.directEpgResult = (token, result, fallback, error)
        threading.Thread(target=worker, name="TiviMateDirectEPG", daemon=True).start()
        try: self.directEpgTimer.start(120, False)
        except Exception: pass
        return True

    def _finishDirectEpg(self):
        result = self.directEpgResult
        if result is None:
            try: self.directEpgTimer.start(120, False)
            except Exception: pass
            return
        self.directEpgResult = None
        token, rows, fallback, error = result
        if token != self.directEpgToken:
            return
        now_ts = int(time.time())
        parsed = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._epgTimestamp(row, True)
            end = self._epgTimestamp(row, False)
            duration = max(0, end - begin)
            title = self._decodeEpgText(row.get("title") or row.get("name") or row.get("programme"))
            desc = self._decodeEpgText(row.get("description") or row.get("desc") or row.get("plot"))
            if begin and title:
                parsed.append((begin, duration, title, desc))
        parsed.sort(key=lambda x: x[0])
        current = None
        upcoming = None
        for event in parsed:
            begin, duration, title, desc = event
            finish = begin + duration if duration else begin + 3600
            if begin <= now_ts < finish:
                current = event
            elif begin > now_ts and upcoming is None:
                upcoming = event
        if current is None and parsed:
            # Some panels return only the nearest entries without reliable clock
            # offsets. Prefer the first entry rather than showing another channel.
            current = parsed[0]
            upcoming = parsed[1] if len(parsed) > 1 else upcoming
        if current:
            begin, duration, title, desc = current
            self["epgNowTime"].setText(self._formatEpgTime(begin, duration))
            self["epgNowTitle"].setText(title)
            elapsed = max(0, now_ts - begin)
            percent = min(100, max(0, int((elapsed * 100) / duration))) if duration > 0 else 0
            self["epgProgressText"].setText("%d%%" % percent)
            self["desc"].setText((desc or fallback or "No programme description.")[:600])
            if upcoming:
                ub, ud, ut, _ = upcoming
                self["epgNextTime"].setText(self._formatEpgTime(ub, ud))
                self["epgNextTitle"].setText(ut)
        else:
            self["epgNowTitle"].setText(tr("No EPG data"))
            self["desc"].setText(fallback or ("Provider EPG unavailable" if not error else "Provider EPG unavailable"))

    def _applyLocalEpgEvent(self, current, upcoming, fallback=""):
        now_ts = int(time.time())
        begin, duration, title, desc = current
        self["epgNowTime"].setText(self._formatEpgTime(begin, duration))
        self["epgNowTitle"].setText(title or "")
        elapsed = max(0, now_ts - int(begin))
        percent = min(100, max(0, int((elapsed * 100) / duration))) if duration > 0 else 0
        self["epgProgressText"].setText("%d%%" % percent)
        try: self["liveProgress"].setValue(percent)
        except Exception: pass
        self["desc"].setText((desc or fallback or "No programme description.")[:600])
        if upcoming:
            ub, ud, ut, _ = upcoming
            self["epgNextTime"].setText(self._formatEpgTime(ub, ud))
            self["epgNextTitle"].setText(ut or "")

    def _updateLiveEpg(self, item):
        """XKlass-compatible EPG: local XMLTV JSON first, eEPGCache second."""
        for key in ("epgNowTime", "epgNowTitle", "epgNextTime", "epgNextTitle", "epgProgressText"):
            try:
                self[key].setText(tr(""))
            except Exception:
                pass
        fallback = (item.get("plot") or item.get("description") or "").strip()

        # Read only the already-built filtered cache. Never download/parse XMLTV while Live is open.
        try:
            current, upcoming = lookup_channel_epg(self.source, item, int(time.time()))
            if current:
                self._applyLocalEpgEvent(current, upcoming, fallback)
                return
        except Exception:
            pass

        try:
            cache = eEPGCache.getInstance()
            ref_string = epg_reference_string(self.source, item)
            events = ["IBDTEX", (ref_string, -1, -1, -1)]
            rows = [] if cache is None else (cache.lookupEvent(events) or [])
            if rows:
                def event(row):
                    return (int(row[1] or 0), int(row[2] or 0), row[3] or "", row[4] or "")
                current = event(rows[0])
                upcoming = event(rows[1]) if len(rows) > 1 else None
                self._applyLocalEpgEvent(current, upcoming, fallback)
                return
        except Exception:
            pass

        self["epgNowTitle"].setText(tr("No EPG data"))
        try: self["liveProgress"].setValue(0)
        except Exception: pass
        self["desc"].setText(fallback or "Run EPG update from the plugin settings, then reopen Live.")

    def _cleanLiveProgrammeTitle(self, title):
        value = str(title or "").strip()
        value = re.sub(r"\s*[\-–—:]?\s*[Ss]\d{1,2}[Ee]\d{1,3}.*$", "", value)
        value = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", "", value)
        value = re.sub(r"\s+", " ", value).strip(" -:|")
        return value

    def _scheduleLivePoster(self, item):
        self.livePosterToken += 1
        self._livePosterItem = dict(item or {})
        self.livePosterResult = None
        try: self.livePosterTimer.stop()
        except Exception: pass
        try: self.livePosterPoll.stop()
        except Exception: pass
        try: self["livePoster"].hide()
        except Exception: pass
        poster_enabled = str(self.source.get("show_live_poster", "0")).strip().lower() in ("1", "true", "yes", "on", "enabled")
        if not poster_enabled:
            return

        # A known programme must never wait for TMDb again.  Resolve its stable
        # URL from the tiny title index, then decode the already cached file
        # immediately.  Only a first-time title uses the delayed TMDb lookup.
        title = self._cleanLiveProgrammeTitle(self["epgNowTitle"].getText())
        key = _live_poster_key(title)
        url = _load_live_poster_urls().get(key, "") if key else ""
        token = self.livePosterToken
        if url:
            cached = cached_artwork(url, "live_tmdb_poster")
            if cached:
                self._showLivePosterPath(cached, token)
                return
            # The URL is known but its file was removed.  Re-fetch directly in
            # the artwork queue without repeating a TMDb search or 12s delay.
            def ready(path):
                self._showLivePosterPath(path, token)
            request_artwork(url, kind="live_tmdb_poster", callback=ready, priority=25)
            return

        # First encounter only: keep network metadata work behind video startup.
        try: self.livePosterTimer.start(12000, True)
        except Exception: self.livePosterTimer.start(12000)

    def _startLivePosterLookup(self):
        item = getattr(self, "_livePosterItem", {}) or {}
        title = self._cleanLiveProgrammeTitle(self["epgNowTitle"].getText())
        if not title or title in ("No EPG data", "Loading EPG..."):
            return
        token = self.livePosterToken
        def worker():
            url = ""
            try:
                client = TMDbClient()
                result = client.search_title(title, "vod") or client.search_title(title, "series")
                path = (result or {}).get("poster_path") or ""
                if path:
                    url = IMAGE_BASE + "w342" + path
            except Exception:
                pass
            self.livePosterResult = (token, url)
        t = threading.Thread(target=worker, name="TiviMateLivePosterTMDb")
        t.daemon = True
        t.start()
        try: self.livePosterPoll.start(250, False)
        except Exception: pass

    def _showLivePosterPath(self, path, token=None):
        if token is not None and token != self.livePosterToken:
            return
        if not path or not os.path.exists(path):
            return
        self.livePosterPath = path
        try:
            self.livePosterLoader.setPara((150, 225, 1, 1, False, 1, "#00000000"))
            self.livePosterLoader.startDecode(path)
        except Exception:
            pass

    def _finishLivePosterLookup(self):
        result = self.livePosterResult
        if result is None:
            try: self.livePosterPoll.start(250, False)
            except Exception: pass
            return
        self.livePosterResult = None
        token, url = result
        if token != self.livePosterToken or not url:
            return
        title = self._cleanLiveProgrammeTitle(self["epgNowTitle"].getText())
        key = _live_poster_key(title)
        if key:
            _save_live_poster_url(key, url)
        def ready(path):
            self._showLivePosterPath(path, token)
        request_artwork(url, kind="live_tmdb_poster", callback=ready, priority=25)

    def _livePosterDecoded(self, picInfo=None):
        try:
            ptr = self.livePosterLoader.getData()
            if ptr is not None:
                self["livePoster"].instance.setPixmap(ptr)
                self["livePoster"].show()
        except Exception:
            pass

    def cancelAction(self):
        if self.kind == "live" and self.focus == "items":
            self.focus = "category"
            self["list"].setList([])
            self["categoryTitle"].setText(tr("PACKAGES"))
            self["channelTitle"].setText(tr("Select a package"))
            self["meta"].setText(tr(""))
            self["desc"].setText(tr("Select a package") + " - OK")
            self._hideRowPicons()
            return
        self.close()

    def _hideRowPicons(self):
        return

    def _refreshVisibleRowPicons(self):
        """Channel list is intentionally text-only for faster navigation."""
        self.rowPiconToken += 1
        self.rowPiconPaths = {}
        self.rowPiconPending = False
        self._hideRowPicons()

    def _finishRowPicons(self):
        self.rowPiconPaths = {}

    def _rowPiconDecoded(self, idx):
        return

    def _updateLiveClock(self):
        try:
            self["clockTitle"].setText(time.strftime("%Y/%m/%d   %H:%M", time.localtime()))
        except Exception:
            pass

    def _visibleLiveItems(self):
        items = self.mediaItemsCurrent or []
        if not items:
            return []
        try:
            idx = self["list"].getSelectedIndex()
        except Exception:
            idx = 0
        start = max(0, min(idx - 4, max(0, len(items) - 10)))
        return items[start:start + 10]

    def _updateLiveKeys(self):
        if self.kind != "live":
            return
        try:
            self["styleHint"].setText("YELLOW  SWITCH SERVER  •  %s" % self.source.get("name", "SERVER"))
        except Exception:
            pass

    def toggleAutoZap(self):
        if self.kind != "live": return
        self.channelSettings["auto_zap"] = not self.channelSettings.get("auto_zap", True)
        _save_channel_settings(self.channelSettings); self._updateLiveKeys()
        if self.channelSettings["auto_zap"]:
            try: self.zapTimer.stop()
            except Exception: pass
            self._autoZapCurrent()

    def toggleLivePicon(self):
        if self.kind != "live": return
        self.channelSettings["picon"] = not self.channelSettings.get("picon", True)
        _save_channel_settings(self.channelSettings); self._updateLiveKeys(); self.previewLive()

    def _zapLiveItem(self, item, force=False):
        if not item or self.kind != "live":
            return False
        try:
            live_id = str(item.get("stream_id") or item.get("id") or item.get("url") or item.get("cmd") or item.get("name") or "")
            if not force and live_id and live_id == self.lastZappedLiveId:
                return True
            if self.source.get("type") in ("xtream", "stalker"):
                url = get_source_client(self.source).stream_url(item, "live")
            elif self.source.get("type") == "m3u":
                url = item.get("url", "")
            else:
                url = ""
            if not url:
                return False
            service_type = int(self.channelSettings.get("service_type", 4097))
            ref = live_reference(self.source, item, service_type, url, item.get("name") or item.get("title") or "IPTV")
            self.session.nav.playService(ref)
            self.lastZappedLiveId = live_id
            self["meta"].setText(tr("Channel changed"))
            return True
        except Exception as exc:
            try:
                self["meta"].setText("Unable to change channel: %s" % exc)
            except Exception:
                pass
            return False

    def _autoZapCurrent(self):
        if not self.channelSettings.get("auto_zap", True):
            return
        self._zapLiveItem(self.current(), False)

    def _showLivePicon(self, item):
        """Always render a channel Picon in the neutral preview area.

        Each source can supply stream_icon/logo; when it does not, the built-in
        transparent fallback is decoded immediately.  This is source agnostic.
        """
        try:
            self["channelPicon"].show()
        except Exception:
            pass
        self.livePiconToken += 1
        token = self.livePiconToken
        fallback = os.path.join(PLUGIN_PATH, "skins", "live_picon_fallback_r103.png")
        self.livePiconDownload = (token, fallback)
        try:
            self.livePiconTimer.start(1, True)
        except Exception:
            pass
        url = (item.get("stream_icon") or item.get("logo") or "").strip()
        if not url:
            return
        def ready(path, expected=token):
            if expected != self.livePiconToken or not path:
                return
            self.livePiconDownload = (expected, path)
            try:
                self.livePiconTimer.start(1, True)
            except Exception:
                pass
        try:
            request_artwork(url, "logos", ready, priority=50)
        except Exception:
            pass

    def _finishLivePicon(self):
        result = self.livePiconDownload
        self.livePiconDownload = None
        if not result:
            return
        token, path = result
        if token != self.livePiconToken:
            return
        try:
            render_width, render_height = scale_size(118, 68)
            self.livePiconLoader.setPara((render_width,render_height,1,1,False,1,"#00000000"))
            self.livePiconLoader.startDecode(path)
        except Exception:
            pass

    def _livePiconDecoded(self, picInfo=None):
        try:
            ptr=self.livePiconLoader.getData()
            if ptr and self["channelPicon"].instance: self["channelPicon"].instance.setPixmap(ptr)
        except Exception: pass

    def renderPosterPage(self):
        self.downloads=[]; self.picloads=[]
        for slot in range(5):
            idx=self.pageStart+slot
            item=self.mediaItemsCurrent[idx] if idx < len(self.mediaItemsCurrent) else None
            self._setVisibleWidget("poster%d"%slot, bool(item))
            self._setVisibleWidget("posterLabel%d"%slot, bool(item))
            self._setVisibleWidget("posterRate%d"%slot, bool(item))
            self["posterLabel%d"%slot].setText(((item.get("name") or item.get("title") or "")[:22]) if item else "")
            rate = ""
            if item:
                rate = item.get("rating") or item.get("rating_5based") or ""
                rate = str(rate)[:4]
            self["posterRate%d"%slot].setText(rate if rate else "")
            self._setPlaceholder(slot)
            if item:
                url=item.get("stream_icon") or item.get("cover") or item.get("movie_image") or ""
                if url: self._loadPosterSlot(slot,url)
        self._setVisibleWidget("selector", bool(self.mediaItemsCurrent))
        self.moveSelector(); self.previewVod()
        # Poster speed test: after the five visible cards are queued at high
        # priority, prefetch a bounded part of the current category in the
        # background. request_artwork deduplicates existing/running files and
        # keeps only four network transfers active, so navigation stays usable.
        self._prefetchCategoryPosters()

    def _prefetchCategoryPosters(self):
        if self.kind not in ("vod", "series"):
            return
        items = list(self.mediaItemsCurrent or [])
        if not items:
            return
        # Start from the current page, then continue forward.  Eighty posters is
        # enough to test AJPanel-style bulk caching without filling the disk or
        # creating thousands of pending jobs on small receivers.
        start = max(0, int(self.pageStart or 0))
        ordered = items[start:start + 80]
        if start and len(ordered) < 80:
            ordered += items[:80 - len(ordered)]
        for item in ordered:
            try:
                url = item.get("stream_icon") or item.get("cover") or item.get("movie_image") or ""
                if url:
                    request_artwork(url, "posters", None, priority=5)
            except Exception:
                pass

    def _setVisibleWidget(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def _setPlaceholder(self, slot):
        try:
            self["poster%d"%slot].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png")
        except Exception: pass

    def _loadPosterSlot(self, slot, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_poster_artwork_requests", None)
        if requests is None:
            requests = {}
            self._poster_artwork_requests = requests
        requests[slot] = url

        def done(path, s=slot, expected=url):
            if getattr(self, "_poster_artwork_requests", {}).get(s) != expected:
                return
            self._decodeSlot(s, path)

        request_artwork(url, "posters", done, priority=55)

    def _decodeSlot(self, slot, path):
        loader=ePicLoad(); self.picloads.append(loader)
        def ready(_info=None, s=slot, l=loader):
            try:
                ptr = l.getData()
                if ptr and self["poster%d" % s].instance:
                    self["poster%d" % s].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        loader.PictureData.get().append(ready)
        render_width, render_height = scale_size(270, 380)
        loader.setPara((render_width,render_height,1,1,False,1,"#00000000"))
        loader.startDecode(path)

    def moveSelector(self):
        try:
            self["selector"].instance.move(ePoint(sx(self.POSTER_X[self.posterIndex]), sy(525)))
        except Exception: pass

    def scheduleSelectedInfo(self):
        if self.kind not in ("vod", "series") or self.source.get("type") not in ("xtream", "stalker"):
            return
        try: self.infoTimer.stop()
        except Exception: pass
        try: self.infoTimer.start(900, True)
        except Exception: self.loadSelectedInfo()

    def loadSelectedInfo(self):
        if SAFE_TABLE_MODE:
            return
        item = self.current()
        if not item:
            return
        mid = str(item.get("stream_id") or item.get("series_id") or "")
        if not mid:
            return
        key = self.kind + ":" + mid
        cached = self.fullInfoCache.get(key)
        if cached is not None:
            self.applySelectedInfo(mid, cached)
            return
        if key in self.infoProcesses:
            return
        try:
            if self.source.get("type") == "stalker":
                return
            client = XtreamClient(self.source)
            action = "get_vod_info" if self.kind == "vod" else "get_series_info"
            try:
                from urllib.parse import urlencode
            except ImportError:
                from urllib import urlencode
            url = client.base + "/player_api.php?" + urlencode({
                "username": client.user,
                "password": client.password,
                "action": action,
                ("vod_id" if self.kind == "vod" else "series_id"): mid,
            })
            cache_dir = get_cache_dir("info")
            try:
                ensure_dir(cache_dir)
            except Exception:
                pass
            path = os.path.join(cache_dir, hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")
            proc = eConsoleAppContainer()
            self.infoProcesses[key] = proc
            self.pendingInfoId = mid
            def done(ret, k=key, m=mid, p=path):
                self.infoProcesses.pop(k, None)
                if ret != 0 or not os.path.exists(p):
                    return
                try:
                    with open_text(p, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    self.fullInfoCache[k] = data or {}
                    self.applySelectedInfo(m, data or {})
                except Exception:
                    pass
            try:
                proc.appClosed.append(done)
            except Exception:
                proc.appClosed.get().append(done)
            proc.execute(PYTHON_EXECUTABLE, PYTHON_COMMAND, INFO_FETCH, url, path)
        except Exception:
            return

    def applySelectedInfo(self, mid, data):
        current = self.current()
        current_id = str((current or {}).get("stream_id") or (current or {}).get("series_id") or "")
        if current_id != str(mid):
            return
        item = current or {}
        info = (data or {}).get("info") or {}
        movie = (data or {}).get("movie_data") or {}
        merged = {}
        merged.update(item)
        merged.update(movie)
        merged.update(info)
        title = merged.get("name") or merged.get("title") or ""
        year = merged.get("releasedate") or merged.get("releaseDate") or merged.get("year") or ""
        rating = merged.get("rating") or merged.get("rating_5based") or ""
        genre = merged.get("genre") or ""
        duration = merged.get("duration") or merged.get("duration_secs") or ""
        self["channelTitle"].setText(title)
        self["meta"].setText("   ".join(x for x in [str(year), ("★ %s" % rating) if rating else "", str(duration), str(genre)] if x))
        self["desc"].setText((merged.get("plot") or merged.get("description") or merged.get("overview") or "لا توجد أية معلومات")[:650])
        back = merged.get("backdrop_path") or merged.get("backdrop") or merged.get("backdrop_url") or []
        if isinstance(back, list):
            back = back[0] if back else ""
        if isinstance(back, str):
            back = back.strip().replace(chr(92) + "/", "/")
            if back.startswith("["):
                try:
                    arr = json.loads(back)
                    back = arr[0] if arr else ""
                except Exception:
                    pass
            if back.startswith("/") and not back.startswith("//"):
                back = "https://image.tmdb.org/t/p/w1280" + back
        if not back:
            back = merged.get("cover_big") or merged.get("cover") or merged.get("stream_icon") or merged.get("movie_image") or ""
        if back:
            self.loadBackdrop(back)

    def loadBackdrop(self, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        self._media_backdrop_request = url

        def done(path, expected=url):
            if getattr(self, "_media_backdrop_request", "") != expected:
                return
            self.decodeBackdrop(path)

        request_artwork(url, "backdrops", done, priority=115)

    def decodeBackdrop(self, path):
        self.backdropLoader=ePicLoad()
        def ready(_info=None):
            try:
                ptr=self.backdropLoader.getData()
                if ptr and self["backdrop"].instance: self["backdrop"].instance.setPixmap(ptr)
            except Exception: pass
        self.backdropLoader.PictureData.get().append(ready)
        render_width, render_height = scale_size(1920, 1080)
        self.backdropLoader.setPara((render_width,render_height,0,0,False,1,"#00000000"))
        self.backdropLoader.startDecode(path)

    def previewVod(self):
        item=self.current()
        if not item:
            self["channelTitle"].setText(tr("No content")); self["meta"].setText(tr("")); self["desc"].setText(tr("")); self["nowLabel"].setText(tr("0/0")); return
        title=item.get("name") or item.get("title") or ""
        year=item.get("releaseDate") or item.get("year") or ""; rating=item.get("rating") or item.get("rating_5based") or ""; genre=item.get("genre") or ""; dur=item.get("duration") or ""; typ=item.get("container_extension") or item.get("stream_type") or ""
        self["channelTitle"].setText(title)
        self["meta"].setText("  •  ".join(x for x in [(str(rating) if rating else ""), str(genre), str(dur), str(year)] if x))
        self["desc"].setText((item.get("plot") or item.get("description") or "لا توجد أية معلومات")[:600])
        self["nowLabel"].setText("%d / %d" % (self.pageStart+self.posterIndex+1, len(self.mediaItemsCurrent)))
        self.scheduleSelectedInfo()

    def left(self):
        if self.focus == "top":
            self.topIndex = max(0, self.topIndex - 1)
            self._updateTopFocus()
            return
        if self.focus == "items":
            if self.kind == "live":
                self.cancelAction()
                return
            if self.posterIndex > 0:
                self.posterIndex -= 1
                self.moveSelector(); self.previewVod()
                return
            if self.pageStart >= 5:
                self.pageStart -= 5
                self.posterIndex = 4
                self.renderPosterPage()
                return
            self.focus = "category"
            self._updateTopFocus()
            return
        if self.focus == "category":
            self.focus = "rail"
            self._updateTopFocus()

    def right(self):
        if self.focus == "top":
            self.topIndex = min(len(self.topNames) - 1, self.topIndex + 1)
            self._updateTopFocus()
            return
        if self.focus == "rail":
            self.switchSection(self.currentRailSection())
            return
        if self.focus == "category":
            self.loadSelectedCategory()
            self.focus = "items"
            self._updateTopFocus()
            if self.kind != "live":
                self.moveSelector(); self.previewVod()
            return
        if self.kind == "live":
            return
        if self.pageStart + self.posterIndex + 1 >= len(self.mediaItemsCurrent):
            return
        if self.posterIndex < 4 and self.pageStart + self.posterIndex + 1 < len(self.mediaItemsCurrent):
            self.posterIndex += 1
            self.moveSelector(); self.previewVod()
        else:
            self.pageStart += 5
            self.posterIndex = 0
            self.renderPosterPage()

    def up(self):
        if self.focus == "top":
            return
        if self.focus == "rail":
            if self.kind != "live":
                self.focus = "top"
                self._updateTopFocus()
                return
            self["rail"].up()
            return
        if self.focus == "category":
            if self.kind == "live":
                self["category"].up()
            else:
                try:
                    if self["category"].getSelectedIndex() <= 0:
                        self.focus = "top"
                        self._updateTopFocus()
                        return
                except Exception:
                    pass
                self["category"].up()
            return
        if self.kind == "live":
            self["list"].up(); self.previewLive()
            return
        if self.pageStart >= 5:
            self.pageStart -= 5
            self.renderPosterPage()
        else:
            self.focus = "top"
            self._updateTopFocus()

    def down(self):
        if self.focus == "top":
            self.focus = "items"
            self._updateTopFocus()
            if self.kind != "live":
                self.moveSelector(); self.previewVod()
            return
        if self.focus == "rail":
            self["rail"].down()
            return
        if self.focus == "category":
            if self.kind == "live":
                self["category"].down()
            else:
                self["category"].down()
            return
        if self.kind == "live":
            self["list"].down(); self.previewLive()
            return
        if self.pageStart + 5 < len(self.mediaItemsCurrent):
            self.pageStart += 5
            self.renderPosterPage()

    def openLiveSearch(self):
        if self.kind != "live":
            return
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard,
            title="Search channels", text=self.searchQuery or "")

    def openLiveFilter(self):
        if self.kind != "live":
            return
        self.session.openWithCallback(self._liveFilterClosed, ServerCategoryFilter, self.source)

    def _liveFilterClosed(self, changed=False):
        if not changed or self.kind != "live":
            return
        self.searchQuery = ""
        self.sortMode = "default"
        self.lastCategoryItems = []
        self.mediaItemsCurrent = []
        self.focus = "category"
        try:
            pass
        except Exception:
            pass
        self.loadCategories()

    def toggleLiveSort(self):
        if self.kind != "live":
            return
        modes = ["default", "name"]
        try:
            position = modes.index(self.sortMode)
        except Exception:
            position = 0
        self.sortMode = modes[(position + 1) % len(modes)]
        items = list(self.lastCategoryItems or [])
        if self.searchQuery:
            query = self.searchQuery.lower()
            items = [entry for entry in items if query in (entry.get("name") or entry.get("title") or "").lower()]
        if self.sortMode == "name":
            items.sort(key=lambda entry: (entry.get("name") or entry.get("title") or "").lower())
            label = "A-Z"
        else:
            label = "Default"
        try:
            self["meta"].setText("Sort: %s" % label)
        except Exception:
            pass
        self.showItems(items)

    def toggleSort(self):
        if self.kind == "live":
            self.toggleLiveSort()
            return
        modes = ["default", "name", "rating"]
        try:
            pos = modes.index(self.sortMode)
        except Exception:
            pos = 0
        self.sortMode = modes[(pos + 1) % len(modes)]
        items = list(self.mediaItemsCurrent or self.lastCategoryItems or [])
        if self.sortMode == "name":
            items.sort(key=lambda x: (x.get("name") or x.get("title") or "").lower())
            self["filterIcon"].setText(tr("Name"))
        elif self.sortMode == "rating":
            def rating_value(x):
                try:
                    return float(x.get("rating") or x.get("rating_5based") or 0)
                except Exception:
                    return 0
            items.sort(key=rating_value, reverse=True)
            self["filterIcon"].setText(tr("Rating"))
        else:
            items = list(self.lastCategoryItems or [])
            if self.searchQuery:
                q = self.searchQuery.lower()
                items = [x for x in items if q in (x.get("name") or x.get("title") or "").lower()]
            self["filterIcon"].setText(tr("Filter"))
        self.showItems(items)

    def openSearch(self):
        if self.kind == "live":
            return
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard, title="Search content", text=self.searchQuery or "")

    def searchCallback(self, value=None):
        if value is None:
            return
        value = (value or "").strip()
        self.searchQuery = value
        if not value:
            self.showItems(self.lastCategoryItems)
            return
        self.applySearch(value)

    def applySearch(self, value):
        q = (value or "").strip().lower()
        items = []
        for x in (self.lastCategoryItems or []):
            name = (x.get("name") or x.get("title") or "").lower()
            plot = (x.get("plot") or x.get("description") or "").lower()
            if q in name or q in plot:
                items.append(x)
        self.showItems(items)
        try:
            caption = self["currentCategory"].getText() or ""
            if q:
                self["currentCategory"].setText((caption.split("  •  ")[0] if "  •  " in caption else caption) + "  •  Search")
        except Exception:
            pass

    def close(self, *args, **kwargs):
        if self.kind == "live":
            try:
                self.zapTimer.stop(); self.livePiconTimer.stop(); self.rowPiconTimer.stop(); self.directEpgTimer.stop()
                pass
                if self.oldService: self.session.nav.playService(self.oldService)
            except Exception:
                pass
        return Screen.close(self, *args, **kwargs)

    def livePlayerClosed(self, index=None):
        try:
            if index is not None and self.mediaItemsCurrent:
                index = max(0, min(int(index), len(self.mediaItemsCurrent) - 1))
                self["list"].moveToIndex(index)
                self.previewLive()
        except Exception:
            pass
        try:
            self.show()
        except Exception:
            pass

    def playerClosed(self, *args):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        try:
            self.show()
        except Exception:
            pass

    def ok(self):
        if self.focus == "top":
            return self._openTopItem()
        if self.focus == "rail":
            self.switchSection(self.currentRailSection())
            return
        if self.focus=="category":
            self.loadSelectedCategory(); self.focus="items"; return
        item=self.current()
        if not item: return
        if self.kind == "live":
            try:
                index = self["list"].getSelectedIndex()
            except Exception:
                index = 0
            self.keepCurrentLiveService = True
            try:
                self.zapTimer.stop()
            except Exception:
                pass
            self.session.openWithCallback(self.livePlayerClosed, TiviMateLivePlayer,
                                          self.source, list(self.mediaItemsCurrent or []), index)
            return
        try:
            if self.source.get("type") in ("xtream", "stalker"):
                if self.kind=="series":
                    return self.session.open(SeriesDetailsScreen, self.source, item)
                url=get_source_client(self.source).stream_url(item,self.kind)
            elif self.source.get("type")=="m3u": url=item.get("url","")
            else: url=""
            if not url: raise Exception("لا يوجد رابط تشغيل")
            service=eServiceReference(4097,0,url); service.setName(item.get("name") or item.get("title") or "IPTV")
            self.session.openWithCallback(self.playerClosed, TiviMatePlayer, service, item)
        except Exception as e:
            self.session.open(MessageBox,"تعذر التشغيل:\n%s"%e,MessageBox.TYPE_ERROR)



FAVOURITES_SKIN = '''<screen name="TiviMateFavorites" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#10151D">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#10151D" zPosition="0" />
    <eLabel position="0,0" size="1920,108" backgroundColor="#182330" zPosition="1" />
    <eLabel position="0,107" size="1920,2" backgroundColor="#65D7F3" zPosition="2" />
    <widget name="title" position="72,24" size="600,60" font="Regular;42" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="filter" position="1350,35" size="500,42" font="Regular;25" foregroundColor="#8EE7FF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
    <widget name="featuredTitle" position="75,160" size="1050,54" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="status" position="75,216" size="1725,52" font="Regular;25" foregroundColor="#C7D3DF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="75,278" size="1725,34" text="TIP: ON A MOVIE OR TV SHOW POSTER, HOLD YELLOW TO ADD TO FAVORITES" font="Regular;21" foregroundColor="#FFE383" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="list" position="-20,-20" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />
    <widget name="poster0" position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle0" position="105,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster1" position="367,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="367,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle1" position="367,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster2" position="629,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="629,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle2" position="629,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster3" position="891,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="891,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle3" position="891,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster4" position="1153,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="1153,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle4" position="1153,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster5" position="1415,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="1415,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle5" position="1415,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="posterSelector" position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_focus_r121.png" alphatest="blend" zPosition="12" />
    <eLabel position="0,936" size="1920,144" backgroundColor="#182330" zPosition="2" />
    <eLabel position="72,966" size="330,50" text="OK  OPEN / PLAY" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="455,966" size="305,50" text="RED  REMOVE" font="Regular;25" foregroundColor="#FF8A87" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="825,966" size="350,50" text="YELLOW  FILTER" font="Regular;25" foregroundColor="#FFE383" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="1240,966" size="340,50" text="BLUE  REFRESH" font="Regular;25" foregroundColor="#8EE7FF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="1640,966" size="220,50" text="EXIT  BACK" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
    <widget name="keys" position="75,1026" size="1770,34" font="Regular;21" foregroundColor="#9EAFBF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
</screen>'''

FAVOURITES_SKIN = scale_skin(FAVOURITES_SKIN)


class FavoritesScreen(Screen):
    """Full-screen local Favorite library for live channels, movies, and series."""
    skin = FAVOURITES_SKIN
    FILTERS = ((tr("ALL"), ""), (tr("LIVE"), "live"), (tr("MOVIES"), "vod"), (tr("TV SHOWS"), "series"))
    KIND_LABELS = {"live": tr("LIVE"), "vod": tr("MOVIE"), "series": tr("SERIES")}
    POSTER_X = (105, 367, 629, 891, 1153, 1415)
    POSTER_Y = 344
    PAGE_SIZE = 6

    def __init__(self, session):
        Screen.__init__(self, session)
        self.filterIndex = 0
        self.records = []
        self.pageStart = 0
        self.posterIndex = 0
        self.picloads = []
        self._poster_artwork_requests = {}
        self["title"] = Label(tr("Favorite"))
        self["filter"] = Label("")
        self["featuredTitle"] = Label(tr("YOUR SAVED CONTENT"))
        self["list"] = MenuList([])
        self["status"] = Label("")
        self["keys"] = Label(tr("ARROWS  SELECT POSTER     •     HOLD YELLOW ON A MOVIE / TV SHOW POSTER  =  ADD TO FAVORITES"))
        for slot in range(self.PAGE_SIZE):
            self["poster%d" % slot] = Pixmap()
            self["posterTitle%d" % slot] = Label("")
        self["posterSelector"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "ok": self.openCurrent, "cancel": self.close,
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "red": self.removeCurrent, "yellow": self.nextFilter, "blue": self.reload,
            "menu": self.nextFilter
        }, -1)
        self.onLayoutFinish.append(self.reload)

    def _currentRecord(self):
        index = self.pageStart + self.posterIndex
        if 0 <= index < len(self.records):
            return self.records[index]
        return None

    def _setVisible(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def _setPlaceholder(self, slot):
        try:
            self["poster%d" % slot].instance.setPixmapFromFile(
                "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png"
            )
        except Exception:
            pass

    def _recordTitle(self, record):
        item = record.get("item") or {}
        return item.get("name") or record.get("title") or item.get("title") or "IPTV"

    def _recordArtwork(self, record):
        item = record.get("item") or {}
        return item.get("stream_icon") or item.get("cover") or item.get("movie_image") or item.get("cover_big") or ""

    def reload(self):
        label, kind = self.FILTERS[self.filterIndex]
        self.records = list_favourites(kind or None)
        self.pageStart = 0
        self.posterIndex = 0
        rows = [(self._recordTitle(record), record) for record in self.records]
        self["list"].setList(rows)
        self["filter"].setText("%s: %s" % (tr("Filter"), label))
        self.renderPosterPage()

    def renderPosterPage(self):
        for slot in range(self.PAGE_SIZE):
            index = self.pageStart + slot
            record = self.records[index] if index < len(self.records) else None
            self._setVisible("poster%d" % slot, bool(record))
            self._setVisible("posterTitle%d" % slot, bool(record))
            if not record:
                try:
                    self["posterTitle%d" % slot].setText(tr(""))
                except Exception:
                    pass
                continue
            title = self._recordTitle(record)
            kind = self.KIND_LABELS.get(record.get("kind"), "IPTV")
            self["posterTitle%d" % slot].setText(("%s\n%s" % (kind, title))[:42])
            self._setPlaceholder(slot)
            artwork = self._recordArtwork(record)
            if artwork:
                self._loadPoster(slot, artwork)
        self._setVisible("posterSelector", bool(self.records))
        self._moveSelector()
        self._updateStatus()

    def _loadPoster(self, slot, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        self._poster_artwork_requests[slot] = url
        def done(path, s=slot, expected=url):
            if self._poster_artwork_requests.get(s) != expected:
                return
            self._decodePoster(s, path)
        request_artwork(url, "posters", done, priority=55)

    def _decodePoster(self, slot, path):
        loader = ePicLoad()
        self.picloads.append(loader)
        def ready(_info=None, s=slot, current=loader):
            try:
                ptr = current.getData()
                if ptr and self["poster%d" % s].instance:
                    self["poster%d" % s].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if current in self.picloads:
                    self.picloads.remove(current)
            except Exception:
                pass
        try:
            loader.PictureData.get().append(ready)
        except Exception:
            try:
                loader.PictureData.connect(ready)
            except Exception:
                pass
        try:
            render_width, render_height = scale_size(230, 300)
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
            loader.startDecode(path)
        except Exception:
            pass

    def _moveSelector(self):
        if not self.records:
            return
        try:
            self["posterSelector"].instance.move(ePoint(sx(self.POSTER_X[self.posterIndex]), sy(self.POSTER_Y)))
            self["posterSelector"].show()
        except Exception:
            pass

    def _updateStatus(self):
        total = len(self.records)
        record = self._currentRecord()
        if not record:
            self["status"].setText(tr("No saved items in this filter. Open a title and choose Add to My List."))
            return
        title = self._recordTitle(record)
        kind = self.KIND_LABELS.get(record.get("kind"), "IPTV")
        self["status"].setText("%s  •  %s     %d / %d" % (kind, title, self.pageStart + self.posterIndex + 1, total))

    def left(self):
        index = self.pageStart + self.posterIndex
        if index <= 0:
            return
        index -= 1
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def right(self):
        index = self.pageStart + self.posterIndex
        if index >= len(self.records) - 1:
            return
        index += 1
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def up(self):
        index = self.pageStart + self.posterIndex
        if index < self.PAGE_SIZE:
            return
        index -= self.PAGE_SIZE
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def down(self):
        index = self.pageStart + self.posterIndex
        if index + self.PAGE_SIZE >= len(self.records):
            return
        index += self.PAGE_SIZE
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def nextFilter(self):
        self.filterIndex = (self.filterIndex + 1) % len(self.FILTERS)
        self.reload()

    def removeCurrent(self):
        record = self._currentRecord()
        if not record:
            return
        if remove_record(record.get("id", "")):
            self.reload()
        else:
            self["status"].setText(tr("Unable to remove this Favorite."))

    def openCurrent(self):
        record = self._currentRecord()
        if not record:
            return
        source = source_for_record(record, get_sources())
        if not source:
            return self.session.open(MessageBox, "This item's source no longer exists. Press RED to remove it.", MessageBox.TYPE_INFO)
        item = dict(record.get("item") or {})
        kind = record.get("kind")
        try:
            if kind == "live":
                return self.session.open(TiviMateLivePlayer, source, [item], 0)
            if kind == "series":
                if source.get("type") != "xtream":
                    raise Exception("Series require an Xtream Codes source")
                return self.session.open(SeriesDetailsScreen, source, item)
            if source.get("type") == "xtream":
                url = XtreamClient(source).stream_url(item, "vod")
            elif source.get("type") == "m3u":
                url = item.get("url", "")
            else:
                url = StalkerClient(source).stream_url(item, "vod")
            if not url:
                raise Exception("No playable URL")
            service = eServiceReference(4097, 0, url)
            service.setName(item.get("name") or item.get("title") or "IPTV")
            return self.session.open(TiviMatePlayer, service, item)
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open Favorite:\n%s" % exc, MessageBox.TYPE_ERROR)

