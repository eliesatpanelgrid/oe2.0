# -*- coding: utf-8 -*-
from __future__ import absolute_import

try:
    from urllib.parse import quote
except Exception:
    from urllib import quote


def live_reference_string(source, item, service_type, url):
    """Return the exact standard IPTV service reference used by Enigma2.

    The Live player and InfoBar use this same string. Do not add synthetic
    SID/TSID/ONID values; Enigma2 identifies IPTV services by the full URL
    reference.
    """
    encoded = quote(str(url or ""), safe="/").replace("%3A", "%3a")
    return "%d:0:1:0:0:0:0:0:0:0:%s" % (int(service_type), encoded)


def live_reference(source, item, service_type, url, name="IPTV"):
    from enigma import eServiceReference
    ref = eServiceReference(live_reference_string(source, item, service_type, url))
    try:
        ref.setName(name or "IPTV")
    except Exception:
        pass
    return ref
