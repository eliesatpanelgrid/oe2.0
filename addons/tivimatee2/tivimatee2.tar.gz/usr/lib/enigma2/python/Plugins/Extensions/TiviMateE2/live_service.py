# -*- coding: utf-8 -*-

import hashlib
try:
    from urllib.parse import urlencode
except Exception:
    from urllib import urlencode

try:
    from urllib.parse import quote
except Exception:
    from urllib import quote


def _int_value(value, default=0):
    try:
        return int(str(value or '').strip())
    except Exception:
        return int(default)


def _source_key(source):
    parts = [
        str((source or {}).get('name') or ''),
        str((source or {}).get('url') or ''),
        str((source or {}).get('username') or ''),
        str((source or {}).get('type') or ''),
    ]
    raw = '|'.join(parts).encode('utf-8', 'replace')
    return int(hashlib.md5(raw).hexdigest()[:8], 16)


def _service_ids(source, item, url):
    """Build stable unique DVB identity fields for IPTV EPG mapping.

    Enigma2's EPG cache primarily keys events by the DVB identity fields, not
    by the URL path.  Using zero for every IPTV channel makes all channels
    collide.  These values stay stable across restarts and are shared by the
    Live player and EPGImport channels.xml generation.
    """
    stream_id = _int_value((item or {}).get('stream_id') or (item or {}).get('id'))
    if stream_id <= 0:
        raw = str(url or '').encode('utf-8', 'replace')
        stream_id = int(hashlib.md5(raw).hexdigest()[:8], 16)

    source_hash = _source_key(source)
    sid = stream_id & 0xFFFF
    if sid == 0:
        sid = 1
    tsid = (stream_id >> 16) & 0xFFFF
    if tsid == 0:
        tsid = source_hash & 0xFFFF or 1
    onid = (source_hash >> 16) & 0xFFFF or 1
    namespace = source_hash & 0xFFFFFFFF
    return sid, tsid, onid, namespace


def live_reference_string(source, item, service_type, url):
    """Return one stable IPTV service reference used by Live and EPGImport."""
    encoded = quote(str(url or ''), safe='/').replace('%3A', '%3a')
    sid, tsid, onid, namespace = _service_ids(source, item, url)
    return '%d:0:1:%X:%X:%X:%X:0:0:0:%s' % (
        int(service_type), sid, tsid, onid, namespace, encoded
    )



def _xklass_full_url(source):
    """Build the same get.php URL XKlass stores as playlist_info.full_url."""
    source = source or {}
    host = str(source.get('url') or '').rstrip('/')
    username = str(source.get('username') or '')
    password = str(source.get('password') or '')
    output = str(source.get('output') or 'ts')
    if not (host and username and password):
        return str(source.get('full_url') or host)
    query = urlencode({
        'username': username,
        'password': password,
        'type': 'm3u_plus',
        'output': output,
    })
    return '%s/get.php?%s' % (host, query)

def _xklass_unique_ref(source):
    """Return the exact provider identifier used by XKlass/XStreamity."""
    full_url = _xklass_full_url(source)
    return sum(ord(ch) for ch in str(full_url)) or 1


def epg_reference_string(source, item):
    """XKlass-compatible EPG-only reference.

    This reference deliberately does not use the playback URL or playback service
    type. EPGImport and eEPGCache both use this exact type-1 placeholder identity.
    """
    item = item or {}
    custom_sid = str(item.get('custom_sid') or '').strip()
    if custom_sid and custom_sid not in ('null', 'None', '0'):
        if custom_sid[0].isdigit():
            custom_sid = '1' + custom_sid[1:]
        elif custom_sid.startswith(':0'):
            custom_sid = '1' + custom_sid
        return ':'.join(custom_sid.split(':')[:7]) + ':0:0:0:http%3a//example.m3u8'

    stream_id = _int_value(item.get('stream_id') or item.get('id'))
    if stream_id <= 0:
        raw = str(item.get('url') or item.get('cmd') or item.get('name') or '').encode('utf-8', 'replace')
        stream_id = int(hashlib.md5(raw).hexdigest()[:8], 16)
    bouquet_id1 = int(stream_id) // 65535
    bouquet_id2 = int(stream_id) - int(bouquet_id1 * 65535)
    unique_ref = _xklass_unique_ref(source)
    return '1:0:1:%x:%x:%x:0:0:0:0:http%%3a//example.m3u8' % (bouquet_id1, bouquet_id2, unique_ref)

def live_reference(source, item, service_type, url, name='IPTV'):
    from enigma import eServiceReference

    # Stalker Live URLs are short-lived and may contain signed query strings.
    # Passing them through the DVB/EPG reference encoder can alter the URL on
    # some images and result in audio/video never starting.  EStalker plays
    # these streams directly, so keep the EPG identity separate and use a
    # plain IPTV service reference for Stalker playback only.
    source_type = str((source or {}).get('type') or '').strip().lower()
    resolved_type = int(service_type)
    stream_url = str(url or '').strip()
    if source_type == 'stalker':
        try:
            path = stream_url.split('?', 1)[0].lower()
            if resolved_type == 1 and path.endswith('.m3u8'):
                resolved_type = 4097
        except Exception:
            pass
        ref = eServiceReference(resolved_type, 0, stream_url)
    else:
        ref = eServiceReference(live_reference_string(source, item, resolved_type, stream_url))
    try:
        ref.setName(name or 'IPTV')
    except Exception:
        pass
    return ref
