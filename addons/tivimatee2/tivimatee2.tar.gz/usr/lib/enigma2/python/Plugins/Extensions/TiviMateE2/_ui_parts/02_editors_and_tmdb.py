class PlaylistEditor(Screen, ConfigListScreen):
    skin = XTREAM_EDITOR_R203_SKIN

    def __init__(self, session, source=None, callback=None):
        Screen.__init__(self, session)
        self["brandLabel"] = Label("TiviMate E2")
        self["sectionLive"] = Label("LIVE TV")
        self["sectionMovies"] = Label("MOVIES")
        self["sectionSeries"] = Label("SERIES")
        self["sectionSettings"] = Label("SETTINGS")
        self["typeBadge"] = Label('XTREAM CODES')
        self["typeDesc"] = Label('Username + Password\nAPI connection')
        self["typeHint"] = Label('Live TV • Movies • Series')
        self["statusLine"] = Label("Use OK to edit • GREEN to save • RED to cancel • EXIT to go back")
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.callback = callback
        self.original = source or {}
        self["title"] = Label(tr(("EDIT SERVER" if self.original else "ADD NEW SERVER") + "  •  XTREAM CODES"))
        self["hint"] = Label("Playlist file: %s" % PLAYLISTS_FILE)
        self["keys"] = Label("OK  KEYBOARD      GREEN  SAVE      BLUE  TEST      RED  CANCEL      EXIT  BACK")
        self.provider = ConfigText(default=self.original.get("name", "IPTV"), fixed_size=False)
        self.protocol = ConfigSelection(default=self._protocol(), choices=[("http://", "http://"), ("https://", "https://")])
        host, port = self._host_port()
        self.server = ConfigText(default=host, fixed_size=False)
        self.port = ConfigText(default=port, fixed_size=False)
        self.username = ConfigText(default=self.original.get("username", ""), fixed_size=False)
        self.password = ConfigPassword(default=self.original.get("password", ""), fixed_size=False)
        self.output = ConfigSelection(default=self.original.get("output", "ts"), choices=[("ts", "TS"), ("m3u8", "M3U8")])
        saved_xtream_types = _load_xtream_service_types(self.original) if self.original else {"live": 4097, "vod": 4097, "series": 4097}
        xtream_live_type = _clean_stream_type(self.original.get("service_type", saved_xtream_types.get("live", 4097)))
        xtream_vod_type = _clean_stream_type(saved_xtream_types.get("vod", 4097), 4097)
        xtream_series_type = _clean_stream_type(saved_xtream_types.get("series", 4097), 4097)
        self.liveStreamType = ConfigSelection(default=str(xtream_live_type), choices=STREAM_TYPE_CONFIG_CHOICES)
        self.vodStreamType = ConfigSelection(default=str(xtream_vod_type), choices=STREAM_TYPE_CONFIG_CHOICES)
        self.seriesStreamType = ConfigSelection(default=str(xtream_series_type), choices=STREAM_TYPE_CONFIG_CHOICES)
        external_epg_raw = self.original.get("external_live_epg", True)
        external_epg_enabled = str(external_epg_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.externalLiveEpg = ConfigYesNo(default=bool(external_epg_enabled))
        self.epgOffset = ConfigSelection(default=str(self.original.get("epg_offset", "-1")), choices=[
            ("auto", "Auto (XMLTV timezone)"), ("0", "No correction"),
            ("-2", "-2 hours"), ("-1", "-1 hour"),
            ("1", "+1 hour"), ("2", "+2 hours")
        ])
        poster_raw = self.original.get("show_live_poster", True)
        poster_enabled = str(poster_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.livePoster = ConfigYesNo(default=bool(poster_enabled))
        infobar_poster_raw = self.original.get("show_live_infobar_poster", True)
        infobar_poster_enabled = str(infobar_poster_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.liveInfobarPoster = ConfigYesNo(default=bool(infobar_poster_enabled))
        adult_raw = self.original.get("adult_enabled", False)
        adult_enabled = str(adult_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.adultContent = ConfigYesNo(default=not bool(adult_enabled))
        catchup_raw = self.original.get("catchup_enabled", False)
        catchup_enabled = str(catchup_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.catchupEnabled = ConfigYesNo(default=bool(catchup_enabled))
        entries = [
            getConfigListEntry(tr("Playlist Name"), self.provider),
            getConfigListEntry(tr("Protocol"), self.protocol),
            getConfigListEntry(tr("Server URL"), self.server),
            getConfigListEntry(tr("Port"), self.port),
            getConfigListEntry(tr("Username"), self.username),
            getConfigListEntry(tr("Password"), self.password),
            getConfigListEntry(tr("Stream Format"), self.output),
            getConfigListEntry(tr("Live Stream Type"), self.liveStreamType),
            getConfigListEntry(tr("VOD Stream Type"), self.vodStreamType),
            getConfigListEntry(tr("Series Stream Type"), self.seriesStreamType),
            getConfigListEntry(tr("External Live EPG"), self.externalLiveEpg),
            getConfigListEntry(tr("EPG Time Offset"), self.epgOffset),
            getConfigListEntry(tr(u"★ TMDb Poster in Live"), self.livePoster),
            getConfigListEntry(tr(u"★ Small Poster in Live Infobar"), self.liveInfobarPoster),
            getConfigListEntry(tr("Hide Adult Content"), self.adultContent),
            getConfigListEntry(tr("Enable Catch-up Package"), self.catchupEnabled),
        ]
        ConfigListScreen.__init__(self, entries, session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.openKeyboard, "green": self.save, "blue": self.testPortal,
            "red": self.close, "cancel": self.close,
            "left": self.keyLeft, "right": self.keyRight
        }, -1)

    def keyLeft(self):
        try:
            ConfigListScreen.keyLeft(self)
        except Exception:
            pass

    def keyRight(self):
        try:
            ConfigListScreen.keyRight(self)
        except Exception:
            pass

    def _protocol(self):
        return "https://" if self.original.get("url", "").startswith("https://") else "http://"

    def _host_port(self):
        url = self.original.get("url", "").replace("http://", "").replace("https://", "").rstrip("/")
        return tuple(url.rsplit(":", 1)) if ":" in url else (url, "")


    def addTmdbKey(self):
        # Import from any Enigma2 path. The shared built-in credential is never
        # shown or written to the browser. Only a user-selected text file is read.
        self.session.openWithCallback(self.tmdbKeyImported, TMDbKeyImportBrowser, start_path="/")

    def tmdbKeyImported(self, value=None):
        if not value:
            return
        self.customTmdbKey.value = (value or "").strip()
        try:
            self["hint"].setText("Custom TMDb key imported. Press GREEN to save.")
        except Exception:
            pass

    def tmdbKeyEntered(self, value=None):
        if value is None:
            return
        self.customTmdbKey.value = (value or "").strip()
        try:
            self["hint"].setText("Custom TMDb key ready. Press GREEN to save.")
        except Exception:
            pass

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if not current:
            return
        cfg = current[1]
        if cfg is self.livePoster or cfg is self.liveInfobarPoster or cfg is self.adultContent or cfg is self.catchupEnabled or cfg is self.externalLiveEpg:
            try:
                cfg.value = not bool(cfg.value)
                cfg.changed()
            except Exception:
                return
            try:
                self["config"].invalidateCurrent()
            except Exception:
                pass
            return
        if not isinstance(cfg, (ConfigText, ConfigPassword)):
            return
        self.session.openWithCallback(self.keyboardCallback, VirtualKeyBoard, title=current[0], text=cfg.value or "")

    def keyboardCallback(self, value=None):
        if value is None:
            return
        current = self["config"].getCurrent()
        if current:
            current[1].value = value
            self["config"].invalidateCurrent()

    def testPortal(self):
        host = (self.server.value or "").strip().replace("http://", "").replace("https://", "").rstrip("/")
        port = (self.port.value or "").strip()
        if not host or not self.username.value or not self.password.value:
            self.session.open(MessageBox, "Enter the server URL, username, and password first.", MessageBox.TYPE_ERROR); return
        url = self.protocol.value + host + ((":" + port) if port else "")
        source = {
            "type": "xtream", "name": self.provider.value or "IPTV", "url": url,
            "username": self.username.value, "password": self.password.value,
            "output": self.output.value
        }
        self["hint"].setText("Testing Xtream connection...")
        def worker():
            try:
                report = XtreamClient(source).test()
                ok = bool(report)
                message = "Xtream connection successful." if ok else "Xtream connection failed."
            except Exception as exc:
                ok = False
                message = "Xtream connection failed: %s" % exc
            def done():
                try:
                    self["hint"].setText(message)
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR, timeout=7)
                except Exception:
                    pass
            try:
                reactor.callFromThread(done) if reactor is not None else done()
            except Exception:
                done()
        threading.Thread(target=worker).start()

    def save(self):
        host = (self.server.value or "").strip().replace("http://", "").replace("https://", "").rstrip("/")
        port = (self.port.value or "").strip()
        if not host or not self.username.value or not self.password.value:
            self.session.open(MessageBox, "Enter the server URL, username, and password.", MessageBox.TYPE_ERROR); return
        url = self.protocol.value + host + ((":" + port) if port else "")
        src = dict(self.original or {})
        src.update({
            "type": "xtream", "name": self.provider.value or "IPTV", "url": url,
            "username": self.username.value, "password": self.password.value,
            "output": self.output.value, "epg_offset": self.epgOffset.value,
            "service_type": _clean_stream_type(self.liveStreamType.value),
            "external_live_epg": bool(self.externalLiveEpg.value),
            "show_live_poster": bool(self.livePoster.value),
            "show_live_infobar_poster": bool(self.liveInfobarPoster.value),
            "adult_enabled": not bool(self.adultContent.value),
            "catchup_enabled": bool(self.catchupEnabled.value)
        })
        xtream_types = _load_xtream_service_types(src)
        xtream_types["live"] = _clean_stream_type(self.liveStreamType.value)
        xtream_types["vod"] = _clean_stream_type(self.vodStreamType.value, 4097)
        xtream_types["series"] = _clean_stream_type(self.seriesStreamType.value, 4097)
        _save_xtream_service_types(src, xtream_types)

        # External EPG is intentionally isolated from Live navigation.  Only
        # when the user changes this switch do we rebuild the EPG cache in the
        # existing background worker; no extra read/call is added to channel
        # movement or the 260 ms selection debounce path.
        old_external = str(self.original.get("external_live_epg", False)).strip().lower() in ("1", "true", "yes", "on", "enabled")
        new_external = bool(self.externalLiveEpg.value)
        legacy_external_setting = bool(self.original) and "external_live_epg" not in self.original
        if legacy_external_setting or old_external != new_external:
            try:
                from .epg_local import refresh_source_epg
                refresh_source_epg(src, force=True, background=True)
            except Exception:
                pass
        self.close(src)



SOURCE_TYPE_PICKER_R128_SKIN = r"""<screen name="SourceTypePicker" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/add_server_picker_r128.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="cardFocus" position="140,300" size="480,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/add_server_picker_focus_r177.png" alphatest="blend" zPosition="9"/>
    <widget name="brand" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="side" position="0,0" size="1,1" transparent="1" zPosition="1"/>
    <widget name="title" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="subtitle" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="menu" position="0,0" size="1,1" transparent="1" zPosition="1"/>
    <widget name="cardTitle0" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="cardTitle1" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="cardTitle2" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="cardText0" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="cardText1" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="cardText2" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="info" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="keys" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="guideBar" position="0,0" size="1,1" transparent="1" zPosition="1"/>
</screen>"""

class SourceTypePicker(Screen):
    """Premium three-card source chooser."""
    skin = SOURCE_TYPE_PICKER_R128_SKIN
    CARD_X = [140, 715, 1290]
    TYPES = ["xtream", "stalker", "m3u"]

    def __init__(self, session):
        Screen.__init__(self, session)
        self.choice = 0
        self["brand"] = Label(tr("TiViMate"))
        self["side"] = MenuList([])
        self["title"] = Label(tr("ADD NEW SERVER"))
        self["subtitle"] = Label(tr("Choose the type of IPTV connection you want to add"))
        self["menu"] = MenuList([])
        self["cardFocus"] = Pixmap()
        self["cardTitle0"] = Label("Xtream Codes")
        self["cardTitle1"] = Label("Stalker Portal")
        self["cardTitle2"] = Label("Import M3U")
        self["cardText0"] = Label(tr("Live TV  •  Movies  •  TV Shows\nUsername and password login"))
        self["cardText1"] = Label(tr("Portal based connection\nPortal URL and MAC address"))
        self["cardText2"] = Label(tr("Import M3U / M3U8 playlist\nHDD • USB • receiver storage"))
        self["info"] = Label(tr("Select a server type. You can edit it later from Server Manager."))
        self["keys"] = Label(tr("◀  ▶  CHOOSE SERVER TYPE        OK  SELECT        EXIT  BACK"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.choose, "cancel": self.close,
            "left": self.left, "right": self.right,
            "up": self.left, "down": self.right
        }, -1)
        self.onLayoutFinish.append(self._render)

    def _render(self):
        try:
            self["cardFocus"].instance.move(ePoint(sx(self.CARD_X[self.choice]), sy(300)))
        except Exception:
            pass

    def left(self):
        self.choice = (self.choice - 1) % 3
        self._render()

    def right(self):
        self.choice = (self.choice + 1) % 3
        self._render()

    def choose(self):
        self.close(self.TYPES[self.choice])





class M3UFileImportBrowser(Screen):
    """Storage-aware M3U file picker using the same mount/file-list model as subtitles."""
    skin = r"""<screen name="M3UFileImportBrowser" position="center,center" size="1500,850" flags="wfNoBorder" backgroundColor="#070A0E">
        <eLabel position="0,0" size="1500,92" backgroundColor="#0B1118" zPosition="1"/>
        <widget name="title" position="48,18" size="900,54" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="2"/>
        <widget name="path" position="48,102" size="1404,46" font="Regular;25" foregroundColor="#9CB6C9" transparent="1" zPosition="2"/>
        <widget name="file_list" position="48,162" size="1404,570" scrollbarMode="showOnDemand" backgroundColor="#090E14" foregroundColor="#FFFFFF" zPosition="2"/>
        <eLabel position="48,752" size="1404,2" backgroundColor="#244256" zPosition="2"/>
        <widget name="hint" position="48,770" size="1404,52" font="Regular;24" foregroundColor="#DDE8F0" transparent="1" halign="center" valign="center" zPosition="2"/>
    </screen>"""

    def __init__(self, session, start_path=None):
        Screen.__init__(self, session)
        from .TiviMateSubtitles.compat import FileList as TiviMateFileList

        preferred = start_path
        if not preferred:
            for candidate in ("/media/hdd", "/media/usb", "/media/mmc"):
                if os.path.isdir(candidate):
                    preferred = candidate
                    break
        if preferred and os.path.isdir(preferred) and not preferred.endswith('/'):
            preferred += '/'

        self["title"] = Label("IMPORT M3U FILE")
        self["path"] = Label("")
        self["hint"] = Label("OK  OPEN / IMPORT     BLUE  STORAGE     RED / EXIT  CANCEL")
        self["file_list"] = TiviMateFileList(
            preferred,
            showDirectories=True,
            showFiles=True,
            showMountpoints=True,
            matchingPattern=r"(?i)^.*\.(m3u|m3u8|txt)$",
            useServiceRef=False,
        )
        try:
            self["file_list"].l.setFont(0, gFont("Regular", 28))
            self["file_list"].l.setItemHeight(50)
        except Exception:
            pass

        self["actions"] = ActionMap([
            "OkCancelActions", "ColorActions", "DirectionActions"
        ], {
            "ok": self.ok,
            "cancel": self.close,
            "red": self.close,
            "blue": self.showStorage,
            "up": self["file_list"].up,
            "down": self["file_list"].down,
            "left": self["file_list"].pageUp,
            "right": self["file_list"].pageDown,
        }, -1)
        self.onLayoutFinish.append(self._updatePath)

    def _updatePath(self):
        try:
            path = self["file_list"].getCurrentDirectory()
            self["path"].setText(path or "HDD / USB / MMC")
        except Exception:
            self["path"].setText("HDD / USB / MMC")

    def showStorage(self):
        try:
            self["file_list"].changeDir(None)
            self._updatePath()
        except Exception:
            pass

    def ok(self):
        try:
            if self["file_list"].canDescent():
                self["file_list"].descent()
                self._updatePath()
                return
            filename = self["file_list"].getFilename()
            current = self["file_list"].getCurrentDirectory()
            if not filename:
                return
            if os.path.isabs(filename):
                path = filename
            else:
                path = os.path.join(current or "", filename)
            path = os.path.abspath(path)
            if os.path.isfile(path) and path.lower().endswith((".m3u", ".m3u8", ".txt")):
                self.close(path)
        except Exception:
            return

M3U_PHONE_IMPORT_SKIN = scale_skin(r'''<screen name="M3UPhoneImportScreen" position="center,center" size="1320,760" flags="wfNoBorder" backgroundColor="#07111E">
    <eLabel position="0,0" size="1320,760" backgroundColor="#07111E" zPosition="0" />
    <widget name="title" position="80,55" size="1160,55" font="Regular;40" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="3" />
    <widget name="subtitle" position="100,120" size="1120,36" font="Regular;24" foregroundColor="#56E5FF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="3" />
    <eLabel position="145,190" size="430,430" backgroundColor="#FFFFFF" zPosition="1" />
    <widget name="qr" position="175,220" size="370,370" alphatest="blend" zPosition="3" />
    <widget name="status" position="650,225" size="560,50" font="Regular;31" foregroundColor="#69E99C" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <widget name="url" position="650,305" size="560,100" font="Regular;27" foregroundColor="#71E4FF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="3" />
    <widget name="help" position="650,430" size="560,155" font="Regular;25" foregroundColor="#E8F2FB" backgroundColor="#00000000" transparent="1" valign="top" zPosition="3" />
    <widget name="footer" position="90,675" size="1140,42" font="Regular;22" foregroundColor="#BCCDE0" backgroundColor="#00000000" transparent="1" halign="center" zPosition="3" />
</screen>''')


class M3UPhoneImportScreen(Screen):
    """LAN-only QR entry point for phone M3U upload using the existing web manager."""
    skin = M3U_PHONE_IMPORT_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["title"] = Label("IMPORT M3U FROM PHONE")
        self["subtitle"] = Label("Scan the QR code, choose m3u.txt / .m3u / .m3u8, then upload")
        self["qr"] = Pixmap()
        self["status"] = Label("Web Server: STARTING")
        self["url"] = Label("")
        self["help"] = Label("1. Scan QR with your phone\n2. Choose your playlist file\n3. Tap Import to Receiver")
        self["footer"] = Label("GREEN  REFRESH    •    EXIT / BACK  CLOSE")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.close,
            "ok": self.close,
            "red": self.close,
            "green": self.refreshAccess,
        }, -1)
        self._qrPath = data_path("runtime", "m3u_phone_import_qr.png")
        self.onLayoutFinish.append(self.refreshAccess)

    def refreshAccess(self):
        try:
            from .web_manager import start_web_manager, web_manager_status
            start_web_manager()
            status = web_manager_status() or {}
            ip = str(status.get("ip") or "127.0.0.1")
            port = int(status.get("port") or 8088)
            running = bool(status.get("running"))
            url = "http://%s:%d/m3u-upload" % (ip, port)
            self["status"].setText("Web Server: %s" % ("ON" if running else "OFF"))
            self["url"].setText(url if running else "")
            if running and ip not in ("127.0.0.1", "0.0.0.0"):
                ensure_dir(os.path.dirname(self._qrPath))
                from .web_qr import make_qr_png
                make_qr_png(url, self._qrPath, scale=9, border=4)
                self["qr"].instance.setPixmap(LoadPixmap(self._qrPath))
                self["qr"].show()
            else:
                self["help"].setText("Receiver needs a LAN/Wi-Fi address. Connect it to the network and press GREEN.")
        except Exception as exc:
            self["status"].setText("Web Server: ERROR")
            self["url"].setText("")
            self["help"].setText("Unable to start phone import: %s" % exc)


class M3UPlaylistEditor(Screen, ConfigListScreen):
    """Add a standard M3U playlist from a URL or local .m3u/.m3u8/.txt file."""
    skin = M3U_EDITOR_R203_SKIN

    def __init__(self, session, source=None, callback=None):
        Screen.__init__(self, session)
        self["brandLabel"] = Label("TiviMate E2")
        self["sectionLive"] = Label("LIVE TV")
        self["sectionMovies"] = Label("MOVIES")
        self["sectionSeries"] = Label("SERIES")
        self["sectionSettings"] = Label("SETTINGS")
        self["typeBadge"] = Label('IMPORT M3U')
        self["typeDesc"] = Label('Local playlist import\nM3U / M3U8')
        self["typeHint"] = Label('Full local playlist source')
        self["statusLine"] = Label("Use OK to edit • GREEN to save • RED to cancel • EXIT to go back")
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.callback = callback
        self.original = source or {}
        self["title"] = Label(tr(("EDIT M3U" if self.original else "IMPORT M3U PLAYLIST") + "  •  M3U / M3U8 / TXT"))
        self["hint"] = Label(tr("Import a ready-made M3U/M3U8/TXT file. Existing URL playlists remain supported when editing."))
        self["keys"] = Label("OK  EDIT      GREEN  IMPORT/SAVE      BLUE  PHONE QR      YELLOW  HDD/USB      RED  CANCEL")

        original_mode = str(self.original.get("m3u_mode") or "").strip().lower()
        if original_mode not in ("url", "file"):
            original_mode = "file" if (self.original.get("path") or not self.original) else "url"

        self.provider = ConfigText(default=self.original.get("name", "M3U Playlist"), fixed_size=False)
        self.mode = ConfigSelection(default=original_mode, choices=[
            ("url", "M3U URL"),
            ("file", "Local M3U File"),
        ])
        self.location = ConfigText(
            default=(self.original.get("path") if original_mode == "file" else self.original.get("url", "")) or "",
            fixed_size=False
        )
        self.liveStreamType = ConfigSelection(
            default=str(_clean_stream_type(self.original.get("service_type", 4097))),
            choices=STREAM_TYPE_CONFIG_CHOICES
        )

        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Playlist Name"), self.provider),
            getConfigListEntry(tr("Source Type"), self.mode),
            getConfigListEntry(tr("URL / File Path"), self.location),
            getConfigListEntry(tr("Live Stream Type"), self.liveStreamType),
        ], session=session)

        self["actions"] = ActionMap(["OkCancelActions","ColorActions","DirectionActions"], {
            "ok": self.openEditor,
            "green": self.save,
            "blue": self.openPhoneImport,
            "yellow": self.findLocalFile,
            "red": self.close,
            "cancel": self.close,
            "left": self.keyLeft,
            "right": self.keyRight,
        }, -1)

    def keyLeft(self):
        try: ConfigListScreen.keyLeft(self)
        except Exception: pass

    def keyRight(self):
        try: ConfigListScreen.keyRight(self)
        except Exception: pass

    def openEditor(self):
        current = self["config"].getCurrent()
        if not current:
            return
        cfg = current[1]
        if cfg is self.mode or cfg is self.liveStreamType:
            try: ConfigListScreen.keyRight(self)
            except Exception: pass
            return
        if not isinstance(cfg, ConfigText):
            return
        self.session.openWithCallback(
            lambda value, c=cfg: self._keyboardDone(c, value),
            VirtualKeyBoard, title=current[0], text=cfg.value or ""
        )

    def _keyboardDone(self, cfg, value=None):
        if value is None:
            return
        cfg.value = str(value).strip()
        try:self["config"].invalidateCurrent()
        except Exception:pass

    def _scanM3UFiles(self):
        roots = ["/media/hdd", "/media/usb", "/media/mmc", "/media", "/home/root", "/tmp", "/etc/enigma2"]
        found = []
        seen = set()
        for root in roots:
            if not os.path.isdir(root):
                continue
            for dirpath, dirnames, filenames in os.walk(root):
                # Keep scans bounded; receiver media trees can be huge.
                depth = dirpath[len(root):].count(os.sep)
                if depth >= 3:
                    dirnames[:] = []
                for name in filenames:
                    if not name.lower().endswith((".m3u", ".m3u8", ".txt")):
                        continue
                    path = os.path.join(dirpath, name)
                    if path not in seen:
                        seen.add(path)
                        found.append(path)
                    if len(found) >= 80:
                        return found
        return found

    def openPhoneImport(self):
        self.session.open(M3UPhoneImportScreen)

    def findLocalFile(self):
        # Open the lightweight browser directly.  Do not build/open a ChoiceBox:
        # on some receivers that extra surface can exhaust graphics memory.
        self.session.openWithCallback(self._fileSelected, M3UFileImportBrowser, None)

    def _fileSelected(self, choice=None):
        if not choice:
            return
        self.mode.value = "file"
        self.location.value = str(choice)
        try:self["config"].invalidateCurrent()
        except Exception:pass
        self["hint"].setText("Selected: %s" % self.location.value)

    def _importPlaylistCopy(self, path):
        """Copy an imported playlist into plugin data so removable media is no longer required."""
        path = os.path.abspath(os.path.expanduser(str(path or "")))
        if not os.path.isfile(path):
            raise IOError("M3U file not found: %s" % path)
        with open(path, "rb") as handle:
            data = handle.read()
        if b"#EXTM3U" not in data[:4096]:
            stripped = data.lstrip()
            if stripped.startswith(b"#EXTINF"):
                data = b"#EXTM3U\n" + stripped
            else:
                raise ValueError("The selected TXT/M3U file is not a valid M3U playlist.")
        import_dir = data_path("imported_m3u")
        ensure_dir(import_dir)
        digest = hashlib.sha1(data).hexdigest()[:12]
        ext = ".m3u8" if path.lower().endswith(".m3u8") else (".txt" if path.lower().endswith(".txt") else ".m3u")
        target = os.path.join(import_dir, "playlist_%s%s" % (digest, ext))
        if not os.path.exists(target):
            tmp = target + ".tmp"
            with open(tmp, "wb") as handle:
                handle.write(data)
            atomic_replace(tmp, target)
        return target

    def save(self):
        name = str(self.provider.value or "M3U Playlist").strip()
        mode = str(self.mode.value or "url").strip()
        value = str(self.location.value or "").strip()
        if not value:
            self.session.open(MessageBox, "Enter an M3U URL or select a local file.", MessageBox.TYPE_ERROR)
            return

        src = dict(self.original or {})
        src.update({
            "type": "m3u",
            "name": name,
            "m3u_mode": mode,
            "service_type": _clean_stream_type(self.liveStreamType.value),
        })

        if mode == "file":
            try:
                path = self._importPlaylistCopy(value)
            except Exception as exc:
                self.session.open(MessageBox, "Unable to import M3U file:\n%s" % exc, MessageBox.TYPE_ERROR)
                return
            src["path"] = path
            src["url"] = ""
            src["imported"] = True
            try:
                parsed = M3UClient(src).entries() or []
                epg_url = next((str(row.get("epg_url") or "").strip() for row in parsed if str(row.get("epg_url") or "").strip()), "")
                if epg_url:
                    src["epg_url"] = epg_url
                src["catchup_enabled"] = any(bool(str(row.get("catchup") or row.get("catchup_source") or row.get("timeshift") or "").strip()) for row in parsed)
                src["entry_count"] = len(parsed)
            except Exception:
                pass
        else:
            if not value.lower().startswith(("http://", "https://")):
                self.session.open(MessageBox, "M3U URL must start with http:// or https://", MessageBox.TYPE_ERROR)
                return
            src["url"] = value
            src.pop("path", None)

        self.close(src)


class StalkerPortalEditor(Screen, ConfigListScreen):
    """Private local editor for a user-supplied Stalker/Ministra VOD portal."""
    skin = STALKER_EDITOR_R203_SKIN

    def __init__(self, session, source=None, callback=None):
        Screen.__init__(self, session)
        self["brandLabel"] = Label("TiviMate E2")
        self["sectionLive"] = Label("LIVE TV")
        self["sectionMovies"] = Label("MOVIES")
        self["sectionSeries"] = Label("SERIES")
        self["sectionSettings"] = Label("SETTINGS")
        self["typeBadge"] = Label('STALKER PORTAL')
        self["typeDesc"] = Label('Portal URL + MAC\nMinistra / MAG')
        self["typeHint"] = Label('Portal based IPTV source')
        self["statusLine"] = Label("Use OK to edit • GREEN to save • RED to cancel • EXIT to go back")
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.callback = callback
        self.original = source or {}
        self["title"] = Label(tr(("EDIT SERVER" if self.original else "ADD NEW SERVER") + "  •  STALKER PORTAL"))
        self["hint"] = Label(tr("Enter your own Portal URL and MAG MAC address. No portal or account is bundled with TiViMate."))
        self["keys"] = Label("OK  KEYBOARD      GREEN  SAVE      BLUE  TEST      RED  CANCEL      EXIT  BACK")
        self["testButton"] = Label(tr("BLUE  TEST PORTAL"))
        self.provider = ConfigText(default=self.original.get("name", "Stalker Portal"), fixed_size=False)
        self.portal = ConfigText(default=self.original.get("url", ""), fixed_size=False)
        self._mac_formatting = False
        self.mac = ConfigText(default=self._initialMacList(self.original), fixed_size=False)
        self.epgOffset = ConfigSelection(default=str(self.original.get("epg_offset", "auto")), choices=[
            ("auto", "Auto (portal/XMLTV timezone)"), ("0", "No correction"),
            ("-2", "-2 hours"), ("-1", "-1 hour"),
            ("1", "+1 hour"), ("2", "+2 hours")
        ])
        poster_raw = self.original.get("show_live_poster", True)
        poster_enabled = str(poster_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.livePoster = ConfigYesNo(default=bool(poster_enabled))
        infobar_poster_raw = self.original.get("show_live_infobar_poster", True)
        infobar_poster_enabled = str(infobar_poster_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.liveInfobarPoster = ConfigYesNo(default=bool(infobar_poster_enabled))
        adult_raw = self.original.get("adult_enabled", False)
        adult_enabled = str(adult_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.adultContent = ConfigYesNo(default=not bool(adult_enabled))
        catchup_raw = self.original.get("catchup_enabled", False)
        catchup_enabled = str(catchup_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.catchupEnabled = ConfigYesNo(default=bool(catchup_enabled))
        saved_stalker_types = _load_stalker_service_types(self.original) if self.original else {"live": 4097}
        stalker_live_type = _clean_stream_type(self.original.get("service_type", saved_stalker_types.get("live", 4097)))
        self.liveStreamType = ConfigSelection(default=str(stalker_live_type), choices=STREAM_TYPE_CONFIG_CHOICES)
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Portal Name"), self.provider),
            getConfigListEntry(tr("Portal URL"), self.portal),
            getConfigListEntry(tr("MAG MACs / Alias"), self.mac),
            getConfigListEntry(tr("Live Stream Type"), self.liveStreamType),
            getConfigListEntry(tr("EPG Time Offset"), self.epgOffset),
            getConfigListEntry(tr(u"★ TMDb Poster in Live"), self.livePoster),
            getConfigListEntry(tr(u"★ Small Poster in Live Infobar"), self.liveInfobarPoster),
            getConfigListEntry(tr("Hide Adult Content"), self.adultContent),
            getConfigListEntry(tr("Enable Catch-up Package"), self.catchupEnabled),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.openKeyboard, "green": self.save, "blue": self.testPortal, "red": self.close, "cancel": self.close,
            "left": self.keyLeft, "right": self.keyRight
        }, -1)

    def keyLeft(self):
        try:
            ConfigListScreen.keyLeft(self)
        except Exception:
            pass

    def keyRight(self):
        try:
            ConfigListScreen.keyRight(self)
        except Exception:
            pass


    def addTmdbKey(self):
        # Import from a local text/key/config file.  The built-in shared key and
        # any previously saved private key are never displayed on screen.
        self.session.openWithCallback(self.tmdbKeyEntered, TMDbKeyImportBrowser, "/")

    def tmdbKeyEntered(self, value=None):
        if value is None:
            return
        self.customTmdbKey.value = (value or "").strip()
        try:
            self["hint"].setText("Custom TMDb key ready. Press GREEN to save.")
        except Exception:
            pass

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if not current:
            return
        cfg = current[1]
        if cfg is self.livePoster or cfg is self.liveInfobarPoster or cfg is self.adultContent or cfg is self.catchupEnabled:
            try:
                cfg.value = not bool(cfg.value)
                cfg.changed()
            except Exception:
                return
            try:
                self["config"].invalidateCurrent()
            except Exception:
                pass
            return
        if not isinstance(cfg, ConfigText):
            return
        self.session.openWithCallback(self.keyboardCallback, VirtualKeyBoard, title=current[0], text=cfg.value or "")

    @staticmethod
    def _formatMacValue(value):
        raw = str(value or "").upper()
        hexchars = "".join(ch for ch in raw if ch in "0123456789ABCDEF")[:12]
        return ":".join(hexchars[i:i + 2] for i in range(0, len(hexchars), 2))

    @classmethod
    def _parseMacList(cls, value):
        entries = []
        seen = set()
        raw = str(value or "").replace("\n", ",").replace(";", ",")
        for part in raw.split(","):
            part = part.strip()
            if not part:
                continue
            if "=" in part:
                mac_raw, alias = part.split("=", 1)
            elif "|" in part:
                mac_raw, alias = part.split("|", 1)
            else:
                mac_raw, alias = part, ""
            mac = cls._formatMacValue(mac_raw)
            bits = mac.split(":")
            try:
                valid = len(bits) == 6 and all(len(bit) == 2 and int(bit, 16) >= 0 for bit in bits)
            except Exception:
                valid = False
            if valid and mac not in seen:
                seen.add(mac)
                entries.append({"mac": mac, "alias": str(alias or "").strip()})
        return entries

    @classmethod
    def _initialMacList(cls, source):
        source = source or {}
        entries = []
        raw = source.get("macs")
        if isinstance(raw, list):
            for row in raw:
                if isinstance(row, dict):
                    mac = cls._formatMacValue(row.get("mac", ""))
                    alias = str(row.get("alias") or "").strip()
                    if mac:
                        entries.append("%s=%s" % (mac, alias) if alias else mac)
        if not entries:
            mac = cls._formatMacValue(source.get("mac", ""))
            alias = str(source.get("mac_alias") or source.get("alias") or "").strip()
            if mac:
                entries.append("%s=%s" % (mac, alias) if alias else mac)
        return ", ".join(entries)

    def keyboardCallback(self, value=None):
        if value is None:
            return
        current = self["config"].getCurrent()
        if current:
            cfg = current[1]
            if cfg is self.mac:
                parsed = self._parseMacList(value)
                cfg.value = ", ".join(
                    ("%s=%s" % (row["mac"], row["alias"])) if row.get("alias") else row["mac"]
                    for row in parsed
                )
            else:
                cfg.value = value
            self["config"].invalidateCurrent()

    def _normalisePortal(self):
        portal = (self.portal.value or "").strip().rstrip("/")
        if portal and "://" not in portal:
            portal = "http://" + portal
        return portal

    def _normaliseMacs(self):
        return self._parseMacList(self.mac.value)

    def _normaliseMac(self):
        rows = self._normaliseMacs()
        return rows[0]["mac"] if rows else ""

    def _diagnosticText(self, report):
        report = report or {}
        endpoint = report.get("endpoint") or "Not detected"
        quick = bool(report.get("quick_test"))
        lines = [
            "Portal path: %s" % endpoint,
            "Handshake: %s" % ("OK" if report.get("handshake") else "FAILED"),
            "Profile: %s" % ("OK" if report.get("profile") else "FAILED"),
            "Live categories: %s" % int(report.get("categories") or 0),
            "Live channels: %s" % ("SKIPPED" if quick else int(report.get("channels") or 0)),
            "Create live link: %s" % ("SKIPPED" if quick else ("OK" if report.get("live_link") else "FAILED")),
        ]
        if report.get("error"):
            lines.append("Error: %s" % report.get("error"))
        lines.append("Player engine is tested during playback; try 4097, 5002 or 5001 if video is black.")
        return "\n".join(lines)

    def testPortal(self):
        portal = self._normalisePortal()
        macs = self._normaliseMacs()
        mac = macs[0]["mac"] if macs else ""
        parts = mac.split(":")
        try:
            valid_mac = len(parts) == 6 and all(len(part) == 2 and int(part, 16) >= 0 for part in parts)
        except Exception:
            valid_mac = False
        if not ((portal.startswith("http://") or portal.startswith("https://")) and valid_mac):
            self.session.open(MessageBox, "Enter a valid Portal URL and MAC first.", MessageBox.TYPE_ERROR); return
        self["hint"].setText("Testing portal with first MAC (%d saved): handshake, profile and categories..." % len(macs))
        source = {"type": "stalker", "name": self.provider.value or "Stalker Portal", "url": portal, "mac": mac}
        def worker():
            try:
                report = StalkerClient(source).test()
            except Exception as exc:
                report = {"ok": False, "error": str(exc), "stage": "test"}
            message = self._diagnosticText(report)
            def done():
                try:
                    self["hint"].setText("Portal test completed.")
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO if report.get("ok") else MessageBox.TYPE_ERROR, timeout=15)
                except Exception:
                    pass
            try:
                reactor.callFromThread(done) if reactor is not None else done()
            except Exception:
                done()
        thread = threading.Thread(target=worker, name="TiviMateStalkerTest")
        thread.daemon = True
        thread.start()

    def save(self):
        portal = self._normalisePortal()
        macs = self._normaliseMacs()
        mac = macs[0]["mac"] if macs else ""
        valid_portal = portal.startswith("http://") or portal.startswith("https://")
        parts = mac.split(":")
        try:
            valid_mac = len(parts) == 6 and all(len(part) == 2 and int(part, 16) >= 0 for part in parts)
        except Exception:
            valid_mac = False
        if not valid_portal or not valid_mac:
            self.session.open(MessageBox, "Enter a valid Portal URL and a MAG MAC address in the format 00:1A:79:12:34:56.", MessageBox.TYPE_ERROR); return
        src = dict(self.original or {})
        src.update({
            "type": "stalker",
            "name": (self.provider.value or "Stalker Portal").strip() or "Stalker Portal",
            "url": portal,
            "macs": list(macs),
            "mac": mac,
            "epg_offset": self.epgOffset.value,
            "service_type": _clean_stream_type(self.liveStreamType.value),
            "show_live_poster": bool(self.livePoster.value),
            "show_live_infobar_poster": bool(self.liveInfobarPoster.value),
            "adult_enabled": not bool(self.adultContent.value),
            "catchup_enabled": bool(self.catchupEnabled.value)
        })
        stalker_types = _load_stalker_service_types(src)
        stalker_types["live"] = _clean_stream_type(self.liveStreamType.value)
        _save_stalker_service_types(src, stalker_types)
        src.pop("mac_alias", None)
        src.pop("alias", None)
        self.close(src)


class TMDbKeyImportBrowser(Screen):
    """Tiny local file browser used only to import a private TMDb credential.

    The shared credential is never displayed here.  The browser starts at / so
    users can reach HDD, USB, /tmp, /home/root and any other mounted Enigma2
    path with the remote control.
    """
    skin = r"""<screen name="TMDbKeyImportBrowser" position="center,center" size="1500,850" flags="wfNoBorder" backgroundColor="#070A0E">
        <eLabel position="0,0" size="1500,92" backgroundColor="#0B1118" zPosition="1"/>
        <widget name="title" position="48,18" size="900,54" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="2"/>
        <widget name="path" position="48,102" size="1404,46" font="Regular;25" foregroundColor="#9CB6C9" transparent="1" zPosition="2"/>
        <widget name="list" position="48,162" size="1404,570" font="Regular;28" itemHeight="48" scrollbarMode="showOnDemand" backgroundColor="#090E14" foregroundColor="#FFFFFF" zPosition="2"/>
        <eLabel position="48,752" size="1404,2" backgroundColor="#244256" zPosition="2"/>
        <widget name="hint" position="48,770" size="1404,52" font="Regular;24" foregroundColor="#DDE8F0" transparent="1" halign="center" valign="center" zPosition="2"/>
    </screen>"""

    def __init__(self, session, start_path="/"):
        Screen.__init__(self, session)
        self.current_path = self._safe_dir(start_path)
        self.entries = []
        self["title"] = Label("IMPORT TMDb KEY")
        self["path"] = Label("")
        self["list"] = MenuList([])
        self["hint"] = Label("OK  OPEN / IMPORT     BACK  PARENT     RED  CANCEL")
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok,
            "cancel": self.back,
            "red": self.close,
            "up": self.up,
            "down": self.down,
            "left": self.pageUp,
            "right": self.pageDown,
        }, -1)
        self._reload()

    def _safe_dir(self, path):
        try:
            path = os.path.abspath(path or "/")
            if os.path.isdir(path):
                return path
        except Exception:
            pass
        return "/"

    def _reload(self):
        path = self._safe_dir(self.current_path)
        self.current_path = path
        rows = []
        entries = []
        if path != "/":
            rows.append("[..]  Parent folder")
            entries.append(("parent", os.path.dirname(path.rstrip("/")) or "/"))
        try:
            names = os.listdir(path)
        except Exception:
            names = []
        dirs, files = [], []
        for name in names:
            if not name or name in (".", ".."):
                continue
            full = os.path.join(path, name)
            try:
                if os.path.isdir(full):
                    dirs.append((name.lower(), name, full))
                elif os.path.isfile(full):
                    files.append((name.lower(), name, full))
            except Exception:
                continue
        dirs.sort(key=lambda x: x[0])
        files.sort(key=lambda x: x[0])
        for _, name, full in dirs:
            rows.append("[DIR]  %s" % name)
            entries.append(("dir", full))
        for _, name, full in files:
            try:
                size = os.path.getsize(full)
                size_txt = self._fmt_size(size)
            except Exception:
                size_txt = ""
            rows.append("       %s%s" % (name, ("   (%s)" % size_txt) if size_txt else ""))
            entries.append(("file", full))
        if not rows:
            rows = ["(empty folder)"]
            entries = [("empty", path)]
        self.entries = entries
        self["list"].setList(rows)
        self["path"].setText(path)

    def _fmt_size(self, size):
        try:
            size = int(size)
        except Exception:
            return ""
        if size < 1024:
            return "%d B" % size
        if size < 1024 * 1024:
            return "%.1f KB" % (size / 1024.0)
        return "%.1f MB" % (size / (1024.0 * 1024.0))

    def _index(self):
        try:
            return int(self["list"].getSelectedIndex())
        except Exception:
            try:
                return int(self["list"].l.getCurrentSelectionIndex())
            except Exception:
                return 0

    def _selected(self):
        idx = self._index()
        if 0 <= idx < len(self.entries):
            return self.entries[idx]
        return None

    def up(self):
        try: self["list"].up()
        except Exception: pass

    def down(self):
        try: self["list"].down()
        except Exception: pass

    def pageUp(self):
        try: self["list"].pageUp()
        except Exception: pass

    def pageDown(self):
        try: self["list"].pageDown()
        except Exception: pass

    def back(self):
        if self.current_path == "/":
            self.close(None)
            return
        self.current_path = os.path.dirname(self.current_path.rstrip("/")) or "/"
        self._reload()

    def ok(self):
        selected = self._selected()
        if not selected:
            return
        kind, path = selected
        if kind in ("parent", "dir"):
            self.current_path = self._safe_dir(path)
            self._reload()
            return
        if kind != "file":
            return
        try:
            key = self._read_key(path)
        except Exception as exc:
            self.session.open(MessageBox, "Unable to import this file: %s" % exc, MessageBox.TYPE_ERROR, timeout=6)
            return
        if not key:
            self.session.open(MessageBox, "No valid TMDb key was found in this file.", MessageBox.TYPE_ERROR, timeout=6)
            return
        self.close(key)

    def _read_key(self, path):
        # Keys are tiny text values.  Refuse huge/binary files so selecting a
        # movie, database or image cannot stall the receiver.
        try:
            size = os.path.getsize(path)
        except Exception:
            size = 0
        if size > 65536:
            raise ValueError("file is too large")
        with open(path, "rb") as handle:
            raw = handle.read(65536)
        if b"\x00" in raw:
            raise ValueError("file is not plain text")
        try:
            text = raw.decode("utf-8-sig")
        except Exception:
            text = raw.decode("latin-1", "ignore")
        text = text.strip()
        if not text:
            return ""

        # JSON export support, e.g. {"tmdb_key":"..."}.
        try:
            obj = json.loads(text)
            if isinstance(obj, dict):
                for name in ("tmdb_key", "tmdb_api_key", "api_key", "access_token", "token", "key"):
                    value = obj.get(name)
                    if isinstance(value, str) and value.strip():
                        return self._clean_value(value)
        except Exception:
            pass

        wanted = set(("tmdb_key", "tmdb_api_key", "api_key", "access_token", "token", "key"))
        raw_candidates = []
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith(";"):
                continue
            raw_candidates.append(line)
            for sep in ("=", ":"):
                if sep in line:
                    left, right = line.split(sep, 1)
                    left = left.strip().lower().replace("-", "_").replace(" ", "_")
                    if left in wanted and right.strip():
                        return self._clean_value(right)
        if len(raw_candidates) == 1:
            return self._clean_value(raw_candidates[0])
        # If a normal key/token appears among comments or metadata, accept the
        # first credential-looking line only; never display it in the browser.
        for value in raw_candidates:
            cleaned = self._clean_value(value)
            if self._looks_like_key(cleaned):
                return cleaned
        return ""

    def _clean_value(self, value):
        value = str(value or "").strip().strip('"').strip("'").strip()
        if value.lower().startswith("bearer "):
            value = value[7:].strip()
        return value

    def _looks_like_key(self, value):
        if not value or len(value) < 16 or len(value) > 4096:
            return False
        if any(ch.isspace() for ch in value):
            return False
        return True



# ---------------------------------------------------------------------------
# TMDb settings
# ---------------------------------------------------------------------------

class TMDbSettings(Screen, ConfigListScreen):
    skin = TMDB_SETTINGS_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = load_tmdb_settings()
        self["title"] = Label(tr("TMDb TRENDING SETTINGS"))
        self["hint"] = Label(tr("Built-in TMDb access is active. Enter your own key only to override it."))
        self["keys"] = Label("GREEN SAVE    BLUE TEST    YELLOW IMPORT TMDB KEY    RED CANCEL")
        self.mode = ConfigSelection(default=cfg.get("mode", "auto"), choices=[
            ("auto", "Auto (Shared key / Custom key)"),
            ("disabled", "Disabled"),
        ])
        # Keep the three legacy credential fields out of the visible UI. A single
        # masked override is easier to use and preserves the shared built-in key
        # when left empty. Existing v3/v4 overrides are migrated into this field.
        existing_custom = (cfg.get("custom_api_key") or cfg.get("custom_api_key2") or cfg.get("custom_access_token") or "")
        self.customTmdbKey = ConfigPassword(default=existing_custom, fixed_size=False)
        self.language = ConfigSelection(default=cfg.get("language_setting", cfg.get("language", "auto")), choices=[("auto", "Device language (Auto)"), ("en-US", "English"), ("ar-AE", "Arabic")])
        self.backdropQuality = ConfigSelection(default=cfg.get("backdrop_quality", "w1280"), choices=[
            ("w1280", "Balanced (1280)"),
            ("w1920", "High (1920)"),
            ("original", "Original"),
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry("TMDb Mode", self.mode),
            getConfigListEntry(tr("Metadata language"), self.language),
            getConfigListEntry("Backdrop Quality", self.backdropQuality),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.openKeyboard, "green": self.save, "blue": self.testConnection,
            "yellow": self.addTmdbKey, "red": self.close, "cancel": self.close
        }, -1)


    def addTmdbKey(self):
        # Import from a local text/key/config file.  The built-in shared key and
        # any previously saved private key are never displayed on screen.
        self.session.openWithCallback(self.tmdbKeyEntered, TMDbKeyImportBrowser, "/")

    def tmdbKeyEntered(self, value=None):
        if value is None:
            return
        self.customTmdbKey.value = (value or "").strip()
        try:
            self["hint"].setText("Custom TMDb key ready. Press GREEN to save.")
        except Exception:
            pass

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if current and isinstance(current[1], ConfigText):
            self.session.openWithCallback(self.keyboardDone, VirtualKeyBoard, title=current[0], text=current[1].value or "")

    def keyboardDone(self, value=None):
        if value is None: return
        current = self["config"].getCurrent()
        if current:
            current[1].value = value
            self["config"].invalidateCurrent()

    def _credentialsValid(self):
        # Enabled modes always have shared built-in credentials; fields here are
        # optional user overrides.
        return True

    def _splitCustomCredential(self):
        value = (self.customTmdbKey.value or "").strip()
        if not value:
            return "", ""
        # TMDb v4 read-access tokens are long bearer/JWT-like strings. Standard
        # v3 API keys are short hex-like values. Keep detection deliberately
        # simple so pasted keys continue to work without another mode selector.
        lower = value.lower()
        if len(value) > 64 or lower.startswith("eyj") or value.count(".") >= 2:
            return "", value
        return value, ""

    def save(self):
        if not self._credentialsValid():
            self.session.open(MessageBox, "Enter the credential required by the selected TMDb mode.", MessageBox.TYPE_ERROR); return
        custom_key, custom_token = self._splitCustomCredential()
        # One visible custom key replaces the three legacy override fields. The
        # second custom API key is intentionally cleared; shared fallback remains.
        if save_tmdb_settings(custom_key, self.language.value, self.mode.value, custom_token, "", self.backdropQuality.value):
            self.session.open(MessageBox, "TMDb settings saved.", MessageBox.TYPE_INFO, timeout=4)
            self.close()
        else:
            self.session.open(MessageBox, "Unable to save settings.", MessageBox.TYPE_ERROR)

    def testConnection(self):
        if not self._credentialsValid():
            self.session.open(MessageBox, "Enter the credential required by the selected TMDb mode.", MessageBox.TYPE_ERROR); return
        self["hint"].setText("Testing TMDb connection...")
        mode = self.mode.value
        custom_key, custom_token = self._splitCustomCredential()
        key = custom_key or None
        token = custom_token or None
        key2 = None
        language = self.language.value
        def worker():
            ok, message = False, ""
            try:
                client = TMDbClient(api_key=key, api_key2=key2, access_token=token, mode=mode,
                    language=None if language == "auto" else language)
                client._get("/configuration", {})
                ok, message = True, "TMDb connection successful."
            except Exception as exc:
                message = "TMDb connection failed: %s" % exc
            def done():
                try:
                    self["hint"].setText(message)
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR, timeout=6)
                except Exception:
                    pass
            try:
                reactor.callFromThread(done) if reactor is not None else done()
            except Exception:
                done()
        t = threading.Thread(target=worker, name="TiviMateTMDbTest")
        t.daemon = True
        t.start()


SERVER_CATEGORY_FILTER_SKIN = r"""<screen name="ServerCategoryFilter" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#02060B">
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_cinematic_bg_r209.jpg" alphatest="blend" zPosition="0"/>
<eLabel position="0,0" size="1920,128" backgroundColor="#050A10" zPosition="1"/>
<eLabel position="48,126" size="1824,2" backgroundColor="#153653" zPosition="2"/>
<ePixmap position="64,26" size="306,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" zPosition="4"/>
<widget name="brand" position="1,1" size="1,1" font="Regular;1" foregroundColor="#FFFFFF" transparent="1" zPosition="1"/>
<widget name="title" position="430,25" size="900,52" font="Regular;38" foregroundColor="#FFFFFF" transparent="1" zPosition="4"/>
<eLabel position="432,78" size="720,30" text="Select and filter server packages" font="Regular;22" foregroundColor="#8EA7BA" transparent="1" zPosition="4"/>
<widget name="page" position="1460,36" size="390,46" font="Regular;27" foregroundColor="#D7E8F5" transparent="1" halign="right" zPosition="4"/>

<eLabel position="102,150" size="548,112" backgroundColor="#071A2B" zPosition="1"/>
<eLabel position="686,150" size="548,112" backgroundColor="#21112F" zPosition="1"/>
<eLabel position="1270,150" size="548,112" backgroundColor="#07282E" zPosition="1"/>
<ePixmap position="132,168" size="76,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_tab_live_r209.png" alphatest="blend" zPosition="4"/>
<ePixmap position="716,168" size="76,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_tab_vod_r209.png" alphatest="blend" zPosition="4"/>
<ePixmap position="1300,168" size="76,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_tab_series_r209.png" alphatest="blend" zPosition="4"/>
<widget name="tabLive" position="218,177" size="405,56" font="Regular;32" foregroundColor="#59C8FF" transparent="1" halign="center" valign="center" zPosition="4"/>
<widget name="tabMovies" position="802,177" size="405,56" font="Regular;32" foregroundColor="#C987FF" transparent="1" halign="center" valign="center" zPosition="4"/>
<widget name="tabSeries" position="1386,177" size="405,56" font="Regular;32" foregroundColor="#54E4D6" transparent="1" halign="center" valign="center" zPosition="4"/>
<widget name="tabFocus" position="102,258" size="548,5" backgroundColor="#59C8FF" zPosition="5"/>

<widget name="card0" position="102,286" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon0" position="124,325" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name0" position="228,320" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta0" position="228,376" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state0" position="508,346" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card1" position="700,286" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon1" position="722,325" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name1" position="826,320" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta1" position="826,376" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state1" position="1106,346" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card2" position="1298,286" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon2" position="1320,325" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name2" position="1424,320" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta2" position="1424,376" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state2" position="1704,346" size="92,42" alphatest="blend" zPosition="5"/>

<widget name="card3" position="102,470" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon3" position="124,509" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name3" position="228,504" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta3" position="228,560" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state3" position="508,530" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card4" position="700,470" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon4" position="722,509" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name4" position="826,504" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta4" position="826,560" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state4" position="1106,530" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card5" position="1298,470" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon5" position="1320,509" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name5" position="1424,504" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta5" position="1424,560" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state5" position="1704,530" size="92,42" alphatest="blend" zPosition="5"/>

<widget name="card6" position="102,654" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon6" position="124,693" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name6" position="228,688" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta6" position="228,744" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state6" position="508,714" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card7" position="700,654" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon7" position="722,693" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name7" position="826,688" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta7" position="826,744" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state7" position="1106,714" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card8" position="1298,654" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon8" position="1320,693" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name8" position="1424,688" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta8" position="1424,744" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state8" position="1704,714" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="cardFocus" position="96,280" size="532,174" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_focus_r208.png" alphatest="blend" zPosition="7"/>

<widget name="summary" position="190,836" size="1540,42" font="Regular;26" foregroundColor="#B9D7EA" transparent="1" halign="center" zPosition="4"/>
<widget name="hint" position="190,879" size="1540,32" font="Regular;20" foregroundColor="#8299AA" transparent="1" halign="center" zPosition="4"/>
<eLabel position="58,930" size="1804,2" backgroundColor="#17324B" zPosition="2"/>

<ePixmap position="90,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_key_red_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="150,964" size="205,42" text="Disable All" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<ePixmap position="370,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_key_yellow_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="430,964" size="205,42" text="Enable All" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<ePixmap position="650,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_key_green_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="710,964" size="190,42" text="Save Filters" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<ePixmap position="930,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_key_blue_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="990,964" size="220,42" text="Change Category" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<ePixmap position="1240,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_key_nav_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="1300,964" size="185,42" text="Navigate" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<ePixmap position="1510,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_key_ok_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="1570,964" size="245,42" text="Select / Toggle" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<widget name="keys" position="1,1" size="1,1" font="Regular;1" foregroundColor="#FFFFFF" transparent="1" zPosition="1"/>
</screen>"""


# ---------------------------------------------------------------------------
# Server and package filters
# ---------------------------------------------------------------------------

class ServerCategoryFilter(Screen):
    skin = SERVER_CATEGORY_FILTER_SKIN
    ALL_KINDS = [("live", "LIVE TV"), ("vod", "MOVIES"), ("series", "TV SHOWS")]
    PAGE_SIZE = 9
    CARD_POSITIONS = [
        (102,286),(700,286),(1298,286),
        (102,470),(700,470),(1298,470),
        (102,654),(700,654),(1298,654),
    ]

    def __init__(self, session, source, initial_kind=None, fixed_kind=False):
        Screen.__init__(self, session)
        self.source = source or {}
        self.fixed_kind = bool(fixed_kind)
        requested = str(initial_kind or "").strip().lower()
        if self.fixed_kind and requested in ("vod", "series"):
            self.KINDS = [(requested, "MOVIES" if requested == "vod" else "TV SHOWS")]
        elif self.source.get("type") in ("stalker", "xtream"):
            self.KINDS = list(self.ALL_KINDS)
        else:
            self.KINDS = [("live", "LIVE TV")]
        self.kindIndex = 0
        if requested:
            for i, item in enumerate(self.KINDS):
                if item[0] == requested:
                    self.kindIndex = i
                    break
        self.pageIndex = 0
        self.cursorIndex = 0
        self.rows = []
        self.selected = {}
        self.loaded = {}
        self["brand"] = Label("TiViMate E2")
        self["title"] = Label("")
        self["page"] = Label("")
        self["tabLive"] = Label("LIVE TV")
        self["tabMovies"] = Label("MOVIES")
        self["tabSeries"] = Label("TV SHOWS")
        self["tabFocus"] = Label("")
        for i in range(9):
            self["card%d" % i] = Pixmap()
            self["icon%d" % i] = Pixmap()
            self["name%d" % i] = Label("")
            self["meta%d" % i] = Label("")
            self["state%d" % i] = Pixmap()
        self["cardFocus"] = Pixmap()
        self["summary"] = Label("")
        self["hint"] = Label("")
        self["keys"] = Label("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.toggle, "cancel": self.close, "green": self.save,
            "yellow": self.selectAll, "red": self.clearAll, "blue": self.nextKind,
            "left": self.moveLeft, "right": self.moveRight,
            "up": self.moveUp, "down": self.moveDown,
            "pageUp": self.prevPage, "pageDown": self.nextPage,
        }, -1)
        self.onLayoutFinish.append(self.loadCurrent)

    def _kind(self):
        return self.KINDS[self.kindIndex][0]

    def _updateTabs(self):
        kind = self._kind()
        pos = {"live": (102,258), "vod": (686,258), "series": (1270,258)}.get(kind, (102,258))
        color = {"live":"#58C0FF", "vod":"#C68BFF", "series":"#52E7D8"}.get(kind, "#58C0FF")
        try:
            self["tabFocus"].instance.move(ePoint(pos[0], pos[1]))
            self["tabFocus"].instance.resize(eSize(548,5))
            self["tabFocus"].instance.setBackgroundColor(parseColor(color))
        except Exception:
            pass

    def _updateFocus(self):
        if not self.rows:
            try: self["cardFocus"].hide()
            except Exception: pass
            return
        self.cursorIndex = max(0, min(self.cursorIndex, len(self.rows)-1))
        x, y = self.CARD_POSITIONS[self.cursorIndex]
        try:
            self["cardFocus"].show()
            self["cardFocus"].instance.move(ePoint(x-6, y-6))
        except Exception:
            pass

    def loadCurrent(self):
        kind, label = self.KINDS[self.kindIndex]
        self.pageIndex = 0
        self.cursorIndex = 0
        self["title"].setText("PACKAGE FILTER  •  %s" % label)
        self["hint"].setText("")
        self._updateTabs()
        try:
            source_type = self.source.get("type")
            if source_type == "xtream":
                cats = XtreamClient(self.source).categories(kind) or []
                candidates = [(c.get("category_id", ""), c.get("category_name") or "Other") for c in cats]
            elif source_type == "stalker":
                cats = StalkerClient(self.source).categories(kind) or []
                candidates = [(c.get("category_id", ""), c.get("category_name") or "Other") for c in cats]
            else:
                entries = M3UClient(self.source).entries() or []
                candidates = [(e.get("group", "Other"), e.get("group", "Other")) for e in entries]
            clean, seen = [], set()
            for raw_id, raw_name in candidates:
                cid = str(raw_id or "").strip()
                if not cid or cid in seen:
                    continue
                seen.add(cid)
                clean.append({"id": cid, "name": str(raw_name or "Other").strip()})
            self.loaded[kind] = clean
            if kind not in self.selected:
                configured = get_allowed_category_ids(self.source, kind)
                self.selected[kind] = set(x["id"] for x in clean) if configured is None else set(configured)
            self.render()
        except Exception as exc:
            self.rows = []
            self["page"].setText("PAGE 0 / 0")
            self["summary"].setText("")
            self["hint"].setText("Unable to load packages: %s" % exc)
            for i in range(9):
                self["name%d" % i].setText("")
                self["meta%d" % i].setText("")
                try:
                    self["card%d" % i].hide(); self["icon%d" % i].hide(); self["state%d" % i].hide()
                except Exception:
                    pass
            self._updateFocus()

    def render(self):
        kind, label = self.KINDS[self.kindIndex]
        selected = self.selected.get(kind, set())
        allrows = self.loaded.get(kind, [])
        pages = max(1, (len(allrows) + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
        self.pageIndex = max(0, min(self.pageIndex, pages - 1))
        a = self.pageIndex * self.PAGE_SIZE
        b = a + self.PAGE_SIZE
        self.rows = allrows[a:b]
        self.cursorIndex = max(0, min(self.cursorIndex, max(0, len(self.rows)-1)))
        accent = {"live": ("LIVE", "#0E3150", "#59C8FF"), "vod": ("MOV", "#2B1840", "#C987FF"), "series": ("TV", "#08343A", "#54E4D6")}.get(kind, ("PKG", "#123149", "#59C8FF"))
        for i in range(9):
            card = self["card%d" % i]
            icon = self["icon%d" % i]
            name_w = self["name%d" % i]
            meta = self["meta%d" % i]
            state = self["state%d" % i]
            if i < len(self.rows):
                row = self.rows[i]
                number = a + i + 1
                name = row.get("name") or "Other"
                if len(name) > 30:
                    name = name[:27] + "..."
                name_w.setText(name)
                meta.setText("PACKAGE %02d" % number)
                enabled = row.get("id") in selected
                try:
                    icon_path = os.path.join(PLUGIN_PATH, "skins/packages/package_filter_icon_%s_r208.png" % kind)
                    switch_path = os.path.join(PLUGIN_PATH, "skins/packages/package_filter_switch_%s_r208.png" % ("on" if enabled else "off"))
                    icon.instance.setPixmap(LoadPixmap(icon_path))
                    state.instance.setPixmap(LoadPixmap(switch_path))
                    card.show(); icon.show(); state.show()
                except Exception:
                    pass
            else:
                name_w.setText("")
                meta.setText("")
                try:
                    card.hide(); icon.hide(); state.hide()
                except Exception:
                    pass
        self["page"].setText("PAGE %d / %d" % (self.pageIndex + 1, pages))
        shown_from = 0 if not allrows else a + 1
        shown_to = min(b, len(allrows))
        self["summary"].setText("%s   •   %d / %d ENABLED   •   %d-%d" % (label, len(selected), len(allrows), shown_from, shown_to))
        self["hint"].setText("Use arrows to navigate • OK toggles package • edge left/right changes page")
        self._updateTabs()
        self._updateFocus()

    def toggle(self):
        if not self.rows or self.cursorIndex >= len(self.rows):
            return
        kind = self._kind()
        cid = str(self.rows[self.cursorIndex].get("id") or "")
        selected = self.selected.setdefault(kind, set())
        if cid in selected:
            selected.remove(cid)
        else:
            selected.add(cid)
        self.render()

    def selectAll(self):
        self.selected[self._kind()] = set(x["id"] for x in self.loaded.get(self._kind(), []))
        self.render()

    def clearAll(self):
        self.selected[self._kind()] = set()
        self.render()

    def prevPage(self):
        if self.pageIndex > 0:
            self.pageIndex -= 1
            self.cursorIndex = 0
            self.render()

    def nextPage(self):
        total = len(self.loaded.get(self._kind(), []))
        pages = max(1, (total + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
        if self.pageIndex + 1 < pages:
            self.pageIndex += 1
            self.cursorIndex = 0
            self.render()

    def moveLeft(self):
        if not self.rows:
            return
        col = self.cursorIndex % 3
        if col > 0:
            self.cursorIndex -= 1
            self._updateFocus()
        elif self.pageIndex > 0:
            self.pageIndex -= 1
            self.cursorIndex = min(2, len(self.loaded.get(self._kind(), [])) - self.pageIndex * self.PAGE_SIZE - 1)
            self.render()

    def moveRight(self):
        if not self.rows:
            return
        col = self.cursorIndex % 3
        if col < 2 and self.cursorIndex + 1 < len(self.rows):
            self.cursorIndex += 1
            self._updateFocus()
        else:
            total = len(self.loaded.get(self._kind(), []))
            pages = max(1, (total + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
            if self.pageIndex + 1 < pages:
                self.pageIndex += 1
                self.cursorIndex = 0
                self.render()

    def moveUp(self):
        if not self.rows:
            return
        if self.cursorIndex >= 3:
            self.cursorIndex -= 3
            self._updateFocus()
        elif self.pageIndex > 0:
            self.pageIndex -= 1
            self.cursorIndex = min(self.cursorIndex + 6, 8)
            self.render()

    def moveDown(self):
        if not self.rows:
            return
        if self.cursorIndex + 3 < len(self.rows):
            self.cursorIndex += 3
            self._updateFocus()
        else:
            total = len(self.loaded.get(self._kind(), []))
            pages = max(1, (total + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
            if self.pageIndex + 1 < pages:
                self.pageIndex += 1
                self.cursorIndex = self.cursorIndex % 3
                self.render()

    def nextKind(self):
        if len(self.KINDS) > 1:
            self.kindIndex = (self.kindIndex + 1) % len(self.KINDS)
            self.loadCurrent()

    def prevKind(self):
        if len(self.KINDS) > 1:
            self.kindIndex = (self.kindIndex - 1) % len(self.KINDS)
            self.loadCurrent()

    def save(self):
        data = _load_all_filters()
        key = _source_filter_key(self.source)
        entry = dict(data.get(key, {}) or {})
        for kind, _label in self.KINDS:
            if kind not in self.selected:
                continue
            selected = set(str(x) for x in self.selected.get(kind, set()))
            available = set(str(x.get("id") or "") for x in self.loaded.get(kind, []))
            if available and selected == available:
                entry.pop(kind, None)
            else:
                entry[kind] = sorted(selected)
        if entry:
            data[key] = entry
        else:
            data.pop(key, None)
        if _save_all_filters(data):
            try:
                prefetch_selected_categories(self.source, entry)
            except Exception:
                pass
            try:
                from .epg_local import refresh_source_epg
                refresh_source_epg(self.source, force=True, background=True)
            except Exception:
                pass
            self.session.open(MessageBox, "Packages saved. EPG for selected packages is updating in the background.", MessageBox.TYPE_INFO)
            self.close(True)
        else:
            self.session.open(MessageBox, "Unable to save the filter.", MessageBox.TYPE_ERROR)






PROFESSIONAL_PACKAGE_BROWSER_SKIN = r"""<screen name="HomePackageBrowserScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#030508">
<widget name="background" position="0,0" size="1920,1080" alphatest="blend" scale="1" zPosition="0"/>
<eLabel position="0,0" size="390,1080" backgroundColor="#050608" zPosition="3"/>
<eLabel position="389,0" size="2,1080" backgroundColor="#D9DDE2" zPosition="4"/>
<ePixmap position="28,24" size="325,96" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_e2_gold_logo.png" alphatest="blend" scale="1" zPosition="6"/>
<widget name="sideSelector" position="15,389" size="360,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/packages_nav_focus_r52.png" alphatest="blend" zPosition="7"/>

<widget name="nav0" position="78,130" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<widget name="nav1" position="78,215" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<widget name="nav2" position="78,300" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<widget name="nav3" position="78,402" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<widget name="nav4" position="78,500" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<widget name="nav5" position="78,585" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<ePixmap position="35,928" size="320,90" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/developed_by_opesboy_signature_r212.png" alphatest="blend" scale="1" zPosition="8"/>

<widget name="title" position="500,80" size="930,70" font="Regular;50" foregroundColor="#E5B243" transparent="1" zPosition="8"/>
<widget name="subtitle" position="505,160" size="1000,34" font="Regular;22" foregroundColor="#E0D8EE" transparent="1" zPosition="8"/>
<widget name="count" position="1430,110" size="320,40" font="Regular;24" foregroundColor="#E5B243" transparent="1" halign="right" zPosition="8"/>
<widget name="serverNameBold" position="1281,148" size="470,48" font="Regular;32" foregroundColor="#FF3030" transparent="1" halign="right" valign="center" zPosition="8"/>
<widget name="serverName" position="1280,148" size="470,48" font="Regular;32" foregroundColor="#FF3030" transparent="1" halign="right" valign="center" zPosition="9"/>
<widget name="clock" position="1500,36" size="250,38" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="right" zPosition="8"/>
<widget name="date" position="1465,80" size="285,26" font="Regular;18" foregroundColor="#B3BDC7" transparent="1" halign="right" zPosition="8"/>

<eLabel position="475,225" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>
<eLabel position="475,318" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>
<eLabel position="475,411" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>
<eLabel position="475,504" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>
<eLabel position="475,597" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>
<eLabel position="475,690" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>

<widget name="logo0" position="500,237" size="150,58" alphatest="blend" scale="1" zPosition="7"/>
<widget name="logo1" position="500,330" size="150,58" alphatest="blend" scale="1" zPosition="7"/>
<widget name="logo2" position="500,423" size="150,58" alphatest="blend" scale="1" zPosition="7"/>
<widget name="logo3" position="500,516" size="150,58" alphatest="blend" scale="1" zPosition="7"/>
<widget name="logo4" position="500,609" size="150,58" alphatest="blend" scale="1" zPosition="7"/>
<widget name="logo5" position="500,702" size="150,58" alphatest="blend" scale="1" zPosition="7"/>

<widget name="row0" position="675,232" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>
<widget name="row1" position="675,325" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>
<widget name="row2" position="675,418" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>
<widget name="row3" position="675,511" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>
<widget name="row4" position="675,604" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>
<widget name="row5" position="675,697" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>

<widget name="desc0" position="675,269" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>
<widget name="desc1" position="675,362" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>
<widget name="desc2" position="675,455" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>
<widget name="desc3" position="675,548" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>
<widget name="desc4" position="675,641" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>
<widget name="desc5" position="675,734" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>

<widget name="meta0" position="1460,242" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>
<widget name="meta1" position="1460,335" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>
<widget name="meta2" position="1460,428" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>
<widget name="meta3" position="1460,521" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>
<widget name="meta4" position="1460,614" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>
<widget name="meta5" position="1460,707" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>

<widget name="packageTextFocusBg" position="655,232" size="1080,66" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_text_focus_bg_r180.png" alphatest="blend" zPosition="6"/>
<widget name="packageSelector" position="475,225" size="1340,84" alphatest="blend" zPosition="9"/>

<eLabel position="475,820" size="1340,82" backgroundColor="#07080B" cornerRadius="16" zPosition="4"/>
<ePixmap position="510,832" size="56,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_key_red_r209.png" alphatest="blend" scale="1" zPosition="8"/>
<widget name="back" position="575,839" size="175,48" font="Regular;22" foregroundColor="#FFFFFF" transparent="1" halign="left" valign="center" zPosition="8"/>
<ePixmap position="760,832" size="56,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_key_green_r209.png" alphatest="blend" scale="1" zPosition="8"/>
<widget name="info" position="825,839" size="300,48" font="Regular;22" foregroundColor="#FFFFFF" transparent="1" halign="left" valign="center" zPosition="8"/>
<ePixmap position="1140,832" size="56,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_key_yellow_r209.png" alphatest="blend" scale="1" zPosition="8"/>
<widget name="sort" position="1205,839" size="220,48" font="Regular;22" foregroundColor="#FFD34E" transparent="1" halign="left" valign="center" zPosition="8"/>
<ePixmap position="1430,832" size="56,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_key_blue_r209.png" alphatest="blend" scale="1" zPosition="8"/>
<widget name="open" position="1495,839" size="220,48" font="Regular;22" foregroundColor="#FFFFFF" transparent="1" halign="left" valign="center" zPosition="8"/>
<widget name="packageFocusBold" position="676,232" size="760,42" font="Regular;31" foregroundColor="#FFD34E" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="11"/>
<eLabel position="710,908" size="860,58" backgroundColor="#07080B" cornerRadius="12" zPosition="4"/>
<widget name="packageMenuHint" position="730,912" size="820,50" font="Regular;26" foregroundColor="#FFD34E" transparent="1" halign="center" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="8"/>
</screen>"""


def _package_glass_rows(base_skin):
    """Apply the shared six-row glass treatment to Movies and TV package pages."""
    skin = base_skin
    for y in (225, 318, 411, 504, 597, 690):
        old = '<eLabel position="475,%d" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>' % y
        new = '<ePixmap position="475,%d" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/movie_package_glass_row_r67.png" alphatest="blend" zPosition="4"/>' % y
        skin = skin.replace(old, new)
    return skin


PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN = _package_glass_rows(PROFESSIONAL_PACKAGE_BROWSER_SKIN)
PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN

CONTENT_PACKAGE_CONTROLS_FILE = data_path("content_package_controls.json")
