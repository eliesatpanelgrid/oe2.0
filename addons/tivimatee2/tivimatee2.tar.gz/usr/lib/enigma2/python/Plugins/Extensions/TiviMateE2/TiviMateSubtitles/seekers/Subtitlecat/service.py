# -*- coding: utf-8 -*-

from __future__ import absolute_import, print_function
import os
import re
import requests
import random
import json
import warnings
from bs4 import BeautifulSoup
from six.moves.urllib.parse import quote_plus
from requests.packages.urllib3.exceptions import InsecureRequestWarning

warnings.simplefilter('ignore', InsecureRequestWarning)
user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.2 Mobile/15E148 Safari/604.1"
]

# Function to get a random User-Agent string
def get_random_ua():
    return random.choice(user_agents)

session = requests.Session()

# Set headers for the request
session.headers.update({
    "User-Agent": get_random_ua(),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Language": 'en-US,en;q=0.9,*;q=0.5',
    "Referer": "https://www.subtitlecat.com/",
})

main_url = "https://www.subtitlecat.com"

def getSearchTitle(title, year=None):
    url = f'{main_url}/index.php?search={quote_plus(title)}'
    pass  # debug output removed
    response = session.get(url, verify=False, timeout=8)
    return response.url  # Return final URL

def _norm_lang(value):
    try:
        value = str(value or "").strip().lower()
    except Exception:
        value = ""
    aliases = {
        "ar": "arabic", "ara": "arabic", "arab": "arabic", "العربية": "arabic",
        "en": "english", "eng": "english",
        "fr": "french", "fra": "french", "fre": "french",
    }
    return aliases.get(value, value)


def _wanted_language_names(languages):
    out = []
    for lang in (languages or []):
        value = _norm_lang(lang)
        if value and value not in out:
            out.append(value)
    return out


def _pick_language_link(page_url, wanted_languages):
    """Return the preferred ready SRT on a Subtitlecat multi-language page."""
    links = get_real_srt_links(page_url)
    if not links:
        return None

    wanted = _wanted_language_names(wanted_languages)
    for wanted_lang in wanted:
        for item in links:
            if _norm_lang(item.get("language")) == wanted_lang:
                return item

    # TiviMate is normally configured for Arabic. Never silently return a
    # different language from a '3 languages / 7 languages' result.
    return None


def getallsubs(response, wanted_languages=None, max_results=18):
    soup = BeautifulSoup(response.text, 'html.parser')
    subtitles = []

    # Subtitlecat's search page only says "3 languages", "7 languages", etc.
    # Resolve each candidate page and expose only the requested language.
    for row in soup.find_all('tr'):
        if len(subtitles) >= max_results:
            break
        link_tag = row.find('a')
        if not link_tag:
            continue

        title = link_tag.text.strip()
        href = main_url + "/" + link_tag['href'].strip()
        download_count = row.find_all('td')[-2].text.strip() if len(row.find_all('td')) > 2 else "0"

        try:
            picked = _pick_language_link(href, wanted_languages)
        except Exception:
            picked = None
        if not picked:
            continue

        language = picked.get("language", "") or ""
        language_norm = _norm_lang(language)

        item = {
            'filename': title,
            'link': href,
            'downloads': download_count,
            'language_name': "Arabic" if language_norm == "arabic" else language,
            'sync': True,
            '_tivimate_direct_srt': picked.get("download_link", ""),
            '_tivimate_language': language,
        }
        if language_norm == "arabic":
            # TiviMate Arabic result icon is the UAE flag.
            item['country'] = 'ar'
        subtitles.append(item)

    return subtitles


def search_movie(title, year, languages, filename):
    url = getSearchTitle(title, year)
    pass  # debug output removed
    response = session.get(url, verify=False, timeout=8)

    if response.status_code == 200:
        return getallsubs(response, languages)
    return []

def search_tvshow(tvshow, season, episode, languages, filename):
    search_query = f"{tvshow} S{int(season):02d}E{int(episode):02d}"
    return search_movie(search_query, None, languages, filename)

def search_manual(searchstr, languages, filename):
    return search_movie(searchstr, None, languages, filename)

def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    if tvshow:
        return search_tvshow(tvshow, season, episode, [lang1, lang2, lang3], file_original_path), "", ""
    elif title:
        return search_movie(title, year, [lang1, lang2, lang3], file_original_path), "", ""
    else:
        return search_manual(title, [lang1, lang2, lang3], file_original_path), "", ""

def get_real_srt_links(page_url):
    """
    Extracts only ready-to-download subtitles (.srt links) from a subtitle page.
    """
    response = requests.get(page_url, verify=False, timeout=8)
    if response.status_code != 200:
        return []  # Return empty if fetching page fails

    soup = BeautifulSoup(response.text, 'html.parser')
    srt_links = []

    # Find all available subtitles (ignores translation-needed ones)
    for sub_single in soup.find_all('div', class_='sub-single'):
        language = sub_single.find_all('span')[1].text.strip()
        download_tag = sub_single.find('a', class_='green-link')

        if download_tag:
            download_link = "https://www.subtitlecat.com" + download_tag['href']
            srt_links.append({"language": language, "download_link": download_link})

    return srt_links  # Returns only valid SRT links


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    """Download the exact language selected during search."""
    selected = subtitles_list[pos]
    srt_download_link = selected.get("_tivimate_direct_srt", "")
    language = selected.get("_tivimate_language", "") or selected.get("language_name", "")

    if not srt_download_link:
        page_url = selected.get("link", "")
        preferred = [language or selected.get("language_name", "")]
        picked = _pick_language_link(page_url, preferred)
        if not picked:
            raise Exception("Requested subtitle language is not available")
        srt_download_link = picked.get("download_link", "")
        language = picked.get("language", language)

    if not srt_download_link:
        raise Exception("No downloadable SRT file found")

    subtitle_response = requests.get(srt_download_link, verify=False, timeout=10)
    if subtitle_response.status_code != 200:
        raise Exception("Failed to download subtitle file")

    file_name = srt_download_link.split("/")[-1] or "subtitle.srt"
    file_path = os.path.join(tmp_sub_dir, file_name)
    with open(file_path, 'wb') as file:
        file.write(subtitle_response.content)

    return False, language, file_path
