# -*- coding: utf-8 -*-
from .storage import get_data_root, data_path
from datetime import datetime, date, timedelta

"""Small LAN-only web manager for TiviMateE2 server configuration.

The implementation intentionally uses only the Python standard library so it can
run on modern Python 3 Enigma2 images.
"""

from .cache_manager import get_log_path
import json
import os
import socket
import sys
import shutil
import threading
import time
import glob
import re
import hashlib

from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import parse_qs, urlparse, quote_plus
from html import escape as html_escape

from .core import get_sources, set_sources, write_playlists, load_json, save_json, XtreamClient, StalkerClient
from .server_status import evaluate_reply
from .cache_manager import cache_status, clear_cache, cleanup_cache, get_settings as get_cache_settings

WEB_PORT = 8088
WEB_HOST = "0.0.0.0"
VERSION = "1.0.10"
_LOCK = threading.RLock()
_SERVER = None
_THREAD = None

BACKUP_FILES = [
    data_path("channel_settings.json"), data_path("live_source.json"),
    data_path("stalker_hidden.json"), data_path("stalker_pin.json"),
    data_path("resume.json"), data_path("live_poster_index.json"),
    data_path("home_appearance.json"), data_path("update_settings.json"),
    data_path("active_source.json"), data_path("player.json"),
    data_path("recording.json"), data_path("language.json"),
]
BACKUP_DIRS = [get_data_root()]

def _json_text(data):
    value = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
    if not isinstance(value, str):
        value = str(value)
    return value

def _read_json_file(path):
    try:
        raw = open(path, "rb").read()
        if isinstance(raw, bytes):
            try: raw = raw.decode("utf-8", "replace")
            except Exception: pass
        return json.loads(raw)
    except Exception: return None

def _write_json_file(path, data):
    from .compat import open_text, atomic_replace, ensure_dir
    ensure_dir(os.path.dirname(path))
    tmp = path + ".tmp"
    with open_text(tmp, "w", encoding="utf-8") as fh: fh.write(_json_text(data))
    atomic_replace(tmp, path)

def _build_backup():
    files = {}
    paths = list(BACKUP_FILES)
    for directory in BACKUP_DIRS:
        try: paths.extend(glob.glob(os.path.join(directory, "*.json")))
        except Exception: pass
    for path in sorted(set(paths)):
        if os.path.isfile(path):
            data = _read_json_file(path)
            if data is not None: files[path] = data
    return {"format":"TiviMateE2-backup-v1","plugin_version":VERSION,"created":int(time.time()),"sources":get_sources(),"files":files}

def _restore_backup(data):
    if not isinstance(data, dict) or data.get("format") != "TiviMateE2-backup-v1": raise ValueError("Invalid TiviMateE2 backup file")
    sources = data.get("sources")
    if not isinstance(sources, list): raise ValueError("Backup does not contain a valid server list")
    with _LOCK:
        set_sources(sources); write_playlists(sources)
        for path, value in (data.get("files") or {}).items():
            if path in BACKUP_FILES or path.startswith(get_data_root().rstrip("/") + "/"): _write_json_file(path, value)
    return True

def _human_bytes(value):
    try: value=float(value)
    except Exception: return "0 B"
    units=["B","KB","MB","GB","TB"]; i=0
    while value>=1024.0 and i<len(units)-1: value/=1024.0; i+=1
    return ("%.1f %s"%(value,units[i])) if i else ("%d %s"%(int(value),units[i]))

def _disk_free(path):
    try:
        st=os.statvfs(path); return st.f_bavail*st.f_frsize
    except Exception: return 0

def _find_logs():
    out=[]
    for pattern in ("/home/root/logs/enigma2_crash_*.log","/home/root/logs/enigma2-debug*.log","/tmp/enigma2_crash_*.log","/tmp/enigma2-debug*.log","/tmp/tivimatee2/*.log"):
        try: out.extend(glob.glob(pattern))
        except Exception: pass
    out=[p for p in set(out) if os.path.isfile(p)]
    try: out.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    except Exception: pass
    return out[:8]

def _tail(path, limit=24000):
    try:
        fh=open(path,"rb"); fh.seek(0,2); size=fh.tell(); fh.seek(max(0,size-limit),0); raw=fh.read(); fh.close()
        if isinstance(raw, bytes):
            try: raw=raw.decode("utf-8","replace")
            except Exception: pass
        return raw
    except Exception: return ""

def _image_name():
    for path in ("/etc/image-version","/etc/issue"):
        try:
            raw=open(path,"rb").read()
            if isinstance(raw,bytes): raw=raw.decode("utf-8","replace")
            raw=raw.strip().replace("\n"," ")
            if raw: return raw[:120]
        except Exception: pass
    return "Enigma2"

XTREAM_SVG = u'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="48" fill="#0877d1"/><circle cx="50" cy="50" r="38" fill="#061526" stroke="#62c8ff" stroke-width="3"/><path d="M28 35h44L58 50l14 15H28l14-15z" fill="#27b7ff"/><text x="50" y="83" text-anchor="middle" fill="white" font-family="Arial" font-size="11" font-weight="bold">XTREAM</text></svg>'''
STALKER_SVG = u'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="48" fill="#15191f" stroke="#e5e7eb" stroke-width="3"/><circle cx="50" cy="43" r="23" fill="#f2f2f2"/><circle cx="42" cy="40" r="4"/><circle cx="58" cy="40" r="4"/><path d="M38 52q12 9 24 0" fill="none" stroke="#111" stroke-width="4"/><text x="50" y="83" text-anchor="middle" fill="white" font-family="Arial" font-size="10" font-weight="bold">STALKER</text></svg>'''


def _text(value):
    if value is None:
        return ""
    try:
        return value if isinstance(value, str) else str(value)
    except Exception:
        return ""


def _h(value):
    try:
        return html_escape(_text(value), quote=True)
    except TypeError:
        return html_escape(_text(value))


def _private_client(ip):
    """Restrict configuration UI to loopback/private LAN clients."""
    ip = _text(ip).split("%", 1)[0]
    if ip in ("127.0.0.1", "::1"):
        return True
    if ip.startswith("10.") or ip.startswith("192.168."):
        return True
    if ip.startswith("172."):
        try:
            second = int(ip.split(".")[1])
            return 16 <= second <= 31
        except Exception:
            return False
    if ip.lower().startswith(("fc", "fd", "fe80:")):
        return True
    return False


def _local_ip():
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"
    finally:
        try:
            if sock:
                sock.close()
        except Exception:
            pass


def _normalise_url(value):
    value = _text(value).strip().rstrip("/")
    if value and not value.lower().startswith(("http://", "https://")):
        value = "http://" + value
    return value


def _short_server_name(url, fallback="Server"):
    """Compact provider label: hostname/IP plus non-default port."""
    value = _normalise_url(url)
    try:
        parsed = urlparse(value)
        host = parsed.hostname or ""
        port = parsed.port
        if host:
            if port and not ((parsed.scheme == "http" and port == 80) or (parsed.scheme == "https" and port == 443)):
                return "%s:%d" % (host, port)
            return host
    except Exception:
        pass
    return _text(fallback or "Server").strip() or "Server"


def _normalise_mac(value):
    raw = "".join([c for c in _text(value).upper() if c in "0123456789ABCDEF"])
    if len(raw) != 12:
        return ""
    return ":".join([raw[i:i + 2] for i in range(0, 12, 2)])


def _stream_type(value):
    try:
        parsed = int(value)
    except Exception:
        parsed = 4097
    return parsed if parsed in (1, 4097, 5001, 5002) else 4097


XTREAM_SERVICE_TYPES_FILE = data_path("xtream_service_types.json")
STALKER_SERVICE_TYPES_FILE = data_path("stalker_service_types.json")


def _source_identity(source):
    source = source or {}
    return "%s|%s|%s|%s" % (
        source.get("type", ""),
        (source.get("url") or source.get("host") or source.get("server") or source.get("portal") or "").rstrip("/"),
        source.get("username", ""),
        source.get("mac", ""),
    )


def _save_service_types(source, value):
    path = XTREAM_SERVICE_TYPES_FILE if source.get("type") == "xtream" else STALKER_SERVICE_TYPES_FILE
    data = load_json(path, {}) or {}
    if not isinstance(data, dict):
        data = {}
    value = _stream_type(value)
    data[_source_identity(source)] = {"live": value, "vod": value, "series": value}
    save_json(path, data)


def _source_status(source):
    try:
        if source.get("type") == "xtream":
            reply = XtreamClient(source).test()
        elif source.get("type") == "stalker":
            reply = StalkerClient(source).test()
        else:
            return "offline", "Unsupported source type"
        report = evaluate_reply(source.get("type"), reply)
        return report.get("state", "offline"), ""
    except Exception as exc:
        return "offline", _text(exc)



DISCOVERY_SOURCES = [
    {"id": "iptvlinks", "name": "IPTV Links", "feed": "https://iptvlinkseuro.blogspot.com/feeds/posts/default?alt=json&max-results=10"},
    {"id": "stbstalker", "name": "STB Stalker", "feed": "https://stbstalker.alaaeldinee.com/feeds/posts/default?alt=json&max-results=10"},
]


def _urlopen_text(url, timeout=8):
    try:
        try:
            from urllib.request import Request, urlopen
        except ImportError:
            from urllib.request import Request, urlopen
        req = Request(url, headers={"User-Agent": "Mozilla/5.0 TiviMateE2/%s" % VERSION})
        res = urlopen(req, timeout=timeout)
        raw = res.read(524288)
        final = getattr(res, "geturl", lambda: url)()
        code = getattr(res, "getcode", lambda: 200)()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "replace")
        return int(code or 200), _text(final), raw
    except Exception as exc:
        return 0, url, _text(exc)


def _strip_html(value):
    value = re.sub(r"(?is)<script.*?</script>|<style.*?</style>", " ", _text(value))
    value = re.sub(r"(?s)<[^>]+>", " ", value)
    value = value.replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
    return re.sub(r"\\s+", " ", value).strip()


def _extract_all_http_urls(text):
    """Return de-duplicated HTTP(S) URLs from the post body."""
    found = []
    raw = _text(text).replace('&amp;', '&')
    for url in re.findall(r"https?://[^\s<>\"']+", raw, flags=re.I):
        url = url.rstrip(".,);]}")
        if url not in found:
            found.append(url)
    return found


def _looks_like_stalker_endpoint(url):
    """Strict Stalker endpoint detection.

    Do not classify arbitrary /iptv/C... paths as Stalker. The old '/c'
    substring test did exactly that and mis-labelled M3U8 stream URLs.
    """
    try:
        parsed = urlparse(_text(url).strip())
        path = (parsed.path or '/').lower()
    except Exception:
        path = _text(url).lower()
    if path in ('/c', '/c/'):
        return True
    markers = ('/stalker_portal/', '/portal.php', '/server/load.php', '/stalker_portal/server/load.php')
    return any(marker in path for marker in markers)


def _extract_public_portals(text, title=''):
    """Collect Stalker portal URLs without confusing IPTV/M3U paths."""
    found = []
    title_low = _text(title).lower()
    stalker_post = any(x in title_low for x in ('stalker', 'stbemu', 'stb emu', 'portal mac', 'mag portal'))
    for url in _extract_all_http_urls(text):
        low = url.lower()
        # Never classify playlist/stream URLs as Stalker.
        if any(x in low for x in ('.m3u', '.m3u8', 'get.php?', 'username=', 'password=')):
            continue
        if _looks_like_stalker_endpoint(url):
            if url not in found:
                found.append(url)
            continue
        # On a clearly-labelled Stalker/STBEmu post, a bare server root is
        # also a portal candidate. Avoid Blogger/assets/obvious web links.
        if stalker_post:
            try:
                parsed = urlparse(url)
                path = parsed.path or '/'
                host = (parsed.netloc or '').lower()
            except Exception:
                path, host = '/', ''
            if host and 'blogspot.' not in host and 'blogger.' not in host and path in ('', '/'):
                if url not in found:
                    found.append(url)
    return found[:20]


def _extract_public_macs(text):
    """Parse MAC-looking values already present in a discovery post."""
    found = []
    raw = _strip_html(_text(text))
    patterns = [
        r"(?i)(?<![0-9a-f])(?:[0-9a-f]{2}\s*[:\-\.]\s*){5}[0-9a-f]{2}(?![0-9a-f])",
        r"(?i)(?<![0-9a-f])(?:[0-9a-f]{2}\s+){5}[0-9a-f]{2}(?![0-9a-f])",
        r"(?i)(?<![0-9a-f])[0-9a-f]{12}(?![0-9a-f])",
    ]
    for pattern in patterns:
        for value in re.findall(pattern, raw):
            hexv = re.sub(r"[^0-9A-Fa-f]", "", value).upper()
            if len(hexv) != 12:
                continue
            mac = ":".join(hexv[i:i+2] for i in range(0, 12, 2))
            if mac not in found:
                found.append(mac)
    return found[:100]


def _post_lines(text):
    """Convert Blogger HTML into useful logical lines for credential parsing."""
    raw = _text(text).replace('&amp;', '&').replace('&quot;', '"').replace('&#39;', "'")
    raw = re.sub(r'(?is)<\s*br\s*/?\s*>|</\s*(?:p|div|li|tr|h[1-6])\s*>', '\n', raw)
    raw = re.sub(r'(?s)<[^>]+>', ' ', raw)
    lines = []
    for line in raw.splitlines():
        line = re.sub(r'\s+', ' ', line).strip()
        if line:
            lines.append(line)
    return lines


def _make_xtream_url(base, username, password, output='ts'):
    base = _text(base).strip().rstrip('/')
    username = _text(username).strip().strip('"\'')
    password = _text(password).strip().strip('"\'')
    if not base or not username or not password:
        return ''
    output = 'm3u8' if _text(output).lower() == 'm3u8' else 'ts'
    return '%s/get.php?username=%s&password=%s&type=m3u_plus&output=%s' % (
        base, quote_plus(username), quote_plus(password), output)


def _extract_public_xtream(text):
    """Extract Xtream credentials in both common publishing styles.

    Supported examples:
      http://host:port/get.php?username=u&password=p&type=m3u_plus
      http://host:port
      username=u
      password=p
    Blogger often splits the get.php query across BR/newline tags, so the
    parser intentionally rebuilds the block before parsing it.
    """
    found = []
    lines = _post_lines(text)

    def add(url):
        if url and url not in found:
            found.append(url)

    # Fully-published get.php links from raw HTML.
    for url in _extract_all_http_urls(text):
        if 'get.php?' in url.lower():
            xt = _xtream_from_m3u_url(url)
            if xt:
                add(_make_xtream_url(xt['url'], xt['username'], xt['password'], xt.get('output') or 'ts'))

    # Rebuild split lines and base + username + password blocks.
    i = 0
    while i < len(lines):
        line = lines[i]
        m = re.search(r'(https?://[^\s<>\"\']+)', line, re.I)
        if not m:
            i += 1
            continue
        first_url = m.group(1).rstrip('.,);]}')
        low = first_url.lower()
        # Do not borrow credentials across another URL; inspect only the
        # short text block immediately following this URL.
        block = [line]
        j = i + 1
        while j < len(lines) and j <= i + 4:
            if re.search(r'https?://', lines[j], re.I):
                break
            block.append(lines[j])
            j += 1
        joined = ' '.join(block).replace('&amp;', '&')
        um = re.search(r'(?i)\b(?:username|user)\s*[=:]\s*([^\s&<>]+)', joined)
        pm = re.search(r'(?i)\b(?:password|pass)\s*[=:]\s*([^\s&<>]+)', joined)
        if um and pm:
            try:
                parsed = urlparse(first_url)
                base = '%s://%s' % (parsed.scheme, parsed.netloc)
            except Exception:
                base = first_url
            output_m = re.search(r'(?i)\boutput\s*=\s*(ts|m3u8)', joined)
            output = output_m.group(1).lower() if output_m else 'ts'
            add(_make_xtream_url(base, um.group(1), pm.group(1), output))
        i += 1
    return found[:100]


def _extract_public_m3u(text):
    """Collect direct M3U/M3U8 playlist/stream URLs only.

    Xtream get.php credentials are handled separately so the same account is
    never shown twice as both M3U and Xtream.
    """
    found = []
    for url in _extract_all_http_urls(text):
        low = url.lower()
        if 'get.php?' in low:
            continue
        if ('.m3u' in low or '.m3u8' in low) and url not in found:
            found.append(url)
    return found[:100]


def _xtream_from_m3u_url(url):
    """Return Xtream source fields from a get.php playlist URL, or None."""
    raw = _text(url).strip()
    try:
        parsed = urlparse(raw)
        q = parse_qs(parsed.query or "")
        username = _text((q.get("username") or [""])[0]).strip()
        password = _text((q.get("password") or [""])[0]).strip()
        if not parsed.scheme or not parsed.netloc or not username or not password:
            return None
        base = "%s://%s" % (parsed.scheme, parsed.netloc)
        output = _text((q.get("output") or ["ts"])[0]).strip().lower()
        if output not in ("ts", "m3u8"):
            output = "ts"
        return {"url": base.rstrip("/"), "username": username, "password": password, "output": output}
    except Exception:
        return None


def _relative_date_label(value):
    try:
        d = datetime.strptime(_text(value)[:10], "%Y-%m-%d").date()
        delta = (date.today() - d).days
        if delta <= 0:
            return "اليوم"
        if delta == 1:
            return "قبل يوم"
        if delta == 2:
            return "قبل يومين"
        if delta == 3:
            return "قبل 3 أيام"
        if delta <= 7:
            return "قبل %d أيام" % delta
        return _text(value)[:10]
    except Exception:
        return _text(value)[:10]


def _fetch_discovery(source_id="iptvlinks", limit=10, days=3):
    src = next((x for x in DISCOVERY_SOURCES if x.get("id") == source_id), DISCOVERY_SOURCES[0])
    code, final, raw = _urlopen_text(src["feed"], timeout=10)
    if not code or code >= 400:
        return src, [], "Source fetch failed: %s" % _text(raw)[:180]
    try:
        data = json.loads(raw)
    except Exception as exc:
        return src, [], "Feed parse failed: %s" % exc
    entries = (((data or {}).get("feed") or {}).get("entry") or [])[:max(1, min(int(limit or 10), 10))]
    out = []
    for item in entries:
        title = _text(((item.get("title") or {}).get("$t")))
        published = _text(((item.get("published") or {}).get("$t")))[:10]
        try:
            pub_date = datetime.strptime(published, "%Y-%m-%d").date()
            if int(days or 0) > 0 and (date.today() - pub_date).days > int(days):
                continue
        except Exception:
            pass
        body = _text(((item.get("content") or item.get("summary") or {}).get("$t")))
        urls = _extract_public_portals(body, title)
        macs = _extract_public_macs(body)
        xtreams = _extract_public_xtream(body)
        m3us = _extract_public_m3u(body)
        if urls or xtreams or m3us:
            out.append({"title": title, "date": published, "urls": urls, "macs": macs, "xtreams": xtreams, "m3us": m3us})
    return src, out, ""


def _discovery_candidates(posts, max_candidates=20):
    """Flatten discovery posts into unique portal candidates without testing them."""
    candidates = []
    seen = set()
    for post in posts or []:
        for url in post.get("urls") or []:
            clean = _normalise_url(url)
            if not clean or clean in seen:
                continue
            seen.add(clean)
            candidates.append((post, clean))
            if len(candidates) >= max(1, int(max_candidates or 20)):
                return candidates
    return candidates


def _discovery_items(posts, mode="all", max_candidates=40):
    """Flatten posts into unique Stalker, Xtream and direct-M3U results."""
    mode = _text(mode or 'all').lower()
    if mode not in ('all', 'stalker', 'm3u'):
        mode = 'all'
    items, seen = [], set()
    for post in posts or []:
        if mode in ('all', 'stalker'):
            for url in post.get('urls') or []:
                clean = _normalise_url(url)
                key = ('stalker', clean)
                if clean and key not in seen:
                    seen.add(key)
                    items.append({'kind':'stalker','post':post,'url':clean})
                    if len(items) >= max(1, int(max_candidates or 40)):
                        return items
        if mode in ('all', 'm3u'):
            # Xtream first. These are addable to Server Manager.
            for url in post.get('xtreams') or []:
                clean = _text(url).strip()
                key = ('xtream', clean)
                if clean and key not in seen:
                    seen.add(key)
                    items.append({'kind':'xtream','post':post,'url':clean})
                    if len(items) >= max(1, int(max_candidates or 40)):
                        return items
            # Direct M3U/M3U8 is shown once as a playlist, never duplicated as Xtream.
            for url in post.get('m3us') or []:
                clean = _text(url).strip()
                key = ('m3u', clean)
                if clean and key not in seen:
                    seen.add(key)
                    items.append({'kind':'m3u','post':post,'url':clean})
                    if len(items) >= max(1, int(max_candidates or 40)):
                        return items
    return items


def _public_reachability(url):
    # Safe preview: checks only the public portal URL, with no MAC/token/login attempt.
    start = time.time()
    code, final, raw = _urlopen_text(_normalise_url(url), timeout=5)
    ms = int((time.time() - start) * 1000)
    # A normal page or redirect is considered reachable. 4xx/5xx are not shown
    # as working results because they are not useful for the Finder shortlist.
    if 200 <= code < 400:
        return "reachable", code, ms, final
    return "offline", code, ms, final


def _filter_reachable_discovery(posts, max_candidates=10):
    """Return only public portal URLs that answer successfully.

    Discovery remains credential-free: this performs no MAG/Stalker handshake and
    never tests MAC addresses. It merely reduces the page to reachable portal URLs.
    """
    candidates = []
    seen = set()
    for post in posts or []:
        for url in post.get("urls") or []:
            clean = _normalise_url(url)
            if not clean or clean in seen:
                continue
            seen.add(clean)
            candidates.append((post, clean))
            if len(candidates) >= max(1, int(max_candidates or 10)):
                break
        if len(candidates) >= max(1, int(max_candidates or 10)):
            break
    if not candidates:
        return []

    def _one(item):
        post, url = item
        state, code, ms, final = _public_reachability(url)
        return post, url, state, code, ms, final

    try:
        from multiprocessing.dummy import Pool as ThreadPool
        pool = ThreadPool(min(4, len(candidates)))
        try:
            checked = pool.map(_one, candidates)
        finally:
            pool.close(); pool.join()
    except Exception:
        checked = [_one(x) for x in candidates]

    return [x for x in checked if x[2] == "reachable"]

STYLE = r"""
:root{--bg:#07111c;--panel:#0e1b29;--panel2:#142437;--line:#283a4d;--blue:#168cff;--gold:#f6b717;--green:#23cf6d;--red:#f04444;--text:#f5f8fc;--muted:#9fb2c6}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 75% 0,#12304e 0,#07111c 38%,#050b12 100%);color:var(--text);font-family:Arial,Helvetica,sans-serif}.wrap{max-width:1280px;margin:auto;min-height:100vh}.top{display:flex;align-items:center;justify-content:space-between;padding:25px 30px;border-bottom:1px solid var(--line);background:rgba(5,12,20,.92)}.brand b{font-size:38px;letter-spacing:.5px}.brand small{display:block;letter-spacing:4px;color:#dbe6f1}.version{border:1px solid #205786;padding:8px 13px;border-radius:8px;color:#59adff}.grid{display:grid;grid-template-columns:220px 1fr;min-height:calc(100vh - 100px)}nav{padding:24px 14px;border-right:1px solid var(--line);background:rgba(7,17,28,.82)}nav a{display:block;padding:15px 17px;margin-bottom:8px;border-radius:8px;color:#e9f1fa;text-decoration:none}nav a.active{background:linear-gradient(90deg,#1457a5,#1d6ac8);border-left:4px solid #48a8ff}.dev{position:sticky;top:80vh;margin:30px 12px;color:var(--muted);font-size:13px}.dev b{color:#4ca7ff}main{padding:26px}.toolbar{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:18px}.btn{border:0;border-radius:8px;padding:11px 17px;color:white;text-decoration:none;cursor:pointer;font-weight:bold;background:#263748}.btn.blue{background:#1479df}.btn.green{background:#15964c}.btn.red{background:#bb3030}.btn.gold{background:#b97f00}.card{background:linear-gradient(145deg,var(--panel2),var(--panel));border:1px solid var(--line);border-radius:13px;padding:18px;margin-bottom:13px;box-shadow:0 12px 26px rgba(0,0,0,.2)}.server{display:grid;grid-template-columns:1fr auto;gap:18px;align-items:center}.server h3{margin:0 0 8px;font-size:21px}.meta{color:var(--muted);font-size:14px;line-height:1.7}.pill{display:inline-block;padding:5px 9px;border-radius:7px;font-size:12px;background:#163b62;color:#62b6ff}.status{display:inline-block;padding:6px 10px;border-radius:7px;font-weight:bold}.online,.busy{background:#123f27;color:#42e184}.offline{background:#47191d;color:#ff6565}.actions{display:flex;gap:8px;flex-wrap:wrap}.form{display:grid;grid-template-columns:1fr 1fr;gap:14px}.form .full{grid-column:1/-1}label{display:block;color:#cad6e2;font-size:13px;margin-bottom:6px}input,select,textarea{width:100%;padding:11px 12px;border:1px solid #41566c;border-radius:7px;background:#0b1622;color:white;outline:none}textarea{resize:vertical;min-height:92px;font-family:Arial,Helvetica,sans-serif}.macauthbox{display:flex;flex-direction:column;gap:10px;margin-top:8px;padding:14px;border:1px solid #2b4158;border-radius:10px;background:#0a1521}.macauthbox .actions{display:flex;flex-direction:column;align-items:stretch;gap:8px}.macauthbox .actions .btn,.macauthbox .actions select{width:100%}.macauthbox select{min-height:132px;padding:6px}.macauthbox select option{padding:10px 12px;border-bottom:1px solid #26394c;background:#0b1622;color:#fff}.macauthbox .note{margin:0}.findercheckform{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:center;margin-top:10px}.note{color:#9fb2c6;font-size:13px}.flash{padding:12px 15px;border-radius:9px;margin-bottom:16px;background:#113e28;color:#55e391;border:1px solid #1a6a3d}.flash.err{background:#42191c;color:#ff7171;border-color:#713036}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:17px}.stat{background:#0c1824;border:1px solid var(--line);border-radius:10px;padding:14px}.stat b{font-size:24px;display:block;margin-top:6px}.finderrow{display:grid;grid-template-columns:1fr auto;gap:14px;align-items:center}.sourcechip{display:inline-block;padding:7px 11px;border-radius:20px;background:#25214a;color:#cdbdff}.finderurl{font-family:monospace;word-break:break-all}.check{font-size:18px}.mutedbox{background:#0a1521;border:1px dashed #334b63;border-radius:10px;padding:14px;color:var(--muted)}@media(max-width:760px){.grid{grid-template-columns:1fr}nav{display:flex;overflow:auto;border-right:0;border-bottom:1px solid var(--line);padding:9px}nav a{white-space:nowrap;margin:0 5px}.dev{display:none}.top{padding:16px}.brand b{font-size:27px}main{padding:14px}.server{grid-template-columns:1fr}.form{grid-template-columns:1fr}.form .full{grid-column:1}.stats{grid-template-columns:1fr}}

.findercheckform{display:grid;grid-template-columns:1fr auto;gap:10px;margin-top:14px;align-items:center}.findercheckform input{min-width:0}.findercheckform .btn{min-width:110px}.findercheck{margin-top:12px;padding:12px 14px;border-radius:10px;display:flex;gap:14px;align-items:center;flex-wrap:wrap}.findercheck.ok{background:rgba(37,180,92,.14);border:1px solid rgba(37,180,92,.45);color:#8ff0ae}.findercheck.bad{background:rgba(230,68,68,.12);border:1px solid rgba(230,68,68,.4);color:#ffaaaa}.finderadd{margin-top:10px}.findercheck span{font-size:13px}
"""


class _ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class TiviMateWebHandler(BaseHTTPRequestHandler):
    server_version = "TiviMateE2Web/%s" % VERSION

    def log_message(self, fmt, *args):
        try:
            with open(get_log_path("tivimatee2_web.log"), "a") as handle:
                handle.write("[%s] %s - %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), self.client_address[0], fmt % args))
        except Exception:
            pass

    def _allowed(self):
        return _private_client(self.client_address[0])

    def _send(self, body, code=200, content_type="text/html; charset=utf-8"):
        if not isinstance(body, bytes):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.end_headers()
        self.wfile.write(body)

    def _redirect(self, location="/"):
        self.send_response(303)
        self.send_header("Location", location)
        self.end_headers()

    def _forbidden(self):
        self._send("Forbidden: local network access only.", 403, "text/plain; charset=utf-8")

    def _params(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except Exception:
            length = 0
        raw = self.rfile.read(length)
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "replace")
        parsed = parse_qs(raw, keep_blank_values=True)
        return dict([(key, values[-1] if values else "") for key, values in parsed.items()])

    def do_GET(self):
        if not self._allowed():
            self._forbidden(); return
        parsed = urlparse(self.path)
        if parsed.path == '/health':
            self._send(json.dumps({'ok': True, 'version': VERSION}), content_type='application/json; charset=utf-8'); return
        if parsed.path == '/assets/xtream.svg':
            self._send(XTREAM_SVG, content_type='image/svg+xml'); return
        if parsed.path == '/assets/stalker.svg':
            self._send(STALKER_SVG, content_type='image/svg+xml'); return
        if parsed.path == '/status':
            self._send(self._status_page()); return
        if parsed.path == '/m3u-upload':
            q = parse_qs(parsed.query)
            self._send(self._m3u_upload_page((q.get('msg') or [''])[0], (q.get('err') or [''])[0])); return
        if parsed.path == '/stalker-finder':
            q=parse_qs(parsed.query)
            check = {
                'url': (q.get('checked_url') or [''])[0],
                'mac': (q.get('checked_mac') or [''])[0],
                'name': (q.get('checked_name') or [''])[0],
                'ok': (q.get('checked_ok') or [''])[0],
                'handshake': (q.get('handshake') or [''])[0],
                'profile': (q.get('profile') or [''])[0],
                'categories': (q.get('categories') or [''])[0],
                'channels': (q.get('channels') or [''])[0],
                'live_link': (q.get('live_link') or [''])[0],
                'stage': (q.get('stage') or [''])[0],
                'check_error': (q.get('check_error') or [''])[0],
            }
            try:
                page = max(1, int((q.get('page') or ['1'])[0] or 1))
            except Exception:
                page = 1
            days=int((q.get('days') or ['3'])[0] or 3); mode=(q.get('mode') or ['all'])[0] or 'all'; self._send(self._stalker_finder_page((q.get('source') or ['iptvlinks'])[0], (q.get('msg') or [''])[0], (q.get('err') or [''])[0], check, page, days, mode)); return
        if parsed.path == '/finder-add':
            q=parse_qs(parsed.query); self._send(self._finder_add_page((q.get('url') or [''])[0], (q.get('msg') or [''])[0], (q.get('err') or [''])[0])); return
        if parsed.path == '/backup':
            payload=_json_text(_build_backup())
            self.send_response(200); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Disposition','attachment; filename=TiViMateE2-backup-1.0.06.json'); self.end_headers()
            if not isinstance(payload, bytes): payload=payload.encode('utf-8')
            self.wfile.write(payload); return
        if parsed.path == '/maintenance':
            q=parse_qs(parsed.query); self._send(self._maintenance_page((q.get('msg') or [''])[0],(q.get('err') or [''])[0])); return
        if parsed.path == '/diagnostics':
            self._send(self._diagnostics_page()); return
        if parsed.path == '/diagnostics.txt':
            self._send(self._diagnostics_text(), content_type='text/plain; charset=utf-8'); return
        query = parse_qs(parsed.query)
        edit = None
        if parsed.path == "/edit":
            try: edit = int((query.get("id") or [""])[0])
            except Exception: edit = None
        self._send(self._page(edit_index=edit, message=(query.get("msg") or [""])[0], error=(query.get("err") or [""])[0], prefill_type=(query.get("prefill_type") or [""])[0], prefill_url=(query.get("prefill_url") or [""])[0]))

    def do_POST(self):
        if not self._allowed():
            self._forbidden(); return
        parsed = urlparse(self.path)
        params = self._params()
        try:
            if parsed.path == "/save":
                self._save_source(params); return
            if parsed.path == "/delete":
                self._delete_source(params); return
            if parsed.path == '/test':
                self._test_source(params); return
            if parsed.path == '/check-all':
                self._check_all(); return
            if parsed.path == '/restore':
                self._restore_settings(params); return
            if parsed.path == '/clear-cache':
                self._clear_cache(); return
            if parsed.path == '/cleanup-cache':
                self._cleanup_cache(); return
            if parsed.path == '/finder-check':
                self._finder_check(params); return
            if parsed.path == '/finder-use':
                self._finder_use(params); return
            if parsed.path == '/finder-save':
                self._finder_save(params); return
            if parsed.path == '/finder-save-m3u':
                self._finder_save_m3u(params); return
            if parsed.path == '/finder-save-direct-m3u':
                self._finder_save_direct_m3u(params); return
            if parsed.path == '/m3u-upload':
                self._m3u_upload(params); return
        except Exception as exc:
            self._redirect("/?err=" + self._quote("Operation failed: %s" % exc)); return
        self._redirect("/")

    @staticmethod
    def _quote(value):
        try:
            from urllib import quote
        except ImportError:
            from urllib.parse import quote
        return quote(_text(value))

    def _m3u_upload_page(self, message="", error=""):
        flash = ""
        if message:
            flash += '<div class="flash ok">%s</div>' % _h(message)
        if error:
            flash += '<div class="flash err">%s</div>' % _h(error)
        body = flash + r'''
<section class="card">
  <h2>Import M3U from Phone</h2>
  <p class="note">Choose <b>m3u.txt</b>, <b>.m3u</b> or <b>.m3u8</b>. The playlist is copied into TiviMateE2 and added as an M3U server.</p>
  <form id="m3uForm" method="post" action="/m3u-upload">
    <label>Playlist Name</label>
    <input name="name" id="playlistName" value="M3U Playlist" maxlength="80">
    <label style="margin-top:16px">Playlist File</label>
    <input type="file" id="m3uFile" accept=".txt,.m3u,.m3u8,text/plain,audio/x-mpegurl,application/vnd.apple.mpegurl" required>
    <input type="hidden" name="filename" id="m3uFilename">
    <textarea name="m3u_text" id="m3uText" style="display:none"></textarea>
    <p class="note" id="m3uState">No file selected.</p>
    <button class="btn green" type="submit">Import to Receiver</button>
  </form>
</section>
<script>
(function(){
  var f=document.getElementById('m3uFile'), t=document.getElementById('m3uText'), n=document.getElementById('m3uFilename'), st=document.getElementById('m3uState'), form=document.getElementById('m3uForm');
  f.addEventListener('change', function(){
    var file=f.files && f.files[0];
    if(!file){ t.value=''; n.value=''; st.textContent='No file selected.'; return; }
    n.value=file.name || 'm3u.txt';
    st.textContent='Reading ' + n.value + ' ...';
    var reader=new FileReader();
    reader.onload=function(){ t.value=reader.result || ''; st.textContent=n.value + ' ready • ' + Math.round(file.size/1024) + ' KB'; };
    reader.onerror=function(){ t.value=''; st.textContent='Could not read file.'; };
    reader.readAsText(file);
  });
  form.addEventListener('submit', function(e){
    if(!t.value){ e.preventDefault(); st.textContent='Choose a valid M3U/TXT file first.'; }
  });
})();
</script>'''
        return self._layout(body, active="servers")

    def _m3u_upload(self, params):
        name = _text(params.get("name") or "M3U Playlist").strip()[:80] or "M3U Playlist"
        filename = os.path.basename(_text(params.get("filename") or "m3u.txt").strip())
        text = _text(params.get("m3u_text") or "")
        if not text.strip():
            self._redirect("/m3u-upload?err=" + self._quote("Choose an M3U/TXT file first.")); return
        raw = text.encode("utf-8", "replace")
        if len(raw) > 12 * 1024 * 1024:
            self._redirect("/m3u-upload?err=" + self._quote("Playlist is too large (maximum 12 MB).")); return
        stripped = raw.lstrip()
        if b"#EXTM3U" not in stripped[:4096]:
            if stripped.startswith(b"#EXTINF"):
                raw = b"#EXTM3U\n" + stripped
            else:
                self._redirect("/m3u-upload?err=" + self._quote("This TXT file does not look like an M3U playlist.")); return
        import_dir = data_path("imported_m3u")
        try:
            os.makedirs(import_dir, exist_ok=True)
        except TypeError:
            if not os.path.isdir(import_dir):
                os.makedirs(import_dir)
        digest = hashlib.sha1(raw).hexdigest()[:12]
        low = filename.lower()
        ext = ".m3u8" if low.endswith(".m3u8") else (".txt" if low.endswith(".txt") else ".m3u")
        target = os.path.join(import_dir, "playlist_%s%s" % (digest, ext))
        tmp = target + ".tmp"
        with open(tmp, "wb") as fh:
            fh.write(raw)
        os.replace(tmp, target)
        source = {
            "type": "m3u",
            "name": name,
            "m3u_mode": "file",
            "path": target,
            "url": "",
            "imported": True,
            "service_type": 4097,
        }
        with _LOCK:
            sources = get_sources()
            replaced = False
            for idx, existing in enumerate(sources):
                if existing.get("type") == "m3u" and _text(existing.get("path")) == target:
                    sources[idx] = source
                    replaced = True
                    break
            if not replaced:
                sources.append(source)
            set_sources(sources)
            write_playlists(sources)
        self._redirect("/m3u-upload?msg=" + self._quote("M3U imported successfully. Return to the receiver and refresh the server list."))

    def _save_source(self, params):
        stype = _text(params.get("type")).strip().lower()
        url = _normalise_url(params.get("url"))
        name = _text(params.get("name")).strip() or _short_server_name(
            url, "Stalker Portal" if stype == "stalker" else "IPTV"
        )
        if stype not in ("xtream", "stalker") or not url:
            self._redirect("/?err=" + self._quote("Server type and URL are required.")); return
        source = {"type": stype, "name": name, "url": url, "service_type": _stream_type(params.get("service_type"))}
        if stype == "xtream":
            username = _text(params.get("username")).strip()
            password = _text(params.get("password"))
            if not username:
                self._redirect("/?err=" + self._quote("Xtream username is required.")); return
            source.update({"username": username, "password": password, "output": _text(params.get("output") or "ts")})
        else:
            mac = _normalise_mac(params.get("mac"))
            if not mac:
                self._redirect("/?err=" + self._quote("A valid Stalker MAC address is required.")); return
            source["mac"] = mac

        try: index = int(params.get("index", "-1"))
        except Exception: index = -1
        with _LOCK:
            sources = get_sources()
            if 0 <= index < len(sources):
                old = sources[index]
                if stype == "xtream" and not source.get("password"):
                    source["password"] = old.get("password", "")
                sources[index] = source
            else:
                if stype == "xtream" and not source.get("password"):
                    self._redirect("/?err=" + self._quote("Xtream password is required for a new server.")); return
                sources.append(source)
            set_sources(sources)
            write_playlists(sources)
            _save_service_types(source, source.get("service_type", 4097))
        self._redirect("/?msg=" + self._quote("Server saved successfully."))

    def _delete_source(self, params):
        try: index = int(params.get("index", "-1"))
        except Exception: index = -1
        with _LOCK:
            sources = get_sources()
            if 0 <= index < len(sources):
                del sources[index]
                set_sources(sources)
                write_playlists(sources)
                self._redirect("/?msg=" + self._quote("Server deleted.")); return
        self._redirect("/?err=" + self._quote("Server was not found."))

    def _test_source(self, params):
        try: index = int(params.get("index", "-1"))
        except Exception: index = -1
        sources = get_sources()
        if 0 <= index < len(sources):
            state, error = _source_status(sources[index])
            try:
                sources[index]["_last_status"] = state if state in ("online", "busy") else "offline"
                sources[index]["_last_status_detail"] = _text(error or "")[:160]
                sources[index]["_last_status_at"] = int(time.time())
                set_sources(sources)
            except Exception:
                pass
            if state in ("online", "busy"):
                self._redirect("/?msg=" + self._quote("Connection successful: %s" % state.upper())); return
            self._redirect("/?err=" + self._quote("Connection failed%s" % ((": " + error) if error else "."))); return
        self._redirect("/?err=" + self._quote("Server was not found."))

    def _layout(self, content, active="servers"):
        nav = "".join([
            '<a class="%s" href="/">Servers</a>' % ("active" if active == "servers" else ""),
            '<a href="/#add">Add Server</a>',
            '<a class="%s" href="/status">Status</a>' % ('active' if active == 'status' else ''),
            '<a class="%s" href="/stalker-finder">IPTV Finder</a>' % ('active' if active == 'finder' else ''),
            '<a class="%s" href="/maintenance">Maintenance</a>' % ('active' if active == 'maintenance' else ''),
            '<a class="%s" href="/diagnostics">Diagnostics</a>' % ('active' if active == 'diagnostics' else ''),
        ])
        return u"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TiviMate IPTV Experience</title><style>%s</style></head><body><div class="wrap"><header class="top"><div class="brand"><b>TiviMate</b><small>IPTV EXPERIENCE</small></div><span class="version">v%s</span></header><div class="grid"><nav>%s<div class="dev">Developed by <b>opesboy</b><br><br>Web Server: ON<br>Port: %d</div></nav><main>%s</main></div></div></body></html>""" % (STYLE, VERSION, nav, WEB_PORT, content)

    def _page(self, edit_index=None, message="", error="", prefill_type="", prefill_url=""):
        sources = get_sources()
        flash = ""
        if message: flash = '<div class="flash">%s</div>' % _h(message)
        if error: flash = '<div class="flash err">%s</div>' % _h(error)
        cards = []
        xtream_count = 0; stalker_count = 0
        for index, source in enumerate(sources):
            stype = source.get("type", "")
            if stype == "xtream": xtream_count += 1
            if stype == "stalker": stalker_count += 1
            endpoint = source.get("url", "")
            if stype == "xtream":
                icon, type_label, ident_label, identity = "xtream", "Xtream Codes", "User", _h(source.get("username", ""))
                edit_action = '<a class="btn blue" href="/edit?id=%d#add">Edit</a>' % index
            elif stype == "m3u":
                icon, type_label, ident_label, identity = "xtream", "M3U Playlist", "Playlist", "Direct URL"
                edit_action = ''
            else:
                icon, type_label, ident_label, identity = "stalker", "Stalker Portal", "MAC", _h(source.get("mac", ""))
                edit_action = '<a class="btn blue" href="/edit?id=%d#add">Edit</a>' % index
            cards.append(u'''<section class="card server"><div style="display:flex;gap:16px;align-items:center"><img src="/assets/%s.svg" style="width:72px;height:72px;flex:none"><div><h3>%s <span class="pill">%s</span></h3><div class="meta">Stream Type: %s</div></div></div><div class="actions">%s<form method="post" action="/test"><input type="hidden" name="index" value="%d"><button class="btn green">Test</button></form><form method="post" action="/delete" onsubmit="return confirm('Delete this server?')"><input type="hidden" name="index" value="%d"><button class="btn red">Delete</button></form></div></section>''' % (_h(icon), _h(source.get("name") or "Server"), _h(type_label), _h(source.get("service_type", 4097)), edit_action, index, index))

        edit_source = {}
        if edit_index is not None and 0 <= edit_index < len(sources):
            edit_source = sources[edit_index]
        else:
            edit_index = -1
        if edit_index < 0:
            if prefill_type in ("xtream", "stalker"):
                edit_source["type"] = prefill_type
            if prefill_url:
                edit_source["url"] = _normalise_url(prefill_url)
        etype = edit_source.get("type", "xtream")
        form = u'''<section class="card" id="add"><h2>%s</h2><form method="post" action="/save" class="form"><input type="hidden" name="index" value="%d"><div><label>Server Type</label><select name="type" id="stype" onchange="toggleType()"><option value="xtream" %s>Xtream Codes</option><option value="stalker" %s>Stalker Portal</option></select></div><div><label>Server Name</label><input name="name" value="%s" placeholder="Server 1"></div><div class="full"><label>Server URL / Portal URL</label><input name="url" value="%s" placeholder="http://server:port"></div><div id="xtuser"><label>Username</label><input name="username" value="%s"></div><div id="xtpass"><label>Password</label><input name="password" type="password" placeholder="%s"></div><div id="stmac" style="display:none"><label>MAC Address</label><input name="mac" value="%s" placeholder="00:1A:79:XX:XX:XX"></div><div><label>Stream Type</label><select name="service_type">%s</select></div><div id="xtoutput"><label>Stream Format</label><select name="output"><option value="ts" %s>TS</option><option value="m3u8" %s>M3U8</option></select></div><div class="full actions"><button class="btn blue">Save Server</button><a class="btn" href="/">Cancel</a></div><div class="full note">For security, saved Xtream passwords are never displayed. Leave password blank while editing to keep the current password.</div></form></section><script>function toggleType(){var s=document.getElementById('stype').value;document.getElementById('xtuser').style.display=s==='xtream'?'block':'none';document.getElementById('xtpass').style.display=s==='xtream'?'block':'none';document.getElementById('xtoutput').style.display=s==='xtream'?'block':'none';document.getElementById('stmac').style.display=s==='stalker'?'block':'none'}toggleType();</script>''' % (
            "Edit Server" if edit_index >= 0 else "Add Server", edit_index,
            "selected" if etype == "xtream" else "", "selected" if etype == "stalker" else "",
            _h(edit_source.get("name", "")), _h(edit_source.get("url", "")), _h(edit_source.get("username", "")),
            "Leave blank to keep current" if edit_index >= 0 else "Required", _h(edit_source.get("mac", "")),
            "".join(['<option value="%d" %s>%d</option>' % (x, "selected" if _stream_type(edit_source.get("service_type", 4097)) == x else "", x) for x in (1,4097,5001,5002)]),
            "selected" if edit_source.get("output", "ts") == "ts" else "", "selected" if edit_source.get("output", "ts") == "m3u8" else "")
        stats = u'''<div class="stats"><div class="stat">Total Servers<b>%d</b></div><div class="stat">Xtream<b>%d</b></div><div class="stat">Stalker<b>%d</b></div></div><p class="note">Receiver IP: %s &nbsp; • &nbsp; Open from your phone: http://%s:%d</p>''' % (len(sources), xtream_count, stalker_count, _h(_local_ip()), _h(_local_ip()), WEB_PORT)
        content = flash + '<div class="toolbar"><a class="btn blue" href="#add">+ Add Server</a><a class="btn" href="/">Refresh</a></div>' + ("".join(cards) if cards else '<section class="card">No servers configured yet.</section>') + stats + form
        return self._layout(content)

    def _restore_settings(self, params):
        raw=_text(params.get('backup_json')).strip()
        if not raw: self._redirect('/maintenance?err='+self._quote('Choose a backup JSON file first.')); return
        try: _restore_backup(json.loads(raw))
        except Exception as exc: self._redirect('/maintenance?err='+self._quote('Restore failed: %s'%exc)); return
        self._redirect('/maintenance?msg='+self._quote('Backup restored. Restart Enigma2 before using restored settings.'))

    def _clear_cache(self):
        if clear_cache(): self._redirect('/maintenance?msg='+self._quote('Artwork cache cleared successfully.')); return
        self._redirect('/maintenance?err='+self._quote('Cache could not be cleared.'))

    def _cleanup_cache(self):
        try: cleanup_cache(); self._redirect('/maintenance?msg='+self._quote('Cache age policy applied successfully.')); return
        except Exception as exc: self._redirect('/maintenance?err='+self._quote('Cache cleanup failed: %s'%exc))

    def _maintenance_page(self, message='', error=''):
        flash = ('<div class="flash">%s</div>'%_h(message)) if message else ''
        if error: flash += '<div class="flash err">%s</div>'%_h(error)
        try:
            root,size,count=cache_status(); cfg=get_cache_settings() or {}; free=_disk_free(root if os.path.exists(root) else '/')
        except Exception: root,size,count,cfg,free='N/A',0,0,{},0
        days=int(cfg.get('retention_days',0) or 0); policy='Unlimited' if days<=0 else '%d days'%days
        body=flash+'<section class="card"><h2>Backup & Restore</h2><p class="note">Backup includes servers and TiViMateE2 settings. Keep it private because credentials are included.</p><a class="btn blue" href="/backup">Download Backup</a><br><br><form method="post" action="/restore"><div class="uploadbox"><label>Select backup JSON</label><input type="file" id="backupFile" accept=".json,application/json"><input type="hidden" name="backup_json" id="backupJson"><p class="note" id="backupState">No file selected.</p><button class="btn gold" onclick="return confirm(\'Restore this backup?\')">Restore Backup</button></div></form></section>'
        body+='<section class="card"><h2>Cache Manager</h2><div class="stats"><div class="stat">Cache Size<b>%s</b></div><div class="stat">Files<b>%d</b></div><div class="stat">Free Space<b>%s</b></div></div><div class="meta">Location: %s<br>Retention: %s</div><br><div class="actions"><form method="post" action="/cleanup-cache"><button class="btn green">Apply Age Policy</button></form><form method="post" action="/clear-cache" onsubmit="return confirm(\'Clear artwork cache?\')"><button class="btn red">Clear Artwork Cache</button></form></div></section>'%(_h(_human_bytes(size)),count,_h(_human_bytes(free)),_h(root),_h(policy))
        body+="<script>(function(){var f=document.getElementById('backupFile'),o=document.getElementById('backupJson'),s=document.getElementById('backupState');if(!f)return;f.addEventListener('change',function(){if(!f.files||!f.files[0]){o.value='';return;}var r=new FileReader();r.onload=function(){o.value=r.result||'';s.textContent='Backup ready to restore.';};r.readAsText(f.files[0]);});})();</script>"
        return self._layout(body,active='maintenance')

    def _stalker_finder_page(self, source_id="iptvlinks", message="", error="", check=None, page=1, days=3, mode="all"):
        days = days if days in (1,3,7) else 3
        mode = _text(mode or 'all').lower()
        if mode not in ('all','stalker','m3u'):
            mode = 'all'
        src, posts, fetch_error = _fetch_discovery(source_id, 10, days)
        if fetch_error and not error:
            error = fetch_error
        check = check or {}
        flash = ('<div class="flash">%s</div>' % _h(message)) if message else ''
        if error:
            flash += '<div class="flash err">%s</div>' % _h(error)
        options = ''.join(['<option value="%s" %s>%s</option>' % (_h(x['id']), 'selected' if x['id']==source_id else '', _h(x['name'])) for x in DISCOVERY_SOURCES])
        body = flash + ('<section class="card"><h2>IPTV Finder — Stalker & M3U/Xtream</h2>'
            '<p class="note">Searches the selected public source. Newest posts first.</p>'
            '<form method="get" action="/stalker-finder"><div class="finderrow">'
            '<div><label>Source</label><select name="source">%s</select></div>'
            '<div><label>Type</label><select name="mode"><option value="all" %s>All</option><option value="stalker" %s>Stalker</option><option value="m3u" %s>M3U / Xtream</option></select></div>'
            '<div><label>Period</label><select name="days"><option value="1" %s>Today</option><option value="3" %s>Last 3 days</option><option value="7" %s>Last 7 days</option></select></div>'
            '<button class="btn blue">Fetch Latest</button></div></form></section>') % (
                options,
                'selected' if mode=='all' else '', 'selected' if mode=='stalker' else '', 'selected' if mode=='m3u' else '',
                'selected' if days==1 else '', 'selected' if days==3 else '', 'selected' if days==7 else '')

        items = _discovery_items(posts, mode, 40)
        if not items:
            body += '<div class="mutedbox">No matching Stalker or M3U/Xtream results were found in the selected period.</div>'
            return self._layout(body, active='finder')

        total = len(items)
        page = max(1, min(int(page or 1), total))
        item = items[page-1]
        post, url, kind = item['post'], item['url'], item['kind']

        if kind in ('m3u', 'xtream'):
            low = url.lower()
            label = 'Xtream' if kind == 'xtream' else ('M3U8' if '.m3u8' in low else 'M3U')
            default_name = _text(post.get('title') or label).strip() or label
            if kind == 'xtream':
                add_html = (
                    '<form method="post" action="/finder-save-m3u" class="finderadd" style="margin-top:14px">'
                    '<input type="hidden" name="url" value="%s"><input type="hidden" name="source" value="%s">'
                    '<input type="hidden" name="page" value="%d"><input type="hidden" name="days" value="%d"><input type="hidden" name="mode" value="%s">'
                    '<label>Server Name</label><input name="name" value="%s" placeholder="Xtream Server">'
                    '<div class="actions" style="margin-top:10px"><button class="btn green">Add Server</button></div></form>'
                ) % (_h(url), _h(source_id), page, days, _h(mode), _h(default_name))
            else:
                add_html = (
                    '<form method="post" action="/finder-save-direct-m3u" class="finderadd" style="margin-top:14px">'
                    '<input type="hidden" name="url" value="%s"><input type="hidden" name="source" value="%s">'
                    '<input type="hidden" name="page" value="%d"><input type="hidden" name="days" value="%d"><input type="hidden" name="mode" value="%s">'
                    '<label>Server Name</label><input name="name" value="%s" placeholder="M3U Server">'
                    '<div class="actions" style="margin-top:10px"><button class="btn green">Add Server</button></div></form>'
                ) % (_h(url), _h(source_id), page, days, _h(mode), _h(default_name))
            body += (
                '<section class="card"><div style="width:100%%">'
                '<span class="sourcechip">%s</span><span class="status online">%s</span>'
                '<h3>%s</h3><div class="meta">Date: %s</div>'
                '<div class="finderurl">%s</div>'
                '<div class="actions" style="margin-top:14px"><a class="btn blue" href="%s" target="_blank" rel="noopener">Open / Download</a></div>%s'
                '</div></section>'
            ) % (_h(src['name']), _h(label), _h(post.get('title') or 'Recent post'), _h(_relative_date_label(post.get('date')) + ' (' + _text(post.get('date')) + ')'), _h(url), _h(url), add_html)
        else:
            state, code, ms, final = _public_reachability(url)
            mac_value = _normalise_mac(check.get('mac')) if _normalise_url(check.get('url')) == url else ''
            result_html = ''
            if _normalise_url(check.get('url')) == url and check.get('ok'):
                if check.get('ok') == '1':
                    result_html = (
                        '<div class="findercheck ok"><b>✓ CHECK OK</b><span>Handshake: %s</span><span>Profile: %s</span><span>Categories: %s</span><span>Channels: %s</span><span>Live: %s</span></div>'
                        '<form method="post" action="/finder-save" class="finderadd">'
                        '<input type="hidden" name="url" value="%s"><input type="hidden" name="mac" value="%s">'
                        '<input type="hidden" name="service_type" value="4097"><input type="hidden" name="last_status" value="online"><input type="hidden" name="return_to" value="finder"><input type="hidden" name="source" value="%s">'
                        '<label>Server Name</label><input name="name" value="%s" placeholder="Stalker Portal">'
                        '<button class="btn green" style="margin-top:10px">Add Server</button></form>'
                    ) % (_h(check.get('handshake') or 'OK'), _h(check.get('profile') or 'OK'), _h(check.get('categories') or '0'), _h(check.get('channels') or '0'), _h(check.get('live_link') or 'OK'), _h(url), _h(mac_value), _h(source_id), _h(check.get('name') or _short_server_name(url, 'Stalker Portal')))
                else:
                    result_html = '<div class="findercheck bad"><b>✕ CHECK FAILED</b><span>Stage: %s</span><span>%s</span></div>' % (_h(check.get('stage') or 'unknown'), _h(check.get('check_error') or 'Stalker login failed.'))

            status_cls = 'online' if state == 'reachable' else 'offline'
            status_text = 'Portal Reachable' if state == 'reachable' else 'Portal Offline'
            public_macs = post.get('macs') or []
            if public_macs:
                rows = []
                for i, m in enumerate(public_macs):
                    checked_attr = ' checked' if (m == mac_value or (not mac_value and i == 0)) else ''
                    rows.append('<label class="macrow" style="display:flex;align-items:center;gap:12px;padding:11px 13px;border:1px solid #2b4158;border-radius:8px;background:#0a1521;cursor:pointer"><input type="radio" name="mac" value="%s"%s style="width:auto"><code>%s</code></label>' % (_h(m), checked_attr, _h(m)))
                default_name = _short_server_name(url, 'Stalker Portal')
                macs_html = '<form method="post" action="/finder-check"><input type="hidden" name="url" value="%s"><input type="hidden" name="source" value="%s"><input type="hidden" name="page" value="%d"><input type="hidden" name="days" value="%d"><input type="hidden" name="mode" value="%s"><input type="hidden" name="service_type" value="4097"><input type="hidden" name="return_to" value="finder"><label style="margin-top:10px">Server Name</label><input name="name" value="%s" placeholder="Stalker Portal"><div class="maclist" style="display:flex;flex-direction:column;gap:8px;margin-top:10px">%s</div><div class="actions" style="margin-top:12px"><button class="btn blue" type="submit">Check selected MAC</button><button class="btn green" type="submit" formaction="/finder-save">Add Server</button></div></form>' % (_h(url), _h(source_id), page, days, _h(mode), _h(default_name), ''.join(rows))
            else:
                macs_html = '<div class="mutedbox">No MAC values found in this post.</div>'

            body += (
                '<section class="card"><div style="width:100%%">'
                '<span class="sourcechip">%s</span><span class="status %s">%s</span>'
                '<h3>%s</h3><div class="meta">Date: %s &nbsp; | &nbsp; HTTP %s &nbsp; | &nbsp; %d ms</div>'
                '<div class="finderurl">%s</div>'
                '<div class="meta" style="margin-top:12px"><b>MACs</b></div>%s%s'
                '</div></section>'
            ) % (_h(src['name']), status_cls, status_text, _h(post.get('title') or 'Recent post'), _h(_relative_date_label(post.get('date')) + ' (' + _text(post.get('date')) + ')'), _h(code), int(ms), _h(url), macs_html, result_html)

        nums=[]
        for n in range(1,total+1):
            cls='btn blue' if n==page else 'btn'
            nums.append('<a class="%s" href="/stalker-finder?source=%s&mode=%s&days=%d&page=%d">%d</a>' % (cls, _h(source_id), _h(mode), days, n, n))
        prev = '<a class="btn" href="/stalker-finder?source=%s&mode=%s&days=%d&page=%d">‹ Previous</a>' % (_h(source_id), _h(mode), days, page-1) if page>1 else ''
        nxt = '<a class="btn" href="/stalker-finder?source=%s&mode=%s&days=%d&page=%d">Next ›</a>' % (_h(source_id), _h(mode), days, page+1) if page<total else ''
        body += '<div class="card"><div class="meta" style="margin-bottom:10px">Result %d of %d</div><div class="actions">%s%s%s</div></div>' % (page,total,prev,''.join(nums),nxt)
        return self._layout(body, active='finder')

    def _finder_check(self, params):
        url = _normalise_url(params.get('url'))
        mac = _normalise_mac(params.get('mac'))
        source_id = _text(params.get('source') or 'iptvlinks').strip() or 'iptvlinks'
        try:
            days = int(params.get('days') or 3)
        except Exception:
            days = 3
        try:
            page = max(1, int(params.get('page') or 1))
        except Exception:
            page = 1
        if not url:
            self._redirect('/stalker-finder?err='+self._quote('No portal URL selected.')); return
        if not mac:
            self._redirect('/stalker-finder?source='+self._quote(source_id)+'&err='+self._quote('A valid Stalker MAC address is required.')); return
        result = StalkerClient({'type':'stalker','url':url,'mac':mac,'service_type':4097}).test() or {}
        mode = _text(params.get('mode') or 'all').lower()
        if mode not in ('all','stalker','m3u'):
            mode = 'all'
        query = [
            'source='+self._quote(source_id),
            'mode='+self._quote(mode),
            'days='+self._quote(str(days)),
            'page='+self._quote(str(page)),
            'checked_url='+self._quote(url),
            'checked_mac='+self._quote(mac),
            'checked_name='+self._quote(_text(params.get('name') or 'Stalker Portal').strip() or 'Stalker Portal'),
            'checked_ok='+('1' if result.get('ok') else '0'),
            'handshake='+self._quote('OK' if result.get('handshake') else 'FAIL'),
            'profile='+self._quote('OK' if result.get('profile') else 'FAIL'),
            'categories='+self._quote(str(result.get('categories') or 0)),
            'channels='+self._quote(str(result.get('channels') or 0)),
            'live_link='+self._quote('OK' if result.get('live_link') else 'NO'),
            'stage='+self._quote(result.get('stage') or ''),
            'check_error='+self._quote(result.get('error') or ''),
        ]
        self._redirect('/stalker-finder?'+'&'.join(query))

    def _finder_use(self, params):
        url = _normalise_url(params.get('url'))
        if not url:
            self._redirect('/stalker-finder?err='+self._quote('No portal URL selected.')); return
        self._redirect('/finder-add?url='+self._quote(url))

    def _finder_add_page(self, url, message='', error=''):
        url = _normalise_url(url)
        if not url:
            return self._layout('<div class="flash err">No portal URL selected.</div>', active='finder')
        flash = ('<div class="flash">%s</div>' % _h(message)) if message else ''
        if error:
            flash += '<div class="flash err">%s</div>' % _h(error)
        body = flash + (
            '<section class="card"><h2>Add verified Stalker Portal</h2>'
            '<p class="note">تم اختيار Portal مستجيب. أدخل MAC المصرح لك باستخدامه، ثم احفظه مباشرة في TiviMateE2.</p>'
            '<form method="post" action="/finder-save">'
            '<label>Portal URL</label><input name="url" value="%s" readonly>'
            '<label>Server Name</label><input name="name" value="%s">'
            '<label>MAC Address</label><input name="mac" placeholder="00:1A:79:XX:XX:XX" required>'
            '<label>Live Stream Type</label><select name="service_type">'
            '<option value="1">DVB (1)</option><option value="4097" selected>GStreamer (4097)</option>'
            '<option value="5001">GstPlayer (5001)</option><option value="5002">ExtePlayer3 (5002)</option>'
            '</select>'
            '<div class="actions" style="margin-top:18px">'
            '<a class="btn" href="/stalker-finder">Cancel</a>'
            '<button class="btn green">Save to TiviMateE2</button>'
            '</div></form></section>'
        ) % (_h(url), _h(_short_server_name(url, 'Stalker Portal')))
        return self._layout(body, active='finder')

    def _finder_save(self, params):
        url = _normalise_url(params.get('url'))
        mac = _normalise_mac(params.get('mac'))
        name = _text(params.get('name')).strip() or _short_server_name(url, 'Stalker Portal')
        if not url:
            self._redirect('/stalker-finder?err='+self._quote('No portal URL selected.')); return
        if not mac:
            self._redirect('/finder-add?url='+self._quote(url)+'&err='+self._quote('A valid Stalker MAC address is required.')); return
        source = {"type": "stalker", "name": name, "url": url, "mac": mac, "service_type": _stream_type(params.get('service_type'))}
        initial_status = _text(params.get('last_status')).strip().lower()
        if initial_status in ("online", "busy", "offline"):
            source["_last_status"] = initial_status
            source["_last_status_at"] = int(time.time())
        with _LOCK:
            sources = get_sources()
            duplicate = False
            for item in sources:
                if item.get('type') == 'stalker' and _normalise_url(item.get('url')) == url and _normalise_mac(item.get('mac')) == mac:
                    duplicate = True
                    break
            if not duplicate:
                sources.append(source)
                set_sources(sources)
                write_playlists(sources)
                _save_service_types(source, source.get('service_type', 4097))
        return_to = _text(params.get('return_to')).strip().lower()
        source_id = _text(params.get('source') or 'iptvlinks').strip() or 'iptvlinks'
        if duplicate:
            target = '/stalker-finder?source='+self._quote(source_id)+'&msg='+self._quote('Stalker portal already exists.') if return_to == 'finder' else '/?msg='+self._quote('Stalker portal already exists.')
            self._redirect(target); return
        if return_to == 'finder':
            page = _text(params.get('page') or '1').strip() or '1'
            days = _text(params.get('days') or '3').strip() or '3'
            mode = _text(params.get('mode') or 'all').strip() or 'all'
            target = '/stalker-finder?source='+self._quote(source_id)+'&mode='+self._quote(mode)+'&days='+self._quote(days)+'&page='+self._quote(page)+'&msg='+self._quote('Stalker portal added successfully to TiviMateE2.')
        else:
            target = '/?msg='+self._quote('Stalker portal added successfully from Finder.')
        self._redirect(target)

    def _finder_save_m3u(self, params):
        url = _text(params.get('url')).strip()
        name = _text(params.get('name')).strip() or 'Xtream Server'
        source_id = _text(params.get('source') or 'iptvlinks').strip() or 'iptvlinks'
        xt = _xtream_from_m3u_url(url)
        if not xt:
            self._redirect('/stalker-finder?source='+self._quote(source_id)+'&err='+self._quote('Xtream credentials were not found in this playlist URL.')); return
        source = {
            'type':'xtream', 'name':name, 'url':xt['url'],
            'username':xt['username'], 'password':xt['password'],
            'output':xt['output'], 'service_type':4097
        }
        with _LOCK:
            sources = get_sources()
            duplicate = any(
                x.get('type') == 'xtream' and
                _normalise_url(x.get('url')) == _normalise_url(source.get('url')) and
                _text(x.get('username')).strip() == source.get('username')
                for x in sources
            )
            if not duplicate:
                sources.append(source)
                set_sources(sources)
                write_playlists(sources)
                _save_service_types(source, 4097)
        msg = 'Xtream server already exists.' if duplicate else 'Xtream server added successfully to TiviMateE2.'
        page = _text(params.get('page') or '1').strip() or '1'
        days = _text(params.get('days') or '3').strip() or '3'
        mode = _text(params.get('mode') or 'all').strip() or 'all'
        self._redirect('/stalker-finder?source='+self._quote(source_id)+'&mode='+self._quote(mode)+'&days='+self._quote(days)+'&page='+self._quote(page)+'&msg='+self._quote(msg))

    def _finder_save_direct_m3u(self, params):
        url = _text(params.get('url')).strip()
        name = _text(params.get('name')).strip() or 'M3U Server'
        source_id = _text(params.get('source') or 'iptvlinks').strip() or 'iptvlinks'
        if not url:
            self._redirect('/stalker-finder?source='+self._quote(source_id)+'&err='+self._quote('No M3U URL selected.')); return
        source = {'type':'m3u', 'name':name, 'url':url, 'service_type':4097}
        with _LOCK:
            sources = get_sources()
            duplicate = any(x.get('type') == 'm3u' and _text(x.get('url')).strip() == url for x in sources)
            if not duplicate:
                sources.append(source)
                set_sources(sources)
                write_playlists(sources)
                _save_service_types(source, 4097)
        msg = 'M3U server already exists.' if duplicate else 'M3U server added successfully to TiviMateE2.'
        page = _text(params.get('page') or '1').strip() or '1'
        days = _text(params.get('days') or '3').strip() or '3'
        mode = _text(params.get('mode') or 'all').strip() or 'all'
        self._redirect('/stalker-finder?source='+self._quote(source_id)+'&mode='+self._quote(mode)+'&days='+self._quote(days)+'&page='+self._quote(page)+'&msg='+self._quote(msg))

    def _diagnostics_text(self):
        lines=['TiViMateE2 Diagnostics','Plugin Version: %s'%VERSION,'Receiver IP: %s'%_local_ip(),'Image: %s'%_image_name(),'Python: %s'%sys.version.replace('\n',' '),'Servers: %d'%len(get_sources())]
        try:
            root,size,count=cache_status(); lines.append('Cache: %s | %s | %d files'%(root,_human_bytes(size),count))
        except Exception as exc: lines.append('Cache: error %s'%exc)
        for i,src in enumerate(get_sources()): lines.append('  %d. %s | %s | %s'%(i+1,src.get('name','Server'),src.get('type',''),src.get('url','')))
        logs=_find_logs(); lines.append('Logs found: %d'%len(logs)); lines.extend(['  '+p for p in logs])
        return '\n'.join(lines)+'\n'

    def _diagnostics_page(self):
        logs=_find_logs(); rows=[]
        for path in logs:
            try: size=os.path.getsize(path); stamp=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(os.path.getmtime(path)))
            except Exception: size,stamp=0,'N/A'
            rows.append('<tr><td>%s</td><td>%s</td><td>%s</td></tr>'%(_h(path),_h(_human_bytes(size)),_h(stamp)))
        latest=logs[0] if logs else ''; tail=_tail(latest) if latest else 'No Enigma2/TiViMateE2 log found.'
        body='<div class="toolbar"><a class="btn blue" href="/diagnostics.txt">Download Diagnostics</a><a class="btn" href="/diagnostics">Refresh</a></div>'
        body+='<section class="card"><h2>Diagnostics</h2><div class="code">%s</div></section>'%_h(self._diagnostics_text())
        body+='<section class="card"><h3>Recent Logs</h3><table class="diag"><tr><th>Path</th><th>Size</th><th>Modified</th></tr>%s</table></section>'%(''.join(rows) if rows else '<tr><td colspan="3">No logs found.</td></tr>')
        body+='<section class="card"><h3>Latest Log Tail%s</h3><div class="code">%s</div></section>'%(((': '+_h(latest)) if latest else ''),_h(tail))
        body+='<p class="note">Passwords and MAC credentials are not included in the diagnostics report.</p>'
        return self._layout(body,active='diagnostics')

    def _check_all(self):
        sources = get_sources()
        results = []
        for i, source in enumerate(sources):
            try:
                state, error = _source_status(source)
            except Exception as exc:
                state, error = 'offline', _text(exc)
            results.append({'index': i, 'state': state, 'error': error or ''})
        self._redirect('/status?checked=1')

    def _status_page(self):
        sources = get_sources()
        rows=[]; online=0; offline=0; xt=0; st=0
        for i, source in enumerate(sources):
            typ=source.get('type','')
            if typ=='xtream': xt += 1
            elif typ=='stalker': st += 1
            try:
                state, error = _source_status(source)
            except Exception as exc:
                state, error = 'offline', _text(exc)
            if state in ('online','busy'): online += 1
            else: offline += 1
            rows.append('<section class="card server"><div style="display:flex;gap:16px;align-items:center"><img src="/assets/%s.svg" style="width:64px;height:64px"><div><h3>%s <span class="pill">%s</span></h3><div class="meta">%s</div></div></div><span class="status %s">%s</span></section>' % ('xtream' if typ=='xtream' else 'stalker', _h(source.get('name') or 'Server'), _h('Xtream Codes' if typ=='xtream' else 'Stalker Portal'), _h(error or 'Connection checked'), 'online' if state in ('online','busy') else 'offline', _h(state.upper())))
        try:
            up=int(float(open('/proc/uptime').read().split()[0])); uptime='%dd %02dh %02dm' % (up//86400,(up%86400)//3600,(up%3600)//60)
        except Exception: uptime='N/A'
        try:
            du=shutil.disk_usage('/'); free='%.1f GB' % (du.free/1073741824.0)
        except Exception: free='N/A'
        image='Enigma2'
        for f in ('/etc/image-version','/etc/issue'):
            try:
                txt=open(f).read().strip().replace('\n',' '); image=txt[:80] or image; break
            except Exception: pass
        body='<div class="toolbar"><form method="post" action="/check-all"><button class="btn green">Check All Servers</button></form><a class="btn" href="/status">Refresh</a></div>'
        body += '<div class="stats"><div class="stat">Web Server<b>RUNNING</b></div><div class="stat">Plugin Version<b>v%s</b></div><div class="stat">Receiver IP<b>%s</b></div><div class="stat">Python<b>%s</b></div><div class="stat">Uptime<b>%s</b></div><div class="stat">Free Disk<b>%s</b></div></div>' % (VERSION,_h(_local_ip()),_h(sys.version.split()[0]),_h(uptime),_h(free))
        body += '<section class="card"><h3>System</h3><div class="meta">Image: %s<br>Total Servers: %d &nbsp; • &nbsp; Xtream: %d &nbsp; • &nbsp; Stalker: %d &nbsp; • &nbsp; Online: %d &nbsp; • &nbsp; Offline: %d</div></section>' % (_h(image),len(sources),xt,st,online,offline)
        body += ''.join(rows) if rows else '<section class="card">No servers configured.</section>'
        return self._layout(body, active='status')


def start_web_manager():
    global _SERVER, _THREAD
    if _SERVER is not None:
        return True
    try:
        server = _ThreadingHTTPServer((WEB_HOST, WEB_PORT), TiviMateWebHandler)
    except Exception:
        return False
    _SERVER = server
    thread = threading.Thread(target=server.serve_forever, name="TiviMateWebManager")
    thread.daemon = True
    thread.start()
    _THREAD = thread
    return True


def stop_web_manager():
    global _SERVER, _THREAD
    server = _SERVER
    _SERVER = None
    _THREAD = None
    if server is None:
        return
    try:
        server.shutdown()
    except Exception:
        pass
    try:
        server.server_close()
    except Exception:
        pass


def web_manager_status():
    return {"running": _SERVER is not None, "port": WEB_PORT, "ip": _local_ip(), "version": VERSION}
