# -*- coding: utf-8 -*-
"""Small recovery helpers used by UI/network code.

Recovery is deliberately conservative: it never retries blindly on the GUI
thread. It records failures, invalidates stale generations and allows callers to
return to a known state instead of leaving a permanent Loading state.
"""
import threading
import time
from .diagnostics import event

_LOCK = threading.RLock()
_STATE = {}


def mark(area, state, **fields):
    try:
        with _LOCK:
            _STATE[str(area)] = {"state": str(state), "at": time.time()}
        event("recovery", state, area=area, **fields)
    except Exception:
        pass


def state(area):
    try:
        with _LOCK:
            return dict(_STATE.get(str(area)) or {})
    except Exception:
        return {}


def guarded(area, fallback=None):
    def deco(fn):
        def wrapped(*args, **kwargs):
            try:
                mark(area, "begin")
                value = fn(*args, **kwargs)
                mark(area, "ready")
                return value
            except Exception as exc:
                mark(area, "failed", error=exc.__class__.__name__)
                if callable(fallback):
                    try:
                        return fallback(*args, **kwargs)
                    except Exception:
                        pass
                return fallback
        wrapped.__name__ = getattr(fn, "__name__", "guarded")
        return wrapped
    return deco
