# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, threading, time

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.ServiceEventTracker import InfoBarBase, ServiceEventTracker
from Components.Sources.StaticText import StaticText
from enigma import eTimer, ePicLoad, iPlayableService
from .live_service import live_reference
from .epg_local import lookup_channel_epg
from .artwork_queue import request_artwork
from .display_scale import scale_skin, scale_size
from .i18n import tr
from Screens.ChoiceBox import ChoiceBox
from Screens.InfoBarGenerics import InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarSummarySupport
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen

try:
    from .core import XtreamClient, M3UClient, StalkerClient, get_source_client, cached_image
except Exception:
    XtreamClient = M3UClient = StalkerClient = get_source_client = None
    cached_image = None


PLAYER_CONFIG = "/etc/enigma2/tivimatee2_player.json"
# Kept only as a read fallback for installations that used the earlier live-only setting.
LIVE_SETTINGS_FILE = "/etc/enigma2/tivimatee2_channel_settings.json"

def _available_service_types():
    values = [(4097, "GStreamer 4097 (default)")]
    serviceapp = any(os.path.isdir(path) for path in (
        "/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp",
        "/usr/lib/enigma2/python/Plugins/Extensions/ServiceApp",
    ))
    if serviceapp or os.path.exists("/usr/bin/gstplayer"):
        values.append((5001, "GstPlayer 5001"))
    if serviceapp or os.path.exists("/usr/bin/exteplayer3"):
        values.append((5002, "ExtePlayer3 5002"))
    if serviceapp or os.path.exists("/usr/bin/ffmpeg"):
        values.append((8193, "ServiceApp/FFmpeg 8193"))
    return values

def _load_service_type():
    available = [value for value, _label in _available_service_types()]
    for path in (PLAYER_CONFIG, LIVE_SETTINGS_FILE):
        try:
            import json
            with open(path, "r") as handle:
                value = int((json.load(handle) or {}).get("service_type", 4097))
            if value in available:
                return value
        except Exception:
            pass
    return available[0] if available else 4097

def _save_service_type(value):
    try:
        import json
        folder = os.path.dirname(PLAYER_CONFIG)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = PLAYER_CONFIG + ".tmp"
        with open(tmp, "w") as handle:
            json.dump({"service_type": int(value)}, handle)
        os.rename(tmp, PLAYER_CONFIG)
    except Exception:
        pass

class LiveInfoBarShowHide(object):
    STATE_HIDDEN = 0
    STATE_SHOWN = 1

    def __init__(self):
        self._ib_state = self.STATE_SHOWN
        self._ib_timer = eTimer()
        try:
            self._ib_timer.timeout.connect(self._hideInfobar)
        except Exception:
            self._ib_timer.callback.append(self._hideInfobar)
        self.onShow.append(self._onShown)
        self.onHide.append(self._onHidden)

    def _onShown(self):
        self._ib_state = self.STATE_SHOWN
        self._startHideTimer()

    def _onHidden(self):
        self._ib_state = self.STATE_HIDDEN

    def _startHideTimer(self):
        try:
            self._ib_timer.stop()
            self._ib_timer.start(5000, True)
        except Exception:
            pass

    def _hideInfobar(self):
        try:
            self.hide()
        except Exception:
            pass

    def toggleInfobar(self):
        if self._ib_state == self.STATE_HIDDEN:
            self.show()
            self._startHideTimer()
        else:
            self.hide()

    def showInfobar(self):
        try:
            self.show()
            self._startHideTimer()
        except Exception:
            pass


class TiviMateLivePlayer(InfoBarBase, LiveInfoBarShowHide, InfoBarAudioSelection,
                         InfoBarSubtitleSupport, InfoBarSummarySupport, Screen):
    """Dedicated Live player. It intentionally does not inherit or modify the VOD player."""

    skin = '''<screen name="TiviMateLivePlayer" position="0,0" size="1920,1080" backgroundColor="#ff000000" flags="wfNoBorder">
        <eLabel position="0,790" size="1920,290" backgroundColor="#d012151b" zPosition="1"/>
        <eLabel position="0,790" size="1920,3" backgroundColor="#e03b6ea8" zPosition="2"/>
        <widget name="picon" position="45,812" size="280,168" alphatest="blend" zPosition="4"/>
        <widget source="channel" render="Label" position="350,820" size="960,54" font="Regular;40" foregroundColor="#ffffff" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget source="session.CurrentService" render="Label" position="1325,820" size="250,54" font="Regular;30" foregroundColor="#79dfff" backgroundColor="#00000000" transparent="1" noWrap="1" halign="right" zPosition="4"><convert type="TiviMateTestServiceInfo">VideoResolution</convert></widget>
        <widget name="nowTag" position="350,882" size="105,40" font="Regular;29" foregroundColor="#18d8e8" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="epgNow" position="458,882" size="967,40" font="Regular;29" foregroundColor="#ffffff" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="nextTag" position="350,928" size="105,34" font="Regular;24" foregroundColor="#ffd34d" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="epgNext" position="458,928" size="967,34" font="Regular;24" foregroundColor="#e6edf5" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <eLabel position="45,988" size="280,8" backgroundColor="#304050" zPosition="3"/>
        <widget name="epgProgress" position="45,988" size="280,8" borderWidth="0" backgroundColor="#304050" foregroundColor="#18b9c7" zPosition="4"/>
        <widget name="epgProgressText" position="45,1001" size="280,30" font="Regular;21" foregroundColor="#9fdde4" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4"/>
        <widget source="counter" render="Label" position="1590,825" size="275,48" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4"/>
        <widget source="clock" render="Label" position="1590,885" size="275,48" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4"/>
        <widget source="hint" render="Label" position="1435,982" size="430,54" font="Regular;22" foregroundColor="#8fc8ff" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4"/>
    </screen>'''

    def __init__(self, session, source, channels, index=0):
        Screen.__init__(self, session)
        self.session = session
        self.source = source or {}
        self.channels = list(channels or [])
        self.index = max(0, min(int(index or 0), max(0, len(self.channels) - 1)))
        self.service_type = _load_service_type()
        self.current_url = ""
        self._picon_token = 0
        self._picon_path = None
        self._subssupport = None
        self._original_service = None
        try:
            self._original_service = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            pass

        InfoBarBase.__init__(self)
        LiveInfoBarShowHide.__init__(self)
        InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        InfoBarSummarySupport.__init__(self)

        self["channel"] = StaticText("")
        self["counter"] = StaticText("")
        self["clock"] = StaticText("")
        self["hint"] = StaticText(tr("↑↓ Change   MENU Player Engine   BLUE SubsSupport   RED Edit Subtitles"))
        self["picon"] = Pixmap()
        self["nowTag"] = Label(tr("NOW"))
        self["epgNow"] = Label("")
        self["nextTag"] = Label(tr("NEXT"))
        self["epgNext"] = Label("")
        self["epgProgress"] = ProgressBar()
        self["epgProgressText"] = Label("")

        self._pic = ePicLoad()
        try:
            self._pic.PictureData.get().append(self._piconDecoded)
        except Exception:
            self._pic_conn = self._pic.PictureData.connect(self._piconDecoded)

        self._clock_timer = eTimer()
        try:
            self._clock_timer.timeout.connect(self._updateClock)
        except Exception:
            self._clock_timer.callback.append(self._updateClock)

        # Playback must start before any EPG JSON work.  The one-shot timer
        # lets the decoder settle, then reads the already-built in-memory/disk
        # cache without starting downloads or XML conversion in the player.
        self._epg_timer = eTimer()
        try:
            self._epg_timer.timeout.connect(self._delayedEpg)
        except Exception:
            self._epg_timer.callback.append(self._delayedEpg)
        self._epg_ready = False

        self["actions"] = ActionMap([
            "OkCancelActions", "DirectionActions", "InfobarShowHideActions",
            "ChannelSelectBaseActions", "InfobarChannelSelection", "ColorActions", "NumberActions", "MenuActions"
        ], {
            "cancel": self.back,
            "red": self.openSubtitleEditor,
            "ok": self.showInfobar,
            "toggleShow": self.showInfobar,
            "up": self.nextChannel,
            "channelUp": self.nextChannel,
            "down": self.prevChannel,
            "channelDown": self.prevChannel,
            "menu": self.openPlayerEngineMenu,
            "info": self.openPlayerEngineMenu,
            "0": self.cycleServiceType,
            "blue": self.openSubsSupport,
            
        }, -2)

        self._events = ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evStart: self._serviceStarted,
        })
        self.onFirstExecBegin.append(self.playCurrent)
        self.onClose.append(self._cleanup)

    def _current(self):
        if not self.channels:
            return {}
        return self.channels[self.index]

    def _urlFor(self, item):
        try:
            stype = self.source.get("type")
            if stype in ("xtream", "stalker"):
                return get_source_client(self.source).stream_url(item, "live")
            if stype == "m3u":
                return item.get("url", "")
            return ""
        except Exception:
            return ""

    def playCurrent(self):
        item = self._current()
        if not item:
            return
        url = self._urlFor(item)
        if not url:
            return
        self.current_url = url
        name = item.get("name") or item.get("title") or "IPTV"
        ref = live_reference(self.source, item, int(self.service_type), url, name)
        self.current_ref = ref
        try:
            # Stop the previous DVB/IPTV service explicitly before every zap.
            # Some DreamOS/OpenATV builds otherwise leave the DVB decoder alive
            # while the new IPTV service fails to take ownership.
            try:
                self.session.nav.stopService()
            except Exception:
                pass
            try:
                self.session.nav.playService(ref, forceRestart=True)
            except TypeError:
                self.session.nav.playService(ref)
        except Exception:
            return
        self["channel"].setText(name)
        self["counter"].setText("%d / %d" % (self.index + 1, len(self.channels)))
        self._updateClock()
        try:
            self._clock_timer.start(30000, False)
        except Exception:
            pass
        self._loadPicon(item)
        self._scheduleEpg()
        self.showInfobar()

    def cycleServiceType(self):
        values = [value for value, _label in _available_service_types()]
        try:
            pos = values.index(int(self.service_type))
        except Exception:
            pos = 0
        self.service_type = values[(pos + 1) % len(values)]
        _save_service_type(self.service_type)
        self["hint"].setText("Engine: %s   MENU Player Engine   BLUE SubsSupport" % self.service_type)
        self.playCurrent()

    def openPlayerEngineMenu(self):
        choices = []
        for value, label in _available_service_types():
            prefix = "✓ " if int(value) == int(self.service_type) else ""
            choices.append((prefix + label, value))
        self.session.openWithCallback(
            self._playerEngineSelected,
            ChoiceBox,
            title="اختر محرك التشغيل العام",
            list=choices
        )

    def _playerEngineSelected(self, selected):
        if not selected:
            return
        value = int(selected[1])
        if value == int(self.service_type):
            return
        self.service_type = value
        _save_service_type(value)
        self["hint"].setText("Engine: %s   MENU Player Engine   BLUE SubsSupport" % self.service_type)
        self.playCurrent()

    def _clearSubsSupport(self):
        support = getattr(self, "_subssupport", None)
        self._subssupport = None
        if support is None:
            return
        try:
            support.hideSubsDialog()
        except Exception:
            pass
        try:
            support.exitSubs()
        except Exception:
            pass

    def _subsSupportEpgContext(self):
        """Return the current EPG title and elapsed programme seconds."""
        item = self._current()
        now = int(time.time())
        try:
            current, _upcoming = lookup_channel_epg(self.source, item, now)
            if current and len(current) > 2:
                title = str(current[2] or "").strip()
                start = int(current[0] or 0)
                stop = int(current[1] or 0)
                elapsed = max(0, now - start) if start else 0
                if stop > start:
                    elapsed = min(elapsed, max(0, stop - start))
                if title:
                    return title, elapsed
        except Exception:
            pass

        # Fallback title has no reliable start time, so do not invent an offset.
        try:
            import re
            title = str(self["epgNow"].getText() or "").strip()
            title = re.sub(r"^\s*\d{1,2}[:.]\d{2}\s*[\-–—]\s*\d{1,2}[:.]\d{2}\s*", "", title).strip()
            if title and title.lower() not in ("no epg data",):
                return title, 0
        except Exception:
            pass
        return "", 0

    def _subsSupportSearchTitle(self):
        return self._subsSupportEpgContext()[0]

    def openSubsSupport(self):
        """Open SubsSupportPro first using the current EPG programme title."""
        try:
            search_title, elapsed_seconds = self._subsSupportEpgContext()
            from .subtitle_picker_bridge import open_subtitle_search
            if open_subtitle_search(self, search_title, elapsed_seconds=elapsed_seconds):
                return
        except Exception:
            pass
        self.session.open(
            MessageBox,
            "تعذر فتح SubsSupportPro أو SubsSupport. تحقق من توافق الإضافة المثبتة.",
            MessageBox.TYPE_ERROR,
            timeout=6
        )

    def openSubtitleEditor(self):
        """Open the active SubsSupport subtitle-line picker with RED."""
        try:
            from .subtitle_picker_bridge import open_active_subtitle_picker
            if open_active_subtitle_picker(self, [getattr(self, "_subssupport", None)]):
                return
        except Exception:
            pass
        self.session.open(
            MessageBox,
            "لا توجد ترجمة قابلة للتعديل. حمّل الترجمة وشغّلها أولاً بالزر الأزرق.",
            MessageBox.TYPE_INFO,
            timeout=5
        )

    def _serviceStarted(self):
        # Service notifications preserve playback-first navigation.
        self.showInfobar()

    def nextChannel(self):
        if not self.channels:
            return
        self.index = (self.index + 1) % len(self.channels)
        self.playCurrent()

    def prevChannel(self):
        if not self.channels:
            return
        self.index = (self.index - 1) % len(self.channels)
        self.playCurrent()

    def _loadPicon(self, item):
        self._picon_token += 1
        token = self._picon_token
        url = item.get("stream_icon") or item.get("logo") or ""
        try:
            self["picon"].instance.setPixmapFromFile(os.path.join(os.path.dirname(__file__), "skins", "transparent.png"))
        except Exception:
            pass
        if not url:
            return

        def ready(path, expected=url, request_token=token):
            if request_token != self._picon_token or expected != url or not path:
                return
            self._picon_path = path
            try:
                render_width, render_height = scale_size(280, 168)
                # High-quality decode while keeping the already cached source image.
                self._pic.setPara((render_width,render_height,1,1,False,1,"#00000000"))
                self._pic.startDecode(path)
            except Exception:
                pass

        # The queue serves a cache hit immediately and limits all live-picon
        # downloads with the same four-transfer policy used by every screen.
        request_artwork(url, "logos", ready, priority=35)

    def _piconDecoded(self, info=None):
        try:
            ptr = self._pic.getData()
            if ptr is not None and self["picon"].instance:
                self["picon"].instance.setPixmap(ptr)
        except Exception:
            pass

    def _scheduleEpg(self):
        self._epg_ready = False
        try:
            self._epg_timer.stop()
        except Exception:
            pass
        self["epgNow"].setText(tr(""))
        self["epgNext"].setText(tr(""))
        self["epgProgress"].setValue(0)
        self["epgProgressText"].setText(tr(""))
        try:
            self._epg_timer.start(3000, True)
        except TypeError:
            self._epg_timer.start(3000)
        except Exception:
            self._delayedEpg()

    def _delayedEpg(self):
        self._epg_ready = True
        self._updateEpg()

    def _formatEpgClock(self, begin, duration):
        try:
            end = int(begin) + int(duration or 0)
            return "%s–%s" % (time.strftime("%H:%M", time.localtime(int(begin))), time.strftime("%H:%M", time.localtime(end)))
        except Exception:
            return ""

    def _updateEpg(self, item=None):
        item = item or self._current()
        try:
            current, upcoming = lookup_channel_epg(self.source, item, int(time.time()))
        except Exception:
            current, upcoming = None, None
        if not current:
            # Never download or parse XMLTV while live playback is starting.
            # Updates are handled at application/session level.
            self["epgNow"].setText(tr("No EPG data"))
            self["epgNext"].setText(tr(""))
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText(tr(""))
            return
        begin, duration, title, desc = current
        now = int(time.time())
        elapsed = max(0, now - int(begin))
        percent = min(100, max(0, int((elapsed * 100) / int(duration)))) if int(duration or 0) > 0 else 0
        remaining = max(0, int(begin) + int(duration or 0) - now)
        remaining_min = int((remaining + 59) / 60)
        self["epgNow"].setText("%s   %s" % (self._formatEpgClock(begin, duration), title or ""))
        if upcoming:
            ub, ud, ut, _ux = upcoming
            self["epgNext"].setText("%s   %s" % (self._formatEpgClock(ub, ud), ut or ""))
        else:
            self["epgNext"].setText(tr(""))
        self["epgProgress"].setValue(percent)
        self["epgProgressText"].setText("%d%%  •  %d min left" % (percent, remaining_min))

    def _updateClock(self):
        try:
            self["clock"].setText(time.strftime("%H:%M  %d/%m/%Y"))
            if self._epg_ready:
                self._updateEpg()
        except Exception:
            pass

    def back(self):
        self.close(self.index)

    def _cleanup(self):
        self._clearSubsSupport()
        try:
            self._clock_timer.stop()
            self._epg_timer.stop()
            self._ib_timer.stop()
        except Exception:
            pass
        try:
            if self._original_service is not None:
                self.session.nav.playService(self._original_service)
        except Exception:
            pass


# Resolve the native FHD/WQHD layout only after the full player class exists.
TiviMateLivePlayer.skin = scale_skin(TiviMateLivePlayer.skin)
