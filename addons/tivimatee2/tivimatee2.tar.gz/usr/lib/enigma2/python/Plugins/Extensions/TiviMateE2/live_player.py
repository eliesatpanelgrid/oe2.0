# -*- coding: utf-8 -*-
from .storage import get_data_root, data_path
import os, threading, time, json, re

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.ServiceEventTracker import InfoBarBase, ServiceEventTracker
from Components.Sources.StaticText import StaticText
from enigma import eTimer, ePicLoad, iPlayableService, iServiceInformation
from .live_service import live_reference
from .epg_local import lookup_channel_epg
from .artwork_queue import request_artwork, cached_artwork
from .tmdb_client import TMDbClient
from .estalker_picon import direct_picon
from .display_scale import scale_skin, scale_size
from .i18n import tr
from Screens.ChoiceBox import ChoiceBox
from Screens.InfoBarGenerics import InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarSummarySupport
from Screens.MessageBox import MessageBox
from .recording_manager import stalker_live_recorder
from Screens.Screen import Screen

try:
    from .core import XtreamClient, M3UClient, StalkerClient, get_source_client, cached_image, stalker_log, load_stalker_compat, save_stalker_compat
except Exception:
    XtreamClient = M3UClient = StalkerClient = get_source_client = None
    cached_image = None
    def load_stalker_compat(portal, mac): return {}
    def save_stalker_compat(portal, mac, **values): return {}
    def stalker_log(message):
        pass


PLAYER_CONFIG = data_path("player.json")
# Kept only as a read fallback for installations that used the earlier live-only setting.
LIVE_SETTINGS_FILE = data_path("channel_settings.json")


STALKER_SERVICE_TYPES_FILE = data_path("stalker_service_types.json")

def _stalker_source_key(source):
    source = source or {}
    return "%s|%s" % (source.get("portal") or source.get("url") or "", source.get("mac") or "")

def _load_stalker_live_service_type(source, fallback):
    if (source or {}).get("type") != "stalker":
        return fallback
    try:
        with open(STALKER_SERVICE_TYPES_FILE, "r") as handle:
            raw = json.load(handle) or {}
        value = int((raw.get(_stalker_source_key(source), {}) or {}).get("live", fallback))
        if value in (1, 4097, 5001, 5002):
            return value
    except Exception:
        pass
    return fallback



def _stalker_compat(source):
    source = source or {}
    return load_stalker_compat(source.get("portal") or source.get("url") or "", source.get("mac") or "")

def _save_stalker_engine(source, value):
    source = source or {}
    return save_stalker_compat(source.get("portal") or source.get("url") or "", source.get("mac") or "", live_engine=int(value))

def _available_service_types():
    values = [(4097, "GStreamer 4097 (default)")]
    serviceapp = any(os.path.isdir(path) for path in (
        "/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp",
        "/usr/lib/enigma2/python/Plugins/Extensions/ServiceApp",
    ))
    if serviceapp or os.path.exists("/usr/bin/gstplayer"):
        values.append((5001, "GstPlayer 5001"))
    if serviceapp or os.path.exists("/usr/bin/exteplayer3"):
        values.append((5002, "ExtePlayer3 5002"))
    return values

def _load_service_type():
    available = [value for value, _label in _available_service_types()]
    for path in (PLAYER_CONFIG, LIVE_SETTINGS_FILE):
        try:
            import json
            with open(path, "r") as handle:
                value = int((json.load(handle) or {}).get("service_type", 4097))
            if value in available:
                return value
        except Exception:
            pass
    return available[0] if available else 4097

def _save_service_type(value):
    try:
        import json
        folder = os.path.dirname(PLAYER_CONFIG)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = PLAYER_CONFIG + ".tmp"
        with open(tmp, "w") as handle:
            json.dump({"service_type": int(value)}, handle)
        os.rename(tmp, PLAYER_CONFIG)
    except Exception:
        pass

class LiveInfoBarShowHide(object):
    STATE_HIDDEN = 0
    STATE_SHOWN = 1

    def __init__(self):
        self._ib_state = self.STATE_SHOWN
        self._ib_timer = eTimer()
        try:
            self._ib_timer.timeout.connect(self._hideInfobar)
        except Exception:
            self._ib_timer.callback.append(self._hideInfobar)
        self.onShow.append(self._onShown)
        self.onHide.append(self._onHidden)

    def _onShown(self):
        self._ib_state = self.STATE_SHOWN
        self._startHideTimer()

    def _onHidden(self):
        self._ib_state = self.STATE_HIDDEN

    def _startHideTimer(self):
        try:
            self._ib_timer.stop()
            self._ib_timer.start(5000, True)
        except Exception:
            pass

    def _hideInfobar(self):
        try:
            self.hide()
        except Exception:
            pass

    def toggleInfobar(self):
        if self._ib_state == self.STATE_HIDDEN:
            self.show()
            self._startHideTimer()
        else:
            self.hide()

    def showInfobar(self):
        try:
            self.show()
            self._startHideTimer()
        except Exception:
            pass


class TiviMateLivePlayer(InfoBarBase, LiveInfoBarShowHide, InfoBarAudioSelection,
                         InfoBarSubtitleSupport, InfoBarSummarySupport, Screen):
    """Dedicated Live player. It intentionally does not inherit or modify the VOD player."""

    skin = '''<screen name="TiviMateLivePlayer" position="0,0" size="1920,1080" backgroundColor="#ff000000" flags="wfNoBorder">
        <!-- Premium dark glass infobar: low Enigma2 alpha = more opaque -->
        <eLabel position="0,782" size="1920,298" backgroundColor="#1810151c" zPosition="1"/>
        <eLabel position="0,782" size="1920,3" backgroundColor="#1834d6e8" zPosition="2"/>
        <eLabel position="330,806" size="2,250" backgroundColor="#30465a6a" zPosition="2"/>
        <eLabel position="1590,806" size="2,250" backgroundColor="#30465a6a" zPosition="2"/>

        <widget name="picon" position="55,792" size="245,105" alphatest="blend" scale="1" zPosition="4"/>
        <widget source="channel" render="Label" position="365,807" size="950,50" font="Regular;38" foregroundColor="#ffffff" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget source="session.CurrentService" render="Label" position="1320,813" size="215,40" font="Regular;25" foregroundColor="#65e7f2" backgroundColor="#00000000" transparent="1" noWrap="1" halign="right" zPosition="4"><convert type="TiviMateTestServiceInfo">VideoResolution</convert></widget>

        <widget name="nowTag" position="365,871" size="100,38" font="Regular;27" foregroundColor="#31e6f2" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="epgNow" position="470,871" size="1000,38" font="Regular;28" foregroundColor="#ffffff" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="nextTag" position="365,918" size="100,34" font="Regular;23" foregroundColor="#ffd34d" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="epgNext" position="470,918" size="1000,34" font="Regular;23" foregroundColor="#dbe5ee" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>

        <eLabel position="365,972" size="1100,10" backgroundColor="#18313d48" zPosition="3"/>
        <widget name="epgProgress" position="365,972" size="1100,10" borderWidth="0" backgroundColor="#18313d48" foregroundColor="#21d9e8" zPosition="4"/>
        <widget name="epgProgressText" position="1160,988" size="305,32" font="Regular;20" foregroundColor="#aeeff4" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="4"/>

        <!-- right-side status panel -->
        <widget source="counter" render="Label" position="1600,815" size="250,40" font="Regular;26" foregroundColor="#ffffff" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4"/>
        <widget source="clock" render="Label" position="1590,860" size="260,40" font="Regular;24" foregroundColor="#dce8ef" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4"/>
        <eLabel position="1600,915" size="78,34" backgroundColor="#2025323d" zPosition="3"/>
        <eLabel text="HD" position="1600,915" size="78,34" font="Regular;21" foregroundColor="#65e7f2" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4"/>
        <eLabel position="1690,915" size="78,34" backgroundColor="#2025323d" zPosition="3"/>
        <eLabel text="16:9" position="1690,915" size="78,34" font="Regular;19" foregroundColor="#ffffff" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4"/>
        <eLabel position="1780,915" size="70,34" backgroundColor="#2025323d" zPosition="3"/>
        <eLabel text="2.0" position="1780,915" size="70,34" font="Regular;19" foregroundColor="#ffffff" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4"/>
        <widget source="hint" render="Label" position="1585,975" size="265,48" font="Regular;17" foregroundColor="#86c9e8" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4"/>

        <!-- live poster lower under the raised picon -->
        <widget name="posterFrame" position="83,900" size="194,148" font="Regular;1" text="" backgroundColor="#1810151c" borderWidth="2" borderColor="#b0ffffff" transparent="0" zPosition="5"/>
        <widget name="livePoster" position="89,906" size="182,106" alphatest="blend" scale="1" zPosition="6"/>
        <widget name="posterStars" position="89,1015" size="182,20" font="Regular;16" foregroundColor="#ffd21f" backgroundColor="#00000000" transparent="1" halign="center" zPosition="7"/>
        <widget name="posterMeta" position="89,1036" size="182,18" font="Regular;14" foregroundColor="#ffffff" backgroundColor="#00000000" transparent="1" halign="center" zPosition="7"/>
    </screen>'''

    def __init__(self, session, source, channels, index=0, reuse_current=False):
        Screen.__init__(self, session)
        self.session = session
        self.source = source or {}
        self.channels = list(channels or [])
        self.reuse_current = bool(reuse_current)
        self.index = max(0, min(int(index or 0), max(0, len(self.channels) - 1)))
        compat = _stalker_compat(self.source) if self.source.get("type") == "stalker" else {}
        saved_auto_engine = compat.get("live_engine")
        self._auto_engine = bool(self.source.get("type") == "stalker" and not saved_auto_engine)
        if self.source.get("type") == "stalker":
            initial_engine = saved_auto_engine or _load_stalker_live_service_type(self.source, _load_service_type())
        else:
            initial_engine = self.source.get("service_type", _load_service_type())
        self.service_type = int(initial_engine or 4097)
        available_engines = [v for v, _label in _available_service_types()]
        preferred_order = [4097, 5002, 5001, 1]
        self._engine_candidates = [v for v in preferred_order if v in available_engines and v != self.service_type]
        self._engine_attempted = [self.service_type]
        self.current_url = ""
        self._live_client = None
        try:
            if self.source.get("type") in ("xtream", "stalker"):
                self._live_client = get_source_client(self.source)
        except Exception:
            self._live_client = None

        # Stalker create_link is a network operation. Never run it on the
        # Enigma2 UI thread; otherwise the system spinner appears while the
        # portal is resolving the channel URL.
        self._liveResolveToken = 0
        self._liveResolveResult = None
        self._liveResolveTimer = eTimer()
        try:
            self._liveResolveTimer.timeout.connect(self._finishAsyncLiveResolve)
        except Exception:
            self._liveResolveTimer.callback.append(self._finishAsyncLiveResolve)
        self._picon_token = 0
        self._picon_path = None
        self._subssupport = None
        self._original_service = None
        try:
            self._original_service = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            pass

        InfoBarBase.__init__(self)
        LiveInfoBarShowHide.__init__(self)
        InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        InfoBarSummarySupport.__init__(self)

        self["channel"] = StaticText("")
        self["counter"] = StaticText("")
        self["clock"] = StaticText("")
        self["hint"] = StaticText(tr("↑↓ Change   MENU Player Engine   BLUE SubsSupport   RED Edit Subtitles"))
        self["picon"] = Pixmap()
        self["posterFrame"] = Label("")
        self["livePoster"] = Pixmap()
        self["posterStars"] = Label("")
        self["posterMeta"] = Label("")
        self._livePosterToken = 0
        self._livePosterResult = None
        self._livePosterTimer = eTimer()
        try:
            self._livePosterTimer.callback.append(self._startInfobarPosterLookup)
        except Exception:
            self._livePosterTimer.timeout.connect(self._startInfobarPosterLookup)
        self._livePosterPoll = eTimer()
        try:
            self._livePosterPoll.callback.append(self._finishInfobarPosterLookup)
        except Exception:
            self._livePosterPoll.timeout.connect(self._finishInfobarPosterLookup)
        self._livePosterPic = ePicLoad()
        try:
            self._livePosterPic.PictureData.get().append(self._infobarPosterDecoded)
        except Exception:
            self._livePosterPicConn = self._livePosterPic.PictureData.connect(self._infobarPosterDecoded)
        try:
            self["posterFrame"].hide()
            self["livePoster"].hide()
            self["posterStars"].hide()
            self["posterMeta"].hide()
        except Exception:
            pass
        self["nowTag"] = Label(tr("NOW"))
        self["epgNow"] = Label("")
        self["nextTag"] = Label(tr("NEXT"))
        self["epgNext"] = Label("")
        self["epgProgress"] = ProgressBar()
        self["epgProgressText"] = Label("")
        try:
            self["epgProgress"].setRange((0, 100))
        except Exception:
            pass

        self._pic = ePicLoad()
        try:
            self._pic.PictureData.get().append(self._piconDecoded)
        except Exception:
            self._pic_conn = self._pic.PictureData.connect(self._piconDecoded)

        self._clock_timer = eTimer()
        try:
            self._clock_timer.timeout.connect(self._updateClock)
        except Exception:
            self._clock_timer.callback.append(self._updateClock)

        # Playback must start before any EPG JSON work.  The one-shot timer
        # lets the decoder settle, then reads the already-built in-memory/disk
        # cache without starting downloads or XML conversion in the player.
        self._epg_timer = eTimer()
        try:
            self._epg_timer.timeout.connect(self._delayedEpg)
        except Exception:
            self._epg_timer.callback.append(self._delayedEpg)
        self._epg_ready = False
        self._stalker_epg_token = 0
        self._stalker_epg_result = None
        self._stalker_epg_poll = eTimer()
        try:
            self._stalker_epg_poll.timeout.connect(self._finishStalkerPlayerEpg)
        except Exception:
            self._stalker_epg_poll.callback.append(self._finishStalkerPlayerEpg)

        self._engine_timer = eTimer()
        try:
            self._engine_timer.timeout.connect(self._verifyAutoEngine)
        except Exception:
            self._engine_timer.callback.append(self._verifyAutoEngine)

        self._watchdog_timer = eTimer()
        try:
            self._watchdog_timer.timeout.connect(self._sendStalkerWatchdog)
        except Exception:
            self._watchdog_timer.callback.append(self._sendStalkerWatchdog)

        self._catchup_result = None
        self._catchup_item = None
        self._catchup_timer = eTimer()
        try:
            self._catchup_timer.timeout.connect(self._finishXtreamCatchupFromInfobar)
        except Exception:
            self._catchup_timer.callback.append(self._finishXtreamCatchupFromInfobar)

        self["actions"] = ActionMap([
            "OkCancelActions", "DirectionActions", "InfobarShowHideActions",
            "ChannelSelectBaseActions", "InfobarChannelSelection", "ColorActions", "NumberActions", "MenuActions",
            "InfobarInstantRecord", "RecordActions"
        ], {
            "cancel": self.back,
            "red": self.openSubtitleEditor,
            "ok": self.showInfobar,
            "oklong": self.back,
            "toggleShow": self.showInfobar,
            "right": self.nextChannel,
            "left": self.prevChannel,
            "up": self.back,
            "down": self.back,
            "channelUp": self.nextChannel,
            "channelDown": self.prevChannel,
            "menu": self.openPlayerEngineMenu,
            "info": self.openCatchupFromInfobar,
            "0": self.cycleServiceType,
            "blue": self.openSubsSupport,
            "instantRecord": self.toggleLiveRecording,
            "record": self.toggleLiveRecording,
        }, -2)

        self._events = ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evStart: self._serviceStarted,
        })
        if self.reuse_current:
            self.onFirstExecBegin.append(self._showCurrentWithoutRestart)
        else:
            self.onFirstExecBegin.append(self.playCurrent)
        self.onClose.append(self._cleanup)

    def _showCurrentWithoutRestart(self):
        """Reopen the full-screen Live UI around the already playing service.

        This intentionally does not resolve stream_url/create_link and never
        calls playService, so selecting the same channel from the list cannot
        refresh or restart playback.
        """
        item = self._current()
        if not item:
            return
        name = item.get("name") or item.get("title") or "IPTV"
        try:
            self.current_ref = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            self.current_ref = None
        try:
            self.source["_tivimate_current_live_id"] = str(
                item.get("stream_id") or item.get("ch_id") or item.get("id") or
                item.get("url") or item.get("cmd") or item.get("name") or ""
            ).strip()
        except Exception:
            pass
        self["channel"].setText(name)
        self["counter"].setText("%d / %d" % (self.index + 1, len(self.channels)))
        self._updateClock()
        try:
            self._clock_timer.start(10000, False)
        except Exception:
            pass
        self._loadPicon(item)
        self._scheduleEpg()
        self.showInfobar()

    def _current(self):
        if not self.channels:
            return {}
        return self.channels[self.index]

    def _urlFor(self, item):
        try:
            stype = self.source.get("type")
            if stype in ("xtream", "stalker"):
                client = self._live_client
                if client is None:
                    client = get_source_client(self.source)
                    self._live_client = client
                return client.stream_url(item, "live")
            if stype in ("m3u", "fg"):
                return item.get("url", "")
            return ""
        except Exception as exc:
            try:
                if self.source.get("type") == "stalker":
                    stalker_log("PLAYER resolve failed channel=%s error=%s" % (
                        (item or {}).get("name") or (item or {}).get("title") or "", exc))
            except Exception:
                pass
            return ""


    def _playResolvedCurrent(self, item, url, expected_index=None):
        if not item or not url:
            return
        if expected_index is not None and int(expected_index) != int(self.index):
            return

        self.current_url = url
        try:
            self.source["_tivimate_current_live_id"] = str(
                item.get("stream_id") or item.get("ch_id") or item.get("id") or
                item.get("url") or item.get("cmd") or item.get("name") or ""
            ).strip()
        except Exception:
            pass
        name = item.get("name") or item.get("title") or "IPTV"
        if self.source.get("type") == "stalker":
            try:
                stalker_log("PLAYER service_type=%s channel=%s url=%s" % (
                    self.service_type, name, (url or "")[:180]))
            except Exception:
                pass
        effective_service_type = int(self.service_type)
        try:
            if effective_service_type == 1 and ".m3u8" in str(url).lower():
                effective_service_type = 4097
        except Exception:
            pass
        ref = live_reference(self.source, item, effective_service_type, url, name)
        self.current_ref = ref
        try:
            self.session.nav.playService(ref)
        except Exception:
            return

        self["channel"].setText(name)
        self["counter"].setText("%d / %d" % (self.index + 1, len(self.channels)))
        self._updateClock()
        try:
            self._clock_timer.start(10000, False)
        except Exception:
            pass
        self._loadPicon(item)
        self._scheduleEpg()
        self.showInfobar()

        if self.source.get("type") == "stalker":
            try:
                self._watchdog_timer.stop()
                self._watchdog_timer.start(30000, True)
            except Exception:
                pass
            if self._auto_engine:
                try:
                    self._engine_timer.stop()
                    self._engine_timer.start(5500, True)
                except Exception:
                    pass

    def _finishAsyncLiveResolve(self):
        result = self._liveResolveResult
        if result is None:
            try:
                self._liveResolveTimer.start(80, True)
            except Exception:
                pass
            return

        self._liveResolveResult = None
        token, index, item, url = result
        if token != self._liveResolveToken or index != self.index:
            return
        if not url:
            try:
                self["channel"].setText(item.get("name") or item.get("title") or "IPTV")
            except Exception:
                pass
            return
        self._playResolvedCurrent(item, url, index)

    def playCurrent(self):
        item = self._current()
        if not item:
            return

        # Stalker create_link can take seconds. Resolve it in a worker so
        # Enigma2 never blocks and never shows its system Loading spinner.
        if self.source.get("type") == "stalker":
            self._liveResolveToken += 1
            token = self._liveResolveToken
            index = int(self.index)
            selected = dict(item or {})
            self._liveResolveResult = None

            try:
                self["channel"].setText(selected.get("name") or selected.get("title") or "IPTV")
                self["counter"].setText("%d / %d" % (index + 1, len(self.channels)))
            except Exception:
                pass

            client = self._live_client
            if client is None:
                try:
                    client = get_source_client(self.source)
                    self._live_client = client
                except Exception:
                    client = None

            def worker():
                url = ""
                try:
                    if client is not None:
                        url = client.stream_url(selected, "live") or ""
                except Exception as exc:
                    try:
                        stalker_log("PLAYER async resolve failed channel=%s error=%s" % (
                            selected.get("name") or selected.get("title") or "", exc))
                    except Exception:
                        pass
                self._liveResolveResult = (token, index, selected, url)

            thread = threading.Thread(target=worker, name="TiviMateStalkerCreateLink")
            thread.daemon = True
            thread.start()
            try:
                self._liveResolveTimer.start(40, True)
            except Exception:
                pass
            return

        # Xtream/M3U links are local/cheap and keep the existing fast path.
        url = self._urlFor(item)
        if not url:
            return
        self._playResolvedCurrent(item, url, self.index)


    def _sendStalkerWatchdog(self):
        if self.source.get("type") != "stalker":
            return
        client = self._live_client
        if client is None:
            return
        def worker():
            try: client.watchdog()
            except Exception: pass
        t = threading.Thread(target=worker, name="TiviMateStalkerWatchdog")
        t.daemon = True
        t.start()
        try: self._watchdog_timer.start(30000, True)
        except Exception: pass

    def _videoIsReady(self):
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if not info:
                return False
            width = info.getInfo(iServiceInformation.sVideoWidth)
            height = info.getInfo(iServiceInformation.sVideoHeight)
            return int(width or 0) > 0 and int(height or 0) > 0
        except Exception:
            return False

    def _verifyAutoEngine(self):
        if self.source.get("type") != "stalker" or not self._auto_engine:
            return
        if self._videoIsReady():
            _save_stalker_engine(self.source, self.service_type)
            self._auto_engine = False
            stalker_log("AUTO ENGINE success service_type=%s" % self.service_type)
            return
        if not self._engine_candidates:
            self._auto_engine = False
            stalker_log("AUTO ENGINE exhausted attempted=%s" % self._engine_attempted)
            return
        next_engine = int(self._engine_candidates.pop(0))
        self.service_type = next_engine
        self._engine_attempted.append(next_engine)
        stalker_log("AUTO ENGINE try service_type=%s" % next_engine)
        self["hint"].setText("Auto engine: %s" % next_engine)
        self.playCurrent()

    def cycleServiceType(self):
        values = [value for value, _label in _available_service_types()]
        try:
            pos = values.index(int(self.service_type))
        except Exception:
            pos = 0
        self.service_type = values[(pos + 1) % len(values)]
        _save_service_type(self.service_type)
        if self.source.get("type") == "stalker":
            _save_stalker_engine(self.source, self.service_type)
            self._auto_engine = False
        self["hint"].setText("Engine: %s   MENU Player Engine   BLUE SubsSupport" % self.service_type)
        self.playCurrent()

    def _catchupDecodeText(self, value):
        value = value or ""
        try:
            import base64
            raw = str(value).strip()
            if raw and re.match(r"^[A-Za-z0-9+/=]+$", raw) and len(raw) % 4 == 0:
                decoded = base64.b64decode(raw)
                try:
                    decoded = decoded.decode("utf-8", "ignore")
                except Exception:
                    pass
                if decoded:
                    return str(decoded)
        except Exception:
            pass
        return str(value or "")

    def _catchupTimestamp(self, row, begin=True):
        row = row or {}
        keys = ("start_timestamp", "begin_timestamp", "start", "begin", "date_start") if begin else (
            "stop_timestamp", "end_timestamp", "stop", "end", "date_end"
        )
        for key in keys:
            raw = row.get(key)
            if raw in (None, ""):
                continue
            try:
                value = int(float(str(raw)))
                if value > 100000000000:
                    value = int(value / 1000)
                if value > 1000000000:
                    return value
            except Exception:
                pass
            text = str(raw or "").strip().replace("T", " ")
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d:%H-%M"):
                try:
                    return int(time.mktime(time.strptime(text[:19], fmt)))
                except Exception:
                    pass
        return 0

    def openCatchupFromInfobar(self):
        source_type = self.source.get("type")
        if source_type == "stalker":
            self._openStalkerCatchupFromInfobar()
            return
        if source_type != "xtream":
            self.openPlayerEngineMenu()
            return
        item = self._current() or {}
        if not (item.get("tv_archive") or item.get("archive") or item.get("has_archive") or item.get("tv_archive_duration")):
            self.session.open(MessageBox, tr("This channel does not advertise catch-up support."), MessageBox.TYPE_INFO, timeout=4)
            return
        if self._catchup_result is not None:
            return
        self._catchup_item = dict(item)
        stream_id = str(item.get("stream_id") or item.get("id") or "")
        epg_id = str(item.get("epg_channel_id") or item.get("epg_id") or "")
        source = dict(self.source or {})
        self["hint"].setText(tr("Loading catch-up..."))

        def worker():
            rows, error = [], ""
            try:
                rows = XtreamClient(source).short_epg(stream_id, limit=20, epg_channel_id=epg_id) or []
            except Exception as exc:
                error = str(exc)
            self._catchup_result = (rows, error)

        t = threading.Thread(target=worker, name="TiviMateInfobarCatchup")
        t.daemon = True
        t.start()
        try:
            self._catchup_timer.start(120, False)
        except Exception:
            pass

    def _openStalkerCatchupFromInfobar(self):
        item = self._current() or {}
        if not item:
            return
        self._catchup_item = dict(item)
        self._catchup_result = None
        source = dict(self.source or {})
        channel_id = str(
            item.get("ch_id") or item.get("stream_id") or item.get("id") or
            item.get("cmd") or item.get("url") or ""
        ).strip()
        if not channel_id:
            self.session.open(MessageBox, tr("Catch-up is not available for this channel."), MessageBox.TYPE_INFO, timeout=4)
            return

        self["hint"].setText(tr("Loading catch-up..."))

        def worker():
            rows, error = [], ""
            try:
                client = StalkerClient(source)
                rows = client.short_epg(channel_id, limit=20, force=True) or []
            except Exception as exc:
                error = str(exc)
            self._catchup_result = ("stalker", rows, error)

        t = threading.Thread(target=worker, name="TiviMateStalkerInfobarCatchup")
        t.daemon = True
        t.start()
        try:
            self._catchup_timer.start(120, False)
        except Exception:
            pass

    def _finishStalkerCatchupFromInfobar(self, rows, error):
        now = int(time.time())
        choices = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._catchupTimestamp(row, True)
            end = self._catchupTimestamp(row, False)
            title = self._catchupDecodeText(row.get("title") or row.get("name") or row.get("programme"))
            archive = row.get("has_archive") or row.get("archive") or row.get("allow_archive") or row.get("tv_archive")
            if begin and begin < now and title and (archive not in (0, "0", False) or not end or end <= now):
                payload = dict(row)
                payload["_begin"] = begin
                payload["_end"] = end
                label = "%s  %s" % (time.strftime("%d/%m %H:%M", time.localtime(begin)), title)
                choices.append((label, payload))

        self["hint"].setText("")
        if not choices:
            msg = tr("No catch-up programmes are available for this channel.")
            if error:
                msg += "\n" + error
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)
            return

        self.session.openWithCallback(
            self._playStalkerCatchupFromInfobar,
            ChoiceBox,
            title=tr("Catch-up / Archive"),
            list=choices
        )

    def _playStalkerCatchupFromInfobar(self, selected=None):
        if not selected:
            return
        event = dict(selected[1] or {})
        item = self._catchup_item or self._current() or {}
        try:
            client = StalkerClient(dict(self.source or {}))
            url = client.create_catchup_link(item, event)
            if not url:
                raise RuntimeError(tr("Portal returned no archive link"))

            title = self._catchupDecodeText(event.get("title") or event.get("name")) or item.get("name") or "Catch-up"
            service_type = int(self.service_type or 4097)
            ref = live_reference(self.source, item, service_type, url, title)

            try:
                self.session.nav.stopService()
            except Exception:
                pass
            try:
                self.session.nav.playService(ref, forceRestart=True)
            except TypeError:
                self.session.nav.playService(ref)

            self.current_ref = ref
            self["hint"].setText(tr("Catch-up / Archive"))
            self.showInfobar()
        except Exception as exc:
            self.session.open(
                MessageBox,
                "%s: %s" % (tr("Unable to play catch-up"), exc),
                MessageBox.TYPE_ERROR
            )

    def _finishXtreamCatchupFromInfobar(self):
        result = self._catchup_result
        if result is None:
            try:
                self._catchup_timer.start(120, False)
            except Exception:
                pass
            return
        self._catchup_result = None
        try:
            self._catchup_timer.stop()
        except Exception:
            pass

        # Stalker uses the same eStalker-style flow already used by the Live menu:
        # short_epg -> create_catchup_link.
        if isinstance(result, (tuple, list)) and len(result) == 3 and result[0] == "stalker":
            self._finishStalkerCatchupFromInfobar(result[1], result[2])
            return

        rows, error = result
        now = int(time.time())
        choices = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._catchupTimestamp(row, True)
            end = self._catchupTimestamp(row, False)
            title = self._catchupDecodeText(row.get("title") or row.get("name") or row.get("programme"))
            if begin and begin < now and title:
                if not end or end <= begin:
                    end = begin + 3600
                payload = dict(row)
                payload["_begin"] = begin
                payload["_end"] = end
                label = "%s  %s" % (time.strftime("%d/%m %H:%M", time.localtime(begin)), title)
                choices.append((label, payload))
        self["hint"].setText("")
        if not choices:
            msg = tr("No catch-up programmes are available for this channel.")
            if error:
                msg += "\n" + error
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)
            return
        self.session.openWithCallback(
            self._playXtreamCatchupFromInfobar,
            ChoiceBox,
            title=tr("Catch-up / Archive"),
            list=choices
        )

    def _playXtreamCatchupFromInfobar(self, selected=None):
        if not selected:
            return
        event = dict(selected[1] or {})
        item = self._catchup_item or self._current() or {}
        try:
            begin = int(event.get("_begin") or self._catchupTimestamp(event, True) or 0)
            end = int(event.get("_end") or self._catchupTimestamp(event, False) or 0)
            if not begin:
                raise RuntimeError(tr("Programme start time is missing"))
            if not end or end <= begin:
                end = begin + 3600
            duration = max(1, int((end - begin + 59) / 60))
            base = str(self.source.get("url") or "").rstrip("/")
            user = str(self.source.get("username") or "")
            password = str(self.source.get("password") or "")
            sid = str(item.get("stream_id") or item.get("id") or "")
            if not (base and user and password and sid):
                raise RuntimeError(tr("Xtream archive credentials are incomplete"))
            start = time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin))
            url = "%s/timeshift/%s/%s/%d/%s/%s.ts" % (base, user, password, duration, start, sid)
            ref = live_reference(self.source, item, int(self.service_type), url,
                                 self._catchupDecodeText(event.get("title") or event.get("name")) or item.get("name") or "Catch-up")
            try:
                self.session.nav.stopService()
            except Exception:
                pass
            try:
                self.session.nav.playService(ref, forceRestart=True)
            except TypeError:
                self.session.nav.playService(ref)
            self.current_ref = ref
            self["hint"].setText(tr("Catch-up / Archive"))
            self.showInfobar()
        except Exception as exc:
            self.session.open(MessageBox, "%s: %s" % (tr("Unable to play catch-up"), exc), MessageBox.TYPE_ERROR)

    def openPlayerEngineMenu(self):
        choices = []
        for value, label in _available_service_types():
            prefix = "✓ " if int(value) == int(self.service_type) else ""
            choices.append((prefix + label, value))
        self.session.openWithCallback(
            self._playerEngineSelected,
            ChoiceBox,
            title="اختر محرك التشغيل العام",
            list=choices
        )

    def _playerEngineSelected(self, selected):
        if not selected:
            return
        value = int(selected[1])
        if value == int(self.service_type):
            return
        self.service_type = value
        _save_service_type(value)
        if self.source.get("type") == "stalker":
            _save_stalker_engine(self.source, self.service_type)
            self._auto_engine = False
        self["hint"].setText("Engine: %s   MENU Player Engine   BLUE SubsSupport" % self.service_type)
        self.playCurrent()


    def _recordingBackend(self):
        return stalker_live_recorder

    def toggleLiveRecording(self):
        if self.source.get("type") != "stalker":
            self.session.open(MessageBox, "Live recording is available for Stalker portals only.", MessageBox.TYPE_INFO, timeout=5)
            return
        recorder = self._recordingBackend()
        if recorder.is_recording():
            ok, message = recorder.stop()
            if ok:
                self.session.open(MessageBox, "Live recording stopped.\n%s" % message, MessageBox.TYPE_INFO, timeout=5)
            else:
                self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=5)
            self._restorePlayerEngineAfterRecording()
            return

        item = self._current()
        url = self.current_url or self._urlFor(item)
        if not url:
            self.session.open(MessageBox, "No playable Live URL is available.", MessageBox.TYPE_ERROR, timeout=5)
            return

        self._record_pending_item = dict(item or {})
        self._record_pending_url = url
        self._record_previous_service_type = int(self.service_type)

        # Native Enigma2 recording produced black files with ServiceApp engines
        # (5001/5002) on several images.  Temporarily zap the same channel
        # with 4097, wait for the decoder to lock, then start RecordService.
        if int(self.service_type) != 4097:
            self.service_type = 4097
            self["hint"].setText("Recording engine: 4097")
            self.playCurrent()
            try:
                self._recordStartTimer.stop()
            except Exception:
                self._recordStartTimer = eTimer()
                try:
                    self._recordStartTimer_conn = self._recordStartTimer.timeout.connect(self._startLiveRecordingNow)
                except Exception:
                    try:
                        self._recordStartTimer.callback.append(self._startLiveRecordingNow)
                    except Exception:
                        self._recordStartTimer.timeout.get().append(self._startLiveRecordingNow)
            self.session.open(MessageBox, "Switching temporarily to 4097 for recording...", MessageBox.TYPE_INFO, timeout=3)
            self._recordStartTimer.start(2200, True)
            return

        self._startLiveRecordingNow()

    def _startLiveRecordingNow(self):
        item = getattr(self, "_record_pending_item", None) or self._current() or {}
        url = getattr(self, "_record_pending_url", "") or self.current_url or self._urlFor(item)
        channel = item.get("name") or item.get("title") or "IPTV Live"

        # Stalker links are session-bound and often reject a reused viewing
        # URL. Resolve a new create_link exclusively for this recording.
        if self.source.get("type") == "stalker":
            try:
                client = get_source_client(self.source) if get_source_client else None
                fresh_url = client.stream_url(item, "live") if client is not None else ""
                if not fresh_url:
                    raise RuntimeError("portal returned an empty recording link")
                url = fresh_url
                self._record_pending_url = fresh_url
                stalker_log("RECORD fresh link channel=%s url=%s" % (channel, fresh_url[:180]))
            except Exception as exc:
                self._restorePlayerEngineAfterRecording()
                self.session.open(MessageBox, "Stalker recording link failed.\n%s" % exc, MessageBox.TYPE_ERROR, timeout=8)
                return

        if not url:
            self._restorePlayerEngineAfterRecording()
            self.session.open(MessageBox, "No playable Live URL is available.", MessageBox.TYPE_ERROR, timeout=5)
            return
        try:
            if self.source.get("type") == "stalker":
                # A dedicated 4097 reference is used only by the Stalker
                # recorder. The viewing service remains untouched.
                service_ref = live_reference(self.source, item, 4097, url, channel)
            else:
                service_ref = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            service_ref = None
        recorder = self._recordingBackend()
        ok, message = recorder.start(url, channel, session=self.session, service_ref=service_ref)
        if not ok:
            self._restorePlayerEngineAfterRecording()
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=7)
            return
        self.session.open(MessageBox, "Starting Live recording...", MessageBox.TYPE_INFO, timeout=3)
        try:
            self._recordVerifyTimer.stop()
        except Exception:
            self._recordVerifyTimer = eTimer()
            try:
                self._recordVerifyTimer_conn = self._recordVerifyTimer.timeout.connect(self._verifyLiveRecording)
            except Exception:
                try:
                    self._recordVerifyTimer.callback.append(self._verifyLiveRecording)
                except Exception:
                    self._recordVerifyTimer.timeout.get().append(self._verifyLiveRecording)
        self._recordVerifyTimer.start(3500, True)

    def _restorePlayerEngineAfterRecording(self):
        previous = getattr(self, "_record_previous_service_type", None)
        self._record_previous_service_type = None
        self._record_pending_item = None
        self._record_pending_url = ""
        if previous is None or int(previous) == int(self.service_type):
            return
        self.service_type = int(previous)
        self["hint"].setText("Engine: %s   MENU Player Engine   BLUE SubsSupport" % self.service_type)
        self.playCurrent()

    def _verifyLiveRecording(self):
        recorder = self._recordingBackend()
        ok, message = recorder.verify()
        if ok:
            self.session.open(MessageBox, "Live recording started.\n%s" % message, MessageBox.TYPE_INFO, timeout=5)
            return
        if recorder.is_recording():
            try:
                self._recordVerifyTimer.start(2500, True)
            except Exception:
                pass
            return
        self._restorePlayerEngineAfterRecording()
        self.session.open(MessageBox, "Recording failed.\n%s" % message, MessageBox.TYPE_ERROR, timeout=8)

    def _clearSubsSupport(self):
        support = getattr(self, "_subssupport", None)
        self._subssupport = None
        if support is None:
            return
        try:
            support.hideSubsDialog()
        except Exception:
            pass
        try:
            support.exitSubs()
        except Exception:
            pass

    def _subsSupportEpgContext(self):
        """Return the current EPG title and elapsed programme seconds."""
        item = self._current()
        now = int(time.time())
        try:
            current, _upcoming = lookup_channel_epg(self.source, item, now)
            if current and len(current) > 2:
                title = str(current[2] or "").strip()
                start = int(current[0] or 0)
                stop = int(current[1] or 0)
                elapsed = max(0, now - start) if start else 0
                if stop > start:
                    elapsed = min(elapsed, max(0, stop - start))
                if title:
                    return title, elapsed
        except Exception:
            pass

        # Fallback title has no reliable start time, so do not invent an offset.
        try:
            import re
            title = str(self["epgNow"].getText() or "").strip()
            title = re.sub(r"^\s*\d{1,2}[:.]\d{2}\s*[\-–—]\s*\d{1,2}[:.]\d{2}\s*", "", title).strip()
            if title and title.lower() not in ("no epg data",):
                return title, 0
        except Exception:
            pass
        return "", 0

    def _subsSupportSearchTitle(self):
        return self._subsSupportEpgContext()[0]

    def openSubsSupport(self):
        """Choose regular SubsSupport first, or SubsSupport Pro second."""
        choices = [("SubsSupport", "regular"), ("SubsSupport Pro", "pro")]
        self.session.openWithCallback(
            self._subtitleSupportChoice, ChoiceBox,
            title="Subtitle support", list=choices
        )

    def _subtitleSupportChoice(self, choice=None):
        if not choice:
            return
        value = choice[1]
        search_title, elapsed_seconds = self._subsSupportEpgContext()
        try:
            if value == "regular":
                from .subtitle_picker_bridge import open_subtitle_search
                if open_subtitle_search(self, search_title, elapsed_seconds=elapsed_seconds):
                    return
                message = "تعذر فتح SubsSupport. تحقق من توافق الإضافة المثبتة."
            else:
                from .subtitle_picker_bridge import open_subtitle_pro
                if open_subtitle_pro(self, search_title, elapsed_seconds=elapsed_seconds):
                    return
                message = "تعذر فتح SubsSupport Pro. تحقق من تثبيت الإضافة وتوافقها."
        except Exception:
            message = "تعذر فتح إضافة الترجمة المحددة."
        self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=6)

    def openSubtitleEditor(self):
        """Open the active SubsSupport subtitle-line picker with RED."""
        try:
            from .subtitle_picker_bridge import open_active_subtitle_picker
            if open_active_subtitle_picker(self, [getattr(self, "_subssupport", None)]):
                return
        except Exception:
            pass
        self.session.open(
            MessageBox,
            "لا توجد ترجمة قابلة للتعديل. حمّل الترجمة وشغّلها أولاً بالزر الأزرق.",
            MessageBox.TYPE_INFO,
            timeout=5
        )

    def _serviceStarted(self):
        # Service notifications preserve playback-first navigation.
        self.showInfobar()

    def nextChannel(self):
        if not self.channels:
            return
        self.index = (self.index + 1) % len(self.channels)
        self.playCurrent()

    def prevChannel(self):
        if not self.channels:
            return
        self.index = (self.index - 1) % len(self.channels)
        self.playCurrent()
    def _scheduleInfobarPoster(self, title):
        self._livePosterToken += 1
        token = self._livePosterToken
        try:
            self._livePosterTimer.stop()
            self._livePosterPoll.stop()
            self["posterFrame"].hide()
            self["livePoster"].hide()
            self["posterStars"].hide()
            self["posterMeta"].hide()
        except Exception:
            pass
        enabled = str(self.source.get("show_live_infobar_poster", "0")).strip().lower() in ("1","true","yes","on","enabled")
        if not enabled:
            return
        clean = re.sub(r"\s*[\-–—:]?\s*[Ss]\d{1,2}[Ee]\d{1,3}.*$", "", str(title or "").strip())
        clean = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", "", clean).strip(" -:|")
        if not clean:
            return
        self._infobarPosterTitle = clean
        try:
            self._livePosterTimer.start(350, True)
        except Exception:
            self._startInfobarPosterLookup()

    def _startInfobarPosterLookup(self):
        title = getattr(self, "_infobarPosterTitle", "")
        token = self._livePosterToken
        if not title:
            return
        def worker():
            url = ""
            rating = 0.0
            year = ""
            try:
                client = TMDbClient()
                result = client.search_artwork(title, "vod", required_key="poster_path") or client.search_artwork(title, "series", required_key="poster_path")
                result = result or {}
                path = result.get("poster_path") or ""
                if path:
                    url = "https://image.tmdb.org/t/p/w342" + path
                try:
                    rating = float(result.get("vote_average") or result.get("rating") or 0.0)
                except Exception:
                    rating = 0.0
                date_value = str(result.get("release_date") or result.get("first_air_date") or "")
                if len(date_value) >= 4 and date_value[:4].isdigit():
                    year = date_value[:4]
            except Exception:
                pass
            self._livePosterResult = (token, url, rating, year)
        t = threading.Thread(target=worker, name="TiviMateInfobarPoster")
        t.daemon = True
        t.start()
        try:
            self._livePosterPoll.start(250, False)
        except Exception:
            pass

    def _finishInfobarPosterLookup(self):
        result = self._livePosterResult
        if result is None:
            try:
                self._livePosterPoll.start(250, False)
            except Exception:
                pass
            return
        self._livePosterResult = None
        token, url, rating, year = result
        if token != self._livePosterToken or not url:
            return
        self._infobarPosterRating = rating
        self._infobarPosterYear = year
        cached = cached_artwork(url, "live_tmdb_poster") if cached_artwork else None
        if cached:
            self._showInfobarPoster(cached, token)
            return
        def ready(path):
            self._showInfobarPoster(path, token)
        request_artwork(url, kind="posters", callback=ready, priority=45)

    def _showInfobarPoster(self, path, token):
        if token != self._livePosterToken or not path or not os.path.exists(path):
            return
        try:
            self._infobarPosterDecodeToken = token
            self._livePosterPic.setPara((150,176,1,1,False,1,"#00000000"))
            self._livePosterPic.startDecode(path)
        except Exception:
            pass

    def _infobarPosterDecoded(self, info=None):
        try:
            if getattr(self, "_infobarPosterDecodeToken", -1) != self._livePosterToken:
                return
            ptr = self._livePosterPic.getData()
            if ptr is None:
                return

            rating = float(getattr(self, "_infobarPosterRating", 0.0) or 0.0)
            year = str(getattr(self, "_infobarPosterYear", "") or "")

            # Five-star display, based on TMDb 10-point rating.
            full = int(round(max(0.0, min(10.0, rating)) / 2.0))
            stars = ("★" * full) + ("☆" * (5 - full))
            rating_text = ("%.1f/10" % rating) if rating > 0 else ""
            meta = "  •  ".join([x for x in (rating_text, year) if x])

            self["livePoster"].instance.setPixmap(ptr)
            self["posterStars"].setText(stars if rating > 0 else "")
            self["posterMeta"].setText(meta)

            self["posterFrame"].show()
            self["livePoster"].show()
            if rating > 0:
                self["posterStars"].show()
            else:
                self["posterStars"].hide()
            if meta:
                self["posterMeta"].show()
            else:
                self["posterMeta"].hide()
        except Exception:
            pass


    def _loadPicon(self, item):
        try:
            self._infobarPiconReqId = int(getattr(self, '_infobarPiconReqId', 0) or 0) + 1
        except Exception:
            self._infobarPiconReqId = 1
        req_id = self._infobarPiconReqId

        blank = os.path.join(os.path.dirname(__file__), 'skins', 'transparent.png')
        try:
            if self['picon'].instance and os.path.exists(blank):
                self['picon'].instance.setPixmapFromFile(blank)
            self['picon'].show()
        except Exception:
            pass

        url = str((item or {}).get('stream_icon') or (item or {}).get('logo') or '').strip().replace('\\/','/')

        def current_id():
            return int(getattr(self, '_infobarPiconReqId', 0) or 0)

        def apply_path(path):
            if req_id != current_id() or not path:
                return
            try:
                if self['picon'].instance:
                    self['picon'].instance.setPixmapFromFile(path)
                    self['picon'].show()
            except Exception:
                pass

        direct_picon(url, (280,168), req_id, current_id, apply_path, prefix='tivimate_infobar_picon_')


    def _piconDecoded(self, info=None):
        return


    def _scheduleEpg(self):
        self._epg_ready = False
        try:
            self._epg_timer.stop()
        except Exception:
            pass
        self["epgNow"].setText(tr(""))
        self["epgNext"].setText(tr(""))
        self["epgProgress"].setValue(0)
        self["epgProgressText"].setText(tr(""))
        try:
            self._epg_timer.start(650, True)
        except TypeError:
            self._epg_timer.start(650)
        except Exception:
            self._delayedEpg()

    def _delayedEpg(self):
        self._epg_ready = True
        self._updateEpg()

    def _stalkerEpgTimestamp(self, value):
        if value in (None,""): return 0
        try:
            if isinstance(value,(int,float)): return int(value)
        except Exception: pass
        raw=str(value or "").strip()
        try: return int(float(raw))
        except Exception: pass
        try: return int(time.mktime(time.strptime(raw[:19],"%Y-%m-%d %H:%M:%S")))
        except Exception: return 0

    def _parseStalkerPlayerEpg(self, rows):
        now=int(time.time()); events=[]
        for row in rows or []:
            if not isinstance(row,dict): continue
            start=self._stalkerEpgTimestamp(row.get("time") or row.get("start_timestamp") or row.get("start") or row.get("begin"))
            stop=self._stalkerEpgTimestamp(row.get("time_to") or row.get("stop_timestamp") or row.get("stop") or row.get("end"))
            if not stop and start and row.get("duration"):
                try: stop=start+int(float(row.get("duration")))
                except Exception: pass
            if start and stop:
                events.append((start,stop,str(row.get("name") or row.get("title") or "").strip(),row))
        events.sort(key=lambda x:x[0])
        for i,event in enumerate(events):
            if event[0] < now < event[1]:
                return event, events[i+1] if i+1<len(events) else None
        if events:
            for i,event in enumerate(events):
                if event[0]>now:
                    return event, events[i+1] if i+1<len(events) else None
            return events[0], events[1] if len(events)>1 else None
        return None,None

    def _startStalkerPlayerEpg(self, item):
        if self.source.get("type")!="stalker": return False
        ch_id=str((item or {}).get("ch_id") or (item or {}).get("stream_id") or (item or {}).get("id") or "").strip()
        if not ch_id: return False
        self._stalker_epg_token += 1
        token=self._stalker_epg_token
        client=self._live_client
        if client is None:
            try:
                client=get_source_client(self.source); self._live_client=client
            except Exception: return False
        def worker():
            try: rows=client.short_epg(ch_id,limit=10,force=False) or []
            except Exception: rows=[]
            self._stalker_epg_result=(token,rows)
        t=threading.Thread(target=worker,name="TiviMatePlayerShortEPG")
        t.daemon=True; t.start()
        try: self._stalker_epg_poll.start(100,True)
        except Exception: pass
        return True

    def _finishStalkerPlayerEpg(self):
        result=self._stalker_epg_result
        if result is None:
            try: self._stalker_epg_poll.start(100,True)
            except Exception: pass
            return
        self._stalker_epg_result=None
        token,rows=result
        if token != self._stalker_epg_token: return
        current,upcoming=self._parseStalkerPlayerEpg(rows)
        if not current:
            self["epgNow"].setText(tr("No EPG data"))
            self["epgNext"].setText(tr(""))
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText(tr(""))
            return
        now=int(time.time()); begin,stop,title,row=current; duration=max(0,stop-begin)
        current_time=str(row.get("t_time") or "").strip()
        self["epgNow"].setText("%s   %s"%(current_time or self._formatEpgClock(begin,duration),title))
        self._scheduleInfobarPoster(title)
        if upcoming:
            ub,us,ut,urow=upcoming; ud=max(0,us-ub)
            nt=str(urow.get("t_time") or "").strip()
            self["epgNext"].setText("%s   %s"%(nt or self._formatEpgClock(ub,ud),ut))
        else: self["epgNext"].setText(tr(""))
        elapsed=max(0,now-begin)
        percent=min(100,max(0,int((elapsed*100)/duration))) if duration>0 else 0
        elapsed_min=int(elapsed/60); total_min=int((duration+59)/60) if duration else 0
        self["epgProgress"].setValue(percent)
        if total_min>0:
            self["epgProgressText"].setText("%d / %d min  •  %d%%"%(elapsed_min,total_min,percent))
            try:
                self["epgProgress"].show(); self["epgProgressText"].show()
            except Exception: pass

    def _formatEpgClock(self, begin, duration):
        try:
            end = int(begin) + int(duration or 0)
            return "%s–%s" % (time.strftime("%H:%M", time.localtime(int(begin))), time.strftime("%H:%M", time.localtime(end)))
        except Exception:
            return ""

    def _updateEpg(self, item=None):
        item = item or self._current()
        try:
            current, upcoming = lookup_channel_epg(self.source, item, int(time.time()))
        except Exception:
            current, upcoming = None, None
        if not current:
            if self.source.get("type") == "stalker" and self._startStalkerPlayerEpg(item):
                self["epgNow"].setText(tr("Loading EPG..."))
                self["epgNext"].setText(tr(""))
                self["epgProgress"].setValue(0)
                self["epgProgressText"].setText(tr(""))
                return
            self["epgNow"].setText(tr("No EPG data"))
            self["epgNext"].setText(tr(""))
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText(tr(""))
            return
        begin, duration, title, desc = current
        now = int(time.time())
        elapsed = max(0, now - int(begin))
        total = max(0, int(duration or 0))
        percent = min(100, max(0, int((elapsed * 100) / total))) if total > 0 else 0
        remaining = max(0, int(begin) + total - now)
        remaining_min = int((remaining + 59) / 60)
        elapsed_min = int(elapsed / 60)
        total_min = int((total + 59) / 60) if total else 0
        self["epgNow"].setText("%s   %s" % (self._formatEpgClock(begin, duration), title or ""))
        self._scheduleInfobarPoster(title)
        if upcoming:
            ub, ud, ut, _ux = upcoming
            self["epgNext"].setText("%s   %s" % (self._formatEpgClock(ub, ud), ut or ""))
        else:
            self["epgNext"].setText(tr(""))
        self["epgProgress"].setValue(percent)
        if total_min > 0:
            self["epgProgressText"].setText("%d / %d min  •  %d%%" % (elapsed_min, total_min, percent))
            try:
                self["epgProgress"].show()
                self["epgProgressText"].show()
            except Exception:
                pass
        else:
            self["epgProgressText"].setText(tr(""))
            try:
                self["epgProgress"].hide()
                self["epgProgressText"].hide()
            except Exception:
                pass

    def _updateClock(self):
        try:
            self["clock"].setText(time.strftime("%H:%M  %d/%m/%Y"))
            if self._epg_ready:
                self._updateEpg()
        except Exception:
            pass

    def back(self):
        item = self._current() or {}
        live_id = str(
            item.get("stream_id") or item.get("ch_id") or item.get("id") or
            item.get("url") or item.get("cmd") or item.get("name") or ""
        ).strip()
        self.close((self.index, live_id))

    def _cleanup(self):
        self._liveResolveToken += 1
        self._liveResolveResult = None
        try:
            self._liveResolveTimer.stop()
        except Exception:
            pass
        self._clearSubsSupport()
        try:
            self._clock_timer.stop()
            self._epg_timer.stop()
            try:
                self._stalker_epg_poll.stop()
                self._stalker_epg_token += 1
            except Exception:
                pass
            self._engine_timer.stop()
            self._watchdog_timer.stop()
            try:
                self._catchup_timer.stop()
            except Exception:
                pass
            self._ib_timer.stop()
        except Exception:
            pass
        # Do not restore the DVB service when closing only the full-screen
        # Live player. The IPTV service must continue while browsing channels
        # and packages. MediaScreen restores the original receiver service only
        # when the user finally exits the Live section.


# Resolve the native FHD/WQHD layout only after the full player class exists.
TiviMateLivePlayer.skin = scale_skin(TiviMateLivePlayer.skin)
