# -*- coding: utf-8 -*-
from .storage import get_data_root, data_path, get_playlists_file
from .compat import atomic_replace, ensure_dir, open_text
import os, json, hashlib, re, ssl, time, threading, socket, gzip, io, random, string, gc
from urllib.request import Request, urlopen
from urllib.parse import urlencode, urlparse, parse_qs, quote, parse_qsl, urlunparse
from collections import OrderedDict

try:
    import requests
    try:
        from requests.adapters import HTTPAdapter
    except Exception:
        HTTPAdapter = None
except Exception:
    requests = None
    HTTPAdapter = None

BASE = get_data_root()
SOURCES_FILE = data_path("sources.json")
PLAYLISTS_FILE = get_playlists_file()
LEGACY_TIVIMATE_PLAYLISTS_FILE = "/etc/enigma2/tivimate/playlists.txt"
from .cache_manager import get_cache_root, get_cache_dir, get_log_path, stable_cache_key, persistent_cache_get, persistent_cache_set, persistent_cache_peek
from .resource_guard import stalker_request_slot
CACHE = get_cache_root()
UA = "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/0.3"

# One bounded network policy and one generic catalog cache are used for every
# supported source.  Cache keys are derived from the configured source only;
# no service receives source-specific performance settings.
NETWORK_TIMEOUT = 10
CATALOG_CACHE_TTL = 24 * 60 * 60
_CATALOG_MEMORY = OrderedDict()
_CATALOG_REFRESHING = set()
_CATALOG_LOCK = threading.RLock()
_STALKER_TOKENS = OrderedDict()
_STALKER_TOKEN_TTL = 25 * 60
_STALKER_EPG_CACHE = OrderedDict()
_STALKER_EPG_TTL = 10 * 60
_XTREAM_EPG_CACHE = OrderedDict()
_XTREAM_EPG_TTL = 10 * 60
_STALKER_CATEGORY_TTL = 6 * 60 * 60
_STALKER_CHANNEL_TTL = 30 * 60
_STALKER_PAGE_TTL = 30 * 60
STALKER_STREAM_TTL = _STALKER_PAGE_TTL
_STALKER_SERIES_INFO_TTL = 6 * 60 * 60
_STALKER_VOD_INFO_TTL = 60 * 60

# Bounded runtime caches: keep frequently used Stalker data in RAM without
# allowing long Enigma2 sessions to grow indefinitely. Persistent copies stay
# on HDD/USB and can be reloaded after eviction.
_CATALOG_MEMORY_LIMIT = 24
_STALKER_TOKEN_LIMIT = 8
_STALKER_EPG_MEMORY_LIMIT = 160
_XTREAM_EPG_MEMORY_LIMIT = 160
_STALKER_LIVE_MEMORY_LIMIT = 96
_STALKER_LIVE_MEMORY = OrderedDict()
_STALKER_REFRESHING = set()
_STALKER_PREFETCH_AT = {}
_STALKER_CREATE_LINK_CACHE = OrderedDict()
_STALKER_CREATE_LINK_LIMIT = 96
_STALKER_CREATE_LINK_TTL = 45
_STALKER_CAPABILITY_TTL = 24 * 60 * 60
_STALKER_STALE_WINDOW = 24 * 60 * 60
_STALKER_BACKOFF = {}
_STALKER_HEALTH = {}


class StalkerCancelledError(RuntimeError):
    pass


def classify_stalker_error(value):
    """Return a short stable category/message for UI diagnostics."""
    text = str(value or "").strip()
    low = text.lower()
    if isinstance(value, StalkerCancelledError) or "cancelled" in low or "canceled" in low:
        return "cancelled", "Request cancelled"
    if "timed out" in low or "timeout" in low:
        return "timeout", "Portal request timed out"
    if "name or service not known" in low or "temporary failure in name resolution" in low or "dns" in low:
        return "dns", "Portal hostname could not be resolved"
    if "connection refused" in low:
        return "connection", "Portal refused the connection"
    if "network is unreachable" in low or "no route to host" in low:
        return "network", "Portal network is unreachable"
    if "unauthorized" in low or "not authorized" in low or "access denied" in low or "invalid token" in low or "token expired" in low:
        return "auth", "Portal authentication failed"
    if "429" in low or "rate limit" in low or "too many requests" in low:
        return "rate_limit", "Portal is rate limiting requests"
    if "invalid response" in low or "complete json" in low:
        return "response", "Portal returned an invalid response"
    return "portal", text or "Portal request failed"


def _raise_if_stalker_cancelled(cancel_event):
    if cancel_event is not None:
        try:
            if cancel_event.is_set():
                raise StalkerCancelledError("Stalker request cancelled")
        except AttributeError:
            pass
_RUNTIME_GC_LAST = 0.0
_RUNTIME_GC_INTERVAL = 120.0

def _lru_get(mapping, key):
    try:
        value = mapping.pop(key)
    except Exception:
        return None
    mapping[key] = value
    return value

def _lru_put(mapping, key, value, limit):
    try:
        mapping.pop(key, None)
        mapping[key] = value
        while len(mapping) > max(1, int(limit)):
            mapping.popitem(last=False)
    except Exception:
        pass
    return value

def runtime_memory_cleanup(force_gc=False):
    """Bound TiviMateE2-owned RAM caches and collect cyclic garbage sparingly.

    This never drops Linux page cache and never touches other Enigma2 plugins.
    """
    global _RUNTIME_GC_LAST
    now = time.time()
    with _CATALOG_LOCK:
        # Expire stale Stalker session tokens.
        for key, value in list(_STALKER_TOKENS.items()):
            try:
                if not value or now - float(value[1]) >= _STALKER_TOKEN_TTL:
                    _STALKER_TOKENS.pop(key, None)
            except Exception:
                _STALKER_TOKENS.pop(key, None)
        while len(_STALKER_TOKENS) > _STALKER_TOKEN_LIMIT:
            _STALKER_TOKENS.popitem(last=False)

        # EPG rows are short-lived and can become the biggest Python object set.
        for key, value in list(_STALKER_EPG_CACHE.items()):
            try:
                if not value or now - float(value[0]) >= _STALKER_EPG_TTL:
                    _STALKER_EPG_CACHE.pop(key, None)
            except Exception:
                _STALKER_EPG_CACHE.pop(key, None)
        while len(_STALKER_EPG_CACHE) > _STALKER_EPG_MEMORY_LIMIT:
            _STALKER_EPG_CACHE.popitem(last=False)

        # Xtream short EPG mirrors the same 10-minute bounded RAM policy.
        for key, value in list(_XTREAM_EPG_CACHE.items()):
            try:
                if not value or now - float(value[0]) >= _XTREAM_EPG_TTL:
                    _XTREAM_EPG_CACHE.pop(key, None)
            except Exception:
                _XTREAM_EPG_CACHE.pop(key, None)
        while len(_XTREAM_EPG_CACHE) > _XTREAM_EPG_MEMORY_LIMIT:
            _XTREAM_EPG_CACHE.popitem(last=False)

        while len(_STALKER_LIVE_MEMORY) > _STALKER_LIVE_MEMORY_LIMIT:
            _STALKER_LIVE_MEMORY.popitem(last=False)
        while len(_CATALOG_MEMORY) > _CATALOG_MEMORY_LIMIT:
            _CATALOG_MEMORY.popitem(last=False)

    if force_gc or now - _RUNTIME_GC_LAST >= _RUNTIME_GC_INTERVAL:
        try:
            gc.collect()
        except Exception:
            pass
        _RUNTIME_GC_LAST = now
STALKER_COMPAT_FILE = os.path.join(BASE, "stalker_compat.json")
STALKER_MAG_MODELS = ("MAG250", "MAG254", "MAG322")

STALKER_LOG = get_log_path("tivimatee2_stalker.log")

def stalker_log(message):
    """Write a bounded diagnostic log without exposing full tokens or MAC data."""
    try:
        if os.path.exists(STALKER_LOG) and os.path.getsize(STALKER_LOG) > 512 * 1024:
            try:
                os.rename(STALKER_LOG, STALKER_LOG + ".1")
            except Exception:
                pass
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(STALKER_LOG, "a") as handle:
            handle.write("[%s] %s\n" % (stamp, str(message)))
    except Exception:
        pass



def _stalker_compat_key(portal, mac):
    return "%s|%s" % ((portal or "").rstrip("/"), (mac or "").upper())

def load_stalker_compat(portal, mac):
    data = load_json(STALKER_COMPAT_FILE, {}) or {}
    row = data.get(_stalker_compat_key(portal, mac), {})
    return dict(row) if isinstance(row, dict) else {}

def save_stalker_compat(source_portal, mac, **values):
    data = load_json(STALKER_COMPAT_FILE, {}) or {}
    key = _stalker_compat_key(source_portal, mac)
    row = data.get(key, {})
    if not isinstance(row, dict):
        row = {}
    for name, value in values.items():
        if value in (None, ""):
            row.pop(name, None)
        else:
            row[name] = value
    data[key] = row
    save_json(STALKER_COMPAT_FILE, data)
    return row


def get_stalker_account_state(source):
    """Return the last known Stalker account state without making a network call.

    This is the single display-state source for Settings and server menus.
    Authentication/playback continues to be owned by StalkerClient unchanged.
    """
    source = source or {}
    portal = str(source.get("url") or source.get("portal") or "").strip()
    mac = str(source.get("mac") or "").strip().upper()
    compat = load_stalker_compat(portal, mac) if portal and mac else {}

    expiry = str(compat.get("expiry") or source.get("_last_expiry") or "").strip()
    blocked = str(compat.get("blocked") or source.get("_last_blocked") or "0").strip()
    status = compat.get("status")
    if status in (None, ""):
        status = source.get("_last_status")
    status = str(status or "").strip()

    valid = bool(compat)
    if blocked == "1":
        valid = False
    if str(source.get("_last_status") or "").lower() == "offline":
        valid = False

    return {
        "expiry": expiry,
        "blocked": blocked,
        "status": status,
        "valid": valid,
        "portal": str(compat.get("portal") or portal or ""),
        "path_prefix": str(compat.get("path_prefix") or ""),
        "portal_version": str(compat.get("portal_version") or ""),
        "endpoint": str(compat.get("endpoint") or ""),
        "play_token": str(compat.get("play_token") or ""),
    }

def _mask_mac(mac):
    value = str(mac or "")
    return value[:8] + ":XX:XX:XX" if len(value) >= 8 else "hidden"

def _mask_token(token):
    value = str(token or "")
    if not value:
        return "none"
    return value[:6] + "..." + value[-4:] if len(value) > 12 else "present"


for p in (BASE, CACHE, get_cache_dir("posters"), get_cache_dir("backdrops"), get_cache_dir("logos")):
    try: ensure_dir(p)
    except Exception: pass


# ---------------------------------------------------------------------------
# Source persistence and identity helpers
# ---------------------------------------------------------------------------

def load_json(path, default):
    try:
        with open_text(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return default


def save_json(path, data):
    try:
        ensure_dir(os.path.dirname(path))
    except Exception:
        pass

    tmp = path + ".tmp"
    payload = json.dumps(data, ensure_ascii=False, indent=2)
    if not isinstance(payload, str):
        payload = str(payload)
    with open_text(tmp, "w", encoding="utf-8") as handle:
        handle.write(payload)
    atomic_replace(tmp, path)


def _source_endpoint(source, trim=False):
    """Return the configured endpoint with optional surrounding-space cleanup."""
    endpoint = source.get("url", "") or source.get("path", "")
    endpoint = str(endpoint)
    if trim:
        endpoint = endpoint.strip()
    return endpoint.rstrip("/")


def _source_key(source):
    """Runtime identity kept byte-for-byte compatible with previous behavior."""
    return "%s|%s|%s|%s" % (
        source.get("type", ""),
        _source_endpoint(source),
        source.get("username", ""),
        source.get("mac", ""),
    )


def _persistent_source_key(source):
    """Stable storage identity used before writing sources.json.

    Xtream includes the password so two accounts that share a host and
    username but use different credentials are never collapsed together.
    """
    source = source or {}
    stype = str(source.get("type") or "").lower()
    endpoint = _source_endpoint(source, trim=True).lower()

    if stype == "xtream":
        return (
            "xtream",
            endpoint,
            str(source.get("username") or ""),
            str(source.get("password") or ""),
        )

    return (
        stype,
        endpoint,
        str(source.get("username") or ""),
        str(source.get("password") or ""),
        str(source.get("mac") or "").upper(),
    )


def _normalise_stalker_source(name, portal, mac):
    """Create one local Stalker source from a compact playlist record."""
    portal = (portal or "").strip().rstrip("/")
    mac = (mac or "").strip().upper().replace("-", ":")
    if portal and "://" not in portal:
        portal = "http://" + portal
    parts = mac.split(":")
    try:
        valid_mac = len(parts) == 6 and all(len(part) == 2 and int(part, 16) >= 0 for part in parts)
    except Exception:
        valid_mac = False
    if not portal.startswith(("http://", "https://")) or not valid_mac:
        return None
    return {
        "type": "stalker",
        "name": (name or "Stalker Portal").strip() or "Stalker Portal",
        "url": portal,
        "mac": mac,
    }


def _parse_stalker_playlist_line(line, name):
    """Accept explicit STALKER records and the compact Portal/c/MAC shorthand."""
    raw = (line or "").strip()
    parts = [part.strip() for part in raw.split("|")]
    if parts and parts[0].upper() == "STALKER":
        if len(parts) == 4:
            # Prefer STALKER|Name|Portal URL|MAG MAC.  Also allow URL first.
            if parts[1].lower().startswith(("http://", "https://")):
                return _normalise_stalker_source(parts[3] or name, parts[1], parts[2])
            return _normalise_stalker_source(parts[1] or name, parts[2], parts[3])
        if len(parts) == 3:
            return _normalise_stalker_source(name, parts[1], parts[2])
        return None
    # Easy one-line form: http://SERVER:PORT/stalker_portal/c/00:1A:79:AA:BB:CC # Name
    match = re.match(r"^(https?://.+?/c/)([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})/?$", raw)
    if match:
        return _normalise_stalker_source(name, match.group(1), match.group(2))
    return None


def parse_playlist_line(raw):
    line = (raw or "").strip()
    if not line or line.startswith("#"):
        return None
    name = "IPTV"
    if " #" in line:
        line, name = line.rsplit(" #", 1)
        name = name.strip() or "IPTV"
    elif "|" in line and line.lower().startswith(("http://", "https://")):
        # Accept: URL | Name for ordinary M3U lines.
        parts = line.rsplit("|", 1)
        if len(parts) == 2:
            line, name = parts[0].strip(), parts[1].strip() or "IPTV"
    fg_parts = [part.strip() for part in line.split("|")]
    if fg_parts and fg_parts[0].upper() == "FG":
        if len(fg_parts) >= 3:
            return {"type": "fg", "name": fg_parts[1] or name or "FG Code", "url": _normalise_fg_url(fg_parts[2]), "code": fg_parts[2]}
        if len(fg_parts) == 2:
            return {"type": "fg", "name": name or "FG Code", "url": _normalise_fg_url(fg_parts[1]), "code": fg_parts[1]}
    stalker = _parse_stalker_playlist_line(line, name)
    if stalker:
        return stalker
    try:
        u = urlparse(line.strip())
        qs = parse_qs(u.query)
        username = (qs.get("username") or [""])[0]
        password = (qs.get("password") or [""])[0]
        if username and password:
            base = "%s://%s" % (u.scheme or "http", u.netloc)
            output = (qs.get("output") or ["ts"])[0]
            return {"type":"xtream", "name":name, "url":base.rstrip("/"), "username":username, "password":password, "output":output}
        if u.scheme in ("http","https"):
            return {"type":"m3u", "name":name, "url":line.strip()}
    except Exception:
        pass
    return None


def import_playlists(paths=None):
    paths = paths or (PLAYLISTS_FILE, LEGACY_TIVIMATE_PLAYLISTS_FILE)
    found = []
    for path in paths:
        try:
            with open_text(path, "r", encoding="utf-8", errors="ignore") as f:
                for raw in f:
                    s = parse_playlist_line(raw)
                    if s: found.append(s)
        except Exception:
            pass
    return found


def _valid_stalker_mac(value):
    raw = str(value or "").strip().upper()
    parts = raw.split(":")
    if len(parts) != 6:
        return False
    try:
        return all(len(part) == 2 and all(ch in "0123456789ABCDEF" for ch in part) for part in parts)
    except Exception:
        return False


def _normalise_stalker_portal_url(value):
    value = str(value or "").strip().rstrip("/")
    if value and "://" not in value:
        value = "http://" + value
    return value


def _stalker_mac_entries(source):
    """Return de-duplicated [{mac, alias}] entries from old or grouped storage."""
    source = source or {}
    entries = []
    seen = set()

    raw_entries = source.get("macs")
    if isinstance(raw_entries, list):
        for row in raw_entries:
            if isinstance(row, dict):
                mac = str(row.get("mac") or "").strip().upper()
                alias = str(row.get("alias") or "").strip()
            else:
                mac = str(row or "").strip().upper()
                alias = ""
            if _valid_stalker_mac(mac) and mac not in seen:
                seen.add(mac)
                entries.append({"mac": mac, "alias": alias})

    legacy_mac = str(source.get("mac") or "").strip().upper()
    if _valid_stalker_mac(legacy_mac) and legacy_mac not in seen:
        seen.add(legacy_mac)
        entries.append({"mac": legacy_mac, "alias": str(source.get("mac_alias") or source.get("alias") or "").strip()})

    return entries


def _compact_sources_for_storage(sources):
    """Group Stalker MACs by portal and de-duplicate persistent non-Stalker sources."""
    out = []
    groups = {}
    order = []
    seen_nonstalker = set()

    for raw in list(sources or []):
        if not isinstance(raw, dict):
            continue
        source = dict(raw)
        stype = str(source.get("type") or "").lower()

        if stype != "stalker":
            key = _persistent_source_key(source)
            if key in seen_nonstalker:
                continue
            seen_nonstalker.add(key)
            out.append(source)
            continue

        url = _normalise_stalker_portal_url(source.get("url") or source.get("portal"))
        if not url:
            continue

        entries = _stalker_mac_entries(source)
        if not entries:
            continue

        key = url.lower()
        if key not in groups:
            base = dict(source)
            base["type"] = "stalker"
            base["url"] = url
            base.pop("mac", None)
            base.pop("mac_alias", None)
            base.pop("alias", None)
            base["macs"] = []
            groups[key] = base
            order.append(key)

        group = groups[key]
        existing = set(row.get("mac") for row in group.get("macs", []) if isinstance(row, dict))
        for entry in entries:
            if entry["mac"] not in existing:
                group["macs"].append(dict(entry))
                existing.add(entry["mac"])
            elif entry.get("alias"):
                for row in group["macs"]:
                    if row.get("mac") == entry["mac"] and not row.get("alias"):
                        row["alias"] = entry["alias"]

    for key in order:
        group = groups[key]
        if group.get("macs"):
            out.append(group)
    return out


def _expand_sources_for_runtime(sources):
    """Expand grouped Stalker portal storage into one runtime source per MAC."""
    out = []
    for raw in list(sources or []):
        if not isinstance(raw, dict):
            continue
        source = dict(raw)
        if str(source.get("type") or "").lower() != "stalker":
            out.append(source)
            continue

        url = _normalise_stalker_portal_url(source.get("url") or source.get("portal"))
        if not url:
            continue
        entries = _stalker_mac_entries(source)
        if not entries:
            continue

        base_name = str(source.get("name") or "Stalker Portal").strip() or "Stalker Portal"
        for entry in entries:
            item = dict(source)
            item["url"] = url
            item["mac"] = entry["mac"]
            item["mac_alias"] = entry.get("alias") or ""
            item["_portal_group_name"] = base_name
            item["_portal_group_url"] = url
            item.pop("macs", None)
            if entry.get("alias"):
                item["name"] = "%s • %s" % (base_name, entry["alias"])
            else:
                item["name"] = base_name
            out.append(item)
    return out


def get_sources():
    stored = load_json(SOURCES_FILE, [])
    imported = import_playlists()
    compact = _compact_sources_for_storage(list(stored or []) + list(imported or []))

    # Persist migration/cleanup automatically. This removes malformed Stalker
    # entries and de-duplicates MACs under the same portal.
    try:
        if compact != stored:
            save_json(SOURCES_FILE, compact)
    except Exception:
        pass

    runtime = _expand_sources_for_runtime(compact)
    merged = []
    seen = set()
    for s in runtime:
        if s.get("type") == "fg" or s.get("drama_import") or s.get("drama_fg_experimental"):
            continue
        k = _source_key(s)
        if k not in seen:
            seen.add(k)
            merged.append(s)
    return merged


def set_sources(v):
    compact = _compact_sources_for_storage(v)
    save_json(SOURCES_FILE, compact)
    # r448: EPGImport files are no longer generated/synchronised.
    # Internal Xtream EPG refresh is handled by epg_local on session start
    # and by the existing package/filter refresh path.


def xtream_to_playlist_line(src):
    base = src.get("url","").rstrip("/")
    output = src.get("output") or "ts"
    q = urlencode({"username":src.get("username",""), "password":src.get("password",""), "type":"m3u_plus", "output":output})
    return "%s/get.php?%s # %s" % (base, q, src.get("name") or "IPTV")


def write_playlists(sources):
    try:
        ensure_dir(BASE)
    except Exception:
        pass

    compact = _compact_sources_for_storage(sources)
    lines = []
    for s in compact:
        if s.get("type") == "xtream":
            lines.append(xtream_to_playlist_line(s))
        elif s.get("type") == "m3u" and s.get("url"):
            lines.append("%s # %s" % (s.get("url"), s.get("name") or "M3U"))
        elif s.get("type") == "stalker" and s.get("url"):
            pname = (s.get("name") or "Stalker Portal").replace("|", " ")
            for entry in _stalker_mac_entries(s):
                alias = str(entry.get("alias") or "").replace("|", " ").strip()
                display = ("%s [%s]" % (pname, alias)) if alias else pname
                lines.append("STALKER|%s|%s|%s" % (
                    display,
                    s.get("url").rstrip("/") + "/",
                    entry.get("mac")
                ))
    with open_text(PLAYLISTS_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + ("\n" if lines else ""))



# ---------------------------------------------------------------------------
# Shared HTTP and catalog cache
# ---------------------------------------------------------------------------

def fetch(url, headers=None, timeout=NETWORK_TIMEOUT, as_json=False):
    h = {"User-Agent": UA, "Accept": "*/*"}
    if headers: h.update(headers)
    req = Request(url, headers=h)
    try:
        ctx = ssl._create_unverified_context()
    except Exception:
        ctx = None
    try:
        if ctx is not None:
            response = urlopen(req, timeout=timeout, context=ctx)
        else:
            response = urlopen(req, timeout=timeout)
    except TypeError:
        response = urlopen(req, timeout=timeout)
    try:
        data = response.read()
    finally:
        try:
            response.close()
        except Exception:
            pass
    return json.loads(data.decode("utf-8", "replace")) if as_json else data



def _catalog_key(source, bucket):
    return "%s|catalog|%s" % (_source_key(source or {}), str(bucket or "default"))


def _catalog_path(source, bucket):
    digest = hashlib.md5(_catalog_key(source, bucket).encode("utf-8")).hexdigest()
    return os.path.join(get_cache_dir("source_catalog"), digest + ".json")


def _catalog_load(path):
    try:
        age = max(0, time.time() - os.path.getmtime(path))
        with open_text(path, "r", encoding="utf-8") as handle:
            rows = json.load(handle)
        return (list(rows), age) if isinstance(rows, list) else (None, None)
    except Exception:
        return None, None


def _catalog_save(path, rows):
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = path + ".tmp"
        with open_text(tmp, "w", encoding="utf-8") as handle:
            json.dump(list(rows or []), handle, ensure_ascii=False)
        atomic_replace(tmp, path)
    except Exception:
        pass


def _catalog_put(key, path, rows):
    safe_rows = list(rows or [])
    with _CATALOG_LOCK:
        _lru_put(_CATALOG_MEMORY, key, (safe_rows, time.time()), _CATALOG_MEMORY_LIMIT)
    _catalog_save(path, safe_rows)
    return safe_rows


def _refresh_catalog(source, bucket, loader):
    # Refresh a catalog once in the background without delaying a visible page.
    source = dict(source or {})
    key = _catalog_key(source, bucket)
    with _CATALOG_LOCK:
        if key in _CATALOG_REFRESHING:
            return
        _CATALOG_REFRESHING.add(key)

    def worker():
        try:
            rows = list(loader() or [])
            _catalog_put(key, _catalog_path(source, bucket), rows)
        except Exception:
            pass
        finally:
            with _CATALOG_LOCK:
                _CATALOG_REFRESHING.discard(key)

    thread = threading.Thread(target=worker, name="TiviMateCatalogRefresh")
    thread.daemon = True
    thread.start()


def get_cached_catalog(source, bucket, loader, wait_for_server=False):
    # Return RAM/disk catalog data before network data for every source type.
    # The loader is evaluated only in a worker when wait_for_server is true;
    # stale rows remain usable while one daemon refreshes them.
    source = dict(source or {})
    key = _catalog_key(source, bucket)
    path = _catalog_path(source, bucket)
    now = time.time()
    with _CATALOG_LOCK:
        memory = _lru_get(_CATALOG_MEMORY, key)
    if memory is not None:
        rows, loaded_at = memory
        if now - loaded_at > CATALOG_CACHE_TTL:
            _refresh_catalog(source, bucket, loader)
            return list(rows or []), "stale"
        return list(rows or []), "ram"

    rows, age = _catalog_load(path)
    if rows is not None:
        with _CATALOG_LOCK:
            _lru_put(_CATALOG_MEMORY, key, (list(rows), now - float(age or 0)), _CATALOG_MEMORY_LIMIT)
        if age is not None and age > CATALOG_CACHE_TTL:
            _refresh_catalog(source, bucket, loader)
            return list(rows), "stale"
        return list(rows), "disk"

    if wait_for_server:
        rows = list(loader() or [])
        return _catalog_put(key, path, rows), "server"

    _refresh_catalog(source, bucket, loader)
    return [], "loading"


def clear_catalog_memory():
    # Forget only TiviMateE2-owned runtime caches; persistent HDD cache remains.
    with _CATALOG_LOCK:
        _CATALOG_MEMORY.clear()
        _CATALOG_REFRESHING.clear()
        _STALKER_EPG_CACHE.clear()
        _STALKER_LIVE_MEMORY.clear()
    runtime_memory_cleanup(force_gc=True)


def cached_image(url, kind="posters"):
    """Return an already-cached artwork file only.

    r88 keeps this helper read-only for callers that only need a local path.
    Screen artwork misses are handled separately by the bounded background queue,
    so DNS, HTTP, and conversion never execute on the Enigma2 GUI thread.
    """
    if not url:
        return ""
    ext = ".png" if ".png" in url.lower() else ".jpg"
    path = os.path.join(get_cache_dir(kind), hashlib.md5(url.encode("utf-8")).hexdigest() + ext)
    try:
        if os.path.exists(path) and os.path.getsize(path) >= 100:
            return path
    except Exception:
        pass
    return ""



def _stalker_local_timezone():
    for path in ("/etc/timezone", "/etc/TZ"):
        try:
            with open(path, "r") as handle:
                value = handle.read().strip()
            if value:
                return value
        except Exception:
            pass
    try:
        value = os.environ.get("TZ", "").strip()
        if value:
            return value
    except Exception:
        pass
    try:
        value = time.tzname[0] if time.tzname else ""
        if value:
            return value
    except Exception:
        pass
    return "GMT"


# ---------------------------------------------------------------------------
# Xtream client
# ---------------------------------------------------------------------------

class XtreamClient:
    def __init__(self, src):
        self.source = dict(src or {})
        self.base = self.source.get("url", "").rstrip("/")
        self.user = self.source.get("username", "")
        self.password = self.source.get("password", "")
        output = str(
            self.source.get("output") or
            self.source.get("stream_format") or
            self.source.get("format") or
            "ts"
        ).strip().lower().lstrip(".")
        self.output = output if output in ("ts", "m3u8") else "ts"
    def api(self, action=None, **params):
        q={"username":self.user,"password":self.password}
        if action:q["action"]=action
        q.update(params)
        return fetch(self.base+"/player_api.php?"+urlencode(q), as_json=True)
    def test(self): return self.api()
    def categories(self, kind): return self.api({"live":"get_live_categories","vod":"get_vod_categories","series":"get_series_categories"}[kind])
    def streams(self, kind, category_id=""):
        action={"live":"get_live_streams","vod":"get_vod_streams","series":"get_series"}[kind]
        return self.api(action, category_id=category_id) if category_id else self.api(action)
    def _epg_cache_key(self, ch_id, epg_channel_id, limit):
        return stable_cache_key(
            "xtream:short_epg", self.base, self.user, self.password,
            str(ch_id or ""), str(epg_channel_id or ""), int(limit or 10)
        )

    def _epg_listings(self, payload):
        if isinstance(payload, dict):
            rows = (
                payload.get("epg_listings") or payload.get("listings") or
                payload.get("epg") or payload.get("data") or []
            )
        elif isinstance(payload, list):
            rows = payload
        else:
            rows = []
        return [dict(row) for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []

    def short_epg(self, ch_id, limit=10, epg_channel_id="", force=False):
        """Xtream provider EPG with Stalker-style RAM -> HDD -> API flow.

        Empty/error responses never overwrite a valid cached result.  The
        provider compatibility fallbacks remain stream_id, epg_channel_id,
        then channel_id.
        """
        stream_id = str(ch_id or "").strip()
        epg_id = str(epg_channel_id or "").strip()
        if not stream_id and not epg_id:
            return []
        try:
            limit = max(1, min(20, int(limit or 10)))
        except Exception:
            limit = 10
        cache_key = self._epg_cache_key(stream_id, epg_id, limit)
        if not force:
            with _CATALOG_LOCK:
                cached = _lru_get(_XTREAM_EPG_CACHE, cache_key)
            if cached and time.time() - float(cached[0]) < _XTREAM_EPG_TTL:
                return [dict(row) for row in (cached[1] or [])]
            disk_rows = persistent_cache_get(cache_key, None)
            if isinstance(disk_rows, list) and disk_rows:
                clean = [dict(row) for row in disk_rows if isinstance(row, dict)]
                if clean:
                    with _CATALOG_LOCK:
                        _lru_put(_XTREAM_EPG_CACHE, cache_key, (time.time(), clean), _XTREAM_EPG_MEMORY_LIMIT)
                    return [dict(row) for row in clean]

        last_rows = []
        for attempt in range(3):
            rows = []
            if stream_id:
                try:
                    rows = self._epg_listings(self.api("get_short_epg", stream_id=stream_id, limit=limit))
                except Exception:
                    rows = []
            if not rows and epg_id:
                for key in ("epg_channel_id", "channel_id"):
                    try:
                        rows = self._epg_listings(self.api("get_short_epg", **{key: epg_id, "limit": limit}))
                    except Exception:
                        rows = []
                    if rows:
                        break
            if rows:
                clean = [dict(row) for row in rows if isinstance(row, dict)]
                with _CATALOG_LOCK:
                    _lru_put(_XTREAM_EPG_CACHE, cache_key, (time.time(), clean), _XTREAM_EPG_MEMORY_LIMIT)
                persistent_cache_set(cache_key, "xtream:short_epg", clean, _XTREAM_EPG_TTL)
                return [dict(row) for row in clean]
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
        return last_rows

    def short_epg_batch(self, channel_specs, limit=10, done_callback=None, partial_callback=None):
        """Fetch visible Xtream EPG with the same two-worker pattern as Stalker."""
        specs = []
        seen = set()
        for value in (channel_specs or []):
            if isinstance(value, dict):
                ch_id = str(value.get("ch_id") or value.get("stream_id") or value.get("id") or value.get("channel_id") or "").strip()
                epg_id = str(value.get("epg_channel_id") or value.get("tvg_id") or value.get("epg_id") or "").strip()
            elif isinstance(value, (tuple, list)):
                ch_id = str(value[0] if value else "").strip()
                epg_id = str(value[1] if len(value) > 1 else "").strip()
            else:
                ch_id = str(value or "").strip(); epg_id = ""
            identity = (ch_id, epg_id)
            if (ch_id or epg_id) and identity not in seen:
                seen.add(identity); specs.append((ch_id, epg_id))
        state = {"rows": [], "failed": set()}
        if not specs:
            payload = {"js": [], "failed_ids": []}
            if done_callback:
                try: done_callback(payload)
                except Exception: pass
            return payload
        lock = threading.RLock(); sem = threading.BoundedSemaphore(2)
        def fetch_one(ch_id, epg_id, force=False):
            with sem:
                try: rows = self.short_epg(ch_id, limit=limit, epg_channel_id=epg_id, force=force) or []
                except Exception: rows = []
            identity = (ch_id, epg_id)
            with lock:
                if rows:
                    state["rows"].extend(rows); state["failed"].discard(identity)
                else:
                    state["failed"].add(identity)
            if rows and partial_callback:
                try: partial_callback({"js": [dict(row) for row in rows], "ch_id": ch_id, "epg_channel_id": epg_id})
                except Exception: pass
        threads = []
        for ch_id, epg_id in specs:
            t = threading.Thread(target=fetch_one, args=(ch_id, epg_id, False), name="TiviMateXtreamShortEPG")
            t.daemon = True; t.start(); threads.append(t)
        def waiter():
            for t in threads:
                try: t.join(22.0)
                except Exception: pass
            with lock: retry = list(state["failed"])
            if retry:
                time.sleep(0.6)
                rthreads = []
                for ch_id, epg_id in retry:
                    t = threading.Thread(target=fetch_one, args=(ch_id, epg_id, True), name="TiviMateXtreamShortEPGRetry")
                    t.daemon = True; t.start(); rthreads.append(t)
                for t in rthreads:
                    try: t.join(22.0)
                    except Exception: pass
            with lock:
                payload = {"js": [dict(row) for row in state["rows"]], "failed_ids": [x[0] for x in state["failed"]]}
            if done_callback:
                try: done_callback(payload)
                except Exception: pass
        t = threading.Thread(target=waiter, name="TiviMateXtreamShortEPGWait")
        t.daemon = True; t.start()
        return {"js": [], "pending": True}

    def catchup_epg(self, ch_id, epg_channel_id=""):
        """Return the provider EPG table used to build the Catch-up archive.

        get_simple_data_table normally exposes more historical rows than
        get_short_epg.  Fall back to short EPG for panels that do not implement
        the full table endpoint.
        """
        stream_id = str(ch_id or "").strip()
        epg_id = str(epg_channel_id or "").strip()

        def listings(payload):
            if isinstance(payload, dict):
                rows = (
                    payload.get("epg_listings") or
                    payload.get("listings") or
                    payload.get("epg") or
                    payload.get("data") or
                    []
                )
            elif isinstance(payload, list):
                rows = payload
            else:
                rows = []
            return rows if isinstance(rows, list) else []

        rows = []
        if stream_id:
            try:
                rows = listings(self.api("get_simple_data_table", stream_id=stream_id))
            except Exception:
                rows = []

        if not rows and epg_id:
            for key in ("epg_channel_id", "channel_id"):
                try:
                    rows = listings(self.api("get_simple_data_table", **{key: epg_id}))
                except Exception:
                    rows = []
                if rows:
                    break

        if not rows:
            rows = self.short_epg(stream_id, limit=20, epg_channel_id=epg_id)
        return rows



    def vod_info(self, vod_id):
        return self.api("get_vod_info", vod_id=str(vod_id))
    def series_info(self, series_id):
        return self.api("get_series_info", series_id=str(series_id))
    def episode_url(self, episode):
        eid=str(episode.get("id") or episode.get("stream_id") or "")
        ext=episode.get("container_extension") or "mp4"
        return "%s/series/%s/%s/%s.%s"%(self.base,self.user,self.password,eid,ext)
    def stream_url(self, item, kind):
        sid = str((item or {}).get("stream_id") or "")
        if kind == "live":
            return "%s/live/%s/%s/%s.%s" % (
                self.base, self.user, self.password, sid, self.output
            )
        ext = (item or {}).get("container_extension") or "mp4"
        if kind == "vod":
            return "%s/movie/%s/%s/%s.%s" % (
                self.base, self.user, self.password, sid, ext
            )
        return ""



def _normalise_fg_url(value):
    raw = (value or "").strip()
    if not raw:
        return ""
    if raw.startswith(("http://", "https://")):
        return raw
    if "/" in raw or "." in raw:
        # FG links published for Drama Live are commonly supplied without a
        # scheme. Prefer HTTP first for fgcode.org because some codes are
        # served differently there; the resolver also tries HTTPS.
        return "http://" + raw.lstrip("/")
    return "http://fgcode.org/" + raw


def _fg_candidate_urls(value):
    """Return conservative public FG URLs only.

    We intentionally do not guess private application API endpoints here.
    The resolver checks the exact user supplied link and the two public
    fgcode.org scheme variants only.
    """
    raw = (value or "").strip()
    if not raw:
        return []
    out = []
    def add(url):
        if url and url not in out:
            out.append(url)
    if raw.startswith(("http://", "https://")):
        add(raw)
        try:
            plain = raw.split('://', 1)[1]
            add("https://" + plain)
            add("http://" + plain)
        except Exception:
            pass
    elif "/" in raw or "." in raw:
        plain = raw.lstrip('/')
        add("https://" + plain)
        add("http://" + plain)
    else:
        add("https://fgcode.org/" + raw)
        add("http://fgcode.org/" + raw)
    return out

def _fg_extract_candidates(text):
    """Extract possible playlist URLs or Xtream credentials from wrapper data."""
    if not text:
        return [], []
    try:
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    except Exception:
        try:
            from html import unescape
        except Exception:
            unescape = lambda x: x
    try:
        from urllib import unquote
    except Exception:
        try:
            from urllib.parse import unquote
        except Exception:
            unquote = lambda x: x
    urls, xtream = [], []
    def addu(v):
        try:
            v = v.strip().replace('\\/', '/')
        except Exception:
            return
        if v.startswith(("http://", "https://")) and v not in urls:
            urls.append(v)
    def walk(value):
        if isinstance(value, dict):
            low = {}
            for k, v in value.items():
                try: low[str(k).lower()] = v
                except Exception: pass
                walk(v)
            base = low.get('url') or low.get('host') or low.get('server') or low.get('server_url')
            user = low.get('username') or low.get('user')
            password = low.get('password') or low.get('pass')
            if base and user is not None and password is not None:
                xtream.append((str(base), str(user), str(password)))
        elif isinstance(value, (list, tuple)):
            for item in value: walk(item)
        else:
            try:
                item = value if isinstance(value, str) else str(value)
            except Exception:
                return
            if item.startswith(("http://", "https://")): addu(item)
    try:
        walk(json.loads(text))
    except Exception:
        pass
    try:
        cleaned = unescape(text).replace('\\/', '/')
        for found in re.findall(r'https?://[^\\s"\'<>]+', cleaned): addu(found)
        for found in re.findall(r'https?%3A%2F%2F[^\\s"\'<>]+', cleaned, re.I):
            addu(unquote(found))
        # Values are sometimes nested once or twice in URL encoding.
        decoded = cleaned
        for _ in range(2):
            try: decoded = unquote(decoded)
            except Exception: break
        if decoded != cleaned:
            for found in re.findall(r'https?://[^\\s"\'<>]+', decoded): addu(found)
    except Exception:
        pass
    return urls, xtream


def _fg_normalise_m3u_bytes(data):
    if not data:
        return None
    if not isinstance(data, bytes):
        try: data = data.encode("utf-8")
        except Exception: return None
    stripped = data.lstrip()
    if stripped.startswith(b"#EXTM3U"):
        return stripped
    if b"#EXTINF:" in stripped and (b"http://" in stripped or b"https://" in stripped):
        return b"#EXTM3U\n" + stripped
    return None


def _fg_json_to_m3u(text):
    try:
        parsed = json.loads(text)
    except Exception:
        return None
    rows = None
    if isinstance(parsed, dict):
        for key in ("channels", "items", "streams", "data", "playlist"):
            if isinstance(parsed.get(key), list):
                rows = parsed.get(key); break
    elif isinstance(parsed, list):
        rows = parsed
    if not isinstance(rows, list):
        return None
    lines = ["#EXTM3U"]
    count = 0
    for row in rows:
        if not isinstance(row, dict): continue
        url = row.get("url") or row.get("link") or row.get("stream_url") or row.get("stream") or row.get("src")
        if not url: continue
        name = row.get("name") or row.get("title") or row.get("channel_name") or "Channel"
        group = row.get("group") or row.get("group-title") or row.get("category") or row.get("category_name") or "FG Code"
        logo = row.get("logo") or row.get("tvg-logo") or row.get("icon") or row.get("image") or ""
        lines.append('#EXTINF:-1 tvg-logo="%s" group-title="%s",%s' % (logo, group, name))
        lines.append(str(url)); count += 1
    if count:
        return ("\n".join(lines) + "\n").encode("utf-8")
    return None


def _fg_fetch(url, headers, timeout):
    """Fetch FG data and return bytes plus final redirect URL/content type."""
    h = {"User-Agent": UA, "Accept": "*/*"}
    h.update(headers or {})
    req = Request(url, headers=h)
    try: ctx = ssl._create_unverified_context()
    except Exception: ctx = None
    try:
        if ctx is not None: response = urlopen(req, timeout=timeout, context=ctx)
        else: response = urlopen(req, timeout=timeout)
    except TypeError:
        response = urlopen(req, timeout=timeout)
    try:
        data = response.read()
        try: final_url = response.geturl()
        except Exception: final_url = url
        try: ctype = response.info().getheader('Content-Type') or ''
        except Exception: ctype = ''
    finally:
        try: response.close()
        except Exception: pass
    return data, final_url, ctype


def inspect_fg_public(source):
    """Inspect only public/user-supplied FG URLs.

    Returns a diagnostic dictionary. If a public response itself contains a
    usable M3U playlist, it is returned in ``playlist``. No private Drama Live
    API/session is invoked.
    """
    source = source or {}
    raw_value = source.get("code") or source.get("url")
    starts = _fg_candidate_urls(raw_value)
    if not starts:
        raise ValueError("FG Code or URL is empty")
    headers = {
        "User-Agent": UA,
        "Accept": "application/x-mpegURL, application/vnd.apple.mpegurl, text/plain, application/json, text/html, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "close",
    }
    checks = []
    last_error = None
    for current in starts[:4]:
        try:
            data, final_url, ctype = _fg_fetch(current, headers, min(NETWORK_TIMEOUT, 10))
            size = len(data or b"")
            item = {"url": current, "final_url": final_url or current, "content_type": ctype or "", "size": size}
            playlist = _fg_normalise_m3u_bytes(data)
            if playlist is None:
                try: text = data.decode("utf-8", "replace")
                except Exception: text = ""
                playlist = _fg_json_to_m3u(text)
            if playlist is not None:
                item["playlist"] = True
                checks.append(item)
                return {"ok": True, "playlist": playlist, "checks": checks}
            item["playlist"] = False
            checks.append(item)
        except Exception as exc:
            last_error = exc
            checks.append({"url": current, "error": str(exc)})
    return {"ok": False, "playlist": None, "checks": checks, "error": str(last_error) if last_error else ""}


def resolve_fg_playlist(source):
    """Resolve only a public/user-accessible FG response to M3U bytes."""
    report = inspect_fg_public(source)
    if report.get("ok") and report.get("playlist") is not None:
        return report.get("playlist")
    checks = report.get("checks") or []
    if checks:
        last = checks[-1]
        if last.get("error"):
            raise ValueError("FG public URL failed: %s" % last.get("error"))
        raise ValueError("FG public URL responded, but no public M3U playlist was exposed (%s, %s bytes)." % (
            last.get("content_type") or "unknown type", last.get("size", 0)))
    raise ValueError("FG Code could not be checked")



# ---------------------------------------------------------------------------
# M3U / FG client
# ---------------------------------------------------------------------------

class M3UClient:
    def __init__(self, src):
        self.source = src or {}
        self.url = self.source.get("url", "")

    def test(self):
        data = self._read()
        return {"ok": data.startswith(b"#EXTM3U"), "size": len(data)}

    def entries(self):
        text = self._read().decode("utf-8", "replace")
        out = []
        meta = None
        playlist_epg = ""
        first = True
        for raw in text.splitlines():
            line = raw.strip()
            if first and line.startswith("#EXTM3U"):
                first = False
                hdr = dict(re.findall(r'([\w-]+)="([^"]*)"', line)); hdr.update(dict(re.findall(r"([\w-]+)=\'([^\']*)\'", line)))
                playlist_epg = hdr.get("url-tvg") or hdr.get("x-tvg-url") or ""
                continue
            first = False
            if line.startswith("#EXTINF"):
                attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', line)); attrs.update(dict(re.findall(r"([\w-]+)=\'([^\']*)\'", line)))
                name = line.split(",", 1)[1].strip() if "," in line else attrs.get("tvg-name", "Channel")
                group = attrs.get("group-title", "Other") or "Other"
                meta = {
                    "name": name,
                    "title": name,
                    "tvg_name": attrs.get("tvg-name", name),
                    "tvg_id": attrs.get("tvg-id", ""),
                    "epg_channel_id": attrs.get("tvg-id", ""),
                    "logo": attrs.get("tvg-logo", ""),
                    "stream_icon": attrs.get("tvg-logo", ""),
                    "group": group,
                    "category_name": group,
                    "category_id": group,
                    "catchup": attrs.get("catchup", attrs.get("catchup-type", "")),
                    "catchup_source": attrs.get("catchup-source", ""),
                    "catchup_days": attrs.get("catchup-days", attrs.get("timeshift", "")),
                    "timeshift": attrs.get("timeshift", ""),
                    "radio": attrs.get("radio", ""),
                    "epg_url": playlist_epg,
                }
            elif line and not line.startswith("#") and meta:
                meta["url"] = line
                meta["cmd"] = line
                seed = (meta.get("tvg_id") or meta.get("name") or "") + "|" + line
                meta["stream_id"] = hashlib.sha1(seed.encode("utf-8", "ignore")).hexdigest()[:16]
                out.append(meta)
                meta = None

        return out

    def _read(self):
        """Read a standard M3U playlist from HTTP(S) or a local file."""
        if self.source.get("type") == "fg":
            return resolve_fg_playlist(self.source)

        local_path = str(self.source.get("path") or "").strip()
        mode = str(self.source.get("m3u_mode") or "").strip().lower()
        candidate = local_path or str(self.url or "").strip()

        if mode == "file" or (candidate and not candidate.lower().startswith(("http://", "https://"))):
            path = os.path.abspath(os.path.expanduser(candidate))
            if not os.path.isfile(path):
                raise IOError("M3U file not found: %s" % path)
            with open(path, "rb") as handle:
                data = handle.read()
            return data

        return fetch(candidate, timeout=NETWORK_TIMEOUT)



def _http_headers_map(raw_headers):
    """Parse HTTP headers without depending on image-specific HTTP libraries."""
    result = {}
    try:
        text = raw_headers.decode("iso-8859-1", "replace") if isinstance(raw_headers, bytes) else str(raw_headers)
    except Exception:
        return result
    for line in text.split("\r\n")[1:]:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        result[key.strip().lower()] = value.strip()
    return result


def _decode_chunked_body(body):
    """Decode an RFC 7230 chunked body used by several Ministra front ends."""
    output = []
    pos = 0
    total = len(body)
    while pos < total:
        end = body.find(b"\r\n", pos)
        if end < 0:
            raise ValueError("incomplete chunk size")
        size_line = body[pos:end].split(b";", 1)[0].strip()
        size = int(size_line, 16)
        pos = end + 2
        if size == 0:
            return b"".join(output)
        if pos + size > total:
            raise ValueError("incomplete chunk data")
        output.append(body[pos:pos + size])
        pos += size
        if body[pos:pos + 2] != b"\r\n":
            raise ValueError("invalid chunk terminator")
        pos += 2
    raise ValueError("missing final chunk")


def _decode_stalker_http_body(raw_headers, body):
    headers = _http_headers_map(raw_headers)
    transfer = headers.get("transfer-encoding", "").lower()
    if "chunked" in transfer:
        body = _decode_chunked_body(body)
    encoding = headers.get("content-encoding", "").lower()
    if "gzip" in encoding:
        body = gzip.GzipFile(fileobj=io.BytesIO(body)).read()
    return body, headers



# ---------------------------------------------------------------------------
# Stalker client
# ---------------------------------------------------------------------------

class StalkerClient:
    """Stalker / Ministra client with portal-aware session setup.

    This client is intentionally isolated from Xtream and M3U.  It keeps its token
    only in RAM, loads the small Packages list first, and fetches a package only
    when the user opens it.
    """
    PAGE_LIMIT = 3

    def __init__(self, src):
        src = src or {}
        raw_portal = (src.get("url", "") or "").strip().rstrip("/")
        self.mac = (src.get("mac", "00:1A:79:00:00:00") or "").upper()
        # Accept imported forms such as /c/MAC while keeping the MAC separate
        # for the Stalker cookie.  The portal UI path is retained for Referer,
        # while API endpoint discovery operates from the server root.
        embedded = re.search(r"/c/([0-9A-Fa-f:]{17})$", raw_portal)
        if embedded:
            if not src.get("mac"):
                self.mac = embedded.group(1).upper()
            raw_portal = raw_portal[:embedded.start()] + "/c"
        self.portal = raw_portal.rstrip("/")
        self.configured_portal = self.portal
        self._token_key = "%s|%s" % (self.configured_portal, self.mac)
        self.token = ""
        self._compat = load_stalker_compat(self.configured_portal, self.mac)
        self._capability_key = stable_cache_key("stalker:capabilities", self.configured_portal, self.mac)
        _caps = persistent_cache_get(self._capability_key, None)
        if not isinstance(_caps, dict):
            _caps = {}
        self._endpoint = str(self._compat.get("endpoint") or _caps.get("endpoint") or "")
        self.path_prefix = str(self._compat.get("path_prefix") or _caps.get("path_prefix") or "")
        self.portal_version = str(self._compat.get("portal_version") or self._compat.get("version") or _caps.get("portal_version") or "")
        self.play_token = str(self._compat.get("play_token") or "")
        self.account_status = self._compat.get("status", 1)
        self.blocked = str(self._compat.get("blocked") or "0")
        self.expiry = str(self._compat.get("expiry") or "")
        self.account_valid = True
        self.returned_mac = str(self._compat.get("returned_mac") or "")
        self.returned_id = str(self._compat.get("returned_id") or "")
        discovered = str(self._compat.get("portal") or _caps.get("portal") or "")
        if discovered:
            self.portal = discovered.rstrip("/")
        elif self._endpoint and self._endpoint.endswith(("portal.php", "server/load.php", "load.php")):
            self.portal = self._endpoint.rstrip("/")
        self._discovery_ready = bool(self._compat.get("portal") and self._compat.get("path_prefix"))
        self._profile_ready = False
        self._modules_ready = False
        self._estalker_http = None
        self._xtream_creds = {}
        self._xtream_info = {}
        self._native145_headers = {}
        self._native145_account_valid = False
        try:
            if requests is not None:
                self._estalker_http = requests.Session()
                if HTTPAdapter is not None:
                    adapter = HTTPAdapter(max_retries=0)
                    self._estalker_http.mount("http://", adapter)
                    self._estalker_http.mount("https://", adapter)
        except Exception:
            self._estalker_http = None
        self._session_cookies = {}
        # EStalker-style portal hardening: remember temporarily failing API
        # endpoints so one broken fallback does not add seconds to every call.
        self._endpoint_failures = {}
        self._endpoint_cooldown = 15.0
        # Adaptive Stalker timing/health state is kept globally per portal so
        # short-lived client objects reuse the learned timeout without making
        # the first screen slower. It never changes artwork/VOD filtering.
        self._health_key = self._token_key
        # Stable MAG identity values improve compatibility with portals that bind
        # a token to one emulated device.  Values are deterministic per MAC, so
        # restarting Enigma2 does not appear as a new receiver.
        compact_mac = self.mac.replace(":", "").upper()
        self.stb_type = str(src.get("stb_type") or self._compat.get("stb_type") or "MAG250").upper()
        if self.stb_type not in STALKER_MAG_MODELS:
            self.stb_type = "MAG250"
        # Match the stable MAG identity used by mature Stalker clients.
        self.serial = str(src.get("serial") or hashlib.md5(self.mac.encode("ascii", "ignore")).hexdigest()[:13].upper())
        self.device_id = str(src.get("device_id") or hashlib.sha256(self.mac.encode("ascii", "ignore")).hexdigest().upper())
        self.device_id2 = str(src.get("device_id2") or hashlib.sha256(self.device_id.encode("ascii", "ignore")).hexdigest().upper())
        self.signature = str(src.get("signature") or hashlib.sha256((self.device_id + self.device_id).encode("ascii", "ignore")).hexdigest().upper())
        self.hw_version_2 = hashlib.sha1(self.mac.encode("ascii", "ignore")).hexdigest()
        self.prehash = hashlib.sha1((self.serial + self.mac).encode("ascii", "ignore")).hexdigest()
        self.adid = hashlib.md5((self.serial + self.mac).encode("ascii", "ignore")).hexdigest()
        self.token_random = ""
        with _CATALOG_LOCK:
            saved = _lru_get(_STALKER_TOKENS, self._token_key)
        if saved and time.time() - saved[1] < _STALKER_TOKEN_TTL:
            self.token = saved[0]
            # Newer cache entries also remember that profile/modules already
            # succeeded. This avoids repeating those calls for every short-lived
            # client object while keeping compatibility with old 2-tuples.
            if len(saved) > 2:
                self._profile_ready = bool(saved[2])
            if len(saved) > 3:
                self._modules_ready = bool(saved[3])
            if len(saved) > 4 and saved[4]:
                self._endpoint = saved[4]
            if len(saved) > 5 and saved[5] in STALKER_MAG_MODELS:
                self.stb_type = saved[5]
        stalker_log("SESSION portal=%s mac=%s model=%s cached_token=%s profile_cached=%s modules_cached=%s" % (
            self.portal, _mask_mac(self.mac), self.stb_type, bool(self.token),
            bool(self._profile_ready), bool(self._modules_ready)))
        runtime_memory_cleanup(force_gc=False)
        if self.token:
            self._schedule_prefetch()

    def _persistent_key(self, namespace, *parts):
        # Hash portal + MAC so credentials are never stored as readable cache keys.
        return stable_cache_key("stalker:" + str(namespace or "misc"), self.configured_portal, self.mac, *parts)

    def _persistent_get(self, namespace, *parts):
        return persistent_cache_get(self._persistent_key(namespace, *parts), None)

    def _persistent_set(self, namespace, value, ttl, *parts):
        return persistent_cache_set(self._persistent_key(namespace, *parts), "stalker:" + str(namespace or "misc"), value, ttl)

    def _persistent_peek(self, namespace, *parts):
        return persistent_cache_peek(
            self._persistent_key(namespace, *parts), None, _STALKER_STALE_WINDOW
        )

    def _refresh_background(self, marker, worker):
        key = (self._token_key, str(marker))
        with _CATALOG_LOCK:
            if key in _STALKER_REFRESHING:
                return False
            _STALKER_REFRESHING.add(key)

        def run():
            started = time.time()
            try:
                worker()
                stalker_log("BG_REFRESH marker=%s ms=%d" % (
                    marker, int((time.time() - started) * 1000)
                ))
            except Exception as exc:
                stalker_log("BG_REFRESH failed marker=%s error=%s" % (marker, exc))
            finally:
                with _CATALOG_LOCK:
                    _STALKER_REFRESHING.discard(key)
        try:
            thread = threading.Thread(target=run)
            thread.daemon = True
            thread.start()
            return True
        except Exception:
            with _CATALOG_LOCK:
                _STALKER_REFRESHING.discard(key)
            return False

    def _schedule_prefetch(self):
        """Warm packages and the full live catalogue at most once per 10 minutes."""
        now = time.time()
        with _CATALOG_LOCK:
            last = float(_STALKER_PREFETCH_AT.get(self._token_key) or 0)
            if now - last < 600:
                return
            _STALKER_PREFETCH_AT[self._token_key] = now

        def warm():
            try:
                self._categories("itv", ("get_genres", "get_categories"), _refresh_only=True)
            except Exception:
                pass
            try:
                self._channels_network_refresh()
            except Exception:
                pass
        self._refresh_background("prefetch", warm)

    def _pcache_get(self, namespace, *parts):
        return self._persistent_get(namespace, *parts)

    def _pcache_set(self, namespace, value, ttl, *parts):
        return self._persistent_set(namespace, value, ttl, *parts)

    def _live_mem_key(self, namespace, *parts):
        return (self._token_key, str(namespace or "misc")) + tuple(str(x) for x in parts)

    def _live_mem_get(self, namespace, *parts):
        key = self._live_mem_key(namespace, *parts)
        with _CATALOG_LOCK:
            row = _lru_get(_STALKER_LIVE_MEMORY, key)
        if not row:
            return None
        try:
            created, value = row
            if time.time() - float(created) > _STALKER_PAGE_TTL:
                with _CATALOG_LOCK:
                    _STALKER_LIVE_MEMORY.pop(key, None)
                return None
            return value
        except Exception:
            return None

    def _live_mem_set(self, namespace, value, *parts):
        key = self._live_mem_key(namespace, *parts)
        with _CATALOG_LOCK:
            _lru_put(_STALKER_LIVE_MEMORY, key, (time.time(), value), _STALKER_LIVE_MEMORY_LIMIT)
        return value

    def _launcher_root(self):
        parsed = urlparse(self.configured_portal or self.portal)
        scheme = parsed.scheme or "http"
        netloc = parsed.netloc
        path = (parsed.path or "").rstrip("/")
        for suffix in ("/stalker_portal/server/load.php", "/server/load.php", "/portal.php", "/load.php"):
            if path.endswith(suffix):
                path = path[:-len(suffix)]
                break
        for suffix in ("/stalker_portal/c", "/c"):
            if path.endswith(suffix):
                path = path[:-len(suffix)]
                break
        return ("%s://%s%s" % (scheme, netloc, path)).rstrip("/")

    def _launcher_headers(self, url=None):
        parsed = urlparse(url or self.configured_portal or self.portal)
        timezone = _stalker_local_timezone()
        encoded_mac = quote(self.mac, safe="")
        return {
            "Pragma": "no-cache", "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
            "X-User-Agent": "Model: MAG250; Link: WiFi",
            "Connection": "keep-alive",
            "Referer": self._launcher_root() + (self.path_prefix or "/c/") + "index.html",
            "Cookie": "mac=%s; stb_lang=en; timezone=%s" % (encoded_mac, quote(timezone, safe="")),
            "Host": parsed.netloc,
        }

    def _fetch_launcher_text(self, url, timeout=5):
        # EStalker 1.45 keeps one requests.Session from launcher discovery
        # through handshake/profile/account. Use the same behavior when
        # requests is available, with the original urllib path as fallback.
        if self._estalker_http is not None:
            try:
                response = self._estalker_http.get(
                    url, headers=self._launcher_headers(url),
                    timeout=(timeout, timeout), verify=False,
                    allow_redirects=True
                )
                if int(getattr(response, "status_code", 0) or 0) < 400:
                    return str(response.text or ""), str(getattr(response, "url", None) or url)
            except Exception as exc:
                stalker_log("ESTALKER SESSION launcher fallback url=%s error=%s" % (url, exc))

        req = Request(url, headers=self._launcher_headers(url))
        try: ctx = ssl._create_unverified_context()
        except Exception: ctx = None
        try:
            try:
                response = urlopen(req, timeout=timeout, context=ctx) if ctx is not None else urlopen(req, timeout=timeout)
            except TypeError:
                response = urlopen(req, timeout=timeout)
            try:
                data = response.read(1024 * 1024)
                final_url = response.geturl() if hasattr(response, "geturl") else url
            finally:
                try: response.close()
                except Exception: pass
            if isinstance(data, bytes):
                data = data.decode("utf-8", "ignore")
            return str(data or ""), str(final_url or url)
        except Exception:
            return "", url

    def _extract_portal_path_from_xpcom(self, text, source_url):
        prefix = "/stalker_portal" if "/stalker_portal/" in str(source_url) else ""
        for raw in str(text or "").splitlines():
            line = raw.strip()
            if "this.ajax_loader = this" not in line:
                continue
            urls = re.findall(r"""['"](/[^'"]*(?:portal\.php|server/load\.php|load\.php)[^'"]*)['"]""", line)
            if urls:
                path = re.sub(r"/+", "/", prefix + urls[-1])
                return path if path.startswith("/") else "/" + path
        return ""

    def _discover_portal(self, force=False):
        if self._discovery_ready and not force:
            return True
        host = self._launcher_root()
        if not host:
            return False
        configured_path = (urlparse(self.configured_portal).path or "").rstrip("/") + "/"
        candidates = ("/stalker_portal/c/", "/c/") if configured_path.endswith("/stalker_portal/c/") else ("/c/", "/stalker_portal/c/")
        chosen = ""
        for prefix in candidates:
            body, final_url = self._fetch_launcher_text(host + prefix, timeout=5)
            if body or final_url.rstrip("/") != (host + prefix).rstrip("/"):
                fpath = urlparse(final_url).path or prefix
                chosen = "/stalker_portal/c/" if "/stalker_portal/c" in fpath else ("/c/" if "/c" in fpath else prefix)
                break
        if not chosen:
            chosen = candidates[0]
        self.path_prefix = chosen

        xpcom_urls = [host + chosen + "xpcom.common.js"]
        alt = "/stalker_portal/c/" if chosen == "/c/" else "/c/"
        xpcom_urls.append(host + alt + "xpcom.common.js")
        discovered = ""
        for url in xpcom_urls:
            body, final_url = self._fetch_launcher_text(url, timeout=3)
            if body:
                path = self._extract_portal_path_from_xpcom(body, final_url)
                if path:
                    discovered = host + path
                    break
        self.portal = (discovered or (host + "/portal.php")).rstrip("/")

        body, _ = self._fetch_launcher_text(host + chosen + "version.js", timeout=3)
        if body:
            m = re.search(r"""ver\s*=\s*['"]([^'"]+)['"]""", body)
            if m:
                self.portal_version = m.group(1).strip()
        self._discovery_ready = True
        save_stalker_compat(
            self.configured_portal, self.mac, portal=self.portal,
            path_prefix=self.path_prefix, portal_version=self.portal_version,
            endpoint=self._endpoint, stb_type=self.stb_type
        )
        try:
            persistent_cache_set(self._capability_key, "stalker:capabilities", {
                "portal": self.portal, "endpoint": self._endpoint or self.portal,
                "path_prefix": self.path_prefix, "portal_version": self.portal_version,
                "stb_type": self.stb_type
            }, _STALKER_CAPABILITY_TTL)
        except Exception:
            pass
        stalker_log("DISCOVERY portal=%s prefix=%s version=%s" % (
            self.portal, self.path_prefix, self.portal_version or "unknown"))
        return True

    def _account_info(self):
        try:
            response = self.call(type="account_info", action="get_main_info", JsHttpRequest="1-xml") or {}
            js = self._portal_js(response)
            if not isinstance(js, dict):
                return False
            expiry_value = js.get("end_date") or js.get("expire_billing_date") or js.get("expiry") or js.get("expire_date") or ""
            if not expiry_value:
                phone_value = str(js.get("phone") or "").strip()
                # Some Ministra portals overload "phone" with the subscription date.
                if re.search(r"(?:19|20)\\d{2}[-/.]", phone_value) or re.search(r"[-/.](?:19|20)\\d{2}", phone_value):
                    expiry_value = phone_value
            self.expiry = str(expiry_value or self.expiry or "")
            status_text = str(js.get("status") or js.get("account_status") or "").strip().lower()
            self.account_valid = status_text not in ("0", "disabled", "expired", "blocked", "false")
            save_stalker_compat(
                self.configured_portal, self.mac, expiry=self.expiry,
                play_token=self.play_token, status=self.account_status,
                blocked=self.blocked, returned_mac=self.returned_mac,
                returned_id=self.returned_id, portal=self.portal,
                path_prefix=self.path_prefix, portal_version=self.portal_version
            )
            return True
        except Exception as exc:
            stalker_log("ACCOUNT_INFO optional error=%s" % exc)
            return False


    def _cookie_header(self):
        encoded_mac = quote(self.mac, safe="")
        timezone = _stalker_local_timezone()
        base = {
            "mac": encoded_mac,
            "stb_lang": "en",
            "timezone": quote(timezone, safe=""),
        }
        if "/stalker_portal/" in (self.endpoint() or self.portal):
            base["adid"] = self.adid
        try:
            for key, value in (self._session_cookies or {}).items():
                if key and value and key not in base:
                    base[str(key)] = str(value)
        except Exception:
            pass
        return "; ".join("%s=%s" % (k, v) for k, v in base.items())

    def _remember_set_cookie(self, headers):
        try:
            values = []
            if hasattr(headers, "get_all"):
                values = headers.get_all("Set-Cookie") or []
            if not values:
                one = headers.get("Set-Cookie") if headers else None
                if one:
                    values = [one]
            for raw in values:
                for part in str(raw or "").split(","):
                    first = part.split(";", 1)[0].strip()
                    if "=" not in first:
                        continue
                    key, value = first.split("=", 1)
                    key = key.strip()
                    value = value.strip()
                    if key:
                        self._session_cookies[key] = value
        except Exception:
            pass


    def _native145_make_request(self, url, headers=None, params=None, response_type="json", timeout=(5, 10), allow_redirects=True):
        if self._estalker_http is None:
            raise RuntimeError("EStalker native mode requires requests.Session")
        try:
            if params:
                parsed_url = urlparse(url)
                existing_params = dict(parse_qsl(parsed_url.query))
                existing_params.update(params)
                url = urlunparse(parsed_url._replace(query=urlencode(existing_params)))
            response = self._estalker_http.get(
                url, headers=headers, timeout=timeout,
                verify=False, allow_redirects=allow_redirects
            )
            response.raise_for_status()
            if response_type == "text":
                return response.text
            try:
                return response.json()
            except ValueError:
                try:
                    return json.loads(response.text)
                except Exception:
                    return None
        except Exception:
            return None

    def _native145_build_headers(self, host, mac, timezone, referer):
        parsed = urlparse(host)
        domain = parsed.hostname or ""
        port = parsed.port
        encoded_mac = quote(mac, safe="")
        encoded_timezone = quote(timezone, safe="")
        return {
            "Pragma": "no-cache",
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate",
            "Host": "%s:%s" % (domain, port) if port else domain,
            "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
            "X-User-Agent": "Model: MAG250; Link: WiFi",
            "Connection": "keep-alive",
            "Referer": referer,
            "Cookie": "mac=%s; stb_lang=en; timezone=%s" % (encoded_mac, encoded_timezone),
        }

    def _native145_path_prefix(self, host, headers, path_prefix):
        if path_prefix == "/stalker_portal/c/":
            pairs = [(host + "/stalker_portal/c/", "/stalker_portal/c/"),
                     (host + "/c/", "/c/")]
        elif path_prefix == "/c/":
            pairs = [(host + "/c/", "/c/"),
                     (host + "/stalker_portal/c/", "/stalker_portal/c/")]
        else:
            return path_prefix
        for url, prefix in pairs:
            response = None
            try:
                response = self._estalker_http.get(
                    url, headers=headers, timeout=5, verify=False,
                    stream=True, allow_redirects=True
                )
                response.raise_for_status()
                return prefix
            except Exception:
                pass
            finally:
                try:
                    if response is not None:
                        response.close()
                except Exception:
                    pass
        return pairs[0][1]

    def _native145_extract_portal_path(self, response, url):
        portal_prefix = ""
        try:
            for line in response.iter_lines():
                try:
                    if isinstance(line, bytes):
                        line = line.decode("utf-8", "ignore")
                    elif not isinstance(line, str):
                        line = str(line)
                except Exception:
                    continue
                line = line.strip()
                if not line or "this.ajax_loader = this" not in line:
                    continue
                if "this.portal_path" in line:
                    portal_prefix = "/stalker_portal" if "/stalker_portal/" in url else "/c"

                patterns = [
                    r"this\.portal_protocol\s*\+\s*['\"]://['\"]\s*\+\s*this\.portal_ip\s*\+\s*['\"]/['\"]\s*\+\s*this\.portal_path\s*\+\s*['\"](/[^'\"]+)",
                    r"this\.portal_protocol\s*\+\s*['\"]://['\"]\s*\+\s*this\.portal_ip\s*\+\s*['\"](/[^'\"]+)",
                    r"this\.portal_ip\s*\+\s*['\"](/[^'\"]+)",
                ]
                match = None
                for pat in patterns:
                    match = re.search(pat, line)
                    if match:
                        break
                if match:
                    return re.sub(r"/+", "/", (portal_prefix + match.group(1)).strip())
        except Exception:
            pass
        return ""

    def _native145_portal_url(self, host, headers, path_prefix):
        xpcom_urls = (
            [host + "/stalker_portal/c/xpcom.common.js", host + "/c/xpcom.common.js"]
            if path_prefix == "/stalker_portal/c/" else
            [host + "/c/xpcom.common.js", host + "/stalker_portal/c/xpcom.common.js"]
        )
        for url in xpcom_urls:
            response = None
            try:
                response = self._estalker_http.get(
                    url, headers=headers, timeout=3, verify=False,
                    stream=True, allow_redirects=True
                )
                response.raise_for_status()
                candidate = self._native145_extract_portal_path(response, url)
                if candidate:
                    if not candidate.startswith("/"):
                        candidate = "/" + candidate
                    return host + candidate
            except Exception:
                pass
            finally:
                try:
                    if response is not None:
                        response.close()
                except Exception:
                    pass
        return host + "/portal.php"

    def _native145_portal_version(self, host, headers, path_prefix):
        response = None
        try:
            response = self._estalker_http.get(
                host + path_prefix + "version.js",
                headers=headers, timeout=3, verify=False,
                allow_redirects=False
            )
            response.raise_for_status()
            match = re.search(r"ver\s*=\s*['\"]([^'\"]+)['\"]", response.text)
            return match.group(1).strip() if match else ""
        except Exception:
            return ""
        finally:
            try:
                if response is not None:
                    response.close()
            except Exception:
                pass

    def _native145_handshake_only(self, portal, mac, headers):
        response = self._native145_make_request(
            portal + "?", headers=headers,
            params={"type":"stb","action":"handshake","token":"","JsHttpRequest":"1-xml"}
        )
        if not response:
            response = self._native145_make_request(
                portal + "?", headers=headers,
                params={"type":"stb","action":"handshake","token":"","JsHttpRequest":"1-xml","mac":mac}
            )
        token = None
        token_random = None
        if response and isinstance(response, dict):
            js_data = response.get("js", {})
            if isinstance(js_data, dict) and "msg" in js_data and "missing" in str(js_data["msg"]).lower():
                fake_token = "".join(random.choice(string.ascii_uppercase + string.digits) for _ in range(32))
                prehash = hashlib.sha1(fake_token.encode()).hexdigest()
                headers["Authorization"] = "Bearer " + fake_token
                response = self._native145_make_request(
                    portal + "?", headers=headers,
                    params={"type":"stb","action":"handshake","JsHttpRequest":"1-xml","mac":mac,"prehash":prehash}
                )
                js_data = response.get("js", {}) if response else {}
            if isinstance(js_data, dict):
                token = js_data.get("token")
                token_random = js_data.get("random", "")
                if token:
                    headers["Authorization"] = "Bearer " + token
                    headers["Cookie"] = headers.get("Cookie", "") + "; token=" + token
        return token, token_random

    def _native145_profile(self, portal, mac, token_random, headers, param_mode="full"):
        sn = hashlib.md5(mac.encode()).hexdigest().upper()[:13]
        device_id = hashlib.sha256(mac.encode()).hexdigest().upper()
        device_id2 = hashlib.sha256(device_id.encode()).hexdigest().upper()
        hw_version_2 = hashlib.sha1(mac.encode()).hexdigest()
        prehash = hashlib.sha1((sn + mac).encode()).hexdigest()
        signature2 = hashlib.sha256((device_id + device_id).encode()).hexdigest().upper()
        timestamp = str(int(time.time()))

        params = OrderedDict([("type","stb"),("action","get_profile"),("JsHttpRequest","1-xml")])

        if "/stalker_portal/" in portal:
            metrics = {"type":"stb","model":"MAG254","mac":mac,"sn":sn,"uid":device_id2,"random":token_random}
            params.update(OrderedDict([
                ("hd","1"),
                ("ver","ImageDescription: 0.2.18-r23-250; ImageDate: Thu Sep 13 11:31:16 EEST 2018; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x58c"),
                ("num_banks","2"),("sn",sn),("stb_type","MAG250"),("client_type","STB"),
                ("image_version","218"),("video_out","hdmi"),("device_id",device_id),
                ("device_id2",device_id),("signature",signature2),("auth_second_step","1"),
                ("hw_version","1.7-BD-00"),("not_valid_token","0"),
                ("metrics",quote(json.dumps(metrics,separators=(",",":")))),
                ("hw_version_2",hw_version_2),("timestamp",timestamp),
                ("api_signature","262"),("prehash",prehash)
            ]))
        else:
            metrics = {"mac":mac,"sn":sn,"type":"STB","model":"MAG250","uid":"","random":""}
            if param_mode == "full":
                params.update(OrderedDict([
                    ("hd","1"),
                    ("ver","ImageDescription: 0.2.18-r23-250; ImageDate: Thu Sep 13 11:31:16 EEST 2018; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x58c"),
                    ("num_banks","2"),("sn",sn),("stb_type","MAG250"),("client_type","STB"),
                    ("image_version","218"),("video_out","hdmi"),("device_id",device_id),
                    ("device_id2",device_id),("signature",signature2),("auth_second_step","1"),
                    ("hw_version","1.7-BD-00"),("not_valid_token","0"),
                    ("metrics",quote(json.dumps(metrics,separators=(",",":")))),
                    ("hw_version_2",hw_version_2),("timestamp",timestamp),
                    ("api_signature","262"),("prehash",prehash)
                ]))

        profile_data = self._native145_make_request(portal + "?", headers=headers, params=params)
        play_token = None
        status = 1
        blocked = "0"
        returned_mac = ""
        returned_id = ""

        if profile_data:
            js_data = profile_data.get("js", {})
            if not isinstance(js_data, dict):
                js_data = {}
            if js_data:
                play_token = js_data.get("play_token", None)
                status = js_data.get("status", 1)
                blocked = js_data.get("blocked", "0")
                returned_mac = js_data.get("mac", "")
                returned_id = js_data.get("id", "")
                msg = js_data.get("msg", "")
                if msg and not play_token:
                    profile_data = None

        if not profile_data:
            fallback = OrderedDict([
                ("type","stb"),("action","get_profile"),("JsHttpRequest","1-xml"),
                ("sn",sn),("device_id",""),("timestamp",timestamp)
            ])
            profile_data = self._native145_make_request(portal + "?", headers=headers, params=fallback)
            if profile_data:
                js_data = profile_data.get("js", {})
                if isinstance(js_data, dict) and js_data:
                    play_token = js_data.get("play_token", None)
                    status = js_data.get("status", 1)
                    blocked = js_data.get("blocked", "0")
                    returned_mac = js_data.get("mac", "")
                    returned_id = js_data.get("id", "")
        return play_token, status, blocked, returned_mac, returned_id

    def _native145_account_info(self, portal, headers):
        data = self._native145_make_request(
            portal + "?", headers=headers,
            params={"type":"account_info","action":"get_main_info","JsHttpRequest":"1-xml"}
        )
        if data and isinstance(data, dict):
            js_data = data.get("js") or {}
            if isinstance(js_data, dict):
                expiry = (js_data.get("end_date") or js_data.get("expire_billing_date") or
                          js_data.get("expiry") or js_data.get("expire_date") or "")
                if not expiry:
                    phone = str(js_data.get("phone") or "").strip()
                    if re.search(r"(?:19|20)\d{2}[-/.]", phone) or re.search(r"[-/.](?:19|20)\d{2}", phone):
                        expiry = phone
                return str(expiry or ""), True
        return None, False

    def headers(self):
        parsed = urlparse(self.endpoint() or self.portal)
        encoded_mac = quote(self.mac, safe="")
        timezone = _stalker_local_timezone()
        cookie = "mac=%s; stb_lang=en; timezone=%s" % (encoded_mac, quote(timezone, safe=""))
        if "/stalker_portal/" in (self.endpoint() or self.portal):
            cookie += "; adid=%s" % self.adid
        headers = {
            "Pragma": "no-cache",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
            "Cookie": cookie,
            "X-User-Agent": "Model: %s; Link: WiFi" % self.stb_type,
            "Referer": self._launcher_root() + (self.path_prefix or "/c/") + "index.html",
            "Connection": "Close",
        }
        if parsed.netloc:
            headers["Host"] = parsed.netloc
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
            headers["Cookie"] += "; token=" + self.token
        return headers

    def _estalker_headers(self, url=None):
        """Exact EStalker/MAG250 request headers used only as a compatibility retry."""
        parsed = urlparse(url or self.endpoint() or self.portal)
        timezone = _stalker_local_timezone()
        encoded_mac = quote(self.mac, safe="")
        headers = {
            "Pragma": "no-cache",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
            "X-User-Agent": "Model: MAG250; Link: WiFi",
            "Connection": "Close",
            "Referer": self._launcher_root() + (self.path_prefix or "/c/") + "index.html",
            "Cookie": "mac=%s; stb_lang=en; timezone=%s" % (encoded_mac, quote(timezone, safe="")),
        }
        if parsed.netloc:
            headers["Host"] = parsed.netloc
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
            headers["Cookie"] += "; token=" + self.token
        return headers

    def endpoints(self):
        try:
            self._discover_portal(False)
        except Exception:
            pass
        portal = (self.portal or getattr(self, "configured_portal", "")).rstrip("/")
        if not portal:
            return []
        candidates = [portal]
        parsed = urlparse(getattr(self, "configured_portal", "") or portal)
        root = "%s://%s" % (parsed.scheme or "http", parsed.netloc)
        path = (parsed.path or "").rstrip("/")
        for suffix in ("/stalker_portal/c", "/c"):
            if path.endswith(suffix):
                path = path[:-len(suffix)]
                break
        base = (root + path).rstrip("/")
        roots = [base]
        if (parsed.scheme or "").lower() == "https":
            roots.append(("http://%s%s" % (parsed.netloc, path)).rstrip("/"))
        for script in ("/portal.php", "/stalker_portal/server/load.php", "/server/load.php", "/load.php"):
            for candidate_root in roots:
                candidates.append(candidate_root + script)
        unique=[]
        for value in candidates:
            if value and value not in unique:
                unique.append(value)
        return unique


    def endpoint(self):
        choices = self.endpoints()
        return self._endpoint or (choices[0] if choices else "")

    def _decode(self, value):
        if isinstance(value, bytes):
            try:
                value = value.decode("utf-8", "ignore")
            except Exception:
                return value
        if isinstance(value, str):
            raw = value.strip()
            if raw.startswith(("{", "[")):
                try:
                    return json.loads(raw)
                except Exception:
                    pass
        return value

    def _portal_js(self, response):
        response = self._decode(response)
        if not isinstance(response, dict):
            return {}
        value = response.get("js", response.get("data", response))
        return self._decode(value)

    def _response_error(self, response):
        raw = self._decode(response)
        if not isinstance(raw, dict):
            return "Invalid portal response"
        for container in (raw, self._portal_js(raw)):
            if not isinstance(container, dict):
                continue
            error = container.get("error") or container.get("error_msg") or container.get("faultString")
            if error:
                return str(error)
        return ""

    def _is_stalker_auth_error(self, value):
        """Return True only for errors that justify dropping the MAG token."""
        message = str(value or "").strip().lower()
        if not message:
            return False
        markers = (
            "access denied", "not valid token", "invalid token", "token expired",
            "authorization failed", "authorization error", "unauthorized",
            "not authorized", "auth failed", "wrong token", "session expired",
            "session invalid", "need authorization", "authentication required",
        )
        return any(marker in message for marker in markers)

    def _health_state(self):
        try:
            state = _STALKER_HEALTH.get(self._health_key)
            if not isinstance(state, dict):
                state = {"avg_ms": 0.0, "samples": 0, "failures": 0, "status": "Unknown"}
                _STALKER_HEALTH[self._health_key] = state
            return state
        except Exception:
            return {"avg_ms": 0.0, "samples": 0, "failures": 0, "status": "Unknown"}

    def _adaptive_timeout(self):
        """Return a conservative read timeout learned from this portal."""
        state = self._health_state()
        try:
            avg_ms = float(state.get("avg_ms") or 0.0)
            failures = int(state.get("failures") or 0)
        except Exception:
            avg_ms, failures = 0.0, 0
        if avg_ms <= 0:
            return float(NETWORK_TIMEOUT)
        # 3x observed mean + 1.5s breathing room; bounded to avoid either
        # impatient failures or long Enigma2 stalls. Repeated failures add a
        # small allowance, but never exceed 18 seconds.
        timeout = (avg_ms / 1000.0) * 3.0 + 1.5 + min(3.0, failures * 0.75)
        return max(5.0, min(18.0, timeout))

    def _record_portal_health(self, elapsed_ms=None, success=True):
        state = self._health_state()
        try:
            old_status = str(state.get("status") or "Unknown")
            if success and elapsed_ms is not None:
                ms = max(1.0, float(elapsed_ms))
                samples = int(state.get("samples") or 0)
                avg = float(state.get("avg_ms") or 0.0)
                # EWMA reacts to real portal changes without letting one slow
                # request permanently inflate future timeouts.
                avg = ms if samples <= 0 or avg <= 0 else (avg * 0.75 + ms * 0.25)
                state["avg_ms"] = avg
                state["samples"] = min(1000, samples + 1)
                state["failures"] = 0
            elif not success:
                state["failures"] = min(5, int(state.get("failures") or 0) + 1)
            avg = float(state.get("avg_ms") or 0.0)
            failures = int(state.get("failures") or 0)
            if failures >= 5:
                status = "Offline"
            elif failures >= 2:
                status = "Unstable"
            elif avg <= 0:
                status = "Unknown"
            elif avg < 700:
                status = "Excellent"
            elif avg < 1500:
                status = "Online"
            else:
                status = "Slow"
            state["status"] = status
            _STALKER_HEALTH[self._health_key] = state
            if status != old_status or not success:
                stalker_log("PORTAL_HEALTH status=%s avg_ms=%d failures=%d timeout=%.1fs" % (
                    status, int(avg), failures, self._adaptive_timeout()
                ))
        except Exception:
            pass

    def portal_health(self):
        """Small diagnostics snapshot; safe for future Settings UI use."""
        state = dict(self._health_state())
        try:
            state["timeout"] = round(self._adaptive_timeout(), 1)
        except Exception:
            state["timeout"] = float(NETWORK_TIMEOUT)
        return state

    def _endpoint_available(self, endpoint):
        try:
            failed_at = float(self._endpoint_failures.get(endpoint, 0) or 0)
            return not failed_at or (time.time() - failed_at >= self._endpoint_cooldown)
        except Exception:
            return True

    def _mark_endpoint_result(self, endpoint, success):
        try:
            if success:
                self._endpoint_failures.pop(endpoint, None)
            else:
                self._endpoint_failures[endpoint] = time.time()
        except Exception:
            pass

    def _stalker_json_request(self, url, timeout=None, request_headers=None, cancel_event=None):
        """Read one bounded Stalker JSON response without relying on EOF.

        Some legacy Ministra/Stalker front ends send a complete JSON document and
        then leave the connection open despite ``Connection: close``.  The
        generic ``urlopen(...).read()`` transport waits for EOF, times out, and
        loses the usable body.  This Stalker-only reader returns as soon as a
        complete JSON document is received, while retaining the same bounded
        timeout and an explicit response-size limit.
        """
        _raise_if_stalker_cancelled(cancel_event)
        parsed = urlparse(url)
        host = parsed.hostname
        if not host:
            raise RuntimeError("Invalid Stalker portal URL")
        try:
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
        except Exception:
            port = 443 if parsed.scheme == "https" else 80
        target = parsed.path or "/"
        if parsed.query:
            target += "?" + parsed.query
        request_headers = dict(request_headers or self.headers())
        request_headers["Host"] = parsed.netloc
        request_headers["Connection"] = "close"
        request_headers["Accept"] = "*/*"
        lines = ["GET %s HTTP/1.0" % target]
        for key, value in request_headers.items():
            lines.append("%s: %s" % (key, value))
        wire = "\r\n".join(lines) + "\r\n\r\n"
        try:
            payload = wire.encode("utf-8")
        except Exception:
            payload = wire
        # eStalker-style network bounds: fail a dead connection quickly,
        # while still allowing a slower portal up to 10 seconds to return JSON.
        read_timeout = float(timeout or NETWORK_TIMEOUT)
        connect_timeout = min(5.0, read_timeout)
        sock = socket.create_connection((host, port), connect_timeout)
        try:
            if parsed.scheme == "https":
                try:
                    context = ssl._create_unverified_context()
                    sock = context.wrap_socket(sock, server_hostname=host)
                except Exception:
                    sock = ssl.wrap_socket(sock, cert_reqs=ssl.CERT_NONE)
            sock.sendall(payload)
            sock.settimeout(read_timeout)
            received = b""
            header_end = -1
            body = b""
            status = ""
            limit = 16 * 1024 * 1024
            deadline = time.time() + read_timeout
            response = None
            while time.time() < deadline and len(received) < limit:
                _raise_if_stalker_cancelled(cancel_event)
                try:
                    chunk = sock.recv(65536)
                except socket.timeout:
                    break
                if not chunk:
                    break
                received += chunk
                _raise_if_stalker_cancelled(cancel_event)
                if header_end < 0:
                    header_end = received.find(b"\r\n\r\n")
                    if header_end < 0:
                        continue
                    try:
                        status = received[:header_end].decode("iso-8859-1", "replace").split("\r\n", 1)[0]
                    except Exception:
                        status = ""
                raw_headers = received[:header_end]
                body = received[header_end + 4:]
                try:
                    decoded_body, response_headers = _decode_stalker_http_body(raw_headers, body)
                    self._remember_set_cookie(response_headers)
                    response = json.loads(decoded_body.decode("utf-8", "replace").strip())
                    break
                except Exception:
                    response = None
                    try:
                        content_length = int(_http_headers_map(raw_headers).get("content-length", "0") or 0)
                    except Exception:
                        content_length = 0
                    if content_length and len(body) >= content_length:
                        break
            else:
                response = None
            if response is None and header_end >= 0:
                try:
                    raw_headers = received[:header_end]
                    decoded_body, response_headers = _decode_stalker_http_body(raw_headers, body)
                    response = json.loads(decoded_body.decode("utf-8", "replace").strip())
                except Exception:
                    response = None
            if response is None:
                raise RuntimeError("Stalker portal did not return complete JSON")
            if status and not status.startswith("HTTP/"):
                raise RuntimeError("Invalid Stalker HTTP response")
            return response
        finally:
            try:
                sock.close()
            except Exception:
                pass

    def _estalker_session_json(self, endpoint, query, headers=None, cancel_event=None, timeout=None):
        """Exact EStalker 1.45-style GET using the persistent requests.Session."""
        _raise_if_stalker_cancelled(cancel_event)
        if self._estalker_http is None:
            raise RuntimeError("requests.Session unavailable")
        request_headers = dict(headers or self._estalker_headers(endpoint))
        response = self._estalker_http.get(
            endpoint + ("&" if "?" in endpoint else "?"),
            headers=request_headers,
            params=query,
            timeout=(min(5.0, float(timeout or NETWORK_TIMEOUT)), float(timeout or NETWORK_TIMEOUT)),
            verify=False,
            allow_redirects=True
        )
        response.raise_for_status()
        _raise_if_stalker_cancelled(cancel_event)
        try:
            return response.json()
        except Exception:
            return json.loads(str(response.text or "").strip())

    def _request_endpoint(self, endpoint, query, cancel_event=None):
        # r152 Endurance Guard: every Stalker HTTP path shares one small global
        # concurrency ceiling.  This complements the existing bounded artwork
        # queue/task manager and prevents slow portals from piling up requests.
        gate_wait = max(2.0, min(6.0, float(self._adaptive_timeout()) * 0.5))
        with stalker_request_slot(wait_seconds=gate_wait):
            return self._request_endpoint_guarded(endpoint, query, cancel_event=cancel_event)

    def _request_endpoint_guarded(self, endpoint, query, cancel_event=None):
        _raise_if_stalker_cancelled(cancel_event)
        separator = "&" if "?" in endpoint else "?"
        action = query.get("action", "")
        kind = query.get("type", "")
        started = time.time()
        adaptive_timeout = self._adaptive_timeout()
        url = endpoint + separator + urlencode(query)
        last_error = None
        request_modes = [
            ("normal", None, False),
            ("estalker", self._estalker_headers(endpoint), False),
        ]
        if self._estalker_http is not None:
            request_modes.append(("estalker_session", self._estalker_headers(endpoint), True))
        for header_mode, request_headers, use_session in request_modes:
            _raise_if_stalker_cancelled(cancel_event)
            try:
                response = (
                    self._estalker_session_json(endpoint, query, request_headers, cancel_event=cancel_event, timeout=adaptive_timeout)
                    if use_session else
                    self._stalker_json_request(url, timeout=adaptive_timeout, request_headers=request_headers, cancel_event=cancel_event)
                )
                error = self._response_error(response)
                if error:
                    raise RuntimeError(error)
                if not isinstance(self._decode(response), dict):
                    raise RuntimeError("Portal returned an invalid response")
                elapsed_ms = int((time.time() - started) * 1000)
                self._record_portal_health(elapsed_ms, True)
                stalker_log("HTTP OK mode=%s type=%s action=%s endpoint=%s ms=%d adaptive_timeout=%.1fs" % (header_mode, kind, action, endpoint, elapsed_ms, adaptive_timeout))
                return response
            except StalkerCancelledError:
                raise
            except Exception as exc:
                last_error = exc
                if header_mode != request_modes[-1][0]:
                    stalker_log("HTTP retry mode=%s type=%s action=%s endpoint=%s error=%s" % (header_mode, kind, action, endpoint, exc))
                    continue
                stalker_log("HTTP FAIL mode=%s type=%s action=%s endpoint=%s ms=%d error=%s" % (header_mode, kind, action, endpoint, int((time.time()-started)*1000), exc))
        self._record_portal_health(None, False)
        raise last_error or RuntimeError("Portal request failed")

    def call(self, _cancel_event=None, **query):
        """Call compatible endpoints with short-term health memory.

        The last successful endpoint remains first. Temporarily failing
        alternatives are skipped for a few seconds, which prevents a dead
        /portal.php or /server/load.php fallback from slowing every request.
        """
        _raise_if_stalker_cancelled(_cancel_event)
        choices = []
        endpoints = self.endpoints()
        if self._endpoint:
            choices.append(self._endpoint)
            active_scheme = (urlparse(self._endpoint).scheme or "").lower()
            for candidate in endpoints:
                if (urlparse(candidate).scheme or "").lower() == active_scheme and candidate not in choices:
                    choices.append(candidate)
        for candidate in endpoints:
            if candidate not in choices:
                choices.append(candidate)
        if not choices:
            raise RuntimeError("Portal URL is empty")

        healthy = [value for value in choices if self._endpoint_available(value)]
        if healthy:
            choices = healthy

        last_error = None
        for endpoint in choices:
            _raise_if_stalker_cancelled(_cancel_event)
            try:
                response = self._request_endpoint(endpoint, query, cancel_event=_cancel_event)
                self._mark_endpoint_result(endpoint, True)
                self._endpoint = endpoint
                save_stalker_compat(self.portal, self.mac, endpoint=endpoint, stb_type=self.stb_type)
                return response
            except StalkerCancelledError:
                raise
            except Exception as exc:
                self._mark_endpoint_result(endpoint, False)
                last_error = exc
        raise last_error or RuntimeError("Portal request failed")

    def handshake(self):
        if self._estalker_http is None:
            return False
        parsed = urlparse(self.configured_portal or self.portal or "")
        host = "%s://%s" % (parsed.scheme or "http", parsed.netloc)
        original_path = (parsed.path or "").rstrip("/") + "/"
        if original_path.endswith("/stalker_portal/c/"):
            path_prefix = "/stalker_portal/c/"
        elif original_path.endswith("/c/"):
            path_prefix = "/c/"
        else:
            path_prefix = "/c/"

        timezone = _stalker_local_timezone()
        referer = (self.configured_portal or host).rstrip("/") + "/index.html"
        headers = self._native145_build_headers(host, self.mac, timezone, referer)

        path_prefix = self._native145_path_prefix(host, headers, path_prefix)
        portal = self._native145_portal_url(host, headers, path_prefix)
        portal_version = self._native145_portal_version(host, headers, path_prefix)
        token, token_random = self._native145_handshake_only(portal, self.mac, headers)

        if not token:
            self._endpoint = ""
            self.token = ""
            self.token_random = ""
            self._profile_ready = False
            self._native145_headers = {}
            stalker_log("HANDSHAKE EStalker146 native failed")
            return False

        self.portal = portal.rstrip("/")
        self.path_prefix = path_prefix
        self.portal_version = portal_version
        self._endpoint = self.portal
        self.token = str(token)
        self.token_random = str(token_random or "")
        self._native145_headers = dict(headers)
        self._profile_ready = False
        self._modules_ready = False
        self.stb_type = "MAG250"
        save_stalker_compat(
            self.configured_portal, self.mac,
            portal=self.portal,
            path_prefix=self.path_prefix,
            portal_version=self.portal_version, endpoint=self._endpoint,
            stb_type=self.stb_type
        )
        with _CATALOG_LOCK:
            _lru_put(_STALKER_TOKENS, self._token_key, (
                self.token, time.time(), False, False, self._endpoint, self.stb_type
            ), _STALKER_TOKEN_LIMIT)
        try:
            persistent_cache_set(self._capability_key, "stalker:capabilities", {
                "portal": self.portal, "endpoint": self._endpoint,
                "path_prefix": self.path_prefix, "portal_version": self.portal_version,
                "stb_type": self.stb_type
            }, _STALKER_CAPABILITY_TTL)
        except Exception:
            pass
        stalker_log("HANDSHAKE EStalker146 native success endpoint=%s token=%s" % (
            self._endpoint, _mask_token(self.token)))
        return True

    def _ensure_token(self):
        return bool(self.token) or self.handshake()

    def _drop_token(self):
        self.token = ""
        self.token_random = ""
        self._profile_ready = False
        self._modules_ready = False
        with _CATALOG_LOCK:
            _STALKER_TOKENS.pop(self._token_key, None)

    def reauthorize(self):
        stalker_log("REAUTHORIZE start portal=%s mac=%s" % (self.portal, _mask_mac(self.mac)))
        self._drop_token()
        if not self.handshake():
            stalker_log("REAUTHORIZE failed stage=handshake")
            return False
        if not self._ensure_profile():
            stalker_log("REAUTHORIZE failed stage=profile")
            return False
        account_ok = self._account_info()
        if not account_ok:
            # EStalker performs a basic get_profile after account validation fails.
            # Keep it as recovery only so working portals stay on the normal path.
            try:
                timestamp = str(int(time.time()))
                response = self.call(type="stb", action="get_profile", sn=self.serial,
                                     device_id="", timestamp=timestamp, JsHttpRequest="1-xml") or {}
                js = self._portal_js(response)
                if isinstance(js, dict) and js:
                    self.play_token = str(js.get("play_token") or self.play_token or "")
                    self.account_status = js.get("status", self.account_status)
                    self.blocked = str(js.get("blocked", self.blocked or "0"))
                    stalker_log("REAUTHORIZE EStalker basic profile recovery success")
            except Exception as exc:
                stalker_log("REAUTHORIZE EStalker basic profile recovery failed error=%s" % exc)
        stalker_log("REAUTHORIZE success endpoint=%s token=%s play_token=%s status=%s blocked=%s" % (
            self._endpoint, _mask_token(self.token), bool(self.play_token),
            self.account_status, self.blocked))
        return True

    def _ensure_profile(self):
        if self._profile_ready:
            return True
        if not self._ensure_token():
            return False
        headers = dict(self._native145_headers or {})
        if not headers:
            return False

        play_token, status, blocked, returned_mac, returned_id = self._native145_profile(
            self.portal, self.mac, self.token_random, headers, "full"
        )
        expiry, account_valid = self._native145_account_info(self.portal, headers)

        if not account_valid:
            play_token, status, blocked, returned_mac, returned_id = self._native145_profile(
                self.portal, self.mac, self.token_random, headers, "basic"
            )
            expiry, account_valid = self._native145_account_info(self.portal, headers)

        if not account_valid:
            self._profile_ready = False
            stalker_log("PROFILE EStalker146 native failed account_info")
            return False

        self.play_token = str(play_token or "")
        self.account_status = status
        self.blocked = str(blocked or "0")
        self.returned_mac = str(returned_mac or "")
        self.returned_id = str(returned_id or "")
        self.expiry = str(expiry or "")
        self.account_valid = True
        self.stb_type = "MAG250"
        self._profile_ready = True

        save_stalker_compat(
            self.configured_portal, self.mac,
            expiry=self.expiry, play_token=self.play_token,
            status=self.account_status, blocked=self.blocked,
            returned_mac=self.returned_mac, returned_id=self.returned_id,
            portal=self.portal,
            path_prefix=self.path_prefix,
            portal_version=self.portal_version,
            endpoint=self._endpoint, stb_type=self.stb_type
        )
        with _CATALOG_LOCK:
            _lru_put(_STALKER_TOKENS, self._token_key, (
                self.token, time.time(), True, self._modules_ready,
                self._endpoint, self.stb_type
            ), _STALKER_TOKEN_LIMIT)
        stalker_log("PROFILE EStalker146 native success status=%s blocked=%s" % (
            self.account_status, self.blocked))
        try:
            self._warm_xtream_fast_path()
        except Exception:
            pass
        self._schedule_prefetch()
        return True

    def _ensure_modules(self):
        """Warm portal modules once when supported; never block a working portal."""
        if self._modules_ready:
            return True
        self._modules_ready = True
        try:
            self.call(type="stb", action="get_modules", JsHttpRequest="1-xml")
            stalker_log("MODULES success")
        except Exception as exc:
            stalker_log("MODULES optional error=%s" % exc)
        with _CATALOG_LOCK:
            if self.token:
                _lru_put(_STALKER_TOKENS, self._token_key, (self.token, time.time(), self._profile_ready, True, self._endpoint, self.stb_type), _STALKER_TOKEN_LIMIT)
        return True

    def test(self):
        """Fast Stalker connectivity test for the BLUE button.

        Only verifies portal discovery/handshake, MAG profile and the small
        Live categories endpoint.  It deliberately does not download channels
        or create a stream link, because those operations can take a long time
        on slow portals and are already exercised during normal Live playback.
        """
        result = {
            "ok": False,
            "token": False,
            "endpoint": "",
            "handshake": False,
            "profile": False,
            "categories": 0,
            "channels": 0,
            "live_link": False,
            "quick_test": True,
            "expiry": "",
            "stage": "handshake",
            "error": "",
        }
        try:
            result["handshake"] = bool(self.handshake())
            result["token"] = bool(self.token)
            result["endpoint"] = self._endpoint or ""
            if not result["handshake"]:
                result["error"] = "Handshake rejected or no token returned"
                return result

            result["stage"] = "profile"
            result["profile"] = bool(self._ensure_profile())
            result["expiry"] = str(self.expiry or "")
            if not result["profile"]:
                result["error"] = "Profile request failed"
                return result

            result["stage"] = "categories"
            categories = self.live_categories() or []
            result["categories"] = len(categories)
            result["ok"] = bool(result["handshake"] and result["profile"])
            result["stage"] = "complete" if result["ok"] else result["stage"]
            return result
        except Exception as exc:
            result["error"] = str(exc)
            result["endpoint"] = self._endpoint or result.get("endpoint", "")
            result["token"] = bool(self.token)
            return result

    def _native145_live_headers(self):
        """Exact EStalker 1.45 headers rebuilt by live.py/liveplayer.py."""
        portal = str(self.portal or self._endpoint or "")
        parsed = urlparse(portal or self.configured_portal or "")
        domain = parsed.hostname or ""
        port = parsed.port
        timezone = _stalker_local_timezone()
        encoded_mac = quote(self.mac, safe="")
        encoded_timezone = quote(timezone, safe="")
        host = "%s://%s" % (parsed.scheme or "http", parsed.netloc)
        referer = host + (self.path_prefix or "/c/") + "index.html"

        headers = {
            "Pragma": "no-cache",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "Host": "%s:%s" % (domain, port) if port else domain,
            "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
            "X-User-Agent": "Model: MAG250; Link: WiFi",
            "Connection": "Close",
            "Referer": referer,
        }
        if portal and "/stalker_portal/" in portal:
            headers["Cookie"] = "mac=%s; stb_lang=en; timezone=%s; adid=%s" % (
                encoded_mac, encoded_timezone, self.adid
            )
        else:
            headers["Cookie"] = "mac=%s; stb_lang=en; timezone=%s" % (
                encoded_mac, encoded_timezone
            )
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
        return headers

    def _native145_fresh_json_request(self, url, headers):
        """EStalker 1.45 make_request() behavior used by Live/Short EPG."""
        if requests is None:
            return None
        http = requests.Session()
        try:
            response = http.get(
                url, headers=headers, timeout=(5, 10),
                verify=False, allow_redirects=True
            )
            response.raise_for_status()
            try:
                return response.json()
            except ValueError:
                try:
                    return json.loads(response.text)
                except Exception:
                    return None
        except Exception:
            return None
        finally:
            try:
                http.close()
            except Exception:
                pass

    def _native145_reauthorize_live(self):
        """Exact EStalker 1.45 reauthorize_portal sequence for Live create_link."""
        if requests is None:
            return False
        http = requests.Session()
        try:
            headers = dict(self._native145_headers or {})
            if not headers:
                return False

            def req(params):
                try:
                    parsed_url = urlparse(self.portal + "?")
                    existing = dict(parse_qsl(parsed_url.query))
                    existing.update(params)
                    url = urlunparse(parsed_url._replace(query=urlencode(existing)))
                    response = http.get(
                        url, headers=headers, timeout=(5, 10),
                        verify=False, allow_redirects=True
                    )
                    response.raise_for_status()
                    try:
                        return response.json()
                    except ValueError:
                        try:
                            return json.loads(response.text)
                        except Exception:
                            return None
                except Exception:
                    return None

            # perform_handshake() exactly: no MAC first, then MAC.
            response = req({
                "type": "stb", "action": "handshake",
                "token": "", "JsHttpRequest": "1-xml"
            })
            if not response:
                response = req({
                    "type": "stb", "action": "handshake",
                    "token": "", "JsHttpRequest": "1-xml",
                    "mac": self.mac
                })

            token = None
            token_random = None
            if response and isinstance(response, dict):
                js_data = response.get("js", {})
                if isinstance(js_data, dict) and "msg" in js_data and "missing" in str(js_data["msg"]).lower():
                    fake_token = "".join(
                        random.choice(string.ascii_uppercase + string.digits)
                        for _ in range(32)
                    )
                    prehash = hashlib.sha1(fake_token.encode()).hexdigest()
                    headers["Authorization"] = "Bearer " + fake_token
                    response = req({
                        "type": "stb", "action": "handshake",
                        "JsHttpRequest": "1-xml", "mac": self.mac,
                        "prehash": prehash
                    })
                    js_data = response.get("js", {}) if response else {}

                if isinstance(js_data, dict):
                    token = js_data.get("token")
                    token_random = js_data.get("random", "")
                    if token:
                        headers["Authorization"] = "Bearer " + token
                        headers["Cookie"] = headers.get("Cookie", "") + "; token=" + token

            if not token:
                return False

            # Use the exact existing native EStalker profile payload, but with
            # this reauthorization Session just like reauthorize_portal().
            old_http = self._estalker_http
            self._estalker_http = http
            try:
                play_token, status, blocked, returned_mac, returned_id = self._native145_profile(
                    self.portal, self.mac, token_random, headers, "full"
                )
                expiry, account_valid = self._native145_account_info(self.portal, headers)
                if not account_valid:
                    play_token, status, blocked, returned_mac, returned_id = self._native145_profile(
                        self.portal, self.mac, token_random, headers, "basic"
                    )
            finally:
                self._estalker_http = old_http

            self.token = str(token)
            self.token_random = str(token_random or "")
            self._native145_headers = dict(headers)
            self.play_token = str(play_token or "")
            self.account_status = status
            self.blocked = str(blocked or "0")
            self.returned_mac = str(returned_mac or "")
            self.returned_id = str(returned_id or "")
            if expiry:
                self.expiry = str(expiry)
            self._profile_ready = True
            stalker_log("REAUTH EStalker146 live success")
            return True
        finally:
            try:
                http.close()
            except Exception:
                pass

    def _short_epg_request(self, ch_id, limit=10, timeout=6.0):
        channel_id = str(ch_id or "").strip()
        if not self._ensure_token():
            raise RuntimeError("Stalker handshake was rejected by the portal")
        if not self._ensure_profile():
            raise RuntimeError("Stalker profile request failed")

        # Exact EStalker 1.45 Short EPG URL. It does not add JsHttpRequest
        # and it does not cycle endpoints or reauthorize here.
        url = (
            self.portal +
            "?type=itv&action=get_short_epg&ch_id=%s&limit=10&size=10" %
            channel_id
        )
        response = self._native145_fresh_json_request(
            url, self._native145_live_headers()
        )
        return response or {}

    def _normalise_short_epg_rows(self, payload, ch_id):
        candidate = self._portal_js(payload)
        if isinstance(candidate, dict):
            candidate = candidate.get("data") or candidate.get("items") or candidate.get("epg") or candidate.get("list") or []
        if not isinstance(candidate, list):
            return []
        rows = []
        for raw in candidate:
            if not isinstance(raw, dict):
                continue
            item = dict(raw)
            item.setdefault("ch_id", str(ch_id))
            if not item.get("title"):
                item["title"] = item.get("name") or item.get("programme") or item.get("event_name") or ""
            if not item.get("description"):
                item["description"] = item.get("descr") or item.get("desc") or item.get("plot") or ""
            if not item.get("start_timestamp"):
                item["start_timestamp"] = item.get("start") or item.get("begin_timestamp") or item.get("begin") or item.get("time")
            if not item.get("stop_timestamp"):
                item["stop_timestamp"] = item.get("stop") or item.get("end_timestamp") or item.get("end") or item.get("time_to")
            rows.append(item)
        return rows

    def short_epg(self, ch_id, limit=10, force=False):
        channel_id = str(ch_id or "").strip()
        if not channel_id:
            return []
        try:
            limit = max(1, min(20, int(limit or 10)))
        except Exception:
            limit = 10
        cache_key = (self._token_key, channel_id, limit)
        if not force:
            with _CATALOG_LOCK:
                cached = _lru_get(_STALKER_EPG_CACHE, cache_key)
            if cached and time.time() - cached[0] < _STALKER_EPG_TTL:
                return [dict(row) for row in (cached[1] or [])]
            disk_rows = self._persistent_get("short_epg", channel_id, limit)
            if isinstance(disk_rows, list):
                with _CATALOG_LOCK:
                    _lru_put(_STALKER_EPG_CACHE, cache_key, (time.time(), [dict(row) for row in disk_rows if isinstance(row, dict)]), _STALKER_EPG_MEMORY_LIMIT)
                return [dict(row) for row in disk_rows if isinstance(row, dict)]
        last_error = None
        for attempt in range(3):
            try:
                response = self._short_epg_request(channel_id, limit=limit, timeout=6.0)
                rows = self._normalise_short_epg_rows(response, channel_id)
                if rows:
                    with _CATALOG_LOCK:
                        _lru_put(_STALKER_EPG_CACHE, cache_key, (time.time(), [dict(row) for row in rows]), _STALKER_EPG_MEMORY_LIMIT)
                    self._persistent_set("short_epg", [dict(row) for row in rows], _STALKER_EPG_TTL, channel_id, limit)
                    return rows
                last_error = RuntimeError("empty short EPG response")
            except Exception as exc:
                last_error = exc
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
        stalker_log("SHORT_EPG failed ch=%s error=%s" % (channel_id, last_error or "empty"))
        return []

    def short_epg_batch(self, channel_ids, limit=10, done_callback=None, partial_callback=None):
        ids=[]; seen=set()
        for value in (channel_ids or []):
            ch_id=str(value or "").strip()
            if ch_id and ch_id not in seen: seen.add(ch_id); ids.append(ch_id)
        state={"rows":[],"failed":set()}
        if not ids:
            payload={"js":[],"failed_ids":[]}
            if done_callback:
                try: done_callback(payload)
                except Exception: pass
            return payload
        lock=threading.RLock(); sem=threading.BoundedSemaphore(2)
        def fetch(ch_id,force=False):
            with sem:
                try: rows=self.short_epg(ch_id,limit=limit,force=force) or []
                except Exception: rows=[]
            with lock:
                if rows:
                    state["rows"].extend(rows); state["failed"].discard(ch_id)
                else: state["failed"].add(ch_id)
            if rows and partial_callback:
                try: partial_callback({"js":[dict(row) for row in rows]})
                except Exception: pass
        threads=[]
        for ch_id in ids:
            t=threading.Thread(target=fetch,args=(ch_id,False),name="TiviMateStalkerShortEPG")
            t.daemon=True; t.start(); threads.append(t)
        def waiter():
            for t in threads:
                try: t.join(22.0)
                except Exception: pass
            with lock: retry=list(state["failed"])
            if retry:
                time.sleep(0.6)
                rthreads=[]
                for ch_id in retry:
                    t=threading.Thread(target=fetch,args=(ch_id,True),name="TiviMateStalkerShortEPGRetry")
                    t.daemon=True; t.start(); rthreads.append(t)
                for t in rthreads:
                    try: t.join(12.0)
                    except Exception: pass
            with lock: payload={"js":[dict(x) for x in state["rows"]],"failed_ids":list(state["failed"])}
            if done_callback:
                try: done_callback(payload)
                except Exception: pass
        done=threading.Thread(target=waiter,name="TiviMateStalkerShortEPGDone")
        done.daemon=True; done.start()
        return state


    def _call_retry(self, _cancel_event=None, **query):
        _raise_if_stalker_cancelled(_cancel_event)
        action = str(query.get("action") or "")
        api_type = str(query.get("type") or "")
        marker = (self._token_key, api_type, action)
        started = time.time()

        # Short exponential backoff only after repeated failures. This avoids
        # hammering a slow portal while still allowing the first retry.
        now = time.time()
        state = _STALKER_BACKOFF.get(marker)
        if state:
            failures, retry_at = state
            if retry_at > now:
                wait_ms = int((retry_at - now) * 1000)
                stalker_log("BACKOFF type=%s action=%s wait_ms=%d" % (api_type, action, wait_ms))
                raise RuntimeError("Stalker portal is in short backoff")

        stalker_log("CALL type=%s action=%s token=%s" % (
            api_type, action, _mask_token(self.token)
        ))
        if not self._ensure_token():
            raise RuntimeError("Stalker handshake was rejected by the portal")
        self._ensure_profile()

        first_exc = None
        try:
            response = self.call(_cancel_event=_cancel_event, **query) or {}
            js = self._portal_js(response)
            if response and (js not in (None, "", [], {})):
                _STALKER_BACKOFF.pop(marker, None)
                stalker_log("TIMING type=%s action=%s ms=%d retry=0" % (
                    api_type, action, int((time.time() - started) * 1000)
                ))
                return response
            raise RuntimeError("Stalker portal returned an empty response")
        except StalkerCancelledError:
            raise
        except Exception as exc:
            first_exc = exc
            stalker_log("CALL first failure type=%s action=%s error=%s" % (
                api_type, action, exc
            ))

        # One controlled reauthorization only.
        self._drop_token()
        self._profile_ready = False
        self._modules_ready = False
        try:
            if not self._ensure_token():
                raise RuntimeError("Stalker session could not be renewed")
            self._ensure_profile()
            response = self.call(_cancel_event=_cancel_event, **query) or {}
            js = self._portal_js(response)
            if not response or js in (None, "", [], {}):
                raise RuntimeError("Stalker portal returned an empty response after retry")
            _STALKER_BACKOFF.pop(marker, None)
            stalker_log("TIMING type=%s action=%s ms=%d retry=1" % (
                api_type, action, int((time.time() - started) * 1000)
            ))
            return response
        except StalkerCancelledError:
            raise
        except Exception as second_exc:
            prev = _STALKER_BACKOFF.get(marker) or (0, 0)
            failures = min(5, int(prev[0] or 0) + 1)
            delay = min(30.0, 2.0 ** failures)
            _STALKER_BACKOFF[marker] = (failures, time.time() + delay)
            stalker_log("TIMING_FAIL type=%s action=%s ms=%d backoff=%ds error=%s" % (
                api_type, action, int((time.time() - started) * 1000), int(delay), second_exc
            ))
            raise second_exc or first_exc

    def _portal_rows(self, response):
        """Return a row list from the common Stalker/Ministra response envelopes.

        Different portal versions put the same list below ``js``, ``data``,
        ``result``, ``items`` or a JSON-encoded variant of one of those fields.
        The traversal is deliberately bounded and read-only.
        """
        pending = [self._portal_js(response)]
        visited = set()
        list_keys = ("data", "items", "channels", "results", "list", "content", "rows", "movies", "series", "vod")
        wrapper_keys = ("js", "data", "result", "results", "response", "payload", "content", "list")
        while pending:
            candidate = self._decode(pending.pop(0))
            if isinstance(candidate, list):
                return candidate
            if not isinstance(candidate, dict):
                continue
            marker = id(candidate)
            if marker in visited:
                continue
            visited.add(marker)
            for key in list_keys:
                value = self._decode(candidate.get(key))
                if isinstance(value, list):
                    return value
            for key in wrapper_keys:
                value = self._decode(candidate.get(key))
                if isinstance(value, (dict, list)):
                    pending.append(value)
        return []

    def _portal_payload(self, response):
        """Return the useful payload while preserving detail dictionaries."""
        js = self._portal_js(response)
        if not isinstance(js, dict):
            return js
        for key in ("data", "result", "results", "response", "payload", "content"):
            value = self._decode(js.get(key))
            if isinstance(value, (dict, list)):
                return value
        return js

    def _categories(self, api_type, actions, _refresh_only=False):
        """Fetch packages with stale-while-revalidate and six-hour fresh TTL."""
        action_key = ",".join([str(x) for x in actions])
        cached_rows, fresh = self._persistent_peek("categories", api_type, action_key)
        if isinstance(cached_rows, list) and cached_rows and not _refresh_only:
            rows = [dict(row) for row in cached_rows if isinstance(row, dict)]
            if fresh:
                return rows
            self._refresh_background(
                "categories:%s:%s" % (api_type, action_key),
                lambda: self._categories(api_type, actions, _refresh_only=True)
            )
            stalker_log("SWR categories type=%s stale_rows=%d" % (api_type, len(rows)))
            return rows

        for action in actions:
            try:
                response = self._call_retry(type=api_type, action=action, JsHttpRequest="1-xml")
            except Exception:
                continue
            rows, seen = [], set()
            for item in self._portal_rows(response):
                if not isinstance(item, dict):
                    continue
                if api_type == "itv" and action == "get_genres":
                    cid = item.get("id")
                else:
                    cid = item.get("id") or item.get("category_id") or item.get("genre_id") or item.get("value") or item.get("alias") or item.get("category")
                if cid is None or str(cid).strip() == "":
                    continue
                cid = str(cid)
                if cid in seen:
                    continue
                seen.add(cid)
                title = item.get("title") or item.get("name") or item.get("category_name") or item.get("alias") or item.get("label") or "Other"
                rows.append({
                    "category_id": cid, "genre_id": cid,
                    "category_name": title,
                    "_stalker_category_type": item.get("type") or item.get("content_type") or "",
                    "_stalker_is_series": item.get("is_series") or item.get("series") or "",
                })
            if rows:
                self._persistent_set("categories", rows, _STALKER_CATEGORY_TTL, api_type, action_key)
                return rows

        if isinstance(cached_rows, list) and cached_rows:
            return [dict(row) for row in cached_rows if isinstance(row, dict)]
        return []

    def _list_query_variants(self, api_type, action, category_id, page):
        """Build a short, ordered list of non-conflicting catalog requests.

        IPTV keeps the r105 request unchanged.  VOD/Series portals differ on
        whether a package is called ``category``, ``genre`` or ``category_id``;
        sending all aliases together causes valid portals to return an empty list.
        """
        # Live is kept intentionally identical to EStalker's request shape:
        # type=itv&action=get_ordered_list&genre=<id>&sortby=number&p=<page>
        # &JsHttpRequest=1-xml
        if api_type == "itv":
            query = {
                "type": "itv",
                "action": action,
                "sortby": "number",
                "p": str(page),
                "JsHttpRequest": "1-xml",
            }
            if category_id:
                query["genre"] = str(category_id)
                return [query]
            # Keep the existing request first, then exact EStalker genre=* fallback.
            star = dict(query)
            star["genre"] = "*"
            return [query, star]

        base = {
            "type": api_type, "action": action, "p": str(page), "fav": "0",
            "hd": "1", "force_ch_link_check": "0", "JsHttpRequest": "1-xml"
        }
        if api_type not in ("vod", "series"):
            query = dict(base)
            query["sortby"] = "number"
            return [query]
        if not category_id:
            query = dict(base)
            query["sortby"] = "number"
            return [query]
        variants, seen = [], set()

        def add_query(query):
            marker = tuple(sorted((str(key), str(value)) for key, value in query.items()))
            if marker not in seen:
                seen.add(marker)
                variants.append(query)

        # The ordinary MAG convention is category.  It is tried first to keep
        # normal portals just as quick as r105.
        for key in ("category", "genre", "category_id", "genre_id"):
            query = dict(base)
            query["sortby"] = "number"
            query[key] = str(category_id)
            add_query(query)
            # Some older forks reject an unknown sortby field completely.
            query = dict(base)
            query[key] = str(category_id)
            add_query(query)
        query = dict(base)
        query["sortby"] = "number"
        query["category"] = str(category_id)
        query["genre"] = str(category_id)
        add_query(query)
        return variants

    def _portal_total(self, response):
        for payload in (self._portal_js(response), self._portal_payload(response)):
            if not isinstance(payload, dict):
                continue
            for key in ("total_items", "total", "total_count", "count"):
                try:
                    value = int(payload.get(key) or 0)
                except Exception:
                    value = 0
                if value:
                    return value
        return 0

    def _paged_rows(self, api_type, action, category_id="", max_pages=None):
        # EStalker-compatible Live pagination. Ministra get_ordered_list uses
        # 14 rows per page. Keep provider positions and duplicates exactly as
        # returned instead of applying a client-side identity de-duplication.
        if api_type == "itv" and action == "get_ordered_list":
            page = 1
            total = 0
            slots = []
            downloaded = set()
            safety_pages = 500
            while page <= safety_pages:
                response = None
                page_rows = []
                query = None
                for candidate in self._list_query_variants(api_type, action, category_id, page):
                    marker = tuple(sorted((str(k), str(v)) for k, v in candidate.items()))
                    if marker in downloaded:
                        continue
                    downloaded.add(marker)
                    try:
                        candidate_response = self._call_retry(**candidate)
                    except Exception:
                        continue
                    candidate_rows = self._portal_rows(candidate_response)
                    if candidate_rows:
                        query = candidate
                        response = candidate_response
                        page_rows = candidate_rows
                        break
                if not page_rows:
                    break
                if page == 1:
                    total = self._portal_total(response)
                    if total > 0:
                        slots = [{} for _ in range(total)]
                if not page_rows:
                    break
                if slots:
                    start_index = (page - 1) * 14
                    for offset, item in enumerate(page_rows):
                        pos = start_index + offset
                        if pos < len(slots) and isinstance(item, dict):
                            slots[pos] = item
                else:
                    for item in page_rows:
                        if isinstance(item, dict):
                            slots.append(item)
                if total and page * 14 >= total:
                    break
                if not total and len(page_rows) < 14:
                    break
                page += 1
            return [item for item in slots if isinstance(item, dict) and item]

        # Existing compatibility pagination remains for VOD/Series.
        max_pages = self.PAGE_LIMIT if max_pages is None else max(1, int(max_pages))
        rows, seen = [], set()
        page = 1
        while page <= max_pages:
            page_rows, total = [], 0
            for query in self._list_query_variants(api_type, action, category_id, page):
                try:
                    response = self._call_retry(**query)
                except Exception:
                    continue
                candidate = self._portal_rows(response)
                if candidate:
                    page_rows = candidate
                    total = self._portal_total(response)
                    break
            if not page_rows:
                break
            added = 0
            for item in page_rows:
                if not isinstance(item, dict):
                    continue
                identity = str(item.get("id") or item.get("stream_id") or item.get("vod_id") or item.get("movie_id") or item.get("series_id") or item.get("cmd") or item.get("name") or item.get("title") or "")
                if identity and identity in seen:
                    continue
                if identity:
                    seen.add(identity)
                rows.append(item)
                added += 1
            if not added or (total and len(rows) >= total) or (len(page_rows) < 2 and not total):
                break
            page += 1
        return rows

    def _normalise_live(self, item):
        """Normalize one Ministra live row using EStalker 1.45 semantics."""
        item = dict(item or {})
        sid = item.get("id") or item.get("stream_id") or item.get("channel_id") or item.get("ch_id")
        ch_id = item.get("id") or item.get("ch_id") or item.get("stream_id") or item.get("channel_id")
        cid = item.get("tv_genre_id") or item.get("genre_id") or item.get("category_id") or item.get("genre") or ""

        logo = str(item.get("logo") or item.get("stream_icon") or item.get("icon") or item.get("screenshot_uri") or "").strip()
        if not logo.startswith(("http://", "https://")):
            logo = ""
        elif logo.startswith("https://vignette.wikia.nocookie.net/tvfanon6528") and "scale-to-width-down" not in logo:
            logo += "/revision/latest/scale-to-width-down/220"

        return {
            "stream_id": str(sid or ""),
            "id": str(sid or ""),
            "ch_id": str(ch_id or ""),
            "name": item.get("name") or item.get("title") or "CHANNEL",
            "title": item.get("name") or item.get("title") or "CHANNEL",
            "number": str(item.get("number") or ""),
            "category_id": str(cid),
            "genre_id": str(cid),
            "stream_icon": logo,
            "logo": logo,
            "description": "",
            "plot": "",
            "cmd": str(item.get("cmd") or item.get("command") or ""),
            "_stalker_live": True,
        }

    def _channels_network_refresh(self):
        started = time.time()
        response = self._call_retry(type="itv", action="get_all_channels", JsHttpRequest="1-xml")
        rows = self._portal_rows(response)
        if not rows:
            rows = self._paged_rows("itv", "get_ordered_list", max_pages=1)
        items = [self._normalise_live(item) for item in rows if isinstance(item, dict)]
        if items:
            self._live_mem_set("all", items)
            self._persistent_set("channels_all", items, _STALKER_CHANNEL_TTL)
            # Keep the legacy alias synchronized for local bouquet pagination.
            self._persistent_set("live_all", items, _STALKER_CHANNEL_TTL)
        stalker_log("FULL_CATALOG rows=%d ms=%d" % (
            len(items), int((time.time() - started) * 1000)
        ))
        return items

    def channels(self):
        memory = self._live_mem_get("all")
        if isinstance(memory, list) and memory:
            return [dict(row) for row in memory if isinstance(row, dict)]

        cached, fresh = self._persistent_peek("channels_all")
        if not isinstance(cached, list) or not cached:
            cached, fresh = self._persistent_peek("live_all")
        if isinstance(cached, list) and cached:
            rows = [dict(row) for row in cached if isinstance(row, dict)]
            self._live_mem_set("all", rows)
            if not fresh:
                self._refresh_background("full_catalog", self._channels_network_refresh)
                stalker_log("SWR full_catalog stale_rows=%d" % len(rows))
            return rows

        return self._channels_network_refresh()

    def live_categories(self):
        rows = self._categories("itv", ("get_genres", "get_categories"))
        if rows:
            return rows
        categories, seen = [], set()
        for item in self.channels():
            cid = item.get("category_id") or item.get("genre_id")
            if not cid or cid in seen:
                continue
            seen.add(cid)
            categories.append({"category_id": str(cid), "genre_id": str(cid), "category_name": "Live TV"})
        return categories


    def live_page_cached(self, category_id="", page=1, sortby="number"):
        """Return one Stalker Live page only from RAM/persistent cache.

        Never performs a portal/network request.  The UI can use this to render
        an already-cached bouquet synchronously, avoiding the worker/timer path.
        """
        try:
            page = max(1, int(page or 1))
        except Exception:
            page = 1
        wanted = str(category_id or "").strip()
        sort_key = str(sortby or "number")

        memory_page = self._live_mem_get("page", wanted, page, sort_key)
        if isinstance(memory_page, dict) and isinstance(memory_page.get("items"), list):
            return memory_page

        cached = self._pcache_get("live_page", wanted, page, sort_key)
        if isinstance(cached, dict) and isinstance(cached.get("items"), list):
            self._live_mem_set("page", cached, wanted, page, sort_key)
            return cached

        all_rows = self._live_mem_get("all")
        if not all_rows:
            persisted_all = self._pcache_get("channels_all")
            if not isinstance(persisted_all, list) or not persisted_all:
                persisted_all = self._pcache_get("live_all")
            if isinstance(persisted_all, list) and persisted_all:
                all_rows = [dict(x) for x in persisted_all if isinstance(x, dict)]
                self._live_mem_set("all", all_rows)
        if not all_rows:
            return None

        filtered = []
        for item in all_rows:
            cid = str(item.get("category_id") or item.get("genre_id") or "").strip()
            if wanted and cid != wanted:
                continue
            filtered.append(dict(item))
        if sort_key.lower() == "number":
            def _num(row):
                try:
                    return int(str(row.get("number") or "0").strip())
                except Exception:
                    return 999999
            filtered.sort(key=_num)
        start = (page - 1) * 14
        local_items = filtered[start:start + 14]
        if not local_items and page != 1:
            return None
        result = {
            "items": local_items,
            "page": page,
            "total_items": len(filtered),
            "has_more": start + 14 < len(filtered),
        }
        self._live_mem_set("page", result, wanted, page, sort_key)
        self._pcache_set("live_page", result, STALKER_STREAM_TTL, wanted, page, sort_key)
        return result

    def _live_page_network_refresh(self, category_id="", page=1, sortby="number", cancel_event=None):
        # Keep Stalker Live category opening identical to EStalker 1.45:
        # type=itv&action=get_ordered_list&genre=<id>&sortby=number&p=<page>
        # &JsHttpRequest=1-xml.  _call_retry already performs exactly one
        # controlled re-authorization on a failed/empty portal response.
        query = {
            "type": "itv",
            "action": "get_ordered_list",
            "sortby": str(sortby or "number"),
            "p": str(page),
            "JsHttpRequest": "1-xml",
        }
        wanted = str(category_id or "").strip()
        if wanted:
            query["genre"] = wanted
        response = self._call_retry(_cancel_event=cancel_event, **query)
        _raise_if_stalker_cancelled(cancel_event)
        rows = self._portal_rows(response)
        total = self._portal_total(response)
        items = [self._normalise_live(row) for row in rows if isinstance(row, dict)]
        stalker_log("LIVE_PAGE estalker genre=%s page=%s rows=%d total=%d" % (
            wanted or "*", page, len(items), int(total or 0)
        ))

        result = {
            "items": items, "page": int(page),
            "total_items": int(total or 0),
            "has_more": bool(items) and (
                (int(total or 0) > 0 and int(page) * 14 < int(total or 0)) or
                (not int(total or 0) and len(items) >= 14)
            ),
        }
        if items:
            self._live_mem_set("page", result, wanted, int(page), str(sortby or "number"))
            self._persistent_set("live_page", result, _STALKER_PAGE_TTL, wanted, int(page), str(sortby or "number"))
        return result

    def live_page(self, category_id="", page=1, sortby="number", cancel_event=None, force_network=False):
        """Render local catalogue first; optionally bypass it for provider-restricted bouquets.

        Adult bouquets on some Ministra/Stalker portals are intentionally omitted or
        truncated in get_all_channels.  For those bouquets the UI requests the exact
        EStalker-style get_ordered_list page directly from the portal.
        """
        try:
            page = max(1, int(page or 1))
        except Exception:
            page = 1
        wanted = str(category_id or "").strip()
        sort_key = str(sortby or "number")

        if force_network:
            stalker_log("LIVE_PAGE direct_provider genre=%s page=%s" % (wanted or "*", page))
            return self._live_page_network_refresh(wanted, page, sort_key, cancel_event=cancel_event)

        # Fastest path: RAM/SQLite full catalogue -> local bouquet page.
        local = self.live_page_cached(wanted, page, sort_key)
        if isinstance(local, dict) and isinstance(local.get("items"), list) and local.get("items"):
            return local

        cached, fresh = self._persistent_peek("live_page", wanted, page, sort_key)
        if isinstance(cached, dict) and isinstance(cached.get("items"), list) and cached.get("items"):
            self._live_mem_set("page", cached, wanted, page, sort_key)
            if not fresh:
                self._refresh_background(
                    "live_page:%s:%s:%s" % (wanted, page, sort_key),
                    lambda: self._live_page_network_refresh(wanted, page, sort_key)
                )
                stalker_log("SWR live_page genre=%s page=%s rows=%d" % (
                    wanted, page, len(cached.get("items") or [])
                ))
            return cached

        return self._live_page_network_refresh(wanted, page, sort_key, cancel_event=cancel_event)

    def live_streams_direct(self, category_id="", sortby="number", cancel_event=None):
        """Fetch the complete Stalker Live bouquet directly from the portal.

        Used only for provider-restricted bouquets (Adult) where get_all_channels
        may be incomplete.  All Ministra get_ordered_list pages are collected in
        portal order, then normalised into one flat channel list.
        """
        wanted = str(category_id or "").strip()
        _raise_if_stalker_cancelled(cancel_event)
        rows = self._paged_rows("itv", "get_ordered_list", wanted)
        _raise_if_stalker_cancelled(cancel_event)
        items = [
            self._normalise_live(item) if not item.get("_stalker_live") else dict(item)
            for item in rows if isinstance(item, dict)
        ]
        # Keep numbering continuous even when the provider omits/duplicates the
        # displayed MAG channel number. This is UI numbering only.
        for index, item in enumerate(items):
            item["_tivimate_list_number"] = index + 1
        stalker_log("LIVE_FULL direct_provider genre=%s rows=%d" % (wanted or "*", len(items)))
        return items

    def live_streams(self, category_id="", sortby="number"):
        wanted = str(category_id or "").strip()
        cached = self._persistent_get("live_streams", wanted, str(sortby or "number"))
        if isinstance(cached, list) and cached:
            return [dict(row) for row in cached if isinstance(row, dict)]
        # EStalker request shape: get_ordered_list&genre=<id>&sortby=<mode>&p=1
        # _paged_rows follows all 14-item pages and preserves portal ordering.
        rows = self._paged_rows("itv", "get_ordered_list", wanted)
        items = [
            self._normalise_live(item) if not item.get("_stalker_live") else item
            for item in rows if isinstance(item, dict)
        ]
        if items:
            self._persistent_set("live_streams", items, _STALKER_CHANNEL_TTL, wanted, str(sortby or "number"))
        return items

    def search_filtered_media_native(self, kind, query, category_ids, limit=500):
        """Try Ministra/Stalker native VOD/Series search inside selected packages.

        Returns a list when the portal demonstrably honours one of the common
        native search parameters (``search``, ``search_str`` or ``name``).
        Returns ``None`` when native search cannot be proven, allowing the UI to
        fall back to its existing cache/package scan without changing results.

        The request is package-scoped from the start, so Search never leaks
        content from bouquets/packages the user did not enable.
        """
        media_kind = "series" if str(kind or "").lower() == "series" else "vod"
        needle = str(query or "").strip().lower()
        if not needle:
            return []
        try:
            cap = max(1, min(500, int(limit or 500)))
        except Exception:
            cap = 500
        allowed = []
        seen_cids = set()
        for cid in category_ids or []:
            cid = str(cid or "").strip()
            if cid and cid not in seen_cids:
                seen_cids.add(cid)
                allowed.append(cid)
        if not allowed:
            return []

        actions = (("series", "get_ordered_list"), ("series", "get_series_list"), ("series", "get_all_series")) \
            if media_kind == "series" else (("vod", "get_ordered_list"), ("vod", "get_vod_list"), ("vod", "get_movies"))

        def title_matches(row):
            try:
                value = str((row or {}).get("name") or (row or {}).get("title") or
                            (row or {}).get("movie_name") or (row or {}).get("series_name") or "").lower()
            except Exception:
                value = ""
            return needle in value

        # A key is considered supported only after at least one returned row
        # actually matches the query.  This prevents portals that silently
        # ignore unknown parameters from being mistaken for native search.
        for search_key in ("search", "search_str", "name"):
            collected = []
            dedupe = set()
            key_proven = False
            per_category = {}
            per_plan = {}
            for cid in allowed:
                category_rows = []
                for api_type, action in actions:
                    # Reuse the portal-specific category/genre variants already
                    # used by normal catalogue loading, then add only one search
                    # key.  Page 1 is enough to prove support and most portals
                    # return filtered matches first.
                    for base in self._list_query_variants(api_type, action, cid, 1):
                        request = dict(base)
                        request[search_key] = str(query or "")
                        try:
                            response = self._call_retry(**request)
                            rows = [r for r in self._portal_rows(response) if isinstance(r, dict)]
                        except Exception:
                            rows = []
                        if not rows:
                            continue
                        matched = [r for r in rows if title_matches(r)]
                        if matched:
                            key_proven = True
                            category_rows = matched
                            per_plan[cid] = dict(base)
                            break
                    if category_rows:
                        break
                per_category[cid] = category_rows

            if not key_proven:
                continue

            # Once the portal proved this key, trust empty responses for other
            # selected packages as real "no match" results. For packages that
            # did return matches, follow native result pages so searches are not
            # truncated to the portal's usual 14-item first page.
            for cid, plan in list(per_plan.items()):
                for page in range(2, 21):
                    request = dict(plan)
                    request["p"] = str(page)
                    request[search_key] = str(query or "")
                    try:
                        response = self._call_retry(**request)
                        rows = [r for r in self._portal_rows(response) if isinstance(r, dict)]
                    except Exception:
                        break
                    if not rows:
                        break
                    matched = [r for r in rows if title_matches(r)]
                    if not matched:
                        break
                    per_category.setdefault(cid, []).extend(matched)
                    total = self._portal_total(response)
                    if total and len(per_category.get(cid) or []) >= total:
                        break

            # Normalise and apply an additional category guard before returning
            # to the UI.
            for cid in allowed:
                for raw in per_category.get(cid) or []:
                    try:
                        item = self._normalise_series(raw, "series") if media_kind == "series" else self._normalise_vod(raw)
                    except Exception:
                        continue
                    if media_kind == "vod" and self._is_series_item(raw):
                        continue
                    item_cid = str(item.get("category_id") or item.get("genre_id") or "").strip()
                    if item_cid and item_cid not in seen_cids:
                        continue
                    marker = str(item.get("stream_id") or item.get("series_id") or item.get("vod_id") or "") + "|" + str(item.get("name") or "")
                    if marker in dedupe:
                        continue
                    dedupe.add(marker)
                    collected.append(item)
                    if len(collected) >= cap:
                        return collected
            stalker_log("NATIVE_SEARCH kind=%s key=%s packages=%d rows=%d" % (
                media_kind, search_key, len(allowed), len(collected)
            ))
            return collected

        stalker_log("NATIVE_SEARCH_FALLBACK kind=%s packages=%d" % (media_kind, len(allowed)))
        return None

    def search_all_live(self, query=""):
        """Search cached Stalker channels first; fetch the portal only on cache miss."""
        cached = self._persistent_get("channels_all")
        if isinstance(cached, list) and cached:
            items = [dict(row) for row in cached if isinstance(row, dict)]
        else:
            response = self._call_retry(
                type="itv", action="get_all_channels", sortby="name", JsHttpRequest="1-xml"
            )
            rows = self._portal_rows(response)
            items = [self._normalise_live(raw) for raw in rows if isinstance(raw, dict)]
            if items:
                self._persistent_set("channels_all", items, _STALKER_CHANNEL_TTL)
        needle = str(query or "").strip().lower()
        out = []
        for item in items:
            name = str(item.get("name") or item.get("title") or "").lower()
            if not needle or needle in name:
                out.append(item)
        return out


    def _catalog_rows(self, attempts, category_id="", max_pages=None):
        """Try documented and common fork-specific catalog actions in order."""
        for api_type, action in attempts:
            try:
                rows = self._paged_rows(api_type, action, category_id, max_pages)
            except Exception:
                rows = []
            if rows:
                return rows
        return []

    def _first_item_value(self, item, keys, default=""):
        item = item if isinstance(item, dict) else {}
        info = item.get("info") if isinstance(item.get("info"), dict) else {}
        for mapping in (item, info):
            for key in keys:
                value = mapping.get(key)
                if isinstance(value, (dict, list)) or value is None:
                    continue
                try:
                    if str(value).strip():
                        return value
                except Exception:
                    continue
        return default

    def _portal_asset(self, value):
        """Make a portal-relative poster/backdrop usable by the image queue."""
        try:
            value = (value or "").strip().replace("\\/", "/")
        except Exception:
            return ""
        if not value or value.startswith(("http://", "https://", "data:")):
            return value
        parsed = urlparse(self.portal)
        if not parsed.scheme or not parsed.netloc:
            return value
        root = "%s://%s" % (parsed.scheme, parsed.netloc)
        if value.startswith("//"):
            return parsed.scheme + ":" + value
        if value.startswith("/"):
            return root + value
        path = (parsed.path or "").rstrip("/")
        if path.endswith("/c"):
            path = path[:-2].rstrip("/")
        return root + path + "/" + value.lstrip("/")

    def _is_series_item(self, item):
        marker = self._first_item_value(item, ("is_series", "is_tv", "is_tvshow", "series", "series_type"), "")
        marker = str(marker).strip().lower()
        if marker in ("1", "true", "yes", "series", "tv", "tvshow", "tv_show"):
            return True
        kind = self._first_item_value(item, ("type", "content_type", "item_type", "media_type"), "")
        kind = str(kind).strip().lower()
        if "series" in kind or "tv" in kind or "show" in kind:
            return True
        return bool(self._first_item_value(item, ("series_id",), "") and not self._first_item_value(item, ("movie_id", "vod_id"), ""))

    def _is_series_category(self, category):
        category = category if isinstance(category, dict) else {}
        marker = str(category.get("_stalker_is_series") or category.get("_stalker_category_type") or "").lower()
        if marker in ("1", "true", "yes", "series", "tv", "tvshow", "tv_show") or "series" in marker:
            return True
        name = str(category.get("category_name") or "").lower()
        keywords = ("series", "séries", "serial", "сериал", "dizi", "مسلسل", "مسلسلات", "show", "tv")
        return any(keyword in name for keyword in keywords)

    def _valid_catalog_item(self, item):
        try:
            return bool(str((item or {}).get("stream_id") or "").strip() and str((item or {}).get("name") or "").strip())
        except Exception:
            return False

    def vod_categories(self):
        return self._categories("vod", ("get_categories", "get_genres"))

    def _normalise_vod(self, item):
        item = dict(item or {})
        sid = self._first_item_value(item, ("id", "stream_id", "vod_id", "movie_id", "film_id", "item_id"), "")
        cid = self._first_item_value(item, ("category_id", "category", "genre_id", "genre", "group_id"), "")
        cmd = self._first_item_value(item, ("cmd", "command", "stream_url", "url"), "")
        title = self._first_item_value(item, ("name", "title", "movie_name", "o_name", "original_name", "display_name"), "MOVIE")
        poster = self._portal_asset(self._first_item_value(item, ("screenshot_uri", "cover", "stream_icon", "image", "movie_image", "poster", "poster_url", "poster_path", "cover_big"), ""))
        backdrop = self._portal_asset(self._first_item_value(item, ("backdrop", "backdrop_path", "backdrop_url", "fanart", "background"), ""))
        description = self._first_item_value(item, ("description", "plot", "about", "story", "overview"), "")
        return {
            "stream_id": str(sid or ""), "vod_id": str(sid or ""),
            "name": title, "title": title,
            "category_id": str(cid or ""), "genre_id": str(cid or ""), "stream_icon": poster, "cover": poster,
            "backdrop": backdrop,
            "description": description, "plot": description,
            "rating": self._first_item_value(item, ("rating_imdb", "rating", "imdb_rating", "score"), ""), "year": self._first_item_value(item, ("year", "releasedate", "release_date", "release_year"), ""),
            "added": self._first_item_value(item, ("added",), "0"), "container_extension": self._first_item_value(item, ("container_extension", "extension", "format"), "mp4"),
            "cmd": cmd, "_stalker_vod": True, "_stalker_link_type": "vod",
        }

    def vod_streams(self, category_id="", max_pages=None):
        # r153: complete persistent catalogue path: RAM/UI -> SQLite -> portal.
        # Store normalised rows (metadata only; artwork stays as files) so a box
        # restart does not force the same Stalker package to be downloaded again.
        cache_part = str(category_id or "")
        cached, fresh = self._persistent_peek("vod_streams", cache_part, str(max_pages or "default"))
        if isinstance(cached, list) and cached:
            return [dict(x) for x in cached if isinstance(x, dict)]
        rows = self._catalog_rows((("vod", "get_ordered_list"), ("vod", "get_vod_list"), ("vod", "get_movies")), category_id, max_pages)
        normal = [self._normalise_vod(item) for item in rows if isinstance(item, dict) and not self._is_series_item(item)]
        normal = [item for item in normal if self._valid_catalog_item(item)]
        if normal:
            self._persistent_set("vod_streams", normal, _STALKER_PAGE_TTL, cache_part, str(max_pages or "default"))
        return normal

    def recent_media_filtered(self, kind="vod", category_ids=None, limit=25):
        """Fetch a light Recent Added snapshot for enabled Stalker packages.

        One first-page request per enabled package is used instead of walking the
        complete package catalogue.  The portal is asked to order by ``added``
        and only the newest ``limit`` normalised rows are returned.  This keeps
        the user's package filter authoritative while cutting Recent Movies
        network traffic dramatically on large VOD libraries.
        """
        try:
            limit = max(1, min(25, int(limit or 25)))
        except Exception:
            limit = 25
        media_kind = "series" if str(kind or "").lower() == "series" else "vod"
        allowed = []
        seen = set()
        for cid in (category_ids or []):
            cid = str(cid or "").strip()
            if cid and cid not in seen:
                seen.add(cid)
                allowed.append(cid)
        if not allowed:
            return []

        cache_key = ",".join(sorted(allowed))
        cached = self._persistent_get("recent_media_filtered", media_kind, cache_key, limit)
        if isinstance(cached, list) and cached:
            return [dict(x) for x in cached[:limit] if isinstance(x, dict)]

        def _fetch_one(api_type, action, cid):
            # Try the same category aliases used by the normal catalogue, but
            # force a single page ordered by added.  Stop on the first response
            # that contains rows; never walk page 2+.
            for request in self._list_query_variants(api_type, action, cid, 1):
                req = dict(request)
                req["sortby"] = "added"
                try:
                    response = self._call_retry(**req)
                    rows = [row for row in self._portal_rows(response) if isinstance(row, dict)]
                except Exception:
                    rows = []
                if rows:
                    return rows
            return []

        collected = []
        for cid in allowed:
            rows = []
            if media_kind == "vod":
                for action in ("get_ordered_list", "get_vod_list", "get_movies"):
                    rows = _fetch_one("vod", action, cid)
                    if rows:
                        break
                normal = [self._normalise_vod(row) for row in rows if not self._is_series_item(row)]
            else:
                link_type = "series"
                for action in ("get_ordered_list", "get_series_list", "get_all_series"):
                    rows = _fetch_one("series", action, cid)
                    if rows:
                        break
                if not rows:
                    link_type = "vod"
                    for action in ("get_ordered_list", "get_vod_list", "get_movies"):
                        candidate = _fetch_one("vod", action, cid)
                        rows = [row for row in candidate if self._is_series_item(row)]
                        if rows:
                            break
                normal = [self._normalise_series(row, link_type) for row in rows]
            for item in normal:
                if self._valid_catalog_item(item):
                    collected.append(item)

        def _added(row):
            try:
                return int(str((row or {}).get("added") or "0").strip())
            except Exception:
                return 0
        if any(_added(row) for row in collected):
            collected.sort(key=_added, reverse=True)

        dedup, result = set(), []
        for item in collected:
            marker = str(item.get("stream_id") or item.get("series_id") or item.get("vod_id") or item.get("id") or "")
            if not marker:
                marker = str(item.get("name") or item.get("title") or "")
            if marker in dedup:
                continue
            dedup.add(marker)
            result.append(item)
            if len(result) >= limit:
                break
        if result:
            self._persistent_set("recent_media_filtered", result, 10 * 60, media_kind, cache_key, limit)
        return result

    def recent_media(self, kind="vod", limit=25):
        """Return only the first Stalker/Ministra Recent Added page.

        The portal performs the ordering (sortby=added).  This deliberately
        bypasses enabled-package scans so Recent Added can paint quickly.
        Only the first page is requested and only *limit* normalised rows are
        returned to the UI.
        """
        try:
            limit = max(1, min(25, int(limit or 25)))
        except Exception:
            limit = 25
        media_kind = "series" if str(kind or "").lower() == "series" else "vod"
        cached = self._persistent_get("recent_media", media_kind, limit)
        if isinstance(cached, list) and cached:
            return [dict(x) for x in cached[:limit] if isinstance(x, dict)]

        def _fetch(api_type, action):
            try:
                response = self._call_retry(
                    type=api_type, action=action, sortby="added", p="1",
                    fav="0", hd="1", force_ch_link_check="0",
                    JsHttpRequest="1-xml"
                )
            except Exception:
                return []
            return [row for row in self._portal_rows(response) if isinstance(row, dict)]

        if media_kind == "vod":
            rows = []
            for action in ("get_ordered_list", "get_vod_list", "get_movies"):
                rows = _fetch("vod", action)
                if rows:
                    break
            normal = [self._normalise_vod(row) for row in rows if not self._is_series_item(row)]
        else:
            rows = []
            link_type = "series"
            for action in ("get_ordered_list", "get_series_list", "get_all_series"):
                rows = _fetch("series", action)
                if rows:
                    break
            if not rows:
                link_type = "vod"
                for action in ("get_ordered_list", "get_vod_list", "get_movies"):
                    candidate = _fetch("vod", action)
                    rows = [row for row in candidate if self._is_series_item(row)]
                    if rows:
                        break
            normal = [self._normalise_series(row, link_type) for row in rows]

        normal = [row for row in normal if self._valid_catalog_item(row)]
        # Keep the provider's Recent Added ordering, but guard against portals
        # that return the first page unsorted despite accepting sortby=added.
        def _added(row):
            try:
                return int(str((row or {}).get("added") or "0").strip())
            except Exception:
                return 0
        if any(_added(row) for row in normal):
            normal.sort(key=_added, reverse=True)
        result = normal[:limit]
        if result:
            self._persistent_set("recent_media", result, 10 * 60, media_kind, limit)
        return result

    def series_categories(self):
        rows = self._categories("series", ("get_categories", "get_genres"))
        if rows:
            return rows
        # Many MAG portals place TV Shows in the VOD catalog and mark list rows
        # with is_series=1.  Prefer clearly named packages, then retain all VOD
        # packages only when the provider uses an unknown language/name scheme.
        fallback = self.vod_categories()
        marked = [row for row in fallback if self._is_series_category(row)]
        return marked or fallback

    def _normalise_series(self, item, link_type="series"):
        item = dict(item or {})
        sid = self._first_item_value(item, ("id", "series_id", "stream_id", "vod_id", "movie_id", "item_id"), "")
        cid = self._first_item_value(item, ("category_id", "category", "genre_id", "genre", "group_id"), "")
        title = self._first_item_value(item, ("name", "title", "series_name", "o_name", "original_name", "display_name"), "TV SHOW")
        poster = self._portal_asset(self._first_item_value(item, ("screenshot_uri", "cover", "stream_icon", "image", "movie_image", "poster", "poster_url", "poster_path", "cover_big"), ""))
        backdrop = self._portal_asset(self._first_item_value(item, ("backdrop", "backdrop_path", "backdrop_url", "fanart", "background"), ""))
        description = self._first_item_value(item, ("description", "plot", "about", "story", "overview"), "")
        return {
            "stream_id": str(sid or ""), "series_id": str(sid or ""),
            "name": title, "title": title,
            "category_id": str(cid or ""), "genre_id": str(cid or ""), "stream_icon": poster, "cover": poster,
            "backdrop": backdrop,
            "description": description, "plot": description,
            "rating": self._first_item_value(item, ("rating_imdb", "rating", "imdb_rating", "score"), ""), "year": self._first_item_value(item, ("year", "releasedate", "release_date", "release_year"), ""),
            "added": self._first_item_value(item, ("added",), "0"), "cmd": self._first_item_value(item, ("cmd", "command", "stream_url", "url"), ""),
            "_stalker_series": True, "_stalker_link_type": link_type,
        }

    def series_streams(self, category_id="", max_pages=None):
        cache_part = str(category_id or "")
        cached, fresh = self._persistent_peek("series_streams", cache_part, str(max_pages or "default"))
        if isinstance(cached, list) and cached:
            return [dict(x) for x in cached if isinstance(x, dict)]
        rows = self._catalog_rows((("series", "get_ordered_list"), ("series", "get_series_list"), ("series", "get_all_series")), category_id, max_pages)
        link_type = "series"
        if not rows and category_id:
            rows = self._catalog_rows((("vod", "get_ordered_list"), ("vod", "get_vod_list"), ("vod", "get_movies")), category_id, max_pages)
            rows = [item for item in rows if isinstance(item, dict) and self._is_series_item(item)]
            link_type = "vod"
        normal = [self._normalise_series(item, link_type) for item in rows if isinstance(item, dict)]
        normal = [item for item in normal if self._valid_catalog_item(item)]
        if normal:
            self._persistent_set("series_streams", normal, _STALKER_PAGE_TTL, cache_part, str(max_pages or "default"))
        return normal

    def categories(self, kind):
        if kind == "live": return self.live_categories()
        if kind == "vod": return self.vod_categories()
        if kind == "series": return self.series_categories()
        return []

    def streams(self, kind, category_id=""):
        if kind == "live": return self.live_streams(category_id)
        if kind == "vod": return self.vod_streams(category_id)
        if kind == "series": return self.series_streams(category_id)
        return []

    def _normalise_episode(self, item, season="", link_type="series"):
        item = dict(item or {})
        info = item.get("info") if isinstance(item.get("info"), dict) else {}
        number = item.get("episode_num") or item.get("episode_number") or item.get("number") or info.get("episode_num") or info.get("episode_number") or ""
        season_num = item.get("season") or item.get("season_number") or info.get("season") or info.get("season_number") or season or "1"
        cmd = item.get("cmd") or item.get("command") or item.get("stream_url") or info.get("cmd") or ""
        image = item.get("movie_image") or item.get("cover") or item.get("stream_icon") or item.get("screenshot_uri") or item.get("poster") or info.get("movie_image") or info.get("cover") or ""
        image = self._portal_asset(image)
        title = item.get("title") or item.get("name") or item.get("episode_name") or info.get("title") or info.get("name") or "Episode %s" % (number or "")
        eid = item.get("id") or item.get("stream_id") or item.get("episode_id") or item.get("vod_id") or item.get("movie_id") or ""
        return {
            "id": str(eid), "stream_id": str(eid),
            "title": title, "name": title,
            "episode_num": number, "episode_number": number, "season": str(season_num), "season_number": str(season_num),
            "cmd": cmd, "movie_image": image, "cover": image, "stream_icon": image, "info": info, "_stalker_episode": True, "_stalker_link_type": link_type,
        }

    def _normalise_series_info(self, payload, fallback, link_type="series"):
        raw = payload or {}
        if isinstance(raw, list): raw = {"episodes": raw}
        if not isinstance(raw, dict): return {"info": {}, "episodes": {}, "seasons": []}
        # Some portals wrap a series record twice, e.g. js.result.data.  Unwrap
        # only structural dictionaries and stop as soon as episode/info fields
        # become visible, so real detail metadata is never discarded.
        for _unused in range(3):
            nested = None
            for key in ("data", "result", "results", "response", "payload", "content"):
                value = self._decode(raw.get(key)) if isinstance(raw, dict) else None
                if isinstance(value, dict) and ("episodes" in value or "info" in value or "seasons" in value):
                    nested = value
                    break
            if nested is None:
                break
            raw = nested
        info = raw.get("info") if isinstance(raw.get("info"), dict) else {}
        if not info:
            info = {key: raw.get(key) for key in ("name", "title", "description", "plot", "rating", "year", "cover", "backdrop") if raw.get(key) is not None}
        episodes = raw.get("episodes") or raw.get("items") or raw.get("data") or []
        if not episodes:
            inferred = {}
            for key, value in raw.items():
                if str(key).isdigit() and isinstance(value, (list, dict)):
                    inferred[key] = value
            episodes = inferred
        grouped = {}
        if isinstance(episodes, dict):
            for season, values in episodes.items():
                if isinstance(values, dict): values = values.get("episodes") or values.get("items") or values.get("data") or [values]
                if not isinstance(values, list): continue
                key = str(season or "1")
                grouped[key] = [self._normalise_episode(value, key, link_type) for value in values if isinstance(value, dict)]
        elif isinstance(episodes, list):
            for value in episodes:
                if not isinstance(value, dict): continue
                normal = self._normalise_episode(value, "", link_type)
                key = str(normal.get("season") or "1")
                grouped.setdefault(key, []).append(normal)
        seasons = [{"season_number": key, "name": "Season %s" % key} for key in sorted(grouped.keys(), key=lambda value: int(value) if str(value).isdigit() else 999)]
        return {"info": info, "episodes": grouped, "seasons": seasons}

    @staticmethod
    def _series_episode_identity(row, index=0):
        if not isinstance(row, dict):
            return ("invalid", str(index))
        for key in ("episode_id", "id", "stream_id", "series_id"):
            value = row.get(key)
            if value not in (None, ""):
                return (str(key), str(value))
        season = row.get("season") or row.get("season_number") or ""
        number = row.get("episode_num") or row.get("episode_number") or row.get("episode") or ""
        if number not in (None, ""):
            return ("episode", str(season), str(number))
        return ("row", str(row.get("name") or row.get("title") or ""), str(index))

    @classmethod
    def _merge_series_info(cls, *values):
        """Merge normalized Stalker series data without letting a partial reply erase richer cached rows."""
        merged_info = {}
        grouped = {}
        for value in values:
            if not isinstance(value, dict):
                continue
            info = value.get("info")
            if isinstance(info, dict):
                for key, item in info.items():
                    if item not in (None, "", [], {}):
                        merged_info[key] = item
            episodes = value.get("episodes") or {}
            if not isinstance(episodes, dict):
                continue
            for season, rows in episodes.items():
                season_key = str(season or "1")
                bucket = grouped.setdefault(season_key, {})
                if not isinstance(rows, list):
                    continue
                for index, row in enumerate(rows):
                    if not isinstance(row, dict) or not row:
                        continue
                    identity = cls._series_episode_identity(row, index)
                    previous = bucket.get(identity)
                    if previous is None:
                        bucket[identity] = dict(row)
                    else:
                        combined = dict(previous)
                        for key, item in row.items():
                            if item not in (None, "", [], {}):
                                combined[key] = item
                        bucket[identity] = combined
        episodes = {}
        for season, bucket in grouped.items():
            episodes[season] = list(bucket.values())
        seasons = [{"season_number": key, "name": "Season %s" % key} for key in sorted(episodes.keys(), key=lambda value: int(value) if str(value).isdigit() else 999)]
        return {"info": merged_info, "episodes": episodes, "seasons": seasons}

    @staticmethod
    def _series_info_count(value):
        if not isinstance(value, dict):
            return 0
        episodes = value.get("episodes") or {}
        if not isinstance(episodes, dict):
            return 0
        return sum(len(rows) for rows in episodes.values() if isinstance(rows, list))

    @staticmethod
    def _series_info_suspicious(value):
        if not isinstance(value, dict):
            return True
        episodes = value.get("episodes") or {}
        if not isinstance(episodes, dict) or not episodes:
            return True
        numbers = []
        for season in episodes.keys():
            try:
                numbers.append(int(str(season).strip()))
            except Exception:
                continue
        if not numbers:
            return False
        unique = sorted(set(numbers))
        if unique[0] > 1:
            return True
        return unique != list(range(unique[0], unique[-1] + 1))

    def series_info(self, series_id):
        sid = str(series_id or "")
        if not sid:
            return {"info": {}, "episodes": {}, "seasons": []}

        # Keep the normal fast path for fresh cache.  If the cache has just
        # expired, retain it as a stable baseline while refreshing so a
        # smaller/transient portal reply cannot wipe complete seasons.
        cached, fresh = self._persistent_peek("series_info", sid)
        if fresh and isinstance(cached, dict) and (cached.get("episodes") or cached.get("info")):
            return cached
        stable = cached if isinstance(cached, dict) else None
        stable_count = self._series_info_count(stable)

        params = {"series_id": sid, "id": sid, "movie_id": sid, "vod_id": sid, "JsHttpRequest": "1-xml"}
        best = stable if stable_count else None
        best_count = stable_count
        fallback = stable if isinstance(stable, dict) and stable.get("info") else None
        routes = (
            ("series", ("get_series", "get_series_info", "get_episodes")),
            ("vod", ("get_series", "get_series_info", "get_episodes", "get_vod_info")),
        )

        for api_type, actions in routes:
            for action in actions:
                try:
                    response = self._call_retry(type=api_type, action=action, **params)
                except Exception:
                    continue
                normalized = self._normalise_series_info(self._portal_payload(response), sid, api_type)
                if normalized.get("info") and fallback is None:
                    fallback = normalized

                count = self._series_info_count(normalized)
                if not count:
                    continue

                merged = self._merge_series_info(best, normalized) if best else normalized
                merged_count = self._series_info_count(merged)
                if merged_count >= best_count:
                    best = merged
                    best_count = merged_count

                # Preserve the old fast behavior for a clearly complete reply.
                # Continue through the existing fallback routes only when the
                # reply is smaller than our stable baseline or has season gaps.
                suspicious = self._series_info_suspicious(normalized)
                if stable_count and count < stable_count:
                    suspicious = True
                if not suspicious:
                    result = best or normalized
                    self._persistent_set("series_info", result, _STALKER_SERIES_INFO_TTL, sid)
                    return result

        result = best or fallback or {"info": {}, "episodes": {}, "seasons": []}
        if isinstance(result, dict) and (result.get("episodes") or result.get("info")):
            self._persistent_set("series_info", result, _STALKER_SERIES_INFO_TTL, sid)
        return result

    def vod_info(self, vod_id):
        vid = str(vod_id or "")
        if not vid:
            return {}
        cached = self._persistent_get("vod_info", vid)
        if isinstance(cached, dict) and cached:
            return cached
        params = {"vod_id": vid, "id": vid, "movie_id": vid, "JsHttpRequest": "1-xml"}
        for action in ("get_vod_info", "get_movie_info", "get_info"):
            try:
                response = self._call_retry(type="vod", action=action, **params)
            except Exception:
                continue
            payload = self._portal_payload(response)
            if isinstance(payload, dict):
                self._persistent_set("vod_info", payload, _STALKER_VOD_INFO_TTL, vid)
                return payload
            if isinstance(payload, list) and payload and isinstance(payload[0], dict):
                self._persistent_set("vod_info", payload[0], _STALKER_VOD_INFO_TTL, vid)
                return payload[0]
        return {}

    def _extract_link(self, response):
        """Extract a playable URL while keeping the original fast Stalker flow."""
        import re
        for payload in (self._portal_js(response), self._portal_payload(response)):
            if isinstance(payload, dict):
                command = payload.get("cmd") or payload.get("url") or payload.get("stream_url") or ""
            elif isinstance(payload, str):
                command = payload
            else:
                command = ""
            command = str(command or "").replace("\\/", "/").strip()
            if not command:
                continue
            if command.lower().startswith(("http://", "https://", "rtmp://", "rtsp://", "udp://", "rtp://")):
                return command
            urls = re.findall(r"(?:https?|rtmp|rtsp|udp|rtp)://[^\s\"']+", command, re.I)
            if urls:
                return urls[-1]
            if command.lower().startswith(("ffmpeg ", "ffrt ")):
                parts = command.split()
                if len(parts) > 1:
                    return parts[-1]
            return command
        return ""

    def _direct_link_from_cmd(self, cmd):
        """Return a URL already present in a channel command, if any."""
        return self._extract_link({"js": {"cmd": cmd or ""}})

    def _extract_xtream_creds_from_link(self, link):
        value = str(link or "")
        match = re.search(r"/(?:movie|live|series)/([^/]+)/([^/]+)/", value)
        if not match:
            return {}
        return {"username": match.group(1), "password": match.group(2)}

    def _xtream_player_api(self, username, password):
        if not username or not password:
            return {}
        parsed = urlparse(self.configured_portal or self.portal or "")
        host = "%s://%s" % (parsed.scheme or "http", parsed.netloc)
        url = host.rstrip("/") + "/player_api.php"
        query = {"username": username, "password": password}
        try:
            if self._estalker_http is not None:
                response = self._estalker_http.get(
                    url, params=query,
                    headers={
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/145.0.0.0 Safari/537.36",
                        "Accept-Encoding": "gzip, deflate",
                    },
                    timeout=(5, 5), verify=False
                )
                response.raise_for_status()
                return response.json()
            request = Request(url + "?" + urlencode(query), headers={"User-Agent": UA})
            response = urlopen(request, timeout=5)
            try:
                raw = response.read()
            finally:
                response.close()
            if isinstance(raw, bytes):
                raw = raw.decode("utf-8", "ignore")
            return json.loads(raw)
        except Exception as exc:
            stalker_log("XTREAM FAST player_api failed error=%s" % exc)
            return {}

    def _warm_xtream_fast_path(self):
        """EStalker 1.45: derive Xtream creds from one resolved Stalker stream."""
        if self._xtream_creds:
            return True
        if not self.token:
            return False
        for content_type in ("vod", "itv"):
            try:
                response = self.call(
                    type=content_type, action="get_ordered_list",
                    genre="*", p="1", JsHttpRequest="1-xml"
                ) or {}
                rows = self._portal_rows(response)
                first = next(
                    (row for row in rows if isinstance(row, dict) and row.get("cmd")),
                    None
                )
                if not first:
                    continue
                cmd = str(first.get("cmd") or "")
                if cmd.startswith("/media/"):
                    cmd = cmd.replace("/media/", "/media/file_", 1)
                link_response = self.call(
                    type=content_type, action="create_link", cmd=cmd,
                    series="", forced_storage="", disable_ad="0",
                    download="0", force_ch_link_check="0",
                    JsHttpRequest="1-xml"
                ) or {}
                link = self._extract_link(link_response)
                creds = self._extract_xtream_creds_from_link(link)
                if not creds:
                    continue
                self._xtream_creds = creds
                info = self._xtream_player_api(
                    creds.get("username", ""), creds.get("password", "")
                ) or {}
                self._xtream_info = info
                user = info.get("user_info") if isinstance(info, dict) else {}
                if isinstance(user, dict):
                    exp = user.get("exp_date")
                    if exp:
                        try:
                            self.expiry = time.strftime(
                                "%Y-%m-%d %H:%M:%S",
                                time.localtime(int(exp))
                            )
                        except Exception:
                            pass
                    status = str(user.get("status") or "")
                    if status:
                        self.account_status = status
                stalker_log("XTREAM FAST success type=%s user=present api=%s" % (
                    content_type, bool(info)))
                return True
            except Exception as exc:
                stalker_log("XTREAM FAST retry type=%s error=%s" % (content_type, exc))
        return False

    def _create_link(self, kind, item_id, cmd=""):
        """Short-lived resolved-link cache to avoid duplicate create_link zaps."""
        raw = str(cmd or item_id or "")
        cmd_hash = hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()[:16]
        key = (self._token_key, str(kind), str(item_id or ""), cmd_hash)
        now = time.time()
        with _CATALOG_LOCK:
            row = _lru_get(_STALKER_CREATE_LINK_CACHE, key)
        if row:
            try:
                created, link = row
                ttl = 120 if str(kind) in ("vod", "series") else _STALKER_CREATE_LINK_TTL
                if link and now - float(created) < ttl:
                    stalker_log("CREATE_LINK cache_hit kind=%s id=%s" % (kind, item_id))
                    return link
            except Exception:
                pass

        link = self._create_link_uncached(kind, item_id, cmd)
        if link:
            with _CATALOG_LOCK:
                _lru_put(_STALKER_CREATE_LINK_CACHE, key, (time.time(), link), _STALKER_CREATE_LINK_LIMIT)
        return link

    def _create_link_uncached(self, kind, item_id, cmd=""):
        original_cmd = str(cmd or item_id or "").strip()
        direct = self._direct_link_from_cmd(original_cmd)
        lower_cmd = original_cmd.lower()
        needs_resolution = (
            not direct or "localhost" in lower_cmd or "///" in original_cmd or
            "/ch/" in lower_cmd or
            not lower_cmd.startswith(("http://", "https://", "rtmp://", "rtsp://", "udp://", "rtp://"))
        )
        if not needs_resolution and direct:
            stalker_log("CREATE_LINK direct kind=%s id=%s" % (kind, item_id))
            return direct

        # Live follows EStalker 1.45 exactly:
        # one create_link request; if empty, reauthorize once and retry it once.
        if kind == "itv":
            if not self._ensure_token():
                raise RuntimeError("Stalker handshake was rejected by the portal")
            if not self._ensure_profile():
                raise RuntimeError("Stalker profile request failed")

            url = (
                self.portal +
                "?type=itv&action=create_link&cmd=%s"
                "&series=0&forced_storage=0&disable_ad=0&download=0"
                "&force_ch_link_check=0&JsHttpRequest=1-xml" %
                original_cmd
            )
            response = self._native145_fresh_json_request(
                url, self._native145_live_headers()
            )

            if not response:
                if self._native145_reauthorize_live():
                    response = self._native145_fresh_json_request(
                        url, self._native145_live_headers()
                    )

            next_url = ""
            if isinstance(response, dict):
                js = response.get("js")
                if isinstance(js, dict) and "cmd" in js:
                    next_url = str(js.get("cmd") or "")

            if next_url:
                parts = next_url.split(None, 1)
                if len(parts) == 2:
                    next_url = parts[1].lstrip()
                parsed = urlparse(next_url)
                if parsed.scheme in ("http", "https"):
                    next_url = parsed.geturl()
                stalker_log("CREATE_LINK EStalker146 live success id=%s" % item_id)
                return next_url

            if direct:
                return direct
            raise RuntimeError("Stalker portal returned no playable URL")

        estalker_cmd = original_cmd
        if estalker_cmd.startswith("/media/") and not estalker_cmd.startswith("/media/file_"):
            estalker_cmd = estalker_cmd.replace("/media/", "/media/file_", 1)
        query = {
            "type": kind, "action": "create_link", "cmd": original_cmd,
            "series": "0" if kind == "itv" else "",
            "forced_storage": "0" if kind == "itv" else "",
            "disable_ad": "0", "download": "0", "force_ch_link_check": "0",
            "JsHttpRequest": "1-xml",
        }
        started = time.time()
        first_error = None

        def create_once():
            if not self._ensure_token():
                raise RuntimeError("Stalker handshake was rejected by the portal")
            self._ensure_profile()
            variants = [dict(query)]
            if estalker_cmd and estalker_cmd != original_cmd:
                eq = dict(query)
                eq["cmd"] = estalker_cmd
                variants.append(eq)
            # Some forks are strict about series being blank rather than 0.
            if kind == "itv":
                eq = dict(query)
                eq["series"] = ""
                eq["forced_storage"] = ""
                variants.append(eq)
            last = None
            for candidate in variants:
                try:
                    link = self._extract_link(self.call(**candidate) or {})
                    if link:
                        return link
                except Exception as exc:
                    last = exc
            if last:
                raise last
            return ""

        try:
            link = create_once()
            if link:
                stalker_log("CREATE_LINK result kind=%s id=%s ms=%d" % (
                    kind, item_id, int((time.time()-started)*1000)))
                return link
            first_error = RuntimeError("portal returned an empty create_link")
        except Exception as exc:
            first_error = exc
            stalker_log("CREATE_LINK primary failed kind=%s id=%s error=%s" % (kind, item_id, exc))

        if kind == "itv" and (
            first_error is None or
            self._is_stalker_auth_error(first_error) or
            "empty create_link" in str(first_error).lower()
        ):
            try:
                if self.reauthorize():
                    link = create_once()
                    if link:
                        stalker_log("CREATE_LINK reauthorized kind=%s id=%s ms=%d" % (
                            kind, item_id, int((time.time()-started)*1000)))
                        return link
                    stalker_log("CREATE_LINK reauthorized_empty kind=%s id=%s" % (kind, item_id))
            except Exception as exc:
                stalker_log("CREATE_LINK reauthorize retry failed kind=%s id=%s error=%s" % (kind, item_id, exc))

        try:
            fallback = dict(query)
            fallback["action"] = "get_link"
            link = self._extract_link(self._call_retry(**fallback))
            if link:
                return link
        except Exception as exc:
            stalker_log("CREATE_LINK get_link failed kind=%s id=%s error=%s" % (kind, item_id, exc))
        if direct:
            return direct
        raise first_error or RuntimeError("Stalker portal returned no playable URL")

    def create_catchup_link(self, item, event):
        """Resolve Stalker/Ministra TV archive with several MAG-compatible variants."""
        item = item or {}
        event = event or {}

        # Prefer an event-specific command if the portal supplied one.
        cmd = str(
            event.get("cmd") or event.get("url") or event.get("stream_url") or
            item.get("cmd") or item.get("url") or item.get("stream_id") or item.get("id") or ""
        ).strip()

        start_ts = (
            event.get("_begin") or event.get("start_timestamp") or event.get("start") or
            event.get("begin_timestamp") or event.get("begin") or event.get("time")
        )
        stop_ts = (
            event.get("_end") or event.get("stop_timestamp") or event.get("stop") or
            event.get("end_timestamp") or event.get("end")
        )

        try:
            start_ts = int(float(start_ts))
            if start_ts > 100000000000:
                start_ts = int(start_ts / 1000)
        except Exception:
            start_ts = 0

        try:
            stop_ts = int(float(stop_ts))
            if stop_ts > 100000000000:
                stop_ts = int(stop_ts / 1000)
        except Exception:
            stop_ts = 0

        if not stop_ts or stop_ts <= start_ts:
            try:
                duration = int(float(event.get("duration") or 3600))
            except Exception:
                duration = 3600
            stop_ts = start_ts + max(60, duration)

        if not cmd or not start_ts:
            raise RuntimeError("Catch-up command or start time is missing")

        now_ts = int(time.time())
        first_error = None

        # MAG/Stalker portals vary here. Important difference:
        # many portals expect lutc=current UTC, not programme end.
        time_pairs = [
            (start_ts, now_ts, "now"),
            (start_ts, stop_ts, "end"),
        ]

        forced_values = ("undefined", "0")

        for utc_value, lutc_value, time_mode in time_pairs:
            for forced_storage in forced_values:
                query = {
                    "type": "itv",
                    "action": "create_link",
                    "cmd": cmd,
                    "series": "0",
                    "forced_storage": forced_storage,
                    "disable_ad": "0",
                    "download": "0",
                    "force_ch_link_check": "0",
                    "utc": str(utc_value),
                    "lutc": str(lutc_value),
                    "JsHttpRequest": "1-xml",
                }

                for action in ("create_link", "get_link"):
                    query["action"] = action
                    try:
                        link = self._extract_link(self._call_retry(**query))
                        if link:
                            stalker_log(
                                "CATCHUP_LINK success action=%s mode=%s forced=%s utc=%s lutc=%s" %
                                (action, time_mode, forced_storage, utc_value, lutc_value)
                            )
                            return link
                    except Exception as exc:
                        first_error = first_error or exc
                        stalker_log(
                            "CATCHUP_LINK failed action=%s mode=%s forced=%s error=%s" %
                            (action, time_mode, forced_storage, exc)
                        )

        # Some portals return a normal live URL first and expect archive
        # timestamps directly on that URL.
        try:
            live_url = self._create_link(
                "itv",
                item.get("stream_id") or item.get("id"),
                item.get("cmd") or item.get("url") or cmd
            )
            if live_url:
                sep = "&" if "?" in live_url else "?"
                direct = "%s%sutc=%s&lutc=%s" % (live_url, sep, start_ts, now_ts)
                stalker_log("CATCHUP_LINK direct_url utc=%s lutc=%s" % (start_ts, now_ts))
                return direct
        except Exception as exc:
            first_error = first_error or exc
            stalker_log("CATCHUP_LINK direct_url failed error=%s" % exc)

        raise first_error or RuntimeError("Portal returned no catch-up link")


    def create_vod_link(self, item):
        item = item or {}
        return self._create_link("vod", item.get("vod_id") or item.get("stream_id"), item.get("cmd"))

    def create_series_link(self, item):
        item = item or {}
        kind = item.get("_stalker_link_type") or "series"
        if kind not in ("series", "vod"):
            kind = "series"
        return self._create_link(kind, item.get("series_id") or item.get("stream_id") or item.get("id"), item.get("cmd"))

    def watchdog(self):
        """Keep the Ministra/Stalker session alive without restarting video."""
        try:
            response = self._call_retry(
                **{
                    "type": "watchdog",
                    "action": "get_events",
                    "init": "0",
                    "cur_play_type": "1",
                    "event_active_id": "0",
                    "JsHttpRequest": "1-xml",
                }
            )
            return bool(response)
        except Exception as exc:
            stalker_log("WATCHDOG failed error=%s" % exc)
            return False


    def stream_url(self, item, kind="live"):
        item = item or {}
        if kind == "live":
            return self._create_link("itv", item.get("stream_id") or item.get("id"), item.get("cmd"))
        if kind == "series":
            return self.create_series_link(item)
        return self.create_vod_link(item)




# ---------------------------------------------------------------------------
# Client factory
# ---------------------------------------------------------------------------

def get_source_client(source):
    """Return the catalogue client matching a configured source type."""
    source = source or {}
    if source.get("type") == "stalker":
        return StalkerClient(source)
    if source.get("type") in ("m3u", "fg"):
        return M3UClient(source)
    return XtreamClient(source)
