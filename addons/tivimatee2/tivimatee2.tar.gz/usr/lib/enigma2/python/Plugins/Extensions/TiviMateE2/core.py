# -*- coding: utf-8 -*-
from __future__ import absolute_import
from .compat import atomic_replace, ensure_dir, open_text
import os, json, hashlib, re, ssl, time, threading, socket
try:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode, urlparse, parse_qs
except ImportError:
    from urllib2 import Request, urlopen
    from urllib import urlencode
    from urlparse import urlparse, parse_qs

BASE = "/etc/enigma2/tivimatee2"
SOURCES_FILE = os.path.join(BASE, "sources.json")
PLAYLISTS_FILE = os.path.join(BASE, "playlists.txt")
LEGACY_TIVIMATE_PLAYLISTS_FILE = "/etc/enigma2/tivimate/playlists.txt"
from .cache_manager import get_cache_root, get_cache_dir
CACHE = get_cache_root()
UA = "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/0.3"

# One bounded network policy and one generic catalog cache are used for every
# supported source.  Cache keys are derived from the configured source only;
# no service receives source-specific performance settings.
NETWORK_TIMEOUT = 10
CATALOG_CACHE_TTL = 24 * 60 * 60
_CATALOG_MEMORY = {}
_CATALOG_REFRESHING = set()
_CATALOG_LOCK = threading.RLock()
_STALKER_TOKENS = {}
_STALKER_TOKEN_TTL = 25 * 60


for p in (BASE, CACHE, get_cache_dir("posters"), get_cache_dir("backdrops"), get_cache_dir("logos")):
    try: ensure_dir(p)
    except Exception: pass


def load_json(path, default):
    try:
        with open_text(path, "r", encoding="utf-8") as f: return json.load(f)
    except Exception: return default


def save_json(path, data):
    try: ensure_dir(os.path.dirname(path))
    except Exception: pass
    tmp = path + ".tmp"
    with open_text(tmp, "w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False, indent=2)
    atomic_replace(tmp, path)


def _source_key(s):
    return "%s|%s|%s|%s" % (s.get("type",""), s.get("url","").rstrip("/"), s.get("username",""), s.get("mac",""))


def _normalise_stalker_source(name, portal, mac):
    """Create one local Stalker source from a compact playlist record."""
    portal = (portal or "").strip().rstrip("/")
    mac = (mac or "").strip().upper().replace("-", ":")
    if portal and "://" not in portal:
        portal = "http://" + portal
    parts = mac.split(":")
    try:
        valid_mac = len(parts) == 6 and all(len(part) == 2 and int(part, 16) >= 0 for part in parts)
    except Exception:
        valid_mac = False
    if not portal.startswith(("http://", "https://")) or not valid_mac:
        return None
    return {
        "type": "stalker",
        "name": (name or "Stalker Portal").strip() or "Stalker Portal",
        "url": portal,
        "mac": mac,
    }


def _parse_stalker_playlist_line(line, name):
    """Accept explicit STALKER records and the compact Portal/c/MAC shorthand."""
    raw = (line or "").strip()
    parts = [part.strip() for part in raw.split("|")]
    if parts and parts[0].upper() == "STALKER":
        if len(parts) == 4:
            # Prefer STALKER|Name|Portal URL|MAG MAC.  Also allow URL first.
            if parts[1].lower().startswith(("http://", "https://")):
                return _normalise_stalker_source(parts[3] or name, parts[1], parts[2])
            return _normalise_stalker_source(parts[1] or name, parts[2], parts[3])
        if len(parts) == 3:
            return _normalise_stalker_source(name, parts[1], parts[2])
        return None
    # Easy one-line form: http://SERVER:PORT/stalker_portal/c/00:1A:79:AA:BB:CC # Name
    match = re.match(r"^(https?://.+?/c/)([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})/?$", raw)
    if match:
        return _normalise_stalker_source(name, match.group(1), match.group(2))
    return None


def parse_playlist_line(raw):
    line = (raw or "").strip()
    if not line or line.startswith("#"):
        return None
    name = "IPTV"
    if " #" in line:
        line, name = line.rsplit(" #", 1)
        name = name.strip() or "IPTV"
    elif "|" in line and line.lower().startswith(("http://", "https://")):
        # Accept: URL | Name for ordinary M3U lines.
        parts = line.rsplit("|", 1)
        if len(parts) == 2:
            line, name = parts[0].strip(), parts[1].strip() or "IPTV"
    stalker = _parse_stalker_playlist_line(line, name)
    if stalker:
        return stalker
    try:
        u = urlparse(line.strip())
        qs = parse_qs(u.query)
        username = (qs.get("username") or [""])[0]
        password = (qs.get("password") or [""])[0]
        if username and password:
            base = "%s://%s" % (u.scheme or "http", u.netloc)
            output = (qs.get("output") or ["ts"])[0]
            return {"type":"xtream", "name":name, "url":base.rstrip("/"), "username":username, "password":password, "output":output}
        if u.scheme in ("http","https"):
            return {"type":"m3u", "name":name, "url":line.strip()}
    except Exception:
        pass
    return None


def import_playlists(paths=None):
    paths = paths or (PLAYLISTS_FILE, LEGACY_TIVIMATE_PLAYLISTS_FILE)
    found = []
    for path in paths:
        try:
            with open_text(path, "r", encoding="utf-8", errors="ignore") as f:
                for raw in f:
                    s = parse_playlist_line(raw)
                    if s: found.append(s)
        except Exception:
            pass
    return found


def get_sources():
    stored = load_json(SOURCES_FILE, [])
    merged = []
    seen = set()
    for s in stored + import_playlists():
        k = _source_key(s)
        if k not in seen:
            seen.add(k); merged.append(s)
    return merged


def set_sources(v):
    save_json(SOURCES_FILE, v)


def xtream_to_playlist_line(src):
    base = src.get("url","").rstrip("/")
    output = src.get("output") or "ts"
    q = urlencode({"username":src.get("username",""), "password":src.get("password",""), "type":"m3u_plus", "output":output})
    return "%s/get.php?%s # %s" % (base, q, src.get("name") or "IPTV")


def write_playlists(sources):
    try: ensure_dir(BASE)
    except Exception: pass
    lines = []
    for s in sources:
        if s.get("type") == "xtream":
            lines.append(xtream_to_playlist_line(s))
        elif s.get("type") == "m3u" and s.get("url"):
            lines.append("%s # %s" % (s.get("url"), s.get("name") or "M3U"))
        elif s.get("type") == "stalker" and s.get("url") and s.get("mac"):
            # Keep the user-managed source portable without exposing it in package files.
            pname = (s.get("name") or "Stalker Portal").replace("|", " ")
            lines.append("STALKER|%s|%s|%s" % (pname, s.get("url").rstrip("/") + "/", s.get("mac")))
    with open_text(PLAYLISTS_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + ("\n" if lines else ""))


def fetch(url, headers=None, timeout=NETWORK_TIMEOUT, as_json=False):
    h = {"User-Agent": UA, "Accept": "*/*"}
    if headers: h.update(headers)
    req = Request(url, headers=h)
    try:
        ctx = ssl._create_unverified_context()
    except Exception:
        ctx = None
    try:
        if ctx is not None:
            response = urlopen(req, timeout=timeout, context=ctx)
        else:
            response = urlopen(req, timeout=timeout)
    except TypeError:
        response = urlopen(req, timeout=timeout)
    try:
        data = response.read()
    finally:
        try:
            response.close()
        except Exception:
            pass
    return json.loads(data.decode("utf-8", "replace")) if as_json else data



def _catalog_key(source, bucket):
    return "%s|catalog|%s" % (_source_key(source or {}), str(bucket or "default"))


def _catalog_path(source, bucket):
    digest = hashlib.md5(_catalog_key(source, bucket).encode("utf-8")).hexdigest()
    return os.path.join(get_cache_dir("source_catalog"), digest + ".json")


def _catalog_load(path):
    try:
        age = max(0, time.time() - os.path.getmtime(path))
        with open_text(path, "r", encoding="utf-8") as handle:
            rows = json.load(handle)
        return (list(rows), age) if isinstance(rows, list) else (None, None)
    except Exception:
        return None, None


def _catalog_save(path, rows):
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = path + ".tmp"
        with open_text(tmp, "w", encoding="utf-8") as handle:
            json.dump(list(rows or []), handle, ensure_ascii=False)
        atomic_replace(tmp, path)
    except Exception:
        pass


def _catalog_put(key, path, rows):
    safe_rows = list(rows or [])
    with _CATALOG_LOCK:
        _CATALOG_MEMORY[key] = (safe_rows, time.time())
    _catalog_save(path, safe_rows)
    return safe_rows


def _refresh_catalog(source, bucket, loader):
    # Refresh a catalog once in the background without delaying a visible page.
    source = dict(source or {})
    key = _catalog_key(source, bucket)
    with _CATALOG_LOCK:
        if key in _CATALOG_REFRESHING:
            return
        _CATALOG_REFRESHING.add(key)

    def worker():
        try:
            rows = list(loader() or [])
            _catalog_put(key, _catalog_path(source, bucket), rows)
        except Exception:
            pass
        finally:
            with _CATALOG_LOCK:
                _CATALOG_REFRESHING.discard(key)

    thread = threading.Thread(target=worker, name="TiviMateCatalogRefresh")
    thread.daemon = True
    thread.start()


def get_cached_catalog(source, bucket, loader, wait_for_server=False):
    # Return RAM/disk catalog data before network data for every source type.
    # The loader is evaluated only in a worker when wait_for_server is true;
    # stale rows remain usable while one daemon refreshes them.
    source = dict(source or {})
    key = _catalog_key(source, bucket)
    path = _catalog_path(source, bucket)
    now = time.time()
    with _CATALOG_LOCK:
        memory = _CATALOG_MEMORY.get(key)
    if memory is not None:
        rows, loaded_at = memory
        if now - loaded_at > CATALOG_CACHE_TTL:
            _refresh_catalog(source, bucket, loader)
            return list(rows or []), "stale"
        return list(rows or []), "ram"

    rows, age = _catalog_load(path)
    if rows is not None:
        with _CATALOG_LOCK:
            _CATALOG_MEMORY[key] = (list(rows), now - float(age or 0))
        if age is not None and age > CATALOG_CACHE_TTL:
            _refresh_catalog(source, bucket, loader)
            return list(rows), "stale"
        return list(rows), "disk"

    if wait_for_server:
        rows = list(loader() or [])
        return _catalog_put(key, path, rows), "server"

    _refresh_catalog(source, bucket, loader)
    return [], "loading"


def clear_catalog_memory():
    # Forget in-memory catalog data after the user explicitly clears cache.
    with _CATALOG_LOCK:
        _CATALOG_MEMORY.clear()
        _CATALOG_REFRESHING.clear()


def cached_image(url, kind="posters"):
    """Return an already-cached artwork file only.

    r88 keeps this helper read-only for callers that only need a local path.
    Screen artwork misses are handled separately by the bounded background queue,
    so DNS, HTTP, and conversion never execute on the Enigma2 GUI thread.
    """
    if not url:
        return ""
    ext = ".png" if ".png" in url.lower() else ".jpg"
    path = os.path.join(get_cache_dir(kind), hashlib.md5(url.encode("utf-8")).hexdigest() + ext)
    try:
        if os.path.exists(path) and os.path.getsize(path) >= 100:
            return path
    except Exception:
        pass
    return ""


class XtreamClient:
    def __init__(self, src):
        self.base=src.get("url","").rstrip("/"); self.user=src.get("username",""); self.password=src.get("password","")
    def api(self, action=None, **params):
        q={"username":self.user,"password":self.password}
        if action:q["action"]=action
        q.update(params)
        return fetch(self.base+"/player_api.php?"+urlencode(q), as_json=True)
    def test(self): return self.api()
    def categories(self, kind): return self.api({"live":"get_live_categories","vod":"get_vod_categories","series":"get_series_categories"}[kind])
    def streams(self, kind, category_id=""):
        action={"live":"get_live_streams","vod":"get_vod_streams","series":"get_series"}[kind]
        return self.api(action, category_id=category_id) if category_id else self.api(action)
    def vod_info(self, vod_id):
        return self.api("get_vod_info", vod_id=str(vod_id))
    def series_info(self, series_id):
        return self.api("get_series_info", series_id=str(series_id))
    def episode_url(self, episode):
        eid=str(episode.get("id") or episode.get("stream_id") or "")
        ext=episode.get("container_extension") or "mp4"
        return "%s/series/%s/%s/%s.%s"%(self.base,self.user,self.password,eid,ext)
    def stream_url(self,item,kind):
        sid=str(item.get("stream_id") or "")
        output = "ts"
        if kind=="live": return "%s/live/%s/%s/%s.%s"%(self.base,self.user,self.password,sid,output)
        ext=item.get("container_extension") or "mp4"
        if kind=="vod": return "%s/movie/%s/%s/%s.%s"%(self.base,self.user,self.password,sid,ext)
        return ""


class M3UClient:
    def __init__(self, src):
        self.url = src.get("url", "")

    def test(self):
        data = self._read()
        return {"ok": data.startswith(b"#EXTM3U"), "size": len(data)}

    def entries(self):
        text = self._read().decode("utf-8", "replace")
        out = []
        meta = None
        for raw in text.splitlines():
            line = raw.strip()
            if line.startswith("#EXTINF"):
                attrs = dict(re.findall(r"([\w-]+)=[\"']([^\"']*)[\"']", line))
                name = line.split(",", 1)[1].strip() if "," in line else attrs.get("tvg-name", "Channel")
                meta = {
                    "name": name,
                    "logo": attrs.get("tvg-logo", ""),
                    "group": attrs.get("group-title", "Other"),
                }
            elif line and not line.startswith("#") and meta:
                meta["url"] = line
                out.append(meta)
                meta = None
        return out

    def _read(self):
        # Playlist transport follows the same bounded timeout as every source.
        return fetch(self.url, timeout=NETWORK_TIMEOUT)


class StalkerClient:
    """Stalker / Ministra client with portal-aware session setup.

    This client is intentionally isolated from Xtream and M3U.  It keeps its token
    only in RAM, loads the small Packages list first, and fetches a package only
    when the user opens it.
    """
    PAGE_LIMIT = 3

    def __init__(self, src):
        src = src or {}
        self.portal = (src.get("url", "") or "").strip().rstrip("/")
        self.mac = (src.get("mac", "00:1A:79:00:00:00") or "").upper()
        self._token_key = "%s|%s" % (self.portal, self.mac)
        self.token = ""
        self._endpoint = ""
        self._profile_ready = False
        with _CATALOG_LOCK:
            saved = _STALKER_TOKENS.get(self._token_key)
        if saved and time.time() - saved[1] < _STALKER_TOKEN_TTL:
            self.token = saved[0]

    def headers(self):
        headers = {
            "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 MAG254 stbapp",
            "Cookie": "mac=%s; stb_lang=en; timezone=GMT" % self.mac,
            "X-User-Agent": "Model: MAG254; Link: Ethernet",
            "Referer": self.portal.rstrip("/") + "/",
            "Accept": "*/*",
        }
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
        return headers

    def endpoints(self):
        """Return likely Ministra endpoints without changing the saved Portal URL."""
        portal = self.portal.rstrip("/")
        if not portal:
            return []
        if portal.endswith(".php"):
            return [portal]
        roots = [portal]
        if portal.endswith("/c"):
            roots.append(portal[:-2].rstrip("/"))
        candidates = []
        for root in roots:
            candidates.extend((root + "/portal.php", root + "/server/load.php", root + "/load.php"))
        unique = []
        for value in candidates:
            if value not in unique:
                unique.append(value)
        return unique

    def endpoint(self):
        choices = self.endpoints()
        return self._endpoint or (choices[0] if choices else "")

    def _decode(self, value):
        if isinstance(value, bytes):
            try:
                value = value.decode("utf-8", "ignore")
            except Exception:
                return value
        if isinstance(value, str):
            raw = value.strip()
            if raw.startswith(("{", "[")):
                try:
                    return json.loads(raw)
                except Exception:
                    pass
        return value

    def _portal_js(self, response):
        response = self._decode(response)
        if not isinstance(response, dict):
            return {}
        value = response.get("js", response.get("data", response))
        return self._decode(value)

    def _response_error(self, response):
        raw = self._decode(response)
        if not isinstance(raw, dict):
            return "Invalid portal response"
        for container in (raw, self._portal_js(raw)):
            if not isinstance(container, dict):
                continue
            error = container.get("error") or container.get("error_msg") or container.get("faultString")
            if error:
                return str(error)
        return ""

    def _stalker_json_request(self, url):
        """Read one bounded Stalker JSON response without relying on EOF.

        Some legacy Ministra/Stalker front ends send a complete JSON document and
        then leave the connection open despite ``Connection: close``.  The
        generic ``urlopen(...).read()`` transport waits for EOF, times out, and
        loses the usable body.  This Stalker-only reader returns as soon as a
        complete JSON document is received, while retaining the same bounded
        timeout and an explicit response-size limit.
        """
        parsed = urlparse(url)
        host = parsed.hostname
        if not host:
            raise RuntimeError("Invalid Stalker portal URL")
        try:
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
        except Exception:
            port = 443 if parsed.scheme == "https" else 80
        target = parsed.path or "/"
        if parsed.query:
            target += "?" + parsed.query
        request_headers = self.headers()
        request_headers["Host"] = parsed.netloc
        request_headers["Connection"] = "close"
        request_headers["Accept"] = "*/*"
        lines = ["GET %s HTTP/1.0" % target]
        for key, value in request_headers.items():
            lines.append("%s: %s" % (key, value))
        wire = "\r\n".join(lines) + "\r\n\r\n"
        try:
            payload = wire.encode("utf-8")
        except Exception:
            payload = wire
        sock = socket.create_connection((host, port), NETWORK_TIMEOUT)
        try:
            if parsed.scheme == "https":
                try:
                    context = ssl._create_unverified_context()
                    sock = context.wrap_socket(sock, server_hostname=host)
                except Exception:
                    sock = ssl.wrap_socket(sock, cert_reqs=ssl.CERT_NONE)
            sock.sendall(payload)
            sock.settimeout(NETWORK_TIMEOUT)
            received = b""
            header_end = -1
            body = b""
            status = ""
            limit = 4 * 1024 * 1024
            deadline = time.time() + NETWORK_TIMEOUT
            response = None
            while time.time() < deadline and len(received) < limit:
                try:
                    chunk = sock.recv(65536)
                except socket.timeout:
                    break
                if not chunk:
                    break
                received += chunk
                if header_end < 0:
                    header_end = received.find(b"\r\n\r\n")
                    if header_end < 0:
                        continue
                    try:
                        status = received[:header_end].decode("iso-8859-1", "replace").split("\r\n", 1)[0]
                    except Exception:
                        status = ""
                body = received[header_end + 4:]
                try:
                    response = json.loads(body.decode("utf-8", "replace").strip())
                    break
                except Exception:
                    response = None
            else:
                response = None
            if response is None and header_end >= 0:
                try:
                    response = json.loads(body.decode("utf-8", "replace").strip())
                except Exception:
                    response = None
            if response is None:
                raise RuntimeError("Stalker portal did not return complete JSON")
            if status and not status.startswith("HTTP/"):
                raise RuntimeError("Invalid Stalker HTTP response")
            return response
        finally:
            try:
                sock.close()
            except Exception:
                pass

    def _request_endpoint(self, endpoint, query):
        separator = "&" if "?" in endpoint else "?"
        response = self._stalker_json_request(endpoint + separator + urlencode(query))
        error = self._response_error(response)
        if error:
            raise RuntimeError(error)
        if not isinstance(self._decode(response), dict):
            raise RuntimeError("Portal returned an invalid response")
        return response

    def call(self, **query):
        """Call each compatible endpoint until one supplies a valid response."""
        choices = []
        if self._endpoint:
            choices.append(self._endpoint)
        for candidate in self.endpoints():
            if candidate not in choices:
                choices.append(candidate)
        if not choices:
            raise RuntimeError("Portal URL is empty")
        last_error = None
        for endpoint in choices:
            try:
                response = self._request_endpoint(endpoint, query)
                self._endpoint = endpoint
                return response
            except Exception as exc:
                last_error = exc
        raise last_error or RuntimeError("Portal request failed")

    def handshake(self):
        last_error = None
        for endpoint in self.endpoints():
            try:
                response = self._request_endpoint(endpoint, {
                    "type": "stb", "action": "handshake", "token": "", "JsHttpRequest": "1-xml"
                }) or {}
                js = self._portal_js(response)
                token = (js or {}).get("token", "") if isinstance(js, dict) else ""
                if token:
                    self._endpoint = endpoint
                    self.token = str(token)
                    self._profile_ready = False
                    with _CATALOG_LOCK:
                        _STALKER_TOKENS[self._token_key] = (self.token, time.time())
                    return True
            except Exception as exc:
                last_error = exc
        self._endpoint = ""
        self.token = ""
        self._profile_ready = False
        return False

    def _ensure_token(self):
        return bool(self.token) or self.handshake()

    def _drop_token(self):
        self.token = ""
        self._profile_ready = False
        with _CATALOG_LOCK:
            _STALKER_TOKENS.pop(self._token_key, None)

    def _ensure_profile(self):
        """Complete the MAG profile step required by many portals before catalog calls."""
        if self._profile_ready:
            return True
        if not self._ensure_token():
            return False
        query = {
            "type": "stb", "action": "get_profile", "hd": "1", "ver": "ImageDescription: 0.2.18-r23-254; ImageDate: Thu Oct 15 15:06:42 EEST 2015;",
            "num_banks": "2", "sn": "000000000000000", "stb_type": "MAG254", "image_version": "218", "video_out": "hdmi",
            "JsHttpRequest": "1-xml",
        }
        try:
            self.call(**query)
            self._profile_ready = True
            return True
        except Exception:
            # Several older Stalker installations expose lists immediately after
            # handshake; do not reject those portals merely because get_profile is absent.
            self._profile_ready = True
            return True

    def test(self):
        ok = self.handshake()
        if ok:
            self._ensure_profile()
        return {"ok": ok, "token": bool(self.token), "endpoint": self._endpoint}

    def _call_retry(self, **query):
        if not self._ensure_token():
            raise RuntimeError("Stalker handshake was rejected by the portal")
        self._ensure_profile()
        try:
            return self.call(**query) or {}
        except Exception:
            self._drop_token()
            if not self._ensure_token():
                raise RuntimeError("Stalker session could not be renewed")
            self._ensure_profile()
            return self.call(**query) or {}

    def _portal_rows(self, response):
        """Return a row list from the common Stalker/Ministra response envelopes.

        Different portal versions put the same list below ``js``, ``data``,
        ``result``, ``items`` or a JSON-encoded variant of one of those fields.
        The traversal is deliberately bounded and read-only.
        """
        pending = [self._portal_js(response)]
        visited = set()
        list_keys = ("data", "items", "channels", "results", "list", "content", "rows", "movies", "series", "vod")
        wrapper_keys = ("js", "data", "result", "results", "response", "payload", "content", "list")
        while pending:
            candidate = self._decode(pending.pop(0))
            if isinstance(candidate, list):
                return candidate
            if not isinstance(candidate, dict):
                continue
            marker = id(candidate)
            if marker in visited:
                continue
            visited.add(marker)
            for key in list_keys:
                value = self._decode(candidate.get(key))
                if isinstance(value, list):
                    return value
            for key in wrapper_keys:
                value = self._decode(candidate.get(key))
                if isinstance(value, (dict, list)):
                    pending.append(value)
        return []

    def _portal_payload(self, response):
        """Return the useful payload while preserving detail dictionaries."""
        js = self._portal_js(response)
        if not isinstance(js, dict):
            return js
        for key in ("data", "result", "results", "response", "payload", "content"):
            value = self._decode(js.get(key))
            if isinstance(value, (dict, list)):
                return value
        return js

    def _categories(self, api_type, actions):
        """Fetch portal packages, tolerating unavailable compatibility actions."""
        for action in actions:
            try:
                response = self._call_retry(type=api_type, action=action, JsHttpRequest="1-xml")
            except Exception:
                continue
            rows, seen = [], set()
            for item in self._portal_rows(response):
                if not isinstance(item, dict):
                    continue
                cid = item.get("id") or item.get("category_id") or item.get("genre_id") or item.get("value") or item.get("alias") or item.get("category")
                if cid is None or str(cid).strip() == "":
                    continue
                cid = str(cid)
                if cid in seen:
                    continue
                seen.add(cid)
                title = item.get("title") or item.get("name") or item.get("category_name") or item.get("alias") or item.get("label") or "Other"
                rows.append({
                    "category_id": cid, "genre_id": cid,
                    "category_name": title,
                    "_stalker_category_type": item.get("type") or item.get("content_type") or "",
                    "_stalker_is_series": item.get("is_series") or item.get("series") or "",
                })
            if rows:
                return rows
        return []

    def _list_query_variants(self, api_type, action, category_id, page):
        """Build a short, ordered list of non-conflicting catalog requests.

        IPTV keeps the r105 request unchanged.  VOD/Series portals differ on
        whether a package is called ``category``, ``genre`` or ``category_id``;
        sending all aliases together causes valid portals to return an empty list.
        """
        base = {
            "type": api_type, "action": action, "p": str(page), "fav": "0",
            "hd": "1", "force_ch_link_check": "0", "JsHttpRequest": "1-xml"
        }
        if api_type not in ("vod", "series"):
            query = dict(base)
            query["sortby"] = "number"
            if category_id:
                query["category"] = str(category_id)
                query["genre"] = str(category_id)
            return [query]
        if not category_id:
            query = dict(base)
            query["sortby"] = "number"
            return [query]
        variants, seen = [], set()

        def add_query(query):
            marker = tuple(sorted((str(key), str(value)) for key, value in query.items()))
            if marker not in seen:
                seen.add(marker)
                variants.append(query)

        # The ordinary MAG convention is category.  It is tried first to keep
        # normal portals just as quick as r105.
        for key in ("category", "genre", "category_id", "genre_id"):
            query = dict(base)
            query["sortby"] = "number"
            query[key] = str(category_id)
            add_query(query)
            # Some older forks reject an unknown sortby field completely.
            query = dict(base)
            query[key] = str(category_id)
            add_query(query)
        query = dict(base)
        query["sortby"] = "number"
        query["category"] = str(category_id)
        query["genre"] = str(category_id)
        add_query(query)
        return variants

    def _portal_total(self, response):
        for payload in (self._portal_js(response), self._portal_payload(response)):
            if not isinstance(payload, dict):
                continue
            for key in ("total_items", "total", "total_count", "count"):
                try:
                    value = int(payload.get(key) or 0)
                except Exception:
                    value = 0
                if value:
                    return value
        return 0

    def _paged_rows(self, api_type, action, category_id="", max_pages=None):
        # Load a small bounded first slice so opening one Package is responsive on
        # low-power receivers.  Further Packages are loaded only when selected.
        max_pages = self.PAGE_LIMIT if max_pages is None else max(1, int(max_pages))
        rows, seen = [], set()
        page = 1
        while page <= max_pages:
            page_rows, total = [], 0
            for query in self._list_query_variants(api_type, action, category_id, page):
                try:
                    response = self._call_retry(**query)
                except Exception:
                    continue
                candidate = self._portal_rows(response)
                if candidate:
                    page_rows = candidate
                    total = self._portal_total(response)
                    break
            if not page_rows:
                break
            added = 0
            for item in page_rows:
                if not isinstance(item, dict):
                    continue
                identity = str(item.get("id") or item.get("stream_id") or item.get("vod_id") or item.get("movie_id") or item.get("series_id") or item.get("cmd") or item.get("name") or item.get("title") or "")
                if identity and identity in seen:
                    continue
                if identity:
                    seen.add(identity)
                rows.append(item)
                added += 1
            if not added or (total and len(rows) >= total) or (len(page_rows) < 2 and not total):
                break
            page += 1
        return rows

    def _normalise_live(self, item):
        item = dict(item or {})
        sid = item.get("id") or item.get("stream_id") or item.get("channel_id")
        cid = item.get("genre_id") or item.get("category_id") or item.get("genre") or ""
        logo = item.get("logo") or item.get("stream_icon") or item.get("icon") or item.get("screenshot_uri") or ""
        return {
            "stream_id": str(sid or ""), "id": str(sid or ""),
            "name": item.get("name") or item.get("title") or "CHANNEL",
            "title": item.get("name") or item.get("title") or "CHANNEL",
            "category_id": str(cid), "genre_id": str(cid),
            "stream_icon": logo, "logo": logo,
            "description": item.get("description") or item.get("plot") or "",
            "cmd": item.get("cmd") or item.get("command") or "",
            "_stalker_live": True,
        }

    def channels(self):
        response = self._call_retry(type="itv", action="get_all_channels", JsHttpRequest="1-xml")
        rows = self._portal_rows(response)
        if not rows:
            rows = self._paged_rows("itv", "get_ordered_list", max_pages=1)
        return [self._normalise_live(item) for item in rows if isinstance(item, dict)]

    def live_categories(self):
        rows = self._categories("itv", ("get_genres", "get_categories"))
        if rows:
            return rows
        categories, seen = [], set()
        for item in self.channels():
            cid = item.get("category_id") or item.get("genre_id")
            if not cid or cid in seen:
                continue
            seen.add(cid)
            categories.append({"category_id": str(cid), "genre_id": str(cid), "category_name": "Live TV"})
        return categories

    def live_streams(self, category_id=""):
        rows = self._paged_rows("itv", "get_ordered_list", category_id)
        if not rows and not category_id:
            rows = self.channels()
        normal = [self._normalise_live(item) if not item.get("_stalker_live") else item for item in rows]
        if category_id:
            wanted = str(category_id)
            normal = [item for item in normal if str(item.get("category_id") or item.get("genre_id") or "") == wanted or not (item.get("category_id") or item.get("genre_id"))]
        return normal

    def _catalog_rows(self, attempts, category_id="", max_pages=None):
        """Try documented and common fork-specific catalog actions in order."""
        for api_type, action in attempts:
            try:
                rows = self._paged_rows(api_type, action, category_id, max_pages)
            except Exception:
                rows = []
            if rows:
                return rows
        return []

    def _first_item_value(self, item, keys, default=""):
        item = item if isinstance(item, dict) else {}
        info = item.get("info") if isinstance(item.get("info"), dict) else {}
        for mapping in (item, info):
            for key in keys:
                value = mapping.get(key)
                if isinstance(value, (dict, list)) or value is None:
                    continue
                try:
                    if str(value).strip():
                        return value
                except Exception:
                    continue
        return default

    def _portal_asset(self, value):
        """Make a portal-relative poster/backdrop usable by the image queue."""
        try:
            value = (value or "").strip().replace("\\/", "/")
        except Exception:
            return ""
        if not value or value.startswith(("http://", "https://", "data:")):
            return value
        parsed = urlparse(self.portal)
        if not parsed.scheme or not parsed.netloc:
            return value
        root = "%s://%s" % (parsed.scheme, parsed.netloc)
        if value.startswith("//"):
            return parsed.scheme + ":" + value
        if value.startswith("/"):
            return root + value
        path = (parsed.path or "").rstrip("/")
        if path.endswith("/c"):
            path = path[:-2].rstrip("/")
        return root + path + "/" + value.lstrip("/")

    def _is_series_item(self, item):
        marker = self._first_item_value(item, ("is_series", "is_tv", "is_tvshow", "series", "series_type"), "")
        marker = str(marker).strip().lower()
        if marker in ("1", "true", "yes", "series", "tv", "tvshow", "tv_show"):
            return True
        kind = self._first_item_value(item, ("type", "content_type", "item_type", "media_type"), "")
        kind = str(kind).strip().lower()
        if "series" in kind or "tv" in kind or "show" in kind:
            return True
        return bool(self._first_item_value(item, ("series_id",), "") and not self._first_item_value(item, ("movie_id", "vod_id"), ""))

    def _is_series_category(self, category):
        category = category if isinstance(category, dict) else {}
        marker = str(category.get("_stalker_is_series") or category.get("_stalker_category_type") or "").lower()
        if marker in ("1", "true", "yes", "series", "tv", "tvshow", "tv_show") or "series" in marker:
            return True
        name = str(category.get("category_name") or "").lower()
        keywords = ("series", "séries", "serial", "сериал", "dizi", "مسلسل", "مسلسلات", "show", "tv")
        return any(keyword in name for keyword in keywords)

    def _valid_catalog_item(self, item):
        try:
            return bool(str((item or {}).get("stream_id") or "").strip() and str((item or {}).get("name") or "").strip())
        except Exception:
            return False

    def vod_categories(self):
        return self._categories("vod", ("get_categories", "get_genres"))

    def _normalise_vod(self, item):
        item = dict(item or {})
        sid = self._first_item_value(item, ("id", "stream_id", "vod_id", "movie_id", "film_id", "item_id"), "")
        cid = self._first_item_value(item, ("category_id", "category", "genre_id", "genre", "group_id"), "")
        cmd = self._first_item_value(item, ("cmd", "command", "stream_url", "url"), "")
        title = self._first_item_value(item, ("name", "title", "movie_name", "o_name", "original_name", "display_name"), "MOVIE")
        poster = self._portal_asset(self._first_item_value(item, ("screenshot_uri", "cover", "stream_icon", "image", "movie_image", "poster", "poster_url", "poster_path", "cover_big"), ""))
        backdrop = self._portal_asset(self._first_item_value(item, ("backdrop", "backdrop_path", "backdrop_url", "fanart", "background"), ""))
        description = self._first_item_value(item, ("description", "plot", "about", "story", "overview"), "")
        return {
            "stream_id": str(sid or ""), "vod_id": str(sid or ""),
            "name": title, "title": title,
            "category_id": str(cid or ""), "genre_id": str(cid or ""), "stream_icon": poster, "cover": poster,
            "backdrop": backdrop,
            "description": description, "plot": description,
            "rating": self._first_item_value(item, ("rating_imdb", "rating", "imdb_rating", "score"), ""), "year": self._first_item_value(item, ("year", "releasedate", "release_date", "release_year"), ""),
            "added": self._first_item_value(item, ("added", "added_date", "created", "created_at"), "0"), "container_extension": self._first_item_value(item, ("container_extension", "extension", "format"), "mp4"),
            "cmd": cmd, "_stalker_vod": True, "_stalker_link_type": "vod",
        }

    def vod_streams(self, category_id="", max_pages=None):
        rows = self._catalog_rows((("vod", "get_ordered_list"), ("vod", "get_vod_list"), ("vod", "get_movies")), category_id, max_pages)
        normal = [self._normalise_vod(item) for item in rows if isinstance(item, dict) and not self._is_series_item(item)]
        return [item for item in normal if self._valid_catalog_item(item)]

    def series_categories(self):
        rows = self._categories("series", ("get_categories", "get_genres"))
        if rows:
            return rows
        # Many MAG portals place TV Shows in the VOD catalog and mark list rows
        # with is_series=1.  Prefer clearly named packages, then retain all VOD
        # packages only when the provider uses an unknown language/name scheme.
        fallback = self.vod_categories()
        marked = [row for row in fallback if self._is_series_category(row)]
        return marked or fallback

    def _normalise_series(self, item, link_type="series"):
        item = dict(item or {})
        sid = self._first_item_value(item, ("id", "series_id", "stream_id", "vod_id", "movie_id", "item_id"), "")
        cid = self._first_item_value(item, ("category_id", "category", "genre_id", "genre", "group_id"), "")
        title = self._first_item_value(item, ("name", "title", "series_name", "o_name", "original_name", "display_name"), "TV SHOW")
        poster = self._portal_asset(self._first_item_value(item, ("screenshot_uri", "cover", "stream_icon", "image", "movie_image", "poster", "poster_url", "poster_path", "cover_big"), ""))
        backdrop = self._portal_asset(self._first_item_value(item, ("backdrop", "backdrop_path", "backdrop_url", "fanart", "background"), ""))
        description = self._first_item_value(item, ("description", "plot", "about", "story", "overview"), "")
        return {
            "stream_id": str(sid or ""), "series_id": str(sid or ""),
            "name": title, "title": title,
            "category_id": str(cid or ""), "genre_id": str(cid or ""), "stream_icon": poster, "cover": poster,
            "backdrop": backdrop,
            "description": description, "plot": description,
            "rating": self._first_item_value(item, ("rating_imdb", "rating", "imdb_rating", "score"), ""), "year": self._first_item_value(item, ("year", "releasedate", "release_date", "release_year"), ""),
            "added": self._first_item_value(item, ("added", "added_date", "created", "created_at"), "0"), "cmd": self._first_item_value(item, ("cmd", "command", "stream_url", "url"), ""),
            "_stalker_series": True, "_stalker_link_type": link_type,
        }

    def series_streams(self, category_id="", max_pages=None):
        rows = self._catalog_rows((("series", "get_ordered_list"), ("series", "get_series_list"), ("series", "get_all_series")), category_id, max_pages)
        if rows:
            normal = [self._normalise_series(item, "series") for item in rows if isinstance(item, dict)]
            return [item for item in normal if self._valid_catalog_item(item)]
        if not category_id:
            return []
        rows = self._catalog_rows((("vod", "get_ordered_list"), ("vod", "get_vod_list"), ("vod", "get_movies")), category_id, max_pages)
        normal = [self._normalise_series(item, "vod") for item in rows if isinstance(item, dict) and self._is_series_item(item)]
        return [item for item in normal if self._valid_catalog_item(item)]

    def categories(self, kind):
        if kind == "live": return self.live_categories()
        if kind == "vod": return self.vod_categories()
        if kind == "series": return self.series_categories()
        return []

    def streams(self, kind, category_id=""):
        if kind == "live": return self.live_streams(category_id)
        if kind == "vod": return self.vod_streams(category_id)
        if kind == "series": return self.series_streams(category_id)
        return []

    def _normalise_episode(self, item, season="", link_type="series"):
        item = dict(item or {})
        info = item.get("info") if isinstance(item.get("info"), dict) else {}
        number = item.get("episode_num") or item.get("episode_number") or item.get("number") or info.get("episode_num") or info.get("episode_number") or ""
        season_num = item.get("season") or item.get("season_number") or info.get("season") or info.get("season_number") or season or "1"
        cmd = item.get("cmd") or item.get("command") or item.get("stream_url") or info.get("cmd") or ""
        image = item.get("movie_image") or item.get("cover") or item.get("stream_icon") or item.get("screenshot_uri") or item.get("poster") or info.get("movie_image") or info.get("cover") or ""
        image = self._portal_asset(image)
        title = item.get("title") or item.get("name") or item.get("episode_name") or info.get("title") or info.get("name") or "Episode %s" % (number or "")
        eid = item.get("id") or item.get("stream_id") or item.get("episode_id") or item.get("vod_id") or item.get("movie_id") or ""
        return {
            "id": str(eid), "stream_id": str(eid),
            "title": title, "name": title,
            "episode_num": number, "episode_number": number, "season": str(season_num), "season_number": str(season_num),
            "cmd": cmd, "movie_image": image, "cover": image, "stream_icon": image, "info": info, "_stalker_episode": True, "_stalker_link_type": link_type,
        }

    def _normalise_series_info(self, payload, fallback, link_type="series"):
        raw = payload or {}
        if isinstance(raw, list): raw = {"episodes": raw}
        if not isinstance(raw, dict): return {"info": {}, "episodes": {}, "seasons": []}
        # Some portals wrap a series record twice, e.g. js.result.data.  Unwrap
        # only structural dictionaries and stop as soon as episode/info fields
        # become visible, so real detail metadata is never discarded.
        for _unused in range(3):
            nested = None
            for key in ("data", "result", "results", "response", "payload", "content"):
                value = self._decode(raw.get(key)) if isinstance(raw, dict) else None
                if isinstance(value, dict) and ("episodes" in value or "info" in value or "seasons" in value):
                    nested = value
                    break
            if nested is None:
                break
            raw = nested
        info = raw.get("info") if isinstance(raw.get("info"), dict) else {}
        if not info:
            info = {key: raw.get(key) for key in ("name", "title", "description", "plot", "rating", "year", "cover", "backdrop") if raw.get(key) is not None}
        episodes = raw.get("episodes") or raw.get("items") or raw.get("data") or []
        if not episodes:
            inferred = {}
            for key, value in raw.items():
                if str(key).isdigit() and isinstance(value, (list, dict)):
                    inferred[key] = value
            episodes = inferred
        grouped = {}
        if isinstance(episodes, dict):
            for season, values in episodes.items():
                if isinstance(values, dict): values = values.get("episodes") or values.get("items") or values.get("data") or [values]
                if not isinstance(values, list): continue
                key = str(season or "1")
                grouped[key] = [self._normalise_episode(value, key, link_type) for value in values if isinstance(value, dict)]
        elif isinstance(episodes, list):
            for value in episodes:
                if not isinstance(value, dict): continue
                normal = self._normalise_episode(value, "", link_type)
                key = str(normal.get("season") or "1")
                grouped.setdefault(key, []).append(normal)
        seasons = [{"season_number": key, "name": "Season %s" % key} for key in sorted(grouped.keys(), key=lambda value: int(value) if str(value).isdigit() else 999)]
        return {"info": info, "episodes": grouped, "seasons": seasons}

    def series_info(self, series_id):
        sid = str(series_id or "")
        if not sid: return {"info": {}, "episodes": {}, "seasons": []}
        params = {"series_id": sid, "id": sid, "movie_id": sid, "vod_id": sid, "JsHttpRequest": "1-xml"}
        fallback = None
        routes = (
            ("series", ("get_series", "get_series_info", "get_episodes")),
            ("vod", ("get_series", "get_series_info", "get_episodes", "get_vod_info")),
        )
        for api_type, actions in routes:
            for action in actions:
                try:
                    response = self._call_retry(type=api_type, action=action, **params)
                except Exception:
                    continue
                normalized = self._normalise_series_info(self._portal_payload(response), sid, api_type)
                if normalized.get("episodes"):
                    return normalized
                if normalized.get("info") and fallback is None:
                    fallback = normalized
        return fallback or {"info": {}, "episodes": {}, "seasons": []}

    def vod_info(self, vod_id):
        params = {"vod_id": str(vod_id or ""), "id": str(vod_id or ""), "movie_id": str(vod_id or ""), "JsHttpRequest": "1-xml"}
        for action in ("get_vod_info", "get_movie_info", "get_info"):
            try:
                response = self._call_retry(type="vod", action=action, **params)
            except Exception:
                continue
            payload = self._portal_payload(response)
            if isinstance(payload, dict):
                return payload
            if isinstance(payload, list) and payload and isinstance(payload[0], dict):
                return payload[0]
        return {}

    def _extract_link(self, response):
        for payload in (self._portal_js(response), self._portal_payload(response)):
            if isinstance(payload, dict):
                command = payload.get("cmd") or payload.get("url") or payload.get("stream_url") or ""
            elif isinstance(payload, str):
                command = payload
            else:
                command = ""
            if command:
                command = str(command).replace("\\/", "/")
                if command.startswith("ffmpeg "):
                    return command.split(" ", 1)[-1]
                return command
        return ""

    def _create_link(self, kind, item_id, cmd=""):
        query = {"type": kind, "action": "create_link", "cmd": cmd or str(item_id or ""), "id": str(item_id or ""), "JsHttpRequest": "1-xml"}
        return self._extract_link(self._call_retry(**query))

    def create_vod_link(self, item):
        item = item or {}
        return self._create_link("vod", item.get("vod_id") or item.get("stream_id"), item.get("cmd"))

    def create_series_link(self, item):
        item = item or {}
        kind = item.get("_stalker_link_type") or "series"
        if kind not in ("series", "vod"):
            kind = "series"
        return self._create_link(kind, item.get("series_id") or item.get("stream_id") or item.get("id"), item.get("cmd"))

    def stream_url(self, item, kind="live"):
        item = item or {}
        if kind == "live":
            return self._create_link("itv", item.get("stream_id") or item.get("id"), item.get("cmd"))
        if kind == "series":
            return self.create_series_link(item)
        return self.create_vod_link(item)



def get_source_client(source):
    """Return the catalogue client matching a configured source type."""
    source = source or {}
    if source.get("type") == "stalker":
        return StalkerClient(source)
    if source.get("type") == "m3u":
        return M3UClient(source)
    return XtreamClient(source)
