# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, re, json, unicodedata

PLUGIN_PATH = os.path.dirname(__file__)
ALIASES_FILE = os.path.join(PLUGIN_PATH, "package_logo_aliases.json")
LOGO_DIR = os.path.join(PLUGIN_PATH, "resources", "package_logos")
_CACHE = None

def _norm(value):
    text = str(value or "").strip().lower()
    try:
        text = unicodedata.normalize("NFKC", text)
    except Exception:
        pass
    text = text.replace("_", " ").replace("-", " ").replace("|", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text

def load_aliases():
    global _CACHE
    if isinstance(_CACHE, dict):
        return _CACHE
    try:
        with open(ALIASES_FILE, "r") as handle:
            data = json.load(handle)
        _CACHE = data if isinstance(data, dict) else {}
    except Exception:
        _CACHE = {}
    return _CACHE

def resolve_package_logo(name):
    text = _norm(name)
    compact = re.sub(r"[^a-z0-9+\u0600-\u06ff]+", "", text)
    for key, spec in load_aliases().items():
        if not isinstance(spec, dict):
            continue
        for alias in spec.get("aliases") or []:
            a = _norm(alias)
            if not a:
                continue
            ac = re.sub(r"[^a-z0-9+\u0600-\u06ff]+", "", a)
            # Exact, token/phrase containment, then compact containment.
            if text == a or a in text or (ac and ac in compact):
                filename = str(spec.get("file") or "")
                path = os.path.join(LOGO_DIR, filename) if filename else ""
                return (key, path if path and os.path.isfile(path) else "")
    return ("", "")

def package_logo_path(name):
    return resolve_package_logo(name)[1]

def package_provider_key(name):
    return resolve_package_logo(name)[0]


def package_logo_for_key(key):
    """Return a logo path for a canonical manifest key."""
    spec = load_aliases().get(str(key or "").strip().lower()) or {}
    filename = str(spec.get("file") or "") if isinstance(spec, dict) else ""
    path = os.path.join(LOGO_DIR, filename) if filename else ""
    return path if path and os.path.isfile(path) else ""
