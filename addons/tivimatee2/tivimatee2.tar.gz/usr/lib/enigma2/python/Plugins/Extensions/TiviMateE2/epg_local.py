# -*- coding: utf-8 -*-

from .storage import get_data_root, data_path
import calendar
import difflib
import gzip
import json
import os
import re
import tempfile
import threading
import time
from urllib.parse import urlencode
from urllib.request import Request, urlopen
try:
    from xml.etree.cElementTree import iterparse
except Exception:
    from xml.etree.ElementTree import iterparse

from .cache_manager import get_log_path
from .compat import ensure_dir, open_text, atomic_replace

def _epg_storage_base():
    """Keep large EPG data off receiver flash.

    Preferred order:
      1. HDD/USB persistent storage when mounted and writable.
      2. /tmp as an ephemeral fallback when no external storage exists.

    Never store generated EPG data under /etc/enigma2 or the plugin directory.
    """
    candidates = (
        "/media/hdd",
        "/hdd",
        "/media/usb",
        "/media/usb0",
        "/media/usb1",
        "/media/sda1",
        "/media/sdb1",
    )

    for mount in candidates:
        try:
            if not os.path.isdir(mount):
                continue
            # Reject empty mount directories that are merely on root flash.
            mounted = os.path.ismount(mount)
            if not mounted:
                try:
                    mounted = os.path.ismount(os.path.realpath(mount))
                except Exception:
                    mounted = False
            if not mounted:
                continue
            if not os.access(mount, os.W_OK):
                continue

            base = data_path("epg")
            try:
                if not os.path.isdir(base):
                    os.makedirs(base)
                return base
            except Exception:
                continue
        except Exception:
            continue

    base = data_path("epg")
    try:
        if not os.path.isdir(base):
            os.makedirs(base)
    except Exception:
        pass
    return base


BASE_DIR = _epg_storage_base()
UA = "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/1.0"
MAX_AGE = 4 * 3600
# r458: Primary stays the playlist/Xtream XMLTV. Fallback is split by scope:
# MENA feeds are used only for selected movie/entertainment brands, while UK/US
# feeds can fill any still-missing enabled channels. Primary always wins.
FALLBACK_EPG_SPECS = (
    ("https://epgshare01.online/epgshare01/epg_ripper_AE1.xml.gz", "arabic"),
    ("https://epgshare01.online/epgshare01/epg_ripper_BEIN1.xml.gz", "bein"),
    ("https://epgshare01.online/epgshare01/epg_ripper_UK1.xml.gz", "all"),
    ("https://epgshare01.online/epgshare01/epg_ripper_US2.xml.gz", "all"),
)

ARABIC_FALLBACK_KEYS = (
    "mbc1", "mbc2", "mbc3", "mbc4", "mbc5", "mbcmasr", "mbcmasr1", "mbcmasr2", "mbcmax", "mbcaction", "mbcbollywood",
    "mbcthriller", "tash", "fairuz", "shahid", "shahidvip",
    "dubai", "dubaitv", "dubaione", "abudhabi", "ad tv", "adtv", "sharjah",
    "aljazeera", "osn", "beinmovies", "beinmovie", "beinentertainment",
)
BEIN_FALLBACK_KEYS = ("beinsports", "bein sports", "beinmovies", "beinmovie", "beinentertainment")
_LOCK = threading.Lock()
_RUNNING = set()

def _external_epg_enabled(source):
    """Return the per-server External Live EPG switch without any disk I/O."""
    value = (source or {}).get("external_live_epg", False)
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "on", "enabled")


def _safe_name(value, fallback="IPTV"):
    value = (value or fallback).strip() or fallback
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_")
    return value or fallback


def _source_slug(source):
    return _safe_name((source or {}).get("name") or "IPTV")


def epg_json_path(source):
    return os.path.join(BASE_DIR, _source_slug(source), "epg.json")


def epg_alias_path(source):
    return os.path.join(BASE_DIR, _source_slug(source), "epg_aliases.json")


def _normalise_channel_name(value):
    """Normalize provider/XMLTV channel labels for matching only.

    Keep real channel words (including Arabic/Unicode letters) while stripping
    playlist decorations such as country/language prefixes and quality tags.
    The visible channel name itself is never changed.
    """
    value = str(value or "").strip().lower()
    if not value:
        return ""

    # Normalize common Arabic/Persian decimal digits so numbered channels match.
    try:
        value = value.translate(str.maketrans(
            "٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹",
            "01234567890123456789"
        ))
    except Exception:
        pass

    value = value.replace("&", " and ")
    value = value.replace("ـ", "")
    # Conservative Arabic letter folding for channel-name variants.
    value = value.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا").replace("ٱ", "ا")
    value = value.replace("ى", "ي")
    # Arabic vowel/diacritic marks should not affect an EPG match.
    value = re.sub(r"[\u064b-\u065f\u0670\u06d6-\u06ed]", "", value)

    # Bracket blocks in IPTV lists are normally provider/language decorations.
    value = re.sub(r"\[[^\]]*\]", " ", value)

    # Remove parenthesized blocks only when they contain decoration tokens; do
    # not erase meaningful names such as OSN Movies (Action).
    deco = r"(?:4k|8k|uhd|fhd|full\s*hd|hd|sd|hevc|h\.?265|h\.?264|50\s*fps|60\s*fps|arabic|english|french|العربية|عربي|انجليزي|إنجليزي)"
    value = re.sub(r"\(\s*" + deco + r"(?:\s*[/|,+-]\s*" + deco + r")*\s*\)", " ", value, flags=re.I)

    # Drop provider/country/language prefixes only when clearly separated from
    # the real channel name by ':' '|' '-' or ';'. Repeat for stacked prefixes.
    prefix = r"(?:vip|premium|server\s*\d*|live|raw|backup|uae|ae|ksa|saudi|sa|qatar|qa|kuwait|kw|bahrain|bh|oman|om|egypt|eg|jordan|jo|lebanon|lb|iraq|iq|uk|gb|us|usa|ar|arabic|en|eng|english|fr|french|de|it|es|pt|nl|be|ch|at|my|au|ca|ie|in|tr|gr|se|no|dk|fi|الامارات|الإمارات|السعودية|عربي|العربية)"
    for _ in range(4):
        cleaned = re.sub(r"^\s*[|:;\-–—]*\s*" + prefix + r"\s*[|:;\-–—]+\s*", "", value, count=1, flags=re.I)
        if cleaned == value:
            break
        value = cleaned

    # Quality/codec labels may appear anywhere around the real name.
    value = re.sub(r"\b(?:4k|8k|uhd|fhd|full\s*hd|hd|sd|hevc|h\.?265|h\.?264|50\s*fps|60\s*fps)\b", " ", value, flags=re.I)

    # Preserve Unicode letters/digits (Arabic included), remove punctuation,
    # whitespace and underscores to produce one stable comparison token.
    value = re.sub(r"[^\w]+", "", value, flags=re.UNICODE)
    value = value.replace("_", "")
    return value


def _normalise_epg_id(value):
    value = str(value or "").strip().lower()
    if not value:
        return ""
    # r456: normalize the *whole* XMLTV id, then drop only a trailing
    # country/region token.  r455 used the text before the first dot, so
    # ids such as bein.sports.1.qa collapsed to just "bein" and could not
    # match provider ids such as beinsports1.qa.
    parts = [p for p in re.split(r"[._:/\\-]+", value) if p]
    if len(parts) > 1 and parts[-1] in {
        "qa", "ae", "sa", "kw", "bh", "om", "eg", "jo", "lb", "iq", "ma", "tn", "dz",
        "uk", "gb", "us", "usa", "fr", "de", "it", "es", "pt", "nl", "be", "ch",
        "at", "ie", "ca", "au", "nz", "tr", "gr", "in", "pk", "my", "sg", "za"
    }:
        parts = parts[:-1]
    return re.sub(r"[^a-z0-9]+", "", "".join(parts))


def _xmltv_url(source):
    source = source or {}
    explicit = str(source.get("epg_url") or source.get("xmltv_url") or "").strip()
    if explicit:
        return explicit
    if source.get("type") == "xtream":
        base = str(source.get("url") or "").rstrip("/")
        user = str(source.get("username") or "")
        password = str(source.get("password") or "")
        if base and user and password:
            return "%s/xmltv.php?%s" % (base, urlencode({"username": user, "password": password}))
    return ""


def _quickptime(value):
    return time.struct_time((int(value[0:4]), int(value[4:6]), int(value[6:8]), int(value[8:10]), int(value[10:12]), 0, 1, -1, 0))


def _time_utc(value):
    try:
        parts = str(value).split(" ")
        epoch = calendar.timegm(_quickptime(parts[0]))
        if len(parts) > 1 and parts[1]:
            offset = parts[1]
            sign = -1 if offset.startswith("-") else 1
            digits = offset.lstrip("+-")
            hours = int(digits[:2] or 0)
            minutes = int(digits[2:4] or 0)
            epoch -= sign * ((hours * 3600) + (minutes * 60))
        return int(epoch)
    except Exception:
        return 0


def _download(url, path, timeout=90):
    req = Request(url, headers={"User-Agent": UA, "Accept-Encoding": "gzip"})
    response = urlopen(req, timeout=timeout)
    try:
        with open(path, "wb") as handle:
            while True:
                chunk = response.read(1024 * 256)
                if not chunk:
                    break
                handle.write(chunk)
    finally:
        try:
            response.close()
        except Exception:
            pass


def _open_xml(path):
    handle = open(path, "rb")
    magic = handle.read(2)
    handle.seek(0)
    if magic == b"\x1f\x8b":
        handle.close()
        return gzip.open(path, "rb")
    return handle


def _selected_epg_ids(source):
    """Return enabled Live tvg-ids for this server, or None when unfiltered.

    This runs only in the background EPG refresh worker. It may reuse/fill the
    per-category stream cache, but Live playback never calls it.
    """
    try:
        from .filters import get_allowed_category_ids, get_category_streams
        from .core import get_source_client
        allowed = get_allowed_category_ids(source, "live")
        if allowed is None:
            return None
        if not allowed:
            return set()
        client = get_source_client(dict(source))
        ids = set()
        names = set()
        for category_id in sorted(allowed):
            try:
                rows = get_category_streams(source, "live", client, str(category_id), use_cache=True, wait_for_server=True) or []
            except Exception:
                rows = []
            for item in rows:
                epg_id = str((item or {}).get("epg_channel_id") or (item or {}).get("tvg_id") or "").strip().lower()
                if epg_id:
                    ids.add(epg_id)
                norm_name = _normalise_channel_name((item or {}).get("name") or "")
                if norm_name:
                    names.add(norm_name)
        return {"ids": ids, "names": names}
    except Exception:
        return None




def _focused_fallback_ids(allowed_ids, scope):
    """Keep regional fallbacks focused while UK/US remain general."""
    if scope not in ("arabic", "bein") or not isinstance(allowed_ids, dict):
        return allowed_ids
    ids = set()
    names = set()
    raw_keys = ARABIC_FALLBACK_KEYS if scope == "arabic" else BEIN_FALLBACK_KEYS
    keys = tuple(_normalise_channel_name(x) for x in raw_keys)
    for value in allowed_ids.get("ids") or []:
        norm = _normalise_channel_name(value)
        if norm and any(k and k in norm for k in keys):
            ids.add(value)
    for value in allowed_ids.get("names") or []:
        norm = _normalise_channel_name(value)
        if norm and any(k and k in norm for k in keys):
            names.add(value)
    return {"ids": ids, "names": names}

def _build_json(xml_path, json_path, allowed_ids=None, alias_path=None):
    now = int(calendar.timegm(time.gmtime()))
    limit = now + (24 * 3600)
    epg = {}
    xml_channels = set()
    channel_names = {}
    selected_ids = None
    selected_norm_ids = set()
    selected_names = set()
    if isinstance(allowed_ids, dict):
        selected_ids = set(allowed_ids.get("ids") or [])
        selected_norm_ids = set(_normalise_epg_id(x) for x in selected_ids if _normalise_epg_id(x))
        selected_names = set(allowed_ids.get("names") or [])
    elif allowed_ids is not None:
        selected_ids = set(allowed_ids)
    stream = _open_xml(xml_path)
    try:
        for event, elem in iterparse(stream, events=("end",)):
            tag = elem.tag.split("}")[-1]
            if tag == "channel":
                channel_id = str(elem.get("id") or "").strip().lower()
                if channel_id:
                    names = []
                    for child in list(elem):
                        if child.tag.split("}")[-1] == "display-name" and child.text:
                            text = str(child.text).strip()
                            if text:
                                names.append(text)
                    if names:
                        channel_names[channel_id] = names
                elem.clear()
                continue
            if tag != "programme":
                continue
            channel = str(elem.get("channel") or "").strip().lower()
            if channel:
                xml_channels.add(channel)
            if selected_ids is not None and channel not in selected_ids:
                # r456: keep XMLTV channels whose id differs only by separators
                # or a trailing country code (e.g. bein.sports.1.qa vs
                # beinsports1.qa), before falling back to display-name match.
                id_match = _normalise_epg_id(channel) in selected_norm_ids
                display_names = channel_names.get(channel) or []
                name_match = False
                if not id_match:
                    for display_name in display_names:
                        if _normalise_channel_name(display_name) in selected_names:
                            name_match = True
                            break
                if not id_match and not name_match:
                    elem.clear()
                    continue
            start = _time_utc(elem.get("start") or "")
            stop = _time_utc(elem.get("stop") or "")
            title = ""
            desc = ""
            for child in list(elem):
                ctag = child.tag.split("}")[-1]
                if ctag == "title" and not title:
                    title = child.text or ""
                elif ctag == "desc" and not desc:
                    desc = child.text or ""
            if channel and start < limit and stop > start and stop > now:
                epg.setdefault(channel, []).append([start, stop, title, desc])
            elem.clear()
    finally:
        try:
            stream.close()
        except Exception:
            pass
    for rows in epg.values():
        rows.sort(key=lambda row: row[0])
    ensure_dir(os.path.dirname(json_path))
    tmp = json_path + ".tmp"
    with open_text(tmp, "w", encoding="utf-8") as handle:
        json.dump(epg, handle, ensure_ascii=False, separators=(",", ":"))
    atomic_replace(tmp, json_path)

    # r454: keep a tiny local name->XMLTV-id index beside epg.json.  This is
    # used only when the provider's epg_channel_id does not match its own
    # XMLTV channel id. Direct ID matching always wins.
    if alias_path:
        aliases = {}
        for channel_id, names in channel_names.items():
            if channel_id not in epg:
                continue
            for name in names:
                key = _normalise_channel_name(name)
                if key and key not in aliases:
                    aliases[key] = channel_id
        atmp = alias_path + ".tmp"
        with open_text(atmp, "w", encoding="utf-8") as handle:
            json.dump(aliases, handle, ensure_ascii=False, separators=(",", ":"))
        atomic_replace(atmp, alias_path)

    matched = set(epg.keys())
    return {
        "xml_channels": len(xml_channels),
        "enabled_ids": None if selected_ids is None else len(selected_ids),
        "matched_ids": len(matched),
        "unmatched_enabled_ids": None if selected_ids is None else max(0, len(selected_ids - matched)),
        "aliases": len(channel_names),
    }


def _read_json_file(path):
    try:
        with open_text(path, "r", encoding="utf-8") as handle:
            return json.load(handle) or {}
    except Exception:
        return {}


def _merge_epg_layer(target, alias_target, layer_json, layer_alias):
    """Merge a fallback layer without overriding primary EPG rows/aliases."""
    primary = _read_json_file(target)
    aliases = _read_json_file(alias_target)
    fallback = _read_json_file(layer_json)
    fallback_aliases = _read_json_file(layer_alias)

    added_channels = 0
    for channel_id, rows in fallback.items():
        if channel_id not in primary:
            primary[channel_id] = rows
            added_channels += 1

    added_aliases = 0
    for key, channel_id in fallback_aliases.items():
        if key not in aliases:
            aliases[key] = channel_id
            added_aliases += 1

    ensure_dir(os.path.dirname(target))
    tmp = target + ".tmp"
    with open_text(tmp, "w", encoding="utf-8") as handle:
        json.dump(primary, handle, ensure_ascii=False, separators=(",", ":"))
    atomic_replace(tmp, target)

    atmp = alias_target + ".tmp"
    with open_text(atmp, "w", encoding="utf-8") as handle:
        json.dump(aliases, handle, ensure_ascii=False, separators=(",", ":"))
    atomic_replace(atmp, alias_target)
    return added_channels, added_aliases


def _refresh(source, force=False):
    url = _xmltv_url(source)
    if not url:
        return False
    target = epg_json_path(source)
    alias_target = epg_alias_path(source)
    marker = os.path.join(os.path.dirname(target), ".r542_epg_nameclean")
    external_enabled = _external_epg_enabled(source)
    expected_mode = "external=1" if external_enabled else "external=0"
    try:
        marker_mode = ""
        if os.path.exists(marker):
            with open(marker, "r") as handle:
                marker_mode = (handle.read() or "").strip()
        if (not force and os.path.exists(target) and os.path.exists(alias_target)
                and marker_mode == expected_mode
                and (time.time() - os.path.getmtime(target)) < MAX_AGE):
            return True
    except Exception:
        pass

    folder = os.path.dirname(target)
    ensure_dir(folder)
    allowed_ids = _selected_epg_ids(source)
    log_rows = []
    success = False

    # Source 1 / Primary: the playlist provider's own Xtream XMLTV.
    fd, temp_path = tempfile.mkstemp(prefix="epg_primary_", suffix=".xml", dir=folder)
    os.close(fd)
    try:
        try:
            _download(url, temp_path)
            stats = _build_json(temp_path, target, allowed_ids=allowed_ids, alias_path=alias_target)
            success = True
            log_rows.append("primary matched=%s xml=%s" % (stats.get("matched_ids"), stats.get("xml_channels")))
        except Exception as exc:
            # Primary failure must not block the secondary provider. Start from
            # an empty local layer and let fallback populate what it can.
            with open_text(target + ".tmp", "w", encoding="utf-8") as handle:
                json.dump({}, handle, separators=(",", ":"))
            atomic_replace(target + ".tmp", target)
            with open_text(alias_target + ".tmp", "w", encoding="utf-8") as handle:
                json.dump({}, handle, separators=(",", ":"))
            atomic_replace(alias_target + ".tmp", alias_target)
            log_rows.append("primary error=%s" % exc)
    finally:
        try:
            os.remove(temp_path)
        except Exception:
            pass

    # Source 2 / Fallback: optional per-server EPGShare layers.  When the
    # switch is Off this whole block is skipped, so Live navigation keeps the
    # exact same lookup path and no external network work is started.
    fallback_ok = False
    if external_enabled:
        for index, spec in enumerate(FALLBACK_EPG_SPECS):
            fallback_url, fallback_scope = spec
            fd, fallback_xml = tempfile.mkstemp(prefix="epg_fallback_%s_" % index, suffix=".xml", dir=folder)
            os.close(fd)
            fallback_json = os.path.join(folder, ".epg_fallback_%s.json" % index)
            fallback_alias = os.path.join(folder, ".epg_fallback_%s_aliases.json" % index)
            try:
                try:
                    _download(fallback_url, fallback_xml)
                    layer_allowed = _focused_fallback_ids(allowed_ids, fallback_scope)
                    stats = _build_json(fallback_xml, fallback_json, allowed_ids=layer_allowed, alias_path=fallback_alias)
                    added_channels, added_aliases = _merge_epg_layer(target, alias_target, fallback_json, fallback_alias)
                    fallback_ok = True
                    log_rows.append("fallback%s scope=%s matched=%s added=%s aliases=%s" % (
                        index + 1, fallback_scope, stats.get("matched_ids"), added_channels, added_aliases))
                except Exception as exc:
                    log_rows.append("fallback%s error=%s" % (index + 1, exc))
            finally:
                for path in (fallback_xml, fallback_json, fallback_alias):
                    try:
                        os.remove(path)
                    except Exception:
                        pass
    else:
        log_rows.append("external=off")

    ok = bool(success or fallback_ok)
    if ok:
        try:
            with open(marker, "w") as handle:
                handle.write(expected_mode + "\n")
        except Exception:
            pass
    try:
        with open(get_log_path("tivimatee2_epg_local.log"), "a") as log:
            log.write("%s | r458 | %s | json=%s\n" % (_source_slug(source), " | ".join(log_rows), target))
    except Exception:
        pass
    return ok


def _worker(source, force):
    slug = _source_slug(source)
    try:
        _refresh(source, force=force)
    except Exception as exc:
        try:
            with open(get_log_path("tivimatee2_epg_local.log"), "a") as log:
                log.write("%s: %s\n" % (slug, exc))
        except Exception:
            pass
    finally:
        with _LOCK:
            _RUNNING.discard(slug)


def refresh_source_epg(source, force=False, background=True):
    if not source or source.get("type") != "xtream":
        return False
    slug = _source_slug(source)
    with _LOCK:
        if slug in _RUNNING:
            return True
        _RUNNING.add(slug)
    if background:
        thread = threading.Thread(target=_worker, args=(dict(source), force), name="TiviMateE2LocalEPG")
        try:
            thread.daemon = True
        except Exception:
            pass
        thread.start()
    else:
        _worker(dict(source), force)
    return True


def refresh_all_sources(sources, force=False, background=True):
    count = 0
    for source in sources or []:
        if source.get("type") == "xtream" and refresh_source_epg(source, force=force, background=background):
            count += 1
    return count


_CACHE = {}
_CACHE_MTIME = {}
_ALIAS_CACHE = {}
_ALIAS_MTIME = {}
_MATCH_CACHE = {}


def load_source_epg(source):
    path = epg_json_path(source)
    try:
        mtime = os.path.getmtime(path)
    except Exception:
        return {}
    if path in _CACHE and _CACHE_MTIME.get(path) == mtime:
        return _CACHE[path]
    try:
        with open_text(path, "r", encoding="utf-8") as handle:
            data = json.load(handle) or {}
        _CACHE[path] = data
        _CACHE_MTIME[path] = mtime
        return data
    except Exception:
        return {}



def _load_source_aliases(source):
    path = epg_alias_path(source)
    try:
        mtime = os.path.getmtime(path)
    except Exception:
        return {}
    if path in _ALIAS_CACHE and _ALIAS_MTIME.get(path) == mtime:
        return _ALIAS_CACHE[path]
    try:
        with open_text(path, "r", encoding="utf-8") as handle:
            data = json.load(handle) or {}
        _ALIAS_CACHE[path] = data
        _ALIAS_MTIME[path] = mtime
        return data
    except Exception:
        return {}


def _bein_exact_token(value):
    # A provider channel name may include prefixes/quality labels (AR|, FHD),
    # while an XMLTV id usually does not.  Try both normalizers independently.
    for norm in (_normalise_epg_id(value), _normalise_channel_name(value)):
        if not norm or "bein" not in norm:
            continue
        pos = norm.find("bein")
        norm = norm[pos:]
        match = re.search(r"beinsports(?:max)?(\d+)", norm)
        if match:
            return "beinsports%s" % match.group(1)
        if "beinmovies" in norm:
            tail = norm.split("beinmovies", 1)[1]
            tail = re.sub(r"(?:fhd|uhd|hd|sd|hevc|h265|h264)$", "", tail)
            return "beinmovies%s" % tail
        if "beinentertainment" in norm:
            return "beinentertainment"
    return ""



def _osn_exact_token(value):
    """Return a conservative canonical OSN token across common provider/XMLTV labels.

    r515 widens only OSN name matching. It does not add EPG requests or change
    Live navigation. Known OSN aliases are folded to one token while unrelated
    OSN channels remain isolated from each other.
    """
    raw = str(value or "").strip().lower()
    if not raw:
        return ""

    for norm in (_normalise_epg_id(raw), _normalise_channel_name(raw)):
        if not norm or "osn" not in norm:
            continue
        pos = norm.find("osn")
        token = norm[pos:]
        # Provider/XMLTV labels often append quality/codec/live decorations.
        token = re.sub(r"(?:live|channel|fhd|uhd|4k|hd|sd|hevc|h265|h264)+$", "", token)

        aliases = {
            # Movies Premiere
            "osnpremiere": "osnpremiere",
            "osnmoviepremiere": "osnpremiere",
            "osnmoviespremiere": "osnpremiere",
            "osntvpremiere": "osnpremiere",
            "osnpluspremiere": "osnpremiere",
            # Movies Action
            "osnaction": "osnaction",
            "osnmovieaction": "osnaction",
            "osnmoviesaction": "osnaction",
            "osntvaction": "osnaction",
            "osnplusaction": "osnaction",
            # Movies Family
            "osnfamily": "osnfamily",
            "osnmoviefamily": "osnfamily",
            "osnmoviesfamily": "osnfamily",
            "osntvfamily": "osnfamily",
            "osnplusfamily": "osnfamily",
            # Movies Comedy
            "osncomedy": "osncomedy",
            "osnmoviecomedy": "osncomedy",
            "osnmoviescomedy": "osncomedy",
            "osntvcomedy": "osncomedy",
            "osnpluscomedy": "osncomedy",
            # Movies Horror
            "osnhorror": "osnhorror",
            "osnmoviehorror": "osnhorror",
            "osnmovieshorror": "osnhorror",
            "osntvhorror": "osnhorror",
            "osnplushorror": "osnhorror",
            # Series First
            "osnfirst": "osnfirst",
            "osnseriesfirst": "osnfirst",
            "osntvfirst": "osnfirst",
            "osnplusfirst": "osnfirst",
            # Other common OSN linear labels. Keep each channel distinct.
            "osnshowcase": "osnshowcase",
            "osntvshowcase": "osnshowcase",
            "osnplusshowcase": "osnshowcase",
            "osnyahala": "osnyahala",
            "osnyahalamovie": "osnyahalamovie",
            "osnyahalamovies": "osnyahalamovie",
            "osnwwe": "osnwwe",
            "osnnews": "osnnews",
        }
        return aliases.get(token, token)
    return ""


def _shahid_exact_token(value):
    """Canonical token for Shahid/MBC linear channels, including Arabic labels."""
    raw = str(value or "").strip().lower()
    if not raw:
        return ""
    translated = raw
    for old, new in (
        ("طاش", " tash "),
        ("فيروز", " fairuz "),
        ("شاهد", " shahid "),
        ("ام بي سي", " mbc "),
        ("إم بي سي", " mbc "),
        ("امبيسي", " mbc "),
    ):
        translated = translated.replace(old, new)
    norm = _normalise_channel_name(translated) or _normalise_epg_id(translated)
    if not norm:
        return ""
    # r519: do not guess provider prefixes. If a playlist adds any text
    # before the real MBC/Shahid linear channel name, discard everything
    # before the first recognised channel anchor. Bare "MBC" is not
    # treated as MBC1: only MBC1/MBC 1 -> mbc1 and MBC2/MBC 2 -> mbc2.
    anchors = ("mbc", "tash", "fairuz", "fairouz", "fayrouz")
    positions = [(norm.find(anchor), anchor) for anchor in anchors if norm.find(anchor) >= 0]
    if positions:
        pos, _anchor = min(positions, key=lambda item: item[0])
        norm = norm[pos:]
    norm = re.sub(r"(?:live|channel)$", "", norm)
    known = {
        "mbcthriller": "mbcthriller", "thriller": "mbcthriller",
        "tash": "tash", "fairuz": "fairuz", "fairouz": "fairuz", "fayrouz": "fairuz",
        "mbc1": "mbc1", "mbc2": "mbc2", "mbc3": "mbc3", "mbc4": "mbc4", "mbc5": "mbc5",
        "mbcmasr": "mbcmasr1", "mbcmasr1": "mbcmasr1", "mbcmasr2": "mbcmasr2",
        "mbcaction": "mbcaction", "mbcmax": "mbcmax", "mbcbollywood": "mbcbollywood",
        "mbcdrama": "mbcdrama",
    }
    return known.get(norm, "")


def _sky_cinema_exact_info(value):
    """Return (region, token) for Sky Cinema. Region is inferred before prefixes are stripped."""
    raw = str(value or "").strip().lower()
    norm = _normalise_epg_id(raw) or _normalise_channel_name(raw)
    if not norm or "skycinema" not in norm:
        return ("", "")
    region = ""
    # Preserve explicit regional evidence from provider names / XMLTV ids.
    if re.search(r"(^|[^a-z0-9])(de|ger|germany|deutschland)([^a-z0-9]|$)", raw) or raw.endswith(".de"):
        region = "de"
    elif re.search(r"(^|[^a-z0-9])(uk|gb|britain|united kingdom)([^a-z0-9]|$)", raw) or raw.endswith((".uk", ".gb")):
        region = "uk"
    pos = norm.find("skycinema")
    token = norm[pos:]
    token = re.sub(r"(?:fhd|uhd|hd|sd|hevc|h265|h264)$", "", token)
    return (region, token)

def _smart_epg_id(source, item, epg_map):
    """Resolve a broken Xtream tvg-id conservatively against local XMLTV.

    Order: protected exact channel families -> exact provider id -> exact XMLTV
    display-name alias -> conservative normalized/fuzzy fallback.  A fallback is
    returned only at a high score to avoid assigning the wrong programme guide
    to a similarly named channel.
    """
    direct = str((item or {}).get("epg_channel_id") or (item or {}).get("tvg_id") or "").strip().lower()
    name = str((item or {}).get("name") or "").strip()

    # r523: MBC channel names are authoritative. Some providers expose a valid
    # but wrong tvg-id for MBC rows; accepting that id before matching the name
    # can attach an unrelated Arabic guide. Protect every recognised MBC channel
    # by resolving only the exact canonical MBC token from the visible name.
    mbc_name_token = _shahid_exact_token(name)
    if mbc_name_token.startswith("mbc"):
        norm_name = _normalise_channel_name(name)
        cache_key = (_source_slug(source), direct, norm_name)
        cached = _MATCH_CACHE.get(cache_key)
        if cached is not None:
            return cached
        for candidate in epg_map.keys():
            if _shahid_exact_token(candidate) == mbc_name_token:
                _MATCH_CACHE[cache_key] = candidate
                return candidate
        aliases = _load_source_aliases(source)
        for alias_name, candidate in aliases.items():
            if candidate in epg_map and _shahid_exact_token(alias_name) == mbc_name_token:
                _MATCH_CACHE[cache_key] = candidate
                return candidate
        _MATCH_CACHE[cache_key] = ""
        return ""

    if direct and direct in epg_map:
        return direct
    norm_name = _normalise_channel_name(name)
    if not norm_name:
        return ""
    cache_key = (_source_slug(source), direct, norm_name)
    cached = _MATCH_CACHE.get(cache_key)
    if cached is not None:
        return cached

    # r525: SKY STORE rows are matched only by their cleaned exact token.
    # This strips arbitrary provider prefixes such as "UK:" and suffixes such
    # as "RAW" while keeping PREMIERE 1/2/3... strictly separate.
    sky_store_token = _sky_store_exact_token(direct) or _sky_store_exact_token(name)
    if sky_store_token:
        for candidate in epg_map.keys():
            if _sky_store_exact_token(candidate) == sky_store_token:
                _MATCH_CACHE[cache_key] = candidate
                return candidate
        aliases = _load_source_aliases(source)
        for alias_name, candidate in aliases.items():
            if candidate in epg_map and _sky_store_exact_token(alias_name) == sky_store_token:
                _MATCH_CACHE[cache_key] = candidate
                return candidate
        _MATCH_CACHE[cache_key] = ""
        return ""

    # r459: never fuzzy-match numbered beIN channels.  A wrong guide is worse
    # than no guide, so only accept an XMLTV id/name with the same exact token.
    bein_token = _bein_exact_token(direct) or _bein_exact_token(name)
    if bein_token:
        for candidate in epg_map.keys():
            if _bein_exact_token(candidate) == bein_token:
                _MATCH_CACHE[cache_key] = candidate
                return candidate
        aliases = _load_source_aliases(source)
        for alias_name, candidate in aliases.items():
            if candidate in epg_map and _bein_exact_token(alias_name) == bein_token:
                _MATCH_CACHE[cache_key] = candidate
                return candidate
        _MATCH_CACHE[cache_key] = ""
        return ""

    # r463: OSN is also protected from fuzzy cross-channel matches.
    osn_token = _osn_exact_token(direct) or _osn_exact_token(name)
    if osn_token:
        for candidate in epg_map.keys():
            if _osn_exact_token(candidate) == osn_token:
                _MATCH_CACHE[cache_key] = candidate
                return candidate
        aliases = _load_source_aliases(source)
        for alias_name, candidate in aliases.items():
            if candidate in epg_map and _osn_exact_token(alias_name) == osn_token:
                _MATCH_CACHE[cache_key] = candidate
                return candidate
        _MATCH_CACHE[cache_key] = ""
        return ""

    # r504: Shahid/MBC linear channels use exact aliases before generic fuzzy matching.
    shahid_token = _shahid_exact_token(direct) or _shahid_exact_token(name)
    if shahid_token:
        for candidate in epg_map.keys():
            if _shahid_exact_token(candidate) == shahid_token:
                _MATCH_CACHE[cache_key] = candidate
                return candidate
        aliases = _load_source_aliases(source)
        for alias_name, candidate in aliases.items():
            if candidate in epg_map and _shahid_exact_token(alias_name) == shahid_token:
                _MATCH_CACHE[cache_key] = candidate
                return candidate
        _MATCH_CACHE[cache_key] = ""
        return ""

    # r463: Sky Cinema Germany and UK must never cross-match.
    sky_region, sky_token = _sky_cinema_exact_info(direct or name)
    if sky_token:
        aliases = _load_source_aliases(source)
        candidates = []
        for candidate in epg_map.keys():
            cand_region, cand_token = _sky_cinema_exact_info(candidate)
            if cand_token == sky_token and (not sky_region or not cand_region or cand_region == sky_region):
                candidates.append((candidate, cand_region))
        if sky_region:
            region_hits = [c for c, r in candidates if r == sky_region]
            if len(region_hits) == 1:
                _MATCH_CACHE[cache_key] = region_hits[0]
                return region_hits[0]
        elif len(candidates) == 1:
            _MATCH_CACHE[cache_key] = candidates[0][0]
            return candidates[0][0]
        for alias_name, candidate in aliases.items():
            if candidate not in epg_map:
                continue
            a_region, a_token = _sky_cinema_exact_info(alias_name)
            if a_token != sky_token:
                continue
            if sky_region and a_region and a_region != sky_region:
                continue
            _MATCH_CACHE[cache_key] = candidate
            return candidate
        _MATCH_CACHE[cache_key] = ""
        return ""

    aliases = _load_source_aliases(source)
    exact = aliases.get(norm_name)
    if exact and exact in epg_map:
        _MATCH_CACHE[cache_key] = exact
        return exact

    # r456: provider tvg-id is useful even when its punctuation/country suffix
    # differs from the XMLTV id.  Try it before fuzzy name matching.
    direct_norm = _normalise_epg_id(direct)
    if direct_norm:
        exact = aliases.get(direct_norm)
        if exact and exact in epg_map:
            _MATCH_CACHE[cache_key] = exact
            return exact
        for candidate in epg_map.keys():
            if _normalise_epg_id(candidate) == direct_norm:
                _MATCH_CACHE[cache_key] = candidate
                return candidate

    # Exact normalized comparison against XMLTV IDs handles simple cases
    # such as TF1 / tf1.fr without requiring an alias file.
    for candidate in epg_map.keys():
        if _normalise_epg_id(candidate) == norm_name:
            _MATCH_CACHE[cache_key] = candidate
            return candidate

    best_id = ""
    best_score = 0.0
    # Prefer XMLTV display names because they are less ambiguous than IDs.
    for alias_name, candidate in aliases.items():
        if candidate not in epg_map:
            continue
        score = difflib.SequenceMatcher(None, norm_name, alias_name).ratio()
        if score > best_score:
            best_score, best_id = score, candidate
    # Only if display names did not give a strong hit, compare channel IDs.
    if best_score < 0.90:
        for candidate in epg_map.keys():
            cid = _normalise_epg_id(candidate)
            if not cid:
                continue
            score = difflib.SequenceMatcher(None, norm_name, cid).ratio()
            if score > best_score:
                best_score, best_id = score, candidate
    # Keep this deliberately strict: wrong EPG is worse than no EPG.
    result = best_id if best_score >= 0.88 else ""
    _MATCH_CACHE[cache_key] = result
    return result




def source_epg_offset_seconds(source):
    """r458: automatic XMLTV timing only; trust each programme timezone."""
    return 0

def ensure_source_epg(source):
    """Ensure Xtream local EPG JSON exists/fresh without EPGImport.

    The existing local XMLTV worker downloads the playlist XMLTV directly to
    the HDD/USB EPG cache, converts it to epg.json, then removes the temporary
    XML file.  This function only starts that existing background worker when
    the JSON cache is missing or older than MAX_AGE.
    """
    if not source or source.get("type") != "xtream":
        return False
    path = epg_json_path(source)
    try:
        alias = epg_alias_path(source)
        fresh = os.path.exists(path) and os.path.exists(alias) and (time.time() - os.path.getmtime(path)) < MAX_AGE
    except Exception:
        fresh = False
    if fresh:
        return True
    try:
        return refresh_source_epg(source, force=False, background=True)
    except Exception:
        return False


def _sky_store_exact_token(value):
    """Return a strict canonical SKY STORE token from provider-decorated names.

    Examples:
      UK: SKY STORE PREMIERE 1 RAW -> skystorepremiere1
      SKY STORE PREMIERE 2 HD      -> skystorepremiere2

    Prefix text before SKY STORE and trailing RAW/quality decorations are
    ignored.  Numbered PREMIERE rows remain distinct, so PREMIERE 1 can never
    cross-match PREMIERE 2 or SKY CINEMA PREMIERE.
    """
    raw = str(value or "").strip().lower()
    if not raw:
        return ""
    pos = raw.find("sky store")
    if pos < 0:
        compact = re.sub(r"[^a-z0-9]+", "", raw)
        pos2 = compact.find("skystore")
        if pos2 < 0:
            return ""
        raw = compact[pos2:]
    else:
        raw = raw[pos:]
    raw = re.sub(r"\b(?:raw|4k|uhd|fhd|hd|sd|hevc|h265|h264|50fps|60fps)\b", " ", raw)
    norm = re.sub(r"[^a-z0-9]+", "", raw)
    m = re.match(r"^skystorepremiere(\d+)$", norm)
    if m:
        return "skystorepremiere%s" % m.group(1)
    if norm == "skystoreinfo":
        return "skystoreinfo"
    return ""


def lookup_channel_epg(source, item, now=None):
    epg_id = str((item or {}).get("epg_channel_id") or (item or {}).get("tvg_id") or "").strip().lower()
    if not epg_id and not str((item or {}).get("name") or "").strip():
        return None, None
    # r459: Live navigation is read-only against the prepared HDD cache.
    # Cache refresh is started once when an Xtream bouquet is opened, not once
    # per highlighted channel.
    epg_map = load_source_epg(source)
    direct_match = bool(epg_id and epg_id in epg_map)
    resolved_id = epg_id if direct_match else _smart_epg_id(source, item, epg_map)
    rows = epg_map.get(resolved_id) or []
    if not direct_match:
        try:
            with open(get_log_path("tivimatee2_epg_local.log"), "a") as log:
                log.write(
                    "%s | lookup | channel=%s | direct_id=%s | alias_match=%s | resolved_id=%s | rows=%s\n" % (
                        _source_slug(source),
                        str((item or {}).get("name") or ""),
                        epg_id,
                        bool(resolved_id and resolved_id in epg_map),
                        resolved_id,
                        len(rows),
                    )
                )
        except Exception:
            pass
    if not rows:
        return None, None
    now = int(now or time.time())
    shift = source_epg_offset_seconds(source)
    current = None
    upcoming = None
    for row in rows:
        try:
            start, stop, title, desc = int(row[0]), int(row[1]), row[2] or "", row[3] or ""
        except Exception:
            continue
        start += shift
        stop += shift
        event = (start, max(0, stop - start), title, desc)
        if start <= now < stop:
            current = event
        elif start > now and upcoming is None:
            upcoming = event
        if current is not None and upcoming is not None:
            break
    return current, upcoming

