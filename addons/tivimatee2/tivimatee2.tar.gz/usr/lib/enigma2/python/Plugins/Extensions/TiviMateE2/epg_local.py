# -*- coding: utf-8 -*-

from .storage import get_data_root, data_path
import calendar
import gzip
import json
import os
import re
import tempfile
import threading
import time
from urllib.parse import urlencode
from urllib.request import Request, urlopen
try:
    from xml.etree.cElementTree import iterparse
except Exception:
    from xml.etree.ElementTree import iterparse

from .cache_manager import get_log_path
from .compat import ensure_dir, open_text, atomic_replace

def _epg_storage_base():
    """Keep large EPG data off receiver flash.

    Preferred order:
      1. HDD/USB persistent storage when mounted and writable.
      2. /tmp as an ephemeral fallback when no external storage exists.

    Never store generated EPG data under /etc/enigma2 or the plugin directory.
    """
    candidates = (
        "/media/hdd",
        "/hdd",
        "/media/usb",
        "/media/usb0",
        "/media/usb1",
        "/media/sda1",
        "/media/sdb1",
    )

    for mount in candidates:
        try:
            if not os.path.isdir(mount):
                continue
            # Reject empty mount directories that are merely on root flash.
            mounted = os.path.ismount(mount)
            if not mounted:
                try:
                    mounted = os.path.ismount(os.path.realpath(mount))
                except Exception:
                    mounted = False
            if not mounted:
                continue
            if not os.access(mount, os.W_OK):
                continue

            base = data_path("epg")
            try:
                if not os.path.isdir(base):
                    os.makedirs(base)
                return base
            except Exception:
                continue
        except Exception:
            continue

    base = data_path("epg")
    try:
        if not os.path.isdir(base):
            os.makedirs(base)
    except Exception:
        pass
    return base


BASE_DIR = _epg_storage_base()
UA = "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/1.0"
MAX_AGE = 4 * 3600
_LOCK = threading.Lock()
_RUNNING = set()


def _safe_name(value, fallback="IPTV"):
    value = (value or fallback).strip() or fallback
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_")
    return value or fallback


def _source_slug(source):
    return _safe_name((source or {}).get("name") or "IPTV")


def epg_json_path(source):
    return os.path.join(BASE_DIR, _source_slug(source), "epg.json")


def _xmltv_url(source):
    source = source or {}
    explicit = str(source.get("epg_url") or source.get("xmltv_url") or "").strip()
    if explicit:
        return explicit
    if source.get("type") == "xtream":
        base = str(source.get("url") or "").rstrip("/")
        user = str(source.get("username") or "")
        password = str(source.get("password") or "")
        if base and user and password:
            return "%s/xmltv.php?%s" % (base, urlencode({"username": user, "password": password}))
    return ""


def _quickptime(value):
    return time.struct_time((int(value[0:4]), int(value[4:6]), int(value[6:8]), int(value[8:10]), int(value[10:12]), 0, 1, -1, 0))


def _time_utc(value):
    try:
        parts = str(value).split(" ")
        epoch = calendar.timegm(_quickptime(parts[0]))
        if len(parts) > 1 and parts[1]:
            offset = parts[1]
            sign = -1 if offset.startswith("-") else 1
            digits = offset.lstrip("+-")
            hours = int(digits[:2] or 0)
            minutes = int(digits[2:4] or 0)
            epoch -= sign * ((hours * 3600) + (minutes * 60))
        return int(epoch)
    except Exception:
        return 0


def _download(url, path, timeout=90):
    req = Request(url, headers={"User-Agent": UA, "Accept-Encoding": "gzip"})
    response = urlopen(req, timeout=timeout)
    try:
        with open(path, "wb") as handle:
            while True:
                chunk = response.read(1024 * 256)
                if not chunk:
                    break
                handle.write(chunk)
    finally:
        try:
            response.close()
        except Exception:
            pass


def _open_xml(path):
    handle = open(path, "rb")
    magic = handle.read(2)
    handle.seek(0)
    if magic == b"\x1f\x8b":
        handle.close()
        return gzip.open(path, "rb")
    return handle


def _selected_epg_ids(source):
    """Return enabled Live tvg-ids for this server, or None when unfiltered.

    This runs only in the background EPG refresh worker. It may reuse/fill the
    per-category stream cache, but Live playback never calls it.
    """
    try:
        from .filters import get_allowed_category_ids, get_category_streams
        from .core import get_source_client
        allowed = get_allowed_category_ids(source, "live")
        if allowed is None:
            return None
        if not allowed:
            return set()
        client = get_source_client(dict(source))
        ids = set()
        for category_id in sorted(allowed):
            try:
                rows = get_category_streams(source, "live", client, str(category_id), use_cache=True, wait_for_server=True) or []
            except Exception:
                rows = []
            for item in rows:
                epg_id = str((item or {}).get("epg_channel_id") or (item or {}).get("tvg_id") or "").strip().lower()
                if epg_id:
                    ids.add(epg_id)
        return ids
    except Exception:
        return None


def _build_json(xml_path, json_path, allowed_ids=None):
    now = int(calendar.timegm(time.gmtime()))
    limit = now + (24 * 3600)
    epg = {}
    stream = _open_xml(xml_path)
    try:
        for event, elem in iterparse(stream, events=("end",)):
            tag = elem.tag.split("}")[-1]
            if tag != "programme":
                if tag == "channel":
                    elem.clear()
                continue
            channel = str(elem.get("channel") or "").strip().lower()
            if allowed_ids is not None and channel not in allowed_ids:
                elem.clear()
                continue
            start = _time_utc(elem.get("start") or "")
            stop = _time_utc(elem.get("stop") or "")
            title = ""
            desc = ""
            for child in list(elem):
                ctag = child.tag.split("}")[-1]
                if ctag == "title" and not title:
                    title = child.text or ""
                elif ctag == "desc" and not desc:
                    desc = child.text or ""
            if channel and start < limit and stop > start and stop > now:
                epg.setdefault(channel, []).append([start, stop, title, desc])
            elem.clear()
    finally:
        try:
            stream.close()
        except Exception:
            pass
    for rows in epg.values():
        rows.sort(key=lambda row: row[0])
    ensure_dir(os.path.dirname(json_path))
    tmp = json_path + ".tmp"
    with open_text(tmp, "w", encoding="utf-8") as handle:
        json.dump(epg, handle, ensure_ascii=False, separators=(",", ":"))
    atomic_replace(tmp, json_path)
    return len(epg)


def _refresh(source, force=False):
    url = _xmltv_url(source)
    if not url:
        return False
    target = epg_json_path(source)
    try:
        if not force and os.path.exists(target) and (time.time() - os.path.getmtime(target)) < MAX_AGE:
            return True
    except Exception:
        pass
    folder = os.path.dirname(target)
    ensure_dir(folder)
    fd, temp_path = tempfile.mkstemp(prefix="epg_", suffix=".xml", dir=folder)
    os.close(fd)
    try:
        _download(url, temp_path)
        allowed_ids = _selected_epg_ids(source)
        _build_json(temp_path, target, allowed_ids=allowed_ids)
        return True
    finally:
        try:
            os.remove(temp_path)
        except Exception:
            pass


def _worker(source, force):
    slug = _source_slug(source)
    try:
        _refresh(source, force=force)
    except Exception as exc:
        try:
            with open(get_log_path("tivimatee2_epg_local.log"), "a") as log:
                log.write("%s: %s\n" % (slug, exc))
        except Exception:
            pass
    finally:
        with _LOCK:
            _RUNNING.discard(slug)


def refresh_source_epg(source, force=False, background=True):
    if not source or source.get("type") != "xtream":
        return False
    slug = _source_slug(source)
    with _LOCK:
        if slug in _RUNNING:
            return True
        _RUNNING.add(slug)
    if background:
        thread = threading.Thread(target=_worker, args=(dict(source), force), name="TiviMateE2LocalEPG")
        try:
            thread.daemon = True
        except Exception:
            pass
        thread.start()
    else:
        _worker(dict(source), force)
    return True


def refresh_all_sources(sources, force=False, background=True):
    count = 0
    for source in sources or []:
        if source.get("type") == "xtream" and refresh_source_epg(source, force=force, background=background):
            count += 1
    return count


_CACHE = {}
_CACHE_MTIME = {}


def load_source_epg(source):
    path = epg_json_path(source)
    try:
        mtime = os.path.getmtime(path)
    except Exception:
        return {}
    if path in _CACHE and _CACHE_MTIME.get(path) == mtime:
        return _CACHE[path]
    try:
        with open_text(path, "r", encoding="utf-8") as handle:
            data = json.load(handle) or {}
        _CACHE[path] = data
        _CACHE_MTIME[path] = mtime
        return data
    except Exception:
        return {}



def source_epg_offset_seconds(source):
    """Return the per-playlist EPG correction in seconds.

    auto trusts the timezone embedded in XMLTV. Existing playlists created
    before Test33 default to -1 hour in the editor to preserve Test32 timing.
    """
    value = str((source or {}).get("epg_offset", "auto") or "auto").strip().lower()
    if value == "auto":
        return 0
    try:
        return int(float(value) * 3600)
    except Exception:
        return 0

def lookup_channel_epg(source, item, now=None):
    epg_id = str((item or {}).get("epg_channel_id") or (item or {}).get("tvg_id") or "").strip().lower()
    if not epg_id:
        return None, None
    rows = load_source_epg(source).get(epg_id) or []
    if not rows:
        return None, None
    now = int(now or time.time())
    shift = source_epg_offset_seconds(source)
    current = None
    upcoming = None
    for row in rows:
        try:
            start, stop, title, desc = int(row[0]), int(row[1]), row[2] or "", row[3] or ""
        except Exception:
            continue
        start += shift
        stop += shift
        event = (start, max(0, stop - start), title, desc)
        if start <= now < stop:
            current = event
        elif start > now and upcoming is None:
            upcoming = event
        if current is not None and upcoming is not None:
            break
    return current, upcoming
