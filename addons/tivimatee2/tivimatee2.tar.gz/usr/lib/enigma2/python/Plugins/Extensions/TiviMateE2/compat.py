# -*- coding: utf-8 -*-
"""Small local Python 2/3 compatibility helpers for TiviMate E2 only."""
from __future__ import absolute_import

import io
import os


def open_text(path, mode="r", encoding="utf-8", errors="strict"):
    """Open a text file uniformly on Python 2 and Python 3."""
    if "b" in mode:
        return io.open(path, mode)
    return io.open(path, mode, encoding=encoding or "utf-8", errors=errors or "strict")


def ensure_dir(path, mode=511):
    """Create a directory if absent; equivalent to exist_ok=True."""
    if not path:
        return
    if os.path.isdir(path):
        return
    try:
        os.makedirs(path, mode)
    except OSError:
        if not os.path.isdir(path):
            raise


def atomic_replace(source, destination):
    """Use os.replace where available and rename safely on legacy Python."""
    replace = getattr(os, "replace", None)
    if replace is not None:
        return replace(source, destination)
    if os.path.exists(destination):
        try:
            os.unlink(destination)
        except OSError:
            pass
    return os.rename(source, destination)


def python_command():
    """Return a usable interpreter path and argv[0] on common Enigma2 images."""
    for path, command in (
        ("/usr/bin/python3", "python3"),
        ("/usr/bin/python", "python"),
        ("/usr/bin/python2", "python2"),
    ):
        if os.path.exists(path):
            return path, command
    return "python", "python"
