# -*- coding: utf-8 -*-
"""Small receiver resource guardrails.

The goal is deliberately narrow: protect long downloads from exhausting the HDD
and serialize rare heavyweight artwork conversions. Normal JPEG/PNG downloads,
TMDb requests, UI rendering and playback are untouched.
"""
from __future__ import absolute_import

import os
import shutil
import threading
import time
from contextlib import contextmanager

DEFAULT_DOWNLOAD_RESERVE_MB = 512
MIN_DOWNLOAD_RESERVE_MB = 256
MAX_DOWNLOAD_RESERVE_MB = 8192
DOWNLOAD_RECHECK_BYTES = 4 * 1024 * 1024


# Lightweight endurance guard for Stalker network activity.  Search, EPG,
# catalog prefetch and playback-link resolution all share this process-wide
# ceiling, so a slow portal cannot create an ever-growing wave of concurrent
# socket/requests work.  Existing per-feature queues remain unchanged.
MAX_CONCURRENT_STALKER_REQUESTS = 6
_STALKER_REQUEST_SLOTS = threading.BoundedSemaphore(MAX_CONCURRENT_STALKER_REQUESTS)


@contextmanager
def stalker_request_slot(wait_seconds=4.0):
    acquired = False
    started = time.time()
    try:
        try:
            acquired = _STALKER_REQUEST_SLOTS.acquire(timeout=max(0.1, float(wait_seconds or 0.1)))
        except TypeError:
            # Compatibility fallback for older Python threading implementations.
            deadline = time.time() + max(0.1, float(wait_seconds or 0.1))
            while time.time() < deadline:
                if _STALKER_REQUEST_SLOTS.acquire(False):
                    acquired = True
                    break
                time.sleep(0.05)
        if not acquired:
            try:
                from .diagnostics import event
                event("endurance", "stalker_slot_timeout", wait_ms=int((time.time() - started) * 1000), limit=MAX_CONCURRENT_STALKER_REQUESTS)
            except Exception:
                pass
            raise RuntimeError("Stalker request queue is busy")
        waited = time.time() - started
        if waited >= 0.75:
            try:
                from .diagnostics import event
                event("endurance", "stalker_slot_wait", wait_ms=int(waited * 1000), limit=MAX_CONCURRENT_STALKER_REQUESTS)
            except Exception:
                pass
        yield
    finally:
        if acquired:
            try:
                _STALKER_REQUEST_SLOTS.release()
            except Exception:
                pass


def free_bytes(path):
    target = os.path.abspath(path or ".")
    while not os.path.exists(target):
        parent = os.path.dirname(target)
        if parent == target:
            break
        target = parent
    try:
        return int(shutil.disk_usage(target).free)
    except Exception:
        stat = os.statvfs(target)
        return int(stat.f_bavail) * int(stat.f_frsize)


def download_reserve_bytes(value_mb=None):
    try:
        value = int(value_mb if value_mb is not None else DEFAULT_DOWNLOAD_RESERVE_MB)
    except Exception:
        value = DEFAULT_DOWNLOAD_RESERVE_MB
    value = max(MIN_DOWNLOAD_RESERVE_MB, min(MAX_DOWNLOAD_RESERVE_MB, value))
    return value * 1024 * 1024


def ensure_download_capacity(path, incoming_bytes=0, reserve_bytes=None):
    reserve = download_reserve_bytes() if reserve_bytes is None else max(0, int(reserve_bytes or 0))
    incoming = max(0, int(incoming_bytes or 0))
    free = free_bytes(path)
    required = reserve + incoming
    if free < required:
        raise RuntimeError(
            "Insufficient HDD space: %.1f MB free; %.1f MB required including safety reserve"
            % (free / 1048576.0, required / 1048576.0)
        )
    return free


@contextmanager
def artwork_conversion_lock(lock_path):
    """Cross-process lock for ffmpeg image conversion.

    Artwork network transfers stay concurrent. Only WebP/AVIF/other conversion is
    serialized so several ffmpeg processes cannot spike RAM/CPU together.
    """
    handle = None
    locked = False
    try:
        try:
            import fcntl
            directory = os.path.dirname(lock_path)
            if directory and not os.path.isdir(directory):
                os.makedirs(directory)
            handle = open(lock_path, "a+")
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            locked = True
        except Exception:
            pass
        yield
    finally:
        if handle is not None:
            try:
                if locked:
                    import fcntl
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            except Exception:
                pass
            try:
                handle.close()
            except Exception:
                pass
