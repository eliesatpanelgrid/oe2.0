from .storage import get_data_root, data_path
from .compat import atomic_replace, ensure_dir, open_text
import os, json, re, ssl, traceback, subprocess, time, hashlib, unicodedata, difflib
from urllib.request import Request, urlopen
from urllib.parse import urlencode

CONFIG_DIR = get_data_root()
CONFIG_FILE = data_path("tmdb.json")
API_BASE = "https://api.themoviedb.org/3"
IMAGE_BASE = "https://image.tmdb.org/t/p/"
# Shared defaults stay available to every user, but are not stored as plain text.
# User-provided TMDb credentials always override these values.
_TMDB_MASK = 0x5A

def _decode_builtin(values):
    try:
        return "".join(chr(int(value) ^ _TMDB_MASK) for value in values.split(",") if value)
    except Exception:
        return ""

DEFAULT_API_KEY = _decode_builtin("105,57,105,63,60,57,60,110,109,57,105,111,109,109,111,111,98,98,107,104,56,56,99,62,108,110,106,107,99,62,108,111")
DEFAULT_API_KEY2 = _decode_builtin("106,105,63,109,107,109,98,59,63,59,98,60,56,105,109,98,98,98,99,108,56,99,63,107,98,59,99,110,99,105,63,60")
DEFAULT_ACCESS_TOKEN = _decode_builtin("63,35,16,50,56,29,57,51,21,51,16,19,15,32,19,107,20,51,16,99,116,63,35,16,50,62,13,11,51,21,51,19,45,23,104,15,105,23,14,57,110,3,13,12,50,21,29,0,51,23,32,57,110,21,30,61,111,20,55,19,111,0,14,31,110,3,14,49,106,21,14,20,54,0,51,19,41,19,55,111,51,0,51,19,108,23,14,3,32,20,32,19,104,21,30,3,45,20,25,110,107,23,30,31,41,19,52,20,107,3,51,19,108,19,48,3,34,21,14,0,51,3,32,62,48,3,32,24,50,0,14,23,104,23,30,27,106,20,29,3,35,23,29,8,51,20,35,19,41,19,52,20,48,56,105,24,54,57,35,19,108,13,35,16,50,57,29,54,60,57,55,12,50,0,25,16,62,22,25,16,104,0,2,16,32,59,13,99,47,19,48,53,34,60,11,116,49,60,42,61,104,99,46,19,2,40,13,99,60,42,2,51,45,51,29,16,41,43,5,105,61,108,21,56,27,2,48,45,24,13,35,29,15,21,60,18,32,56,3")



def _tmdb_normalize_unicode_digits(value):
    """Normalize Arabic-Indic and other Unicode decimal digits for TMDb queries."""
    out = []
    for ch in str(value or ""):
        try:
            if ch.isdigit():
                out.append(str(unicodedata.digit(ch)))
            else:
                out.append(ch)
        except Exception:
            out.append(ch)
    return "".join(out)

def _tmdb_extract_year(title, explicit_year=None):
    """Return a safe 4-digit release year from provider metadata or title."""
    value = _tmdb_normalize_unicode_digits(explicit_year)
    m = re.search(r"\b((?:19|20)\d{2})\b", value)
    if m:
        return m.group(1)
    m = re.search(r"(?:^|[^0-9])((?:19|20)\d{2})(?:[^0-9]|$)", _tmdb_normalize_unicode_digits(title))
    return m.group(1) if m else None


def _tmdb_script_group(ch):
    """Broad script group for multilingual IPTV titles.

    Digits/punctuation are neutral and get attached to their neighboring title.
    This is intentionally provider-agnostic: it is only used to create alternate
    TMDb queries and never changes the visible title in the UI.
    """
    try:
        code = ord(ch)
    except Exception:
        return "neutral"
    if ch.isdigit() or ch.isspace() or ch in "-–—:|/\\+.,'’\"()[]{}&!؟":
        return "neutral"
    if (0x0041 <= code <= 0x024F) or (0x1E00 <= code <= 0x1EFF):
        return "latin"
    if (0x0600 <= code <= 0x06FF) or (0x0750 <= code <= 0x077F) or (0x08A0 <= code <= 0x08FF):
        return "arabic"
    if (0x0400 <= code <= 0x052F):
        return "cyrillic"
    if (0x0370 <= code <= 0x03FF):
        return "greek"
    if (0x0900 <= code <= 0x097F):
        return "devanagari"
    if (0x3040 <= code <= 0x30FF):
        return "japanese"
    if (0xAC00 <= code <= 0xD7AF):
        return "korean"
    if (0x3400 <= code <= 0x9FFF):
        return "cjk"
    if (0x0E00 <= code <= 0x0E7F):
        return "thai"
    if (0x0590 <= code <= 0x05FF):
        return "hebrew"
    return "other"


def _tmdb_multiscript_candidates(value):
    """Split a cleaned mixed-language title into usable per-script alternatives."""
    value = re.sub(r"\s+", " ", str(value or "")).strip(" -|:_")
    if not value:
        return []

    runs = []
    current = []
    current_script = None

    def emit(chars):
        part = re.sub(r"\s+", " ", "".join(chars)).strip(" -|:_")
        if part and any(ch.isalpha() for ch in part):
            runs.append(part)

    for ch in value:
        script = _tmdb_script_group(ch)
        if script == "neutral":
            current.append(ch)
            continue

        if current_script is None:
            current_script = script
            current.append(ch)
            continue

        if script == current_script or script == "other" or current_script == "other":
            current.append(ch)
            if current_script == "other" and script != "other":
                current_script = script
            continue

        # Script changed. Remove separator whitespace/punctuation from the prior
        # run before emitting it. Neutral digits are kept with the side they
        # naturally belong to, but are never allowed to truncate words.
        trailing = []
        while current and _tmdb_script_group(current[-1]) == "neutral":
            trailing.insert(0, current.pop())
        emit(current)

        # Carry only leading digits from the neutral bridge to the new title,
        # e.g. "6 أيام". Normal separators stay discarded.
        carry = "".join(trailing).strip()
        current = ([carry + " "] if carry and any(c.isdigit() for c in carry) else [])
        current.append(ch)
        current_script = script

    emit(current)

    out = []
    for part in runs:
        part = re.sub(r"^[\W_]+|[\W_]+$", "", part, flags=re.UNICODE).strip()
        if len(part) >= 2 and part not in out:
            out.append(part)
    return out


def _tmdb_title_candidates(title):
    """Generate aggressive-but-safe TMDb title candidates for IPTV catalogs.

    The provider title shown in the UI is never changed.  Only TMDb search
    queries use these variants.  Instead of one destructive cleanup pass, this
    function returns several ordered candidates from strict to relaxed.
    """
    raw = _tmdb_normalize_unicode_digits(title).strip()
    if not raw:
        return []

    # Normalise Unicode presentation forms without transliterating real words.
    try:
        raw_nfkc = unicodedata.normalize("NFKC", raw)
    except Exception:
        raw_nfkc = raw
    raw_nfkc = raw_nfkc.replace("_", " ").replace("\\/", "/")
    raw_nfkc = re.sub(r"[\u200b-\u200f\u202a-\u202e\u2060\ufeff]", "", raw_nfkc)

    out = []
    seen = set()

    def add(value):
        value = str(value or "")
        value = value.replace("_", " ")
        value = re.sub(r"\s+", " ", value)
        value = value.strip(" \t\r\n-|:;/._")
        if not value or len(value) < 2 or not any(ch.isalpha() for ch in value):
            return
        key = value.casefold() if hasattr(value, "casefold") else value.lower()
        if key in seen:
            return
        seen.add(key)
        out.append(value)

    # Country/language/service/quality/release metadata.  These are removed only
    # when they appear as standalone tags, bracket metadata, or provider chains.
    tags = [
        # Quality / resolution / dynamic range
        r"4K", r"8K", r"UHD", r"FHD", r"FULL\s*HD", r"HD", r"SD",
        r"2160P", r"1440P", r"1080P", r"1080I", r"720P", r"576P", r"480P",
        r"HDR10\+?", r"HDR", r"DV", r"DOLBY\s*VISION", r"HLG",
        r"10BIT", r"8BIT", r"60FPS", r"50FPS", r"30FPS", r"25FPS", r"24FPS",

        # Streaming/provider/source
        r"AMZ", r"AMZN", r"AMAZON", r"AMAZON\s*PRIME", r"PRIME\s*VIDEO",
        r"NF", r"NETFLIX", r"DSNP", r"DISNEY\+?", r"DISNEYPLUS",
        r"APTV", r"ATVP", r"APPLE\s*TV\+?", r"APPLETV\+?",
        r"HMAX", r"HBO\s*MAX", r"HBO", r"MAX", r"HULU", r"SHAHID",
        r"OSN", r"STARZPLAY", r"STARZ", r"PARAMOUNT\+?", r"PMTP",
        r"PEACOCK", r"CRITERION", r"MUBI", r"PLEX",
        r"WEB[- ]?DL", r"WEBDL", r"WEB[- ]?RIP", r"WEBRIP", r"WEB",
        r"BLU[- ]?RAY", r"BLURAY", r"BDRIP", r"BRRIP", r"BDREMUX",
        r"REMUX", r"HDTV", r"PDTV", r"DVDRIP", r"DVD", r"CAM", r"TS",
        r"TELESYNC", r"TC", r"SCR", r"SCREENER",

        # Video codec
        r"HEVC", r"H\.?265", r"H265", r"X265", r"H\.?264", r"H264", r"X264",
        r"AV1", r"VP9", r"MPEG[- ]?2", r"MPEG[- ]?4",

        # Audio
        r"AAC(?:2\.0|5\.1|7\.1)?", r"AC3", r"EAC3", r"E[- ]?AC[- ]?3",
        r"DDP(?:2\.0|5\.1|7\.1)?", r"DD\+?", r"DTS(?:[- ]?HD)?",
        r"DTS[- ]?X", r"TRUEHD", r"ATMOS", r"DOLBY\s*AUDIO",
        r"2\.0CH", r"5\.1CH", r"7\.1CH",

        # Sub/dub/release markers
        r"MULTI", r"MULTI[- ]?AUDIO", r"MULTI[- ]?SUBS?", r"DUAL[- ]?AUDIO",
        r"SUBS?", r"SUBBED", r"HARDSUB", r"HC", r"DUB", r"DUBBED",
        r"ORIGINAL", r"UNCUT", r"EXTENDED", r"THEATRICAL", r"REPACK",
        r"PROPER", r"INTERNAL", r"COMPLETE",

        # Language codes/names
        r"AR", r"ARA", r"ARABIC", r"EN", r"ENG", r"ENGLISH",
        r"FR", r"FRE", r"FRA", r"FRENCH", r"ES", r"SPA", r"SPANISH",
        r"DE", r"GER", r"DEU", r"GERMAN", r"IT", r"ITA", r"ITALIAN",
        r"TR", r"TUR", r"TURKISH", r"PT", r"POR", r"PORTUGUESE",
        r"RU", r"RUS", r"RUSSIAN", r"HI", r"HIN", r"HINDI",
        r"UR", r"URD", r"URDU", r"FA", r"PER", r"FARSI", r"PERSIAN",
        r"KO", r"KOR", r"KOREAN", r"JA", r"JPN", r"JAPANESE",
        r"ZH", r"CHI", r"ZHO", r"CHINESE", r"TH", r"THA", r"THAI",
        r"HE", r"HEB", r"HEBREW", r"NL", r"DUT", r"DUTCH",
        r"PL", r"POL", r"POLISH", r"RO", r"RON", r"ROMANIAN",
        r"SV", r"SWE", r"SWEDISH", r"NO", r"NOR", r"NORWEGIAN",
        r"DA", r"DAN", r"DANISH", r"FI", r"FIN", r"FINNISH",
        r"EL", r"GRE", r"GREEK", r"CS", r"CZE", r"CZECH",
        r"HU", r"HUN", r"HUNGARIAN", r"ID", r"IND", r"INDONESIAN",
        r"MS", r"MAY", r"MALAY", r"BN", r"BEN", r"BENGALI",
        r"PA", r"PAN", r"PUNJABI", r"TA", r"TAM", r"TAMIL",
        r"TE", r"TEL", r"TELUGU", r"ML", r"MAL", r"MALAYALAM",

        # Country/region codes commonly inserted by IPTV servers
        r"US", r"USA", r"UK", r"GB", r"UAE", r"AE", r"KSA", r"SA",
        r"IN", r"INDIA", r"CA", r"CAN", r"AU", r"AUS", r"NZ",
        r"FRANCE", r"GERMANY", r"ITALY", r"SPAIN", r"TURKEY",
        r"RUSSIA", r"JAPAN", r"KOREA", r"CHINA", r"EG", r"EGYPT",
        r"MA", r"MOROCCO", r"DZ", r"ALGERIA", r"TN", r"TUNISIA",
        r"QA", r"QATAR", r"KW", r"KUWAIT", r"BH", r"BAHRAIN", r"OM", r"OMAN",
    ]
    tag = r"(?:" + "|".join(tags) + r")"

    # Preserve useful title material inside brackets before removing metadata.
    # Example: "Alien (Romulus)" remains available as a candidate, while
    # "(2025) (IN) [1080p]" is treated as metadata.
    work0 = raw_nfkc

    # Explicit year is passed separately to TMDb, never kept in cleaned queries.
    yearless = re.sub(
        r"(?<!\d)[\[(]?\s*(?:19|20)\d{2}\s*[\])]?(?!\d)",
        " ", work0
    )

    # Remove season/episode markers only as metadata suffix/prefix.  Keep the
    # base series name as a candidate.
    seasonless = re.sub(
        r"(?i)(?:\bS(?:EASON)?\s*\d{1,2}\b|\bE(?:P(?:ISODE)?)?\s*\d{1,3}\b|"
        r"\bS\d{1,2}E\d{1,3}\b|\b\d{1,2}X\d{1,3}\b)",
        " ", yearless
    )

    # Remove technical metadata in any bracket style.
    bracket_clean = seasonless
    for _ in range(10):
        before = bracket_clean
        bracket_clean = re.sub(
            r"[\[\(\{]\s*(?:" + tag + r")"
            r"(?:\s*[-|+/.,]\s*(?:" + tag + r"))*\s*[\]\)\}]",
            " ", bracket_clean, flags=re.I
        )
        if bracket_clean == before:
            break

    # Compact provider chains: "4K-AMZ-AR-DO - TITLE", "FHD.NF.EN | TITLE".
    # The unknown short token (e.g. DO) is removed only when the same chain also
    # contains at least one known metadata tag.
    chain_clean = bracket_clean
    compact = re.match(
        r"^\s*([A-Z0-9+]{1,8}(?:\s*[-|:/+.]\s*[A-Z0-9+]{1,8}){1,10})"
        r"\s*(?:-\s+|\|\s+|:\s+)(.+)$",
        chain_clean
    )
    if compact:
        chain, tail = compact.group(1), compact.group(2).strip()
        parts = [p for p in re.split(r"\s*[-|:/+.]\s*", chain) if p]
        known = any(re.fullmatch(tag, p, flags=re.I) for p in parts)
        codeish = all(re.fullmatch(r"[A-Z0-9+]{1,8}", p) for p in parts)
        if known and codeish and tail:
            chain_clean = tail

    # Repeated standalone metadata at beginning/end.
    edge_clean = chain_clean
    for _ in range(20):
        before = edge_clean
        edge_clean = re.sub(
            r"^\s*[\[\(\{]?\s*" + tag +
            r"(?=$|[\s\]\)\}\-|:/+.,])\s*[\]\)\}]?\s*(?:[-|:/+.,]\s*)?",
            "", edge_clean, count=1, flags=re.I
        )
        if edge_clean == before:
            break
    for _ in range(20):
        before = edge_clean
        edge_clean = re.sub(
            r"(?:\s+|[-|:/+.,]\s*)[\[\(\{]?\s*" + tag +
            r"\s*[\]\)\}]?\s*$",
            "", edge_clean, count=1, flags=re.I
        )
        if edge_clean == before:
            break

    # Remove release group suffixes only when they look strongly technical:
    # "-GROUP", "@GROUP", "[GROUP]" after a recognisable title.
    release_clean = re.sub(
        r"(?i)\s*(?:-|@)\s*(?:RARBG|YIFY|YTS|PSA|NTB|NTG|FLUX|TEPES|"
        r"ION10|ION265|FGT|EVO|CMRG|MZABI|TOMMY|HONE|GGEZ|SuccessfulCrab|"
        r"MeGusta|GalaxyTV|ETHEL|KOGI|SuccessfulCrab)\s*$",
        " ", edge_clean
    )

    # Drop standalone technical tokens that remain in the middle only if they
    # are surrounded by separators/spaces. This catches "Movie 1080p WEB-DL".
    mid_clean = release_clean
    for _ in range(6):
        before = mid_clean
        mid_clean = re.sub(
            r"(?i)(?:(?<=^)|(?<=[\s|:/+\-\[\(\{]))" + tag +
            r"(?=$|[\s|:/+\-\]\)\}])",
            " ", mid_clean
        )
        if mid_clean == before:
            break

    # Normalise common separators and dots used as word separators in releases.
    clean = mid_clean
    # Dots between alphabetic words are usually release separators; don't touch
    # decimal numbers such as "5.1".
    clean = re.sub(r"(?<=[A-Za-z\u0600-\u06FF])\.(?=[A-Za-z\u0600-\u06FF])", " ", clean)
    clean = re.sub(r"\s*[-|:/+]\s*[-|:/+]+\s*", " - ", clean)
    clean = re.sub(r"\s+", " ", clean).strip(" -|:/._")

    # Ordered strategy: strongest cleaned complete title first.
    add(clean)

    # If a title still ends with a bracketed non-metadata phrase, keep both full
    # and base-title candidates. This avoids breaking genuine titles while also
    # recovering provider annotations unknown to us.
    m = re.match(r"^(.*?)\s*[\(\[\{]([^)\]\}]{2,40})[\)\]\}]\s*$", clean)
    if m:
        base = m.group(1).strip()
        bracket = m.group(2).strip()
        add(clean)
        if base:
            add(base)
        if bracket and any(ch.isalpha() for ch in bracket):
            add("%s %s" % (base, bracket))

    # Provider prefix before a strong delimiter. Generate right side as a
    # candidate even if the prefix is unknown, but only when the left side is
    # short/code-like. Example "VIP MOVIES | Dune Part Two".
    for sep in (" | ", " - ", " : ", " / ", " — ", " – "):
        if sep not in clean:
            continue
        parts = [p.strip() for p in clean.split(sep) if p.strip()]
        for part in parts:
            add(part)
        if len(parts) >= 2:
            left = parts[0]
            if len(left.split()) <= 4 and (
                left.isupper() or
                re.fullmatch(r"[A-Za-z0-9+._ -]{2,22}", left)
            ):
                add(sep.join(parts[1:]).strip())

    # Mixed-language title: Arabic/Latin/Cyrillic/etc. become independent
    # candidates, e.g. "6 Days ستة أيام" -> "6 Days" and "ستة أيام".
    for part in _tmdb_multiscript_candidates(clean):
        add(part)

    # Repeat multi-script split for all delimiter candidates generated above.
    for candidate in list(out):
        for part in _tmdb_multiscript_candidates(candidate):
            add(part)

    # Colon subtitle fallback: TMDb sometimes stores only the main title.
    # Keep the full provider title first, then progressively safer alternates.
    # Some Arabic IPTV catalogues append an editorial type before a colon, e.g.
    # "القصة الكاملة دراما: لعبة جهنم" while TMDb stores "القصة الكاملة".
    # Never remove "دراما" globally: only add a base-title candidate when it is
    # the final token immediately before a colon, and only after the full/head
    # candidates have already been tried.
    for candidate in list(out):
        for sep in (":", " - ", " – ", " — "):
            if sep in candidate:
                head = candidate.split(sep, 1)[0].strip()
                tail = candidate.split(sep, 1)[1].strip()
                if head:
                    add(head)
                    if sep == ":":
                        base = re.sub(r"\s+(?:دراما)\s*$", "", head, flags=re.UNICODE).strip()
                        # Avoid turning a one-word title into an unsafe broad query.
                        if base and base != head and len(base.split()) >= 2:
                            add(base)
                if tail and len(tail) >= 3:
                    add(tail)

    # Remove common edition suffixes as an additional candidate, not destructive.
    for candidate in list(out):
        editionless = re.sub(
            r"(?i)\s+(?:DIRECTOR'?S\s+CUT|FINAL\s+CUT|SPECIAL\s+EDITION|"
            r"ANNIVERSARY\s+EDITION|RESTORED|REMASTERED|IMAX|UNRATED)\s*$",
            "", candidate
        ).strip()
        add(editionless)

    # Raw normalized provider title is last-resort compatibility fallback only.
    add(raw_nfkc)
    if raw_nfkc != raw:
        add(raw)

    return out


def _tmdb_match_norm(value):
    """Search-only normalization used to score TMDb candidates safely."""
    text = _tmdb_normalize_unicode_digits(value)
    try:
        text = unicodedata.normalize("NFKC", str(text or ""))
    except Exception:
        text = str(text or "")
    text = re.sub(r"[^\w\u0600-\u06ff]+", " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip().casefold()


def _tmdb_result_score(query, row, kind="vod", wanted_year=None):
    """Score TMDb search rows instead of trusting the first result.

    Based on UltraStalker's safe matching strategy: exact/core Arabic titles are
    strong evidence, while a small editorial suffix (e.g. "دراما") is allowed.
    """
    media_title = row.get("title") if kind == "vod" else row.get("name")
    original = row.get("original_title") if kind == "vod" else row.get("original_name")
    q = _tmdb_match_norm(query)
    t = _tmdb_match_norm(media_title)
    o = _tmdb_match_norm(original)
    if not q:
        return 0.0
    base = max(
        difflib.SequenceMatcher(None, q, t).ratio() if t else 0.0,
        difflib.SequenceMatcher(None, q, o).ratio() if o else 0.0,
    )
    if q == t or q == o:
        base = 1.0
    else:
        q_tokens = q.split()
        for candidate in (t, o):
            if not candidate:
                continue
            if candidate.startswith(q + " ") or q.startswith(candidate + " "):
                base = max(base, 0.96)
                continue
            c_tokens = candidate.split()
            if len(q_tokens) >= 2 and len(c_tokens) >= len(q_tokens):
                qset, cset = set(q_tokens), set(c_tokens)
                if qset and qset.issubset(cset) and len(cset - qset) <= 3:
                    base = max(base, 0.91)
    try:
        if wanted_year:
            date = row.get("release_date") if kind == "vod" else row.get("first_air_date")
            ry = _tmdb_extract_year(date)
            if ry:
                diff = abs(int(wanted_year) - int(ry))
                if diff == 0:
                    base += 0.16
                elif diff == 1:
                    base += 0.05
                elif diff >= 3:
                    base -= 0.18
    except Exception:
        pass
    try:
        base += min(0.02, float(row.get("popularity") or 0) / 15000.0)
    except Exception:
        pass
    return max(0.0, min(1.0, base))


def _device_tmdb_language():
    try:
        from Components.Language import language
        code = str(language.getLanguage() or "").lower()
        if code.startswith("ar"):
            return "ar-AE"
    except Exception:
        pass
    return "en-US"
DETAILS_TTL = 24 * 60 * 60
SEARCH_TTL = 24 * 60 * 60
TRENDING_TTL = 6 * 60 * 60


def _redact_tmdb_log(value):
    """Remove TMDb credentials from diagnostic text, including subprocess errors."""
    text = str(value or "")
    try:
        text = re.sub(r"(?i)(api_key=)[^&\s'\"]+", r"\1***", text)
        text = re.sub(r"(?i)(Authorization:\s*Bearer\s+)[^\s'\"]+", r"\1***", text)
        text = re.sub(r"(?i)(--header=Authorization:\s*Bearer\s+)[^\s'\"]+", r"\1***", text)
    except Exception:
        pass
    return text

def _log(message):
    return None

def load_settings():
    try:
        with open_text(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f) or {}
        selected = str(data.get("language") or "auto")
        mode = str(data.get("mode") or "auto").lower()
        if mode not in ("auto", "v3", "v4", "disabled"):
            mode = "auto"

        # A user's saved values take priority. Empty fields keep using the shared
        # built-in credentials so existing installations continue to work.
        custom_key = str(data.get("api_key") or "").strip()
        custom_key2 = str(data.get("api_key2") or "").strip()
        custom_token = str(data.get("access_token") or "").strip()
        enabled = mode != "disabled"
        key = custom_key or (DEFAULT_API_KEY if enabled else "")
        key2 = custom_key2 or (DEFAULT_API_KEY2 if enabled else "")
        token = custom_token or (DEFAULT_ACCESS_TOKEN if enabled else "")
        return {
            "mode": mode,
            "api_key": key,
            "api_key2": key2,
            "access_token": token,
            "custom_api_key": custom_key,
            "custom_api_key2": custom_key2,
            "custom_access_token": custom_token,
            "language": _device_tmdb_language() if selected == "auto" else selected,
            "language_setting": selected,
            "backdrop_quality": data.get("backdrop_quality", "w1280") if data.get("backdrop_quality", "w1280") in ("w1280", "w1920", "original") else "w1280",
        }
    except Exception:
        return {
            "mode": "auto",
            "api_key": DEFAULT_API_KEY,
            "api_key2": DEFAULT_API_KEY2,
            "access_token": DEFAULT_ACCESS_TOKEN,
            "custom_api_key": "",
            "custom_api_key2": "",
            "custom_access_token": "",
            "language": _device_tmdb_language(),
            "language_setting": "auto",
            "backdrop_quality": "w1280",
        }


def save_settings(api_key, language="en-US", mode="auto", access_token="", api_key2="", backdrop_quality="w1280"):
    try:
        ensure_dir(CONFIG_DIR)
        payload = {
            "mode": (mode or "auto").lower(),
            "api_key": (api_key or "").strip(),
            "api_key2": (api_key2 or "").strip(),
            "access_token": (access_token or "").strip(),
            "language": language or "en-US",
            "backdrop_quality": backdrop_quality if backdrop_quality in ("w1280", "w1920", "original") else "w1280",
        }
        with open_text(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(payload, f)
        try:
            os.chmod(CONFIG_FILE, 0o600)
        except Exception:
            pass
        return True
    except Exception:
        return False



def save_backdrop_quality(backdrop_quality):
    """Update only artwork quality without materialising built-in TMDb credentials.

    load_settings() intentionally exposes effective credentials (custom or built-in),
    so appearance-only saves must never round-trip those effective values into tmdb.json.
    """
    try:
        ensure_dir(CONFIG_DIR)
        try:
            with open_text(CONFIG_FILE, "r", encoding="utf-8") as f:
                payload = json.load(f) or {}
        except Exception:
            payload = {}
        payload["backdrop_quality"] = backdrop_quality if backdrop_quality in ("w1280", "w1920", "original") else "w1280"
        # Keep only actual persisted user overrides; never inject DEFAULT_* here.
        payload.setdefault("mode", "auto")
        payload.setdefault("language", "auto")
        payload.setdefault("api_key", "")
        payload.setdefault("api_key2", "")
        payload.setdefault("access_token", "")
        with open_text(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(payload, f)
        try:
            os.chmod(CONFIG_FILE, 0o600)
        except Exception:
            pass
        return True
    except Exception:
        return False



def _search_cache_path(kind, language, title, year):
    try:
        from .cache_manager import get_cache_dir
        directory = get_cache_dir("metadata")
    except Exception:
        # Do not silently spill persistent TMDb cache into /tmp.
        # If cache_manager is unavailable, skip disk cache for this lookup.
        return None
    key = "%s|%s|%s|%s" % (kind, language or "en-US", str(title or "").strip().lower(), str(year or ""))
    return os.path.join(directory, "search_" + hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")

def _load_search_cache(kind, language, title, year):
    path = _search_cache_path(kind, language, title, year)
    try:
        if not os.path.exists(path) or time.time() - os.path.getmtime(path) >= SEARCH_TTL:
            return None
        with open_text(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else None
    except Exception:
        return None

def _save_search_cache(kind, language, title, year, data):
    path = _search_cache_path(kind, language, title, year)
    try:
        temporary = path + ".tmp"
        with open_text(temporary, "w", encoding="utf-8") as handle:
            json.dump(data or {}, handle, ensure_ascii=False)
        atomic_replace(temporary, path)
    except Exception:
        pass

def _trending_cache_path(kind, language):
    try:
        from .cache_manager import get_cache_dir
        directory = get_cache_dir("metadata")
    except Exception:
        return None
    key = "trending-2026|%s|%s" % (kind, language or "en-US")
    return os.path.join(directory, "trending_" + hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")


def _load_trending_cache(kind, language):
    path = _trending_cache_path(kind, language)
    try:
        if not os.path.exists(path) or time.time() - os.path.getmtime(path) >= TRENDING_TTL:
            return None
        with open_text(path, "r", encoding="utf-8") as handle:
            rows = json.load(handle)
        return rows if isinstance(rows, list) else None
    except Exception:
        return None


def _save_trending_cache(kind, language, rows):
    path = _trending_cache_path(kind, language)
    try:
        temporary = path + ".tmp"
        with open_text(temporary, "w", encoding="utf-8") as handle:
            json.dump(list(rows or []), handle, ensure_ascii=False)
        atomic_replace(temporary, path)
    except Exception:
        pass




def backdrop_quality():
    try:
        value = str(load_settings().get("backdrop_quality") or "w1280")
    except Exception:
        value = "w1920"
    return value if value in ("w1280", "w1920", "original") else "w1280"


def backdrop_url(path):
    path = str(path or "")
    if not path:
        return ""
    if path.startswith("http://") or path.startswith("https://"):
        return path
    if not path.startswith("/"):
        path = "/" + path
    return IMAGE_BASE + backdrop_quality() + path

class TMDbClient(object):
    def __init__(self, api_key=None, language=None, access_token=None, mode=None, api_key2=None):
        cfg = load_settings()
        self.mode = (mode or cfg.get("mode") or "auto").lower()
        self.api_key = (api_key if api_key is not None else cfg.get("api_key") or "").strip()
        self.api_key2 = (api_key2 if api_key2 is not None else cfg.get("api_key2") or "").strip()
        self.access_token = (access_token if access_token is not None else cfg.get("access_token") or "").strip()
        self.language = language or cfg.get("language") or "en-US"

    def configured(self):
        if self.mode == "disabled":
            return False
        if self.mode == "v4":
            return bool(self.access_token)
        if self.mode == "v3":
            return bool(self.api_key or self.api_key2)
        return bool(self.access_token or self.api_key or self.api_key2)

    def _request(self, path, params, use_token=False, api_key=None):
        params = dict(params or {})
        params.setdefault("language", self.language)
        args = ["/usr/bin/wget", "-qO-", "--tries=1", "--timeout=8"]
        if use_token:
            if not self.access_token:
                raise RuntimeError("TMDb Read Access Token is not configured")
            args.append("--header=Authorization: Bearer %s" % self.access_token)
        else:
            selected_key = (api_key or self.api_key or "").strip()
            if not selected_key:
                raise RuntimeError("TMDb API key is not configured")
            params["api_key"] = selected_key
        url = API_BASE + path + "?" + urlencode(params)
        args.append(url)
        raw = subprocess.check_output(args, stderr=subprocess.STDOUT)
        if not isinstance(raw, str):
            raw = raw.decode("utf-8", "replace")
        data = json.loads(raw or "{}")
        if isinstance(data, dict) and data.get("success") is False:
            raise RuntimeError(data.get("status_message") or "TMDb request failed")
        return data

    def _get(self, path, params=None):
        if self.mode == "disabled":
            raise RuntimeError("TMDb is disabled")
        methods = []
        if self.mode == "v4":
            methods = [(True, None, "v4")]
        elif self.mode == "v3":
            if self.api_key:
                methods.append((False, self.api_key, "v3-key1"))
            if self.api_key2 and self.api_key2 != self.api_key:
                methods.append((False, self.api_key2, "v3-key2"))
        else:
            # Auto mode follows the preferred EStalker-style fallback order:
            # API Key 1 first, API Key 2 second, then the v4 token only if both fail.
            if self.api_key:
                methods.append((False, self.api_key, "v3-key1"))
            if self.api_key2 and self.api_key2 != self.api_key:
                methods.append((False, self.api_key2, "v3-key2"))
            if self.access_token:
                methods.append((True, None, "v4"))
        if not methods:
            raise RuntimeError("TMDb credentials are not configured")
        last = None
        for use_token, api_key, auth_name in methods:
            try:
                data = self._request(path, params, use_token=use_token, api_key=api_key)
                _log("GET OK %s auth=%s results=%s" % (
                    path, auth_name,
                    len(data.get("results") or []) if isinstance(data, dict) else "?"
                ))
                return data
            except Exception as exc:
                last = exc
                _log("GET FAILED %s auth=%s: %s" % (path, auth_name, exc))
        raise last or RuntimeError("TMDb request failed")

    def _is_scripted_tv_series(self, item):
        """Keep English US/UK scripted series and reject programme-style TV."""
        if not isinstance(item, dict):
            return False

        if str(item.get("original_language") or "").lower() != "en":
            return False

        origins = set(str(x or "").upper() for x in (item.get("origin_country") or []))
        if origins and not origins.intersection(set(("US", "GB"))):
            return False

        try:
            genres = set(int(x) for x in (item.get("genre_ids") or []))
        except Exception:
            genres = set()

        # Programme/factual genres we do not want in Popular or Trending TV.
        rejected = set((
            99,     # Documentary
            10763,  # News
            10764,  # Reality
            10767,  # Talk
        ))
        if genres.intersection(rejected):
            return False

        # Positive scripted-series genres. This intentionally excludes generic
        # factual/sports/reality/talk content even when TMDb marks it popular.
        allowed = set((
            16,     # Animation
            18,     # Drama
            35,     # Comedy
            37,     # Western
            80,     # Crime
            9648,   # Mystery
            10751,  # Family
            10759,  # Action & Adventure
            10765,  # Sci-Fi & Fantasy
            10766,  # Soap
            10768,  # War & Politics
        ))
        return bool(genres.intersection(allowed))


    def recommendations_for(self, tmdb_id, kind="vod", limit=20):
        """Return recommendation/similar titles for one TMDb item.

        This intentionally bypasses details_bundle cache because older cached
        details may have credits/artwork but an empty recommendations section.
        """
        try:
            tid=int(str(tmdb_id or "0").strip())
            if tid<=0:
                return []
        except Exception:
            return []

        try:
            wanted=max(1,min(int(limit or 20),50))
        except Exception:
            wanted=20

        media="movie" if kind=="vod" else "tv"
        results=[]
        seen=set()

        for endpoint in ("recommendations","similar"):
            page=1
            while len(results)<wanted and page<=2:
                try:
                    payload=self._get(
                        "/%s/%s/%s" % (media,tid,endpoint),
                        {"page":page}
                    ) or {}
                except Exception:
                    payload={}
                rows=payload.get("results") or []
                if not rows:
                    break
                for item in rows:
                    row=self._convert(item,kind)
                    rid=str(row.get("tmdb_id") or "")
                    if not rid or rid in seen:
                        continue
                    seen.add(rid)
                    results.append(row)
                    if len(results)>=wanted:
                        break
                page+=1

        return results[:wanted]


    def provider_catalog(self, kind, provider, limit=50):
        """Return TMDb titles available on one streaming provider.

        Provider ids used by TMDb:
          Netflix = 8
          Amazon Prime Video = 9
        No Popular/Trending fallback is used, so each mode remains provider-specific.
        """
        try:
            limit = max(1, min(int(limit or 200), 200))
        except Exception:
            limit = 200

        provider_key = str(provider or "").strip().lower()
        provider_id = {"netflix": 8, "prime": 9, "prime_video": 9}.get(provider_key)
        if not provider_id:
            return []

        media = "movie" if kind == "vod" else "tv"
        results = []
        seen = set()
        page = 1

        while len(results) < limit and page <= 10:
            params = {
                "watch_region": "US",
                "with_watch_providers": str(provider_id),
                "with_original_language": "en",
                "sort_by": "popularity.desc",
                "page": page,
            }
            payload = self._get("/discover/%s" % media, params) or {}
            rows = payload.get("results") or []
            if not rows:
                break

            for item in rows:
                if kind != "vod":
                    if not self._is_scripted_tv_series(item):
                        continue
                else:
                    if str(item.get("original_language") or "").lower() != "en":
                        continue

                row = self._convert(item, kind)
                tid = row.get("tmdb_id")
                if tid and tid not in seen:
                    row["_tmdb_provider"] = provider_key
                    results.append(row)
                    seen.add(tid)
                if len(results) >= limit:
                    break
            page += 1

        return results[:limit]


    def popular(self, kind, limit=50):
        """Return up to 50 current Popular Movies/TV Shows.

        Uses TMDb popular pages directly.  No per-title detail calls are made,
        so the landing row stays lightweight.
        """
        try:
            limit = max(1, min(int(limit or 50), 50))
        except Exception:
            limit = 50
        media = "movie" if kind == "vod" else "tv"
        results = []
        seen = set()
        page = 1
        while len(results) < limit and page <= 3:
            data = self._get("/%s/popular" % media, {"page": page})
            rows = data.get("results") or []
            if not rows:
                break
            for item in rows:
                if kind == "vod":
                    if str(item.get("original_language") or "").lower() != "en":
                        continue
                else:
                    if not self._is_scripted_tv_series(item):
                        continue
                row = self._convert(item, kind)
                tid = row.get("tmdb_id")
                if tid and tid not in seen:
                    seen.add(tid)
                    results.append(row)
                if len(results) >= limit:
                    break
            page += 1
        return results[:limit]



    def trending_2026(self, kind, limit=8):
        try:
            limit = max(1, min(int(limit or 8), 50))
        except Exception:
            limit = 8

        media = "movie" if kind == "vod" else "tv"
        results = []
        seen = set()
        page = 1
        absolute_rank = 0

        while len(results) < limit and page <= 5:
            data = self._get("/trending/%s/week" % media, {"page": page}) or {}
            rows = data.get("results") or []
            if not rows:
                break

            for item in rows:
                absolute_rank += 1
                if not self._eligible(item, kind):
                    continue
                if kind != "vod" and not self._is_scripted_tv_series(item):
                    continue

                row = self._convert(item, kind)
                tid = row.get("tmdb_id")
                if tid and tid not in seen:
                    row["_tmdb_rank"] = absolute_rank
                    results.append(row)
                    seen.add(tid)

                if len(results) >= limit:
                    break
            page += 1

        results = results[:limit]
        _save_trending_cache(kind, self.language, results)
        _log("TRENDING WEEKLY kind=%s count=%d" % (kind, len(results)))
        return results


    def home_feed(self, mode, limit=6):
        """Return distinct Popular/Trending Home rows from their real TMDb feeds."""
        mode = str(mode or "popular_movies")
        kind = "series" if mode.endswith("_series") else "vod"
        media = "tv" if kind == "series" else "movie"
        wanted = int(limit or 6)
        is_trending = mode.startswith("trending_")

        results = []
        seen = set()
        popular_ids = set()

        if is_trending:
            # Exclude current Popular titles so Home Trending is not a duplicate.
            for page in (1, 2, 3):
                payload = self._get("/%s/popular" % media, {"page": page}) or {}
                for item in payload.get("results") or []:
                    popular_ids.add(str(item.get("id") or ""))

            for page in (1, 2, 3, 4, 5):
                payload = self._get("/trending/%s/week" % media, {"page": page}) or {}
                for item in payload.get("results") or []:
                    tid = str(item.get("id") or "")
                    if tid and tid in popular_ids:
                        continue
                    if kind == "series" and not self._is_scripted_tv_series(item):
                        continue
                    if kind == "vod" and str(item.get("original_language") or "").lower() != "en":
                        continue
                    if tid and tid not in seen:
                        results.append(item)
                        seen.add(tid)
                    if len(results) >= wanted:
                        break
                if len(results) >= wanted:
                    break
        else:
            for page in (1, 2, 3, 4, 5):
                payload = self._get("/%s/popular" % media, {"page": page}) or {}
                for item in payload.get("results") or []:
                    tid = str(item.get("id") or "")
                    if kind == "series":
                        if not self._is_scripted_tv_series(item):
                            continue
                    else:
                        if str(item.get("original_language") or "").lower() != "en":
                            continue
                    if tid and tid not in seen:
                        results.append(item)
                        seen.add(tid)
                    if len(results) >= wanted:
                        break
                if len(results) >= wanted:
                    break

        converted = []
        for item in results[:wanted]:
            row = self._convert(item, kind)
            row["_tivimate_home_kind"] = kind
            row["_home_tmdb_feed"] = mode
            converted.append(row)
        return converted[:wanted]


    def search_title(self, title, kind="vod", year=None):
        media = "movie" if kind == "vod" else "tv"
        year = _tmdb_extract_year(title, year)
        candidates = _tmdb_title_candidates(title)
        if not candidates:
            return None
        # Cleaned title first, then raw fallback. Year first, then title-only.
        attempts = [year, None] if year else [None]
        for clean_title in candidates:
            for wanted_year in attempts:
                cached = _load_search_cache(kind, self.language, clean_title, wanted_year)
                if cached:
                    _log("SEARCH CACHE HIT kind=%s title=%s year=%s" % (kind, clean_title, wanted_year or ""))
                    return cached
                # Ignore cached empty results so an old bad normalization can never block recovery.
                params = {"query": clean_title, "page": 1}
                if wanted_year:
                    params["year" if kind == "vod" else "first_air_date_year"] = str(wanted_year)
                data = self._get("/search/%s" % media, params) or {}
                rows = data.get("results") or []
                result = rows[0] if rows else {}
                _save_search_cache(kind, self.language, clean_title, wanted_year, result)
                if result:
                    return result
        return None

    def search_artwork(self, title, kind="vod", year=None, required_key=None):
        """Provider-agnostic TMDb artwork search with confidence scoring.

        Do not trust TMDb result #1 blindly. IPTV labels often contain Arabic
        editorial/provider suffixes; score all returned rows and accept a core
        title match while rejecting unrelated first results.
        """
        year = _tmdb_extract_year(title, year)
        candidates = _tmdb_title_candidates(title)
        if not candidates:
            return None
        media = "movie" if kind == "vod" else "tv"
        attempts = [year, None] if year else [None]
        best_row = None
        best_score = 0.0
        for candidate in candidates:
            for wanted_year in attempts:
                try:
                    params = {"query": candidate, "page": 1}
                    if wanted_year:
                        params["year" if kind == "vod" else "first_air_date_year"] = str(wanted_year)
                    payload = self._get("/search/%s" % media, params) or {}
                    rows = payload.get("results") or []
                    local_row = None
                    local_score = 0.0
                    for row in rows[:20]:
                        if required_key and not row.get(required_key):
                            continue
                        score = _tmdb_result_score(candidate, row, kind, wanted_year)
                        if score > local_score:
                            local_score, local_row = score, row
                        if score > best_score:
                            best_score, best_row = score, row
                    # Exact/core-title matches are decisive; stop early.
                    if local_row is not None and local_score >= 0.90:
                        return local_row
                except Exception:
                    continue
        # Prefer no artwork over an unrelated poster. 0.72 still allows normal
        # punctuation/translation variation while blocking weak name collisions.
        if best_row is not None and best_score >= 0.72:
            return best_row
        return None

    def details_bundle(self, tmdb_id, kind="vod"):
        """Return movie/series details with a persistent 24-hour JSON cache.

        The cached data is returned immediately on repeat visits. When the cache
        is stale, TMDb is queried and the file is atomically refreshed.
        """
        # Never turn a missing provider id into /movie/0 or /tv/0. Besides being
        # invalid, auto auth mode would retry the same bad request with every
        # configured credential and can stall Enigma2 for several timeouts.
        try:
            if int(str(tmdb_id or "0").strip()) <= 0:
                return {}
        except Exception:
            return {}
        media = "movie" if kind == "vod" else "tv"
        try:
            from .cache_manager import get_cache_dir
            cache_dir = get_cache_dir("metadata")
        except Exception:
            # No persistent cache root available: keep details in memory/network only.
            cache_dir = None
        # Shared details record: every page uses the same TMDb-id keyed file.
        safe_lang = re.sub(r"[^A-Za-z0-9_.-]+", "_", self.language.replace("/", "_"))
        cache_key = "%s_%s_%s" % (media, str(tmdb_id), safe_lang)
        cache_path = (os.path.join(cache_dir, "details_tmdb_%s.json" % cache_key) if cache_dir else None)
        legacy_cache_path = None
        if cache_dir:
            try:
                from .cache_manager import get_cache_root
                legacy_cache_path = os.path.join(get_cache_root(), "details_json", hashlib.md5(cache_key.encode("utf-8")).hexdigest() + ".json")
            except Exception:
                legacy_cache_path = None
        def useful(payload):
            if not isinstance(payload, dict) or not payload.get("id"):
                return False
            # Old builds could cache a text-only/empty response for 24 hours.
            # Require at least one artwork or enrichment section before trusting it.
            return bool(
                payload.get("poster_path") or payload.get("backdrop_path") or
                ((payload.get("credits") or {}).get("cast") or []) or
                ((payload.get("recommendations") or {}).get("results") or []) or
                ((payload.get("similar") or {}).get("results") or [])
            )

        try:
            if cache_path and (not os.path.exists(cache_path)) and legacy_cache_path and os.path.exists(legacy_cache_path):
                try:
                    os.rename(legacy_cache_path, cache_path)
                except Exception:
                    try:
                        import shutil
                        shutil.copy2(legacy_cache_path, cache_path)
                    except Exception:
                        pass
            if cache_path and os.path.exists(cache_path) and os.path.getsize(cache_path) > 20:
                age = time.time() - os.path.getmtime(cache_path)
                if age < DETAILS_TTL:
                    with open_text(cache_path, "r", encoding="utf-8") as f:
                        data = json.load(f) or {}
                    if useful(data):
                        _log("DETAILS CACHE HIT %s:%s age=%ds" % (media, tmdb_id, int(age)))
                        return data
                    _log("DETAILS CACHE INCOMPLETE %s:%s; refreshing" % (media, tmdb_id))
        except Exception as exc:
            _log("DETAILS CACHE READ FAILED %s:%s %s" % (media, tmdb_id, exc))

        data = self._get("/%s/%s" % (media, tmdb_id), {
            "append_to_response": "credits,recommendations,similar,images",
            # Do not restrict TMDb poster/backdrop artwork by UI language.
            # Omitting include_image_language lets the images payload expose artwork
            # across all available languages; title/metadata language stays unchanged.
        })
        # Some localized responses contain text but miss enrichment. Retry once in
        # English and merge only missing fields; this keeps Arabic metadata when present.
        if not useful(data) and self.language != "en-US":
            try:
                original_language = self.language
                self.language = "en-US"
                fallback = self._get("/%s/%s" % (media, tmdb_id), {
                    "append_to_response": "credits,recommendations,similar,images",
                    # Artwork remains language-unrestricted on the English metadata fallback.
                }) or {}
                self.language = original_language
                merged = dict(fallback)
                merged.update(data or {})
                for key in ("credits", "recommendations", "similar", "images"):
                    if not (merged.get(key) or {}):
                        merged[key] = fallback.get(key) or {}
                for key in ("poster_path", "backdrop_path", "overview"):
                    if not merged.get(key):
                        merged[key] = fallback.get(key)
                data = merged
            except Exception as exc:
                try:
                    self.language = original_language
                except Exception:
                    pass
                _log("DETAILS EN FALLBACK FAILED %s:%s %s" % (media, tmdb_id, exc))
        if useful(data):
            if cache_path:
                try:
                    tmp = cache_path + ".tmp"
                    with open_text(tmp, "w", encoding="utf-8") as f:
                        json.dump(data or {}, f, ensure_ascii=False)
                    atomic_replace(tmp, cache_path)
                    _log("DETAILS CACHE WRITE %s:%s" % (media, tmdb_id))
                except Exception as exc:
                    _log("DETAILS CACHE WRITE FAILED %s:%s %s" % (media, tmdb_id, exc))
        else:
            _log("DETAILS NOT CACHED incomplete %s:%s" % (media, tmdb_id))
        return data or {}

    def convert_public(self, item, kind):
        return self._convert(item or {}, kind)

    def _eligible(self, item, kind):
        date = item.get("release_date") if kind == "vod" else item.get("first_air_date")
        if not str(date or "").startswith("2026"):
            return False
        if str(item.get("original_language") or "").lower() != "en":
            return False
        if kind == "series":
            origins = item.get("origin_country") or []
            if origins and "US" not in origins:
                return False
        return True

    def _convert(self, item, kind):
        title = item.get("title") or item.get("name") or ""
        original = item.get("original_title") or item.get("original_name") or title
        date = item.get("release_date") if kind == "vod" else item.get("first_air_date")
        year = str(date or "")[:4]
        poster = item.get("poster_path") or ""
        backdrop = item.get("backdrop_path") or ""
        return {
            "_tmdb": True,
            "tmdb_id": str(item.get("id") or ""),
            "name": title,
            "title": title,
            "original_title": original,
            "year": year,
            "releaseDate": date or "",
            "rating": str(item.get("vote_average") or "")[:4],
            "plot": item.get("overview") or "",
            "description": item.get("overview") or "",
            "stream_icon": (IMAGE_BASE + "w500" + poster) if poster else "",
            "cover": (IMAGE_BASE + "w500" + poster) if poster else "",
            "backdrop_path": backdrop_url(backdrop) if backdrop else "",
            "logo_path": "",
            "media_type": kind,
        }
