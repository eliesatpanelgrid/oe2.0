from __future__ import absolute_import
from .compat import atomic_replace, ensure_dir, open_text
import os, json, re, ssl, traceback, subprocess, time, hashlib
try:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode
except ImportError:
    try:
        from urllib2 import Request, urlopen
        from urllib import urlencode
    except Exception:
        Request = urlopen = urlencode = None

CONFIG_DIR = "/etc/enigma2/tivimatee2"
CONFIG_FILE = os.path.join(CONFIG_DIR, "tmdb.json")
API_BASE = "https://api.themoviedb.org/3"
IMAGE_BASE = "https://image.tmdb.org/t/p/"
DEFAULT_API_KEY = "3c3efcf47c3577558812bb9d64019d65"


def _device_tmdb_language():
    try:
        from Components.Language import language
        code = str(language.getLanguage() or "").lower()
        if code.startswith("ar"):
            return "ar-AE"
    except Exception:
        pass
    return "en-US"
LOG_FILE = "/tmp/tivimatee2/tmdb.log"
DETAILS_TTL = 24 * 60 * 60
TRENDING_TTL = 6 * 60 * 60


def _log(message):
    try:
        ensure_dir(os.path.dirname(LOG_FILE))
        with open_text(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(str(message) + "\n")
    except Exception:
        pass

def load_settings():
    try:
        with open_text(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f) or {}
        key = str(data.get("api_key") or "").strip() or DEFAULT_API_KEY
        selected = str(data.get("language") or "auto")
        return {"api_key": key, "language": _device_tmdb_language() if selected == "auto" else selected, "language_setting": selected}
    except Exception:
        return {"api_key": DEFAULT_API_KEY, "language": _device_tmdb_language(), "language_setting": "auto"}


def save_settings(api_key, language="en-US"):
    try:
        ensure_dir(CONFIG_DIR)
        with open_text(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump({"api_key": (api_key or "").strip(), "language": language or "en-US"}, f)
        return True
    except Exception:
        return False


def _trending_cache_path(kind, language):
    try:
        from .cache_manager import get_cache_dir
        directory = get_cache_dir("tmdb_trending")
    except Exception:
        directory = "/tmp/tivimatee2/tmdb_trending"
        try:
            if not os.path.isdir(directory):
                os.makedirs(directory)
        except Exception:
            pass
    key = "trending-2026|%s|%s" % (kind, language or "en-US")
    return os.path.join(directory, hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")


def _load_trending_cache(kind, language):
    path = _trending_cache_path(kind, language)
    try:
        if not os.path.exists(path) or time.time() - os.path.getmtime(path) >= TRENDING_TTL:
            return None
        with open_text(path, "r", encoding="utf-8") as handle:
            rows = json.load(handle)
        return rows if isinstance(rows, list) else None
    except Exception:
        return None


def _save_trending_cache(kind, language, rows):
    path = _trending_cache_path(kind, language)
    try:
        temporary = path + ".tmp"
        with open_text(temporary, "w", encoding="utf-8") as handle:
            json.dump(list(rows or []), handle, ensure_ascii=False)
        atomic_replace(temporary, path)
    except Exception:
        pass


class TMDbClient(object):
    def __init__(self, api_key=None, language=None):
        cfg = load_settings()
        self.api_key = (api_key or cfg.get("api_key") or "").strip()
        self.language = language or cfg.get("language") or "en-US"

    def configured(self):
        return bool(self.api_key)

    def _get(self, path, params=None):
        if not self.api_key:
            raise RuntimeError("TMDb API key is not configured")
        params = dict(params or {})
        params["api_key"] = self.api_key
        params.setdefault("language", self.language)
        url = API_BASE + path + "?" + urlencode(params)
        try:
            # Pure2 wget was verified to access TMDb successfully on the target box.
            raw = subprocess.check_output(["/usr/bin/wget", "-qO-", "--tries=1", "--timeout=8", url], stderr=subprocess.STDOUT)
            if not isinstance(raw, str):
                raw = raw.decode("utf-8", "replace")
            data = json.loads(raw or "{}")
            if isinstance(data, dict) and data.get("success") is False:
                raise RuntimeError(data.get("status_message") or "TMDb request failed")
            _log("GET OK %s results=%s" % (path, len(data.get("results") or []) if isinstance(data, dict) else "?"))
            return data
        except Exception as exc:
            _log("WGET %s FAILED: %s" % (url, exc))
            raise

    def trending_2026(self, kind, limit=8):
        cached = _load_trending_cache(kind, self.language)
        if cached is not None:
            _log("TRENDING CACHE HIT kind=%s count=%d" % (kind, len(cached)))
            return list(cached[:limit])
        media = "movie" if kind == "vod" else "tv"
        results = []
        seen = set()
        # Primary source: current TMDb trending.
        data = self._get("/trending/%s/week" % media, {"page": 1})
        for item in data.get("results") or []:
            if self._eligible(item, kind):
                row = self._convert(item, kind)
                if row["tmdb_id"] not in seen:
                    results.append(row); seen.add(row["tmdb_id"])
            if len(results) >= limit:
                break
        # Fallback: popular US/English 2026, so the row never disappears.
        if len(results) < limit:
            if kind == "vod":
                params = {"primary_release_year": "2026", "with_original_language": "en", "region": "US", "sort_by": "popularity.desc", "page": 1}
                path = "/discover/movie"
            else:
                params = {"first_air_date_year": "2026", "with_original_language": "en", "with_origin_country": "US", "sort_by": "popularity.desc", "page": 1}
                path = "/discover/tv"
            data = self._get(path, params)
            for item in data.get("results") or []:
                row = self._convert(item, kind)
                if row["tmdb_id"] not in seen:
                    results.append(row); seen.add(row["tmdb_id"])
                if len(results) >= limit:
                    break
        # Return trending immediately. Logo lookups are intentionally not done here:
        # fetching /images for every item can block the Enigma2 page for minutes.
        # The UI already has a text-logo fallback, so content appears without delay.
        results = results[:limit]
        _save_trending_cache(kind, self.language, results)
        _log("TRENDING OK kind=%s count=%d" % (kind, len(results)))
        return results


    def search_title(self, title, kind="vod", year=None):
        media = "movie" if kind == "vod" else "tv"
        params = {"query": title or "", "page": 1}
        if year:
            params["year" if kind == "vod" else "first_air_date_year"] = str(year)
        data = self._get("/search/%s" % media, params)
        rows = data.get("results") or []
        return rows[0] if rows else None

    def details_bundle(self, tmdb_id, kind="vod"):
        """Return movie/series details with a persistent 24-hour JSON cache.

        The cached data is returned immediately on repeat visits. When the cache
        is stale, TMDb is queried and the file is atomically refreshed.
        """
        media = "movie" if kind == "vod" else "tv"
        try:
            from .cache_manager import get_cache_dir
            cache_dir = get_cache_dir("details_json")
        except Exception:
            cache_dir = "/tmp/tivimatee2/details_json"
            try:
                ensure_dir(cache_dir)
            except Exception:
                pass
        cache_key = "%s_%s_%s" % (media, str(tmdb_id), self.language.replace("/", "_"))
        cache_path = os.path.join(cache_dir, hashlib.md5(cache_key.encode("utf-8")).hexdigest() + ".json")
        try:
            if os.path.exists(cache_path) and os.path.getsize(cache_path) > 20:
                age = time.time() - os.path.getmtime(cache_path)
                if age < DETAILS_TTL:
                    with open_text(cache_path, "r", encoding="utf-8") as f:
                        data = json.load(f) or {}
                    _log("DETAILS CACHE HIT %s:%s age=%ds" % (media, tmdb_id, int(age)))
                    return data
        except Exception as exc:
            _log("DETAILS CACHE READ FAILED %s:%s %s" % (media, tmdb_id, exc))

        data = self._get("/%s/%s" % (media, tmdb_id), {
            "append_to_response": "credits,recommendations,similar,images",
            "include_image_language": "en,null"
        })
        try:
            tmp = cache_path + ".tmp"
            with open_text(tmp, "w", encoding="utf-8") as f:
                json.dump(data or {}, f, ensure_ascii=False)
            atomic_replace(tmp, cache_path)
            _log("DETAILS CACHE WRITE %s:%s" % (media, tmdb_id))
        except Exception as exc:
            _log("DETAILS CACHE WRITE FAILED %s:%s %s" % (media, tmdb_id, exc))
        return data

    def convert_public(self, item, kind):
        return self._convert(item or {}, kind)

    def _eligible(self, item, kind):
        date = item.get("release_date") if kind == "vod" else item.get("first_air_date")
        if not str(date or "").startswith("2026"):
            return False
        if str(item.get("original_language") or "").lower() != "en":
            return False
        if kind == "series":
            origins = item.get("origin_country") or []
            if origins and "US" not in origins:
                return False
        return True

    def _convert(self, item, kind):
        title = item.get("title") or item.get("name") or ""
        original = item.get("original_title") or item.get("original_name") or title
        date = item.get("release_date") if kind == "vod" else item.get("first_air_date")
        year = str(date or "")[:4]
        poster = item.get("poster_path") or ""
        backdrop = item.get("backdrop_path") or ""
        return {
            "_tmdb": True,
            "tmdb_id": str(item.get("id") or ""),
            "name": title,
            "title": title,
            "original_title": original,
            "year": year,
            "releaseDate": date or "",
            "rating": str(item.get("vote_average") or "")[:4],
            "plot": item.get("overview") or "",
            "description": item.get("overview") or "",
            "stream_icon": (IMAGE_BASE + "w500" + poster) if poster else "",
            "cover": (IMAGE_BASE + "w500" + poster) if poster else "",
            "backdrop_path": (IMAGE_BASE + "w1280" + backdrop) if backdrop else "",
            "logo_path": "",
            "media_type": kind,
        }
