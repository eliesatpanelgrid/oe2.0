TiviMateE2 skin asset layout

common/   shared logos, overlays, badges
home/     Home screen and navigation artwork
live/     Live TV artwork
movies/   Movie/VOD detail/action artwork
series/   Series/episode artwork
poster/   Poster layouts, frames and poster-view assets
packages/ Package/filter artwork and provider package art
server/   Server manager/editor/status artwork
settings/ Settings, language, cache, backup and TMDb settings art
search/   Search screen artwork
player/   Player-only artwork
navicons/ Shared top navigation icons

Subtitle module resources remain under TiviMateSubtitles/.
