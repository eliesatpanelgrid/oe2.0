# -*- coding: utf-8 -*-
"""TiviMateE2 VOD Player - clean rebuild.

This module is a standalone VOD player path. It deliberately does not load
or execute the legacy ``_player_parts`` implementation. Live TV continues to
use ``live_player.py``.

Design goals:
* Enigma2-native playback (eServiceReference/session.nav + public InfoBar mixins)
* 4097 default, 5002/5001 available, 8193 only on DreamOS, never service type 1
* resume identity independent from service type and stream URL
* safe service switching while preserving resume/audio/subtitle preferences
* clear startup/EOF behavior without auto-fallback or hidden engine changes
* TiviMate subtitle provider bridge preserved as a feature layer
"""
from __future__ import absolute_import

import hashlib
import json
import os
import re
import time

try:
    from PIL import Image, ImageDraw
except Exception:
    Image = None
    ImageDraw = None

from Components.ActionMap import ActionMap
try:
    from Components.ActionMap import NumberActionMap
except Exception:
    NumberActionMap = ActionMap
from Components.Label import Label
from Components.Pixmap import MultiPixmap, Pixmap
from Components.ProgressBar import ProgressBar
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
try:
    from Components.Sources.StaticText import StaticText
except Exception:
    from Components.Sources.Source import Source

    class StaticText(Source):
        def __init__(self, text=""):
            Source.__init__(self)
            self.text = text

        def setText(self, text):
            self.text = text
            self.changed((self.CHANGED_ALL,))

from enigma import eConsoleAppContainer, eServiceReference, eTimer, iPlayableService, setSpinnerOnOff
try:
    from enigma import iServiceInformation
except Exception:
    iServiceInformation = None

# UltraStalker native aspect-ratio authority.
try:
    from enigma import eAVSwitch
except Exception:
    try:
        from enigma import eAVControl as eAVSwitch
    except Exception:
        eAVSwitch = None

ASPECT_RATIOS = {
    0: "4:3 Letterbox",
    1: "4:3 PanScan",
    2: "16:9",
    3: "16:9 Always",
    4: "16:10 Letterbox",
    5: "16:10 PanScan",
    6: "16:9 Letterbox",
}

from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.InfoBarGenerics import (
    InfoBarAudioSelection,
    InfoBarMoviePlayerSummarySupport,
    InfoBarNotifications,
    InfoBarSeek,
    InfoBarSubtitleSupport,
    InfoBarSummarySupport,
)

from .display_scale import scale_skin
from .storage import data_path
from .artwork_queue import request_artwork, cached_artwork


PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
PLAYER_STATE_FILE = data_path("vod_player_state_v2.json")
PLAYER_RESUME_FILE = data_path("vod_resume_v2.json")
CONTINUE_WATCHING_FILE = data_path("resume.json")
PLAYER_PREFS_FILE = data_path("vod_preferences_v2.json")

PTS = 90000
RESUME_MIN_SECONDS = 15
RESUME_OFFER_SECONDS = 20
COMPLETE_RATIO = 0.95
STARTUP_GRACE_SECONDS = 12
STALL_NOTICE_SECONDS = 12


# ---------------------------------------------------------------------------
# Small, dependency-free persistence helpers
# ---------------------------------------------------------------------------
def _read_json(path):
    try:
        with open(path, "r") as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _write_json(path, value):
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        temp = path + ".tmp"
        with open(temp, "w") as handle:
            json.dump(value, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        os.rename(temp, path)
        return True
    except Exception:
        return False


def _clean_title(value):
    return re.sub(r"\s+", " ", str(value or "").strip())


def _identity_title(value):
    text = _clean_title(value).lower()
    text = re.sub(r"\b(?:19|20)\d{2}\b", " ", text)
    text = re.sub(
        r"\b(?:4k|8k|uhd|fhd|hd|sd|2160p|1080p|720p|nf|netflix|amz|amzn|"
        r"web[- ]?dl|webrip|bluray|x264|x265|h264|h265|hevc|ar|ara|arabic|en|eng|english)\b",
        " ", text, flags=re.I,
    )
    text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
    return " ".join(text.split())


def _item_year(item):
    item = item or {}
    for key in ("year", "release_year", "releaseDate", "release_date"):
        match = re.search(r"\b(?:19|20)\d{2}\b", str(item.get(key) or ""))
        if match:
            return match.group(0)
    title = item.get("name") or item.get("title") or item.get("stream_name") or ""
    match = re.search(r"\b(?:19|20)\d{2}\b", str(title))
    return match.group(0) if match else ""


def _media_identity(item):
    """Stable identity that never includes service type or stream URL."""
    item = item or {}
    series_name = item.get("series_name") or item.get("_tmdb_title") or ""
    title = series_name or item.get("name") or item.get("title") or item.get("stream_name") or ""
    normalized = _identity_title(title)
    season = str(item.get("season_number") or item.get("season") or item.get("_subdl_season") or "")
    episode = str(item.get("episode_number") or item.get("episode_num") or item.get("episode") or item.get("_subdl_episode") or "")
    kind = str(item.get("_kind") or "").lower()
    is_episode = bool(series_name or season or episode or kind in ("episode", "series", "tv", "show"))

    if normalized:
        if is_episode:
            raw = "episode|%s|s%s|e%s" % (normalized, season, episode)
        else:
            raw = "movie|%s|%s" % (normalized, _item_year(item))
    else:
        source = str(item.get("_source_key") or item.get("server_id") or item.get("source_id") or item.get("playlist_id") or "")
        content_id = ""
        for key in ("stream_id", "vod_id", "movie_id", "episode_id", "id"):
            value = item.get(key)
            if value not in (None, ""):
                content_id = str(value)
                break
        raw = "id|%s|%s|s%s|e%s" % (source, content_id, season, episode)
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()


def _ref_url(ref):
    if ref is None:
        return ""
    try:
        path = ref.getPath()
        if path:
            return str(path)
    except Exception:
        pass
    try:
        text = str(ref.toString() or "")
        if text.startswith(("http://", "https://")):
            return text
        if "http%3a" in text.lower() or "https%3a" in text.lower():
            try:
                from urllib.parse import unquote
            except Exception:
                from urllib import unquote
            return unquote(text.split(":", 10)[-1])
    except Exception:
        pass
    return ""


# ---------------------------------------------------------------------------
# Service policy
# ---------------------------------------------------------------------------
def _is_dreamos():
    texts = []
    for path in ("/etc/image-version", "/etc/issue", "/etc/os-release"):
        try:
            with open(path, "r") as handle:
                texts.append(handle.read(8192).lower())
        except Exception:
            pass
    blob = "\n".join(texts)
    if "dreamos" in blob or "dreambox os" in blob:
        return True
    try:
        model = open("/proc/stb/info/model", "r").read().strip().lower()
        if model.startswith(("dm", "dream")) and os.path.exists("/usr/bin/dpkg"):
            return True
    except Exception:
        pass
    return False


def _available_stream_types():
    values = [
        (4097, "GStreamer"),
        (5001, "ServiceApp"),
        (5002, "ServiceApp / ExtePlayer3"),
    ]
    if _is_dreamos():
        values.append((8193, "DreamOS"))
    return values


def _load_player_type():
    """Compatibility API for callers. New VOD sessions always default to 4097."""
    return 4097


def _save_player_type(value):
    """Compatibility API. Persist last manual choice for diagnostics only."""
    try:
        value = int(value)
    except Exception:
        value = 4097
    allowed = [item[0] for item in _available_stream_types()]
    state = _read_json(PLAYER_STATE_FILE)
    state["last_service_type"] = value if value in allowed else 4097
    _write_json(PLAYER_STATE_FILE, state)


# ---------------------------------------------------------------------------
# Lightweight UI helpers; no legacy player class is referenced
# ---------------------------------------------------------------------------
class FreshInfoBarShowHide(object):
    def __init__(self):
        self._hud_lock = 0
        self._hud_timer = eTimer()
        try:
            self._hud_timer_conn = self._hud_timer.timeout.connect(self._hideHud)
        except Exception:
            self._hud_timer.callback.append(self._hideHud)
        self.onShow.append(self._hudShown)

    def _hudShown(self):
        if self._hud_lock:
            return
        try:
            self._hud_timer.stop()
            self._hud_timer.start(5000, True)
        except Exception:
            pass

    def _hideHud(self):
        # r265: restore normal InfoBar auto-hide using the existing HUD timer.
        # Playback remains active; only the player HUD Screen is hidden.
        if self._hud_lock:
            return
        try:
            self.hide()
        except Exception:
            pass

    def refreshInfobar(self):
        try:
            self.show()
        except Exception:
            pass
        self._hudShown()

    def lockShow(self):
        self._hud_lock += 1
        try:
            self._hud_timer.stop()
            self.show()
        except Exception:
            pass

    def unlockShow(self):
        self._hud_lock = max(0, self._hud_lock - 1)
        if not self._hud_lock:
            self._hudShown()


class FreshPVRState(object):
    def __init__(self):
        try:
            self.onPlayStateChanged.append(self._freshPlayState)
        except Exception:
            pass

    def _freshPlayState(self, state):
        text = ">"
        try:
            text = state[3] or ">"
        except Exception:
            pass
        icon = 0
        speed = ""
        if text == "||":
            icon = 1
        elif text == "END":
            icon = 2
        elif text.startswith(">>"):
            icon = 3
            speed = text.replace(">>", "").strip()
        elif text.startswith("<<"):
            icon = 4
            speed = text.replace("<<", "").strip()
        elif text.startswith("/"):
            icon = 5
            speed = text
        try:
            self["statusicon"].setPixmapNum(icon)
            self["speed"].setText(speed)
        except Exception:
            pass
        self.refreshInfobar()


class TiviMatePlayer(
    InfoBarBase,
    FreshInfoBarShowHide,
    FreshPVRState,
    InfoBarAudioSelection,
    InfoBarSubtitleSupport,
    InfoBarSeek,
    InfoBarNotifications,
    InfoBarSummarySupport,
    InfoBarMoviePlayerSummarySupport,
    Screen,
):
    """Standalone VOD player built around Enigma2 public playback APIs."""

    ENABLE_RESUME_SUPPORT = False
    ALLOW_SUSPEND = True

    skin = """<screen name="TiviMateVodPlayerV2" position="0,0" size="1920,1080" backgroundColor="#ff000000" flags="wfNoBorder">
        <!-- r276: full-width bottom HUD; large circle + clean reference icon row. -->
        <eLabel position="0,820" size="1920,260" backgroundColor="#B8000000" zPosition="1"/>
        <eLabel position="0,819" size="1920,1" backgroundColor="#55FFFFFF" zPosition="2"/>

        <widget name="cover" position="28,748" size="320,320" alphatest="blend" scale="1" zPosition="5"/>

        <widget name="titleLabel" position="385,845" size="760,46" font="Regular;36" noWrap="1" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="3"/>
        <!-- Service type is rendered as a PNG badge (4097/5002/5001), not text. -->
        <widget source="streamtype" render="Label" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <!-- r483: clean inline metadata; no outer badge boxes. Keep only small service icon, yellow IMDb mark and calendar icon. -->
        <widget name="serviceTypeBadge" position="385,894" size="32,28" alphatest="blend" scale="1" zPosition="4"/>
        <widget name="serviceTypeText" position="424,892" size="72,32" font="Regular;22" noWrap="1" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="3"/>
        <ePixmap position="510,894" size="56,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/tivimate_infobar/player/player_imdb_mark_r483.png" alphatest="blend" scale="1" zPosition="4"/>
        <widget name="ratingLabel" position="575,892" size="54,32" font="Regular;22" noWrap="1" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="3"/>
        <ePixmap position="644,896" size="34,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/tivimate_infobar/player/player_year_icon_r483.png" alphatest="blend" scale="1" zPosition="4"/>
        <widget name="metaLabel" position="687,892" size="90,32" font="Regular;22" noWrap="1" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="3"/>

        <widget name="vodPosition" position="385,940" size="180,38" font="Regular;29" noWrap="1" foregroundColor="#28A9FF" backgroundColor="#00000000" halign="left" transparent="1" zPosition="3"/>
        <widget name="vodDuration" position="1180,940" size="190,38" font="Regular;29" noWrap="1" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="right" transparent="1" zPosition="3"/>
        <widget name="vodProgress" position="385,972" size="985,11" borderWidth="0" backgroundColor="#59636D" foregroundColor="#16C4EA" zPosition="3"/>

        <!-- r481: compact original-style color keys + 0/TV hints below progress. Visual only. -->
        <eLabel position="385,1009" size="24,24" backgroundColor="#E53935" cornerRadius="12" zPosition="6"/>
        <widget name="redHint" position="418,1003" size="180,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4"/>
        <eLabel position="610,1009" size="24,24" backgroundColor="#31D158" cornerRadius="12" zPosition="6"/>
        <widget name="greenHint" position="643,1003" size="130,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4"/>
        <eLabel position="785,1009" size="24,24" backgroundColor="#FFD84D" cornerRadius="12" zPosition="6"/>
        <widget name="yellowHint" position="818,1003" size="155,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4"/>
        <widget name="zeroHint" position="985,1003" size="185,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4"/>
        <widget name="tvHint" position="1180,1003" size="210,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4"/>

        <!-- Provider logo uses the package/source already attached to the item. -->
        <widget name="providerLogo" position="1285,846" size="105,42" alphatest="blend" scale="1" zPosition="4"/>

        <!-- r277: technical badges are live values from the currently playing service. -->
        <widget name="resolutionBadge" position="1400,846" size="100,42" alphatest="blend" zPosition="4"/>
        <widget name="aspectBadge" position="1510,846" size="82,42" alphatest="blend" zPosition="4"/>
        <widget name="videoBadge" position="1602,846" size="100,42" alphatest="blend" zPosition="4"/>
        <widget name="audioBadge" position="1712,846" size="100,42" alphatest="blend" zPosition="4"/>

        <!-- Same analog clock used on Packages; centered just below the H.26 video badge. -->
        <widget name="playerClockFace" position="1594,894" size="116,116" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_clock_r108/face.png" alphatest="blend" scale="1" zPosition="4"/>
        <widget name="playerClockHour" position="1594,894" size="116,116" alphatest="blend" scale="1" zPosition="5"/>
        <widget name="playerClockMinute" position="1594,894" size="116,116" alphatest="blend" scale="1" zPosition="6"/>
        <widget name="playerDate" position="1722,936" size="180,34" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="5"/>

        <widget name="lockIcon" position="1810,846" size="42,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/tivimate_infobar/player/player_icon_lock_r276.png" alphatest="blend" zPosition="4"/>
        <widget name="networkIcon" position="1860,846" size="50,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/tivimate_infobar/player/player_icon_wifi_r276.png" alphatest="blend" zPosition="4"/>

        <widget name="codecLabel" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <widget name="speed" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <widget name="statusicon" position="0,0" size="1,1" zPosition="0"/>

        <widget name="descLabel" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <widget name="service8193Box" position="0,0" size="1,1" zPosition="0"/>
        <widget name="service8193Label" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <widget name="notification" position="520,760" size="880,42" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="20"/>
        <widget name="subtitleHint" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <widget name="srtOverlay" position="120,600" size="1680,160" font="Regular;44" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="bottom" zPosition="30"/>
    </screen>"""

    def __init__(self, session, service, item=None):
        Screen.__init__(self, session)
        self.session = session
        self.input_service = service
        self.item = dict(item or {})
        self.streamurl = _ref_url(service) or str(
            self.item.get("url") or self.item.get("stream_url") or self.item.get("play_url") or ""
        )
        # Preserve the service type selected by the caller/server instead of
        # forcing every VOD session to 4097. Fall back to 4097 only when the
        # incoming reference does not expose a valid type.
        try:
            incoming_type = int(getattr(service, "type", 0) or 0)
        except Exception:
            incoming_type = 0
        if not incoming_type:
            try:
                incoming_type = int(str(service.toString() or "").split(":", 1)[0])
            except Exception:
                incoming_type = 0
        self.servicetype = incoming_type if incoming_type > 0 else 4097
        self._startup_preferred_type = int(self.servicetype)
        self._identity = _media_identity(self.item)
        self._closing = False
        self._restored_original_service = False
        self._started = False
        self._playback_confirmed = False
        self._service_started_at = 0.0
        self._startup_eof_count = 0
        self._last_position = 0
        self._last_duration = 0
        self._last_pts_seen = 0
        self._last_pts_change_at = 0.0
        self._stall_notice_sent = False
        self._resume_target = 0
        self._resume_applied = False
        self._resume_attempts = 0
        self._external_subs = None
        self._tivimate_subtitles = None
        self._tivimate_subtitle_controller = None
        self._external_subtitle_path = ""
        self._external_subtitle_owner = ""
        self._subtitle_session_delay_ms = 0
        self._subtitle_restore_attempted = False
        self._record_process = None
        self._record_path = ""
        self.ar_id_player = -1
        self._episode_items = list(self.item.get("_episode_items") or [])
        try:
            self._episode_index = int(self.item.get("_episode_index", -1))
        except Exception:
            self._episode_index = -1
        self._episode_source = dict(self.item.get("_episode_source") or {})
        self._cover_cached_path = ""

        try:
            self.original_service = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            self.original_service = None

        # Initialize only public Enigma2 mixins used by this player.
        for klass in (
            InfoBarBase,
            FreshInfoBarShowHide,
            InfoBarAudioSelection,
            InfoBarSubtitleSupport,
            InfoBarSeek,
            InfoBarNotifications,
            InfoBarSummarySupport,
            InfoBarMoviePlayerSummarySupport,
        ):
            klass.__init__(self)
        FreshPVRState.__init__(self)

        # r490: initialize the shared embedded/server subtitle renderer so
        # Server / Embedded tracks use the same CC Font settings as every
        # downloaded/external provider. This reuses the existing TiviMate
        # subtitle settings/renderer and adds no timer or network work.
        self._unified_embedded_ready = False
        try:
            from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import (
                initTiviMateSettings, TiviMateSubtitleSupportEmbedded)
            self.subsProSettings = initTiviMateSettings()
            TiviMateSubtitleSupportEmbedded.__init__(self, True, True)
            self._unified_embedded_ready = True
        except Exception as exc:
            print("[TiviMateE2] unified subtitle renderer init failed: %s" % exc)

        title = _clean_title(self.item.get("name") or self.item.get("title") or self.item.get("stream_name") or "TiviMate")
        self["titleLabel"] = Label(title)
        year = _item_year(self.item)
        rating = str(self.item.get("rating") or self.item.get("rating_5based") or self.item.get("vote_average") or "").strip()
        runtime = str(self.item.get("runtime") or self.item.get("duration") or self.item.get("duration_secs") or "").strip()
        genre = str(self.item.get("genre") or self.item.get("genres") or self.item.get("category_name") or "").strip()
        self["ratingLabel"] = Label(rating if rating else "-")
        self["metaLabel"] = Label(year if year else "-")
        self["redHint"] = Label("Subtitles")
        self["greenHint"] = Label("Audio")
        self["yellowHint"] = Label("Subtitle List")
        self["zeroHint"] = Label("0  Aspect Ratio")
        self["tvHint"] = Label("TV  Service Type")
        description = _clean_title(self.item.get("plot") or self.item.get("description") or self.item.get("overview") or "")
        self["descLabel"] = Label(description[:260])
        extension = os.path.splitext(self.streamurl.split("?", 1)[0])[-1].replace(".", "").upper() or "STREAM"
        video_hint = str(self.item.get("container_extension") or self.item.get("codec") or self.item.get("video_codec") or "").upper()
        self["codecLabel"] = Label("  •  ".join([x for x in (extension, video_hint) if x]))
        self["cover"] = Pixmap()
        self["vodProgress"] = ProgressBar()
        try:
            self["vodProgress"].setRange((0, 1000))
        except Exception:
            pass
        self["vodPosition"] = Label("00:00")
        self["vodDuration"] = Label("00:00")
        self["resolutionBadge"] = Pixmap()
        self["aspectBadge"] = Pixmap()
        self["videoBadge"] = Pixmap()
        self["audioBadge"] = Pixmap()
        self["playerClockFace"] = Pixmap()
        self["playerClockHour"] = Pixmap()
        self["playerClockMinute"] = Pixmap()
        self["playerDate"] = Label("")
        self["serviceTypeBadge"] = Pixmap()
        self["serviceTypeText"] = Label("")
        self._player_clock_minute = None
        self._player_clock_hour_slot = None
        self["providerLogo"] = Pixmap()
        try:
            self["providerLogo"].hide()
        except Exception:
            pass
        self["lockIcon"] = Pixmap()
        self["networkIcon"] = Pixmap()
        for _badge_name in ("resolutionBadge", "aspectBadge", "videoBadge", "audioBadge"):
            try:
                self[_badge_name].hide()
            except Exception:
                pass
        self._tech_badge_tick = 0
        # Keep the last valid technical values while Enigma2 briefly reports
        # empty stream metadata during/after a VOD seek.  Reset on each new
        # service start so values never leak to another movie/episode.
        self._tech_badge_values = {"resolution": "", "aspect": "", "video": "", "audio": ""}
        self["speed"] = Label("")
        self["notification"] = Label("")
        self["subtitleHint"] = Label("")
        self["srtOverlay"] = Label("")
        try:
            self["srtOverlay"].hide()
        except Exception:
            pass
        self["statusicon"] = MultiPixmap()
        self["streamcat"] = StaticText("Series" if self._episode_items else "VOD")
        self["streamtype"] = StaticText(str(self.servicetype))
        self["extension"] = StaticText(extension)
        self["service8193Box"] = Pixmap()
        self["service8193Label"] = Label("8193")
        if not _is_dreamos():
            try:
                self["service8193Box"].hide()
                self["service8193Label"].hide()
            except Exception:
                pass

        self._notification_timer = self._makeTimer(self._clearNotification)
        self._monitor_timer = self._makeTimer(self._monitorPlayback)
        self._checkpoint_timer = self._makeTimer(self._checkpoint)
        self._resume_timer = self._makeTimer(self._resumeTick)
        self._prefs_timer = self._makeTimer(self._restorePreferences)

        self["actions"] = ActionMap(
            [
                "OkCancelActions",
                "ColorActions",
                "ChannelSelectBaseActions",
                "MoviePlayerActions",
                "MediaPlayerActions",
                "DirectionActions",
                "TiviMatePlayerActions",
            ],
            {
                "cancel": self.back,
                "ok": self.refreshInfobar,
                "green": self.audioSelection,
                "red": self.openSubtitleEditor,
                "blue": self.openSubsSupport,
                "yellow": self.openSubtitleSelection,
                "channelUp": self.nextEpisode,
                "channelDown": self.prevEpisode,
                "tv": self.cycleStreamTypeQuick,
                "subtitleFineMinus": self.subtitleFineMinus,
                "subtitleFinePlus": self.subtitleFinePlus,
            },
            -2,
        )
        self["menuActions"] = ActionMap(
            ["MenuActions", "InfobarEPGActions"],
            {"menu": self.openPlayerMenu, "info": self.openPlayerMenu},
            -3,
        )
        try:
            self["numberActions"] = NumberActionMap(["NumberActions"], {"5": self.openSubsSupport, "0": (lambda *args: self.nextAspectRatio())}, -4)
        except Exception:
            pass

        events = {
            iPlayableService.evStart: self._serviceStarted,
            iPlayableService.evEOF: self._serviceEOF,
        }
        tune_failed = getattr(iPlayableService, "evTuneFailed", None)
        if tune_failed is not None:
            events[tune_failed] = self._serviceFailed
        self._event_tracker = ServiceEventTracker(screen=self, eventmap=events)
        self.onFirstExecBegin.append(self.playStream)
        self.onClose.append(self._cleanup)

    # ------------------------------------------------------------------
    # Timers / notification
    # ------------------------------------------------------------------
    def _makeTimer(self, callback):
        timer = eTimer()
        try:
            connection = timer.timeout.connect(callback)
            setattr(self, "_timer_connection_%s" % id(timer), connection)
        except Exception:
            timer.callback.append(callback)
        return timer

    def _showNotification(self, text, kind=None, timeout=4):
        try:
            self["notification"].setText(str(text))
            self.refreshInfobar()
        except Exception:
            pass
        try:
            self._notification_timer.stop()
            self._notification_timer.start(int(timeout * 1000), True)
        except Exception:
            pass

    def _clearNotification(self):
        try:
            self["notification"].setText("")
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Playback core
    # ------------------------------------------------------------------
    def _serviceReference(self):
        ref = eServiceReference(int(self.servicetype), 0, self.streamurl)
        title = _clean_title(self.item.get("name") or self.item.get("title") or self.item.get("stream_name") or "TiviMate")
        try:
            ref.setName(title)
        except Exception:
            pass
        return ref

    def _loadHudPoster(self):
        # r268: crop the already-cached server poster to a true transparent circle.
        # No network request or new timer/hook; the generated PNG is reused from cache.
        path = str(self.item.get("_player_cover_cache") or "").strip()
        provider_cache = str(self.item.get("_player_cover_cache_fallback") or "").strip()
        fallback_path = os.path.join(os.path.dirname(__file__), "tivimate_infobar", "player", "player_tivimate_circle_fallback_r278.png")

        # r428: series details always passes the parent-series poster URL in
        # _player_cover.  Reuse the existing artwork queue only when that poster
        # is not cached yet; this is player-only and does not touch episode art.
        if not path or not os.path.exists(path):
            if provider_cache and os.path.exists(provider_cache):
                path = provider_cache
            else:
                cover_url = str(self.item.get("_player_cover") or "").strip()
                is_series = str(self.item.get("_tmdb_kind") or self.item.get("_kind") or "").lower() in ("series", "tv", "episode")
                if cover_url and is_series and not getattr(self, "_hud_poster_request_pending", False):
                    self._hud_poster_request_pending = True
                    def poster_done(cached_path):
                        self._hud_poster_request_pending = False
                        try:
                            if cached_path and os.path.exists(cached_path):
                                self.item["_player_cover_cache"] = cached_path
                                self._loadHudPoster()
                        except Exception:
                            pass
                    def poster_failed(_path):
                        self._hud_poster_request_pending = False
                    try:
                        request_artwork(cover_url, "posters", poster_done, priority=80, errback=poster_failed)
                    except Exception:
                        self._hud_poster_request_pending = False
                path = fallback_path
                if not os.path.exists(path):
                    return

        display_path = path
        is_logo_fallback = (os.path.abspath(path) == os.path.abspath(fallback_path))
        if (not is_logo_fallback) and Image is not None and ImageDraw is not None:
            try:
                root, _ext = os.path.splitext(path)
                circle_path = root + ".tivimate-circle-r302.png"
                source_mtime = int(os.path.getmtime(path))
                circle_ok = os.path.exists(circle_path) and int(os.path.getmtime(circle_path)) >= source_mtime
                if not circle_ok:
                    img = Image.open(path).convert("RGBA")
                    w, h = img.size
                    try:
                        resample = Image.Resampling.LANCZOS
                    except Exception:
                        resample = getattr(Image, "LANCZOS", Image.BICUBIC)
                    target = 320

                    # r302: true full-bleed circle for both server and TMDb posters.
                    # Center-crop to fill the whole 320x320 circle; no inset poster.
                    fill_ratio = max(float(target) / max(1, w), float(target) / max(1, h))
                    fill_w = max(target, int(round(w * fill_ratio)))
                    fill_h = max(target, int(round(h * fill_ratio)))
                    canvas = img.resize((fill_w, fill_h), resample)
                    crop_left = max(0, (fill_w - target) // 2)
                    crop_top = max(0, (fill_h - target) // 2)
                    canvas = canvas.crop((crop_left, crop_top, crop_left + target, crop_top + target)).convert("RGBA")

                    mask = Image.new("L", (target, target), 0)
                    draw_mask = ImageDraw.Draw(mask)
                    draw_mask.ellipse((2, 2, target - 3, target - 3), fill=255)
                    canvas.putalpha(mask)
                    # Thin white/soft-gray rim, matching the approved reference.
                    rim = ImageDraw.Draw(canvas)
                    rim.ellipse((3, 3, target - 4, target - 4), outline=(238, 242, 246, 255), width=3)
                    canvas.save(circle_path, "PNG")
                display_path = circle_path
            except Exception:
                display_path = path

        try:
            self["cover"].instance.setPixmapFromFile(display_path)
            self._cover_cached_path = display_path
        except Exception:
            try:
                self["cover"].setPixmapFromFile(display_path)
                self._cover_cached_path = display_path
            except Exception:
                pass

    def _loadProviderLogo(self):
        """Show the packaged provider logo from existing item/package metadata.

        No network lookup, timer or extra service query is used here.
        """
        try:
            self["providerLogo"].hide()
        except Exception:
            pass

        provider = str(
            self.item.get("_server_package_provider")
            or self.item.get("_tmdb_provider")
            or self.item.get("provider")
            or ""
        ).strip().lower()
        package_name = str(
            self.item.get("_server_package_name")
            or self.item.get("package_name")
            or self.item.get("category_name")
            or ""
        ).strip().lower()
        title = str(self.item.get("name") or self.item.get("title") or "").strip().lower()
        hint = " ".join((provider, package_name, title[:24]))

        key = ""
        spaced_hint = " " + hint.replace("_", " ").replace("-", " ") + " "
        # Provider/package logos first, then content-category logos.  Everything
        # is resolved from metadata already attached to the item: no network,
        # timer or additional playback query is introduced here.
        if provider in ("netflix", "nf") or "netflix" in hint or title.startswith("nf -") or title.startswith("nf-"):
            key = "netflix"
        elif provider in ("prime", "amazon", "primevideo", "prime video") or "prime video" in hint or "amazon prime" in hint or title.startswith("pv -"):
            key = "prime"
        elif provider in ("disney", "disney+") or "disney" in hint:
            key = "disney"
        elif provider == "shahid" or "shahid" in hint or "شاهد" in hint:
            key = "shahid"
        elif provider == "tod" or " tod " in spaced_hint:
            key = "tod"
        elif provider == "viu" or " viu " in spaced_hint:
            key = "viu"
        elif provider == "hulu" or " hulu " in spaced_hint:
            key = "hulu"
        elif "imdb" in hint:
            key = "imdb"
        elif "ufc" in hint:
            key = "ufc"
        elif "wwe" in hint or "wrestling" in hint or "مصارعة" in hint:
            key = "wrestling"
        elif "horror" in hint or "رعب" in hint:
            key = "horror"
        elif "action" in hint or "اكشن" in hint or "أكشن" in hint:
            key = "action"
        elif "anime" in hint or "انمي" in hint or "أنمي" in hint:
            key = "anime"
        elif "kids" in hint or "kidz" in hint or "children" in hint or "اطفال" in hint or "أطفال" in hint:
            key = "kids"
        elif "asian" in hint or "آسيو" in hint or "اسيو" in hint:
            key = "asian"
        elif "indian" in hint or "bollywood" in hint or "هندي" in hint:
            key = "indian"
        elif "ramadan" in hint or "رمضان" in hint:
            key = "ramadan"
        elif "theater" in hint or "theatre" in hint or "مسرح" in hint:
            key = "theater"
        elif "music" in hint or "موسيقى" in hint or "موسيقي" in hint:
            key = "music"
        elif "foreign" in hint or "اجنبي" in hint or "أجنبي" in hint:
            key = "foreign"
        elif "series" in hint or "tv shows" in hint or "مسلسلات" in hint:
            key = "series"
        elif "movie" in hint or "movies" in hint or "افلام" in hint or "أفلام" in hint:
            key = "movies"

        base = os.path.dirname(__file__)
        player_dir = os.path.join(base, "skins", "player")
        paths = {
            "netflix": os.path.join(player_dir, "player_provider_netflix_r285.png"),
            "prime": os.path.join(player_dir, "player_provider_prime_r285.png"),
            "disney": os.path.join(player_dir, "player_provider_disney_r285.png"),
            "shahid": os.path.join(player_dir, "player_provider_shahid_r285.png"),
            "tod": os.path.join(player_dir, "player_provider_tod_r285.png"),
            "viu": os.path.join(player_dir, "player_package_viu_r405.png"),
            "hulu": os.path.join(player_dir, "player_package_hulu_r405.png"),
            "imdb": os.path.join(player_dir, "player_package_imdb_r405.png"),
            "action": os.path.join(player_dir, "player_package_action_r405.png"),
            "horror": os.path.join(player_dir, "player_package_horror_r405.png"),
            "kids": os.path.join(player_dir, "player_package_kids_r405.png"),
            "anime": os.path.join(player_dir, "player_package_anime_r405.png"),
            "asian": os.path.join(player_dir, "player_package_asian_r405.png"),
            "indian": os.path.join(player_dir, "player_package_indian_r405.png"),
            "wrestling": os.path.join(player_dir, "player_package_wrestling_r405.png"),
            "ufc": os.path.join(player_dir, "player_package_ufc_r405.png"),
            "ramadan": os.path.join(player_dir, "player_package_ramadan_r405.png"),
            "theater": os.path.join(player_dir, "player_package_theater_r405.png"),
            "music": os.path.join(player_dir, "player_package_music_r405.png"),
            "foreign": os.path.join(player_dir, "player_package_foreign_r405.png"),
            "movies": os.path.join(player_dir, "player_package_movies_r405.png"),
            "series": os.path.join(player_dir, "player_package_series_r405.png"),
        }
        logo = paths.get(key, "")
        if not logo or not os.path.exists(logo):
            return
        try:
            self["providerLogo"].instance.setPixmapFromFile(logo)
            self["providerLogo"].show()
        except Exception:
            try:
                self["providerLogo"].setPixmapFromFile(logo)
                self["providerLogo"].show()
            except Exception:
                pass

    def playStream(self):
        self._loadProviderLogo()
        self._loadHudPoster()
        if self._closing:
            return
        if not self.streamurl:
            self._showNotification("Stream URL unavailable", MessageBox.TYPE_ERROR, 6)
            return


        # Preserve the current media position before an explicit engine restart.
        if self._started:
            self._saveResume()
            self._savePreferences()

        # r407 startup fix: replace the active service directly.
        # On Enigma2/4097, stopService() can emit an EOF from the previous
        # service during startup and make a valid VOD appear stuck on
        # "Starting 4097". playService() already replaces the current service.
        self._started = False
        self._playback_confirmed = False
        self._service_started_at = time.time()
        self._startup_eof_count = 0
        self._last_pts_seen = 0
        self._last_pts_change_at = time.time()
        self._stall_notice_sent = False
        self._resume_applied = False
        self._resume_attempts = 0
        self._resume_seek_count = 0
        self._resume_verify_cycles = 0
        self._resume_grace_until = 0.0
        self._resume_started_at = 0.0
        self._resume_phase = "probe"
        self._resume_target = self._loadResumeTarget()
        if int(self._resume_target or 0) > 0:
            self._resume_grace_until = time.time() + 16.0
        self._subtitle_restore_attempted = False
        # r408: native/server subtitle tracks can arrive after the one-shot
        # preferences restore. Reuse the existing 1s playback monitor to retry
        # the saved global language briefly; no new timer or event hook.
        self._tech_badge_values = {"resolution": "", "aspect": "", "video": "", "audio": ""}

        try:
            # Keep the short Enigma2 busy spinner hidden while the service engine
            # accepts the new VOD service. This does not change playback timing.
            try:
                setSpinnerOnOff(0)
            except Exception:
                pass
            try:
                result = self.session.nav.playService(self._serviceReference())
            finally:
                try:
                    setSpinnerOnOff(1)
                except Exception:
                    pass
            if result is False:
                raise RuntimeError("service engine rejected the stream")
            self._started = True
            self["streamtype"].setText(str(self.servicetype))
            self._updateServiceTypeBadge()
            self._monitor_timer.start(1000, False)
            # r393: re-enable the existing resume/checkpoint path. No new timer/hook.
            if self.ENABLE_RESUME_SUPPORT:
                self._checkpoint_timer.start(30000, False)
            self._prefs_timer.start(1800, True)
            self.refreshInfobar()
        except Exception as exc:
            self._showNotification("Playback failed: %s" % exc, MessageBox.TYPE_ERROR, 7)

    def _serviceStarted(self):
        self._service_started_at = time.time()
        self._last_pts_change_at = time.time()
        self._resume_attempts = 0

        # Do not let Enigma2/ServiceApp briefly render its first automatic
        # embedded subtitle track (commonly English) before TiviMateE2 restores
        # the user's remembered Server/Embedded language.  Clear only the
        # native subtitle selection at service start; the existing playback
        # monitor will enable the remembered language once its track is ready.
        try:
            InfoBarSubtitleSupport.enableSubtitle(self, None)
        except Exception:
            pass
        if self.ENABLE_RESUME_SUPPORT and int(self._resume_target or 0) > 0 and not self._resume_applied:
            self._resume_started_at = time.time()
            self._resume_phase = "probe"
            self._scheduleResumeProbe()
    def _serviceFailed(self):
        self._showNotification("Service Type %s could not start" % self.servicetype, MessageBox.TYPE_ERROR, 6)

    def _serviceEOF(self):
        # UltraStalker-style resume shield: some ServiceApp/ExtEplayer3 builds
        # emit transient EOF while the decoder is still becoming seekable.
        if int(self._resume_target or 0) > 0 and time.time() < float(self._resume_grace_until or 0.0):
            return
        # 4097 can emit an early EOF while GStreamer is still opening a URL.
        if not self._playback_confirmed:
            self._startup_eof_count += 1
            if time.time() - self._service_started_at < STARTUP_GRACE_SECONDS:
                self._showNotification("Opening %s ..." % self.servicetype, MessageBox.TYPE_INFO, 3)
                return
            self._showNotification("No playable video on %s" % self.servicetype, MessageBox.TYPE_ERROR, 5)
            return

        seek, position, duration = self._seekData()
        if duration and position >= int(duration * COMPLETE_RATIO):
            self._clearResume()
            self._showNotification("End of movie", MessageBox.TYPE_INFO, 2)
        else:
            self._saveResume()
            self._showNotification("Stream ended", MessageBox.TYPE_INFO, 3)

    def _seekData(self):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if not seek:
                return None, 0, 0
            pos_result = seek.getPlayPosition()
            len_result = seek.getLength()
            position = int(pos_result[1]) if pos_result and pos_result[0] == 0 and pos_result[1] > 0 else 0
            duration = int(len_result[1]) if len_result and len_result[0] == 0 and len_result[1] > 0 else 0
            return seek, position, duration
        except Exception:
            return None, 0, 0

    def _videoGeometry(self):
        if iServiceInformation is None:
            return 0, 0
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if not info:
                return 0, 0
            width = int(info.getInfo(iServiceInformation.sVideoWidth) or 0)
            height = int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
            return max(0, width), max(0, height)
        except Exception:
            return 0, 0


    def _technicalItemHints(self):
        """Return technical hints already carried by the current VOD item.

        This is a local metadata fallback only; it performs no network request.
        Enigma2 service.info() remains authoritative whenever it reports a
        concrete value.
        """
        item = self.item if isinstance(getattr(self, "item", None), dict) else {}
        nested = item.get("info") if isinstance(item.get("info"), dict) else {}

        def first(keys):
            for src in (item, nested):
                for key in keys:
                    value = src.get(key)
                    if value not in (None, ""):
                        return str(value).strip()
            return ""

        resolution = ""
        quality_text = " ".join(filter(None, [
            first(("resolution", "quality", "video_resolution", "stream_quality")),
            first(("name", "title", "stream_name")),
        ])).upper()
        if any(token in quality_text for token in ("2160", "4K", "UHD")):
            resolution = "2160p"
        elif any(token in quality_text for token in ("1080", "FHD", "FULL HD")):
            resolution = "1080p"
        elif "720" in quality_text or " HD " in (" %s " % quality_text):
            resolution = "720p"
        elif "576" in quality_text:
            resolution = "576p"
        elif "480" in quality_text or " SD " in (" %s " % quality_text):
            resolution = "480p"

        video = ""
        codec_text = first(("video_codec", "codec", "video", "vcodec", "video_type")).upper()
        if "H265" in codec_text or "H.265" in codec_text or "HEVC" in codec_text or "X265" in codec_text:
            video = "HEVC"
        elif "H264" in codec_text or "H.264" in codec_text or "AVC" in codec_text or "X264" in codec_text:
            video = "H.264"
        elif "VP9" in codec_text:
            video = "VP9"
        elif "VP8" in codec_text:
            video = "VP8"
        elif "MPEG2" in codec_text or "MPEG-2" in codec_text:
            video = "MPEG2"
        elif "MPEG4" in codec_text or "MPEG-4" in codec_text:
            video = "MPEG4"
        elif "VC1" in codec_text or "VC-1" in codec_text:
            video = "VC-1"
        elif "XVID" in codec_text:
            video = "XVID"

        aspect = ""
        aspect_text = first(("aspect", "aspect_ratio", "display_aspect_ratio", "dar")).replace(" ", "")
        if aspect_text in ("16:9", "16/9", "1.7778", "1.78"):
            aspect = "16:9"
        elif aspect_text in ("4:3", "4/3", "1.3333", "1.33"):
            aspect = "4:3"
        elif aspect_text in ("2.35:1", "2.35", "2.39:1", "2.39", "21:9"):
            aspect = "2.35:1"

        return resolution, aspect, video

    def _technicalStreamInfo(self, width=0, height=0):
        """Read current stream technical data from the active Enigma2 service.

        Uses the already-existing playback monitor.  No new timer or hook is
        introduced.  Direct service values are preferred and geometry is kept
        as a safe fallback for images/service types that expose less metadata.
        """
        resolution = ""
        aspect = ""
        video = ""
        audio_name = ""

        try:
            width = int(width or 0)
            height = int(height or 0)
        except Exception:
            width, height = 0, 0

        service = None
        info = None
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
        except Exception:
            service = None
            info = None

        # Refresh geometry directly from the active service when the caller
        # still has 0/old values.  This is the same service.info() path already
        # used by _videoGeometry(), not a network request.
        if info is not None and iServiceInformation is not None:
            try:
                iw = int(info.getInfo(iServiceInformation.sVideoWidth) or 0)
                ih = int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
                if iw > 0:
                    width = iw
                if ih > 0:
                    height = ih
            except Exception:
                pass

        # Resolution class: use both dimensions.  Cinemascope 1920x800/816
        # is still a 1080-class source, and 3840x1600 is still 2160/4K-class.
        if width > 0 or height > 0:
            if width >= 3000 or height >= 1800:
                resolution = "2160p"
            elif width >= 1800 or height >= 1000:
                resolution = "1080p"
            elif width >= 1200 or height >= 700:
                resolution = "720p"
            elif width >= 900 or height >= 560:
                resolution = "576p"
            elif width >= 700 or height >= 460:
                resolution = "480p"

        # Prefer the Enigma2 aspect value only when the image exposes a value
        # we can identify safely.  Otherwise derive it from the actual video
        # geometry, which is reliable across ServiceApp/4097 variants.
        if info is not None and iServiceInformation is not None:
            try:
                aspect_key = getattr(iServiceInformation, "sAspect", None)
                if aspect_key is not None:
                    av = int(info.getInfo(aspect_key))
                    # Common Enigma2 aspect encodings seen across images.
                    if av in (2, 3, 4, 5, 6):
                        aspect = "16:9"
                    elif av in (0, 1):
                        aspect = "4:3"
            except Exception:
                pass
        if not aspect and width > 0 and height > 0:
            try:
                ratio = float(width) / float(height)
                if abs(ratio - (16.0 / 9.0)) < 0.14:
                    aspect = "16:9"
                elif abs(ratio - (4.0 / 3.0)) < 0.11:
                    aspect = "4:3"
                elif 2.18 <= ratio <= 2.52:
                    aspect = "2.35:1"
            except Exception:
                pass

        # Video codec.  Some images return a numeric enum, while others return
        # -2 and expose the value through getInfoString().  Handle both.
        if info is not None and iServiceInformation is not None:
            try:
                video_type_key = getattr(iServiceInformation, "sVideoType", None)
                if video_type_key is not None:
                    raw_vtype = info.getInfo(video_type_key)
                    video_map = {
                        0: "MPEG2", 1: "H.264", 2: "H.263", 3: "VC-1",
                        4: "MPEG4", 5: "VC-1", 6: "MPEG1", 7: "HEVC",
                        8: "VP8", 9: "VP9", 10: "XVID", 11: "AVS",
                        12: "AVS2", 13: "VVC",
                    }
                    try:
                        iv = int(raw_vtype)
                    except Exception:
                        iv = -1
                    video = video_map.get(iv, "")
                    if not video and iv == -2:
                        try:
                            txt = str(info.getInfoString(video_type_key) or "").upper()
                        except Exception:
                            txt = ""
                        if "H265" in txt or "H.265" in txt or "HEVC" in txt:
                            video = "HEVC"
                        elif "H264" in txt or "H.264" in txt or "AVC" in txt:
                            video = "H.264"
                        elif "VP9" in txt:
                            video = "VP9"
                        elif "VP8" in txt:
                            video = "VP8"
                        elif "MPEG2" in txt or "MPEG-2" in txt:
                            video = "MPEG2"
                        elif "MPEG4" in txt or "MPEG-4" in txt:
                            video = "MPEG4"
                        elif "VC1" in txt or "VC-1" in txt:
                            video = "VC-1"
            except Exception:
                pass

        # Current selected audio track.  Keep the real track description as
        # source and normalize only to badge names we actually ship.
        try:
            tracks = service and service.audioTracks()
            if tracks and int(tracks.getNumberOfTracks()) > 0:
                index = int(tracks.getCurrentTrack())
                track = tracks.getTrackInfo(index)
                desc = str(track.getDescription() or "").strip()
                upper = desc.upper().replace("_", " ")
                if "E-AC3" in upper or "EAC3" in upper or "EC-3" in upper or "DD+" in upper or "DOLBY DIGITAL PLUS" in upper:
                    audio_name = "E-AC3"
                elif "TRUEHD" in upper:
                    audio_name = "TRUEHD"
                elif "AC3" in upper or "AC-3" in upper or "DOLBY DIGITAL" in upper:
                    audio_name = "AC3"
                elif "DTS" in upper:
                    audio_name = "DTS"
                elif "AAC" in upper:
                    audio_name = "AAC"
                elif "MP3" in upper or "MPEG LAYER 3" in upper:
                    audio_name = "MP3"
        except Exception:
            pass

        # If Enigma2 has not exposed video metadata yet (common on some
        # service types during startup/after a seek), use only metadata that
        # already arrived with this VOD item.  Never overwrite a concrete
        # service.info() value with a hint.
        try:
            hint_resolution, hint_aspect, hint_video = self._technicalItemHints()
            if not resolution and hint_resolution:
                resolution = hint_resolution
            if not aspect and hint_aspect:
                aspect = hint_aspect
            if not video and hint_video:
                video = hint_video
        except Exception:
            pass

        return resolution, aspect, video, audio_name

    def _setTechnicalBadgePixmap(self, widget_name, filename):
        widget = self[widget_name]
        if not filename:
            try:
                widget.hide()
            except Exception:
                pass
            return
        path = os.path.join(PLUGIN_PATH, "tivimate_infobar", "common", filename)
        if not os.path.exists(path):
            try:
                widget.hide()
            except Exception:
                pass
            return
        try:
            widget.instance.setPixmapFromFile(path)
        except Exception:
            try:
                widget.setPixmapFromFile(path)
            except Exception:
                return
        try:
            widget.show()
        except Exception:
            pass

    def _updateTechnicalBadges(self, width=0, height=0):
        try:
            resolution, aspect, video, audio_name = self._technicalStreamInfo(width, height)
            resolution_files = {
                "2160p": "player_badge_res_2160p_r280.png",
                "1080p": "player_badge_res_1080p_r280.png",
                "720p": "player_badge_res_720p_r280.png",
                "576p": "player_badge_res_576p_r280.png",
                "480p": "player_badge_res_480p_r280.png",
            }
            aspect_files = {
                "16:9": "player_badge_aspect_16_9_r280.png",
                "4:3": "player_badge_aspect_4_3_r280.png",
                "2.35:1": "player_badge_aspect_2_35_1_r280.png",
            }
            video_files = {
                "H.264": "player_badge_video_h264_r280.png",
                "HEVC": "player_badge_video_hevc_r280.png",
                "VP9": "player_badge_video_vp9_r280.png",
                "VP8": "player_badge_video_vp8_r280.png",
                "MPEG2": "player_badge_video_mpeg2_r280.png",
                "MPEG4": "player_badge_video_mpeg4_r280.png",
                "VC-1": "player_badge_video_vc1_r280.png",
                "XVID": "player_badge_video_xvid_r280.png",
                "AVS": "player_badge_video_avs_r280.png",
                "AVS2": "player_badge_video_avs2_r280.png",
            }
            audio_files = {
                "AAC": "player_badge_audio_aac_r280.png",
                "AC3": "player_badge_audio_ac3_r280.png",
                "E-AC3": "player_badge_audio_eac3_r280.png",
                "DTS": "player_badge_audio_dts_r280.png",
                "MP3": "player_badge_audio_mp3_r280.png",
            }

            # During a seek, service.info() can transiently return 0/empty for
            # video geometry and codec.  Do not turn a valid badge off because
            # of that temporary gap; replace it only when a new valid value is
            # reported.
            last = getattr(self, "_tech_badge_values", None)
            if not isinstance(last, dict):
                last = {"resolution": "", "aspect": "", "video": "", "audio": ""}
            if resolution in resolution_files:
                last["resolution"] = resolution
            if aspect in aspect_files:
                last["aspect"] = aspect
            if video in video_files:
                last["video"] = video
            if audio_name in audio_files:
                last["audio"] = audio_name
            self._tech_badge_values = last

            self._setTechnicalBadgePixmap("resolutionBadge", resolution_files.get(last.get("resolution")))
            self._setTechnicalBadgePixmap("aspectBadge", aspect_files.get(last.get("aspect")))
            self._setTechnicalBadgePixmap("videoBadge", video_files.get(last.get("video")))
            self._setTechnicalBadgePixmap("audioBadge", audio_files.get(last.get("audio")))
        except Exception:
            pass
        # Lock reflects HTTPS transport; network icon reflects an IP stream URL.
        try:
            is_secure = str(self.streamurl or "").lower().startswith("https://")
            (self["lockIcon"].show() if is_secure else self["lockIcon"].hide())
        except Exception:
            pass
        try:
            is_network = str(self.streamurl or "").lower().startswith(("http://", "https://"))
            (self["networkIcon"].show() if is_network else self["networkIcon"].hide())
        except Exception:
            pass

    @staticmethod
    def _clock(pts):
        seconds = max(0, int(pts or 0) // PTS)
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return "%d:%02d:%02d" % (hours, minutes, seconds) if hours else "%02d:%02d" % (minutes, seconds)

    def _updateServiceTypeBadge(self):
        try:
            value = str(int(self.servicetype))
            try:
                self["serviceTypeText"].setText(value)
            except Exception:
                pass
            path = os.path.join(PLUGIN_PATH, "tivimate_infobar", "player", "player_service_icon_r483.png")
            if os.path.exists(path):
                self["serviceTypeBadge"].instance.setPixmapFromFile(path)
                self["serviceTypeBadge"].show()
            else:
                self["serviceTypeBadge"].hide()
        except Exception:
            pass

    def _updatePlayerAnalogClock(self):
        # Reuse the existing 1-second playback monitor; no extra timer/hook.
        self._updateServiceTypeBadge()
        try:
            now_tm = time.localtime()
            try:
                self["playerDate"].setText(time.strftime("%d/%m/%Y", now_tm))
            except Exception:
                pass
            minute = int(now_tm.tm_min)
            hour_slot = ((int(now_tm.tm_hour) % 12) * 12 + int(minute / 5)) % 144
            clock_root = os.path.join(PLUGIN_PATH, "skins", "packages", "package_clock_r108")
            if hour_slot != self._player_clock_hour_slot:
                self["playerClockHour"].instance.setPixmapFromFile(os.path.join(clock_root, "h%03d.png" % hour_slot))
                self["playerClockHour"].show()
                self._player_clock_hour_slot = hour_slot
            if minute != self._player_clock_minute:
                self["playerClockMinute"].instance.setPixmapFromFile(os.path.join(clock_root, "m%02d.png" % minute))
                self["playerClockMinute"].show()
                self._player_clock_minute = minute
        except Exception:
            pass


    def _monitorPlayback(self):
        seek, position, duration = self._seekData()
        width, height = self._videoGeometry()
        now = time.time()
        self._updatePlayerAnalogClock()
        self._tech_badge_tick = (int(getattr(self, "_tech_badge_tick", 0)) + 1) % 3
        if self._tech_badge_tick == 1:
            self._updateTechnicalBadges(width, height)

        if position > 0:
            self._last_position = position
        if duration > 0:
            self._last_duration = duration

        # Playback is confirmed by a moving PTS or a real decoded video geometry.
        # Do this before restoring late audio/subtitle tracks so ServiceApp is
        # already rendering the service when an embedded subtitle is enabled.
        if position > 0 or (width > 0 and height > 0):
            if not self._playback_confirmed:
                self._playback_confirmed = True
                self._stall_notice_sent = False
                self._clearNotification()

        # Audio track selection is user-controlled. Do not force English or
        # switch tracks after playback has started.

        # Server/Embedded subtitles are user-controlled. Do not auto-enable a
        # remembered language while the decoder is running.

        if position and position != self._last_pts_seen:
            self._last_pts_seen = position
            self._last_pts_change_at = now
            self._stall_notice_sent = False
        elif self._playback_confirmed and now - self._last_pts_change_at >= STALL_NOTICE_SECONDS and not self._stall_notice_sent:
            self._stall_notice_sent = True
            self._showNotification("Playback stalled - try another Service Type", MessageBox.TYPE_INFO, 5)
        elif not self._playback_confirmed and now - self._service_started_at >= STARTUP_GRACE_SECONDS and not self._stall_notice_sent:
            self._stall_notice_sent = True
            self._showNotification("No video yet on %s - try another Service Type" % self.servicetype, MessageBox.TYPE_INFO, 5)

        # Hidden widgets are still updated for summary/compatibility logic.
        try:
            self["vodPosition"].setText(self._clock(position))
            self["vodDuration"].setText(self._clock(duration))
            value = int(min(1000, max(0, (float(position) / float(duration)) * 1000))) if duration else 0
            self["vodProgress"].setValue(value)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Resume store
    # ------------------------------------------------------------------
    def _resumeDb(self):
        return _read_json(PLAYER_RESUME_FILE)

    def _loadResumeTarget(self):
        # Same bookmark eligibility used by the UltraStalker reference player:
        # ignore only trivial starts (<10s) and bookmarks in the last 10s.
        if not self.ENABLE_RESUME_SUPPORT:
            return 0
        row = self._resumeDb().get(self._identity) or {}
        try:
            position = max(0, int(row.get("position", 0) or 0))
        except Exception:
            position = 0
        try:
            duration = max(0, int(row.get("duration", 0) or 0))
        except Exception:
            duration = 0
        if position < 10 * PTS:
            return 0
        if duration and (position >= duration or max(0, duration - position) <= 10 * PTS):
            return 0
        return position

    def _scheduleResumeProbe(self):
        if self._closing or self._resume_applied or int(self._resume_target or 0) <= 0:
            return
        attempt = max(0, int(self._resume_attempts or 0))
        delay = min(1200, 50 * (2 ** min(attempt, 4)))
        try:
            self._resume_timer.stop()
        except Exception:
            pass
        try:
            self._resume_timer.start(int(delay), True)
        except Exception:
            pass

    def _finishResume(self, available=True):
        self._resume_target = 0
        self._resume_grace_until = 0.0
        self._resume_applied = True
        try:
            self._resume_timer.stop()
        except Exception:
            pass
        if not available:
            self._showNotification("Resume unavailable", MessageBox.TYPE_INFO, 2)

    def _cancelPendingResumeForManualSeek(self):
        if int(self._resume_target or 0) <= 0 or self._resume_applied:
            return
        self._resume_target = 0
        self._resume_grace_until = 0.0
        self._resume_applied = True
        try:
            self._resume_timer.stop()
        except Exception:
            pass

    def _resumeTick(self):
        """UltraStalker V6 resume lifecycle, adapted to the existing TiviMate timer.

        Start playback first, wait for evStart, verify a real seek interface, a
        valid duration and play position, allow at least 0.55s decoder settle,
        issue exactly one absolute seek, then verify it reached the bookmark.
        """
        if not self.ENABLE_RESUME_SUPPORT:
            self._finishResume(True)
            return
        if self._closing or self._resume_applied:
            try:
                self._resume_timer.stop()
            except Exception:
                pass
            return
        target = int(self._resume_target or 0)
        if target <= 0:
            self._finishResume(True)
            return

        # Verification phase after the one and only automatic seek.
        if int(self._resume_seek_count or 0) > 0:
            try:
                service = self.session.nav.getCurrentService()
                seekable = service.seek() if service else None
                pos = seekable.getPlayPosition() if seekable else None
                current = max(0, int(pos[1])) if pos and not pos[0] else 0
            except Exception:
                current = 0
            tolerance = 7 * PTS
            if current and abs(int(current) - target) <= tolerance:
                self._last_position = max(int(getattr(self, "_last_position", 0) or 0), current)
                self._showNotification("Resume %s" % self._clock(current), MessageBox.TYPE_INFO, 2)
                self._finishResume(True)
                return
            self._resume_verify_cycles += 1
            if self._resume_verify_cycles < 7:
                try:
                    self._resume_timer.stop()
                    self._resume_timer.start(350, True)
                except Exception:
                    pass
                return
            # Never issue a second late seek. If the engine ignored the first,
            # fail cleanly instead of overriding later user input.
            self._finishResume(False)
            return

        # Probe phase. ServiceApp/ExtEplayer3 may expose service.seek() at
        # evStart before seekTo() is actually honoured.
        if self._resume_started_at and (time.time() - self._resume_started_at) < 0.55:
            self._resume_attempts += 1
            self._scheduleResumeProbe()
            return
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
        except Exception:
            seekable = None
        if seekable is None:
            self._resume_attempts += 1
            if self._resume_attempts < 14:
                self._scheduleResumeProbe()
            else:
                self._finishResume(False)
            return

        native_probe = getattr(self, "isCurrentlySeekable", None)
        if callable(native_probe):
            try:
                state = native_probe()
                if isinstance(state, (tuple, list)):
                    state = (not state[0]) and (len(state) < 2 or bool(state[1]))
                if not bool(state):
                    self._resume_attempts += 1
                    if self._resume_attempts < 14:
                        self._scheduleResumeProbe()
                    else:
                        self._finishResume(False)
                    return
            except Exception:
                pass

        try:
            length = seekable.getLength()
            position = seekable.getPlayPosition()
            length_ok = bool(length and not length[0] and int(length[1] or 0) > 30 * PTS)
            pos_ok = bool(position and not position[0] and int(position[1] or 0) >= 0)
        except Exception:
            length = None
            length_ok = False
            pos_ok = False
        if not (length_ok and pos_ok):
            self._resume_attempts += 1
            if self._resume_attempts < 14:
                self._scheduleResumeProbe()
            else:
                self._finishResume(False)
            return

        try:
            effective_target = min(target, max(0, int(length[1]) - 10 * PTS))
            seekable.seekTo(int(effective_target))
            self._resume_target = int(effective_target)
            self._resume_seek_count = 1
            self._resume_verify_cycles = 0
            self._last_position = max(int(getattr(self, "_last_position", 0) or 0), int(effective_target))
            self._resume_timer.stop()
            self._resume_timer.start(450, True)
        except Exception:
            self._resume_attempts += 1
            if self._resume_seek_count == 0 and self._resume_attempts < 14:
                self._scheduleResumeProbe()
            else:
                self._finishResume(False)

    def _checkpoint(self):
        if self.ENABLE_RESUME_SUPPORT:
            self._saveResume()

    def _saveContinueWatching(self):
        """Save Continue Watching history without enabling automatic Resume.

        This deliberately uses the existing Continue Watching database (resume.json)
        and never feeds a seek target back into playback.
        """
        _seek, position, duration = self._seekData()
        # ServiceApp can briefly report the pre-seek/zero PTS when EXIT follows a
        # large forward seek.  Keep the newest valid sample collected by the
        # existing playback monitor and never let that transient read erase it.
        last_position = int(getattr(self, "_last_position", 0) or 0)
        if position > 0:
            position = max(int(position), last_position)
            self._last_position = position
        else:
            position = last_position
        last_duration = int(getattr(self, "_last_duration", 0) or 0)
        if duration > 0:
            duration = max(int(duration), last_duration)
            self._last_duration = duration
        else:
            duration = last_duration

        # Do not create accidental cards from a title that was only opened briefly.
        if not position or position < RESUME_MIN_SECONDS * PTS:
            return

        db = _read_json(CONTINUE_WATCHING_FILE)
        key = str(self._identity or "")
        if not key:
            return

        # Finished titles are removed from Continue Watching.
        if duration and position >= int(duration * COMPLETE_RATIO):
            if key in db:
                db.pop(key, None)
                _write_json(CONTINUE_WATCHING_FILE, db)
            return

        item = dict(self.item or {})
        title = _clean_title(item.get("name") or item.get("title") or item.get("stream_name") or "")
        source_key = str(item.get("_source_key") or "")
        source_type = str(item.get("_source_type") or "xtream")
        try:
            service_type = int(self.servicetype or 4097)
        except Exception:
            service_type = 4097

        is_series = bool(
            item.get("series_name") or item.get("series_id") or
            item.get("episode_num") not in (None, "") or
            item.get("episode_number") not in (None, "") or
            item.get("_episode_items")
        )
        row = {
            "position": int(position),
            "length": int(duration or 0),
            "duration": int(duration or 0),
            "updated": int(time.time()),
            "title": title,
            "kind": "episode" if is_series else "movie",
            "source_key": source_key,
            "source_type": source_type,
            "service_type": service_type,
            "streamurl": str(self.streamurl or ""),
            "item": item,
        }
        if is_series:
            row["series_title"] = _clean_title(item.get("series_name") or item.get("_tmdb_title") or title)
            row["series_id"] = item.get("series_id") or ""
            row["season"] = item.get("season") or item.get("season_number") or ""
            row["episode"] = item.get("episode_num") or item.get("episode_number") or item.get("episode") or ""

        previous = db.get(key) if isinstance(db.get(key), dict) else {}
        servers = dict(previous.get("servers") or {})
        if source_key and self.streamurl:
            servers[source_key] = {
                "source_key": source_key,
                "source_type": source_type,
                "streamurl": str(self.streamurl),
                "service_type": service_type,
                "item": item,
            }
        if servers:
            row["servers"] = servers

        db[key] = row
        _write_json(CONTINUE_WATCHING_FILE, db)

    def _saveResume(self):
        # Keep call sites compatible, but never read/write resume state while disabled.
        if not self.ENABLE_RESUME_SUPPORT:
            return
        _seek, position, duration = self._seekData()
        if position > 0:
            self._last_position = position
        else:
            position = self._last_position
        if duration > 0:
            self._last_duration = duration
        else:
            duration = self._last_duration

        db = self._resumeDb()
        # Never erase a good resume merely because startup/decoder currently has no PTS.
        if not position or position < RESUME_MIN_SECONDS * PTS:
            return
        if duration and position >= int(duration * COMPLETE_RATIO):
            if self._identity in db:
                db.pop(self._identity, None)
                _write_json(PLAYER_RESUME_FILE, db)
            return
        db[self._identity] = {
            "position": int(position),
            "duration": int(duration or 0),
            "updated": int(time.time()),
            "title": _clean_title(self.item.get("name") or self.item.get("title") or ""),
        }
        _write_json(PLAYER_RESUME_FILE, db)

    def _clearResume(self):
        if not self.ENABLE_RESUME_SUPPORT:
            return
        db = self._resumeDb()
        if self._identity in db:
            db.pop(self._identity, None)
            _write_json(PLAYER_RESUME_FILE, db)

    # ------------------------------------------------------------------
    # Audio / subtitle preferences
    # ------------------------------------------------------------------
    def _prefsDb(self):
        return _read_json(PLAYER_PREFS_FILE)

    def _savePreferences(self):
        db = self._prefsDb()
        row = dict(db.get(self._identity) or {})
        # Audio selection is intentionally manual. Do not persist or restore
        # an audio track here, because track ordering can differ per service
        # and restoring it can move the UI selection away from the real audio.
        row.pop("audio_index", None)
        row.pop("audio_lang", None)
        row.pop("audio_desc", None)
        row["subtitle_delay_ms"] = int(self._subtitle_session_delay_ms or 0)
        if self._external_subtitle_path:
            row["external_subtitle_path"] = str(self._external_subtitle_path)
        row["last_service_type"] = int(self.servicetype)
        db[self._identity] = row
        _write_json(PLAYER_PREFS_FILE, db)

    def _restorePreferences(self):
        row = self._prefsDb().get(self._identity) or {}
        # Audio tracks are user-controlled. Never change the selected audio
        # track from delayed preference restore.
        try:
            self._subtitle_session_delay_ms = int(row.get("subtitle_delay_ms", 0) or 0)
        except Exception:
            self._subtitle_session_delay_ms = 0

        # Server / Embedded subtitle selection is manual.

        # Restore the last downloaded TiviMate subtitle for this media item only.
        if not self._subtitle_restore_attempted:
            self._subtitle_restore_attempted = True
            subtitle_path = str(row.get("external_subtitle_path") or "")
            if subtitle_path and os.path.exists(subtitle_path):
                try:
                    from .subtitle_picker_bridge import _controller
                    controller = _controller(self)
                    if controller.loadSubs(subtitle_path, newService=False):
                        controller.resumeSubs()
                        # Keep restored subtitles on the same active controller
                        # references used by RED and the fine-sync keys.
                        self._external_subs = controller
                        self._subssupport = controller
                        self._tivimate_subtitles = controller
                        self._tivimate_subtitle_controller = controller
                        self._external_subtitle_path = subtitle_path
                        self._external_subtitle_owner = "subssupport"
                        try:
                            controller._tivimateDelayChangedCB = self._tivimateSubtitleDelayChanged
                        except Exception:
                            pass
                        try:
                            setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
                            if callable(setter) and self._subtitle_session_delay_ms:
                                setter(self._subtitle_session_delay_ms)
                        except Exception:
                            pass
                        try:
                            controller.playAfterSeek()
                        except Exception:
                            pass
                except Exception:
                    pass

    def audioSelection(self):
        try:
            return InfoBarAudioSelection.audioSelection(self)
        except Exception:
            return None

    def openSubtitleSelection(self):
        try:
            return self.subtitleSelection()
        except Exception:
            return None

    def _syncExternalSubtitleAfterSeek(self):
        """Resync the active external subtitle engine after a VOD seek.

        TiviMatePlayer uses InfoBarSeek directly rather than inheriting the
        subtitle controller mixin, so normal seek actions otherwise bypass
        TiviMateSubtitleSupport.playAfterSeek().
        """
        controller = (getattr(self, "_external_subs", None) or
                      getattr(self, "_tivimate_subtitles", None) or
                      getattr(self, "_subssupport", None) or
                      getattr(self, "_tivimate_subtitle_controller", None))
        if controller is None:
            return
        try:
            sync = getattr(controller, "playAfterSeek", None)
            if callable(sync):
                sync()
        except Exception as exc:
            print("[TiviMateE2] subtitle resync after seek failed: %s" % exc)

    def doSeekRelative(self, pts):
        self._cancelPendingResumeForManualSeek()
        result = InfoBarSeek.doSeekRelative(self, pts)
        self._syncExternalSubtitleAfterSeek()
        return result

    def doSeek(self, pts):
        self._cancelPendingResumeForManualSeek()
        result = InfoBarSeek.doSeek(self, pts)
        self._syncExternalSubtitleAfterSeek()
        return result

    def enableSubtitle(self, subtitle):
        try:
            if getattr(self, "_unified_embedded_ready", False):
                from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import TiviMateSubtitleSupportEmbedded
                result = TiviMateSubtitleSupportEmbedded.enableSubtitle(self, subtitle)
            else:
                result = InfoBarSubtitleSupport.enableSubtitle(self, subtitle)
            return result
        except Exception as exc:
            print("[TiviMateE2] unified native subtitle enable failed: %s" % exc)
            try:
                result = InfoBarSubtitleSupport.enableSubtitle(self, subtitle)
                return result
            except Exception:
                return None

    # ------------------------------------------------------------------
    # TiviMate subtitle feature layer
    # ------------------------------------------------------------------
    def openSubsSupport(self):
        try:
            from .subtitle_picker_bridge import open_tivimate_subtitle_search
            title = _clean_title(self.item.get("name") or self.item.get("title") or self.item.get("stream_name") or "")
            if not open_tivimate_subtitle_search(self, title=title):
                self._showNotification("Could not open TiviMate Subtitles", MessageBox.TYPE_ERROR, 5)
        except Exception as exc:
            self._showNotification("Subtitle error: %s" % exc, MessageBox.TYPE_ERROR, 5)

    def _subtitlePickerSource(self):
        """Build the large RED picker from the subtitle actually loaded in VOD."""
        cues = []
        path = str(getattr(self, "_external_subtitle_path", "") or "")
        if path and os.path.isfile(path):
            try:
                from .srt_overlay import parse_srt_file
                cues = list(parse_srt_file(path) or [])
            except Exception:
                cues = []

        rows = []
        normalized = []
        for index, cue in enumerate(cues):
            try:
                start_ms, end_ms, text = cue
                start_ms = int(float(start_ms))
                end_ms = max(start_ms + 1, int(float(end_ms)))
                text = str(text or "")
                normalized.append((start_ms, end_ms, text))
                rows.append({
                    "index": index,
                    "text": text,
                    "start": float(start_ms) / 1000.0,
                    "end": float(end_ms) / 1000.0,
                })
            except Exception:
                continue
        if rows:
            return normalized, rows

        # Fallback to the same active subtitle controller/engine; no parallel
        # controller is created and no new subtitle path is loaded here.
        controllers = (
            getattr(self, "_external_subs", None),
            getattr(self, "_tivimate_subtitles", None),
            getattr(self, "_subssupport", None),
            getattr(self, "_tivimate_subtitle_controller", None),
        )
        seen = set()
        for controller in controllers:
            if controller is None or id(controller) in seen:
                continue
            seen.add(id(controller))
            engine = getattr(controller, "engine", None)
            getter = getattr(engine, "getSubtitlesList", None)
            if not callable(getter):
                continue
            try:
                engine_rows = list(getter() or [])
            except Exception:
                continue
            normalized = []
            rows = []
            for index, row in enumerate(engine_rows):
                try:
                    start_sec = float(row.get("start", 0) or 0)
                    end_sec = float(row.get("end", start_sec) or start_sec)
                    text = str(row.get("text", "") or "")
                    start_ms = int(start_sec * 1000.0)
                    end_ms = max(start_ms + 1, int(end_sec * 1000.0))
                    normalized.append((start_ms, end_ms, text))
                    rows.append({
                        "index": index,
                        "text": text,
                        "start": start_sec,
                        "end": end_sec,
                    })
                except Exception:
                    continue
            if rows:
                return normalized, rows
        return [], []

    def openSubtitleEditor(self):
        """RED: open the large subtitle-line screen at the current movie time."""
        cues, subtitle_list = self._subtitlePickerSource()
        if not subtitle_list:
            self._showNotification("No readable subtitle is loaded", MessageBox.TYPE_INFO, 3)
            return
        self._subtitle_picker_cues = cues

        current_index = 0
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek and seek.getPlayPosition()
            if position and not position[0]:
                playback_ms = max(0, int(position[1] or 0) // 90)
                delay_ms = int(getattr(self, "_subtitle_session_delay_ms", 0) or 0)
                subtitle_time_ms = max(0, playback_ms - delay_ms)
                current_index = len(cues) - 1
                for cue_index, cue in enumerate(cues):
                    cue_start_ms = int(cue[0])
                    if cue_start_ms >= subtitle_time_ms:
                        current_index = cue_index
                        if cue_index > 0:
                            prev_ms = int(cues[cue_index - 1][0])
                            if abs(subtitle_time_ms - prev_ms) <= abs(cue_start_ms - subtitle_time_ms):
                                current_index = cue_index - 1
                        break
        except Exception:
            current_index = 0

        current_index = max(0, min(current_index, len(subtitle_list) - 1))
        try:
            from Plugins.Extensions.TiviMateE2.subtitle_picker_original import SubtitlePicker
            self.session.openWithCallback(
                self._subtitlePickerSelected, SubtitlePicker, subtitle_list, current_index
            )
        except Exception as exc:
            print("[TiviMateE2] subtitle picker open failed: %s" % exc)
            self._showNotification("Could not open Subtitle Picker", MessageBox.TYPE_ERROR, 4)

    def _subtitlePickerSelected(self, selected=None):
        if selected is None:
            return
        fine_ms = 0
        if isinstance(selected, (tuple, list)) and len(selected) >= 2:
            try:
                fine_ms = int(selected[1] or 0)
            except Exception:
                fine_ms = 0
            selected = selected[0]
        try:
            index = int(selected)
        except Exception:
            return
        cues = list(getattr(self, "_subtitle_picker_cues", None) or [])
        if index < 0 or index >= len(cues):
            return
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek and seek.getPlayPosition()
            if not position or position[0]:
                return
            playback_ms = max(0, int(position[1] or 0) // 90)
            cue_start_ms = int(cues[index][0])
            delay_ms = playback_ms - cue_start_ms + fine_ms
            delay_ms = max(-120000, min(120000, delay_ms))
            controller = (getattr(self, "_external_subs", None) or
                          getattr(self, "_tivimate_subtitles", None) or
                          getattr(self, "_subssupport", None) or
                          getattr(self, "_tivimate_subtitle_controller", None))
            if controller is None:
                return
            setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
            if callable(setter):
                setter(delay_ms)
            self._subtitle_session_delay_ms = delay_ms
            sync = getattr(controller, "playAfterSeek", None)
            if callable(sync):
                sync()
            self._savePreferences()
            self._showNotification("Subtitle synchronized: %+.1f sec" % (delay_ms / 1000.0), MessageBox.TYPE_INFO, 2)
        except Exception:
            pass

    def _stepSubtitleDialogue(self, direction):
        """VOD: align playback to the previous/next cue using one fixed delay."""
        controller = (getattr(self, "_external_subs", None) or
                      getattr(self, "_tivimate_subtitles", None) or
                      getattr(self, "_tivimate_subtitle_controller", None) or
                      getattr(self, "_subssupport", None))
        if controller is None:
            return
        try:
            cues, _rows = self._subtitlePickerSource()
            if not cues:
                return

            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek and seek.getPlayPosition()
            if not position or position[0]:
                return
            playback_ms = max(0, int(position[1] or 0) // 90)

            # Convert the current movie position to subtitle-timeline time using
            # the one currently active delay.  This avoids relying on the
            # subtitle engine's moving internal position/timers when stepping.
            current_delay_ms = int(getattr(self, "_subtitle_session_delay_ms", 0) or 0)
            getter = getattr(controller, "getSubsDelay", None)
            if callable(getter):
                try:
                    active_delay = getter()
                    if active_delay is not None:
                        current_delay_ms = int(round(float(active_delay)))
                except Exception:
                    pass
            subtitle_time_ms = playback_ms - current_delay_ms

            # Find the cue that corresponds most closely to the current
            # subtitle time, then select exactly one previous/next cue.
            current_index = 0
            for idx, cue in enumerate(cues):
                cue_start = int(cue[0])
                cue_end = int(cue[1]) if len(cue) > 1 else cue_start
                if cue_start <= subtitle_time_ms <= cue_end:
                    current_index = idx
                    break
                if cue_start <= subtitle_time_ms:
                    current_index = idx
                elif cue_start > subtitle_time_ms:
                    if idx > 0:
                        prev_start = int(cues[idx - 1][0])
                        if abs(cue_start - subtitle_time_ms) < abs(subtitle_time_ms - prev_start):
                            current_index = idx
                    break

            target_index = current_index + (-1 if int(direction) < 0 else 1)
            target_index = max(0, min(target_index, len(cues) - 1))
            if target_index == current_index:
                return

            target_start_ms = int(cues[target_index][0])
            new_delay_ms = playback_ms - target_start_ms
            new_delay_ms = max(-120000, min(120000, new_delay_ms))

            setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
            if not callable(setter):
                return

            # Replace the previous value once.  Do not subscribe a callback and
            # do not call playAfterSeek here: both can cause the same adjustment
            # to be recalculated later.  The subtitle engine resumes from this
            # single absolute delay and the movie preference stores that value.
            setter(new_delay_ms)
            self._subtitle_session_delay_ms = new_delay_ms
            self._savePreferences()
        except Exception as exc:
            print("[TiviMateE2] VOD fixed subtitle dialogue step failed: %s" % exc)

    def subtitleFineMinus(self):
        self._stepSubtitleDialogue(-1)

    def subtitleFinePlus(self):
        self._stepSubtitleDialogue(1)

    def _clearSRTOverlay(self):
        try:
            self["srtOverlay"].setText("")
            self["srtOverlay"].hide()
        except Exception:
            pass

    def _tivimateSubtitleDelayChanged(self, delay_ms):
        try:
            value = int(delay_ms)
        except Exception:
            return
        if abs(value) <= 120000:
            self._subtitle_session_delay_ms = value
            self._savePreferences()

    def _clearExternalSubtitle(self):
        seen = set()
        for obj in (self._external_subs, self._tivimate_subtitles, self._tivimate_subtitle_controller):
            if obj is None or id(obj) in seen:
                continue
            seen.add(id(obj))
            for method in ("pauseSubs", "hideSubs", "resetSubs"):
                try:
                    func = getattr(obj, method, None)
                    if callable(func):
                        func()
                except Exception:
                    pass
            # TiviMateSubtitleSupport is owned by the player bridge rather than
            # by the Screen itself, so Enigma2 will not call exitSubs() for us.
            # Finish the controller lifecycle explicitly before dropping the
            # references; this releases the SubsEngine, renderer dialog and
            # subtitle timers left behind by the previous movie/episode.
            try:
                func = getattr(obj, "exitSubs", None)
                if callable(func):
                    func()
            except Exception as exc:
                print("[TiviMateE2] external subtitle exit cleanup failed: %s" % exc)
        self._external_subs = None
        self._tivimate_subtitles = None
        self._tivimate_subtitle_controller = None
        self._external_subtitle_path = ""
        self._external_subtitle_owner = ""
        self._clearSRTOverlay()

    # ------------------------------------------------------------------
    # Service type handling
    # ------------------------------------------------------------------
    def cycleStreamTypeQuick(self):
        """Cycle Service Type directly from the dedicated TV key without opening a menu."""
        available = [int(item[0]) for item in _available_stream_types()]
        if not available:
            return
        try:
            current = int(self.servicetype)
        except Exception:
            current = available[0]
        try:
            index = available.index(current)
            target = available[(index + 1) % len(available)]
        except ValueError:
            target = available[0]
        # Quick TV-key cycling is session-only: do not persist it as the player default.
        self._switchPlaybackEngine(target, persist_choice=False)

    def toggleStreamType(self):
        choices = []
        for service_type, name in _available_stream_types():
            choices.append(("%s  •  %s" % (service_type, name), service_type))
        self.lockShow()
        self.session.openWithCallback(self._engineSelected, ChoiceBox, title="Service Type", list=choices)

    def _engineSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        # A deliberate selection from the Service Type menu is the persistent/manual choice.
        self._switchPlaybackEngine(selected[1], persist_choice=True)

    def _switchPlaybackEngine(self, value, persist_choice=False):
        try:
            value = int(value)
        except Exception:
            return
        if value not in [item[0] for item in _available_stream_types()] or value == self.servicetype:
            return
        self._saveResume()
        self._savePreferences()
        self._clearExternalSubtitle()
        self.servicetype = value
        if persist_choice:
            _save_player_type(value)
        self.playStream()

    # ------------------------------------------------------------------
    # Player menu
    # ------------------------------------------------------------------
    def openPlayerMenu(self):
        choices = [
            ("TiviMate Subtitles", "subs"),
            ("Server / Embedded Subtitles", "native_subs"),
            ("Audio Tracks", "audio"),
            ("Service Type", "engine"),
            ("Subtitle Font / Style", "subtitle_style"),
            ("Subtitle Delay", "subtitle_delay"),
            ("Downloads Manager", "downloads"),
            ("Record / Download Current", "record"),
            ("Stop Recording", "stop_record"),
            ("Aspect Ratio", "aspect"),
        ]
        self.lockShow()
        self.session.openWithCallback(self._menuSelected, ChoiceBox, title="TiviMate Player", list=choices)

    def _menuSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        action = selected[1]
        if action == "subs":
            return self.openSubsSupport()
        if action == "native_subs":
            return self.openSubtitleSelection()
        if action == "audio":
            return self.audioSelection()
        if action == "engine":
            return self.toggleStreamType()
        if action == "subtitle_style":
            return self.openSubtitleStyleSettings()
        if action == "subtitle_delay":
            return self.openSubtitleDelay()
        if action == "downloads":
            return self.openDownloadsManager()
        if action == "record":
            return self.startRecordingCurrent()
        if action == "stop_record":
            return self.stopRecordingCurrent()
        if action == "aspect":
            return self.nextAspectRatio()

    def openSubtitleStyleSettings(self):
        try:
            from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import initTiviMateSettings, TiviMateSetupExternal
            settings = initTiviMateSettings()
            self.session.openWithCallback(self._unifiedSubtitleStyleSaved, TiviMateSetupExternal, settings.external)
        except Exception as exc:
            self._showNotification("Subtitle style unavailable: %s" % exc, MessageBox.TYPE_ERROR, 5)

    def _unifiedSubtitleStyleSaved(self, *args):
        """Apply one CC Font profile to external + server/embedded subtitles."""
        try:
            from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import initTiviMateSettings
            settings = initTiviMateSettings()
            ext = settings.external
            emb = settings.embedded

            # Font face (regular / italic / bold), size and vertical position.
            for style in ("regular", "italic", "bold"):
                try:
                    getattr(emb.font, style).type.value = getattr(ext.font, style).type.value
                    getattr(emb.font, style).type.save()
                except Exception:
                    pass
            try:
                emb.font.size.value = ext.font.size.value
                emb.font.size.save()
            except Exception:
                pass
            try:
                emb.position.value = ext.position.value
                emb.position.save()
            except Exception:
                pass

            # Native/embedded renderer has one foreground + border/shadow set;
            # use the regular CC color as its common default.
            try:
                emb.color.value = ext.font.regular.color.value
                emb.color.save()
            except Exception:
                pass
            for name in ("color", "size", "xOffset", "yOffset"):
                try:
                    src = getattr(ext.shadow, name)
                    dst = getattr(emb.shadow, name)
                    dst.value = src.value
                    dst.save()
                except Exception:
                    pass

            # Keep Enigma2's own native size preference aligned as a fallback
            # on images where the custom embedded renderer is unavailable.
            try:
                native_size = getattr(getattr(config, "subtitles", None), "subtitle_fontsize", None)
                if native_size is not None:
                    native_size.value = int(ext.font.size.value)
                    native_size.save()
            except Exception:
                pass
            try:
                configfile.save()
            except Exception:
                pass

            # Repaint the currently loaded external subtitle immediately.
            seen = set()
            for obj in (getattr(self, "_external_subs", None),
                        getattr(self, "_tivimate_subtitles", None),
                        getattr(self, "_tivimate_subtitle_controller", None)):
                if obj is None or id(obj) in seen:
                    continue
                seen.add(id(obj))
                try:
                    fn = getattr(obj, "reloadSubtitleStyle", None)
                    if callable(fn):
                        fn()
                except Exception:
                    pass

            # Rebuild/repaint active Server / Embedded subtitle using the same
            # profile, including the selected font face.
            if getattr(self, "_unified_embedded_ready", False):
                try:
                    self.resetEmbeddedSubs(True)
                    self.restartSubtitle()
                except Exception as exc:
                    print("[TiviMateE2] embedded CC style reload failed: %s" % exc)
        except Exception as exc:
            print("[TiviMateE2] unified CC style save failed: %s" % exc)

    def openSubtitleDelay(self):
        current = int(self._subtitle_session_delay_ms or 0)
        values = []
        for delay in range(-10000, 10001, 500):
            prefix = "✓ " if delay == current else ""
            values.append(("%s%+.1f sec" % (prefix, delay / 1000.0), delay))
        self.lockShow()
        self.session.openWithCallback(self._subtitleDelaySelected, ChoiceBox, title="Subtitle Delay", list=values)

    def _subtitleDelaySelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        try:
            self._subtitle_session_delay_ms = int(selected[1])
        except Exception:
            return
        controller = self._external_subs or self._tivimate_subtitles or self._tivimate_subtitle_controller
        if controller is not None:
            try:
                func = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
                if callable(func):
                    func(self._subtitle_session_delay_ms)
            except Exception:
                pass
        self._savePreferences()
        self._showNotification("Subtitle delay %+.1f sec" % (self._subtitle_session_delay_ms / 1000.0), MessageBox.TYPE_INFO, 3)

    def openDownloadsManager(self):
        try:
            from .download_manager import DownloadsManagerScreen
            self.session.open(DownloadsManagerScreen)
        except Exception as exc:
            self._showNotification("Downloads unavailable: %s" % exc, MessageBox.TYPE_ERROR, 5)

    # ------------------------------------------------------------------
    # Recording / display
    # ------------------------------------------------------------------
    def startRecordingCurrent(self):
        if self._record_process is not None:
            self._showNotification("Recording already running", MessageBox.TYPE_INFO, 3)
            return
        folder = "/media/hdd/movie"
        if not os.path.isdir(folder):
            try:
                os.makedirs(folder)
            except Exception:
                self._showNotification("HDD movie folder unavailable", MessageBox.TYPE_ERROR, 5)
                return
        title = re.sub(r"[^A-Za-z0-9._ -]+", "_", _clean_title(self.item.get("name") or self.item.get("title") or "TiviMate"))[:100]
        extension = os.path.splitext(self.streamurl.split("?", 1)[0])[1].lower()
        if extension not in (".ts", ".mp4", ".mkv", ".avi", ".mov"):
            extension = ".ts"
        output = os.path.join(folder, "%s-%s%s" % (title, time.strftime("%Y%m%d-%H%M%S"), extension))
        process = eConsoleAppContainer()
        self._record_process = process
        self._record_path = output
        if os.path.exists("/usr/bin/ffmpeg"):
            command = "/usr/bin/ffmpeg -y -loglevel error -i %s -c copy %s" % (repr(self.streamurl), repr(output))
        else:
            command = "/usr/bin/wget -c -O %s %s" % (repr(output), repr(self.streamurl))
        try:
            process.execute("/bin/sh", "sh", "-c", command)
            self._showNotification("Recording started", MessageBox.TYPE_INFO, 4)
        except Exception as exc:
            self._record_process = None
            self._showNotification("Recording failed: %s" % exc, MessageBox.TYPE_ERROR, 5)

    def stopRecordingCurrent(self):
        if self._record_process is None:
            self._showNotification("No recording running", MessageBox.TYPE_INFO, 3)
            return
        try:
            self._record_process.sendCtrlC()
        except Exception:
            try:
                self._record_process.kill()
            except Exception:
                pass
        self._record_process = None
        self._showNotification("Recording stopped", MessageBox.TYPE_INFO, 3)

    def nextAspectRatio(self, *args):
        self.ar_id_player += 1
        if self.ar_id_player > 6:
            self.ar_id_player = 0
        try:
            if eAVSwitch is not None:
                eAVSwitch.getInstance().setAspectRatio(self.ar_id_player)
            message = ASPECT_RATIOS.get(self.ar_id_player, "Auto")
        except Exception:
            message = "Aspect-ratio change failed"
        try:
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=1)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Episodes
    # ------------------------------------------------------------------
    def _episodeUrl(self, episode):
        source = self._episode_source
        if not source:
            return str(episode.get("url") or episode.get("stream_url") or "")
        try:
            if source.get("type") == "stalker":
                from .core import StalkerClient
                return StalkerClient(source).stream_url(episode, "series")
            from .core import XtreamClient
            return XtreamClient(source).episode_url(episode)
        except Exception:
            return str(episode.get("url") or episode.get("stream_url") or "")

    def _playEpisodeIndex(self, index):
        if index < 0 or index >= len(self._episode_items):
            return
        self._saveContinueWatching()
        self._saveResume()
        self._savePreferences()
        self._clearExternalSubtitle()
        episode = dict(self._episode_items[index] or {})
        url = self._episodeUrl(episode)
        if not url:
            self._showNotification("Episode URL unavailable", MessageBox.TYPE_ERROR, 4)
            return
        for key in ("series_name", "series_id", "_source_key", "_source_type", "_episode_items", "_episode_source"):
            if key in self.item and key not in episode:
                episode[key] = self.item[key]
        episode["_episode_items"] = list(self._episode_items)
        episode["_episode_index"] = index
        episode["_episode_source"] = dict(self._episode_source)
        self.item = episode
        self._episode_index = index
        self.streamurl = str(url)
        self._identity = _media_identity(self.item)
        self["titleLabel"].setText(_clean_title(episode.get("name") or episode.get("title") or episode.get("series_name") or "Episode"))
        self.playStream()

    def nextEpisode(self):
        if self._episode_items:
            self._playEpisodeIndex(self._episode_index + 1)

    def prevEpisode(self):
        if self._episode_items:
            self._playEpisodeIndex(self._episode_index - 1)

    # ------------------------------------------------------------------
    # Exit / cleanup
    # ------------------------------------------------------------------
    def _stopTimers(self):
        for timer in (
            getattr(self, "_monitor_timer", None),
            getattr(self, "_checkpoint_timer", None),
            getattr(self, "_resume_timer", None),
            getattr(self, "_prefs_timer", None),
            getattr(self, "_notification_timer", None),
            getattr(self, "_hud_timer", None),
        ):
            try:
                if timer:
                    timer.stop()
            except Exception:
                pass

    def _restoreOriginalService(self):
        if self._restored_original_service:
            return
        self._restored_original_service = True
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        if self.original_service:
            try:
                self.session.nav.playService(self.original_service)
            except Exception:
                pass

    def back(self):
        if self._closing:
            return
        self._closing = True
        self._saveContinueWatching()
        self._saveResume()
        self._savePreferences()
        self._clearExternalSubtitle()
        self._stopTimers()
        self._restoreOriginalService()
        try:
            self.close()
        except Exception:
            pass

    def _cleanup(self):
        if not self._closing:
            try:
                self._saveContinueWatching()
            except Exception:
                pass
        self._stopTimers()
        try:
            self._clearExternalSubtitle()
        except Exception:
            pass
        # If Enigma closed the screen externally, still restore the service once.
        if not self._restored_original_service:
            self._restoreOriginalService()


TiviMatePlayer.skin = scale_skin(TiviMatePlayer.skin)
