# -*- coding: utf-8 -*-
"""TiviMateE2 player source loader.

The player implementation is stored as ordered source fragments in
_player_parts/.  They are concatenated and compiled as one module so the
public API, class layout, globals and runtime behavior stay identical to the
original single-file implementation.
"""
import os as _player_loader_os

_PLAYER_PARTS = (
    "01_runtime_helpers.part",
    "02_infobar_subdl.part",
    "03_player_init_server_subtitles.part",
    "04_lifecycle_playback_resume.part",
    "05_subtitles_audio.part",
    "06_episodes_menu_recording_engine.part",
    "07_cover_cleanup.part",
)


def _load_player_source():
    _base = _player_loader_os.path.join(
        _player_loader_os.path.dirname(__file__), "_player_parts"
    )
    _chunks = []
    for _name in _PLAYER_PARTS:
        _path = _player_loader_os.path.join(_base, _name)
        with open(_path, "rb") as _handle:
            _chunks.append(_handle.read())
    _source = b"".join(_chunks)
    _code = compile(_source, __file__, "exec")
    exec(_code, globals(), globals())


_load_player_source()

# Loader-only names are private and are not part of the player API.
del _load_player_source
del _PLAYER_PARTS
del _player_loader_os
