# -*- coding: utf-8 -*-
from __future__ import absolute_import

import json
import os
import tempfile
import threading

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigPassword, ConfigSelection, ConfigText, getConfigListEntry
from Components.Pixmap import MultiPixmap, Pixmap
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
try:
    from Components.Sources.StaticText import StaticText
except Exception:
    from Components.Sources.Source import Source
    class StaticText(Source):
        def __init__(self, text=""):
            Source.__init__(self)
            self.text = text
        def setText(self, text):
            self.text = text
            self.changed((self.CHANGED_ALL,))

from enigma import eTimer, eServiceReference, ePicLoad, iPlayableService
from Screens.ChoiceBox import ChoiceBox
from Screens.InfoBarGenerics import (
    InfoBarSeek, InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarSummarySupport,
    InfoBarMoviePlayerSummarySupport, InfoBarNotifications
)
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard

try:
    from Components.PluginComponent import plugins
    from Plugins.Plugin import PluginDescriptor
except Exception:
    plugins = None
    PluginDescriptor = None

try:
    from twisted.internet import reactor
except Exception:
    reactor = None

from .display_scale import scale_skin, scale_size
from .subdl_client import (
    SubDLClient, SubDLError, load_settings as load_subdl_settings,
    save_settings as save_subdl_settings, LANGUAGE_CHOICES as SUBDL_LANGUAGE_CHOICES,
    KIND_CHOICES as SUBDL_KIND_CHOICES
)

try:
    from twisted.web.client import downloadPage
except Exception:
    downloadPage = None

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
PLAYER_CONFIG = "/etc/enigma2/tivimatee2_player.json"
SUBDL_IMPORT_FILE = "/tmp/key.txt"
DEFAULT_COVER = os.path.join(PLUGIN_PATH, "tivimate_infobar", "common", "cover.png")


def _read_import_key(path):
    """Read exactly one non-empty API key from a temporary local file."""
    if not os.path.isfile(path):
        raise IOError("missing")
    with open(path, "rb") as handle:
        raw = handle.read(1025)
    if len(raw) > 1024:
        raise ValueError("too_long")
    try:
        text = raw.decode("utf-8", "ignore")
    except Exception:
        text = str(raw)
    lines = [line.strip() for line in text.replace("\\ufeff", "").splitlines() if line.strip()]
    if len(lines) != 1:
        raise ValueError("invalid_content")
    return lines[0]


def _read_subdl_import_key():
    return _read_import_key(SUBDL_IMPORT_FILE)


ASSET = os.path.join(PLUGIN_PATH, "tivimate_infobar", "common")


def _available_stream_types():
    """Return only usable playback backends exposed by the receiver image.

    ServiceApp images do not always expose their backend executables under the
    same filename, so detecting the plugin itself is essential for VOD files
    that play audio without a picture through the stock GStreamer type.
    """
    result = [(4097, "GStreamer 4097 (default)")]
    serviceapp = any(os.path.isdir(path) for path in (
        "/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp",
        "/usr/lib/enigma2/python/Plugins/Extensions/ServiceApp",
    ))
    if serviceapp or os.path.exists("/usr/bin/gstplayer"):
        result.append((5001, "GstPlayer 5001"))
    if serviceapp or os.path.exists("/usr/bin/exteplayer3"):
        result.append((5002, "ExtePlayer3 5002"))
    if serviceapp or os.path.exists("/usr/bin/ffmpeg"):
        result.append((8193, "ServiceApp/FFmpeg 8193"))
    return result


def _load_player_type():
    available = [x[0] for x in _available_stream_types()]
    try:
        with open(PLAYER_CONFIG, "r") as handle:
            value = int(json.load(handle).get("service_type", 4097))
            if value in available:
                return value
    except Exception:
        pass
    return available[0] if available else 4097


def _save_player_type(value):
    try:
        parent = os.path.dirname(PLAYER_CONFIG)
        if not os.path.isdir(parent):
            os.makedirs(parent)
        with open(PLAYER_CONFIG, "w") as handle:
            json.dump({"service_type": int(value)}, handle)
    except Exception:
        pass


def _normalise_cover_url(value):
    """Return a downloadable artwork URL from Xtream or TMDb episode data."""
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ""
    try:
        value = value.strip().replace("\\/", "/")
    except Exception:
        return ""
    if value.startswith("["):
        try:
            decoded = json.loads(value)
            if isinstance(decoded, (list, tuple)):
                value = decoded[0] if decoded else ""
            else:
                value = decoded
        except Exception:
            pass
        try:
            value = value.strip().replace("\\/", "/")
        except Exception:
            return ""
    if value.startswith("//"):
        return "https:" + value
    if value.startswith("/"):
        return "https://image.tmdb.org/t/p/w500" + value
    return value


class IPTVInfoBarShowHide(object):
    STATE_HIDDEN = 0
    STATE_SHOWN = 3
    skipToggleShow = False

    def __init__(self):
        self.__state = self.STATE_SHOWN
        self.__locked = 0
        self.hideTimer = eTimer()
        try:
            self.hideTimer_conn = self.hideTimer.timeout.connect(self.doTimerHide)
        except Exception:
            self.hideTimer.callback.append(self.doTimerHide)
        self.onShow.append(self.__onShow)
        self.onHide.append(self.__onHide)

    def __onShow(self):
        self.__state = self.STATE_SHOWN
        self.startHideTimer()

    def __onHide(self):
        self.__state = self.STATE_HIDDEN

    def OkPressed(self):
        self.toggleShow()

    def startHideTimer(self):
        if self.__state == self.STATE_SHOWN and not self.__locked:
            self.hideTimer.stop()
            self.hideTimer.start(4000, True)
        self.skipToggleShow = False

    def doTimerHide(self):
        self.hideTimer.stop()
        if self.__state == self.STATE_SHOWN:
            self.hide()

    def toggleShow(self):
        if self.skipToggleShow:
            self.skipToggleShow = False
            return
        if self.__state == self.STATE_HIDDEN:
            self.show()
            self.hideTimer.stop()
        else:
            self.hide()
            self.startHideTimer()

    def lockShow(self):
        self.__locked += 1
        self.show()
        self.hideTimer.stop()

    def unlockShow(self):
        self.__locked = max(0, self.__locked - 1)
        self.startHideTimer()


class IPTVInfoBarPVRState(object):
    def __init__(self):
        self.onChangedEntry = []
        self.onPlayStateChanged.append(self.__playStateChanged)

    def __playStateChanged(self, state):
        text = ">"
        try:
            text = state[3] or ">"
        except Exception:
            pass
        icon = 0
        speed = ""
        if text == "||":
            icon = 1
        elif text == "END":
            icon = 2
        elif text.startswith(">>"):
            icon = 3
            parts = text.split()
            speed = parts[1] if len(parts) > 1 else ""
        elif text.startswith("<<"):
            icon = 4
            parts = text.split()
            speed = parts[1] if len(parts) > 1 else ""
        elif text.startswith("/"):
            icon = 5
            speed = text
        try:
            self["statusicon"].setPixmapNum(icon)
            self["speed"].setText(speed)
        except Exception:
            pass
        try:
            self.show()
            self.startHideTimer()
        except Exception:
            pass


class SubDLKeyBoard(VirtualKeyBoard):
    """A fixed-contrast keyboard for images whose default keyboard skin hides input text."""
    skin = """
        <screen name="SubDLKeyBoard" position="center,center" size="1180,700" title="SUBDL API KEY">
            <eLabel position="0,0" size="1180,700" backgroundColor="#101820" />
            <widget name="header" position="50,36" size="1080,52" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#101820" transparent="1" />
            <widget name="hint" position="50,95" size="1080,40" font="Regular;24" foregroundColor="#b9d9ff" backgroundColor="#101820" transparent="1" />
            <eLabel position="48,145" size="1084,86" backgroundColor="#ffffff" />
            <widget name="text" position="65,161" size="1050,54" font="Regular;30" foregroundColor="#101820" backgroundColor="#ffffff" />
            <widget name="list" position="48,255" size="1084,385" transparent="1" />
            <eLabel position="48,654" size="1084,2" backgroundColor="#39a9ff" />
        </screen>"""

    def __init__(self, session, title="", text=""):
        VirtualKeyBoard.__init__(self, session, title=title, text=text)
        self["hint"] = Label("Use OK to enter characters. GREEN saves. RED or EXIT cancels.")


class SubDLSettingsScreen(Screen, ConfigListScreen):
    """Local configuration only; no provider key is bundled in the package."""
    skin = """
        <screen name="SubDLSettingsScreen" position="center,center" size="1120,610" title="SUBDL EXTERNAL SUBTITLES">
            <eLabel position="0,0" size="1120,610" backgroundColor="#101820" />
            <widget name="config" position="45,45" size="1030,340" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#101820" transparent="1" />
            <widget name="keyhint" position="48,410" size="1024,54" font="Regular;25" foregroundColor="#b9d9ff" backgroundColor="#101820" transparent="1" />
            <widget name="help" position="48,486" size="1024,55" font="Regular;23" foregroundColor="#ffffff" backgroundColor="#101820" transparent="1" />
            <eLabel position="48,558" size="1024,2" backgroundColor="#39a9ff" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        current = load_subdl_settings()
        self.apiKey = ConfigPassword(default=current.get("api_key", ""), fixed_size=False)
        self.language = ConfigSelection(default=current.get("language", "ar"), choices=SUBDL_LANGUAGE_CHOICES)
        self.kind = ConfigSelection(default=current.get("kind", "standard"), choices=SUBDL_KIND_CHOICES)
        ConfigListScreen.__init__(self, [
            getConfigListEntry("SubDL API Key  (OK to edit)", self.apiKey),
            getConfigListEntry("Default Subtitle Language", self.language),
            getConfigListEntry("Default Subtitle Type", self.kind),
        ], session=session)
        self["keyhint"] = Label("")
        self["help"] = Label("OK: Edit key   YELLOW: Import /tmp/key.txt   GREEN: Save   EXIT: Close")
        self._refreshKeyHint()
        self.setTitle("SUBDL EXTERNAL SUBTITLES")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.openKeyEditor,
            "yellow": self.importKeyFromTmp,
            "green": self.save,
            "red": self.close,
            "cancel": self.close,
        }, -1)

    def _refreshKeyHint(self):
        value = self.apiKey.value or ""
        self["keyhint"].setText(
            "Key status: key entered (%d characters)." % len(value)
            if value else "Key status: no key entered."
        )

    def openKeyEditor(self):
        current = self["config"].getCurrent()
        if not current:
            return
        if current[1] is not self.apiKey:
            try:
                ConfigListScreen.keyOK(self)
            except Exception:
                pass
            return
        self.session.openWithCallback(
            self._apiKeyEntered,
            SubDLKeyBoard,
            title="Enter SubDL API Key, then press GREEN",
            text=self.apiKey.value or ""
        )

    def _apiKeyEntered(self, value=None):
        if value is None:
            return
        try:
            if isinstance(value, bytes):
                value = value.decode("utf-8", "ignore")
        except Exception:
            pass
        self.apiKey.value = str(value).strip()
        self["config"].invalidateCurrent()
        self._refreshKeyHint()

    def importKeyFromTmp(self):
        """Import and save one local key without revealing its value."""
        try:
            value = _read_subdl_import_key()
            self.apiKey.value = value
            self["config"].invalidateCurrent()
            self._refreshKeyHint()
            save_subdl_settings(self.apiKey.value, self.language.value, self.kind.value)
            removed = False
            try:
                os.remove(SUBDL_IMPORT_FILE)
                removed = True
            except Exception:
                pass
            message = (
                "SubDL key imported and saved locally. The temporary file was removed."
                if removed else
                "SubDL key imported and saved locally. Remove /tmp/key.txt manually to protect your key."
            )
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=5)
        except IOError:
            self.session.open(
                MessageBox,
                "File not found: /tmp/key.txt. Put only one SubDL key in this file, then choose Import SubDL Key from MENU.",
                MessageBox.TYPE_INFO,
                timeout=7
            )
        except ValueError:
            self.session.open(
                MessageBox,
                "Invalid /tmp/key.txt. It must contain exactly one non-empty SubDL key and be under 1 KB.",
                MessageBox.TYPE_ERROR,
                timeout=7
            )
        except Exception:
            self.session.open(MessageBox, "Could not import the SubDL key from /tmp/key.txt.", MessageBox.TYPE_ERROR, timeout=5)

    def save(self):
        try:
            save_subdl_settings(self.apiKey.value, self.language.value, self.kind.value)
            # Closing directly avoids an image-specific blank MessageBox after saving.
            self.close(True)
        except Exception:
            self.session.open(MessageBox, "Could not save SubDL settings.", MessageBox.TYPE_ERROR, timeout=4)


class TiviMatePlayer(
        InfoBarBase,
        IPTVInfoBarShowHide,
        IPTVInfoBarPVRState,
        InfoBarAudioSelection,
        InfoBarSubtitleSupport,
        InfoBarSeek,
        InfoBarNotifications,
        InfoBarSummarySupport,
        InfoBarMoviePlayerSummarySupport,
        Screen):

    ENABLE_RESUME_SUPPORT = True
    ALLOW_SUSPEND = True

    skin = """<screen name="TiviMateVodPlayer" position="0,0" size="1920,1080" backgroundColor="#ff000000" flags="wfNoBorder">
        <eLabel position="0,864" size="1920,216" backgroundColor="#40000000" zPosition="1"/>
        <eLabel position="0,863" size="1920,1" backgroundColor="#ffffff" zPosition="1"/>
        <widget name="cover" pixmap="%s" position="30,720" size="220,330" alphatest="blend" zPosition="2"/>
        <widget name="speed" position="1368,888" size="54,48" font="Regular;36" foregroundColor="#ffffff" backgroundColor="#40000000" halign="right" valign="center" transparent="1" zPosition="3"/>
        <widget name="notification" position="321,934" size="1143,24" font="Regular;22" noWrap="1" foregroundColor="#b9d9ff" backgroundColor="#40000000" halign="left" transparent="1" zPosition="4"/>
        <widget source="session.CurrentService" render="Label" position="321,888" size="900,48" font="Regular;36" noWrap="1" foregroundColor="#ffffff" backgroundColor="#40000000" transparent="1" zPosition="3"><convert type="ServiceName">Name</convert></widget>
        <widget name="statusicon" position="1428,894" size="38,38" zPosition="5" alphatest="blend" pixmaps="%s,%s,%s,%s,%s,%s,%s"/>
        <eLabel position="280,894" size="1,156" backgroundColor="#ffffff" zPosition="1"/>
        <eLabel position="1512,894" size="1,156" backgroundColor="#ffffff" zPosition="1"/>
        <widget source="session.CurrentService" render="Progress" position="321,1002" size="1143,12" borderWidth="1" borderColor="#ffffff" foregroundColor="#2a70a4" backgroundColor="#1a000000" zPosition="3"><convert type="TiviMateServicePosition">Position</convert></widget>
        <widget source="session.CurrentService" render="Label" position="321,956" size="900,48" font="Regular;30" noWrap="1" foregroundColor="#ffffff" backgroundColor="#40000000" halign="left" transparent="1" zPosition="3"><convert type="TiviMateServicePosition">Position,ShowHours</convert></widget>
        <widget source="session.CurrentService" render="Label" position="1344,956" size="120,48" font="Regular;30" noWrap="1" foregroundColor="#ffffff" backgroundColor="#40000000" halign="right" transparent="1" zPosition="3"><convert type="TiviMateServicePosition">Length,ShowHours</convert></widget>
        <widget source="global.CurrentTime" render="Label" position="1560,888" size="318,48" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#40000000" transparent="1" zPosition="2"><convert type="ClockToText">Format:%%H:%%M | %%A</convert></widget>
        <ePixmap pixmap="%s" position="1560,939" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1656,939" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1752,939" size="90,36" alphatest="blend" zPosition="2"/>
        <ePixmap pixmap="%s" position="1560,981" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1656,981" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1752,981" size="90,36" alphatest="blend" zPosition="2"/>
        <ePixmap pixmap="%s" position="1560,1023" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1656,1023" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1752,1023" size="90,36" alphatest="blend" zPosition="2"/>
        <widget source="streamcat" render="Label" position="1560,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"/>
        <widget source="streamtype" render="Label" position="1560,981" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"/>
        <widget source="extension" render="Label" position="1560,1023" size="90,36" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"/>
        <widget source="session.CurrentService" render="Label" position="1656,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateServiceInfo">VideoWidth</convert></widget>
        <widget source="session.CurrentService" render="Label" position="1656,981" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateServiceInfo">VideoHeight</convert></widget>
        <widget source="session.CurrentService" render="Label" position="1656,1023" size="90,36" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateServiceInfo">Framerate</convert></widget>
        <widget text="UHD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateServiceInfo">IsUHD</convert><convert type="ConditionalShowHide"/></widget>
        <widget text="FHD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateServiceInfo">IsFHD</convert><convert type="ConditionalShowHide"/></widget>
        <widget text="HD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateServiceInfo">IsHD</convert><convert type="ConditionalShowHide"/></widget>
        <widget text="SD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateServiceInfo">IsSD</convert><convert type="ConditionalShowHide"/></widget>
        <widget text="16:9" render="FixedLabel" source="session.CurrentService" position="1752,981" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateServiceInfo">IsWidescreen</convert><convert type="ConditionalShowHide"/></widget>
        <widget text="4:3" render="FixedLabel" source="session.CurrentService" position="1752,981" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateServiceInfo">IsWidescreen</convert><convert type="ConditionalShowHide">Invert</convert></widget>
        <widget source="session.CurrentService" render="Pixmap" pixmap="%s" position="1752,1023" size="90,36" alphatest="blend" zPosition="2"><convert type="TiviMateServiceInfo">IsMultichannel</convert><convert type="ConditionalShowHide"/></widget>
        <widget source="session.CurrentService" render="Pixmap" pixmap="%s" position="1848,939" size="38,38" alphatest="blend" zPosition="2"><convert type="TiviMateServiceInfo">AudioTracksAvailable</convert><convert type="ConditionalShowHide"/></widget>
    </screen>""" % (
        DEFAULT_COVER,
        os.path.join(ASSET, "state_play.png"), os.path.join(ASSET, "state_pause.png"), os.path.join(ASSET, "state_stop.png"),
        os.path.join(ASSET, "state_ff.png"), os.path.join(ASSET, "state_rw.png"), os.path.join(ASSET, "state_slow.png"), os.path.join(ASSET, "state_blank.png"),
        *([os.path.join(ASSET, "stream-box.png")] * 9),
        os.path.join(ASSET, "dolby.png"), os.path.join(ASSET, "key_audio.png")
    )

    def __init__(self, session, service, item=None):
        Screen.__init__(self, session)
        self.session = session
        self.item = item or {}
        self.streamurl = ""
        try:
            self.streamurl = service.getPath()
        except Exception:
            try:
                self.streamurl = service.toString().split(":", 10)[-1]
            except Exception:
                pass
        self.servicetype = _load_player_type()
        self.original_service = None
        self._external_subs = None
        self._external_subtitle_path = ""
        self._subssupport = None
        self._subtitle_thread = None
        self._closing = False
        try:
            self.original_service = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            pass

        # OpenATV's subtitle picker calls self.enableSubtitle().  The standard
        # mixin supplies that interface, including selected_subtitle tracking
        # and the receiver-owned subtitle display window.
        for klass in (InfoBarBase, IPTVInfoBarShowHide, InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarSeek,
                      InfoBarNotifications, InfoBarSummarySupport, InfoBarMoviePlayerSummarySupport):
            klass.__init__(self)
        IPTVInfoBarPVRState.__init__(self)

        self["streamcat"] = StaticText("VOD")
        self["streamtype"] = StaticText(str(self.servicetype))
        ext = os.path.splitext(self.streamurl.split("?", 1)[0])[-1].replace(".", "").upper() or "STREAM"
        self["extension"] = StaticText(ext)
        self["cover"] = Pixmap()
        self["speed"] = Label("")
        self["notification"] = Label("")
        self["statusicon"] = MultiPixmap()
        self._notification_timer = eTimer()
        try:
            self._notification_timer_conn = self._notification_timer.timeout.connect(self._clearNotification)
        except Exception:
            self._notification_timer.callback.append(self._clearNotification)

        self.PicLoad = ePicLoad()
        try:
            self.PicLoad.PictureData.get().append(self._decodeCover)
        except Exception:
            self._pic_conn = self.PicLoad.PictureData.connect(self._decodeCover)
        self._cover_file = None

        self["actions"] = ActionMap([
            "OkCancelActions", "InfobarShowHideActions", "ColorActions", "MoviePlayerActions",
            "MediaPlayerActions", "DirectionActions", "MenuActions"
        ], {
            "cancel": self.back, "stop": self.back, "red": self.back,
            "ok": self.refreshInfobar, "toggleShow": self.refreshInfobar,
            "menu": self.openPlayerMenu, "info": self.openPlayerMenu, "tv": self.openPlayerMenu,
            "green": self.audioSelection,
            "yellow": self.autoDownloadExternalSubtitle,
            "blue": self.openSubsSupport,
        }, -2)

        self._event_tracker = ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evStart: self._serviceStarted,
            iPlayableService.evEOF: self._serviceEOF,
        })
        self.onFirstExecBegin.append(self.playStream)
        self.onClose.append(self._cleanup)

    def refreshInfobar(self):
        IPTVInfoBarShowHide.OkPressed(self)

    def _externalSubtitleIsActive(self):
        """Return true only while this player owns a successfully loaded SRT.

        IPTV servers can advertise many duplicated embedded subtitle tracks.  An
        external SRT is rendered by SubsSupport and is not part of Enigma2's
        native `getSubtitleList()`, so opening the native picker after a
        successful attach is both misleading and can replace the user's view.
        """
        path = getattr(self, "_external_subtitle_path", "")
        support = getattr(self, "_external_subs", None)
        if not path or not support or not os.path.isfile(path):
            return False
        checker = getattr(support, "isSubsLoaded", None)
        if callable(checker):
            try:
                return bool(checker())
            except Exception:
                # Older image ports may expose a broken status probe even while
                # their external renderer is running.  The live object and SRT
                # path are then the safest compatibility evidence.
                return True
        return True

    def subtitleSelection(self):
        """Reserve TiviMate's subtitle controls for external SRT files only.

        A server can publish many repeated `embedded` tracks.  They belong to
        the stream and cannot be safely de-duplicated by the plugin, so the VOD
        player deliberately never opens Enigma2's native track picker.  The
        user is instead guided to the independent SubDL workflow.
        """
        if self._externalSubtitleIsActive():
            message = "External SRT is active. Server embedded subtitle tracks are ignored."
        else:
            message = "No external SRT is active. Use YELLOW for SubDL; server embedded tracks are ignored."
        self._showNotification(message, MessageBox.TYPE_INFO, timeout=5)
        return 1

    def subtitleQuickMenu(self):
        """Use the same external-only policy on images with a quick subtitle key."""
        return self.subtitleSelection()

    def playStream(self):
        if not self.streamurl:
            self.session.open(MessageBox, "Invalid playback URL.", MessageBox.TYPE_ERROR, timeout=4)
            return
        try:
            ref = eServiceReference(int(self.servicetype), 0, self.streamurl)
            ref.setName(self.item.get("name") or self.item.get("title") or "IPTV")
            self.session.nav.playService(ref)
            self["streamtype"].setText(str(self.servicetype))
            self.downloadCover()
            self.show()
            self.startHideTimer()
        except Exception as exc:
            self.session.open(MessageBox, "Could not start playback:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=5)

    def _serviceStarted(self):
        try:
            self["statusicon"].setPixmapNum(0)
            self["speed"].setText("")
        except Exception:
            pass

    def _serviceEOF(self):
        try:
            self["statusicon"].setPixmapNum(2)
            self.show()
        except Exception:
            pass



    def _mainThread(self, callback):
        if getattr(self, "_closing", False):
            return
        try:
            if reactor is not None:
                reactor.callFromThread(callback)
                return
        except Exception:
            pass
        callback()

    def _clearNotification(self):
        try:
            self._notification_timer.stop()
        except Exception:
            pass
        try:
            self["notification"].setText("")
        except Exception:
            pass

    def _showNotification(self, message, msg_type=MessageBox.TYPE_INFO, timeout=5):
        """Show a non-modal inline status message safely inside the player.

        Pure2startup rejects ``session.open(MessageBox, ...)`` while processing
        delayed ChoiceBox callbacks.  This method deliberately does not open a
        screen or queue a MessageBox; it only updates an existing Label and
        clears it with the player's own timer.  ``msg_type`` is kept for callers
        and future colour handling without changing the safe execution path.
        """
        if getattr(self, "_closing", False):
            return
        try:
            self["notification"].setText(message)
            self.show()
            self._notification_timer.stop()
            self._notification_timer.start(max(1, int(timeout)) * 1000, True)
        except Exception:
            pass

    def _hasSubsSupport(self):
        try:
            from Plugins.Extensions.SubsSupport.subtitles import SubsSupport  # noqa: F401
            return True
        except Exception:
            return False

    def _clearSubsSupport(self):
        support = getattr(self, "_subssupport", None)
        self._subssupport = None
        if support is None:
            return
        try:
            support.hideSubsDialog()
        except Exception:
            pass
        try:
            support.exitSubs()
        except Exception:
            pass

    def openSubsSupport(self):
        """Open the installed SubsSupport menu from BLUE for the active stream."""
        try:
            from Plugins.Extensions.SubsSupport.subtitles import SubsSupport
        except Exception:
            self._showNotification(
                "SubsSupport is not installed. Install it from your receiver's plugin feed, then try again.",
                MessageBox.TYPE_INFO,
                timeout=7
            )
            return
        try:
            self._clearSubsSupport()
            self._subssupport = SubsSupport(
                self.session,
                defaultPath="/tmp",
                forceDefaultPath=False,
                autoLoad=False,
                showGUIInfoMessages=True,
                embeddedSupport=False,
                preferEmbedded=False,
                searchSupport=True,
            )
            self._subssupport.subsMenu()
        except Exception:
            self._clearSubsSupport()
            self._showNotification(
                "Could not open SubsSupport. Check that the installed version is compatible with your receiver image.",
                MessageBox.TYPE_ERROR,
                timeout=6
            )

    def _openSubDLSettings(self, resume_search=False, resume_auto=False):
        self._resume_subdl_search = bool(resume_search)
        self._resume_subdl_auto = bool(resume_auto)
        self.lockShow()
        self.session.openWithCallback(self._subdlSettingsClosed, SubDLSettingsScreen)

    def _subdlSettingsClosed(self, saved=None):
        self.unlockShow()
        resume_search = bool(getattr(self, "_resume_subdl_search", False))
        resume_auto = bool(getattr(self, "_resume_subdl_auto", False))
        self._resume_subdl_search = False
        self._resume_subdl_auto = False
        if not saved or not load_subdl_settings().get("api_key"):
            return
        if resume_auto:
            self.autoDownloadExternalSubtitle()
        elif resume_search:
            self.openExternalSubtitleSearch()


    def _importSubDLKeyFromMenu(self):
        """Import the local key directly from the player's MENU list."""
        try:
            value = _read_subdl_import_key()
            current = load_subdl_settings()
            save_subdl_settings(value, current.get("language", "ar"), current.get("kind", "standard"))
            removed = False
            try:
                os.remove(SUBDL_IMPORT_FILE)
                removed = True
            except Exception:
                pass
            message = (
                "SubDL key imported and saved locally. The temporary file was removed."
                if removed else
                "SubDL key imported and saved locally. Remove /tmp/key.txt manually to protect your key."
            )
            self._showNotification(message, MessageBox.TYPE_INFO, timeout=6)
        except IOError:
            self._showNotification(
                "File not found: /tmp/key.txt. Put only one SubDL key in this file, then open MENU and choose Import SubDL Key.",
                MessageBox.TYPE_INFO,
                timeout=8
            )
        except ValueError:
            self._showNotification(
                "Invalid /tmp/key.txt. It must contain exactly one non-empty SubDL key and be under 1 KB.",
                MessageBox.TYPE_ERROR,
                timeout=8
            )
        except Exception:
            self._showNotification("Could not import the SubDL key from /tmp/key.txt.", MessageBox.TYPE_ERROR, timeout=6)

    def autoDownloadExternalSubtitle(self):
        """YELLOW: search, download, and load the best matching SRT in one step."""
        if getattr(self, "_auto_subtitle_busy", False):
            self._showNotification("Automatic subtitle download is already running...", MessageBox.TYPE_INFO, timeout=4)
            return
        if not self._hasSubsSupport():
            self._showNotification(
                "To display external subtitles, install SubsSupport from your receiver's plugin feed, then reopen the video.",
                MessageBox.TYPE_INFO,
                timeout=8
            )
            return
        settings = load_subdl_settings()
        if not settings.get("api_key"):
            self._showNotification(
                "Import your SubDL API key first: put it in /tmp/key.txt, then choose Import SubDL API Key from MENU.",
                MessageBox.TYPE_INFO,
                timeout=8
            )
            return
        self._auto_subtitle_busy = True
        self._showNotification("Searching and downloading the best subtitle...", MessageBox.TYPE_INFO, timeout=5)
        self._subtitle_thread = threading.Thread(
            target=self._autoDownloadExternalSubtitle,
            args=(settings.get("api_key", ""), settings.get("language", "ar"), settings.get("kind", "standard")),
            name="TiviMateSubDLAutoDownload"
        )
        self._subtitle_thread.daemon = True
        self._subtitle_thread.start()

    def _downloadBestExternalSubtitle(self, api_key, rows):
        """Download the highest-ranked usable SubDL SRT, trying two fallbacks.

        SubDL can occasionally return a stale or temporarily unavailable file URL.
        For the automatic action, trying the next compatible release avoids a
        needless failure while preserving the manual release chooser unchanged.
        """
        errors = []
        for row in list(rows or [])[:3]:
            try:
                return SubDLClient(api_key).download(row), row
            except SubDLError as exc:
                errors.append(str(exc))
        if errors:
            raise SubDLError("SubDL found subtitles, but none of the available downloads could be loaded. " + errors[-1])
        raise SubDLError("No usable SubDL subtitle download was found.")

    def _autoDownloadExternalSubtitle(self, api_key, language, kind):
        try:
            rows = SubDLClient(api_key).search(self.item, language, kind)
            if not rows:
                raise SubDLError("No matching subtitle was found. Open MENU to try another language or release.")
            path, row = self._downloadBestExternalSubtitle(api_key, rows)
            self._mainThread(lambda: self._attachAutoExternalSubtitle(path, row))
        except SubDLError as exc:
            message = str(exc)
            self._mainThread(lambda: self._autoExternalSubtitleFailed(message))
        except Exception:
            self._mainThread(lambda: self._autoExternalSubtitleFailed("Could not automatically download the external subtitle."))

    def _attachAutoExternalSubtitle(self, path, row):
        self._auto_subtitle_busy = False
        self._attachExternalSubtitle(path, row)

    def _autoExternalSubtitleFailed(self, message):
        self._auto_subtitle_busy = False
        self._showNotification(message, MessageBox.TYPE_ERROR, timeout=7)

    def openExternalSubtitleSearch(self):
        """Manual SubDL search remains available from MENU."""
        if not self._hasSubsSupport():
            self._showNotification(
                "To display external subtitles, install SubsSupport from your receiver's plugin feed, then reopen the video.",
                MessageBox.TYPE_INFO,
                timeout=8
            )
            return
        settings = load_subdl_settings()
        if not settings.get("api_key"):
            self._showNotification(
                "Import your SubDL API key first: put it in /tmp/key.txt, then choose Import SubDL API Key from MENU.",
                MessageBox.TYPE_INFO,
                timeout=8
            )
            return
        self.lockShow()
        self.session.openWithCallback(
            self._subtitleLanguageSelected,
            ChoiceBox,
            title="Choose External Subtitle Language",
            list=SUBDL_LANGUAGE_CHOICES,
            selection=0
        )

    def _subtitleLanguageSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        self._subtitle_language = selected[1]
        self.lockShow()
        self.session.openWithCallback(
            self._subtitleKindSelected,
            ChoiceBox,
            title="Choose Subtitle Type",
            list=SUBDL_KIND_CHOICES,
            selection=0
        )

    def _subtitleKindSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        language = getattr(self, "_subtitle_language", "ar")
        kind = selected[1]
        settings = load_subdl_settings()
        self._showNotification("Searching for external subtitles...", MessageBox.TYPE_INFO, timeout=3)
        self._subtitle_thread = threading.Thread(
            target=self._searchExternalSubtitles,
            args=(settings.get("api_key", ""), language, kind),
            name="TiviMateSubDLSearch"
        )
        self._subtitle_thread.daemon = True
        self._subtitle_thread.start()

    def _searchExternalSubtitles(self, api_key, language, kind):
        try:
            rows = SubDLClient(api_key).search(self.item, language, kind)
            if not rows:
                raise SubDLError("No matching subtitle was found. Try another language or subtitle type.")
            self._mainThread(lambda: self._showExternalSubtitleResults(rows))
        except SubDLError as exc:
            message = str(exc)
            self._mainThread(lambda: self._showNotification(message, MessageBox.TYPE_INFO, timeout=6))
        except Exception:
            self._mainThread(lambda: self._showNotification("Could not search for external subtitles.", MessageBox.TYPE_ERROR, timeout=5))

    def _showExternalSubtitleResults(self, rows):
        choices = [(row.get("label", "SUBTITLE"), row) for row in rows]
        self.lockShow()
        self.session.openWithCallback(
            self._externalSubtitleSelected,
            ChoiceBox,
            title="SubDL - Choose a Release",
            list=choices
        )

    def _externalSubtitleSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        row = selected[1]
        api_key = load_subdl_settings().get("api_key", "")
        self._showNotification("Downloading subtitle...", MessageBox.TYPE_INFO, timeout=3)
        self._subtitle_thread = threading.Thread(
            target=self._downloadExternalSubtitle,
            args=(api_key, row),
            name="TiviMateSubDLDownload"
        )
        self._subtitle_thread.daemon = True
        self._subtitle_thread.start()

    def _downloadExternalSubtitle(self, api_key, row):
        try:
            path = SubDLClient(api_key).download(row)
            self._mainThread(lambda: self._attachExternalSubtitle(path, row))
        except SubDLError as exc:
            message = str(exc)
            self._mainThread(lambda: self._showNotification(message, MessageBox.TYPE_ERROR, timeout=6))
        except Exception:
            self._mainThread(lambda: self._showNotification("Could not download the external subtitle.", MessageBox.TYPE_ERROR, timeout=5))

    def _clearExternalSubtitle(self):
        support = getattr(self, "_external_subs", None)
        self._external_subs = None
        self._external_subtitle_path = ""
        if support is None:
            return
        try:
            support.hideSubsDialog()
        except Exception:
            pass
        try:
            support.exitSubs()
        except Exception:
            pass

    def _loadExternalSubtitleWithSubsSupport(self, support, path):
        """Attach an SRT while the current Enigma2 service keeps playing.

        Recent SubsSupport versions expose ``loadSubs(path, newService=False)``
        for replacing an external subtitle on the already running service.  A
        small compatibility ladder keeps older builds working when they do not
        accept the keyword or second argument.
        """
        loader = getattr(support, "loadSubs", None)
        if not callable(loader):
            raise RuntimeError("load method unavailable")

        try:
            loaded = loader(path, newService=False)
        except TypeError:
            try:
                loaded = loader(path, False)
            except TypeError:
                loaded = loader(path)

        # Some older ports return None on success, so reject only an explicit
        # False return.  If a status method exists, it remains the stronger
        # indicator of success.
        if loaded is False:
            raise RuntimeError("load rejected")
        checker = getattr(support, "isSubsLoaded", None)
        if callable(checker):
            try:
                if not checker():
                    raise RuntimeError("load status false")
            except RuntimeError:
                raise
            except Exception:
                # A broken status probe must not discard a subtitle which a
                # legacy implementation has already accepted.
                pass

        # ``resumeSubs`` is the public same-service path used by SubsSupport
        # itself.  It shows the dialog and synchronises it to the current PTS.
        resumer = getattr(support, "resumeSubs", None)
        if callable(resumer):
            try:
                resumer()
                return "resume"
            except Exception:
                # Fall through to the older delayed-start entry point.
                pass

        starter = getattr(support, "startSubs", None)
        if callable(starter):
            starter(0)
            return "start"
        raise RuntimeError("start method unavailable")

    def _attachExternalSubtitle(self, path, row):
        try:
            from Plugins.Extensions.SubsSupport.subtitles import SubsSupport
        except Exception:
            self._showNotification(
                "The subtitle file was downloaded, but SubsSupport is not available to load it.",
                MessageBox.TYPE_ERROR,
                timeout=6
            )
            return

        stage = "checking the downloaded SRT"
        try:
            if not path or not os.path.isfile(path):
                raise RuntimeError("downloaded file missing")
            self._clearExternalSubtitle()
            stage = "starting SubsSupport"
            self._external_subs = SubsSupport(
                self.session,
                defaultPath=os.path.dirname(path),
                forceDefaultPath=True,
                autoLoad=False,
                showGUIInfoMessages=False,
                embeddedSupport=False,
                preferEmbedded=False,
                searchSupport=False,
            )
            stage = "loading the SRT into the current video"
            self._loadExternalSubtitleWithSubsSupport(self._external_subs, path)
            self._external_subtitle_path = path
            release = row.get("release") or row.get("format", "SRT").upper()
            self._showNotification("External subtitle loaded: %s" % release[:80], MessageBox.TYPE_INFO, timeout=4)
        except Exception:
            try:
                print("[TiviMateE2] SubsSupport subtitle attach failed while %s" % stage)
            except Exception:
                pass
            self._clearExternalSubtitle()
            self._showNotification(
                "The subtitle was downloaded but SubsSupport could not attach it while %s. Try another release or press BLUE to check SubsSupport." % stage,
                MessageBox.TYPE_ERROR,
                timeout=8
            )

    def openPlayerMenu(self):
        choices = [
            ("Import SubDL API Key", "import_subdl_key"),
            ("Download Best Subtitle Automatically (YELLOW button)", "auto_subtitle"),
            ("Choose SubDL Subtitle Manually", "external_subtitle"),
            ("Change Aspect Ratio", "aspect_ratio"),
            ("Try Next Playback Engine (this item only)", "try_next_engine"),
            ("SubsSupport (BLUE button)", "subssupport"),
        ]
        for value, name in _available_stream_types():
            prefix = "✓ " if int(value) == int(self.servicetype) else ""
            choices.append((prefix + "Set default: " + name, value))
        self.lockShow()
        self.session.openWithCallback(
            self._playerSelected,
            ChoiceBox,
            title="Player & External Subtitles",
            list=choices
        )

    def _playerSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        value = selected[1]
        if value == "settings":
            self._openSubDLSettings()
            return
        if value == "auto_subtitle":
            self.autoDownloadExternalSubtitle()
            return
        if value == "aspect_ratio":
            self.nextAspectRatio()
            return
        if value == "import_subdl_key":
            self._importSubDLKeyFromMenu()
            return
        if value == "try_next_engine":
            engines = [engine for engine, _label in _available_stream_types()]
            if not engines:
                return
            try:
                position = engines.index(int(self.servicetype))
            except Exception:
                position = -1
            self._switchPlaybackEngine(engines[(position + 1) % len(engines)], save_default=False)
            return
        if value == "subssupport":
            self.openSubsSupport()
            return
        if value == "external_subtitle":
            self.openExternalSubtitleSearch()
            return
        value = int(value)
        self._switchPlaybackEngine(value, save_default=True)

    def _switchPlaybackEngine(self, value, save_default=False):
        """Restart the active VOD item through a chosen backend.

        Temporary retries keep the global setting intact, allowing an unsupported
        codec in one file to be tested without changing every other channel.
        """
        value = int(value)
        if value == int(self.servicetype) and not save_default:
            return
        self._clearExternalSubtitle()
        self.servicetype = value
        if save_default:
            _save_player_type(value)
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.playStream()
        try:
            mode = "Default playback engine saved" if save_default else "Trying this engine for the current item only"
            self._showNotification("%s: %s" % (mode, value), MessageBox.TYPE_INFO, timeout=3)
        except Exception:
            pass


    def nextAspectRatio(self):
        try:
            from enigma import eAVSwitch
        except Exception:
            try:
                from enigma import eAVControl as eAVSwitch
            except Exception:
                return
        self._aspect = (getattr(self, "_aspect", 2) + 1) % 7
        try:
            eAVSwitch.getInstance().setAspectRatio(self._aspect)
        except Exception:
            pass

    def downloadCover(self):
        try:
            self["cover"].instance.setPixmapFromFile(DEFAULT_COVER)
        except Exception:
            pass
        info = self.item.get("info") or {}
        if not isinstance(info, dict):
            info = {}
        url = (
            self.item.get("_player_cover") or
            self.item.get("movie_image") or info.get("movie_image") or
            self.item.get("cover_big") or info.get("cover_big") or
            self.item.get("cover") or info.get("cover") or
            self.item.get("poster_path") or info.get("poster_path") or
            self.item.get("stream_icon") or info.get("stream_icon") or ""
        )
        url = _normalise_cover_url(url)
        if not url or not str(url).startswith(("http://", "https://")) or downloadPage is None:
            return
        try:
            fd, path = tempfile.mkstemp(prefix="tivixs_cover_", suffix=".jpg", dir="/tmp")
            os.close(fd)
            self._cover_file = path
            request_url = url.encode("utf-8") if isinstance(url, str) else url
            d = downloadPage(request_url, path, timeout=7)
            d.addCallback(lambda _r: self._resizeCover(path))
            d.addErrback(lambda _f: self._removeCover())
        except Exception:
            self._removeCover()

    def _resizeCover(self, path):
        try:
            render_width, render_height = scale_size(220, 330)
            self.PicLoad.setPara([render_width, render_height, 1, 1, 0, 1, "FF000000"])
            self.PicLoad.startDecode(path)
        except Exception:
            self._removeCover()

    def _decodeCover(self, _info=None):
        try:
            ptr = self.PicLoad.getData()
            if ptr is not None and self["cover"].instance:
                self["cover"].instance.setPixmap(ptr)
                self["cover"].instance.show()
        except Exception:
            pass
        self._removeCover()

    def _removeCover(self):
        path = self._cover_file
        self._cover_file = None
        try:
            if path and os.path.exists(path):
                os.remove(path)
        except Exception:
            pass

    def back(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        try:
            if self.original_service is not None:
                self.session.nav.playService(self.original_service)
        except Exception:
            pass
        self.close()

    def _cleanup(self):
        self._closing = True
        self._clearExternalSubtitle()
        self._clearSubsSupport()
        try:
            self.hideTimer.stop()
        except Exception:
            pass
        try:
            self._notification_timer.stop()
        except Exception:
            pass
        self._removeCover()


# Keep player and subtitle dialogs in the same native coordinate system as the
# active FHD or WQHD Enigma2 desktop.
SubDLKeyBoard.skin = scale_skin(SubDLKeyBoard.skin)
SubDLSettingsScreen.skin = scale_skin(SubDLSettingsScreen.skin)
TiviMatePlayer.skin = scale_skin(TiviMatePlayer.skin)
