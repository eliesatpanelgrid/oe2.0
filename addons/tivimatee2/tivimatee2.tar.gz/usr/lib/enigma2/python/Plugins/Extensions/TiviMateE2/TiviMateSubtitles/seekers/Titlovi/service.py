# -*- coding: utf-8 -*-

from __future__ import absolute_import
from .ti_utilities import OSDBServer

from ..utilities import languageTranslate, log
from ..seeker import SubtitlesDownloadError, SubtitlesErrors


from six.moves import urllib


def _tivimate_validate_download(data, content_type=""):
    """Reject HTML/error bodies before the subtitle decoder sees them."""
    if data is None or len(data) == 0:
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Empty subtitle download")
    ctype = (content_type or "").lower()
    sample = data[:8192]
    lowered = sample.lstrip(b"\xef\xbb\xbf \t\r\n").lower()
    if ("text/html" in ctype or "application/xhtml" in ctype or
            lowered.startswith(b"<!doctype html") or lowered.startswith(b"<html") or
            b"<head" in lowered[:1024] or b"cloudflare" in lowered[:2048]):
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Provider returned HTML instead of subtitles")
    if sample.startswith(b"PK\x03\x04"):
        return "zip"
    if sample.startswith(b"Rar!\x1a\x07"):
        return "rar"
    # Plain subtitle formats retain ASCII timing/format markers even with Arabic legacy encodings.
    if (b"-->" in sample or b"WEBVTT" in sample[:64].upper() or
            b"[Script Info]" in sample or b"Dialogue:" in sample or
            __import__('re').search(br"\{\d+\}\{\d+\}", sample)):
        return "plain"
    raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Downloaded file is not a supported subtitle/archive")

def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack): #standard input
    osdb_server = OSDBServer()
    language1 = languageTranslate(lang1, 0, 2)
    language2 = languageTranslate(lang2, 0, 2)
    language3 = languageTranslate(lang3, 0, 2)
    subtitles_list = osdb_server.search_subtitles(title, tvshow, season, episode, [language1, language2, language3], year)
    return subtitles_list, "", "" #standard output


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    OSDBServer()
    params = subtitles_list[pos]
    url = "https://titlovi.com/download/?type=1&mediaid=%s" % params["ID"]
    language_name = params["language_name"]
    log(__name__, 'link: %s' % url)
    try:
        response = urllib.request.urlopen(url, timeout=10)
        data = response.read()
        content_type = response.headers.get('Content-Type', '') if getattr(response, 'headers', None) else ''
        kind = _tivimate_validate_download(data, content_type)
        with open(zip_subs, 'wb') as local_file:
            local_file.write(data)
    except SubtitlesDownloadError:
        raise
    except Exception as error:
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Titlovi download failed: %s" % error)
    if kind == 'zip':
        return True, language_name, 'zip'
    if kind == 'rar':
        return True, language_name, 'rar'
    return False, language_name, zip_subs
