# -*- coding: utf-8 -*-
from __future__ import absolute_import
from .compat import atomic_replace, ensure_dir, open_text
import os, json, time, hashlib, threading

from .cache_manager import get_cache_dir

FILTERS_FILE = "/etc/enigma2/tivimatee2/category_filters.json"
CACHE_TTL = 86400  # 24 hours
_RAM_STREAM_CACHE = {}
_RAM_CATALOG_CACHE = {}
_RAM_CATEGORY_CACHE = {}
_REFRESHING = set()
_PREFETCHING = set()
_CATEGORY_REFRESHING = set()
_CATALOG_REFRESHING = set()


def _is_stalker(source):
    return isinstance(source, dict) and source.get("type") == "stalker"

def _usable_for_cache(source, rows):
    # Empty lists are valid for other providers, but for Stalker they usually mean
    # an incomplete session/profile or a transient portal response.  Retry instead.
    return bool(rows) or not _is_stalker(source)

def _discard_cache(path):
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def _cache_dir():
    return get_cache_dir("category_data")


def source_filter_key(source):
    return "%s|%s|%s|%s" % (
        source.get("type", ""), source.get("url", "").rstrip("/"),
        source.get("username", ""), source.get("mac", "")
    )


def load_all_filters():
    try:
        with open_text(FILTERS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_all_filters(data):
    try:
        ensure_dir(os.path.dirname(FILTERS_FILE))
        tmp = FILTERS_FILE + ".tmp"
        with open_text(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        atomic_replace(tmp, FILTERS_FILE)
        # Filtering only changes which already-known categories are visible.  Do
        # not delete the catalogue/category cache here: clearing it forced the
        # next screen to download every selected category again after OK.
        return True
    except Exception:
        return False


def get_allowed_category_ids(source, kind):
    entry = load_all_filters().get(source_filter_key(source), {})
    if kind not in entry:
        return None
    return set(str(x) for x in (entry.get(kind) or []))


def category_id_for_item(item):
    """Return the stable category identity advertised by any supported source.

    Xtream uses ``category_id`` while M3U playlists use ``group-title`` (stored
    as ``group``) and portal sources commonly expose ``genre_id``.  Keeping the
    lookup here makes filtering apply to every source type
    without hard-coding a provider or a bouquet name.
    """
    if not isinstance(item, dict):
        return ""
    for key in ("category_id", "category-id", "group_id", "group-id", "group", "group-title", "genre_id", "genre-id", "genre", "category_name", "category-name"):
        value = item.get(key)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def filter_categories(source, kind, categories):
    allowed = get_allowed_category_ids(source, kind)
    if allowed is None:
        return list(categories or [])
    result = []
    for category in (categories or []):
        cid = category_id_for_item(category)
        if cid in allowed:
            result.append(category)
    return result


def filter_items(source, kind, items):
    allowed = get_allowed_category_ids(source, kind)
    if allowed is None:
        return list(items or [])
    return [item for item in (items or []) if category_id_for_item(item) in allowed]


def _cache_path(source, kind, category_id):
    key = "%s|%s|%s" % (source_filter_key(source), kind, category_id)
    return os.path.join(_cache_dir(), hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")


def _load_cache_state(path):
    """Return (list_or_none, age_seconds). Expired data is still usable as stale cache."""
    try:
        age = max(0, time.time() - os.path.getmtime(path))
        with open_text(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return (data if isinstance(data, list) else None), age
    except Exception:
        return None, None


def _load_cache(path):
    data, age = _load_cache_state(path)
    if data is None or age is None or age > CACHE_TTL:
        return None
    return data

def _save_cache(path, data):
    try:
        ensure_dir(_cache_dir())
        tmp = path + ".tmp"
        with open_text(tmp, "w", encoding="utf-8") as f:
            json.dump(data or [], f, ensure_ascii=False)
        atomic_replace(tmp, path)
    except Exception:
        pass


def clear_source_cache():
    try:
        global _RAM_STREAM_CACHE, _RAM_CATALOG_CACHE, _RAM_CATEGORY_CACHE
        _RAM_STREAM_CACHE = {}
        _RAM_CATALOG_CACHE = {}
        _RAM_CATEGORY_CACHE = {}
        cache_dir = _cache_dir()
        if not os.path.isdir(cache_dir):
            return
        for name in os.listdir(cache_dir):
            if name.endswith(".json"):
                try: os.remove(os.path.join(cache_dir, name))
                except Exception: pass
    except Exception:
        pass





def _categories_cache_path(source, kind):
    key = "%s|categories|%s" % (source_filter_key(source), kind)
    return os.path.join(_cache_dir(), hashlib.md5(key.encode("utf-8")).hexdigest() + ".categories.json")


def _catalog_cache_path(source, kind):
    """Cache the unfiltered provider catalog as one response per source/kind."""
    key = "%s|catalog|%s" % (source_filter_key(source), kind)
    return os.path.join(_cache_dir(), hashlib.md5(key.encode("utf-8")).hexdigest() + ".catalog.json")


def _catalog_key(source, kind):
    return "%s|catalog|%s" % (source_filter_key(source), kind)


def _refresh_catalog(source, kind):
    """Refresh an expired full catalog without delaying an already cached page."""
    key = _catalog_key(source, kind)
    if key in _CATALOG_REFRESHING:
        return
    _CATALOG_REFRESHING.add(key)

    def worker():
        try:
            from .core import get_source_client
            rows = list(get_source_client(dict(source)).streams(kind) or [])
            if _usable_for_cache(source, rows):
                _RAM_CATALOG_CACHE[key] = (list(rows), time.time())
                _save_cache(_catalog_cache_path(source, kind), rows)
        except Exception:
            pass
        finally:
            _CATALOG_REFRESHING.discard(key)

    thread = threading.Thread(target=worker, name="TiviMateCatalog-%s" % kind)
    thread.daemon = True
    thread.start()


def _refresh_categories(source, kind):
    key = "%s|%s" % (source_filter_key(source), kind)
    if key in _CATEGORY_REFRESHING:
        return
    _CATEGORY_REFRESHING.add(key)
    def worker():
        try:
            from .core import get_source_client
            rows = list(get_source_client(dict(source)).categories(kind) or [])
            if _usable_for_cache(source, rows):
                _RAM_CATEGORY_CACHE[key] = (list(rows), time.time())
                _save_cache(_categories_cache_path(source, kind), rows)
        except Exception:
            pass
        finally:
            _CATEGORY_REFRESHING.discard(key)
    t = threading.Thread(target=worker, name="TiviMateCategories-%s" % kind)
    t.daemon = True
    t.start()


def get_cached_categories(source, kind, client=None, wait_for_server=False):
    """Return RAM/disk categories first, with an optional cold-cache server read.

    Screens already running a worker thread may request ``wait_for_server`` on
    first use.  UI callbacks use the default and therefore never block.
    """
    key = "%s|categories|%s" % (source_filter_key(source), kind)
    memory = _RAM_CATEGORY_CACHE.get(key)
    if memory is not None:
        rows, loaded_at = memory
        if _is_stalker(source) and not rows:
            _RAM_CATEGORY_CACHE.pop(key, None)
        else:
            if time.time() - loaded_at > CACHE_TTL:
                _refresh_categories(dict(source), kind)
                return list(rows or []), "stale"
            return list(rows or []), "ram"

    path = _categories_cache_path(source, kind)
    rows, age = _load_cache_state(path)
    if rows is not None:
        if _is_stalker(source) and not rows:
            _discard_cache(path)
        else:
            _RAM_CATEGORY_CACHE[key] = (list(rows), time.time() - float(age or 0))
            if age is not None and age > CACHE_TTL:
                _refresh_categories(dict(source), kind)
                return list(rows), "stale"
            return list(rows), "disk"
    if wait_for_server:
        try:
            if client is None:
                from .core import get_source_client
                client = get_source_client(dict(source))
            rows = list(client.categories(kind) or [])
            if _usable_for_cache(source, rows):
                _RAM_CATEGORY_CACHE[key] = (list(rows), time.time())
                _save_cache(path, rows)
            return rows, ("server" if rows or not _is_stalker(source) else "empty")
        except Exception:
            return [], "error"
    _refresh_categories(dict(source), kind)
    return [], "loading"

def _refresh_category(source, kind, category_id, client=None):
    cid = str(category_id or "")
    key = "%s|%s|%s" % (source_filter_key(source), kind, cid)
    if key in _REFRESHING:
        return
    _REFRESHING.add(key)
    def worker():
        try:
            c = client or __import__(__package__ + ".core", fromlist=["get_source_client"]).get_source_client(source)
            items = list(c.streams(kind, cid) or [])
            if _usable_for_cache(source, items):
                _RAM_STREAM_CACHE[key] = list(items)
                _save_cache(_cache_path(source, kind, cid), items)
        except Exception:
            pass
        finally:
            _REFRESHING.discard(key)
    t = threading.Thread(target=worker, name="TiviMateRefresh-%s" % kind)
    t.daemon = True
    t.start()


def get_category_streams(source, kind, client, category_id, use_cache=True, wait_for_server=True):
    """RAM -> disk -> stale disk; optionally refresh without ever blocking UI."""
    cid = str(category_id or "")
    key = "%s|%s|%s" % (source_filter_key(source), kind, cid)
    if use_cache and key in _RAM_STREAM_CACHE:
        cached = list(_RAM_STREAM_CACHE.get(key) or [])
        if _is_stalker(source) and not cached:
            _RAM_STREAM_CACHE.pop(key, None)
        else:
            return cached, "ram"
    path = _cache_path(source, kind, cid)
    if use_cache:
        items, age = _load_cache_state(path)
        if items is not None:
            if _is_stalker(source) and not items:
                _discard_cache(path)
            else:
                _RAM_STREAM_CACHE[key] = list(items)
                if age is not None and age > CACHE_TTL:
                    _refresh_category(dict(source), kind, cid)
                    return list(items), "stale"
                return list(items), "disk"
    if not wait_for_server:
        _refresh_category(dict(source), kind, cid, client)
        return [], "loading"
    items = list(client.streams(kind, cid) or [])
    if _usable_for_cache(source, items):
        _RAM_STREAM_CACHE[key] = list(items)
        if use_cache:
            _save_cache(path, items)
    return items, ("server" if items or not _is_stalker(source) else "empty")


# Stalker has no portable unfiltered VOD/Series catalog.  The dashboard and
# library landing pages therefore need a small preview from one real package
# rather than calling streams(kind) with an empty category id.  Keep this
# helper local to Stalker and use the normal category cache/fetch path.
_STALKER_GENERIC_LANDING_NAMES = frozenset((
    "all", "all movies", "all films", "all vod", "all series", "all tv shows",
    "all content", "movies", "films", "vod", "series", "tv shows", "tv series",
    "كل الأفلام", "جميع الأفلام", "كل افلام", "جميع افلام", "كل المسلسلات",
    "جميع المسلسلات", "كل المحتوى",
))


def _stalker_landing_name(category):
    try:
        return str((category or {}).get("category_name") or "").strip().lower()
    except Exception:
        return ""


def get_stalker_landing_items(source, kind, client, categories=None, limit=24):
    """Return a compact, cache-aware Stalker preview and the source package.

    The function never changes filters or cache policy.  It prefers a named
    package over a provider-wide ``All`` package so the first landing render is
    responsive on lower-powered receivers, but falls back to the latter when it
    is the only permitted package.
    """
    if not _is_stalker(source):
        return [], None, "unsupported"
    try:
        maximum = max(1, int(limit))
    except Exception:
        maximum = 24
    rows = categories
    if rows is None:
        rows, _origin = get_cached_categories(source, kind, client=client, wait_for_server=True)
    candidates = filter_categories(source, kind, list(rows or []))
    candidates = [entry for entry in candidates if str((entry or {}).get("category_id") or "")]
    if not candidates:
        return [], None, "empty"
    named = [entry for entry in candidates if _stalker_landing_name(entry) not in _STALKER_GENERIC_LANDING_NAMES]
    ordered = named or candidates
    fallback = dict(ordered[0])
    last_origin = "empty"
    for category in ordered:
        category_id = str(category.get("category_id") or "")
        if not category_id:
            continue
        try:
            items, origin = get_category_streams(source, kind, client, category_id, use_cache=True, wait_for_server=True)
        except Exception:
            items, origin = [], "error"
        last_origin = origin
        if items:
            return list(items)[:maximum], dict(category), origin
    return [], fallback, last_origin


def _stalker_home_added_key(item):
    """Stable chronological key for portal variants with absent/malformed dates."""
    try:
        value = (item or {}).get("added") or (item or {}).get("last_modified") or 0
        return int(float(str(value).strip() or "0"))
    except Exception:
        return 0


def _tag_stalker_home_items(items, kind):
    tagged = []
    for item in list(items or []):
        if not isinstance(item, dict):
            continue
        entry = dict(item)
        entry["_tivimate_home_kind"] = kind
        tagged.append(entry)
    tagged.sort(key=_stalker_home_added_key, reverse=True)
    return tagged


def get_stalker_home_items(source, client, limit=6):
    """Return a balanced, compact Home preview of VOD and Series for Stalker.

    Each kind is resolved through a real permitted package, never through an
    unfiltered provider-wide endpoint.  The method deliberately knows nothing
    about a portal URL, MAC address, package name or category identifier.
    """
    if not _is_stalker(source):
        return []
    try:
        maximum = max(1, int(limit))
    except Exception:
        maximum = 6

    movies, _movie_package, _movie_origin = get_stalker_landing_items(
        source, "vod", client, categories=None, limit=maximum
    )
    series, _series_package, _series_origin = get_stalker_landing_items(
        source, "series", client, categories=None, limit=maximum
    )
    movies = _tag_stalker_home_items(movies, "vod")
    series = _tag_stalker_home_items(series, "series")

    # Reserve an equal first share so both library types are visible.  Any
    # unused slots are then filled by the newest remaining valid items.
    share = maximum // 2
    movie_head = movies[:share]
    series_head = series[:share]
    output = []
    for index in range(max(len(movie_head), len(series_head))):
        if index < len(movie_head):
            output.append(movie_head[index])
        if index < len(series_head):
            output.append(series_head[index])

    if len(output) < maximum:
        remainder = movies[len(movie_head):] + series[len(series_head):]
        remainder.sort(key=_stalker_home_added_key, reverse=True)
        output.extend(remainder[:maximum - len(output)])
    return output[:maximum]


def prefetch_allowed_series(source):
    """Warm enabled series categories sequentially in background. Never blocks UI."""
    if not source or source.get("type") not in ("xtream", "stalker"):
        return
    skey = source_filter_key(source)
    if skey in _PREFETCHING:
        return
    entry = load_all_filters().get(skey, {})
    allowed = entry.get("series")
    if allowed is None or not allowed:
        return
    # Keep saved order; it usually reflects the user's selected category order.
    category_ids = [str(x) for x in allowed if str(x)]
    _PREFETCHING.add(skey)
    def worker():
        try:
            from .core import get_source_client
            client = get_source_client(dict(source))
            # First three categories get priority, then the rest.
            for cid in category_ids:
                try:
                    path = _cache_path(source, "series", cid)
                    data, age = _load_cache_state(path)
                    if data is None:
                        items = list(client.streams("series", cid) or [])
                        key = "%s|series|%s" % (skey, cid)
                        _RAM_STREAM_CACHE[key] = list(items)
                        _save_cache(path, items)
                    elif age is not None and age > CACHE_TTL:
                        _refresh_category(dict(source), "series", cid, client)
                except Exception:
                    continue
                time.sleep(0.15)
        finally:
            _PREFETCHING.discard(skey)
    t = threading.Thread(target=worker, name="TiviMateSeriesPrefetch")
    t.daemon = True
    t.start()

def prefetch_selected_categories(source, selected_by_kind=None):
    """Warm only newly selected categories after saving a filter.

    The caller returns to the UI immediately.  Existing disk/RAM entries are
    reused, while a cold category is fetched one by one in a daemon thread.
    This keeps applying a filter local and avoids a blocking full reload.
    """
    if not source:
        return
    source_copy = dict(source)
    source_type = source_copy.get("type")
    if source_type not in ("xtream", "stalker"):
        return
    configured = selected_by_kind or load_all_filters().get(source_filter_key(source_copy), {})
    jobs = []
    for kind, category_ids in (configured or {}).items():
        if kind not in ("live", "vod", "series"):
            continue
        for category_id in category_ids or []:
            cid = str(category_id or "").strip()
            if cid:
                jobs.append((kind, cid))
    if not jobs:
        return
    job_key = "%s|filter-warm|%s" % (source_filter_key(source_copy), "|".join("%s:%s" % pair for pair in jobs))
    if job_key in _PREFETCHING:
        return
    _PREFETCHING.add(job_key)

    def worker():
        try:
            from .core import get_source_client
            client = get_source_client(source_copy)
            for kind, category_id in jobs:
                try:
                    get_category_streams(source_copy, kind, client, category_id, use_cache=True, wait_for_server=True)
                except Exception:
                    pass
                # Be considerate of lower-powered receivers and provider limits.
                time.sleep(0.10)
        finally:
            _PREFETCHING.discard(job_key)

    thread = threading.Thread(target=worker, name="TiviMateFilterWarm")
    thread.daemon = True
    thread.start()


def get_filtered_streams(source, kind, client, use_cache=True):
    """Return a locally cached catalog before touching the provider.

    An unfiltered source uses one aggregate cache file.  Fresh data is returned
    immediately; expired data remains usable while a daemon thread refreshes it.
    Category-filtered sources keep the existing per-category cache behaviour.
    """
    allowed = get_allowed_category_ids(source, kind)
    if _is_stalker(source) and allowed is None:
        return []
    if allowed is None:
        key = _catalog_key(source, kind)
        path = _catalog_cache_path(source, kind)
        memory = _RAM_CATALOG_CACHE.get(key) if use_cache else None
        if memory is not None:
            items, loaded_at = memory
            if time.time() - loaded_at > CACHE_TTL:
                _refresh_catalog(dict(source), kind)
            return list(items or [])
        if use_cache:
            items, age = _load_cache_state(path)
            if items is not None:
                _RAM_CATALOG_CACHE[key] = (list(items), time.time() - float(age or 0))
                if age is not None and age > CACHE_TTL:
                    _refresh_catalog(dict(source), kind)
                return list(items)
        # Cold cache: this function is normally invoked from the screen worker.
        # Persist the result so every later entry can be rendered immediately.
        items = list(client.streams(kind) or [])
        _RAM_CATALOG_CACHE[key] = (list(items), time.time())
        if use_cache:
            _save_cache(path, items)
        return items
    if not allowed:
        return []

    rows = []
    seen = set()
    for cid in sorted(allowed):
        path = _cache_path(source, kind, cid)
        items = _load_cache(path) if use_cache else None
        if items is None:
            items, _origin = get_category_streams(source, kind, client, cid, use_cache=use_cache)
        for item in items:
            sid = str(item.get("stream_id") or item.get("series_id") or item.get("num") or "")
            item_key = sid or (str(item.get("name") or item.get("title") or "") + "|" + str(item.get("category_id") or ""))
            if item_key in seen:
                continue
            seen.add(item_key)
            rows.append(item)
    return rows
