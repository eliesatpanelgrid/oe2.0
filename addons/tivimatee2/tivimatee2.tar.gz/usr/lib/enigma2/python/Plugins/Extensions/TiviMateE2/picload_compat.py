

def connect_picture_data(loader, callback, owner=None, oneshot=False):
    """Connect ePicLoad.PictureData across Enigma2 image variants.

    With ``oneshot=True`` the callback disconnects itself immediately after the
    first decode notification.  This is important for short-lived ePicLoad
    instances used by poster/category navigation: keeping every signal
    connection alive on the Screen eventually exhausts receiver resources.
    """
    try:
        signal = loader.PictureData
    except Exception:
        return None

    if not oneshot:
        try:
            callbacks = signal.get()
            callbacks.append(callback)
            return callback
        except Exception:
            pass
        try:
            connection = signal.connect(callback)
            if owner is not None:
                connections = getattr(owner, "_picload_connections", None)
                if connections is None:
                    connections = []
                    setattr(owner, "_picload_connections", connections)
                connections.append(connection)
            return connection
        except Exception:
            return None

    state = {"callbacks": None, "connection": None, "wrapper": None}

    def wrapper(*args, **kwargs):
        try:
            callback(*args, **kwargs)
        finally:
            callbacks = state.get("callbacks")
            if callbacks is not None:
                try:
                    callbacks.remove(state.get("wrapper"))
                except Exception:
                    pass
            connection = state.get("connection")
            if connection is not None:
                try:
                    connection.disconnect()
                except Exception:
                    pass
                if owner is not None:
                    try:
                        connections = getattr(owner, "_picload_connections", None)
                        if connections is not None and connection in connections:
                            connections.remove(connection)
                    except Exception:
                        pass

    state["wrapper"] = wrapper

    try:
        callbacks = signal.get()
        callbacks.append(wrapper)
        state["callbacks"] = callbacks
        return wrapper
    except Exception:
        pass

    try:
        connection = signal.connect(wrapper)
        state["connection"] = connection
        if owner is not None:
            connections = getattr(owner, "_picload_connections", None)
            if connections is None:
                connections = []
                setattr(owner, "_picload_connections", connections)
            connections.append(connection)
        return connection
    except Exception:
        return None
