# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, re
import requests
from bs4 import BeautifulSoup
from six.moves.urllib.parse import quote_plus
from ..seeker import SubtitlesDownloadError, SubtitlesErrors

BASE = 'https://www.addic7ed.com'
HDR = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/133 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.8',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
}
TIMEOUT = 8


def _norm(x):
    return re.sub(r'[^a-z0-9]+', '', (x or '').lower())


def _valid_year(text, year):
    if not year:
        return True
    ys = re.findall(r'(?:19|20)\d{2}', text or '')
    return not ys or str(year) in ys


def _uniq(seq):
    out, seen = [], set()
    for value in seq:
        if value and value not in seen:
            seen.add(value)
            out.append(value)
    return out


def _series_urls(tvshow, year, season, episode):
    """Build current Addic7ed episode URLs without doing any extra request."""
    names = [tvshow or '']
    # Addic7ed keeps some remakes under "Title (YEAR)". Try that form too,
    # but only as a fallback candidate and keep the normal title first.
    if year and tvshow and str(year) not in tvshow:
        names.append('%s (%s)' % (tvshow, year))
    urls = []
    for name in names:
        slug = quote_plus(name).replace('+', '%20')
        urls.append(BASE + '/serie/%s/%s/%s/addic7ed' % (slug, int(season), int(episode)))
    return _uniq(urls)


def _movie_urls(title, year):
    """Search movies using Addic7ed's current srch.php endpoint."""
    q = quote_plus(title or '')
    url = BASE + '/srch.php?Submit=Search&search=' + q
    r = requests.get(url, headers=HDR, timeout=TIMEOUT)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, 'html.parser')
    wanted = _norm(title)
    out = []

    for a in soup.find_all('a', href=True):
        href = a.get('href') or ''
        # Current movie pages use /movie/<numeric id>.
        if not re.search(r'(?:^|/)movie/\d+', href, re.I):
            continue

        # Search result titles can be on a sibling/parent rather than inside
        # the anchor itself (image links are common), so inspect the result row.
        container = a.find_parent('tr') or a.parent
        text = container.get_text(' ', strip=True) if container else a.get_text(' ', strip=True)
        if wanted and wanted not in _norm(text):
            continue
        if not _valid_year(text, year):
            continue
        out.append(requests.compat.urljoin(BASE, href))

    # If the page uses an image anchor whose parent text is incomplete, accept
    # exact /movie/ links from a single-result search as a conservative fallback.
    if not out:
        candidates = []
        for a in soup.find_all('a', href=True):
            href = a.get('href') or ''
            if re.search(r'(?:^|/)movie/\d+', href, re.I):
                candidates.append(requests.compat.urljoin(BASE, href))
        candidates = _uniq(candidates)
        if len(candidates) == 1:
            out = candidates

    return _uniq(out)[:3]


def _page_urls(title, tvshow, year, season, episode):
    if tvshow:
        return _series_urls(tvshow, year, season, episode)
    return _movie_urls(title, year)


def _parse_page(url, wanted, video, year):
    r = requests.get(url, headers=HDR, timeout=TIMEOUT)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, 'html.parser')
    results = []

    # Addic7ed subtitle versions are table rows. Keep language, release and
    # download link from the same row so results cannot be cross-paired.
    for tr in soup.find_all('tr'):
        text = ' '.join(tr.stripped_strings)
        if not text or not _valid_year(text, year):
            continue

        normalized_text = _norm(text)
        lang = None
        for w in wanted:
            if w and _norm(w) in normalized_text:
                lang = w
                break
        if not lang:
            continue

        dl = None
        for a in tr.find_all('a', href=True):
            href = a.get('href') or ''
            anchor_text = a.get_text(' ', strip=True).lower()
            if ('download' in anchor_text or '/original/' in href.lower() or
                    '/updated/' in href.lower()):
                dl = requests.compat.urljoin(BASE, href)
                break
        if not dl:
            continue

        m = re.search(r'Version\s+(.+?)(?:,\s*Duration:|\s+Duration:|$)', text, re.I)
        release = m.group(1).strip() if m else text[:120]
        sync = False
        video_name = _norm(os.path.basename(video or ''))
        release_norm = _norm(release)
        if release_norm and video_name and release_norm in video_name:
            sync = True

        results.append({
            'filename': release,
            'sync': sync,
            'link': dl,
            'language_name': lang,
            'rating': '0',
            '_referer': url,
        })
    return results


def search_subtitles(file_original_path, title, tvshow, year, season, episode,
                     set_temp, rar, lang1, lang2, lang3, stack):
    wanted = [x for x in (lang1, lang2, lang3) if x]
    out = []
    errors = []
    try:
        urls = _page_urls(title, tvshow, year, season, episode)
    except Exception as e:
        return [], '', str(e)

    # One bad candidate must not abort all fallbacks (important for remakes
    # where Addic7ed may require the year in the show name).
    for url in urls:
        try:
            out.extend(_parse_page(url, wanted, file_original_path, year))
            if out and tvshow:
                break
        except Exception as e:
            errors.append(str(e))
            continue

    seen, clean = set(), []
    for item in out:
        key = (_norm(item.get('language_name')), _norm(item.get('filename')), item.get('link'))
        if key not in seen:
            seen.add(key)
            clean.append(item)
    clean.sort(key=lambda x: not x.get('sync', False))

    if clean:
        return clean, '', ''
    return [], '', (errors[-1] if errors else '')


def _validate(data, ctype):
    h = (data or b'')[:512].lstrip().lower()
    ct = (ctype or '').lower()
    if not data or b'<html' in h or b'<!doctype html' in h or 'text/html' in ct:
        raise ValueError('HTML/error page returned')
    if data[:4].startswith(b'PK\x03\x04'):
        return 'zip'
    if data[:4].startswith(b'Rar!'):
        return 'rar'
    return 'srt'


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    item = subtitles_list[pos]
    lang = item.get('language_name', '')
    try:
        headers = dict(HDR)
        if item.get('_referer'):
            headers['Referer'] = item.get('_referer')
        r = requests.get(item['link'], headers=headers, timeout=TIMEOUT, allow_redirects=True)
        r.raise_for_status()
        kind = _validate(r.content, r.headers.get('Content-Type', ''))
        if not os.path.exists(tmp_sub_dir):
            os.makedirs(tmp_sub_dir)
        path = os.path.join(tmp_sub_dir, re.sub(r'[\\/]', '_', zip_subs))
        with open(path, 'wb') as fh:
            fh.write(r.content)
        return True, lang, kind
    except Exception as e:
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, str(e))
