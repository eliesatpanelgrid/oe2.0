# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

import os
import re
try:
    from urllib.parse import quote_plus, urljoin
except ImportError:
    from urllib import quote_plus
    from urlparse import urljoin

import requests
from bs4 import BeautifulSoup

from ..seeker import SubtitlesDownloadError, SubtitlesErrors
from ..utilities import log
from ..Subf2m.Subf2mUtilities import LANGUAGES

BASE = 'https://www.tvsubs.net/'
UA = 'Mozilla/5.0 (X11; Linux) AppleWebKit/537.36 Chrome/122 Safari/537.36'
TIMEOUT = 12

LANG_BY_2 = dict((x[2].lower(), x[0]) for x in LANGUAGES)
LANG_BY_3 = dict((x[3].lower(), x[0]) for x in LANGUAGES)
LANG_ALIASES = {
    'gr': 'Greek', 'el': 'Greek', 'pb': 'PortugueseBrazil', 'pt-br': 'PortugueseBrazil',
    'br': 'PortugueseBrazil', 'ua': 'Ukrainian', 'cz': 'Czech', 'dk': 'Danish',
}


def _session():
    s = requests.Session()
    s.headers.update({'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9'})
    return s


def _get(s, url):
    r = s.get(url, timeout=TIMEOUT, allow_redirects=True)
    r.raise_for_status()
    return r


def _clean_name(v):
    v = (v or '').strip().lower()
    v = re.sub(r'\(\d{4}\)$', '', v).strip()
    v = re.sub(r'[^a-z0-9]+', ' ', v)
    return ' '.join(v.split())


def _language_from_li(li):
    # TVsubs puts a short language flag code (en/ar/de/...) inside each row.
    for img in li.find_all('img'):
        vals = [img.get('alt', ''), img.get('title', ''), img.get('src', '')]
        blob = ' '.join(vals).lower()
        m = re.search(r'(?:^|[^a-z])([a-z]{2,3})(?:[^a-z]|$)', blob)
        if m:
            code = m.group(1)
            if code in LANG_ALIASES:
                return LANG_ALIASES[code]
            if code in LANG_BY_2:
                return LANG_BY_2[code]
            if code in LANG_BY_3:
                return LANG_BY_3[code]
    # Fallback: infer from nearest heading, e.g. "Arabic subtitles".
    h = li.find_previous(['h1','h2','h3','h4','div','strong'])
    if h:
        text = h.get_text(' ', strip=True)
        m = re.search(r'([A-Za-z]+)\s+subtitles', text, re.I)
        if m:
            return m.group(1).capitalize()
    return ''


def _wanted_langs(lang1, lang2, lang3):
    out=[]
    for x in (lang1, lang2, lang3):
        x=(x or '').strip()
        if x and x.lower() not in [y.lower() for y in out]:
            out.append(x)
    return out


def _find_show(s, query, season, year=''):
    url = BASE + 'search.php?q=' + quote_plus(query)
    soup = BeautifulSoup(_get(s, url).text, 'html.parser')
    qn = _clean_name(query)
    best = None
    best_score = -1
    for a in soup.find_all('a', href=True):
        href = a.get('href','')
        m = re.search(r'tvshow-(\d+)-(\d+)\.html', href)
        if not m:
            continue
        name = a.get_text(' ', strip=True)
        nn = _clean_name(name)
        score = 0
        if nn == qn: score += 100
        elif qn and (qn in nn or nn in qn): score += 50
        score -= abs(len(nn)-len(qn))
        if year and str(year) in name: score += 10
        if score > best_score:
            best_score = score
            best = m.group(1)
    if not best:
        return None
    return urljoin(BASE, 'tvshow-%s-%d.html' % (best, int(season or 1)))


def _find_episode_url(s, season_url, episode):
    soup = BeautifulSoup(_get(s, season_url).text, 'html.parser')
    ep = int(episode or 0)
    # Episode links are episode-<id>.html; match the visible row number first.
    for a in soup.find_all('a', href=True):
        href=a.get('href','')
        if not re.search(r'episode-\d+\.html', href):
            continue
        parent = a.find_parent('li')
        text = parent.get_text(' ', strip=True) if parent else a.get_text(' ', strip=True)
        m = re.match(r'\s*(\d{1,3})\.', text)
        if m and int(m.group(1)) == ep:
            return urljoin(BASE, href)
    # Fallback: nth episode link on the season page.
    links=[]
    for a in soup.find_all('a', href=True):
        if re.search(r'episode-\d+\.html', a.get('href','')):
            links.append(urljoin(BASE, a.get('href')))
    if 1 <= ep <= len(links):
        return links[ep-1]
    return None


def _episode_subs(s, episode_url, wanted, filename=''):
    soup = BeautifulSoup(_get(s, episode_url).text, 'html.parser')
    wanted_l = set(x.lower() for x in wanted)
    out=[]
    for a in soup.find_all('a', href=True):
        href=a.get('href','')
        m=re.search(r'subtitle-(\d+)\.html', href)
        if not m:
            continue
        li=a.find_parent('li')
        if li is None:
            continue
        language=_language_from_li(li)
        if wanted_l and language.lower() not in wanted_l:
            continue
        release=a.get_text(' ', strip=True) or ('TVsubs subtitle %s' % m.group(1))
        # Site detail page exposes the exact .srt filename, but release text is enough for matching.
        sync=False
        if filename:
            f=_clean_name(os.path.basename(filename))
            r=_clean_name(release)
            sync = bool(f and r and (f in r or r in f))
        out.append({
            'filename': release + '.zip',
            'language_name': language or 'English',
            'sync': sync,
            'rating': '0',
            'tvsubs_id': m.group(1),
            'detail_url': urljoin(BASE, href),
            'download_url': urljoin(BASE, 'download-%s.html' % m.group(1)),
        })
    return out


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    # TVsubs.net is TV-series only. Ignore movie searches entirely.
    query = (tvshow or '').strip()
    if not query or not season or not episode:
        return [], '', ''
    wanted=_wanted_langs(lang1,lang2,lang3)
    s=_session()
    try:
        season_url=_find_show(s, query, season, year)
        if not season_url:
            return [], '', ''
        episode_url=_find_episode_url(s, season_url, episode)
        if not episode_url:
            return [], '', ''
        items=_episode_subs(s, episode_url, wanted, file_original_path or title or query)
        items.sort(key=lambda x: (not x.get('sync',False), x.get('filename','').lower()))
        return items, '', ''
    except Exception as e:
        log(__name__, 'TVsubs search failed: %s' % e)
        return [], '', 'TVsubs: %s' % e


def _extract_redirect(html, current_url):
    soup=BeautifulSoup(html, 'html.parser')
    meta=soup.find('meta', attrs={'http-equiv': re.compile('refresh', re.I)})
    if meta:
        content=meta.get('content','')
        m=re.search(r'url\s*=\s*[\"\']?([^\"\';]+)', content, re.I)
        if m:
            return urljoin(current_url, m.group(1).strip())
    for pat in (r'window\.location(?:\.href)?\s*=\s*[\"\']([^\"\']+)',
                r'location\.href\s*=\s*[\"\']([^\"\']+)',
                r'href=[\"\']([^\"\']+\.zip(?:\?[^\"\']*)?)[\"\']'):
        m=re.search(pat, html, re.I)
        if m:
            return urljoin(current_url, m.group(1))
    return None


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    item=subtitles_list[pos]
    s=_session()
    url=item.get('download_url')
    try:
        r=_get(s,url)
        data=r.content
        ctype=(r.headers.get('Content-Type') or '').lower()
        # Some TVsubs downloads first return a 0-second HTML redirect.
        for _ in range(3):
            stripped=data.lstrip()
            if data.startswith(b'PK\x03\x04') or 'zip' in ctype:
                break
            if stripped[:32].lower().startswith(b'<!doctype html') or stripped[:16].lower().startswith(b'<html') or 'text/html' in ctype:
                html=data.decode('utf-8','ignore')
                nxt=_extract_redirect(html, r.url)
                if not nxt:
                    raise Exception('download redirect not found')
                r=_get(s,nxt)
                data=r.content
                ctype=(r.headers.get('Content-Type') or '').lower()
                continue
            break
        if not data.startswith(b'PK\x03\x04'):
            raise Exception('provider did not return a ZIP archive')
        with open(zip_subs,'wb') as f:
            f.write(data)
        return True, item.get('language_name','English'), 'zip'
    except Exception as e:
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, 'TVsubs download failed: %s' % e)
