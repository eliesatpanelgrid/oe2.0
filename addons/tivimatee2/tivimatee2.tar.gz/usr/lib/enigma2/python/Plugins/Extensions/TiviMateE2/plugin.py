from Plugins.Plugin import PluginDescriptor
from .ui import TiviMateE2Home


def main(session, **kwargs):
    """Open TiviMate E2 directly in its lightweight IPTV mode."""
    session.open(TiviMateE2Home)


def Plugins(**kwargs):
    return [PluginDescriptor(
        name="TiviMate E2",
        description="Independent Xtream, M3U and Stalker client for Enigma2",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="icons/plugin.png",
        fnc=main,
    )]
