from Plugins.Plugin import PluginDescriptor
from .ui import TiviMateE2Home


def _sync_epgimport(background=True, refresh_local=True, **kwargs):
    try:
        from .core import get_sources
        from .epgimport_sync import sync_epgimport_sources
        from .epg_local import refresh_all_sources
        sources = get_sources()
        sync_epgimport_sources(sources, background=background)
        if refresh_local:
            refresh_all_sources(sources, background=background)
    except Exception:
        pass


def main(session, **kwargs):
    """Open TiviMate E2."""
    # Do not start a second XMLTV download when the user opens the app.
    # Session-start maintenance keeps the cache fresh.
    _sync_epgimport(background=True, refresh_local=False)
    session.open(TiviMateE2Home)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="TiviMate E2",
            description="Independent Xtream, M3U and Stalker client for Enigma2",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icons/plugin.png",
            fnc=main,
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=_sync_epgimport,
        ),
    ]
