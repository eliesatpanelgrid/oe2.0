# Load TiviMateE2's namespaced player keymap (Ultra/XStreamity-style TV key mapping).
try:
    import os
    import keymapparser
    _KEYMAP = os.path.join(os.path.dirname(__file__), "keymap.xml")
    if os.path.isfile(_KEYMAP):
        keymapparser.readKeymap(_KEYMAP)
except Exception:
    pass

from .cache_manager import migrate_legacy_logs, migrate_legacy_tmp_cache, cleanup_stale_temp_files
try:
    migrate_legacy_logs()
    migrate_legacy_tmp_cache()
    cleanup_stale_temp_files()
except Exception:
    pass
from Plugins.Plugin import PluginDescriptor
from .ui import TiviMateE2Home
try:
    from .action_trace import log_action
    log_action("plugin_loaded", ["Plugin"], None, "START")
except Exception:
    pass


def _sync_epgimport(background=True, refresh_local=True, **kwargs):
    """Refresh TiviMateE2 internal Xtream EPG only.

    r448: EPGImport integration is intentionally disabled.  The historical
    function name is kept to avoid changing callers/hooks, but it now only
    refreshes the plugin's own HDD/USB XMLTV -> epg.json cache.
    """
    try:
        from .core import get_sources
        from .epg_local import refresh_all_sources
        sources = get_sources()
        if refresh_local:
            refresh_all_sources(sources, background=background)
    except Exception:
        pass



def _session_start(reason=0, session=None, **kwargs):
    """Session maintenance: EPG refresh plus the lightweight LAN web manager."""
    if reason not in (0, None):
        try:
            from .memory_manager import stop as stop_memory_manager
            stop_memory_manager()
        except Exception:
            pass
        try:
            from .web_manager import stop_web_manager
            stop_web_manager()
        except Exception:
            pass
        return
    _sync_epgimport(background=True, refresh_local=True)
    try:
        from .memory_manager import start as start_memory_manager
        start_memory_manager()
    except Exception:
        pass
    try:
        from .web_manager import start_web_manager
        start_web_manager()
    except Exception:
        pass


def main(session, **kwargs):
    """Open TiviMate E2."""
    # Do not start a second XMLTV download when the user opens the app.
    # Session-start maintenance keeps the cache fresh.
    _sync_epgimport(background=True, refresh_local=False)
    try:
        import threading
        from .ui import run_auto_backup_if_due
        threading.Thread(target=run_auto_backup_if_due, kwargs={"force": False}, daemon=True).start()
    except Exception:
        pass
    session.open(TiviMateE2Home)


def menu(menuid, **kwargs):
    """Expose TiviMate IPTV in the Enigma2 main menu."""
    if menuid != "mainmenu":
        return []
    return [("TiviMate IPTV", main, "TiviMateE2", 45)]


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="TiviMate E2",
            description="Independent Xtream, M3U and Stalker client for Enigma2",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icons/plugin.png",
            fnc=main,
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_MENU,
            fnc=menu,
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=_session_start,
        ),
    ]
