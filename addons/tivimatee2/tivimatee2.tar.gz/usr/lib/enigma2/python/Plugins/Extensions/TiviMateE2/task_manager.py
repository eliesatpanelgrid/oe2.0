# -*- coding: utf-8 -*-
"""Bounded, keyed background task manager.

Newest keyed work wins. Stale queued tasks are skipped before execution, which
prevents fast navigation from building a large backlog of obsolete portal/TMDb
jobs. Worker count and queue size are intentionally small for Enigma2 boxes.
"""
import threading
try:
    import queue
except Exception:
    import Queue as queue
from .diagnostics import event, timer

class TaskManager(object):
    def __init__(self, name="TiviMate", workers=4, max_pending=96):
        self.name = str(name)
        self.queue = queue.Queue(maxsize=max(8, int(max_pending)))
        self.lock = threading.RLock()
        self.latest = {}
        self.started = False
        self.workers = max(1, min(6, int(workers)))

    def _ensure(self):
        with self.lock:
            if self.started:
                return
            self.started = True
            for idx in range(self.workers):
                t = threading.Thread(target=self._worker, name="%sTask-%d" % (self.name, idx + 1))
                t.daemon = True
                t.start()

    def submit(self, target, args=(), key=None, area="background"):
        self._ensure()
        generation = 0
        if key is not None:
            with self.lock:
                generation = int(self.latest.get(key, 0) or 0) + 1
                self.latest[key] = generation
        try:
            self.queue.put_nowait((target, tuple(args or ()), key, generation, str(area)))
            return generation or True
        except Exception:
            event("tasks", "queue_full", manager=self.name, task_area=area, key=key or "")
            return False

    def cancel(self, key):
        if key is None:
            return
        with self.lock:
            self.latest[key] = int(self.latest.get(key, 0) or 0) + 1

    def active(self, key, generation):
        if key is None:
            return True
        with self.lock:
            return int(self.latest.get(key, 0) or 0) == int(generation or 0)

    def _worker(self):
        while True:
            try:
                target, args, key, generation, area = self.queue.get()
            except Exception:
                continue
            try:
                if key is not None and not self.active(key, generation):
                    event("tasks", "stale_skip", manager=self.name, task_area=area, key=key)
                    continue
                done = timer("tasks", "run", manager=self.name, task_area=area, key=key or "")
                try:
                    target(*args)
                    done("ok")
                except Exception as exc:
                    done("error", error=exc.__class__.__name__)
            finally:
                try:
                    self.queue.task_done()
                except Exception:
                    pass

CONTENT_TASKS = TaskManager("TiviMateContent", workers=4, max_pending=128)
MAINTENANCE_TASKS = TaskManager("TiviMateMaint", workers=1, max_pending=16)
