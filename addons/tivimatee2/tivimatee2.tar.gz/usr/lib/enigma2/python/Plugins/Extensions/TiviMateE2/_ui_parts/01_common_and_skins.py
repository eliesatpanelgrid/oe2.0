def _home_tmdb_cache_load():
    try:
        with _HOME_TMDb_CACHE_LOCK:
            with open(HOME_TMDb_CACHE_FILE, "r") as h:
                data = json.load(h) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def _home_tmdb_cache_get(mode):
    row = _home_tmdb_cache_load().get(str(mode or "popular_movies")) or {}
    items = row.get("items") if isinstance(row, dict) else []
    return [dict(x) for x in (items or []) if isinstance(x, dict)]

def _home_tmdb_cache_put(mode, items):
    rows = [dict(x) for x in (items or []) if isinstance(x, dict)]
    if not rows:
        return False
    try:
        data = _home_tmdb_cache_load()
        data[str(mode or "popular_movies")] = {
            "updated": int(time.time()),
            "items": rows[:12],
        }
        with _HOME_TMDb_CACHE_LOCK:
            folder = os.path.dirname(HOME_TMDb_CACHE_FILE)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = HOME_TMDb_CACHE_FILE + ".tmp"
            with open(tmp, "w") as h:
                json.dump(data, h, separators=(",", ":"), sort_keys=True)
            os.replace(tmp, HOME_TMDb_CACHE_FILE)
        return True
    except Exception:
        return False

HOME_SERVER_2026_ROTATION_FILE = data_path("home_server_2026_rotation.json")
_HOME_SERVER_2026_ROTATION_LOCK = threading.Lock()
_HOME_SERVER_2026_SLOT_SECONDS = 6 * 60 * 60
_HOME_SERVER_TRENDING_SLOT_SECONDS = 6 * 60 * 60


def _home_server_filter_cache_mode(source, mode):
    """Bind server-backed Home caches to the current package-filter selection.

    This prevents Popular/You Might Like rows built before a filter change from
    leaking hidden packages back into Home. TMDb-only feeds are unaffected.
    """
    mode = str(mode or "popular_movies")
    kind = "series" if mode in ("popular_series", "trending_series") else "vod"
    try:
        allowed = get_allowed_category_ids(source or {}, kind)
    except Exception:
        allowed = None
    if allowed is None:
        sig_raw = "ALL"
    else:
        sig_raw = ",".join(sorted(str(x) for x in allowed if str(x))) or "NONE"
    try:
        sig = hashlib.sha1(sig_raw.encode("utf-8", "ignore")).hexdigest()[:10]
    except Exception:
        sig = str(abs(hash(sig_raw)))[:10]
    return "%s_pf_%s" % (mode, sig)

def _home_server_2026_source_key(source):
    source = source or {}
    raw = "|".join([
        str(source.get("type") or ""),
        str(source.get("name") or ""),
        str(source.get("url") or source.get("portal") or ""),
        str(source.get("username") or source.get("mac") or ""),
    ])
    try:
        return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()
    except Exception:
        return raw

def _home_server_2026_slot(mode=None):
    seconds = _HOME_SERVER_TRENDING_SLOT_SECONDS if str(mode or "").startswith("trending_") else _HOME_SERVER_2026_SLOT_SECONDS
    return int(time.time() // seconds)

def _home_server_2026_cache_file(source):
    # r183: every IPTV source owns a physical Home cache file. This prevents
    # a server switch from reusing/overwriting another server's 2026 rotation.
    key = _home_server_2026_source_key(source)
    folder = data_path("home_server_2026")
    try:
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
    except Exception:
        pass
    return os.path.join(folder, "%s.json" % key)

def _home_server_2026_cache_load(source):
    path = _home_server_2026_cache_file(source)
    try:
        with _HOME_SERVER_2026_ROTATION_LOCK:
            with open(path, "r") as h:
                data = json.load(h) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def _home_server_2026_cache_get(source, mode):
    try:
        key = str(mode or "popular_movies")
        row = _home_server_2026_cache_load(source).get(key) or {}
        if int(row.get("slot", -1)) != _home_server_2026_slot(key):
            return []
        items = row.get("items") or []
        return [dict(x) for x in items if isinstance(x, dict)][:6]
    except Exception:
        return []

def _home_server_2026_cache_get_any(source, mode):
    """Return the last saved row even when its rotation slot is stale.

    Used only for instant first paint.  The caller still refreshes in the
    background and replaces this stale row when the current slot is ready.
    """
    try:
        key = str(mode or "popular_movies")
        row = _home_server_2026_cache_load(source).get(key) or {}
        items = row.get("items") or []
        return [dict(x) for x in items if isinstance(x, dict)][:6]
    except Exception:
        return []

def _home_server_2026_cache_put(source, mode, items):
    rows = [dict(x) for x in (items or []) if isinstance(x, dict)][:6]
    if not rows:
        return False
    try:
        path = _home_server_2026_cache_file(source)
        key = str(mode or "popular_movies")
        data = _home_server_2026_cache_load(source)
        data[key] = {"slot": _home_server_2026_slot(key), "updated": int(time.time()), "items": rows}
        with _HOME_SERVER_2026_ROTATION_LOCK:
            folder = os.path.dirname(path)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = path + ".tmp"
            with open(tmp, "w") as h:
                json.dump(data, h, separators=(",", ":"), sort_keys=True)
            try:
                os.replace(tmp, path)
            except Exception:
                os.rename(tmp, path)
        return True
    except Exception:
        return False



from .cache_manager import get_cache_dir, get_cache_root, get_settings as get_cache_settings, save_settings as save_cache_settings, clear_cache, cache_status, cleanup_cache, is_internal_cache_active
from .artwork_queue import request_artwork, cached_artwork, prefetch_artwork
from .estalker_picon import direct_picon
from .picload_compat import connect_picture_data
from .display_scale import scale_skin, sx, sy, scale_size

from .package_logos import package_logo_path, package_provider_key, package_logo_for_key
from .core import (
    get_sources, set_sources, write_playlists, PLAYLISTS_FILE,
    XtreamClient, M3UClient, StalkerClient, get_source_client, get_cached_catalog, clear_catalog_memory,
    BASE, load_json, save_json, load_stalker_compat, get_stalker_account_state
)
from .server_status import evaluate_reply
from .task_manager import CONTENT_TASKS

from .tmdb_client import load_settings as load_tmdb_settings, save_settings as save_tmdb_settings, save_backdrop_quality as save_tmdb_backdrop_quality, TMDbClient, IMAGE_BASE, backdrop_url
from .rating_cache import split_ranked, enrich_missing
from .subdl_client import (
    load_settings as load_subdl_settings,
    save_settings as save_subdl_settings,
    LANGUAGE_CHOICES as SUBDL_LANGUAGE_CHOICES,
)
from .filters import (source_filter_key as _source_filter_key, load_all_filters as _load_all_filters,
    save_all_filters as _save_all_filters, get_allowed_category_ids, filter_items as filter_items_for_source,
    filter_categories, get_filtered_streams, get_category_streams, get_category_streams_batch, prefetch_allowed_series,
    prefetch_selected_categories, get_cached_categories, get_recent_preview_items, get_stalker_landing_items, get_stalker_home_items)
from .favorites import (add_favourite, toggle_favourite, is_favourite, list_favourites,
    source_for_record, remove_record, source_id as favourite_source_id, count as favourites_count)
from .update_manager import check_for_update, download_package, install_command, PLUGIN_VERSION, CURRENT_REVISION
from .i18n import tr, get_language, nav_label, save_language, nav_label


def _sync_native_subtitle_language(language_code):
    """Persist one global subtitle language and mirror it to Enigma2 Auto Language."""
    language_code = str(language_code or "").strip().lower()

    # Keep TiviMateE2's VOD player on the same global language.  The player
    # retries this value on its existing playback monitor until the server's
    # embedded subtitle tracks are available.
    try:
        player_state_file = os.path.join(BASE, "vod_player_state_v2.json")
        state = load_json(player_state_file, {}) or {}
        if not isinstance(state, dict):
            state = {}
        state["native_subtitle_lang"] = language_code
        save_json(player_state_file, state)
    except Exception:
        pass

    mapping = {
        "ar": "ara",
        "en": "eng",
        "fr": "fra fre",
        "de": "deu ger",
        "es": "spa",
        "it": "ita",
        "pt": "por",
        "tr": "tur",
        "ru": "rus",
        "fa": "fas per",
        "zh": "zho chi",
    }
    target = mapping.get(language_code, "---")
    try:
        auto = getattr(config, "autolanguage", None)
        setting = getattr(auto, "subtitle_autoselect1", None) if auto is not None else None
        if setting is None:
            return False

        # Prefer the canonical value used by Enigma2. If this image exposes a
        # slightly different choice list, choose the first compatible token.
        value = target
        try:
            choices = getattr(setting, "choices", None) or []
            available = []
            for entry in choices:
                raw = entry[0] if isinstance(entry, (tuple, list)) else entry
                available.append(str(raw))
            if available and value not in available:
                tokens = value.split()
                matched = None
                for option in available:
                    option_tokens = set(option.split())
                    if any(tok in option_tokens for tok in tokens):
                        matched = option
                        break
                if matched:
                    value = matched
        except Exception:
            pass

        setting.value = value
        try:
            setting.save()
        except Exception:
            pass

        # Use Enigma2's native cached subtitle selection after the user chooses a track.
        try:
            # Do not reuse a cached subtitle from another title. The preferred language
            # from Settings #5 is applied fresh by Enigma2 Auto Language.
            usecache = getattr(auto, "subtitle_usecache", None)
            if usecache is not None:
                usecache.value = False
                try:
                    usecache.save()
                except Exception:
                    pass
        except Exception:
            pass

        # Allow Arabic subtitles even when the audio language is also Arabic.
        try:
            equal = getattr(auto, "equal_languages", None)
            if equal is not None and str(getattr(equal, "value", "0")) == "0":
                equal.value = "1"
                try:
                    equal.save()
                except Exception:
                    pass
        except Exception:
            pass

        try:
            configfile.save()
        except Exception:
            pass
        return True
    except Exception:
        return False


PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
CATCHUP_VERIFY_CACHE_FILE = data_path("catchup_verified.json")
HOME_RECENT_CACHE_MAX_AGE = 21600  # 6 hours; stale data can still paint instantly while background refresh runs.

def _home_cache_root():
    """Prefer persistent HDD, then USB/MMC, then internal flash."""
    candidates = (
        "/media/hdd",
        "/media/usb",
        "/media/usb1",
        "/media/usb2",
        "/media/mmc",
    )
    for mount in candidates:
        try:
            real = os.path.realpath(mount)
            if os.path.isdir(mount) and (os.path.ismount(mount) or os.path.ismount(real)) and os.access(mount, os.W_OK | os.X_OK):
                root = data_path("home")
                ensure_dir(root)
                return root
        except Exception:
            pass
    root = data_path("home")
    try:
        ensure_dir(root)
    except Exception:
        pass
    return root

def _home_recent6_file(source, mode):
    """One tiny cache file per source/mode; it contains at most six rows."""
    raw = "%s|%s" % (_source_identity(source or {}), str(mode or "recent_movies"))
    try:
        key = hashlib.sha1(raw.encode("utf-8")).hexdigest()
    except Exception:
        key = hashlib.sha1(str(raw).encode("utf-8")).hexdigest()
    folder = os.path.join(_home_cache_root(), "recent6")
    try:
        ensure_dir(folder)
    except Exception:
        pass
    return os.path.join(folder, "%s.json" % key)

def _home_movie_index_file():
    return os.path.join(_home_cache_root(), "home_movie_index_cache.json")
SUBDL_IMPORT_FILES = [
    "/media/hdd/tivimatee2/key.txt",
    "/media/hdd/key.txt",
    "/media/usb/tivimatee2/key.txt",
    "/media/usb/key.txt",
    "/media/usb2/tivimatee2/key.txt",
    "/media/usb2/key.txt",
    "/media/usb3/tivimatee2/key.txt",
    "/media/usb3/key.txt",
    "/media/mmc/tivimatee2/key.txt",
    "/media/mmc/key.txt",
    "/media/sdcard/tivimatee2/key.txt",
    "/media/sdcard/key.txt",
    "/mnt/hdd/tivimatee2/key.txt",
    "/mnt/hdd/key.txt",
    "/mnt/usb/tivimatee2/key.txt",
    "/mnt/usb/key.txt",
    "/mnt/mmc/tivimatee2/key.txt",
    "/mnt/mmc/key.txt",
    data_path("key.txt"),
    data_path("subdl.key"),
    data_path("key.txt"),
    data_path("subdl.key"),
    "/tmp/tivimatee2/key.txt",
]
SUBDL_LAST_IMPORT_FILE = ""
IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")
INFO_FETCH = os.path.join(PLUGIN_PATH, "info_fetch.py")
PYTHON_EXECUTABLE, PYTHON_COMMAND = python_command()

# Process-local currently playing Live channel identity. This survives closing
# the fullscreen player back to the Live list, unlike a per-screen variable.
_CURRENT_LIVE_CHANNEL = {"source": "", "channel": ""}



def _read_subdl_key_file(path):
    with open_text(path, "rb") as handle:
        raw = handle.read(1025)
    if len(raw) > 1024:
        raise ValueError("too_long")
    try:
        value = raw.decode("utf-8", "ignore")
    except Exception:
        value = str(raw)
    lines = [line.strip() for line in value.replace("\ufeff", "").splitlines() if line.strip()]
    if len(lines) != 1:
        raise ValueError("invalid_content")
    return lines[0]


def _read_subdl_import_key():
    """Read the first valid SubDL key from common HDD/USB/MMC/config locations."""
    global SUBDL_LAST_IMPORT_FILE
    SUBDL_LAST_IMPORT_FILE = ""
    invalid = None
    for path in SUBDL_IMPORT_FILES:
        if not os.path.isfile(path):
            continue
        try:
            value = _read_subdl_key_file(path)
            SUBDL_LAST_IMPORT_FILE = path
            return value
        except ValueError as exc:
            invalid = exc
    if invalid is not None:
        raise invalid
    raise IOError("missing")


def _remove_subdl_import_file():
    path = SUBDL_LAST_IMPORT_FILE
    if not path:
        return False
    try:
        os.remove(path)
        return True
    except Exception:
        return False
# Artwork is now processed by artwork_queue with two background transfers.
# Keep this switch false so legacy screen paths can show cached/queued artwork.
SAFE_TABLE_MODE = False
CHANNEL_SETTINGS_FILE = data_path("channel_settings.json")
LIVE_SOURCE_FILE = data_path("live_source.json")
MAIN_SOURCE_FILE = data_path("active_source.json")
STALKER_HIDDEN_FILE = data_path("stalker_hidden.json")
STALKER_PIN_FILE = data_path("stalker_pin.json")
STALKER_RECENT_FILE = data_path("resume.json")
XTREAM_HIDDEN_FILE = data_path("xtream_hidden.json")
XTREAM_PIN_FILE = data_path("xtream_pin.json")
XTREAM_SERVICE_TYPES_FILE = data_path("xtream_service_types.json")


def _load_xtream_hidden(source):
    data = load_json(XTREAM_HIDDEN_FILE, {}) or {}
    state = data.get(_hidden_source_key(source)) or {}
    return {
        "categories": set(str(x) for x in (state.get("categories") or [])),
        "channels": set(str(x) for x in (state.get("channels") or [])),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }


def _save_xtream_hidden(source, state):
    data = load_json(XTREAM_HIDDEN_FILE, {}) or {}
    data[_hidden_source_key(source)] = {
        "categories": sorted(state.get("categories") or []),
        "channels": sorted(state.get("channels") or []),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }
    return save_json(XTREAM_HIDDEN_FILE, data)


def _load_xtream_pin(source):
    data = load_json(XTREAM_PIN_FILE, {}) or {}
    state = data.get(_hidden_source_key(source)) or {}
    return {
        "pin": str(state.get("pin") or "0000"),
        "categories": set(str(x) for x in (state.get("categories") or [])),
        "channels": set(str(x) for x in (state.get("channels") or [])),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }


def _save_xtream_pin(source, state):
    data = load_json(XTREAM_PIN_FILE, {}) or {}
    data[_hidden_source_key(source)] = {
        "pin": str(state.get("pin") or "0000"),
        "categories": sorted(state.get("categories") or []),
        "channels": sorted(state.get("channels") or []),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }
    return save_json(XTREAM_PIN_FILE, data)


def _load_xtream_service_types(source):
    # Default all Xtream playback types to GStreamer 4097 unless the user
    # has explicitly saved a different per-source engine.
    defaults = {"live": 4097, "vod": 4097, "series": 4097}
    data = load_json(XTREAM_SERVICE_TYPES_FILE, {}) or {}
    saved = data.get(_source_identity(source), {}) if isinstance(data, dict) else {}
    for key in defaults:
        try:
            value = int(saved.get(key, defaults[key]))
            if value in STALKER_SERVICE_TYPE_CHOICES:
                defaults[key] = value
        except Exception:
            pass
    return defaults


def _save_xtream_service_types(source, values):
    data = load_json(XTREAM_SERVICE_TYPES_FILE, {}) or {}
    clean = {}
    for key in ("live", "vod", "series"):
        try: value = int((values or {}).get(key, 4097))
        except Exception: value = 4097
        clean[key] = value if value in STALKER_SERVICE_TYPE_CHOICES else 4097
    data[_source_identity(source)] = clean
    return save_json(XTREAM_SERVICE_TYPES_FILE, data)


def _xtream_service_type(source, kind):
    fallback = 4097
    return int(_load_xtream_service_types(source).get(kind, fallback))


def _load_stalker_recent(source, limit=30):
    data = load_json(STALKER_RECENT_FILE, {}) or {}
    source_key = _source_identity(source)
    rows = []
    for resume_key, row in data.items():
        if not isinstance(row, dict) or row.get("source_type") != "stalker":
            continue
        if row.get("source_key") != source_key:
            continue
        item = row.get("item") or {}
        if not isinstance(item, dict):
            continue
        rows.append((resume_key, row))
    rows.sort(key=lambda pair: int((pair[1] or {}).get("updated", 0)), reverse=True)
    return rows[:max(1, int(limit or 30))]


def _hidden_source_key(source):
    raw = _source_identity(source).encode("utf-8", "ignore")
    return hashlib.sha1(raw).hexdigest()


def _load_stalker_hidden(source):
    data = load_json(STALKER_HIDDEN_FILE, {}) or {}
    state = data.get(_hidden_source_key(source)) or {}
    return {
        "categories": set(str(x) for x in (state.get("categories") or [])),
        "channels": set(str(x) for x in (state.get("channels") or [])),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }


def _save_stalker_hidden(source, state):
    data = load_json(STALKER_HIDDEN_FILE, {}) or {}
    data[_hidden_source_key(source)] = {
        "categories": sorted(state.get("categories") or []),
        "channels": sorted(state.get("channels") or []),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }
    return save_json(STALKER_HIDDEN_FILE, data)



def _load_stalker_pin(source):
    data = load_json(STALKER_PIN_FILE, {}) or {}
    state = data.get(_hidden_source_key(source)) or {}
    return {
        "pin": str(state.get("pin") or "0000"),
        "categories": set(str(x) for x in (state.get("categories") or [])),
        "channels": set(str(x) for x in (state.get("channels") or [])),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }


def _save_stalker_pin(source, state):
    data = load_json(STALKER_PIN_FILE, {}) or {}
    data[_hidden_source_key(source)] = {
        "pin": str(state.get("pin") or "0000"),
        "categories": sorted(state.get("categories") or []),
        "channels": sorted(state.get("channels") or []),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }
    return save_json(STALKER_PIN_FILE, data)


def _adult_source_enabled(source):
    raw = (source or {}).get("adult_enabled", False)
    return str(raw).strip().lower() in ("1", "true", "yes", "on", "enabled")

def _adult_live_name(name):
    text = str(name or "").strip().lower()
    if not text:
        return False
    # Explicit provider markers only. Any 3+ consecutive X catches XXX/XXXX/etc.
    if re.search(r"(^|[^a-z0-9])x{3,}([^a-z0-9]|$)", text, re.I):
        return True
    markers = (
        "adult", "adults only", "adult only", "porn", "porno",
        "pornography", "erotic", "erotica", "playboy", "brazzers",
        "redlight", "red light", u"اباحي", u"إباحي", u"إباحية",
    )
    return any(marker in text for marker in markers)

def _live_item_id(item):
    item = item or {}
    return str(item.get("ch_id") or item.get("stream_id") or item.get("id") or item.get("cmd") or item.get("url") or item.get("name") or "")




def _source_identity(source):
    source = source or {}
    return u"%s|%s|%s|%s" % (
        source.get("type", ""),
        (source.get("url") or source.get("host") or source.get("server") or source.get("portal") or "").rstrip("/"),
        source.get("username", ""),
        source.get("mac", ""),
    )


def _load_live_source(fallback=None):
    sources = get_sources()
    if not sources:
        return fallback
    try:
        with open_text(LIVE_SOURCE_FILE, "r") as handle:
            saved_key = (json.load(handle) or {}).get("key", "")
        for candidate in sources:
            if _source_identity(candidate) == saved_key:
                return candidate
    except Exception:
        pass
    fallback_key = _source_identity(fallback)
    for candidate in sources:
        if _source_identity(candidate) == fallback_key:
            return candidate
    return sources[0]


def _save_live_source(source):
    try:
        ensure_dir(os.path.dirname(LIVE_SOURCE_FILE))
        with open_text(LIVE_SOURCE_FILE, "w") as handle:
            json.dump({"key": _source_identity(source)}, handle)
        return True
    except Exception:
        return False


def _load_main_source(fallback=None):
    """Return the Home/VOD provider independently from the remembered Live provider."""
    sources = get_sources()
    if not sources:
        return fallback
    try:
        with open_text(MAIN_SOURCE_FILE, "r") as handle:
            saved_key = (json.load(handle) or {}).get("key", "")
        for candidate in sources:
            if _source_identity(candidate) == saved_key:
                return candidate
    except Exception:
        pass
    fallback_key = _source_identity(fallback)
    for candidate in sources:
        if _source_identity(candidate) == fallback_key:
            return candidate
    for candidate in sources:
        if candidate.get("type") == "xtream":
            return candidate
    return sources[0]

LIVE_POSTER_INDEX_FILE = data_path("live_poster_index.json")
BEIN_CACHE_FILE = data_path("bein_cache.json")
BEIN_CACHE_MAX_AGE = 1800
_LIVE_POSTER_URLS = None

def _bein_base_source(source):
    source = source or {}
    if source.get("_virtual_bein"):
        if isinstance(source.get("_bein_provider"), dict):
            return dict(source.get("_bein_provider") or {})
        if isinstance(source.get("base_source"), dict):
            return dict(source.get("base_source") or {})
    return dict(source)


def _bein_cache_key(source):
    return _source_identity(_bein_base_source(source))


def _load_bein_cache(source, max_age=BEIN_CACHE_MAX_AGE):
    data = load_json(BEIN_CACHE_FILE, {}) or {}
    row = data.get(_bein_cache_key(source)) or {}
    try:
        stamp = int(row.get("timestamp") or 0)
    except Exception:
        stamp = 0
    items = row.get("items") or []
    if not isinstance(items, list):
        items = []
    fresh = bool(items and stamp and (int(time.time()) - stamp) <= int(max_age))
    return items, fresh, stamp


def _save_bein_cache(source, items):
    data = load_json(BEIN_CACHE_FILE, {}) or {}
    data[_bein_cache_key(source)] = {
        "timestamp": int(time.time()),
        "items": list(items or []),
    }
    # Keep only a small number of server caches on compact receivers.
    if len(data) > 8:
        ordered = sorted(data.items(), key=lambda kv: int((kv[1] or {}).get("timestamp") or 0), reverse=True)[:8]
        data = dict(ordered)
    return save_json(BEIN_CACHE_FILE, data)


def _make_bein_virtual_source(source):
    # Keep the beIN view completely separate from the real provider object.
    # Only the private provider copy is used for fetching/playing channels.
    base = _bein_base_source(source)
    virtual = {
        "type": "bein",
        "name": "beIN SPORTS",
        "service_type": base.get("service_type", 4097),
        "_virtual_bein": True,
        "_bein_provider": base,
    }
    return virtual


def _load_live_poster_urls():
    global _LIVE_POSTER_URLS
    if isinstance(_LIVE_POSTER_URLS, dict):
        return _LIVE_POSTER_URLS
    data = {}
    try:
        with open_text(LIVE_POSTER_INDEX_FILE, "r") as handle:
            raw = json.load(handle) or {}
        if isinstance(raw, dict):
            data = {str(k): str(v) for k, v in raw.items() if k and v}
    except Exception:
        pass
    _LIVE_POSTER_URLS = data
    return _LIVE_POSTER_URLS

def _save_live_poster_url(key, url):
    if not key or not url:
        return
    data = _load_live_poster_urls()
    if data.get(key) == url:
        return
    data[key] = url
    # Keep the index bounded for compact receivers.
    if len(data) > 1200:
        for old_key in list(data.keys())[:len(data) - 1000]:
            data.pop(old_key, None)
    try:
        tmp = LIVE_POSTER_INDEX_FILE + ".tmp"
        with open_text(tmp, "w") as handle:
            json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
        atomic_replace(tmp, LIVE_POSTER_INDEX_FILE)
    except Exception:
        pass

def _live_poster_key(title):
    return re.sub(r"\s+", " ", str(title or "").strip().lower())

def _load_channel_settings():
    # These settings belong strictly to Live playback and the visual interface.
    defaults = {"auto_zap": True, "picon": True, "service_type": 4097, "live_color": "#008080", "live_theme": "turquoise"}
    try:
        with open_text(CHANNEL_SETTINGS_FILE, "r") as f:
            data = json.load(f) or {}
        defaults.update({k: bool(data.get(k, defaults[k])) for k in ("auto_zap", "picon")})
        try:
            defaults["service_type"] = int(data.get("service_type", 4097))
        except Exception:
            defaults["service_type"] = 4097
        color = str(data.get("live_color", defaults["live_color"]) or defaults["live_color"]).strip()
        if color.startswith("#") and len(color) in (7, 9):
            defaults["live_color"] = color
        theme = str(data.get("live_theme", defaults["live_theme"]) or defaults["live_theme"]).strip().lower()
        if theme in ("turquoise", "blue", "green", "gold", "purple", "silver"):
            defaults["live_theme"] = theme
    except Exception:
        pass
    return defaults

def _save_channel_settings(data):
    try:
        folder = os.path.dirname(CHANNEL_SETTINGS_FILE)
        if not os.path.isdir(folder): os.makedirs(folder)
        tmp = CHANNEL_SETTINGS_FILE + ".tmp"
        with open_text(tmp, "w") as f:
            json.dump(data, f)
        os.rename(tmp, CHANNEL_SETTINGS_FILE)
        return True
    except Exception:
        return False



STALKER_SERVICE_TYPES_FILE = data_path("stalker_service_types.json")
STALKER_SERVICE_TYPE_CHOICES = (1, 4097, 5001, 5002)
STREAM_TYPE_CONFIG_CHOICES = [("1", "DVB service (1)"), ("4097", "GStreamer (4097)"), ("5001", "GstPlayer (5001)"), ("5002", "ExtePlayer3 (5002)")]

def _clean_stream_type(value, default=4097):
    try:
        parsed = int(value)
    except Exception:
        parsed = int(default)
    return parsed if parsed in STALKER_SERVICE_TYPE_CHOICES else 4097

def _stalker_service_key(source):
    try:
        return _source_identity(source or {})
    except Exception:
        source = source or {}
        return "%s|%s" % (source.get("portal") or source.get("url") or "", source.get("mac") or "")

def _load_stalker_service_types(source):
    defaults = {"live": 4097, "vod": 4097, "series": 4097}
    try:
        with open_text(STALKER_SERVICE_TYPES_FILE, "r") as handle:
            raw = json.load(handle) or {}
        saved = raw.get(_stalker_service_key(source), {}) if isinstance(raw, dict) else {}
        for name in defaults:
            value = int(saved.get(name, defaults[name]))
            if value in STALKER_SERVICE_TYPE_CHOICES:
                defaults[name] = value
    except Exception:
        pass
    return defaults

def _save_stalker_service_types(source, values):
    try:
        folder = os.path.dirname(STALKER_SERVICE_TYPES_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        raw = {}
        try:
            with open_text(STALKER_SERVICE_TYPES_FILE, "r") as handle:
                loaded = json.load(handle) or {}
                if isinstance(loaded, dict):
                    raw = loaded
        except Exception:
            pass
        clean = {}
        for name in ("live", "vod", "series"):
            value = int((values or {}).get(name, 4097))
            clean[name] = value if value in STALKER_SERVICE_TYPE_CHOICES else 4097
        raw[_stalker_service_key(source)] = clean
        tmp = STALKER_SERVICE_TYPES_FILE + ".tmp"
        with open_text(tmp, "w") as handle:
            json.dump(raw, handle, separators=(",", ":"))
        atomic_replace(tmp, STALKER_SERVICE_TYPES_FILE)
        return True
    except Exception:
        return False

def _stalker_service_type(source, kind):
    return int(_load_stalker_service_types(source).get(kind, 4097))


def _media_service_type(source, kind):
    """Return the saved per-source engine for Live/VOD/Series without forcing 4097."""
    source = source or {}
    source_type = str(source.get("type") or "").lower()
    media_kind = "series" if str(kind or "").lower() in ("series", "episode", "tv") else ("live" if str(kind or "").lower() == "live" else "vod")
    if source_type == "xtream":
        return _xtream_service_type(source, media_kind)
    if source_type == "stalker":
        return _stalker_service_type(source, media_kind)
    return _clean_stream_type(source.get("service_type", 4097))


def _connect_timer(timer, callback):
    """Connect eTimer on DreamOS and OE-A images without duplicate callbacks."""
    try:
        timer.timeout.connect(callback)
        return
    except Exception:
        pass
    try:
        timer.callback.append(callback)
        return
    except Exception:
        pass
    try:
        timer.timeout.get().append(callback)
    except Exception:
        pass


class LiveCategoryMenuList(MenuList):
    """Live packages list with a permanently gold Favorites star.

    The rest of each row keeps the active skin's normal and selected colors,
    so switching Live styles does not alter the existing icons or theme logic.
    """
    def __init__(self, entries=None):
        MenuList.__init__(self, entries or [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 21))
            self.l.setItemHeight(48)
            self.l.setBuildFunc(self._build_entry)
        except Exception:
            pass

    def _build_entry(self, name, category_id):
        name = str(name or "")
        category_id = str(category_id or "")
        result = [(name, category_id)]
        if category_id == "__favorites__":
            result.append(MultiContentEntryText(
                pos=(4, 0), size=(34, 48), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=u"★", color=0x00FFD700,
                color_sel=0x00FFD700
            ))
            label = name.replace(u"★", "").strip()
            result.append(MultiContentEntryText(
                pos=(42, 0), size=(270, 48), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=label
            ))
        else:
            result.append(MultiContentEntryText(
                pos=(4, 0), size=(308, 48), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=name
            ))
        return result

HOME_APPEARANCE_FILE = data_path("home_appearance.json")

def _load_home_appearance():
    # Popular is the default everywhere on a fresh installation.
    data = {
        "skin": "skin2_dark",
        "content": "popular_movies",
        "movies_content": "none",
        "series_content": "none",
        "show_netflix_package": False,
        "show_prime_package": False,
        "poster_style": "original",
    }
    try:
        with open_text(HOME_APPEARANCE_FILE, "r") as f:
            saved = json.load(f)
        _saved_skin = saved.get("skin")
        if _saved_skin == "skin3_accessibility":
            # Accessibility Skin 3 was retired; migrate existing users to Skin 2.
            data["skin"] = "skin2_dark"
        elif _saved_skin in ("reference_home", "skin2_dark"):
            data["skin"] = _saved_skin
        if saved.get("content") in (
            "popular_movies", "popular_series", "trending_movies", "trending_series"
        ):
            data["content"] = saved.get("content")
        if saved.get("movies_content") == "none":
            data["movies_content"] = "none"
        if saved.get("series_content") == "none":
            data["series_content"] = "none"
        data["show_netflix_package"] = bool(saved.get("show_netflix_package", False))
        data["show_prime_package"] = bool(saved.get("show_prime_package", False))
        if saved.get("poster_style") in ("original", "wall_poster", "square", "circle"):
            data["poster_style"] = saved.get("poster_style")
    except Exception:
        pass
    return data

def _save_home_appearance(skin_name, content_mode=None, movies_content=None, series_content=None, show_netflix_package=None, show_prime_package=None, poster_style=None):
    try:
        folder = os.path.dirname(HOME_APPEARANCE_FILE)
        if not os.path.isdir(folder): os.makedirs(folder)
        current = _load_home_appearance()
        payload = {
            "skin": skin_name or current.get("skin", "skin2_dark"),
            "content": content_mode or current.get("content", "popular_movies"),
            "movies_content": movies_content or current.get("movies_content", "none"),
            "series_content": series_content or current.get("series_content", "none"),
            "show_netflix_package": current.get("show_netflix_package", False) if show_netflix_package is None else bool(show_netflix_package),
            "show_prime_package": current.get("show_prime_package", False) if show_prime_package is None else bool(show_prime_package),
            "poster_style": poster_style if poster_style in ("original", "wall_poster", "square", "circle") else current.get("poster_style", "original"),
        }
        tmp = HOME_APPEARANCE_FILE + ".tmp"
        with open_text(tmp, "w") as f:
            json.dump(payload, f)
        os.rename(tmp, HOME_APPEARANCE_FILE)
        return True
    except Exception:
        return False


UPDATE_SETTINGS_FILE = data_path("update_settings.json")

def _load_update_settings():
    defaults = {"auto_check": True}
    try:
        with open_text(UPDATE_SETTINGS_FILE, "r") as handle:
            stored = json.load(handle) or {}
        defaults["auto_check"] = bool(stored.get("auto_check", defaults["auto_check"]))
    except Exception:
        pass
    return defaults


def _save_update_settings(auto_check):
    try:
        folder = os.path.dirname(UPDATE_SETTINGS_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = UPDATE_SETTINGS_FILE + ".tmp"
        with open_text(temporary, "w") as handle:
            json.dump({"auto_check": bool(auto_check)}, handle)
        os.rename(temporary, UPDATE_SETTINGS_FILE)
        return True
    except Exception:
        return False

HOME_SKIN1 = '''<screen name="TiviMateE2Home" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#050C14">
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/home_reference_v4_bg_r77_1920x1080.jpg" alphatest="blend" zPosition="0" />
		<widget name="homeBrandLogo" position="62,10" size="300,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" zPosition="6" />
	<ePixmap position="13,320" size="64,273" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/sidebar_classic_icons_v2.png" alphatest="blend" zPosition="6" />
	<widget name="headline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="subheadline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="logo" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <ePixmap position="335,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="5" />
    <widget name="nav0" position="364,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="490,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="5" />
    <widget name="nav1" position="519,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="645,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="5" />
    <widget name="nav2" position="674,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="800,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="5" />
    <widget name="nav3" position="829,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="955,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="5" />
    <widget name="nav4" position="984,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="1110,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="5" />
    <widget name="nav5" position="1139,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="1265,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="5" />
    <widget name="nav6" position="1294,27" size="111,58" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="1420,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="5" />
    <widget name="nav7" position="1449,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
	<widget name="navSelector" position="520,27" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/nav_gold.png" alphatest="blend" zPosition="9" />
	<widget name="clock" position="1595,16" size="275,28" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
	<widget name="date" position="1595,48" size="275,20" font="Regular;14" foregroundColor="#91A0B4" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />

	<widget name="banner" position="108,120" size="1704,454" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder_v4.jpg" alphatest="blend" scale="1" zPosition="1" />
<ePixmap position="108,120" size="1704,454" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/home_vod_dim_r501.png" alphatest="blend" zPosition="2" />
<widget name="quality" position="155,151" size="330,30" font="Regular;20" foregroundColor="#27C8FF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureTitle" position="155,194" size="720,112" font="Regular;56" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureMeta" position="155,324" size="700,36" font="Regular;23" foregroundColor="#DDE5EF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureDesc" position="155,371" size="720,84" font="Regular;22" foregroundColor="#DDE5EF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="playNow" position="155,498" size="240,60" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#24292F" halign="center" valign="center" zPosition="4" />
<widget name="recentTitle" position="100,610" size="500,42" font="Regular;30" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="poster0" position="114,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="106,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="116,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate0" position="116,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle0" position="184,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster1" position="406,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="398,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="408,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate1" position="408,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle1" position="476,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster2" position="698,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="690,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="700,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate2" position="700,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle2" position="768,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster3" position="990,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="982,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="992,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate3" position="992,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle3" position="1060,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster4" position="1282,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1274,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="1284,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate4" position="1284,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle4" position="1352,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster5" position="1574,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1566,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="1576,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate5" position="1576,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle5" position="1644,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="posterSelector" position="106,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_248x338.png" alphatest="blend" zPosition="8" />
<widget name="status" position="520,1038" size="880,26" font="Regular;17" foregroundColor="#95A2B5" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
</screen>'''

# Retired Skin 3 removed in r150. Existing saved values migrate to Skin 2 in _load_home_appearance().
SEARCH_SCREEN = '''<screen name="TiviMateE2Search" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#070A0F">
<eLabel position="0,0" size="1920,1080" backgroundColor="#070A0F" zPosition="0" />
<ePixmap position="36,82" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" zPosition="5" />
<ePixmap position="46,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="7" />
<widget name="top0" position="76,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="231,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="7" />
<widget name="top1" position="261,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="416,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="7" />
<widget name="top2" position="446,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="601,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="7" />
<widget name="top3" position="631,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="786,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="7" />
<widget name="top4" position="816,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="971,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="7" />
<widget name="top5" position="1001,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="1156,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="7" />
<widget name="top6" position="1186,18" size="314,46" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="1516,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="7" />
<widget name="top7" position="1546,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="topSelector" position="45,66" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/nav_gold.png" alphatest="blend" zPosition="9" />
<widget name="back" position="30,104" size="70,70" font="Regular;42" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<eLabel position="394,91" size="1132,94" backgroundColor="#3A3020" zPosition="1" />
<eLabel position="398,95" size="1124,86" backgroundColor="#0B1017" zPosition="2" />
<ePixmap position="400,97" size="1120,82" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/search/search_bar.png" alphatest="blend" zPosition="3" />
<widget name="searchText" position="460,112" size="900,52" font="Regular;30" foregroundColor="#F3F4F8" backgroundColor="#00000000" transparent="1" valign="center" zPosition="2" />
<widget name="mic" position="1365,97" size="70,82" font="Regular;36" foregroundColor="#F5C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<widget name="closeIcon" position="1445,97" size="70,82" font="Regular;38" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<widget name="moviesTitle" position="70,202" size="1160,46" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" />
<widget name="showsTitle" position="70,950" size="1160,28" font="Regular;21" foregroundColor="#AAB3C1" backgroundColor="#00000000" transparent="1" />
<widget name="poster0" position="70,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="70,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate0" position="78,463" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel0" position="78,500" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster1" position="315,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="315,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate1" position="323,463" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel1" position="323,500" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster2" position="560,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="560,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate2" position="568,463" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel2" position="568,500" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster3" position="805,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="805,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate3" position="813,463" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel3" position="813,500" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster4" position="1050,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1050,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate4" position="1058,463" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel4" position="1058,500" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster5" position="70,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="70,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate5" position="78,791" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel5" position="78,828" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster6" position="315,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="315,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate6" position="323,791" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel6" position="323,828" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster7" position="560,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="560,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate7" position="568,791" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel7" position="568,828" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster8" position="805,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="805,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate8" position="813,791" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel8" position="813,828" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster9" position="1050,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1050,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate9" position="1058,791" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel9" position="1058,828" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="movieSelector" position="70,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_200x285.png" alphatest="blend" zPosition="8" />
<widget name="showSelector" position="70,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_200x285.png" alphatest="blend" zPosition="8" />
<eLabel position="1310,165" size="545,765" backgroundColor="#0C1118" zPosition="1" />
<eLabel position="1310,165" size="4,765" backgroundColor="#E2B84B" zPosition="2" />
<eLabel position="1467,187" size="231,321" backgroundColor="#E2B84B" zPosition="2" />
<eLabel position="1471,191" size="223,313" backgroundColor="#111821" zPosition="3" />
<widget name="detailPoster" position="1475,195" size="215,305" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="4" />
<widget name="selectedTitle" position="1350,520" size="465,90" font="Regular;30" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" valign="center" zPosition="3" />
<widget name="selectedMeta" position="1350,610" size="465,180" font="Regular;21" foregroundColor="#D6DBE3" backgroundColor="#00000000" transparent="1" valign="top" zPosition="3" />
<widget name="selectedOverview" position="1350,790" size="465,105" font="Regular;18" foregroundColor="#AEB7C5" backgroundColor="#00000000" transparent="1" valign="top" zPosition="3" />
<widget name="play" position="1350,900" size="215,48" font="Regular;22" foregroundColor="#111318" backgroundColor="#E2B84B" halign="center" valign="center" zPosition="3" />
<widget name="favorite" position="1580,900" size="235,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#2A313B" halign="center" valign="center" zPosition="3" />
<widget name="pageInfo" position="500,980" size="400,40" font="Regular;22" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" />
<widget name="status" position="330,1022" size="750,32" font="Regular;19" foregroundColor="#D2D8E1" backgroundColor="#00000000" transparent="1" halign="center" />
<eLabel position="95,1002" size="290,54" backgroundColor="#111821" zPosition="3" />
<eLabel position="98,1005" size="54,48" text="←" font="Regular;34" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
<eLabel position="160,1007" size="210,42" text="نتائج أكثر يسار" font="Regular;20" foregroundColor="#E7ECF2" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
<widget name="guideBar" position="-10,-10" size="1,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/search/search_guide.png" alphatest="blend" zPosition="1" />
<eLabel position="1535,1002" size="290,54" backgroundColor="#111821" zPosition="3" />
<eLabel position="1768,1005" size="54,48" text="→" font="Regular;34" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
<eLabel position="1548,1007" size="210,42" text="نتائج أكثر يمين" font="Regular;20" foregroundColor="#E7ECF2" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
</screen>'''

EDITOR = '''<screen name="TiviMateE2PlaylistEditor" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#06101D">
    <!-- RGB PNG base: one opaque navy colour, with no alpha channel or panel overlays. -->
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_web_blue.png" alphatest="blend" zPosition="0" />
    <widget name="settingsLogo" position="78,14" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" zPosition="5" />
    <widget name="settingsBrand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsTagline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNavSelector" position="1215,27" size="165,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/nav_classic_focus_v5.png" alphatest="blend" zPosition="3" />
    <widget name="settingsNav0" position="450,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav1" position="603,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav2" position="756,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav3" position="909,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav4" position="1062,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav5" position="1215,27" size="165,58" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsClock" position="1430,28" size="160,34" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" zPosition="4" />
    <widget name="settingsDate" position="1430,67" size="190,26" font="Regular;17" foregroundColor="#91A0B4" backgroundColor="#00000000" transparent="1" halign="left" zPosition="4" />
    <widget name="settingsSideTitle" position="92,182" size="330,54" font="Regular;32" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="3" />
    <ePixmap position="190,242" size="140,140" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/control_center_gear.png" alphatest="blend" zPosition="4" />
    <widget name="settingsSideText" position="98,350" size="318,72" font="Regular;20" foregroundColor="#D6E4F2" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="3" />
    <widget name="settingsSideHint" position="100,736" size="316,78" font="Regular;20" foregroundColor="#6DD8FF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="3" />
    <ePixmap position="110,430" size="286,270" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_card_r64.png" alphatest="blend" zPosition="2" />
    <ePixmap position="130,447" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_globe.png" alphatest="blend" zPosition="4" />
    <widget name="languageTitle" position="170,446" size="205,36" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="languageSelector" position="124,492" size="258,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_row_focus_r64.png" alphatest="blend" zPosition="3" />
    <widget name="language0" position="146,498" size="174,44" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
    <widget name="language1" position="146,562" size="174,44" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
    <widget name="language2" position="146,626" size="174,44" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
    <widget name="languageRadio0" position="334,504" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_radio_off_r64.png" alphatest="blend" zPosition="5" />
    <widget name="languageRadio1" position="334,568" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_radio_off_r64.png" alphatest="blend" zPosition="5" />
    <widget name="languageRadio2" position="334,632" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_radio_off_r64.png" alphatest="blend" zPosition="5" />
    <widget name="title" position="500,196" size="1260,52" font="Regular;39" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />
    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />
    <widget name="config" position="520,312" size="660,350" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#1268B3" selectionForegroundColor="#FFFFFF" zPosition="4" />
    <widget name="hint" position="500,878" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
    <widget name="settingsGuide" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_guide_keyboard_save_r69.png" alphatest="blend" zPosition="4" />
</screen>'''

XTREAM_EDITOR_SKIN = EDITOR
STALKER_EDITOR_SKIN = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="StalkerPortalEditor"')

# Server Manager keeps the existing menu, navigation and action bar intact.  Only
# the unused lower space becomes a general connection-status card; no account or
# subscriber information is displayed here.
SERVER_MANAGER_SKIN = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="ServerManager"').replace(
    '''    <widget name="config" position="500,294" size="1230,480" itemHeight="68" foregroundColor="#F5F8FC" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" zPosition="3" />
    <widget name="hint" position="500,878" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="3" />''',
    '''    <widget name="config" position="500,294" size="1230,380" itemHeight="68" foregroundColor="#F5F8FC" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" zPosition="3" />
    <eLabel position="500,792" size="1230,132" backgroundColor="#10233A" zPosition="1" />
    <eLabel position="502,794" size="1226,128" backgroundColor="#142B46" zPosition="2" />
    <ePixmap position="1298,796" size="430,124" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_status_network.png" alphatest="blend" zPosition="3" />
    <widget name="serverStatusTitle" position="536,808" size="650,28" font="Regular;24" foregroundColor="#F2FBFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="serverStatusText" position="536,844" size="650,26" font="Regular;20" foregroundColor="#B9CDE0" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendOnlineIcon" position="536,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_status_online_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendOnline" position="562,875" size="170,26" font="Regular;18" foregroundColor="#67E89A" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendCheckingIcon" position="740,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_status_busy_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendChecking" position="766,875" size="185,26" font="Regular;18" foregroundColor="#FFD669" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendOfflineIcon" position="960,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_status_offline_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendOffline" position="986,875" size="185,26" font="Regular;18" foregroundColor="#FF8C95" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="hint" position="500,892" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="5" />'''
)
SERVER_MANAGER_SKIN = SERVER_MANAGER_SKIN.replace(
    '</screen>',
    '    <widget name="settingsActionButtons" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_action_buttons_poster.png" alphatest="blend" zPosition="4" />\n</screen>'
)

# r111: visible experimental-settings entry in the existing Settings / Server Manager screen.
SERVER_MANAGER_SKIN = SERVER_MANAGER_SKIN.replace(
    '</screen>',
    '    <eLabel position="92,696" size="300,82" backgroundColor="#241D0B" cornerRadius="14" zPosition="5" />\n'
    '    <eLabel position="96,700" size="292,74" backgroundColor="#0C1A28" cornerRadius="12" zPosition="6" />\n'
    '    <widget name="settingsNewButton" position="108,710" size="268,54" font="Regular;22" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="7" />\n'
    '</screen>'
)


# Test73: enlarge only the Server Manager list area. Keep the simple list style
# and leave editors, language card, navigation, and action buttons unchanged.
SERVER_MANAGER_SKIN = SERVER_MANAGER_SKIN.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(
    '<eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />\n'
    '    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />\n'
    '    <widget name="config" position="520,312" size="660,350" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#1268B3" selectionForegroundColor="#FFFFFF" zPosition="4" />',
    '<eLabel position="455,252" size="1215,500" backgroundColor="#07121D" zPosition="2" />\n'
    '    <eLabel position="463,260" size="1199,484" backgroundColor="#0D1C2A" zPosition="3" />\n'
    '    <widget name="config" position="495,286" size="1135,410" itemHeight="88" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_row_focus_dark_cyan_r126.png" selectionForegroundColor="#FFFFFF" zPosition="4" />'
)

def _setup_settings_chrome(screen):
    labels = [tr("Search"), tr("Home"), tr("Live"), tr("Movies"), tr("TV Shows"), tr("Settings")]
    screen["settingsBrand"] = Label(tr("TiViMate"))
    screen["settingsTagline"] = Label(tr("IPTV EXPERIENCE"))
    screen["settingsLogo"] = Pixmap()
    screen["settingsSideTitle"] = Label(tr("CONTROL CENTER"))
    screen["settingsSideText"] = Label(tr("Manage playlists,\nconnections and metadata,\nand appearance settings."))
    screen["settingsSideHint"] = Label(tr("Use the colour keys below\nfor quick actions."))
    screen["settingsNavSelector"] = Pixmap()
    screen["settingsGuide"] = Pixmap()
    screen["settingsActionButtons"] = Pixmap()
    try:
        screen["settingsNavSelector"].hide()
        screen["settingsGuide"].hide()
        screen["settingsActionButtons"].hide()
    except Exception:
        pass
    for index, label in enumerate(labels):
        screen["settingsNav%d" % index] = Label(label)
    now = time.localtime()
    screen["settingsClock"] = Label(time.strftime("%H:%M", now))
    screen["settingsDate"] = Label(time.strftime("%a, %d %b", now))
    screen["languageTitle"] = Label(tr("APPLICATION LANGUAGE"))
    screen["languageSelector"] = Pixmap()
    screen["language0"] = Label(tr("English"))
    screen["language1"] = Label(tr("Arabic"))
    screen["language2"] = Label(tr("French"))
    screen["languageRadio0"] = Pixmap()
    screen["languageRadio1"] = Pixmap()
    screen["languageRadio2"] = Pixmap()


def _show_settings_guide(screen):
    try:
        screen["settingsGuide"].show()
    except Exception:
        pass



# Skin 2 is the optional cinematic Home dashboard selected in Home Appearance.
# It intentionally preserves every widget TiviMateE2Home manages at runtime.
HOME_SKIN2 = """<screen name="TiviMateE2Home" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05080D">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#05080D" zPosition="0" />
    <eLabel position="0,0" size="1920,92" backgroundColor="#090D12" zPosition="1" />

    <widget name="banner" position="0,92" size="1920,370" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/tivimate_global_hero_r70.png" alphatest="blend" scale="1" zPosition="1" />
    <ePixmap position="0,92" size="1920,370" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/home_skin2_vod_dim_r501.png" alphatest="blend" zPosition="2" />

    <widget name="logo" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="homeBrandLogo" position="28,10" size="285,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" zPosition="7" />
    <eLabel position="269,48" size="82,26" text="v1.0.10" font="Regular;17" foregroundColor="#E2B84B" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="9" />
    <widget name="headline" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="subheadline" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />

        <ePixmap position="335,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="8" />
    <widget name="nav0" position="364,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="490,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="8" />
    <widget name="nav1" position="519,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="645,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="8" />
    <widget name="nav2" position="674,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="800,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="8" />
    <widget name="nav3" position="829,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="955,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="8" />
    <widget name="nav4" position="984,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="1110,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="8" />
    <widget name="nav5" position="1139,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="1265,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="8" />
    <widget name="nav6" position="1294,15" size="111,64" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="1420,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="8" />
    <widget name="nav7" position="1449,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <widget name="navSelector" position="467,79" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/nav_gold.png" alphatest="blend" zPosition="9" />
    <widget name="clock" position="1595,10" size="275,28" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" halign="right" zPosition="7" />
    <widget name="date" position="1595,45" size="275,20" font="Regular;14" foregroundColor="#A9B3BD" transparent="1" halign="right" zPosition="7" />

    <widget name="quality" position="48,148" size="680,32" font="Regular;21" foregroundColor="#E2B84B" transparent="1" zPosition="7" />
    <widget name="featureTitle" position="48,180" size="760,72" font="Regular;42" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="7" />
    <widget name="featureMeta" position="48,258" size="700,42" font="Regular;24" foregroundColor="#E5EAF0" transparent="1" valign="center" zPosition="7" />
    <widget name="featureDesc" position="48,305" size="680,82" font="Regular;22" foregroundColor="#D5DCE4" transparent="1" zPosition="7" />
    <eLabel position="48,395" size="245,56" backgroundColor="#B7181F" cornerRadius="12" zPosition="6" />
    <widget name="playNow" position="48,395" size="245,56" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="7" />
    <eLabel position="315,395" size="245,56" text="ⓘ  More Info" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#24292F" halign="center" valign="center" cornerRadius="12" zPosition="7" />

    <widget name="recentTitle" position="55,468" size="560,40" font="Regular;28" foregroundColor="#FFFFFF" transparent="1" halign="left" zPosition="8" />

    <widget name="poster0" position="62,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="55,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate0" position="67,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle0" position="66,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster1" position="382,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="375,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate1" position="387,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle1" position="386,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster2" position="702,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="695,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate2" position="707,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle2" position="706,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster3" position="1022,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="1015,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate3" position="1027,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle3" position="1026,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster4" position="1342,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="1335,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate4" position="1347,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle4" position="1346,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster5" position="1662,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="1655,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate5" position="1667,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle5" position="1666,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="posterSelector" position="53,508" size="219,364" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/skin2_card_focus_reference_215x360.png" alphatest="blend" zPosition="10" />

    <eLabel position="45,888" size="1830,74" backgroundColor="#0F151C" zPosition="5" />
    <eLabel position="55,898" size="425,54" backgroundColor="#B7181F" cornerRadius="12" zPosition="6" />
    <eLabel position="505,898" size="425,54" backgroundColor="#13823B" cornerRadius="12" zPosition="6" />
    <eLabel position="955,898" size="425,54" backgroundColor="#C58B00" cornerRadius="12" zPosition="6" />
    <eLabel position="1405,898" size="425,54" backgroundColor="#1269A6" cornerRadius="12" zPosition="6" />
    <ePixmap position="82,904" size="42,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/home_action_server.png" alphatest="blend" zPosition="8" />
    <ePixmap position="532,904" size="42,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/home_action_packages.png" alphatest="blend" zPosition="8" />
    <ePixmap position="982,904" size="42,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/home_action_lists.png" alphatest="blend" zPosition="8" />
    <ePixmap position="1432,904" size="42,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/home_action_favorite.png" alphatest="blend" zPosition="8" />
    <widget name="actionLabel0" position="120,898" size="340,54" font="Regular;28" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="9" />
    <widget name="actionLabel1" position="570,898" size="340,54" font="Regular;28" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="9" />
    <widget name="actionLabel2" position="1020,898" size="340,54" font="Regular;28" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="9" />
    <widget name="actionLabel3" position="1470,898" size="340,54" font="Regular;28" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="9" />

    <eLabel position="45,974" size="575,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <eLabel position="645,974" size="620,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <ePixmap position="853,979" size="204,63" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/developed_by_opesboy_badge.png" alphatest="blend" scale="1" zPosition="9" />
    <eLabel position="1290,974" size="540,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <widget name="skin2HelpTitle" position="68,985" size="225,28" font="Regular;22" foregroundColor="#E2B84B" transparent="1" zPosition="8" />
    <widget name="skin2HelpBody" position="68,1014" size="520,28" font="Regular;17" foregroundColor="#C4CED8" transparent="1" zPosition="8" />
    <widget name="skin2LangTitle" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#E2B84B" transparent="1" halign="center" zPosition="8" />
    <widget name="skin2LangBody" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#C4CED8" transparent="1" halign="center" zPosition="8" />
    <widget name="skin2Key5" position="1310,986" size="500,54" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />
    <widget name="status" position="510,1048" size="900,28" font="Regular;17" foregroundColor="#B8C3CD" transparent="1" halign="center" valign="center" zPosition="8" />
</screen>"""

LIVE_CLASSIC = """<screen name="MediaScreen" position="0,0" size="1920,1080" backgroundColor="#00101214" flags="wfNoBorder">
    <!-- Test10: opaque Live layout with a real receiver PIG preview. -->
    <eLabel position="0,0" size="1920,1080" backgroundColor="#00101214" zPosition="0" />

    <widget name="brand" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="rail" position="-20,-20" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />

    <!-- Header -->
    <widget name="title" position="42,24" size="1180,50" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="10" />
    <widget name="clockTitle" position="1505,26" size="360,42" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="10" />
    <eLabel position="34,84" size="920,3" backgroundColor="#20262D" zPosition="4" />

    <!-- Packages: narrow Aglare-style list -->
    <eLabel position="28,104" size="355,850" backgroundColor="#D8171A1C" cornerRadius="18" zPosition="1" />
    <eLabel position="38,114" size="335,48" backgroundColor="#00131313" cornerRadius="12" zPosition="2" />
    <eLabel position="54,121" size="220,36" text="PACKAGES" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="categoryTitle" position="278,123" size="78,32" font="Regular;17" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="8" />
    <widget name="category" position="42,176" size="327,760" itemHeight="48" foregroundColor="#F1F3F5" foregroundColorSelected="#008080" backgroundColor="#00000000" backgroundColorSelected="#00000000" transparent="1" itemGradientSelected="#003F3F3F,#002F2F2F,#003F3F3F,vertical" itemCornerRadius="10" itemCornerRadiusSelected="10" scrollbarMode="showOnDemand" zPosition="7" />

    <!-- Channels: main list, matching ChannelSelection proportions -->
    <eLabel position="402,104" size="610,850" backgroundColor="#D8171A1C" cornerRadius="18" zPosition="1" />
    <eLabel position="412,114" size="590,48" backgroundColor="#00131313" cornerRadius="12" zPosition="2" />
    <eLabel position="430,121" size="300,36" text="CHANNELS" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="pageInfo" position="826,123" size="154,32" font="Regular;17" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="8" />
    <widget name="list" position="478,176" size="510,760" itemHeight="50" foregroundColor="#FFFFFF" foregroundColorSelected="#008080" backgroundColor="#00000000" backgroundColorSelected="#00000000" transparent="1" itemGradientSelected="#003F3F3F,#002F2F2F,#003F3F3F,vertical" itemCornerRadius="10" itemCornerRadiusSelected="10" scrollbarMode="showOnDemand" zPosition="7" />

    <!-- Right details area inspired by Aglare ChannelSelectionPIG -->
    <eLabel position="1032,104" size="860,850" backgroundColor="#B8171A1C" cornerRadius="18" zPosition="1" />
    <widget name="channelPicon" position="1045,126" size="220,130" alphatest="blend" scale="1" zPosition="8" />
    <widget name="channelTitle" position="1290,126" size="560,48" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="meta" position="1290,180" size="560,34" font="Regular;20" foregroundColor="#D4D9DE" backgroundColor="#00000000" transparent="1" zPosition="8" />

    <!-- Real receiver PIG preview window -->
    <widget source="session.VideoPicture" render="Pig" position="1318,232" size="540,306" backgroundColor="transparent" transparent="0" zPosition="8" />
        <eLabel position="1318,548" size="540,9" backgroundColor="#5A5A5A" cornerRadius="4" zPosition="7" />
    <widget name="liveProgress" position="1318,548" size="540,9" borderWidth="0" foregroundColor="#00B77A" backgroundColor="#5A5A5A" zPosition="9" />

    <!-- Current and next EPG from Enigma2 EPG cache -->
    <eLabel position="1060,578" size="798,342" backgroundColor="#85131313" cornerRadius="16" zPosition="2" />
    <eLabel position="1084,600" size="750,3" backgroundColor="#6A6F75" zPosition="4" />
    <widget name="livePoster" position="1080,265" size="200,300" alphatest="blend" zPosition="9" />
    <widget name="epgNowTime" position="1084,614" size="170,34" font="Regular;20" foregroundColor="#00D7C7" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="epgNowTitle" position="1254,610" size="576,42" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="8" />
    <widget name="epgProgressText" position="1680,652" size="150,30" font="Regular;18" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="8" />
    <eLabel position="1084,684" size="750,2" backgroundColor="#4A4F55" zPosition="4" />
    <widget name="epgNextTime" position="1084,696" size="170,34" font="Regular;20" foregroundColor="#E5B243" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="epgNextTitle" position="1254,692" size="576,42" font="Regular;23" foregroundColor="#F0F2F4" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="8" />
    <widget name="desc" position="1084,746" size="746,150" font="Regular;20" foregroundColor="#D8DDE2" backgroundColor="#00000000" transparent="1" valign="top" zPosition="8" />

    <!-- Visible hint so every user knows how to change the full Live style -->
    <widget name="styleHint" position="1580,62" size="280,34" font="Regular;18" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="12" />

    <!-- Keep original plugin footer exactly as-is -->
    <widget name="guideBar" position="80,1015" size="1760,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/live_guide_r120.png" alphatest="blend" zPosition="12" />

    <widget name="nowLabel" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="keys" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
</screen>"""
VOD = '''<screen name="TiviMateE2Vod" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#10151d">
<widget name="backdrop" position="0,0" size="1920,1080" alphatest="blend" zPosition="0" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/vod_cinematic_overlay.png" alphatest="blend" zPosition="1" />
<ePixmap position="46,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="7" />
<widget name="top0" position="76,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="231,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="7" />
<widget name="top1" position="261,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="416,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="7" />
<widget name="top2" position="446,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="601,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="7" />
<widget name="top3" position="631,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="786,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="7" />
<widget name="top4" position="816,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="971,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="7" />
<widget name="top5" position="1001,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="1156,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="7" />
<widget name="top6" position="1186,24" size="314,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="1516,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="7" />
<widget name="top7" position="1546,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="topSelector" position="45,75" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/nav_gold.png" alphatest="blend" zPosition="9" />
<!-- compatibility widgets kept off-screen: categories are opened through FILTER only -->
<widget name="brand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="rail" position="-10,-10" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />
<widget name="category" position="-10,-10" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />
<widget name="sectionTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="contentProviderNetflix" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/provider_netflix.png" alphatest="blend" zPosition="10" />
<widget name="contentProviderPrime" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/provider_prime.png" alphatest="blend" zPosition="10" />
<widget name="contentProviderDisney" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/resources/package_logos/package_disney.png" alphatest="blend" zPosition="10" />
<widget name="contentProviderMax" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/resources/package_logos/package_max.png" alphatest="blend" zPosition="10" />
<widget name="contentProviderApple" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/resources/package_logos/package_apple.png" alphatest="blend" zPosition="10" />
<widget name="contentProviderParamount" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/resources/package_logos/package_paramount.png" alphatest="blend" zPosition="10" />
<!-- Dynamic TMDb title logo for the currently selected movie/series. -->
<widget name="titleLogo" position="1390,120" size="430,180" alphatest="blend" zPosition="11" />
<widget name="currentCategory" position="80,450" size="700,42" font="Regular;31" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="searchIcon" position="1650,55" size="85,55" font="Regular;36" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
<widget name="filterIcon" position="1740,55" size="110,55" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
<widget name="title" position="80,92" size="1500,44" font="Regular;30" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="channelTitle" position="80,137" size="1500,70" font="Regular;54" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="meta" position="80,212" size="1470,44" font="Regular;31" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="desc" position="80,272" size="1180,185" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="nowLabel" position="1650,450" size="190,42" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
<widget name="poster0" position="70,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="posterShell0" position="70,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<widget name="poster1" position="450,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="posterShell1" position="450,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<widget name="poster2" position="830,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="posterShell2" position="830,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<widget name="poster3" position="1210,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="posterShell3" position="1210,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<widget name="poster4" position="1590,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="posterShell4" position="1590,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<widget name="posterRate0" position="82,916" size="82,34" font="Regular;21" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate1" position="462,916" size="82,34" font="Regular;21" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate2" position="842,916" size="82,34" font="Regular;21" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate3" position="1222,916" size="82,34" font="Regular;21" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate4" position="1602,916" size="82,34" font="Regular;21" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel0" position="146,905" size="183,55" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel1" position="526,905" size="183,55" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel2" position="906,905" size="183,55" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel3" position="1286,905" size="183,55" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel4" position="1666,905" size="183,55" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="selector" position="70,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_270x435.png" alphatest="blend" zPosition="8" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="80,1015" size="1760,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/vod_guide_r115.png" alphatest="blend" zPosition="6" />
</screen>'''

SERIES_DETAILS = '''<screen name="TiviMateE2SeriesDetails" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#11151d">
<widget name="backdrop" position="0,0" size="1920,1080" alphatest="blend" zPosition="0" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series/series_overlay.png" alphatest="blend" zPosition="1" />
<widget name="title" position="80,52" size="1500,82" font="Regular;56" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rating" position="84,143" size="150,42" font="Regular;34" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
<widget name="ratingStars" position="84,181" size="170,27" font="Regular;22" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
<eLabel position="84,207" size="150,22" text="RATING" font="Regular;14" foregroundColor="#D9DEE5" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
<widget name="meta" position="250,145" size="1250,60" font="Regular;35" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="providerLogo" position="1540,145" size="250,62" alphatest="blend" zPosition="12" />
<widget name="cast" position="85,220" size="1320,112" font="Regular;31" foregroundColor="#F7F7F7" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="desc" position="85,334" size="1340,205" font="Regular;33" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="seasonInfo" position="1420,560" size="430,52" font="Regular;33" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="4" />
<widget name="episode0" position="80,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode1" position="440,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode2" position="800,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode3" position="1160,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode4" position="1520,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episodeLabel0" position="80,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel1" position="440,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel2" position="800,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel3" position="1160,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel4" position="1520,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeSelector" position="72,632" size="346,282" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series/episode_select.png" alphatest="blend" zPosition="5" />
<widget name="episodeInfo" position="85,925" size="1500,58" font="Regular;23" foregroundColor="#dce3eb" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="85,1005" size="1740,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series/series_details_guide_r69.png" alphatest="blend" zPosition="5" />
</screen>'''

# Test74: keep Server Manager simple, use a calmer selected-row colour, and
# make both Edit screens match the manager panel proportions.
SERVER_MANAGER_SKIN = SERVER_MANAGER_SKIN.replace(
    'selectionBackgroundColor="#1E9FDF"',
    'selectionBackgroundColor="#17679E"'
)

_editor_old = """<eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />
    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />
    <widget name="config" position="520,312" size="660,350" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#1268B3" selectionForegroundColor="#FFFFFF" zPosition="4" />"""
_editor_new_xtream = """<eLabel position="455,252" size="1215,500" backgroundColor="#07121D" zPosition="2" />
    <eLabel position="463,260" size="1199,484" backgroundColor="#0D1C2A" zPosition="3" />
    <widget name="config" position="495,286" size="1135,410" itemHeight="58" foregroundColor="#F5F8FC" backgroundColor="#12385F" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#17679E" selectionForegroundColor="#FFFFFF" zPosition="4" />"""
_editor_new_stalker = _editor_new_xtream.replace('itemHeight="58"', 'itemHeight="70"')

XTREAM_EDITOR_SKIN = XTREAM_EDITOR_SKIN.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(_editor_old, _editor_new_xtream)

STALKER_EDITOR_SKIN = STALKER_EDITOR_SKIN.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(_editor_old, _editor_new_stalker)

# The standard settings action artwork has no Stalker diagnostic button.
# Add a real, visible BLUE TEST control above the footer so users can see
# the feature and press the blue remote key on every supported skin/image.
STALKER_EDITOR_SKIN = STALKER_EDITOR_SKIN.replace(
    '</screen>',
    '    <widget name="testButton" position="1390,884" size="300,48" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#147FC1" transparent="0" halign="center" valign="center" zPosition="10" />\n</screen>'
)

# r29: use the Server Manager content geometry as the master layout for all
# standard Settings pages. This changes layout only; screen logic/actions are untouched.
EDITOR = EDITOR.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(
    '<eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />\n'
    '    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />\n'
    '    <widget name="config" position="520,312" size="660,350" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#1268B3" selectionForegroundColor="#FFFFFF" zPosition="4" />',
    '<eLabel position="455,252" size="1215,500" backgroundColor="#07121D" zPosition="2" />\n'
    '    <eLabel position="463,260" size="1199,484" backgroundColor="#0D1C2A" zPosition="3" />\n'
    '    <widget name="config" position="495,286" size="1135,410" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#17679E" selectionForegroundColor="#FFFFFF" zPosition="4" />'
)


# r109: unified Add Server editor identity for Xtream / Stalker / M3U.
def _premium_server_editor_skin(xml):
    xml = xml.replace('backgroundColor="#06101D"', 'backgroundColor="#070C13"', 1)
    xml = xml.replace('pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_web_blue.png"',
                      'pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_solid_navy_r64.png"')
    xml = xml.replace('foregroundColor="#6DD8FF"', 'foregroundColor="#F1C84C"')
    xml = xml.replace('selectionBackgroundColor="#17679E"', 'selectionBackgroundColor="#8A6819"')
    xml = xml.replace('selectionBackgroundColor="#1268B3"', 'selectionBackgroundColor="#8A6819"')
    xml = xml.replace('backgroundColor="#12385F"', 'backgroundColor="#111A24"')
    xml = xml.replace('backgroundColor="#0D1C2A"', 'backgroundColor="#0D141E"')
    xml = xml.replace('backgroundColor="#07121D"', 'backgroundColor="#050A10"')
    # Gold accent rail on the main form, visually matching the approved mock-up.
    xml = xml.replace('</screen>',
        '    <eLabel position="455,252" size="5,500" backgroundColor="#E2B84B" zPosition="8" />\\n'
        '    <eLabel position="463,252" size="1199,2" backgroundColor="#E2B84B" zPosition="8" />\\n'
        '</screen>')
    return xml

EDITOR = _premium_server_editor_skin(EDITOR)
XTREAM_EDITOR_SKIN = _premium_server_editor_skin(XTREAM_EDITOR_SKIN)
STALKER_EDITOR_SKIN = _premium_server_editor_skin(STALKER_EDITOR_SKIN)
# The XML uses a 1920x1080 design canvas.  Convert it once at import time
# when the active Enigma2 desktop is WQHD, before any Screen is constructed.
HOME_SKIN1 = scale_skin(HOME_SKIN1)
HOME_SKIN2 = scale_skin(HOME_SKIN2)
SEARCH_SCREEN = scale_skin(SEARCH_SCREEN)
EDITOR = scale_skin(EDITOR)
XTREAM_EDITOR_SKIN = scale_skin(XTREAM_EDITOR_SKIN)
STALKER_EDITOR_SKIN = scale_skin(STALKER_EDITOR_SKIN)
SERVER_MANAGER_SKIN = scale_skin(SERVER_MANAGER_SKIN)

# Wide dark settings layout used by TMDb.
# r235: visual-only redesign built from the stable r233 screen contract.
# Keep the exact widget names used by TMDbSettings and shared settings chrome.
TMDB_SETTINGS_SKIN = r"""<screen name="TMDbSettings" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#050708">
    <!-- r264: user-approved cinematic TMDb artwork as a skin background only. -->
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/tmdb_settings_cinematic_r270.jpg" scale="1" zPosition="0" />

    <!-- Real Enigma2 settings stay live and editable over the empty center rows. -->
    <widget name="config" position="330,304" size="1260,548" itemHeight="84" font="Regular;27" foregroundColor="#F4F7FA" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" selectionBackgroundColor="#163745" selectionForegroundColor="#FFFFFF" zPosition="8" />

    <!-- Functional key hints only; deliberately subtle so the cinematic design stays clean. -->
    <widget name="keys" position="410,900" size="1100,42" font="Regular;19" foregroundColor="#AAB5BE" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />

    <!-- Existing screen contract: keep title/hint and shared Settings chrome widgets alive but visually hidden. -->
    <widget name="title" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="hint" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsLogo" position="-10,-10" size="1,1" transparent="1" />
    <widget name="settingsBrand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsTagline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNavSelector" position="-10,-10" size="1,1" transparent="1" />
    <widget name="settingsNav0" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNav1" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNav2" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNav3" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNav4" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNav5" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsClock" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsDate" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsSideTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsSideText" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsSideHint" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsGuide" position="-10,-10" size="1,1" transparent="1" />
    <widget name="settingsActionButtons" position="-10,-10" size="1,1" transparent="1" />
    <widget name="languageTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="languageSelector" position="-10,-10" size="1,1" transparent="1" />
    <widget name="language0" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="language1" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="language2" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="languageRadio0" position="-10,-10" size="1,1" transparent="1" />
    <widget name="languageRadio1" position="-10,-10" size="1,1" transparent="1" />
    <widget name="languageRadio2" position="-10,-10" size="1,1" transparent="1" />
</screen>"""
TMDB_SETTINGS_SKIN = scale_skin(TMDB_SETTINGS_SKIN)

LIVE_CLASSIC = scale_skin(LIVE_CLASSIC)

LIVE_STYLE_CHOICES = [
    ("تركوازي", "turquoise"),
    ("أزرق", "blue"),
    ("أخضر", "green"),
    ("ذهبي", "gold"),
    ("بنفسجي", "purple"),
    ("فضي", "silver"),
]

LIVE_STYLE_PALETTES = {
    "turquoise": {
        "accent": "#008F95", "bg": "#00101214", "panel": "#D8171A1C", "panel2": "#B8171A1C",
        "header": "#00131313", "line": "#263B40", "progress": "#00BFC7", "soft": "#B8DDE0",
    },
    "blue": {
        "accent": "#168CFF", "bg": "#000B1422", "panel": "#D8101A2B", "panel2": "#B80D1727",
        "header": "#00101D31", "line": "#244C78", "progress": "#168CFF", "soft": "#BBD8FF",
    },
    "green": {
        "accent": "#19C878", "bg": "#000C1712", "panel": "#D812211A", "panel2": "#B80E1C16",
        "header": "#0013231B", "line": "#285D45", "progress": "#19C878", "soft": "#BCEBD4",
    },
    "gold": {
        "accent": "#E5B243", "bg": "#0017130B", "panel": "#D8221B10", "panel2": "#B81D170D",
        "header": "#00261E10", "line": "#6B5525", "progress": "#E5B243", "soft": "#F2DEB0",
    },
    "purple": {
        "accent": "#935CFF", "bg": "#00120D1B", "panel": "#D81C1428", "panel2": "#B8171022",
        "header": "#0020152F", "line": "#5B3A86", "progress": "#935CFF", "soft": "#D8C4FF",
    },
    "silver": {
        "accent": "#E5E7EB", "bg": "#00121315", "panel": "#D81C1E21", "panel2": "#B8181A1D",
        "header": "#00232629", "line": "#5F666D", "progress": "#D8DDE2", "soft": "#E8EAED",
    },
}

def _live_skin_with_style(theme):
    theme = theme if theme in LIVE_STYLE_PALETTES else "turquoise"
    p = LIVE_STYLE_PALETTES[theme]
    skin = LIVE_CLASSIC
    replacements = {
        '#00101214': p['bg'],
        '#D8171A1C': p['panel'],
        '#B8171A1C': p['panel2'],
        '#00131313': p['header'],
        '#20262D': p['line'],
        '#6A6F75': p['line'],
        '#5A5A5A': p['line'],
        '#00B77A': p['progress'],
        '#008080': p['accent'],
        '#BFC7CF': p['soft'],
        '#D4D9DE': p['soft'],
    }
    for old, new in replacements.items():
        skin = skin.replace(old, new)
    return skin

VOD = scale_skin(VOD)
SERIES_DETAILS = scale_skin(SERIES_DETAILS)

# r223: stable clipped Circle VOD view with a real focused duplicate poster.
# Base posters stay fixed/clipped at 222x222. The selected slot shows a separate
# statically-clipped 242x242 poster, so the circle visibly grows without exposing
# rectangular poster corners even during fast navigation. Rating is bottom-center.
# No timer/network/cache path.
def _vod_poster_style_spec(style):
    key = str(style or "original").strip().lower()
    specs = {
        "original": {"x": [70,450,830,1210,1590], "y": 525, "w": 270, "h": 380, "label_y": 905, "rate_y": 916, "radius": 0},
        "circle": {"x": [86,461,836,1211,1586], "y": 610, "w": 222, "h": 222, "label_y": 838, "rate_y": 784, "radius": 222},
    }
    return key if key in specs else "original", specs.get(key, specs["original"])

def _vod_skin_with_poster_style(style):
    key, spec = _vod_poster_style_spec(style)
    if key == "original":
        return VOD
    skin = VOD
    skin = re.sub(r'<(?:ePixmap|widget)[^>]*(?:name="posterShell[0-4]"[^>]*|poster_card_shell_r75_270x435\.png[^>]*)/>\s*', '', skin)

    def geom(name, x, y, w, h, radius=None, font=None, fg=None, bg=None, halign=None, valign=None, transparent=None):
        nonlocal skin
        pattern = r'(<widget\s+name="%s"\s+)([^>]*)(/>)' % re.escape(name)
        def repl(m):
            attrs = m.group(2)
            attrs = re.sub(r'position="[^"]*"', 'position="%d,%d"' % (sx(x), sy(y)), attrs, count=1)
            attrs = re.sub(r'size="[^"]*"', 'size="%d,%d"' % (sx(w), sy(h)), attrs, count=1)
            attrs = re.sub(r'\s+cornerRadius="[^"]*"', '', attrs)
            if radius:
                attrs = attrs.rstrip() + ' cornerRadius="%d" ' % max(1, sx(radius))
            for attr, val in (("font", font),("foregroundColor", fg),("backgroundColor", bg),("halign", halign),("valign", valign)):
                if val is not None:
                    if re.search(r'\b%s="[^"]*"' % attr, attrs):
                        attrs = re.sub(r'\b%s="[^"]*"' % attr, '%s="%s"' % (attr,val), attrs, count=1)
                    else:
                        attrs = attrs.rstrip() + ' %s="%s" ' % (attr,val)
            if transparent is not None:
                attrs = re.sub(r'\s+transparent="[^"]*"', '', attrs)
                attrs = attrs.rstrip() + ' transparent="%d" ' % int(bool(transparent))
            return m.group(1) + attrs + m.group(3)
        skin = re.sub(pattern, repl, skin, count=1)

    if key == "circle":
        shell = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/vod_circle_shell_r222.png'
        for i, x in enumerate(spec["x"]):
            marker = '<widget name="poster%d"' % i
            ring = '<ePixmap position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" zPosition="2" />\n' % (
                sx(x-6), sy(spec["y"]-6), sx(234), sy(234), shell)
            skin = skin.replace(marker, ring + marker, 1)
            geom("poster%d" % i, x, spec["y"], 222, 222, 222)
            # r225: circle view has its own transparent round placeholder so missing artwork
            # can never expose the rectangular generic NO POSTER card outside the ring.
            poster_pattern = r'(<widget\s+name="poster%d"\s+)([^>]*)(/>)' % i
            def poster_placeholder_repl(m):
                attrs = m.group(2)
                attrs = re.sub(r'pixmap="[^"]*"', 'pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/vod_circle_no_poster_r225.png"', attrs, count=1)
                return m.group(1) + attrs + m.group(3)
            skin = re.sub(poster_pattern, poster_placeholder_repl, skin, count=1)
            # A second poster widget is statically round-clipped at its focused size.
            # It is hidden by default and shown only for the selected slot.
            marker_after = '<widget name="poster%d"' % i
            # Inject focused duplicate immediately before its base poster so Enigma
            # creates a normal Pixmap component with a fixed 242x242 corner radius.
            focus_widget = '<widget name="posterFocus%d" position="%d,%d" size="%d,%d" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/vod_circle_no_poster_r225.png" alphatest="blend" scale="1" cornerRadius="%d" zPosition="4" />\n' % (
                i, sx(x-10), sy(spec["y"]-10), sx(242), sy(242), sx(242))
            skin = skin.replace(marker_after, focus_widget + marker_after, 1)
            # Premium gray-to-black rating strip, fully inside the lower-center of the circle.
            rate_bar = '<ePixmap position="%d,%d" size="%d,%d" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/vod_rating_bar_grayblack_r224.png" alphatest="blend" zPosition="5" />\n' % (
                sx(x+53), sy(spec["y"]+169), sx(116), sy(34))
            skin = skin.replace(marker, rate_bar + marker, 1)
            geom("posterRate%d" % i, x+58, spec["y"]+171, 106, 30, None,
                 font="Regular;%d" % max(12, sy(18)), fg="#F4C542", bg="#00000000", halign="center", valign="center", transparent=True)
            geom("posterLabel%d" % i, x-8, spec["label_y"]-4, 238, 38, None,
                 font="Regular;%d" % max(14, sy(20)), fg="#D8DDE3", bg="#00000000", halign="center", valign="center", transparent=True)
        selector = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/vod_circle_focus_r223.png'
        pattern = r'(<widget\s+name="selector"\s+)([^>]*)(/>)'
        def sel(m):
            attrs=m.group(2)
            attrs=re.sub(r'position="[^"]*"','position="%d,%d"'%(sx(spec["x"][0]-18),sy(spec["y"]-18)),attrs,count=1)
            attrs=re.sub(r'size="[^"]*"','size="%d,%d"'%(sx(258),sy(258)),attrs,count=1)
            attrs=re.sub(r'pixmap="[^"]*"','pixmap="%s"'%selector,attrs,count=1)
            attrs=re.sub(r'\s+cornerRadius="[^"]*"','',attrs)
            return m.group(1)+attrs+m.group(3)
        skin=re.sub(pattern,sel,skin,count=1)
    return skin



UNIFIED_SERVER_EDITOR_SKIN = r"""<screen name="UnifiedServerEditor" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#03070B">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#03070B" zPosition="0"/>
    <eLabel position="0,0" size="1920,112" backgroundColor="#07101A" zPosition="1"/>
    <eLabel position="0,110" size="1920,2" backgroundColor="#1D6E9B" zPosition="2"/>

    <widget name="brandLabel" position="58,22" size="350,55" font="Regular;36" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="sectionLive" position="520,32" size="155,42" font="Regular;21" foregroundColor="#9FAEBD" transparent="1" halign="center" valign="center" zPosition="5"/>
    <widget name="sectionMovies" position="680,32" size="155,42" font="Regular;21" foregroundColor="#9FAEBD" transparent="1" halign="center" valign="center" zPosition="5"/>
    <widget name="sectionSeries" position="840,32" size="155,42" font="Regular;21" foregroundColor="#9FAEBD" transparent="1" halign="center" valign="center" zPosition="5"/>
    <widget name="sectionSettings" position="1000,32" size="185,42" font="Regular;21" foregroundColor="#55C7FF" transparent="1" halign="center" valign="center" zPosition="5"/>
    <widget name="settingsClock" position="1590,22" size="230,38" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="right" zPosition="5"/>
    <widget name="settingsDate" position="1510,65" size="310,28" font="Regular;17" foregroundColor="#8797A8" transparent="1" halign="right" zPosition="5"/>

    <!-- hidden compatibility widgets used by shared Settings chrome -->
    <widget name="settingsBrand" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsTagline" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsLogo" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="settingsSideTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsSideText" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsSideHint" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNavSelector" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="settingsGuide" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="settingsActionButtons" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="settingsNav0" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNav1" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNav2" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNav3" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNav4" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNav5" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="languageTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="languageSelector" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="language0" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="language1" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="language2" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="languageRadio0" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="languageRadio1" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="languageRadio2" position="-10,-10" size="1,1" transparent="1"/>

    <widget name="title" position="475,132" size="1370,56" font="Regular;38" foregroundColor="#FFFFFF" transparent="1" halign="left" valign="center" zPosition="5"/>
    <widget name="hint" position="475,190" size="1370,34" font="Regular;18" foregroundColor="#93A7B9" transparent="1" halign="left" valign="center" zPosition="5"/>

    <!-- protocol cards: same motion/logo idea as Server Manager -->
    <ePixmap position="65,250" size="360,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_editor_xtream_card_r203.png" alphatest="blend" zPosition="3"/>
    <ePixmap position="65,450" size="360,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_editor_m3u_card_r203.png" alphatest="blend" zPosition="3"/>
    <ePixmap position="65,650" size="360,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_editor_stalker_card_r203.png" alphatest="blend" zPosition="3"/>
    <eLabel position="185,284" size="205,38" text="XTREAM" font="Regular;30" foregroundColor="#6ED2FF" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="185,326" size="205,30" text="CODES API" font="Regular;19" foregroundColor="#2F9FFF" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="185,484" size="205,38" text="M3U" font="Regular;30" foregroundColor="#7AF09D" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="185,526" size="205,30" text="PLAYLIST" font="Regular;19" foregroundColor="#36D66A" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="185,684" size="205,38" text="STALKER" font="Regular;30" foregroundColor="#FFBE59" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="185,726" size="205,30" text="PORTAL" font="Regular;19" foregroundColor="#FF941F" transparent="1" halign="center" valign="center" zPosition="5"/>
    <ePixmap position="__FOCUS_X__,__FOCUS_Y__" size="360,180" pixmap="__FOCUS_PIX__" alphatest="blend" zPosition="7"/>

    <!-- main connection panel -->
    <eLabel position="455,245" size="1390,620" backgroundColor="#07131D" zPosition="2"/>
    <eLabel position="463,253" size="1374,604" backgroundColor="#0A1925" zPosition="3"/>
    <eLabel position="495,278" size="1308,52" backgroundColor="#0D2232" zPosition="4"/>
    <eLabel position="520,286" size="580,36" text="CONNECTION DETAILS" font="Regular;24" foregroundColor="__ACCENT__" transparent="1" valign="center" zPosition="5"/>
    <widget name="typeBadge" position="1190,282" size="570,36" font="Regular;22" foregroundColor="__ACCENT__" transparent="1" halign="right" valign="center" zPosition="5"/>
    <widget name="config" position="500,350" size="1290,420" itemHeight="60" font="Regular;23" foregroundColor="#EEF4F8" backgroundColor="#0A1925" transparent="0" scrollbarMode="showOnDemand" zPosition="8"/>

    <eLabel position="500,790" size="1290,2" backgroundColor="#263B49" zPosition="5"/>
    <widget name="typeDesc" position="515,805" size="530,50" font="Regular;19" foregroundColor="#D4DEE7" transparent="1" valign="center" zPosition="6"/>
    <widget name="typeHint" position="1080,805" size="700,50" font="Regular;18" foregroundColor="__ACCENT__" transparent="1" halign="right" valign="center" zPosition="6"/>

    <widget name="statusLine" position="440,885" size="1420,38" font="Regular;19" foregroundColor="#AEBBC7" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="440,940" size="1420,72" backgroundColor="#07131D" zPosition="2"/>
    <widget name="keys" position="470,952" size="1360,46" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0B1B28" transparent="0" halign="center" valign="center" zPosition="5"/>
</screen>"""

XTREAM_EDITOR_R203_SKIN = (UNIFIED_SERVER_EDITOR_SKIN
    .replace('__FOCUS_X__','65').replace('__FOCUS_Y__','250')
    .replace('__FOCUS_PIX__','/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_editor_xtream_focus_r203.png')
    .replace('__ACCENT__','#55C7FF').replace('__SELECT__','#123D5A'))
M3U_EDITOR_R203_SKIN = (UNIFIED_SERVER_EDITOR_SKIN
    .replace('__FOCUS_X__','65').replace('__FOCUS_Y__','450')
    .replace('__FOCUS_PIX__','/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_editor_m3u_focus_r203.png')
    .replace('__ACCENT__','#54E381').replace('__SELECT__','#123D2A'))
STALKER_EDITOR_R203_SKIN = (UNIFIED_SERVER_EDITOR_SKIN
    .replace('__FOCUS_X__','65').replace('__FOCUS_Y__','650')
    .replace('__FOCUS_PIX__','/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_editor_stalker_focus_r203.png')
    .replace('__ACCENT__','#FFAA35').replace('__SELECT__','#533414'))

# ---------------------------------------------------------------------------
# Source editors and import screens
# ---------------------------------------------------------------------------



def _ui_stability_log(event, detail=""):
    try:
        _tivimate_stability_log("ui", event, detail)
    except Exception:
        pass


def _ui_safe_call(event, fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except Exception as e:
        _ui_stability_log(event, repr(e))
        return None

