
# r427 diagnostic only: persistent checkpoints for Series restart tracing.
# No timer/hook/thread is added by this logger.
def _series_restart_log(stage, item=None, extra=""):
    return None

class SeriesDetailsScreen(Screen):
    skin = SERIES_DETAILS
    EPISODE_X = [80, 440, 800, 1160, 1520]

    def _seriesTmdbSearchTitles(self, title):
        """Ordered TMDb titles for SeriesDetails/episode artwork only.

        Keep the provider title intact.  When an IPTV provider appends a
        descriptive Arabic marker such as "... دراما: ...", the full title is
        still tried first, but we also expose the stable base title.  A normal
        title containing the word دراما is not shortened.
        """
        raw = re.sub(r"\s+", " ", str(title or "")).strip()
        if not raw:
            return []
        out = [raw]
        try:
            m = re.match(r"^(.+?)\s+دراما\s*:\s*(.+)$", raw, flags=re.UNICODE)
            if m:
                base = re.sub(r"\s+", " ", m.group(1)).strip(" -|:/._")
                suffix = re.sub(r"\s+", " ", m.group(2)).strip()
                if base and suffix and len(base.split()) >= 2 and base not in out:
                    out.append(base)
        except Exception:
            pass
        return out

    def _seriesTmdbNorm(self, value):
        text = str(value or "").lower()
        try:
            text = re.sub(r"[\u064b-\u065f\u0670\u06d6-\u06ed]", "", text)
        except Exception:
            pass
        text = re.sub(r"[^0-9a-z\u0600-\u06ff]+", " ", text, flags=re.UNICODE)
        return re.sub(r"\s+", " ", text).strip()

    def _searchSeriesTmdbSafe(self, client, title, year=None):
        """Resolve SeriesDetails TMDb id without letting a noisy provider suffix win.

        This is deliberately local to SeriesDetails because these results drive
        the episode still endpoint.  A wrong series id gives foreign episode
        thumbnails even when the episode numbers are correct.
        """
        candidates = self._seriesTmdbSearchTitles(title)
        if not candidates:
            return {}
        full = {}
        try:
            full = client.search_title(candidates[0], "series", year) or {}
            if not full and year:
                full = client.search_title(candidates[0], "series", None) or {}
        except Exception:
            full = {}
        if len(candidates) < 2:
            return full

        # For the explicit "دراما:" suffix pattern, also resolve the base name.
        # Prefer it only when TMDb's returned title actually matches that base.
        base = candidates[1]
        try:
            base_found = client.search_title(base, "series", year) or {}
            if not base_found and year:
                base_found = client.search_title(base, "series", None) or {}
        except Exception:
            base_found = {}
        if base_found:
            returned = (base_found.get("name") or base_found.get("title") or
                        base_found.get("original_name") or base_found.get("original_title") or "")
            bn = self._seriesTmdbNorm(base)
            rn = self._seriesTmdbNorm(returned)
            if bn and rn and (bn == rn or bn in rn or rn in bn):
                return base_found
        return full or base_found


    def __init__(self, session, source, seriesItem):
        _series_restart_log("DETAILS_INIT_ENTER", seriesItem, "source_type=%s" % str((source or {}).get("type") if isinstance(source, dict) else ""))
        Screen.__init__(self, session)
        _series_restart_log("DETAILS_SCREEN_INIT_OK", seriesItem)
        self.source = source
        self._vodSelectedSource = dict(self.source or {})
        self.seriesItem = seriesItem or {}
        self._serverPackageProvider = str(self.seriesItem.get("_server_package_provider") or self.seriesItem.get("_tmdb_provider") or "")
        self.seriesData = {}
        self.episodesBySeason = {}
        self.seasonItems = []
        self.episodeItems = []
        self.seasonIndex = 0
        self.episodePage = 0
        self.episodeIndex = 0
        self.downloads = []
        self.picloads = []
        self.backdropLoader = None
        self.backdropDownloader = None
        self.seriesFallbackPoster = ""
        self.seriesBackdrop = ""
        self["backdrop"] = Pixmap()
        self["providerLogo"] = Pixmap()
        self["title"] = Label(self.seriesItem.get("name") or self.seriesItem.get("title") or (tr("TV Show") if get_language() != "ar" else "مسلسل"))
        self["rating"] = Label("")
        self["ratingStars"] = Label("")
        self["meta"] = Label("")
        self["cast"] = Label("")
        self["desc"] = Label(tr(""))
        self["seasonInfo"] = Label("")
        self["episodeInfo"] = Label("")
        for i in range(5):
            self["episode%d" % i] = Pixmap()
            self["episodeLabel%d" % i] = Label("")
        self["episodeSelector"] = Pixmap()
        self["keys"] = Label(tr("LEFT/RIGHT Episodes    UP/DOWN Change Season    OK Play    RED Favorite    EXIT Back"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "yellowlong": self.addSeriesFavourite
        }, -1)
        self.onLayoutFinish.append(self._updateProviderLogo)
        self.onLayoutFinish.append(self._startSeriesArtworkFirst)
        _series_restart_log("DETAILS_INIT_DONE", self.seriesItem)


    def _updateProviderLogo(self):
        try:
            provider = str((self.seriesItem or {}).get("_server_package_provider") or (self.seriesItem or {}).get("_tmdb_provider") or self._serverPackageProvider or "").strip().lower()
            if provider == "prime_video":
                provider = "prime"
            path = package_logo_for_key(provider)
            if path and os.path.exists(path):
                self["providerLogo"].instance.setPixmapFromFile(path)
                self["providerLogo"].show()
            else:
                self["providerLogo"].hide()
        except Exception:
            try: self["providerLogo"].hide()
            except Exception: pass


    def _normImage(self, value):
        if isinstance(value, list):
            value = value[0] if value else ""
        if isinstance(value, str):
            v = value.strip().replace("\\/", "/")
            if v.startswith("["):
                try:
                    arr = json.loads(v)
                    v = arr[0] if arr else ""
                except Exception:
                    pass
            if v.startswith("/") and not v.startswith("//"):
                v = "https://image.tmdb.org/t/p/w1280" + v
            return v
        return ""

    def _normSeriesTitle(self, value):
        text = str(value or "").lower()
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"\b(?:4k|uhd|fhd|hd|sd|1080p|720p|2160p|ar|en|eng|arabic|english|netflix|amz|amzn|web[- ]?dl|webrip)\b", " ", text)
        text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
        return " ".join(text.split())

    def _seriesServerBackdrop(self, *mappings):
        """Resolve provider backdrop fields against the active server.

        A leading slash from Xtream/Stalker is a server-relative path, not a
        TMDb path. TMDb paths are handled separately before this helper.
        """
        for mapping in mappings:
            if not isinstance(mapping, dict):
                continue
            for key in ("backdrop_path", "backdrop", "backdrop_url", "movie_backdrop", "screenshot_uri"):
                value = mapping.get(key)
                if value not in (None, "", [], {}):
                    try:
                        url = _server_asset_url(self._vodSelectedSource or {}, value)
                    except Exception:
                        url = ""
                    if url:
                        return url
        return ""

    def _startSeriesArtworkFirst(self):
        _series_restart_log("LAYOUT_ARTWORK_ENTER", self.seriesItem)
        try:
            # Use the same provider-poster resolver as Movies/player. It checks
            # all common poster fields and resolves relative server URLs correctly.
            poster = _server_poster_url(self._vodSelectedSource or {}, self.seriesItem)
            if not poster:
                poster = self._normImage(self.seriesItem.get("poster_path") or "")
            tmdb_backdrop = self._normImage(self.seriesItem.get("_tmdb_backdrop") or "")
            backdrop = tmdb_backdrop or self._seriesServerBackdrop(self.seriesItem)
            self.seriesFallbackPoster = poster
            # Backdrop stays a backdrop. Never stretch a poster into the large
            # background, and do not replace an already-visible backdrop later.
            self.seriesBackdrop = backdrop
            self._seriesBackdropLocked = bool(backdrop)
            if self.seriesBackdrop:
                _series_restart_log("BACKDROP_LOAD_CALL", self.seriesItem, self.seriesBackdrop)
                self.loadBackdrop(self.seriesBackdrop)
            _series_restart_log("LAYOUT_ARTWORK_RESOLVED", self.seriesItem, "poster=%s backdrop=%s" % (bool(self.seriesFallbackPoster), bool(self.seriesBackdrop)))
        except Exception as exc:
            _series_restart_log("LAYOUT_ARTWORK_ERROR", self.seriesItem, str(exc))
        try:
            timer = eTimer()
            self._seriesDeferredLoadTimer = timer
            def go():
                try: timer.stop()
                except Exception: pass
                self.loadSeries()
            try:
                self._seriesDeferredLoadConn = timer.timeout.connect(go)
            except Exception:
                timer.callback.append(go)
            timer.start(120, True)
            _series_restart_log("DEFER_TIMER_STARTED", self.seriesItem, "120ms")
        except Exception as exc:
            _series_restart_log("DEFER_TIMER_ERROR", self.seriesItem, str(exc))
            self.loadSeries()


    def loadSeries(self):
        sid = self.seriesItem.get("series_id") or self.seriesItem.get("stream_id")
        _series_restart_log("LOAD_SERIES_ENTER", self.seriesItem, "sid=%s" % str(sid))
        self["desc"].setText(tr(""))

        def worker():
            _series_restart_log("WORKER_ENTER", self.seriesItem, "sid=%s" % str(sid))
            try:
                source = dict(self._vodSelectedSource or {})
                chosen = dict(self.seriesItem or {})
                resolved_sid = sid

                # Popular/Trending never checks availability in the list.
                # Search the provider only after this details screen has opened.
                if not resolved_sid and chosen.get("_home_tmdb_feed"):
                    wanted_id = str(chosen.get("tmdb_id") or chosen.get("id") or "").strip()
                    wanted = self._normSeriesTitle(chosen.get("name") or chosen.get("title") or "")
                    wanted_year_match = re.search(r"\b(19|20)\d{2}\b", str(chosen.get("year") or chosen.get("first_air_date") or ""))
                    wanted_year = wanted_year_match.group(0) if wanted_year_match else ""
                    best = None

                    def row_tmdb_id(row):
                        row = row or {}
                        for mapping in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
                            for key in ("tmdb_id", "tmdb", "tmdbid"):
                                value = mapping.get(key)
                                if value not in (None, ""):
                                    try:
                                        return str(int(value))
                                    except Exception:
                                        value = str(value).strip()
                                        if value:
                                            return value
                        return ""

                    def match_rows(rows):
                        if wanted_id:
                            for candidate in rows or []:
                                if row_tmdb_id(candidate) == wanted_id:
                                    return dict(candidate)
                        selected = None
                        selected_score = 0.0
                        for candidate in rows or []:
                            cand = self._normSeriesTitle(candidate.get("name") or candidate.get("title") or "")
                            if not cand or not wanted:
                                continue
                            raw_year = candidate.get("year") or candidate.get("releaseDate") or candidate.get("first_air_date") or ""
                            ym = re.search(r"\b(19|20)\d{2}\b", str(raw_year))
                            row_year = ym.group(0) if ym else ""
                            if wanted_year and row_year and wanted_year != row_year:
                                continue
                            a=set(wanted.split()); b=set(cand.split())
                            overlap=a & b
                            coverage=float(len(overlap))/float(min(len(a),len(b))) if a and b else 0.0
                            union=float(len(a | b)) if a or b else 0.0
                            jaccard=float(len(overlap))/union if union else 0.0
                            ratio=SequenceMatcher(None,wanted,cand).ratio()
                            score=1.0 if wanted == cand else 0.0
                            if not score and coverage == 1.0 and min(len(a),len(b)) >= 2 and abs(len(a)-len(b)) <= 1:
                                score=0.98
                            elif not score and min(len(a),len(b)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
                                score=ratio
                            threshold=0.94 if wanted_year and row_year else 0.98
                            if score >= threshold and score > selected_score:
                                selected=dict(candidate); selected_score=score
                        return selected

                    try:
                        client = get_source_client(source)
                        if source.get("type") == "xtream":
                            best = match_rows(list(get_filtered_streams(source, "series", client) or []))
                        elif source.get("type") == "stalker":
                            cats,_ = get_cached_categories(source, "series", client=client, wait_for_server=True)
                            cats = filter_categories(source, "series", cats or [])
                            for cat in cats:
                                cid = str((cat or {}).get("category_id") or "")
                                if not cid:
                                    continue
                                rows,_origin = get_category_streams(source, "series", client, cid, use_cache=True, wait_for_server=True)
                                best = match_rows(rows or [])
                                if best:
                                    break
                        if best is not None:
                            chosen.update(best)
                            resolved_sid = best.get("series_id") or best.get("stream_id") or best.get("id")
                            self.seriesItem.update(best)
                            if self._serverPackageProvider:
                                self.seriesItem["_server_package_provider"] = self._serverPackageProvider
                                self.seriesItem["_tmdb_provider"] = self._serverPackageProvider
                    except Exception:
                        pass

                _series_restart_log("SERIES_INFO_BEFORE", chosen, "resolved_sid=%s" % str(resolved_sid))
                data = (get_source_client(source).series_info(resolved_sid) or {}) if resolved_sid else {}
                _series_restart_log("SERIES_INFO_AFTER", chosen, "keys=%s" % (list(data.keys())[:20] if isinstance(data, dict) else type(data).__name__))

                try:
                    info = data.get("info") or {}
                    raw_title = info.get("name") or chosen.get("name") or chosen.get("title") or ""
                    raw_year = info.get("releaseDate") or info.get("releasedate") or info.get("year") or chosen.get("year") or ""
                    year_match = re.search(r"\b(19|20)\d{2}\b", str(raw_year))
                    _series_restart_log("TMDB_METADATA_BEFORE", chosen, "title=%s" % str(raw_title)[:120])
                    tmdb = TMDbClient()
                    search_year = year_match.group(0) if year_match else None
                    # r435: this TMDb id drives episode stills. Resolve noisy
                    # provider titles here, on the actual SeriesDetails path,
                    # rather than only in the package-poster grid.
                    found = self._searchSeriesTmdbSafe(tmdb, raw_title, search_year) if raw_title else None
                    tid = (found or {}).get("id") or chosen.get("tmdb_id") or chosen.get("tmdb")
                    bundle = tmdb.details_bundle(tid, "series") if tid else {}
                    if found:
                        seed = dict(found); seed.update(bundle or {}); bundle = seed
                    # Match the player poster fallback when series details/TMDb
                    # metadata has no poster. Search artwork only in that case.
                    if raw_title and not (bundle or {}).get("poster_path"):
                        try:
                            artwork = tmdb.search_artwork(raw_title, kind="series", year=search_year, required_key="poster_path") or {}
                            if artwork.get("poster_path"):
                                seed = dict(artwork); seed.update(bundle or {})
                                seed["poster_path"] = artwork.get("poster_path")
                                bundle = seed
                        except Exception:
                            pass
                    if tid:
                        self.seriesItem["tmdb_id"] = str(tid)
                        data["_tmdb_id"] = str(tid)
                    data["_tmdb_bundle"] = bundle or {}
                    _series_restart_log("TMDB_METADATA_AFTER", chosen, "tmdb_id=%s poster=%s backdrop=%s" % (str(tid or ""), bool((bundle or {}).get("poster_path")), bool((bundle or {}).get("backdrop_path"))))
                except Exception as exc:
                    _series_restart_log("TMDB_METADATA_ERROR", chosen, str(exc))

                _series_restart_log("WORKER_READY_DISPATCH", self.seriesItem, "episodes_type=%s" % type((data or {}).get("episodes") if isinstance(data, dict) else None).__name__)
                if reactor:
                    reactor.callFromThread(self._seriesReady, data)
                else:
                    self._seriesReady(data)
            except Exception as exc:
                _series_restart_log("WORKER_ERROR", self.seriesItem, str(exc))
                if reactor:
                    reactor.callFromThread(self._seriesFailed, str(exc))
                else:
                    self._seriesFailed(str(exc))

        _series_restart_log("THREAD_CREATE", self.seriesItem)
        thread = threading.Thread(target=worker, name="TiviMateSeriesDetails")
        thread.daemon = True
        thread.start()
        _series_restart_log("THREAD_STARTED", self.seriesItem)


    def _seriesReady(self, data):
        _series_restart_log("SERIES_READY_ENTER", self.seriesItem, "data_type=%s" % type(data).__name__)
        try:
            self.seriesData = data or {}
            info = self.seriesData.get("info") or {}
            tmdb_data = self.seriesData.get("_tmdb_bundle") or {}
            # Keep an existing Arabic server title Arabic. TMDb must not replace
            # it with an English/localized name; it remains metadata fallback only.
            server_title = info.get("name") or self.seriesItem.get("name") or self.seriesItem.get("title") or ""
            if re.search(r"[\u0600-\u06FF]", str(server_title or "")):
                title = server_title
            else:
                title = tmdb_data.get("name") or server_title or (tr("TV Show") if get_language() != "ar" else "مسلسل")
            year = (tmdb_data.get("first_air_date") or info.get("releaseDate") or
                    info.get("releasedate") or info.get("year") or "")
            rating = tmdb_data.get("vote_average") or info.get("rating") or info.get("rating_5based") or ""
            tmdb_genre = ", ".join(x.get("name", "") for x in (tmdb_data.get("genres") or [])[:3] if x.get("name"))
            genre = tmdb_genre or info.get("genre") or ""
            cast = ", ".join(x.get("name", "") for x in ((tmdb_data.get("credits") or {}).get("cast") or [])[:8] if x.get("name"))
            if not cast:
                cast = info.get("cast") or info.get("actors") or ""
            director = ", ".join(x.get("name", "") for x in ((tmdb_data.get("credits") or {}).get("crew") or []) if x.get("job") in ("Director", "Creator"))
            if not director:
                director = info.get("director") or ""
            self["title"].setText(title)
            rating_text = "--"
            stars_text = "☆☆☆☆☆"
            try:
                rating_value = float(str(rating).replace(",", "."))
                if rating_value > 10.0:
                    rating_value = rating_value / 10.0
                rating_value = max(0.0, min(10.0, rating_value))
                rating_text = "%.1f" % rating_value
                star_value = rating_value / 2.0
                full = int(star_value)
                if (star_value - full) >= 0.5 and full < 5:
                    full += 1
                full = max(0, min(5, full))
                stars_text = ("★" * full) + ("☆" * (5 - full))
            except Exception:
                if rating:
                    rating_text = str(rating)[:4]
            self["rating"].setText(rating_text)
            self["ratingStars"].setText(stars_text)
            self["meta"].setText("  •  ".join(x for x in [str(year), str(genre)] if x))
            cast_text = []
            if cast:
                cast_text.append("طاقم الممثلين: %s" % str(cast)[:150])
            if director:
                cast_text.append("المخرج: %s" % str(director)[:90])
            self["cast"].setText("\n".join(cast_text))
            self["desc"].setText((tmdb_data.get("overview") or info.get("plot") or info.get("description") or "لا توجد معلومات")[:720])
            # Poster policy: provider/server first using the same resolver as
            # Movies/player (including nested info + relative server URLs), then TMDb.
            server_poster = _server_poster_url(self._vodSelectedSource or {}, self.seriesItem, extra=info)
            self.seriesFallbackPoster = server_poster or self._normImage(tmdb_data.get("poster_path") or "")
            resolvedBackdrop = self._normImage(tmdb_data.get("backdrop_path") or "")
            if not resolvedBackdrop:
                resolvedBackdrop = self._seriesServerBackdrop(info, self.seriesItem)
            if resolvedBackdrop and not getattr(self, "_seriesBackdropLocked", False):
                self.seriesBackdrop = resolvedBackdrop
                self._seriesBackdropLocked = True
                self.loadBackdrop(self.seriesBackdrop)
            if not self.seriesFallbackPoster or not self.seriesBackdrop:
                self._ensureSeriesArtworkFallback()

            raw = self.seriesData.get("episodes") or {}
            _series_restart_log("EPISODES_RAW", self.seriesItem, "type=%s seasons=%s" % (type(raw).__name__, len(raw) if hasattr(raw, "__len__") else "?"))
            self.episodesBySeason = {str(key): (value or []) for key, value in raw.items() if value}
            seasons = self.seriesData.get("seasons") or []
            self.seasonItems = []
            if seasons:
                for season in seasons:
                    number = str(season.get("season_number") if season.get("season_number") is not None else season.get("season") or "")
                    if self.episodesBySeason.get(number):
                        row = dict(season)
                        row["_num"] = number
                        self.seasonItems.append(row)
            if not self.seasonItems:
                for number in sorted(self.episodesBySeason.keys(), key=lambda value: int(value) if str(value).isdigit() else 999):
                    self.seasonItems.append({"_num": number, "name": (("Season %s" % number) if get_language() == "en" else (("Saison %s" % number) if get_language() == "fr" else ("الموسم %s" % number)))})
            self.seasonIndex = 0
            _series_restart_log("SEASONS_BUILT", self.seriesItem, "seasonItems=%d episodeSeasons=%d" % (len(self.seasonItems), len(self.episodesBySeason)))
            self.selectSeason()
            _series_restart_log("SERIES_READY_DONE", self.seriesItem)
        except Exception as exc:
            _series_restart_log("SERIES_READY_ERROR", self.seriesItem, str(exc))
            self._seriesFailed(str(exc))

    def _seriesFailed(self, error):
        self["desc"].setText("تعذر تحميل المسلسل\n%s" % error)

    def _setVisible(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def selectSeason(self):
        _series_restart_log("SELECT_SEASON_ENTER", self.seriesItem, "index=%s seasons=%s" % (str(self.seasonIndex), len(self.seasonItems)))
        if not self.seasonItems:
            self.episodeItems = []
            self["seasonInfo"].setText(tr("No seasons"))
            self.renderEpisodes()
            return
        self.seasonIndex = max(0, min(self.seasonIndex, len(self.seasonItems) - 1))
        season = self.seasonItems[self.seasonIndex]
        num = str(season.get("_num", ""))
        self.episodeItems = self.episodesBySeason.get(num, []) or []
        lang = get_language()
        if lang == "en":
            season_name = "Season %s" % num
            self["seasonInfo"].setText("SEASON %s / %d" % (num, len(self.seasonItems)))
        elif lang == "fr":
            season_name = "Saison %s" % num
            self["seasonInfo"].setText("SAISON %s / %d" % (num, len(self.seasonItems)))
        else:
            season_name = season.get("name") or "الموسم %s" % num
            self["seasonInfo"].setText("%s  /  %d حلقة" % (season_name, len(self.episodeItems)))
        self.episodePage = 0
        self.episodeIndex = 0
        _series_restart_log("SELECT_SEASON_RENDER", self.seriesItem, "season=%s episodes=%d" % (num, len(self.episodeItems)))
        self.renderEpisodes()

    def _episodeArtworkUrl(self, item, info=None):
        """Return a real episode/still image from provider data, if present."""
        item = item if isinstance(item, dict) else {}
        info = info if isinstance(info, dict) else {}
        # Episode APIs commonly expose landscape artwork in these fields.
        # Keep this separate from the generic series-poster resolver so a
        # portrait poster does not win over a real episode still.
        keys = (
            "screenshot_uri", "still_path", "backdrop_path", "backdrop", "backdrop_url",
            "movie_image", "image", "cover_big", "cover", "stream_icon"
        )
        for mapping in (item, item.get("info") if isinstance(item.get("info"), dict) else {}, info):
            for key in keys:
                value = mapping.get(key) if isinstance(mapping, dict) else None
                if value not in (None, "", [], {}):
                    try:
                        url = _server_poster_url(self._vodSelectedSource or {}, {key: value})
                    except Exception:
                        url = ""
                    if url:
                        return url
        return ""

    def _ensureSeriesArtworkFallback(self, force_poster=False, force_backdrop=False):
        """Mirror the player TMDb fallback, including failed provider artwork.

        A provider URL can be present but dead.  In that case the player falls
        back to TMDb after the download fails; SeriesDetails must do the same.
        """
        if getattr(self, "_seriesArtworkFallbackPending", False):
            return
        title = str(
            self.seriesItem.get("name") or self.seriesItem.get("title") or
            (self.seriesData.get("info") or {}).get("name") or ""
        ).strip()
        tid = str(
            (self.seriesData or {}).get("_tmdb_id") or self.seriesItem.get("tmdb_id") or
            self.seriesItem.get("tmdb") or ""
        ).strip()
        if not title and not tid:
            return
        self._seriesArtworkFallbackPending = True
        token = "%s|%s" % (tid, title)
        self._seriesArtworkFallbackToken = token

        def worker():
            resolved_tid = tid
            poster = ""
            backdrop = ""
            try:
                client = TMDbClient()
                data = client.details_bundle(resolved_tid, "series") if resolved_tid else {}
                poster = (data or {}).get("poster_path") or ""
                backdrop = (data or {}).get("backdrop_path") or ""
                if not poster or not backdrop:
                    raw_year = (
                        self.seriesItem.get("year") or self.seriesItem.get("releaseDate") or
                        self.seriesItem.get("releasedate") or (self.seriesData.get("info") or {}).get("year") or ""
                    )
                    match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                    found = self._searchSeriesTmdbSafe(
                        client, title, match.group(0) if match else None
                    ) if title else None
                    new_tid = (found or {}).get("id")
                    if new_tid:
                        resolved_tid = str(new_tid)
                        detail = client.details_bundle(resolved_tid, "series") or {}
                        data = dict(found or {})
                        data.update(detail)
                    elif found:
                        data = found
                    poster = poster or (data or {}).get("poster_path") or ""
                    backdrop = backdrop or (data or {}).get("backdrop_path") or ""
                poster = self._normImage(poster)
                backdrop = self._normImage(backdrop)
            except Exception:
                poster = ""
                backdrop = ""

            def apply():
                if getattr(self, "_seriesArtworkFallbackToken", "") != token:
                    return
                self._seriesArtworkFallbackPending = False
                previous_tid = str((self.seriesData or {}).get("_tmdb_id") or self.seriesItem.get("tmdb_id") or "").strip()
                if resolved_tid:
                    self.seriesItem["tmdb_id"] = str(resolved_tid)
                    self.seriesData["_tmdb_id"] = str(resolved_tid)
                changed = bool(resolved_tid and str(resolved_tid) != previous_tid)
                if poster and ((force_poster and poster != self.seriesFallbackPoster) or not self.seriesFallbackPoster):
                    self.seriesFallbackPoster = poster
                    changed = True
                if backdrop and ((force_backdrop and backdrop != self.seriesBackdrop) or not self.seriesBackdrop):
                    self.seriesBackdrop = backdrop
                    self._seriesBackdropLocked = True
                    self.loadBackdrop(backdrop)
                    changed = True
                # A newly resolved TMDb id is itself enough reason to repaint:
                # missing episode cards can now request their real TMDb stills.
                if changed and self.episodeItems:
                    self.renderEpisodes()

            if reactor:
                reactor.callFromThread(apply)
            else:
                apply()

        thread = threading.Thread(target=worker, name="TiviMateSeriesArtworkFallback")
        thread.daemon = True
        thread.start()

    def _episodeNumbers(self, item, absolute_index):
        try:
            season = str(self.seasonItems[self.seasonIndex].get("_num", "") or "") if self.seasonItems else ""
        except Exception:
            season = ""
        info = (item or {}).get("info") or {}
        if not season:
            season = str((item or {}).get("season") or (item or {}).get("season_number") or info.get("season") or info.get("season_number") or "")
        episode = ((item or {}).get("episode_num") or (item or {}).get("episode_number") or
                   info.get("episode_num") or info.get("episode_number") or (absolute_index + 1))
        try:
            return str(int(str(season).strip())), str(int(str(episode).strip()))
        except Exception:
            return "", ""

    def _queueEpisodeStill(self, slot, item, absolute_index):
        """Resolve a missing episode thumbnail from TMDb, then repaint that card."""
        tid = str((self.seriesData or {}).get("_tmdb_id") or self.seriesItem.get("tmdb_id") or "").strip()
        if not tid:
            self._ensureSeriesArtworkFallback()
            return
        season, episode = self._episodeNumbers(item, absolute_index)
        if not season or not episode:
            return
        key = "%s:%s:%s" % (tid, season, episode)
        pending = getattr(self, "_episodeStillPending", None)
        if pending is None:
            pending = set()
            self._episodeStillPending = pending
        if key in pending or str((item or {}).get("_tmdb_episode_still") or "").strip():
            return
        pending.add(key)

        def worker():
            still = ""
            try:
                row = TMDbClient()._get("/tv/%s/season/%s/episode/%s" % (tid, season, episode), {}) or {}
                still = self._normImage(row.get("still_path") or "")
            except Exception:
                still = ""

            def apply():
                try:
                    self._episodeStillPending.discard(key)
                except Exception:
                    pass
                if not still:
                    return
                try:
                    item["_tmdb_episode_still"] = still
                except Exception:
                    return
                current = self.episodePage + slot
                if 0 <= current < len(self.episodeItems) and self.episodeItems[current] is item:
                    fallback = self.seriesFallbackPoster or self.seriesBackdrop
                    self._loadThumb(
                        slot, still, (330, 186), fallback_url=fallback,
                        kind="backdrops",
                        fallback_kind=("posters" if self.seriesFallbackPoster else "backdrops")
                    )
                selected = self.episodePage + self.episodeIndex
                if selected == absolute_index:
                    self.loadBackdrop(still)

            if reactor:
                reactor.callFromThread(apply)
            else:
                apply()

        thread = threading.Thread(target=worker, name="TiviMateEpisodeStill")
        thread.daemon = True
        thread.start()

    def renderEpisodes(self):
        _series_restart_log("RENDER_EPISODES_ENTER", self.seriesItem, "page=%s index=%s count=%s active_picloads=%s" % (str(self.episodePage), str(self.episodeIndex), len(self.episodeItems), len(getattr(self, "picloads", []) or [])))
        self.downloads = []
        # r428: NEVER drop active ePicLoad objects while their async decode
        # callback is still pending.  Enigma2's native decoder keeps using the
        # Python-owned loader; replacing this list can release the loader and
        # produce a native restart with no Python crash screen.  Each completed
        # loader already removes itself in _decodeThumb.ready(), so preserving
        # the list is both bounded and safe across episode-page redraws.
        if not isinstance(getattr(self, "picloads", None), list):
            self.picloads = []
        for slot in range(5):
            idx = self.episodePage + slot
            item = self.episodeItems[idx] if idx < len(self.episodeItems) else None
            self._setVisible("episode%d" % slot, bool(item))
            self._setVisible("episodeLabel%d" % slot, bool(item))
            if not item:
                self["episodeLabel%d" % slot].setText(tr(""))
                continue
            ep = item.get("episode_num") or item.get("episode_number") or (idx + 1)
            lang = get_language()
            fallback_title = ("Episode %s" % ep) if lang == "en" else (("Épisode %s" % ep) if lang == "fr" else ("الحلقة %s" % ep))
            title = item.get("title") or item.get("name") or fallback_title
            prefix = ("EPISODE %s" % ep) if lang == "en" else (("ÉPISODE %s" % ep) if lang == "fr" else ("الحلقة %s" % ep))
            self["episodeLabel%d" % slot].setText("%s  •  %s" % (prefix, title[:24]))
            self._placeholder(slot)
            inf = item.get("info") or {}
            episode_url = self._episodeArtworkUrl(item, inf)
            tmdb_still = str(item.get("_tmdb_episode_still") or "").strip()
            fallback_url = self.seriesFallbackPoster or self.seriesBackdrop
            url = episode_url or tmdb_still or fallback_url
            if url:
                landscape = bool(episode_url or tmdb_still)
                primary_kind = "backdrops" if landscape else ("posters" if self.seriesFallbackPoster else "backdrops")
                fallback_kind = "posters" if self.seriesFallbackPoster and fallback_url == self.seriesFallbackPoster else "backdrops"
                self._loadThumb(slot, url, (330, 186),
                                fallback_url=(fallback_url if landscape and fallback_url and fallback_url != url else ""),
                                kind=primary_kind, fallback_kind=fallback_kind)
            if not episode_url and not tmdb_still:
                self._queueEpisodeStill(slot, item, idx)
        episode_prefetch = []
        for row in list(self.episodeItems or []):
            try:
                inf = (row or {}).get("info") or {}
                u = self._episodeArtworkUrl(row or {}, inf)
                if u:
                    episode_prefetch.append(u)
            except Exception:
                pass
        if episode_prefetch:
            prefetch_artwork(episode_prefetch, "backdrops", priority=2)
        if self.seriesFallbackPoster:
            prefetch_artwork([self.seriesFallbackPoster], "posters", priority=3)
        elif self.seriesBackdrop:
            prefetch_artwork([self.seriesBackdrop], "backdrops", priority=2)
        self._setVisible("episodeSelector", bool(self.episodeItems))
        self._moveSelector()
        self.previewEpisode()
        _series_restart_log("RENDER_EPISODES_DONE", self.seriesItem, "page=%s active_picloads=%s" % (str(self.episodePage), len(getattr(self, "picloads", []) or [])))

    def _placeholder(self, slot):
        try:
            self["episode%d" % slot].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "series/episode_placeholder.png"))
        except Exception:
            pass

    def _loadThumb(self, slot, url, size, fallback_url="", retry=1, kind="backdrops", fallback_kind="posters"):
        url = (url or "").strip().replace("\\/", "/")
        fallback_url = (fallback_url or "").strip().replace("\\/", "/")
        kind = kind if kind in ("posters", "backdrops") else "backdrops"
        fallback_kind = fallback_kind if fallback_kind in ("posters", "backdrops") else "posters"
        if not url:
            if fallback_url:
                return self._loadThumb(slot, fallback_url, size, fallback_url="", retry=0, kind=fallback_kind, fallback_kind=fallback_kind)
            return
        requests = getattr(self, "_episode_artwork_requests", None)
        if requests is None:
            requests = {}
            self._episode_artwork_requests = requests
        token = "%s|%s" % (slot, url)
        requests[slot] = token

        def done(path, s=slot, sz=size, expected=token):
            if getattr(self, "_episode_artwork_requests", {}).get(s) != expected:
                return
            self._decodeThumb(s, path, sz)

        def failed(_path, s=slot, primary=url, fb=fallback_url, retries=retry):
            if getattr(self, "_episode_artwork_requests", {}).get(s) != token:
                return
            if retries > 0:
                self._loadThumb(s, primary, size, fallback_url=fb, retry=retries - 1, kind=kind, fallback_kind=fallback_kind)
            elif fb and fb != primary:
                self._loadThumb(s, fb, size, fallback_url="", retry=0, kind=fallback_kind, fallback_kind=fallback_kind)
            else:
                # Important: a non-empty provider poster may still be a dead URL.
                # The player detects that at download time and falls back to TMDb;
                # make SeriesDetails follow the exact same rule.
                try:
                    if primary == self.seriesFallbackPoster:
                        self._ensureSeriesArtworkFallback(force_poster=True)
                    else:
                        # Also resolve a TMDb id so an episode whose provider still
                        # failed can be repainted from /season/N/episode/N/still_path.
                        self._ensureSeriesArtworkFallback()
                except Exception:
                    pass

        request_artwork(url, kind, done, priority=45, errback=failed)

    def _decodeThumb(self, slot, path, size):
        loader = ePicLoad()
        self.picloads.append(loader)
        def ready(_info=None, s=slot, l=loader):
            try:
                ptr = l.getData()
                if ptr and self["episode%d" % s].instance:
                    self["episode%d" % s].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(size[0], size[1])
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def _moveSelector(self):
        try:
            self["episodeSelector"].instance.move(ePoint(sx(self.EPISODE_X[self.episodeIndex] - 8), sy(632)))
        except Exception:
            pass

    def left(self):
        idx = self.episodePage + self.episodeIndex
        if idx <= 0:
            return
        if self.episodeIndex > 0:
            self.episodeIndex -= 1
        else:
            self.episodePage = max(0, self.episodePage - 5)
            self.episodeIndex = min(4, len(self.episodeItems) - self.episodePage - 1)
            self.renderEpisodes()
        self._moveSelector()
        self.previewEpisode()

    def right(self):
        idx = self.episodePage + self.episodeIndex
        if idx + 1 >= len(self.episodeItems):
            return
        if self.episodeIndex < 4 and self.episodeIndex + 1 < len(self.episodeItems) - self.episodePage:
            self.episodeIndex += 1
        else:
            self.episodePage += 5
            self.episodeIndex = 0
            self.renderEpisodes()
        self._moveSelector()
        self.previewEpisode()

    def up(self):
        if self.seasonIndex > 0:
            self.seasonIndex -= 1
            self.selectSeason()

    def down(self):
        if self.seasonIndex + 1 < len(self.seasonItems):
            self.seasonIndex += 1
            self.selectSeason()

    def previewEpisode(self):
        idx = self.episodePage + self.episodeIndex
        ep = self.episodeItems[idx] if 0 <= idx < len(self.episodeItems) else None
        if not ep:
            self["episodeInfo"].setText(tr(""))
            return
        inf = ep.get("info") or {}
        num = ep.get("episode_num") or ep.get("episode_number") or (idx + 1)
        lang = get_language()
        fallback_title = ("Episode %s" % num) if lang == "en" else (("Épisode %s" % num) if lang == "fr" else ("الحلقة %s" % num))
        title = ep.get("title") or ep.get("name") or fallback_title
        duration = inf.get("duration") or ep.get("duration") or ""
        plot = inf.get("plot") or inf.get("description") or ep.get("plot") or ""
        prefix = ("Episode %s" % num) if lang == "en" else (("Épisode %s" % num) if lang == "fr" else ("الحلقة %s" % num))
        info = "%s  •  %s" % (prefix, title)
        if duration:
            info += "  •  %s" % duration
        if plot:
            info += "    %s" % str(plot)[:180]
        self["episodeInfo"].setText(info)
        episode_art = self._episodeArtworkUrl(ep, inf) or str(ep.get("_tmdb_episode_still") or "").strip()
        if episode_art:
            self.loadBackdrop(episode_art)
        elif self.seriesBackdrop:
            self.loadBackdrop(self.seriesBackdrop)
        else:
            self._queueEpisodeStill(self.episodeIndex, ep, idx)
            self._ensureSeriesArtworkFallback()

    def toggleFavourite(self):
        added, saved = toggle_favourite(self.source, "series", self.seriesItem)
        title = self.seriesItem.get("name") or self.seriesItem.get("title") or "المسلسل"
        if not saved:
            self["keys"].setText(tr("Unable to save favorite"))
        elif added:
            self["keys"].setText("★ تمت إضافة %s إلى المفضلات" % title)
        else:
            self["keys"].setText("☆ تمت إزالة %s من المفضلات" % title)

    def addSeriesFavourite(self):
        if is_favourite(self.source, "series", self.seriesItem):
            self["keys"].setText(tr("Series is already in favorites"))
        elif add_favourite(self.source, "series", self.seriesItem):
            self["keys"].setText(tr("Series added to favorites"))
        else:
            self["keys"].setText(tr("Unable to save favorite"))

    def ok(self):
        idx = self.episodePage + self.episodeIndex
        if not (0 <= idx < len(self.episodeItems)):
            return
        ep = dict(self.episodeItems[idx] or {})
        series_title = self.seriesItem.get("name") or self.seriesItem.get("title") or ""
        episode_info = ep.get("info") or {}
        if not isinstance(episode_info, dict):
            episode_info = {}
        # r425: keep the player poster independent from episode thumbnails.
        # The episode rail keeps its original artwork path; the player receives
        # only the parent-series poster that this details screen already caches.
        player_cover = self._normImage(self.seriesFallbackPoster or "")
        if player_cover:
            ep["_player_cover"] = player_cover
            try:
                # r428: pass the real completed cache file when available.
                # The player can still fetch _player_cover through the existing
                # artwork queue if this page has not finished caching it yet.
                cover_cache = cached_artwork(player_cover, "posters")
                if cover_cache and os.path.exists(cover_cache):
                    ep["_player_cover_cache"] = cover_cache
            except Exception:
                pass
        if self.seriesItem.get("tmdb_id"):
            ep["tmdb_id"] = self.seriesItem.get("tmdb_id")
        if self.seriesFallbackPoster and not ep.get("_player_cover"):
            ep["_player_cover"] = self.seriesFallbackPoster
        ep["_tmdb_title"] = series_title
        ep["_tmdb_kind"] = "series"
        ep["series_name"] = series_title
        ep["series_id"] = self.seriesItem.get("series_id") or self.seriesItem.get("stream_id") or ep.get("series_id") or ""
        try:
            ep["_source_key"] = _source_identity(self.source)
        except Exception:
            ep["_source_key"] = ""
        ep["_source_type"] = self.source.get("type") or ""
        ep["_subdl_type"] = "tv"
        ep["_subdl_title"] = series_title
        ep["_subdl_season"] = self.seasonItems[self.seasonIndex].get("_num", "") if self.seasonItems else ""
        ep["_subdl_episode"] = ep.get("episode_num") or ep.get("episode_number") or (idx + 1)
        # Give every subtitle provider the same explicit TV identity.  Several
        # provider seekers read the standard season/episode fields rather than
        # TiviMate's _subdl_* aliases.
        if ep.get("_subdl_season") not in (None, ""):
            ep["season"] = ep.get("_subdl_season")
            ep["season_number"] = ep.get("_subdl_season")
        if ep.get("_subdl_episode") not in (None, ""):
            ep["episode_num"] = ep.get("_subdl_episode")
            ep["episode_number"] = ep.get("_subdl_episode")
        ep["_episode_items"] = list(self.episodeItems or [])
        ep["_episode_index"] = int(idx)
        ep["_episode_source"] = dict(self.source or {})
        try:
            if self.source.get("type") == "stalker":
                url = StalkerClient(self.source).stream_url(ep, "series")
            else:
                url = XtreamClient(self.source).episode_url(ep)
            service_type = int(_media_service_type(self.source, "series"))
            service = eServiceReference(service_type, 0, url)
            service.setName(ep.get("title") or ep.get("name") or "حلقة")
            ep["_kind"] = "episode"
            self.session.open(TiviMatePlayer, service, ep)
        except Exception as exc:
            self.session.open(MessageBox, "تعذر تشغيل الحلقة\n%s" % exc, MessageBox.TYPE_ERROR)

    def loadBackdrop(self, url):
        url = self._normImage(url)
        if not url:
            return
        self._series_backdrop_request = url

        def done(path, expected=url):
            if getattr(self, "_series_backdrop_request", "") != expected:
                return
            self.decodeBackdrop(path)

        def failed(_path, expected=url):
            if getattr(self, "_series_backdrop_request", "") != expected:
                return
            retries = getattr(self, "_series_backdrop_retries", {})
            count = retries.get(expected, 0)
            if count < 1:
                retries[expected] = count + 1
                self._series_backdrop_retries = retries
                def retry_failed(_p, exp=expected):
                    if getattr(self, "_series_backdrop_request", "") != exp:
                        return
                    try:
                        self._ensureSeriesArtworkFallback(force_backdrop=True)
                    except Exception:
                        pass
                request_artwork(expected, "backdrops", done, priority=115, errback=retry_failed)
            else:
                try:
                    self._ensureSeriesArtworkFallback(force_backdrop=True)
                except Exception:
                    pass

        request_artwork(url, "backdrops", done, priority=115, errback=failed)

    def decodeBackdrop(self, path):
        loader = ePicLoad()
        self.backdropLoader = loader
        def ready(_info=None, l=loader):
            try:
                ptr = l.getData()
                if ptr and self["backdrop"].instance:
                    self["backdrop"].instance.setPixmap(ptr)
            except Exception:
                pass
            finally:
                try:
                    if self.backdropLoader is l:
                        self.backdropLoader = None
                except Exception:
                    pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(1920, 1080)
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)


def _is_bein_sports_channel(item):
    """Return True for channels that clearly identify as beIN SPORTS.

    This is a local filter only. It never creates or resolves stream URLs.
    """
    item = item or {}
    parts = []
    for key in ("name", "title", "stream_display_name", "channel_name", "tvg_name", "epg_channel_name"):
        value = item.get(key)
        if value not in (None, ""):
            try:
                parts.append(str(value))
            except Exception:
                pass
    text = " ".join(parts).lower().replace("_", " ").replace("-", " ")
    compact = " ".join(text.split())
    return (
        "bein sports" in compact or "bein sport" in compact or
        "be in sports" in compact or "be in sport" in compact or
        u"بي ان سبورت" in compact or u"بي إن سبورت" in compact or u"بين سبورت" in compact
    )



RECENT_MEDIA_CACHE_FILE = data_path("recent_media_cache.json")
RECENT_MEDIA_CACHE_TTL = 1800  # 30 minutes

def _recent_media_cache_key(source, kind):
    try:
        raw = (_source_identity(source) + "|" + str(kind or "")).encode("utf-8", "ignore")
    except Exception:
        raw = (str(source) + "|" + str(kind or "")).encode("utf-8", "ignore")
    return hashlib.sha1(raw).hexdigest()

def _load_recent_media_cache(source, kind):
    try:
        data = load_json(RECENT_MEDIA_CACHE_FILE, {}) or {}
        row = data.get(_recent_media_cache_key(source, kind)) or {}
        saved = int(row.get("saved") or 0)
        if not saved or int(time.time()) - saved > RECENT_MEDIA_CACHE_TTL:
            return []
        items = row.get("items") or []
        return [dict(x) for x in items if isinstance(x, dict)]
    except Exception:
        return []

def _save_recent_media_cache(source, kind, items):
    try:
        data = load_json(RECENT_MEDIA_CACHE_FILE, {}) or {}
        data[_recent_media_cache_key(source, kind)] = {
            "saved": int(time.time()),
            "items": [dict(x) for x in (items or [])[:100] if isinstance(x, dict)],
        }
        save_json(RECENT_MEDIA_CACHE_FILE, data)
    except Exception:
        pass
