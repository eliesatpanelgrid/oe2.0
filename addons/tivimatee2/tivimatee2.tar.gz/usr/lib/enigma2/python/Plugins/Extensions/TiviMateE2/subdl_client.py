# -*- coding: utf-8 -*-

import hashlib
import io
import json
import os
import socket
import time
import zipfile

from urllib.parse import urlencode, urlparse
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .core import BASE, fetch, load_json, save_json
from .subtitle_title import subtitle_title_candidates
from .storage import data_path

SETTINGS_FILE = os.path.join(BASE, "subdl.json")
API_V2_URL = "https://api.subdl.com/api/v2/subtitles/search"
API_V1_URL = "https://api.subdl.com/api/v1/subtitles"
DOWNLOAD_HOST = "dl.subdl.com"
API_HOST = "api.subdl.com"
DOWNLOAD_PREFIX = "https://" + DOWNLOAD_HOST
V2_DOWNLOAD_PREFIX = "https://" + API_HOST + "/api/v2/subtitles/"
DOWNLOAD_DIR = data_path("subtitles")
MAX_SUBTITLE_BYTES = 3 * 1024 * 1024
# SubDL can intermittently close or delay a connection.  Requests happen in a
# background player thread, so use only two short bounded retries for transient
# faults.  Authentication and rate-limit failures are never retried.
REQUEST_ATTEMPTS = 3
RETRY_DELAYS = (0.35, 0.90)
# The installed SubsSupport parser is most reliable with SubRip.  Limiting
# external SubDL results to SRT prevents unsupported ASS/VTT files from being
# downloaded and then rejected by the receiver.
SAFE_FORMATS = ("srt",)
# Some SubDL downloads are ZIP archives even when the selected result is SRT.
# Extraction stays in memory, accepts SRT only, and is bounded against archives
# with excessive members or expansion ratios.
MAX_ARCHIVE_MEMBERS = 64
MAX_ARCHIVE_EXPANSION_RATIO = 250

AUTH_ERROR = "The SubDL key is invalid or inactive. Put a valid key.txt on HDD/USB/MMC or /etc/enigma2, choose Import SubDL API Key, then try again."
NETWORK_ERROR = "Could not connect to SubDL. Check your internet connection and try again."
SERVICE_ERROR = "SubDL could not process the request right now. Try again later."
RATE_LIMIT_ERROR = "The temporary SubDL request limit was reached. Wait a moment, then try again."
PAID_DOWNLOAD_ERROR = "SubDL accepted the search but requires an active paid API plan for this download. The subtitle was not downloaded."

LANGUAGE_CHOICES = [
    ("Arabic", "ar"),
    ("English", "en"),
    ("Turkish", "tr"),
    ("French", "fr"),
    ("Spanish", "es"),
]
KIND_CHOICES = [
    ("Standard", "standard"),
    ("Hearing Impaired (HI)", "hi"),
    ("All Types", "all"),
]


class SubDLError(Exception):
    pass


def load_settings():
    data = load_json(SETTINGS_FILE, {}) or {}
    language = str(data.get("language") or "ar").lower()
    known_languages = [item[1] for item in LANGUAGE_CHOICES]
    if language not in known_languages:
        language = "ar"
    kind = str(data.get("kind") or "standard").lower()
    if kind not in ("standard", "hi", "all"):
        kind = "standard"
    return {
        "api_key": str(data.get("api_key") or "").strip(),
        "language": language,
        "kind": kind,
    }


def save_settings(api_key, language="ar", kind="standard"):
    api_key = str(api_key or "").strip()
    language = str(language or "ar").lower()
    kind = str(kind or "standard").lower()
    if language not in [item[1] for item in LANGUAGE_CHOICES]:
        language = "ar"
    if kind not in ("standard", "hi", "all"):
        kind = "standard"
    save_json(SETTINGS_FILE, {"api_key": api_key, "language": language, "kind": kind})
    return True


def _text(value):
    return str(value or "").strip()


def _safe_file_stem(value, fallback="subtitle"):
    """Return a readable, receiver-safe filename stem for saved SubDL SRTs."""
    value = _text(value)
    allowed = []
    for char in value:
        if char.isalnum() or char in ("-", "_", "."):
            allowed.append(char)
        elif char.isspace():
            allowed.append("_")
    stem = "".join(allowed).strip("._")
    while "__" in stem:
        stem = stem.replace("__", "_")
    return (stem or fallback)[:96]


def _number(value):
    try:
        return int(str(value).strip())
    except Exception:
        return None


def _bool(value):
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in ("1", "true", "yes", "y", "hi")


def _file_format(entry):
    value = _text(entry.get("format") or entry.get("ext") or entry.get("file_extension") or entry.get("file_type")).lower().lstrip(".")
    if not value:
        name = _text(entry.get("name"))
        value = os.path.splitext(name)[1].lower().lstrip(".")
    return value


def _language_code(value):
    """Normalize SubDL's ISO-639 labels to our two-letter UI codes."""
    raw = _text(value).lower().replace("_", "-")
    aliases = {
        "ar": "ar", "ara": "ar", "arabic": "ar",
        "en": "en", "eng": "en", "english": "en",
        "tr": "tr", "tur": "tr", "turkish": "tr",
        "fr": "fr", "fra": "fr", "fre": "fr", "french": "fr",
        "es": "es", "spa": "es", "spanish": "es",
    }
    return aliases.get(raw, raw[:2])


def _api_language_code(value):
    return _language_code(value).upper()


def _archive_language_score(info, preferred_language):
    """Prefer the user's selected language when one ZIP has several SRT files."""
    name = _text(getattr(info, "filename", "")).lower()
    normal = name.replace("-", "_").replace(".", "_").replace(" ", "_")
    language = _language_code(preferred_language)
    aliases = {
        "ar": ("ar", "ara", "arabic"), "en": ("en", "eng", "english"),
        "tr": ("tr", "tur", "turkish"), "fr": ("fr", "fra", "fre", "french"),
        "es": ("es", "spa", "spanish"),
    }.get(language, (language,))
    padded = "_" + normal + "_"
    for alias in aliases:
        if alias and ("_" + alias + "_") in padded:
            return 1
    return 0


def _unpack_srt_archive(data, preferred_language=""):
    """Extract one bounded, safe SRT member from a SubDL ZIP response."""
    try:
        archive = zipfile.ZipFile(io.BytesIO(data), "r")
    except Exception:
        raise SubDLError("The subtitle archive could not be read.")
    try:
        candidates = []
        for info in archive.infolist()[:MAX_ARCHIVE_MEMBERS]:
            name = _text(getattr(info, "filename", "")).replace("\\", "/")
            parts = [part for part in name.split("/") if part]
            if (not name or name.endswith("/") or name.startswith("/") or ".." in parts or
                    not name.lower().endswith(".srt")):
                continue
            try:
                size = int(getattr(info, "file_size", 0) or 0)
                compressed = int(getattr(info, "compress_size", 0) or 0)
            except Exception:
                continue
            if size <= 0 or size > MAX_SUBTITLE_BYTES:
                continue
            if compressed > 0 and size > compressed * MAX_ARCHIVE_EXPANSION_RATIO:
                continue
            candidates.append(info)
        if not candidates:
            raise SubDLError("The subtitle archive does not contain a safe SRT file.")
        candidates.sort(key=lambda info: (-_archive_language_score(info, preferred_language), _text(getattr(info, "filename", "")).lower()))
        try:
            unpacked = archive.read(candidates[0])
        except Exception:
            raise SubDLError("Could not extract the subtitle from its archive.")
        if not unpacked or len(unpacked) > MAX_SUBTITLE_BYTES:
            raise SubDLError("The extracted subtitle file size is not accepted.")
        return unpacked
    finally:
        try:
            archive.close()
        except Exception:
            pass


def _normalise_srt_bytes(data, preferred_language=""):
    """Normalize a direct or ZIP-packaged SRT to UTF-8 for SubsSupport."""
    if not data:
        raise SubDLError("The subtitle file is empty.")
    if data.startswith(b"PK\x03\x04"):
        data = _unpack_srt_archive(data, preferred_language)
    for encoding in ("utf-8-sig", "utf-16", "utf-16-le", "utf-16-be",
                     "windows-1256", "iso-8859-6", "windows-1252", "latin-1"):
        try:
            text = data.decode(encoding)
            text = text.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
            if "-->" in text:
                return text.encode("utf-8")
        except Exception:
            pass
    raise SubDLError("The downloaded file is not a valid UTF-8 compatible SRT subtitle.")


def _safe_v2_id(value):
    value = _text(value)
    if not value or len(value) > 160:
        return ""
    for char in value:
        if not (char.isalnum() or char in ("-", "_")):
            return ""
    return value


def _is_v2_download_url(url):
    try:
        parsed = urlparse(_text(url))
        host = (getattr(parsed, "hostname", "") or parsed.netloc.split(":", 1)[0]).lower()
        path = (parsed.path or "").rstrip("/")
        return host == API_HOST and path.startswith("/api/v2/subtitles/") and path.endswith("/download")
    except Exception:
        return False


def _trusted_download_url(raw_url):
    raw_url = _text(raw_url)
    if raw_url.startswith("/"):
        raw_url = ("https://" + API_HOST + raw_url) if raw_url.startswith("/api/v2/") else DOWNLOAD_PREFIX + raw_url
    try:
        parsed = urlparse(raw_url)
        host = (getattr(parsed, "hostname", "") or parsed.netloc.split(":", 1)[0]).lower()
        path = parsed.path or ""
    except Exception:
        return ""
    if parsed.scheme != "https":
        return ""
    if host == DOWNLOAD_HOST and path.startswith("/subtitle/"):
        return raw_url
    if _is_v2_download_url(raw_url):
        return raw_url
    return ""


def _http_status(error):
    try:
        return int(getattr(error, "code", 0) or getattr(error, "status", 0) or 0)
    except Exception:
        return 0


def _payload_status(payload):
    if not isinstance(payload, dict):
        return 0
    return _number(payload.get("statusCode") or payload.get("status_code") or payload.get("code")) or 0


def _payload_message(payload):
    if not isinstance(payload, dict):
        return ""
    return _text(payload.get("message") or payload.get("error") or payload.get("detail"))


def _failure_status(failure):
    if isinstance(failure, dict):
        return _payload_status(failure)
    return _http_status(failure)


def _failure_text(failure):
    if isinstance(failure, dict):
        return _payload_message(failure).lower()
    try:
        return _text(getattr(failure, "reason", "") or str(failure)).lower()
    except Exception:
        return ""


def _is_auth_failure(failure):
    if _failure_status(failure) in (401, 403):
        return True
    text = _failure_text(failure)
    return any(marker in text for marker in (
        "not_authorized", "unauthorized", "not authorized", "invalid api", "invalid key",
        "api key", "authentication", "forbidden", "access denied"
    ))


def _is_rate_limit_failure(failure):
    return _failure_status(failure) == 429 or "rate limit" in _failure_text(failure)


def _is_paid_download_failure(failure):
    """Return True for SubDL's explicit paid-download entitlement response."""
    if _failure_status(failure) == 402:
        return True
    text = _failure_text(failure)
    return "paid_api_required" in text or "paid api" in text or "paid subscription" in text


def _payload_is_failure(payload):
    if not isinstance(payload, dict):
        return True
    if payload.get("status") is False:
        return True
    if _payload_status(payload) >= 400:
        return True
    text = _payload_message(payload).lower()
    return bool(text and any(marker in text for marker in (
        "not_authorized", "unauthorized", "not authorized", "invalid api", "invalid key",
        "authentication", "forbidden", "access denied"
    )))


def _is_network_failure(failure):
    if isinstance(failure, (URLError, socket.timeout, TimeoutError)):
        return True
    return not isinstance(failure, dict) and _failure_status(failure) == 0


def _is_transient_failure(failure):
    """Return True only for failures where one short retry is worthwhile."""
    status = _failure_status(failure)
    if _is_network_failure(failure):
        return True
    if status in (408, 425, 500, 502, 503, 504):
        return True
    # The shared JSON fetcher raises ValueError on a temporary HTML/empty body.
    return isinstance(failure, (ValueError, UnicodeError))


def _retry_delay(attempt):
    if attempt < len(RETRY_DELAYS):
        time.sleep(RETRY_DELAYS[attempt])


def _raise_request_failure(primary, fallback=None):
    failures = [failure for failure in (primary, fallback) if failure is not None]
    if any(_is_auth_failure(failure) for failure in failures):
        raise SubDLError(AUTH_ERROR)
    if any(_is_rate_limit_failure(failure) for failure in failures):
        raise SubDLError(RATE_LIMIT_ERROR)
    if failures and all(_is_network_failure(failure) for failure in failures):
        raise SubDLError(NETWORK_ERROR)
    if any(_failure_status(failure) >= 500 for failure in failures):
        raise SubDLError(SERVICE_ERROR)
    raise SubDLError(SERVICE_ERROR)


def _content_metadata(item):
    item = item or {}
    info = item.get("info") or {}
    series_title = _text(item.get("_subdl_title") or item.get("series_name") or item.get("series_title"))
    season = _number(item.get("_subdl_season") or item.get("season_number") or item.get("season"))
    episode = _number(item.get("_subdl_episode") or item.get("episode_num") or item.get("episode_number"))
    content_type = _text(item.get("_subdl_type")).lower()
    if content_type not in ("movie", "tv"):
        content_type = "tv" if series_title or season is not None or episode is not None else "movie"
    original_title = series_title if content_type == "tv" and series_title else _text(
        item.get("title") or item.get("name") or info.get("title") or info.get("name")
    )
    title_candidates = subtitle_title_candidates(original_title)
    if not title_candidates:
        raise SubDLError("There is not enough title information to search for subtitles.")
    title = title_candidates[0]
    year = _number(item.get("year") or item.get("release_year") or info.get("year"))
    if year is None:
        date = _text(item.get("release_date") or info.get("release_date") or info.get("releasedate"))
        if len(date) >= 4 and date[:4].isdigit():
            year = int(date[:4])
    tmdb_id = _text(item.get("tmdb_id") or info.get("tmdb_id"))
    imdb_id = _text(item.get("imdb_id") or info.get("imdb_id"))
    return {
        "title": title,
        "title_candidates": title_candidates,
        "type": content_type,
        "season": season,
        "episode": episode,
        "year": year,
        "tmdb_id": tmdb_id,
        "imdb_id": imdb_id,
    }


def _subtitle_groups(payload):
    """Return all likely subtitle groups from documented v1 and v2 payloads."""
    if not isinstance(payload, dict):
        return []
    groups = []
    for key in ("subtitles", "data", "items"):
        rows = payload.get(key)
        if isinstance(rows, list):
            groups.extend(row for row in rows if isinstance(row, dict))
    results = payload.get("results")
    if isinstance(results, list):
        for row in results:
            if not isinstance(row, dict):
                continue
            if any(name in row for name in ("unpack_files", "files", "subtitle_files", "download_url")):
                groups.append(row)
            for key in ("subtitles", "data", "items"):
                nested = row.get(key)
                if isinstance(nested, list):
                    groups.extend(entry for entry in nested if isinstance(entry, dict))
    return groups


def _files_from_group(group):
    files = group.get("unpack_files") or group.get("files") or group.get("subtitle_files") or []
    if isinstance(files, list) and files:
        return files
    if any(name in group for name in ("url", "download_url", "file_n_id", "n_id")):
        return [group]
    return []


def _entry_download_url(group, entry):
    raw_url = entry.get("url") or entry.get("download_url") or entry.get("file_url")
    if raw_url:
        trusted = _trusted_download_url(raw_url)
        if trusted:
            return trusted
    n_id = _safe_v2_id(entry.get("n_id") or group.get("n_id") or group.get("id"))
    file_n_id = _safe_v2_id(entry.get("file_n_id"))
    if n_id and file_n_id:
        return _trusted_download_url("/subtitle/%s/%s" % (n_id, file_n_id))
    # v2 can provide a subtitle ID but omit an unpacked file URL.  Its documented
    # download endpoint is authenticated in ``download`` below.
    if n_id:
        return _trusted_download_url(V2_DOWNLOAD_PREFIX + n_id + "/download?format=file")
    return ""


def _download_url_from_json(data):
    """Extract only a trusted SubDL file URL from a small download response."""
    try:
        if not data or len(data) > 65536:
            return ""
        payload = json.loads(data.decode("utf-8", "replace"))
    except Exception:
        return ""
    candidates = []
    if isinstance(payload, dict):
        for key in ("url", "download_url", "file_url", "link"):
            candidates.append(payload.get(key))
        nested = payload.get("data") or payload.get("result")
        if isinstance(nested, dict):
            for key in ("url", "download_url", "file_url", "link"):
                candidates.append(nested.get(key))
    for candidate in candidates:
        trusted = _trusted_download_url(candidate)
        if trusted:
            return trusted
    return ""


class SubDLClient(object):
    def __init__(self, api_key):
        self.api_key = _text(api_key)
        if not self.api_key:
            raise SubDLError("No SubDL key is saved. Put key.txt on HDD/USB/MMC or /etc/enigma2, choose Import SubDL API Key, then try again.")

    def _v2_params(self, meta, language):
        params = {
            "type": meta["type"],
            "languages": _api_language_code(language),
            "unpack": 1,
            "client": "custom_integration",
        }
        if meta["tmdb_id"]:
            params["tmdb_id"] = meta["tmdb_id"]
        elif meta["imdb_id"]:
            params["imdb_id"] = meta["imdb_id"]
        else:
            params["film_name"] = meta["title"]
        if meta["type"] == "tv":
            if meta["season"] is not None:
                params["season"] = meta["season"]
            if meta["episode"] is not None:
                params["episode"] = meta["episode"]
        return params

    def _v1_params(self, meta, language):
        params = {
            "api_key": self.api_key,
            "film_name": meta["title"],
            "type": meta["type"],
            "languages": _api_language_code(language),
            "releases": 1,
            "unpack": 1,
            "client": "custom_integration",
        }
        if meta["year"]:
            params["year"] = meta["year"]
        if meta["type"] == "tv":
            if meta["season"] is not None:
                params["season_number"] = meta["season"]
            if meta["episode"] is not None:
                params["episode_number"] = meta["episode"]
        if meta["tmdb_id"]:
            params["tmdb_id"] = meta["tmdb_id"]
        elif meta["imdb_id"]:
            params["imdb_id"] = meta["imdb_id"]
        return params

    def _fetch_with_retry(self, url, headers=None, timeout=12, as_json=False):
        """Fetch a SubDL URL with a small retry budget for transient faults."""
        failure = None
        for attempt in range(REQUEST_ATTEMPTS):
            try:
                value = fetch(url, headers=headers or {}, timeout=timeout, as_json=as_json)
                # JSON API responses can carry a temporary HTTP-style status even
                # though the transport itself succeeded.  Retry those only.
                if not (as_json and isinstance(value, dict) and _is_transient_failure(value)):
                    if value:
                        return value
                    failure = RuntimeError("empty SubDL response")
                else:
                    failure = value
            except Exception as exc:
                failure = exc
            if attempt + 1 < REQUEST_ATTEMPTS and _is_transient_failure(failure):
                _retry_delay(attempt)
                continue
            break
        if isinstance(failure, BaseException):
            raise failure
        return failure

    def _fetch_json(self, endpoint, params, headers=None):
        return self._fetch_with_retry(
            endpoint + "?" + urlencode(params),
            headers=headers or {},
            timeout=12,
            as_json=True,
        )

    def _search_payload(self, meta, language):
        v2_failure = None
        try:
            payload = self._fetch_json(
                API_V2_URL,
                self._v2_params(meta, language),
                {"Authorization": "Bearer " + self.api_key, "Accept": "application/json"},
            )
            if isinstance(payload, dict) and not _payload_is_failure(payload):
                return payload
            v2_failure = payload
        except Exception as exc:
            v2_failure = exc

        # A controlled v1 fallback keeps legacy SubDL API keys/devices working.
        # It is attempted only after the header-authenticated v2 route fails.
        try:
            payload = self._fetch_json(API_V1_URL, self._v1_params(meta, language))
            if isinstance(payload, dict) and not _payload_is_failure(payload):
                return payload
            _raise_request_failure(v2_failure, payload)
        except SubDLError:
            raise
        except Exception as exc:
            _raise_request_failure(v2_failure, exc)

    def _result_rows(self, payload, language, kind):
        """Extract compatible rows from one SubDL response."""
        results = []
        seen = set()
        for group in _subtitle_groups(payload):
            for entry in _files_from_group(group):
                if not isinstance(entry, dict):
                    continue
                fmt = _file_format(entry)
                if fmt not in SAFE_FORMATS:
                    continue
                entry_language = _language_code(entry.get("language") or group.get("language"))
                # Do not display English (or another language) when Arabic was selected.
                # The documented unpack response contains a language per raw file.
                if entry_language != language:
                    continue
                url = _entry_download_url(group, entry)
                if not url or url in seen:
                    continue
                size = _number(entry.get("size"))
                if size is not None and (size <= 0 or size > MAX_SUBTITLE_BYTES):
                    continue
                hearing_impaired = _bool(entry.get("hi") or entry.get("hearing_impaired"))
                if kind == "standard" and hearing_impaired:
                    continue
                if kind == "hi" and not hearing_impaired:
                    continue
                seen.add(url)
                release = _text(entry.get("release_name") or group.get("release_name") or entry.get("name"))
                display_language = entry_language.upper()
                flags = "HI" if hearing_impaired else "STD"
                popularity = _number(
                    entry.get("downloads") or entry.get("download_count") or entry.get("downloads_count") or
                    group.get("downloads") or group.get("download_count") or group.get("downloads_count")
                ) or 0
                label = "%s  •  %s  •  %s%s" % (
                    display_language,
                    flags,
                    fmt.upper(),
                    ("  •  " + release[:72]) if release else "",
                )
                results.append({
                    "url": url,
                    "format": fmt,
                    "language": display_language,
                    "hearing_impaired": hearing_impaired,
                    "release": release,
                    "popularity": popularity,
                    "label": label,
                })
        # General ranking: prefer the most downloaded compatible SRT, not a
        # particular video-resolution tag.  Users can still choose any result.
        results.sort(key=lambda row: (-int(row.get("popularity") or 0), row.get("release") or ""))
        return results[:40]

    def search(self, item, language, kind="standard"):
        """UltraStalker-compatible SubDL v1 search."""
        language = _language_code(language) or "ar"
        if language not in [entry[1] for entry in LANGUAGE_CHOICES]:
            raise SubDLError("The selected subtitle language is not supported.")
        meta = _content_metadata(item)
        params = {
            "api_key": self.api_key,
            "type": meta.get("type") or "movie",
            "languages": _api_language_code(language),
            "subs_per_page": "20",
            "releases": "1",
            "unpack": "1",
            "client": "custom_integration",
        }
        if meta.get("tmdb_id"):
            params["tmdb_id"] = meta.get("tmdb_id")
        elif meta.get("imdb_id"):
            params["imdb_id"] = meta.get("imdb_id")
        elif meta.get("title"):
            params["film_name"] = meta.get("title")
            if meta.get("year"):
                params["year"] = str(meta.get("year"))
        else:
            raise SubDLError("There is not enough title information to search for subtitles.")
        if params["type"] == "tv":
            if meta.get("season") is not None:
                params["season_number"] = str(meta.get("season"))
            if meta.get("episode") is not None:
                params["episode_number"] = str(meta.get("episode"))
        req = Request(API_V1_URL + "?" + urlencode(params), headers={
            "Accept": "application/json",
            "User-Agent": "UltraStalker/10.0",
        })
        try:
            with urlopen(req, timeout=15) as res:
                payload = json.loads(res.read(2 * 1024 * 1024).decode("utf-8", "replace"))
        except Exception as exc:
            if _is_auth_failure(exc):
                raise SubDLError(AUTH_ERROR)
            if _is_rate_limit_failure(exc):
                raise SubDLError(RATE_LIMIT_ERROR)
            raise SubDLError(NETWORK_ERROR)
        if not isinstance(payload, dict) or not payload.get("status"):
            raise SubDLError(str((payload or {}).get("error") or "SubDL search failed"))
        rows = []
        for group in payload.get("subtitles") or []:
            if not isinstance(group, dict):
                continue
            release = _text(group.get("release_name") or group.get("name") or "Subtitle")
            unpack = group.get("unpack_files") or []
            for entry in unpack:
                if not isinstance(entry, dict):
                    continue
                entry_lang = _language_code(entry.get("language") or group.get("language"))
                if entry_lang and entry_lang != language:
                    continue
                fmt = _text(entry.get("format") or "").lower()
                if fmt not in ("srt", "ass", "ssa", "vtt"):
                    continue
                hearing = _bool(entry.get("hi") or entry.get("hearing_impaired"))
                if kind == "standard" and hearing:
                    continue
                if kind == "hi" and not hearing:
                    continue
                url = _text(entry.get("url") or "")
                if not url:
                    continue
                name = _text(entry.get("name") or release)
                rows.append({
                    "url": url, "format": fmt, "language": language.upper(),
                    "hearing_impaired": hearing, "release": name, "archive": False,
                    "label": "%s  •  %s  •  %s  •  %s" % (language.upper(), "HI" if hearing else "STD", fmt.upper(), name[:72])
                })
            group_url = _text(group.get("url") or "")
            if group_url:
                rows.append({
                    "url": group_url, "format": "zip", "language": language.upper(),
                    "hearing_impaired": False, "release": release, "archive": True,
                    "label": "%s  •  ZIP  •  %s" % (language.upper(), release[:72])
                })
        if not rows:
            raise SubDLError("SubDL returned no downloadable subtitle.")
        return rows[:40]

    def download(self, result):
        """UltraStalker-compatible direct SubDL download."""
        if not isinstance(result, dict):
            raise SubDLError("The subtitle file selection is invalid.")
        url = _text(result.get("url") or "")
        if not url:
            raise SubDLError("The subtitle download URL is missing.")
        if url.startswith("/"):
            url = DOWNLOAD_PREFIX + url
        req = Request(url, headers={"User-Agent": "UltraStalker/10.0", "Accept": "*/*"})
        try:
            with urlopen(req, timeout=15) as res:
                data = res.read(8 * 1024 * 1024 + 1)
        except Exception as exc:
            if _is_auth_failure(exc):
                raise SubDLError(AUTH_ERROR)
            if _is_rate_limit_failure(exc):
                raise SubDLError(RATE_LIMIT_ERROR)
            raise SubDLError("Could not download the selected subtitle file.")
        if not data or len(data) > 8 * 1024 * 1024:
            raise SubDLError("The subtitle file size is not accepted.")
        archive = bool(result.get("archive")) or data[:2] == b"PK"
        raw = data
        ext = ".srt"
        if archive:
            try:
                zf = zipfile.ZipFile(io.BytesIO(data), "r")
                names = [n for n in zf.namelist() if os.path.splitext(n)[1].lower() in (".srt", ".ass", ".ssa", ".vtt")]
                if not names:
                    raise SubDLError("The subtitle archive contains no supported subtitle file.")
                names.sort(key=lambda n: (0 if n.lower().endswith(".srt") else 1, len(n)))
                chosen = names[0]
                raw = zf.read(chosen)
                ext = os.path.splitext(chosen)[1].lower()
            except SubDLError:
                raise
            except Exception:
                raise SubDLError("The subtitle archive could not be read.")
        else:
            fmt = _text(result.get("format") or "").lower()
            if fmt in ("srt", "ass", "ssa", "vtt"):
                ext = "." + fmt
        if ext in (".srt", ".vtt"):
            raw = _normalise_srt_bytes(raw, _language_code(result.get("language") or ""))
        try:
            if not os.path.isdir(DOWNLOAD_DIR):
                os.makedirs(DOWNLOAD_DIR)
            digest = hashlib.sha256(url.encode("utf-8")).hexdigest()[:12]
            release = _safe_file_stem(result.get("release") or "subtitle")
            path = os.path.join(DOWNLOAD_DIR, "%s_subdl_%s%s" % (release, digest, ext))
            with open(path, "wb") as handle:
                handle.write(raw)
        except Exception:
            raise SubDLError("Could not save the subtitle file on this receiver.")
        return path
