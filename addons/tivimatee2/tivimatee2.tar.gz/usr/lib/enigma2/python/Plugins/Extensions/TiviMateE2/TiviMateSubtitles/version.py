# -*- coding: utf-8 -*-
VER = "1.3.0"
PLUGIN_VERSION_TITLE = "TiviMate Subtitles %s" % VER
