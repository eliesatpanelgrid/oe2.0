
import os
import ssl
import sys
import subprocess
import shutil

from urllib.request import Request, urlopen

from .cache_manager import get_cache_root
from .storage import get_data_root
from .resource_guard import artwork_conversion_lock

UA = "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/0.6.26"
MAX_IMAGE_BYTES = 20 * 1024 * 1024
# A missed artwork URL should not hold a queue slot for a long time.  This is a
# network wait limit only; it does not resize, compress, or otherwise modify images.
IMAGE_TIMEOUT_SECONDS = 8


def _selected_data_root():
    """Use the same user-selected cache root as the rest of TiviMateE2."""
    try:
        return get_cache_root()
    except Exception:
        try:
            return get_data_root()
        except Exception:
            return "/var/tmp/tivimatee2-cache"


def _selected_log_path():
    return os.path.join(_selected_data_root(), "logs", "poster.log")


def log(msg):
    try:
        log_file = _selected_log_path()
        directory = os.path.dirname(log_file)
        if not os.path.isdir(directory):
            os.makedirs(directory)
        with open(log_file, "a") as handle:
            handle.write(str(msg) + "\n")
    except Exception:
        pass


def is_jpeg(data):
    return data[:3] == b"\xff\xd8\xff"


def is_png(data):
    return data[:8] == b"\x89PNG\r\n\x1a\n"


def is_webp(data):
    return len(data) > 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP"


def _atomic_replace(src, dst):
    try:
        os.replace(src, dst)
    except AttributeError:
        if os.path.exists(dst):
            os.remove(dst)
        os.rename(src, dst)


def convert_to_jpeg(src, dst):
    """Convert only formats unsupported by the target image decoder.

    JPEG and PNG never reach this function and remain byte-for-byte identical to
    the provider response.  For WebP/other formats, preserve native dimensions
    and use the highest practical JPEG quality rather than resizing artwork.
    """
    find_executable = getattr(shutil, "which", None)
    ffmpeg = (find_executable("ffmpeg") if find_executable else None) or "/usr/bin/ffmpeg"
    if os.path.exists(ffmpeg):
        try:
            lock_path = os.path.join(_selected_data_root(), "locks", "artwork-convert.lock")
            with artwork_conversion_lock(lock_path):
                subprocess.check_call([
                    ffmpeg, "-loglevel", "quiet", "-y", "-i", src,
                    "-q:v", "1", "-pix_fmt", "yuvj420p", dst
                ])
            return os.path.exists(dst) and os.path.getsize(dst) > 100
        except Exception as exc:
            log("ffmpeg convert failed: %s" % exc)
    return False


def _read_image(response):
    total = 0
    chunks = []
    while True:
        chunk = response.read(64 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > MAX_IMAGE_BYTES:
            raise RuntimeError("image exceeds %d bytes" % MAX_IMAGE_BYTES)
        chunks.append(chunk)
    return b"".join(chunks)


def _open_image_url(request):
    """Open an image URL with Python 3 urllib."""
    context_factory = getattr(ssl, "_create_unverified_context", None)
    try:
        if context_factory is not None:
            return urlopen(request, timeout=IMAGE_TIMEOUT_SECONDS, context=context_factory())
        return urlopen(request, timeout=IMAGE_TIMEOUT_SECONDS)
    except TypeError:
        return urlopen(request, timeout=IMAGE_TIMEOUT_SECONDS)


def main():
    if len(sys.argv) != 3:
        return 2
    url, path = sys.argv[1], sys.argv[2]
    raw = path + ".part"
    try:
        url = (url or "").strip().replace("\\/", "/")
        if not url.startswith(("http://", "https://")):
            raise RuntimeError("unsupported image URL")
        directory = os.path.dirname(path)
        if directory and not os.path.isdir(directory):
            os.makedirs(directory)
        referer = ""
        if "://" in url:
            scheme, rest = url.split("://", 1)
            referer = scheme + "://" + rest.split("/", 1)[0] + "/"
        headers = {
            "User-Agent": UA,
            "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
            "Referer": referer,
        }
        request = Request(url, headers=headers)
        response = _open_image_url(request)
        try:
            data = _read_image(response)
            content_type = (response.headers.get("Content-Type") or "").lower()
        finally:
            try:
                response.close()
            except Exception:
                pass
        if len(data) < 100:
            raise RuntimeError("small response: %d bytes" % len(data))
        if "text/html" in content_type or data[:40].lower().startswith((b"<!doctype html", b"<html")):
            raise RuntimeError("server returned HTML instead of image")
        with open(raw, "wb") as handle:
            handle.write(data)
        # Preserve normally supplied artwork exactly.  The output suffix is kept
        # stable for the cache, while ePicLoad detects JPEG/PNG by file contents.
        if is_jpeg(data) or is_png(data):
            _atomic_replace(raw, path)
        elif is_webp(data) or "webp" in content_type or "avif" in content_type:
            if not convert_to_jpeg(raw, path):
                raise RuntimeError("unsupported image format and conversion failed")
            try:
                os.remove(raw)
            except Exception:
                pass
        else:
            # Decode any other image format only when it is required for the
            # receiver.  Conversion never scales the artwork and uses q=1.
            if not convert_to_jpeg(raw, path):
                raise RuntimeError("unsupported image format and conversion failed")
            try:
                os.remove(raw)
            except Exception:
                pass
        return 0
    except Exception as exc:
        for candidate in (raw, path + ".raw"):
            try:
                if os.path.exists(candidate):
                    os.remove(candidate)
            except Exception:
                pass
        log("ERROR %s :: %s" % (url, exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
