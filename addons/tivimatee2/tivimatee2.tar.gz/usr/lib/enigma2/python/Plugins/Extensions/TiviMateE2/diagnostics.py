# -*- coding: utf-8 -*-
"""Low-overhead rotating diagnostics for TiviMateE2.

Never logs credentials or full URLs. The file is intended for crash/freeze
investigation on receivers and is capped so diagnostics cannot grow forever.
"""
import json
import os
import threading
import time
from .storage import data_path

_LOCK = threading.RLock()
_PATH = data_path("diagnostics.log")
_MAX_BYTES = 512 * 1024
_MAX_BACKUPS = 2
_SENSITIVE = ("username", "password", "token", "auth", "cookie", "apikey", "api_key")


def _safe(value):
    try:
        text = str(value if value is not None else "")
    except Exception:
        text = ""
    # Do not leak query strings or credentials embedded in IPTV URLs.
    if "://" in text:
        try:
            base = text.split("?", 1)[0]
            parts = base.split("/")
            if len(parts) > 3:
                return "/".join(parts[:3]) + "/..."
            return base
        except Exception:
            return "<url>"
    return text[:240]


def _rotate():
    try:
        if not os.path.exists(_PATH) or os.path.getsize(_PATH) < _MAX_BYTES:
            return
        for idx in range(_MAX_BACKUPS, 0, -1):
            src = _PATH + (".%d" % (idx - 1) if idx > 1 else "")
            dst = _PATH + ".%d" % idx
            if os.path.exists(src):
                try:
                    if os.path.exists(dst):
                        os.remove(dst)
                except Exception:
                    pass
                try:
                    os.rename(src, dst)
                except Exception:
                    pass
    except Exception:
        pass


def event(area, name, **fields):
    try:
        row = {"ts": round(time.time(), 3), "area": _safe(area), "event": _safe(name)}
        for key, value in fields.items():
            lk = str(key).lower()
            if any(s in lk for s in _SENSITIVE):
                row[str(key)] = "<redacted>"
            else:
                row[str(key)] = _safe(value)
        line = json.dumps(row, separators=(",", ":"), ensure_ascii=True) + "\n"
        with _LOCK:
            folder = os.path.dirname(_PATH)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            _rotate()
            with open(_PATH, "a") as handle:
                handle.write(line)
    except Exception:
        pass


def timer(area, name, **fields):
    start = time.time()
    def done(status="ok", **extra):
        payload = dict(fields)
        payload.update(extra)
        payload["status"] = status
        payload["ms"] = int((time.time() - start) * 1000)
        event(area, name, **payload)
    return done


def path():
    return _PATH
