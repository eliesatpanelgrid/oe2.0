# -*- coding: utf-8 -*-
"""Compatibility diagnostics API with disk logging disabled."""
import time

def event(area, name, **fields):
    return None

def timer(area, name, **fields):
    start = time.time()
    def done(status="ok", **extra):
        return None
    return done

def path():
    return ""
