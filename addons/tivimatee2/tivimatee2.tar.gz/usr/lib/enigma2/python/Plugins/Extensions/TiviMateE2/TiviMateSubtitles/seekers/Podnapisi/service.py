# -*- coding: utf-8 -*-

from __future__ import absolute_import
import os

from .pn_utilities import PNServer, OpensubtitlesHash, \
    calculateSublightHash, __scriptid__
from . import pn_utilities

from ..utilities import log, languageTranslate, normalizeString
from ..seeker import SubtitlesDownloadError, SubtitlesErrors


from six.moves import urllib


def Search(item):
    pn_server = PNServer()
    pn_server.Create()
    if item['temp']:
        item['OShash'] = "000000000000"
        item['SLhash'] = "000000000000"
    else:
        item['OShash'] = OpensubtitlesHash(item)
        item['SLhash'] = calculateSublightHash(item['file_original_path'])
        log(__scriptid__, "xbmc module OShash: %s, SLhash:%s" % (item['OShash'], item['SLhash']))

    log(__scriptid__, "Search for [%s] by name" % (os.path.basename(item['file_original_path']),))
    subtitles_list = pn_server.SearchSubtitlesWeb(item)
    return subtitles_list


def Download(params):
    pn_server = PNServer()
    pn_server.Create()
    url = pn_server.Download(params)
    return url



def _tivimate_validate_download(data, content_type=""):
    """Reject HTML/error bodies before the subtitle decoder sees them."""
    if data is None or len(data) == 0:
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Empty subtitle download")
    ctype = (content_type or "").lower()
    sample = data[:8192]
    lowered = sample.lstrip(b"\xef\xbb\xbf \t\r\n").lower()
    if ("text/html" in ctype or "application/xhtml" in ctype or
            lowered.startswith(b"<!doctype html") or lowered.startswith(b"<html") or
            b"<head" in lowered[:1024] or b"cloudflare" in lowered[:2048]):
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Provider returned HTML instead of subtitles")
    if sample.startswith(b"PK\x03\x04"):
        return "zip"
    if sample.startswith(b"Rar!\x1a\x07"):
        return "rar"
    # Plain subtitle formats retain ASCII timing/format markers even with Arabic legacy encodings.
    if (b"-->" in sample or b"WEBVTT" in sample[:64].upper() or
            b"[Script Info]" in sample or b"Dialogue:" in sample or
            __import__('re').search(br"\{\d+\}\{\d+\}", sample)):
        return "plain"
    raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Downloaded file is not a supported subtitle/archive")

def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):  # standard input
    pn_utilities.settings_provider = settings_provider
    item = {}
    item['temp'] = False
    item['rar'] = False
    item['year'] = year
    item['season'] = str(season)
    item['episode'] = str(episode)
    item['tvshow'] = tvshow
    item['title'] = title
    item['file_original_path'] = file_original_path
    item['3et_language'] = [languageTranslate(lang1, 0, 1), languageTranslate(lang2, 0, 1), languageTranslate(lang3, 0, 1)]

    if not item['title']:
        log(__scriptid__, "VideoPlayer.OriginalTitle not found")
        item['title'] = normalizeString(os.path.basename(item['file_original_path']))

    if item['episode'].lower().find("s") > -1:  # Check if season is "Special"
        item['season'] = "0"  #
        item['episode'] = item['episode'][-1:]

    if (item['file_original_path'].find("http") > -1):
        item['temp'] = True

    elif (item['file_original_path'].find("rar://") > -1):
        item['rar'] = True
        item['file_original_path'] = os.path.dirname(item['file_original_path'][6:])

    elif (item['file_original_path'].find("stack://") > -1):
        stackPath = item['file_original_path'].split(" , ")
        item['file_original_path'] = stackPath[0][8:]

    return Search(item), "", ""


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    pn_utilities.settings_provider = settings_provider
    params = subtitles_list[pos]
    params['match'] = params['sync']
    url = Download(params)
    language = params['language_name']
    if not url:
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Podnapisi download URL is missing")
    try:
        response = urllib.request.urlopen(url, timeout=12)
        data = response.read()
        content_type = response.headers.get('Content-Type', '') if getattr(response, 'headers', None) else ''
        kind = _tivimate_validate_download(data, content_type)
        with open(zip_subs, 'wb') as local_file:
            local_file.write(data)
    except SubtitlesDownloadError:
        raise
    except Exception as error:
        raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR, "Podnapisi download failed: %s" % error)
    if kind == 'zip':
        return True, language, 'zip'
    if kind == 'rar':
        return True, language, 'rar'
    return False, language, zip_subs
