# -*- coding: utf-8 -*-
"""Persistent, source-scoped favourites for TiviMate E2.

The store intentionally keeps only a hash of the configured source identity.  A
favourite therefore remains associated with its server without duplicating the
source URL, account name, or password into this file.
"""
from .storage import get_data_root, data_path

import hashlib
import io
import json
import os
import time

from .filters import source_filter_key

FAVORITES_FILE = data_path("favorites.json")
FAVORITES_VERSION = 1

text_type = str


def _text(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8", "ignore")
        except Exception:
            return str(value)
    try:
        return text_type(value)
    except Exception:
        return str(value)


def source_id(source):
    """Return a stable opaque identifier without persisting source credentials."""
    raw = _text(source_filter_key(source or {})).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _item_key(kind, item):
    item = item or {}
    values = []
    for key in ("stream_id", "series_id", "vod_id", "id", "url", "cmd", "name", "title"):
        value = item.get(key)
        if value is not None and _text(value).strip():
            values.append("%s=%s" % (key, _text(value).strip()))
            break
    raw = "%s|%s" % (_text(kind).lower(), "|".join(values))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _snapshot(item):
    """Keep fields needed for display and standard playback only.

    No server configuration is copied into a favourite record.  The selected
    server is resolved again from the normal source configuration at playback.
    """
    item = item or {}
    allowed = (
        "stream_id", "series_id", "vod_id", "id", "name", "title",
        "container_extension", "stream_icon", "cover", "cover_big",
        "movie_image", "backdrop", "backdrop_path", "backdrop_url",
        "category_id", "category_name", "group", "group-title",
        "rating", "rating_5based", "year", "releaseDate", "releasedate",
        "plot", "description", "genre", "tmdb_id", "added", "cmd",
        "url", "epg_channel_id", "channel_id"
    )
    result = {}
    for key in allowed:
        value = item.get(key)
        if value is None:
            continue
        if isinstance(value, (dict, list, tuple)):
            # Nested provider metadata is not required to restore an item.
            continue
        result[key] = _text(value)
    return result


def _empty():
    return {"version": FAVORITES_VERSION, "items": []}


def _load():
    try:
        with io.open(FAVORITES_FILE, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            return _empty()
        items = data.get("items")
        if not isinstance(items, list):
            items = []
        return {"version": FAVORITES_VERSION, "items": [x for x in items if isinstance(x, dict)]}
    except Exception:
        return _empty()


def _save(data):
    try:
        folder = os.path.dirname(FAVORITES_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = FAVORITES_FILE + ".tmp"
        with io.open(temporary, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, sort_keys=True, indent=2)
        os.rename(temporary, FAVORITES_FILE)
        return True
    except Exception:
        try:
            if os.path.exists(FAVORITES_FILE + ".tmp"):
                os.unlink(FAVORITES_FILE + ".tmp")
        except Exception:
            pass
        return False


def favourite_id(source, kind, item):
    return "%s:%s:%s" % (source_id(source), _text(kind).lower(), _item_key(kind, item))


def is_favourite(source, kind, item):
    target = favourite_id(source, kind, item)
    return any(record.get("id") == target for record in _load().get("items", []))


def list_favourites(kind=None):
    records = list(_load().get("items", []))
    if kind:
        records = [record for record in records if record.get("kind") == _text(kind).lower()]
    records.sort(key=lambda record: int(record.get("saved_at") or 0), reverse=True)
    return records


def add_favourite(source, kind, item):
    if not isinstance(item, dict):
        return False
    kind = _text(kind).lower().strip()
    if kind not in ("live", "vod", "series"):
        return False
    data = _load()
    record_id = favourite_id(source, kind, item)
    existing = [record for record in data["items"] if record.get("id") != record_id]
    snapshot = _snapshot(item)
    # Xtream and Stalker rebuild a stream URL from the normal source at playback.
    # Only M3U rows need their item URL retained to remain playable.
    if (source or {}).get("type") != "m3u":
        snapshot.pop("url", None)
    title = snapshot.get("name") or snapshot.get("title") or "IPTV"
    existing.append({
        "id": record_id,
        "source_id": source_id(source),
        "kind": kind,
        "title": title,
        "saved_at": int(time.time()),
        "item": snapshot,
    })
    data["items"] = existing
    return _save(data)


def remove_favourite(source, kind, item):
    data = _load()
    record_id = favourite_id(source, kind, item)
    original_count = len(data["items"])
    data["items"] = [record for record in data["items"] if record.get("id") != record_id]
    if len(data["items"]) == original_count:
        return True
    return _save(data)


def toggle_favourite(source, kind, item):
    if is_favourite(source, kind, item):
        return False, remove_favourite(source, kind, item)
    return True, add_favourite(source, kind, item)


def remove_record(record_id):
    """Remove a saved row even when the original source has been deleted."""
    data = _load()
    original_count = len(data["items"])
    data["items"] = [record for record in data["items"] if record.get("id") != record_id]
    if len(data["items"]) == original_count:
        return True
    return _save(data)


def source_for_record(record, sources):
    wanted = (record or {}).get("source_id", "")
    for source in (sources or []):
        try:
            if source_id(source) == wanted:
                return source
        except Exception:
            pass
    return None


def count():
    return len(_load().get("items", []))
