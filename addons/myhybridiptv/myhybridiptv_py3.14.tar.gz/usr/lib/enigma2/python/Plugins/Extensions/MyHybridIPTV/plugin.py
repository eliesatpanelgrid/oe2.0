#!/usr/bin/env python
# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Components.config import (
    config, ConfigSubsection, ConfigText, ConfigPassword, ConfigSelection
)

# ── Initialise config keys once on plugin load ────────────────────────────────
config.plugins.hybridiptv          = ConfigSubsection()
_c                                 = config.plugins.hybridiptv

_c.xtream                          = ConfigSubsection()
_c.xtream.name                     = ConfigText(default="",        fixed_size=False)
_c.xtream.host                     = ConfigText(default="http://", fixed_size=False)
_c.xtream.user                     = ConfigText(default="",        fixed_size=False)
_c.xtream.password                 = ConfigPassword(default="")

_c.m3u                             = ConfigSubsection()
_c.m3u.name                        = ConfigText(default="",        fixed_size=False)
_c.m3u.url                         = ConfigText(default="http://", fixed_size=False)

_c.stalker                         = ConfigSubsection()
_c.stalker.name                    = ConfigText(default="",        fixed_size=False)
_c.stalker.portal                  = ConfigText(default="http://",            fixed_size=False)
_c.stalker.mac                     = ConfigText(default="00:1A:79:00:00:00", fixed_size=False)

from Components.config import ConfigDirectory, ConfigLocations, ConfigYesNo
import os

def sanitize_path(path):
    if not path.endswith('/'):
        path += '/'
    return path

# Default medialist for bookmarks
medialist = []
try:
    with open('/proc/mounts', 'r') as f:
        for line in f:
            if '/media/' in line:
                mpath = line.split()[1]
                if mpath not in medialist:
                    medialist.append(mpath)
except:
    pass

# Download / subtitle settings
_c.download_dir                    = ConfigDirectory(default=sanitize_path("/media/hdd/movie/"))
_c.opensubtitles_api_key           = ConfigText(default="",                  fixed_size=False)
_c.subdl_api_key                   = ConfigText(default="",                  fixed_size=False)
_c.picon_cache_dir                 = ConfigDirectory(default=sanitize_path("/media/hdd/.hybridiptv_cache/"))
_c.bookmarks                       = ConfigLocations(default=[sanitize_path(m) for m in medialist + ['/media/hdd']])

# Subtitle Preferences
_c.sub_pos                         = ConfigSelection(default="bottom", choices=[("bottom", "Bottom"), ("middle", "Middle"), ("top", "Top")])
_c.sub_size                        = ConfigSelection(default="medium", choices=[("small", "Small"), ("medium", "Medium"), ("large", "Large"), ("extra", "Extra Large")])
_c.sub_color                       = ConfigSelection(default="white",  choices=[("white", "White"), ("yellow", "Yellow"), ("green", "Green")])

# Player Preferences
vodstreamtypelist_choices = [("4097", "4097 (Standard)")]
if os.path.exists('/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp'):
    vodstreamtypelist_choices.extend([("5001", "5001 (GSTPlayer)"), ("5002", "5002 (ExtePlayer3)")])
    
_c.vod_streamtype                  = ConfigSelection(default="4097", choices=vodstreamtypelist_choices)

# Content Filters
_c.show_adult                      = ConfigYesNo(default=False)




def main(session, **kwargs):
    from .main import IPTVMain
    session.open(IPTVMain)


def Plugins(**kwargs):
    try:
        from .utils.resolver import start_resolver_server
        start_resolver_server()
    except Exception as e:
        print("[MyHybridIPTV] Failed to start resolver server: %s" % str(e))

    try:
        from .utils.webif import start_webif_server
        start_webif_server()
    except Exception as e:
        print("[MyHybridIPTV] Failed to start web config server: %s" % str(e))

    return [
        PluginDescriptor(
            name        = "Hybrid IPTV",
            description = "Xtream / M3U / Stalker IPTV Player",
            where       = PluginDescriptor.WHERE_PLUGINMENU,
            icon        = "icon.png",
            fnc         = main,
        )
    ]
