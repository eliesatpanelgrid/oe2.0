#!/usr/bin/env python
# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Components.config import (
    config, ConfigSubsection, ConfigText, ConfigPassword
)

# ── Initialise config keys once on plugin load ────────────────────────────────
config.plugins.hybridiptv          = ConfigSubsection()
_c                                 = config.plugins.hybridiptv

_c.xtream                          = ConfigSubsection()
_c.xtream.name                     = ConfigText(default="",        fixed_size=False)
_c.xtream.host                     = ConfigText(default="http://", fixed_size=False)
_c.xtream.user                     = ConfigText(default="",        fixed_size=False)
_c.xtream.password                 = ConfigPassword(default="")

_c.m3u                             = ConfigSubsection()
_c.m3u.name                        = ConfigText(default="",        fixed_size=False)
_c.m3u.url                         = ConfigText(default="http://", fixed_size=False)

_c.stalker                         = ConfigSubsection()
_c.stalker.name                    = ConfigText(default="",        fixed_size=False)
_c.stalker.portal                  = ConfigText(default="http://",            fixed_size=False)
_c.stalker.mac                     = ConfigText(default="00:1A:79:00:00:00", fixed_size=False)


def main(session, **kwargs):
    from .main import IPTVMain
    session.open(IPTVMain)


def Plugins(**kwargs):
    try:
        from .utils.resolver import start_resolver_server
        start_resolver_server()
    except Exception as e:
        print("[MyHybridIPTV] Failed to start resolver server: %s" % str(e))

    try:
        from .utils.webif import start_webif_server
        start_webif_server()
    except Exception as e:
        print("[MyHybridIPTV] Failed to start web config server: %s" % str(e))

    return [
        PluginDescriptor(
            name        = "Hybrid IPTV",
            description = "Xtream / M3U / Stalker IPTV Player",
            where       = PluginDescriptor.WHERE_PLUGINMENU,
            icon        = "icon.png",
            fnc         = main,
        )
    ]
