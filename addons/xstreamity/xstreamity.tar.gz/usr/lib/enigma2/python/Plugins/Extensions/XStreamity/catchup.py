#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import division

# Standard library imports
import base64
import codecs
import json
import os
import time
import tempfile
from datetime import datetime, timedelta
from itertools import cycle, islice

try:
    from http.client import HTTPConnection
    HTTPConnection.debuglevel = 0
except ImportError:
    from httplib import HTTPConnection
    HTTPConnection.debuglevel = 0

try:
    from urllib.parse import urlparse
except:
    from urlparse import urlparse

# Third-party imports
import requests
from PIL import Image
from requests.adapters import HTTPAdapter, Retry
from twisted.web.client import downloadPage

# Enigma2 components
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.Sources.List import List
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard

from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, eServiceReference

# Local application/library-specific imports
from . import _
from . import xstreamity_globals as glob
from .plugin import cfg, common_path, dir_tmp, downloads_json, pythonVer, screenwidth, skin_directory, hasConcurrent, hasMultiprocessing
from .xStaticText import StaticText


# HTTPS twisted client hack
try:
    from twisted.internet import ssl
    from twisted.internet._sslverify import ClientTLSOptions
    sslverify = True
except ImportError:
    sslverify = False

if sslverify:
    class SNIFactory(ssl.ClientContextFactory):
        def __init__(self, hostname=None):
            self.hostname = hostname

        def getContext(self):
            ctx = self._contextFactory(self.method)
            if self.hostname:
                ClientTLSOptions(self.hostname, ctx)
            return ctx

playlists_json = cfg.playlists_json.value

epgimporter = os.path.isdir("/usr/lib/enigma2/python/Plugins/Extensions/EPGImport")

hdr = {
    'User-Agent': str(cfg.useragent.value),
}


if pythonVer == 3:
    superscript_to_normal = str.maketrans(
        '⁰¹²³⁴⁵⁶⁷⁸⁹ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖʳˢᵗᵘᵛʷˣʸᶻ'
        'ᴬᴮᴰᴱᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᴿᵀᵁⱽᵂ⁺⁻⁼⁽⁾',
        '0123456789abcdefghijklmnoprstuvwxyz'
        'ABDEGHIJKLMNOPRTUVW+-=()'
    )


def normalize_superscripts(text):
    return text.translate(superscript_to_normal)


def clean_names(streams):
    for item in streams:
        for field in ("name", "category_name"):
            if field in item and isinstance(item[field], str):
                item[field] = normalize_superscripts(item[field])
    return streams


class XStreamity_Catchup_Categories(Screen):
    ALLOW_SUSPEND = True

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        if cfg.interface.value == "xstreamity":
            skin_path = os.path.join(skin_directory, cfg.interface.value, cfg.xstreamity_skin.value)

        if cfg.interface.value == "xklass":
            skin_path = os.path.join(skin_directory, cfg.interface.value, cfg.xklass_skin.value)

        skin = os.path.join(skin_path, "live_categories.xml")

        if os.path.exists("/var/lib/dpkg/status"):
            skin = os.path.join(skin_path, "DreamOS/live_categories.xml")

        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = f.read()

        glob.active_playlist.setdefault("data", {})

        self.setup_title = _("Catch Up Categories")
        self.main_title = _("Catch Up TV")
        self["main_title"] = StaticText(self.main_title)

        self.main_list = []  # displayed list
        self["main_list"] = List(self.main_list, enableWrapAround=True)

        self["x_title"] = StaticText()
        self["x_description"] = StaticText()

        self["picon"] = Pixmap()
        self["picon"].hide()

        self["progress"] = ProgressBar()
        self["progress"].hide()

        # skin epg variables
        self["epg_bg"] = Pixmap()
        self["epg_bg"].hide()

        self.epglist = []
        self["epg_list"] = List(self.epglist, enableWrapAround=True)

        # skin short epg variables
        self.epgshortlist = []
        self["epg_short_list"] = List(self.epgshortlist, enableWrapAround=True)
        self["epg_short_list"].onSelectionChanged.append(self.displayShortEPG)

        # pagination variables
        self["page"] = StaticText("")
        self["listposition"] = StaticText("")
        self.itemsperpage = 10

        self.searchString = ""
        self.filterresult = ""

        self.pin = False

        self.sortindex = 0
        self.sortText = _("Sort: A-Z")

        self.level = 1
        glob.current_level = 1

        self.selectedlist = self["main_list"]

        self.host = glob.active_playlist["playlist_info"]["host"]
        self.username = glob.active_playlist["playlist_info"]["username"]
        self.password = glob.active_playlist["playlist_info"]["password"]
        self.output = glob.active_playlist["playlist_info"]["output"]
        self.name = glob.active_playlist["playlist_info"]["name"]
        self.player_api = glob.active_playlist["playlist_info"]["player_api"]

        self.liveStreamsUrl = str(self.player_api) + "&action=get_live_streams"
        self.simpledatatable = str(self.player_api) + "&action=get_simple_data_table&stream_id="

        self.original_active_playlist = glob.active_playlist

        self.liveStreamsData = []

        next_url = str(self.player_api) + "&action=get_live_categories"

        self.firstrun = True

        # buttons / keys
        self["key_red"] = StaticText(_("Back"))
        self["key_green"] = StaticText(_("OK"))
        self["key_yellow"] = StaticText(self.sortText)
        self["key_blue"] = StaticText(_("Search"))
        self["key_epg"] = StaticText("")
        self["key_menu"] = StaticText("")

        # cache pixmaps (avoid LoadPixmap per row)
        self._px_more = LoadPixmap(os.path.join(common_path, "more.png"))

        # cache picon target size (screen size does not change at runtime)
        if screenwidth.width() == 2560:
            self.picon_size = (294, 176)
        elif screenwidth.width() > 1280:
            self.picon_size = (220, 130)
        else:
            self.picon_size = (147, 88)

        # cache adult keywords (used in parentalCheck)
        self.adult_keywords = set([
            "adult", "+18", "18+", "18 rated", "xxx", "sex", "porn",
            "voksen", "volwassen", "aikuinen", "Erwachsene", "dorosly",
            "взрослый", "vuxen", "£дорослий"
        ])

        menu_handler = self.showHiddenList

        if cfg.interface.value == "xklass":
            menu_handler = self.showPopupMenu

        self["category_actions"] = ActionMap(["XStreamityActions"], {
            "cancel": self.back,
            "red": self.back,
            "ok": self.parentalCheck,
            "green": self.parentalCheck,
            "yellow": self.sort,
            "blue": self.search,
            "left": self.pageUp,
            "right": self.pageDown,
            "up": self.goUp,
            "down": self.goDown,
            "channelUp": self.pageUp,
            "channelDown": self.pageDown,
            "0": self.reset,
            "menu": menu_handler,
        }, -2)

        self["channel_actions"] = ActionMap(["XStreamityActions"], {
            "cancel": self.back,
            "red": self.back,
            "ok": self.parentalCheck,
            "green": self.parentalCheck,
            "yellow": self.sort,
            "blue": self.search,
            "left": self.pageUp,
            "right": self.pageDown,
            "up": self.goUp,
            "down": self.goDown,
            "channelUp": self.pageUp,
            "channelDown": self.pageDown,
            "rec": self.downloadVideo,
            "5": self.downloadVideo,
            "0": self.reset,
            "menu": menu_handler,
        }, -2)

        self['menu_actions'] = ActionMap(["XStreamityActions"], {
            "cancel": self.closeChoiceBoxDialog,
            "red": self.closeChoiceBoxDialog,
            "menu": self.closeChoiceBoxDialog,
        }, -2)

        self["menu_actions"].setEnabled(False)
        self["channel_actions"].setEnabled(False)

        self["splash"] = Pixmap()
        # self["splash"].show()
        self["splash"].hide()

        self._picon_req_id = 0

        glob.nextlist = []
        glob.nextlist.append({"next_url": next_url, "index": 0, "level": self.level, "sort": self.sortText, "filter": ""})

        self.timerImage = eTimer()
        try:
            self.timerImage.callback.append(self.downloadImage)
        except:
            self.timerImage_conn = self.timerImage.timeout.connect(self.downloadImage)

        self.onFirstExecBegin.append(self.start)

        if cfg.interface.value == "xklass":
            try:
                self.closeChoiceBoxDialog()
            except Exception as e:
                print(e)

        self.onLayoutFinish.append(self.__layoutFinished)

    def start(self):
        if cfg.interface.value == "xklass":
            self.initGlobals()
            self.onShow.append(self.refresh)
            self.onHide.append(self.__onHide)

        else:
            self.createSetup()

    def __onHide(self):
        glob.current_level = self.level

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def _stopTimerImage(self):
        # Stop any scheduled timer fire
        try:
            if self.timerImage:
                self.timerImage.stop()
        except:
            pass

    def initGlobals(self):
        self.host = glob.active_playlist["playlist_info"]["host"]
        self.username = glob.active_playlist["playlist_info"]["username"]
        self.password = glob.active_playlist["playlist_info"]["password"]
        self.output = glob.active_playlist["playlist_info"]["output"]
        self.name = glob.active_playlist["playlist_info"]["name"]
        self.player_api = glob.active_playlist["playlist_info"]["player_api"]

        self.liveStreamsData = []

        self.p_live_categories_url = str(self.player_api) + "&action=get_live_categories"
        self.p_vod_categories_url = str(self.player_api) + "&action=get_vod_categories"
        self.p_series_categories_url = str(self.player_api) + "&action=get_series_categories"

        self.liveStreamsUrl = str(self.player_api) + "&action=get_live_streams"
        self.simpledatatable = str(self.player_api) + "&action=get_simple_data_table&stream_id="

        if self.level == 1:
            next_url = str(self.player_api) + "&action=get_live_categories"
            glob.nextlist = []
            glob.nextlist.append({"next_url": next_url, "index": 0, "level": self.level, "sort": self.sortText, "filter": ""})

    def playOriginalChannel(self):
        # self.stopVideo()

        try:
            if glob.currentPlayingServiceRefString:
                self.session.nav.playService(eServiceReference(glob.currentPlayingServiceRefString))
        except Exception as e:
            print(e)

    def refresh(self):
        self.level = glob.current_level

        if not glob.ChoiceBoxDialog:
            if self.level == 1:
                self["category_actions"].setEnabled(True)
                self["channel_actions"].setEnabled(False)
                self["menu_actions"].setEnabled(False)
            elif self.level == 2:
                self["category_actions"].setEnabled(False)
                self["channel_actions"].setEnabled(True)
                self["menu_actions"].setEnabled(False)

        sameplaylist = True

        if self.original_active_playlist["playlist_info"]["full_url"] != glob.active_playlist["playlist_info"]["full_url"]:
            if self.level == 1:
                self.reset()
            elif self.level == 2:
                self.back()
                self.reset()
            glob.active_playlist["data"]["live_streams"] = []
            sameplaylist = False

            self.initGlobals()

            if not glob.active_playlist["player_info"]["showcatchup"]:
                self.original_active_playlist = glob.active_playlist
                # self["splash"].hide()
                self.close()
            else:
                self.original_active_playlist = glob.active_playlist
                self.makeUrlList()

        if self.firstrun or not sameplaylist:
            self.firstrun = False
            self.resetButtons()
            self.createSetup()

        if sameplaylist:
            if self["main_list"].getCurrent():
                self["main_list"].setIndex(glob.nextlist[-1]["index"])
            self.selectionChanged()

    def makeUrlList(self):
        self.url_list = []

        player_api = str(glob.active_playlist["playlist_info"].get("player_api", ""))
        full_url = str(glob.active_playlist["playlist_info"].get("full_url", ""))
        domain = str(glob.active_playlist["playlist_info"].get("domain", ""))
        username = str(glob.active_playlist["playlist_info"].get("username", ""))
        password = str(glob.active_playlist["playlist_info"].get("password", ""))
        if "get.php" in full_url and domain and username and password:
            self.url_list.append([player_api, 0])
            self.url_list.append([self.p_live_categories_url, 1])
            self.url_list.append([self.p_vod_categories_url, 2])
            self.url_list.append([self.p_series_categories_url, 3])

        self.process_downloads()

    def download_url(self, url):
        import requests
        index = url[1]
        response = None

        retries = Retry(total=1, backoff_factor=1)
        adapter = HTTPAdapter(max_retries=retries)

        with requests.Session() as http:
            http.mount("http://", adapter)
            http.mount("https://", adapter)

            try:
                r = http.get(url[0], headers=hdr, timeout=(10, 20), verify=False)
                r.raise_for_status()

                # Get Content-Type from headers
                content_type = r.headers.get('Content-Type', '')

                # Handle JSON content directly
                if 'application/json' in content_type:
                    try:
                        response = r.json()
                    except ValueError as e:
                        print("Error decoding JSON:", e, url)
                        return index, None

                # Handle text/html content
                elif 'text/html' in content_type:
                    try:
                        # Attempt to parse the HTML body as JSON
                        response_text = r.text
                        response = json.loads(response_text)
                    except ValueError as e:
                        print("Error decoding JSON from HTML content:", e, url)
                        return index, None

                else:
                    print("Final response is non-JSON content:", r.url)
                    return index, None

            except requests.exceptions.RequestException as e:
                print("Request error:", e)
            except Exception as e:
                print("Unexpected error:", e)

        return index, response

    def process_downloads(self):
        threads = min(len(self.url_list), 10)
        results = []

        self.retry = 0
        glob.active_playlist["data"]["live_categories"] = []
        glob.active_playlist["data"]["vod_categories"] = []
        glob.active_playlist["data"]["series_categories"] = []

        if hasConcurrent or hasMultiprocessing:
            if hasConcurrent:
                try:
                    from concurrent.futures import ThreadPoolExecutor
                    with ThreadPoolExecutor(max_workers=threads) as executor:
                        results = list(executor.map(self.download_url, self.url_list))
                except Exception as e:
                    print("Concurrent execution error:", e)

            elif hasMultiprocessing:
                # print("********** trying multiprocessing threadpool *******")
                try:
                    from multiprocessing.pool import ThreadPool
                    pool = ThreadPool(threads)
                    results = pool.imap_unordered(self.download_url, self.url_list)
                    pool.close()
                    pool.join()
                except Exception as e:
                    print("Multiprocessing execution error:", e)

            for index, response in results:
                if response:
                    if index == 0:
                        if "user_info" in response:
                            glob.active_playlist.update(response)
                        else:
                            glob.active_playlist["user_info"] = {}
                    if index == 1:
                        glob.active_playlist["data"]["live_categories"] = response
                    if index == 2:
                        glob.active_playlist["data"]["vod_categories"] = response
                    if index == 3:
                        glob.active_playlist["data"]["series_categories"] = response

        else:
            # print("*** trying sequential ***")
            for url in self.url_list:
                result = self.download_url(url)
                index = result[0]
                response = result[1]
                if response:
                    if index == 0:
                        if "user_info" in response:
                            glob.active_playlist.update(response)
                        else:
                            glob.active_playlist["user_info"] = {}
                    if index == 1:
                        glob.active_playlist["data"]["live_categories"] = response
                    if index == 2:
                        glob.active_playlist["data"]["vod_categories"] = response
                    if index == 3:
                        glob.active_playlist["data"]["series_categories"] = response

        # glob.active_playlist["data"]["data_downloaded"] = True
        glob.active_playlist["data"]["live_streams"] = []
        self.writeJsonFile()

    def writeJsonFile(self):
        with open(playlists_json, "r") as f:
            playlists_all = json.load(f)

        playlists_all[glob.current_selection] = glob.active_playlist

        with open(playlists_json, "w") as f:
            json.dump(playlists_all, f, indent=4)

    def createSetup(self, data=None):
        self["x_title"].setText("")
        self["x_description"].setText("")

        if self.level == 1:
            self.getCategories()
        else:
            self.getLevel2()

        # self["splash"].hide()
        self.buildLists()

    def buildLists(self):
        if self.level == 1:
            self.buildList1()
        else:
            self.buildList2()

        self.resetButtons()
        self.selectionChanged()

    def getCategories(self):
        index = 0
        self.list1 = []
        self.prelist = []
        self.pre_list = []
        archivelist = []

        currentPlaylist = glob.active_playlist
        currentCategoryList = currentPlaylist.get("data", {}).get("live_categories", [])
        currentHidden = set(currentPlaylist.get("player_info", {}).get("catchuphidden", []))

        hidden = "0" in currentHidden

        if not self.liveStreamsData:
            self.liveStreamsData = self.downloadApiData(self.liveStreamsUrl) or []

        archivelist = [
            x for x in self.liveStreamsData
            if "tv_archive" in x and str(x["tv_archive"]) == "1"
            and "tv_archive_duration" in x
            and str(x["tv_archive_duration"]) != "0"
            and x["category_id"] not in currentHidden
        ]

        if archivelist:
            self.prelist.append(
                [index, _("ALL"), "0", hidden]
            )
            index += 1

        for item in currentCategoryList:
            for archive in archivelist:
                if "category_id" in item:
                    if item["category_id"] == archive["category_id"]:
                        self.list1.append(
                            [
                                index,
                                str(item["category_name"] if "category_name" in item else "No category"),
                                str(item["category_id"] if "category_id" in item else "999999"),
                                item["category_id"] in currentHidden
                            ]
                        )
                        index += 1
                        break

        glob.originalChannelList1 = self.list1[:]

    def getLevel2(self):
        response = self.downloadApiData(glob.nextlist[-1]["next_url"]) or []

        index = 0
        self.list2 = []

        if response:
            catchup_hidden_channels = set(glob.active_playlist["player_info"]["catchupchannelshidden"])

            for index, channel in enumerate(response):

                if channel.get("tv_archive") == 0 or channel.get("tv_archive") == "0" or channel.get("tv_archive_duration") == "0" or channel.get("tv_archive_duration") == 0:
                    continue

                name = str(channel.get("name", ""))

                if not name or name == "None":
                    continue

                if name and '\" ' in name:
                    parts = name.split('\" ', 1)
                    if len(parts) > 1:
                        name = parts[0]

                stream_id = channel.get("stream_id", "")
                if not stream_id:
                    continue

                hidden = str(stream_id) in catchup_hidden_channels

                stream_icon = str(channel.get("stream_icon", ""))

                if stream_icon and stream_icon.startswith("http"):
                    if stream_icon.startswith("https://vignette.wikia.nocookie.net/tvfanon6528"):
                        if "scale-to-width-down" not in stream_icon:
                            stream_icon = str(stream_icon) + "/revision/latest/scale-to-width-down/220"
                else:
                    stream_icon = ""

                epg_channel_id = str(channel.get("epg_channel_id", ""))
                if epg_channel_id and "&" in epg_channel_id:
                    epg_channel_id = epg_channel_id.replace("&", "&amp;")

                added = str(channel.get("added", "0"))

                next_url = "{}/live/{}/{}/{}.{}".format(self.host, self.username, self.password, stream_id, self.output)

                self.list2.append([index, str(name), str(stream_id), str(stream_icon), str(epg_channel_id), str(added), str(next_url), "", "", "", "", "", "", hidden])

        glob.originalChannelList2 = self.list2[:]

    def downloadApiData(self, url):
        retries = Retry(total=1, backoff_factor=1)
        adapter = HTTPAdapter(max_retries=retries)

        with requests.Session() as http:
            http.mount("http://", adapter)
            http.mount("https://", adapter)

            try:
                response = http.get(url, headers=hdr, timeout=(10, 60), verify=False)
                response.raise_for_status()

                if response.status_code == requests.codes.ok:
                    try:
                        if pythonVer == 3:
                            return clean_names(response.json())
                        else:
                            return response.json()
                    except ValueError:
                        print("JSON decoding failed.")
                        return None
            except Exception as e:
                print("Error occurred during API data download:", e)
                self.session.open(MessageBox, _("Server error or invalid link."), MessageBox.TYPE_ERROR, timeout=3)
                return None

    def buildList1(self):
        self["picon"].hide()

        if self["key_blue"].getText() != _("Reset Search"):
            self.pre_list = [buildCategoryList(x[0], x[1], x[2], x[3], self._px_more) for x in self.prelist if not x[3]]
        else:
            self.pre_list = []

        self.main_list = [buildCategoryList(x[0], x[1], x[2], x[3], self._px_more) for x in self.list1 if not x[3]]

        self["main_list"].setList(self.pre_list + self.main_list)

        if self["main_list"].getCurrent() and glob.nextlist[-1]["index"] != 0:
            self["main_list"].setIndex(glob.nextlist[-1]["index"])

    def buildList2(self):
        self.main_list = [buildCatchupStreamList(x[0], x[1], x[2], x[3], x[4], x[5], x[6], x[13], self._px_more) for x in self.list2 if not x[13]]
        self["main_list"].setList(self.main_list)
        self["picon"].show()

        if self["main_list"].getCurrent() and glob.nextlist[-1]["index"] != 0:
            self["main_list"].setIndex(glob.nextlist[-1]["index"])

    def resetButtons(self):
        if glob.nextlist[-1]["filter"]:
            self["key_yellow"].setText(self.sortText)
            self["key_blue"].setText(_("Reset Search"))
            self["key_menu"].setText("")
        else:
            if self.selectedlist == self["epg_short_list"]:
                self["key_blue"].setText("")
                self["key_yellow"].setText(_("Reverse"))
                self["key_menu"].setText("+/-")
            else:
                if not glob.nextlist[-1]["sort"]:
                    self.sortText = _("Sort: A-Z")
                    glob.nextlist[-1]["sort"] = self.sortText

                self["key_blue"].setText(_("Search"))
                self["key_yellow"].setText(_(glob.nextlist[-1]["sort"]))
                self["key_menu"].setText("+/-")

    def stopStream(self):
        current_playing_ref = glob.currentPlayingServiceRefString
        new_playing_ref = glob.newPlayingServiceRefString

        if current_playing_ref and new_playing_ref and current_playing_ref != new_playing_ref:
            currently_playing_service = self.session.nav.getCurrentlyPlayingServiceReference()
            if currently_playing_service:
                self.session.nav.stopService()
            self.session.nav.playService(eServiceReference(current_playing_ref))
            glob.newPlayingServiceRefString = current_playing_ref

    def selectionChanged(self):
        current_item = self["main_list"].getCurrent()
        if current_item:
            channel_title = current_item[0]
            current_index = self["main_list"].getIndex()
            glob.currentchannellistindex = current_index
            glob.nextlist[-1]["index"] = current_index

            position = current_index + 1
            position_all = len(self.pre_list) + len(self.main_list) if self.level == 1 else len(self.main_list)
            page = (position - 1) // self.itemsperpage + 1
            page_all = (position_all + self.itemsperpage - 1) // self.itemsperpage

            self["page"].setText(_("Page: ") + "{}/{}".format(page, page_all))
            self["listposition"].setText("{}/{}".format(position, position_all))
            self["main_title"].setText("{}: {}".format(self.main_title, channel_title))

            self.loadBlankImage()

            if self.level == 2:
                if cfg.channelpicons.value:
                    self._stopTimerImage()
                    self.timerImage.start(250, True)
        else:
            position = 0
            position_all = 0
            page = 0
            page_all = 0

            self["page"].setText(_("Page: ") + "{}/{}".format(page, page_all))
            self["listposition"].setText("{}/{}".format(position, position_all))
            self["key_yellow"].setText("")
            self["key_blue"].setText("")

    def downloadImage(self):
        if not self["main_list"].getCurrent():
            self.loadDefaultImage()
            return

        # Clear immediately so previous image doesn't remain if new fails
        self.loadBlankImage()

        # bump request id so stale callbacks can be ignored (zap protection)
        try:
            self._picon_req_id += 1
        except:
            self._picon_req_id = 1

        req_id = self._picon_req_id

        desc_image = ""
        try:
            desc_image = self["main_list"].getCurrent()[5]
        except:
            desc_image = ""

        if not desc_image or desc_image.lower() == "n/a":
            self.loadDefaultImage()
            return

        if not desc_image.startswith(("http://", "https://")):
            self.loadDefaultImage()
            return

        fd = None
        temp = None

        try:
            fd, temp = tempfile.mkstemp(prefix="xst_live_picon_", suffix=".png", dir=dir_tmp)
            try:
                os.close(fd)
            except:
                pass

            parsed = urlparse(desc_image)
            domain = parsed.hostname
            scheme = parsed.scheme

            url = desc_image

            if pythonVer == 3:
                try:
                    url = desc_image.encode()
                except:
                    url = desc_image

            def _cleanup_temp():
                try:
                    if temp and os.path.exists(temp):
                        os.remove(temp)
                except:
                    pass

            def _ok(_data=None):
                # ignore stale callback if user moved again
                if getattr(self, "_picon_req_id", 0) != req_id:
                    _cleanup_temp()
                    return

                self.resizeImage(temp, req_id=req_id)

            def _err(_failure=None):
                if getattr(self, "_picon_req_id", 0) != req_id:
                    _cleanup_temp()
                    return

                _cleanup_temp()
                self.loadDefaultImage()

            if scheme == "https" and sslverify:
                sniFactory = SNIFactory(domain)
                d = downloadPage(url, temp, sniFactory, timeout=2)
            else:
                d = downloadPage(url, temp, timeout=2)

            d.addCallback(_ok)
            d.addErrback(_err)

        except Exception:
            try:
                if fd:
                    os.close(fd)
            except:
                pass

            try:
                if temp and os.path.exists(temp):
                    os.remove(temp)
            except:
                pass

            self.loadDefaultImage()

    def loadBlankImage(self, data=None):
        if self["picon"].instance:
            self["picon"].instance.setPixmapFromFile(os.path.join(common_path, "picon_blank.png"))

    def loadDefaultImage(self, data=None):
        if self["picon"].instance:
            self["picon"].instance.setPixmapFromFile(os.path.join(common_path, "picon.png"))

    def resizeImage(self, original, req_id=None, data=None):
        if req_id is not None and getattr(self, "_picon_req_id", 0) != req_id:
            try:
                if original and os.path.exists(original):
                    os.remove(original)
            except:
                pass
            return

        size = self.picon_size
        if os.path.exists(original):
            im = None
            try:
                im = Image.open(original)
                if im.mode != "RGBA":
                    im = im.convert("RGBA")

                if im.size[0] == 0 or im.size[1] == 0:
                    raise ValueError("Image has zero dimension")
                ratio = min(size[0] / float(im.size[0]), size[1] / float(im.size[1]))
                new_size = (int(im.size[0] * ratio), int(im.size[1] * ratio))
                try:
                    im = im.resize(new_size, Image.Resampling.LANCZOS)
                except:
                    im = im.resize(new_size, Image.ANTIALIAS)

                bg = Image.new("RGBA", size, (255, 255, 255, 0))
                left = (size[0] - im.size[0]) // 2
                top = (size[1] - im.size[1]) // 2
                bg.paste(im, (left, top), mask=im)
                bg.save(original, "PNG")

                if self["picon"].instance:
                    self["picon"].instance.setPixmapFromFile(original)

            except Exception as e:
                print("Error resizing image:", e)
                self.loadDefaultImage()
            finally:
                if im is not None:
                    try:
                        im.close()
                    except:
                        pass

            try:
                os.remove(original)
            except:
                pass
        else:
            self.loadDefaultImage()

    def goUp(self):
        instance = self.selectedlist.master.master.instance
        instance.moveSelection(instance.moveUp)
        self.selectionChanged()

    def goDown(self):
        instance = self.selectedlist.master.master.instance
        instance.moveSelection(instance.moveDown)
        self.selectionChanged()

    def pageUp(self):
        instance = self.selectedlist.master.master.instance
        instance.moveSelection(instance.pageUp)
        self.selectionChanged()

    def pageDown(self):
        instance = self.selectedlist.master.master.instance
        instance.moveSelection(instance.pageDown)
        self.selectionChanged()

    # button 0
    def reset(self):
        self.selectedlist.setIndex(0)
        self.selectionChanged()

    def sort(self):
        current_sort = self["key_yellow"].getText()
        if not current_sort:
            return

        if glob.nextlist[-1]["filter"]:
            activelist = glob.originalChannelList1[:] if self.level == 1 else glob.originalChannelList2[:]
            activelist = [channel for channel in activelist if str(self.filterresult).lower() in str(channel[1]).lower()]
        else:
            activelist = self.list1 if self.level == 1 else self.list2

        sortlist = [_("Sort: A-Z"), _("Sort: Z-A")]
        if self.level == 1:
            sortlist.append(_("Sort: Original"))
        else:
            sortlist.extend([_("Sort: Added"), _("Sort: Original")])

        for index, item in enumerate(sortlist):
            if str(item) == str(self.sortText):
                self.sortindex = index
                break

        if self["main_list"].getCurrent():
            self["main_list"].setIndex(0)

        if current_sort == _("Sort: A-Z"):
            activelist.sort(key=lambda x: x[1].lower(), reverse=False)

        elif current_sort == _("Sort: Z-A"):
            activelist.sort(key=lambda x: x[1].lower(), reverse=True)

        elif current_sort == _("Sort: Added"):
            if self.level != 1:
                activelist.sort(key=lambda x: x[1].lower(), reverse=False)
                activelist.sort(key=lambda x: (x[5] or ""), reverse=True)

        elif current_sort == _("Sort: Original"):
            activelist.sort(key=lambda x: x[0], reverse=False)

        next_sort_type = next(islice(cycle(sortlist), self.sortindex + 1, None))
        self.sortText = str(next_sort_type)

        self["key_yellow"].setText(self.sortText)
        glob.nextlist[-1]["sort"] = self["key_yellow"].getText()

        if self.level == 1:
            self.list1 = activelist
        else:
            self.list2 = activelist

        self.buildLists()

    def search(self, result=None):
        if not self["key_blue"].getText():
            return

        current_filter = self["key_blue"].getText()

        if current_filter == _("Reset Search"):
            self.resetSearch()
        else:
            self.session.openWithCallback(self.filterChannels, VirtualKeyBoard, title=_("Filter this category..."), text=self.searchString)

    def filterChannels(self, result=None):
        activelist = []

        if result:
            self.filterresult = result
            glob.nextlist[-1]["filter"] = self.filterresult
            self.searchString = result
            activelist = self.list1 if self.level == 1 else self.list2
            activelist = [channel for channel in activelist if str(result).lower() in str(channel[1]).lower()]

            if not activelist:
                self.searchString = ""
                self.session.openWithCallback(self.search, MessageBox, _("No results found."), type=MessageBox.TYPE_ERROR, timeout=5)
            else:
                self._pre_search_sort = self["key_yellow"].getText()
                activelist.sort(key=lambda x: x[1].lower(), reverse=False)
                self.sortText = _("Sort: Z-A")
                glob.nextlist[-1]["sort"] = self.sortText

                if self.level == 1:
                    self.list1 = activelist
                else:
                    self.list2 = activelist

                self["key_blue"].setText(_("Reset Search"))
                self["key_yellow"].setText(_("Sort: A-Z"))

                self.buildLists()

    def resetSearch(self):
        self["key_blue"].setText(_("Search"))

        if self.level == 1:
            self.list1 = glob.originalChannelList1[:]
        else:
            self.list2 = glob.originalChannelList2[:]

        self.filterresult = ""
        glob.nextlist[-1]["filter"] = self.filterresult

        self.sortText = getattr(self, "_pre_search_sort", self.sortText)
        glob.nextlist[-1]["sort"] = self.sortText
        self["key_yellow"].setText(self.sortText)

        self.buildLists()

    def pinEntered(self, result=None):
        if not result:
            self.pin = False
            self.session.open(MessageBox, _("Incorrect pin code."), type=MessageBox.TYPE_ERROR, timeout=5)

        if self.pin is True:
            if pythonVer == 2:
                glob.pintime = int(time.mktime(datetime.now().timetuple()))
            else:
                glob.pintime = int(datetime.timestamp(datetime.now()))

            self.next()
        else:
            return

    def parentalCheck(self):
        # print("*** parentalcheck ***")
        self.pin = True
        nowtime = int(time.mktime(datetime.now().timetuple())) if pythonVer == 2 else int(datetime.timestamp(datetime.now()))

        if self.level == 1 and self["main_list"].getCurrent():

            current_title = str(self["main_list"].getCurrent()[0])

            if current_title == "ALL" or current_title == _("ALL"):
                glob.adultChannel = True

            elif "sport" in current_title.lower():
                glob.adultChannel = False

            elif any(keyword in current_title.lower() for keyword in self.adult_keywords):
                glob.adultChannel = True

            else:
                glob.adultChannel = False

            if cfg.adult.value and nowtime - int(glob.pintime) > 900 and glob.adultChannel:
                from Screens.InputBox import PinInput
                self.session.openWithCallback(
                    self.pinEntered,
                    PinInput,
                    pinList=[cfg.adultpin.value],
                    triesEntry=cfg.retries.adultpin,
                    title=_("Please enter the parental control pin code"),
                    windowTitle=_("Enter pin code")
                )
            else:
                self.next()
        else:
            self.next()

    def next(self):
        if self["main_list"].getCurrent():
            current_index = self["main_list"].getIndex()
            glob.nextlist[-1]["index"] = current_index
            glob.currentchannellist = self.main_list[:]
            glob.currentchannellistindex = current_index

            if self.level == 1:
                if self.list1:
                    category_id = self["main_list"].getCurrent()[3]
                    next_url = "{0}&action=get_live_streams&category_id={1}".format(self.player_api, category_id) if category_id != "0" else "{0}&action=get_live_streams".format(self.player_api)
                    self.level += 1
                    self["main_list"].setIndex(0)
                    self["category_actions"].setEnabled(False)
                    self["channel_actions"].setEnabled(True)
                    self["menu_actions"].setEnabled(False)

                    self["key_yellow"].setText(_("Sort: A-Z"))
                    glob.nextlist.append({"next_url": next_url, "index": 0, "level": self.level, "sort": self["key_yellow"].getText(), "filter": ""})
                    self.createSetup()
                else:
                    self.createSetup()
            else:
                if self.list2:
                    if self.selectedlist == self["main_list"]:
                        self.catchupEPG()
                        self.resetButtons()
                    else:
                        self.playCatchup()
                else:
                    self.createSetup()

    def applySavedSort(self):
        """Re-apply the sort currently stored in glob.nextlist without advancing to the next sort type."""
        current_sort = glob.nextlist[-1].get("sort", "")
        if not current_sort or current_sort == _("Sort: Original"):
            return

        activelist = self.list1 if self.level == 1 else self.list2

        if current_sort == _("Sort: A-Z"):
            activelist.sort(key=lambda x: x[1].lower(), reverse=False)
        elif current_sort == _("Sort: Z-A"):
            activelist.sort(key=lambda x: x[1].lower(), reverse=True)
        elif current_sort == _("Sort: Added") and self.level != 1:
            activelist.sort(key=lambda x: x[1].lower(), reverse=False)
            activelist.sort(key=lambda x: (x[5] or ""), reverse=True)

        if self.level == 1:
            self.list1 = activelist
        else:
            self.list2 = activelist

        self.sortText = current_sort
        self["key_yellow"].setText(self.sortText)
        self.buildLists()

    def setIndex(self, data=None):
        if self["main_list"].getCurrent():
            if cfg.interface.value == "xstreamity":
                self.createSetup()
                self.applySavedSort()
            self["main_list"].setIndex(glob.currentchannellistindex)

    def back(self, data=None):
        self._stopTimerImage()

        if cfg.interface.value == "xklass":
            try:
                self.closeChoiceBoxDialog()
            except Exception as e:
                print(e)

        self.hideEPG()

        if self.selectedlist == self["epg_short_list"]:
            epg_instance = self["epg_short_list"].master.master.instance
            epg_instance.setSelectionEnable(0)
            self["epg_short_list"].setList([])
            main_instance = self["main_list"].master.master.instance
            main_instance.setSelectionEnable(1)
            self.selectedlist = self["main_list"]
            self.resetButtons()
        else:
            if glob.nextlist:
                glob.nextlist.pop()

            if not glob.nextlist:
                self.stopStream()
                # self["splash"].hide()
                self.close()
            else:
                self["x_title"].setText("")
                self["x_description"].setText("")
                self.stopStream()
                self.level -= 1

                self["category_actions"].setEnabled(True)
                self["channel_actions"].setEnabled(False)
                self["menu_actions"].setEnabled(False)

                self.createSetup()

    def showHiddenList(self):
        if self["key_menu"].getText():
            current_list = self.prelist + self.list1 if self.level == 1 else self.list2
            if current_list and self["main_list"].getCurrent():
                from . import hidden
                self.session.openWithCallback(self.createSetup, hidden.XStreamity_HiddenCategories, "catchup", current_list, self.level)

    def hideEPG(self):
        self["picon"].hide()
        self["epg_bg"].hide()
        self["x_title"].setText("")
        self["x_description"].setText("")
        self["progress"].hide()

    def showEPG(self):
        self["picon"].show()
        self["epg_bg"].show()

    def displayShortEPG(self):
        current_item = self["epg_short_list"].getCurrent()

        if current_item:
            title = str(current_item[0])
            description = str(current_item[3])
            timeall = str(current_item[2])

            self["x_title"].setText("{} {}".format(timeall, title))
            self["x_description"].setText(description)
            self.showEPG()

    def downloadVideo(self):
        if self.selectedlist != self["epg_short_list"]:
            return

        if not self["main_list"].getCurrent():
            return

        if not self["epg_short_list"].getCurrent():
            return

        main_current = self["main_list"].getCurrent()
        epg_current = self["epg_short_list"].getCurrent()

        next_url = main_current[3] if len(main_current) > 3 else ""
        if not next_url:
            return

        stream = next_url.rpartition("/")[-1]
        description = str(epg_current[3]) if len(epg_current) > 3 else ""
        date = str(epg_current[4]) if len(epg_current) > 4 else ""
        timestamp = ""

        if ":" in date:
            try:
                parts = date.split(":")
                if len(parts) == 2:
                    date_part = parts[0]
                    time_part = parts[1].replace("-", ":")
                    cleaned = date_part + " " + time_part
                    dt = datetime.strptime(cleaned, "%Y-%m-%d %H:%M")
                    timestamp = int(time.mktime(dt.timetuple()))
            except Exception as e:
                print("Error parsing timestamp:", e)
                timestamp = ""

        try:
            date_all = str(epg_current[1]).strip() if len(epg_current) > 1 else ""
            time_all = str(epg_current[2]).strip() if len(epg_current) > 2 else ""
            time_start = time_all.partition(" - ")[0].strip()
            current_year = int(datetime.now().year)
            date2 = str(datetime.strptime(str(current_year) + str(date_all) + str(time_start), "%Y%a %d/%m%H:%M")).replace("-", "").replace(":", "")[:-2]
        except Exception as e:
            print("Error parsing date2:", e)
            date2 = ""

        duration = str(epg_current[5]) if len(epg_current) > 5 else "0"
        otitle = str(epg_current[0]) if len(epg_current) > 0 else ""
        channel = str(main_current[0]) if len(main_current) > 0 else ""
        title = str(date2) + " - " + str(channel) + " - " + str(otitle)
        playurl = "%s/timeshift/%s/%s/%s/%s/%s" % (self.host, self.username, self.password, duration, date, stream)

        downloads_all = []
        if os.path.isfile(downloads_json):
            try:
                with open(downloads_json, "r") as f:
                    downloads_all = json.load(f)
                if not isinstance(downloads_all, list):
                    downloads_all = []
            except Exception as e:
                print("Error loading downloads JSON:", e)
                downloads_all = []

        exists = any(video[2] == playurl for video in downloads_all if len(video) > 2)

        if not exists:
            downloads_all.append([_("Catch-up"), title, playurl, "Not Started", 0, 0, description, duration, channel, timestamp])
            try:
                with open(downloads_json, "w") as f:
                    json.dump(downloads_all, f, indent=4)
            except Exception as e:
                print("Error saving downloads JSON:", e)
                self.session.open(MessageBox, _("Failed to add to download manager"), MessageBox.TYPE_ERROR, timeout=5)
                return

            self.session.openWithCallback(
                self.opendownloader,
                MessageBox,
                _(title) + "\n\n" + _("Added to download manager") + "\n\n" +
                _("Note recording acts as an open connection.") + "\n" +
                _("Do not record and play streams at the same time.") + "\n\n" +
                _("Open download manager?")
            )
        else:
            self.session.open(MessageBox, _(title) + "\n\n" + _("Already added to download manager"), MessageBox.TYPE_ERROR, timeout=5)

    def opendownloader(self, answer=None):
        if not answer:
            return
        else:
            from . import downloadmanager
            self.session.openWithCallback(self.setIndex, downloadmanager.XStreamity_DownloadManager)

    def failed(self, data=None):
        if data:
            print(data)
        return

    def playCatchup(self):
        current_main_list_item = self["main_list"].getCurrent()
        if current_main_list_item:
            next_url = current_main_list_item[3]
            stream = next_url.rpartition("/")[-1]

            epg_short_list_current_item = self["epg_short_list"].getCurrent()
            date = str(epg_short_list_current_item[4])
            duration = str(epg_short_list_current_item[5])

            playurl = "{}/timeshift/{}/{}/{}/{}/{}".format(self.host, self.username, self.password, duration, date, stream)
            if next_url and next_url != "None" and "/live/" in next_url:
                from . import catchupplayer
                streamtype = glob.active_playlist["player_info"]["vodtype"]
                glob.catchupdata = [str(epg_short_list_current_item[0]), str(epg_short_list_current_item[3])]
                self.session.openWithCallback(self.setIndex, catchupplayer.XStreamity_CatchupPlayer, str(playurl), str(streamtype))
            else:
                self.session.open(MessageBox, _("Catchup error. No data for this slot"), MessageBox.TYPE_WARNING, timeout=5)

    def checkRedirect(self, url):
        retries = Retry(total=1, backoff_factor=1)
        adapter = HTTPAdapter(max_retries=retries)

        with requests.Session() as http:
            http.mount("http://", adapter)
            http.mount("https://", adapter)

            try:
                response = http.get(url, headers=hdr, timeout=30, verify=False, stream=True)
                url = response.url
                return str(url)
            except Exception as e:
                print(e)
                return str(url)

    def parse_datetime(self, datetime_str):
        time_formats = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H-%M-%S", "%Y-%m-%d-%H:%M:%S", "%Y- %m-%d %H:%M:%S"]

        for time_format in time_formats:
            try:
                return datetime.strptime(datetime_str, time_format)
            except ValueError:
                pass
        return ""  # Return None if none of the formats match

    def catchupEPG(self):
        current_item = self["main_list"].getCurrent()
        if not current_item:
            return

        next_url = current_item[3]
        if not next_url or next_url == "None" or "/live/" not in next_url:
            return

        stream_id = next_url.rpartition("/")[-1].partition(".")[0]

        url = "{}{}".format(self.simpledatatable, stream_id)
        url = self.checkRedirect(url)

        retries = Retry(total=1, backoff_factor=1)
        adapter = HTTPAdapter(max_retries=retries)

        with requests.Session() as http:
            http.mount("http://", adapter)
            http.mount("https://", adapter)

            try:
                response = http.get(url, headers=hdr, timeout=(10, 20), verify=False)
                response.raise_for_status()
                if response.status_code == requests.codes.ok:
                    shortEPGJson = response.json()

            except Exception as e:
                print("Error fetching catchup EPG:", e)
                return

        if "epg_listings" not in shortEPGJson or not shortEPGJson["epg_listings"]:
            self.session.open(MessageBox, _("Catchup currently not available. Missing EPG data"), type=MessageBox.TYPE_INFO, timeout=2)
            return

        index = 0
        self.epgshortlist = []
        duplicatecheck = set()

        shift = int(glob.active_playlist["player_info"].get("serveroffset", 0))
        catchupstart = int(cfg.catchupstart.value)
        catchupend = int(cfg.catchupend.value)

        for listing in shortEPGJson["epg_listings"]:
            if "has_archive" in listing and listing["has_archive"] == 1 or ("now_playing" in listing and listing["now_playing"] == 1):
                title = base64.b64decode(listing.get("title", "")).decode("utf-8")
                description = base64.b64decode(listing.get("description", "")).decode("utf-8")

                start = listing.get("start", "")
                end = listing.get("end", "")
                stop = listing.get("stop", "")

                if start:
                    start_datetime_original = self.parse_datetime(start)
                    if start_datetime_original:
                        start_datetime = start_datetime_original + timedelta(hours=shift)
                        start_datetime_original_margin = start_datetime_original - timedelta(minutes=catchupstart)
                    else:
                        print("Error parsing start datetime")
                        continue

                if end:
                    end_datetime = self.parse_datetime(end)
                    if end_datetime:
                        end_datetime += timedelta(hours=shift)
                    else:
                        print("Error parsing end datetime")
                        continue
                elif stop:
                    stop_datetime = self.parse_datetime(stop)
                    if stop_datetime:
                        end_datetime = stop_datetime + timedelta(hours=shift)
                    else:
                        print("Error parsing stop datetime")
                        continue
                else:
                    print("Error: Missing end or stop time")
                    continue

                if start_datetime and end_datetime:

                    start_datetime_margin = start_datetime - timedelta(minutes=catchupstart)
                    end_datetime_margin = end_datetime + timedelta(minutes=catchupend)

                    epg_date_all = start_datetime.strftime("%a %d/%m")

                    epg_time_all = "{} - {}".format(start_datetime.strftime("%H:%M"), end_datetime.strftime("%H:%M"))

                    epg_duration = int((end_datetime_margin - start_datetime_margin).total_seconds() / 60.0)

                    url_datestring = start_datetime_original_margin.strftime("%Y-%m-%d:%H-%M")

                    # url_datestring = start_datetime_margin.strftime("%Y-%m-%d:%H-%M")

                    if (epg_date_all, epg_time_all) not in duplicatecheck:
                        duplicatecheck.add((epg_date_all, epg_time_all))
                        self.epgshortlist.append(buildCatchupEPGListEntry(str(title), epg_date_all, epg_time_all, str(description), url_datestring, str(epg_duration), index))

                        index += 1

        self.epgshortlist.reverse()
        self["epg_short_list"].setList(self.epgshortlist)

        if self["epg_short_list"].getCurrent():
            glob.catchupdata = [str(self["epg_short_list"].getCurrent()[0]), str(self["epg_short_list"].getCurrent()[3])]
        instance = self["epg_short_list"].master.master.instance
        instance.setSelectionEnable(1)

        self.selectedlist = self["epg_short_list"]
        self.displayShortEPG()

    def reverse(self):
        self.epgshortlist.reverse()
        self["epg_short_list"].setList(self.epgshortlist)

    def showChoiceBoxDialog(self, Answer=None):
        self["channel_actions"].setEnabled(False)
        self["category_actions"].setEnabled(False)
        glob.ChoiceBoxDialog['dialogactions'].execBegin()
        glob.ChoiceBoxDialog.show()
        self["menu_actions"].setEnabled(True)

    def closeChoiceBoxDialog(self, Answer=None):
        if glob.ChoiceBoxDialog:
            self["menu_actions"].setEnabled(False)
            glob.ChoiceBoxDialog.hide()
            glob.ChoiceBoxDialog['dialogactions'].execEnd()
            self.session.deleteDialog(glob.ChoiceBoxDialog)

            if self.level == 1:
                self["category_actions"].setEnabled(True)
                self["channel_actions"].setEnabled(False)

            if self.level == 2:
                self["category_actions"].setEnabled(False)
                self["channel_actions"].setEnabled(True)

    def showPopupMenu(self):
        if self.selectedlist == self["epg_short_list"]:
            self.back()
        from . import channelmenu
        glob.current_list = self.prelist + self.list1 if self.level == 1 else self.list2
        glob.current_level = self.level
        glob.current_screen = "catchup"

        glob.ChoiceBoxDialog = self.session.instantiateDialog(channelmenu.XStreamity_ChannelMenu, "catchup")
        self.showChoiceBoxDialog()


def buildCategoryList(index, title, category_id, hidden, px_more=None):
    return (title, px_more, index, category_id, hidden)


def buildCatchupStreamList(index, title, stream_id, stream_icon, epg_channel_id, added, next_url, hidden, px_more=None):
    return (title, px_more, index, next_url, stream_id, stream_icon, epg_channel_id, added, hidden)


def buildCatchupEPGListEntry(title, date_all, time_all, description, start, duration, index):
    return (title, date_all, time_all, description, start, duration, index)
