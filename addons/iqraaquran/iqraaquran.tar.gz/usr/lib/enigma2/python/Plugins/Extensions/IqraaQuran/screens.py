# -*- coding: utf-8 -*-
"""Standalone UI screens for IqraaQuran.

This module intentionally avoids importing plugin.py to prevent circular imports
on DreamOS/Python 2.7 and open-source Python 3 images.
"""
import os
import re
import sys
import json
from datetime import datetime

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox as _original_MessageBox
class MessageBox(_original_MessageBox):
    def __init__(self, session, text, type=_original_MessageBox.TYPE_YESNO, *args, **kwargs):
        safe_text = to_enigma_string(text)
        _original_MessageBox.__init__(self, session, safe_text, type, *args, **kwargs)
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.ProgressBar import ProgressBar
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigYesNo, ConfigSelection, getConfigListEntry
from Components.Sources.StaticText import StaticText
from Tools import Notifications
from enigma import loadPNG, gPixmapPtr, ePoint
from enigma import eTimer as _original_eTimer

# ─────────────────────────────────────────────────────────────────────────────
# SafeETimer: غلاف آمن لـ eTimer يدعم كلاً من .callback.append()
# و .timeout.connect() ليكون متوافقاً مع جميع صور Enigma2
# ─────────────────────────────────────────────────────────────────────────────
class SafeETimer(object):
    def __init__(self, *args, **kwargs):
        self._timer = _original_eTimer(*args, **kwargs)
        self._conns = []
    def __getattr__(self, name):
        return getattr(self._timer, name)
    def __setattr__(self, name, value):
        if name in ("_timer", "_conns"):
            super(SafeETimer, self).__setattr__(name, value)
        else:
            setattr(self._timer, name, value)
    @property
    def callback(self):
        class CallbackList(object):
            def __init__(self, outer):
                self.outer = outer
            def append(self, fn):
                try:
                    self.outer._timer.callback.append(fn)
                    return
                except AttributeError:
                    pass
                try:
                    conn = self.outer._timer.timeout.connect(fn)
                    self.outer._conns.append(conn)
                    return
                except AttributeError:
                    pass
                try:
                    self.outer._timer.timeout.get().append(fn)
                    return
                except AttributeError:
                    pass
        return CallbackList(self)
    @property
    def timeout(self):
        class TimeoutProxy(object):
            def __init__(self, timer):
                self.timer = timer
            def __getattr__(self, name):
                return getattr(self.timer._timer.timeout, name)
            def connect(self, fn):
                try:
                    conn = self.timer._timer.timeout.connect(fn)
                    self.timer._conns.append(conn)
                    return conn
                except AttributeError:
                    pass
                try:
                    self.timer._timer.timeout.get().append(fn)
                    return
                except AttributeError:
                    pass
                try:
                    self.timer._timer.callback.append(fn)
                    return
                except AttributeError:
                    pass
            @property
            def get(self):
                class Getter(object):
                    def __init__(self, outer):
                        self.outer = outer
                    def append(self, fn):
                        self.outer.connect(fn)
                return lambda: Getter(self)
        return TimeoutProxy(self)

# استبدال eTimer العالمي بالغلاف الآمن في هذا الملف
eTimer = SafeETimer

# ─────────────────────────────────────────────────────────────────────────────
# كشف إصدار Python - PY2 لبايثون 2، PY3 لبايثون 3
# ─────────────────────────────────────────────────────────────────────────────
PY2 = sys.version_info[0] == 2
PY3 = not PY2

# ─────────────────────────────────────────────────────────────────────────────
# كشف نوع الصورة: DreamOS أو open-source
# ─────────────────────────────────────────────────────────────────────────────
isDreamOS = False
try:
    from enigma import eEnv
    isDreamOS = True
except ImportError:
    if os.path.exists('/usr/bin/apt-get') and not os.path.exists('/usr/bin/opkg'):
        isDreamOS = True

def detect_openatv_image():
    # فحص ملفات النظام للتعرف على صورة OpenATV
    for path in ("/etc/issue", "/etc/image-version", "/etc/hostname"):
        try:
            if os.path.exists(path):
                with open(path, "rb") as f:
                    if b"openatv" in f.read().lower():
                        return True
        except Exception:
            pass
    return False

# ─────────────────────────────────────────────────────────────────────────────
# متغيرات كشف البيئة المجمَّعة
# ─────────────────────────────────────────────────────────────────────────────
IS_DREAMOS_PY2 = PY2 and isDreamOS
IS_OPEN_SOURCE_PY3 = PY3
IS_OPENATV_PY3 = PY3 and detect_openatv_image()

# ─────────────────────────────────────────────────────────────────────────────
# استيراد PAGE_VERSE_MAP من generate_index - الاستيراد النسبي أولاً ثم المطلق
# ─────────────────────────────────────────────────────────────────────────────
try:
    try:
        from .generate_index import PAGE_VERSE_MAP
    except Exception:
        from generate_index import PAGE_VERSE_MAP
except Exception:
    PAGE_VERSE_MAP = []

Plugin_version = "1.3"
Plugin_name = "IQRAA Quran"
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/IqraaQuran"
Images_PATH = os.path.join(PLUGIN_PATH, "images")
Sound_PATH = os.path.join(PLUGIN_PATH, "sounds")
REMINDERS_FILE = os.path.join(PLUGIN_PATH, "Reminders.json")
Buttons_PATH = os.path.join(PLUGIN_PATH, "buttons")

# ─────────────────────────────────────────────────────────────────────────────
# قراءة ألوان الإسكين الفعلي - للتوافق الديناميكي مع جميع الإسكينات
# ─────────────────────────────────────────────────────────────────────────────
try:
    from skin import colorNames as _skin_color_names
except Exception:
    _skin_color_names = {}

def skin_selection_background():
    # البحث عن اسم لون شريط التظليل في الإسكين المفعَّل
    for name in ("ListboxSelectedBackground", "listboxSelectedBackground",
                 "selectionBackground", "selectedBackground",
                 "ListboxMarkedBackground", "listboxMarkedBackground"):
        try:
            if name in _skin_color_names:
                return name
        except Exception:
            pass
    return "background"

SKIN_SELECTION_BACKGROUND = skin_selection_background()
if SKIN_SELECTION_BACKGROUND == "background":
    SKIN_SELECTION_BACKGROUND = "#3a281a"
DREAMOS_SOFT_HIGHLIGHT_BACKGROUND = "#3a281a"

def read_plugin_version(default="1.3"):
    # قراءة إصدار البلاجين من ملف ver.txt
    try:
        for filename in ("ver.txt", "Ver.txt"):
            version_path = os.path.join(PLUGIN_PATH, filename)
            if os.path.exists(version_path):
                with open(version_path, "rb") as f:
                    value = f.read().decode("utf-8").strip()
                    if value:
                        return value
    except Exception as e:
        print("[IqraaQuran] Could not read version file:", e)
    return default

Plugin_version = read_plugin_version(Plugin_version)

# ─────────────────────────────────────────────────────────────────────────────
# دوال التحويل النصي - متوافقة مع Python 2 و 3
# ─────────────────────────────────────────────────────────────────────────────
def to_unicode(text):
    # تحويل النص إلى unicode في كلا الإصدارين
    if PY2:
        if isinstance(text, str):
            return text.decode('utf-8')
        return text
    else:
        if isinstance(text, bytes):
            return text.decode('utf-8')
        return text

def to_utf8(text):
    # تحويل النص إلى UTF-8 لبايثون 2، أو إرجاع str مباشرةً في بايثون 3
    if PY2:
        if isinstance(text, unicode):
            return text.encode('utf-8')
        return text
    else:
        if isinstance(text, bytes):
            return text.decode('utf-8')
        return text

def to_enigma_string(text):
    # تهيئة النص ليكون مقبولاً في واجهة Enigma2 على كلا الإصدارين
    if PY2:
        if isinstance(text, unicode):
            return text.encode('utf-8')
        return text
    else:
        if isinstance(text, bytes):
            return text.decode('utf-8')
        return text

def safe_menulist_count(widget, fallback_list=None):
    # حساب عدد عناصر MenuList بشكل آمن
    try:
        return widget.count()
    except Exception:
        try:
            return len(fallback_list or [])
        except Exception:
            return 0

def safe_menulist_index(widget, total=0):
    # قراءة فهرس العنصر المحدد بشكل آمن من MenuList
    try:
        index = widget.getSelectedIndex()
    except Exception:
        return 0
    try:
        index = int(index)
    except Exception:
        index = 0
    if total:
        if index < 0:
            index = 0
        elif index >= total:
            index = total - 1
    return index

def arabic_menu_pad(count=22):
    # حشو نصي للقوائم العربية - فراغ عادي متوافق مع جميع الإصدارات
    # في Python 2 نستخدم مسافة unicode عادية لتجنب مشاكل ترميز NBSP
    if PY2:
        return u" " * count
    return u" " * count

# ─────────────────────────────────────────────────────────────────────────────
# نصوص شاشة التلاوة - مُعرَّفة بـ unicode literals صريحة لتجنب أخطاء الترميز
# ─────────────────────────────────────────────────────────────────────────────
RECITATION_SCREEN_TITLE = u"\u0634\u0627\u0634\u0647 \u0627\u0644\u062a\u0644\u0627\u0648\u0647"
RECITATION_HELP_TEXT = (u"\u2191\u2193 \u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0633\u0648\u0631\u0629"
                        u" | \u2190\u2192 \u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0642\u0627\u0631\u0626"
                        u" | OK/\u0627\u0644\u0623\u062e\u0636\u0631 \u062a\u0634\u063a\u064a\u0644"
                        u" | \u0627\u0644\u0623\u0635\u0641\u0631 \u0625\u064a\u0642\u0627\u0641 \u0645\u0624\u0642\u062a"
                        u" | \u0627\u0644\u0623\u062d\u0645\u0631 \u0625\u064a\u0642\u0627\u0641 \u0648\u0625\u063a\u0644\u0627\u0642"
                        u" | EXIT \u0631\u062c\u0648\u0639 \u0644\u0644\u0645\u0635\u062d\u0641 \u0648\u0627\u0644\u0635\u0648\u062a \u0645\u0633\u062a\u0645\u0631")
RECITATION_BUTTON_EXIT = u"\u062e\u0631\u0648\u062c"
RECITATION_BUTTON_PLAY = u"\u062a\u0634\u063a\u064a\u0644"
RECITATION_BUTTON_PAUSE = u"\u0625\u064a\u0642\u0627\u0641 \u0645\u0624\u0642\u062a"
RECITATION_SCREEN_TITLE_SKIN = to_utf8(RECITATION_SCREEN_TITLE)
RECITATION_HELP_TEXT_SKIN = to_utf8(RECITATION_HELP_TEXT)

def strip_enigma_color(text):
    # إزالة رموز الألوان من النص لعرضه بشكل نظيف
    text = to_unicode(text)
    return re.sub(r'\\c[0-9a-fA-F]{8}', '', text).strip()

def left_column_text(text, width=44):
    # محاذاة النص في العمود الأيسر - ضرورية لعرض DreamOS
    text = strip_enigma_color(text)
    if IS_DREAMOS_PY2:
        return text.ljust(width)
    return text

def crop_text(text, max_chars):
    # اقتطاع النص إذا تجاوز الحد الأقصى للأحرف
    text = strip_enigma_color(text)
    if len(text) > max_chars:
        return text[:max_chars - 1] + "."
    return text

def leading_number(text):
    # استخراج الرقم الابتدائي من النص لأغراض الترتيب
    match = re.match(r'\s*(\d+)', strip_enigma_color(text))
    return int(match.group(1)) if match else 999

def text_has_any(text, markers):
    # فحص وجود أي من الكلمات المحددة في النص
    text = strip_enigma_color(text)
    for marker in markers:
        if to_unicode(marker) in text:
            return True
    return False

def reciter_group_from_url(url):
    # تصنيف القارئ حسب رابط URL الخاص به
    url = (url or "").lower()
    if not url:
        return 99
    if "mojawwad" in url:
        return 2
    if "mo-lim" in url or "3zazi" in url or "bari" in url:
        return 3
    if ("rewayat-warsh" in url or "omar_warsh" in url or "koshi" in url
            or "/qari/" in url or "rewayat-assosi" in url
            or "rewayat-khalaf" in url or "abdullah/" in url):
        return 1
    return 0

def reciter_group_from_text(text):
    # تصنيف القارئ حسب النص (المجود، المعلم، الروايات)
    if text_has_any(text, (u"\u0645\u062c\u0648\u062f",)):
        return 2
    if text_has_any(text, (u"\u0645\u0639\u0644\u0645",)):
        return 3
    if text_has_any(text, (u"\u0648\u0631\u0634", u"\u0627\u0644\u0633\u0648\u0633\u064a",
                           u"\u062e\u0644\u0641", u"\u0627\u0644\u0628\u0632\u064a",
                           u"\u0642\u0646\u0628\u0644")):
        return 1
    return None

def reciter_header_group(text):
    # تصنيف عناوين مجموعات القراء لأغراض الترتيب
    text = strip_enigma_color(text)
    if u"\u062d\u0641\u0635" in text:
        return 0
    if u"\u0645\u062c" in text:
        return 2
    if u"\u0645\u0635\u062d\u0641" in text or u"\u0645\u0639\u0644\u0645" in text:
        return 3
    if u"\u0631\u0648\u0627\u064a" in text:
        return 1
    return 99

def reciter_sort_key(item):
    # مفتاح ترتيب القراء: حسب المجموعة ثم الرقم ثم الاسم
    key, info = item
    url = info.get("url", "")
    if not url:
        return (reciter_header_group(key), -1, key)
    text_group = reciter_group_from_text(key)
    group = text_group if text_group is not None else reciter_group_from_url(url)
    return (group, leading_number(key), key)

def ordered_reciter_keys(reciters_data):
    # إرجاع مفاتيح القراء مرتبة حسب المجموعة
    return [key for key, info in sorted(reciters_data.items(), key=reciter_sort_key)]

def audio_colored_text(text, state="normal"):
    # تلوين نص القارئ/السورة حسب حالة التشغيل
    text = strip_enigma_color(text)
    if IS_DREAMOS_PY2:
        # DreamOS Python 2: بدون رموز ألوان لتجنب التشوهات البصرية
        return text
    if state == "selected":
        return "\\c00ffff00" + text
    if state == "playing":
        return "\\c0000ff00" + text
    if state == "paused":
        return "\\c00ffff00" + text
    return "\\c00ffffff" + text

def count_downloaded_pages(pic_path):
    # حساب عدد الصفحات المُنزَّلة في مجلد الصور
    try:
        if os.path.exists(pic_path):
            return len([f for f in os.listdir(pic_path) if f.endswith(".png")])
    except Exception:
        pass
    return 0

reminders_default = {
    "daily_reminder": {"enabled": False, "time_hour": 8, "time_minute": 0, "time_ampm": "AM", "last_reading": 0},
    "friday_reminder": {"enabled": True, "time_hour": 10, "time_minute": 0, "time_ampm": "AM", "last_reminder": 0},
    "page_layout": "double",
    "last_page_layout": "double"
}

def normalize_page_layout(value):
    # التحقق من صحة قيمة تخطيط الصفحة
    if value in ("double", "single"):
        return value
    return "double"

def get_saved_page_layout(reminders):
    # استرجاع تخطيط الصفحة المحفوظ من ملف الإعدادات
    if not isinstance(reminders, dict):
        return "double"
    return normalize_page_layout(reminders.get("last_page_layout", "double"))

def set_saved_page_layout(reminders, layout):
    # تحديث تخطيط الصفحة في قاموس الإعدادات
    if not isinstance(reminders, dict):
        reminders = {}
    layout = normalize_page_layout(layout)
    reminders["page_layout"] = layout
    reminders["last_page_layout"] = layout
    return reminders

def load_json_file(file_path, default_data):
    # تحميل ملف JSON بشكل آمن متوافق مع Python 2 و 3
    if os.path.exists(file_path):
        try:
            with open(file_path, "rb") as f:
                return json.loads(f.read().decode("utf-8"))
        except Exception as e:
            print("[IqraaQuran] Error loading json:", str(e))
            return default_data
    save_json_file(file_path, default_data)
    return default_data

def save_json_file(file_path, data):
    # حفظ بيانات JSON بترميز UTF-8 متوافق مع Python 2 و 3
    try:
        serialized = json.dumps(data, indent=4, ensure_ascii=False)
        if PY2 and isinstance(serialized, unicode):
            serialized = serialized.encode("utf-8")
        elif PY3 and isinstance(serialized, str):
            serialized = serialized.encode("utf-8")
        with open(file_path, "wb") as f:
            f.write(serialized)
    except Exception as e:
        print("[IqraaQuran] Error saving json:", str(e))

def load_reminders():
    # تحميل ملف التذكيرات مع ضمان وجود قيمة صحيحة لتخطيط الصفحة
    reminders = load_json_file(REMINDERS_FILE, reminders_default)
    return set_saved_page_layout(reminders, get_saved_page_layout(reminders))

def save_reminders(reminders):
    # حفظ التذكيرات في الملف
    save_json_file(REMINDERS_FILE, reminders)
    print("Reminders saved to Reminders.json")

class PluginInfoScreen(Screen):
    skin = """
    <screen name="PluginInfoScreen" position="0,0" size="1920,1080" title="معلومات عن بلجن عارض القرآن">
        <widget name="info_pixmap" position="0,0" size="1920,1080" transparent="1" alphatest="on"/>
        <widget name="error_label" position="center,center" size="1200,600" font="Regular;28" halign="center" valign="center" transparent="1"/>
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle(u"معلومات عن {} - إصدار {}".format(Plugin_name, Plugin_version))
        self.image_path = os.path.join(Images_PATH, "info.png")
        self["info_pixmap"] = Pixmap()
        self["error_label"] = Label()
        self["error_label"].hide()
        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.close,
            "cancel": self.close
        }, -1)
        self.onLayoutFinish.append(self.loadImage)

    def loadImage(self):
        # تحميل صورة معلومات البلاجين وعرضها
        if os.path.exists(self.image_path):
            self["info_pixmap"].instance.setPixmap(gPixmapPtr(loadPNG(self.image_path)))
            self["info_pixmap"].instance.setScale(1)
        else:
            self["error_label"].setText(
                u"لم يتم العثور على صورة المعلومات\n\nالرجاء التأكد من وجود الملف في:\n" + self.image_path
            )
            self["error_label"].show()

####################################################  شاشة قراءة المصحف  ####################################################


class DownloadProgressScreen(Screen):
    skin = """
        <screen name="DownloadProgressScreen" position="center,827" size="834,226" title="تحميل صفحات المصحف" flags="wfNoBorder">
            <widget name="batteryFrame" position="130,160" size="600,40" pixmap="{Images_PATH}/progress_empty.png" alphatest="on" zPosition="1" />
            <widget name="progressBar" position="130,160" size="600,40" pixmap="{Images_PATH}/progress_green.png" transparent="1" zPosition="2" />
            <widget name="progressLabel" position="50,24" size="748,51" font="Regular;30" halign="center" transparent="1" zPosition="2" />
            <widget name="progressText" position="50,95" size="748,51" font="Regular;30" halign="center" transparent="1" zPosition="2" />
        </screen>""".format(Images_PATH=Images_PATH)

    def __init__(self, session, callback=None):
        Screen.__init__(self, session)
        self.session = session
        self.callback = callback
        self.picPath = "/media/hdd/quran_pages"
        self.total = 604
        self.downloaded = count_downloaded_pages(self.picPath)
        self["batteryFrame"] = Pixmap()
        self["progressBar"] = ProgressBar()
        self["progressLabel"] = Label(to_enigma_string(u"جاري تحميل صفحات المصحف خلال دقائق ... الرجاء الانتظار..."))
        self["progressText"] = Label("")
        self.timer = eTimer()
        self.timer.callback.append(self.updateProgress)
        self.timer.start(1000, False)
        self.updateProgress()

    def updateProgress(self):
        # تحديث شريط التقدم أثناء تحميل الصفحات
        try:
            self.downloaded = count_downloaded_pages(self.picPath)
        except Exception as e:
            self["progressText"].setText(to_enigma_string(u"خطأ: {}".format(e)))
            return
        percent = int((self.downloaded * 100) // self.total)
        self["progressText"].setText(to_enigma_string(u"تم تحميل {}/{} صفحة (%{})".format(
            self.downloaded, self.total, percent)))
        self["progressBar"].setValue(percent)
        if self.downloaded >= self.total:
            self.timer.stop()
            self["progressText"].setText(to_enigma_string(u"تم تحميل صفحات المصحف بنجاح!"))
            self["progressLabel"].setText("")

            def finish():
                if self.callback:
                    try:
                        self.callback()
                    except Exception as e:
                        print("Callback error:", e)
                self.close()

            self.finish_timer = eTimer()
            self.finish_timer.callback.append(finish)
            self.finish_timer.start(2000, True)

####################################################
# شاشة البحث في القرآن
####################################################


class QuranSearchScreen(Screen):
    # تحديد سكين نتائج البحث حسب نوع الصورة
    if isDreamOS:
        _search_results_skin = '<widget name="search_results" position="50,80" size="1482,791" />'
    else:
        _search_results_skin = ('<widget name="search_results" position="50,80" size="1482,791"'
                                ' font="Regular;28" foregroundColor="#ffffff" foregroundColorSelected="#ffffff"'
                                ' backgroundColor="#101010" backgroundColorSelected="#2f3a40" itemHeight="36" />')

    skin = """
    <screen name="QuranSearchScreen" position="center,center" size="1567,892" title="بحث في القرآن">
        <widget name="search_label" position="430,20" size="1100,50" font="Regular;44" halign="right" transparent="1" />
        {search_results_skin}
        <ePixmap pixmap="{buttons_path}/red.png" position="50,20" size="140,40" alphatest="on" />
        <ePixmap pixmap="{buttons_path}/green.png" position="205,20" size="140,40" alphatest="on" />
        <widget source="key_red" render="Label" position="50,20" zPosition="1" size="140,40" font="Regular;30" halign="center" valign="center" transparent="1" />
        <widget source="key_green" render="Label" position="205,20" zPosition="1" size="140,40" font="Regular;30" foregroundColor="#000000" halign="center" valign="center" transparent="1" />
    </screen>""".format(search_results_skin=_search_results_skin, buttons_path=Buttons_PATH)

    def __init__(self, session, parent, search_term=None, saved_results=None, selected_index=0):
        Screen.__init__(self, session)
        self.parent = parent
        self.search_term = search_term
        self.search_results = []
        self.results_data = saved_results or []
        self.last_selected_index = selected_index
        self["key_red"] = StaticText(to_enigma_string(u"إلغاء"))
        self["key_green"] = StaticText(to_enigma_string(u"عرض"))
        self["search_label"] = Label(to_enigma_string(u"كلمة البحث: {}".format(search_term)))
        self["search_results"] = MenuList([])
        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions", "DirectionActions"],
            {
                "ok": self.handleOk, "green": self.handleOk,
                "cancel": self.handleCancel, "red": self.handleCancel,
                "up": self.up, "down": self.down,
                "left": self.pageUp, "right": self.pageDown,
            }, -2)
        if saved_results:
            self.display_results()
        else:
            self.results_data = parent.search_quran(search_term)
            self.display_results()
        if self.last_selected_index < len(self.results_data):
            target_line_in_menulist = -1
            for line_idx, data_idx in enumerate(self.line_to_result_index):
                if data_idx == self.last_selected_index:
                    target_line_in_menulist = line_idx
                    break
            results_count = safe_menulist_count(self["search_results"], self.line_to_result_index)
            if target_line_in_menulist != -1 and target_line_in_menulist < results_count:
                self["search_results"].moveToIndex(target_line_in_menulist)
            elif self.results_data:
                for line_idx, data_idx in enumerate(self.line_to_result_index):
                    if data_idx == 0:
                        if line_idx < results_count:
                            self["search_results"].moveToIndex(line_idx)
                        break

    def display_results(self):
        # عرض نتائج البحث في قائمة منسقة
        results_display_list = []
        self.line_to_result_index = []
        header = u"{:>5} │ {:>15} │ {:>8} │ {:>5} │ {:<}".format(
            u"م", u"السورة", u"الآية", u"الصفحة", u"النص")
        separator = u"─" * 120
        results_display_list.append(to_enigma_string(header))
        self.line_to_result_index.append(-1)
        results_display_list.append(to_enigma_string(separator))
        self.line_to_result_index.append(-1)
        for i, entry in enumerate(self.results_data):
            wrapped_lines = self.wrap_text(entry.get('highlighted_text', entry['clean_text']), 65)
            first_line = u"{:>5} │ {:>15} │ {:>8} │ {:>5} │ {:<}".format(
                str(i + 1),
                to_utf8(entry['sura_name']),
                str(entry['verse']),
                str(entry['page']),
                to_utf8(wrapped_lines[0])
            )
            results_display_list.append(to_enigma_string(first_line))
            self.line_to_result_index.append(i)
            for extra_line in wrapped_lines[1:]:
                line = u"{:>5} │ {:>15} │ {:>8} │ {:>5} │ {:<}".format(
                    u"", u"", u"", u"", to_utf8(extra_line))
                results_display_list.append(to_enigma_string(line))
                self.line_to_result_index.append(i)
        self["search_results"].setList(results_display_list)

    def wrap_text(self, text, width):
        # تقطيع النص إلى سطور بعرض محدد
        lines = []
        current_line = u""
        for word in text.split():
            if len(current_line + " " + word) <= width:
                current_line += " " + word if current_line else word
            else:
                lines.append(current_line)
                current_line = word
        if current_line:
            lines.append(current_line)
        return lines if lines else [u""]

    def handleOk(self):
        # معالجة ضغطة OK في قائمة نتائج البحث
        selected_line_index = safe_menulist_index(
            self["search_results"], len(self.line_to_result_index))
        if 0 <= selected_line_index < len(self.line_to_result_index):
            result_data_index = self.line_to_result_index[selected_line_index]
            if 0 <= result_data_index < len(self.results_data):
                selected_entry = self.results_data[result_data_index]
                page_to_go = selected_entry["page"]
                self.close(page_to_go, self.results_data, self.search_term, result_data_index)
            else:
                print("Selected line does not map to a valid result.")
        else:
            print("Invalid selection index.")

    def handleCancel(self):
        # إغلاق شاشة البحث مع حفظ حالة البحث
        self.close(None, self.results_data, self.search_term,
                   safe_menulist_index(self["search_results"], len(self.line_to_result_index)))

    def up(self): self["search_results"].up()
    def down(self): self["search_results"].down()
    def pageUp(self): self["search_results"].pageUp()
    def pageDown(self): self["search_results"].pageDown()


class AudioControlAndReciterScreen(Screen):
    # ─────────────────────────────────────────────────────────────────────────
    # تحديد سكين شاشة التلاوة حسب نوع الصورة/Python:
    # IS_DREAMOS_PY2: استخدام Labels مستقلة (DreamOS لا يدعم MenuList الملوّنة)
    # IS_OPENATV_PY3: شاشة صغيرة مع MenuList ملوّنة
    # else: شاشة أكبر للصور الأخرى
    # ─────────────────────────────────────────────────────────────────────────
    if IS_DREAMOS_PY2:
        _screen_size = "1160,760"
        _screen_title = ""
        _screen_attrs = 'backgroundColor="#232323" flags="wfNoBorder"'
        _screen_background_skin = ('<eLabel position="0,0" size="%s" backgroundColor="#232323"'
                                   ' transparent="0" zPosition="0" />'
                                   '<eLabel position="0,0" size="1160,58" backgroundColor="#454b50"'
                                   ' transparent="0" zPosition="1" />'
                                   '<eLabel position="0,58" size="1160,702" backgroundColor="#000000"'
                                   ' transparent="0" zPosition="1" />') % "1160,760"
        _title_skin = ('<widget name="title_label" position="760,8" size="350,38" font="Regular;30"'
                       ' foregroundColor="#d48c1f" backgroundColor="#454b50" halign="right"'
                       ' valign="center" transparent="0" zPosition="3" />')
        _column_lines = ('<eLabel position="285,58" size="2,500" backgroundColor="#505050"'
                         ' transparent="0" zPosition="3" />'
                         '<eLabel position="555,58" size="2,500" backgroundColor="#505050"'
                         ' transparent="0" zPosition="3" />')
        _solid_text_panels = ('<eLabel position="20,80" size="260,420" backgroundColor="#000000"'
                              ' transparent="0" zPosition="2" />'
                              '<eLabel position="300,80" size="245,420" backgroundColor="#000000"'
                              ' transparent="0" zPosition="2" />'
                              '<eLabel position="575,80" size="555,420" backgroundColor="#000000"'
                              ' transparent="0" zPosition="2" />'
                              '<eLabel position="20,545" size="1120,78" backgroundColor="#000000"'
                              ' transparent="0" zPosition="2" />')
        _dreamos_list_y = 88
        _dreamos_line_h = 30
        _dreamos_visible_lines = 13
        _highlight_skin = ('<widget name="reciter_highlight_row" position="585,88" size="535,30"'
                           ' zPosition="5" font="Regular;25" foregroundColor="#ffffff" halign="left"'
                           ' valign="center" backgroundColor="{bg}" transparent="0" />'
                           '<widget name="surah_highlight_row" position="310,88" size="220,30"'
                           ' zPosition="5" font="Regular;25" foregroundColor="#ffffff" halign="left"'
                           ' valign="center" backgroundColor="{bg}" transparent="0" />').format(
            bg=DREAMOS_SOFT_HIGHLIGHT_BACKGROUND)
        _reciter_list_skin = ''.join([
            '<widget name="reciter_row_%d" position="585,%d" size="535,30" zPosition="4"'
            ' font="Regular;25" foregroundColor="#ffffff" backgroundColor="#000000"'
            ' halign="left" valign="center" transparent="0" />' % (i, 88 + (i * 30))
            for i in range(13)
        ])
        _surah_list_skin = ''.join([
            '<widget name="surah_row_%d" position="310,%d" size="220,30" zPosition="4"'
            ' font="Regular;25" foregroundColor="#ffffff" backgroundColor="#000000"'
            ' halign="left" valign="center" transparent="0" />' % (i, 88 + (i * 30))
            for i in range(13)
        ])
        _reciter_label_pos = "585,50"
        _reciter_label_size = "535,34"
        _reciter_label_halign = "left"
        _surah_label_pos = "310,50"
        _surah_label_size = "220,34"
        _surah_label_halign = "left"
        _column_label_color_attr = 'foregroundColor="#ff3030"'
        _left_x = "20"
        _left_label_size = "260,58"
        _playing_label_size = "260,70"
        _left_info_skin = ('<widget name="current_reciter_label" position="20,92" size="260,105"'
                           ' zPosition="4" font="Regular;24" foregroundColor="#ffffff"'
                           ' backgroundColor="#000000" halign="left" valign="center" transparent="0" />'
                           '<widget name="current_surah_label" position="20,200" size="260,54"'
                           ' zPosition="4" font="Regular;26" foregroundColor="#4cff4c"'
                           ' backgroundColor="#000000" halign="left" valign="center" transparent="0" />'
                           '<widget name="playing_surah_label" position="20,275" size="260,60"'
                           ' zPosition="4" font="Regular;27" foregroundColor="#4cff4c"'
                           ' backgroundColor="#000000" halign="left" valign="center" transparent="0" />'
                           '<widget name="play_pause_button_label" position="20,355" size="260,55"'
                           ' zPosition="4" font="Regular;27" foregroundColor="#4cff4c"'
                           ' backgroundColor="#000000" halign="left" valign="center" transparent="0" />'
                           '<widget name="stop_button_label" position="20,435" size="260,55"'
                           ' zPosition="4" font="Regular;27" foregroundColor="#ffffff"'
                           ' backgroundColor="#000000" halign="left" valign="center" transparent="0" />')
        _help_pos = "20,545"
        _help_size = "1120,78"
        _help_panel_background = "#000000"
        _help_panel_transparency = "0"
        _help_panel_z = "2"
        _help_label_attrs = 'foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="-1,-1" zPosition="4"'
        _control_skin = ('<eLabel position="20,635" size="1120,80" backgroundColor="#300000"'
                         ' transparent="0" zPosition="2" />'
                         '<ePixmap pixmap="{bp}/red.png" position="90,650" size="210,50" alphatest="on" zPosition="3" />'
                         '<widget name="red_action_label" position="90,650" size="210,50" zPosition="4"'
                         ' font="Regular;27" halign="center" valign="center" transparent="1" />'
                         '<ePixmap pixmap="{bp}/green.png" position="475,650" size="210,50" alphatest="on" zPosition="3" />'
                         '<widget name="green_action_label" position="475,650" size="210,50" zPosition="4"'
                         ' font="Regular;27" foregroundColor="#000000" halign="center" valign="center" transparent="1" />'
                         '<ePixmap pixmap="{bp}/yellow.png" position="860,650" size="210,50" alphatest="on" zPosition="3" />'
                         '<widget name="yellow_action_label" position="860,650" size="210,50" zPosition="4"'
                         ' font="Regular;27" foregroundColor="#000000" halign="center" valign="center" transparent="1" />'
                         ).format(bp=Buttons_PATH)
        _label_font = "Regular;29"
        _button_font = "Regular;28"
        _help_font = "Regular;23"
        _text_transparency = "0"
        _text_background = '#000000'

    elif IS_OPENATV_PY3:
        _screen_size = "1347,804"
        _screen_title = RECITATION_SCREEN_TITLE_SKIN
        _screen_attrs = ''
        _screen_background_skin = ('<eLabel position="0,0" size="1347,804"'
                                   ' backgroundColor="#101010" zPosition="-10" />')
        _title_skin = ""
        _column_lines = ""
        _solid_text_panels = ""
        _highlight_skin = ""
        _reciter_list_skin = ('<widget name="reciter_list" position="645,84" size="700,438"'
                              ' scrollbarMode="showOnDemand" itemHeight="32" font="Regular;28"'
                              ' foregroundColor="#ffffff" foregroundColorSelected="#ffffff"'
                              ' backgroundColor="#101010" backgroundColorSelected="#2f3a40" />')
        _surah_list_skin = ('<widget name="surah_list" position="350,82" size="250,438"'
                            ' scrollbarMode="showOnDemand" itemHeight="32" font="Regular;28"'
                            ' foregroundColor="#ffffff" foregroundColorSelected="#ffffff"'
                            ' backgroundColor="#101010" backgroundColorSelected="#2f3a40" />')
        _dreamos_list_y = 0
        _dreamos_line_h = 0
        _dreamos_visible_lines = 0
        _reciter_label_pos = "645,18"
        _reciter_label_size = "700,35"
        _reciter_label_halign = "center"
        _surah_label_pos = "350,20"
        _surah_label_size = "250,39"
        _surah_label_halign = "center"
        _column_label_color_attr = 'foregroundColor="#ff3030"'
        _left_x = "20"
        _left_label_size = "320,76"
        _playing_label_size = "320,87"
        _left_info_skin = ('<widget name="current_reciter_label" position="25,92" size="315,112"'
                           ' font="Regular;23" halign="left" valign="center" />'
                           '<widget name="current_surah_label" position="25,205" size="315,52"'
                           ' font="Regular;26" halign="left" valign="center" />'
                           '<widget name="playing_surah_label" position="25,280" size="315,60"'
                           ' font="Regular;30" halign="left" valign="center" />'
                           '<widget name="play_pause_button_label" position="25,365" size="315,55"'
                           ' font="Regular;30" halign="left" valign="center" />'
                           '<widget name="stop_button_label" position="25,445" size="315,55"'
                           ' font="Regular;30" halign="left" valign="center" />')
        _help_pos = "185,590"
        _help_size = "1030,78"
        _help_panel_background = "#101010"
        _help_panel_transparency = "0"
        _help_panel_z = "-1"
        _help_label_attrs = ""
        _control_skin = ('<eLabel position="185,690" size="1030,96" backgroundColor="#300000" zPosition="-1" />'
                         '<ePixmap pixmap="{bp}/red.png" position="230,718" size="230,48" alphatest="on" />'
                         '<widget name="red_action_label" position="230,718" size="230,48" zPosition="1"'
                         ' font="Regular;27" halign="center" valign="center" transparent="1" />'
                         '<ePixmap pixmap="{bp}/green.png" position="558,718" size="230,48" alphatest="on" />'
                         '<widget name="green_action_label" position="558,718" size="230,48" zPosition="1"'
                         ' font="Regular;27" foregroundColor="#000000" halign="center" valign="center" transparent="1" />'
                         '<ePixmap pixmap="{bp}/yellow.png" position="886,718" size="230,48" alphatest="on" />'
                         '<widget name="yellow_action_label" position="886,718" size="230,48" zPosition="1"'
                         ' font="Regular;27" foregroundColor="#000000" halign="center" valign="center" transparent="1" />'
                         ).format(bp=Buttons_PATH)
        _label_font = "Regular;34"
        _button_font = "Regular;32"
        _help_font = "Regular;22"
        _text_transparency = "1"
        _text_background = 'transparent'

    else:
        # صور Python 3 الأخرى (VTi, Black Hole, إلخ)
        _screen_size = "1347,804"
        _screen_title = RECITATION_SCREEN_TITLE_SKIN
        _screen_attrs = ''
        _screen_background_skin = ('<eLabel position="0,0" size="1347,804"'
                                   ' backgroundColor="#101010" zPosition="-10" />')
        _title_skin = ""
        _column_lines = ""
        _highlight_skin = ""
        _reciter_list_skin = ('<widget name="reciter_list" position="702,84" size="625,608"'
                              ' scrollbarMode="showOnDemand" itemHeight="32" font="Regular;28"'
                              ' foregroundColor="#ffffff" foregroundColorSelected="#ffffff"'
                              ' backgroundColor="#101010" backgroundColorSelected="#2f3a40" />')
        _surah_list_skin = ('<widget name="surah_list" position="360,82" size="315,608"'
                            ' scrollbarMode="showOnDemand" itemHeight="32" font="Regular;28"'
                            ' foregroundColor="#ffffff" foregroundColorSelected="#ffffff"'
                            ' backgroundColor="#101010" backgroundColorSelected="#2f3a40" />')
        _dreamos_list_y = 0
        _dreamos_line_h = 0
        _dreamos_visible_lines = 0
        _reciter_label_pos = "702,18"
        _reciter_label_size = "625,35"
        _reciter_label_halign = "center"
        _surah_label_pos = "360,20"
        _surah_label_size = "315,39"
        _surah_label_halign = "center"
        _left_x = "20"
        _left_label_size = "320,76"
        _playing_label_size = "320,87"
        _left_info_skin = ('<widget name="current_reciter_label" position="20,92" size="320,76"'
                           ' font="Regular;27" halign="left" valign="center" />'
                           '<widget name="current_surah_label" position="20,170" size="320,76"'
                           ' font="Regular;27" halign="left" valign="center" />'
                           '<widget name="playing_surah_label" position="20,250" size="320,87"'
                           ' font="Regular;32" halign="left" valign="center" />'
                           '<widget name="play_pause_button_label" position="20,340" size="320,76"'
                           ' font="Regular;32" halign="left" valign="center" />'
                           '<widget name="stop_button_label" position="20,425" size="320,76"'
                           ' font="Regular;32" halign="left" valign="center" />')
        _help_pos = "189,675"
        _help_size = "989,115"
        _solid_text_panels = ""
        _column_label_color_attr = 'foregroundColor="#ff3030"'
        _text_transparency = "1"
        _text_background = 'transparent'
        _help_panel_background = "#101010"
        _help_panel_transparency = "0"
        _help_panel_z = "-1"
        _help_label_attrs = ""
        _control_skin = ""
        _label_font = "Regular;34"
        _button_font = "Regular;32"
        _help_font = "Regular;25"

    skin = """
        <screen name="AudioControlAndReciterScreen" position="center,center" size="{screen_size}" title="{screen_title}" {screen_attrs}>
            {screen_background_skin}
            {solid_text_panels}
            {title_skin}
            {column_lines}
            <widget name="reciter_list_label" position="{reciter_label_pos}" size="{reciter_label_size}" zPosition="4" font="{label_font}" {column_label_color_attr} backgroundColor="{text_background}" halign="{reciter_label_halign}" valign="center" transparent="{text_transparency}" />
            {reciter_list_skin}
            <widget name="surah_list_label" position="{surah_label_pos}" size="{surah_label_size}" zPosition="4" font="{label_font}" {column_label_color_attr} backgroundColor="{text_background}" halign="{surah_label_halign}" valign="center" transparent="{text_transparency}" />
            {surah_list_skin}
            {highlight_skin}
            {left_info_skin}
            <eLabel position="{help_pos}" size="{help_size}" backgroundColor="{help_panel_background}" transparent="{help_panel_transparency}" zPosition="{help_panel_z}" />
            <eLabel text="{help_text}" position="{help_pos}" size="{help_size}" font="{help_font}" {help_label_attrs} backgroundColor="{text_background}" halign="center" valign="center" transparent="{text_transparency}" />
            {control_skin}
        </screen>""".format(
        screen_size=_screen_size, screen_title=_screen_title,
        screen_attrs=_screen_attrs, screen_background_skin=_screen_background_skin,
        title_skin=_title_skin, column_lines=_column_lines,
        solid_text_panels=_solid_text_panels, highlight_skin=_highlight_skin,
        reciter_list_skin=_reciter_list_skin, surah_list_skin=_surah_list_skin,
        reciter_label_pos=_reciter_label_pos, reciter_label_size=_reciter_label_size,
        reciter_label_halign=_reciter_label_halign,
        surah_label_pos=_surah_label_pos, surah_label_size=_surah_label_size,
        surah_label_halign=_surah_label_halign,
        column_label_color_attr=_column_label_color_attr,
        left_info_skin=_left_info_skin,
        help_pos=_help_pos, help_size=_help_size, label_font=_label_font,
        button_font=_button_font, help_font=_help_font,
        help_text=RECITATION_HELP_TEXT_SKIN,
        help_panel_background=_help_panel_background,
        help_panel_transparency=_help_panel_transparency,
        help_panel_z=_help_panel_z, help_label_attrs=_help_label_attrs,
        text_transparency=_text_transparency, text_background=_text_background,
        control_skin=_control_skin
    )

    def __init__(self, session, parent, current_surah_index=0):
        Screen.__init__(self, session)
        self.parent = parent
        self.reciters_data = self.parent.reciters_data
        self.surah_names_simple = self.parent.surah_names_simple[:]
        self.reciter_keys = ordered_reciter_keys(self.reciters_data)
        self.reciter_display = []
        self.selected_reciter_index = self.first_playable_reciter_index()
        self.selected_surah_index = current_surah_index
        self.reciter_key = self.reciter_keys[self.selected_reciter_index] if self.reciter_keys else None

        # ضبط عنوان الشاشة حسب نوع الصورة
        if IS_DREAMOS_PY2:
            self.setTitle("")
            self["title_label"] = Label(to_enigma_string(RECITATION_SCREEN_TITLE))
        else:
            self.setTitle(to_enigma_string(RECITATION_SCREEN_TITLE))

        self["reciter_list_label"] = Label(to_enigma_string(u"اختر القارئ"))

        # في DreamOS: استخدام Labels مستقلة (لعدم دعم MenuList الملوّنة)
        if IS_DREAMOS_PY2:
            self["reciter_highlight_row"] = Label("")
            self["surah_highlight_row"] = Label("")
            for row in range(self._dreamos_visible_lines):
                self["reciter_row_%d" % row] = Label("")
        else:
            self["reciter_list"] = MenuList([])
            try:
                self["reciter_list"].listbox.setMarkupEnabled(True)
            except Exception:
                pass

        self["surah_list_label"] = Label(to_enigma_string(u"اختر السورة"))

        if IS_DREAMOS_PY2:
            for row in range(self._dreamos_visible_lines):
                self["surah_row_%d" % row] = Label("")
        else:
            self["surah_list"] = MenuList([])
            try:
                self["surah_list"].listbox.setMarkupEnabled(True)
            except Exception:
                pass

        self["current_reciter_label"] = Label("")
        self["current_surah_label"] = Label("")
        self["playing_surah_label"] = Label(to_enigma_string(u"متوقف"))
        self["play_pause_button_label"] = Label(to_enigma_string(u"تشغيل"))
        self["stop_button_label"] = Label(to_enigma_string(u"إيقاف وإغلاق"))

        # أزرار الإجراءات (DreamOS و Open-Source)
        if IS_DREAMOS_PY2 or IS_OPEN_SOURCE_PY3:
            self["red_action_label"] = Label(to_enigma_string(RECITATION_BUTTON_EXIT))
            self["green_action_label"] = Label(to_enigma_string(RECITATION_BUTTON_PLAY))
            self["yellow_action_label"] = Label(to_enigma_string(RECITATION_BUTTON_PAUSE))

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok": self.play_selected_surah,
                "green": self.play_selected_surah,
                "yellow": self.pause_audio,
                "red": self.stop_audio_and_close,
                "cancel": self.close,
                "left": self.keyLeft,
                "right": self.keyRight,
                "up": self.keyUp,
                "down": self.keyDown,
            }, -1)

        self.refresh_standard_lists()
        if IS_DREAMOS_PY2:
            self.onLayoutFinish.append(self.refresh_dreamos_columns)
        self.update_reciter_and_surah_labels()
        if self.parent.audio_playing:
            self.update_playing_surah_info(self.parent.current_audio_surah_index)
            self.update_ui_for_pause_play(self.parent.audio_paused)
        else:
            self.update_ui_for_stop()

    def first_playable_reciter_index(self):
        # إيجاد أول قارئ له رابط صوتي صالح
        for index, key in enumerate(self.reciter_keys):
            if self.reciters_data.get(key, {}).get("url"):
                return index
        return 0

    def next_playable_reciter_index(self, start_index, step):
        # إيجاد القارئ الصالح التالي/السابق
        if not self.reciter_keys:
            return 0
        index = start_index
        for _unused in range(len(self.reciter_keys)):
            index = (index + step) % len(self.reciter_keys)
            if self.reciters_data.get(self.reciter_keys[index], {}).get("url"):
                return index
        return start_index

    def refresh_standard_lists(self):
        # تحديث قوائم القراء والسور في صور Python 3
        if IS_DREAMOS_PY2:
            return
        playing_reciter_key = getattr(self.parent, "current_audio_reciter_key", None)
        playing_surah_index = getattr(self.parent, "current_audio_surah_index", -1)
        reciter_items = []
        for index, key in enumerate(self.reciter_keys):
            state = "normal"
            if index == self.selected_reciter_index:
                state = "selected"
            elif playing_reciter_key and key == playing_reciter_key:
                state = "playing"
            reciter_items.append(to_enigma_string(audio_colored_text(left_column_text(key, 58), state)))
        surah_items = []
        for index, name in enumerate(self.surah_names_simple):
            state = "normal"
            if index == self.selected_surah_index:
                state = "selected"
            elif index == playing_surah_index:
                state = "playing"
            surah_items.append(to_enigma_string(audio_colored_text(left_column_text(name, 24), state)))
        self["reciter_list"].setList(reciter_items)
        self.selected_reciter_index = (max(0, min(self.selected_reciter_index, len(reciter_items) - 1))
                                       if reciter_items else 0)
        self["reciter_list"].moveToIndex(self.selected_reciter_index)
        self["surah_list"].setList(surah_items)
        self.selected_surah_index = (max(0, min(self.selected_surah_index, len(surah_items) - 1))
                                     if surah_items else 0)
        self["surah_list"].moveToIndex(self.selected_surah_index)

    def move_dreamos_highlight_row(self, widget_name, x_pos, row, text):
        # تحريك صف التظليل في DreamOS إلى الموضع الصحيح
        try:
            y_pos = self._dreamos_list_y + (row * self._dreamos_line_h)
            widget = self[widget_name]
            if getattr(widget, "instance", None):
                widget.instance.move(ePoint(x_pos, y_pos))
                widget.show()
            widget.setText(to_enigma_string(text))
        except Exception as e:
            print("[AudioControl] highlight move skipped: {}".format(e))

    def dreamos_page_start(self, selected_index, total_items):
        # حساب بداية الصفحة المرئية في DreamOS
        visible_lines = self._dreamos_visible_lines or 1
        start = (selected_index // visible_lines) * visible_lines
        if start >= total_items:
            start = max(0, total_items - visible_lines)
        return start

    def refresh_dreamos_columns(self):
        # تحديث أعمدة القراء والسور في DreamOS (labels مستقلة)
        if not IS_DREAMOS_PY2:
            return
        selected_reciter_text = ""
        start = self.dreamos_page_start(self.selected_reciter_index, len(self.reciter_keys))
        end = min(len(self.reciter_keys), start + self._dreamos_visible_lines)
        for row in range(self._dreamos_visible_lines):
            self["reciter_row_%d" % row].setText("")
        for idx in range(start, end):
            row = idx - start
            line = crop_text(self.reciter_keys[idx], 46)
            if idx == self.selected_reciter_index:
                selected_reciter_text = audio_colored_text(line, "selected")
                line = ""
            elif getattr(self.parent, "current_audio_reciter_key", None) == self.reciter_keys[idx]:
                line = audio_colored_text(line, "playing")
            else:
                line = audio_colored_text(line, "normal")
            self["reciter_row_%d" % row].setText(to_enigma_string(line))
        self.move_dreamos_highlight_row("reciter_highlight_row",
                                        585, self.selected_reciter_index - start, selected_reciter_text)

        selected_surah_text = ""
        start = self.dreamos_page_start(self.selected_surah_index, len(self.surah_names_simple))
        end = min(len(self.surah_names_simple), start + self._dreamos_visible_lines)
        for row in range(self._dreamos_visible_lines):
            self["surah_row_%d" % row].setText("")
        for idx in range(start, end):
            row = idx - start
            line = crop_text(self.surah_names_simple[idx], 18)
            if idx == self.selected_surah_index:
                selected_surah_text = audio_colored_text(line, "selected")
                line = ""
            elif idx == getattr(self.parent, "current_audio_surah_index", -1):
                line = audio_colored_text(line, "playing")
            else:
                line = audio_colored_text(line, "normal")
            self["surah_row_%d" % row].setText(to_enigma_string(line))
        self.move_dreamos_highlight_row("surah_highlight_row",
                                        310, self.selected_surah_index - start, selected_surah_text)

    def update_reciter_and_surah_labels(self):
        # تحديث تسميات القارئ والسورة المحددين
        if self.reciter_keys:
            self.reciter_key = self.reciter_keys[self.selected_reciter_index]
            if self.reciters_data[self.reciter_key]["url"]:
                clean_key = strip_enigma_color(self.reciter_key)
                if IS_DREAMOS_PY2 or IS_OPENATV_PY3:
                    self["current_reciter_label"].setText(to_enigma_string(u"القارئ:\n{}".format(clean_key)))
                else:
                    self["current_reciter_label"].setText(to_enigma_string(u"القارئ: {}".format(clean_key)))
            else:
                self["current_reciter_label"].setText("")
            if not IS_DREAMOS_PY2:
                self.refresh_standard_lists()
        if self.surah_names_simple:
            surah_name = self.surah_names_simple[self.selected_surah_index]
            self["current_surah_label"].setText(to_enigma_string(u"السورة: {}".format(surah_name)))
            if not IS_DREAMOS_PY2:
                self.refresh_standard_lists()
        self.refresh_dreamos_columns()

    def keyLeftRightReciter(self, direction):
        # التنقل بين القراء يساراً/يميناً
        if not self.reciter_keys:
            return
        if direction == "left":
            self.selected_reciter_index = self.next_playable_reciter_index(
                self.selected_reciter_index, -1)
        elif direction == "right":
            self.selected_reciter_index = self.next_playable_reciter_index(
                self.selected_reciter_index, 1)
        if not IS_DREAMOS_PY2:
            self.refresh_standard_lists()
        self.update_reciter_and_surah_labels()

    def keyUpDownSurah(self, direction):
        # التنقل بين السور أعلى/أسفل
        if IS_DREAMOS_PY2:
            if direction == "up":
                self.selected_surah_index = max(0, self.selected_surah_index - 1)
            elif direction == "down":
                self.selected_surah_index = min(
                    len(self.surah_names_simple) - 1, self.selected_surah_index + 1)
        else:
            if direction == "up":
                self["surah_list"].up()
            elif direction == "down":
                self["surah_list"].down()
            self.selected_surah_index = safe_menulist_index(
                self["surah_list"], len(self.surah_names_simple))
            self.refresh_standard_lists()
        self.update_reciter_and_surah_labels()

    def play_selected_surah(self):
        # تشغيل السورة المحددة للقارئ المحدد
        if not self.reciter_key or self.selected_surah_index < 0:
            self.session.open(MessageBox,
                              u"الرجاء اختيار القارئ والسورة أولاً.", MessageBox.TYPE_INFO)
            return
        print("[AudioControl] Play selected: Reciter {}, Surah Index {}".format(
            self.reciter_key, self.selected_surah_index))
        self.parent.play_audio_for_surah(self.reciter_key, self.selected_surah_index)

    def stop_audio_and_close(self):
        # إيقاف الصوت وإغلاق الشاشة
        self.parent.stop_current_audio(restore_service=True)
        self.close()

    def togglePlayPause(self):
        # تبديل حالة التشغيل/الإيقاف المؤقت
        self.parent.toggle_audio_pause()

    def pause_audio(self):
        # إيقاف الصوت مؤقتاً إذا كان يعمل
        if self.parent.audio_playing:
            self.parent.toggle_audio_pause()

    def update_playing_surah_info(self, surah_index):
        # تحديث معلومات السورة التي تُشغَّل حالياً
        self.selected_surah_index = surah_index
        if 0 <= surah_index < len(self.surah_names_simple):
            surah_name = self.surah_names_simple[surah_index]
            self["playing_surah_label"].setText(to_enigma_string(u"جاري تشغيل: {}".format(surah_name)))
        else:
            self["playing_surah_label"].setText(to_enigma_string(u"جاري تشغيل سورة..."))
        self["play_pause_button_label"].setText(to_enigma_string(u"إيقاف مؤقت"))
        self.update_reciter_and_surah_labels()
        self.refresh_standard_lists()

    def update_ui_for_stop(self):
        # تحديث الواجهة عند إيقاف التشغيل
        self["playing_surah_label"].setText(to_enigma_string(u"متوقف"))
        self["play_pause_button_label"].setText(to_enigma_string(u"تشغيل"))
        self.refresh_standard_lists()
        self.refresh_dreamos_columns()

    def update_ui_for_pause_play(self, is_paused):
        # تحديث زر التشغيل/الإيقاف المؤقت
        if is_paused:
            self["play_pause_button_label"].setText(to_enigma_string(u"استئناف"))
        else:
            self["play_pause_button_label"].setText(to_enigma_string(u"إيقاف مؤقت"))

    def keyUp(self): self.keyUpDownSurah("up")
    def keyDown(self): self.keyUpDownSurah("down")
    def keyLeft(self): self.keyLeftRightReciter("left")
    def keyRight(self): self.keyLeftRightReciter("right")


class PageInputScreen(Screen):
    skin = """
        <screen position="center,center" size="860,650" title="ادخل رقم الصفحة" flags="wfNoBorder">
            <eLabel position="0,0" size="860,650" backgroundColor="#555555" zPosition="-2" />
            <widget name="screen_title" position="520,18" size="285,42" font="Regular;34" foregroundColor="#d6a33a" halign="right" valign="center" transparent="1" zPosition="2" />
            <widget name="highlight_page" position="145,105" size="525,70" backgroundColor="{selection_background}" transparent="0" zPosition="0" />
            <widget name="highlight_surah" position="145,195" size="525,70" backgroundColor="{selection_background}" transparent="0" zPosition="0" />
            <widget name="highlight_ayah" position="145,285" size="525,70" backgroundColor="{selection_background}" transparent="0" zPosition="0" />
            <widget name="highlight_word" position="145,375" size="525,55" backgroundColor="{selection_background}" transparent="0" zPosition="0" />
            <eLabel position="145,105" size="250,70" backgroundColor="#00304d" zPosition="-1" />
            <widget name="page_number_title" position="420,105" size="250,70" font="Regular;34" foregroundColor="#d6a33a" halign="center" valign="center" transparent="1" zPosition="2" />
            <widget name="page_number" position="145,105" size="250,70" font="Regular;42" foregroundColor="#dfff00" halign="center" valign="center" transparent="1" zPosition="2" />
            <eLabel position="420,105" size="250,70" backgroundColor="#00304d" zPosition="-1" />
            <eLabel position="145,195" size="250,70" backgroundColor="#00304d" zPosition="-1" />
            <widget name="surah_title" position="420,195" size="250,70" font="Regular;34" foregroundColor="#d6a33a" halign="center" valign="center" transparent="1" zPosition="2" />
            <widget name="surah_name" position="145,195" size="250,70" font="Regular;34" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="2" />
            <eLabel position="420,195" size="250,70" backgroundColor="#00304d" zPosition="-1" />
            <widget name="ayah_title" position="420,285" size="250,70" font="Regular;34" foregroundColor="#d6a33a" halign="center" valign="center" transparent="1" zPosition="2" />
            <widget name="ayah_number" position="145,285" size="250,70" font="Regular;34" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="2" />
            <eLabel position="145,285" size="250,70" backgroundColor="#00304d" zPosition="-1" />
            <eLabel position="420,285" size="250,70" backgroundColor="#00304d" zPosition="-1" />
            <eLabel position="145,375" size="250,55" backgroundColor="#00304d" zPosition="-1" />
            <eLabel position="420,375" size="250,55" backgroundColor="#00304d" zPosition="-1" />
            <widget name="word_search_label" position="420,375" size="250,55" font="Regular;30" foregroundColor="#d6a33a" halign="center" valign="center" transparent="1" zPosition="2" />
            <widget name="word_search_button" position="145,375" size="250,55" font="Regular;30" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="2" />
            <widget name="surah_menu_panel" position="355,92" size="350,350" backgroundColor="background" transparent="0" zPosition="5" />
            <widget name="surah_menu" position="370,105" size="320,325" font="Regular;30" scrollbarMode="showOnDemand" itemHeight="38" zPosition="6" />
            <eLabel position="105,455" size="640,70" backgroundColor="#214b70" zPosition="-1" />
            <widget name="input_label" position="120,463" size="610,54" font="Regular;29" halign="center" valign="center" transparent="1" zPosition="2" />
            <widget name="cancel_button" position="250,560" size="170,60" font="Regular;34" foregroundColor="#ffffff" backgroundColor="#d00000" halign="center" valign="center" />
            <widget name="ok_button" position="500,560" size="170,60" font="Regular;34" foregroundColor="#000000" backgroundColor="#00b000" halign="center" valign="center" />
        </screen>""".format(Images_PATH=Images_PATH, selection_background=SKIN_SELECTION_BACKGROUND)

    def __init__(self, session, currentPage=1, suraList=None):
        Screen.__init__(self, session)
        self.currentPage = currentPage
        self.suraList = suraList or []
        self.selected_field = 0
        self.selected_surah_index = self.current_surah_index()
        self.surah_table_open = False
        self.ayah_value = 1
        self.input_text = ""
        self["screen_title"] = Label(to_enigma_string(u"شاشة البحث"))
        self["input_label"] = Label(to_enigma_string(u"استخدم الأرقام أو الأسهم للتنقل"))
        self["page_number_title"] = Label(to_enigma_string(u"رقم الصفحة"))
        self["page_number"] = Label(str(self.currentPage))
        self["surah_title"] = Label(to_enigma_string(u"السورة"))
        self["surah_name"] = Label("")
        self["ayah_title"] = Label(to_enigma_string(u"الآية"))
        self["ayah_number"] = Label("1")
        self["word_search_label"] = Label(to_enigma_string(u"البحث بالكلمة"))
        self["word_search_button"] = Label(to_enigma_string(u"اضغط OK"))
        self["surah_menu_panel"] = Label("")
        self["surah_menu"] = MenuList([])
        self["surah_menu"].setList([
            to_enigma_string(self.format_search_surah_menu_name(item[0]))
            for item in self.suraList
        ])
        for name in ("highlight_page", "highlight_surah", "highlight_ayah", "highlight_word"):
            self[name] = Label("")
        self["ok_button"] = Label(to_enigma_string(u"موافق"))
        self["cancel_button"] = Label(to_enigma_string(u"إلغاء"))
        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions", "NumberActions"],
            {
                "ok": self.confirm,
                "cancel": self.handleCancel,
                "green": self.green_confirm,
                "red": self.close,
                "blue": self.word_search,
                "up": self.previous_field,
                "down": self.next_field,
                "left": self.decrease_current,
                "right": self.increase_current,
                "0": lambda: self.addDigit("0"),
                "1": lambda: self.addDigit("1"),
                "2": lambda: self.addDigit("2"),
                "3": lambda: self.addDigit("3"),
                "4": lambda: self.addDigit("4"),
                "5": lambda: self.addDigit("5"),
                "6": lambda: self.addDigit("6"),
                "7": lambda: self.addDigit("7"),
                "8": lambda: self.addDigit("8"),
                "9": lambda: self.addDigit("9"),
            })
        self.update_display()
        self.refresh_highlight()

    def increment(self):
        # زيادة رقم الصفحة بمقدار واحد
        if self.currentPage < 604:
            self.currentPage += 1
            self.selected_surah_index = self.current_surah_index()
            self.update_display()

    def decrement(self):
        # إنقاص رقم الصفحة بمقدار واحد
        if self.currentPage > 1:
            self.currentPage -= 1
            self.selected_surah_index = self.current_surah_index()
            self.update_display()

    def update_display(self):
        # تحديث عرض رقم الصفحة واسم السورة والآية
        self["page_number"].setText(to_enigma_string(str(self.currentPage)))
        self["surah_name"].setText(to_enigma_string(self.surah_name_for_page(self.currentPage)))
        self["ayah_number"].setText(to_enigma_string(str(self.ayah_value)))
        self.input_text = ""
        if self.suraList:
            try:
                self["surah_menu"].moveToIndex(self.selected_surah_index)
            except Exception:
                pass

    def format_search_surah_menu_name(self, name):
        # تنسيق اسم السورة في قائمة البحث
        if IS_DREAMOS_PY2:
            return arabic_menu_pad(10) + name
        return name

    def refresh_highlight(self):
        # تحديث إبراز الحقل المحدد حالياً
        names = ("highlight_page", "highlight_surah", "highlight_ayah", "highlight_word")
        for idx, name in enumerate(names):
            if idx == self.selected_field:
                self[name].show()
            else:
                self[name].hide()
        if self.selected_field == 1 and self.surah_table_open:
            self["surah_menu_panel"].show()
            self["surah_menu"].show()
        else:
            self["surah_menu_panel"].hide()
            self["surah_menu"].hide()

    def sync_openatv_surah_menu_selection(self):
        # مزامنة اختيار السورة في OpenATV
        if not (IS_OPENATV_PY3 and self.surah_table_open and self.suraList):
            return
        self.sync_search_surah_menu_selection()

    def sync_search_surah_menu_selection(self):
        # مزامنة اختيار السورة من قائمة البحث
        if not (self.surah_table_open and self.suraList):
            return
        try:
            index = self["surah_menu"].getSelectedIndex()
            if 0 <= index < len(self.suraList):
                self.selected_surah_index = index
                self.currentPage = self.suraList[index][1]
        except Exception as e:
            print("[IqraaQuran] Search surah menu sync failed:", e)

    def next_field(self):
        # الانتقال إلى الحقل التالي أو التمرير داخل قائمة السور
        if IS_OPENATV_PY3 and self.selected_field == 1 and self.surah_table_open:
            try:
                self["surah_menu"].down()
            except Exception:
                pass
            self.sync_openatv_surah_menu_selection()
            self.update_display()
            self.refresh_highlight()
            return
        self.selected_field = (self.selected_field + 1) % 4
        if self.selected_field == 1:
            self.surah_table_open = True
        self.refresh_highlight()

    def previous_field(self):
        # الانتقال إلى الحقل السابق أو التمرير داخل قائمة السور
        if IS_OPENATV_PY3 and self.selected_field == 1 and self.surah_table_open:
            try:
                self["surah_menu"].up()
            except Exception:
                pass
            self.sync_openatv_surah_menu_selection()
            self.update_display()
            self.refresh_highlight()
            return
        self.selected_field = (self.selected_field - 1) % 4
        if self.selected_field == 1:
            self.surah_table_open = True
        self.refresh_highlight()

    def increase_current(self):
        # زيادة قيمة الحقل الحالي
        if self.selected_field == 0:
            self.increment()
        elif self.selected_field == 1 and self.suraList:
            self.surah_table_open = True
            self.selected_surah_index = min(len(self.suraList) - 1, self.selected_surah_index + 1)
            self.currentPage = self.suraList[self.selected_surah_index][1]
            self.update_display()
            self.refresh_highlight()
        elif self.selected_field == 2:
            self.ayah_value += 1
            self.update_display()

    def decrease_current(self):
        # إنقاص قيمة الحقل الحالي
        if self.selected_field == 0:
            self.decrement()
        elif self.selected_field == 1 and self.suraList:
            self.surah_table_open = True
            self.selected_surah_index = max(0, self.selected_surah_index - 1)
            self.currentPage = self.suraList[self.selected_surah_index][1]
            self.update_display()
            self.refresh_highlight()
        elif self.selected_field == 2 and self.ayah_value > 1:
            self.ayah_value -= 1
            self.update_display()

    def current_surah_index(self):
        # حساب فهرس السورة الحالية بناءً على رقم الصفحة
        current = 0
        for index, item in enumerate(self.suraList):
            if self.currentPage >= item[1]:
                current = index
            else:
                break
        return current

    def surah_name_for_page(self, page):
        # الحصول على اسم السورة بناءً على رقم الصفحة
        current = u"الفاتحة"
        for name, start in self.suraList:
            if page >= start:
                current = name
            else:
                break
        return current

    def word_search(self):
        # تفعيل وضع البحث بالكلمة
        self.close("word_search")

    def selected_surah_page(self):
        # الحصول على رقم صفحة السورة المحددة
        if not self.suraList:
            return None
        try:
            index = int(self.selected_surah_index)
        except Exception:
            index = self.current_surah_index()
        if index < 0:
            index = 0
        elif index >= len(self.suraList):
            index = len(self.suraList) - 1
        try:
            return int(self.suraList[index][1])
        except Exception:
            return None

    def page_for_selected_surah_ayah(self):
        # الحصول على رقم الصفحة بناءً على السورة والآية المحددتين
        if not PAGE_VERSE_MAP:
            return None
        try:
            sura_num = int(self.selected_surah_index) + 1
            verse_num = int(self.ayah_value)
        except Exception:
            return None
        if verse_num < 1:
            verse_num = 1
        page = None
        for index, item in enumerate(PAGE_VERSE_MAP):
            try:
                start_sura = int(item[0])
                start_verse = int(item[1])
            except Exception:
                continue
            if start_sura < sura_num or (start_sura == sura_num and start_verse <= verse_num):
                page = index + 1
            else:
                break
        return page

    def addDigit(self, digit):
        # إضافة رقم لحقل الإدخال الحالي
        if self.selected_field not in (0, 2):
            return
        self.input_text += digit
        if len(self.input_text) > 3:
            self.input_text = self.input_text[-3:]
        if self.selected_field == 0:
            self["page_number"].setText(to_enigma_string(self.input_text))
        elif self.selected_field == 2:
            self["ayah_number"].setText(to_enigma_string(self.input_text))

    def confirm(self):
        # تأكيد الاختيار حسب الحقل الحالي
        if self.selected_field == 3:
            self.word_search()
            return
        if self.selected_field == 1 and self.suraList:
            if IS_DREAMOS_PY2:
                if self.surah_table_open:
                    self.sync_search_surah_menu_selection()
                    self.currentPage = self.suraList[self.selected_surah_index][1]
                    self.update_display()
                    self.surah_table_open = False
                    self.refresh_highlight()
                    return
                page = self.selected_surah_page()
                if page:
                    self.close(page)
                    return
                self["input_label"].setText(to_enigma_string(u"تعذر تحديد صفحة السورة"))
                return
            if IS_OPENATV_PY3:
                if self.surah_table_open:
                    self.sync_search_surah_menu_selection()
                    self.currentPage = self.suraList[self.selected_surah_index][1]
                    self.update_display()
                    self.surah_table_open = False
                    self.refresh_highlight()
                    return
                page = self.selected_surah_page()
                if page:
                    self.close(page)
                    return
                self["input_label"].setText(to_enigma_string(u"تعذر تحديد صفحة السورة"))
                return
            self.sync_openatv_surah_menu_selection()
            self.currentPage = self.suraList[self.selected_surah_index][1]
            self.update_display()
            self.surah_table_open = False
            self.refresh_highlight()
            return
        if self.selected_field == 2:
            if self.input_text:
                self.ayah_value = max(1, int(self.input_text))
            if IS_OPENATV_PY3 or IS_DREAMOS_PY2:
                target_page = self.page_for_selected_surah_ayah()
                if target_page:
                    self.close(target_page)
                    return
                self["input_label"].setText(to_enigma_string(u"تعذر تحديد صفحة الآية"))
                return
            self.input_text = ""
            self.update_display()
            return
        if not self.input_text and not self.currentPage:
            self["input_label"].setText(to_enigma_string(u"الرجاء إدخال رقم!"))
            return
        if self.input_text:
            try:
                entered_page = int(self.input_text)
                if 1 <= entered_page <= 604:
                    self.close(entered_page)
                else:
                    self["input_label"].setText(to_enigma_string(u"رقم غير صالح (1-604)!"))
            except ValueError:
                self["input_label"].setText(to_enigma_string(u"أدخل أرقامًا فقط!"))
        else:
            self.close(self.currentPage)

    def green_confirm(self):
        # تأكيد اختيار السورة بزر الأخضر في DreamOS
        if IS_DREAMOS_PY2 and self.selected_field == 1 and self.suraList:
            if self.surah_table_open:
                self.sync_search_surah_menu_selection()
                self.currentPage = self.suraList[self.selected_surah_index][1]
                self.update_display()
                self.surah_table_open = False
                self.refresh_highlight()
                return
            page = self.selected_surah_page()
            if page:
                self.close(page)
                return
            self["input_label"].setText(to_enigma_string(u"تعذر تحديد صفحة السورة"))
            return
        self.confirm()

    def handleCancel(self):
        # إلغاء أو إغلاق الشاشة
        if self.selected_field == 1 and self.surah_table_open:
            self.surah_table_open = False
            self.refresh_highlight()
            return
        self.close()


class QuranStatsScreen(Screen):
    skin = """
        <screen name="QuranStatsScreen" position="510,245" size="900,620" title="إحصائيات القراءة">
            <!-- statsLabel: محاذاة النص للأعلى بدلاً من المنتصف لملء المساحة الفارغة -->
            <widget name="statsLabel" position="50,30" size="800,560" font="Regular;42" halign="right" valign="top" transparent="1" />
        </screen>
    """

    def __init__(self, session, stats_text):
        Screen.__init__(self, session)
        self["statsLabel"] = Label()
        self["statsLabel"].setText(to_enigma_string(stats_text))
        self["actions"] = ActionMap(["OkCancelActions"], {
            "cancel": self.close,
            "ok": self.close
        }, -1)


class QuranSettings(ConfigListScreen, Screen):
    skin = """
        <screen position="center,center" size="1300,760" title="" backgroundColor="#101010" flags="wfNoBorder">
            <eLabel position="0,0" size="1300,58" backgroundColor="#454b50" transparent="0" zPosition="-1" />
            <widget source="settings_title" render="Label" position="620,6" size="610,44" font="Regular;32" foregroundColor="#d48c1f" halign="right" valign="center" transparent="1" />
            <widget name="config" position="30,60" size="1200,500" scrollbarMode="showOnDemand" itemHeight="48" />
            <eLabel position="30,578" size="1200,82" backgroundColor="#101010" zPosition="-1" />
            <widget source="settings_help" render="Label" position="50,586" size="1160,66" font="Regular;28" halign="center" valign="center" transparent="1" />
            <ePixmap pixmap="{bp}/red.png" position="170,690" size="240,58" alphatest="on" />
            <ePixmap pixmap="{bp}/green.png" position="530,690" size="240,58" alphatest="on" />
            <ePixmap pixmap="{bp}/blue.png" position="890,690" size="240,58" alphatest="on" />
            <widget source="key_red" render="Label" position="170,690" zPosition="1" size="240,58" font="Regular;35" halign="center" valign="center" transparent="1" />
            <widget source="key_green" render="Label" position="530,690" zPosition="1" size="240,58" font="Regular;35" foregroundColor="#000000" halign="center" valign="center" transparent="1" />
            <widget source="key_blue" render="Label" position="890,690" zPosition="1" size="240,58" font="Regular;35" halign="center" valign="center" transparent="1" />
        </screen>""".format(bp=Buttons_PATH)

    def __init__(self, session, parent=None):
        Screen.__init__(self, session)
        self.parent = parent
        reminders = load_reminders()
        self.auto_update_enabled = ConfigYesNo(default=reminders.get("auto_update", True))
        self.daily_reminder_enabled = ConfigYesNo(default=reminders["daily_reminder"]["enabled"])
        self.friday_reminder_enabled = ConfigYesNo(default=reminders["friday_reminder"]["enabled"])

        current_hour_daily = reminders["daily_reminder"]["time_hour"]
        current_ampm_daily = "AM" if reminders["daily_reminder"]["time_ampm"] == "AM" else "PM"
        if current_hour_daily > 12:
            current_hour_daily -= 12
        elif current_hour_daily == 0:
            current_hour_daily = 12

        current_hour_friday = reminders["friday_reminder"]["time_hour"]
        current_ampm_friday = "AM" if reminders["friday_reminder"]["time_ampm"] == "AM" else "PM"
        if current_hour_friday > 12:
            current_hour_friday -= 12
        elif current_hour_friday == 0:
            current_hour_friday = 12

        self.daily_reminder_hours = ConfigSelection(
            default=str(current_hour_daily),
            choices=[(str(i), to_enigma_string(u"وقت التذكير اليومي - الساعة {:02d}".format(i))) for i in range(1, 13)]
        )
        self.daily_reminder_minutes = ConfigSelection(
            default=str(reminders["daily_reminder"]["time_minute"]),
            choices=[(str(i), to_enigma_string(u"دقيقة التذكير اليومي - الدقيقة {:02d}".format(i))) for i in range(0, 60)]
        )
        self.daily_reminder_ampm = ConfigSelection(
            default=current_ampm_daily,
            choices=[("AM", to_enigma_string(u"فترة التذكير اليومي - صباحاً")), ("PM", to_enigma_string(u"فترة التذكير اليومي - مساءً"))]
        )
        self.friday_reminder_hours = ConfigSelection(
            default=str(current_hour_friday),
            choices=[(str(i), to_enigma_string(u"ساعة تذكير الجمعة - الساعة {:02d}".format(i))) for i in range(1, 13)]
        )
        self.friday_reminder_minutes = ConfigSelection(
            default=str(reminders["friday_reminder"]["time_minute"]),
            choices=[(str(i), to_enigma_string(u"دقيقة تذكير الجمعة - الدقيقة {:02d}".format(i))) for i in range(0, 60)]
        )
        self.friday_reminder_ampm = ConfigSelection(
            default=current_ampm_friday,
            choices=[("AM", to_enigma_string(u"فترة تذكير الجمعة - صباحاً")), ("PM", to_enigma_string(u"فترة تذكير الجمعة - مساءً"))]
        )
        self.page_layout = ConfigSelection(
            default=get_saved_page_layout(reminders),
            choices=[("double", to_enigma_string(u"عرض الصفحات - صفحتان")), ("single", to_enigma_string(u"عرض الصفحات - صفحة واحدة"))]
        )
        # اختيار رواية المصحف: حفص أو ورش
        self.mushaf_riwaya = ConfigSelection(
            default=reminders.get("mushaf_riwaya", "hafs"),
            choices=[("hafs", to_enigma_string(u"رواية المصحف - حفص عن عاصم")), ("warsh", to_enigma_string(u"رواية المصحف - ورش عن نافع"))]
        )
        ConfigListScreen.__init__(self, [])

        # ضبط فاصل أعمدة قائمة الإعدادات - يجرب الاسمين المختلفين
        try:
            self["config"].l.setSeperation(560)
        except Exception:
            try:
                self["config"].l.setSeparation(560)
            except Exception:
                pass

        self.setTitle("")
        self["settings_title"] = StaticText(to_enigma_string(u"إعدادات تذكير قراءة القرآن"))
        self["key_red"] = StaticText(to_enigma_string(u"إلغاء"))
        self["key_green"] = StaticText(to_enigma_string(u"حفظ"))
        self["key_blue"] = StaticText(to_enigma_string(u"الإحصائيات"))
        self["settings_help"] = StaticText(
            to_enigma_string(u"OK أو السهم يمين/يسار لتغيير الاختيار | الأخضر حفظ | الأحمر إلغاء | الأزرق إحصائيات القراءة | EXIT رجوع")
        )
        self.setupList()
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"], {
            "ok": self.keyOK,
            "save": self.save,
            "cancel": self.cancel,
            "red": self.cancel,
            "green": self.save,
            "blue": self.show_stats,
            "left": self.keyLeft,
            "right": self.keyRight,
        }, -2)

    def setupList(self):
        # بناء قائمة إعدادات التذكير وتخطيط الصفحة والرواية
        self.list = []
        self.list.append(getConfigListEntry(to_enigma_string(u"التحقق من التحديثات"), self.auto_update_enabled))
        self.list.append(getConfigListEntry(to_enigma_string(u"التذكير اليومي"), self.daily_reminder_enabled))
        if self.daily_reminder_enabled.value:
            self.list.append(getConfigListEntry("", self.daily_reminder_hours))
            self.list.append(getConfigListEntry("", self.daily_reminder_minutes))
            self.list.append(getConfigListEntry("", self.daily_reminder_ampm))
        self.list.append(getConfigListEntry(to_enigma_string(u"تذكير الكهف الجمعة"), self.friday_reminder_enabled))
        if self.friday_reminder_enabled.value:
            self.list.append(getConfigListEntry("", self.friday_reminder_hours))
            self.list.append(getConfigListEntry("", self.friday_reminder_minutes))
            self.list.append(getConfigListEntry("", self.friday_reminder_ampm))
        self.list.append(getConfigListEntry("", self.page_layout))
        # إضافة خيار الرواية لقائمة الإعدادات
        self.list.append(getConfigListEntry("", self.mushaf_riwaya))
        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def keyOK(self):
        current = self["config"].getCurrent()
        if current:
            self.keyRight()

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.setupList()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.setupList()

    def convert_12h_to_24h(self, hour, ampm):
        # تحويل الوقت من نظام 12 ساعة إلى 24 ساعة
        if ampm == "PM" and hour < 12:
            return hour + 12
        elif ampm == "AM" and hour == 12:
            return 0
        else:
            return hour

    def save(self):
        # حفظ جميع إعدادات التذكير والتخطيط والرواية
        reminders = load_reminders()
        reminders["auto_update"] = self.auto_update_enabled.value
        reminders["daily_reminder"]["enabled"] = (
            self.daily_reminder_enabled.value
            if hasattr(self, 'daily_reminder_enabled')
            else reminders["daily_reminder"]["enabled"]
        )
        reminders["daily_reminder"]["time_hour"] = int(self.daily_reminder_hours.value)
        reminders["daily_reminder"]["time_minute"] = int(self.daily_reminder_minutes.value)
        reminders["daily_reminder"]["time_ampm"] = self.daily_reminder_ampm.value
        reminders["friday_reminder"]["enabled"] = (
            self.friday_reminder_enabled.value
            if hasattr(self, 'friday_reminder_enabled')
            else reminders["friday_reminder"]["enabled"]
        )
        reminders["friday_reminder"]["time_hour"] = int(self.friday_reminder_hours.value)
        reminders["friday_reminder"]["time_minute"] = int(self.friday_reminder_minutes.value)
        reminders["friday_reminder"]["time_ampm"] = self.friday_reminder_ampm.value
        set_saved_page_layout(reminders, self.page_layout.value)
        # حفظ رواية المصحف المختارة
        reminders["mushaf_riwaya"] = self.mushaf_riwaya.value
        save_reminders(reminders)
        self.close(True)

    def show_stats(self):
        # عرض إحصائيات القراءة من الشاشة الرئيسية
        if self.parent and hasattr(self.parent, "show_stats"):
            self.parent.show_stats()

    def cancel(self):
        # إلغاء التغييرات وإغلاق شاشة الإعدادات
        for x in self["config"].list:
            x[1].cancel()
        self.close(False)


class QuranReminderAutoStartScreen(Screen):
    # شاشة خفية (1x1 بكسل) تعمل في الخلفية لفحص التذكيرات بشكل دوري
    skin = '<screen position="0,0" size="1,1" />'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.timer = eTimer()
        self.timer.callback.append(self.checkReminderTime)
        self.timer.start(5000, True)

    def convert_12h_to_24h(self, hour, ampm):
        # تحويل الوقت من نظام 12 ساعة إلى 24 ساعة
        if ampm == "PM" and hour < 12:
            return hour + 12
        elif ampm == "AM" and hour == 12:
            return 0
        else:
            return hour

    def playSound(self, sound_path):
        # تشغيل صوت التذكير - يستخدم aplay المتاح على معظم صور Enigma2
        if os.path.exists(sound_path):
            try:
                os.system('aplay "' + sound_path + '" >/dev/null 2>&1 &')
            except Exception:
                pass
        else:
            print("[IqraaQuran ...] الملف غير موجود: " + str(sound_path))

    def checkReminderTime(self):
        # فحص وقت التذكيرات اليومي والجمعة وإظهارها عند الحاجة
        now = datetime.now()
        print("[IqraaQuran ...] Now: {}:{}".format(now.hour, now.minute))
        reminders = load_reminders()
        daily = reminders["daily_reminder"]
        if daily["enabled"]:
            hour = daily["time_hour"]
            minute = daily["time_minute"]
            ampm = daily["time_ampm"]
            hour_24 = self.convert_12h_to_24h(hour, ampm)
            print("[IqraaQuran ...] Target Time: {}:{}, Enabled: {}".format(
                hour_24, minute, daily['enabled']))
            today_str = now.strftime("%Y%m%d")
            if daily.get("last_reading", 0) != int(today_str):
                if now.hour == hour_24 and now.minute == minute:
                    self.playSound(os.path.join(Sound_PATH, 'Daily_reminder.wav'))
                    self.showDailyReminder()
                    daily["last_reading"] = int(today_str)
                    save_reminders(reminders)
        friday = reminders["friday_reminder"]
        if friday["enabled"] and now.weekday() == 4:
            today_str = int(now.strftime("%Y%m%d"))
            if friday.get("last_reminder", 0) != today_str:
                f_hour = self.convert_12h_to_24h(friday["time_hour"], friday["time_ampm"])
                if now.hour == f_hour and now.minute == friday["time_minute"]:
                    self.playSound(os.path.join(Sound_PATH, 'kahf_reminder.wav'))
                    self.showKahfReminder()
                    friday["last_reminder"] = today_str
                    save_reminders(reminders)
        # إعادة ضبط المؤقت للفحص التالي بعد 5 ثوانٍ
        self.timer.start(5000, True)

    def showDailyReminder(self):
        # عرض إشعار التذكير اليومي
        print("[IqraaQuran ...] Showing daily reminder!")
        Notifications.AddNotificationWithCallback(
            self.handleDailyReminderResponse,
            MessageBox,
            u"تذكير: حان وقت قراءة وردك اليومي من القرآن الكريم\nهل تريد بدء القراءة الآن؟",
            type=MessageBox.TYPE_YESNO
        )

    def handleDailyReminderResponse(self, answer):
        # معالجة رد المستخدم على التذكير اليومي
        if answer:
            print("[IqraaQuran ...] المستخدم وافق على فتح الورد اليومي")
            self.openQuranViewerAtDailyPage()
        else:
            print("[IqraaQuran ...] المستخدم رفض فتح الورد اليومي")

    def openQuranViewerAtDailyPage(self):
        # فتح عارض المصحف عند صفحة الورد اليومي
        try:
            from Plugins.Extensions.IqraaQuran.plugin import IqraaQuran
            start, end = self.get_daily_portion_by_juz()
            today = datetime.now().day
            juz_index = (today - 1) % 30
            juz_name = u"الجزء {}".format(juz_index + 1)
            message = u"الورد اليومي: {}\nمن صفحة {} إلى {}\nهل تريد البدء الآن؟".format(
                juz_name, start, end)
            Notifications.AddNotificationWithCallback(
                lambda answer, s=start: self._handle_portion_confirmation(answer, s),
                MessageBox,
                message,
                type=MessageBox.TYPE_YESNO
            )
        except Exception as e:
            print("[IqraaQuran ...] خطأ أثناء الحصول على الورد اليومي:", e)
            import traceback
            traceback.print_exc()

    def _handle_portion_confirmation(self, answer, start_page):
        # تأكيد فتح صفحة الورد اليومي - يستخدم SafeETimer بدلاً من eTimer المباشر
        if answer:
            try:
                from Plugins.Extensions.IqraaQuran.plugin import IqraaQuran
                # نستخدم SafeETimer (المُعرَّف في هذا الملف) لضمان التوافق
                self.viewer = self.session.open(IqraaQuran)
                self.update_timer = eTimer()
                self.update_timer.callback.append(self._update_page_callback)
                self.update_timer.start(500, True)
                self.target_page = start_page
            except Exception as e:
                print("[IqraaQuran ...] خطأ أثناء فتح العارض:", e)
                import traceback
                traceback.print_exc()

    def _update_page_callback(self):
        # تحديث الصفحة في عارض المصحف بعد فتحه
        try:
            if hasattr(self, 'viewer') and hasattr(self, 'target_page'):
                print("[IqraaQuran ...] جاري تحميل الصفحة {}".format(self.target_page))
                self.viewer.currentPage = self.target_page
                self.viewer.set_info_page(self.target_page)
                self.viewer.updateImages()
                self.viewer["leftImage"].show()
                self.viewer["rightImage"].show()
                self.viewer.instance.show()
                self.viewer.mark_daily_reading_done()
                print("[IqraaQuran ...] تم تحميل الصفحة {} بنجاح".format(self.target_page))
        except Exception as e:
            print("[IqraaQuran ...] خطأ أثناء تحديث الصفحة:", e)
            import traceback
            traceback.print_exc()
        finally:
            if hasattr(self, 'update_timer'):
                try:
                    self.update_timer.stop()
                except Exception:
                    pass
                del self.update_timer
            if hasattr(self, 'target_page'):
                del self.target_page

    def get_daily_portion_by_juz(self):
        # حساب صفحات الورد اليومي بناءً على اليوم الحالي
        try:
            juz_start_pages = [
                1, 22, 42, 62, 82, 102, 121, 142, 162, 182,
                201, 222, 242, 262, 282, 302, 322, 342, 362, 382,
                402, 422, 442, 462, 482, 502, 522, 542, 562, 582
            ]
            today = datetime.now().day
            juz_index = (today - 1) % 30
            start_page = juz_start_pages[juz_index]
            end_page = juz_start_pages[juz_index + 1] - 1 if juz_index < 29 else 604
            return (start_page, end_page)
        except Exception as e:
            print("[IqraaQuran] Error in get_daily_portion_by_juz: {}".format(str(e)))
            return (1, 20)

    def showKahfReminder(self):
        # عرض إشعار تذكير سورة الكهف يوم الجمعة
        from Tools import Notifications
        from Screens.MessageBox import MessageBox
        print("[IqraaQuran ...] Showing kahf reminder!")
        Notifications.AddNotificationWithCallback(
            self.handleKahfReminderResponse,
            MessageBox,
            u"تذكير: حان وقت قراءة وردك الإسبوعي لسورة الكهف من سنن يوم جمعة!\nهل تريد بدء قراءة سورة الكهف الآن؟",
            type=MessageBox.TYPE_YESNO,
            timeout=9
        )

    def handleKahfReminderResponse(self, answer):
        # معالجة رد المستخدم على تذكير الكهف
        if answer:
            print("[IqraaQuran ...] المستخدم وافق على فتح الكهف")
            self.openKahfPage()
        else:
            print("[IqraaQuran ...] المستخدم رفض فتح الكهف")

    def openKahfPage(self):
        # فتح عارض المصحف عند صفحة سورة الكهف
        try:
            from Plugins.Extensions.IqraaQuran.plugin import IqraaQuran
            kahf_page = 293
            self.viewer = self.session.open(IqraaQuran)
            # نستخدم SafeETimer (المُعرَّف في هذا الملف) لضمان التوافق
            self.update_timer = eTimer()
            self.update_timer.callback.append(self._update_kahf_page_callback)
            self.update_timer.start(500, True)
            self.target_page = kahf_page
        except Exception as e:
            print("[IqraaQuran ...] خطأ أثناء فتح سورة الكهف:", e)
            import traceback
            traceback.print_exc()

    def _update_kahf_page_callback(self):
        # تحديث عارض المصحف للانتقال إلى صفحة سورة الكهف
        try:
            if hasattr(self, 'viewer') and hasattr(self, 'target_page'):
                print("[IqraaQuran ...] جاري تحميل صفحة الكهف {}".format(self.target_page))
                self.viewer.currentPage = self.target_page
                self.viewer.set_info_page(self.target_page)
                self.viewer.updateImages()
                self.viewer["leftImage"].show()
                self.viewer["rightImage"].show()
                self.viewer.instance.show()
                self.viewer.mark_daily_reading_done()
                print("[IqraaQuran ...] تم تحميل صفحة الكهف {} بنجاح".format(self.target_page))
        except Exception as e:
            print("[IqraaQuran ...] خطأ أثناء تحديث صفحة الكهف:", e)
            import traceback
            traceback.print_exc()
        finally:
            if hasattr(self, 'update_timer'):
                try:
                    self.update_timer.stop()
                except Exception:
                    pass
                del self.update_timer
            if hasattr(self, 'target_page'):
                del self.target_page
