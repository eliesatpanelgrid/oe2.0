# -*- coding: utf-8 -*-
"""
بلجن عرض صفحات القرآن الكريم المطور محمد الصفطي 2026
"""
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from .screens import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.InfoBar import InfoBar
from Screens.Console import Console
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.ProgressBar import ProgressBar
from Components.config import config, ConfigSubsection, ConfigClock, ConfigYesNo, ConfigInteger, getConfigListEntry, ConfigSelection, ConfigText
from Components.ConfigList import ConfigListScreen
from Components.Sources.StaticText import StaticText
from enigma import ePicLoad, loadPic, loadPNG, gPixmapPtr, getDesktop, eServiceReference, iPlayableService, ePoint
from enigma import eTimer as _original_eTimer

# ─────────────────────────────────────────────────────────────────────────────
# SafeETimer: غلاف آمن لـ eTimer يدعم كلاً من .callback.append()
# و .timeout.connect() ليكون متوافقاً مع جميع صور Enigma2
# (DreamOS/Python 2 و open-source/Python 3)
# ─────────────────────────────────────────────────────────────────────────────
class SafeETimer(object):
    def __init__(self, *args, **kwargs):
        self._timer = _original_eTimer(*args, **kwargs)
        self._conns = []
    def __getattr__(self, name):
        return getattr(self._timer, name)
    def __setattr__(self, name, value):
        if name in ("_timer", "_conns"):
            super(SafeETimer, self).__setattr__(name, value)
        else:
            setattr(self._timer, name, value)
    @property
    def callback(self):
        class CallbackList(object):
            def __init__(self, outer):
                self.outer = outer
            def append(self, fn):
                try:
                    self.outer._timer.callback.append(fn)
                    return
                except AttributeError:
                    pass
                try:
                    conn = self.outer._timer.timeout.connect(fn)
                    self.outer._conns.append(conn)
                    return
                except AttributeError:
                    pass
                try:
                    self.outer._timer.timeout.get().append(fn)
                    return
                except AttributeError:
                    pass
        return CallbackList(self)
    @property
    def timeout(self):
        class TimeoutProxy(object):
            def __init__(self, timer):
                self.timer = timer
            def __getattr__(self, name):
                return getattr(self.timer._timer.timeout, name)
            def connect(self, fn):
                try:
                    conn = self.timer._timer.timeout.connect(fn)
                    self.timer._conns.append(conn)
                    return conn
                except AttributeError:
                    pass
                try:
                    self.timer._timer.timeout.get().append(fn)
                    return
                except AttributeError:
                    pass
                try:
                    self.timer._timer.callback.append(fn)
                    return
                except AttributeError:
                    pass
            @property
            def get(self):
                class Getter(object):
                    def __init__(self, outer):
                        self.outer = outer
                    def append(self, fn):
                        self.outer.connect(fn)
                return lambda: Getter(self)
        return TimeoutProxy(self)

# استبدال eTimer العالمي بالغلاف الآمن
eTimer = SafeETimer

# ─────────────────────────────────────────────────────────────────────────────
# استيرادات المكتبات القياسية
# ─────────────────────────────────────────────────────────────────────────────
from time import strftime
from datetime import datetime, timedelta
from collections import defaultdict
from Tools import Notifications
from Tools.BoundFunction import boundFunction
import time, os, tempfile, json, unicodedata, re, subprocess, threading, tarfile
import sys

# ─────────────────────────────────────────────────────────────────────────────
# كشف إصدار Python - PY2 لبايثون 2، PY3 لبايثون 3
# ─────────────────────────────────────────────────────────────────────────────
PY2 = sys.version_info[0] == 2
PY3 = not PY2

# عداد الصفحات المُنزَّلة (global)
QURAN_DOWNLOADED_COUNT = 0

# ─────────────────────────────────────────────────────────────────────────────
# كشف نوع الصورة: DreamOS أو open-source
# eEnv موجود فقط في DreamOS/Python 2؛ وجود apt-get بدون opkg يعني DreamOS أيضاً
# ─────────────────────────────────────────────────────────────────────────────
isDreamOS = False
try:
    from enigma import eEnv
    isDreamOS = True
except ImportError:
    if os.path.exists('/usr/bin/apt-get') and not os.path.exists('/usr/bin/opkg'):
        isDreamOS = True

def detect_openatv_image():
    # فحص ملفات النظام للتعرف على صورة OpenATV
    for path in ("/etc/issue", "/etc/image-version", "/etc/hostname"):
        try:
            if os.path.exists(path):
                with open(path, "rb") as f:
                    if b"openatv" in f.read().lower():
                        return True
        except Exception:
            pass
    return False

# ─────────────────────────────────────────────────────────────────────────────
# متغيرات كشف البيئة المجمَّعة - تُستخدم في جميع أنحاء الكود
# ─────────────────────────────────────────────────────────────────────────────
IS_DREAMOS_PY2 = PY2 and isDreamOS
IS_OPEN_SOURCE_PY3 = PY3
IS_OPENATV_PY3 = PY3 and detect_openatv_image()

# ─────────────────────────────────────────────────────────────────────────────
# قراءة ألوان الإسكين الفعلي - للتوافق الديناميكي مع جميع الإسكينات
# إذا لم يكن الإسكين يوفر اللون، يُستخدم "background" كقيمة آمنة
# ─────────────────────────────────────────────────────────────────────────────
try:
    from skin import colorNames as _skin_color_names
except Exception:
    _skin_color_names = {}

def skin_selection_background():
    # البحث عن اسم لون شريط التظليل في الإسكين المفعَّل
    for name in ("ListboxSelectedBackground", "listboxSelectedBackground",
                 "selectionBackground", "selectedBackground",
                 "ListboxMarkedBackground", "listboxMarkedBackground"):
        try:
            if name in _skin_color_names:
                return name
        except Exception:
            pass
    return "background"

SKIN_SELECTION_BACKGROUND = skin_selection_background()
# لون التظليل في DreamOS - يُستمد من الإسكين إن أمكن
DREAMOS_SOFT_HIGHLIGHT_BACKGROUND = SKIN_SELECTION_BACKGROUND

# ─────────────────────────────────────────────────────────────────────────────
# دوال التحويل النصي - متوافقة مع Python 2 و 3
# ─────────────────────────────────────────────────────────────────────────────
def to_unicode(text):
    # تحويل النص إلى unicode في كلا الإصدارين
    if PY2:
        if isinstance(text, str):
            return text.decode('utf-8')
        return text
    else:
        if isinstance(text, bytes):
            return text.decode('utf-8')
        return text

def to_utf8(text):
    # تحويل النص إلى UTF-8 لبايثون 2، أو إرجاع str مباشرةً في بايثون 3
    if PY2:
        if isinstance(text, unicode):
            return text.encode('utf-8')
        return text
    else:
        if isinstance(text, bytes):
            return text.decode('utf-8')
        return text

def to_enigma_string(text):
    # تهيئة النص ليكون مقبولاً في واجهة Enigma2 على كلا الإصدارين
    if PY2:
        if isinstance(text, unicode):
            return text.encode('utf-8')
        return text
    else:
        if isinstance(text, bytes):
            return text.decode('utf-8')
        return text

def safe_menulist_index(widget, total=0):
    # قراءة فهرس العنصر المحدد بشكل آمن من MenuList
    try:
        index = widget.getSelectedIndex()
    except Exception:
        return 0
    try:
        index = int(index)
    except Exception:
        index = 0
    if total:
        if index < 0:
            index = 0
        elif index >= total:
            index = total - 1
    return index

def arabic_menu_pad(count=22):
    # حشو نصي للقوائم العربية - الفراغ العادي متوافق مع جميع الإصدارات
    # في Python 3 (open-source) نُرجع سلسلة فارغة لأن التخطيط مختلف
    if IS_OPEN_SOURCE_PY3:
        return u""
    # في Python 2: نستخدم المسافة العادية - \xc2\xa0 أحياناً تسبب تشويهاً
    if PY2:
        return u" " * count
    return u" " * count

def strip_enigma_color(text):
    # إزالة رموز الألوان من النص لعرضه بشكل نظيف
    text = to_unicode(text)
    return re.sub(r'\\c[0-9a-fA-F]{8}', '', text).strip()

def left_column_text(text, width=44):
    # محاذاة النص في العمود الأيسر - ضرورية لعرض DreamOS
    text = strip_enigma_color(text)
    if IS_DREAMOS_PY2:
        return text.ljust(width)
    return text

def crop_text(text, max_chars):
    # اقتطاع النص إذا تجاوز الحد الأقصى للأحرف
    text = strip_enigma_color(text)
    if len(text) > max_chars:
        return text[:max_chars - 1] + "."
    return text

def leading_number(text):
    # استخراج الرقم الابتدائي من النص لأغراض الترتيب
    match = re.match(r'\s*(\d+)', strip_enigma_color(text))
    return int(match.group(1)) if match else 999

def reciter_group_from_url(url):
    # تصنيف القارئ حسب رابط URL الخاص به
    url = (url or "").lower()
    if not url:
        return 99
    if "mojawwad" in url:
        return 2
    if "mo-lim" in url or "3zazi" in url or "bari" in url:
        return 3
    if ("rewayat-warsh" in url or "omar_warsh" in url or "koshi" in url
            or "/qari/" in url or "rewayat-assosi" in url
            or "rewayat-khalaf" in url or "abdullah/" in url):
        return 1
    return 0

def text_has_any(text, markers):
    # فحص وجود أي من الكلمات المحددة في النص
    text = strip_enigma_color(text)
    for marker in markers:
        if to_unicode(marker) in text:
            return True
    return False

def reciter_group_from_text(text):
    # تصنيف القارئ حسب النص (المجود، المعلم، الروايات)
    if text_has_any(text, (u"مجود",)):
        return 2
    if text_has_any(text, (u"معلم",)):
        return 3
    if text_has_any(text, (u"ورش", u"السوسي", u"خلف", u"البزي", u"قنبل")):
        return 1
    return None

def reciter_header_group(text):
    # تصنيف عناوين مجموعات القراء لأغراض الترتيب
    text = strip_enigma_color(text)
    if u"حفص" in text:
        return 0
    if u"مج" in text:
        return 2
    if u"مصحف" in text or u"معلم" in text:
        return 3
    if u"رواي" in text:
        return 1
    return 99

def reciter_sort_key(item):
    # مفتاح ترتيب القراء: حسب المجموعة ثم الرقم ثم الاسم
    key, info = item
    url = info.get("url", "")
    if not url:
        return (reciter_header_group(key), -1, key)
    text_group = reciter_group_from_text(key)
    group = text_group if text_group is not None else reciter_group_from_url(url)
    return (group, leading_number(key), key)

def ordered_reciter_keys(reciters_data):
    # إرجاع مفاتيح القراء مرتبة حسب المجموعة
    return [key for key, info in sorted(reciters_data.items(), key=reciter_sort_key)]

def enigma_colored_text(text, color_code):
    # إضافة رمز لون Enigma2 للنص - فقط في Python 3 (open-source)
    if IS_OPEN_SOURCE_PY3:
        return color_code + text
    return text

# ─────────────────────────────────────────────────────────────────────────────
# io.open - دعم open مع encoding في Python 2 و 3
# ─────────────────────────────────────────────────────────────────────────────
from io import open as io_open

# ─────────────────────────────────────────────────────────────────────────────
# urllib - متوافق مع Python 2 و 3
# في Python 3: urllib.request / urllib.error
# في Python 2: urllib2
# ─────────────────────────────────────────────────────────────────────────────
try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError, HTTPError
except ImportError:
    from urllib2 import urlopen, Request, URLError, HTTPError

# ─────────────────────────────────────────────────────────────────────────────
# MoviePlayer - مسارات مختلفة حسب الصورة، نجرب كليهما
# ─────────────────────────────────────────────────────────────────────────────
try:
    from Screens.InfoBar import MoviePlayer
except ImportError:
    try:
        from Screens.MoviePlayer import MoviePlayer
    except ImportError:
        MoviePlayer = None

# ─────────────────────────────────────────────────────────────────────────────
# مقارنة الإصدارات - بدون مكتبات خارجية (متوافق مع Python 2 و 3)
# ─────────────────────────────────────────────────────────────────────────────
def _parse_ver(v):
    try:
        return [int(x) for x in str(v).strip().split(".")]
    except Exception:
        return [0]

class _Version(object):
    def __init__(self, v):
        self._p = _parse_ver(v)
    def __gt__(self, o):
        other_p = o._p if isinstance(o, _Version) else _parse_ver(str(o))
        return self._p > other_p
    def __eq__(self, o):
        other_p = o._p if isinstance(o, _Version) else _parse_ver(str(o))
        return self._p == other_p

def parse_version(v):
    return _Version(v)

# ─────────────────────────────────────────────────────────────────────────────
# _subprocess_run - متوافق مع Python 2 و 3
# subprocess.run غير موجود في Python 2، نستخدم subprocess.call بدلاً منه
# ─────────────────────────────────────────────────────────────────────────────
def _subprocess_run(args, **kw):
    run = getattr(subprocess, "run", None)
    if run is not None:
        return run(args, **kw)
    else:
        check = kw.pop("check", False)
        kw.pop("capture_output", None)
        ret = subprocess.call(args, **kw)
        if check and ret != 0:
            raise subprocess.CalledProcessError(ret, args)
        return ret

# ─────────────────────────────────────────────────────────────────────────────
# _fetch_url - تنزيل URL وإرجاع (status_code, text) - بدون مكتبة requests
# ─────────────────────────────────────────────────────────────────────────────
def _fetch_url(url, timeout=5):
    """تنزيل URL وإرجاع (status_code, text)"""
    try:
        req = Request(url, headers={"User-Agent": "IqraaQuran/1.3"})
        resp = urlopen(req, timeout=timeout)
        raw = resp.read()
        try:
            text = raw.decode("utf-8")
        except Exception:
            text = raw.decode("latin-1")
        return 200, text
    except HTTPError as e:
        return e.code, ""
    except Exception:
        return 0, ""

####################################################  اسم البلجن والإصدار ####################################################
Plugin_version = "1.3"
Plugin_name = "Iqraa Quran"
QURAN_REPO_RAW = "https://raw.githubusercontent.com/angelheart150/IqraaQuran/main"
QURAN_ARCHIVES = {
    "hafs": "hafs.tar.gz",
    "warsh": "warsh.tar.gz",
}
####################################################  تهيئة المسارات ####################################################
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/IqraaQuran"
Images_PATH = os.path.join(PLUGIN_PATH, "images")
Sound_PATH = os.path.join(PLUGIN_PATH, "sounds")
Buttons_PATH = os.path.join(PLUGIN_PATH, "buttons")
REMINDERS_FILE = os.path.join(PLUGIN_PATH, "Reminders.json")
KEYMAP_PATH = os.path.join(PLUGIN_PATH, "keymap.xml")

# ─────────────────────────────────────────────────────────────────────────────
# تحميل خريطة المفاتيح مرة واحدة فقط لتجنب التكرار
# ─────────────────────────────────────────────────────────────────────────────
_IQRAA_KEYMAP_LOADED = False

def load_plugin_keymap():
    # تحميل keymap.xml الخاص بالبلاجين - يُستدعى مرة واحدة فقط
    global _IQRAA_KEYMAP_LOADED
    try:
        if _IQRAA_KEYMAP_LOADED:
            return
        if os.path.exists(KEYMAP_PATH):
            from keymapparser import readKeymap
            readKeymap(KEYMAP_PATH)
            _IQRAA_KEYMAP_LOADED = True
            print("[IqraaQuran] keymap.xml loaded successfully")
    except Exception as e:
        print("[IqraaQuran] Could not load keymap.xml:", e)

def read_plugin_version(default="1.3"):
    # قراءة إصدار البلاجين من ملف ver.txt
    try:
        for filename in ("ver.txt", "Ver.txt"):
            version_path = os.path.join(PLUGIN_PATH, filename)
            if os.path.exists(version_path):
                with open(version_path, "rb") as f:
                    value = f.read().decode("utf-8").strip()
                    if value:
                        return value
    except Exception as e:
        print("[IqraaQuran] Could not read version file:", e)
    return default

Plugin_version = read_plugin_version(Plugin_version)
__all__ = ['clean_arabic_text']

QURAN_INDEX = defaultdict(list)
index_path = os.path.join(PLUGIN_PATH, 'quran_index.json')
generate_script = os.path.join(PLUGIN_PATH, 'generate_index.py')

# تحميل keymap عند بدء التشغيل
load_plugin_keymap()

####################################################
# دالة مساعدة لتنظيف النص العربي
####################################################
def clean_arabic_text(word):
    # تنظيف النص العربي من التشكيل والحروف الإضافية لتوحيد البحث
    word = to_unicode(word)
    replacements = {
        u'ى': u'ي', u'ة': u'ه', u'إ': u'ا', u'أ': u'ا',
        u'آ': u'ا', u'ؤ': u'و', u'ئ': u'ي', u'ـ': u''
    }
    try:
        cleaned = unicodedata.normalize('NFKD', word)
        cleaned = u''.join([c for c in cleaned if not unicodedata.combining(c)])
        cleaned = u''.join([replacements.get(c, c) for c in cleaned])
        if PY2:
            # في Python 2 نستخدم translate مع dict من unicode ordinals
            remove_chars = {ord(c): None for c in u'،.:؛!؟؟،ْ'}
            return cleaned.translate(remove_chars)
        else:
            # في Python 3 نستخدم str.maketrans مباشرة
            return cleaned.translate(str.maketrans('', '', u'،.:؛!؟؟،ْ'))
    except Exception:
        return word

####################################################
def load_json_file(file_path, default_data):
    # تحميل ملف JSON بشكل آمن متوافق مع Python 2 و 3
    if os.path.exists(file_path):
        try:
            with open(file_path, "rb") as f:
                data = f.read()
                return json.loads(data.decode("utf-8"))
        except Exception as e:
            print("[IqraaQuran] Error loading json:", str(e))
            return default_data
    else:
        save_json_file(file_path, default_data)
        return default_data

def save_json_file(file_path, data):
    # حفظ بيانات JSON بترميز UTF-8 متوافق مع Python 2 و 3
    try:
        serialized = json.dumps(data, indent=4, ensure_ascii=False)
        # في كلا الإصدارين نحوّل إلى bytes قبل الكتابة
        if PY2 and isinstance(serialized, unicode):
            serialized = serialized.encode("utf-8")
        elif PY3 and isinstance(serialized, str):
            serialized = serialized.encode("utf-8")
        with open(file_path, "wb") as f:
            f.write(serialized)
    except Exception as e:
        print("[IqraaQuran] Error saving json:", str(e))

reminders_default = {
    "daily_reminder": {"enabled": False, "time_hour": 8, "time_minute": 0, "time_ampm": "AM", "last_reading": 0},
    "friday_reminder": {"enabled": True, "time_hour": 10, "time_minute": 0, "time_ampm": "AM", "last_reminder": 0},
    "page_layout": "double",
    "last_page_layout": "double"
}

def normalize_page_layout(value):
    # التحقق من صحة قيمة تخطيط الصفحة
    if value in ("double", "single"):
        return value
    return "double"

def get_saved_page_layout(reminders):
    # استرجاع تخطيط الصفحة المحفوظ من ملف الإعدادات
    if not isinstance(reminders, dict):
        return "double"
    return normalize_page_layout(reminders.get("last_page_layout", "double"))

def set_saved_page_layout(reminders, layout):
    # تحديث تخطيط الصفحة في قاموس الإعدادات
    if not isinstance(reminders, dict):
        reminders = {}
    layout = normalize_page_layout(layout)
    reminders["page_layout"] = layout
    reminders["last_page_layout"] = layout
    return reminders

def load_reminders():
    # تحميل ملف التذكيرات مع ضمان وجود قيمة صحيحة لتخطيط الصفحة
    reminders = load_json_file(REMINDERS_FILE, reminders_default)
    return set_saved_page_layout(reminders, get_saved_page_layout(reminders))

def save_reminders(reminders):
    # حفظ التذكيرات في الملف
    save_json_file(REMINDERS_FILE, reminders)
    print("Reminders saved to Reminders.json")

# ─────────────────────────────────────────────────────────────────────────────
# استيراد الشاشات من screens.py - يُجرَّب الاستيراد النسبي أولاً ثم المطلق
# لضمان التوافق مع DreamOS/Python 2 والصور المفتوحة
# ─────────────────────────────────────────────────────────────────────────────
try:
    from .screens import (PluginInfoScreen, PageInputScreen, QuranStatsScreen,
                          DownloadProgressScreen, QuranSearchScreen,
                          AudioControlAndReciterScreen, QuranSettings,
                          QuranReminderAutoStartScreen)
except ImportError:
    from screens import (PluginInfoScreen, PageInputScreen, QuranStatsScreen,
                         DownloadProgressScreen, QuranSearchScreen,
                         AudioControlAndReciterScreen, QuranSettings,
                         QuranReminderAutoStartScreen)

# ─────────────────────────────────────────────────────────────────────────────
# دوال التنزيل
# ─────────────────────────────────────────────────────────────────────────────
def _download_url_to_file(url, dest_path, timeout=90):
    # تنزيل ملف من URL وحفظه في المسار المحدد بشكل آمن (يستخدم ملف مؤقت)
    tmp_path = dest_path + ".tmp"
    try:
        req = Request(url, headers={"User-Agent": "IqraaQuran/1.3"})
        resp = urlopen(req, timeout=timeout)
        with open(tmp_path, "wb") as out:
            while True:
                chunk = resp.read(1024 * 64)
                if not chunk:
                    break
                out.write(chunk)
        if os.path.exists(dest_path):
            try:
                os.remove(dest_path)
            except Exception:
                pass
        os.rename(tmp_path, dest_path)
        return True
    except Exception as e:
        print("[IqraaQuran] Download failed {}: {}".format(url, e))
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        return False

def _download_repo_file(filename, dest_path, timeout=90):
    # تنزيل ملف من مستودع GitHub الخاص بالبلاجين
    return _download_url_to_file("{}/{}".format(QURAN_REPO_RAW, filename), dest_path, timeout=timeout)

####################################################  شاشة التحديث  ####################################################
def check_for_update(session):
    # فحص التحديثات من GitHub ومطالبة المستخدم بالتحديث إذا توفر إصدار أحدث
    try:
        reminders = load_reminders()
        if not reminders.get("auto_update", True):
            session.open(IqraaQuran)
            return
        version_url = "https://raw.githubusercontent.com/angelheart150/IqraaQuran/main/version"
        changelog_url = "https://raw.githubusercontent.com/angelheart150/IqraaQuran/main/changelog.txt"
        version_status, version_text = _fetch_url(version_url, timeout=5)
        version_res_ok = (version_status == 200)
        changelog_status, changelog_text = _fetch_url(changelog_url, timeout=5)
        if version_res_ok:
            remote_version = (version_text.strip().split('"')[1]
                              if 'CURRENT_VERSION' in version_text
                              else version_text.strip())
            local_version = Plugin_version
            if not remote_version or not local_version:
                session.open(IqraaQuran)
                return
            remote_v = parse_version(remote_version)
            local_v = parse_version(local_version)
            if remote_v > local_v:
                changelog = changelog_text.strip() if changelog_status == 200 else "No Remarks"
                msg = ("There is a new version of IqraaQuran available!\n\n"
                       "Installed version: {}\nNew version: {}\n\n{}").format(
                    local_version, remote_version, changelog)
                def update_callback(answer):
                    if answer:
                        url = ("wget -q --no-check-certificate "
                               "https://raw.githubusercontent.com/angelheart150/IqraaQuran/main/installer.sh"
                               " -O - | /bin/sh")
                        session.open(Console, title="Update IqraaQuran", cmdlist=[url])
                    else:
                        session.open(IqraaQuran)
                session.openWithCallback(update_callback, MessageBox, msg,
                                         MessageBox.TYPE_YESNO, default=False)
                return
            else:
                print("[IqraaQuran] No update needed: installed ({}) >= remote ({})".format(
                    local_version, remote_version))
    except Exception as e:
        print("[IqraaQuran] فشل التحقق من التحديث:", str(e))
    session.open(IqraaQuran)

####################################################  شاشة معلومات البلجن  ####################################################
class DreamboxCenteredExitPopup(Screen):
    # نافذة تأكيد الخروج مركزية - خاصة بـ DreamOS لتحسين المظهر
    skin = """
        <screen name="DreamboxCenteredExitPopup" position="center,center" size="760,260" title="" flags="wfNoBorder">
            <eLabel position="0,0" size="760,260" backgroundColor="#101010" zPosition="-2" />
            <eLabel position="6,6" size="748,248" backgroundColor="#2f3a40" zPosition="-1" />
            <widget name="message" position="25,35" size="710,190" font="Regular;31" halign="center" valign="center" transparent="1" />
        </screen>"""

    def __init__(self, session, message, timeout=1):
        Screen.__init__(self, session)
        self["message"] = Label(to_enigma_string(message))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.close_now,
            "cancel": self.close_now,
            "red": self.close_now,
        }, -1)
        self.timer = eTimer()
        self.timer.callback.append(self.close_now)
        self.timer.start(int(timeout * 1000), True)

    def close_now(self):
        try:
            if self.timer.isActive():
                self.timer.stop()
        except Exception:
            pass
        self.close(True)

class IqraaQuran(Screen):
    # ─────────────────────────────────────────────────────────────────────────
    # تحديد سكين قوائم السور والأجزاء والصورة المركزية حسب نوع الصورة/Python
    # OpenATV Python 3: يدعم الألوان والخطوط الكاملة
    # DreamOS Python 2: بدون ألوان مخصصة لأن النظام لا يدعمها
    # غير ذلك: نفس إعدادات OpenATV
    # ─────────────────────────────────────────────────────────────────────────
    if IS_OPENATV_PY3:
        _surah_list_skin = ('<widget name="surah_list" position="1625,92" size="263,840"'
                            ' scrollbarMode="showAlways" transparent="1" font="Regular;36"'
                            ' itemHeight="42" foregroundColor="#ffffff" foregroundColorSelected="#ffffff"'
                            ' backgroundColor="#101010" backgroundColorSelected="#2f3a40" />')
        _juz_list_skin = ('<widget name="juz_list" position="30,90" size="263,840"'
                          ' scrollbarMode="showAlways" transparent="1" font="Regular;36"'
                          ' itemHeight="42" foregroundColor="#ffffff" foregroundColorSelected="#ffffff"'
                          ' backgroundColor="#101010" backgroundColorSelected="#2f3a40" />')
        _center_image_skin = ('<widget name="centerImage" position="253,90"'
                              ' size="1400,860" alphatest="on" />')
    elif IS_DREAMOS_PY2:
        # DreamOS Python 2: بدون تخصيص ألوان - يُورَث من الإسكين الحالي
        _surah_list_skin = ('<widget name="surah_list" position="1625,92" size="263,840"'
                            ' scrollbarMode="showAlways" transparent="1" />')
        _juz_list_skin = ('<widget name="juz_list" position="30,90" size="263,840"'
                          ' scrollbarMode="showAlways" transparent="1" />')
        _center_image_skin = ('<widget name="centerImage" position="253,90"'
                              ' size="1400,860" alphatest="on" />')
    else:
        # صور Python 3 الأخرى (VTi, Black Hole, إلخ)
        _surah_list_skin = ('<widget name="surah_list" position="1625,92" size="263,840"'
                            ' scrollbarMode="showAlways" transparent="1" font="Regular;36"'
                            ' itemHeight="42" foregroundColor="#ffffff" foregroundColorSelected="#ffffff"'
                            ' backgroundColor="#101010" backgroundColorSelected="#2f3a40" />')
        _juz_list_skin = ('<widget name="juz_list" position="30,90" size="263,840"'
                          ' scrollbarMode="showAlways" transparent="1" font="Regular;36"'
                          ' itemHeight="42" foregroundColor="#ffffff" foregroundColorSelected="#ffffff"'
                          ' backgroundColor="#101010" backgroundColorSelected="#2f3a40" />')
        _center_image_skin = ('<widget name="centerImage" position="253,90"'
                              ' size="1400,860" alphatest="on" />')

    skin = """
        <screen name="IqraaQuran" position="0,-1" size="1920,1080" title="" flags="wfNoBorder">
           <!-- معلومات البلجن -->
           <widget name="pluginInfo" position="17,5" size="560,40" font="Regular;32" valign="center" transparent="1" />
           <!-- معلومات الصفحة -->
           <widget name="infoLabel" position="445,5" size="650,40" font="Regular;32" halign="center" valign="center" transparent="1" />
           <widget name="surahJuzLabel" position="501,44" size="398,39" font="Regular;32" halign="center" valign="center" transparent="1" />
           <!-- خلفية الشاشة -->
           <ePixmap position="0,0" zPosition="-1" size="1911,1080" pixmap="{Images_PATH}/bg.png" />
           <!-- شريط المعلومات العلوي الموحد -->
           <!-- الوقت والتاريخ -->
           <widget name="time_date" position="1195,5" size="720,40" font="Regular;32" halign="center" valign="center" transparent="1" />
           <widget name="hijri_date" position="1390,45" size="524,35" font="Regular;28" transparent="1" halign="center" />
           <!-- قوائم السور والأجزاء -->
           {surah_list_skin}
           {juz_list_skin}
           <widget name="play_icon" pixmap="{Images_PATH}/play.png" position="464,18" size="60,60" transparent="1" alphatest="on" />
           <!-- الصور -->
           <widget name="rightImage" position="953,90" size="660,860" alphatest="on" />
           <widget name="leftImage" position="293,90" size="660,860" alphatest="on" />
           {center_image_skin}
           <!-- أرقام الصفحات -->
           <widget name="pageLabelLeft" position="31,950" size="266,58" font="Regular;30" halign="right" transparent="1" />
           <widget name="pageLabelRight" position="1613,950" size="266,58" font="Regular;30" halign="left" transparent="1" />
           <!-- أزرار التحكم السفلية -->
           <eLabel position="310,1000" size="1300,65" backgroundColor="#300000" zPosition="-1" />
           <ePixmap pixmap="{Buttons_PATH}/red.png" position="325,1008" size="230,48" alphatest="on" />
           <widget name="main_red_action_label" position="325,1008" size="230,48" zPosition="1" font="Regular;27" halign="center" valign="center" transparent="1" />
           <ePixmap pixmap="{Buttons_PATH}/green.png" position="580,1008" size="230,48" alphatest="on" />
           <widget name="main_green_action_label" position="580,1008" size="230,48" zPosition="1" font="Regular;27" foregroundColor="#000000" halign="center" valign="center" transparent="1" />
           <ePixmap pixmap="{Buttons_PATH}/yellow.png" position="835,1008" size="230,48" alphatest="on" />
           <widget name="main_yellow_action_label" position="835,1008" size="230,48" zPosition="1" font="Regular;27" foregroundColor="#000000" halign="center" valign="center" transparent="1" />
           <ePixmap pixmap="{Buttons_PATH}/blue.png" position="1090,1008" size="230,48" alphatest="on" />
           <widget name="main_blue_action_label" position="1090,1008" size="230,48" zPosition="1" font="Regular;27" halign="center" valign="center" transparent="1" />
           <ePixmap pixmap="{Buttons_PATH}/menu.png" position="1345,1008" size="230,48" alphatest="on" />
           <widget name="main_menu_action_label" position="1345,1008" size="230,48" zPosition="1" font="Regular;27" foregroundColor="#000000" halign="center" valign="center" transparent="1" />
           <!-- تسميات الأزرار -->
           <widget name="key_red_label" position="26,45" size="279,50" font="Regular;38" halign="center" valign="center" transparent="1" text="فهرس الأجزاء" />
           <widget name="key_blue_label" position="1615,45" size="279,50" font="Regular;38" halign="center" valign="center" transparent="1" text="فهرس السور" />
           <widget name="key_yellow_label" position="900,20" size="192,50" font="Regular;40" halign="center" valign="center" transparent="1" />
           <widget name="key_epg_label" position="1106,20" size="259,50" font="Regular;40" halign="center" valign="center" transparent="1" />
           <widget name="statusLabel" position="center,520" size="900,60" font="Regular;30" halign="center" valign="center" transparent="1" zPosition="5" />
           <widget name="key_0_label" position="600,947" size="300,50" font="Regular;30" halign="center" valign="center" transparent="1" />
        </screen>""".format(
        Images_PATH=Images_PATH,
        Buttons_PATH=Buttons_PATH,
        surah_list_skin=_surah_list_skin,
        juz_list_skin=_juz_list_skin,
        center_image_skin=_center_image_skin
    )

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setTitle("")
        self.playSound(os.path.join(Sound_PATH, 'intro.wav'))
        self.REMINDERS_FILE = os.path.join(PLUGIN_PATH, "Reminders.json")
        self.picPath = "/media/hdd/quran_pages"
        self.totalPages = 604
        self.currentPage = 1
        self.pageInput = ""
        self.activeList = None
        self.inputMode = False
        self.showingSelectionMessage = False
        self._screen_closing = False

        # ─────────────────────────────────────────────────────────────────────
        # تهيئة محمّلات الصور - يدعم كلاً من .connect() و .get().append()
        # ─────────────────────────────────────────────────────────────────────
        self.picload_left = ePicLoad()
        self.picload_right = ePicLoad()
        self.picload_center = ePicLoad()
        self.picload_conns = []
        try:
            self.picload_conns.append(self.picload_left.PictureData.connect(self.setLeftImage))
        except AttributeError:
            self.picload_left.PictureData.get().append(self.setLeftImage)
        try:
            self.picload_conns.append(self.picload_right.PictureData.connect(self.setRightImage))
        except AttributeError:
            self.picload_right.PictureData.get().append(self.setRightImage)
        try:
            self.picload_conns.append(self.picload_center.PictureData.connect(self.setCenterImage))
        except AttributeError:
            self.picload_center.PictureData.get().append(self.setCenterImage)

        # تهيئة عناصر الواجهة
        self["pluginInfo"] = Label(to_enigma_string("{} Ver {}".format(Plugin_name, Plugin_version)))
        self["infoLabel"] = Label()
        self["surahJuzLabel"] = Label()
        self["statusLabel"] = Label("")
        self["time_date"] = Label("")
        self["hijri_date"] = Label("")
        self["pageLabelLeft"] = Label("")
        self["pageLabelRight"] = Label("")
        self["play_icon"] = Pixmap()
        self["leftImage"] = Pixmap()
        self["rightImage"] = Pixmap()
        self["centerImage"] = Pixmap()
        self["key_red_label"] = Label(to_enigma_string(u"فهرس الأجزاء"))
        self["key_blue_label"] = Label(to_enigma_string(u"فهرس السور"))
        self["key_0_label"] = Label("")
        self["key_yellow_label"] = Label("")
        self["key_epg_label"] = Label("")
        self["main_red_action_label"] = Label(to_enigma_string(u"البحث"))
        self["main_green_action_label"] = Label(to_enigma_string(u"التلاوة"))
        self["main_yellow_action_label"] = Label(to_enigma_string(u"الأجزاء"))
        self["main_blue_action_label"] = Label(to_enigma_string(u"السور"))
        self["main_menu_action_label"] = Label(to_enigma_string(u"الإعدادات"))

        # قائمة السور مع أرقام صفحاتها
        self.suraList = [
            (u"الفاتحة", 1), (u"البقرة", 2), (u"آل عمران", 50), (u"النساء", 77),
            (u"المائدة", 106), (u"الأنعام", 128), (u"الأعراف", 151), (u"الأنفال", 177),
            (u"التوبة", 187), (u"يونس", 208), (u"هود", 221), (u"يوسف", 235),
            (u"الرعد", 249), (u"إبراهيم", 255), (u"الحجر", 262), (u"النحل", 267),
            (u"الإسراء", 282), (u"الكهف", 293), (u"مريم", 305), (u"طه", 312),
            (u"الأنبياء", 322), (u"الحج", 332), (u"المؤمنون", 342), (u"النور", 350),
            (u"الفرقان", 359), (u"الشعراء", 367), (u"النمل", 377), (u"القصص", 385),
            (u"العنكبوت", 396), (u"الروم", 404), (u"لقمان", 411), (u"السجدة", 415),
            (u"الأحزاب", 418), (u"سبأ", 428), (u"فاطر", 434), (u"يس", 440),
            (u"الصافات", 446), (u"ص", 453), (u"الزمر", 458), (u"غافر", 467),
            (u"فصلت", 477), (u"الشورى", 483), (u"الزخرف", 489), (u"الدخان", 496),
            (u"الجاثية", 499), (u"الأحقاف", 502), (u"محمد", 507), (u"الفتح", 511),
            (u"الحجرات", 515), (u"ق", 518), (u"الذاريات", 520), (u"الطور", 523),
            (u"النجم", 526), (u"القمر", 528), (u"الرحمن", 531), (u"الواقعة", 534),
            (u"الحديد", 537), (u"المجادلة", 542), (u"الحشر", 545), (u"الممتحنة", 549),
            (u"الصف", 551), (u"الجمعة", 553), (u"المنافقون", 554), (u"التغابن", 556),
            (u"الطلاق", 558), (u"التحريم", 560), (u"الملك", 562), (u"القلم", 564),
            (u"الحاقة", 566), (u"المعارج", 568), (u"نوح", 570), (u"الجن", 572),
            (u"المزمل", 574), (u"المدثر", 575), (u"القيامة", 577), (u"الإنسان", 578),
            (u"المرسلات", 580), (u"النبأ", 582), (u"النازعات", 583), (u"عبس", 585),
            (u"التكوير", 586), (u"الانفطار", 587), (u"المطففين", 587), (u"الانشقاق", 589),
            (u"البروج", 590), (u"الطارق", 591), (u"الأعلى", 591), (u"الغاشية", 592),
            (u"الفجر", 593), (u"البلد", 594), (u"الشمس", 595), (u"الليل", 595),
            (u"الضحى", 596), (u"الشرح", 596), (u"التين", 597), (u"العلق", 597),
            (u"القدر", 598), (u"البينة", 598), (u"الزلزلة", 599), (u"العاديات", 599),
            (u"القارعة", 600), (u"التكاثر", 600), (u"العصر", 601), (u"الهمزة", 601),
            (u"الفيل", 601), (u"قريش", 602), (u"الماعون", 602), (u"الكوثر", 602),
            (u"الكافرون", 603), (u"النصر", 603), (u"المسد", 603), (u"الإخلاص", 604),
            (u"الفلق", 604), (u"الناس", 604),
        ]

        # قائمة الأجزاء مع أرقام صفحاتها الابتدائية
        self.juzList = [(u"الجزء {}".format(i + 1), page) for i, page in enumerate([
            1, 22, 42, 62, 82, 102, 121, 142, 162, 182,
            201, 222, 242, 262, 282, 302, 322, 342, 362, 382,
            402, 422, 442, 462, 482, 502, 522, 542, 562, 582
        ])]

        self.surah_names_simple = [s[0] for s in self.suraList]  # For AudioControlScreen
        self.reciters_data = {  # For AudioControlScreen
            u"=========== روايـــة حفص عن عــاصم ===========": {"url": "", "count": 0},
            u"01- محمود خليل الحصري (مرتل - برواية حفص)": {"url": "https://server13.mp3quran.net/husr/", "count": 114},
            u"02 - محمد صديق المنشاوي  (مرتل - برواية حفص)": {"url": "https://server10.mp3quran.net/minsh/", "count": 114},
            u"03 - محمد أيوب (مرتل - مميز)": {"url": "https://server16.mp3quran.net/ayyoub2/Rewayat-Hafs-A-n-Assem/", "count": 114},
            u"04 - مصطفي اسماعيل (مرتل - برواية حفص)": {"url": "https://server8.mp3quran.net/mustafa/", "count": 114},
            u"05 - عبدالباسط عبدالصمد (مرتل - برواية حفص)": {"url": "https://server7.mp3quran.net/basit/", "count": 114},
            u"06 - محمود علي البنا (مرتل - برواية حفص)": {"url": "https://server8.mp3quran.net/bna/", "count": 114},
            u"07 - مشاري العفاسي (مرتل - برواية حفص)": {"url": "https://server8.mp3quran.net/afs/", "count": 114},
            u"08 - علي الحذيفي (مرتل - برواية حفص)": {"url": "https://server9.mp3quran.net/hthfi/", "count": 114},
            u"09 - سعود الشريم (مرتل - برواية حفص)": {"url": "https://server7.mp3quran.net/shur/", "count": 114},
            u"10- عبد الرحمن السديس  (مرتل - برواية حفص)": {"url": "https://server11.mp3quran.net/sds/", "count": 114},
            u"11- أحمد بن علي العجمي (مرتل - برواية حفص)": {"url": "https://server10.mp3quran.net/ajm/", "count": 114},
            u"12- سعد الغامدي (مرتل - برواية حفص)": {"url": "https://server7.mp3quran.net/s_gmd/", "count": 114},
            u"13- ماهر المعيقلي (مرتل - برواية حفص)": {"url": "https://server12.mp3quran.net/maher/", "count": 114},
            u"14- ياسر الدوسري (مرتل - برواية حفص)": {"url": "https://server11.mp3quran.net/yasser/", "count": 114},
            u"15- إدريس أبكر (مرتل - برواية حفص)": {"url": "https://server6.mp3quran.net/abkr/", "count": 114},
            u"16- رعد الكردي (مرتل - برواية حفص)": {"url": "https://server6.mp3quran.net/kurdi/", "count": 114},
            u"17- أبو بكر الشاطري (مرتل - برواية حفص)": {"url": "https://server11.mp3quran.net/shatri/", "count": 114},
            u"18- عبدالله بصفر (مرتل - برواية حفص)": {"url": "https://server6.mp3quran.net/bsfr/", "count": 114},
            u"19- بندر بليلة (مرتل - برواية حفص)": {"url": "https://server6.mp3quran.net/balilah/", "count": 114},
            u"20- صلاح بو خاطر (مرتل - برواية حفص)": {"url": "https://server8.mp3quran.net/bu_khtr/", "count": 114},
            u"21- عبدالرشيد صوفي (مرتل - برواية حفص)": {"url": "https://server16.mp3quran.net/soufi/Rewayat-Hafs-A-n-Assem/", "count": 114},
            u"================  روايــــات  ================": {"url": "", "count": 0},
            u"01- محمود خليل الحصري (مرتل - برواية ورش)": {"url": "https://server13.mp3quran.net/husr/Rewayat-Warsh-A-n-Nafi", "count": 114},
            u"02- عبدالباسط عبدالصمد (مرتل - برواية ورش)": {"url": "https://server7.mp3quran.net/basit/", "count": 114},
            u"03- ياسين الجزائري - (مرتل - برواية ورش)": {"url": "https://server11.mp3quran.net/qari/", "count": 114},
            u"04- العيون الكوشي - (مرتل - برواية ورش)": {"url": "https://server11.mp3quran.net/koshi/", "count": 114},
            u"05- عمر القزابري - (مرتل - برواية ورش)": {"url": "https://server9.mp3quran.net/omar_warsh/", "count": 114},
            u"06- عبدالرشيد صوفي (مرتل - برواية السوسي)": {"url": "https://server16.mp3quran.net/soufi/Rewayat-Assosi-A-n-Abi-Amr/", "count": 114},
            u"07- عبدالرشيد صوفي (مرتل - برواية خلف عن حمزة)": {"url": "https://server16.mp3quran.net/soufi/Rewayat-Khalaf-A-n-Hamzah/", "count": 114},
            u"08- محمد عبدالحكيم سعيد - (مرتل - برواية البزي وقنبل عن ابن كثير)": {"url": "https://server9.mp3quran.net/abdullah/", "count": 114},
            u"=================  مجــــود  =================": {"url": "", "count": 0},
            u"01- محمود خليل الحصري (مجود - برواية حفص)": {"url": "https://server13.mp3quran.net/husr/Almusshaf-Al-Mojawwad/", "count": 114},
            u"02- مصطفي اسماعيل (مجود - برواية حفص)": {"url": "https://server8.mp3quran.net/mustafa/Almusshaf-Al-Mojawwad/", "count": 114},
            u"03- محمد صديق المنشاوي  (مجود - برواية حفص)": {"url": "https://server10.mp3quran.net/minsh/Almusshaf-Al-Mojawwad/", "count": 114},
            u"04- عبدالباسط عبدالصمد (مجود - برواية حفص)": {"url": "https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/", "count": 114},
            u"05- محمود علي البنا (مجود - برواية حفص)": {"url": "https://server8.mp3quran.net/bna/Almusshaf-Al-Mojawwad/", "count": 114},
            u"==============  المصحف المعلم  ==============": {"url": "", "count": 0},
            u"01- محمد صديق المنشاوي (معلم - برواية حفص)": {"url": "https://server10.mp3quran.net/minsh/Almusshaf-Al-Mo-lim/", "count": 114},
            u"02- الحسيني العزازي (معلم غير مكتمل - برواية حفص)": {"url": "https://server8.mp3quran.net/3zazi/", "count": 114},
            u"03- ماهر المعيقلي (معلم غير مكتمل - برواية حفص)": {"url": "https://server12.mp3quran.net/maher/Almusshaf-Al-Mo-lim/", "count": 114},
            u"04- عبدالبارئ محمد (معلم غير مكتمل - برواية حفص)": {"url": "https://server12.mp3quran.net/bari/Almusshaf-Al-Mo-lim/", "count": 114},
            u"05- عبدالله الموسى (معلم غير مكتمل - برواية حفص)": {"url": "https://server14.mp3quran.net/mousa/Almusshaf-Al-Mo-lim/", "count": 114},
        }
        # Add more reciters here

        self["surah_list"] = MenuList([])
        try:
            self["surah_list"].listbox.setMarkupEnabled(True)
        except Exception:
            pass
        self["juz_list"] = MenuList([])
        try:
            self["juz_list"].listbox.setMarkupEnabled(True)
        except Exception:
            pass

        self.quran_index = {}
        self.prefixes = [u'ال', u'ب', u'ل', u'ك', u'و', u'ف', u'س', u'أ', u'أل', u'لل', u'فال', u'وال', u'بال', u'كال', u'فل', u'ول', u'لل']
        self.suffixes = [u'ا', u'ان', u'ين', u'ون', u'ات', u'ة', u'ه', u'ها', u'هم', u'هن', u'نا', u'كم', u'تم', u'تن', u'ي', u'ني', u'ك', u'كما', u'هما']
        self.saved_search_results = None
        self.saved_search_term = None
        self.saved_search_index = 0

        # ─────────────────────────────────────────────────────────────────────
        # المؤقتات - تستخدم SafeETimer لضمان التوافق مع كافة الإصدارات
        # callback.append() يعمل في كلا Python 2 و 3
        # ─────────────────────────────────────────────────────────────────────
        self.reminder_timer = eTimer()
        self.daily_timer = eTimer()
        self.daily_timer.callback.append(self.check_reminder)
        self.friday_timer = eTimer()
        self.friday_timer.callback.append(self.show_kahf_reminder)
        self.timer = eTimer()
        self.timer.callback.append(self.updateClock)
        self.timer.start(60000, False)
        self.imageUpdateTimer = eTimer()
        self.imageUpdateTimer.callback.append(self.updateImages)
        self._decode_retry_timers = []

        self.onShown.append(self.setupClock)
        self.onHide.append(self.stopClock)
        self.setup_reminder()
        self.setup_reminder_timers()
        self.reminders = load_reminders()
        self.onLayoutFinish.append(self.onLayoutFinished)
        self.onLayoutFinish.append(self.update_info_label)

        self.notification_timer = eTimer()
        self.notification_timer.callback.append(self.show_daily_portion_notification)

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "IqraaQuranActions",
             "InputActions", "EPGSelectActions", "InfobarActions",
             "ButtonSetupActions", "InfoActions"],
            {
                "ok": self.handleOk,
                "cancel": self.handleCancel,
                "left": self.handleLeft,
                "right": self.handleRight,
                "up": self.handleUp,
                "down": self.handleDown,
                "red": self.openPageInputScreen,
                "blue": self.activateSuraList,
                "green": self.show_audio_controls,
                "back": self.handleCancel,
                "exit": self.handleCancel,
                "yellow": self.activateJuzList,
                "0": self.reset_progress,
                "epg": self.open_search,
                "menu": self.open_settings,
                "showMovies": self.return_to_previous_page,
                "epg_long": self.play_current_surah_audio,
                "info": self.show_plugin_info,
            }, -1)

        self.daily_portion = self.get_daily_portion()
        self.onShown.append(self.check_and_start_download)
        self.onClose.append(self.save_current_page_layout)
        self.onClose.append(self.cleanup_open_source_image_loaders)
        self.onClose.append(self.detach_service_event)

        # متغيرات الصوت
        self.audio_playing = False
        self["play_icon"].hide()
        self.audio_paused = False
        self.current_audio_url = None
        self.player_service = None
        self._nav_event_attached = False
        self.last_service_before_audio = None
        self.continuous_play_active = False
        self.current_audio_reciter_key = None
        self.current_audio_surah_index = -1
        self.onShown.append(self.on_screen_shown)
        self.auto_audio_play_enabled = False
        self.auto_audio_reciter_key = None
        self.evEOF_handled = False

        self.page_layout = ConfigSelection(
            default=get_saved_page_layout(self.reminders),
            choices=[("double", to_enigma_string(u"صفحتان")), ("single", to_enigma_string(u"صفحة واحدة"))]
        )
        self.refresh_main_index_lists()

    def save_current_page_layout(self):
        # حفظ تخطيط الصفحة الحالي عند الإغلاق
        try:
            layout = get_saved_page_layout(getattr(self, "reminders", {}))
            reminders = load_json_file(REMINDERS_FILE, reminders_default)
            set_saved_page_layout(reminders, layout)
            save_reminders(reminders)
        except Exception as e:
            print("[IqraaQuran] Could not save current page layout:", e)

    def cleanup_open_source_image_loaders(self):
        # تنظيف المؤقتات وإيقافها عند إغلاق الشاشة لمنع التسرب
        self._screen_closing = True
        for timer_name in ("imageUpdateTimer", "updateImagesTimer", "retryTimer"):
            try:
                timer = getattr(self, timer_name, None)
                if timer and timer.isActive():
                    timer.stop()
            except Exception:
                pass
        try:
            for timer in getattr(self, "_decode_retry_timers", []):
                try:
                    if timer.isActive():
                        timer.stop()
                except Exception:
                    pass
            self._decode_retry_timers = []
        except Exception:
            pass

    def show_plugin_info(self):
        self.session.open(PluginInfoScreen)

    def playSound(self, Sound_PATH):
        # تشغيل الصوت في خيط منفصل لتجنب تجميد الواجهة
        if os.path.exists(Sound_PATH):
            def _play():
                try:
                    subprocess.Popen(['aplay', Sound_PATH],
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                except Exception:
                    try:
                        os.system('aplay "' + Sound_PATH + '" >/dev/null 2>&1 &')
                    except Exception:
                        pass
            t = threading.Thread(target=_play)
            t.daemon = True
            t.start()
        else:
            print("[IqraaQuran] الملف الصوتي غير موجود: " + str(Sound_PATH))

    def setupClock(self):
        # تحديث الساعة فوراً ثم ضبط المؤقت للثانية التالية الكاملة
        self.updateClock()
        now = datetime.now()
        delay = 60 - now.second
        self.timer.start(delay * 1000, True)

    def stopClock(self):
        # إيقاف مؤقت الساعة عند إخفاء الشاشة
        if self.timer.isActive():
            self.timer.stop()

    def setLeftImage(self, picInfo=None):
        # عرض الصورة اليسرى بعد اكتمال فك الضغط
        if getattr(self, "_screen_closing", False) or not hasattr(self, "picload_left"):
            return
        ptr = self.picload_left.getData()
        layout_mode = self.reminders.get("page_layout", "double")
        if ptr and layout_mode == "double":  # التأكد من الوضع المزدوج
            self["leftImage"].instance.setPixmap(ptr)
            self["leftImage"].show()

    def setRightImage(self, picInfo=None):
        # عرض الصورة اليمنى بعد اكتمال فك الضغط
        if getattr(self, "_screen_closing", False) or not hasattr(self, "picload_right"):
            return
        ptr = self.picload_right.getData()
        layout_mode = self.reminders.get("page_layout", "double")
        if ptr and layout_mode == "double":  # التأكد من الوضع المزدوج
            self["rightImage"].instance.setPixmap(ptr)
            self["rightImage"].show()

    def setCenterImage(self, picInfo=None):
        # عرض الصورة المركزية (وضع صفحة واحدة) بعد اكتمال فك الضغط
        if getattr(self, "_screen_closing", False) or not hasattr(self, "picload_center"):
            return
        ptr = self.picload_center.getData()
        layout_mode = self.reminders.get("page_layout", "double")
        if ptr and layout_mode == "single":  # التأكد من الوضع الفردي
            self["centerImage"].instance.setPixmap(ptr)
            self["centerImage"].show()

    def loadImage(self, path, picload, widget):
        # تحميل وعرض صورة صفحة المصحف - متوافق مع DreamOS وOpen-Source
        if os.path.exists(path):
            width = 660
            height = 820
            if widget == self["centerImage"]:
                width = 1320
                height = 820
            try:
                if widget and widget.instance:
                    sz = widget.instance.size()
                    if sz.width() > 0 and sz.height() > 0:
                        width = sz.width()
                        height = sz.height()
            except Exception as e:
                print("[IqraaQuran] Error getting widget size:", e)

            # نسبة العرض إلى الارتفاع حسب نوع الصورة والنظام
            if widget == self["centerImage"] and IS_DREAMOS_PY2:
                aspect_ratio = 180
            elif widget == self["centerImage"] and IS_OPEN_SOURCE_PY3:
                aspect_ratio = 150
            elif widget == self["centerImage"]:
                aspect_ratio = 0
            elif IS_DREAMOS_PY2:
                aspect_ratio = 120
            elif IS_OPEN_SOURCE_PY3:
                aspect_ratio = 120
            else:
                aspect_ratio = 100

            # Using tuple for strict DreamOS bindings
            picload.setPara((
                width,
                height,
                100,          # Scale
                aspect_ratio, # Aspect
                0,            # Cache
                1,            # Resize
                "#00000000"   # Background
            ))

            # Safe call for startDecode with argument compatibility
            try:
                picload.startDecode(path)
            except TypeError:
                try:
                    picload.startDecode(path, 0, 0, False)
                except Exception as e:
                    print("[IqraaQuran] Error starting decode with 4 arguments:", e)
            except Exception as e:
                print("[IqraaQuran] Error starting decode:", e)

            if IS_OPEN_SOURCE_PY3:
                self._scheduleOpenSourceDecodeRetry(path, picload)

    def get_daily_portion(self):
        # حساب الورد اليومي بتقسيم المصحف على 30 يوماً
        daily_pages = 604 // 30
        today = datetime.now().day
        start_page = ((today - 1) % 30) * daily_pages + 1
        end_page = min(start_page + daily_pages - 1, 604)
        return (start_page, end_page)

    def page_for_current_layout(self, page):
        # تعديل رقم الصفحة ليتوافق مع وضع العرض (مفرد/مزدوج)
        if self.reminders.get("page_layout", "double") == "single":
            return page
        return page if page % 2 == 1 else page - 1

    def set_info_page(self, page):
        # تعيين رقم الصفحة المرجعية للمعلومات
        try:
            page = int(page)
        except Exception:
            page = self.currentPage
        total_pages = getattr(self, "totalPages", 604)
        if page < 1:
            page = 1
        elif page > total_pages:
            page = total_pages
        self._info_page = page

    def get_current_reference_page(self):
        # استرجاع رقم الصفحة المرجعية الحالية
        page = getattr(self, "_info_page", self.currentPage)
        try:
            page = int(page)
        except Exception:
            page = self.currentPage
        total_pages = getattr(self, "totalPages", 604)
        if page < 1 or page > total_pages:
            page = self.currentPage
        return page

    def format_dreamos_index_column(self, data_list, index, item):
        # تنسيق عمود الفهرس في DreamOS باستخدام حشو نصي
        return arabic_menu_pad(22) + item[0]

    def build_colored_index_items(self, data_list):
        # بناء قائمة عناصر الفهرس مع الألوان للإصدارات المدعومة
        current_page = self.get_current_reference_page()
        current_index = self.getCurrentIndex(data_list)
        pad = u""
        items = []
        is_surah = (len(data_list) == 114)
        is_juz = (len(data_list) == 30)
        for index, item in enumerate(data_list):
            name = item[0]
            if is_surah or is_juz:
                name = u"{}- {}".format(index + 1, name)
            title = (self.format_dreamos_index_column(data_list, index, (name, item[1]))
                     if IS_DREAMOS_PY2 else pad + name)
            if IS_DREAMOS_PY2:
                pass  # DreamOS: بدون ألوان، يُستخدم تنسيق النص العادي
            elif index == current_index:
                title = enigma_colored_text(title, "\\c00ffff00")
            elif item[1] < current_page:
                title = enigma_colored_text(title, "\\c0000ff00")
            else:
                title = enigma_colored_text(title, "\\c00ffffff")
            items.append(to_enigma_string(title))
        return items

    def refresh_main_index_lists(self):
        # تحديث قوائم السور والأجزاء في الواجهة
        try:
            if hasattr(self, "suraList"):
                self["surah_list"].setList(self.build_colored_index_items(self.suraList))
            if hasattr(self, "juzList"):
                self["juz_list"].setList(self.build_colored_index_items(self.juzList))
        except Exception as e:
            print("[IqraaQuran] Could not refresh colored index lists:", e)

########################################################  عرض التاريخ الميلادي والهجري والوقت
    def gregorian_to_hijri(self, g_year, g_month, g_day):
        # تحويل التاريخ الميلادي إلى هجري باستخدام خوارزمية رياضية محلية
        jd = (1461 * (g_year + 4800 + (g_month - 14) // 12)) // 4 + \
             (367 * (g_month - 2 - 12 * ((g_month - 14) // 12))) // 12 - \
             (3 * ((g_year + 4900 + (g_month - 14) // 12) // 100)) // 4 + \
             g_day - 32075
        l = jd - 1948440 + 10632
        n = (l - 1) // 10631
        l = l - 10631 * n + 354
        j = ((10985 - l) // 5316) * ((50 * l) // 17719) + (l // 5670) * ((43 * l) // 15238)
        l = l - ((30 - j) // 15) * ((17719 * j) // 50) - (j // 16) * ((15238 * j) // 43) + 29
        m = (24 * l) // 709
        d = l - (709 * m) // 24
        y = 30 * n + j - 30
        return y, m, d

    def fetch_ummalqura_hijri(self, year, month, day):
        # محاولة جلب التاريخ الهجري الدقيق من API خارجي (اختياري)
        try:
            date_str = "{:04d}-{:02d}-{:02d}".format(year, month, day)
            url = "https://api.aladhan.com/v1/gToH?date={}".format(date_str)
            status, text = _fetch_url(url, timeout=5)
            if status == 200:
                data = json.loads(text)
                h_date = data["data"]["hijri"]["date"]
                h_day, h_month, h_year = map(int, h_date.split('-'))
                return h_year, h_month, h_day
        except Exception:
            return None
        return None

    def updateClock(self):
        # تحديث عرض التاريخ والوقت في الواجهة
        now = datetime.now()
        HIJRI_MONTHS = [
            u"محرم", u"صفر", u"ربيع الأول", u"ربيع الآخر",
            u"جمادى الأولى", u"جمادى الآخرة", u"رجب", u"شعبان",
            u"رمضان", u"شوال", u"ذو القعدة", u"ذو الحجة"
        ]
        # نحاول جلب التاريخ الهجري من الإنترنت، وعند الفشل نحسبه محلياً
        hijri_date = self.fetch_ummalqura_hijri(now.year, now.month, now.day)
        if hijri_date is not None:
            h_year, h_month, h_day = hijri_date
        else:
            h_year, h_month, h_day = self.gregorian_to_hijri(now.year, now.month, now.day)
        hijri_month_name = HIJRI_MONTHS[h_month - 1]
        hijri_str = u"{} {} {} هـ".format(h_day, hijri_month_name, h_year)
        self["time_date"].setText(to_enigma_string(
            u"{} - {}".format(now.strftime("%A, %d %b %Y | %I:%M %p"), hijri_str)
        ))
        self["hijri_date"].setText("")
        self.timer.start(60000, True)

    def onLayoutFinished(self):
        # تهيئة config إذا لم تكن موجودة
        if not hasattr(config.plugins, 'IqraaQuran'):
            config.plugins.IqraaQuran = ConfigSubsection()
        if not hasattr(config.plugins.IqraaQuran, 'last_page_before_kah'):
            config.plugins.IqraaQuran.last_page_before_kahf = ConfigInteger(default=0)
        if not hasattr(config.plugins.IqraaQuran, 'last_page_read'):
            config.plugins.IqraaQuran.last_page_read = ConfigInteger(default=1)
        if not hasattr(config.plugins.IqraaQuran, 'pages_read_today'):
            config.plugins.IqraaQuran.pages_read_today = ConfigInteger(default=0)
        if not hasattr(config.plugins.IqraaQuran, 'total_pages_read'):
            config.plugins.IqraaQuran.total_pages_read = ConfigInteger(default=0)
        last_page = self.load_progress()
        self.currentPage = last_page
        self.set_info_page(last_page)
        self.download_all_pages_in_background()
        self.updateImagesTimer = eTimer()
        self.updateImagesTimer.callback.append(self.updateImages)
        self.updateImagesTimer.start(1000, True)

    def _scheduleOpenSourceDecodeRetry(self, path, picload):
        """Extra decode nudge for open-source Python 3 images where ePicLoad can be slow."""
        try:
            timer = eTimer()

            def retry_decode():
                try:
                    if os.path.exists(path):
                        picload.startDecode(path)
                except TypeError:
                    try:
                        picload.startDecode(path, 0, 0, False)
                    except Exception as e:
                        print("[IqraaQuran] Open source decode retry failed:", e)
                except Exception as e:
                    print("[IqraaQuran] Open source decode retry failed:", e)
                try:
                    if timer in self._decode_retry_timers:
                        self._decode_retry_timers.remove(timer)
                except Exception:
                    pass

            timer.callback.append(retry_decode)
            self._decode_retry_timers.append(timer)
            timer.start(350, True)
        except Exception as e:
            print("[IqraaQuran] Could not schedule open source decode retry:", e)

    def updateImages(self):
        # تحديث عرض الصور حسب وضع التخطيط (مفرد/مزدوج)
        if not os.path.exists(self.picPath):
            try:
                os.makedirs(self.picPath)
            except Exception:
                pass
        layout_mode = self.reminders.get("page_layout", "double")
        if IS_OPEN_SOURCE_PY3:
            if layout_mode == "single":
                self["leftImage"].hide()
                self["rightImage"].hide()
            else:
                self["centerImage"].hide()
        else:
            self["leftImage"].hide()
            self["rightImage"].hide()
            self["centerImage"].hide()
        self["pageLabelLeft"].hide()
        if layout_mode == "single":
            page_path = os.path.join(self.picPath, "page{:03d}.png".format(self.currentPage))
            if os.path.exists(page_path):
                self.loadImage(page_path, self.picload_center, self["centerImage"])
            else:
                self.download_image(self.currentPage, page_path)
                self._scheduleImageRetry()
            self["pageLabelRight"].setText(to_enigma_string(u"صفحة: {}".format(self.currentPage)))
            self["pageLabelLeft"].hide()
        else:
            right = self.currentPage
            left = self.currentPage + 1 if self.currentPage < self.totalPages else 1
            right_path = os.path.join(self.picPath, "page{:03d}.png".format(right))
            left_path = os.path.join(self.picPath, "page{:03d}.png".format(left))
            needs_retry = False
            if os.path.exists(right_path):
                self.loadImage(right_path, self.picload_right, self["rightImage"])
            else:
                self.download_image(right, right_path)
                needs_retry = True
            if os.path.exists(left_path):
                self.loadImage(left_path, self.picload_left, self["leftImage"])
            else:
                self.download_image(left, left_path)
                needs_retry = True
            if needs_retry:
                self._scheduleImageRetry()
            self["pageLabelRight"].setText(to_enigma_string(u"صفحة: {} >>>".format(right)))
            self["pageLabelLeft"].setText(to_enigma_string(u"<<< صفحة: {}".format(left)))
            self["pageLabelLeft"].show()
        self.update_info_label()
        self.refresh_main_index_lists()
        self["surah_list"].show()
        self["juz_list"].show()
        self.save_progress(self.currentPage)

    download_in_progress = False

    def get_mushaf_archive_name(self):
        # الحصول على اسم أرشيف المصحف حسب الرواية المختارة
        riwaya = self.reminders.get("mushaf_riwaya", "hafs")
        return QURAN_ARCHIVES.get(riwaya, QURAN_ARCHIVES["hafs"])

    def download_pages_archive(self, missing_count):
        # تنزيل أرشيف صفحات المصحف كاملاً إذا كان عدد الصفحات المفقودة كبيراً
        if missing_count < 30:
            return False
        archive_name = self.get_mushaf_archive_name()
        archive_path = os.path.join(self.picPath, archive_name)
        print("[IqraaQuran] Trying Quran archive download from repo:", archive_name)
        if not _download_repo_file(archive_name, archive_path, timeout=180):
            return False
        extracted = self.extract_pages_archive(archive_path)
        try:
            os.remove(archive_path)
        except Exception:
            pass
        return extracted

    def extract_pages_archive(self, archive_path):
        # استخراج صفحات المصحف من الأرشيف المضغوط
        global QURAN_DOWNLOADED_COUNT
        page_re = re.compile(r'^(?:page)?(\d{3})\.png$', re.I)
        extracted = 0
        try:
            if not os.path.exists(self.picPath):
                os.makedirs(self.picPath)
            tar = tarfile.open(archive_path, "r:gz")
            try:
                for member in tar.getmembers():
                    if not member.isfile():
                        continue
                    base = os.path.basename(member.name)
                    match = page_re.match(base)
                    if not match:
                        continue
                    page_number = int(match.group(1))
                    if page_number < 1 or page_number > self.totalPages:
                        continue
                    source = tar.extractfile(member)
                    if source is None:
                        continue
                    dest_path = os.path.join(self.picPath, "page{:03d}.png".format(page_number))
                    tmp_path = dest_path + ".tmp"
                    with open(tmp_path, "wb") as out:
                        while True:
                            chunk = source.read(1024 * 64)
                            if not chunk:
                                break
                            out.write(chunk)
                    os.rename(tmp_path, dest_path)
                    extracted += 1
            finally:
                tar.close()
            QURAN_DOWNLOADED_COUNT = len([f for f in os.listdir(self.picPath) if f.endswith(".png")])
            print("[IqraaQuran] Extracted {} Quran pages from archive.".format(extracted))
            return extracted > 0
        except Exception as e:
            print("[IqraaQuran] Archive extraction failed:", e)
            return False

    def download_all_pages_in_background(self):
        """تحميل صفحات المصحف كاملاً في خيط خلفي نقي لتجنب التجميد والتعارض"""
        if IqraaQuran.download_in_progress:
            print("[IqraaQuran] التحميل قيد التنفيذ بالفعل، لن يتم بدء خيط آخر.")
            return

        IqraaQuran.download_in_progress = True
        pic_path = self.picPath
        total_pages_count = self.totalPages

        global QURAN_DOWNLOADED_COUNT
        try:
            if os.path.exists(pic_path):
                QURAN_DOWNLOADED_COUNT = len([f for f in os.listdir(pic_path) if f.endswith(".png")])
            else:
                QURAN_DOWNLOADED_COUNT = 0
        except Exception:
            QURAN_DOWNLOADED_COUNT = 0

        def _do_pure_python_download():
            global QURAN_DOWNLOADED_COUNT
            try:
                if not os.path.exists(pic_path):
                    try:
                        os.makedirs(pic_path)
                    except Exception as e:
                        print("[IqraaQuran] لا يمكن إنشاء المجلد: {}".format(e))
                        return

                missing = []
                for page_number in range(1, total_pages_count + 1):
                    page_path = os.path.join(pic_path, "page{:03d}.png".format(page_number))
                    if not os.path.exists(page_path):
                        missing.append((page_number, page_path))
                    time.sleep(0.005)

                if not missing:
                    return

                if self.download_pages_archive(len(missing)):
                    missing = []
                    for page_number in range(1, total_pages_count + 1):
                        page_path = os.path.join(pic_path, "page{:03d}.png".format(page_number))
                        if not os.path.exists(page_path):
                            missing.append((page_number, page_path))
                    if not missing:
                        print("[IqraaQuran] اكتمل تحميل المصحف من الأرشيف بنجاح!")
                        return

                print("[IqraaQuran] بدء تحميل {} صفحة مفقودة عبر خيط خلفي متعدد...".format(len(missing)))

                # Queue متوافق مع Python 2 (Queue) و Python 3 (queue)
                try:
                    import Queue as queue
                except ImportError:
                    import queue

                q = queue.Queue()
                for item in missing:
                    q.put(item)

                def worker():
                    global QURAN_DOWNLOADED_COUNT
                    while True:
                        try:
                            page_number, page_path = q.get_nowait()
                        except queue.Empty:
                            break

                        url = "https://surahquran.com/img/pages-quran/page{:03d}.png".format(page_number)
                        try:
                            req = Request(url, headers={"User-Agent": "IqraaQuran/1.3"})
                            resp = urlopen(req, timeout=15)
                            data = resp.read()
                            tmp_path = page_path + ".tmp"
                            with open(tmp_path, 'wb') as f:
                                f.write(data)
                            os.rename(tmp_path, page_path)
                            QURAN_DOWNLOADED_COUNT += 1
                            time.sleep(0.01)  # Yield GIL
                        except Exception as e:
                            print("[IqraaQuran] خطأ أثناء تحميل الصفحة {}: {}".format(page_number, e))
                            time.sleep(0.05)
                        finally:
                            q.task_done()

                threads = []
                for i in range(4):  # 4 parallel download threads
                    t = threading.Thread(target=worker)
                    t.daemon = True
                    t.start()
                    threads.append(t)

                for t in threads:
                    t.join()

                print("[IqraaQuran] اكتمل التحميل الخلفي المتعدد بنجاح!")
            finally:
                IqraaQuran.download_in_progress = False

        t = threading.Thread(target=_do_pure_python_download)
        t.daemon = True
        t.start()

    def _scheduleImageRetry(self):
        """إعادة محاولة تحميل الصورة بعد ثانيتين بدون تجميد الواجهة"""
        try:
            self.retryTimer = eTimer()
            self.retryTimer.callback.append(self.updateImages)
            self.retryTimer.start(2000, True)
        except Exception:
            pass

    def check_and_start_download(self):
        # فحص إذا كانت هناك صفحات مفقودة وبدء التحميل إذا لزم
        missing = any(
            not os.path.exists(os.path.join(self.picPath, "page{:03d}.png".format(page)))
            for page in range(1, self.totalPages + 1)
        )
        if missing:
            self.session.openWithCallback(self.on_download_finished, DownloadProgressScreen)
            self.showTemporaryMessage(u"جاري تحميل صفحات المصحف كاملاً خلال دقائق لمرة واحدة ... فصبر جميل", 4000)
            self.download_all_pages_in_background()
        else:
            self.updateImages()

    def on_download_finished(self):
        # استدعاء بعد انتهاء شاشة التحميل
        self.showTemporaryMessage(u"تم تحميل صفحات المصحف بنجاح!", 4000)
        self.updateImages()

    def showTemporaryMessage(self, message, duration=3000):
        # عرض رسالة مؤقتة في شريط الحالة
        self["statusLabel"].setText(to_enigma_string(message))
        self.msgTimer = eTimer()
        self.msgTimer.callback.append(self.clearStatusLabel)
        # استخدام start() بدلاً من startLongTimer() لضمان التوافق الكامل
        self.msgTimer.start(int(duration), True)

    def clearStatusLabel(self):
        # مسح رسالة شريط الحالة
        self["statusLabel"].setText("")
        self.msgTimer = None

    def download_image(self, page_number, save_path):
        """تحميل صفحة واحدة في خيط خلفي لتجنب تجميد الواجهة"""
        def _do_download():
            try:
                url = "https://surahquran.com/img/pages-quran/page{:03d}.png".format(page_number)
                response = urlopen(url, timeout=15)
                data = response.read()
                tmp_path = save_path + ".tmp"
                with open(tmp_path, 'wb') as f:
                    f.write(data)
                os.rename(tmp_path, save_path)
                print("[IqraaQuran] تم تحميل الصفحة رقم " + str(page_number))
            except Exception as e:
                print("[IqraaQuran] خطأ أثناء تحميل الصفحة {}: {}".format(page_number, e))

        t = threading.Thread(target=_do_download)
        t.daemon = True
        t.start()

    def save_progress(self, page):
        # حفظ الصفحة الحالية في ملف التقدم
        try:
            progress_file = os.path.join(PLUGIN_PATH, 'progress.txt')
            with open(progress_file, 'w') as f:
                f.write(str(page))
            daily_pages_file = os.path.join(PLUGIN_PATH, 'daily_pages.txt')
            today = datetime.now().strftime("%Y-%m-%d")
            with open(daily_pages_file, 'a') as f:
                f.write("{},{}\n".format(today, page))
            return True
        except Exception:
            return False

    def load_progress(self):
        # تحميل آخر صفحة تمت قراءتها من ملف التقدم
        try:
            progress_file = os.path.join(PLUGIN_PATH, 'progress.txt')
            if os.path.exists(progress_file):
                with open(progress_file, 'r') as f:
                    page = int(f.read().strip())
                    if 1 <= page <= 604:
                        return page
            return 1
        except Exception:
            return 1

    def get_daily_pages(self):
        # جلب قائمة الصفحات المقروءة اليوم من ملف السجل
        today = datetime.now().strftime("%Y-%m-%d")
        daily_pages = []
        try:
            daily_pages_file = os.path.join(PLUGIN_PATH, 'daily_pages.txt')
            if os.path.exists(daily_pages_file):
                with open(daily_pages_file, 'r') as f:
                    for line in f:
                        parts = line.strip().split(',')
                        if len(parts) == 2:
                            date, page = parts
                            if date == today:
                                daily_pages.append(int(page))
        except Exception:
            pass
        return daily_pages

    def update_info_label(self):
        # تحديث شريط المعلومات بالسورة والجزء ورقم الصفحة الحالية
        current_sura = u""
        current_juz = u""
        current_page = self.get_current_reference_page()
        for sura_name, start_page in reversed(self.suraList):
            if current_page >= start_page:
                current_sura = sura_name
                break
        for i, (juz_name, start_page) in enumerate(reversed(self.juzList)):
            original_index = len(self.juzList) - 1 - i
            if current_page >= start_page:
                current_juz = u"الجزء {}".format(original_index + 1)
                break
        self["infoLabel"].setText(to_enigma_string(
            u"{} - سورة {} - صفحة {}".format(current_juz, current_sura, current_page)
        ))
        self["surahJuzLabel"].setText("")

    def play_audio_for_surah(self, reciter_key, surah_index):
        # تشغيل صوت سورة محددة لقارئ محدد
        if not self.audio_playing:
            current_service = self.session.nav.getCurrentlyPlayingServiceReference()
            if current_service and current_service.type != 4097:
                self.last_service_before_audio = current_service
                print("[IqraaQuran] Stored last TV/Radio service:", self.last_service_before_audio)
            elif not current_service:
                self.last_service_before_audio = current_service
                print("[IqraaQuran] Nothing was playing, stored None as last_service_before_audio")
        self.current_audio_reciter_key = reciter_key
        self.current_audio_surah_index = surah_index
        self.continuous_play_active = True
        reciter_info = self.reciters_data[reciter_key]
        surah_number_to_play = surah_index + 1
        if 1 <= surah_number_to_play <= reciter_info['count']:
            base_url = reciter_info.get('url', '').strip()
            if base_url and not base_url.endswith('/'):
                base_url += '/'
            audio_url = "{}{}.mp3".format(base_url, str(surah_number_to_play).zfill(3))
            self.play_audio_url(audio_url)
            current_dialog = self.session.current_dialog
            if isinstance(current_dialog, AudioControlAndReciterScreen):
                current_dialog.update_playing_surah_info(surah_index)
        else:
            print("[IqraaQuran] Surah index {} out of range for reciter {}".format(surah_index, reciter_key))
            self.continuous_play_active = False
            if self.audio_playing:
                self.stop_current_audio(restore_service=True)

    def stop_current_audio(self, restore_service=False):
        # إيقاف تشغيل الصوت واستعادة الخدمة السابقة إذا لزم
        if self.player_service:
            self.session.nav.stopService()
            self.player_service = None
        self.audio_playing = False
        self.continuous_play_active = False
        self.audio_paused = False
        self.current_audio_reciter_key = None
        self.current_audio_surah_index = -1
        self["play_icon"].hide()
        print("[IqraaQuran] Audio stopped.")
        current_dialog = self.session.current_dialog
        if isinstance(current_dialog, AudioControlAndReciterScreen):
            current_dialog.update_ui_for_stop()
        if restore_service and self.last_service_before_audio:
            print("[IqraaQuran] Restoring last service:", self.last_service_before_audio)
            self.session.nav.playService(self.last_service_before_audio)
            self.last_service_before_audio = None
        elif restore_service and self.last_service_before_audio is None:
            print("[IqraaQuran] Nothing to restore, ensuring Enigma2 player is stopped.")
            self.session.nav.stopService()

    def play_audio_url(self, url):
        # تشغيل رابط صوتي عبر Enigma2 بتجربة أنواع خدمة متعددة
        print("[IqraaQuran] Attempting to play URL: {}".format(url))
        if not url or not url.startswith("http"):
            print("[IqraaQuran] Invalid audio URL, skipping playback.")
            self.audio_playing = False
            self["play_icon"].hide()
            return
        if self.player_service:
            self.session.nav.stopService()
            self.player_service = None
        self.current_audio_url = url
        self.audio_playing = False
        self.audio_paused = False
        self["play_icon"].hide()
        service_types = [4097, 5001, 5002]
        for service_type in service_types:
            print("[IqraaQuran] Trying service type {} for URL: {}".format(service_type, url))
            try:
                service_ref = eServiceReference(service_type, 0, url)
                service_ref.setName(os.path.basename(url))
                self.audio_service_ref = service_ref
                started = self.session.nav.playService(service_ref)
                self.player_service = self.session.nav.getCurrentService()
            except Exception as e:
                print("[IqraaQuran] Exception with service type {}: {}".format(service_type, e))
                self.player_service = None
                continue
            if self.player_service:
                self.audio_playing = True
                self["play_icon"].show()
                print("[IqraaQuran] Playback started using service type {} for: {}".format(service_type, url))
                return
        self.session.open(MessageBox, u"فشل تشغيل الملف الصوتي بأي من المشغلات المتاحة.", MessageBox.TYPE_ERROR)
        print("[IqraaQuran] Failed to start playback for: {} using all fallback players.".format(url))

    def toggle_audio_pause(self):
        # إيقاف/استئناف تشغيل الصوت
        if not self.audio_playing:
            print("[IqraaQuran] Toggle pause called but not playing.")
            current_dialog = self.session.current_dialog
            if isinstance(current_dialog, AudioControlAndReciterScreen):
                current_dialog.play_selected_surah()
            return
        service = self.session.nav.getCurrentService()
        if service:
            pauseable = service.pause()
            if pauseable is not None:
                if self.audio_paused:
                    pauseable.unpause()
                    self.audio_paused = False
                    self["play_icon"].show()
                    print("[IqraaQuran] Audio unpaused.")
                else:
                    pauseable.pause()
                    self.audio_paused = True
                    self["play_icon"].hide()
                    print("[IqraaQuran] Audio paused.")
            current_dialog = self.session.current_dialog
            if isinstance(current_dialog, AudioControlAndReciterScreen):
                current_dialog.update_ui_for_pause_play(self.audio_paused)

    def on_screen_shown(self):
        # ربط حدث الخدمة عند ظهور الشاشة
        if not getattr(self, "_nav_event_attached", False):
            try:
                self.session.nav.event.append(self.service_event)
                self._nav_event_attached = True
            except Exception as e:
                print("[IqraaQuran] Could not attach service event:", e)

    def detach_service_event(self):
        # فصل حدث الخدمة عند إغلاق الشاشة لمنع التسرب
        if getattr(self, "_nav_event_attached", False):
            try:
                self.session.nav.event.remove(self.service_event)
            except Exception as e:
                print("[IqraaQuran] Could not detach service event:", e)
            self._nav_event_attached = False

    def service_event(self, event):
        # معالجة أحداث الخدمة (نهاية الملف الصوتي)
        if not hasattr(self, "player_service") or not hasattr(self, "audio_playing"):
            print("[IqraaQuran] service_event triggered too early, ignoring.")
            return
        if self.player_service is None or not self.audio_playing:
            return
        if event == iPlayableService.evEOF:
            print("[IqraaQuran] Audio track finished (evEOF).")
            if getattr(self, "evEOF_handled", False):
                print("[IqraaQuran] evEOF already handled. Skipping.")
                return
            self.evEOF_handled = True
            if self.continuous_play_active:
                print("[IqraaQuran] Continuous play active, trying next Surah.")
                self.play_next_surah()
            else:
                print("[IqraaQuran] EOF received, not in continuous play. Audio stopped.")
                self.stop_current_audio(restore_service=True)

            def reset_flag():
                self.evEOF_handled = False

            # محاولة استخدام twisted reactor أولاً، وعند الفشل نستخدم SafeETimer
            try:
                from twisted.internet import reactor
                reactor.callLater(1.0, reset_flag)
            except Exception:
                self._eof_reset_timer = eTimer()
                self._eof_reset_timer.callback.append(reset_flag)
                self._eof_reset_timer.start(1000, True)

    def play_next_surah(self):
        # تشغيل السورة التالية في وضع التشغيل المتواصل
        self.current_audio_surah_index += 1
        if self.current_audio_surah_index < len(self.surah_names_simple):
            self.play_audio_for_surah(self.current_audio_reciter_key, self.current_audio_surah_index)
        else:
            print("[IqraaQuran] End of surah list. Stopping.")
            self.stop_current_audio(restore_service=True)

    def handleOk(self):
        # معالجة ضغطة OK حسب الحالة الحالية (قائمة/إدخال)
        if self.activeList:
            layout_mode = self.reminders.get("page_layout", "double")
            if self.activeList == "surah_list":
                index = safe_menulist_index(self["surah_list"], len(self.suraList))
                selected_sura_page = self.suraList[index][1]
                self.set_info_page(selected_sura_page)
                if layout_mode == "single":
                    self.currentPage = selected_sura_page
                else:
                    self.currentPage = selected_sura_page if selected_sura_page % 2 == 1 else selected_sura_page - 1
            elif self.activeList == "juz_list":
                index = safe_menulist_index(self["juz_list"], len(self.juzList))
                selected_juz_page = self.juzList[index][1]
                self.set_info_page(selected_juz_page)
                if layout_mode == "single":
                    self.currentPage = selected_juz_page
                else:
                    self.currentPage = selected_juz_page if selected_juz_page % 2 == 1 else selected_juz_page - 1
            self["surah_list"].show()
            self["juz_list"].show()
            self["surah_list"].selectionEnabled(False)
            self["juz_list"].selectionEnabled(False)
            self.activeList = None
            self.updateImages()
        elif self.inputMode:
            try:
                page_num = int(self.pageInput)
                if 1 <= page_num <= self.totalPages:
                    self.set_info_page(page_num)
                    self.currentPage = self.page_for_current_layout(page_num)
                    self.updateImages()
                else:
                    self.session.open(MessageBox, u"رقم الصفحة غير صحيح", MessageBox.TYPE_ERROR)
            except ValueError:
                self.session.open(MessageBox, u"إدخال غير صحيح", MessageBox.TYPE_ERROR)
            self.pageInput = ""
            self.inputMode = False
            self["statusLabel"].setText("")

    def handleCancel(self):
        # معالجة ضغطة إلغاء/رجوع
        if self.activeList:
            self["surah_list"].show()
            self["juz_list"].show()
            self["surah_list"].selectionEnabled(False)
            self["juz_list"].selectionEnabled(False)
            self.activeList = None
            self.update_info_label()
            return
        if self.inputMode:
            self.pageInput = ""
            self.inputMode = False
            self["statusLabel"].setText("")
            return
        self.playSound(os.path.join(Sound_PATH, 'end.wav'))
        exit_message = u"جزانا و جزاكم الله خيرا \nوجعلنا وإياكم من أهل القرءان وخاصته \nلا تنسونا من دعاءكم بظهر الغيب"
        if isDreamOS:
            self.session.openWithCallback(self.confirm_exit, DreamboxCenteredExitPopup, exit_message, 1)
        else:
            self.session.openWithCallback(self.confirm_exit, MessageBox, exit_message, MessageBox.TYPE_INFO, 1)

    def confirm_exit(self, answer=None):
        # تأكيد الخروج من البلاجين
        self.close()

    def handleLeft(self):
        # الانتقال إلى الصفحة التالية (الضغط يسار = صفحة للأمام)
        if self.activeList:
            self[self.activeList].pageUp()
        elif not self.inputMode:
            layout_mode = self.reminders.get("page_layout", "double")
            increment = 1 if layout_mode == "single" else 2
            if self.currentPage < self.totalPages - (increment - 1):
                self.currentPage += increment
                self.set_info_page(self.currentPage)
                self.imageUpdateTimer.start(0, True)
                self.playSound(os.path.join(Sound_PATH, 'pageflip.wav'))

    def handleRight(self):
        # الانتقال إلى الصفحة السابقة (الضغط يمين = صفحة للخلف)
        if self.activeList:
            self[self.activeList].pageDown()
        elif not self.inputMode:
            layout_mode = self.reminders.get("page_layout", "double")
            decrement = 1 if layout_mode == "single" else 2
            if self.currentPage > 1:
                self.currentPage -= decrement
                if self.currentPage < 1:
                    self.currentPage = 1
                self.set_info_page(self.currentPage)
                self.imageUpdateTimer.start(0, True)
                self.playSound(os.path.join(Sound_PATH, 'pageflip.wav'))

    def handleUp(self):
        # التمرير لأعلى في القائمة النشطة
        if self.activeList:
            self[self.activeList].up()

    def handleDown(self):
        # التمرير لأسفل في القائمة النشطة
        if self.activeList:
            self[self.activeList].down()

    def activateJuzList(self):
        # تفعيل قائمة الأجزاء للتنقل
        self.refresh_main_index_lists()
        self["juz_list"].show()
        self.activeList = "juz_list"
        self["juz_list"].selectionEnabled(True)
        self["surah_list"].selectionEnabled(False)
        self.showingSelectionMessage = True
        self["infoLabel"].setText(to_enigma_string(u"اختر جزء ثم اضغط OK"))

    def activateSuraList(self):
        # تفعيل قائمة السور للتنقل
        if not hasattr(self, 'suraList'):
            return
        self.refresh_main_index_lists()
        self["surah_list"].show()
        self.activeList = "surah_list"
        self["surah_list"].selectionEnabled(True)
        self["juz_list"].selectionEnabled(False)
        self.showingSelectionMessage = True
        self["infoLabel"].setText(to_enigma_string(u"اختر سورة ثم اضغط OK"))

    def getCurrentIndex(self, dataList):
        # حساب فهرس العنصر الحالي في قائمة البيانات
        if not dataList:
            return 0
        current_page = self.get_current_reference_page()
        current = 0
        for i, item in enumerate(dataList):
            if item[1] <= current_page:
                current = i
            else:
                break
        return current

    def openPageInputScreen(self):
        # فتح شاشة إدخال رقم الصفحة
        self.session.openWithCallback(
            self.onPageNumberEntered, PageInputScreen,
            currentPage=self.currentPage, suraList=self.suraList
        )

    def onPageNumberEntered(self, entered_page=None):
        # معالجة رقم الصفحة المُدخَل من شاشة البحث
        if entered_page == "word_search":
            self.open_search()
            return
        if entered_page is not None:
            layout_mode = self.reminders.get("page_layout", "double")
            self.set_info_page(entered_page)
            if layout_mode == "single":
                self.currentPage = entered_page
            else:
                self.currentPage = entered_page if entered_page % 2 == 1 else entered_page - 1
            self["surah_list"].hide()
            self["juz_list"].hide()
            self.activeList = None
            self.from_page_input = True
            self.updateImagesTimer = eTimer()
            self.updateImagesTimer.callback.append(self.updateImages)
            self.updateImagesTimer.start(500, True)
            self.playSound(os.path.join(Sound_PATH, 'pageflip.wav'))

    def show_stats(self):
        # عرض إحصائيات القراءة
        current_page = self.load_progress()
        daily_pages = self.get_daily_pages()
        read_pages = current_page - 1
        today_count = len(daily_pages)
        completed_parts = read_pages // 20
        progress_percent = round((read_pages / self.totalPages) * 100, 1)
        stats_text = (
            u"=== إحصائيات القراءة === \n"
            u"تقدمك في القراءة :\n"
            u"- الصفحات المقروءة اليوم : {today}\n"
            u"- الصفحات المقروءة إجمالاً : {read}/{total}\n"
            u"- الأجزاء المكتملة : {parts}/30\n"
            u"- النسبة المئوية : % {pct}"
        ).format(
            today=today_count,
            read=read_pages,
            total=self.totalPages,
            parts=completed_parts,
            pct=progress_percent
        )
        self.session.open(QuranStatsScreen, to_enigma_string(stats_text))

    def reset_progress(self):
        # طلب تأكيد حذف سجلات التقدم
        self.session.openWithCallback(
            self.confirm_reset, MessageBox,
            u"هل أنت متأكد من حذف جميع سجلات التقدم؟\nسيتم حذف كل البيانات المحفوظة!",
            MessageBox.TYPE_YESNO
        )

    def confirm_reset(self, answer):
        # تنفيذ حذف سجلات التقدم بعد تأكيد المستخدم
        if answer:
            try:
                if not hasattr(config.plugins, 'IqraaQuran'):
                    config.plugins.IqraaQuran = ConfigSubsection()
                    config.plugins.IqraaQuran.last_page_read = ConfigInteger(default=1)
                    config.plugins.IqraaQuran.pages_read_today = ConfigInteger(default=0)
                    config.plugins.IqraaQuran.total_pages_read = ConfigInteger(default=0)
                config.plugins.IqraaQuran.last_page_read.value = 1
                config.plugins.IqraaQuran.pages_read_today.value = 0
                config.plugins.IqraaQuran.total_pages_read.value = 0
                config.plugins.IqraaQuran.save()
                self.playSound(os.path.join(Sound_PATH, 'reset.wav'))
                self.currentPage = 1
                self.set_info_page(1)
                self.updateImages()
                self.session.open(MessageBox, u"تم حذف جميع سجلات التقدم بنجاح", MessageBox.TYPE_INFO, timeout=3)
            except Exception as e:
                self.session.open(MessageBox,
                                  u"حدث خطأ أثناء حذف السجلات: {}".format(str(e)),
                                  MessageBox.TYPE_ERROR, timeout=3)

    def get_selected_audio_surah_index(self):
        # الحصول على فهرس السورة المحددة حالياً للتشغيل الصوتي
        if self.activeList == "surah_list":
            try:
                index = safe_menulist_index(self["surah_list"], len(self.suraList))
                if 0 <= index < len(self.suraList):
                    return index
            except Exception as e:
                print("[IqraaQuran] Cannot read selected surah index:", e)
        for idx, (sura_name, start_page) in enumerate(reversed(self.suraList)):
            if self.currentPage >= start_page:
                return len(self.suraList) - 1 - idx
        return -1

    def show_audio_controls(self):
        # فتح شاشة التحكم بالتلاوة الصوتية
        selected_surah_index = self.get_selected_audio_surah_index()
        if selected_surah_index != -1:
            self.session.open(AudioControlAndReciterScreen, self, selected_surah_index)
        else:
            self.session.open(AudioControlAndReciterScreen, self)

    def play_current_surah_audio(self):
        # تشغيل صوت السورة الحالية مباشرة بالقارئ الافتراضي
        current_sura_name = u""
        current_sura_index = -1
        for idx, (sura_name, start_page) in enumerate(reversed(self.suraList)):
            if self.currentPage >= start_page:
                current_sura_name = sura_name
                current_sura_index = len(self.suraList) - 1 - idx
                break
        if current_sura_index != -1:
            if self.reciters_data:
                reciter_key = list(self.reciters_data.keys())[1]
                reciter_info = self.reciters_data[reciter_key]
                surah_number_to_play = current_sura_index + 1
                if 1 <= surah_number_to_play <= reciter_info['count']:
                    audio_url = "{}{}.mp3".format(reciter_info['url'], str(surah_number_to_play).zfill(3))
                    if not self.audio_playing:
                        current_service = self.session.nav.getCurrentlyPlayingServiceReference()
                        if current_service and current_service.type != 4097:
                            self.last_service_before_audio = current_service
                        elif not current_service:
                            self.last_service_before_audio = None
                    self.play_audio_url(audio_url)
                    self.session.open(MessageBox, u"جاري تشغيل سورة {}".format(current_sura_name),
                                      MessageBox.TYPE_INFO, timeout=3)
                else:
                    self.session.open(MessageBox,
                                      u"لا يمكن تشغيل سورة {} لهذا القارئ".format(current_sura_name),
                                      MessageBox.TYPE_ERROR)
            else:
                self.session.open(MessageBox, u"لا يوجد قراء متاحون", MessageBox.TYPE_ERROR)
        else:
            self.session.open(MessageBox, u"لا يمكن تحديد السورة الحالية", MessageBox.TYPE_ERROR)

    def return_to_previous_page(self):
        # العودة إلى الصفحة المحفوظة قبل تذكير الكهف
        print("[IqraaQuran] PVR button pressed - return_to_previous_page called.")
        last_page = config.plugins.IqraaQuran.last_page_before_kahf.value
        if last_page > 0:
            self.currentPage = self.page_for_current_layout(last_page)
            self.updateImages()
            config.plugins.IqraaQuran.last_page_before_kahf.value = 0
            config.plugins.IqraaQuran.save()
            self.session.open(MessageBox, u"تم العودة إلى صفحة {}".format(last_page),
                              MessageBox.TYPE_INFO, timeout=3)
        else:
            self.session.open(MessageBox, u"لا توجد صفحة سابقة للعودة إليها.",
                              MessageBox.TYPE_INFO, timeout=3)

    def show_daily_portion_notification(self):
        # عرض إشعار الورد اليومي إذا لم يتم قراءته بعد
        if not self.session or self.is_daily_reading_done():
            print("[IqraaQuran ...] Daily portion already marked as read for today.")
            return
        start, end = self.daily_portion
        message = u"الورد اليومي: من صفحة {} إلى {}\nهل تريد البدء الآن؟".format(start, end)
        try:
            self.session.openWithCallback(self.start_daily_reading, MessageBox, message, MessageBox.TYPE_YESNO)
        except Exception as e:
            print("[IqraaQuran] Error showing daily reminder: {}".format(e))

    def start_daily_reading(self, answer):
        # بدء قراءة الورد اليومي عند موافقة المستخدم
        if answer:
            self.currentPage = self.daily_portion[0]
            self.set_info_page(self.currentPage)
            self.updateImages()
            self.mark_daily_reading_done()

    def is_daily_reading_done(self):
        # فحص إذا كان الورد اليومي قد اكتمل لهذا اليوم
        reminders = load_reminders()
        today = int(datetime.now().strftime("%Y%m%d"))
        return reminders.get("daily_reminder", {}).get("last_reading", 0) == today

    def mark_daily_reading_done(self):
        # تسجيل إتمام الورد اليومي في ملف التذكيرات
        reminders = load_reminders()
        if "daily_reminder" not in reminders:
            reminders["daily_reminder"] = {}
        reminders["daily_reminder"]["last_reading"] = int(datetime.now().strftime("%Y%m%d"))
        save_reminders(reminders)

    def convert_12h_to_24h(self, hour, ampm):
        # تحويل الوقت من نظام 12 ساعة إلى 24 ساعة
        if ampm == "PM" and hour < 12:
            return hour + 12
        elif ampm == "AM" and hour == 12:
            return 0
        else:
            return hour

    def check_reminder(self):
        # فحص وعرض التذكير اليومي
        reminders = load_reminders()
        daily_reminder = reminders["daily_reminder"]
        if daily_reminder["enabled"]:
            self.playSound(os.path.join(Sound_PATH, 'Daily_reminder.wav'))
            self.session.openWithCallback(
                self.daily_reminder_response, MessageBox,
                u"تذكير: حان وقت قراءة وردك اليومي من القرآن الكريم\nهل تريد بدء القراءة الآن؟",
                MessageBox.TYPE_YESNO
            )

    def daily_reminder_response(self, answer):
        # معالجة رد المستخدم على التذكير اليومي
        if answer:
            print("[IqraaQuran ...] بدأت القراءة الآن")
            self.show_daily_portion_notification()
        else:
            print(" [IqraaQuran ...] تم اختيار لا، سيتم تأجيل القراءة")

    def setup_reminder(self):
        # ضبط مؤقت التذكير العام
        reminders = load_reminders()
        if reminders["daily_reminder"]["enabled"]:
            now = datetime.now()
            reminder_hour = reminders["daily_reminder"]["time_hour"]
            reminder_minute = reminders["daily_reminder"]["time_minute"]
            reminder_ampm = reminders["daily_reminder"]["time_ampm"]
            reminder_hour_24 = self.convert_12h_to_24h(reminder_hour, reminder_ampm)
            reminder_time = now.replace(hour=reminder_hour_24, minute=reminder_minute, second=0)
            if now > reminder_time:
                reminder_time += timedelta(days=1)
            delay = (reminder_time - now).total_seconds() * 1000
            self.reminder_timer.start(int(delay), True)
            print("[IqraaQuran ...] تم ضبط التذكير العام للساعة {}:{} {}".format(
                reminder_hour, reminder_minute, reminder_ampm))

    def setup_reminder_timers(self):
        """إعداد مؤقتات التذكير"""
        reminders = load_reminders()
        daily_reminder = reminders["daily_reminder"]
        friday_reminder = reminders["friday_reminder"]
        # إعداد التذكير اليومي
        if daily_reminder["enabled"]:
            now = datetime.now()
            reminder_hour = daily_reminder["time_hour"]
            reminder_minute = daily_reminder["time_minute"]
            reminder_ampm = daily_reminder["time_ampm"]
            reminder_hour_24 = self.convert_12h_to_24h(reminder_hour, reminder_ampm)
            reminder_time = now.replace(hour=reminder_hour_24, minute=reminder_minute, second=0)
            if now > reminder_time:
                reminder_time += timedelta(days=1)
            delay = (reminder_time - now).total_seconds() * 1000
            self.daily_timer.start(int(delay), True)
            print("[IqraaQuran ...] تم ضبط التذكير اليومي للساعة {:02d}:{} {}".format(
                reminder_hour, reminder_minute, reminder_ampm))
        if friday_reminder["enabled"]:
            now = datetime.now()
            if now.weekday() == 4:
                today_str = int(now.strftime("%Y%m%d"))
                if reminders["friday_reminder"]["last_reminder"] != today_str:
                    reminder_hour = friday_reminder["time_hour"]
                    reminder_minute = friday_reminder["time_minute"]
                    reminder_ampm = friday_reminder["time_ampm"]
                    reminder_hour_24 = self.convert_12h_to_24h(reminder_hour, reminder_ampm)
                    next_time = now.replace(hour=reminder_hour_24, minute=reminder_minute, second=0)
                    if now < next_time:
                        delay = (next_time - now).total_seconds() * 1000
                        self.friday_timer.start(int(delay), True)
                        print("[IqraaQuran ...] تم ضبط تذكير الجمعة للساعة {:02d}:{} {}".format(
                            reminder_hour, reminder_minute, reminder_ampm))
            else:
                days_until_friday = (4 - now.weekday() + 7) % 7
                next_friday = (now + timedelta(days=days_until_friday)).replace(
                    hour=0, minute=0, second=1, microsecond=0)
                delay = (next_friday - now).total_seconds() * 1000
                self.temp_friday_check_timer = eTimer()
                self.temp_friday_check_timer.callback.append(self.setup_reminder_timers)
                self.temp_friday_check_timer.start(int(delay), True)
                print("[IqraaQuran ...] Scheduling Friday reminder check for next Friday in {} days".format(
                    days_until_friday))

    def show_kahf_reminder(self):
        # عرض تذكير قراءة سورة الكهف يوم الجمعة
        reminders = load_reminders()
        friday_reminder = reminders["friday_reminder"]
        if friday_reminder["enabled"]:
            today = int(datetime.now().strftime("%Y%m%d"))
            if reminders["friday_reminder"]["last_reminder"] != today:
                self.previous_page_before_reminder = self.currentPage
                self.playSound(os.path.join(Sound_PATH, 'kahf_reminder.wav'))
                self.session.openWithCallback(
                    self.handle_kahf_reminder_response, MessageBox,
                    u"تذكير: حان وقت قراءة وردك الإسبوعي لسورة الكهف من سنن يوم جمعة!\nهل تريد بدء قراءة سورة الكهف الآن؟",
                    MessageBox.TYPE_YESNO
                )
                reminders["friday_reminder"]["last_reminder"] = today
                save_reminders(reminders)
                print("[IqraaQuran ...] تم عرض تذكير سورة الكهف وتحديث التاريخ")

    def handle_kahf_reminder_response(self, answer):
        # معالجة رد المستخدم على تذكير الكهف
        if answer:
            self.open_kahf_after_reminder()
        else:
            self.return_to_previous_page_from_reminder()

    def open_kahf_after_reminder(self):
        # فتح صفحة سورة الكهف بعد موافقة المستخدم
        for sura_name, page_number in self.suraList:
            if sura_name == u"الكهف":
                self.currentPage = page_number
                self.set_info_page(page_number)
                self.updateImages()
                self.playSound(os.path.join(Sound_PATH, 'kahf_reminder.wav'))
                return
        print("[IqraaQuran ...] !لم يتم العثور على سورة الكهف")

    def return_to_previous_page_from_reminder(self):
        # العودة إلى الصفحة السابقة بعد رفض تذكير الكهف
        if hasattr(self, 'previous_page_before_reminder'):
            self.currentPage = self.previous_page_before_reminder
            self.set_info_page(self.currentPage)
            self.updateImages()
            del self.previous_page_before_reminder

    def open_settings(self):
        # فتح شاشة الإعدادات
        self.session.openWithCallback(self.on_settings_closed, QuranSettings, self)

    def on_settings_closed(self, result=None):
        # تطبيق الإعدادات بعد إغلاق شاشة الإعدادات
        self.reminders = load_reminders()
        self.setup_reminder()
        self.setup_reminder_timers()
        self.updateImages()

    def open_search(self):
        # فتح وظيفة البحث في القرآن
        global QURAN_INDEX
        if not QURAN_INDEX:
            if os.path.exists(index_path):
                try:
                    with open(index_path, 'rb') as f:
                        QURAN_INDEX = json.loads(f.read().decode('utf-8'))
                    print("تم تحميل الفهرس مباشرة دون الحاجة لإنشائه.")
                    self._open_keyboard_or_results()
                    return
                except Exception as e:
                    print("فشل تحميل الفهرس:", e)
                    QURAN_INDEX = defaultdict(list)
            self.loadingMessageBox = self.session.open(
                MessageBox,
                u"فهرس البحث غير متاح، جاري إعداده لمرة واحدة خلال دقيقتين.\n"
                u"وتستطيع استخدامه فيما بعد مباشرة بدون تحميل ... فصبراً جميلاً.",
                MessageBox.TYPE_INFO, timeout=0
            )
            self.indexLoadTimer = eTimer()
            self.indexLoadTimer.callback.append(self._start_index_loading)
            self.indexLoadTimer.start(500, True)
        else:
            self._open_keyboard_or_results()

    def _start_index_loading(self):
        # بدء تحميل أو إنشاء فهرس البحث
        global QURAN_INDEX
        print("جاري إعداد فهرس البحث...")
        if os.path.exists(index_path):
            try:
                with open(index_path, 'rb') as f:
                    QURAN_INDEX = json.loads(f.read().decode('utf-8'))
                print("تم تحميل فهرس البحث بنجاح.")
            except Exception as e:
                print("فشل تحميل فهرس البحث:", e)
                QURAN_INDEX = defaultdict(list)
        else:
            if os.path.exists(generate_script):
                try:
                    if _download_repo_file('quran_index.json', index_path, timeout=120):
                        with open(index_path, 'rb') as f:
                            QURAN_INDEX = json.loads(f.read().decode('utf-8'))
                        print("تم تنزيل فهرس البحث من الريبو وتحميله بنجاح.")
                    else:
                        # استخدام Python الحالي لتشغيل سكريبت الإنشاء
                        python_exe = sys.executable if sys.executable else 'python3'
                        _subprocess_run([python_exe, generate_script], check=True)
                        with open(index_path, 'rb') as f:
                            QURAN_INDEX = json.loads(f.read().decode('utf-8'))
                        print("تم إنشاء فهرس البحث وتحميله بنجاح.")
                except subprocess.CalledProcessError as e:
                    print("فشل إنشاء فهرس البحث:", e)
                    QURAN_INDEX = defaultdict(list)
                except Exception as e:
                    print("فشل تنزيل أو إنشاء فهرس البحث:", e)
                    QURAN_INDEX = defaultdict(list)
            else:
                if _download_repo_file('quran_index.json', index_path, timeout=120):
                    try:
                        with open(index_path, 'rb') as f:
                            QURAN_INDEX = json.loads(f.read().decode('utf-8'))
                        print("تم تنزيل فهرس البحث من الريبو وتحميله بنجاح.")
                    except Exception as e:
                        print("فشل تحميل فهرس البحث بعد تنزيله:", e)
                        QURAN_INDEX = defaultdict(list)
                else:
                    print("ملف generate_index.py غير موجود، وتعذر تنزيل quran_index.json!")
                    QURAN_INDEX = defaultdict(list)
        if hasattr(self, 'loadingMessageBox'):
            try:
                self.loadingMessageBox.close()
            except Exception:
                pass
        self.successMsgTimer = eTimer()
        self.successMsgTimer.callback.append(self._show_success_message)
        self.successMsgTimer.start(500, True)

    def _show_success_message(self):
        self.session.openWithCallback(
            self._after_index_ready, MessageBox,
            u"تم إعداد الفهرس بنجاح.\nشكراً لوقتك ... ابدأ البحث الآن.",
            MessageBox.TYPE_INFO, 5
        )

    def _after_index_ready(self, *args):
        self._open_keyboard_or_results()

    def _open_keyboard_or_results(self):
        # فتح لوحة المفاتيح أو عرض نتائج البحث المحفوظة
        if self.saved_search_results and self.saved_search_term:
            self.session.openWithCallback(
                self.goto_page_from_search, QuranSearchScreen,
                self, self.saved_search_term, self.saved_search_results, self.saved_search_index
            )
        else:
            self.session.openWithCallback(
                self.onSearchTextEntered, VirtualKeyBoard,
                title=to_enigma_string(u"أدخل كلمة البحث باللغة العربية")
            )

    def onSearchTextEntered(self, text=None):
        # معالجة نص البحث المُدخَل وعرض النتائج
        if text:
            results = self.search_quran(text)
            if results:
                self.playSound(os.path.join(Sound_PATH, 'results.wav'))
                self.session.openWithCallback(
                    self.goto_page_from_search, QuranSearchScreen,
                    self, text, results, 0
                )
            else:
                self.session.open(
                    MessageBox,
                    u"لم يتم العثور على نتائج للبحث عن: {}".format(text),
                    MessageBox.TYPE_INFO
                )

    def goto_page_from_search(self, page=None, results=None, search_term=None, selected_index=0):
        # الانتقال إلى صفحة نتيجة البحث وحفظ حالة البحث
        if results is not None:
            self.saved_search_results = results
            self.saved_search_term = search_term
            self.saved_search_index = selected_index
            print("[IqraaQuran ...] Saved search state: term=\"{}\", index={}".format(
                search_term, selected_index))
        if isinstance(page, int):
            self.set_info_page(page)
            self.currentPage = self.page_for_current_layout(page)
            self.from_search = True
            self.updateImagesTimer = eTimer()
            self.updateImagesTimer.callback.append(self.updateImages)
            self.updateImagesTimer.start(100, True)
            print("[IqraaQuran ...] Navigated to page {} from search.".format(self.currentPage))

    def is_matching_word(self, word, search_term, prefixes, suffixes):
        # فحص مطابقة كلمة مع مصطلح البحث مع مراعاة السوابق واللواحق
        if word == search_term:
            return True
        for prefix in prefixes:
            if len(prefix) < len(word) and word.startswith(prefix) and word[len(prefix):] == search_term:
                return True
        for suffix in suffixes:
            if len(suffix) < len(word) and word.endswith(suffix) and word[:-len(suffix)] == search_term:
                return True
        for prefix in prefixes:
            for suffix in suffixes:
                if (len(prefix) < len(word) and len(suffix) < len(word) and
                        word.startswith(prefix) and word.endswith(suffix) and
                        len(word) > len(prefix) + len(suffix) and
                        word[len(prefix):-len(suffix)] == search_term):
                    return True
        return False

    def highlight_search_term(self, text, search_term, prefixes, suffixes):
        # تمييز كلمة البحث في النص بأقواس مربعة
        words = text.split()
        result = []
        for word in words:
            clean_word = re.sub(r'[^\w\s]', '', word)
            if self.is_matching_word(clean_word, search_term, prefixes, suffixes):
                result.append("[ {} ]".format(word))
            else:
                result.append(word)
        return ' '.join(result)

    def search_quran(self, search_term):
        # البحث في فهرس القرآن عن الكلمة المطلوبة
        if not search_term:
            return []
        search_term = to_unicode(search_term)
        clean_search = clean_arabic_text(search_term)
        results = []
        seen_verses = set()
        for word, entries in QURAN_INDEX.items():
            word = to_unicode(word)
            clean_word = clean_arabic_text(word)
            if self.is_matching_word(clean_word, clean_search, self.prefixes, self.suffixes):
                for entry in entries:
                    verse_key = "{}:{}".format(entry['sura'], entry['verse'])
                    if verse_key not in seen_verses:
                        seen_verses.add(verse_key)
                        e = entry.copy()
                        e['clean_text'] = to_unicode(e.get('clean_text', ''))
                        e['sura_name'] = to_unicode(e.get('sura_name', ''))
                        e['highlighted_text'] = self.highlight_search_term(
                            e['clean_text'], clean_search, self.prefixes, self.suffixes
                        )
                        results.append(e)
        return results

    def close(self):
        # إغلاق البلاجين مع إيقاف الصوت إذا كان يعمل
        if self.audio_playing:
            self.stop_current_audio(restore_service=True)
        Screen.close(self)


def main(session, **kwargs):
    # نقطة الدخول الرئيسية للبلاجين - يُحمّل keymap ثم يفتح الشاشة
    load_plugin_keymap()
    check_for_update(session)


def autostartQuranReminder(reason, **kwargs):
    # بدء التذكيرات تلقائياً عند تشغيل Enigma2 إذا كانت مفعلة
    if reason == 0 and 'session' in kwargs:
        reminders = load_reminders()
        if (reminders.get("daily_reminder", {}).get("enabled") or
                reminders.get("friday_reminder", {}).get("enabled")):
            print("[IqraaQuran ...] Reminder is enabled, initializing reminder timers.")
            session = kwargs['session']
            session.open(QuranReminderAutoStartScreen)
        else:
            print("[IqraaQuran ...] No reminders enabled, skipping background process.")
    elif reason == 1:
        print("[IqraaQuran ...] Enigma2 shutting down.")
        pass


def Plugins(**kwargs):
    # تسجيل البلاجين في Enigma2 (قائمة الإضافات والتشغيل التلقائي)
    from Plugins.Plugin import PluginDescriptor
    return [
        PluginDescriptor(
            where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART],
            fnc=autostartQuranReminder
        ),
        PluginDescriptor(
            name=Plugin_name,
            description=to_enigma_string(u"عرض صفحات المصحف الشريف"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=main
        ),
        PluginDescriptor(
            name=Plugin_name,
            description=to_enigma_string(u"عرض صفحات المصحف الشريف"),
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main
        )
    ]
