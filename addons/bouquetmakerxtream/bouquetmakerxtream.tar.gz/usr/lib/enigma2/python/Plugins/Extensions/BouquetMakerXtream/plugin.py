#!/usr/bin/python
# -*- coding: utf-8 -*-

# Standard library imports
import os
import re
import requests
import shutil
import sys
import time
import twisted.python.runtime
from datetime import datetime, timedelta
from requests.adapters import HTTPAdapter, Retry
from Screens.Standby import inStandby


try:
    from urlparse import urljoin
except:
    from urllib.parse import urljoin


# Enigma2 components
from Components.ActionMap import HelpableActionMap
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigDirectory, ConfigYesNo, ConfigSelectionNumber, ConfigClock, ConfigPIN, ConfigInteger, configfile
from enigma import addFont, eServiceReference, eTimer, getDesktop
from Plugins.Plugin import PluginDescriptor
from Screens.ChannelSelection import ChannelSelectionBase
from ServiceReference import ServiceReference

# Local application/library-specific imports
from . import _
from . import bouquet_globals as glob

try:
    from multiprocessing.pool import ThreadPool
    hasMultiprocessing = True
except ImportError:
    hasMultiprocessing = False

try:
    from concurrent.futures import ThreadPoolExecutor
    if twisted.python.runtime.platform.supportsThreads():
        hasConcurrent = True
    else:
        hasConcurrent = False
except ImportError:
    hasConcurrent = False

pythonFull = float(str(sys.version_info.major) + "." + str(sys.version_info.minor))
pythonVer = sys.version_info.major

isDreambox = os.path.exists("/usr/bin/apt-get")

debugs = False

epgimporter = False
if os.path.isdir("/usr/lib/enigma2/python/Plugins/Extensions/EPGImport"):
    epgimporter = True


with open("/usr/lib/enigma2/python/Plugins/Extensions/BouquetMakerXtream/version.txt", "r") as f:
    version = f.readline()

screenwidth = getDesktop(0).size()


def choose_tmp_dir(min_free_mb=150):
    min_free = min_free_mb * 1024 * 1024  # convert MB to bytes

    candidates = [
        "/media/hdd",
        "/media/usb",
        "/etc/enigma2/bouquetmakerxtream/tmp"
    ]

    for path in candidates:
        if os.path.exists(path):
            try:
                stat = os.statvfs(path)
                free = stat.f_bavail * stat.f_frsize
                # free_mb = free / (1024 * 1024)
                # print("[Plugin][choose_tmp_dir] Path exists:", path, "Free MB:", int(free_mb))
                if free >= min_free:
                    # ensure directory exists
                    if not os.path.exists(path):
                        os.makedirs(path)
                    # print("[Plugin][choose_tmp_dir] Using path:", path)
                    return path
            except Exception as e:
                print("[Plugin][choose_tmp_dir] Failed to stat {}: {}".format(path, e))
                continue
        else:
            print("[Plugin][choose_tmp_dir] Path does not exist:", path)

    # Fallback to /tmp if nothing else works
    fallback = "/tmp"
    print("[Plugin][choose_tmp_dir] No suitable storage found, using fallback:", fallback)
    return fallback


_dir_tmp = None


def dir_tmp():
    global _dir_tmp
    if _dir_tmp is None:
        _dir_tmp = choose_tmp_dir()
    return _dir_tmp


dir_etc = "/etc/enigma2/bouquetmakerxtream/"
dir_plugins = "/usr/lib/enigma2/python/Plugins/Extensions/BouquetMakerXtream/"
dir_custom = "/media/hdd/picon/"

if screenwidth.width() == 2560:
    skin_directory = os.path.join(dir_plugins, "skin/uhd/")
elif screenwidth.width() > 1280:
    skin_directory = os.path.join(dir_plugins, "skin/fhd/")
else:
    skin_directory = os.path.join(dir_plugins, "skin/hd/")

folders = [folder for folder in os.listdir(skin_directory) if folder != "common"]

useragents = [
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36", "Chrome 145"),
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0", "Firefox 125"),
    ("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36", "Android")
]

# Configurations initialization
config.plugins.BouquetMakerXtream = ConfigSubsection()
cfg = config.plugins.BouquetMakerXtream

live_stream_type_choices = [("1", "DVB(1)"), ("4097", "IPTV(4097)")]
vod_stream_type_choices = [("4097", "IPTV(4097)")]

if os.path.exists("/usr/bin/gstplayer"):
    live_stream_type_choices.append(("5001", "GStreamer(5001)"))
    vod_stream_type_choices.append(("5001", "GStreamer(5001)"))

if os.path.exists("/usr/bin/exteplayer3"):
    live_stream_type_choices.append(("5002", "ExtePlayer(5002)"))
    vod_stream_type_choices.append(("5002", "ExtePlayer(5002)"))

if os.path.exists("/usr/bin/apt-get"):
    live_stream_type_choices.append(("8193", "DreamOS GStreamer(8193)"))
    vod_stream_type_choices.append(("8193", "DreamOS GStreamer(8193)"))

SizeList = [
    ("xpicons", _("XPicons - 220x132 Pixel")),
    ("zzzpicons", _("ZZZPicons - 400x240 Pixel"))]

cfg.live_type = ConfigSelection(default="4097", choices=live_stream_type_choices)
cfg.vod_type = ConfigSelection(default="4097", choices=vod_stream_type_choices)

cfg.location = ConfigDirectory(default=dir_etc)
cfg.local_location = ConfigDirectory(default=dir_etc)
cfg.main = ConfigYesNo(default=True)
cfg.skin = ConfigSelection(default="default", choices=folders)
cfg.parental = ConfigYesNo(default=False)
cfg.catchup_on = ConfigYesNo(default=False)
cfg.catchup = ConfigYesNo(default=False)
cfg.catchup_prefix = ConfigSelection(default="~", choices=[("~", "~"), ("!", "!"), ("#", "#"), ("-", "-"), ("^", "^")])
cfg.catchup_start = ConfigSelectionNumber(0, 30, 1, default=0, wraparound=True)
cfg.catchup_end = ConfigSelectionNumber(0, 30, 1, default=0, wraparound=True)
cfg.skip_playlists_screen = ConfigYesNo(default=False)
cfg.wakeup = ConfigClock(default=((9 * 60) + 0) * 60)  # 10:00
cfg.adult = ConfigYesNo(default=False)
cfg.adultpin = ConfigPIN(default=0000)
cfg.retries = ConfigSubsection()
cfg.retries.adultpin = ConfigSubsection()
cfg.retries.adultpin.tries = ConfigInteger(default=3)
cfg.retries.adultpin.time = ConfigInteger(default=3)
cfg.autoupdate = ConfigYesNo(default=False)
cfg.missedupdate = ConfigYesNo(default=False)
cfg.groups = ConfigYesNo(default=False)
cfg.location_valid = ConfigYesNo(default=True)
cfg.position = ConfigSelection(default="bottom", choices=[("bottom", _("Bottom")), ("top", _("Top"))])

cfg.picon_bitdepth = ConfigSelection(default="24bit", choices=[("24", _("24 Bit")), ("8bit", _("8 Bit"))])
cfg.picon_type = ConfigSelection(default="SRP", choices=[("SRP", _("Service Reference Picons")), ("SNP", _("Service Name Picons"))])
cfg.picon_overwrite = ConfigYesNo(default=False)
cfg.picon_size = ConfigSelection(default="xpicons", choices=SizeList)
cfg.picon_custom = ConfigDirectory(default=dir_custom)
cfg.max_threads = ConfigSelectionNumber(5, 40, 5, default=20, wraparound=True)
cfg.picon_max_size = ConfigSelection(default="100000", choices=[("100000", _("100KB")), ("200000", _("200KB")), ("300000", _("300KB")), ("400000", _("400KB")), ("500000", _("500KB")), ("0", _("No limit"))])
cfg.picon_max_width = ConfigSelection(default="1000", choices=[("480", _("480px")), ("728", _("728px")), ("1000", _("1000px")), ("1280", _("1280px")), ("1920", _("1920px")), ("0", _("No limit"))])

cfg.picon_location = ConfigSelection(default="/media/hdd/picon/", choices=[
    ("/media/hdd/picon/", "/media/hdd/picon"),
    ("/media/usb/picon/", "/media/usb/picon"),
    ("/media/mmc/picon/", "/media/mmc/picon"),
    ("/usr/share/enigma2/picon/", "/usr/share/enigma2/picon"),
    ("/picons/piconHD/", "/picons/piconHD"),
    ("/data/picon/", "/data/picon"),
    ("/data/picons//piconHD/", "/data/picons/piconHD"),
    ("custom", "Custom location")
]
)

cfg.useragent = ConfigSelection(default="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36", choices=useragents)

cfg.deepstandby = ConfigSelection(default="skip", choices=[
    ("wakeup", _("import after wake up")),
    ("skip", _("skip the import"))
])

# vti picon symlink - ln -s /media/hdd/picon /usr/share/enigma2
# newenigma2 symlink - # ln -s /data/picons /picons

# Set default file paths
playlist_file = os.path.join(dir_etc, "playlists.txt")
playlists_json = os.path.join(dir_etc, "bmx_playlists.json")

# Set skin and font paths
skin_path = os.path.join(skin_directory, cfg.skin.value)
common_path = os.path.join(skin_directory, "common/")

location = cfg.location.value
if location:
    if os.path.exists(location):
        playlist_file = os.path.join(cfg.location.value, "playlists.txt")
        cfg.location_valid.setValue(True)
    else:
        os.makedirs(location)  # Create directory if it doesn't exist
        playlist_file = os.path.join(location, "playlists.txt")

        cfg.location_valid.setValue(True)
else:
    cfg.location.setValue(dir_etc)
    cfg.location_valid.setValue(False)

cfg.save()
configfile.save()

font_folder = os.path.join(dir_plugins, "fonts/")
addFont(os.path.join(font_folder, "slyk-medium.ttf"), "slykregular", 100, 0)
addFont(os.path.join(font_folder, "slyk-bold.ttf"), "slykbold", 100, 0)
addFont(os.path.join(font_folder, "m-plus-rounded-1c-regular.ttf"), "bmxregular", 100, 0)
addFont(os.path.join(font_folder, "m-plus-rounded-1c-medium.ttf"), "bmxbold", 100, 0)

hdr = {
    'User-Agent': str(cfg.useragent.value),
}

# create folder for working files
if not os.path.exists(dir_etc):
    os.makedirs(dir_etc)

# delete temporary folder and contents
if os.path.exists("/tmp/bouquetmakerxtream/"):
    shutil.rmtree("/tmp/bouquetmakerxtream/")

# check if playlists.txt file exists in specified location
if not os.path.isfile(playlist_file):
    with open(playlist_file, "a") as f:
        f.close()

# check if playlists.json file exists in specified location
if not os.path.isfile(playlists_json):
    with open(playlists_json, "a") as f:
        f.close()


def main(session, **kwargs):
    from . import mainmenu

    session.open(mainmenu.BmxMainMenu)
    return


def mainmenu(menu_id, **kwargs):
    if menu_id == "mainmenu":
        return [(_("Bouquet Maker Xtream"), main, "BouquetMakerXtream", 49)]
    else:
        return []


# Global variables
bmxAutoStartTimer = None
originalref = None
originalrefstring = None

original_ChannelSelectionBase = ChannelSelectionBase.__init__
BmxChannelSelectionBase__init__ = None
_session = None


class BMXAutoStartTimer:
    def __init__(self, session):
        self.session = session
        self.timer = eTimer()
        self._running_update = False  # Prevent overlapping updates

        try:
            self.timer_conn = self.timer.timeout.connect(self.onTimer)
        except:
            self.timer.callback.append(self.onTimer)

        now = datetime.now()
        clock = cfg.wakeup.value
        scheduled_today = datetime(now.year, now.month, now.day, clock[0], clock[1], 0)

        # Run missed update shortly after boot if enabled and scheduled time has passed
        if cfg.autoupdate.value and cfg.missedupdate.value:
            if now >= scheduled_today:
                print("[BMXAutoStartTimer] Scheduling missed update shortly after boot")
                self.bootTimer = eTimer()
                try:
                    self.bootTimer_conn = self.bootTimer.timeout.connect(self.runUpdate)
                except:
                    self.bootTimer.callback.append(self.runUpdate)
                self.bootTimer.startLongTimer(60)  # 60-second delay after boot

        # Schedule the next daily wake
        self.update()

    def getWakeTime(self):
        if not cfg.autoupdate.value:
            return -1

        clock = cfg.wakeup.value
        now = datetime.now()
        dt = datetime(now.year, now.month, now.day, clock[0], clock[1], 0)

        # If scheduled time has already passed, schedule for next day
        if dt <= now:
            dt += timedelta(days=1)

        return int(time.mktime(dt.timetuple()))

    def update(self):
        self.timer.stop()
        wake = self.getWakeTime()
        nowtime = time.time()

        if wake > 0:
            next = wake - int(nowtime)

            # Cap maximum wait to 24 hours
            if next > 24 * 3600:
                next = 24 * 3600

            wake_dt = datetime.fromtimestamp(wake)
            print("[BMXAutoStartTimer] Next wake in %d seconds at %s" %
                  (next, wake_dt.strftime("%Y-%m-%d %H:%M:%S")))

            self.timer.startLongTimer(next)
        else:
            print("[BMXAutoStartTimer] Auto update disabled")

        return wake

    def onTimer(self):
        self.timer.stop()
        self.runUpdate()
        self.update()  # Schedule next day

    def runUpdate(self):
        if self._running_update:
            print("[BMXAutoStartTimer] Update already running, skipping...")
            return

        try:
            self._running_update = True
            print("\n*********** BouquetMakerXtream runupdate ************\n")
            if self.session and not inStandby:
                from . import update2
                self.session.open(update2.BmxUpdate, "auto")
            else:
                print("[BMX] Skipping splash (standby or UI not ready)")
        finally:
            self._running_update = False


def myBase(self, session, forceLegacy=False):
    original_ChannelSelectionBase(self, session)

    ChannelSelectionBase.showBmxCatchup = showBmxCatchup
    ChannelSelectionBase.playOriginalChannel = playOriginalChannel

    self["BmxCatchupAction"] = HelpableActionMap(self, "BMXCatchupActions", {
        "catchup": self.showBmxCatchup,
    })


def autostart(reason, session=None, **kwargs):
    global bmxAutoStartTimer
    global _session

    now = datetime.now()
    print("[BouquetMakerXtream] autostart (%s) occurred at %s" % (reason, now))

    if reason == 0 and session is not None:
        _session = session
        if bmxAutoStartTimer is None:
            bmxAutoStartTimer = BMXAutoStartTimer(session)

        # Replace ChannelSelectionBase.__init__ if needed
        if cfg.catchup_on.value and ChannelSelectionBase.__init__ != BmxChannelSelectionBase__init__:
            ChannelSelectionBase.__init__ = myBase
    else:
        print("[BouquetMakerXtream] Shutdown or other reason, no timer started")


def showBmxCatchup(self):
    try:
        global originalref
        global originalrefstring
        originalref = self.session.nav.getCurrentlyPlayingServiceReference()
        originalrefstring = originalref.toString()
    except:
        pass

    selected_ref = self["list"].getCurrent()
    selected_ref_string = selected_ref.toString()

    glob.currentref = ServiceReference(selected_ref)

    path = str(selected_ref.getPath())

    if "http" not in path:
        return

    glob.name = glob.currentref.getServiceName()

    is_catchup_channel = False
    ref_url = ""
    ref_stream = ""
    ref_stream_num = ""
    username = ""
    password = ""
    domain = ""

    original_path = ServiceReference(originalref).getPath()
    ref_url = glob.currentref.getPath()

    # http://domain.xyx:0000/live/user/pass/12345.ts

    if "/live/" not in ref_url:
        return

    ref_stream = ref_url.split("/")[-1]
    # 12345.ts

    ref_stream_num = int(ref_stream.split(".")[0])
    # 12345

    # get domain, username, password from path
    match1 = False
    if re.search(r"(https|http):\/\/[^\/]+\/(live|movie|series)\/[^\/]+\/[^\/]+\/\d+(\.m3u8|\.ts|$)", ref_url) is not None:
        match1 = True

    match2 = False
    if re.search(r"(https|http):\/\/[^\/]+\/[^\/]+\/[^\/]+\/\d+(\.m3u8|\.ts|$)", ref_url) is not None:
        match2 = True

    if match1:
        username = re.search(r"[^\/]+(?=\/[^\/]+\/\d+\.)", ref_url).group()
        password = re.search(r"[^\/]+(?=\/\d+\.)", ref_url).group()
        domain = re.search(r"(https|http):\/\/[^\/]+", ref_url).group()
    elif match2:
        username = re.search(r"[^\/]+(?=\/[^\/]+\/[^\/]+$)", ref_url).group()
        password = re.search(r"[^\/]+(?=\/[^\/]+$)", ref_url).group()
        domain = re.search(r"(https|http):\/\/[^\/]+", ref_url).group()

    get_live_streams = "%s/player_api.php?username=%s&password=%s&action=get_live_streams" % (domain, username, password)

    retries = Retry(total=1, backoff_factor=1)
    adapter = HTTPAdapter(max_retries=retries)

    with requests.Session() as http:
        http.mount("http://", adapter)
        http.mount("https://", adapter)
        response = ""

        try:
            # Use context manager for the response
            r = http.get(get_live_streams, headers=hdr, timeout=10, verify=False)
            r.raise_for_status()
            if r.status_code == requests.codes.ok:
                try:
                    response = r.json()
                except Exception as ex:
                    print("JSON parsing error:", ex)

        except Exception as exc:
            print("Request error:", exc)

    if response:
        live_streams = response

        is_catchup_channel = False
        for channel in live_streams:
            if channel["stream_id"] == ref_stream_num and int(channel["tv_archive"]) == 1:
                is_catchup_channel = True
                break

    if live_streams and is_catchup_channel:
        from . import catchup

        if (originalrefstring == selected_ref_string) or (urljoin(original_path, "/") == urljoin(ref_url, "/")):
            self.session.nav.stopService()
            self.session.openWithCallback(self.playOriginalChannel, catchup.BmxCatchup)
        else:
            self.session.open(catchup.BmxCatchup)


def playOriginalChannel(self, answer=None):
    self.session.nav.playService(eServiceReference(originalrefstring))


def Plugins(**kwargs):
    iconFile = "icons/plugin-icon.png" if screenwidth.width() > 1280 else "icons/plugin-icon_sd.png"
    description = _("IPTV Bouquets Creator by KiddaC")
    pluginname = _("BouquetMakerXtream")

    # Menus
    main_menu = PluginDescriptor(
        name=pluginname,
        description=description,
        where=PluginDescriptor.WHERE_MENU,
        fnc=mainmenu,
        needsRestart=True
    )
    extensions_menu = PluginDescriptor(
        name=pluginname,
        description=description,
        where=PluginDescriptor.WHERE_EXTENSIONSMENU,
        fnc=main,
        needsRestart=True
    )

    # Plugin descriptors list
    result = [
        PluginDescriptor(
            name=pluginname,
            description=description,
            where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART],
            fnc=autostart
        ),
        PluginDescriptor(
            name=pluginname,
            description=description,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=iconFile,
            fnc=main
        )
    ]

    # Append extensions and main menu if configured
    result.append(extensions_menu)
    if cfg.main.value:
        result.append(main_menu)

    return result
