# -*- coding: utf-8 -*-
"""
IPTV Dream v5.1 - ULEPSZONA WERSJA
- Zintegrowane z nowym systemem EPG
- Lepsze mapowanie do kanałów satelitarnych
- Eksport z informacjami EPG
"""

from Screens.Screen       import Screen
from Screens.MessageBox   import MessageBox
from Screens.ChoiceBox    import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.Label     import Label
from Components.Language  import language
from .export              import export_bouquets, add_to_bouquets_index
from .vkb_input           import VKInputBox
from .file_pick           import M3UFilePick
from .tools.mac_portal    import (load_mac_json, save_mac_json, parse_mac_playlist, add_mac_portal)
from .tools.updater       import check_update, do_update
from .tools.lang          import _
from .tools.xtream_one_window import XtreamOneWindow
from .tools.bouquet_picker    import BouquetPicker
from .tools.epg_picon         import fetch_epg_for_playlist, download_picon_url, install_epg_sources, EPG_URL_KEY
from .tools.webif         import start_web_server, stop_web_server

import os, json, re, threading, socket
import requests
from twisted.internet import reactor
from enigma import quitMainloop
from enigma import eDVBDB 
from datetime import date 

PROFILES      = "/etc/enigma2/iptvdream_profiles.json"
MY_LINKS_FILE = "/etc/enigma2/iptvdream_mylinks.json"
PLUGIN_VERSION = "5.1" 
WEB_IF_PORT = 9999
DL_TIMEOUT = 15

PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))
PIC_PATH = os.path.join(PLUGIN_PATH, "pic")

def run_in_thread(blocking_func, on_done_callback, *args, **kwargs):
    """Uruchamia funkcję w wątku."""
    def thread_target():
        try:
            result = blocking_func(*args, **kwargs)
            reactor.callFromThread(on_done_callback, result, None)
        except Exception as e:
            reactor.callFromThread(on_done_callback, None, str(e))
    t = threading.Thread(target=thread_target)
    t.daemon = True
    t.start()

def get_lan_ip():
    """Pobiera lokalny adres IP."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except: 
        return "127.0.0.1"

# --- SUPER AGRESYWNY PARSER M3U (NAPRAWA GRUP) ---
def parse_m3u_bytes_improved(data, content_filter='all'):
    """Parser M3U z ulepszoną detekcją XXX i VOD."""
    out = []
    try: 
        text = data.decode("utf-8", "ignore")
    except: 
        text = str(data)
    
    # Regexy
    rx_attrs = re.compile(r'([a-zA-Z0-9_-]+)\s*=\s*("[^"]*"|[^,;\s]+)')
    rx_bracket_group = re.compile(r'^\[([^\]]+)\]')
    rx_adult = re.compile(r'(xxx|adult|porn|sex|erotic|18\+|mature)', re.IGNORECASE)
    rx_vod = re.compile(r'(vod|movie|film|video|series|serial)', re.IGNORECASE)
    
    lines = text.splitlines()
    current_entry = {}
    
    for line in lines:
        line = line.strip()
        if not line: 
            continue
        
        # 1. Analiza linii EXTINF
        if line.startswith("#EXTINF"):
            current_entry = {} 
            
            if ',' in line:
                parts = line.split(',', 1)
                meta_part = parts[0]
                current_entry["title"] = parts[1].strip() if len(parts) > 1 else "No Name"
            else:
                meta_part = line
                current_entry["title"] = "No Name"

            # Szukanie atrybutów
            attrs = rx_attrs.findall(meta_part)
            for key, val in attrs:
                clean_val = val.replace('"', '').strip()
                key_lower = key.lower()
                
                if key_lower in ["group-title", "group", "category", "cat"]:
                    current_entry["group"] = clean_val
                elif key_lower in ["tvg-logo", "logo"]:
                    current_entry["logo"] = clean_val
                elif key_lower in ["tvg-id", "epg-id", "id"]:
                    current_entry["epg_id"] = clean_val
            
            # Jeśli nadal brak grupy, szukamy w tytule
            if "group" not in current_entry:
                m_grp = rx_bracket_group.match(current_entry["title"])
                if m_grp:
                     current_entry["group"] = m_grp.group(1).strip()

        # 2. Analiza linii #EXTGRP
        elif line.startswith("#EXTGRP:"):
            grp_name = line.split(":", 1)[1].strip()
            if grp_name:
                current_entry["group"] = grp_name

        # 3. Analiza URL
        elif "://" in line and not line.startswith("#"):
            url = line.strip()
            
            if not current_entry:
                name = url.split('/')[-1]
                name = re.sub(r'\.(ts|m3u8|mp4|mkv)$', '', name, flags=re.IGNORECASE)
                current_entry = {"title": name}

            # Określenie grupy na podstawie zawartości
            if "group" not in current_entry or not current_entry["group"]:
                title_lower = current_entry.get("title", "").lower()
                
                # Wykrywanie kanałów dla dorosłych
                if rx_adult.search(title_lower):
                    current_entry["group"] = "XXX"
                # Wykrywanie VOD
                elif rx_vod.search(title_lower):
                    current_entry["group"] = "VOD"
                # Wykrywanie filmów/seriali po URL
                elif '/movie/' in url.lower() or '/series/' in url.lower():
                    current_entry["group"] = "VOD"
                else:
                    current_entry["group"] = "Inne"

            # Logika VOD
            is_vod = False
            if '/movie/' in url or '/series/' in url: 
                is_vod = True
            elif url.lower().endswith(('.mp4', '.mkv', '.avi', '.vod', '.mp3', '.flac')): 
                is_vod = True
            elif rx_vod.search(current_entry.get("group", "")): 
                is_vod = True
            
            # Filtrowanie
            skip = False
            if content_filter == 'live' and is_vod: 
                skip = True
            if content_filter == 'vod' and not is_vod: 
                skip = True
            if content_filter == 'adult' and not (rx_adult.search(current_entry.get("group", "")) or rx_adult.search(current_entry.get("title", ""))): 
                skip = True
            
            if not skip:
                out.append({
                    "title":  current_entry.get("title", "No Name"),
                    "url":    url,
                    "group":  current_entry.get("group", "Inne"), 
                    "logo":   current_entry.get("logo", ""),
                    "epg_id": current_entry.get("epg_id", "")
                })
            
            current_entry = {} 

    return out

def load_profiles():
    """Wczytuje profile użytkownika."""
    try:
        if os.path.exists(PROFILES):
            with open(PROFILES, "r") as f: 
                return json.load(f)
    except: 
        pass
    return {}

def save_profiles(data):
    """Zapisuje profile użytkownika."""
    try:
        with open(PROFILES, "w") as f: 
            json.dump(data, f, indent=2, ensure_ascii=False)
    except: 
        pass

class IPTVDreamMain(Screen):
    """Główna klasa wtyczki IPTV Dream."""
    
    skin = """
    <screen name="IPTVDreamMain" position="center,center" size="1050,720" title="IPTV Dream v5.1">
        
        <eLabel position="0,0" size="1050,60" backgroundColor="#202020" zPosition="-1" />
        <widget name="version_label" position="0,10" size="1050,40" font="Regular;32" halign="center" valign="center" foregroundColor="#ffcc00" backgroundColor="#202020" transparent="1" />

        <eLabel position="0,60" size="1050,40" backgroundColor="#004400" zPosition="-1" />
        <widget name="status" position="0,60" size="1050,40" font="Regular;24" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#004400" transparent="1" />

        <eLabel text="1" position="20,120" size="50,50" font="Regular;35" halign="center" valign="center" foregroundColor="white" backgroundColor="#1f771f" cornerRadius="5"/>
        <eLabel text="M3U URL" position="80,120" size="150,50" font="Regular;24" halign="left" valign="center"/>
        <widget name="lab1" position="230,120" size="280,50" font="Regular;20" halign="left" valign="center" foregroundColor="#aaaaaa"/>

        <eLabel text="2" position="20,180" size="50,50" font="Regular;35" halign="center" valign="center" foregroundColor="white" backgroundColor="#1f771f" cornerRadius="5"/>
        <widget name="lbl_m3u_file" position="80,180" size="150,50" font="Regular;24" halign="left" valign="center" transparent="1"/>
        <widget name="lab2" position="230,180" size="280,50" font="Regular;20" halign="left" valign="center" foregroundColor="#aaaaaa"/>

        <eLabel text="3" position="20,240" size="50,50" font="Regular;35" halign="center" valign="center" foregroundColor="white" backgroundColor="#1f771f" cornerRadius="5"/>
        <eLabel text="Xtream" position="80,240" size="150,50" font="Regular;24" halign="left" valign="center"/>
        <widget name="lab3" position="230,240" size="280,50" font="Regular;20" halign="left" valign="center" foregroundColor="#aaaaaa"/>

        <eLabel text="4" position="20,300" size="50,50" font="Regular;35" halign="center" valign="center" foregroundColor="white" backgroundColor="#1f771f" cornerRadius="5"/>
        <eLabel text="MAC Portal" position="80,300" size="150,50" font="Regular;24" halign="left" valign="center"/>
        <widget name="lab4" position="230,300" size="280,50" font="Regular;20" halign="left" valign="center" foregroundColor="#aaaaaa"/>

        <eLabel text="9" position="20,360" size="50,50" font="Regular;35" halign="center" valign="center" foregroundColor="white" backgroundColor="#8B0000" cornerRadius="5"/>
        <widget name="lab9_name" position="80,360" size="150,50" font="Regular;24" halign="left" valign="center"/>
        <widget name="lab9_val" position="230,360" size="280,50" font="Regular;20" halign="left" valign="center" foregroundColor="#00ccff"/>

        <eLabel text="5" position="540,120" size="50,50" font="Regular;35" halign="center" valign="center" foregroundColor="white" backgroundColor="#555555" cornerRadius="5"/>
        <widget name="lbl_custom" position="600,120" size="150,50" font="Regular;24" halign="left" valign="center" transparent="1"/>
        <widget name="lab5" position="750,120" size="280,50" font="Regular;20" halign="left" valign="center" foregroundColor="#aaaaaa"/>

        <eLabel text="6" position="540,180" size="50,50" font="Regular;35" halign="center" valign="center" foregroundColor="white" backgroundColor="#800080" cornerRadius="5"/>
        <widget name="lbl_lang" position="600,180" size="150,50" font="Regular;24" halign="left" valign="center" transparent="1"/>
        <widget name="lab6" position="750,180" size="280,50" font="Regular;20" halign="left" valign="center" foregroundColor="#aaaaaa"/>

        <eLabel text="7" position="540,240" size="50,50" font="Regular;35" halign="center" valign="center" foregroundColor="white" backgroundColor="#ff8000" cornerRadius="5"/>
        <eLabel text="EPG URL" position="600,240" size="150,50" font="Regular;24" halign="left" valign="center"/>
        <widget name="lab7" position="750,240" size="280,50" font="Regular;20" halign="left" valign="center" foregroundColor="#aaaaaa"/>

        <eLabel text="8" position="540,300" size="50,50" font="Regular;35" halign="center" valign="center" foregroundColor="white" backgroundColor="#0000ff" cornerRadius="5"/>
        <widget name="lab8_status" position="600,300" size="150,50" font="Regular;24" halign="left" valign="center"/>
        <widget name="lab8_info" position="750,300" size="280,50" font="Regular;20" halign="left" valign="center" foregroundColor="#00ccff"/>

        <eLabel position="20,440" size="1010,2" backgroundColor="#333333" />

        <ePixmap pixmap="{pic_path}/qrcode.png" position="20,460" size="120,120" alphatest="blend" transparent="1" />
        <widget name="support_label" position="150,460" size="380,120" font="Regular;22" halign="left" valign="center" foregroundColor="#00ff00" transparent="1"/>

        <widget name="info" position="540,460" size="490,40" font="Regular;20" halign="center" valign="center" foregroundColor="yellow"/>
        <widget name="foot" position="540,540" size="490,30" font="Regular;16" halign="center" valign="center" foregroundColor="grey"/>

        <eLabel position="20,660" size="240,40" backgroundColor="#b30000" zPosition="1" cornerRadius="5" />
        <widget name="key_red" position="20,660" size="240,40" font="Regular;22" halign="center" valign="center" foregroundColor="white" backgroundColor="#b30000" transparent="1" zPosition="2" />

        <eLabel position="275,660" size="240,40" backgroundColor="#007f00" zPosition="1" cornerRadius="5" />
        <widget name="key_green" position="275,660" size="240,40" font="Regular;22" halign="center" valign="center" foregroundColor="white" backgroundColor="#007f00" transparent="1" zPosition="2" />

        <eLabel position="530,660" size="240,40" backgroundColor="#cccc00" zPosition="1" cornerRadius="5" />
        <widget name="key_yellow" position="530,660" size="240,40" font="Regular;22" halign="center" valign="center" foregroundColor="black" backgroundColor="#cccc00" transparent="1" zPosition="2" />

        <eLabel position="785,660" size="240,40" backgroundColor="#0000b3" zPosition="1" cornerRadius="5" />
        <widget name="key_blue" position="785,660" size="240,40" font="Regular;22" halign="center" valign="center" foregroundColor="white" backgroundColor="#0000b3" transparent="1" zPosition="2" />

    </screen>""".replace("{pic_path}", PIC_PATH)

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.playlist = []
        self.listname = "IPTV-Dream"
        self.prof = load_profiles()
        self.webif_running = False
        self.service_type = self.prof.get("service_type", "4097")
        self.xtream_data = None
        
        sys_lang = language.getLanguage()[:2] 
        self.lang = "pl" if sys_lang == "pl" else "en"

        self["lbl_m3u_file"] = Label("M3U Plik" if self.lang == "pl" else "M3U File")
        self["lbl_custom"] = Label("Własne" if self.lang == "pl" else "Custom")
        self["lbl_lang"] = Label("Język" if self.lang == "pl" else "Language")
        
        self.setTitle(f"IPTV Dream v{PLUGIN_VERSION}")
        self["version_label"] = Label(f"IPTV Dream v{PLUGIN_VERSION}")
        self["foot"] = Label("")
        self["lab8_status"] = Label("")
        self["lab8_info"] = Label("")
        self["lab9_name"] = Label("")
        self["lab9_val"]  = Label("")
        self["support_label"] = Label(_("support_text_long", self.lang))
        self["status"] = Label("") 

        self.updateLangStrings()
        self["actions"] = ActionMap(["ColorActions", "NumberActions", "OkCancelActions"], {
            "1": self.openUrl, "2": self.openFile, "3": self.openXtream,
            "4": self.openMacMenu,
            "5": self.openMyLinks, "6": self.toggleLang,
            "7": self.openEpgUrl, "8": self.toggleWebIf, "9": self.togglePlayer,
            "red": self.close, "green": self.checkUpdates, 
            "yellow": self.forceInstallEPG,
            "blue": self.exportBouquet, "cancel": self.close
        }, -1)
        self.onLayoutFinish.append(self.startAutoCheck)
        self.onLayoutFinish.append(self.checkWebIfStatus)

    # --- BEZPIECZNE MENU ZARZĄDZANIA MAC (ChoiceBox zamiast własnego Screena) ---
    def openMacMenu(self):
        portals = load_mac_json()
        
        # Główne menu: lista portali + "Dodaj nowy"
        options = []
        options.append((_("Dodaj nowy portal MAC", self.lang), "NEW"))
        
        for idx, p in enumerate(portals):
            name = p.get('name', 'Portal')
            label = f"{name} ({p.get('host')})"
            options.append((label, idx))
        
        # Dodaj opcję zarządzania wszystkimi portalami
        options.append((_("Zarządzaj wszystkimi portalami MAC", self.lang), "MANAGE_ALL"))
            
        self.session.openWithCallback(self.onPortalSelect, ChoiceBox, title=_("mac_select_title", self.lang), list=options)

    def onPortalSelect(self, choice):
        if not choice: 
            return
        val = choice[1]
        
        if val == "NEW":
            self.session.openWithCallback(self.onMacJson, VirtualKeyBoard, title="JSON", text="")
        elif val == "MANAGE_ALL":
            self.manageAllMacPortals()
        elif isinstance(val, int): # Wybrano istniejący portal (indeks)
            # Pytamy co zrobić: Załaduj czy Usuń?
            self.selected_portal_idx = val
            actions = [
                (_("Załaduj listę", self.lang), "LOAD"),
                (_("Usuń wpis", self.lang), "DELETE"),
                (_("Edytuj wpis", self.lang), "EDIT")
            ]
            self.session.openWithCallback(self.onPortalAction, ChoiceBox, title=_("Wybierz akcję:", self.lang), list=actions)

    def manageAllMacPortals(self):
        portals = load_mac_json()
        if not portals:
            self.session.open(MessageBox, _("Brak zapisanych portali MAC", self.lang), MessageBox.TYPE_INFO)
            return
            
        options = []
        for idx, p in enumerate(portals):
            name = p.get('name', 'Portal')
            label = f"{name} ({p.get('host')})"
            options.append((label, idx))
        
        self.session.openWithCallback(self.onDeleteMultipleMac, ChoiceBox, title=_("Wybierz portale do usunięcia (OK = usuń):", self.lang), list=options)

    def onDeleteMultipleMac(self, choice):
        if not choice: 
            return
        idx = choice[1]
        
        portals = load_mac_json()
        if 0 <= idx < len(portals):
            portal_name = portals[idx].get('name', portals[idx].get('host', 'Nieznany'))
            
            def confirmDelete(answer):
                if answer:
                    del portals[idx]
                    save_mac_json(portals)
                    self.session.open(MessageBox, _("Portal MAC usunięty: %s", self.lang) % portal_name, MessageBox.TYPE_INFO)
                    # Ponownie otwórz menu zarządzania
                    self.manageAllMacPortals()
            
            self.session.openWithCallback(confirmDelete, MessageBox, 
                _("Czy na pewno chcesz usunąć portal: %s?", self.lang) % portal_name, 
                MessageBox.TYPE_YESNO)

    def onPortalAction(self, choice):
        if not choice: 
            return
        action = choice[1]
        portals = load_mac_json()
        idx = self.selected_portal_idx
        
        if action == "LOAD":
            if 0 <= idx < len(portals):
                p = portals[idx]
                self.startMacDownload(p["host"], p["mac"])
                
        elif action == "DELETE":
            if 0 <= idx < len(portals):
                portal_name = portals[idx].get('name', portals[idx].get('host', 'Nieznany'))
                
                def confirmDelete(answer):
                    if answer:
                        del portals[idx]
                        save_mac_json(portals)
                        self.session.open(MessageBox, _("Portal MAC usunięty: %s", self.lang) % portal_name, MessageBox.TYPE_INFO)
                
                self.session.openWithCallback(confirmDelete, MessageBox, 
                    _("Czy na pewno chcesz usunąć portal: %s?", self.lang) % portal_name, 
                    MessageBox.TYPE_YESNO)
                    
        elif action == "EDIT":
            if 0 <= idx < len(portals):
                portal = portals[idx]
                current_json = json.dumps(portal, indent=2, ensure_ascii=False)
                self.session.openWithCallback(lambda x: self.onMacEditDone(x, idx), 
                    VirtualKeyBoard, title=_("Edytuj dane portalu:", self.lang), text=current_json)

    def onMacEditDone(self, new_json, idx):
        if not new_json: 
            return
        try:
            portals = load_mac_json()
            new_data = json.loads(new_json)
            if new_data.get("host") and new_data.get("mac"):
                portals[idx] = new_data
                save_mac_json(portals)
                self.session.open(MessageBox, _("Portal MAC zaktualizowany", self.lang), MessageBox.TYPE_INFO)
            else:
                self.session.open(MessageBox, _("mac_no_host_mac", self.lang), MessageBox.TYPE_ERROR)
        except Exception as e:
            self.session.open(MessageBox, f"JSON Error: {e}", MessageBox.TYPE_ERROR)

    def startMacDownload(self, host, mac):
        self["status"].setText(_("downloading_mac", self.lang))
        reactor.callInThread(self._mac_thread_worker, host, mac)

    def startAutoCheck(self):
        if self.prof.get("auto_update", False):
            self.checkUpdates(silent=True)
            
    def togglePlayer(self):
        if self.service_type == "4097":
            self.service_type = "5002"
        else:
            self.service_type = "4097"
        self.prof["service_type"] = self.service_type
        save_profiles(self.prof)
        self.updatePlayerLabel()
        
    def updatePlayerLabel(self):
        self["lab9_name"].setText(_("player_type", self.lang))
        if self.service_type == "4097":
            self["lab9_val"].setText(_("gst_player", self.lang))
        else:
            self["lab9_val"].setText(_("exte_player", self.lang))

    def checkWebIfStatus(self):
        enabled = self.prof.get("webif_enabled", False)
        if enabled:
             if not self.webif_running:
                 self.startWebIf()
             else:
                 self.updateWebIfLabel(True)
        else:
             self.updateWebIfLabel(False)

    def startWebIf(self):
        start_web_server(
            port=WEB_IF_PORT, 
            on_data_ready=lambda data: reactor.callFromThread(self._handle_webif_data, data)
        )
        self.webif_running = True
        self.updateWebIfLabel(True)

    def toggleWebIf(self):
        if self.webif_running:
            stop_web_server()
            self.prof["webif_enabled"] = False
            self.webif_running = False
            self.updateWebIfLabel(False)
            self["status"].setText(_("webif_stopped", self.lang))
        else:
            self.startWebIf()
            self.prof["webif_enabled"] = True
            self["status"].setText(_("webif_started", self.lang))
            
        save_profiles(self.prof)

    def updateWebIfLabel(self, is_running):
        ip = get_lan_ip()
        if is_running:
            self["lab8_info"].setText(f"http://{ip}:{WEB_IF_PORT}")
        else:
            self["lab8_info"].setText(_("webif_off", self.lang))

    def _handle_webif_data(self, data):
        dtype = data.get("type")
        if dtype == "m3u":
            self.session.open(MessageBox, f"{_('webif_received', self.lang)}: {dtype.upper()}", MessageBox.TYPE_INFO, timeout=3)
            url = data.get("url")
            self.onUrlReady(url)
        elif dtype == "xtream":
            self.session.open(MessageBox, f"{_('webif_received', self.lang)}: {dtype.upper()}", MessageBox.TYPE_INFO, timeout=3)
            host = data.get("host")
            user = data.get("user")
            pwd  = data.get("pass")
            if host and user and pwd:
                self.onXtreamOne((host, user, pwd))
        elif dtype == "mac":
            host = data.get("host")
            mac  = data.get("mac")
            if host and mac:
                add_mac_portal(host, mac)
                self.session.open(MessageBox, _("mac_added_info", self.lang), MessageBox.TYPE_INFO)

    def updateLangStrings(self):
        """Aktualizuje łańcuchy językowe."""
        self["key_red"]    = Label(_("exit", self.lang))
        self["key_green"]  = Label(_("check_upd", self.lang))
        self["key_yellow"] = Label(_("epg_install", self.lang))
        self["key_blue"]   = Label(_("export", self.lang))
        
        self["lab1"] = Label(_("load_url", self.lang))
        self["lab2"] = Label(_("pick_file", self.lang))
        self["lab3"] = Label(_("xtream", self.lang))
        self["lab4"] = Label(_("mac_json", self.lang))
        self["lab5"] = Label(_("own_links", self.lang))
        self["lab6"] = Label(_("toggle_lang", self.lang))
        self["lab7"] = Label(_("url_epg", self.lang))
        self["lab8_status"] = Label(_("webif_status", self.lang))
        self.updatePlayerLabel()
        self["support_label"].setText(_("support_text_long", self.lang))
        self.checkWebIfStatus()
        self["info"]   = Label(_("press_1_6", self.lang))
        self["status"] = Label("")
        
        today_date = date.today().strftime("%Y-%m-%d")
        foot_text = _("foot", self.lang).replace("{date}", today_date)
        self["foot"].setText(f"{foot_text} v{PLUGIN_VERSION}")

    # --- XTREAM VOD LOGIC ---
    def openXtream(self):
        self.session.openWithCallback(self.onXtreamOne, XtreamOneWindow)

    def onXtreamOne(self, data):
        if not data: 
            return
        self.xtream_data = data 
        options = [
            (_("xt_live", self.lang), "live"),
            (_("xt_vod", self.lang), "vod"),
            (_("xt_all", self.lang), "all"),
            (_("xt_adult", self.lang), "adult")  # NOWOŚĆ
        ]
        self.session.openWithCallback(self.onXtreamTypeSelected, ChoiceBox, title=_("xt_select_type", self.lang), list=options)

    def onXtreamTypeSelected(self, choice):
        if not choice: 
            return
        content_type = choice[1]
        host, user, pwd = self.xtream_data
        
        self["status"].setText(_("downloading_xtream", self.lang))
        
        def do_dl():
            base = host if host.startswith("http") else f"http://{host}"
            url = f"{base}/get.php?username={user}&password={pwd}&type=m3u_plus&output=ts"
            r = requests.get(url, timeout=DL_TIMEOUT, verify=False)
            r.raise_for_status()
            return r.content
        run_in_thread(do_dl, lambda res, err: self.onXtreamDone(res, err, user, content_type))

    def onXtreamDone(self, data, error, user, content_type):
        if error:
            self["status"].setText(_("xtream_error", self.lang))
            self.session.open(MessageBox, f"Xtream Error: {error}", MessageBox.TYPE_ERROR)
            return
        
        playlist = parse_m3u_bytes_improved(data, content_filter=content_type)
        
        if not playlist:
            self.session.open(MessageBox, _("empty_channel_list", self.lang), MessageBox.TYPE_ERROR)
            return
            
        suffix = "LIVE" if content_type == 'live' else "VOD" if content_type == 'vod' else "ADULT" if content_type == 'adult' else "ALL"
        self.onListLoaded(playlist, f"Xtream-{user}-{suffix}")

    # --- STANDARDOWE FUNKCJE ---
    def openEpgUrl(self):
        current_url = self.prof.get(EPG_URL_KEY, "http://")
        self.session.openWithCallback(self.onEpgUrlReady, VirtualKeyBoard, title=_("Wklej URL EPG:", self.lang), text=current_url)

    def onEpgUrlReady(self, url):
        if not url: 
            return
        self.prof[EPG_URL_KEY] = url
        save_profiles(self.prof)
        self.session.open(MessageBox, _("epg_url_saved_info", self.lang), MessageBox.TYPE_INFO)

    def forceInstallEPG(self):
        custom_url = self.prof.get(EPG_URL_KEY)
        success, msg = install_epg_sources(custom_url=custom_url)
        if success:
            self.session.open(MessageBox, f"{msg}\n\n{_('epg_install_success_info', self.lang)}", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, f"{_('error', self.lang)}: {msg}", MessageBox.TYPE_ERROR)

    def openUrl(self):
        last_url = self.prof.get("last_url", "http://")
        self.session.openWithCallback(self.onUrlReady, VirtualKeyBoard, title=_("Wklej link M3U:", self.lang), text=last_url)

    def onUrlReady(self, url):
        if not url or not url.startswith(('http://', 'https://')): 
            return
        self._current_url = url
        self["status"].setText(_("downloading", self.lang)) 
        
        def do_download(target_url):
            headers = {'User-Agent': 'Mozilla/5.0'}
            r = requests.get(target_url, timeout=DL_TIMEOUT, headers=headers, verify=False)
            r.raise_for_status()
            return r.content
        run_in_thread(do_download, self.onDataDownloaded, url)

    def onDataDownloaded(self, data, error):
        if error:
            self["status"].setText(_("download_error", self.lang)) 
            self.session.open(MessageBox, f"URL Error: {error}", MessageBox.TYPE_ERROR)
            return
        playlist = parse_m3u_bytes_improved(data)
        self.prof["last_url"] = self._current_url
        save_profiles(self.prof)
        self.onListLoaded(playlist, "M3U-URL")

    def openFile(self):
        self.session.openWithCallback(self.onFileReady, M3UFilePick, start_dir="/tmp/")

    def onFileReady(self, path):
        if not path: 
            return
        try:
            with open(path, "rb") as f: 
                data = f.read()
            playlist = parse_m3u_bytes_improved(data)
            name = os.path.splitext(os.path.basename(path))[0]
            self.onListLoaded(playlist, name)
        except Exception as e:
            self.session.open(MessageBox, f"File error: {e}", MessageBox.TYPE_ERROR)

    def onMacJson(self, txt):
        if not txt: 
            return
        try:
            self.data = json.loads(txt)
            if self.data.get("host") and self.data.get("mac"):
                self.startMacDownload(self.data["host"], self.data["mac"])
            else:
                self.session.open(MessageBox, _("mac_no_host_mac", self.lang), MessageBox.TYPE_ERROR)
        except Exception as e:
            self.session.open(MessageBox, f"JSON Error: {e}", MessageBox.TYPE_ERROR)

    def _mac_thread_worker(self, host, mac):
        try:
            playlist = parse_mac_playlist(host, mac)
            reactor.callFromThread(self._mac_thread_done, playlist, None)
        except Exception as e:
            reactor.callFromThread(self._mac_thread_done, None, str(e))

    def _mac_thread_done(self, playlist, error):
        if error:
            self["status"].setText(_("mac_error", self.lang))
            self.session.open(MessageBox, str(error), MessageBox.TYPE_ERROR)
            return
        try:
            if not playlist:
                self.session.open(MessageBox, _("portal_returned_zero", self.lang), MessageBox.TYPE_ERROR)
                self.onListLoaded([], "MAC-Portal")
                return
        except Exception as e:
            print(f"[IPTVDream] Błąd: {e}")
        self.onListLoaded(playlist, "MAC-Portal")

    # --- BEZPIECZNE MENU ZARZĄDZANIA WŁASNYMI LINKAMI ---
    def openMyLinks(self):
        if not os.path.exists(MY_LINKS_FILE):
             self.session.open(MessageBox, _("no_saved_links", self.lang), MessageBox.TYPE_INFO)
             return

        try:
            with open(MY_LINKS_FILE) as f: 
                links = json.load(f)
        except: 
            links = []

        if not links:
            self.session.open(MessageBox, _("no_saved_links", self.lang), MessageBox.TYPE_INFO)
            return
            
        # Lista linków do wyboru
        options = []
        for idx, item in enumerate(links):
            name = item.get("name", "Bez nazwy")
            url = item.get("url", "")
            label = f"{name} ({url})"
            options.append((label, idx))
        
        # Dodaj opcję zarządzania wszystkimi linkami
        options.append((_("Zarządzaj wszystkimi linkami", self.lang), "MANAGE_ALL"))
            
        self.session.openWithCallback(self.onMyLinkSelect, ChoiceBox, title=_("Wybierz link:", self.lang), list=options)

    def onMyLinkSelect(self, choice):
        if not choice: 
            return
        val = choice[1]
        
        if val == "MANAGE_ALL":
            self.manageAllLinks()
        else:
            self.selected_link_idx = val
            # Pytamy o akcję
            actions = [
                (_("Załaduj listę", self.lang), "LOAD"),
                (_("Usuń wpis", self.lang), "DELETE"),
                (_("Edytuj wpis", self.lang), "EDIT")
            ]
            self.session.openWithCallback(self.onMyLinkAction, ChoiceBox, title=_("Wybierz akcję:", self.lang), list=actions)

    def manageAllLinks(self):
        try:
            with open(MY_LINKS_FILE) as f: 
                links = json.load(f)
        except: 
            links = []

        if not links:
            self.session.open(MessageBox, _("no_saved_links", self.lang), MessageBox.TYPE_INFO)
            return
            
        options = []
        for idx, item in enumerate(links):
            name = item.get("name", "Bez nazwy")
            url = item.get("url", "")
            label = f"{name} ({url})"
            options.append((label, idx))
        
        self.session.openWithCallback(self.onDeleteMultipleLinks, ChoiceBox, title=_("Wybierz linki do usunięcia (OK = usuń):", self.lang), list=options)

    def onDeleteMultipleLinks(self, choice):
        if not choice: 
            return
        idx = choice[1]
        
        try:
            with open(MY_LINKS_FILE) as f: 
                links = json.load(f)
        except: 
            links = []
        
        if 0 <= idx < len(links):
            link_name = links[idx].get('name', links[idx].get('url', 'Nieznany'))
            
            def confirmDelete(answer):
                if answer:
                    del links[idx]
                    with open(MY_LINKS_FILE, "w") as f: 
                        json.dump(links, f, indent=2)
                    self.session.open(MessageBox, _("Link usunięty: %s", self.lang) % link_name, MessageBox.TYPE_INFO)
                    # Ponownie otwórz menu zarządzania
                    self.manageAllLinks()
            
            self.session.openWithCallback(confirmDelete, MessageBox, 
                _("Czy na pewno chcesz usunąć link: %s?", self.lang) % link_name, 
                MessageBox.TYPE_YESNO)

    def onMyLinkAction(self, choice):
        if not choice: 
            return
        action = choice[1]
        
        try:
            with open(MY_LINKS_FILE) as f: 
                links = json.load(f)
        except: 
            links = []
        
        if action == "LOAD":
            if 0 <= self.selected_link_idx < len(links):
                url = links[self.selected_link_idx]["url"]
                self.onUrlReady(url)
                
        elif action == "DELETE":
            if 0 <= self.selected_link_idx < len(links):
                link_name = links[self.selected_link_idx].get('name', links[self.selected_link_idx].get('url', 'Nieznany'))
                
                def confirmDelete(answer):
                    if answer:
                        del links[self.selected_link_idx]
                        with open(MY_LINKS_FILE, "w") as f: 
                            json.dump(links, f, indent=2)
                        self.session.open(MessageBox, _("Link usunięty: %s", self.lang) % link_name, MessageBox.TYPE_INFO)
                
                self.session.openWithCallback(confirmDelete, MessageBox, 
                    _("Czy na pewno chcesz usunąć link: %s?", self.lang) % link_name, 
                    MessageBox.TYPE_YESNO)

        elif action == "EDIT":
            if 0 <= self.selected_link_idx < len(links):
                link = links[self.selected_link_idx]
                current_json = json.dumps(link, indent=2, ensure_ascii=False)
                self.session.openWithCallback(lambda x: self.onMyLinkEditDone(x, self.selected_link_idx), 
                    VirtualKeyBoard, title=_("Edytuj link:", self.lang), text=current_json)

    def onMyLinkEditDone(self, new_json, idx):
        if not new_json: 
            return
        try:
            links = []
            if os.path.exists(MY_LINKS_FILE):
                with open(MY_LINKS_FILE) as f: 
                    links = json.load(f)
            
            new_data = json.loads(new_json)
            if new_data.get("url"):
                links[idx] = new_data
                with open(MY_LINKS_FILE, "w") as f: 
                    json.dump(links, f, indent=2)
                self.session.open(MessageBox, _("Link zaktualizowany", self.lang), MessageBox.TYPE_INFO)
            else:
                self.session.open(MessageBox, _("Link musi zawierać URL"), MessageBox.TYPE_ERROR)
        except Exception as e:
            self.session.open(MessageBox, f"JSON Error: {e}", MessageBox.TYPE_ERROR)

    def toggleLang(self):
        self.lang = "en" if self.lang == "pl" else "pl"
        self.updateLangStrings()
        self["status"].setText(f"{_('lang_changed', self.lang)} {self.lang.upper()}")

    def onListLoaded(self, playlist, name):
        if not playlist:
            self["status"].setText("")
            return
        self.playlist = playlist
        self.listname = name
        self["status"].setText(f"{_('loaded', self.lang) % len(playlist)}")
        
        # SZYBKA ŚCIEŻKA DLA MAC/XTREAM (Bez EPG XML)
        if "MAC" in name or "Xtream" in name:
             self.exportBouquet() 
             return

        custom_url = self.prof.get(EPG_URL_KEY)
        install_epg_sources(custom_url=custom_url)
        
        self["status"].setText(_("epg_generating", self.lang))
        run_in_thread(self._bg_worker, self.onPostProcessDone, self.playlist)

    def _bg_worker(self, pl):
        """Przetwarza playlistę w tle."""
        from .export import create_epg_xml
        import zlib
        epg_mapping = []
        
        for ch in pl:
            title = ch.get("title", "No Name")
            url   = ch.get("url", "")
            tvg   = ch.get("epg_id", "") # Pobieramy tvg-id!
            
            if not url: 
                continue
                
            unique_sid = zlib.crc32(url.encode()) & 0xffff
            if unique_sid == 0: 
                unique_sid = 1
            sid_hex = f"{unique_sid:X}"
            
            # Tworzymy krotkę z (ref, title, tvg_id)
            ref_dvb  = f"1:0:1:{sid_hex}:0:0:0:0:0:0"
            ref_iptv = f"4097:0:1:{sid_hex}:0:0:0:0:0:0"
            ref_ext  = f"5002:0:1:{sid_hex}:0:0:0:0:0:0"
            
            epg_mapping.append((ref_dvb, title, tvg))
            epg_mapping.append((ref_iptv, title, tvg))
            epg_mapping.append((ref_ext, title, tvg))
            
        create_epg_xml(epg_mapping)
        fetch_epg_for_playlist(pl)
        return pl

    def onPostProcessDone(self, result, error):
        self["status"].setText(_("epg_done_opening", self.lang))
        self.exportBouquet()

    def exportBouquet(self):
        if not self.playlist: 
            return
        groups = {}
        for ch in self.playlist:
            g = ch.get("group", "Inne") or "Inne"
            groups.setdefault(g, []).append(ch)
        self._groups = groups
        self.session.openWithCallback(self.onBouquetsSelected, BouquetPicker, groups)

    def onBouquetsSelected(self, selected_keys):
        if not selected_keys: 
            return
        final_list = []
        for k in selected_keys:
            if k in self._groups:
                final_list.extend(self._groups[k])
                
        res, chans = export_bouquets(final_list, self.listname, service_type=self.service_type)
        try:
             eDVBDB.getInstance().reloadBouquets()
             eDVBDB.getInstance().reloadServicelist()
        except Exception: 
            pass
        
        # NOWOŚĆ: Opcja eksportu z EPG do pliku M3U
        def exportWithEpg(answer):
            if answer:
                # Eksportuj z EPG do pliku M3U
                from .export import export_epg_to_m3u
                m3u_file = export_epg_to_m3u(final_list)
                if m3u_file:
                    self.session.open(MessageBox, f"Playlista z EPG zapisana w: {m3u_file}", MessageBox.TYPE_INFO)
        
        self.session.openWithCallback(
            exportWithEpg,
            MessageBox,
            f"{_('exported_channels_bouquets', self.lang) % (chans, res)}\n\nCzy chcesz też wyeksportować playlistę M3U z informacjami EPG?", 
            MessageBox.TYPE_YESNO
        )

    def onExportFinished(self, answer=None):
        self.session.openWithCallback(lambda x: x and quitMainloop(3), MessageBox, 
                                      _("exported", self.lang) + "\n" + _("update_ok_restart_msg", self.lang), 
                                      MessageBox.TYPE_YESNO)

    def checkUpdates(self, silent=False):
        if not silent:
            self["status"].setText(_("checking_update", self.lang))
        run_in_thread(check_update, lambda res, err: self.onUpdateCheck(res, err, silent))

    def onUpdateCheck(self, result, error, silent):
        if error or not result:
            if not silent:
                self["status"].setText(_("update_check_error", self.lang))
                self.session.open(MessageBox, _("update_check_fail_msg", self.lang), MessageBox.TYPE_ERROR)
            return

        has_new, local_ver, remote_ver, changelog = result

        if has_new:
            msg = f"{_('remote_ver', self.lang)}: v{remote_ver}\n"
            msg += f"{_('local_ver', self.lang)}: v{local_ver}\n\n"
            msg += f"{_('changes', self.lang)}:\n"
            msg += f"{changelog}\n\n"
            msg += _("update_ask", self.lang)
            
            self.session.openWithCallback(self.doUpdateConfirm, MessageBox, msg, MessageBox.TYPE_YESNO)
        else:
            if not silent:
                self["status"].setText(f"{_('no_update', self.lang)} (v{local_ver}).")
                self.session.open(MessageBox, f"{_('no_update_msg', self.lang)} (v{local_ver}).", MessageBox.TYPE_INFO)

    def doUpdateConfirm(self, ans):
        if ans: 
            run_in_thread(do_update, self.onUpdateDone)

    def onUpdateDone(self, res, err):
        if err:
            self.session.open(MessageBox, f"{_('update_fail', self.lang)}: {err}", MessageBox.TYPE_ERROR)
        else:
            self.session.openWithCallback(lambda x: x and quitMainloop(3), MessageBox, 
                                          _("update_ok_restart_msg", self.lang), 
                                          MessageBox.TYPE_YESNO)

    def close(self):
        Screen.close(self)