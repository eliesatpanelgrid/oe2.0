# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
#
# core.py - Constants, text/path helpers, skin loader, shell utilities
# Part of: Enigma2 Uninstaller Plugin
# Created by iet5
# Compatible: Python 2.7 / Python 3.12 / Python 3.13 / Python 3.14
#
# The plugin uses ONLY the new graphic skin (SourceList + TemplatedMultiContent).
# The new graphic skin (SourceList + TemplatedMultiContent) is always used.
#

import os
import subprocess
import sys

# Python version flags — imported from __init__.py after relative import below

# Enigma2 imports needed by helpers
from Components.Label import Label
from Screens.Console import Console
from Screens.MessageBox import MessageBox

# getDesktop - screen size detection
try:
    from enigma import getDesktop
except Exception:
    getDesktop = None

# Import everything from __init__.py
try:
    from . import (
        PLUGIN_FOLDER, PLUGIN_NAME, PLUGIN_HEADER, PLUGIN_ICON,
        plugin_path, plugin_version, native_text, native_path,
        read_text, skin_path, to_text, PY2, PY3,
        is_dreambox, is_dreamos, is_vuplus, is_vti, is_blackhole, is_openatv, is_opensource,
    )
except Exception:
    from __init__ import (
        PLUGIN_FOLDER, PLUGIN_NAME, PLUGIN_HEADER, PLUGIN_ICON,
        plugin_path, plugin_version, native_text, native_path,
        read_text, skin_path, to_text, PY2, PY3,
        is_dreambox, is_dreamos, is_vuplus, is_vti, is_blackhole, is_openatv, is_opensource,
    )


# =============================================================================
# Plugin-wide constants
# =============================================================================

PLUGIN_DESC = u"Remove Enigma2 plugin packages safely (IPK/DEB)"

# Temporary shell scripts written to /tmp at runtime
TMP_REMOVE_PACKAGES = "/tmp/enigma2_uninstaller_remove.sh"
TMP_RESTART_GUI     = "/tmp/enigma2_uninstaller_restart.sh"

# Absolute paths of the two Enigma2 plugin roots.
# Used for path-safety checks only; deletion is performed by package managers.
PLUGIN_ROOTS = (
    "/usr/lib/enigma2/python/Plugins/Extensions",
    "/usr/lib/enigma2/python/Plugins/SystemPlugins",
)

# Package name prefixes this plugin is allowed to list and remove
PACKAGE_PREFIXES = (
    "enigma2-plugin-",
    "enigma2-skin-",
    "enigma2-picon-",
)

# File extensions / markers that are safe to delete during Blue-button cleanup.
# These are only cache/temp/leftover artefacts, never active plugin files.
CLEANUP_FILE_EXTS    = ('.pyc', '.pyo', '.tmp', '.bak', '.old', '.removed', '.removing')
CLEANUP_FILE_MARKERS = ('.opkg-', '.dpkg-', '.ipk-new', '.ipk-old')

# Configuration
CONFIG_FILE = plugin_path("settings.json")
DEFAULT_CONFIG = {
    "hide_warning": False,
    "hide_details": False, # Activated = Hide [DEB]/[Dir]
}

# Normalised suffixes of core SystemPlugins that must never be removed.
# Removing any of these may break the Enigma2 image or prevent the box from booting.
PROTECTED_SYSTEMPLUGIN_SUFFIXES = (
    # Network & connectivity
    'networkbrowser',
    'networksetup',
    'networkwizard',
    'wirelesslan',
    'hotplug',
    # Satellite tuning
    'satfinder',
    'satelliteequipmentcontrol',
    'positionersetup',
    'diseqctester',
    'nimmanager',
    'nimsetup',
    # Video & audio
    'videomode',
    'videotune',
    'videoenhancement',
    'audiosync',
    # System management
    'softwaremanager',
    'softwareupdate',
    'pluginmanager',
    'defaultservicesscanner',
    'defaultservicelist',
    'commoninterfaceassignment',
    'frontprocessorupgrade',
    # Input & navigation
    'fastscan',
    # DreamOS / Dreambox specific
    'dreamdlna',
    'dreamexplorer',
    'dreamirc',
    'partnerbox',
    'autoresolution',
    # System core (must never be removed)
    'crashlogautosubmit',
    'cleanupwizard',
    'tempfancontrol',
    'fancontrol',
    'osd3dsetup',
    'osdsetup',
    'defaultservicescanner',
    'graphmultiepg',
    'infopanel',
    'epgrefresh',
    'automaticvolumeadjustment',
    'vps',
    'hdmicec',
)


# =============================================================================
# Text and path helpers
# =============================================================================

def gui_text(value):
    """Return value in the native string type for Enigma2 Label widgets.
    Python 2: UTF-8 bytes.  Python 3: str (unicode)."""
    return native_text(value)


def gui_path(value):
    """Return a filesystem path in the native type for the running Python.
    Prevents path/unicode issues on older DreamOS Python 2.7 builds."""
    return native_path(value)


def safe_open(path, mode):
    """Open a file using the native path type for Python 2 / Python 3."""
    return open(gui_path(path), mode)


def safe_listdir(path):
    """Return os.listdir(path) as a list of items, or [] on any error."""
    try:
        return os.listdir(gui_path(path))
    except Exception:
        return []


def read_file(path):
    """Read a file as unicode text. Returns empty string on any error."""
    return read_text(path)


def get_config():
    """Load configuration from JSON file, merge with defaults."""
    import json
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(gui_path(CONFIG_FILE)):
        try:
            with safe_open(CONFIG_FILE, "rb") as f:
                data = f.read()
                # Python 2/3 compatible json load from bytes
                try:
                    loaded = json.loads(data.decode("utf-8"))
                except Exception:
                    loaded = json.loads(data)
                if isinstance(loaded, dict):
                    cfg.update(loaded)
                    # Backward compatibility: old key "show_warning" was inverted logic.
                    # If the old key exists but the new key does not, migrate it safely.
                    if "show_warning" in loaded and "hide_warning" not in loaded:
                        cfg["hide_warning"] = not bool(loaded["show_warning"])
        except Exception:
            pass
    return cfg


def save_config(config):
    """Save configuration to JSON file."""
    import json
    try:
        # Ensure legacy key "show_warning" is never written; always use "hide_warning"
        clean = {k: v for k, v in config.items() if k != "show_warning"}
        with safe_open(CONFIG_FILE, "wb") as f:
            # Both Python 2 and Python 3: encode to UTF-8 bytes and write
            f.write(json.dumps(clean, indent=4).encode("utf-8"))
        return True
    except Exception:
        return False


# =============================================================================
# Screen and widget helpers
# =============================================================================

def messagebox_error_type():
    """Return a safe MessageBox error-type constant.
    Falls back to TYPE_INFO on images that do not define TYPE_ERROR."""
    return getattr(MessageBox, "TYPE_ERROR", MessageBox.TYPE_INFO)


def get_screen_width():
    """Return the primary display width in pixels. Falls back to 1280 (HD)."""
    try:
        if getDesktop is not None:
            return getDesktop(0).size().width()
    except Exception:
        pass
    return 1280


def version_label():
    """Return the formatted plugin version label string."""
    return gui_text(u"Ver. %s" % plugin_version())


def setup_main_header(screen):
    """Populate the main screen header widgets (title + version)."""
    screen["header_title"]   = Label(gui_text(PLUGIN_HEADER))
    screen["header_version"] = Label(version_label())


def setup_message_header(screen):
    """Populate a dialog screen header widget (title only)."""
    screen["header_title"] = Label(gui_text(PLUGIN_HEADER))


def set_label_safe(label, text):
    """Set Label text safely on Python 2 and Python 3 images."""
    try:
        label.setText(gui_text(text))
    except Exception:
        try:
            label.setText(str(text))
        except Exception:
            pass


def format_package_row_text(name, pt, kind, hide_details=False):
    """Build the visible text for one package list row.
    
    Logic per user request:
      - Activated (hide_details=True) : HIDE the 'DEB' / 'Dir' prefix.
      - ALWAYS SHOW: The '[extension]' / '[system]' / '[skin]' label.
    """
    parts     = []
    pt_text   = to_text(pt).upper().strip() # DEB, DIR, IPK
    kind_text = to_text(kind).strip()       # extension, system, skin
    name_text = to_text(name).strip()       # package name
    
    # Hide the type prefix (DEB/DIR) only when the setting is activated
    if pt_text and not hide_details:
        parts.append(pt_text)
    
    # Always show the category/kind (e.g. [extension])
    if kind_text:
        parts.append(u'[%s]' % kind_text)
        
    if name_text:
        parts.append(name_text)
        
    return u' '.join(parts)


# =============================================================================
# Skin loader - new skin only (SourceList + TemplatedMultiContent)
# =============================================================================

def load_skin(screen_type, suffix=""):
    """Load the XML skin for screen_type ('main', 'setting', etc.).
    Optional suffix (e.g. 'graphic' or 'config') allows choosing between styles.
    Resolution is auto-detected: FHD (>= 1920 px) or HD (< 1920 px).
    """
    width = get_screen_width()
    res   = "fhd" if width >= 1920 else "hd"
    if suffix:
        fname = "%s_%s_%s.xml" % (screen_type, suffix, res)
    else:
        fname = "%s_%s.xml" % (screen_type, res)
    path  = skin_path(fname)
    try:
        handle = safe_open(path, "rb")
        try:
            content = to_text(handle.read())
        finally:
            handle.close()
        content = content.replace(u"{PATH}", to_text(plugin_path()))
        if is_opensource():
            content = adjust_opensource_skin(content, width)
        return gui_text(content)
    except Exception:
        pass

    # --- Minimal fallback skins (used only if the XML files are missing) ---
    if screen_type == "msg":
        content = (
            u'<screen name="CustomMessageBox" position="center,center" size="900,520" title="Message">'
            u'<widget name="text_top" position="20,15" size="860,70" font="Regular;20"'
            u' halign="center" valign="center"/>'
            u'<widget name="count_text" position="20,93" size="860,36" font="Regular;20"'
            u' halign="center" valign="center" foregroundColor="#31ff31"/>'
            u'<widget name="package_names" position="20,137" size="860,120" font="Regular;22"'
            u' halign="center" valign="center" foregroundColor="#31ff31"/>'
            u'<widget name="text_bottom" position="20,265" size="860,168" font="Regular;20"'
            u' halign="center" valign="center"/>'
            u'<eLabel position="0,453" size="900,67" backgroundColor="#3b3a39" zPosition="-1"/>'
            u'<widget name="key_red" position="100,459" size="250,55" font="Regular;22" halign="center" valign="center" transparent="1"/>'
            u'<widget name="key_green" position="550,459" size="250,55" font="Regular;22" halign="center" valign="center" transparent="1"/>'
            u'</screen>'
        )
        if is_opensource():
            content = adjust_opensource_skin(content, width)
        return gui_text(content)

    # Fallback main - uses source="list" consistent with the new graphic skin
    content = (
        u'<screen name="Enigma2UninstallerMain" position="center,center" size="1100,677"'
        u' title="Remove Enigma2 Packages">'
        u'<widget name="header_title" position="25,2" size="700,52" font="Regular;20"'
        u' foregroundColor="#31ff31" halign="left" valign="center"/>'
        u'<widget name="header_version" position="800,2" size="300,52" font="Regular;16"'
        u' foregroundColor="#31ff31" halign="right" valign="center"/>'
        u'<widget source="list" render="Listbox" position="25,58" size="1050,420"'
        u' scrollbarMode="showOnDemand" transparent="1">'
        u'<convert type="TemplatedMultiContent">'
        u'{"template": ['
        u'MultiContentEntryText(pos=(6,0), size=(910,35), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),'
        u'MultiContentEntryPixmapAlphaTest(pos=(970,5), size=(61,24), png=1)'
        u'], "fonts": [gFont("Regular", 18)], "itemHeight": 35}'
        u'</convert>'
        u'</widget>'
        u'<widget name="status" position="26,486" size="1048,44" font="Regular;15"'
        u' foregroundColor="#f0a30a" halign="left" valign="center"/>'
        u'<widget name="help" position="26,535" size="1048,44" font="Regular;16"'
        u' foregroundColor="#cccccc" halign="left" valign="center"/>'
        u'<eLabel position="0,587" size="1100,90" backgroundColor="#3b3a39" zPosition="-1"/>'
        u'<ePixmap pixmap="{PATH}/buttons/red.png" position="78,598" size="225,68" alphatest="blend" zPosition="1"/>'
        u'<widget name="key_red" position="78,598" size="225,68" font="Regular;24" halign="center" valign="center" transparent="1" zPosition="2"/>'
        u'<ePixmap pixmap="{PATH}/buttons/green.png" position="318,598" size="225,68" alphatest="blend" zPosition="1"/>'
        u'<widget name="key_green" position="318,598" size="225,68" font="Regular;24" halign="center" valign="center" foregroundColor="#000000" transparent="1" zPosition="2"/>'
        u'<ePixmap pixmap="{PATH}/buttons/yellow.png" position="558,598" size="225,68" alphatest="blend" zPosition="1"/>'
        u'<widget name="key_yellow" position="558,598" size="225,68" font="Regular;24" halign="center" valign="center" foregroundColor="#000000" transparent="1" zPosition="2"/>'
        u'<ePixmap pixmap="{PATH}/buttons/blue.png" position="798,598" size="225,68" alphatest="blend" zPosition="1"/>'
        u'<widget name="key_blue" position="798,598" size="225,68" font="Regular;24" halign="center" valign="center" transparent="1" zPosition="2"/>'
        u'</screen>'
    )
    content = content.replace(u"{PATH}", to_text(plugin_path()))
    if is_opensource():
        content = adjust_opensource_skin(content, width)
    return gui_text(content)


def adjust_opensource_skin(content, width):
    """Shift ONLY the ePixmap coloured-button images downward on Open Source images.

    Problem on Open Source / Python 3 (OpenATV, VTi, Black Hole, etc.):
      The Enigma2 skin engine on these images renders ePixmap button graphics
      higher than their declared position.  The text labels (widget key_*)
      render correctly at their declared position.

    Solution:
      1. Shift ePixmap button background images downward (btn_shift) for alignment.
      2. User request for SettingScreen:
         - Move BOTH the button and the text UP by 15 pixels.
         - Keep the writing (text) centered by moving it DOWN 15 pixels relative
           to its original position (offsetting the lift).
    """
    if u"buttons/" not in content:
        return content

    import re

    # RemovalMethodBox uses hand-tuned inline positions - do not touch it
    if 'name="RemovalMethodBox"' in content:
        return content

    is_setting = 'SettingScreen' in content
    btn_shift = 20 if width >= 1920 else 14
    
    # Adjustment for SettingScreen on Open Source images (e.g. OpenATV)
    # Python 3: Move buttons DOWN 15px, keep text UNTOUCHED.
    # Python 2: Keep previous behavior (lift everything UP 15px).
    if is_setting and PY3:
        total_lift = 0    # Adjusted: moved up another 5px
        text_down  = 0    # Adjusted: keeps text at original position
    elif is_setting:
        total_lift = 15   # Original legacy behavior
        text_down  = 15
    else:
        total_lift = 0
        text_down = 0

    def shift_pos(match, offset):
        """Helper to shift the position attribute within a tag."""
        tag = match.group(0)
        pos_m = re.search(r'position\s*=\s*["\'](\d+)\s*,\s*(\d+)["\']', tag, re.IGNORECASE)
        if not pos_m:
            return tag
        x = pos_m.group(1)
        y = int(pos_m.group(2))
        return tag.replace(pos_m.group(0), 'position="%s,%d"' % (x, y + offset))

    # 1. Alignment fix for ePixmap (Move backgrounds DOWN by btn_shift, UP by total_lift)
    def epixmap_fix(match):
        return shift_pos(match, btn_shift - total_lift)

    content = re.sub(r'<ePixmap[^>]*?buttons/[^>]*?>', epixmap_fix, content, flags=re.IGNORECASE)

    # 2. Adjust text labels (Move UP by total_lift, DOWN by text_down)
    if is_setting:
        def text_adjust(match):
            return shift_pos(match, text_down - total_lift)

        content = re.sub(r'<widget\s+name\s*=\s*["\']key_(?:red|green|yellow|blue)["\'][^>]*?>', 
                         text_adjust, content, flags=re.IGNORECASE)

    # 3. Global Font Increase for 'help' widget on Open Source images
    # This ensures the +2 increase is applied even if fallback skins are used.
    def help_font_increase(match):
        tag = match.group(0)
        font_m = re.search(r'font\s*=\s*["\']([^;]+);(\d+)["\']', tag, re.IGNORECASE)
        if font_m:
            fname = font_m.group(1)
            fsize = int(font_m.group(2))
            return tag.replace(font_m.group(0), 'font="%s;%d"' % (fname, fsize + 2))
        return tag

    content = re.sub(r'<widget\s+name\s*=\s*["\']help["\'][^>]*?>', help_font_increase, content, flags=re.IGNORECASE)

    return content


# =============================================================================
# Shell / system utilities
# =============================================================================

def command_exists(cmd):
    """Return True if cmd is found and executable on the system PATH."""
    for base in os.environ.get("PATH", "/bin:/sbin:/usr/bin:/usr/sbin").split(os.pathsep):
        full = os.path.join(base, cmd)
        if os.path.exists(full) and os.access(full, os.X_OK):
            return True
    return False


def run_command(args):
    """Run a command and return combined stdout+stderr as unicode text.
    Never raises an exception; returns empty string on any error."""
    try:
        out = subprocess.check_output(args, stderr=subprocess.STDOUT)
        return to_text(out)
    except Exception:
        return u""


def shell_quote(value):
    """POSIX single-quote a shell argument. Handles embedded single quotes safely."""
    value = to_text(value)
    if not value:
        return u"''"
    return u"'" + value.replace(u"'", u"'\"'\"'") + u"'"


def write_script(path, lines):
    """Write lines to a shell script file and chmod +x it. Returns True on success."""
    try:
        handle = safe_open(path, "wb")
        try:
            data = u"\n".join([to_text(x) for x in lines]) + u"\n"
            if PY2:
                handle.write(data.encode("utf-8", "ignore"))
            else:
                handle.write(data.encode("utf-8"))
        finally:
            handle.close()
        os.chmod(gui_path(path), 0o755)
        return True
    except Exception:
        return False


def open_console_safe(session, callback, title, commands):
    """Open Screens.Console with a compatibility ladder.

    Some DreamOS / VTi images do not accept the closeOnSuccess keyword, so this
    function tries multiple call signatures before falling back to session.open.
    This ensures the Console screen opens correctly on every Enigma2 image.
    """
    title = gui_text(title)
    if callback is not None:
        try:
            session.openWithCallback(callback, Console, title, commands, closeOnSuccess=True)
            return
        except TypeError:
            pass
        try:
            session.openWithCallback(callback, Console, title, commands)
            return
        except TypeError:
            pass
    try:
        session.open(Console, title, commands, closeOnSuccess=True)
    except TypeError:
        session.open(Console, title, commands)


def build_restart_script():
    """Build a shell script that restarts Enigma2 using the safest available method.

    Priority order:
      1. systemctl restart enigma2       (DreamOS / systemd-based images)
      2. init 4 / init 3                 (classic SysV init images: OpenATV, VTi, etc.)
      3. killall -9 enigma2              (last resort - always works)
    """
    lines = ["#!/bin/sh", "echo 'Restarting Enigma2...'"]
    if is_dreamos() or is_dreambox():
        # DreamOS uses systemd; try it first
        lines.extend([
            "if command -v systemctl >/dev/null 2>&1; then",
            "    systemctl restart enigma2 >/dev/null 2>&1 && exit 0",
            "    systemctl restart enigma2.service >/dev/null 2>&1 && exit 0",
            "fi",
        ])
    # SysV init fallback (OpenATV, VTi, Black Hole, OpenPLi, etc.)
    lines.extend([
        "if command -v init >/dev/null 2>&1; then init 4; sleep 2; init 3; exit 0; fi",
        "killall -9 enigma2 >/dev/null 2>&1",
        "exit 0",
    ])
    write_script(TMP_RESTART_GUI, lines)
    return TMP_RESTART_GUI
# =============================================================================
# Keymap Loading
# =============================================================================

def load_keymap():
    """Register the custom keymap.xml with the system using universal eActionMap.

    Uses the absolute plugin path so that the keymap is found correctly regardless
    of the current working directory at import time.  Silently ignored on images
    that do not support eActionMap.readKeymap (e.g. very old DreamOS builds).
    """
    try:
        from enigma import eActionMap
        km_path = gui_path(plugin_path("keymap.xml"))
        if os.path.exists(km_path):
            eActionMap.getInstance().readKeymap(km_path)
    except Exception:
        pass

# Initialize keymap on import
try:
    load_keymap()
except Exception:
    pass
