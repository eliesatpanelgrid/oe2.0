# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
#
# screens.py - Enigma2 Screen classes
#   Enigma2UninstallerMain  : main package list screen with toggle selection
#   RemovalMethodBox        : Normal vs Force removal method dialog
#   CustomMessageBox        : Yes/No confirmation dialog
#
# Part of: Enigma2 Uninstaller Plugin
# Created by iet5
# Compatible: Python 2.7 / Python 3.12 / Python 3.13 / Python 3.14
# Images: OpenATV, VTi, Black Hole, OpenPLi, DreamOS, and all Enigma2 images
# Devices: Dreambox 920, Vu+, and all standard Enigma2 receivers
#

import os
import shutil

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigBoolean, getConfigListEntry
try:
    from enigma import parseColor
except Exception:
    def parseColor(s): return None

try:
    from enigma import gRGB
except Exception:
    gRGB = None

try:
    from enigma import ePoint, eSize, eLabel
except Exception:
    ePoint = eSize = eLabel = None

try:
    from enigma import eTimer
except Exception:
    # Safe dummy timer if enigma.eTimer is missing
    class eTimer(object):
        def __init__(self, *args, **kwargs): pass
        def start(self, *args, **kwargs): pass
        def stop(self, *args, **kwargs): pass
        @property
        def timeout(self):
            class Dummy:
                def connect(self, *args): pass
            return Dummy()

from .core import (
    PLUGIN_NAME, PLUGIN_ROOTS, CLEANUP_FILE_EXTS, CLEANUP_FILE_MARKERS,
    TMP_REMOVE_PACKAGES, TMP_RESTART_GUI,
    gui_text, gui_path, to_text,
    get_screen_width, setup_main_header,
    set_label_safe, format_package_row_text, load_skin,
    messagebox_error_type, shell_quote, write_script,
    open_console_safe, build_restart_script,
    plugin_path, get_config, save_config,
)

# Package helpers
from .packages import (
    installed_packages, detect_environment,
    is_safe_plugin_path, find_plugin_folder_targets, folder_entry_target,
    protected_selection, protected_removal_reason, format_protected_message,
)

# Widget factory
from .widgets import PackageList, SettingList


# =============================================================================
# Main screen
# =============================================================================

class Enigma2UninstallerMain(Screen):
    """Main plugin screen - displays installed Enigma2 packages with toggle selection.

    Key bindings:
      OK     - Toggle package selection on/off
      Green  - Confirm and remove selected packages
      Yellow - Show information about the highlighted package
      Blue   - Cleanup cache/leftover files (*.pyc, *.pyo, __pycache__, temp files)
      Red    - Close the plugin
      Cancel - Close the plugin
    """

    def __init__(self, session):
        # load_skin() handles {PATH} replacement and Open Source adjustments internally
        self.skin = load_skin("main")
        Screen.__init__(self, session)
        self.session = session

        # Plugin state
        self.packages         = []   # Full list: [(name, pt, kind), ...]
        self.selected         = []   # Names toggled for removal
        self.pending_selected = []   # Snapshot used across multi-step dialogs
        self.visible          = []   # Currently visible (filtered) rows
        self.filter_text      = u""
        self.force_remove     = False
        self.config           = get_config()
        self.first_scan       = True
        self.first_warn       = True

        # Widgets - names must match the skin XML exactly
        setup_main_header(self)
        self["list"]       = PackageList()
        self["status"]     = Label(gui_text(u"Loading packages..."))
        self["help"]       = Label(gui_text(u"OK: Select | Yellow: Info | Green: Remove | Blue: Cleanup | Menu: Settings"))
        self["key_red"]    = Label(gui_text(u"Close"))
        self["key_green"]  = Label(gui_text(u"Remove"))
        self["key_yellow"] = Label(gui_text(u"Info"))
        self["key_blue"]   = Label(gui_text(u"Cleanup"))

        self["actions"] = ActionMap(
            ["Enigma2UninstallerActions", "OkCancelActions", "ColorActions", "MenuActions"],
            {
                "ok":     self.toggle_selection,
                "green":  self.confirm_method,
                "yellow": self.show_package_info,
                "blue":   self.confirm_cleanup,
                "red":    self.close,
                "cancel": self.close,
                "menu":   self.open_settings,
            },
            -1,
        )

        try:
            self["list"].onSelectionChanged.append(self.update_help)
        except Exception:
            pass
        self.onLayoutFinish.append(self._on_layout_finish)
        self.onShown.append(self._on_first_shown)

    def _on_layout_finish(self):
        """Defer the startup warning so it opens after the main screen is fully modal."""
        self._warn_timer = eTimer()
        try:
            self._warn_timer_conn = self._warn_timer.timeout.connect(self.show_startup_warning)
        except AttributeError:
            self._warn_timer.callback.append(self.show_startup_warning)
        self._warn_timer.start(500, True)

    def _on_first_shown(self):
        """Called every time the screen is shown. Only scan disk on the first time."""
        if self.first_scan:
            self.first_scan = False
            self.load_packages()

    def show_startup_warning(self):
        """Show the risk warning if enabled in settings."""
        if not self.first_warn:
            return
        self.first_warn = False
        if not self.config.get("hide_warning", False):
            msg = (
                u"Welcome to %s\n\n"
                u"WARNING: Removing system plugins or core components can make your receiver "
                u"unstable or prevent it from booting.\n\n"
                u"Always ensure you have a full backup before making changes.\n"
                u"Use this plugin at your own risk.\n\n"
                u"You can disable this message in the Settings menu (MENU key).\n\n"
                u"(Press any key or wait 10s to continue)"
            ) % PLUGIN_NAME
            self.session.open(WarningScreen, gui_text(msg))

    def open_settings(self):
        """Open the new Setting Screen."""
        self.session.openWithCallback(self.settings_finished, SettingScreen)

    def settings_finished(self, *args):
        """Reload config and refresh the list after settings are changed."""
        self.config = get_config()
        self.update_list()

    # -------------------------------------------------------------------------
    # Yellow button — package information
    # -------------------------------------------------------------------------

    def show_package_info(self):
        """Show information about the highlighted package without changing its selection."""
        try:
            idx = self["list"].getSelectionIndex()
        except Exception:
            idx = None
        if idx is None or idx < 0 or idx >= len(self.visible):
            self.session.open(MessageBox, gui_text(u"No package highlighted."), MessageBox.TYPE_INFO)
            return
        name, pt, kind = self.visible[idx]
        is_selected  = name in self.selected
        env          = detect_environment()
        block_reason = protected_removal_reason(name)
        protection_text = (u"\nProtected: %s" % block_reason) if block_reason else u"\nStatus: Removable"
        msg = (
            u"Package information:\n\n"
            u"Name: %s\n"
            u"Type: %s\n"
            u"Kind: %s\n"
            u"Selected for removal: %s"
            u"%s\n\n"
            u"Box: %s\n"
            u"Image: %s\n"
            u"Python: %s\n\n"
            u"This screen is for information only. Nothing is changed."
        ) % (
            to_text(name), to_text(pt).upper(), to_text(kind),
            u"Yes" if is_selected else u"No", protection_text,
            env.get("box", "Unknown"), env.get("image", "Unknown"), env.get("python", "Unknown"),
        )
        self.session.open(MessageBox, gui_text(msg), MessageBox.TYPE_INFO)

    # -------------------------------------------------------------------------
    # Help bar update
    # -------------------------------------------------------------------------

    def update_help(self):
        """Update the bottom help bar with info about the highlighted package."""
        try:
            idx = self["list"].getSelectionIndex()
        except Exception:
            idx = None
        if idx is not None and 0 <= idx < len(self.visible):
            name, pt, kind = self.visible[idx]
            label = u"Folder" if pt == "dir" else u"Package"
            set_label_safe(self["help"],
                u"%s: %s | Type: %s | Kind: %s" % (label, name, to_text(pt).upper(), to_text(kind)))
        else:
            set_label_safe(self["help"],
                u"OK: Select | Yellow: Info | Green: Remove | Blue: Cleanup | Menu: Settings")

    # -------------------------------------------------------------------------
    # Package loading
    # -------------------------------------------------------------------------

    def load_packages(self):
        """Query all package sources and refresh the list widget."""
        self.packages    = installed_packages()
        self.selected    = []
        self.filter_text = u""
        self.update_list()
        env = detect_environment()
        if self.packages:
            managers = u",".join(env["managers"]) if env["managers"] else u"none"
            set_label_safe(self["status"],
                u"OK: Select/Unselect | Yellow: Info | Green: Remove | Blue: Cleanup"
                u" | %s / %s / Python %s / %s"
                % (env["box"], env["image"], env["python"], managers))
        else:
            set_label_safe(self["status"], u"No Enigma2 packages or plugin folders found.")

    # -------------------------------------------------------------------------
    # List rendering
    # -------------------------------------------------------------------------

    def update_list(self):
        """Rebuild the visible package list and preserve the cursor position."""
        if self.filter_text:
            self.visible = [p for p in self.packages if self.filter_text in to_text(p[0]).lower()]
        else:
            self.visible = list(self.packages)

        try:
            current_index = self["list"].getSelectionIndex()
        except Exception:
            current_index = 0

        self["list"].set_packages(self.visible, self.selected, self.config.get("hide_details", False))

        try:
            if self.visible:
                self["list"].moveToIndex(max(0, min(current_index, len(self.visible) - 1)))
        except Exception:
            pass

        if self.filter_text:
            set_label_safe(self["status"], u"Filter: '%s' | Found: %d" % (self.filter_text, len(self.visible)))
        self.update_help()

    # -------------------------------------------------------------------------
    # OK button — toggle selection
    # -------------------------------------------------------------------------

    def toggle_selection(self):
        """Toggle the selection state of the currently highlighted package."""
        try:
            idx = self["list"].getSelectionIndex()
        except Exception:
            idx = None
        if idx is None or idx < 0 or idx >= len(self.visible):
            return
        name = self.visible[idx][0]
        if name in self.selected:
            self.selected.remove(name)
        else:
            self.selected.append(name)
        self.update_list()

    # -------------------------------------------------------------------------
    # Selection normalisation helpers
    # -------------------------------------------------------------------------

    def _normalize_selected_names(self, names):
        """Return unique selected names that still exist in the current package list."""
        valid = {item[0]: True for item in self.packages}
        result = []
        seen   = {}
        for name in names or []:
            if name in valid and name not in seen:
                result.append(name)
                seen[name] = True
        return result

    def _get_selected_names(self):
        """Return a verified snapshot of selected names and sync self.selected."""
        selected     = self._normalize_selected_names(self.selected)
        self.selected = list(selected)
        return selected

    # -------------------------------------------------------------------------
    # Blue button — Cleanup
    # -------------------------------------------------------------------------

    def _is_cleanup_file(self, filename):
        """Return True for known cache/temp/leftover filenames only."""
        lower = to_text(filename).lower()
        if lower.endswith(CLEANUP_FILE_EXTS):
            return True
        for marker in CLEANUP_FILE_MARKERS:
            if marker in lower:
                return True
        return False

    def _find_cleanup_targets(self):
        """Walk all plugin roots and collect removable cache/leftover paths.

        Blue Cleanup is independent of package selection. It only removes:
          - *.pyc and *.pyo cache files
          - __pycache__ directories
          - *.tmp, *.bak, *.old, *.removed, opkg/dpkg temporary files
        It never removes active plugin folders.
        """
        targets = []
        seen    = {}
        for root in PLUGIN_ROOTS:
            if not os.path.isdir(gui_path(root)):
                continue
            for current, dirs, files in os.walk(gui_path(root)):
                current_text = to_text(current)
                for dname in list(dirs):
                    dpath = os.path.join(current_text, to_text(dname))
                    if to_text(dname) == u"__pycache__" and is_safe_plugin_path(dpath):
                        if dpath not in seen:
                            targets.append((u"dir", dpath))
                            seen[dpath] = True
                for fname in files:
                    if not self._is_cleanup_file(fname):
                        continue
                    fpath = os.path.join(current_text, to_text(fname))
                    if is_safe_plugin_path(fpath) and fpath not in seen:
                        targets.append((u"file", fpath))
                        seen[fpath] = True
        return targets

    def confirm_cleanup(self):
        """Scan for cleanup targets, then ask the user for confirmation."""
        targets = self._find_cleanup_targets()
        if not targets:
            self.session.open(MessageBox,
                gui_text(u"Cleanup scan finished. No cache or leftover files were found."),
                MessageBox.TYPE_INFO)
            return

        self.pending_cleanup_targets = list(targets)
        shown      = [u"%d. %s: %s" % (i + 1, u"Folder" if k == u"dir" else u"File", to_text(p))
                      for i, (k, p) in enumerate(targets[:12])]
        names_text = u"\n".join(shown)
        extra      = (u"\n... and %d more" % (len(targets) - 12)) if len(targets) > 12 else u""
        file_count = sum(1 for x in targets if x[0] == u"file")
        dir_count  = sum(1 for x in targets if x[0] == u"dir")

        self.session.openWithCallback(
            self.cleanup_confirmed,
            CustomMessageBox,
            gui_text(u"Cleanup scan is independent of package selection.\nActive plugin folders will NOT be deleted."),
            "Confirm Cleanup",
            gui_text(names_text + extra),
            gui_text(
                u"Items that will be removed:\n"
                u"- Python cache files: *.pyc and *.pyo\n"
                u"- __pycache__ folders inside plugin paths\n"
                u"- Leftover temp files: *.tmp, *.bak, *.old, *.removed, opkg/dpkg temp files\n\n"
                u"Active plugin folders are kept safe.\n\nContinue cleanup?"
            ),
            gui_text(u"Found: %d files, %d folders" % (file_count, dir_count)),
        )

    def cleanup_confirmed(self, answer):
        """Execute the cleanup after user confirmation."""
        if not answer:
            return
        targets = getattr(self, "pending_cleanup_targets", []) or []
        result  = self._cleanup_leftovers(targets)
        msg = (
            u"Cleanup finished.\n\nDeleted files: %d\nDeleted folders: %d\n"
            u"Active plugin folders deleted: 0\nErrors: %d"
        ) % (result.get("files", 0), result.get("dirs", 0), len(result.get("errors", [])))
        if result.get("errors"):
            msg += u"\n\nSome items could not be removed:\n" + u"\n".join(result["errors"][:6])
        self.session.open(MessageBox, gui_text(msg), MessageBox.TYPE_INFO)
        self.pending_cleanup_targets = []
        self.load_packages()

    def _cleanup_leftovers(self, targets):
        """Remove only scanned cache/leftover targets. Never remove plugin folders."""
        result = {"files": 0, "dirs": 0, "errors": []}
        for item in targets or []:
            try:
                kind, path = item
            except Exception:
                continue
            path = to_text(path)
            if not is_safe_plugin_path(path):
                continue
            try:
                if kind == u"dir":
                    if os.path.basename(path) != u"__pycache__":
                        continue
                    shutil.rmtree(gui_path(path), ignore_errors=False)
                    result["dirs"] += 1
                elif kind == u"file":
                    if not self._is_cleanup_file(os.path.basename(path)):
                        continue
                    os.remove(gui_path(path))
                    result["files"] += 1
            except Exception as err:
                result["errors"].append(u"%s: %s" % (path, to_text(err)))
        return result

    # -------------------------------------------------------------------------
    # Green button — Removal flow (3 steps)
    # -------------------------------------------------------------------------

    def confirm_method(self):
        """Step 1: Check selection, verify no protected packages, ask removal method."""
        selected = self._get_selected_names()
        if not selected:
            self.session.open(MessageBox, gui_text(u"No packages selected."), MessageBox.TYPE_INFO)
            return
        blocked = protected_selection(selected)
        if blocked:
            self.session.open(MessageBox, gui_text(format_protected_message(blocked)), messagebox_error_type())
            return
        self.pending_selected = list(selected)
        self.session.openWithCallback(self.method_selected, RemovalMethodBox)

    def method_selected(self, answer):
        """Step 2: Show confirmation dialog with exact package count and names."""
        if not answer:
            return
        self.force_remove     = (answer[1] == "force")
        selected              = self._normalize_selected_names(self.pending_selected or self.selected)
        self.pending_selected = list(selected)
        self.selected         = list(selected)
        if not selected:
            self.session.open(MessageBox, gui_text(u"No packages selected."), MessageBox.TYPE_INFO)
            return
        blocked = protected_selection(selected)
        if blocked:
            self.session.open(MessageBox, gui_text(format_protected_message(blocked)), messagebox_error_type())
            return
        shown      = [u"%d. %s" % (i + 1, to_text(n)) for i, n in enumerate(selected[:12])]
        names_text = u"\n".join(shown)
        extra      = (u"\n... and %d more" % (len(selected) - 12)) if len(selected) > 12 else u""
        self.session.openWithCallback(
            self.remove_confirmed,
            CustomMessageBox,
            gui_text(u"The following packages will be removed."),
            "Confirm Removal",
            gui_text(names_text + extra),
            gui_text(
                u"The package manager will remove all owned files.\n"
                u"After removal: the plugin folder, *.pyc, *.pyo, and __pycache__ will be cleaned.\n"
                u"Directory-only plugins will be removed directly from their plugin folder.\n\n"
                u"Are you sure you want to continue?"
            ),
            gui_text(u"Total: %d package(s)" % len(selected)),
        )

    def remove_confirmed(self, answer):
        """Step 3: Build and execute the removal shell script."""
        if not answer:
            return
        selected              = self._normalize_selected_names(self.pending_selected or self.selected)
        self.pending_selected = list(selected)
        self.selected         = list(selected)
        if not selected:
            self.session.open(MessageBox, gui_text(u"No packages selected."), MessageBox.TYPE_INFO)
            return
        blocked = protected_selection(selected)
        if blocked:
            self.session.open(MessageBox, gui_text(format_protected_message(blocked)), messagebox_error_type())
            return
        if not self._build_remove_script(selected):
            self.session.open(MessageBox,
                gui_text(u"Could not create the removal script. Please check /tmp permissions."),
                messagebox_error_type())
            return
        open_console_safe(self.session, self._after_removal,
                          "Removing selected packages...", [TMP_REMOVE_PACKAGES])

    def _after_removal(self, *args):
        """Called when the Console screen closes after the removal script finishes.
        
        Performs a final verification scan to ensure no leftover files remain
        for the removed packages, then asks about GUI restart.
        """
        selected = self._normalize_selected_names(self.pending_selected or self.selected)
        # Build lookup only from current packages (may be stale; that is acceptable here)
        lookup = {item[0]: item for item in (self.packages or [])}
        leftovers = []
        for name in selected:
            if name not in lookup:
                continue
            pkg_name, pt, kind = lookup[name]
            if pt == "dir":
                target = folder_entry_target(pkg_name)
                if target and os.path.isdir(gui_path(target)):
                    leftovers.append(target)
            else:
                targets = find_plugin_folder_targets([pkg_name])
                for target in targets:
                    if os.path.isdir(gui_path(target)):
                        leftovers.append(target)
            if pt != "dir":
                if os.path.exists(gui_path("/var/lib/opkg/info/%s.list" % to_text(pkg_name))) or \
                   os.path.exists(gui_path("/var/lib/dpkg/info/%s.list" % to_text(pkg_name))):
                    leftovers.append(u"Package manager entry: %s" % to_text(pkg_name))

        if leftovers:
            msg = (
                u"Removal finished, but some items may still remain:\n\n"
                u"%s\n\n"
                u"Do you want to restart Enigma2 GUI now?\n"
                u"(A restart may help finalize the removal.)"
            ) % u"\n".join(leftovers[:8])
        else:
            msg = (
                u"Removal finished.\n\n"
                u"All packages and plugin folders have been successfully removed.\n"
                u"Compiled Python files (.pyc, .pyo) and __pycache__ folders have been cleaned.\n\n"
                u"Do you want to restart Enigma2 GUI now?"
            )

        self.session.openWithCallback(
            self._restart_asked,
            MessageBox,
            gui_text(msg),
            MessageBox.TYPE_YESNO,
            default=False,
        )

    def _restart_asked(self, answer):
        """Restart Enigma2 if the user confirmed, then reload the package list."""
        if answer:
            build_restart_script()
            open_console_safe(self.session, None, "Restarting Enigma2...", [TMP_RESTART_GUI])
        self.pending_selected = []
        self.load_packages()

    # -------------------------------------------------------------------------
    # Shell script builders
    # -------------------------------------------------------------------------

    def _remove_script_helpers(self):
        """Return POSIX shell helper function definitions for the removal script."""
        return [
            "has_package_manager() {",
            "    kind=\"$1\"",
            "    if [ \"$kind\" = \"deb\" ]; then",
            "        command -v apt-get >/dev/null 2>&1 || command -v dpkg >/dev/null 2>&1",
            "        return $?",
            "    fi",
            "    command -v opkg >/dev/null 2>&1",
            "}",
            "",
            "is_package_installed() {",
            "    pkg=\"$1\"",
            "    if command -v opkg >/dev/null 2>&1 && opkg status \"$pkg\" 2>/dev/null | grep -q '^Status: .* installed'; then return 0; fi",
            "    if command -v opkg >/dev/null 2>&1 && opkg list-installed \"$pkg\" 2>/dev/null | grep -q \"^$pkg \"; then return 0; fi",
            "    if command -v dpkg-query >/dev/null 2>&1 && dpkg-query -W -f='${Status}' \"$pkg\" 2>/dev/null | grep -q 'install ok installed'; then return 0; fi",
            "    if command -v dpkg >/dev/null 2>&1 && dpkg -s \"$pkg\" 2>/dev/null | grep -q '^Status: install ok installed'; then return 0; fi",
            "    return 1",
            "}",
            "",
            "safe_remove_plugin_dir() {",
            "    target=\"$1\"",
            "    case \"$target\" in",
            "        /usr/lib/enigma2/python/Plugins/Extensions/*|/usr/lib/enigma2/python/Plugins/SystemPlugins/*)",
            "            if [ \"$target\" = \"/usr/lib/enigma2/python/Plugins/Extensions\" ] || [ \"$target\" = \"/usr/lib/enigma2/python/Plugins/SystemPlugins\" ]; then",
            "                echo \"Skipped: refusing to delete plugin root: $target\"",
            "                return 0",
            "            fi",
            "            if [ -d \"$target\" ]; then",
            "                echo \"Removing leftover plugin folder: $target\"",
            # Phase 1: Remove all compiled Python files (.pyc, .pyo)
            "                echo \"Phase 1: Removing compiled Python cache files...\"",
            "                find \"$target\" -type f -name '*.pyc' -exec rm -f {} + 2>/dev/null || true",
            "                find \"$target\" -type f -name '*.pyo' -exec rm -f {} + 2>/dev/null || true",
            # Phase 2: Remove __pycache__ directories (recursive)
            "                echo \"Phase 2: Removing __pycache__ directories...\"",
            "                find \"$target\" -type d -name '__pycache__' -exec rm -rf {} + 2>/dev/null || true",
            # Phase 3: Remove temp/leftover files from package managers
            "                echo \"Phase 3: Removing package manager temp files...\"",
            "                find \"$target\" -type f \\( -name '*.tmp' -o -name '*.bak' -o -name '*.old' -o -name '*.removed' -o -name '*.removing' -o -name '.opkg-*' -o -name '.dpkg-*' -o -name '*.ipk-new' -o -name '*.ipk-old' \\) -exec rm -f {} + 2>/dev/null || true",
            # Phase 4: Verify cache cleanup before folder removal
            "                remaining_pyc=$(find \"$target\" -type f -name '*.pyc' 2>/dev/null | wc -l)",
            "                remaining_pyo=$(find \"$target\" -type f -name '*.pyo' 2>/dev/null | wc -l)",
            "                remaining_pycache=$(find \"$target\" -type d -name '__pycache__' 2>/dev/null | wc -l)",
            "                if [ \"$remaining_pyc\" -gt 0 ] || [ \"$remaining_pyo\" -gt 0 ] || [ \"$remaining_pycache\" -gt 0 ]; then",
            "                    echo \"Warning: Some cache files remain (pyc=$remaining_pyc pyo=$remaining_pyo pycache=$remaining_pycache), retrying aggressive cleanup...\"",
            "                    find \"$target\" -type f \\( -name '*.pyc' -o -name '*.pyo' \\) -delete 2>/dev/null || true",
            "                    find \"$target\" -type d -name '__pycache__' -exec rm -rf {} + 2>/dev/null || true",
            "                fi",
            # Phase 5: Remove the folder itself (with retry)
            "                echo \"Phase 5: Removing plugin folder...\"",
            "                rm -rf \"$target\" 2>/dev/null",
            "                if [ -d \"$target\" ]; then",
            "                    echo \"Warning: Folder still exists after first attempt, retrying...\"",
            "                    chmod -R u+rw \"$target\" 2>/dev/null || true",
            "                    rm -rf \"$target\" 2>/dev/null",
            "                fi",
            # Phase 6: Final verification
            "                if [ -d \"$target\" ]; then",
            "                    echo \"ERROR: Failed to remove plugin folder: $target\"",
            "                    return 1",
            "                else",
            "                    echo \"Plugin folder removed successfully: $target\"",
            "                    return 0",
            "                fi",
            "            else",
            "                echo \"Plugin folder already removed: $target\"",
            "            fi",
            "            ;;",
            "        *)",
            "            echo \"Skipped: path is outside safe plugin roots: $target\"",
            "            ;;",
            "    esac",
            "}",
        ]

    def _post_remove_cleanup_cmds(self, pkg_name, pkg_type):
        """Return shell commands to remove plugin folders after successful package removal.
        
        This performs aggressive cleanup of all Python cache files, __pycache__ directories,
        and the plugin folder itself. Includes verification and retry on failure.
        """
        targets = find_plugin_folder_targets([pkg_name])
        if not targets:
            return []
        quoted_pkg  = shell_quote(pkg_name)
        quoted_type = shell_quote(pkg_type)
        lines = [
            "echo %s" % shell_quote("Checking leftover plugin folders for: %s" % to_text(pkg_name)),
            "if ! has_package_manager %s; then" % quoted_type,
            "    echo %s" % shell_quote("Package manager not available; skipping folder cleanup."),
            "elif is_package_installed %s; then" % quoted_pkg,
            "    echo %s" % shell_quote("Package still installed; keeping plugin folder."),
            "else",
            "    echo %s" % shell_quote("Package removed; performing aggressive folder cleanup..."),
        ]
        for target in targets:
            lines.append("    safe_remove_plugin_dir %s" % shell_quote(target))
        lines.append("fi")
        return lines

    def _build_remove_script(self, selected_names=None):
        """Build the complete shell removal script and write it to TMP_REMOVE_PACKAGES."""
        lookup = {item[0]: item for item in self.packages}
        lines  = [
            "#!/bin/sh",
            "echo 'Enigma2 Uninstaller - starting removal...'",
            "echo 'Package manager handles file removal; plugin folders and cache are cleaned after.'",
        ]
        lines.extend(self._remove_script_helpers())

        for name in (selected_names or self.selected):
            if name not in lookup:
                continue
            pkg_name, pt, kind = lookup[name]
            quoted = shell_quote(pkg_name)
            lines.append("")
            lines.append("echo %s" % shell_quote(
                "--- Removing: %s (%s) ---" % (to_text(pkg_name), to_text(pt).upper())))
            if pt == "dir":
                lines.extend(self._dir_cmds(pkg_name))
            elif pt == "deb":
                lines.extend(self._deb_cmds(quoted))
                lines.extend(self._post_remove_cleanup_cmds(pkg_name, pt))
            else:
                # IPK (opkg) — OpenATV, VTi, Black Hole, Merlin, OpenPLi, etc.
                lines.extend(self._ipk_cmds(quoted))
                lines.extend(self._post_remove_cleanup_cmds(pkg_name, pt))

        lines.extend([
            "",
            "echo ''",
            "echo '=== Final global cleanup pass ==='",
            "echo 'Scanning all plugin roots for orphaned cache files...'",
            "",
            "# Global sweep: remove orphaned .pyc/.pyo/__pycache__ in plugin roots",
            "for root in /usr/lib/enigma2/python/Plugins/Extensions /usr/lib/enigma2/python/Plugins/SystemPlugins; do",
            "    if [ -d \"$root\" ]; then",
            "        echo \"Sweeping: $root\"",
            "        find \"$root\" -type f \\( -name '*.pyc' -o -name '*.pyo' \\) -delete 2>/dev/null || true",
            "        find \"$root\" -type d -name '__pycache__' -empty -exec rmdir {} + 2>/dev/null || true",
            "    fi",
            "done",
            "",
            "echo 'Cleaning package manager cache...'",
            "if command -v opkg >/dev/null 2>&1; then opkg clean >/dev/null 2>&1 || true; fi",
            "if command -v apt-get >/dev/null 2>&1; then apt-get clean >/dev/null 2>&1 || true; fi",
            "echo 'All done. Removal finished.'",
            "exit 0",
        ])
        return write_script(TMP_REMOVE_PACKAGES, lines)

    def _dir_cmds(self, entry_name):
        """Shell commands for removing a directory-only (manually-installed) plugin."""
        target = folder_entry_target(entry_name)
        if not target:
            return ["echo %s" % shell_quote("No safe plugin folder found for this entry; skipped.")]
        return [
            "echo %s" % shell_quote("Removing directory-only plugin: %s" % to_text(target)),
            "safe_remove_plugin_dir %s" % shell_quote(target),
        ]

    def _ipk_cmds(self, quoted):
        """Shell commands for IPK/opkg removal (OpenATV, VTi, Black Hole, Merlin, etc.)."""
        if self.force_remove:
            return [
                "if command -v opkg >/dev/null 2>&1; then",
                "    opkg remove --force-depends %s || opkg remove %s" % (quoted, quoted),
                "else",
                "    echo 'opkg not found on this image'",
                "fi",
            ]
        return [
            "if command -v opkg >/dev/null 2>&1; then",
            "    opkg remove --autoremove %s || opkg remove %s" % (quoted, quoted),
            "else",
            "    echo 'opkg not found on this image'",
            "fi",
        ]

    def _deb_cmds(self, quoted):
        """Shell commands for DEB/dpkg removal (Dreambox DreamOS and dpkg-based images)."""
        if self.force_remove:
            return [
                "if command -v dpkg >/dev/null 2>&1; then",
                "    dpkg --remove --force-all %s || dpkg --purge --force-all %s" % (quoted, quoted),
                "else",
                "    echo 'dpkg not found on this image'",
                "fi",
            ]
        return [
            "if command -v apt-get >/dev/null 2>&1; then",
            "    apt-get remove --purge --auto-remove -y %s" % quoted,
            "elif command -v dpkg >/dev/null 2>&1; then",
            "    dpkg --remove --force-depends %s" % quoted,
            "else",
            "    echo 'apt-get and dpkg not found on this image'",
            "fi",
        ]


# =============================================================================
# Settings screen
# =============================================================================

# =============================================================================
# Settings screen (Dual Implementation)
# =============================================================================

class GraphicSettingScreen(Screen):
    """Graphic version of SettingScreen (for Open Source images).
    Uses SourceList with TemplatedMultiContent for ON/OFF switch graphics.
    """

    def __init__(self, session):
        self.skin = load_skin("setting", "graphic")
        Screen.__init__(self, session)
        self.session = session
        self.skinTitle = gui_text(u"Setting Screen")

        self["list"] = SettingList()
        cfg_data = get_config()
        self.hide_warning = cfg_data.get("hide_warning", False)
        self.hide_details = cfg_data.get("hide_details", False)
        self.refresh_list()

        self["key_red"]   = Label(gui_text(u"Exit"))
        self["key_green"] = Label(gui_text(u"Save"))

        self["actions"] = ActionMap(
            ["Enigma2UninstallerSettingActions", "SetupActions", "ColorActions",
             "OkCancelActions"],
            {
                "save":   self.save,
                "cancel": self.close,
                "red":    self.close,
                "green":  self.save,
                "ok":     self.toggle,
                "left":   self.toggle,
                "right":  self.toggle,
            },
            -1,
        )

    def refresh_list(self):
        items = [
            (u"Hide Warning Message on startup", self.hide_warning),
            (u"Hide Plugin Details Information", self.hide_details)
        ]
        self["list"].set_settings(items)

    def toggle(self):
        idx = self["list"].getSelectionIndex()
        if idx == 0: self.hide_warning = not self.hide_warning
        elif idx == 1: self.hide_details = not self.hide_details
        self.refresh_list()

    def save(self):
        new_cfg = {"hide_warning": self.hide_warning, "hide_details": self.hide_details}
        save_config(new_cfg)
        self.close()


class ConfigSettingScreen(Screen, ConfigListScreen):
    """Standard ConfigList version of SettingScreen (for DreamOS / Dreambox).
    Provides a native, professional look on high-end images.
    """

    def __init__(self, session):
        self.skin = load_skin("setting", "config")
        Screen.__init__(self, session)
        self.session = session
        self.skinTitle = gui_text(u"Setting Screen")

        cfg_data = get_config()
        self.config_hide_warning = ConfigBoolean(default=cfg_data.get("hide_warning", False))
        self.config_hide_details = ConfigBoolean(default=cfg_data.get("hide_details", False))

        self.list = [
            getConfigListEntry(gui_text(u"Hide Warning Message on startup"), self.config_hide_warning),
            getConfigListEntry(gui_text(u"Hide Plugin Details Information"), self.config_hide_details)
        ]
        ConfigListScreen.__init__(self, self.list, session=session)

        self["key_red"]   = Label(gui_text(u"Exit"))
        self["key_green"] = Label(gui_text(u"Save"))

        self["actions"] = ActionMap(
            ["Enigma2UninstallerSettingActions", "SetupActions", "ColorActions"],
            {
                "save":   self.save,
                "cancel": self.close,
                "red":    self.close,
                "green":  self.save,
                "ok":     self.save,
            },
            -1,
        )

    def save(self):
        new_cfg = {
            "hide_warning": self.config_hide_warning.value,
            "hide_details": self.config_hide_details.value,
        }
        save_config(new_cfg)
        self.close()


# Unified SettingScreen for all platforms (DreamOS & Open Source)
# This ensures the beautiful Red/Green switch graphics are used everywhere.
SettingScreen = GraphicSettingScreen


# =============================================================================
# Startup warning screen (closes on any key)
# =============================================================================

class WarningScreen(Screen):
    """Custom warning screen that closes when any common key is pressed.
    Auto-closes after 10 seconds if no key is pressed.
    """
    def __init__(self, session, message):
        width = get_screen_width()
        if width >= 1920:
            self.skin = (
                u'<screen name="WarningScreen" position="center,center" size="1200,650" title=" " flags="wfNoBorder">'
                u'<eLabel position="0,0" size="1200,650" backgroundColor="#101010" zPosition="-2" />'
                u'<eLabel position="0,0" size="1200,70" backgroundColor="#2a2a2a" zPosition="-1" />'
                # Custom Title: Red and Centered as requested
                u'<eLabel text="Security Warning" position="0,10" size="1200,50" font="Regular;36" foregroundColor="#ff0000" halign="center" transparent="1" zPosition="1" />'
                # Separator line under header
                u'<eLabel position="0,70" size="1200,2" backgroundColor="#444444" zPosition="0" />'
                # Main text in Yellow/Gold for emphasis
                u'<widget name="text" position="50,85" size="1100,520" font="Regular;30" foregroundColor="#e0c800" halign="center" valign="center" transparent="1" />'
                u'</screen>'
            )
        else:
            self.skin = (
                u'<screen name="WarningScreen" position="center,center" size="900,450" title=" " flags="wfNoBorder">'
                u'<eLabel position="0,0" size="900,450" backgroundColor="#101010" zPosition="-2" />'
                u'<eLabel position="0,0" size="900,50" backgroundColor="#2a2a2a" zPosition="-1" />'
                # Custom Title: Red and Centered as requested
                u'<eLabel text="Security Warning" position="0,5" size="900,40" font="Regular;26" foregroundColor="#ff0000" halign="center" transparent="1" zPosition="1" />'
                # Separator line under header
                u'<eLabel position="0,50" size="900,2" backgroundColor="#444444" zPosition="0" />'
                # Main text in Yellow/Gold for emphasis
                u'<widget name="text" position="20,60" size="860,360" font="Regular;22" foregroundColor="#e0c800" halign="center" valign="center" transparent="1" />'
                u'</screen>'
            )
        Screen.__init__(self, session)
        self.skinTitle = u" "
        self["text"] = Label(message)

        # Timer for 10-second auto-close
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self._on_timer)
        except AttributeError:
            self.timer.callback.append(self._on_timer)
        self.timer.start(10000, True)  # 10 seconds, one-shot

        # ActionMap with extreme priority and comprehensive context list
        self["actions"] = ActionMap(
            ["WizardActions", "SetupActions", "GlobalActions", "ColorActions",
             "DirectionActions", "MenuActions", "OkCancelActions"],
            {
                "ok":     self._close_safe,
                "back":   self._close_safe,
                "cancel": self._close_safe,
                "red":    self._close_safe,
                "green":  self._close_safe,
                "yellow": self._close_safe,
                "blue":   self._close_safe,
                "up":     self._close_safe,
                "down":   self._close_safe,
                "left":   self._close_safe,
                "right":  self._close_safe,
                "menu":   self._close_safe,
                "exit":   self._close_safe,
            },
            -2,  # Highest priority (lower number = higher priority in Enigma2)
        )

    def _on_timer(self):
        """Called when the 10-second auto-close timer fires."""
        self._close_safe()

    def _close_safe(self):
        """Stop the timer before closing to prevent double-close crashes."""
        try:
            self.timer.stop()
        except Exception:
            pass
        self.close()

# =============================================================================
# Removal method selection dialog
# =============================================================================

class RemovalMethodBox(Screen):
    """Dialog for choosing between Normal and Force removal methods.

    Normal - Standard package manager uninstall with dependency handling.
    Force  - Overrides dependency checks; for use on broken packages only.
    """

    def __init__(self, session):
        width = get_screen_width()
        if width >= 1920:
            skin_xml = (
                u'<screen name="RemovalMethodBox" position="center,center" size="1400,600" title="Removal Method">'
                u'<eLabel position="0,0" size="1400,600" backgroundColor="#181818" zPosition="-2" />'
                u'<eLabel position="0,0" size="1400,15" backgroundColor="#3b3f46" zPosition="-1" />'
                u'<widget name="hint" position="100,45" size="1200,40" font="Regular;31" halign="center" valign="center" foregroundColor="#e0c800" transparent="1" />'
                u'<eLabel position="20,120" size="1360,150" backgroundColor="#202020" zPosition="0" />'
                u'<widget name="opt_normal" position="40,135" size="1320,35" font="Regular;31" foregroundColor="#f0a030" transparent="1" zPosition="1" />'
                u'<widget name="desc_normal" position="60,180" size="1280,35" font="Regular;24" foregroundColor="#d8d8d8" transparent="1" zPosition="1" />'
                u'<eLabel position="20,300" size="1360,150" backgroundColor="#202020" zPosition="0" />'
                u'<widget name="opt_force" position="40,315" size="1320,35" font="Regular;31" foregroundColor="#f0f0f0" transparent="1" zPosition="1" />'
                u'<widget name="desc_force" position="60,360" size="1280,35" font="Regular;24" foregroundColor="#d8d8d8" transparent="1" zPosition="1" />'
                u'<ePixmap pixmap="{PATH}/buttons/red.png" position="200,530" size="270,45" alphatest="blend" zPosition="1" />'
                u'<widget name="key_red" position="200,530" size="270,45" font="Regular;28" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="2" />'
                u'<ePixmap pixmap="{PATH}/buttons/green.png" position="930,530" size="270,45" alphatest="blend" zPosition="1" />'
                u'<widget name="key_green" position="930,530" size="270,45" font="Regular;28" halign="center" valign="center" foregroundColor="#000000" transparent="1" zPosition="2" />'
                u'</screen>'
            )
        else:
            skin_xml = (
                u'<screen name="RemovalMethodBox" position="center,center" size="960,420" title="Removal Method">'
                u'<eLabel position="0,0" size="960,420" backgroundColor="#181818" zPosition="-2" />'
                u'<eLabel position="0,0" size="960,12" backgroundColor="#3b3f46" zPosition="-1" />'
                u'<widget name="hint" position="80,30" size="800,35" font="Regular;24" halign="center" valign="center" foregroundColor="#e0c800" transparent="1" />'
                u'<eLabel position="15,85" size="930,105" backgroundColor="#202020" zPosition="0" />'
                u'<widget name="opt_normal" position="30,95" size="900,25" font="Regular;24" foregroundColor="#f0a030" transparent="1" zPosition="1" />'
                u'<widget name="desc_normal" position="45,130" size="870,25" font="Regular;17" foregroundColor="#d8d8d8" transparent="1" zPosition="1" />'
                u'<eLabel position="15,215" size="930,105" backgroundColor="#202020" zPosition="0" />'
                u'<widget name="opt_force" position="30,225" size="900,25" font="Regular;24" foregroundColor="#f0f0f0" transparent="1" zPosition="1" />'
                u'<widget name="desc_force" position="45,260" size="870,25" font="Regular;17" foregroundColor="#d8d8d8" transparent="1" zPosition="1" />'
                u'<ePixmap pixmap="{PATH}/buttons/red.png" position="120,370" size="210,35" alphatest="blend" zPosition="1" />'
                u'<widget name="key_red" position="120,370" size="210,35" font="Regular;22" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="2" />'
                u'<ePixmap pixmap="{PATH}/buttons/green.png" position="630,370" size="210,35" alphatest="blend" zPosition="1" />'
                u'<widget name="key_green" position="630,370" size="210,35" font="Regular;22" halign="center" valign="center" foregroundColor="#000000" transparent="1" zPosition="2" />'
                u'</screen>'
            )

        skin_xml = skin_xml.replace(u"{PATH}", to_text(plugin_path()))
        # Note: adjust_opensource_skin explicitly skips RemovalMethodBox by name,
        # so its inline positions are always used unchanged on all images.
        self.skin = gui_text(skin_xml)
        Screen.__init__(self, session)
        self.session = session
        self.skinTitle = gui_text(u"Removal Method")
        # Header title widget removed from skin per user request
        self["hint"]       = Label(gui_text(u"Select the removal method:"))
        self["desc_normal"]= Label(gui_text(u"Recommended: standard uninstall with safe dependency handling."))
        self["desc_force"] = Label(gui_text(u"Use only when normal removal fails. May ignore broken dependencies."))
        self["key_red"]    = Label(gui_text(u"Cancel"))
        self["key_green"]  = Label(gui_text(u"OK"))
        self.selected_method = "normal"
        self["opt_normal"] = Label(gui_text(u""))
        self["opt_force"]  = Label(gui_text(u""))
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok":     self.confirm,
                "green":  self.confirm,
                "cancel": self.cancel,
                "red":    self.cancel,
                "up":     self.select_normal,
                "down":   self.select_force,
                "left":   self.select_normal,
                "right":  self.select_force,
            },
            -1,
        )
        self.onLayoutFinish.append(self._refresh_selection)

    def _refresh_selection(self):
        """Update the visual > marker for the chosen method."""
        if self.selected_method == "normal":
            set_label_safe(self["opt_normal"], u"> Normal remove (recommended)")
            set_label_safe(self["opt_force"],  u"  Force remove (broken packages only)")
        else:
            set_label_safe(self["opt_normal"], u"  Normal remove (recommended)")
            set_label_safe(self["opt_force"],  u"> Force remove (broken packages only)")

    def select_normal(self):
        """Switch selection to Normal remove method."""
        self.selected_method = "normal"
        self._refresh_selection()

    def select_force(self):
        """Switch selection to Force remove method."""
        self.selected_method = "force"
        self._refresh_selection()

    def confirm(self):
        """Close and return the selected method."""
        label = (gui_text(u"Normal remove (recommended)") if self.selected_method == "normal"
                 else gui_text(u"Force remove (broken packages only)"))
        self.close((label, self.selected_method))

    def cancel(self):
        """Close without selecting."""
        self.close(None)


# =============================================================================
# Confirmation dialog
# =============================================================================

class CustomMessageBox(Screen):
    """Yes/No confirmation dialog with a highlighted list of package names.
    Green = Yes (confirm).  Red = No (cancel).
    """

    def __init__(self, session, message, title=PLUGIN_NAME,
                 package_names=u"", footer_message=u"", count_text=u""):
        self.skin = load_skin("msg")
        Screen.__init__(self, session)
        self.session   = session
        self.skinTitle = gui_text(title)
        self["text_top"]       = Label(gui_text(message))
        self["count_text"]     = Label(gui_text(count_text))
        self["package_names"]  = Label(gui_text(package_names))
        self["text_bottom"]    = Label(gui_text(footer_message))
        self["key_red"]        = Label(gui_text(u"No"))
        self["key_green"]      = Label(gui_text(u"Yes"))
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {"ok": self.confirm, "green": self.confirm, "cancel": self.cancel, "red": self.cancel},
            -1,
        )

    def confirm(self):
        """User pressed Yes / Green / OK - return True to the callback."""
        self.close(True)

    def cancel(self):
        """User pressed No / Red / Cancel - return False to the callback."""
        self.close(False)
