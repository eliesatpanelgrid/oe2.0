# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
#
# plugin.py - Enigma2 entry points only
# Part of: Enigma2 Uninstaller Plugin
# Created by iet5
# Version: 1.1
# Compatible: Python 2.7 / Python 3.12 / Python 3.13 / Python 3.14
# Images: OpenATV, VTi, Black Hole, OpenPLi, OpenHDF, DreamOS, Merlin OE-2.5,
#         and all Enigma2 open-source images
# Devices: Dreambox 920 (DM920), Vu+ (VuPlus), and all standard Enigma2 boxes
#
# Module layout:
#   __init__.py  - Base constants, text/path converters, device detection
#   core.py      - Plugin constants, helpers, skin loader, shell utilities
#   packages.py  - Package detection, parsing, path safety, protection checks
#   widgets.py   - PackageList widget (SourceList + TemplatedMultiContent)
#   screens.py   - Enigma2UninstallerMain, RemovalMethodBox, CustomMessageBox
#   plugin.py    - Enigma2 Plugins() entry point and main() launcher  (this file)
#

from Plugins.Plugin import PluginDescriptor

from .core import PLUGIN_NAME, PLUGIN_ICON, PLUGIN_DESC, gui_text
from .screens import Enigma2UninstallerMain


def main(session, **kwargs):
    """Open the main Enigma2 Uninstaller screen."""
    session.open(Enigma2UninstallerMain)


def Plugins(**kwargs):
    """Register the plugin in the Enigma2 plugin browser menu."""
    return [
        PluginDescriptor(
            name=gui_text(PLUGIN_NAME),
            description=gui_text(PLUGIN_DESC),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=PLUGIN_ICON,
            fnc=main,
        )
    ]
