# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
#
# packages.py - Package detection, parsing, path safety, and protection checks
# Part of: Enigma2 Uninstaller Plugin
# Created by iet5
# Compatible: Python 2.7 / Python 3.12 / Python 3.13 / Python 3.14
#

import os
import sys

# Import shared helpers and constants from core.py
# core.py re-exports to_text and device detectors from __init__.py
from .core import (
    PLUGIN_ROOTS, PACKAGE_PREFIXES, PROTECTED_SYSTEMPLUGIN_SUFFIXES,
    PLUGIN_FOLDER, PLUGIN_NAME,
    command_exists, run_command, safe_listdir, read_file, gui_path,
    to_text, is_dreambox, is_vuplus, is_dreamos, is_vti, is_blackhole, is_openatv,
)


# =============================================================================
# Package classification helpers
# =============================================================================

def is_enigma_package(name):
    """Return True only for Enigma2 packages this plugin is allowed to list."""
    lower = to_text(name).lower()
    for prefix in PACKAGE_PREFIXES:
        if lower.startswith(prefix):
            return True
    return False


def package_kind(name):
    """Classify a package name into a human-readable kind label.

    Returns one of: 'skin', 'system', 'extension', 'picon', 'plugin'.
    """
    lower = to_text(name).lower()
    if lower.startswith("enigma2-skin-") or "-skins-" in lower:
        return "skin"
    if "-systemplugins-" in lower or "-systemplugin-" in lower:
        return "system"
    if "-extensions-" in lower:
        return "extension"
    if lower.startswith("enigma2-picon-"):
        return "picon"
    return "plugin"


def parse_image_name(text):
    """Detect the running image name from Enigma2 identification files."""
    lower = to_text(text).lower()
    if "openatv"                        in lower: return "OpenATV"
    if "vti" in lower or "vu+ team image" in lower: return "VTi"
    if "blackhole" in lower or "black hole" in lower: return "Black Hole"
    if "merlin"                         in lower: return "Merlin"
    if "openpli"                        in lower: return "OpenPLi"
    if "openhdf"                        in lower: return "OpenHDF"
    if "egami"                          in lower: return "Egami"
    if "newnigma"                       in lower: return "Newnigma2"
    if "dreamos"                        in lower: return "DreamOS"
    if "dream"                          in lower: return "Dreambox"
    return "Open Source"


def detect_environment():
    """Detect box type, image, package managers, and Python version.

    Returns a dict with keys:
      box, model, brand, image, managers, python,
      dreamos, vti, blackhole, openatv
    """
    # Use the shared helpers from __init__.py - they already return lowercase
    from . import box_model as _box_model, box_brand as _box_brand
    model = _box_model()
    brand = _box_brand()
    blob = u"\n".join([
        read_file("/etc/issue"),
        read_file("/etc/image-version"),
        read_file("/etc/image.info"),
        read_file("/etc/opkg/all-feed.conf"),
        read_file("/etc/hostname"),
    ])

    if is_dreambox():
        box = "Dreambox"
    elif is_vuplus():
        box = "Vu+"
    else:
        box = "Enigma2"

    managers = []
    if command_exists("opkg") or os.path.exists("/var/lib/opkg/status"):
        managers.append("opkg")
    if command_exists("dpkg") or os.path.exists("/var/lib/dpkg/status"):
        managers.append("dpkg")

    return {
        "box":      box,
        "model":    model or "Unknown",
        "brand":    brand or "Unknown",
        "image":    parse_image_name(blob),
        "managers": managers,
        "python":   "%d.%d.%d" % sys.version_info[:3],
        "dreamos":  is_dreamos(),
        "vti":      is_vti(),
        "blackhole": is_blackhole(),
        "openatv":  is_openatv(),
    }


# =============================================================================
# Package list parsing (opkg / dpkg / status files / info directories)
# =============================================================================

def parse_opkg_output(output):
    """Parse 'opkg list-installed' output -> [(name, 'ipk', kind), ...]."""
    result = []
    for line in to_text(output).splitlines():
        line = line.strip()
        if not line:
            continue
        # Format: "package-name - version - description" or just "package-name"
        name = line.split(" - ", 1)[0].strip() if " - " in line else (line.split()[0] if line.split() else u"")
        if name and is_enigma_package(name):
            result.append((name, "ipk", package_kind(name)))
    return result


def parse_dpkg_output(output):
    """Parse 'dpkg-query -W -f=${Package}' output -> [(name, 'deb', kind), ...]."""
    result = []
    for line in to_text(output).splitlines():
        name = line.strip()
        if name and is_enigma_package(name):
            result.append((name, "deb", package_kind(name)))
    return result


def parse_status_file(path, pkg_type):
    """Parse an opkg or dpkg status file -> [(name, pkg_type, kind), ...]."""
    result = []
    for line in read_file(path).splitlines():
        if line.startswith("Package:"):
            name = line.split(":", 1)[1].strip()
            if name and is_enigma_package(name):
                result.append((name, pkg_type, package_kind(name)))
    return result


def scan_info_dir(path, pkg_type):
    """Scan a package manager info directory for .list/.control files.
    Returns [(name, pkg_type, kind), ...]."""
    result = []
    seen   = set()
    for item in safe_listdir(path):
        item = to_text(item)
        if   item.endswith(".list"):    name = item[:-5]
        elif item.endswith(".control"): name = item[:-8]
        else: continue
        if name and name not in seen and is_enigma_package(name):
            seen.add(name)
            result.append((name, pkg_type, package_kind(name)))
    return result


def scan_plugin_folders(existing_packages=None):
    """Scan Extensions/SystemPlugins for manually-installed plugins not tracked
    by any package manager. These are returned as 'dir' type entries."""
    result      = []
    seen_paths  = {}
    existing_paths = {}
    existing_names = {}

    # Build a set of real paths and normalized names for already-tracked packages
    for item in existing_packages or []:
        try:
            name = item[0]
            # Normalize the package name and its potential suffix for fuzzy matching
            existing_names[normalize_for_match(name)] = True
            suffix, _ = extract_plugin_suffix(name)
            if suffix:
                existing_names[normalize_for_match(suffix)] = True
        except Exception:
            continue

        # Map package to its physical folder(s) using system file lists or fuzzy matching
        for target in find_plugin_folder_targets([name]):
            try:
                full_path = gui_path(target)
                existing_paths[os.path.realpath(full_path)] = True
                # Also add the folder name itself to existing_names for redundant safety
                folder_name = os.path.basename(target)
                if folder_name:
                    existing_names[normalize_for_match(folder_name)] = True
            except Exception:
                pass

    roots = (
        (PLUGIN_ROOTS[0], u"Extensions",    u"extension folder"),
        (PLUGIN_ROOTS[1], u"SystemPlugins", u"system folder"),
    )
    for root, root_type, kind in roots:
        if not os.path.isdir(gui_path(root)):
            continue
        for folder in safe_listdir(root):
            folder = to_text(folder)
            if not folder or folder.startswith(u".") or folder == u"__pycache__":
                continue
            
            # Unification Logic: Skip if this folder name matches an existing package name/suffix
            folder_norm = normalize_for_match(folder)
            is_duplicate = False
            for existing_norm in existing_names:
                if folder_norm and existing_norm and (folder_norm in existing_norm or existing_norm in folder_norm):
                    is_duplicate = True
                    break
            
            if is_duplicate:
                continue

            full = os.path.join(root, folder)
            if not os.path.isdir(gui_path(full)) or not is_safe_plugin_path(full):
                continue
            
            try:
                real_full = os.path.realpath(gui_path(full))
            except Exception:
                real_full = full
            
            # Skip if the physical path is already owned by a package
            if real_full in existing_paths or real_full in seen_paths:
                continue
            
            seen_paths[real_full] = True
            result.append((folder_entry_name(root_type, folder), u"dir", kind))
    return result


def installed_packages():
    """Return a sorted, deduplicated list of installed Enigma2 packages.

    Sources queried in priority order:
      1. opkg list-installed        (OpenATV, VTi, Black Hole, OpenPLi, OpenHDF, etc.)
      2. /var/lib/opkg/status       (fallback when opkg command is absent)
      3. /var/lib/opkg/info/*.list
      4. dpkg-query                 (DreamOS / Dreambox DEB-based images)
      5. /var/lib/dpkg/status
      6. /var/lib/dpkg/info/*.list
      7. Physical plugin folder scan (manually copied / extracted plugins)

    DEB entries take priority over IPK when both exist for the same package
    (common on DreamOS where dpkg and opkg can coexist).
    """
    pkgs = []

    # --- IPK / opkg (OpenATV, VTi, Black Hole, OpenPLi, VuPlus images, etc.) ---
    if command_exists("opkg"):
        pkgs.extend(parse_opkg_output(run_command(["opkg", "list-installed"])))
    pkgs.extend(parse_status_file("/var/lib/opkg/status", "ipk"))
    pkgs.extend(scan_info_dir("/var/lib/opkg/info", "ipk"))

    # --- DEB / dpkg (Dreambox DreamOS and dpkg-based images) ---
    if command_exists("dpkg-query"):
        pkgs.extend(parse_dpkg_output(run_command(["dpkg-query", "-W", "-f=${Package}\n"])))
    pkgs.extend(parse_status_file("/var/lib/dpkg/status", "deb"))
    pkgs.extend(scan_info_dir("/var/lib/dpkg/info", "deb"))

    # Deduplicate - prefer DEB over IPK when both exist (DreamOS coexistence scenario)
    merged = {}
    for name, pt, kind in pkgs:
        key = to_text(name).lower()
        if key not in merged or (merged[key][1] == "ipk" and pt == "deb"):
            merged[key] = (name, pt, kind)

    # Add manually-installed folder-only plugins (not tracked by any package manager)
    for name, pt, kind in scan_plugin_folders(merged.values()):
        key = to_text(name).lower()
        if key not in merged:
            merged[key] = (name, pt, kind)

    # --- Final Aggressive Deduplication Pass ---
    # Even if path-based detection failed, we compare names one last time.
    # If a DIR entry's folder name is found within a DEB/IPK package name, it's a duplicate.
    pkg_entries = [v for v in merged.values() if v[1] in ("deb", "ipk")]
    pkg_norms   = [normalize_for_match(v[0]) for v in pkg_entries]
    
    clean_merged = {}
    for key, item in merged.items():
        name, pt, kind = item
        if pt == "dir":
            _, folder = folder_entry_parts(name)
            folder_norm = normalize_for_match(folder)
            
            is_duplicate = False
            for p_norm in pkg_norms:
                if not folder_norm or not p_norm:
                    continue
                # Aggressive case-insensitive fuzzy match
                if folder_norm in p_norm or p_norm in folder_norm:
                    is_duplicate = True
                    break
            
            if is_duplicate:
                continue
                
        clean_merged[key] = item

    return sorted(clean_merged.values(), key=lambda x: to_text(x[0]).lower())


# =============================================================================
# Path safety helpers
# =============================================================================

def is_safe_plugin_path(path):
    """Return True only if path is strictly inside one of the two PLUGIN_ROOTS.
    The root directories themselves are never safe deletion targets."""
    try:
        real_path = os.path.realpath(gui_path(path))
    except Exception:
        return False
    for root in PLUGIN_ROOTS:
        try:
            real_root = os.path.realpath(gui_path(root))
        except Exception:
            continue
        if real_path == real_root:
            return False                          # root itself - never delete
        if real_path.startswith(real_root + os.sep):
            return True                           # strictly inside root - safe
    return False


def normalize_for_match(value):
    """Strip all non-alphanumeric characters and lowercase for safe fuzzy matching."""
    value = to_text(value).lower()
    return u"".join(ch for ch in value if ch.isalnum())


def extract_plugin_suffix(package_name):
    """Return (suffix, root_type) from an Enigma2 plugin package name.
    Example: 'enigma2-plugin-extensions-autotimer' -> ('autotimer', 'Extensions')
    Returns ('', '') for non-plugin packages."""
    name = to_text(package_name).strip().lower()
    for prefix, root_type in (
        (u"enigma2-plugin-extensions-",    u"Extensions"),
        (u"enigma2-plugin-systemplugins-", u"SystemPlugins"),
        (u"enigma2-plugin-systemplugin-",  u"SystemPlugins"),
    ):
        if name.startswith(prefix):
            return name[len(prefix):], root_type
    return u"", u""


def extract_skin_suffix(package_name):
    """Return a best-effort skin folder suffix from a skin package name."""
    name = to_text(package_name).strip().lower()
    for prefix in (
        u"enigma2-skin-",
        u"enigma2-plugin-skins-",
        u"enigma2-plugin-extensions-skin-",
        u"enigma2-plugin-extensions-skins-",
    ):
        if name.startswith(prefix):
            return name[len(prefix):]
    if u"-skins-" in name:
        return name.split(u"-skins-", 1)[1]
    return u""


def folder_entry_name(root_type, folder):
    """Return a 'RootType/FolderName' display string for a disk-only plugin entry."""
    return u"%s/%s" % (to_text(root_type), to_text(folder))


def folder_entry_parts(entry_name):
    """Return (root_type, folder) from a 'RootType/FolderName' entry string."""
    name = to_text(entry_name).strip()
    if name.startswith(u"Extensions/"):
        return u"Extensions",    name.split(u"/", 1)[1]
    if name.startswith(u"SystemPlugins/"):
        return u"SystemPlugins", name.split(u"/", 1)[1]
    return u"", u""


def folder_entry_target(entry_name):
    """Return the absolute path for a directory-only list entry, or '' if unsafe."""
    root_type, folder = folder_entry_parts(entry_name)
    if not root_type or not folder:
        return u""
    # Prevent path traversal attacks in folder names
    if u"/" in folder or u"\\" in folder or folder in (u".", u".."):
        return u""
    target = os.path.join(
        PLUGIN_ROOTS[0] if root_type == u"Extensions" else PLUGIN_ROOTS[1],
        folder
    )
    return target if is_safe_plugin_path(target) else u""


def find_plugin_folder_targets(selected_names):
    """Find absolute plugin folder paths for the given list of package names.
    Uses accurate system file lists and fuzzy matching as fallback."""
    targets = []
    seen    = {}
    for package_name in selected_names or []:
        package_name = to_text(package_name)
        # Direct match for 'dir' type entries (manually-installed plugins)
        direct = folder_entry_target(package_name)
        if direct and direct not in seen:
            targets.append(direct)
            seen[direct] = True
            continue

        # --- Method 1: Check package manager .list files for accuracy ---
        found_via_list = False
        for info_dir in ("/var/lib/opkg/info", "/var/lib/dpkg/info"):
            list_file = os.path.join(info_dir, "%s.list" % package_name)
            if os.path.exists(gui_path(list_file)):
                for line in read_file(list_file).splitlines():
                    line = to_text(line).strip()
                    for root in PLUGIN_ROOTS:
                        if line.startswith(root) and line != root:
                            rel = line[len(root):].lstrip("/")
                            if rel:
                                folder = rel.split("/")[0]
                                full = os.path.join(root, folder)
                                if is_safe_plugin_path(full) and full not in seen:
                                    targets.append(full)
                                    seen[full] = True
                                    found_via_list = True
                if found_via_list: break

        if found_via_list: continue

        # --- Method 2: Fuzzy matching by suffix (fallback) ---
        suffix, root_type = extract_plugin_suffix(package_name)
        if not suffix:
            continue
        suffix_norm = normalize_for_match(suffix)
        roots = (
            [PLUGIN_ROOTS[0]] if root_type == u"Extensions"    else
            [PLUGIN_ROOTS[1]] if root_type == u"SystemPlugins" else []
        )
        for root in roots:
            for folder in safe_listdir(root):
                full = os.path.join(root, to_text(folder))
                if not os.path.isdir(gui_path(full)):
                    continue
                if normalize_for_match(folder) == suffix_norm:
                    if is_safe_plugin_path(full) and full not in seen:
                        targets.append(full)
                        seen[full] = True
    return targets


# =============================================================================
# Active skin detection
# =============================================================================

def active_skin_value():
    """Read the currently active skin path/name from /etc/enigma2/settings."""
    for line in read_file("/etc/enigma2/settings").splitlines():
        line = to_text(line).strip()
        if line.startswith("config.skin.primary_skin="):
            return line.split("=", 1)[1].strip()
    return u""


def is_active_skin_package(package_name):
    """Return True when package_name appears to provide the currently active skin."""
    suffix = extract_skin_suffix(package_name)
    if not suffix:
        return False
    active = active_skin_value()
    if not active:
        return False
    suffix_norm = normalize_for_match(suffix)
    active_norm = normalize_for_match(active)
    return bool(suffix_norm and active_norm and suffix_norm in active_norm)


# =============================================================================
# Protected package checks
# =============================================================================

def protected_removal_reason(package_name):
    """Return an English reason string when removing package_name is dangerous.
    Returns empty string (u'') when removal is safe to proceed.

    Checks performed (in order):
      1. Is this the running uninstaller plugin itself?
      2. Is this a core Enigma2 SystemPlugin (from the protected suffix list)?
      3. Is this the currently active skin?
    """
    name        = to_text(package_name).strip()
    lower       = name.lower()
    folder_root, folder_name = folder_entry_parts(name)
    folder_norm = normalize_for_match(folder_name)
    suffix, root_type = extract_plugin_suffix(lower)
    suffix_norm = normalize_for_match(suffix)
    self_norms  = (
        normalize_for_match(PLUGIN_FOLDER),
        normalize_for_match(PLUGIN_NAME),
    )

    # 1. Block removing this running uninstaller plugin
    if folder_norm and folder_norm in self_norms:
        return (u"This is the currently running uninstaller plugin. "
                u"Removing it while it is open may crash the current session.")
    if suffix_norm and suffix_norm in self_norms:
        return (u"This is the currently running uninstaller plugin. "
                u"Removing it while it is open may crash the current session.")

    # 2. Block removing core SystemPlugins (folder-type entries)
    if folder_root == u"SystemPlugins" and folder_norm in PROTECTED_SYSTEMPLUGIN_SUFFIXES:
        return (u"This is a core system plugin required for normal Enigma2 operation. "
                u"Removing it may damage the image or prevent the receiver from working correctly.")

    # 2b. Block removing core SystemPlugins (package-type entries)
    if root_type == u"SystemPlugins" and suffix_norm in PROTECTED_SYSTEMPLUGIN_SUFFIXES:
        return (u"This is a core system plugin required for normal Enigma2 operation. "
                u"Removing it may damage the image or prevent the receiver from working correctly.")

    # 3. Block removing the currently active skin
    if is_active_skin_package(lower):
        return (u"This is the currently active skin. "
                u"Removing it will immediately crash or break the Enigma2 user interface.")

    return u""


def protected_selection(names):
    """Return [(package_name, reason), ...] for packages that cannot be safely removed."""
    blocked = []
    for name in names or []:
        reason = protected_removal_reason(name)
        if reason:
            blocked.append((name, reason))
    return blocked


def format_protected_message(blocked):
    """Build a clear, English user-facing message for packages that cannot be removed."""
    lines = [u"The following package(s) cannot be removed:", u""]
    for idx, (name, reason) in enumerate((blocked or [])[:10]):
        lines.append(u"%d. %s" % (idx + 1, to_text(name)))
        lines.append(u"   Reason: %s" % to_text(reason))
    if blocked and len(blocked) > 10:
        lines.append(u"... and %d more package(s) were also blocked." % (len(blocked) - 10))
    lines.extend([
        u"",
        u"Please deselect these packages before proceeding.",
        u"They are protected to prevent damaging the image or stopping Enigma2 from working.",
    ])
    return u"\n".join(lines)
