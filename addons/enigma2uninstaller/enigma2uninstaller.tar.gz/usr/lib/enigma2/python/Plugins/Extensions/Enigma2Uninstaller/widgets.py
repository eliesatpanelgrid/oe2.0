# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
#
# widgets.py - Package list widget (new skin: SourceList + TemplatedMultiContent)
# Part of: Enigma2 Uninstaller Plugin
# Created by iet5
# Compatible: Python 2.7 / Python 3.12 / Python 3.13 / Python 3.14
#
# The plugin uses ONLY the new graphic skin (SourceList + TemplatedMultiContent).
# Each row = (text_string, toggle_pixmap).
# The pixmap is rendered on the RIGHT side of each row via the skin XML template.
# Selection state is shown via the ON/OFF pixmap on the right of each row.
#
# NOTE on SourceList instantiation:
#   SourceList is a C-extension type on DreamOS and Merlin OE images.
#   We subclass it normally (no __new__ + __class__ tricks) to ensure all
#   C-side attributes (downstream_elements, changed, etc.) are initialised
#   correctly. Using __new__ + __class__ reassignment on a C-extension type
#   leaves those attributes absent and crashes skin.py on applySkin().
#

from Components.Sources.List import List as SourceList

# loadPixmap - tries all known import locations for cross-image compatibility.
# DreamOS/Merlin uses enigma.loadPixmap; older/open-source images use Tools.LoadPixmap.
loadPixmap = None
try:
    from enigma import loadPixmap
except Exception:
    pass
if loadPixmap is None:
    try:
        from Tools.LoadPixmap import LoadPixmap as loadPixmap
    except Exception:
        pass
if loadPixmap is None:
    try:
        from Tools.LoadPixmap import loadPixmap
    except Exception:
        pass
if loadPixmap is None:
    # Last-resort no-op stub - ensures code never raises NameError at runtime
    def loadPixmap(path, desktop=None):
        return None

try:
    from enigma import getDesktop
except Exception:
    getDesktop = None

from .core import (
    get_screen_width,
    gui_text, gui_path, format_package_row_text,
    plugin_path,
)


# =============================================================================
# Pixmap loading helper
# =============================================================================

def _try_load_pixmap(path):
    """Load a pixmap trying both calling conventions (with / without desktop).

    Some Enigma2 images require the desktop argument; others reject it or
    raise a TypeError.  We try both to maximise cross-image compatibility.
    Returns the pixmap object, or None if loading fails on all attempts.
    """
    try:
        pix = loadPixmap(gui_path(path))
        if pix is not None:
            return pix
    except Exception:
        pass
    try:
        desktop = getDesktop(0) if getDesktop is not None else None
        pix = loadPixmap(gui_path(path), desktop)
        if pix is not None:
            return pix
    except Exception:
        pass
    return None


# =============================================================================
# Package list widget - new skin (SourceList + TemplatedMultiContent)
# =============================================================================

class PackageList(SourceList):
    """SourceList-backed package list that renders the new graphic skin.

    Each row is a (text_string, toggle_pixmap) tuple:
      index 0 - package text displayed by MultiContentEntryText  (text=0 in XML)
      index 1 - ON or OFF pixmap displayed by MultiContentEntryPixmapAlphaTest (png=1 in XML)

    The pixmap appears on the RIGHT side of every row as defined in the skin XML.
      OK button - selects / deselects the highlighted package (pixmap toggles OFF <-> ON)

    Resolution-aware pixmap loading:
      HD  (< 1920 px) : on_row_hd.png  / off_row_hd.png
      FHD (>= 1920 px): on_row_fhd.png / off_row_fhd.png
    """

    def __init__(self):
        SourceList.__init__(self, [])
        self.screen_width = get_screen_width()
        self.pix_on  = None
        self.pix_off = None
        self._load_toggle_pixmaps()

    def _load_toggle_pixmaps(self):
        """Load ON/OFF toggle pixmaps from the buttons folder.

        HD  (< 1920 px) : on_row_hd.png  / off_row_hd.png
        FHD (>= 1920 px): on_row_fhd.png / off_row_fhd.png
        Falls back to None (no pixmap) if the files cannot be loaded.
        """
        try:
            if self.screen_width >= 1920:
                on_name  = 'on_row_fhd.png'
                off_name = 'off_row_fhd.png'
            else:
                on_name  = 'on_row_hd.png'
                off_name = 'off_row_hd.png'
            self.pix_on  = _try_load_pixmap(plugin_path('buttons', on_name))
            self.pix_off = _try_load_pixmap(plugin_path('buttons', off_name))
        except Exception:
            self.pix_on  = None
            self.pix_off = None

    def set_packages(self, visible_rows, selected_names, hide_details=False):
        """Populate the list with (text, toggle_pixmap) rows.

        visible_rows   - list of (name, pt, kind) tuples from packages.py
        selected_names - list or set of package names currently toggled ON
        hide_details   - if True, hide [kind] (e.g. [DEB]) in the row text
        """
        rows = []
        for name, pt, kind in visible_rows:
            pix = self.pix_on if name in selected_names else self.pix_off
            rows.append((gui_text(format_package_row_text(name, pt, kind, hide_details)), pix))
        self.setList(rows)

    def getSelectionIndex(self):
        """Return the current cursor row index (0-based).
        Falls back to self.index or 0 if getIndex() is unavailable."""
        try:
            return self.getIndex()
        except Exception:
            return getattr(self, "index", 0)

    def moveToIndex(self, index):
        """Move the cursor to the given row index.
        Uses setIndex() on modern images; falls back to direct attribute write."""
        try:
            self.setIndex(index)
        except Exception:
            try:
                self.index = index
            except Exception:
                pass

# =============================================================================
# Setting list widget - for SettingScreen with ON/OFF switches
# =============================================================================

class SettingList(SourceList):
    """SourceList-backed list for settings.
    Renders rows with (text, ON/OFF pixmap).
    """

    def __init__(self):
        SourceList.__init__(self, [])
        self.screen_width = get_screen_width()
        self.pix_on  = None
        self.pix_off = None
        self._load_toggle_pixmaps()

    def _load_toggle_pixmaps(self):
        """Same logic as PackageList for consistency."""
        try:
            if self.screen_width >= 1920:
                on_name  = 'on_row_fhd.png'
                off_name = 'off_row_fhd.png'
            else:
                on_name  = 'on_row_hd.png'
                off_name = 'off_row_hd.png'
            self.pix_on  = _try_load_pixmap(plugin_path('buttons', on_name))
            self.pix_off = _try_load_pixmap(plugin_path('buttons', off_name))
        except Exception:
            pass

    def set_settings(self, items):
        """items: list of (title_string, bool_value)"""
        rows = []
        for title, value in items:
            pix = self.pix_on if value else self.pix_off
            rows.append((gui_text(title), pix))
        self.setList(rows)

    def getSelectionIndex(self):
        try: return self.getIndex()
        except Exception: return 0

    def moveToIndex(self, index):
        try: self.setIndex(index)
        except Exception: pass
