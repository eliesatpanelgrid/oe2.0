# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
#
# __init__.py - Base constants, text/path converters, device detection
# Part of: Enigma2 Uninstaller Plugin
# Created by iet5
# Compatible with: Python 2.7, Python 3.12, Python 3.13, Python 3.14 (and later 3.x)
# Images: OpenATV, OpenPLi, VTi, Black Hole, DreamOS, OpenHDF, and all Enigma2 open source images
# Devices: Dreambox 920 (DM920), Vu+, and all standard Enigma2 boxes
#
# Notes:
# - This file avoids unicode_literals because some old Python 2.7 Enigma2 images
#   expect native UTF-8 byte strings for widget text, file paths, and plugin metadata.
# - Unicode is still supported through explicit conversion helpers below.
# - All strings that leave this module are either native_text (for widgets) or
#   unicode (u"...") for internal logic, ensuring correct behaviour on all images.
#

import os
import sys

# -----------------------------------------------------------------------------
# Python version detection - used throughout the plugin for compatibility
# -----------------------------------------------------------------------------
PY2    = sys.version_info[0] == 2           # True for Python 2.7.x
PY3    = sys.version_info[0] >= 3           # True for Python 3.x
PY_VER = sys.version_info[:3]              # Full tuple e.g. (3, 13, 0)

# -----------------------------------------------------------------------------
# Plugin identity constants - do NOT rename; they are imported by plugin.py
# -----------------------------------------------------------------------------
PLUGIN_FOLDER = "Enigma2Uninstaller"
PLUGIN_NAME   = "Enigma2Uninstaller"
PLUGIN_HEADER = "Enigma2 Uninstaller By iet5"
PLUGIN_ICON   = "plugin.png"

SKIN_FOLDER  = "skins"
VERSION_FILE = "Ver.txt"

# -----------------------------------------------------------------------------
# Unicode / text type helpers
# Python 2: str=bytes, unicode=text  |  Python 3: str=text, bytes=bytes
# -----------------------------------------------------------------------------
if PY2:
    text_type  = unicode   # noqa: F821 - unicode is a Python 2 built-in
    bytes_type = str
else:
    text_type  = str
    bytes_type = bytes


def to_text(value):
    """
    Convert any value to a unicode/str text object.
    Handles bytes, str, unicode (Python 2), and arbitrary objects.
    Safe for Python 2.7 through Python 3.14.
    """
    if value is None:
        return u""
    if isinstance(value, text_type):
        return value
    if isinstance(value, bytes_type):
        try:
            return value.decode("utf-8", "ignore")
        except Exception:
            try:
                return value.decode("latin-1", "ignore")
            except Exception:
                return u""
    try:
        return text_type(value)
    except Exception:
        return u""


def native_text(value):
    """
    Return text in the native string type expected by Enigma2.
    Python 2 Enigma2 widgets usually expect encoded UTF-8 bytes (str).
    Python 3 Enigma2 widgets expect str (unicode text).
    """
    value = to_text(value)
    if PY2:
        try:
            return value.encode("utf-8", "ignore")
        except Exception:
            try:
                return str(value)
            except Exception:
                return ""
    return value


def native_path(value):
    """
    Return a filesystem path in the safest native type for the running Python.
    This prevents path/unicode issues on older DreamOS Python 2.7 builds.
    """
    return native_text(value) if PY2 else to_text(value)


# -----------------------------------------------------------------------------
# File reading helpers
# -----------------------------------------------------------------------------
def read_text(path):
    """
    Read a file from disk and return its content as unicode text.
    Returns an empty string on any error, missing file, or permission issue.
    Binary-mode read plus explicit decode works on Python 2 and Python 3.
    """
    try:
        handle = open(native_path(path), "rb")
        try:
            return to_text(handle.read()).strip()
        finally:
            handle.close()
    except Exception:
        return u""


# -----------------------------------------------------------------------------
# Enigma2 image and receiver detection helpers
# -----------------------------------------------------------------------------
def file_contains(path, words):
    """Return True if any requested word exists inside a text file (case-insensitive)."""
    data = read_text(path).lower()
    for word in words:
        if word.lower() in data:
            return True
    return False


def box_model():
    """Return a best-effort receiver model string (lowercase)."""
    value = (read_text("/proc/stb/info/model")   or
             read_text("/proc/stb/info/boxtype")  or
             read_text("/proc/stb/info/vumodel")  or
             read_text("/etc/hostname")            or
             u"Unknown")
    return value.lower()


def box_brand():
    """Return a best-effort receiver brand string (lowercase)."""
    value = (read_text("/proc/stb/info/brand") or
             read_text("/proc/stb/info/oem")   or
             u"")
    return value.lower()


def image_blob():
    """Return combined image identification text from common Enigma2 files."""
    return u"\n".join([
        read_text("/etc/issue"),
        read_text("/etc/image-version"),
        read_text("/etc/image.info"),
        read_text("/etc/enigma2/settings"),
        read_text("/etc/opkg/all-feed.conf"),
        read_text("/etc/apt/sources.list"),
    ])


def is_dreambox():
    """Detect Dreambox / DreamOS receivers, including DM920."""
    model = box_model()
    brand = box_brand()
    blob  = image_blob().lower()
    return ("dream" in model or "dreambox" in model or model.startswith("dm") or
            "dream" in brand or "dreambox" in brand or
            "dream" in blob  or "dreambox" in blob)


def is_vuplus():
    """Detect Vu+ / VuPlus receivers."""
    model = box_model()
    brand = box_brand()
    blob  = image_blob().lower()
    return ("vuplus" in model or "vu+" in model or model.startswith("vu") or
            "vuplus" in brand or "vu+" in brand or
            "vuplus" in blob  or "vu+" in blob)


def is_vti():
    """Detect VTi images (Vu+ Team Image)."""
    return (file_contains("/etc/issue",         ["vti", "vu+ team"]) or
            file_contains("/etc/image-version",  ["vti"]))


def is_blackhole():
    """Detect Black Hole images."""
    blob = image_blob().lower()
    return "blackhole" in blob or "black hole" in blob



def is_dreamos():
    """Detect DreamOS / Dreambox OE2.5/OE2.6 style images (dpkg-based)."""
    blob = image_blob().lower()
    return is_dreambox() and ("dreamos" in blob or os.path.exists("/var/lib/dpkg/status"))


def is_openatv():
    """Detect OpenATV images (comprehensive check)."""
    blob = image_blob().lower()
    return "openatv" in blob or "atv" in blob or "metas" in blob


def is_opensource():
    """Detect non-DreamOS images (OpenATV, VTi, Black Hole, OpenPLi, etc.).
    Open source images almost always use 'opkg', while DreamOS uses 'apt/dpkg'.
    """
    # Explicitly identified Open Source distributions
    if is_openatv() or is_vti() or is_blackhole():
        return True
    # If it's a Dreambox but doesn't have DreamOS-specific markers or apt, it's open source (like OpenATV on DM)
    if is_dreambox():
        blob = image_blob().lower()
        if "dreamos" in blob or os.path.exists("/usr/bin/apt-get") or os.path.exists("/var/lib/dpkg/status"):
            return False
        return True
    # Everything else (Vu+, etc.) is open source
    return True


# Convenience constants computed once at import time
DREAMBOX_PY2 = PY2 and is_dreambox()
VU_PLUS_PY2  = PY2 and is_vuplus()


# -----------------------------------------------------------------------------
# Path helpers
# -----------------------------------------------------------------------------
def plugin_path(*parts):
    """
    Return an absolute path inside this plugin installation directory.
    Falls back to the standard Enigma2 Extensions path if __file__ is missing.
    Accepts zero or more path components to join after the base.
    """
    try:
        base = os.path.dirname(os.path.realpath(__file__))
    except Exception:
        base = "/usr/lib/enigma2/python/Plugins/Extensions/%s" % PLUGIN_FOLDER
    if parts:
        return native_path(os.path.join(base, *parts))
    return native_path(base)


def skin_path(name):
    """Return the full path to a skin XML file by file name."""
    return plugin_path(SKIN_FOLDER, name)


def version_file_path():
    """Return the full path to the version text file."""
    return plugin_path(VERSION_FILE)


# -----------------------------------------------------------------------------
# Version helper
# -----------------------------------------------------------------------------
def plugin_version(default="1.1"):
    """Read and return the plugin version string from Ver.txt."""
    value = read_text(version_file_path())
    if value:
        first_line = value.splitlines()[0].strip()
        return first_line if first_line else default
    return default
