# -*- coding: utf-8 -*-
# Protected Python source - generated for Enigma2 plugin packaging
import base64 as __b64, zlib as __zlib, hashlib as __hashlib
__k = b'\x8b8\xcc\xeec\x81\x9d\x8e:\xb7\xbf\x1d\x90\xa1h\x1c@\x7f\x08\x9cz\xea\xf2\x0f\xd5\xca,\xbc\x9d\x9b\xeb\xa9'
__d = 'CjLGJxz2PIF06HH0cc3cz795oZvodo0ewprz0S188Xd70Qzr3ilQrpfjxWIaByKtbyx2IqG3sUcG0zydG48gxIgtJgeVzAeD8gP38wzky6tkgHCgkcZA76sCilldb2bbVJlYPErNxBFgJynmEl2Hf54+cQ4A8eBP31SFgjcD1g58gjRsRPgpA6/J/+mT+rKZo3yDakQr6E5zdJ5FlCatGTFUG07m2W7m5Ru5+onc/DDBFMiptliCpB+DAh+SzyAJr5RPffZws9zjqEQq9sjkZEZlIqxZqjdU0oXEFgSkD72LmqxMsOGu97/6T3Om/IfV3usLgENnY6UspM5gLG0jyXbRROmBsKNeR1P7xOji+vmyZeEDcP7iASp2LflUTq8iy5CXyR3JVyUmMXW6S1Cf01zGQB9cP7O6yD5AfjmXbkPm01nTGxLDQsXITqsHVvWZTVFPnXD5jObGmpApoZJZzzC46J0hobZSGfkoIWtYtA7RuKjuOhS+Gi5ErrhyhSuMo/1KVOp0Pn2A2BtKLmVxw0F0gJk2DTwgXzin3iO5fhUSe/GB0WJ0Hsz8OHcYW9p41RnUEJxQ3O2D+Q1jwbiHvgW2D1bPknMPik03vH8K9SgSztpat86A58efRH3k7HBonCkuZDVDix69Mx8Yuu4WcjfjHBTXE36INMlBpuCk/LOjI4qbxYvmPQQ3o3S6mz7wS1yz+uvknytzmqjCCY0+S+JLKYln+/2yC0M6xOc2+qS7sbFLZZztIpYcbI9IGbo1O88LKktmfQ/IhdaqkWdTFb3dDTT28I/63FwOzqSQiW1yYHyPtK5IJt38fax/vO1b3ys5xfMZt56qNxLR1wlE/V37kgFoO+gjimaM7DZUjiEJuplG1ujVSJtCfyn5NWyl1/oMCODp2aX01KnQepPa1ZE07KL2NldUkBDs2IKRLnsLcM5bVBG/Nn4AEvwFYvTou51rLntFNOk2YQ=='
def __s(__k, __n):
    __r=[]; __c=0; __t=0
    while __t < __n:
        __h = __hashlib.sha256(__k + __c.to_bytes(8, 'big')).digest()
        __r.append(__h); __t += len(__h); __c += 1
    return b''.join(__r)[:__n]
__x = __b64.b64decode(__d)
__src = __zlib.decompress(bytes((__a ^ __b) for __a, __b in zip(__x, __s(__k, len(__x)))))
exec(compile(__src, __file__, 'exec'), globals(), globals())
del __b64, __zlib, __hashlib, __k, __d, __s, __x, __src
