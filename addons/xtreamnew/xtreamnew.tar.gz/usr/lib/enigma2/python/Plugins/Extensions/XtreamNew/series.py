# -*- coding: utf-8 -*-
# Protected Python source - generated for Enigma2 plugin packaging
import base64 as __b64, zlib as __zlib, hashlib as __hashlib
__k = b'\x8b8\xcc\xeec\x81\x9d\x8e:\xb7\xbf\x1d\x90\xa1h\x1c@\x7f\x08\x9cz\xea\xf2\x0f\xd5\xca,\xbc\x9d\x9b\xeb\xa9'
__d = 'CjLGJxzWO4Fo6GH07eE8felLYT2/7vVFd/RoBWwkekxDL5XrzvqRoacEQAJmJcwn9HhF0bHMRbM/rs2wbSkbNWPri5nnCIrRWhi6pFAeoxtVhbeXnKgyhhdNlt0kua8i+2I2sweFQXN8oK/M//FP2gAaOIFY+41IByoFxRUG8ndBjH5HhAR7RUpD7lZnDM2QpcgCM0krY3T9rtCPGSHdAd9E2qTQxRscgknr2ftHIrCBwFsK8RK83ePox5XrKqQq2M+MBcVTJRoad1GB0qpogBDtXC1gpBRH+J6+da2RG5+RBAWpoRgdNesNNh/hmL0lohqB3oQ8GH92BgaSrKM3j+RSIq39/wdk7yseJXBiR+0lFwlEhHfjcSHpSj/WtCM4F07vKoH+Be24jezGHgkQyf20YLzKCSz2IGFQvVDriphCCeyeHYzaZLDw6YpR6iaWHdq0iAx2D8IlXqJYzF9dQL8sBMUGFtfpEnu3i63EpWNCZxh5rCaheN+soD9SOLYTdyQBMWqztX0PEzG2D0uVG22gMSPYtmiYdJAkiyHM9rzXGGAfJ5aypQLtxq2lujebFvl7g+Esll9osyCPJ3iPGGBvus5WfnjpN5/s+NkABX3qSmu2UvrkT05CUWNOz+1DfY/zhtBcpIbsP3P6Qx4ZsyOkf6jrqip/zN16gKUl/9ja9r7F619hYtEIW22eXyf/j4B7fJCCV4OdRONRWbxDfh4t/GFWGIuCHYPeNJzVwabU944M/3XrdAYdpQvobkcvC3tfgY+rtej+Ib/cOe5EUVudjX0OUZGPhOzPK4ZZZv3dwDFebgv6zNnKaoXExGrhK2ccEZhsOS2wxQ6YatY1YSrHNQ2Io+8mFdI7RBHwMoV4UibR2QthWlVkhwxOpulilMSZi1eWvM38r7ib58MNxWdQLilW/8+f5jFlPm8pozf9hCcGxa7NqmySiHSJahsEmFAyCyE7vuEV4EY='
def __s(__k, __n):
    __r=[]; __c=0; __t=0
    while __t < __n:
        __h = __hashlib.sha256(__k + __c.to_bytes(8, 'big')).digest()
        __r.append(__h); __t += len(__h); __c += 1
    return b''.join(__r)[:__n]
__x = __b64.b64decode(__d)
__src = __zlib.decompress(bytes((__a ^ __b) for __a, __b in zip(__x, __s(__k, len(__x)))))
exec(compile(__src, __file__, 'exec'), globals(), globals())
del __b64, __zlib, __hashlib, __k, __d, __s, __x, __src
