# -*- coding: utf-8 -*-
# Protected Python source - generated for Enigma2 plugin packaging
import base64 as __b64, zlib as __zlib, hashlib as __hashlib
__k = b'\x8b8\xcc\xeec\x81\x9d\x8e:\xb7\xbf\x1d\x90\xa1h\x1c@\x7f\x08\x9cz\xea\xf2\x0f\xd5\xca,\xbc\x9d\x9b\xeb\xa9'
__d = 'CjKe5Ao2QoFwklVe6cIB1Ntc2CT/2DsO3JFoqP6SXfwlduxznMpZ2IRGoddfI634kS4Sk7Zt8wA1PID73XAeYOH15coEh33wxrgmynVhSI2iuDbyD6BALsZ8tgJnHg9Fms0CYPBV1DuuzwRlcPzwWklv6tqfi7Y0ZtPWYh54AM5ighkippu0At9hbSyZxeT8nKdsAEY2rhFGgyasxUXQowm1KwqTYIEkgDwief+5lo6sGxTHaYon+aB4xHqIa7gmOcq7aVw8HDnhEXC8X9fE81z5fU+21EZHD3F3m5eTls6FkSE0fPsxWdf+Repx7KwkEGuE/KNx1Nh6AnPDX4jl7Rvp5WM6oQBBt8blEvnMsWrb3BQwzZuvo9qOBN+H7GlgLQtIPjSJS6true3zC7GpTEdpS3DUgBPj9eT7rGrxjaRhTvbLuavlGdpEU3zeamE4vrhWqf/yRzo13SUC/TtSzWuu2UImh+YIwY3hSwfcyBqhOkmCpOL4Dz2kGimULeg9tEN3IauaupDfiDRYJaGjLJywXnhEBBwrzQ/ILVHktp6BMaPd0j2ezNEOmwjfhmVvEZEOQXihfi/cfMW3J0aK9LvTt1/1d3kqan4CU15YCWKqjPh8OmFVNAFebzitx5mVVs8C6ExAVRfcnM3BPHmrOaj0D5PsCH7olzBFvZHM7PgI4+H6xBkho3G8O+cwUsYqdUdnaKQn97JQBrqx8+7lSaAIUl9bQbBHAo/HnqJ2RvfGnU/uHE2tk/4dya3+rgioajeoDuZrMvekbg=='
def __s(__k, __n):
    __r=[]; __c=0; __t=0
    while __t < __n:
        __h = __hashlib.sha256(__k + __c.to_bytes(8, 'big')).digest()
        __r.append(__h); __t += len(__h); __c += 1
    return b''.join(__r)[:__n]
__x = __b64.b64decode(__d)
__src = __zlib.decompress(bytes((__a ^ __b) for __a, __b in zip(__x, __s(__k, len(__x)))))
exec(compile(__src, __file__, 'exec'), globals(), globals())
del __b64, __zlib, __hashlib, __k, __d, __s, __x, __src
