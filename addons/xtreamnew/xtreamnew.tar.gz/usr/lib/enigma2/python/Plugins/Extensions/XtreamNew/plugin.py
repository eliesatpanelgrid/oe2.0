# -*- coding: utf-8 -*-
# Protected Python source - generated for Enigma2 plugin packaging
import base64 as __b64, zlib as __zlib, hashlib as __hashlib
__k = b'\x8b8\xcc\xeec\x81\x9d\x8e:\xb7\xbf\x1d\x90\xa1h\x1c@\x7f\x08\x9cz\xea\xf2\x0f\xd5\xca,\xbc\x9d\x9b\xeb\xa9'
__d = 'CjLuJKrSA4l0qzczAk4dLAVTc+tQVazbpU/7qJK0ZEaAggRZav9gp5yVUuwplczJ2TwHsc0Y8PZLK2JmXXRbRwJsgKrm+RSaazW6VOsIYxlgjoJjYpEV431lQSwbWa3cgbY7bkn+Vp6Dk7hX2pPfFJorDG3zbDAR3JhUIs6ZWM1c/5zTn1FN4UFyMtqfsuTd/uCt/DF9nqaxJPE2FAdF2PgwgjuOKMOjDlu/vwQWjLafsbihTBd6yORJdqgUIsb98Q3qWEyDIv0YN5eqM/R0he22v0HiivkcIZVnGNEi7m3hyBsSuh3nJiHTwExugBAbfri3f/r0wvuYJBEirYrJgRD9wz/koyws8Wuj1pfL2lQSsX0HB3TzceuRigxmihXUZgEyUlkKN/upb/PMJM0WlrmmiEtbSoThV6vqbYrnn3anCJB0PkAR5w2WyEuPyANkn+EUM4A/ttq8GpZy/kypsG9dsyLOneLe72fW71eojs5L/KI1mZ806GGur8ZEzXkmI9hgffFHHJLRgbC8ErAicutc4M2ykpNdj6NNyyI9QTnMM0XXL3FjpXk/IIEuqjmyooMLKMRi45ehHJvUpypn36GUcUUw7MYb+4zDUGxrSvo/7Y2yhC0sL6l+KiK+MtptqOw7UKaHrTDvEVtUXBdiVVD47/PVqWxDBYixz/G7GDUsCGN5Ob+ZRoWrwk5YdRZGlzs0yYTakI6F2ZaAMl2LimM2XnIF16ZdXBAnwhX8c+9EgGjfOgbHukp2zhBqpM08jgtzOW6sAWC+qq5744zdfE7k3D4ogxictZK1NF25DFZudUwC6z+CxsHYO4Z1vX86oneIHmo+bURRgALq9vW9+nzymik6eiBUBp2IcfD6OS2wLSdxGgK4qNjst/FYZIfac0tjdYo3MLs+XGHvV7kHSbox1l7oy/bZ67XAqgKsFvon8uXG7PvrPgy7dglPzaJ2QAF80RNiOrtcHYZt/Kd0JZyWemsfq9eXO7E8YG1HVsVxcKsxuNsNTGPX+1cPezbs9VsiK0Pa5pnXK+fhIF/GTYv7XCTyCENhC0Y9+o0kQ9sbwzTXz+uW10MN9+XF/Gv5fnU5EPeJ/IM7MlOmw8IDcb/asEqe3+z+lkl8FOJ0TkO1K8vTRN3NJEvEwYZJYuJTbkWwiG2I8Qw+6MYwt/UzW4bMYgLYf6q53/SlsUdDZTzOjhJNA2S3PtypQ37KbMnYvEY4MLwfKvVtKFfALiT849xY8HObPgMGWHUHNITjtz5DB49GOPgMtWo5xqnfN/dsNK5yuX3GSHaG92Ur6/E0ohbK8pvYQD1S1DnG27NB6MEAtbvg8wbQZYJM4MHO/fRAJKJjBmp5hMcXUfdi4ZNnDIKBfv+fOO39+bUsO7Kzgch3xwRXb+E/avJ+0wkJMati1j4yu9OB8ba4Qs4VmLTc/EtxFaAW4tZlUbf3T1jN3MHaxPI3j4JLtEBLGLqR9Yk9EqrCVKn7ZZExWIeWbBoNiG2e6ZyvjJf/bFxuxEbYTML0axAN8y3AZBa0H2HwS1QYT6r6/luwajJKHN0IIc9CRWsOlTMa8IjbGmYGHtEg5/9mhPC6wV/JVZsIQ8ftbw2whcV8VZgYpQyzKyeBja88yt9KHrzNjslhiodOpsKM+P6ukbZVPmchaqA37jXF3drnm+Sa5Fq7dftsg9CSbT2kskX2h4dhgBAunqzzKm/YBrnXs31yfwQMIY5kJR1vhgAidy8LEzU+zOncr2IL6pb6QA=='
def __s(__k, __n):
    __r=[]; __c=0; __t=0
    while __t < __n:
        __h = __hashlib.sha256(__k + __c.to_bytes(8, 'big')).digest()
        __r.append(__h); __t += len(__h); __c += 1
    return b''.join(__r)[:__n]
__x = __b64.b64decode(__d)
__src = __zlib.decompress(bytes((__a ^ __b) for __a, __b in zip(__x, __s(__k, len(__x)))))
exec(compile(__src, __file__, 'exec'), globals(), globals())
del __b64, __zlib, __hashlib, __k, __d, __s, __x, __src
