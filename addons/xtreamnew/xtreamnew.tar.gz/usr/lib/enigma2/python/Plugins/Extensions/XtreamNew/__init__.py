# -*- coding: utf-8 -*-
# Protected Python source - generated for Enigma2 plugin packaging
import base64 as __b64, zlib as __zlib, hashlib as __hashlib
__k = b'\x8b8\xcc\xeec\x81\x9d\x8e:\xb7\xbf\x1d\x90\xa1h\x1c@\x7f\x08\x9cz\xea\xf2\x0f\xd5\xca,\xbc\x9d\x9b\xeb\xa9'
__d = 'CjIgJYFsMuQsm8VqMUROJp0Fk+MLlFTP15dYdyE='
def __s(__k, __n):
    __r=[]; __c=0; __t=0
    while __t < __n:
        __h = __hashlib.sha256(__k + __c.to_bytes(8, 'big')).digest()
        __r.append(__h); __t += len(__h); __c += 1
    return b''.join(__r)[:__n]
__x = __b64.b64decode(__d)
__src = __zlib.decompress(bytes((__a ^ __b) for __a, __b in zip(__x, __s(__k, len(__x)))))
exec(compile(__src, __file__, 'exec'), globals(), globals())
del __b64, __zlib, __hashlib, __k, __d, __s, __x, __src
