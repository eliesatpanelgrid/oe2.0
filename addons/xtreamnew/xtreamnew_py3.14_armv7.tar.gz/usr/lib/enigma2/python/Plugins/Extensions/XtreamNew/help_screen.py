# -*- coding: utf-8 -*-
from __future__ import absolute_import

from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap

try:
    from .store import getSetting
    from .ui_style import skin_with_theme_tokens
except Exception:
    from Plugins.Extensions.XtreamNew.store import getSetting
    from Plugins.Extensions.XtreamNew.ui_style import skin_with_theme_tokens


class XtreamPageKeysHelp(Screen):
    skin = r"""
    <screen name="XtreamPageKeysHelp" position="center,center" size="1500,900" backgroundColor="#0010151b" flags="wfNoBorder">
        <eLabel position="0,0" size="1500,900" backgroundColor="#0010151b" cornerRadius="28" />
        <eLabel position="0,0" size="1500,82" backgroundColor="__GRAD1__" backgroundGradient="__GRAD1__,__GRAD3__,horizontal" cornerRadius="28" />

        <widget name="title" position="45,12" size="1410,56" font="XtreamNewBold;38" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1" zPosition="5" />

        <widget name="englishTitle" position="70,99" size="620,40" font="XtreamNewBold;27" halign="left" valign="center" foregroundColor="__ACCENT3__" transparent="1" zPosition="5" />
        <widget name="arabicTitle" position="810,99" size="620,40" font="XtreamNewBold;27" halign="right" valign="center" foregroundColor="__ACCENT3__" transparent="1" zPosition="5" />

        <eLabel position="748,105" size="3,665" backgroundColor="__GRAD2__" zPosition="4" />

        <widget name="bodyEn" position="70,145" size="650,620" font="XtreamNewRegular;23" halign="left" valign="top" foregroundColor="#00ffffff" transparent="1" zPosition="5" />
        <widget name="bodyAr" position="780,145" size="650,620" font="XtreamNewRegular;23" halign="right" valign="top" foregroundColor="#00ffffff" transparent="1" zPosition="5" />

        <widget name="page" position="70,785" size="1360,36" font="XtreamNewBold;24" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1" zPosition="5" />
        <widget name="footer" position="70,835" size="1360,42" font="XtreamNewRegular;23" halign="center" valign="center" foregroundColor="__ACCENT3__" transparent="1" zPosition="5" />
    </screen>"""

    def __init__(self, session, mode="vod"):
        try:
            self.skin = skin_with_theme_tokens(self.skin, getSetting)
        except Exception:
            pass

        Screen.__init__(self, session)

        self._sections = ("vod", "series", "live")
        requested = str(mode or "vod").strip().lower()
        aliases = {
            "movie": "vod",
            "movies": "vod",
            "cinematic": "vod",
            "tv": "live",
            "livetv": "live",
            "live_tv": "live",
        }
        requested = aliases.get(requested, requested)
        try:
            self._section_index = self._sections.index(requested)
        except Exception:
            self._section_index = 0

        self["title"] = Label("")
        self["englishTitle"] = Label("English")
        self["arabicTitle"] = Label("العربية")
        self["bodyEn"] = Label("")
        self["bodyAr"] = Label("")
        self["page"] = Label("")
        self["footer"] = Label("LEFT / RIGHT: Change section   |   تبديل القسم     BACK / OK / 5: Close   |   إغلاق")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "NumberActions"],
            {
                "ok": self.close,
                "cancel": self.close,
                "5": self.close,
                "left": self.previousSection,
                "right": self.nextSection,
            },
            -1
        )

        self._showSection()

    def _movieHelp(self):
        english = [
            "OK        Open / play the selected movie",
            "ARROWS    Move between posters and the top bar",
            "CH+/CH-   Previous / next page",
            "1         Open the category sidebar",
            "2         Play the trailer",
            "3         Clear search and return to the first item",
            "5         Open this help screen",
            "BLUE      Search",
            "GREEN     Sort the list",
            "YELLOW    Add the selected movie to Favorites",
            "RED       Remove the selected movie from Favorites",
            "INFO      Open IMDb / enter the Cinematic top bar",
            "0         Download the selected movie",
            "MENU      Open the Downloads screen",
            "BACK      Return to the previous screen",
        ]
        arabic = [
            "فتح / تشغيل الفيلم المحدد        OK",
            "التنقل بين البوسترات والشريط العلوي    الأسهم",
            "الصفحة السابقة / التالية    CH+/CH-",
            "فتح القائمة الجانبية للأقسام        1",
            "تشغيل الإعلان الترويجي        2",
            "مسح البحث والعودة لأول عنصر        3",
            "فتح شاشة المساعدة        5",
            "البحث      الأزرق",
            "ترتيب القائمة      الأخضر",
            "إضافة الفيلم المحدد للمفضلة      الأصفر",
            "إزالة الفيلم المحدد من المفضلة      الأحمر",
            "فتح IMDb / دخول الشريط العلوي في Cinematic      INFO",
            "تحميل الفيلم المحدد        0",
            "فتح شاشة التحميلات      MENU",
            "العودة للشاشة السابقة      BACK",
        ]
        return "Movies - Remote Keys  |  الأفلام - أزرار الريموت", english, arabic

    def _seriesHelp(self):
        english = [
            "OK        Open the selected series / seasons / episodes",
            "ARROWS    Move between posters and the top bar",
            "CH+/CH-   Previous / next page",
            "1         Open the category sidebar",
            "2         Play the trailer",
            "3         Clear search and return to the first item",
            "5         Open this help screen",
            "BLUE      Search",
            "GREEN     Sort the list",
            "YELLOW    Add the selected series to Favorites",
            "RED       Remove the selected series from Favorites",
            "INFO      Open IMDb / enter the Cinematic top bar",
            "0         Download when available",
            "MENU      Open the Downloads screen",
            "BACK      Return to the previous screen",
        ]
        arabic = [
            "فتح المسلسل / المواسم / الحلقات المحددة        OK",
            "التنقل بين البوسترات والشريط العلوي    الأسهم",
            "الصفحة السابقة / التالية    CH+/CH-",
            "فتح القائمة الجانبية للأقسام        1",
            "تشغيل الإعلان الترويجي        2",
            "مسح البحث والعودة لأول عنصر        3",
            "فتح شاشة المساعدة        5",
            "البحث      الأزرق",
            "ترتيب القائمة      الأخضر",
            "إضافة المسلسل المحدد للمفضلة      الأصفر",
            "إزالة المسلسل المحدد من المفضلة      الأحمر",
            "فتح IMDb / دخول الشريط العلوي في Cinematic      INFO",
            "التحميل عند توفر رابط مباشر        0",
            "فتح شاشة التحميلات      MENU",
            "العودة للشاشة السابقة      BACK",
        ]
        return "Series - Remote Keys  |  المسلسلات - أزرار الريموت", english, arabic

    def _liveHelp(self):
        english = [
            "OK        Open a category / play the selected channel",
            "ARROWS    Navigate categories and channels",
            "CH+/CH-   Switch between Categories and Channels",
            "GREEN     Open category / play selected channel",
            "YELLOW    First category / previous category",
            "BLUE      Search categories / next category",
            "MENU      Open the Live options menu",
            "1         Open the main sidebar",
            "2         Hide the selected category or channel",
            "3         Show hidden categories and channels",
            "4         Export the current category to a bouquet",
            "5         Export the selected channel to IP Audio",
            "0         Return focus to the currently playing channel",
            "INFO/EPG  Open EPG and Catch-up",
            "RED/BACK  Channels > Categories / close Live",
        ]
        arabic = [
            "فتح القسم / تشغيل القناة المحددة        OK",
            "التنقل بين الأقسام والقنوات    الأسهم",
            "التبديل بين عرض الأقسام وعرض القنوات    CH+/CH-",
            "فتح القسم / تشغيل القناة المحددة      الأخضر",
            "أول قسم / القسم السابق      الأصفر",
            "بحث الأقسام / القسم التالي      الأزرق",
            "فتح قائمة خيارات البث المباشر      MENU",
            "فتح القائمة الجانبية الرئيسية        1",
            "إخفاء القسم أو القناة المحددة        2",
            "إظهار الأقسام والقنوات المخفية        3",
            "تصدير القسم الحالي إلى Bouquet        4",
            "تصدير القناة المحددة إلى IP Audio        5",
            "العودة إلى القناة التي تعمل حاليًا        0",
            "فتح دليل البرامج وCatch-up      INFO/EPG",
            "من القنوات إلى الأقسام / إغلاق المباشر      الأحمر/BACK",
        ]
        return "Live TV - Remote Keys  |  البث المباشر - أزرار الريموت", english, arabic

    def _showSection(self):
        section = self._sections[self._section_index]
        if section == "series":
            title, english, arabic = self._seriesHelp()
        elif section == "live":
            title, english, arabic = self._liveHelp()
        else:
            title, english, arabic = self._movieHelp()

        try:
            self["title"].setText(title)
            self["bodyEn"].setText("\n".join(english))
            self["bodyAr"].setText("\n".join(arabic))
            self["page"].setText("%d / %d" % (self._section_index + 1, len(self._sections)))
        except Exception:
            pass

    def previousSection(self):
        try:
            self._section_index = (self._section_index - 1) % len(self._sections)
            self._showSection()
        except Exception:
            pass

    def nextSection(self):
        try:
            self._section_index = (self._section_index + 1) % len(self._sections)
            self._showSection()
        except Exception:
            pass
