# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

try:
    from .store import getSetting
except Exception:
    try:
        from Plugins.Extensions.XtreamNew.store import getSetting
    except Exception:
        def getSetting(key, default=None):
            return default


def get_plugin_keyboard_preference(override=None):
    """Return XtreamNew's plugin-wide keyboard preference.

    plugin_keyboard is the new global setting.  subtitle_keyboard is retained
    only as a migration fallback for installations upgraded from older builds.
    """
    try:
        if override is not None:
            value = str(override or "default").strip().lower()
        else:
            value = str(getSetting("plugin_keyboard", getSetting("subtitle_keyboard", "default")) or "default").strip().lower()
    except Exception:
        value = "default"
    return value if value in ("default", "new") else "default"


def resolve_plugin_keyboard(preference=None):
    pref = get_plugin_keyboard_preference(preference)
    if pref == "new":
        for mod_name, cls_name in (
            ("Screens.NewVirtualKeyBoard", "NewVirtualKeyBoard"),
            ("Plugins.Extensions.XtreamNew.NewVirtualKeyBoard", "NewVirtualKeyBoard"),
            ("Plugins.Extensions.XtreamNew.newvirtualkeyboard", "NewVirtualKeyBoard"),
        ):
            try:
                mod = __import__(mod_name, fromlist=[cls_name])
                keyboard = getattr(mod, cls_name)
                if keyboard is not None:
                    return keyboard
            except Exception:
                pass
    try:
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        return VirtualKeyBoard
    except Exception:
        return None


def open_plugin_keyboard(session, callback, title="Enter text", text="", preference=None):
    """Open the selected keyboard and safely fall back to the image default."""
    keyboard = resolve_plugin_keyboard(preference)
    if keyboard is None:
        return False
    try:
        session.openWithCallback(callback, keyboard, title=title, text=text)
        return True
    except Exception:
        # If a third-party/new keyboard exists but cannot be instantiated on
        # this image, make one final attempt with Enigma2's default keyboard.
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            if keyboard is not VirtualKeyBoard:
                session.openWithCallback(callback, VirtualKeyBoard, title=title, text=text)
                return True
        except Exception:
            pass
    return False
