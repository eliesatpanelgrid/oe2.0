ضع خطوط البلجن المرخصة داخل هذا المجلد بصيغة TTF أو OTF.

الاختيار التلقائي:
- أي ملف عادي يستخدم كخط Regular.
- أي ملف يحتوي اسمه على Bold أو Black أو Heavy أو SemiBold يستخدم كخط Bold.

أمثلة أسماء:
XtreamNew-Regular.ttf
XtreamNew-Bold.ttf

يتم تسجيل الخطوط عند بدء Enigma2 قبل فتح أي شاشة من XtreamNew.
