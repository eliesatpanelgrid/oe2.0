# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

"""
XtreamNew Series clean entry point.

Home Grid setting opens categories first.
The selected category opens the independent horizontal series screen.
No old Series logic is kept here.
"""

from Screens.Screen import Screen

try:
    from .store import getSetting
except Exception:
    def getSetting(key, default=None):
        return default


SERIES_LAYOUT_REGISTRY = {
    # Keep the single visible setup option name, but route it to categories first.
    "home_grid": "Plugins.Extensions.XtreamNew.series_layouts.categories.CleanSeriesCategoriesScreen",
}


def _safe_layout_key(value):
    value = str(value or "home_grid").strip().lower()
    if value not in SERIES_LAYOUT_REGISTRY:
        value = "home_grid"
    return value


def _load_class(path):
    module_name, class_name = path.rsplit(".", 1)
    try:
        module = __import__(module_name, globals(), locals(), [class_name], 0)
    except ImportError:
        if module_name.startswith("Plugins.Extensions.XtreamNew."):
            module_name = module_name.replace("Plugins.Extensions.XtreamNew.", "", 1)
            module = __import__(module_name, globals(), locals(), [class_name], 0)
        else:
            raise
    return getattr(module, class_name)


class XtreamSeriesScreen(Screen):
    """Router only: Series always starts from the standalone categories screen."""

    def __new__(cls, session, *args, **kwargs):
        layout_key = _safe_layout_key(getSetting("series_layout_style", "home_grid"))
        screen_class = _load_class(SERIES_LAYOUT_REGISTRY[layout_key])
        return screen_class(session, *args, **kwargs)
