# -*- coding: utf-8 -*-
from __future__ import absolute_import

from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap

try:
    from .store import getSetting
    from .ui_style import skin_with_theme_tokens
except Exception:
    from Plugins.Extensions.XtreamNew.store import getSetting
    from Plugins.Extensions.XtreamNew.ui_style import skin_with_theme_tokens


class XtreamPageKeysHelp(Screen):
    skin = r"""
    <screen name="XtreamPageKeysHelp" position="center,center" size="1320,820" backgroundColor="#0010151b" flags="wfNoBorder">
        <eLabel position="0,0" size="1320,820" backgroundColor="#0010151b" cornerRadius="28" />
        <eLabel position="0,0" size="1320,78" backgroundColor="__GRAD1__" backgroundGradient="__GRAD1__,__GRAD3__,horizontal" cornerRadius="28" />
        <widget name="title" position="40,12" size="1240,54" font="XtreamNewBold;40" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1" zPosition="5" />
        <widget name="body" position="70,105" size="1180,620" font="XtreamNewRegular;25" foregroundColor="#00ffffff" transparent="1" zPosition="5" />
        <widget name="footer" position="70,750" size="1180,42" font="Regular;25" halign="center" valign="center" foregroundColor="__ACCENT3__" transparent="1" zPosition="5" />
    </screen>"""

    def __init__(self, session, mode="vod"):
        try:
            self.skin = skin_with_theme_tokens(self.skin, getSetting)
        except Exception:
            pass
        Screen.__init__(self, session)
        self.mode = str(mode or "vod")
        self["title"] = Label("Movies & Series - Remote Keys")
        lines = [
            "OK        Open the selected item",
            "ARROWS    Move between posters",
            "CH+/CH-   Previous / next page",
            "BLUE      Search",
            "GREEN     Sort",
            "YELLOW    Add to Favorites",
            "RED       Remove from Favorites",
            "INFO      Open IMDb information",
            "INFO      cinematic / top bar",
            "4         in the category / export",
            "2         Play trailer",
            "3         Clear search and return to first item",
            "5         Open this help page",
            "0         cinematic series / IMDB",
            "0         Download series cinematic & carousel & grid - from episodes / ",
            "MENU      Open Downloads",
            "BACK      Return to previous page",
        ]
        self["body"] = Label("\n".join(lines))
        self["footer"] = Label("Press BACK, OK or 5 to close")
        self["actions"] = ActionMap(["OkCancelActions", "NumberActions"], {
            "ok": self.close,
            "cancel": self.close,
            "5": self.close,
        }, -1)
