# -*- coding: utf-8 -*-

#This plugin is free software, you are allowed to
#modify it (if you keep the license),
#but you are not allowed to distribute/publish
#it without source code (this version and your modifications).
#This means you also have to distribute
#source code of your modifications.

# Edit By Hamdy Ahmed 20-05-2026 (Support All python)

# python3.13-3.14
from __future__ import print_function

from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.PluginComponent import plugins
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigLocations, ConfigText, ConfigSelection, getConfigListEntry, ConfigInteger, NoSave
from Components.ConfigList import ConfigListScreen
from Components.FileList import FileList
from Components.Sources.StaticText import StaticText
from Components.Sources.List import List
from Screens.Screen import Screen
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.LocationBox import LocationBox
from Plugins.Plugin import PluginDescriptor
from Screens.Standby import TryQuitMainloop
from .QuickButtonList import QuickButtonList, QuickButtonListEntry
from .QuickButtonXML import QuickButtonXML
from enigma import getDesktop
from Tools.Directories import *
import xml.sax.xmlreader
import keymapparser
import os

functionfile = "/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/mqbfunctions.xml"
macrofile = "/etc/MultiQuickButton/mqb_macro.cfg"
mqbkeymapfile = "/etc/MultiQuickButton/keymap.xml"
config.plugins.QuickButton = ConfigSubsection()
config.plugins.QuickButton.enable = ConfigYesNo(default = True)
config.plugins.QuickButton.enable_movieplayer = ConfigYesNo(default = False)
config.plugins.QuickButton.info = ConfigYesNo(default = True)
config.plugins.QuickButton.mainmenu = ConfigYesNo(default = True)
config.plugins.QuickButton.last_backupdir = ConfigText(default=resolveFilename(SCOPE_SYSETC))
config.plugins.QuickButton.backupdirs = ConfigLocations(default=[resolveFilename(SCOPE_SYSETC)])
MultiQuickButton_version = "2.8.0"
autostart=_("Autostart") + ": "
menuentry=_("Main menu") + ": "
info=_("Info") + ": "
movieplayer=_("MoviePlayer") + ": "

def getKeyDic():
	keys = {  
		"KEY_01_red": 			("<key id=\"KEY_RED\" mapto=\"red\" flags=\"b\" />", _('red'), "red"),
		"KEY_02_red_long": 		("<key id=\"KEY_RED\" mapto=\"red_long\" flags=\"l\" />", _('red') + _(' long'), "red_long"),
		"KEY_03_green": 		("<key id=\"KEY_GREEN\" mapto=\"green\" flags=\"b\" />", _('green'), "green"),
		"KEY_04_green_long": 		("<key id=\"KEY_GREEN\" mapto=\"green_long\" flags=\"l\" />", _('green') + _(' long'), "green_long"),
		"KEY_05_yellow":		("<key id=\"KEY_YELLOW\" mapto=\"yellow\" flags=\"b\" />", _('yellow'), "yellow"),
		"KEY_06_yellow_long":		("<key id=\"KEY_YELLOW\" mapto=\"yellow_long\" flags=\"l\" />", _('yellow') + _(' long'), "yellow_long"),
		"KEY_07_blue":			("<key id=\"KEY_BLUE\" mapto=\"blue\" flags=\"b\" />", _('blue'), "blue"),
		"KEY_08_blue_long":		("<key id=\"KEY_BLUE\" mapto=\"blue_long\" flags=\"l\" />", _('blue') + _(' long'), "blue_long"),
		"KEY_09_text":			("<key id=\"KEY_TEXT\" mapto=\"text\" flags=\"b\" />", _('TEXT'), "text"),
		"KEY_10_text_long":		("<key id=\"KEY_TEXT\" mapto=\"text_long\" flags=\"l\" />", _('TEXT') + _(' long'), "text_long"),
		"KEY_11_help_long":		("<key id=\"KEY_HELP\" mapto=\"help_long\" flags=\"l\" />", _('HELP') + _(' long'), "help_long"),
		"KEY_12_info":			("<key id=\"KEY_INFO\" mapto=\"info\" flags=\"b\" />", _('VU+ EPG / INFO'), "info"),
		"KEY_13_info_long":		("<key id=\"KEY_INFO\" mapto=\"info_long\" flags=\"l\" />", _('VU+ EPG / INFO') + _(' long'), "info_long"),
		"KEY_14_subtitle":		("<key id=\"KEY_SUBTITLE\" mapto=\"subtitle\" flags=\"m\" />", _('Subtitle'), "subtitle"),
		"KEY_17_video":			("<key id=\"KEY_VIDEO\" mapto=\"pvr\" flags=\"b\" />", _('VU+ R-Button'), "pvr"),
		"KEY_18_video_long":		("<key id=\"KEY_VIDEO\" mapto=\"pvr_long\" flags=\"l\" />", _('VU+ R-Button') + _(' long'), "pvr_long"),
		"KEY_19_radio":			("<key id=\"KEY_RADIO\" mapto=\"radio\" flags=\"b\" />", _('RADIO'), "radio"),
		"KEY_20_radio_long":		("<key id=\"KEY_RADIO\" mapto=\"radio_long\" flags=\"l\" />", _('RADIO') + _(' long'), "radio_long"),
		"KEY_21_tv":			("<key id=\"KEY_TV\" mapto=\"tv\" flags=\"m\" />", _('TV'), "tv"),
		"KEY_22_cross_up":		("<key id=\"KEY_UP\" mapto=\"cross_up\" flags=\"mr\" />", _('Cross Up'), "cross_up"),
		"KEY_23_cross_down":		("<key id=\"KEY_DOWN\" mapto=\"cross_down\" flags=\"mr\" />", _('Cross Down'), "cross_down"),
		"KEY_24_cross_left":		("<key id=\"KEY_LEFT\" mapto=\"cross_left\" flags=\"mr\" />", _('Cross Left'), "cross_left"),
		"KEY_25_cross_right":		("<key id=\"KEY_RIGHT\" mapto=\"cross_right\" flags=\"mr\" />", _('Cross Right'), "cross_right"),
		"KEY_26_channelup":		("<key id=\"KEY_CHANNELUP\" mapto=\"channelup\" flags=\"mr\" />", _('Channel +'), "channelup"),
		"KEY_27_channeldown":		("<key id=\"KEY_CHANNELDOWN\" mapto=\"channeldown\" flags=\"mr\" />", _('Channel -'), "channeldown"),
		"KEY_28_previous":		("<key id=\"KEY_PREVIOUS\" mapto=\"previous\" flags=\"mr\" />", _('Backward <'), "previous"),
		"KEY_29_next":			("<key id=\"KEY_NEXT\" mapto=\"next\" flags=\"mr\" />", _('Forward >'), "next"),
		"KEY_30_mqb_volup":		("<key id=\"KEY_VOLUMEUP\" mapto=\"mqb_volup\" flags=\"mr\" />", _('Volume +'), "mqb_volup"),
		"KEY_31_mqb_voldown":		("<key id=\"KEY_VOLUMEDOWN\" mapto=\"mqb_voldown\" flags=\"mr\" />", _('Volume -'), "mqb_voldown"),
		"KEY_32_mqb_mute":		("<key id=\"KEY_MUTE\" mapto=\"mqb_mute\" flags=\"mr\" />", _('Mute'), "mqb_mute"),
		"KEY_33_mqb_power":		("<key id=\"KEY_POWER\" mapto=\"mqb_power\" flags=\"b\" />", _('Power'), "mqb_power"),
		"KEY_34_mqb_power_long":	("<key id=\"KEY_POWER\" mapto=\"mqb_power_long\" flags=\"l\" />", _('Power') + _(' long'), "mqb_power_long"),
		"KEY_35_audio":			("<key id=\"KEY_AUDIO\" mapto=\"audio\" flags=\"m\" />", _('Audio'), "audio"),
		"KEY_36_play":			("<key id=\"KEY_PLAY\" mapto=\"play\" flags=\"m\" />", _('Play'), "play"),
		"KEY_37_pause":			("<key id=\"KEY_PAUSE\" mapto=\"pause\" flags=\"m\" />", _('Pause'), "pause"),
		"KEY_38_stop":			("<key id=\"KEY_STOP\" mapto=\"stop\" flags=\"b\" />", _('Stop'), "stop"),
		"KEY_39_rewind":		("<key id=\"KEY_REWIND\" mapto=\"rewind\" flags=\"b\" />", _('Rewind <<'), "rewind"),
		"KEY_40_previoussong":		("<key id=\"KEY_PREVIOUSSONG\" mapto=\"rewind\" flags=\"b\" />", _('Rewind <<'), "rewind"),
		"KEY_41_fastforward":		("<key id=\"KEY_FASTFORWARD\" mapto=\"fastforward\" flags=\"b\" />", _('FastForward >>'), "fastforward"),
		"KEY_42_nextsong":		("<key id=\"KEY_NEXTSONG\" mapto=\"fastforward\" flags=\"b\" />", _('FastForward >>'), "fastforward"),
		"KEY_43_ok":			("<key id=\"KEY_OK\" mapto=\"ok\" flags=\"m\" />", _('OK'), "ok"),
		"KEY_44_exit":			("<key id=\"KEY_EXIT\" mapto=\"exit\" flags=\"m\" />", _('EXIT'), "exit"),
		"KEY_45_end":			("<key id=\"KEY_END\" mapto=\"end\" flags=\"b\" />", _('END'), "end"),
		"KEY_46_end_long":		("<key id=\"KEY_END\" mapto=\"end_long\" flags=\"l\" />", _('END') + _(' long'), "end_long"),
		"KEY_47_home":			("<key id=\"KEY_HOME\" mapto=\"home\" flags=\"b\" />", _('HOME'), "home"),
		"KEY_48_home_long":		("<key id=\"KEY_HOME\" mapto=\"home_long\" flags=\"l\" />", _('HOME') + _(' long'), "home_long"),
	}
	return keys

class MultiQuickButton(Screen):

	global HD_Res

	try:
		sz_w = getDesktop(0).size().width()
	except:
		sz_w = 720

	if sz_w == 1280:
		HD_Res = True
	else:
		HD_Res = False

	if HD_Res:
		skin = """
		<screen position="415,260" size="1100,600" title="MultiQuickButton Panel %s" backgroundColor="background4">
			<widget name="list" position="10,10" size="1065,452" scrollbarMode="showOnDemand" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_red.png" zPosition="2" position="63,493" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_green.png" zPosition="2" position="358,493" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_yellow.png" zPosition="2" position="647,493" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_blue.png" zPosition="2" position="833,493" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/key_0.png" zPosition="2" position="61,540" size="35,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/key_1.png" zPosition="2" position="354,540" size="35,25" alphatest="on" />
			<widget name="key_red" backgroundColor="#1f771f" zPosition="2" position="95,487" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_green" backgroundColor="#1f771f" position="389,487" zPosition="2" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_yellow" backgroundColor="#1f771f" position="675,487" zPosition="2" size="150,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_blue" backgroundColor="#1f771f" position="861,487" zPosition="2" size="150,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_0" backgroundColor="#1f771f" position="95,535" zPosition="2" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_1" backgroundColor="#1f771f" position="389,535" zPosition="2" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_2" backgroundColor="#1f771f" position="674,535" zPosition="2" size="150,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_3" backgroundColor="#1f771f" position="861,535" zPosition="2" size="150,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="background" backgroundColor="#220a0a0a" zPosition="1" position="10,476" size="1073,112" font="Regular;20" halign="left" valign="center" />
		</screen>""" % (MultiQuickButton_version)
	else:
		skin = """
		<screen position="415,260" size="1100,600" title="MultiQuickButton Panel %s" backgroundColor="background4">
			<widget name="list" position="10,10" size="1065,452" scrollbarMode="showOnDemand" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_red.png" zPosition="2" position="63,493" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_green.png" zPosition="2" position="358,493" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_yellow.png" zPosition="2" position="647,493" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_blue.png" zPosition="2" position="833,493" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/key_0.png" zPosition="2" position="61,540" size="35,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/key_1.png" zPosition="2" position="354,540" size="35,25" alphatest="on" />
			<widget name="key_red" backgroundColor="#1f771f" zPosition="2" position="95,487" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_green" backgroundColor="#1f771f" position="389,487" zPosition="2" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_yellow" backgroundColor="#1f771f" position="675,487" zPosition="2" size="150,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_blue" backgroundColor="#1f771f" position="861,487" zPosition="2" size="150,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_0" backgroundColor="#1f771f" position="95,535" zPosition="2" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_1" backgroundColor="#1f771f" position="389,535" zPosition="2" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_2" backgroundColor="#1f771f" position="674,535" zPosition="2" size="150,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_3" backgroundColor="#1f771f" position="861,535" zPosition="2" size="150,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="background" backgroundColor="#220a0a0a" zPosition="1" position="10,476" size="1073,112" font="Regular;20" halign="left" valign="center" />
		</screen>""" % (MultiQuickButton_version)

	def __init__(self, session, args=None):
		Screen.__init__(self, session)
		self.session = session
		self.menu = args
		self.settigspath = ""
		
		self["background"] = Label('')
		self["key_red"] = Label(autostart)
		self["key_green"] = Label(_("Select Buttons"))
		self["key_yellow"] = Label(_("Restore"))
		self["key_blue"] = Label(_("Backup"))
		self["key_0"] = Label(info)
		self["key_1"] = Label(menuentry)
		self["key_2"] = Label(movieplayer)
		self["key_3"] = Label("")
		self.createList()
		self["list"] = QuickButtonList(list=self.list, selection = 0)
		self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "NumberActions", "EPGSelectActions"],
		{
			"ok": self.run,
			"cancel": self.closeMQB,
			"red": self.autostart,
			"green": self.selectButtons,
			"yellow": self.restore,
			"blue": self.backup,
			"0": self.setInfo,
			"1": self.setMainMenu,
			"2": self.setMoviePlayer,
			"info": self.showAbout,
		}, -1)
		self.onShown.append(self.updateSettings)

	def createList(self):
		self.list = []
		functions = self.getAvailableButtons()
		for x in functions:
			if config.plugins.QuickButton.info.value:
				try:
					functionbutton = " ["
					path = "/etc/MultiQuickButton/quickbutton_" + x[1] + ".xml"
					menu = xml.dom.minidom.parse(path)
					self.XML_db = QuickButtonXML(menu)
					for a in self.XML_db.getMenu():
						if a[1] == "1":
							if functionbutton == " [":
								functionbutton = _(str(a[0]))
							else:
								functionbutton = functionbutton + " | " + _(str(a[0]))
					if functionbutton == " [":
						space1 = " "
						space2 = " "
						functionbutton = " "
					else:
						space1 = " ["
						space2 = "]"
					globals()['functionbutton_%s' % x[1]] = space1 + functionbutton + space2
					self.list.append(QuickButtonListEntry('',(x[2] + globals()['functionbutton_%s' % x[1]], x[1])))
				except Exception as a:
					pass
			else:
				globals()['functionbutton_%s' % x[1]] = " "
				self.list.append(QuickButtonListEntry('',(x[2] + globals()['functionbutton_%s' % x[1]], x[1])))

	def getAvailableButtons(self):
		b_list = []
		plugin_mqb_keymap_file = "/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/keymap_orig.xml"
		if not os.path.exists(mqbkeymapfile):
			os.system ("cp %s %s" % (plugin_mqb_keymap_file, mqbkeymapfile))
		if not os.path.exists(mqbkeymapfile):
			return b_list
		mqbkeymap = open(mqbkeymapfile, "r")
		text = mqbkeymap.read()
		mqbkeymap.close()
		keys = getKeyDic()
		for key in keys:
			keyinactive = "<!-- " + keys[key][0] + " -->"
			if keyinactive in text:
				pass
			else:
				b_list.append((key, keys[key][2], keys[key][1]))
		b_list = sorted(b_list, key = lambda item: item[0])
		return b_list

	def updateList(self):
		self.createList()
		self["list"].l.setList(self.list)

	def updateSettings(self):
		autostart_state = autostart
		menuentry_state = menuentry
		info_state = info
		movieplayer_state = movieplayer
		if config.plugins.QuickButton.enable.value:
			autostart_state += _("on")
		else:
			autostart_state += _("off")

		if config.plugins.QuickButton.mainmenu.value:
			menuentry_state += _("on")
		else:
			menuentry_state += _("off")

		if config.plugins.QuickButton.info.value:
			info_state += _("on")
		else:
			info_state += _("off")

		if config.plugins.QuickButton.enable_movieplayer.value:
			movieplayer_state += _("on")
		else:
			movieplayer_state += _("off")

		self["key_red"].setText(autostart_state)
		self["key_0"].setText(info_state)
		self["key_1"].setText(menuentry_state)
		self["key_2"].setText(movieplayer_state)

	def run(self):
		cur = self["list"].l.getCurrentSelection()
		if cur != None:
			returnValue = cur[0][1]
			title = cur[0][0]
			if returnValue != None:
				key_dic = getKeyDic()
				values = []
				for key in key_dic:
					values.append(key_dic[key][2])
				if returnValue in values:
					path = '/etc/MultiQuickButton/quickbutton_' + returnValue + '.xml'
					if os.path.exists(path) == True:
						self.session.openWithCallback(self.updateAfterButtonChange, QuickButton, path, (_("Quickbutton Key : %s") % title))
					else:
						self.session.open(MessageBox,("file %s not found!" % (path)),  MessageBox.TYPE_ERROR)

	def updateAfterButtonChange(self, res = None):
		self.updateList()

	def backup(self):
		self.session.openWithCallback(
			self.callBackup,
			BackupLocationBox,
			_("Please select the backup path..."),
			"",
			config.plugins.QuickButton.last_backupdir.value
		)

	def callBackup(self, path):
		if path != None:
			if pathExists(path):
				config.plugins.QuickButton.last_backupdir.value = path
				config.plugins.QuickButton.last_backupdir.save()
				self.settigspath = path + "MultiQuickButton_settings.tar.gz"
				if fileExists(self.settigspath):
					self.session.openWithCallback(self.callOverwriteBackup, MessageBox,_("Overwrite existing Backup?."),type = MessageBox.TYPE_YESNO,)
				else:
					com = "tar czvf %s /etc/MultiQuickButton/" % (self.settigspath)
					self.session.open(Console,_("Backup Settings..."),[com])
			else:
				self.session.open(
					MessageBox,
					_("Directory %s nonexistent.") % (path),
					type = MessageBox.TYPE_ERROR,
					timeout = 5
					)

	def callOverwriteBackup(self, res):
		if res:
			com = "tar czvf %s /etc/MultiQuickButton/" % (self.settigspath)
			self.session.open(Console,_("Backup Settings..."),[com])

	def restore(self):
		self.session.openWithCallback(
			self.callRestore,
			BackupLocationBox,
			_("Please select the restore path..."),
			"",
			config.plugins.QuickButton.last_backupdir.value
		)

	def callRestore(self, path):
		if path != None:
			self.settigspath = path + "MultiQuickButton_settings.tar.gz"
			if fileExists(self.settigspath):
				self.session.openWithCallback(self.callOverwriteSettings, MessageBox,_("Overwrite existing Settings?."),type = MessageBox.TYPE_YESNO,)
			else:
				self.session.open(MessageBox,_("File %s nonexistent.") % (path),type = MessageBox.TYPE_ERROR,timeout = 5)
		else:
			pass

	def callOverwriteSettings(self, res):
		if res:
			com = "cd /; tar xzvf %s" % (self.settigspath)
			self.session.open(Console,_("Restore Settings..."),[com])

	def autostart(self):
		if config.plugins.QuickButton.enable.value:
			config.plugins.QuickButton.enable.setValue(False)
			config.plugins.QuickButton.mainmenu.setValue(False)
		else:
			config.plugins.QuickButton.enable.setValue(True)

		self.updateSettings()
		config.plugins.QuickButton.enable.save()
		self.session.openWithCallback(self.callRestart,MessageBox,_("Restarting Enigma2 to set\nMulti QuickButton Autostart"), MessageBox.TYPE_YESNO, timeout=10)

	def setMainMenu(self):
		if config.plugins.QuickButton.mainmenu.value:
			config.plugins.QuickButton.mainmenu.setValue(False)
		else:
			config.plugins.QuickButton.mainmenu.setValue(True)

		config.plugins.QuickButton.mainmenu.save()
		self.updateSettings()
		self.session.openWithCallback(self.callRestart,MessageBox,_("Restarting Enigma2 to load:\n") + _("Main menu") + _("Multi QuickButton settings"), MessageBox.TYPE_YESNO, timeout=10)

	def setMoviePlayer(self):
		if config.plugins.QuickButton.enable_movieplayer.value:
			config.plugins.QuickButton.enable_movieplayer.setValue(False)
		else:
			config.plugins.QuickButton.enable_movieplayer.setValue(True)

		config.plugins.QuickButton.enable_movieplayer.save()
		self.updateSettings()
		self.session.openWithCallback(self.callRestart,MessageBox,_("Restarting Enigma2 to load:\n") + _("MoviePlayer") + _("Multi QuickButton settings"), MessageBox.TYPE_YESNO, timeout=10)

	def setInfo(self):
		if config.plugins.QuickButton.info.value:
			config.plugins.QuickButton.info.setValue(False)
		else:
			config.plugins.QuickButton.info.setValue(True)

		config.plugins.QuickButton.info.save()
		self.updateList()
		self.updateSettings()

	def selectButtons(self):
		self.session.openWithCallback(self.changedButtonsSelection, QuickButtonSelection)
		
	def changedButtonsSelection(self, ret = None):
		if ret:
			self.updateList()

	def showAbout(self):
		self.session.open(MessageBox,("Multi Quickbutton idea is based on\nGP2\'s Quickbutton\nVersion: 2.7\n ***special thanks*** to:\ngutemine & AliAbdul & Dr.Best ;-)\n\nModified and upgraded to a new version by \nHamdy Ahmed 2026\nWith full rights reserved\nVersion %s" % (MultiQuickButton_version)),  MessageBox.TYPE_INFO)
  
	def callRestart(self, restart):
		if restart == True:
			self.session.open(TryQuitMainloop, 3)
		else:
			pass

	def closeMQB(self):
		from Plugins.Extensions.MultiQuickButton.plugin import gMQBActionStrings
		gMQBActionStrings.updateInfoBarColorKeys()
		self.close()

class BackupLocationBox(LocationBox):
	def __init__(self, session, text, filename, dir, minFree = None):
		inhibitDirs = ["/bin", "/boot", "/dev", "/lib", "/proc", "/sbin", "/sys", "/usr", "/var"]
		LocationBox.__init__(self, session, text = text, filename = filename, currDir = dir, bookmarks = config.plugins.QuickButton.backupdirs, autoAdd = True, editDir = True, inhibitDirs = inhibitDirs, minFree = minFree)
		self.skinName = "LocationBox"

class QuickButton(Screen):

	global HD_Res

	try:
		sz_w = getDesktop(0).size().width()
	except:
		sz_w = 720

	if sz_w == 1280:
		HD_Res = True
	else:
		HD_Res = False

	if HD_Res:
		skin = """
		<screen position="415,260" size="1100,600" title="QuickButton" backgroundColor="background4">
			<widget name="list" position="10,10" size="1066,512" scrollbarMode="showOnDemand" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_red.png" zPosition="2" position="29,550" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_green.png" zPosition="2" position="294,550" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_yellow.png" zPosition="2" position="574,550" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_blue.png" zPosition="2" position="840,550" size="25,25" alphatest="on" />
			<widget name="key_red" backgroundColor="#1f771f" zPosition="2" position="60,544" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_green" backgroundColor="#1f771f" position="322,544" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_yellow" backgroundColor="#1f771f" position="607,544" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_blue" backgroundColor="#1f771f" position="869,544" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="background" backgroundColor="#220a0a0a" zPosition="1" position="20,545" size="1055,40" font="Regular;20" halign="left" valign="center" />
		</screen>"""
	else:
		skin = """
		<screen position="415,260" size="1100,600" title="QuickButton">
			<widget name="list" position="10,10" size="1066,512" scrollbarMode="showOnDemand" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_red.png" zPosition="2" position="29,550" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_green.png" zPosition="2" position="294,550" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_yellow.png" zPosition="2" position="574,550" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_blue.png" zPosition="2" position="840,550" size="25,25" alphatest="on" />
			<widget name="key_red" backgroundColor="#1f771f" zPosition="2" position="60,544" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_green" backgroundColor="#1f771f" position="322,544" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_yellow" backgroundColor="#1f771f" position="607,544" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_blue" backgroundColor="#1f771f" position="869,544" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="background" backgroundColor="#220a0a0a" zPosition="1" position="20,545" size="1055,40" font="Regular;20" halign="left" valign="center" />
		</screen>"""

	def __init__(self, session, path=None, title = "" ):
		Screen.__init__(self, session)
		self.session = session
		self.path = path
		self.newtitle = title
		self.changed = False
		self.e = None
		list = []
		try:
			menu = xml.dom.minidom.parse(self.path)
			self.XML_db = QuickButtonXML(menu)
			for e in self.XML_db.getMenu():
				if e[1] == "1":
					list.append(QuickButtonListEntry('green',(_(e[0]),e[0], '1')))
					
				else:
					list.append(QuickButtonListEntry('red',(_(e[0]),e[0], '')))
					
		except Exception as e:
			self.e = e
			list = []

		self["list"] = QuickButtonList(list=list, selection = 0)
		self["background"] = Label('')
		self["key_red"] = Label(_("Cancel"))
		self["key_green"] = Label(_("Save"))
		self["key_yellow"] = Label(_("delete"))
		self["key_blue"] = Label(_("Add"))
		self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], 
		{
			"ok": self.run,
			"cancel": self.cancel,
			"red": self.close,
			"green": self.save,
			"yellow": self.delete,
			"blue": self.add,
			"up": self.up,
			"down": self.down,
			"left": self.keyLeft,
			"right": self.keyRight
		}, -1)
		self.onExecBegin.append(self.error)
		self.onShown.append(self.updateTitle)

	def error(self):
		if self.e:
			self.session.open(MessageBox,("XML " + _("Error") + ": %s" % self.e),  MessageBox.TYPE_ERROR)
			self.close(None)

			
	def updateTitle(self):
		self.setTitle(self.newtitle)

	def run(self):
		if not self["list"].l.getCurrentSelection():
			return
		returnValue = self["list"].l.getCurrentSelection()[0][2]
		name = self["list"].l.getCurrentSelection()[0][1]
		self.changed = True
		if returnValue != None:
			idx = 0;
			if returnValue == "1":
				list = []
				self.XML_db.setSelection(name, "")
				for e in self.XML_db.getMenu():
					if e[1] == "1":
						list.append(QuickButtonListEntry('green',(_(str(e[0])),e[0], '1')))
						idx += 1
					else:
						list.append(QuickButtonListEntry('red',(_(str(e[0])),e[0], '')))

			else:
				list = []
				self.XML_db.setSelection(name, "1")
				for e in self.XML_db.getMenu():
					if e[1] == "1":
						list.append(QuickButtonListEntry('green',(_(str(e[0])),e[0], '1')))
						idx += 1
					else:
						list.append(QuickButtonListEntry('red',(_(str(e[0])),e[0], '')))

			self["list"].setList(list)

	def save(self):
		self.XML_db.saveMenu(self.path)
		self.changed = False
		self.cancel()

	def keyLeft(self):
		if len(self["list"].list) > 0:
			while 1:
				self["list"].instance.moveSelection(self["list"].instance.pageUp)
				if self["list"].l.getCurrentSelection()[0][1] != "--" or self["list"].l.getCurrentSelectionIndex() == 0:
					break

	def keyRight(self):
		if len(self["list"].list) > 0:
			while 1:
				self["list"].instance.moveSelection(self["list"].instance.pageDown)
				if self["list"].l.getCurrentSelection()[0][1] != "--" or self["list"].l.getCurrentSelectionIndex() == len(self["list"].list) - 1:
					break

	def up(self):
		if len(self["list"].list) > 0:
			while 1:
				self["list"].instance.moveSelection(self["list"].instance.moveUp)
				if self["list"].l.getCurrentSelection()[0][1] != "--" or self["list"].l.getCurrentSelectionIndex() == 0:
					break

	def down(self):
		if len(self["list"].list) > 0:
			while 1:
				self["list"].instance.moveSelection(self["list"].instance.moveDown)
				if self["list"].l.getCurrentSelection()[0][1] != "--" or self["list"].l.getCurrentSelectionIndex() == len(self["list"].list) - 1:
					break

	def getPluginsList(self):
		unic = []
		twins = [""]
		pluginlist = plugins.getPlugins([PluginDescriptor.WHERE_PLUGINMENU ,PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_EVENTINFO])
		pluginlist.sort(key = lambda p: p.name)
		for plugin in pluginlist:
			if plugin.name in twins:
				pass 
			else:
				unic.append((_(plugin.name), plugin.name, "plugins", ""))
				twins.append(plugin.name)
		return unic

	def getFunctionList(self):
		unic = []
		mqbfunctionfile = functionfile
		self.mqbfunctions = xml.dom.minidom.parse(mqbfunctionfile)
		for mqbfunction in self.mqbfunctions.getElementsByTagName("mqbfunction"):
			functionname = str(mqbfunction.getElementsByTagName("name")[0].childNodes[0].data)
			unic.append((_(functionname),functionname, "functions" ""))
		return unic

	def add(self):
		self.changed = True
		self.session.openWithCallback(self.setNewEntryType,ChoiceBox,_("MQB Functions and Plugins") ,self.getNewEntryType())

	def setNewEntryType(self, selection):
		if selection:
			if selection[1] == "functions":
				self.addfunction()
			elif selection[1] == "plugins":
				self.addplugin()
			elif selection[1] == "macros":
				self.addmacro()
			elif selection[1] == "scripts":
				self.addscript()
			else:
				self.session.open(MessageBox,_("No valid selection"), type = MessageBox.TYPE_ERROR,timeout = 5)

	def getNewEntryType(self):
		entrytype = []
		entrytype.append((_("Add Functions to MQB Key"),"functions"))
		entrytype.append((_("Add Plugins to MQB Key"),"plugins"))
		entrytype.append((_("Add Macro to MQB Key"),"macros"))
		entrytype.append((_("Add Script/Binary to MQB Key"),"scripts"))
		return entrytype

	def addfunction(self):
		self.changed = True
		try:
			self.session.openWithCallback(self.QuickPluginSelected,ChoiceBox,_("Functions") ,self.getFunctionList())
		except Exception as e:
			self.session.open(MessageBox,_("No valid function file found"), type = MessageBox.TYPE_ERROR,timeout = 5)

	def addplugin(self):
		self.changed = True
		self.session.openWithCallback(self.QuickPluginSelected,ChoiceBox,_("Plugins") ,self.getPluginsList())

	def addmacro(self):
		self.changed = True
		self.session.openWithCallback(self.QuickPluginSelected, MultiQuickButtonMacro)

	def addscript(self):
		self.changed = True
		self.session.openWithCallback(self.QuickPluginSelected, MultiQuickButtonScript)

	def QuickPluginSelected(self, choice):
		if choice:
			for entry in self["list"].list:
				if entry[0][0] == choice[0]:
					self.session.open(MessageBox,_("Entry %s already exists.") % (entry[0][0]),type = MessageBox.TYPE_ERROR,timeout = 5)
					return
			if choice[2] == "plugins":
				self.XML_db.addPluginEntry(choice[1])
			elif choice[2] == "functions":
				self.XML_db.addFunctionEntry(choice[1])
			elif choice[2] == "macros":
				self.XML_db.addMacroEntry(choice)
			elif choice[2] == "scripts":
				self.XML_db.addScriptEntry(choice)
			else:
				return
			list = []
			for newEntry in self.XML_db.getMenu():
				if newEntry[1] == "1":
					list.append(QuickButtonListEntry('green',(_(newEntry[0]), _(newEntry[0]), '1')))
				else:
					list.append(QuickButtonListEntry('red',(_(newEntry[0]), _(newEntry[0]), '')))
					
			self["list"].setList(list)
			if len(self["list"].list) > 0:
				while 1:
					self["list"].instance.moveSelection(self["list"].instance.moveDown)
					if self["list"].l.getCurrentSelection()[0][1] != '--' or self["list"].l.getCurrentSelectionIndex() == len(self["list"].list) - 1:
						break

	def delete(self):
		if not self["list"].l.getCurrentSelection():
			return
		self.changed = True
		name = self["list"].l.getCurrentSelection()[0][1]
		if name and name != "--":
			self.XML_db.rmEntry(name)

			list = []
			for e in self.XML_db.getMenu():
				if e[1] == "1":
					list.append(QuickButtonListEntry('green',(_(str(e[0])),e[0], '1')))
				else:
					list.append(QuickButtonListEntry('red',(_(str(e[0])),e[0], '')))

			lastValue="--"
			tmplist = []
			for i in list:
				if i[0][1] == "--" and lastValue == "--":
					lastValue = ""
				else:
					tmplist.append(i)
					lastValue = i[0][1]
			list = tmplist
			self["list"].setList(list)

	def cancel(self):
		if self.changed == True:
			self.session.openWithCallback(self.callForSaveValue,MessageBox,_("Save Settings"), MessageBox.TYPE_YESNO)
		else:
			self.close(None)

	def callForSaveValue(self, result):
		if result == True:
			self.save()
			self.close(None)
		else:
			self.close(None)

class QuickButtonSelection(Screen):

	global HD_Res

	try:
		sz_w = getDesktop(0).size().width()
	except:
		sz_w = 720

	if sz_w == 1280:
		HD_Res = True
	else:
		HD_Res = False

	if HD_Res:
		skin = """
		<screen position="415,260" size="1100,600" title="QuickButton" backgroundColor="background4">
			<widget name="list" position="10,10" size="1068,512" scrollbarMode="showOnDemand" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_red.png" zPosition="2" position="57,549" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_green.png" zPosition="2" position="302,549" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_yellow.png" zPosition="2" position="544,549" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_blue.png" zPosition="2" position="783,549" size="25,25" alphatest="on" />
			<widget name="key_red" backgroundColor="#1f771f" zPosition="2" position="89,544" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_green" backgroundColor="#1f771f" position="333,542" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_yellow" backgroundColor="#1f771f" position="575,542" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_blue" backgroundColor="#1f771f" position="816,542" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="background" backgroundColor="#220a0a0a" zPosition="1" position="0,539" size="1079,40" font="Regular;20" halign="left" valign="center" />
		</screen>"""
	else:
		skin = """
		<screen position="415,260" size="1100,600" title="QuickButton" >
			<widget name="list" position="10,10" size="1068,512" scrollbarMode="showOnDemand" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_red.png" zPosition="2" position="57,549" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_green.png" zPosition="2" position="302,549" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_yellow.png" zPosition="2" position="544,549" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_blue.png" zPosition="2" position="783,549" size="25,25" alphatest="on" />
			<widget name="key_red" backgroundColor="#1f771f" zPosition="2" position="89,544" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_green" backgroundColor="#1f771f" position="333,542" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_yellow" backgroundColor="#1f771f" position="575,542" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="key_blue" backgroundColor="#1f771f" position="816,542" zPosition="2" size="180,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="background" backgroundColor="#220a0a0a" zPosition="1" position="0,539" size="1079,40" font="Regular;20" halign="left" valign="center" />
		</screen>"""


	def __init__(self, session):
		Screen.__init__(self, session)
		self.skinName = [ "QuickButtonSelection", "QuickButton" ]
		self.session = session
		self.title = _("MultiQuickButton button selection")
		self.b_list = self.getButtonList()

		self["list"] = QuickButtonList(list = self.b_list, selection = 0, enableWrapAround = True)
		self["background"] = Label('')
		self["key_red"] = Label(_("Cancel"))
		self["key_green"] = Label(_("Save"))
		self["key_yellow"] = Label("")
		self["key_blue"] = Label("")
		self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], 
		{
			"ok": self.run,
			"cancel": self.cancel,
			"red": self.close,
			"green": self.save,
			"yellow": self.doNothing,
			"blue": self.doNothing,
			"up": self.up,
			"down": self.down,
			"left": self.keyLeft,
			"right": self.keyRight
		}, -1)
		self.onShown.append(self.updateTitle)

	def doNothing(self):
		pass

	def updateTitle(self):
		self.setTitle(self.title)

	def getButtonList(self):
		b_list = []
		mqbkeymap = open(mqbkeymapfile, "r")
		text = mqbkeymap.read()
		mqbkeymap.close()
		keys = getKeyDic()
		key_dic = getKeyDic()
		for key in keys:
			keyinactive = "<!-- " + keys[key][0] + " -->"
			if keyinactive in text:
				b_list.append(QuickButtonListEntry('red',(keys[key][1], key, '', keys[key][0])))
			else:
				b_list.append(QuickButtonListEntry('green',(keys[key][1], key, '1', keys[key][0])))
		b_list = sorted(b_list, key = lambda item: item[0][1])
		return b_list

	def setButtonList(self):
		mqbkeymap = open(mqbkeymapfile, "r")
		text = mqbkeymap.read()
		mqbkeymap.close()

		for entry in self.b_list:
			sel = entry[0][2]
			key = entry[0][3]
			keyinactive = "<!-- " + key + " -->"
			if keyinactive in text and sel == "1":
				text = text.replace(keyinactive, key)
			elif keyinactive in text and sel == "":
				pass
			elif key in text and sel != "1":
				text = text.replace(key, keyinactive)
		mqbkeymap = open(mqbkeymapfile, "w")
		mqbkeymap.write(text)
		mqbkeymap.close()
		keymapparser.removeKeymap(mqbkeymapfile)
		keymapparser.readKeymap(mqbkeymapfile)

	def run(self):
		if not self["list"].l.getCurrentSelection():
			return
		cur = self["list"].l.getCurrentSelection()[0]
		if cur == None:
			return
		cur_sel = cur[2]
		cur_key = cur[1]
		cur_name = cur[0]
		if cur_sel != None:
			b_list = []
			for entry in self.b_list:
				if cur_key == entry[0][1]:
					if cur_sel == "1":
						b_list.append(QuickButtonListEntry('red',(entry[0][0], entry[0][1], '', entry[0][3])))
					else:
						b_list.append(QuickButtonListEntry('green',(entry[0][0], entry[0][1], '1', entry[0][3])))
				else:
					if entry[0][2] == "1":
						b_list.append(QuickButtonListEntry('green',(entry[0][0], entry[0][1], '1', entry[0][3])))
					else:
						b_list.append(QuickButtonListEntry('red',(entry[0][0], entry[0][1], '', entry[0][3])))
			self.b_list = b_list
			self["list"].setList(b_list)
			self.down()

	def save(self):
		self.setButtonList()
		self.close(True)

	def keyLeft(self):
		if len(self["list"].list) > 0:
			self["list"].instance.moveSelection(self["list"].instance.pageUp)

	def keyRight(self):
		if len(self["list"].list) > 0:
			self["list"].instance.moveSelection(self["list"].instance.pageDown)

	def up(self):
		if len(self["list"].list) > 0:
			self["list"].instance.moveSelection(self["list"].instance.moveUp)

	def down(self):
		if len(self["list"].list) > 0:
			self["list"].instance.moveSelection(self["list"].instance.moveDown)

	def cancel(self):
		self.close(None)



class MultiQuickButtonMacro(Screen):
	skin = """
		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_red.png" zPosition="2" position="45,538" size="25,25" alphatest="on" />
		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_green.png" zPosition="2" position="353,538" size="25,25" alphatest="on" />
		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_yellow.png" zPosition="2" position="664,538" size="25,25" alphatest="on" />
		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_blue.png" zPosition="2" position="883,538" size="25,25" alphatest="on" />
		<widget name="buttonred" backgroundColor="#1f771f" position="76,527" zPosition="2" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
		<widget name="buttongreen" backgroundColor="#1f771f" position="382,527" zPosition="2" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
		<widget name="buttonyellow" backgroundColor="#1f771f" position="696,527" zPosition="2" size="150,40" font="Regular;20" halign="left" valign="center" transparent="1" />
		<widget name="buttonblue" backgroundColor="#1f771f" position="914,527" zPosition="2" size="150,40" font="Regular;20" halign="left" valign="center" transparent="1" />
		<widget source="menu" render="Listbox" position="10,10" size="1063,483" scrollbarMode="showOnDemand" enableWrapAround="1">
			<convert type="TemplatedMultiContent" transparent="0">
				{"template": [
						MultiContentEntryText(pos = (5, 2), size = (600, 20), font=0, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 0),
					],
				"fonts": [gFont("Regular", 22)],
				"itemHeight": 26
				}
			</convert>
		</widget>
		</screen>"""

	def __init__(self, session, args = 0):
		self.session = session
		Screen.__init__(self, session)
		
		self.title=_("MultiQuickButton macro configuration")
		try:
			self["title"]=StaticText(self.title)
		except:
			print('self["title"] was not found in skin')
		
		self.list = self.readConfig()
		self["menu"] = List(self.list)
		
		self["buttonred"] = Label(_("Name"))
		self["buttongreen"] = Label(_("Modify"))
		self["buttonyellow"] = Label(_("Delete"))
		self["buttonblue"] = Label(_("Add"))
		self["setupActions"] = ActionMap(["ColorActions", "SetupActions",],
			{
				"green": self.save,
				"red": self.keyRed,
				"blue": self.addButton,
				"yellow": self.removeButton,
				"cancel": self.keyCancel,
				"ok": self.keyOk,
			}, -2)
		self.selectmacro = True
		self.configmacro = False
		self.addkey = False
		
		self.buttondic = {
					"011" : "0",
					"002" : "1",
					"003" : "2",
					"004" : "3",
					"005" : "4",
					"006" : "5",
					"007" : "6",
					"008" : "7",
					"009" : "8",
					"010" : "9",
					"116" : _("Power"),
					"139" : _("Menu"),
					"402" : _("Channel +"),
					"403" : _("Channel -"),
					"358" : _("VU+ EPG / Info"),
					"352" : _("OK"),
					"105" : _("Cross Left"),
					"106" : _("Cross Right"),
					"103" : _("Cross Up"),
					"108" : _("Cross Down"),
					"174" : _("EXIT"),
					"398" : _("red"),
					"401" : _("blue"),
					"399" : _("green"),
					"400" : _("yellow"),
					"207" : _("Play"),
					"119" : _("Pause"),
					"128" : _("Stop"),
					"167" : _("Record"),
					"208" : _("FastForward >>"),
					"168" : _("Rewind <<"),
					"107" : _("END"),
					"102" : _("HOME"),
					"392" : _("Audio"),
					"370" : _("Subtitle"),
					"168" : _("Rewind <<"),
					"388" : _("TEXT"),
					"377" : _("TV"),
					"385" : _("RADIO"),
					"393" : _("VU+ R-Button"),
					"138" : _("HELP"),
					"115" : _("Volume +"),
					"114" : _("Volume -"),
					"113" : _("Mute"),
					"407" : _("Forward >"),
					"412" : _("Backward <"),
					"P100" : (_("Pause") + " 0.1 sec"),
					"P500" : (_("Pause") + " 0.5 sec"),
					"P1000" : (_("Pause") + " 1.0 sec")
				}

	def readConfig(self):
		config_list = []
		if not os.path.exists(macrofile):
			system("touch %s" % macrofile)
			os.chmod(macrofile, '0644')
		content = open(macrofile).readlines()
		for line in content:
			line = line.strip().split(":")
			if len(line) == 2:
				config_list.append((line[0], line[1]))
		return config_list

	def writeConfig(self):
		text = ""
		if len(self.list):
			for button in self.list:
				if len(button) == 2:
					text += "%s:%s\n" % (str(button[0]), str(button[1]))
		f = open(macrofile, "w")
		f.write(text)
		f.close()

	def changeMacroName(self, ret = None):
		if ret and ret[0]:
			idx = ret[1]
			cur_old = self.list[idx]
			self.list[idx] = (str(ret[0]), cur_old[1])

	def keyOk(self):
		cur = self["menu"].getCurrent()
		if cur:
			self["buttonred"].setText(_("Cancel"))
			self["buttongreen"].setText(_("Save"))
			self["buttonyellow"].setText(_("Delete"))
			self["buttonblue"].setText(_("Add"))
			if self.configmacro == False and self.selectmacro == True:
				self.writeConfig()
				cur_macro = self["menu"].getCurrent()
				ret = (cur_macro[0], cur_macro[1], "macros")
				self.close(ret)
			elif self.configmacro == True and self.selectmacro == False and self.addkey == True:
				self.addkey = False
				self.macrolist.insert(self.new_key_idx, cur)
				idx = len(self.macrolist) -1
				self["menu"].setList(self.macrolist)
				self['menu'].setIndex(self.new_key_idx)

	def addButton(self):
		if self.configmacro == True and self.selectmacro == False  and self.addkey == False:
			if len(self.macrolist):
				self.new_key_idx = self["menu"].getIndex() + 1
			else:
				self.new_key_idx = 0
			self["buttonred"].setText(_("Cancel"))
			self["buttongreen"].setText(_("Ok"))
			self["buttonyellow"].setText("")
			self["buttonblue"].setText("")
			self.addkey = True
			self.buttonlist =[]
			for key in sorted(self.buttondic.iterkeys()):
				if key.startswith('P'):
					self.buttonlist.append(("--- " + self.buttondic[key] + " ---", key))
				else:
					self.buttonlist.append((_("Button : ") + self.buttondic[key], key))
			self["menu"].setList(self.buttonlist)
		elif self.selectmacro == True:
			number = len(self.list) + 1
			idx = self["menu"].getIndex() + 1
			self.list.insert(idx, ("Macro %d" % number,""))
			if len(self.list) == 1:
				idx = 0
			self['menu'].setList(self.list)
			self['menu'].setIndex(idx)

	def removeButton(self):
		if self.configmacro == True and self.selectmacro == False  and self.addkey == False:
			# hm, why we have to recreate the list if we remove entries which exists twice in the list ???
			curidx = self["menu"].getIndex()
			idx = -1
			new_macrolist = []
			for entry in self.macrolist:
				idx += 1
				if idx != curidx:
					new_macrolist.append(entry)
			self.macrolist = new_macrolist
			self['menu'].setList(self.macrolist)
			if len(self.macrolist) == curidx:
				self['menu'].setIndex(curidx - 1)
			else:
				self['menu'].setIndex(curidx)
		elif self.selectmacro == True:
			curidx = self["menu"].getIndex()
			idx = -1
			new_list = []
			for entry in self.list:
				idx += 1
				if idx != curidx:
					new_list.append(entry)
			self.list = new_list
			self['menu'].setList(self.list)
			if len(self.list) == curidx:
				self['menu'].setIndex(curidx - 1)
			else:
				self['menu'].setIndex(curidx)

	def save(self):
		if self.configmacro == True and self.selectmacro == False and self.addkey == False:
			self.selectmacro = True
			self.configmacro = False
			self.addkey = False
			self.new_config_value = ""
			for entry in self.macrolist:
				self.new_config_value = self.new_config_value + "," + entry[1]
			self.new_config_value = self.new_config_value.strip(",")
			i = self.current_macro
			macro = self.list[i][0]
			self.list[i] = (macro, self.new_config_value)
			self["buttonred"].setText(_("Name"))
			self["buttongreen"].setText(_("Modify"))
			self["menu"].setList(self.list)
			self.writeConfig()
		elif self.configmacro == False and self.selectmacro == True:
			if len(self.list):
				cur = self["menu"].getCurrent()
				self.selectmacro = False
				self.configmacro = True
				self.current_macro = self.list.index(cur)
				self.macrolist = []
				for key in cur[1].split(","):
					if key in self.buttondic:
						if key.startswith('P'):
							self.macrolist.append(("--- " + _(self.buttondic[key]) + " ---", key))
						else:
							self.macrolist.append((_("Button : ") + _(self.buttondic[key]), key))
				self["menu"].setList(self.macrolist)
				self["buttonred"].setText(_("Cancel"))
				self["buttongreen"].setText(_("Save"))

	def keyRed(self):
		if self.configmacro == False and self.selectmacro == True:
			cur = self["menu"].getCurrent()
			idx = self.list.index(cur)
			oldname = cur[0]
			self.session.openWithCallback(self.changeMacroName, InputMacroName, idx, oldname)
		
		elif self.configmacro == True and self.selectmacro == False and self.addkey == False:
			self.selectmacro = True
			self.configmacro = False
			self["buttonred"].setText(_("Name"))
			self["buttongreen"].setText(_("Modify"))
			self["buttonyellow"].setText(_("Delete"))
			self["buttonblue"].setText(_("Add"))
			self["menu"].setList(self.list)
		
		elif self.configmacro == True and self.selectmacro == False and self.addkey == True:
			self.addkey = False
			self["buttonred"].setText(_("Cancel"))
			self["buttongreen"].setText(_("Save"))
			self["buttonyellow"].setText(_("Delete"))
			self["buttonblue"].setText(_("Add"))
			self["menu"].setList(self.macrolist)

	def keyCancel(self):
		if self.configmacro == False and self.selectmacro == True:
			ret = None
			self.close(ret)
		else:
			self.keyRed()

class InputMacroName(Screen, ConfigListScreen):
	skin = """
		<screen name="InputMacroName" position="center,center" size="840,300" title="Input macro name" backgroundColor="background4">
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_red.png" zPosition="2" position="10,50" size="25,25" alphatest="on" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MultiQuickButton/pic/button_green.png" zPosition="2" position="160,50" size="25,25" alphatest="on" />
			<widget render="Label" source="key_red" backgroundColor="#1f771f" position="35,43" zPosition="2" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget render="Label" source="key_green" backgroundColor="#1f771f" position="185,43" zPosition="2" size="250,40" font="Regular;20" halign="left" valign="center" transparent="1" />
			<widget name="config" zPosition="2" position="10,7" size="814,276" transparent="1" />
		</screen>
		"""

	def __init__(self, session, idx, oldname):
		Screen.__init__(self, session)
		self.title=_("Input name for MQB macro")
		try:
			self["title"]=StaticText(self.title)
		except:
			print('self["title"] was not found in skin')
		self.listidx = idx
		self.macroname = NoSave(ConfigText(default = oldname, visible_width = 50, fixed_size = False))
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Ok"))
		self["shortcuts"] = ActionMap(["SetupActions", "ColorActions", "InputActions"],
		{
			"ok": self.keyGo,
			"cancel": self.keyCancel,
			"red": self.keyCancel,
			"green": self.keyGo,
		}, -1)
		self.list = []
		ConfigListScreen.__init__(self, self.list,session = session)
		self.createSetup()

	def createSetup(self):
		self.list = []
		self.inputpanelpassword = getConfigListEntry(_("Input name for MQB macro : "), self.macroname)
		self.list.append(self.inputpanelpassword)
		self["config"].list = self.list
		self["config"].l.setList(self.list)

	def keyCancel(self):
		ret = None
		self.close((ret, self.listidx))

	def keyGo(self):
		ret = self.macroname.value
		self.close((ret, self.listidx))


class MultiQuickButtonScript(Screen):
	skin = """
		<screen name="MultiQuickButtonScript" position="415,260" size="1100,600" title="Select file to execute" backgroundColor="background4">
		<ePixmap pixmap="skin_default/buttons/red.png" position="212,3" zPosition="0" size="140,40" transparent="1" alphatest="on" />
		<ePixmap pixmap="skin_default/buttons/green.png" position="465,3" zPosition="0" size="140,40" transparent="1" alphatest="on" />
		<ePixmap pixmap="skin_default/buttons/blue.png" position="714,3" zPosition="0" size="140,40" transparent="1" alphatest="on" />
		<widget name="executable" position="10,50" size="1072,50" valign="top" font="Regular;22" />
		<widget name="keyblue" position="733,3" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="blue" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
		<widget name="filelist" position="10,90" zPosition="1" size="1074,486" scrollbarMode="showOnDemand" />
		<widget render="Label" source="key_red" position="237,3" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
		<widget render="Label" source="key_green" position="487,3" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="green" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
		</screen>
	"""

	def __init__(self, session):
		Screen.__init__(self, session)
		initDir = "/"
		self["filelist"] = FileList(initDir, inhibitMounts = False, inhibitDirs = False, showMountpoints = False)
		self["executable"] = Label()
		self["keyblue"] = Label()
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions"],
		{
			"back": self.cancel,
			"left": self.left,
			"right": self.right,
			"up": self.up,
			"down": self.down,
			"ok": self.ok,
			"green": self.green,
			"blue": self.blue,
			"red": self.cancel
			
		}, -1)
		self.title=_("Select a file to execute")
		try:
			self["title"]=StaticText(self.title)
		except:
			print('self["title"] was not found in skin')
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("OK"))

	def cancel(self):
		self.close((None, None, None))

	def green(self):
		if self["filelist"].getSelection()[1] == True:
			self["executable"].setText(_("Invalid Choice"))
		else:
			directory = self["filelist"].getCurrentDirectory()
			if (directory.endswith("/")):
				self.fullpath = self["filelist"].getCurrentDirectory() + self["filelist"].getFilename()
			else:
				self.fullpath = self["filelist"].getCurrentDirectory() + "/" + self["filelist"].getFilename()
			if not os.access(self.fullpath,os.X_OK):
				self["executable"].setText(_("File != executable"))
			else:
				file_name = os.path.basename(self.fullpath)
				self.mqb_name = _("Script") + ": " + file_name
				self.exe_file = self.fullpath
				self.ret = (_("Script") + ": " + file_name, self.fullpath, "scripts")
				self.session.openWithCallback(self.add_cmd_options, MessageBox,_("Add command line options ?"), type = MessageBox.TYPE_YESNO, default = False)
			  	#self.close()

	def blue(self):
		notexec = self["keyblue"].getText()
		if notexec == "chmod 755":
			directory = self["filelist"].getCurrentDirectory()
			if (directory.endswith("/")):
				self.fullpath = self["filelist"].getCurrentDirectory() + self["filelist"].getFilename()
			else:
				self.fullpath = self["filelist"].getCurrentDirectory() + "/" + self["filelist"].getFilename()
			os.chmod(self.fullpath, '0755')
			self["keyblue"].setText(_(" "))
			self["executable"].setText(self["filelist"].getFilename())
		else:
			pass

	def add_cmd_options(self, ret):
		if ret:
			self.session.openWithCallback(self.close_with_option, InputBox, title = _("Please enter the command line options"), text = "")
		else:
			self.close_with_option()

	def close_with_option(self, ret = None):
		if ret:
			self.exe_file = self.exe_file + " " + ret
			self.mqb_name = self.mqb_name + " " + ret
		self.close((self.mqb_name, self.exe_file, "scripts"))

	def up(self):
		self["filelist"].up()
		self.updateFile()

	def down(self):
		self["filelist"].down()
		self.updateFile()

	def left(self):
		self["filelist"].pageUp()
		self.updateFile()

	def right(self):
		self["filelist"].pageDown()
		self.updateFile()

	def ok(self):
		if self["filelist"].canDescent():
			self["filelist"].descent()
			self.updateFile()

	def updateFile(self):
		currFolder = self["filelist"].getSelection()[0]
		if self["filelist"].getFilename() != None:
			directory = self["filelist"].getCurrentDirectory()
			if (directory.endswith("/")):
				self.fullpath = self["filelist"].getCurrentDirectory() + self["filelist"].getFilename()
			else:
				self.fullpath = self["filelist"].getCurrentDirectory() + "/" + self["filelist"].getFilename()
			if not os.access(self.fullpath,os.X_OK):
				if self["filelist"].getSelection()[1] == True:
					self["executable"].setText(currFolder)
					self["keyblue"].setText(_(" "))
				else:
					self["executable"].setText(_("File != executable"))
					self["keyblue"].setText(_("chmod 755"))
			else:
				self["executable"].setText(self["filelist"].getFilename())
				self["keyblue"].setText(_(" "))
		else:
			currFolder = self["filelist"].getSelection()[0]
			if currFolder != None:
				self["executable"].setText(currFolder)
				self["keyblue"].setText(_(" "))
			else:
				self["executable"].setText(_("Invalid Choice"))
				self["keyblue"].setText(_(" "))
