#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import print_function

import threading

from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from enigma import eTimer

from .plugin import cfg
from .xStaticText import StaticText


class XKlass_Audio_QuickReturn(Screen):
    """Cached channel list for the currently running R25/R26 background IPAUDIO."""
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session=session
        from .backgroundaudio import get_resume_context
        self.context=get_resume_context() or {}
        self.channels=list(self.context.get('channels') or [])
        self.source=str(self.context.get('source') or '')
        self.current_index=int(self.context.get('selected_index') or 0) if self.channels else 0
        if self.current_index < 0 or self.current_index >= len(self.channels):
            self.current_index=0
        try:
            from .stalker import _channels_skin
            self.skin=_channels_skin()
        except Exception:
            self.skin='<screen name="XKlassAudioQuickReturn" position="0,0" size="720,576" backgroundColor="#50002040" flags="wfNoBorder"></screen>'
        self['title']=StaticText('')
        self['key_red']=StaticText('Back')
        self['key_green']=StaticText('Audio')
        self['key_yellow']=StaticText('IPAudio Pro')
        self['key_blue']=StaticText('Main Menu')
        self['list']=List([], enableWrapAround=True)
        self['actions']=ActionMap(['XKlassActions','OkCancelActions','ColorActions','MenuActions'], {
            'cancel': self.exit_browser,
            'red': self.exit_browser,
            'green': self.play_selected,
            'ok': self.play_selected,
            'yellow': self.add_pro,
            'blue': self.open_main_menu,
            'menu': self.options_menu,
            'stop': self.stop_all,
        }, -10)
        self._resolving=False
        self._done=False
        self._error=''
        self._resolved=''
        self._client=None
        self._target_index=self.current_index
        self._target_name=''
        self._target_cmd=''
        self._timer=eTimer()
        try:
            self._timer_conn=self._timer.timeout.connect(self._poll_resolve)
        except Exception:
            self._timer.callback.append(self._poll_resolve)
        self.onLayoutFinish.append(self._build)

    def _name_value(self, item):
        if isinstance(item, dict):
            return str(item.get('name') or 'Channel'), str(item.get('value') or item.get('url') or item.get('cmd') or '')
        if isinstance(item, (list,tuple)) and len(item) >= 2:
            return str(item[0]), str(item[1])
        return str(item), ''

    def _build(self):
        rows=[]
        for idx,item in enumerate(self.channels):
            name,_=self._name_value(item)
            rows.append((name,idx))
        if not rows:
            rows=[('No cached IPAUDIO channels.',-1)]
        self['list'].setList(rows)
        if self.channels:
            try: self['list'].setIndex(self.current_index)
            except Exception: pass
        label={'stalker':'MAC IPAUDIO','xtream':'IPAUDIO XTREME','best_audio':'Best Audio',
               'sat_family':'Sat Family Audio','orange_audio':'Orange IPAUDIO',
               'free_audio':'Free IPAUDIO'}.get(self.source,'IPAUDIO')
        name=self._name_value(self.channels[self.current_index])[0] if self.channels else ''
        self['title'].setText('%s - %s' % (label,name))

    def _index(self):
        cur=self['list'].getCurrent()
        try: return int(cur[1]) if cur else -1
        except Exception: return -1

    def play_selected(self):
        if self._resolving: return
        idx=self._index()
        if idx < 0 or idx >= len(self.channels): return
        if idx == self.current_index:
            self.exit_browser(); return
        name,value=self._name_value(self.channels[idx])
        self._target_index=idx; self._target_name=name; self._target_cmd=value
        self['title'].setText('Switching audio to %s ...' % name)
        if self.source == 'stalker':
            self._resolving=True; self._done=False; self._error=''; self._resolved=''
            t=threading.Thread(target=self._resolve_worker, args=(value,))
            t.daemon=True; t.start(); self._timer.start(120,False)
        else:
            self._start_audio(value,name,idx,{'User-Agent': str(cfg.useragent.value)})

    def _resolve_worker(self, command):
        try:
            from .stalker import StalkerClient
            self._client=StalkerClient(dict(self.context.get('portal') or {}))
            self._resolved=self._client.create_link(command)
            if not self._resolved: raise RuntimeError('Portal did not return a playable stream URL')
        except Exception as e:
            self._error=str(e)
        self._done=True

    def _poll_resolve(self):
        if not self._done: return
        try: self._timer.stop()
        except Exception: pass
        self._resolving=False
        if self._error:
            self.session.open(MessageBox,'Unable to resolve MAC channel:\n%s' % self._error,MessageBox.TYPE_ERROR,timeout=7)
            self._build(); return
        headers=dict(getattr(self._client,'headers',{}) or {})
        self._start_audio(self._resolved,self._target_name,self._target_index,headers)

    def _start_audio(self, url, name, idx, headers):
        try:
            from .backgroundaudio import start_background_audio_direct
            context=dict(self.context)
            context['selected_index']=int(idx)
            context['channel_name']=str(name)
            retry=None
            if self.source == 'stalker':
                cmd=self._target_cmd
                client=self._client
                retry=(lambda: client.create_link(cmd)) if client is not None else None
            start_background_audio_direct(self.session,str(url),str(name),headers=dict(headers or {}),resume_context=context,retry_resolver=retry)
            self.context=context; self.current_index=int(idx)
            try: self['list'].setIndex(self.current_index)
            except Exception: pass
            label={'stalker':'MAC IPAUDIO','xtream':'IPAUDIO XTREME','best_audio':'Best Audio',
                   'sat_family':'Sat Family Audio','orange_audio':'Orange IPAUDIO',
                   'free_audio':'Free IPAUDIO'}.get(self.source,'IPAUDIO')
            self['title'].setText('%s - %s' % (label,name))
        except Exception as e:
            self.session.open(MessageBox,'Unable to switch IPAUDIO:\n%s' % e,MessageBox.TYPE_ERROR,timeout=8)
            self._build()

    def _selected_for_export(self, callback):
        idx=self._index()
        if idx < 0 or idx >= len(self.channels): return
        name,value=self._name_value(self.channels[idx])
        if self.source != 'stalker':
            callback(name,value); return
        self._export_callback=callback
        self._target_name=name; self._target_cmd=value
        self._resolving=True; self._done=False; self._error=''; self._resolved=''
        t=threading.Thread(target=self._resolve_worker,args=(value,)); t.daemon=True; t.start()
        # reuse poll but route export after resolve
        self._export_pending=True
        self._timer.start(120,False)

    def _export(self, kind, name, url):
        try:
            from .ipaudioexport import export_channel
            path,added=export_channel(kind,name,url)
            msg=('%s added to %s' if added else '%s is already in %s') % (name,path)
            if self.source == 'stalker':
                msg += '\n\nMAC link was freshly resolved. Some portals issue expiring links.'
            self.session.open(MessageBox,msg,MessageBox.TYPE_INFO,timeout=7)
        except Exception as e:
            self.session.open(MessageBox,'Unable to save channel:\n%s' % e,MessageBox.TYPE_ERROR,timeout=8)

    def add_pro(self):
        self._export_selected_kind='pro'; self._selected_for_export(lambda n,u:self._export('pro',n,u))

    def add_legacy(self):
        self._export_selected_kind='legacy'; self._selected_for_export(lambda n,u:self._export('legacy',n,u))

    def _poll_resolve(self):
        if not self._done: return
        try: self._timer.stop()
        except Exception: pass
        self._resolving=False
        if self._error:
            self.session.open(MessageBox,'Unable to resolve MAC channel:\n%s' % self._error,MessageBox.TYPE_ERROR,timeout=7)
            self._build(); return
        if getattr(self,'_export_pending',False):
            self._export_pending=False
            cb=getattr(self,'_export_callback',None)
            if cb: cb(self._target_name,self._resolved)
            return
        headers=dict(getattr(self._client,'headers',{}) or {})
        self._start_audio(self._resolved,self._target_name,self._target_index,headers)

    def options_menu(self):
        self.session.openWithCallback(self._option_selected,ChoiceBox,title='Active IPAUDIO',list=[
            ('Add to IPAudio Pro','add_pro'),
            ('Add to IPAudio','add_old'),
            ('Stop IPAUDIO and restore satellite audio','stop'),
            ('Open XKlass main menu','main'),
            ('Cancel','cancel'),
        ])

    def _option_selected(self, answer=None):
        if not answer or len(answer)<2: return
        action=answer[1]
        if action=='add_pro': self.add_pro()
        elif action=='add_old': self.add_legacy()
        elif action=='stop':
            self.stop_all()
        elif action=='main': self.open_main_menu()

    def open_main_menu(self):
        try:
            from . import startmenu
            self.session.open(startmenu.XKlass_MainMenu)
        except Exception as e:
            self.session.open(MessageBox,'Unable to open main menu:\n%s' % e,MessageBox.TYPE_ERROR,timeout=6)

    def exit_browser(self):
        self.close()

    def stop_all(self):
        try:
            from .backgroundaudio import stop_ipaudio_and_timeshift
            stop_ipaudio_and_timeshift(session=self.session, close_plugin=True)
        except Exception as e:
            self.session.open(MessageBox,'Unable to stop IPAUDIO / Timeshift:\n%s' % e,
                              MessageBox.TYPE_ERROR,timeout=6)
