#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Small text-only UI helpers that stay fast on low-memory receivers."""


def first_letter(value, default="S"):
    text = str(value or "").strip()
    for char in text:
        if char.isalnum():
            return char.upper()
    return default


def server_row(name, host="", details=""):
    """Create a lightweight first-letter avatar without loading extra images."""
    title = str(name or "Server").strip() or "Server"
    pieces = ["● %s" % first_letter(title), title]
    if host:
        pieces.append("‹%s›" % str(host))
    if details:
        pieces.append(str(details))
    return "   ".join(pieces)


def channel_row(number, name, playing=False):
    marker = "▶" if playing else " "
    return "%s %03d   %s" % (marker, int(number) + 1, str(name or "Channel"))
