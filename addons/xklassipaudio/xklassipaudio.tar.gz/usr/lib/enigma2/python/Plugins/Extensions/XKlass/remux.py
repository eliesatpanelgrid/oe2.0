#!/usr/bin/python
# -*- coding: utf-8 -*-
"""IPAudio AlQuds Lite24 R14 Timeshift Compat Gate.

R14 keeps the receiver-proven R9 remux + automatic retry path and the R11/R12
session reset/Stable Gate, but makes the disk recorder deterministic across
OpenATV/Enigma2 images.  The preferred recorder is a tiny Python 2/3-compatible
raw HTTP copier, with curl/wget/FFmpeg as fallbacks.  The gate also validates
real 188-byte MPEG-TS sync before freezing video.  The proven Local Remux audio
path is deliberately untouched.

Legacy design notes:

Goal:
    DVB satellite video + IPTV/Stalker audio -> one local MPEG-TS service.

The receiver only has one hardware DVB audio decoder, so independent background
sound is impossible on some Broadcom images.  Instead we keep everything as ONE
Enigma2 service:

    input 0: local Enigma2 streamproxy (satellite service)
    input 1: selected Xtream/Stalker stream
    output : local HTTP MPEG-TS served by ffmpeg

Dual mode maps two audio tracks into the local TS:
    track 1: IPTV audio (MP2 128k, default)
    track 2: original satellite audio (stream copy)

Video is never transcoded; it is always copied bit-for-bit.
"""

from __future__ import print_function

import os
import socket
import subprocess
import threading
import time
import fcntl
import glob as glob_module

try:
    from urllib.parse import quote
except Exception:
    from urllib import quote

from enigma import eServiceReference, eTimer

try:
    from . import xklass_globals as glob
except Exception:
    glob = None

LOG = "/tmp/xklass-remux.log"
FFLOG = "/tmp/xklass-remux-ffmpeg.log"

_LOCK = threading.RLock()
_STATE = {
    "session": None,
    "proc": None,
    "timer": None,
    "timer_conn": None,
    "original_ref": "",
    "local_ref": "",
    "local_url": "",
    "iptv_name": "",
    "mode": "",
    "port": 0,
    "started": 0.0,
    "armed": False,
    "played": False,
    "error": "",
    "stderr": None,
    "iptv_headers": {},
    "resume_context": None,
    "iptv_url": "",
    "video_hold": False,
    "timeshift_recorder": None,
    "timeshift_recorder_log": None,
    "timeshift_tail": None,
    "timeshift_file": "",
    "timeshift_started": 0.0,
    "timeshift_recording": False,
    "timeshift_playback": False,
    "timeshift_delay": 0.0,
    "timeshift_last_size": 0,
    "timeshift_last_growth": 0.0,
    "timeshift_last_restart": 0.0,
    "timeshift_signal_lost": False,
    "timeshift_rate_bps": 0.0,
    "timeshift_sample_time": 0.0,
    "resume_after_play": False,
    "video_hold_started": 0.0,
    "video_hold_min": 2.0,
    "audio_relay": None,
    "audio_slot": 0,
    "timeshift_video_proc": None,
    "timeshift_video_log": None,
    "timeshift_video_port": 0,
    "timeshift_video_generation": 0,
    "timeshift_video_clock_started": 0.0,
    "startup_phase": "",
    "retry_count": 0,
    "retry_max": 1,
    "retrying": False,
    "retry_resolver": None,
}


def _log(msg):
    try:
        with open(LOG, "a") as f:
            f.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), str(msg)))
    except Exception:
        pass


def _find_executable(name):
    for base in ("/usr/bin", "/bin", "/usr/local/bin"):
        path = os.path.join(base, name)
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    return ""


def _find_python_executable():
    # Use a real standalone interpreter. Embedded Enigma2 can report
    # /usr/bin/enigma2 as sys.executable, which is not suitable for -c helpers.
    for name in ("python3", "python", "python2.7", "python2"):
        path = _find_executable(name)
        if path:
            return path
    return ""


_PY_RAW_RECORDER = r'''from __future__ import print_function
import socket
import sys
try:
    from urllib.request import Request, urlopen
except Exception:
    from urllib2 import Request, urlopen
socket.setdefaulttimeout(12.0)
url = sys.argv[1]
req = Request(url)
try:
    req.add_header('User-Agent', 'Alkuds-IPAudio-R14')
    req.add_header('Accept', '*/*')
except Exception:
    pass
resp = urlopen(req, timeout=12.0)
out = getattr(sys.stdout, 'buffer', sys.stdout)
while True:
    data = resp.read(188 * 256)
    if not data:
        break
    out.write(data)
    out.flush()
'''


_PY_FILE_FOLLOWER = r'''from __future__ import print_function
import os
import sys
import time
path = sys.argv[1]
start = max(0, int(sys.argv[2]) - 1)
out = getattr(sys.stdout, 'buffer', sys.stdout)
f = open(path, 'rb')
f.seek(start, os.SEEK_SET)
while True:
    data = f.read(188 * 256)
    if data:
        out.write(data)
        out.flush()
    else:
        time.sleep(0.05)
'''


def _ts_sync_ok(path):
    # Cheap MPEG-TS body validation compatible with Python 2 and Python 3.
    try:
        with open(path, "rb") as f:
            data = f.read(188 * 12)
    except Exception:
        return False
    if len(data) < 188 * 5:
        return False

    def _byte(i):
        value = data[i]
        if isinstance(value, int):
            return value
        return ord(value)

    # Search one packet width and require five consecutive 0x47 sync bytes.
    limit = min(188, max(0, len(data) - (188 * 5)))
    for offset in range(limit + 1):
        good = True
        for n in range(5):
            if _byte(offset + (n * 188)) != 0x47:
                good = False
                break
        if good:
            return True
    return False


def _service_string(session):
    try:
        ref = session.nav.getCurrentlyPlayingServiceReference()
        if ref:
            return str(ref.toString())
    except Exception:
        pass
    return ""


def _is_dvb_ref(refstr):
    try:
        return int(str(refstr).split(":", 1)[0]) == 1
    except Exception:
        return False


def _pick_satellite_ref(session):
    # Prefer the service that was active when XKlass was opened.  Stalker/Xtream
    # preview playback may have replaced the current service by the time MENU is
    # opened, but xklass_globals keeps the original service reference.
    candidates = []
    # Lite18: when switching the IPTV audio source while a local remux is already
    # running, the currently playing service is the local 4097 URL, not DVB.
    # Keep using the original DVB reference stored by the active remux.
    try:
        with _LOCK:
            active_original = str(_STATE.get("original_ref") or "") if _STATE.get("armed") else ""
        if active_original:
            candidates.append(active_original)
    except Exception:
        pass
    try:
        if glob is not None:
            candidates.append(str(getattr(glob, "currentPlayingServiceRefString", "") or ""))
    except Exception:
        pass
    candidates.append(_service_string(session))

    for ref in candidates:
        if _is_dvb_ref(ref):
            return ref
    return ""


def _streamproxy_url(refstr):
    # Colons are valid in the Enigma2 service-ref path.  Encode everything else
    # so channel names/odd URL fields cannot corrupt the HTTP request.
    return "http://127.0.0.1:8001/%s" % quote(str(refstr), safe=":")


_PORT_CURSOR = 17999
_RECENT_PORTS = {}


def _find_free_port():
    """Pick a rotating local port and avoid immediate reuse after a handover.

    Reusing 17999/18000 immediately can leave FFmpeg colliding with a socket in
    TIME_WAIT on some Enigma2 images. That typically appears as: first delay
    change works, the next one hangs. Keep a 90-second cooldown per port and
    rotate through a wider private range.
    """
    global _PORT_CURSOR
    now = time.time()
    start = int(_PORT_CURSOR or 17999)
    ports = list(range(start, 18120)) + list(range(17999, start))
    for port in ports:
        last = float(_RECENT_PORTS.get(port, 0.0) or 0.0)
        if last and (now - last) < 90.0:
            continue
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("127.0.0.1", port))
            _RECENT_PORTS[port] = now
            _PORT_CURSOR = 17999 if port >= 18119 else port + 1
            return port
        except Exception:
            pass
        finally:
            try:
                s.close()
            except Exception:
                pass
    # If every candidate is still cooling down, make one last pass based only
    # on actual bindability instead of failing the whole remux.
    for port in range(17999, 18120):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("127.0.0.1", port))
            _RECENT_PORTS[port] = now
            _PORT_CURSOR = 17999 if port >= 18119 else port + 1
            return port
        except Exception:
            pass
        finally:
            try:
                s.close()
            except Exception:
                pass
    raise RuntimeError("No free local port for XKlass remux")


def _port_listening(port):
    wanted = "%04X" % int(port)
    for procfile in ("/proc/net/tcp", "/proc/net/tcp6"):
        try:
            with open(procfile, "r") as f:
                for line in f.readlines()[1:]:
                    fields = line.split()
                    if len(fields) < 4:
                        continue
                    local_addr = fields[1]
                    state = fields[3]
                    if state == "0A" and local_addr.upper().endswith(":" + wanted):
                        return True
        except Exception:
            pass
    return False


def _udp_port_bound(port):
    """Return True once FFmpeg has bound the local UDP audio input.

    Lite24 R3 uses this as the startup handshake between the main Local Remux
    and the persistent IPTV audio relay.  The relay is not allowed to send its
    first MPEG-TS packets until this becomes true.
    """
    wanted = "%04X" % int(port)
    for procfile in ("/proc/net/udp", "/proc/net/udp6"):
        try:
            with open(procfile, "r") as f:
                for line in f.readlines()[1:]:
                    fields = line.split()
                    if len(fields) < 2:
                        continue
                    local_addr = fields[1]
                    if local_addr.upper().endswith(":" + wanted):
                        return True
        except Exception:
            pass
    return False


def _terminate(proc):
    if not proc:
        return
    try:
        if proc.poll() is None:
            proc.terminate()
            end = time.time() + 0.8
            while proc.poll() is None and time.time() < end:
                time.sleep(0.05)
            if proc.poll() is None:
                proc.kill()
    except Exception:
        pass


def _terminate_fast(proc):
    """Stop a short-lived video feeder with a tiny UDP gap.

    The normal 0.8s graceful wait is useful for the main remux, but far too
    long for a live video-source switch: while video is absent FFmpeg may hold
    audio for interleaving.  Keep the gap below roughly one frame period.
    """
    if not proc:
        return
    try:
        if proc.poll() is None:
            proc.terminate()
            end = time.time() + 0.06
            while proc.poll() is None and time.time() < end:
                time.sleep(0.01)
            if proc.poll() is None:
                proc.kill()
    except Exception:
        pass


def _close_fflog():
    with _LOCK:
        fh = _STATE.get("stderr")
        _STATE["stderr"] = None
    if fh:
        try:
            fh.close()
        except Exception:
            pass


def _stop_timer():
    with _LOCK:
        timer = _STATE.get("timer")
        _STATE["timer"] = None
        _STATE["timer_conn"] = None
    if timer:
        try:
            timer.stop()
        except Exception:
            pass


def _reset_state(keep_original=False):
    with _LOCK:
        original = _STATE.get("original_ref", "") if keep_original else ""
        _STATE.update({
            "session": None,
            "proc": None,
            "timer": None,
            "timer_conn": None,
            "original_ref": original,
            "local_ref": "",
            "local_url": "",
            "iptv_name": "",
            "mode": "",
            "port": 0,
            "started": 0.0,
            "armed": False,
            "played": False,
            "error": "",
            "stderr": None,
            "iptv_headers": {},
            "resume_context": None,
            "iptv_url": "",
            "video_hold": False,
            "timeshift_recorder": None,
            "timeshift_recorder_log": None,
            "timeshift_tail": None,
            "timeshift_file": "",
            "timeshift_started": 0.0,
            "timeshift_recording": False,
            "timeshift_playback": False,
            "timeshift_delay": 0.0,
    "timeshift_last_size": 0,
    "timeshift_last_growth": 0.0,
    "timeshift_last_restart": 0.0,
    "timeshift_signal_lost": False,
    "timeshift_rate_bps": 0.0,
    "timeshift_sample_time": 0.0,
            "resume_after_play": False,
            "video_hold_started": 0.0,
            "video_hold_min": 2.0,
            "audio_relay": None,
            "audio_slot": 0,
            "timeshift_video_proc": None,
            "timeshift_video_log": None,
            "timeshift_video_port": 0,
            "timeshift_video_generation": 0,
            "timeshift_video_clock_started": 0.0,
            "startup_phase": "",
            "retry_count": 0,
            "retry_max": 1,
            "retrying": False,
            "retry_resolver": None,
        })


def _ffmpeg_command(ffmpeg, sat_url, iptv_url, output_url, mode, iptv_headers=None, sat_pipe=False):
    relay_audio = str(iptv_url or "").startswith("udp://127.0.0.1:")
    # Audio transcode only.  MP2 is deliberately chosen because it is cheap to
    # encode and universally understood by old DVB/Enigma2 audio decoders.
    #
    # Lite24 R5 compatibility rule: when IPTV audio already comes from our local
    # UDP relay, open that UDP input FIRST.  FFmpeg therefore binds the receive
    # socket immediately, before it spends time probing streamproxy/DVB.  The
    # startup worker can then see the bound port and only afterwards activate
    # the provider relay.  This removes the 7-second "satellite did not reach
    # audio-input stage" race seen on older/vendor Enigma2 FFmpeg builds.
    cmd = [
        ffmpeg,
        "-nostdin", "-hide_banner", "-loglevel", "error",
        "-fflags", "+genpts+discardcorrupt",
    ]

    headers = dict(iptv_headers or {})

    if relay_audio:
        # Input 0: persistent local IPTV audio relay.  Keep the URL itself plain
        # for maximum compatibility; fifo_size/overrun_nonfatal URL AVOptions
        # are rejected by some receiver FFmpeg packages.
        cmd += [
            "-probesize", "1048576", "-analyzeduration", "1000000",
            "-thread_queue_size", "512", "-i", str(iptv_url),
        ]

        # Input 1: satellite video (live streamproxy or the fixed timeshift UDP
        # video feeder).  This is opened only after the audio socket is bound.
        if sat_pipe:
            cmd += ["-re", "-thread_queue_size", "1024", "-i", "pipe:0"]
        else:
            cmd += [
                "-probesize", "8388608", "-analyzeduration", "4000000",
                "-thread_queue_size", "1024", "-i", str(sat_url),
            ]
        video_input = 1
        audio_input = 0
    else:
        # Direct-provider path retained for modes which do not use the
        # persistent relay.  Satellite remains input 0 and IPTV input 1.
        if sat_pipe:
            cmd += ["-re", "-thread_queue_size", "1024", "-i", "pipe:0"]
        else:
            cmd += [
                "-probesize", "8388608", "-analyzeduration", "4000000",
                "-thread_queue_size", "1024", "-i", str(sat_url),
            ]

        if str(iptv_url).lower().startswith(("http://", "https://")):
            user_agent = str(headers.pop("User-Agent", "") or "").strip()
            if user_agent:
                cmd += ["-user_agent", user_agent]

            # Do not forward Authorization blindly to the media host.  The
            # Stalker play_token is already the media credential.
            extra = []
            for key in ("X-User-Agent", "Cookie", "Referer"):
                value = str(headers.get(key, "") or "").replace("\r", " ").replace("\n", " ").strip()
                if value:
                    extra.append("%s: %s\r\n" % (key, value))
            if extra:
                cmd += ["-headers", "".join(extra)]

        cmd += [
            "-probesize", "1048576", "-analyzeduration", "1000000",
            "-thread_queue_size", "512", "-i", str(iptv_url),
        ]
        video_input = 0
        audio_input = 1

    cmd += [
        "-map", "%d:v:0" % video_input,
        "-map", "%d:a:0" % audio_input,
    ]

    if mode == "dual":
        cmd += ["-map", "%d:a:0?" % video_input]

    cmd += ["-c:v", "copy"]
    if relay_audio:
        # The persistent upstream relay already encoded IPTV audio as MP2/48k.
        cmd += ["-c:a:0", "copy"]
    else:
        cmd += ["-c:a:0", "mp2", "-b:a:0", "128k", "-ar:a:0", "48000", "-ac:a:0", "2"]
    cmd += [
        "-metadata:s:a:0", "title=IPTV Audio",
        "-disposition:a:0", "default",
    ]

    if mode == "dual":
        cmd += [
            "-c:a:1", "copy",
            "-metadata:s:a:1", "title=Satellite Audio",
            "-disposition:a:1", "0",
        ]

    cmd += [
        "-max_interleave_delta", "100000",
        "-muxdelay", "0", "-muxpreload", "0",
        "-mpegts_flags", "+resend_headers+pat_pmt_at_frames",
        "-f", "mpegts",
        "-listen", "1",
        output_url,
    ]
    return cmd

def _launch_worker(ffmpeg, sat_url, iptv_url, output_url, mode, iptv_headers=None):
    try:
        # Truncate each session's ffmpeg log so diagnosis is concise.
        stderr_fh = open(FFLOG, "w")
        cmd = _ffmpeg_command(ffmpeg, sat_url, iptv_url, output_url, mode, iptv_headers)
        proc = subprocess.Popen(
            cmd,
            stdin=open(os.devnull, "rb"),
            stdout=open(os.devnull, "wb"),
            stderr=stderr_fh,
            close_fds=True,
        )
        with _LOCK:
            if not _STATE.get("armed"):
                _terminate(proc)
                try:
                    stderr_fh.close()
                except Exception:
                    pass
                return
            _STATE["proc"] = proc
            _STATE["stderr"] = stderr_fh
        _log("ffmpeg remux process started (mode=%s)" % mode)
    except Exception as e:
        with _LOCK:
            _STATE["error"] = str(e)
        _log("ffmpeg start error: %s" % e)


def _launch_worker_after_relay(ffmpeg, sat_url, remux_audio_url, output_url, mode, relay,
                               upstream_url, upstream_headers, label, wait_seconds=8.0):
    """Start the main remux first, then activate IPTV audio.

    Lite24 R3 reverses the old race-prone order.  The UDP destination used by
    the main FFmpeg is reserved in advance, FFmpeg is launched and we wait
    until /proc/net/udp proves that it actually bound that port.  Only then do
    we open the Xtream/Stalker provider connection, guaranteeing that the first
    PAT/PMT/audio packets have a receiver.
    """
    try:
        from .audiorelay import (
            activate_relay, restart_relay, relay_alive, relay_ready, relay_error
        )

        ports = list(relay.get("ports") or []) if relay else []
        if not ports:
            raise RuntimeError("IPTV audio relay has no reserved UDP ports")
        audio_port = int(ports[0])

        with _LOCK:
            if not _STATE.get("armed") or _STATE.get("audio_relay") is not relay:
                return
            _STATE["startup_phase"] = "binding_audio_input"
            startup_source = str((_STATE.get("resume_context") or {}).get("source") or "").lower()

        # Xtream preview was just replaced by DVB on the GUI thread. Give the
        # tuner/connection a short background-only settling window; unlike R2
        # this never blocks Enigma2 or leaves a modal black screen.
        if startup_source == "xtream":
            time.sleep(0.30)

        # Launch the same main Local Remux FFmpeg used by the older stable
        # builds.  It opens satellite streamproxy first, then binds the reserved
        # UDP audio input and waits there for IPTV packets.
        _launch_worker(ffmpeg, sat_url, remux_audio_url, output_url, mode, {})

        bind_deadline = time.time() + 3.5
        while time.time() < bind_deadline:
            with _LOCK:
                if not _STATE.get("armed") or _STATE.get("audio_relay") is not relay:
                    return
                proc = _STATE.get("proc")
                state_error = str(_STATE.get("error") or "")
            if state_error:
                raise RuntimeError(state_error)
            if proc is not None:
                try:
                    code = proc.poll()
                except Exception:
                    code = 1
                if code is not None:
                    raise RuntimeError("Local Remux FFmpeg exited before binding IPTV audio input (exit %s)" % code)
            if _udp_port_bound(audio_port):
                break
            time.sleep(0.04)
        else:
            raise RuntimeError("Local IPTV audio UDP input did not bind within 3.5 seconds")

        with _LOCK:
            if not _STATE.get("armed") or _STATE.get("audio_relay") is not relay:
                return
            _STATE["startup_phase"] = "starting_iptv_audio"
        _log("main remux bound UDP audio port %s; activating IPTV provider" % audio_port)

        activate_relay(relay)

        # Normally ready in well under a second.  Give slower portals one clean
        # retry on THE SAME UDP bank, so the already-bound main FFmpeg does not
        # need to be restarted or pointed at a different port.
        for attempt in (1, 2):
            deadline = time.time() + float(wait_seconds or 8.0)
            while time.time() < deadline:
                with _LOCK:
                    if not _STATE.get("armed") or _STATE.get("audio_relay") is not relay:
                        return
                if not relay_alive(relay):
                    break
                if relay_ready(relay):
                    with _LOCK:
                        if _STATE.get("armed") and _STATE.get("audio_relay") is relay:
                            _STATE["startup_phase"] = "starting_remux"
                    _log("IPTV audio reached bound Local Remux input on attempt %s" % attempt)
                    return
                time.sleep(0.05)

            last_error = relay_error(relay) or "IPTV audio produced no packets within %.0f seconds" % float(wait_seconds or 8.0)
            if attempt == 1:
                with _LOCK:
                    if _STATE.get("armed") and _STATE.get("audio_relay") is relay:
                        _STATE["startup_phase"] = "retrying_iptv_audio"
                _log("IPTV audio attempt 1 failed (%s); retrying on the same UDP input" % last_error)
                restart_relay(relay, 0.70)
                continue
            raise RuntimeError(last_error)
    except Exception as e:
        with _LOCK:
            if _STATE.get("armed"):
                _STATE["error"] = "Local Remux startup failed: %s" % str(e)
                _STATE["startup_phase"] = "error"
        _log("deterministic remux startup failed: %s" % e)

def _message(session, text, error=False, timeout=7):
    try:
        from Screens.MessageBox import MessageBox
        session.open(MessageBox, text, MessageBox.TYPE_ERROR if error else MessageBox.TYPE_INFO, timeout=timeout)
    except Exception:
        pass



# R9: lightweight automatic return to live TV after a successful IPTV-only
# remux.  This deliberately does NOT start the old Auto-Timeshift controller.
# It only reproduces the user's proven manual BACK/EXIT sequence while keeping
# the local 4097 service alive.
_UNWIND_TIMER = None
_UNWIND_CONN = None
_UNWIND_STEPS = 0


def _stop_unwind_timer():
    global _UNWIND_TIMER, _UNWIND_CONN, _UNWIND_STEPS
    timer = _UNWIND_TIMER
    _UNWIND_TIMER = None
    _UNWIND_CONN = None
    _UNWIND_STEPS = 0
    if timer:
        try:
            timer.stop()
        except Exception:
            pass


def _schedule_unwind_to_infobar(session, delay_ms=350, start_timeshift=False):
    """Close XKlass/plugin-browser dialogs exactly like manual EXIT.

    The Local Remux is intentionally left armed/running.  No service retune,
    no VIDEO_FREEZE and no Timeshift action happens here.
    """
    global _UNWIND_TIMER, _UNWIND_CONN, _UNWIND_STEPS
    _stop_unwind_timer()
    _UNWIND_STEPS = 0
    timer = eTimer()

    def _step():
        global _UNWIND_STEPS
        _UNWIND_STEPS += 1
        with _LOCK:
            active = bool(_STATE.get("armed") and _STATE.get("played"))
        if not active:
            _stop_unwind_timer()
            return
        try:
            from Screens.InfoBar import InfoBar
            ib = getattr(InfoBar, "instance", None)
        except Exception:
            ib = None
        try:
            dlg = session.current_dialog
        except Exception:
            dlg = None
        if ib is not None and dlg is ib:
            _log("R14 auto-exit reached InfoBar; Local Remux remains active")
            _stop_unwind_timer()
            if start_timeshift:
                try:
                    from .remuxreturn import begin_auto_timeshift
                    ok = bool(begin_auto_timeshift(session, 2))
                    if ok:
                        _log("R14 Auto-Timeshift stable-gate started after clean R9 InfoBar handoff")
                    else:
                        _log("R14 Auto-Timeshift could not start; Local Remux remains running")
                except Exception as e:
                    _log("R14 Auto-Timeshift start exception: %s" % e)
            return

        closeable = False
        module = ""
        name = ""
        try:
            cls = dlg.__class__ if dlg is not None else None
            module = str(getattr(cls, "__module__", "") or "")
            name = str(getattr(cls, "__name__", "") or "")
            closeable = (("Plugins.Extensions.XKlass" in module) or
                         name.startswith("XKlass_") or
                         (module == "Screens.PluginBrowser" and name == "PluginBrowser"))
        except Exception:
            closeable = False

        if closeable and dlg is not None:
            try:
                # Stalker/Xtream channel browsers use back() to stop their own
                # list/background timers.  MainMenu.quit() has an explicit
                # Local-Remux-active guard and therefore will not restore DVB.
                if name == "XKlass_MainMenu" and hasattr(dlg, "quit"):
                    dlg.quit()
                elif ("stalker" in module.lower() or "xtreamlite" in module.lower()) and hasattr(dlg, "back"):
                    dlg.back()
                else:
                    dlg.close()
                _log("R9 auto-exit closed %s.%s" % (module, name))
            except Exception as e:
                _log("R9 auto-exit close failed for %s.%s: %s" % (module, name, e))
        elif _UNWIND_STEPS >= 28:
            _log("R9 auto-exit stopped after 28 steps; foreign dialog=%s.%s" % (module, name))
            _stop_unwind_timer()

    conn = None
    try:
        conn = timer.timeout.connect(_step)
    except Exception:
        timer.callback.append(_step)
    _UNWIND_TIMER = timer
    _UNWIND_CONN = conn
    timer.start(max(100, int(delay_ms or 350)), False)
    _log("R14 auto-exit armed; Local Remux stays running, then stable-gated Timeshift starts at InfoBar")


def _begin_initial_retry(session, exit_code):
    """Automatically reproduce the user's successful second manual attempt.

    The first failed FFmpeg run is torn down without resetting the whole remux
    state.  We retune the original DVB service, wait for streamproxy/tuner to
    settle, optionally resolve a FRESH Stalker URL, choose a fresh local port,
    then launch exactly one silent retry.
    """
    with _LOCK:
        if (not _STATE.get("armed") or _STATE.get("played") or
                _STATE.get("retrying") or
                int(_STATE.get("retry_count") or 0) >= int(_STATE.get("retry_max") or 1)):
            return False
        proc = _STATE.get("proc")
        original_ref = str(_STATE.get("original_ref") or "")
        old_url = str(_STATE.get("iptv_url") or "")
        name = str(_STATE.get("iptv_name") or "IPTV")
        mode = str(_STATE.get("mode") or "iptv")
        headers = dict(_STATE.get("iptv_headers") or {})
        resolver = _STATE.get("retry_resolver")
        _STATE["retry_count"] = int(_STATE.get("retry_count") or 0) + 1
        attempt = int(_STATE.get("retry_count") or 1)
        _STATE["retrying"] = True
        _STATE["proc"] = None
        _STATE["error"] = ""
        _STATE["startup_phase"] = "auto_retry_prepare"
        _STATE["started"] = time.time()

    _log("R9 first FFmpeg startup failed (exit %s); silent auto-retry %s/1" % (exit_code, attempt))
    _terminate(proc)
    _close_fflog()

    # This is the important part observed on the receiver: after the failed
    # first attempt, manual retry succeeds while the real DVB service is back.
    if original_ref and _is_dvb_ref(original_ref):
        try:
            session.nav.playService(eServiceReference(original_ref))
            _log("R9 auto-retry restored DVB service before warm-up")
        except Exception as e:
            _log("R9 auto-retry DVB restore failed: %s" % e)

    def _retry_worker():
        try:
            # Match the successful manual delay: let tuner/streamproxy and the
            # Stalker media token settle before opening both FFmpeg inputs.
            time.sleep(1.10)
            retry_url = old_url
            if callable(resolver):
                _log("R9 auto-retry requesting a fresh IPTV/Stalker URL")
                retry_url = str(resolver() or "").strip()
                if not retry_url:
                    raise RuntimeError("retry resolver returned no IPTV URL")
                # Some Stalker media servers need a short token activation gap.
                time.sleep(0.35)

            with _LOCK:
                if not _STATE.get("armed") or not _STATE.get("retrying"):
                    return
            port = _find_free_port()
            sat_url = _streamproxy_url(original_ref)
            local_url = "http://127.0.0.1:%d/xklass.ts" % port
            ffmpeg = _find_executable("ffmpeg")
            if not ffmpeg:
                raise RuntimeError("ffmpeg is not installed")

            with _LOCK:
                if not _STATE.get("armed") or not _STATE.get("retrying"):
                    return
                _STATE["port"] = port
                _STATE["local_url"] = local_url
                _STATE["local_ref"] = ""
                _STATE["iptv_url"] = retry_url
                _STATE["started"] = time.time()
                _STATE["startup_phase"] = "auto_retry_launch"

            _log("R9 auto-retry launching: port=%s channel=%s" % (port, name))
            _launch_worker(ffmpeg, sat_url, retry_url, local_url, mode, headers)
            with _LOCK:
                if _STATE.get("armed"):
                    _STATE["retrying"] = False
                    _STATE["startup_phase"] = "auto_retry_waiting"
            _log("R9 auto-retry FFmpeg launched; waiting for local service")
        except Exception as e:
            with _LOCK:
                if _STATE.get("armed"):
                    _STATE["retrying"] = False
                    _STATE["error"] = "Automatic remux retry failed: %s" % str(e)
                    _STATE["startup_phase"] = "error"
            _log("R9 auto-retry error: %s" % e)

    t = threading.Thread(target=_retry_worker)
    t.daemon = True
    t.start()
    return True


def _poll_start():
    with _LOCK:
        if not _STATE.get("armed"):
            return
        session = _STATE.get("session")
        proc = _STATE.get("proc")
        port = int(_STATE.get("port") or 0)
        played = bool(_STATE.get("played"))
        started = float(_STATE.get("started") or 0.0)
        error = str(_STATE.get("error") or "")
        local_url = str(_STATE.get("local_url") or "")
        name = str(_STATE.get("iptv_name") or "IPTV")
        mode = str(_STATE.get("mode") or "dual")
        audio_relay = _STATE.get("audio_relay")
        startup_phase = str(_STATE.get("startup_phase") or "")
        retrying = bool(_STATE.get("retrying"))

    # Lite24 R4 startup gate: a reserved relay is intentionally NOT alive yet.
    # R3 could see the local HTTP listener before the background worker had
    # activated the IPTV provider, mark the remux as running, then the next
    # watchdog tick interpreted the still-reserved relay as a dead relay and
    # tore the whole session down.  Do not health-check a relay as "dead"
    # until it has actually produced audio at least once.
    relay_ready_for_play = (audio_relay is None)
    if audio_relay is not None:
        try:
            from .audiorelay import relay_alive, relay_ready, relay_error, LOG as AUDIO_RELAY_LOG
            relay_ready_for_play = bool(relay_ready(audio_relay))
            relay_ever_ready = bool(float(audio_relay.get("ready_at") or 0.0))
            if relay_ever_ready and not relay_alive(audio_relay):
                relay_msg = relay_error(audio_relay) or "IPTV audio relay stopped"
                stop_local_remux(restore=True)
                _message(session, "%s\n\nSatellite service was restored.\nSee %s" % (relay_msg, AUDIO_RELAY_LOG), True, 9)
                return
            # Before first readiness, the background startup worker owns the
            # timeout/retry path.  The GUI watchdog must not cancel it.
        except Exception as e:
            relay_ready_for_play = False
            _log("audio relay health check failed: %s" % e)

    if retrying:
        return

    if error:
        stop_local_remux(restore=True)
        _message(session, "Local Remux failed:\n%s\n\nSatellite service was restored.\nSee %s" % (error, FFLOG), True, 9)
        return

    if proc is not None:
        try:
            code = proc.poll()
        except Exception:
            code = 1
        if code is not None and not played:
            if _begin_initial_retry(session, code):
                return
            stop_local_remux(restore=True)
            _message(session, "FFmpeg could not create the local remux stream after automatic retry (exit %s).\nSatellite service was restored.\nSee %s" % (code, FFLOG), True, 8)
            return
        if code is not None and played:
            stop_local_remux(restore=True)
            _message(session, "Local Remux stopped unexpectedly (FFmpeg exit %s). Satellite service was restored.\nSee %s" % (code, FFLOG), True, 8)
            return

    # R4: the HTTP listener alone is not sufficient. FFmpeg can open its
    # output socket while the IPTV relay is still only reserved.  Start the
    # Enigma2 4097/5002 service only after the relay has emitted real audio
    # packets; this closes the R3 race which produced Error (8).
    if not played and proc is not None and port and relay_ready_for_play and _port_listening(port):
        try:
            # R20: Vu+ 4K receivers prefer ExtePlayer3 for the completed
            # local A/V service when it is installed. The remux already combines
            # satellite video + IPTV audio, so one player can safely own both
            # hardware decoders without relying on broken independent ALSA PCM.
            try:
                from .receivercompat import preferred_local_service_type
                primary_type = int(preferred_local_service_type())
            except Exception:
                primary_type = 4097
            fallback_type = 4097 if primary_type == 5002 else 5002
            ref = eServiceReference(primary_type, 0, local_url)
            ref.setName("SAT + %s" % name)
            result = session.nav.playService(ref)
            if result is False and (fallback_type != 5002 or os.path.exists("/usr/bin/exteplayer3")):
                ref = eServiceReference(fallback_type, 0, local_url)
                ref.setName("SAT + %s" % name)
                session.nav.playService(ref)
            with _LOCK:
                _STATE["played"] = True
                _STATE["startup_phase"] = "running"
                _STATE["local_ref"] = str(ref.toString())
                resume_after_play = bool(_STATE.get("resume_after_play"))
                _STATE["resume_after_play"] = False
            if resume_after_play:
                try:
                    _video_ioctl(VIDEO_CONTINUE)
                    with _LOCK:
                        _STATE["video_hold"] = False
                        _STATE["video_hold_started"] = 0.0
                    _log("video decoder continued after Local Remux handover")
                except Exception:
                    pass
            _log("local remux service started: %s" % local_url)
            with _LOCK:
                watchdog = _STATE.get("timer")
            if watchdog:
                try:
                    watchdog.start(1000, False)
                except Exception:
                    pass
            if mode == "iptv":
                # R10 deliberately preserves the exact R9 startup/auto-exit that
                # was proven on the receiver.  Only after InfoBar is reached do
                # we start the HDD satellite buffer and the single deferred
                # VIDEO_FREEZE managed by remuxreturn.py.
                _log("R14 REMUX running; scheduling stable-gated Timeshift only after InfoBar")
                _schedule_unwind_to_infobar(session, 350, True)
            else:
                msg = ("Local Remux is running.\n\nVideo: satellite (copy)\n"
                       "Audio 1/default: IPTV\nAudio 2: satellite\n\n"
                       "Press AUDIO to try switching between the two tracks.")
                _message(session, msg, False, 7)
        except Exception as e:
            stop_local_remux(restore=True)
            _message(session, "Unable to play the local remux service:\n%s" % e, True, 8)
        return

    if not played and started and (time.time() - started) > 30.0:
        with _LOCK:
            phase = str(_STATE.get("startup_phase") or "starting")
        stop_local_remux(restore=True)
        _message(session,
                 "Local Remux startup timed out (%s).\n"
                 "IPTV audio or the satellite stream did not become ready in time.\n"
                 "Satellite service was restored.\nSee %s" % (phase, FFLOG),
                 True, 10)


def start_local_remux(session, iptv_url, iptv_name="IPTV", mode="dual", iptv_headers=None, resume_context=None, retry_resolver=None):
    """Start the proven direct Local Remux path.

    Lite24 R6 removes the persistent audio relay from INITIAL startup. The
    first Local Remux uses the older direct satellite + IPTV topology. The
    persistent relay is created only once, on the first delayed-video OK
    handover, where it is needed for repeated video-only sync adjustments.
    """
    iptv_url = str(iptv_url or "").strip()
    if not iptv_url:
        raise RuntimeError("No IPTV stream URL")
    if mode not in ("dual", "iptv"):
        mode = "dual"

    ffmpeg = _find_executable("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg is not installed")

    sat_ref = _pick_satellite_ref(session)
    if not sat_ref:
        raise RuntimeError("No original DVB satellite service found. Tune a satellite channel before opening XKlass.")

    try:
        from .backgroundaudio import stop_background_audio
        stop_background_audio()
    except Exception:
        pass

    # R11 session boundary.  R10 used restore=False here.  That is unsafe after
    # delayed-video playback because Enigma2 can remain tuned to the old 4097
    # localhost service after its ffmpeg/tail processes are killed.  The next
    # run then starts from a dead service and can show a black frame with a live
    # Timeshift overlay.  Remember whether a previous pipeline existed, then
    # tear it down while restoring the real DVB service.
    with _LOCK:
        had_prior_pipeline = bool(
            _STATE.get("armed") or _STATE.get("proc") is not None or
            _STATE.get("timeshift_recording") or _STATE.get("timeshift_playback") or
            _STATE.get("timeshift_recorder") is not None or
            _STATE.get("timeshift_video_proc") is not None
        )
    stop_local_remux(restore=True)

    # Always make the satellite service the decoder/tuner owner before a fresh
    # Local Remux.  This is intentionally event-based and happens only once at
    # a new session boundary.
    try:
        current_ref = _service_string(session)
        if current_ref != sat_ref:
            session.nav.playService(eServiceReference(sat_ref))
            _log("R14 session reset tuned original DVB service before new remux")
        else:
            _log("R14 session reset confirmed original DVB service is already active")
    except Exception as e:
        _log("R14 DVB session reset tune failed: %s" % e)

    port = _find_free_port()
    sat_url = _streamproxy_url(sat_ref)
    local_url = "http://127.0.0.1:%d/xklass.ts" % port
    _log("R14 REMUX: satellite source=%s, local=%s, mode=%s" % (sat_url, local_url, mode))
    _log("R14 REMUX: R9 startup preserved; raw recorder + stable-gated Auto-Timeshift")

    with _LOCK:
        _STATE.update({
            "session": session,
            "proc": None,
            "timer": None,
            "original_ref": sat_ref,
            "local_ref": "",
            "local_url": local_url,
            "iptv_name": str(iptv_name or "IPTV"),
            "mode": mode,
            "port": port,
            "started": time.time(),
            "armed": True,
            "played": False,
            "error": "",
            "stderr": None,
            "iptv_headers": dict(iptv_headers or {}),
            "iptv_url": iptv_url,
            "resume_context": dict(resume_context or {}),
            "video_hold": False,
            "video_hold_started": 0.0,
            "video_hold_min": 2.0,
            "audio_relay": None,
            "audio_slot": 0,
            "startup_phase": "direct_stable",
            "retry_count": 0,
            "retry_max": 1,
            "retrying": False,
            "retry_resolver": retry_resolver,
            # Every new R11 session starts with no inherited Timeshift state.
            "timeshift_recorder": None,
            "timeshift_recorder_log": None,
            "timeshift_tail": None,
            "timeshift_file": "",
            "timeshift_started": 0.0,
            "timeshift_recording": False,
            "timeshift_playback": False,
            "timeshift_delay": 0.0,
            "timeshift_last_size": 0,
            "timeshift_last_growth": 0.0,
            "timeshift_last_restart": 0.0,
            "timeshift_signal_lost": False,
            "timeshift_rate_bps": 0.0,
            "timeshift_sample_time": 0.0,
            "timeshift_video_proc": None,
            "timeshift_video_log": None,
            "timeshift_video_port": 0,
            "timeshift_video_generation": 0,
            "timeshift_video_clock_started": 0.0,
        })

    _log("arming direct local remux: mode=%s, port=%s, channel=%s" % (
        mode, port, str(iptv_name or "IPTV")))

    def _direct_worker():
        try:
            source = str((resume_context or {}).get("source") or "").lower()
            if had_prior_pipeline:
                # The previous 4097/timeshift chain has just been torn down and
                # the tuner was returned to DVB.  Give streamproxy/decoder a real
                # settle window before ffmpeg opens the satellite input again.
                time.sleep(1.35)
                _log("R14 post-timeshift session reset warm-up complete")
            elif source == "xtream":
                time.sleep(0.30)
            elif source == "stalker":
                # Fresh create_link tokens on this receiver/provider can race
                # the media server.  A short activation gap reduces the first
                # attempt failure; the automatic retry remains the fallback.
                time.sleep(0.55)
        except Exception:
            pass
        _launch_worker(ffmpeg, sat_url, iptv_url, local_url, mode, dict(iptv_headers or {}))

    worker = threading.Thread(target=_direct_worker)
    worker.daemon = True
    worker.start()

    timer = eTimer()
    conn = None
    try:
        conn = timer.timeout.connect(_poll_start)
    except Exception:
        timer.callback.append(_poll_start)
    with _LOCK:
        _STATE["timer"] = timer
        _STATE["timer_conn"] = conn
    timer.start(150, False)
    return True


def stop_local_remux(restore=True):
    # R11: cancel the R9/R10 dialog-unwind timer FIRST.  An old timer callback
    # must never observe a newly armed _STATE and start Auto-Timeshift for the
    # wrong session.
    try:
        _stop_unwind_timer()
    except Exception:
        pass

    # R7: stop the singleton auto-timeshift controller FIRST. Otherwise its
    # 250ms watchdog/ActionMaps can briefly survive the old remux teardown and
    # touch the state of a newly started session (especially on a second test).
    try:
        from .remuxreturn import stop_auto_timeshift
        stop_auto_timeshift()
    except Exception:
        pass

    # Cancel any replacement remux that is still being prepared.
    try:
        _cancel_handover(True)
    except Exception:
        pass
    # Never leave the decoder frozen when the remux is stopped.
    try:
        resume_remux_video(force=True)
    except Exception:
        pass
    with _LOCK:
        had_state = bool(_STATE.get("armed")) or (_STATE.get("proc") is not None)
        session = _STATE.get("session")
        original_ref = str(_STATE.get("original_ref") or "")
        proc = _STATE.get("proc")
        ts_recorder = _STATE.get("timeshift_recorder")
        ts_tail = _STATE.get("timeshift_tail")
        ts_file = str(_STATE.get("timeshift_file") or "")
        ts_log = _STATE.get("timeshift_recorder_log")
        audio_relay = _STATE.get("audio_relay")
        ts_video_proc = _STATE.get("timeshift_video_proc")
        ts_video_log = _STATE.get("timeshift_video_log")
        _STATE["armed"] = False
        _STATE["proc"] = None
        _STATE["timeshift_recorder"] = None
        _STATE["timeshift_tail"] = None
        _STATE["timeshift_video_proc"] = None
        _STATE["timeshift_video_log"] = None
        _STATE["timeshift_video_port"] = 0
        _STATE["timeshift_recorder_log"] = None

    _stop_timer()

    # Retune before killing ffmpeg so streamproxy can hand the same tuner/service
    # cleanly back to Enigma2 on single-tuner boxes.
    if restore and session and original_ref and _is_dvb_ref(original_ref):
        try:
            session.nav.playService(eServiceReference(original_ref))
            _log("restored original DVB service")
        except Exception as e:
            _log("restore DVB service failed: %s" % e)

    _terminate(proc)
    _terminate(ts_video_proc)
    _terminate(ts_tail)
    _terminate(ts_recorder)
    try:
        from .audiorelay import stop_relay
        stop_relay(audio_relay)
    except Exception as e:
        _log("audio relay stop failed: %s" % e)
    if ts_video_log:
        try:
            ts_video_log.close()
        except Exception:
            pass
    if ts_log:
        try:
            ts_log.close()
        except Exception:
            pass
    if ts_file:
        try:
            if os.path.exists(ts_file):
                os.remove(ts_file)
        except Exception:
            pass
    _close_fflog()
    _reset_state(False)
    if had_state:
        _log("local remux stopped")
    return had_state



# ---------------------------------------------------------------------------
# Lite18 smart-return context + independent satellite-video timeshift
# ---------------------------------------------------------------------------
# Linux DVB video ioctls from <linux/dvb/video.h>.  VIDEO_FREEZE freezes only
# the hardware video decoder; audio keeps running.  This is intentionally used
# instead of native Enigma2 timeshift for the exit hold: timeshifting/pausing the
# local remux service would pause the working IPTV audio as well.
VIDEO_FREEZE = 0x6F17
VIDEO_CONTINUE = 0x6F18


def get_resume_context():
    """Return the in-memory channel-list context for the active remux."""
    with _LOCK:
        if not _STATE.get("armed"):
            return {}
        context = _STATE.get("resume_context") or {}
        try:
            result = dict(context)
            if isinstance(context.get("channels"), list):
                result["channels"] = list(context.get("channels") or [])
            return result
        except Exception:
            return {}


def get_active_iptv_source():
    """Return the active upstream IPTV metadata without opening a new connection."""
    with _LOCK:
        return {
            "url": str(_STATE.get("iptv_url") or ""),
            "name": str(_STATE.get("iptv_name") or "IPTV"),
            "mode": str(_STATE.get("mode") or "iptv"),
            "headers": dict(_STATE.get("iptv_headers") or {}),
            "context": dict(_STATE.get("resume_context") or {}),
            "relay": _STATE.get("audio_relay"),
            "audio_slot": int(_STATE.get("audio_slot") or 0),
        }


def update_resume_context(**values):
    with _LOCK:
        context = dict(_STATE.get("resume_context") or {})
        context.update(values)
        _STATE["resume_context"] = context
    return context


def is_local_remux_active():
    with _LOCK:
        proc = _STATE.get("proc")
        armed = bool(_STATE.get("armed"))
        played = bool(_STATE.get("played"))
    if not armed or not played or proc is None:
        return False
    try:
        return proc.poll() is None
    except Exception:
        return False


def _dvb_video_devices():
    devices = []
    for pattern in ("/dev/dvb/adapter*/video*", "/dev/dvb/card*/video*"):
        try:
            for path in sorted(glob_module.glob(pattern)):
                if os.path.exists(path) and path not in devices:
                    devices.append(path)
        except Exception:
            pass
    return devices


def _video_ioctl(request):
    success = False
    for path in _dvb_video_devices():
        fd = None
        try:
            fd = os.open(path, os.O_RDWR | getattr(os, "O_NONBLOCK", 0))
            fcntl.ioctl(fd, request)
            success = True
        except Exception as e:
            _log("DVB video ioctl failed %s 0x%x: %s" % (path, int(request), e))
        finally:
            if fd is not None:
                try:
                    os.close(fd)
                except Exception:
                    pass
    return success


def freeze_remux_video(min_seconds=2):
    """Freeze only the video decoder while the IPTV audio keeps playing."""
    if not is_local_remux_active():
        return False
    try:
        minimum = max(0.5, float(min_seconds))
    except Exception:
        minimum = 2.0
    success = _video_ioctl(VIDEO_FREEZE)
    with _LOCK:
        _STATE["video_hold"] = bool(success)
        _STATE["video_hold_started"] = time.time() if success else 0.0
        _STATE["video_hold_min"] = minimum
    if success:
        _log("local remux VIDEO_FREEZE armed; IPTV audio continues")
    return success


def resume_remux_video(force=False):
    with _LOCK:
        held = bool(_STATE.get("video_hold"))
        started = float(_STATE.get("video_hold_started") or 0.0)
        minimum = float(_STATE.get("video_hold_min") or 0.0)
    if not held:
        return True
    if not force and started and (time.time() - started) < minimum:
        return False
    success = _video_ioctl(VIDEO_CONTINUE)
    if success:
        with _LOCK:
            _STATE["video_hold"] = False
            _STATE["video_hold_started"] = 0.0
        _log("local remux VIDEO_CONTINUE")
    return success


def video_hold_status():
    with _LOCK:
        return bool(_STATE.get("video_hold")), float(_STATE.get("video_hold_started") or 0.0), float(_STATE.get("video_hold_min") or 0.0)

def local_remux_status():
    with _LOCK:
        proc = _STATE.get("proc")
        armed = bool(_STATE.get("armed"))
        played = bool(_STATE.get("played"))
        name = str(_STATE.get("iptv_name") or "")
        mode = str(_STATE.get("mode") or "")
        port = int(_STATE.get("port") or 0)
        error = str(_STATE.get("error") or "")
    alive = False
    if proc:
        try:
            alive = proc.poll() is None
        except Exception:
            pass
    if armed and (alive or not error):
        state = "playing" if played else "starting"
        tracks = "IPTV + Satellite audio tracks" if mode == "dual" else "IPTV audio only"
        return True, name, "%s | %s | port %s" % (state, tracks, port)
    return False, name, error


# ---------------------------------------------------------------------------
# Lite18: seamless audio-source handover + adjustable satellite VIDEO buffer
# ---------------------------------------------------------------------------
TIMESHIFT_LOG = "/tmp/xklass-timeshift.log"
TIMESHIFT_FFLOG = "/tmp/xklass-timeshift-ffmpeg.log"
TIMESHIFT_VIDEO_LOG = "/tmp/xklass-timeshift-video.log"
_VIDEO_UDP_CURSOR = 19100

_HANDOVER = {
    "active": False,
    "done": False,
    "error": "",
    "session": None,
    "proc": None,
    "stderr": None,
    "tail": None,
    "timer": None,
    "timer_conn": None,
    "port": 0,
    "local_url": "",
    "name": "",
    "mode": "iptv",
    "headers": {},
    "context": {},
    "iptv_url": "",
    "satellite_source": "live",
    "target_delay": None,
    "started": 0.0,
    "generation": 0,
    "candidate_relay": None,
    "audio_slot": 0,
    "remux_audio_url": "",
    "video_feeder": None,
    "video_log": None,
    "video_port": 0,
    "video_clock_started": 0.0,
}


def _tslog(msg):
    try:
        with open(TIMESHIFT_LOG, "a") as f:
            f.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), str(msg)))
    except Exception:
        pass


def _find_free_video_udp_port():
    """Allocate a local UDP receiver port used only by the satellite-video feeder."""
    global _VIDEO_UDP_CURSOR
    start = int(_VIDEO_UDP_CURSOR or 19100)
    candidates = list(range(start, 19280)) + list(range(19100, start))
    for port in candidates:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.bind(("127.0.0.1", int(port)))
            _VIDEO_UDP_CURSOR = 19100 if port >= 19279 else port + 1
            return int(port)
        except Exception:
            pass
        finally:
            try:
                sock.close()
            except Exception:
                pass
    raise RuntimeError("No free local UDP port for satellite timeshift video")


def _timeshift_seek_point(ts_file, target_delay, ts_started, ts_rate_bps):
    """Return (tail_start_1_based, effective_delay, rate_bps)."""
    size_now = int(os.path.getsize(ts_file))
    elapsed_now = max(0.25, time.time() - float(ts_started or 0.0))
    rate = float(ts_rate_bps or 0.0)
    if rate < 10000.0:
        rate = float(size_now) / elapsed_now if size_now > 0 else 0.0
    if rate < 10000.0:
        raise RuntimeError("Satellite timeshift bitrate is not ready yet")

    available = max(0.0, float(size_now) / rate)
    if target_delay is None:
        # Initial OK starts at the beginning of the current buffer.
        target = max(0.5, available)
        start_zero = 0
    else:
        upper = max(0.5, available - 0.20)
        target = max(0.5, min(float(target_delay), upper))
        wanted_back = int(rate * target)
        start_zero = max(0, size_now - wanted_back)
        start_zero -= (start_zero % 188)
    return int(start_zero) + 1, float(target), float(rate)


def _spawn_timeshift_video_feeder(ffmpeg, ts_file, target_delay, ts_started, ts_rate_bps, udp_port, truncate_log=False, clock_offset=0.0):
    """Feed only delayed satellite video to a fixed local UDP input.

    Lite24 keeps the main Local Remux/Enigma service alive.  Delay changes only
    replace this small video feeder, so IPTV audio and the HTTP Local Remux are
    never restarted on LEFT/RIGHT/number-key sync adjustments.
    """
    tail = _find_executable("tail")
    python_bin = _find_python_executable()
    if not tail and not python_bin:
        raise RuntimeError("No tail/Python file follower is installed for timeshift playback")
    if not ts_file or not os.path.exists(ts_file):
        raise RuntimeError("Timeshift buffer file is missing")

    tail_start, effective_delay, rate = _timeshift_seek_point(ts_file, target_delay, ts_started, ts_rate_bps)
    if truncate_log:
        try:
            open(TIMESHIFT_VIDEO_LOG, "w").close()
        except Exception:
            pass
    logfh = open(TIMESHIFT_VIDEO_LOG, "a")
    tail_proc = None
    video_proc = None
    try:
        if tail:
            follower_cmd = [tail, "-c", "+%d" % int(tail_start), "-f", ts_file]
            follower_backend = "tail -f"
        else:
            follower_cmd = [python_bin, "-u", "-c", _PY_FILE_FOLLOWER, ts_file, str(int(tail_start))]
            follower_backend = "python file follower"
        null_in = open(os.devnull, "rb")
        null_err = open(os.devnull, "wb")
        tail_proc = subprocess.Popen(
            follower_cmd,
            stdin=null_in,
            stdout=subprocess.PIPE,
            stderr=null_err,
            close_fds=True,
        )
        try:
            null_in.close()
            null_err.close()
        except Exception:
            pass
        _tslog("R14 delayed-video follower backend: %s" % follower_backend)
        cmd = [
            ffmpeg,
            "-nostdin", "-hide_banner", "-loglevel", "error",
            "-re", "-fflags", "+genpts+discardcorrupt",
            "-probesize", "2097152", "-analyzeduration", "1000000",
            "-i", "pipe:0",
            "-map", "0:v:0", "-an", "-sn", "-dn",
            "-c:v", "copy",
            "-muxdelay", "0", "-muxpreload", "0",
            "-mpegts_flags", "+resend_headers",
            # Keep the feeder on one monotonically increasing timestamp line.
            # Without this, every LEFT/RIGHT adjustment starts video again near
            # PTS=0 while the IPTV audio clock is already far ahead; FFmpeg then
            # waits on interleaving and both sound and picture appear frozen.
            "-output_ts_offset", "%.3f" % max(0.0, float(clock_offset or 0.0)),
            "-f", "mpegts",
            "udp://127.0.0.1:%d?pkt_size=1316" % int(udp_port),
        ]
        video_proc = subprocess.Popen(
            cmd,
            stdin=tail_proc.stdout,
            stdout=open(os.devnull, "wb"),
            stderr=logfh,
            close_fds=True,
        )
        try:
            tail_proc.stdout.close()
        except Exception:
            pass
        time.sleep(0.08)
        code = video_proc.poll()
        if code is not None:
            raise RuntimeError("Satellite video feeder FFmpeg exit %s" % code)
        _tslog("video feeder started delay=%.1fs byte=%d udp=%d rate=%.0fB/s" % (
            effective_delay, tail_start, int(udp_port), rate))
        return tail_proc, video_proc, logfh, effective_delay
    except Exception:
        _terminate(video_proc)
        _terminate(tail_proc)
        try:
            logfh.close()
        except Exception:
            pass
        raise


def _handover_clear(kill_processes=True):
    with _LOCK:
        timer = _HANDOVER.get("timer")
        proc = _HANDOVER.get("proc")
        tail = _HANDOVER.get("tail")
        stderr = _HANDOVER.get("stderr")
        candidate_relay = _HANDOVER.get("candidate_relay")
        video_feeder = _HANDOVER.get("video_feeder")
        video_log = _HANDOVER.get("video_log")
        generation = int(_HANDOVER.get("generation") or 0)
        _HANDOVER.update({
            "active": False, "done": False, "error": "", "session": None,
            "proc": None, "stderr": None, "tail": None, "timer": None,
            "timer_conn": None, "port": 0, "local_url": "", "name": "",
            "mode": "iptv", "headers": {}, "context": {}, "iptv_url": "",
            "satellite_source": "live", "target_delay": None, "started": 0.0,
            "generation": generation, "candidate_relay": None,
            "audio_slot": 0, "remux_audio_url": "",
            "video_feeder": None, "video_log": None, "video_port": 0,
            "video_clock_started": 0.0,
        })
    if timer:
        try:
            timer.stop()
        except Exception:
            pass
    if kill_processes:
        _terminate(proc)
        _terminate(video_feeder)
        _terminate(tail)
        if candidate_relay is not None:
            try:
                from .audiorelay import stop_relay
                stop_relay(candidate_relay)
            except Exception:
                pass
    if stderr:
        try:
            stderr.close()
        except Exception:
            pass
    if video_log:
        try:
            video_log.close()
        except Exception:
            pass


def _cancel_handover(kill_processes=True):
    try:
        _handover_clear(kill_processes)
    except Exception:
        pass


def _handover_worker(ffmpeg, sat_url, iptv_url, output_url, mode, headers, satellite_source, ts_file, target_delay=None, ts_started=0.0, ts_rate_bps=0.0, generation=0, candidate_relay=None):
    stderr_fh = None
    tail_proc = None
    video_feeder = None
    video_log = None
    proc = None
    try:
        stderr_fh = open(TIMESHIFT_FFLOG if satellite_source == "timeshift" else FFLOG, "a")
        main_sat_url = sat_url
        effective_delay = target_delay
        video_port = 0

        video_clock_started = 0.0
        if satellite_source == "timeshift":
            video_clock_started = time.time()
            video_port = _find_free_video_udp_port()
            tail_proc, video_feeder, video_log, effective_delay = _spawn_timeshift_video_feeder(
                ffmpeg, ts_file, target_delay, ts_started, ts_rate_bps,
                video_port, truncate_log=True, clock_offset=0.0
            )
            main_sat_url = "udp://127.0.0.1:%d" % int(video_port)

        cmd = _ffmpeg_command(
            ffmpeg, main_sat_url, iptv_url, output_url, mode,
            dict(headers or {}), sat_pipe=False
        )
        proc = subprocess.Popen(
            cmd,
            stdin=open(os.devnull, "rb"),
            stdout=open(os.devnull, "wb"),
            stderr=stderr_fh,
            close_fds=True,
        )

        if candidate_relay is not None and not candidate_relay.get("activated"):
            from .audiorelay import activate_relay, relay_ready, relay_alive, relay_error, stop_relay
            ports = list(candidate_relay.get("ports") or [])
            if not ports:
                raise RuntimeError("Candidate IPTV audio relay has no UDP ports")
            audio_port = int(ports[0])
            deadline = time.time() + 4.0
            while time.time() < deadline:
                with _LOCK:
                    if (not _HANDOVER.get("active") or
                            int(_HANDOVER.get("generation") or 0) != int(generation or 0)):
                        return
                code = proc.poll()
                if code is not None:
                    raise RuntimeError("Replacement Local Remux exited before binding audio (exit %s)" % code)
                if _udp_port_bound(audio_port):
                    break
                time.sleep(0.04)
            else:
                raise RuntimeError("Replacement Local Remux did not bind IPTV audio UDP within 4 seconds")

            activate_relay(candidate_relay)
            deadline = time.time() + 8.0
            while time.time() < deadline:
                with _LOCK:
                    if (not _HANDOVER.get("active") or
                            int(_HANDOVER.get("generation") or 0) != int(generation or 0)):
                        return
                if relay_ready(candidate_relay):
                    break
                if not relay_alive(candidate_relay):
                    raise RuntimeError(relay_error(candidate_relay) or "IPTV audio relay stopped during handover")
                time.sleep(0.05)
            else:
                raise RuntimeError(relay_error(candidate_relay) or "IPTV audio relay produced no packets within 8 seconds")
            _tslog("first delayed-video handover audio relay ready on UDP %s" % audio_port)

        with _LOCK:
            if (not _HANDOVER.get("active") or
                    int(_HANDOVER.get("generation") or 0) != int(generation or 0)):
                _terminate(proc)
                _terminate(video_feeder)
                _terminate(tail_proc)
                try:
                    stderr_fh.close()
                except Exception:
                    pass
                if video_log:
                    try:
                        video_log.close()
                    except Exception:
                        pass
                return
            _HANDOVER["proc"] = proc
            _HANDOVER["tail"] = tail_proc
            _HANDOVER["stderr"] = stderr_fh
            _HANDOVER["video_feeder"] = video_feeder
            _HANDOVER["video_log"] = video_log
            _HANDOVER["video_port"] = int(video_port or 0)
            _HANDOVER["video_clock_started"] = float(video_clock_started or 0.0)
            if satellite_source == "timeshift":
                _HANDOVER["target_delay"] = float(effective_delay or 0.5)
        _tslog("handover ffmpeg started source=%s dynamic_video_port=%s" % (satellite_source, video_port))
    except Exception as e:
        _terminate(proc)
        _terminate(video_feeder)
        _terminate(tail_proc)
        if candidate_relay is not None:
            try:
                from .audiorelay import stop_relay
                stop_relay(candidate_relay)
            except Exception:
                pass
        if stderr_fh:
            try:
                stderr_fh.close()
            except Exception:
                pass
        if video_log:
            try:
                video_log.close()
            except Exception:
                pass
        with _LOCK:
            if int(_HANDOVER.get("generation") or 0) == int(generation or 0):
                _HANDOVER["error"] = str(e)
        _tslog("handover start failed gen=%s: %s" % (generation, e))


def handover_local_remux(session, iptv_url, iptv_name="IPTV", mode=None,
                         iptv_headers=None, resume_context=None,
                         satellite_source="live", target_delay=None):
    """Prepare a new remux while the old one keeps playing, then atomically zap.

    This fixes Smart Return channel changes: the old local service is not killed
    until the replacement HTTP MPEG-TS is already listening.  It is also the
    mechanism used to resume a paused satellite-video timeshift buffer.
    """
    iptv_url = str(iptv_url or "").strip()
    if not iptv_url:
        raise RuntimeError("No IPTV stream URL")
    if satellite_source not in ("live", "timeshift"):
        satellite_source = "live"

    with _LOCK:
        active = bool(_STATE.get("armed")) and bool(_STATE.get("played")) and _STATE.get("proc") is not None
        original_ref = str(_STATE.get("original_ref") or "")
        current_mode = str(_STATE.get("mode") or "iptv")
        ts_file = str(_STATE.get("timeshift_file") or "")
        ts_started = float(_STATE.get("timeshift_started") or 0.0)
        ts_recording = bool(_STATE.get("timeshift_recording"))
        ts_rate_bps = float(_STATE.get("timeshift_rate_bps") or 0.0)
        active_relay = _STATE.get("audio_relay")
        current_audio_slot = int(_STATE.get("audio_slot") or 0)
        current_upstream_url = str(_STATE.get("iptv_url") or "")
        current_upstream_headers = dict(_STATE.get("iptv_headers") or {})
    if not active:
        return start_local_remux(session, iptv_url, iptv_name, mode or current_mode,
                                 iptv_headers=iptv_headers, resume_context=resume_context)
    if not original_ref or not _is_dvb_ref(original_ref):
        raise RuntimeError("Original satellite service is unavailable")
    if satellite_source == "timeshift" and (not ts_recording or not ts_file or not os.path.exists(ts_file)):
        raise RuntimeError("No satellite-video timeshift buffer is recording")

    if satellite_source != "timeshift":
        target_delay = None
    elif target_delay is not None:
        try:
            elapsed_now = max(0.0, time.time() - float(ts_started or 0.0))
            if ts_rate_bps > 10000.0 and ts_file and os.path.exists(ts_file):
                try:
                    elapsed_now = max(0.0, float(os.path.getsize(ts_file)) / ts_rate_bps)
                except Exception:
                    pass
            upper = max(0.5, elapsed_now - 0.25)
            target_delay = max(0.5, min(float(target_delay), upper))
        except Exception:
            target_delay = None

    ffmpeg = _find_executable("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg is not installed")
    if mode not in ("dual", "iptv"):
        mode = current_mode if current_mode in ("dual", "iptv") else "iptv"

    # R6: initial playback has no relay. On the first delayed-video handover
    # create one persistent relay; after that, repeated video-delay adjustments
    # reuse it and never reopen the provider.
    candidate_relay = None
    remux_audio_url = ""
    audio_slot = 0
    upstream_url = str(iptv_url or current_upstream_url)
    upstream_headers = dict(iptv_headers or {})
    try:
        from .audiorelay import reserve_relay, relay_input_url, relay_alive
        same_source = bool(current_upstream_url and upstream_url == current_upstream_url)
        reuse_active = bool(active_relay is not None and relay_alive(active_relay)
                            and (satellite_source == "timeshift" or same_source))
        if reuse_active:
            ports = list(active_relay.get("ports") or [])
            if not ports:
                raise RuntimeError("Persistent IPTV audio relay has no local ports")
            audio_slot = (int(current_audio_slot) + 1) % len(ports)
            remux_audio_url, audio_slot = relay_input_url(active_relay, audio_slot)
            upstream_url = current_upstream_url
            upstream_headers = current_upstream_headers
        else:
            candidate_relay = reserve_relay(
                upstream_url, upstream_headers, str(iptv_name or "IPTV"),
                truncate_log=False
            )
            remux_audio_url, audio_slot = relay_input_url(candidate_relay, 0)
        if not remux_audio_url:
            raise RuntimeError("No local IPTV audio relay input was allocated")
    except Exception:
        if candidate_relay is not None:
            try:
                from .audiorelay import stop_relay
                stop_relay(candidate_relay)
            except Exception:
                pass
        raise

    _cancel_handover(True)
    with _LOCK:
        generation = int(_HANDOVER.get("generation") or 0) + 1
        _HANDOVER["generation"] = generation
    port = _find_free_port()
    local_url = "http://127.0.0.1:%d/xklass.ts" % port
    sat_url = _streamproxy_url(original_ref) if satellite_source == "live" else "pipe:0"
    with _LOCK:
        _HANDOVER.update({
            "active": True, "done": False, "error": "", "session": session,
            "proc": None, "stderr": None, "tail": None, "timer": None,
            "timer_conn": None, "port": port, "local_url": local_url,
            "name": str(iptv_name or "IPTV"), "mode": mode,
            "headers": dict(upstream_headers or {}), "context": dict(resume_context or {}),
            "iptv_url": upstream_url, "satellite_source": satellite_source,
            "target_delay": target_delay, "started": time.time(),
            "generation": generation, "candidate_relay": candidate_relay,
            "audio_slot": int(audio_slot), "remux_audio_url": remux_audio_url,
            "video_feeder": None, "video_log": None, "video_port": 0,
        })

    worker = threading.Thread(
        target=_handover_worker,
        args=(ffmpeg, sat_url, remux_audio_url, local_url, mode,
              {}, satellite_source, ts_file, target_delay, ts_started, ts_rate_bps, generation, candidate_relay)
    )
    worker.daemon = True
    worker.start()

    timer = eTimer()
    conn = None
    try:
        conn = timer.timeout.connect(_poll_handover)
    except Exception:
        timer.callback.append(_poll_handover)
    with _LOCK:
        _HANDOVER["timer"] = timer
        _HANDOVER["timer_conn"] = conn
    timer.start(120, False)
    _tslog("handover armed gen=%s source=%s port=%s channel=%s" % (generation, satellite_source, port, str(iptv_name or "IPTV")))
    return True


def _poll_handover():
    with _LOCK:
        if not _HANDOVER.get("active"):
            return
        session = _HANDOVER.get("session")
        proc = _HANDOVER.get("proc")
        tail = _HANDOVER.get("tail")
        stderr = _HANDOVER.get("stderr")
        port = int(_HANDOVER.get("port") or 0)
        local_url = str(_HANDOVER.get("local_url") or "")
        name = str(_HANDOVER.get("name") or "IPTV")
        mode = str(_HANDOVER.get("mode") or "iptv")
        headers = dict(_HANDOVER.get("headers") or {})
        context = dict(_HANDOVER.get("context") or {})
        iptv_url = str(_HANDOVER.get("iptv_url") or "")
        satellite_source = str(_HANDOVER.get("satellite_source") or "live")
        target_delay = _HANDOVER.get("target_delay")
        started = float(_HANDOVER.get("started") or 0.0)
        error = str(_HANDOVER.get("error") or "")
        candidate_relay = _HANDOVER.get("candidate_relay")
        new_audio_slot = int(_HANDOVER.get("audio_slot") or 0)
        video_feeder = _HANDOVER.get("video_feeder")
        video_log = _HANDOVER.get("video_log")
        video_port = int(_HANDOVER.get("video_port") or 0)
        video_clock_started = float(_HANDOVER.get("video_clock_started") or 0.0)

    code = None
    if proc is not None:
        try:
            code = proc.poll()
        except Exception:
            code = 1
    if error or (proc is not None and code is not None):
        msg = error or "FFmpeg exit %s" % code
        _tslog("handover failed: %s" % msg)
        _handover_clear(True)
        # If a pause was waiting for this handover, return to the live picture.
        try:
            resume_remux_video(True)
        except Exception:
            pass
        _message(session, "Unable to switch Local Remux:\n%s\n\nSee %s" % (msg, TIMESHIFT_FFLOG), True, 7)
        return

    if proc is not None and port and _port_listening(port):
        # Snapshot old objects before committing the replacement.
        with _LOCK:
            old_proc = _STATE.get("proc")
            old_timer = _STATE.get("timer")
            old_stderr = _STATE.get("stderr")
            old_tail = _STATE.get("timeshift_tail")
            original_ref = str(_STATE.get("original_ref") or "")
            ts_recorder = _STATE.get("timeshift_recorder")
            ts_rec_log = _STATE.get("timeshift_recorder_log")
            ts_file = str(_STATE.get("timeshift_file") or "")
            ts_started = float(_STATE.get("timeshift_started") or 0.0)
            ts_recording = bool(_STATE.get("timeshift_recording"))
            ts_last_size = int(_STATE.get("timeshift_last_size") or 0)
            ts_last_growth = float(_STATE.get("timeshift_last_growth") or 0.0)
            ts_last_restart = float(_STATE.get("timeshift_last_restart") or 0.0)
            ts_signal_lost = bool(_STATE.get("timeshift_signal_lost"))
            ts_rate_bps = float(_STATE.get("timeshift_rate_bps") or 0.0)
            ts_sample_time = float(_STATE.get("timeshift_sample_time") or 0.0)
            old_audio_relay = _STATE.get("audio_relay")
            old_video_feeder = _STATE.get("timeshift_video_proc")
            old_video_log = _STATE.get("timeshift_video_log")
            old_video_port = int(_STATE.get("timeshift_video_port") or 0)
            old_video_generation = int(_STATE.get("timeshift_video_generation") or 0)

        try:
            ref = eServiceReference(4097, 0, local_url)
            ref.setName("SAT + %s" % name)
            result = session.nav.playService(ref)
            if result is False:
                ref = eServiceReference(5002, 0, local_url)
                ref.setName("SAT + %s" % name)
                session.nav.playService(ref)
        except Exception as e:
            _handover_clear(True)
            try:
                resume_remux_video(True)
            except Exception:
                pass
            _message(session, "Unable to play replacement Local Remux:\n%s" % e, True, 7)
            return

        # Stop the old watchdog before its process is killed, otherwise it can
        # mistakenly restore the satellite service during the handover window.
        if old_timer:
            try:
                old_timer.stop()
            except Exception:
                pass

        watchdog = eTimer()
        watchdog_conn = None
        try:
            watchdog_conn = watchdog.timeout.connect(_poll_start)
        except Exception:
            watchdog.callback.append(_poll_start)

        effective_ts_delay = 0.0
        if satellite_source == "timeshift" and ts_started:
            if target_delay is not None:
                effective_ts_delay = float(target_delay)
            elif ts_rate_bps > 10000.0 and ts_file:
                try:
                    effective_ts_delay = max(0.0, float(os.path.getsize(ts_file)) / ts_rate_bps)
                except Exception:
                    effective_ts_delay = max(0.0, time.time() - ts_started)
            else:
                effective_ts_delay = max(0.0, time.time() - ts_started)

        with _LOCK:
            _STATE.update({
                "session": session,
                "proc": proc,
                "timer": watchdog,
                "timer_conn": watchdog_conn,
                "original_ref": original_ref,
                "local_ref": str(ref.toString()),
                "local_url": local_url,
                "iptv_name": name,
                "mode": mode,
                "port": port,
                "started": time.time(),
                "armed": True,
                "played": True,
                "error": "",
                "stderr": stderr,
                "iptv_headers": headers,
                "iptv_url": iptv_url,
                "audio_relay": candidate_relay if candidate_relay is not None else old_audio_relay,
                "audio_slot": int(new_audio_slot),
                "resume_context": context,
                "video_hold": False,
                "video_hold_started": 0.0,
                "timeshift_recorder": ts_recorder,
                "timeshift_recorder_log": ts_rec_log,
                "timeshift_file": ts_file,
                "timeshift_started": ts_started,
                "timeshift_recording": ts_recording,
                "timeshift_playback": satellite_source == "timeshift",
                "timeshift_tail": tail if satellite_source == "timeshift" else None,
                "timeshift_video_proc": video_feeder if satellite_source == "timeshift" else None,
                "timeshift_video_log": video_log if satellite_source == "timeshift" else None,
                "timeshift_video_port": int(video_port if satellite_source == "timeshift" else 0),
                "timeshift_video_generation": (old_video_generation + 1) if satellite_source == "timeshift" else 0,
                "timeshift_video_clock_started": float(video_clock_started if satellite_source == "timeshift" else 0.0),
                "timeshift_delay": effective_ts_delay,
                "timeshift_last_size": ts_last_size,
                "timeshift_last_growth": ts_last_growth,
                "timeshift_last_restart": ts_last_restart,
                "timeshift_signal_lost": ts_signal_lost,
                "timeshift_rate_bps": ts_rate_bps,
                "timeshift_sample_time": ts_sample_time,
                "resume_after_play": False,
            })
            # Detach candidate objects before clearing _HANDOVER so they are not killed.
            _HANDOVER["proc"] = None
            _HANDOVER["tail"] = None
            _HANDOVER["stderr"] = None
            _HANDOVER["candidate_relay"] = None
            _HANDOVER["video_feeder"] = None
            _HANDOVER["video_log"] = None
            _HANDOVER["video_port"] = 0
            _HANDOVER["video_clock_started"] = 0.0

        _handover_clear(False)
        # New service owns the decoder now; release the frozen picture only here.
        try:
            _video_ioctl(VIDEO_CONTINUE)
        except Exception:
            pass
        _terminate(old_proc)
        if candidate_relay is not None and old_audio_relay is not candidate_relay:
            try:
                from .audiorelay import stop_relay
                stop_relay(old_audio_relay)
            except Exception as e:
                _tslog("old audio relay stop failed: %s" % e)
        if old_video_feeder and old_video_feeder is not video_feeder:
            _terminate(old_video_feeder)
        if old_tail and old_tail is not tail:
            _terminate(old_tail)
        if old_video_log and old_video_log is not video_log:
            try:
                old_video_log.close()
            except Exception:
                pass
        if old_stderr and old_stderr is not stderr:
            try:
                old_stderr.close()
            except Exception:
                pass
        watchdog.start(1000, False)
        _tslog("handover complete source=%s url=%s" % (satellite_source, local_url))
        return

    if started and (time.time() - started) > 14.0:
        _tslog("handover timed out")
        _handover_clear(True)
        try:
            resume_remux_video(True)
        except Exception:
            pass
        _message(session, "Local Remux handover timed out.\nSee %s" % TIMESHIFT_FFLOG, True, 7)


def handover_status():
    with _LOCK:
        active = bool(_HANDOVER.get("active"))
        error = str(_HANDOVER.get("error") or "")
        source = str(_HANDOVER.get("satellite_source") or "")
    return active, error, source


def adjust_timeshift_video_delay(target_delay):
    """Change satellite-video delay without rebuilding Local Remux.

    Only the tail+FFmpeg video feeder is replaced.  The Enigma 4097 service,
    Local Remux HTTP server and persistent IPTV audio relay remain untouched.
    This is the core Lite24 fix for the second-adjustment audio/video lockup.
    Returns (ok, effective_delay, error_text).
    """
    ffmpeg = _find_executable("ffmpeg")
    if not ffmpeg:
        return False, 0.0, "ffmpeg is not installed"

    with _LOCK:
        active = bool(_STATE.get("armed")) and bool(_STATE.get("played"))
        playback = bool(_STATE.get("timeshift_playback"))
        ts_file = str(_STATE.get("timeshift_file") or "")
        ts_started = float(_STATE.get("timeshift_started") or 0.0)
        ts_rate_bps = float(_STATE.get("timeshift_rate_bps") or 0.0)
        video_port = int(_STATE.get("timeshift_video_port") or 0)
        old_tail = _STATE.get("timeshift_tail")
        old_video = _STATE.get("timeshift_video_proc")
        old_log = _STATE.get("timeshift_video_log")
        old_delay = float(_STATE.get("timeshift_delay") or 0.5)
        generation = int(_STATE.get("timeshift_video_generation") or 0) + 1
        video_clock_started = float(_STATE.get("timeshift_video_clock_started") or 0.0)
        main_proc = _STATE.get("proc")
        _STATE["timeshift_video_generation"] = generation

    if not active or not playback:
        return False, old_delay, "Satellite delayed playback is not active"
    if not ts_file or not os.path.exists(ts_file):
        return False, old_delay, "Timeshift buffer file is missing"
    if not video_port:
        return False, old_delay, "Dynamic satellite-video feeder is not active"
    try:
        if main_proc is None or main_proc.poll() is not None:
            return False, old_delay, "Local Remux is not running"
    except Exception:
        return False, old_delay, "Local Remux process status is unavailable"

    # Stop only the old VIDEO producer.  Do not touch the Local Remux process,
    # Enigma service or IPTV audio relay.  The resulting UDP gap is intentionally
    # very short and max_interleave_delta is kept low so audio keeps flowing.
    _terminate_fast(old_video)
    _terminate_fast(old_tail)
    if old_log:
        try:
            old_log.close()
        except Exception:
            pass

    new_tail = None
    new_video = None
    new_log = None
    try:
        clock_offset = max(0.0, time.time() - video_clock_started) if video_clock_started else 0.0
        new_tail, new_video, new_log, effective = _spawn_timeshift_video_feeder(
            ffmpeg, ts_file, float(target_delay), ts_started, ts_rate_bps,
            video_port, truncate_log=False, clock_offset=clock_offset
        )
        with _LOCK:
            if int(_STATE.get("timeshift_video_generation") or 0) != generation:
                _terminate(new_video)
                _terminate(new_tail)
                try:
                    if new_log:
                        new_log.close()
                except Exception:
                    pass
                return False, old_delay, "A newer video-delay adjustment replaced this one"
            _STATE["timeshift_tail"] = new_tail
            _STATE["timeshift_video_proc"] = new_video
            _STATE["timeshift_video_log"] = new_log
            _STATE["timeshift_delay"] = float(effective)
        _tslog("dynamic video delay applied %.1fs gen=%s clock_offset=%.3fs; Local Remux/audio untouched" % (float(effective), generation, float(clock_offset)))
        return True, float(effective), ""
    except Exception as e:
        error = str(e)
        _tslog("dynamic video delay failed gen=%s: %s" % (generation, error))

        # Best-effort rollback to the previous delay.  Even if rollback fails,
        # IPTV audio remains on the persistent Local Remux and the user can stop
        # IPAudio normally; the box should not require a reboot.
        try:
            rollback_offset = max(0.0, time.time() - video_clock_started) if video_clock_started else 0.0
            rb_tail, rb_video, rb_log, rb_effective = _spawn_timeshift_video_feeder(
                ffmpeg, ts_file, old_delay, ts_started, ts_rate_bps,
                video_port, truncate_log=False, clock_offset=rollback_offset
            )
            with _LOCK:
                if int(_STATE.get("timeshift_video_generation") or 0) == generation:
                    _STATE["timeshift_tail"] = rb_tail
                    _STATE["timeshift_video_proc"] = rb_video
                    _STATE["timeshift_video_log"] = rb_log
                    _STATE["timeshift_delay"] = float(rb_effective)
            _tslog("dynamic video delay rollback restored %.1fs" % float(rb_effective))
        except Exception as rb_error:
            _tslog("dynamic video delay rollback failed: %s" % rb_error)
        return False, old_delay, error


def _timeshift_storage_dir():
    # Lite21: disk-backed only. Never spill this continuously-growing buffer to
    # flash or /tmp. Prefer Enigma2's normal HDD timeshift directory.
    candidates = ["/media/hdd/timeshift", "/media/hdd"]
    for base in candidates:
        try:
            if not os.path.isdir(base) or not os.access(base, os.W_OK):
                continue
            st = os.statvfs(base)
            free = int(st.f_bavail) * int(st.f_frsize)
            if free >= 128 * 1024 * 1024:
                return base
        except Exception:
            pass
    return ""


def _spawn_timeshift_recorder(original_ref, path, append=False):
    """Raw-copy streamproxy MPEG-TS to the HDD buffer.

    R14 prefers a tiny Python 2/3 raw HTTP copier so OpenATV 8/ARM and older
    images use the same byte-for-byte behavior regardless of BusyBox wget
    differences. curl/wget remain fallbacks; FFmpeg is last resort only.
    """
    sat_url = _streamproxy_url(original_ref)
    logfh = open("/tmp/xklass-timeshift-recorder.log", "a" if append else "w")
    outfh = None
    try:
        outfh = open(path, "ab" if append else "wb")
        python_bin = _find_python_executable()
        curl = _find_executable("curl")
        wget = _find_executable("wget")
        if python_bin:
            cmd = [python_bin, "-u", "-c", _PY_RAW_RECORDER, sat_url]
            backend = "python raw MPEG-TS"
        elif curl:
            cmd = [curl, "-L", "-sS", "--no-buffer", "--connect-timeout", "8", sat_url]
            backend = "curl raw MPEG-TS"
        elif wget:
            # Keep options inside the common BusyBox/GNU subset.
            cmd = [wget, "-q", "-O", "-", sat_url]
            backend = "wget raw MPEG-TS"
        else:
            ffmpeg = _find_executable("ffmpeg")
            if not ffmpeg:
                raise RuntimeError("No Python/curl/wget/ffmpeg recorder backend is installed")
            cmd = [
                ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error",
                "-fflags", "+genpts+discardcorrupt",
                "-probesize", "8388608", "-analyzeduration", "4000000",
                "-i", sat_url,
                "-map", "0:v:0", "-map", "0:a:0?",
                "-c", "copy", "-mpegts_flags", "+resend_headers",
                "-f", "mpegts", "pipe:1",
            ]
            backend = "ffmpeg fallback"
        null_in = open(os.devnull, "rb")
        proc = subprocess.Popen(
            cmd,
            stdin=null_in, stdout=outfh,
            stderr=logfh, close_fds=True,
        )
        try:
            null_in.close()
        except Exception:
            pass
        try:
            outfh.close()
        except Exception:
            pass
        _tslog("R14 satellite recorder backend: %s%s" % (backend, " (append)" if append else ""))
        return proc, logfh
    except Exception:
        try:
            if outfh:
                outfh.close()
        except Exception:
            pass
        try:
            logfh.close()
        except Exception:
            pass
        raise

def start_video_timeshift_recording(minimum_seconds=2, freeze_now=True):
    """Start recording the original satellite TS.

    Lite24 R7 can defer the first VIDEO_FREEZE until the Local Remux satellite
    picture has actually had time to reach the hardware decoder.  Older callers
    keep the previous immediate-freeze behaviour via ``freeze_now=True``.
    """
    if not is_local_remux_active():
        return False, "Local Remux is not running"
    with _LOCK:
        if _STATE.get("timeshift_recording"):
            return True, ""
        original_ref = str(_STATE.get("original_ref") or "")
        existing_tail = _STATE.get("timeshift_tail")
    if not original_ref or not _is_dvb_ref(original_ref):
        return False, "Original satellite service is unavailable"
    if existing_tail:
        if not freeze_now:
            return True, ""
        ok = freeze_remux_video(max(0.5, float(minimum_seconds)))
        return ok, ""

    base = _timeshift_storage_dir()
    if not base:
        return False, "Internal HDD /media/hdd is unavailable or has less than 128 MB free"
    path = os.path.join(base, ".ipaudio-alquds-sat-timeshift-%d.ts" % os.getpid())
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass
    try:
        proc, logfh = _spawn_timeshift_recorder(original_ref, path, append=False)
    except Exception as e:
        return False, str(e)

    now = time.time()
    with _LOCK:
        _STATE["timeshift_recorder"] = proc
        _STATE["timeshift_recorder_log"] = logfh
        _STATE["timeshift_file"] = path
        _STATE["timeshift_started"] = now
        _STATE["timeshift_recording"] = True
        _STATE["timeshift_playback"] = False
        _STATE["timeshift_delay"] = 0.0
        _STATE["timeshift_last_size"] = 0
        _STATE["timeshift_last_growth"] = now
        _STATE["timeshift_last_restart"] = now
        _STATE["timeshift_signal_lost"] = False
        _STATE["timeshift_rate_bps"] = 0.0
        _STATE["timeshift_sample_time"] = now
    if freeze_now:
        ok = freeze_remux_video(0.0)
        if not ok:
            _terminate(proc)
            try:
                logfh.close()
            except Exception:
                pass
            with _LOCK:
                _STATE["timeshift_recorder"] = None
                _STATE["timeshift_recorder_log"] = None
                _STATE["timeshift_file"] = ""
                _STATE["timeshift_started"] = 0.0
                _STATE["timeshift_recording"] = False
            try:
                if os.path.exists(path):
                    os.remove(path)
            except Exception:
                pass
            return False, "DVB VIDEO_FREEZE is unavailable"
        _tslog("satellite video timeshift recording started and video frozen: %s" % path)
    else:
        _tslog("satellite video timeshift recording started; initial freeze deferred: %s" % path)
    return True, ""


def maintain_video_timeshift_recording(stall_seconds=2.5, retry_seconds=2.0):
    """Watch the satellite recorder and reconnect without discarding its file.

    Returns (state, size_bytes), where state is one of:
        ok, lost, reconnecting, restored, stopped

    A growth stall is treated as signal loss even if ffmpeg itself is still
    alive. The stale recorder is replaced and the replacement appends to the
    SAME TS file, preserving delayed `tail -f` playback and therefore the user's
    target A/V offset as closely as the DVB continuity permits.
    """
    now = time.time()
    with _LOCK:
        recording = bool(_STATE.get("timeshift_recording"))
        proc = _STATE.get("timeshift_recorder")
        logfh = _STATE.get("timeshift_recorder_log")
        path = str(_STATE.get("timeshift_file") or "")
        original_ref = str(_STATE.get("original_ref") or "")
        last_size = int(_STATE.get("timeshift_last_size") or 0)
        last_growth = float(_STATE.get("timeshift_last_growth") or 0.0)
        last_restart = float(_STATE.get("timeshift_last_restart") or 0.0)
        was_lost = bool(_STATE.get("timeshift_signal_lost"))
        old_rate = float(_STATE.get("timeshift_rate_bps") or 0.0)
        sample_time = float(_STATE.get("timeshift_sample_time") or 0.0)
    if not recording or not path or not original_ref:
        return "stopped", 0

    try:
        size = int(os.path.getsize(path))
    except Exception:
        size = 0
    alive = False
    if proc is not None:
        try:
            alive = proc.poll() is None
        except Exception:
            alive = False

    if size > last_size:
        dt = max(0.001, now - sample_time) if sample_time else 0.0
        delta = max(0, size - last_size)
        rate = old_rate
        # Ignore a long outage interval when calculating bitrate. Once packets
        # resume, the next short sample will quickly refresh the EWMA.
        if dt and dt <= 1.5 and delta >= 188 * 20:
            instant = float(delta) / dt
            if 10000.0 <= instant <= 50000000.0:
                rate = instant if old_rate < 10000.0 else (old_rate * 0.75 + instant * 0.25)
        with _LOCK:
            _STATE["timeshift_last_size"] = size
            _STATE["timeshift_last_growth"] = now
            _STATE["timeshift_sample_time"] = now
            _STATE["timeshift_signal_lost"] = False
            if rate > 0.0:
                _STATE["timeshift_rate_bps"] = rate
        if alive:
            if was_lost:
                _tslog("satellite signal restored; recorder continues same TS file")
                return "restored", size
            return "ok", size
        # The process can exit immediately after flushing a final chunk. Keep
        # the new size/rate sample but fall through and reconnect instead of
        # falsely reporting a healthy recorder for another watchdog cycle.
        _tslog("R14 recorder exited after final growth sample; reconnecting without discarding buffer")

    # No growth (or recorder already exited). Give a living connection a fair
    # window, but do not force a dead helper to wait the full stall timeout.
    age = now - (last_growth or now)
    if alive and age < float(stall_seconds):
        return "lost" if was_lost else "ok", size

    with _LOCK:
        _STATE["timeshift_signal_lost"] = True
    if not was_lost:
        _tslog("satellite signal/buffer growth lost; holding existing timeshift buffer")

    retry_wait = 0.75 if not alive else float(retry_seconds)
    if (now - last_restart) < retry_wait:
        return "lost", size

    # Replace only the recorder. Do NOT touch the delayed playback tail/remux.
    _terminate(proc)
    if logfh:
        try:
            logfh.close()
        except Exception:
            pass
    with _LOCK:
        _STATE["timeshift_recorder"] = None
        _STATE["timeshift_recorder_log"] = None
        _STATE["timeshift_last_restart"] = now
        _STATE["timeshift_sample_time"] = now
    try:
        new_proc, new_log = _spawn_timeshift_recorder(original_ref, path, append=True)
        with _LOCK:
            _STATE["timeshift_recorder"] = new_proc
            _STATE["timeshift_recorder_log"] = new_log
            _STATE["timeshift_last_restart"] = now
            _STATE["timeshift_sample_time"] = now
        _tslog("satellite recorder reconnect attempt started (append mode)")
        return "reconnecting", size
    except Exception as e:
        _tslog("satellite recorder reconnect failed: %s" % e)
        return "lost", size



def cancel_video_timeshift_keep_remux(reason=""):
    """Abort only the HDD/delayed-video layer; keep the proven Local Remux live."""
    with _LOCK:
        recorder = _STATE.get("timeshift_recorder")
        rec_log = _STATE.get("timeshift_recorder_log")
        tail = _STATE.get("timeshift_tail")
        video_proc = _STATE.get("timeshift_video_proc")
        video_log = _STATE.get("timeshift_video_log")
        path = str(_STATE.get("timeshift_file") or "")
        _STATE["timeshift_recorder"] = None
        _STATE["timeshift_recorder_log"] = None
        _STATE["timeshift_tail"] = None
        _STATE["timeshift_video_proc"] = None
        _STATE["timeshift_video_log"] = None
        _STATE["timeshift_video_port"] = 0
        _STATE["timeshift_file"] = ""
        _STATE["timeshift_started"] = 0.0
        _STATE["timeshift_recording"] = False
        _STATE["timeshift_playback"] = False
        _STATE["timeshift_delay"] = 0.0
        _STATE["timeshift_last_size"] = 0
        _STATE["timeshift_last_growth"] = 0.0
        _STATE["timeshift_last_restart"] = 0.0
        _STATE["timeshift_signal_lost"] = False
        _STATE["timeshift_rate_bps"] = 0.0
        _STATE["timeshift_sample_time"] = 0.0
    try:
        resume_remux_video(force=True)
    except Exception:
        pass
    _terminate(video_proc)
    _terminate(tail)
    _terminate(recorder)
    for fh in (video_log, rec_log):
        if fh:
            try:
                fh.close()
            except Exception:
                pass
    if path:
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass
    _tslog("timeshift layer aborted; Local Remux kept alive%s" % (": " + str(reason) if reason else ""))
    return True


def timeshift_buffer_health():
    """Return (ready, size, age_since_growth, rate_bps) for the R14 freeze gate.

    Bytes alone are not enough: an HTTP error page can grow and pass the old
    gate. R14 requires real 188-byte MPEG-TS sync and recent growth. The byte
    threshold follows the measured bitrate (roughly 0.65s, bounded) so low and
    high bitrate services behave consistently across receiver images.
    """
    now = time.time()
    with _LOCK:
        path = str(_STATE.get("timeshift_file") or "")
        recording = bool(_STATE.get("timeshift_recording"))
        last_growth = float(_STATE.get("timeshift_last_growth") or 0.0)
        rate = float(_STATE.get("timeshift_rate_bps") or 0.0)
    size = 0
    if path:
        try:
            size = int(os.path.getsize(path))
        except Exception:
            size = 0
    age = (now - last_growth) if last_growth else 999.0
    minimum_bytes = 188 * 1536
    if rate > 10000.0:
        minimum_bytes = max(minimum_bytes, min(1024 * 1024, int(rate * 0.65)))
    ts_ok = bool(path and size >= (188 * 5) and _ts_sync_ok(path))
    ready = bool(recording and ts_ok and size >= minimum_bytes and age <= 2.5)
    return ready, size, age, rate


def timeshift_signal_status():
    with _LOCK:
        return bool(_STATE.get("timeshift_signal_lost")), float(_STATE.get("timeshift_delay") or 0.0)


def video_timeshift_status():
    with _LOCK:
        proc = _STATE.get("timeshift_recorder")
        path = str(_STATE.get("timeshift_file") or "")
        started = float(_STATE.get("timeshift_started") or 0.0)
        recording = bool(_STATE.get("timeshift_recording"))
        playback = bool(_STATE.get("timeshift_playback"))
        held = bool(_STATE.get("video_hold"))
        rate = float(_STATE.get("timeshift_rate_bps") or 0.0)
    alive = False
    if proc:
        try:
            alive = proc.poll() is None
        except Exception:
            pass
    size = 0
    if path:
        try:
            size = os.path.getsize(path)
        except Exception:
            pass
    if rate > 10000.0 and size > 0:
        elapsed = float(size) / rate
    else:
        elapsed = max(0.0, time.time() - started) if started else 0.0
    # `recording` is a logical session state; a reconnect window is not treated
    # as a destroyed timeshift because the same HDD file is retained.
    return bool(recording), playback, held, elapsed, size, path


def cancel_video_timeshift(delete_file=True, resume_video=True):
    with _LOCK:
        recorder = _STATE.get("timeshift_recorder")
        tail = _STATE.get("timeshift_tail")
        video_proc = _STATE.get("timeshift_video_proc")
        video_log = _STATE.get("timeshift_video_log")
        logfh = _STATE.get("timeshift_recorder_log")
        path = str(_STATE.get("timeshift_file") or "")
        _STATE["timeshift_recorder"] = None
        _STATE["timeshift_tail"] = None
        _STATE["timeshift_recorder_log"] = None
        _STATE["timeshift_file"] = ""
        _STATE["timeshift_started"] = 0.0
        _STATE["timeshift_recording"] = False
        _STATE["timeshift_playback"] = False
        _STATE["timeshift_delay"] = 0.0
        _STATE["timeshift_last_size"] = 0
        _STATE["timeshift_last_growth"] = 0.0
        _STATE["timeshift_last_restart"] = 0.0
        _STATE["timeshift_signal_lost"] = False
        _STATE["timeshift_rate_bps"] = 0.0
        _STATE["timeshift_sample_time"] = 0.0
    _terminate(video_proc)
    _terminate(tail)
    _terminate(recorder)
    if video_log:
        try:
            video_log.close()
        except Exception:
            pass
    if logfh:
        try:
            logfh.close()
        except Exception:
            pass
    if delete_file and path:
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass
    if resume_video:
        try:
            resume_remux_video(True)
        except Exception:
            pass
    _tslog("video timeshift cancelled")
    return True


def timeshift_playback_active():
    with _LOCK:
        return bool(_STATE.get("timeshift_playback")) and is_local_remux_active()


def timeshift_delay_status():
    """Return (active, configured_delay_seconds, available_buffer_seconds)."""
    with _LOCK:
        playback = bool(_STATE.get("timeshift_playback"))
        delay = float(_STATE.get("timeshift_delay") or 0.0)
        started = float(_STATE.get("timeshift_started") or 0.0)
        path = str(_STATE.get("timeshift_file") or "")
        rate = float(_STATE.get("timeshift_rate_bps") or 0.0)
    elapsed = max(0.0, time.time() - started) if started else 0.0
    if path and rate > 10000.0:
        try:
            elapsed = max(0.0, float(os.path.getsize(path)) / rate)
        except Exception:
            pass
    return bool(playback and is_local_remux_active()), delay, elapsed
