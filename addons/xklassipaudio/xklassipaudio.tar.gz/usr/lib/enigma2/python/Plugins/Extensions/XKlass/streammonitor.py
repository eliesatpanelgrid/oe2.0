#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Lightweight fullscreen stream InfoBar and persistent IPAUDIO badge."""

from __future__ import division, print_function

import os
import time

from Components.Label import Label
from Components.ProgressBar import ProgressBar
from Screens.Screen import Screen
from enigma import eTimer, getDesktop, iServiceInformation

from .streammetrics import (
    AUDIO_BITRATE_PATHS,
    VIDEO_BITRATE_PATHS,
    classify_flow,
    format_rate,
    network_link_up,
    quality_label,
    read_decoder_bitrate_bytes,
    read_network_rx_bytes,
)


def _desktop_size():
    try:
        size = getDesktop(0).size()
        return int(size.width()), int(size.height())
    except Exception:
        return 1280, 720


def _stream_info_skin():
    width, height = _desktop_size()
    scale = max(0.75, float(width) / 1280.0)
    bar_h = int(176 * scale)
    y = max(0, height - bar_h)

    def s(value):
        return int(value * scale)

    return '''<screen name="XKlassStreamInfoBar" position="0,%d" size="%d,%d" backgroundColor="#78121B28" flags="wfNoBorder" zPosition="20">
        <widget name="channel" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#FFFFFF" transparent="1" noWrap="1" />
        <widget name="clock" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#FFFFFF" transparent="1" halign="right" noWrap="1" />
        <widget name="event" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#DDE7F2" transparent="1" noWrap="1" />
        <widget name="event_time" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#7FDBFF" transparent="1" halign="right" noWrap="1" />
        <widget name="quality" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#FFFFFF" transparent="1" noWrap="1" />
        <widget name="player" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#FFD166" transparent="1" noWrap="1" />
        <widget name="video_rate" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#FFFFFF" transparent="1" noWrap="1" />
        <widget name="audio_rate" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#FFFFFF" transparent="1" noWrap="1" />
        <widget name="total_rate" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#FFFFFF" transparent="1" noWrap="1" />
        <widget name="network" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#58D68D" transparent="1" noWrap="1" />
        <widget name="flow" position="%d,%d" size="%d,%d" borderWidth="%d" borderColor="#FFFFFF" foregroundColor="#35C46A" backgroundColor="#273444" />
        <widget name="diagnosis" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#DDE7F2" transparent="1" halign="right" noWrap="1" />
        <widget name="hint" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#9FB3C8" transparent="1" halign="center" noWrap="1" />
    </screen>''' % (
        y, width, bar_h,
        s(30), s(10), s(820), s(35), s(26),
        s(1000), s(10), s(240), s(35), s(25),
        s(30), s(48), s(780), s(30), s(21),
        s(820), s(48), s(420), s(30), s(20),
        s(30), s(82), s(260), s(28), s(19),
        s(300), s(82), s(315), s(28), s(19),
        s(625), s(82), s(190), s(28), s(19),
        s(820), s(82), s(190), s(28), s(19),
        s(1015), s(82), s(225), s(28), s(19),
        s(30), s(118), s(350), s(28), s(20),
        s(390), s(126), s(480), s(14), max(1, s(1)),
        s(880), s(118), s(360), s(28), s(18),
        s(30), s(148), s(1210), s(22), s(16),
    )


def _ipaudio_badge_skin():
    width, _height = _desktop_size()
    scale = max(0.75, float(width) / 1280.0)

    def s(value):
        return int(value * scale)

    badge_w, badge_h = s(390), s(48)
    x, y = max(0, width - badge_w - s(18)), s(18)
    return '''<screen name="XKlassIPAudioBadge" position="%d,%d" size="%d,%d" backgroundColor="#D0101820" flags="wfNoBorder" zPosition="30">
        <widget name="status" position="%d,0" size="%d,%d" font="Regular;%d" foregroundColor="#FFD166" transparent="1" valign="center" halign="center" noWrap="1" />
    </screen>''' % (x, y, badge_w, badge_h, s(8), badge_w - s(16), badge_h, s(20))


def _timer_connect(timer, callback):
    try:
        return timer.timeout.connect(callback)
    except Exception:
        timer.callback.append(callback)
        return None


def available_player_types():
    values = [(4097, "IPTV / ServiceMP3")]
    if os.path.isfile("/usr/bin/gstplayer"):
        values.append((5001, "GStreamer / GstPlayer"))
    if os.path.isfile("/usr/bin/exteplayer3") or os.path.isfile("/usr/bin/exteplayer3.sh"):
        values.append((5002, "ExtePlayer3"))
    if os.path.isfile("/usr/bin/apt-get"):
        values.append((8193, "DreamOS GStreamer"))
    return values


def player_label(service_type):
    try:
        service_type = int(service_type)
    except Exception:
        service_type = 4097
    names = dict(available_player_types())
    return "%s (%d)" % (names.get(service_type, "Player"), service_type)


def _safe_service_info(info, key_name):
    if not info:
        return 0
    key = getattr(iServiceInformation, key_name, None)
    if key is None:
        return 0
    try:
        value = int(info.getInfo(key))
        return value if value > 0 else 0
    except Exception:
        return 0


def _format_duration(seconds):
    try:
        seconds = max(0, int(seconds or 0))
    except Exception:
        seconds = 0
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return "%d:%02d:%02d" % (hours, minutes, secs)
    return "%02d:%02d" % (minutes, secs)


class XKlassStreamInfoBar(Screen):
    skin = _stream_info_skin()

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.channel_name = ""
        self.service_type = 4097
        self._visible = False
        self._last_rx = read_network_rx_bytes()
        self._last_rx_time = time.time()
        self._flow_history = []
        self._metric_timer = eTimer()
        self._metric_timer_conn = _timer_connect(self._metric_timer, self._update)
        # The bar is user-controlled: it stays visible until OK/INFO is pressed.
        self._hide_timer = eTimer()
        self._hide_timer_conn = _timer_connect(self._hide_timer, self.hide)
        for name in ("channel", "clock", "event", "event_time", "quality", "player",
                     "video_rate", "audio_rate", "total_rate", "network",
                     "diagnosis", "hint"):
            self[name] = Label("")
        self["flow"] = ProgressBar()
        self["hint"].setText("MENU: change player    OK/INFO: show or hide    CH+/CH-: zap    0: restart")
        self.onShow.append(self._shown)
        self.onHide.append(self._hidden)
        self.onClose.append(self.stop)

    def set_context(self, channel_name, service_type):
        self.channel_name = str(channel_name or "Channel")
        try:
            self.service_type = int(service_type)
        except Exception:
            self.service_type = 4097
        self["channel"].setText(self.channel_name)
        self["player"].setText("Player: " + player_label(self.service_type))
        self._last_rx = read_network_rx_bytes()
        self._last_rx_time = time.time()
        self._flow_history = []
        self._update()

    def show_for(self, milliseconds=0):
        self.show()
        try:
            self._hide_timer.stop()
        except Exception:
            pass

    def toggle(self):
        if self._visible:
            self.hide()
        else:
            self.show_for()

    def _shown(self):
        self._visible = True
        self._update()
        try:
            self._metric_timer.start(1000, False)
        except Exception:
            pass

    def _hidden(self):
        self._visible = False
        try:
            self._metric_timer.stop()
            self._hide_timer.stop()
        except Exception:
            pass

    def stop(self):
        for timer in (self._metric_timer, self._hide_timer):
            try:
                timer.stop()
            except Exception:
                pass

    def _event_details(self, info):
        try:
            event = info.getEvent(0) if info else None
        except Exception:
            event = None
        if not event:
            return "Event: --", ""
        try:
            name = str(event.getEventName() or "--")
        except Exception:
            name = "--"
        try:
            begin = int(event.getBeginTime())
            duration = int(event.getDuration())
            now = int(time.time())
            elapsed = max(0, min(duration, now - begin))
            remaining = max(0, duration - elapsed)
            timing = "Elapsed %s  |  Remaining %s" % (
                _format_duration(elapsed), _format_duration(remaining))
        except Exception:
            timing = ""
        return "Event: " + name, timing

    def _set_network_colour(self, colour):
        values = {
            "red": 0x00E74C3C,
            "orange": 0x00F39C12,
            "yellow": 0x00F4D03F,
            "green": 0x0035C46A,
        }
        try:
            from enigma import gRGB
            rgb = gRGB(values.get(colour, values["green"]))
            if self["network"].instance:
                self["network"].instance.setForegroundColor(rgb)
            if self["flow"].instance:
                self["flow"].instance.setForegroundColor(rgb)
        except Exception:
            pass

    def _update(self):
        now = time.time()
        current_rx = read_network_rx_bytes()
        elapsed = max(0.20, now - self._last_rx_time)
        rx_rate = max(0, int((current_rx - self._last_rx) / elapsed)) if current_rx >= self._last_rx else 0
        self._last_rx, self._last_rx_time = current_rx, now
        self._flow_history.append(rx_rate)
        self._flow_history = self._flow_history[-8:]

        service = None
        info = None
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
        except Exception:
            pass
        width = _safe_service_info(info, "sVideoWidth")
        height = _safe_service_info(info, "sVideoHeight")
        framerate = _safe_service_info(info, "sFrameRate")
        if framerate > 1000:
            framerate = int((framerate + 500) / 1000)

        quality = quality_label(width, height)
        resolution = "%dx%d" % (width, height) if width and height else "resolving..."
        fps = " @ %dfps" % framerate if framerate else ""
        self["quality"].setText("Video: %s  %s%s" % (quality, resolution, fps))
        self["player"].setText("Player: " + player_label(self.service_type))

        video_rate = read_decoder_bitrate_bytes(VIDEO_BITRATE_PATHS)
        audio_rate = read_decoder_bitrate_bytes(AUDIO_BITRATE_PATHS)
        self["video_rate"].setText("V: %s" % (format_rate(video_rate) if video_rate else "N/A"))
        self["audio_rate"].setText("A: %s" % (format_rate(audio_rate) if audio_rate else "N/A"))
        self["total_rate"].setText("RX: %s" % format_rate(rx_rate))

        event, event_time = self._event_details(info)
        self["event"].setText(event)
        self["event_time"].setText(event_time)
        self["clock"].setText(time.strftime("%H:%M:%S"))

        label, percent, colour, diagnosis = classify_flow(
            rx_rate, height, self._flow_history, network_link_up())
        self["network"].setText("Internet/stream: " + label)
        self["flow"].setValue(int(percent))
        self["diagnosis"].setText(diagnosis)
        self._set_network_colour(colour)


class XKlassIPAudioBadge(Screen):
    skin = _ipaudio_badge_skin()

    def __init__(self, session):
        Screen.__init__(self, session)
        self["status"] = Label("IP AUDIO: STARTING")
        self._timer = eTimer()
        self._timer_conn = _timer_connect(self._timer, self._update)
        self.onShow.append(self._shown)
        self.onClose.append(self.stop)

    def _shown(self):
        self._update()
        try:
            self._timer.start(1000, False)
        except Exception:
            pass

    def stop(self):
        try:
            self._timer.stop()
        except Exception:
            pass

    def _set_colour(self, value):
        try:
            from enigma import gRGB
            if self["status"].instance:
                self["status"].instance.setForegroundColor(gRGB(value))
        except Exception:
            pass

    def _update(self):
        try:
            from .backgroundaudio import background_audio_diagnostics
            data = background_audio_diagnostics()
        except Exception:
            data = {"state": "starting", "name": ""}
        state = str(data.get("state") or "stopped")
        name = str(data.get("name") or "")
        short_name = name[:24]
        if state == "running":
            text, colour = "IP AUDIO: ON", 0x0035C46A
        elif state == "failed":
            text, colour = "IP AUDIO: FAILED", 0x00E74C3C
        elif state == "restarting":
            text, colour = "IP AUDIO: RECONNECTING", 0x00F39C12
        elif state == "starting":
            text, colour = "IP AUDIO: STARTING", 0x00F4D03F
        else:
            self.hide()
            return
        if short_name:
            text += "  |  " + short_name
        self["status"].setText(text)
        self._set_colour(colour)


_IPAUDIO_DIALOG = None


def create_stream_info_dialog(session):
    try:
        dialog = session.instantiateDialog(XKlassStreamInfoBar)
        dialog.hide()
        return dialog
    except Exception as error:
        print("[XKlass] stream InfoBar unavailable: %s" % error)
        return None


def destroy_stream_info_dialog(session, dialog):
    if not dialog:
        return
    try:
        dialog.stop()
    except Exception:
        pass
    try:
        session.deleteDialog(dialog)
    except Exception:
        try:
            dialog.hide()
        except Exception:
            pass


def show_ipaudio_status(session):
    global _IPAUDIO_DIALOG
    if session is None:
        return None
    if _IPAUDIO_DIALOG is None:
        try:
            _IPAUDIO_DIALOG = session.instantiateDialog(XKlassIPAudioBadge)
        except Exception as error:
            print("[XKlass] IPAUDIO badge unavailable: %s" % error)
            _IPAUDIO_DIALOG = None
            return None
    try:
        _IPAUDIO_DIALOG.show()
    except Exception:
        pass
    return _IPAUDIO_DIALOG


def hide_ipaudio_status(session=None):
    global _IPAUDIO_DIALOG
    dialog = _IPAUDIO_DIALOG
    _IPAUDIO_DIALOG = None
    if dialog is None:
        return
    try:
        dialog.stop()
    except Exception:
        pass
    try:
        if session is not None:
            session.deleteDialog(dialog)
        else:
            dialog.hide()
    except Exception:
        try:
            dialog.hide()
        except Exception:
            pass
