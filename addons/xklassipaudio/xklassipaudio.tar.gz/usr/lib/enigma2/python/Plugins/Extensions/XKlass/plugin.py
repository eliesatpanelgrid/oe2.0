#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import shutil
import sys
import time
import glob as glob_module
import twisted.python.runtime

from . import _
from Components.config import (
    config, ConfigSubsection, ConfigSelection, ConfigDirectory,
    ConfigYesNo, ConfigSelectionNumber, ConfigClock, ConfigPIN,
    ConfigInteger, configfile, ConfigText
)
from enigma import eTimer, getDesktop, addFont
from Plugins.Plugin import PluginDescriptor
from os.path import isdir

# ------------------------------------------------------------------
# Basic environment / platform checks
# ------------------------------------------------------------------

pythonFull = (sys.version_info.major, sys.version_info.minor)
pythonVer = sys.version_info.major
isDreambox = os.path.exists("/usr/bin/apt-get")
debugs = False

# ------------------------------------------------------------------
# Dependencies checks
# ------------------------------------------------------------------

try:
    from multiprocessing.pool import ThreadPool
    hasMultiprocessing = True
except ImportError:
    hasMultiprocessing = False

try:
    from concurrent.futures import ThreadPoolExecutor
    if twisted.python.runtime.platform.supportsThreads():
        hasConcurrent = True
    else:
        hasConcurrent = False
except ImportError:
    hasConcurrent = False


# ------------------------------------------------------------------
# Paths
# ------------------------------------------------------------------

dir_etc = "/etc/enigma2/xklass/"
dir_tmp = "/etc/enigma2/xklass/tmp/"
dir_plugins = "/usr/lib/enigma2/python/Plugins/Extensions/XKlass/"
dir_videos = "/usr/lib/enigma2/python/Plugins/Extensions/XKlass/video/"


# ------------------------------------------------------------------
# Version
# ------------------------------------------------------------------

version = ""
try:
    with open(os.path.join(dir_plugins, "version.txt"), "r") as f:
        version = f.readline().strip()
except:
    version = ""


# ------------------------------------------------------------------
# Screen / skin selection
# ------------------------------------------------------------------

screenwidth = getDesktop(0).size()

if screenwidth.width() == 2560:
    skin_directory = os.path.join(dir_plugins, "skin/uhd/")
elif screenwidth.width() > 1280:
    skin_directory = os.path.join(dir_plugins, "skin/fhd/")
else:
    skin_directory = os.path.join(dir_plugins, "skin/hd/")

try:
    folders = [x for x in os.listdir(skin_directory) if x != "common"]
except:
    folders = ["default"]

files = os.listdir(dir_videos)

video_extensions = ('.mp4', '.avi', '.mkv')
video_files = [file for file in files if file.endswith(video_extensions)]
video_list = [(os.path.join(dir_videos, file), file) for file in video_files]

# ------------------------------------------------------------------
# Language & User-Agent options
# ------------------------------------------------------------------

languages = [
    ("", "English"),
    ("de-DE", "Deutsch"),
    ("es-ES", "Español"),
    ("fr-FR", "Français"),
    ("it-IT", "Italiano"),
    ("nl-NL", "Nederlands"),
    ("tr-TR", "Türkçe"),
    ("cs-CZ", "Český"),
    ("da-DK", "Dansk"),
    ("hr-HR", "Hrvatski"),
    ("hu-HU", "Magyar"),
    ("no-NO", "Norsk"),
    ("pl-PL", "Polski"),
    ("pt-PT", "Português"),
    ("ro-RO", "Română"),
    ("ru-RU", "Pусский"),
    ("sh-SH", "Srpski"),
    ("sk-SK", "Slovenčina"),
    ("fi-FI", "suomi"),
    ("sv-SE", "svenska"),
    ("uk-UA", "Український"),
    ("ar-SA", "العربية"),
    ("bg-BG", "български език"),
    ("el-GR", "ελληνικά"),
    ("sq-AL", "shqip"),
    ("zh-CN", "中文")
]

useragents = [
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"),
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0", "Firefox 147"),
    ("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36", "Android")
]

# ------------------------------------------------------------------
# Config setup
# ------------------------------------------------------------------

config.plugins.XKlass = ConfigSubsection()
cfg = config.plugins.XKlass

live_streamtype_choices = [("1", "DVB(1)"), ("4097", "IPTV(4097)")]
vod_streamtype_choices = [("4097", "IPTV(4097)")]

if os.path.exists("/usr/bin/gstplayer"):
    live_streamtype_choices.append(("5001", "GStreamer(5001)"))
    vod_streamtype_choices.append(("5001", "GStreamer(5001)"))

if os.path.exists("/usr/bin/exteplayer3"):
    live_streamtype_choices.append(("5002", "ExtePlayer(5002)"))
    vod_streamtype_choices.append(("5002", "ExtePlayer(5002)"))

if isDreambox:
    live_streamtype_choices.append(("8193", "DreamOS GStreamer(8193)"))
    vod_streamtype_choices.append(("8193", "DreamOS GStreamer(8193)"))

default_streamtype = "5002" if any(x[0] == "5002" for x in live_streamtype_choices) else "4097"
default_vodtype = "5002" if any(x[0] == "5002" for x in vod_streamtype_choices) else "4097"
cfg.livetype = ConfigSelection(default=default_streamtype, choices=live_streamtype_choices)
cfg.vodtype = ConfigSelection(default=default_vodtype, choices=vod_streamtype_choices)

cfg.ar_id_player = ConfigSelection(default="6", choices=[
    ("0", _("4:3 Letterbox")),
    ("1", _("4:3 PanScan")),
    ("2", _("16:9")),
    ("3", _("16:9 Always")),
    ("4", _("16:10 Letterbox")),
    ("5", _("16:10 PanScan")),
    ("6", _("16:9 Letterbox")),
])

# ------------------------------------------------------------------
# Download location (safe, minimal writes)
# ------------------------------------------------------------------

result = cfg.downloadlocation.value if hasattr(cfg, "downloadlocation") else ""

if not result:
    try:
        if isdir("/media/hdd/movie/"):
            result = "/media/hdd/movie/"
        elif isdir("/media/usb/movie/"):
            result = "/media/usb/movie/"
        elif config.usage.instantrec_path.value:
            result = config.usage.instantrec_path.value
        elif config.movielist.last_videodir.value:
            result = config.movielist.last_videodir.value
        else:
            result = "/media/"
    except Exception as e:
        print(e)
        result = "/media/"

cfg.downloadlocation = ConfigDirectory(default=result)

# ------------------------------------------------------------------
# EPG location (prefer system epgcachepath if available)
# ------------------------------------------------------------------

epg_base = "/etc/enigma2/"

try:
    if hasattr(config, "misc") and hasattr(config.misc, "epgcachepath"):
        epgcachepath = config.misc.epgcachepath.value
        if epgcachepath:
            epg_base = epgcachepath
except:
    pass

cfg.epglocation = ConfigDirectory(default=epg_base)
cfg.location = ConfigDirectory(default=dir_etc)
cfg.main = ConfigYesNo(default=True)
cfg.livepreview = ConfigYesNo(default=False)
cfg.stopstream = ConfigYesNo(default=False)
cfg.skin = ConfigSelection(default="xklass", choices=folders)
cfg.timeout = ConfigSelectionNumber(1, 20, 1, default=20, wraparound=True)
cfg.TMDB = ConfigYesNo(default=False)
cfg.TMDBLanguage2 = ConfigSelection(default="", choices=languages)
cfg.catchupstart = ConfigSelectionNumber(0, 30, 1, default=0, wraparound=True)
cfg.catchupend = ConfigSelectionNumber(0, 30, 1, default=0, wraparound=True)
cfg.subs = ConfigYesNo(default=False)
cfg.wakeup = ConfigClock(default=((9 * 60) + 30) * 60)  # 10:30
cfg.adult = ConfigYesNo(default=False)
cfg.adultpin = ConfigPIN(default=0000)
cfg.retries = ConfigSubsection()
cfg.retries.adultpin = ConfigSubsection()
cfg.retries.adultpin.tries = ConfigInteger(default=3)
cfg.retries.adultpin.time = ConfigInteger(default=3)
cfg.location_valid = ConfigYesNo(default=True)

cfg.channelpicons = ConfigYesNo(default=False)
cfg.infobarpicons = ConfigYesNo(default=False)
cfg.channelcovers = ConfigYesNo(default=False)
cfg.infobarcovers = ConfigYesNo(default=False)

cfg.introvideo = ConfigYesNo(default=False)
cfg.introloop = ConfigYesNo(default=False)
cfg.introvideoselection = ConfigSelection(choices=video_list)
cfg.speedtest = ConfigYesNo(default=False)

cfg.startmenuplaylists = ConfigYesNo(default=True)
cfg.manageplaylists = ConfigYesNo(default=True)
cfg.sidemenumanageplaylists = ConfigYesNo(default=True)
cfg.sidemenuaccountinfo = ConfigYesNo(default=True)

cfg.boot = ConfigYesNo(default=False)
cfg.useragent = ConfigSelection(default="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36", choices=useragents)
cfg.lastplaylist = ConfigText()

# Lite16 Local Remux convenience controls.
# Smart return opens the exact cached channel list that feeds the active remux.
# The exit controller waits for PAUSE, records the original satellite TS to disk,
# freezes VIDEO only, and replays that growing buffer while IPTV audio remains live.
cfg.remuxquickreturn = ConfigYesNo(default=True)
cfg.remuxvideohold = ConfigYesNo(default=True)
cfg.remuxvideoholddelay = ConfigSelectionNumber(1, 10, 1, default=2, wraparound=True)

# R31 IPAUDIO-only delay.  The value is applied by FFmpeg before the proven
# MP2/MPEG-TS local bridge, so the DVB service and native Timeshift remain
# completely owned by Enigma2.  Quarter-second steps are fine enough for lip
# sync while keeping the setting usable on old remote controls/images.
cfg.ipaudiodelayms = ConfigSelectionNumber(0, 10000, 250, default=0, wraparound=False)

cfg.vodcategoryorder = ConfigSelection(default=(_("Sort: Original")), choices=[(_("Sort: A-Z"), "A-Z"), (_("Sort: Z-A"), "Z-A"), (_("Sort: Original"), _("Original"))])
cfg.vodstreamorder = ConfigSelection(default=(_("Sort: Original")), choices=[(_("Sort: A-Z"), "A-Z"), (_("Sort: Z-A"), "Z-A"), (_("Sort: Added"), _("Added")), (_("Sort: Year"), _("Year")), (_("Sort: Original"), _("Original"))])

cfg.seriescategoryorder = ConfigSelection(default=(_("Sort: Original")), choices=[(_("Sort: A-Z"), "A-Z"), (_("Sort: Z-A"), "Z-A"), (_("Sort: Original"), _("Original"))])
cfg.seriesorder = ConfigSelection(default=(_("Sort: Original")), choices=[(_("Sort: A-Z"), "A-Z"), (_("Sort: Z-A"), "Z-A"), (_("Sort: Added"), _("Added")), (_("Sort: Year"), _("Year")), (_("Sort: Original"), _("Original"))])


# ------------------------------------------------------------------
# File paths
# ------------------------------------------------------------------

playlist_file = os.path.join(dir_etc, "playlists.txt")
playlists_json = os.path.join(dir_etc, "x-playlists.json")
downloads_json = os.path.join(dir_etc, "downloads2.json")
skin_path = os.path.join(skin_directory, cfg.skin.value)
common_path = os.path.join(skin_directory, "common/")

location = cfg.location.value

if location:
    if os.path.exists(location):
        playlist_file = os.path.join(cfg.location.value, "playlists.txt")
        cfg.location_valid.setValue(True)
    else:
        os.makedirs(location)  # Create directory if it doesn't exist
        playlist_file = os.path.join(location, "playlists.txt")

        cfg.location_valid.setValue(True)
else:
    cfg.location.setValue(dir_etc)
    cfg.location_valid.setValue(False)

cfg.playlist_file = ConfigText(playlist_file)
cfg.playlists_json = ConfigText(playlists_json)
cfg.downloads_json = ConfigText(downloads_json)
cfg.save()
configfile.save()

if os.path.isdir("/usr/lib/enigma2/python/Plugins/Extensions/InternetSpeedTest"):
    InternetSpeedTest_installed = True
else:
    InternetSpeedTest_installed = False


if os.path.isdir("/usr/lib/enigma2/python/Plugins/Extensions/NetSpeedTest"):
    NetSpeedTest_installed = True
else:
    NetSpeedTest_installed = False


# ------------------------------------------------------------------
# Check folders
# ------------------------------------------------------------------

# create folder for working files
if not os.path.exists(dir_etc):
    os.makedirs(dir_etc)

# create temporary folder for downloaded files
if not os.path.exists(dir_tmp):
    os.makedirs(dir_tmp)

# check if playlists.txt file exists in specified location
if not os.path.isfile(cfg.playlist_file.value):
    with open(cfg.playlist_file.value, "a") as f:
        f.close()

# check if x-playlists.json file exists in specified location
if not os.path.isfile(cfg.playlists_json.value):
    with open(cfg.playlists_json.value, "a") as f:
        f.close()

# check if x-downloads.json file exists in specified location
if not os.path.isfile(cfg.downloads_json.value):
    with open(cfg.downloads_json.value, "a") as f:
        f.close()


# ------------------------------------------------------------------
# Fonts (safe)
# ------------------------------------------------------------------

font_folder = os.path.join(dir_plugins, "fonts/")
for font, name in [
    ("m-plus-rounded-1c-regular.ttf", "xklassregular"),
    ("m-plus-rounded-1c-medium.ttf", "xklassbold"),
    ("slyk-medium.ttf", "slykregular"),
    ("slyk-bold.ttf", "slykbold"),
    ("classfont2.ttf", "klass"),
]:
    try:
        addFont(os.path.join(font_folder, font), name, 100, 0)
    except:
        pass


# ------------------------------------------------------------------
# Headers
# ------------------------------------------------------------------

hdr = {
    'User-Agent': str(cfg.useragent.value),
}


# ------------------------------------------------------------------
# Main entry
# ------------------------------------------------------------------

def main(session, **kwargs):
    # Retry any Telegram subscription backups that were queued while offline.
    try:
        from .remote_backup import flush_pending_async
        flush_pending_async()
    except Exception:
        pass

    # R26: while background IPAUDIO is active, reopen directly on the exact
    # cached Xtream/MAC channel list used to start that audio. No provider API
    # or category request is needed for this quick-return path.
    try:
        from .backgroundaudio import background_audio_status, get_resume_context
        active, _name, _backend = background_audio_status()
        context = get_resume_context() if active else {}
        if active and context and context.get("channels"):
            from . import audioquickreturn
            session.open(audioquickreturn.XKlass_Audio_QuickReturn)
            return
    except Exception as e:
        print("[XKlass R26] IPAUDIO quick return:", e)

    # Lite16: if a Local Remux is already feeding IPTV audio, jump straight
    # back to the exact cached channel list instead of forcing the user through
    # source/account/category selection again. This path is fully local.
    try:
        if cfg.remuxquickreturn.value:
            from .remux import is_local_remux_active, get_resume_context
            context = get_resume_context() if is_local_remux_active() else {}
            if context and context.get("channels"):
                from . import remuxreturn
                session.open(remuxreturn.XKlass_Remux_Return)
                return
    except Exception as e:
        print("[XKlass Lite16] smart return:", e)

    if os.path.exists(dir_tmp):
        shutil.rmtree(dir_tmp)
    os.makedirs(dir_tmp)

    epg_root = os.path.join(str(cfg.epglocation.value).rstrip("/"), "iptv-epg")
    if os.path.isdir(epg_root):
        epgfolder = os.path.join(epg_root, '*', '*.xml')
        for file_path in glob_module.glob(epgfolder):
            try:
                os.remove(file_path)
            except:
                pass

    from . import startmenu
    session.open(startmenu.XKlass_MainMenu)


# ------------------------------------------------------------------
# Menus / autostart / boot
# ------------------------------------------------------------------

def mainmenu(menu_id, **kwargs):
    if menu_id == "mainmenu":
        return [(_("Alkuds ipaudio"), main, "XKlass", 0)]
    return []


class XCAutoStartTimer:
    def __init__(self, session):
        self.session = session
        self.timer = eTimer()

        try:
            self.timer_conn = self.timer.timeout.connect(self.onTimer)
        except:
            self.timer.callback.append(self.onTimer)
        self.update()

    def getWakeTime(self):
        clock = cfg.wakeup.value
        nowt = time.time()
        now = time.localtime(nowt)
        return int(time.mktime((now.tm_year, now.tm_mon, now.tm_mday, clock[0], clock[1], 0, now.tm_wday, now.tm_yday, now.tm_isdst)))

    def update(self, atLeast=0):
        self.timer.stop()
        wake = self.getWakeTime()
        now = int(time.time())
        if wake < now + atLeast:
            wake += 86400
        self.timer.startLongTimer(max(60, min(3600, wake - now)))

    def onTimer(self):
        self.timer.stop()
        now = int(time.time())
        wake = self.getWakeTime()
        atLeast = 0
        if abs(wake - now) < 60:
            self.runUpdate()
            atLeast = 60
        self.update(atLeast)

    def runUpdate(self):
        print("\n *********** Updating XKlass EPG ************ \n")
        from . import update
        update.XKlass_Update(self.session)


xcAutoStartTimer = None


def autostart(reason, session=None, **kwargs):
    global xcAutoStartTimer
    if reason == 0 and session and xcAutoStartTimer is None:
        xcAutoStartTimer = XCAutoStartTimer(session)
    elif reason == 1:
        # Never leave an external background-audio process behind on GUI shutdown.
        try:
            from .backgroundaudio import stop_background_audio
            stop_background_audio()
        except Exception:
            pass
        try:
            from .remux import stop_local_remux
            stop_local_remux(restore=False)
        except Exception:
            pass


def stop_bg_audio_menu(session, **kwargs):
    try:
        from .backgroundaudio import stop_background_audio, background_audio_status
        active, name, backend = background_audio_status()
        if active:
            stop_background_audio()
            text = _("XKlass background audio stopped: %s") % name
        else:
            text = _("XKlass background audio is not running.")
    except Exception as e:
        text = _("Unable to control XKlass background audio: %s") % str(e)
    from Screens.MessageBox import MessageBox
    session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=5)


def stop_ipaudio_timeshift_menu(session, **kwargs):
    try:
        from .backgroundaudio import stop_ipaudio_and_timeshift
        had_audio, stopped_timeshift, _closed = stop_ipaudio_and_timeshift(
            session=session, close_plugin=False)
        if had_audio or stopped_timeshift:
            text = _("Alkuds ipaudio audio and native Timeshift stopped. Satellite audio restored.")
        else:
            text = _("Alkuds ipaudio audio / Timeshift is not running.")
    except Exception as e:
        text = _("Unable to stop Alkuds ipaudio / Timeshift: %s") % str(e)
    from Screens.MessageBox import MessageBox
    session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=5)



def stop_local_remux_menu(session, **kwargs):
    try:
        from .remux import stop_local_remux, local_remux_status
        active, name, backend = local_remux_status()
        if active:
            stop_local_remux(restore=True)
            text = _("XKlass Local Remux stopped. Satellite service restored.")
        else:
            text = _("XKlass Local Remux is not running.")
    except Exception as e:
        text = _("Unable to control XKlass Local Remux: %s") % str(e)
    from Screens.MessageBox import MessageBox
    session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=5)


glb_session = None
glb_startDelay = None


class StartDelay:
    def __init__(self):
        self.timerboot = eTimer()

    def start(self):
        delay = 2000

        try:
            self.timer_conn = self.timerboot.timeout.connect(self.query)
        except:
            self.timerboot.callback.append(self.query)

        self.timerboot.start(delay, True)

    def query(self):
        from . import startmenu
        glb_session.open(startmenu.XKlass_MainMenu)
        return


def bootstart(reason, **kwargs):
    print("*** bootstart ***")
    global glb_session
    global glb_startDelay
    if reason == 0 and "session" in kwargs:
        glb_session = kwargs["session"]
        glb_startDelay = StartDelay()
        glb_startDelay.start()


def Plugins(**kwargs):
    iconFile = "icons/plugin-icon_sd.png"
    if screenwidth.width() > 1280:
        iconFile = "icons/plugin-icon.png"
    description = _("MAC & XTREME player")
    pluginname = _("Alkuds ipaudio")

    main_menu = PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_MENU, fnc=mainmenu, needsRestart=True)

    extensions_menu = PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main, needsRestart=True)

    boot_start = PluginDescriptor(name=pluginname, description=description, where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART], fnc=bootstart, needsRestart=True)

    result = [PluginDescriptor(name=pluginname, description=description, where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart),
              PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_PLUGINMENU, icon=iconFile, fnc=main)]

    result.append(extensions_menu)
    result.append(PluginDescriptor(name=_("Alkuds ipaudio - STOP Audio + Timeshift"),
                                   description=_("Stop Alkuds ipaudio audio/timeshift and restore satellite"),
                                   where=PluginDescriptor.WHERE_EXTENSIONSMENU,
                                   fnc=stop_ipaudio_timeshift_menu, needsRestart=False))

    if cfg.main.value:
        result.append(main_menu)

    if cfg.boot.value:
        result.append(boot_start)

    return result
