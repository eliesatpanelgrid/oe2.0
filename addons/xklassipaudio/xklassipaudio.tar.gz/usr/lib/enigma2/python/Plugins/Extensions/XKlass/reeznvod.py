#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Reezn 2.0.19 catalogue and its native VidSrc/VixSrc HTTP resolvers.

The Android app uses TMDB for titles, seasons and episodes, and a separate
ExtractionCoordinator for playback. These are intentionally separate here too.
No Android WebView or DRM implementation is assumed on the receiver.
"""
from __future__ import print_function
import os
import re
import time
import requests
try:
    from urllib.parse import urljoin, urlparse, urlencode
    from html import unescape
except ImportError:
    from urlparse import urljoin, urlparse
    from urllib import urlencode
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'
LOG = '/tmp/xklass_reezn_vod.log'
try:
    string_types = (basestring,)
except NameError:
    string_types = (str, bytes)

def _log(message):
    try:
        with open(LOG, 'a') as handle:
            handle.write('%s %s\n' % (time.strftime('%H:%M:%S'), str(message)))
    except Exception:
        pass


def groups(kind):
    from . import freeproviders as fp
    media = 'movie' if kind == 'movie' else 'tv'
    result = []
    def add(name, path='', params=None, action=''):
        result.append({'id': path + repr(params or {}) + action, 'name': name,
                       'path': path, 'params': params or {}, 'action': action,
                       'kind': kind, 'source': 'reezn_vod_group'})
    add(u'بحث بالاسم', action='search')
    add(u'الأكثر شعبية', media + '/popular')
    add(u'الرائج هذا الأسبوع', 'trending/' + media + '/week')
    add(u'الأعلى تقييمًا', media + '/top_rated')
    if kind == 'movie':
        add(u'أفلام تعرض الآن', 'movie/now_playing')
        add(u'أفلام قادمة', 'movie/upcoming')
    else:
        add(u'حلقات تعرض اليوم', 'tv/airing_today')
        add(u'مسلسلات تعرض حاليًا', 'tv/on_the_air')
    for name, language in [(u'عربي', 'ar'), (u'تركي', 'tr'), (u'كوري', 'ko'),
                           (u'هندي', 'hi'), (u'إنجليزي', 'en'), (u'صيني', 'zh'),
                           (u'إسباني', 'es')]:
        add(name, 'discover/' + media, {'with_original_language': language, 'sort_by': 'popularity.desc'})
    add(u'تصفح حسب سنة الإنتاج', action='year')
    add(u'DramaBox - مكتبة عربية ومترجمة', action='dramabox')
    for genre in fp._tmdb_get('genre/' + media + '/list').get('genres') or []:
        if genre.get('id') is not None:
            add(str(genre.get('name') or genre['id']), 'discover/' + media,
                {'with_genres': str(genre['id']), 'sort_by': 'popularity.desc'})
    return result


def items(kind, parent, page):
    from . import freeproviders as fp
    media = 'movie' if kind == 'movie' else 'tv'
    parent = dict(parent or {})
    params = dict(parent.get('params') or {})
    params.update({'page': max(1, min(500, int(page or 1))), 'include_adult': 'false'})
    payload = fp._tmdb_get(parent.get('path') or media + '/popular', params)
    entries = [x for x in (fp._tmdb_item(r, kind) for r in payload.get('results') or []) if x]
    return {'entries': entries, 'page': int(payload.get('page') or page or 1),
            'last_page': max(1, min(500, int(payload.get('total_pages') or 1))),
            'total': int(payload.get('total_results') or len(entries))}


def servers(item):
    # VidSrc currently returns either a 403 challenge or a shell without a
    # playable frame.  Do not expose a known-broken server in the chooser;
    # keep it only as an internal last-resort fallback from VixSrc.
    row = dict(item)
    row.update({'name': 'VixSrc Auto', 'play_name': item.get('name') or 'Video',
                'resolver': 'vixsrc', 'source': 'reezn_vod'})
    return [row]


def _http(url):
    parsed = urlparse(str(url or ''))
    if parsed.scheme.lower() not in ('http', 'https') or not parsed.netloc:
        raise RuntimeError('The source returned an invalid video address')
    return url


def _get(session, url, referer='', extra=None):
    headers = {'User-Agent': UA, 'Accept': '*/*'}
    if referer:
        headers['Referer'] = referer
    headers.update(extra or {})
    with session.get(_http(url), headers=headers, timeout=(8, 18), stream=True) as response:
        if response.status_code >= 400:
            raise RuntimeError('Source returned HTTP %d' % response.status_code)
        raw = response.raw.read(2 * 1024 * 1024 + 1, decode_content=True)
        if len(raw) > 2 * 1024 * 1024:
            raise RuntimeError('Source response is too large')
        text = raw.decode('utf-8', 'replace')
        if any(marker in text.lower() for marker in ('cf-turnstile', 'just a moment...', 'cf-chl-')):
            raise RuntimeError('This source requires browser verification; choose another server')
        return text, response.url


def _match(pattern, text, message):
    match = re.search(pattern, text, re.I | re.S)
    if not match:
        raise RuntimeError(message)
    return unescape(match.group(1).replace('\\/', '/'))


def _stream(url, name, referer, mediatype='hls', extra_headers=None, relay_options=None):
    _http(url)
    headers = {'User-Agent': UA, 'Referer': referer, 'Accept': '*/*'}
    headers.update(extra_headers or {})
    options = {'live': False, 'credential_origin': url}
    options.update(relay_options or {})
    return {'name': name, 'url': url, 'source': 'reezn_vod',
            'headers': headers,
            'mediatype': mediatype, 'relay': mediatype == 'hls',
            'relay_options': options}


def _direct_hls(text, base_url):
    """Return plain HLS URLs embedded in HTML/JS before deeper parsing."""
    found = []
    pattern = r"[\"']((?:https?:)?//[^\"'<>\\\s]+(?:\.m3u8|/playlist/)[^\"'<>\\\s]*)[\"']"
    for match in re.findall(pattern, text or '', re.I):
        value = unescape(match.replace('\\/', '/')).strip()
        if value.startswith('//'):
            value = urlparse(base_url).scheme + ':' + value
        value = urljoin(base_url, value)
        if value not in found:
            found.append(value)
    return found


def _vidsrc_one(session, item, base, style='path'):
    movie = item.get('kind') == 'movie'
    if movie:
        ident = str(item.get('tmdb_id') or item.get('id') or '')
        page = base.rstrip('/') + ('/embed/movie/' + ident if style == 'path' else '/embed/movie?tmdb=' + ident)
    else:
        ident = str(item.get('series_id') or '')
        season = str(item.get('season', 1))
        episode = str(item.get('episode') or 1)
        if style == 'path':
            page = base.rstrip('/') + '/embed/tv/%s/%s/%s' % (ident, season, episode)
        else:
            page = base.rstrip('/') + '/embed/tv?' + urlencode({'tmdb': ident, 'season': season, 'episode': episode})
    if not ident:
        raise RuntimeError('VidSrc media identifier is missing')
    _log('VidSrc page %s' % page)
    text, page = _get(session, page)

    direct = _direct_hls(text, page)
    if direct:
        return [_stream(url, 'VidSrc %d' % (idx + 1), page) for idx, url in enumerate(direct[:4])]

    tags = re.findall(r'<iframe\b[^>]*>', text, re.I | re.S)
    tag = next((t for t in tags if re.search(r'\bid\s*=\s*[\"\']player_iframe[\"\']', t, re.I)), '')
    if not tag and tags:
        tag = tags[0]
    iframe = _match(r'\bsrc\s*=\s*[\"\']([^\"\']+)', tag, 'VidSrc player frame was not found')
    frame = urljoin(page, iframe)
    text, frame = _get(session, frame, page)

    direct = _direct_hls(text, frame)
    if direct:
        return [_stream(url, 'VidSrc %d' % (idx + 1), frame) for idx, url in enumerate(direct[:4])]

    route_match = re.search(r"src\s*:\s*[\"'](/prorcp/[^\"']+)|[\"'](/prorcp/[^\"']+)[\"']", text, re.I | re.S)
    if not route_match:
        raise RuntimeError('VidSrc player route was not found')
    route = route_match.group(1) or route_match.group(2)
    text, player = _get(session, urljoin(frame, route), frame)

    direct = _direct_hls(text, player)
    if direct:
        return [_stream(url, 'VidSrc %d' % (idx + 1), urljoin(frame, '/')) for idx, url in enumerate(direct[:4])]

    urls = _match(r"master_urls\s*=\s*[\"']([^\"']+)[\"']", text, 'VidSrc returned no video sources')
    endpoint = re.search(r"[\"'](https?://[^\"']+/generate\.php)[\"']", text)
    if re.search(r'__TOKEN[A-Z0-9_]*__', urls):
        if endpoint:
            token_url = endpoint.group(1)
        else:
            first = re.split(r'\s+or\s+|,', urls, flags=re.I)[0].strip()
            parsed = urlparse(_http(first))
            token_url = parsed.scheme + '://' + parsed.netloc + '/generate.php'
        token, unused = _get(session, token_url, player)
        token = token.strip()
        if not token or len(token) > 4096 or '<' in token:
            raise RuntimeError('VidSrc returned an invalid playback token')
        urls = re.sub(r'__TOKEN[A-Z0-9_]*__', lambda unused: token, urls)
    if re.search(r'__[A-Z0-9_]+__', urls):
        raise RuntimeError('VidSrc returned an unresolved playback token')
    referer = urljoin(frame, '/')
    result = []
    for url in re.split(r'\s+or\s+|,', urls, flags=re.I):
        url = unescape(url.strip().replace('\\/', '/'))
        if not url:
            continue
        url = urljoin(player, url)
        path = urlparse(url).path.lower()
        if path.endswith(('.m3u8', '.mp4')) or '/playlist/' in path:
            result.append(_stream(url, 'VidSrc %d' % (len(result) + 1), referer,
                                  'mp4' if path.endswith('.mp4') else 'hls'))
    if not result:
        raise RuntimeError('VidSrc returned no supported video URL')
    return result


def _vidsrc(session, item):
    errors = []
    for base in ('https://vidsrc.sh', 'https://vsembed.ru'):
        for style in ('path', 'query'):
            try:
                result = _vidsrc_one(session, item, base, style)
                if result:
                    _log('VidSrc resolved via %s style=%s streams=%d' % (base, style, len(result)))
                    return result
            except Exception as error:
                errors.append('%s %s: %s' % (base, style, error))
                _log('VidSrc failed %s style=%s error=%s' % (base, style, error))
    raise RuntimeError('VidSrc resolver failed: %s' % (' | '.join(errors[-3:]) or 'no source'))


def _vixsrc_ids(item):
    """Return TMDB id first, then IMDb id when TMDB exposes one."""
    movie = item.get('kind') == 'movie'
    primary = str(item.get('tmdb_id') or item.get('id')) if movie else str(item.get('series_id') or '')
    ids = []
    if primary:
        ids.append(primary)
    try:
        from . import freeproviders as fp
        media = 'movie' if movie else 'tv'
        payload = fp._tmdb_get('%s/%s/external_ids' % (media, primary)) if primary else {}
        imdb = str((payload or {}).get('imdb_id') or '').strip()
        if imdb and imdb not in ids:
            ids.append(imdb)
    except Exception as error:
        _log('VixSrc external id lookup failed: %s' % error)
    return ids


def _vixsrc_legacy(session, item):
    import json
    movie = item.get('kind') == 'movie'
    ident = str(item.get('tmdb_id') or item.get('id')) if movie else str(item.get('series_id') or '')
    path = 'movie/' + ident if movie else 'tv/%s/%s/%s' % (ident, item.get('season', 1), item.get('episode') or 1)
    api = 'https://vixsrc.to/api/' + path + '?lang=en'
    raw, unused = _get(session, api, extra={'X-Requested-With': 'XMLHttpRequest'})
    src = json.loads(raw).get('src') or ''
    if not src:
        raise RuntimeError('VixSrc legacy API has no source for this title')
    return urljoin('https://vixsrc.to/', src)


def _vixsrc_player_page(item, ident):
    movie = item.get('kind') == 'movie'
    if movie:
        return 'https://vixsrc.to/movie/%s' % ident
    season = int(item.get('season', 1) or 0)
    episode = int(item.get('episode') or 1)
    return 'https://vixsrc.to/tv/%s/%s/%s' % (ident, season, episode)


def _vixsrc_direct(session, item, ident):
    """Resolve the current public VixSrc player page directly.

    Current VixSrc embeds the signed HLS tuple in the first body script:
    url + token + expires, with canPlayFHD optionally enabling h=1.  The HLS
    requests must use the player page itself as Referer; using /api/... here
    can resolve successfully but later yields a silent 403 in the player.
    """
    base = 'https://vixsrc.to'
    page = _vixsrc_player_page(item, ident)
    _log('VixSrc page %s' % page)
    text, final_page = _get(
        session, page, referer=base + '/',
        extra={
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
        })

    # Prefer the first script in <body>, matching the current VixSrc player.
    body = re.search(r'<body\b[^>]*>(.*)</body>', text, re.I | re.S)
    area = body.group(1) if body else text
    script = re.search(r'<script\b[^>]*>(.*?)</script>', area, re.I | re.S)
    js = script.group(1) if script else area

    # Tolerate both JS object notation and JSON-ish quoted keys. Tokens are not
    # restricted to \\w because current deployments may use URL-safe symbols.
    token_match = re.search(r'(?:["\']?token["\']?)\s*:\s*["\']([^"\']*)["\']', js, re.I)
    expires_match = re.search(r'(?:["\']?expires["\']?)\s*:\s*["\']?(\d+)["\']?', js, re.I)
    url_match = re.search(r'(?:["\']?url["\']?)\s*:\s*["\']([^"\']+)["\']', js, re.I)

    if not (token_match and expires_match and url_match):
        # Some builds put the tuple outside the first script or inline a fully
        # signed /playlist/ URL. Search the full page before giving up.
        token_match = token_match or re.search(r'(?:["\']?token["\']?)\s*:\s*["\']([^"\']*)["\']', text, re.I)
        expires_match = expires_match or re.search(r'(?:["\']?expires["\']?)\s*:\s*["\']?(\d+)["\']?', text, re.I)
        url_match = url_match or re.search(r'(?:["\']?url["\']?)\s*:\s*["\']([^"\']+)["\']', text, re.I)
        if not (token_match and expires_match and url_match):
            direct = _direct_hls(text, final_page)
            signed = [u for u in direct if '/playlist/' in urlparse(u).path]
            if signed:
                return [_stream(url, 'VixSrc %d' % (idx + 1), final_page,
                                'hls', {'Origin': base, 'Sec-Fetch-Site': 'same-origin',
                                        'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Dest': 'empty'},
                                {'vixsrc': True, 'referer': final_page})
                        for idx, url in enumerate(signed[:4])]
            raise RuntimeError('VixSrc player metadata was not found')

    playlist = unescape(url_match.group(1).replace('\\/', '/')).strip()
    playlist = urljoin(final_page, playlist)
    token = token_match.group(1).strip() if token_match else ''
    expires = expires_match.group(1).strip()

    # Preserve existing query parameters. Only add values that are not already
    # present, as VixSrc occasionally returns a partially signed URL.
    additions = []
    low = playlist.lower()
    if token and 'token=' not in low:
        additions.append('token=' + token)
    if 'expires=' not in low:
        additions.append('expires=' + expires)
    can_fhd = bool(re.search(r'window\.canPlayFHD\s*=\s*true', text, re.I))
    if can_fhd and not re.search(r'(?:[?&])h=', playlist, re.I):
        additions.append('h=1')
    if additions:
        playlist += ('&' if '?' in playlist else '?') + '&'.join(additions)

    _http(playlist)
    _log('VixSrc direct resolved id=%s host=%s token=%s referer=%s' % (
        ident, urlparse(playlist).netloc or 'unknown', 'yes' if token else 'empty', final_page))
    return [_stream(playlist, 'VixSrc Auto', final_page, 'hls',
                    {'Origin': base, 'Sec-Fetch-Site': 'same-origin',
                     'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Dest': 'empty'},
                    {'vixsrc': True, 'referer': final_page})]


def _vixsrc_api(session, item):
    """Resolve current VixSrc flow: API -> embed src -> signed playlist.

    Current VixSrc does not expose the signed playback tuple on the public
    /movie or /tv page itself.  The API returns an embed src; the token,
    expires and playlist URL live in that embed page.
    """
    import json
    movie = item.get('kind') == 'movie'
    season = int(item.get('season', 1) or 0) if not movie else 0
    episode = int(item.get('episode') or 1) if not movie else 0
    ids = _vixsrc_ids(item)
    if not ids:
        raise RuntimeError('VixSrc media identifier is missing')

    errors = []
    base = 'https://vixsrc.to'
    for ident in ids:
        api_path = ('/api/movie/%s' % ident) if movie else ('/api/tv/%s/%s/%s' % (ident, season, episode))
        api_url = base + api_path
        try:
            _log('VixSrc API %s' % api_url)
            raw, final_api = _get(
                session, api_url, referer=base,
                extra={
                    'Accept': 'application/json, text/javascript, */*; q=0.01',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Origin': base,
                    'X-Requested-With': 'XMLHttpRequest',
                })
            try:
                payload = json.loads(raw)
            except Exception:
                raise RuntimeError('VixSrc API returned invalid JSON')
            src = str((payload or {}).get('src') or '').strip()
            if not src:
                raise RuntimeError('VixSrc API returned no embed source')

            embed_url = urljoin(base + '/', src)
            _log('VixSrc embed %s' % embed_url)
            text, final_embed = _get(
                session, embed_url, referer=base + '/',
                extra={
                    'Accept': 'text/html,application/xhtml+xml,*/*',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Origin': base,
                })

            # Current embed pages expose these fields in JS.  Keep the regexes
            # tolerant to quoted/unquoted keys and escaped slashes.
            url_match = re.search(r'(?:["\']?url["\']?)\s*:\s*["\']([^"\']+)["\']', text, re.I)
            token_match = re.search(r'(?:["\']?token["\']?)\s*:\s*["\']([^"\']*)["\']', text, re.I)
            expires_match = re.search(r'(?:["\']?expires["\']?)\s*:\s*["\']?(\d+)["\']?', text, re.I)

            if not (url_match and expires_match):
                # Some builds inline the already signed /playlist/ URL.
                direct = _direct_hls(text, final_embed)
                signed = [u for u in direct if '/playlist/' in urlparse(u).path]
                if signed:
                    return [_stream(url, 'VixSrc %d' % (idx + 1), api_url,
                                    'hls', {'Origin': base})
                            for idx, url in enumerate(signed[:4])]
                raise RuntimeError('VixSrc embed did not expose playlist metadata')

            playlist = unescape(url_match.group(1).replace('\\/', '/')).strip()
            playlist = urljoin(final_embed, playlist)
            token = token_match.group(1) if token_match else ''
            expires = expires_match.group(1).strip()
            if not expires:
                raise RuntimeError('VixSrc playback expiry is missing')

            sep = '&' if '?' in playlist else '?'
            params = []
            if token:
                params.append('token=' + token)
            params.extend(['expires=' + expires, 'h=1'])
            stream_url = playlist + sep + '&'.join(params)
            _http(stream_url)
            _log('VixSrc resolved id=%s playlist host=%s token=%s' % (
                ident, urlparse(stream_url).netloc or 'unknown', 'yes' if token else 'empty'))
            return [_stream(stream_url, 'VixSrc Auto', api_url, 'hls',
                            {'Origin': base})]
        except Exception as error:
            errors.append('%s: %s' % (ident, error))
            _log('VixSrc id=%s failed: %s' % (ident, error))

    raise RuntimeError('VixSrc resolver failed: %s' % (' | '.join(errors[-3:]) or 'no source'))



def _vixsrc(session, item):
    """Resolve VixSrc with the public player flow first, then legacy API."""
    ids = _vixsrc_ids(item)
    if not ids:
        raise RuntimeError('VixSrc media identifier is missing')
    errors = []
    for ident in ids:
        try:
            return _vixsrc_direct(session, item, ident)
        except Exception as error:
            errors.append('%s direct: %s' % (ident, error))
            _log('VixSrc direct id=%s failed: %s' % (ident, error))
    try:
        result = _vixsrc_api(session, item)
        # The API fallback must still send the public player page as Referer.
        if result:
            ident = ids[0]
            referer = _vixsrc_player_page(item, ident)
            for stream in result:
                stream.setdefault('headers', {})['Referer'] = referer
                stream['headers']['Origin'] = 'https://vixsrc.to'
                options = dict(stream.get('relay_options') or {})
                options.pop('reezn', None)
                options.update({'vixsrc': True, 'referer': referer})
                stream['relay_options'] = options
            _log('VixSrc API fallback streams=%d referer=%s' % (len(result), referer))
            return result
    except Exception as error:
        errors.append('api: %s' % error)
        _log('VixSrc API fallback failed: %s' % error)
    raise RuntimeError('VixSrc resolver failed: %s' % (' | '.join(errors[-4:]) or 'no source'))



def _collect_stream_urls(value, out=None):
    """Collect plausible direct media URLs from a JSON payload."""
    if out is None:
        out = []
    if isinstance(value, dict):
        # Prefer well-known direct-stream fields first.
        for key in ('stream_url', 'streamUrl', 'hls', 'hls_url', 'hlsUrl', 'url', 'source', 'file'):
            candidate = value.get(key)
            if isinstance(candidate, string_types):
                try:
                    candidate = candidate.decode('utf-8', 'replace') if isinstance(candidate, bytes) else candidate
                except Exception:
                    pass
                candidate = str(candidate or '').strip().replace('\\/', '/')
                if candidate.startswith(('http://', 'https://')) and candidate not in out:
                    out.append(candidate)
        for child in value.values():
            _collect_stream_urls(child, out)
    elif isinstance(value, (list, tuple)):
        for child in value:
            _collect_stream_urls(child, out)
    elif isinstance(value, string_types):
        try:
            value = value.decode('utf-8', 'replace') if isinstance(value, bytes) else value
        except Exception:
            pass
        value = str(value or '').strip().replace('\\/', '/')
        if value.startswith(('http://', 'https://')) and value not in out:
            out.append(value)
    return out


def _ezvidapi_provider_list(session):
    """Return provider slugs advertised by ezvidapi, with safe fallbacks."""
    import json
    providers = []
    try:
        raw, unused = _get(
            session, 'https://api.ezvidapi.com/list',
            referer='https://ezvidapi.com/',
            extra={'Accept': 'application/json', 'Origin': 'https://ezvidapi.com'})
        payload = json.loads(raw)
        def walk(obj):
            if isinstance(obj, dict):
                for key in ('id', 'slug', 'provider', 'name'):
                    val = obj.get(key)
                    if isinstance(val, string_types):
                        try:
                            val = val.decode('utf-8', 'replace') if isinstance(val, bytes) else val
                        except Exception:
                            pass
                        val = str(val or '').strip().lower()
                        if re.match(r'^[a-z0-9_-]{2,40}$', val) and val not in providers:
                            providers.append(val)
                for child in obj.values():
                    walk(child)
            elif isinstance(obj, (list, tuple)):
                for child in obj:
                    walk(child)
        walk(payload)
    except Exception as error:
        _log('Backup provider list failed: %s' % error)
    # Names documented by the service and commonly returned by /list.
    for val in ('vidsrc', 'consumet', 'superembed', '2embed'):
        if val not in providers:
            providers.append(val)
    return providers[:10]


def _ezvidapi(session, item):
    """Fallback direct-HLS resolver by TMDB id.

    Used only when VixSrc has no playable entry for the title/episode.
    """
    import json
    movie = item.get('kind') == 'movie'
    ident = str(item.get('tmdb_id') or item.get('id') or '') if movie else str(item.get('series_id') or '')
    if not ident:
        raise RuntimeError('Backup resolver media identifier is missing')
    season = int(item.get('season', 1) or 1)
    episode = int(item.get('episode') or 1)
    errors = []
    for provider in _ezvidapi_provider_list(session):
        if movie:
            endpoint = 'https://api.ezvidapi.com/movie/%s/%s' % (provider, ident)
        else:
            endpoint = 'https://api.ezvidapi.com/tv/%s/%s?%s' % (
                provider, ident, urlencode({'season': season, 'episode': episode}))
        try:
            _log('Backup API provider=%s url=%s' % (provider, endpoint))
            raw, final_url = _get(
                session, endpoint, referer='https://ezvidapi.com/',
                extra={'Accept': 'application/json', 'Origin': 'https://ezvidapi.com'})
            payload = json.loads(raw)
            urls = _collect_stream_urls(payload)
            # Do not mistake artwork/API links for video. Prefer obvious HLS/MP4.
            media = []
            for url in urls:
                low = url.lower()
                if any(x in low for x in ('.m3u8', '/playlist/', '.mp4', 'manifest')):
                    media.append(url)
            if not media and urls:
                # The documented endpoint returns stream_url; accept the first
                # HTTPS URL if no extension is present.
                media = urls[:1]
            if not media:
                raise RuntimeError('provider returned no direct stream URL')
            payload_headers = payload.get('headers') if isinstance(payload, dict) else None
            if not isinstance(payload_headers, dict):
                payload_headers = {}
            streams = []
            for idx, url in enumerate(media[:4]):
                path = urlparse(url).path.lower()
                mediatype = 'mp4' if path.endswith('.mp4') else 'hls'
                streams.append(_stream(
                    url, 'Backup %s %d' % (provider, idx + 1),
                    'https://ezvidapi.com/', mediatype,
                    payload_headers, {'referer': 'https://ezvidapi.com/'}))
            _log('Backup API resolved provider=%s streams=%d' % (provider, len(streams)))
            return streams
        except Exception as error:
            errors.append('%s: %s' % (provider, error))
            _log('Backup API provider=%s failed: %s' % (provider, error))
    raise RuntimeError('Backup resolver failed: %s' % (' | '.join(errors[-4:]) or 'no source'))

def resolve(item):
    resolver = item.get('resolver') or 'vixsrc'
    try:
        if os.path.exists(LOG) and os.path.getsize(LOG) > 256 * 1024:
            os.remove(LOG)
    except Exception:
        pass
    _log('NEW resolver=%s kind=%s id=%s series=%s s=%s e=%s' % (
        resolver, item.get('kind'), item.get('tmdb_id') or item.get('id'),
        item.get('series_id'), item.get('season'), item.get('episode')))
    with requests.Session() as session:
        if resolver == 'vidsrc':
            streams = _vidsrc(session, item)
        elif resolver == 'vixsrc':
            # Keep the now-working VixSrc path first.  If the title/episode is
            # missing there (commonly HTTP 404 for newer TMDB entries), try a
            # direct-HLS multi-provider fallback by the same TMDB id.
            try:
                streams = _vixsrc(session, item)
            except Exception as primary_error:
                _log('VixSrc primary failed; trying backup: %s' % primary_error)
                try:
                    streams = _ezvidapi(session, item)
                except Exception as backup_error:
                    raise RuntimeError('VixSrc failed: %s ; backup failed: %s' % (primary_error, backup_error))
        else:
            raise RuntimeError('Unknown Reezn video server')
    _log('DONE resolver=%s streams=%d' % (resolver, len(streams or [])))
    return {'id': item.get('id'), 'name': item.get('play_name') or item.get('name') or 'Video',
            'image': item.get('image') or '', 'description': item.get('description') or '',
            'kind': item.get('kind'), 'source': 'reezn_vod', 'streams': streams,
            'url': streams[0]['url'], 'urls': [s['url'] for s in streams],
            'headers': streams[0]['headers']}

