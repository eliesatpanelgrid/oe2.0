#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Export to IPAudio Pro/legacy and mirror into Alkuds Free IPAUDIO."""
from __future__ import print_function

import glob
import json
import os
import shutil
import time


PRO_FILENAME = 'IPAudioPro.json'
LEGACY_FILENAME = 'ipaudio.json'
PRO_WRONG_CASE_FILENAMES = ('ipaudiopro.json',)


def _candidate_paths(filename):
    paths = [
        os.path.join('/etc/enigma2', filename),
        os.path.join('/media/hdd', filename),
        os.path.join('/media/hdd/etc/enigma2', filename),
        os.path.join('/media/usb', filename),
        os.path.join('/media/mmc', filename),
        os.path.join('/media/cf', filename),
    ]
    try:
        paths.extend(sorted(glob.glob('/media/*/' + filename)))
        paths.extend(sorted(glob.glob('/media/*/etc/enigma2/' + filename)))
    except Exception:
        pass
    out=[]
    for path in paths:
        if path and path not in out:
            out.append(path)
    return out


def find_target(kind):
    filename = PRO_FILENAME if str(kind) == 'pro' else LEGACY_FILENAME
    for path in _candidate_paths(filename):
        if os.path.isfile(path):
            return path
    return os.path.join('/etc/enigma2', filename)


def _export_targets(kind):
    """Return the active target plus writable ETC/HDD mirrors."""
    filename = PRO_FILENAME if str(kind) == 'pro' else LEGACY_FILENAME
    paths = [find_target(kind)]
    for folder in ('/etc/enigma2', '/media/hdd'):
        if not os.path.isdir(folder) or not os.access(folder, os.W_OK):
            continue
        path = os.path.join(folder, filename)
        if path not in paths:
            paths.append(path)
    return paths


def _load_source_for_target(path, kind):
    """Read an older wrong-case Pro file when the canonical file is absent.

    Linux filenames are case-sensitive.  Earlier Alkuds builds wrote
    ``ipaudiopro.json`` while IPAudio Pro reads ``IPAudioPro.json``.  Migrate
    the old content into the correctly cased target on the next export instead
    of silently losing the user's existing entries.
    """
    if os.path.isfile(path) or str(kind) != 'pro':
        return path
    folder = os.path.dirname(path) or '.'
    for filename in PRO_WRONG_CASE_FILENAMES:
        candidate = os.path.join(folder, filename)
        if os.path.isfile(candidate):
            return candidate
    return path


def _load_json(path, default):
    if not os.path.isfile(path) or os.path.getsize(path) <= 0:
        return default
    with open(path, 'rb') as f:
        raw=f.read()
    if not raw:
        return default
    try:
        text=raw.decode('utf-8-sig')
    except Exception:
        text=raw.decode('utf-8','replace') if hasattr(raw,'decode') else raw
    data=json.loads(text)
    return data


def _atomic_write(path, data):
    folder=os.path.dirname(path) or '.'
    if not os.path.isdir(folder):
        os.makedirs(folder)
    if os.path.isfile(path):
        try:
            shutil.copy2(path, path + '.bak')
        except Exception:
            pass
    payload=json.dumps(data, ensure_ascii=False, indent=4, sort_keys=False)
    if not isinstance(payload, bytes):
        payload=payload.encode('utf-8')
    tmp=path + '.tmp.%d' % int(time.time()*1000)
    with open(tmp,'wb') as f:
        f.write(payload)
        f.write(b'\n')
        try:
            f.flush(); os.fsync(f.fileno())
        except Exception:
            pass
    try:
        os.chmod(tmp, 0o644)
    except Exception:
        pass
    os.rename(tmp, path)


def _append_pro(data, name, url):
    if not isinstance(data, dict):
        data={}
    group=data.get('Playlist')
    if not isinstance(group, dict):
        group={}
        data['Playlist']=group
    streams=group.get('streams')
    if not isinstance(streams, list):
        streams=[]
        group['streams']=streams
    for item in streams:
        if isinstance(item, dict) and str(item.get('url') or '') == url:
            if not item.get('display_name'):
                item['display_name']=name
            if not item.get('name'):
                item['name']=name
            return data, False
    streams.append({'name': name, 'display_name': name, 'url': url})
    return data, True


def _append_legacy(data, name, url):
    if not isinstance(data, dict):
        data={}
    streams=data.get('playlist')
    if not isinstance(streams, list):
        streams=[]
        data['playlist']=streams
    for item in streams:
        if isinstance(item, dict) and str(item.get('url') or '') == url:
            if not item.get('channel'):
                item['channel']=name
            return data, False
    streams.append({'channel': name, 'url': url})
    return data, True


def export_channel(kind, channel_name, stream_url):
    kind='pro' if str(kind).lower() in ('pro','ipaudiopro','ipaudio pro') else 'legacy'
    name=str(channel_name or 'Channel').strip() or 'Channel'
    url=str(stream_url or '').strip()
    if not url:
        raise ValueError('No playable stream URL')
    paths=_export_targets(kind)
    path=paths[0]
    added=False
    for target in paths:
        target_default={} if kind == 'pro' else {'playlist': []}
        source = _load_source_for_target(target, kind)
        try:
            data=_load_json(source, target_default)
        except Exception as e:
            raise ValueError('Invalid JSON in %s: %s' % (source, e))
        if kind == 'pro':
            data, target_added=_append_pro(data, name, url)
        else:
            data, target_added=_append_legacy(data, name, url)
        _atomic_write(target, data)
        added=bool(added or target_added)
    # Keep the Alkuds shared source file in both /etc and /media/hdd in sync.
    # Import lazily to preserve startup compatibility on older Enigma2 images.
    try:
        from .audiofeeds import add_free_audio_source
        add_free_audio_source(name, url)
    except Exception as e:
        raise IOError('External IPAudio file was saved, but Free IPAUDIO sync failed: %s' % e)
    return path, added
