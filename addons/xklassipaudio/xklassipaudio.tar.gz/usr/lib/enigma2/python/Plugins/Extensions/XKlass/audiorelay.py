#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Persistent IPTV-audio fan-out relay for IPAudio AlQuds.

One upstream FFmpeg connection reads the selected Xtream/Stalker stream and
transcodes its first audio track to MP2/MPEG-TS. A lightweight Python UDP fanout
copies that local TS to several loopback ports. Local A/V remux instances can
therefore overlap during satellite-delay handovers without opening a second
provider connection or requesting a second Stalker play_token.
"""
from __future__ import print_function

import os
import socket
import subprocess
import threading
import time

LOG = "/tmp/xklass-backgroundaudio.log"
_LOCK = threading.RLock()
_RESERVED = set()
_UDP_CURSOR = 18200


def _find_executable(name):
    for base in ("/usr/bin", "/bin", "/usr/local/bin"):
        path = os.path.join(base, name)
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    return ""


def _log(msg):
    try:
        with open(LOG, "a") as f:
            f.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), str(msg)))
    except Exception:
        pass


def _terminate(proc):
    if not proc:
        return
    try:
        if proc.poll() is None:
            proc.terminate()
            end = time.time() + 0.8
            while proc.poll() is None and time.time() < end:
                time.sleep(0.05)
            if proc.poll() is None:
                proc.kill()
    except Exception:
        pass


def _udp_port_free(port):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.bind(("127.0.0.1", int(port)))
        return True
    except Exception:
        return False
    finally:
        try:
            s.close()
        except Exception:
            pass


def _allocate_bank(count=4):
    global _UDP_CURSOR
    count = max(2, int(count or 4))
    with _LOCK:
        start = int(_UDP_CURSOR or 18200)
        candidates = list(range(start, 18960)) + list(range(18200, start))
        for base in candidates:
            ports = list(range(base, base + count))
            if ports[-1] >= 18960:
                continue
            if any(p in _RESERVED for p in ports):
                continue
            if not all(_udp_port_free(p) for p in ports):
                continue
            for p in ports:
                _RESERVED.add(p)
            _UDP_CURSOR = ports[-1] + 1
            if _UDP_CURSOR >= 18960:
                _UDP_CURSOR = 18200
            return ports
    raise RuntimeError("No free local UDP bank for IPTV audio relay")


def _release_bank(ports):
    with _LOCK:
        for p in list(ports or []):
            try:
                _RESERVED.discard(int(p))
            except Exception:
                pass


def _http_input_options(url, headers):
    opts = []
    if not str(url or "").lower().startswith(("http://", "https://")):
        return opts
    h = dict(headers or {})
    user_agent = str(h.pop("User-Agent", "") or "").strip()
    if user_agent:
        opts += ["-user_agent", user_agent]
    extra = []
    for key in ("X-User-Agent", "Cookie", "Referer"):
        value = str(h.get(key, "") or "").replace("\r", " ").replace("\n", " ").strip()
        if value:
            extra.append("%s: %s\r\n" % (key, value))
    if extra:
        opts += ["-headers", "".join(extra)]
    # Lite24: do not add the reconnect_* AVOptions here. Several Enigma2
    # images ship older/vendor FFmpeg builds where those options either fail
    # before opening the Xtream URL or are implemented differently.  The
    # direct-input profile below deliberately mirrors the Local Remux input
    # options which were already proven to work on Xtream in Lite22.
    return opts


def _relay_command(ffmpeg, url, headers):
    cmd = [
        ffmpeg,
        "-nostdin", "-hide_banner", "-loglevel", "error",
        "-fflags", "+discardcorrupt+genpts",
        "-probesize", "4194304", "-analyzeduration", "2000000",
        "-thread_queue_size", "512",
    ]
    cmd += _http_input_options(url, headers)
    cmd += [
        "-i", str(url),
        "-map", "0:a:0",
        "-vn", "-sn", "-dn",
        "-c:a", "mp2", "-b:a", "128k", "-ar", "48000", "-ac", "2",
        "-muxdelay", "0", "-muxpreload", "0",
        "-mpegts_flags", "+resend_headers",
        "-f", "mpegts", "pipe:1",
    ]
    return cmd


def _fanout_worker(relay):
    proc = relay.get("proc")
    stop = relay.get("stop")
    ports = list(relay.get("ports") or [])
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 262144)
    except Exception:
        pass
    buffer_data = b""
    sent_packets = 0
    try:
        fd = proc.stdout.fileno() if proc and proc.stdout else -1
        while stop is not None and not stop.is_set():
            if proc is None:
                relay["error"] = "IPTV audio relay process is missing"
                break
            code = proc.poll()
            if code is not None:
                relay["error"] = "IPTV audio relay FFmpeg exit %s" % code
                break
            try:
                chunk = os.read(fd, 10528)  # 56 MPEG-TS packets maximum.
            except Exception as e:
                relay["error"] = "IPTV audio relay read failed: %s" % e
                break
            if not chunk:
                code = proc.poll()
                if code is not None:
                    relay["error"] = "IPTV audio relay FFmpeg exit %s" % code
                    break
                time.sleep(0.02)
                continue
            buffer_data += chunk
            # 1316 bytes = 7 x 188-byte TS packets, ideal for UDP transport.
            while len(buffer_data) >= 1316:
                packet = buffer_data[:1316]
                buffer_data = buffer_data[1316:]
                for port in ports:
                    try:
                        sock.sendto(packet, ("127.0.0.1", int(port)))
                    except Exception:
                        pass
                sent_packets += 1
                if not relay.get("ready") and sent_packets >= 2:
                    relay["ready"] = True
                    relay["ready_at"] = time.time()
                    _log("relay ready label=%s ports=%s" % (relay.get("label", "IPTV"), ",".join([str(x) for x in ports])))
    except Exception as e:
        relay["error"] = "IPTV audio fanout failed: %s" % e
    finally:
        try:
            sock.close()
        except Exception:
            pass
        relay["ended"] = True
        if relay.get("error"):
            _log(relay.get("error"))


def reserve_relay(url, headers=None, label="IPTV", truncate_log=False):
    """Reserve a local UDP fanout bank without opening the IPTV provider yet.

    Lite24 R3 uses this for deterministic Local Remux startup: the main FFmpeg
    is started first and allowed to bind its UDP audio input. Only then is the
    provider connection activated, so the first MPEG-TS packets cannot be lost
    before a receiver exists.
    """
    url = str(url or "").strip()
    if not url:
        raise RuntimeError("No IPTV URL for audio relay")
    ffmpeg = _find_executable("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg is not installed")
    if truncate_log:
        try:
            open(LOG, "w").close()
        except Exception:
            pass
    ports = _allocate_bank(4)
    relay = {
        "proc": None,
        "stderr": None,
        "ports": ports,
        "stop": threading.Event(),
        "thread": None,
        "url": url,
        "headers": dict(headers or {}),
        "label": str(label or "IPTV"),
        "started": 0.0,
        "ready": False,
        "ready_at": 0.0,
        "ended": False,
        "error": "",
        "next_slot": 0,
        "reserved": True,
        "activated": False,
        "released": False,
    }
    _log("reserved audio relay label=%s ports=%s" % (
        str(label or "IPTV"), ",".join([str(x) for x in ports])))
    return relay


def activate_relay(relay):
    """Open the provider connection for a previously reserved relay."""
    if not relay:
        raise RuntimeError("No reserved IPTV audio relay")
    if relay.get("activated"):
        if relay_alive(relay):
            return relay
        raise RuntimeError(relay_error(relay) or "IPTV audio relay is no longer running")

    ffmpeg = _find_executable("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg is not installed")
    logfh = None
    proc = None
    try:
        logfh = open(LOG, "a")
        _log("activating single-upstream audio relay label=%s" % str(relay.get("label") or "IPTV"))
        cmd = _relay_command(ffmpeg, str(relay.get("url") or ""), dict(relay.get("headers") or {}))
        proc = subprocess.Popen(
            cmd,
            stdin=open(os.devnull, "rb"),
            stdout=subprocess.PIPE,
            stderr=logfh,
            close_fds=True,
            bufsize=0,
        )
        relay["proc"] = proc
        relay["stderr"] = logfh
        relay["started"] = time.time()
        relay["ready"] = False
        relay["ready_at"] = 0.0
        relay["ended"] = False
        relay["error"] = ""
        relay["activated"] = True
        t = threading.Thread(target=_fanout_worker, args=(relay,))
        t.daemon = True
        relay["thread"] = t
        t.start()
        return relay
    except Exception:
        _terminate(proc)
        if logfh:
            try:
                logfh.close()
            except Exception:
                pass
        relay["proc"] = None
        relay["stderr"] = None
        relay["activated"] = False
        relay["error"] = "Unable to activate IPTV audio relay"
        raise


def start_relay(url, headers=None, label="IPTV", truncate_log=False):
    relay = reserve_relay(url, headers, label, truncate_log)
    try:
        return activate_relay(relay)
    except Exception:
        stop_relay(relay)
        raise


def restart_relay(relay, release_wait=0.65):
    """Restart only the provider side while keeping the same UDP bank.

    This is important during initial Local Remux startup: the main FFmpeg is
    already bound to one of these UDP ports, so a retry must not allocate a new
    port or the receiver would keep waiting on the old one.
    """
    if not relay:
        raise RuntimeError("No IPTV audio relay to restart")
    try:
        stop = relay.get("stop")
        if stop is not None:
            stop.set()
    except Exception:
        pass
    _terminate(relay.get("proc"))
    try:
        if relay.get("proc") is not None and relay.get("proc").stdout:
            relay.get("proc").stdout.close()
    except Exception:
        pass
    fh = relay.get("stderr")
    if fh:
        try:
            fh.close()
        except Exception:
            pass
    t = relay.get("thread")
    if t:
        try:
            t.join(0.8)
        except Exception:
            pass
    if release_wait:
        try:
            time.sleep(max(0.0, float(release_wait)))
        except Exception:
            pass
    relay["proc"] = None
    relay["stderr"] = None
    relay["thread"] = None
    relay["stop"] = threading.Event()
    relay["ready"] = False
    relay["ready_at"] = 0.0
    relay["ended"] = False
    relay["error"] = ""
    relay["activated"] = False
    _log("restarting provider on existing audio relay ports=%s" % ",".join([str(x) for x in relay.get("ports") or []]))
    return activate_relay(relay)


def stop_relay(relay):
    if not relay:
        return
    try:
        stop = relay.get("stop")
        if stop is not None:
            stop.set()
    except Exception:
        pass
    _terminate(relay.get("proc"))
    try:
        if relay.get("proc") is not None and relay.get("proc").stdout:
            relay.get("proc").stdout.close()
    except Exception:
        pass
    fh = relay.get("stderr")
    if fh:
        try:
            fh.close()
        except Exception:
            pass
    if not relay.get("released"):
        _release_bank(relay.get("ports") or [])
        relay["released"] = True
    relay["ended"] = True


def relay_alive(relay):
    if not relay:
        return False
    if not relay.get("activated"):
        return False
    proc = relay.get("proc")
    try:
        return proc is not None and proc.poll() is None and not relay.get("ended")
    except Exception:
        return False


def relay_ready(relay):
    return bool(relay and relay.get("ready") and relay_alive(relay))


def relay_error(relay):
    if not relay:
        return "IPTV audio relay is unavailable"
    value = str(relay.get("error") or "")
    if value:
        return value
    proc = relay.get("proc")
    if proc is not None:
        try:
            code = proc.poll()
            if code is not None:
                return "IPTV audio relay FFmpeg exit %s" % code
        except Exception:
            pass
    return ""


def relay_input_url(relay, slot=None):
    if not relay:
        return "", 0
    ports = list(relay.get("ports") or [])
    if not ports:
        return "", 0
    if slot is None:
        slot = int(relay.get("next_slot") or 0) % len(ports)
        relay["next_slot"] = (slot + 1) % len(ports)
    else:
        slot = int(slot) % len(ports)
    port = int(ports[slot])
    # Each Local Remux gets a dedicated fanout destination, so the old and new
    # remux can overlap safely while handover is committed.
    # Lite24 R5: use a plain loopback UDP URL.  A number of vendor/older
    # Enigma2 FFmpeg builds reject fifo_size/overrun_nonfatal when those AVOptions
    # are embedded in the URL, producing "Error opening input file udp://...".
    # Loopback fanout is tiny and dedicated, so these options are not required.
    return "udp://127.0.0.1:%d" % port, slot
