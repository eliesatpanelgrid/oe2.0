#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Small localhost HLS relay.

Ostora live streams are handed to the Android Url Video Player through a
custom HLS data source.  Besides ordinary HLS URL rewriting that data source
honours a few private manifest tags and unwraps media segments carried inside
PNG/sTeG containers.  Enigma2 does not know about those extensions, so the
relay reproduces only the network/media transformations needed for playback.
"""

from __future__ import print_function

import base64
import binascii
import hashlib
import hmac
import os
import re
import select
import socket
import struct
import subprocess
import threading
import time
import uuid

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import unquote, urljoin, urlparse
except ImportError:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from urllib import unquote
    from urlparse import urljoin, urlparse

import requests


_LOCK = threading.RLock()
_SESSIONS = {}
_SERVER = None
_SERVER_THREAD = None
_LOG_PATH = "/tmp/xklass_ostora_relay.log"
_VOD_LOG_PATH = "/tmp/xklass_reezn_vod.log"
_PNG_SIG = b"\x89PNG\r\n\x1a\n"
_MAX_WRAPPED_SEGMENT = 32 * 1024 * 1024
_DEFAULT_MINI_PASSWORD = "eb6f33a0d660e06d08b12e2f221c38a8d341cbff8157675e397a83d672b60b94"


def _as_bytes(value):
    if isinstance(value, bytes):
        return value
    return str(value or "").encode("utf-8")


def _hex(value):
    try:
        return binascii.hexlify(value).decode("ascii")
    except Exception:
        return _safe_text(binascii.hexlify(value))


def _byte_value(value):
    return value if isinstance(value, int) else ord(value)


def _raw_bytes(value):
    if isinstance(value, bytes):
        return value
    try:
        return binascii.unhexlify(binascii.hexlify(value))
    except Exception:
        return _as_bytes(value)


def _safe_text(value):
    try:
        return str(value or "")
    except Exception:
        return ""


def _log(message):
    """Tiny bounded diagnostic log; never let logging interrupt playback."""
    try:
        text = "%s\n" % _safe_text(message).replace("\r", " ").replace("\n", " ")
        # Keep the file useful on small receiver flash/tmp filesystems.
        try:
            if os.path.exists(_LOG_PATH) and os.path.getsize(_LOG_PATH) > 256 * 1024:
                with open(_LOG_PATH, "rb") as old:
                    tail = old.read()[-96 * 1024:]
                with open(_LOG_PATH, "wb") as new:
                    new.write(tail)
        except Exception:
            pass
        with open(_LOG_PATH, "ab") as handle:
            handle.write(_as_bytes(text))
    except Exception:
        pass


def _vod_log(message):
    """Append VixSrc relay diagnostics to the Reezn VOD log."""
    try:
        with open(_VOD_LOG_PATH, "ab") as handle:
            handle.write(_as_bytes("%s RELAY %s\n" % (time.strftime("%H:%M:%S"), _safe_text(message).replace("\r", " ").replace("\n", " "))))
    except Exception:
        pass


def _strip_manifest_value(value):
    value = _safe_text(value).strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
        value = value[1:-1]
    try:
        value = unquote(value)
    except Exception:
        pass
    return value.strip()


def _parse_hls_options(text, inherited=None):
    """Parse the private tags used by Url Video Player's HLS DataSource."""
    options = dict(inherited or {})
    custom = dict(options.get("headers") or {})
    seen = []
    for raw_line in _safe_text(text).splitlines():
        line = raw_line.strip()
        upper = line.upper()
        if upper.startswith("#EXT-X-MEDIA-UA:"):
            value = _strip_manifest_value(line.split(":", 1)[1])
            if value:
                options["user_agent"] = value
                seen.append("UA")
        elif upper.startswith("#EXT-X-MEDIA-REF:"):
            value = _strip_manifest_value(line.split(":", 1)[1])
            if value:
                options["referer"] = value
                seen.append("REF")
        elif upper.startswith("#EXT-X-MEDIA-HTTP:"):
            value = _strip_manifest_value(line.split(":", 1)[1])
            if value:
                options["http"] = value
                seen.append("HTTP=%s" % value)
        elif upper.startswith("#EXT-X-MEDIA-HEADER:"):
            value = line.split(":", 1)[1].strip()
            if ":" in value:
                name, header_value = value.split(":", 1)
            elif "=" in value:
                name, header_value = value.split("=", 1)
            else:
                continue
            name = name.strip()
            header_value = _strip_manifest_value(header_value)
            if name and header_value and "\r" not in name + header_value and "\n" not in name + header_value:
                custom[name] = header_value
                seen.append("HEADER:%s" % name)
        elif upper.startswith("#EXT-X-ENCRYPTION:"):
            match = re.search(r"(?:^|,)\s*PASSWORD\s*=\s*(\"[^\"]*\"|'[^']*'|[^,\s]+)",
                              line.split(":", 1)[1], re.I)
            if match:
                password = _strip_manifest_value(match.group(1))
                if password:
                    options["password"] = password
                    seen.append("PASSWORD")
    if custom:
        options["headers"] = custom
    return options, seen


def _origin_from_referer(referer):
    try:
        parsed = urlparse(referer)
        if not parsed.scheme or not parsed.netloc:
            return ""
        return "%s://%s" % (parsed.scheme, parsed.netloc)
    except Exception:
        return ""


def _browser_headers(base, options):
    headers = dict(base or {})
    options = dict(options or {})
    ua = _safe_text(options.get("user_agent") or headers.get("User-Agent") or headers.get("user-agent")).strip()
    if ua:
        headers["User-Agent"] = ua
        headers.pop("user-agent", None)
    headers.setdefault("Accept", "*/*")
    headers.setdefault("Accept-Encoding", "identity")
    if "Mozilla/" in ua:
        headers.setdefault("Accept-Language", "en-US,en;q=0.9")
        headers.setdefault("Sec-Fetch-Dest", "empty")
        headers.setdefault("Sec-Fetch-Mode", "cors")
        headers.setdefault("Sec-Fetch-Site", "cross-site")
    if "Chrome/" in ua:
        match = re.search(r"Chrome/(\d+)", ua)
        major = match.group(1) if match else "150"
        headers.setdefault("sec-ch-ua", '"Not_A Brand";v="99", "Chromium";v="%s", "Google Chrome";v="%s"' % (major, major))
        headers.setdefault("sec-ch-ua-mobile", "?1" if ("Mobile" in ua or "Android" in ua) else "?0")
        platform = "Android" if "Android" in ua else ("Windows" if "Windows" in ua else "Linux")
        headers.setdefault("sec-ch-ua-platform", '"%s"' % platform)
    referer = _safe_text(options.get("referer") or headers.get("Referer") or headers.get("referer")).strip()
    if referer:
        headers["Referer"] = referer
        headers.pop("referer", None)
        origin = _origin_from_referer(referer)
        if origin:
            headers.setdefault("Origin", origin)
    for key, value in (options.get("headers") or {}).items():
        key, value = _safe_text(key).strip(), _safe_text(value).strip()
        if key and value:
            # The Android player keeps already prepared request headers when a
            # private MEDIA-HEADER repeats the same name.
            present = False
            for existing in headers:
                if existing.lower() == key.lower():
                    present = True
                    break
            if not present:
                headers[key] = value
    return headers


def _openssl_path():
    for candidate in ("/usr/bin/openssl", "/bin/openssl", "/usr/local/bin/openssl", "openssl"):
        if candidate == "openssl" or os.path.exists(candidate):
            return candidate
    return "openssl"


def _openssl_cipher(cipher, key, iv, data):
    cmd = [_openssl_path(), "enc", "-d", "-" + cipher, "-nosalt", "-nopad", "-K", _hex(key)]
    if iv is not None:
        cmd.extend(["-iv", _hex(iv)])
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate(data)
    if proc.returncode != 0:
        raise RuntimeError("openssl %s failed" % cipher)
    return stdout


def _pbkdf2_sha1(password, salt, iterations, dklen):
    password = _as_bytes(password)
    try:
        return hashlib.pbkdf2_hmac("sha1", password, salt, int(iterations), int(dklen))
    except AttributeError:
        # Python 2 fallback for older Enigma2 images.
        blocks = []
        index = 1
        while len(b"".join(blocks)) < dklen:
            u = hmac.new(password, salt + struct.pack(">I", index), hashlib.sha1).digest()
            result = bytearray(u)
            previous = u
            for _unused in range(1, int(iterations)):
                previous = hmac.new(password, previous, hashlib.sha1).digest()
                for pos, value in enumerate(bytearray(previous)):
                    result[pos] ^= value
            blocks.append(_raw_bytes(result))
            index += 1
        return b"".join(blocks)[:dklen]


def _png_payload(data):
    """Return (sTeG_chunk, bytes_after_IEND, chunk_names)."""
    if not data.startswith(_PNG_SIG):
        return None, b"", []
    offset = 8
    steg = None
    iend_end = None
    names = []
    total = len(data)
    while offset + 12 <= total:
        try:
            length = struct.unpack(">I", data[offset:offset + 4])[0]
        except Exception:
            break
        end = offset + 12 + length
        if length > _MAX_WRAPPED_SEGMENT or end > total:
            break
        kind = data[offset + 4:offset + 8]
        try:
            names.append(kind.decode("ascii", "replace"))
        except Exception:
            names.append(repr(kind))
        chunk = data[offset + 8:offset + 8 + length]
        if kind == b"sTeG":
            steg = chunk
        offset = end
        if kind == b"IEND":
            iend_end = end
            break
    appended = data[iend_end:] if iend_end is not None and iend_end < total else b""
    return steg, appended, names


def _decrypt_mini_container(blob, password):
    """Decode the three IMINPNG container modes used by libnext.so."""
    if not blob or len(blob) < 14:
        raise ValueError("short sTeG container")
    mode = None
    if blob.startswith(b"IMINPNG1"):
        if len(blob) < 13:
            raise ValueError("short IMINPNG1 header")
        payload_len = struct.unpack(">I", blob[8:12])[0]
        meta_len = _byte_value(blob[12])
        start = 13 + meta_len
        mode = 3
        label = "IMINPNG1"
    elif blob.startswith(b"IMINPNG2"):
        if len(blob) < 14:
            raise ValueError("short IMINPNG2 header")
        mode = _byte_value(blob[8])
        if mode not in (1, 2):
            raise ValueError("unsupported IMINPNG2 mode %s" % mode)
        payload_len = struct.unpack(">I", blob[9:13])[0]
        meta_len = _byte_value(blob[13])
        start = 14 + meta_len
        label = "IMINPNG2/%d" % mode
    else:
        raise ValueError("unknown sTeG magic")
    end = start + payload_len
    if payload_len <= 0 or end > len(blob):
        raise ValueError("invalid %s payload length" % label)
    payload = blob[start:end]
    password = password or _DEFAULT_MINI_PASSWORD

    if mode == 1:
        if len(payload) < 52:
            raise ValueError("short AES-CTR container")
        salt, iv = payload[:16], payload[16:32]
        ciphertext = payload[32:-20]
        derived = _pbkdf2_sha1(password, salt, 60000, 36)
        # The player authenticates with HMAC-SHA1 over salt+IV+ciphertext.
        # Verify when possible, but do not make old images fail on compare_digest.
        try:
            expected = hmac.new(derived[16:36], salt + iv + ciphertext, hashlib.sha1).digest()
            if not hmac.compare_digest(expected, payload[-20:]):
                raise ValueError("AES-CTR HMAC mismatch")
        except AttributeError:
            pass
        plain = _openssl_cipher("aes-128-ctr", derived[:16], iv, ciphertext)
    elif mode == 2:
        if len(payload) < 44:
            raise ValueError("short ChaCha20 container")
        salt, nonce = payload[:16], payload[16:28]
        ciphertext = payload[28:-16]
        key = _pbkdf2_sha1(password, salt, 60000, 32)
        # RFC8439 encryption starts media data at counter=1.  OpenSSL's raw
        # ChaCha20 IV is little-endian 32-bit counter followed by 96-bit nonce.
        iv = struct.pack("<I", 1) + nonce
        plain = _openssl_cipher("chacha20", key, iv, ciphertext)
    else:  # IMINPNG1 / AES-256-GCM payload.  GCM plaintext is CTR from J0+1.
        if len(payload) < 44:
            raise ValueError("short AES-GCM container")
        salt, nonce = payload[:16], payload[16:28]
        ciphertext = payload[28:-16]
        key = _pbkdf2_sha1(password, salt, 150000, 32)
        iv = nonce + b"\x00\x00\x00\x02"
        plain = _openssl_cipher("aes-256-ctr", key, iv, ciphertext)
    return plain, label


def _transform_wrapped_media(data, password):
    if not data.startswith(_PNG_SIG):
        return None, ""
    steg, appended, names = _png_payload(data)
    _log("PNG chunks=%s sTeG=%s appended=%d" % (",".join(names[:12]), bool(steg), len(appended)))
    if steg is not None:
        try:
            plain, label = _decrypt_mini_container(steg, password)
            _log("mini-container %s decrypted bytes=%d password=%s" %
                 (label, len(plain), "manifest" if password else "default"))
            return plain, label
        except Exception as error:
            _log("mini-container decrypt failed: %s" % error)
            return None, ""
    if appended:
        _log("PNG trailer media extracted bytes=%d" % len(appended))
        return appended, "PNG-trailer"
    return None, ""


_ENC_HLS_SECRET = b"a61d8421f01ec97a15c0ebaeb9ddfe99"


def _rol8(value, shift):
    shift = int(shift) & 7
    value = int(value) & 0xff
    if not shift:
        return value
    return ((value << shift) | (value >> (8 - shift))) & 0xff


def _ror8(value, shift):
    shift = int(shift) & 7
    value = int(value) & 0xff
    if not shift:
        return value
    return ((value >> shift) | (value << (8 - shift))) & 0xff


def _decrypt_enc_hls_key(data):
    """Port Url Video Player 4.0 HlsKeyDecryptor.d0 (ENC: wrapper).

    The Android native method accepts ``ENC:<base64>``.  The decoded value is
    a 16-byte nonce followed by the encrypted HLS key.  Its key schedule uses
    FNV-1a mixing plus byte rotations; reproducing it here lets ordinary
    Enigma2/FFmpeg receive the real 16-byte AES-128 HLS key.
    """
    raw_text = _raw_bytes(data).strip()
    if not raw_text.startswith(b"ENC:"):
        return None
    try:
        packed = bytearray(base64.b64decode(raw_text[4:].strip()))
    except Exception as error:
        _log("HLS ENC base64 decode failed: %s" % error)
        return None
    if len(packed) < 17:
        _log("HLS ENC payload too short: %d" % len(packed))
        return None

    nonce = packed[:16]
    cipher = packed[16:]
    state = bytearray(32)
    fnv = 0x811c9dc5
    prime = 0x01000193

    # Native d0 first folds its fixed 32-byte secret into a 32-byte state.
    secret = bytearray(_ENC_HLS_SECRET)
    for index in range(len(secret)):
        fnv ^= int(secret[index]) & 0xff
        fnv = (fnv * prime) & 0xffffffff
        pos = index & 31
        state[pos] = (int(state[pos]) ^ (fnv & 0xff)) & 0xff
        pos2 = (index + 1) & 31
        state[pos2] = (int(state[pos2]) ^ ((fnv >> 8) & 0xff)) & 0xff

    # Then mix the 16-byte nonce from the encrypted blob.
    for index in range(16):
        fnv ^= int(nonce[index]) & 0xff
        fnv = (fnv * prime) & 0xffffffff
        state[index] = (int(state[index]) ^ (fnv & 0xff)) & 0xff
        state[index + 3] = (int(state[index + 3]) ^ ((fnv >> 16) & 0xff)) & 0xff

    # Generate the same byte stream as the native routine.
    stream = bytearray(len(cipher))
    previous = int(state[0]) & 0xff
    add_value = 0
    for index in range(len(cipher)):
        previous ^= add_value
        add_value = (add_value + 0x6d) & 0xffffffff
        rotate = (index % 7) + 1
        previous ^= _rol8(int(state[index & 31]), rotate)
        stream[index] = previous & 0xff
        previous = (int(state[(index + 7) & 31]) ^ previous) & 0xff

    plain = bytearray(len(cipher))
    for index in range(len(cipher)):
        rotate = (index % 7) + 1
        plain[index] = (int(stream[index]) ^ _ror8(int(cipher[index]), rotate)) & 0xff

    # Keep Python 2/3 behaviour identical: bytearray -> raw bytes.
    return binascii.unhexlify(binascii.hexlify(plain))


def _decode_data_uri(value):
    """Decode data: URIs used by Url Video Player for inline HLS keys."""
    value = _safe_text(value).strip()
    if not value.lower().startswith("data:") or "," not in value:
        return None
    meta, payload = value[5:].split(",", 1)
    try:
        if ";base64" in meta.lower():
            return base64.b64decode(_as_bytes(payload))
        decoded = unquote(payload)
        if isinstance(decoded, bytes):
            return decoded
        return decoded.encode("utf-8")
    except Exception as error:
        _log("inline data URI decode failed: %s" % error)
        return None


def _transform_hls_key(data):
    """Reproduce Url Video Player 4.0 HlsKeyDecryptor wrappers."""
    data = _raw_bytes(data).strip()
    if data.startswith(b"UVK:"):
        value = data[4:].strip()
        if value:
            result = hashlib.md5(value).digest()
            _log("HLS key UVK -> MD5 bytes=%d" % len(result))
            return result, "UVK"
    if data.startswith(b"ENC:"):
        result = _decrypt_enc_hls_key(data)
        if result is not None:
            _log("HLS key ENC -> native d0 bytes=%d" % len(result))
            return result, "ENC"
        _log("HLS key ENC decrypt failed")
    return None, ""


def _media_content_type(data, fallback="application/octet-stream"):
    if data.startswith(b"\x47"):
        return "video/mp2t"
    if len(data) >= 8 and data[4:8] in (b"ftyp", b"styp", b"moof"):
        return "video/mp4"
    return fallback or "application/octet-stream"


class _RelaySession(object):
    def __init__(self, upstream_url, headers, swap, options=None):
        self.ident = uuid.uuid4().hex
        self.headers = dict(headers or {})
        self.swap = dict(swap or {})
        self.options = dict(options or {})
        self.http = requests.Session()
        self.routes = {"root": str(upstream_url)}
        self.reverse = {str(upstream_url): "root"}
        self.lock = threading.RLock()

    def transform(self, url):
        value = str(url or "")
        for old, new in self.swap.items():
            old = str(old or "")
            if old:
                value = value.replace(old, str(new or ""))
        return value

    def update_options(self, parsed):
        parsed = dict(parsed or {})
        with self.lock:
            custom = dict(self.options.get("headers") or {})
            custom.update(parsed.get("headers") or {})
            self.options.update(parsed)
            if custom:
                self.options["headers"] = custom

    def request_headers(self):
        with self.lock:
            return _browser_headers(self.headers, self.options)

    def password(self):
        with self.lock:
            return _safe_text(self.options.get("password") or "")

    def fetch(self, url, headers):
        if not self.options.get("reezn"):
            return self.http.get(url, headers=headers, timeout=(15, 35),
                                 verify=False, stream=True, allow_redirects=True)
        # App cookies belong to the source origin, never to an unrelated
        # redirect target or a cross-origin HLS segment/key host.
        origin = _origin_from_referer(self.options.get("credential_origin") or self.routes["root"])
        headers = dict(headers)
        for unused in range(6):
            if _origin_from_referer(url) != origin:
                headers = {k: v for k, v in headers.items()
                           if str(k).lower() not in ("cookie", "authorization")}
            response = self.http.get(url, headers=headers, timeout=(10, 12) if self.options.get("live") else (15, 35),
                                     verify=False, stream=True, allow_redirects=False)
            if response.status_code not in (301, 302, 303, 307, 308):
                return response
            target = response.headers.get("Location")
            response.close()
            if not target:
                raise RuntimeError("Stream redirect has no destination")
            url = urljoin(url, target)
            if urlparse(url).scheme.lower() not in ("http", "https"):
                raise RuntimeError("Unsupported stream redirect")
        raise RuntimeError("Too many stream redirects")

    def add_route(self, url):
        value = self.transform(url)
        with self.lock:
            route = self.reverse.get(value)
            if route is None:
                route = hashlib.sha1(_as_bytes(value)).hexdigest()
                self.routes[route] = value
                self.reverse[value] = route
        return route

    def get_route(self, route):
        with self.lock:
            return self.routes.get(route)


class _ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class _RelayHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        return

    def do_HEAD(self):
        self._serve(head_only=True)

    def do_GET(self):
        self._serve(head_only=False)

    def _client_gone(self):
        try:
            ready, unused, errors = select.select([self.connection], [], [self.connection], 0)
            return bool(errors) or bool(ready and not self.connection.recv(1, socket.MSG_PEEK))
        except Exception:
            return True

    def _stream_live_ts(self, relay, response, first):
        """Keep one player connection open across upstream live-TS EOFs."""
        self.send_response(200)
        self.send_header("Content-Type", "video/mp2t")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        failures = 0
        try:
            while not self._client_gone():
                delivered = 0
                pending = b""
                upstream_error = False
                if response is not None:
                    chunks = response.iter_content(188 * 128)
                    chunk = first
                    while not self._client_gone():
                        if chunk:
                            pending += chunk
                            size = len(pending) // 188 * 188
                            if size:
                                # Client write failures must terminate, never reconnect.
                                self.wfile.write(pending[:size])
                                self.wfile.flush()
                                delivered += size
                                pending = pending[size:]
                        try:
                            chunk = next(chunks)
                        except StopIteration:
                            break
                        except Exception:
                            upstream_error = True
                            break
                    response.close()
                    response = None
                if self._client_gone():
                    return
                failures = 0 if delivered >= 188 * 40 else failures + 1
                if failures >= 4:
                    _log("Reezn live TS stopped after repeated empty connections")
                    return
                _log("Reezn live TS reconnect reason=%s bytes=%d" %
                     ("read-error" if upstream_error else "EOF", delivered))
                time.sleep(min(2.0, 0.25 + failures * 0.5))
                if self._client_gone():
                    return
                try:
                    # Reopen the original resolver for a fresh redirect/token.
                    response = relay.fetch(relay.routes["root"], relay.request_headers())
                    response.raise_for_status()
                    first = next(response.iter_content(4096), b"")
                    if len(first) < 377 or not (first[0:1] == first[188:189] == first[376:377] == b"\x47"):
                        raise RuntimeError("Reconnected source is not MPEG-TS")
                except Exception:
                    if response is not None:
                        response.close()
                    response = None
                    first = b""
        finally:
            if response is not None:
                response.close()

    def _error(self, status, message):
        body = _as_bytes(message)
        try:
            self.send_response(status)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Connection", "close")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)
        except Exception:
            pass

    def _send_buffer(self, response, body, content_type, head_only=False):
        status = response.status_code
        # A transformed object is no longer the upstream byte range.
        if status == 206:
            status = 200
        self.send_response(status)
        self.send_header("Content-Type", content_type or "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()
        if not head_only:
            self.wfile.write(body)

    def _serve(self, head_only=False):
        parts = urlparse(self.path).path.strip("/").split("/")
        if len(parts) != 3 or parts[0] != "xklass-hls":
            self._error(404, "Unknown relay route")
            return
        with _LOCK:
            relay = _SESSIONS.get(parts[1])
        if relay is None:
            self._error(404, "Expired relay session")
            return
        upstream_url = relay.get_route(parts[2])
        if not upstream_url:
            self._error(404, "Unknown relay item")
            return

        headers = relay.request_headers()
        range_value = self.headers.get("Range")
        if range_value:
            headers["Range"] = range_value

        # Url Video Player deliberately allows HLS AES keys to be embedded as
        # data: URIs.  requests has no data: adapter, so resolve them locally
        # instead of trying an HTTP GET (the exact failure seen in R65 logs).
        if _safe_text(upstream_url).lower().startswith("data:"):
            inline = _decode_data_uri(upstream_url)
            if inline is None:
                _log("inline data URI could not be decoded")
                self._error(502, "Invalid inline HLS key")
                return
            transformed, label = _transform_hls_key(inline)
            body = transformed if transformed is not None else inline
            try:
                _log("inline HLS data served type=%s input=%d output=%d" %
                     (label or "raw", len(inline), len(body)))
            except Exception:
                pass
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            if not head_only:
                self.wfile.write(body)
            return

        response = None
        try:
            last_error = None
            for attempt in range(3):
                try:
                    response = relay.fetch(upstream_url, headers)
                    if response.status_code not in (502, 503, 504) or attempt == 2:
                        break
                    response.close()
                    response = None
                except Exception as caught:
                    last_error = caught
                    if response is not None:
                        try:
                            response.close()
                        except Exception:
                            pass
                        response = None
            if response is None:
                raise last_error or RuntimeError("Upstream did not respond")

            if relay.options.get("vixsrc"):
                try:
                    _vod_log("status=%s type=%s url=%s referer=%s" % (
                        response.status_code, response.headers.get("Content-Type") or "",
                        response.url, headers.get("Referer") or headers.get("referer") or ""))
                except Exception:
                    pass

            # Reezn's origin advertises JSON/HTML for playlists and media.
            # Sniff HEAD too, so players receive the actual content type.
            first = b"" if head_only and not relay.options.get("reezn") else next(response.iter_content(4096), b"")
            content_type = _safe_text(response.headers.get("Content-Type") or "")
            if (not head_only and relay.options.get("reezn") and relay.options.get("live")
                    and parts[2] == "root" and response.status_code == 200 and len(first) >= 377
                    and first[0:1] == first[188:189] == first[376:377] == b"\x47"):
                self._stream_live_ts(relay, response, first)
                return
            is_playlist = first.lstrip().upper().startswith(b"#EXTM3U")
            if is_playlist:
                chunks = [first]
                chunks.extend(response.iter_content(65536))
                body = b"".join(chunks)
                body = self._rewrite_playlist(relay, response.url, body)
                _log("playlist status=%s url=%s bytes=%d" % (response.status_code, response.url, len(body)))
                self._send_buffer(response, body, "application/vnd.apple.mpegurl", head_only)
                return

            # The Android player inspects the first 8 bytes and buffers a PNG
            # wrapper before handing media to ExoPlayer.  Do the same here.
            if first.startswith(_PNG_SIG):
                data = bytearray(first)
                for chunk in response.iter_content(65536):
                    if chunk:
                        data.extend(chunk)
                        if len(data) > _MAX_WRAPPED_SEGMENT:
                            raise RuntimeError("Wrapped segment exceeds 32 MiB")
                transformed, label = _transform_wrapped_media(_raw_bytes(data), relay.password())
                if transformed is not None:
                    self._send_buffer(response, transformed,
                                      _media_content_type(transformed, content_type), head_only)
                    return
                # If parsing/decryption failed, pass the original object so
                # unprotected PNG-media tricks are not made worse.
                self._send_buffer(response, _raw_bytes(data), content_type or "application/octet-stream", head_only)
                return

            if first.startswith((b"UVK:", b"ENC:")):
                data = bytearray(first)
                for chunk in response.iter_content(65536):
                    if chunk:
                        data.extend(chunk)
                        if len(data) > 1024 * 1024:
                            break
                transformed, label = _transform_hls_key(_raw_bytes(data))
                if transformed is not None:
                    self._send_buffer(response, transformed, "application/octet-stream", head_only)
                    return
                self._send_buffer(response, _raw_bytes(data), content_type or "application/octet-stream", head_only)
                return

            if parts[2] != "root":
                try:
                    _log("media status=%s type=%s first8=%s url=%s" %
                         (response.status_code, content_type, _hex(first[:8]), response.url))
                except Exception:
                    pass

            if relay.options.get("reezn"):
                content_type = _media_content_type(first, content_type)
            elif relay.options.get("vixsrc"):
                # VixSrc deliberately serves AES-encrypted HLS fragments from
                # URLs ending in .html and labels them text/html.  The HLS
                # demuxer already knows these are media fragments; forwarding
                # text/html can make Enigma2/ServiceApp reject them before AES
                # decryption.  Keep playlists handled above, and expose the
                # remaining VixSrc objects as opaque media bytes.
                if content_type.lower().startswith(("text/html", "text/plain")):
                    content_type = "application/octet-stream"

            self.send_response(response.status_code)
            for key in ("Content-Type", "Content-Range", "Accept-Ranges"):
                value = content_type if key == "Content-Type" else response.headers.get(key)
                if value:
                    self.send_header(key, value)

            # We sniffed `first` from the same upstream response, so the total
            # response size has not changed.  Preserve Content-Length even for
            # 206 responses; ExtePlayer/FFmpeg uses it together with
            # Content-Range when reading VixSrc's byte-ranged .html fragments.
            length = response.headers.get("Content-Length")
            if length:
                self.send_header("Content-Length", length)
            if relay.options.get("vixsrc"):
                self.send_header("Cache-Control", "no-store")
                try:
                    _vod_log("media pass status=%s type=%s len=%s range=%s first8=%s" % (
                        response.status_code, content_type, length or "",
                        response.headers.get("Content-Range") or "", _hex(first[:8])))
                except Exception:
                    pass
            self.send_header("Connection", "close")
            self.end_headers()
            if not head_only:
                if first:
                    self.wfile.write(first)
                for chunk in response.iter_content(65536):
                    if chunk:
                        self.wfile.write(chunk)
        except Exception as error:
            _log("relay failed url=%s error=%s" % (upstream_url, error))
            self._error(502, "Relay request failed: %s" % str(error))
        finally:
            try:
                if response is not None:
                    response.close()
            except Exception:
                pass

    def _rewrite_playlist(self, relay, base_url, raw):
        try:
            text = raw.decode("utf-8")
        except Exception:
            text = raw.decode("latin-1", "replace")

        parsed, seen = _parse_hls_options(text, relay.options)
        if seen:
            relay.update_options(parsed)
            _log("custom HLS tags: %s" % ",".join(seen))

        def local_url(value):
            absolute = urljoin(base_url, value.replace("&amp;", "&"))
            route = relay.add_route(absolute)
            return "http://127.0.0.1:%d/xklass-hls/%s/%s" % (
                self.server.server_port, relay.ident, route)

        lines = []
        uri_pattern = re.compile(r'URI=(["\'])(.*?)(\1)', re.I)
        for raw_line in text.splitlines():
            line = raw_line.strip()
            if line and not line.startswith("#"):
                lines.append(local_url(line))
            elif line.startswith("#") and "URI=" in line.upper():
                lines.append(uri_pattern.sub(
                    lambda match: "URI=%s%s%s" % (
                        match.group(1), local_url(match.group(2)), match.group(3)),
                    raw_line))
            else:
                lines.append(raw_line)
        return _as_bytes("\n".join(lines) + "\n")


def _ensure_server():
    global _SERVER, _SERVER_THREAD
    with _LOCK:
        if _SERVER is None:
            _SERVER = _ThreadingHTTPServer(("127.0.0.1", 0), _RelayHandler)
            _SERVER_THREAD = threading.Thread(target=_SERVER.serve_forever)
            _SERVER_THREAD.daemon = True
            _SERVER_THREAD.start()
        return _SERVER


def prepare_hls_relay(upstream_url, headers=None, swap=None, options=None):
    """Register a live HLS source and return its localhost playback URL."""
    server = _ensure_server()
    relay = _RelaySession(upstream_url, headers, swap, options)
    with _LOCK:
        _SESSIONS[relay.ident] = relay
        # Keep memory bounded during long Enigma2 sessions.
        if len(_SESSIONS) > 24:
            for ident in list(_SESSIONS.keys()):
                if ident != relay.ident:
                    _SESSIONS.pop(ident, None)
                    if len(_SESSIONS) <= 16:
                        break
    try:
        # New play attempt = fresh, compact diagnostics for the user's test.
        _log("NEW relay id=%s upstream=%s options=%s" %
             (relay.ident[:8], upstream_url,
              ",".join(sorted(k for k in relay.options.keys() if k != "password"))))
    except Exception:
        pass
    return "http://127.0.0.1:%d/xklass-hls/%s/root" % (
        server.server_port, relay.ident)
