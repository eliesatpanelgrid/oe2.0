#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Small localhost HLS relay for providers that rewrite child request URLs."""

from __future__ import print_function

import hashlib
import re
import threading
import uuid

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import urljoin, urlparse
except ImportError:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from urlparse import urljoin, urlparse

import requests


_LOCK = threading.RLock()
_SESSIONS = {}
_SERVER = None
_SERVER_THREAD = None


def _as_bytes(value):
    if isinstance(value, bytes):
        return value
    return str(value or "").encode("utf-8")


class _RelaySession(object):
    def __init__(self, upstream_url, headers, swap):
        self.ident = uuid.uuid4().hex
        self.headers = dict(headers or {})
        self.swap = dict(swap or {})
        self.http = requests.Session()
        self.routes = {"root": str(upstream_url)}
        self.reverse = {str(upstream_url): "root"}
        self.lock = threading.RLock()

    def transform(self, url):
        value = str(url or "")
        for old, new in self.swap.items():
            old = str(old or "")
            if old:
                value = value.replace(old, str(new or ""))
        return value

    def add_route(self, url):
        value = self.transform(url)
        with self.lock:
            route = self.reverse.get(value)
            if route is None:
                route = hashlib.sha1(_as_bytes(value)).hexdigest()
                self.routes[route] = value
                self.reverse[value] = route
        return route

    def get_route(self, route):
        with self.lock:
            return self.routes.get(route)


class _ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class _RelayHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        return

    def do_HEAD(self):
        self._serve(head_only=True)

    def do_GET(self):
        self._serve(head_only=False)

    def _error(self, status, message):
        body = _as_bytes(message)
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(body)
            except Exception:
                pass

    def _serve(self, head_only=False):
        parts = urlparse(self.path).path.strip("/").split("/")
        if len(parts) != 3 or parts[0] != "xklass-hls":
            self._error(404, "Unknown relay route")
            return
        with _LOCK:
            relay = _SESSIONS.get(parts[1])
        if relay is None:
            self._error(404, "Expired relay session")
            return
        upstream_url = relay.get_route(parts[2])
        if not upstream_url:
            self._error(404, "Unknown relay item")
            return

        headers = dict(relay.headers)
        range_value = self.headers.get("Range")
        if range_value:
            headers["Range"] = range_value
        response = None
        try:
            last_error = None
            for attempt in range(3):
                try:
                    response = relay.http.get(
                        upstream_url, headers=headers, timeout=(15, 35),
                        verify=False, stream=True, allow_redirects=True)
                    if response.status_code not in (502, 503, 504) or attempt == 2:
                        break
                    response.close()
                    response = None
                except Exception as caught:
                    last_error = caught
                    if response is not None:
                        try:
                            response.close()
                        except Exception:
                            pass
                        response = None
            if response is None:
                raise last_error or RuntimeError("Upstream did not respond")
            first = b"" if head_only else next(response.iter_content(4096), b"")
            is_playlist = first.lstrip().upper().startswith(b"#EXTM3U")
            if is_playlist:
                chunks = [first]
                chunks.extend(response.iter_content(65536))
                body = b"".join(chunks)
                body = self._rewrite_playlist(relay, response.url, body)
                self.send_response(response.status_code)
                self.send_header("Content-Type", "application/vnd.apple.mpegurl")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "close")
                self.end_headers()
                if not head_only:
                    self.wfile.write(body)
                return

            self.send_response(response.status_code)
            for key in ("Content-Type", "Content-Range", "Accept-Ranges"):
                value = response.headers.get(key)
                if value:
                    self.send_header(key, value)
            length = response.headers.get("Content-Length")
            if length and not first:
                self.send_header("Content-Length", length)
            self.send_header("Connection", "close")
            self.end_headers()
            if not head_only:
                if first:
                    self.wfile.write(first)
                for chunk in response.iter_content(65536):
                    if chunk:
                        self.wfile.write(chunk)
        except Exception as error:
            try:
                self._error(502, "Relay request failed: %s" % str(error))
            except Exception:
                pass
        finally:
            try:
                if response is not None:
                    response.close()
            except Exception:
                pass

    def _rewrite_playlist(self, relay, base_url, raw):
        try:
            text = raw.decode("utf-8")
        except Exception:
            text = raw.decode("latin-1", "replace")

        def local_url(value):
            absolute = urljoin(base_url, value.replace("&amp;", "&"))
            route = relay.add_route(absolute)
            return "http://127.0.0.1:%d/xklass-hls/%s/%s" % (
                self.server.server_port, relay.ident, route)

        lines = []
        uri_pattern = re.compile(r'URI=(["\'])(.*?)(\1)', re.I)
        for raw_line in text.splitlines():
            line = raw_line.strip()
            if line and not line.startswith("#"):
                lines.append(local_url(line))
            elif line.startswith("#") and "URI=" in line.upper():
                lines.append(uri_pattern.sub(
                    lambda match: "URI=%s%s%s" % (
                        match.group(1), local_url(match.group(2)), match.group(3)),
                    raw_line))
            else:
                lines.append(raw_line)
        return _as_bytes("\n".join(lines) + "\n")


def _ensure_server():
    global _SERVER, _SERVER_THREAD
    with _LOCK:
        if _SERVER is None:
            _SERVER = _ThreadingHTTPServer(("127.0.0.1", 0), _RelayHandler)
            _SERVER_THREAD = threading.Thread(target=_SERVER.serve_forever)
            _SERVER_THREAD.daemon = True
            _SERVER_THREAD.start()
        return _SERVER


def prepare_hls_relay(upstream_url, headers=None, swap=None):
    """Register a live HLS source and return its localhost playback URL."""
    server = _ensure_server()
    relay = _RelaySession(upstream_url, headers, swap)
    with _LOCK:
        _SESSIONS[relay.ident] = relay
        # Keep memory bounded during long Enigma2 sessions.
        if len(_SESSIONS) > 24:
            for ident in list(_SESSIONS.keys()):
                if ident != relay.ident:
                    _SESSIONS.pop(ident, None)
                    if len(_SESSIONS) <= 16:
                        break
    return "http://127.0.0.1:%d/xklass-hls/%s/root" % (
        server.server_port, relay.ident)
