#!/bin/sh
# Alkuds IPAUDIO R31P7 dependency bootstrapper
# Installs only from the receiver's configured package feeds. This avoids
# mixing foreign image binaries/ABIs on Enigma2 boxes.

LOG=/tmp/ipaudio-dependencies.log
MODE="${1:-manual}"
: > "$LOG" 2>/dev/null || true
# Keep output visible in the Enigma2 Console; individual messages are also appended.

say() { echo "[IPAudio deps] $*"; echo "[IPAudio deps] $*" >> "$LOG" 2>/dev/null || true; }
has_cmd() { command -v "$1" >/dev/null 2>&1; }

PY=""
if has_cmd python3; then PY=python3; elif has_cmd python; then PY=python; fi
PYMAJOR=""
if [ -n "$PY" ]; then
    PYMAJOR="$($PY -c 'import sys; print(sys.version_info[0])' 2>/dev/null || true)"
fi

say "mode=$MODE"
say "date=$(date 2>/dev/null || true)"
say "python=${PY:-missing} major=${PYMAJOR:-unknown}"
[ -r /etc/image-version ] && { say "image-version:"; sed 's/^/  /' /etc/image-version; }
[ -r /etc/issue ] && say "issue=$(head -n 1 /etc/issue 2>/dev/null)"
if [ -r /proc/stb/info/model ]; then say "model=$(cat /proc/stb/info/model 2>/dev/null)"; fi
if [ -r /proc/stb/info/boxtype ]; then say "boxtype=$(cat /proc/stb/info/boxtype 2>/dev/null)"; fi
if has_cmd opkg; then say "opkg architectures:"; opkg print-architecture 2>/dev/null | sed 's/^/  /'; fi

test_py() {
    [ -n "$PY" ] && "$PY" -c "$1" >/dev/null 2>&1
}

PKGMGR=""
if has_cmd opkg; then PKGMGR=opkg; elif has_cmd apt-get; then PKGMGR=apt; fi

pkg_update() {
    case "$PKGMGR" in
        opkg) opkg update || true ;;
        apt) DEBIAN_FRONTEND=noninteractive apt-get update || true ;;
    esac
}

try_install() {
    # Try candidate package names until the caller's test succeeds.
    TEST_KIND="$1"; TEST_VALUE="$2"; shift 2
    for PKG in "$@"; do
        [ -n "$PKG" ] || continue
        case "$TEST_KIND" in
            cmd) has_cmd "$TEST_VALUE" && return 0 ;;
            py) test_py "$TEST_VALUE" && return 0 ;;
        esac
        say "trying package: $PKG"
        case "$PKGMGR" in
            opkg) opkg install "$PKG" || true ;;
            apt) DEBIAN_FRONTEND=noninteractive apt-get -y install "$PKG" || true ;;
            *) return 1 ;;
        esac
    done
    case "$TEST_KIND" in
        cmd) has_cmd "$TEST_VALUE" ;;
        py) test_py "$TEST_VALUE" ;;
        *) return 1 ;;
    esac
}

if [ -z "$PKGMGR" ]; then
    say "No supported package manager found (opkg/apt-get)."
    exit 0
fi

say "Updating configured image feeds..."
pkg_update

# HTTPS trust store: required by requests/curl/wget against modern portals.
case "$PKGMGR" in
  opkg) opkg install ca-certificates >/dev/null 2>&1 || true ;;
  apt) DEBIAN_FRONTEND=noninteractive apt-get -y install ca-certificates >/dev/null 2>&1 || true ;;
esac

# Python runtime libraries used directly by XKlass.
if [ "$PYMAJOR" = "3" ]; then
    test_py 'import requests' || try_install py 'import requests' python3-requests python3-requests-pyc
    test_py 'from PIL import Image' || try_install py 'from PIL import Image' python3-pillow python3-pil
    test_py 'import six' || try_install py 'import six' python3-six
    test_py 'from multiprocessing.pool import ThreadPool' || try_install py 'from multiprocessing.pool import ThreadPool' python3-multiprocessing
    test_py 'import twisted' || try_install py 'import twisted' python3-twisted
    test_py 'import pkg_resources' || try_install py 'import pkg_resources' python3-setuptools
else
    test_py 'import requests' || try_install py 'import requests' python-requests
    test_py 'from PIL import Image' || try_install py 'from PIL import Image' python-image python-imaging python-pillow
    test_py 'import six' || try_install py 'import six' python-six
    test_py 'from multiprocessing.pool import ThreadPool' || try_install py 'from multiprocessing.pool import ThreadPool' python-multiprocessing
    test_py 'import twisted' || try_install py 'import twisted' python-twisted
    test_py 'import pkg_resources' || try_install py 'import pkg_resources' python-setuptools
fi

# Core media dependency for IPAUDIO Local Remux/background audio.
has_cmd ffmpeg || try_install cmd ffmpeg ffmpeg

# Vu+ path: ServiceApp/ExtEplayer3 is preferred because it writes through the
# DVB playback path. OE-Alliance's exteplayer3 package itself depends on ffmpeg.
# Package names vary between images, so try the common names harmlessly.
if [ ! -x /usr/bin/exteplayer3 ]; then
    try_install cmd exteplayer3 exteplayer3 enigma2-plugin-systemplugins-serviceapp serviceapp || true
fi

# ServiceApp gstplayer is useful on Vu+ images and also pulls in the image's
# own GStreamer/DVB sink integration on several feeds.
if [ ! -x /usr/bin/gstplayer ] && [ ! -x /usr/bin/gstplayer_gst-1.0 ]; then
    try_install cmd gstplayer gstplayer enigma2-plugin-systemplugins-serviceapp || true
fi

# R24's preferred Vu+ native-timeshift backend needs the hardware DVB audio
# GStreamer sink.  Package names differ slightly between OE families.
if has_cmd gst-inspect-1.0; then
    if ! gst-inspect-1.0 dvbaudiosink >/dev/null 2>&1; then
        say "dvbaudiosink missing; trying image-feed packages"
        case "$PKGMGR" in
            opkg)
                for p in gstreamer1.0-plugin-dvbmediasink gstreamer1.0-plugin-multibox-dvbmediasink gstreamer1.0-plugin-dreambox-dvbmediasink; do
                    opkg install "$p" >/dev/null 2>&1 || true
                    gst-inspect-1.0 dvbaudiosink >/dev/null 2>&1 && break
                done
                ;;
        esac
    fi
fi

# Background-audio fallback used by receivers where independent PCM works.
if ! has_cmd gst-launch-1.0; then
    try_install cmd gst-launch-1.0 gstreamer1.0-tools gstreamer1.0 gstreamer1.0-plugins-base || true
fi
# Codec/decoder plugins. These are soft installs: unavailable names must not
# prevent the main plugin package from installing.
if [ "$PKGMGR" = "opkg" ]; then
    for p in gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly gstreamer1.0-libav; do
        opkg install "$p" >/dev/null 2>&1 || true
    done
    if has_cmd gst-inspect-1.0 && ! gst-inspect-1.0 dvbaudiosink >/dev/null 2>&1; then
        for p in gstreamer1.0-plugin-dvbmediasink gstreamer1.0-plugin-multibox-dvbmediasink gstreamer1.0-plugin-dreambox-dvbmediasink; do
            opkg install "$p" >/dev/null 2>&1 || true
            gst-inspect-1.0 dvbaudiosink >/dev/null 2>&1 && break
        done
    fi
fi

# R31P7 Vu+ path: render IPTV sound through ALSA, independently from the
# Broadcom DVB decoder that OpenATV pauses during native Timeshift.
if has_cmd gst-inspect-1.0 && ! gst-inspect-1.0 alsasink >/dev/null 2>&1; then
    say "alsasink missing; trying image-feed packages"
    case "$PKGMGR" in
        opkg)
            for p in gstreamer1.0-plugins-base-alsa gstreamer1.0-plugin-alsa gstreamer1.0-alsa alsa-plugins; do
                opkg install "$p" >/dev/null 2>&1 || true
                gst-inspect-1.0 alsasink >/dev/null 2>&1 && break
            done
            ;;
        apt)
            DEBIAN_FRONTEND=noninteractive apt-get -y install gstreamer1.0-alsa >/dev/null 2>&1 || true
            ;;
    esac
fi

has_cmd aplay || try_install cmd aplay alsa-utils-aplay alsa-utils || true
has_cmd curl || try_install cmd curl curl || true
has_cmd wget || try_install cmd wget wget || true

say "--- final dependency report ---"
for c in ffmpeg exteplayer3 gstplayer gstplayer_gst-1.0 gst-launch-1.0 gst-inspect-1.0 aplay curl wget; do
    if has_cmd "$c"; then say "$c: $(command -v "$c")"; else say "$c: MISSING"; fi
done
if has_cmd gst-inspect-1.0 && gst-inspect-1.0 alsasink >/dev/null 2>&1; then
    say "GStreamer alsasink: OK"
else
    say "GStreamer alsasink: MISSING"
fi
[ -r /proc/asound/pcm ] && { say "ALSA playback devices:"; sed 's/^/  /' /proc/asound/pcm; }
if [ -n "$PY" ]; then
    for spec in 'requests:import requests' 'PIL:from PIL import Image' 'six:import six' 'multiprocessing:from multiprocessing.pool import ThreadPool' 'twisted:import twisted' 'pkg_resources:import pkg_resources'; do
        NAME=${spec%%:*}; CODE=${spec#*:}
        if test_py "$CODE"; then say "python $NAME: OK"; else say "python $NAME: MISSING"; fi
    done
fi

# A simple marker prevents ambiguity when diagnosing whether auto-install ran.
mkdir -p /etc/enigma2 2>/dev/null || true
{
    echo "completed=$(date +%s 2>/dev/null || echo 0)"
    echo "ffmpeg=$(command -v ffmpeg 2>/dev/null || true)"
    echo "exteplayer3=$(command -v exteplayer3 2>/dev/null || true)"
    echo "gst=$(command -v gst-launch-1.0 2>/dev/null || true)"
    echo "gstplayer=$(command -v gstplayer 2>/dev/null || command -v gstplayer_gst-1.0 2>/dev/null || true)"
    if command -v gst-inspect-1.0 >/dev/null 2>&1 && gst-inspect-1.0 dvbaudiosink >/dev/null 2>&1; then
        echo "dvbaudiosink=OK"
    else
        echo "dvbaudiosink=MISSING"
    fi
    if command -v gst-inspect-1.0 >/dev/null 2>&1 && gst-inspect-1.0 alsasink >/dev/null 2>&1; then
        echo "alsasink=OK"
    else
        echo "alsasink=MISSING"
    fi
    echo "aplay=$(command -v aplay 2>/dev/null || true)"
    echo "dvb_audio_nodes=$(ls /dev/dvb/adapter*/audio* 2>/dev/null | tr '\n' ' ')"
    echo "alsa_pcm_nodes=$(ls /dev/snd/pcmC*D*p 2>/dev/null | tr '\n' ' ')"
} > /etc/enigma2/dependency_status.txt 2>/dev/null || true

say "Done. Log: $LOG"
exit 0
