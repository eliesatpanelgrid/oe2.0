#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Receiver-specific compatibility helpers for Alkuds IPAUDIO (R31P7).

Vu+ 4K receivers use Broadcom vendor audio drivers whose DVB audio decoder is
paused together with native Timeshift. Detect Vu+ using both procfs and
Enigma2's own boxbranding/BoxInfo APIs, then select the audio-only Enigma2
handoff plus the independent ALSA renderer. The main DVB video service and
native Timeshift remain untouched; Local Remux is never selected here.
"""

import os


def _read_text(path):
    try:
        with open(path, "rb") as f:
            data = f.read(2048)
        if not isinstance(data, str):
            data = data.decode("utf-8", "ignore")
        return str(data or "").replace("\x00", " ").strip()
    except Exception:
        return ""


def _safe_call(module_name, names):
    values = []
    try:
        mod = __import__(module_name, fromlist=list(names))
        for name in names:
            try:
                fn = getattr(mod, name, None)
                if callable(fn):
                    value = fn()
                    if value is not None and str(value).strip():
                        values.append("%s=%s" % (name, str(value).strip()))
            except Exception:
                pass
    except Exception:
        pass
    return values


def _boxinfo_values():
    values = []
    # Newer OpenATV/OpenBH style BoxInfo API.
    try:
        from Components.SystemInfo import BoxInfo
        for key in ("brand", "model", "boxtype", "machinebuild", "machinename", "machinebrand", "oem"):
            try:
                value = BoxInfo.getItem(key)
                if value is not None and str(value).strip():
                    values.append("BoxInfo.%s=%s" % (key, str(value).strip()))
            except Exception:
                pass
    except Exception:
        pass

    # Older images expose only SystemInfo dict + HardwareInfo.
    try:
        from Tools.HardwareInfo import HardwareInfo
        hw = HardwareInfo()
        for name in ("get_device_model", "get_device_name", "get_vu_device_name"):
            try:
                fn = getattr(hw, name, None)
                if callable(fn):
                    value = fn()
                    if value is not None and str(value).strip():
                        values.append("HardwareInfo.%s=%s" % (name, str(value).strip()))
            except Exception:
                pass
    except Exception:
        pass
    return values


def receiver_signature():
    values = []
    for path in (
        "/proc/stb/info/brand",
        "/proc/stb/info/model",
        "/proc/stb/info/boxtype",
        "/proc/stb/info/boxmodel",
        "/proc/stb/info/vumodel",
        "/proc/stb/info/machinebuild",
        "/proc/stb/info/chipset",
        "/proc/device-tree/model",
        "/sys/firmware/devicetree/base/model",
        "/etc/hostname",
    ):
        value = _read_text(path)
        if value:
            values.append("%s=%s" % (path, value))

    values.extend(_safe_call("boxbranding", (
        "getBoxType", "getMachineBuild", "getMachineBrand", "getMachineName",
        "getBrandOEM", "getMachineMake", "getModel"
    )))
    values.extend(_boxinfo_values())
    return " | ".join(values)


def _normalise(value):
    return "".join(ch for ch in str(value or "").lower() if ch.isalnum() or ch == "+")


def is_vuplus():
    ident = _normalise(receiver_signature())
    if not ident:
        return False

    # Exact/common Vu+ 4K machine identifiers used by Enigma2 images.
    markers = (
        "vu+", "vuplus",
        "vusolo4k", "solo4k",
        "vuuno4k", "uno4k", "vuuno4kse", "uno4kse",
        "vuultimo4k", "ultimo4k",
        "vuduo4k", "duo4k", "vuduo4kse", "duo4kse",
        "vuzero4k", "zero4k",
    )
    if any(_normalise(marker) in ident for marker in markers):
        return True

    # Some vendor images identify the brand separately and the model simply as
    # "Solo 4K"/"Duo 4K" etc.  Require both sides to avoid classifying another
    # receiver merely because it contains a generic model word.
    vu_brand = any(x in ident for x in ("machinebrandvu", "brandvu", "oemvu", "brandvutplus", "vuplus"))
    vu_4k_model = any(x in ident for x in ("solo4k", "uno4k", "ultimo4k", "duo4k", "zero4k"))
    return bool(vu_brand and vu_4k_model)


def needs_single_service_audio():
    """Compatibility flag for legacy/remux callers on Vu+ hardware."""
    return is_vuplus()


def preferred_local_service_type():
    """Prefer ExtePlayer3 on Vu+ when installed; otherwise native 4097."""
    if is_vuplus() and os.path.isfile("/usr/bin/exteplayer3") and os.access("/usr/bin/exteplayer3", os.X_OK):
        return 5002
    return 4097


def preferred_foreground_service_type():
    """Use ServiceApp/ExtePlayer3 for normal IPTV whenever it is installed."""
    for path in ("/usr/bin/exteplayer3", "/usr/bin/exteplayer3.sh"):
        try:
            if os.path.isfile(path) and os.access(path, os.X_OK):
                return 5002
        except Exception:
            pass
    return 4097
