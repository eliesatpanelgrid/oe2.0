#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Dynamic public-channel catalogues used by the Free Arabic TV screen."""

from __future__ import print_function

import base64
import binascii
import hashlib
import hmac
import json
import os
import re
import shutil
import subprocess
import time
import uuid
import zlib

try:
    from urllib.parse import parse_qs, unquote, urljoin, urlparse
except ImportError:
    from urllib import unquote
    from urlparse import parse_qs, urljoin, urlparse

import requests

try:
    string_types = (basestring,)
except NameError:
    string_types = (str,)

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote


def service_stream_url(url, headers):
    """ServiceApp reads HTTP options from the URL fragment, not a pipe."""
    normalised = {}
    for raw_key, raw_value in (headers or {}).items():
        key = str(raw_key or '').strip().lower()
        if key:
            normalised[key] = raw_value
    parts = []
    for key in ('User-Agent', 'Referer', 'Origin', 'Cookie'):
        value = str(normalised.get(key.lower()) or '').strip()
        if value:
            if '\r' in value or '\n' in value:
                raise ValueError('Invalid stream header')
            parts.append('%s=%s' % (key, quote(value, safe='')))
    return url + ('#' + '&'.join(parts) if parts else '')


ELAHMAD_HOME = "https://www.elahmad.ru/tv/live-arabic-channels.php"
ELAHMAD_SOURCE = "https://www.elahmad.ru/tv/js/source.php"
FAJER_API = "https://tv.alfajertv.com/api/get-stream.php"
FAJER_ASSIGN = "https://tv.alfajertv.com/api/assign.php"
DRAMA_API_BASES = (
    "http://live.eastgoessouth.online/api/live/livedrama/v13.0.0/",
    "http://main.eastgoessouth.online/api/live/livedrama/v13.0.0/",
    "http://main.backendcoreapi.com/api/live/livedrama/v13.0.0/",
    "http://main.swiftapi.org/api/live/livedrama/v13.0.0/",
)
DRAMA_REDIRECT_BASES = (
    "http://redirect.eastgoessouth.online/redirect/",
)
DRAMA_SHOW_BASES = (
    "http://shows.eastgoessouth.online/search/v3/",
)
DRAMA_EPISODE_BASES = (
    "http://shows.1spbgmu.com/search/v3/",
    "http://shows.eastgoessouth.online/search/v3/",
)
DRAMA_AES_KEY = b"0123456789abcdef"
DRAMA_AES_IV = b"fedcba9876543210"
DRAMA_DEVICE_ID = uuid.uuid4().hex[:16]
YACINE_API = "https://deft.yacinelive.com/api/"
# Yacine TV wraps every JSON response with the same lightweight native
# routine used by its Android client: base64 followed by a repeating XOR.
YACINE_KEY_PREFIX = b"c!xZj+N9&G@Ev@vw"
SYRIA_LIVE_API = "https://api.syria-scores.info/api/v2/"
EGYBEST_API = "https://hrrejhp.com/egybestV26/public/api/"
EGYBEST_CODE = "p2lbgWkFrykA4QyUmpHihzmc5BNzIABq"
ORIGINAL_API = "https://panel.originalpro.online/api.php"
ORIGINAL_HOME = "https://panel.originalpro.online/"
ORIGINAL_KEY = "cda11IxQWjX1bZP5Yfdhqm2B4NwzuLJGHE3RDCcsAn7rT9aVU0"
ORIGINAL_PAGE_SIZE = 100
REEZN_API = "https://api.ott-topred.site/api/v3/"
REEZN_SIGN_KEY = b"fb674c0686ec14c0fc271e93663ac7cc1189036a4ef57ab6444b7957cf63dc72f1a36b12dec96da4907740916ba36926fede34cde3f2a0785eb2c70996b4276b"
REEZN_LIVE_PATH = "app/live/get_channels_db.php"
REEZN_CACHE_TTL = 300
_reezn_live_cache = {"time": 0, "channels": []}
TMDB_API = "https://api.themoviedb.org/3/"
TMDB_IMAGE = "https://image.tmdb.org/t/p/w500"
TMDB_KEY = "467b493108e523c37d6fb1bc24c926b3"
BROWSER_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)


def _headers(user_agent, referer=""):
    user_agent = str(user_agent or "").strip()
    if "Mozilla/" not in user_agent:
        user_agent = BROWSER_UA
    result = {"User-Agent": user_agent, "Accept": "*/*"}
    if referer:
        result["Referer"] = referer
    return result


def _decode_arabic(raw):
    if isinstance(raw, str):
        return raw
    for encoding in ("utf-8", "cp1256", "iso-8859-6"):
        try:
            return raw.decode(encoding)
        except Exception:
            pass
    return raw.decode("utf-8", "replace")


def parse_elahmad_catalogue(text):
    channels = {}
    pages = {}
    for raw_line in str(text or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or line.startswith("//"):
            continue
        match = re.match(r'chan\[(\d+)\]\s*=\s*["\'](.*?)["\']\s*;', line)
        if match:
            channels[int(match.group(1))] = match.group(2).strip()
            continue
        match = re.match(r'surl\[(\d+)\]\s*=\s*["\'](.*?)["\']\s*;', line)
        if match:
            pages[int(match.group(1))] = match.group(2).strip()
    result = []
    for index in sorted(set(channels).intersection(pages)):
        name = channels[index].strip()
        page = pages[index].strip()
        if not name or name.lower() == "file" or not page or page.lower() == "file":
            continue
        if page.lower().endswith(".swf"):
            continue
        result.append({"name": name, "page": urljoin(ELAHMAD_HOME, page), "source": "elahmad"})
    return result



# Ostora TV v7.0 does not call the visible fallback host directly.  It first
# resolves a DNS TXT bootstrap record, decrypts/decompresses that configuration,
# then uses the runtime host and UA from it.  API bodies are AES-256-CBC text.
OSTORA_BOOTSTRAP_NAME = "start.ver6.top"
OSTORA_DOH = (
    "https://1.1.1.1/dns-query",
    "https://8.8.8.8/resolve",
    "https://1.0.0.1/dns-query",
    "https://8.8.4.4/resolve",
)
OSTORA_API = "/api/v6.2/"
OSTORA_PLAYER_FALLBACK_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
OSTORA_BRIGHTCOVE_API = "https://edge.api.brightcove.com/playback/v1/accounts/6057955906001/videos/ref:"
OSTORA_BRIGHTCOVE_POLICY = "BCpkADawqM0ulfr-fTtpl4YejzzO3z_76a_ZRKgvLDjHckfm-KQwPTJRIv8pznKIST7BMwBUYIVW-hySTUB5PQ8altdPHr9UcaQnGrs_ePsEEYoyoGhi3ezBsr3YRpLv9xqjzcBJBxVr_6Sh"
OSTORA_AES_KEY = "4e5c6d1a8b3fe8137a3b9df26a9c4de195267b8e6f6c0b4e1c3ae1d27f2b4e6f"
OSTORA_AES_IV = "a9c21f8d7e6b4a9db12e4f9d5c1a7b8e"
OSTORA_CONFIG_TTL = 300
_ostora_config_cache = {"time": 0, "value": None}


def _ostora_device_id():
    seed = ""
    for path in ("/etc/machine-id", "/proc/stb/info/serial", "/proc/stb/info/chipset"):
        try:
            with open(path, "r") as handle:
                seed = handle.read().strip()
            if seed:
                break
        except Exception:
            pass
    if not seed:
        seed = str(uuid.getnode())
    return hashlib.sha256(seed.encode("utf-8")).hexdigest()[:16]


OSTORA_DEVICE_ID = _ostora_device_id()


def _ostora_decrypt(value):
    value = str(value or "").strip()
    if not value:
        raise RuntimeError("Ostora returned an empty encrypted response")
    value += "=" * ((4 - len(value) % 4) % 4)
    try:
        encrypted = base64.urlsafe_b64decode(value.encode("ascii"))
    except Exception:
        raise RuntimeError("Ostora returned invalid encrypted data")
    proc = subprocess.Popen(
        [_openssl_path(), "enc", "-d", "-aes-256-cbc", "-nosalt",
         "-K", OSTORA_AES_KEY, "-iv", OSTORA_AES_IV],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate(encrypted)
    if proc.returncode != 0:
        raise RuntimeError("Unable to decrypt Ostora response")
    try:
        return stdout.decode("utf-8").strip()
    except Exception:
        return str(stdout).strip()


def _ostora_setting(value):
    value = str(value or "").strip()
    if not value:
        return ""
    value += "=" * ((4 - len(value) % 4) % 4)
    try:
        return base64.b64decode(value.encode("ascii")).decode("utf-8").strip()
    except Exception:
        return ""


def _ostora_bootstrap(force=False):
    cached = _ostora_config_cache.get("value")
    if cached and not force and time.time() - _ostora_config_cache.get("time", 0) < OSTORA_CONFIG_TTL:
        return cached
    last = None
    for endpoint in OSTORA_DOH:
        try:
            response = requests.get(
                endpoint, params={"name": OSTORA_BOOTSTRAP_NAME, "type": "txt"},
                headers={"accept": "application/dns-json"}, timeout=30, verify=False)
            response.raise_for_status()
            answer = response.json().get("Answer") or []
            if not answer:
                raise RuntimeError("DNS TXT answer is empty")
            encrypted = "".join(str(row.get("data") or "") for row in answer)
            encrypted = encrypted.replace('"', "").replace(" ", "")
            packed = _ostora_decrypt(encrypted)
            decoded = base64.b64decode(packed.encode("ascii"))
            settings = json.loads(zlib.decompress(decoded).decode("utf-8"))
            hosts = []
            for index in range(10):
                host = _ostora_setting(settings.get("x%d" % index))
                if host and host not in hosts:
                    hosts.append(host)
            if not hosts:
                raise RuntimeError("Ostora bootstrap did not return an API host")
            config = {
                "hosts": hosts,
                "ua": _ostora_setting(settings.get("ua")),
                "dns": _ostora_setting(settings.get("dns")),
                "prefix": _ostora_setting(settings.get("ps")),
            }
            _ostora_config_cache.update({"time": time.time(), "value": config})
            return config
        except Exception as error:
            last = error
    raise RuntimeError("Ostora bootstrap is unavailable: %s" % last)


def _ostora_headers(user_agent="", referer=""):
    config = _ostora_bootstrap()
    ua = str(config.get("ua") or user_agent or BROWSER_UA).strip()
    return {"id": OSTORA_DEVICE_ID, "User-Agent": ua}


def _ostora_get(path, user_agent="", params=None):
    last = None
    config = _ostora_bootstrap()
    for host in config.get("hosts") or []:
        url = "https://" + host.strip().strip("/") + "/" + str(path or "").lstrip("/")
        try:
            response = requests.get(url, params=params, headers=_ostora_headers(user_agent),
                                    timeout=40, verify=False, allow_redirects=True)
            response.raise_for_status()
            text = (response.text or "").strip()
            if text.startswith(("<!DOCTYPE", "<html", "<HTML")):
                raise RuntimeError("Ostora API returned HTML")
            payload = json.loads(_ostora_decrypt(text))
            if not isinstance(payload, (dict, list)):
                raise RuntimeError("Ostora API returned invalid data")
            return payload, response.url
        except Exception as error:
            last = error
    raise RuntimeError("Ostora API is unavailable: %s" % last)


def _ostora_dicts(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            for row in _ostora_dicts(child):
                yield row
    elif isinstance(value, list):
        for child in value:
            for row in _ostora_dicts(child):
                yield row


def _ostora_text(row, *keys):
    for key in keys:
        value = row.get(key) if isinstance(row, dict) else None
        if value not in (None, "", []):
            return str(value).strip()
    return ""


def _ostora_kind(row):
    item_type = _ostora_text(row, "type").lower()
    if item_type in ("live", "movie", "series"):
        return item_type
    raw = " ".join([_ostora_text(row, "kind", "section", "content_type", "model"),
                    _ostora_text(row, "category_name", "category", "name", "title")]).lower()
    if any(x in raw for x in ("series", "serial", "مسلسل", "مسلسلات", "episode", "season")):
        return "series"
    if any(x in raw for x in ("movie", "film", "فيلم", "افلام", "أفلام", "cinema")):
        return "movie"
    if any(x in raw for x in ("live", "channel", "tv", "قناة", "قنوات", "مباشر", "match")):
        return "live"
    if _ostora_text(row, "adp") == "3":
        return "series"
    return ""


def _ostora_image(row):
    return _ostora_text(row, "image", "image_url", "poster", "poster_url", "logo", "thumbnail", "thumb")


def _ostora_id(row):
    return _ostora_text(row, "id", "ID", "category_id", "channel_id", "movie_id", "series_id", "episode_id")


def _ostora_name(row):
    return _ostora_text(row, "name", "title", "channel_name", "movie_name", "series_name", "episode_name")


def _ostora_url_values(value, out=None, label=""):
    if out is None:
        out = []
    if isinstance(value, dict):
        for key, child in value.items():
            kl = str(key).lower()
            if isinstance(child, string_types):
                u = str(child).strip().replace("\\/", "/")
                if u.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")) and (
                        any(x in kl for x in ("url", "link", "stream", "video", "file", "src", "server")) or
                        re.search(r"\.(?:m3u8|mpd|mp4|mkv|ts)(?:\?|$)", u, re.I)):
                    out.append((u, str(key)))
            else:
                _ostora_url_values(child, out, str(key))
    elif isinstance(value, list):
        for child in value:
            _ostora_url_values(child, out, label)
    return out


def _ostora_items(payload):
    if not isinstance(payload, dict):
        return payload if isinstance(payload, list) else []
    data = payload.get("data")
    if isinstance(data, dict):
        return data.get("items") or []
    return data if isinstance(data, list) else []


def _ostora_playable(row):
    return bool(_ostora_text(row, "source", "url", "stream")) or _ostora_text(row, "type").lower() in (
        "live", "movie", "series")


def _ostora_entry(row, kind=""):
    entry = {"id": _ostora_id(row), "name": _ostora_name(row) or "Ostora",
            "image": _ostora_image(row), "kind": _ostora_kind(row) or kind,
            "source": "ostora", "raw": row,
            "description": _ostora_text(row, "description", "overview", "story")}
    entry["is_group"] = not _ostora_playable(row)
    return entry


def _ostora_main(user_agent):
    payload, _ = _ostora_get(OSTORA_API + "main", user_agent, {"page": 1})
    return [row for row in _ostora_items(payload) if isinstance(row, dict)]


def fetch_ostora_groups(kind, user_agent):
    rows = _ostora_main(user_agent)
    groups = []
    for row in rows:
        name = _ostora_name(row)
        row_kind = _ostora_kind(row)
        if kind == "movie":
            include = row_kind == "movie"
        elif kind == "series":
            include = row_kind == "series"
        else:
            include = row_kind not in ("movie", "series")
        if not include:
            continue
        entry = _ostora_entry(row, kind)
        entry["source"] = "ostora_group"
        entry["is_group"] = True
        groups.append(entry)
    return groups


def fetch_ostora_items(kind, user_agent, parent=None, page=1):
    parent = dict(parent or {})
    cid = str(parent.get("id") or "").strip()
    if not cid:
        raise RuntimeError("Ostora category id is missing")
    payload, _ = _ostora_get(OSTORA_API + "category/" + cid, user_agent, {"page": page})
    rows = [row for row in _ostora_items(payload) if isinstance(row, dict)]
    entries, seen = [], set()
    for row in rows:
        name = _ostora_name(row)
        if not name:
            continue
        rid = _ostora_id(row)
        sig = (rid, name)
        if sig in seen:
            continue
        seen.add(sig); entries.append(_ostora_entry(row, kind))
    last_page = page
    total = len(entries)
    if isinstance(payload, dict):
        data = payload.get("data") or {}
        pagination = data.get("pagination") if isinstance(data, dict) else {}
        try: last_page = max(page, int((pagination or {}).get("pages") or page))
        except Exception: pass
        try: total = int((pagination or {}).get("total") or total)
        except Exception: pass
    return {"entries": entries, "page": page, "last_page": last_page, "total": total}


def fetch_ostora_seasons(show, user_agent):
    result = fetch_ostora_items("series", user_agent, show, 1).get("entries") or []
    return [{"id": "direct", "name": u"الحلقات", "kind": "series",
             "source": "ostora", "raw": {"episodes": [row.get("raw") for row in result]}}] if result else []


def fetch_ostora_episodes(season, user_agent):
    raw = dict((season or {}).get("raw") or {})
    episodes = raw.get("episodes") or raw.get("episode") or raw.get("items") or []
    if isinstance(episodes, dict): episodes = list(episodes.values())
    result = []
    for i, row in enumerate(episodes if isinstance(episodes, list) else []):
        if not isinstance(row, dict): row = {"url": str(row)}
        item = _ostora_entry(row, "series")
        item["name"] = _ostora_name(row) or (u"الحلقة %d" % (i + 1))
        result.append(item)
    return result


def _ostora_normalize_stream(value, config_prefix="", strip_player_scheme=True):
    """Normalize one Ostora source while preserving v7 live-player payloads."""
    source = str(value or "").strip().replace("\\/", "/")
    if not source:
        return ""
    if config_prefix:
        source = source.replace(config_prefix, "")
    if "<F>" in source:
        source = source.split("<F>", 1)[1]
    source = re.sub(r"\|\d+$", "", source).strip()
    if strip_player_scheme:
        source = re.sub(r"^urlvplayer://", "", source, flags=re.I)
    source = source.replace("random_id", uuid.uuid4().hex + uuid.uuid4().hex[:8])
    source = source.replace("android_id", OSTORA_DEVICE_ID)
    return source.strip()


def _ostora_stream_candidates(raw):
    """Collect playback/extractor candidates from an Ostora API object."""
    candidates = []
    seen = set()

    def walk(value, label=""):
        if isinstance(value, dict):
            for key, child in value.items():
                walk(child, str(key))
            return
        if isinstance(value, list):
            for child in value:
                walk(child, label)
            return
        if not isinstance(value, string_types):
            return
        text = str(value).strip().replace("\\/", "/")
        if not text:
            return
        lower = text.lower()
        # v7 can prepend its bootstrap marker / <F> before a real source, so
        # checking startswith() alone drops valid alternate providers.
        is_protocol = any(token in lower for token in (
            "http://", "https://", "rtmp://", "rtsp://", "urlvplayer://",
            "urlplayer://", "brightcove|"))
        is_media = bool(re.search(r"\.(?:m3u8|mpd|mp4|mkv|ts)(?:\?|$)", lower))
        key_hint = str(label or "").lower()
        stream_hint = any(token in key_hint for token in (
            "source", "stream", "server", "url", "link", "video", "file",
            "play", "player", "hls", "m3u", "quality", "hd", "sd", "adp"))
        if not (is_protocol and (stream_hint or is_media)):
            return
        if text not in seen:
            seen.add(text)
            candidates.append((text, str(label or "")))

    walk(raw)
    return candidates



def _ostora_loose_live_candidates(raw):
    """Collect alternate live fields even when v7 stores an encoded token.

    Some category rows use adp/server fields whose value is not itself an
    http URL (percent/base64/player token).  The strict collector intentionally
    ignored these, which made the row look as if it had no stream at all.
    """
    result, seen = [], set()
    hints = ("source", "stream", "server", "url", "link", "video", "file",
             "play", "player", "hls", "m3u", "quality", "hd", "sd", "adp")

    def walk(value, label=""):
        if isinstance(value, dict):
            for key, child in value.items():
                walk(child, str(key))
            return
        if isinstance(value, list):
            for child in value:
                walk(child, label)
            return
        if not isinstance(value, string_types):
            return
        text = str(value or "").strip().replace("\\/", "/")
        if not text:
            return
        lower, key = text.lower(), str(label or "").lower()
        interesting = any(token in key for token in hints) or any(token in lower for token in (
            "http://", "https://", "urlvplayer://", "urlplayer://", "brightcove|",
            "###", "<f>"))
        if interesting and text not in seen:
            seen.add(text); result.append((text, str(label or "")))

    walk(raw)
    return result


def _ostora_decode_candidate_variants(value, config_prefix=""):
    """Return textual forms of one alternate source without guessing endpoints."""
    result, seen = [], set()

    def add(text):
        text = str(text or "").strip().replace("\\/", "/")
        if not text or text in seen:
            return
        seen.add(text); result.append(text)

    original = _ostora_normalize_stream(value, config_prefix, strip_player_scheme=False)
    add(original)

    # Percent encoding is used around some player tokens.  Decode gradually so
    # signed query strings are not mangled more than necessary.
    work = original
    for _unused in range(3):
        try:
            nxt = unquote(work)
        except Exception:
            break
        if nxt == work:
            break
        add(nxt); work = nxt

    # adp fields can contain a compact base64/url-safe wrapper around the real
    # player instruction.  Only accept decoded text when it clearly contains a
    # playback marker/URL so arbitrary ids are never treated as streams.
    for candidate in list(result):
        compact = candidate.strip()
        if 16 <= len(compact) <= 8192 and re.match(r'^[A-Za-z0-9_+/=%-]+$', compact):
            for raw_b64 in (compact, compact.replace('-', '+').replace('_', '/')):
                try:
                    padded = raw_b64 + '=' * ((4 - len(raw_b64) % 4) % 4)
                    decoded = base64.b64decode(padded.encode('ascii')).decode('utf-8', 'ignore').strip()
                except Exception:
                    continue
                low = decoded.lower()
                if any(x in low for x in ('http://', 'https://', 'urlvplayer://', 'urlplayer://', 'brightcove|')):
                    add(decoded)

    # Do not discard extractor-marker strings.  Preserve the whole value first,
    # then expose individual pieces containing a known playback instruction.
    for candidate in list(result):
        for part in re.split(r'###|<F>', candidate, flags=re.I):
            part = part.strip(' |;,:\t\r\n')
            low = part.lower()
            if any(x in low for x in ('http://', 'https://', 'urlvplayer://', 'urlplayer://', 'brightcove|')):
                add(part)
    return result


def _ostora_expand_live_candidate(value, config_prefix, user_agent, base_headers):
    """Expand one strict/loose live candidate into playable URLs."""
    expanded = []
    seen = set()

    def add(url, agent="", special=False):
        url = str(url or "").strip().replace("\\/", "/").strip("\"' <>")
        if not url.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
            return
        key = (url, str(agent or ""))
        if key in seen:
            return
        seen.add(key); expanded.append((url, str(agent or ""), bool(special)))

    for variant in _ostora_decode_candidate_variants(value, config_prefix):
        low = variant.lower()
        # Brightcove may be surrounded by marker text.  The helper itself finds
        # the marker and resolves the exact account/policy present in the APK.
        if "brightcove|" in low:
            for url in _ostora_resolve_brightcove(variant, user_agent):
                add(url, "", False)

        # Player deep links can appear after a prefix/marker rather than at byte 0.
        for match in re.finditer(r'(?:urlvplayer|urlplayer)://[^\s\"\'<>]+', variant, re.I):
            deep = match.group(0).rstrip(')]},;')
            for url, agent in _ostora_player_payloads(deep, config_prefix):
                add(url, agent, True)
        if low.startswith(("urlvplayer://", "urlplayer://")):
            for url, agent in _ostora_player_payloads(variant, config_prefix):
                add(url, agent, True)

        # Plain URLs embedded in JSON-ish/marker text.
        if low.startswith(("http://", "https://", "rtmp://", "rtsp://")):
            add(_ostora_normalize_stream(variant, config_prefix), "", False)
        for url in re.findall(r'https?://[^\s\"\'<>]+', variant, re.I):
            add(url.rstrip(')]},;'), "", False)
    return expanded

def _ostora_quality_from_label(label):
    text = str(label or "")
    match = re.search(r"(?:^|\D)(2160|1440|1080|720|576|480|360|244)(?:p|\D|$)", text, re.I)
    return "%sp" % match.group(1) if match else ""


def _ostora_raw_stream_headers(raw, user_agent):
    """Headers the Android path can carry into the live-player request."""
    headers = dict(_ostora_headers(user_agent))
    agent = _ostora_text(raw, "agent", "user_agent", "user-agent")
    if agent:
        headers["User-Agent"] = agent
    for src_keys, dst in (
            (("referer", "referrer", "ref"), "Referer"),
            (("origin",), "Origin"),
            (("cookie", "cookies"), "Cookie"),
            (("authorization", "auth"), "Authorization")):
        value = _ostora_text(raw, *src_keys)
        if value:
            headers[dst] = value
    return headers


OSTORA_URLPLAYER_KEY = u"jMkn9kbN4Xr8V3NKXdsRA7QwY4Ars9mv4Xr8V3NKXYFhbYgw"


def _ostora_url_decode_component(value):
    """Mirror java.net.URLDecoder.decode(value, "UTF-8")."""
    text = str(value or "")
    try:
        return unquote(text.replace("+", " "))
    except Exception:
        return text.replace("+", " ")


def _ostora_uri_query_parameter(query, wanted):
    """Mirror Android Uri.getQueryParameter without losing '+' in Base64.

    Uri decoding handles percent escapes first; URL Video Player then calls
    URLDecoder.decode() once more.  parse_qs() cannot be used here because it
    turns '+' into a space too early.
    """
    wanted = str(wanted or "")
    for part in str(query or "").split("&"):
        key, sep, value = part.partition("=")
        try:
            key = unquote(key)
        except Exception:
            pass
        if key == wanted:
            try:
                return unquote(value) if sep else ""
            except Exception:
                return value if sep else ""
    return ""


def _ostora_urlplayer_xor(value):
    """The exact lightweight transform used by Url Video Player 4.0 Scheme."""
    text = str(value or "")
    key = OSTORA_URLPLAYER_KEY
    if not text or not key:
        return text
    return "".join(chr(ord(ch) ^ ord(key[i % len(key)])) for i, ch in enumerate(text))


def _ostora_decode_urlplayer_url(encoded):
    """Decode the encrypted `url` query parameter used by urlvplayer://play."""
    encoded = _ostora_url_decode_component(encoded).strip()
    if not encoded:
        return ""
    # Android code normalises standard Base64 into URL-safe Base64 and uses
    # Base64.URL_SAFE (flag 8).
    encoded = encoded.replace("/", "_").replace(" ", "-").replace("+", "-")
    try:
        encoded += "=" * ((4 - (len(encoded) % 4)) % 4)
        raw = base64.urlsafe_b64decode(encoded.encode("ascii"))
        if not isinstance(raw, str):
            raw = raw.decode("utf-8", "ignore")
        plain = _ostora_urlplayer_xor(raw)
        return _ostora_url_decode_component(plain).strip()
    except Exception:
        return ""


def _ostora_player_payloads(value, config_prefix=""):
    """Decode Url Video Player deep-links exactly as its Scheme activity does.

    Returns [(url, user_agent), ...].  A generic fallback is retained for old
    builds that used a plain URL instead of the encrypted v4 `play` scheme.
    """
    original = _ostora_normalize_stream(value, config_prefix, strip_player_scheme=False)
    if not original:
        return []

    result = []
    seen = set()

    def add(url, agent=""):
        url = str(url or "").strip().replace("\\/", "/").strip("\"' <>")
        if url.lower().startswith(("http://", "https://")) and url not in seen:
            seen.add(url)
            result.append((url, str(agent or "").strip()))

    lower = original.lower()
    if lower.startswith(("urlvplayer://", "urlplayer://")):
        try:
            parsed = urlparse(original)
            host = str(parsed.netloc or "").lower()
            if host.endswith("play") or host.endswith("web"):
                enc_url = _ostora_uri_query_parameter(parsed.query, "url")
                enc_agent = _ostora_uri_query_parameter(parsed.query, "agent")
                decoded_url = _ostora_decode_urlplayer_url(enc_url)
                decoded_agent = _ostora_url_decode_component(enc_agent)
                add(decoded_url, decoded_agent)
        except Exception:
            pass

    # Backward-compatible fallback: plain/percent-encoded deep-link payloads.
    work = original
    for scheme in ("urlvplayer://", "urlplayer://"):
        if work.lower().startswith(scheme):
            work = work[len(scheme):].lstrip("/")
            break
    decoded = work
    for _unused in range(3):
        try:
            nxt = unquote(decoded)
        except Exception:
            break
        if nxt == decoded:
            break
        decoded = nxt
    add(work)
    add(decoded)
    for text in (work, decoded):
        try:
            parsed = urlparse(text if "://" in text else "http://x/?" + text.lstrip("?"))
            query = parse_qs(parsed.query, keep_blank_values=False)
            for key in ("url", "link", "src", "source", "stream", "file", "data", "u"):
                for candidate in query.get(key, []):
                    add(unquote(str(candidate)))
        except Exception:
            pass
        for match in re.findall(r"https?://[^\s\"'<>]+", text, re.I):
            add(match.rstrip(")]},;"))
    return result


def _ostora_player_payload_urls(value, config_prefix=""):
    return [row[0] for row in _ostora_player_payloads(value, config_prefix)]

def _ostora_extract_urls_from_text(text):
    """Extract live media URLs from a small JSON/text resolver response."""
    found = []
    def add(value):
        value = str(value or "").strip().replace("\\/", "/")
        if value.lower().startswith(("http://", "https://")) and value not in found:
            found.append(value)
    stripped = str(text or "").strip()
    if not stripped:
        return found
    if stripped.startswith(("{", "[")):
        try:
            obj = json.loads(stripped)
            def walk(value):
                if isinstance(value, dict):
                    for child in value.values(): walk(child)
                elif isinstance(value, list):
                    for child in value: walk(child)
                elif isinstance(value, string_types):
                    v = str(value).replace("\\/", "/").strip()
                    if v.lower().startswith("urlvplayer://"):
                        for u in _ostora_player_payload_urls(v): add(u)
                    elif v.lower().startswith(("http://", "https://")):
                        add(v)
            walk(obj)
        except Exception:
            pass
    for deep in re.findall(r"(?:urlvplayer|urlplayer)://[^\s\"'<>]+", stripped, re.I):
        deep = deep.rstrip(")]},;")
        for u in _ostora_player_payload_urls(deep):
            add(u)
    for match in re.findall(r"https?://[^\s\"'<>]+", stripped, re.I):
        add(match.rstrip(")]},;"))
    return found



def _ostora_resolve_brightcove(value, user_agent):
    '''Resolve the Brightcove alternate source used by Ostora TV v7.'''
    value = str(value or "").strip()
    pos = value.lower().find("brightcove|")
    if pos < 0:
        return []
    ref = value[pos + len("brightcove|"):].strip().strip("\"' <>/")
    if not ref:
        return []
    if ref.lower().startswith("ref:"):
        ref = ref[4:]
    ref = ref.split("<F>", 1)[0].split("###", 1)[0].strip()
    # Some API rows append player metadata after the reference id.
    if "|" in ref:
        ref = ref.split("|", 1)[0].strip()
    if not ref:
        return []

    endpoint = OSTORA_BRIGHTCOVE_API + quote(ref, safe="._-~")
    headers = {
        "User-Agent": str(user_agent or OSTORA_PLAYER_FALLBACK_UA),
        "Accept": "application/json;pk=" + OSTORA_BRIGHTCOVE_POLICY,
    }
    try:
        response = requests.get(endpoint, headers=headers, timeout=(7, 18), verify=False)
        response.raise_for_status()
        payload = response.json()
    except Exception:
        return []

    sources = payload.get("sources", []) if isinstance(payload, dict) else []
    if isinstance(sources, dict):
        sources = list(sources.values())
    ranked = []
    for row in sources if isinstance(sources, list) else []:
        if not isinstance(row, dict):
            continue
        src = str(row.get("src") or row.get("url") or "").strip().replace("\\/", "/")
        if not src.lower().startswith(("http://", "https://")):
            continue
        typ = str(row.get("type") or "").lower()
        container = str(row.get("container") or "").lower()
        lower = src.lower()
        if "mpegurl" in typ or "m3u8" in lower:
            score = 0
        elif "dash" in typ or "mpd" in lower:
            score = 1
        elif "mp4" in typ or container == "mp4" or re.search(r"\.mp4(?:\?|$)", lower):
            score = 2
        else:
            score = 3
        ranked.append((score, src))
    ranked.sort(key=lambda row: row[0])
    result = []
    for _score, src in ranked:
        if src not in result:
            result.append(src)
    return result

def _ostora_probe_live_url(url, headers):
    """Resolve the small redirect/JSON layer used before Ostora live HLS.

    It intentionally reads only the first 256 KiB, so a TS/live body is never
    downloaded into Enigma2 memory.  The returned cookie header is preserved
    for the local HLS relay.
    """
    current = str(url or "").strip()
    if not current.lower().startswith(("http://", "https://")):
        return [(current, dict(headers or {}))] if current else []
    session = requests.Session()
    result_headers = dict(headers or {})
    response = None
    try:
        for _unused in range(5):
            response = session.get(current, headers=result_headers, timeout=(5, 12),
                                   verify=False, allow_redirects=False, stream=True)
            if response.status_code in (301, 302, 303, 307, 308):
                target = str(response.headers.get("Location") or "").strip()
                if not target:
                    break
                target = urljoin(current, target)
                # Never leak explicit auth/cookie to an unrelated host. Session
                # cookies set by the redirect chain are added again below.
                if urlparse(target).netloc != urlparse(current).netloc:
                    result_headers.pop("Authorization", None)
                    result_headers.pop("Cookie", None)
                current = target
                response.close(); response = None
                continue
            response.raise_for_status()
            ctype = str(response.headers.get("Content-Type") or "").lower()
            final_url = str(response.url or current)
            # For obvious media streams, do not consume the body.
            if ("video/" in ctype or "audio/" in ctype or
                    re.search(r"\.(?:ts|mp4|mkv|mpd)(?:\?|$)", final_url, re.I)):
                break
            raw = response.raw.read(262144, decode_content=True)
            text = raw.decode("utf-8", "ignore") if isinstance(raw, bytes) else str(raw or "")
            if text.lstrip().upper().startswith("#EXTM3U"):
                break
            nested = _ostora_extract_urls_from_text(text)
            if nested:
                cookies = session.cookies.get_dict()
                if cookies:
                    result_headers["Cookie"] = "; ".join("%s=%s" % (k, v) for k, v in cookies.items())
                return [(u, dict(result_headers)) for u in nested]
            break
        cookies = session.cookies.get_dict()
        if cookies:
            result_headers["Cookie"] = "; ".join("%s=%s" % (k, v) for k, v in cookies.items())
        return [(str(response.url if response is not None else current), result_headers)]
    except Exception:
        return [(current, result_headers)]
    finally:
        try:
            if response is not None: response.close()
        except Exception:
            pass
        try: session.close()
        except Exception: pass


def resolve_ostora_live_item(item, user_agent):
    """Resolve Ostora v7 live channels through the player/resolver layer.

    Pass 1 preserves the R66 path that already works for the main bouquets.
    Pass 2 only runs when that path yields nothing and handles encoded adp /
    alternate-provider fields used by later bouquets.
    """
    item = dict(item or {})
    raw = dict(item.get("raw") or {})
    name = str(item.get("name") or "Ostora")
    config_prefix = str((_ostora_bootstrap().get("prefix") or ""))[:5]
    base_headers = _ostora_raw_stream_headers(raw, user_agent)
    streams, seen = [], set()

    def consume(candidates):
        for raw_source, label in candidates:
            for source, player_agent, is_player_link in _ostora_expand_live_candidate(
                    raw_source, config_prefix, user_agent, base_headers):
                if is_player_link:
                    # Exact Url Video Player behaviour: only its supplied UA is
                    # forwarded to media requests, not the Ostora API device id.
                    player_headers = {"User-Agent": player_agent or OSTORA_PLAYER_FALLBACK_UA}
                else:
                    player_headers = dict(base_headers)
                resolved = (_ostora_probe_live_url(source, player_headers)
                            if source.lower().startswith(("http://", "https://"))
                            else [(source, dict(player_headers))])
                for current, stream_headers in resolved:
                    current = str(current or "").strip()
                    if not current or current in seen:
                        continue
                    seen.add(current)
                    quality = _ostora_quality_from_label(label)
                    server_name = u"السيرفر %d" % (len(streams) + 1)
                    label_clean = str(label or "").strip().replace("_", " ").replace("-", " ")
                    if label_clean and not quality and label_clean.lower() not in (
                            "source", "url", "stream", "server"):
                        server_name = u"%s - %s" % (server_name, label_clean)
                    stream = {
                        "url": current,
                        "headers": dict(stream_headers or player_headers),
                        "name": server_name,
                        "server": server_name,
                        "source": "ostora",
                        "relay": current.lower().startswith(("http://", "https://")),
                    }
                    if quality:
                        stream["quality"] = quality
                    if "m3u8" in current.lower() or "redirect" in current.lower():
                        stream["mediatype"] = "hls"
                    streams.append(stream)

    strict = _ostora_stream_candidates(raw)
    if not strict:
        fallback = _ostora_text(raw, "source", "url", "stream")
        if fallback:
            strict = [(fallback, "source")]
    consume(strict)

    # Later bouquets can expose adp1..adp9 / alternate providers even when a
    # primary field is present. R68 only tried these when the primary path
    # returned nothing, so a dead primary URL hid working backup servers.
    # Always merge alternate candidates; final URL de-duplication keeps the
    # known-good primary server first while exposing backups in the chooser.
    loose = _ostora_loose_live_candidates(raw)
    consume(loose)

    if not streams:
        # Lightweight diagnostics: no secrets/cookies are written, only keys
        # and shortened candidate shapes needed to identify a new provider type.
        try:
            values = []
            for value, label in _ostora_loose_live_candidates(raw):
                sample = str(value).replace("\n", " ")[:220]
                values.append("%s=%s" % (label, sample))
            with open("/tmp/xklass_ostora_resolve.log", "a") as log:
                log.write("FAIL %s id=%s keys=%s candidates=%s\n" % (
                    name, _ostora_id(raw), ",".join(sorted(str(k) for k in raw.keys())),
                    " || ".join(values[:20])))
        except Exception:
            pass
        raise RuntimeError("Ostora returned no playable live stream")

    result = dict(item)
    result["streams"] = streams
    result["urls"] = [x["url"] for x in streams]
    result["url"] = streams[0]["url"]
    result["headers"] = streams[0].get("headers", base_headers)
    result["name"] = name
    return result

def resolve_ostora_item(item, user_agent):
    """Resolve Ostora movies/series. Live uses resolve_ostora_live_item()."""
    item = dict(item or {})
    raw = dict(item.get("raw") or {})
    name = str(item.get("name") or "Ostora")
    config_prefix = str((_ostora_bootstrap().get("prefix") or ""))[:5]
    headers = {"User-Agent": _ostora_text(raw, "agent", "user_agent") or _ostora_headers(user_agent)["User-Agent"]}

    candidates = _ostora_stream_candidates(raw)
    if not candidates:
        fallback = _ostora_text(raw, "source", "url", "stream")
        if fallback: candidates = [(fallback, "source")]
    if not candidates:
        raise RuntimeError("Ostora returned no playable stream")

    streams, seen_urls = [], set()
    for raw_source, label in candidates:
        source = _ostora_normalize_stream(raw_source, config_prefix)
        if not source or source in seen_urls or source.startswith("brightcove|") or "###" in source:
            continue
        if not source.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
            continue
        stream_headers = dict(headers)
        current = source
        if "redirect.m3u8" in current.lower():
            try:
                response = requests.get(current, headers=stream_headers, timeout=25,
                                        verify=False, allow_redirects=False)
                target = str(response.headers.get("Location") or "").strip()
                if target: current = urljoin(current, target)
            except Exception:
                pass
        if current in seen_urls: continue
        seen_urls.add(current)
        quality = _ostora_quality_from_label(label)
        server_name = u"السيرفر %d" % (len(streams) + 1)
        label_clean = str(label or "").strip().replace("_", " ").replace("-", " ")
        if label_clean and not quality and label_clean.lower() not in ("source", "url", "stream", "server"):
            server_name = u"%s - %s" % (server_name, label_clean)
        stream = {"url": current, "headers": stream_headers, "name": server_name,
                  "server": server_name, "source": "ostora"}
        if quality: stream["quality"] = quality
        if re.search(r"\.(?:m3u8|json)(?:\?|$)", current, re.I) or "m3u8" in current.lower():
            stream["mediatype"] = "hls"
        streams.append(stream)
    if not streams:
        raise RuntimeError("Ostora returned no direct playable stream")
    result = dict(item)
    result["streams"] = streams
    result["urls"] = [x["url"] for x in streams]
    result["url"] = streams[0]["url"]
    result["headers"] = streams[0].get("headers", headers)
    result["name"] = name
    return result

def fetch_elahmad_catalogue(user_agent):
    # source.php used to be the catalogue, but the current site can return an
    # empty/blocked response there while the public live page still contains
    # the complete channel data. Try both dynamically.
    errors = []
    for url in (ELAHMAD_SOURCE, ELAHMAD_HOME):
        try:
            response = requests.get(url, headers=_headers(user_agent, ELAHMAD_HOME),
                                    timeout=35, verify=False)
            response.raise_for_status()
            text = _decode_arabic(response.content)
            channels = parse_elahmad_catalogue(text)
            if not channels:
                # Newer page builds put channel targets in anchors/onclicks.
                found, seen = [], set()
                patterns = [
                    r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
                    r'(?:window\.open|location(?:\.href)?)\s*\(?\s*["\']([^"\']+)["\']',
                ]
                for pattern in patterns:
                    for match in re.finditer(pattern, text, re.I | re.S):
                        target = match.group(1).strip()
                        if not target or target.startswith(("#", "javascript:")):
                            continue
                        page = urljoin(ELAHMAD_HOME, target)
                        if page in seen or not page.startswith(("http://", "https://")):
                            continue
                        label = re.sub(r'<[^>]+>', ' ', match.group(2) if match.lastindex and match.lastindex > 1 else '')
                        label = re.sub(r'\s+', ' ', label).strip()
                        if not label:
                            continue
                        seen.add(page); found.append({"name": label, "page": page, "source": "elahmad"})
                channels = found
            if channels:
                return channels
        except Exception as error:
            errors.append(str(error))
    raise RuntimeError("Elahmad returned an empty or blocked catalogue: %s" % (errors[-1] if errors else "no channels"))


def fetch_fajer_channels(user_agent):
    response = requests.get(FAJER_API + "?t=%d" % int(time.time() * 1000),
                            headers=_headers(user_agent, "https://tv.alfajertv.com/"),
                            timeout=(7, 20), verify=False)
    response.raise_for_status()
    payload = response.json()
    streams = payload.get("streams", {}) if isinstance(payload, dict) else {}
    result = []
    for number in range(1, 6):
        key = "fajer%d" % number
        url = str(streams.get(key) or "").strip()
        result.append({"name": "Al Fajer %d" % number, "url": url,
                       "number": number, "source": "alfajer",
                       "headers": {"Referer": "https://tv.alfajertv.com/"}})
    return result


def _yacine_decode(response):
    content = response.content or b""
    try:
        # Keep compatibility with an unwrapped/plain response in case the API
        # is changed server-side.
        return response.json()
    except Exception:
        pass
    token = str(response.headers.get("t") or int(time.time()))[:10]
    try:
        encrypted = base64.b64decode(content.strip())
        key = YACINE_KEY_PREFIX + token.encode("ascii")
        decoded = bytes(bytearray(
            value ^ key[index % len(key)] for index, value in enumerate(bytearray(encrypted))))
        return json.loads(decoded.decode("utf-8"))
    except Exception as error:
        raise RuntimeError("Yacine TV returned an invalid response: %s" % error)


def _yacine_get(path, user_agent):
    response = requests.get(urljoin(YACINE_API, str(path or "").lstrip("/")),
                            headers=_headers(user_agent), timeout=(8, 28), verify=False)
    response.raise_for_status()
    payload = _yacine_decode(response)
    if not isinstance(payload, dict):
        raise RuntimeError("Yacine TV returned invalid data")
    rows = payload.get("data")
    if not isinstance(rows, list):
        raise RuntimeError("Yacine TV returned an empty catalogue")
    return rows


def fetch_yacine_categories(user_agent, parent=None):
    category_id = str((parent or {}).get("id") or "").strip()
    rows = _yacine_get("categories/%s" % category_id if category_id else "categories",
                       user_agent)
    result = []
    for row in rows:
        if not isinstance(row, dict) or not row.get("id"):
            continue
        result.append({
            "id": str(row.get("id")),
            "name": str(row.get("name") or "Category").strip(),
            "image": str(row.get("logo") or "").strip(),
            "child_count": int(row.get("child_count") or 0),
            "source": "yacine_category",
        })
    if not result:
        raise RuntimeError("Yacine TV returned no categories")
    return result


def fetch_yacine_channels(category, user_agent):
    category_id = str((category or {}).get("id") or "").strip()
    if not category_id:
        raise RuntimeError("Yacine TV category identifier is missing")
    rows = _yacine_get("categories/%s/channels" % category_id, user_agent)
    result = []
    for row in rows:
        if not isinstance(row, dict) or not row.get("id") or int(row.get("is_hide") or 0):
            continue
        result.append({
            "id": str(row.get("id")),
            "name": str(row.get("name") or "Channel").strip(),
            "image": str(row.get("logo") or "").strip(),
            "priority": int(row.get("priority") or 0),
            "source": "yacine",
        })
    if not result:
        raise RuntimeError("Yacine TV returned no channels for this category")
    return result


def resolve_yacine_channel(item, user_agent):
    channel_id = str((item or {}).get("id") or "").strip()
    name = str((item or {}).get("name") or "Yacine TV").strip()
    if not channel_id:
        raise RuntimeError("Yacine TV channel identifier is missing")
    rows = _yacine_get("channel/%s" % channel_id, user_agent)
    streams = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        url = str(row.get("url") or "").strip().replace("\\u0026", "&")
        if not url.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
            continue
        # Enigma2 cannot open Widevine/ClearKey payloads itself. Do not offer a
        # misleading player choice when the API marks a source as DRM-only.
        if row.get("drm"):
            continue
        headers = dict(row.get("headers") or {}) if isinstance(row.get("headers"), dict) else {}
        agent = str(row.get("user_agent") or "").strip()
        referer = str(row.get("referer") or "").strip()
        if agent:
            headers.setdefault("User-Agent", agent)
        else:
            headers.setdefault("User-Agent", _headers(user_agent).get("User-Agent"))
        if referer:
            headers.setdefault("Referer", referer)
        stream_name = str(row.get("name") or "").strip()
        quality = None
        quality_match = re.search(r"(?:^|\D)(2160|1440|1080|720|576|480|360|244)(?:p|\D|$)",
                                  stream_name, re.I)
        if quality_match:
            quality = "%sp" % quality_match.group(1)
        stream = {"name": stream_name or name, "url": url, "headers": headers,
                  "quality": quality, "source": "yacine"}
        if all(old.get("url") != url for old in streams):
            streams.append(stream)
    if not streams:
        raise RuntimeError("Yacine TV has no non-DRM stream for this channel")
    return {"id": channel_id, "name": name, "url": streams[0]["url"],
            "urls": [stream["url"] for stream in streams], "streams": streams,
            "headers": streams[0].get("headers", {}),
            "image": str((item or {}).get("image") or ""), "source": "yacine"}


def _syria_live_event(row):
    """Convert a Syria Live API match into the common live-channel shape."""
    if not isinstance(row, dict):
        return None
    match_id = str(row.get("match_id") or "").strip()
    home = str(row.get("home_team") or "").strip()
    away = str(row.get("away_team") or "").strip()
    name = ("%s  vs  %s" % (home, away)).strip() if home and away else (home or away)
    links = row.get("stream_links") if isinstance(row.get("stream_links"), dict) else {}
    header_map = row.get("stream_headers") if isinstance(row.get("stream_headers"), dict) else {}
    streams = []
    for label, raw_url in links.items():
        url = str(raw_url or "").strip().replace("\\u0026", "&")
        if not url.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
            continue
        headers = header_map.get(label) if isinstance(header_map.get(label), dict) else {}
        streams.append({
            "name": str(label or "Live").strip(),
            "url": url,
            "headers": dict(headers),
            "source": "syrialive",
        })
    if not name or not streams:
        return None
    return {
        "id": match_id or name,
        "name": name,
        "url": streams[0]["url"],
        "urls": [stream["url"] for stream in streams],
        "streams": streams,
        "headers": streams[0].get("headers", {}),
        "image": str(row.get("home_logo") or row.get("away_logo") or "").strip(),
        "source": "syrialive",
    }


def fetch_syria_live_events(user_agent):
    """Fetch the currently advertised Syria Live match streams."""
    response = requests.get(urljoin(SYRIA_LIVE_API, "lives"),
                            headers=_headers(user_agent), timeout=(8, 28), verify=False)
    response.raise_for_status()
    try:
        payload = response.json()
    except Exception:
        # The provider occasionally omits the final list/object terminators
        # after a complete last event. Its Android client tolerates this; do
        # the same, but only for the known top-level lives response.
        raw = _decode_arabic(response.content or b"").rstrip()
        if '"lives"' not in raw or not raw.endswith("}"):
            raise RuntimeError("Syria Live returned malformed live data")
        try:
            payload = json.loads(raw + "]}")
        except Exception:
            raise RuntimeError("Syria Live returned malformed live data")
    rows = payload.get("lives") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        raise RuntimeError("Syria Live returned invalid live data")
    result = []
    for row in rows:
        event = _syria_live_event(row)
        if event:
            result.append(event)
    if not result:
        raise RuntimeError("Syria Live has no live events at this time")
    return result


def resolve_syria_live_event(item, user_agent):
    """Refresh the event before playback so expiring stream URLs stay current."""
    event_id = str((item or {}).get("id") or "").strip()
    try:
        current = fetch_syria_live_events(user_agent)
        for event in current:
            if str(event.get("id") or "").strip() == event_id:
                return event
    except Exception:
        # A just-loaded item can still be useful during a short API outage.
        pass
    fallback = dict(item or {})
    if fallback.get("url"):
        return fallback
    raise RuntimeError("The selected Syria Live event is no longer available")


def _egybest_get(path, user_agent, params=None):
    headers = _headers(user_agent)
    headers.update({"Accept": "application/json", "Device-Id": EGYBEST_CODE[:16]})
    response = requests.get(urljoin(EGYBEST_API, str(path or "").lstrip("/")),
                            params=params or {}, headers=headers,
                            timeout=(25, 35), verify=False)
    response.raise_for_status()
    try:
        payload = response.json()
    except Exception:
        raise RuntimeError("Egybest returned invalid JSON")
    if not isinstance(payload, (dict, list)):
        raise RuntimeError("Egybest returned invalid data")
    return payload


def _egybest_headers(video, user_agent):
    result = {}
    for part in str((video or {}).get("header") or "").split("|"):
        if ":" in part:
            key, value = part.split(":", 1)
            if key.strip() and value.strip():
                result[key.strip().title()] = value.strip()
    agent = str((video or {}).get("useragent") or "").strip()
    result.setdefault("User-Agent", agent if len(agent) > 12 else _headers(user_agent)["User-Agent"])
    return result


def _egybest_item(row, kind):
    if not isinstance(row, dict) or not row.get("id"):
        return None
    name = str(row.get("title") or row.get("name") or row.get("original_name") or row.get("id")).strip()
    if not name:
        return None
    return {"id": str(row.get("id")), "name": name,
            "image": str(row.get("poster_path") or row.get("still_path") or ""),
            "description": str(row.get("overview") or ""),
            "videos": list(row.get("videos") or []), "kind": kind,
            "source": "egybest"}


def fetch_egybest_live_groups(user_agent):
    payload = _egybest_get("categories/list/%s" % EGYBEST_CODE, user_agent)
    result = [
        {"id": "latest", "name": u"أحدث القنوات", "kind": "live", "source": "egybest_group"},
        {"id": "featured", "name": u"القنوات المميزة", "kind": "live", "source": "egybest_group"},
        {"id": "mostwatched", "name": u"الأكثر مشاهدة", "kind": "live", "source": "egybest_group"},
    ]
    for row in payload.get("categories") or []:
        if isinstance(row, dict) and row.get("id") and row.get("name"):
            result.append({"id": str(row["id"]), "name": str(row["name"]),
                           "kind": "live", "source": "egybest_group"})
    if not result:
        raise RuntimeError("Egybest returned no live categories")
    return result


def fetch_egybest_items(kind, user_agent, parent=None, page=1):
    kind = str(kind or "").lower()
    page = max(1, int(page or 1))
    if kind == "live":
        group_id = str((parent or {}).get("id") or "")
        if not group_id:
            raise RuntimeError("Egybest live category is missing")
        if group_id in ("latest", "featured", "mostwatched"):
            path = "livetv/%s/%s" % (group_id, EGYBEST_CODE)
            payload = _egybest_get(path, user_agent)
            entries = []
            for row in payload.get("livetv") or []:
                item = _egybest_item(row, kind)
                if item:
                    entries.append(item)
            return {"entries": entries, "page": 1, "last_page": 1,
                    "total": len(entries)}
        path = "categories/streaming/show/%s/%s" % (group_id, EGYBEST_CODE)
    elif kind in ("movie", "series"):
        path = "genres/%s/all/%s" % ("movies" if kind == "movie" else "series", EGYBEST_CODE)
    else:
        raise RuntimeError("Invalid Egybest section")
    # The backend fixes page size at 12. Load five adjacent API pages per UI
    # page so a normal list contains up to 60 entries instead of appearing
    # artificially limited to twelve.
    batch_size = 5
    first_api_page = ((page - 1) * batch_size) + 1
    payloads = [_egybest_get(path, user_agent, {"page": first_api_page})]
    api_last_page = int(payloads[0].get("last_page") or first_api_page)
    for api_page in range(first_api_page + 1,
                          min(api_last_page, first_api_page + batch_size - 1) + 1):
        try:
            payloads.append(_egybest_get(path, user_agent, {"page": api_page}))
        except Exception:
            break
    entries, seen = [], set()
    for payload in payloads:
        for row in payload.get("data") or []:
            item = _egybest_item(row, kind)
            if item and item["id"] not in seen:
                seen.add(item["id"])
                entries.append(item)
    ui_last_page = max(1, (api_last_page + batch_size - 1) // batch_size)
    return {"entries": entries, "page": page, "last_page": ui_last_page,
            "total": int(payloads[0].get("total") or len(entries))}


def fetch_egybest_seasons(show, user_agent):
    show_id = str((show or {}).get("id") or "")
    payload = _egybest_get("series/show/%s/%s" % (show_id, EGYBEST_CODE), user_agent)
    result = []
    for row in payload.get("seasons") or []:
        if not isinstance(row, dict) or not row.get("id"):
            continue
        result.append({"id": str(row["id"]),
                       "name": str(row.get("name") or "Season %s" % row.get("season_number", "")),
                       "show_name": str((show or {}).get("name") or ""),
                       "image": str((show or {}).get("image") or ""),
                       "kind": "season", "source": "egybest"})
    return result


def fetch_egybest_episodes(season, user_agent):
    season_id = str((season or {}).get("id") or "")
    payload = _egybest_get("series/season/%s/%s" % (season_id, EGYBEST_CODE), user_agent)
    result = []
    for row in payload.get("episodes") or []:
        item = _egybest_item(row, "episode")
        if item:
            item["show_name"] = str((season or {}).get("show_name") or "")
            result.append(item)
    return result


def _egybest_streams(row, user_agent, fallback_name):
    result = []
    for video in (row or {}).get("videos") or []:
        if not isinstance(video, dict) or int(video.get("status") or 1) == 0 or int(video.get("drm") or 0):
            continue
        url = str(video.get("link") or "").strip().replace("\\/", "/").replace("\\u0026", "&")
        if not url.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
            continue
        name = str(video.get("server") or fallback_name or "Server").strip()
        quality = re.search(r"(?:^|\D)(2160|1440|1080|720|576|480|360|244)(?:p|\D|$)", name + " " + url, re.I)
        result.append({"name": name, "url": url, "headers": _egybest_headers(video, user_agent),
                       "quality": "%sp" % quality.group(1) if quality else None,
                       "supported_host": bool(int(video.get("supported_hosts") or 0)),
                       "source": "egybest"})
    def priority(stream):
        url = str(stream.get("url") or "").lower()
        if any(ext in url for ext in (".m3u8", ".mp4", ".mpd", ".ts")):
            return 0
        if "vidspeed." in url:
            return 1
        if any(host in url for host in ("streamwish.", "uqload.", "earnvids.")):
            return 2
        return 3
    return sorted(result, key=priority)


def _unpack_egybest_script(text):
    """Unpack the common eval(function(p,a,c,k...)) video wrapper."""
    match = re.search(r"}\('(.*)',(\d+),(\d+),'(.*)'\.split", str(text or ""), re.S)
    if not match:
        return ""
    payload = match.group(1)
    base = int(match.group(2))
    count = int(match.group(3))
    words = match.group(4).split("|")
    alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

    def token_number(token):
        value = 0
        for char in token:
            index = alphabet.find(char)
            if index < 0 or index >= base:
                return None
            value = value * base + index
        return value

    def replace(found):
        index = token_number(found.group(0))
        if index is not None and index < count and index < len(words) and words[index]:
            return words[index]
        return found.group(0)
    return re.sub(r"\b[0-9A-Za-z]+\b", replace, payload)


def _resolve_egybest_page(stream):
    url = str(stream.get("url") or "")
    headers = dict(stream.get("headers") or {})
    headers.setdefault("Referer", url)
    probe_headers = dict(headers)
    probe_headers["Range"] = "bytes=0-1023"
    response = requests.get(url, headers=probe_headers, timeout=(20, 30),
                            verify=False, stream=True)
    if response.status_code == 416:
        # Some wrapper CDNs reject every byte-range request even though the
        # same URL returns its small HTML player normally.
        response.close()
        response = requests.get(url, headers=headers, timeout=(20, 30),
                                verify=False, stream=True)
    try:
        response.raise_for_status()
        content_type = str(response.headers.get("Content-Type") or "").lower()
        raw = response.raw.read(131072, decode_content=True)
    finally:
        response.close()
    if ("video/" in content_type or "audio/" in content_type or
            "mpegurl" in content_type or "application/octet-stream" in content_type):
        return stream
    if len(raw) >= 1024 and "html" in content_type:
        # Embed pages can place the packed player script after the first KB.
        response = requests.get(url, headers=headers, timeout=(20, 30),
                                verify=False, stream=True)
        try:
            response.raise_for_status()
            raw = response.raw.read(131072, decode_content=True)
        finally:
            response.close()
    try:
        text = raw.decode("utf-8", "ignore")
    except Exception:
        text = str(raw or "")
    text = text.replace("\\/", "/").replace("\\u0026", "&")
    unpacked = _unpack_egybest_script(text)
    if unpacked:
        text = unpacked + "\n" + text
    # CDN movie links often return a tiny HTML iframe whose src is the real,
    # short-lived media URL. Keep its complete query string intact.
    iframe_urls = [value.replace("&amp;", "&") for value in re.findall(
        r"<iframe[^>]+src\s*=\s*['\"](https?://[^'\"]+)['\"]", text, re.I)]
    urls = list(iframe_urls)
    urls.extend(_media_urls(text))
    if not urls:
        for pattern in (r"(?:file|src|source)\s*[:=]\s*['\"](https?://[^'\"]+)['\"]",
                        r"sources?\s*:\s*\[\s*['\"](https?://[^'\"]+)['\"]"):
            urls.extend(re.findall(pattern, text, re.I))
    if not urls:
        raise RuntimeError("host page did not expose a media URL")
    for candidate in urls:
        candidate = str(candidate or "").replace("&amp;", "&").strip()
        path = urlparse(candidate).path.lower()
        if path.endswith((".jpg", ".jpeg", ".png", ".gif", ".webp", ".css", ".js", ".vtt", ".srt")):
            continue
        result = dict(stream)
        result["url"] = candidate
        final_headers = dict(headers)
        # The movie wrapper declares referrerpolicy=no-referrer and Yandex
        # rejects the signed URL with "Invalid Referer" if we carry the outer
        # page's Referer into playback.
        if candidate in iframe_urls:
            for key in list(final_headers):
                if str(key).lower() in ("referer", "origin", "range"):
                    final_headers.pop(key, None)
        result["headers"] = final_headers
        return result
    raise RuntimeError("host page returned images but no playable media")


def resolve_egybest_item(item, user_agent):
    kind = str((item or {}).get("kind") or "").lower()
    item_id = str((item or {}).get("id") or "")
    name = str((item or {}).get("name") or "Egybest")
    row = dict(item or {})
    if kind == "movie":
        row = _egybest_get("media/detail/%s/%s" % (item_id, EGYBEST_CODE), user_agent)
    elif kind == "live":
        try:
            fresh = _egybest_get("stream/show/%s/%s" % (item_id, EGYBEST_CODE), user_agent)
            row = fresh.get("stream") if isinstance(fresh.get("stream"), dict) else fresh
        except Exception:
            pass
    streams = _egybest_streams(row, user_agent, name) or _egybest_streams(item, user_agent, name)
    resolved, last_error = [], None
    for stream in streams[:6]:
        url = stream["url"].lower()
        candidate = stream
        if stream.get("supported_host"):
            try:
                candidate = _resolve_egybest_page(stream)
            except Exception as error:
                last_error = error
                continue
        if all(candidate["url"] != old["url"] for old in resolved):
            resolved.append(candidate)
        if stream.get("supported_host") and resolved:
            break
        if len(resolved) >= 4:
            break
    if not resolved:
        raise RuntimeError("No compatible Egybest server was resolved: %s" % (last_error or "no active source"))
    return {"id": item_id, "name": name, "url": resolved[0]["url"],
            "urls": [x["url"] for x in resolved], "streams": resolved,
            "headers": resolved[0].get("headers", {}),
            "image": str((item or {}).get("image") or ""),
            "kind": kind, "source": "egybest"}


def _original_get(action, user_agent, params=None):
    query = {str(action): "", "api_key": ORIGINAL_KEY}
    query.update(params or {})
    headers = _headers(user_agent, ORIGINAL_HOME)
    headers.update({"Accept": "application/json", "Data-Agent": "The Stream"})
    response = requests.get(ORIGINAL_API, params=query, headers=headers,
                            timeout=(15, 40), verify=False)
    response.raise_for_status()
    try:
        payload = response.json()
    except Exception:
        raise RuntimeError("Original TV returned invalid JSON")
    if not isinstance(payload, dict) or str(payload.get("status") or "ok").lower() not in ("ok", "success", "1"):
        raise RuntimeError("Original TV returned invalid data")
    return payload


def _reezn_decode(value):
    """Decode the lightweight cardinal wrapper used by Reezn live data."""
    if not isinstance(value, string_types):
        return value
    value = str(value or "")
    if not value.startswith("cardinal@r"):
        return value
    try:
        raw = base64.b64decode(value[10:])
        return raw.decode("utf-8", "replace") if not isinstance(raw, str) else raw
    except Exception:
        return ""


def _reezn_signed_post(path, body="{}"):
    timestamp = str(int(time.time()))
    encoded_path = "/api/v3/" + str(path or "").lstrip("/")
    payload = ("POST" + encoded_path + timestamp + body).encode("utf-8")
    signature = hmac.new(REEZN_SIGN_KEY, payload, hashlib.sha256).hexdigest()
    headers = {
        "Content-Type": "application/json; charset=utf-8",
        "X-Reezn-Client": "SecureNativeV3",
        "X-Request-Time": timestamp,
        "X-Request-Signature": signature,
        "User-Agent": "Mozilla/5.0 (Android; Mobile) ReeznApp/1.0",
        "Cache-Control": "no-cache",
        "Connection": "close",
    }
    response = requests.post(REEZN_API + str(path).lstrip("/"), data=body,
                             headers=headers, timeout=(15, 45), verify=False)
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict) or not payload.get("success"):
        raise RuntimeError("Reezn returned invalid live data")
    return payload.get("data") or {}


def _reezn_live_channels(force=False):
    now = time.time()
    if (not force and _reezn_live_cache["channels"] and
            now - _reezn_live_cache["time"] < REEZN_CACHE_TTL):
        return _reezn_live_cache["channels"]
    rows = (_reezn_signed_post(REEZN_LIVE_PATH).get("channels") or [])
    channels = []
    for row in rows:
        if not isinstance(row, dict) or row.get("isHidden") or row.get("isAdult"):
            continue
        item = {}
        for key in ("id", "name", "category", "logo", "origin", "network",
                    "network_logo", "ua", "referer", "cookies", "cookie",
                    "clearKeyId", "clearKeyVal"):
            item[key] = _reezn_decode(row.get(key)) or ""
        item["kind"] = "live"
        item["source"] = "reezn"
        item["image"] = item.get("logo") or item.get("network_logo") or ""
        sources = []
        for source in row.get("sources") or []:
            if not isinstance(source, dict):
                continue
            url = str(_reezn_decode(source.get("url")) or "").strip()
            if not url.lower().startswith(("http://", "https://")):
                continue
            kid = str(_reezn_decode(source.get("clearKeyId") or source.get("clear_key_id") or source.get("kid")) or "").strip()
            key = str(_reezn_decode(source.get("clearKeyVal") or source.get("clear_key_val") or source.get("key")) or "").strip()
            if kid or key:
                continue
            ua = str(_reezn_decode(source.get("ua") or source.get("userAgent") or source.get("user_agent")) or item.get("ua") or "").strip()
            referer = str(_reezn_decode(source.get("referer") or source.get("referrer")) or item.get("referer") or "").strip()
            cookies = str(_reezn_decode(source.get("cookies") or source.get("cookie")) or item.get("cookies") or item.get("cookie") or "").strip()
            headers = {"User-Agent": ua or BROWSER_UA}
            if referer:
                headers["Referer"] = referer
            if cookies:
                headers["Cookie"] = cookies
            sources.append({"name": str(_reezn_decode(source.get("label")) or "Server %d" % (len(sources) + 1)),
                            "url": url, "headers": headers, "source": "reezn",
                            "relay": not urlparse(url).path.lower().endswith(".mpd"),
                            "relay_options": {"reezn": True, "live": True, "credential_origin": url}})
        if sources:
            item["streams"] = sources
            item["urls"] = [source["url"] for source in sources]
            item["url"] = sources[0]["url"]
            channels.append(item)
    _reezn_live_cache["time"] = now
    _reezn_live_cache["channels"] = channels
    return channels


def _reezn_localized(value):
    if isinstance(value, dict):
        return str(value.get("ar") or value.get("en") or next(iter(value.values()), ""))
    return str(value or "")


def _reezn_matches():
    body = json.dumps({"date": time.strftime("%d_%m_%Y")}, separators=(",", ":"))
    rows = _reezn_signed_post("app/sports/get_sports_db.php", body).get("matches") or []
    result = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        mapped = [_reezn_decode(value) for value in (row.get("channels") or [])]
        result.append({"id": str(row.get("id") or ""),
                       "name": _reezn_localized(row.get("title")),
                       "description": _reezn_localized(row.get("league")),
                       "image": str(row.get("background") or row.get("league_logo") or ""),
                       "match_date": str(row.get("start_time") or ""),
                       "mapped_channels": [x for x in mapped if x],
                       "kind": "matches", "source": "reezn"})
    return result


def _tmdb_get(path, params=None):
    query = {"api_key": TMDB_KEY, "language": "ar-SA"}
    query.update(params or {})
    response = requests.get(TMDB_API + str(path).lstrip("/"), params=query,
                            timeout=(10, 30), verify=False)
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict):
        raise RuntimeError("TMDB returned invalid data")
    return payload


def _tmdb_image(path):
    path = str(path or "").strip()
    return TMDB_IMAGE + path if path.startswith("/") else ""


def _tmdb_item(row, kind):
    item_id = str((row or {}).get("id") or "")
    if not item_id:
        return None
    if kind == "movie":
        name = str(row.get("title") or row.get("original_title") or item_id)
        date = str(row.get("release_date") or "")
    else:
        name = str(row.get("name") or row.get("original_name") or item_id)
        date = str(row.get("first_air_date") or "")
    return {"id": item_id, "tmdb_id": item_id, "name": name,
            "image": _tmdb_image(row.get("poster_path") or row.get("backdrop_path")),
            "description": str(row.get("overview") or ""), "date": date,
            "original_title": str(row.get("original_title") or row.get("original_name") or name),
            "kind": kind, "source": "reezn_vod"}


def _tmdb_items(kind, page):
    path = "movie/popular" if kind == "movie" else "tv/popular"
    payload = _tmdb_get(path, {"page": max(1, int(page or 1))})
    entries = [item for item in (_tmdb_item(row, kind) for row in payload.get("results") or []) if item]
    return {"entries": entries, "page": int(payload.get("page") or page or 1),
            "last_page": max(1, int(payload.get("total_pages") or 1)),
            "total": int(payload.get("total_results") or len(entries))}


def _original_drm_enabled(row):
    value = str((row or {}).get("drm_enabled") or "").strip().lower()
    return value in ("1", "true", "yes", "enabled", "on")


def _original_headers(row, user_agent):
    supplied = str((row or {}).get("user_agent") or "").strip()
    if not supplied or supplied.lower() == "default" or len(supplied) < 12:
        supplied = _headers(user_agent).get("User-Agent", BROWSER_UA)
    headers = {"User-Agent": supplied}
    referer = str((row or {}).get("http_referer") or "").strip()
    origin = str((row or {}).get("http_origin") or "").strip()
    if referer:
        headers["Referer"] = referer
    if origin:
        headers["Origin"] = origin
    return headers


def _original_unwrap_url(value):
    value = str(value or "").strip().replace("\\/", "/").replace("&amp;", "&")
    if not value:
        return ""
    try:
        parsed = urlparse(value)
        query = parse_qs(parsed.query)
        # A ck parameter carries a ClearKey pair. Enigma2 cannot safely play
        # that protected source, so do not expose the key or treat it as a
        # normal clear stream.
        if query.get("ck"):
            return ""
        inner = (query.get("url") or [""])[0]
        inner = unquote(str(inner or "")).strip()
        if inner.lower().startswith(("http://", "https://")):
            return inner
    except Exception:
        pass
    return value


def _original_streams(row, kind, user_agent):
    if _original_drm_enabled(row):
        return []
    if kind == "matches":
        keys = ("matches_url", "matches_url_backup", "matches_url_backup_1",
                "matches_url_backup_2", "matches_url_backup_3")
    elif kind == "live":
        keys = ("channel_url", "channel_url_backup_1", "channel_url_backup_2",
                "channel_url_backup_3")
    elif kind == "movie":
        keys = ("movie_url",)
    else:
        keys = ("episode_url",)
    candidates = []
    for index, key in enumerate(keys):
        value = _original_unwrap_url((row or {}).get(key))
        if value:
            candidates.append(("Primary" if index == 0 else "Backup %d" % index, value))
    for index, extra in enumerate((row or {}).get("additional_urls") or []):
        if isinstance(extra, dict):
            name = str(extra.get("name") or "Server %d" % (len(candidates) + 1))
            value = _original_unwrap_url(extra.get("url"))
        else:
            name, value = "Server %d" % (len(candidates) + 1), _original_unwrap_url(extra)
        if value:
            candidates.append((name, value))
    result, seen = [], set()
    headers = _original_headers(row, user_agent)
    for name, url in candidates:
        if url in seen:
            continue
        seen.add(url)
        result.append({"name": name, "url": url, "headers": dict(headers),
                       "source": "originaltv"})
    return result


def _original_item(row, kind):
    if not isinstance(row, dict):
        return None
    fields = {
        "live": ("channel_id", "channel_name", "channel_image", "channel_description"),
        "matches": ("matches_id", "matches_name", "matches_image", "matches_description"),
        "movie": ("movie_id", "movie_title", "movie_image", "movie_description"),
        "series": ("series_id", "series_title", "series_image", "series_description"),
        "episode": ("episode_id", "episode_title", "episode_image", "episode_description"),
    }
    id_key, name_key, image_key, description_key = fields[kind]
    item_id = row.get(id_key)
    if item_id is None or str(item_id).strip() == "":
        return None
    name = str(row.get(name_key) or item_id).strip()
    if kind == "matches":
        opponent = str(row.get("matches_name_2") or "").strip()
        if opponent:
            name = "%s vs %s" % (name, opponent)
        channel = str(row.get("matches_channel") or "").strip()
        date = str(row.get("match_date") or "").strip()
        suffix = " - ".join(value for value in (channel, date) if value)
        if suffix:
            name = "%s  [%s]" % (name, suffix)
    item = {"id": str(item_id), "name": name,
            "image": str(row.get(image_key) or ""),
            "description": str(row.get(description_key) or ""),
            "kind": kind, "source": "originaltv"}
    item.update(row)
    return item


def fetch_original_groups(user_agent):
    # Reezn presents live channels as networks.  Preserve the app order and
    # make each network a normal Enigma2 folder.
    channels = _reezn_live_channels()
    result, seen = [], set()
    for channel in channels:
        name = str(channel.get("network") or channel.get("category") or "Other").strip()
        if not name or name in seen:
            continue
        seen.add(name)
        result.append({"id": name, "name": name,
                       "image": str(channel.get("network_logo") or ""),
                       "kind": "live", "source": "reezn_group"})
    if result:
        return result
    payload = _original_get("get_category_index", user_agent)
    result = []
    for row in payload.get("categories") or []:
        if isinstance(row, dict) and row.get("cid") is not None:
            result.append({"id": str(row.get("cid")),
                           "name": str(row.get("category_name") or row.get("cid")),
                           "image": str(row.get("category_image") or ""),
                           "kind": "live", "source": "originaltv_group"})
    if not result:
        raise RuntimeError("Original TV returned no live categories")
    return result


def fetch_original_items(kind, user_agent, parent=None, page=1):
    kind = str(kind or "").lower()
    page = max(1, int(page or 1))
    if kind == "matches":
        entries = _reezn_matches()
        return {"entries": entries, "page": 1, "last_page": 1, "total": len(entries)}
    if kind in ("movie", "series"):
        from .reeznvod import items
        return items(kind, parent, page)
    if kind == "live":
        group = str((parent or {}).get("id") or (parent or {}).get("name") or "").strip()
        rows = [row for row in _reezn_live_channels()
                if str(row.get("network") or row.get("category") or "Other").strip() == group]
        start = (page - 1) * ORIGINAL_PAGE_SIZE
        entries = rows[start:start + ORIGINAL_PAGE_SIZE]
        last_page = max(1, (len(rows) + ORIGINAL_PAGE_SIZE - 1) // ORIGINAL_PAGE_SIZE)
        return {"entries": entries, "page": page, "last_page": last_page, "total": len(rows)}
    if kind == "live":
        category_id = str((parent or {}).get("id") or "")
        if not category_id:
            raise RuntimeError("Original TV live category is missing")
        payload = _original_get("get_category_posts", user_agent,
                                {"id": category_id, "page": page,
                                 "count": ORIGINAL_PAGE_SIZE})
        rows = payload.get("posts") or []
    elif kind == "matches":
        payload = _original_get("get_event", user_agent)
        rows = payload.get("matches") or []
    elif kind == "movie":
        payload = _original_get("get_movies", user_agent,
                                {"page": page, "count": ORIGINAL_PAGE_SIZE})
        rows = payload.get("movies") or []
    elif kind == "series":
        payload = _original_get("get_series", user_agent,
                                {"page": page, "count": ORIGINAL_PAGE_SIZE})
        rows = payload.get("series") or []
    else:
        raise RuntimeError("Invalid Original TV section")
    # Do not advertise protected rows as playable channels. Original TV's
    # Android client can use ClearKey/Widevine metadata, while Enigma2's
    # normal 5002/5001/4097 services cannot play those sources.
    if kind in ("live", "matches"):
        rows = [row for row in rows if not _original_drm_enabled(row)]
    entries = [item for item in (_original_item(row, kind) for row in rows) if item]
    if kind == "matches":
        entries.sort(key=lambda item: (str(item.get("match_date") or ""),
                                       str(item.get("matches_id") or item.get("id") or "")),
                     reverse=True)
    total = int(payload.get("count_total") or len(entries))
    if kind in ("live", "matches") and int(payload.get("pages") or 1) <= 1:
        total = len(entries)
    last_page = max(1, (total + ORIGINAL_PAGE_SIZE - 1) // ORIGINAL_PAGE_SIZE)
    return {"entries": entries, "page": page, "last_page": last_page, "total": total}


def _original_series_detail(series, user_agent):
    series_id = str((series or {}).get("series_id") or (series or {}).get("id") or "")
    if not series_id:
        raise RuntimeError("Original TV series identifier is missing")
    return _original_get("get_series_detail", user_agent, {"id": series_id})


def fetch_original_seasons(series, user_agent):
    if str((series or {}).get("source") or "") in ("tmdb", "reezn_vod"):
        series_id = str((series or {}).get("tmdb_id") or (series or {}).get("id") or "")
        payload = _tmdb_get("tv/%s" % series_id)
        result = []
        for row in payload.get("seasons") or []:
            number = int(row.get("season_number") or 0)
            # VixSrc does not consistently publish TMDB Season 0 / Specials.
            # R73-R75 exposed it at the bottom of the list, where selecting it
            # deterministically produced 404 for both TMDB and IMDb IDs.
            # Hide that non-playable synthetic season; normal seasons remain
            # untouched.
            if number <= 0:
                continue
            result.append({"id": "%s:%s" % (series_id, number),
                           "name": str(row.get("name") or "Season %d" % number),
                           "series_id": series_id, "series_name": str((series or {}).get("name") or ""),
                           "season": number, "image": _tmdb_image(row.get("poster_path")),
                           "description": str(row.get("overview") or ""),
                           "kind": "season", "source": "reezn_vod"})
        result.sort(key=lambda item: (int(item.get("season", 0)) == 0, int(item.get("season", 0))))
        return result
    payload = _original_series_detail(series, user_agent)
    groups = {}
    for row in payload.get("episodes") or []:
        if not isinstance(row, dict):
            continue
        try:
            number = max(1, int(row.get("season") or 1))
        except Exception:
            number = 1
        groups.setdefault(number, []).append(row)
    result = []
    for number in sorted(groups):
        result.append({"id": "%s:%s" % ((series or {}).get("id") or "", number),
                       "name": "Season %d" % number,
                       "series_id": str((series or {}).get("series_id") or (series or {}).get("id") or ""),
                       "series_name": str((series or {}).get("name") or ""),
                       "season": number, "episodes": groups[number],
                       "image": str((series or {}).get("image") or ""),
                       "kind": "season", "source": "originaltv"})
    return result


def fetch_original_episodes(season, user_agent):
    if str((season or {}).get("source") or "") in ("tmdb", "reezn_vod"):
        series_id = str((season or {}).get("series_id") or "")
        number = int((season or {}).get("season", 1))
        payload = _tmdb_get("tv/%s/season/%s" % (series_id, number))
        result = []
        for row in payload.get("episodes") or []:
            episode = int(row.get("episode_number") or 0)
            if episode < 1:
                continue
            result.append({"id": "%s:%s:%s" % (series_id, number, episode),
                           "name": str(row.get("name") or "Episode %d" % episode),
                           "image": _tmdb_image(row.get("still_path")),
                           "description": str(row.get("overview") or ""),
                           "series_id": series_id, "season": number, "episode": episode,
                           "series_name": str((season or {}).get("series_name") or ""),
                           "kind": "episode", "source": "reezn_vod"})
        return result
    rows = list((season or {}).get("episodes") or [])
    if not rows:
        payload = _original_series_detail(season, user_agent)
        wanted = int((season or {}).get("season") or 1)
        rows = [row for row in payload.get("episodes") or []
                if int(row.get("season") or 1) == wanted]
    result = []
    for row in rows:
        item = _original_item(row, "episode")
        if item:
            item["series_name"] = str((season or {}).get("series_name") or "")
            result.append(item)
    return result


def resolve_original_item(item, user_agent):
    kind = str((item or {}).get("kind") or "").lower()
    item_id = str((item or {}).get("id") or "")
    row = dict(item or {})
    if str(row.get("source") or "") in ("tmdb", "reezn_vod"):
        from .reeznvod import resolve
        return resolve(row)
    if kind == "matches" and str(row.get("source") or "") == "reezn":
        by_id = {str(channel.get("id") or ""): channel for channel in _reezn_live_channels()}
        streams, seen = [], set()
        for channel_id in row.get("mapped_channels") or []:
            channel = by_id.get(str(channel_id))
            if not channel:
                continue
            for source in channel.get("streams") or []:
                url = str(source.get("url") or "")
                if not url or url in seen:
                    continue
                seen.add(url)
                stream = dict(source)
                stream["name"] = "%s - %s" % (channel.get("name") or channel_id,
                                                source.get("name") or "Server")
                streams.append(stream)
        if not streams:
            raise RuntimeError("No mapped Reezn channels are available for this match")
        return {"id": item_id, "name": str(row.get("name") or "Match"),
                "url": streams[0]["url"], "urls": [x["url"] for x in streams],
                "streams": streams, "headers": streams[0].get("headers", {}),
                "image": str(row.get("image") or ""),
                "description": str(row.get("description") or ""),
                "kind": "matches", "source": "reezn"}
    if kind == "live" and str(row.get("source") or "") == "reezn":
        streams = list(row.get("streams") or [])
        if not streams:
            raise RuntimeError("Reezn returned no Enigma2-compatible server")
        return {"id": item_id, "name": str(row.get("name") or "Reezn Live"),
                "url": streams[0]["url"], "urls": [x["url"] for x in streams],
                "streams": streams, "headers": streams[0].get("headers", {}),
                "image": str(row.get("image") or ""), "description": "",
                "kind": "live", "source": "reezn"}
    try:
        if kind == "live":
            payload = _original_get("get_post_detail", user_agent, {"id": item_id})
            row = payload.get("post") if isinstance(payload.get("post"), dict) else row
        elif kind == "matches":
            payload = _original_get("get_event", user_agent)
            for fresh in payload.get("matches") or []:
                if str(fresh.get("matches_id") or "") == item_id:
                    row = fresh
                    break
        elif kind == "movie":
            payload = _original_get("get_movie_detail", user_agent, {"id": item_id})
            row = payload.get("post") if isinstance(payload.get("post"), dict) else row
        elif kind == "episode":
            payload = _original_get("get_episode_detail", user_agent,
                                    {"episode_id": item_id})
            for key in ("episode", "post"):
                if isinstance(payload.get(key), dict):
                    row = payload[key]
                    break
    except Exception:
        # The list response already carries playable URLs; keep it usable
        # during a temporary detail-endpoint failure.
        row = dict(item or {})
    if _original_drm_enabled(row):
        raise RuntimeError("This Original TV source is DRM protected and is not compatible with Enigma2")
    streams = _original_streams(row, kind, user_agent)
    if not streams:
        raise RuntimeError("Original TV returned no non-DRM stream for this item")
    name = str((item or {}).get("name") or row.get("channel_name") or
               row.get("movie_title") or row.get("episode_title") or "Original TV")
    image = str((item or {}).get("image") or row.get("channel_image") or
                row.get("movie_image") or row.get("episode_image") or row.get("matches_image") or "")
    return {"id": item_id, "name": name, "url": streams[0]["url"],
            "urls": [stream["url"] for stream in streams], "streams": streams,
            "headers": streams[0].get("headers", {}), "image": image,
            "description": str((item or {}).get("description") or ""),
            "kind": kind, "source": "originaltv"}


def _unique_urls(values):
    result = []
    for value in values:
        value = str(value or "").strip()
        if value and value not in result:
            result.append(value)
    return result


def _ostora_manifest_value(value):
    value = str(value or "").strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
        value = value[1:-1]
    try:
        value = unquote(value)
    except Exception:
        pass
    return value.strip()


def _ostora_hls_manifest_options(text, inherited=None):
    """Carry Url Video Player private HLS tags into the selected quality."""
    options = dict(inherited or {})
    custom = dict(options.get("headers") or {})
    for raw_line in str(text or "").splitlines():
        line = raw_line.strip()
        upper = line.upper()
        if upper.startswith("#EXT-X-MEDIA-UA:"):
            value = _ostora_manifest_value(line.split(":", 1)[1])
            if value:
                options["user_agent"] = value
        elif upper.startswith("#EXT-X-MEDIA-REF:"):
            value = _ostora_manifest_value(line.split(":", 1)[1])
            if value:
                options["referer"] = value
        elif upper.startswith("#EXT-X-MEDIA-HTTP:"):
            value = _ostora_manifest_value(line.split(":", 1)[1])
            if value:
                options["http"] = value
        elif upper.startswith("#EXT-X-MEDIA-HEADER:"):
            value = line.split(":", 1)[1].strip()
            if ":" in value:
                name, header_value = value.split(":", 1)
            elif "=" in value:
                name, header_value = value.split("=", 1)
            else:
                continue
            name = name.strip()
            header_value = _ostora_manifest_value(header_value)
            if name and header_value and "\r" not in name + header_value and "\n" not in name + header_value:
                custom[name] = header_value
        elif upper.startswith("#EXT-X-ENCRYPTION:"):
            match = re.search(r"(?:^|,)\s*PASSWORD\s*=\s*(\"[^\"]*\"|'[^']*'|[^,\s]+)",
                              line.split(":", 1)[1], re.I)
            if match:
                value = _ostora_manifest_value(match.group(1))
                if value:
                    options["password"] = value
    if custom:
        options["headers"] = custom
    return options


def _ostora_apply_hls_headers(headers, options):
    result = dict(headers or {})
    options = dict(options or {})
    if options.get("user_agent"):
        result["User-Agent"] = str(options.get("user_agent"))
    if options.get("referer"):
        result["Referer"] = str(options.get("referer"))
        try:
            parsed = urlparse(result["Referer"])
            if parsed.scheme and parsed.netloc:
                result.setdefault("Origin", "%s://%s" % (parsed.scheme, parsed.netloc))
        except Exception:
            pass
    for key, value in (options.get("headers") or {}).items():
        found = False
        for existing in result:
            if str(existing).lower() == str(key).lower():
                found = True
                break
        if not found:
            result[str(key)] = str(value)
    return result


def hls_variant_streams(stream):
    """Return quality variants for one Reezn server, or the server itself."""
    stream = dict(stream or {})
    # Reezn uses HLS under .json and PNG-wrapped media. Keep the relay
    # metadata on every quality, including redirected and JSON sources.
    relay_options = dict(stream.get("relay_options") or {})
    url = str(stream.get("url") or "").strip()
    headers = dict(stream.get("headers") or {})
    hls_options = dict(stream.get("ostora_hls") or {})
    if stream.get("source") == "ostora":
        headers = _ostora_apply_hls_headers(headers, hls_options)
    if not url:
        return []
    if stream.get("source") == "reezn" and urlparse(url).path.lower().endswith(".ts"):
        # TOD's standalone TS channels have no HLS quality list. Probing them
        # opens an unnecessary second live session on connection-limited hosts.
        return [stream]
    current = url
    response = None
    try:
        for _unused in range(4):
            response = requests.get(current, headers=headers, timeout=(4, 8),
                                    verify=False, allow_redirects=False, stream=True)
            if response.status_code not in (301, 302, 303, 307, 308):
                response.raise_for_status()
                break
            target = urljoin(current, response.headers.get("Location") or "")
            response.close()
            response = None
            if urlparse(target).netloc != urlparse(current).netloc:
                headers.pop("Cookie", None)
                headers.pop("Authorization", None)
            current = target
        raw = response.raw.read(262144, decode_content=True) if response is not None else b""
        if response is not None:
            response.close()
            response = None
        text = raw.decode("utf-8", "ignore") if isinstance(raw, bytes) else str(raw or "")
        if stream.get("source") == "reezn" and raw[:1] == b"\x47":
            # Direct live TS: keep the app endpoint, not its expiring redirect.
            # The relay must revisit that endpoint whenever a connection ends.
            return [stream]
        if stream.get("source") == "ostora":
            hls_options = _ostora_hls_manifest_options(text, hls_options)
            headers = _ostora_apply_hls_headers(headers, hls_options)
        if text.lstrip().startswith(("{", "[")):
            found = []
            def walk(value, label=""):
                if isinstance(value, dict):
                    for key, child in value.items():
                        walk(child, str(key))
                elif isinstance(value, list):
                    for child in value:
                        walk(child, label)
                elif isinstance(value, string_types):
                    candidate = str(value).replace("\\/", "/").strip()
                    if candidate.lower().startswith(("http://", "https://")) and ".m3u8" in candidate.lower():
                        found.append((label, candidate))
            try:
                walk(json.loads(text))
            except Exception:
                found = []
            if found:
                result, seen = [], set()
                for label, target in found:
                    if target in seen:
                        continue
                    seen.add(target)
                    quality = re.search(r"(2160|1440|1080|720|576|480|360|244)", label)
                    quality = "%sp" % quality.group(1) if quality else (label or "Auto")
                    variant = {"name": quality, "quality": quality, "url": target,
                               "headers": dict(headers), "source": stream.get("source"),
                               "relay": stream.get("relay", False)}
                    if relay_options:
                        variant["relay_options"] = dict(relay_options)
                    if hls_options:
                        variant["ostora_hls"] = dict(hls_options)
                    result.append(variant)
                return result
        if stream.get("source") == "ostora" and "#EXTM3U" not in text.upper():
            nested_urls = _ostora_extract_urls_from_text(text)
            if nested_urls:
                nested_result = []
                for index, target in enumerate(nested_urls):
                    variant = dict(stream)
                    variant["url"] = target
                    variant["headers"] = dict(headers)
                    variant["quality"] = variant.get("quality") or (u"مصدر %d" % (index + 1))
                    variant["name"] = variant["quality"]
                    if hls_options:
                        variant["ostora_hls"] = dict(hls_options)
                    nested_result.append(variant)
                return nested_result
        if "#EXT-X-STREAM-INF" not in text.upper():
            updated = dict(stream)
            updated["url"] = current
            updated["headers"] = dict(headers)
            if hls_options:
                updated["ostora_hls"] = dict(hls_options)
            return [updated]
        lines, result = text.splitlines(), []
        for index, line in enumerate(lines):
            if not line.strip().upper().startswith("#EXT-X-STREAM-INF"):
                continue
            target = ""
            for following in lines[index + 1:]:
                following = following.strip()
                if following and not following.startswith("#"):
                    target = urljoin(current, following)
                    break
            if not target:
                continue
            height = re.search(r"RESOLUTION=\d+x(\d+)", line, re.I)
            bandwidth = re.search(r"BANDWIDTH=(\d+)", line, re.I)
            quality = "%sp" % height.group(1) if height else (
                "%d kbps" % (int(bandwidth.group(1)) // 1000) if bandwidth else "Auto")
            variant = {"name": quality, "quality": quality, "url": target,
                       "headers": dict(headers), "source": stream.get("source"),
                       "relay": stream.get("relay", False)}
            if relay_options:
                variant["relay_options"] = dict(relay_options)
            if hls_options:
                variant["ostora_hls"] = dict(hls_options)
            result.append(variant)
        return result or [stream]
    except Exception:
        return [stream]
    finally:
        try:
            if response is not None:
                response.close()
        except Exception:
            pass


def _probe_hls(url, user_agent, referer):
    response = None
    try:
        response = requests.get(url, headers=_headers(user_agent, referer),
                                timeout=(5, 10), verify=False, stream=True)
        response.raise_for_status()
        prefix = b""
        try:
            prefix = next(response.iter_content(512))
        except StopIteration:
            pass
        if isinstance(prefix, str):
            prefix = prefix.encode("utf-8", "ignore")
        return b"#EXTM3U" in prefix.upper()
    except Exception:
        return False
    finally:
        try:
            if response is not None:
                response.close()
        except Exception:
            pass


def resolve_fajer_channel(item, user_agent):
    """Mirror the official player's per-channel capacity assignment."""
    try:
        number = int((item or {}).get("number") or 0)
    except Exception:
        number = 0
    if number not in range(1, 6):
        raise RuntimeError("Invalid Al Fajer channel number")

    session = requests.Session()
    referer = "https://tv.alfajertv.com/"
    response = session.get(FAJER_API + "?t=%d" % int(time.time() * 1000),
                           headers=_headers(user_agent, referer), timeout=(7, 20), verify=False)
    response.raise_for_status()
    payload = response.json()
    streams = payload.get("streams", {}) if isinstance(payload, dict) else {}

    assigned = ""
    if number in (1, 3, 4, 5):
        try:
            capacity = session.get(
                FAJER_ASSIGN + "?channel=fajer%d&_=%d" % (number, int(time.time() * 1000)),
                headers=_headers(user_agent, referer), timeout=(7, 20), verify=False)
            capacity.raise_for_status()
            assignment = capacity.json()
            if isinstance(assignment, dict) and assignment.get("ok") and not assignment.get("full"):
                assigned = str(assignment.get("url") or "").strip()
        except Exception:
            assigned = ""

    if number == 1:
        candidates = [streams.get("fajer1-hd2"), assigned,
                      streams.get("fajer1"), streams.get("fajer1-hd")]
    elif number == 3:
        candidates = [streams.get("fajer3-hd"), assigned, streams.get("fajer3")]
    else:
        candidates = [assigned, streams.get("fajer%d" % number)]
    candidates = _unique_urls(candidates)
    if not candidates:
        raise RuntimeError("Al Fajer did not return a stream URL")

    selected = candidates[0]
    for candidate in candidates:
        if _probe_hls(candidate, user_agent, referer):
            selected = candidate
            break
    ordered = [selected] + [value for value in candidates if value != selected]
    return {"name": "Al Fajer %d" % number, "url": selected,
            "urls": ordered, "number": number, "source": "alfajer",
            "headers": {"Referer": referer}}


def _media_urls(text):
    # Keep query signatures intact and ignore quotes/HTML delimiters.
    pattern = r'https?://[^\s"\'<>]+(?:\.m3u8|\.mpd|\.mp4|\.ts)(?:\?[^\s"\'<>]*)?'
    result = []
    for value in re.findall(pattern, str(text or ""), re.I):
        value = value.replace("&amp;", "&").replace("\\/", "/")
        value = value.rstrip("\\);,]}")
        if value and value not in result:
            result.append(value)
    return result



def _elahmad_media_urls(text, base_url):
    '''Extract absolute or relative media URLs from current Elahmad HTML/JS.'''
    body = str(text or "")
    body = body.replace("\\/", "/").replace("&amp;", "&")
    body = body.replace("\\u0026", "&").replace("\\x26", "&")
    result = []

    def add(value):
        value = str(value or "").strip().strip("\"' <>\\")
        value = value.replace("\\/", "/").replace("&amp;", "&")
        value = value.rstrip("\\);,]}")
        if not value or value.lower().startswith(("data:", "javascript:")):
            return
        if value.startswith("//"):
            value = (urlparse(base_url).scheme or "https") + ":" + value
        else:
            value = urljoin(base_url, value)
        if urlparse(value).scheme not in ("http", "https"):
            return
        if not re.search(r"\.(?:m3u8|mpd|mp4|ts)(?:[?#]|$)", value, re.I):
            return
        if value not in result:
            result.append(value)

    for value in _media_urls(body):
        add(value)

    media_re = re.compile(
        r"[\"'](?P<u>(?:(?:https?:)?//|/|\.\.?/)[^\"'<>\s]+\.(?:m3u8|mpd|mp4|ts)(?:\?[^\"'<>\s]*)?)[\"']",
        re.I)
    for match in media_re.finditer(body):
        add(match.group("u"))
    return result



def _elahmad_query_media_urls(value, base_url=""):
    """Extract media passed through radiant/stream_player query parameters."""
    result = []
    work = str(value or "").replace("&amp;", "&")
    try:
        parsed = urlparse(urljoin(base_url or value, work))
    except Exception:
        return result
    query = parse_qs(parsed.query, keep_blank_values=False)
    for key in ("url", "playlist", "src", "source", "stream", "file", "id"):
        for raw in query.get(key, []):
            candidate = str(raw or "")
            for _unused in range(3):
                try:
                    nxt = unquote(candidate)
                except Exception:
                    break
                if nxt == candidate:
                    break
                candidate = nxt
            if candidate.startswith("//"):
                candidate = (parsed.scheme or "https") + ":" + candidate
            if candidate.lower().startswith(("http://", "https://")) and re.search(
                    r'\.(?:m3u8|mpd|mp4|ts)(?:[?#]|$)', candidate, re.I):
                if candidate not in result:
                    result.append(candidate)
    return result


def _elahmad_encoded_media_urls(text, base_url):
    """Handle common JS wrappers used by the current Elahmad player pages."""
    body = str(text or "").replace("\\/", "/").replace("\\u0026", "&").replace("\\x26", "&")
    result = []

    def add(value):
        for media in _elahmad_media_urls(value, base_url):
            if media not in result:
                result.append(media)
        for media in _elahmad_query_media_urls(value, base_url):
            if media not in result:
                result.append(media)

    add(body)
    # URLs are often nested inside radiant.php?id= or stream_player.php?url=.
    for wrapped in re.findall(
            r'["\']([^"\']*(?:radiant\.php|stream_player\.php|video-player\.php)[^"\']*)["\']',
            body, re.I):
        add(wrapped)

    # Decode literal atob("...") payloads, but only retain actual media URLs.
    for encoded in re.findall(r'atob\s*\(\s*["\']([A-Za-z0-9+/=_-]{12,})["\']\s*\)', body, re.I):
        for token in (encoded, encoded.replace('-', '+').replace('_', '/')):
            try:
                token += '=' * ((4 - len(token) % 4) % 4)
                decoded = base64.b64decode(token.encode('ascii')).decode('utf-8', 'ignore')
            except Exception:
                continue
            add(decoded)
    return result


def _elahmad_alternate_pages(page_url):
    """Map the current JS-only mobile page to still-supported legacy views."""
    parsed = urlparse(str(page_url or ""))
    query = parse_qs(parsed.query)
    slug = str((query.get("id") or query.get("tv") or [""])[0]).strip()
    if not slug:
        return []
    base = "%s://%s" % (parsed.scheme or "https", parsed.netloc)
    paths = (
        "/tv/mobiletv/?tv=" + quote(slug, safe="_-"),
        "/tv/arabic-tv-online.php?id=" + quote(slug, safe="_-"),
    )
    return [base + value for value in paths]

def _elahmad_script_media(session, html, page_url, user_agent):
    '''Inspect same-site JS because Elahmad now places stream paths there.'''
    result = []
    seen_scripts = set()
    for src in re.findall(r"<script[^>]+src=[\"']([^\"']+)", str(html or ""), re.I):
        script_url = urljoin(page_url, src.replace("&amp;", "&"))
        parsed = urlparse(script_url)
        host = parsed.netloc.lower().split(":", 1)[0]
        if host not in ("www.elahmad.ru", "elahmad.ru", "www.elahmad.com", "elahmad.com",
                        "www.elahmad.site", "elahmad.site"):
            continue
        if script_url in seen_scripts:
            continue
        seen_scripts.add(script_url)
        if len(seen_scripts) > 8:
            break
        try:
            response = session.get(script_url, headers=_headers(user_agent, page_url),
                                   timeout=20, verify=False)
            response.raise_for_status()
            for media in _elahmad_media_urls(response.text, response.url or script_url):
                if media not in result:
                    result.append(media)
        except Exception:
            continue
    return result

def _decrypt_openssl(link_4, key, iv, key_is_hex=True):
    executable = None
    for path in ("/usr/bin/openssl", "/bin/openssl", "openssl"):
        if path == "openssl" or (os.path.isfile(path) and os.access(path, os.X_OK)):
            executable = path
            break
    if not executable:
        raise RuntimeError("OpenSSL is required to decode this provider link")
    encrypted = base64.b64decode(str(link_4))
    if not key_is_hex:
        try:
            key = str(key).encode("utf-8").hex()
            iv = str(iv).encode("utf-8").hex()
        except AttributeError:
            key = "".join("%02x" % ord(char) for char in str(key))
            iv = "".join("%02x" % ord(char) for char in str(iv))
    proc = subprocess.Popen([executable, "enc", "-d", "-aes-256-cbc", "-K", str(key), "-iv", str(iv)],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate(encrypted)
    if proc.returncode != 0:
        raise RuntimeError("Unable to decode provider link")
    try:
        return stdout.decode("utf-8").strip()
    except Exception:
        return str(stdout).strip()


def _openssl_path():
    for path in ("/usr/bin/openssl", "/bin/openssl", "openssl"):
        if path == "openssl" or (os.path.isfile(path) and os.access(path, os.X_OK)):
            return path
    raise RuntimeError("OpenSSL is required for Drama Live")


def _drama_cipher(data, decrypt=False):
    if isinstance(data, str):
        data = data.encode("utf-8")
    command = [
        _openssl_path(), "enc", "-aes-128-cbc", "-nosalt",
        "-K", binascii.hexlify(DRAMA_AES_KEY).decode("ascii"),
        "-iv", binascii.hexlify(DRAMA_AES_IV).decode("ascii"),
    ]
    if decrypt:
        command.insert(2, "-d")
    proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate(data)
    if proc.returncode != 0:
        raise RuntimeError("Unable to decode Drama Live response")
    return stdout


def _drama_encode(payload):
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    encrypted = _drama_cipher(raw, decrypt=False)
    return "%s:%s" % (
        base64.b64encode(encrypted).decode("ascii"),
        base64.b64encode(DRAMA_AES_IV).decode("ascii"),
    )


def _drama_decode(content):
    if not isinstance(content, str):
        content = content.decode("ascii", "ignore")
    parts = content.strip().split(":", 1)
    if len(parts) != 2:
        raise RuntimeError("Drama Live returned an invalid response")
    decrypted = _drama_cipher(base64.b64decode(parts[0]), decrypt=True)
    return json.loads(decrypted.decode("utf-8"))


def _drama_payload(extra=None):
    payload = {
        "user_id": "empty",
        "device_id": DRAMA_DEVICE_ID,
        "device_api": "35",
        "version_name": "187",
        "language": "ar",
        "timezone": "Etc/GMT",
        "device_type": "tv",
        "KEY_ACTIVATED_TYPE": "202122",
        "store": "direct",
        "isStoreVersion": False,
        "isPremium": False,
        "isCoupon_active": False,
        "hideAds": False,
        "appCount": '{"runCount":0,"adsLoaded":0,"adsShowed":0,"adsFailed":0}',
        "mainServer": DRAMA_API_BASES[1],
    }
    payload.update(extra or {})
    return payload


def _drama_request(action, extra, user_agent):
    return _drama_request_from(DRAMA_API_BASES, action, extra, user_agent)


def _drama_request_from(base_urls, action, extra, user_agent):
    body = _drama_encode(_drama_payload(extra))
    error = None
    for base_url in base_urls:
        try:
            response = requests.post(
                base_url + action,
                data=body,
                headers=dict(_headers(user_agent),
                             **{"Content-Type": "application/json; charset=utf-8"}),
                timeout=(7, 30), verify=False)
            response.raise_for_status()
            payload = _drama_decode(response.content)
            if isinstance(payload, dict):
                return payload
        except Exception as caught:
            error = caught
    raise RuntimeError("Drama Live server is unavailable: %s" % str(error or "unknown error"))


def _drama_redirect_request(action, extra, user_agent):
    return _drama_request_from(DRAMA_REDIRECT_BASES, action, extra, user_agent)


def _json_array(value):
    if isinstance(value, list):
        return value
    if isinstance(value, string_types):
        value = json.loads(value)
    return value if isinstance(value, list) else []


def fetch_drama_topics(user_agent):
    payload = _drama_request("getliveTopics", {"type": "tv"}, user_agent)
    if int(payload.get("result", -1)) != 0:
        raise RuntimeError("Drama Live did not return its channel groups")
    result = []
    seen = set()
    for topic in _json_array(payload.get("live_topics", [])):
        if not isinstance(topic, dict):
            continue
        topic_id = str(topic.get("id_topic") or "").strip()
        name = str(topic.get("name_topic") or topic_id).strip()
        if not topic_id or not name or topic_id in seen:
            continue
        seen.add(topic_id)
        result.append({"id": topic_id, "name": name,
                       "image": str(topic.get("img_url_topic") or ""),
                       "source": "dramalive_topic"})
    if not result:
        raise RuntimeError("Drama Live returned an empty group list")
    return result


def fetch_drama_channels(topic, user_agent):
    topic_id = str((topic or {}).get("id") or (topic or {}).get("id_topic") or "").strip()
    if not topic_id:
        raise RuntimeError("Drama Live group is missing")
    payload = _drama_request(
        "getLiveByTopic", {"type": "tv", "topic": topic_id}, user_agent)
    if int(payload.get("result", -1)) not in (0, 1):
        raise RuntimeError("Drama Live did not return channels for this group")
    result = []
    seen = set()
    for channel in _json_array(payload.get("live", [])):
        if not isinstance(channel, dict):
            continue
        channel_id = str(channel.get("id_live") or "").strip()
        name = str(channel.get("name") or channel_id).strip()
        if not channel_id or not name or channel_id in seen:
            continue
        seen.add(channel_id)
        result.append({"id": channel_id, "name": name,
                       "image": str(channel.get("img_url") or ""),
                       "source": "dramalive"})
    return result


def _show_rows(payload):
    if not isinstance(payload, dict) or int(payload.get("result", -1)) != 0:
        raise RuntimeError("Entertainment catalogue did not return data")
    rows = _json_array(payload.get("data", []))
    return [row for row in rows if isinstance(row, dict)]


def _fetch_paged_show_rows(action, extra, user_agent, id_key="id", max_pages=40,
                           base_urls=None):
    """Fetch every page of a Drama Live listing endpoint, not just the first.

    getShowsPage's name (and getShowEpisodes truncating long series) makes
    clear this backend paginates. We used to always request page 1 only,
    so any topic/show with more entries than one page holds was silently
    cut short. This keeps requesting page 2, 3, ... and merges everything,
    but stops as soon as a page adds no new rows - which also makes it
    safe to call against an endpoint that turns out not to paginate at
    all (it just costs one harmless extra request).
    """
    rows = []
    seen = set()
    page = 1
    while page <= max_pages:
        payload_extra = dict(extra)
        payload_extra["page"] = page
        try:
            page_rows = _show_rows(_drama_request_from(
                base_urls or DRAMA_SHOW_BASES, action, payload_extra, user_agent))
        except Exception:
            if page == 1:
                raise
            break
        added = False
        for row in page_rows:
            row_id = str(row.get(id_key) or "").strip()
            if not row_id or row_id in seen:
                continue
            seen.add(row_id)
            rows.append(row)
            added = True
        if not page_rows or not added:
            break
        page += 1
    return rows


def _fetch_all_show_rows(base_urls, action, extra, user_agent, paged=False):
    """Merge mirrors instead of trusting the first server's partial reply."""
    rows = []
    seen = set()
    last_error = None
    for base_url in base_urls:
        try:
            if paged:
                incoming = _fetch_paged_show_rows(
                    action, extra, user_agent, max_pages=80,
                    base_urls=(base_url,))
            else:
                incoming = _show_rows(_drama_request_from(
                    (base_url,), action, extra, user_agent))
        except Exception as error:
            last_error = error
            continue
        for row in incoming:
            row_id = str(row.get("id") or "").strip()
            marker = row_id or json.dumps(row, sort_keys=True, ensure_ascii=False)
            if marker in seen:
                continue
            seen.add(marker)
            rows.append(row)
    if not rows and last_error:
        raise last_error
    return rows


def fetch_drama_show_topics(kind, user_agent):
    """Return the app's own Series or Movie catalogue groups."""
    kind = str(kind or "").strip().lower()
    if kind not in ("series", "movie"):
        raise RuntimeError("Invalid entertainment section")
    rows = _fetch_all_show_rows(
        DRAMA_EPISODE_BASES, "getShowsTopics", {}, user_agent, paged=False)
    result = []
    seen = set()
    for row in rows:
        topic_id = str(row.get("id") or "").strip()
        name = str(row.get("name") or topic_id).strip()
        token = (topic_id + " " + name).lower()
        is_movie = ("_movies" in token or "movie" in token or
                    u"أفلام" in token or u"افلام" in token)
        is_series = ("_series" in token or "series" in token or
                     u"مسلسل" in token or u"رمضان" in token or
                     u"برامج" in token or u"مسرحيات" in token)
        wanted = is_series if kind == "series" else is_movie
        if not wanted or not topic_id or not name or topic_id in seen:
            continue
        seen.add(topic_id)
        result.append({"id": topic_id, "name": name,
                       "image": str(row.get("image") or ""),
                       "kind": kind, "source": "drama_show_topic"})
    if not result:
        raise RuntimeError("Entertainment section is currently empty")
    return result


def fetch_drama_shows(topic, user_agent):
    topic_id = str((topic or {}).get("id") or "").strip()
    if not topic_id:
        raise RuntimeError("Entertainment group is missing")
    rows = _fetch_all_show_rows(
        DRAMA_EPISODE_BASES, "getShowsPage", {"id": topic_id},
        user_agent, paged=True)
    result = []
    seen = set()
    for row in rows:
        show_id = str(row.get("id") or "").strip()
        name = str(row.get("name") or show_id).strip()
        if not show_id or not name or show_id in seen:
            continue
        seen.add(show_id)
        result.append({"id": show_id, "name": name,
                       "image": str(row.get("image") or ""),
                       "kind": str((topic or {}).get("kind") or "series"),
                       "source": "drama_show"})
    return result


def fetch_drama_episodes(show, user_agent):
    show_id = str((show or {}).get("id") or "").strip()
    if not show_id:
        raise RuntimeError("Entertainment title is missing")
    # The Android extractor uses the 1spbgmu mirror for episodes while the
    # catalogue uses eastgoessouth.  Merge both: either mirror can lag and
    # returning the first successful response was the reason for missing
    # episodes on long/current series.
    rows = _fetch_all_show_rows(
        DRAMA_EPISODE_BASES, "getShowEpisodes", {"id": show_id},
        user_agent, paged=True)
    result = []
    seen = set()
    for row in rows:
        episode_id = str(row.get("id") or "").strip()
        episode_name = str(row.get("name") or episode_id).strip()
        if not episode_id or not episode_name or episode_id in seen:
            continue
        seen.add(episode_id)
        result.append({"id": episode_id, "name": episode_name,
                       "show_name": str((show or {}).get("name") or ""),
                       "image": str((show or {}).get("image") or row.get("image") or ""),
                       "kind": str((show or {}).get("kind") or "series"),
                       "source": "drama_episode"})
    return result


def _drama_stream(value, agent, fallback_name):
    value = str(value or "").strip()
    agent = str(agent or "").strip()
    headers = {}
    swap = {}
    mediatype = ""
    advanced_url = False
    if value.startswith("{"):
        try:
            advanced = json.loads(value)
            advanced_url = True
            value = str(advanced.get("url") or "").strip()
            agent = str(advanced.get("agent") or agent).strip()
            if isinstance(advanced.get("headers"), dict):
                headers.update(advanced.get("headers"))
            raw_swap = advanced.get("swap")
            if isinstance(raw_swap, string_types):
                raw_swap = _json_object(raw_swap)
            if isinstance(raw_swap, dict):
                swap.update(raw_swap)
            mediatype = str(advanced.get("mediatype") or "").strip().lower()
            referer = str(advanced.get("referer") or "").strip()
            if referer:
                headers["Referer"] = referer
        except Exception:
            return None
    if not value.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
        return None
    if agent and agent.lower() not in (
            "advanced", "hls", "redirect", "double_redirect", "all_streams_redirect"):
        headers.setdefault("User-Agent", agent)
    return {"name": fallback_name, "url": value, "headers": headers,
            "agent": agent.lower(), "swap": swap, "mediatype": mediatype,
            "advanced": advanced_url}


def _json_object(value):
    if isinstance(value, dict):
        return value
    if not isinstance(value, string_types):
        try:
            value = value.decode("utf-8")
        except Exception:
            return None
    try:
        parsed = json.loads(value)
    except Exception:
        return None
    return parsed if isinstance(parsed, dict) else None


def _drama_response_model(payload, key="data"):
    if not isinstance(payload, dict) or int(payload.get("result", -1)) != 0:
        raise RuntimeError("Drama Live redirect resolver did not return a stream")
    model = _json_object(payload.get(key))
    if not model:
        raise RuntimeError("Drama Live redirect resolver returned invalid data")
    return model


def _drama_model_stream(model, fallback_name):
    agent = str((model or {}).get("agent") or "").strip().lower()
    value = (model or {}).get("url")
    if agent in ("redirect", "double_redirect", "all_streams_redirect"):
        return {"name": fallback_name, "url": value, "headers": {}, "agent": agent}
    return _drama_stream(value, agent, fallback_name)


def _advanced_request_data(value, user_agent, base_headers=None):
    """Execute the intermediate HTTP request used by Drama Live's Android client.

    ``base_headers`` are whatever headers (typically a Referer) the API had
    already attached to the *outer* stream before this "double_redirect"
    hop. Sites like the daddylive-style mirrors used for match feeds
    (e.g. hamis.romponalis.st) 403 a bare request with no Referer, so those
    headers must survive into this request - they used to be discarded
    here, which is what broke every match channel while ordinary streams
    (that never take this branch, or already had their headers baked into
    the JSON blob) kept working.
    """
    raw_value = value
    advanced = _json_object(value)
    if not advanced:
        text = str(value or "")
        marker = "myWebDoubleRedirect_"
        if text.startswith(marker):
            advanced = {"url": text[len(marker):], "headers": {}}
        elif text.lower().startswith(("http://", "https://")):
            advanced = {"url": text, "headers": {}}
        else:
            raise RuntimeError("Drama Live returned an invalid redirect instruction")

    url = str(advanced.get("url") or "").strip()
    if not url.lower().startswith(("http://", "https://")):
        raise RuntimeError("Drama Live redirect instruction has no HTTP URL")
    headers = dict(base_headers) if isinstance(base_headers, dict) else {}
    supplied = advanced.get("headers")
    if isinstance(supplied, string_types):
        supplied = _json_object(supplied)
    if isinstance(supplied, dict):
        headers.update(supplied)
    if not any(str(key).lower() == "user-agent" for key in headers):
        headers["User-Agent"] = _headers(user_agent).get("User-Agent")
    if not any(str(key).lower() == "referer" for key in headers):
        # Fallback for hosts (daddylive-style match mirrors, e.g.
        # hamis.romponalis.st) that 403 a request with no Referer at all
        # but don't actually validate it against a specific embed page -
        # a same-origin Referer is enough to pass that check when the API
        # didn't hand us one explicitly.
        parsed = urlparse(url)
        if parsed.scheme and parsed.netloc:
            headers["Referer"] = "%s://%s/" % (parsed.scheme, parsed.netloc)
    data = advanced.get("data")
    if data:
        response = requests.post(url, data=data, headers=headers,
                                 timeout=(7, 30), verify=False)
    else:
        response = requests.get(url, headers=headers, timeout=(7, 30), verify=False)
    response.raise_for_status()
    text = response.text
    start = advanced.get("returnFrom")
    end = advanced.get("returnTo")
    if start and end:
        begin = text.find(str(start))
        finish = text.find(str(end), begin + len(str(start))) if begin >= 0 else -1
        if finish >= 0:
            text = text[begin + len(str(start)):finish]
    if not text:
        raise RuntimeError("Drama Live redirect page returned no data")
    if isinstance(raw_value, dict):
        raw_value = json.dumps(raw_value, ensure_ascii=False, separators=(",", ":"))
    return str(raw_value), text


def _resolve_drama_redirect(stream, channel_id, user_agent, fallback_name, depth=0):
    """Resolve the redirect chain used by match feeds into a normal media URL."""
    if depth > 4:
        raise RuntimeError("Drama Live redirect chain is too long")
    agent = str(stream.get("agent") or "").strip().lower()
    url = stream.get("url")

    if agent == "all_streams_redirect":
        payload = _drama_request(
            "getLiveAllStreamsById", {"id": channel_id}, user_agent)
        if not isinstance(payload, dict) or int(payload.get("result", -1)) not in (0, 1):
            raise RuntimeError("Drama Live all-streams resolver returned no stream")
        model = payload.get("live")
        if isinstance(model, string_types):
            model = _json_object(model)
        if not isinstance(model, dict):
            raise RuntimeError("Drama Live all-streams resolver returned invalid data")
        candidate = _drama_stream(
            model.get("url"), model.get("agent"), fallback_name)
        if not candidate:
            raise RuntimeError("Drama Live all-streams resolver returned no URL")
        if (candidate.get("agent") == agent and
                candidate.get("url") == url):
            raise RuntimeError("Drama Live all-streams resolver did not advance")
        return _resolve_drama_redirect(
            candidate, channel_id, user_agent, fallback_name, depth + 1)

    if agent == "redirect":
        payload = _drama_redirect_request(
            "getLiveByRedirect",
            {"id": channel_id, "url": url, "agent": agent}, user_agent)
        model = _drama_response_model(payload)
        candidate = _drama_model_stream(model, fallback_name)
        if not candidate:
            raise RuntimeError("Drama Live redirect resolver returned no URL")
        return _resolve_drama_redirect(
            candidate, channel_id, user_agent, fallback_name, depth + 1)

    if agent == "double_redirect":
        request_value, raw_data = _advanced_request_data(
            url, user_agent, base_headers=stream.get("headers"))
        payload = _drama_redirect_request(
            "getLiveByDoubleRedirect",
            {"id": channel_id, "url": request_value,
             "agent": agent, "raw_data": raw_data}, user_agent)
        model = _drama_response_model(payload)
        candidate = _drama_model_stream(model, fallback_name)
        if not candidate:
            raise RuntimeError("Drama Live double redirect returned no URL")
        return _resolve_drama_redirect(
            candidate, channel_id, user_agent, fallback_name, depth + 1)

    if agent == "advanced":
        if not str(url or "").lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
            raise RuntimeError("Drama Live returned an invalid advanced stream")
        return stream

    hostname = urlparse(str(url or "")).hostname or ""
    if hostname.startswith("."):
        raise RuntimeError("Drama Live returned an unresolved internal stream identifier")
    return stream


_FFPROBE_PATH_CACHE = {}


def _ffprobe_path():
    """Locate ffprobe once and remember the result (None if absent)."""
    if "path" not in _FFPROBE_PATH_CACHE:
        found = shutil.which("ffprobe")
        if not found:
            for candidate in ("/usr/bin/ffprobe", "/usr/local/bin/ffprobe"):
                if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                    found = candidate
                    break
        _FFPROBE_PATH_CACHE["path"] = found
    return _FFPROBE_PATH_CACHE["path"]


def _hls_variant_heights(text):
    heights = []
    for line in text.splitlines():
        if line.upper().startswith("#EXT-X-STREAM-INF"):
            match = re.search(r'RESOLUTION=\d+x(\d+)', line, re.I)
            if match:
                heights.append(int(match.group(1)))
    return heights


def stream_quality_label(url, headers=None):
    """Best-effort playback quality label ("1080p", ...) for a resolved
    stream, so a "Server #2 / #3" chooser can show what each option
    actually is instead of a meaningless index. Never raises - any probe
    failure just means no label, not a broken chooser."""
    url = str(url or "").strip()
    if not url:
        return None
    headers = headers if isinstance(headers, dict) else {}
    url_quality = re.search(r"(?:^|[^0-9])(2160|1440|1080|720|576|480|360|244)(?:p|[^0-9]|$)",
                            url, re.I)
    try:
        if ".m3u8" in url.lower():
            response = requests.get(url, headers=headers, timeout=(3, 5),
                                    verify=False, stream=True)
            try:
                response.raise_for_status()
                raw = response.raw.read(65536, decode_content=True)
            finally:
                response.close()
            if isinstance(raw, bytes):
                text = raw.decode("utf-8", "ignore")
            else:
                text = str(raw or "")
            heights = _hls_variant_heights(text)
            if heights:
                return "%dp" % max(heights)
            # A media playlist represents one fixed rendition and therefore
            # has no EXT-X-STREAM-INF line. Fall through to ffprobe so its
            # actual dimensions can still be displayed beside the player.
        ffprobe = _ffprobe_path()
        if not ffprobe:
            return "%sp" % url_quality.group(1) if url_quality else None
        command = [ffprobe, "-v", "quiet", "-print_format", "json", "-show_streams"]
        if headers:
            header_text = "".join("%s: %s\r\n" % (key, value) for key, value in headers.items())
            command += ["-headers", header_text]
        command.append(url)
        proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            stdout, _stderr = proc.communicate(timeout=6)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
            return None
        info = json.loads(stdout.decode("utf-8", "ignore") or "{}")
        for stream_info in info.get("streams") or []:
            if stream_info.get("codec_type") == "video" and stream_info.get("height"):
                return "%dp" % int(stream_info["height"])
        return "%sp" % url_quality.group(1) if url_quality else None
    except Exception:
        return "%sp" % url_quality.group(1) if url_quality else None


def _probe_drama_stream(stream):
    response = None
    try:
        response = requests.get(stream.get("url"), headers=stream.get("headers") or {},
                                timeout=(3, 7), verify=False, stream=True)
        response.raise_for_status()
        prefix = next(response.iter_content(256), b"")
        if isinstance(prefix, str):
            prefix = prefix.encode("utf-8", "ignore")
        url = str(stream.get("url") or "").lower()
        return bool(prefix) and (".m3u8" not in url or b"#EXTM3U" in prefix.upper())
    except Exception:
        return False
    finally:
        try:
            if response is not None:
                response.close()
        except Exception:
            pass


def resolve_drama_channel(item, user_agent):
    channel_id = str((item or {}).get("id") or "").strip()
    name = str((item or {}).get("name") or "Drama Live").strip()
    if not channel_id:
        raise RuntimeError("Drama Live channel identifier is missing")
    payload = _drama_request(
        "getLiveAllStreamsById", {"id": channel_id}, user_agent)
    if int(payload.get("result", -1)) not in (0, 1):
        raise RuntimeError("Drama Live has no active stream for this channel")
    live = payload.get("live", {})
    if isinstance(live, str):
        live = json.loads(live)
    if not isinstance(live, dict):
        raise RuntimeError("Drama Live returned invalid stream data")

    streams = []
    primary = _drama_stream(live.get("url"), live.get("agent"), name)
    if primary:
        streams.append(primary)
    for backup in str(live.get("backup") or "").split(" -;- "):
        parts = backup.split(" -- ", 1)
        if len(parts) != 2:
            continue
        candidate = _drama_stream(parts[0], parts[1], name)
        if candidate and all(candidate["url"] != old["url"] for old in streams):
            streams.append(candidate)
    if not streams:
        raise RuntimeError("Drama Live returned no stream candidates")
    resolved_streams = []
    last_error = None
    for candidate in streams:
        try:
            resolved = _resolve_drama_redirect(
                candidate, channel_id, user_agent, name)
            if resolved and all(resolved["url"] != old["url"] for old in resolved_streams):
                resolved_streams.append(resolved)
        except Exception as error:
            last_error = error
    streams = resolved_streams
    if not streams:
        raise RuntimeError("Unable to resolve this Drama Live stream: %s" %
                           str(last_error or "unknown redirect error"))
    selected = None
    for candidate in streams[:4]:
        if _probe_drama_stream(candidate):
            selected = candidate
            break
    if selected is not None and selected is not streams[0]:
        streams = [selected] + [candidate for candidate in streams if candidate is not selected]
    return {"name": name, "url": streams[0]["url"], "urls": [x["url"] for x in streams],
            "streams": streams, "headers": streams[0].get("headers", {}),
            "source": "dramalive"}


def _show_model_candidates(model, fallback_name):
    result = []
    values = [(model.get("id"), model.get("agent"))]
    backup_value = str(model.get("backup") or "").strip()
    if backup_value:
        # Shows encode backup targets as:
        # target -- double_redirect -;- target -- double_redirect -;-
        # Splitting first on "-;-" lost every server whose target itself was
        # a JSON instruction.  Keep each target intact and attach its agent.
        for part in re.split(r"\s*-;-\s*", backup_value):
            part = part.strip()
            if not part:
                continue
            match = re.match(r"^(.*)\s+--\s+([a-z_]+)\s*$", part, re.I | re.S)
            if match:
                values.append((match.group(1).strip(), match.group(2).strip()))
            else:
                values.append((part, "double_redirect"))
    for value, agent in values:
        agent_name = str(agent or "").strip().lower()
        embedded = _json_object(value)
        if embedded and not agent_name:
            agent_name = str(embedded.get("agent") or "").strip().lower()
        if not agent_name and value:
            raw_value = str(value).strip().lower()
            if not (raw_value.startswith(("http://", "https://")) and
                    re.search(r"\.(?:m3u8|mpd|mp4)(?:[?#]|$)", raw_value)):
                agent_name = "double_redirect"
        if agent_name in ("redirect", "double_redirect", "all_streams_redirect"):
            candidate = {"name": fallback_name, "url": value,
                         "headers": {}, "agent": agent_name}
        else:
            candidate = _drama_stream(value, agent, fallback_name)
        if candidate and all(candidate.get("url") != old.get("url") for old in result):
            result.append(candidate)
    return result


def _resolve_show_candidate(candidate, media_id, user_agent, fallback_name, depth=0):
    if depth > 4:
        raise RuntimeError("Entertainment redirect chain is too long")
    agent = str(candidate.get("agent") or "").strip().lower()
    if agent == "double_redirect":
        target = candidate.get("url")
        # Android first submits the untouched target token to the redirect
        # service.  Only replies "1"/"2" require downloading the intermediate
        # page.  The previous implementation skipped this step and called a
        # non-app endpoint, so most movies and series never resolved.
        last_error = None
        try:
            payload = _drama_redirect_request(
                "getLiveByDoubleRedirect", {"id": target}, user_agent)
            model = _drama_response_model(payload)
            redirect_value = str(model.get("url") or "").strip()
            if redirect_value not in ("1", "2"):
                nested = _drama_model_stream(model, fallback_name)
                if nested:
                    return _resolve_show_candidate(
                        nested, media_id, user_agent, fallback_name, depth + 1)
        except Exception as error:
            last_error = error

        request_value, raw_data = _advanced_request_data(
            target, user_agent, base_headers=candidate.get("headers"))
        # Some hosts expose the final media URL directly in the page.
        normalised = str(raw_data or "").replace("\\/", "/").replace("\\u0026", "&")
        direct_urls = _unique_urls(_media_urls(normalised))
        if direct_urls:
            instruction = _json_object(request_value) or {}
            supplied = instruction.get("headers")
            if isinstance(supplied, string_types):
                supplied = _json_object(supplied)
            headers = dict(supplied or {}) if isinstance(supplied, dict) else {}
            player_agent = str(instruction.get("agent") or "").strip()
            if player_agent:
                headers.setdefault("User-Agent", player_agent)
            headers.setdefault("User-Agent", _headers(user_agent).get("User-Agent"))
            source_url = str(instruction.get("url") or "").strip()
            if source_url.lower().startswith(("http://", "https://")):
                headers.setdefault("Referer", source_url)
                parsed_source = urlparse(source_url)
                if parsed_source.scheme and parsed_source.netloc:
                    headers.setdefault("Origin", "%s://%s" % (
                        parsed_source.scheme, parsed_source.netloc))
            primary = {"name": fallback_name, "url": direct_urls[0],
                    "headers": headers, "agent": "hls"}
            primary["alternatives"] = [
                {"name": fallback_name, "url": value,
                 "headers": dict(headers), "agent": "hls"}
                for value in direct_urls[1:]]
            return primary

        try:
            payload = _drama_redirect_request(
                "getLiveByDoubleRedirect",
                {"id": target, "url": target, "agent": "double_redirect",
                 "raw_data": raw_data}, user_agent)
            model = _drama_response_model(payload)
            nested = _drama_model_stream(model, fallback_name)
            if nested:
                return _resolve_show_candidate(
                    nested, media_id, user_agent, fallback_name, depth + 1)
        except Exception as error:
            last_error = error
        raise RuntimeError(str(last_error or "Entertainment redirect failed"))
    if agent == "redirect":
        payload = _drama_redirect_request(
            "getLiveByRedirect",
            {"id": media_id, "url": candidate.get("url"), "agent": agent}, user_agent)
        model = _drama_response_model(payload)
        nested = _drama_model_stream(model, fallback_name)
        if not nested:
            raise RuntimeError("Entertainment redirect returned no URL")
        return _resolve_show_candidate(
            nested, media_id, user_agent, fallback_name, depth + 1)
    if agent == "all_streams_redirect":
        raise RuntimeError("Unsupported entertainment redirect type")
    return candidate


def resolve_drama_episode(item, user_agent):
    media_id = str((item or {}).get("id") or "").strip()
    episode_name = str((item or {}).get("name") or "Video").strip()
    show_name = str((item or {}).get("show_name") or "").strip()
    name = (show_name + " - " + episode_name).strip(" -")
    if not media_id:
        raise RuntimeError("Entertainment episode identifier is missing")
    rows = _fetch_all_show_rows(
        DRAMA_EPISODE_BASES, "analyzeSearchObject", {"id": media_id},
        user_agent, paged=False)
    streams = []
    last_error = None
    for row in rows:
        for candidate in _show_model_candidates(row, name):
            try:
                resolved = _resolve_show_candidate(
                    candidate, media_id, user_agent, name)
                resolved_items = [resolved] + list((resolved or {}).get("alternatives") or [])
                for resolved_item in resolved_items:
                    if resolved_item and all(resolved_item.get("url") != old.get("url")
                                             for old in streams):
                        resolved_item = dict(resolved_item)
                        resolved_item.pop("alternatives", None)
                        streams.append(resolved_item)
            except Exception as error:
                last_error = error
    if not streams:
        raise RuntimeError("Unable to resolve this entertainment video: %s" %
                           str(last_error or "no playable source"))
    for index, stream in enumerate(streams):
        stream["name"] = u"سيرفر %d" % (index + 1)
    # Do not probe every server here. Four sequential probes could freeze the
    # catalogue for almost half a minute; the chooser/player already performs
    # safe fallback and reports an offline server without blocking the GUI.
    return {"id": media_id, "name": name, "url": streams[0]["url"],
            "urls": [stream["url"] for stream in streams], "streams": streams,
            "headers": streams[0].get("headers", {}),
            "image": str((item or {}).get("image") or ""),
            "kind": str((item or {}).get("kind") or "series"),
            "source": "drama_episode"}


def _resolved(name, url, referer, user_agent=""):
    headers = _headers(user_agent, referer)
    stream = {
        "name": u"السيرفر 1",
        "server": u"السيرفر 1",
        "url": url,
        "headers": dict(headers),
        "source": "elahmad",
        "relay": False,
    }
    if ".m3u8" in str(url or "").lower():
        stream["mediatype"] = "hls"
    return {
        "name": name or "Channel",
        "url": url,
        "urls": [url],
        "streams": [stream],
        "source": "elahmad",
        "headers": dict(headers),
    }


def _legacy_post(session, page_url, html, name, user_agent):
    data_match = re.search(r'var\s+da_ta\s*=\s*\{(.*?)\}', html, re.I | re.S)
    crypt_match = re.search(
        r'my_crypt\(a\.link_1\s*,\s*["\']([^"\']+)["\']\s*,\s*["\']([^"\']+)',
        html, re.I | re.S)
    if not data_match or not crypt_match:
        return None
    data = dict(re.findall(
        r'["\']([^"\']+)["\']\s*:\s*["\']([^"\']*)["\']',
        data_match.group(1)))
    if not data:
        return None
    parsed = urlparse(page_url)
    post_url = "%s://%s%s" % (parsed.scheme, parsed.netloc, parsed.path)
    response = session.post(post_url, headers=_headers(user_agent, page_url), data=data,
                            timeout=35, verify=False)
    response.raise_for_status()
    payload = response.json()
    encrypted = payload.get("link_1", "") if isinstance(payload, dict) else ""
    if not encrypted:
        return None
    url = _decrypt_openssl(
        encrypted, crypt_match.group(1), crypt_match.group(2), key_is_hex=False)
    if url.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
        return _resolved(name, url, page_url, user_agent)
    return None


def _internal_pages(html, page_url):
    candidates = []
    patterns = (
        r'<iframe[^>]+src=["\']([^"\']+)',
        r'iframe\s*\(\s*["\']([^"\']+)',
        r'(?:window\.)?location(?:\.href)?\s*=\s*["\']([^"\']+)',
        r'window\.open\s*\(\s*["\']([^"\']+)',
        r'["\']([^"\']+(?:channel|glarb|radiant|mobiletv|stream_player|embed|player)[^"\']*)["\']',
    )
    allowed_hosts = ("www.elahmad.ru", "elahmad.ru", "www.elahmad.com", "elahmad.com",
                     "www.elahmad.site", "elahmad.site")
    for pattern in patterns:
        for value in re.findall(pattern, str(html or ""), re.I):
            url = urljoin(page_url, value.replace("&amp;", "&"))
            parsed = urlparse(url)
            if parsed.scheme not in ("http", "https"):
                continue
            host = parsed.netloc.lower().split(":", 1)[0]
            # Follow all Elahmad pages.  For external hosts, only follow URLs
            # that clearly look like a player/embed page (not ad/navigation links).
            if host not in allowed_hosts and not re.search(
                    r'(?:embed|player|stream|live|hls|m3u8)', parsed.path + "?" + parsed.query, re.I):
                continue
            if url not in candidates:
                candidates.append(url)
    candidates.sort(key=lambda value: 0 if ("radiant.php" in value or "stream_player.php" in value) else 1)
    return candidates[:14]

def _resolve_elahmad_page(session, page_url, name, user_agent, visited, depth=0):
    if depth > 5 or page_url in visited:
        return None
    visited.add(page_url)

    # radiant.php?id=<m3u8> and stream_player.php?url=<m3u8> need no HTML scrape.
    query_media = _elahmad_query_media_urls(page_url, page_url)
    if query_media:
        return _resolved(name, query_media[0], page_url, user_agent)

    response = session.get(page_url, headers=_headers(user_agent, ELAHMAD_HOME),
                           timeout=35, verify=False)
    response.raise_for_status()
    page_url = response.url or page_url
    html = response.text

    direct = _elahmad_encoded_media_urls(html, page_url)
    if direct:
        return _resolved(name, direct[0], page_url, user_agent)

    scripts = _elahmad_script_media(session, html, page_url, user_agent)
    if scripts:
        return _resolved(name, scripts[0], page_url, user_agent)

    csrf = re.search(r'name=["\']csrf-token["\']\s+content=["\']([^"\']+)', html, re.I)
    endpoint = re.search(r'embed_result\s*=\s*["\']([^"\']+)', html, re.I)
    if not endpoint:
        packed = re.search(r'for\s*\(var\s+d\s*=\s*\[([0-9,\s]+)\]\s*,\s*k\s*=\s*(\d+)', html, re.I)
        if packed:
            try:
                encoded = "".join(chr(int(value) ^ int(packed.group(2)))
                                  for value in packed.group(1).split(","))
                decoded_script = base64.b64decode(encoded).decode("utf-8", "ignore")
                endpoint = re.search(r'embed_result\s*=\s*["\']([^"\']+)', decoded_script, re.I)
            except Exception:
                endpoint = None
    query_id = parse_qs(urlparse(page_url).query).get("id", [""])[0]
    if csrf and endpoint and query_id:
        try:
            result = session.post(
                urljoin(page_url, endpoint.group(1)),
                headers=dict(_headers(user_agent, page_url),
                             **{"Content-Type": "application/x-www-form-urlencoded"}),
                data={"id": query_id, "csrf_token": csrf.group(1)},
                timeout=35, verify=False)
            result.raise_for_status()
            payload = result.json()
            url = _decrypt_openssl(
                payload.get("link_4", ""), payload.get("key", ""), payload.get("iv", ""))
            if url.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
                return _resolved(name, url, page_url, user_agent)
        except Exception:
            pass

    try:
        legacy = _legacy_post(session, page_url, html, name, user_agent)
    except Exception:
        legacy = None
    if legacy:
        return legacy

    for nested_url in _internal_pages(html, page_url):
        # A nested radiant/player URL may already carry the final media URL.
        nested_media = _elahmad_query_media_urls(nested_url, page_url)
        if nested_media:
            return _resolved(name, nested_media[0], page_url, user_agent)
        try:
            resolved = _resolve_elahmad_page(
                session, nested_url, name, user_agent, visited, depth + 1)
            if resolved:
                return resolved
        except Exception:
            continue

    # The current glarb page is a JS shell.  Elahmad still exposes legacy
    # server-rendered views for the same channel id; use them as a fallback.
    if depth <= 2:
        for alternate in _elahmad_alternate_pages(page_url):
            if alternate in visited:
                continue
            try:
                resolved = _resolve_elahmad_page(
                    session, alternate, name, user_agent, visited, depth + 1)
                if resolved:
                    return resolved
            except Exception:
                continue
    return None

def resolve_elahmad_channel(item, user_agent):
    page_url = str((item or {}).get("page") or "").strip()
    if not page_url:
        raise RuntimeError("Channel page is missing")
    name = str((item or {}).get("name") or "Channel")
    result = _resolve_elahmad_page(
        requests.Session(), page_url, name, user_agent, set(), 0)
    if result:
        return result
    try:
        with open("/tmp/xklass_elahmad_resolve.log", "a") as log:
            log.write("FAIL %s page=%s\n" % (name, page_url))
    except Exception:
        pass
    raise RuntimeError("The provider has no compatible live stream for this channel")
