#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Dynamic public-channel catalogues used by the Free Arabic TV screen."""

from __future__ import print_function

import base64
import binascii
import json
import os
import re
import subprocess
import time
import uuid

try:
    from urllib.parse import parse_qs, urljoin, urlparse
except ImportError:
    from urlparse import parse_qs, urljoin, urlparse

import requests

try:
    string_types = (basestring,)
except NameError:
    string_types = (str,)

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote


def service_stream_url(url, headers):
    """ServiceApp reads HTTP options from the URL fragment, not a pipe."""
    normalised = {}
    for raw_key, raw_value in (headers or {}).items():
        key = str(raw_key or '').strip().lower()
        if key:
            normalised[key] = raw_value
    parts = []
    for key in ('User-Agent', 'Referer', 'Origin', 'Cookie'):
        value = str(normalised.get(key.lower()) or '').strip()
        if value:
            if '\r' in value or '\n' in value:
                raise ValueError('Invalid stream header')
            parts.append('%s=%s' % (key, quote(value, safe='')))
    return url + ('#' + '&'.join(parts) if parts else '')


ELAHMAD_HOME = "https://www.elahmad.ru/tv/live-arabic-channels.php"
ELAHMAD_SOURCE = "https://www.elahmad.ru/tv/js/source.php"
FAJER_API = "https://tv.alfajertv.com/api/get-stream.php"
FAJER_ASSIGN = "https://tv.alfajertv.com/api/assign.php"
DRAMA_API_BASES = (
    "http://live.eastgoessouth.online/api/live/livedrama/v13.0.0/",
    "http://main.eastgoessouth.online/api/live/livedrama/v13.0.0/",
    "http://main.backendcoreapi.com/api/live/livedrama/v13.0.0/",
    "http://main.swiftapi.org/api/live/livedrama/v13.0.0/",
)
DRAMA_REDIRECT_BASES = (
    "http://redirect.eastgoessouth.online/redirect/",
)
DRAMA_SHOW_BASES = (
    "http://shows.eastgoessouth.online/search/v3/",
)
DRAMA_AES_KEY = b"0123456789abcdef"
DRAMA_AES_IV = b"fedcba9876543210"
DRAMA_DEVICE_ID = uuid.uuid4().hex[:16]
BROWSER_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)


def _headers(user_agent, referer=""):
    user_agent = str(user_agent or "").strip()
    if "Mozilla/" not in user_agent:
        user_agent = BROWSER_UA
    result = {"User-Agent": user_agent, "Accept": "*/*"}
    if referer:
        result["Referer"] = referer
    return result


def _decode_arabic(raw):
    if isinstance(raw, str):
        return raw
    for encoding in ("utf-8", "cp1256", "iso-8859-6"):
        try:
            return raw.decode(encoding)
        except Exception:
            pass
    return raw.decode("utf-8", "replace")


def parse_elahmad_catalogue(text):
    channels = {}
    pages = {}
    for raw_line in str(text or "").replace("\r", "").split("\n"):
        line = raw_line.strip()
        if not line or line.startswith("//"):
            continue
        match = re.match(r'chan\[(\d+)\]\s*=\s*["\'](.*?)["\']\s*;', line)
        if match:
            channels[int(match.group(1))] = match.group(2).strip()
            continue
        match = re.match(r'surl\[(\d+)\]\s*=\s*["\'](.*?)["\']\s*;', line)
        if match:
            pages[int(match.group(1))] = match.group(2).strip()
    result = []
    for index in sorted(set(channels).intersection(pages)):
        name = channels[index].strip()
        page = pages[index].strip()
        if not name or name.lower() == "file" or not page or page.lower() == "file":
            continue
        if page.lower().endswith(".swf"):
            continue
        result.append({"name": name, "page": urljoin(ELAHMAD_HOME, page), "source": "elahmad"})
    return result


def fetch_elahmad_catalogue(user_agent):
    response = requests.get(ELAHMAD_SOURCE, headers=_headers(user_agent, ELAHMAD_HOME),
                            timeout=(7, 20), verify=False)
    response.raise_for_status()
    channels = parse_elahmad_catalogue(_decode_arabic(response.content))
    if not channels:
        raise RuntimeError("Elahmad returned an empty or blocked catalogue")
    return channels


def fetch_fajer_channels(user_agent):
    response = requests.get(FAJER_API + "?t=%d" % int(time.time() * 1000),
                            headers=_headers(user_agent, "https://tv.alfajertv.com/"),
                            timeout=(7, 20), verify=False)
    response.raise_for_status()
    payload = response.json()
    streams = payload.get("streams", {}) if isinstance(payload, dict) else {}
    result = []
    for number in range(1, 6):
        key = "fajer%d" % number
        url = str(streams.get(key) or "").strip()
        result.append({"name": "Al Fajer %d" % number, "url": url,
                       "number": number, "source": "alfajer",
                       "headers": {"Referer": "https://tv.alfajertv.com/"}})
    return result


def _unique_urls(values):
    result = []
    for value in values:
        value = str(value or "").strip()
        if value and value not in result:
            result.append(value)
    return result


def _probe_hls(url, user_agent, referer):
    response = None
    try:
        response = requests.get(url, headers=_headers(user_agent, referer),
                                timeout=(5, 10), verify=False, stream=True)
        response.raise_for_status()
        prefix = b""
        try:
            prefix = next(response.iter_content(512))
        except StopIteration:
            pass
        if isinstance(prefix, str):
            prefix = prefix.encode("utf-8", "ignore")
        return b"#EXTM3U" in prefix.upper()
    except Exception:
        return False
    finally:
        try:
            if response is not None:
                response.close()
        except Exception:
            pass


def resolve_fajer_channel(item, user_agent):
    """Mirror the official player's per-channel capacity assignment."""
    try:
        number = int((item or {}).get("number") or 0)
    except Exception:
        number = 0
    if number not in range(1, 6):
        raise RuntimeError("Invalid Al Fajer channel number")

    session = requests.Session()
    referer = "https://tv.alfajertv.com/"
    response = session.get(FAJER_API + "?t=%d" % int(time.time() * 1000),
                           headers=_headers(user_agent, referer), timeout=(7, 20), verify=False)
    response.raise_for_status()
    payload = response.json()
    streams = payload.get("streams", {}) if isinstance(payload, dict) else {}

    assigned = ""
    if number in (1, 3, 4, 5):
        try:
            capacity = session.get(
                FAJER_ASSIGN + "?channel=fajer%d&_=%d" % (number, int(time.time() * 1000)),
                headers=_headers(user_agent, referer), timeout=(7, 20), verify=False)
            capacity.raise_for_status()
            assignment = capacity.json()
            if isinstance(assignment, dict) and assignment.get("ok") and not assignment.get("full"):
                assigned = str(assignment.get("url") or "").strip()
        except Exception:
            assigned = ""

    if number == 1:
        candidates = [streams.get("fajer1-hd2"), assigned,
                      streams.get("fajer1"), streams.get("fajer1-hd")]
    elif number == 3:
        candidates = [streams.get("fajer3-hd"), assigned, streams.get("fajer3")]
    else:
        candidates = [assigned, streams.get("fajer%d" % number)]
    candidates = _unique_urls(candidates)
    if not candidates:
        raise RuntimeError("Al Fajer did not return a stream URL")

    selected = candidates[0]
    for candidate in candidates:
        if _probe_hls(candidate, user_agent, referer):
            selected = candidate
            break
    ordered = [selected] + [value for value in candidates if value != selected]
    return {"name": "Al Fajer %d" % number, "url": selected,
            "urls": ordered, "number": number, "source": "alfajer",
            "headers": {"Referer": referer}}


def _media_urls(text):
    # Keep query signatures intact and ignore quotes/HTML delimiters.
    pattern = r'https?://[^\s"\'<>]+(?:\.m3u8|\.mpd|\.mp4|\.ts)(?:\?[^\s"\'<>]*)?'
    result = []
    for value in re.findall(pattern, str(text or ""), re.I):
        value = value.replace("&amp;", "&").replace("\\/", "/")
        value = value.rstrip("\\);,]}")
        if value and value not in result:
            result.append(value)
    return result


def _decrypt_openssl(link_4, key, iv, key_is_hex=True):
    executable = None
    for path in ("/usr/bin/openssl", "/bin/openssl", "openssl"):
        if path == "openssl" or (os.path.isfile(path) and os.access(path, os.X_OK)):
            executable = path
            break
    if not executable:
        raise RuntimeError("OpenSSL is required to decode this provider link")
    encrypted = base64.b64decode(str(link_4))
    if not key_is_hex:
        try:
            key = str(key).encode("utf-8").hex()
            iv = str(iv).encode("utf-8").hex()
        except AttributeError:
            key = "".join("%02x" % ord(char) for char in str(key))
            iv = "".join("%02x" % ord(char) for char in str(iv))
    proc = subprocess.Popen([executable, "enc", "-d", "-aes-256-cbc", "-K", str(key), "-iv", str(iv)],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate(encrypted)
    if proc.returncode != 0:
        raise RuntimeError("Unable to decode provider link")
    try:
        return stdout.decode("utf-8").strip()
    except Exception:
        return str(stdout).strip()


def _openssl_path():
    for path in ("/usr/bin/openssl", "/bin/openssl", "openssl"):
        if path == "openssl" or (os.path.isfile(path) and os.access(path, os.X_OK)):
            return path
    raise RuntimeError("OpenSSL is required for Drama Live")


def _drama_cipher(data, decrypt=False):
    if isinstance(data, str):
        data = data.encode("utf-8")
    command = [
        _openssl_path(), "enc", "-aes-128-cbc", "-nosalt",
        "-K", binascii.hexlify(DRAMA_AES_KEY).decode("ascii"),
        "-iv", binascii.hexlify(DRAMA_AES_IV).decode("ascii"),
    ]
    if decrypt:
        command.insert(2, "-d")
    proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate(data)
    if proc.returncode != 0:
        raise RuntimeError("Unable to decode Drama Live response")
    return stdout


def _drama_encode(payload):
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    encrypted = _drama_cipher(raw, decrypt=False)
    return "%s:%s" % (
        base64.b64encode(encrypted).decode("ascii"),
        base64.b64encode(DRAMA_AES_IV).decode("ascii"),
    )


def _drama_decode(content):
    if not isinstance(content, str):
        content = content.decode("ascii", "ignore")
    parts = content.strip().split(":", 1)
    if len(parts) != 2:
        raise RuntimeError("Drama Live returned an invalid response")
    decrypted = _drama_cipher(base64.b64decode(parts[0]), decrypt=True)
    return json.loads(decrypted.decode("utf-8"))


def _drama_payload(extra=None):
    payload = {
        "user_id": "empty",
        "device_id": DRAMA_DEVICE_ID,
        "device_api": "35",
        "version_name": "187",
        "language": "ar",
        "timezone": "Etc/GMT",
        "device_type": "tv",
        "KEY_ACTIVATED_TYPE": "202122",
        "store": "direct",
        "isStoreVersion": False,
        "isPremium": False,
        "isCoupon_active": False,
        "hideAds": False,
        "appCount": '{"runCount":0,"adsLoaded":0,"adsShowed":0,"adsFailed":0}',
        "mainServer": DRAMA_API_BASES[1],
    }
    payload.update(extra or {})
    return payload


def _drama_request(action, extra, user_agent):
    return _drama_request_from(DRAMA_API_BASES, action, extra, user_agent)


def _drama_request_from(base_urls, action, extra, user_agent):
    body = _drama_encode(_drama_payload(extra))
    error = None
    for base_url in base_urls:
        try:
            response = requests.post(
                base_url + action,
                data=body,
                headers=dict(_headers(user_agent),
                             **{"Content-Type": "application/json; charset=utf-8"}),
                timeout=(7, 30), verify=False)
            response.raise_for_status()
            payload = _drama_decode(response.content)
            if isinstance(payload, dict):
                return payload
        except Exception as caught:
            error = caught
    raise RuntimeError("Drama Live server is unavailable: %s" % str(error or "unknown error"))


def _drama_redirect_request(action, extra, user_agent):
    return _drama_request_from(DRAMA_REDIRECT_BASES, action, extra, user_agent)


def _json_array(value):
    if isinstance(value, list):
        return value
    if isinstance(value, string_types):
        value = json.loads(value)
    return value if isinstance(value, list) else []


def fetch_drama_topics(user_agent):
    payload = _drama_request("getliveTopics", {"type": "tv"}, user_agent)
    if int(payload.get("result", -1)) != 0:
        raise RuntimeError("Drama Live did not return its channel groups")
    result = []
    seen = set()
    for topic in _json_array(payload.get("live_topics", [])):
        if not isinstance(topic, dict):
            continue
        topic_id = str(topic.get("id_topic") or "").strip()
        name = str(topic.get("name_topic") or topic_id).strip()
        if not topic_id or not name or topic_id in seen:
            continue
        seen.add(topic_id)
        result.append({"id": topic_id, "name": name,
                       "image": str(topic.get("img_url_topic") or ""),
                       "source": "dramalive_topic"})
    if not result:
        raise RuntimeError("Drama Live returned an empty group list")
    return result


def fetch_drama_channels(topic, user_agent):
    topic_id = str((topic or {}).get("id") or (topic or {}).get("id_topic") or "").strip()
    if not topic_id:
        raise RuntimeError("Drama Live group is missing")
    payload = _drama_request(
        "getLiveByTopic", {"type": "tv", "topic": topic_id}, user_agent)
    if int(payload.get("result", -1)) not in (0, 1):
        raise RuntimeError("Drama Live did not return channels for this group")
    result = []
    seen = set()
    for channel in _json_array(payload.get("live", [])):
        if not isinstance(channel, dict):
            continue
        channel_id = str(channel.get("id_live") or "").strip()
        name = str(channel.get("name") or channel_id).strip()
        if not channel_id or not name or channel_id in seen:
            continue
        seen.add(channel_id)
        result.append({"id": channel_id, "name": name,
                       "image": str(channel.get("img_url") or ""),
                       "source": "dramalive"})
    return result


def _show_rows(payload):
    if not isinstance(payload, dict) or int(payload.get("result", -1)) != 0:
        raise RuntimeError("Entertainment catalogue did not return data")
    rows = _json_array(payload.get("data", []))
    return [row for row in rows if isinstance(row, dict)]


def fetch_drama_show_topics(kind, user_agent):
    """Return the app's own Series or Movie catalogue groups."""
    kind = str(kind or "").strip().lower()
    if kind not in ("series", "movie"):
        raise RuntimeError("Invalid entertainment section")
    rows = _show_rows(_drama_request_from(
        DRAMA_SHOW_BASES, "getShowsTopics", {}, user_agent))
    result = []
    seen = set()
    for row in rows:
        topic_id = str(row.get("id") or "").strip()
        name = str(row.get("name") or topic_id).strip()
        token = (topic_id + " " + name).lower()
        is_movie = ("_movies" in token or "movie" in token or
                    u"أفلام" in token or u"افلام" in token)
        is_series = ("_series" in token or "series" in token or
                     u"مسلسل" in token or u"رمضان" in token or
                     u"برامج" in token or u"مسرحيات" in token)
        wanted = is_series if kind == "series" else is_movie
        if not wanted or not topic_id or not name or topic_id in seen:
            continue
        seen.add(topic_id)
        result.append({"id": topic_id, "name": name,
                       "image": str(row.get("image") or ""),
                       "kind": kind, "source": "drama_show_topic"})
    if not result:
        raise RuntimeError("Entertainment section is currently empty")
    return result


def fetch_drama_shows(topic, user_agent):
    topic_id = str((topic or {}).get("id") or "").strip()
    if not topic_id:
        raise RuntimeError("Entertainment group is missing")
    rows = _show_rows(_drama_request_from(
        DRAMA_SHOW_BASES, "getShowsPage", {"id": topic_id, "page": 1}, user_agent))
    result = []
    seen = set()
    for row in rows:
        show_id = str(row.get("id") or "").strip()
        name = str(row.get("name") or show_id).strip()
        if not show_id or not name or show_id in seen:
            continue
        seen.add(show_id)
        result.append({"id": show_id, "name": name,
                       "image": str(row.get("image") or ""),
                       "kind": str((topic or {}).get("kind") or "series"),
                       "source": "drama_show"})
    return result


def fetch_drama_episodes(show, user_agent):
    show_id = str((show or {}).get("id") or "").strip()
    if not show_id:
        raise RuntimeError("Entertainment title is missing")
    rows = _show_rows(_drama_request_from(
        DRAMA_SHOW_BASES, "getShowEpisodes", {"id": show_id}, user_agent))
    result = []
    seen = set()
    for row in rows:
        episode_id = str(row.get("id") or "").strip()
        episode_name = str(row.get("name") or episode_id).strip()
        if not episode_id or not episode_name or episode_id in seen:
            continue
        seen.add(episode_id)
        result.append({"id": episode_id, "name": episode_name,
                       "show_name": str((show or {}).get("name") or ""),
                       "image": str((show or {}).get("image") or row.get("image") or ""),
                       "kind": str((show or {}).get("kind") or "series"),
                       "source": "drama_episode"})
    return result


def _drama_stream(value, agent, fallback_name):
    value = str(value or "").strip()
    agent = str(agent or "").strip()
    headers = {}
    swap = {}
    mediatype = ""
    advanced_url = False
    if value.startswith("{"):
        try:
            advanced = json.loads(value)
            advanced_url = True
            value = str(advanced.get("url") or "").strip()
            agent = str(advanced.get("agent") or agent).strip()
            if isinstance(advanced.get("headers"), dict):
                headers.update(advanced.get("headers"))
            raw_swap = advanced.get("swap")
            if isinstance(raw_swap, string_types):
                raw_swap = _json_object(raw_swap)
            if isinstance(raw_swap, dict):
                swap.update(raw_swap)
            mediatype = str(advanced.get("mediatype") or "").strip().lower()
            referer = str(advanced.get("referer") or "").strip()
            if referer:
                headers["Referer"] = referer
        except Exception:
            return None
    if not value.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
        return None
    if agent and agent.lower() not in (
            "advanced", "hls", "redirect", "double_redirect", "all_streams_redirect"):
        headers.setdefault("User-Agent", agent)
    return {"name": fallback_name, "url": value, "headers": headers,
            "agent": agent.lower(), "swap": swap, "mediatype": mediatype,
            "advanced": advanced_url}


def _json_object(value):
    if isinstance(value, dict):
        return value
    if not isinstance(value, string_types):
        try:
            value = value.decode("utf-8")
        except Exception:
            return None
    try:
        parsed = json.loads(value)
    except Exception:
        return None
    return parsed if isinstance(parsed, dict) else None


def _drama_response_model(payload, key="data"):
    if not isinstance(payload, dict) or int(payload.get("result", -1)) != 0:
        raise RuntimeError("Drama Live redirect resolver did not return a stream")
    model = _json_object(payload.get(key))
    if not model:
        raise RuntimeError("Drama Live redirect resolver returned invalid data")
    return model


def _drama_model_stream(model, fallback_name):
    agent = str((model or {}).get("agent") or "").strip().lower()
    value = (model or {}).get("url")
    if agent in ("redirect", "double_redirect", "all_streams_redirect"):
        return {"name": fallback_name, "url": value, "headers": {}, "agent": agent}
    return _drama_stream(value, agent, fallback_name)


def _advanced_request_data(value, user_agent, base_headers=None):
    """Execute the intermediate HTTP request used by Drama Live's Android client.

    ``base_headers`` are whatever headers (typically a Referer) the API had
    already attached to the *outer* stream before this "double_redirect"
    hop. Sites like the daddylive-style mirrors used for match feeds
    (e.g. hamis.romponalis.st) 403 a bare request with no Referer, so those
    headers must survive into this request - they used to be discarded
    here, which is what broke every match channel while ordinary streams
    (that never take this branch, or already had their headers baked into
    the JSON blob) kept working.
    """
    raw_value = value
    advanced = _json_object(value)
    if not advanced:
        text = str(value or "")
        marker = "myWebDoubleRedirect_"
        if text.startswith(marker):
            advanced = {"url": text[len(marker):], "headers": {}}
        else:
            raise RuntimeError("Drama Live returned an invalid redirect instruction")

    url = str(advanced.get("url") or "").strip()
    if not url.lower().startswith(("http://", "https://")):
        raise RuntimeError("Drama Live redirect instruction has no HTTP URL")
    headers = dict(base_headers) if isinstance(base_headers, dict) else {}
    supplied = advanced.get("headers")
    if isinstance(supplied, string_types):
        supplied = _json_object(supplied)
    if isinstance(supplied, dict):
        headers.update(supplied)
    if not any(str(key).lower() == "user-agent" for key in headers):
        headers["User-Agent"] = _headers(user_agent).get("User-Agent")
    if not any(str(key).lower() == "referer" for key in headers):
        # Fallback for hosts (daddylive-style match mirrors, e.g.
        # hamis.romponalis.st) that 403 a request with no Referer at all
        # but don't actually validate it against a specific embed page -
        # a same-origin Referer is enough to pass that check when the API
        # didn't hand us one explicitly.
        parsed = urlparse(url)
        if parsed.scheme and parsed.netloc:
            headers["Referer"] = "%s://%s/" % (parsed.scheme, parsed.netloc)
    data = advanced.get("data")
    if data:
        response = requests.post(url, data=data, headers=headers,
                                 timeout=(7, 30), verify=False)
    else:
        response = requests.get(url, headers=headers, timeout=(7, 30), verify=False)
    response.raise_for_status()
    text = response.text
    start = advanced.get("returnFrom")
    end = advanced.get("returnTo")
    if start and end:
        begin = text.find(str(start))
        finish = text.find(str(end), begin + len(str(start))) if begin >= 0 else -1
        if finish >= 0:
            text = text[begin + len(str(start)):finish]
    if not text:
        raise RuntimeError("Drama Live redirect page returned no data")
    if isinstance(raw_value, dict):
        raw_value = json.dumps(raw_value, ensure_ascii=False, separators=(",", ":"))
    return str(raw_value), text


def _resolve_drama_redirect(stream, channel_id, user_agent, fallback_name, depth=0):
    """Resolve the redirect chain used by match feeds into a normal media URL."""
    if depth > 4:
        raise RuntimeError("Drama Live redirect chain is too long")
    agent = str(stream.get("agent") or "").strip().lower()
    url = stream.get("url")

    if agent == "all_streams_redirect":
        payload = _drama_request(
            "getLiveAllStreamsById", {"id": channel_id}, user_agent)
        if not isinstance(payload, dict) or int(payload.get("result", -1)) not in (0, 1):
            raise RuntimeError("Drama Live all-streams resolver returned no stream")
        model = payload.get("live")
        if isinstance(model, string_types):
            model = _json_object(model)
        if not isinstance(model, dict):
            raise RuntimeError("Drama Live all-streams resolver returned invalid data")
        candidate = _drama_stream(
            model.get("url"), model.get("agent"), fallback_name)
        if not candidate:
            raise RuntimeError("Drama Live all-streams resolver returned no URL")
        if (candidate.get("agent") == agent and
                candidate.get("url") == url):
            raise RuntimeError("Drama Live all-streams resolver did not advance")
        return _resolve_drama_redirect(
            candidate, channel_id, user_agent, fallback_name, depth + 1)

    if agent == "redirect":
        payload = _drama_redirect_request(
            "getLiveByRedirect",
            {"id": channel_id, "url": url, "agent": agent}, user_agent)
        model = _drama_response_model(payload)
        candidate = _drama_model_stream(model, fallback_name)
        if not candidate:
            raise RuntimeError("Drama Live redirect resolver returned no URL")
        return _resolve_drama_redirect(
            candidate, channel_id, user_agent, fallback_name, depth + 1)

    if agent == "double_redirect":
        request_value, raw_data = _advanced_request_data(
            url, user_agent, base_headers=stream.get("headers"))
        payload = _drama_redirect_request(
            "getLiveByDoubleRedirect",
            {"id": channel_id, "url": request_value,
             "agent": agent, "raw_data": raw_data}, user_agent)
        model = _drama_response_model(payload)
        candidate = _drama_model_stream(model, fallback_name)
        if not candidate:
            raise RuntimeError("Drama Live double redirect returned no URL")
        return _resolve_drama_redirect(
            candidate, channel_id, user_agent, fallback_name, depth + 1)

    if agent == "advanced":
        if not str(url or "").lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
            raise RuntimeError("Drama Live returned an invalid advanced stream")
        return stream

    hostname = urlparse(str(url or "")).hostname or ""
    if hostname.startswith("."):
        raise RuntimeError("Drama Live returned an unresolved internal stream identifier")
    return stream


def _probe_drama_stream(stream):
    response = None
    try:
        response = requests.get(stream.get("url"), headers=stream.get("headers") or {},
                                timeout=(3, 7), verify=False, stream=True)
        response.raise_for_status()
        prefix = next(response.iter_content(256), b"")
        if isinstance(prefix, str):
            prefix = prefix.encode("utf-8", "ignore")
        url = str(stream.get("url") or "").lower()
        return bool(prefix) and (".m3u8" not in url or b"#EXTM3U" in prefix.upper())
    except Exception:
        return False
    finally:
        try:
            if response is not None:
                response.close()
        except Exception:
            pass


def resolve_drama_channel(item, user_agent):
    channel_id = str((item or {}).get("id") or "").strip()
    name = str((item or {}).get("name") or "Drama Live").strip()
    if not channel_id:
        raise RuntimeError("Drama Live channel identifier is missing")
    payload = _drama_request(
        "getLiveAllStreamsById", {"id": channel_id}, user_agent)
    if int(payload.get("result", -1)) not in (0, 1):
        raise RuntimeError("Drama Live has no active stream for this channel")
    live = payload.get("live", {})
    if isinstance(live, str):
        live = json.loads(live)
    if not isinstance(live, dict):
        raise RuntimeError("Drama Live returned invalid stream data")

    streams = []
    primary = _drama_stream(live.get("url"), live.get("agent"), name)
    if primary:
        streams.append(primary)
    for backup in str(live.get("backup") or "").split(" -;- "):
        parts = backup.split(" -- ", 1)
        if len(parts) != 2:
            continue
        candidate = _drama_stream(parts[0], parts[1], name)
        if candidate and all(candidate["url"] != old["url"] for old in streams):
            streams.append(candidate)
    if not streams:
        raise RuntimeError("Drama Live returned no stream candidates")
    resolved_streams = []
    last_error = None
    for candidate in streams:
        try:
            resolved = _resolve_drama_redirect(
                candidate, channel_id, user_agent, name)
            if resolved and all(resolved["url"] != old["url"] for old in resolved_streams):
                resolved_streams.append(resolved)
        except Exception as error:
            last_error = error
    streams = resolved_streams
    if not streams:
        raise RuntimeError("Unable to resolve this Drama Live stream: %s" %
                           str(last_error or "unknown redirect error"))
    selected = None
    for candidate in streams[:4]:
        if _probe_drama_stream(candidate):
            selected = candidate
            break
    if selected is not None and selected is not streams[0]:
        streams = [selected] + [candidate for candidate in streams if candidate is not selected]
    return {"name": name, "url": streams[0]["url"], "urls": [x["url"] for x in streams],
            "streams": streams, "headers": streams[0].get("headers", {}),
            "source": "dramalive"}


def _show_model_candidates(model, fallback_name):
    result = []
    values = [(model.get("id"), model.get("agent"))]
    for backup in str(model.get("backup") or "").split(" -;- "):
        parts = backup.split(" -- ", 1)
        if len(parts) == 2:
            values.append((parts[0], parts[1]))
    for value, agent in values:
        agent_name = str(agent or "").strip().lower()
        if agent_name in ("redirect", "double_redirect", "all_streams_redirect"):
            candidate = {"name": fallback_name, "url": value,
                         "headers": {}, "agent": agent_name}
        else:
            candidate = _drama_stream(value, agent, fallback_name)
        if candidate and all(candidate.get("url") != old.get("url") for old in result):
            result.append(candidate)
    return result


def _resolve_show_candidate(candidate, media_id, user_agent, fallback_name, depth=0):
    if depth > 4:
        raise RuntimeError("Entertainment redirect chain is too long")
    agent = str(candidate.get("agent") or "").strip().lower()
    if agent == "double_redirect":
        request_value, raw_data = _advanced_request_data(
            candidate.get("url"), user_agent, base_headers=candidate.get("headers"))
        # Follow the same resolver order as the Android app.  This is
        # especially important for movies, whose page can contain a decoy or
        # incomplete media URL before the server returns the signed stream.
        last_error = None
        try:
            payload = _drama_request_from(
                DRAMA_SHOW_BASES, "getShowEpisodesByDoubleRedirect",
                {"id": media_id, "raw_data": raw_data}, user_agent)
            rows = _show_rows(payload)
            resolved_rows = []
            for row in rows:
                for nested in _show_model_candidates(row, fallback_name):
                    try:
                        resolved = _resolve_show_candidate(
                            nested, media_id, user_agent, fallback_name, depth + 1)
                        if resolved and all(resolved.get("url") != old.get("url")
                                            for old in resolved_rows):
                            resolved_rows.append(resolved)
                    except Exception as error:
                        last_error = error
            if resolved_rows:
                primary = dict(resolved_rows[0])
                primary["alternatives"] = resolved_rows[1:]
                return primary
        except Exception as error:
            last_error = error

        # Some hosts expose the final URL directly in the fetched page.  Keep
        # this as a fallback and carry the browser headers to the receiver.
        normalised = str(raw_data or "").replace("\\/", "/").replace("\\u0026", "&")
        direct_urls = _unique_urls(_media_urls(normalised))
        if direct_urls:
            instruction = _json_object(request_value) or {}
            supplied = instruction.get("headers")
            if isinstance(supplied, string_types):
                supplied = _json_object(supplied)
            headers = dict(supplied or {}) if isinstance(supplied, dict) else {}
            player_agent = str(instruction.get("agent") or "").strip()
            if player_agent:
                headers.setdefault("User-Agent", player_agent)
            headers.setdefault("User-Agent", _headers(user_agent).get("User-Agent"))
            source_url = str(instruction.get("url") or "").strip()
            if source_url.lower().startswith(("http://", "https://")):
                headers.setdefault("Referer", source_url)
                parsed_source = urlparse(source_url)
                if parsed_source.scheme and parsed_source.netloc:
                    headers.setdefault("Origin", "%s://%s" % (
                        parsed_source.scheme, parsed_source.netloc))
            return {"name": fallback_name, "url": direct_urls[0],
                    "headers": headers, "agent": "hls"}
        raise RuntimeError(str(last_error or "Entertainment redirect failed"))
    if agent == "redirect":
        payload = _drama_redirect_request(
            "getLiveByRedirect",
            {"id": media_id, "url": candidate.get("url"), "agent": agent}, user_agent)
        model = _drama_response_model(payload)
        nested = _drama_model_stream(model, fallback_name)
        if not nested:
            raise RuntimeError("Entertainment redirect returned no URL")
        return _resolve_show_candidate(
            nested, media_id, user_agent, fallback_name, depth + 1)
    if agent == "all_streams_redirect":
        raise RuntimeError("Unsupported entertainment redirect type")
    return candidate


def resolve_drama_episode(item, user_agent):
    media_id = str((item or {}).get("id") or "").strip()
    episode_name = str((item or {}).get("name") or "Video").strip()
    show_name = str((item or {}).get("show_name") or "").strip()
    name = (show_name + " - " + episode_name).strip(" -")
    if not media_id:
        raise RuntimeError("Entertainment episode identifier is missing")
    rows = _show_rows(_drama_request_from(
        DRAMA_SHOW_BASES, "analyzeSearchObject", {"id": media_id}, user_agent))
    streams = []
    last_error = None
    for row in rows:
        for candidate in _show_model_candidates(row, name):
            try:
                resolved = _resolve_show_candidate(
                    candidate, media_id, user_agent, name)
                resolved_items = [resolved] + list((resolved or {}).get("alternatives") or [])
                for resolved_item in resolved_items:
                    if resolved_item and all(resolved_item.get("url") != old.get("url")
                                             for old in streams):
                        resolved_item = dict(resolved_item)
                        resolved_item.pop("alternatives", None)
                        streams.append(resolved_item)
            except Exception as error:
                last_error = error
    if not streams:
        raise RuntimeError("Unable to resolve this entertainment video: %s" %
                           str(last_error or "no playable source"))
    selected = None
    for candidate in streams[:4]:
        if _probe_drama_stream(candidate):
            selected = candidate
            break
    if selected is not None and selected is not streams[0]:
        streams = [selected] + [candidate for candidate in streams if candidate is not selected]
    return {"id": media_id, "name": name, "url": streams[0]["url"],
            "urls": [stream["url"] for stream in streams], "streams": streams,
            "headers": streams[0].get("headers", {}),
            "image": str((item or {}).get("image") or ""),
            "kind": str((item or {}).get("kind") or "series"),
            "source": "drama_episode"}


def _resolved(name, url, referer):
    return {"name": name or "Channel", "url": url, "source": "elahmad",
            "headers": {"Referer": referer}}


def _legacy_post(session, page_url, html, name, user_agent):
    data_match = re.search(r'var\s+da_ta\s*=\s*\{(.*?)\}', html, re.I | re.S)
    crypt_match = re.search(
        r'my_crypt\(a\.link_1\s*,\s*["\']([^"\']+)["\']\s*,\s*["\']([^"\']+)',
        html, re.I | re.S)
    if not data_match or not crypt_match:
        return None
    data = dict(re.findall(
        r'["\']([^"\']+)["\']\s*:\s*["\']([^"\']*)["\']',
        data_match.group(1)))
    if not data:
        return None
    parsed = urlparse(page_url)
    post_url = "%s://%s%s" % (parsed.scheme, parsed.netloc, parsed.path)
    response = session.post(post_url, headers=_headers(user_agent, page_url), data=data,
                            timeout=(7, 20), verify=False)
    response.raise_for_status()
    payload = response.json()
    encrypted = payload.get("link_1", "") if isinstance(payload, dict) else ""
    if not encrypted:
        return None
    url = _decrypt_openssl(
        encrypted, crypt_match.group(1), crypt_match.group(2), key_is_hex=False)
    if url.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
        return _resolved(name, url, page_url)
    return None


def _internal_pages(html, page_url):
    candidates = []
    patterns = (
        r'<iframe[^>]+src=["\']([^"\']+)',
        r'iframe\s*\(\s*["\']([^"\']+)',
    )
    for pattern in patterns:
        for value in re.findall(pattern, html, re.I):
            url = urljoin(page_url, value.replace("&amp;", "&"))
            parsed = urlparse(url)
            if parsed.scheme not in ("http", "https"):
                continue
            host = parsed.netloc.lower().split(":", 1)[0]
            if host not in ("www.elahmad.ru", "elahmad.ru",
                            "www.elahmad.site", "elahmad.site"):
                continue
            if url not in candidates:
                candidates.append(url)
    candidates.sort(key=lambda value: 0 if "radiant.php" in value else 1)
    return candidates[:10]


def _resolve_elahmad_page(session, page_url, name, user_agent, visited, depth=0):
    if depth > 4 or page_url in visited:
        return None
    visited.add(page_url)
    response = session.get(page_url, headers=_headers(user_agent, ELAHMAD_HOME),
                           timeout=(7, 20), verify=False)
    response.raise_for_status()
    page_url = response.url or page_url
    html = response.text

    direct = _media_urls(html)
    if direct:
        return _resolved(name, direct[0], page_url)

    csrf = re.search(r'name=["\']csrf-token["\']\s+content=["\']([^"\']+)', html, re.I)
    endpoint = re.search(r'embed_result\s*=\s*["\']([^"\']+)', html, re.I)
    query_id = parse_qs(urlparse(page_url).query).get("id", [""])[0]
    if csrf and endpoint and query_id:
        try:
            result = session.post(
                urljoin(page_url, endpoint.group(1)),
                headers=dict(_headers(user_agent, page_url),
                             **{"Content-Type": "application/x-www-form-urlencoded"}),
                data={"id": query_id, "csrf_token": csrf.group(1)},
                timeout=(7, 20), verify=False)
            result.raise_for_status()
            payload = result.json()
            url = _decrypt_openssl(
                payload.get("link_4", ""), payload.get("key", ""), payload.get("iv", ""))
            if url.lower().startswith(("http://", "https://", "rtmp://", "rtsp://")):
                return _resolved(name, url, page_url)
        except Exception:
            pass

    try:
        legacy = _legacy_post(session, page_url, html, name, user_agent)
    except Exception:
        legacy = None
    if legacy:
        return legacy

    for nested_url in _internal_pages(html, page_url):
        try:
            resolved = _resolve_elahmad_page(
                session, nested_url, name, user_agent, visited, depth + 1)
            if resolved:
                return resolved
        except Exception:
            continue
    return None


def resolve_elahmad_channel(item, user_agent):
    page_url = str((item or {}).get("page") or "").strip()
    if not page_url:
        raise RuntimeError("Channel page is missing")
    name = str((item or {}).get("name") or "Channel")
    result = _resolve_elahmad_page(
        requests.Session(), page_url, name, user_agent, set(), 0)
    if result:
        return result
    raise RuntimeError("The provider has no compatible live stream for this channel")
