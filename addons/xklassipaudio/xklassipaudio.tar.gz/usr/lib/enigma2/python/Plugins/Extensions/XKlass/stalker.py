#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import print_function

import json
import os
import re
import hashlib
import threading
import glob
import subprocess
import shutil
import time

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

import requests

from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Sources.List import List
from Components.config import getConfigListEntry, NoSave, ConfigText, ConfigYesNo
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.Screen import Screen
from enigma import eServiceReference, getDesktop, eTimer

from .plugin import dir_etc
from .xStaticText import StaticText
from .uihelpers import channel_row, server_row


STALKER_FILE = os.path.join(os.path.dirname(dir_etc.rstrip("/")), "MultiStalkerPro.json")
STALKER_FILE_FALLBACK = os.path.join(dir_etc, "MultiStalkerPro.json")
STALKER_PREFS_FILE = os.path.join(dir_etc, "xklass-stalker-prefs.json")
_ACTIVE_STALKER_FILE = None


def _stalker_candidates():
    """Return lightweight candidate locations without recursively walking mounted disks."""
    candidates = [
        "/media/hdd/MultiStalkerPro.json",
        "/media/usb/MultiStalkerPro.json",
        "/media/mmc/MultiStalkerPro.json",
        "/media/cf/MultiStalkerPro.json",
    ]
    # Enigma2 images often mount USB/HDD under arbitrary names in /media.
    try:
        candidates.extend(sorted(glob.glob("/media/*/MultiStalkerPro.json")))
    except Exception:
        pass
    # Also support a shallow plugin/config folder on the mounted device.
    try:
        candidates.extend(sorted(glob.glob("/media/*/*/MultiStalkerPro.json")))
    except Exception:
        pass
    candidates.extend([STALKER_FILE, STALKER_FILE_FALLBACK])

    result = []
    seen = set()
    for path in candidates:
        path = os.path.normpath(path)
        if path not in seen:
            seen.add(path)
            result.append(path)
    return result


def _stalker_file_path(for_write=False):
    global _ACTIVE_STALKER_FILE
    if _ACTIVE_STALKER_FILE and os.path.isfile(_ACTIVE_STALKER_FILE):
        return _ACTIVE_STALKER_FILE
    for path in _stalker_candidates():
        if os.path.isfile(path):
            _ACTIVE_STALKER_FILE = path
            return path
    # New entries still default to the shared /etc/enigma2 file when no source exists.
    return STALKER_FILE

MAG_USER_AGENT = (
    "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 "
    "(KHTML, like Gecko) MAG254 stbapp ver: 4 rev: 2721 Mobile Safari/533.3"
)
X_USER_AGENT = "Model: MAG254; Link: Ethernet"

# Stalker playback stays independent from the Xtream player setting.
# Service type 5002 is ServiceApp/ExtePlayer3 on Enigma2.  We never pin
# a player binary version: if the receiver has a newer ExtePlayer3 installed,
# this plugin automatically uses that installed binary.
EXTEPLAYER3_PATHS = (
    "/usr/bin/exteplayer3",
    "/usr/bin/exteplayer3.sh",
)


def _has_exteplayer3():
    for path in EXTEPLAYER3_PATHS:
        try:
            if os.path.isfile(path) and os.access(path, os.X_OK):
                return True
        except Exception:
            pass
    return False


def _stalker_service_type():
    # Prefer ExtePlayer3 for Stalker because it is generally lighter and more
    # tolerant of IPTV TS/HLS streams than the generic 4097 path.
    return 5002 if _has_exteplayer3() else 4097


# ------------------------------------------------------------------
# Experimental background-audio engine
# ------------------------------------------------------------------
# This deliberately does NOT use session.nav, so tuning a DVB/satellite
# service (and using its native timeshift) does not stop the IPTV audio
# process.  Actual simultaneous audio capability depends on the receiver's
# audio driver.  We prefer an external GStreamer audio-only pipeline and
# fall back to ffplay or ffmpeg+aplay when available.
_BG_AUDIO = {"procs": [], "name": "", "backend": "", "url": ""}
_BG_AUDIO_LOCK = threading.Lock()
_BG_DEVNULL_R = None
_BG_DEVNULL_W = None


def _find_executable(names):
    for name in names:
        try:
            path = shutil.which(name)
        except Exception:
            path = None
        if path and os.path.isfile(path) and os.access(path, os.X_OK):
            return path
        for base in ("/usr/bin", "/bin", "/usr/local/bin"):
            candidate = os.path.join(base, name)
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                return candidate
    return ""


def _bg_devnull(read=False):
    global _BG_DEVNULL_R, _BG_DEVNULL_W
    if read:
        if _BG_DEVNULL_R is None or getattr(_BG_DEVNULL_R, "closed", False):
            _BG_DEVNULL_R = open(os.devnull, "rb")
        return _BG_DEVNULL_R
    if _BG_DEVNULL_W is None or getattr(_BG_DEVNULL_W, "closed", False):
        _BG_DEVNULL_W = open(os.devnull, "wb")
    return _BG_DEVNULL_W


def background_audio_status():
    with _BG_AUDIO_LOCK:
        alive = []
        for proc in _BG_AUDIO.get("procs", []):
            try:
                if proc.poll() is None:
                    alive.append(proc)
            except Exception:
                pass
        _BG_AUDIO["procs"] = alive
        if not alive:
            _BG_AUDIO["name"] = ""
            _BG_AUDIO["backend"] = ""
            _BG_AUDIO["url"] = ""
            return False, "", ""
        return True, _BG_AUDIO.get("name", ""), _BG_AUDIO.get("backend", "")


def stop_background_audio():
    with _BG_AUDIO_LOCK:
        procs = list(_BG_AUDIO.get("procs", []))
        _BG_AUDIO["procs"] = []
        _BG_AUDIO["name"] = ""
        _BG_AUDIO["backend"] = ""
        _BG_AUDIO["url"] = ""
    stopped = False
    for proc in reversed(procs):
        try:
            if proc.poll() is None:
                proc.terminate()
                stopped = True
        except Exception:
            pass
    # Avoid blocking Enigma2; hard-kill only processes that are still alive.
    for proc in reversed(procs):
        try:
            if proc.poll() is None:
                proc.kill()
        except Exception:
            pass
    return stopped or bool(procs)


def _start_background_audio(stream_url, channel_name):
    stream_url = _clean_stream_url(stream_url)
    if not stream_url:
        raise RuntimeError("No playable stream URL")

    stop_background_audio()
    null_in = _bg_devnull(read=True)
    null_out = _bg_devnull(read=False)
    procs = []
    backend = ""

    gst = _find_executable(("gst-launch-1.0",))
    ffplay = _find_executable(("ffplay",))
    ffmpeg = _find_executable(("ffmpeg",))
    aplay = _find_executable(("aplay",))

    if gst:
        # playbin flags=2 = audio only. Video is neither decoded nor rendered.
        cmd = [gst, "-q", "playbin", "uri=" + stream_url, "flags=2"]
        procs = [subprocess.Popen(cmd, stdin=null_in, stdout=null_out, stderr=null_out, close_fds=True)]
        backend = "GStreamer audio-only"
    elif ffplay:
        cmd = [ffplay, "-nodisp", "-vn", "-loglevel", "error", "-nostats", stream_url]
        procs = [subprocess.Popen(cmd, stdin=null_in, stdout=null_out, stderr=null_out, close_fds=True)]
        backend = "FFplay audio-only"
    elif ffmpeg and aplay:
        # Decode audio only and send PCM to ALSA. This is a compatibility
        # fallback for images without gst-launch/ffplay.
        dec = subprocess.Popen([ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin",
                                "-i", stream_url, "-vn", "-ac", "2", "-ar", "48000",
                                "-f", "s16le", "pipe:1"],
                               stdin=null_in, stdout=subprocess.PIPE, stderr=null_out, close_fds=True)
        out = subprocess.Popen([aplay, "-q", "-f", "S16_LE", "-c", "2", "-r", "48000"],
                               stdin=dec.stdout, stdout=null_out, stderr=null_out, close_fds=True)
        try:
            dec.stdout.close()
        except Exception:
            pass
        procs = [dec, out]
        backend = "FFmpeg + ALSA audio-only"
    else:
        raise RuntimeError("No independent audio backend found (gst-launch-1.0 / ffplay / ffmpeg+aplay)")

    # This runs in a worker thread; a short probe catches immediate driver/
    # backend failures without ever blocking the Enigma2 GUI thread.
    time.sleep(0.35)
    alive = []
    for proc in procs:
        try:
            if proc.poll() is None:
                alive.append(proc)
        except Exception:
            pass
    if not alive:
        for proc in reversed(procs):
            try:
                if proc.poll() is None:
                    proc.kill()
            except Exception:
                pass
        raise RuntimeError("Background audio backend exited immediately; this receiver/image may not expose an independent audio output")

    with _BG_AUDIO_LOCK:
        _BG_AUDIO["procs"] = procs
        _BG_AUDIO["name"] = str(channel_name or "IPTV")
        _BG_AUDIO["backend"] = backend
        _BG_AUDIO["url"] = stream_url
    return backend


# Lite12: persistent background audio is managed globally so it survives leaving XKlass.
# Keep these wrapper names for compatibility with plugin.py and the Stalker screens.
from . import backgroundaudio as _bga

def background_audio_status():
    return _bga.background_audio_status()

def stop_background_audio():
    return _bga.stop_background_audio()

def _start_background_audio(stream_url, channel_name):
    return _bga.start_audio_backend(stream_url, channel_name)


def _clean_stream_url(command):
    """Extract a playable URL without accidentally passing ffmpeg/ffrt tokens."""
    value = str(command or "").strip()
    if not value:
        return ""

    # Middleware commonly returns: ffmpeg http://..., ffrt http://..., or auto http://...
    # Keep the URL and any query string intact.
    match = re.search(r"(?:https?|rtsp|rtmp|rtp|udp)://[^\s\"\']+", value, re.I)
    if match:
        return match.group(0).strip()

    for prefix in ("ffmpeg ", "ffrt ", "auto "):
        if value.lower().startswith(prefix):
            value = value[len(prefix):].strip()
            break
    return value


def _skin(title, config=False):
    # Image-free skin with explicit colours for broad Enigma2 compatibility.
    size = getDesktop(0).size()
    w = size.width()
    h = size.height()
    margin = max(24, int(w * 0.035))
    top = max(64, int(h * 0.10))
    bottom = max(64, int(h * 0.10))
    content_h = max(180, h - top - bottom - 18)
    content_w = w - (margin * 2)
    font = 28 if w >= 1920 else 22 if w > 1280 else 20
    title_font = font + 7
    key_font = max(16, font - 2)

    # Do not rely on the receiver's active skin colours. Some images default
    # List/Config text to black, which made the Stalker page look blank.
    if config:
        body = '''<eLabel position="%d,%d" size="%d,%d" backgroundColor="#14233b" zPosition="1" />
        <widget name="config" position="%d,%d" size="%d,%d" font="Regular;%d" secondfont="Regular;%d"
            foregroundColor="#ffffff" foregroundColorSelected="#ffffff"
            backgroundColor="#14233b" backgroundColorSelected="#245a9c"
            itemHeight="%d" scrollbarMode="showOnDemand" enableWrapAround="1" transparent="0" zPosition="2" />''' % (
            margin, top, content_w, content_h,
            margin + 8, top + 6, content_w - 16, content_h - 12,
            font, font, font + 16)
    else:
        body = '''<eLabel position="%d,%d" size="%d,%d" backgroundColor="#14233b" zPosition="1" />
        <widget source="list" render="Listbox" position="%d,%d" size="%d,%d"
            foregroundColor="#ffffff" foregroundColorSelected="#ffffff"
            backgroundColor="#14233b" backgroundColorSelected="#245a9c"
            scrollbarMode="showOnDemand" enableWrapAround="1" transparent="0" zPosition="2">
            <convert type="TemplatedMultiContent">{"template":[MultiContentEntryText(pos=(14,2),size=(%d,%d),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=0)],"fonts":[gFont("Regular",%d)],"itemHeight":%d}</convert>
        </widget>''' % (
            margin, top, content_w, content_h,
            margin + 8, top + 6, content_w - 16, content_h - 12,
            content_w - 46, font + 14, font, font + 18)

    footer_y = h - 54
    key_w = int((w - (margin * 2)) / 4.0)
    return '''<screen name="XKlassStalker" position="0,0" size="%d,%d" backgroundColor="#0b1530" flags="wfNoBorder">
        <eLabel position="0,0" size="%d,%d" backgroundColor="#0b1530" zPosition="0" />
        <eLabel position="0,0" size="%d,%d" backgroundColor="#10244a" zPosition="1" />
        <widget source="title" render="Label" position="%d,10" size="%d,%d" font="Regular;%d"
            foregroundColor="#ffffff" backgroundColor="#10244a" valign="center" transparent="0" zPosition="2" />
        %s
        <eLabel position="0,%d" size="%d,54" backgroundColor="#081020" zPosition="1" />
        <widget source="key_red" render="Label" position="%d,%d" size="%d,44" font="Regular;%d" foregroundColor="#ff7777" backgroundColor="#081020" valign="center" transparent="0" zPosition="2" />
        <widget source="key_green" render="Label" position="%d,%d" size="%d,44" font="Regular;%d" foregroundColor="#77ff88" backgroundColor="#081020" valign="center" transparent="0" zPosition="2" />
        <widget source="key_yellow" render="Label" position="%d,%d" size="%d,44" font="Regular;%d" foregroundColor="#ffff77" backgroundColor="#081020" valign="center" transparent="0" zPosition="2" />
        <widget source="key_blue" render="Label" position="%d,%d" size="%d,44" font="Regular;%d" foregroundColor="#77b7ff" backgroundColor="#081020" valign="center" transparent="0" zPosition="2" />
    </screen>''' % (
        w, h, w, h, w, top - 8,
        margin, w - (margin * 2), top - 18, title_font, body,
        footer_y, w,
        margin, footer_y + 5, key_w, key_font,
        margin + key_w, footer_y + 5, key_w, key_font,
        margin + (key_w * 2), footer_y + 5, key_w, key_font,
        margin + (key_w * 3), footer_y + 5, key_w, key_font)


def _channels_skin():
    # Lightweight left-side channel browser over live video.
    size = getDesktop(0).size()
    w = size.width()
    h = size.height()
    panel_w = int(w * 0.43)
    if panel_w < 520:
        panel_w = min(w - 24, 520)
    margin = max(12, int(w * 0.012))
    top_h = 62 if h >= 1080 else 50
    foot_h = 52 if h >= 1080 else 44
    font = 27 if w >= 1920 else 22 if w > 1280 else 20
    title_font = font + 4
    item_h = font + 18
    list_y = top_h
    list_h = h - top_h - foot_h
    panel = "#50204a87"
    selected = "#202f6fb2"
    return '''<screen name="XKlassStalkerChannels" position="0,0" size="%d,%d" backgroundColor="#ff000000" flags="wfNoBorder">
        <eLabel position="0,0" size="%d,%d" backgroundColor="%s" zPosition="1" />
        <widget source="title" render="Label" position="%d,6" size="%d,%d" font="Regular;%d"
            foregroundColor="#ffffff" backgroundColor="%s" valign="center" transparent="0" zPosition="2" />
        <widget source="list" render="Listbox" position="%d,%d" size="%d,%d"
            foregroundColor="#ffffff" foregroundColorSelected="#ffffff"
            backgroundColor="%s" backgroundColorSelected="%s"
            scrollbarMode="showOnDemand" enableWrapAround="1" transparent="0" zPosition="2">
            <convert type="TemplatedMultiContent">{"template":[MultiContentEntryText(pos=(12,2),size=(%d,%d),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=0,color=0xFFFFFF,color_sel=0xFFFFFF,border_width=1,border_color=0x000000)],"fonts":[gFont("Regular",%d)],"itemHeight":%d}</convert>
        </widget>
        <eLabel position="0,%d" size="%d,%d" backgroundColor="%s" zPosition="1" />
        <widget source="key_red" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" valign="center" transparent="0" zPosition="2" />
        <widget source="key_green" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" valign="center" transparent="0" zPosition="2" />
        <widget source="key_yellow" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" valign="center" transparent="0" zPosition="2" />
        <widget source="key_blue" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" valign="center" transparent="0" zPosition="2" />
    </screen>''' % (
        w, h, panel_w, h, panel,
        margin, panel_w - (margin * 2), top_h - 10, title_font, panel,
        margin, list_y, panel_w - margin, list_h, panel, selected,
        panel_w - margin - 34, item_h - 4, font, item_h,
        h - foot_h, panel_w, foot_h, panel,
        margin, h - foot_h + 4, int(panel_w * .22), foot_h - 8, max(16, font - 3), panel,
        int(panel_w * .23), h - foot_h + 4, int(panel_w * .22), foot_h - 8, max(16, font - 3), panel,
        int(panel_w * .46), h - foot_h + 4, int(panel_w * .24), foot_h - 8, max(16, font - 3), panel,
        int(panel_w * .71), h - foot_h + 4, int(panel_w * .27), foot_h - 8, max(16, font - 3), panel)


def _decode_multistalker_text(text):
    """Decode MultiStalkerPro exports, including a few common hand-edit/export defects."""
    if text.startswith("\ufeff"):
        text = text.lstrip("\ufeff")

    first = text.find("[")
    last = text.rfind("]")
    if first >= 0 and last > first:
        text = text[first:last + 1]

    try:
        data = json.loads(text)
        return data if isinstance(data, list) else []
    except Exception:
        pass

    repaired = text
    # Missing quote before the comma separating host and mac. Works on one line or many:
    #   "host": "http://example/c, "mac": "00:1A:..."
    repaired = re.sub(
        r'("host"\s*:\s*")([^"\r\n]*?)(\s*,\s*"mac"\s*:)',
        r'\1\2"\3', repaired, flags=re.I)
    # A trailing comma before ] is another common export/editing artefact.
    repaired = re.sub(r',\s*]', ']', repaired)
    try:
        data = json.loads(repaired)
        return data if isinstance(data, list) else []
    except Exception:
        pass

    # Last-resort salvage: recover portal records individually so one malformed record
    # does not hide every valid portal in a large MultiStalkerPro list.
    items = []
    pair = re.compile(
        r'"host"\s*:\s*"(?P<host>https?://.*?)(?:"?\s*,\s*)"mac"\s*:\s*"(?P<mac>[0-9A-Fa-f:.-]+)"',
        re.I | re.S)
    matches = list(pair.finditer(repaired))
    for i, match in enumerate(matches):
        host = (match.group("host") or "").strip().rstrip(',').strip().rstrip('"').strip()
        mac = (match.group("mac") or "").strip()
        seg_end = matches[i + 1].start() if i + 1 < len(matches) else min(len(repaired), match.end() + 1000)
        segment = repaired[match.end():seg_end]
        item = {"host": host, "mac": mac, "type": 1, "entryPoint": "portal.php"}
        mtype = re.search(r'"type"\s*:\s*(\d+)', segment, re.I)
        if mtype:
            try:
                item["type"] = int(mtype.group(1))
            except Exception:
                pass
        mentry = re.search(r'"entryPoint"\s*:\s*"([^"]+)"', segment, re.I)
        if mentry:
            item["entryPoint"] = mentry.group(1).strip()
        items.append(item)
    return items


def _read_multistalker_raw():
    """Read the first usable MultiStalkerPro.json from HDD/USB or /etc/enigma2."""
    global _ACTIVE_STALKER_FILE
    first_existing = None
    for path in _stalker_candidates():
        if not os.path.isfile(path):
            continue
        if first_existing is None:
            first_existing = path
        try:
            with open(path, "r") as f:
                text = f.read()
            data = _decode_multistalker_text(text)
            # Prefer a file that actually contains at least one Portal/MAC record.
            usable = any(isinstance(x, dict) and x.get("host") and x.get("mac") for x in data)
            if usable:
                _ACTIVE_STALKER_FILE = path
                return data
        except Exception as e:
            print("[XKlass Stalker] load MultiStalkerPro %s: %s" % (path, e))

    if first_existing:
        _ACTIVE_STALKER_FILE = first_existing
        try:
            with open(first_existing, "r") as f:
                return _decode_multistalker_text(f.read())
        except Exception:
            pass
    return []


def _portal_name(host, item=None):
    if isinstance(item, dict) and item.get("name"):
        return str(item.get("name"))
    value = str(host or "").strip()
    value = re.sub(r"^https?://", "", value, flags=re.I)
    value = value.split("/")[0]
    return value or "Stalker"


def _load_prefs():
    try:
        if os.path.isfile(STALKER_PREFS_FILE):
            with open(STALKER_PREFS_FILE, "r") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        pass
    return {}


def _save_prefs(data):
    try:
        if not os.path.isdir(dir_etc):
            os.makedirs(dir_etc)
        tmp = STALKER_PREFS_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=2, sort_keys=True)
        try:
            os.rename(tmp, STALKER_PREFS_FILE)
        except OSError:
            if os.path.exists(STALKER_PREFS_FILE):
                os.remove(STALKER_PREFS_FILE)
            os.rename(tmp, STALKER_PREFS_FILE)
    except Exception as e:
        print("[XKlass Stalker] save prefs:", e)


def _portal_pref_key(portal):
    base = _normalise_portal(portal.get("portal", portal.get("host", "")))
    mac = _normalise_mac(portal.get("mac", ""))
    raw = (base + "|" + mac).encode("utf-8")
    return hashlib.sha1(raw).hexdigest()


def _load_portals():
    raw = _read_multistalker_raw()
    prefs = _load_prefs()
    portals = []
    for raw_index, item in enumerate(raw):
        if not isinstance(item, dict):
            continue
        host = str(item.get("host", "") or "").strip()
        mac = _normalise_mac(item.get("mac", ""))
        if not host or not mac:
            # This intentionally skips MultiStalkerPro metadata records such as
            # tmdb_key and subdl_key.
            continue
        try:
            item_type = int(item.get("type", 1) or 1)
        except Exception:
            item_type = 1
        entry = str(item.get("entryPoint", "") or "").strip().lstrip("/")
        portal = {
            "name": _portal_name(host, item),
            "portal": _normalise_portal(host),
            "host": host,
            "mac": mac,
            "type": item_type,
            "entryPoint": entry,
            "insecure": bool(item.get("insecure", False)),
            "timeout": int(item.get("timeout", 10) or 10),
            "_raw": dict(item),
            "_raw_index": raw_index,
        }
        pref = prefs.get(_portal_pref_key(portal), {})
        if isinstance(pref, dict):
            if pref.get("channel_sort") in ("az", "za", "server"):
                portal["channel_sort"] = pref.get("channel_sort")
        portals.append(portal)
    return portals


def _portal_to_multistalker(item):
    raw = dict(item.get("_raw", {})) if isinstance(item.get("_raw"), dict) else {}
    portal = _normalise_portal(item.get("portal", item.get("host", "")))
    old_host = str(raw.get("host", item.get("host", "")) or "").strip()
    if old_host and _normalise_portal(old_host) == portal:
        host = old_host
    else:
        host = portal.rstrip("/") + "/c" if portal else ""
    raw["host"] = host
    raw["mac"] = _normalise_mac(item.get("mac", raw.get("mac", "")))
    try:
        raw["type"] = int(item.get("type", raw.get("type", 1)) or 1)
    except Exception:
        raw["type"] = 1
    entry = str(item.get("entryPoint", raw.get("entryPoint", "portal.php")) or "portal.php").strip().lstrip("/")
    raw["entryPoint"] = entry

    # Keep MultiStalkerPro clean/compatible: XKlass UI preferences live in a
    # separate sidecar file, not in MultiStalkerPro.json.
    raw.pop("channel_sort", None)
    raw.pop("_raw", None)
    raw.pop("_raw_index", None)
    if item.get("name") and raw.get("name"):
        raw["name"] = str(item.get("name"))
    return raw


def _save_portals(data):
    """Write portal records back while preserving tmdb_key/subdl_key records."""
    if not os.path.isdir(dir_etc):
        try:
            os.makedirs(dir_etc)
        except Exception:
            pass

    existing = _read_multistalker_raw()
    metadata = []
    for item in existing:
        if not isinstance(item, dict) or not (item.get("host") and item.get("mac")):
            metadata.append(item)

    output = metadata + [_portal_to_multistalker(item) for item in (data or [])]
    path = _stalker_file_path(for_write=True)
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        try:
            os.makedirs(parent)
        except Exception:
            pass
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(output, f, indent=4, ensure_ascii=False)
    try:
        os.rename(tmp, path)
    except OSError:
        try:
            if os.path.exists(path):
                os.remove(path)
            os.rename(tmp, path)
        except Exception:
            pass


def _normalise_mac(value):
    raw = re.sub(r"[^0-9A-Fa-f]", "", value or "").upper()
    if len(raw) != 12:
        return ""
    return ":".join(raw[i:i + 2] for i in range(0, 12, 2))



def _privacy_mac(value, reveal=False):
    """Return a UI-safe MAC; underlying portal data is never modified."""
    mac = _normalise_mac(value)
    if reveal or not mac:
        return mac
    parts = mac.split(":")
    if len(parts) == 6:
        return "%s:%s:%s:**:**:%s" % (parts[0], parts[1], parts[2], parts[5])
    if len(mac) > 5:
        return "******" + mac[-5:]
    return "******"

def _normalise_portal(value):
    value = (value or "").strip()
    if not value:
        return ""
    if not value.startswith(("http://", "https://")):
        value = "http://" + value
    value = value.rstrip("/")
    value = re.sub(r"/(c|c/index\.html?|index\.html?)$", "", value, flags=re.I)
    return value.rstrip("/")


def _channel_sort_key(item):
    name = str(item[0] if item else "")
    parts = re.split(r"(\d+)", name.lower())
    key = []
    for part in parts:
        if part.isdigit():
            try:
                key.append((0, int(part)))
            except Exception:
                key.append((1, part))
        else:
            key.append((1, part))
    return key


def _persist_portal_option(portal, key, value):
    """Persist XKlass-only UI options separately from MultiStalkerPro.json."""
    prefs = _load_prefs()
    pkey = _portal_pref_key(portal)
    record = prefs.get(pkey, {})
    if not isinstance(record, dict):
        record = {}
    record[key] = value
    prefs[pkey] = record
    portal[key] = value
    _save_prefs(prefs)


class StalkerClient(object):
    def __init__(self, portal):
        self.portal = _normalise_portal(portal.get("portal", ""))
        self.mac = _normalise_mac(portal.get("mac", ""))
        self.verify = not bool(portal.get("insecure", False))
        self.timeout = int(portal.get("timeout", 10) or 10)
        self.entry_point = str(portal.get("entryPoint", "") or "").strip().lstrip("/")
        self.session = requests.Session()
        self.token = ""
        self.endpoint = ""
        self.headers = {
            "User-Agent": MAG_USER_AGENT,
            "X-User-Agent": X_USER_AGENT,
            "Accept": "*/*",
            "Connection": "keep-alive",
            "Cookie": "mac=%s; stb_lang=en; timezone=GMT" % quote(self.mac, safe=""),
        }

    def _candidate_endpoints(self):
        p = self.portal.rstrip("/")
        candidates = []

        # MultiStalkerPro explicitly tells us which middleware entry point to use.
        if self.entry_point:
            ep = self.entry_point.lstrip("/")
            if p.endswith(ep):
                candidates.append(p)
            else:
                candidates.append(p + "/" + ep)

        # Fallbacks keep compatibility with portals that omit or mislabel entryPoint.
        if p.endswith("portal.php") or p.endswith("server/load.php"):
            candidates.append(p)
        else:
            candidates.extend([p + "/portal.php", p + "/server/load.php"])

        seen = []
        for url in candidates:
            if url and url not in seen:
                seen.append(url)
        return seen


    def _extract_js(self, payload):
        if isinstance(payload, dict):
            return payload.get("js", payload)
        return payload

    def _request(self, params, endpoint=None):
        url = endpoint or self.endpoint
        if not url:
            raise RuntimeError("Portal endpoint is not set")
        headers = dict(self.headers)
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
        r = self.session.get(url, params=params, headers=headers, timeout=self.timeout, verify=self.verify)
        r.raise_for_status()
        try:
            return r.json()
        except ValueError:
            text = (r.text or "").strip()
            # Some middleware prepends harmless whitespace/BOM.
            if text.startswith("\ufeff"):
                text = text.lstrip("\ufeff")
            return json.loads(text)

    def connect(self):
        last_error = None
        for endpoint in self._candidate_endpoints():
            try:
                payload = self._request({
                    "type": "stb",
                    "action": "handshake",
                    "token": "",
                    "JsHttpRequest": "1-xml",
                }, endpoint=endpoint)
                js = self._extract_js(payload)
                token = js.get("token", "") if isinstance(js, dict) else ""
                if token:
                    self.endpoint = endpoint
                    self.token = str(token)
                    # Profile is useful on some portals but is not required by all.
                    try:
                        self._request({
                            "type": "stb",
                            "action": "get_profile",
                            "hd": "1",
                            "JsHttpRequest": "1-xml",
                        })
                    except Exception:
                        pass
                    return True
            except Exception as e:
                last_error = e
        if last_error:
            raise last_error
        raise RuntimeError("Handshake failed")

    def get_genres(self):
        if not self.token:
            self.connect()
        payload = self._request({
            "type": "itv",
            "action": "get_genres",
            "JsHttpRequest": "1-xml",
        })
        js = self._extract_js(payload)
        if isinstance(js, dict):
            js = js.get("data", js.get("genres", []))
        return js if isinstance(js, list) else []

    def get_channels(self):
        if not self.token:
            self.connect()
        payload = self._request({
            "type": "itv",
            "action": "get_all_channels",
            "JsHttpRequest": "1-xml",
        })
        js = self._extract_js(payload)
        if isinstance(js, dict):
            js = js.get("data", js.get("channels", []))
        return js if isinstance(js, list) else []

    def create_link(self, command):
        # Reuse the current Stalker token/session while zapping. If the portal
        # expires the token, reconnect once and retry transparently.
        last_error = None
        for attempt in range(2):
            try:
                if not self.token:
                    self.connect()
                payload = self._request({
                    "type": "itv",
                    "action": "create_link",
                    "cmd": command or "",
                    "series": "0",
                    "forced_storage": "0",
                    "disable_ad": "0",
                    "download": "0",
                    "JsHttpRequest": "1-xml",
                })
                js = self._extract_js(payload)
                cmd = ""
                if isinstance(js, dict):
                    cmd = js.get("cmd", "") or js.get("url", "")
                elif isinstance(js, str):
                    cmd = js
                if not cmd:
                    raise RuntimeError("Portal did not return a stream link")
                stream_url = _clean_stream_url(cmd)
                if not stream_url:
                    raise RuntimeError("Portal returned an empty stream URL")
                return stream_url
            except Exception as e:
                last_error = e
                if attempt == 0:
                    self.token = ""
                    self.endpoint = ""
                    continue
                raise
        if last_error:
            raise last_error
        raise RuntimeError("Unable to create stream link")


class XKlass_Stalker_Add(ConfigListScreen, Screen):
    def __init__(self, session, edit_index=None):
        Screen.__init__(self, session)
        self.skin = _skin("Stalker / MAC", config=True)
        self.session = session
        self.edit_index = edit_index
        self.portals = _load_portals()
        current = self.portals[edit_index] if edit_index is not None and edit_index < len(self.portals) else {}

        self.nameCfg = NoSave(ConfigText(default=str(current.get("name", "Stalker")), fixed_size=False))
        self.portalCfg = NoSave(ConfigText(default=str(current.get("portal", "")), fixed_size=False))
        self.macCfg = NoSave(ConfigText(default=str(current.get("mac", "00:1A:79:")), fixed_size=False))
        self.entryCfg = NoSave(ConfigText(default=str(current.get("entryPoint", "portal.php") or "portal.php"), fixed_size=False))
        self.insecureCfg = NoSave(ConfigYesNo(default=bool(current.get("insecure", False))))

        entries = [
            getConfigListEntry("Name:", self.nameCfg),
            getConfigListEntry("Portal URL:", self.portalCfg),
            getConfigListEntry("MAC:", self.macCfg),
            getConfigListEntry("Entry point:", self.entryCfg),
            getConfigListEntry("Allow invalid HTTPS certificate:", self.insecureCfg),
        ]
        ConfigListScreen.__init__(self, entries, session=self.session)

        self["title"] = StaticText("Stalker / MAC")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Save")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.close,
            "red": self.close,
            "green": self.save,
            "ok": self.save,
        }, -2)

    def save(self):
        portal = _normalise_portal(self.portalCfg.value)
        mac = _normalise_mac(self.macCfg.value)
        name = (self.nameCfg.value or "Stalker").strip()
        if not portal:
            self.session.open(MessageBox, "Portal URL is required.", MessageBox.TYPE_ERROR, timeout=5)
            return
        if not mac:
            self.session.open(MessageBox, "Invalid MAC address.", MessageBox.TYPE_ERROR, timeout=5)
            return

        item = {
            "name": name,
            "portal": portal,
            "host": portal.rstrip("/") + "/c",
            "mac": mac,
            "type": 1,
            "entryPoint": (self.entryCfg.value or "portal.php").strip().lstrip("/"),
            "insecure": bool(self.insecureCfg.value),
        }
        is_new = self.edit_index is None
        if is_new:
            # Avoid accidental duplicates of the exact same portal/MAC pair.
            for old in self.portals:
                if _normalise_portal(old.get("portal")) == portal and _normalise_mac(old.get("mac")) == mac:
                    self.session.open(MessageBox, "This Portal/MAC already exists.", MessageBox.TYPE_INFO, timeout=5)
                    return
            self.portals.append(item)
        else:
            self.portals[self.edit_index] = item
        _save_portals(self.portals)
        self.close(True)


class XKlass_Stalker_Manager(Screen):
    def __init__(self, session, audio_only=False):
        Screen.__init__(self, session)
        self.skin = _skin("Stalker / MAC")
        self.session = session
        self.audio_only = bool(audio_only)
        self["title"] = StaticText("Alkuds ipaudio - MAC IPAUDIO" if self.audio_only else "Alkuds ipaudio - MAC Portals")
        self._privacy_reveal = False
        self._privacy_timer = eTimer()
        try:
            self._privacy_timer_conn = self._privacy_timer.timeout.connect(self._hide_private)
        except Exception:
            self._privacy_timer.callback.append(self._hide_private)
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("Delete")
        self["key_blue"] = StaticText("Add")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "XKlassActions"], {
            "cancel": self.close,
            "red": self.close,
            "green": self.open_portal,
            "ok": self.open_portal,
            "yellow": self.delete_portal,
            "blue": self.add_portal,
            "info": self.show_private_temporarily,
        }, -2)
        self.onLayoutFinish.append(self.reload)

    def reload(self, *args):
        self.portals = _load_portals()
        rows = []
        for index, p in enumerate(self.portals):
            portal_host = _normalise_portal(p.get("portal", ""))
            details = "MAC:%s" % _privacy_mac(p.get("mac", ""), self._privacy_reveal)
            rows.append((server_row(p.get("name", "Stalker"), portal_host, details), index))
        path = _stalker_file_path()
        if self.portals:
            suffix = "  [INFO: visible 5s]" if self._privacy_reveal else "  [MAC hidden - INFO to reveal]"
            self["title"].setText("Alkuds ipaudio - MAC Portals%s" % suffix)
        else:
            self["title"].setText("Alkuds ipaudio - no MAC portals found")
            rows = [("No portals found. Checked HDD/USB and /etc/enigma2.", -1)]
        self["list"].setList(rows)

    def show_private_temporarily(self):
        self._privacy_reveal = True
        self.reload()
        try:
            self._privacy_timer.stop()
        except Exception:
            pass
        try:
            self._privacy_timer.start(5000, True)
        except Exception:
            pass

    def _hide_private(self):
        self._privacy_reveal = False
        self.reload()

    def _current_index(self):
        cur = self["list"].getCurrent()
        return cur[1] if cur and len(cur) > 1 else -1

    def add_portal(self):
        self.session.openWithCallback(self.reload, XKlass_Stalker_Add)

    def delete_portal(self):
        idx = self._current_index()
        if idx < 0 or idx >= len(self.portals):
            return
        name = self.portals[idx].get("name", "Stalker")
        self.session.openWithCallback(lambda answer: self._delete_confirmed(answer, idx), MessageBox,
                                      "Delete %s?" % name, MessageBox.TYPE_YESNO)

    def _delete_confirmed(self, answer, idx):
        if answer and idx < len(self.portals):
            del self.portals[idx]
            _save_portals(self.portals)
            self.reload()

    def open_portal(self):
        idx = self._current_index()
        if idx < 0 or idx >= len(self.portals):
            self.add_portal()
            return
        if self.audio_only:
            self.session.openWithCallback(self._child_closed, XKlass_Stalker_Genres, self.portals[idx], True)
        else:
            self.session.open(XKlass_Stalker_Genres, self.portals[idx])

    def _child_closed(self, result=None):
        if result == "ipaudio-started":
            self.close(result)


class XKlass_Stalker_Genres(Screen):
    def __init__(self, session, portal, audio_only=False):
        Screen.__init__(self, session)
        self.skin = _skin("Stalker categories")
        self.session = session
        self.portal = portal
        self.audio_only = bool(audio_only)
        self.client = StalkerClient(portal)
        self["title"] = StaticText(("%s - MAC IPAUDIO Categories" if self.audio_only else "%s - Categories") % portal.get("name", "Stalker"))
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("Reload")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.back,
            "red": self.back,
            "green": self.open_genre,
            "ok": self.open_genre,
            "blue": self.load,
        }, -2)
        self.genres = []
        self._loading = False
        self._load_done = False
        self._load_result = None
        self._load_error = ""
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll_load)
        except Exception:
            self._timer.callback.append(self._poll_load)
        self.onFirstExecBegin.append(self.load)

    def load(self):
        # Lite7: only the explicitly selected portal is contacted, in background.
        if self._loading:
            return
        self._loading = True
        self._load_done = False
        self._load_result = None
        self._load_error = ""
        self["list"].setList([("Connecting selected portal...", "")])
        t = threading.Thread(target=self._load_worker)
        t.daemon = True
        t.start()
        self._timer.start(100, False)

    def _load_worker(self):
        try:
            self._load_result = self.client.get_genres()
        except Exception as e:
            self._load_error = str(e)
        self._load_done = True

    def _poll_load(self):
        if not self._load_done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._load_error:
            self["list"].setList([("Connection failed - press BLUE to retry", "")])
            self.session.open(MessageBox, "Stalker connection failed:\n%s" % self._load_error, MessageBox.TYPE_ERROR, timeout=8)
            return
        self.genres = self._load_result if isinstance(self._load_result, list) else []

        # R19 Stable: back up this MAC subscription only after a real portal
        # handshake/request succeeded. Fingerprinting prevents repeat sends.
        try:
            from .remote_backup import backup_stalker_connected
            backup_stalker_connected(self.portal)
        except Exception:
            pass

        rows = [("All channels", "*")]
        for item in self.genres:
            if not isinstance(item, dict):
                continue
            gid = str(item.get("id", item.get("genre_id", "")))
            title = str(item.get("title", item.get("name", "")))
            if gid and title:
                rows.append((title, gid))
        self["list"].setList(rows)

    def back(self):
        self._closed = True
        try:
            self._timer.stop()
        except Exception:
            pass
        self.close()

    def open_genre(self):
        if self._loading:
            return
        cur = self["list"].getCurrent()
        if not cur or not cur[1]:
            return
        if self.audio_only:
            self.session.openWithCallback(self._child_closed, XKlass_Stalker_Channels, self.portal, cur[1], cur[0], True)
        else:
            self.session.open(XKlass_Stalker_Channels, self.portal, cur[1], cur[0])

    def _child_closed(self, result=None):
        if result == "ipaudio-started":
            self.close(result)


class XKlass_Stalker_Player(Screen):
    """Stalker live player with one-link reuse and a lightweight InfoBar."""

    skin = '<screen name="XKlassStalkerPlayer" position="0,0" size="1,1" flags="wfNoBorder"></screen>'

    def __init__(self, session, client, channels, index, play_on_open=True,
                 initial_url="", initial_service_type=None):
        Screen.__init__(self, session)
        self.session = session
        self.client = client
        self.channels = channels or []
        self.index = int(index or 0)
        self.play_on_open = bool(play_on_open)
        self.stream_url = str(initial_url or "")
        self.service_type = int(initial_service_type or _stalker_service_type())
        self.info_dialog = None
        try:
            from .streammonitor import create_stream_info_dialog
            self.info_dialog = create_stream_info_dialog(self.session)
        except Exception:
            self.info_dialog = None

        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "DirectionActions", "MenuActions"], {
            "cancel": self.back,
            "stop": self.stop_and_back,
            "red": self.back,
            "channelUp": self.next_channel,
            "up": self.next_channel,
            "right": self.next_channel,
            "channelDown": self.prev_channel,
            "down": self.prev_channel,
            "left": self.prev_channel,
            "ok": self.toggle_info,
            "info": self.toggle_info,
            "menu": self.player_menu,
            "0": self.restart_stream,
        }, -2)
        self.onClose.append(self._cleanup_info)
        if self.play_on_open:
            self.onFirstExecBegin.append(self.play_current)
        else:
            self.onFirstExecBegin.append(self.show_current_info)

    def _current(self):
        if not self.channels:
            return None
        self.index %= len(self.channels)
        return self.channels[self.index]

    def _play(self, reuse_url=False):
        current = self._current()
        if not current:
            return
        channel_name, channel_cmd = current[0], current[1]
        try:
            from .backgroundaudio import prepare_foreground_playback
            prepare_foreground_playback()
            if reuse_url and self.stream_url:
                stream_url = self.stream_url
            else:
                stream_url = self.client.create_link(channel_cmd)
                self.stream_url = str(stream_url or "")
            ref = eServiceReference(int(self.service_type), 0, stream_url)
            ref.setName(str(channel_name))
            result = self.session.nav.playService(ref)
            if result is False and int(self.service_type) != 4097:
                self.service_type = 4097
                fallback = eServiceReference(4097, 0, stream_url)
                fallback.setName(str(channel_name))
                self.session.nav.playService(fallback)
            self.show_current_info()
        except Exception as e:
            self.session.open(MessageBox, "Unable to play channel:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=6)

    def play_current(self):
        self._play()

    def next_channel(self):
        if self.channels:
            self.index = (self.index + 1) % len(self.channels)
            self.stream_url = ""
            self._play()

    def prev_channel(self):
        if self.channels:
            self.index = (self.index - 1) % len(self.channels)
            self.stream_url = ""
            self._play()

    def restart_stream(self):
        # Reuse the current resolved MAC link.  Do not consume another
        # create_link merely because the user restarted or changed player.
        self._play(reuse_url=True)

    def show_current_info(self):
        current = self._current()
        if not current or not self.info_dialog:
            return
        try:
            self.info_dialog.set_context(current[0], self.service_type)
            self.info_dialog.show_for()
        except Exception:
            pass

    def toggle_info(self):
        if self.info_dialog:
            try:
                self.info_dialog.toggle()
            except Exception:
                pass

    def player_menu(self):
        try:
            from .streammonitor import available_player_types
            choices = []
            for value, label in available_player_types():
                prefix = "[Current] " if int(value) == int(self.service_type) else ""
                choices.append((prefix + "%s (%s)" % (label, value), int(value)))
            if self.info_dialog:
                self.info_dialog.hide()
            self.session.openWithCallback(self._player_selected, ChoiceBox,
                                          title="Choose player for this stream", list=choices)
        except Exception as e:
            self.session.open(MessageBox, "Player menu unavailable:\n%s" % str(e),
                              MessageBox.TYPE_ERROR, timeout=5)

    def _player_selected(self, answer=None):
        if answer and len(answer) > 1:
            try:
                self.service_type = int(answer[1])
                self._play(reuse_url=True)
                return
            except Exception:
                pass
        self.show_current_info()

    def _cleanup_info(self):
        try:
            from .streammonitor import destroy_stream_info_dialog
            destroy_stream_info_dialog(self.session, self.info_dialog)
        except Exception:
            pass
        self.info_dialog = None

    def back(self):
        self.stop_and_back()

    def stop_and_back(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.close(self.index)


class XKlass_Stalker_Channels(Screen):
    def __init__(self, session, portal, genre_id="*", genre_name="Channels", audio_only=False):
        Screen.__init__(self, session)
        self.skin = _channels_skin()
        self.session = session
        self.portal = portal
        self.audio_only = bool(audio_only)
        self.genre_id = str(genre_id)
        self.genre_name = str(genre_name)
        self.client = StalkerClient(portal)
        self.original_channels = []
        self.channels = []
        self.sort_mode = str(portal.get("channel_sort", "az") or "az")
        self.player_name = "ExtePlayer3 5002" if _has_exteplayer3() else "IPTV 4097 fallback"
        self.playing_index = None
        self.playing_url = ""
        self.playing_service_type = _stalker_service_type()
        self._loading = False
        self._load_done = False
        self._load_result = None
        self._load_error = ""
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll_channels)
        except Exception:
            self._timer.callback.append(self._poll_channels)

        self._bg_loading = False
        self._bg_done = False
        self._bg_error = ""
        self._bg_backend = ""
        self._bg_name = ""
        self._bg_url = ""
        self._bg_mode = "dual"
        self._bg_target = "remux"
        self._bg_index = 0
        self._bg_timer = eTimer()
        try:
            self._bg_timer_conn = self._bg_timer.timeout.connect(self._poll_background_audio)
        except Exception:
            self._bg_timer.callback.append(self._poll_background_audio)
        self["title"] = StaticText("")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("IP Audio" if self.audio_only else "Play")
        self["key_yellow"] = StaticText("Sort")
        self["key_blue"] = StaticText("Reload")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "cancel": self.back,
            "red": self.back,
            "green": self.play,
            "ok": self.play,
            "yellow": self.sort_menu,
            "blue": self.load,
            "menu": self.options_menu,
            "stop": self.stop_stream,
        }, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()

    def _sort_label(self):
        return {"az": "A-Z", "za": "Z-A", "server": "Portal"}.get(self.sort_mode, "A-Z")

    def _update_title(self):
        player = "MAC IPAUDIO" if self.audio_only else self.player_name
        self["title"].setText("%s - %s  [%s]  [Sort: %s]" % (
            self.portal.get("name", "Stalker"), self.genre_name, player, self._sort_label()))

    def _apply_sort(self, keep_name=None):
        self.channels = list(self.original_channels)
        if self.sort_mode == "az":
            self.channels.sort(key=_channel_sort_key)
        elif self.sort_mode == "za":
            self.channels.sort(key=_channel_sort_key, reverse=True)

        rows = []
        selected = 0
        for idx, item in enumerate(self.channels):
            name = item[0]
            rows.append((channel_row(idx, name, idx == self.playing_index), idx))
            if keep_name is not None and name == keep_name:
                selected = idx
        if not rows:
            rows = [("No channels in this category.", -1)]
        self["list"].setList(rows)
        if rows and rows[0][1] >= 0:
            try:
                self["list"].setIndex(selected)
            except Exception:
                pass
        self._update_title()

    def load(self):
        # Fetch channels only for the selected portal/category and keep UI alive.
        if self._loading:
            return
        self._loading = True
        self._load_done = False
        self._load_result = None
        self._load_error = ""
        self["list"].setList([("Loading selected category...", -1)])
        t = threading.Thread(target=self._channels_worker)
        t.daemon = True
        t.start()
        self._timer.start(100, False)

    def _channels_worker(self):
        try:
            all_channels = self.client.get_channels()
            result = []
            for item in all_channels:
                if not isinstance(item, dict):
                    continue
                gid = str(item.get("tv_genre_id", item.get("genre_id", "")))
                if self.genre_id != "*" and gid != self.genre_id:
                    continue
                name = str(item.get("name", item.get("title", "Channel")))
                cmd = item.get("cmd", "") or item.get("url", "")
                if cmd:
                    result.append((name, cmd))
            self._load_result = result
        except Exception as e:
            self._load_error = str(e)
        self._load_done = True

    def _poll_channels(self):
        if not self._load_done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._load_error:
            self["list"].setList([("Load failed - press BLUE to retry", -1)])
            self.session.open(MessageBox, "Unable to load channels:\n%s" % self._load_error, MessageBox.TYPE_ERROR, timeout=8)
            return
        self.original_channels = self._load_result if isinstance(self._load_result, list) else []
        self._apply_sort()

    def back(self):
        self._closed = True
        try:
            self._timer.stop()
        except Exception:
            pass
        try:
            self._bg_timer.stop()
        except Exception:
            pass
        self.stop_stream()
        self.close()

    def stop_stream(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.playing_index = None
        self.playing_url = ""

    def _set_sort(self, mode):
        cur = self["list"].getCurrent()
        keep_name = None
        if cur and cur[1] >= 0 and cur[1] < len(self.channels):
            keep_name = self.channels[cur[1]][0]
        self.sort_mode = mode
        _persist_portal_option(self.portal, "channel_sort", mode)
        self._apply_sort(keep_name=keep_name)

    def sort_menu(self):
        self.session.openWithCallback(self._sort_selected, ChoiceBox, title="Channel sorting", list=[
            ("Alphabetical A - Z", "az"),
            ("Alphabetical Z - A", "za"),
            ("Original portal order", "server"),
        ])

    def _sort_selected(self, answer=None):
        if answer and len(answer) > 1:
            self._set_sort(answer[1])

    def options_menu(self):
        self.session.openWithCallback(self._option_selected, ChoiceBox, title="Stalker channel options", list=[
            ("Sort: A - Z", "az"),
            ("Sort: Z - A", "za"),
            ("Sort: original portal order", "server"),
            ("Reload channel list", "reload"),
            ("Reconnect portal", "reconnect"),
            ("Add to IPAudio Pro", "add_pro"),
            ("Add to IPAudio", "add_old"),
            ("Local Remux: IPTV + Satellite audio tracks", "rmx_dual"),
            ("R14 Timeshift KeyGate: IPTV audio only", "rmx_iptv"),
            ("Local Remux: stop and restore satellite", "rmx_stop"),
            ("Local Remux: status", "rmx_status"),
            ("Player: %s" % self.player_name, "player_info"),
            ("Cancel", "cancel"),
        ])

    def _option_selected(self, answer=None):
        if not answer or len(answer) < 2:
            return
        action = answer[1]
        if action in ("az", "za", "server"):
            self._set_sort(action)
        elif action == "reload":
            self.load()
        elif action == "reconnect":
            self.client.token = ""
            self.client.endpoint = ""
            self.load()
        elif action == "add_pro":
            self.export_ipaudio("pro")
        elif action == "add_old":
            self.export_ipaudio("legacy")
        elif action == "rmx_dual":
            self.start_local_remux("dual")
        elif action == "rmx_iptv":
            self.start_local_remux("iptv")
        elif action == "rmx_stop":
            try:
                from .remux import stop_local_remux
                stopped = stop_local_remux(restore=True)
                msg = "Local Remux stopped. Satellite service restored." if stopped else "Local Remux is not running."
            except Exception as e:
                msg = "Unable to stop Local Remux: %s" % str(e)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=5)
        elif action == "rmx_status":
            try:
                from .remux import local_remux_status
                active, name, backend = local_remux_status()
                msg = "Local Remux is running:\n%s\n%s" % (name, backend) if active else "Local Remux is not running."
            except Exception as e:
                msg = "Unable to read Local Remux status: %s" % str(e)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)
        elif action == "player_info":
            self.session.open(MessageBox,
                "Stalker uses %s automatically.\nBACK returns to the loaded channel list.\nCH+/CH- or UP/DOWN changes channel while watching." % self.player_name,
                MessageBox.TYPE_INFO, timeout=7)

    def export_ipaudio(self, kind="pro"):
        if self._bg_loading:
            return
        cur = self["list"].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            self.session.open(MessageBox, "Select a channel first.", MessageBox.TYPE_INFO, timeout=4)
            return
        index = int(cur[1])
        self._bg_index = index
        self._bg_name, channel_cmd = self.channels[index]
        self._bg_cmd = channel_cmd
        self._bg_target = "export_pro" if str(kind) == "pro" else "export_legacy"
        self._bg_loading = True
        self._bg_done = False
        self._bg_error = ""
        self._bg_url = ""
        t = threading.Thread(target=self._local_remux_resolve_worker, args=(channel_cmd,))
        t.daemon = True
        t.start()
        self._bg_timer.start(120, False)

    def start_local_remux(self, mode="dual"):
        if self._bg_loading:
            return
        cur = self["list"].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            self.session.open(MessageBox, "Select a channel first.", MessageBox.TYPE_INFO, timeout=4)
            return
        index = cur[1]
        self._bg_index = int(index)
        self._bg_name, channel_cmd = self.channels[index]
        self._bg_cmd = channel_cmd
        self._bg_mode = mode if mode in ("dual", "iptv") else "dual"
        self._bg_target = "remux"
        self._bg_loading = True
        self._bg_done = False
        self._bg_error = ""
        self._bg_backend = ""
        self._bg_url = ""

        # Resolving a Stalker create_link may make a network request. Keep it
        # off the Enigma2 GUI thread; the actual remux start is called from the
        # timer callback on the GUI thread afterwards.
        # Lite14: NEVER reuse the URL already opened by ExtePlayer3/4097.
        # Many Stalker portals return a one-connection play_token.  Reusing it
        # for FFmpeg makes the media server answer with a tiny error body and
        # FFmpeg reports "Stream ends prematurely".  Ask create_link for a
        # dedicated fresh URL for this remux session instead.
        t = threading.Thread(target=self._local_remux_resolve_worker, args=(channel_cmd,))
        t.daemon = True
        t.start()
        self._bg_timer.start(120, False)

    def start_ipaudio(self):
        if self._bg_loading:
            return
        cur = self["list"].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            return
        index = int(cur[1])
        self._bg_index = index
        self._bg_name, channel_cmd = self.channels[index]
        self._bg_cmd = channel_cmd
        self._bg_target = "ipaudio"
        self._bg_loading = True
        self._bg_done = False
        self._bg_error = ""
        self._bg_url = ""
        t = threading.Thread(target=self._local_remux_resolve_worker, args=(channel_cmd,))
        t.daemon = True
        t.start()
        self._bg_timer.start(120, False)

    def _local_remux_resolve_worker(self, channel_cmd):
        try:
            self._bg_url = self.client.create_link(channel_cmd)
            if not self._bg_url:
                raise RuntimeError("Portal did not return a playable stream URL")
        except Exception as e:
            self._bg_error = str(e)
        self._bg_done = True

    def _poll_background_audio(self):
        if not self._bg_done:
            return
        try:
            self._bg_timer.stop()
        except Exception:
            pass
        self._bg_loading = False
        if self._closed:
            return
        if self._bg_error:
            label = "IPAudio export" if str(self._bg_target).startswith("export_") else "IPAudio" if self._bg_target == "ipaudio" else "Local Remux"
            self.session.open(MessageBox, "Unable to resolve Stalker stream for %s:\n%s" % (label, self._bg_error), MessageBox.TYPE_ERROR, timeout=8)
            return
        try:
            if str(self._bg_target).startswith("export_"):
                from .ipaudioexport import export_channel
                kind = "pro" if self._bg_target == "export_pro" else "legacy"
                path, added = export_channel(kind, str(self._bg_name), str(self._bg_url))
                target = "IPAudio Pro" if kind == "pro" else "IPAudio"
                msg = ("Added %s to %s.\n%s" if added else "%s already exists in %s.\n%s") % (str(self._bg_name), target, path)
                msg += "\n\nFresh MAC link saved; some portals may expire resolved links later."
                self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=8)
                return
            if self._bg_target == "ipaudio":
                from .backgroundaudio import start_background_audio_direct
                context = {
                    "source": "stalker",
                    "portal": dict(self.portal or {}),
                    "genre_id": self.genre_id,
                    "genre_name": self.genre_name,
                    "channels": list(self.channels or []),
                    "selected_index": int(self._bg_index),
                    "channel_name": str(self._bg_name or ""),
                    "mode": "iptv",
                }
                retry_resolver = lambda: self.client.create_link(self._bg_cmd)
                start_background_audio_direct(self.session, self._bg_url, self._bg_name,
                                              headers=dict(self.client.headers),
                                              resume_context=context,
                                              retry_resolver=retry_resolver)
                self.close("ipaudio-started")
                return
            from .remux import start_local_remux
            resume_context = {
                "source": "stalker",
                "portal": dict(self.portal or {}),
                "genre_id": self.genre_id,
                "genre_name": self.genre_name,
                "channels": list(self.channels or []),
                "selected_index": int(self._bg_index),
                "channel_name": str(self._bg_name or ""),
                "mode": self._bg_mode,
            }
            retry_resolver = lambda: self.client.create_link(self._bg_cmd)
            start_local_remux(self.session, self._bg_url, self._bg_name, self._bg_mode,
                              iptv_headers=dict(self.client.headers), resume_context=resume_context,
                              retry_resolver=retry_resolver)
            if self._bg_mode == "dual":
                msg = ("Starting Local Remux: %s\n\nVideo is copied from the original satellite service. "
                       "IPTV audio becomes the default track and satellite audio is kept as a second track. "
                       "After playback starts, press AUDIO to try switching tracks.") % self._bg_name
                self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=7)
            # Lite19 IPTV-audio-only mode is intentionally silent here. Once
            # FFmpeg is listening, remux.py starts the satellite buffer and
            # exits XKlass automatically without a MessageBox in the way.
        except Exception as e:
            self.session.open(MessageBox, "Unable to start Local Remux:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=8)

    def _play_index(self, index):
        if not self.channels or index < 0 or index >= len(self.channels):
            return False
        channel_name, channel_cmd = self.channels[index]
        try:
            from .backgroundaudio import prepare_foreground_playback
            prepare_foreground_playback()
            stream_url = self.client.create_link(channel_cmd)
            servicetype = _stalker_service_type()
            ref = eServiceReference(servicetype, 0, stream_url)
            ref.setName(str(channel_name))
            result = self.session.nav.playService(ref)
            if result is False and servicetype == 5002:
                fallback = eServiceReference(4097, 0, stream_url)
                fallback.setName(str(channel_name))
                self.session.nav.playService(fallback)
                servicetype = 4097
            self.playing_index = index
            self.playing_url = stream_url
            self.playing_service_type = int(servicetype)
            return True
        except Exception as e:
            self.session.open(MessageBox, "Unable to play channel:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=6)
            return False

    def play(self):
        cur = self["list"].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            return
        index = cur[1]
        if self.audio_only:
            self.start_ipaudio()
            return

        # First OK tunes the selected channel while the left browser remains visible.
        # Second OK on the already playing channel enters full-screen without restart.
        if self.playing_index != index:
            self._play_index(index)
            return

        try:
            self.hide()
            self.session.openWithCallback(self._player_closed, XKlass_Stalker_Player,
                                          self.client, self.channels, index, False,
                                          self.playing_url, self.playing_service_type)
        except Exception:
            try:
                self.show()
            except Exception:
                pass
            raise

    def _player_closed(self, index=None):
        try:
            self.show()
        except Exception:
            pass
        try:
            if index is not None and self.channels:
                self.playing_index = int(index) % len(self.channels)
                self["list"].setIndex(self.playing_index)
        except Exception:
            pass
