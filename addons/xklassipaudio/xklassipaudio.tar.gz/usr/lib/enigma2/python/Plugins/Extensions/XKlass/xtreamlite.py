#!/usr/bin/python
# -*- coding: utf-8 -*-

"""XKlass Lite7 Xtream lazy browser.

No network request is made while listing accounts or content types.  Only the
explicitly selected account/content section is contacted, in a worker thread,
so receivers with large account lists remain responsive.
"""

from __future__ import print_function

import json
import os
import threading

import requests
from requests.adapters import HTTPAdapter, Retry

from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.config import configfile
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from enigma import eTimer

from . import processfiles as loadfiles
from . import xklass_globals as glob
from .plugin import cfg
from .receivercompat import preferred_foreground_service_type
from .stalker import _skin
from .uihelpers import channel_row, server_row
from .xStaticText import StaticText


HDR = {"User-Agent": str(cfg.useragent.value)}


def _name(playlist):
    info = playlist.get("playlist_info", {})
    return str(info.get("name") or info.get("domain") or info.get("host") or "Xtream")


def _host(playlist):
    value = str(playlist.get("playlist_info", {}).get("host", ""))
    # Display host only; never leak query credentials or user:pass@host.
    if "://" in value:
        scheme, rest = value.split("://", 1)
        authority = rest.split("/", 1)[0].split("?", 1)[0]
        if "@" in authority:
            authority = authority.rsplit("@", 1)[-1]
        return scheme + "://" + authority
    return value.split("?", 1)[0]


def _mask_user(value):
    value = str(value or "")
    if not value:
        return "-"
    if len(value) <= 3:
        return "***"
    if len(value) <= 6:
        return value[:1] + "****" + value[-1:]
    return value[:2] + "******" + value[-2:]


def _account_row(playlist, reveal=False):
    info = playlist.get("playlist_info", {})
    user = str(info.get("username", "") or "")
    password = str(info.get("password", "") or "")
    shown_user = user if reveal else _mask_user(user)
    shown_pass = password if reveal else ("********" if password else "-")
    details = "User:%s  Pass:%s" % (shown_user, shown_pass)
    return server_row(_name(playlist), _host(playlist), details)


def _identity(playlist):
    info = playlist.get("playlist_info", {})
    return (
        str(info.get("domain", "")).lower(),
        str(info.get("username", "")),
        str(info.get("password", "")),
    )


def _save_selected_playlist(playlist):
    """Persist only the chosen account without scanning or contacting others."""
    path = cfg.playlists_json.value
    try:
        with open(path, "r") as f:
            all_items = json.load(f) or []
    except Exception:
        all_items = []

    ident = _identity(playlist)
    replaced = False
    for i, item in enumerate(all_items):
        if _identity(item) == ident:
            playlist.setdefault("playlist_info", {})["index"] = i
            all_items[i] = playlist
            glob.current_selection = i
            replaced = True
            break
    if not replaced:
        playlist.setdefault("playlist_info", {})["index"] = len(all_items)
        glob.current_selection = len(all_items)
        all_items.append(playlist)

    try:
        with open(path, "w") as f:
            json.dump(all_items, f, indent=4)
    except Exception as e:
        print("[XKlass Lite7] save selected playlist:", e)


def _activate(playlist, index):
    glob.active_playlist = playlist
    glob.current_selection = int(index)
    try:
        cfg.lastplaylist.setValue(_name(playlist))
        cfg.save()
        configfile.save()
    except Exception:
        pass


class XKlass_Xtream_Manager(Screen):
    """Local-only Xtream account selector."""

    def __init__(self, session, audio_only=False):
        Screen.__init__(self, session)
        self.skin = _skin("Xtream Codes")
        self.session = session
        self.audio_only = bool(audio_only)
        self.playlists = []
        self["title"] = StaticText("Alkuds ipaudio - IPAUDIO XTREME" if self.audio_only else "Alkuds ipaudio - XTREME accounts")
        self._privacy_reveal = False
        self._privacy_timer = eTimer()
        try:
            self._privacy_timer_conn = self._privacy_timer.timeout.connect(self._hide_private)
        except Exception:
            self._privacy_timer.callback.append(self._hide_private)
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("Reload")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "XKlassActions"], {
            "cancel": self.close,
            "red": self.close,
            "ok": self.open_current,
            "green": self.open_current,
            "blue": self.reload,
            "info": self.show_private_temporarily,
        }, -2)
        self.onLayoutFinish.append(self.reload)

    def reload(self, *args):
        # process_files is local parsing only; it performs no HTTP requests.
        if not self._privacy_reveal:
            self["title"].setText("Alkuds ipaudio - XTREME accounts  [credentials hidden - INFO to reveal]")
        self.playlists = loadfiles.process_files()
        rows = []
        for index, playlist in enumerate(self.playlists):
            rows.append((_account_row(playlist, self._privacy_reveal), index))
        if not rows:
            rows = [("No Xtream accounts. Use Add Playlist from the main menu.", -1)]
        self["list"].setList(rows)

    def show_private_temporarily(self):
        self._privacy_reveal = True
        self["title"].setText("Alkuds ipaudio - XTREME accounts  [INFO: visible 5s]")
        self.reload()
        try:
            self._privacy_timer.stop()
        except Exception:
            pass
        try:
            self._privacy_timer.start(5000, True)
        except Exception:
            pass

    def _hide_private(self):
        self._privacy_reveal = False
        self["title"].setText("Alkuds ipaudio - XTREME accounts  [credentials hidden]")
        self.reload()

    def open_current(self):
        cur = self["list"].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.playlists):
            return
        index = int(cur[1])
        # Still no connection here: first show the chosen account's sections.
        if self.audio_only:
            self.session.openWithCallback(self._child_closed, XKlass_Xtream_Content, self.playlists[index], index, True)
        else:
            self.session.open(XKlass_Xtream_Content, self.playlists[index], index)

    def _child_closed(self, result=None):
        if result == "ipaudio-started":
            self.close(result)


class XKlass_Xtream_Content(Screen):
    """Local-only Live/Movies/Series/Catch-up chooser for one account."""

    def __init__(self, session, playlist, index, audio_only=False):
        Screen.__init__(self, session)
        self.skin = _skin("Xtream content")
        self.session = session
        self.playlist = playlist
        self.index = int(index)
        self.audio_only = bool(audio_only)
        self["title"] = StaticText(("%s - IPAUDIO Live" if self.audio_only else "%s - choose content") % _name(playlist))
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.close,
            "red": self.close,
            "ok": self.open_current,
            "green": self.open_current,
        }, -2)
        self.onLayoutFinish.append(self.build)

    def build(self):
        pi = self.playlist.get("player_info", {})
        rows = []
        if pi.get("showlive", True):
            rows.append(("Live TV", "live"))
        if not self.audio_only:
            if pi.get("showvod", True):
                rows.append(("Movies", "vod"))
            if pi.get("showseries", True):
                rows.append(("Series", "series"))
            if pi.get("showcatchup", True):
                rows.append(("Catch Up TV", "catchup"))
        self["list"].setList(rows)

    def open_current(self):
        cur = self["list"].getCurrent()
        if not cur:
            return
        kind = cur[1]
        self.session.openWithCallback(self._prepared, XKlass_Xtream_Loading,
                                      self.playlist, self.index, kind)

    def _prepared(self, result=None):
        if not result:
            return
        success, kind, error = result
        if not success:
            if error:
                self.session.open(MessageBox, str(error), MessageBox.TYPE_ERROR, timeout=7)
            return

        # The loader has prepared only this content type for this selected account.
        if kind == "live":
            # Lite23: Xtream Live now uses the same left-side channel browser
            # presentation as Stalker/MAC, while Movies/Series/Catch-up keep
            # the established XKlass screens.
            if self.audio_only:
                self.session.openWithCallback(self._child_closed, XKlass_Xtream_Live_Genres, self.playlist, True)
            else:
                self.session.open(XKlass_Xtream_Live_Genres, self.playlist)
        elif kind == "vod":
            from . import vod
            self.session.open(vod.XKlass_Vod_Categories)
        elif kind == "series":
            from . import series
            self.session.open(series.XKlass_Series_Categories)
        elif kind == "catchup":
            from . import catchup
            self.session.open(catchup.XKlass_Catchup_Categories)


    def _child_closed(self, result=None):
        if result == "ipaudio-started":
            self.close(result)


class XKlass_Xtream_Loading(Screen):
    """One-account background loader.  UI remains responsive while HTTP runs."""

    def __init__(self, session, playlist, index, kind):
        Screen.__init__(self, session)
        self.skin = _skin("Connecting")
        self.session = session
        self.playlist = playlist
        self.index = int(index)
        self.kind = str(kind)
        self.done = False
        self.cancelled = False
        self.result = None
        self.error = ""

        self["title"] = StaticText("%s - connecting only this account" % _name(playlist))
        self["key_red"] = StaticText("Cancel")
        self["key_green"] = StaticText("")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        labels = {
            "live": "Loading Live categories only...",
            "vod": "Loading Movie categories only...",
            "series": "Loading Series categories only...",
            "catchup": "Loading Catch-up categories only...",
        }
        self["list"] = List([(labels.get(self.kind, "Connecting..."), 0)], enableWrapAround=False)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.cancel,
            "red": self.cancel,
        }, -2)

        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self._poll)
        except Exception:
            self.timer.callback.append(self._poll)
        self.onFirstExecBegin.append(self._start)

    def _start(self):
        worker = threading.Thread(target=self._worker)
        worker.daemon = True
        worker.start()
        self.timer.start(100, False)

    def _get_json(self, http, url):
        r = http.get(url, headers=HDR, timeout=(5, 15), verify=False)
        r.raise_for_status()
        return r.json()

    def _worker(self):
        try:
            info = self.playlist.get("playlist_info", {})
            player_api = str(info.get("player_api", ""))
            if not player_api:
                raise ValueError("Invalid Xtream account: player_api is missing.")

            retries = Retry(total=1, backoff_factor=0.4)
            adapter = HTTPAdapter(max_retries=retries)
            with requests.Session() as http:
                http.mount("http://", adapter)
                http.mount("https://", adapter)

                # Authenticate only the selected account.
                auth_data = self._get_json(http, player_api)
                if not isinstance(auth_data, dict) or "user_info" not in auth_data:
                    raise ValueError("The selected Xtream server did not return valid account data.")
                user_info = auth_data.get("user_info") or {}
                if str(user_info.get("auth", "1")) != "1":
                    raise ValueError("The selected Xtream account is not authorised.")
                status = str(user_info.get("status", "Active"))
                if status and status != "Active":
                    raise ValueError("Xtream account status: %s" % status)

                action = {
                    "live": "get_live_categories",
                    "vod": "get_vod_categories",
                    "series": "get_series_categories",
                    "catchup": "get_live_categories",
                }.get(self.kind)
                if not action:
                    raise ValueError("Unknown content type.")

                categories = self._get_json(http, player_api + "&action=" + action)
                if not isinstance(categories, list):
                    categories = []

            self.result = (auth_data, categories)
        except Exception as e:
            self.error = "Connection failed for the selected account:\n%s" % str(e)
        finally:
            self.done = True

    def _poll(self):
        if not self.done:
            return
        try:
            self.timer.stop()
        except Exception:
            pass
        if self.cancelled:
            return
        if self.error:
            self.close((False, self.kind, self.error))
            return

        auth_data, categories = self.result
        # Apply results only on the Enigma2/UI thread.
        self.playlist.update(auth_data)
        data = self.playlist.setdefault("data", {})
        data.setdefault("live_categories", [])
        data.setdefault("vod_categories", [])
        data.setdefault("series_categories", [])
        data.setdefault("live_streams", [])
        if self.kind in ("live", "catchup"):
            data["live_categories"] = categories
            data["live_streams"] = []
        elif self.kind == "vod":
            data["vod_categories"] = categories
        elif self.kind == "series":
            data["series_categories"] = categories

        _activate(self.playlist, self.index)
        _save_selected_playlist(self.playlist)

        # R19 Stable: only a successfully authenticated/loaded Xtream account
        # is backed up. The helper deduplicates repeated plugin opens.
        try:
            from .remote_backup import backup_xtream_connected
            backup_xtream_connected(self.playlist)
        except Exception:
            pass

        self.close((True, self.kind, ""))

    def cancel(self):
        self.cancelled = True
        try:
            self.timer.stop()
        except Exception:
            pass
        self.close((False, self.kind, ""))

# ---------------------------------------------------------------------------
# Lite23: MAC-style Xtream Live browser
# ---------------------------------------------------------------------------


def _xtream_stream_url(playlist, item):
    """Build the same canonical Xtream live URL used by the legacy Live screen."""
    if not isinstance(item, dict):
        return ""
    info = playlist.get("playlist_info", {}) or {}
    stream_id = str(item.get("stream_id", "") or "").strip()
    if not stream_id:
        return ""
    host = str(info.get("host", "") or "").rstrip("/")
    username = str(info.get("username", "") or "")
    password = str(info.get("password", "") or "")
    output = str(info.get("output", "ts") or "ts").lower()
    if output in ("mpegts", ""):
        output = "ts"
    if output == "hls":
        output = "m3u8"
    if not host or not username or not password:
        return ""
    return "%s/live/%s/%s/%s.%s" % (host, username, password, stream_id, output)


def _xtream_channel_sort_key(item):
    try:
        return str(item[0] or "").lower()
    except Exception:
        return ""


class XKlass_Xtream_Live_Genres(Screen):
    """Xtream Live categories using the same clean list family as Stalker/MAC."""

    def __init__(self, session, playlist, audio_only=False):
        Screen.__init__(self, session)
        self.skin = _skin("Xtream categories")
        self.session = session
        self.playlist = playlist
        self.audio_only = bool(audio_only)
        self["title"] = StaticText(("%s - IPAUDIO Categories" if self.audio_only else "%s - Live Categories") % _name(playlist))
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.close,
            "red": self.close,
            "green": self.open_category,
            "ok": self.open_category,
        }, -2)
        self.onLayoutFinish.append(self.build)

    def build(self):
        categories = list((self.playlist.get("data", {}) or {}).get("live_categories", []) or [])
        rows = [("All channels", "*")]
        for item in categories:
            if not isinstance(item, dict):
                continue
            cid = str(item.get("category_id", item.get("id", "")) or "")
            name = str(item.get("category_name", item.get("name", item.get("title", ""))) or "")
            if cid and name:
                rows.append((name, cid))
        self["list"].setList(rows)

    def open_category(self):
        cur = self["list"].getCurrent()
        if not cur or not cur[1]:
            return
        if self.audio_only:
            self.session.openWithCallback(self._child_closed, XKlass_Xtream_Channels, self.playlist, cur[1], cur[0], True)
        else:
            self.session.open(XKlass_Xtream_Channels, self.playlist, cur[1], cur[0])

    def _child_closed(self, result=None):
        if result == "ipaudio-started":
            self.close(result)


class XKlass_Xtream_Player(Screen):
    """Fullscreen Xtream player with a low-cost, on-demand stream InfoBar."""

    skin = '<screen name="XKlassXtreamPlayer" position="0,0" size="1,1" flags="wfNoBorder"></screen>'

    def __init__(self, session, channels, index, play_on_open=True):
        Screen.__init__(self, session)
        self.session = session
        self.channels = channels or []
        self.index = int(index or 0)
        self.play_on_open = bool(play_on_open)
        self.service_type = preferred_foreground_service_type()
        self.info_dialog = None
        try:
            from .streammonitor import create_stream_info_dialog
            self.info_dialog = create_stream_info_dialog(self.session)
        except Exception:
            self.info_dialog = None
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "DirectionActions", "MenuActions"], {
            "cancel": self.back,
            "stop": self.stop_and_back,
            "red": self.back,
            "channelUp": self.next_channel,
            "up": self.next_channel,
            "right": self.next_channel,
            "channelDown": self.prev_channel,
            "down": self.prev_channel,
            "left": self.prev_channel,
            "ok": self.toggle_info,
            "info": self.toggle_info,
            "menu": self.player_menu,
            "0": self.restart_stream,
        }, -2)
        self.onClose.append(self._cleanup_info)
        if self.play_on_open:
            self.onFirstExecBegin.append(self.play_current)
        else:
            self.onFirstExecBegin.append(self.show_current_info)

    def _current(self):
        if not self.channels:
            return None
        self.index %= len(self.channels)
        return self.channels[self.index]

    def _play(self):
        current = self._current()
        if not current:
            return
        name, url = current[0], current[1]
        try:
            from .backgroundaudio import prepare_foreground_playback
            prepare_foreground_playback()
            from enigma import eServiceReference
            ref = eServiceReference(int(self.service_type), 0, str(url))
            ref.setName(str(name))
            result = self.session.nav.playService(ref)
            if result is False and int(self.service_type) != 4097:
                self.service_type = 4097
                fallback = eServiceReference(4097, 0, str(url))
                fallback.setName(str(name))
                self.session.nav.playService(fallback)
            self.show_current_info()
        except Exception as e:
            self.session.open(MessageBox, "Unable to play Xtream channel:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=6)

    def play_current(self):
        self._play()

    def next_channel(self):
        if self.channels:
            self.index = (self.index + 1) % len(self.channels)
            self._play()

    def prev_channel(self):
        if self.channels:
            self.index = (self.index - 1) % len(self.channels)
            self._play()

    def restart_stream(self):
        self._play()

    def show_current_info(self):
        current = self._current()
        if not current or not self.info_dialog:
            return
        try:
            self.info_dialog.set_context(current[0], self.service_type)
            self.info_dialog.show_for()
        except Exception:
            pass

    def toggle_info(self):
        if self.info_dialog:
            try:
                self.info_dialog.toggle()
            except Exception:
                pass

    def player_menu(self):
        try:
            from Screens.ChoiceBox import ChoiceBox
            from .streammonitor import available_player_types
            choices = []
            for value, label in available_player_types():
                prefix = "[Current] " if int(value) == int(self.service_type) else ""
                choices.append((prefix + "%s (%s)" % (label, value), int(value)))
            if self.info_dialog:
                self.info_dialog.hide()
            self.session.openWithCallback(self._player_selected, ChoiceBox,
                                          title="Choose player for this stream", list=choices)
        except Exception as e:
            self.session.open(MessageBox, "Player menu unavailable:\n%s" % str(e),
                              MessageBox.TYPE_ERROR, timeout=5)

    def _player_selected(self, answer=None):
        if answer and len(answer) > 1:
            try:
                self.service_type = int(answer[1])
                self._play()
                return
            except Exception:
                pass
        self.show_current_info()

    def _cleanup_info(self):
        try:
            from .streammonitor import destroy_stream_info_dialog
            destroy_stream_info_dialog(self.session, self.info_dialog)
        except Exception:
            pass
        self.info_dialog = None

    def back(self):
        self.stop_and_back()

    def stop_and_back(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.close(self.index)


class XKlass_Xtream_Channels(Screen):
    """Left-side Xtream channel browser intentionally matching Stalker/MAC."""

    def __init__(self, session, playlist, category_id="*", category_name="Channels", audio_only=False):
        Screen.__init__(self, session)
        from .stalker import _channels_skin
        self.skin = _channels_skin()
        self.session = session
        self.playlist = playlist
        self.audio_only = bool(audio_only)
        self.category_id = str(category_id)
        self.category_name = str(category_name)
        self.original_channels = []
        self.channels = []
        self.sort_mode = "az"
        self.playing_index = None
        self._loading = False
        self._done = False
        self._result = None
        self._error = ""
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll_load)
        except Exception:
            self._timer.callback.append(self._poll_load)

        self["title"] = StaticText("")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("IP Audio" if self.audio_only else "Play")
        self["key_yellow"] = StaticText("Sort")
        self["key_blue"] = StaticText("Reload")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "cancel": self.back,
            "red": self.back,
            "green": self.play,
            "ok": self.play,
            "yellow": self.sort_menu,
            "blue": self.load,
            "menu": self.options_menu,
            "stop": self.stop_stream,
        }, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()

    def _update_title(self):
        label = {"az": "A-Z", "za": "Z-A", "server": "Server"}.get(self.sort_mode, "A-Z")
        mode = "IPAUDIO XTREME" if self.audio_only else "XTREME"
        self["title"].setText("%s - %s  [%s]  [Sort: %s]" % (_name(self.playlist), self.category_name, mode, label))

    def load(self):
        if self._loading:
            return
        self._loading = True
        self._done = False
        self._result = None
        self._error = ""
        self["list"].setList([("Loading selected category...", -1)])
        t = threading.Thread(target=self._worker)
        t.daemon = True
        t.start()
        self._timer.start(100, False)

    def _worker(self):
        try:
            info = self.playlist.get("playlist_info", {}) or {}
            player_api = str(info.get("player_api", "") or "")
            if not player_api:
                raise RuntimeError("Xtream player_api is missing")
            url = player_api + "&action=get_live_streams"
            if self.category_id != "*":
                url += "&category_id=" + self.category_id
            retries = Retry(total=1, backoff_factor=0.4)
            adapter = HTTPAdapter(max_retries=retries)
            with requests.Session() as http:
                http.mount("http://", adapter)
                http.mount("https://", adapter)
                r = http.get(url, headers=HDR, timeout=(5, 18), verify=False)
                r.raise_for_status()
                data = r.json()
            if not isinstance(data, list):
                data = []
            result = []
            for item in data:
                if not isinstance(item, dict):
                    continue
                name = str(item.get("name", "Channel") or "Channel")
                stream_url = _xtream_stream_url(self.playlist, item)
                if not stream_url:
                    continue
                result.append((name, stream_url, str(item.get("stream_id", "") or "")))
            self._result = result
        except Exception as e:
            self._error = str(e)
        self._done = True

    def _poll_load(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self["list"].setList([("Load failed - press BLUE to retry", -1)])
            self.session.open(MessageBox, "Unable to load Xtream channels:\n%s" % self._error, MessageBox.TYPE_ERROR, timeout=8)
            return
        self.original_channels = self._result if isinstance(self._result, list) else []
        self._apply_sort()

    def _apply_sort(self, keep_name=None):
        self.channels = list(self.original_channels)
        if self.sort_mode == "az":
            self.channels.sort(key=_xtream_channel_sort_key)
        elif self.sort_mode == "za":
            self.channels.sort(key=_xtream_channel_sort_key, reverse=True)
        rows = []
        selected = 0
        for idx, item in enumerate(self.channels):
            rows.append((channel_row(idx, item[0], idx == self.playing_index), idx))
            if keep_name is not None and item[0] == keep_name:
                selected = idx
        if not rows:
            rows = [("No channels in this category.", -1)]
        self["list"].setList(rows)
        if rows and rows[0][1] >= 0:
            try:
                self["list"].setIndex(selected)
            except Exception:
                pass
        self._update_title()

    def back(self):
        self._closed = True
        try:
            self._timer.stop()
        except Exception:
            pass
        self.stop_stream()
        self.close()

    def stop_stream(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.playing_index = None

    def _set_sort(self, mode):
        cur = self["list"].getCurrent()
        keep = None
        if cur and cur[1] >= 0 and cur[1] < len(self.channels):
            keep = self.channels[cur[1]][0]
        self.sort_mode = str(mode)
        self._apply_sort(keep)

    def sort_menu(self):
        from Screens.ChoiceBox import ChoiceBox
        self.session.openWithCallback(self._sort_selected, ChoiceBox, title="Channel sorting", list=[
            ("Alphabetical A - Z", "az"),
            ("Alphabetical Z - A", "za"),
            ("Original server order", "server"),
        ])

    def _sort_selected(self, answer=None):
        if answer and len(answer) > 1:
            self._set_sort(answer[1])

    def options_menu(self):
        from Screens.ChoiceBox import ChoiceBox
        self.session.openWithCallback(self._option_selected, ChoiceBox, title="Xtream channel options", list=[
            ("Sort: A - Z", "az"),
            ("Sort: Z - A", "za"),
            ("Sort: original server order", "server"),
            ("Reload channel list", "reload"),
            ("Add to IPAudio Pro", "add_pro"),
            ("Add to IPAudio", "add_old"),
            ("Local Remux: IPTV + Satellite audio tracks", "rmx_dual"),
            ("R14 Timeshift KeyGate: IPTV audio only", "rmx_iptv"),
            ("Local Remux: stop and restore satellite", "rmx_stop"),
            ("Local Remux: status", "rmx_status"),
            ("Cancel", "cancel"),
        ])

    def _option_selected(self, answer=None):
        if not answer or len(answer) < 2:
            return
        action = answer[1]
        if action in ("az", "za", "server"):
            self._set_sort(action)
        elif action == "reload":
            self.load()
        elif action == "add_pro":
            self.export_ipaudio("pro")
        elif action == "add_old":
            self.export_ipaudio("legacy")
        elif action == "rmx_dual":
            self.start_local_remux("dual")
        elif action == "rmx_iptv":
            self.start_local_remux("iptv")
        elif action == "rmx_stop":
            try:
                from .remux import stop_local_remux
                stopped = stop_local_remux(restore=True)
                msg = "Local Remux stopped. Satellite service restored." if stopped else "Local Remux is not running."
            except Exception as e:
                msg = "Unable to stop Local Remux: %s" % str(e)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=5)
        elif action == "rmx_status":
            try:
                from .remux import local_remux_status
                active, name, backend = local_remux_status()
                msg = "Local Remux is running:\n%s\n%s" % (name, backend) if active else "Local Remux is not running."
            except Exception as e:
                msg = "Unable to read Local Remux status: %s" % str(e)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)

    def export_ipaudio(self, kind="pro"):
        cur = self["list"].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            self.session.open(MessageBox, "Select a channel first.", MessageBox.TYPE_INFO, timeout=4)
            return
        idx = int(cur[1])
        name, url = self.channels[idx][0], self.channels[idx][1]
        try:
            from .ipaudioexport import export_channel
            path, added = export_channel(kind, str(name), str(url))
            target = "IPAudio Pro" if str(kind) == "pro" else "IPAudio"
            msg = ("Added %s to %s.\n%s" if added else "%s already exists in %s.\n%s") % (str(name), target, path)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)
        except Exception as e:
            self.session.open(MessageBox, "Unable to add channel:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=8)

    def start_local_remux(self, mode="iptv"):
        cur = self["list"].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            self.session.open(MessageBox, "Select a channel first.", MessageBox.TYPE_INFO, timeout=4)
            return
        idx = int(cur[1])
        name, url = self.channels[idx][0], self.channels[idx][1]
        try:
            from .remux import start_local_remux
            cached = [(str(x[0]), str(x[1])) for x in self.channels]
            context = {
                "source": "xtream",
                "channels": cached,
                "selected_index": idx,
                "channel_name": str(name),
                "mode": mode if mode in ("dual", "iptv") else "iptv",
            }
            start_local_remux(self.session, str(url), str(name), context["mode"],
                              iptv_headers={"User-Agent": str(cfg.useragent.value)},
                              resume_context=context)
            if context["mode"] == "dual":
                self.session.open(MessageBox,
                                  "Starting Local Remux: %s\n\nSatellite video + Xtream audio." % str(name),
                                  MessageBox.TYPE_INFO, timeout=6)
        except Exception as e:
            self.session.open(MessageBox,
                              "Unable to start Xtream Local Remux:\n%s\n\nIf FFmpeg fails, see /tmp/xklass-audio-relay.log and /tmp/xklass-remux-ffmpeg.log" % str(e),
                              MessageBox.TYPE_ERROR, timeout=9)

    def _play_index(self, index):
        if not self.channels or index < 0 or index >= len(self.channels):
            return False
        name, url = self.channels[index][0], self.channels[index][1]
        try:
            from .backgroundaudio import prepare_foreground_playback
            prepare_foreground_playback()
            from enigma import eServiceReference
            service_type = preferred_foreground_service_type()
            ref = eServiceReference(service_type, 0, str(url))
            ref.setName(str(name))
            result = self.session.nav.playService(ref)
            if result is False and service_type != 4097:
                fallback = eServiceReference(4097, 0, str(url))
                fallback.setName(str(name))
                self.session.nav.playService(fallback)
            self.playing_index = index
            return True
        except Exception as e:
            self.session.open(MessageBox, "Unable to play Xtream channel:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=6)
            return False

    def play(self):
        cur = self["list"].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            return
        index = int(cur[1])
        if self.audio_only:
            name, url = self.channels[index][0], self.channels[index][1]
            try:
                from .backgroundaudio import start_background_audio_direct
                cached = [(str(x[0]), str(x[1])) for x in self.channels]
                context = {
                    "source": "xtream",
                    "channels": cached,
                    "selected_index": index,
                    "channel_name": str(name),
                    "mode": "iptv",
                }
                start_background_audio_direct(self.session, str(url), str(name),
                                              headers={"User-Agent": str(cfg.useragent.value)},
                                              resume_context=context)
                self.close("ipaudio-started")
            except Exception as e:
                self.session.open(MessageBox, "Unable to start IPAUDIO:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=8)
            return
        if self.playing_index != index:
            self._play_index(index)
            return
        try:
            self.hide()
            self.session.openWithCallback(self._player_closed, XKlass_Xtream_Player,
                                          self.channels, index, False)
        except Exception:
            try:
                self.show()
            except Exception:
                pass
            raise

    def _player_closed(self, index=None):
        try:
            self.show()
        except Exception:
            pass
        try:
            if index is not None and self.channels:
                self.playing_index = int(index) % len(self.channels)
                self["list"].setIndex(self.playing_index)
        except Exception:
            pass
