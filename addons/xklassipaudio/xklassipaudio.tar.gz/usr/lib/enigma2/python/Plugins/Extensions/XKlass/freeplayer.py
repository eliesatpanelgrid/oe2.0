#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Small, self-contained player for Free Arabic TV."""

from __future__ import absolute_import, print_function

import os
import subprocess
import time

try:
    import cPickle as pickle
except ImportError:
    import pickle

from Components.ActionMap import ActionMap
from Components.ServiceEventTracker import ServiceEventTracker
from enigma import eServiceReference, eTimer, getDesktop, iPlayableService, iServiceInformation
from Screens.ChoiceBox import ChoiceBox
from Screens.Screen import Screen

from .receivercompat import set_selected_free_service_type
from .xStaticText import StaticText


RESUME_FILE = "/etc/enigma2/xklass/free_entertainment_resume.pkl"


def _load_resume_points():
    try:
        with open(RESUME_FILE, "rb") as handle:
            data = pickle.load(handle)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_resume_points(points):
    try:
        folder = os.path.dirname(RESUME_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = RESUME_FILE + ".tmp"
        with open(temporary, "wb") as handle:
            pickle.dump(points, handle, pickle.HIGHEST_PROTOCOL)
        os.rename(temporary, RESUME_FILE)
    except Exception:
        pass


def _player_skin():
    size = getDesktop(0).size()
    width = size.width()
    height = size.height()
    bar_h = 190 if height >= 1080 else 132
    title_font = 34 if width >= 1920 else 27 if width > 1280 else 24
    body_font = max(19, title_font - 6)
    y = height - bar_h
    return '''<screen name="XKlassFreeTVPlayer" position="0,0" size="%d,%d" backgroundColor="#ff000000" flags="wfNoBorder">
        <eLabel position="0,%d" size="%d,%d" backgroundColor="#30101b32" zPosition="1" />
        <widget source="name" render="Label" position="36,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#30101b32" valign="center" noWrap="1" transparent="0" zPosition="2" />
        <widget source="status" render="Label" position="36,%d" size="%d,%d" font="Regular;%d" foregroundColor="#7dff91" backgroundColor="#30101b32" valign="center" noWrap="1" transparent="0" zPosition="2" />
        <widget source="details" render="Label" position="36,%d" size="%d,%d" font="Regular;%d" foregroundColor="#c8d6ef" backgroundColor="#30101b32" valign="center" noWrap="1" transparent="0" zPosition="2" />
    </screen>''' % (
        width, height, y, width, bar_h,
        y + 10, width - 72, int(bar_h * .36), title_font,
        y + int(bar_h * .38), width - 72, int(bar_h * .28), body_font,
        y + int(bar_h * .68), width - 72, int(bar_h * .24), body_font)


class XKlass_FreeTV_Player(Screen):
    """Plain Screen avoids receiver-specific teardown crashes from PVR mixins."""

    ALLOW_SUSPEND = True

    def __init__(self, session, streamurls, servicetype, name,
                 category="Live", description="", image="", resume_key=""):
        Screen.__init__(self, session)
        self.skin = _player_skin()
        self.session = session
        self.streamurls = list(streamurls or [])
        self.servicetype = int(servicetype)
        self.name = str(name or "Channel")
        self.category = str(category or "Live")
        self.description = str(description or "")
        self.resume_key = str(resume_key or "")
        self.streamurl = self.streamurls[0] if self.streamurls else ""
        self._closed = False
        self._confirmed = False
        self._failed = False
        self._playback_stopped = False
        self._started_attempts = False
        self._attempt_index = -1
        self._attempts = []
        self._bar_visible = True
        self._resume_applied = False
        self._resume_target = 0
        self._speed_mbps = 0.0
        self._last_rx = self._network_rx_bytes()
        self._last_rx_time = time.time()
        self._attempt_started_at = 0.0
        self._attempt_data_ticks = 0
        if self.category.lower() != "live" and self.resume_key:
            try:
                self._resume_target = int((_load_resume_points().get(self.resume_key) or [0])[0])
            except Exception:
                self._resume_target = 0
        for streamurl in self.streamurls:
            # The player is chosen manually from MENU. Never switch 5002,
            # 5001 and 4097 behind the user's back; only try another URL with
            # the same selected player when one was explicitly supplied.
            if (streamurl, self.servicetype) not in self._attempts:
                self._attempts.append((streamurl, self.servicetype))

        self["name"] = StaticText(self.name)
        self["status"] = StaticText("Connecting to stream...")
        self["details"] = StaticText(self._details_text())

        self._attempt_timer = eTimer()
        try:
            self._attempt_timer_conn = self._attempt_timer.timeout.connect(self._attempt_timeout)
        except Exception:
            self._attempt_timer.callback.append(self._attempt_timeout)
        self._resume_timer = eTimer()
        try:
            self._resume_timer_conn = self._resume_timer.timeout.connect(self._resume_tick)
        except Exception:
            self._resume_timer.callback.append(self._resume_tick)
        self._status_timer = eTimer()
        try:
            self._status_timer_conn = self._status_timer.timeout.connect(self._status_tick)
        except Exception:
            self._status_timer.callback.append(self._status_tick)
        self._close_timer = eTimer()
        try:
            self._close_timer_conn = self._close_timer.timeout.connect(self._close_after_stop)
        except Exception:
            self._close_timer.callback.append(self._close_after_stop)
        self._pending_result = None

        eventmap = {}
        for event_name, callback in (
                ("evStart", self._service_started),
                ("evUpdatedInfo", self._service_updated),
                ("evVideoSizeChanged", self._video_ready),
                ("evTuneFailed", self._service_failed),
                ("evEOF", self._service_failed)):
            event = getattr(iPlayableService, event_name, None)
            if event is not None:
                eventmap[event] = callback
        self._service_tracker = ServiceEventTracker(screen=self, eventmap=eventmap)

        self["actions"] = ActionMap([
            "XKlassActions", "OkCancelActions", "DirectionActions", "InfobarSeekActions"], {
            "cancel": self.back,
            "red": self.back,
            "stop": self.stopPlayback,
            "menu": self.choose_player,
            "ok": self.toggle_info,
            "info": self.toggle_info,
            "up": self.nextChannel,
            "channelUp": self.nextChannel,
            "down": self.prevChannel,
            "channelDown": self.prevChannel,
            "left": self.seek_back,
            "right": self.seek_forward,
            "seekBack": self.seek_back,
            "seekFwd": self.seek_forward,
            "seekBackManual": self.seek_back,
            "seekFwdManual": self.seek_forward,
        }, -2)
        self.onFirstExecBegin.append(self.playStream)
        self.onFirstExecBegin.append(lambda: self._status_timer.start(1000, False))
        self.onClose.append(self._cleanup)

    def choose_player(self):
        current = int(self.servicetype)
        choices = [
            ((u"✓ " if current == 5002 else u"") + u"ExtePlayer3 (5002)", 5002),
            ((u"✓ " if current == 5001 else u"") + u"GStreamer (5001)", 5001),
            ((u"✓ " if current == 4097 else u"") + u"IPTV الأصلي (4097)", 4097),
        ]
        self.session.openWithCallback(
            self._player_chosen, ChoiceBox,
            title=u"اختر المشغل الثابت", list=choices)

    def _player_chosen(self, choice):
        if not choice:
            return
        selected = int(choice[1])
        set_selected_free_service_type(selected)
        if selected == self.servicetype:
            self._set_status("Player %d is already selected." % selected)
            return
        old_type = self.servicetype
        try:
            self._attempt_timer.stop()
            self.session.nav.stopService()
        except Exception:
            pass
        if old_type == 5002:
            try:
                with open(os.devnull, "wb") as sink:
                    subprocess.call(["killall", "-TERM", "exteplayer3"], stdout=sink, stderr=sink)
            except Exception:
                pass
        self.servicetype = selected
        self._attempts = [(url, selected) for url in self.streamurls]
        self._attempt_index = -1
        self._failed = False
        self._confirmed = False
        self._playback_stopped = True
        self._try_next()

    def _network_rx_bytes(self):
        """Best available live throughput counter on receiver images."""
        total = 0
        try:
            with open("/proc/net/dev", "r") as handle:
                for line in handle:
                    if ":" not in line:
                        continue
                    interface, values = line.split(":", 1)
                    if interface.strip() == "lo":
                        continue
                    fields = values.split()
                    if fields:
                        total += int(fields[0])
        except Exception:
            pass
        return total

    def _service_info_value(self, *names):
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if not info:
                return 0
            for name in names:
                key = getattr(iServiceInformation, name, None)
                if key is not None:
                    value = int(info.getInfo(key))
                    if value > 0:
                        return value
        except Exception:
            pass
        return 0

    def _details_text(self):
        clean_url = str(self.streamurl or "").split("#", 1)[0]
        extension = os.path.splitext(clean_url)[-1].split("?", 1)[0].lstrip(".") or "stream"
        width, height = self._stream_dimensions()
        resolution = "%dx%d" % (width, height) if width and height else "detecting resolution"
        frame_rate = self._service_info_value("sFrameRate")
        if frame_rate > 1000:
            frame_rate = int(round(frame_rate / 1000.0))
        bitrate = self._service_info_value("sVideoBitrate", "sBitrate")
        if bitrate > 10000:
            speed = bitrate / 1000000.0
        else:
            speed = self._speed_mbps
        text = "%s  •  Player %s  •  %s  •  %s  •  %.2f Mbps" % (
            self.category, self.servicetype, extension[:8].upper(), resolution, speed)
        if frame_rate:
            text += "  •  %d fps" % frame_rate
        if self.description:
            text += "  •  " + self.description
        return text

    def _status_tick(self):
        if self._closed:
            return
        now = time.time()
        received = self._network_rx_bytes()
        elapsed = max(0.001, now - self._last_rx_time)
        delta = received - self._last_rx if received >= self._last_rx else 0
        if delta >= 0:
            self._speed_mbps = (delta * 8.0) / elapsed / 1000000.0
        self._last_rx = received
        self._last_rx_time = now
        if self._started_attempts and not self._confirmed and delta >= 8192:
            self._attempt_data_ticks += 1
            self._set_status("Buffering stream... data is being received.")
            # Some Enigma2 images never emit video-size events for ServiceApp
            # even though playback has started. Sustained traffic is enough to
            # keep that stream instead of falsely switching/marking it offline.
            if self._attempt_data_ticks >= 3:
                self._mark_ready()
                return
        elif not self._confirmed:
            self._attempt_data_ticks = max(0, self._attempt_data_ticks - 1)
        self["details"].setText(self._details_text())

    def _set_status(self, value):
        if self._closed:
            return
        self["status"].setText(str(value or ""))
        self["details"].setText(self._details_text())

    def playStream(self):
        try:
            from .backgroundaudio import prepare_foreground_playback
            prepare_foreground_playback()
        except Exception:
            pass
        self._started_attempts = True
        self._try_next()

    def _try_next(self):
        if self._closed:
            return
        try:
            self._attempt_timer.stop()
        except Exception:
            pass
        self._confirmed = False
        self._attempt_index += 1
        if self._attempt_index >= len(self._attempts):
            self._failed = True
            self._set_status("Stream is offline or not responding.")
            try:
                self.session.nav.stopService()
                self._playback_stopped = True
            except Exception:
                pass
            return
        self.streamurl, service_type = self._attempts[self._attempt_index]
        self.servicetype = int(service_type)
        self._attempt_started_at = time.time()
        self._attempt_data_ticks = 0
        self._last_rx = self._network_rx_bytes()
        self._last_rx_time = self._attempt_started_at
        self._set_status("Connecting to stream...")
        try:
            reference = eServiceReference(self.servicetype, 0, self.streamurl)
            reference.setName(self.name)
            if self.session.nav.playService(reference) is False:
                self._try_next()
                return
            self._playback_stopped = False
            self._attempt_timer.start(15000, True)
        except Exception:
            self._try_next()

    def _service_started(self):
        if self._started_attempts and not self._confirmed:
            self._set_status("Buffering stream...")

    def _stream_dimensions(self):
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            width = int(info.getInfo(iServiceInformation.sVideoWidth)) if info else 0
            height = int(info.getInfo(iServiceInformation.sVideoHeight)) if info else 0
            return max(0, width), max(0, height)
        except Exception:
            return 0, 0

    def _service_updated(self):
        width, height = self._stream_dimensions()
        if width > 0:
            self._mark_ready(width, height)

    def _video_ready(self):
        width, height = self._stream_dimensions()
        self._mark_ready(width, height)

    def _mark_ready(self, width=0, height=0):
        if self._closed:
            return
        self._confirmed = True
        try:
            self._attempt_timer.stop()
        except Exception:
            pass
        resolution = " %dx%d" % (width, height) if width and height else ""
        self._set_status("Stream is working.%s" % resolution)
        self._apply_resume()
        if self.category.lower() != "live":
            try:
                self._resume_timer.start(30000, False)
            except Exception:
                pass

    def _service_failed(self):
        if self._started_attempts and not self._closed:
            self._try_next()

    def _attempt_timeout(self):
        if self._closed or self._confirmed:
            return
        if self._attempt_data_ticks and time.time() - self._attempt_started_at < 45:
            self._set_status("Buffering stream... waiting for video.")
            self._attempt_timer.start(10000, True)
            return
        self._try_next()

    def toggle_info(self):
        if self._bar_visible:
            self.hide()
        else:
            self.show()
        self._bar_visible = not self._bar_visible

    def nextChannel(self):
        if self.category.lower() == "live":
            self._finish("next", force_stop=True)

    def prevChannel(self):
        if self.category.lower() == "live":
            self._finish("prev", force_stop=True)

    def _seekable(self):
        try:
            service = self.session.nav.getCurrentService()
            return service and service.seek()
        except Exception:
            return None

    def _seek_relative(self, direction):
        if self.category.lower() == "live" or self._closed:
            return
        seekable = self._seekable()
        if not seekable:
            self._set_status("Seeking is not supported by this server.")
            return
        try:
            seekable.seekRelative(1 if direction > 0 else -1, 60 * 90000)
            self._set_status("Forward 60 seconds." if direction > 0 else "Back 60 seconds.")
            self._save_resume()
        except Exception:
            self._set_status("Seeking is not supported by this server.")

    def seek_forward(self):
        self._seek_relative(1)

    def seek_back(self):
        self._seek_relative(-1)

    def _apply_resume(self):
        if self._resume_applied or self._resume_target < 30 * 90000:
            return
        seekable = self._seekable()
        if not seekable:
            return
        try:
            seekable.seekTo(self._resume_target)
            self._resume_applied = True
            seconds = self._resume_target // 90000
            self._set_status("Resumed at %02d:%02d:%02d." % (
                seconds // 3600, (seconds % 3600) // 60, seconds % 60))
        except Exception:
            pass

    def _resume_tick(self):
        if not self._closed:
            self._save_resume()

    def _save_resume(self):
        if self.category.lower() == "live" or not self.resume_key or self._failed:
            return
        seekable = self._seekable()
        if not seekable:
            return
        try:
            position = seekable.getPlayPosition()
            if not position or position[0] or int(position[1]) < 10 * 90000:
                return
            current = int(position[1])
            length_result = seekable.getLength()
            length = int(length_result[1]) if length_result and not length_result[0] else 0
            points = _load_resume_points()
            if length and current >= max(0, length - 90 * 90000):
                points.pop(self.resume_key, None)
            else:
                points[self.resume_key] = [current, length, int(time.time())]
            if len(points) > 300:
                ordered = sorted(points.items(), key=lambda pair: pair[1][2] if len(pair[1]) > 2 else 0)
                points = dict(ordered[-300:])
            _write_resume_points(points)
        except Exception:
            pass

    def stopPlayback(self):
        self._finish("stopped", force_stop=True)

    def back(self):
        action = "failed" if self._failed else "back"
        # A live ServiceApp/ExtePlayer3 process must be stopped before another
        # server is selected. Leaving it alive caused the second stream to
        # deadlock the receiver.
        self._finish(action, force_stop=True)

    def _finish(self, action, force_stop=False):
        if self._closed:
            return
        self._save_resume()
        result = (str(action), "working" if self._confirmed else "offline")
        self._closed = True
        self._cleanup()
        if force_stop and not self._playback_stopped:
            try:
                self.session.nav.stopService()
                self._playback_stopped = True
            except Exception:
                pass
        if any(service_type == 5002 for _url, service_type in self._attempts):
            try:
                with open(os.devnull, "wb") as sink:
                    subprocess.call(["killall", "-TERM", "exteplayer3"], stdout=sink, stderr=sink)
            except Exception:
                pass
        self._pending_result = result if self.category.lower() == "live" else None
        try:
            self._close_timer.start(450, True)
        except Exception:
            self._close_after_stop()

    def _close_after_stop(self):
        try:
            self._close_timer.stop()
        except Exception:
            pass
        if self.category.lower() == "live":
            self.close(self._pending_result)
        else:
            self.close()

    def _cleanup(self):
        if not self._closed:
            self._save_resume()
        try:
            self._attempt_timer.stop()
        except Exception:
            pass
        try:
            self._resume_timer.stop()
        except Exception:
            pass
        try:
            self._status_timer.stop()
        except Exception:
            pass
        # Also cover unexpected screen destruction (GUI restart/close path),
        # not only the normal Back action.
        if not self._playback_stopped:
            try:
                self.session.nav.stopService()
                self._playback_stopped = True
            except Exception:
                pass
