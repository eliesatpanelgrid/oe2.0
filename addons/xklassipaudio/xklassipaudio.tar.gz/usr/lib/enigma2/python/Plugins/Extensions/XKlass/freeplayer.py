#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Small, self-contained player for Free Arabic TV."""

from __future__ import absolute_import, print_function

import os
import time

try:
    import cPickle as pickle
except ImportError:
    import pickle

from Components.ActionMap import ActionMap
from Components.ServiceEventTracker import ServiceEventTracker
from enigma import eServiceReference, eTimer, getDesktop, iPlayableService, iServiceInformation
from Screens.Screen import Screen

from .xStaticText import StaticText


RESUME_FILE = "/etc/enigma2/xklass/free_entertainment_resume.pkl"


def _load_resume_points():
    try:
        with open(RESUME_FILE, "rb") as handle:
            data = pickle.load(handle)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_resume_points(points):
    try:
        folder = os.path.dirname(RESUME_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = RESUME_FILE + ".tmp"
        with open(temporary, "wb") as handle:
            pickle.dump(points, handle, pickle.HIGHEST_PROTOCOL)
        os.rename(temporary, RESUME_FILE)
    except Exception:
        pass


def _player_skin():
    size = getDesktop(0).size()
    width = size.width()
    height = size.height()
    bar_h = 190 if height >= 1080 else 132
    title_font = 34 if width >= 1920 else 27 if width > 1280 else 24
    body_font = max(19, title_font - 6)
    y = height - bar_h
    return '''<screen name="XKlassFreeTVPlayer" position="0,0" size="%d,%d" backgroundColor="#ff000000" flags="wfNoBorder">
        <eLabel position="0,%d" size="%d,%d" backgroundColor="#30101b32" zPosition="1" />
        <widget source="name" render="Label" position="36,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#30101b32" valign="center" noWrap="1" transparent="0" zPosition="2" />
        <widget source="status" render="Label" position="36,%d" size="%d,%d" font="Regular;%d" foregroundColor="#7dff91" backgroundColor="#30101b32" valign="center" noWrap="1" transparent="0" zPosition="2" />
        <widget source="details" render="Label" position="36,%d" size="%d,%d" font="Regular;%d" foregroundColor="#c8d6ef" backgroundColor="#30101b32" valign="center" noWrap="1" transparent="0" zPosition="2" />
    </screen>''' % (
        width, height, y, width, bar_h,
        y + 10, width - 72, int(bar_h * .36), title_font,
        y + int(bar_h * .38), width - 72, int(bar_h * .28), body_font,
        y + int(bar_h * .68), width - 72, int(bar_h * .24), body_font)


class XKlass_FreeTV_Player(Screen):
    """Plain Screen avoids receiver-specific teardown crashes from PVR mixins."""

    ALLOW_SUSPEND = True

    def __init__(self, session, streamurls, servicetype, name,
                 category="Live", description="", image="", resume_key=""):
        Screen.__init__(self, session)
        self.skin = _player_skin()
        self.session = session
        self.streamurls = list(streamurls or [])
        self.servicetype = int(servicetype)
        self.name = str(name or "Channel")
        self.category = str(category or "Live")
        self.description = str(description or "")
        self.resume_key = str(resume_key or "")
        self.streamurl = self.streamurls[0] if self.streamurls else ""
        self._closed = False
        self._confirmed = False
        self._failed = False
        self._playback_stopped = False
        self._started_attempts = False
        self._attempt_index = -1
        self._attempts = []
        self._bar_visible = True
        self._resume_applied = False
        self._resume_target = 0
        if self.category.lower() != "live" and self.resume_key:
            try:
                self._resume_target = int((_load_resume_points().get(self.resume_key) or [0])[0])
            except Exception:
                self._resume_target = 0
        for streamurl in self.streamurls:
            self._attempts.append((streamurl, self.servicetype))
            if self.servicetype != 4097:
                self._attempts.append((streamurl, 4097))

        self["name"] = StaticText(self.name)
        self["status"] = StaticText("Connecting to stream...")
        self["details"] = StaticText(self._details_text())

        self._attempt_timer = eTimer()
        try:
            self._attempt_timer_conn = self._attempt_timer.timeout.connect(self._attempt_timeout)
        except Exception:
            self._attempt_timer.callback.append(self._attempt_timeout)
        self._resume_timer = eTimer()
        try:
            self._resume_timer_conn = self._resume_timer.timeout.connect(self._resume_tick)
        except Exception:
            self._resume_timer.callback.append(self._resume_tick)

        eventmap = {}
        for event_name, callback in (
                ("evStart", self._service_started),
                ("evUpdatedInfo", self._service_updated),
                ("evVideoSizeChanged", self._video_ready),
                ("evTuneFailed", self._service_failed),
                ("evEOF", self._service_failed)):
            event = getattr(iPlayableService, event_name, None)
            if event is not None:
                eventmap[event] = callback
        self._service_tracker = ServiceEventTracker(screen=self, eventmap=eventmap)

        self["actions"] = ActionMap([
            "XKlassActions", "OkCancelActions", "DirectionActions", "InfobarSeekActions"], {
            "cancel": self.back,
            "red": self.back,
            "stop": self.stopPlayback,
            "ok": self.toggle_info,
            "info": self.toggle_info,
            "up": self.nextChannel,
            "channelUp": self.nextChannel,
            "down": self.prevChannel,
            "channelDown": self.prevChannel,
            "left": self.seek_back,
            "right": self.seek_forward,
            "seekBack": self.seek_back,
            "seekFwd": self.seek_forward,
            "seekBackManual": self.seek_back,
            "seekFwdManual": self.seek_forward,
        }, -2)
        self.onFirstExecBegin.append(self.playStream)
        self.onClose.append(self._cleanup)

    def _details_text(self):
        clean_url = str(self.streamurl or "").split("#", 1)[0]
        extension = os.path.splitext(clean_url)[-1].split("?", 1)[0].lstrip(".") or "stream"
        text = "%s  •  Player %s  •  %s" % (self.category, self.servicetype, extension[:8])
        if self.description:
            text += "  •  " + self.description
        return text

    def _set_status(self, value):
        if self._closed:
            return
        self["status"].setText(str(value or ""))
        self["details"].setText(self._details_text())

    def playStream(self):
        try:
            from .backgroundaudio import prepare_foreground_playback
            prepare_foreground_playback()
        except Exception:
            pass
        self._started_attempts = True
        self._try_next()

    def _try_next(self):
        if self._closed:
            return
        try:
            self._attempt_timer.stop()
        except Exception:
            pass
        self._confirmed = False
        self._attempt_index += 1
        if self._attempt_index >= len(self._attempts):
            self._failed = True
            self._set_status("Stream is offline or not responding.")
            try:
                self.session.nav.stopService()
                self._playback_stopped = True
            except Exception:
                pass
            return
        self.streamurl, service_type = self._attempts[self._attempt_index]
        self.servicetype = int(service_type)
        self._set_status("Connecting to stream...")
        try:
            reference = eServiceReference(self.servicetype, 0, self.streamurl)
            reference.setName(self.name)
            if self.session.nav.playService(reference) is False:
                self._try_next()
                return
            self._playback_stopped = False
            self._attempt_timer.start(10000, True)
        except Exception:
            self._try_next()

    def _service_started(self):
        if self._started_attempts and not self._confirmed:
            self._set_status("Buffering stream...")

    def _stream_dimensions(self):
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            width = int(info.getInfo(iServiceInformation.sVideoWidth)) if info else 0
            height = int(info.getInfo(iServiceInformation.sVideoHeight)) if info else 0
            return max(0, width), max(0, height)
        except Exception:
            return 0, 0

    def _service_updated(self):
        width, height = self._stream_dimensions()
        if width > 0:
            self._mark_ready(width, height)

    def _video_ready(self):
        width, height = self._stream_dimensions()
        self._mark_ready(width, height)

    def _mark_ready(self, width=0, height=0):
        if self._closed:
            return
        self._confirmed = True
        try:
            self._attempt_timer.stop()
        except Exception:
            pass
        resolution = " %dx%d" % (width, height) if width and height else ""
        self._set_status("Stream is working.%s" % resolution)
        self._apply_resume()
        if self.category.lower() != "live":
            try:
                self._resume_timer.start(30000, False)
            except Exception:
                pass

    def _service_failed(self):
        if self._started_attempts and not self._closed:
            self._try_next()

    def _attempt_timeout(self):
        if not self._closed and not self._confirmed:
            self._try_next()

    def toggle_info(self):
        if self._bar_visible:
            self.hide()
        else:
            self.show()
        self._bar_visible = not self._bar_visible

    def nextChannel(self):
        if self.category.lower() == "live":
            self._finish("next", force_stop=False)

    def prevChannel(self):
        if self.category.lower() == "live":
            self._finish("prev", force_stop=False)

    def _seekable(self):
        try:
            service = self.session.nav.getCurrentService()
            return service and service.seek()
        except Exception:
            return None

    def _seek_relative(self, direction):
        if self.category.lower() == "live" or self._closed:
            return
        seekable = self._seekable()
        if not seekable:
            self._set_status("Seeking is not supported by this server.")
            return
        try:
            seekable.seekRelative(1 if direction > 0 else -1, 60 * 90000)
            self._set_status("Forward 60 seconds." if direction > 0 else "Back 60 seconds.")
            self._save_resume()
        except Exception:
            self._set_status("Seeking is not supported by this server.")

    def seek_forward(self):
        self._seek_relative(1)

    def seek_back(self):
        self._seek_relative(-1)

    def _apply_resume(self):
        if self._resume_applied or self._resume_target < 30 * 90000:
            return
        seekable = self._seekable()
        if not seekable:
            return
        try:
            seekable.seekTo(self._resume_target)
            self._resume_applied = True
            seconds = self._resume_target // 90000
            self._set_status("Resumed at %02d:%02d:%02d." % (
                seconds // 3600, (seconds % 3600) // 60, seconds % 60))
        except Exception:
            pass

    def _resume_tick(self):
        if not self._closed:
            self._save_resume()

    def _save_resume(self):
        if self.category.lower() == "live" or not self.resume_key or self._failed:
            return
        seekable = self._seekable()
        if not seekable:
            return
        try:
            position = seekable.getPlayPosition()
            if not position or position[0] or int(position[1]) < 10 * 90000:
                return
            current = int(position[1])
            length_result = seekable.getLength()
            length = int(length_result[1]) if length_result and not length_result[0] else 0
            points = _load_resume_points()
            if length and current >= max(0, length - 90 * 90000):
                points.pop(self.resume_key, None)
            else:
                points[self.resume_key] = [current, length, int(time.time())]
            if len(points) > 300:
                ordered = sorted(points.items(), key=lambda pair: pair[1][2] if len(pair[1]) > 2 else 0)
                points = dict(ordered[-300:])
            _write_resume_points(points)
        except Exception:
            pass

    def stopPlayback(self):
        self._finish("stopped", force_stop=True)

    def back(self):
        action = "failed" if self._failed else "back"
        self._finish(action, force_stop=self._failed or self.category.lower() != "live")

    def _finish(self, action, force_stop=False):
        if self._closed:
            return
        self._save_resume()
        result = (str(action), "working" if self._confirmed else "offline")
        self._closed = True
        self._cleanup()
        if force_stop and not self._playback_stopped:
            try:
                self.session.nav.stopService()
                self._playback_stopped = True
            except Exception:
                pass
        if self.category.lower() == "live":
            self.close(result)
        else:
            self.close()

    def _cleanup(self):
        if not self._closed:
            self._save_resume()
        try:
            self._attempt_timer.stop()
        except Exception:
            pass
        try:
            self._resume_timer.stop()
        except Exception:
            pass
