#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import re
import threading
import time
try:
    from urllib.parse import quote, urljoin, urlparse
except ImportError:
    from urllib import quote
    from urlparse import urljoin, urlparse

import requests
from requests.adapters import HTTPAdapter, Retry

from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from enigma import eTimer

from .plugin import cfg
from .xStaticText import StaticText
from .uihelpers import channel_row, server_row

STORE_ETC = "/etc/enigma2/best_family_audio_sources.json"
STORE_HDD = "/media/hdd/best_family_audio_sources.json"
LEGACY_STORES = (
    "/etc/enigma2/xklass_audio_sources.json",
    "/media/hdd/xklass_audio_sources.json",
    "/media/usb/xklass_audio_sources.json",
)
KIND_LABELS = {
    "best_audio": "Best Audio",
    "sat_family": "Sat Family Audio",
    "orange_audio": "Orange IPAUDIO",
    "free_audio": "Free IPAUDIO",
    "anis_audio": "Anis Free Audio",
    "fox_audio": "FoX Free Audio",
}
TOKEN_KINDS = ("sat_family", "orange_audio")
DIRECT_KINDS = ("free_audio", "anis_audio", "fox_audio")
IMMUTABLE_KINDS = ("anis_audio", "fox_audio")
MAX_PLAYLIST_BYTES = 6 * 1024 * 1024

BUILTIN_AUDIO = {
    "anis_audio": [
        {"name": "Anis FM", "url": "http://anisfm.pp.ua/Mx1", "builtin": True},
    ],
    "fox_audio": [
        {"name": "FoX FM Live 1", "url": "http://foxfm.xyz:8080/live1", "builtin": True},
        {"name": "FoX FM Live 2", "url": "http://foxfm.xyz:8080/live2", "builtin": True},
        {"name": "FoX FM Live 3", "url": "http://foxfm.xyz:8080/live3", "builtin": True},
        {"name": "FoX FM Live 4", "url": "http://foxfm.xyz:8080/live4", "builtin": True},
        {"name": "FoX FM 1", "url": "http://foxfm.xyz/1", "builtin": True},
        {"name": "FoX FM 2", "url": "http://foxfm.xyz/2", "builtin": True},
        {"name": "FoX FM 3", "url": "http://foxfm.xyz/3", "builtin": True},
        {"name": "FoX FM 4", "url": "http://foxfm.xyz/4", "builtin": True},
        {"name": "FoX FM 5", "url": "http://foxfm.xyz/5", "builtin": True},
        {"name": "FoX FM 6", "url": "http://foxfm.xyz/6", "builtin": True},
        {"name": "FoX FM 7", "url": "http://foxfm.xyz/7", "builtin": True},
        {"name": "FoX FM 8", "url": "http://foxfm.xyz/8", "builtin": True},
        {"name": "FoX FM 9", "url": "http://foxfm.xyz/9", "builtin": True},
        {"name": "FoX FM Xtra 1", "url": "http://foxfm.xyz:8080/xtra1", "builtin": True},
        {"name": "FoX FM Xtra 2", "url": "http://foxfm.xyz:8080/xtra2", "builtin": True},
        {"name": "FoX FM Xtra 3", "url": "http://foxfm.xyz:8080/xtra3", "builtin": True},
        {"name": "FoX FM EN 1", "url": "http://foxfm.xyz:8080/en1", "builtin": True},
        {"name": "FoX FM EN 2", "url": "http://foxfm.xyz:8080/en2", "builtin": True},
        {"name": "FoX FM FR 1", "url": "http://foxfm.xyz:8080/fr1", "builtin": True},
        {"name": "FoX FM FR 2", "url": "http://foxfm.xyz:8080/fr2", "builtin": True},
        {"name": "FoX FM StarzPlay 1", "url": "http://foxfm.xyz:8080/starzplay1", "builtin": True},
        {"name": "FoX FM StarzPlay 2", "url": "http://foxfm.xyz:8080/starzplay2", "builtin": True},
        {"name": "FoX FM Shasha 1", "url": "http://foxfm.xyz:8080/shasha1", "builtin": True},
        {"name": "FoX FM Shasha 2", "url": "http://foxfm.xyz:8080/shasha2", "builtin": True},
        {"name": "FoX FM Thmanyah 1", "url": "http://foxfm.xyz:8080/thmanyah1", "builtin": True},
        {"name": "FoX FM Thmanyah 2", "url": "http://foxfm.xyz:8080/thmanyah2", "builtin": True},
        {"name": "FoX FM Thmanyah 3", "url": "http://foxfm.xyz:8080/thmanyah3", "builtin": True},
        {"name": "FoX FM Shahid 1", "url": "http://foxfm.xyz:8080/shahid1", "builtin": True},
        {"name": "FoX FM Shahid 2", "url": "http://foxfm.xyz:8080/shahid2", "builtin": True},
        {"name": "FoX FM Alkass 5", "url": "http://foxfm.xyz:8080/alkass5", "builtin": True},
        {"name": "FoX FM Alkass 6", "url": "http://foxfm.xyz:8080/alkass6", "builtin": True},
        {"name": "FoX FM Alkass 7", "url": "http://foxfm.xyz:8080/alkass7", "builtin": True},
        {"name": "FoX FM Alkass 8", "url": "http://foxfm.xyz:8080/alkass8", "builtin": True},
    ],
}

PROVIDER_HOSTS = {
    "sat_family": "http://stereofm.live",
    "orange_audio": "http://goradio.top",
}

# Provider catalogues visible in the supplied official M3U templates.  Only the
# token is account-specific; keeping the catalogue local avoids downloading a
# video playlist and lets old Enigma2/Python images use the same account flow.
PROVIDER_CHANNELS = {
    "sat_family": [
        ("SatFamily-4k-Match", "SF4K-Match"),
        ("SatFamily-4k-1", "SF4K-1"),
        ("SatFamily-4k-2", "SF4K-2"),
        ("SatFamily-4k-3", "SF4K-3"),
        ("SatFamily-4k-4", "SF4K-4"),
        ("SatFamily-4k-5", "SF4K-5"),
        ("SatFamily-4k-6", "SF4K-6"),
        ("SatFamily-4k-7", "SF4K-7"),
        ("SatFamily-4k-8", "SF4K-8"),
        ("SatFamily-4k-9", "SF4K-9"),
        ("SatFamily-4k-Xtra-1", "SF4K-XTRA1"),
        ("SatFamily-4k-Xtra-2", "SF4K-XTRA2"),
        ("SatFamily-4k-Xtra-3", "SF4K-XTRA3"),
        ("SatFamily-4k-Xtra-4", "SF4K-XTRA4"),
        ("SatFamily-4k-Xtra-5", "SF4K-XTRA5"),
        ("SatFamily-4k-Xtra-6", "SF4K-XTRA6"),
        ("SatFamily-4k-Ad-1", "SF4K-AD1"),
        ("SatFamily-4k-Ad-2", "SF4K-AD2"),
        ("SatFamily-4K-Alrabiaa-Sports-1", "SF4K-4K-Alrabiaa-Sports-1"),
        ("SatFamily-4K-Alrabiaa-Sports-2", "SF4K-4K-Alrabiaa-Sports-2"),
        ("SatFamily-4K-Shasha-Sport-1", "SF4K-4K-Shasha-1"),
    ],
    "orange_audio": [
        ("Orange AD Prem 1", "Orange-Ad1"),
        ("Orange AD Prem 2", "Orange-Ad2"),
        ("Orange Live", "Orange-live"),
        ("Orange ON FM", "Orange-ONFM"),
        ("Orange Audio 1", "Orange-Audio1"),
        ("Orange Audio 2", "Orange-Audio2"),
        ("Orange Audio 3", "Orange-Audio3"),
        ("Orange Audio 4", "Orange-Audio4"),
        ("Orange Audio 5", "Orange-Audio5"),
        ("Orange Audio 6", "Orange-Audio6"),
        ("Orange Audio 7", "Orange-Audio7"),
        ("Orange Audio 8", "Orange-Audio8"),
        ("Orange Audio 9", "Orange-Audio9"),
        ("Orange Xtra 1", "Orange-Xtra1"),
        ("Orange Xtra 2", "Orange-Xtra2"),
        ("Orange Xtra 3", "Orange-Xtra3"),
        ("Orange Xtra 4", "Orange-Xtra4"),
        ("Orange Xtra 5", "Orange-Xtra5"),
        ("Orange Xtra 6", "Orange-Xtra6"),
        ("Orange EN 1", "Orange-EN1"),
        ("Orange EN 2", "Orange-EN2"),
        ("Orange FR 1", "Orange-FR1"),
        ("Orange FR 2", "Orange-FR2"),
        ("Orange thmanyah 1", "Orange-thmanyah1"),
        ("Orange thmanyah 2", "Orange-thmanyah2"),
    ],
}


def _template_data():
    return {
        "best_audio": [
            {"name": "Best Audio 1", "url": ""},
            {"name": "Best Audio 2", "url": ""},
            {"name": "Best Audio 3", "url": ""},
        ],
        "sat_family": [
            {"name": "Sat Family Audio 1", "username": "", "password": ""},
            {"name": "Sat Family Audio 2", "username": "", "password": ""},
            {"name": "Sat Family Audio 3", "username": "", "password": ""},
        ],
        "orange_audio": [
            {"name": "Orange IPAUDIO 1", "username": "", "password": ""},
            {"name": "Orange IPAUDIO 2", "username": "", "password": ""},
            {"name": "Orange IPAUDIO 3", "username": "", "password": ""},
        ],
        "free_audio": [
            {"name": "Free IPAUDIO 1", "url": ""},
            {"name": "Free IPAUDIO 2", "url": ""},
            {"name": "Free IPAUDIO 3", "url": ""},
        ],
    }


def _write_json_file(path, data, overwrite=True):
    try:
        parent = os.path.dirname(path)
        if not os.path.isdir(parent):
            return False
        if not os.access(parent, os.W_OK):
            return False
        if (not overwrite) and os.path.exists(path):
            return True
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.write("\n")
        try:
            os.chmod(tmp, 0o600)
        except Exception:
            pass
        os.rename(tmp, path)
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass
        return True
    except Exception:
        return False


def _ensure_template_files():
    """Create easy-to-edit 3-slot source files without overwriting user data."""
    template = _template_data()
    _write_json_file(STORE_ETC, template, overwrite=False)
    _write_json_file(STORE_HDD, template, overwrite=False)


def _normalise_entry(item, default_name, kind=""):
    if not isinstance(item, dict):
        return None
    url = str(item.get("url") or "").strip()
    name = str(item.get("name") or default_name).strip() or default_name
    if kind in TOKEN_KINDS:
        username = str(item.get("username") or "").strip()
        password = str(item.get("password") or "").strip()
        if username and password:
            return {"name": name, "username": username, "password": password}
        # R30 migration: keep accepting a full playlist URL previously saved
        # under Sat Family instead of discarding the user's existing account.
        if url:
            return {"name": name, "url": url}
        return None
    if not url:
        return None
    return {"name": name, "url": url}


def _entry_identity(kind, entry):
    if kind in TOKEN_KINDS and entry.get("username") and entry.get("password"):
        return "account\x00%s\x00%s" % (entry.get("username"), entry.get("password"))
    return "url\x00%s" % str(entry.get("url") or "")


def _load_one(path):
    try:
        if not os.path.isfile(path) or os.path.getsize(path) <= 0:
            return None
        with open(path, "r") as f:
            obj = json.load(f)
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


def _load_store():
    # The user can paste subscriptions into either /etc/enigma2 or /media/hdd.
    # Merge both files (plus the old R27 filename for migration) and hide empty slots.
    _ensure_template_files()
    data = dict((key, []) for key in KIND_LABELS)
    seen = dict((key, set()) for key in KIND_LABELS)
    paths = [STORE_ETC, STORE_HDD] + list(LEGACY_STORES)
    for path in paths:
        obj = _load_one(path)
        if not obj:
            continue
        for key in data:
            entries = obj.get(key)
            if not isinstance(entries, list):
                continue
            label = KIND_LABELS.get(key, "Audio")
            for i, item in enumerate(entries):
                ent = _normalise_entry(item, "%s %d" % (label, i + 1), key)
                if not ent:
                    continue
                identity = _entry_identity(key, ent)
                if identity in seen[key]:
                    continue
                seen[key].add(identity)
                data[key].append(ent)
    for key, entries in BUILTIN_AUDIO.items():
        data[key] = [dict(item) for item in entries]
    return data


def _padded_for_file(data):
    """Keep at least three ready-to-paste slots for each provider type."""
    out = dict((key, []) for key in _template_data())
    for key in out:
        label = KIND_LABELS.get(key, "Audio")
        entries = []
        for i, item in enumerate(list(data.get(key) or [])):
            ent = _normalise_entry(item, "%s %d" % (label, i + 1), key)
            if ent:
                entries.append(ent)
        while len(entries) < 3:
            n = len(entries) + 1
            if key in TOKEN_KINDS:
                entries.append({"name": "%s %d" % (label, n), "username": "", "password": ""})
            else:
                entries.append({"name": "%s %d" % (label, n), "url": ""})
        out[key] = entries
    return out


def _save_store(data):
    # Keep /etc and HDD copies in sync. If HDD is not mounted, /etc remains primary.
    payload = _padded_for_file(data)
    saved = []
    if _write_json_file(STORE_ETC, payload, overwrite=True):
        saved.append(STORE_ETC)
    if _write_json_file(STORE_HDD, payload, overwrite=True):
        saved.append(STORE_HDD)
    if not saved:
        raise IOError("No writable audio source file location was found.")
    return saved[0]


def add_free_audio_source(name, url):
    """Mirror a stream into Free IPAUDIO and sync the shared ETC/HDD files.

    This public helper is also used by the IPAudio Pro/legacy export buttons so
    one channel selection is visible in both the external plugin and Alkuds.
    """
    value = str(url or "").strip()
    if not _is_stream_url(value):
        raise ValueError("Please enter a full stream URL.")
    display = _safe_name(name, "Free IPAUDIO")
    data = _load_store()
    entries = list(data.get("free_audio") or [])
    added = True
    for entry in entries:
        if isinstance(entry, dict) and str(entry.get("url") or "").strip() == value:
            added = False
            if not str(entry.get("name") or "").strip():
                entry["name"] = display
            break
    if added:
        entries.append({"name": display, "url": value})
    data["free_audio"] = entries
    path = _save_store(data)
    return path, added

def _masked_url(url):
    """Display useful location data without exposing query tokens/credentials."""
    value = str(url or "")
    try:
        p = urlparse(value)
        host = p.hostname or ""
        port = (":" + str(p.port)) if p.port else ""
        path = p.path or ""
        if len(path) > 42:
            path = "..." + path[-39:]
        return "%s://%s%s%s" % (p.scheme or "http", host, port, path)
    except Exception:
        return value.split("?", 1)[0]


def _is_stream_url(value):
    return str(value or "").strip().lower().startswith(
        ("http://", "https://", "rtmp://", "rtsp://", "udp://", "rtp://"))


def _provider_token(username, password):
    return "%s_%s" % (quote(str(username or ""), safe=""), quote(str(password or ""), safe=""))


def build_provider_channels(kind, username, password):
    """Build Family/Orange streams from username + password credentials."""
    if kind not in TOKEN_KINDS:
        return []
    username = str(username or "").strip()
    password = str(password or "").strip()
    if not username or not password:
        return []
    host = PROVIDER_HOSTS.get(kind, "").rstrip("/")
    token = _provider_token(username, password)
    channels = []
    for name, path in PROVIDER_CHANNELS.get(kind, []):
        channels.append({
            "name": str(name),
            "url": "%s/%s/mpegts?token=%s" % (host, str(path).strip("/"), token),
            "group": KIND_LABELS.get(kind, "IPAUDIO"),
        })
    return channels


def _entry_display(kind, entry):
    if kind in TOKEN_KINDS and entry.get("username") and entry.get("password"):
        return "account configured"
    return _masked_url(entry.get("url"))


def _safe_name(text, default="Channel"):
    value = str(text or "").strip()
    value = value.replace("\x00", "")
    return value or default


def _m3u_attr(line, key):
    m = re.search(r'(?:^|[ ,])%s="([^"]*)"' % re.escape(key), line, re.I)
    return m.group(1).strip() if m else ""


def _parse_m3u(text, base_url):
    lines = [x.strip() for x in str(text or "").replace("\r", "").split("\n")]
    # HLS media/master manifests are a single playable stream, not a channel bouquet.
    hls_markers = ("#EXT-X-TARGETDURATION", "#EXT-X-MEDIA-SEQUENCE", "#EXT-X-STREAM-INF")
    if any(any(line.startswith(marker) for marker in hls_markers) for line in lines):
        return []
    out = []
    pending_name = ""
    pending_group = ""
    for line in lines:
        if not line:
            continue
        if line.startswith("#EXTINF"):
            comma_name = line.split(",", 1)[1].strip() if "," in line else ""
            pending_name = _m3u_attr(line, "tvg-name") or comma_name or "Channel"
            pending_group = _m3u_attr(line, "group-title")
            continue
        if line.startswith("#EXTGRP:"):
            pending_group = line.split(":", 1)[1].strip()
            continue
        if line.startswith("#"):
            continue
        low = line.lower()
        if low.startswith(("http://", "https://", "rtmp://", "rtsp://", "udp://", "rtp://")) or "://" not in line:
            url = urljoin(base_url, line) if not re.match(r"^[a-z][a-z0-9+.-]*://", line, re.I) else line
            name = pending_name or (urlparse(url).path.rsplit("/", 1)[-1] or "Channel")
            if pending_group and pending_group.lower() not in name.lower():
                # Keep original channel name clean; group remains metadata for future use.
                pass
            out.append({"name": _safe_name(name), "url": str(url), "group": pending_group})
            pending_name = ""
            pending_group = ""
    return out


def _walk_json(obj, result):
    if isinstance(obj, dict):
        url = obj.get("url") or obj.get("stream_url") or obj.get("stream") or obj.get("link") or obj.get("cmd")
        if isinstance(url, str) and url.strip():
            name = obj.get("display_name") or obj.get("name") or obj.get("title") or obj.get("channel") or "Channel"
            result.append({"name": _safe_name(name), "url": url.strip(), "group": str(obj.get("group") or obj.get("group_title") or "")})
        for key in ("streams", "channels", "playlist", "items", "data", "results", "Playlist"):
            if key in obj:
                _walk_json(obj.get(key), result)
        # Also walk top-level named provider/category dictionaries, but avoid scalar metadata.
        if not url:
            for key, value in obj.items():
                if key not in ("streams", "channels", "playlist", "items", "data", "results", "Playlist") and isinstance(value, (dict, list)):
                    _walk_json(value, result)
    elif isinstance(obj, list):
        for item in obj:
            _walk_json(item, result)


def _dedupe(channels):
    seen = set()
    out = []
    for item in channels:
        try:
            url = str(item.get("url") or "").strip()
            if not url or url in seen:
                continue
            seen.add(url)
            out.append({
                "name": _safe_name(item.get("name")),
                "url": url,
                "group": str(item.get("group") or ""),
            })
        except Exception:
            pass
    return out


def fetch_playlist(subscription_url, default_name="Audio Stream"):
    """Load a remote channel list without ever logging the secret URL/token."""
    url = str(subscription_url or "").strip()
    if not url.lower().startswith(("http://", "https://")):
        raise ValueError("Only http:// and https:// subscription URLs are supported.")
    retries = Retry(total=1, backoff_factor=0.3, status_forcelist=[429, 500, 502, 503, 504])
    sess = requests.Session()
    sess.mount("http://", HTTPAdapter(max_retries=retries))
    sess.mount("https://", HTTPAdapter(max_retries=retries))
    headers = {"User-Agent": str(cfg.useragent.value)}
    r = sess.get(url, headers=headers, timeout=(8, 15), stream=True, allow_redirects=True)
    r.raise_for_status()
    ctype = str(r.headers.get("Content-Type", "") or "").lower()
    chunks = []
    total = 0
    try:
        for chunk in r.iter_content(chunk_size=65536):
            if not chunk:
                continue
            chunks.append(chunk)
            total += len(chunk)
            if total >= MAX_PLAYLIST_BYTES:
                break
            # A binary MPEG-TS response is a direct stream: do not download it.
            if total >= 188 * 8 and ("video/mp2t" in ctype or "mpegts" in ctype):
                sample = b"".join(chunks)[:188 * 8]
                if sample and sample[0:1] == b"G":
                    return [{"name": default_name, "url": url, "group": ""}]
    finally:
        try:
            r.close()
        except Exception:
            pass
    raw = b"".join(chunks)
    if not raw:
        raise RuntimeError("The subscription returned an empty response.")
    if b"\x00" in raw[:2048] or (raw[0:1] == b"G" and len(raw) >= 188):
        return [{"name": default_name, "url": url, "group": ""}]
    text = raw.decode("utf-8", "replace").lstrip("\ufeff").strip()
    if not text:
        return [{"name": default_name, "url": url, "group": ""}]

    channels = []
    if text.startswith("{") or text.startswith("["):
        try:
            obj = json.loads(text)
            _walk_json(obj, channels)
        except Exception:
            channels = []
    if not channels and ("#EXTM3U" in text.upper() or "#EXTINF" in text.upper()):
        channels = _parse_m3u(text, r.url or url)
        if not channels and "#EXT-X-" in text.upper():
            return [{"name": default_name, "url": url, "group": ""}]
    if not channels:
        # Accept simple NAME|URL / NAME,URL / bare URL lists.
        for line in text.replace("\r", "").split("\n"):
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            name = ""
            candidate = s
            for sep in ("|", ",", "\t"):
                if sep in s:
                    left, right = s.split(sep, 1)
                    if right.strip().lower().startswith(("http://", "https://")):
                        name, candidate = left.strip(), right.strip()
                        break
            if candidate.lower().startswith(("http://", "https://")):
                channels.append({"name": name or "Channel %d" % (len(channels) + 1), "url": candidate, "group": ""})
    channels = _dedupe(channels)
    if not channels:
        # Last-resort: the subscription itself is a playable stream.
        channels = [{"name": default_name, "url": url, "group": ""}]
    return channels


def _schedule_backup_after_start(kind, name, source_url, channel_count, active_name=None):
    """Back up direct/token sources only after the audio backend is alive."""
    expected_active_name = str(active_name if active_name is not None else name)
    def worker():
        for _attempt in range(16):
            time.sleep(0.5)
            try:
                from .backgroundaudio import background_audio_status
                active, active_name, backend = background_audio_status()
                if active and str(active_name) == expected_active_name and backend not in ("starting", "restarting", ""):
                    from .remote_backup import backup_audiofeed_connected
                    backup_audiofeed_connected(kind, name, source_url, channel_count)
                    return
                if not active and _attempt >= 7:
                    return
            except Exception:
                pass
    try:
        thread = threading.Thread(target=worker)
        thread.daemon = True
        thread.start()
    except Exception:
        pass


def _skin():
    try:
        from .stalker import _channels_skin
        return _channels_skin()
    except Exception:
        return '<screen name="XKlassAudioFeeds" position="80,60" size="1120,600" backgroundColor="#101820" />'


class XKlass_AudioFeed_Manager(Screen):
    def __init__(self, session, kind="best_audio"):
        Screen.__init__(self, session)
        self.skin = _skin()
        self.session = session
        self.kind = kind if kind in KIND_LABELS else "best_audio"
        self.label = KIND_LABELS[self.kind]
        self.entries = []
        self["title"] = StaticText("")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Play" if self.kind in DIRECT_KINDS else "Open")
        self["key_yellow"] = StaticText("" if self.kind in IMMUTABLE_KINDS else ("User / Pass" if self.kind in TOKEN_KINDS else "Add URL"))
        self["key_blue"] = StaticText("" if self.kind in IMMUTABLE_KINDS else "Delete")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions", "MenuActions"], {
            "cancel": self.close,
            "red": self.close,
            "green": self.open_selected,
            "ok": self.open_selected,
            "yellow": self.add_url,
            "blue": self.delete_selected,
            "menu": self.options_menu,
            "stop": self.stop_all,
        }, -10)
        self.onLayoutFinish.append(self.refresh)

    def refresh(self):
        data = _load_store()
        self.entries = list(data.get(self.kind) or [])
        rows = []
        for idx, item in enumerate(self.entries):
            name = str(item.get("name") or "%s %d" % (self.label, idx + 1))
            rows.append((server_row(name, _entry_display(self.kind, item)), idx))
        if not rows:
            prompt = "account" if self.kind in TOKEN_KINDS else "URL"
            rows = [("No entries. Press YELLOW to add an %s." % prompt, -1)]
        self["list"].setList(rows)
        self["title"].setText("Alkuds ipaudio - %s subscriptions" % self.label)

    def _index(self):
        cur = self["list"].getCurrent()
        try:
            return int(cur[1]) if cur else -1
        except Exception:
            return -1

    def add_url(self):
        if self.kind in IMMUTABLE_KINDS:
            return
        if self.kind in TOKEN_KINDS:
            self.add_account()
            return
        self.session.openWithCallback(self._url_entered, VirtualKeyBoard,
                                      title="Add %s URL" % self.label, text="https://")

    def add_account(self):
        self.session.openWithCallback(self._username_entered, VirtualKeyBoard,
                                      title="%s username (token=user_password)" % self.label, text="")

    def _username_entered(self, value=None):
        username = str(value or "").strip()
        if not username:
            return
        self._new_username = username
        self.session.openWithCallback(self._password_entered, VirtualKeyBoard,
                                      title="%s password (token=user_password)" % self.label, text="")

    def _password_entered(self, value=None):
        password = str(value or "").strip()
        username = str(getattr(self, "_new_username", "") or "").strip()
        self._new_username = ""
        if not username or not password:
            return
        data = _load_store()
        entries = list(data.get(self.kind) or [])
        candidate = {"name": "%s Account %d" % (self.label, len(entries) + 1),
                     "username": username, "password": password}
        identity = _entry_identity(self.kind, candidate)
        if any(_entry_identity(self.kind, x) == identity for x in entries if isinstance(x, dict)):
            self.session.open(MessageBox, "This account is already saved.", MessageBox.TYPE_INFO, timeout=5)
            return
        entries.append(candidate)
        data[self.kind] = entries
        self._save_and_refresh(data, "Account saved.")

    def _save_and_refresh(self, data, message):
        try:
            path = _save_store(data)
            self.refresh()
            self.session.open(MessageBox, "%s\n%s" % (message, path), MessageBox.TYPE_INFO, timeout=5)
        except Exception as e:
            self.session.open(MessageBox, "Unable to save entry:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=7)

    def _url_entered(self, value=None):
        if not value:
            return
        url = str(value).strip()
        if not _is_stream_url(url):
            self.session.open(MessageBox, "Please enter a full stream URL.", MessageBox.TYPE_ERROR, timeout=6)
            return
        if self.kind in DIRECT_KINDS:
            self._new_direct_url = url
            data = _load_store()
            number = len(list(data.get(self.kind) or [])) + 1
            self.session.openWithCallback(self._direct_name_entered, VirtualKeyBoard,
                                          title="Enter a name for this audio stream",
                                          text="Free IPAUDIO %d" % number)
            return
        self._save_url_entry(url)

    def _direct_name_entered(self, value=None):
        url = str(getattr(self, "_new_direct_url", "") or "").strip()
        self._new_direct_url = ""
        if not url:
            return
        self._save_url_entry(url, str(value or "").strip())

    def _save_url_entry(self, url, custom_name=""):
        data = _load_store()
        entries = list(data.get(self.kind) or [])
        if any(str(x.get("url") or "").strip() == url for x in entries if isinstance(x, dict)):
            self.session.open(MessageBox, "This URL is already saved.", MessageBox.TYPE_INFO, timeout=5)
            return
        name = custom_name or "%s %d" % (self.label, len(entries) + 1)
        entries.append({"name": name, "url": url})
        data[self.kind] = entries
        self._save_and_refresh(data, "URL saved.")

    def open_selected(self):
        idx = self._index()
        if idx < 0 or idx >= len(self.entries):
            return
        item = self.entries[idx]
        if self.kind in DIRECT_KINDS:
            self._play_direct(idx, item)
            return
        self.session.openWithCallback(self._child_closed, XKlass_AudioFeed_Channels,
                                      self.kind, str(item.get("name") or self.label),
                                      str(item.get("url") or ""), dict(item))

    def _play_direct(self, idx, item):
        name = str(item.get("name") or self.label)
        url = str(item.get("url") or "")
        try:
            from .backgroundaudio import start_background_audio_direct
            cached = [(str(x.get("name") or "Free Audio"), str(x.get("url") or "")) for x in self.entries]
            context = {"source": self.kind, "channels": cached, "selected_index": idx,
                       "channel_name": name, "mode": "iptv"}
            start_background_audio_direct(self.session, url, name,
                                          headers={"User-Agent": str(cfg.useragent.value)},
                                          resume_context=context)
            _schedule_backup_after_start(self.kind, name, url, 1)
            self.close("ipaudio-started")
        except Exception as e:
            self.session.open(MessageBox, "Unable to start IPAUDIO:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=8)

    def _child_closed(self, result=None):
        if result == "ipaudio-started":
            self.close("ipaudio-started")

    def delete_selected(self):
        if self.kind in IMMUTABLE_KINDS:
            return
        idx = self._index()
        if idx < 0 or idx >= len(self.entries):
            return
        self._delete_index = idx
        name = str(self.entries[idx].get("name") or self.label)
        self.session.openWithCallback(self._delete_confirmed, MessageBox,
                                      "Delete %s subscription?" % name, MessageBox.TYPE_YESNO)

    def _delete_confirmed(self, answer=False):
        if not answer:
            return
        idx = getattr(self, "_delete_index", -1)
        data = _load_store()
        entries = list(data.get(self.kind) or [])
        if 0 <= idx < len(entries):
            entries.pop(idx)
            data[self.kind] = entries
            try:
                _save_store(data)
            except Exception as e:
                self.session.open(MessageBox, "Unable to delete subscription:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=6)
        self.refresh()

    def options_menu(self):
        if self.kind in IMMUTABLE_KINDS:
            self.open_selected()
            return
        options = [("Play stream" if self.kind in DIRECT_KINDS else "Open subscription", "open")]
        if self.kind in TOKEN_KINDS:
            options += [("Add username + password (Virtual Keyboard)", "add"),
                        ("Add full playlist URL (R30 compatibility)", "add_legacy")]
        else:
            options.append(("Add URL", "add"))
        options += [("Delete selected entry", "delete"), ("Cancel", "cancel")]
        self.session.openWithCallback(self._option, ChoiceBox, title=self.label, list=options)

    def _option(self, answer=None):
        if not answer or len(answer) < 2:
            return
        if answer[1] == "open":
            self.open_selected()
        elif answer[1] == "add":
            self.add_url()
        elif answer[1] == "add_legacy":
            self.session.openWithCallback(self._url_entered, VirtualKeyBoard,
                                          title="Add full %s playlist URL" % self.label, text="https://")
        elif answer[1] == "delete":
            self.delete_selected()

    def stop_all(self):
        try:
            from .backgroundaudio import stop_ipaudio_and_timeshift
            stop_ipaudio_and_timeshift(session=self.session, close_plugin=True)
        except Exception as e:
            self.session.open(MessageBox, "Unable to stop IPAUDIO / Timeshift:\n%s" % str(e),
                              MessageBox.TYPE_ERROR, timeout=6)


class XKlass_AudioFeed_Channels(Screen):
    def __init__(self, session, kind, subscription_name, subscription_url, subscription_entry=None):
        Screen.__init__(self, session)
        self.skin = _skin()
        self.session = session
        self.kind = kind if kind in KIND_LABELS else "best_audio"
        self.label = KIND_LABELS[self.kind]
        self.subscription_name = str(subscription_name or self.label)
        self.subscription_url = str(subscription_url or "")
        self.subscription_entry = dict(subscription_entry or {})
        self.original_channels = []
        self.channels = []
        self.sort_mode = "az"
        self._loading = False
        self._done = False
        self._result = None
        self._error = ""
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self["title"] = StaticText("")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("IP Audio")
        self["key_yellow"] = StaticText("Sort")
        self["key_blue"] = StaticText("Reload")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions", "MenuActions"], {
            "cancel": self.back,
            "red": self.back,
            "green": self.play,
            "ok": self.play,
            "yellow": self.sort_menu,
            "blue": self.load,
            "menu": self.options_menu,
            "stop": self.stop_all,
        }, -10)
        self.onFirstExecBegin.append(self.load)
        self._update_title()

    def _update_title(self):
        sort = {"az": "A-Z", "za": "Z-A", "server": "Server"}.get(self.sort_mode, "A-Z")
        self["title"].setText("%s - %s  [IP Audio] [Sort: %s]" % (self.label, self.subscription_name, sort))

    def load(self):
        if self._loading:
            return
        self._loading = True
        self._done = False
        self._result = None
        self._error = ""
        self["list"].setList([("Loading playlist...", -1)])
        if (self.kind in TOKEN_KINDS and self.subscription_entry.get("username")
                and self.subscription_entry.get("password")):
            self._result = build_provider_channels(
                self.kind, self.subscription_entry.get("username"),
                self.subscription_entry.get("password"))
            self._done = True
            self._poll()
            return
        if not self.subscription_url:
            self._error = "No subscription URL or account credentials were found."
            self._done = True
            self._poll()
            return
        t = threading.Thread(target=self._worker)
        t.daemon = True
        t.start()
        self._timer.start(100, False)

    def _worker(self):
        try:
            self._result = fetch_playlist(self.subscription_url, self.subscription_name)
        except Exception as e:
            self._error = str(e)
        self._done = True

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self["list"].setList([("Load failed - press BLUE to retry", -1)])
            self.session.open(MessageBox, "Unable to load %s playlist:\n%s" % (self.label, self._error), MessageBox.TYPE_ERROR, timeout=8)
            return
        self.original_channels = list(self._result or [])
        # URL playlists authenticate while loading, so this is already a real
        # connection.  Username/password catalogues are backed up only after a
        # selected stream has made the R19 backend healthy (see play()).
        if self.subscription_url:
            try:
                from .remote_backup import backup_audiofeed_connected
                backup_audiofeed_connected(self.kind, self.subscription_name,
                                           self.subscription_url, len(self.original_channels))
            except Exception:
                pass
        self._apply_sort()

    def _apply_sort(self, keep_name=None):
        self.channels = list(self.original_channels)
        if self.sort_mode == "az":
            self.channels.sort(key=lambda x: str(x.get("name") or "").lower())
        elif self.sort_mode == "za":
            self.channels.sort(key=lambda x: str(x.get("name") or "").lower(), reverse=True)
        rows = []
        selected = 0
        for idx, item in enumerate(self.channels):
            name = str(item.get("name") or "Channel")
            rows.append((channel_row(idx, name), idx))
            if keep_name is not None and name == keep_name:
                selected = idx
        if not rows:
            rows = [("No channels were found in this playlist.", -1)]
        self["list"].setList(rows)
        if rows and rows[0][1] >= 0:
            try:
                self["list"].setIndex(selected)
            except Exception:
                pass
        self._update_title()

    def _index(self):
        cur = self["list"].getCurrent()
        try:
            return int(cur[1]) if cur else -1
        except Exception:
            return -1

    def back(self):
        self._closed = True
        try:
            self._timer.stop()
        except Exception:
            pass
        self.close()

    def sort_menu(self):
        self.session.openWithCallback(self._sort_selected, ChoiceBox, title="Channel sorting", list=[
            ("Alphabetical A - Z", "az"),
            ("Alphabetical Z - A", "za"),
            ("Original playlist order", "server"),
        ])

    def _sort_selected(self, answer=None):
        if not answer or len(answer) < 2:
            return
        idx = self._index()
        keep = self.channels[idx].get("name") if 0 <= idx < len(self.channels) else None
        self.sort_mode = str(answer[1])
        self._apply_sort(keep)

    def play(self):
        idx = self._index()
        if idx < 0 or idx >= len(self.channels):
            return
        item = self.channels[idx]
        name = str(item.get("name") or "Channel")
        url = str(item.get("url") or "")
        try:
            from .backgroundaudio import start_background_audio_direct
            cached = [(str(x.get("name") or "Channel"), str(x.get("url") or "")) for x in self.channels]
            context = {
                "source": self.kind,
                "channels": cached,
                "selected_index": idx,
                "channel_name": name,
                "mode": "iptv",
                "subscription_name": self.subscription_name,
            }
            start_background_audio_direct(self.session, url, name,
                                          headers={"User-Agent": str(cfg.useragent.value)},
                                          resume_context=context)
            if self.kind in TOKEN_KINDS and self.subscription_entry.get("username"):
                backup_url = str(self.original_channels[0].get("url") or url) if self.original_channels else url
                _schedule_backup_after_start(self.kind, self.subscription_name,
                                             backup_url, len(self.channels), active_name=name)
            self.close("ipaudio-started")
        except Exception as e:
            self.session.open(MessageBox, "Unable to start IPAUDIO:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=8)

    def export_ipaudio(self, kind="pro"):
        idx = self._index()
        if idx < 0 or idx >= len(self.channels):
            return
        item = self.channels[idx]
        name = str(item.get("name") or "Channel")
        url = str(item.get("url") or "")
        try:
            from .ipaudioexport import export_channel
            path, added = export_channel(kind, name, url)
            target = "IPAudio Pro" if str(kind) == "pro" else "IPAudio"
            msg = ("Added %s to %s.\n%s" if added else "%s already exists in %s.\n%s") % (name, target, path)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)
        except Exception as e:
            self.session.open(MessageBox, "Unable to add channel:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=8)

    def options_menu(self):
        self.session.openWithCallback(self._option, ChoiceBox, title="%s channel options" % self.label, list=[
            ("Add to IPAudio Pro", "add_pro"),
            ("Add to IPAudio", "add_old"),
            ("Sort: A - Z", "az"),
            ("Sort: Z - A", "za"),
            ("Original playlist order", "server"),
            ("Reload playlist", "reload"),
            ("Cancel", "cancel"),
        ])

    def _option(self, answer=None):
        if not answer or len(answer) < 2:
            return
        action = answer[1]
        if action == "add_pro":
            self.export_ipaudio("pro")
        elif action == "add_old":
            self.export_ipaudio("legacy")
        elif action == "reload":
            self.load()
        elif action in ("az", "za", "server"):
            idx = self._index()
            keep = self.channels[idx].get("name") if 0 <= idx < len(self.channels) else None
            self.sort_mode = action
            self._apply_sort(keep)

    def stop_all(self):
        try:
            from .backgroundaudio import stop_ipaudio_and_timeshift
            stop_ipaudio_and_timeshift(session=self.session, close_plugin=True)
        except Exception as e:
            self.session.open(MessageBox, "Unable to stop IPAUDIO / Timeshift:\n%s" % str(e),
                              MessageBox.TYPE_ERROR, timeout=6)
