#!/usr/bin/python
# -*- coding: utf-8 -*-
"""IPAudio AlQuds Lite24 R14 compatibility-gated auto-timeshift + monotonic video sync controller."""

from __future__ import print_function

import threading
import time

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Sources.List import List
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from enigma import eTimer
try:
    from enigma import eActionMap
except Exception:
    eActionMap = None

from .plugin import cfg
from .xStaticText import StaticText


class XKlass_Remux_Return(Screen):
    """Cached live-channel list for the currently active Local Remux."""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        from .remux import get_resume_context
        self.context = get_resume_context() or {}
        self.channels = list(self.context.get("channels") or [])
        self.source = str(self.context.get("source") or "")
        self.mode = str(self.context.get("mode") or "iptv")
        self.current_index = int(self.context.get("selected_index") or 0) if self.channels else 0
        if self.current_index < 0 or self.current_index >= len(self.channels):
            self.current_index = 0

        try:
            from .stalker import _channels_skin
            self.skin = _channels_skin()
        except Exception:
            self.skin = '<screen name="XKlassRemuxReturn" position="0,0" size="720,576" backgroundColor="#50002040" flags="wfNoBorder"></screen>'

        self["title"] = StaticText("")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Play")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("Main Menu")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap([
            "XKlassActions", "OkCancelActions", "ColorActions", "MenuActions"
        ], {
            "cancel": self.exit_browser,
            "red": self.exit_browser,
            "green": self.play_or_fullscreen,
            "ok": self.play_or_fullscreen,
            "blue": self.open_main_menu,
            "menu": self.options_menu,
        }, -10)

        self._loading = False
        self._done = False
        self._error = ""
        self._resolved_url = ""
        self._target_index = self.current_index
        self._target_name = ""
        self._client = None
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll_resolve)
        except Exception:
            self._timer.callback.append(self._poll_resolve)

        self._handover_timer = eTimer()
        try:
            self._handover_conn = self._handover_timer.timeout.connect(self._poll_channel_handover)
        except Exception:
            self._handover_timer.callback.append(self._poll_channel_handover)

        self.onLayoutFinish.append(self._build)

    def _channel_name_url(self, item):
        if isinstance(item, dict):
            return str(item.get("name") or "Channel"), str(item.get("value") or item.get("url") or item.get("cmd") or "")
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            return str(item[0]), str(item[1])
        return str(item), ""

    def _build(self):
        rows = []
        for idx, item in enumerate(self.channels):
            name, _value = self._channel_name_url(item)
            rows.append((name, idx))
        if not rows:
            rows = [("No cached channels for the active remux.", -1)]
        self["list"].setList(rows)
        if self.channels:
            try:
                self["list"].setIndex(self.current_index)
            except Exception:
                pass
        source_label = "Portal / MAC" if self.source == "stalker" else "Xtream Live" if self.source == "xtream" else "IPTV"
        current_name = self._channel_name_url(self.channels[self.current_index])[0] if self.channels else ""
        self["title"].setText("%s - %s" % (source_label, current_name))

    def _current_index(self):
        cur = self["list"].getCurrent()
        try:
            return int(cur[1]) if cur else -1
        except Exception:
            return -1

    def play_or_fullscreen(self):
        if self._loading:
            return
        idx = self._current_index()
        if idx < 0 or idx >= len(self.channels):
            return

        # Same channel: return to the full-screen remux and leave the lightweight
        # pause/timeshift key controller armed behind XKlass.
        if idx == self.current_index:
            self.exit_browser()
            return

        # Do not silently destroy an already delayed satellite-video buffer just
        # because the IPTV audio source was changed.
        try:
            from .remux import video_timeshift_status
            _rec, playback, held, _elapsed, _size, _path = video_timeshift_status()
            if playback or held:
                self.session.open(
                    MessageBox,
                    "Satellite video timeshift is active. Resume/stop the timeshift first, then change the IPTV channel.",
                    MessageBox.TYPE_INFO, timeout=6
                )
                return
        except Exception:
            pass

        self._target_index = idx
        self._target_name, value = self._channel_name_url(self.channels[idx])
        self["title"].setText("Switching audio to %s ..." % self._target_name)

        if self.source == "stalker":
            self._loading = True
            self._done = False
            self._error = ""
            self._resolved_url = ""
            t = threading.Thread(target=self._resolve_stalker_worker, args=(value,))
            t.daemon = True
            t.start()
            self._timer.start(100, False)
        else:
            self._start_handover(value, self._target_name, idx, {"User-Agent": str(cfg.useragent.value)})

    def _resolve_stalker_worker(self, command):
        try:
            from .stalker import StalkerClient
            portal = dict(self.context.get("portal") or {})
            self._client = StalkerClient(portal)
            self._resolved_url = self._client.create_link(command)
            if not self._resolved_url:
                raise RuntimeError("Portal did not return a playable stream URL")
        except Exception as e:
            self._error = str(e)
        self._done = True

    def _poll_resolve(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._error:
            self.session.open(MessageBox, "Unable to switch Stalker channel:\n%s" % self._error, MessageBox.TYPE_ERROR, timeout=7)
            self._build()
            return
        headers = dict(getattr(self._client, "headers", {}) or {})
        self._start_handover(self._resolved_url, self._target_name, self._target_index, headers)

    def _start_handover(self, stream_url, name, index, headers):
        try:
            from .remux import handover_local_remux
            new_context = dict(self.context)
            new_context["selected_index"] = int(index)
            new_context["channel_name"] = str(name)
            new_context["mode"] = self.mode
            handover_local_remux(
                self.session, stream_url, name, self.mode,
                iptv_headers=dict(headers or {}), resume_context=new_context,
                satellite_source="live"
            )
            self._loading = True
            self._target_index = int(index)
            self._target_name = str(name)
            self._handover_timer.start(150, False)
        except Exception as e:
            self._loading = False
            self.session.open(MessageBox, "Unable to switch Local Remux channel:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=8)
            self._build()

    def _poll_channel_handover(self):
        try:
            from .remux import handover_status, get_resume_context
            active, _error, _source = handover_status()
            if active:
                return
            self._handover_timer.stop()
            self._loading = False
            ctx = get_resume_context() or {}
            actual = int(ctx.get("selected_index") or 0) if ctx else self.current_index
            if actual == self._target_index:
                self.context = ctx
                self.current_index = self._target_index
                try:
                    self["list"].setIndex(self.current_index)
                except Exception:
                    pass
                self["title"].setText("%s - %s" % (
                    "Portal / MAC" if self.source == "stalker" else "Xtream Live",
                    self._target_name
                ))
            else:
                self._build()
        except Exception:
            try:
                self._handover_timer.stop()
            except Exception:
                pass
            self._loading = False
            self._build()

    def options_menu(self):
        self.session.openWithCallback(self._option_selected, ChoiceBox, title="Active Local Remux", list=[
            ("Stop IPTV audio and restore satellite", "stop"),
            ("Local Remux status", "status"),
            ("Start satellite video timeshift", "timeshift"),
            ("Open XKlass main menu", "main"),
            ("Cancel", "cancel"),
        ])

    def _option_selected(self, answer=None):
        if not answer or len(answer) < 2:
            return
        action = answer[1]
        if action == "stop":
            try:
                from .remux import stop_local_remux
                stopped = stop_local_remux(restore=True)
                msg = "IPTV audio stopped. Satellite service restored." if stopped else "Local Remux is not running."
                self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=4)
                self.close()
            except Exception as e:
                self.session.open(MessageBox, "Unable to stop Local Remux:\n%s" % e, MessageBox.TYPE_ERROR, timeout=6)
        elif action == "status":
            try:
                from .remux import local_remux_status, video_timeshift_status
                active, name, backend = local_remux_status()
                rec, playback, held, elapsed, size, path = video_timeshift_status()
                msg = "Local Remux: %s\n%s\n%s" % (name, backend, "Video timeshift: %ss / %.1f MB" % (int(elapsed), size / 1048576.0) if rec else "Video timeshift: idle") if active else "Local Remux is not running."
            except Exception as e:
                msg = "Unable to read status: %s" % e
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=7)
        elif action == "timeshift":
            # Return to full screen; the controller opened on exit catches PAUSE.
            self.exit_browser()
        elif action == "main":
            self.open_main_menu()

    def open_main_menu(self):
        try:
            from . import startmenu
            self.session.open(startmenu.XKlass_MainMenu)
        except Exception as e:
            self.session.open(MessageBox, "Unable to open XKlass main menu:\n%s" % str(e), MessageBox.TYPE_ERROR, timeout=6)

    def exit_browser(self):
        try:
            if bool(cfg.remuxvideohold.value):
                schedule_video_hold(self.session, int(cfg.remuxvideoholddelay.value))
        except Exception:
            pass
        self.close()


# ---------------------------------------------------------------------------
# Lite23 automatic disk-backed satellite-video timeshift with persistent IPTV audio relay.
#
# Architecture:
#   * No PAUSE interception at all.
#   * No session.open() controller and no hidden current_dialog.
#   * After IPTV-audio-only remux is ready, satellite TS recording starts and
#     VIDEO_FREEZE is issued immediately while IPTV audio keeps running.
#   * XKlass dialogs are unwound back to the real InfoBar before any key map is
#     armed. Only OK is captured while paused; LEFT/RIGHT are captured only
#     after delayed playback starts. MENU/PLUGINS remain owned by Enigma2.
#   * Counter is an instantiateDialog overlay and is deleted, not merely hidden.
#   * Lite22 consumes sync keys before InfoBar zap handling: 0.5s/press.
#   * DVB recorder watchdog reconnects in append mode on the SAME HDD TS file.
# ---------------------------------------------------------------------------
_AUTO = None


class XKlass_Remux_TimeshiftOverlay(Screen):
    # Lite22 R2: larger two-line rectangle for sofa-distance sync adjustment.
    # The first line is intentionally large and dedicated to the current delay;
    # the second line shows the available buffer and remote shortcuts.
    skin = '''
    <screen name="XKlassRemuxTimeshiftOverlay" position="center,470" size="850,126" backgroundColor="#00000000" flags="wfNoBorder">
        <widget name="counter" position="10,8" size="830,68" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#D0002040" halign="center" valign="center" />
        <widget name="hint" position="10,78" size="830,40" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#D0002040" halign="center" valign="center" />
    </screen>
    '''

    def __init__(self, session):
        Screen.__init__(self, session)
        self["counter"] = Label("")
        self["hint"] = Label("")


def begin_auto_timeshift(session, minimum_seconds=1):
    """Start the automatic satellite-video buffer for IPTV-audio-only mode."""
    global _AUTO
    try:
        if _AUTO is not None:
            _AUTO.shutdown()
    except Exception:
        pass
    try:
        _AUTO = _AutoTimeshift(session, minimum_seconds)
        return _AUTO.start()
    except Exception as e:
        _AUTO = None
        try:
            with open('/tmp/xklass-timeshift.log', 'a') as f:
                f.write('%s auto-timeshift start failed: %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), str(e)))
        except Exception:
            pass
        return False


def stop_auto_timeshift():
    """Stop the singleton controller before a Local Remux teardown/restart.

    R7 makes this explicit so an old 250ms watchdog cannot survive long enough
    to operate on the state of a newly-started remux session.
    """
    global _AUTO
    obj = _AUTO
    if obj is None:
        return False
    try:
        obj.shutdown()
    except Exception:
        try:
            _AUTO = None
        except Exception:
            pass
    return True


def schedule_video_hold(session, minimum_seconds=1):
    """Compatibility shim: Lite19 no longer intercepts PAUSE on plugin exit."""
    global _AUTO
    try:
        if _AUTO is not None:
            _AUTO.minimum = max(1, int(minimum_seconds))
    except Exception:
        pass
    return True


def _auto_released(obj):
    global _AUTO
    if _AUTO is obj:
        _AUTO = None


class _AutoTimeshift(object):
    def __init__(self, session, minimum_seconds=1):
        self.session = session
        try:
            self.minimum = max(1, int(minimum_seconds))
        except Exception:
            self.minimum = 1
        self._closed = False
        self._paused = True
        self._resolving = False
        self._handover_started = False
        self._operation = ''
        self._requested_delay = None
        self._queued_delay = None
        self._resolved_done = False
        self._resolved_error = ''
        self._resolved_url = ''
        self._resolved_headers = {}
        self._resolved_context = {}
        self._client = None
        self._overlay = None
        self._actions_armed = False
        self._pause_enforce_last = 0.0
        self._pause_enforce_logged = False
        self._pause_enforce_count = 0
        self._raw_arrows_bound = False
        self._raw_arrow_callback = self._raw_arrow_event
        self._last_signal_state = 'ok'
        self._restored_notice_until = 0.0
        # R14 compatibility gate: never freeze/arm controls until the HDD buffer has
        # shown consecutive growth samples.  This prevents a live overlay on a
        # dead/empty buffer and avoids issuing VIDEO_FREEZE while the decoder is
        # still busy changing service ownership.
        self._preflight_last_size = 0
        self._preflight_stable = 0
        self._preflight_checks = 0
        self._freeze_failures = 0
        self._signal_loss_since = 0.0

        self._ok_actions = ActionMap(["OkCancelActions"], {"ok": self.ok_pressed}, -100)
        self._delay_actions = ActionMap(["DirectionActions"], {
            "right": self.delay_right,
            "left": self.delay_left,
        }, -100)
        try:
            self._ok_actions.setEnabled(False)
            self._delay_actions.setEnabled(False)
        except Exception:
            pass

        self._tick = eTimer()
        try:
            self._tick_conn = self._tick.timeout.connect(self._tick_status)
        except Exception:
            self._tick.callback.append(self._tick_status)

        self._unwind = eTimer()
        try:
            self._unwind_conn = self._unwind.timeout.connect(self._unwind_step)
        except Exception:
            self._unwind.callback.append(self._unwind_step)

        self._resolve_timer = eTimer()
        try:
            self._resolve_conn = self._resolve_timer.timeout.connect(self._poll_resolve)
        except Exception:
            self._resolve_timer.callback.append(self._poll_resolve)

        self._adjust_timer = eTimer()
        try:
            self._adjust_conn = self._adjust_timer.timeout.connect(self._apply_queued_delay)
        except Exception:
            self._adjust_timer.callback.append(self._apply_queued_delay)

        self._overlay_timer = eTimer()
        try:
            self._overlay_conn = self._overlay_timer.timeout.connect(self._hide_counter)
        except Exception:
            self._overlay_timer.callback.append(self._hide_counter)

        self._delayed_resume_timer = None
        self._delayed_resume_conn = None

        # R7: do not freeze the DVB decoder while Enigma2 is still switching
        # from the IPTV preview/local service into the satellite-video remux.
        # The first freeze is delayed until we are back on the real InfoBar,
        # giving the decoder one full settling window to display a satellite frame.
        self._initial_freeze_pending = True
        self._initial_freeze_attempts = 0
        self._initial_freeze_timer = eTimer()
        try:
            self._initial_freeze_conn = self._initial_freeze_timer.timeout.connect(self._apply_initial_freeze)
        except Exception:
            self._initial_freeze_timer.callback.append(self._apply_initial_freeze)

    def _log(self, text):
        try:
            with open('/tmp/xklass-timeshift.log', 'a') as f:
                f.write('%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), str(text)))
        except Exception:
            pass

    def start(self):
        from .remux import start_video_timeshift_recording
        # R7 records immediately but deliberately does NOT touch VIDEO_FREEZE yet.
        # Freezing while playService() is still changing decoder ownership can
        # preserve the old IPTV preview frame and can stress vendor DVB drivers.
        ok, error = start_video_timeshift_recording(self.minimum, freeze_now=False)
        if not ok:
            self._log('automatic recorder failed: %s' % error)
            try:
                self.session.open(MessageBox, "Unable to start IPAudio AlQuds satellite timeshift:\n%s" % error, MessageBox.TYPE_ERROR, timeout=7)
            except Exception:
                pass
            self.shutdown()
            return False
        self._log('automatic HDD timeshift recording started; waiting for satellite frame before first freeze')
        self._tick.start(250, False)
        self._unwind.start(80, False)
        return True

    def _enforce_timeshift_pause(self, force=False):
        """Avoid repeated vendor DVB VIDEO_FREEZE ioctls."""
        if self._closed or not self._paused or self._handover_started:
            return False
        # While the initial R7 settling timer owns the first freeze, the 250ms
        # watchdog must not race it with another ioctl.
        if self._initial_freeze_pending:
            return False
        try:
            from .remux import video_hold_status, freeze_remux_video
            held, _started, _minimum = video_hold_status()
            if held:
                if not self._pause_enforce_logged:
                    self._pause_enforce_logged = True
                    self._log('satellite video remains paused; no repeated DVB freeze ioctl')
                return True
            if self._pause_enforce_count >= 1:
                return False
            self._pause_enforce_count = 1
            ok = bool(freeze_remux_video(0.0))
            if ok and not self._pause_enforce_logged:
                self._pause_enforce_logged = True
                self._log('satellite video paused by one fallback freeze')
            return ok
        except Exception as e:
            self._log('timeshift video pause check failed: %s' % e)
            return False

    def _abort_timeshift_keep_live(self, reason):
        """Fail safe to the proven R9 live remux instead of leaving black video."""
        try:
            from .remux import cancel_video_timeshift_keep_remux
            cancel_video_timeshift_keep_remux(reason)
        except Exception as e:
            self._log('R14 fail-safe cleanup error: %s' % e)
        self._hide_counter()
        self._log('R14 timeshift fail-safe -> live Local Remux: %s' % reason)
        self.shutdown()

    def _apply_initial_freeze(self):
        if self._closed or not self._paused or self._handover_started:
            return
        if not self._initial_freeze_pending:
            return

        # R13: require real MPEG-TS sync plus recent HDD growth before touching the DVB decoder.
        # The old code could freeze after a timer alone even when the recorder
        # was already stalled, producing a black screen with a live overlay.
        try:
            from .remux import timeshift_buffer_health
            ready, size, age, rate = timeshift_buffer_health()
        except Exception as e:
            ready, size, age, rate = False, 0, 999.0, 0.0
            self._log('R14 buffer health check failed: %s' % e)

        self._preflight_checks += 1
        if ready and size > self._preflight_last_size:
            self._preflight_stable += 1
        else:
            self._preflight_stable = 0
        self._preflight_last_size = int(size or 0)

        if self._preflight_stable < 3:
            if self._preflight_checks >= 24:
                self._initial_freeze_pending = False
                self._abort_timeshift_keep_live(
                    'HDD buffer never became stable (size=%d age=%.1fs rate=%.0fB/s)' %
                    (int(size or 0), float(age or 0.0), float(rate or 0.0)))
                return
            try:
                self._initial_freeze_timer.start(500, True)
                if self._preflight_checks in (1, 4, 8, 12):
                    self._log('R14 freeze gate waiting for valid/stable TS buffer: sample=%d/3 size=%d age=%.2fs rate=%.0fB/s' %
                              (self._preflight_stable, int(size or 0), float(age or 0.0), float(rate or 0.0)))
                return
            except Exception as e:
                self._initial_freeze_pending = False
                self._abort_timeshift_keep_live('freeze gate timer failed: %s' % e)
                return

        # Buffer is healthy.  Only now attempt VIDEO_FREEZE.  A busy decoder is
        # retried with generous spacing; controls are never armed on failure.
        self._initial_freeze_attempts += 1
        try:
            from .remux import freeze_remux_video
            ok = bool(freeze_remux_video(0.0))
        except Exception as e:
            ok = False
            self._log('initial deferred freeze failed: %s' % e)
        if ok:
            self._initial_freeze_pending = False
            self._pause_enforce_count = 1
            self._arm_actions()
            # R14: bind a direct KEY_OK fallback now. The existing ActionMap is
            # retained; whichever path receives OK first starts the same guarded
            # resume_request(), while repeats are ignored by _resolving.
            self._bind_raw_arrows()
            self._update_counter()
            self._log('R14 valid stable TS + satellite frame frozen; OK armed (ActionMap + raw KEY_OK)')
            return

        self._freeze_failures += 1
        if self._freeze_failures < 3:
            try:
                self._initial_freeze_timer.start(1200, True)
                self._log('R14 VIDEO_FREEZE busy/unavailable; retry %d/3 scheduled in 1200ms' %
                          (self._freeze_failures + 1))
                return
            except Exception:
                pass

        self._initial_freeze_pending = False
        self._abort_timeshift_keep_live('DVB VIDEO_FREEZE remained busy after 3 stable-buffer attempts')

    def _infobar(self):
        try:
            from Screens.InfoBar import InfoBar
            return getattr(InfoBar, 'instance', None)
        except Exception:
            return None

    def _on_infobar(self):
        try:
            ib = self._infobar()
            return ib is not None and self.session.current_dialog is ib
        except Exception:
            return False

    def _is_xklass_dialog(self, dlg):
        if dlg is None:
            return False
        try:
            cls = dlg.__class__
            module = str(getattr(cls, '__module__', '') or '')
            name = str(getattr(cls, '__name__', '') or '')
            return ('Plugins.Extensions.XKlass' in module) or name.startswith('XKlass_')
        except Exception:
            return False

    def _unwind_step(self):
        if self._closed:
            return
        if self._on_infobar():
            try:
                self._unwind.stop()
            except Exception:
                pass
            # R7: returning to InfoBar is not proof that a NEW satellite frame
            # has reached the hardware plane.  Wait 900ms before the first
            # VIDEO_FREEZE so the old IPTV preview cannot be the frozen frame.
            if self._initial_freeze_pending:
                try:
                    self._initial_freeze_timer.stop()
                except Exception:
                    pass
                self._initial_freeze_timer.start(2200, True)
                self._log('returned to InfoBar; R14 settling decoder/buffer for 2200ms before stable-gated freeze')
            else:
                self._arm_actions()
                self._update_counter()
            return
        try:
            dlg = self.session.current_dialog
        except Exception:
            dlg = None
        closeable = self._is_xklass_dialog(dlg)
        if not closeable and dlg is not None:
            try:
                cls = dlg.__class__
                module = str(getattr(cls, '__module__', '') or '')
                name = str(getattr(cls, '__name__', '') or '')
                # If XKlass was launched from the normal Plugins browser, close
                # that browser too so the user lands directly on live TV.
                closeable = (module == 'Screens.PluginBrowser' and name == 'PluginBrowser')
            except Exception:
                closeable = False
        if closeable:
            try:
                dlg.close()
                return
            except Exception as e:
                self._log('dialog close failed: %s' % e)
        # Do not close any other foreign Enigma2 dialog. Wait for it to disappear.

    def _bind_raw_arrows(self):
        """Consume LEFT/RIGHT before Enigma2 can interpret them as zap keys.

        The callback is global but returns 0 for every key unless delayed
        timeshift playback is active on the real InfoBar. KEY_LEFT/KEY_RIGHT are
        Linux input key codes 105/106. Only the key-down event changes delay;
        repeats/releases are swallowed so one press always equals exactly 0.5s.
        """
        if self._raw_arrows_bound or eActionMap is None:
            return self._raw_arrows_bound
        try:
            eActionMap.getInstance().bindAction('', -0x7FFFFFFF, self._raw_arrow_callback)
            self._raw_arrows_bound = True
            self._log('R14 raw remote-control guard bound at highest priority')
            return True
        except Exception as e:
            self._log('R14 raw remote-control guard bind failed: %s' % e)
            self._raw_arrows_bound = False
            return False

    def _unbind_raw_arrows(self):
        if not self._raw_arrows_bound or eActionMap is None:
            self._raw_arrows_bound = False
            return
        try:
            eActionMap.getInstance().unbindAction('', self._raw_arrow_callback)
        except Exception as e:
            self._log('R14 raw remote-control guard unbind failed: %s' % e)
        self._raw_arrows_bound = False

    def _raw_arrow_event(self, key, flag):
        try:
            key = int(key)
            flag = int(flag)
        except Exception:
            return 0
        # Linux input key codes: KEY_OK=352 (some vendor remotes expose ENTER=28);
        # 1=2, 3=4, 4=5, 6=7, 7=8, 9=10, LEFT=105, RIGHT=106.  R14 binds KEY_OK directly while the
        # initial frozen frame is waiting, because some OpenATV 8/ARM keymaps
        # let InfoBar consume OkCancelActions before our detached ActionMap sees it.
        if key not in (2, 4, 5, 7, 8, 10, 28, 105, 106, 352):
            return 0

        try:
            from .remux import is_local_remux_active, timeshift_playback_active
            active = is_local_remux_active()
            delayed = timeshift_playback_active()
        except Exception:
            active = delayed = False

        if key in (28, 352):
            eligible_ok = (self._on_infobar() and self._paused and active
                           and not self._initial_freeze_pending and not self._resolving)
            if not eligible_ok:
                return 0
            # Consume make/repeat/break, but start exactly once on key-down.
            if flag == 0:
                self._log('R14 raw OK key=%s received; starting delayed-video handover' % key)
                self.resume_request()
            return 1

        eligible = (self._on_infobar() and not self._paused and active and delayed)
        if not eligible:
            return 0
        # Consume make/repeat/break. Adjust only on make so a held key cannot
        # launch repeated seeks. Numeric shortcuts use larger, practical steps.
        if flag == 0 and not self._resolving:
            delta_map = {
                106: +0.5, 105: -0.5,
                4: +10.0, 2: -10.0,
                7: +5.0, 5: -5.0,
                10: +2.0, 8: -2.0,
            }
            delta = delta_map.get(key)
            if delta is not None:
                self._queue_delay(delta)
        return 1

    def _arm_actions(self):
        if self._actions_armed:
            self._sync_actions()
            return
        try:
            self._ok_actions.execBegin()
            self._delay_actions.execBegin()
            self._actions_armed = True
        except Exception as e:
            self._log('ActionMap arm failed: %s' % e)
        self._sync_actions()

    def _sync_actions(self):
        on_info = self._on_infobar()
        try:
            from .remux import is_local_remux_active, timeshift_playback_active
            active = is_local_remux_active()
            delayed = timeshift_playback_active()
        except Exception:
            active = delayed = False
        try:
            # OK starts playback while initially paused; once delayed playback is
            # active it becomes the user's explicit "show sync panel" key.
            self._ok_actions.setEnabled(bool(on_info and active and (self._paused or delayed) and not self._resolving))
            if on_info and active and delayed and not self._paused:
                self._bind_raw_arrows()
            # Fallback DirectionActions is used only if raw eActionMap binding is
            # unavailable. When raw guard is active it alone owns LEFT/RIGHT.
            self._delay_actions.setEnabled(bool(on_info and active and delayed and not self._paused and not self._resolving and not self._raw_arrows_bound))
        except Exception:
            pass

    def _ensure_overlay(self):
        if self._overlay is not None:
            return self._overlay
        try:
            self._overlay = self.session.instantiateDialog(XKlass_Remux_TimeshiftOverlay)
            return self._overlay
        except Exception as e:
            self._log('overlay create failed: %s' % e)
            self._overlay = None
            return None

    def _set_counter(self, text, auto_hide_ms=0, hint=''):
        if not self._on_infobar():
            self._hide_counter()
            return
        try:
            self._overlay_timer.stop()
        except Exception:
            pass
        overlay = self._ensure_overlay()
        if overlay is None:
            return
        try:
            overlay['counter'].setText(str(text))
            overlay['hint'].setText(str(hint or ''))
            overlay.show()
        except Exception:
            pass
        if auto_hide_ms:
            try:
                self._overlay_timer.start(int(auto_hide_ms), True)
            except Exception:
                pass

    def _hide_counter(self):
        overlay = self._overlay
        self._overlay = None
        if overlay is None:
            return
        try:
            overlay['counter'].setText('')
            overlay['hint'].setText('')
            overlay.hide()
        except Exception:
            pass
        try:
            self.session.deleteDialog(overlay)
        except Exception:
            pass

    def _update_counter(self):
        if not self._paused:
            return
        try:
            from .remux import video_timeshift_status
            rec, _playback, _held, elapsed, size, _path = video_timeshift_status()
            if not rec:
                self._set_counter('TIMESHIFT RECORDER STOPPED', 1800)
                return
            self._set_counter('TIMESHIFT REC  %02d:%02d   %.1f MB' % (
                int(elapsed) // 60, int(elapsed) % 60, size / 1048576.0),
                hint='OK = START VIDEO   •   IPTV AUDIO CONTINUES')
        except Exception:
            pass

    def ok_pressed(self):
        """OK starts the initial delayed playback, then shows the large sync HUD."""
        if self._closed or not self._on_infobar() or self._resolving:
            return 1
        if self._paused:
            self._log('R14 ActionMap OK received; starting delayed-video handover')
            return self.resume_request()
        self._show_sync_panel(7000)
        return 1

    def _show_sync_panel(self, auto_hide_ms=7000, prefix='SAT DELAY'):
        try:
            from .remux import timeshift_delay_status
            active, delay, available = timeshift_delay_status()
            if not active:
                return
            mins = int(available) // 60
            secs = int(available) % 60
            self._set_counter('%s   %.1f s' % (str(prefix), float(delay)), auto_hide_ms,
                              'BUFFER %02d:%02d   •   3/1 ±10s   6/4 ±5s   9/7 ±2s   ←/→ ±0.5s' % (mins, secs))
        except Exception as e:
            self._log('sync panel failed: %s' % e)

    def resume_request(self):
        if self._closed or not self._on_infobar() or not self._paused or self._resolving:
            return 1
        try:
            from .remux import video_timeshift_status, timeshift_signal_status
            lost, _delay = timeshift_signal_status()
            if lost:
                self._set_counter('SIGNAL LOST  •  BUFFER HOLD')
                return 1
            rec, _playback, _held, elapsed, size, _path = video_timeshift_status()
            if not rec:
                self._set_counter('TIMESHIFT RECORDER STOPPED', 1800)
                return 1
            if elapsed < float(self.minimum) or size < 188 * 200:
                self._set_counter('TIMESHIFT BUFFERING  %02d:%02d' % (int(elapsed) // 60, int(elapsed) % 60))
                wait_ms = max(100, int((float(self.minimum) - elapsed) * 1000))
                try:
                    if self._delayed_resume_timer is not None:
                        self._delayed_resume_timer.stop()
                except Exception:
                    pass
                t = eTimer()
                self._delayed_resume_timer = t
                try:
                    self._delayed_resume_conn = t.timeout.connect(self.resume_request)
                except Exception:
                    t.callback.append(self.resume_request)
                t.start(wait_ms, True)
                return 1
        except Exception as e:
            self._log('resume status failed: %s' % e)
            return 1
        self._begin_resolve('resume', None)
        return 1

    def delay_right(self):
        self._queue_delay(+0.5)
        return 1

    def delay_left(self):
        self._queue_delay(-0.5)
        return 1

    def _queue_delay(self, delta):
        if self._closed or not self._on_infobar() or self._paused or self._resolving:
            return
        try:
            from .remux import timeshift_delay_status, timeshift_signal_status
            lost, _saved = timeshift_signal_status()
            if lost:
                self._set_counter('SIGNAL LOST  •  BUFFER HOLD')
                return
            active, current, elapsed = timeshift_delay_status()
            if not active:
                return
            base = float(self._queued_delay) if self._queued_delay is not None else float(current)
            target = max(0.5, base + float(delta))
            target = round(target * 2.0) / 2.0
            self._queued_delay = target
            maximum_now = max(0.5, float(elapsed) - 0.25)
            if target > maximum_now:
                self._set_counter('SAT DELAY TARGET   %.1f s' % target, 7000,
                                  'BUFFERING %.1f / %.1f s   •   3/1 ±10s   6/4 ±5s   9/7 ±2s   ←/→ ±0.5s' % (maximum_now, target))
            else:
                self._set_counter('SAT DELAY   %.1f s' % target, 7000,
                                  '3/1 ±10s   •   6/4 ±5s   •   9/7 ±2s   •   ←/→ ±0.5s')
            try:
                self._adjust_timer.stop()
            except Exception:
                pass
            self._adjust_timer.start(800, True)
        except Exception as e:
            self._log('delay queue failed: %s' % e)

    def _apply_queued_delay(self):
        if self._queued_delay is None or self._closed or not self._on_infobar() or self._paused or self._resolving:
            return
        target = float(self._queued_delay)
        try:
            from .remux import timeshift_delay_status, timeshift_signal_status
            lost, _saved = timeshift_signal_status()
            if lost:
                self._set_counter('SIGNAL LOST  •  BUFFER HOLD')
                self._adjust_timer.start(1000, True)
                return
            active, _current, elapsed = timeshift_delay_status()
            if not active:
                return
            maximum_now = max(0.5, float(elapsed) - 0.25)
            # Positive large jumps can exceed the amount already recorded. Keep
            # the exact requested target and wait for the HDD buffer to grow
            # instead of silently shrinking +10s into +2.5s, for example.
            if target > maximum_now:
                self._set_counter('SAT DELAY TARGET   %.1f s' % target, 7000, 'BUFFERING %.1f / %.1f s' % (maximum_now, target))
                self._adjust_timer.start(500, True)
                return
        except Exception as e:
            self._log('delay availability check failed: %s' % e)
        self._set_counter('SAT DELAY   %.1f s' % target, 7000, 'APPLYING VIDEO ONLY ...  •  IPTV AUDIO STAYS LIVE')
        try:
            from .remux import adjust_timeshift_video_delay
            ok, effective, error = adjust_timeshift_video_delay(target)
            self._queued_delay = None
            if ok:
                self._set_counter('SAT DELAY   %.1f s' % float(effective), 7000,
                                  'AUDIO UNTOUCHED   •   3/1 ±10s   6/4 ±5s   9/7 ±2s   ←/→ ±0.5s')
                self._log('dynamic video-only delay applied %.1fs' % float(effective))
            else:
                self._set_counter('VIDEO ADJUST ERROR', 3000, str(error or 'Unable to adjust satellite video'))
                self._log('dynamic video-only delay failed: %s' % str(error or 'unknown'))
        except Exception as e:
            self._queued_delay = None
            self._set_counter('VIDEO ADJUST ERROR', 3000, str(e))
            self._log('dynamic video-only delay exception: %s' % e)

    def _begin_resolve(self, operation, target_delay):
        if self._resolving:
            return
        self._resolving = True
        self._handover_started = False
        self._operation = str(operation or 'resume')
        self._log('R14 resolve/handover request accepted operation=%s target_delay=%s' % (self._operation, str(target_delay)))
        self._requested_delay = target_delay
        self._resolved_done = False
        self._resolved_error = ''
        self._resolved_url = ''
        self._resolved_headers = {}
        self._resolved_context = {}
        if self._operation == 'resume':
            self._set_counter('TIMESHIFT  starting delayed video ...')
        self._sync_actions()
        t = threading.Thread(target=self._resolve_worker)
        t.daemon = True
        t.start()
        self._resolve_timer.start(100, False)

    def _resolve_worker(self):
        """Resolve one fresh provider URL for the first delayed-video handover."""
        try:
            from .remux import get_resume_context, get_active_iptv_source
            context = get_resume_context() or {}
            source_info = get_active_iptv_source() or {}
            channels = list(context.get('channels') or [])
            idx = int(context.get('selected_index') or 0) if channels else -1
            value = ''
            if 0 <= idx < len(channels):
                item = channels[idx]
                if isinstance(item, dict):
                    value = str(item.get('value') or item.get('url') or item.get('cmd') or '')
                elif isinstance(item, (list, tuple)) and len(item) >= 2:
                    value = str(item[1])
            source_kind = str(context.get('source') or '').lower()

            if source_kind == 'stalker':
                if not value:
                    raise RuntimeError('Active Stalker channel command is missing')
                from .stalker import StalkerClient
                self._client = StalkerClient(dict(context.get('portal') or {}))
                self._resolved_url = self._client.create_link(value)
                self._resolved_headers = dict(getattr(self._client, 'headers', {}) or {})
            elif source_kind == 'xtream':
                self._resolved_url = value or str(source_info.get('url') or '')
                self._resolved_headers = {'User-Agent': str(cfg.useragent.value)}
            else:
                self._resolved_url = str(source_info.get('url') or value or '')
                self._resolved_headers = dict(source_info.get('headers') or {})

            if not self._resolved_url:
                raise RuntimeError('Could not resolve IPTV stream for delayed playback')
            self._resolved_context = context or dict(source_info.get('context') or {})
            if source_info.get('name') and not self._resolved_context.get('channel_name'):
                self._resolved_context['channel_name'] = str(source_info.get('name'))
            if source_info.get('mode'):
                self._resolved_context['mode'] = str(source_info.get('mode'))
        except Exception as e:
            self._resolved_error = str(e)
        self._resolved_done = True

    def _poll_resolve(self):
        if self._closed or not self._resolved_done:
            return
        try:
            self._resolve_timer.stop()
        except Exception:
            pass
        if self._resolved_error:
            msg = self._resolved_error
            self._resolving = False
            self._operation = ''
            self._requested_delay = None
            self._queued_delay = None
            self._sync_actions()
            self._set_counter('TIMESHIFT ERROR', 1800)
            self._log('resolve failed: %s' % msg)
            return
        try:
            from .remux import handover_local_remux
            context = dict(self._resolved_context or {})
            name = str(context.get('channel_name') or 'IPTV')
            mode = str(context.get('mode') or 'iptv')
            handover_local_remux(
                self.session, self._resolved_url, name, mode,
                iptv_headers=dict(self._resolved_headers or {}),
                resume_context=context,
                satellite_source='timeshift',
                target_delay=self._requested_delay
            )
            self._handover_started = True
        except Exception as e:
            self._resolving = False
            self._handover_started = False
            self._operation = ''
            self._requested_delay = None
            self._queued_delay = None
            self._sync_actions()
            self._set_counter('TIMESHIFT ERROR', 1800)
            self._log('handover start failed: %s' % e)

    def _finish_handover(self):
        self._resolving = False
        self._handover_started = False
        self._operation = ''
        self._requested_delay = None
        self._paused = False
        self._queued_delay = None
        try:
            from .remux import timeshift_delay_status
            active, delay, _elapsed = timeshift_delay_status()
        except Exception:
            active, delay = False, 0.0
        if active:
            self._bind_raw_arrows()
            self._show_sync_panel(5000)
        else:
            self._hide_counter()
        self._sync_actions()
        self._log('delayed satellite video started')

    def _tick_status(self):
        if self._closed:
            return
        try:
            from .remux import (
                is_local_remux_active, handover_status, timeshift_playback_active,
                maintain_video_timeshift_recording, timeshift_delay_status,
            )
            if not is_local_remux_active():
                self.shutdown()
                return

            # Lite21 satellite-signal watchdog. It only replaces the DVB->HDD
            # recorder and appends to the SAME TS file; it never tears down IPTV
            # audio, the delayed tail, or the current local remux service.
            signal_state, _size = maintain_video_timeshift_recording(5.5, 1.5)
            previous_signal = self._last_signal_state
            self._last_signal_state = signal_state

            # R13: tolerate longer recorder reconnects across OpenATV/BusyBox variants, but a sustained loss
            # while the picture is held must never leave a black screen with a
            # live timeshift overlay.  Fall back to the proven live remux.
            if self._paused and not self._handover_started:
                if signal_state in ('lost', 'reconnecting'):
                    if not self._signal_loss_since:
                        self._signal_loss_since = time.time()
                    elif (time.time() - self._signal_loss_since) >= 9.0:
                        self._abort_timeshift_keep_live('satellite HDD buffer stalled for >9.0s while paused')
                        return
                else:
                    self._signal_loss_since = 0.0

            if self._paused and not self._handover_started:
                self._enforce_timeshift_pause(False)
            if not self._actions_armed and self._on_infobar() and not self._initial_freeze_pending:
                self._arm_actions()
            self._sync_actions()
            if not self._on_infobar():
                self._hide_counter()
                return

            if signal_state in ('lost', 'reconnecting'):
                text = 'SIGNAL LOST  •  RECONNECTING' if signal_state == 'reconnecting' else 'SIGNAL LOST  •  BUFFER HOLD'
                self._set_counter(text)
            elif signal_state == 'restored':
                try:
                    _active, delay, _available = timeshift_delay_status()
                except Exception:
                    delay = 0.0
                if self._paused:
                    self._set_counter('SIGNAL RESTORED  •  TIMESHIFT REC', 1800)
                else:
                    self._set_counter('SYNC RESTORED  •  %.1fs' % float(delay), 2200)
                self._restored_notice_until = time.time() + 2.2
            elif self._paused and not self._initial_freeze_pending:
                self._update_counter()
            elif time.time() >= float(self._restored_notice_until or 0.0):
                # Do not leave a stale reconnect overlay on screen after growth
                # resumes. Normal delay overlay is shown only on user actions.
                if previous_signal in ('lost', 'reconnecting', 'restored'):
                    self._hide_counter()

            if self._resolving and self._handover_started:
                active, _err, _source = handover_status()
                if not active:
                    if timeshift_playback_active():
                        self._finish_handover()
                    else:
                        self._resolving = False
                        self._handover_started = False
                        self._operation = ''
                        self._requested_delay = None
                        self._queued_delay = None
                        self._sync_actions()
                        if signal_state in ('lost', 'reconnecting'):
                            self._set_counter('SIGNAL LOST  •  BUFFER HOLD')
                        else:
                            self._update_counter()
        except Exception as e:
            self._log('tick error: %s' % e)

    def shutdown(self):
        if self._closed:
            return
        self._closed = True
        for timer in (self._tick, self._unwind, self._resolve_timer, self._adjust_timer, self._overlay_timer, self._delayed_resume_timer, self._initial_freeze_timer):
            if timer is not None:
                try:
                    timer.stop()
                except Exception:
                    pass
        self._hide_counter()
        self._unbind_raw_arrows()
        if self._actions_armed:
            try:
                self._delay_actions.execEnd()
            except Exception:
                pass
            try:
                self._ok_actions.execEnd()
            except Exception:
                pass
        self._actions_armed = False
        _auto_released(self)
        self._log('automatic timeshift controller stopped')


# Backwards-compatible class name; it is no longer opened as a Screen in Lite21.
XKlass_Remux_VideoHold = XKlass_Remux_TimeshiftOverlay
