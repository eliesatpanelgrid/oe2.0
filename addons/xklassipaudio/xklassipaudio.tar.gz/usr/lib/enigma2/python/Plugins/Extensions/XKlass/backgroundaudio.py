#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Persistent IPTV background audio for XKlass (R31P7 Vu+ independent ALSA).

Design goal:
* keep the Enigma2 DVB service as the main service, so satellite video and
  native timeshift continue to work;
* keep satellite video and native Enigma2 timeshift owned by Enigma2;
* on Vu+ ask the current Enigma2 service itself to release ONLY its audio PID
  via setQpipMode(False, audio=False), which cleanly closes the satellite audio
  decoder without putting the main service in QPiP mode;
* keep the proven FFmpeg MP2/MPEG-TS local bridge, but render its audio through
  an explicit ALSA GStreamer sink on Vu+.  Unlike dvbaudiosink, this PCM path is
  not paused by the Broadcom DVB decoder when native Timeshift changes state;
* keep the previous generic backends for non-Vu+ receivers.

This separation is important on receivers where AUDIO_SET_MUTE also silences
PCM produced by GStreamer/ServiceApp.
"""

import os
import re
import glob
import fcntl
import shutil
import socket
import subprocess
import threading
import time

from enigma import eTimer
try:
    from enigma import eActionMap
except Exception:
    eActionMap = None

_LOCK = threading.RLock()
_DEVNULL_R = None
_DEVNULL_W = None
_TIMER = None
_TIMER_CONN = None
_KEY_TIMER = None
_KEY_TIMER_CONN = None
_KEY_BOUND = False
_NAMED_KEY_BOUND = False
_VU_HANDOFF_TIMER = None
_VU_HANDOFF_TIMER_CONN = None
_STOP_TIMER = None
_STOP_TIMER_CONN = None
_LOG = "/tmp/xklass-backgroundaudio.log"

_STATE = {
    "wanted": False,
    "session": None,
    "name": "",
    "url": "",
    "backend": "",
    "procs": [],
    "dvb_stopped": False,
    "dvb_devices": [],
    "last_service": "",
    "restart_due": 0.0,
    "restarting": False,
    "error": "",
    "error_reported": False,
    "headers": {},
    "retry_resolver": None,
    "bridge_port": 0,
    "e2_audio_disabled": False,
    "resume_context": {},
    "sink_retry_count": 0,
    "sink_handoff_until": 0.0,
    "vu_handoff_phase": "",
    "vu_handoff_action": "",
    "vu_handoff_started": 0.0,
    "vu_video_paused": False,
}


def _log(message):
    try:
        with open(_LOG, "a") as f:
            f.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), str(message)))
    except Exception:
        pass


def _find_executable(names):
    for name in names:
        try:
            path = shutil.which(name)
        except Exception:
            path = None
        if path and os.path.isfile(path) and os.access(path, os.X_OK):
            return path
        for base in ("/usr/bin", "/bin", "/usr/local/bin"):
            candidate = os.path.join(base, name)
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                return candidate
    return ""


def configured_audio_delay_ms():
    """Return the persisted IPAUDIO delay, clamped for old-image safety."""
    try:
        from .plugin import cfg
        value = int(getattr(cfg, "ipaudiodelayms").value)
    except Exception:
        value = 0
    return max(0, min(10000, value))


def _audio_filter_chain(include_resample=False):
    """Build a FFmpeg 4.4-compatible audio filter chain.

    adelay inserts real silence instead of only shifting timestamps.  That is
    important for a live UDP bridge because a timestamp-only offset can be
    normalised away when GStreamer establishes its clock.
    """
    filters = []
    delay_ms = configured_audio_delay_ms()
    if delay_ms > 0:
        filters.append("adelay=delays=%d:all=1" % delay_ms)
    if include_resample:
        filters.append("aresample=async=1:first_pts=0")
    return ",".join(filters)


def _append_audio_filter(args, include_resample=False):
    chain = _audio_filter_chain(include_resample=include_resample)
    if chain:
        args += ["-af", chain]
    return args


def _devnull(read=False):
    global _DEVNULL_R, _DEVNULL_W
    if read:
        if _DEVNULL_R is None or getattr(_DEVNULL_R, "closed", False):
            _DEVNULL_R = open(os.devnull, "rb")
        return _DEVNULL_R
    if _DEVNULL_W is None or getattr(_DEVNULL_W, "closed", False):
        _DEVNULL_W = open(os.devnull, "wb")
    return _DEVNULL_W


def clean_stream_url(command):
    value = str(command or "").strip()
    if not value:
        return ""
    match = re.search(r"(?:https?|rtsp|rtmp|rtp|udp)://[^\s\"\']+", value, re.I)
    if match:
        return match.group(0).strip()
    for prefix in ("ffmpeg ", "ffrt ", "auto "):
        if value.lower().startswith(prefix):
            value = value[len(prefix):].strip()
            break
    return value


# Linux DVB audio ioctls from <linux/dvb/audio.h> on common Enigma2 kernels.
# AUDIO_STOP stops only the DVB audio decoder; unlike AUDIO_SET_MUTE it should
# not mute an independent ALSA PCM path.
AUDIO_STOP = 0x6F01
AUDIO_PLAY = 0x6F02
AUDIO_PAUSE = 0x6F03
AUDIO_CONTINUE = 0x6F04
AUDIO_SET_MUTE = 0x6F06


def _dvb_audio_devices():
    devices = []
    for pattern in ("/dev/dvb/adapter*/audio*", "/dev/dvb/card*/audio*"):
        for path in sorted(glob.glob(pattern)):
            if os.path.exists(path) and path not in devices:
                devices.append(path)
    return devices


def _ioctl_audio(path, request, arg=None):
    fd = None
    try:
        fd = os.open(path, os.O_RDWR | getattr(os, "O_NONBLOCK", 0))
        if arg is None:
            fcntl.ioctl(fd, request)
        else:
            fcntl.ioctl(fd, request, arg)
        return True
    except Exception as e:
        _log("DVB ioctl failed %s 0x%x: %s" % (path, int(request), e))
        return False
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except Exception:
                pass


def _set_dvb_decoder_stopped(stopped):
    """Stop/play only DVB audio decoding; never touch the global mixer."""
    devices = _dvb_audio_devices()
    success = False
    for path in devices:
        if stopped:
            # Clear a mute that could have been left by Lite11, then stop decode.
            _ioctl_audio(path, AUDIO_SET_MUTE, 0)
            if _ioctl_audio(path, AUDIO_STOP):
                success = True
        else:
            if _ioctl_audio(path, AUDIO_PLAY):
                success = True
            _ioctl_audio(path, AUDIO_SET_MUTE, 0)
    with _LOCK:
        _STATE["dvb_stopped"] = bool(stopped and success)
        _STATE["dvb_devices"] = devices
    if devices:
        _log("DVB audio %s on %s" % ("STOP" if stopped else "PLAY", ",".join(devices)))
    else:
        _log("No DVB audio device nodes found")
    return success


def _alsa_playback_devices():
    """Return ALSA PCM candidates discovered from both procfs and aplay -L.

    OpenATV/ARM images do not always expose /proc/asound/pcm even when named
    ALSA routes exist. R15 therefore tried only 'default' on the test box and
    immediately fell back to the Enigma2/GStreamer sink. R16 probes the image's
    own ALSA names before giving up, which is the best chance for a truly
    independent PCM path that keeps playing while native Timeshift pauses DVB.
    """
    # IPAudio 7.4's broadly deployed Enigma2 setup maps its default PCM to
    # card 0/device 0.  Probe those explicit routes even on images whose
    # /proc/asound/pcm file is absent (the R15 failure mode).
    candidates = ["plughw:0,0", "hw:0,0"]
    try:
        data = open("/proc/asound/pcm", "r").read().splitlines()
        for line in data:
            m = re.match(r"\s*(\d+)-(\d+):.*\bplayback\s+\d+", line, re.I)
            if not m:
                continue
            card = int(m.group(1))
            dev = int(m.group(2))
            for value in ("plughw:%d,%d" % (card, dev), "hw:%d,%d" % (card, dev)):
                if value not in candidates:
                    candidates.append(value)
    except Exception as e:
        _log("Unable to read /proc/asound/pcm: %s" % e)

    aplay = _find_executable(("aplay",))
    if aplay:
        try:
            proc = subprocess.Popen([aplay, "-L"], stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, close_fds=True)
            out, _err = proc.communicate()
            try:
                if not isinstance(out, str):
                    out = out.decode("utf-8", "ignore")
            except Exception:
                out = str(out or "")
            named = []
            for line in str(out or "").splitlines():
                if not line or line[:1].isspace():
                    continue
                name = line.strip()
                low = name.lower()
                if not name or low == "null":
                    continue
                if any(low.startswith(x) for x in ("hdmi", "iec958", "sysdefault", "default", "front", "dmix", "plug")):
                    named.append(name)
            # HDMI/digital and explicit card routes first; generic default last.
            named.sort(key=lambda x: (0 if x.lower().startswith(("hdmi", "iec958", "sysdefault")) else 1,
                                      1 if x.lower() == "default" else 0, x))
            for name in named[:16]:
                if name not in candidates:
                    candidates.append(name)
        except Exception as e:
            _log("aplay -L probe failed: %s" % e)

    if "default" not in candidates:
        candidates.append("default")
    _log("R31P7 ALSA candidates: %s" % (", ".join(candidates) if candidates else "none"))
    return candidates


def _is_independent_audio_backend(backend=None):
    """True only when IPTV sound is outside the DVB decoder ownership chain."""
    if backend is None:
        with _LOCK:
            backend = str(_STATE.get("backend") or "")
    return "ALSA-independent" in str(backend or "")


def _release_enigma_alsa_output():
    """Release Enigma2's optional ALSA singleton before opening our PCM sink.

    Some OpenATV/Vu+ builds export eAlsaOutput even though normal DVB playback
    uses dvbaudiosink.  IPAudio 7.4 closes this singleton before starting its
    ALSA renderer.  Do the same when available, without stopping or retuning
    the current DVB service.
    """
    try:
        from enigma import eAlsaOutput
        output = eAlsaOutput.getInstance()
        if output is None:
            return False
        for name in ("stop", "close"):
            method = getattr(output, name, None)
            if callable(method):
                method()
        _log("R31P7 released Enigma2 eAlsaOutput without service retune")
        return True
    except Exception as e:
        _log("R31P7 eAlsaOutput release unavailable: %s" % e)
        return False


def _current_service_string(session):
    try:
        ref = session.nav.getCurrentlyPlayingServiceReference() if session else None
        return ref.toString() if ref else ""
    except Exception:
        return ""


def _native_timeshift_enabled(session):
    """Read native Enigma2 Timeshift state without changing playback.

    OpenATV keeps the authoritative controller on InfoBar.  Older Enigma2
    images expose only iTimeshift on the current service, so retain that
    read-only fallback for the same IPK/Python source.
    """
    try:
        from Screens.InfoBar import InfoBar
        infobar = getattr(InfoBar, "instance", None)
        if infobar is not None:
            for name in ("timeshiftEnabled", "ptsGetTimeshiftStatus"):
                value = getattr(infobar, name, None)
                if callable(value):
                    value = value()
                if isinstance(value, (list, tuple)):
                    value = value[-1] if value else False
                if value:
                    return True
    except Exception:
        pass
    try:
        service = session.nav.getCurrentService() if session and getattr(session, "nav", None) else None
        getter = getattr(service, "timeshift", None)
        timeshift = getter() if callable(getter) else None
        enabled = getattr(timeshift, "isTimeshiftEnabled", None)
        return bool(enabled() if callable(enabled) else enabled)
    except Exception:
        return False


def _infobar_pause_state():
    """Return True/False for InfoBar Pause/Play, or None when unavailable."""
    try:
        from Screens.InfoBar import InfoBar
        infobar = getattr(InfoBar, "instance", None)
        if infobar is None:
            return None
        seekstate = getattr(infobar, "seekstate", None)
        pause_state = getattr(infobar, "SEEK_STATE_PAUSE", None)
        play_state = getattr(infobar, "SEEK_STATE_PLAY", None)
        if pause_state is not None and seekstate == pause_state:
            return True
        if play_state is not None and seekstate == play_state:
            return False
        if isinstance(seekstate, (list, tuple)) and seekstate:
            marker = str(seekstate[-1])
            if marker == "||":
                return True
            if marker == ">":
                return False
    except Exception:
        pass
    return None


def _is_dvb_service_string(service_ref):
    """Return True only for native Enigma2 DVB services.

    IPAudio is designed to sit beside a native satellite service (type 1).
    Streaming/file players use service types such as 4097/5001/5002 and need
    exclusive access to their own A/V pipeline.
    """
    value = str(service_ref or "").strip()
    if not value or ":" not in value:
        return False
    try:
        return int(value.split(":", 1)[0]) == 1
    except Exception:
        return False


def _terminate_procs(procs):
    for proc in reversed(list(procs or [])):
        try:
            if proc.poll() is None:
                proc.terminate()
        except Exception:
            pass
    for proc in reversed(list(procs or [])):
        try:
            if proc.poll() is None:
                proc.kill()
        except Exception:
            pass


def _stop_processes_only():
    with _LOCK:
        procs = list(_STATE.get("procs", []))
        _STATE["procs"] = []
        _STATE["backend"] = ""
        _STATE["bridge_port"] = 0
        _STATE["sink_retry_count"] = 0
        _STATE["sink_handoff_until"] = 0.0
        _STATE["vu_handoff_phase"] = ""
        _STATE["vu_handoff_action"] = ""
        _STATE["vu_handoff_started"] = 0.0
    _terminate_procs(procs)


def _alive_procs():
    with _LOCK:
        old = list(_STATE.get("procs", []))
        wanted = bool(_STATE.get("wanted"))
        backend = str(_STATE.get("backend") or "")
        sink_handoff_until = float(_STATE.get("sink_handoff_until") or 0.0)
    if not old:
        return []
    alive = []
    dead = []
    for proc in old:
        try:
            if proc.poll() is None:
                alive.append(proc)
            else:
                dead.append(proc)
        except Exception:
            dead.append(proc)
    # A Vu+ 3.14/Broadcom driver can finish its native Timeshift decoder
    # transition after a replacement playbin has survived the initial probe.
    # During the short, explicitly armed Vu+ handoff window preserve the first
    # process (provider FFmpeg) when only the local GStreamer sink dies, and
    # retry the sink.  Never consume a second MAC create_link for this local
    # hardware race.  Outside that window retain the proven R19 atomic-chain
    # behavior.
    if dead and len(old) > 1:
        provider = old[0]
        provider_alive = any(proc is provider for proc in alive)
        provider_dead = any(proc is provider for proc in dead)
        vu_sink_grace = bool(
            wanted and "local MP2 TS" in backend and
            sink_handoff_until > time.time() and provider_alive and not provider_dead
        )
        if vu_sink_grace:
            _terminate_procs([proc for proc in alive if proc is not provider])
            alive = [provider]
            _log("R31P6 Vu+ late sink exit during native Timeshift; provider preserved, sink retry armed")
            _arm_pause_key_timer(420)
        else:
            _log("R19 audio pipeline member exited; restarting whole bridge")
            _terminate_procs(alive)
            alive = []
    with _LOCK:
        _STATE["procs"] = alive
    return alive


def _is_mac_portal_audio():
    """Return True for the Stalker/MAC IPAUDIO path.

    MAC streams carry portal headers/cookies.  Xtream does not.  The distinction
    matters on the OpenATV 8 ARM test receiver: R17 AUDIO_CONTINUE keeps Xtream
    audio alive during native Timeshift, but on MAC it re-enables the original
    satellite audio decoder.  R19 therefore preserves the proven Xtream path
    and gives MAC a sink-only handoff with no DVB audio ioctl after Pause/Play.
    """
    with _LOCK:
        headers = dict(_STATE.get("headers") or {})
    keys = set([str(x) for x in headers.keys()])
    return bool(keys.intersection(set(["Cookie", "X-User-Agent", "Authorization"])))


def _continue_xtream_audio_after_pause():
    """Preserve the R17 behavior that was proven working for Xtream."""
    with _LOCK:
        wanted = bool(_STATE.get("wanted"))
        backend = str(_STATE.get("backend") or "")
    if not wanted:
        return
    if "GStreamer" not in backend and "FFplay" not in backend:
        return
    ok = False
    for path in _dvb_audio_devices():
        if _ioctl_audio(path, AUDIO_CONTINUE):
            ok = True
    _log("R19 Xtream Timeshift isolation: AUDIO_CONTINUE %s (backend=%s)" %
         ("applied" if ok else "not-supported", backend))


def _process_dvb_audio_ownership(proc):
    """Return whether *proc* really owns a DVB audio fd, or None if unknown.

    Vu+'s dvbaudiosink returns a live GStreamer process even when opening
    audio0 failed with EBUSY.  Process liveness therefore cannot prove that
    sound was recovered.  Reading the process fd table is non-invasive and is
    available on the root-run Enigma2 images; retain an unknown result for old
    images that restrict procfs so their previous behavior remains intact.
    """
    try:
        pid = int(getattr(proc, "pid", 0) or 0)
    except Exception:
        pid = 0
    devices = set([os.path.realpath(path) for path in _dvb_audio_devices()])
    if pid <= 0 or not devices:
        return None
    fd_dir = "/proc/%d/fd" % pid
    try:
        entries = os.listdir(fd_dir)
    except Exception:
        return None
    for entry in entries:
        try:
            target = os.path.realpath(os.path.join(fd_dir, entry))
            if target in devices:
                return True
        except Exception:
            pass
    return False


def _wait_for_dvb_audio_ownership(proc, attempts=12, delay=0.12):
    """Wait briefly for dvbaudiosink to open audio0 after parsing the TS."""
    last = None
    for _index in range(max(1, int(attempts))):
        try:
            if proc.poll() is not None:
                return False
        except Exception:
            return False
        last = _process_dvb_audio_ownership(proc)
        if last is True or last is None:
            return last
        time.sleep(float(delay))
    return False


def _alsa_pcm_nodes():
    nodes = []
    for path in sorted(glob.glob("/dev/snd/pcmC*D*p")):
        try:
            real = os.path.realpath(path)
        except Exception:
            real = path
        if real not in nodes:
            nodes.append(real)
    return nodes


def _process_alsa_pcm_ownership(proc):
    """Return whether *proc* owns an ALSA playback PCM, or None if unknown."""
    try:
        pid = int(getattr(proc, "pid", 0) or 0)
    except Exception:
        pid = 0
    devices = set(_alsa_pcm_nodes())
    if pid <= 0 or not devices:
        return None
    fd_dir = "/proc/%d/fd" % pid
    try:
        entries = os.listdir(fd_dir)
    except Exception:
        return None
    for entry in entries:
        try:
            target = os.path.realpath(os.path.join(fd_dir, entry))
            if target in devices:
                return True
        except Exception:
            pass
    return False


def _wait_for_alsa_pcm_ownership(sink, provider=None, attempts=32, delay=0.10):
    """Wait until alsasink has decoded the local TS and opened a PCM node.

    When old images hide /proc fd information the result remains unknown, but
    the full probe window still verifies that both processes stay alive.
    """
    last = None
    for _index in range(max(1, int(attempts))):
        for proc in (provider, sink):
            if proc is None:
                continue
            try:
                if proc.poll() is not None:
                    return False
            except Exception:
                return False
        last = _process_alsa_pcm_ownership(sink)
        if last is True:
            return True
        time.sleep(float(delay))
    return last


def _restart_local_gstreamer_sink():
    """Restart only the local GStreamer audio sink after native Timeshift.

    The provider-side FFmpeg process and the Stalker/MAC create_link connection
    stay open.  This is intentionally NOT a full audio restart: reopening the
    provider can consume/invalidate a session-bound MAC URL.  On Vu+ R25/R31,
    Enigma2 has already released its audio PID and GStreamer owns audio0.  A
    native Pause can pause that hardware decoder, while a second-process ioctl
    is rejected with EBUSY.  Recreating only playbin makes dvbaudiosink issue
    its own PLAY transition through the descriptor it owns.  This works for
    Xtream/direct feeds as well as MAC, and never touches the DVB video graph.
    """
    gst = _find_executable(("gst-launch-1.0",))
    if not gst:
        _log("R31P6 local sink handoff skipped: gst-launch-1.0 missing")
        return False

    with _LOCK:
        wanted = bool(_STATE.get("wanted"))
        backend = str(_STATE.get("backend") or "")
        port = int(_STATE.get("bridge_port") or 0)
        procs = list(_STATE.get("procs", []))
    if not wanted:
        return False
    if "local MP2 TS" not in backend or port <= 0 or len(procs) < 1:
        _log("R31P6 local sink handoff unavailable backend=%s port=%s procs=%s" %
             (backend, port, len(procs)))
        return False

    provider = procs[0]
    old_sink = procs[1] if len(procs) > 1 else None
    try:
        if provider.poll() is not None:
            _log("R31P6 local sink handoff aborted: provider already exited=%s" % provider.poll())
            _schedule_restart(0.05)
            return False
    except Exception:
        _schedule_restart(0.05)
        return False

    # Remove the old sink from the atomic process list before terminating it so
    # the watchdog never mistakes this deliberate sink replacement for a dead
    # provider and kills the still-valid MAC connection.
    with _LOCK:
        current = list(_STATE.get("procs", []))
        if not current or current[0] is not provider:
            _log("R31P6 local sink handoff cancelled: audio pipeline changed")
            return False
        _STATE["procs"] = [provider]

    if old_sink is not None:
        _terminate_procs([old_sink])
    null_in = _devnull(read=True)
    null_out = _devnull(read=False)
    logfh = _spawn_log_handle()
    new_sink = None
    try:
        args = [gst, "-q", "playbin", "uri=udp://127.0.0.1:%d" % port, "flags=2"]
        new_sink = subprocess.Popen(args, stdin=null_in, stdout=null_out,
                                    stderr=logfh, close_fds=True)
        time.sleep(0.22)
        if new_sink.poll() is not None:
            raise RuntimeError("replacement GStreamer exited %s" % new_sink.poll())
        audio_owned = None
        if _is_vuplus_receiver():
            audio_owned = _wait_for_dvb_audio_ownership(new_sink)
            if audio_owned is False:
                raise RuntimeError("replacement GStreamer is alive but did not acquire DVB audio0")
        with _LOCK:
            if not _STATE.get("wanted"):
                discard = True
            else:
                current = list(_STATE.get("procs", []))
                discard = (not current or current[0] is not provider)
                if not discard:
                    _STATE["procs"] = [provider, new_sink]
                    _STATE["sink_retry_count"] = 0
        if discard:
            _terminate_procs([new_sink])
            return False
        _log("R31P6 native Timeshift: local GStreamer sink reacquired audio0_owned=%s; provider connection preserved" %
             audio_owned)
        return True
    except Exception as e:
        _terminate_procs([new_sink] if new_sink is not None else [])
        # Never reopen the provider merely because the local output sink was
        # temporarily busy.  This is especially important for one-shot MAC
        # create_link URLs.  Keep FFmpeg and retry only playbin a few times.
        with _LOCK:
            retries = int(_STATE.get("sink_retry_count") or 0) + 1
            _STATE["sink_retry_count"] = retries
        _log("R31P6 local sink handoff failed attempt=%s: %s" % (retries, e))
        if retries <= 3:
            _arm_pause_key_timer(450 + (retries * 180))
        else:
            _log("R31P6 local sink retry limit reached; provider connection remains open")
        return False
    finally:
        try:
            if logfh is not None and logfh is not _DEVNULL_W:
                logfh.close()
        except Exception:
            pass


# Compatibility alias for any older in-memory caller loaded before upgrade.
_restart_mac_local_gstreamer_sink = _restart_local_gstreamer_sink


def _pause_key_timer_fire():
    try:
        if _is_independent_audio_backend():
            # Native Timeshift controls only the DVB video/decoder graph.  The
            # ALSA renderer is independent and must be left continuously open.
            # Reassert only Enigma2's satellite-audio exclusion because some
            # Vu+ drivers recreate their DVB audio decoder during the switch.
            with _LOCK:
                session = _STATE.get("session")
            isolated = _set_enigma_service_audio(session, False)
            _log("R31P7 Pause/Play: independent ALSA untouched; DVB audio isolation=%s" %
                 bool(isolated))
            return
        # Pause/Play belongs entirely to Enigma2's native Timeshift controller.
        # On Vu+ the R25 handoff makes GStreamer the owner of audio0, so a raw
        # AUDIO_CONTINUE from this second Python process is rejected with EBUSY.
        # Restart only the local sink and preserve the provider/FFmpeg process.
        # Never call setQpipMode or a DVB ioctl from this post-key path.
        if _is_vuplus_receiver():
            _restart_local_gstreamer_sink()
        elif _is_mac_portal_audio():
            _restart_local_gstreamer_sink()
        else:
            _continue_xtream_audio_after_pause()
    except Exception as e:
        _log("R31P7 pause-isolation timer failed: %s" % e)

def _arm_pause_key_timer(delay_ms=180):
    global _KEY_TIMER, _KEY_TIMER_CONN
    if _KEY_TIMER is None:
        _KEY_TIMER = eTimer()
        try:
            _KEY_TIMER_CONN = _KEY_TIMER.timeout.connect(_pause_key_timer_fire)
        except Exception:
            _KEY_TIMER.callback.append(_pause_key_timer_fire)
    try:
        _KEY_TIMER.stop()
    except Exception:
        pass
    try:
        _KEY_TIMER.start(int(delay_ms), True)
    except Exception:
        pass


def _arm_vu_handoff_timer(delay_ms):
    """Schedule the next non-blocking stage of the Vu+ decoder handoff."""
    global _VU_HANDOFF_TIMER, _VU_HANDOFF_TIMER_CONN
    if _VU_HANDOFF_TIMER is None:
        _VU_HANDOFF_TIMER = eTimer()
        try:
            _VU_HANDOFF_TIMER_CONN = _VU_HANDOFF_TIMER.timeout.connect(_vu_handoff_timer_fire)
        except Exception:
            _VU_HANDOFF_TIMER.callback.append(_vu_handoff_timer_fire)
    try:
        _VU_HANDOFF_TIMER.stop()
    except Exception:
        pass
    try:
        _VU_HANDOFF_TIMER.start(int(delay_ms), True)
    except Exception as e:
        _log("R31P6 Vu+ handoff timer failed: %s" % e)


def _begin_vu_native_timeshift_handoff(action=""):
    """Release only playbin before OpenATV handles the original key.

    Solo 4K exposes one Broadcom audio decoder node.  If native Timeshift is
    activated while GStreamer's dvbaudiosink owns audio0, the driver pauses
    that audio descriptor but fails to switch the video decoder.  Preserve the
    provider FFmpeg/MAC session, close only playbin, then let InfoBar switch the
    native video graph before the local sink is reacquired.
    """
    current_pause = _infobar_pause_state()
    if action == "pauseService":
        expected_pause = True
    elif action == "playpauseService" and current_pause is not None:
        expected_pause = not current_pause
    else:
        expected_pause = None

    with _LOCK:
        wanted = bool(_STATE.get("wanted"))
        backend = str(_STATE.get("backend") or "")
        procs = list(_STATE.get("procs", []))
        pending = str(_STATE.get("vu_handoff_phase") or "")
    if _is_independent_audio_backend(backend):
        _log("R31P7 Vu+ native Timeshift: no sink handoff for independent ALSA")
        return False
    if not wanted or "local MP2 TS" not in backend or not procs:
        return False
    if pending:
        _log("R31P6 Vu+ additional Pause/Play passed through during handoff phase=%s" % pending)
        return True

    provider = procs[0]
    try:
        if provider.poll() is not None:
            _log("R31P6 Vu+ pre-handoff aborted: provider exited=%s" % provider.poll())
            _schedule_restart(0.05)
            return False
    except Exception:
        _schedule_restart(0.05)
        return False

    sinks = procs[1:]
    with _LOCK:
        current = list(_STATE.get("procs", []))
        if not current or current[0] is not provider:
            return False
        _STATE["procs"] = [provider]
        _STATE["sink_retry_count"] = 0
        _STATE["sink_handoff_until"] = time.time() + 12.0
        _STATE["vu_handoff_phase"] = "wait-native"
        _STATE["vu_handoff_action"] = str(action or "")
        _STATE["vu_handoff_started"] = time.time()
        _STATE["vu_video_paused"] = expected_pause

    _terminate_procs(sinks)
    _log("R31P6 Vu+ pre-handoff: local sink released; provider preserved; original key continues to OpenATV")
    _arm_vu_handoff_timer(350)
    return True


def _vu_handoff_timer_fire():
    """Wait for OpenATV's native transition, then recover local audio."""
    with _LOCK:
        wanted = bool(_STATE.get("wanted"))
        phase = str(_STATE.get("vu_handoff_phase") or "")
        session = _STATE.get("session")
    if not wanted or not phase:
        with _LOCK:
            _STATE["vu_handoff_phase"] = ""
            _STATE["vu_handoff_action"] = ""
            _STATE["vu_handoff_started"] = 0.0
        return

    if phase == "wait-native":
        with _LOCK:
            started = float(_STATE.get("vu_handoff_started") or 0.0)
            action_name = str(_STATE.get("vu_handoff_action") or "")
            expected_pause = _STATE.get("vu_video_paused")
        elapsed = max(0.0, time.time() - started) if started else 99.0
        native_enabled = _native_timeshift_enabled(session)
        pause_state = _infobar_pause_state()
        transition_ready = bool(
            native_enabled and
            (expected_pause is None or pause_state is None or pause_state == expected_pause)
        )
        if not transition_ready and elapsed < 4.2:
            _log("R31P6 Vu+ waiting for OpenATV transition action=%s enabled=%s pause=%s expected=%s elapsed=%.1fs" %
                 (action_name, bool(native_enabled), pause_state, expected_pause, elapsed))
            _arm_vu_handoff_timer(350)
            return
        isolated = _set_enigma_service_audio(session, False)
        with _LOCK:
            if _STATE.get("vu_handoff_phase") == "wait-native":
                _STATE["vu_handoff_phase"] = "sink"
        _log("R31P6 Vu+ OpenATV transition ready=%s action=%s enabled=%s pause=%s expected=%s elapsed=%.1fs; audio-only isolation=%s" %
             (bool(transition_ready), action_name, bool(native_enabled), pause_state,
              expected_pause, elapsed, bool(isolated)))
        _arm_vu_handoff_timer(220)
        return

    if phase == "sink":
        recovered = _restart_local_gstreamer_sink()
        with _LOCK:
            _STATE["vu_handoff_phase"] = ""
            _STATE["vu_handoff_action"] = ""
            _STATE["vu_handoff_started"] = 0.0
            _STATE["vu_video_paused"] = False
        _log("R31P6 Vu+ handoff complete sink_recovered=%s provider_preserved=True" %
             bool(recovered))
        return

    _log("R31P6 Vu+ unknown handoff phase=%s; clearing" % phase)
    with _LOCK:
        _STATE["vu_handoff_phase"] = ""
        _STATE["vu_handoff_action"] = ""
        _STATE["vu_handoff_started"] = 0.0


def _named_timeshift_action(context, action):
    """Pre-release Vu+ audio, then leave the original key to OpenATV."""
    action = str(action or "")
    if action not in ("pauseService", "playpauseService"):
        return 0
    with _LOCK:
        wanted = bool(_STATE.get("wanted"))
        backend = str(_STATE.get("backend") or "")
    if not wanted or not _is_vuplus_receiver():
        return 0
    if _is_independent_audio_backend(backend):
        _arm_pause_key_timer(620)
        _log("R31P7 Vu+ named Pause/Play passed directly to OpenATV; ALSA remains live")
        return 0
    if _begin_vu_native_timeshift_handoff(action):
        _log("R31P6 Vu+ named key context=%s action=%s passed to native OpenATV controller" %
             (context, action))
        return 0
    _log("R31P6 Vu+ named key action=%s passed to OpenATV; pre-handoff unavailable" % action)
    return 0


def _stop_key_timer_fire():
    try:
        with _LOCK:
            session = _STATE.get("session")
        stop_ipaudio_and_timeshift(session=session, close_plugin=True)
    except Exception as e:
        _log("R31 STOP controller failed: %s" % e)


def _arm_stop_key_timer(delay_ms=40):
    global _STOP_TIMER, _STOP_TIMER_CONN
    if _STOP_TIMER is None:
        _STOP_TIMER = eTimer()
        try:
            _STOP_TIMER_CONN = _STOP_TIMER.timeout.connect(_stop_key_timer_fire)
        except Exception:
            _STOP_TIMER.callback.append(_stop_key_timer_fire)
    try:
        _STOP_TIMER.stop()
    except Exception:
        pass
    try:
        _STOP_TIMER.start(int(delay_ms), True)
    except Exception:
        pass


def _raw_timeshift_key(key, flag):
    try:
        key = int(key)
        flag = int(flag)
    except Exception:
        return 0
    # Linux input codes commonly used by Enigma2 remotes.
    # STOP=128 and STOPCD=166.  Consume STOP while IPAUDIO is active so an
    # image-specific Timeshift confirmation cannot leave half of the session
    # running; the short timer performs one ordered, idempotent full shutdown.
    if key in (128, 166) and flag == 0:
        with _LOCK:
            wanted = bool(_STATE.get("wanted"))
        if wanted:
            _log("R31 STOP key observed; ending IPAUDIO + native Timeshift")
            _arm_stop_key_timer()
            return 1

    # PAUSE=119, PLAYPAUSE=164, PLAY=207. Never consume the event: native
    # Enigma2 must still freeze/resume VIDEO and manage its own Timeshift file.
    if key in (119, 164, 207) and flag == 0:
        with _LOCK:
            wanted = bool(_STATE.get("wanted"))
            backend = str(_STATE.get("backend") or "")
        if wanted:
            vuplus = _is_vuplus_receiver()
            if vuplus and _is_independent_audio_backend(backend):
                if not _NAMED_KEY_BOUND:
                    _arm_pause_key_timer(620)
                _log("R31P7 Vu+ raw key=%s passed to native OpenATV; independent ALSA untouched" % key)
                return 0
            if vuplus and _NAMED_KEY_BOUND:
                # The named InfobarSeekActions hook releases the local sink at
                # high priority, then returns 0 so the exact same physical key
                # reaches OpenATV's currently enabled native Timeshift map.
                _log("R31P6 Vu+ raw key=%s delegated to named pre-handoff observer" % key)
                return 0
            with _LOCK:
                _STATE["sink_retry_count"] = 0
                # Only Vu+ gets the decoder-transition grace.  Octagon and all
                # other receivers remain byte-for-byte on the R19/R31 path.
                if vuplus:
                    _STATE["sink_handoff_until"] = time.time() + 5.0
            if vuplus or _is_mac_portal_audio():
                mode = "local-sink-handoff"
            else:
                mode = "R19-R17-continue"
            _log("R31P6 native Timeshift key=%s observed; mode=%s backend=%s" %
                 (key, mode, backend))
            _arm_pause_key_timer(260 if mode == "local-sink-handoff" else 180)
    return 0


def _bind_pause_isolation():
    global _KEY_BOUND, _NAMED_KEY_BOUND
    if eActionMap is None:
        _log("R31P6 Timeshift hooks unavailable: eActionMap missing")
        return
    if not _KEY_BOUND:
        try:
            eActionMap.getInstance().bindAction('', -0x7FFFFFFE, _raw_timeshift_key)
            _KEY_BOUND = True
            _log("R31P6 raw STOP guard / compatibility observer bound")
        except Exception as e:
            _log("R31P6 raw key observer bind failed: %s" % e)
    else:
        _log("R31P6 raw STOP guard / compatibility observer already bound")

    if _is_vuplus_receiver():
        if not _NAMED_KEY_BOUND:
            try:
                # InfobarSeekActions maps KEY_PAUSE, KEY_PLAYPAUSE and KEY_PLAY
                # by action name on OpenATV old and new.  Binding the context
                # directly avoids receiver-specific Linux key-code guesses.
                eActionMap.getInstance().bindAction(
                    'InfobarSeekActions', -0x7FFFFFFD, _named_timeshift_action)
                _NAMED_KEY_BOUND = True
                _log("R31P6 Vu+ named Pause/Play pre-handoff observer bound")
            except Exception as e:
                _log("R31P6 Vu+ named Pause/Play bind failed: %s" % e)
        else:
            _log("R31P6 Vu+ named Pause/Play pre-handoff observer already bound")


def _unbind_pause_isolation():
    global _KEY_BOUND, _NAMED_KEY_BOUND
    if eActionMap is None:
        _KEY_BOUND = False
        _NAMED_KEY_BOUND = False
        return
    if _KEY_BOUND:
        try:
            eActionMap.getInstance().unbindAction('', _raw_timeshift_key)
        except Exception:
            pass
    if _NAMED_KEY_BOUND:
        try:
            eActionMap.getInstance().unbindAction('InfobarSeekActions', _named_timeshift_action)
        except Exception:
            pass
    _KEY_BOUND = False
    _NAMED_KEY_BOUND = False


def _ensure_timer():
    global _TIMER, _TIMER_CONN
    if _TIMER is None:
        _TIMER = eTimer()
        try:
            _TIMER_CONN = _TIMER.timeout.connect(_watchdog_tick)
        except Exception:
            _TIMER.callback.append(_watchdog_tick)
    try:
        _TIMER.start(350, False)
    except Exception:
        pass


def _stop_timer():
    if _TIMER is not None:
        try:
            _TIMER.stop()
        except Exception:
            pass


def arm_background_audio(session, channel_name="IPTV", headers=None, resume_context=None,
                         retry_resolver=None):
    current_service = _current_service_string(session)
    native_timeshift = _native_timeshift_enabled(session)
    if current_service and not _is_dvb_service_string(current_service) and not native_timeshift:
        raise RuntimeError("Tune a satellite DVB channel before starting IPAUDIO")
    _stop_processes_only()
    try:
        with open(_LOG, "w") as log_file:
            log_file.write("")
    except Exception:
        pass
    with _LOCK:
        _STATE["wanted"] = True
        _STATE["session"] = session
        _STATE["name"] = str(channel_name or "IPTV")
        _STATE["url"] = ""
        _STATE["backend"] = ""
        _STATE["dvb_stopped"] = False
        _STATE["dvb_devices"] = []
        _STATE["last_service"] = _current_service_string(session)
        _STATE["restart_due"] = 0.0
        _STATE["restarting"] = False
        _STATE["error"] = ""
        _STATE["error_reported"] = False
        _STATE["headers"] = dict(headers or {})
        _STATE["retry_resolver"] = retry_resolver if callable(retry_resolver) else None
        _STATE["bridge_port"] = 0
        _STATE["e2_audio_disabled"] = False
        _STATE["resume_context"] = dict(resume_context or {})
        _STATE["sink_retry_count"] = 0
        _STATE["sink_handoff_until"] = 0.0
        _STATE["vu_handoff_phase"] = ""
        _STATE["vu_handoff_action"] = ""
        _STATE["vu_handoff_started"] = 0.0
        _STATE["vu_video_paused"] = False
    try:
        from .receivercompat import receiver_signature, is_vuplus
        _log("R31P7 receiver profile vuplus=%s signature=%s" %
             (bool(is_vuplus()), receiver_signature() or "<unknown>"))
    except Exception:
        _log("R31P7 receiver profile unavailable")
    _log("Arming background audio for %s native_timeshift=%s" %
         (channel_name, bool(native_timeshift)))
    # A Timeshift session already owns a live recording/playback transition.
    # Release only Enigma2's audio PID once before GStreamer starts.  On Vu+
    # R31P7 explicitly keeps QPiP False so the active video/timeshift graph is
    # not moved into a secondary-decoder mode.
    _release_main_audio_for_ipaudio(session, preserve_timeshift=native_timeshift)
    if _is_vuplus_receiver():
        # Enigma objects are safest on the Enigma2/UI thread.  Release this
        # optional singleton here, before the worker opens GStreamer ALSA.
        _release_enigma_alsa_output()
    _bind_pause_isolation()
    _ensure_timer()


def _ffmpeg_audio_input_args(stream_url, ffmpeg, headers=None):
    args = [ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin"]
    hdrs = dict(headers or {})
    if str(stream_url).lower().startswith(("http://", "https://")):
        ua = str(hdrs.pop("User-Agent", "") or "").strip()
        if ua:
            args += ["-user_agent", ua]
        extra = []
        for hkey in ("X-User-Agent", "Cookie", "Referer", "Authorization"):
            hval = str(hdrs.get(hkey, "") or "").replace("\r", " ").replace("\n", " ").strip()
            if hval:
                extra.append("%s: %s\r\n" % (hkey, hval))
        # Preserve other simple portal headers as well. Stalker/MAC portals
        # often require them even after create_link returns the media URL.
        for hkey, hval in hdrs.items():
            if hkey in ("X-User-Agent", "Cookie", "Referer", "Authorization"):
                continue
            key = str(hkey or "").replace("\r", " ").replace("\n", " ").strip()
            val = str(hval or "").replace("\r", " ").replace("\n", " ").strip()
            if key and val:
                extra.append("%s: %s\r\n" % (key, val))
        if extra:
            args += ["-headers", "".join(extra)]
        # Keep startup bounded on live IPTV while remaining conservative enough
        # for MPEG-TS/HLS stream discovery on ffmpeg 4.4.x.
        args += ["-probesize", "262144", "-analyzeduration", "1500000"]
    args += ["-i", stream_url]
    return args


def _free_udp_port():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])
    finally:
        try:
            sock.close()
        except Exception:
            pass


def _r9_provider_input_args(stream_url, ffmpeg, headers=None):
    """R9-proven provider input profile used by the old audio relay/remux.

    R16's small probe window and forwarding of arbitrary/Authorization headers
    was too fragile on the OpenATV 8 ARM test box.  This intentionally mirrors
    the conservative provider side that already worked in R9/R12: larger
    probing, queueing, and only the Stalker headers known to be safe for the
    resolved media host.
    """
    args = [
        ffmpeg,
        "-nostdin", "-hide_banner", "-loglevel", "warning",
        "-fflags", "+discardcorrupt+genpts",
        "-probesize", "4194304", "-analyzeduration", "2000000",
        "-thread_queue_size", "1024",
    ]
    hdrs = dict(headers or {})
    if str(stream_url).lower().startswith(("http://", "https://")):
        ua = str(hdrs.pop("User-Agent", "") or "").strip()
        if ua:
            args += ["-user_agent", ua]
        extra = []
        # Keep this identical in spirit to the proven R9 relay.  In particular
        # do NOT forward Authorization blindly to a create_link media host.
        for hkey in ("X-User-Agent", "Cookie", "Referer"):
            hval = str(hdrs.get(hkey, "") or "").replace("\r", " ").replace("\n", " ").strip()
            if hval:
                extra.append("%s: %s\r\n" % (hkey, hval))
        if extra:
            args += ["-headers", "".join(extra)]
    args += ["-i", stream_url]
    return args


def _spawn_log_handle():
    try:
        return open(_LOG, "a")
    except Exception:
        return _devnull(read=False)


def _gst_has_element(element):
    """Return True when the receiver image exposes a GStreamer element."""
    inspector = _find_executable(("gst-inspect-1.0",))
    if not inspector:
        return False
    try:
        proc = subprocess.Popen([inspector, element], stdin=_devnull(read=True),
                                stdout=_devnull(read=False), stderr=_devnull(read=False),
                                close_fds=True)
        return proc.wait() == 0
    except Exception as e:
        _log("gst-inspect failed for %s: %s" % (element, e))
        return False


def _is_vuplus_receiver():
    try:
        from .receivercompat import is_vuplus
        return bool(is_vuplus())
    except Exception as e:
        _log("Vu+ detection failed: %s" % e)
        return False


def _set_enigma_service_audio(session, enabled):
    """Enable/disable audio on the CURRENT DVB service through Enigma2 itself.

    On OpenATV/eDVBServicePlay, setQpipMode(False, audio=False) sets the current
    audio PID to -1 and reapplies the decoder.  That destroys Enigma2's eDVBAudio
    object and releases /dev/dvb/adapter0/audio0 while leaving video/timeshift
    untouched.  This is the key Vu+ fix: opening audio0 from a second process
    while Enigma2 owns it returns EBUSY.
    """
    try:
        if session is None or getattr(session, "nav", None) is None:
            return False
        service = session.nav.getCurrentService()
        if service is None:
            _log("R31P6 E2 audio handoff: no current service")
            return False
        setter = getattr(service, "setQpipMode", None)
        if not callable(setter):
            _log("R31P6 E2 audio handoff: current service has no setQpipMode")
            return False

        # The first argument is QPiP mode, not an audio-disable switch.  Newer
        # OpenATV ignores it, while older OpenPLi/Vu+ branches persist it as
        # m_qpip_mode across decoder/timeshift updates.  IPAUDIO never uses
        # QPiP, so keep it False and control only the independent audio flag.
        # This works with both implementations and avoids changing the video
        # service mode on Solo 4K.
        setter(False, bool(enabled))
        with _LOCK:
            _STATE["e2_audio_disabled"] = not bool(enabled)
            _STATE["dvb_stopped"] = not bool(enabled)
            _STATE["dvb_devices"] = _dvb_audio_devices()
        _log("R31P7 E2 service audio %s via setQpipMode(qpip=False,audio=%s)" %
             (("RESTORED" if enabled else "RELEASED"), bool(enabled)))
        return True
    except Exception as e:
        _log("R31P6 E2 audio handoff failed enabled=%s: %s" % (enabled, e))
        return False


def _release_main_audio_for_ipaudio(session, preserve_timeshift=False):
    """Release the satellite audio decoder without touching satellite video."""
    if _is_vuplus_receiver():
        if preserve_timeshift:
            _log("R31P6 active native Timeshift: one-time Enigma2 audio-only handoff")
        if _set_enigma_service_audio(session, False):
            # eTSMPEGDecoder::set() is synchronous, but a tiny grace period is
            # useful on older Broadcom Vu+ drivers before dvbaudiosink opens it.
            time.sleep(0.08)
            return True
        _log("R25 Vu+: Enigma2 audio release unavailable; trying legacy DVB ioctl")
    return _set_dvb_decoder_stopped(True)


def _restore_main_audio_after_ipaudio(session):
    """Restore satellite audio after the IPTV audio process has released audio0."""
    with _LOCK:
        used_e2_handoff = bool(_STATE.get("e2_audio_disabled"))
    if used_e2_handoff and _set_enigma_service_audio(session, True):
        return True
    return _set_dvb_decoder_stopped(False)


def _start_ffmpeg_local_ts_alsa_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers=None):
    """Vu+ single-open bridge with audio rendered outside the DVB decoder.

    FFmpeg owns the provider/MAC connection exactly once and continuously sends
    the R19 MP2 transport stream to loopback.  Only local GStreamer sinks are
    probed.  Native Pause/Play can therefore operate on the DVB video/timeshift
    graph without pausing this independent ALSA PCM stream.
    """
    if not _gst_has_element("alsasink"):
        raise RuntimeError("GStreamer element alsasink is not installed")

    port = _free_udp_port()
    ffproc = None
    gstproc = None
    fflog = None
    gstlog = None
    sink_errors = []
    try:
        ffargs = _r9_provider_input_args(stream_url, ffmpeg, headers)
        ffargs += ["-map", "0:a:0", "-vn", "-sn", "-dn"]
        _append_audio_filter(ffargs, include_resample=True)
        ffargs += [
            "-c:a", "mp2", "-b:a", "160k", "-ar", "48000", "-ac", "2",
            "-muxdelay", "0", "-muxpreload", "0",
            "-mpegts_flags", "+resend_headers",
            "-f", "mpegts",
            "udp://127.0.0.1:%d?pkt_size=1316" % port,
        ]
        fflog = _spawn_log_handle()
        ffproc = subprocess.Popen(ffargs, stdin=null_in, stdout=null_out,
                                  stderr=fflog, close_fds=True)

        # Probe local sinks only; never reopen FFmpeg or consume a second MAC
        # create_link while selecting the receiver's ALSA PCM route.
        candidates = []
        for device in _alsa_playback_devices():
            value = str(device or "").strip()
            if value and value not in candidates:
                candidates.append(value)
            if len(candidates) >= 12:
                break
        for device in candidates:
            gstproc = None
            try:
                gstargs = [
                    gst, "-q", "playbin",
                    "uri=udp://127.0.0.1:%d" % port,
                    "flags=2",
                    "audio-sink=alsasink device=%s sync=false" % device,
                ]
                gstlog = _spawn_log_handle()
                gstproc = subprocess.Popen(gstargs, stdin=null_in, stdout=null_out,
                                           stderr=gstlog, close_fds=True)
                owned = _wait_for_alsa_pcm_ownership(gstproc, ffproc)
                if gstproc.poll() is None and ffproc.poll() is None and owned is not False:
                    with _LOCK:
                        _STATE["bridge_port"] = int(port)
                    _log("R31P7 Vu+ independent ALSA bridge ready port=%d device=%s pcm_owned=%s" %
                         (port, device, owned))
                    return [ffproc, gstproc], (
                        "FFmpeg R9-input -> local MP2 TS -> GStreamer ALSA-independent (%s)" % device)
                sink_errors.append("%s owned=%s gst=%s" % (device, owned, gstproc.poll()))
            except Exception as e:
                sink_errors.append("%s: %s" % (device, e))
            finally:
                try:
                    if gstlog is not None and gstlog is not _DEVNULL_W:
                        gstlog.close()
                except Exception:
                    pass
                gstlog = None
            _terminate_procs([gstproc] if gstproc is not None else [])
            gstproc = None
            try:
                if ffproc.poll() is not None:
                    raise RuntimeError("provider FFmpeg exited %s while probing ALSA" % ffproc.poll())
            except AttributeError:
                raise RuntimeError("provider FFmpeg state is unavailable")

        # Compatibility fallback on images whose feed lacks a usable ALSA PCM.
        # Reuse the SAME provider-side FFmpeg/UDP connection; do not create a
        # second Stalker link merely because local ALSA is unavailable.
        _log("R31P7 ALSA sink unavailable (%s); reusing provider with DVB playbin fallback" %
             ("; ".join(sink_errors[-4:]) or "no candidates"))
        gstargs = [gst, "-q", "playbin", "uri=udp://127.0.0.1:%d" % port, "flags=2"]
        gstlog = _spawn_log_handle()
        gstproc = subprocess.Popen(gstargs, stdin=null_in, stdout=null_out,
                                   stderr=gstlog, close_fds=True)
        end = time.time() + 3.2
        while time.time() < end:
            if gstproc.poll() is not None or ffproc.poll() is not None:
                break
            time.sleep(0.10)
        if gstproc.poll() is None and ffproc.poll() is None:
            with _LOCK:
                _STATE["bridge_port"] = int(port)
            return [ffproc, gstproc], (
                "FFmpeg R9-input -> local MP2 TS -> GStreamer playbin DVB-fallback")
        raise RuntimeError("local bridge exited after ALSA probes (ffmpeg=%s gst=%s)" %
                           (ffproc.poll(), gstproc.poll()))
    except Exception:
        _terminate_procs([x for x in (ffproc, gstproc) if x is not None])
        raise
    finally:
        for fh in (fflog, gstlog):
            try:
                if fh is not None and fh is not _DEVNULL_W:
                    fh.close()
            except Exception:
                pass


def _start_ffmpeg_local_ts_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers=None):
    """Single-open bridge: provider -> FFmpeg -> local MPEG-TS -> playbin.

    The OpenATV ARM box already proved that GStreamer playbin can reach the
    receiver audio output.  R19 keeps the R17-proven design where FFmpeg do only the fragile part
    (provider auth/network/codec normalisation) and gives playbin a local TS.

    For Stalker/MAC this function deliberately opens the provider exactly once.
    Reusing a create_link URL after a failed output probe can invalidate a
    one-shot/session-bound portal stream.
    """
    port = _free_udp_port()
    gstproc = None
    ffproc = None
    gstlog = None
    fflog = None
    try:
        gstargs = [gst, "-q", "playbin",
                   "uri=udp://127.0.0.1:%d" % port, "flags=2"]
        gstlog = _spawn_log_handle()
        gstproc = subprocess.Popen(gstargs, stdin=null_in, stdout=null_out,
                                   stderr=gstlog, close_fds=True)
        time.sleep(0.30)
        if gstproc.poll() is not None:
            raise RuntimeError("local GStreamer sink exited %s before provider open" % gstproc.poll())

        ffargs = _r9_provider_input_args(stream_url, ffmpeg, headers)
        ffargs += [
            "-map", "0:a:0", "-vn", "-sn", "-dn",
        ]
        _append_audio_filter(ffargs, include_resample=True)
        ffargs += [
            "-c:a", "mp2", "-b:a", "160k", "-ar", "48000", "-ac", "2",
            "-muxdelay", "0", "-muxpreload", "0",
            "-mpegts_flags", "+resend_headers",
            "-f", "mpegts",
            "udp://127.0.0.1:%d?pkt_size=1316" % port,
        ]
        fflog = _spawn_log_handle()
        ffproc = subprocess.Popen(ffargs, stdin=null_in, stdout=null_out,
                                  stderr=fflog, close_fds=True)

        # 4K and some Stalker streams need more than R16's 650 ms probe. Audio
        # is already flowing during this check; it only prevents false success.
        end = time.time() + 3.2
        while time.time() < end:
            if gstproc.poll() is not None or ffproc.poll() is not None:
                break
            time.sleep(0.10)
        if gstproc.poll() is None and ffproc.poll() is None:
            _log("R19 single-open local audio bridge ready port=%d" % port)
            with _LOCK:
                _STATE["bridge_port"] = int(port)
            return [ffproc, gstproc], "FFmpeg R9-input -> local MP2 TS -> GStreamer playbin"
        raise RuntimeError("local bridge exited (ffmpeg=%s gst=%s)" %
                           (ffproc.poll(), gstproc.poll()))
    except Exception:
        _terminate_procs([x for x in (ffproc, gstproc) if x is not None])
        raise
    finally:
        for fh in (gstlog, fflog):
            try:
                if fh is not None and fh is not _DEVNULL_W:
                    fh.close()
            except Exception:
                pass

def _start_ffmpeg_aplay(stream_url, ffmpeg, aplay, null_in, null_out, headers=None):
    last_error = ""
    for device in _alsa_playback_devices():
        dec = None
        out = None
        try:
            _log("Trying ALSA device %s" % device)
            ffargs = _r9_provider_input_args(stream_url, ffmpeg, headers)
            ffargs += ["-map", "0:a:0?", "-vn", "-sn", "-dn"]
            _append_audio_filter(ffargs)
            ffargs += ["-ac", "2", "-ar", "48000", "-f", "s16le", "pipe:1"]
            dec = subprocess.Popen(
                ffargs,
                stdin=null_in, stdout=subprocess.PIPE, stderr=null_out, close_fds=True)
            out = subprocess.Popen(
                [aplay, "-q", "-D", device, "-t", "raw", "-f", "S16_LE",
                 "-c", "2", "-r", "48000"],
                stdin=dec.stdout, stdout=null_out, stderr=null_out, close_fds=True)
            try:
                dec.stdout.close()
            except Exception:
                pass
            time.sleep(0.45)
            if out.poll() is None and dec.poll() is None:
                return [dec, out], "FFmpeg -> ALSA PCM (%s)" % device
            last_error = "ALSA device %s exited (ffmpeg=%s aplay=%s)" % (device, dec.poll(), out.poll())
        except Exception as e:
            last_error = "%s: %s" % (device, e)
        _terminate_procs([p for p in (dec, out) if p is not None])
    raise RuntimeError(last_error or "No usable ALSA playback device")


def _start_ffmpeg_dvbaudiosink_pcm(stream_url, ffmpeg, gst, null_in, null_out, headers=None):
    """Vu+ path: FFmpeg provider/auth -> raw PCM -> GStreamer dvbaudiosink.

    Vu+ 4K boxes are well known for an unusable ALSA path while their native
    DVB audio sink still works.  This backend keeps Enigma2's satellite VIDEO
    service and native timeshift untouched, opens the IPTV provider only once
    (important for MAC/Stalker), and hands already-decoded S16LE PCM directly
    to the receiver's DVB audio sink.  No Local Remux is involved.
    """
    if not _gst_has_element("dvbaudiosink"):
        raise RuntimeError("GStreamer element dvbaudiosink is not installed")

    dec = None
    out = None
    try:
        ffargs = _r9_provider_input_args(stream_url, ffmpeg, headers)
        ffargs += ["-map", "0:a:0", "-vn", "-sn", "-dn"]
        _append_audio_filter(ffargs)
        ffargs += ["-ac", "2", "-ar", "48000", "-f", "s16le", "pipe:1"]
        fflog = _spawn_log_handle()
        gstlog = _spawn_log_handle()
        try:
            dec = subprocess.Popen(ffargs, stdin=null_in, stdout=subprocess.PIPE,
                                   stderr=fflog, close_fds=True)
            gstargs = [gst, "-q", "fdsrc", "fd=0", "!",
                       "audio/x-raw,format=S16LE,channels=2,layout=interleaved,rate=48000",
                       "!", "dvbaudiosink"]
            out = subprocess.Popen(gstargs, stdin=dec.stdout, stdout=null_out,
                                   stderr=gstlog, close_fds=True)
            try:
                dec.stdout.close()
            except Exception:
                pass

            # Give MAC/Stalker + 4K boxes enough time to probe and acquire the
            # hardware sink.  A live pair after this window is a usable backend.
            end = time.time() + 3.2
            while time.time() < end:
                if dec.poll() is not None or out.poll() is not None:
                    break
                time.sleep(0.10)
            if dec.poll() is None and out.poll() is None:
                _log("R24 Vu+ dvbaudiosink backend ready")
                return [dec, out], "FFmpeg -> Vu+ DVB audio sink"
            raise RuntimeError("dvbaudiosink exited (ffmpeg=%s gst=%s)" %
                               (dec.poll(), out.poll()))
        finally:
            for fh in (fflog, gstlog):
                try:
                    if fh is not None and fh is not _DEVNULL_W:
                        fh.close()
                except Exception:
                    pass
    except Exception:
        _terminate_procs([x for x in (dec, out) if x is not None])
        raise


def _start_ffmpeg_gstreamer_pcm(stream_url, ffmpeg, gst, null_in, null_out, headers=None):
    """Use FFmpeg for network/auth, GStreamer only as the PCM output sink.

    This fixes the R15 MAC failure mode where playbin did not receive Stalker
    headers. It also gives explicit ALSA a chance before autoaudiosink.
    """
    last_error = ""
    sink_specs = ["alsasink sync=false", "autoaudiosink sync=false"]
    for sink_spec in sink_specs:
        dec = None
        out = None
        try:
            ffargs = _r9_provider_input_args(stream_url, ffmpeg, headers)
            ffargs += ["-map", "0:a:0?", "-vn", "-sn", "-dn"]
            _append_audio_filter(ffargs)
            ffargs += ["-ac", "2", "-ar", "48000", "-f", "s16le", "pipe:1"]
            dec = subprocess.Popen(ffargs, stdin=null_in, stdout=subprocess.PIPE,
                                   stderr=null_out, close_fds=True)
            gstargs = [gst, "-q", "fdsrc", "fd=0", "!",
                       "audio/x-raw,format=S16LE,channels=2,rate=48000,layout=interleaved",
                       "!", "audioconvert", "!", "audioresample", "!"]
            gstargs += sink_spec.split()
            out = subprocess.Popen(gstargs, stdin=dec.stdout, stdout=null_out,
                                   stderr=null_out, close_fds=True)
            try:
                dec.stdout.close()
            except Exception:
                pass
            time.sleep(0.65)
            if dec.poll() is None and out.poll() is None:
                return [dec, out], "FFmpeg -> GStreamer PCM (%s)" % sink_spec.split()[0]
            last_error = "%s exited (ffmpeg=%s gst=%s)" % (sink_spec, dec.poll(), out.poll())
        except Exception as e:
            last_error = "%s: %s" % (sink_spec, e)
        _terminate_procs([x for x in (dec, out) if x is not None])
    raise RuntimeError(last_error or "No FFmpeg/GStreamer PCM sink")


def start_audio_backend(stream_url, channel_name="IPTV", restart=False, headers=None):
    """Start IPTV audio while Enigma2 keeps ownership of satellite video/timeshift."""
    stream_url = clean_stream_url(stream_url)
    if not stream_url:
        raise RuntimeError("No playable stream URL")

    _stop_processes_only()
    null_in = _devnull(read=True)
    null_out = _devnull(read=False)
    procs = []
    backend = ""
    errors = []

    ffmpeg = _find_executable(("ffmpeg",))
    aplay = _find_executable(("aplay",))
    ffplay = _find_executable(("ffplay",))
    gst = _find_executable(("gst-launch-1.0",))
    hdrkeys = set([str(x) for x in dict(headers or {}).keys()])
    portal_headers = bool(hdrkeys.intersection(set(["Cookie", "X-User-Agent", "Authorization"])))
    vuplus = _is_vuplus_receiver()
    has_alsa_sink = bool(gst and _gst_has_element("alsasink"))
    has_dvb_sink = bool(gst and _gst_has_element("dvbaudiosink"))

    with _LOCK:
        e2_audio_disabled = bool(_STATE.get("e2_audio_disabled"))
        dvb_audio_stopped = bool(_STATE.get("dvb_stopped"))
    audio_released = bool(e2_audio_disabled or dvb_audio_stopped)
    _log("R31P7 backend probe vuplus=%s ffmpeg=%s gst=%s aplay=%s portal_headers=%s alsasink=%s dvbaudiosink=%s audio_released=%s" %
         (vuplus, bool(ffmpeg), bool(gst), bool(aplay), portal_headers,
          has_alsa_sink, has_dvb_sink, audio_released))

    # R31P7 Vu+ FIRST: retain the proven FFmpeg MP2 local TS and single provider
    # connection, but force playbin through an independent ALSA PCM sink.  The
    # Solo 4K Broadcom driver pauses dvbaudiosink together with native DVB
    # Timeshift; ALSA is not in that decoder ownership chain.
    if vuplus and ffmpeg and gst:
        if not audio_released:
            errors.append("DVBaudio=not released")
            _log("R31P6 Vu+ backend warning: audio handoff state is not active")
        if has_alsa_sink:
            try:
                procs, backend = _start_ffmpeg_local_ts_alsa_gstreamer(
                    stream_url, ffmpeg, gst, null_in, null_out, headers)
                release = "R25 E2-audio-release" if e2_audio_disabled else "R19 Timeshift release"
                backend = release + " -> " + backend
            except Exception as e:
                # The helper reuses one FFmpeg process for every local sink
                # probe.  Never reopen a possibly one-shot MAC create_link here.
                errors.append("Vu+ALSA-GSTlocal=%s" % e)
                _log("R31P7 Vu+ single-open ALSA/local bridge failed: %s" % e)
        else:
            # alsasink absence is known before any provider connection opens.
            try:
                procs, backend = _start_ffmpeg_local_ts_gstreamer(
                    stream_url, ffmpeg, gst, null_in, null_out, headers)
                release = "R25 E2-audio-release" if e2_audio_disabled else "R19 Timeshift release"
                backend = release + " -> " + backend + " DVB-fallback"
            except Exception as e:
                errors.append("Vu+GSTfallback=%s" % e)
                _log("R31P7 Vu+ DVB playbin fallback failed: %s" % e)

    # Non-Vu+ receivers keep the previously proven direct ALSA path first.
    if not procs and (not vuplus) and ffmpeg and aplay:
        try:
            procs, backend = _start_ffmpeg_aplay(stream_url, ffmpeg, aplay, null_in, null_out, headers)
        except Exception as e:
            errors.append("ALSA=%s" % e)
            _log("FFmpeg+ALSA failed: %s" % e)

    # Buffered local AUDIO bridge only.  This is not Local Remux and never
    # retunes/replaces the Enigma2 satellite video service.  It remains a
    # fallback when the image's playbin can acquire its DVB audio sink.
    if not procs and ffmpeg and gst and not vuplus:
        try:
            procs, backend = _start_ffmpeg_local_ts_gstreamer(stream_url, ffmpeg, gst,
                                                              null_in, null_out, headers)
        except Exception as e:
            errors.append("GSTlocal=%s" % e)
            _log("R25 buffered local audio bridge failed: %s" % e)

    if not procs and ffmpeg and gst and not portal_headers and not vuplus:
        try:
            procs, backend = _start_ffmpeg_gstreamer_pcm(stream_url, ffmpeg, gst,
                                                         null_in, null_out, headers)
        except Exception as e:
            errors.append("GSTpcm=%s" % e)
            _log("FFmpeg+GStreamer PCM failed: %s" % e)

    if not procs and ffplay and not portal_headers and not vuplus:
        cmd = [ffplay, "-nodisp", "-vn", "-loglevel", "error", "-nostats"]
        _append_audio_filter(cmd)
        cmd.append(stream_url)
        procs = [subprocess.Popen(cmd, stdin=null_in, stdout=null_out, stderr=null_out, close_fds=True)]
        backend = "FFplay direct audio"
        time.sleep(0.35)
        if not _alive_list(procs):
            errors.append("FFplay=exited")
            _terminate_procs(procs)
            procs = []
            backend = ""

    if not procs and gst and not portal_headers and not vuplus:
        if configured_audio_delay_ms() > 0:
            _log("R31 warning: direct GStreamer fallback cannot apply configured audio delay")
        cmd = [gst, "-q", "playbin", "uri=" + stream_url, "flags=2"]
        procs = [subprocess.Popen(cmd, stdin=null_in, stdout=null_out, stderr=null_out, close_fds=True)]
        backend = "GStreamer audio-only (fallback)"
        time.sleep(0.35)
        if not _alive_list(procs):
            errors.append("GSTdirect=exited")
            _terminate_procs(procs)
            procs = []
            backend = ""

    if not procs:
        short = "; ".join(errors[-3:])
        if vuplus:
            raise RuntimeError("Vu+ audio backend failed (R31P7 independent ALSA). %s. See /tmp/xklass-backgroundaudio.log" %
                               (short or "Enigma2 audio release / GStreamer alsasink unavailable"))
        raise RuntimeError("No IPAUDIO backend could be started (R25 native-timeshift). %s" % short)

    delay_ms = configured_audio_delay_ms()
    if delay_ms > 0 and ("FFmpeg" in backend or "FFplay" in backend):
        backend += " | delay %.2fs" % (float(delay_ms) / 1000.0)

    with _LOCK:
        if not _STATE.get("wanted"):
            discard = True
        else:
            discard = False
            _STATE["procs"] = procs
            _STATE["name"] = str(channel_name or _STATE.get("name") or "IPTV")
            _STATE["backend"] = backend
            _STATE["url"] = stream_url
            _STATE["restarting"] = False
            _STATE["error"] = ""
            _STATE["headers"] = dict(headers or _STATE.get("headers") or {})
    if discard:
        _terminate_procs(procs)
        raise RuntimeError("Background audio was cancelled")
    _log("Background audio started with %s" % backend)
    return backend


def _alive_list(procs):
    alive = []
    for proc in procs or []:
        try:
            if proc.poll() is None:
                alive.append(proc)
        except Exception:
            pass
    return alive


def report_start_error(error):
    _log("Start error: %s" % error)
    with _LOCK:
        _STATE["error"] = str(error or "Unable to start background audio")
        _STATE["restarting"] = False


def _restart_worker(url, name, headers, retry_resolver=None):
    try:
        refreshed_url = str(url or "")
        refreshed_headers = dict(headers or {})
        if callable(retry_resolver):
            result = retry_resolver()
            if isinstance(result, dict):
                refreshed_url = str(result.get("url") or result.get("stream_url") or "")
                if isinstance(result.get("headers"), dict):
                    refreshed_headers = dict(result.get("headers") or {})
            elif isinstance(result, (list, tuple)):
                refreshed_url = str(result[0] if result else "")
                if len(result) > 1 and isinstance(result[1], dict):
                    refreshed_headers = dict(result[1] or {})
            else:
                refreshed_url = str(result or "")
            refreshed_url = clean_stream_url(refreshed_url)
            if not refreshed_url:
                raise RuntimeError("MAC portal did not return a fresh playable URL")
            with _LOCK:
                _STATE["url"] = refreshed_url
                _STATE["headers"] = dict(refreshed_headers)
            _log("R30 refreshed MAC/Stalker stream link before audio restart")
        start_audio_backend(refreshed_url, name, restart=True, headers=refreshed_headers)
    except Exception as e:
        with _LOCK:
            _STATE["error"] = str(e)
            _STATE["restarting"] = False
            _STATE["restart_due"] = time.time() + 2.0
        _log("Restart failed: %s" % e)


def _schedule_restart(delay=0.45):
    with _LOCK:
        if _STATE.get("wanted") and _STATE.get("url"):
            _STATE["restart_due"] = time.time() + float(delay)


def _watchdog_tick():
    with _LOCK:
        wanted = bool(_STATE.get("wanted"))
        session = _STATE.get("session")
        last_service = str(_STATE.get("last_service") or "")
        error = str(_STATE.get("error") or "")
        error_reported = bool(_STATE.get("error_reported"))

    if not wanted:
        _stop_timer()
        return

    # R25: on Vu+ never fight Enigma2 for /dev/dvb/adapter0/audio0 with raw
    # ioctls.  Reapply the service-level no-audio state only after a real
    # service change (or if the initial handoff failed).  Other boxes retain
    # the legacy AUDIO_STOP behavior.
    current_service = _current_service_string(session)
    native_timeshift = _native_timeshift_enabled(session)
    if (current_service and last_service and current_service != last_service and
            not _is_dvb_service_string(current_service) and not native_timeshift):
        _log("R30 foreground video service detected; stopping IPAUDIO before A/V handoff")
        stop_background_audio(restore_main=False)
        return
    with _LOCK:
        dvb_stopped = bool(_STATE.get("dvb_stopped"))
    if native_timeshift:
        # OpenATV may expose a temporary PVR/file-like reference during its
        # native transition.  It is still the same DVB ownership chain.  Do
        # not issue another setQpipMode/AUDIO_STOP after IPAUDIO is running.
        with _LOCK:
            _STATE["last_service"] = current_service
        if current_service != last_service:
            _log("R31P6 native Timeshift service transition preserved")
    elif current_service != last_service or not dvb_stopped:
        _release_main_audio_for_ipaudio(session, preserve_timeshift=False)
        with _LOCK:
            _STATE["last_service"] = current_service
        if current_service != last_service:
            _log("R25 main service changed; reapplying IPAUDIO audio isolation")

    alive = _alive_procs()
    with _LOCK:
        url = str(_STATE.get("url") or "")
        name = str(_STATE.get("name") or "IPTV")
        due = float(_STATE.get("restart_due") or 0.0)
        restarting = bool(_STATE.get("restarting"))
        headers = dict(_STATE.get("headers") or {})
        retry_resolver = _STATE.get("retry_resolver")

    now = time.time()
    needs_restart = bool(url and not alive and not restarting)
    if url and due and now >= due:
        needs_restart = True

    if needs_restart and not restarting:
        with _LOCK:
            _STATE["restart_due"] = 0.0
            _STATE["restarting"] = True
        _stop_processes_only()
        t = threading.Thread(target=_restart_worker,
                             args=(url, name, headers, retry_resolver))
        t.daemon = True
        t.start()

    if error and not url and not error_reported:
        with _LOCK:
            _STATE["error_reported"] = True
        try:
            from Screens.MessageBox import MessageBox
            if session:
                session.open(MessageBox, "Unable to start background audio:\n%s" % error,
                             MessageBox.TYPE_ERROR, timeout=7)
        except Exception:
            pass
        stop_background_audio()


def start_background_audio_direct(session, stream_url, channel_name="IPTV", headers=None,
                                  resume_context=None, retry_resolver=None):
    # R25 Native-Timeshift rule:
    # IPAUDIO must NEVER retune the DVB service or enter Local Remux implicitly.
    # Keep the currently playing satellite service owned by Enigma2 so its native
    # timeshift/seek pipeline remains available.  The extra arguments are kept
    # for Stalker/Xtream callers. resume_context is kept in-memory so reopening
    # the plugin can jump directly back to the same cached channel list.
    try:
        from .receivercompat import receiver_signature
        _log("R25 native-timeshift receiver=%s; Local Remux fallback disabled" %
             (receiver_signature() or "<unknown>"))
    except Exception:
        _log("R25 native-timeshift mode; Local Remux fallback disabled")

    arm_background_audio(session, channel_name, headers, resume_context=resume_context,
                         retry_resolver=retry_resolver)
    def worker():
        try:
            start_audio_backend(stream_url, channel_name, headers=headers)
        except Exception as e:
            report_start_error(e)
    t = threading.Thread(target=worker)
    t.daemon = True
    t.start()
    return True


def get_resume_context():
    """Return cached source/channel context while IPAUDIO is active."""
    with _LOCK:
        if not _STATE.get("wanted"):
            return {}
        context = _STATE.get("resume_context") or {}
        try:
            result = dict(context)
            if isinstance(context.get("channels"), list):
                result["channels"] = list(context.get("channels") or [])
            return result
        except Exception:
            return {}


def update_resume_context(**values):
    """Update quick-return context without touching the running audio backend."""
    with _LOCK:
        context = dict(_STATE.get("resume_context") or {})
        context.update(values)
        _STATE["resume_context"] = context
        return dict(context)


def background_audio_status():
    alive = _alive_procs()
    with _LOCK:
        wanted = bool(_STATE.get("wanted"))
        name = str(_STATE.get("name") or "")
        backend = str(_STATE.get("backend") or "")
        error = str(_STATE.get("error") or "")
        restarting = bool(_STATE.get("restarting"))
        dvb_stopped = bool(_STATE.get("dvb_stopped"))
    if alive:
        with _LOCK:
            e2_audio_disabled = bool(_STATE.get("e2_audio_disabled"))
        if e2_audio_disabled:
            isolation = "Enigma2 audio PID released"
        else:
            isolation = "DVB decoder STOP" if dvb_stopped else "audio isolation unavailable"
        return True, name, (backend + " | " + isolation)
    if wanted and restarting:
        return True, name, "restarting"
    if wanted and not error:
        return True, name, "starting"
    return False, name, backend


def prepare_foreground_playback():
    """Release IPAudio before XKlass starts a normal foreground A/V service."""
    with _LOCK:
        active = bool(_STATE.get("wanted")) or bool(_STATE.get("procs"))
    if not active:
        return False
    _log("R30 foreground playback preflight: stopping IPAUDIO cleanly")
    return stop_background_audio(restore_main=True)


def stop_background_audio(restore_main=True):
    with _LOCK:
        procs = list(_STATE.get("procs", []))
        session = _STATE.get("session")
        had_state = bool(_STATE.get("wanted")) or bool(procs)
        _STATE["wanted"] = False
        _STATE["name"] = ""
        _STATE["url"] = ""
        _STATE["backend"] = ""
        _STATE["procs"] = []
        _STATE["restart_due"] = 0.0
        _STATE["restarting"] = False
        _STATE["error"] = ""
        _STATE["error_reported"] = False
        _STATE["headers"] = {}
        _STATE["retry_resolver"] = None
        _STATE["bridge_port"] = 0
        _STATE["resume_context"] = {}
        _STATE["sink_retry_count"] = 0
        _STATE["sink_handoff_until"] = 0.0
        _STATE["vu_handoff_phase"] = ""
        _STATE["vu_handoff_action"] = ""
        _STATE["vu_handoff_started"] = 0.0
        _STATE["vu_video_paused"] = False
    _stop_timer()
    try:
        if _KEY_TIMER is not None:
            _KEY_TIMER.stop()
    except Exception:
        pass
    try:
        if _STOP_TIMER is not None:
            _STOP_TIMER.stop()
    except Exception:
        pass
    try:
        if _VU_HANDOFF_TIMER is not None:
            _VU_HANDOFF_TIMER.stop()
    except Exception:
        pass
    _unbind_pause_isolation()

    # Stop the independent ALSA (or compatibility DVB) sink first, then let
    # Enigma2 recreate/restore its own satellite audio decoder.
    _terminate_procs(procs)
    if restore_main:
        _restore_main_audio_after_ipaudio(session)

    with _LOCK:
        _STATE["session"] = None
        _STATE["dvb_stopped"] = False
        _STATE["e2_audio_disabled"] = False
        _STATE["dvb_devices"] = []
    if restore_main:
        _log("Background audio stopped; native Enigma2 audio restored")
    else:
        _log("Background audio stopped for foreground service handoff")
    return had_state


def _stop_native_timeshift(session):
    """Stop native Enigma2 Timeshift without retuning the DVB service.

    Images expose the high-level controller under Screens.InfoBar, while some
    older forks only make the service-level iTimeshift object available.  Use
    the controller first so its seek/UI state is cleaned up, then keep a small
    service-level fallback for cross-image compatibility.
    """
    stopped = False
    try:
        from Screens.InfoBar import InfoBar
        infobar = getattr(InfoBar, "instance", None)
        callback = getattr(infobar, "stopTimeshiftcheckTimeshiftRunningCallback", None)
        if callable(callback):
            callback(True)
            stopped = True
            _log("R31 native Timeshift stopped through InfoBar callback")
        elif infobar is not None:
            action = getattr(infobar, "stopTimeshift", None)
            if callable(action):
                action()
                stopped = True
                _log("R31 native Timeshift stop requested through InfoBar")
    except Exception as e:
        _log("R31 InfoBar Timeshift stop unavailable: %s" % e)

    if stopped:
        return True

    try:
        service = session.nav.getCurrentService() if session and getattr(session, "nav", None) else None
        timeshift = service and service.timeshift()
        if timeshift is None:
            return False
        enabled = getattr(timeshift, "isTimeshiftEnabled", None)
        if callable(enabled) and not enabled():
            return False
        action = getattr(timeshift, "stopTimeshift", None)
        if not callable(action):
            return False
        try:
            action(True)
        except TypeError:
            action()
        _log("R31 native Timeshift stopped through service fallback")
        return True
    except Exception as e:
        _log("R31 service Timeshift stop failed: %s" % e)
        return False


def _close_active_xklass_dialog(session):
    try:
        dialog = getattr(session, "current_dialog", None) if session else None
        module = str(getattr(getattr(dialog, "__class__", None), "__module__", "") or "")
        if dialog is not None and (module.startswith("Plugins.Extensions.XKlass") or ".XKlass." in module):
            dialog.close()
            _log("R31 active Alkuds ipaudio screen closed after STOP")
            return True
    except Exception as e:
        _log("R31 unable to close active plugin screen: %s" % e)
    return False


def stop_ipaudio_and_timeshift(session=None, close_plugin=False):
    """One public, idempotent shutdown path for the square STOP button."""
    with _LOCK:
        active_session = session or _STATE.get("session")
    had_audio = stop_background_audio(restore_main=True)
    stopped_timeshift = _stop_native_timeshift(active_session)
    closed = _close_active_xklass_dialog(active_session) if close_plugin else False
    _log("R31 full stop complete audio=%s timeshift=%s screen=%s" %
         (had_audio, stopped_timeshift, closed))
    return had_audio, stopped_timeshift, closed
