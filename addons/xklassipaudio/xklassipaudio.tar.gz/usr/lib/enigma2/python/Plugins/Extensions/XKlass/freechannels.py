#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Free Arabic TV catalogues with on-demand provider refresh."""

from __future__ import print_function

import re
import threading
import time

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from enigma import eTimer, getDesktop

from .freeproviders import (
    fetch_drama_channels,
    fetch_drama_episodes,
    fetch_drama_show_topics,
    fetch_drama_shows,
    fetch_drama_topics,
    fetch_elahmad_catalogue,
    fetch_fajer_channels,
    fetch_yacine_categories,
    fetch_yacine_channels,
    fetch_syria_live_events,
    fetch_egybest_live_groups,
    fetch_egybest_items,
    fetch_egybest_seasons,
    fetch_egybest_episodes,
    fetch_original_groups,
    fetch_original_items,
    fetch_original_seasons,
    fetch_original_episodes,
    fetch_ostora_groups,
    fetch_ostora_items,
    fetch_ostora_seasons,
    fetch_ostora_episodes,
    resolve_drama_channel,
    resolve_drama_episode,
    resolve_elahmad_channel,
    resolve_fajer_channel,
    resolve_yacine_channel,
    resolve_syria_live_event,
    resolve_egybest_item,
    resolve_original_item,
    resolve_ostora_item,
    resolve_ostora_live_item,
    hls_variant_streams,
    service_stream_url,
    stream_quality_label,
)
from .plugin import cfg
from .receivercompat import selected_free_service_type, set_selected_free_service_type
from .streamproxy import prepare_hls_relay
from .xStaticText import StaticText


COLOR_WHITE = 0x00FFFFFF
COLOR_GREEN = 0x006DFF86
COLOR_RED = 0x00FF6464


def _list_entry(text, value, marker="", marker_color=COLOR_WHITE):
    return (str(text or ""), value, str(marker or ""), int(marker_color))


def _free_channels_skin():
    """Roomier card-style browser dedicated to the free-TV screens."""
    size = getDesktop(0).size()
    width = size.width()
    height = size.height()
    panel_w = int(width * .54)
    if panel_w < 620:
        panel_w = min(width - 20, 620)
    margin = max(12, int(width * .012))
    top_h = 72 if height >= 1080 else 58
    foot_h = 58 if height >= 1080 else 48
    font = 31 if width >= 1920 else 25 if width > 1280 else 23
    title_font = font + 4
    item_h = font + 25
    list_h = height - top_h - foot_h
    row_w = panel_w - margin - 34
    text_w = row_w - 62
    key_w = int((panel_w - (margin * 2)) / 4.0)
    return '''<screen name="XKlassFreeTVList" position="0,0" size="%d,%d" backgroundColor="#ff000000" flags="wfNoBorder">
        <eLabel position="0,0" size="%d,%d" backgroundColor="#e0101b32" zPosition="1" />
        <widget source="title" render="Label" position="%d,7" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#e0101b32" valign="center" noWrap="1" transparent="0" zPosition="2" />
        <widget source="list" render="Listbox" position="%d,%d" size="%d,%d" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" backgroundColor="#e0101b32" backgroundColorSelected="#245a9c" scrollbarMode="showOnDemand" enableWrapAround="1" transparent="0" zPosition="2">
          <convert type="TemplatedMultiContent">{"template":[MultiContentEntryText(pos=(8,4),size=(50,%d),font=0,flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER,text=2,color=3,color_sel=3,backcolor=0x182744,backcolor_sel=0x245a9c),MultiContentEntryText(pos=(58,4),size=(%d,%d),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=0,color=0xFFFFFF,color_sel=0xFFFFFF,backcolor=0x182744,backcolor_sel=0x245a9c)],"fonts":[gFont("Regular",%d)],"itemHeight":%d}</convert>
        </widget>
        <eLabel position="0,%d" size="%d,%d" backgroundColor="#e0081020" zPosition="1" />
        <widget source="key_red" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ff8585" backgroundColor="#e0081020" valign="center" transparent="0" zPosition="2" />
        <widget source="key_green" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#7dff91" backgroundColor="#e0081020" valign="center" transparent="0" zPosition="2" />
        <widget source="key_yellow" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#fff18a" backgroundColor="#e0081020" valign="center" transparent="0" zPosition="2" />
        <widget source="key_blue" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#82bfff" backgroundColor="#e0081020" valign="center" transparent="0" zPosition="2" />
    </screen>''' % (
        width, height, panel_w, height, margin, panel_w - margin * 2, top_h - 12, title_font,
        margin, top_h, panel_w - margin, list_h, item_h - 8, text_w, item_h - 8, font, item_h,
        height - foot_h, panel_w, foot_h,
        margin, height - foot_h + 4, key_w, foot_h - 8, max(17, font - 5),
        margin + key_w, height - foot_h + 4, key_w, foot_h - 8, max(17, font - 5),
        margin + key_w * 2, height - foot_h + 4, key_w, foot_h - 8, max(17, font - 5),
        margin + key_w * 3, height - foot_h + 4, key_w, foot_h - 8, max(17, font - 5))


def _alpha_key(item):
    value = item.get("name", "") if isinstance(item, dict) else item
    try:
        if not isinstance(value, str):
            value = value.decode("utf-8", "replace")
    except Exception:
        pass
    try:
        return value.strip().lower()
    except Exception:
        return str(value).strip().lower()


def _natural_key(item):
    value = _alpha_key(item)
    parts = []
    for part in re.split(r"(\d+)", value):
        parts.append((1, int(part)) if part.isdigit() else (0, part))
    return parts


def _prepared_stream_entries(item):
    """Yield (raw_stream_dict, prepared_service_url) pairs, in order.

    Shared by _prepared_stream_urls() and _prepared_stream_labels() so the
    two lists can never drift out of sync with each other.
    """
    streams = item.get("streams") or []
    if not streams:
        streams = [{"url": value, "headers": item.get("headers", {})}
                   for value in list(item.get("urls") or [item.get("url")])]
    for stream in streams:
        if not isinstance(stream, dict):
            stream = {"url": stream, "headers": item.get("headers", {})}
        url = str(stream.get("url") or "").strip()
        if not url:
            continue
        headers = stream.get("headers") if isinstance(stream.get("headers"), dict) else {}
        swap = stream.get("swap") if isinstance(stream.get("swap"), dict) else {}
        mediatype = str(stream.get("mediatype") or "").strip().lower()
        force_relay = bool(stream.get("relay"))
        if (swap or force_relay) and url.lower().startswith(("http://", "https://")) and mediatype in ("", "hls"):
            prepared_url = prepare_hls_relay(url, headers, swap, stream.get("relay_options") or stream.get("ostora_hls") or {})
        else:
            prepared_url = service_stream_url(url, headers)
        yield stream, prepared_url


def _prepared_stream_urls(item):
    return [prepared_url for _stream, prepared_url in _prepared_stream_entries(item)]


def _prepared_stream_labels(item):
    """Return labels without network probes; probing every server froze E2."""
    labels = []
    for stream, _prepared_url in _prepared_stream_entries(item):
        url = str(stream.get("url") or "").strip()
        headers = stream.get("headers") if isinstance(stream.get("headers"), dict) else {}
        supplied = str(stream.get("quality") or "").strip()
        if not supplied:
            name_match = re.search(r"(?:^|\D)(2160|1440|1080|720|576|480|360|244)(?:p|\D|$)",
                                   str(stream.get("name") or ""), re.I)
            supplied = "%sp" % name_match.group(1) if name_match else ""
        labels.append(supplied)
    return labels


class _ListNavigationMixin(object):
    def choose_player(self):
        current = selected_free_service_type()
        choices = [
            ((u"✓ " if current == 5002 else u"") + u"ExtePlayer3 (5002)", 5002),
            ((u"✓ " if current == 5001 else u"") + u"GStreamer (5001)", 5001),
            ((u"✓ " if current == 4097 else u"") + u"IPTV الأصلي (4097)", 4097),
        ]
        self.session.openWithCallback(
            self._player_chosen, ChoiceBox,
            title=u"اختر المشغل الثابت لقنوات Free Arabic TV", list=choices)

    def _player_chosen(self, choice):
        if not choice:
            return
        try:
            set_selected_free_service_type(choice[1])
            if hasattr(self, "_update_title"):
                self._update_title()
            self.session.open(
                MessageBox, u"تم تثبيت المشغل %s ولن يتغير تلقائياً." % choice[1],
                MessageBox.TYPE_INFO, timeout=3)
        except Exception as error:
            self.session.open(MessageBox, str(error), MessageBox.TYPE_ERROR, timeout=5)

    def _move_list(self, movement):
        try:
            instance = self["list"].master.master.instance
            instance.moveSelection(getattr(instance, movement))
        except Exception:
            pass

    def go_up(self):
        self._move_list("moveUp")

    def go_down(self):
        self._move_list("moveDown")

    def page_up(self):
        self._move_list("pageUp")

    def page_down(self):
        self._move_list("pageDown")

    def _safe_close(self):
        """Detach asynchronous callbacks before a receiver destroys the screen."""
        # Re-entrancy guard: a fast double "cancel"/back press (or a cancel
        # arriving while the poll timer is also mid-callback) can call this
        # twice for the same screen. The second self.close() then runs on an
        # instance that is already being torn down, which raised an
        # unhandled exception straight out of the ActionMap key callback and
        # took the whole receiver down with it. One flag makes the method
        # idempotent.
        if getattr(self, "_closing", False):
            return
        self._closing = True
        self._closed = True
        timer = getattr(self, "_timer", None)
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
            # Drop the timeout connection too, not just stop() the timer.
            # While stopped it can no longer fire, but leaving the signal
            # wired to self._poll keeps a live native callback pointed at a
            # screen instance that is about to be destroyed.
            timer_conn = getattr(self, "_timer_conn", None)
            if timer_conn is not None:
                try:
                    timer.timeout.disconnect(timer_conn)
                except Exception:
                    pass
                self._timer_conn = None
        try:
            self["actions"].setEnabled(False)
        except Exception:
            pass
        try:
            self.close()
        except Exception:
            # self.close() can itself raise (e.g. the underlying C/C++
            # screen object is already gone) if teardown was already under
            # way. Every other step here is defensively wrapped except this
            # one used to be - letting it raise inside a key-press callback
            # is what turned into the visible "crash".
            pass


class XKlass_FreeTV_Menu(_ListNavigationMixin, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self["title"] = StaticText("Alkuds ipaudio - Free Arabic TV")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["list"] = List([
            _list_entry(u"الأسطورة", "ostora", u"●", 0x00FFD166),
            _list_entry(u"عالم الترفيه", "entertainment", u"●", COLOR_GREEN),
            _list_entry(u"تلفزيون ياسين", "yacine", u"●", 0x00FF9F5A),
            _list_entry(u"سيريا لايف", "syrialive", u"●", 0x00FF6464),
            _list_entry(u"ايجي بيست", "egybest", u"●", 0x00FFB347),
            _list_entry(u"اوريجينال تي في", "originaltv", u"●", 0x00C58AFF),
            _list_entry(u"قنوات عربية مباشرة", "elahmad", u"●", 0x0082BFFF),
            _list_entry("Al Fajer 1 - 5 (dynamic)", "alfajer", u"●", 0x00FFF18A),
        ], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player,
            "cancel": self.close,
            "red": self.close,
            "ok": self.open_current,
            "green": self.open_current,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
        }, -2)

    def open_current(self):
        current = self["list"].getCurrent()
        if current and current[1]:
            if current[1] == "ostora":
                self.session.open(XKlass_Ostora_Menu)
            elif current[1] == "entertainment":
                self.session.open(XKlass_Entertainment_Menu)
            elif current[1] == "yacine":
                self.session.open(XKlass_Yacine_Categories)
            elif current[1] == "egybest":
                self.session.open(XKlass_Egybest_Menu)
            elif current[1] == "originaltv":
                self.session.open(XKlass_OriginalTV_Menu)
            else:
                self.session.open(XKlass_FreeTV_Channels, current[1])


class XKlass_Ostora_Menu(_ListNavigationMixin, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self["title"] = StaticText(u"Alkuds ipaudio - الأسطورة")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["list"] = List([
            _list_entry(u"لايف", "live", u"●", COLOR_GREEN),
            _list_entry(u"مسلسلات", "series", u"●", 0x0082BFFF),
            _list_entry(u"أفلام", "movie", u"●", 0x00FFF18A),
        ], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player, "cancel": self.close, "red": self.close,
            "ok": self.open_current, "green": self.open_current,
            "up": self.go_up, "down": self.go_down, "left": self.page_up, "right": self.page_down,
        }, -2)

    def open_current(self):
        current = self["list"].getCurrent()
        if current and current[1] in ("live", "series", "movie"):
            self.session.open(XKlass_Ostora_Browser, current[1], "groups")


class XKlass_Entertainment_Menu(_ListNavigationMixin, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self["title"] = StaticText(u"Alkuds ipaudio - عالم الترفيه")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["list"] = List([
            _list_entry("Live", "live", u"●", COLOR_GREEN),
            _list_entry(u"المسلسلات - عالم الترفيه", "series", u"●", 0x0082BFFF),
            _list_entry(u"الأفلام - عالم الترفيه", "movie", u"●", 0x00FFF18A),
        ], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player,
            "cancel": self.close,
            "red": self.close,
            "ok": self.open_current,
            "green": self.open_current,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
        }, -2)

    def open_current(self):
        current = self["list"].getCurrent()
        if not current:
            return
        if current[1] == "live":
            self.session.open(XKlass_Drama_Topics)
        elif current[1] in ("series", "movie"):
            self.session.open(XKlass_Drama_Catalog, current[1], "topics")


class XKlass_Egybest_Menu(_ListNavigationMixin, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self["title"] = StaticText(u"Alkuds ipaudio - ايجي بيست")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["list"] = List([
            _list_entry("Live", "live", u"●", COLOR_GREEN),
            _list_entry("Series", "series", u"●", 0x0082BFFF),
            _list_entry("Movie", "movie", u"●", 0x00FFF18A),
        ], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player,
            "cancel": self.close, "red": self.close,
            "ok": self.open_current, "green": self.open_current,
            "up": self.go_up, "down": self.go_down,
            "left": self.page_up, "right": self.page_down,
        }, -2)

    def open_current(self):
        current = self["list"].getCurrent()
        if current and current[1] in ("live", "series", "movie"):
            self.session.open(XKlass_Egybest_Browser, current[1],
                              "groups" if current[1] == "live" else "items")


class XKlass_OriginalTV_Menu(_ListNavigationMixin, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self["title"] = StaticText(u"Alkuds ipaudio - اوريجينال تي في")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["list"] = List([
            _list_entry("Live", "live", u"●", COLOR_GREEN),
            _list_entry(u"Matches - المباريات", "matches", u"●", COLOR_RED),
            _list_entry(u"المسلسلات - Reezn", "series", u"●", 0x0082BFFF),
            _list_entry(u"الأفلام - Reezn", "movie", u"●", 0x00FFF18A),
        ], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player,
            "cancel": self.close, "red": self.close,
            "ok": self.open_current, "green": self.open_current,
            "up": self.go_up, "down": self.go_down,
            "left": self.page_up, "right": self.page_down,
        }, -2)

    def open_current(self):
        current = self["list"].getCurrent()
        if current and current[1] in ("live", "matches", "series", "movie"):
            self.session.open(XKlass_OriginalTV_Browser, current[1],
                              "items" if current[1] == "matches" else "groups")


class XKlass_Yacine_Categories(_ListNavigationMixin, Screen):
    """Dynamic Yacine TV category tree (including movie/series channels)."""

    def __init__(self, session, parent=None):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self.parent = dict(parent or {})
        self.entries = []
        self._loading = False
        self._done = False
        self._result = None
        self._error = ""
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self["title"] = StaticText(self._title())
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("Refresh")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player,
            "cancel": self.back,
            "red": self.back,
            "ok": self.open_current,
            "green": self.open_current,
            "blue": self.load,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
            "channelUp": self.page_up,
            "channelDown": self.page_down,
        }, -2)
        self.onFirstExecBegin.append(self.load)

    def _title(self, suffix=""):
        label = str(self.parent.get("name") or "").strip()
        return (u"تلفزيون ياسين" + (" - " + label if label else "") + suffix)

    def load(self):
        if self._loading:
            return
        self._loading = True
        self._done = False
        self._result = None
        self._error = ""
        self["list"].setList([_list_entry("Loading Yacine TV categories...", -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            self._result = fetch_yacine_categories(cfg.useragent.value, self.parent)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self["list"].setList([_list_entry("Yacine TV categories are unavailable.", -1,
                                               u"●", COLOR_RED)])
            self.session.open(MessageBox, "Unable to load Yacine TV:\n%s" % self._error,
                              MessageBox.TYPE_ERROR, timeout=8)
            return
        self.entries = list(self._result or [])
        rows = [_list_entry("%03d   %s" % (index + 1, item.get("name") or "Category"), index)
                for index, item in enumerate(self.entries)]
        self["list"].setList(rows or [_list_entry("No Yacine TV categories are available.", -1)])
        self["title"].setText(self._title("  [%d]" % len(self.entries)))

    def open_current(self):
        if self._loading:
            return
        current = self["list"].getCurrent()
        try:
            index = int(current[1]) if current else -1
        except Exception:
            index = -1
        if index < 0 or index >= len(self.entries):
            return
        item = dict(self.entries[index])
        if int(item.get("child_count") or 0) > 0:
            self.session.open(XKlass_Yacine_Categories, item)
        else:
            self.session.open(XKlass_FreeTV_Channels, "yacine", item)

    def back(self):
        self._safe_close()


class XKlass_Drama_Topics(_ListNavigationMixin, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self.topics = []
        self._loading = False
        self._done = False
        self._result = None
        self._error = ""
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self["title"] = StaticText(u"عالم الترفيه - Live")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("Refresh")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player,
            "cancel": self.back,
            "red": self.back,
            "ok": self.open_current,
            "green": self.open_current,
            "blue": self.load,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
            "channelUp": self.page_up,
            "channelDown": self.page_down,
        }, -2)
        self.onFirstExecBegin.append(self.load)

    def load(self):
        if self._loading:
            return
        self._loading = True
        self._done = False
        self._result = None
        self._error = ""
        self["list"].setList([_list_entry("Loading Live groups...", -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            self._result = fetch_drama_topics(cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self["list"].setList([_list_entry("Live groups are unavailable.", -1, u"●", COLOR_RED)])
            self.session.open(MessageBox, "Unable to load Live groups:\n%s" % self._error,
                              MessageBox.TYPE_ERROR, timeout=8)
            return
        # Preserve the provider's priority/order (especially current matches).
        self.topics = list(self._result or [])
        rows = [_list_entry("%03d   %s" % (index + 1, item.get("name") or "Group"), index)
                for index, item in enumerate(self.topics)]
        self["list"].setList(rows or [_list_entry("No Live groups are available.", -1)])
        self["title"].setText(u"عالم الترفيه - Live  [%d]" % len(self.topics))

    def open_current(self):
        if self._loading:
            return
        current = self["list"].getCurrent()
        try:
            index = int(current[1]) if current else -1
        except Exception:
            index = -1
        if 0 <= index < len(self.topics):
            self.session.open(XKlass_FreeTV_Channels, "dramalive", self.topics[index])

    def back(self):
        self._safe_close()


class XKlass_Drama_Catalog(_ListNavigationMixin, Screen):
    """Series/Movie groups, titles and episodes from the source application."""

    def __init__(self, session, kind="series", level="topics", parent=None):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self.kind = kind if kind in ("series", "movie") else "series"
        self.level = level if level in ("topics", "shows", "episodes") else "topics"
        self.parent = dict(parent or {})
        self.entries = []
        self._loading = False
        self._done = False
        self._result = None
        self._error = ""
        self._closed = False
        self._operation = "load"
        self._selected_index = -1
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self["title"] = StaticText("")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open" if self.level != "episodes" else "Play")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("Refresh")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player,
            "cancel": self.back,
            "red": self.back,
            "ok": self.open_current,
            "green": self.open_current,
            "blue": self.load,
            "stop": self.stop_stream,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
            "channelUp": self.page_up,
            "channelDown": self.page_down,
        }, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()

    def _label(self):
        section = "Series" if self.kind == "series" else "Movie"
        if self.level == "topics":
            return u"عالم الترفيه - %s" % section
        return u"عالم الترفيه - %s - %s" % (section, str(self.parent.get("name") or ""))

    def _update_title(self, suffix=""):
        self["title"].setText("%s%s" % (self._label(), suffix))

    def load(self):
        if self._loading:
            return
        self._operation = "load"
        self._loading = True
        self._done = False
        self._result = None
        self._error = ""
        self["list"].setList([_list_entry("Loading entertainment catalogue...", -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == "topics":
                self._result = fetch_drama_show_topics(self.kind, cfg.useragent.value)
            elif self.level == "shows":
                self._result = fetch_drama_shows(self.parent, cfg.useragent.value)
            else:
                self._result = fetch_drama_episodes(self.parent, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _resolve_worker(self, item):
        try:
            self._result = resolve_drama_episode(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _set_rows(self):
        rows = [_list_entry("%03d   %s" % (index + 1, item.get("name") or "Item"), index)
                for index, item in enumerate(self.entries)]
        self["list"].setList(rows or [_list_entry("No items are currently available.", -1)])
        if 0 <= self._selected_index < len(self.entries):
            try:
                self["list"].setIndex(self._selected_index)
            except Exception:
                pass

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self._set_rows()
            self._update_title("  [failed]")
            self.session.open(MessageBox, "Unable to load entertainment content:\n%s" % self._error,
                              MessageBox.TYPE_ERROR, timeout=8)
            return
        if self._operation == "load":
            sort_key = _natural_key if self.level == "episodes" else _alpha_key
            self.entries = sorted(list(self._result or []), key=sort_key)
            self._set_rows()
            self._update_title("  [%d]" % len(self.entries))
            return
        self._start_resolved(self._result)

    def _index(self):
        current = self["list"].getCurrent()
        try:
            return int(current[1]) if current else -1
        except Exception:
            return -1

    def open_current(self):
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if self.level == "topics":
            self.session.open(XKlass_Drama_Catalog, self.kind, "shows", item)
        elif self.level == "shows":
            self.session.open(XKlass_Drama_Catalog, self.kind, "episodes", item)
        else:
            self._operation = "resolve"
            self._loading = True
            self._done = False
            self._result = None
            self._error = ""
            self._update_title("  [resolving stream...]")
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)

    def _start_resolved(self, item):
        if not isinstance(item, dict) or not item.get("url"):
            self.session.open(MessageBox, "No playable link was returned.",
                              MessageBox.TYPE_ERROR, timeout=6)
            return
        prepared = _prepared_stream_urls(item)
        if not prepared:
            self.session.open(MessageBox, "No playable link was returned.",
                              MessageBox.TYPE_ERROR, timeout=6)
            return
        category = "Series" if self.kind == "series" else "Movie"
        if len(prepared) > 1:
            labels = _prepared_stream_labels(item)
            resume_key = "%s:%s" % (self.kind, str(item.get("id") or item.get("name") or "video"))
            self.session.open(
                XKlass_StreamChooser, prepared, labels, item,
                str(item.get("name") or "Video"), category,
                str(self.parent.get("name") or ""), str(item.get("image") or ""),
                resume_key, False)
            return
        self._open_video(prepared, item, category)

    def _open_video(self, prepared, item, category):
        # VOD deliberately has no close callback.  A few receiver images crash
        # while restoring the parent screen from an openWithCallback teardown.
        from .freeplayer import XKlass_FreeTV_Player
        resume_key = "%s:%s" % (self.kind, str(item.get("id") or item.get("name") or "video"))
        self.session.open(
            XKlass_FreeTV_Player, prepared, selected_free_service_type(),
            str(item.get("name") or "Video"), category,
            str(self.parent.get("name") or ""), str(item.get("image") or ""),
            resume_key)

    def _player_closed(self, result=None, *args):
        self._set_rows()
        self._update_title("  [%d]" % len(self.entries))
        action = result[0] if isinstance(result, (tuple, list)) and result else result
        if action == "failed" and not self._closed:
            self.session.open(MessageBox, "This video is offline or did not start.",
                              MessageBox.TYPE_ERROR, timeout=6)

    def stop_stream(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass

    def back(self):
        self._safe_close()


class XKlass_Egybest_Browser(_ListNavigationMixin, Screen):
    """Paged Egybest browser: categories/titles/seasons/episodes."""

    def __init__(self, session, kind="movie", level="items", parent=None, page=1):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self.kind = kind if kind in ("live", "series", "movie") else "movie"
        self.level = level if level in ("groups", "items", "seasons", "episodes", "servers") else "items"
        self.parent = dict(parent or {})
        self.page, self.last_page, self.total = max(1, int(page or 1)), 1, 0
        self.entries, self._result, self._error = [], None, ""
        self._loading = self._done = self._closed = False
        self._operation, self._selected_index = "load", -1
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self["title"] = StaticText("")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Play" if self.level == "episodes" else "Open")
        self["key_yellow"] = StaticText("Previous" if self.level == "items" else "")
        self["key_blue"] = StaticText("Next" if self.level == "items" else "Refresh")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player,
            "cancel": self.back, "red": self.back,
            "ok": self.open_current, "green": self.open_current,
            "yellow": self.previous_page, "blue": self.next_or_refresh,
            "stop": self.stop_stream, "up": self.go_up, "down": self.go_down,
            "left": self.page_up, "right": self.page_down,
            "channelUp": self.page_up, "channelDown": self.page_down,
        }, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()

    def _label(self):
        section = {"live": "Live", "series": "Series", "movie": "Movie"}[self.kind]
        parent = str(self.parent.get("name") or "").strip()
        return u"ايجي بيست - %s%s" % (section, " - " + parent if parent else "")

    def _update_title(self, suffix=""):
        page = "  [Page %d/%d]" % (self.page, self.last_page) if self.level == "items" and self.last_page > 1 else ""
        self["title"].setText(self._label() + page + suffix)

    def load(self):
        if self._loading:
            return
        self._operation, self._loading, self._done = "load", True, False
        self._result, self._error = None, ""
        self["list"].setList([_list_entry("Loading Egybest catalogue...", -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == "groups":
                self._result = fetch_egybest_live_groups(cfg.useragent.value)
            elif self.level == "items":
                self._result = fetch_egybest_items(self.kind, cfg.useragent.value,
                                                   self.parent, self.page)
            elif self.level == "seasons":
                self._result = fetch_egybest_seasons(self.parent, cfg.useragent.value)
            else:
                self._result = fetch_egybest_episodes(self.parent, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _resolve_worker(self, item):
        try:
            self._result = resolve_egybest_item(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _set_rows(self):
        rows = [_list_entry("%03d   %s" % (i + 1, item.get("name") or "Item"), i)
                for i, item in enumerate(self.entries)]
        self["list"].setList(rows or [_list_entry("No items are currently available.", -1)])
        if 0 <= self._selected_index < len(self.entries):
            try:
                self["list"].setIndex(self._selected_index)
            except Exception:
                pass

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self._set_rows()
            self._update_title("  [failed]")
            self.session.open(MessageBox, "Unable to load Egybest content:\n%s" % self._error,
                              MessageBox.TYPE_ERROR, timeout=8)
            return
        if self._operation == "resolve":
            self._start_resolved(self._result)
            return
        if self.level == "items" and isinstance(self._result, dict):
            self.entries = list(self._result.get("entries") or [])
            self.page = int(self._result.get("page") or self.page)
            self.last_page = max(self.page, int(self._result.get("last_page") or self.page))
            self.total = int(self._result.get("total") or len(self.entries))
        else:
            self.entries = list(self._result or [])
            if self.level in ("seasons", "episodes"):
                self.entries = sorted(self.entries, key=_natural_key)
        self._set_rows()
        self._update_title("  [%d]" % (self.total if self.level == "items" else len(self.entries)))

    def _index(self):
        current = self["list"].getCurrent()
        try:
            return int(current[1]) if current else -1
        except Exception:
            return -1

    def open_current(self):
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if self.level == "groups":
            self.session.open(XKlass_Egybest_Browser, "live", "items", item, 1)
        elif self.level == "items" and self.kind == "series":
            self.session.open(XKlass_Egybest_Browser, "series", "seasons", item, 1)
        elif self.level == "seasons":
            self.session.open(XKlass_Egybest_Browser, "series", "episodes", item, 1)
        else:
            self._operation, self._loading, self._done = "resolve", True, False
            self._result, self._error = None, ""
            self._update_title("  [resolving stream...]")
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)

    def _start_resolved(self, item):
        prepared = _prepared_stream_urls(item) if isinstance(item, dict) else []
        if not prepared:
            self.session.open(MessageBox, "No playable link was returned.",
                              MessageBox.TYPE_ERROR, timeout=6)
            return
        live = self.kind == "live"
        category = "Live" if live else ("Series" if self.kind == "series" else "Movie")
        description = str(self.parent.get("name") or item.get("description") or "")
        resume_key = "" if live else "egybest:%s:%s" % (self.kind, item.get("id") or item.get("name"))
        if len(prepared) > 1:
            self.session.open(XKlass_StreamChooser, prepared, _prepared_stream_labels(item), item,
                              str(item.get("name") or "Egybest"), category, description,
                              str(item.get("image") or ""), resume_key, live)
        else:
            from .freeplayer import XKlass_FreeTV_Player
            self.session.open(XKlass_FreeTV_Player, prepared, selected_free_service_type(),
                              str(item.get("name") or "Egybest"), category, description,
                              str(item.get("image") or ""), resume_key)

    def previous_page(self):
        if self.level == "items" and not self._loading and self.page > 1:
            self.page -= 1
            self._selected_index = -1
            self.load()

    def next_or_refresh(self):
        if self.level != "items":
            self.load()
        elif not self._loading and self.page < self.last_page:
            self.page += 1
            self._selected_index = -1
            self.load()

    def stop_stream(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass

    def back(self):
        self._safe_close()


class XKlass_Ostora_Browser(XKlass_Egybest_Browser):
    """Ostora TV API browser; catalogue is always fetched live from the APK API."""
    def __init__(self, session, kind="movie", level="groups", parent=None, page=1):
        XKlass_Egybest_Browser.__init__(self, session, kind, level, parent, page)
        self._update_title()

    def _label(self):
        section = {"live": u"لايف", "series": u"مسلسلات", "movie": u"أفلام"}[self.kind]
        parent = str(self.parent.get("name") or "").strip()
        return u"الأسطورة - %s%s" % (section, " - " + parent if parent else "")

    def load(self):
        if self._loading: return
        self._operation, self._loading, self._done = "load", True, False
        self._result, self._error = None, ""
        self["list"].setList([_list_entry(u"جاري جلب بيانات الأسطورة...", -1)])
        worker = threading.Thread(target=self._load_worker); worker.daemon = True; worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == "groups": self._result = fetch_ostora_groups(self.kind, cfg.useragent.value)
            elif self.level == "items": self._result = fetch_ostora_items(self.kind, cfg.useragent.value, self.parent, self.page)
            elif self.level == "seasons": self._result = fetch_ostora_seasons(self.parent, cfg.useragent.value)
            else: self._result = fetch_ostora_episodes(self.parent, cfg.useragent.value)
        except Exception as error: self._error = str(error)
        self._done = True

    def _resolve_worker(self, item):
        try:
            if self.kind == "live":
                self._result = resolve_ostora_live_item(item, cfg.useragent.value)
            else:
                self._result = resolve_ostora_item(item, cfg.useragent.value)
        except Exception as error: self._error = str(error)
        self._done = True

    def open_current(self):
        if self._loading: return
        index = self._index()
        if index < 0 or index >= len(self.entries): return
        self._selected_index = index; item = dict(self.entries[index])
        if self.level == "groups":
            self.session.open(XKlass_Ostora_Browser, self.kind, "items", item, 1)
        elif item.get("is_group"):
            self.session.open(XKlass_Ostora_Browser, self.kind, "items", item, 1)
        elif self.level == "seasons":
            self.session.open(XKlass_Ostora_Browser, "series", "episodes", item, 1)
        else:
            self._operation, self._loading, self._done = "resolve", True, False
            self._result, self._error = None, ""
            self._update_title("  [resolving stream...]")
            worker = threading.Thread(target=self._resolve_worker, args=(item,)); worker.daemon = True; worker.start()
            self._timer.start(120, False)

    def _start_resolved(self, item):
        prepared = _prepared_stream_urls(item) if isinstance(item, dict) else []
        if not prepared:
            self.session.open(MessageBox, "No playable link was returned.", MessageBox.TYPE_ERROR, timeout=6); return
        live = self.kind == "live"
        category = "Live" if live else ("Series" if self.kind == "series" else "Movie")
        resume_key = "" if live else "ostora:%s:%s" % (self.kind, item.get("id") or item.get("name"))
        if live or len(prepared) > 1:
            self.session.open(XKlass_StreamChooser, prepared, _prepared_stream_labels(item), item,
                              str(item.get("name") or "Ostora"), category,
                              str(item.get("description") or ""), str(item.get("image") or ""), resume_key, live)
        else:
            from .freeplayer import XKlass_FreeTV_Player
            self.session.open(XKlass_FreeTV_Player, prepared, selected_free_service_type(),
                              str(item.get("name") or "Ostora"), category,
                              str(item.get("description") or ""), str(item.get("image") or ""), resume_key)


class XKlass_OriginalTV_Browser(XKlass_Egybest_Browser):
    """Original TV browser for live groups, matches, movies and series."""

    def __init__(self, session, kind="movie", level="items", parent=None, page=1):
        requested = kind if kind in ("live", "matches", "series", "movie") else "movie"
        XKlass_Egybest_Browser.__init__(
            self, session, "live" if requested == "matches" else requested,
            level, parent, page)
        self.kind = requested
        self._update_title()

    def _label(self):
        section = {"live": "Live", "matches": u"Matches - المباريات",
                   "series": "Series", "movie": "Movie"}[self.kind]
        parent = str(self.parent.get("name") or "").strip()
        return u"اوريجينال تي في - %s%s" % (section, " - " + parent if parent else "")

    def load(self):
        if self._loading:
            return
        self._operation, self._loading, self._done = "load", True, False
        self._result, self._error = None, ""
        self["list"].setList([_list_entry("Loading Original TV catalogue...", -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == "groups":
                if self.kind in ("movie", "series"):
                    from .reeznvod import groups
                    self._result = groups(self.kind)
                else:
                    self._result = fetch_original_groups(cfg.useragent.value)
            elif self.level == "servers":
                from .reeznvod import servers
                self._result = servers(self.parent)
            elif self.level == "items":
                self._result = fetch_original_items(self.kind, cfg.useragent.value,
                                                     self.parent, self.page)
            elif self.level == "seasons":
                self._result = fetch_original_seasons(self.parent, cfg.useragent.value)
            else:
                self._result = fetch_original_episodes(self.parent, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _resolve_worker(self, item):
        try:
            self._result = resolve_original_item(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self._set_rows()
            self._update_title("  [failed]")
            self.session.open(MessageBox, "Unable to load Original TV content:\n%s" % self._error,
                              MessageBox.TYPE_ERROR, timeout=8)
            return
        if self._operation == "resolve":
            self._start_resolved(self._result)
            return
        if self.level == "items" and isinstance(self._result, dict):
            self.entries = list(self._result.get("entries") or [])
            self.page = int(self._result.get("page") or self.page)
            self.last_page = max(self.page, int(self._result.get("last_page") or self.page))
            self.total = int(self._result.get("total") or len(self.entries))
        else:
            self.entries = list(self._result or [])
            if self.level in ("seasons", "episodes"):
                self.entries = sorted(self.entries, key=_natural_key)
        self._set_rows()
        self._update_title("  [%d]" % (self.total if self.level == "items" else len(self.entries)))

    def open_current(self):
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if self.level == "groups":
            action = item.get("action")
            if action in ("search", "year"):
                from Screens.VirtualKeyBoard import VirtualKeyBoard
                self._input_action = action
                self.session.openWithCallback(self._catalogue_input, VirtualKeyBoard,
                    title=u"اسم الفيلم أو المسلسل" if action == "search" else u"سنة الإنتاج", text="")
            elif action == "dramabox":
                self.session.open(XKlass_Drama_Catalog, self.kind, "topics")
            else:
                self.session.open(XKlass_OriginalTV_Browser, self.kind, "items", item, 1)
        elif self.level == "items" and self.kind == "series":
            self.session.open(XKlass_OriginalTV_Browser, "series", "seasons", item, 1)
        elif self.level == "seasons":
            self.session.open(XKlass_OriginalTV_Browser, "series", "episodes", item, 1)
        elif self.kind in ("movie", "series") and self.level in ("items", "episodes"):
            self.session.open(XKlass_OriginalTV_Browser, self.kind, "servers", item, 1)
        else:
            self._operation, self._loading, self._done = "resolve", True, False
            self._result, self._error = None, ""
            self._update_title("  [resolving stream...]")
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)

    def _catalogue_input(self, value):
        value = str(value or "").strip()
        if not value or self._closed:
            return
        media = "movie" if self.kind == "movie" else "tv"
        if self._input_action == "year":
            if not re.match(r"^\d{4}$", value) or not 1870 <= int(value) <= 2200:
                self.session.open(MessageBox, "Enter a four-digit production year.", MessageBox.TYPE_ERROR, timeout=5)
                return
            params = {"primary_release_year" if media == "movie" else "first_air_date_year": value,
                      "sort_by": "popularity.desc"}
            path = "discover/" + media
        else:
            params, path = {"query": value}, "search/" + media
        parent = {"name": value, "path": path, "params": params, "source": "reezn_vod_group"}
        self.session.open(XKlass_OriginalTV_Browser, self.kind, "items", parent, 1)

    def _start_resolved(self, item):
        prepared = _prepared_stream_urls(item) if isinstance(item, dict) else []
        if not prepared:
            self.session.open(MessageBox, "No playable non-DRM link was returned.",
                              MessageBox.TYPE_ERROR, timeout=6)
            return
        live = self.kind in ("live", "matches")
        category = {"live": "Live", "matches": "Matches",
                    "series": "Series", "movie": "Movie"}[self.kind]
        description = str(self.parent.get("name") or item.get("description") or "")
        resume_key = "" if live else "originaltv:%s:%s" % (
            self.kind, item.get("id") or item.get("name"))
        if len(prepared) > 1:
            self.session.openWithCallback(
                self._child_closed, XKlass_StreamChooser, prepared,
                _prepared_stream_labels(item), item,
                str(item.get("name") or "Original TV"), category, description,
                str(item.get("image") or ""), resume_key, live)
        else:
            from .freeplayer import XKlass_FreeTV_Player
            self.session.openWithCallback(
                self._child_closed, XKlass_FreeTV_Player, prepared,
                selected_free_service_type(),
                str(item.get("name") or "Original TV"), category, description,
                str(item.get("image") or ""), resume_key)

    def _child_closed(self, result=None, *args):
        if self.kind not in ("live", "matches") or not self.entries:
            return
        if isinstance(result, (tuple, list)):
            action = result[0] if result else None
        else:
            action = result
        if action not in ("next", "prev"):
            return
        index = self._selected_index if 0 <= self._selected_index < len(self.entries) else 0
        index = (index + (1 if action == "next" else -1)) % len(self.entries)
        self._selected_index = index
        try:
            self["list"].setIndex(index)
        except Exception:
            pass
        item = dict(self.entries[index])
        self._operation, self._loading, self._done = "resolve", True, False
        self._result, self._error = None, ""
        self._update_title("  [resolving stream...]")
        worker = threading.Thread(target=self._resolve_worker, args=(item,))
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)


class XKlass_StreamChooser(_ListNavigationMixin, Screen):
    """Persistent stream/server chooser.

    It deliberately remains below the player in the screen stack. Pressing
    Back in the player therefore returns here, allowing server 2, 3, ... to be
    selected immediately without changing the channel or episode first.
    """

    def __init__(self, session, prepared, labels, item, name, category="Live",
                 description="", image="", resume_key="", live=True):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self.prepared = list(prepared or [])
        self.labels = list(labels or [])
        self.item = dict(item or {})
        self.name = str(name or "Channel")
        self.category = str(category or "Live")
        self.description = str(description or "")
        self.image = str(image or "")
        self.resume_key = str(resume_key or "")
        self.live = bool(live)
        self.last_state = None
        self["title"] = StaticText(u"اختر مشغل التشغيل - %s" % self.name)
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Play")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        rows = []
        streams = list(self.item.get("streams") or [])
        for index in range(len(self.prepared)):
            quality = self.labels[index] if index < len(self.labels) else None
            server = ""
            if index < len(streams) and isinstance(streams[index], dict):
                server = str(streams[index].get("name") or "").strip()
            text = u"%s%s" % (server or u"سيرفر %d" % (index + 1),
                               u"  (%s)" % quality if quality else u"")
            rows.append(_list_entry(text, index, u"●", COLOR_GREEN if index == 0 else COLOR_WHITE))
        self["list"] = List(rows, enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player,
            "cancel": self.back,
            "red": self.back,
            "ok": self.play,
            "green": self.play,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
        }, -2)

    def play(self):
        current = self["list"].getCurrent()
        try:
            index = int(current[1]) if current else -1
        except Exception:
            index = -1
        if index < 0 or index >= len(self.prepared):
            return
        streams = list(self.item.get("streams") or [])
        if index < len(streams) and isinstance(streams[index], dict):
            self.session.openWithCallback(
                self._player_closed, XKlass_QualityChooser, streams[index],
                self.name, self.category, self.description, self.image,
                self.resume_key)
            return
        from .freeplayer import XKlass_FreeTV_Player
        self.session.openWithCallback(
            self._player_closed, XKlass_FreeTV_Player, [self.prepared[index]],
            selected_free_service_type(), self.name, self.category,
            self.description, self.image, self.resume_key)

    def _player_closed(self, result=None, *args):
        if isinstance(result, (tuple, list)):
            action = result[0] if result else None
            state = result[1] if len(result) > 1 else None
        else:
            action, state = result, None
        if state in ("working", "offline"):
            self.last_state = state
        if self.live and action in ("next", "prev"):
            self.close((action, self.last_state))
        elif action == "failed":
            self.session.open(MessageBox, "This player is offline or did not start.",
                              MessageBox.TYPE_ERROR, timeout=5)

    def back(self):
        if self.live:
            self.close(("back", self.last_state))
        else:
            self.close()


class XKlass_QualityChooser(_ListNavigationMixin, Screen):
    """Second-level HLS quality chooser for a selected Reezn server."""

    def __init__(self, session, stream, name, category, description, image, resume_key):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self.stream = dict(stream or {})
        self.variants = []
        self._done = False
        self._closed = False
        self._started_at = 0.0
        self.name, self.category = str(name), str(category)
        self.description, self.image = str(description), str(image)
        self.resume_key = str(resume_key or "")
        self["title"] = StaticText(u"اختر جودة التشغيل - %s" % self.name)
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Play")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["list"] = List([_list_entry(u"جاري جلب الجودات...", -1)], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player,
            "cancel": self.close, "red": self.close, "ok": self.play, "green": self.play,
            "up": self.go_up, "down": self.go_down, "left": self.page_up, "right": self.page_down,
        }, -2)
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self.onFirstExecBegin.append(self.load)
        self.onClose.append(self._cleanup)

    def load(self):
        self._started_at = time.time()
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        variants = hls_variant_streams(self.stream)
        if not self._closed and not self._done:
            self.variants = variants or [self.stream]
            self._done = True

    def _poll(self):
        if self._closed:
            return
        if not self._done:
            # A slow/odd server must never leave the receiver stuck on
            # "fetching qualities". Offer its original URL after ten seconds.
            if self._started_at and time.time() - self._started_at >= 10:
                self.variants = [self.stream]
                self._done = True
            else:
                return
        self._timer.stop()
        rows = []
        for index, item in enumerate(self.variants):
            label = str(item.get("quality") or item.get("name") or "Auto")
            if len(self.variants) == 1 and label == str(self.stream.get("name") or ""):
                label = "Auto / Original"
            rows.append(_list_entry(label, index, u"●",
                                    COLOR_GREEN if index == 0 else COLOR_WHITE))
        self["list"].setList(rows or [_list_entry("No playable quality", -1)])

    def _cleanup(self):
        self._closed = True
        try:
            self._timer.stop()
        except Exception:
            pass

    def play(self):
        current = self["list"].getCurrent()
        try:
            index = int(current[1]) if current else -1
        except Exception:
            index = -1
        if index < 0 or index >= len(self.variants):
            return
        stream = self.variants[index]
        url = str(stream.get("url") or "")
        headers = stream.get("headers") or {}
        mediatype = str(stream.get("mediatype") or "").strip().lower()
        if stream.get("relay") and url.lower().startswith(("http://", "https://")) and mediatype in ("", "hls"):
            prepared = prepare_hls_relay(url, headers, stream.get("swap") or {}, stream.get("relay_options") or stream.get("ostora_hls") or {})
        else:
            prepared = service_stream_url(url, headers)
        from .freeplayer import XKlass_FreeTV_Player
        self.session.openWithCallback(
            self._player_closed, XKlass_FreeTV_Player, [prepared],
            selected_free_service_type(), self.name, self.category,
            self.description, self.image, self.resume_key)

    def _player_closed(self, result=None, *args):
        if isinstance(result, (tuple, list)) and result and result[0] in ("next", "prev"):
            self.close(result)


class XKlass_FreeTV_Channels(_ListNavigationMixin, Screen):
    def __init__(self, session, provider="alfajer", topic=None):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self.provider = provider if provider in ("elahmad", "alfajer", "dramalive", "yacine", "syrialive") else "alfajer"
        self.topic = dict(topic or {})
        self.channels = []
        self.playing_index = None
        self.channel_states = {}
        self._loading = False
        self._done = False
        self._result = None
        self._error = ""
        self._closed = False
        self._operation = "load"
        self._selected_index = -1
        self._panel_hidden = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)

        self["title"] = StaticText("")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Play")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("Refresh")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "menu": self.choose_player,
            "cancel": self.back,
            "red": self.back,
            "ok": self.play,
            "green": self.play,
            "blue": self.load,
            "stop": self.stop_stream,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
            "channelUp": self.page_up,
            "channelDown": self.page_down,
        }, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()

    def _update_title(self, suffix=""):
        if self.provider == "elahmad":
            label = u"قنوات عربية مباشرة"
        elif self.provider == "dramalive":
            label = u"عالم الترفيه - Live - %s" % str(self.topic.get("name") or "Channels")
        elif self.provider == "yacine":
            label = u"تلفزيون ياسين - %s" % str(self.topic.get("name") or "Channels")
        elif self.provider == "syrialive":
            label = u"سيريا لايف - البث المباشر"
        else:
            label = "Al Fajer 1 - 5"
        preferred = selected_free_service_type()
        player = "ExtePlayer3 5002" if preferred == 5002 else (
            "GStreamer 5001" if preferred == 5001 else "IPTV 4097")
        self["title"].setText("%s  [%s]%s" % (label, player, suffix))

    def load(self):
        if self._loading:
            return
        self._show_panel()
        self._operation = "load"
        self._loading = True
        self._done = False
        self._result = None
        self._error = ""
        self["list"].setList([_list_entry("Loading current channel list...", -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.provider == "elahmad":
                self._result = fetch_elahmad_catalogue(cfg.useragent.value)
            elif self.provider == "dramalive":
                self._result = fetch_drama_channels(self.topic, cfg.useragent.value)
            elif self.provider == "yacine":
                self._result = fetch_yacine_channels(self.topic, cfg.useragent.value)
            elif self.provider == "syrialive":
                self._result = fetch_syria_live_events(cfg.useragent.value)
            else:
                self._result = fetch_fajer_channels(cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _set_rows(self):
        rows = []
        for index, item in enumerate(self.channels):
            state = self.channel_states.get(index)
            if index == self.playing_index or state == "working":
                marker, color = u"●", COLOR_GREEN
            elif state == "offline":
                marker, color = u"●", COLOR_RED
            else:
                marker, color = "", COLOR_WHITE
            text = "%03d   %s" % (index + 1, item.get("name") or "Channel")
            rows.append(_list_entry(text, index, marker, color))
        if not rows:
            rows = [_list_entry("No channels are currently available.", -1)]
        self["list"].setList(rows)
        if self.playing_index is not None and rows and rows[0][1] >= 0:
            try:
                self["list"].setIndex(self.playing_index)
            except Exception:
                pass

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            if self._operation == "resolve" and self._selected_index >= 0:
                self.channel_states[self._selected_index] = "offline"
            self._set_rows()
            self._update_title("  [failed]")
            self.session.open(MessageBox, "Unable to load the selected free source:\n%s" % self._error,
                              MessageBox.TYPE_ERROR, timeout=8)
            return
        if self._operation == "load":
            self.channels = list(self._result or [])
            if self.provider not in ("dramalive", "syrialive"):
                self.channels = sorted(self.channels, key=_alpha_key)
            self.playing_index = None
            self.channel_states = {}
            self._set_rows()
            self._update_title("  [%d channels]" % len(self.channels))
            return
        self._start_resolved(self._result)

    def _index(self):
        current = self["list"].getCurrent()
        try:
            return int(current[1]) if current else -1
        except Exception:
            return -1

    def play(self):
        if self._panel_hidden:
            self._show_panel()
            return
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.channels):
            return
        if self.playing_index == index:
            self._panel_hidden = True
            self.hide()
            return
        item = self.channels[index]
        self._operation = "resolve"
        self._selected_index = index
        self._loading = True
        self._done = False
        self._result = None
        self._error = ""
        self._update_title("  [resolving stream...]")
        worker = threading.Thread(target=self._resolve_worker, args=(dict(item),))
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _resolve_worker(self, item):
        try:
            if self.provider == "elahmad":
                self._result = resolve_elahmad_channel(item, cfg.useragent.value)
            elif self.provider == "dramalive":
                self._result = resolve_drama_channel(item, cfg.useragent.value)
            elif self.provider == "yacine":
                self._result = resolve_yacine_channel(item, cfg.useragent.value)
            elif self.provider == "syrialive":
                self._result = resolve_syria_live_event(item, cfg.useragent.value)
            else:
                self._result = resolve_fajer_channel(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _start_resolved(self, item):
        if not isinstance(item, dict) or not item.get("url"):
            self.session.open(MessageBox, "No playable link was returned.", MessageBox.TYPE_ERROR, timeout=6)
            return
        index = self._selected_index
        name = str(item.get("name") or "Channel")
        prepared = _prepared_stream_urls(item)
        if not prepared:
            self.session.open(MessageBox, "No playable link was returned.", MessageBox.TYPE_ERROR, timeout=6)
            return
        # Elahmad uses the same two-stage flow as the other IPTV sources:
        # server chooser first, then HLS quality chooser. Even a single server
        # is wrapped as a stream by resolve_elahmad_channel().
        if self.provider == "elahmad" or len(prepared) > 1:
            labels = _prepared_stream_labels(item)
            self.session.openWithCallback(
                self._player_closed, XKlass_StreamChooser,
                prepared, labels, item, name, "Live",
                str(self.topic.get("name") or ""), str(item.get("image") or ""),
                "", True)
            return
        self._open_player(prepared, name, item)

    def _open_player(self, prepared, name, item):
        self.playing_index = self._selected_index
        self._set_rows()
        from .freeplayer import XKlass_FreeTV_Player
        category = "Live"
        self.session.openWithCallback(
            self._player_closed, XKlass_FreeTV_Player, prepared,
            selected_free_service_type(),
            name, category, str(self.topic.get("name") or ""), str(item.get("image") or ""))

    def _player_closed(self, result=None, *args):
        if isinstance(result, (tuple, list)):
            action = result[0] if result else None
            state = result[1] if len(result) > 1 else None
        else:
            action, state = result, None
        if self._selected_index >= 0 and state in ("working", "offline"):
            self.channel_states[self._selected_index] = state
        if action in ("next", "prev") and self.channels:
            direction = 1 if action == "next" else -1
            target = (self._selected_index + direction) % len(self.channels)
            self.playing_index = None
            try:
                self["list"].setIndex(target)
            except Exception:
                pass
            self.play()
            return
        self.playing_index = None if action in ("failed", "stopped") else self._selected_index
        self._set_rows()
        self._update_title("  [%d channels]" % len(self.channels))
        if action == "failed" and not self._closed:
            self.session.open(MessageBox, "This channel is offline or did not start.",
                              MessageBox.TYPE_ERROR, timeout=6)

    def stop_stream(self):
        self._show_panel()
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.playing_index = None
        if self.channels:
            self._set_rows()

    def _show_panel(self):
        if self._panel_hidden:
            try:
                self.show()
            except Exception:
                pass
        self._panel_hidden = False

    def back(self):
        self._show_panel()
        self._safe_close()
