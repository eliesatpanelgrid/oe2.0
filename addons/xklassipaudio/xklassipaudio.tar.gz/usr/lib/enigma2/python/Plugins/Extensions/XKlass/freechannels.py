#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Free Arabic TV catalogues with on-demand provider refresh."""

from __future__ import print_function

import re
import threading

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from enigma import eTimer, getDesktop

from .freeproviders import (
    fetch_drama_channels,
    fetch_drama_episodes,
    fetch_drama_show_topics,
    fetch_drama_shows,
    fetch_drama_topics,
    fetch_elahmad_catalogue,
    fetch_fajer_channels,
    resolve_drama_channel,
    resolve_drama_episode,
    resolve_elahmad_channel,
    resolve_fajer_channel,
    service_stream_url,
)
from .plugin import cfg
from .receivercompat import preferred_foreground_service_type
from .streamproxy import prepare_hls_relay
from .xStaticText import StaticText


COLOR_WHITE = 0x00FFFFFF
COLOR_GREEN = 0x006DFF86
COLOR_RED = 0x00FF6464


def _list_entry(text, value, marker="", marker_color=COLOR_WHITE):
    return (str(text or ""), value, str(marker or ""), int(marker_color))


def _free_channels_skin():
    """Roomier card-style browser dedicated to the free-TV screens."""
    size = getDesktop(0).size()
    width = size.width()
    height = size.height()
    panel_w = int(width * .54)
    if panel_w < 620:
        panel_w = min(width - 20, 620)
    margin = max(12, int(width * .012))
    top_h = 72 if height >= 1080 else 58
    foot_h = 58 if height >= 1080 else 48
    font = 31 if width >= 1920 else 25 if width > 1280 else 23
    title_font = font + 4
    item_h = font + 25
    list_h = height - top_h - foot_h
    row_w = panel_w - margin - 34
    text_w = row_w - 62
    key_w = int((panel_w - (margin * 2)) / 4.0)
    return '''<screen name="XKlassFreeTVList" position="0,0" size="%d,%d" backgroundColor="#ff000000" flags="wfNoBorder">
        <eLabel position="0,0" size="%d,%d" backgroundColor="#e0101b32" zPosition="1" />
        <widget source="title" render="Label" position="%d,7" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#e0101b32" valign="center" noWrap="1" transparent="0" zPosition="2" />
        <widget source="list" render="Listbox" position="%d,%d" size="%d,%d" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" backgroundColor="#e0101b32" backgroundColorSelected="#245a9c" scrollbarMode="showOnDemand" enableWrapAround="1" transparent="0" zPosition="2">
          <convert type="TemplatedMultiContent">{"template":[MultiContentEntryText(pos=(8,4),size=(50,%d),font=0,flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER,text=2,color=3,color_sel=3,backcolor=0x182744,backcolor_sel=0x245a9c),MultiContentEntryText(pos=(58,4),size=(%d,%d),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=0,color=0xFFFFFF,color_sel=0xFFFFFF,backcolor=0x182744,backcolor_sel=0x245a9c)],"fonts":[gFont("Regular",%d)],"itemHeight":%d}</convert>
        </widget>
        <eLabel position="0,%d" size="%d,%d" backgroundColor="#e0081020" zPosition="1" />
        <widget source="key_red" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ff8585" backgroundColor="#e0081020" valign="center" transparent="0" zPosition="2" />
        <widget source="key_green" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#7dff91" backgroundColor="#e0081020" valign="center" transparent="0" zPosition="2" />
        <widget source="key_yellow" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#fff18a" backgroundColor="#e0081020" valign="center" transparent="0" zPosition="2" />
        <widget source="key_blue" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#82bfff" backgroundColor="#e0081020" valign="center" transparent="0" zPosition="2" />
    </screen>''' % (
        width, height, panel_w, height, margin, panel_w - margin * 2, top_h - 12, title_font,
        margin, top_h, panel_w - margin, list_h, item_h - 8, text_w, item_h - 8, font, item_h,
        height - foot_h, panel_w, foot_h,
        margin, height - foot_h + 4, key_w, foot_h - 8, max(17, font - 5),
        margin + key_w, height - foot_h + 4, key_w, foot_h - 8, max(17, font - 5),
        margin + key_w * 2, height - foot_h + 4, key_w, foot_h - 8, max(17, font - 5),
        margin + key_w * 3, height - foot_h + 4, key_w, foot_h - 8, max(17, font - 5))


def _alpha_key(item):
    value = item.get("name", "") if isinstance(item, dict) else item
    try:
        if not isinstance(value, str):
            value = value.decode("utf-8", "replace")
    except Exception:
        pass
    try:
        return value.strip().lower()
    except Exception:
        return str(value).strip().lower()


def _natural_key(item):
    value = _alpha_key(item)
    parts = []
    for part in re.split(r"(\d+)", value):
        parts.append((1, int(part)) if part.isdigit() else (0, part))
    return parts


def _prepared_stream_urls(item):
    streams = item.get("streams") or []
    if not streams:
        streams = [{"url": value, "headers": item.get("headers", {})}
                   for value in list(item.get("urls") or [item.get("url")])]
    prepared = []
    for stream in streams:
        if not isinstance(stream, dict):
            stream = {"url": stream, "headers": item.get("headers", {})}
        url = str(stream.get("url") or "").strip()
        if not url:
            continue
        headers = stream.get("headers") if isinstance(stream.get("headers"), dict) else {}
        swap = stream.get("swap") if isinstance(stream.get("swap"), dict) else {}
        mediatype = str(stream.get("mediatype") or "").strip().lower()
        if swap and url.lower().startswith(("http://", "https://")) and mediatype in ("", "hls"):
            prepared.append(prepare_hls_relay(url, headers, swap))
        else:
            prepared.append(service_stream_url(url, headers))
    return prepared


class _ListNavigationMixin(object):
    def _move_list(self, movement):
        try:
            instance = self["list"].master.master.instance
            instance.moveSelection(getattr(instance, movement))
        except Exception:
            pass

    def go_up(self):
        self._move_list("moveUp")

    def go_down(self):
        self._move_list("moveDown")

    def page_up(self):
        self._move_list("pageUp")

    def page_down(self):
        self._move_list("pageDown")

    def _safe_close(self):
        """Detach asynchronous callbacks before a receiver destroys the screen."""
        # Re-entrancy guard: a fast double "cancel"/back press (or a cancel
        # arriving while the poll timer is also mid-callback) can call this
        # twice for the same screen. The second self.close() then runs on an
        # instance that is already being torn down, which raised an
        # unhandled exception straight out of the ActionMap key callback and
        # took the whole receiver down with it. One flag makes the method
        # idempotent.
        if getattr(self, "_closing", False):
            return
        self._closing = True
        self._closed = True
        timer = getattr(self, "_timer", None)
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
            # Drop the timeout connection too, not just stop() the timer.
            # While stopped it can no longer fire, but leaving the signal
            # wired to self._poll keeps a live native callback pointed at a
            # screen instance that is about to be destroyed.
            timer_conn = getattr(self, "_timer_conn", None)
            if timer_conn is not None:
                try:
                    timer.timeout.disconnect(timer_conn)
                except Exception:
                    pass
                self._timer_conn = None
        try:
            self["actions"].setEnabled(False)
        except Exception:
            pass
        try:
            self.close()
        except Exception:
            # self.close() can itself raise (e.g. the underlying C/C++
            # screen object is already gone) if teardown was already under
            # way. Every other step here is defensively wrapped except this
            # one used to be - letting it raise inside a key-press callback
            # is what turned into the visible "crash".
            pass


class XKlass_FreeTV_Menu(_ListNavigationMixin, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self["title"] = StaticText("Alkuds ipaudio - Free Arabic TV")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["list"] = List([
            _list_entry(u"عالم الترفيه", "entertainment", u"●", COLOR_GREEN),
            _list_entry(u"قنوات عربية مباشرة", "elahmad", u"●", 0x0082BFFF),
            _list_entry("Al Fajer 1 - 5 (dynamic)", "alfajer", u"●", 0x00FFF18A),
        ], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "cancel": self.close,
            "red": self.close,
            "ok": self.open_current,
            "green": self.open_current,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
        }, -2)

    def open_current(self):
        current = self["list"].getCurrent()
        if current and current[1]:
            if current[1] == "entertainment":
                self.session.open(XKlass_Entertainment_Menu)
            else:
                self.session.open(XKlass_FreeTV_Channels, current[1])


class XKlass_Entertainment_Menu(_ListNavigationMixin, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self["title"] = StaticText(u"Alkuds ipaudio - عالم الترفيه")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("")
        self["list"] = List([
            _list_entry("Live", "live", u"●", COLOR_GREEN),
            _list_entry("Series", "series", u"●", 0x0082BFFF),
            _list_entry("Movie", "movie", u"●", 0x00FFF18A),
        ], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "cancel": self.close,
            "red": self.close,
            "ok": self.open_current,
            "green": self.open_current,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
        }, -2)

    def open_current(self):
        current = self["list"].getCurrent()
        if not current:
            return
        if current[1] == "live":
            self.session.open(XKlass_Drama_Topics)
        elif current[1] in ("series", "movie"):
            self.session.open(XKlass_Drama_Catalog, current[1], "topics")


class XKlass_Drama_Topics(_ListNavigationMixin, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self.topics = []
        self._loading = False
        self._done = False
        self._result = None
        self._error = ""
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self["title"] = StaticText(u"عالم الترفيه - Live")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("Refresh")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "cancel": self.back,
            "red": self.back,
            "ok": self.open_current,
            "green": self.open_current,
            "blue": self.load,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
            "channelUp": self.page_up,
            "channelDown": self.page_down,
        }, -2)
        self.onFirstExecBegin.append(self.load)

    def load(self):
        if self._loading:
            return
        self._loading = True
        self._done = False
        self._result = None
        self._error = ""
        self["list"].setList([_list_entry("Loading Live groups...", -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            self._result = fetch_drama_topics(cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self["list"].setList([_list_entry("Live groups are unavailable.", -1, u"●", COLOR_RED)])
            self.session.open(MessageBox, "Unable to load Live groups:\n%s" % self._error,
                              MessageBox.TYPE_ERROR, timeout=8)
            return
        # Preserve the provider's priority/order (especially current matches).
        self.topics = list(self._result or [])
        rows = [_list_entry("%03d   %s" % (index + 1, item.get("name") or "Group"), index)
                for index, item in enumerate(self.topics)]
        self["list"].setList(rows or [_list_entry("No Live groups are available.", -1)])
        self["title"].setText(u"عالم الترفيه - Live  [%d]" % len(self.topics))

    def open_current(self):
        if self._loading:
            return
        current = self["list"].getCurrent()
        try:
            index = int(current[1]) if current else -1
        except Exception:
            index = -1
        if 0 <= index < len(self.topics):
            self.session.open(XKlass_FreeTV_Channels, "dramalive", self.topics[index])

    def back(self):
        self._safe_close()


class XKlass_Drama_Catalog(_ListNavigationMixin, Screen):
    """Series/Movie groups, titles and episodes from the source application."""

    def __init__(self, session, kind="series", level="topics", parent=None):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self.kind = kind if kind in ("series", "movie") else "series"
        self.level = level if level in ("topics", "shows", "episodes") else "topics"
        self.parent = dict(parent or {})
        self.entries = []
        self._loading = False
        self._done = False
        self._result = None
        self._error = ""
        self._closed = False
        self._operation = "load"
        self._selected_index = -1
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self["title"] = StaticText("")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Open" if self.level != "episodes" else "Play")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("Refresh")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "cancel": self.back,
            "red": self.back,
            "ok": self.open_current,
            "green": self.open_current,
            "blue": self.load,
            "stop": self.stop_stream,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
            "channelUp": self.page_up,
            "channelDown": self.page_down,
        }, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()

    def _label(self):
        section = "Series" if self.kind == "series" else "Movie"
        if self.level == "topics":
            return u"عالم الترفيه - %s" % section
        return u"عالم الترفيه - %s - %s" % (section, str(self.parent.get("name") or ""))

    def _update_title(self, suffix=""):
        self["title"].setText("%s%s" % (self._label(), suffix))

    def load(self):
        if self._loading:
            return
        self._operation = "load"
        self._loading = True
        self._done = False
        self._result = None
        self._error = ""
        self["list"].setList([_list_entry("Loading entertainment catalogue...", -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == "topics":
                self._result = fetch_drama_show_topics(self.kind, cfg.useragent.value)
            elif self.level == "shows":
                self._result = fetch_drama_shows(self.parent, cfg.useragent.value)
            else:
                self._result = fetch_drama_episodes(self.parent, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _resolve_worker(self, item):
        try:
            self._result = resolve_drama_episode(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _set_rows(self):
        rows = [_list_entry("%03d   %s" % (index + 1, item.get("name") or "Item"), index)
                for index, item in enumerate(self.entries)]
        self["list"].setList(rows or [_list_entry("No items are currently available.", -1)])
        if 0 <= self._selected_index < len(self.entries):
            try:
                self["list"].setIndex(self._selected_index)
            except Exception:
                pass

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self._set_rows()
            self._update_title("  [failed]")
            self.session.open(MessageBox, "Unable to load entertainment content:\n%s" % self._error,
                              MessageBox.TYPE_ERROR, timeout=8)
            return
        if self._operation == "load":
            sort_key = _natural_key if self.level == "episodes" else _alpha_key
            self.entries = sorted(list(self._result or []), key=sort_key)
            self._set_rows()
            self._update_title("  [%d]" % len(self.entries))
            return
        self._start_resolved(self._result)

    def _index(self):
        current = self["list"].getCurrent()
        try:
            return int(current[1]) if current else -1
        except Exception:
            return -1

    def open_current(self):
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if self.level == "topics":
            self.session.open(XKlass_Drama_Catalog, self.kind, "shows", item)
        elif self.level == "shows":
            self.session.open(XKlass_Drama_Catalog, self.kind, "episodes", item)
        else:
            self._operation = "resolve"
            self._loading = True
            self._done = False
            self._result = None
            self._error = ""
            self._update_title("  [resolving stream...]")
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)

    def _start_resolved(self, item):
        if not isinstance(item, dict) or not item.get("url"):
            self.session.open(MessageBox, "No playable link was returned.",
                              MessageBox.TYPE_ERROR, timeout=6)
            return
        prepared = _prepared_stream_urls(item)
        if not prepared:
            self.session.open(MessageBox, "No playable link was returned.",
                              MessageBox.TYPE_ERROR, timeout=6)
            return
        category = "Series" if self.kind == "series" else "Movie"
        if len(prepared) > 1:
            self._pending_video = (prepared, item, category)
            choices = [(u"سيرفر رقم %d" % (index + 1), index)
                       for index in range(len(prepared))]
            self.session.openWithCallback(
                self._video_choice, ChoiceBox,
                title=u"اختر سيرفر التشغيل", list=choices)
            return
        self._open_video(prepared, item, category)

    def _video_choice(self, choice=None):
        pending = getattr(self, "_pending_video", None)
        self._pending_video = None
        if not pending or not choice:
            return
        prepared, item, category = pending
        try:
            selected = int(choice[1])
        except Exception:
            selected = 0
        if selected < 0 or selected >= len(prepared):
            selected = 0
        self._open_video([prepared[selected]], item, category)

    def _open_video(self, prepared, item, category):
        # VOD deliberately has no close callback.  A few receiver images crash
        # while restoring the parent screen from an openWithCallback teardown.
        from .freeplayer import XKlass_FreeTV_Player
        resume_key = "%s:%s" % (self.kind, str(item.get("id") or item.get("name") or "video"))
        self.session.open(
            XKlass_FreeTV_Player, prepared, preferred_foreground_service_type(),
            str(item.get("name") or "Video"), category,
            str(self.parent.get("name") or ""), str(item.get("image") or ""),
            resume_key)

    def _player_closed(self, result=None, *args):
        self._set_rows()
        self._update_title("  [%d]" % len(self.entries))
        action = result[0] if isinstance(result, (tuple, list)) and result else result
        if action == "failed" and not self._closed:
            self.session.open(MessageBox, "This video is offline or did not start.",
                              MessageBox.TYPE_ERROR, timeout=6)

    def stop_stream(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass

    def back(self):
        self._safe_close()


class XKlass_FreeTV_Channels(_ListNavigationMixin, Screen):
    def __init__(self, session, provider="alfajer", topic=None):
        Screen.__init__(self, session)
        self.skin = _free_channels_skin()
        self.session = session
        self.provider = provider if provider in ("elahmad", "alfajer", "dramalive") else "alfajer"
        self.topic = dict(topic or {})
        self.channels = []
        self.playing_index = None
        self.channel_states = {}
        self._loading = False
        self._done = False
        self._result = None
        self._error = ""
        self._closed = False
        self._operation = "load"
        self._selected_index = -1
        self._panel_hidden = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)

        self["title"] = StaticText("")
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Play")
        self["key_yellow"] = StaticText("")
        self["key_blue"] = StaticText("Refresh")
        self["list"] = List([], enableWrapAround=True)
        self["actions"] = ActionMap(["XKlassActions", "OkCancelActions", "ColorActions"], {
            "cancel": self.back,
            "red": self.back,
            "ok": self.play,
            "green": self.play,
            "blue": self.load,
            "stop": self.stop_stream,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.page_up,
            "right": self.page_down,
            "channelUp": self.page_up,
            "channelDown": self.page_down,
        }, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()

    def _update_title(self, suffix=""):
        if self.provider == "elahmad":
            label = u"قنوات عربية مباشرة"
        elif self.provider == "dramalive":
            label = u"عالم الترفيه - Live - %s" % str(self.topic.get("name") or "Channels")
        else:
            label = "Al Fajer 1 - 5"
        player = "ExtePlayer3 5002" if preferred_foreground_service_type() == 5002 else "IPTV 4097"
        self["title"].setText("%s  [%s]%s" % (label, player, suffix))

    def load(self):
        if self._loading:
            return
        self._show_panel()
        self._operation = "load"
        self._loading = True
        self._done = False
        self._result = None
        self._error = ""
        self["list"].setList([_list_entry("Loading current channel list...", -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.provider == "elahmad":
                self._result = fetch_elahmad_catalogue(cfg.useragent.value)
            elif self.provider == "dramalive":
                self._result = fetch_drama_channels(self.topic, cfg.useragent.value)
            else:
                self._result = fetch_fajer_channels(cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _set_rows(self):
        rows = []
        for index, item in enumerate(self.channels):
            state = self.channel_states.get(index)
            if index == self.playing_index or state == "working":
                marker, color = u"●", COLOR_GREEN
            elif state == "offline":
                marker, color = u"●", COLOR_RED
            else:
                marker, color = "", COLOR_WHITE
            text = "%03d   %s" % (index + 1, item.get("name") or "Channel")
            rows.append(_list_entry(text, index, marker, color))
        if not rows:
            rows = [_list_entry("No channels are currently available.", -1)]
        self["list"].setList(rows)
        if self.playing_index is not None and rows and rows[0][1] >= 0:
            try:
                self["list"].setIndex(self.playing_index)
            except Exception:
                pass

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            if self._operation == "resolve" and self._selected_index >= 0:
                self.channel_states[self._selected_index] = "offline"
            self._set_rows()
            self._update_title("  [failed]")
            self.session.open(MessageBox, "Unable to load the selected free source:\n%s" % self._error,
                              MessageBox.TYPE_ERROR, timeout=8)
            return
        if self._operation == "load":
            self.channels = list(self._result or [])
            if self.provider != "dramalive":
                self.channels = sorted(self.channels, key=_alpha_key)
            self.playing_index = None
            self.channel_states = {}
            self._set_rows()
            self._update_title("  [%d channels]" % len(self.channels))
            return
        self._start_resolved(self._result)

    def _index(self):
        current = self["list"].getCurrent()
        try:
            return int(current[1]) if current else -1
        except Exception:
            return -1

    def play(self):
        if self._panel_hidden:
            self._show_panel()
            return
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.channels):
            return
        if self.playing_index == index:
            self._panel_hidden = True
            self.hide()
            return
        item = self.channels[index]
        self._operation = "resolve"
        self._selected_index = index
        self._loading = True
        self._done = False
        self._result = None
        self._error = ""
        self._update_title("  [resolving stream...]")
        worker = threading.Thread(target=self._resolve_worker, args=(dict(item),))
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _resolve_worker(self, item):
        try:
            if self.provider == "elahmad":
                self._result = resolve_elahmad_channel(item, cfg.useragent.value)
            elif self.provider == "dramalive":
                self._result = resolve_drama_channel(item, cfg.useragent.value)
            else:
                self._result = resolve_fajer_channel(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _start_resolved(self, item):
        if not isinstance(item, dict) or not item.get("url"):
            self.session.open(MessageBox, "No playable link was returned.", MessageBox.TYPE_ERROR, timeout=6)
            return
        index = self._selected_index
        name = str(item.get("name") or "Channel")
        prepared = _prepared_stream_urls(item)
        if not prepared:
            self.session.open(MessageBox, "No playable link was returned.", MessageBox.TYPE_ERROR, timeout=6)
            return
        if self.provider == "dramalive" and len(prepared) > 1:
            choices = [(u"مشغل رقم %d" % (number + 1), number)
                       for number in range(len(prepared))]
            self._pending_player = (prepared, name, item)
            self.session.openWithCallback(
                self._player_choice, ChoiceBox,
                title=u"اختر مشغل المباراة أو الحدث", list=choices)
            return
        self._open_player(prepared, name, item)

    def _player_choice(self, choice=None):
        pending = getattr(self, "_pending_player", None)
        self._pending_player = None
        if not pending or not choice:
            return
        prepared, name, item = pending
        try:
            selected = int(choice[1])
        except Exception:
            selected = 0
        if selected < 0 or selected >= len(prepared):
            selected = 0
        self._open_player([prepared[selected]], name, item)

    def _open_player(self, prepared, name, item):
        self.playing_index = self._selected_index
        self._set_rows()
        from .freeplayer import XKlass_FreeTV_Player
        category = "Live"
        self.session.openWithCallback(
            self._player_closed, XKlass_FreeTV_Player, prepared,
            preferred_foreground_service_type(),
            name, category, str(self.topic.get("name") or ""), str(item.get("image") or ""))

    def _player_closed(self, result=None, *args):
        if isinstance(result, (tuple, list)):
            action = result[0] if result else None
            state = result[1] if len(result) > 1 else None
        else:
            action, state = result, None
        if self._selected_index >= 0 and state in ("working", "offline"):
            self.channel_states[self._selected_index] = state
        if action in ("next", "prev") and self.channels:
            direction = 1 if action == "next" else -1
            target = (self._selected_index + direction) % len(self.channels)
            self.playing_index = None
            try:
                self["list"].setIndex(target)
            except Exception:
                pass
            self.play()
            return
        self.playing_index = None if action in ("failed", "stopped") else self._selected_index
        self._set_rows()
        self._update_title("  [%d channels]" % len(self.channels))
        if action == "failed" and not self._closed:
            self.session.open(MessageBox, "This channel is offline or did not start.",
                              MessageBox.TYPE_ERROR, timeout=6)

    def stop_stream(self):
        self._show_panel()
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.playing_index = None
        if self.channels:
            self._set_rows()

    def _show_panel(self):
        if self._panel_hidden:
            try:
                self.show()
            except Exception:
                pass
        self._panel_hidden = False

    def back(self):
        self._show_panel()
        self._safe_close()
