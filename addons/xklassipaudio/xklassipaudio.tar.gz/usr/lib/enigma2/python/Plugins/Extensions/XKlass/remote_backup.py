#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import print_function

import datetime
import hashlib
import json
import os
import threading
import time

try:
    import requests
except Exception:
    requests = None

CONFIG_FILE = "/etc/enigma2/remote_backup_config.json"
QUEUE_FILE = "/etc/enigma2/remote_backup_pending.json"
SENT_FILE = "/etc/enigma2/remote_backup_sent.json"
_WORKER_LOCK = threading.Lock()
_STATE_LOCK = threading.Lock()

try:
    text_type = unicode
except NameError:
    text_type = str


def _chmod_private(path):
    try:
        os.chmod(path, 384)  # 0600; works on Python 2 and 3
    except Exception:
        pass


def _load_json(path, default):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except Exception:
        return default


def _atomic_write(path, value):
    tmp = path + ".tmp"
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        with open(tmp, "w") as f:
            json.dump(value, f, indent=2)
        _chmod_private(tmp)
        try:
            os.rename(tmp, path)
        except Exception:
            if os.path.exists(path):
                os.remove(path)
            os.rename(tmp, path)
        _chmod_private(path)
        return True
    except Exception:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        return False


def _config():
    data = _load_json(CONFIG_FILE, {})
    return {
        "enabled": bool(data.get("enabled", False)),
        "bot_token": str(data.get("bot_token", "") or "").strip(),
        "chat_id": str(data.get("chat_id", "") or "").strip(),
    }


def _queue():
    value = _load_json(QUEUE_FILE, [])
    return value if isinstance(value, list) else []


def _sent():
    value = _load_json(SENT_FILE, {})
    if isinstance(value, dict):
        items = value.get("sent", [])
    elif isinstance(value, list):
        items = value
    else:
        items = []
    return [str(x) for x in items if x]


def _save_sent(items):
    # Keep this file tiny even after many account edits over time.
    unique = []
    seen = set()
    for item in items:
        item = str(item or "")
        if item and item not in seen:
            seen.add(item)
            unique.append(item)
    if len(unique) > 500:
        unique = unique[-500:]
    return _atomic_write(SENT_FILE, {"version": 1, "sent": unique})


def _as_bytes(value):
    try:
        if isinstance(value, bytes):
            return value
    except Exception:
        pass
    if not isinstance(value, text_type):
        value = text_type(value)
    try:
        return value.encode("utf-8")
    except Exception:
        return str(value)


def _fingerprint(kind, values):
    canonical = text_type(kind).strip().lower() + u"\n" + u"\n".join(
        [text_type(v if v is not None else "").strip() for v in values]
    )
    return hashlib.sha256(_as_bytes(canonical)).hexdigest()


def _already_sent_or_pending(fingerprint):
    if fingerprint in _sent():
        return True
    for item in _queue():
        if str(item.get("fingerprint", "")) == fingerprint:
            return True
    return False


def _append_pending_unique(fingerprint, message):
    # Prevent repeated plugin opens from appending the same subscription again.
    _STATE_LOCK.acquire()
    try:
        if _already_sent_or_pending(fingerprint):
            return False
        items = _queue()
        stamp = "%d-%d" % (int(time.time() * 1000), len(items))
        items.append({"id": stamp, "fingerprint": fingerprint, "text": str(message)})
        return _atomic_write(QUEUE_FILE, items)
    finally:
        try:
            _STATE_LOCK.release()
        except Exception:
            pass


def _send_text(text):
    cfg = _config()
    if not cfg["enabled"] or not cfg["bot_token"] or not cfg["chat_id"] or requests is None:
        return False
    url = "https://api.telegram.org/bot%s/sendMessage" % cfg["bot_token"]
    try:
        r = requests.post(url, data={
            "chat_id": cfg["chat_id"],
            "text": text,
            "disable_web_page_preview": "true",
        }, timeout=10)
        if int(getattr(r, "status_code", 0)) != 200:
            return False
        try:
            payload = r.json()
            return bool(payload.get("ok", False))
        except Exception:
            return True
    except Exception:
        return False


def _mark_sent(fingerprint):
    if not fingerprint:
        return
    _STATE_LOCK.acquire()
    try:
        items = _sent()
        if fingerprint not in items:
            items.append(fingerprint)
            _save_sent(items)
    finally:
        try:
            _STATE_LOCK.release()
        except Exception:
            pass


def _remove_pending(item_id):
    _STATE_LOCK.acquire()
    try:
        items = _queue()
        new_items = []
        removed = False
        for item in items:
            if not removed and str(item.get("id", "")) == str(item_id):
                removed = True
                continue
            new_items.append(item)
        _atomic_write(QUEUE_FILE, new_items)
    finally:
        try:
            _STATE_LOCK.release()
        except Exception:
            pass


def _flush_worker():
    if not _WORKER_LOCK.acquire(False):
        return
    try:
        while True:
            items = _queue()
            if not items:
                return
            current = items[0]
            fingerprint = str(current.get("fingerprint", ""))

            # Migration safety: if this fingerprint was already completed, just drop it.
            if fingerprint and fingerprint in _sent():
                _remove_pending(current.get("id", ""))
                continue

            if not _send_text(str(current.get("text", ""))):
                return
            if fingerprint:
                _mark_sent(fingerprint)
            _remove_pending(current.get("id", ""))
    finally:
        try:
            _WORKER_LOCK.release()
        except Exception:
            pass


def flush_pending_async():
    try:
        t = threading.Thread(target=_flush_worker)
        t.daemon = True
        t.start()
    except Exception:
        pass


def _backup_message(kind, fields):
    lines = [
        "Alkuds ipaudio - Subscription Backup",
        "Type: %s" % str(kind),
        "Connected: %s" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "",
    ]
    for key, value in fields:
        lines.append("%s: %s" % (str(key), str(value if value not in (None, "") else "-")))
    return "\n".join(lines)


def backup_xtream_connected(playlist):
    """Queue one Telegram backup only after Xtream auth succeeded."""
    try:
        info = (playlist or {}).get("playlist_info", {}) or {}
        name = str(info.get("name", "Xtream") or "Xtream")
        host = str(info.get("host", "") or "").rstrip("/")
        username = str(info.get("username", "") or "")
        password = str(info.get("password", "") or "")
        output = str(info.get("output", "ts") or "ts")
        if not host or not username:
            return False
        fingerprint = _fingerprint("xtream", [host.lower(), username, password, output])
        text = _backup_message("XTREME", [
            ("Name", name),
            ("Server", host),
            ("Username", username),
            ("Password", password),
            ("Output", output),
        ])
        queued = _append_pending_unique(fingerprint, text)
        if queued:
            flush_pending_async()
        return queued
    except Exception:
        return False


def backup_stalker_connected(portal):
    """Queue one Telegram backup only after MAC/Stalker handshake + load succeeded."""
    try:
        portal = portal or {}
        name = str(portal.get("name", "Stalker") or "Stalker")
        url = str(portal.get("portal", "") or "").rstrip("/")
        mac = str(portal.get("mac", "") or "").upper()
        entry_point = str(portal.get("entryPoint", "portal.php") or "portal.php")
        if not url or not mac:
            return False
        fingerprint = _fingerprint("stalker", [url.lower(), mac, entry_point.lower()])
        text = _backup_message("MAC / Stalker", [
            ("Name", name),
            ("Portal", url),
            ("MAC", mac),
            ("Entry point", entry_point),
        ])
        queued = _append_pending_unique(fingerprint, text)
        if queued:
            flush_pending_async()
        return queued
    except Exception:
        return False

def backup_audiofeed_connected(kind, name, subscription_url, channel_count=None):
    """Queue one Telegram backup after an audio source connects successfully."""
    try:
        kind = str(kind or "best_audio").strip().lower()
        labels = {
            "best_audio": "BEST AUDIO",
            "sat_family": "SAT FAMILY AUDIO",
            "orange_audio": "ORANGE IPAUDIO",
            "free_audio": "FREE IPAUDIO",
        }
        label = labels.get(kind, "AUDIO PLAYLIST")
        name = str(name or label)
        url = str(subscription_url or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            return False
        # The URL/token identifies the subscription.  Do not resend it on every plugin open.
        fingerprint = _fingerprint("audiofeed:%s" % kind, [url])
        fields = [
            ("Name", name),
            ("URL", url),
        ]
        try:
            count = int(channel_count)
            if count >= 0:
                fields.append(("Channels", count))
        except Exception:
            pass
        text = _backup_message(label, fields)
        queued = _append_pending_unique(fingerprint, text)
        if queued:
            flush_pending_async()
        return queued
    except Exception:
        return False
