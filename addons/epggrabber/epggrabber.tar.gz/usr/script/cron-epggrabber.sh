#!/bin/sh

# 1. تنظيف كاش الذاكرة بالكامل دفعة واحدة لتوفير مساحة للرام
echo 3 > /proc/sys/vm/drop_caches

# 2. إعدادات المسارات وقائمة الملفات المراد تخطيها وعدم تشغيلها
PROVIDERS_DIR="/usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers"

# اضف هنا أسماء الملفات التي تريد تخطيها (افصل بينها بمسافة)
EXCLUDED_PROVIDERS="__init__.py aljazeera.py"

# 3. التحقق الذكي من أمر البايثون المدعوم في الصورة الحالية (Python 3 أو القديم)
if command -v python3 >/dev/null 2>&1; then
    PYTHON_CMD="python3"
else
    PYTHON_CMD="python"
fi

echo "=================================================="
echo "    Starting EPG Grabber Providers Sequentially   "
echo "    Using: $PYTHON_CMD"
echo "=================================================="

# 4. فحص المجلد وتشغيل كل ملف بايثون بالترتيب تلقائياً مع ميزة التخطي
if [ -d "$PROVIDERS_DIR" ]; then
    for provider_script in "$PROVIDERS_DIR"/*.py; do
        # التأكد من وجود ملفات فعلياً داخل المجلد وتجنب الخطأ إذا كان فارغاً
        [ -e "$provider_script" ] || continue
        
        SCRIPT_NAME=$(basename "$provider_script")
        
        # فحص ما إذا كان الملف الحالي موجوداً في قائمة الاستبعاد والتخطى
        MATCH_FOUND=0
        for excluded in $EXCLUDED_PROVIDERS; do
            if [ "$SCRIPT_NAME" = "$excluded" ]; then
                MATCH_FOUND=1
                break
            fi
        done
        
        # إذا تم العثور عليه في قائمة الاستبعاد، يتم تخطيه فوراً والانتقال للتالي
        if [ $MATCH_FOUND -eq 1 ]; then
            echo "[ - ] Skipping Excluded Provider: $SCRIPT_NAME"
            continue
        fi
        
        echo "[*] Executing: $SCRIPT_NAME"
        $PYTHON_CMD "$provider_script"
        
        # تنظيف الكاش صامتاً بعد كل ملف لحماية الأجهزة الضعيفة من الامتلاء أثناء جلب البيانات
        echo 3 > /proc/sys/vm/drop_caches
    done
    
    echo "=================================================="
    echo " 🎉 All EPG Providers Executed Successfully!       "
    echo "=================================================="
else
    echo "[-] Error: Providers directory not found!"
    exit 1
fi

exit 0

