# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function

# Load plugin keymap (needed on some images so OK/ENTER triggers our Actions context)
try:
    from Tools.Directories import resolveFilename, SCOPE_PLUGINS
    from Components.ActionMap import loadKeymap
    loadKeymap(resolveFilename(SCOPE_PLUGINS, 'Extensions/XMLupdatebyiet5/keymap.xml'))
except Exception:
    try:
        from Tools.Directories import resolveFilename, SCOPE_PLUGINS
        from keymapparser import readKeymap
        readKeymap(resolveFilename(SCOPE_PLUGINS, 'Extensions/XMLupdatebyiet5/keymap.xml'))
    except Exception:
        pass

# plugin created by iet5

import os
import time
import shutil
import json
import re
from datetime import datetime
from sys import version_info

from Plugins.Plugin import PluginDescriptor
from Tools.Directories import fileExists

from Components.config import (
    config, ConfigSubsection, ConfigYesNo, ConfigSelection,
    ConfigDirectory, ConfigFloat, ConfigInteger, ConfigText, getConfigListEntry
)

# Restart GUI
try:
    from Screens.Standby import TryQuitMainloop
except Exception:
    TryQuitMainloop = None

# Screens (editor)
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console

# Components (editor)
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.ConfigList import ConfigListScreen
from Components.GUIComponent import GUIComponent
from Components.HTMLComponent import HTMLComponent
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Components.NimManager import nimmanager
from Components.Pixmap import Pixmap

from enigma import (
    eListbox, gFont, eListboxPythonMultiContent,
    RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER,
    RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP,
    eRect, eTimer, getDesktop
)

# Plugin local imports (editor)
from . import _
from .components import (
    FHD_Res, HD_Res, need_update, Transponder,
    TransponderList, Head, SatelliteList
)
from .satxmleditscreen import SatXmlEditScreen
from .sateditscreen import SatEditor
from .addnewsatscreen import AddNewSatScreen
from .transpondereditor import TransponderEditor
from .transponderseditor import TranspondersEditor

PY3 = (version_info[0] == 3)

# ---------------- XML parsing (Python 2/3) ----------------
try:
    import xml.etree.cElementTree as cElementTree
except Exception:
    import xml.etree.ElementTree as cElementTree

# ---------------- Network (Python 2/3) ----------------
try:
    from urllib.request import urlopen, Request
except Exception:
    from urllib2 import urlopen, Request

try:
    from urllib.error import HTTPError, URLError
except Exception:
    try:
        from urllib2 import HTTPError, URLError
    except Exception:
        HTTPError = URLError = Exception

# SSL compatibility (some images ship with old CA bundles)
try:
    import ssl
except Exception:
    ssl = None

# Optional requests (works around SSL/SNI issues on some images)
try:
    import requests
    try:
        import warnings
        warnings.filterwarnings("ignore", message="Unverified HTTPS request")
    except Exception:
        pass
except Exception:
    requests = None

def _patch_ssl_unverified():
    """Best-effort: allow HTTPS downloads on images with broken/old CA bundles."""
    if ssl is None:
        return None
    try:
        return ssl._create_unverified_context()
    except Exception:
        try:
            ssl._create_default_https_context = ssl._create_unverified_context
        except Exception:
            pass
    return None

# Apply SSL unverified patch globally when possible
try:
    _patch_ssl_unverified()
except Exception:
    pass

# ---------------- Paths / Constants ----------------
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
VERSION_FILE = os.path.join(PLUGIN_DIR, "version.txt")
LOG_FILE = "/tmp/XMLupdatebyiet5.log"   # kept for compatibility, but no logging calls remain

URLS = {
    "satellites.xml": "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/refs/heads/master/src/satellites.xml",
    "terrestrial.xml": "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/refs/heads/master/src/terrestrial.xml",
    "cables.xml": "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/refs/heads/master/src/cables.xml",
}

# satellites.xml sources (user selectable)
SATELLITES_SOURCES = {
    "oe_alliance": {
        "label": "OE-Alliance",
        "raw_url": "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/refs/heads/master/src/satellites.xml",
        "api_commits": "https://api.github.com/repos/oe-alliance/oe-alliance-tuxbox-common/commits?path=src/satellites.xml&per_page=1&page=1",
        "commits_page": "https://github.com/oe-alliance/oe-alliance-tuxbox-common/commits/master/src/satellites.xml",
    },
    "openpli": {
        "label": "OpenPLi",
        "raw_url": "https://raw.githubusercontent.com/OpenPLi/tuxbox-xml/master/xml/satellites.xml",
        "api_commits": "https://api.github.com/repos/OpenPLi/tuxbox-xml/commits?path=xml/satellites.xml&per_page=1&page=1",
        "commits_page": "https://github.com/OpenPLi/tuxbox-xml/commits/master/xml/satellites.xml",
    },
}

DEFAULT_PATHS = ["/etc/tuxbox", "/etc/enigma2"]

# --------- Plugin Path ---------
plugin_path = os.path.dirname(os.path.realpath(__file__))

# --------- Version from file ---------
version_file_path = os.path.join(plugin_path, "version.txt")
try:
    with open(version_file_path, "r") as f:
        currversion = f.read().strip() or "Unknown"
except Exception:
    currversion = "Unknown"

# ---------------- Logging (dummy function, kept to avoid errors in other files) ----------------
def log_line(msg):
    pass

def _run_cmd_capture(cmd):
    """Run a shell command and return its combined stdout+stderr as string."""
    try:
        p = os.popen(cmd + " 2>&1")
        output = p.read()
        p.close()
        return output
    except Exception:
        return ""

def _wget_get(url, timeout_sec=20):
    """Best-effort fetch using external wget/curl (works around Python SSL issues on some images)."""
    try:
        url = str(url)
    except Exception:
        pass
    # Use a set of commands with and without a User-Agent, with no-check-certificate
    cmds = [
        'wget -qO- --no-check-certificate --timeout=%d --tries=1 "%s"' % (int(timeout_sec), url),
        'wget -q -O - --no-check-certificate --timeout=%d --tries=1 "%s"' % (int(timeout_sec), url),
        'busybox wget -qO- --no-check-certificate -T %d -t 1 "%s"' % (int(timeout_sec), url),
        'busybox wget -q -O - --no-check-certificate -T %d -t 1 "%s"' % (int(timeout_sec), url),
        'curl -L -k --max-time %d "%s"' % (int(timeout_sec), url),
        # With a common browser User-Agent
        'wget -qO- --no-check-certificate --timeout=%d --tries=1 -U "Mozilla/5.0" "%s"' % (int(timeout_sec), url),
        'curl -L -k --max-time %d -A "Mozilla/5.0" "%s"' % (int(timeout_sec), url),
    ]
    for cmd in cmds:
        try:
            p = os.popen(cmd)
            data = p.read()
            try:
                p.close()
            except Exception:
                pass
            if data and len(data) > 10:  # Ignore empty or very short responses
                return data
        except Exception:
            continue
    return ""

def _jina_proxy(url):
    """Return a r.jina.ai proxy URL for GitHub resources (helps when github.com/api.github.com are blocked)."""
    try:
        u = str(url)
    except Exception:
        u = url
    if not u:
        return ""
    if u.startswith("http://") or u.startswith("https://"):
        return "https://r.jina.ai/%s" % u
    return ""

def _best_get(url, timeout_sec=20):
    """Best-effort fetch for text content.

    Order:
      1) Python urllib (with unverified SSL context when possible)
      2) External wget/curl (multiple variants)
      3) r.jina.ai proxy for GitHub (then again urllib/wget)
    """
    if not url:
        return ""
    # 0) requests (often handles TLS/SNI better on some receivers)
    if requests is not None:
        try:
            r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, verify=False, timeout=float(timeout_sec))
            txt = getattr(r, "text", "") or ""
            if txt:
                return txt
        except Exception:
            pass

    # 1) Python urllib
    try:
        ctx = _patch_ssl_unverified()
        req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
        try:
            if ctx is not None:
                data = urlopen(req, timeout=int(timeout_sec), context=ctx).read()
            else:
                data = urlopen(req, timeout=int(timeout_sec)).read()
        except TypeError:
            data = urlopen(req, timeout=int(timeout_sec)).read()
        if data:
            try:
                if not isinstance(data, str):
                    data = data.decode("utf-8", "ignore")
            except Exception:
                pass
            if len(data) > 10:
                return data
    except Exception:
        pass

    # 2) External tools
    data = _wget_get(url, timeout_sec)
    if data:
        return data

    # 3) Proxy (GitHub only)
    proxy = _jina_proxy(url)
    if proxy and proxy != url:
        # Try urllib on proxy
        try:
            ctx = _patch_ssl_unverified()
            req = Request(proxy, headers={"User-Agent": "Mozilla/5.0"})
            try:
                if ctx is not None:
                    data = urlopen(req, timeout=int(timeout_sec), context=ctx).read()
                else:
                    data = urlopen(req, timeout=int(timeout_sec)).read()
            except TypeError:
                data = urlopen(req, timeout=int(timeout_sec)).read()
            if data:
                try:
                    if not isinstance(data, str):
                        data = data.decode("utf-8", "ignore")
                except Exception:
                    pass
                if len(data) > 10:
                    return data
        except Exception:
            pass

        data = _wget_get(proxy, timeout_sec)
        if data:
            return data

    return ""

# ---------------- Config: XMLupdatebyiet5 ----------------
config.plugins.XMLupdatebyiet5 = ConfigSubsection()
config.plugins.XMLupdatebyiet5.do_sat = ConfigYesNo(default=True)
config.plugins.XMLupdatebyiet5.do_ter = ConfigYesNo(default=True)
config.plugins.XMLupdatebyiet5.do_cab = ConfigYesNo(default=True)
config.plugins.XMLupdatebyiet5.restart_gui_after_update = ConfigYesNo(default=False)

# satellites.xml source (mutually exclusive)
config.plugins.XMLupdatebyiet5.sat_src_oe_alliance = ConfigYesNo(default=True)
config.plugins.XMLupdatebyiet5.sat_src_openpli = ConfigYesNo(default=False)

config.plugins.XMLupdatebyiet5.save_mode = ConfigSelection(
    default="both",
    choices=[
        ("both", "Save to: /etc/tuxbox and /etc/enigma2"),
        ("tuxbox", "Save to: /etc/tuxbox only"),
        ("enigma2", "Save to: /etc/enigma2 only"),
        ("custom", "Save to: custom path"),
    ]
)
config.plugins.XMLupdatebyiet5.custom_path = ConfigDirectory(default="/etc")

# ---------------- Helpers (XMLupdatebyiet5) ----------------
def read_version():
    try:
        if fileExists(VERSION_FILE):
            s = open(VERSION_FILE).read().strip()
            return s if s else "ver.00"
    except Exception:
        pass
    return "ver.00"

def get_selected_files():
    files = []
    if config.plugins.XMLupdatebyiet5.do_sat.value:
        files.append("satellites.xml")
    if config.plugins.XMLupdatebyiet5.do_ter.value:
        files.append("terrestrial.xml")
    if config.plugins.XMLupdatebyiet5.do_cab.value:
        files.append("cables.xml")
    return files

def _bytes_to_text(b):
    if b is None:
        return ""
    if PY3:
        try:
            if isinstance(b, bytes):
                return b.decode("utf-8", "ignore")
        except Exception:
            pass
        try:
            return str(b)
        except Exception:
            return ""
    try:
        if isinstance(b, unicode):
            return b
    except Exception:
        pass
    try:
        if isinstance(b, str):
            return b
    except Exception:
        pass
    try:
        return unicode(b)
    except Exception:
        return ""

def get_satellites_source_key():
    """Return current satellites.xml source key.

    Requirement: only one source can be enabled at a time.
    """
    p = config.plugins.XMLupdatebyiet5
    oe = bool(p.sat_src_oe_alliance.value)
    pl = bool(p.sat_src_openpli.value)
    if oe and pl:
        # prefer OE-Alliance if both are enabled (and fix config)
        try:
            p.sat_src_openpli.value = False
            p.sat_src_openpli.save()
        except Exception:
            pass
        return "oe_alliance"
    if pl:
        return "openpli"
    # default/fallback
    return "oe_alliance"

def set_satellites_source_key(source_key):
    """Set satellites.xml source (mutually exclusive)."""
    p = config.plugins.XMLupdatebyiet5
    if source_key == "openpli":
        p.sat_src_openpli.value = True
        p.sat_src_oe_alliance.value = False
    else:
        p.sat_src_oe_alliance.value = True
        p.sat_src_openpli.value = False
    try:
        p.sat_src_openpli.save()
        p.sat_src_oe_alliance.save()
    except Exception:
        pass

def get_satellites_url():
    key = get_satellites_source_key()
    try:
        return SATELLITES_SOURCES[key]["raw_url"]
    except Exception:
        return URLS["satellites.xml"]

def get_satellites_source_label():
    key = get_satellites_source_key()
    try:
        return SATELLITES_SOURCES[key]["label"]
    except Exception:
        return "OE-Alliance"

_SAT_LAST_UPDATE_CACHE = {}

def get_satellites_last_update(force_refresh=False):
    """Return last update date string for selected satellites.xml source.

    Uses GitHub commits API (single request, small payload).
    """
    key = get_satellites_source_key()
    if (not force_refresh) and key in _SAT_LAST_UPDATE_CACHE:
        return _SAT_LAST_UPDATE_CACHE.get(key, "")

    try:
        api_url = SATELLITES_SOURCES[key]["api_commits"]
    except Exception:
        return ""

    ctx = _patch_ssl_unverified()
    try:
        req = Request(api_url, headers={"User-Agent": "Mozilla/5.0"})
        try:
            if ctx is not None:
                raw = urlopen(req, timeout=10, context=ctx).read()
            else:
                raw = urlopen(req, timeout=10).read()
        except TypeError:
            raw = urlopen(req, timeout=10).read()
        txt = _bytes_to_text(raw)
        data = json.loads(txt) if txt else []
        date_str = ""
        if isinstance(data, list) and data:
            try:
                date_str = data[0].get("commit", {}).get("committer", {}).get("date", "")
            except Exception:
                date_str = ""
        if date_str:
            try:
                date_str = date_str.replace("T", " ").replace("Z", "")
                date_str = date_str[:16]
            except Exception:
                pass
        _SAT_LAST_UPDATE_CACHE[key] = date_str
        return date_str
    except Exception:
        # Fallback: try Last-Modified header from the raw file URL (works even if GitHub API is blocked).
        try:
            raw_url = SATELLITES_SOURCES.get(key, {}).get("raw_url", "")
            if raw_url:
                ctx = _patch_ssl_unverified()
                req = Request(raw_url, headers={"User-Agent": "Mozilla/5.0"})
                try:
                    if ctx is not None:
                        resp = urlopen(req, timeout=10, context=ctx)
                    else:
                        resp = urlopen(req, timeout=10)
                except TypeError:
                    resp = urlopen(req, timeout=10)
                try:
                    try:
                        lm = resp.headers.get("Last-Modified", "")
                    except Exception:
                        lm = ""
                    if not lm:
                        try:
                            lm = resp.info().get("Last-Modified", "")
                        except Exception:
                            lm = ""
                    if lm:
                        _SAT_LAST_UPDATE_CACHE[key] = _bytes_to_text(lm).strip()
                        return _SAT_LAST_UPDATE_CACHE[key]
                finally:
                    try:
                        resp.close()
                    except Exception:
                        pass
        except Exception:
            pass

        _SAT_LAST_UPDATE_CACHE[key] = ""
        return ""

# Cache for commits helper text (key, per_page) -> (timestamp, lines)
_SAT_COMMITS_CACHE = {}

def _parse_github_date(date_str):
    try:
        # Example: 2026-02-17T10:23:11Z
        date_str = date_str.replace("T", " ").replace("Z", "")
        return date_str
    except Exception:
        return date_str or ""

def _human_delta_minutes(dt_utc):
    try:
        now = datetime.utcnow()
        diff = now - dt_utc
        mins = int(diff.total_seconds() // 60)
        if mins < 1:
            return "just now"
        if mins < 60:
            return "%d minutes ago" % mins
        hrs = mins // 60
        if hrs < 24:
            return "%d hours ago" % hrs
        days = hrs // 24
        if days == 1:
            return "1 day ago"
        return "%d days ago" % days
    except Exception:
        return ""

def _fetch_commits_api(src_key, per_page):
    """Return list of dicts from GitHub commits API, or [] on failure."""
    try:
        src = SATELLITES_SOURCES.get(src_key, {})
        api = src.get("api_commits", "")
        if not api:
            return []
        # Adjust per_page
        if "per_page=" in api:
            api = re.sub(r"per_page=\d+", "per_page=%d" % int(per_page), api)
        else:
            sep = "&" if "?" in api else "?"
            api = api + sep + "per_page=%d" % int(per_page)

        data = _best_get(api, 20)
        if not data:
            # Direct wget as fallback with exact command that worked
            direct_cmd = 'wget -qO- --no-check-certificate --timeout=20 --tries=1 "%s"' % api
            data = _run_cmd_capture(direct_cmd)
            if not data:
                return []
        try:
            if not isinstance(data, str):
                data = data.decode("utf-8", "ignore")
        except Exception:
            pass
        try:
            parsed = json.loads(data)
            if isinstance(parsed, list):
                return parsed
            else:
                return []
        except Exception:
            return []
    except Exception:
        return []

def _fetch_commits_html(src_key, per_page):
    """Fallback: scrape commits page HTML for a few items (best effort)."""
    try:
        src = SATELLITES_SOURCES.get(src_key, {})
        page = src.get("commits_page", "")
        if not page:
            return []

        html = _best_get(page, 20)
        if not html:
            return []
        try:
            if not isinstance(html, str):
                html = html.decode("utf-8", "ignore")
        except Exception:
            pass

        items = []
        # Try multiple patterns for commit messages
        msg_matches = re.findall(r'class="Link--primary[^"]*"[^>]*>([^<]{3,200})</a>', html)
        if not msg_matches:
            msg_matches = re.findall(r'data-testid="commit-group-title"[^>]*>\s*<span[^>]*>(.*?)</span>', html, re.S)
        if not msg_matches:
            msg_matches = re.findall(r'<a[^>]*class="[^"]*commit-title[^"]*"[^>]*>([^<]+)</a>', html)

        time_matches = re.findall(r'<relative-time[^>]*datetime="([^"]+)"', html)
        author_matches = re.findall(r'rel="author"[^>]*>([^<]{2,80})</a>', html)

        if time_matches:
            n = min(int(per_page), len(msg_matches), len(time_matches))
        else:
            n = min(int(per_page), len(msg_matches))

        for i in range(n):
            msg = re.sub(r"<[^>]+>", "", msg_matches[i]).strip()
            author = author_matches[i].strip() if i < len(author_matches) else ""
            date_iso = time_matches[i].strip() if i < len(time_matches) else ""
            items.append({"msg": msg, "author": author, "date": date_iso})
        return items
    except Exception:
        return []

def _fetch_last_modified(url, timeout_sec=15):
    """Return Last-Modified header text for a URL if available, else empty string."""
    if not url:
        return ""
    # Try Python urllib HEAD
    try:
        ctx = _patch_ssl_unverified()
        req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
        try:
            req.get_method = lambda: "HEAD"
        except Exception:
            pass
        try:
            if ctx is not None:
                resp = urlopen(req, timeout=int(timeout_sec), context=ctx)
            else:
                resp = urlopen(req, timeout=int(timeout_sec))
        except TypeError:
            resp = urlopen(req, timeout=int(timeout_sec))
        try:
            lm = resp.headers.get("Last-Modified") or resp.headers.get("last-modified") or ""
        except Exception:
            lm = ""
        try:
            resp.close()
        except Exception:
            pass
        if lm:
            return lm.strip()
    except Exception:
        pass

    # External tools: curl/wget/busybox wget (HEAD)
    cmd_list = [
        "curl -sI -L -k --max-time %d '%s'" % (int(timeout_sec), url),
        "wget -q --server-response --spider '%s' 2>&1" % url,
        "wget -qS --spider '%s' 2>&1" % url,
        "busybox wget -q --server-response --spider '%s' 2>&1" % url,
    ]
    for cmd in cmd_list:
        out = _run_cmd_capture(cmd)
        if out:
            m = re.search(r"(?im)^\s*Last-Modified:\s*(.+)$", out)
            if m:
                return m.group(1).strip()
    return ""

def get_satellites_commits_lines(src_key, per_page=3, force_refresh=False):
    """Return up to N lines describing the latest commits for satellites.xml for a given source."""
    try:
        per_page = int(per_page)
    except Exception:
        per_page = 3
    if per_page < 1:
        per_page = 1
    if per_page > 5:
        per_page = 5

    cache_key = (src_key, per_page)
    now_ts = int(time.time())
    if not force_refresh and cache_key in _SAT_COMMITS_CACHE:
        ts, lines = _SAT_COMMITS_CACHE.get(cache_key, (0, []))
        if lines and (now_ts - int(ts)) < 300:
            return lines

    label = SATELLITES_SOURCES.get(src_key, {}).get("label", src_key)

    lines = []
    # Try API first
    commits = _fetch_commits_api(src_key, per_page)
    if commits:
        for c in commits[:per_page]:
            try:
                msg = c.get("commit", {}).get("message", "")
                msg = msg.split("\n")[0].strip()
                author = c.get("commit", {}).get("author", {}).get("name", "") or ""
                date_iso = c.get("commit", {}).get("committer", {}).get("date", "") or c.get("commit", {}).get("author", {}).get("date", "")
                date_txt = _parse_github_date(date_iso)[:16].strip()
                delta = ""
                try:
                    if date_iso:
                        dt = datetime.strptime(date_iso.replace("Z", ""), "%Y-%m-%dT%H:%M:%S")
                        delta = _human_delta_minutes(dt)
                except Exception:
                    pass
                parts = []
                if date_txt:
                    parts.append(date_txt)
                if msg:
                    parts.append(msg)
                if author:
                    parts.append("(%s)" % author)
                if delta:
                    parts.append("- %s" % delta)
                line = " - ".join([parts[0], " ".join(parts[1:])]) if len(parts) > 1 else (parts[0] if parts else "")
                line = re.sub(r"\s+", " ", line).strip()
                if line:
                    lines.append(line)
            except Exception:
                continue

    # Fallback: HTML
    if not lines:
        items = _fetch_commits_html(src_key, per_page)
        for it in items[:per_page]:
            msg = (it.get("msg") or "").strip()
            author = (it.get("author") or "").strip()
            date_iso = (it.get("date") or "").strip()
            date_txt = _parse_github_date(date_iso)[:16].strip()
            parts = []
            if date_txt:
                parts.append(date_txt)
            if msg:
                parts.append(msg)
            if author:
                parts.append("(%s)" % author)
            line = " - ".join([parts[0], " ".join(parts[1:])]) if len(parts) > 1 else (parts[0] if parts else "")
            line = re.sub(r"\s+", " ", line).strip()
            if line:
                lines.append(line)

    # Final fallback: Last-Modified
    if not lines:
        raw_url = SATELLITES_SOURCES.get(src_key, {}).get("raw_url", "")
        lm = _fetch_last_modified(raw_url)
        if lm:
            lines = ["Last-Modified for %s: %s" % (label, lm), "Commits list unavailable on this device"]
        else:
            lines = ["Commits for %s: Unknown (network/API blocked)" % label]

    _SAT_COMMITS_CACHE[cache_key] = (now_ts, lines)
    return lines

def get_target_paths():
    mode = config.plugins.XMLupdatebyiet5.save_mode.value
    if mode == "both":
        return list(DEFAULT_PATHS)
    if mode == "tuxbox":
        return ["/etc/tuxbox"]
    if mode == "enigma2":
        return ["/etc/enigma2"]
    return [config.plugins.XMLupdatebyiet5.custom_path.value]

def download_url(url):
    # Try multiple raw URL formats (some GitHub raw URLs change).
    urls_to_try = [url]
    if "/refs/heads/" in url:
        urls_to_try.append(url.replace("/refs/heads/", "/"))

    ctx = _patch_ssl_unverified()
    last_err = None

    for u in urls_to_try:
        try:
            req = Request(u, headers={"User-Agent": "Mozilla/5.0"})
            try:
                if ctx is not None:
                    return urlopen(req, timeout=25, context=ctx).read()
            except TypeError:
                pass
            return urlopen(req, timeout=25).read()
        except HTTPError as e:
            last_err = e
            try:
                if hasattr(e, "code") and int(e.code) == 404:
                    continue
            except Exception:
                pass
        except URLError as e:
            last_err = e
        except Exception as e:
            last_err = e

    if last_err:
        raise last_err
    raise Exception("Download failed")

def ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def backup_file(path):
    """
    Backup naming:
      satellites.xml.bak-20260205-14:31:46
    """
    if not fileExists(path):
        return True
    stamp = time.strftime("%-Y-%m-%d-%H:%M:%S")
    bak = "%s.bak-%s" % (path, stamp)
    shutil.copy2(path, bak)
    return True

def atomic_write(path, data):
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        try:
            os.fsync(f.fileno())
        except Exception:
            pass
    os.rename(tmp, path)
    return True

def run_download(progress_cb=None, status_cb=None):
    files = get_selected_files()
    targets = get_target_paths()

    if not files:
        return {
            "targets": targets,
            "downloaded_files": 0,
            "ok_copies": 0,
            "fail_copies": 0,
            "all_ok": False
        }

    steps = len(files) * len(targets)
    done = 0

    downloaded_files = 0
    ok_copies = 0
    fail_copies = 0

    for t in targets:
        try:
            ensure_dir(t)
        except Exception as e:
            return {
                "targets": targets,
                "downloaded_files": 0,
                "ok_copies": 0,
                "fail_copies": steps,
                "all_ok": False
            }

    for fname in files:
        if status_cb:
            try:
                status_cb("Downloading %s..." % fname)
            except Exception:
                pass

        try:
            if fname == "satellites.xml":
                data = download_url(get_satellites_url())
            else:
                data = download_url(URLS[fname])
            downloaded_files += 1
        except Exception as e:
            fail_copies += len(targets)
            done += len(targets)
            if progress_cb and steps:
                try:
                    progress_cb(int((done * 100) / steps))
                except Exception:
                    pass
            continue

        for t in targets:
            try:
                if status_cb:
                    try:
                        status_cb("Saving %s to %s..." % (fname, t))
                    except Exception:
                        pass

                path = os.path.join(t, fname)
                backup_file(path)
                atomic_write(path, data)
                ok_copies += 1
            except Exception:
                fail_copies += 1

            done += 1
            if progress_cb and steps:
                try:
                    progress_cb(int((done * 100) / steps))
                except Exception:
                    pass

    all_ok = (fail_copies == 0)

    return {
        "targets": targets,
        "downloaded_files": downloaded_files,
        "ok_copies": ok_copies,
        "fail_copies": fail_copies,
        "all_ok": all_ok
    }

def can_restart_gui():
    return TryQuitMainloop is not None

def do_restart_gui(session):
    if TryQuitMainloop is None:
        return False
    session.open(TryQuitMainloop, 3)
    return True

# ---------------- Enigma2 Entry: XMLupdatebyiet5 ----------------
def main_xmlupdate(session, **kwargs):
    try:
        from .mainscreen import XMLupdateByIet5Screen
        session.openWithCallback(lambda *args, **kwargs: None, XMLupdateByIet5Screen)
    except Exception as e:
        try:
            session.open(MessageBox, "Failed to open main screen.\n%s" % str(e), MessageBox.TYPE_ERROR)
        except Exception:
            pass

def Plugins(**kwargs):
    """Plugin descriptor for XMLupdatebyiet5.

    Note: Only one entry is exposed in the Plugin Menu to avoid duplicate items.
    """
    desc = "Download and update satellites/terrestrial/cables XML files"
    return [
        PluginDescriptor(
            name="XMLupdatebyiet5",
            description=desc,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main_xmlupdate
        )
    ]