# -*- coding: utf-8 -*-
from __future__ import absolute_import

import os
import gettext

PLUGIN_DOMAIN = "XMLupdatebyiet5"
PLUGIN_LOCALE = os.path.join(os.path.dirname(__file__), "locale")


def localeInit():
    gettext.bindtextdomain(PLUGIN_DOMAIN, PLUGIN_LOCALE)


localeInit()
_ = gettext.gettext