from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.InfoBar import MoviePlayer, InfoBar
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Tools.Directories import resolveFilename, fileExists, SCOPE_PLUGINS
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap

from Components.config import (
    config, ConfigSubsection, ConfigText, ConfigYesNo,
    ConfigSelection, ConfigInteger, getConfigListEntry
)
try:
    from Components.ConfigList import ConfigListScreen, ConfigList
except Exception:
    from Screens.ConfigList import ConfigListScreen
    from Components.ConfigList import ConfigList

from Components.Sources.List import List
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest

from enigma import gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, eTimer, eServiceReference, getDesktop, iPlayableService, ePicLoad, eSize, eAVSwitch
from Tools.LoadPixmap import LoadPixmap
from Screens.InfoBarGenerics import InfoBarSubtitleSupport
from Components.ServiceEventTracker import ServiceEventTracker
from Components.Pixmap import Pixmap, MultiPixmap

from twisted.internet import reactor, task, threads
from twisted.web.client import downloadPage

import sys
import json, random, os, time, re, subprocess, shlex, ast
from itertools import cycle, islice
import gzip
import ssl
try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:

    pass
else:

    ssl._create_default_https_context = _create_unverified_https_context

if sys.version_info[0] >= 3:
    import urllib.request as urllib2
    import urllib.parse as urllib
    from io import BytesIO as StringIO
    unicode = str
    basestring = str
else:
    import urllib2
    import urllib
    import StringIO
    StringIO = StringIO.StringIO



try:
    from .torrmgr import torrsrv
except Exception:
    torrsrv = None




# Factory
def get_provider(url):
    url = url.lower()
    if "comet" in url: return CometProvider()
    if "mediafusion" in url: return MediaFusionProvider()
    if "stremthru" in url: return StremThruProvider()
    if "torbox" in url: return TorBoxProvider()
    if "aiostreams" in url: return AIOStreamsProvider()
    if "easynews" in url: return EasyNewsProvider()
    return TorrentioProvider() # Default



from Screens.Console import Console

try:
    from Plugins.Extensions.SubsSupport.subtitlesdvb import SubsSupportDVB
    from Plugins.Extensions.SubsSupport import SubsSupport, SubsSupportStatus, initSubsSettings
    from Plugins.Extensions.SubsSupport.subtitles import E2SubsSeeker, SubsSearch, initSubsSettings, SubsStatusScreen, SubsSearchParamsMenu, SubsMenu
    Subs = True
except ImportError:
    Subs = False
    class SubsSupport(object):
        def __init__(self, *args, **kwargs): pass
    class SubsSupportStatus(object):
        def __init__(self, *args, **kwargs): pass



def log_to_file(msg):
    """Log message to /tmp/stremio.log for debugging"""
    try:
        with open("/tmp/stremio.log", "a") as f:
            f.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))
    except: pass
    print(msg)

if not hasattr(config, "plugins"):
    config.plugins = ConfigSubsection()
if not hasattr(config.plugins, "Stremio"):
    config.plugins.Stremio = ConfigSubsection()

config.plugins.Stremio.torrserver_url    = ConfigText(default="http://127.0.0.1:8090")
config.plugins.Stremio.subtitles_enabled = ConfigYesNo(default=True)
config.plugins.Stremio.subtitle_lang     = ConfigText(default="en")
config.plugins.Stremio.os_api_key        = ConfigText(default="")
config.plugins.Stremio.os_token          = ConfigText(default="")
config.plugins.Stremio.show_cast         = ConfigYesNo(default=True)


config.plugins.Stremio.quality_pref = ConfigSelection(
    default="auto",
    choices=[("auto","Auto (all)"),("2160p","2160p / 4K"),("1080p","1080p"),("720p","720p"),("480p","480p and below")]
)

config.plugins.Stremio.hero_interval_ms = ConfigInteger(default=10000, limits=(2000, 60000))

config.plugins.Stremio.trakt_enabled   = ConfigYesNo(default=False)
config.plugins.Stremio.trakt_client_id = ConfigText(default="")
config.plugins.Stremio.trakt_client_secret = ConfigText(default="")
config.plugins.Stremio.trakt_token     = ConfigText(default="")

config.plugins.Stremio.tmdb_enabled    = ConfigYesNo(default=False)
config.plugins.Stremio.tmdb_api_key    = ConfigText(default="7bff10009e7deed9307ad50c67270b6b")
config.plugins.Stremio.tmdb_language   = ConfigSelection(
    default="en-US",
    choices=[
        ("en-US", "English"),
        ("fr-FR", "French"),
        ("es-ES", "Spanish"),
        ("de-DE", "German"),
        ("it-IT", "Italian"),
        ("pt-BR", "Portuguese (Brazil)"),
        ("ar-SA", "Arabic"),
        ("nl-NL", "Dutch"),
        ("ru-RU", "Russian"),
        ("tr-TR", "Turkish"),
        ("ja-JP", "Japanese"),
        ("ko-KR", "Korean"),
        ("zh-CN", "Chinese (Simplified)"),
        ("fa-IR", "Persian"),
    ]
)

config.plugins.Stremio.startup_category = ConfigSelection(
    default="Movies",
    choices=[
        ("Movies", "Movies"),
        ("Series", "Series"),
        ("Trending", "Trending"),
        ("TMDB Movies [New]", "TMDB Movies [New]"),
        ("TMDB Movies [Top Rated]", "TMDB Movies [Top Rated]"),
        ("TVDB Series [New]", "TVDB Series [New]"),
        ("TVDB Series [Top Rated]", "TVDB Series [Top Rated]"),
        ("My Trakt", "My Trakt"),
        ("My Stremio Library", "My Stremio Library"),
    ]
)


config.plugins.Stremio.debrid_provider = ConfigSelection(
    default="none", choices=[("none","None"),("realdebrid","Real-Debrid"),("alldebrid","AllDebrid")]
)
config.plugins.Stremio.debrid_token    = ConfigText(default="")

config.plugins.Stremio.ytdlp_enabled   = ConfigYesNo(default=True)

config.plugins.Stremio.email    = ConfigText(default="")
config.plugins.Stremio.password = ConfigText(default="")
config.plugins.Stremio.auth_key = ConfigText(default="")
config.plugins.Stremio.user_id  = ConfigText(default="")

config.plugins.Stremio.lastPosition = ConfigText(default="[]")
config.plugins.Stremio.onMovieStop = ConfigSelection(default="ask", choices=[("ask", "Ask user"), ("quit", "Return to list")])
config.plugins.Stremio.onMovieEof = ConfigSelection(default="ask", choices=[("ask", "Ask user"), ("quit", "Return to list")])

LOADED_CONFIG_PATH = "None"

ADDON_BASE_URL = "https://torrentio.strem.fun"
ADDON_PARAMS_DEFAULT = "ranked=1&qualityfilter=2160p,1080p,720p,480p"

ADDON_PRESETS = [
    ("https://torrentio.strem.fun", "Torrentio"),
    ("https://mediafusion.elfhosted.com/D-KbFjcL7shV3nF5URsgpERXNhL_XBJ6EGht2NKLbvhYMLLTuwVx8FHavz5BasCyB08p-V9MJANcKlNPclL-8LtdZBPO8CMGPa3J6LlhUpzYz40qfgeazG45o_GTAbMd_7Z8PTgAr9BO7FBlz8XO6k9R4eEMZJ8MicI6vu4uC4aEFFCTbiKArUDobe7TPVYyT5-z6RDm-w80PG-RopSD5-fpJToKkfSdRsUmQQFDrsOHejjaFrcJJzhgc-Tv3rPSJiho4M2PZlwASLofIx5qDBQQ", "MediaFusion"),
    ("https://comet.stremio.ru", "Comet"),
    ("https://stremthru.13377001.xyz/stremio/torz/eyJpbmRleGVycyI6bnVsbCwic3RvcmVzIjpbeyJjIjoidGIiLCJ0IjoiMzhhZWVjYTEtNjNhMC00ODExLWEwMmMtYWZkYjNjOTRjNjVjIn1dLCJjYWNoZWQiOnRydWV9", "StremThru"),
    ("https://stremio.torbox.app/38aeeca1-63a0-4811-a02c-afdb3c94c65c", "TorBox"),
    ("https://aiostreamsfortheweebsstable.midnightignite.me/stremio/9c8a8e08-9269-4beb-b1d4-789a7594dc53/eyJpIjoiLzYwOG5rZ1pweWhPSnJSZ28wcFkrdz09IiwiZSI6ImFCdTBGN3BnM0IydUhnNUR3UlB6alE9PSIsInQiOiJhIn0", "AIOStreams"),
    ("https://easynews.io", "EasyNews"),
]

config.plugins.Stremio.addon_base_url = ConfigSelection(default="https://torrentio.strem.fun", choices=ADDON_PRESETS)

THEME_PRESETS = [
    ("#4000FFD0", "Classic Cyan"),
    ("#3b444b", "Stremio Dark"),
    ("#FF0055", "Candy Red"),
    ("#FF9900", "Candy Orange"),
    ("#9900FF", "Candy Purple"),
    ("#00FF99", "Candy Green"),
    ("#FF00FF", "Candy Magenta"),
    ("#000080", "Blue Navy"),
]
config.plugins.Stremio.theme_color = ConfigSelection(default="#18121E", choices=THEME_PRESETS)

config.plugins.Stremio.play_mode = ConfigSelection(default="torrserver", choices=[
    ("torrserver", "TorrServer"),
    ("debrid", "Debrid"),
])

CATEGORIES = {
    "Movies": [
        "https://v3-cinemeta.strem.io/catalog/movie/top.json",
        "https://v3-cinemeta.strem.io/catalog/movie/popular.json",
        "https://v3-cinemeta.strem.io/catalog/movie/trending.json",
    ],
    "Series": [
        "https://v3-cinemeta.strem.io/catalog/series/top.json",
        "https://v3-cinemeta.strem.io/catalog/series/popular.json",
        "https://v3-cinemeta.strem.io/catalog/series/trending.json",
    ],
    "Trending": [
        "https://v3-cinemeta.strem.io/catalog/movie/trending.json",
    ],
}


VIDEO_ASPECT_RATIO_MAP = {
    0: "4:3 Letterbox",
    1: "4:3 PanScan",
    2: "16:9",
    3: "16:9 Always",
    4: "16:10 Letterbox",
    5: "16:10 PanScan",
    6: "16:9 Letterbox"
}

vodstreamtypelist = ["4097"]
if os.path.exists("/usr/bin/gstplayer"):
    vodstreamtypelist.append("5001")
if os.path.exists("/usr/bin/exteplayer3"):
    vodstreamtypelist.append("5002")

def save_last_position(list=[]):
    config.plugins.Stremio.lastPosition.value = str(list)
    config.plugins.Stremio.lastPosition.save()

def load_settings_from_json():
    global LOADED_CONFIG_PATH
    json_paths = [
        "/etc/enigma2/stremio.json",
        os.path.join(os.path.dirname(__file__), "stremio.json")
    ]
    json_path = None
    for p in json_paths:
        if os.path.exists(p):
            json_path = p
            break

    if not json_path:
        LOADED_CONFIG_PATH = "No file found"
        log_to_file("load_settings_from_json: No config file found in paths: %s" % json_paths)
        return

    try:
        log_to_file("load_settings_from_json: Loading settings from %s" % json_path)
        with open(json_path, "r") as f:
            data = json.load(f)

        LOADED_CONFIG_PATH = json_path
        mapping = {
            "torrserver_url": config.plugins.Stremio.torrserver_url,
            "trakt_client_id": config.plugins.Stremio.trakt_client_id,
            "trakt_client_secret": config.plugins.Stremio.trakt_client_secret,
            "trakt_token": config.plugins.Stremio.trakt_token,
            "debrid_provider": config.plugins.Stremio.debrid_provider,
            "debrid_token": config.plugins.Stremio.debrid_token,
            "addon_base_url": config.plugins.Stremio.addon_base_url,
            "os_api_key": config.plugins.Stremio.os_api_key,
            "os_token": config.plugins.Stremio.os_token,
            "subtitles_enabled": config.plugins.Stremio.subtitles_enabled,
            "subtitle_lang": config.plugins.Stremio.subtitle_lang,
            "quality_pref": config.plugins.Stremio.quality_pref,
            "tmdb_api_key": config.plugins.Stremio.tmdb_api_key,
            "tmdb_language": config.plugins.Stremio.tmdb_language,
            "startup_category": config.plugins.Stremio.startup_category,
            "stremio_email": config.plugins.Stremio.email,
            "stremio_password": config.plugins.Stremio.password,
            "stremio_auth_key": config.plugins.Stremio.auth_key,
            "stremio_user_id": config.plugins.Stremio.user_id,
        }

        updated = False
        for key, cfg in mapping.items():
            if key in data:
                val = data[key]
                if str(val).upper().startswith("YOUR_"):
                    log_to_file("Skipping placeholder config: %s" % key)
                    continue

                if key in ["stremio_auth_key", "stremio_user_id"] and not val:
                    log_to_file("Skipping empty %s from JSON (keeping existing)" % key)
                    continue

                log_to_file("Loading config: %s = %s" % (key, val))

                if isinstance(cfg, ConfigYesNo):
                    cfg.value = bool(val)
                elif isinstance(cfg, ConfigSelection):
                    str_val = str(val)
                    valid_choices = []
                    for c in cfg.choices:
                        if isinstance(c, tuple) or isinstance(c, list):
                            valid_choices.append(str(c[0]))
                        else:
                            valid_choices.append(str(c))

                    if str_val in valid_choices:
                        cfg.value = str_val
                    else:
                        log_to_file("Invalid value for %s: %s. Valid: %s" % (key, val, valid_choices))
                        found = False
                        for c in valid_choices:
                            if c.lower() == str_val.lower():
                                cfg.value = c
                                found = True
                                break
                        if not found:
                            continue
                else:
                    cfg.value = str(val)
                cfg.save()
                updated = True

        if updated:
            log_to_file("Settings loaded and saved to enigma2 config")
            from Components.config import configfile
            configfile.save()

    except Exception as e:
        log_to_file("Error loading settings: %s" % e)
        print("[Stremio] Error loading settings:", e)
load_settings_from_json()

def _extend_virtual_categories():
    try:
        if config.plugins.Stremio.tmdb_enabled.value:
            CATEGORIES["TMDB Movies [New]"] = ["tmdb:movie:now_playing"]
            CATEGORIES["TMDB Movies [Top Rated]"] = ["tmdb:movie:top_rated"]
            CATEGORIES["TVDB Series [New]"] = ["tmdb:tv:on_the_air"]
            CATEGORIES["TVDB Series [Top Rated]"] = ["tmdb:tv:top_rated"]
        if config.plugins.Stremio.trakt_enabled.value:
            CATEGORIES["My Trakt"] = ["trakt:watchlist:movies","trakt:watchlist:shows"]
            CATEGORIES["Trakt Movies"] = ["trakt:movies:trending", "trakt:movies:popular"]
            CATEGORIES["Trakt Series"] = ["trakt:shows:trending", "trakt:shows:popular"]

        auth = config.plugins.Stremio.auth_key.value
        log_to_file("_extend_virtual_categories: auth_key=%s" % auth)
        if auth:
            CATEGORIES["My Stremio Library"] = ["stremio:library:all"]
            log_to_file("Added My Library to CATEGORIES")
    except Exception as e:
        log_to_file("_extend_virtual_categories error: %s" % e)
_extend_virtual_categories()

def stremio_login(email, password):
    url = "https://api.strem.io/api/login"
    data = {"email": email, "password": password}
    log_to_file("stremio_login: Attempting login for %s" % email)
    try:
        resp = http_post(url, data=data)
        log_to_file("stremio_login: Response: %s" % str(resp))

        if resp and resp.get("result"):
            res = resp["result"]
            auth_key = res.get("authKey")
            user = res.get("user", {})
            uid = user.get("_id")
            if auth_key and uid:
                config.plugins.Stremio.auth_key.value = str(auth_key)
                config.plugins.Stremio.user_id.value = str(uid)
                config.plugins.Stremio.auth_key.save()
                config.plugins.Stremio.user_id.save()
                return True, "Logged in as %s" % email
        elif resp and resp.get("error"):
             err_msg = resp.get("error", {}).get("message", "Unknown error")
             log_to_file("stremio_login: API Error: %s" % err_msg)
             return False, "Login failed: %s" % err_msg
    except Exception as e:
        log_to_file("stremio_login: Exception: %s" % e)
        return False, "Login error: %s" % str(e)
    return False, "Login failed (unknown)"

def fetch_stremio_library(kind="movie", page_size=48):
    auth_key = config.plugins.Stremio.auth_key.value
    log_to_file("[fetch_stremio_library] call kind=%s auth_key_len=%d" % (kind, len(str(auth_key))))
    if not auth_key:
        log_to_file("[fetch_stremio_library] No auth key")
        return []



    # Use standard datastoreGet to get all library items
    url = "https://api.strem.io/api/datastoreGet"
    headers = {"AuthKey": auth_key}
    # authKey is often required in the payload for datastoreGet
    payload = {"collection": "libraryItem", "all": True, "authKey": auth_key}

    log_to_file("[fetch_stremio_library] URL: %s Payload: %s" % (url, payload))

    j = http_post(url, data=payload, headers=headers)
    if not j:
        log_to_file("[fetch_stremio_library] JSON invalid or None")
        return []

    # Expecting a list of items
    all_items = []
    if isinstance(j, list):
        all_items = j
    elif isinstance(j, dict) and "result" in j:
        all_items = j["result"]
    else:
        log_to_file("[fetch_stremio_library] Unexpected structure: %s" % str(j)[:200])
        return []

    # Sort by mtime (modification time) descending to show recently added/watched first
    try:
        all_items.sort(key=lambda x: x.get("mtime", ""), reverse=True)
    except: pass

    log_to_file("[fetch_stremio_library] Got %d items, filtering for %s" % (len(all_items), kind))

    out = []
    for it in all_items:
        if it.get("removed"): continue

        # Extract meta
        # Items might have metadata at top level or in "meta" or "tempMeta"
        meta = it.get("meta") or it.get("tempMeta") or it

        # Check type
        # "series" in Stremio vs likely "series" in enigma config.
        # API usually returns "movie" or "series".
        m_type = meta.get("type") or it.get("type")

        log_to_file("[fetch_stremio_library] Item: %s | Type: %s | Expected: %s" % (meta.get("name"), m_type, kind))

        if kind != "all" and m_type != kind: continue

        title = meta.get("name") or it.get("name") or "No Title"
        poster = meta.get("poster") or it.get("poster") or ""
        backdrop = meta.get("background") or it.get("background") or poster
        year = str(meta.get("year") or it.get("year") or "")

        imdb = meta.get("imdb_id") or it.get("imdb_id") or ""
        if not imdb:
             # Try to find imdb in _id if it looks like tt12345
             mid = it.get("_id","")
             if mid.startswith("tt"): imdb = mid

        desc = meta.get("description") or it.get("description") or ""

        out.append((title, poster, year, desc, backdrop, imdb, kind))

        if len(out) >= page_size: break

    log_to_file("[fetch_stremio_library] Returning %d items" % len(out))
    return out

def _u8(s):
    """
    Convert to UTF-8 for Enigma2 components.
    Python 2: unicode -> bytes (UTF-8 encoded)
    Python 3: str -> str (already Unicode, no encoding needed)
    """
    if sys.version_info[0] >= 3:

        if isinstance(s, bytes):
            return s.decode("utf-8", "ignore")
        return str(s) if s is not None else ""
    else:

        try:
            if isinstance(s, unicode):
                return s.encode("utf-8", "ignore")
        except:
            pass
        return s

def _connect_timer(timer, callback):
    """
    Connect eTimer callback for both OpenATV and DreamOS.
    OpenATV (Python 2): uses timer.callback.append(callback)
    DreamOS (Python 3): uses timer.timeout.connect(callback)
    """
    try:
        timer.timeout.connect(callback)
    except AttributeError:
        timer.callback.append(callback)

def http_get(url, headers=None, timeout=12):
    try:
        req = urllib2.Request(url)
        req.add_header("User-Agent", "Mozilla/5.0 (Dreambox; Enigma2) AppleWebKit/537.36 (KHTML, like Gecko)")
        req.add_header("Accept", "application/json,text/plain;q=0.9,*/*;q=0.8")
        req.add_header("Accept-Language", "en-US,en;q=0.8")
        req.add_header("Cache-Control", "no-cache")
        req.add_header("Pragma", "no-cache")
        if headers:
            for k, v in headers.items(): req.add_header(k, v)
        return urllib2.urlopen(req, timeout=timeout).read()
    except Exception as e:
        log_to_file("[Stremio] HTTP GET error: %s URL: %s" % (e, url))
        return None

def http_json(url, headers=None, timeout=14):
    base = {
        "User-Agent": "Stremio/4.x (Dreambox; Enigma2)",
        "Accept": "application/json,text/plain;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.8",
        "Origin": "https://web.stremio.com",
        "Referer": "https://web.stremio.com/",
        "Connection": "close",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    }
    if headers:
        base.update(headers)
    try:
        req = urllib2.Request(url)
        for k, v in base.items(): req.add_header(k, v)
        resp = urllib2.urlopen(req, timeout=timeout)
        data = resp.read()
        if resp.info().get("Content-Encoding", "") == "gzip":
            data = gzip.GzipFile(fileobj=StringIO(data)).read()
        return json.loads(data)
    except Exception as e:
        log_to_file("[Stremio] http_json error: %s URL: %s" % (e, url))
        return None

def http_post(url, data=None, headers=None, timeout=14):
    base = {
        "User-Agent": "Stremio/4.x (Dreambox; Enigma2)",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    if headers:
        base.update(headers)
    try:
        if data is not None and not isinstance(data, str):
            data = json.dumps(data)
        if data and isinstance(data, unicode):
            data = data.encode("utf-8")

        log_to_file("[Stremio] http_post: %s data len: %d" % (url, len(data) if data else 0))
        req = urllib2.Request(url, data)
        for k, v in base.items(): req.add_header(k, v)
        resp = urllib2.urlopen(req, timeout=timeout)
        return json.loads(resp.read())
    except urllib2.HTTPError as e:
        err_content = e.read()
        log_to_file("[Stremio] http_post HTTPError: %s Content: %s" % (e, err_content))
        try: return json.loads(err_content)
        except: return None
    except Exception as e:
        log_to_file("[Stremio] http_post error: %s URL: %s" % (e, url))
        return None

def normalize_img_url(u):
    if not u: return []
    cands = [u]
    try:
        if ".webp" in u: cands.append(u.replace(".webp", ".jpg"))
        if "format=" not in u:
            sep = "&" if "?" in u else "?"
            cands.append(u + sep + "format=jpg")
        if "/webp/" in u: cands.append(u.replace("/webp/", "/jpg/"))
    except: pass
    out, seen = [], set()
    for x in cands:
        if x and x not in seen:
            out.append(x); seen.add(x)
    return out

def cache_image_safe(url, fallback_url=None):
    candidates = []
    for u in (url, fallback_url): candidates.extend(normalize_img_url(u) if u else [])
    if not candidates: return None

    cache_dir = "/media/hdd/transmission/poster/stremio_thumbs/"
    if not os.path.exists(cache_dir):
        try:
            os.makedirs(cache_dir)
        except:
            pass

    for u in candidates:
        try:
            h_url = abs(hash(u))
            for check_ext in (".jpg", ".png"):
                check_local = "%sst_%d%s" % (cache_dir, h_url, check_ext)
                if os.path.exists(check_local) and os.path.getsize(check_local) > 0:
                    return check_local

            req = urllib2.Request(u)
            req.add_header("Accept", "image/jpeg,image/png;q=0.9,image/*;q=0.6,*/*;q=0.5")
            req.add_header("User-Agent", "Mozilla/5.0 (Dreambox; Enigma2)")
            resp = urllib2.urlopen(req, timeout=12)
            data = resp.read()
            ctype = resp.info().get("Content-Type","").lower()
            if (len(data) >= 4 and data[:4] == "RIFF") or "webp" in ctype or "avif" in ctype:
                continue
            ext = ".jpg" if ("jpeg" in ctype or "jpg" in ctype) else ".png"
            local = "%sst_%d%s" % (cache_dir, h_url, ext)
            if not os.path.exists(local):
                import uuid
                tmp_local = local + ".tmp." + str(uuid.uuid4())
                with open(tmp_local, "wb") as f:
                    f.write(data)
                os.rename(tmp_local, local)
            return local
        except Exception as e:
            print("[Stremio] cache_image_safe err:", e, u)
            continue
    return None

def process_backdrop_with_gradient(raw_image_path, is_backdrop=False):
    """
    Process backdrop images with gradient overlay for OpenATV GPU compatibility.
    OpenATV can't render gradients on images, so we composite them together using PIL.
    Similar to TransmissionMovieBrowserGrid.download_and_process_backdrop

    Args:
        raw_image_path: Path to the downloaded raw image
        is_backdrop: If True, apply gradient/mask compositing for backdrop images

    Returns:
        Path to processed image with gradient overlay, or original path if processing fails
    """
    if not is_backdrop or not raw_image_path or not os.path.exists(raw_image_path):
        return raw_image_path

    try:
        from PIL import Image
        try:
            from PIL.Image import LANCZOS
        except ImportError:
            from PIL.Image import Resampling
            LANCZOS = Resampling.LANCZOS

        processed_path = raw_image_path.replace(".jpg", "_gradient.jpg").replace(".png", "_gradient.jpg")
        if os.path.exists(processed_path):
            return processed_path

        plugin_dir = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')

        gradient_path = os.path.join(plugin_dir, "backdrop.png")
        mask_path = os.path.join(plugin_dir, "mask.png")

        if not os.path.exists(gradient_path) or not os.path.exists(mask_path):
            return raw_image_path

        background = Image.open(gradient_path).convert('RGBA')
        cover = Image.open(raw_image_path).convert('RGBA')
        mask = Image.open(mask_path).convert('RGBA')
        w, h = background.size

        cover = cover.resize((w, h), LANCZOS)
        mask = mask.resize((w, h), LANCZOS)

        background.paste(cover, (0, 0), mask)
        background = background.convert('RGB')
        background.save(processed_path, quality=90)

        return processed_path

    except Exception as e:
        print("[Stremio] Backdrop gradient processing error:", e)
        return raw_image_path

def magnet_from_infohash(infohash, name="", file_idx=None):
    xt = "urn:btih:%s" % infohash
    params = []
    if name: params.append(("dn", name))
    if file_idx is not None: params.append(("ix", str(file_idx)))
    params.append(("tr", "udp://tracker.opentrackr.org:1337/announce"))
    params.append(("tr", "udp://tracker.openbittorrent.com:6969/announce"))
    qs = urllib.urlencode(params)
    return "magnet:?xt=%s%s%s" % (xt, "&" if qs else "", qs)

def get_addon_base():
    try:
        base = config.plugins.Stremio.addon_base.value.strip()
        if base: return base.rstrip("/")
    except: pass
    return "https://torrentio.strem.fun"

def get_available_space(path):
    import os
    try:
        if not os.path.exists(path): return 0
        stat = os.statvfs(path)
        return stat.f_bsize * stat.f_bavail
    except Exception as e:
        log_to_file('Error getting available space: %s' % e)
        return 0

def get_total_space(path):
    import os
    try:
        stat = os.statvfs(path)
        return stat.f_bsize * stat.f_blocks
    except Exception as e:
        log_to_file('Error getting total space: %s' % e)
        return 0

def initiateDownload(session, torrent_link, file_size, title):
    import os
    # Assuming config.plugins.torreplayer is where transmission plugin keeps config
    # We might need to check if Transmission plugin is installed and use its config
    # Fallback or strict dependency? User code imports Plugins.Extensions.Transmission.torrmgr

    try:
        from Plugins.Extensions.Transmission.torrmgr import config as tconfig
        download_path = "%s/transmission" % tconfig.plugins.torreplayer.poster_path.value
    except:
        # Fallback if transmission config not found
        download_path = "/media/hdd/transmission"

    available_space = get_available_space(download_path)
    if available_space >= int(float(file_size)):
        download_limit = '1000000'
        upload_limit = '100'
        rpc_url = 'http://127.0.0.1:9091/transmission/rpc'

        # Ensure quote escaping for shell
        command = 'transmission-remote %s -a "%s" -w "%s" -d %s -u %s' % (
            rpc_url, torrent_link, download_path, download_limit, upload_limit
        )

        title_text = "Downloading: %s" % title[:30]
        session.open(Console, title_text, [command])
    else:
        free_space = available_space // 1073741824
        total_space = get_total_space(download_path) // 1073741824
        message = "Insufficient space on the download path.\nAvailable: %dGB / Total: %dGB" % (free_space, total_space)
        session.open(MessageBox, message, MessageBox.TYPE_ERROR)

def _tmdb_img(path, kind="poster"):
    if not path: return ""
    size = "w500" if kind=="poster" else "w780"
    return "https://image.tmdb.org/t/p/%s%s" % (size, path)

def fetch_tmdb_list(kind, which, page=1, page_size=48):
    api = config.plugins.Stremio.tmdb_api_key.value
    if not api: return []

    lang = config.plugins.Stremio.tmdb_language.value
    base = "https://api.themoviedb.org/3"

    if which == "trending":
        url = "%s/trending/%s/day?api_key=%s&page=%d&language=%s" % (base, kind, api, page, lang)
    else:
        url = "%s/%s/%s?api_key=%s&page=%d&language=%s" % (base, kind, which, api, page, lang)

    j = http_json(url)
    if not j: return []
    results = j.get("results", [])[:page_size]
    out = []

    for it in results:
        title = it.get("title") or it.get("name") or "No Title"
        year = ""
        date = it.get("release_date") or it.get("first_air_date") or ""
        if date: year = date.split("-")[0]


        poster_path = it.get("poster_path")
        backdrop_path = it.get("backdrop_path")
        overview = it.get("overview") or ""
        tmdb_id = it.get("id")

        if (not poster_path or not backdrop_path or not overview) and lang != "en-US":
            try:
                fallback_url = "%s/%s/%s?api_key=%s&language=en-US" % (base, kind, tmdb_id, api)
                fallback = http_json(fallback_url)
                if fallback:
                    if not poster_path:
                        poster_path = fallback.get("poster_path")
                    if not backdrop_path:
                        backdrop_path = fallback.get("backdrop_path")
                    if not overview:
                        overview = fallback.get("overview") or ""
            except:
                pass

        poster = _tmdb_img(poster_path, "poster")
        backdrop = _tmdb_img(backdrop_path, "backdrop")

        imdb = ""
        try:
            ext = http_json("%s/%s/%s/external_ids?api_key=%s" % (base, kind, tmdb_id, api))
            imdb = (ext or {}).get("imdb_id") or ""
        except: pass

        typ = "series" if kind == "tv" else "movie"
        rating = str(it.get("vote_average", ""))
        out.append((title, poster, year, overview, backdrop, imdb, typ, "", rating))
    return out

def fetch_tmdb_trailer(imdb_id, kind="movie"):
    api = config.plugins.Stremio.tmdb_api_key.value
    if not (api and imdb_id): return None

    base = "https://api.themoviedb.org/3"

    # 1. Find TMDB ID from IMDB ID
    find_url = "%s/find/%s?api_key=%s&external_source=imdb_id" % (base, imdb_id, api)
    j = http_json(find_url)
    if not j: return None

    tmdb_id = None
    results = j.get("movie_results" if kind=="movie" else "tv_results", [])
    if results:
        tmdb_id = results[0].get("id")

    if not tmdb_id: return None

    # 2. Get Videos
    vid_url = "%s/%s/%s/videos?api_key=%s" % (base, "movie" if kind=="movie" else "tv", tmdb_id, api)
    vj = http_json(vid_url)
    if not vj: return None

    for vid in vj.get("results", []):
        if vid.get("site") == "YouTube" and vid.get("type") == "Trailer":
            return "https://www.youtube.com/watch?v=%s" % vid.get("key")

    # Fallback to Teaser if no Trailer
    for vid in vj.get("results", []):
        if vid.get("site") == "YouTube":
            return "https://www.youtube.com/watch?v=%s" % vid.get("key")

    return None

def fetch_tmdb_cast(imdb_id, kind="movie"):
    """Fetch cast and director for IMDB ID"""
    api = config.plugins.Stremio.tmdb_api_key.value
    if not (api and imdb_id): return None

    base = "https://api.themoviedb.org/3"

    # 1. Find TMDB ID from IMDB ID
    tmdb_id = None
    if kind == "movie":
         # Maybe we can use /movie/{imdb_id} directly? Not always reliably supported for all endpoints.
         # safer to use find.
         pass

    find_url = "%s/find/%s?api_key=%s&external_source=imdb_id" % (base, imdb_id, api)
    j = http_json(find_url)
    if not j: return None

    results = j.get("movie_results" if kind=="movie" else "tv_results", [])
    if results:
        tmdb_id = results[0].get("id")

    if not tmdb_id: return None

    # 2. Get Credits
    cred_url = "%s/%s/%s/credits?api_key=%s" % (base, "movie" if kind=="movie" else "tv", tmdb_id, api)
    cj = http_json(cred_url)
    if not cj: return None

    # Process Cast
    actors = []
    for c in cj.get("cast", [])[:5]: # Top 5
        profile = c.get("profile_path")
        pic_url = "https://image.tmdb.org/t/p/w185%s" % profile if profile else None
        actors.append({"name": c.get("name"), "pic": pic_url})

    # Process Crew (Director)
    director = None
    for c in cj.get("crew", []):
        if c.get("job") == "Director":
            director = c.get("name")
            break

    return {"actors": actors, "director": director}

def _trakt_headers():
    return {
        "trakt-api-version": "2",
        "Content-Type": "application/json",
        "trakt-api-key": config.plugins.Stremio.trakt_client_id.value or "",
        "Authorization": "Bearer %s" % (config.plugins.Stremio.trakt_token.value or "")
    }

def fetch_trakt_watchlist(kind="movies", page_size=48):
    enabled = config.plugins.Stremio.trakt_enabled.value
    cid = config.plugins.Stremio.trakt_client_id.value
    tok = config.plugins.Stremio.trakt_token.value
    log_to_file("[fetch_trakt_watchlist] enabled=%s cid_len=%d tok_len=%d" % (enabled, len(str(cid)), len(str(tok))))

    if not (enabled and cid and tok):
        return []

    h = _trakt_headers()
    url = "https://api.trakt.tv/sync/watchlist/%s" % kind
    log_to_file("[fetch_trakt_watchlist] URL: %s" % url)

    j = http_json(url, headers=h)
    if not j:
        log_to_file("[fetch_trakt_watchlist] API returned None/empty")

        return []

    items = j[:page_size]
    log_to_file("[fetch_trakt_watchlist] Got %d items" % len(items))
    out = []
    for it in items:
        media = it.get("movie") if kind=="movies" else it.get("show")
        if not media: continue
        title = media.get("title") or "No Title"
        year = str(media.get("year") or "")
        ids = media.get("ids") or {}
        imdb = ids.get("imdb") or ""
        typ = "movie" if kind=="movies" else "series"
        poster = backdrop = desc = ""
        if imdb:
            cm = http_json("https://v3-cinemeta.strem.io/meta/%s/%s.json" % (typ, imdb))
            if cm and cm.get("meta"):
                m = cm["meta"]
                poster = m.get("poster") or m.get("posterShape") or ""
                backdrop = m.get("background", poster) or m.get("backdrop", poster)
                desc = m.get("description","") or m.get("overview","")
        out.append((title, poster, year, desc, backdrop, imdb, typ))
    return out

def fetch_trakt_list(kind="movies", which="trending", page_size=48):
    enabled = config.plugins.Stremio.trakt_enabled.value
    cid = config.plugins.Stremio.trakt_client_id.value
    log_to_file("[fetch_trakt_list] kind=%s which=%s enabled=%s cid_len=%d" % (kind, which, enabled, len(str(cid))))

    if not (enabled and cid):
        return []

    h = _trakt_headers()
    url = "https://api.trakt.tv/%s/%s?limit=%d" % (kind, which, page_size)
    log_to_file("[fetch_trakt_list] URL: %s" % url)

    j = http_json(url, headers=h)
    if not j:
        log_to_file("[fetch_trakt_list] API returned None")

        return []

    log_to_file("[fetch_trakt_list] Got %d items" % len(j))
    out = []
    for it in j:
        media = it.get("movie") or it.get("show") if which == "trending" else it
        if not media: continue
        title = media.get("title") or "No Title"
        year = str(media.get("year") or "")
        ids = media.get("ids") or {}
        imdb = ids.get("imdb") or ""
        typ = "movie" if kind=="movies" else "series"
        poster = backdrop = desc = ""
        if imdb:
            cm = http_json("https://v3-cinemeta.strem.io/meta/%s/%s.json" % (typ, imdb))
            if cm and cm.get("meta"):
                m = cm["meta"]
                poster = m.get("poster") or m.get("posterShape") or ""
                backdrop = m.get("background", poster) or m.get("backdrop", poster)
                desc = m.get("description","") or m.get("overview","")
        out.append((title, poster, year, desc, backdrop, imdb, typ))
    return out

class DebridResolver(object):
    def __init__(self):
        self.provider = (config.plugins.Stremio.debrid_provider.value or "none").lower()
        self.token = (config.plugins.Stremio.debrid_token.value or "").strip()
    def enabled(self):
        return self.provider != "none" and bool(self.token)
    def rd_add_magnet(self, magnet):
        try:
            req = urllib2.Request("https://api.real-debrid.com/rest/1.0/torrents/addMagnet",
                                  data=urllib.urlencode({"magnet": magnet}))
            req.add_header("Authorization", "Bearer %s" % self.token)
            data = urllib2.urlopen(req, timeout=20).read()
            j = json.loads(data) if data else {}
            return j.get("id")
        except Exception as e:
            print("[Stremio] RD addMagnet err:", e); return None
    def rd_select_all(self, tid):
        try:
            req = urllib2.Request("https://api.real-debrid.com/rest/1.0/torrents/selectFiles/%s" % tid,
                                  data=urllib.urlencode({"files":"all"}))
            req.add_header("Authorization", "Bearer %s" % self.token)
            urllib2.urlopen(req, timeout=20).read()
        except Exception as e:
            print("[Stremio] RD select err:", e)
    def rd_info(self, tid):
        try:
            req = urllib2.Request("https://api.real-debrid.com/rest/1.0/torrents/info/%s" % tid)
            req.add_header("Authorization", "Bearer %s" % self.token)
            data = urllib2.urlopen(req, timeout=20).read()
            return json.loads(data) if data else {}
        except Exception as e:
            print("[Stremio] RD info err:", e); return {}
    def rd_unrestrict(self, link):
        try:
            req = urllib2.Request("https://api.real-debrid.com/rest/1.0/unrestrict/link",
                                  data=urllib.urlencode({"link": link}))
            req.add_header("Authorization", "Bearer %s" % self.token)
            data = urllib2.urlopen(req, timeout=20).read()
            j = json.loads(data) if data else {}
            return j.get("download")
        except Exception as e:
            print("[Stremio] RD unrestrict err:", e); return None
        return out

    def ad_add_magnet(self, magnet):
        try:
            url = "https://api.alldebrid.com/v4/magnet/upload?agent=stremio&apikey=%s&magnets[]=%s" % (self.token, urllib.quote(magnet))
            data = urllib2.urlopen(url, timeout=20).read()
            j = json.loads(data)
            if j.get("status") == "success":
                return j["data"]["magnets"][0]["id"]
            return None
        except Exception as e:
            print("[Stremio] AD addMagnet err:", e); return None

    def ad_status(self, tid):
        try:
            url = "https://api.alldebrid.com/v4/magnet/status?agent=stremio&apikey=%s&id=%s" % (self.token, tid)
            data = urllib2.urlopen(url, timeout=20).read()
            j = json.loads(data)
            if j.get("status") == "success":
                return j["data"]["magnets"]
            return {}
        except Exception as e:
            print("[Stremio] AD status err:", e); return {}

    def ad_unlock(self, link):
        try:
            url = "https://api.alldebrid.com/v4/link/unlock?agent=stremio&apikey=%s&link=%s" % (self.token, urllib.quote(link))
            data = urllib2.urlopen(url, timeout=20).read()
            j = json.loads(data)
            if j.get("status") == "success":
                return j["data"]["link"]
            return None
        except Exception as e:
            print("[Stremio] AD unlock err:", e); return None

    def add_and_list(self, magnet):
        if self.provider == "realdebrid":
            tid = self.rd_add_magnet(magnet)
            if not tid: return []
            self.rd_select_all(tid)
            info = self.rd_info(tid) or {}
            files = info.get("files", []) or []
            links = info.get("links", []) or []
            out = []
            url = links[0] if links else None
            for f in files:
                name = (f.get("path") or "").split("/")[-1]
                size = int(f.get("bytes", 0) or 0)
                link = url
                if link:
                    dl = self.rd_unrestrict(link) or link
                    out.append((name, size, dl))
            return out

        elif self.provider == "alldebrid":
            tid = self.ad_add_magnet(magnet)
            if not tid: return []
            info = self.ad_status(tid)
            if not info: return []

            links = info.get("links") or []
            out = []
            for l in links:
                name = l.get("filename") or "video"
                size = int(l.get("size") or 0)
                raw_link = l.get("link")
                if raw_link:
                    dl = self.ad_unlock(raw_link) or raw_link
            out.append((name, size, dl))
            return out

        return []

class StremioMenu(Screen):
    def __init__(self, session, categories):
        self._setSkin()
        Screen.__init__(self, session)
        l = []
        l.append((_u8("Search by title (IMDB/Cinemeta)"), "search_imdb"))
        l.append((_u8("Search & play via Debrid"), "search_debrid"))
        l.append((_u8("Settings"), "settings"))
        for c in categories:
            l.append((_u8(c), "category"))

        self.options = l

        self["menu"] = List(l)
        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.ok,
            "cancel": self.close,
        }, -1)

    def _setSkin(self):
        color = config.plugins.Stremio.theme_color.value
        if getDesktop(0).size().width() >= 1900:
            self.skin = """
            <screen name="StremioMenu" position="center,center" size="600,550" title="Select Provider">
                <eLabel backgroundGradient="#00000000,%s,vertical" position="0,0" size="600,800" zPosition="0" />
                <widget source="menu" position="10,30" size="580,500" render="Listbox" scrollbarMode="showOnDemand" transparent="1" zPosition="2" >
                    <convert type="TemplatedMultiContent">
                        {"templates":
                            {"default": (50, [
                                MultiContentEntryText(pos=(5, 0), size=(550, 50), font=0, flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER, text=0),
                            ])
                            },
                            "fonts": [gFont("Regular", 26)],
                            "itemHeight": 50
                        }
                    </convert>
                </widget>
            </screen>
            """ % color
        else:
            self.skin = """
            <screen name="StremioMenu" position="center,center" size="600,550" title="Choice Menu">
                <eLabel backgroundGradient="#00000000,%s,vertical" position="0,0" size="600,800" zPosition="0" />
                <widget source="menu" position="5,30" size="590,500" render="Listbox" scrollbarMode="showOnDemand" transparent="1" zPosition="2" >
                    <convert type="TemplatedMultiContent">
                        {"templates":
                            {"default": (50, [
                                MultiContentEntryText(pos=(10, 0), size=(540, 50), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                            ])
                            },
                            "fonts": [gFont("Regular", 26)],
                            "itemHeight": 50
                        }
                    </convert>
                </widget>
            </screen>
            """ % color

    def ok(self):
        sel = self["menu"].getCurrent()
        if sel:
            self.close(sel)
        else:
            self.close(None)

class StremioMain(Screen):
    def _setSkin(self):
        color = config.plugins.Stremio.theme_color.value
        if color == "#4000FFD0":
            color2 = "#FFFFFF"
        else:
            color2 = "#00FFAA"
        if getDesktop(0).size().width() >= 1900:
            self.skin = """<screen name="StremioMain" position="center,center" size="1920,1080" title="Stremio by Ostende">
            <eLabel backgroundGradient="#00000000,%s,horizontal" position="center,center" size="1920,1080" zPosition="1" />
            <eLabel backgroundGradient="#CC000000,#00000000,vertical" position="center,center" size="1920,1080" zPosition="0" />
            <widget name="hero" position="80,60" size="1760,440" zPosition="5" scale="1" />
            <widget name="title" position="110,16" size="1700,70" font="Regular;64" foregroundColor="#FFFFFF" transparent="1" zPosition="6"/>
            <eLabel backgroundGradient="#00000000,%s,horizontal" position="80,522" size="1760,46" zPosition="2" />
            <eLabel backgroundGradient="%s,#00000000,horizontal" position="75,517" size="1770,56" zPosition="1" />
            <widget name="category" position="104,522" size="1712,46" valign="center" halign="center" font="Regular;40" foregroundColor="%s" transparent="1" zPosition="3"/>

            <!-- Carousel Widgets -->
            <!-- Far Far Left -->
            <widget name="poster_0" position="160,680" size="150,245" zPosition="2" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Far Left -->
            <widget name="poster_1" position="330,650" size="180,290" zPosition="3" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Left -->
            <widget name="poster_2" position="550,620" size="240,360" zPosition="4" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Center (Selected) -->
            <widget name="poster_3" position="810,580" size="300,450" zPosition="5" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Right -->
            <widget name="poster_4" position="1130,620" size="240,360" zPosition="4" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Far Right -->
            <widget name="poster_5" position="1410,650" size="180,290" zPosition="3" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Far Far Right -->
            <widget name="poster_6" position="1610,680" size="150,245" zPosition="2" alphatest="blend" scale="1" cornerRadius="20" />

            <!-- Selection Info -->
            <eLabel cornerRadius="30" backgroundColor="#0000FF" position="1795,1020" size="115,55" zPosition="1" />
            <eLabel cornerRadius="30" backgroundColor="#00000000" position="1800,1025" size="105,45" zPosition="2" />
            <eLabel position="1805,1025" size="100,45" text="Page +" valign="center" halign="center" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="3" />

            <eLabel cornerRadius="30" backgroundColor="#FFFF00" position="10,1020" size="115,55" zPosition="1" />
            <eLabel cornerRadius="30" backgroundColor="#00000000" position="15,1025" size="105,45" zPosition="2" />
            <eLabel position="20,1025" size="100,45" text="Page -" valign="center" halign="center" font="Regular;20" foregroundColor="#FFFF00" transparent="1" zPosition="3" />

            <widget name="sel_title" position="80,1040" size="1760,40" font="Regular;32" halign="center" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
            </screen>""" % (color, color, color, color2)
        else:
            self.skin = """<screen name="StremioMain" position="center,center" size="1280,720" title="Stremio by Ostende">
            <widget name="hero" position="60,30" size="1160,260" zPosition="5" scale="1" />
            <eLabel backgroundGradient="#00000000,%s,horizontal" position="center,center" size="1280,720" zPosition="1" />
            <eLabel backgroundGradient="#CC000000,#00000000,vertical" position="center,center" size="1280,720" zPosition="0" />
            <widget name="title" position="80,18" size="1120,50" font="Regular;40" foregroundColor="#FFFFFF" transparent="1" zPosition="6" />
            <eLabel backgroundGradient="#00000000,%s,horizontal" position="65,313" size="1160,30" zPosition="6" />
            <eLabel backgroundGradient="%s,#00000000,horizontal" position="60,308" size="1170,40" zPosition="5" />

            <widget name="category" position="76,313" size="1128,30" valign="center" halign="center"  font="Regular;22" foregroundColor="%s" transparent="1" zPosition="7"/>

            <!-- Carousel Widgets (720p) -->
            <!-- Far Far Left -->
            <widget name="poster_0" position="130,460" size="90,135" zPosition="2" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Far Left -->
            <widget name="poster_1" position="230,440" size="120,180" zPosition="3" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Left -->
            <widget name="poster_2" position="360,410" size="160,240" zPosition="4" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Center (Selected) -->
            <widget name="poster_3" position="540,380" size="200,300" zPosition="5" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Right -->
            <widget name="poster_4" position="760,410" size="160,240" zPosition="4" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Far Right -->
            <widget name="poster_5" position="930,440" size="120,180" zPosition="3" alphatest="blend" scale="1" cornerRadius="20" />
            <!-- Far Far Right -->
            <widget name="poster_6" position="1060,460" size="90,135" zPosition="2" alphatest="blend" scale="1" cornerRadius="20" />

            <eLabel cornerRadius="20" backgroundColor="#0000FF" position="1135,673" size="115,35" zPosition="1" />
            <eLabel cornerRadius="20" backgroundColor="#00000000" position="1140,675" size="105,30" zPosition="2" />
            <eLabel position="1145,675" size="100,30" text="Page +" valign="center" halign="center" font="Regular;18" foregroundColor="#FFFFFF" transparent="1" zPosition="3" />

            <eLabel cornerRadius="20" backgroundColor="#FFFF00" position="10,673" size="115,35" zPosition="1" />
            <eLabel cornerRadius="20" backgroundColor="#00000000" position="15,675" size="105,30" zPosition="2" />
            <eLabel position="10,675" size="100,30" text="Page -" valign="center" halign="center" font="Regular;18" foregroundColor="#FFFF00" transparent="1" zPosition="3" />

            <widget name="sel_title" position="60,690" size="1160,30" font="Regular;24" halign="center" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
            </screen>""" % (color, color, color, color2)

    def __init__(self, session):
        self._setSkin()
        Screen.__init__(self, session)

        log_to_file("StremioMain initialized. Loaded config: %s" % LOADED_CONFIG_PATH)

        if not config.plugins.Stremio.auth_key.value:
            email = config.plugins.Stremio.email.value
            pwd = config.plugins.Stremio.password.value
            if email and pwd:
                log_to_file("Attempting auto-login for %s" % email)
                success, msg = stremio_login(email, pwd)
                if success:
                    log_to_file("Auto-login success")
                    try:
                        for k in ["My Stremio Library"]:
                            if k in CATEGORIES: del CATEGORIES[k]
                        _extend_virtual_categories()
                    except: pass
                else:
                    log_to_file("Auto-login failed: %s" % msg)

        self.page = 0
        self.page_size = 48  # grid-friendly

        self["actions"] = ActionMap([
            "OkCancelActions", "ChannelSelectBaseActions", "ChannelSelectActions", "ColorActions", "MenuActions", "DirectionActions"
        ], {
            "cancel": self.close,
            "ok": self.openDetails,
            "blue": self.nextPage,
            "yellow": self.prevPage,
            "menu": self.openMenu,
            "left": self.moveLeft,
            "right": self.moveRight,
            "up": self.moveUp,
            "down": self.moveDown,
        }, -1)

        self["title"] = Label(_u8("Stremio by Ostende"))
        self["category"] = Label(_u8("Movies"))
        self["hero"] = Pixmap()


        for i in range(7):
            self["poster_%d" % i] = Pixmap()
        self["sel_title"] = Label("")

        self.categories = list(CATEGORIES.keys())
        startup_cat = config.plugins.Stremio.startup_category.value
        if startup_cat and startup_cat in self.categories:
            self.cat_index = self.categories.index(startup_cat)
        else:
            self.cat_index = 0
        self.selection_index = 0

        self.metas = []           # list of tuples (title, poster, year, desc, backdrop, imdb, typ [, trailer])
        self._queue = []          # enumerate(self.metas)
        self._pump = None
        self.row_to_item = []     # row index -> metas index

        self.heroTimer = eTimer()
        _connect_timer(self.heroTimer, self.updateHero)

        self._hero_pool = []
        self._hero_idx = -1

        self._in_search_results = False
        self._search_mode = None  # 'imdb' or 'debrid'
        self._search_query = ""

        self.onLayoutFinish.append(self.loadItems)
        self.onClose.append(self._cleanup)

    def _active_catalog_and_skip(self, base_urls):
        ci = self.page % len(base_urls)
        turns = self.page // len(base_urls)
        skip = turns * self.page_size
        return base_urls[ci], skip, ci, turns

    def _add_params(self, url, params):
        qs = []
        for k, v in params.items():
            qs.append("%s=%s" % (k, urllib.quote(str(v))))
        return url + ("&" if "?" in url else "?") + "&".join(qs)

    def _cleanup(self):
        try:
            if self._pump: self._pump.stop()
        except: pass
        try:
            self.heroTimer.stop()
        except: pass

    def fetchItems(self, url_or_urls):

        url = url_or_urls[0] if isinstance(url_or_urls, list) else url_or_urls
        data = http_get(url, headers={"Accept": "application/json"})
        if not data:
            return []
        try:
            j = json.loads(data)
            metas = j.get("metas") or j.get("metasDetailed") or []
            out = []
            for item in metas:
                title = item.get("name") or item.get("title") or "No Title"
                poster = item.get("poster") or item.get("posterShape") or ""
                year = str(item.get("year", "")) if item.get("year") else ""
                desc = item.get("description", "") or item.get("overview", "")
                backdrop = item.get("background", poster) or item.get("backdrop", poster)
                imdb = item.get("id", "") or item.get("imdb_id", "")
                typ = (item.get("type") or "movie").lower()
                trailer = item.get("trailer") or ""
                rating = str(item.get("imdbRating") or item.get("rating") or "")
                out.append((title, poster, year, desc, backdrop, imdb, typ, trailer, rating))
            return out
        except Exception as e:
            print("[Stremio] JSON parse error:", e, url)
            return []

    def _search_tmdb(self, query, limit=50):
        api = config.plugins.Stremio.tmdb_api_key.value
        if not api: return []

        q = urllib.quote(query.strip())
        lang = config.plugins.Stremio.tmdb_language.value
        base = "https://api.themoviedb.org/3"
        out = []
        seen = set()


        for kind in ["movie", "tv"]:
            try:
                url = "%s/search/%s?api_key=%s&query=%s&language=%s" % (base, kind, api, q, lang)
                j = http_json(url)
                results = (j.get("results") or [])[:limit]

                for it in results:
                    tmdb_id = it.get("id")
                    if not tmdb_id: continue


                    imdb = ""
                    try:
                        ext = http_json("%s/%s/%s/external_ids?api_key=%s" % (base, kind, tmdb_id, api))
                        imdb = (ext or {}).get("imdb_id") or ""
                    except: pass

                    if not imdb or imdb in seen: continue
                    seen.add(imdb)

                    title = it.get("title") or it.get("name") or "No Title"
                    poster_path = it.get("poster_path")
                    backdrop_path = it.get("backdrop_path")
                    desc = it.get("overview") or ""

                    if (not poster_path or not backdrop_path or not desc) and lang != "en-US":
                        try:
                            fallback_url = "%s/%s/%s?api_key=%s&language=en-US" % (base, kind, tmdb_id, api)
                            fallback = http_json(fallback_url)
                            if fallback:
                                if not poster_path:
                                    poster_path = fallback.get("poster_path")
                                if not backdrop_path:
                                    backdrop_path = fallback.get("backdrop_path")
                                if not desc:
                                    desc = fallback.get("overview") or ""
                        except:
                            pass

                    poster = _tmdb_img(poster_path, "poster")
                    backdrop = _tmdb_img(backdrop_path, "backdrop")

                    date = it.get("release_date") or it.get("first_air_date") or ""
                    year = date.split("-")[0] if date else ""
                    typ = "series" if kind == "tv" else "movie"
                    rating = str(it.get("vote_average", ""))


                    trailer = ""

                    out.append((title, poster, year, desc, backdrop, imdb, typ, trailer, rating))
                    if len(out) >= limit: break
            except Exception as e:
                print("[Stremio] TMDB search err:", e)

            if len(out) >= limit: break

        return out

    def buildRow(self, title, pm):
        return (title, "", "", "", "", "", "", "", "", pm)

    def _pumpQueue(self):
        if not self._queue:
            if self._pump:
                try: self._pump.stop()
                except: pass
                self._pump = None
            return

        item_idx, meta = self._queue.pop(0)
        t, u, y, d, b, imdb, tp = meta[:7]

        def _prepare():
            local = cache_image_safe(u, fallback_url=b)
            if not local: return None
            pm = LoadPixmap(cached=True, path=local)
            if not pm: return None
            return self.buildRow(_u8(t), pm), item_idx

        def _add(res):
            if not res: return
            row, original_index = res
            pass

        threads.deferToThread(_prepare).addCallback(lambda r: reactor.callFromThread(_add, r))

    def _loadItems_from_list(self, cat_label, items):
        self["category"].setText(_u8("%s — Page %d" % (cat_label, self.page + 1)))
        self.metas = items or []
        self._queue = list(enumerate(self.metas))
        self.row_to_item = []
        if self._pump:
            try: self._pump.stop()
            except: pass
            self._pump = None
        if self.metas:
            self._pump = task.LoopingCall(self._pumpQueue)
            self._pump.start(0.05, now=True)
            self._hero_pool, self._hero_idx = [], -1
            self.updateHero()
            try:
                interval = int(config.plugins.Stremio.hero_interval_ms.value)
            except:
                interval = 10000
            self.heroTimer.start(max(1500, interval), True)
            self.selection_index = 0
            self.updateCarousel()
        else:
            self["title"].setText(_u8("No items for this page."))

    def loadItems(self):
        self._in_search_results = False
        cat = self.categories[self.cat_index]
        base_urls = CATEGORIES[cat]

        url0, skip, ci, turns = self._active_catalog_and_skip(base_urls)
        try:
            sub = url0.split("/catalog/")[1].split("/")[1].split(".")[0]
        except:
            sub = "list"

        if url0.startswith("tmdb:"):
            _, kind, which = url0.split(":")
            items = fetch_tmdb_list(kind, which, page=self.page+1, page_size=self.page_size)
            return self._loadItems_from_list("%s — %s" % (cat, which.replace("_", " ").title()), items)

        if url0.startswith("trakt:"):
            parts = url0.split(":")
            if len(parts) == 3:
                _, what, kind = parts
                if what == "watchlist":
                    items = fetch_trakt_watchlist("movies" if kind=="movies" else "shows", page_size=self.page_size)
                    return self._loadItems_from_list("%s — %s" % (cat, "Watchlist"), items)
                else:
                    items = fetch_trakt_list(what, kind, page_size=self.page_size)
                    return self._loadItems_from_list("%s — %s" % (cat, kind.title()), items)

        if url0.startswith("stremio:"):
            _, what, kind = url0.split(":")
            if what == "library":
                items = fetch_stremio_library(kind, page_size=self.page_size)
                return self._loadItems_from_list("%s — %s" % (cat, "Library"), items)

        self["category"].setText(_u8("%s — %s — Page %d" % (cat, sub.title(), self.page + 1)))

        self.metas, self._queue, self.row_to_item = [], [], []
        if self._pump:
            try: self._pump.stop()
            except: pass
            self._pump = None

        final_url = self._add_params(url0, {"limit": self.page_size, "skip": skip, "cb": int(time.time()) % 100000})

        def _fetch():
            return self.fetchItems(final_url)

        def _got(items):
            self.metas = items or []
            self._queue = list(enumerate(self.metas))
            if self.metas:
                self._pump = task.LoopingCall(self._pumpQueue)
                self._pump.start(0.05, now=True)
                self._hero_pool, self._hero_idx = [], -1
                self.updateHero()
                try:
                    interval = int(config.plugins.Stremio.hero_interval_ms.value)
                except:
                    interval = 10000
                self.heroTimer.start(max(1500, interval), True)
                self.selection_index = 0
                self.updateCarousel()
            else:
                self["title"].setText(_u8("No items for this page."))

        threads.deferToThread(_fetch).addCallback(lambda res: reactor.callFromThread(_got, res))

    def updateHero(self):
        try:
            interval = int(config.plugins.Stremio.hero_interval_ms.value)
        except:
            interval = 10000
        self.heroTimer.start(max(800, interval), True)

        if not self.metas:
            return

        if not self._hero_pool:
            def _build_pool():
                pool, seen = [], set()
                for (t, u, y, d, b, imdb, tp) in [m[:7] for m in self.metas]:
                    local = cache_image_safe(b, fallback_url=u)
                    if local and os.path.exists(local):
                        try:
                            local = process_backdrop_with_gradient(local, is_backdrop=True)
                        except:
                            pass  # If processing fails, use original
                        if local and local not in seen:
                            pool.append((local, _u8(t))); seen.add(local)
                    if len(pool) >= 20: break
                return pool
            def _pool_ready(pool):
                self._hero_pool = pool or []
                self._hero_idx = -1
                if self._hero_pool:
                    self.updateHero()
            threads.deferToThread(_build_pool).addCallback(lambda p: reactor.callFromThread(_pool_ready, p))
            return

        if self._hero_pool:
            self._hero_idx = (self._hero_idx + 1) % len(self._hero_pool)
            local, title_txt = self._hero_pool[self._hero_idx]

            def _prep():
                pm = LoadPixmap(cached=True, path=local)
                return pm, title_txt

            def _apply(res):
                pm, title_txt = res or (None, None)
                if not pm: return
                try:
                    if self["hero"].instance:
                        self["hero"].instance.setPixmap(pm)
                        try: self["hero"].instance.setScale(1)
                        except: pass
                    if title_txt:
                        self["title"].setText(title_txt)
                except: pass

            threads.deferToThread(_prep).addCallback(lambda r: reactor.callFromThread(_apply, r))

    def updateCarousel(self):
        if not self.metas:
            for i in range(7):
                self["poster_%d" % i].hide()
            self["sel_title"].setText("")
            return

        total = len(self.metas)
        center_idx = self.selection_index

        offsets = [-3, -2, -1, 0, 1, 2, 3]

        for i, offset in enumerate(offsets):
            idx = (center_idx + offset) % total

            meta = self.metas[idx]
            t, u, y, d, b, imdb, tp = meta[:7]


            def _load_poster(url, widget_name):
                local = cache_image_safe(url)
                if local:
                    pm = LoadPixmap(cached=True, path=local)
                    return widget_name, pm
                return widget_name, None

            def _apply_poster(res):
                w_name, pm = res
                if pm and self[w_name].instance:
                    self[w_name].instance.setPixmap(pm)
                    self[w_name].show()
                else:
                    self[w_name].hide()

            if offset == 0:
                self["sel_title"].setText(_u8(t))

            threads.deferToThread(_load_poster, u, "poster_%d" % i).addCallback(lambda r: reactor.callFromThread(_apply_poster, r))

    def moveLeft(self):
        if not self.metas: return
        self.selection_index = (self.selection_index - 1) % len(self.metas)
        self.updateCarousel()

    def moveRight(self):
        if not self.metas: return
        self.selection_index = (self.selection_index + 1) % len(self.metas)
        self.updateCarousel()

    def moveUp(self):
        if not self.metas: return
        self.selection_index = (self.selection_index - 6) % len(self.metas)
        self.updateCarousel()

    def moveDown(self):
        if not self.metas: return
        self.selection_index = (self.selection_index + 6) % len(self.metas)
        self.updateCarousel()

    def openMenu(self):
        self.session.openWithCallback(self._onMenuChoice, StremioMenu, self.categories)

    def _onMenuChoice(self, choice=None):
        if not choice: return
        label, mode = choice

        if mode == "settings":
            self.session.openWithCallback(self.refreshCategories, StremioSettings)
        elif mode.startswith("search_"):
            self._search_mode = mode.replace("search_", "")
            self.session.openWithCallback(self._onSearchText, VirtualKeyBoard, title=_u8("Enter title"), text=self._search_query or "")
        elif mode == "category":
            cat = label
            if cat in self.categories:
                self.cat_index = self.categories.index(cat)
                self.page = 0
                self.loadItems()



    def _onSearchText(self, text=None):
        if not text: return
        self._search_query = text
        q = text.strip()
        def _work():
            return self._search_tmdb(q, limit=50)
        def _after(items):
            self._in_search_results = True
            label = "Debrid search" if self._search_mode == "debrid" else "Search"
            self._loadItems_from_list("%s: %s" % (label, q), items)
        d = threads.deferToThread(_work)
        d.addCallback(lambda items: reactor.callFromThread(_after, items))
        d.addErrback(lambda f: reactor.callFromThread(self._search_failed))

    def _search_failed(self):
        self.session.open(MessageBox, "Search failed.", MessageBox.TYPE_ERROR)

    def refreshCategories(self, *args):
        self.categories = list(CATEGORIES.keys())
        log_to_file("refreshCategories: %s" % self.categories)
        if self.categories and self.cat_index >= len(self.categories):
            self.cat_index = 0
            self.loadItems()

    def nextCategory(self):
        self.cat_index = (self.cat_index + 1) % len(self.categories)
        self.page = 0
        self.loadItems()

    def prevCategory(self):
        self.cat_index = (self.cat_index - 1) % len(self.categories)
        self.page = 0
        self.loadItems()

    def nextPage(self):
        self.page += 1
        if self._in_search_results:
            self.loadItems()  # or keep same page for search
        else:
            self.loadItems()

    def prevPage(self):
        if self.page > 0:
            self.page -= 1
        if self._in_search_results:
            self.loadItems()
        else:
            self.loadItems()

    def openDetails(self):
        sel_idx = self.selection_index

        t, u, y, d, b, imdb, tp = self.metas[sel_idx][:7]
        trailer = self.metas[sel_idx][7] if len(self.metas[sel_idx]) > 7 else ""
        rating = self.metas[sel_idx][8] if len(self.metas[sel_idx]) > 8 else ""
        payload = {
            "title": t, "poster": u, "year": y, "description": d,
            "background": b, "imdb_id": imdb, "type": tp, "trailer": trailer,
            "rating": rating,
            "search_mode": self._search_mode or ""
        }
        self.session.open(StremioDetails, payload)

class StremioDetails(Screen):
    def _setSkin(self):
        color = config.plugins.Stremio.theme_color.value
        if getDesktop(0).size().width() >= 1900:
            self.skin = """<screen name="StremioDetails" position="center,center" size="1920,1080" title="">
            <eLabel backgroundGradient="#00000000,%s,horizontal" position="center,center" size="1920,1080" zPosition="1" />
            <eLabel backgroundGradient="#CC000000,#00000000,vertical" position="center,center" size="1920,1080" zPosition="0" />

            <widget name="backdrop" position="0,0" scale="1" size="1920,1080" zPosition="2" />
            <widget name="poster" scale="1" position="96,270" size="390,585" zPosition="3" cornerRadius="20" />
            <widget name="title" position="520,250" size="1320,80" font="Regular;64" backgroundColor="#00000000" foregroundColor="#FFFFFF" transparent="1" zPosition="3" />
            <widget name="year" position="520,360" size="300,54" font="Regular;36" backgroundColor="#00000000" foregroundColor="#AAAAAA" transparent="1" zPosition="3" />
            <widget name="rating" position="520,410" size="500,40" font="Regular;32" backgroundColor="#00000000" foregroundColor="#FFD700" transparent="1" zPosition="3" />
            <widget name="description" position="520,460" size="1320,510" font="Regular;36" backgroundColor="#00000000" foregroundColor="#DDDDDD" transparent="1" zPosition="3" />
            <widget name="status" position="40,20" size="1320,50" font="Regular;28" foregroundColor="%s" backgroundColor="#00000000" transparent="1" zPosition="3" />

            <!-- Director -->
            <widget name="director_name" position="520,325" size="1320,30" font="Regular;28" backgroundColor="#00000000"  foregroundColor="#dddddd" transparent="1" zPosition="4" />

            <!-- Actors -->
            <widget name="actor1_pic" position="520,760" scale="1" size="150,220" zPosition="5" cornerRadius="10" />
            <widget name="actor1_name" position="520,990" size="150,40" font="Regular;20" halign="center" backgroundColor="#00000000" foregroundColor="#ffffff" transparent="1" zPosition="5" />

            <widget name="actor2_pic" position="680,760" scale="1" size="150,220" zPosition="5" cornerRadius="10" />
            <widget name="actor2_name" position="680,990" size="150,40" font="Regular;20" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" />

            <widget name="actor3_pic" position="840,760" scale="1" size="150,220" zPosition="5" cornerRadius="10" />
            <widget name="actor3_name" position="840,990" size="150,40" font="Regular;20" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" />

            <widget name="actor4_pic" position="1000,760" scale="1" size="150,220" zPosition="5" cornerRadius="10" />
            <widget name="actor4_name" position="1000,990" size="150,40" font="Regular;20" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" />

            <widget name="actor5_pic" position="1160,760" scale="1" size="150,220" zPosition="5" cornerRadius="10" />
            <widget name="actor5_name" position="1160,990" size="150,40" font="Regular;20" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" />

            <eLabel cornerRadius="30" backgroundColor="%s" position="1505,1010" size="320,55" zPosition="4" />
            <eLabel cornerRadius="30" backgroundColor="#00000000" position="1510,1015" size="310,45" zPosition="5" />
            <widget name="keys" position="1520,1020" size="290,40" font="Regular;28" foregroundColor="%s" transparent="1" zPosition="6" />
            </screen>""" % (color, color, color, color)
        else:
            self.skin = """<screen name="StremioDetails" position="center,center" size="1280,720" title="">
            <eLabel backgroundGradient="#00000000,%s,horizontal" position="center,center" size="1280,720" zPosition="1" />
            <eLabel backgroundGradient="#CC000000,#00000000,vertical" position="center,center" size="1280,720" zPosition="0" />

            <widget name="backdrop" position="0,0" size="1280,720" zPosition="2" />
            <widget name="poster" scale="1" position="60,180" size="250,370" zPosition="3" cornerRadius="20" />
            <widget name="title" position="340,180" size="880,50" font="Regular;40" foregroundColor="#FFFFFF" transparent="1" zPosition="3"/>
            <widget name="year" position="340,240" size="200,40" font="Regular;26" foregroundColor="#AAAAAA" transparent="1" zPosition="3"/>
            <widget name="rating" position="340,280" size="400,30" font="Regular;24" foregroundColor="#FFD700" transparent="1" zPosition="3"/>
            <widget name="description" position="340,320" size="850,280" font="Regular;24" foregroundColor="#DDDDDD" transparent="1" zPosition="3"/>
            <widget name="status" position="10,30" size="880,40" font="Regular;22" foregroundColor="%s" transparent="1" zPosition="3"/>

            <!-- Director -->
            <widget name="director_name" position="340,215" size="880,25" font="Regular;22" foregroundColor="#dddddd" transparent="1" zPosition="3" />

            <!-- Actors -->
            <widget name="actor1_pic" position="340,510" scale="1" size="100,150" zPosition="5" cornerRadius="5" />
            <widget name="actor1_name" position="340,665" size="100,30" font="Regular;14" halign="center" backgroundColor="#00000000" foregroundColor="#ffffff" transparent="1" zPosition="5" />

            <widget name="actor2_pic" position="450,510" scale="1" size="100,150" zPosition="5" cornerRadius="5" />
            <widget name="actor2_name" position="450,665" size="100,30" font="Regular;14" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" />

            <widget name="actor3_pic" position="560,510" scale="1" size="100,150" zPosition="5" cornerRadius="5" />
            <widget name="actor3_name" position="560,665" size="100,30" font="Regular;14" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" />

            <widget name="actor4_pic" position="670,510" scale="1" size="100,150" zPosition="5" cornerRadius="5" />
            <widget name="actor4_name" position="670,665" size="100,30" font="Regular;14" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" />

            <widget name="actor5_pic" position="780,510" scale="1" size="100,150" zPosition="5" cornerRadius="5" />
            <widget name="actor5_name" position="780,665" size="100,30" font="Regular;14" halign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" />

            <eLabel cornerRadius="20" backgroundColor="%s" position="905,660" size="300,45" zPosition="4" />
            <eLabel cornerRadius="20" backgroundColor="#00000000" position="910,665" size="290,35" zPosition="5" />
            <widget name="keys" position="925,668" size="270,30" font="Regular;20" valign="center" halign=\"center\" foregroundColor="%s" transparent="1" zPosition="6"/>
            </screen>""" % (color, color, color, color)

    def __init__(self, session, movie):
        self._setSkin()
        Screen.__init__(self, session)
        self.setTitle(movie.get("title", "Details"))
        self.movie = movie
        self._is_fetching = False
        self.poster_path = None

        self["poster"] = Pixmap()
        self["backdrop"] = Pixmap()
        self["title"] = Label(_u8(movie.get("title", "Unknown")))
        self["year"] = Label(_u8(movie.get("year", "")))

        r = movie.get("rating", "")
        if r:
            try:
                val = float(r)
                stars = "★" * int(round(val/2)) + "☆" * (5 - int(round(val/2)))
                r_text = "%s  %s/10" % (stars, r)
            except:
                r_text = r
        else:
            r_text = ""
        self["rating"] = Label(_u8(r_text))

        self["description"] = Label(_u8(movie.get("description", "")))
        self["status"] = Label("")
        self["keys"] = Label(_u8("Blue: Trailer   OK: Play"))

        self["director_name"] = Label("")
        for i in range(1, 6):
             self["actor%d_pic" % i] = Pixmap()
             self["actor%d_name" % i] = Label("")

        self["actions"] = ActionMap(["OkCancelActions","ColorActions"], {
            "cancel": self.close,
            "ok": self.playPressed,
            "blue": self.playTrailer,
        }, -1)

        self.onLayoutFinish.append(self.loadImages)
        self.onLayoutFinish.append(self.loadCast)
        self.onLayoutFinish.append(self.checkAutoPlay)

    def checkAutoPlay(self):
        if (self.movie.get("search_mode") or "") == "imdb":
            self.playPressed()

        if (self.movie.get("search_mode") or "") == "debrid":
            try:
                self["status"].setText(_u8("Tip: Press Green to play via Debrid"))
            except: pass

    def _setStatus(self, txt=""):
        try:
            self["status"].setText(_u8(txt) or "")
        except: pass

    def _pretty_bytes(self, n):
        try:
            n = float(int(n or 0))
            for unit in ["B","KB","MB","GB","TB","PB"]:
                if n < 1024.0: return "%3.1f %s" % (n, unit)
                n /= 1024.0
            return "%3.1f EB" % n
        except:
            return "—"

    def loadImages(self):
        poster_url = self.movie.get("poster", "")
        backdrop_url = self.movie.get("background", poster_url)
        def _prep():
            p_local = cache_image_safe(poster_url)
            b_local = cache_image_safe(backdrop_url, fallback_url=poster_url)
            if b_local:
                try:
                    b_local = process_backdrop_with_gradient(b_local, is_backdrop=True)
                except:
                    pass  # If processing fails, use original
            pm_p = LoadPixmap(cached=True, path=p_local) if p_local else None
            pm_b = LoadPixmap(cached=True, path=b_local) if b_local else None
            return pm_p, pm_b, p_local
        def _apply(res):
            if not res: return
            pm_p, pm_b, p_local = res
            self.poster_path = p_local
            try:
                if pm_p and self["poster"].instance: self["poster"].instance.setPixmap(pm_p)
                if pm_b and self["backdrop"].instance: self["backdrop"].instance.setPixmap(pm_b)
            except: pass
        threads.deferToThread(_prep).addCallback(lambda r: reactor.callFromThread(_apply, r))

    def loadCast(self):
        if not config.plugins.Stremio.show_cast.value: return

        def _fetch():
             imdb = self.movie.get("imdb_id")
             kind = self.movie.get("type", "movie")
             return fetch_tmdb_cast(imdb, kind)

        def _apply(res):
             if not res: return
             # Director
             dname = res.get("director")
             if dname and self["director_name"].instance:
                  self["director_name"].setText(_u8("Director: " + dname))

             # Actors (Texts)
             actors = res.get("actors", [])
             for i, actor in enumerate(actors):
                  idx = i + 1
                  if idx > 5: break
                  aname = actor.get("name")
                  if aname and self["actor%d_name" % idx].instance:
                       self["actor%d_name" % idx].setText(_u8(aname))

             # Fetch Images
             def _fetch_imgs():
                  out = []
                  for i, actor in enumerate(actors):
                       if i >= 5: break
                       url = actor.get("pic")
                       if url:
                            loc = cache_image_safe(url)
                            if loc: out.append((i+1, loc))
                  return out

             def _show_imgs(imgs):
                  for idx, path in imgs:
                       if path:
                            pm = LoadPixmap(cached=True, path=path)
                            if pm and self["actor%d_pic"%idx].instance:
                                 self["actor%d_pic"%idx].instance.setPixmap(pm)

             threads.deferToThread(_fetch_imgs).addCallback(lambda r: reactor.callFromThread(_show_imgs, r))

        threads.deferToThread(_fetch).addCallback(lambda r: reactor.callFromThread(_apply, r))

    def playPressed(self):
        if self._is_fetching: return
        typ = (self.movie.get("type") or "movie").lower()
        imdb = self.movie.get("imdb_id", "")
        if not imdb:
            self.session.open(MessageBox, "No IMDB id found!", MessageBox.TYPE_ERROR); return
        if typ == "series":
            self._fetchEpisodesThenChoose(imdb)
        else:
            mode = config.plugins.Stremio.play_mode.value
            if mode == "debrid":
                self.playViaDebrid()
            else:
                self._pickStreamsThenChoose("movie", imdb, None, None)

    def playTrailer(self):
        tr = (self.movie.get("trailer") or "").strip()
        poster_url = self.movie.get("poster", "")
        poster = cache_image_safe(poster_url)

        # If no trailer in metadata, try to fetch from TMDB
        if not tr:
            self["status"].setText("Searching TMDB for trailer...")

            def _find_trailer():
                imdb = self.movie.get("imdb_id")
                kind = self.movie.get("type", "movie")
                return fetch_tmdb_trailer(imdb, kind)

            def _got_trailer(res):
                self["status"].setText("")
                if res:
                    self.movie["trailer"] = res # Cache it
                    self.playTrailer() # Recursive call now that we have it
                else:
                    self.session.open(MessageBox, "No trailer available.", MessageBox.TYPE_INFO)

            threads.deferToThread(_find_trailer).addCallback(lambda r: reactor.callFromThread(_got_trailer, r))
            return

        if tr.startswith("youtube:"):
            tr = "https://www.youtube.com/watch?v=" + tr.split(":",1)[1]
        if not tr.startswith("http"):
            self.session.open(MessageBox, "Unsupported trailer format.", MessageBox.TYPE_INFO); return
        if not config.plugins.Stremio.ytdlp_enabled.value:
            self.session.open(MessageBox, "Enable yt-dlp in settings to play trailers.", MessageBox.TYPE_INFO); return
        try:
            # Usage b[ext=mp4] to get pre-merged mp4 (video+audio) which is most compatible
            # and suppresses the warning. Fallback to 'best' if no mp4 found.
            cmd = "yt-dlp -g -f \"b[ext=mp4]/best\" %s" % tr
            log_to_file("[playTrailer] Executing: %s" % cmd)
            p = subprocess.Popen(shlex.split(cmd), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = p.communicate()
            if err:
                log_to_file("[playTrailer] yt-dlp stderr: %s" % err)

            url = (out or "").strip().splitlines()[-1]
            if not url:
                log_to_file("[playTrailer] yt-dlp returned no URL. Out: %s" % out)
                raise Exception("yt-dlp failed to resolve URL")

            # yt-dlp output is bytes in Py3, need to decode
            if isinstance(url, bytes):
                url = url.decode("utf-8").strip()
            # In rare cases if it is already str but we want to be safe
            elif isinstance(url, str):
                url = url.strip()

            log_to_file("[playTrailer] Resolved URL: %s" % url)

            ref = eServiceReference(4097, 0, url)
            ref.setName(_u8((self.movie.get("title") or "") + " • Trailer"))
            disp = _u8((self.movie.get("title") or "") + " • Trailer")
            self.session.open(StremioPlayer, ref, str(url), poster, str(url), poster, 4097, disp, streamMode=True, askBeforeLeaving=True)
            #self.session.open(MoviePlayer, ref)
        except Exception as e:
            log_to_file("[playTrailer] Exception: %s" % e)
            self.session.open(MessageBox, "Trailer resolve failed: %s" % str(e), MessageBox.TYPE_ERROR)

    def _fetchEpisodesThenChoose(self, imdb):
        self._is_fetching = True
        self._setStatus("Fetching episodes…")
        def _fetch_videos():
            data = http_get("https://v3-cinemeta.strem.io/meta/series/%s.json" % imdb, headers={"Accept":"application/json"})
            if not data: return []
            j = json.loads(data)
            vids = j.get("meta", {}).get("videos", []) or []
            try: vids.sort(key=lambda v: (int(v.get("season", 0)), int(v.get("episode", 0))))
            except: pass
            return vids
        def _choose(videos):
            self._is_fetching = False
            self._setStatus("")
            if not videos:
                self.session.open(MessageBox, "No episodes found", MessageBox.TYPE_ERROR); return
            def cb_ep(ep_data=None):
                if not ep_data: return
                s = int(ep_data.get("season", 0))
                e = int(ep_data.get("episode", 0))
                self._pickStreamsThenChoose("series", imdb, s, e)

            self.session.openWithCallback(cb_ep, StremioEpisodes, self.movie, videos)
        d = threads.deferToThread(_fetch_videos)
        d.addCallback(lambda vids: reactor.callFromThread(_choose, vids))
        d.addErrback(lambda f: reactor.callFromThread(self._onAsyncError))

    def _build_lang_tag(self, text):
        t = (text or "").lower()
        langs = []
        pairs = [
            ("english","EN"), ("eng","EN"), ("en","EN"),
            ("french","FR"), ("fr","FR"),
            ("dutch","NL"), ("nederlands","NL"), ("nl","NL"),
            ("german","DE"), ("ger","DE"), ("de","DE"),
            ("italian","IT"), ("ita","IT"), ("it","IT"),
            ("spanish","ES"), ("spa","ES"), ("es","ES"),
            ("portuguese","PT"), ("pt-br","PT-BR"), ("pt","PT"),
            ("russian","RU"), ("rus","RU"), ("ru","RU"),
            ("polish","PL"), ("pl","PL"),
            ("turkish","TR"), ("tr","TR"),
            ("arabic","AR"), ("ar","AR"),
            ("multi","MULTI")
        ]
        for k, tag in pairs:
            if ("[%s]"%k) in t or ("(%s)"%k) in t or (" %s " % k) in (" "+t+" "):
                if tag not in langs: langs.append(tag)
        return ",".join(langs) if langs else ""

    def _build_quality_tag(self, title_info_blob):
        b = (title_info_blob or "").lower()
        tags = []
        for q in ["2160p","4k","1080p","720p","480p"]:
            if q in b: tags.append(q.upper()); break
        for v in ["remux","bluray","bdrip","web-dl","webrip","hdr","dv","atmos","dts","5.1","7.1","x265","hevc","x264"]:
            if v in b: tags.append(v.upper())
        return " ".join(tags)

    def _build_stream_label(self, s):
        title = s.get("title") or s.get("name") or ""
        info  = s.get("info") or s.get("description") or ""
        file  = s.get("filename") or ""
        prov  = s.get("provider") or s.get("source") or s.get("from") or ""
        size  = s.get("size") or ""
        seeds = s.get("seeders") or s.get("seeds") or ""
        blob = " ".join([title, info, file])
        qtag = self._build_quality_tag(blob)
        ltag = self._build_lang_tag(blob)
        bits = []
        if qtag: bits.append(qtag)
        if ltag: bits.append(ltag)
        if prov: bits.append(prov)
        if seeds: bits.append("seeds:%s" % seeds)
        if size: bits.append(size)
        release = title or file or "Stream"
        label = " • ".join(bits)
        if label: label += "  —  " + release
        else: label = release
        return _u8(label)

    def _pickStreamsThenChoose(self, typ, imdb, season, episode):
        if self._is_fetching: return
        self._is_fetching = True
        tid = "%s:%d:%d" % (imdb, int(season), int(episode)) if (season is not None and episode is not None) else imdb
        self._setStatus("Fetching streams…")

        def _fetch_streams():
            base = (config.plugins.Stremio.addon_base_url.value or ADDON_BASE_URL).rstrip("/")
            prov = get_provider(base)
            url = prov.get_stream_url(typ, imdb, season, episode)

            log_to_file("[_fetch_streams] Provider: %s URL: %s" % (prov.name, url))

            j = http_json(url)
            log_to_file("[_fetch_streams] Result: %s" % ("Found" if j else "None"))

            return prov.parse_streams(j, self.movie.get("title"), self.movie.get("year"), season, episode) if j else []

        def _choose(streams):
            self._is_fetching = False
            self._setStatus("")
            if not streams:
                self.session.open(MessageBox, "No streams available", MessageBox.TYPE_ERROR); return

            opts, built = [], []  # -> (label, magnet, human)
            for s in streams:
                url = s.get("url") or ""
                title = s.get("title") or s.get("name") or imdb
                if not url.startswith("magnet:"):
                    ih = s.get("infoHash") or s.get("infohash") or s.get("info_hash") or ""
                    if ih:
                        fidx = s.get("fileIdx") or s.get("fileIndex") or s.get("file")
                        try:
                            if isinstance(fidx, basestring) and fidx.isdigit(): fidx = int(fidx)
                        except: pass
                        url = magnet_from_infohash(ih, name=title or imdb, file_idx=fidx)

                if not (url.startswith("magnet:") or url.startswith("http")): continue

                label = self._build_stream_label(s)
                built.append((label, url, title))
                opts.append((label, len(built)-1))

            if not opts:
                self.session.open(MessageBox, "No streams found", MessageBox.TYPE_ERROR); return

            def cb_stream(choice=None):
                if choice is None: return
                _, url, human = built[choice]

                if url.startswith("http"):
                    ref = eServiceReference(4097, 0, url)
                    ref.setName(_u8(human))
                    self.session.open(MoviePlayer, ref)
                    return

                if (self.movie.get("search_mode") or "") == "debrid":
                    self._play_via_debrid_magnet(url)
                    return

                # For magnets/other, ask Play or Download
                def _handle_choice(action):
                    log_to_file("[cb_stream] _handle_choice action=%s type=%s" % (str(action), type(action)))

                    # ChoiceBox returns (label, key) if a list of tuples was passed
                    # If just ["a", "b"] it returns string. We passed tuples.
                    # e.g. ("Play...", "play")

                    val = action
                    if isinstance(action, tuple) or isinstance(action, list):
                        if len(action) > 1: val = action[1]

                    log_to_file("[cb_stream] Selected value: %s" % val)

                    if val == "play":
                         self._useTorrMgr_listFiles(url, human)
                    elif val == "download":
                        # We need an estimated size. Stremio doesn't give it easily in stream list sometimes.
                        # We used to pass it. 'built' has (label, url, title).
                        # Let's verify if we can extract size from title or just usage big estimate
                        bsize = 5 * 1024 * 1024 * 1024
                        initiateDownload(self.session, url, bsize, human)

                menu = [
                    ("Play [TorrServer / Debrid]", "play"),
                    ("Download [Transmission-Cli]", "download"),
                ]
                self.session.openWithCallback(_handle_choice, ChoiceBox, title="Choose action for %s" % human, list=menu)

            payload = {
                "title": self.movie.get("title", ""),
                "poster": self.movie.get("poster", ""),
                "year": self.movie.get("year", ""),
                "background": self.movie.get("background", ""),
                "type": self.movie.get("type", ""),
                "description": self.movie.get("description", ""),
                "streams": built
            }
            self.session.openWithCallback(cb_stream, StremioStreams, payload)

        d = threads.deferToThread(_fetch_streams)
        d.addCallback(lambda st: reactor.callFromThread(_choose, st))
        d.addErrback(lambda f: reactor.callFromThread(self._onAsyncError))

    def _onAsyncError(self, *_a, **_kw):
        self._is_fetching = False
        self._setStatus("")
        self.session.open(MessageBox, "Network error", MessageBox.TYPE_ERROR)

    def playViaDebrid(self):
        imdb = self.movie.get("imdb_id","")
        if not imdb:
            self.session.open(MessageBox, "No IMDB id for this title.", MessageBox.TYPE_ERROR); return
        typ = (self.movie.get("type") or "movie").lower()
        def _fetch_streams():
            base = ADDON_BASE_URL.rstrip("/")
            url = "%s/stream/%s/%s.json" % (base, typ, imdb)
            params = ADDON_PARAMS_DEFAULT
            if params: url += "?" + params
            j = http_json(url)
            return (j.get("streams") or []) if j else []
        def _choose_and_debrid(streams):
            if not streams:
                self.session.open(MessageBox, "No streams available for Debrid.", MessageBox.TYPE_ERROR); return
            opts, built = [], []
            for s in streams:
                url = s.get("url") or ""
                title = s.get("title") or s.get("name") or (self.movie.get("title") or imdb)
                if not url.startswith("magnet:"):
                    ih = s.get("infoHash") or s.get("infohash") or s.get("info_hash") or ""
                    if ih:
                        fidx = s.get("fileIdx") or s.get("fileIndex") or s.get("file")
                        try:
                            if isinstance(fidx, basestring) and fidx.isdigit(): fidx = int(fidx)
                        except: pass
                        url = magnet_from_infohash(ih, name=title or imdb, file_idx=fidx)
                if not url.startswith("magnet:"): continue
                label = self._build_stream_label(s)
                built.append((label, url, title))
                opts.append((label, len(built)-1))
            if not opts:
                self.session.open(MessageBox, "No magnet streams found for Debrid.", MessageBox.TYPE_ERROR); return

            def cb_stream(choice=None):
                if choice is None: return
                _, magnet, _ = built[choice]
                self._play_via_debrid_magnet(magnet)

            payload = {
                "title": self.movie.get("title", ""),
                "poster": self.movie.get("poster", ""),
                "background": self.movie.get("background", ""),
                "year": self.movie.get("year", ""),
                "vote_average": self.movie.get("vote_average", ""),
                "overview": self.movie.get("overview", ""),
                "streams": built
            }
            self.session.openWithCallback(cb_stream, StremioStreams, payload)
        d = threads.deferToThread(_fetch_streams)
        d.addCallback(lambda st: reactor.callFromThread(_choose_and_debrid, st))
        d.addErrback(lambda f: reactor.callFromThread(self._onAsyncError))

    def _play_via_debrid_magnet(self, magnet):
        dr = DebridResolver()
        if not dr.enabled():
            self.session.open(MessageBox, "Enable Debrid + token in Settings.", MessageBox.TYPE_INFO); return
        def _work():
            return dr.add_and_list(magnet)  # -> list of (name, size, direct_url)
        def _pick_file(files):
            if not files:
                self.session.open(MessageBox, "Debrid did not return any files.", MessageBox.TYPE_ERROR); return

            tr_adapter = DebridTorrentAdapter(
                title=self.movie.get("title", "Debrid Stream"),
                files=files,
                poster=self.poster_path or self.movie.get("poster", "")
            )
            self.session.open(StremioTorrFiles, tr_adapter, self.movie.get("title", "Debrid Stream"))
        d = threads.deferToThread(_work)
        d.addCallback(lambda fs: reactor.callFromThread(_pick_file, fs))
        d.addErrback(lambda f: reactor.callFromThread(self._onAsyncError))

    def _useTorrMgr_listFiles(self, magnet, human_title):
        if torrsrv is None:
            self.session.open(MessageBox, "TorrServer module not available.", MessageBox.TYPE_ERROR); return
        base = (config.plugins.Stremio.torrserver_url.value or "").strip()
        if not base:
            self.session.open(MessageBox, "TorrServer URL is empty in Settings.", MessageBox.TYPE_ERROR); return
        self._is_fetching = True
        self._setStatus("Adding torrent to TorrServer…")

        def _work():
            ts = torrsrv.torrserver()
            ts.url = base
            tr = torrsrv.torrent(title=human_title,
                                 poster=self.poster_path or self.movie.get("poster", ""),
                                 link=magnet,
                                 torrsrv=ts)
            log_to_file("[Stremio] Adding torrent to TorrServer: %s" % human_title)
            ok = ts.add_torrent(tr)
            if not ok:
                log_to_file("[Stremio] Failed to add torrent to TorrServer")
                return None

            log_to_file("[Stremio] Waiting for metadata...")
            for i in range(10):
                res = ts.get_torrent(tr)
                if res and res.files and len(res.files) > 0:
                    log_to_file("[Stremio] Metadata found! Files: %d" % len(res.files))
                    return res
                log_to_file("[Stremio] Metadata not ready yet, retrying... (%d/10)" % (i+1))
                time.sleep(1)

            log_to_file("[Stremio] Metadata fetch timed out")
            return ts.get_torrent(tr)  # fills hash + files

        def _after(tr_full):
            self._is_fetching = False
            self._setStatus("")
            if not tr_full:
                self.session.open(MessageBox, "TorrServer: failed to add torrent.", MessageBox.TYPE_ERROR); return

            if not tr_full.files:
                 self.session.open(MessageBox, "TorrServer: metadata not found or no video files.", MessageBox.TYPE_ERROR); return

            self.session.open(StremioTorrFiles, tr_full, self.movie.get("title", human_title), self.poster_path or self.movie.get("poster", ""))

        d = threads.deferToThread(_work)
        d.addCallback(lambda tr: reactor.callFromThread(_after, tr))
        d.addErrback(lambda f: reactor.callFromThread(self._onAsyncError))

class StremioStreams(Screen):
    def _setSkin(self):
        """Screen to display and select Torrentio streams with backdrop and poster"""
        color = config.plugins.Stremio.theme_color.value
        if getDesktop(0).size().width() >= 1900:
            self.skin = """<screen name="StremioStreams" position="center,center" size="1920,1080" title="Select Stream">
            <widget name="backdrop" position="0,0" scale="1" size="1920,1080" zPosition="0" />
            <widget name="poster" scale="1" position="96,100" size="300,450" zPosition="4" cornerRadius="20" />
            <widget name="name" position="450,100" size="1400,70" font="Regular;56" foregroundColor="#FFFFFF" transparent="1" zPosition="4"/>
            <widget name="info" position="450,180" size="1400,40" font="Regular;32" foregroundColor="#AAAAAA" transparent="1" zPosition="4"/>
            <widget name="description" position="450,260" size="1320,310" font="Regular;36" backgroundColor="#00000000" foregroundColor="#DDDDDD" transparent="1" zPosition="5" />
            <widget enableWrapAround="1" itemheight="80" position="96,580" size="1750,400" render="Listbox" source="streamlist" scrollbarMode="showOnDemand" transparent="1" zPosition="1">
                <convert type="TemplatedMultiContent">{
                    "templates": {
                        "default": (
                            80, [
                                MultiContentEntryText(pos=(10,5), size=(200,30), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                                MultiContentEntryText(pos=(220,5), size=(1350,70), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=1),
                                MultiContentEntryText(pos=(1580,5), size=(150,30), font=0, flags=RT_HALIGN_RIGHT|RT_VALIGN_CENTER, color="#00ced1", text=2),
                                MultiContentEntryText(pos=(1580,40), size=(150,30), font=0, flags=RT_HALIGN_RIGHT|RT_VALIGN_CENTER, color="#00ff00", text=3),
                                MultiContentEntryText(pos=(10,40), size=(1430,30), font=1, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=4)
                            ]
                        )
                    },
                    "fonts": [ gFont("Regular",24), gFont("Regular",20) ],
                    "itemHeight": 80
                }</convert>
            </widget>
            <eLabel cornerRadius="30" backgroundColor="%s" position="40,1010" size="1845,55" zPosition="4" />
            <eLabel cornerRadius="30" backgroundColor="#00000000" position="50,1015" size="1830,45" zPosition="5" />

            <widget name="status" position="60,1020" size="1800,40" valign="center" halign="center" font="Regular;28" foregroundColor="%s" transparent="1" zPosition="6"/>
            </screen>"""  % (color, color)
        else:
            self.skin =  """<screen name="StremioStreams" position="center,center" size="1280,720" title="Select Stream">
            <widget name="backdrop" position="0,0" size="1280,720" zPosition="0" />
            <widget name="poster" scale="1" position="60,70" size="200,300" zPosition="4" cornerRadius="20" />
            <widget name="name" position="300,70" size="920,50" font="Regular;40" foregroundColor="#FFFFFF" transparent="1" zPosition="1"/>
            <widget name="info" position="300,130" size="920,30" font="Regular;24" foregroundColor="#AAAAAA" transparent="1" zPosition="1"/>
            <widget name="description" position="300,180" size="850,200" font="Regular;24" foregroundColor="#DDDDDD" transparent="1" zPosition="3"/>
            <widget enableWrapAround="1" itemheight="60" position="60,400" size="1160,240" render="Listbox" source="streamlist" scrollbarMode="showOnDemand" transparent="1" zPosition="1">
                <convert type="TemplatedMultiContent">{
                    "templates": {
                        "default": (
                            60, [
                                MultiContentEntryText(pos=(5,3), size=(130,22), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                                MultiContentEntryText(pos=(140,5), size=(880,50), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=1),
                                MultiContentEntryText(pos=(1030,3), size=(100,22), font=0, flags=RT_HALIGN_RIGHT|RT_VALIGN_CENTER, color="#00ced1", text=2),
                                MultiContentEntryText(pos=(1030,28), size=(110,22), font=0, flags=RT_HALIGN_RIGHT|RT_VALIGN_CENTER, color="#00ff00", text=3),
                                MultiContentEntryText(pos=(5,28), size=(965,22), font=1, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=4)
                            ]
                        )
                    },
                    "fonts": [ gFont("Regular",18), gFont("Regular",16) ],
                    "itemHeight": 60
                }</convert>
            </widget>
            <eLabel cornerRadius="30" backgroundColor="%s" position="30,670" size="1195,45" zPosition="4" />
            <eLabel cornerRadius="30" backgroundColor="#00000000" position="35,675" size="1180,35" zPosition="5" />
            <widget name="status" position="40,680" size="1170,30" valign="center" halign="center" font="Regular;22" foregroundColor="%s" transparent="1" zPosition="6"/>
            </screen>""" % (color, color)

    def __init__(self, session, movie_data):
        self._setSkin()
        Screen.__init__(self, session)
        self.movie = movie_data
        self.streams = movie_data.get("streams", [])

        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.selectStream,
            "cancel": self.close
        }, -1)

        self["backdrop"] = Pixmap()
        self["poster"] = Pixmap()
        self["name"] = Label(_u8(self._buildtitle()))
        self["info"] = Label(_u8(self._buildInfo()))
        self["streamlist"] = List([])
        self["status"] = Label(_u8("OK: Select Stream   |   Exit: Cancel"))
        self["status"] = Label(_u8("OK: Select Stream   |   Exit: Cancel"))
        self["description"] = Label(_u8(self._buildDesc()))

        self.onLayoutFinish.append(self.loadData)

    def _buildtitle(self):
        parts = []
        title = self.movie.get("title", "Unknown")
        if title: parts.append(str(title))
        prov_url = config.plugins.Stremio.addon_base_url.value
        prov = get_provider(prov_url)
        parts.append(str(prov.name))
        return " |  Provider:  ".join(parts) if parts else ""

    def _buildDesc(self):
        desc = self.movie.get("description", "")
        return desc if desc else ""

    def _buildInfo(self):
        parts = []
        year = self.movie.get("year", "")
        if year: parts.append(str(year))
        typ = self.movie.get("type", "")
        if typ: parts.append(typ.title())
        return " • ".join(parts) if parts else ""

    def loadData(self):
        log_to_file("[StremioStreams] loadData called")
        poster_url = self.movie.get("poster", "")
        backdrop_url = self.movie.get("background", poster_url)

        def _prep():
            p_local = cache_image_safe(poster_url)
            b_local = cache_image_safe(backdrop_url, fallback_url=poster_url)
            if b_local:
                try:
                    b_local = process_backdrop_with_gradient(b_local, is_backdrop=True)
                except:
                    pass
            pm_p = LoadPixmap(cached=True, path=p_local) if p_local else None
            pm_b = LoadPixmap(cached=True, path=b_local) if b_local else None
            return pm_p, pm_b

        def _apply(res):
            if not res: return
            pm_p, pm_b = res
            try:
                if pm_p and self["poster"].instance: self["poster"].instance.setPixmap(pm_p)
                if pm_b and self["backdrop"].instance: self["backdrop"].instance.setPixmap(pm_b)
            except: pass

        threads.deferToThread(_prep).addCallback(lambda r: reactor.callFromThread(_apply, r))

        self.buildStreamList()

    def buildStreamList(self):
        """Build formatted stream list from streams data"""
        lst = []
        for idx, stream_data in enumerate(self.streams):
            label_text, magnet, human_title = stream_data

            quality = self._extractQuality(label_text)
            size = self._extractSize(label_text)
            seeds = self._extractSeeds(label_text)
            title = self._cleanTitle(label_text)
            extra = self._buildExtra(label_text)

            entry = (
                _u8(quality),
                _u8(title),
                _u8(size),
                _u8('Seeders 👤: {}'.format(seeds)),
                _u8(extra)
            )
            lst.append(entry)

        self["streamlist"].setList(lst)

    def _extractQuality(self, label):
        """Extract quality from label (4K, 2160p, 1080p, 720p, etc)"""
        label_upper = label.upper()
        if "2160P" in label_upper or "4K" in label_upper:
            return "[4K]"
        elif "1080P" in label_upper:
            return "[1080p]"
        elif "720P" in label_upper:
            return "[720p]"
        elif "480P" in label_upper:
            return "[480p]"
        return "[SD]"

    def _extractSize(self, label):
        """Extract file size from label"""
        import re
        match = re.search(r'([\d.]+\s*[GMK]B)', label, re.IGNORECASE)
        return match.group(1) if match else ""

    def _extractSeeds(self, label):
        """Extract seeders count from label"""
        import re
        match = re.search(r'(\d+)\s*seeders?', label, re.IGNORECASE)
        if not match:
            match = re.search(r'[👤]\s*(\d+)', label)
        return match.group(1) if match else ""

    def _cleanTitle(self, label):
        """Clean title by removing emoji/metadata"""
        import re
        title = re.sub(r'[\U0001F300-\U0001F9FF]', '', label)  # All emoji
        title = re.sub(r'[⚡⚙️]', '', title)  # Additional symbols
        title = re.sub(r'\d+(\.\d+)?\s*[GMK]B', '', title, flags=re.IGNORECASE)
        title = re.sub(r'\d+\s*seeders?', '', title, flags=re.IGNORECASE)
        title = re.sub(r'\s+', ' ', title).strip()
        if len(title) > 120:
            title = title[:110] + "\n" + title[110:]
        return title

    def _buildExtra(self, label):
        """Build extra info line"""
        parts = []
        if "cached" in label.lower() or "debrid" in label.lower():
            parts.append("Cached")
        if "HEVC" in label.upper() or "X265" in label.upper():
            parts.append("HEVC")
        if "HDR" in label.upper():
            parts.append("HDR")
        if "REMUX" in label.upper():
            parts.append("REMUX")
        return " | ".join(parts) if parts else ""

    def selectStream(self):
        """User selected a stream"""
        sel = self["streamlist"].getIndex()
        if sel >= 0 and sel < len(self.streams):
            self.close(sel)
        else:
            self.close(None)

class StremioEpisodes(Screen):
    def _setSkin(self):
        """Screen to display and select Torrentio streams with backdrop and poster"""
        color = config.plugins.Stremio.theme_color.value
        if getDesktop(0).size().width() >= 1900:
            self.skin = """<screen name="StremioEpisodes" position="center,center" size="1920,1080" title="Select Episode">
            <widget name="backdrop" position="0,0" scale="1" size="1920,1080" zPosition="0" />
            <widget name="poster" scale="1" position="96,100" size="300,450" zPosition="4" cornerRadius="20" />
            <widget name="title" position="450,100" size="1400,70" font="Regular;56" foregroundColor="#FFFFFF" transparent="1" zPosition="4"/>
            <widget name="info" position="450,180" size="1400,40" font="Regular;32" foregroundColor="#AAAAAA" transparent="1" zPosition="4"/>
            <widget name="description" position="450,260" size="1400,410" font="Regular;32" foregroundColor="#DDDDDD" transparent="1" zPosition="3" />
            <widget enableWrapAround="1" itemheight="50" position="96,600" size="1750,420" render="Listbox" source="list" scrollbarMode="showOnDemand" transparent="1" zPosition="1">
                <convert type="TemplatedMultiContent">{
                    "templates": {
                        "default": (
                            50, [
                                MultiContentEntryText(pos=(10,5), size=(200,40), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                                MultiContentEntryText(pos=(220,5), size=(1200,40), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=1),
                                MultiContentEntryText(pos=(1430,5), size=(300,40), font=0, flags=RT_HALIGN_RIGHT|RT_VALIGN_CENTER, text=2)
                            ]
                        )
                    },
                    "fonts": [ gFont("Regular",34), gFont("Regular",20) ],
                    "itemHeight": 50
                }</convert>
            </widget>
            <eLabel cornerRadius="30" backgroundColor="%s" position="40,1010" size="1845,55" zPosition="4" />
            <eLabel cornerRadius="30" backgroundColor="#00000000" position="50,1015" size="1830,45" zPosition="5" />

            <widget name="status" position="60,1020" size="1800,40" valign="center" halign="center" font="Regular;28" foregroundColor="%s" transparent="1" zPosition="6"/>
            </screen>"""  % (color, color)
        else:
            self.skin = """<screen name="StremioEpisodes" position="center,center" size="1280,720" title="Select Episode">
            <widget name="backdrop" position="0,0" size="1280,720" zPosition="0" />
            <widget name="poster" scale="1" position="60,70" size="200,300" zPosition="4" cornerRadius="20" />
            <widget name="title" position="300,70" size="920,50" font="Regular;40" foregroundColor="#FFFFFF" transparent="1" zPosition="1"/>
            <widget name="info" position="300,130" size="920,30" font="Regular;24" foregroundColor="#AAAAAA" transparent="1" zPosition="1"/>
            <widget name="description" position="300,150" size="920,210" font="Regular;24" foregroundColor="#DDDDDD" transparent="1" zPosition="3"/>
            <widget enableWrapAround="1" itemheight="40" position="60,400" size="1160,240" render="Listbox" source="list" scrollbarMode="showOnDemand" transparent="1" zPosition="1">
                <convert type="TemplatedMultiContent">{
                    "templates": {
                        "default": (
                            40, [
                                MultiContentEntryText(pos=(5,3), size=(130,22), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                                MultiContentEntryText(pos=(140,3), size=(650,22), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=1),
                                MultiContentEntryText(pos=(1025,3), size=(100,22), font=0, flags=RT_HALIGN_RIGHT|RT_VALIGN_CENTER, text=2)
                            ]
                        )
                    },
                    "fonts": [ gFont("Regular",18), gFont("Regular",16) ],
                    "itemHeight": 40
                }</convert>
            </widget>
            <eLabel cornerRadius="30" backgroundColor="%s" position="30,670" size="1195,45" zPosition="4" />
            <eLabel cornerRadius="30" backgroundColor="#00000000" position="35,675" size="1180,35" zPosition="5" />
            <widget name="status" position="40,680" size="1170,30" valign="center" halign="center" font="Regular;22" foregroundColor="%s" transparent="1" zPosition="6"/>
            </screen>""" % (color, color)

    def __init__(self, session, movie_data, episodes):
        self._setSkin()
        Screen.__init__(self, session)
        self.movie = movie_data
        self.episodes = episodes

        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.selectEpisode,
            "cancel": self.close
        }, -1)

        self["backdrop"] = Pixmap()
        self["poster"] = Pixmap()
        self["title"] = Label(_u8(self.movie.get("title", "Unknown")))
        self["info"] = Label(_u8(self._buildInfo()))
        self["description"] = Label("")
        self["list"] = List([])
        self["status"] = Label(_u8("OK: Select episode | Exit: Cancel"))

        self.onLayoutFinish.append(self.loadData)
        self['list'].onSelectionChanged.append(self.description)

    def _buildInfo(self):
        parts = []
        year = self.movie.get("year", "")
        if year: parts.append(str(year))
        typ = self.movie.get("type", "")
        if typ: parts.append(typ.title())
        return " • ".join(parts) if parts else ""

    def loadData(self):
        poster_url = self.movie.get("poster", "")
        backdrop_url = self.movie.get("background", poster_url)

        def _prep():
            p_local = cache_image_safe(poster_url)
            b_local = cache_image_safe(backdrop_url, fallback_url=poster_url)
            if b_local:
                try:
                    b_local = process_backdrop_with_gradient(b_local, is_backdrop=True)
                except:
                    pass
            pm_p = LoadPixmap(cached=True, path=p_local) if p_local else None
            pm_b = LoadPixmap(cached=True, path=b_local) if b_local else None
            return pm_p, pm_b

        def _apply(res):
            if not res: return
            pm_p, pm_b = res
            try:
                if pm_p and self["poster"].instance: self["poster"].instance.setPixmap(pm_p)
                if pm_b and self["backdrop"].instance: self["backdrop"].instance.setPixmap(pm_b)
            except: pass

        threads.deferToThread(_prep).addCallback(lambda r: reactor.callFromThread(_apply, r))

        self.buildList()

    def buildList(self):
        lst = []
        for ep in self.episodes:
            s = ep.get("season", 0)
            e = ep.get("episode", 0)
            name = ep.get("name", "")
            released = ep.get("released", "")
            overview = ep.get("overview", "")

            s_e = "S%02dE%02d" % (s, e)

            entry = (
                _u8(s_e),
                _u8(name),
                _u8(released.split("T")[0] if released else ""),
                _u8(overview),
                ep # store full object for return
            )
            lst.append(entry)

        self["list"].setList(lst)

    def selectEpisode(self):
        cur = self["list"].getCurrent()
        if cur:
            ep_data = cur[4]
            self.close(ep_data)

    def description(self):
        try:
            selected_item = self['list'].getCurrent()
            overview = selected_item[3]
            self['description'].setText(_('Description:\n') + _u8(overview) if overview else _('\n\nNo Description Found'))
        except:
            pass

class DebridFileAdapter:
    def __init__(self, name, size, url):
        self.path = name
        self.length = size
        self.id = url

class DebridServiceAdapter:
    def get_stream_url(self, trnt, file_id):
        return {"stream": file_id, "file": file_id}

    def preload_torrent(self, trnt, fid, wait_time=10):
        raise Exception("Preload not supported for Debrid streams")

class DebridTorrentAdapter:
    def __init__(self, title, files, poster=""):
        self.title = title
        self.poster = poster
        self.files = [DebridFileAdapter(n, s, u) for n, s, u in files]
        self.torrsrv = DebridServiceAdapter()

class PVRState2(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self["eventname"] = Label('')
        self["state"] = Label('')
        self["speed"] = Label('')
        self["statusicon"] = MultiPixmap()

PVRState = PVRState2

class IPTVInfoBarPVRState:
    def __init__(self, screen=PVRState, force_show=True):
        self.onChangedEntry = []
        self.onPlayStateChanged.append(self.__playStateChanged)
        self.pvrStateDialog = self.session.instantiateDialog(screen)
        self.onShow.append(self._mayShow)
        self.onHide.append(self.pvrStateDialog.hide)
        self.force_show = force_show

    def _mayShow(self):
        if "state" in self and not self.force_show:
            self["state"].setText("")
            self["statusicon"].setPixmapNum(6)
            self["speed"].setText("")
        if self.shown and self.seekstate != self.SEEK_STATE_EOF and not self.force_show:
            self.pvrStateDialog.show()
            self.startHideTimer()

    def __playStateChanged(self, state):
        playstateString = state[3]
        state_summary = playstateString

        if "statusicon" in self.pvrStateDialog:
            self.pvrStateDialog["state"].setText(playstateString)
            speedtext = ""
            self.pvrStateDialog["speed"].setText("")
            speed_summary = self.pvrStateDialog["speed"].text
            if playstateString:
                if playstateString == ">":
                    statusicon_summary = 0
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)

                elif playstateString == "||":
                    statusicon_summary = 1
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)

                elif playstateString == "END":
                    statusicon_summary = 2
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)

                elif playstateString.startswith(">>"):
                    speed = state[3].split()
                    statusicon_summary = 3
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)
                    self.pvrStateDialog["speed"].setText(speed[1])
                    speedtext = speed[1]

                elif playstateString.startswith("<<"):
                    speed = state[3].split()
                    statusicon_summary = 4
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)
                    self.pvrStateDialog["speed"].setText(speed[1])
                    speedtext = speed[1]

                elif playstateString.startswith("/"):
                    statusicon_summary = 5
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)
                    self.pvrStateDialog["speed"].setText(playstateString)

                    speedtext = playstateString

            if "state" in self and self.force_show:
                self["state"].setText(playstateString)
                self["statusicon"].setPixmapNum(statusicon_summary)
                self["speed"].setText(speedtext)

            for cb in self.onChangedEntry:
                cb(state_summary, speed_summary, statusicon_summary)

class StremioPlayer(MoviePlayer, IPTVInfoBarPVRState, SubsSupport, SubsSupportStatus, InfoBarSubtitleSupport):
    def __init__(self, session, service, current, poster, streamurl, dfposter, source, name, streamMode=False, askBeforeLeaving=False):
        log_to_file("[StremioPlayer] __init__ called. URL: %s" % streamurl)
        MoviePlayer.__init__(self, session, service)
        InfoBarSubtitleSupport.__init__(self)
        IPTVInfoBarPVRState.__init__(self, PVRState, True)
        color = config.plugins.Stremio.theme_color.value
        if getDesktop(0).size().width() >= 1900:
            self.skin = """<screen name="TransmissionVodplayer" position="0,0" size="1920,1080" backgroundColor="#ff000000" flags="wfNoBorder">
    		<!-- bottom background -->
            <eLabel backgroundGradient="#00000000,%s,#00000000,vertical" position="0,864" size="1920,216" zPosition="0" />
    		<eLabel position="0,863" size="1920,1" backgroundColor="#fffffff" zPosition="1"/>
    		<!-- picon -->
    		<widget name="cover" position="30,720" size="220,330" alphatest="blend" zPosition="4" cornerRadius="20"/>
    		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/Transmission.png" position="65,920" size="220,330" alphatest="blend" zPosition="1"/>
    		<widget name="speed" position="1368,888" size="54,48" font="Regular;36" foregroundColor="#ffffff" backgroundColor="#40000000" halign="right" valign="center" transparent="1" zPosition="3"/>
    		<widget source="session.CurrentService" render="Label" position="321,888" size="900,48" font="Bold;36" noWrap="1" foregroundColor="#ffffff" backgroundColor="#40000000" transparent="1" zPosition="3">
    			<convert type="ServiceName">Name</convert>
    		</widget>
    		<widget name="statusicon" position="1428,894" size="38,38" zPosition="5" alphatest="blend" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_play.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_pause.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_stop.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_ff.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_rw.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_slow.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_blank.png"/>
    		<!-- left divider -->
    		<eLabel position="280,894" size="1,156" backgroundColor="#fffffff" zPosition="1"/>
    		<!-- right divider -->
    		<eLabel position="1512,894" size="1,156" backgroundColor="#fffffff" zPosition="1"/>
    		<widget source="session.CurrentService" render="Progress" position="321,1002" size="1143,12" borderWidth="1" borderColor="#ffffff" foregroundColor="#57ffff" backgroundColor="#494f83" zPosition="3">
    			<convert type="TransmissionServicePosition">Position</convert>
    		</widget>
    		<widget source="session.CurrentService" render="Label" position="321,956" size="900,48" font="Regular;30" noWrap="1" foregroundColor="#ffffff" backgroundColor="#40000000" halign="left" transparent="1" zPosition="3">
    			<convert type="TransmissionServicePosition">Position,ShowHours</convert>
    		</widget>
    		<widget source="session.CurrentService" render="Label" position="1344,956" size="120,48" font="Regular;30" noWrap="1" foregroundColor="#ffffff" backgroundColor="#40000000" halign="right" transparent="1" zPosition="3">
    			<convert type="TransmissionServicePosition">Length,ShowHours</convert>
    		</widget>
    		<!-- date -->
    		<widget source="global.CurrentTime" render="Label" position="1560,888" size="318,48" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#40000000" transparent="1" zPosition="2">
    			<convert type="ClockToText">Format:%%H:%%M | %%A</convert>
    		</widget>
    		<!-- info boxes -->
    		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1560,939" size="90,36" alphatest="blend" zPosition="2"/>
    		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1656,939" size="90,36" alphatest="blend" zPosition="2"/>
    		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1752,939" size="90,36" alphatest="blend" zPosition="2"/>
    		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1560,981" size="90,36" alphatest="blend" zPosition="2"/>
    		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1656,981" size="90,36" alphatest="blend" zPosition="2"/>
    		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1752,981" size="90,36" alphatest="blend" zPosition="2"/>
    		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1560,1023" size="90,36" alphatest="blend" zPosition="2"/>
    		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1656,1023" size="90,36" alphatest="blend" zPosition="2"/>
    		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1752,1023" size="90,36" alphatest="blend" zPosition="2"/>
    		<!-- streamtype -->
    		<widget source="streamcat" render="Label" position="1560,939" size="90,36" font="Bold;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"/>
    		<!-- streamtype -->
    		<widget source="streamtype" render="Label" position="1560,981" size="90,36" font="Bold;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"/>
    		<!-- extension -->
    		<widget source="extension" render="Label" position="1560,1023" size="90,36" font="Bold;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"/>
    		<!-- resolution -->
    		<widget source="session.CurrentService" render="Label" position="1656,939" size="90,36" font="Bold;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
    			<convert type="TransmissionServiceInfo">VideoWidth</convert>
    		</widget>
    		<widget source="session.CurrentService" render="Label" position="1656,981" size="90,36" font="Bold;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
    			<convert type="TransmissionServiceInfo">VideoHeight</convert>
    		</widget>
    		<widget source="session.CurrentService" render="Label" position="1656,1023" size="90,36" font="Bold;24" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
    			<convert type="TransmissionServiceInfo">Framerate</convert>
    		</widget>
    		<!-- infos -->
    		<widget text="UHD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Bold;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
    			<convert type="TransmissionServiceInfo">IsUHD</convert>
    			<convert type="ConditionalShowHide"/>
    		</widget>
    		<widget text="FHD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Bold;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
    			<convert type="TransmissionServiceInfo">IsFHD</convert>
    			<convert type="ConditionalShowHide"/>
    		</widget>
    		<widget text="HD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Bold;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
    			<convert type="TransmissionServiceInfo">IsHD</convert>
    			<convert type="ConditionalShowHide"/>
    		</widget>
    		<widget text="SD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Bold;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
    			<convert type="TransmissionServiceInfo">IsSD</convert>
    			<convert type="ConditionalShowHide"/>
    		</widget>
    		<widget text="16:9" render="FixedLabel" source="session.CurrentService" position="1752,981" size="90,36" font="Bold;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
    			<convert type="TransmissionServiceInfo">IsWidescreen</convert>
    			<convert type="ConditionalShowHide"/>
    		</widget>
    		<widget text="4:3" render="FixedLabel" source="session.CurrentService" position="1752,981" size="90,36" font="Bold;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
    			<convert type="TransmissionServiceInfo">IsWidescreen</convert>
    			<convert type="ConditionalShowHide">Invert</convert>
    		</widget>
    		<!-- multichannel -->
    		<widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/dolby.png" position="1752,1023" size="90,36" alphatest="blend" zPosition="2">
    			<convert type="TransmissionServiceInfo">IsMultichannel</convert>
    			<convert type="ConditionalShowHide"/>
    		</widget>
    		<!-- buttons -->
    		<widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/key_audio.png" position="1848,939" size="38,38" alphatest="blend" zPosition="2">
    			<convert type="TransmissionServiceInfo">AudioTracksAvailable</convert>
    			<convert type="ConditionalShowHide"/>
    		</widget>
    		<widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/key_subs.png" position="1848,981" size="38,38" alphatest="blend" zPosition="2">
    			<convert type="TransmissionServiceInfo">SubtitlesAvailable</convert>
    			<convert type="ConditionalShowHide"/>
    		</widget>
    	</screen>""" % color
        else:
            self.skin = """<screen name="TransmissionVodplayer" position="0,0" size="1280,720" backgroundColor="#ff000000" flags="wfNoBorder">

        		<eLabel backgroundGradient="#00000000,%s,#00000000,vertical" position="0,576" size="1280,144" zPosition="0" />
        		<eLabel position="0,575" size="1280,0" backgroundColor="#fffffff" zPosition="1" />

        		<widget name="cover" scale="1" position="20,470" size="156,240" alphatest="blend" zPosition="4" cornerRadius="30" />
        		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/Transmission.png" position="23,613" size="146,220" alphatest="blend" zPosition="1" />
        		<widget name="speed" position="912,592" size="36,32" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#40000000" halign="right" valign="center" transparent="1" zPosition="3" />
        		<widget source="session.CurrentService" render="Label" position="214,592" size="600,32" font="Bold;24" noWrap="1" foregroundColor="#ffffff" backgroundColor="#40000000" transparent="1" zPosition="3">
        			<convert type="ServiceName">Name</convert>
        		</widget>
        		<widget scale="1" name="statusicon" position="952,596" size="25,25" zPosition="5" alphatest="blend" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_play.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_pause.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_stop.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_ff.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_rw.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_slow.png,/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/state_blank.png" />

        		<eLabel position="186,596" size="0,104" backgroundColor="#fffffff" zPosition="1" />

        		<eLabel position="1008,596" size="0,104" backgroundColor="#fffffff" zPosition="1" />
        		<widget source="session.CurrentService" render="Progress" position="214,668" size="762,8" borderWidth="1" borderColor="#ffffff" foregroundColor="#57ffff" backgroundColor="#494f83" zPosition="3">
        			<convert type="TransmissionServicePosition">Position</convert>
        		</widget>
        		<widget source="session.CurrentService" render="Label" position="214,637" size="600,32" font="Regular;20" noWrap="1" foregroundColor="#ffffff" backgroundColor="#40000000" halign="left" transparent="1" zPosition="3">
        			<convert type="TransmissionServicePosition">Position,ShowHours</convert>
        		</widget>
        		<widget source="session.CurrentService" render="Label" position="896,637" size="80,32" font="Regular;20" noWrap="1" foregroundColor="#ffffff" backgroundColor="#40000000" halign="right" transparent="1" zPosition="3">
        			<convert type="TransmissionServicePosition">Length,ShowHours</convert>
        		</widget>

        		<widget source="global.CurrentTime" render="Label" position="1040,592" size="212,32" font="Regular;20" foregroundColor="#ffffff" backgroundColor="#40000000" transparent="1" zPosition="2">
        			<convert type="ClockToText">Format:%%H:%%M | %%A</convert>
        		</widget>

        		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1040,626" size="60,24" alphatest="blend" zPosition="2" />
        		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1104,626" size="60,24" alphatest="blend" zPosition="2" />
        		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1168,626" size="60,24" alphatest="blend" zPosition="2" />
        		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1040,654" size="60,24" alphatest="blend" zPosition="2" />
        		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1104,654" size="60,24" alphatest="blend" zPosition="2" />
        		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1168,654" size="60,24" alphatest="blend" zPosition="2" />
        		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1040,682" size="60,24" alphatest="blend" zPosition="2" />
        		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1104,682" size="60,24" alphatest="blend" zPosition="2" />
        		<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/stream-box.png" position="1168,682" size="60,24" alphatest="blend" zPosition="2" />

        		<widget source="streamcat" render="Label" position="1040,626" size="60,24" font="Bold;18" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3" />

        		<widget source="streamtype" render="Label" position="1040,654" size="60,24" font="Bold;18" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3" />

        		<widget source="extension" render="Label" position="1040,682" size="60,24" font="Bold;18" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3" />

        		<widget source="session.CurrentService" render="Label" position="1104,626" size="60,24" font="Bold;18" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
        			<convert type="TransmissionServiceInfo">VideoWidth</convert>
        		</widget>
        		<widget source="session.CurrentService" render="Label" position="1104,654" size="60,24" font="Bold;18" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
        			<convert type="TransmissionServiceInfo">VideoHeight</convert>
        		</widget>
        		<widget source="session.CurrentService" render="Label" position="1104,682" size="60,24" font="Bold;16" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
        			<convert type="TransmissionServiceInfo">Framerate</convert>
        		</widget>

        		<widget text="UHD" render="FixedLabel" source="session.CurrentService" position="1168,626" size="60,24" font="Bold;18" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
        			<convert type="TransmissionServiceInfo">IsUHD</convert>
        			<convert type="ConditionalShowHide" />
        		</widget>
        		<widget text="FHD" render="FixedLabel" source="session.CurrentService" position="1168,626" size="60,24" font="Bold;18" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
        			<convert type="TransmissionServiceInfo">IsFHD</convert>
        			<convert type="ConditionalShowHide" />
        		</widget>
        		<widget text="HD" render="FixedLabel" source="session.CurrentService" position="1168,626" size="60,24" font="Bold;18" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
        			<convert type="TransmissionServiceInfo">IsHD</convert>
        			<convert type="ConditionalShowHide" />
        		</widget>
        		<widget text="SD" render="FixedLabel" source="session.CurrentService" position="1168,626" size="60,24" font="Bold;18" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
        			<convert type="TransmissionServiceInfo">IsSD</convert>
        			<convert type="ConditionalShowHide" />
        		</widget>
        		<widget text="16:9" render="FixedLabel" source="session.CurrentService" position="1168,654" size="60,24" font="Bold;18" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
        			<convert type="TransmissionServiceInfo">IsWidescreen</convert>
        			<convert type="ConditionalShowHide" />
        		</widget>
        		<widget text="4:3" render="FixedLabel" source="session.CurrentService" position="1168,654" size="60,24" font="Bold;18" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3">
        			<convert type="TransmissionServiceInfo">IsWidescreen</convert>
        			<convert type="ConditionalShowHide">Invert</convert>
        		</widget>

        		<widget scale="1" source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/dolby.png" position="1168,682" size="60,24" alphatest="blend" zPosition="2">
        			<convert type="TransmissionServiceInfo">IsMultichannel</convert>
        			<convert type="ConditionalShowHide" />
        		</widget>

        		<widget scale="1" source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/key_audio.png" position="1232,626" size="25,25" alphatest="blend" zPosition="2">
        			<convert type="TransmissionServiceInfo">AudioTracksAvailable</convert>
        			<convert type="ConditionalShowHide" />
        		</widget>
        		<widget  scale="1" source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/key_subs.png" position="1232,654" size="25,25" alphatest="blend" zPosition="2">
        			<convert type="TransmissionServiceInfo">SubtitlesAvailable</convert>
        			<convert type="ConditionalShowHide" />
        		</widget>
        	</screen>
        	""" % color
        self.statusicon_summary = 0
        self.current = current
        self.servicetype = str(source)
        self.streamurl = streamurl
        self.name = name
        self.streamMode = streamMode
        self.askBeforeLeaving = askBeforeLeaving
        if InfoBar.instance:
            self.servicelist = InfoBar.instance.servicelist
        else:
            self.servicelist = None
        self.filename = poster
        self.default = dfposter
        self.started = False
        self.__PlayStarted = False
        self.__VideoSizeStr = ''
        self.__Bitrate = 0
        self.lastPosition = []
        self["streamcat"] = Label("VOD")
        self["streamtype"] = Label('')
        self["extension"] = Label('')
        self["cover"] = Pixmap()
        self["eventname"] = Label('')
        self["state"] = Label('')
        self["speed"] = Label('')
        self["statusicon"] = MultiPixmap()
        self["PTSSeekBack"] = Pixmap()
        self["PTSSeekPointer"] = Pixmap()
        self.PicLoad = ePicLoad()
        self.PicLoad.PictureData.get().append(self.DecodePicture)
        self.ar_id_player = 0
        self.srt_loaded = False
        self.setup_title = "VOD"
        self["actions"] = ActionMap(
            ["TorrePlayerActions", "OkCancelActions", "ColorActions", "InfobarActions", "MoviePlayerActions"],
            {
                "cancel": self.leavePlayerOnExit,
                "stop": self.leavePlayer,
                "red": self.leavePlayer,
                "blue": self.subplayer,
                "tv": self.toggleStreamType,
                "info": self.toggleStreamType,
                "green": self.nextAR,
            },
            -2
        )

        ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evStart: self.__torrentStart,
            iPlayableService.evVideoSizeChanged: self.__torrentStart,
        })

        if Subs:
            try:
                initSubsSettings()
                SubsSupport.__init__(self, searchSupport=True, embeddedSupport=True)
                SubsSupportStatus.__init__(self)
            except Exception as e:
                print("Failed to initialize subtitle support: %s" % str(e))

        self.onLayoutFinish.append(self.__onLayoutFinish)

    def __onLayoutFinish(self):
        log_to_file("[StremioPlayer] __onLayoutFinish called. Playing stream...")
        self.playStream(self.servicetype, self.streamurl)

    def subplayer(self):
        if Subs:
            try:
                self.session.open(SubsMenu, self, embeddedSupport=True, searchSupport=True)
            except Exception as e:
                self.session.open(MessageBox, 'Error opening subtitle menu %s' % str(e), MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, 'SubsSupport Not installed ', MessageBox.TYPE_INFO)

    def __torrentStart(self):
        log_to_file("[StremioPlayer] __torrentStart called")
        try:
            self.resizeImage()
            if not self.srt_loaded:
                self.loadSRTfromTmp("/tmp")
                self.srt_loaded = True
        except Exception as e:
            log_to_file("Error resizing image: {}".format(e))
            self.loadDefaultImage()

        if not self.started:
            self.started = True
            log_to_file("[StremioPlayer] __self started set to true")
            self["streamcat"].setText("VOD")
            self["streamtype"].setText(str(self.servicetype))
            self.resizeImage()

            try:
                self["extension"].setText(str(os.path.splitext(self.streamurl)[-1]))
            except KeyError as e:
                log_to_file("Error setting extension: {}".format(e))

            try:
                self.lastPosition = ast.literal_eval(config.plugins.Stremio.lastPosition.value)
                for i in self.lastPosition:
                    if i.__contains__(self.current):
                        self.lastPosition.pop(self.lastPosition.index(i))
                        self.seekPosition = int(i.split('*')[1])
                        save_last_position(list=self.lastPosition)
                        self.session.openWithCallback(self.messageBoxCallback, MessageBox, text='Resume playback from the previous position?', timeout=5)
            except SyntaxError:
                save_last_position()
                self.lastPosition = []
            except Exception as e:
                log_to_file("Error in handling last position: {}".format(e))

    def messageBoxCallback(self, answer):
        if answer:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if seek:
                seek.seekTo(self.seekPosition)

    def leavePlayerOnExit(self):
        self.is_closing = True
        self.session.openWithCallback(self.leavePlayerOnExitCallback, MessageBox, 'Exit player?')

    def leavePlayer(self):
        on_movie_stop = config.plugins.Stremio.onMovieStop.value
        if on_movie_stop == 'ask':
            title = 'Stop playing this movie?'
            clist = (('Yes, and return to list', 'quit'),
             ('No, but play video again', 'repeat'),
             ('No', 'continue'))
            self.session.openWithCallback(self.leavePlayerConfirmed, ChoiceBox, title=title, list=clist)
        else:
            self.leavePlayerConfirmed([None, on_movie_stop])
        return

    def leavePlayerOnExitCallback(self, answer):
        if answer:
            self.leavePlayerConfirmed([None, 'exit'])
        return

    def leavePlayerConfirmed(self, answer):
        if answer and answer[1] != 'continue':
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if seek:
                if len(self.lastPosition) > 20:
                    self.lastPosition.pop(0)
                playposition = seek.getPlayPosition()[1]
                length = seek.getLength()[1]
                if length > 0:
                    percent = '%d' % ((playposition * 100 - 1) / length)
                    self.lastPosition.append('%s*%s*%s' % (self.current, str(playposition), percent))
                    save_last_position(list=self.lastPosition)
            self.close(answer)

    def doEofInternal(self, playing):
        if self.execing and playing:
            self.leavePlayerConfirmed([None, config.plugins.Stremio.onMovieEof.value])
        return

    def loadSRTfromTmp(self, path="/tmp"):
        try:
            subtitle = self.getCurrentServiceSubtitle()
            if not subtitle:
                return

            srt_files = [f for f in os.listdir(path) if f.endswith('.srt')]
            srt_files.sort()

            for srt in srt_files:
                full_path = os.path.join(path, srt)
                if hasattr(self, 'addExternalSubtitle'):
                    self.addExternalSubtitle(full_path)
                else:
                    log_to_file("addExternalSubtitle method not found on self (SubsSupport not installed?)")
        except Exception as e:
            log_to_file("loadSRTfromTmp error: %s", str(e))

    def loadDefaultImage(self, data=None):
        if self.default:
            self["cover"].instance.setPixmapFromFile(self.default)

    def resizeImage(self, data=None):
        if self["cover"].instance and self.filename:
            if self.filename.startswith("http"):
                pass

            preview = self.filename
            width = 220
            height = 330
            self.PicLoad.setPara([width, height, 1, 1, 0, 1, "FF000000"])
            if self.PicLoad.startDecode(preview):
                self.PicLoad = ePicLoad()
                self.PicLoad.PictureData.get().append(self.DecodePicture)
                self.PicLoad.setPara([width, height, 1, 1, 0, 1, "FF000000"])
                self.PicLoad.startDecode(preview)


    def DecodePicture(self, PicInfo=None):
        ptr = self.PicLoad.getData()
        if ptr is not None:
            self["cover"].instance.setPixmap(ptr)
            self["cover"].instance.show()

    def toggleStreamType(self):
        currentindex = 0
        for index, item in enumerate(vodstreamtypelist, start=0):
            if str(item) == str(self.servicetype):
                currentindex = index
                break
        nextStreamType = islice(cycle(vodstreamtypelist), currentindex + 1, None)
        try:
            self.servicetype = int(next(nextStreamType))
            message = 'Stream-Type Changed to ' + str(self.servicetype)
            self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=2)
            self.playStream(self.servicetype, self.streamurl)
        except Exception as e:
            log_to_file("toggleStreamType error: %s" % str(e))

    def playStream(self, servicetype, streamurl):
        log_to_file("[StremioPlayer] playStream called. Type: %s, URL: %s" % (servicetype, streamurl))
        current_service = self.session.nav.getCurrentService()
        if current_service:
            self.session.nav.stopService()
        self.servicetype = servicetype
        self.streamurl = streamurl
        try:
            self.reference = eServiceReference(int(self.servicetype), 0, self.streamurl)
            self.reference.setName(str(self.name))
            self.session.nav.playService(self.reference)
            self["streamcat"].setText("VOD")
            self["streamtype"].setText(str(servicetype))
            self["extension"].setText(str(os.path.splitext(self.streamurl)[-1]))
            self.resizeImage()
        except Exception as e:
            log_to_file("[StremioPlayer] Error playing stream: %s" % str(e))
            self.loadDefaultImage()

    def nextAR(self):
        self.ar_id_player += 1
        if self.ar_id_player > 6:
            self.ar_id_player = 0
        try:
            eAVSwitch.getInstance().setAspectRatio(self.ar_id_player)
            message = VIDEO_ASPECT_RATIO_MAP[self.ar_id_player]
            self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=2)
        except Exception as e:
            print(e)

class StremioTorrFiles(Screen):
    if getDesktop(0).size().width() >= 1900:
        skin = """<screen name="StremioTorrFiles" position="center,center" size="1280,720" title="Stremio Torrents Files">
        <widget name="title" position="40,30" size="1200,60" font="Regular;42" foregroundColor="#FFFFFF" transparent="1"/>
        <widget source="menu" position="40,120" size="1200,500" render="Listbox" scrollbarMode="showOnDemand" >
            <convert type="TemplatedMultiContent">{
                "templates": {"default": (48, [
                    MultiContentEntryText(pos=(10,0), size=(700,48), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                    MultiContentEntryText(pos=(820,0), size=(200,48), font=0, flags=RT_HALIGN_RIGHT|RT_VALIGN_CENTER, text=1),
                    MultiContentEntryText(pos=(1030,0), size=(150,48), font=0, flags=RT_HALIGN_RIGHT|RT_VALIGN_CENTER, text=2)
                ])},
                "fonts": [ gFont("Regular",28) ],
                "itemHeight": 48
            }</convert>
        </widget>

        <eLabel cornerRadius="30" backgroundColor="red" position="30,655" size="225,45" zPosition="1" />
        <eLabel cornerRadius="30" backgroundColor="#00000000" position="35,658" size="215,40" zPosition="2" />
        <widget name="key_red" position="40,660" size="210,40" font="Regular;26" valign="center" halign="center" foregroundColor="#FFFFFF" transparent="1" zPosition="3"/>

        <eLabel cornerRadius="30" backgroundColor="#00FF00" position="375,655" size="420,45" zPosition="1" />
        <eLabel cornerRadius="30" backgroundColor="#00000000" position="380,658" size="410,40" zPosition="2" />
        <widget name="key_green" position="380,660" size="410,40" font="Regular;26" valign="center" halign="center" zPosition="3" foregroundColor="#FFFFFF" transparent="1" />

        <eLabel cornerRadius="30" backgroundColor="yellow" position="950,655" size="225,45" zPosition="1" />
        <eLabel cornerRadius="30" backgroundColor="#00000000" position="955,658" size="215,40" zPosition="2" />
        <widget name="key_yellow" position="955,660" size="220,40" font="Regular;26" valign="center" halign="center" zPosition="3" foregroundColor="#FFFFFF" transparent="1" />
        </screen>"""
    else:
        skin = """<screen name="StremioTorrFiles" position="center,center" size="1000,600" title="Stremio Torrents Files">
        <widget name="title" position="30,20" size="940,40" font="Regular;30" foregroundColor="#FFFFFF" transparent="1"/>
        <widget source="menu" position="30,90" size="940,440" render="Listbox" scrollbarMode="showOnDemand" >
            <convert type="TemplatedMultiContent">{
                "templates": {"default": (40, [
                    MultiContentEntryText(pos=(60, 6), size=(880, 40), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                    MultiContentEntryText(pos=(820, 10), size=(95, 40), font=0, flags=RT_HALIGN_RIGHT|RT_VALIGN_CENTER, text=1),
                    MultiContentEntryText(pos=(3,6), size=(48,21), font=0, flags=RT_HALIGN_RIGHT|RT_VALIGN_CENTER, text=2)
                ])},
                "fonts": [ gFont("Regular",22) ],
                "itemHeight": 40
            }</convert>
        </widget>

        <eLabel cornerRadius="30" backgroundColor="red" position="30,545" size="225,35" zPosition="1" />
        <eLabel cornerRadius="30" backgroundColor="#00000000" position="35,548" size="215,30" zPosition="2" />

        <widget name="key_red" position="35,550" size="210,30"  valign="center" halign="center"  font="Regular;22" foregroundColor="#FFFFFF" transparent="1" zPosition="3" />

        <eLabel cornerRadius="30" backgroundColor="#00FF00" position="270,545" size="420,35" zPosition="1" />
        <eLabel cornerRadius="30" backgroundColor="#00000000" position="275,548" size="410,30" zPosition="2" />
        <widget name="key_green" position="275,550" size="410,30" valign="center" halign="center" font="Regular;22" foregroundColor="#FFFFFF" transparent="1" zPosition="3" />

        <eLabel cornerRadius="30" backgroundColor="yellow" position="750,545" size="225,35" zPosition="1" />
        <eLabel cornerRadius="30" backgroundColor="#00000000" position="755,548" size="215,30" zPosition="2" />
        <widget name="key_yellow" position="755,550" size="210,30" valign="center" halign="center"  font="Regular;22" foregroundColor="#FFFFFF" transparent="1" zPosition="3" />
        </screen>"""

    def __init__(self, session, trnt, title_txt="", poster_url=None):
        Screen.__init__(self, session)
        self.trnt = trnt
        self.ts = trnt.torrsrv
        try:
            self.files = list(trnt.files) if trnt.files is not None else []
        except Exception as e:
            log_to_file("[Stremio] Error listing files from torrent: %s" % e)
            self.files = []
        self.poster_url = poster_url or getattr(trnt, "poster", "")
        self._closed = False

        self["title"] = Label(_u8(str(title_txt) or str(trnt.title) or "Files"))
        self["menu"] = List([])

        self["key_red"] = Label(_u8("Close"))
        self["key_green"] = Label(_u8("Preload"))
        self["key_yellow"] = Label(_u8("Play"))

        self.preload_timer = eTimer()
        _connect_timer(self.preload_timer, self._animate_preload_tick)
        self.preload_dots = 0

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.close,
            "red": self.close,
            "ok": self._play_selected,
            "yellow": self._play_selected,
            "green": self._preload_selected,
        }, -1)

        self._fill()

    def _is_sample_name(self, path):
        name = _u8(path).lower()
        patterns = [
            r"\bsample\b", r"\btrailer\b", r"\bextra(s)?\b", r"\bfeaturette\b",
            r"\bpreview\b", r"\bclip\b", r"\bteaser\b", r"\bshort\b"
        ]
        for p in patterns:
            try:
                if re.search(p, name): return True
            except: pass
        return False

    def _has_quality_hint(self, path):
        name = _u8(path).lower()
        hints = ["2160p","4k","1080p","720p","webrip","web-dl","bluray","bdrip","remux","hdr","dv","x265","hevc","x264"]
        return any(h in name for h in hints)

    def _score_file(self, f, max_len):
        try:
            size = int(getattr(f, "length", 0) or 0)
            score = float(size)
            too_small_cut = max(200 * 1024 * 1024, int(0.10 * (max_len or 0)))
            if size < too_small_cut: score *= 0.05
            path_str = _u8(getattr(f, "path", ""))
            if self._is_sample_name(path_str): score *= 0.01
            if self._has_quality_hint(path_str): score *= 1.10
            return score
        except Exception:
            return 0.0

    def _fill(self):
        try:
            max_len = max(int(getattr(f, "length", 0) or 0) for f in self.files) if self.files else 0
        except:
            max_len = 0

        log_to_file("[Stremio] Filling file list. Total files: %d" % len(self.files))

        try:
            lastPosition = ast.literal_eval(config.plugins.Stremio.lastPosition.value)
        except:
            lastPosition = []

        try:
            ranked = sorted(self.files, key=lambda f: (self._score_file(f, max_len), _u8(getattr(f, "path", ""))), reverse=True)
        except Exception as e:
            log_to_file("[Stremio] Error sorting files: %s" % e)
            ranked = self.files

        rows = []
        for f in ranked:
            try:
                path_str = _u8(getattr(f, "path", ""))
                name = path_str.split("/")[-1] if path_str else "file"
                size = self._pretty(getattr(f, "length", 0))

                progress_pct = ""
                try:
                    info = self.ts.get_stream_url(self.trnt, f.id)
                    url = info.get("stream")
                    if url:
                        if sys.version_info[0] < 3 and isinstance(url, unicode):
                            url = url.encode("utf-8")

                        for entry in lastPosition:
                            if entry.startswith(str(url) + "*"):
                                parts = entry.split("*")
                                if len(parts) >= 3:
                                    progress_pct = parts[2] + "%"
                                break
                except Exception as e:
                    print("Error checking progress for file %s: %s" % (name, e))

                rows.append((_u8(name), _u8(size), _u8(progress_pct), f.id))
            except Exception as e:
                log_to_file("[Stremio] Error processing file row: %s" % e)

        log_to_file("[Stremio] Generated %d rows for display" % len(rows))
        self._rows = rows
        self["menu"].setList([(r[0], r[1], r[2]) for r in rows])
        try:
            if hasattr(self["menu"], "moveToIndex") and rows:
                self["menu"].moveToIndex(0)
        except: pass

    def _pretty(self, n):
        try:
            n = int(n)
            for unit in ["B","KB","MB","GB","TB"]:
                if n < 1024: return "%.2f %s" % (n, unit)
                n /= 1024.0
        except: pass
        return "0 B"

    def _current_row(self):
        idx = self["menu"].getSelectedIndex()
        if idx is not None and 0 <= idx < len(self._rows):
            return self._rows[idx]
        return None, None, None, None

    def _play_selected(self):
        row = self._current_row()
        if not row: return
        name, _size, _pct, fid = row
        fobj = None
        for f in self.files:
            if f.id == fid: fobj = f; break
        if fobj and self._is_sample_name(getattr(fobj, "path", "")):
            if self._rows:
                best_row = self._rows[0]
                best_name, _best_size, _best_pct, best_fid = best_row
                def _cb(ch):
                    if ch and ch[1] == "best": self._play_by_id(best_fid)
                    elif ch and ch[1] == "sel": self._play_by_id(fid)
            self.session.openWithCallback(_cb, ChoiceBox,
                title=_u8("This looks like a sample. Play the main file instead?"),
                list=[(_u8("Yes, play main file (%s)" % best_name), "best"),
                      (_u8("No, play selected anyway"), "sel")]
            )
            return
        self._play_by_id(fid)

    def _preload_selected(self):
        row = self._current_row()
        if not row: return
        if len(row) == 4:
            _name, _size, _pct, fid = row
        else:
            _name, _size, fid = row

        if not fid: return

        self.preload_dots = 0
        self.preload_timer.start(500, False)
        self["key_green"].setText(_u8("Preloading buffer"))

        def _preload():
            return self.ts.preload_torrent(self.trnt, fid, wait_time=10)

        def _done(_res):
            if self._closed:
                return
            try:
                self.preload_timer.stop()
                self["key_green"].setText(_u8("Preload"))
            except Exception:
                pass

        def _err(f):
            if self._closed:
                return
            try:
                self.preload_timer.stop()
                self["key_green"].setText(_u8("Preload"))
                self.session.open(MessageBox, "Preload failed.", MessageBox.TYPE_ERROR)
            except Exception:
                pass

        d = threads.deferToThread(_preload)
        d.addCallback(lambda r: reactor.callFromThread(_done, r))
        d.addErrback(lambda f: reactor.callFromThread(_err, f))

    def _animate_preload_tick(self):
        self.preload_dots = (self.preload_dots + 1) % 4
        dots = "." * self.preload_dots
        self["key_green"].setText(_u8("Preloading buffer" + dots))

    def close(self, *args, **kwargs):
        self._closed = True
        try:
            self.preload_timer.stop()
        except: pass
        Screen.close(self, *args, **kwargs)

    def _play_by_id(self, file_id):
        try:
            info = self.ts.get_stream_url(self.trnt, file_id)
            url = info.get("stream")
            if not url:
                if not self._closed:
                    self.session.open(MessageBox, "Failed to get stream URL.", MessageBox.TYPE_ERROR)
                return

            if sys.version_info[0] < 3 and isinstance(url, unicode):
                url = url.encode("utf-8")

            disp = (info.get("file") or "").split("/")[-1] or (self.trnt.title or "Video")
            ref = eServiceReference(4097, 0, str(url))
            ref.setName(_u8(disp))
            poster = self.poster_url
            if not self._closed:
                self.session.open(StremioPlayer, ref, str(url), poster, str(url), poster, 4097, disp, streamMode=True, askBeforeLeaving=True)
        except Exception as e:
            if not self._closed:
                self.session.open(MessageBox, "Play error: %s" % e, MessageBox.TYPE_ERROR)

    def _pretty(self, n):
        try:
            n = float(int(n or 0))
            for unit in ["B","KB","MB","GB","TB","PB"]:
                if n < 1024.0: return "%3.1f %s" % (n, unit)
                n /= 1024.0
            return "%3.1f EB" % n
        except:
            return "—"

    def _current_row(self):
        idx = 0
        try: idx = self["menu"].getCurrentIndex()
        except: pass
        if idx < 0 or idx >= len(self._rows): idx = 0
        return self._rows[idx]

    def _play_selected(self):
        row = self._current_row()
        if not row: return
        if len(row) == 4:
            name, _size, _pct, fid = row
        else:
            name, _size, fid = row

        fobj = None
        for f in self.files:
            if f.id == fid:
                fobj = f; break
        if fobj and self._is_sample_name(getattr(fobj, "path", "")) and self._rows:
            best_row = self._rows[0]
            if len(best_row) == 4:
                best_name, _best_size, _best_pct, best_fid = best_row
            else:
                best_name, _best_size, best_fid = best_row

            def _cb(ch):
                if ch and ch[1] == "best": self._play_by_id(best_fid)
                elif ch and ch[1] == "sel": self._play_by_id(fid)
            self.session.openWithCallback(_cb, ChoiceBox,
                title=_u8("This looks like a sample. Play the main file instead?"),
                list=[(_u8("Yes, play main file (%s)" % best_name), "best"),
                      (_u8("No, play selected anyway"), "sel")]
            )
            return
        self._play_by_id(fid)


class StremioSettings(ConfigListScreen, Screen):
    skin = """
    <screen name="StremioSettings" position="center,center" size="1200,550" title="Stremio Settings">
        <widget name="config" itemHeight="60" position="20,20" size="860,440" scrollbarMode="showOnDemand"/>
        <widget name="status" position="880,20" size="320,440" valign="center" halign="center" font="Regular;20" foregroundColor="#AAAAAA" transparent="1"/>
        <eLabel cornerRadius="30" backgroundColor="#00FF00" position="10,490" size="215,55" zPosition="1" />
        <eLabel cornerRadius="30" backgroundColor="#00000000" position="15,495" size="205,45" zPosition="2" />
        <eLabel position="20,500" size="200,40" text="Save" valign="center" halign="center" font="Regular;20" foregroundColor="#00FF00" transparent="1" zPosition="3" />
        <eLabel cornerRadius="30" backgroundColor="#0000FF" position="240,490" size="215,55" zPosition="1" />
        <eLabel cornerRadius="30" backgroundColor="#00000000" position="245,495" size="205,45" zPosition="2" />
        <eLabel position="250,500" size="200,40" text="Trakt Login" valign="center" halign="center" font="Regular;20" foregroundColor="#0000FF" transparent="1" zPosition="3" />
        <eLabel cornerRadius="30" backgroundColor="#FFFF00" position="470,490" size="215,55" zPosition="1" />
        <eLabel cornerRadius="30" backgroundColor="#00000000" position="475,495" size="205,45" zPosition="2" />
        <eLabel position="480,500" size="200,40" text="Stremio Login" valign="center" halign="center" font="Regular;20" foregroundColor="#FFFF00" transparent="1" zPosition="3" />
    </screen>
    """

    def __init__(self, session):
        load_settings_from_json()
        Screen.__init__(self, session)
        self["status"] = Label("Config: %s" % LOADED_CONFIG_PATH)
        clist = [
            getConfigListEntry("TorrServer URL",             config.plugins.Stremio.torrserver_url),
            getConfigListEntry("Enable Subtitles",           config.plugins.Stremio.subtitles_enabled),
            getConfigListEntry("Subtitle Language (ISO)",    config.plugins.Stremio.subtitle_lang),
            getConfigListEntry("OpenSubtitles API Key",      config.plugins.Stremio.os_api_key),

            getConfigListEntry("Addon URL",                  config.plugins.Stremio.addon_base_url),

            getConfigListEntry("Play Mode",                  config.plugins.Stremio.play_mode),
            getConfigListEntry("Theme Color",                config.plugins.Stremio.theme_color),
            getConfigListEntry("Enable Show Cast/Director",  config.plugins.Stremio.show_cast),

            getConfigListEntry("Preferred Quality",          config.plugins.Stremio.quality_pref),
            getConfigListEntry("Startup Category",           config.plugins.Stremio.startup_category),
            getConfigListEntry("Hero Slideshow (ms)",        config.plugins.Stremio.hero_interval_ms),

            getConfigListEntry("TMDB: Enable",               config.plugins.Stremio.tmdb_enabled),
            getConfigListEntry("TMDB: API Key",              config.plugins.Stremio.tmdb_api_key),
            getConfigListEntry("TMDB: Language",             config.plugins.Stremio.tmdb_language),

            getConfigListEntry("Trakt: Enable",              config.plugins.Stremio.trakt_enabled),
            getConfigListEntry("Trakt: Client ID",           config.plugins.Stremio.trakt_client_id),
            getConfigListEntry("Trakt: Access Token",        config.plugins.Stremio.trakt_token),

            getConfigListEntry("Debrid Provider",            config.plugins.Stremio.debrid_provider),
            getConfigListEntry("Debrid Token",               config.plugins.Stremio.debrid_token),

            getConfigListEntry("Stremio Email",              config.plugins.Stremio.email),
            getConfigListEntry("Stremio Password",           config.plugins.Stremio.password),

            getConfigListEntry("YouTube: use yt-dlp",        config.plugins.Stremio.ytdlp_enabled),
        ]
        ConfigListScreen.__init__(self, clist, session)

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.save,
            "green": self.save,
            "blue": self.loginTrakt,
            "yellow": self.loginStremio,
        }, -1)

    def loginStremio(self):
        email = config.plugins.Stremio.email.value
        password = config.plugins.Stremio.password.value
        if not email or not password:
            self.session.open(MessageBox, "Please enter Email and Password first.", MessageBox.TYPE_ERROR)
            return

        success, msg = stremio_login(email, password)
        if success:
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO)
            self["status"].setText("Logged in: " + email)
        else:
            self.session.open(MessageBox, msg, MessageBox.TYPE_ERROR)

    def loginTrakt(self):
        self.session.open(StremioTraktLogin)

    def save(self):
        for x in self["config"].list:
            try: x[1].save()
            except: pass
        try:
            for k in ["TMDB (Movies)","TMDB (Series)","My Trakt", "My Stremio Library"]:
                if k in CATEGORIES: del CATEGORIES[k]
            _extend_virtual_categories()
        except: pass
        self.close()

class StremioTraktLogin(Screen):
    skin = """<screen name="StremioTraktLogin" position="center,center" size="800,400" title="Login with Trakt">
        <widget name="info" position="20,20" size="760,100" font="Regular;28" halign="center" valign="center" transparent="1" />
        <widget name="code" position="20,140" size="760,80" font="Regular;60" halign="center" valign="center" foregroundColor="#00FFAA" transparent="1" />
        <widget name="status" position="20,250" size="760,50" font="Regular;24" halign="center" valign="center" foregroundColor="#AAAAAA" transparent="1" />
        <eLabel cornerRadius="30" backgroundColor="red" position="10,340" size="215,55" zPosition="1" />
        <eLabel cornerRadius="30" backgroundColor="#00000000" position="15,345" size="205,45" zPosition="2" />
        <widget name="key_red" position="20,350" size="200,40" font="Regular;22"  halign="center" valign="center" transparent="1" zPosition="3" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self["info"] = Label(_u8("Please visit: https://trakt.tv/activate\nAnd enter the code below:"))
        self["code"] = Label(_u8("Loading..."))
        self["status"] = Label(_u8("Waiting for code..."))
        self["key_red"] = Label(_u8("Cancel"))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.close,
            "red": self.close,
        }, -1)

        self.device_code = None
        self.interval = 5
        self.poll_timer = eTimer()
        _connect_timer(self.poll_timer, self._poll)

        self.onLayoutFinish.append(self._start_auth)

    def _start_auth(self):
        client_id = config.plugins.Stremio.trakt_client_id.value
        if not client_id:
            self["status"].setText(_u8("Error: Client ID missing in settings"))
            return

        def _req():
            url = "https://api.trakt.tv/oauth/device/code"
            data = {"client_id": client_id}
            return http_post(url, data)

        def _got(res):
            if not res or "user_code" not in res:
                self["status"].setText(_u8("Error fetching code"))
                return

            self.device_code = res["device_code"]
            self.interval = res.get("interval", 5)
            self["code"].setText(_u8(res["user_code"]))
            self["status"].setText(_u8("Waiting for activation..."))

            self.poll_timer.start(self.interval * 1000, False)

        threads.deferToThread(_req).addCallback(lambda r: reactor.callFromThread(_got, r))

    def _poll(self):
        if not self.device_code: return

        client_id = config.plugins.Stremio.trakt_client_id.value
        client_secret = config.plugins.Stremio.trakt_client_secret.value

        def _req():
            url = "https://api.trakt.tv/oauth/device/token"
            data = {
                "code": self.device_code,
                "client_id": client_id,
                "client_secret": client_secret
            }
            return http_post(url, data)

        def _got(res):
            if not res: return # Network error?

            if "access_token" in res:
                token = res["access_token"]
                config.plugins.Stremio.trakt_token.value = token
                config.plugins.Stremio.trakt_token.save()
                config.plugins.Stremio.trakt_enabled.value = True
                config.plugins.Stremio.trakt_enabled.save()

                self.poll_timer.stop()
                self.session.open(MessageBox, "Trakt Login Successful!", MessageBox.TYPE_INFO)
                self.close()
            elif "error" in res:
                err = res["error"]
                if err == "slow_down":
                    self.interval += 5
                    self.poll_timer.start(self.interval * 1000, False)
                elif err == "expired_token":
                    self["status"].setText(_u8("Code expired. Please reopen."))
                    self.poll_timer.stop()

        threads.deferToThread(_req).addCallback(lambda r: reactor.callFromThread(_got, r))

# --- Provider System ---

class Provider(object):
    def __init__(self):
        self.base_url = ""
        self.name = "Unknown"

    def get_stream_url(self, typ, imdb, season=None, episode=None):
        return ""

    def parse_streams(self, data, title, year, season=None, episode=None):
        return []

    def _format_size(self, size):
        try:
            size = float(size)
            for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
                if size < 1024:
                    return "%.2f %s" % (size, unit)
                size /= 1024
            return "%.2f PB" % size
        except: return "0 B"

class TorrentioProvider(Provider):
    def __init__(self):
        self.name = "Torrentio"
        # Base URL is dynamic from config, but we can default it purely for class structure
        self.base_url = "https://torrentio.strem.fun"

    def get_stream_url(self, typ, imdb, season=None, episode=None):
        # Allow overriding base via config passed or global
        base = (config.plugins.Stremio.addon_base_url.value or self.base_url).rstrip("/")
        if typ == "movie":
            return "%s/stream/movie/%s.json" % (base, imdb)
        elif typ == "series":
            return "%s/stream/series/%s:%s:%s.json" % (base, imdb, season, episode)
        return ""

    def parse_streams(self, data, title, year, season=None, episode=None):
        streams = data.get("streams", [])
        return streams # Torrentio format is native Stremio format

class CometProvider(Provider):
    def __init__(self):
        self.name = "Comet"
        self.base_url = "https://comet.stremio.ru"

    def get_stream_url(self, typ, imdb, season=None, episode=None):
        base = (config.plugins.Stremio.addon_base_url.value or self.base_url).rstrip("/")
        # Comet needs token sometimes, but let's assume URL config has it full
        if typ == "movie":
            return "%s/stream/movie/%s.json" % (base, imdb)
        elif typ == "series":
            return "%s/stream/series/%s:%s:%s.json" % (base, imdb, season, episode)
        return ""

    def parse_streams(self, data, title, year, season=None, episode=None):
        streams = data.get("streams", [])
        for s in streams:
            bh = s.get("behaviorHints", {})
            if "bingeGroup" in bh and "infoHash" not in s:
                 s["infoHash"] = bh["bingeGroup"].replace("comet|", "")
            if "filename" in bh and "title" not in s:
                 s["title"] = bh["filename"]
        return streams

class MediaFusionProvider(Provider):
    def __init__(self):
        self.name = "MediaFusion"
        self.base_url = "https://mediafusion.elfhosted.com"

    def get_stream_url(self, typ, imdb, season=None, episode=None):
        base = (config.plugins.Stremio.addon_base_url.value or self.base_url).rstrip("/")
        if typ == "movie":
            return "%s/stream/movie/%s.json" % (base, imdb)
        elif typ == "series":
            return "%s/stream/series/%s:%s:%s.json" % (base, imdb, season, episode)
        return ""

    def parse_streams(self, data, title, year, season=None, episode=None):
        streams = data.get("streams", [])
        import re
        for s in streams:
            url = s.get("url", "")
            if "/playback/" in url and "infoHash" not in s:
                m = re.search(r'/playback/([^/]+)', url)
                if m: s["infoHash"] = m.group(1)
        return streams

class StremThruProvider(Provider):
    def __init__(self):
        self.name = "StremThru"
        self.base_url = "https://stremthru.13377001.xyz"

    def get_stream_url(self, typ, imdb, season=None, episode=None):
        base = (config.plugins.Stremio.addon_base_url.value or self.base_url).rstrip("/")
        if typ == "movie":
            return "%s/stream/movie/%s.json" % (base, imdb)
        elif typ == "series":
            return "%s/stream/series/%s:%s:%s.json" % (base, imdb, season, episode)
        return ""

    def parse_streams(self, data, title, year, season=None, episode=None):
        return data.get("streams", [])

class TorBoxProvider(Provider):
    def __init__(self):
        self.name = "TorBox"
        self.base_url = "https://stremio.torbox.app"

    def get_stream_url(self, typ, imdb, season=None, episode=None):
        base = (config.plugins.Stremio.addon_base_url.value or self.base_url).rstrip("/")
        if typ == "movie":
            return "%s/stream/movie/%s.json" % (base, imdb)
        elif typ == "series":
            return "%s/stream/series/%s:%s:%s.json" % (base, imdb, season, episode)
        return ""

    def parse_streams(self, data, title, year, season=None, episode=None):
        return data.get("streams", [])

class AIOStreamsProvider(Provider):
    def __init__(self):
        self.name = "AIOStreams"
        self.base_url = "https://aiostreamsfortheweebsstable.midnightignite.me"

    def get_stream_url(self, typ, imdb, season=None, episode=None):
        base = (config.plugins.Stremio.addon_base_url.value or self.base_url).rstrip("/")
        if typ == "movie":
            return "%s/stream/movie/%s.json" % (base, imdb)
        elif typ == "series":
            return "%s/stream/series/%s:%s:%s.json" % (base, imdb, season, episode)
        return ""

    def parse_streams(self, data, title, year, season=None, episode=None):
        return data.get("streams", [])

class EasyNewsProvider(Provider):
    def __init__(self):
        self.name = "EasyNews"
        self.base_url = "https://easynews.io" # Placeholder if needed

    def get_stream_url(self, typ, imdb, season=None, episode=None):
        base = (config.plugins.Stremio.addon_base_url.value or self.base_url).rstrip("/")
        if typ == "movie":
            return "%s/stream/movie/%s.json" % (base, imdb)
        elif typ == "series":
            return "%s/stream/series/%s:%s:%s.json" % (base, imdb, season, episode)
        return ""

    def parse_streams(self, data, title, year, season=None, episode=None):
        return data.get("streams", [])
