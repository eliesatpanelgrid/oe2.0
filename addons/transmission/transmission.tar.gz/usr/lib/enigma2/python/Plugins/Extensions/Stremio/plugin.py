# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from .screens import StremioMain, StremioSettings
from Screens.MessageBox import MessageBox
from Components.config import config, ConfigSubsection, ConfigText, ConfigYesNo


# Config (editable in Settings screen)
config.plugins.stremiolike = ConfigSubsection()
config.plugins.stremiolike.torrserver_url = ConfigText(default="http://127.0.0.1:8090")
config.plugins.stremiolike.subtitles_enabled = ConfigYesNo(default=True)
config.plugins.stremiolike.subtitle_lang = ConfigText(default="eng")     # eng, ara, fre, nld, deu, ...
config.plugins.stremiolike.os_api_key = ConfigText(default="")           # OpenSubtitles API Key
config.plugins.stremiolike.os_token = ConfigText(default="")             # Optional: OpenSubtitles OAuth token

def main(session, **kwargs):
    session.open(StremioMain)

def settings(session, **kwargs):
    session.open(StremioSettings)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Stremio",
            icon="stremio.png",
            description="Stremio styled Dreambox UI",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main
        ),
        PluginDescriptor(
            name="Stremio Settings",
            description="Configure TorrServer & Subtitles",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=settings
        ),
    ]
