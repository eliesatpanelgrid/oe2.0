#!/usr/bin/python
# -*- coding: utf-8 -*-
import requests, base64
from bs4 import BeautifulSoup
import json, urllib, os, logging
from urllib.parse import quote_plus
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from . import _
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class SubtitleProvider(object):

    def __init__(self, preferred_language='english'):
        self.providers = {'yts': self.get_yts_subs,
           'opensubtitles': self.get_opensubtitles_subs,
           'subscene': self.get_subscene_subs,
           'subdl': self.get_subdl_subs}
        self.preferred_language = preferred_language.lower()
        self.fallback_language = 'english'
        self.logger = logging.getLogger('SubtitleProvider')
        self.logger.setLevel(logging.DEBUG)
        handler = logging.FileHandler('/tmp/SubtitleProvider.log')
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'}
        self.logger.info('Initialized SubtitleProvider with language: %s' % self.preferred_language)

    def get_movie_data(self, imdb_id, api_key=None, provider='yts'):
        """Get movie data from specified provider with language filtering"""
        self.logger.debug('Getting data from provider: %s for IMDb: %s' % (provider, imdb_id))
        if provider not in self.providers:
            self.logger.error('Invalid provider specified: %s' % provider)
            raise ValueError('Invalid provider. Choose from: %s' % (', ').join(self.providers.keys()))

        try:
            if provider == 'subdl':
                result = self.providers[provider](imdb_id, api_key)
            else:
                result = self.providers[provider](imdb_id)
            filtered_subs = []
            for sub in result.get('subtitles', []):
                sub_lang = sub.get('language', '').lower()
                if sub_lang == self.preferred_language:
                    filtered_subs.append(sub)
                elif sub_lang == self.fallback_language and self.preferred_language != self.fallback_language:
                    sub['is_fallback'] = True
                    filtered_subs.append(sub)

            result['subtitles'] = filtered_subs
            result['language_preference'] = self.preferred_language
            result['used_fallback'] = any(sub.get('is_fallback', False) for sub in filtered_subs)
            self.logger.debug('Found %d subtitles after filtering' % len(filtered_subs))
            return result
        except Exception as e:
            self.logger.error('Failed to get data from %s: %s' % (provider, str(e)))
            return {'title': _('Unknown'),
               'year': _('Unknown'),
               'rating': _('Unknown'),
               'genres': [], 'description': _('No description available'),
               'subtitles': [], 'provider': provider,
               'language_preference': self.preferred_language,
               'error': str(e)}

    def get_yts_subs(self, imdb_id):
        """Fetch subtitles from YTS"""
        url = 'https://yts-subs.com/movie-imdb/' + str(imdb_id)
        self.logger.debug('Fetching YTS data from: %s' % url)
        try:
            response = requests.get(url, verify=False, headers=self.headers, timeout=30)
            response.raise_for_status()
            soup = BeautifulSoup(response.content, 'html.parser')
            title = soup.find('h2', class_='movie-main-title').text.strip() if soup.find('h2', class_='movie-main-title') else _('Unknown Title')
            year = soup.find('div', id='circle-score-year').get('data-text', '').strip() if soup.find('div', id='circle-score-year') else _('Unknown Year')
            rating = soup.find('div', id='circle-score-imdb').get('data-text', '').strip() if soup.find('div', id='circle-score-imdb') else _('Unknown Rating')
            genres = [ g.strip() for g in soup.find('div', class_='movie-genre').text.split(',') ] if soup.find('div', class_='movie-genre') else []
            description = soup.find('div', class_='movie-desc').text.strip() if soup.find('div', class_='movie-desc') else _('No Description')
            subtitles = []
            for row in soup.find_all('tr', class_='high-rating'):
                try:
                    language = row.find('span', class_='sub-lang').text.strip().lower()
                    if language not in [self.preferred_language, self.fallback_language]:
                        continue
                    title_part = row.find('a', class_='subtitle-download').text.strip()
                    rel_url = row.find('a', class_='subtitle-download')['href']
                    subtitle_download_link = 'https://yts-subs.com' + rel_url
                    response_sub = requests.get(subtitle_download_link, verify=False, headers=self.headers, timeout=30)
                    soup_sub = BeautifulSoup(response_sub.content, 'html.parser')
                    dl_link = soup_sub.find('a', id='btn-download-subtitle').get('data-link', None)
                    if dl_link:
                        dl_url = base64.b64decode(dl_link).decode('utf-8', 'ignore')
                        subtitles.append({
                            'language': language,
                            'title': title_part,
                            'url': dl_url,  # Now a string
                            'provider': 'yts'
                        })
                except Exception as e:
                    self.logger.warning('Error processing YTS subtitle row: %s' % str(e))

            return {'title': title, 'year': year,
               'rating': rating,
               'genres': genres,
               'description': description,
               'subtitles': subtitles,
               'provider': 'yts'}
        except Exception as e:
            self.logger.error('YTS processing failed: %s' % str(e))
            raise

        return

    def get_opensubtitles_subs(self, imdb_id):
        """Fetch subtitles from OpenSubtitles"""
        url = 'https://www.opensubtitles.org/en/search/imdbid-%s/sublanguageid-all' % imdb_id
        self.logger.debug('Fetching OpenSubtitles data from: %s' % url)
        try:
            headers = self.headers.copy()
            headers.update({'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
               'Accept-Language': 'en-US,en;q=0.5',
               'Referer': 'https://www.opensubtitles.org/'})
            response = requests.get(url, verify=False, headers=headers, timeout=30)
            response.raise_for_status()
            soup = BeautifulSoup(response.content, 'html.parser')
            title_tag = soup.find('h1', {'class': 'text-white'})
            title = title_tag.text.replace('Subtitles for', '').strip() if title_tag else _('Unknown Title')
            subtitles = []
            table = soup.find('tbody', {'id': 'search_results'})
            if table:
                for row in table.find_all('tr'):
                    try:
                        lang_td = row.find('td', {'class': 'flag-cell'})
                        if not lang_td:
                            continue
                        lang_span = lang_td.find('span', {'class': 'flag'})
                        lang_name = lang_span.get('title', '').lower() if lang_span else ''
                        if lang_name not in [self.preferred_language, self.fallback_language]:
                            continue
                        link_a = row.find('td', {'class': 'actions-cell'}).find('a', {'href': lambda x: x and '/subtitles/' in x})
                        if not link_a:
                            continue
                        subtitle_link = 'https://www.opensubtitles.org' + link_a['href']
                        sub_title = link_a.text.strip()
                        response_sub = requests.get(subtitle_link, verify=False, headers=headers, timeout=30)
                        soup_sub = BeautifulSoup(response_sub.content, 'html.parser')
                        download_link = soup_sub.find('a', {'id': 'bt-dwl-bt'})
                        if download_link:
                            download_url = download_link.get('href', '')
                            if download_url.startswith('/'):
                                download_url = 'https://www.opensubtitles.org' + download_url
                            subtitles.append({'language': lang_name,
                               'title': sub_title,
                               'url': download_url,
                               'provider': 'opensubtitles'})
                    except Exception as e:
                        self.logger.warning('Error processing OpenSubtitles row: %s' % str(e))

            return {'title': title,
               'year': _('Unknown'),
               'rating': _('Unknown'),
               'genres': [], 'description': _('No description available'),
               'subtitles': subtitles,
               'provider': 'opensubtitles'}
        except Exception as e:
            self.logger.error('OpenSubtitles processing failed: %s' % str(e))
            raise

    def get_subscene_subs(self, imdb_id):
        """Fetch subtitles from Subscene"""
        self.logger.debug('Starting Subscene search for IMDb: %s' % imdb_id)
        try:
            yts_data = self.get_yts_subs(imdb_id)
            search_query = yts_data['title']
            url = 'https://subscene.com/subtitles/searchbytitle?query=%s' % quote_plus(search_query)
            self.logger.debug('Fetching Subscene search page: %s' % url)
            headers = self.headers.copy()
            headers.update({'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
               'Accept-Language': 'en-US,en;q=0.5',
               'Referer': 'https://subscene.com/'})
            session = requests.Session()
            response = session.get(url, verify=False, headers=headers, timeout=30)
            if response.status_code == 403:
                self.logger.warning('Subscene blocked request, trying with different headers')
                headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                   'Accept-Encoding': 'gzip, deflate, br'})
                response = session.get(url, verify=False, headers=headers, timeout=30)
            if response.status_code != 200:
                raise Exception('Failed to access Subscene, status: %d' % response.status_code)
            soup = BeautifulSoup(response.content, 'html.parser')
            movie_link = None
            for li in soup.find_all('div', {'class': 'title'}):
                a_tag = li.find('a')
                if a_tag and imdb_id in a_tag.get('href', ''):
                    movie_link = 'https://subscene.com' + a_tag['href']
                    break

            if not movie_link:
                raise Exception('No matching movie found on Subscene')
            response = session.get(movie_link, verify=False, headers=headers, timeout=30)
            soup = BeautifulSoup(response.content, 'html.parser')
            subtitles = []
            for row in soup.find_all('tr'):
                try:
                    td_a1 = row.find('td', {'class': 'a1'})
                    if not td_a1:
                        continue
                    lang_span = td_a1.find('span', {'class': None})
                    link_a = td_a1.find('a')
                    if not lang_span or not link_a:
                        continue
                    lang_name = lang_span.text.strip().lower()
                    if lang_name not in [self.preferred_language, self.fallback_language]:
                        continue
                    subtitle_link = 'https://subscene.com' + link_a['href']
                    sub_title = link_a.text.strip()
                    response_sub = session.get(subtitle_link, verify=False, headers=headers, timeout=30)
                    soup_sub = BeautifulSoup(response_sub.content, 'html.parser')
                    download_link = soup_sub.find('a', {'id': 'downloadButton'})
                    if download_link:
                        download_url = download_link.get('href', '')
                        if download_url.startswith('/'):
                            download_url = 'https://subscene.com' + download_url
                        subtitles.append({'language': lang_name,
                           'title': sub_title,
                           'url': download_url,
                           'provider': 'subscene'})
                except Exception as e:
                    self.logger.warning('Error processing Subscene row: %s' % str(e))

            return {'title': yts_data['title'], 'year': yts_data['year'],
               'rating': yts_data['rating'],
               'genres': yts_data['genres'],
               'description': yts_data['description'],
               'subtitles': subtitles,
               'provider': 'subscene'}
        except Exception as e:
            self.logger.error('Subscene processing failed: %s' % str(e))
            raise

        return

    def get_subdl_subs(self, imdb_id, api_key):
        """Fetch subtitles from SubDL API"""
        self.logger.debug('Starting SubDL search for IMDb: %s' % imdb_id)
        try:
            yts_data = self.get_yts_subs(imdb_id)
            search_query = yts_data['title']
            params = {'api_key': api_key,
               'imdb_id': imdb_id,
               'film_name': search_query,
               'type': 'movie',
               'languages': 'ar,en',
               'subs_per_page': 30,
               'year': yts_data.get('year', '')}
            response = requests.get('https://api.subdl.com/api/v1/subtitles', params=params, verify=False, headers=self.headers, timeout=30)
            response.raise_for_status()
            json_data = json.loads(response.text)
            subtitles = []
            if json_data.get('status'):
                lang_map = {'ar': 'arabic', 'en': 'english'}
                for item in json_data.get('subtitles', []):
                    try:
                        language = item.get('lang', '').lower()
                        lang_name = lang_map.get(language, language)
                        if lang_name in [self.preferred_language, self.fallback_language]:
                            subtitles.append({'language': lang_name,
                               'title': item.get('release_name', ''),
                               'url': 'https://dl.subdl.com' + item.get('url', ''),
                               'provider': 'subdl'})
                    except Exception as e:
                        self.logger.warning('Error processing SubDL item: %s' % str(e))

            return {'title': yts_data['title'],
               'year': yts_data['year'],
               'rating': yts_data['rating'],
               'genres': yts_data['genres'],
               'description': yts_data['description'],
               'subtitles': subtitles,
               'provider': 'subdl'}
        except Exception as e:
            self.logger.error('SubDL processing failed: %s' % str(e))
            raise

    def save_to_json(self, data, filename):
        """Atomic JSON save with validation"""
        try:
            dirname = os.path.dirname(filename)
            os.makedirs(dirname, exist_ok=True)

            # Validate data serialization first
            try:
                json.dumps(data, ensure_ascii=False)
            except TypeError as e:
                self.logger.error("Non-serializable data: %s", str(e))
                return False

            # Use temporary file for atomic write
            temp_path = filename + '.tmp'
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

            # Atomic replace
            os.replace(temp_path, filename)
            return True
        except Exception as e:
            self.logger.error("Save failed: %s", str(e))
            if os.path.exists(temp_path):
                try: os.remove(temp_path)
                except: pass
            return False
