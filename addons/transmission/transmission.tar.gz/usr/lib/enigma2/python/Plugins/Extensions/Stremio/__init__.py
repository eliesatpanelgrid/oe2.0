import os
from os import environ, path
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

def clean_py_files(plugin_dir):
    """
    Remove .py files when corresponding .pyc files exist in the same directory
    Avoids removing files from other plugins
    """
    if not os.path.exists(plugin_dir):
        print(f"Plugin directory {plugin_dir} does not exist")
        return

    print(f"Checking for .pyc files in: {plugin_dir}")
    for root, dirs, files in os.walk(plugin_dir):
        for file in files:
            if file.endswith('.pyc'):
                py_file = os.path.join(root, file[:-1])  # Remove 'c' from extension
                if os.path.exists(py_file):
                    try:
                        os.remove(py_file)
                        print(f"Removed .py file: {py_file}")
                    except Exception as e:
                        print(f"Error removing {py_file}: {str(e)}")

PluginLanguageDomain = "Stremio"
plugin_base_dir = resolveFilename(SCOPE_PLUGINS, 'Extensions/' + PluginLanguageDomain)
clean_py_files(plugin_base_dir)
