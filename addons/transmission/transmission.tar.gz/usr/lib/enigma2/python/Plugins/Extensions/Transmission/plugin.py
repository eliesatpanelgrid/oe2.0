import os
import io
import tarfile
import logging
import requests
import subprocess
import json
import six
import urllib3
import base64
import re
import time
import ssl
import socket
import tempfile
import glob
import traceback
import ast
import random
from os import environ, path
from enigma import (
    loadPNG, loadJPG, eServiceCenter, RT_HALIGN_CENTER, RT_VALIGN_TOP,
    RT_WRAP, eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, eTimer,
    ePixmap, ePicLoad, eSize, getDesktop, quitMainloop
)
from Components.config import (
    config, ConfigSubsection, ConfigText, ConfigNumber, ConfigYesNo, ConfigSelection
)
from Components.Pixmap import Pixmap, MultiPixmap
from Components.Sources.List import List
from Components.ActionMap import ActionMap
from Components.AVSwitch import AVSwitch
from Components.Label import Label
from Components.Scanner import Scanner, ScanPath
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Plugins.Plugin import PluginDescriptor
from Tools.BoundFunction import boundFunction
from Tools.Directories import resolveFilename, fileExists, SCOPE_PLUGINS
from Tools.Notifications import AddPopup
from transmission_rpc import Client, TransmissionError
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from twisted.internet import reactor, defer
from twisted.internet.threads import deferToThread
from mimetypes import add_type
from .Loading import Loading
from .TransmissionBrowser import (
    EZTVAPIResult, TvSearch, TransmissionMovieBrowserGrid, TorrSearch, TorrEpisodes,
    TorrConf, TorrMenu, TransmissionMovieFavourites, TransmissionSeriesBrowserGrid,
    startWebServer
)

# ... (rest of imports)

def sessionStart(reason, **kwargs):
    if reason == 0: # Session Start
        startWebServer(kwargs['session'])

def Plugins(**kwargs):
    plugin_list = [
        PluginDescriptor(where=PluginDescriptor.WHERE_AUTOSTART, fnc=autoStart),
        PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionStart),
        PluginDescriptor(name=_('Transmission'), description=_('Transmission a Torrent Client & Playback Plugin'), icon='transmission.png', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main, needsRestart=False),
        PluginDescriptor(name=_('Transmission Plugin'), icon='transmission.png', where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main, needsRestart=False),
        PluginDescriptor(name=_('Transmission Movies'), icon='transmission.png', where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=extern, needsRestart=False),
        PluginDescriptor(name=_('Transmission Series'), icon='transmission.png', where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=seriesExt, needsRestart=False),
        PluginDescriptor(name=_('Search in Torrent [Transmission]'), description=_('Search Torrent For Current Event'), where=[PluginDescriptor.WHERE_EVENTINFO], icon='transmission.png', fnc=eventInfo, needsRestart=False),
        PluginDescriptor(where=PluginDescriptor.WHERE_FILESCAN, fnc=filescan, needsRestart=False)
    ]
    if config.plugins.torreplayer.show_in_menu.value == True:
        plugin_list.append(
            PluginDescriptor(name=_('Transmission'), description=_('Transmission a Torrent Client & Playback Plugin'), icon='transmission.png', where=PluginDescriptor.WHERE_MENU, fnc=Transmission_menu, needsRestart=True)
        )

    return plugin_list
from . import EmissionOverview
from .EmissionOverview import LIST_TYPE_ALL, SORT_TYPE_ADDED
from . import _, getSkin, medialist, ghost
from .torrmgr import torrsrv
from .torrmgr.urlrequest import request_url

# Try to import optional dependencies
try:
    from Plugins.Extensions.MoviesManager.MoviesScreen import MovieScreen, SeriesScreen
    MoviesManager_installed = True
except ImportError:
    MoviesManager_installed = False

try:
    from Plugins.Extensions.TMBD.plugin import TMBD
    from Plugins.Extensions.TMBD.tmbdYTTrailer import TmbdYTTrailerList
    TMDB_installed = True
except ImportError:
    TMDB_installed = False

try:
    from Plugins.Extensions.SubsSupport.subtitlesdvb import SubsSupportDVB
    from Plugins.Extensions.SubsSupport import SubsSupport, SubsSupportStatus, initSubsSettings
    from Plugins.Extensions.SubsSupport.subtitles import E2SubsSeeker, SubsSearch, initSubsSettings, SubsStatusScreen, SubsSearchParamsMenu
    Subs = True
except ImportError:
    Subs = False

# Initialize logging
def setup_logging():
    logger = logging.getLogger('TransmissionPlugin')
    logger.setLevel(logging.DEBUG)
    handler = logging.FileHandler('/tmp/TransmissionPlugin.log')
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger

logger = setup_logging()

# Configuration setup
ts = torrsrv.torrserver()
ts.srv_timeout = 5
torrserver_path = '/usr/bin/TorrServer'
NOTIFICATIONID = 'EmissionAutodownloadError'
repolist = 'https://releases.yourok.ru/torr/server_release.json'
context = ssl._create_unverified_context()

config.plugins.emission = ConfigSubsection()
config.plugins.emission.hostname = ConfigText(default="127.0.0.1", fixed_size=False)
config.plugins.emission.username = ConfigText(default="", fixed_size=False)
config.plugins.emission.password = ConfigText(default="", fixed_size=False)
config.plugins.emission.port = ConfigNumber(default=9091)
config.plugins.emission.autodownload_from_simplerss = ConfigYesNo(default=False)
config.plugins.emission.last_tab = ConfigNumber(default=LIST_TYPE_ALL)
config.plugins.emission.last_sort = ConfigNumber(default=SORT_TYPE_ADDED)

# Get desktop size
sz_w = getDesktop(0).size().width()

# Path constants
transmission_sh = '/etc/init.d/transmission-daemon'
transmission_remote = 'transmission-remote http://127.0.0.1:9091/transmission/rpc -l'
ostende = '/usr/lib/enigma2/python/Plugins/Extensions/Transmission'
arch = subprocess.check_output('uname -m', shell=True).decode().strip()
transmission_version = '4.1.0'
plugin_version = '5.4.2'

PLUGIN_NAME = 'Transmission'
PLUGIN_LANGUAGE_DOMAIN = 'Transmission'
PLUGIN_LANGUAGE_PATH = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/locale')
PLUGIN_SKIN_PATH = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')
INSTALL_DIR = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission')
VERSION_CHECK_URL = 'https://dreambox4u.com/dreamarabia/Transmission_e2/Transmission_ver.txt'
UPDATE_PACKAGE_URL = 'https://dreambox4u.com/dreamarabia/Transmission_e2/Transmission.tar.xz'
TORRSERVER_PATH = '/usr/bin/TorrServer'
NOTIFICATIONID = 'TransmissionAutodownloadError'

# Utility functions
def logdata(label_name='', data=None):
    try:
        data = str(data)
        with open('/tmp/transmission_main.log', 'a') as fp:
            fp.write(f"{label_name} : {data}\n")
    except Exception:
        pass

imdb_genres = {
    'Action': _('Action'),
    'Adventure': _('Adventure'),
    'Animation': _('Animation'),
    'Biography': _('Biography'),
    'Comedy': _('Comedy'),
    'Crime': _('Crime'),
    'Documentary': _('Documentary'),
    'Drama': _('Drama'),
    'Family': _('Family'),
    'Fantasy': _('Fantasy'),
    'Film-Noir': _('Film-Noir'),
    'History': _('History'),
    'Horror': _('Horror'),
    'Music': _('Music'),
    'Musical': _('Musical'),
    'Mystery': _('Mystery'),
    'Romance': _('Romance'),
    'Sci-Fi': _('Sci-Fi'),
    'Short': _('Short'),
    'Sport': _('Sport'),
    'Thriller': _('Thriller'),
    'War': _('War'),
    'Western': _('Western'),
}

def get_pid(name):
    try:
        return subprocess.check_output(['pidof', name])
    except subprocess.CalledProcessError:
        return False

def start_server():
    if os.path.isfile(torrserver_path):
        server_port = '8090'
        config_path = '/etc/enigma2'
        fh = open(os.devnull, 'wb')
        os.system('export GODEBUG=madvdontneed=1')
        args = [torrserver_path, '--port', server_port, '--path', config_path]
        p = subprocess.Popen(args, shell=False, stdout=fh, stderr=fh)

# RSS callback handlers
def simplerss_update_callback(id=None):
    try:
        from Plugins.Extensions.SimpleRSS.plugin import rssPoller
    except ImportError:
        pass
    else:
        errors = 0
        if id is None:
            client = None
            for item in rssPoller.newItemFeed.history:
                for file in item[3]:
                    if file.mimetype == "application/x-bittorrent":
                        if client is None:
                            client = Client(
                                host=config.plugins.emission.hostname.value,
                                port=config.plugins.emission.port.value,
                                username=config.plugins.emission.username.value,
                                password=config.plugins.emission.password.value
                            )
                        try:
                            client.add_url(file.path)
                        except TransmissionError:
                            errors += 1
        if errors > 0:
            AddPopup(
                _("Failed to add %d torrents.") % (errors),
                MessageBox.TYPE_WARNING,
                5,
                NOTIFICATIONID
            )

def simplerss_handle_callback(el):
    try:
        from Plugins.Extensions.SimpleRSS.RSSPoller import update_callbacks
    except ImportError:
        if not el.value:
            return

        try:
            import Plugins.Extensions.SimpleRSS.plugin
            AddPopup(
                _("Your version if SimpleRSS is too old to support this feature.\nIf possible update your SimpleRSS installation."),
                MessageBox.TYPE_ERROR,
                5
            )
        except ImportError:
            AddPopup(
                _("This feature requires SimpleRSS to be installed.\nYou can do so with the Plugin Installer, see the User Manual for further explanation."),
                MessageBox.TYPE_ERROR,
                5
            )
    else:
        if el.value:
            if simplerss_update_callback not in update_callbacks:
                update_callbacks.append(simplerss_update_callback)
        elif simplerss_update_callback in update_callbacks:
            update_callbacks.remove(simplerss_update_callback)

# Attach notifier to config option
config.plugins.emission.autodownload_from_simplerss.addNotifier(simplerss_handle_callback, immediate_feedback=False)

# File scanner function
def filescan_open(item, session, **kwargs):
    client = Client(
        address=config.plugins.emission.hostname.value,
        port=config.plugins.emission.port.value,
        user=config.plugins.emission.username.value,
        password=config.plugins.emission.password.value
    )

    added = 0
    errors = 0

    for each in item:
        try:
            if client.add_url(each):
                added += 1
        except TransmissionError:
            errors += 1

    session.open(
        MessageBox,
        _("%d Torrents(s) were scheduled for download, %d failed.") % (added, errors),
        type=MessageBox.TYPE_INFO,
        timeout=5
    )

# Add MIME types
add_type("application/x-bittorrent", ".tor")
add_type("application/x-bittorrent", ".torrent")

# File scanner definition
def filescan(**kwargs):
    return [
        Scanner(
            mimetypes=("application/x-bittorrent",),
            paths_to_scan=(ScanPath(path="", with_subdirs=False),),
            name="BitTorrrent Download",
            description=_("Download torrent..."),
            openfnc=filescan_open,
        )
    ]

def check_url_connectivity(session, url, on_success_callback):
    if not url:
        on_success_callback()
        return

    def check_thread():
        # Import proxy manager if available
        try:
            from .proxy_manager import make_proxied_request
            PROXY_AVAILABLE = True
        except ImportError:
            PROXY_AVAILABLE = False
        try:
            # Multiple User-Agent strings to try
            user_agents = [
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            ]

            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate, br',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Cache-Control': 'no-cache'
            }

            # Try with proxy first if enabled
            if PROXY_AVAILABLE and hasattr(config.plugins.torreplayer, 'proxy') and config.plugins.torreplayer.proxy.value:
                try:
                    use_cors = (config.plugins.torreplayer.proxy_type.value == 'cors')
                    response = make_proxied_request(url, headers=headers, timeout=20, use_cors=use_cors)
                    if response and 200 <= response.status_code < 500:
                        return True
                except Exception as e:
                    logger.debug("Proxy connectivity check failed: %s", str(e))

            # Try with different User-Agents - be more lenient
            success_on_any_method = False
            last_error = None

            for user_agent in user_agents:
                try:
                    headers['User-Agent'] = user_agent
                    # Use HEAD request first (lighter), fallback to GET if HEAD fails
                    for method in ['HEAD', 'GET']:
                        try:
                            if method == 'HEAD':
                                response = requests.head(url, headers=headers, timeout=20, stream=True, verify=False, allow_redirects=True)
                            else:
                                response = requests.get(url, headers=headers, timeout=20, stream=True, verify=False, allow_redirects=True)

                            status_code = response.status_code

                            # Close the connection properly
                            try:
                                response.close()
                            except:
                                pass

                            # Be very lenient - accept almost any response that shows server is reachable
                            # 2xx = Success
                            # 3xx = Redirect (ok)
                            # 4xx = Client error but server is reachable (ok for our purposes)
                            # Only fail on 5xx server errors or no response
                            if 200 <= status_code < 500:
                                logger.debug("Server responded with %d for %s - considering as accessible", status_code, url)
                                return True
                            elif status_code >= 500:
                                last_error = "Server error: HTTP %d" % status_code
                                # Don't break, try other user agents
                                continue
                        except requests.exceptions.Timeout:
                            last_error = "Connection timeout"
                            continue
                        except requests.exceptions.SSLError as ssl_err:
                            # SSL errors often occur but the site might still work
                            logger.debug("SSL error for %s: %s - trying fallback", url, str(ssl_err))
                            last_error = "SSL error"
                            continue
                        except requests.exceptions.ConnectionError as conn_err:
                            last_error = "Connection error"
                            continue
                        except requests.exceptions.RequestException as req_err:
                            last_error = "Request error"
                            continue
                except Exception as e:
                    last_error = str(e)
                    continue

            # Final fallback: try socket connection - if this works, assume URL is accessible
            try:
                from six.moves.urllib.parse import urlparse
                parsed = urlparse(url)
                host = parsed.hostname
                if host:
                    port = parsed.port or (443 if parsed.scheme == 'https' else 80)
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(8)
                    result = sock.connect_ex((host, port))
                    sock.close()
                    if result == 0:
                        # Socket connection works, assume URL is accessible
                        logger.info("Socket connection to %s:%d successful - considering URL accessible", host, port)
                        return True
            except Exception as sock_err:
                logger.debug("Socket test also failed: %s", str(sock_err))

            return last_error or "Unable to connect"
        except Exception as e:
            logger.error("check_url_connectivity exception: %s", str(e))
            return str(e)

    def on_complete(result):
        if result is True:
            on_success_callback()
        else:
            # Log the error for debugging
            logger.warning("URL connectivity check failed for %s: %s", url, result)
            # Show error but allow user to proceed anyway with YES as default
            session.openWithCallback(
                lambda ret: on_success_callback() if ret else None,
                MessageBox,
                _("Connection check failed:\n\nError: %s\n\nDo you want to proceed anyway?") % (result),
                MessageBox.TYPE_YESNO,
                default=True
            )

    deferToThread(check_thread).addCallback(on_complete)

class MainScreen(Screen):
    def createSummary(self):
        from .TransmissionBrowser import TransmissionLCDSummary
        return TransmissionLCDSummary

    def getLCDSummary(self):
        cur = self['menu'].getCurrent()
        title = cur[0] if cur else ""
        return {
            "title": "Transmission – Main Menu",
            "line1": title[:32],
            "line2": "",
            "line3": "",
            "progress": 0,
        }
    def __init__(self, session, args=None):
        Screen.__init__(self, session)
        self.skin = getSkin('Transmission mainscreen')
        self.skinName = 'Transmission mainscreen'
        self["pic_loading"] = Pixmap()
        self["int_loading"] = Label('')
        self["msg_loading"] = Label('')
        self.loading = Loading(self["pic_loading"], self["int_loading"], self["msg_loading"], None)
        self.icons_directory = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/icons/')
        self.session = session
        self.menu = args
        menu_list = [
            (_('Latest Watched'), 'TorrPlayer', _('Latest Watched Torrents On TorrServer'), 'watched'),
            (_('Favorites'), 'favorite', _('Your Favorites List of Torrents'), 'favorites'),
            (_('Movies'), 'Torrent_Browser', _('Browse Latest Torrents Movies From [YIFI]'), 'yifi'),
            (_('Series'), 'Torrent_series', _('Browse Latest Torrents TvShows & Series From [EZTV]'), 'eztv'),
            (_('Search Torrents'), 'sekker', _('Search Torrents From [Rutor]'), 'sekker'),
            (_('Download Files Manager'), 'downloader', _('Manage Your Download'), 'downloader'),
            (_('Settings'), 'settings', _('Setup Your Plugin Skin and Torrplayer Functions'), 'setting'),
            (_('Transmission Tools'), 'transmission', _('Activate/Deactivate Transmission Daemon'), 'daemon'),
            (_('Clean Poster Path'), 'cleaner', _('Clean The Poster Path.'), 'cleaner'),
            (_('Check for Updates'), 'check_updates', _('Check and Install the Latest Plugin Version'), 'update'),
            (_('About Transmission'), 'about_transmission', _('See You @ [tunisia-sat]'), 'about')
        ]
        if MoviesManager_installed:
            menu_list.append(( _('My Media'), 'movies_manager', _('Local Movies & Series'), 'movies'))
        self['menu'] = List(menu_list)
        self['yassine'] = Label('')
        self["cover"] = Pixmap()
        self['actions'] = ActionMap(['OkCancelActions', "DirectionActions"], {'ok': self.go, 'cancel': self.close, 'left': self.keyLeft, 'right': self.keyRight, 'up': self.keyUp,
        'down': self.keyDown}, -1)
        self['menu'].onSelectionChanged.append(self.description)
        self['menu'].onSelectionChanged.append(self.showPoster)
        self.onExecBegin.append(self.description)

    def go(self):
        returnValue = self['menu'].getCurrent()[1]
        if returnValue:
            if returnValue == 'Torrent_Browser':
                self.session.open(MainScreen2)
            elif returnValue == 'Torrent_series':
                #self.session.open(MessageBox, 'Work in Progress next update will be ready ..', MessageBox.TYPE_INFO)
                self.session.open(MainScreenEz)
            elif returnValue == 'TorrPlayer':
                self.session.open(TorrMenu)
            elif returnValue == 'downloader':
                self.session.open(EmissionOverview.EmissionOverview)
            elif returnValue == 'transmission':
                self.session.open(TransmissionTools)
            elif returnValue == 'favorite':
                self.session.open(TransmissionMovieFavourites)
            elif returnValue == 'sekker':
                text = ''
                if config.plugins.torreplayer.rememberlastsearch.value:
                    text = config.plugins.torreplayer.lastsearch.value
                self.session.openWithCallback(self.addTorrent, VirtualKeyBoard, title=_('Enter torrent to search'),
                                              text=text)
            elif returnValue == 'cleaner':
                self.poster_path = '{}/transmission/poster'.format(config.plugins.torreplayer.poster_path.value)
                self.clean_poster_directory(str(self.poster_path), 1)
            elif returnValue == 'settings':
                self.session.open(TorrConf)
            elif returnValue == 'movies_manager':
                self.open_movies_manager()
            elif returnValue == 'check_updates':
                self.checkForUpdates()
            elif returnValue == 'about_transmission':
                self.session.open(AboutScreen)

    def keyLeft(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index - 1)

    def keyRight(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index + 1)

    def keyUp(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index - 4)

    def keyDown(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index + 4)

    def showPoster(self):
        selection = self['menu'].getCurrent()
        if selection:
            p = selection[3]
            filename = os.path.join(self.icons_directory, '{}.png'.format(p))
            logger.debug("Trying to show poster: %s", filename)
            if os.path.exists(filename):
                if self["cover"].instance:
                    try:
                        self["cover"].instance.setPixmapFromFile(filename)
                        logger.debug("Poster set successfully for: %s", p)
                    except Exception as e:
                        logger.error("Error setting poster for %s: %s", p, str(e))
                else:
                    logger.warning("Cover instance not available.")
            else:
                logger.warning("Poster file does not exist for main menu: %s", p)

    def open_movies_manager(self):
        """
        Prompts the user to choose between Movies and Series, and opens the corresponding screen.
        """
        choices = [
            (_("Movies"), "movies"),
            (_("Series"), "series")
        ]
        self.session.openWithCallback(self.movies_manager_callback, ChoiceBox, title=_("Choose type"), list=choices)

    def movies_manager_callback(self, choice):
        """
        Handles the user's choice for Movies or Series.
        """
        if choice is None:
            return  # User cancelled the choice box

        selected = choice[1]
        if selected == "movies":
            self.path = '{}/data/movies.json'.format(config.plugins.moviemanager.movis_path.value)
            logger.info("Path movie manager (Movies): %s", self.path)
            self.session.open(MovieScreen, self.path)
        elif selected == "series":
            self.path = '{}/data/movies.json'.format(config.plugins.moviemanager.movis_path.value)
            logger.info("Path movie manager (Series): %s", self.path)
            self.session.open(SeriesScreen, self.path)

    def clean_poster_directory(self, directory_path, max_size_mb):
        self.loading.stop()
        try:
            files = [
                os.path.join(directory_path, f)
                for f in os.listdir(directory_path)
                if os.path.isfile(os.path.join(directory_path, f))
            ]

            total_size_bytes = sum(os.path.getsize(f) for f in files)
            max_size_bytes = max_size_mb * 1024 * 1024

            if total_size_bytes > max_size_bytes:
                msg = _('Poster directory is over limit (%.2f MB > %.2f MB). Clean it?') % (
                    total_size_bytes / 1048576, max_size_bytes / 1048576)

                def on_confirm(answer):
                    if not answer:
                        return self.loading.stop()

                    self.loading.start(msg=_('Cleaning poster directory...\n{}'.format(directory_path)))

                    def delete_files_thread():
                        files.sort(key=lambda x: os.path.getmtime(x))
                        total_files = len(files)
                        deleted_size = 0
                        progress = []

                        for index, file_path in enumerate(files):
                            try:
                                file_size = os.path.getsize(file_path)
                                os.remove(file_path)
                                deleted_size += file_size
                            except Exception as e:
                                print("Error deleting", file_path, str(e))
                            percent = int((index + 1) * 100 / total_files)
                            progress.append(percent)

                        return deleted_size, progress

                    def on_success(result):
                        deleted_size, progress_list = result
                        self.loading.stop()

                        final_size = (total_size_bytes - deleted_size) / 1048576
                        self.session.open(
                            MessageBox,
                            _('Cleaned poster directory. Current size: %.2f MB') % final_size,
                            MessageBox.TYPE_INFO, timeout=5
                        )

                    def on_fail(failure):
                        self.loading.stop(msg=_('Error during cleaning'))
                        self.session.open(
                            MessageBox,
                            _('Failed to clean poster directory: %s') % str(failure.value),
                            MessageBox.TYPE_ERROR, timeout=5
                        )

                    d = deferToThread(delete_files_thread)
                    d.addCallback(on_success)
                    d.addErrback(on_fail)

                self.session.openWithCallback(
                    on_confirm,
                    MessageBox,
                    msg,
                    MessageBox.TYPE_YESNO,
                    timeout=0
                )
                self.loading.stop()

            else:
                self.session.open(
                    MessageBox,
                    _('Poster directory size is within limit. Current size: %.2f MB') % (total_size_bytes / 1048576),
                    MessageBox.TYPE_INFO, timeout=5
                )
        except Exception as e:
            print('Failed to clean poster directory:', str(e))

    def description(self):
        returnValue = self['menu'].getCurrent()[2]
        if returnValue:
            self['yassine'].setText(returnValue)

    def addTorrent(self, name):
        if name:
            if config.plugins.torreplayer.rememberlastsearch.value:
                config.plugins.torreplayer.lastsearch.value = name
                config.plugins.torreplayer.lastsearch.save()
            self.session.openWithCallback(self.handleTorrSearch, TorrSearch, search_topic=name)

    def handleTorrSearch(self, result):
        if result and len(result) >= 4:
            action = result[1]
            name = result[2]
            magnet = result[3]
            poster = ''
            new_torrent = torrsrv.torrent()
            new_torrent.link = result[3]
            new_torrent.title = result[2]
            new_torrent.poster = None
            new_torrent.save_to_db = True
            if action == 'onlyadd':
                ts.add_torrent(new_torrent)
            elif action == 'addplay':
                ts.add_torrent(new_torrent)
                name = new_torrent.title
                magnet = new_torrent.link
                titles = [name, magnet]
                self.session.open(TorrEpisodes, titles, poster)
            elif action == 'onlyplay':
                ts.add_torrent(new_torrent)
                name = new_torrent.title
                magnet = new_torrent.link
                titles = [name, magnet]
                self.session.open(TorrEpisodes, titles, poster)
            else:
                logger.error("Unexpected action: %s", action)
        else:
            logger.error('Movie torrent link not available.')


    def checkForUpdates(self):
        """
        Checks for updates by comparing the local plugin version with the online version.
        If an update is available, initiates the update process.
        """
        logger.info("Current plugin version: %s", plugin_version)

        try:
            logger.info("Checking for updates from: %s", VERSION_CHECK_URL)

            # Solution 1: Use rotating user agents to prevent blocking
            user_agents = [
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
            ]

            headers = {'User-Agent': random.choice(user_agents)}

            # Solution 2: Add referer header which some servers require
            headers['Referer'] = 'https://dreambox4u.com/'

            # Solution 3: Use session with retries
            session = requests.Session()
            retries = Retry(total=3, backoff_factor=0.5, status_forcelist=[429, 500, 502, 503, 504])
            session.mount('https://', HTTPAdapter(max_retries=retries))

            response = session.get(VERSION_CHECK_URL, headers=headers, timeout=15)
            response.raise_for_status()

            online_version = response.text.strip()
            logger.info("Online plugin version: %s", online_version)

            if self.is_newer_version(online_version, plugin_version):
                logger.info("New version available. Prompting user for installation.")
                self.prompt_for_update(online_version)
            else:
                logger.info("No updates available. You are running the latest version.")
                self.session.open(MessageBox, _("No updates available. You are running the latest version [%s]." % str(plugin_version)), MessageBox.TYPE_INFO)

        except requests.RequestException as e:
            logger.error("Error checking for updates: %s", e)

            # Solution 4: Fallback to cached version if available
            if hasattr(self, 'cached_version'):
                logger.warning("Using cached version info due to connection error")
                if self.is_newer_version(self.cached_version, plugin_version):
                    self.prompt_for_update(self.cached_version)
                return

            self.session.open(MessageBox, _("Error checking for updates: %s") % str(e), MessageBox.TYPE_ERROR)

    def prompt_for_update(self, online_version):
        """
        Prompts the user to confirm the update installation and proceeds based on the user's response.
        """
        self.session.openWithCallback(
            self.install_update,  # Callback to install the update
            MessageBox,
            _("A new version (%s) is available.\n\nDo you want to install it now?") % online_version,
            MessageBox.TYPE_YESNO
        )

    def install_update(self, confirmed):
        """
        Handles the installation process based on user confirmation.
        """
        if confirmed:
            try:
                logger.info("User confirmed update installation.")
                cmd = "wget -q --no-check-certificate https://dreambox4u.com/dreamarabia/Transmission_e2/Transmission_update.sh -O - | bash"
                self.session.open(
                    Console,
                    title="Installing update...",
                    cmdlist=[cmd],
                    finishedCallback=self.handle_installation_result(confirmed),
                    closeOnSuccess=True
                )
            except Exception as e:
                logger.error("Error during update installation: %s", str(e))
                self.session.open(MessageBox, _("Error during update installation: %s") % str(e), MessageBox.TYPE_ERROR)
        else:
            logger.info("User canceled the update installation.")
            self.session.open(MessageBox, _("Update installation was canceled."), MessageBox.TYPE_INFO)

    def handle_installation_result(self, result):
        """
        Processes the result of the installation command.
        """
        if result:
            logger.info("Update installation succeeded.")
            self.session.openWithCallback(
                self.restartEnigma2,
                MessageBox,
                _("Plugin updated successfully.\nDo you want to restart Enigma2 now?"),
                MessageBox.TYPE_YESNO
            )
        else:
            logger.error("Update installation failed.")
            self.session.open(MessageBox, _("Plugin update failed."), MessageBox.TYPE_ERROR)

    def is_newer_version(self, online_version, local_version):
        """
        Compares the online version to the local version.
        Returns True if the online version is newer.
        """
        online_version_parts = [int(part) for part in online_version.split('.')]
        local_version_parts = [int(part) for part in local_version.split('.')]
        return online_version_parts > local_version_parts

    def restartEnigma2(self, confirmed):
        """
        Restarts Enigma2 if the user confirms.
        """
        if confirmed:
            logger.info("Restarting Enigma2...")
            quitMainloop(3)  # Restart Enigma2
        else:
            logger.info("User chose not to restart Enigma2.")

class TransmissionTools(Screen):
    def __init__(self, session, args=None):
        Screen.__init__(self, session)
        self.skin = getSkin('Transmission Menu')
        self.skinName = 'Transmission Menu'
        self.session = session
        self.menu = args

        self.icons_directory = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/icons/')
        list_items = [
            (_('Start'), 'start', _('Starting Transmission-Daemon')),
            (_('Stop'), 'stop', _('Stopping Transmission-Daemon')),
            (_('Restart'), 'restart', _('Restarting Transmission-Daemon')),
            (_('Status'), 'status', _('Reading Transmission-Daemon Info')),
            (_('Enable Auto-Start'), 'enable', _('Enabling Auto-Start for Transmission-Daemon \n [setup first download limit]')),
            (_('Disable Auto-Start'), 'disable', _('Disabling Auto-Start for Transmission-Daemon')),
            (_('Move TorrServer'), 'move', _('Move TorrServer binary to external drive and create symlink'))
        ]

        self['yassine'] = Label('')
        self['menu'] = List(list_items)
        self["cover"] = Pixmap()
        self['actions'] = ActionMap(['OkCancelActions', "DirectionActions"], {'ok': self.run, 'cancel': self.close, 'left': self.keyLeft, 'right': self.keyRight, 'up': self.keyUp,
        'down': self.keyDown}, -1)
        self['menu'].onSelectionChanged.append(self.description)
        self['menu'].onSelectionChanged.append(self.showPoster)
        self.onExecBegin.append(self.description)
        self.onExecBegin.append(self.showPoster)

    def run(self):
        current_item = self['menu'].getCurrent()
        if current_item is None or not isinstance(current_item, tuple):
            return

        action = current_item[1]

        if action == 'status':
            self.session.open(Console, _('status'), [transmission_remote])
        elif action == 'move':
            self.moveTorrServer()
        else:
            self.session.open(Console, _(action), ['%s %s' % (transmission_sh, action)])

    def keyLeft(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index - 1)

    def keyRight(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index + 1)

    def keyUp(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index - 4)

    def keyDown(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index + 4)

    def moveTorrServer(self):
        source_path = "/usr/bin/TorrServer"
        target_dir = os.path.join(config.plugins.torreplayer.poster_path.value, "transmission")
        target_path = os.path.join(target_dir, "TorrServer")
        symlink_path = "/usr/bin/TorrServer"

        commands = [
            "mkdir -p '%s'" % target_dir,
            "mv '%s' '%s'" % (source_path, target_path),
            "ln -sf '%s' '%s'" % (target_path, symlink_path)
        ]

        self.session.open(Console, _('Moving TorrServer'), commands)

    def description(self):
        current_item = self['menu'].getCurrent()
        if current_item and isinstance(current_item, tuple):
            desc = current_item[2]
            self['yassine'].setText(desc if isinstance(desc, str) else '')
        else:
            self['yassine'].setText('')

    def showPoster(self):
        selection = self['menu'].getCurrent()
        if selection:
            p = selection[1]
            filename = os.path.join(self.icons_directory, '{}.png'.format(p))
            logger.debug("Trying to show poster: %s", filename)
            if os.path.exists(filename):
                if self["cover"].instance:
                    try:
                        self["cover"].instance.setPixmapFromFile(filename)
                        logger.debug("Poster set successfully for: %s", p)
                    except Exception as e:
                        logger.error("Error setting poster for %s: %s", p, str(e))
                else:
                    logger.warning("Cover instance not available.")
            else:
                logger.warning("Poster file does not exist for tools menu: %s", p)

class MainScreen2(Screen):
    def __init__(self, session, args=None):
        Screen.__init__(self, session)
        self.skin = getSkin('Transmission mainscreen')
        self.skinName = 'Transmission mainscreen'
        self.session = session
        self.plugin_path = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission')
        self.icons_directory = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/icons/')
        self.base_url = None
        self.menu = args
        menu_list = [
            (_('Latest Movies'), 'Torrent_Browser', _('New Movies Added to Yifi Server')),
            (_('4k Movies'), 'Torrent_Browser_4k', _('A Various Movies With [2160p] Quality')),
            (_('3D Movies'), 'MoviesBrowser3D', _('A Various Movies With [3D] Quality')),
            (_('Most Rated Movies'), 'MoviesBrowserRating', _('Best Rated Movies Based On IMDB')),
            (_('More Categories'), 'MoviesCategories', _('Sort The Movies By Categories')),
            (_('Search Movies'), 'Torrent_search', _('Search Movie Torrent'))
        ]
        self['menu'] = List(menu_list)
        self["cover"] = Pixmap()
        self['yassine'] = Label('')
        self['actions'] = ActionMap(['OkCancelActions', "DirectionActions"], {'ok': self.go, 'cancel': self.close, 'left': self.keyLeft, 'right': self.keyRight, 'up': self.keyUp,
        'down': self.keyDown}, -1)
        self['menu'].onSelectionChanged.append(self.description)
        self['menu'].onSelectionChanged.append(self.showPoster)
        self.onExecBegin.append(self.description)
        self.onExecBegin.append(self.showPoster)

    def go(self):
        returnValue = self['menu'].getCurrent()[1]
        if returnValue:
            limit_param = ""
            if config.plugins.torreplayer.items.value != 150:
                limit_param = "&limit={}".format(str(config.plugins.torreplayer.items.value))

            if returnValue == 'Torrent_Browser':
                self.base_url = 'https://yts.lt/api/v2/list_movies.json?quality=all&sort_by=date_added{}&page='.format(limit_param)
                text = _("Downloading Latest Movies Data Please Wait ...")
                check_url_connectivity(self.session, self.base_url, lambda: self.session.open(TransmissionMovieBrowserGrid, self.base_url, text))

            elif returnValue == 'Torrent_Browser_4k':
                self.base_url = 'https://yts.lt/api/v2/list_movies.json?quality=2160p&sort_by=seeds{}&page='.format(limit_param)
                text = _("Downloading 4K Movies Data Please Wait ...")
                check_url_connectivity(self.session, self.base_url, lambda: self.session.open(TransmissionMovieBrowserGrid, self.base_url, text))

            elif returnValue == 'MoviesBrowser3D':
                self.base_url = 'https://yts.lt/api/v2/list_movies.json?quality=3D&sort_by=seeds{}&page='.format(limit_param)
                text = _("Downloading 3D Movies Data Please Wait ...")
                check_url_connectivity(self.session, self.base_url, lambda: self.session.open(TransmissionMovieBrowserGrid, self.base_url, text))

            elif returnValue == 'MoviesBrowserRating':
                self.base_url = 'https://yts.lt/api/v2/list_movies.json?sort_by=rating{}&page='.format(limit_param)
                text = _("Downloading Rated [IMDB] Movies Data Please Wait ...")
                check_url_connectivity(self.session, self.base_url, lambda: self.session.open(TransmissionMovieBrowserGrid, self.base_url, text))

            elif returnValue == 'MoviesCategories':
                self.session.open(Categories)

            elif returnValue == 'Torrent_search':
                title = _('Please enter the movie title')
                text = ''
                if config.plugins.torreplayer.rememberlastsearchyts.value:
                    text = config.plugins.torreplayer.lastsearchyts.value
                self.session.openWithCallback(self.save_title, VirtualKeyBoard, title=title, text=text)



    def save_title(self, title):
        if title:
            if config.plugins.torreplayer.rememberlastsearchyts.value:
                config.plugins.torreplayer.lastsearchyts.value = title
                config.plugins.torreplayer.lastsearchyts.save()

            self.base_url = 'https://yts.lt/api/v2/list_movies.json?query_term={}&page='.format(str(title))
            print("search", self.base_url)
            text = _('Searching [ {} ] Data Please Wait ...').format(title)
            check_url_connectivity(self.session, self.base_url, lambda: self.session.open(TransmissionMovieBrowserGrid, self.base_url, text))



    def description(self):
        returnValue = self['menu'].getCurrent()[2]
        if returnValue:
            self['yassine'].setText(returnValue)

    def showPoster(self):
        selection = self['menu'].getCurrent()
        if selection:
            p = selection[0]
            pet = p.lower().replace(' ', '')
            filename = os.path.join(self.icons_directory, '{}.png'.format(pet))
            logger.debug("Trying to show poster: %s", filename)
            if os.path.exists(filename):
                if self["cover"].instance:
                    try:
                        self["cover"].instance.setPixmapFromFile(filename)
                        logger.debug("Poster set successfully for: %s", p)
                    except Exception as e:
                        logger.error("Error setting poster for %s: %s", p, str(e))
                else:
                    logger.warning("Cover instance not available.")
            else:
                logger.warning("Poster file does not exist for movies menu: %s", p)

    def keyLeft(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index - 1)

    def keyRight(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index + 1)

    def keyUp(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index - 4)

    def keyDown(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index + 4)

class Categories(Screen):
    def __init__(self, session, args=None):
        Screen.__init__(self, session)
        self.skin = getSkin('Transmission categories')
        self.skinName = 'Transmission categories'
        self.session = session
        self.picload = ePicLoad()
        self.icons_directory = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/icons/')
        self.menu = args

        # Get the translated genres
        self.genres = list(imdb_genres.keys())
        menu_list = []
        Poster = None

        for genre in self.genres:
            filename = os.path.join(self.icons_directory, '{}.png'.format(genre))
            if os.path.exists(filename):
                Poster = loadPNG(filename)

            # Use the translated genre names here
            translated_genre = imdb_genres[genre]
            menu_list.append((translated_genre, genre, Poster))

        self['menu'] = List(menu_list)
        self['actions'] = ActionMap(['OkCancelActions', "DirectionActions"], {'ok': self.go, 'cancel': self.close, 'left': self.keyLeft, 'right': self.keyRight, 'up': self.keyUp,
        'down': self.keyDown}, -1)

    def go(self):
        selection = self['menu'].getCurrent()
        if selection:
            genre = selection[1]  # Keep the original genre key
            self.moatje = str(genre)
            self.base_url = 'https://yts.lt/api/v2/list_movies.json?genre={}&sort_by=date_added&limit={}&page='.format(self.moatje, str(config.plugins.torreplayer.items.value))
            text = _("Downloading {} Movies Data Please Wait ...").format(imdb_genres[genre])
            check_url_connectivity(self.session, self.base_url, lambda: self.session.open(TransmissionMovieBrowserGrid, self.base_url, text))

    def keyLeft(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index - 1)

    def keyRight(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index + 1)

    def keyUp(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index - 5)

    def keyDown(self):
        index = self['menu'].getIndex()
        self['menu'].setIndex(index + 5)

class MainScreenEz(Screen):
    def __init__(self, session, args=None):
        Screen.__init__(self, session)
        self.skin = getSkin('Transmission mainscEz')
        self.skinName = 'Transmission mainscEz'
        self.session = session
        self.plugin_path = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission')
        self.icons_directory = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/icons/')
        self.menu = args
        self.id_tvdb = ''
        self.base_url = ''
        menu_list = [
            (_('Latest TvShow & Series'), 'Torrent_Browser_TV', _('Latest New Episodes Added to [ EZTV ]')),
            (_('Top Rated TvShow & Series'), 'Torrent_rated_TV', _('Top Rated Series Based on [ IMDB ]')),
            (_('TvShow & Series Search'), 'Torrent_search_TV', _('Searching Series & TvShow'))
        ]
        self['yassine'] = Label('')

        self["cover"] = Pixmap()
        self['menu'] = List(menu_list)
        self['actions'] = ActionMap(['OkCancelActions'], {'ok': self.go, 'cancel': self.close}, -1)
        self['menu'].onSelectionChanged.append(self.description)
        self['menu'].onSelectionChanged.append(self.showPoster)
        self.onExecBegin.append(self.description)
        self.onExecBegin.append(self.showPoster)

    def go(self):
        returnValue = self['menu'].getCurrent()[1]
        if returnValue:
            if returnValue == 'Torrent_Browser_TV':
                text = _("Downloading Series & TvShow Data Please Wait ...")
                self.url = 'https://eztvx.to/api/get-torrents?limit={}&page='.format(str(config.plugins.torreplayer.items.value))
                check_url_connectivity(self.session, self.url, lambda: self.session.open(EZTVAPIResult, self.url, text))
            elif returnValue == 'Torrent_rated_TV':
                text = _("Downloading Top Rated Series Based on [ IMDB ] Data Please Wait ...")
                check_url_connectivity(self.session, '', lambda: self.session.open(TransmissionSeriesBrowserGrid, '', text))
            elif returnValue == 'Torrent_search_TV':
                title = _('Please enter the TvSerie')
                text = ''
                if config.plugins.torreplayer.rememberlastsearchyts_tv.value:
                    text = config.plugins.torreplayer.lastsearchyts_tv.value
                self.session.openWithCallback(self.save_title, VirtualKeyBoard, title=title, text=text)

    def save_title(self, title):
        if title:
            if config.plugins.torreplayer.rememberlastsearchyts_tv.value:
                config.plugins.torreplayer.lastsearchyts_tv.value = title
                config.plugins.torreplayer.lastsearchyts_tv.save()
            url_tmdb = 'https://api.themoviedb.org/3/search/tv?api_key=3c3efcf47c3577558812bb9d64019d65&query={}'.format(title)
            response = requests.get(url_tmdb, verify=False)
            try:
                data = response.json()
                if 'results' in data and data['results']:
                    tv_show = data['results'][0]
                    tmdb_id = tv_show.get('id', '')
                    imdb_id = self.get_imdb_id_from_tmdb(tmdb_id)
                    if imdb_id:
                        self.base_url = 'https://eztvx.to/api/get-torrents?imdb_id={}&page='.format(imdb_id)
                        logdata("search", self.base_url)
                        text = _('Searching [ {} ] Data. Please Wait...').format(title)
                        check_url_connectivity(self.session, self.base_url, lambda: self.session.open(TvSearch, self.base_url, text))
                    else:
                        self.session.open(MessageBox, _('No IMDb ID found for the TV show'), MessageBox.TYPE_INFO, timeout=5)
                else:
                    self.session.open(MessageBox, _('No TV show found with the given title'), MessageBox.TYPE_INFO, timeout=5)
            except ValueError as e:
                logdata('Error parsing JSON from TMDb:', str(e))
            except requests.exceptions.RequestException as e:
                logdata('Error fetching data from TMDb:', str(e))

    def get_imdb_id_from_tmdb(self, tmdb_id):
        """Fetches IMDb ID for a TV show using its TMDb ID."""
        url = 'https://api.themoviedb.org/3/tv/{}/external_ids?api_key=3c3efcf47c3577558812bb9d64019d65'.format(tmdb_id)
        try:
            response = requests.get(url, verify=False)
            data = response.json()
            imdb_id = data.get('imdb_id', None)
            if imdb_id and imdb_id.startswith('tt'):
                imdb_id = imdb_id[2:]  # Remove the 'tt' prefix
            return imdb_id
        except requests.exceptions.RequestException as e:
            logdata('Error fetching IMDb ID from TMDb:', str(e))
            return None



    def cleanTitle(self, title):
        return title.lower().replace(' ', '').replace('.', '').replace('/', '').replace(':', '')

    def description(self):
        returnValue = self['menu'].getCurrent()[2]
        if returnValue:
            self['yassine'].setText(returnValue)

    def showPoster(self):
        selection = self['menu'].getCurrent()
        if selection:
            p = selection[1]
            pet = p.lower().replace(' ', '').replace('_', '')
            filename = os.path.join(self.icons_directory, '{}.png'.format(pet))
            logger.debug("Trying to show poster: %s", filename)
            if os.path.exists(filename):
                if self["cover"].instance:
                    try:
                        self["cover"].instance.setPixmapFromFile(filename)
                        logger.debug("Poster set successfully for: %s", p)
                    except Exception as e:
                        logger.error("Error setting poster for %s: %s", p, str(e))
                else:
                    logger.warning("Cover instance not available.")
            else:
                logger.warning("Poster file does not exist for movies menu: %s", p)

class AboutScreen(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.skin = getSkin('AboutScreens_transmission')
        self.skinName = 'AboutScreens_transmission'
        self.qr_image_path = "/tmp/transmission_about_qrcode.png"

        self["info_label"] = Label(self.get_about_info())
        self["qr_image"] = Pixmap()
        self["qr_image2"] = Pixmap()
        self["qr_image3"] = Pixmap()
        self["tunisia_sat_logo"] = Pixmap()
        self["qr_info_label"] = Label(_("Arabic Support\ntunisia-sat"))
        self["qr_info_label2"] = Label(_("English Support\nlinuxsat-support"))
        self["qr_info_label3"] = Label(_("Scan for donate"))
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.close, "cancel": self.close}, -1)

        self.onLayoutFinish.append(self.generateAndDisplayQRCode)
        self.onLayoutFinish.append(self.load_tunisia_sat_logo)


    def get_about_info(self):
        title = _(
            'Transmission-Cli version:\n  %s \n\nPlugin version:\n  %s \n\nCompiled and Developed by:\n\n  *** Ostende ***\n\nFor more info please visit:'
        ) % (transmission_version, plugin_version)
        return title


    def generateAndDisplayQRCode(self):
        qr_data1 = "https://www.tunisia-sat.com/forums/threads/4436107/"
        qr_data2 = "https://www.linuxsat-support.com/thread/157336-transmission-torrent-client/"
        qr_data3 = "https://www.paypal.com/donate?hosted_button_id=CZ72EK8PWCTXU"

        qr_image_path1 = os.path.join(resolveFilename(SCOPE_PLUGINS, "Extensions/Transmission/skins/"), "transmission_about_qrcode1.png")
        qr_image_path2 = os.path.join(resolveFilename(SCOPE_PLUGINS, "Extensions/Transmission/skins/"), "transmission_about_qrcode2.png")
        qr_image_path3 = os.path.join(resolveFilename(SCOPE_PLUGINS, "Extensions/Transmission/skins/"), "transmission_about_qrcode3.png")

        try:
            if "qr_image" in self:
                self["qr_image"].instance.setPixmapFromFile(qr_image_path1)
            if "qr_image2" in self:
                self["qr_image2"].instance.setPixmapFromFile(qr_image_path2)
            if "qr_image3" in self:
                self["qr_image3"].instance.setPixmapFromFile(qr_image_path3)


        except Exception as e:
            print("[AboutScreen] Error generating QR codes:", e)
            self["qr_info_label"].setText(_("Error generating QR code"))
            self["qr_info_label2"].setText(_("Error generating QR code"))
            self["qr_info_label3"].setText(_("Error generating QR code"))

    def load_tunisia_sat_logo(self):
        try:
            logo_path = os.path.join(resolveFilename(SCOPE_PLUGINS, "Extensions/Transmission/skins/"), "paypal_logo_icon.png")
            if not os.path.exists(logo_path):
                print("[AboutScreen] Logo file missing:", logo_path)
                return

            if "tunisia_sat_logo" not in self:
                print("[AboutScreen] SKIN ERROR: 'tunisia_sat_logo' widget not defined!")
                return

            print("[AboutScreen] Loading logo:", logo_path)
            self["tunisia_sat_logo"].instance.setPixmapFromFile(logo_path)
        except Exception as e:
            print("[AboutScreen] Logo load error:", e)


    def onHide(self):
        pass

def autoStart(reason, **kwargs):
    if get_pid('TorrServer') == False and os.path.isfile(torrserver_path) == True:
        start_server()

def get_version():
    try:
        ver = subprocess.check_output(torrserver_path + ' --version', shell=True)
        match = re.match('TorrServer (.*)', six.ensure_str(ver))
        return str(match.group(1).strip())
    except subprocess.CalledProcessError:
        return 'no version'

def download_file(url, fileToSave, attr='u=rx,g=r,o=r'):
    retval = False
    content = request_url(url, context=context)
    if content:
        try:
            with open(fileToSave, 'wb') as (f):
                f.write(content['data'])
            time.sleep(0.5)
            if os.path.isfile(fileToSave):
                if os.path.getsize(fileToSave) > 0:
                    subprocess.call(['chmod', attr, fileToSave])
                    retval = True
                else:
                    os.path.remove(fileToSave)
        except:
            pass

    return retval


def main(session, **kwargs):
    subs_path = resolveFilename(SCOPE_PLUGINS, 'Extensions/' + 'SubsSupport')
    tmdb_path = resolveFilename(SCOPE_PLUGINS, 'Extensions/' + 'TMBD')
    Subs_installed = os.path.isdir(subs_path)
    TMDB_installed = os.path.isdir(tmdb_path)
    poster_base_path = os.path.normpath(config.plugins.torreplayer.poster_path.value).rstrip('/')
    transmission_dir = os.path.join(poster_base_path, 'transmission')
    poster_path = os.path.join(transmission_dir, 'poster')
    source_path = "/usr/bin/TorrServer"
    target = "/usr/bin/TorrServer"
    target_path = os.path.join(transmission_dir, "TorrServer")
    repolist = 'https://releases.yourok.ru/torr/server_release.json'
    try:
        for p in [transmission_dir, poster_path]:
            if not os.path.exists(p):
                os.makedirs(p)
    except Exception as e:
        session.open(MessageBox, _("Error creating the folder: %s") % str(e), MessageBox.TYPE_ERROR)
        return

    def continueToMainScreen():
        session.open(MainScreen)

    def ask_install_subssupport():
        def install_subssupport_callback(answer):
            if answer:
                session.openWithCallback(
                    lambda ret: continueToMainScreen(),
                    Console,
                    _("Installing SubsSupport..."),
                    ['wget -q "--no-check-certificate" https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh']
                )
            else:
                continueToMainScreen()

        if not Subs_installed:
            session.openWithCallback(
                install_subssupport_callback,
                MessageBox,
                _("SubsSupport plugin is not installed.\nInstall it now?"),
                MessageBox.TYPE_YESNO,
                default=True
            )
        else:
            continueToMainScreen()

    def ask_install_tmdb():
        def install_tmdb_callback(answer):
            if answer:
                session.openWithCallback(
                    lambda ret: ask_install_subssupport(),
                    Console,
                    _("Installing TMDB..."),
                    ['wget https://raw.githubusercontent.com/biko-73/TMBD/main/installer.sh -O - | /bin/sh']
                )
            else:
                ask_install_subssupport()

        if not TMDB_installed:
            session.openWithCallback(
                install_tmdb_callback,
                MessageBox,
                _("TMDB plugin is not installed.\nInstall it now?"),
                MessageBox.TYPE_YESNO,
                default=True
            )
        else:
            ask_install_subssupport()

    def create_symlink_callback(answer):
        if answer:
            cmds = [
                'mv "%s" "%s"' % (source_path, target_path),
                'ln -s "%s" "%s"' % (target_path, source_path),
                'killall -9 enigma2'
            ]
            session.openWithCallback(
                lambda ret=None: ask_install_tmdb(),
                Console,
                _("Creating TorrServer symlink..."),
                cmds
            )
        else:
            ask_install_tmdb()

    def install_binary_callback(answer):
        if not answer:
            ask_install_tmdb()
            return

        try:
            arch_raw = subprocess.check_output('uname -m; exit 0', shell=True).strip()
            arch = six.ensure_str(arch_raw)

            arch_map = {
                "armv7l": "linux-arm7",
                "aarch64": "linux-arm64",
                "armv8": "linux-arm64",
                "hi3798mv200": "linux-arm7",
                "hi3798mv100": "linux-arm7",
                "mips": "linux-mipsle",
                "mipsle": "linux-mipsle",
                "mips64": "linux-mips64",
                "mips64el": "linux-mips64le",
                "i686": "linux-386",
                "x86_64": "linux-amd64"
            }

            link_key = arch_map.get(arch)
            if not link_key:
                session.open(MessageBox, _("Unsupported CPU architecture: %s") % arch, MessageBox.TYPE_ERROR)
                return

            http = urllib3.PoolManager(headers={'User-Agent': 'Mozilla/5.0', 'Accept-Encoding': 'gzip'})
            response = http.request('GET', repolist)

            if response.status != 200:
                raise Exception("Failed to fetch repolist (HTTP %s)" % response.status)

            repo_data = json.loads(response.data.decode('utf-8'))
            new_ver = repo_data.get('version')
            links = repo_data.get('links')
            url = links.get(link_key) if links else None

            if not new_ver or not url:
                raise Exception("Invalid repo JSON: missing version or link")

            cmds = [
                'echo "Downloading TorrServer..."',
                'wget -O "%s" "%s"' % (target, url),
                'chmod 755 "%s"' % target,
                'killall -9 enigma2'
            ]

            session.openWithCallback(
                lambda ret: ask_install_tmdb(),
                Console,
                _("Installing TorrServer..."),
                cmds
            )

        except Exception as e:
            session.open(MessageBox, _("Failed to install TorrServer:\n%s") % str(e), MessageBox.TYPE_ERROR)

    if os.path.isfile(source_path):
        ask_install_tmdb()
    elif os.path.isfile(target_path):
        session.openWithCallback(
            create_symlink_callback,
            MessageBox,
            _("TorrServer binary found in 'transmission' folder.\nDo you want to create a symlink in /usr/bin?"),
            MessageBox.TYPE_YESNO,
            default=True
        )
    else:
        session.openWithCallback(
            install_binary_callback,
            MessageBox,
            _("TorrServer is not installed.\nDo you want to download and install it now?"),
            MessageBox.TYPE_YESNO,
            default=True
        )


def eventInfo(session, event=None, service=None, *args, **kwargs):
    """Fetch and handle event information from TMDb based on the event name or current service name."""
    event_name = event.getEventName() if event else get_current_event_name(session)

    if event_name:
        try:
            # Fetch TMDb search results
            tv_show, media_type = fetch_tmdb_data(event_name)

            # Process the results based on media type
            if media_type == 'movie':
                handle_movie(session, tv_show)
            elif media_type == 'tv':
                handle_tv_show(session, tv_show)
        except Exception as e:
            logdata('Error in eventInfo:', str(e))
    else:
        logdata('No valid event name found.')

def get_current_event_name(session):
    """Gets the current service event name if no specific event is provided."""
    s = session.nav.getCurrentService()
    if s:
        info = s.info()
        event = info.getEvent(0)
        return event and event.getEventName() or ''
    return ''

def fetch_tmdb_data(query):
    """Fetch TMDb search results for the given query."""
    url = 'https://api.themoviedb.org/3/search/multi?api_key=3c3efcf47c3577558812bb9d64019d65&query={}'.format(query)
    response = requests.get(url, verify=False)
    data = response.json()

    if 'results' in data and data['results']:
        tv_show = data['results'][0]
        media_type = tv_show.get('media_type', '')
        return tv_show, media_type
    else:
        raise ValueError("No results found in TMDb for query: {}".format(query))

def handle_movie(session, tv_show):
    """Handles movie data by opening the TransmissionMovieBrowserGrid."""
    title = tv_show.get('title', 'Unknown Title')
    text = _('Searching [ {} ] Data Please Wait ...').format(title)
    base_url = 'https://yts.lt/api/v2/list_movies.json?query_term={}&page='.format(title)

    # Use reactor to ensure it runs on the main thread
    reactor.callFromThread(check_url_connectivity, session, base_url, lambda: session.openWithCallback(boundFunction(searchCallback, session, title), TransmissionMovieBrowserGrid, base_url, text))

def handle_tv_show(session, tv_show):
    """Handles TV show data by fetching IMDb ID and opening TvSearch."""
    tmdb_id = tv_show.get('id', '')
    name = tv_show.get('name', 'Unknown TV Show')
    imdb_id = get_imdb_id_from_tmdb(tmdb_id)

    if imdb_id:
        base_url = 'https://eztvx.to/api/get-torrents?imdb_id={}&page='.format(imdb_id)
        text = _('Searching [ {} ] Data. Please Wait...').format(name)

        # Ensure it runs on the main thread
        reactor.callFromThread(check_url_connectivity, session, base_url, lambda: session.open(TvSearch, base_url, text))

def get_imdb_id_from_tmdb(tmdb_id):
    """Fetches IMDb ID for a TV show using its TMDb ID."""
    url = 'https://api.themoviedb.org/3/tv/{}/external_ids?api_key=3c3efcf47c3577558812bb9d64019d65'.format(tmdb_id)
    try:
        response = requests.get(url, verify=False)
        data = response.json()
        imdb_id = data.get('imdb_id', None)
        if imdb_id and imdb_id.startswith('tt'):
            imdb_id = imdb_id[2:]  # Remove the 'tt' prefix
        return imdb_id
    except requests.RequestException as e:
        logdata('Error fetching IMDb ID from TMDb:', str(e))
        return None



def searchCallback(session, retValue):
    if 'Event' in session.current_dialog:  # Check if the dialog exists
        CHANGED_ALL = 1
        session.current_dialog['Event'].changed((CHANGED_ALL, 'force_changed'))

    # Close only if it's the current screen
    if session.current_dialog:
        session.close(session.current_dialog)


def extern(session, **kwargs):
    session.open(MainScreen2)

def seriesExt(session, **kwargs):
    session.open(MainScreenEz)


def Transmission_menu(menuid, **kwargs):
    if menuid == 'mainmenu':
        return [(_('Transmission'), main, 'transmission', 11)]
    return []
