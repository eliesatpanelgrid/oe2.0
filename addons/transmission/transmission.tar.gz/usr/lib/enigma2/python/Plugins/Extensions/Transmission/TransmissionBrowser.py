#!/usr/bin/python
# -*- coding: utf-8 -*-
from Components.config import config, ConfigSubsection, ConfigInteger, ConfigText, ConfigNumber, ConfigYesNo, ConfigSelection, ConfigOnOff, configfile, getConfigListEntry, ConfigDirectory, ConfigLocations
from Components.ActionMap import ActionMap
from Components.AVSwitch import AVSwitch
from Components.Label import Label
from Components.Pixmap import Pixmap, MultiPixmap
from Components.ProgressBar import ProgressBar
from Components.Sources.List import List
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.ConfigList import ConfigListScreen
from Components.PluginComponent import plugins
from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, fileExists, SCOPE_PLUGINS
from Tools.LoadPixmap import LoadPixmap
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Screens.InfoBar import InfoBar, MoviePlayer
from Screens.InfoBarGenerics import InfoBarShowHide, InfoBarSeek, InfoBarSubtitleSupport
from Screens.LocationBox import LocationBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from enigma import (loadPNG, loadJPG, eServiceReference, eServiceCenter, RT_HALIGN_CENTER,
                    RT_VALIGN_TOP, RT_WRAP, eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT,
                    eTimer, ePixmap, ePicLoad, eSize, getDesktop, iPlayableService, eAVSwitch)
try:
    from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO, BT_HALIGN_CENTER, BT_VALIGN_CENTER
except:
    pass
import logging, tempfile, shutil, zipfile, time, pickle, hashlib, datetime
import base64, subprocess, os, re, json, requests, time, ssl, tempfile, six, urllib3, glob, traceback, ast, sys
from json import dumps
import threading
from bs4 import BeautifulSoup
from six import ensure_str
from twisted.internet import reactor, defer
from twisted.internet.threads import deferToThread
from threading import Thread, Lock, Event
from twisted.internet import threads
from itertools import cycle, islice
from datetime import datetime
from PIL import Image

try:
    LANCZOS = Image.Resampling.LANCZOS
except AttributeError:
    try:
        LANCZOS = Image.ANTIALIAS
    except AttributeError:
        LANCZOS = Image.LANCZOS
import logging
from twisted.python.failure import Failure
try:
    from Plugins.SystemPlugins.ServiceApp.plugin import ServiceAppSettings
    ServiceApp_installed = True
except:
    ServiceApp_installed = False
from .SubSengine import SubtitleProvider
from . import EmissionOverview
from .torrmgr import torrsrv
from . import _, getSkin, medialist, TorrePlayer_skin
from .Loading import Loading
from .xStaticText import StaticText
from .torrmgr.urlrequest import request_url
from .torrmgr.tmdb import tmdb_query, constants
from .torrmgr.search_parsers import rutor
from collections import OrderedDict
from twisted.web import server, resource, static
try:
    from Plugins.Extensions.AJPan.plugin import *
    AJPan_installed = True
except:
    AJPan_installed = False
try:
    from urllib import quote  # Python 2
except ImportError:
    from urllib.parse import quote  # Python 3

try:
    from enigma import eAVSwitch
except Exception:
    from enigma import eAVControl as eAVSwitch
import tempfile
try:
    from Plugins.Extensions.TMBD.plugin import TMBD
    from Plugins.Extensions.TMBD.tmbdYTTrailer import TmbdYTTrailerList
    TMDB_installed = True
except:
    TMDB_installed = False

try:
    from Plugins.Extensions.SubsSupport.subtitlesdvb import SubsSupportDVB
    from Plugins.Extensions.SubsSupport import SubsSupport, SubsSupportStatus, initSubsSettings
    from Plugins.Extensions.SubsSupport.subtitles import E2SubsSeeker, SubsSearch, initSubsSettings, SubsStatusScreen, SubsSearchParamsMenu, SubsMenu
    Subs = True
except ImportError:
    Subs = False
    class SubsSupport(object):
        def __init__(self, *args, **kwargs):
            pass

    class SubsSupportStatus(object):
        def __init__(self, *args, **kwargs):
            pass


arch = subprocess.check_output('uname -m', shell=True).decode().strip()
ostende = '/usr/lib/enigma2/python/Plugins/Extensions/Transmission'

class TransmissionLCDSummary(Screen):
    def __init__(self, session, parent):
        Screen.__init__(self, session)
        self.skin = getSkin('TransmissionLCDSummary')
        self.parent = parent
        self["lcd_title"] = Label("Transmission")
        self["lcd_line1"] = Label("")
        self["lcd_line2"] = Label("")
        self["lcd_line3"] = Label("")
        self["lcd_page"] = Label("")
        self["lcd_poster"] = Pixmap()
        self["lcd_backdrop"] = Pixmap()
        self["lcd_section"] = Label("")
        self["lcd_rating"] = Label("")
        from Components.Sources.Progress import Progress
        self["lcd_progress"] = Progress(0)
        self.onShow.append(self.updateSummary)

    def updateSummary(self):
        try:
            if hasattr(self.parent, "getLCDSummary"):
                info = self.parent.getLCDSummary() or {}
            else:
                info = {}
            self["lcd_title"].setText(info.get("title", "Transmission"))
            self["lcd_line1"].setText(info.get("line1", ""))
            self["lcd_line2"].setText(info.get("line2", ""))
            self["lcd_line3"].setText(info.get("line3", ""))
            self["lcd_page"].setText(info.get("page", ""))
            self["lcd_section"].setText(info.get("section", ""))
            self["lcd_rating"].setText(info.get("rating", ""))

            # Handle Poster (kept for compatibility or if needed)
            poster_path = info.get("poster", "")
            if poster_path and os.path.exists(poster_path):
                self["lcd_poster"].instance.setPixmapFromFile(poster_path)
                self["lcd_poster"].show()
            else:
                self["lcd_poster"].hide()

            # Handle Backdrop
            backdrop_path = info.get("backdrop", "")
            if backdrop_path and os.path.exists(backdrop_path):
                self["lcd_backdrop"].instance.setPixmapFromFile(backdrop_path)
                self["lcd_backdrop"].show()
            else:
                self["lcd_backdrop"].hide()

            self["lcd_progress"].setValue(int(info.get("progress", 0)))
        except Exception as e:
            logdata("LCDSummary error", e)

def logdata(label_name='', data=None):
    try:
        data = str(data)
        fp = open('/tmp/transmission_browser.log', 'a')
        fp.write(str(label_name) + ' : ' + data + '\n')
        fp.close()
    except:
        logdata()

def logdata3(label_name='', data=None):
    try:
        with open('/tmp/rating.log', 'a') as fp:
            fp.write(str(label_name) + ' : ' + str(data) + '\n')
    except Exception as e:
        print("Logging failed:", e)


def setup_logging():
    logger = logging.getLogger('TransmissionPlugin')
    logger.setLevel(logging.DEBUG)
    handler = logging.FileHandler('/tmp/TransmissionPlugin.log')
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger

logger = setup_logging()


def get_movie_data(id):
    url = 'https://yts-subs.com/movie-imdb/' + str(id)
    logdata('Fetching data from URL: ' + url)
    response = requests.get(url, verify=False)
    soup = BeautifulSoup(response.content, 'html.parser')
    title_div = soup.find('h2', class_='movie-main-title')
    title = title_div.text.strip() if title_div else 'Unknown Title'
    logdata('Title: ' + title)
    year_div = soup.find('div', id='circle-score-year')
    year_data = year_div.get('data-text') if year_div else None
    year = year_data.strip() if year_data else 'Unknown Year'
    logdata('Year: ' + year)
    rating_div = soup.find('div', id='circle-score-imdb')
    rating_span = rating_div.get('data-text') if rating_div else None
    rating = rating_span.strip() if rating_span else 'Unknown Rating'
    logdata('Rating: ' + rating)
    genres_div = soup.find('div', class_='movie-genre')
    genres = genres_div.text.strip().split(',') if genres_div else []
    logdata('Genres: ' + str(genres))
    description_div = soup.find('div', class_='movie-desc')
    description = description_div.text.strip() if description_div else 'No Description'
    logdata('Description: ' + description)
    subtitles_rows = soup.find_all('tr', class_='high-rating')
    subtitles = []
    for row in subtitles_rows:
        try:
            language = row.find('span', class_='sub-lang').text.strip()
            title_part = row.find('a', class_='subtitle-download').text.strip()
            data_id = row.get('data-id', None)
            subtitle_download_link = 'https://yts-subs.com' + row.find('a', class_='subtitle-download')['href']
            response_subtitle = requests.get(subtitle_download_link, verify=False)
            soup_subtitle = BeautifulSoup(response_subtitle.content, 'html.parser')
            subtitle_download_link_final = soup_subtitle.find('a', id='btn-download-subtitle').get('data-link', None)
            if subtitle_download_link_final:
                subtitle_download_link_final = base64.b64decode(subtitle_download_link_final).decode('utf-8')
                subtitles.append(language + ': ' + subtitle_download_link_final)
            else:
                subtitles.append(language + ': No Download Link')
        except Exception as e:
            logdata('Error processing subtitle for ' + language + ': ' + str(e))
            subtitles.append(language + ': Error')

    return {'title': title, 'year': year,
       'rating': rating,
       'genres': genres,
       'description': description,
       'subtitles': subtitles}

def resize_image(input_path, output_path, size=(251, 367)):
    try:
        img = Image.open(input_path)
        img.load()
        img = img.convert('RGBA') if img.mode in ('RGBA', 'LA') else img.convert('RGB')
        img = img.resize(size, LANCZOS)
        ext = os.path.splitext(output_path)[1].lower()
        if ext == '.png':
            img.save(output_path, format='PNG')
        else:
            img.save(output_path, format='JPEG')
        return True
    except Exception as e:
        logdata('Error resizing image:', str(e))
        return False

def save_to_json(file_path, data):
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            json_data = json.load(file)
    else:
        json_data = {'movies': {}}
    title = data['title']
    json_data['movies'][title] = data
    with open(file_path, 'w') as file:
        json.dump(json_data, file, indent=4, ensure_ascii=False)


VIDEO_ASPECT_RATIO_MAP = {
    0: "4:3 Letterbox",
    1: "4:3 PanScan",
    2: "16:9",
    3: "16:9 Always",
    4: "16:10 Letterbox",
    5: "16:10 PanScan",
    6: "16:9 Letterbox"
}

def sanitize_path(path):
    """Remove trailing slash from path unless it's root '/'."""
    if path != '/':
        return path.rstrip('/')
    return path


vodstreamtypelist = ["4097"]

if os.path.exists("/usr/bin/gstplayer"):
    vodstreamtypelist.append("5001")
if os.path.exists("/usr/bin/exteplayer3"):
    vodstreamtypelist.append("5002")

ts = torrsrv.torrserver()
torrsettings = torrsrv.torrsettings()
ts.srv_timeout = 5
context = ssl._create_unverified_context()
screenWidth = getDesktop(0).size().width()
screenwidth2 = getDesktop(0).size()
# Check the platform based on /etc/issue
imgr = ""
img = "/etc/issue"
if os.path.exists(img):
    with open(img, "r") as f:
        imgr = f.read().lower()





vod_player_list = [
    ('transmission', _('Transmission Player')),
    ('enigma', _('Enigma2 Player')),
    ('ajpanel', _('AJPanel Player'))
]

vod_choices = [choice for choice in vod_player_list if (choice[0] != 'ajpanel' or AJPan_installed)]
# Define available skin choices
all_skin_choices = [
    ('carousel', _('Carousel')),
    ('grid', _('Grid')),
    ('horizontal', _('Horizontal')),
    ('list_old', _('Classic List')),
    ('list_new', _('List vertical left'))
]

all_skin_tv_choices = [
    ('EZTV_grid', _('Grid')),
    ('EZTV_horizontal', _('Horizontal')),
    ('EZTV_banner', _('Banner'))
]
if any(x in imgr for x in ["teamblue"]):
    skin_choices = [choice for choice in all_skin_choices if choice[0] != 'grid']  # Remove 'grid'
    skin_tv_choices = [choice for choice in all_skin_tv_choices if choice[0] != 'EZTV_grid']  # Remove 'EZTV_grid'
else:
    skin_choices = all_skin_choices
    skin_tv_choices = all_skin_tv_choices

# Config initialization
config.plugins.torreplayer = ConfigSubsection()
config.plugins.torreplayer.autostart = ConfigOnOff(default=True)
config.plugins.torreplayer.bacdrop = ConfigOnOff(default=True)
config.plugins.torreplayer.show_in_menu = ConfigOnOff(default=False)
config.plugins.torreplayer.skins = ConfigSelection(default='horizontal' if 'grid' not in [c[0] for c in skin_choices] else 'grid', choices=skin_choices)
config.plugins.torreplayer.skins_tv = ConfigSelection(default='EZTV_horizontal' if 'EZTV_grid' not in [c[0] for c in skin_tv_choices] else 'EZTV_grid', choices=skin_tv_choices)
config.plugins.torreplayer.proxy = ConfigYesNo(default=False)
config.plugins.torreplayer.proxy_type = ConfigSelection(default='cors', choices=[('cors', _('CORS Proxy (Recommended)')), ('ip', _('IP:Port Proxy'))])
config.plugins.torreplayer.items = ConfigSelection(default='48', choices=[('6', _('6')), ('12', _('12')), ('24', _('24')), ('48', _('48')), ('96', _('100'))])
config.plugins.torreplayer.vod_screen = ConfigSelection(default='transmission', choices=vod_choices)
config.plugins.torreplayer.onMovieEof = ConfigSelection(default='ask', choices=[('ask', _('Ask user')), ('quit', _('Return to list'))])
config.plugins.torreplayer.onMovieStop = ConfigSelection(default='ask', choices=[('ask', _('Ask user')), ('quit', _('Return to list'))])
config.plugins.torreplayer.tmdblng = ConfigSelection(
    default='ar',
    choices=[
        ('nl', _('Nederland')),
        ('ar', _('Arabic')),
        ('en', _('English')),
        ('fr', _('French')),
        ('de', _('Deutsch')),
        ('it', _('Italian')),
        ('es', _('Spanish')),
        ('pt', _('Portuguese')),
        ('ru', _('Russian')),
        ('zh', _('Chinese')),
        ('ja', _('Japanese')),
        ('ko', _('Korean')),
        ('tr', _('Turkish'))
    ]
)
config.plugins.torreplayer.subslng = ConfigSelection(
    default='arabic',
    choices=[
        ('nederland', _('Nederland')),
        ('arabic', _('Arabic')),
        ('english', _('English')),
        ('french', _('French')),
        ('deutsch', _('Deutsch'))
    ]
)
# Conditional player choices based on ServiceApp installation
if ServiceApp_installed:
    config.plugins.torreplayer.player = ConfigSelection(default='5002', choices=[('4097', _('Default [4097]')), ('5002', _('Exteplayer [5002]')), ('5001', _('Gstplayer [5001]'))])
else:
    config.plugins.torreplayer.player = ConfigSelection(default='4097', choices=[('4097', _('Default [4097]'))])
config.plugins.torreplayer.buffer = ConfigSelection(default='0', choices=[("0", _("No Buffering(0)")), ("1", _("Buffering Enabled(1)")), ("3", _("Progressive Buffering(3)"))])
config.plugins.torreplayer.subdl_api = ConfigText(default='Enter your Api', visible_width=30, fixed_size=False)
config.plugins.torreplayer.serv_url = ConfigText(default='http://127.0.0.1:8090', visible_width=30, fixed_size=False)
config.plugins.torreplayer.rememberlastsearch = ConfigYesNo()
config.plugins.torreplayer.rememberlastsearchyts = ConfigYesNo()
config.plugins.torreplayer.rememberlastsearchyts_tv = ConfigYesNo()
config.plugins.torreplayer.lastsearch = ConfigText(default='')
config.plugins.torreplayer.lastsearchyts = ConfigText(default='')
config.plugins.torreplayer.lastsearchyts_tv = ConfigText(default='')
config.plugins.torreplayer.lastPosition = ConfigText(default='[]')
config.plugins.torreplayer.config_path = ConfigDirectory('/etc/enigma2')
config.plugins.torreplayer.config_bookmarks = ConfigLocations(default=medialist + ['/home/root', '/etc/enigma2'])
config.plugins.torreplayer.poster_path = ConfigDirectory(sanitize_path('/media/hdd'))
config.plugins.torreplayer.poster_bookmarks = ConfigLocations(default=[sanitize_path(m) for m in medialist + ['/media/hdd']])
config.plugins.torreplayer.torrent_disconnect_timeout = ConfigInteger(default=60, limits=(10, 600))
config.plugins.torreplayer.download_rate_limit = ConfigInteger(default=0, limits=(0, 1000000))  # 0 = unlimited
config.plugins.torreplayer.upload_rate_limit = ConfigInteger(default=0, limits=(0, 1000000))
config.plugins.torreplayer.connections_limit = ConfigInteger(default=200, limits=(1, 10000))
config.plugins.torreplayer.cache_size = ConfigInteger(default=64, limits=(8, 2048))
config.plugins.torreplayer.preload_buffer = ConfigInteger(default=20, limits=(1, 100))
config.plugins.torreplayer.use_disk = ConfigYesNo(default=True)
config.plugins.torreplayer.remove_cache = ConfigYesNo(default=True)
config.plugins.torreplayer.reader_read_ahead = ConfigInteger(default=8, limits=(1, 100))
ts.url = config.plugins.torreplayer.serv_url.value
torrserver_path = '/usr/bin/TorrServer'
repolist = 'https://releases.yourok.ru/torr/server_release.json'
plugin_version = '5.4.2'
transmission_version = '4.1.0'
DEBUG = False
log_file = '/tmp/torreplayer.log'
TMDB_API_KEY = '3c3efcf47c3577558812bb9d64019d65'

# Import proxy manager
try:
    from .proxy_manager import get_proxy_manager, make_proxied_request
    PROXY_MANAGER_AVAILABLE = True
except ImportError:
    PROXY_MANAGER_AVAILABLE = False
    logger.warning("Proxy manager not available")

def get_proxied_url(url, proxy_index=0):
    """
    Returns a proxied URL using proxy manager or fallback CORS proxies.
    """
    if PROXY_MANAGER_AVAILABLE and config.plugins.torreplayer.proxy.value:
        proxy_manager = get_proxy_manager()
        use_cors = (config.plugins.torreplayer.proxy_type.value == 'cors')
        return proxy_manager.get_proxied_url(url, use_cors=use_cors)

    # Fallback to old method
    PROXY_SERVICES = [
        "https://api.codetabs.com/v1/proxy?quest=",
        "https://cors.eu.org/",
        "https://corsproxy.io/?",
    ]
    if proxy_index >= len(PROXY_SERVICES):
        return url
    proxy = PROXY_SERVICES[proxy_index]
    return proxy + quote(url, safe='')

def make_request_with_proxy(url, headers=None, timeout=15, **kwargs):
    """
    Make a request with automatic proxy support if enabled.
    """
    if PROXY_MANAGER_AVAILABLE and config.plugins.torreplayer.proxy.value:
        use_cors = (config.plugins.torreplayer.proxy_type.value == 'cors')
        response = make_proxied_request(url, headers=headers, timeout=timeout, use_cors=use_cors, **kwargs)
        if response:
            return response

    # Fallback to direct request
    try:
        return requests.get(url, headers=headers, timeout=timeout, verify=False, **kwargs)
    except Exception as e:
        logger.error("Direct request failed: %s", str(e))
        return None


def run_AJPanel_api(action, dictData=None):
    try:
        from Plugins.Extensions.AJPan.plugin import CCMTfv
        if not CCMTfv.VVy1jd():
            CCMTfv.VVeTpx(None, True)
        port = config.plugins.AJPanel.wsPort.value
    except:
        return "", "Latest AJPanel is not installed or Server not running"
    url = "http://127.0.0.1:%s/%s" % (port, action)
    try:
        # Use json=dictData for proper JSON handling
        r = requests.post(url, json=dictData, timeout=3, headers={"Accept": "text/plain"})
        return r.text, ""
    except requests.Timeout:
        return "", "Connection Timeout"
    except requests.ConnectionError:
        return "", "Connection Error"
    except Exception as e:
        return "", "Error: %s" % e



def logdata2(label_name='', data=None):
    try:
        data = str(data)
        fp = open('/tmp/torreplayer.log', 'a')
        fp.write(str(label_name) + ' : ' + data + '\n')
        fp.close()
    except:
        logdata2()


def write_log(value):
    with open(log_file, 'a') as (f):
        f.write('%s\n' % value)


def get_pid(name):
    try:
        return subprocess.check_output(['pidof', name])
    except subprocess.CalledProcessError:
        return False


def get_version():
    try:
        ver = subprocess.check_output(torrserver_path + ' --version', shell=True)
        match = re.match('TorrServer (.*)', six.ensure_str(ver))
        return str(match.group(1).strip())
    except subprocess.CalledProcessError:
        return 'no version'


def start_server():
    if os.path.isfile(torrserver_path):
        server_port = config.plugins.torreplayer.serv_url.value.split(':')[-1]
        fh = open(os.devnull, 'wb')
        os.system('export GODEBUG=madvdontneed=1')
        args = [torrserver_path,
         '--port',
         server_port,
         '--path',
         config.plugins.torreplayer.config_path.value]
        p = subprocess.Popen(args, shell=False, stdout=fh, stderr=fh)
        fh.close()
        time.sleep(0.5)


def stop_server():
    os.system('killall -9 TorrServer')
    time.sleep(0.5)


def download_file(url, fileToSave, attr='u=rx,g=r,o=r'):
    retval = False
    content = request_url(url, context=context)
    if content:
        try:
            with open(fileToSave, 'wb') as (f):
                f.write(content['data'])
            time.sleep(0.5)
            if os.path.isfile(fileToSave):
                if os.path.getsize(fileToSave) > 0:
                    subprocess.call(['chmod', attr, fileToSave])
                    retval = True
                else:
                    os.path.remove(fileToSave)
        except:
            pass

    return retval

def _u8(s):
    if sys.version_info[0] >= 3:
        if isinstance(s, bytes):
            return s.decode("utf-8", "ignore")
        return str(s) if s is not None else ""
    else:
        try:
            if isinstance(s, unicode):
                return s.encode("utf-8", "ignore")
        except:
            pass
        return s

def get_status():
    if os.path.isfile(torrserver_path) == False:
        return (_('TorrServer not installed :('), '', _('Install'))
    else:
        if get_pid('TorrServer'):
            return (_('TorrServer:  ') + get_version(), _('Stop'), _('Check updates'))
        return (_('TorrServer:  ') + _('down :('), _('Start'), _('Check updates'))


def search_tmdb(search_topic):
    src = tmdb_query()
    src.cleaning = True
    src.search_mode = constants.sort_fullin
    src.query = search_topic
    src.api_key = '7bff10009e7deed9307ad50c67270b6b'
    src.sort_mode = constants.sort_ratio
    src.search_language = config.plugins.torreplayer.tmdblng.value
    return src.select_tmdb_info()


def pretty_size(size):
    """ выводит размер файла в подходящих единицах
    size - размер в байтах, результат - строка"""
    units = [
     _('B'),
     _('KB'),
     _('MB'),
     _('GB')]
    unit = 0
    while size >= 1024 and unit < len(units):
        size /= 1024.0
        unit += 1

    return '%0.2f %s' % (size, units[unit])


def select_torrents(search_topic):
    items_torrs = []
    s_obj = rutor()
    s_obj.query = search_topic
    if s_obj.search():
        for one in s_obj.rts_infos:
            items_torrs.append({'title': one.name, 'source': 'rutor',
               'size': one.size,
               'date': one.date,
               'magnet': one.magnet,
               'seeders': str(one.seeders),
               'leechers': str(one.leechers)})

    return items_torrs


def save_last_position(list=[]):
    config.plugins.torreplayer.lastPosition.value = str(list)
    config.plugins.torreplayer.lastPosition.save()

class PVRState2(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self["eventname"] = Label('')
        self["state"] = Label('')
        self["speed"] = Label('')
        self["statusicon"] = MultiPixmap()

PVRState = PVRState2

class IPTVInfoBarPVRState:
    def __init__(self, screen=PVRState, force_show=True):
        self.onChangedEntry = []
        self.onPlayStateChanged.append(self.__playStateChanged)
        self.pvrStateDialog = self.session.instantiateDialog(screen)
        self.onShow.append(self._mayShow)
        self.onHide.append(self.pvrStateDialog.hide)
        self.force_show = force_show

    def _mayShow(self):
        if "state" in self and not self.force_show:
            self["state"].setText("")
            self["statusicon"].setPixmapNum(6)
            self["speed"].setText("")
        if self.shown and self.seekstate != self.SEEK_STATE_EOF and not self.force_show:
            self.pvrStateDialog.show()
            self.startHideTimer()

    def __playStateChanged(self, state):
        playstateString = state[3]
        state_summary = playstateString

        if "statusicon" in self.pvrStateDialog:
            self.pvrStateDialog["state"].setText(playstateString)
            speedtext = ""
            self.pvrStateDialog["speed"].setText("")
            speed_summary = self.pvrStateDialog["speed"].text
            if playstateString:
                if playstateString == ">":
                    statusicon_summary = 0
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)

                elif playstateString == "||":
                    statusicon_summary = 1
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)

                elif playstateString == "END":
                    statusicon_summary = 2
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)

                elif playstateString.startswith(">>"):
                    speed = state[3].split()
                    statusicon_summary = 3
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)
                    self.pvrStateDialog["speed"].setText(speed[1])
                    speedtext = speed[1]

                elif playstateString.startswith("<<"):
                    speed = state[3].split()
                    statusicon_summary = 4
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)
                    self.pvrStateDialog["speed"].setText(speed[1])
                    speedtext = speed[1]

                elif playstateString.startswith("/"):
                    statusicon_summary = 5
                    self.pvrStateDialog["statusicon"].setPixmapNum(statusicon_summary)
                    self.pvrStateDialog["speed"].setText(playstateString)

                    speedtext = playstateString

            if "state" in self and self.force_show:
                self["state"].setText(playstateString)
                self["statusicon"].setPixmapNum(statusicon_summary)
                self["speed"].setText(speedtext)

            for cb in self.onChangedEntry:
                cb(state_summary, speed_summary, statusicon_summary)

class TorrPlayer(MoviePlayer, IPTVInfoBarPVRState, SubsSupport, SubsSupportStatus, InfoBarSubtitleSupport):

    def __init__(self, session, service, current, poster, streamurl, dfposter, source, name, streamMode=False, askBeforeLeaving=False):
        MoviePlayer.__init__(self, session, service)
        InfoBarSubtitleSupport.__init__(self)
        IPTVInfoBarPVRState.__init__(self, PVRState, True)
        self.skin = getSkin('TransmissionVodplayer')
        self.skinName = 'TransmissionVodplayer'
        self.statusicon_summary = 0
        self.current = current
        self.servicetype = source
        self.streamurl = streamurl
        self.name = name
        self.streamMode = streamMode
        self.askBeforeLeaving = askBeforeLeaving
        self.servicelist = InfoBar.instance and InfoBar.instance.servicelist
        self.filename = poster
        self.default = dfposter
        self.started = False
        self.__PlayStarted = False
        self.__VideoSizeStr = ''
        self.__Bitrate = 0
        self.lastPosition = []
        self["streamcat"] = StaticText()
        self["streamtype"] = StaticText()
        self["extension"] = StaticText()
        self["cover"] = Pixmap()
        self["eventname"] = Label('')
        self["state"] = Label('')
        self["speed"] = Label('')
        self["statusicon"] = MultiPixmap()
        self["PTSSeekBack"] = Pixmap()
        self["PTSSeekPointer"] = Pixmap()
        self['LabelVideoPara'] = StaticText()
        self.PicLoad = ePicLoad()
        self.PicLoad.PictureData.get().append(self.DecodePicture)
        self.ar_id_player = 0
        self.srt_loaded = False
        self.setup_title = _("VOD")
        self["actions"] = ActionMap(
            ["TorrePlayerActions"],
            {
                "cancel": self.leavePlayerOnExit,
                "stop": self.leavePlayer,
                "red": self.leavePlayer,
                "blue": self.subplayer,
                "tv": self.toggleStreamType,
                "info": self.toggleStreamType,
                "green": self.nextAR,
                "video_but": self.startWithPvrButton,
            },
            -2
        )
        IPTVInfoBarPVRState.__init__(self, PVRState, True)
        ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evStart: self.__torrentStart,
            iPlayableService.evVideoSizeChanged: self.__torrentStart,
        })
        if Subs:
            try:
                def initSubtitleConfig():
                    if not hasattr(config, 'subtitles'):
                        config.subtitles = ConfigSubsection()
                    if not hasattr(config.subtitles, 'embeddedFontSize'):
                        config.subtitles.subtitle_fontsize = ConfigSelection(
                            default="24", choices=["18", "20", "22", "24", "26", "28", "30"]
                        )

                initSubtitleConfig()  # <-- This is important!
                initSubsSettings()
                SubsSupport.__init__(self, searchSupport=True, embeddedSupport=True)
                SubsSupportStatus.__init__(self)

            except Exception as e:
                logger.error("Failed to initialize subtitle support: %s" % str(e))

    def subplayer(self):
        if Subs:
            try:
                self.session.open(SubsMenu, self, embeddedSupport=True, searchSupport=True)
            except Exception as e:
                logger.error("Failed to open SubsMenu: %s" % str(e))
                self.session.open(MessageBox, _('Error opening subtitle menu %s' % str(e)), MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, _('SubsSupport Not installed '), MessageBox.TYPE_INFO)

    def startWithPvrButton(self):
        if Subs:
            if self.name:
                settings = initSubsSettings().search
                titleList = [str(self.name)]
                seeker = E2SubsSeeker(self.session, settings)

                def afterParamsClosed(returnValue=None):
                    # If user confirmed the menu, open actual search
                    self.session.open(SubsSearch, seeker, settings, searchTitles=titleList, standAlone=True)

                self.session.openWithCallback(afterParamsClosed, SubsSearchParamsMenu,
                                              seeker, settings, titleList,
                                              resetSearchParams=True,
                                              enabledList=True,
                                              windowTitle=_("Subtitle search options"))
        else:
            self.session.open(MessageBox, _('SubsSupport Not installed '), MessageBox.TYPE_INFO)

    def __torrentStart(self):
        try:
            self.resizeImage()
            if not self.srt_loaded:
                self.loadSRTfromTmp("/tmp")
                self.srt_loaded = True
        except Exception as e:
            logdata("Error resizing image: {}".format(e))
            self.loadDefaultImage()

        if not self.started:
            self.started = True
            self["streamcat"].setText("VOD")
            self["streamtype"].setText(str(self.servicetype))
            self.resizeImage()

            try:
                self["extension"].setText(str(os.path.splitext(self.streamurl)[-1]))
            except KeyError as e:
                logdata("Error setting extension: {}".format(e))

            try:
                self.lastPosition = ast.literal_eval(config.plugins.torreplayer.lastPosition.value)
                for i in self.lastPosition:
                    if i.__contains__(self.current):
                        self.lastPosition.pop(self.lastPosition.index(i))
                        self.seekPosition = int(i.split('*')[1])
                        save_last_position(list=self.lastPosition)
                        self.session.openWithCallback(self.messageBoxCallback, MessageBox, text=_('Resume playback from the previous position?'), timeout=5)
            except SyntaxError:
                logdata('[TorrePlayer] wrong last position config settings!')
                save_last_position()
                self.lastPosition = []
            except Exception as e:
                logdata("Error in handling last position: {}".format(e))

    def messageBoxCallback(self, answer):
        if answer:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if seek:
                seek.seekTo(self.seekPosition)

    def leavePlayerOnExit(self):
        self.is_closing = True
        self.session.openWithCallback(self.leavePlayerOnExitCallback, MessageBox, _('Exit torrent player?'))

    def leavePlayer(self):
        on_movie_stop = config.plugins.torreplayer.onMovieStop.value
        if on_movie_stop == 'ask':
            title = _('Stop playing this movie?')
            clist = ((_('Yes, and return to list'), 'quit'),
             (_('No, but play video again'), 'repeat'),
             (_('No'), 'continue'))
            self.session.openWithCallback(self.leavePlayerConfirmed, ChoiceBox, title=title, list=clist)
        else:
            self.leavePlayerConfirmed([None, on_movie_stop])
        return

    def leavePlayerOnExitCallback(self, answer):
        if answer:
            self.leavePlayerConfirmed([None, 'exit'])
        return

    def leavePlayerConfirmed(self, answer):
        if answer and answer[1] != 'continue':
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if seek:
                if len(self.lastPosition) > 20:
                    self.lastPosition.pop(0)
                playposition = seek.getPlayPosition()[1]
                length = seek.getLength()[1]
                percent = '%d' % ((playposition * 100 - 1) / length)
                self.lastPosition.append('%s*%s*%s' % (self.current, str(playposition), percent))
                save_last_position(list=self.lastPosition)
            self.close(answer)

    def doEofInternal(self, playing):
        if self.execing and playing:
            self.leavePlayerConfirmed([None, config.plugins.torreplayer.onMovieEof.value])
        return

    def showMovies(self):
        pass

    def __evUpdatedBitrate(self):
        try:
            self.__Bitrate = 0
            if self.started:
                self.__PlayStarted = True
                service = self.session.nav.getCurrentService()
                if service:
                    info = service.info()
                    if info:
                        currBitrate = info.getInfo(iServiceInformation.sTagBitrate)
                        if currBitrate > 0:
                            self.__Bitrate = currBitrate
                            text = self.__VideoSizeStr + '  %.2fKbps' % (self.__Bitrate / 1024)
                            self['LabelVideoPara'].setText(text)
        except:
            pass

    def playStream(self, servicetype, streamurl):
        current_service = self.session.nav.getCurrentService()
        if current_service:
            self.session.nav.stopService()
        self.servicetype = servicetype
        self.streamurl = streamurl
        try:
            self.reference = eServiceReference(int(self.servicetype), 0, self.streamurl)
            self.reference.setName(str(self.name))
            self.session.nav.playService(self.reference)
            self["streamcat"].setText("VOD")
            self["streamtype"].setText(str(servicetype))
            self["extension"].setText(str(os.path.splitext(self.streamurl)[-1]))
            self.resizeImage()
        except Exception as e:
            logdata("Error playing stream: ", str(e))
            self.loadDefaultImage()

    def loadSRTfromTmp(self, path="/tmp"):
        try:
            subtitle = self.getCurrentServiceSubtitle()
            if not subtitle:
                logger.debug("No subtitle track service available.")
                return

            srt_files = [f for f in os.listdir(path) if f.endswith('.srt')]
            srt_files.sort()

            for srt in srt_files:
                full_path = os.path.join(path, srt)
                logger.debug("Adding external subtitle: %s", full_path)
                if hasattr(self, 'addExternalSubtitle'):
                    self.addExternalSubtitle(full_path)
                else:
                    logger.warning("addExternalSubtitle method not found on self (SubsSupport not installed?)")

            logger.info("Loaded %d SRT subtitles from %s", len(srt_files), path)
        except Exception as e:
            logger.error("loadSRTfromTmp error: %s", str(e))


    def loadDefaultImage(self, data=None):
        self["cover"].instance.setPixmapFromFile(self.default)

    def resizeImage(self, data=None):
        if self["cover"].instance and self.filename:
            preview = os.path.join(self.filename)

            if screenwidth2.width() == 2560:
                width = 293
                height = 440
            elif screenwidth2.width() > 1280:
                width = 220
                height = 330
            else:
                width = 147
                height = 220

            self.PicLoad.setPara([width, height, 1, 1, 0, 1, "FF000000"])

            if self.PicLoad.startDecode(preview):
                self.PicLoad = ePicLoad()
                self.PicLoad.PictureData.get().append(self.DecodePicture)
                self.PicLoad.setPara([width, height, 1, 1, 0, 1, "FF000000"])
                self.PicLoad.startDecode(preview)
        else:
            logdata("[resizeImage] Warning: 'filename' is None or 'cover' instance is missing")


    def DecodePicture(self, PicInfo=None):
        ptr = self.PicLoad.getData()
        if ptr is not None:
            self["cover"].instance.setPixmap(ptr)
            self["cover"].instance.show()

    def toggleStreamType(self):
        currentindex = 0
        for index, item in enumerate(vodstreamtypelist, start=0):
            if str(item) == str(self.servicetype):
                currentindex = index
                break
        nextStreamType = islice(cycle(vodstreamtypelist), currentindex + 1, None)
        try:
            self.servicetype = int(next(nextStreamType))
            message = 'Stream-Type Changed to ' + self.servicetype
            self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=2)
        except Exception as e:
            logger.error("toggleStreamType error: %s", str(e))
        self.playStream(self.servicetype, self.streamurl)

    def nextARfunction(self):
        self.ar_id_player += 1
        if self.ar_id_player > 6:
            self.ar_id_player = 0
        try:
            eAVSwitch.getInstance().setAspectRatio(self.ar_id_player)
            return VIDEO_ASPECT_RATIO_MAP[self.ar_id_player]
        except Exception as e:
            logdata(e)
            return _("Resolution Change Failed")

    def nextAR(self):
        message = self.nextARfunction()
        self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=2)

InfoBar.MoviePlayer = TorrPlayer


class TorrSearch(Screen):
    def createSummary(self):
        return TransmissionLCDSummary

    def getLCDSummary(self):
        cur = self["menu"].getCurrent()
        title = cur[0] if cur else ""
        return {
            "title": "Transmission – Search",
            "line1": title[:32],
            "line2": "",
            "line3": "",
            "progress": 0,
        }

    def __init__(self, session, search_topic):
        Screen.__init__(self, session)
        self.skin = getSkin('TorrSearch')
        self.search_topic = search_topic
        self.setTitle(_('Search result <*  %s  *>') % self.search_topic)
        self['key_red'] = Label(_('Exit'))
        self.menulist = []
        self['menu'] = List(self.menulist, enableWrapAround=True)
        self['description'] = Label('')
        self['actions'] = ActionMap(['TorrePlayerActions'], {'cancel': self.cancel, 'back': self.cancel,
                                                             'red': self.cancel,
                                                             'ok': self.ok,
                                                             'down': self.keyDown,
                                                             'up': self.keyUp,
                                                             'left': self.keyLeft,
                                                             'right': self.keyRight}, -1)
        self.onLayoutFinish.append(self.createSubList)

    def createSubList(self):
        self.menulist = []
        items = select_torrents(self.search_topic)
        if items:
            for item in items:
                name = item['title']
                source = item['source']
                size = item['size']
                date = item['date']
                magnet = item['magnet']
                logdata2('magnet', magnet)
                seeders = item['seeders']
                leechers = item['leechers']
                peers = 'Peers: ' + leechers + '/' + seeders
                source_date = date + ' / ' + source
                size_bitrate = size
                self.menulist.append((name, magnet, source_date, size_bitrate, peers))

            self['menu'].setList(self.menulist)
        else:
            resp = _('No results were found for "%s"') % self.search_topic
            self.menulist.append((resp, '', '', '', ' '))
            self['menu'].setList(self.menulist)

    def keyRight(self):
        self['menu'].pageDown()

    def keyLeft(self):
        self['menu'].pageUp()

    def keyUp(self):
        self['menu'].selectPrevious()

    def keyDown(self):
        self['menu'].selectNext()

    def cancel(self):
        self.close()

    def ok(self):
        if self['menu'].getCurrent()[1] == '':
            self.close(None)
        else:
            self.name = self['menu'].getCurrent()[0]
            self.magnet = self['menu'].getCurrent()[1]
            title = _('What do you want to do?')
            options = [
                (_('Only add torrent to playlist'), 'onlyadd'),
                (_('Only play torrent'), 'onlyplay'),
                (_('Add torrent to playlist and play'), 'addplay'),
                (_('Download torrent'), 'download')
            ]
            self.session.openWithCallback(self.searchCallback, ChoiceBox, title=title, list=options)

    def searchCallback(self, action=None):
        if action:
            action = action[1]
            if action == 'download':
                file_size = self['menu'].getCurrent()[3]
                self.initiateDownload(self.magnet, file_size, self.name)
            else:
                self.close([None, action, self.name, self.magnet])
        return

    def initiateDownload(self, torrent_link, file_size, title):
        download_path = '{}/transmission'.format(config.plugins.torreplayer.poster_path.value)
        if torrent_link:
            download_limit = '1000000'
            upload_limit = '100'
            rpc_url = 'http://127.0.0.1:9091/transmission/rpc'
            command = ('transmission-remote {} -a "{}" -w "{}" -d {} -u {}').format(rpc_url, torrent_link, download_path, download_limit, upload_limit)
            title = 'Download {}'.format(title)
            self.session.open(Console, title, [command])

class TorrEpisodes(Screen):
    def createSummary(self):
        return TransmissionLCDSummary

    def getLCDSummary(self):
        cur = self["menu"].getCurrent()
        title = cur[0] if cur else ""
        return {
            "title": "Transmission – Episodes",
            "line1": title[:32],
            "line2": "",
            "line3": "",
            "progress": 0,
        }
    def __init__(self, session, titles, filename):
        Screen.__init__(self, session)
        self.skin = getSkin('TorrEpisodes')
        self["pic_loading"] = Pixmap()
        self["int_loading"] = Label('')
        self["msg_loading"] = Label('')
        self.loading = Loading(self["pic_loading"], self["int_loading"], self["msg_loading"], None)
        self.titles = titles
        self.poster = filename
        self.setTitle('   ' + str(self.titles[0]))
        self['key_red'] = Label(_('Exit'))
        self['key_yellow'] = Label(_('Play'))
        self['key_green'] = Label(_('Preload buffer'))
        self['key_blue'] = Label(_('Remove view states'))
        self.thread = None
        self.menulist = []
        self['menu'] = List(self.menulist)
        self['actions'] = ActionMap(['TorrePlayerActions'], {
            'cancel': self.cancel,
            'back': self.cancel,
            'green': self.preload,
            'yellow': self.action,
            'ok': self.action,
            'blue': self.clear
        }, -1)
        self.retry_count = 0
        self.retry_timer = eTimer()
        self.retry_timer.callback.append(self.createSubList)
        self.onLayoutFinish.append(self.startLoading)

    def startLoading(self):
        self.loading.start(10, _("Loading torrent info..."))
        self.retry_timer.start(100, True)

    def createSubList(self):
        self.menulist = []
        try:
            lastPosition = eval(config.plugins.torreplayer.lastPosition.value)
            ts.url = config.plugins.torreplayer.serv_url.value
            self.trnt = ts.get_torrent(self.titles[1])
            if not self.trnt:
                if self.retry_count < 5:
                    self.retry_count += 1
                    self.retry_timer.start(1000, True)
                    return
                else:
                    self.loading.stop(_("Torrent info not found."))
                    return

            if self.trnt:
                for realID, one in enumerate(self.trnt.files):
                    logdata2('tornt files', self.trnt)
                    stream_info = ts.get_stream_url(self.trnt, one.id)
                    logdata2('stream_info', stream_info)
                    stream = stream_info['stream']
                    logdata2('stream', stream)
                    torrepisode = str(one.path)
                    logdata2('torrepisode', torrepisode)
                    if '/' in torrepisode:
                        torrepisode = torrepisode.split('/')[-1]
                    episod = stream.split('?')[1].replace('&play', '')
                    progress = 0
                    for i in lastPosition:
                        if i.split('*')[0] == episod:
                            progress = int(i.split('*')[2])

                    procent = '%02d' % progress + '%'
                    self.menulist.append((torrepisode, stream, pretty_size(one.length), realID, procent, progress))
            self.loading.stop()
        except Exception as e:
            print('[TorrePlayer] wrong config settings!', e)
            self.loading.stop(_("Error loading torrent info."))
        self['menu'].setList(self.menulist)

    def cancel(self):
        self.loading.stop()
        self.close(self.titles[1])

    def clear(self):
        hashToRemove = self.titles[1]
        lastPosition_new = []
        lastPosition = eval(config.plugins.torreplayer.lastPosition.value)
        for i in lastPosition:
            if hashToRemove not in i:
                lastPosition_new.append(i)
        save_last_position(list=lastPosition_new)
        self.createSubList()

    def preload(self):
        self.ostende = self.trnt.files[self['menu'].getCurrent()[3]].id
        if not self.thread and self.ostende:
            self.loading.start(30, _("Preloading buffer..."))
            wait_time = 1
            try:
                self.thread = threads.deferToThread(ts.preload_torrent, self.trnt, self.ostende, wait_time)
                self.thread.addCallback(self.preloadCallback)
                self.thread.addErrback(self.preloadErrback)
            except Exception as e:
                print('[TorrEpisodes] Error starting preload thread:', e)
                self.loading.stop(_("Failed to start preload buffer"))

    def preloadCallback(self, retval):
        print('[TorrEpisodes] Preload completed:', retval)
        self.thread = None
        msg = _("Preload timed out, but you can still start playback.") if retval is None else _("Preload completed successfully.")
        self.loading.stop(msg)

    def preloadErrback(self, failure):
        print('[TorrEpisodes] Preload error:', failure)
        self.thread = None
        self.loading.stop(_("Preload failed"))

    def action(self, currentSelect=None):
        if currentSelect is None and self.menulist:
            currentSelect = str(self['menu'].getCurrent()[1])
            current = currentSelect.split('?')[-1].replace('&play', '')
            video_url = currentSelect
            service = eServiceReference(int(config.plugins.torreplayer.player.value), 0, currentSelect)
            name = self.titles[0]
            service.setName(str(self.titles[0]))
            source = int(config.plugins.torreplayer.player.value)
            poster = self.poster
            dfposter = '/usr/lib/enigma2/python/Plugins/Extensions/Transmission/skins/default.svg'

            # Enigma2 MoviePlayer
            if config.plugins.torreplayer.vod_screen.value == 'enigma':
                self.session.openWithCallback(self.playCallback, MoviePlayer, service=service)

            # Transmission Player
            elif config.plugins.torreplayer.vod_screen.value == 'transmission':
                self.session.openWithCallback(self.playCallback, TorrPlayer, service=service, current=current, poster=self.poster, streamurl=video_url, dfposter=dfposter, source=source, name=name)

            # AJPanel Player
            if config.plugins.torreplayer.vod_screen.value == 'ajpanel':
                try:
                    from Plugins.Extensions.AJPan.plugin import CCMTfv
                except:
                    return logdata("Latest AJPanel is not installed or Server not running")
                from twisted.internet import reactor

                # Prepare data
                serv = self.session.nav.getCurrentlyPlayingServiceReference()
                endRef = serv.toString()
                name = str(self.titles[0])
                video_url = self['menu'].getCurrent()[1]  # Get selected stream URL
                source = int(config.plugins.torreplayer.player.value)

                # Build service reference
                ref_prefix = f"{source}:0:1:0:0:0:0:0:0:0:"

                # Create fake POST data structure
                data = {
                    "url": video_url,
                    "ref": ref_prefix,
                    "name": name,
                    "logo": self.poster,
                    "endRef": endRef
                }

                # Get AJPanel instance
                ajp_instance = CCMTfv(self.session)

                # Call internal method via main thread
                def _start_playback():
                    # 1. Initialize web server if needed
                    if not CCMTfv.VVy1jd():
                        ajp_instance.VV0G75()

                    # 2. Directly invoke player handler
                    status_code, message = ajp_instance.VVi03A(jDumps(data))

                    # 3. Debug output
                    logdata(f"[TorrEpisodes] AJPanel direct call result: {status_code} - {message}")

                # Ensure execution in main thread
                reactor.callFromThread(_start_playback)

            # No valid player configuration
            else:
                logdata("[TorrEpisodes] No valid player configuration found.")


    def playCallback(self, result=None):
        """Callback for handling playback exit and options."""
        try:
            # Handle different player return types
            self.loading.stop()
            if isinstance(result, tuple) and len(result) >= 2:
                # Existing tuple format from other players
                action = result[1]
            elif isinstance(result, basestring):
                # Direct string from modified callback
                action = result
            elif isinstance(result, list):
                logdata("[TorrEpisodes] Received list callback:", result)
                action = result[1] if len(result) > 1 else "list_exit"
            else:
                # Fallback for unexpected types
                action = "unknown_exit"
                logdata("[TorrEpisodes] Unknown callback result type: %s" % type(result))

            logdata("[TorrEpisodes] Playback callback action: %s" % action)

            if action == 'repeat':
                self.action()
            elif action == 'ask':
                title = _('What do you want to do?')
                options = [
                    (_('Quit'), 'quit'),
                    (_('Play video again'), 'repeat')
                ]
                self.session.openWithCallback(self.playCallback, ChoiceBox, title=title, list=options)
            else:
                self.createSubList()

        except Exception as e:
            logdata("[TorrEpisodes] Callback error: %s" % str(e))
            self.close(self.titles[1])

class TorrMenu(Screen):
    def createSummary(self):
        return TransmissionLCDSummary

    def getLCDSummary(self):
        cur = self["menu"].getCurrent()
        title = cur[0] if cur else ""
        return {
            "title": "Transmission – Menu",
            "line1": title[:32],
            "line2": "",
            "line3": "",
            "progress": 0,
        }

    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = getSkin('TorrMenu')
        self.setTitle(_('Transmission TorrPlayer'))
        self['title'] = Label('')
        self['original_title'] = Label('')
        self['overview'] = Label('')
        self['vote_average'] = Label('')
        self['key_red'] = Label(_('Delete'))
        self['key_green'] = Label(_('Search torrent'))
        self['key_yellow'] = Label(_('Update torrent info'))
        self['key_blue'] = Label(_('Settings'))
        self['statusbar'] = Label('')
        self['poster'] = Pixmap()
        self['stars'] = ProgressBar()
        self['starsbg'] = Pixmap()
        self['stars'].hide()
        self['starsbg'].hide()
        self.ratingstars = 0
        self.menulist = []
        self['menu'] = List(self.menulist, enableWrapAround=True)
        self['actions'] = ActionMap(['TorrePlayerActions'], {'cancel': self.cancel, 'red': self.delete, 'green': self.openVirtualKeyBoard,
           'yellow': self.update,
           'blue': self.torrconf,
           'menu': self.torrconf,
           'ok': self.ok,
           'down': self.keyDown,
           'up': self.keyUp,
           'left': self.keyLeft,
           'right': self.keyRight,
           'info': self.about,
           'list': self.createList}, -1)
        if ServiceApp_installed:
            config.plugins.torreplayer.player = ConfigSelection(default='5002', choices=[('4097', _('Default [4097]')), ('5002', _('Exteplayer [5002]')), ('5001', _('Gstplayer [5001]'))])
        else:
            config.plugins.torreplayer.player = ConfigSelection(default='4097', choices=[('4097', _('Default [4097]'))])

        self.timer = eTimer()
        self.status_timer = eTimer()
        self.status_timer.callback.append(self.get_status)
        self.status_timer.start(500, True)
        threading.Thread(target=self.createList).start()
        self.onClose.append(self.status_timer.stop)
        self.onClose.append(self.cross)
        self['menu'].onSelectionChanged.append(self.redouane)

    def get_status(self):
        self['statusbar'].setText(get_status()[0])

    def redouane(self):
        deferToThread(self.update).addErrback(self.handleError)

    def handleError(self, error):
        logdata('Error occurred during deferred operation: {}'.format(error))

    def createList(self):
        def _createList():
            self.menulist = []
            if get_pid('TorrServer'):
                # Stop timer on main thread
                reactor.callFromThread(self.status_timer.stop)
                ts.url = config.plugins.torreplayer.serv_url.value
                res = ts.read_torrents()
                if ts.test_connection() and len(ts.srv_torrents) > 0:
                    for one in ts.srv_torrents:
                        # Process torrent data in background
                        poster_name = one.poster.split('/')[-1] if one.poster else ''
                        poster_path = self.getPoster(one, str(one.title))
                        if str(one.status_string) == 'Torrent getting info':
                            reactor.callFromThread(self.hide_all)
                            reactor.callFromThread(
                                self.menulist.append,
                                ('***  ADDING A TORRENT ***', one.hash, '', '', '', 0, 0, '', '')
                            )
                            break
                        else:
                            try:
                                Poster = loadJPG(poster_path)
                            except:
                                Poster = None

                            # Add to list on main thread
                            reactor.callFromThread(
                                self.menulist.append,
                                (
                                    str(one.title),
                                    one.hash,
                                    pretty_size(one.torrent_size),
                                    one.poster,
                                    one.data.description,
                                    one.data.vote_average,
                                    one.data.vote_count,
                                    one.data.title,
                                    one.data.original_title,
                                    Poster
                                )
                            )
                            reactor.callFromThread(self.updateMenuList)
                else:
                    reactor.callFromThread(self.status_timer.stop)
                    reactor.callFromThread(self.hide_all)
                    reactor.callFromThread(
                        self.menulist.append,
                        ('***  No TORRENT ***', None, '', '', '', 0, 0, '', '', None)
                    )
                    reactor.callFromThread(self.updateMenuList)

        # Run the list creation in background thread
        deferToThread(_createList).addErrback(self.handleError)

    def updateMenuList(self):
        self['menu'].setList(self.menulist)

    def cancel(self):
        self.status_timer.stop()
        self.close(None)
        return

    def openVirtualKeyBoard(self):
        self.status_timer.stop()
        text = ''
        if config.plugins.torreplayer.rememberlastsearch.value:
            text = config.plugins.torreplayer.lastsearch.value
        self.session.openWithCallback(self.addTorrent, VirtualKeyBoard, title=_('Enter torrent to search'), text=text)

    def addTorrent(self, name):
        if name:
            if config.plugins.torreplayer.rememberlastsearch.value:
                config.plugins.torreplayer.lastsearch.value = name
                config.plugins.torreplayer.lastsearch.save()
            self.session.openWithCallback(self.postaction, TorrSearch, search_topic=name)

    def postaction(self, answer=None):
        safe_title = re.sub('[^A-Za-z0-9]+', '', str(self['menu'].getCurrent()[7]))  # Sanitize title
        title = safe_title.lower() + "_p.jpg"
        poster = os.path.join(
            config.plugins.torreplayer.poster_path.value,
            'transmission',
            'poster',
            title # Limit directory name length
        )
        if answer:
            self.action = answer[1]
            name = answer[2]
            magnet = answer[3]
            titles = [name, magnet]
            trnt = torrsrv.torrent()
            trnt.title = name
            trnt.link = magnet
            self.data_from_tmdb(name, trnt)
            if self.action == 'onlyadd':
                self.status_timer.stop()
                ts.add_torrent(trnt)
                self.createList()
            else:
                if self.action == 'addplay':
                    ts.add_torrent(trnt)
                    self.session.openWithCallback(self.postplay, TorrEpisodes, titles, poster)
                elif self.action == 'onlyplay':
                    self.session.openWithCallback(self.postplay, TorrEpisodes, titles, poster)

    def delete(self):
        if not self.menulist:
            self.session.open(MessageBox, _("No torrents to delete."), MessageBox.TYPE_INFO, timeout=3)
            return

        delete_options = [
            (_('Delete current torrent'), 'current'),
            (_('Delete all torrents'), 'all')
        ]
        self.session.openWithCallback(self.handle_delete_choice, ChoiceBox, title=_('Delete Torrent(s)'), list=delete_options)

    # New method to handle the user's choice from the delete prompt
    def handle_delete_choice(self, choice):
        if choice is None:
            return # User cancelled the choice

        action = choice[1]

        if action == 'current':
            message = _('Do you want to delete this torrent?\n\n%s') % self['menu'].getCurrent()[0]
            self.session.openWithCallback(self.remTorrent, MessageBox, message, timeout=0)
        elif action == 'all':
            message = _('Are you sure you want to delete ALL torrents?')
            self.session.openWithCallback(self.remAllTorrents, MessageBox, message, MessageBox.TYPE_YESNO, timeout=0)

    def remTorrent(self, answer):
        def _delete_torrent():
            try:
                current_hash = self['menu'].getCurrent()[1]
                logdata("Deleting torrent hash:", current_hash)
                ts.remove_torrent(current_hash)
                # Fixed: Added closing parenthesis
                reactor.callFromThread(lambda: deferToThread(self.createList).addErrback(self.handleError))
            except Exception as e:
                logdata("Torrent deletion error:", str(e))
                reactor.callFromThread(self.session.open, MessageBox,
                    _("Error deleting torrent"), MessageBox.TYPE_ERROR, timeout=3)

        if answer:
            reactor.callFromThread(self.hide_all)
            deferToThread(_delete_torrent).addErrback(self.handleError)

    def remAllTorrents(self, answer):
        def _delete_all():
            try:
                if not hasattr(ts, 'srv_torrents') or not ts.srv_torrents:
                    reactor.callFromThread(self.session.open, MessageBox,
                        _("No torrents to delete"), MessageBox.TYPE_INFO, timeout=3)
                    return

                hashes = [getattr(t, 'hash', None) for t in ts.srv_torrents if getattr(t, 'hash', None)]
                logdata("Deleting %d torrents" % len(hashes))

                for torrent_hash in hashes:
                    try:
                        ts.remove_torrent(torrent_hash)
                        logdata("Deleted:", torrent_hash)
                    except Exception as e:
                        logdata("Delete failed for %s:" % torrent_hash, str(e))

                # Fixed: Added closing parenthesis
                reactor.callFromThread(lambda: deferToThread(self.createList).addErrback(self.handleError))
                reactor.callFromThread(self.session.open, MessageBox,
                    _("Deleted %d torrents") % len(hashes), MessageBox.TYPE_INFO, timeout=3)

            except Exception as e:
                logdata("Mass deletion error:", str(e))
                reactor.callFromThread(self.session.open, MessageBox,
                    _("Error deleting torrents"), MessageBox.TYPE_ERROR, timeout=3)

        if answer:
            reactor.callFromThread(self.hide_all)
            deferToThread(_delete_all).addErrback(self.handleError)


    def ok(self, currentSelect=None):
        titel = self['menu'].getCurrent()[0]
        titel_no_year = re.sub(r'\(\s*\d{4}\s*\)', '', titel)
        titel_no_episode = re.sub(r'[:\s]*episode\s*\d+', '', titel_no_year, flags=re.IGNORECASE)
        safe_title = re.sub(r'[^A-Za-z0-9]+', '', titel_no_episode)
        title = safe_title.lower() + "_p.jpg"
        poster = os.path.join(
            config.plugins.torreplayer.poster_path.value,
            'transmission',
            'poster',
            title # Limit directory name length
        )
        if currentSelect is None and self.menulist:
            self.status_timer.stop()
            titles = []
            titles.append(self['menu'].getCurrent()[0])
            titles.append(self['menu'].getCurrent()[1])
            self.action = 'play'
            self.session.openWithCallback(self.postplay, TorrEpisodes, titles, poster)
        return

    def postplay(self, answer=None):
        if answer:
            if self.action == 'onlyplay':
                self.hide_all()
                ts.remove_torrent(torrsrv.hash_from_magnet(answer))
            self.timer.start(100)

    def update(self):
        if ts.test_connection() and len(ts.srv_torrents) > 0:
            idx = self['menu'].getSelectedIndex()
            one = ts.srv_torrents[self['menu'].getCurrent()[1]]
            titel = self['menu'].getCurrent()[0]

            # Use tmdb_query to clean the title (removes year, resolution, release group etc.)
            safe_title = tmdb_query.clear_name(titel)

            try:
                # data_from_tmdb will now handle poster download too using the sanitized title
                self.data_from_tmdb(safe_title, one)
                ts.update_torrent(one)
            except Exception as e:
                logdata("Error updating torrent data: " + str(e))

            # Poster should be downloaded now, get path to load it
            # We pass the safe_title to getPoster so it generates the clean filename
            poster_path = self.getPoster(one, safe_title)

            try:
                if os.path.exists(poster_path):
                    Poster = loadJPG(poster_path)
                else:
                    Poster = None
            except Exception as e:
                Poster = None
                logdata("Error loading poster image: " + str(e))

            self.menulist[idx] = (
                str(one.title),
                one.hash,
                pretty_size(one.torrent_size),
                one.poster,
                one.data.description,
                one.data.vote_average,
                one.data.vote_count,
                one.data.title,
                one.data.original_title,
                Poster
            )
            self['menu'].updateList(self.menulist)
            self.cross()
        else:
            self.createList()
            self.cross()

    def data_from_tmdb(self, item, trnt):
        res = search_tmdb(item)
        if res:
            trnt.poster = res[0].poster_url
            trnt.data.description = res[0].description
            trnt.data.vote_average = res[0].vote_average
            trnt.data.vote_count = res[0].vote_count
            if res[0].title:
                trnt.data.title = res[0].title
            else:
                trnt.data.title = res[0].name
            if res[0].original_title:
                trnt.data.original_title = res[0].original_title
            else:
                trnt.data.original_title = res[0].original_name

            # Download poster if needed, using the sanitized item name for filename
            self.getPoster(trnt, item)
        if res:
            trnt.poster = res[0].poster_url
            trnt.data.description = res[0].description
            trnt.data.vote_average = res[0].vote_average
            trnt.data.vote_count = res[0].vote_count
            if res[0].title:
                trnt.data.title = res[0].title
            else:
                trnt.data.title = res[0].name
            if res[0].original_title:
                trnt.data.original_title = res[0].original_title
            else:
                trnt.data.original_title = res[0].original_name

    def keyRight(self):
        self['menu'].selectNext()
        self.cross()

    def keyLeft(self):
        self['menu'].selectPrevious()
        self.cross()

    def keyUp(self):
        self['menu'].pageDown()
        self.cross()

    def keyDown(self):
        self['menu'].pageUp()
        self.cross()

    def cross(self):
        if get_pid('TorrServer') and self.menulist:
            self['overview'].setText(str(self['menu'].getCurrent()[4]))
            self.showPoster()
            self.vote()
            self['title'].setText(str(self['menu'].getCurrent()[7]))
            self['original_title'].setText(str(self['menu'].getCurrent()[8]))

    def about(self):
        self.session.open(MessageBox, _('Enigma2 TorrePlayer ©2023\nFixed For Dreamos By Ostende'), MessageBox.TYPE_INFO)

    def hide_all(self):
        self['poster'].hide()
        self['title'].setText('')
        self['original_title'].setText('')
        self['overview'].setText('')
        self['vote_average'].setText('')
        self['starsbg'].hide()
        self['stars'].hide()

    def vote(self):
        Ratingtext = _('User Rating') + ': %s /10' % str(self['menu'].getCurrent()[5]) + ' (' + _('Votes') + ': ' + str(self['menu'].getCurrent()[6]) + ')'
        self['vote_average'].setText(Ratingtext)
        if DEBUG:
            write_log('Ratingtext: %s' % Ratingtext)
        self.ratingstars = int(10 * float(str(self['menu'].getCurrent()[5])))
        self['starsbg'].show()
        self['stars'].setValue(self.ratingstars)
        self['stars'].show()

    def getPoster(self, torrent, titel):
        poster_url = getattr(torrent, 'poster', '')

        # Use tmdb_query.clear_name for robust cleaning
        titel_clean = tmdb_query.clear_name(titel)

        # Remove non-alphanumerics from the cleaned title to form the filename
        safe_title = re.sub(r'[^A-Za-z0-9]+', '', titel_clean)

        # Final poster filename
        title = safe_title.lower() + "_p.jpg"

        logdata('poster name TorrMenu', title)

        poster_dir = os.path.join(
            config.plugins.torreplayer.poster_path.value,
            'transmission',
            'poster',
            title
        )
        if not os.path.exists(poster_dir):
            return self.default_poster_path()
        poster_full_path = os.path.join(
            config.plugins.torreplayer.poster_path.value,
            'transmission',
            'poster',
            title
        )
        logdata('poster path TorrMenu', poster_full_path)
        if not self.valid_poster_exists(poster_full_path):
            success = self.download_with_retry(poster_url, poster_full_path)
            if not success:
                return self.default_poster_path()
        return poster_full_path

    def download_with_retry(self, url, path, retries=3):
        """Download with headers and retries"""
        headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36',
            'Referer': 'https://www.google.com/'
        }
        for attempt in range(retries):
            try:
                response = requests.get(url, headers=headers, verify=False, timeout=10)
                response.raise_for_status()
                with open(path, 'wb') as f:
                    f.write(response.content)
                return True
            except Exception as e:
                time.sleep(2)
        if os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass
        return False

    def valid_poster_exists(self, path):
        """Check if we have a valid cached poster"""
        return os.path.isfile(path) and os.path.getsize(path) > 1024  # At least 1KB

    def default_poster_path(self):
        return '/usr/lib/enigma2/python/Plugins/Extensions/Transmission/images/poster_none.png'

    def showPoster(self):
        pass

    def torrconf(self):
        self.status_timer.stop()
        self.session.openWithCallback(self.torrconf_post, TorrConf)

    def torrconf_post(self):
        if not get_pid('TorrServer'):
            self.hide_all()
        self.timer.start(100)

class TorrConf(ConfigListScreen, Screen):
    def createSummary(self):
        return TransmissionLCDSummary

    def getLCDSummary(self):
        return {
            "title": "Transmission – Settings",
            "line1": "Configuration",
            "line2": "",
            "line3": "",
            "progress": 0,
        }

    def __init__(self, session):
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [], session=session)
        self.session = session
        self.skin = getSkin('TorrConf')
        self['statusbar'] = Label('')
        self['key_red'] = Label(_('Cancel'))
        self['key_green'] = Label(_('Save'))
        self['key_yellow'] = Label(_('Start'))
        self['key_blue'] = Label(_('Install'))
        self.setTitle(_('Settings Transmission'))
        self.setConfigList()
        self['actions'] = ActionMap(['TorrePlayerActions'], {'ok': self.ok, 'green': self.save,
           'yellow': self.start_stop,
           'blue': self.install_update,
           'cancel': self.exit,
           'red': self.exit}, -2)
        self.stimer = eTimer()
        self.get_status()
        self.stimer.callback.append(self.get_status)
        self.stimer.start(2000)
        self.onClose.append(self.stimer.stop)

    def setConfigList(self, configElement=None):
        self.list = []
        self.list.append(getConfigListEntry(_('Autostart'), config.plugins.torreplayer.autostart))
        self.list.append(getConfigListEntry(_('Choose Skin Movies:'), config.plugins.torreplayer.skins))
        self.list.append(getConfigListEntry(_('Choose Skin Series:'), config.plugins.torreplayer.skins_tv))
        self.list.append(getConfigListEntry(_('Set items in list:'), config.plugins.torreplayer.items))
        self.list.append(getConfigListEntry(_('Activate Proxy'), config.plugins.torreplayer.proxy))
        self.list.append(getConfigListEntry(_('Added Transmission to Menu'), config.plugins.torreplayer.show_in_menu))
        self.list.append(getConfigListEntry(_('Disable Backdrop as Background'), config.plugins.torreplayer.bacdrop))
        self.list.append(getConfigListEntry(_('Player Screen'), config.plugins.torreplayer.vod_screen))
        self.list.append(getConfigListEntry(_('Player torrent'), config.plugins.torreplayer.player))
        self.list.append(getConfigListEntry(_('Buffer streams'), config.plugins.torreplayer.buffer))
        self.list.append(getConfigListEntry(_('Tmdb Info language:'), config.plugins.torreplayer.tmdblng))
        self.list.append(getConfigListEntry(_('Subtitles language:'), config.plugins.torreplayer.subslng))
        self.list.append(getConfigListEntry(_('SubDl Api Key:'), config.plugins.torreplayer.subdl_api))
        self.list.append(getConfigListEntry(_('When video ends:'), config.plugins.torreplayer.onMovieEof))
        self.list.append(getConfigListEntry(_('When playback stop:'), config.plugins.torreplayer.onMovieStop))
        self.list.append(getConfigListEntry(_('Remember last search on Torr'), config.plugins.torreplayer.rememberlastsearch))
        self.list.append(getConfigListEntry(_('Remember last search on YTS Movies'), config.plugins.torreplayer.rememberlastsearchyts))
        self.list.append(getConfigListEntry(_('Remember last search on YTS TV'), config.plugins.torreplayer.rememberlastsearchyts_tv))
        self.list.append(getConfigListEntry(_('Server & Port:'), config.plugins.torreplayer.serv_url))
        self.config_path = getConfigListEntry(_('Config file path:'), config.plugins.torreplayer.config_path)
        self.list.append(self.config_path)
        self.poster_path = getConfigListEntry(_('Poster path:'), config.plugins.torreplayer.poster_path)
        self.list.append(self.poster_path)
        # TorrServer-specific config
        self.cache_path = getConfigListEntry(_('TorrServer Cache path:'), config.plugins.torreplayer.poster_path)
        self.list.append(self.cache_path)
        self.list.append(getConfigListEntry(_('Remove Cache'), config.plugins.torreplayer.remove_cache))
        self.list.append(getConfigListEntry(_('TorrServer Cache size (MB)'), config.plugins.torreplayer.cache_size))
        self.list.append(getConfigListEntry(_('Preload buffer %'), config.plugins.torreplayer.preload_buffer))
        self.list.append(getConfigListEntry(_('Use disk buffer'), config.plugins.torreplayer.use_disk))
        self.list.append(getConfigListEntry(_('Reader read ahead %'), config.plugins.torreplayer.reader_read_ahead))
        self.list.append(getConfigListEntry(_('Torrent Disconnect Timeout (sec)'), config.plugins.torreplayer.torrent_disconnect_timeout))
        self.list.append(getConfigListEntry(_('Download Rate Limit (KB/s)'), config.plugins.torreplayer.download_rate_limit))
        self.list.append(getConfigListEntry(_('Upload Rate Limit (KB/s)'), config.plugins.torreplayer.upload_rate_limit))
        self.list.append(getConfigListEntry(_('Connections Limit'), config.plugins.torreplayer.connections_limit))

        self['config'].setList(self.list)

    def ok(self):
        if self['config'].getCurrent() == self.config_path:
            self.DirBrowser(config.plugins.torreplayer.config_path.value, config.plugins.torreplayer.config_bookmarks)
        elif self['config'].getCurrent() == self.poster_path:
            self.DirBrowser(config.plugins.torreplayer.poster_path.value, config.plugins.torreplayer.poster_bookmarks)
        elif self['config'].getCurrent() == self.cache_path:
            self.DirBrowser(config.plugins.torreplayer.poster_path.value, config.plugins.torreplayer.poster_bookmarks)
        else:
            self.save()

    def DirBrowser(self, path, bookmarks):
        inhibitDirs = ['/bin',
         '/boot',
         '/dev',
         '/lib',
         '/proc',
         '/run',
         '/sbin',
         '/sys',
         '/share']
        try:
            self.session.openWithCallback(self.DirBrowserX, LocationBox, windowTitle=self['config'].getCurrent()[0], text=_('Choose Directory'), currDir=path, bookmarks=bookmarks, editDir=True, inhibitDirs=inhibitDirs, minFree=5)
        except Exception as ex:
            print('Directory get failed: %s' % ex)

    def DirBrowserX(self, path):
        if path:
            sanitized_path = sanitize_path(path)
            if self['config'].getCurrent() == self.config_path:
                config.plugins.torreplayer.config_path.setValue(sanitized_path)
            else:
                config.plugins.torreplayer.poster_path.setValue(sanitized_path)

    def save(self):
        from time import sleep
        stop_server()
        config.plugins.torreplayer.save()
        configfile.save()
        start_server()

        sleep(2)  # Wait a bit for TorrServer to boot

        try:
            echo_url = config.plugins.torreplayer.serv_url.value.rstrip('/') + '/echo'
            response = requests.get(echo_url, timeout=2)
            if response.ok:
                current_settings = torrsettings({})
                updated_settings = self.apply_torr_config_from_plugin_config(current_settings)
                self.send_settings_to_torrserver(updated_settings)
            else:
                logdata("[TorrConf] TorrServer echo check failed with status:", response.status_code)
        except Exception as e:
            logdata("[TorrConf] TorrServer not ready after restart:", str(e))

        self.stimer.stop()
        self.close()


    @staticmethod
    def apply_torr_config_from_plugin_config(torr_settings):
        torr_settings.CacheSize = config.plugins.torreplayer.cache_size.value
        torr_settings.PreloadBuffer = config.plugins.torreplayer.preload_buffer.value
        torr_settings.UseDisk = config.plugins.torreplayer.use_disk.value
        torr_settings.ReaderReadAHead = config.plugins.torreplayer.reader_read_ahead.value

        # Новые поля
        torr_settings.TorrentDisconnectTimeout = config.plugins.torreplayer.torrent_disconnect_timeout.value
        torr_settings.DownloadRateLimit = config.plugins.torreplayer.download_rate_limit.value
        torr_settings.UploadRateLimit = config.plugins.torreplayer.upload_rate_limit.value
        torr_settings.ConnectionsLimit = config.plugins.torreplayer.connections_limit.value
        torr_settings.TorrentsSavePath = config.plugins.torreplayer.poster_path.value
        torr_settings.RemoveCacheOnDrop = config.plugins.torreplayer.remove_cache.value

        return torr_settings

    @staticmethod
    def send_settings_to_torrserver(torr_settings):
        try:
            url = config.plugins.torreplayer.serv_url.value + '/settings'
            data = json.dumps(torr_settings.sets)
            headers = {'Content-Type': 'application/json'}
            response = requests.post(url, data=data, headers=headers)
            logdata("[TorrEpisodes] Settings update response:", response.status_code)
        except Exception as e:
            logdata("[TorrEpisodes] Failed to send settings to TorrServer:", str(e))


    def exit(self):
        for x in self['config'].list:
            x[1].cancel()

        self.stimer.stop()
        self.close()

    def get_status(self):
        self['statusbar'].setText(get_status()[0])
        self['key_yellow'].setText(get_status()[1])
        self['key_blue'].setText(get_status()[2])

    def install_update(self):
        try:
            arch_raw = subprocess.check_output('uname -m; exit 0', shell=True)
            arch = ensure_str(arch_raw.strip())

            # Architecture map
            arch_map = {
                "armv7l": "linux-arm7",
                "aarch64": "linux-arm64",
                "armv8": "linux-arm64",
                "hi3798mv200": "linux-arm7",
                "hi3798mv100": "linux-arm7",
                "mips": "linux-mipsle",
                "mipsle": "linux-mipsle",
                "mips64": "linux-mips64",
                "mips64el": "linux-mips64le",
                "i686": "linux-386",
                "x86_64": "linux-amd64"
            }

            link_key = arch_map.get(arch)
            if not link_key:
                self['statusbar'].setText(_('Unsupported architecture: %s') % arch)
                if DEBUG:
                    write_log('Unsupported arch: %s' % arch)
                return False

            headers = {
                'User-Agent': 'Mozilla/5.0 (compatible)',
                'Accept-Encoding': 'gzip',
            }

            http = urllib3.PoolManager(headers=headers)
            response = http.request('GET', repolist)

            if response.status != 200:
                raise Exception("Failed to fetch repolist (HTTP %s)" % response.status)

            repo_json = json.loads(response.data.decode('utf-8'))
            new_ver = repo_json.get('version')
            links = repo_json.get('links')
            url = links.get(link_key) if links else None

            if DEBUG:
                write_log('Detected arch: %s → %s' % (arch, link_key))
                write_log('TorrServer version: %s' % new_ver)
                write_log('Download URL: %s' % url)

            if not url:
                self['statusbar'].setText(_('No compatible TorrServer binary found for %s') % arch)
                return False

            res = False
            if not os.path.isfile(torrserver_path):
                self['statusbar'].setText(_('Installing TorrServer...'))
                if DEBUG:
                    write_log('Downloading fresh binary')
                res = download_file(url, torrserver_path, 'u=rwx,g=rx,o=rx')
            elif get_version() != new_ver:
                self['statusbar'].setText(_('Updating TorrServer...'))
                self.start_stop()
                if DEBUG:
                    write_log('New version found, updating')
                res = download_file(url, torrserver_path, 'u=rwx,g=rx,o=rx')
                self.start_stop()
            else:
                self['statusbar'].setText(_('TorrServer is already up to date'))
                if DEBUG:
                    write_log('No update needed')
                return False

            if res:
                self['key_blue'].setText(_('Check updates'))
                self['statusbar'].setText(_('TorrServer installed successfully'))

        except urllib3.exceptions.HTTPError as e:
            self['statusbar'].setText(_('HTTP error while updating TorrServer'))
            if DEBUG:
                write_log('HTTP error: %s' % str(e))
        except Exception as e:
            self['statusbar'].setText(_('Error updating TorrServer: %s') % str(e))
            if DEBUG:
                write_log('Exception: %s' % str(e))

    def start_stop(self):
        if get_pid('TorrServer'):
            stop_server()
        else:
            start_server()
        self.get_status()

class EZTVAPIResult(Screen):
    def __init__(self, session, url, text):
        Screen.__init__(self, session)
        self.session = session
        self.url = url
        self.text = str(text)
        self.page = 0
        self.data = None
        self.movies = []
        self.menu_list = []
        self.torrents = []
        self.loading_time = 5
        self.my_torr_server = ts
        self.darwin_directory = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')
        self.poster_directory = '{}/transmission/poster/'.format(config.plugins.torreplayer.poster_path.value)
        self.is_loading = False

        # Break the initialization into smaller parts
        self.init_skin()
        self.init_labels()
        self.init_actions()
        self.init_components()

        self.onExecBegin.append(self.loader)
        self.onClose.append(self.cleanup)

    # Function to initialize the skin and layout components
    def init_skin(self):
        self.skin = getSkin(str(config.plugins.torreplayer.skins_tv.value))
        self['pic_loading'] = Pixmap()
        self['int_loading'] = Label('')
        self['msg_loading'] = Label('')
        self.loading = Loading(self["pic_loading"], self["int_loading"], self["msg_loading"], None)
        self.picload = ePicLoad()
        self.skin_path = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')

    # Function to initialize labels
    def init_labels(self):
        self['key_red'] = Label(_('Exit'))
        self['key_yellow'] = Label(_('Next'))
        self['key_blue'] = Label(_('Download Manager'))
        self['key_green'] = Label('')
        self['fatima'] = Label(_("*** Torrent Series & TvShow's Browser [EZTV]***"))
        self['yassine'] = Label('')
        self['season'] = Label('')
        self['size'] = Label('')
        self['ostende'] = Label('')
        self['zahra'] = Label('')
        self['info_label'] = Label('')

        # Optional screenshot components
        self['screenshot'] = Pixmap()
        self['screenshot2'] = Pixmap()
        self['screenshot3'] = Pixmap()

    # Function to initialize action map and user input handling
    def init_actions(self):
        self['actions'] = ActionMap(['DirectionActions', 'EPGSelectActions', 'MenuActions', 'OkCancelActions', 'ColorActions'], {
            'ok': self.ok,
            'cancel': self.cancel,
            'green': self.goBack,
            'yellow': self.nextPage,
            'red': self.cancel,
            'blue': self.browser,
            'info': self.ghita
        }, -1)

    def init_components(self):
        self['title_list'] = List(self.menu_list)
        self['title_list'].onSelectionChanged.append(self.getdata)

    def loader(self):
        if self.menu_list:
            self.loading.stop()
        else:
            self.loading.start(self.loading_time, _(self.text))
            deferToThread(self.createList).addErrback(self.handleError)

    def createList(self):
        """Worker thread method to fetch data and create list items sequentially."""
        try:
            logdata('createList: Starting data fetch from {}'.format(self.url))
            data = self.get_data()

            if not data:
                logdata('createList: No data received')
                reactor.callFromThread(self.handleError, "No data received from server")
                return

            torrents = data.get('torrents', [])
            if not torrents:
                logdata('createList: No torrents found')
                reactor.callFromThread(self.handleError, "No torrents found")
                return

            self.total_pages = data.get('data', {}).get('page_count', 1)
            self.menu_list = []

            # Process each torrent sequentially
            for torrent in torrents:
                try:
                    self.process_one_torrent(torrent)
                except Exception as e:
                    logdata('Error processing torrent: {}'.format(str(e)))

            # Finish loading
            reactor.callFromThread(self.finish_loading)

        except Exception as e:
            logdata('createList: Exception: {}'.format(str(e)))
            import traceback
            logdata(traceback.format_exc())
            reactor.callFromThread(self.handleError, str(e))

    def process_one_torrent(self, torrent):
        """Process a single torrent item, including blocking downloads."""
        title = torrent.get('title')
        if title:
            match = re.match('(.+?)\\sS\\d{2}E\\d{2}', title)
            cleaned_title = match.group(1) if match else title.strip()
            movie_title = str(cleaned_title)

        title2 = torrent.get('filename')
        titlex = re.sub('\\[.*?\\]', '', title2).strip()
        titles = titlex.lower().replace(' ', '').replace('.', '')
        imdb = torrent.get('imdb_id')

        Poster = None

        # Blocking download logic
        if config.plugins.torreplayer.skins_tv.value == 'EZTV_banner':
            filename = os.path.join(self.poster_directory, '{}_banner.jpg'.format(titles))
            if not os.path.exists(filename):
                self.banner_blocking(movie_title, filename)

            if os.path.exists(filename) and os.path.getsize(filename) > 0:
                 # Load for UI if needed, or just let showPoster handle it
                 pass

        if imdb:
            # Fetch TMDB data blocking
            tmdb_result = self.gettmdbdata(imdb)
            if tmdb_result:
                self.handle_tmdb_result_blocking(tmdb_result, movie_title)

                # Check for poster after TMDB handling
                name = movie_title.lower().replace(' ', '').replace('.', '')
                poster_path = os.path.join(self.poster_directory, '{}_p.jpg'.format(name))
                if os.path.exists(poster_path):
                    try:
                        Poster = loadJPG(poster_path)
                    except:
                        pass

        # Create list item
        large_screenshots = torrent.get('large_screenshot')
        large_screenshot = str('http:' + large_screenshots) if large_screenshots else None

        seeds = torrent.get('seeds')
        peers = torrent.get('peers')
        year_unix = torrent.get('date_released_unix')
        season = torrent.get('season')
        episode = torrent.get('episode')

        if year_unix and isinstance(year_unix, (int, float)):
            year = datetime.utcfromtimestamp(year_unix).strftime('%Y-%m-%d')
        else:
            year = _('Unknown')

        Ep = self.format_episode_info(episode, season, year)
        size_bytes = torrent.get('size_bytes', 0)
        torrent_url = torrent.get('torrent_url')
        torrent_link = torrent.get('magnet_url')

        torrent_info = (str(movie_title), large_screenshot, seeds, peers,
                       season, episode, size_bytes, year, torrent_link,
                       imdb, str(titlex), Poster, str(Ep))

        # Update UI incrementally
        reactor.callFromThread(self.append_item, torrent_info)

    def format_episode_info(self, episode, season, year):
        if episode and season:
            if config.plugins.torreplayer.skins_tv.value == 'EZTV_banner':
                return _('Year: ') + year + _(' Episode: ') + episode + _(' Season: ') + season
            else:
                return _('Ep: ') + episode + _(' / S: ') + season

        return ''

    def append_item(self, item):
        self.menu_list.append(item)
        self['title_list'].setList(self.menu_list)
        self['title_list'].updateList(self.menu_list)

    def finish_loading(self):
        self.loading.stop()
        self.is_loading = False
        self['msg_loading'].setText('')


    def cleanup(self):
        self.loading.stop()

    def banner_blocking(self, titel, filename):
        """Blocking version of banner download."""
        try:
            name_unclean = str(titel)
            url_tvdb = 'https://thetvdb.com/api/GetSeries.php?seriesname={}'.format(name_unclean)
            response = requests.get(url_tvdb, verify=False, timeout=10)
            response.raise_for_status()
            url_read = response.text

            series_ids = re.findall('<seriesid>(.*?)</seriesid>', url_read)
            if series_ids:
                series_id = series_ids[0]
                url_tvdb = 'https://thetvdb.com/api/a99d487bb3426e5f3a60dea6d3d3c7ef/series/{}/en.xml'.format(series_id)
                response = requests.get(url_tvdb, verify=False, timeout=10)
                url_read = response.text

                poster = re.findall('<banner>(.*?)</banner>', url_read)
                if not poster:
                    poster = re.findall('<fanart>(.*?)</fanart>', url_read)

                if poster:
                    url_poster = 'https://artworks.thetvdb.com/banners/{}'.format(poster[0])
                    self.download_blocking(url_poster, filename)
        except Exception as e:
            logdata("banner_blocking error: " + str(e))

    def handle_tmdb_result_blocking(self, result, movie_title):
        """Blocking version of TMDB result handling."""
        try:
            if not result or not movie_title or not self.poster_directory:
                return

            name = movie_title.lower().replace(' ', '').replace('.', '')
            poster_path = result.get('poster_path')
            backdrop_path = result.get('backdrop_path')
            tvdb_id = result.get('tvdb_id')

            if tvdb_id:
                self.logo_blocking(tvdb_id, name)

            if poster_path:
                url_poster = 'http://image.tmdb.org/t/p/w780{}'.format(poster_path)
                filename_poster = os.path.join(self.poster_directory, '{}_p.jpg'.format(name))
                self.download_blocking(url_poster, filename_poster)

            if backdrop_path:
                url_backdrop = 'http://image.tmdb.org/t/p/w1920{}'.format(backdrop_path)
                filename_backdrop = os.path.join(self.poster_directory, '{}_b.jpg'.format(name))
                self.download_and_process_backdrop(url_backdrop, name)

            # Save overview
            movie_data = {'title': result.get('title'), 'overview': result.get('overview')}
            json_path = os.path.join(self.poster_directory, '{}.json'.format(name))
            with open(json_path, 'w') as f:
                json.dump(movie_data, f)
        except Exception as e:
            logdata('handle_tmdb_result_blocking error: ' + str(e))

    def logo_blocking(self, id_tvdb, name):
        try:
            ext = 'https://api.themoviedb.org/3/tv/' + str(id_tvdb) + '/images?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=en-US&include_image_language=en,null'
            response = requests.get(ext, verify=False, timeout=10)
            data = response.json()
            if 'logos' in data and data['logos']:
                logo_path = data['logos'][0].get('file_path', '')
                if logo_path:
                    url_logo = 'http://image.tmdb.org/t/p/w500' + logo_path
                    filename_logo = os.path.join(self.poster_directory, ('{}_logo.png').format(name))
                    self.download_blocking(url_logo, filename_logo)
        except Exception:
            pass

    def download_blocking(self, url, filename):
        if os.path.exists(filename) and os.path.getsize(filename) > 0:
            return
        try:
            response = requests.get(url, verify=False, timeout=10)
            if response.status_code == 200:
                with open(filename, 'wb') as file:
                    file.write(response.content)
        except Exception:
            pass


    def gettmdbdata(self, imdb_id):
        """Fetch TMDB data for a TV show using IMDB ID."""
        if not imdb_id:
            return None
        try:
            # Use TMDB find API to get TV show data by IMDB ID
            url = 'https://api.themoviedb.org/3/find/tt{}?api_key=8789cfd3fbab7dccf1269c3d7d867aff&external_source=imdb_id&language={}'.format(
                imdb_id, config.plugins.torreplayer.tmdblng.value)
            response = requests.get(url, verify=False, timeout=10)
            data = response.json()

            # Extract TV show results
            tv_results = data.get('tv_results', [])
            if tv_results:
                return tv_results[0]
            return None
        except Exception as e:
            logdata('gettmdbdata error: ' + str(e))
            return None

    def get_data(self):
        if self.page == 0:
            self.base_url = self.url
        else:
            self.base_url = self.url + str(self.page)
        return self.fetch_data(self.base_url)

    def fetch_data(self, url):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/json'
        }
        try:
            # Use proxy if enabled
            response = make_request_with_proxy(url, headers=headers, timeout=15)
            if response and response.status_code == 200:
                return response.json()
            elif response:
                response.raise_for_status()
        except requests.exceptions.RequestException as e:
            logdata('Error during HTTP request: {}'.format(e))
        except ValueError as e:
            logdata('Error parsing JSON: {}'.format(e))
        return None

    def handleError(self, error):
        logdata('Error occurred during deferred operation: {}'.format(error))
        # Update UI to show error
        try:
            if self.loading:
                self.loading.stop()
            self['msg_loading'].setText(_('Error loading data: {}').format(str(error)[:50]))
            # Show message box for user
            self.session.open(MessageBox, _('Failed to load EZTV data: {}').format(str(error)), MessageBox.TYPE_ERROR, timeout=5)
        except Exception as e:
            logdata('Error updating UI in handleError: {}'.format(str(e)))

    def hanan(self):
        try:
            selected_item = self['title_list'].getCurrent()
            if not selected_item:
                return
            title = str(selected_item[0])
            movie_title = title.lower().replace(' ', '').replace('.', '')
            json_filename = os.path.join(self.poster_directory, ('{}.json').format(movie_title))
            try:
                with open(json_filename, 'r') as (json_file):
                    movie_data = json.load(json_file)
                    overview = movie_data.get('overview', '')
                    self['zahra'].setText(_('Description:\n') + str(overview) if overview else _('\n\nNo Description Found'))
            except Exception as e:
                logdata('Error reading JSON file:', str(e))
                self['zahra'].setText(_('\n\nNo Description Found'))

        except:
            pass

    def downloadPicture(self, url, filename, callback=None):
        if os.path.exists(filename):
            if callback:
                reactor.callFromThread(callback, filename)
            return

        try:
            response = requests.get(url, verify=False)
            if response.status_code == 200:
                with open(filename, 'wb') as file:
                    file.write(response.content)
                if callback:
                    reactor.callFromThread(callback, filename)
        except Exception as e:
            logdata('Error downloadPicture EZTV', str(e))

    def downloadPicture2(self, url, filename, callback=None):
        if os.path.exists(filename):
            if callback:
                reactor.callFromThread(callback, filename)
            return
        try:
            response = requests.get(url, verify=False)
            if response.status_code == 200:
                with open(filename, 'wb') as file:
                    for chunk in response.iter_content(1024):
                        file.write(chunk)
                if os.path.exists(filename) and os.path.getsize(filename) > 0:
                    if callback:
                        reactor.callFromThread(callback, filename)
                else:
                    logdata('Error: Downloaded file is empty or missing:', filename)
            else:
                logdata('Failed to download picture, HTTP code:', response.status_code)
        except Exception as e:
            logdata('Error downloadPicture2 EZTV', str(e))



    def downloadPicture3(self, url, filename, callback=None):
        if os.path.exists(filename):
            if callback:
                callback(filename)
            return
        try:
            response = requests.get(url, verify=False)
            if response.status_code == 200:
                with open(filename, 'wb') as file:
                    for chunk in response.iter_content(1024):
                        file.write(chunk)
                if os.path.exists(filename) and os.path.getsize(filename) > 0:
                    if callback:
                        callback(filename)
                else:
                    logdata('Error: Downloaded file is empty or missing:', filename)
            else:
                logdata('Failed to download picture, HTTP code:', response.status_code)
        except Exception as e:
            logdata('Error downloadPicture3 EZTV', str(e))

    def yassine(self):
        try:
            selected_item = self['title_list'].getCurrent()
            if selected_item:
                movie_title = selected_item[0]
                movie_title = str(movie_title)
                if movie_title:
                    try:
                        self['yassine'].setText(movie_title)
                    except Exception as e:
                        logdata('Error set title:', str(e))
            else:
                logdata('No item selected in title_list')
        except:
            pass

    def season(self):
        try:
            selected_item = self['title_list'].getCurrent()
            if not selected_item:
                return
            seasons = str(selected_item[4])
            episode = str(selected_item[5])
            genre_text = _('Season: ') + seasons + _(' | Episode: ') + episode
            self['season'].setText(genre_text)
        except:
            pass

    def size(self):
        try:
            selected_item = self['title_list'].getCurrent()
            if not selected_item:
                self['size'].setText(_('Size: N/A'))
                return
            size_value = selected_item[6]
            if size_value:  # Check if size_value is not empty
                size_bytes = int(size_value)
                if size_bytes >= 1073741824:
                    size_gb = size_bytes / 1073741824
                    size_text = _('Size: {:.2f} GB').format(size_gb)
                else:
                    size_mb = size_bytes / 1048576
                    size_text = _('Size: {:.2f} MB').format(size_mb)
                self['size'].setText(size_text)
            else:
                self['size'].setText(_('Size: N/A'))  # Handle the case where size is not available
        except (ValueError, TypeError) as e:
            self['size'].setText(_('Size: N/A'))  # Handle the case where conversion to int fails
            logdata('Error converting size to int:', str(e))


    def seedsandpeers(self):
        try:
            selected_item = self['title_list'].getCurrent()
            if not selected_item:
                return
            seeds = str(selected_item[2])
            peers = str(selected_item[3])
            self['ostende'].setText(_('Seeds: ') + seeds + _(' | Peers: ') + peers)
        except:
            pass

    def getdata(self):
        self.yassine()
        self.showBackdrop()
        if config.plugins.torreplayer.skins_tv.value != 'EZTV_grid':
            self.getpage()
            self.seedsandpeers()
            self.season()
            self.size()
            self.showLogo()
            self.showPoster()
            self.hanan()

    def showPoster(self):
        try:
            selected_item = self['title_list'].getCurrent()
            if not selected_item:
                return
            movie_titles = selected_item[0]
            movie_title = movie_titles.lower().replace(' ', '').replace('.', '')
            logdata('movie_title eztv poster', movie_title)
            if movie_title:
                default = ('{}/default.svg').format(self.darwin_directory)
                poster_file = ('{}/{}_p.jpg').format(self.poster_directory, movie_title)
                logdata('Poster File Path:', poster_file)
                if os.path.exists(poster_file):
                    logdata('Poster File Exists!')
                    self['screenshot'].instance.setPixmapFromFile(poster_file)
                    self['screenshot'].show()
                else:
                    logdata('Poster File Does Not Exist!')
                    self['screenshot'].instance.setPixmapFromFile(default)
                    self['screenshot'].show()
            else:
                self['screenshot'].hide()
        except Exception as e:
            logdata('Error screenshot:', str(e))

    def download_and_process_backdrop(self, backdrop_url, movie_title):
        try:
            from PIL import Image

            if not backdrop_url or not movie_title:
                logdata("Missing URL or title for backdrop processing")
                return None

            raw_path = os.path.join(self.poster_directory, "{}_b.jpg".format(movie_title))
            final_path = os.path.join(self.poster_directory, "{}_back.jpg".format(movie_title))

            if os.path.exists(final_path):
                logdata("Backdrop already processed", final_path)
                return final_path

            # Download raw backdrop
            #if config.plugins.torreplayer.proxy.value:
                #backdrop_url = "https://thingproxy.freeboard.io/fetch/" + quote(backdrop_url, safe='')

            r = requests.get(backdrop_url, stream=True, verify=False, timeout=10)
            if r.status_code != 200:
                logdata("Backdrop download failed", backdrop_url)
                return None

            with open(raw_path, 'wb') as f:
                for chunk in r.iter_content(1024):
                    f.write(chunk)

            logdata("Backdrop downloaded", raw_path)

            # Load resources
            gradient_path = os.path.join(self.skin_path, "backdrop.png")
            mask_path = os.path.join(self.skin_path, "mask.png")

            if not os.path.exists(gradient_path) or not os.path.exists(mask_path):
                logdata("Missing mask or gradient")
                return raw_path  # fallback

            background = Image.open(gradient_path).convert('RGBA')
            cover = Image.open(raw_path).convert('RGBA')
            mask = Image.open(mask_path).convert('RGBA')
            w, h = background.size

            try:
                cover = cover.resize((w, h), LANCZOS)
                mask = mask.resize((w, h), LANCZOS)
            except Exception as e:
                logdata("Error resizing image: {}".format(e))

            background.paste(cover, (0, 0), mask)
            background = background.convert('RGB')
            background.save(final_path, quality=90)

            logdata("Backdrop processed and saved", final_path)
            return final_path

        except Exception as e:
            logdata("Backdrop processing error", str(e))
            return None

    def showBackdrop(self):
        try:
            selected_item = self['title_list'].getCurrent()
            if not selected_item:
                return
            movie_titles = selected_item[0]
            movie_title = movie_titles.lower().replace(' ', '').replace('.', '')
            logdata('movie_title eztv backdrop', movie_title)
            if movie_title:
                backdrop_file = ('{}/{}_back.jpg').format(self.poster_directory, movie_title)
                if os.path.exists(backdrop_file):
                    self['screenshot2'].instance.setPixmapFromFile(backdrop_file)
                    self['screenshot2'].show()
                else:
                    logdata('backdrop File Does Not Exist! try original background')
                    self['screenshot2'].hide()
            else:
                self['screenshot2'].hide()
        except Exception as e:
            logdata('Error screenshot2:', str(e))

    def showLogo(self):
        try:
            selected_item = self['title_list'].getCurrent()
            if not selected_item:
                return
            movie_titles = selected_item[0]
            movie_title = movie_titles.lower().replace(' ', '').replace('.', '')
            logdata('movie_title eztv logo', movie_title)
            if movie_title:
                logo_file = ('{}/{}_logo.png').format(self.poster_directory, movie_title)
                logdata('logo File Path:', logo_file)
                if os.path.exists(logo_file):
                    logdata('logo File Exists!')
                    self['screenshot3'].instance.setPixmapFromFile(logo_file)
                    self['screenshot3'].show()
                else:
                    logdata('logo File Does Not Exist!')
                    self['screenshot3'].hide()
            else:
                self['screenshot3'].hide()
        except Exception as e:
            logdata('Error screenshot3:', str(e))

    def browser(self):
        self.session.open(EmissionOverview.EmissionOverview)

    def ghita(self):
        if TMDB_installed:
            selected_item = self['title_list'].getCurrent()
            eventName = selected_item[0]
            if eventName:
                self.session.open(ScreenMain, eventName, 2)
        else:
            self.session.open(MessageBox, _('TMDB Plugin Not Installed.'), MessageBox.TYPE_INFO)

    def ok(self):
        selected_item = self['title_list'].getCurrent()
        if selected_item:
            epi = selected_item[12] or _('Episode')
            choices = [
                (_("*** Open All Episodes ***"), "more"),
                (_("↓ Download {}".format(epi)), "download"),
                (_("> Play {}".format(epi)), "play")  # added space after Play
            ]
            self.session.openWithCallback(self.onChoice, ChoiceBox, title=_("Choose an action"), list=choices)
        else:
            logdata('No movie selected')

    def onChoice(self, choice):
        if choice:
            action = choice[1]
            selected_item = self['title_list'].getCurrent()
            if action == "download":
                torrent_link = selected_item[8]
                movie_title = selected_item[0]
                self.download_movie(torrent_link, movie_title)
            elif action == "play":
                torrent_link = selected_item[8]
                self.play_movie(torrent_link, selected_item)
            elif action == "more":
                logdata("action all episodes", str(action))
                torrent_imdb = selected_item[9]
                logdata("action imdb extracted", torrent_imdb)
                titel = selected_item[0]
                name_unclean = str(titel)
                name = name_unclean.lower().replace(' ', '').replace('.', '')
                poster = os.path.join(self.poster_directory, ('{}_p.jpg').format(name))
                backdrop = os.path.join(self.poster_directory, ('{}_back.jpg').format(name))
                logo = os.path.join(self.poster_directory, ('{}_logo.png').format(name))
                self.session.open(downloadMovie, torrent_imdb, name, poster, backdrop, logo, name_unclean)
        else:
            logdata('No action selected')

    def play_movie(self, torrent_link, selected_item):
        logdata('downloadAndPlay', 'Function called')
        if selected_item:
            title = selected_item[0]
            name_unclean = str(title)
            name = name_unclean.lower().replace(' ', '').replace('.', '')
            poster = os.path.join(self.poster_directory, ('{}_p.jpg').format(name))
            if torrent_link:
                new_torrent = torrsrv.torrent()
                new_torrent.link = torrent_link
                logdata('torrent_link', new_torrent.link)
                new_torrent.title = title
                new_torrent.poster = poster
                new_torrent.save_to_db = True
                if self.my_torr_server.add_torrent(new_torrent):
                    name = new_torrent.title
                    magnet = new_torrent.link
                    titles = [name, magnet]
                    self.session.open(TorrEpisodes, titles, poster)
                else:
                    message = _('Torrent link cannot be added on Torrserv for {}.').format(selected_item[0])
                    self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
                    logdata('Failed to add movie torrent to TorrServer.')
            else:
                message = _('Torrent link not available for {}.').format(selected_item[0])
                self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
                logdata('Movie torrent link not available.')
        else:
            logdata('Movie details not available.')

    def download_movie(self, torrent_link, movie_title):
        if torrent_link:
            download_path = '{}/transmission'.format(config.plugins.torreplayer.poster_path.value)
            download_limit = '1000000'  # in KB/s
            upload_limit = '100'  # in KB/s
            rpc_url = 'http://127.0.0.1:9091/transmission/rpc'

            command = ('transmission-remote {} -a "{}" -w "{}" -d {} -u {}').format(rpc_url, torrent_link, download_path, download_limit, upload_limit)

            title = _('Downloading Movie: ') + movie_title
            self.session.open(Console, title, [command])
        else:
            self.session.open(MessageBox, _('No torrents available for this movie.'), MessageBox.TYPE_INFO)


    def cancel(self):
        self.loading.stop()
        self.close()

    def getpage(self):
        if self.page > 1:
            self['key_green'].setText(_('Previous Page'))

    def nextPage(self):
        self.page += 1
        self.updatePage()

    def goBack(self):
        if self.page > 1:
            self.page -= 1
            self.updatePage()

    def updatePage(self):
        self.loading_time = 5
        self.menu_list = []
        self.text = _('Download Series & TvShow Data For Page[{}]').format(str(self.page))
        self['title_list'].setList(self.menu_list)
        self.loading.start(self.loading_time, _(self.text))
        deferToThread(self.createList).addErrback(self.handleError)

class TransmissionSeriesBrowserGrid(Screen):
    def createSummary(self):
        return TransmissionLCDSummary

    def getLCDSummary(self):
        cur = self["menu"].getCurrent()
        title = cur[0] if cur else ""
        page_info = "Page %d" % self.page
        if self.total_pages > 0:
            page_info = "Page %d / %d" % (self.page, self.total_pages)

        # Calculate Poster Path (Series)
        poster_path = ""
        if cur:
             # Logic similar to movies but adapted for series if needed, or use generic logic
             # For now, try standard poster path logic if applicable or leave empty
             pass

        return {
            "title": title[:32],
            "line1": "Series",
            "line2": "",
            "line3": "",
            "page": page_info,
            "poster": poster_path,
            "backdrop": "",
            "section": self.text,
            "rating": "",
            "progress": 0,
        }

    def __init__(self, session, url, text):
        Screen.__init__(self, session)
        self.imdb_id = None
        self.skin = getSkin('grid')
        self.session = session
        self.url = url
        self.text = str(text)
        self.page = 1
        self.total_pages = -1
        self.menu_list = []
        self.cache_expiry = 86400
        self.stop_event = Event()
        self.skin_path = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')
        poster_dir_base = config.plugins.torreplayer.poster_path.value if config.plugins.torreplayer.poster_path.value else '/tmp'
        self.poster_directory = ('{}/transmission/poster/').format(poster_dir_base)
        self.cache_dir = ('{}/transmission/series_cache/').format(poster_dir_base)
        if not os.path.exists(self.poster_directory):
            try:
                os.makedirs(self.poster_directory)
            except OSError as e:
                logdata('Error creating poster directory:', e)
                self.cache_dir = '/tmp/transmission/series_cache/'
                self.poster_directory = '/tmp'

        self.ratingstars = -1
        self.loading_time = 10
        self.page_cache = {}
        self.onExecBegin.append(self.loader)
        self.onClose.append(self.cleanup)
        self.initializeComponents()
        self.initializeActionMap()
        self.initializeLabels()
        return

    def initializeComponents(self):
        self['pic_loading'] = Pixmap()
        self['int_loading'] = Label('')
        self['msg_loading'] = Label('')
        self.loading = Loading(self['pic_loading'], self['int_loading'], self['msg_loading'], None)
        self.picload = ePicLoad()
        self['menu'] = List()
        self['menu'].onSelectionChanged.append(self.getdata)
        self['screenshot3'] = Pixmap()
        self['fsklogo'] = Pixmap()
        self['rating'] = Label('')
        self['stars'] = ProgressBar()
        self['starsbg'] = Pixmap()
        self['stars'].hide()
        self['starsbg'].hide()
        self['backdrop'] = Pixmap()
        self['backdrop'].hide()
        if config.plugins.torreplayer.skins.value in ('list_old', 'list_new'):
            try:
                self['fatima'] = Label(_("*** Torrents Movies's Browser [YTS]***"))
                self['poster'] = Pixmap()
            except KeyError as e:
                logdata(("Skin widget missing: {e}. Check skin definition for 'list_old'/'list_new' compatibility.").format(e=e))

        return

    def initializeActionMap(self):
        self['actions'] = ActionMap(['DirectionActions', 'EPGSelectActions', 'MenuActions', 'OkCancelActions',
         'ColorActions'], {'ok': self.ok, 'cancel': self.cancel,
           'green': self.goBack,
           'yellow': self.nextPage,
           'red': self.cancel,
           'blue': self.browser,
           'info': self.ghita,
           'menu': self.dream}, -1)

    def initializeLabels(self):
        self['key_red'] = Label(_('Exit'))
        self['key_yellow'] = Label('')
        self['key_green'] = Label('')
        self['key_blue'] = Label(_('Download Manager'))
        self['yassine'] = Label('')
        self['zahra'] = Label('')
        self['genre'] = Label('')
        self['ostende'] = Label('')
        self['page'] = Label('')

    def loader(self):
        """Load data from cache or fetch new data if cache is stale"""
        cache_file = self.get_cache_file_path()
        if self.load_from_cache(cache_file):
            logdata('Loaded from cache: ' + cache_file)
            return
        self.fetch_new_data(cache_file)

    def get_cache_file_path(self):
        """Generate unique cache file path based on page and settings"""
        cache_key = '{}-{}-{}'.format(
            self.page,
            config.plugins.torreplayer.items.value,
            config.plugins.torreplayer.tmdblng.value
        )

        # IMPORTANT: encode before hashing
        hashed_key = hashlib.md5(cache_key.encode('utf-8')).hexdigest()

        return os.path.join(self.cache_dir, 'series_page_{}.cache'.format(hashed_key))


    def load_from_cache(self, cache_file):
        """Load data from cache if valid"""
        try:
            if not os.path.exists(self.cache_dir):
                os.makedirs(self.cache_dir)
            if os.path.exists(cache_file):
                file_age = time.time() - os.path.getmtime(cache_file)
                if file_age < self.cache_expiry:
                    with open(cache_file, 'rb') as (f):
                        cache_data = pickle.load(f)
                    if isinstance(cache_data, dict) and 'menu_list' in cache_data:
                        self.menu_list = []
                        for item in cache_data['menu_list']:
                            item_list = list(item)
                            if len(item_list) > 12:
                                poster_filename = item_list[12]
                                if poster_filename and os.path.exists(poster_filename):
                                    pixmap = self.load_poster_from_file(poster_filename)
                                    if pixmap:
                                        item_list[8] = pixmap
                            self.menu_list.append(tuple(item_list))

                        self.total_pages = cache_data.get('total_pages', -1)
                        self.page_cache[self.page] = self.menu_list
                        self['menu'].setList(self.menu_list)
                        if self.menu_list:
                            self['menu'].index = 0
                            self.getdata()
                        self.updatePageDisplay()
                        self.updateNavButtonLabels()
                        self.loading.stop()
                        return True
        except Exception as e:
            logdata('Cache load error: ' + str(e))

        return False

    def load_poster_from_file(self, filename):
        """Loads a poster from file and returns a Pixmap object"""
        try:
            if os.path.exists(filename):
                return loadJPG(filename)
        except Exception as e:
            logdata(('Error loading poster from {}: {}').format(filename, str(e)))

        return

    def fetch_new_data(self, cache_file):
        """Fetch new data and save to cache"""
        self.loading.start(msg=_('Loading...'))
        self.menu_list = []
        self['menu'].setList(self.menu_list)
        deferToThread(self.fetchAndFilterSeriesData, cache_file).addCallback(self.updateUIWithSeriesData).addErrback(self.handleError)

    def fetchAndFilterSeriesData(self, cache_file):
        """Fetches series from TMDb, filters by EZTV availability, and prepares data for the list."""
        series_list_for_ui = []
        try:
            self.series_found = 0
            self.series_available = 0
            desired_total = int(config.plugins.torreplayer.items.value)
            page = self.page
            while self.series_available < desired_total:
                data = self.get_best_rated_tv_series('8789cfd3fbab7dccf1269c3d7d867aff', page)
                if not data or 'results' not in data:
                    if 'total_pages' in data:
                        self.total_pages = data.get('total_pages', 0)
                    break
                results = data['results']
                total_series_on_page = len(results)
                for idx, series_summary in enumerate(results):
                    tmdb_id = series_summary.get('id')
                    titlex = series_summary.get('name', 'N/A')
                    if not tmdb_id:
                        continue
                    self.series_found += 1
                    url_details = ('https://api.themoviedb.org/3/tv/{}?api_key=3c3efcf47c3577558812bb9d64019d65&append_to_response=external_ids').format(tmdb_id)
                    try:
                        response_details = requests.get(url_details, timeout=10, verify=False)
                        response_details.raise_for_status()
                        data_details = response_details.json()
                        imdb_id = data_details.get('external_ids', {}).get('imdb_id', '')
                    except requests.exceptions.RequestException as e:
                        self.try_callOnMainThread(self.updateLoadingMessage)
                        continue

                    if imdb_id and self.checkSeriesOnEZTV(imdb_id):
                        series_info_tuple = self.createSeriesInfo(series_summary, imdb_id)
                        series_list_for_ui.append(series_info_tuple)
                        self.series_available += 1
                    self.try_callOnMainThread(self.updateLoadingMessage)
                    if self.series_available >= desired_total:
                        break

                if self.series_available >= desired_total:
                    break
                page += 1

            logdata(('Finished fetching. Found: {} series, Available: {}').format(self.series_found, self.series_available))
            self.page_cache[self.page] = series_list_for_ui
            cache_data = {'menu_list': [ item[:8] + (None, ) + item[9:] for item in series_list_for_ui
                          ],
               'total_pages': self.total_pages}
            with open(cache_file, 'wb') as (f):
                pickle.dump(cache_data, f)
            logdata('Data saved to cache: ' + cache_file)
            return series_list_for_ui
        except Exception as e:
            logdata(('Unexpected error in fetchAndFilterSeriesData: {}').format(e))
            traceback.print_exc()
            self.try_callOnMainThread(self.handleError, ('Failed to load series: {}').format(e))
            return []

        return

    def clear_cache(self):
        """Clear all cache files (optional method)"""
        try:
            for filename in os.listdir(self.cache_dir):
                file_path = os.path.join(self.cache_dir, filename)
                if os.path.isfile(file_path):
                    os.unlink(file_path)

            logdata('Cache cleared successfully')
        except Exception as e:
            logdata('Cache clear error: ' + str(e))

    def try_callOnMainThread(self, callable_func, *args, **kwargs):
        """Attempts to call function on main thread using reactor.callFromThread."""
        try:
            reactor.callFromThread(callable_func, *args, **kwargs)
        except Exception as e:
            logdata("Error scheduling call on main thread: {}".format(e))

    def updateLoadingMessage(self):
        """Updates the loading message label and progress bar."""
        desired_total = int(config.plugins.torreplayer.items.value)
        percent = int(self.series_available * 100 / desired_total) if desired_total else 0
        msg = _('Found {} Series, {} Available - Loading ({}%)').format(self.series_found, self.series_available, percent)
        self['msg_loading'].setText(msg)
        self.loading.updateProgress(percent)

    def get_best_rated_tv_series(self, api_key, page):
        """Fetches top-rated TV series from the TMDb API for a specific page."""
        language = config.plugins.torreplayer.tmdblng.value
        url = ('https://api.themoviedb.org/3/tv/top_rated?api_key={}&language={}&page={}').format(api_key, language, page)
        logdata('Fetching TMDb URL:', url)
        response = requests.get(url, stream=True, verify=False, timeout=10)
        response.raise_for_status()
        return response.json()

    def checkSeriesOnEZTV(self, imdb_id):
        """Checks if a series with the given IMDb ID is available on EZTV."""
        if not imdb_id or not imdb_id.startswith('tt'):
            logdata('Invalid IMDb ID for EZTV check:', imdb_id)
            return False
        try:
            eztv_imdb_id = imdb_id.replace('tt', '')
            eztv_url = ('https://eztvx.to/api/get-torrents?imdb_id={}&page=1&limit=5').format(eztv_imdb_id)
            logdata('Checking EZTV URL:', eztv_url)
            response = make_request_with_proxy(eztv_url, timeout=15)
            response.raise_for_status()
            data = response.json()
            is_available = 'torrents' in data and isinstance(data['torrents'], list) and len(data['torrents']) > 0
            if not is_available and data.get('torrents_count', 0) > 0:
                is_available = True
            return is_available
        except requests.exceptions.Timeout:
            logdata(('Timeout checking series on EZTV for IMDb ID {}').format(imdb_id))
            return False
        except requests.exceptions.RequestException as e:
            logdata(('Error checking series on EZTV for IMDb ID: {}').format(e))
            return False
        except (ValueError, json.JSONDecodeError) as e:
            logdata(('Error decoding JSON from EZTV for IMDb ID: {}').format(e))
            return False

    def createSeriesInfo(self, series_summary, imdb_id):
        """Creates and returns a tuple with series information for display list."""
        lang = config.plugins.torreplayer.tmdblng.value
        title = series_summary.get('name', '')
        original_title = series_summary.get('original_name', title)
        display_title = original_title if lang != 'ar' else title
        series_id = series_summary.get('id')
        synopsis = series_summary.get('overview', '')
        genres = series_summary.get('genre_ids', [])
        rating = series_summary.get('vote_average', 0.0)
        poster_path = series_summary.get('poster_path', '')
        res = search_tmdb(title)
        filename = ''
        filename_back = ''
        if res:
            backdrop = res[0].background_url
            title_clean = self.cleanTitle(title)
            filename_back = os.path.join(self.poster_directory, ('{}_b.jpg').format(title_clean))
            self.downloadPicture(backdrop, filename_back)
        Poster = None
        if poster_path:
            title_clean = self.cleanTitle(title)
            filename = os.path.join(self.poster_directory, ('{}.jpg').format(title_clean))
            if os.path.exists(filename):
                Poster = loadJPG(filename)
            else:
                linkPoster = 'http://image.tmdb.org/t/p/w780' + poster_path
                self.downloadPicture(linkPoster, filename)
                if os.path.exists(filename):
                    Poster = loadJPG(filename)
        series_info_tuple = (
         str(display_title),
         series_id,
         genres,
         str(synopsis),
         None,
         str(poster_path),
         '',
         float(rating),
         Poster,
         title,
         str(imdb_id),
         filename_back,
         filename)
        return series_info_tuple

    def downloadPicture(self, url, filename):
        """Downloads and resizes a picture from a URL if needed."""
        if os.path.exists(filename):
            return True
        logdata('Attempting download:', url)
        try:
            response = requests.get(url, stream=True, timeout=20, verify=False)
            if response.status_code == 200:
                tmp_path = filename + '.tmp'
                with open(tmp_path, 'wb') as (file):
                    for chunk in response.iter_content(4096):
                        file.write(chunk)

                success = resize_image(tmp_path, filename)
                os.remove(tmp_path)
                if success:
                    logdata('Picture downloaded & resized:', filename)
                    return filename
                return False
            else:
                logdata('Error downloading picture. Status code:', url)
                return False
        except requests.exceptions.RequestException as e:
            logdata('Error during downloadPicture:', str(e))
            return False

    def updateUIWithSeriesData(self, series_list_result):
        """Updates the UI list with fetched series data."""
        logdata('Updating UI with fetched data...')
        self.loading.stop()
        if not series_list_result:
            logdata("Received empty list, displaying 'No Series Found' message.")
            self.menu_list = []
            self['menu'].setList([])
            self['msg_loading'].setText(_('No series found for this page.'))
        else:
            logdata(('Populating UI with {} series').format(len(series_list_result)))
            self.menu_list = series_list_result
            self['menu'].setList(self.menu_list)
            if self.menu_list:
                self['menu'].index = 0
                self.getdata()
        self.updatePageDisplay()
        self.updateNavButtonLabels()

    def handleError(self, failure):
        """Handles errors, potentially displaying a message. Expected to run on Main Thread."""
        self.loading.stop()
        try:
            error_message = failure.getErrorMessage()
        except AttributeError:
            error_message = str(failure)

        logdata('Error occurred during data fetching/processing:', error_message)
        self['msg_loading'].setText(_('Error: ') + error_message)

    def updatePageDisplay(self):
        """Updates the page display widget."""
        page_text = _('**Page {}**').format(self.page)
        if self.total_pages > 0:
            page_text = _('**Page {} of {}**').format(self.page, self.total_pages)
        self['page'].setText(page_text)

    def updateNavButtonLabels(self):
        """Sets the text for the Next/Previous Page buttons based on current page."""
        if self.total_pages > 0 and self.page < self.total_pages:
            self['key_yellow'].setText(_('Next Page'))
        else:
            self['key_yellow'].setText('')
        if self.page > 1:
            self['key_green'].setText(_('Previous Page'))
        else:
            self['key_green'].setText('')

    def getdata(self):
        """Callback when selection changes. Updates detail view (rating, genre, synopsis, poster etc.)."""
        logdata('Selection changed, updating details...')
        selected_item = self['menu'].getCurrent()
        if not selected_item or not isinstance(selected_item, tuple) or len(selected_item) < 11:
            logdata('Invalid item selected or data structure mismatch.')
            self['rating'].setText('')
            self['stars'].hide()
            self['starsbg'].hide()
            self['genre'].setText('')
            self['yassine'].setText('')
            self['zahra'].setText('')
            self['ostende'].setText('')
            if 'screenshot3' in self:
                self['screenshot3'].hide()
            if 'poster' in self:
                self['poster'].hide()
            if 'backdrop' in self:
                self['backdrop'].hide()
            return
        try:
            self.updateRatingDisplay(selected_item)
            self.updateGenreDisplay(selected_item)
            self.updateTitleDisplay(selected_item)
            self.updateSynopsisDisplay(selected_item)
            self.updateSeedsPeersDisplay(selected_item)
            self.updatePosterDisplay(selected_item)
            self.updateBackdropDisplay(selected_item)
            self.updateLogoDisplay(selected_item)
        except Exception as e:
            logdata(('Error updating details in getdata: {}').format(e))
            traceback.print_exc()

    def updateRatingDisplay(self, current_item):
        """Displays IMDb rating for the current series."""
        try:
            rating_value = float(current_item[7])
            if rating_value > 0:
                star_text = _('Rating IMDB : ') + ('{:.1f}/10').format(rating_value)
                self.ratingstars = int(rating_value * 10)
                self['rating'].setText(star_text)
                self['stars'].setValue(self.ratingstars)
                self['starsbg'].show()
                self['stars'].show()
            else:
                self['rating'].setText(_('Rating: N/A'))
                self['stars'].hide()
                self['starsbg'].hide()
        except (TypeError, ValueError, IndexError) as e:
            logdata(('No valid rating found or index error: {}').format(e))
            self['rating'].setText('')
            self['stars'].hide()
            self['starsbg'].hide()

    def updateGenreDisplay(self, current_item):
        """Displays genre information for the selected series."""
        try:
            genre_ids = current_item[2]
            if genre_ids and isinstance(genre_ids, list):
                genre_text = _('Genres: ') + (', ').join(map(str, genre_ids))
            else:
                genre_text = _('Genres: N/A')
            self['genre'].setText(genre_text)
        except (TypeError, IndexError) as e:
            logdata(('Error setting genre text: {}').format(e))
            self['genre'].setText(_('Genres: Error'))

    def updateSynopsisDisplay(self, current_item):
        """Displays the synopsis of the selected series."""
        try:
            summary = current_item[3]
            if summary:
                self['zahra'].setText(_('Description:\n') + str(summary))
            else:
                self['zahra'].setText(_('Description:\n\nNo Description Found'))
        except IndexError as e:
            logdata(('Error getting synopsis: {}').format(e))
            self['zahra'].setText(_('Description:\n\nError'))

    def updateTitleDisplay(self, current_item):
        """Displays the title of the selected series."""
        try:
            series_title = current_item[0]
            self['yassine'].setText(str(series_title))
        except IndexError as e:
            logdata(('Error setting title: {}').format(e))
            self['yassine'].setText(_('Title Error'))

    def updateSeedsPeersDisplay(self, current_item):
        """Displays seeds and peers (currently placeholder)."""
        self['ostende'].setText(_('Seeds/Peers: N/A'))

    def cleanup(self):
        """Stops the loader when closing the screen."""
        logdata('Cleanup called, stopping loader.')
        self.loading.stop()

    def ok(self):
        """Handles 'OK' action: Opens download screen with processed torrent data"""
        self.loading.stop()
        selected_item = self['menu'].getCurrent()
        if not selected_item or not isinstance(selected_item, tuple) or len(selected_item) < 11:
            logdata('OK pressed on invalid selection.')
            self.session.open(MessageBox, _('Please select a valid series first.'), MessageBox.TYPE_INFO)
            return
        else:
            series_title = selected_item[0]
            imdb_id = selected_item[10]
            eztv_imdb_id = imdb_id.replace('tt', '') if imdb_id else None
            if not eztv_imdb_id:
                logdata('Cannot search: IMDb ID missing or invalid.')
                self.session.open(MessageBox, _('Invalid IMDb ID'), MessageBox.TYPE_ERROR)
                return
            name = self.cleanTitle(selected_item[0])
            poster = os.path.join(self.poster_directory, ('{}_p.jpg').format(name))
            backdrop = os.path.join(self.poster_directory, ('{}_back.jpg').format(name))
            logo = os.path.join(self.poster_directory, ('{}_logo.png').format(name))
            url = ('https://eztvx.to/api/get-torrents?imdb_id={}&page=').format(eztv_imdb_id)
            text = _('Searching [ {} ] Data. Please Wait...').format(series_title)
            self.session.open(TvSearch, url, text)
            return

    def gettmdbdata(self, tmdb_id, title, original_series_info):
        """Fetches detailed TMDb data in the background."""
        logdata(('Background fetch: gettmdbdata for TMDb ID {}').format(tmdb_id))
        if tmdb_id:
            api_key = '8789cfd3fbab7dccf1269c3d7d867aff'
            language = config.plugins.torreplayer.tmdblng.value
            url_imdb = ('https://api.themoviedb.org/3/tv/{}?api_key={}&append_to_response=external_ids,images&language={}').format(tmdb_id, api_key, language)
            try:
                response = requests.get(url_imdb, timeout=15, verify=False)
                response.raise_for_status()
                detailed_data = response.json()
                self.processTmdbData(detailed_data, title, original_series_info)
            except requests.exceptions.RequestException as e:
                logdata(('Error fetching detailed data from  {}').format(e))
            except (ValueError, json.JSONDecodeError) as e:
                logdata(('Error decoding JSON from  {}').format(e))

    def processTmdbData(self, detailed_data, series_title_guess, original_series_info):
        """Processes detailed TMDb data fetched by gettmdbdata."""
        logdata('Processing detailed TMDb data...')
        if not original_series_info or not isinstance(original_series_info, tuple) or len(original_series_info) < 11:
            logdata('Invalid original_series_info passed to processTmdbData.')
            return
        try:
            imdb_id = detailed_data.get('external_ids', {}).get('imdb_id', '')
            overview = detailed_data.get('overview', original_series_info[3])
            genres_data = detailed_data.get('genres', [])
            genre_ids = [ g['id'] for g in genres_data if 'id' in g ] if genres_data else original_series_info[2]
            poster_path = detailed_data.get('poster_path', original_series_info[5])
            backdrop_path = detailed_data.get('backdrop_path', '')
            updated_series_info_list = list(original_series_info)
            updated_series_info_list[3] = str(overview)
            updated_series_info_list[2] = genre_ids
            updated_series_info_list[5] = str(poster_path)
            updated_series_info_list[10] = str(imdb_id)
            updated_series_info_tuple = tuple(updated_series_info_list)
            self.try_callOnMainThread(self._updateMenuItem, original_series_info, updated_series_info_tuple)
            clean_title = self.cleanTitle(original_series_info[0])
            self.downloadPosterAndBackdrop(clean_title, poster_path, backdrop_path)
        except Exception as e:
            logdata(('Error processing detailed TMDb data: {}').format(e))
            traceback.print_exc()

    def _updateMenuItem(self, old_tuple, new_tuple):
        """Helper to update an item in self.menu_list (intended for main thread call)."""
        try:
            old_tmdb_id = old_tuple[1]
            found_idx = -1
            for i, item in enumerate(self.menu_list):
                if len(item) > 1 and item[1] == old_tmdb_id:
                    found_idx = i
                    break

            if found_idx != -1:
                self.menu_list[found_idx] = new_tuple
                self['menu'].setList(self.menu_list)
                logdata(('Updated item in menu_list at index {}.').format(found_idx))
            else:
                logdata(('Item to update (TMDb ID {}) not found in menu_list.').format(old_tmdb_id))
        except (ValueError, IndexError, TypeError) as e:
            logdata(('Error finding/updating menu list item: {}').format(e))
        except Exception as e:
            logdata(('General error in _updateMenuItem: {}').format(e))

    def downloadPosterAndBackdrop(self, clean_title, poster_path, backdrop_path):
        """Downloads poster and backdrop images if paths are provided."""
        if poster_path:
            url_poster = 'http://image.tmdb.org/t/p/w780' + poster_path
            filenameP = os.path.join(self.poster_directory, ('{}_p.jpg').format(clean_title))
            self.downloadPicture(url_poster, filenameP)
        if backdrop_path:
            url_backdrop = 'http://image.tmdb.org/t/p/w1920' + backdrop_path
            filenameB = os.path.join(self.poster_directory, ('{}_b.jpg').format(clean_title))
            self.downloadPicture(url_backdrop, filenameB)

    def cleanTitle(self, title):
        if isinstance(title, bytes):
            title = title.decode('utf-8', 'ignore')

        title_clean = title.lower()
        title_clean = re.sub(r'[\\/*?:"<>|]', '', title_clean, flags=re.UNICODE)
        title_clean = re.sub(r'\s+', '_', title_clean, flags=re.UNICODE)
        max_len = 50
        title_clean = title_clean[:max_len]
        return ensure_str(title_clean)

    def cancel(self):
        """Closes the screen."""
        logdata('Cancel/Red button pressed.')
        self.close()

    def updatePosterDisplay(self, selected_item):
        """Shows the poster for the selected item."""
        if 'poster' not in self:
            return
        try:
            title_for_file = selected_item[12]
            poster_filename = os.path.join(self.poster_directory, ('{}.jpg').format(title_for_file))
            logdata('Looking for poster:', poster_filename)
            if os.path.exists(poster_filename):
                pixmap = loadJPG(poster_filename)
                if pixmap:
                    self['poster'].instance.setPixmap(pixmap)
                    self['poster'].show()
                else:
                    logdata('loadJPG failed for:', poster_filename)
                    self['poster'].hide()
            else:
                self['poster'].hide()
                poster_path = selected_item[5]
                if poster_path:
                    url_poster = 'http://image.tmdb.org/t/p/w780' + poster_path
                    logdata('Poster file missing, hiding widget.')
        except (IndexError, TypeError) as e:
            logdata(('Error showing poster: {}').format(e))
            if 'poster' in self:
                self['poster'].hide()
        except Exception as e:
            logdata(('General Error in updatePosterDisplay: {}').format(e))
            if 'poster' in self:
                self['poster'].hide()

    def updateBackdropDisplay(self, selected_item):
        """Shows the backdrop for the selected item."""
        if 'backdrop' not in self:
            return
        try:
            backdrop_filename = selected_item[12]
            logdata('Looking for backdrop:', backdrop_filename)
            if os.path.exists(backdrop_filename):
                pixmap = loadJPG(backdrop_filename)
                if pixmap:
                    self['backdrop'].instance.setPixmap(pixmap)
                    self['backdrop'].show()
                else:
                    logdata('loadJPG failed for:', backdrop_filename)
                    self['backdrop'].hide()
            else:
                self['backdrop'].hide()
                logdata('Backdrop file missing, hiding widget.')
        except (IndexError, TypeError) as e:
            logdata(('Error showing backdrop: {}').format(e))
            self['backdrop'].hide()
        except Exception as e:
            logdata(('General Error in updateBackdropDisplay: {}').format(e))
            self['backdrop'].hide()

    def updateLogoDisplay(self, selected_item):
        """Shows the logo (clearart) for the selected item."""
        if 'screenshot3' not in self:
            return
        try:
            title_for_file = self.cleanTitle(selected_item[0])
            logo_filename = os.path.join(self.poster_directory, ('{}_logo.png').format(title_for_file))
            logdata('Looking for logo:', logo_filename)
            if os.path.exists(logo_filename):
                pixmap = loadJPG(logo_filename)
                if pixmap:
                    self['screenshot3'].instance.setPixmap(pixmap)
                    self['screenshot3'].show()
                else:
                    logdata('loadJPG failed for logo:', logo_filename)
                    self['screenshot3'].hide()
            else:
                self['screenshot3'].hide()
                logdata('Logo file missing, hiding widget.')
        except (IndexError, TypeError) as e:
            logdata(('Error showing logo: {}').format(e))
            self['screenshot3'].hide()
        except Exception as e:
            logdata(('General Error in updateLogoDisplay: {}').format(e))
            self['screenshot3'].hide()

    def dream(self):
        """Placeholder for Menu button action."""
        logdata('Menu button pressed (dream action - no implementation).')

    def browser(self):
        """Opens the Transmission Download Manager/Overview screen."""
        logdata('Blue button pressed, opening EmissionOverview.')
        try:
            from Plugins.Extensions.Transmission.TransmissionBrowser import EmissionOverview
            self.session.open(EmissionOverview.EmissionOverview)
        except ImportError:
            logdata('Error: Could not import EmissionOverview.')
            self.session.open(MessageBox, _('Download manager screen is unavailable (Import Error).'), MessageBox.TYPE_ERROR)
        except NameError:
            logdata('Error: EmissionOverview class not defined.')
            self.session.open(MessageBox, _('Download manager screen is unavailable (Name Error).'), MessageBox.TYPE_ERROR)
        except AttributeError:
            logdata('Error: EmissionOverview structure incorrect (e.g., missing nested class).')
            self.session.open(MessageBox, _('Download manager screen is unavailable (Attribute Error).'), MessageBox.TYPE_ERROR)

    def ghita(self):
        """Opens TMDB details screen if TMDB plugin is installed."""
        logdata('Info button pressed (ghita action).')
        if TMDB_installed:
            selected_item = self['menu'].getCurrent()
            if selected_item and isinstance(selected_item, tuple) and len(selected_item) > 0:
                eventName = selected_item[0]
                logdata(('Opening TMDB plugin (ScreenMain) for event: {}').format(eventName))
                try:
                    from Plugins.Extensions.TMDb.plugin import ScreenMain
                    self.session.open(ScreenMain, eventName, 2)
                except ImportError:
                    logdata('Error: Could not import ScreenMain from TMDb plugin.')
                    self.session.open(MessageBox, _('TMDB detail screen is unavailable (Import Error).'), MessageBox.TYPE_ERROR)
                except NameError:
                    logdata('Error: ScreenMain class not defined.')
                    self.session.open(MessageBox, _('TMDB detail screen is unavailable (Name Error).'), MessageBox.TYPE_ERROR)

            else:
                logdata('No valid item selected for TMDB lookup.')
                self.session.open(MessageBox, _('Please select a series first.'), MessageBox.TYPE_INFO)
        else:
            logdata('TMDB Plugin not installed.')
            self.session.open(MessageBox, _('TMDB Plugin is not installed.'), MessageBox.TYPE_INFO)

    def nextPage(self):
        """Loads the next page of results."""
        if self.total_pages > 0 and self.page >= self.total_pages:
            self.session.open(MessageBox, _('No more pages.'), MessageBox.TYPE_INFO)
            return
        self.page += 1
        self.updatePage()

    def goBack(self):
        """Loads the previous page of results."""
        if self.page > 1:
            self.page -= 1
            self.updatePage()

    def updatePage(self):
        """Updates the UI for the current page, using cache if available."""
        if self.page in self.page_cache:
            self.loader()
        else:
            self.loader()

class downloadMovie(Screen):

    def __init__(self, session, imdb_id, name, poster, backdrop, logo, title):
        Screen.__init__(self, session)
        self.skin = getSkin('EZTV Torrent Episode Browser')
        self["pic_loading"] = Pixmap()
        self["int_loading"] = Label('')
        self["msg_loading"] = Label('')
        self.loading = Loading(self["pic_loading"], self["int_loading"], self["msg_loading"], None)
        self.picload = ePicLoad()
        self.session = session
        self.imdb_id = imdb_id
        self.meknes = str(name)
        self.poster = poster
        self.backdrops = backdrop
        self.logo = logo
        self.skin_path = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')

        self.torrents = []
        self.menu_list = []
        self.movies = []
        self['title_list'] = List(self.menu_list)
        self.page = 1
        self['fatima'] = Label(_('*.*.* [EZTV] Episode Browser *.*.*'))
        self.url = 'https://eztvx.to/api/get-torrents?imdb_id={}&limit={}'.format(self.imdb_id, str(config.plugins.torreplayer.items.value))
        logdata("downloadmovie screen launched __ url", str(self.url))
        self.data = None
        self['actions'] = ActionMap(['DirectionActions', 'EPGSelectActions', 'MenuActions', 'OkCancelActions', 'ColorActions'],
                                    {'ok': self.ok, 'cancel': self.close, 'green': self.goBack, 'yellow': self.nextPage,
                                     'red': self.close, 'blue': self.browser, 'info': self.ghita}, -1)
        self['key_red'] = Label(_('Exit'))
        self['key_yellow'] = Label(_('Next'))
        self['key_blue'] = Label(_('Download Manager'))
        self['key_green'] = Label('')
        self['yassine'] = Label('')
        self['season'] = Label('')
        self['size'] = Label('')
        self['ostende'] = Label('')
        self['zahra'] = Label('')
        self.my_torr_server = ts
        self['screenshot'] = Pixmap()
        self['screenshot2'] = Pixmap()
        self['screenshot3'] = Pixmap()
        self.darwin_directory = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')
        self.poster_directory = '{}/transmission/poster'.format(config.plugins.torreplayer.poster_path.value)
        self.text = ''
        self.onExecBegin.append(self.loader)
        self.onClose.append(self.cleanup)
        self['title_list'].onSelectionChanged.append(self.getdata)
        self.loading_time = 5

    def loader(self):
        if self.menu_list:
            self.loading.stop()
        else:
            self.text = _("Downloading Episodes Data Please Wait ...")
            self.loading.start(self.loading_time, _(self.text))
            threading.Thread(target=self.get_data).start()

    def get_data(self):
        self.parse_data(self.url)

    def parse_data(self, url):
        try:
            # Use proxy if enabled
            response = make_request_with_proxy(url, timeout=15)
            if not response:
                logdata('Error: Failed to fetch data (proxy or direct connection failed)')
                return
            response.raise_for_status()
            data = response.json()
        except requests.exceptions.RequestException as e:
            logdata('Error during HTTP request:', str(e))
            return
        except ValueError as e:
            logdata('Error parsing JSON:', str(e))
            return
        self.data = data
        if self.data is None:
            logdata('No data to parse. Please retrieve data first.', None)
            return
        else:
            self.total_pages = self.data.get('data', {}).get('page_count', 1)
            torrents = self.data.get('torrents', [])
            self.menu_list = []
            Poster = None
            for torrent in torrents:
                title = torrent.get('title')
                if title:
                    match = re.match('(.+?)\\sS\\d{2}E\\d{2}', title)
                    cleaned_title = match.group(1) if match else title.strip()
                    movie_title = str(cleaned_title)
                title2 = torrent.get('filename')
                titlex = re.sub('\\[.*?\\]', '', title2).strip()
                titles = titlex.lower().replace(' ', '').replace('.', '')
                large_screenshots = torrent.get('large_screenshot')
                large_screenshot = str('http:' + large_screenshots)
                if large_screenshot:
                    filename = os.path.join(self.poster_directory, '{}.jpg'.format(titles))
                    filename_b = os.path.join(self.poster_directory, '{}_back.jpg'.format(titles))
                    self.downloadPicture(large_screenshot, filename)
                    if os.path.exists(filename) and str(config.plugins.torreplayer.skins.value) != "list":
                        try:
                            Poster = loadJPG(filename_b)
                        except:
                            Poster = loadJPG(filename)
                seeds = torrent.get('seeds')
                peers = torrent.get('peers')
                season = torrent.get('season')
                episode = torrent.get('episode')
                if episode:
                    Ep = 'Episode: ' + episode
                size_bytes = torrent.get('size_bytes')
                year = torrent.get('date_released_unix')
                imdb = torrent.get('imdb_id')
                logdata('imdb', imdb)
                torrent_url = torrent.get('torrent_url')
                torrent_link = torrent.get('magnet_url')
                torrent_info = (str(movie_title), large_screenshot, seeds, peers, season, episode, size_bytes, year,
                                torrent_link, imdb, str(titlex), Poster, str(Ep))
                self.menu_list.append(torrent_info)
                self.setListInUI()
            if response.status_code != 200:
                logdata('Failed to retrieve data. Status Code: {}'.format(response.status_code))
                tesxt = _('No Data Server Is down')
                self.menu_list.append(tesxt)
                self.setListInUI()
                return
            return

    def setListInUI(self):
        self.loading.stop()
        self['title_list'].setList(self.menu_list)

    def cleanup(self):
        self.loading.stop()

    def yassine(self):
        selected_item = self['title_list'].getCurrent()
        if selected_item:
            movie_title = selected_item[0]
            movie_title = str(movie_title)
            if movie_title:
                try:
                    self['yassine'].setText(movie_title)
                except Exception as e:
                    logdata('Error set title:', str(e))
        else:
            logdata('No item selected in title_list')

    def hanan(self):
        title = self.meknes
        movie_title = title.lower().replace(' ', '').replace('.', '')
        json_filename = os.path.join(self.poster_directory, ('{}.json').format(movie_title))
        try:
            with open(json_filename, 'r') as (json_file):
                movie_data = json.load(json_file)
                overview = movie_data.get('overview', '')
                self['zahra'].setText(_('Description:\n') + str(overview) if overview else _('\n\nNo Description Found'))
        except Exception as e:
            logdata('Error reading JSON file:', str(e))
            self['zahra'].setText(_('\n\nNo Description Found'))

    def downloadPicture(self, url, filename):
        if os.path.exists(filename):
            pass
        else:
            try:
                response = requests.get(url, verify=False)
                if response.status_code == 200:
                    with open(filename, 'wb') as (file):
                        for chunk in response.iter_content(1024):
                            file.write(chunk)

            except Exception as e:
                logdata('Error downloadPicture EZTV episode', str(e))

    def season(self):
        try:
            seasons = str(self['title_list'].getCurrent()[4])
            episode = str(self['title_list'].getCurrent()[5])
            genre_text = _('Season: ') + seasons + _(' | Episode: ') + episode
            logdata('season printing', genre_text)
            self['season'].setText(genre_text)
        except Exception as e:
            logdata('self[season] downlaodmovie class:', str(e))


    def size(self):
        try:
            size_bytes = int(self['title_list'].getCurrent()[6])
            if size_bytes >= 1073741824:
                size_gb = size_bytes / 1073741824
                size_text = _('Size: {:.2f} Go').format(size_gb)
            else:
                size_mb = size_bytes / 1048576
                size_text = _('Size: {:.2f} Mo').format(size_mb)
            logdata('size printing', size_text)
            self['size'].setText(size_text)
        except Exception as e:
            logdata('self[size] downlaodmovie class:', str(e))

    def seedsandpeers(self):
        try:
            seeds = str(self['title_list'].getCurrent()[2])
            peers = str(self['title_list'].getCurrent()[3])
            self['ostende'].setText(_('Seeds: ') + seeds + _(' | Peers: ') + peers)
        except Exception as e:
            logdata('self[ostende] downlaodmovie class:', str(e))

    def getdata(self):
        self.getpage()
        self.yassine()
        self.seedsandpeers()
        self.season()
        self.size()
        self.showPoster()
        self.showBackdrop()
        self.showLogo()
        self.hanan()

    def showPoster(self):
        try:
            filename = self.poster
            default = ('{}/default.svg').format(self.darwin_directory)
            if os.path.exists(filename):
                self['screenshot'].instance.setPixmapFromFile(filename)
                self['screenshot'].show()
            else:
                logdata('Poster File Does Not Exist episode!')
                self['screenshot'].instance.setPixmapFromFile(default)
                self['screenshot'].show()
        except Exception as e:
            logdata('Error screenshot:', str(e))

    def showBackdrop(self):
        try:
            filename = self.backdrops
            if os.path.exists(filename):
                self['screenshot2'].instance.setPixmapFromFile(filename)
                self['screenshot2'].show()
            else:
                self['screenshot2'].hide()
        except Exception as e:
            logdata('Error screenshot2:', str(e))

    def showLogo(self):
        try:
            logo_file = self.logo
            if os.path.exists(logo_file):
                logdata('logo episode File Exists!')
                self['screenshot3'].instance.setPixmapFromFile(logo_file)
                self['screenshot3'].show()
            else:
                logdata('logo episode File Does Not Exist!')
                self['screenshot3'].hide()
        except Exception as e:
            logdata('Error screenshot3:', str(e))

    def browser(self):
        self.session.open(EmissionOverview.EmissionOverview)

    def ghita(self):
        if TMDB_installed:
            selected_item = self['title_list'].getCurrent()
            eventName = selected_item[0]
            if eventName:
                self.session.open(TMBD, eventName)
        else:
            self.session.open(MessageBox, _('TMDB Plugin Not Installed.'), MessageBox.TYPE_INFO)

    def ok(self):
        selected_item = self['title_list'].getCurrent()
        if selected_item:
            choices = [(_("Download"), "download"), (_("Play"), "play")]
            self.session.openWithCallback(self.onChoice, ChoiceBox, title=_("Choose an action"), list=choices)
        else:
            logdata('No movie selected')

    def onChoice(self, choice):
        if choice:
            action = choice[1]
            selected_item = self['title_list'].getCurrent()
            if action == "download":
                torrent_link = selected_item[8]
                movie_title = selected_item[0]
                self.download_movie(torrent_link, movie_title)
            elif action == "play":
                torrent_link = selected_item[8]
                self.play_movie(torrent_link, selected_item)
        else:
            logdata('No action selected')

    def play_movie(self, torrent_link, selected_item):
        logdata('downloadAndPlay', 'Function called')
        if selected_item:
            title = selected_item[0]
            filename = self.poster
            if torrent_link:
                new_torrent = torrsrv.torrent()
                new_torrent.link = torrent_link
                logdata('torrent_link', new_torrent.link)
                new_torrent.title = title
                new_torrent.poster = selected_item[1]
                new_torrent.save_to_db = True
                if self.my_torr_server.add_torrent(new_torrent):
                    name = new_torrent.title
                    magnet = new_torrent.link
                    titles = [name, magnet]
                    self.session.open(TorrEpisodes, titles, filename)
                else:
                    message = _('Torrent link cannot be added on Torrserv for {}.').format(selected_item[0])
                    self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
                    print('Failed to add movie torrent to TorrServer.')
            else:
                message = _('Torrent link not available for {}.').format(selected_item[0])
                self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
                print('Movie torrent link not available.')
        else:
            print('Movie details not available.')

    def download_movie(self, torrent_link, movie_title):
        if torrent_link:
            download_path = '{}/transmission'.format(config.plugins.torreplayer.poster_path.value)
            download_limit = '1000000'  # in KB/s
            upload_limit = '100'  # in KB/s
            rpc_url = 'http://127.0.0.1:9091/transmission/rpc'

            command = ('transmission-remote {} -a "{}" -w "{}" -d {} -u {}').format(rpc_url, torrent_link, download_path, download_limit, upload_limit)

            title = _('Downloading Movie: ') + movie_title
            self.session.open(Console, title, [command])
        else:
            self.session.open(MessageBox, _('No torrents available for this movie.'), MessageBox.TYPE_INFO)

    def getpage(self):
        if self.page > 1:
            self['key_green'].setText(_('Previous Page'))

    def nextPage(self):
        self.page += 1
        self.updatePage()

    def goBack(self):
        if self.page > 1:
            self.page -= 1
            self.updatePage()

    def updatePage(self):
        self.loading_time = 5
        self.menu_list = []
        refresh_list = ('', '', '', '', '', '', '', '', '', '', '', '', '')
        self.menu_list.append(refresh_list)
        self.text = _('Download More Episodes Data For {} Page[{}]').format(self.meknes, str(self.page))
        self['title_list'].setList(self.menu_list)
        self.loading.start(self.loading_time, _(self.text))
        self.stimer.stop()  # Stop any previous timer
        self.stimer.start(6000, True)  # Start the timer to call get_data in 10 seconds

class TvSearch(Screen):
    def __init__(self, session, url, text):
        Screen.__init__(self, session)
        self.skin = getSkin(str(config.plugins.torreplayer.skins_tv.value))
        self["pic_loading"] = Pixmap()
        self["int_loading"] = Label('')
        self["msg_loading"] = Label('')
        self.loading = Loading(self["pic_loading"], self["int_loading"], self["msg_loading"], None)
        self.picload = ePicLoad()
        self.skin_path = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')
        self.torrents = []
        self.menu_list = []
        self.movies = []
        self['title_list'] = List(self.menu_list)
        self.page = 0
        self.url = url
        self.data = None
        self.text = str(text)
        self['actions'] = ActionMap(['DirectionActions', 'EPGSelectActions', 'MenuActions', 'OkCancelActions', 'ColorActions'],
                                    {'ok': self.ok, 'cancel': self.close, 'green': self.goBack, 'yellow': self.nextPage,
                                     'red': self.close, 'blue': self.browser, 'info': self.ghita}, -1)
        self['key_red'] = Label(_('Exit'))
        self['key_yellow'] = Label(_('Next'))
        self['key_blue'] = Label(_('Download Manager'))
        self['key_green'] = Label('')
        self['fatima'] = Label(_("*** Torrent Series & TvShow's Browser [EZTV]***"))
        self['yassine'] = Label('')
        self['season'] = Label('')
        self['size'] = Label('')
        self['ostende'] = Label('')
        self['zahra'] = Label('')
        self.my_torr_server = ts
        self['screenshot'] = Pixmap()
        if config.plugins.torreplayer.bacdrop.value == False:
            self['screenshot2'] = Pixmap()
        self['screenshot3'] = Pixmap()
        self['info_label'] = Label('')
        self.darwin_directory = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')
        self.poster_directory = '{}/transmission/poster'.format(config.plugins.torreplayer.poster_path.value)
        self.stimer = eTimer()

        self.backdropLoad = ePicLoad()
        self.backdropLoad.PictureData.get().append(self.DecodeBackdrop)
        self.onLayoutFinish.append(self.loader)
        self.onClose.append(self.stimer.stop)
        self.onClose.append(self.getdata)
        self['title_list'].onSelectionChanged.append(self.getdata)
        self.loading_time = 5

    def loader(self):
        if self.menu_list:
            self.loading.stop()
        else:
            self.loading.start(self.loading_time, _(self.text))
            threading.Thread(target=self.get_data).start()

    def update_loading(self):
        self.loading_time -= 1
        if self.loading_time <= 0:
            self.loading_time = 0
        self.loading.update(self.loading_time)
        if self.loading_time > 0:
            threading.Thread(target=self.get_data).start()

    def get_data(self):
        self.base_url = self.url + str(self.page)
        self.fetch_data(self.base_url)

    def fetch_data(self, url):
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': 'application/json'
            }
            response = requests.get(url, headers=headers, verify=False, timeout=10)
            response.raise_for_status()
            data = response.json()
            self.process_data(data)
        except requests.exceptions.RequestException as e:
            print('Error during HTTP request: {}'.format(e))
        except ValueError as e:
            print('Error parsing JSON: {}'.format(e))

    def process_data(self, data):
        self.data = data
        if self.data is None:
            print('No data to parse. Please retrieve data first.')
            return
        self.total_pages = self.data.get('data', {}).get('page_count', 1)
        torrents = self.data.get('torrents', [])
        for torrent in torrents:
            title = torrent.get('title')
            if title:
                match = re.match('(.+?)\\sS\\d{2}E\\d{02}', title)
                cleaned_title = match.group(1) if match else title.strip()
                movie_title = str(cleaned_title)
            title2 = torrent.get('filename')
            titlex = re.sub('\\[.*?\\]', '', title2).strip()
            titles = titlex.lower().replace(' ', '').replace('.', '')
            imdb = torrent.get('imdb_id')
            if imdb:
                self.gettmdbdata(imdb, movie_title)
                logdata('imdb', imdb)
            large_screenshots = torrent.get('large_screenshot')
            large_screenshot = str('http:' + large_screenshots)
            if large_screenshot:
                filename = os.path.join(self.poster_directory, '{}.jpg'.format(titles))
                filename_b = os.path.join(self.poster_directory, '{}_b.jpg'.format(titles))
                self.downloadPicture(large_screenshot, filename)
                if str(config.plugins.torreplayer.skins.value) != "list":
                    try:
                        Poster = loadJPG(filename)
                    except:
                        Poster = loadJPG(filename_b)
            if config.plugins.torreplayer.skins_tv.value == 'EZTV_banner':
                filename = os.path.join(self.poster_directory, '{}_banner.jpg'.format(titles))
                if os.path.exists(filename):
                    Poster = loadJPG(filename)
                self.banner(movie_title, filename)
            seeds = torrent.get('seeds')
            peers = torrent.get('peers')
            year_unix = torrent.get('date_released_unix')
            season = torrent.get('season')
            episode = torrent.get('episode')
            if year_unix:
                year = datetime.utcfromtimestamp(year_unix).strftime('%Y-%m-%d')
            else:
                year = 'Unknown'
            Ep = ''
            if episode and season:
                if config.plugins.torreplayer.skins_tv.value == 'EZTV_banner':
                    Ep = _('Year: ') + year + _(' Episode: ') + episode + _(' Season: ') + season
                else:
                    Ep = _('Ep: ') + episode + _(' / S: ') + season
            size_bytes = torrent.get('size_bytes', 0)
            if config.plugins.torreplayer.skins_tv.value == 'EZTV_grid':
                filenameM = os.path.join(self.poster_directory, '{}_p.jpg'.format(titles))
                if os.path.exists(filenameM):
                    Poster = loadJPG(filenameM)
                self.getposter(imdb, movie_title)
            torrent_url = torrent.get('torrent_url')
            torrent_link = torrent.get('magnet_url')
            torrent_info = (
                str(movie_title), large_screenshot, seeds, peers, season, episode, size_bytes, year, torrent_link, imdb,
                str(titlex), Poster, str(Ep))
            self.menu_list.append(torrent_info)
            self.setListInUI()  # Update UI after each movie

        self.stimer.stop()


    def setListInUI(self):
        self.loading.stop()
        self.stimer.stop()
        self['title_list'].setList(self.menu_list)

    def yassine(self):
        selected_item = self['title_list'].getCurrent()
        if selected_item:
            movie_title = selected_item[0]
            movie_title = str(movie_title)
            if movie_title:
                try:
                    self['yassine'].setText(movie_title)
                except Exception as e:
                    logdata('Error set title:', str(e))

        else:
            logdata('No item selected in title_list')

    def gettmdbdata(self, torrent_imdb, titel):
        if titel:
            imdb_ID = str('tt' + torrent_imdb)
            url_imdb = ('https://api.themoviedb.org/3/find/{}?api_key=8789cfd3fbab7dccf1269c3d7d867aff&external_source=imdb_id').format(imdb_ID)
            name_unclean = str(titel)
            name = name_unclean.lower().replace(' ', '').replace('.', '')
            try:
                response = requests.get(url_imdb, verify=False)
                data = response.json()
                if 'tv_results' in data and data['tv_results']:
                    tv_result = data['tv_results'][0]
                    overview = tv_result.get('overview', '')
                    movie_titles = tv_result.get('original_name', '')
                    movie_title = movie_titles.lower().replace(' ', '')
                    poster_path = tv_result.get('poster_path', '')
                    backdrop_path = tv_result.get('backdrop_path', '')
                    id_tvdb = tv_result.get('id', '')
                    if id_tvdb:
                        self.logo(id_tvdb, movie_title, name)
                    if poster_path:
                        url_poster = 'http://image.tmdb.org/t/p/original' + poster_path
                        filenameP = os.path.join(self.poster_directory, ('{}_p.jpg').format(name))
                        self.downloadPicture(url_poster, filenameP)
                    if backdrop_path and config.plugins.torreplayer.bacdrop.value == False:
                        url_backdrop = 'http://image.tmdb.org/t/p/original' + backdrop_path
                        filenameB = os.path.join(self.poster_directory, ('{}.jpg').format(name))
                        self.downloadPicture(url_backdrop, filenameB)
                    movie_data = {'title': movie_title, 'overview': overview}
                    json_filename = os.path.join(self.poster_directory, ('{}.json').format(name))
                    with open(json_filename, 'w') as (json_file):
                        json.dump(movie_data, json_file)
                else:
                    logdata('No TV results found for the given IMDb ID')
            except requests.exceptions.RequestException as e:
                logdata('Error fetching data from TMDb:', str(e))

    def logo(self, id_tvdb, movie_title, name):
        ext = 'https://api.themoviedb.org/3/tv/' + str(id_tvdb) + '/images?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=en-US&include_image_language=en,null'
        try:
            response = requests.get(ext, verify=False)
            data = response.json()
            if 'logos' in data and data['logos']:
                logo_result = data['logos'][0]
                logo_path = logo_result.get('file_path', '')
                if logo_path:
                    url_logo = 'http://image.tmdb.org/t/p/original' + logo_path
                    filename_logo = os.path.join(self.poster_directory, ('{}_logo.png').format(name))
                    self.downloadPicture(url_logo, filename_logo)
            else:
                logdata('No logo found for the given TVDB ID')
        except requests.exceptions.RequestException as e:
            logdata('Error fetching logo data from TMDb:', str(e))

    def banner(self, titel, filename):
        name_unclean = str(titel)
        logdata("banner", name_unclean)
        name = name_unclean.lower().replace(' ', '').replace('.', '')
        url_tvdb = 'https://thetvdb.com/api/GetSeries.php?seriesname={}'.format(name_unclean)
        try:
            response = requests.get(url_tvdb, verify=False)
            response.raise_for_status()
            url_read = response.text
        except requests.exceptions.RequestException as e:
            logdata("Failed to fetch series ID", str(e))
            return
        series_ids = re.findall('<seriesid>(.*?)</seriesid>', url_read)
        if series_ids:
            series_id = series_ids[0]
            url_tvdb = 'https://thetvdb.com/api/a99d487bb3426e5f3a60dea6d3d3c7ef/series/{}/en.xml'.format(series_id)
            try:
                response = requests.get(url_tvdb, verify=False)
                response.raise_for_status()
                url_read = response.text
            except requests.exceptions.RequestException as e:
                logdata("Failed to fetch series details", str(e))
                return
            poster = re.findall('<banner>(.*?)</banner>', url_read)
            if poster:
                url_poster = 'https://artworks.thetvdb.com/banners/{}'.format(poster[0])
                self.downloadPicture(url_poster, filename)
            backdrop = re.findall('<fanart>(.*?)</fanart>', url_read)
            if backdrop:
                filename_logo = ('{}/{}_banner.jpg').format(self.poster_directory, name)
                if not os.path.exists(filename_logo):
                    url_backdrop = 'https://artworks.thetvdb.com/banners/{}'.format(backdrop[0])
                    self.downloadPicture(url_backdrop, filename_logo)
        else:
            logdata("No series ID found in the URL response", "")
            return

    def getposter(self, torrent_imdb, titel):
        if titel:
            imdb_ID = str('tt' + torrent_imdb)
            url_imdb = ('https://api.themoviedb.org/3/find/{}?api_key=8789cfd3fbab7dccf1269c3d7d867aff&external_source=imdb_id').format(imdb_ID)
            name_unclean = str(titel)
            name = name_unclean.lower().replace(' ', '').replace('.', '')
            try:
                response = requests.get(url_imdb, verify=False)
                data = response.json()
                if 'tv_results' in data and data['tv_results']:
                    tv_result = data['tv_results'][0]
                    movie_titles = tv_result.get('original_name', '')
                    movie_title = movie_titles.lower().replace(' ', '')
                    poster_path = tv_result.get('poster_path', '')
                    if poster_path:
                        url_poster = 'http://image.tmdb.org/t/p/original' + poster_path
                        filenameP = os.path.join(self.poster_directory, ('{}_p.jpg').format(name))
                        self.downloadPicture(url_poster, filenameP)
                else:
                    logdata('No TV results found for the given IMDb ID')
            except requests.exceptions.RequestException as e:
                logdata('Error fetching data from TMDb:', str(e))

    def hanan(self):
        try:
            title = str(self['title_list'].getCurrent()[0])
            movie_title = title.lower().replace(' ', '').replace('.', '')
            json_filename = os.path.join(self.poster_directory, ('{}.json').format(movie_title))
            with open(json_filename, 'r') as (json_file):
                movie_data = json.load(json_file)
                overview = movie_data.get('overview', '')
                self['zahra'].setText(_('Description:\n' )+ str(overview) if overview else _('\n\nNo Description Found'))
        except Exception as e:
            logdata('Error reading JSON file:', str(e))
            self['zahra'].setText(_('\n\nNo Description Found'))

    def downloadPicture(self, url, filename):
        if os.path.exists(filename):
            pass
        else:
            try:
                response = requests.get(url, verify=False)
                if response.status_code == 200:
                    with open(filename, 'wb') as (file):
                        for chunk in response.iter_content(1024):
                            file.write(chunk)

            except Exception as e:
                logdata('Error downloadPicture EZTV', str(e))

    def season(self):
        current = self['title_list'].getCurrent()
        if current is None:
            return
        seasons = str(current[4])
        episode = str(current[5])
        genre_text = _('Season: ') + seasons + _(' | Episode: ') + episode
        self['season'].setText(genre_text)

    def size(self):
        try:
            size_value = self['title_list'].getCurrent()[6]
            if size_value:  # Check if size_value is not empty
                size_bytes = int(size_value)
                if size_bytes >= 1073741824:
                    size_gb = size_bytes / 1073741824
                    size_text = _('Size: {:.2f} GB').format(size_gb)
                else:
                    size_mb = size_bytes / 1048576
                    size_text = _('Size: {:.2f} MB').format(size_mb)
                self['size'].setText(size_text)
            else:
                self['size'].setText(_('Size: N/A'))  # Handle the case where size is not available
        except (ValueError, TypeError) as e:
            self['size'].setText(_('Size: N/A'))  # Handle the case where conversion to int fails
            logdata('Error converting size to int:', str(e))


    def seedsandpeers(self):
        current = self['title_list'].getCurrent()
        if current is None:
            return
        seeds = str(current[2])
        peers = str(current[3])
        self['ostende'].setText(_('Seeds: ') + seeds + _(' | Peers: ') + peers)

    def getdata(self):
        if config.plugins.torreplayer.skins_tv.value != 'EZTV_grid':
            self.getpage()
            self.yassine()
            self.seedsandpeers()
            self.season()
            self.size()
            if config.plugins.torreplayer.bacdrop.value == False:
                self.showBackdrop()

            self.showLogo()
            self.showPoster()
            self.hanan()

    def showPoster(self):
        try:
            selected_item = self['title_list'].getCurrent()
            movie_titles = selected_item[0]
            movie_title = movie_titles.lower().replace(' ', '').replace('.', '')
            logdata('movie_title eztv poster', movie_title)
            if movie_title:
                default = ('{}/default.svg').format(self.darwin_directory)
                poster_file = ('{}/{}_p.jpg').format(self.poster_directory, movie_title)
                logdata('Poster File Path:', poster_file)
                if os.path.exists(poster_file):
                    logdata('Poster File Exists!')
                    self['screenshot'].instance.setPixmapFromFile(poster_file)
                    self['screenshot'].show()
                else:
                    logdata('Poster File Does Not Exist!')
                    self['screenshot'].instance.setPixmapFromFile(default)
                    self['screenshot'].show()
            else:
                self['screenshot'].hide()
        except Exception as e:
            logdata('Error screenshot:', str(e))

    def showBackdrop(self):
        selected_item = self['title_list'].getCurrent()
        if selected_item is None:
            return
        movie_titles = selected_item[0]
        movie_title = movie_titles.lower().replace(' ', '').replace('.', '')
        logdata('movie_title eztv backdrop', movie_title)
        if movie_title:
            preview = ('{}/{}.jpg').format(self.poster_directory, movie_title)
            logdata('backdrop File Path:', preview)
            if os.path.isfile(preview):
                background = Image.open(os.path.join(self.skin_path, "backdrop.png")).convert('RGBA')
                cover = Image.open(preview).convert('RGBA')
                mask = Image.open(os.path.join(self.skin_path, "mask.png")).convert('RGBA')

                # Get the size of the background image
                bg_width, bg_height = background.size

                try:
                    cover = cover.resize((bg_width, bg_height), Image.Resampling.LANCZOS)
                except:
                    cover = cover.resize((bg_width, bg_height), LANCZOS)

                # Resize mask to match background size
                mask = mask.resize((bg_width, bg_height), Image.Resampling.LANCZOS)

                # Position cover image on background image (top right)
                offset = (background.size[0] - cover.size[0], 0)

                background.paste(cover, offset, mask)

                background = background.convert('RGB')

                background.save(os.path.join(str(config.plugins.torreplayer.poster_path.value), "transmission/poster/{}_b.jpg".format(movie_title)))

                self.backdropLoad.setPara([self["screenshot2"].instance.size().width(), self["screenshot2"].instance.size().height(), 1, 1, 0, 1, "FF000000"])
                preview = os.path.join(str(config.plugins.torreplayer.poster_path.value), "transmission/poster/{}_b.jpg".format(movie_title))
                self.backdropLoad.startDecode(preview)

    def DecodeBackdrop(self, PicInfo=None):
        ptr = self.backdropLoad.getData()
        if ptr is not None:
            self["screenshot2"].instance.setPixmap(ptr)
            self["screenshot2"].show()
        else:
            self["screenshot2"].hide()

    def showLogo(self):
        try:
            selected_item = self['title_list'].getCurrent()
            movie_titles = selected_item[0]
            movie_title = movie_titles.lower().replace(' ', '').replace('.', '')
            logdata('movie_title eztv logo', movie_title)
            if movie_title:
                logo_file = ('{}/{}_logo.png').format(self.poster_directory, movie_title)
                logdata('logo File Path:', logo_file)
                if os.path.exists(logo_file):
                    logdata('logo File Exists!')
                    self['screenshot3'].instance.setPixmapFromFile(logo_file)
                    self['screenshot3'].show()
                else:
                    logdata('logo File Does Not Exist!')
                    self['screenshot3'].hide()
            else:
                self['screenshot3'].hide()
        except Exception as e:
            logdata('Error screenshot3:', str(e))

    def browser(self):
        self.session.open(EmissionOverview.EmissionOverview)

    def ghita(self):
        if TMDB_installed:
            selected_item = self['title_list'].getCurrent()
            eventName = selected_item[0]
            if eventName:
                self.session.open(TMBD, eventName)
        else:
            self.session.open(MessageBox, _('TMDB Plugin Not Installed.'), MessageBox.TYPE_INFO)

    def ok(self):
        selected_item = self['title_list'].getCurrent()
        if selected_item:
            choices = [(_("All Episodes"), "more"), (_("Download"), "download"), (_("Play"), "play")]
            self.session.openWithCallback(self.onChoice, ChoiceBox, title=_("Choose an action"), list=choices)
        else:
            logdata('No movie selected')

    def onChoice(self, choice):
        if choice:
            action = choice[1]
            selected_item = self['title_list'].getCurrent()
            if action == "download":
                torrent_link = selected_item[8]
                movie_title = selected_item[0]
                self.download_movie(torrent_link, movie_title)
            elif action == "play":
                torrent_link = selected_item[8]
                self.play_movie(torrent_link, selected_item)
            elif action == "more":
                torrent_imdb = selected_item[9]
                titel = selected_item[0]
                name_unclean = str(titel)
                name = name_unclean.lower().replace(' ', '').replace('.', '')
                poster = os.path.join(self.poster_directory, ('{}_p.jpg').format(name))
                backdrop = os.path.join(self.poster_directory, ('{}.jpg').format(name))
                logo = os.path.join(self.poster_directory, ('{}_logo.png').format(name))
                self.session.open(downloadMovie, torrent_imdb, name, poster, backdrop, logo, name_unclean)
        else:
            logdata('No action selected')

    def play_movie(self, torrent_link, selected_item):
        logdata('downloadAndPlay', 'Function called')
        if selected_item:
            title = selected_item[0]
            name_unclean = str(title)
            name = name_unclean.lower().replace(' ', '').replace('.', '')
            poster = os.path.join(self.poster_directory, ('{}_p.jpg').format(name))
            if torrent_link:
                new_torrent = torrsrv.torrent()
                new_torrent.link = torrent_link
                logdata('torrent_link', new_torrent.link)
                new_torrent.title = title
                new_torrent.poster = selected_item[1]
                new_torrent.save_to_db = True
                if self.my_torr_server.add_torrent(new_torrent):
                    name = new_torrent.title
                    magnet = new_torrent.link
                    titles = [name, magnet]
                    self.session.open(TorrEpisodes, titles, poster)
                else:
                    message = _('Torrent link cannot be added on Torrserv for {}.').format(selected_item[0])
                    self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
                    print('Failed to add movie torrent to TorrServer.')
            else:
                message = _('Torrent link not available for {}.').format(selected_item[0])
                self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
                print('Movie torrent link not available.')
        else:
            print('Movie details not available.')

    def download_movie(self, torrent_link, movie_title):
        if torrent_link:
            download_path = '{}/transmission'.format(config.plugins.torreplayer.poster_path.value)
            download_limit = '1000000'  # in KB/s
            upload_limit = '100'  # in KB/s
            rpc_url = 'http://127.0.0.1:9091/transmission/rpc'

            command = ('transmission-remote {} -a "{}" -w "{}" -d {} -u {}').format(rpc_url, torrent_link, download_path, download_limit, upload_limit)

            title = _('Downloading Movie: ') + movie_title
            self.session.open(Console, title, [command])
        else:
            self.session.open(MessageBox, _('No torrents available for this movie.'), MessageBox.TYPE_INFO)


    def getpage(self):
        if self.page > 1:
            self['key_green'].setText(_('Previous Page'))

    def nextPage(self):
        self.page += 1
        self.updatePage()

    def goBack(self):
        if self.page > 1:
            self.page -= 1
            self.updatePage()

    def updatePage(self):
        self.loading_time = 5
        self.menu_list = []
        refresh_list = ('', '', '', '', '', '', '', '', '', '', '', '', '')
        self.menu_list.append(refresh_list)
        self.text = _('Download Series & TvShow Data For Page[{}]').format(str(self.page))
        self['title_list'].setList(self.menu_list)
        self.loading.start(self.loading_time, _(self.text))
        self.stimer.stop()  # Stop any previous timer
        Thread(target=self.get_data).start()  # Start the timer to call get_data in 10 seconds

class TransmissionMovieBrowserGrid(Screen):

    def __init__(self, session, url, text):
        Screen.__init__(self, session)
        self.skin = getSkin('{}'.format(str(config.plugins.torreplayer.skins.value)))
        self.skinName = str(config.plugins.torreplayer.skins.value)
        self.session = session
        self.url = url
        self.text = str(text)
        self.sectionName = "Movies" # Default section name
        if "Latest Movies" in self.text:
            self.sectionName = "Latest Movies"
        self.page = 1
        self.total_pages = -1
        self.menu_list = []
        self.all_menu_items = []
        self.current_index = 0
        self.movies = []
        self.menu_list_lock = Lock()  # Lock for synchronizing access to self.menu_list
        self.stop_event = Event()  # Event to signal the thread to stop
        self.skin_path = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')
        self.poster_directory = '{}/transmission/poster/'.format(config.plugins.torreplayer.poster_path.value)
        self.ratingstars = -1
        self.loading_time = 10
        self.is_loading = False
        #self.backdropLoad = ePicLoad()
        #self.backdropLoad.PictureData.get().append(self.DecodeBackdrop)
        self.onExecBegin.append(self.loader)
        self.onClose.append(self.cleanup)
        self.skin_type = config.plugins.torreplayer.skins.value
        self.initializeComponents()
        self.initializeActionMap()
        self.initializeLabels()

    def updateLCD(self):
        try:
            for summary in self.summaries:
                if hasattr(summary, 'updateSummary'):
                    summary.updateSummary()
        except Exception as e:
            logdata("Error updating LCD", str(e))

    def createSummary(self):
        pass

    def getLCDSummary(self):
        cur = self["menu"].getCurrent()
        title = cur[0] if cur else ""
        page_info = "Page %d" % self.page
        if self.total_pages > 0:
            page_info = "Page %d / %d" % (self.page, self.total_pages)
        seeds = cur[6] if cur and len(cur) > 6 else ""
        size = cur[5] if cur and len(cur) > 5 else ""
        extra = "%s | %s" % (seeds, size) if seeds or size else ""

        # Calculate Poster and Backdrop Path
        poster_path = ""
        backdrop_path = ""
        if cur:
            # Try to get title from index 9 (title) or 0 (title_long)
            movie_title_raw = cur[9] if len(cur) > 9 else cur[0]
            movie_title = movie_title_raw.lower().replace(' ', '').replace('.', '').replace(':', '') if movie_title_raw else ""

            if movie_title:
                # Poster
                logdata3("movie tilte", movie_title)
                pfile = '{}{}_p.jpg'.format(self.poster_directory, movie_title)
                logdata3("*****lcd poster", pfile)
                if not os.path.exists(pfile):
                    pfile = os.path.join(self.poster_directory, '%s.jpg' % self.cleanTitle(cur[0]))
                if os.path.exists(pfile):
                    poster_path = pfile

                # Backdrop - try _back.jpg first
                poster_path_value = config.plugins.torreplayer.poster_path.value
                bfile = os.path.join(poster_path_value, "transmission/poster/{}_back.jpg".format(movie_title))
                logdata3("******** lcd poster2", bfile)
                if os.path.exists(bfile):
                    backdrop_path = bfile
                elif poster_path:  # Fallback to poster if backdrop doesn't exist
                    backdrop_path = poster_path

        # Rating is at index 7 based on addMovieToList
        rating_val = cur[7] if cur and len(cur) > 7 else 0
        rating = "Rating: %s" % str(rating_val)

        return {
            "title": title[:32],
            "line1": "",
            "line2": cur[4] if cur and len(cur) > 4 else "",
            "line3": extra,
            "page": page_info,
            "poster": poster_path,
            "backdrop": backdrop_path,
            "section": self.sectionName, # Use clean section name
            "rating": rating,
            "progress": self.ratingstars if hasattr(self, "ratingstars") and self.ratingstars >= 0 else 0,
        }

    def initializeComponents(self):
        self.isCarousel = (config.plugins.torreplayer.skins.value == 'carousel')
        self["pic_loading"] = Pixmap()
        self["int_loading"] = Label('')
        self["msg_loading"] = Label('')
        self.loading = Loading(self["pic_loading"], self["int_loading"], self["msg_loading"], None)
        self['menu'] = List()
        self['menu'].onSelectionChanged.append(self.getdata)
        #self['menu'].onSelectionChanged.append(self.onSelectionChanged)
        self['screenshot3'] = Pixmap()
        self['fsklogo'] = Pixmap()
        self['rating'] = Label('')
        self.grid_columns = 4 if config.plugins.torreplayer.skins.value == "grid" else 1
        self['stars'] = ProgressBar()
        self['starsbg'] = Pixmap()
        self['stars'].hide()
        self['starsbg'].hide()
        if config.plugins.torreplayer.skins.value != "grid":
            self['backdrop'] = Pixmap()
        if config.plugins.torreplayer.skins.value == "list_old" or config.plugins.torreplayer.skins.value == "list_new":
            self['fatima'] = Label(_("*** Torrents Movies's Browser [YTS]***"))
            self['poster'] = Pixmap()

    def onSelectionChanged(self):
        # Only update LCD if not currently loading
        if not self.is_loading:
            self.updateLCD()

    def initializeActionMap(self):
        self['actions'] = ActionMap(['DirectionActions', 'EPGSelectActions', 'MenuActions', 'OkCancelActions', 'ColorActions'],
                                    {'ok': self.ok, 'cancel': self.cancel, 'green': self.goBack, 'yellow': self.nextPage,
                                     'red': self.cancel, 'blue': self.browser, 'info': self.ghita, 'menu': self.openSortMenu, 'left': self.keyLeft, 'right': self.keyRight, 'up': self.keyUp,
                                     'down': self.keyDown,}, -1)

    def initializeLabels(self):
        self['key_red'] = Label(_('Exit'))
        self['key_yellow'] = Label('')
        self['key_green'] = Label('')
        self['key_blue'] = Label(_('Download Manager'))
        self['yassine'] = Label('')
        self['zahra'] = Label('')
        self['genre'] = Label('')
        self['ostende'] = Label('')
        self['page'] = Label('')

    def loader(self):
        if self.menu_list:
            self.finishLoading()
        else:
            self.is_loading = True
            self.loading.start(self.loading_time, self.text)
            self["msg_loading"].setText(_("Loading, please wait..."))
            reactor.callInThread(self.loadUrl)

    def loadUrl(self):
        if config.plugins.torreplayer.proxy.value:
            url_to_proxy = self.url if 'movie_suggestions.json' in self.url else self.url + str(self.page)
            self.base_url = get_proxied_url(url_to_proxy)
            logdata("url called for movies ", self.base_url)
        else:
            if 'movie_suggestions.json' in self.url:
                self.base_url = self.url
            else:
                self.base_url = self.url + str(self.page)
            logdata("url called for movies ", self.base_url)
        return self.loadMovies(self.base_url)


    def loadMovies(self, url):
        def _fetch():
            try:
                logdata("Fetching URL:", url)
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': 'application/json,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate',
                    'Connection': 'keep-alive'
                }
                # Use proxy if enabled
                response = make_request_with_proxy(url, headers=headers, timeout=15)
                if not response:
                    raise Exception("Failed to fetch data (proxy or direct connection failed)")
                response.raise_for_status()
                text = response.text
                try:
                    data = json.loads(text)
                except Exception as e:
                    raise Exception("JSON decode error: %s" % str(e))
                if not data or "data" not in data:
                    raise Exception("Invalid or empty movie data")
                reactor.callFromThread(self.processMovieData, data)
            except Exception as e:
                logdata("Exception in loadMovies:", str(e))
                reactor.callFromThread(self.handleException, e)
        deferToThread(_fetch)

    def processMovieData(self, data):
        logdata("data called*****", data)
        if not data:
            self.handleNoMoviesFound()
            return
        try:
            movies = data.get('data', {}).get('movies', [])
            if not movies:
                self.handleNoMoviesFound()
                return
            self.menu_list = []
            self.all_menu_items = []
            self.current_index = 0
            self.movies_queue = list(enumerate(movies))  # (idx, movie)
            self.movies = movies
            self.total_movies = len(movies)
            if 'movie_suggestions.json' in self.url:
                self.total_pages = 1
            else:
                self.total_pages = data.get('data', {}).get('page_count', 1)
            self.menu_data = []
            self.updatePageDisplay(
                str(data.get('data', {}).get('movie_count', 0)),
                str(self.total_pages),
                str(self.total_movies)
            )
            self.feedNextMovie()
        except Exception as e:
            logdata('Error processing movie data: {}'.format(str(e)))
            self.handleException(e)

    def feedNextMovie(self):
        if not self.movies_queue:
            self.finishLoading()
            return
        idx, movie = self.movies_queue.pop(0)
        current = idx + 1
        self.addMovieToList(movie, current, self.total_movies)
        reactor.callLater(0.05, self.feedNextMovie)


    def addMovieToList(self, movie, current, total):
        try:
            title_long = movie.get('title_long', '')
            title = movie.get('title', '')
            if not movie.get('id') or not (title_long or title):
                return
            synopsis = movie.get('summary') or movie.get('description_full', 'No description available')
            genres = movie.get('genres', [])
            rating = movie.get('rating', 0)
            poster = movie.get('large_cover_image', '') or movie.get('medium_cover_image', '')
            imdb = movie.get('imdb_code', '')
            year = movie.get('year', '')
            torrents = movie.get('torrents', [])
            movie_info = (
                title_long or title,
                movie.get('id'),
                genres,
                synopsis,
                torrents,
                poster,
                '',
                rating,
                None,
                title,
                year,
                imdb
            )
            percent = int((current * 100) / total) if total else 0
            self["int_loading"].setText(str(percent))
            if isinstance(current, int) and isinstance(total, int) and total > 0:
                self["msg_loading"].setText('Loading %d/%d' % (current, total))
            else:
                self["msg_loading"].setText('Loading...')
            if imdb:
                reactor.callInThread(self.gettmdbdata, imdb, title)
                reactor.callInThread(self.updatePoster, None, poster, title, movie_info, movie)
            if self.isCarousel:
                self.all_menu_items.append(movie_info)
                self.updateCarouselView()
            else:
                self.menu_list.append(movie_info)
        except Exception as e:
            logdata("addMovieToList error: %s" % str(e))

    def handleError(self, error):
        logdata('Error occurred during deferred operation: {}'.format(error))

    def download_with_curl(self, url, filename):
        try:
            cmd = ['curl', '-L', '-k', '-o', filename, url]
            result = subprocess.call(cmd)
            return result == 0 and os.path.exists(filename)
        except Exception as e:
            logdata("curl download failed: %s" % str(e))
            return False

    def updatePoster(self, result, url, title, movie_info, movie):
        try:
            filename = os.path.join(self.poster_directory, '%s.jpg' % self.cleanTitle(title))
            filename2 = os.path.join(self.poster_directory, '%s_p.jpg' % self.cleanTitle(title))
            fallback_url = movie.get('medium_cover_image') or movie.get('large_cover_image')
            urls_to_try = [url]
            if fallback_url and fallback_url != url:
                urls_to_try.append(fallback_url)

            downloaded = False
            for raw_url in urls_to_try:
                if self.download_with_curl(raw_url, filename):
                    downloaded = True
                    break
            if not downloaded and config.plugins.torreplayer.proxy.value:
                for raw_url in urls_to_try:
                    # Try with proxy manager
                    proxied_url = get_proxied_url(raw_url, 0)
                    if not proxied_url:
                        continue
                    logdata('*******************proxied_url*****************', proxied_url)
                    try:
                        r = requests.get(proxied_url, timeout=8, verify=False)
                        if r.status_code == 200:
                            with open(filename, 'wb') as f:
                                f.write(r.content)
                            downloaded = True
                            break
                        else:
                            logdata("Proxy failed: %s [%s]" % (proxied_url, r.status_code))
                    except Exception as e:
                        logdata("Proxy exception: %s -> %s" % (proxied_url, str(e)))
                    if downloaded:
                        break
            pixmap = loadJPG(filename2) if os.path.exists(filename2) else loadJPG(filename)
            new_info = list(movie_info)
            new_info[8] = pixmap
            try:
                if self.isCarousel:
                    idx = self.all_menu_items.index(movie_info)
                    self.all_menu_items[idx] = tuple(new_info)
                    reactor.callFromThread(self.updateCarouselView)
                else:
                    idx = self.menu_list.index(movie_info)
                    self.menu_list[idx] = tuple(new_info)
                    reactor.callFromThread(self.updateListInUI)
            except ValueError as e:
                logdata("updatePoster index error: %s" % str(e))

        except Exception as e:
            logdata("updatePoster failed: %s" % str(e))

    def updateListInUI(self):
        self['menu'].updateList(self.menu_list)

    def setListInUI(self):
        self['menu'].setList(self.menu_list)

    def updatePageDisplay(self, movie_count, total_pages, total_movies):
        try:
            movie_count = int(movie_count)
            page = int(self.page)
            total_movies = int(total_movies)
            if movie_count == 0:
                display_text = _("** Page [%d] **\n**** [%d] Movies Found ****") % (page, total_movies)
            else:
                display_text = _("** Page [%d] **\n**** [%d] Movies Found ****") % (page, movie_count)
            self['page'].setText(display_text)
        except ValueError:
            logdata("Invalid number format in updatePageDisplay")
            self['page'].setText('')

    def handleNoMoviesFound(self):
        self.finishLoading()
        self.session.open(MessageBox, _('No Movies Found.'), MessageBox.TYPE_INFO)
        self.close()

    def handleException(self, e):
        logdata("Exception: %s" % str(e))
        self.menu_list = [('Error fetching data', None, [], 'Error occurred', [], '', '', 0, None, '', 0, '')]
        self.setListInUI()
        self.finishLoading()
        self.session.open(MessageBox, _('Error fetching data: %s') % str(e), MessageBox.TYPE_ERROR)

    def finishLoading(self):
        self.is_loading = False
        self.loading.stop()
        self['msg_loading'].setText('')
        self.updateLCD() # Trigger LCD update after loading
        self['menu'].setList(self.menu_list)

    def cleanup(self):
        self.finishLoading()
        self.stop_event.set()

    def openSortMenu(self):
        choices = [
            (_('Sort by Title (A-Z)'), 'title_asc'),
            (_('Sort by Title (Z-A)'), 'title_desc'),
            (_('Sort by Rating (High to Low)'), 'rating_desc'),
            (_('Sort by Rating (Low to High)'), 'rating_asc'),
            (_('Sort by Year Newest First'), 'year_desc'),  # Updated
            (_('Sort by Year Oldest First'), 'year_asc')   # Updated
        ]
        self.session.openWithCallback(self.sortList, ChoiceBox, title=_('Select Sort Option'), list=choices)


    def sortList(self, choice):
        if not choice:
            return
        sort_option = choice[1]
        if sort_option == 'title_asc':
            self.menu_list.sort(key=lambda x: x[0].lower() if x[0] else '')
        elif sort_option == 'title_desc':
            self.menu_list.sort(key=lambda x: x[0].lower() if x[0] else '', reverse=True)
        elif sort_option == 'rating_asc':
            self.menu_list.sort(key=lambda x: x[7] if x[7] else 0)
        elif sort_option == 'rating_desc':
            self.menu_list.sort(key=lambda x: x[7] if x[7] else 0, reverse=True)
        elif sort_option == 'year_asc':
            self.menu_list.sort(key=lambda x: x[10] if x[10] else 0)
        elif sort_option == 'year_desc':
            self.menu_list.sort(key=lambda x: x[10] if x[10] else 0, reverse=True)
        self.setListInUI()


    def keyLeft(self):
        index = self['menu'].getIndex()
        if self.isCarousel:
            self.moveCarousel(-1)
        elif self.skin_type == "grid":
            self['menu'].setIndex(index - 1)  # Move left in a 4-column grid
        elif self.skin_type == "horizontal":
            self['menu'].setIndex(index - 1)
        else:  # vertical
            self['menu'].up()

    def keyRight(self):
        index = self['menu'].getIndex()
        if self.isCarousel:
            self.moveCarousel(1)
        elif self.skin_type == "grid":
            self['menu'].setIndex(index + 1) # Move right in a 4-column grid
        elif self.skin_type == "horizontal":
            self['menu'].setIndex(index + 1)
        else:  # vertical
            self['menu'].down()

    def keyUp(self):
        index = self['menu'].getIndex()
        if self.isCarousel:
            self.moveCarousel(-6)
        elif self.skin_type == "grid":
            self['menu'].setIndex(index - 6)  # Grid: move up one item
        elif self.skin_type == "horizontal":
            self['menu'].setIndex(index - 6)
        else:
            self['menu'].up()

    def keyDown(self):
        index = self['menu'].getIndex()
        if self.isCarousel:
            self.moveCarousel(+6)
        elif self.skin_type == "grid":
            self['menu'].setIndex(index + 6)
        elif self.skin_type == "horizontal":
            self['menu'].setIndex(index + 6)
        else:
            self['menu'].down()
    def moveCarousel(self, direction):
        if not self.all_menu_items:
            return
        self.current_index = (self.current_index + direction) % len(self.all_menu_items)
        self.updateCarouselView()

    def updateCarouselView(self):
        total = len(self.all_menu_items)
        if total == 0:
            self.menu_list = []
            self.setListInUI()
            return

        target_center_index = 3
        if total < 7:
            # Not enough items to fill carousel, show all and move selection
            self.menu_list = list(self.all_menu_items)
            self.setListInUI()
            try:
                self.current_index = max(0, min(self.current_index, total - 1))
                self['menu'].setIndex(self.current_index)
            except:
                pass
        else:
            # Rotate list to center the current index
            indices = []
            for i in range(-3, 4): # -3, -2, -1, 0, 1, 2, 3
                indices.append((self.current_index + i) % total)

            self.menu_list = [self.all_menu_items[i] for i in indices]
            self.setListInUI()
            try:
                self['menu'].setIndex(target_center_index)
            except:
                pass

    def gettmdbdata(self, torrent_imdb, titel):
        if titel:
            imdb_id = str(torrent_imdb)
            language = config.plugins.torreplayer.tmdblng.value
            url_imdb = 'https://api.themoviedb.org/3/find/%s?api_key=8789cfd3fbab7dccf1269c3d7d867aff&external_source=imdb_id&language=%s' % (imdb_id, language)
            logdata('************* URL TMDb:', str(url_imdb))
            movie_title = self.cleanTitle(titel)
            try:
                response = requests.get(url_imdb)
                data = response.json()
                self.processTmdbData(data, movie_title, titel)
            except requests.exceptions.RequestException as e:
                logdata('Error fetching data from TMDb:', str(e))

    def processTmdbData(self, data, movie_title, titel):
        if 'movie_results' in data and data['movie_results']:
            movie_result = data['movie_results'][0]
            logdata('************* result TMDb:', str(movie_result))
            name = movie_result.get('title', '')
            overview = movie_result.get('overview', '')
            poster_path = movie_result.get('poster_path', '')
            backdrop_path = movie_result.get('backdrop_path', '')
            id_tvdb = movie_result.get('id', '')
            if id_tvdb:
                self.logo(id_tvdb, movie_title)
            self.downloadPosterAndBackdrop(movie_title, poster_path, backdrop_path)
            self.saveMovieData(movie_title, name, overview)
            reactor.callFromThread(self.getdata)
        else:
            logdata('No TV results found for the given IMDb ID')

    def downloadPosterAndBackdrop(self, movie_title, poster_path, backdrop_path):
        if poster_path:
            movie_title = self.cleanTitle(movie_title)
            url_poster = 'http://image.tmdb.org/t/p/original' + poster_path
            logdata('************* url poster  TMDb:', str(url_poster))
            filenameP = os.path.join(self.poster_directory, ('{}_p.jpg').format(movie_title))
            self.downloadPicture(url_poster, filenameP)

        if backdrop_path:
            movie_title = self.cleanTitle(movie_title)
            url_backdrop = 'http://image.tmdb.org/t/p/original' + backdrop_path
            self.download_and_process_backdrop(url_backdrop, movie_title)

    def saveMovieData(self, movie_title, title, overview):
        url_imdb = 'https://api.themoviedb.org/3/search/movie?api_key=3c3efcf47c3577558812bb9d64019d65&language={}&query={}'.format(
            str(config.plugins.torreplayer.tmdblng.value), title)
        logdata("yrl overview", url_imdb)
        try:
            response = requests.get(url_imdb, verify=False)
            data = response.json()
        except requests.exceptions.RequestException as e:
            logdata('Error fetching data from TMDb:', str(e))
        if 'results' in data and data['results']:
            movie_result = data['results'][0]
            synopsis = movie_result.get('overview', '')
            rating = movie_result.get('vote_average', '')
            movie_data = {'title': title, 'overview': synopsis, 'rating': rating}
            json_filename = os.path.join(self.poster_directory, ('{}.json').format(movie_title))
            try:
                with open(json_filename, 'w', encoding='utf-8') as json_file:
                    json.dump(movie_data, json_file, indent=4, ensure_ascii=False)
            except IOError as e:
                logdata('Error writing JSON file:', str(e))

    def downloadImage(self, url, filename, log_prefix):
        try:
            filename = re.sub(r'[<>:"\\|?*]', '', filename)
            filename = re.sub(r'\(\d{4}\)', '', filename)
            if os.path.exists(filename):
                logdata("%s already exists" % log_prefix, filename)
                return
            response = requests.get(url, stream=True, verify=False, timeout=10)
            if response.status_code == 200:
                with open(filename, 'wb') as file:
                    for chunk in response.iter_content(1024):
                        file.write(chunk)
                logdata("%s downloaded" % log_prefix, filename)
            else:
                logdata('Error downloading %s. Status code: %d' % (log_prefix, response.status_code))
        except requests.exceptions.RequestException as e:
            logdata('Error during %s download: %s' % (log_prefix, str(e)))

    def cleanTitle(self, title):
        title = re.sub(r'\(\d{4}\)', '', title)
        return title.lower().replace(' ', '').replace('.', '').replace('/', '').replace(':', '')

    def logo(self, id_tvdb, movie_title):
        ext = "https://api.themoviedb.org/3/movie/" + str(id_tvdb) + "/images"
        primary_language = config.plugins.torreplayer.tmdblng.value
        fallback_language = 'en,null'
        logo_path = self._fetch_logo_with_language(ext, movie_title, primary_language)
        if logo_path:
            return logo_path
        return self._fetch_logo_with_language(ext, movie_title, fallback_language)

    def _fetch_logo_with_language(self, ext, movie_title, language):
        params = {
            'api_key': '8789cfd3fbab7dccf1269c3d7d867aff',
            'language': language,
            'include_image_language': language
        }
        try:
            response = requests.get(ext, params=params, verify=False)
            data = response.json()
            if 'logos' in data and data['logos']:
                logo_result = data['logos'][0]
                logo_path = logo_result.get("file_path", "")
                if logo_path:
                    url_logo = "http://image.tmdb.org/t/p/original" + logo_path
                    filename_logo = os.path.join(self.poster_directory, movie_title + "_logo.png")
                    self.downloadPicture2(url_logo, filename_logo)
                    return filename_logo
        except requests.exceptions.RequestException as e:
            logdata("Error fetching logo data with language " + language + ":", str(e))
        return None



    def yassine(self):
        current_item = self['menu'].getCurrent()
        if current_item and isinstance(current_item, tuple):
            movie_title = current_item[0]
            movie_title = str(movie_title)
            if movie_title:
                try:
                    self['yassine'].setText(movie_title)
                except Exception as e:
                    logdata('Error set title:', str(e))
        else:
            print ("Error: Unexpected value for self['menu'].getCurrent(): {}").format(current_item)

    def synopsis(self):
        current_item = self['menu'].getCurrent()
        if current_item and isinstance(current_item, tuple):
            title = current_item[9]
            movie_title = self.cleanTitle(str(title))
            json_filename = os.path.join(self.poster_directory, '{}.json'.format(movie_title))
            try:
                with open(json_filename, 'r') as json_file:
                    movie_data = json.load(json_file)
                    overview = movie_data.get('overview', '')
                    if overview:
                        self['zahra'].setText(_('Description:\n') + overview)
                        return
            except (FileNotFoundError, json.JSONDecodeError) as e:
                logdata('Error reading JSON file for synopsis: {}'.format(e))
            summary = current_item[3]
            if summary:
                self['zahra'].setText(_('Description:\n') + summary)
            else:
                self['zahra'].setText(_('Description:\n\nNo Description Found'))
        else:
            print("Error: Unexpected value for self['menu'].getCurrent(): {}".format(current_item))

    def seedsandpeers(self):
        current_item = self['menu'].getCurrent()
        if current_item and isinstance(current_item, tuple):
            torrents = current_item[4]
            seeds_and_peers_text = ''
            for torrent in torrents:
                seeds = str(torrent.get('seeds'))
                peers = str(torrent.get('peers'))
                seeds_and_peers_text = _('Seeds: ') + seeds + _(' | Peers: ') + peers
            self['ostende'].setText(seeds_and_peers_text)
        else:
            print ("Error: Unexpected value for self['menu'].getCurrent(): {}").format(current_item)

    def genre(self):
        current_item = self['menu'].getCurrent()
        if current_item and isinstance(current_item, tuple):
            genres = current_item[2]
            try:
                genre_text = _('Genres: ') + (', ').join(genres)
                if genres:
                    genre_string = str(genre_text)
                    self['genre'].setText(genre_string)
            except:
                pass
        else:
            print ("Error: Unexpected value for self['menu'].getCurrent(): {}").format(current_item)

    def rating(self):
        current_item = self['menu'].getCurrent()
        logdata3('current_item', current_item)
        rating = None

        if current_item and isinstance(current_item, tuple):
            title = current_item[9]
            movie_title = self.cleanTitle(str(title))
            json_filename = os.path.join(self.poster_directory, '{}.json'.format(movie_title))
            try:
                with open(json_filename, 'r') as json_file:
                    movie_data = json.load(json_file)
                    rating= movie_data.get('rating', '')
            except (FileNotFoundError, json.JSONDecodeError) as e:
                rating = current_item[7]
                logdata('Error reading JSON file: {}'.format(e))
            logdata3('raw_rating', rating)

            if any(x in imgr for x in ["teamblue", "openbh", "openvix"]):
                self["stars"].show()
                self["starsbg"].show()
                try:
                    rating_value = float(str(rating).replace(',', '.'))
                    star = _('Rating IMDB : ') + str(rating_value) + '/10'
                    self.ratingstars = int(10 * round(float(str(rating).replace(',', '.')), 1))
                    logdata3('ratingstars', self.ratingstars)
                    if self.ratingstars > 0:
                        self["stars"].setValue(self.ratingstars)
                        self["stars"].show()
                        self["starsbg"].show()
                        self['rating'].setText(star)
                except Exception as e:
                    logdata3('rating conversion failed', e)
                    self['stars'].hide()
                    self['starsbg'].hide()
                    self['rating'].setText('')
            else:
                try:
                    rating_value = float(rating)
                    star = _('Rating IMDB : ') + str(rating_value) + '/10'
                    self.ratingstars = int(10 * round(rating_value, 1))
                    self['stars'].show()
                    self['stars'].setValue(self.ratingstars)
                    self['starsbg'].show()
                    self['rating'].setText(star)
                except Exception as e:
                    logdata3('fallback rating conversion failed', e)
                    self['stars'].hide()
                    self['starsbg'].hide()
                    self['rating'].setText('')
        else:
            logdata3('Invalid current_item', current_item)

    def getdata(self):
        try:
            self.getpage()
            self.rating()
            self.genre()
            self.yassine()
            self.seedsandpeers()
            self.synopsis()
            if config.plugins.torreplayer.skins.value == "list_old" or config.plugins.torreplayer.skins.value == "list_new":
                self.showPoster()
            if config.plugins.torreplayer.skins.value != "grid":
                self.showLogo()
                self.showBackdrop()
            if self.ratingstars > 0:
                self['stars'].show()
                self['stars'].setValue(self.ratingstars)
                self['starsbg'].show()
            else:
                self['starsbg'].hide()
                self['stars'].hide()
        except:
            pass



    def cancel(self):
        self.loading.stop()
        self.close()

    def ok(self):
        selected_item = self['menu'].getCurrent()
        if not selected_item:
            logdata('No movie selected for ok')
            return
        movie_titlex = selected_item[0]
        movie_titles = selected_item[9]
        movie_title = movie_titles.lower().replace(' ', '').replace('.', '').replace(':', '')
        movie_id = selected_item[1]
        imdb_id = selected_item[11]
        logdata('ok function - movie title:', movie_titlex)
        logdata('ok function - movie ID:', movie_id)
        threading.Thread(
            target=self.fetch_and_save_movie_data,
            args=(imdb_id, movie_title)
        ).start()
        pfile = os.path.join(self.poster_directory, "{}_p.jpg".format(movie_title))
        b_path = os.path.join(self.poster_directory, "{}_back.jpg".format(movie_title))
        if not os.path.exists(pfile):
            title_clean = self.cleanTitle(movie_titlex)
            fallback_path = os.path.join(self.poster_directory, "{}.jpg".format(title_clean))
            if os.path.exists(fallback_path):
                pfile = fallback_path
            else:
                pfile = None
        sugestion = 'movie_suggestions.json' in self.url
        self.session.open(MovieDetail, movie_id, pfile, b_path, sugestion)
        self.genre()
        self.yassine()
        self.seedsandpeers()

    def fetch_and_save_movie_data(self, imdb_id, movie_title):
        language = config.plugins.torreplayer.subslng.value
        sub_provider = SubtitleProvider(language)
        try:
            combined_data = {
                'title': '',
                'year': '',
                'rating': '',
                'genres': [],
                'description': '',
                'subtitles': [],
                'providers_used': [],
                'language_preference': language
            }
            api_key = config.plugins.torreplayer.subdl_api.value
            for provider_name in ['yts', 'opensubtitles', 'subscene', 'subdl']:
                try:
                    if provider_name == 'subdl':
                        data = sub_provider.get_movie_data(
                            imdb_id=imdb_id,
                            provider=provider_name,
                            api_key=api_key
                        )
                    else:
                        data = sub_provider.get_movie_data(
                            imdb_id=imdb_id,
                            provider=provider_name
                        )
                    if data:
                        if not combined_data['title']:
                            for key in ['title', 'year', 'rating', 'genres', 'description']:
                                if data.get(key):
                                    combined_data[key] = data[key]
                        combined_data['subtitles'].extend(data.get('subtitles', []))
                        combined_data['providers_used'].append(provider_name)
                except Exception as e:
                    logdata('Error with provider %s: %s' % (provider_name, str(e)))
            subs_dir = os.path.join(str(config.plugins.torreplayer.poster_path.value), 'transmission', 'Subs')
            if not os.path.exists(subs_dir):
                os.makedirs(subs_dir)
            json_file = os.path.join(subs_dir, '%s.json' % movie_title)
            sub_provider.save_to_json(combined_data, json_file)
        except Exception as e:
            logdata('Error in fetch_and_save_movie_data: %s' % str(e))

    def showPoster(self):
        try:
            selected_item = self['menu'].getCurrent()
            if not selected_item:
                self['poster'].hide()
                return
            movie_title = selected_item[9].lower().replace(' ', '').replace('.', '')
            if movie_title:
                pfile = '{}{}_p.jpg'.format(self.poster_directory, movie_title)
                if not os.path.exists(pfile):
                    pfile = os.path.join(self.poster_directory, '%s.jpg' % self.cleanTitle(selected_item[0]))
                if os.path.exists(pfile):
                    self['poster'].instance.setPixmapFromFile(pfile)
                    self['poster'].show()
                else:
                    self['poster'].hide()
            else:
                self['poster'].hide()
        except Exception as e:
            logdata('Error in showPoster:', str(e))

    def download_and_process_backdrop(self, backdrop_url, movie_title):
        try:
            from PIL import Image

            if not backdrop_url or not movie_title:
                logdata("Missing URL or title for backdrop processing")
                return None

            raw_path = os.path.join(self.poster_directory, "{}_b.jpg".format(movie_title))
            final_path = os.path.join(self.poster_directory, "{}_back.jpg".format(movie_title))

            if os.path.exists(final_path):
                logdata("Backdrop already processed", final_path)
                return final_path

            # Download raw backdrop
            #if config.plugins.torreplayer.proxy.value:
                #backdrop_url = "https://thingproxy.freeboard.io/fetch/" + quote(backdrop_url, safe='')

            r = requests.get(backdrop_url, stream=True, verify=False, timeout=10)
            if r.status_code != 200:
                logdata("Backdrop download failed", backdrop_url)
                return None

            with open(raw_path, 'wb') as f:
                for chunk in r.iter_content(1024):
                    f.write(chunk)

            logdata("Backdrop downloaded", raw_path)

            # Load resources
            gradient_path = os.path.join(self.skin_path, "backdrop.png")
            mask_path = os.path.join(self.skin_path, "mask.png")

            if not os.path.exists(gradient_path) or not os.path.exists(mask_path):
                logdata("Missing mask or gradient")
                return raw_path  # fallback

            background = Image.open(gradient_path).convert('RGBA')
            cover = Image.open(raw_path).convert('RGBA')
            mask = Image.open(mask_path).convert('RGBA')
            w, h = background.size

            try:
                cover = cover.resize((w, h), LANCZOS)
                mask = mask.resize((w, h), LANCZOS)
            except Exception as e:
                logdata("Error resizing image: {}".format(e))

            background.paste(cover, (0, 0), mask)
            background = background.convert('RGB')
            background.save(final_path, quality=90)

            logdata("Backdrop processed and saved", final_path)
            return final_path

        except Exception as e:
            logdata("Backdrop processing error", str(e))
            return None


    def showBackdrop(self):
        try:
            self["backdrop"].hide()
            selected_item = self['menu'].getCurrent()
            if not selected_item:
                logdata("No selected item for backdrop")
                return

            movie_titles = selected_item[9]
            movie_title = movie_titles.lower().replace(' ', '').replace('.', '').replace(':', '')
            poster_path = config.plugins.torreplayer.poster_path.value
            final_backdrop_path = os.path.join(poster_path, "transmission/poster/{}_back.jpg".format(movie_title))
            logdata("Backdrop path", final_backdrop_path)

            if os.path.exists(final_backdrop_path):
                self["backdrop"].instance.setPixmapFromFile(final_backdrop_path)
                self["backdrop"].show()
                logdata("Backdrop set from file", final_backdrop_path)
            else:
                logdata("Processed backdrop not found", final_backdrop_path)
                self["backdrop"].hide()

        except Exception as e:
            logdata("Backdrop show failed", str(e))
            self["backdrop"].hide()


    def showLogo(self):
        try:
            selected_item = self['menu'].getCurrent()
            movie_titles = selected_item[9]
            movie_title = movie_titles.lower().replace(' ', '').replace('.', '').replace(':', '')
            logdata('movie_title eztv logo', movie_title)
            if movie_title:
                logo_file = ('{}{}_logo.png').format(self.poster_directory, movie_title)
                logdata('logo File Path:', logo_file)
                if os.path.exists(logo_file):
                    logdata('logo File Exists!')
                    self['screenshot3'].instance.setPixmapFromFile(logo_file)
                    self['screenshot3'].show()
                else:
                    logdata('logo File Does Not Exist!')
                    self['screenshot3'].hide()
            else:
                self['screenshot3'].hide()
        except Exception as e:
            logdata('Error screenshot3:', str(e))

    def dream(self):
        pass

    def browser(self):
        self.session.open(EmissionOverview.EmissionOverview)

    def downloadPicture(self, url, filename):
        try:
            if os.path.exists(filename):
                logdata("Picture already exists", filename)
                return
            response = requests.get(url, stream=True, verify=False)
            if response.status_code == 200:
                with open(filename, 'wb') as file:
                    for chunk in response.iter_content(1024):
                        file.write(chunk)
                logdata("Picture downloaded", filename)
            else:
                logdata('Error downloading picture. Status code:', response.status_code)
        except requests.exceptions.RequestException as e:
            logdata('Error during downloadPicture:', str(e))

    def downloadPicture2(self, url, filename):
        try:
            if os.path.exists(filename):
                logdata("Picture already exists", filename)
                return
            response = requests.get(url, stream=True, verify=False)
            if response.status_code == 200:
                with open(filename, 'wb') as file:
                    for chunk in response.iter_content(1024):
                        file.write(chunk)
                logdata("Picture downloaded", filename)
            else:
                logdata('Error downloading picture. Status code:', response.status_code)
        except requests.exceptions.RequestException as e:
            logdata('Error during downloadPicture:', str(e))

    def ghita(self):
        if TMDB_installed:
            selected_item = self['menu'].getCurrent()
            eventName = selected_item[0]
            if eventName:
                self.session.open(TMBD, eventName)
        else:
            self.session.open(MessageBox, _('TMDB Plugin [mod Fairbird] Not Installed.'), MessageBox.TYPE_INFO)

    def getpage(self):
        if self.total_pages > -1:
            if 'movie_suggestions.json' in self.url:
                self['key_yellow'].setText(_(''))
            else:
                self['key_yellow'].setText(_('Next Page'))
        if self.page > 1:
            self['key_green'].setText(_('Previous Page'))

    def nextPage(self):
        if self.is_loading:
            return
        if 'movie_suggestions.json' in self.url:
            return
        self.page += 1
        self.updatePage()

    def goBack(self):
        if self.is_loading:
            return
        if self.page > 1:
            self.page -= 1
            self.updatePage()

    def updatePage(self):
        self['stars'].hide()
        self['starsbg'].hide()
        self.menu_list = []
        self["menu"].setList(self.menu_list)
        self.text = _('Download Movies Data For Page[{}]').format(self.page)
        self["msg_loading"].setText(self.text)
        self.loading_time = 10
        self.loading.start(self.loading_time, self.text)
        self.is_loading = True
        reactor.callInThread(self.loadUrl)

class TransmissionMovieFavourites(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = getSkin(str(config.plugins.torreplayer.skins.value))
        self.skinName = str(config.plugins.torreplayer.skins.value)
        self.initializeComponents()
        self.session = session
        self.text = "Load Movies"
        self.page = 1
        self.total_pages = -1
        self.menu_list = []
        self.movies = []
        self.menu_list_lock = Lock()  # Lock for synchronizing access to self.menu_list
        self.stop_event = Event()  # Event to signal the thread to stop
        self.skin_path = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')

        self.poster_directory = '{}/transmission/poster/'.format(config.plugins.torreplayer.poster_path.value)
        self.ratingstars = -1
        self.loading_time = 10
        self.onExecBegin.append(self.loader)
        self.onClose.append(self.cleanup)
        self.initializeActionMap()
        self.initializeLabels()

    def initializeComponents(self):
        self["pic_loading"] = Pixmap()
        self["int_loading"] = Label('')
        self["msg_loading"] = Label('')
        self.loading = Loading(self["pic_loading"], self["int_loading"], self["msg_loading"], None)
        self['menu'] = List()
        self['menu'].onSelectionChanged.append(self.getdata)
        self['screenshot3'] = Pixmap()
        self['fsklogo'] = Pixmap()
        self['rating'] = Label('')
        self['stars'] = ProgressBar()
        self['starsbg'] = Pixmap()
        self['stars'].hide()
        self['starsbg'].hide()
        if config.plugins.torreplayer.skins.value != "grid":
            self['backdrop'] = Pixmap()
            self["backdrop"].hide()
        if config.plugins.torreplayer.skins.value == "list":
            self['fatima'] = Label(_("*** Torrents Movies's Browser [YTS]***"))
            self['poster'] = Pixmap()

    def initializeActionMap(self):
        self['actions'] = ActionMap(['DirectionActions', 'EPGSelectActions', 'MenuActions', 'OkCancelActions', 'ColorActions'],
                                    {'ok': self.ok, 'cancel': self.cancel, 'green': self.goBack, 'yellow': self.nextPage,
                                     'red': self.removeFavorite, 'blue': self.browser, 'info': self.ghita, 'menu': self.dream}, -1)

    def initializeLabels(self):
        self['key_red'] = Label(_('Remove from list'))
        self['key_yellow'] = Label('')
        self['key_green'] = Label('')
        self['key_blue'] = Label(_('Download Manager'))
        self['yassine'] = Label('')
        self['zahra'] = Label('')
        self['genre'] = Label('')
        self['ostende'] = Label('')

    def loader(self):
        self.loadFavorites()

    def loadFavorites(self):
        fav_file = '/etc/enigma2/favorites_movies.json'
        if not os.path.exists(fav_file):
            self.session.open(MessageBox, _('No Favorites Found.'), MessageBox.TYPE_INFO)
            self.close()
            logdata("Favorites file does not exist")
            return

        with open(fav_file, 'r') as f:
            try:
                favorites = json.load(f)
                self.menu_list.clear()
                if not favorites:
                    logdata("Favorites file is empty")
                    self.menu_list.append(('No favorites found', '', [], '', [], '', '', 0, None, ''))
                    self.setListInUI()
                    return

                for movie in favorites:
                    self.addMovieToList(movie)
                    self.setListInUI()
            except json.JSONDecodeError as e:
                logdata('Error reading favorites JSON file: {}'.format(e))
                self.menu_list.append(('Error reading favorites file', '', [], '', [], '', '', 0, None, ''))
                self.setListInUI()

    def addMovieToList(self, movie):
        try:
            torrents = movie.get('torrents', [])
            logdata("torrents: {}".format(torrents))
            synopsis = movie.get('description_full', 'No description available')
            genres = movie.get('genres', [])
            movie_id = movie.get('id')
            rating = movie.get('rating')
            title_long = movie.get('title_long')
            titlex = movie.get('title')
            poster = movie.get('large_cover_image')
            imdb = movie.get('imdb_code')
            movie_info = self.createMovieInfo(movie, title_long, movie_id, genres, synopsis, torrents, poster, rating, titlex)

            with self.menu_list_lock:
                self.menu_list.append(movie_info)

            if imdb:
                if config.plugins.torreplayer.skins.value == "grid":
                    Thread(target=self.gettmdbdata, args=(imdb, titlex)).start()
                else:
                    self.gettmdbdata(imdb, titlex)
            if poster:
                if config.plugins.torreplayer.skins.value != "grid":
                    self.updatePoster(poster, title_long, movie_info)
                else:
                    Thread(target=self.updatePoster, args=(poster, title_long, movie_info)).start()
        except Exception as e:
            logdata('Error adding movie to list: {}'.format(e))

    def updatePoster(self, poster, title_long, movie_info):
        if self.stop_event.is_set():
            return

        title_clean = title_long.replace('/', '').replace(':', '').replace(' ', '').lower()
        filename = os.path.join(self.poster_directory, '{}_p.jpg'.format(title_clean))
        logdata("poster favourite", filename)
        self.downloadPicture(poster, filename)
        if os.path.exists(filename):
            Poster = loadJPG(filename)
            updated_movie_info = list(movie_info)
            updated_movie_info[8] = Poster
            with self.menu_list_lock:
                try:
                    idx = self.menu_list.index(movie_info)
                    self.menu_list[idx] = tuple(updated_movie_info)
                except ValueError as e:
                    logdata('Error updating poster in menu_list:', str(e))
            # Update the UI
            self.setListInUI()

    def createMovieInfo(self, movie, title_long, movie_id, genres, synopsis, torrents, poster, rating, titlex):
        movie_title = str(title_long) if title_long else movie.get('title', 'No title')
        return (movie_title, movie_id, genres, synopsis, torrents, poster, '', rating, None, titlex)

    def setListInUI(self):
        self['menu'].setList(self.menu_list)

    def cleanup(self):
        self.stop_event.set()

    def removeFavorite(self):
        selected_item = self['menu'].getCurrent()
        if not selected_item or not isinstance(selected_item, tuple) or len(selected_item) < 2:
            logdata('No movie selected or unexpected value: {}'.format(selected_item))
            return

        movie_id = selected_item[1]

        fav_file = '/etc/enigma2/favorites_movies.json'
        if not os.path.exists(fav_file):
            logdata('Favorites file does not exist')
            return

        with open(fav_file, 'r') as f:
            try:
                favorites = json.load(f)
                new_favorites = [movie for movie in favorites if movie.get('id') != movie_id]

                if len(new_favorites) < len(favorites):
                    with open(fav_file, 'w') as f_out:
                        json.dump(new_favorites, f_out, indent=4)
                    logdata('Movie removed from favorites')

                    # Refresh the favorites list in the UI
                    self.loadFavorites()
                else:
                    logdata('Movie ID not found in favorites')
            except json.JSONDecodeError as e:
                logdata('Error reading favorites JSON file: {}'.format(e))

    def gettmdbdata(self, torrent_imdb, titel):
        if titel:
            imdb_ID = str(torrent_imdb)
            url_imdb = ('https://api.themoviedb.org/3/find/{}?api_key=8789cfd3fbab7dccf1269c3d7d867aff&external_source=imdb_id&language={}').format(imdb_ID, str(config.plugins.torreplayer.tmdblng.value))
            movie_title = self.cleanTitle(titel)

            try:
                response = requests.get(url_imdb, verify=False)
                data = response.json()
                self.processTmdbData(data, movie_title, titel)
            except requests.exceptions.RequestException as e:
                logdata('Error fetching data from TMDb:', str(e))

    def processTmdbData(self, data, movie_title, titel):
        if 'movie_results' in data and data['movie_results']:
            movie_result = data['movie_results'][0]
            overview = movie_result.get('overview', '')
            poster_path = movie_result.get('poster_path', '')
            backdrop_path = movie_result.get('backdrop_path', '')
            id_tvdb = movie_result.get('id', '')

            if id_tvdb:
                self.logo(id_tvdb, movie_title)
            self.downloadPosterAndBackdrop(movie_title, poster_path, backdrop_path)
            self.saveMovieData(movie_title, titel, overview)
        else:
            logdata('No TV results found for the given IMDb ID')

    def downloadPosterAndBackdrop(self, movie_title, poster_path, backdrop_path):
        if poster_path:
            url_poster = 'http://image.tmdb.org/t/p/original' + poster_path
            filenameP = os.path.join(self.poster_directory, ('{}_p.jpg').format(movie_title))
            self.downloadPicture(url_poster, filenameP)

        if backdrop_path:
            url_backdrop = 'http://image.tmdb.org/t/p/original' + backdrop_path
            filenameB = os.path.join(self.poster_directory, ('{}_b.jpg').format(movie_title))
            self.downloadPicture(url_backdrop, filenameB)

    def saveMovieData(self, movie_title, titel, overview):
        movie_data = {'title': titel, 'overview': overview}
        json_filename = os.path.join(self.poster_directory, ('{}.json').format(movie_title))
        with open(json_filename, 'w') as (json_file):
            json.dump(movie_data, json_file)

    def cleanTitle(self, title):
        return title.lower().replace(' ', '').replace('.', '').replace('/', '').replace(':', '')

    def logo(self, id_tvdb, movie_title):
        ext = 'https://api.themoviedb.org/3/movie/' + str(id_tvdb) + '/images?api_key=8789cfd3fbab7dccf1269c3d7d867aff&language=en&include_image_language={},null'.format(str(config.plugins.torreplayer.tmdblng.value))
        try:
            response = requests.get(ext, verify=False)
            data = response.json()
            self.processLogoData(data, movie_title)
        except requests.exceptions.RequestException as e:
            logdata('Error fetching logo data from TMDb:', str(e))

    def processLogoData(self, data, movie_title):
        if 'logos' in data and data['logos']:
            logo_result = data['logos'][0]
            logo_path = logo_result.get('file_path', '')
            if logo_path:
                url_logo = 'http://image.tmdb.org/t/p/original' + logo_path
                filename_logo = os.path.join(self.poster_directory, ('{}_logo.png').format(movie_title))
                self.downloadPicture2(url_logo, filename_logo)
        else:
            logdata('No logo found for the given TVDB ID')

    def getdata(self):
        current_item = self['menu'].getCurrent()
        if not current_item or not isinstance(current_item, tuple) or len(current_item) < 5 or current_item[0] in ('No favorites found', 'Error reading favorites file'):
            logdata("Error: Unexpected value for self['menu'].getCurrent(): {}".format(current_item))
            self.resetUI()
            return

        try:
            self.rating()
            self.genre()
            self.yassine()
            self.seedsandpeers()
            self.synopsis()
            if config.plugins.torreplayer.skins.value == "list":
                self.showPoster()
            if config.plugins.torreplayer.skins.value != "grid":
                self.showLogo()
                self.showBackdrop()
            if self.ratingstars > 0:
                self['starsbg'].show()
                self['stars'].show()
                self['stars'].setValue(self.ratingstars)
            else:
                self['starsbg'].hide()
                self['stars'].hide()
        except Exception as e:
            logdata('Exception in getdata: {}'.format(str(e)))

    def resetUI(self):
        self['yassine'].setText('')
        self['zahra'].setText('')
        self['genre'].setText('')
        self['ostende'].setText('')
        self['rating'].setText('')
        self['stars'].hide()
        self['starsbg'].hide()
        if config.plugins.torreplayer.skins.value == "list":
            self['poster'].hide()
        self['backdrop'].hide()
        self['screenshot3'].hide()

    def cancel(self):
        self.loading.stop()
        self.stop_event.set()
        self.close()

    def ok(self):
        selected_item = self['menu'].getCurrent()
        if not selected_item or not isinstance(selected_item, tuple) or len(selected_item) < 5 or selected_item[0] in ('No favorites found', 'Error reading favorites file'):
            logdata('No movie selected or unexpected value: {}'.format(selected_item))
            return

        movie_titlex = selected_item[0]
        movie_titles = selected_item[9] if len(selected_item) > 9 else ''
        movie_title = movie_titles.lower().replace(' ', '').replace('.', '')
        movie_id = selected_item[1]
        logdata('ok function - movie title:', movie_titlex)
        logdata('ok function - movie ID:', movie_id)
        try:
            pfile = ('{}{}_p.jpg').format(self.poster_directory, movie_title)
        except:
            pfile = ('{}{}.jpg').format(self.poster_directory, movie_title)

        b_path = os.path.join(self.poster_directory, "{}_back.jpg".format(movie_title))
        self.session.open(MovieDetail, movie_id, pfile, b_path)
        self.genre()
        self.yassine()
        self.seedsandpeers()

    def rating(self):
        current_item = self['menu'].getCurrent()
        if not current_item or not isinstance(current_item, tuple) or len(current_item) < 8:
            logdata("Error: Unexpected value for self['menu'].getCurrent(): {}".format(current_item))
            self['stars'].hide()
            self['starsbg'].hide()
            self['rating'].setText('')
            return

        movie_titles = current_item[9]
        movie_title = movie_titles.lower().replace(' ', '').replace('.', '')
        json_filename = os.path.join(self.poster_directory, '{}.json'.format(movie_title))
        try:
            with open(json_filename, 'r') as json_file:
                movie_data = json.load(json_file)
                rating= movie_data.get('rating', '')
        except (FileNotFoundError, json.JSONDecodeError) as e:
            rating = current_item[7]
        try:
            rating_value = float(rating)
            star = _('Rating IMDB : ') + str(rating_value) + '/10'
            self.ratingstars = int(10 * round(rating_value, 1))
            self['stars'].show()
            self['stars'].setValue(self.ratingstars)
            self['starsbg'].show()
            self['rating'].setText(star)
        except (TypeError, ValueError):
            logdata('No valid rating found')
            self['stars'].hide()
            self['starsbg'].hide()
            self['rating'].setText('')

    def genre(self):
        current_item = self['menu'].getCurrent()
        if not current_item or not isinstance(current_item, tuple) or len(current_item) < 3:
            logdata("Error: Unexpected value for self['menu'].getCurrent']: {}".format(current_item))
            self['genre'].setText('')
            return

        genres = current_item[2]
        try:
            genre_text = _('Genres: ') + (', ').join(genres)
            if genres:
                genre_string = str(genre_text)
                self['genre'].setText(genre_string)
        except Exception as e:
            logdata('Exception in genre: {}'.format(str(e)))

    def yassine(self):
        current_item = self['menu'].getCurrent()
        if not current_item or not isinstance(current_item, tuple) or len(current_item) < 1:
            logdata("Error: Unexpected value for self['menu'].getCurrent']: {}".format(current_item))
            self['yassine'].setText('')
            return

        movie_title = current_item[0]
        movie_title = str(movie_title)
        if movie_title:
            try:
                self['yassine'].setText(movie_title)
            except Exception as e:
                logdata('Error set title:', str(e))

    def seedsandpeers(self):
        current_item = self['menu'].getCurrent()
        if not current_item or not isinstance(current_item, tuple) or len(current_item) < 5:
            logdata("Error: Unexpected value for self['menu'].getCurrent']: {}".format(current_item))
            self['ostende'].setText('')
            return

        torrents = current_item[4]
        seeds_and_peers_text = ''
        for torrent in torrents:
            seeds = str(torrent.get('seeds'))
            peers = str(torrent.get('peers'))
            seeds_and_peers_text = _('Seeds: ') + seeds + _(' | Peers: ') + peers

        self['ostende'].setText(seeds_and_peers_text)

    def synopsis(self):
        current_item = self['menu'].getCurrent()
        movie_titles = current_item[9]
        movie_title = movie_titles.lower().replace(' ', '').replace('.', '')
        summary = current_item[3]
        if summary:
            try:
                self['zahra'].setText(_('Description:\n') + str(summary))
            except Exception as e:
                logdata('Error set title:', str(e))
        else:
            json_filename = os.path.join(self.poster_directory, '{}.json'.format(movie_title))
            try:
                with open(json_filename, 'r') as json_file:
                    movie_data = json.load(json_file)
                    overview = movie_data.get('overview', '')
                    if overview:
                        self['zahra'].setText(_('Description:\n') + overview)
                        return
            except (FileNotFoundError, json.JSONDecodeError) as e:
                logdata('Error reading JSON file: {}'.format(e))

    def showPoster(self):
        try:
            selected_item = self['menu'].getCurrent()
            if not selected_item or not isinstance(selected_item, tuple) or len(selected_item) < 10:
                self['poster'].hide()
                return

            movie_titles = selected_item[9]
            movie_title = movie_titles.lower().replace(' ', '').replace('.', '')
            if movie_title:
                pfile = ('{}{}_p.jpg').format(self.poster_directory, movie_title)
                logdata('poster list', pfile)
                if os.path.exists(pfile):
                    self['poster'].instance.setPixmapFromFile(pfile)
                    self['poster'].show()
                else:
                    self['poster'].hide()
            else:
                self['poster'].hide()
        except Exception as e:
            logdata('Error poster:', str(e))

    def showBackdrop(self):
        try:
            self["backdrop"].hide()
            selected_item = self['menu'].getCurrent()
            if not selected_item:
                logdata("No selected item for backdrop")
                return

            movie_titles = selected_item[9]
            movie_title = movie_titles.lower().replace(' ', '').replace('.', '').replace(':', '')
            poster_path = config.plugins.torreplayer.poster_path.value
            final_backdrop_path = os.path.join(poster_path, "transmission/poster/{}_back.jpg".format(movie_title))
            logdata("Backdrop path", final_backdrop_path)

            if os.path.exists(final_backdrop_path):
                self["backdrop"].instance.setPixmapFromFile(final_backdrop_path)
                self["backdrop"].show()
                logdata("Backdrop set from file", final_backdrop_path)
            else:
                logdata("Processed backdrop not found", final_backdrop_path)
                self["backdrop"].hide()

        except Exception as e:
            logdata("Backdrop show failed", str(e))
            self["backdrop"].hide()

    def showLogo(self):
        try:
            selected_item = self['menu'].getCurrent()
            if not selected_item or not isinstance(selected_item, tuple) or len(selected_item) < 10:
                self['screenshot3'].hide()
                return

            movie_titles = selected_item[9]
            movie_title = movie_titles.lower().replace(' ', '').replace('.', '')
            logdata('movie_title eztv logo', movie_title)
            if movie_title:
                logo_file = ('{}{}_logo.png').format(self.poster_directory, movie_title)
                logdata('logo File Path:', logo_file)
                if os.path.exists(logo_file):
                    logdata('logo File Exists!')
                    self['screenshot3'].instance.setPixmapFromFile(logo_file)
                    self['screenshot3'].show()
                else:
                    logdata('logo File Does Not Exist!')
                    self['screenshot3'].hide()
            else:
                self['screenshot3'].hide()
        except Exception as e:
            logdata('Error screenshot3:', str(e))

    def dream(self):
        pass

    def browser(self):
        self.session.open(EmissionOverview.EmissionOverview)

    def downloadPicture(self, url, filename):
        try:
            if os.path.exists(filename):
                logdata("Picture already exists", filename)
                return
            response = requests.get(url, stream=True, verify=False)
            if response.status_code == 200:
                with open(filename, 'wb') as file:
                    for chunk in response.iter_content(1024):
                        file.write(chunk)
                logdata("Picture downloaded", filename)
            else:
                logdata('Error downloading picture. Status code:', response.status_code)
        except requests.exceptions.RequestException as e:
            logdata('Error during downloadPicture:', str(e))

    def downloadPicture2(self, url, filename):
        try:
            if os.path.exists(filename):
                logdata("Picture already exists", filename)
                return
            response = requests.get(url, stream=True, verify=False)
            if response.status_code == 200:
                with open(filename, 'wb') as file:
                    for chunk in response.iter_content(1024):
                        file.write(chunk)
                logdata("Picture downloaded", filename)
            else:
                logdata('Error downloading picture. Status code:', response.status_code)
        except requests.exceptions.RequestException as e:
            logdata('Error during downloadPicture:', str(e))

    def ghita(self):
        if TMDB_installed:
            selected_item = self['menu'].getCurrent()
            if not selected_item or not isinstance(selected_item, tuple) or len(selected_item) < 1:
                return

            eventName = selected_item[0]
            if eventName:
                self.session.open(TMBD, eventName)
        else:
            self.session.open(MessageBox, _('TMDB Plugin Not Installed.'), MessageBox.TYPE_INFO)

    def getpage(self):
        if self.total_pages > -1:
            self['key_yellow'].setText(_('Next Page'))
        if self.page > 1:
            self['key_green'].setText(_('Previous Page'))

    def nextPage(self):
        self.page += 1
        self.updatePage()

    def goBack(self):
        if self.page > 1:
            self.page -= 1
            self.updatePage()

    def updatePage(self):
        pass

class MovieDetail(Screen):

    def __init__(self, session, movie_id, pfile, b_path, suggestion=False):
        super(MovieDetail, self).__init__(session)
        self.skin = getSkin('Movie Detail')
        self["pic_loading"] = Pixmap()
        self["int_loading"] = Label('')
        self["msg_loading"] = Label('')
        self.poster_id = pfile
        self.backdrop_id = b_path
        self.loading = Loading(self["pic_loading"], self["int_loading"], self["msg_loading"], None)
        self.poster_directory = '{}/transmission/poster'.format(config.plugins.torreplayer.poster_path.value)
        self.skin_path = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/icons')
        self.movie_id = movie_id
        self.sugestion = suggestion
        self.url = 'https://yts.lt/api/v2/movie_details.json?with_images=true&with_cast=true&movie_id='
        self.initializeActions()
        self.my_torr_server = ts
        self.ratingstars = -1
        self.onExecBegin.append(self.loader)
        self.onClose.append(self.cleanup)
        self.initializeWidgets()
        self.loading_time = -1

    def initializeActions(self):
        self['actions'] = ActionMap(['ColorActions', 'EPGSelectActions', 'OkCancelActions', 'MenuActions'],
                                    {'info': self.ghita,
                                     'ok': self.ghita,
                                     'menu': self.trailer,
                                     'green': self.showDownloadOptions,
                                     'yellow': self.showPlayOptions,
                                     'blue': self.download3D,  # Updated action for adding to favorites
                                     'red': self.btnred,
                                     'cancel': self.cancel}, -1)

    def initializeWidgets(self):
        self['title'] = Label('')
        self['rating'] = Label('')
        self['ostende'] = Label('')
        self['genre'] = Label('')
        self['space'] = Label('')
        self['description'] = Label('')
        self['backdrop'] = Pixmap()
        self['poster'] = Pixmap()
        self['logo'] = Pixmap()
        self['imdb'] = Pixmap()
        self["key_red"] = Label(_("Exit")) if self.sugestion else Label(_("Suggestions"))
        self['key_blue'] = Label(_('Add To Fav'))
        self['key_yellow'] = Label(_('Play Movie'))
        self['key_green'] = Label(_('Download Movie'))
        self['key_white'] = Label(_('Menu To Trailer'))
        self['info'] = Label(_('Info / OK  button For more Torrents links [Stremio]'))
        self['fsklogo'] = Pixmap()
        self['stars'] = ProgressBar()
        self['starsbg'] = Pixmap()
        self['stars'].hide()
        self['starsbg'].hide()
        for i in range(1, 5):
            self['cast_photo_{}'.format(i)] = Pixmap()
            self['cast_name_{}'.format(i)] = Label('')
            self['cast_role_{}'.format(i)] = Label('')


    def loader(self):
        self.loading.start(self.loading_time, _("Fetching Movie Data..."))
        deferToThread(self.get_data).addCallback(self.updateUI).addErrback(self.handleError)

    def handleError(self, error):
        logdata('Error occurred during deferred operation: {}'.format(error))

    def get_data(self):
        self.base_url = self.url + str(self.movie_id)
        if config.plugins.torreplayer.proxy.value:
            self.base_url = get_proxied_url(self.base_url)
        self.movie_details = self.getMovieDetails(self.base_url)

    def getMovieDetails(self, url):
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json'
            }
            # Use proxy if enabled
            response = make_request_with_proxy(url, headers=headers, timeout=15)
            if not response:
                return None
            if response.status_code == 200:
                data = response.json()
                return data.get('data', {})
        except requests.RequestException as e:
            logdata('Error fetching movie details: {}'.format(str(e)))
        return {}  # Return empty data if the request fails

    def updateUI(self, *args):
          reactor.callFromThread(self.updateTitle)
          reactor.callFromThread(self.updateDescription)
          reactor.callFromThread(self.updateRating)
          reactor.callFromThread(self.updateSeedsAndPeers)
          reactor.callFromThread(self.updateGenre)
          reactor.callFromThread(self.updateFSK)
          reactor.callFromThread(self.updateSpace)
          reactor.callFromThread(self.showPoster)
          reactor.callFromThread(self.showBackdrop)
          reactor.callFromThread(self.showLogo)
          reactor.callFromThread(self.showIMDBIcon)
          reactor.callFromThread(self.updateCast)
          self.loading.stop()


    def updateCast(self):
        imdb_id = self.movie_details.get('movie', {}).get('imdb_code')  # tt7181546
        if not imdb_id:
            logdata("IMDb ID missing in movie details.")
            return
        TMDB_API_KEY = "8789cfd3fbab7dccf1269c3d7d867aff"
        find_url = "https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id" % (imdb_id, TMDB_API_KEY)
        try:
            find_response = requests.get(find_url, verify=False, timeout=10)
            if find_response.status_code == 200:
                movie_results = find_response.json().get('movie_results', [])
                if not movie_results:
                    logdata("TMDb movie_results not found for IMDb ID.")
                    return
                tmdb_id = movie_results[0].get('id')
            else:
                logdata("TMDb /find failed:", find_response.status_code)
                return
        except Exception as e:
            logdata("TMDb /find exception:", str(e))
            return
        credits_url = "https://api.themoviedb.org/3/movie/%s/credits?api_key=%s" % (tmdb_id, TMDB_API_KEY)
        try:
            response = requests.get(credits_url, verify=False, timeout=10)
            if response.status_code == 200:
                credits = response.json()
                cast_list = credits.get('cast', [])[:4]
                for i, member in enumerate(cast_list):
                    actor_name = member.get('name', 'Unknown')
                    character_name = _("As: ") + member.get('character', 'Unknown')
                    profile_path = member.get('profile_path')
                    photo_url = "https://image.tmdb.org/t/p/w185" + profile_path if profile_path else None

                    reactor.callFromThread(self['cast_name_{}'.format(i + 1)].setText, str(actor_name))
                    reactor.callFromThread(self['cast_role_{}'.format(i + 1)].setText, str(character_name))

                    if photo_url:
                        reactor.callFromThread(self.downloadAndDisplayPhoto, photo_url, 'cast_photo_{}'.format(i + 1))
                    else:
                        reactor.callFromThread(self['cast_photo_{}'.format(i + 1)].hide)
                        reactor.callFromThread(self['cast_name_{}'.format(i + 1)].hide)
                        reactor.callFromThread(self['cast_role_{}'.format(i + 1)].hide)
            else:
                logdata("TMDb credits fetch error:", response.status_code)
        except Exception as e:
            logdata("TMDb credits request failed:", str(e))

    def downloadAndDisplayPhoto(self, url, widget_name):
        import hashlib
        import time
        try:
            # Generate a hashed filename for caching
            url_hash = hashlib.sha1(url.encode('utf-8')).hexdigest()
            image_file = f'/tmp/{url_hash}.jpg'

            # If the image already exists locally, just show it
            if os.path.exists(image_file):
                self[widget_name].instance.setPixmapFromFile(image_file)
                self[widget_name].show()
                return

            # Use proxy if enabled
            if config.plugins.torreplayer.proxy.value:
                url = get_proxied_url(url)

            # Download and save the image
            response = requests.get(url, stream=True, timeout=10)
            if response.status_code == 200:
                with open(image_file, 'wb') as f:
                    for chunk in response.iter_content(8192):
                        f.write(chunk)
                self[widget_name].instance.setPixmapFromFile(image_file)
                self[widget_name].show()
            else:
                self[widget_name].hide()
        except Exception as e:
            logdata(f'Error downloading cast photo: {str(e)}')
            self[widget_name].hide()


    def extract_subtitles_for_movie(self, movie_title):
        import os
        import json
        subs_base = os.path.join(config.plugins.torreplayer.poster_path.value, 'transmission', 'Subs')
        movie_json_filename = movie_title.lower().replace(' ', '')
        movie_json_file = os.path.join(subs_base, "%s.json" % movie_json_filename)

        if not os.path.exists(movie_json_file):
            logdata("Subtitle JSON file not found: {}".format(movie_json_file))
            return

        try:
            with open(movie_json_file, 'r') as f:
                data = json.load(f)
        except ValueError as e:
            logdata("Error decoding JSON from {}: {}".format(movie_json_file, e))
            return
        except Exception as e:
            logdata("Error reading subtitle JSON file {}: {}".format(movie_json_file, e))
            return

        target_lang = config.plugins.torreplayer.subslng.value.lower()
        logdata('Loaded subtitles JSON: {}'.format(json.dumps(data)))

        downloaded_count = 0
        for sub in data.get('subtitles', []):
            subtitle_language = sub.get('language', '').lower()
            logdata('Checking subtitle language: {}'.format(subtitle_language))
            if subtitle_language == target_lang:
                subtitle_url = sub.get('url')
                if subtitle_url:
                    logdata('Attempting to download subtitle from: {}'.format(subtitle_url))
                    if self.download_subtitle(subtitle_url, "/tmp"):
                        downloaded_count += 1
                else:
                    logdata("Subtitle entry for language '{}' has no URL.".format(target_lang))

        if downloaded_count > 0:
            logdata("Finished attempting to download {} subtitles for language '{}'.".format(downloaded_count, target_lang))
        else:
            logdata("No subtitles found for language '{}'.".format(target_lang))


    def download_subtitle(self, url, target_dir="/tmp"):
        import os
        import requests
        import shutil
        import zipfile
        import errno

        logdata('download_subtitle() called. URL: {}'.format(url))
        tmp_dir = '/tmp'
        zip_path = os.path.join(tmp_dir, 'sub_temp.zip')

        try:
            try:
                os.makedirs(tmp_dir)
            except OSError as e:
                if e.errno != errno.EEXIST:
                    raise

            response = requests.get(url, stream=True, timeout=15)
            if response.status_code != 200:
                logdata("Subtitle download failed: %s (Status Code: %d)" % (url, response.status_code))
                return False

            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            extracted_count = 0
            with zipfile.ZipFile(zip_path, 'r') as z:
                for f in z.namelist():
                    if f.lower().endswith(('.srt', '.sub')):
                        filename = os.path.basename(f)
                        output_path = os.path.join(target_dir, filename)
                        base, ext = os.path.splitext(output_path)
                        counter = 1
                        while os.path.exists(output_path):
                            output_path = "{}_{}{}".format(base, counter, ext)
                            counter += 1
                        try:
                            with z.open(f) as src, open(output_path, 'wb') as dst:
                                shutil.copyfileobj(src, dst)
                            logdata("Subtitle extracted: %s" % output_path)
                            extracted_count += 1
                        except Exception as e:
                            logdata("Error extracting file {} from zip: {}".format(f, e))

            if extracted_count == 0:
                logdata("No .srt or .sub files found in the zip from {}".format(url))

            try:
                os.remove(zip_path)
                logdata("Removed temporary zip file: {}".format(zip_path))
            except Exception as e:
                logdata("Error removing temporary zip file {}: {}".format(zip_path, e))

            return True

        except requests.RequestException as e:
            logdata('Error downloading subtitle from {}: {}'.format(url, str(e)))
            return False
        except zipfile.BadZipfile:
            logdata("Downloaded file is not a valid zip file: {}".format(url))
            return False
        except (IOError, OSError) as e:
            logdata("File or directory error during subtitle download/extraction: {}".format(e))
            return False
        except Exception as e:
            logdata("An unexpected error occurred during subtitle download/extraction: %s" % str(e))
            return False


    def cleanTitle(self, title):
        # Improved cleaning for filesystem safety
        title = re.sub(r'\(\d{4}\)', '', title)
        return re.sub(r'[^a-zA-Z0-9]', '', title).lower()

    def updateTitle(self):
        title = self.movie_details.get('movie', {}).get('title_long', '')
        self['title'].setText(str(title) if title else _('No title available'))

    def updateDescription(self):
        try:
            # Get the movie title and clean it for file name usage
            title = self.movie_details.get('movie', {}).get('title_long', '')
            title = self.cleanTitle(str(title))  # Clean title for the filename
            json_filename = os.path.join(self.poster_directory, '{}.json'.format(title))

            # Log the JSON file path for debugging
            logdata("jsonmoviedetail", json_filename)

            if os.path.exists(json_filename):
                # If file exists, attempt to read it
                logdata("JSON file found: {}".format(json_filename))
                with open(json_filename, 'r') as json_file:
                    try:
                        movie_data = json.load(json_file)
                        logdata("Movie data from JSON: {}".format(movie_data))  # Log entire JSON content

                        # Fetch the overview from the JSON data
                        overview = movie_data.get('overview', '')
                        if overview:
                            overview = self.fix_arabic_text(overview)
                            self['description'].setText(_('Description:\n') + str(overview))
                            return
                        else:
                            logdata("Overview not found in JSON file.")
                    except ValueError as e:
                        # Catch and log JSON parsing errors
                        logdata('Error parsing JSON file: {}'.format(e))
            else:
                logdata("JSON file does not exist: {}".format(json_filename))

        except Exception as e:
            # Catch general exceptions and log for debugging
            logdata('Error in updateDescription: {}'.format(e))

        # Fallback: Get description from movie details directly
        description = self.movie_details.get('movie', {}).get('description_full', '')
        description = self.fix_arabic_text(description)
        self['description'].setText(str(description) if description else _('No description available'))
        logdata('Description from movie details: {}'.format(description))

    def fix_arabic_text(self, text):
        if not text:
            return text
        # Check for Arabic characters (Unicode range 0600-06FF)
        is_arabic = any(u'\u0600' <= char <= u'\u06FF' for char in text)
        if is_arabic:
            # Reverse the order of lines
            lines = text.split('\n')
            return '\n'.join(lines[::-1])
        return text

    def cleanTitle(self, title):
        title = re.sub(r'\(\d{4}\)', '', title)
        # Further clean the title by removing unwanted characters
        return title.lower().replace(' ', '').replace('.', '').replace('/', '').replace(':', '')



    def updateRating(self):
        try:
            title = self.movie_details.get('movie', {}).get('title_long', '')
            title = self.cleanTitle(str(title))  # Clean title for the filename
            json_filename = os.path.join(self.poster_directory, '{}.json'.format(title))

            # Log the JSON file path for debugging
            logdata("jsonmoviedetail", json_filename)

            if os.path.exists(json_filename):
                # If file exists, attempt to read it
                logdata("JSON file found: {}".format(json_filename))
                with open(json_filename, 'r') as json_file:
                    try:
                        movie_data = json.load(json_file)
                        rating = movie_data.get('rating', '')
                        if rating:
                            star_text = 'Rating : {}/10'.format(rating)
                            self.ratingstars = int(10 * round(float(rating), 1))
                            self['stars'].setValue(self.ratingstars)
                            self['rating'].setText(star_text)
                            self['stars'].show()
                            self['starsbg'].show()
                            return
                        else:
                            logdata("Rating not found in JSON file for Moviedetail screen.")
                    except ValueError as e:
                        # Catch and log JSON parsing errors
                        logdata('Error parsing JSON file for rating Moviedetail screen: {}'.format(e))
            else:
                logdata("JSON file does not exist for rating Moviedetail screen: {}".format(json_filename))
        except:
            rating = self.movie_details.get('movie', {}).get('rating', 0)
            star_text = 'Rating : {}/10'.format(rating)
            self.ratingstars = int(10 * round(float(rating), 1))
            self['stars'].setValue(self.ratingstars)
            self['rating'].setText(star_text)
            self['stars'].show()
            self['starsbg'].show()

    def updateSeedsAndPeers(self):
        torrents = self.movie_details.get('movie', {}).get('torrents', [])
        if torrents:
            seeds = str(torrents[0].get('seeds', 0))
            peers = str(torrents[0].get('peers', 0))
            self['ostende'].setText(_('Seeds: {} | Peers: {}').format(seeds, peers))

    def updateGenre(self):
        genres = self.movie_details.get('movie', {}).get('genres', [])
        genre_text = _('Genres: {}').format(', '.join(genres))
        self['genre'].setText(genre_text if genres else _('No genres available'))

    def updateFSK(self):
        pg_rating = self.movie_details.get('movie', {}).get('mpa_rating')
        fsk_value = self.get_fsk_value(pg_rating)
        if fsk_value:
            path = '/usr/lib/enigma2/python/Plugins/Extensions/Transmission/icons/fsk_{}.png'.format(fsk_value)
            if os.path.exists(path):
                self['fsklogo'].instance.setPixmap(LoadPixmap(path))

    def get_fsk_value(self, pg_rating):
        return {
            'PG': '0',
            'PG-13': '12',
            'PG-15': '16',
            'PGR': '16',
            'PGM': '18',
            'PGV': '18'
        }.get(pg_rating, None)

    def updateSpace(self):
        download_path = '{}/'.format(config.plugins.torreplayer.poster_path.value)
        available_space = self.get_available_space(download_path)
        total_space = self.get_total_space(download_path)
        free_space = available_space // 1073741824 if available_space else 0
        total_space = total_space // 1073741824 if total_space else 0
        message = _('Available: {}GB / Total: {}GB').format(free_space, total_space) if available_space and total_space else _('Error retrieving space information.')
        self['space'].setText(message)

    def get_available_space(self, path):
        stat = os.statvfs(path)
        return stat.f_bsize * stat.f_bavail

    def get_total_space(self, path):
        stat = os.statvfs(path)
        return stat.f_bsize * stat.f_blocks

    def showPoster(self):
        title = self.movie_details.get('movie', {}).get('title', '')
        if title:
            image_file = self.poster_id
            logdata('image_file', image_file)
            if os.path.exists(image_file):
                self["poster"].instance.setPixmapFromFile(image_file)
                self["poster"].show()
            else:
                self["poster"].hide()

    def cleanTitle(self, title):
        title = re.sub(r'\(\d{4}\)', '', title)
        return title.lower().replace(' ', '').replace('.', '').replace('/', '').replace(':', '')

    def showBackdrop(self):
        title = self.movie_details.get('movie', {}).get('title', '')
        if title:
            image_file = self.backdrop_id
            logdata('backdrop_file', image_file)
            if os.path.exists(image_file):
                self["backdrop"].instance.setPixmapFromFile(image_file)
                self["backdrop"].show()
            else:
                self["backdrop"].hide()

    def showLogo(self):
        try:
            title = self.movie_details.get('movie', {}).get('title', '')
            title = self.cleanTitle(title)
            if title:
                image_file = '{}/{}{}'.format(self.poster_directory, title, '_logo.png')
                if os.path.exists(image_file):
                    self["logo"].instance.setPixmapFromFile(image_file)
                    self["logo"].show()
                else:
                    self["logo"].hide()
        except Exception as e:
            logdata('Error logo:', str(e))

    def showIMDBIcon(self):
        self['imdb'].instance.setPixmapFromFile('%s/tmdb.png' % self.skin_path)

    def trailer(self):
        if TMDB_installed:
            trailer_code = self.movie_details.get('movie', {}).get('title', '')
            if trailer_code:
                self.session.open(TmbdYTTrailerList, trailer_code)
            else:
                self.session.open(MessageBox, _('No trailer found.'), MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, _('TMDB Plugin Not Installed.'), MessageBox.TYPE_INFO)

    def ghita(self):
        # Get IMDB ID from movie details
        poster = self.poster_id
        backdrop = self.backdrop_id
        imdb_id = self.movie_details.get('movie', {}).get('imdb_code')
        if imdb_id:
            self.session.open(TorrentioStreamsScreen, imdb_id, poster, backdrop)
        else:
            self.session.open(MessageBox, _('IMDB ID not available for this movie.'), MessageBox.TYPE_INFO, timeout=5)

    def showDownloadOptions(self):
        torrents = self.movie_details.get('movie', {}).get('torrents', [])
        options = []
        for torrent in torrents:
            # Ensure all values are converted to strings
            quality_info = _("%s | %s | %d↑ %d↓ | %s") % (
                str(torrent.get('quality', 'N/A')),
                str(torrent.get('size', 'N/A')),
                int(torrent.get('seeds', 0)),
                int(torrent.get('peers', 0)),
                str(torrent.get('video_codec', 'N/A'))
            )
            # Encode to byte string for enigma2 compatibility
            options.append((quality_info, torrent))

        self.session.openWithCallback(self.onDownloadOptionSelected,
                                    ChoiceBox,
                                    title=_('Choose download quality'),
                                    list=options)

    def showPlayOptions(self):
        torrents = self.movie_details.get('movie', {}).get('torrents', [])
        options = []
        for torrent in torrents:
            quality_info = _("%s | %s | %d↑ %d↓ | %s") % (
                str(torrent.get('quality', 'N/A')),
                str(torrent.get('size', 'N/A')),
                int(torrent.get('seeds', 0)),
                int(torrent.get('peers', 0)),
                str(torrent.get('video_codec', 'N/A'))
            )
            options.append((quality_info, torrent))

        self.session.openWithCallback(self.onPlayOptionSelected,
                                    ChoiceBox,
                                    title=_('Choose play quality'),
                                    list=options)

    def onDownloadOptionSelected(self, choice):
        if choice:
            selected_torrent = choice[1]
            if config.plugins.torreplayer.proxy.value:
                self.downloadMoviewithProxy(selected_torrent)
            else:
                self.downloadMovie(selected_torrent)

    def onPlayOptionSelected(self, choice):
        if choice:
            selected_torrent = choice[1]
            if config.plugins.torreplayer.proxy.value:
                self.PlayMoviewithProxy(selected_torrent)
            else:
                self.PlayMovie(selected_torrent)

    def downloadMoviewithProxy(self, torrent):
        raw_title = self.movie_details.get('movie', {}).get('title', '')
        clean_title = self.cleanTitle(raw_title)
        info_hash = torrent.get('hash')
        title = torrent.get('title') or clean_title
        magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={quote(title)}"
        torrent_link = magnet
        file_size = torrent.get('size_bytes')
        if torrent_link and file_size:
            self.initiateDownload(torrent_link, file_size, title)
        else:
            message = _('Torrent data incomplete for %s') % torrent.get('quality', '')
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

    def downloadMovie(self, torrent):
        title = self.movie_details.get('movie', {}).get('title_long', '')
        torrent_link = torrent.get('url')
        file_size = torrent.get('size_bytes')

        if torrent_link and file_size:
            self.initiateDownload(torrent_link, file_size, title)
        else:
            message = _('Torrent data incomplete for %s') % torrent.get('quality', '')
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

    def PlayMoviewithProxy(self, torrent):
        logdata('downloadAndPlay', 'Function called')
        raw_title = self.movie_details.get('movie', {}).get('title', '')
        clean_title = self.cleanTitle(raw_title)
        poster_file = os.path.join(self.poster_directory, "%s_p.jpg" % clean_title)
        if torrent:
            new_torrent = torrsrv.torrent()
            info_hash = torrent.get('hash')
            title = torrent.get('title') or clean_title
            magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={quote(title)}"
            new_torrent.link = magnet
            new_torrent.raw_title = self.movie_details['movie'].get('title', '')
            new_torrent.title = self.movie_details['movie'].get('title_long')
            new_torrent.poster = self.movie_details['movie'].get('large_screenshot_image1')
            new_torrent.save_to_db = True
            self._pending_torrent = {
                'torrent': new_torrent,
                'poster': poster_file,
                'raw_title': raw_title
            }
            self.my_torr_server.add_torrent(new_torrent)
            if self.my_torr_server.add_torrent(new_torrent):
                self.extract_subtitles_for_movie(raw_title)
                self._launch_player()
            else:
                self._check_server_status()

    def PlayMovie(self, torrent):
        logdata('downloadAndPlay', 'Function called')
        raw_title = self.movie_details.get('movie', {}).get('title', '')
        clean_title = self.cleanTitle(raw_title)
        poster_file = os.path.join(self.poster_directory, "%s_p.jpg" % clean_title)


        if torrent:
            logdata('PlayMovie', 'Creating torrent object')
            new_torrent = torrsrv.torrent()

            # Use hash to create magnet link instead of direct URL
            info_hash = torrent.get('hash')
            title = torrent.get('quality') or clean_title
            if info_hash:
                magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={quote(title)}"
                new_torrent.link = magnet
                logdata('PlayMovie', 'Created magnet link from hash: {}'.format(info_hash))
            else:
                # Fallback to direct URL if hash not available
                new_torrent.link = torrent.get('url')
                logdata('PlayMovie', 'Using direct URL (no hash available)')

            logdata('PlayMovie', 'Torrent link: {}'.format(new_torrent.link))
            new_torrent.raw_title = self.movie_details['movie'].get('title', '')
            new_torrent.title = self.movie_details['movie'].get('title_long')
            new_torrent.poster = self.movie_details['movie'].get('large_screenshot_image1')
            new_torrent.save_to_db = True

            # Store torrent data for potential retry
            self._pending_torrent = {
                'torrent': new_torrent,
                'poster': poster_file,
                'raw_title': raw_title
            }
            logdata('PlayMovie', 'Calling add_torrent with server URL: {}'.format(self.my_torr_server.url))
            result = self.my_torr_server.add_torrent(new_torrent)
            logdata('PlayMovie', 'add_torrent result: {}'.format(result))
            if result:
                logdata('PlayMovie', 'Success - launching player')
                self.extract_subtitles_for_movie(raw_title)
                self._launch_player()
            else:
                logdata('PlayMovie', 'Failed - checking server status')
                self._check_server_status()


    def _check_server_status(self):
        """Check if TorrServer is running and handle accordingly"""
        if not get_pid('TorrServer'):
            self.session.openWithCallback(
                self._handle_server_start_choice,
                MessageBox,
                _("TorrServer is not running. Start it now?"),
                MessageBox.TYPE_YESNO
            )
        else:
            self._show_server_error()

    def _handle_server_start_choice(self, answer):
        """Callback for server start confirmation dialog"""
        if answer:
            self._start_torrserver()
            # Retry after short delay
            self._retry_timer = eTimer()
            self._retry_timer.callback.append(self._retry_torrent_add)
            self._retry_timer.start(2000, True)  # 2 second delay
        else:
            self._cleanup_pending()

    def _start_torrserver(self):
        """Start TorrServer process"""
        if os.path.isfile(torrserver_path):
            server_port = config.plugins.torreplayer.serv_url.value.split(':')[-1]
            fh = open(os.devnull, 'wb')
            os.system('export GODEBUG=madvdontneed=1')
            args = [
                torrserver_path,
                '--port', server_port,
                '--path', config.plugins.torreplayer.config_path.value
            ]
            subprocess.Popen(args, shell=False, stdout=fh, stderr=fh)
            fh.close()

    def _retry_torrent_add(self):
        """Retry adding torrent after server start"""
        if self.my_torr_server.add_torrent(self._pending_torrent['torrent']):
            self._launch_player()
        else:
            self._show_server_error()
        self._cleanup_pending()

    def _launch_player(self):
        """Launch the media player with current torrent"""
        raw_title = self._pending_torrent['torrent'].raw_title
        titles = [
            self._pending_torrent['torrent'].title,
            self._pending_torrent['torrent'].link
        ]
        self.session.open(
            TorrEpisodes,
            titles,
            self.poster_id
        )
        self._cleanup_pending()

    def _show_server_error(self):
        """Show server-related error message"""
        message = _('Torrent link cannot be added. Check TorrServer settings.')
        self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
        self._cleanup_pending()

    def _cleanup_pending(self):
        """Clean up pending torrent data"""
        if hasattr(self, '_pending_torrent'):
            del self._pending_torrent
        if hasattr(self, '_retry_timer'):
            del self._retry_timer

    def initiateDownload(self, torrent_link, file_size, title):
        download_path = '{}/transmission'.format(config.plugins.torreplayer.poster_path.value)
        available_space = self.get_available_space(download_path)
        if available_space >= int(file_size):
            download_path = '{}/transmission'.format(config.plugins.torreplayer.poster_path.value)
            download_limit = '1000000'  # in KB/s
            upload_limit = '100'  # in KB/s
            rpc_url = 'http://127.0.0.1:9091/transmission/rpc'

            command = ('transmission-remote {} -a "{}" -w "{}" -d {} -u {}').format(rpc_url, torrent_link, download_path, download_limit, upload_limit)

            title = _('Downloading Movie: ') + title
            self.session.open(Console, title, [command])
        else:
            free_space = available_space // 1073741824
            total_space = self.get_total_space(download_path) // 1073741824
            message = 'Insufficient space on the download path.\n Available: {}GB / Total: {}GB'.format(free_space, total_space)
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

    def cancel(self):
        self.loading.stop()
        #self.stimer.stop()
        self.close()

    def cleanup(self):
        self.loading.stop()
        #self.stimer.stop()

    def download3D(self):
        fav_file = '/etc/enigma2/favorites_movies.json'
        movie = self.movie_details.get('movie', {})
        if not movie:
            self.session.open(MessageBox, _('No movie details available.'), MessageBox.TYPE_ERROR)
            return
        if not os.path.exists(fav_file):
            with open(fav_file, 'w') as f:
                json.dump([], f)
        with open(fav_file, 'r') as f:
            favorites = json.load(f)
        favorites.append(movie)
        with open(fav_file, 'w') as f:
            json.dump(favorites, f)
        self.session.open(MessageBox, _('Movie added to favorites.'), MessageBox.TYPE_INFO)

    def btnred(self):
        if self.sugestion:
            self.cancel()
        else:
            self.maroc()

    def maroc(self):
        try:
            movie_id = int(self.movie_id)
            self.base_url = 'https://yts.lt/api/v2/movie_suggestions.json?movie_id=' + str(movie_id)
            logdata2('base url', self.base_url)

            text = _("Downloading Movies Data Please Wait ...")
            self.session.open(TransmissionMovieBrowserGrid, self.base_url, text)
        except Exception as e:
            print("Error in suggestion():", e)
            self.session.open(MessageBox, _("Invalid movie ID"), MessageBox.TYPE_ERROR, timeout=5)

class TorrentioStreamsScreen(Screen):

        def __init__(self, session, imdb_id, pfile, b_path):
            Screen.__init__(self, session)
            self.session = session
            self.imdb_id = imdb_id
            self.poster_id = pfile
            self.backdrop_id = b_path
            self.streams = []
            self.menu_list = []

            # Skin setup
            self.skin = getSkin('TorrentioStreamsScreen')
            self["pic_loading"] = Pixmap()
            self["int_loading"] = Label('')
            self["msg_loading"] = Label('')
            self.loading = Loading(self["pic_loading"], self["int_loading"], self["msg_loading"], None)
            self["menu"] = List(self.menu_list)
            self["key_red"] = Label(_("Exit"))
            self["key_green"] = Label(_("Transmission Extended Torrents Links [Press OK for Options]"))

            self['backdrop'] = Pixmap()
            self['poster'] = Pixmap()
            self.my_torr_server = torrsrv.torrserver()

            # Actions
            self["actions"] = ActionMap(
                ["OkCancelActions", "ColorActions"],
                {
                    "cancel": self.close,
                    "red": self.close,
                    "green": self.downloadSelected,
                    "ok": self.downloadSelected,
                },
                -1
            )

            # Start loading
            self.streams = None
            self.onFirstExecBegin.append(self.loader)

        def loader(self):
            self.loading.start(5, _("Fetching Torrentio streams..."))
            deferToThread(self.fetchStreams).addCallback(self.updateList).addErrback(self.handleError)

        def fetchStreams(self):
            """Fetch streams from Torrentio API."""
            try:
                url = "https://torrentio.strem.fun/stream/movie/{}.json".format(self.imdb_id)
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
                response = requests.get(url, headers=headers, verify=False, timeout=15)
                response.raise_for_status()
                data = response.json()

                streams = data.get('streams', [])
                return streams
            except Exception as e:
                logdata('Error fetching Torrentio streams: {}'.format(str(e)))
                return []

        def updateList(self, streams):
            self.menu_list = []
            self.streams = streams or []

            for idx, s in enumerate(self.streams):

                label = s.get('title', '')
                name = s.get('name', '')
                info_hash = s.get('infoHash')
                file_idx = s.get('fileIdx', 0)

                quality = self._extractQuality(label)
                size = self._extractSize(label)
                seeds = self._extractSeeds(label)
                title = self._cleanTitle(label)
                extra = self._buildExtra(label)

                entry = (
                    _u8(quality),
                    _u8(title),
                    _u8(size),
                    _u8('Seeders: {}'.format(seeds)),
                    _u8(extra),
                    s  # keep full stream object for OK/download
                )

                self.menu_list.append(entry)

            reactor.callFromThread(self._updateUI)


        def _extractQuality(self, label):
            """Extract quality from label (4K, 2160p, 1080p, 720p, etc)"""
            label_upper = label.upper()
            if "2160P" in label_upper or "4K" in label_upper:
                return "[4K]"
            elif "1080P" in label_upper:
                return "[1080p]"
            elif "720P" in label_upper:
                return "[720p]"
            elif "480P" in label_upper:
                return "[480p]"
            return "[SD]"

        def _extractSize(self, label):
            """Extract file size from label"""
            import re
            match = re.search(r'([\d.]+\s*[GMK]B)', label, re.IGNORECASE)
            return match.group(1) if match else ""

        def _extractSeeds(self, label):
            """Extract seeders count from label"""
            import re
            match = re.search(r'(\d+)\s*seeders?', label, re.IGNORECASE)
            if not match:
                match = re.search(r'[👤]\s*(\d+)', label)
            return match.group(1) if match else ""

        def _cleanTitle(self, label):
            """Clean title by removing emoji/metadata"""
            import re
            title = re.sub(r'[\U0001F300-\U0001F9FF]', '', label)  # All emoji
            title = re.sub(r'[⚡⚙️]', '', title)  # Additional symbols
            title = re.sub(r'\d+(\.\d+)?\s*[GMK]B', '', title, flags=re.IGNORECASE)
            title = re.sub(r'\d+\s*seeders?', '', title, flags=re.IGNORECASE)
            title = re.sub(r'\s+', ' ', title).strip()
            if len(title) > 120:
                title = title[:110] + "\n" + title[110:]
            return title

        def _buildExtra(self, label):
            """Build extra info line"""
            parts = []
            if "cached" in label.lower() or "debrid" in label.lower():
                parts.append("Cached")
            if "HEVC" in label.upper() or "X265" in label.upper():
                parts.append("HEVC")
            if "HDR" in label.upper():
                parts.append("HDR")
            if "REMUX" in label.upper():
                parts.append("REMUX")
            return " | ".join(parts) if parts else ""

        def _updateUI(self):
            self.loading.stop()
            self["menu"].setList(self.menu_list)

            if not self.menu_list:
                self.session.openWithCallback(
                    self._closeAfterNoStreams,
                    MessageBox,
                    _('No streams found from Torrentio.'),
                    MessageBox.TYPE_INFO,
                    timeout=5
                )
                return

            # Streams exist
            self.showPoster()
            self.showBackdrop()

        def _closeAfterNoStreams(self, *args):
            self.close()

        def handleError(self, error):
            """Handle errors during stream fetching."""
            logdata('Torrentio error: {}'.format(error))
            reactor.callFromThread(self._showError)

        def _showError(self):
            self.loading.stop()
            self.session.open(MessageBox, _('Failed to fetch Torrentio streams.'), MessageBox.TYPE_ERROR, timeout=5)


        def downloadSelected(self):
            """Handle torrent selection - show options for play or download."""
            current = self["menu"].getCurrent()
            if current is None:
                return

            stream = current[5]
            info_hash = stream.get('infoHash')
            title = current[1]

            if not info_hash:
                return

            # Create magnet link
            magnet_link = "magnet:?xt=urn:btih:{}".format(info_hash)

            # Show options: Play or Download
            options = [
                (_("Play with TorrServer"), "play"),
                (_("Download with Transmission"), "download")
            ]

            self._current_magnet = magnet_link
            self._current_title = title

            self.session.openWithCallback(
                self._handleOption,
                MessageBox,
                _("Choose action for:\n{}").format(title[:50]),
                list=options,
                type=MessageBox.TYPE_YESNO
            )

        def _handleOption(self, choice):
            """Handle user choice between play and download."""
            if choice == "play":
                self._playWithTorrServer()
            elif choice == "download":
                self._downloadWithTransmission()

        def _playWithTorrServer(self):
            """Play torrent using TorrServer."""
            try:
                # Create torrent object
                new_torrent = torrsrv.torrent()
                new_torrent.link = self._current_magnet
                new_torrent.raw_title = self._current_title
                new_torrent.title = self._current_title
                new_torrent.poster = ''
                new_torrent.save_to_db = True

                # Store for retry if needed
                self._pending_torrent = {'torrent': new_torrent, 'poster': '', 'raw_title': self._current_title}

                result = self.my_torr_server.add_torrent(new_torrent)
                logdata('PlayMovie stremio', 'add_torrent result: {}'.format(result))
                if result:
                    logdata('PlayMovie stremio', 'Success - launching player')
                    self._launch_player()
                else:
                    self._check_server_status()

            except Exception as e:
                logdata('Error playing with TorrServer: {}'.format(str(e)))
                self.session.open(MessageBox, _('Error: {}').format(str(e)), MessageBox.TYPE_ERROR, timeout=5)

        def _launch_player(self):
            """Launch the media player with current torrent."""
            titles = [
                self._pending_torrent['torrent'].title,
                self._pending_torrent['torrent'].link
            ]
            self.session.open(
                TorrEpisodes,
                titles,
                str(self.poster_id)
            )
            self._cleanup_pending()

        def _check_server_status(self):
            """Check if TorrServer is running and offer to start it."""
            message = _('TorrServer not responding. Start TorrServer?')
            self.session.openWithCallback(
                self._handle_server_start_choice,
                MessageBox,
                message,
                MessageBox.TYPE_YESNO
            )

        def _handle_server_start_choice(self, answer):
            """Handle server start confirmation."""
            if answer:
                self._start_torrserver()
                # Retry after delay
                from enigma import eTimer
                self._retry_timer = eTimer()
                self._retry_timer.callback.append(self._retry_torrent_add)
                self._retry_timer.start(2000, True)  # 2 second delay
            else:
                self._cleanup_pending()

        def _start_torrserver(self):
            try:
                start_server()
            except Exception as e:
                logdata('Error starting TorrServer: {}'.format(str(e)))

        def _retry_torrent_add(self):
            """Retry adding torrent after server start."""
            from Plugins.Extensions.Transmission.torrmgr import torrsrv

            if self.my_torr_server.add_torrent(self._pending_torrent['torrent']):
                self._launch_player()
            else:
                self._show_server_error()
            self._cleanup_pending()

        def _show_server_error(self):
            """Show server-related error message."""

            message = _('Torrent link cannot be added.\nCheck TorrServer status and settings.')

            if not os.path.isfile('/usr/bin/TorrServer'):
                message = _('Install TorrServer first from plugin settings.')
            elif not get_pid('TorrServer'):
                message = _('Failed to auto-start TorrServer.\nTry manual start from plugin settings.')

            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
            self._cleanup_pending()

        def _cleanup_pending(self):
            """Clean up pending torrent data."""
            if hasattr(self, '_pending_torrent'):
                del self._pending_torrent
            if hasattr(self, '_retry_timer'):
                del self._retry_timer

        def _downloadWithTransmission(self):
            """Download torrent using Transmission."""
            # Estimate file size (we don't have exact size from Torrentio)
            # Use a default large size to trigger space check
            estimated_size = 5 * 1024 * 1024 * 1024  # 5GB estimate

            self.initiateDownload(self._current_magnet, estimated_size, self._current_title)

        def initiateDownload(self, torrent_link, file_size, title):
            """Initiate download with space checking."""
            import os
            from Components.Console import Console

            download_path = '{}/transmission'.format(config.plugins.torreplayer.poster_path.value)

            # Check available space
            available_space = self.get_available_space(download_path)
            if available_space >= int(file_size):
                download_limit = '1000000'  # in KB/s
                upload_limit = '100'  # in KB/s
                rpc_url = 'http://127.0.0.1:9091/transmission/rpc'

                command = 'transmission-remote {} -a "{}" -w "{}" -d {} -u {}'.format(
                    rpc_url, torrent_link, download_path, download_limit, upload_limit
                )

                title_text = _('Downloading: ') + title[:30]
                self.session.open(Console, title_text, [command])
            else:
                free_space = available_space // 1073741824
                total_space = self.get_total_space(download_path) // 1073741824
                message = _('Insufficient space on the download path.\nAvailable: {}GB / Total: {}GB').format(
                    free_space, total_space
                )
                self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

        def get_available_space(self, path):
            """Get available space in bytes."""
            import os
            try:
                stat = os.statvfs(path)
                return stat.f_bsize * stat.f_bavail
            except Exception as e:
                logdata('Error getting available space: {}'.format(str(e)))
                return 0

        def get_total_space(self, path):
            """Get total space in bytes."""
            import os
            try:
                stat = os.statvfs(path)
                return stat.f_bsize * stat.f_blocks
            except Exception as e:
                logdata('Error getting total space: {}'.format(str(e)))
                return 0

        def showPoster(self):
            if self.imdb_id:
                image_file = self.poster_id
                logdata('image_file', image_file)
                if os.path.exists(image_file):
                    self["poster"].instance.setPixmapFromFile(image_file)
                    self["poster"].show()
                else:
                    self["poster"].hide()


        def showBackdrop(self):
            if self.imdb_id:
                image_file = self.backdrop_id
                logdata('backdrop_file', image_file)
                if os.path.exists(image_file):
                    self["backdrop"].instance.setPixmapFromFile(image_file)
                    self["backdrop"].show()
                else:
                    self["backdrop"].hide()

from twisted.web import server, resource, static, http
import os

class TransmissionWebServer(resource.Resource):
    isLeaf = False

    def __init__(self, session):
        resource.Resource.__init__(self)
        self.session = session
        self.transmissionSessionId = ''
        self.basePath = ''
        self.putChild(b'torrplay', TorrPlayResource(session))
        web_path = '/usr/lib/enigma2/python/Plugins/Extensions/Transmission/web'
        if os.path.exists(web_path):
            self.putChild(b'web', static.File(web_path))

    def build_url(self, path):
        return '%s%s' % (self.basePath, path)

    def safe_float(self, s):
        try:
            return float(str(s or 0).replace(',', '.'))
        except:
            return 0.0

    def getTmdbPoster(self, imdb_id):
        if not imdb_id:
            return ''
        try:
            lang = str(config.plugins.torreplayer.tmdblng.value)
            url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id&language=%s' % (imdb_id, TMDB_API_KEY, lang)
            response = requests.get(url, timeout=5, verify=False)
            data = response.json()
            if data.get('movie_results'):
                poster_path = data['movie_results'][0].get('poster_path')
                if poster_path:
                    return 'https://image.tmdb.org/t/p/w342' + poster_path
            if data.get('tv_results'):
                poster_path = data['tv_results'][0].get('poster_path')
                if poster_path:
                    return 'https://image.tmdb.org/t/p/w342' + poster_path
        except:
            pass
        return ''

    def getChild(self, path, request):
        child = resource.Resource.getChild(self, path, request)
        if isinstance(child, resource.NoResource):
            return self
        return child

    def render(self, request):
        try:
            if request.method == b'GET':
                return self.render_GET(request)
            elif request.method == b'POST':
                return self.render_POST(request)
            else:
                return self.errorPage('Method not allowed')
        except Exception as e:
            import traceback
            return self.errorPage('Error: %s<br><br>%s' % (str(e), traceback.format_exc().replace('\n', '<br>')))

    def render_POST(self, request):
        path = request.path.decode('utf-8')
        if path.endswith('/config'):
            return self.handle_config_request(request)
        else:
            return self.errorPage('Invalid POST request')

    def render_GET(self, request):
        request.setHeader(b'content-type', b'text/html; charset=utf-8')
        path = request.path.decode('utf-8')
        args = {k.decode('utf-8'): [v.decode('utf-8') for v in val] for k, val in request.args.items()}

        if path == '/' or path == '':
            return self.mainPage(request)
        if path.startswith('/movies'):
            return self.getMovies(args)
        elif path == '/movie':
            movie_id = args.get('id', [None])[0]
            if movie_id:
                return self.getMovieDetails(movie_id)
            return self.errorPage('Missing movie ID.')
        elif path == '/series':
            return self.getSeries(args)
        elif path == '/serie':
            imdb_id = args.get('id', [None])[0]
            if imdb_id:
                return self.getSerieDetails(imdb_id)
            return self.errorPage('Missing IMDB ID.')
        elif path == '/play':
            return self.playTorrent(args)
        elif path == '/download':
            magnet = args.get('magnet', [None])[0]
            return self.downloadTorrent(magnet)
        elif path == '/config':
            return self.handle_config_request(request)
        elif path == '/about':
            return self.aboutPage()
        elif path == '/webtor':
            magnet = args.get('magnet', [''])[0]
            title = args.get('title', [''])[0]
            poster = args.get('poster', [''])[0]
            movie_id = args.get('id', [None])[0]
            return self.webtorPage(magnet, title, poster, movie_id)
        elif path == '/add_favorite':
            return self.addFavorite(args)
        return self.errorPage('Page not found.')

    def mainPage(self, request=None):
        base = request.path.decode() if request else ''
        if base.endswith('/'):
            base = base[:-1]
        if not base:
            base = ''

        def href(path):
            return base + path

        style = "\n        <style>\n          :root {\n            --primary: #00e5ff;\n            --secondary: #b388ff;\n            --dark: #0a0a18;\n            --darker: #060612;\n            --card: #13132e;\n          }\n          * {\n            margin: 0;\n            padding: 0;\n            box-sizing: border-box;\n          }\n          body {\n            background: linear-gradient(125deg, var(--darker) 0%, var(--dark) 50%, #1a1a3a 100%);\n            color: #fff;\n            font-family: 'Montserrat', sans-serif;\n            min-height: 100vh;\n            overflow-x: hidden;\n            position: relative;\n          }\n          body::before {\n            content: '';\n            position: absolute;\n            top: 0;\n            left: 0;\n            width: 100%;\n            height: 100%;\n            background:\n              radial-gradient(circle at 15% 50%, rgba(0, 229, 255, 0.1) 0%, transparent 20%),\n              radial-gradient(circle at 85% 30%, rgba(179, 136, 255, 0.1) 0%, transparent 20%);\n            z-index: -1;\n          }\n          h1 {\n            text-align: center;\n            padding: 40px 20px 30px;\n            color: var(--primary);\n            font-family: 'Orbitron', sans-serif;\n            font-size: 2.8rem;\n            text-shadow: 0 0 15px rgba(0, 229, 255, 0.7);\n            letter-spacing: 2px;\n            margin: 0;\n            animation: pulse 3s infinite alternate;\n          }\n          .subtitle {\n            text-align: center;\n            color: var(--secondary);\n            margin-top: -10px;\n            margin-bottom: 30px;\n            font-size: 1.1rem;\n          }\n          .grid {\n            display: grid;\n            gap: 25px;\n            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));\n            padding: 30px;\n            max-width: 1000px;\n            margin: 0 auto;\n          }\n          .card {\n            background: rgba(19, 19, 46, 0.8);\n            border-radius: 16px;\n            text-align: center;\n            padding: 0;\n            transition: all 0.4s;\n            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);\n            cursor: pointer;\n            border: 1px solid rgba(96, 125, 139, 0.3);\n            overflow: hidden;\n            position: relative;\n            transform: translateY(0);\n            opacity: 0;\n            animation: cardEntry 0.6s forwards;\n          }\n          .card:nth-child(1) { animation-delay: 0.1s; }\n          .card:nth-child(2) { animation-delay: 0.2s; }\n          .card:nth-child(3) { animation-delay: 0.3s; }\n          .card:nth-child(4) { animation-delay: 0.4s; }\n          .card:nth-child(5) { animation-delay: 0.5s; }\n          .card:nth-child(6) { animation-delay: 0.6s; }\n          .card:nth-child(7) { animation-delay: 0.7s; }\n          .card:nth-child(8) { animation-delay: 0.8s; }\n          .card::before {\n            content: '';\n            position: absolute;\n            top: -50%;\n            left: -50%;\n            width: 200%;\n            height: 200%;\n            background: linear-gradient(45deg, transparent, rgba(0, 229, 255, 0.1), transparent);\n            transform: rotate(30deg);\n            transition: all 0.6s;\n          }\n          .card:hover {\n            transform: translateY(-10px) scale(1.03);\n            box-shadow: 0 10px 25px rgba(0, 229, 255, 0.3);\n            border-color: rgba(0, 229, 255, 0.5);\n          }\n          .card:hover::before {\n            transform: rotate(30deg) translate(10%, 10%);\n          }\n          .card-content {\n            padding: 30px 20px;\n            position: relative;\n            z-index: 2;\n            background: rgba(19, 19, 46, 0.7);\n            height: 100%;\n            display: flex;\n            flex-direction: column;\n            align-items: center;\n            justify-content: center;\n          }\n          .icon {\n            font-size: 2.5rem;\n            margin-bottom: 15px;\n            color: var(--primary);\n            text-shadow: 0 0 10px rgba(0, 229, 255, 0.7);\n            transition: transform 0.3s;\n          }\n          .card:hover .icon {\n            transform: scale(1.2);\n          }\n          .card a, .card .js-link {\n            color: #fff;\n            text-decoration: none;\n            font-size: 1.2rem;\n            font-weight: 600;\n            letter-spacing: 0.5px;\n            display: block;\n            transition: color 0.3s;\n          }\n          .card:hover a, .card:hover .js-link {\n            color: var(--primary);\n            text-shadow: 0 0 8px rgba(0, 229, 255, 0.5);\n          }\n          .glow {\n            position: fixed;\n            top: 0;\n            left: 0;\n            width: 100%;\n            height: 100%;\n            pointer-events: none;\n            z-index: -1;\n            background: radial-gradient(circle at var(--x) var(--y), rgba(0, 229, 255, 0.1), transparent 30%);\n          }\n          footer {\n            text-align: center;\n            padding: 20px 10px;\n            font-size: 0.9rem;\n            color: #ccc;\n            margin-top: 40px;\n          }\n          .footer-content {\n            display: inline-block;\n          }\n          .footer-content .version {\n            margin-left: 10px;\n            color: var(--primary);\n          }\n          @keyframes pulse {\n            0% { text-shadow: 0 0 15px rgba(0, 229, 255, 0.7); }\n            100% { text-shadow: 0 0 25px rgba(0, 229, 255, 0.9), 0 0 35px rgba(179, 136, 255, 0.7); }\n          }\n          @keyframes cardEntry {\n            0% { transform: translateY(30px); opacity: 0; }\n            100% { transform: translateY(0); opacity: 1; }\n          }\n          @media (max-width: 600px) {\n            .grid {\n              grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));\n              gap: 15px;\n              padding: 20px;\n            }\n            h1 {\n              font-size: 2rem;\n              padding: 30px 15px 20px;\n            }\n            .card-content {\n              padding: 20px 15px;\n            }\n            .icon {\n              font-size: 2rem;\n            }\n          }\n        </style>\n        "
        return ('<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Transmission Web Control</title><link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Orbitron:wght@500&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">%s</head><body><div class="glow"></div><h1><i class="fas fa-cloud-download-alt"></i> TRANSMISSION WEB</h1><p class="subtitle">Your e2Torrent Control Center</p><div class="grid"><div class="card"><div class="card-content"><div class="icon"><i class="fas fa-film"></i></div><a href="%s">All Movies</a></div></div><div class="card"><div class="card-content"><div class="icon"><i class="fas fa-tv"></i></div><a href="%s">4K Movies</a></div></div><div class="card"><div class="card-content"><div class="icon"><i class="fas fa-vr-cardboard"></i></div><a href="%s">3D Movies</a></div></div><div class="card"><div class="card-content"><div class="icon"><i class="fas fa-tv"></i></div><a href="%s">TV Series</a></div></div><div class="card"><div class="card-content"><div class="icon"><i class="fas fa-plug"></i></div><a href="%s">Setup Plugin</a></div></div><div class="card" onclick="openPort(9091)"><div class="card-content"><div class="icon"><i class="fas fa-download"></i></div><div class="js-link">Download Manager</div></div></div><div class="card" onclick="openPort(8090)"><div class="card-content"><div class="icon"><i class="fas fa-bolt"></i></div><div class="js-link">TorrServer</div></div></div><div class="card"><div class="card-content"><div class="icon"><i class="fas fa-info-circle"></i></div><a href="%s">About</a></div></div></div><footer><div class="footer-content"><p>© 2025 Ostende – Transmission Web UI</p><span class="version">v2.1.6</span></div></footer><script>function openPort(port){const loc=window.location;const ip=loc.hostname;const url=`http://${ip}:${port}`;window.open(url,\'_blank\');}document.addEventListener(\'mousemove\',(e)=>{document.documentElement.style.setProperty(\'--x\',`${e.clientX}px`);document.documentElement.style.setProperty(\'--y\',`${e.clientY}px`);});document.querySelectorAll(\'.card\').forEach(card=>{card.addEventListener(\'click\',function(e){if(this.querySelector(\'a\'))return;const rect=this.getBoundingClientRect();const x=e.clientX-rect.left;const y=e.clientY-rect.top;const ripple=document.createElement(\'span\');ripple.className=\'ripple\';ripple.style.left=x+\'px\';ripple.style.top=y+\'px\';this.appendChild(ripple);setTimeout(()=>ripple.remove(),600);});});</script></body></html>' % (style,
         href('/movies'),
         href('/movies?quality=4k'),
         href('/movies?quality=3d'),
         href('/series'),
         href('/config'),
         href('/about'))).encode('utf-8')

    def aboutPage(self):
        plugin_version = '5.4.2'
        transmission_version = '4.1.0'
        html = '\n        <html>\n        <head>\n            <meta charset="UTF-8">\n            <meta name="viewport" content="width=device-width, initial-scale=1">\n            <title>About Transmission</title>\n            <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Orbitron:wght@500&display=swap" rel="stylesheet">\n            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">\n            <style>\n                :root {\n                    --primary: #00e5ff;\n                    --secondary: #b388ff;\n                    --dark: #0a0a18;\n                    --darker: #060612;\n                    --card: #13132e;\n                }\n\n                * {\n                    margin: 0;\n                    padding: 0;\n                    box-sizing: border-box;\n                }\n\n                body {\n                    background: linear-gradient(125deg, var(--darker) 0%%, var(--dark) 50%%, #1a1a3a 100%%);\n                    color: #fff;\n                    font-family: \'Montserrat\', sans-serif;\n                    min-height: 100vh;\n                    overflow-x: hidden;\n                    position: relative;\n                    display: flex;\n                    flex-direction: column;\n                }\n\n                body::before {\n                    content: \'\';\n                    position: absolute;\n                    top: 0;\n                    left: 0;\n                    width: 100%%;\n                    height: 100%%;\n                    background:\n                        radial-gradient(circle at 15%% 50%%, rgba(0, 229, 255, 0.1) 0%%, transparent 20%%),\n                        radial-gradient(circle at 85%% 30%%, rgba(179, 136, 255, 0.1) 0%%, transparent 20%%);\n                    z-index: -1;\n                }\n\n                .container {\n                    padding: 60px 20px 30px;\n                    max-width: 800px;\n                    margin: 0 auto;\n                    flex: 1;\n                    position: relative;\n                    z-index: 2;\n                }\n\n                .glow {\n                    position: fixed;\n                    top: 0;\n                    left: 0;\n                    width: 100%%;\n                    height: 100%%;\n                    pointer-events: none;\n                    z-index: -1;\n                    background: radial-gradient(circle at var(--x) var(--y), rgba(0, 229, 255, 0.1), transparent 30%%);\n                }\n\n                h1 {\n                    text-align: center;\n                    padding: 0 0 30px;\n                    color: var(--primary);\n                    font-family: \'Orbitron\', sans-serif;\n                    font-size: 2.8rem;\n                    text-shadow: 0 0 15px rgba(0, 229, 255, 0.7);\n                    letter-spacing: 2px;\n                    margin: 0;\n                    animation: pulse 3s infinite alternate;\n                }\n\n                .about-card {\n                    background: rgba(19, 19, 46, 0.8);\n                    border-radius: 16px;\n                    padding: 40px;\n                    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);\n                    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);\n                    border: 1px solid rgba(96, 125, 139, 0.3);\n                    margin-bottom: 40px;\n                    animation: fadeInUp 0.8s ease-out forwards;\n                    position: relative;\n                    overflow: hidden;\n                }\n\n                .about-card::before {\n                    content: \'\';\n                    position: absolute;\n                    top: -50%%;\n                    left: -50%%;\n                    width: 200%%;\n                    height: 200%%;\n                    background: linear-gradient(45deg, transparent, rgba(0, 229, 255, 0.1), transparent);\n                    transform: rotate(30deg);\n                    transition: all 0.6s;\n                    z-index: -1;\n                }\n\n                .info-grid {\n                    display: grid;\n                    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));\n                    gap: 30px;\n                    margin-top: 20px;\n                }\n\n                .info-item {\n                    background: rgba(10, 10, 24, 0.5);\n                    border-radius: 12px;\n                    padding: 20px;\n                    text-align: center;\n                    border: 1px solid rgba(0, 229, 255, 0.2);\n                    transition: all 0.3s ease;\n                    animation: fadeIn 0.8s ease-out forwards;\n                }\n\n                .info-item:hover {\n                    transform: translateY(-5px);\n                    box-shadow: 0 8px 20px rgba(0, 229, 255, 0.2);\n                    border-color: var(--primary);\n                }\n\n                .info-item h3 {\n                    color: var(--primary);\n                    margin-bottom: 15px;\n                    font-size: 1.3rem;\n                    font-weight: 600;\n                }\n\n                .info-item p {\n                    font-size: 1.1rem;\n                    margin: 0;\n                }\n\n                .highlight {\n                    color: var(--primary);\n                    font-weight: 600;\n                    text-shadow: 0 0 8px rgba(0, 229, 255, 0.5);\n                }\n\n                .dev-name {\n                    display: inline-block;\n                    animation: glowText 2s infinite alternate;\n                }\n\n                .buttons {\n                    display: grid;\n                    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));\n                    gap: 25px;\n                    margin: 40px 0;\n                }\n\n                .btn {\n                    background: linear-gradient(45deg, rgba(0, 229, 255, 0.2), rgba(179, 136, 255, 0.2));\n                    color: #fff;\n                    padding: 20px;\n                    border: 1px solid rgba(0, 229, 255, 0.3);\n                    border-radius: 16px;\n                    text-decoration: none;\n                    font-size: 1.1rem;\n                    font-weight: 600;\n                    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);\n                    display: flex;\n                    align-items: center;\n                    justify-content: center;\n                    text-align: center;\n                    position: relative;\n                    overflow: hidden;\n                    z-index: 2;\n                    animation: cardEntry 0.6s forwards;\n                    opacity: 0;\n                    transform: translateY(20px);\n                }\n\n                .btn:nth-child(1) { animation-delay: 0.1s; }\n                .btn:nth-child(2) { animation-delay: 0.2s; }\n                .btn:nth-child(3) { animation-delay: 0.3s; }\n\n                .btn::before {\n                    content: \'\';\n                    position: absolute;\n                    top: 0;\n                    left: 0;\n                    width: 100%%;\n                    height: 100%%;\n                    background: linear-gradient(45deg, rgba(0, 229, 255, 0.3), rgba(179, 136, 255, 0.3));\n                    opacity: 0;\n                    transition: opacity 0.4s;\n                    z-index: -1;\n                }\n\n                .btn:hover {\n                    transform: translateY(-8px);\n                    box-shadow: 0 10px 25px rgba(0, 229, 255, 0.3);\n                    border-color: var(--primary);\n                }\n\n                .btn:hover::before {\n                    opacity: 1;\n                }\n\n                .btn span.icon {\n                    font-size: 1.8rem;\n                    margin-right: 15px;\n                    transition: transform 0.3s;\n                }\n\n                .btn:hover span.icon {\n                    transform: scale(1.2);\n                    animation: bounce 0.6s;\n                }\n\n                /* FOOTER STYLES */\n                footer {\n                    background: rgba(10, 10, 24, 0.8);\n                    color: rgba(255, 255, 255, 0.7);\n                    text-align: center;\n                    padding: 15px;\n                    font-size: 0.9rem;\n                    border-top: 1px solid rgba(0, 229, 255, 0.2);\n                    backdrop-filter: blur(5px);\n                    position: relative;\n                    z-index: 10;\n                    margin-top: auto;\n                }\n\n                footer p {\n                    animation: fadeIn 1s ease-out;\n                }\n\n                .footer-content {\n                    max-width: 1200px;\n                    margin: 0 auto;\n                    display: flex;\n                    justify-content: center;\n                    align-items: center;\n                    gap: 10px;\n                }\n\n                .version {\n                    background: rgba(0, 229, 255, 0.1);\n                    padding: 3px 8px;\n                    border-radius: 12px;\n                    font-size: 0.8em;\n                }\n\n                /* Animations */\n                @keyframes pulse {\n                    0%% { text-shadow: 0 0 15px rgba(0, 229, 255, 0.7); }\n                    100%% { text-shadow: 0 0 25px rgba(0, 229, 255, 0.9), 0 0 35px rgba(179, 136, 255, 0.7); }\n                }\n\n                @keyframes fadeInUp {\n                    0%% { opacity: 0; transform: translateY(30px); }\n                    100%% { opacity: 1; transform: translateY(0); }\n                }\n\n                @keyframes cardEntry {\n                    0%% { transform: translateY(30px); opacity: 0; }\n                    100%% { transform: translateY(0); opacity: 1; }\n                }\n\n                @keyframes fadeIn {\n                    from { opacity: 0; }\n                    to { opacity: 1; }\n                }\n\n                @keyframes glowText {\n                    0%% { text-shadow: 0 0 5px rgba(0, 229, 255, 0.7); }\n                    100%% { text-shadow: 0 0 15px rgba(0, 229, 255, 0.9), 0 0 25px rgba(179, 136, 255, 0.7); }\n                }\n\n                @keyframes bounce {\n                    0%%   { transform: translateY(0); }\n                    30%%  { transform: translateY(-6px); }\n                    60%%  { transform: translateY(3px); }\n                    100%% { transform: translateY(0); }\n                }\n\n                @media (max-width: 600px) {\n                    .container {\n                        padding: 40px 15px 20px;\n                    }\n\n                    h1 {\n                        font-size: 2rem;\n                        padding: 0 0 20px;\n                    }\n\n                    .about-card {\n                        padding: 25px 20px;\n                    }\n\n                    .info-grid {\n                        grid-template-columns: 1fr;\n                        gap: 20px;\n                    }\n\n                    .buttons {\n                        grid-template-columns: 1fr;\n                        gap: 15px;\n                    }\n\n                    .btn {\n                        padding: 16px;\n                        font-size: 1rem;\n                    }\n\n                    footer {\n                        padding: 10px;\n                        font-size: 0.8rem;\n                    }\n                }\n            </style>\n        </head>\n        <body>\n            <div class="glow"></div>\n\n            <div class="container">\n                <h1><i class="fas fa-info-circle"></i> ABOUT TRANSMISSION</h1>\n\n                <div class="about-card">\n                    <div class="info-grid">\n                        <div class="info-item">\n                            <h3><i class="fas fa-code-branch"></i> TRANSMISSION-CLI VERSION</h3>\n                            <p class="highlight">%s</p>\n                        </div>\n\n                        <div class="info-item">\n                            <h3><i class="fas fa-plug"></i> PLUGIN VERSION</h3>\n                            <p class="highlight">%s</p>\n                        </div>\n\n                        <div class="info-item">\n                            <h3><i class="fas fa-user-astronaut"></i> DEVELOPED BY</h3>\n                            <p class="dev-name">⭐️ <b>Ostende</b> ⭐️</p>\n                        </div>\n                    </div>\n\n                    <p style="text-align: center; margin-top: 30px; font-size: 1.1rem;">\n                        <i class="fas fa-hands-helping" style="color: var(--secondary); margin-right: 8px;"></i>\n                        For support or donation, please use the links below\n                    </p>\n                </div>\n\n                <div class="buttons">\n                    <a class="btn" href="https://www.tunisia-sat.com/forums/threads/4436107/" target="_blank">\n                        <span class="icon"><i class="fas fa-globe-africa"></i></span>\n                        <span>Arabic Support<br><small>(tunisia-sat)</small></span>\n                    </a>\n\n                    <a class="btn" href="https://www.linuxsat-support.com/thread/157336-transmission-torrent-client/" target="_blank">\n                        <span class="icon"><i class="fas fa-globe-europe"></i></span>\n                        <span>English Support<br><small>(linuxsat-support)</small></span>\n                    </a>\n\n                    <a class="btn" href="https://www.paypal.com/donate?hosted_button_id=CZ72EK8PWCTXU" target="_blank">\n                        <span class="icon"><i class="fas fa-donate"></i></span>\n                        <span>Donate via<br><small>PayPal</small></span>\n                    </a>\n                </div>\n            </div>\n\n            <footer>\n                <div class="footer-content">\n                    <p>© 2025 Ostende – Transmission Web UI</p>\n                    <span class="version">v2.1.6</span>\n                </div>\n            </footer>\n\n            <script>\n                // Mouse position tracking for glow effect\n                document.addEventListener(\'mousemove\', (e) => {\n                    document.documentElement.style.setProperty(\'--x\', `${e.clientX}px`);\n                    document.documentElement.style.setProperty(\'--y\', `${e.clientY}px`);\n                });\n\n                // Add ripple effect to buttons\n                document.querySelectorAll(\'.btn\').forEach(btn => {\n                    btn.addEventListener(\'click\', function(e) {\n                        const rect = this.getBoundingClientRect();\n                        const x = e.clientX - rect.left;\n                        const y = e.clientY - rect.top;\n\n                        const ripple = document.createElement(\'span\');\n                        ripple.className = \'ripple\';\n                        ripple.style.left = x + \'px\';\n                        ripple.style.top = y + \'px\';\n\n                        this.appendChild(ripple);\n\n                        setTimeout(() => ripple.remove(), 600);\n                    });\n                });\n            </script>\n        </body>\n        </html>\n        ' % (str(transmission_version), plugin_version)
        return html.encode("utf-8")

    def getMovies(self, args):
        try:
            import urllib, random, datetime
            from urllib.parse import quote_plus

            def to_str(val):
                if val is None:
                    return ''
                else:
                    if isinstance(val, bytes):
                        return val.decode('utf-8')
                    return str(val)

            page = int(args.get('page', ['1'])[0])
            genre = to_str(args.get('genre', [None])[0])
            quality = to_str(args.get('quality', [None])[0])
            search = to_str(args.get('q', [None])[0])
            year = to_str(args.get('year', [None])[0])
            sort = to_str(args.get('sort', ['date_added'])[0])
            order_by = 'desc'
            sort_mapping = {'date_added': 'date_added',
               'rating': 'rating',
               'seeds': 'seeds'}
            api_sort = sort_mapping.get(sort, 'date_added')
            base_url = 'https://yts.lt/api/v2/list_movies.json?limit=50'
            base_url += '&page=%d&sort_by=%s&order_by=%s' % (page, api_sort, order_by)
            if genre:
                base_url += '&genre=%s' % quote_plus(genre)
            if quality:
                if quality == '4k':
                    base_url += '&quality=2160p'
                elif quality == '3d':
                    base_url += '&quality=3D'
            if search:
                base_url += '&query_term=%s' % quote_plus(search)
            if year:
                try:
                    year_int = int(year)
                    base_url += '&year=%d' % year_int
                except ValueError:
                    pass

            r = requests.get(base_url, verify=False)
            data = r.json()
            all_movies = data.get('data', {}).get('movies', []) or []

            # Fetch TMDB posters in parallel
            if all_movies:
                from concurrent.futures import ThreadPoolExecutor
                def _fetch_poster(movie):
                    imdb_id = movie.get('imdb_code')
                    if imdb_id:
                        tmdb_url = self.getTmdbPoster(imdb_id)
                        if tmdb_url:
                            movie['medium_cover_image'] = tmdb_url

                with ThreadPoolExecutor(max_workers=10) as executor:
                    list(executor.map(_fetch_poster, all_movies))

            movie_count = data.get('data', {}).get('movie_count', 0)
            total_pages = max(1, (movie_count + 49) // 50)
            current_page = min(max(1, page), total_pages)
            hero_movie = random.choice(all_movies) if all_movies else {}
            hero_bg = hero_movie.get('background_image_original', 'https://image.tmdb.org/t/p/original/9yBVqNruk6Ykrwc32qrK2TIE5xw.jpg')
            hero_title = hero_movie.get('title', 'Popular Movies')
            hero_year = hero_movie.get('year', '')
            hero_rating = self.safe_float(hero_movie.get('rating', 0.0))

            def urlencode(params):
                return ('&').join([ '%s=%s' % (k, quote_plus(str(v))) for k, v in params.items() if v and str(v) != 'None'
                                  ])

            base_params = {'q': search,
               'genre': genre,
               'quality': quality,
               'year': year}
            base_param_string = urlencode(base_params)
            imdb_genres = {'Action': 'Action',
               'Adventure': 'Adventure', 'Animation': 'Animation', 'Biography': 'Biography',
               'Comedy': 'Comedy', 'Crime': 'Crime', 'Documentary': 'Documentary',
               'Drama': 'Drama', 'Family': 'Family', 'Fantasy': 'Fantasy',
               'Film-Noir': 'Film-Noir', 'History': 'History', 'Horror': 'Horror',
               'Music': 'Music', 'Musical': 'Musical', 'Mystery': 'Mystery',
               'Romance': 'Romance', 'Sci-Fi': 'Sci-Fi', 'Short': 'Short',
               'Sport': 'Sport', 'Thriller': 'Thriller', 'War': 'War',
               'Western': 'Western'}
            html = """<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Transmission By Ostende - Movies</title><style>:root{--primary:#e50914;--dark:#141414;--light:#f5f5f1;--gray:#808080;--card-bg:#181818;}*{box-sizing:border-box;margin:0;padding:0;}body{background:var(--dark);color:var(--light);font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;overflow-x:hidden;}.navbar{display:flex;align-items:center;justify-content:space-between;padding:20px 4%%;position:fixed;top:0;width:100%%;z-index:100;background:linear-gradient(to bottom,rgba(0,0,0,0.7) 0%%,transparent 100%%);transition:background 0.3s;}.navbar.scrolled{background:var(--dark);}.logo{color:var(--primary);font-size:28px;font-weight:700;text-decoration:none;}.nav-menu{display:flex;list-style:none;}.nav-item{margin:0 15px;}.nav-link{color:var(--light);text-decoration:none;font-size:14px;transition:color 0.3s;}.nav-link:hover{color:var(--primary);}.search-form{display:flex;align-items:center;gap:8px;}.search-input{padding:6px 12px;border-radius:20px;border:none;background:#222;color:white;width:180px;}.search-button{padding:6px 12px;background:var(--primary);border:none;border-radius:20px;color:white;cursor:pointer;}.hero{height:60vh;position:relative;display:flex;align-items:flex-end;padding:0 4%% 5%%;margin-bottom:30px;}.hero::before{content:'';position:absolute;top:0;left:0;width:100%%;height:100%%;background:linear-gradient(to top,var(--dark) 0%%,transparent 50%%),url('%s') center/cover no-repeat;z-index:-1;}.hero-content{width:100%%;}.hero-title{font-size:3rem;margin-bottom:10px;text-shadow:2px 2px 4px rgba(0,0,0,0.5);}.hero-meta{display:flex;gap:15px;margin-bottom:20px;}.hero-year,.hero-rating{font-size:1.2rem;color:#46d369;font-weight:bold;}.filters{display:flex;flex-wrap:wrap;gap:15px;padding:0 4%% 20px;align-items:center;}.filter-group{display:flex;gap:10px;align-items:center;}.filter-label{font-size:0.9rem;color:var(--gray);}.filter-select,.filter-input{padding:8px 12px;border-radius:4px;border:none;background:#222;color:white;}.filter-button{background:var(--primary);color:white;border:none;padding:8px 16px;border-radius:4px;cursor:pointer;}.tabs{display:flex;gap:10px;padding:0 4%% 20px;}.tab{color:white;text-decoration:none;padding:8px 16px;border-radius:4px;background:rgba(255,255,255,0.1);transition:all 0.3s;}.tab:hover,.tab.active{background:var(--primary);transform:scale(1.05);}.genre-bar{display:flex;flex-wrap:wrap;gap:10px;padding:0 4%% 20px;}.genre-btn{background:rgba(255,255,255,0.1);color:white;border:none;padding:8px 16px;border-radius:20px;cursor:pointer;transition:all 0.3s;font-size:0.9rem;}.genre-btn:hover,.genre-btn.active{background:var(--primary);transform:scale(1.05);}.section{padding:0 4%% 40px;}.section-title{font-size:1.5rem;margin-bottom:20px;font-weight:600;}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:20px;}.card{background:var(--card-bg);border-radius:4px;overflow:hidden;transition:all 0.3s ease;position:relative;}.card:hover{transform:scale(1.05);z-index:10;box-shadow:0 10px 20px rgba(0,0,0,0.5);}.card-image{width:100%%;height:300px;object-fit:cover;}.card-overlay{position:absolute;bottom:0;left:0;right:0;background:linear-gradient(to top,rgba(0,0,0,0.9) 0%%,transparent 100%%);padding:20px 10px 10px;}.card-title{font-size:16px;font-weight:600;margin-bottom:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}.card-meta{display:flex;justify-content:space-between;font-size:12px;color:var(--gray);}.card-rating{color:#46d369;font-weight:700;}.card-badge{position:absolute;top:10px;right:10px;background:var(--primary);color:white;font-size:10px;font-weight:bold;padding:3px 6px;border-radius:3px;z-index:2;}.pagination{display:flex;justify-content:center;gap:10px;margin-top:30px;}.page-btn{background:rgba(255,255,255,0.1);color:white;border:none;padding:8px 16px;border-radius:4px;cursor:pointer;transition:background 0.3s;}.page-btn:hover{background:var(--primary);}.page-btn.active{background:var(--primary);font-weight:bold;}@media(max-width:768px){.grid{grid-template-columns:repeat(auto-fill,minmax(150px,1fr));}.hero-title{font-size:2rem;}.card-image{height:225px;}.filters{flex-direction:column;align-items:flex-start;}}</style><script>document.addEventListener('DOMContentLoaded',function(){window.addEventListener('scroll',function(){if(window.scrollY>100){document.querySelector('.navbar').classList.add('scrolled');}else{document.querySelector('.navbar').classList.remove('scrolled');}});document.querySelectorAll('.filter-select').forEach(select=>{select.addEventListener('change',function(){this.closest('form').submit();});});});</script></head><body><nav class="navbar"><a href="/" class="logo">Transmission By Ostende</a><form class="search-form" method="GET" action="/movies"><input type="text" name="q" class="search-input" placeholder="🔍 Search movies..." value="%s"/><button type="submit" class="search-button">Go</button></form></nav><section class="hero"><div class="hero-content"><h1 class="hero-title">%s</h1><div class="hero-meta"><span class="hero-year">%s</span><span class="hero-rating">%.1f ★</span></div></div></section><div class="filters"><form class="filter-group" method="GET" action="/movies"><input type="hidden" name="q" value="%s"><input type="hidden" name="genre" value="%s"><input type="hidden" name="year" value="%s"><input type="hidden" name="sort" value="%s"><span class="filter-label">Quality:</span><select name="quality" class="filter-select"><option value="" %s>All Quality</option><option value="4k" %s>4K Ultra HD</option><option value="3d" %s>3D</option></select></form><form class="filter-group" method="GET" action="/movies"><input type="hidden" name="q" value="%s"><input type="hidden" name="genre" value="%s"><input type="hidden" name="quality" value="%s"><input type="hidden" name="sort" value="%s"><span class="filter-label">Year:</span><select name="year" class="filter-select"><option value="">All Years</option>""" % (
             hero_bg,
             search or '',
             hero_title,
             hero_year,
             hero_rating,
             search or '',
             genre or '',
             year or '',
             sort,
             'selected' if not quality else '',
             'selected' if quality == '4k' else '',
             'selected' if quality == '3d' else '',
             search or '',
             genre or '',
             quality or '',
             sort)
            current_year = datetime.datetime.now().year
            for y in range(current_year, 1900, -1):
                html += "<option value='%d'%s>%d</option>" % (
                 y,
                 ' selected' if year and str(y) == year else '',
                 y)

            html += '</select></form><form class="filter-group" method="GET" action="/movies"><input type="hidden" name="q" value="%s"><input type="hidden" name="quality" value="%s"><input type="hidden" name="year" value="%s"><input type="hidden" name="sort" value="%s"><span class="filter-label">Genre:</span><select name="genre" class="filter-select"><option value="">All Genres</option>' % (
             search or '',
             quality or '',
             year or '',
             sort)
            for key, name in imdb_genres.items():
                selected = 'selected' if genre == key else ''
                html += "<option value='%s' %s>%s</option>" % (key, selected, name)

            html += '</select></form></div><div class="tabs">'
            tabs = [
             (
              'date_added', 'Latest'),
             (
              'rating', 'Best Rated'),
             (
              'seeds', 'Most Seeded')]
            for val, label in tabs:
                active = 'active' if sort == val else ''
                html += "<a href='/movies?%s&sort=%s' class='tab %s'>%s</a>" % (
                 base_param_string, val, active, label)

            html += '</div><section class="section"><h2 class="section-title">'
            if search:
                html += 'Search Results: "%s"' % search
            else:
                if quality == '4k':
                    html += '4K Ultra HD '
                elif quality == '3d':
                    html += '3D '
                if genre:
                    html += imdb_genres.get(genre, genre) + ' '
                html += 'Movies'
                if year:
                    html += ' from %s' % year
                if not quality and not genre and not year:
                    html += 'Popular Movies'
            html += '</h2><div class="grid">'
            for movie in all_movies:
                movie_id = movie['id']
                title = movie.get('title', 'No title')
                year_val = movie.get('year', '')
                rating = movie.get('rating', 0.0)
                poster = movie.get('medium_cover_image', '')
                seeds = movie.get('seeds', 0)
                badge = ''
                torrents = movie.get('torrents', [])
                if any(t.get('quality') == '2160p' for t in torrents):
                    badge = "<span class='card-badge'>4K</span>"
                elif any(t.get('quality') == '3D' for t in torrents):
                    badge = "<span class='card-badge'>3D</span>"
                elif any(t.get('quality') == '1080p' for t in torrents):
                    badge = "<span class='card-badge'>FHD</span>"
                elif any(t.get('quality') == '720p' for t in torrents):
                    badge = "<span class='card-badge'>HD</span>"
                html += '<div class="card">%s<a href="movie?id=%d"><img src="%s" class="card-image" alt="%s"><div class="card-overlay"><h3 class="card-title">%s</h3><div class="card-meta"><span>%s</span>' % (
                 badge,
                 movie_id,
                 poster,
                 title,
                 title[:25],
                 year_val)
                if sort == 'seeds':
                    html += "<span class='card-rating'>%d 🌱</span>" % seeds
                else:
                    html += "<span class='card-rating'>%.1f ★</span>" % self.safe_float(rating)
                html += '</div></div></a></div>'

            html += '</div></section><div class="pagination">'
            if current_page > 1:
                prev_page = current_page - 1
                html += '<a href="/movies?page=%d&%s&sort=%s" class="page-btn">← Prev</a>' % (
                 prev_page, base_param_string, sort)
            start_page = max(1, current_page - 2)
            end_page = min(total_pages, current_page + 2)
            for p in range(start_page, end_page + 1):
                active = 'active' if p == current_page else ''
                html += '<a href="/movies?page=%d&%s&sort=%s" class="page-btn %s">%d</a>' % (
                 p, base_param_string, sort, active, p)

            if current_page < total_pages:
                next_page = current_page + 1
                html += '<a href="/movies?page=%d&%s&sort=%s" class="page-btn">Next →</a>' % (
                 next_page, base_param_string, sort)
            html += '</div></body></html>'
            return html.encode('utf-8')
        except Exception as e:
            import traceback
            return self.errorPage('Error: %s\n%s' % (str(e), traceback.format_exc()))

        return

    def getMovieDetails(self, movie_id):
        from urllib.parse import quote_plus
        try:
            url = 'https://yts.lt/api/v2/movie_details.json?movie_id=%s&with_images=true&with_cast=true' % movie_id
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json'
            }
            movie = requests.get(url, headers=headers, verify=False).json().get('data', {}).get('movie')
            if not movie:
                return self.errorPage('Movie not found')
            title = movie.get('title', '')
            poster = movie.get('large_cover_image', '')
            rating = movie.get('rating', '')
            year = movie.get('year', '')
            desc = movie.get('description_full', '')
            runtime = movie.get('runtime', '')
            lang = movie.get('language', '').upper()
            genres = movie.get('genres', [])
            torrents = movie.get('torrents', [])
            imdb_id = movie.get('imdb_code', '')
            tmdb_backdrop = ''
            tmdb_trailer = ''
            tmdb_cast = []
            if imdb_id:
                lang = str(config.plugins.torreplayer.tmdblng.value)
                tmdb_url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id&language=%s' % (imdb_id, TMDB_API_KEY, lang)
                tmdb_data = requests.get(tmdb_url, verify=False).json()
                if tmdb_data.get('movie_results'):
                    tmdb_res = tmdb_data['movie_results'][0]
                    tmdb_id = tmdb_res['id']
                    backdrop_path = tmdb_res.get('backdrop_path')
                    if backdrop_path:
                        tmdb_backdrop = 'https://image.tmdb.org/t/p/original' + backdrop_path

                    poster_path = tmdb_res.get('poster_path')
                    if poster_path:
                        poster = 'https://image.tmdb.org/t/p/w500' + poster_path

                    # Update description if TMDB has a better one in target language
                    tmdb_desc = tmdb_res.get('overview')
                    if tmdb_desc:
                        desc = tmdb_desc

                    videos_url = 'https://api.themoviedb.org/3/movie/%s/videos?api_key=%s&language=%s' % (tmdb_id, TMDB_API_KEY, lang)
                    videos = requests.get(videos_url, verify=False).json().get('results', [])
                    for v in videos:
                        if v.get('type') == 'Trailer' and v.get('site') == 'YouTube':
                            tmdb_trailer = 'https://www.youtube.com/embed/%s' % v['key']
                            break

                    credits_url = 'https://api.themoviedb.org/3/movie/%s/credits?api_key=%s' % (tmdb_id, TMDB_API_KEY)
                    credits = requests.get(credits_url, verify=False).json()
                    tmdb_cast = credits.get('cast', [])[:6]
            backdrop = tmdb_backdrop or movie.get('background_image_original', '')
            html = """<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>%s - Transmission</title><style>body{background:#141414;color:white;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;margin:0;padding:0;}.movie-header{background:linear-gradient(to top,#141414 0%%,transparent 50%%),url('%s') center/cover no-repeat;height:80vh;display:flex;align-items:flex-end;padding:0 5%% 8%%;box-shadow:inset 0 -50px 50px -10px #141414;}.movie-content{max-width:1200px;margin:0 auto;padding:30px 5%%;}.movie-poster{width:100%%;max-width:350px;aspect-ratio:2/3;object-fit:cover;border-radius:8px;box-shadow:0 10px 30px rgba(0,0,0,0.5);margin:20px auto;display:block;}.movie-title{font-size:3.5rem;text-align:center;margin:20px 0 10px;}.movie-meta,.genre-list{text-align:center;margin-bottom:20px;}.movie-description{text-align:center;font-size:1.1rem;max-width:800px;margin:0 auto 30px;}.cast-grid{display:flex;gap:15px;justify-content:center;margin:30px 0;flex-wrap:wrap;}.cast-card{background:#181818;padding:10px;border-radius:8px;text-align:center;width:120px;}.cast-card img{width:100%%;border-radius:5px;object-fit:cover;}.torrents-container{display:grid;grid-template-columns:repeat(auto-fill,minmax(350px,1fr));gap:25px;margin-bottom:50px;}.torrent-card{background:#181818;padding:20px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);}.torrent-buttons{display:flex;gap:12px;flex-wrap:wrap;margin-top:15px;}.btn{flex:1;padding:10px;border-radius:5px;text-align:center;text-decoration:none;font-weight:bold;transition:0.3s;display:inline-block;}.btn-primary{background:#e50914;color:white;}.btn-secondary{background:rgba(255,255,255,0.15);color:white;}.btn-download{background:#1a73e8;color:white;margin-top:10px;display:block;}.btn-watchlist{background:#ffb300;color:black;margin-top:10px;display:block;}.similar-grid{display:flex;overflow-x:auto;gap:15px;padding:20px 0 40px;scroll-snap-type:x mandatory;}.similar-card{background:#181818;border-radius:8px;overflow:hidden;text-align:center;transition:transform 0.3s;min-width:200px;scroll-snap-align:start;}.similar-card:hover{transform:translateY(-5px);}.similar-card a{text-decoration:none;color:white;display:block;}.similar-poster{width:100%%;aspect-ratio:2/3;object-fit:cover;display:block;}iframe{display:block;margin:30px auto;max-width:100%%;border:none;border-radius:10px;}</style></head><body><div class="movie-header"></div><div class="movie-content"><img src="%s" class="movie-poster" alt="%s"><h1 class="movie-title">%s</h1><div class="movie-meta">⭐ %.1f | %s | %s min | %s</div><div class="genre-list">%s</div><div class="movie-description">%s</div>""" % (title, backdrop, poster, title, title, self.safe_float(rating), year, runtime, lang, (' / ').join('<span>%s</span>' % g for g in genres), desc)

            fav_url = self.build_url('/add_favorite?id=%s&title=%s&poster=%s&year=%s&rating=%s' % (movie_id, quote_plus(title), quote_plus(poster), year, rating))
            html += '<div style="text-align:center; margin-bottom: 30px;"><a href="%s" class="btn btn-watchlist" style="display:inline-block; width:auto; padding: 10px 20px;">★ Add to Favorites</a></div>' % fav_url

            if tmdb_trailer:
                html += '<iframe width="640" height="360" src="%s" allowfullscreen></iframe>' % tmdb_trailer
            if tmdb_cast:
                html += '<h2 style="text-align:center;">Cast</h2><div class="cast-grid">'
                for actor in tmdb_cast:
                    img = 'https://image.tmdb.org/t/p/w185%s' % actor['profile_path'] if actor.get('profile_path') else 'https://via.placeholder.com/185x278?text=No+Image'
                    html += '<div class="cast-card"><img src="%s"><div>%s</div><small>%s</small></div>' % (img, actor['name'], actor['character'])
                html += '</div>'
            html += '<h2>Torrents</h2><div class="torrents-container">'
            for t in torrents:
                magnet = self.buildMagnet(t['hash'], title)
                magnet_quoted = quote_plus(magnet)
                title_quoted = quote_plus(title.encode('utf-8'))
                poster_quoted = quote_plus(backdrop.encode('utf-8'))
                html += '<div class="torrent-card"><div><strong>%s</strong> | %s | %s</div><div class="torrent-buttons"><a href="%s" class="btn btn-primary">▶ Play on Enigma2</a><a href="%s" target="_blank" class="btn btn-secondary">🌐 Play on Web</a></div><a href="%s" class="btn btn-download">⬇ Download</a></div>' % (t['quality'], t['type'], t['size'], self.build_url('/play?magnet=%s&title=%s' % (magnet_quoted, title_quoted)), self.build_url('/webtor?magnet=%s&title=%s&poster=%s&id=%s' % (magnet_quoted, title_quoted, poster_quoted, movie_id)), self.build_url('/download?magnet=%s' % magnet_quoted))

            html += '<h2>You Might Also Like</h2><div class="similar-grid">'
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json'
            }
            suggest_url = 'https://yts.lt/api/v2/movie_suggestions.json?movie_id=%s' % movie_id
            suggest_response = make_request_with_proxy(suggest_url, headers=headers, timeout=15)
            if suggest_response:
                suggest = suggest_response.json()
            else:
                suggest = {}
            for s in suggest.get('data', {}).get('movies', []):
                html += '<div class="similar-card"><a href="%s"><img src="%s" class="similar-poster"><div>%s<br><small>%.1f ★ | %s</small></div></a></div>' % (self.build_url('/movie?id=%d' % s['id']), s['medium_cover_image'], s['title'], self.safe_float(s.get('rating', 0)), s.get('year', ''))

            html += '</div></div></body></html>'
            return html.encode('utf-8')
        except Exception as e:
            return self.errorPage('Error: %s' % str(e))

    def getSeries(self, args):
        try:
            import urllib, random, json
            from collections import OrderedDict
            import requests
            from urllib.parse import quote_plus
            query = args.get('q', [None])[0]
            page = int(args.get('page', ['1'])[0])
            page = max(1, page)
            html_escape = lambda s: s.replace('&', '&amp;').replace('"', '&quot;').replace("'", '&#39;').replace('<', '&lt;').replace('>', '&gt;') if s else ''
            series = OrderedDict()
            actual_limit = 100
            if query:
                tmdb_url = 'https://api.themoviedb.org/3/search/tv?api_key=3c3efcf47c3577558812bb9d64019d65&query=%s' % quote_plus(query)
                tmdb_response = requests.get(tmdb_url, verify=False)
                tmdb_data = tmdb_response.json()
                if 'results' in tmdb_data and tmdb_data['results']:
                    tmdb_id = tmdb_data['results'][0].get('id')
                    if not tmdb_id:
                        return self.errorPage('TMDb ID not found for the series.')
                    imdb_id = self.getImdbIdFromTmdb(tmdb_id)
                    if not imdb_id:
                        return self.errorPage('IMDb ID not found from TMDb data.')
                    imdb_numeric = imdb_id[2:] if imdb_id.startswith('tt') else imdb_id
                    eztv_url = 'https://eztvx.to/api/get-torrents?imdb_id=%s&page=%d' % (imdb_numeric, page)
                else:
                    return self.errorPage('Series not found on TMDb.')
            else:
                eztv_url = 'https://eztvx.to/api/get-torrents?limit=%d&page=%d' % (actual_limit, page)
            r = requests.get(eztv_url, verify=False)
            data = r.json()
            torrents_count = data.get('torrents_count', 0)
            total_pages = (torrents_count + actual_limit - 1) // actual_limit
            for item in data.get('torrents', []):
                imdb_id = item.get('imdb_id')
                title = item.get('title')
                if imdb_id and imdb_id not in series:
                    if len(series) >= 50:
                        break
                    series[imdb_id] = title

            hero_imdb = None
            if series:
                hero_imdb = random.choice(list(series.keys()))
            hero_data = {}
            if hero_imdb:
                full_imdb = 'tt' + hero_imdb if not hero_imdb.startswith('tt') else hero_imdb
                hero_data = self.getSeriesFullInfo(full_imdb)
            hero_backdrop = hero_data.get('backdrop', 'https://image.tmdb.org/t/p/original/9yBVqNruk6Ykrwc32qrK2TIE5xw.jpg')
            hero_title = hero_data.get('title', 'TV Series')
            hero_overview = hero_data.get('overview', '')
            hero_series_list = []
            for imdb in series:
                full_imdb = (imdb.startswith('tt') or 'tt') + imdb if 1 else imdb
                series_info = self.getSeriesFullInfo(full_imdb)
                hero_series_list.append({'imdb': full_imdb,
                   'title': series[imdb],
                   'backdrop': series_info.get('backdrop', '')})

            hero_series_js = json.dumps(hero_series_list)
            escaped_query = html_escape(query or '')
            escaped_title = html_escape(hero_title)
            escaped_overview = html_escape(hero_overview)
            html = """<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Series</title><style>:root{--card-width:140px;--card-height:210px;--mobile-card-width:120px;--mobile-card-height:180px;}body{background:#141414;color:white;font-family:Arial,sans-serif;margin:0;overflow-x:hidden;}.navbar{display:flex;justify-content:space-between;align-items:center;padding:10px 20px;background-color:#111;position:sticky;top:0;z-index:1000;}.logo{color:#e50914;font-weight:bold;font-size:1.5em;text-decoration:none;}.search-form{display:flex;align-items:center;gap:10px;}.search-input{padding:8px 14px;border-radius:20px;border:none;background:#222;color:white;width:220px;}.search-button{padding:8px 16px;border:none;border-radius:20px;background:#e50914;color:white;cursor:pointer;white-space:nowrap;}.hero{height:50vh;background:linear-gradient(to top,rgba(20,20,20,1),rgba(20,20,20,0.4)),url('%s') center/cover no-repeat;display:flex;align-items:flex-end;padding:20px;transition:background-image 1s ease-in-out;}.hero-content{max-width:60%%;padding-bottom:20px;}.hero-title{font-size:2.5em;font-weight:bold;margin-bottom:10px;text-shadow:2px 2px 4px rgba(0,0,0,0.7);}.hero-overview{font-size:1em;color:#ccc;max-height:4.5em;overflow:hidden;text-overflow:ellipsis;text-shadow:1px 1px 2px rgba(0,0,0,0.7);}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(var(--card-width),1fr));gap:15px;padding:20px;}.card{background:#181818;border-radius:8px;overflow:hidden;transition:transform 0.3s,box-shadow 0.3s;box-shadow:0 4px 8px rgba(0,0,0,0.3);}.card:hover{transform:scale(1.05);z-index:2;box-shadow:0 10px 20px rgba(0,0,0,0.6);}.poster-container{position:relative;width:100%%;padding-top:150%%;}.poster-container img{position:absolute;top:0;left:0;width:100%%;height:100%%;object-fit:cover;}.card-title{padding:10px;text-align:center;font-size:0.9em;color:#ccc;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;height:2.5em;line-height:1.25em;display:flex;align-items:center;justify-content:center;}.pagination{text-align:center;padding:20px;display:flex;justify-content:center;gap:15px;}.pagination a{color:#e50914;text-decoration:none;font-size:1.1em;padding:8px 15px;border-radius:5px;background:rgba(255,255,255,0.1);transition:background 0.3s;}.pagination a:hover{background:rgba(229,9,20,0.7);}#spinner{position:fixed;top:50%%;left:50%%;transform:translate(-50%%,-50%%);border:6px solid #f3f3f3;border-top:6px solid #e50914;border-radius:50%%;width:50px;height:50px;animation:spin 1s linear infinite;z-index:9999;}@keyframes spin{0%%{transform:rotate(0deg);}100%%{transform:rotate(360deg);}}body.loaded #spinner{display:none;}@media(max-width:768px){.grid{grid-template-columns:repeat(auto-fill,minmax(var(--mobile-card-width),1fr));}.hero{height:40vh;}.hero-content{max-width:90%%;padding-bottom:15px;}.hero-title{font-size:1.8em;}.hero-overview{font-size:0.9em;max-height:6em;}.search-form{flex-direction:column;gap:8px;}.search-input{width:100%%;max-width:220px;}.pagination{flex-wrap:wrap;}}@media(max-width:480px){.grid{grid-template-columns:repeat(auto-fill,minmax(100px,1fr));}.hero{height:35vh;}.navbar{flex-direction:column;gap:10px;padding:10px;}.logo{font-size:1.3em;}}</style></head><body><div id="spinner"></div><nav class="navbar"><a href="/" class="logo">Transmission By Ostende</a><form class="search-form" method="GET" action="/series" onsubmit="showSpinner()"><input type="text" name="q" class="search-input" placeholder="🔍 Search series..." value="%s" autocomplete="off" /><button type="submit" class="search-button">Go</button></form></nav><div class='hero' id="hero"><div class='hero-content'><div class='hero-title' id="hero-title">%s</div><div class='hero-overview' id="hero-overview">%s</div></div></div><div class='grid'>""" % (hero_backdrop, escaped_query, escaped_title, escaped_overview)
            for imdb in series:
                full_imdb = (imdb.startswith('tt') or 'tt') + imdb if 1 else imdb
                tmdb_data = self.getSeriesFullInfo(full_imdb)
                poster = tmdb_data.get('poster', 'https://via.placeholder.com/300x450?text=No+Poster')
                title_safe = html_escape(series[imdb])
                html += "<div class='card'><a href='serie?id=%s'><div class='poster-container'><img src='%s' alt='%s' loading='lazy'></div><div class='card-title' title='%s'>%s</div></a></div>" % (imdb, poster, title_safe, title_safe, title_safe)

            html += '</div><div class="pagination">'
            if page > 1:
                html += '<a href="/series?page=%d">⬅️ Prev</a>' % (page - 1)
            if page < total_pages:
                html += '<a href="/series?page=%d">Next ➡️</a>' % (page + 1)
            html += '</div><script>window.addEventListener("load",function(){document.body.classList.add("loaded");});function showSpinner(){document.getElementById("spinner").style.display="block";}var heroData=%s;var currentHeroIndex=0;function updateHero(){if(heroData.length===0)return;currentHeroIndex=(currentHeroIndex+1)%%heroData.length;var hero=heroData[currentHeroIndex];var heroDiv=document.getElementById("hero");var heroTitle=document.getElementById("hero-title");var heroOverview=document.getElementById("hero-overview");if(hero.backdrop){heroDiv.style.backgroundImage="linear-gradient(to top, rgba(20,20,20,1), rgba(20,20,20,0.4)), url(\'"+hero.backdrop+"\')";}heroTitle.textContent=hero.title;heroOverview.textContent=hero.overview||"";}setInterval(updateHero,10000);</script></body></html>' % hero_series_js
            return html.encode('utf-8')
        except Exception as e:
            return self.errorPage('Error: %s' % str(e))

        return

    def getImdbIdFromTmdb(self, tmdb_id):
        try:
            url = 'https://api.themoviedb.org/3/tv/%s/external_ids?api_key=3c3efcf47c3577558812bb9d64019d65' % tmdb_id
            r = requests.get(url, verify=False)
            data = r.json()
            return data.get('imdb_id')
        except Exception as e:
            print (
             'Error fetching IMDb ID:', e)
            return

        return

    def getSeriesFullInfo(self, imdb_id):
        try:
            TMDB_API_KEY = '3c3efcf47c3577558812bb9d64019d65'
            url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % (imdb_id, TMDB_API_KEY)
            response = requests.get(url, verify=False, timeout=5)
            data = response.json()
            result = {'backdrop': '', 'poster': ''}
            media_data = None
            if data.get('tv_results'):
                media_data = data['tv_results'][0]
            elif data.get('movie_results'):
                media_data = data['movie_results'][0]
            if media_data:
                result.update({'title': media_data.get('title') or media_data.get('name', ''),
                   'overview': media_data.get('overview', ''),
                   'year': (media_data.get('release_date') or media_data.get('first_air_date', ''))[:4],
                   'rating': '%.1f' % media_data.get('vote_average', 0),
                   'seasons': media_data.get('number_of_seasons', 0),
                   'backdrop': 'https://image.tmdb.org/t/p/original%s' % media_data.get('backdrop_path', '') if media_data.get('backdrop_path') else '',
                   'poster': 'https://image.tmdb.org/t/p/w500%s' % media_data.get('poster_path', '') if media_data.get('poster_path') else ''})
            return result
        except Exception as e:
            print( 'Series info error: %s' % str(e))
            return {}

        return

    def webtorPage(self, magnet, title, poster='', movie_id=None):
        import html
        import json
        from urllib.parse import unquote_plus
        magnet = unquote_plus(magnet)
        title = unquote_plus(title)
        poster = unquote_plus(poster) if poster else ''

        # Use json.dumps for safe JavaScript string embedding
        magnet_js = json.dumps(magnet)
        title_js = json.dumps(title)
        poster_js = json.dumps(poster)

        back_link = '/movie?id=%s' % movie_id if movie_id else 'javascript:history.back()'

        html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TorrServer Web Player</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #0a0a18;
            color: #fff;
            font-family: 'Montserrat', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            overflow: hidden;
        }
        .back-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            z-index: 100;
            background: rgba(0, 0, 0, 0.6);
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .back-btn:hover {
            background: #e50914;
            border-color: #e50914;
        }
        #player-container {
            width: 100%%;
            height: 100%%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #000;
            position: relative;
        }
        video {
            width: 100%%;
            height: 100%%;
            max-height: 80vh;
            background: #000;
        }
        .loading {
            position: absolute;
            top: 50%%;
            left: 50%%;
            transform: translate(-50%%, -50%%);
            text-align: center;
            z-index: 10;
        }
        .spinner {
            border: 4px solid rgba(255, 255, 255, 0.1);
            border-left-color: #00e5ff;
            border-radius: 50%%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        @keyframes spin {
            0%% { transform: rotate(0deg); }
            100%% { transform: rotate(360deg); }
        }
        .status-text {
            font-size: 1.2rem;
            color: #00e5ff;
            text-shadow: 0 0 10px rgba(0, 229, 255, 0.5);
        }
        .error-msg {
            color: #ff4444;
            display: none;
        }
        .external-players {
            margin-top: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
            padding: 10px;
            background: rgba(20, 20, 20, 0.8);
            border-radius: 10px;
        }
        .btn-player {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }
        .btn-player:hover {
            background: rgba(0, 229, 255, 0.2);
            border-color: #00e5ff;
            transform: translateY(-2px);
        }
        .info-text {
            color: #888;
            font-size: 0.8rem;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <a href="%s" class="back-btn"><i class="fas fa-arrow-left"></i> Back</a>

    <div id="player-container">
        <div id="loading" class="loading">
            <div class="spinner"></div>
            <div class="status-text" id="status">Connecting to TorrServer...</div>
            <div class="error-msg" id="error"></div>
        </div>
        <video id="videoPlayer" controls playsinline poster=%s style="display:none;"></video>

        <div id="controls" style="display:none; width: 100%%; text-align:center;">
            <div class="external-players">
                <a href="#" id="vlcBtn" class="btn-player"><i class="fas fa-cone"></i> VLC</a>
                <a href="#" id="mxBtn" class="btn-player"><i class="fas fa-play-circle"></i> MX Player</a>
                <a href="#" id="infuseBtn" class="btn-player"><i class="fas fa-film"></i> Infuse</a>
                <button onclick="copyLink()" class="btn-player"><i class="fas fa-link"></i> Copy Link</button>
            </div>
            <p class="info-text">Use external players for multi-audio support.</p>
        </div>
    </div>

    <script>
        const magnet = %s;
        const title = %s;
        const torrServerPort = 8090;
        const host = window.location.hostname;
        const baseUrl = `http://${host}:${torrServerPort}`;
        let streamUrl = '';

        const statusEl = document.getElementById('status');
        const errorEl = document.getElementById('error');
        const loadingEl = document.getElementById('loading');
        const videoEl = document.getElementById('videoPlayer');

        function updateStatus(msg) {
            statusEl.textContent = msg;
        }

        function showError(msg) {
            document.querySelector('.spinner').style.display = 'none';
            statusEl.style.display = 'none';
            errorEl.textContent = msg;
            errorEl.style.display = 'block';
        }

        // SRT to WebVTT Converter
        function srt2webvtt(data) {
            var srt = data.replace(/\\r+/g, '');
            srt = srt.replace(/^\\s+|\\s+$/g, '');
            var cuelist = srt.split('\\n\\n');
            var result = "WEBVTT\\n\\n";
            if (cuelist.length > 0) {
                for (var i = 0; i < cuelist.length; i = i + 1) {
                    result += convertSrtCue(cuelist[i]);
                }
            }
            return result;
        }

        function convertSrtCue(caption) {
            var cue = "";
            var s = caption.split(/\\n/);
            while (s.length > 3) {
                for (var i = 3; i < s.length; i++) {
                    s[2] += "\\n" + s[i]
                }
                s.splice(3, s.length - 3);
            }
            var line = 0;
            if (!s[0].match(/\\d+:\\d+:\\d+/) && s[1].match(/\\d+:\\d+:\\d+/)) {
                line = 1;
            }
            if (s[line].match(/\\d+:\\d+:\\d+/)) {
                var m = s[1].match(/(\\d+):(\\d+):(\\d+)(?:,(\\d+))?\\s*--?>\\s*(\\d+):(\\d+):(\\d+)(?:,(\\d+))?/);
                if (m) {
                    cue += m[1] + ":" + m[2] + ":" + m[3] + "." + m[4] + " --> " + m[5] + ":" + m[6] + ":" + m[7] + "." + m[8] + "\\n";
                    line += 1;
                } else {
                    return "";
                }
            } else {
                return "";
            }
            if (s[line]) {
                cue += s[line] + "\\n\\n";
            }
            return cue;
        }

        async function resolveTorrent() {
            try {
                updateStatus('Resolving magnet link...');
                const statUrl = `${baseUrl}/stream/fname?link=${encodeURIComponent(magnet)}&stat`;

                let attempts = 0;
                const maxAttempts = 30;

                while (attempts < maxAttempts) {
                    try {
                        const response = await fetch(statUrl);
                        if (response.ok) {
                            const data = await response.json();
                            if (data.file_stats && data.file_stats.length > 0) {
                                return data.file_stats;
                            }
                        }
                    } catch (e) {
                        console.log('Waiting for TorrServer...');
                    }
                    attempts++;
                    await new Promise(r => setTimeout(r, 1000));
                }
                throw new Error('Timeout resolving torrent metadata');
            } catch (e) {
                throw e;
            }
        }

        function findMainFile(files) {
            return files.reduce((prev, current) => (prev.length > current.length) ? prev : current);
        }

        async function loadSubtitles(files) {
            const subtitleFiles = files.filter(f => f.path.toLowerCase().endsWith('.srt') || f.path.toLowerCase().endsWith('.vtt'));

            if (subtitleFiles.length > 0) {
                updateStatus(`Found ${subtitleFiles.length} subtitle(s). Loading...`);
            }

            for (const file of subtitleFiles) {
                try {
                    const subUrl = `${baseUrl}/stream/${encodeURIComponent(file.path)}?link=${encodeURIComponent(magnet)}&index=${file.id}&play`;

                    const response = await fetch(subUrl);
                    let text = await response.text();

                    if (file.path.toLowerCase().endsWith('.srt')) {
                        text = srt2webvtt(text);
                    }

                    const blob = new Blob([text], { type: 'text/vtt' });
                    const blobUrl = URL.createObjectURL(blob);

                    const track = document.createElement('track');
                    track.kind = 'subtitles';
                    track.label = file.path.split('/').pop();
                    track.src = blobUrl;

                    videoEl.appendChild(track);
                    console.log('Loaded subtitle:', file.path);

                } catch (e) {
                    console.error('Error loading subtitle:', file.path, e);
                }
            }
        }

        function setupExternalPlayers(url) {
            document.getElementById('vlcBtn').href = `vlc://${url}`;

            const mxIntent = `intent:${url}#Intent;package=com.mxtech.videoplayer.ad;S.title=${encodeURIComponent(title)};end`;
            document.getElementById('mxBtn').href = mxIntent;

            document.getElementById('infuseBtn').href = `infuse://x-callback-url/play?url=${encodeURIComponent(url)}`;

            document.getElementById('controls').style.display = 'block';
        }

        function copyLink() {
            navigator.clipboard.writeText(streamUrl).then(() => {
                alert('Stream URL copied to clipboard!');
            });
        }

        async function init() {
            try {
                const files = await resolveTorrent();
                updateStatus('Metadata loaded. Starting stream...');

                const mainFile = findMainFile(files);
                const fileIndex = mainFile.id;

                streamUrl = `${baseUrl}/stream/${encodeURIComponent(mainFile.path)}?link=${encodeURIComponent(magnet)}&index=${fileIndex}&play`;

                console.log('Stream URL:', streamUrl);

                setupExternalPlayers(streamUrl);

                videoEl.src = streamUrl;
                videoEl.style.display = 'block';
                loadingEl.style.display = 'none';

                // Load subtitles in background
                loadSubtitles(files).then(() => {
                    console.log('Subtitle loading complete');
                });

                videoEl.play().catch(e => {
                    console.log('Autoplay prevented:', e);
                });

            } catch (e) {
                console.error(e);
                showError('Error: ' + e.message + '. Make sure TorrServer is running on port ' + torrServerPort);
            }
        }

        window.copyLink = copyLink;
        init();
    </script>
</body>
</html>
""" % (back_link, poster_js, magnet_js, title_js)
        return html_content.encode('utf-8')

    def addFavorite(self, args):
        try:
            import json
            import os
            from urllib.parse import unquote_plus

            movie_id = args.get('id', [''])[0]
            title = unquote_plus(args.get('title', [''])[0])
            poster = unquote_plus(args.get('poster', [''])[0])
            year = args.get('year', [''])[0]
            rating = args.get('rating', [''])[0]

            if not movie_id or not title:
                return self.errorPage('Missing movie details')

            fav_file = '/etc/enigma2/favorites_movies.json'

            if not os.path.exists(fav_file):
                with open(fav_file, 'w') as f:
                    json.dump([], f)

            with open(fav_file, 'r') as f:
                try:
                    favorites = json.load(f)
                except:
                    favorites = []

            # Check if already exists
            exists = False
            for movie in favorites:
                if str(movie.get('id')) == str(movie_id):
                    exists = True
                    break

            if not exists:
                new_movie = {
                    'id': int(movie_id) if movie_id.isdigit() else movie_id,
                    'title': title,
                    'medium_cover_image': poster,
                    'year': int(year) if year.isdigit() else year,
                    'rating': float(rating) if rating.replace('.','',1).isdigit() else rating,
                    'torrents': [] # We don't have torrents here, but that's okay for listing
                }
                favorites.append(new_movie)

                with open(fav_file, 'w') as f:
                    json.dump(favorites, f, indent=4)

                msg = "Movie added to favorites successfully!"
            else:
                msg = "Movie is already in favorites!"

            html = """
            <html><head><meta http-equiv="refresh" content="3;url=/movie?id=%s" /><style>body{background:#141414;color:white;font-family:sans-serif;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}.msg{background:#222;padding:20px;border-radius:10px;text-align:center;box-shadow:0 0 20px rgba(0,0,0,0.5);}h2{color:#00e5ff;}</style></head><body><div class="msg"><h2>%s</h2><p>Redirecting back to movie details...</p></div></body></html>
            """ % (movie_id, msg)
            return html.encode('utf-8')

        except Exception as e:
             return self.errorPage('Error adding favorite: %s' % str(e))

    def handle_config_request(self, request):
        from Components.config import config
        config.plugins.torreplayer.load()
        saved = False
        if request.method == b'POST':
            from urllib.parse import parse_qs, unquote_plus
            length = int(request.getHeader(b'Content-Length') or 0)
            data = request.content.read(length)
            # Decode bytes to string
            data_str = data.decode('utf-8') if isinstance(data, bytes) else data
            # Parse URL-encoded form data
            postvars = parse_qs(data_str, keep_blank_values=True)
            # parse_qs returns lists, so we need to extract first value
            postvars = {k: v[0] if v else '' for k, v in postvars.items()}

            def get(name, default=''):
                return unquote_plus(postvars.get(name, default))

            def is_checked(name):
                return name in postvars

            config.plugins.torreplayer.autostart.value = is_checked('autostart')
            config.plugins.torreplayer.show_in_menu.value = is_checked('show_in_menu')
            config.plugins.torreplayer.items.value = get('items')
            config.plugins.torreplayer.skins.value = get('skins')
            config.plugins.torreplayer.skins_tv.value = get('skins_tv')
            config.plugins.torreplayer.vod_screen.value = get('vod_screen')
            config.plugins.torreplayer.onMovieEof.value = get('onMovieEof')
            config.plugins.torreplayer.onMovieStop.value = get('onMovieStop')
            config.plugins.torreplayer.poster_path.value = get('poster_path')
            config.plugins.torreplayer.tmdblng.value = get('tmdblng')
            config.plugins.torreplayer.subslng.value = get('subslng')
            config.plugins.torreplayer.subdl_api.value = get('subdl_api')
            config.plugins.torreplayer.serv_url.value = get('serv_url')
            config.plugins.torreplayer.player.value = get('player')
            config.plugins.torreplayer.buffer.value = get('buffer')
            config.plugins.torreplayer.preload_buffer.value = get('preload_buffer')
            config.plugins.torreplayer.download_rate_limit.value = int(get('download_rate_limit', '0'))
            config.plugins.torreplayer.upload_rate_limit.value = int(get('upload_rate_limit', '0'))
            config.plugins.torreplayer.connections_limit.value = int(get('connections_limit', '200'))
            config.plugins.torreplayer.cache_size.value = int(get('cache_size', '64'))
            config.plugins.torreplayer.reader_read_ahead.value = int(get('reader_read_ahead', '8'))
            config.plugins.torreplayer.use_disk.value = is_checked('use_disk')
            config.plugins.torreplayer.remove_cache.value = is_checked('remove_cache')
            config.plugins.torreplayer.rememberlastsearch.value = is_checked('rememberlastsearch')
            config.plugins.torreplayer.rememberlastsearchyts.value = is_checked('rememberlastsearchyts')
            config.plugins.torreplayer.rememberlastsearchyts_tv.value = is_checked('rememberlastsearchyts_tv')
            config.plugins.torreplayer.save()
            saved = True
        config.plugins.torreplayer.load()

        def render_options(choices, selected):
            options = []
            for choice in choices:
                if isinstance(choice, (tuple, list)) and len(choice) == 2:
                    k, v = choice
                else:
                    k = v = choice
                selected_attr = 'selected="selected"' if k == selected else ''
                options.append(('<option value="{0}" {1}>{2}</option>').format(k, selected_attr, v))

            return ('\n').join(options)

        message = "<p style='color:#0f0;'>✅ Settings saved successfully!</p>" if saved else ''
        html = ('<!DOCTYPE html><html><head><meta charset="UTF-8">\n        <title>Transmission Config</title>\n        <style>\n            body {{ background:#111; color:#eee; font-family:sans-serif; padding:20px }}\n            input, select {{ padding:5px; background:#222; color:#eee; border:1px solid #444 }}\n            label {{ display:block; margin-top:10px }}\n            input[type="submit"] {{ background:#0f0; color:#000; margin-top:20px }}\n            fieldset {{ margin-bottom:20px; border:1px solid #333; padding:10px; border-radius:8px }}\n            legend {{ color:#0f0; font-weight:bold }}\n            a {{ color:#0f0; text-decoration:none }}\n        </style>\n    </head><body>\n    <h1>⚙️ Transmission Web Config</h1>\n    {message}\n    <form method="POST">\n\n    <fieldset><legend>🔧 General Settings</legend>\n        <label><input type="checkbox" name="autostart" {autostart}/> Autostart</label>\n        <label><input type="checkbox" name="show_in_menu" {show_in_menu}/> Show in Main Menu</label>\n        <label>Items per page:\n            <select name="items">{items}</select>\n        </label>\n    </fieldset>\n\n    <fieldset><legend>🎨 Appearance</legend>\n        <label>Movie Skin:\n            <select name="skins">{skins}</select>\n        </label>\n        <label>TV Skin:\n            <select name="skins_tv">{skins_tv}</select>\n        </label>\n    </fieldset>\n\n    <fieldset><legend>📺 Behavior</legend>\n        <label>VOD Screen:\n            <select name="vod_screen">{vod_screen}</select>\n        </label>\n        <label>On Movie End:\n            <select name="onMovieEof">{onMovieEof}</select>\n        </label>\n        <label>On Movie Stop:\n            <select name="onMovieStop">{onMovieStop}</select>\n        </label>\n    </fieldset>\n\n    <fieldset><legend>🗂️ Poster & Subtitles</legend>\n        <label>Poster Path:\n            <input type="text" name="poster_path" value="{poster_path}"/>\n        </label>\n        <label>TMDb Language:\n            <select name="tmdblng">{tmdblng}</select>\n        </label>\n        <label>Subtitle Language:\n            <select name="subslng">{subslng}</select>\n        </label>\n        <label>SubDL API:\n            <input type="text" name="subdl_api" value="{subdl_api}"/>\n        </label>\n    </fieldset>\n\n    <fieldset><legend>🌐 Network & Playback</legend>\n        <label>Server URL:\n            <input type="text" name="serv_url" value="{serv_url}"/>\n        </label>\n        <label>Player:\n            <select name="player">{player}</select>\n        </label>\n        <label>Buffer Mode:\n            <select name="buffer">{buffer}</select>\n        </label>\n        <label>Preload Buffer (%):\n            <input type="text" name="preload_buffer" value="{preload_buffer}"/>\n        </label>\n        <label>Download Rate Limit (KB/s):\n            <input type="text" name="download_rate_limit" value="{download_rate_limit}"/>\n        </label>\n        <label>Upload Rate Limit (KB/s):\n            <input type="text" name="upload_rate_limit" value="{upload_rate_limit}"/>\n        </label>\n        <label>Connections Limit:\n            <input type="text" name="connections_limit" value="{connections_limit}"/>\n        </label>\n        <label>Cache Size (MB):\n            <input type="text" name="cache_size" value="{cache_size}"/>\n        </label>\n        <label>Reader Read Ahead (MB):\n            <input type="text" name="reader_read_ahead" value="{reader_read_ahead}"/>\n        </label>\n        <label><input type="checkbox" name="use_disk" {use_disk}/> Use Disk</label>\n        <label><input type="checkbox" name="remove_cache" {remove_cache}/> Remove Cache</label>\n    </fieldset>\n\n    <fieldset><legend>🔁 Memory</legend>\n        <label><input type="checkbox" name="rememberlastsearch" {rememberlastsearch}/> Remember Last Search</label>\n        <label><input type="checkbox" name="rememberlastsearchyts" {rememberlastsearchyts}/> Remember YTS Search</label>\n        <label><input type="checkbox" name="rememberlastsearchyts_tv" {rememberlastsearchyts_tv}/> Remember TV Search</label>\n    </fieldset>\n\n    <input type="submit" value="💾 Save Config"/>\n    </form>\n    <br/><a href="/">🏠 Back to Home</a>\n    </body></html>').format(message=message, autostart='checked' if config.plugins.torreplayer.autostart.value else '', show_in_menu='checked' if config.plugins.torreplayer.show_in_menu.value else '', items=render_options(config.plugins.torreplayer.items.choices, config.plugins.torreplayer.items.value), skins=render_options(config.plugins.torreplayer.skins.choices, config.plugins.torreplayer.skins.value), skins_tv=render_options(config.plugins.torreplayer.skins_tv.choices, config.plugins.torreplayer.skins_tv.value), vod_screen=render_options(config.plugins.torreplayer.vod_screen.choices, config.plugins.torreplayer.vod_screen.value), onMovieEof=render_options(config.plugins.torreplayer.onMovieEof.choices, config.plugins.torreplayer.onMovieEof.value), onMovieStop=render_options(config.plugins.torreplayer.onMovieStop.choices, config.plugins.torreplayer.onMovieStop.value), poster_path=config.plugins.torreplayer.poster_path.value, tmdblng=render_options(config.plugins.torreplayer.tmdblng.choices, config.plugins.torreplayer.tmdblng.value), subslng=render_options(config.plugins.torreplayer.subslng.choices, config.plugins.torreplayer.subslng.value), subdl_api=config.plugins.torreplayer.subdl_api.value, serv_url=config.plugins.torreplayer.serv_url.value, player=render_options(config.plugins.torreplayer.player.choices, config.plugins.torreplayer.player.value), buffer=render_options(config.plugins.torreplayer.buffer.choices, config.plugins.torreplayer.buffer.value), preload_buffer=config.plugins.torreplayer.preload_buffer.value, download_rate_limit=config.plugins.torreplayer.download_rate_limit.value, upload_rate_limit=config.plugins.torreplayer.upload_rate_limit.value, connections_limit=config.plugins.torreplayer.connections_limit.value, cache_size=config.plugins.torreplayer.cache_size.value, reader_read_ahead=config.plugins.torreplayer.reader_read_ahead.value, use_disk='checked' if config.plugins.torreplayer.use_disk.value else '', remove_cache='checked' if config.plugins.torreplayer.remove_cache.value else '', rememberlastsearch='checked' if config.plugins.torreplayer.rememberlastsearch.value else '', rememberlastsearchyts='checked' if config.plugins.torreplayer.rememberlastsearchyts.value else '', rememberlastsearchyts_tv='checked' if config.plugins.torreplayer.rememberlastsearchyts_tv.value else '')
        request.setResponseCode(200)
        request.setHeader('Content-type', 'text/html')
        return html.encode('utf-8')

    def getSerieDetails(self, imdb_id):
        try:
            import urllib
            from urllib.parse import quote_plus
            TMDB_API_KEY = '3c3efcf47c3577558812bb9d64019d65'
            imdb_id2 = (imdb_id.startswith('tt') or 'tt%s') % imdb_id if 1 else imdb_id
            eps_url = 'https://eztvx.to/api/get-torrents?imdb_id=%s' % imdb_id
            eps_response = make_request_with_proxy(eps_url, timeout=15)
            if eps_response:
                eps = eps_response.json().get('torrents', [])
            else:
                eps = []
            tmdb_data = self.getSeriesFullInfo(imdb_id2)
            tmdb_id = None
            if tmdb_data:
                tmdb_url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % (imdb_id2, TMDB_API_KEY)
                tmdb_find = requests.get(tmdb_url, verify=False).json()
                if tmdb_find.get('tv_results'):
                    tmdb_id = tmdb_find['tv_results'][0]['id']
                    cast_url = 'https://api.themoviedb.org/3/tv/%s/credits?api_key=%s' % (tmdb_id, TMDB_API_KEY)
                    cast_data = requests.get(cast_url, verify=False).json()
                    tmdb_cast = cast_data.get('cast', [])[:6]
                    videos_url = 'https://api.themoviedb.org/3/tv/%s/videos?api_key=%s' % (tmdb_id, TMDB_API_KEY)
                    videos = requests.get(videos_url, verify=False).json().get('results', [])
                    tmdb_trailer = ''
                    for v in videos:
                        if v.get('type') == 'Trailer' and v.get('site') == 'YouTube':
                            tmdb_trailer = 'https://www.youtube.com/embed/%s' % v['key']
                            break

                else:
                    tmdb_cast = []
                    tmdb_trailer = ''
            else:
                tmdb_cast = []
                tmdb_trailer = ''
            backdrop = tmdb_data.get('backdrop', '')
            poster = tmdb_data.get('poster', 'https://via.placeholder.com/300x450?text=No+Poster')
            title = tmdb_data.get('title', 'Series')
            year = tmdb_data.get('year', '')
            rating = tmdb_data.get('rating', '')
            seasons = tmdb_data.get('seasons', '')
            overview = tmdb_data.get('overview', '')
            html = """<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>%s - Transmission</title><style>body{background:#141414;color:white;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;margin:0;padding:0;}.series-header{background:linear-gradient(to top,#141414 0%%,transparent 50%%),url('%s') center/cover no-repeat;height:60vh;display:flex;align-items:flex-end;padding:0 5%% 8%%;box-shadow:inset 0 -50px 50px -10px #141414;}.series-content{max-width:1200px;margin:0 auto;padding:30px 5%%;}.series-poster{width:100%%;max-width:300px;aspect-ratio:2/3;object-fit:cover;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,0.5);margin:20px auto;display:block;}.series-title{font-size:2.8rem;text-align:center;margin:20px 0 10px;}.series-meta{text-align:center;margin-bottom:20px;}.series-meta span{display:inline-block;margin:0 10px;color:#46d369;font-size:1.1rem;}.series-description{text-align:center;font-size:1.1rem;max-width:800px;margin:0 auto 30px;line-height:1.6;}.cast-grid{display:flex;gap:15px;justify-content:center;margin:30px 0;flex-wrap:wrap;}.cast-card{background:#181818;padding:10px;border-radius:8px;text-align:center;width:120px;}.cast-card img{width:100%%;border-radius:5px;object-fit:cover;}.episodes-container{display:grid;grid-template-columns:repeat(auto-fill,minmax(350px,1fr));gap:25px;margin-bottom:50px;}.episode-card{background:#181818;padding:20px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);transition:transform 0.3s,box-shadow 0.3s;}.episode-card:hover{transform:translateY(-5px);box-shadow:0 10px 25px rgba(0,0,0,0.5);}.episode-buttons{display:flex;gap:12px;flex-wrap:wrap;margin-top:15px;}.btn{flex:1;padding:10px;border-radius:5px;text-align:center;text-decoration:none;font-weight:bold;transition:0.3s;display:inline-block;}.btn-primary{background:#e50914;color:white;}.btn-secondary{background:rgba(255,255,255,0.15);color:white;}.btn-download{background:#1a73e8;color:white;margin-top:10px;display:block;}.btn-watchlist{background:#ffb300;color:black;margin-top:10px;display:block;}.similar-grid{display:flex;overflow-x:auto;gap:15px;padding:20px 0 40px;scroll-snap-type:x mandatory;}.similar-card{background:#181818;border-radius:8px;overflow:hidden;text-align:center;transition:transform 0.3s;min-width:200px;scroll-snap-align:start;}.similar-card:hover{transform:translateY(-5px);}.similar-card a{text-decoration:none;color:white;display:block;}.similar-poster{width:100%%;aspect-ratio:2/3;object-fit:cover;display:block;border-radius:8px;}iframe{display:block;margin:30px auto;max-width:100%%;border:none;border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,0.5);}.season-selector{text-align:center;margin:20px 0;}.season-btn{background:rgba(255,255,255,0.1);color:white;border:none;border-radius:20px;padding:8px 15px;margin:0 5px;cursor:pointer;transition:background 0.3s;}.season-btn.active{background:#e50914;}</style></head><body><div class="series-header"></div><div class="series-content"><img src="%s" class="series-poster" alt="%s"><h1 class="series-title">%s</h1><div class="series-meta"><span>📅 %s</span><span>⭐ %.1f</span><span>📺 %s Seasons</span></div><div class="series-description">%s</div>""" % (title, backdrop, poster, title, title, year, float(rating or 0), seasons, overview)
            if tmdb_trailer:
                html += '<iframe width="640" height="360" src="%s" allowfullscreen></iframe>' % tmdb_trailer
            if tmdb_cast:
                html += '<h2 style="text-align:center;">Cast</h2><div class="cast-grid">'
                for actor in tmdb_cast:
                    img = 'https://image.tmdb.org/t/p/w185%s' % actor['profile_path'] if actor.get('profile_path') else 'https://via.placeholder.com/185x278?text=No+Image'
                    html += '<div class="cast-card"><img src="%s"><div>%s</div><small>%s</small></div>' % (img, actor['name'], actor['character'] or 'Actor')
                html += '</div>'
            html += '<h2>Episodes</h2><div class="episodes-container">'
            for ep in eps:
                magnet = ep.get('magnet_url', '')
                title = ep.get('title', 'Episode')
                size = ep.get('size', 'N/A')
                magnet_quoted = quote_plus(magnet)
                title_quoted = quote_plus(title.encode('utf-8'))
                poster_quoted = quote_plus(poster.encode('utf-8'))
                html += '<div class="episode-card"><h3>%s</h3><p><strong>Size:</strong> %s</p><div class="episode-buttons"><a href="/play?magnet=%s&title=%s" class="btn btn-primary">▶ Play on Enigma2</a><a href="/webtor?magnet=%s&title=%s&poster=%s" target="_blank" class="btn btn-secondary">🌐 Play on Web</a></div><a href="/download?magnet=%s" class="btn btn-download">⬇ Download</a></div>' % (title, size, magnet_quoted, title_quoted, magnet_quoted, title_quoted, poster_quoted, magnet_quoted)

            html += '</div>'
            if tmdb_id:
                similar_url = 'https://api.themoviedb.org/3/tv/%s/similar?api_key=%s' % (tmdb_id, TMDB_API_KEY)
                similar_data = requests.get(similar_url, verify=False).json().get('results', [])[:10]
                if similar_data:
                    html += '<h2>You Might Also Like</h2><div class="similar-grid">'
                    for s in similar_data:
                        poster_path = s.get('poster_path')
                        poster_url = 'https://image.tmdb.org/t/p/w300%s' % poster_path if poster_path else 'https://via.placeholder.com/200x300?text=No+Poster'
                        title = s.get('name', '')
                        year = s.get('first_air_date', '')[:4] if s.get('first_air_date') else ''
                        rating = self.safe_float(s.get('vote_average', 0))
                        html += '<div class="similar-card"><a href="/serie?id=%s"><img src="%s" class="similar-poster"><div>%s<br><small>%.1f ★ | %s</small></div></a></div>' % (s.get('id', ''), poster_url, title, rating, year)
                    html += '</div>'
            html += '</div></div></body></html>'
            return html.encode('utf-8')
        except Exception as e:
            return self.errorPage('Error: %s' % str(e))

        return

    def getSeriesBackdrop(self, imdb_id):
        try:
            TMDB_API_KEY = '3c3efcf47c3577558812bb9d64019d65'
            url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % (imdb_id, TMDB_API_KEY)
            r = requests.get(url, verify=False, timeout=5)
            data = r.json()
            if 'tv_results' in data and data['tv_results']:
                item = data['tv_results'][0]
                backdrop = item.get('backdrop_path')
                if backdrop:
                    return 'https://image.tmdb.org/t/p/w780%s' % backdrop
            if 'movie_results' in data and data['movie_results']:
                item = data['movie_results'][0]
                backdrop = item.get('backdrop_path')
                if backdrop:
                    return 'https://image.tmdb.org/t/p/w780%s' % backdrop
        except Exception as e:
            print (
             'getSeriesBackdrop error:', str(e))

        return ''

    def buildMagnet(self, hash_code, title):
        trackers = [
         'udp://open.demonii.com:1337/announce',
         'udp://tracker.openbittorrent.com:80',
         'udp://tracker.opentrackr.org:1337/announce']
        return 'magnet:?xt=urn:btih:%s&dn=%s&%s' % (
         hash_code,
         title.replace(' ', '+'),
         ('&').join('tr=' + t for t in trackers))

    def playTorrent(self, args):
        try:
            magnet = args.get('magnet', [None])[0]
            title = args.get('title', ['Unknown'])[0]
            poster = args.get('poster', [''])[0]
            if not magnet:
                return self.errorPage('Missing magnet')
            self.session.open(TorrEpisodes, [title, magnet], poster)
            html_template = """<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Content Playing!</title><style>@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap');body{background:linear-gradient(135deg,#1a2a6c,#b21f1f,#fdbb2d);height:100vh;margin:0;display:flex;justify-content:center;align-items:center;font-family:'Poppins',sans-serif;overflow:hidden;color:white;text-align:center;}.container{background:rgba(0,0,0,0.7);border-radius:20px;padding:40px;max-width:90%%;width:600px;box-shadow:0 15px 35px rgba(0,0,0,0.5);backdrop-filter:blur(10px);position:relative;z-index:2;}h1{font-size:2.8rem;margin-bottom:20px;color:#4CAF50;text-shadow:0 0 10px rgba(76,175,80,0.5);}.title{font-size:1.8rem;margin:25px 0;padding:15px;background:rgba(255,255,255,0.1);border-radius:10px;border-left:4px solid #fdbb2d;}.message{font-size:1.3rem;margin:30px 0;line-height:1.6;}.popcorn-container{position:absolute;bottom:0;left:0;width:100%%;height:50px;overflow:hidden;z-index:1;}.popcorn{position:absolute;bottom:-50px;font-size:24px;animation:popcorn-fall 4s linear infinite;}@keyframes popcorn-fall{0%%{transform:translateY(0) rotate(0deg);opacity:0;}10%%{opacity:1;}90%%{opacity:1;}100%%{transform:translateY(-100vh) rotate(360deg);opacity:0;}}.tv-animation{width:200px;height:150px;margin:0 auto 30px;position:relative;background:#333;border-radius:15px;overflow:hidden;box-shadow:0 0 20px rgba(0,0,0,0.5);}.tv-screen{width:180px;height:110px;background:linear-gradient(45deg,#ff0080,#00ffff,#ff8c00,#00ff00);margin:10px auto;border-radius:5px;animation:screen-animation 6s infinite linear;position:relative;overflow:hidden;}@keyframes screen-animation{0%%{background-position:0%% 50%%;}50%%{background-position:100%% 50%%;}100%%{background-position:0%% 50%%;}}.tv-stand{width:60px;height:10px;background:#555;margin:0 auto;border-radius:3px;}.tv-base{width:100px;height:10px;background:#777;margin:0 auto;border-radius:5px;}.confetti{position:absolute;width:15px;height:15px;background:#ffd700;opacity:0.7;animation:confetti-fall 8s linear infinite;}@keyframes confetti-fall{0%%{transform:translateY(-100px) rotate(0deg);opacity:0;}10%%{opacity:1;}90%%{opacity:1;}100%%{transform:translateY(100vh) rotate(360deg);opacity:0;}}.countdown{font-size:1.5rem;margin-top:20px;font-weight:bold;color:#fdbb2d;}@media (max-width:600px){.container{padding:25px 15px;}h1{font-size:2.2rem;}.title{font-size:1.4rem;}}</style></head><body><div class="container"><div class="tv-animation"><div class="tv-screen"></div><div class="tv-stand"></div><div class="tv-base"></div></div><h1>✅ Success!</h1><div class="message">Your content is now playing on Dreambox</div><div class="title">%(title)s</div><div class="countdown">Returning to menu in <span id="count">10</span> seconds...</div></div><div class="popcorn-container" id="popcorn"></div><script>// Create popcorn animationfunction createPopcorn(){const container=document.getElementById('popcorn');const popcorn=document.createElement('div');popcorn.className='popcorn';popcorn.innerHTML='🍿';popcorn.style.left=Math.random()*100+'%%';popcorn.style.animationDuration=(Math.random()*3+2)+'s';container.appendChild(popcorn);setTimeout(()=>{popcorn.remove();},5000);}// Create confettifunction createConfetti(){const colors=['#ff0000','#00ff00','#0000ff','#ffff00','#ff00ff','#00ffff'];const confetti=document.createElement('div');confetti.className='confetti';confetti.style.backgroundColor=colors[Math.floor(Math.random()*colors.length)];confetti.style.left=Math.random()*100+'%%';confetti.style.animationDuration=(Math.random()*3+2)+'s';document.body.appendChild(confetti);setTimeout(()=>{confetti.remove();},5000);}// Create animationssetInterval(createPopcorn,200);setInterval(createConfetti,300);// Countdown timerlet count=10;const countElement=document.getElementById('count');const timer=setInterval(()=>{count--;countElement.textContent=count;if(count<=0){clearInterval(timer);window.history.back();}},1000);</script></body></html>"""
            import html
            safe_title = html.escape(title, quote=True)
            html = html_template % {'title': safe_title}
            return html.encode('utf-8')
        except Exception as e:
            return self.errorPage('Play failed: %s' % str(e))

        return

    def downloadTorrent(self, magnet):
        try:
            headers = {'X-Transmission-Session-Id': self.transmissionSessionId}
            url = 'http://127.0.0.1:9091/transmission/rpc'
            payload = {'method': 'torrent-add', 'arguments': {'filename': magnet}}
            r = requests.post(url, json=payload, headers=headers, timeout=5)
            if r.status_code == 409:
                self.transmissionSessionId = r.headers['X-Transmission-Session-Id']
                headers['X-Transmission-Session-Id'] = self.transmissionSessionId
                r = requests.post(url, json=payload, headers=headers, timeout=5)
            return ('<html><body><h1>✅ Download Started</h1></body></html>').encode('utf-8')
        except Exception as e:
            return self.errorPage(str(e))

    def errorPage(self, msg):
        return ("<html><body style='background:black;color:red;text-align:center;'><h1>Error</h1><p>%s</p></body></html>" % msg).encode('utf-8')


class TorrPlayResource(resource.Resource):

    def __init__(self, session):
        self.session = session
        print('[TorrWeb] Initialized TorrPlayResource')
        resource.Resource.__init__(self)

    def render_POST(self, req):
        print('[TorrWeb] Received POST to play')
        try:
            req.setResponseCode(http.OK)
            req.setHeader(b'Content-type', b'text/plain; charset=UTF-8')

            args = {k.decode('utf-8'): [v.decode('utf-8') for v in val] for k, val in req.args.items()}

            title = args.get('title', [None])[0]
            magnet = args.get('magnet', [None])[0]
            poster = args.get('poster', [''])[0]

            if not title or not magnet:
                return b'Missing title or magnet link'
            titles = [title, magnet]
            print('[TorrWeb] Launching TorrEpisodes with title:', title)

            reactor.callFromThread(self.session.open, TorrEpisodes, titles, poster)

            return ("OK: Playing '%s'" % title).encode('utf-8')
        except Exception as e:
            print('[TorrWeb] Exception:', str(e))
            return ('ERROR: %s' % str(e)).encode('utf-8')


def startWebServer(session):
    try:
        # Root is our TransmissionWebServer
        root = TransmissionWebServer(session)

        # Twisted Site
        site = server.Site(root)
        reactor.listenTCP(7878, site)
        print('[TransmissionWebServer] Started on port 7878')
    except Exception as e:
        print('[TransmissionWebServer] Failed to start:', e)
