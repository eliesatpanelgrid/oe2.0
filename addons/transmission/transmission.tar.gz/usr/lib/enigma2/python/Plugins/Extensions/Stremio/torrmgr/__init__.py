#!  /usr/bin/python
# coding: utf8
# author: zmej74, Vasiliks
from six import PY2, PY3
from six.moves.urllib.parse import urlencode, quote, unquote
from six.moves.urllib.request import urlretrieve, urlopen, Request
from six.moves.urllib.error import HTTPError, URLError

ENCODE_UTF8 = lambda x: x.encode("utf-8", "ignore") if PY2 else x
DECODE_UTF8 = lambda x: x.decode("utf-8", "ignore") if PY2 else x
