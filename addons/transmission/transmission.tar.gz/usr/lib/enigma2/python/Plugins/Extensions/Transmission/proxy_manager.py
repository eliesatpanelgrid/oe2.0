#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Proxy Manager for Transmission Plugin
Handles free proxy fetching, testing, and rotation for bypassing ISP blocks
"""
import requests
import time
import random
import logging
import threading
from six.moves.urllib.parse import urlparse, quote
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import ssl

logger = logging.getLogger('ProxyManager')
logger.setLevel(logging.INFO)

class ProxyManager:
    """Manages free proxies for bypassing ISP blocks"""
    
    def __init__(self):
        self.proxies = []
        self.working_proxies = []
        self.current_proxy_index = 0
        self.lock = threading.Lock()
        self.last_update = 0
        self.update_interval = 3600  # Update every hour
        self.test_timeout = 5
        
        # Free proxy API endpoints
        self.proxy_sources = [
            self._fetch_proxyscrape,
            self._fetch_proxylist,
            self._fetch_geonode,
            self._fetch_proxyspace,
        ]
        
        # CORS proxy services (URL-based, no IP:PORT needed)
        self.cors_proxies = [
            "https://api.codetabs.com/v1/proxy?quest=",
            "https://cors.eu.org/",
            "https://corsproxy.io/?",
            "https://cors-anywhere.herokuapp.com/",
            "https://api.allorigins.win/raw?url=",
        ]
        
    def _fetch_proxyscrape(self):
        """Fetch proxies from proxyscrape.com"""
        try:
            url = "https://api.proxyscrape.com/v2/?request=get&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all"
            response = requests.get(url, timeout=10, verify=False)
            if response.status_code == 200:
                proxies = []
                for line in response.text.strip().split('\n'):
                    line = line.strip()
                    if ':' in line and not line.startswith('#'):
                        proxies.append(line)
                return proxies
        except Exception as e:
            logger.debug("Error fetching proxyscrape: %s", str(e))
        return []
    
    def _fetch_proxylist(self):
        """Fetch proxies from proxy-list.download"""
        try:
            url = "https://www.proxy-list.download/api/v1/get?type=http"
            response = requests.get(url, timeout=10, verify=False)
            if response.status_code == 200:
                proxies = []
                for line in response.text.strip().split('\n'):
                    line = line.strip()
                    if ':' in line:
                        proxies.append(line)
                return proxies
        except Exception as e:
            logger.debug("Error fetching proxylist: %s", str(e))
        return []
    
    def _fetch_geonode(self):
        """Fetch proxies from geonode.com"""
        try:
            url = "https://proxylist.geonode.com/api/proxy-list?limit=50&page=1&sort_by=lastChecked&sort_type=desc&protocols=http%2Chttps"
            response = requests.get(url, timeout=10, verify=False)
            if response.status_code == 200:
                data = response.json()
                proxies = []
                for proxy in data.get('data', []):
                    ip = proxy.get('ip')
                    port = proxy.get('port')
                    if ip and port:
                        proxies.append(f"{ip}:{port}")
                return proxies
        except Exception as e:
            logger.debug("Error fetching geonode: %s", str(e))
        return []
    
    def _fetch_proxyspace(self):
        """Fetch proxies from proxyspace.pro"""
        try:
            url = "https://www.proxyspace.pro/api.php?action=list&protocol=http"
            response = requests.get(url, timeout=10, verify=False)
            if response.status_code == 200:
                proxies = []
                for line in response.text.strip().split('\n'):
                    line = line.strip()
                    if ':' in line:
                        proxies.append(line)
                return proxies[:50]  # Limit to 50
        except Exception as e:
            logger.debug("Error fetching proxyspace: %s", str(e))
        return []
    
    def fetch_proxies(self):
        """Fetch proxies from all sources"""
        all_proxies = []
        for source_func in self.proxy_sources:
            try:
                proxies = source_func()
                all_proxies.extend(proxies)
                logger.info("Fetched %d proxies from %s", len(proxies), source_func.__name__)
            except Exception as e:
                logger.debug("Error in %s: %s", source_func.__name__, str(e))
        
        # Remove duplicates
        self.proxies = list(set(all_proxies))
        logger.info("Total unique proxies fetched: %d", len(self.proxies))
        return len(self.proxies)
    
    def test_proxy(self, proxy):
        """Test if a proxy is working"""
        try:
            proxies_dict = {
                'http': f'http://{proxy}',
                'https': f'http://{proxy}'
            }
            # Test with a simple request
            response = requests.get(
                'https://httpbin.org/ip',
                proxies=proxies_dict,
                timeout=self.test_timeout,
                verify=False
            )
            if response.status_code == 200:
                return True
        except Exception:
            pass
        return False
    
    def test_proxies(self, max_tests=20):
        """Test proxies and keep only working ones"""
        if not self.proxies:
            self.fetch_proxies()
        
        working = []
        test_list = self.proxies[:max_tests] if len(self.proxies) > max_tests else self.proxies
        
        logger.info("Testing %d proxies...", len(test_list))
        for i, proxy in enumerate(test_list):
            if self.test_proxy(proxy):
                working.append(proxy)
                logger.info("Proxy %d/%d working: %s", i+1, len(test_list), proxy)
            if len(working) >= 10:  # Stop when we have enough working proxies
                break
        
        with self.lock:
            self.working_proxies = working
            logger.info("Found %d working proxies", len(working))
        
        return len(working)
    
    def get_proxy(self, use_cors=False):
        """Get a proxy (either IP:PORT or CORS URL)"""
        if use_cors:
            # Return a random CORS proxy URL
            return random.choice(self.cors_proxies)
        
        with self.lock:
            if not self.working_proxies:
                # If no working proxies, try to get some
                if time.time() - self.last_update > self.update_interval:
                    self.fetch_proxies()
                    self.test_proxies()
                    self.last_update = time.time()
                if not self.working_proxies:
                    return None
            
            # Round-robin through working proxies
            proxy = self.working_proxies[self.current_proxy_index]
            self.current_proxy_index = (self.current_proxy_index + 1) % len(self.working_proxies)
            return proxy
    
    def get_proxied_url(self, url, use_cors=True):
        """Get a proxied URL using CORS proxy"""
        if use_cors:
            cors_proxy = self.get_proxy(use_cors=True)
            if cors_proxy:
                return cors_proxy + quote(url, safe='')
        return url
    
    def get_proxy_dict(self, use_cors=False):
        """Get proxy dictionary for requests"""
        if use_cors:
            return None  # CORS proxies are URL-based
        
        proxy = self.get_proxy(use_cors=False)
        if proxy:
            return {
                'http': f'http://{proxy}',
                'https': f'http://{proxy}'
            }
        return None
    
    def mark_proxy_failed(self, proxy):
        """Mark a proxy as failed and remove it"""
        with self.lock:
            if proxy in self.working_proxies:
                self.working_proxies.remove(proxy)
                logger.warning("Removed failed proxy: %s", proxy)

# Global instance
_proxy_manager = None

def get_proxy_manager():
    """Get the global proxy manager instance"""
    global _proxy_manager
    if _proxy_manager is None:
        _proxy_manager = ProxyManager()
    return _proxy_manager

def make_proxied_request(url, headers=None, timeout=15, use_cors=True, max_retries=3, **kwargs):
    """
    Make a request with automatic proxy support
    Returns response or None on failure
    """
    proxy_manager = get_proxy_manager()
    
    if use_cors:
        # Use CORS proxy (URL-based, simpler)
        for attempt in range(max_retries):
            try:
                proxied_url = proxy_manager.get_proxied_url(url, use_cors=True)
                response = requests.get(
                    proxied_url,
                    headers=headers,
                    timeout=timeout,
                    verify=False,
                    **kwargs
                )
                if response.status_code == 200:
                    return response
            except Exception as e:
                logger.debug("CORS proxy attempt %d failed: %s", attempt + 1, str(e))
                if attempt < max_retries - 1:
                    time.sleep(1)
    else:
        # Use IP:PORT proxy
        for attempt in range(max_retries):
            try:
                proxy_dict = proxy_manager.get_proxy_dict(use_cors=False)
                if proxy_dict:
                    response = requests.get(
                        url,
                        headers=headers,
                        proxies=proxy_dict,
                        timeout=timeout,
                        verify=False,
                        **kwargs
                    )
                    if response.status_code == 200:
                        return response
                else:
                    # Fallback to direct connection
                    response = requests.get(
                        url,
                        headers=headers,
                        timeout=timeout,
                        verify=False,
                        **kwargs
                    )
                    return response
            except Exception as e:
                logger.debug("Proxy attempt %d failed: %s", attempt + 1, str(e))
                if attempt < max_retries - 1:
                    time.sleep(1)
    
    # Final fallback: direct connection
    try:
        logger.warning("All proxy attempts failed, trying direct connection")
        return requests.get(url, headers=headers, timeout=timeout, verify=False, **kwargs)
    except Exception as e:
        logger.error("Direct connection also failed: %s", str(e))
        return None

