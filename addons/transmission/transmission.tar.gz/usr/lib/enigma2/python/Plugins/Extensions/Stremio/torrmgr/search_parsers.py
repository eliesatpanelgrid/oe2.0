# -*- coding: UTF-8 -*-
# version: 25/03/2022
import re
from .urlrequest import request_url
from . import quote, unquote

def get_text_between(txt, s_delim, e_delim, s_position = 0):
    res = {"text":"", "position":-1}
    first = txt.find(s_delim, s_position)
    if first >= 0:
        first += len(s_delim)
        end = txt.find(e_delim, first)
        if end:
            res["text"] = txt[first:(end if end >= 0 else None)]
            res["position"] = end + len(e_delim)
    return res

def pretty_name(txt):
    retval = re.sub('(<.*?>)'," ",txt)
    retval = retval.replace("&quot;","'").replace('&nbsp;'," ")
    return retval.strip(" :")

class v_link(object):
    def __init__(self, key, value):
        self.key = key
        self.value = value
    @property
    def platform(self):
        return self.key
    @property
    def link(self):
        return self.value

class v_links(object):
    def __init__(self, links):
        self.links = links
        self.counter = 0
    def __iter__(self):
        self.counter = 0
        return self

    def item(self, index):
        return v_link(self.links.keys()[index], self.links.values()[index])

    def next(self):
        if self.counter < len(self.links):
            vl = self.item(self.counter)
            self.counter += 1
            return vl
        else:
            raise StopIteration

    __next__ = next

    def __getitem__(self, index):
        return v_link(self.item(index))
    def __len__(self):
        return len(self.links)
    def count(self):
        return len(self.links)
    def link_by_name(self, key):
        return v_link(key, self.links[key])


class t_info(object):
    def __init__(self, info, search_obj=None):
        self.info = info    #{"url":"", "date":'', "name":"", "size":"", "seeders":"", "leechers":"", "magnet":'', "file_url":""}
        self.detail_info = {"description":"", "year":"", "genres":"", "duration":"", "video":"","quality":""}
        self.search_obj = search_obj
    @property
    def detail_url(self):
        # ссылка на url с детальным описанием
        return self.info.get("url", "")
    @property
    def date(self):
        # дата публикации торрента
        return self.info.get("date", "")
    @property
    def name(self):
        # название/имя торрента
        return self.info.get("name", "")
    @property
    def size(self):
        # размер торрента - строка GB/MB
        return self.info.get("size", "")
    @property
    def magnet(self):
        # magnet ссылка на торрент
        return self.info.get("magnet", "")
    @property
    def file_url(self):
        # ссылка для загрузки файла .torrent
        return self.info.get("file_url", "")
    @property
    def seeders(self):
        # число раздающих - врет безбожно
        return self.info.get("seeders", "")
    @property
    def leechers(self):
        # число качающих
        return self.info.get("leechers", "")
    #detail information
    # детальная информация о торренте, доступная после выполнения метода load_detail_info()
    @property
    def description(self):
        # описание торрента
        return self.detail_info.get("description", "")
    @property
    def poster_url(self):
        # url картинки/постера, не везде есть!
        return self.detail_info.get("poster_url", "")
    @property
    def year(self):
        # год выхода фильма
        return self.detail_info.get("year", "")
    @property
    def genres(self):
        # жанры фильма - список строк
        return self.detail_info.get("genres", [])
    @property
    def duration(self):
        # продолжительность фильма - строка
        return self.detail_info.get("duration", "")
    @property
    def video(self):
        # параметры видео
        return self.detail_info.get("video", "")
    @property
    def quality(self):
        # инфо о качестве видео - невезде есть!
        return self.detail_info.get("quality", "")
    def load_detail_info(self):
        return (self.search_obj.load_detail_info(self) if self.search_obj else False)
    def load_poster(self, fname):
        retval = False
        if self.poster_url:
            tmp = request_url(self.poster_url)
            if tmp["result"]:
                with open(fname, "wb") as fo:
                    fo.write(tmp["data"])
                    retval = True
        return retval

class t_infos(object):
    def __init__(self, info=None, search_obj=None):
        self.info = []
        self.search_obj = search_obj
        if info:
            self.info = info
        self.counter = 0
    def __iter__(self):
        self.counter = 0
        return self

    def item(self, index):
        return t_info(self.info[index], self.search_obj)

    def next(self):
        if self.counter < len(self.info):
            ti = self.item(self.counter)
            self.counter += 1
            return ti
        else:
            raise StopIteration

    __next__ = next

    def __getitem__(self, index):
        return self.item(index)
    def __len__(self):
        return len(self.info)
    def count(self):
        return len(self.info)
    def append(self, info):
        self.info.append(info)

class rts_mode(object):
    full_phrase = 0
    all_words = 1
    any_words = 2
    bool_expression = 3
class rts_category(object):
    all = 0
class rts_area(object):
    titles = 0
    titles_descriptions = 1
class rts_sort(object):
    date = 0
    seeders = 2
    leechers = 4
    name = 6
    size = 8
    relevance = 10
class rts_order(object):
    ascending = 1
    descending = 0


class rutor(object):
    def __init__(self):
        self.rts_search_url = '/search/{page}/{category}/{mode}{area}0/{sort}/{item}'
        self.url_prefix = 'http://rutor.info'
        """ параметры поисковой строки:
            page - страница поиска (0), старт с 0, далее от результата - 1 (вторая страница), 2 (третья и т.д.)
            category - категория фильмов, по-умолчанию 0 - во всех категориях
            mode - режим поиска: 0 - фраза полностью, 1 - все слова, 2 - любое из слов, 3 - логическое выражение
            area - область поиска: 0 - в названиях, 1 - в названиях и описаниях
            sort - сортировка результата: 0 - дата добавления, по убыванию (1-по возрастанию),
                                            2 - по раздающим , по убыванию (3-по возрастанию),
                                            4 - по качающим, по убыванию (5-по возрастанию),
                                            6 - по названию, по убыванию (7-по возрастанию),
                                            8 - по размеру, по убыванию (9-по возрастанию),
                                            10 - по релевантности, по убыванию (11-по возрастанию)
            item - текст поиска
            """
        self.rts_search_page = 0
        self.rts_category = rts_category.all
        self.rts_mode = rts_mode.full_phrase
        self.rts_area = rts_area.titles
        self.rts_sortmode = rts_sort.date
        self.rts_sortorder = rts_order.descending
        self.t_info_dict = {"url":"", "date":'', "name":"", "size":"", "seeders":"", "leechers":"", "magnet":'', "file_url":""}
        self.rts_infos = None
        self.srv_latest_url = 'https://releases.yourok.ru/torr/server_release.json'
        self.rts_search_query = ""

    @property
    def search_url(self):
        return (self.url_prefix+self.rts_search_url).format(page=self.rts_search_page, category=self.rts_category, mode=self.rts_mode,
                                                        area=self.rts_area,
                                                        sort=(self.rts_sortmode+self.rts_sortorder), item=self.rts_search_query)
    @property
    def query(self):
        return unquote(self.rts_search_query)
    @query.setter
    def query(self, val):
        self.rts_search_query = quote(val)

    def parse_next_urls(self, html):
        retval = []
        start = '<div id="index"><b>Страницы:'
        end = '</b>'
        tmp = get_text_between(html, start, end)
        if tmp["text"]:
            retval = [self.url_prefix + one for one in re.findall('(?:<a href=")(.*?)(?:">)', tmp["text"], flags=re.DOTALL)]
        return retval

    def parse_torrs_info(self, html):
        retval = False
        start = '''<table width="100%"><tr class="backgr"><td width="10px">Добавлен</td><td colspan="2">Название</td><td width="1px">Размер</td><td width="1px">Пиры</td></tr>'''
        end = '</table>'
        tmp = get_text_between(html, start, end)
        #tstrs = re.findall('(?:<tr class="tum|gai">)(?:.*?)(?:</tr>)', tmp["text"], flags=re.DOTALL)
        if tmp["text"]:
            tstrs = re.findall('<tr class="(?:gai|tum)">(.*?)</tr>', tmp["text"], flags=re.DOTALL)
            for one in tstrs:
                info = self.t_info_dict.copy()
                istrs = re.findall('<td(.*?)</td>', one, flags=re.DOTALL)
                # date
                info["date"] = re.sub('&nbsp;', ' ', istrs[0].strip("<>") )
                hrefs = re.findall('href="(.*?)">', istrs[1], flags=re.DOTALL)
                # ссылка на скачивание
                info["file_url"] = hrefs[0]
                #magnet
                info["magnet"] = hrefs[1]
                # torrent's page url
                info["url"] = self.url_prefix + hrefs[2]
                #name
                info["name"] = re.findall('(?:href="/torrent.*?>)(.*?)</a>', re.sub('&#039;',"'", istrs[1]) , flags=re.DOTALL)[0]
                #info["name"] =
                # size
                info["size"] = re.sub('align="right">|&nbsp;'," ",istrs[-2]).strip()
                traf = re.findall('(?:>&nbsp;)(.*?)</span>', istrs[-1], flags=re.DOTALL)
                info["seeders"] = int(traf[0])
                info["leechers"] = int(traf[1])
                self.rts_infos.append(info)
            retval = True if len(self.rts_infos) else False
        return retval

    def parse_detail_info(self, html):
        from_list = lambda x, y, z="": x[y] if len(x)>0 else z
        info = {}
        #description
        #desc = re.findall('<b>О фильме:[\s]*</b>(<.*?>)*(.*?)<br />', html, flags=re.DOTALL)
        desc = re.findall('(Описание|О фильме)[\s|:]*</b>(<.*?>)*(.*?)<br />', html, flags=re.DOTALL)
        if desc and type(desc[0]) == tuple and len(desc[0]) == 3:
            info["description"] = pretty_name(desc[0][2])
        else:
            info["description"] = ''
        #poster
        tmp = re.findall('></td><td><br /><img src="(.*?)"', html, flags=re.DOTALL)
        info["poster_url"] = from_list(tmp, 0, "")
        #year
        #tmp = re.findall('<b>Год выхода:[\s]*</b>(.*?)<br />', html, flags=re.DOTALL)
        tmp = re.findall('<b>Год.*?[\s]*</b>:*?(.*?)<br />', html, flags=re.DOTALL)
        info["year"] = pretty_name(from_list(tmp, 0, "") )
        #genre
        #tmp = re.findall('<b>Жанр:[\s]*</b>[\s]*(.*?)<br />', html, flags=re.DOTALL)
        tmp = re.findall('<b>Жанр.*?[\s]*</b>[\s]*:*?[\s]*(.*?)<br />', html, flags=re.DOTALL)
        info["genres"] = re.findall('target="_blank">(.*?)</a>', from_list(tmp, 0, ""), flags=re.DOTALL)
        #duration
        #tmp = re.findall('<b>Продолжительность:[\s]*</b>(.*?)<br />', html, flags=re.DOTALL)
        tmp = re.findall('<b>Продолжительность.*?[\s]*</b>:*?(.*?)<br />', html, flags=re.DOTALL)
        info["duration"] = pretty_name( from_list(tmp, 0, "") )
        #quality
        tmp = re.findall('<b>Качество:[\s]*</b>(.*?)<br />', html, flags=re.DOTALL)
        info["quality"] = from_list(tmp, 0, "")
        #video
        #tmp = re.findall('<b>Видео:[\s]*</b>(.*?)<br />', html, flags=re.DOTALL)
        tmp = re.findall('<b>Видео.*?[\s]*</b>:*?(.*?)<br />', html, flags=re.DOTALL)
        info["video"] = pretty_name(from_list(tmp, 0, "") )
        return info

    def search(self):
        self.rts_infos = t_infos(info=None, search_obj=self)
        #print self.search_url
        tmp = request_url(self.search_url)
        if tmp["result"]:
            nexts = self.parse_next_urls(tmp["data"])
            if self.parse_torrs_info(tmp["data"]):
                for oneurl in nexts:
                    del tmp
                    tmp = request_url(oneurl)
                    if tmp["result"]:
                        self.parse_torrs_info(tmp["data"])
        return (True if len(self.rts_infos) else False)

    def load_detail_info(self, tinfo_obj):
        retval = False
        tmp = request_url(tinfo_obj.detail_url)
        if tmp["result"]:
            s_info = self.parse_detail_info(tmp["data"])
            if s_info:
                tinfo_obj.detail_info = s_info
                retval = True
        return retval
