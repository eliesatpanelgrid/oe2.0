#!/usr/bin/python
# coding=utf-8
#
# Copyright (C) 2018-2023 by dream-alpha
#
# In case of reuse of this source code please do not remove this copyright.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# For more information on the GNU General Public License see:
# <http://www.gnu.org/licenses/>.


import glob, os
from Components.config import config
from enigma import eTimer, gPixmapPtr, getDesktop
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

ACTIVITY_TIMER_DELAY = 250
PLUGIN = 'Transmission'
def getResolution():
	height = getDesktop(0).size().height()
	resolution = "SD"
	if height > 576:
		resolution = "HD"
	if height > 720:
		resolution = "FHD"
	if height > 1080:
		resolution = "WQHD"
	return resolution
def getSkinPath(file_name):
	base_skin_dir = "/usr/share/enigma2"
	sub_skin_dir = os.path.dirname(config.skin.primary_skin.value)
	if not sub_skin_dir:
		sub_skin_dir = "Default-HD"
	elif sub_skin_dir == "Shadow-FHD":
		pass
	elif sub_skin_dir == "Zombi-Shadow-FHD":
		sub_skin_dir = "Shadow-FHD"
	elif sub_skin_dir == "Shadow-WQHD":
		sub_skin_dir = "Default-WQHD"
	else:
		sub_skin_dir = "Default-" + getResolution()

	dirs = [
		os.path.join(resolveFilename(SCOPE_PLUGINS), "Extensions", PLUGIN, "skins", sub_skin_dir),
		os.path.join(resolveFilename(SCOPE_PLUGINS), "SystemPlugins", PLUGIN, "skins", sub_skin_dir),
		os.path.join(resolveFilename(SCOPE_PLUGINS), "Extensions", PLUGIN, "skins"),
		os.path.join(resolveFilename(SCOPE_PLUGINS), "SystemPlugins", PLUGIN, "skins"),
		os.path.join(base_skin_dir, sub_skin_dir),
		base_skin_dir
	]

	for adir in dirs:
		skin_path = os.path.join(adir, file_name)
		if os.path.exists(skin_path):
			break
		skin_path = ""
	return skin_path


class Loading():

	def __init__(self, pic_loading, int_loading, msg_loading, summaries):
		self.activity_timer = eTimer()
		self.activity_timer.callback.append(self.doActivityTimer)
		self.pic_index = 0
		self.pic_loading = pic_loading
		self.int_loading = int_loading
		self.msg_loading = msg_loading
		self.summaries = summaries
		self.pics = len(glob.glob(resolveFilename(SCOPE_PLUGINS, "Extensions/Transmission/images/spinner/*.png")))

	def start(self, seconds=-1, msg=""):
		self.seconds = seconds
		self.activity_timer.start(ACTIVITY_TIMER_DELAY, False)
		self.pic_loading.instance.show()
		if self.seconds > -1:
			self.int_loading.setText("%2d" % seconds)
		self.msg_loading.setText(msg)
		if self.summaries:
			self.summaries[0]["background"].instance.setPixmap(LoadPixmap(getSkinPath("skin_default/display_bg.png"), cached=False))
			self.summaries[0]["lcd_pic_loading"].setShowHideAnimation("")
			self.summaries[0]["lcd_pic_loading"].show()

	def stop(self, msg=""):
		self.activity_timer.stop()
		self.pic_loading.instance.setPixmap(gPixmapPtr())
		self.int_loading.instance.setText("")
		self.msg_loading.instance.setText(msg)
		if self.summaries:
			self.summaries[0]["background"].hide()
			self.summaries[0]["lcd_pic_loading"].hide()

	def updateProgress(self, seconds):
		self.seconds = seconds
		if self.seconds > -1:
			self.int_loading.setText("%2d" % seconds)

	def doActivityTimer(self):
		path = resolveFilename(SCOPE_PLUGINS, "Extensions/Transmission/images/spinner/wait%s.png" % (self.pic_index + 1))
		pixmap = LoadPixmap(path, cached=False)
		self.pic_loading.instance.setPixmap(pixmap)
		if self.pic_index % 4 == 0 and self.seconds > -1:
			self.int_loading.setText("%2d" % self.seconds)
			self.seconds -= 1 if self.seconds else 0
		if self.summaries:
			self.summaries[0]["lcd_pic_loading"].instance.setPixmap(pixmap)
		self.pic_index = (self.pic_index + 1) % self.pics
