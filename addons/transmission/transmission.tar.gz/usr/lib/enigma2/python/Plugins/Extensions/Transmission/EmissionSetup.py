# uncompyle6 version 3.9.0
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.8.10 (default, Nov 22 2023, 10:22:35)
# [GCC 9.4.0]
# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/Transmission/EmissionSetup.py
# Compiled at: 2023-09-27 23:49:42
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from Screens.Setup import SetupSummary
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.config import config, getConfigListEntry
from . import _

class EmissionSetup(Screen, ConfigListScreen):

    def __init__(self, session):
        Screen.__init__(self, session)
        self.skinName = ['EmissionSetup', 'Setup']
        self.setup_title = _('Transmission-cli settings')
        self.onChangedEntry = []
        ConfigListScreen.__init__(self, [
         getConfigListEntry(_('Hostname'), config.plugins.emission.hostname),
         getConfigListEntry(_('Username'), config.plugins.emission.username),
         getConfigListEntry(_('Password'), config.plugins.emission.password),
         getConfigListEntry(_('Port'), config.plugins.emission.port),
         getConfigListEntry(_('Auto-add torrent enclosures from SimpleRSS'), config.plugins.emission.autodownload_from_simplerss)], session=session, on_change=self.changed)
        self['key_green'] = StaticText(_('OK'))
        self['key_red'] = StaticText(_('Cancel'))
        self['actions'] = ActionMap(['SetupActions'], {'cancel': self.keyCancel,
           'save': self.keySave})
        self.changed()
        self.onLayoutFinish.append(self.setCustomTitle)

    def setCustomTitle(self):
        self.setTitle(self.setup_title)

    def changed(self):
        for x in self.onChangedEntry:
            x()

    def getCurrentEntry(self):
        return self['config'].getCurrent()[0]

    def getCurrentValue(self):
        return str(self['config'].getCurrent()[1].getText())

    def createSummary(self):
        return SetupSummary
