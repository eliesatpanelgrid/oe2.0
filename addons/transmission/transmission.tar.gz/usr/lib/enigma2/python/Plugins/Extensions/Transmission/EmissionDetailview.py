# -*- coding: utf-8 -*-
import logging
from . import _, getSkin, medialist
# GUI (Screens)
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.HelpMenu import HelpableScreen

# GUI (Components)
from Components.ActionMap import HelpableActionMap
from Components.Sources.List import List
from Components.Sources.Progress import Progress
from Components.Sources.StaticText import StaticText

from enigma import eTimer

from . import EmissionBandwidth
from transmission_rpc import TransmissionError

from six.moves import reload_module

# Initialize logger
logger = logging.getLogger('EmissionDetailview')
logger.setLevel(logging.DEBUG)
handler = logging.FileHandler('/tmp/detailview_main.log')
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

class EmissionDetailview(Screen, HelpableScreen):
    def createSummary(self):
        from .TransmissionBrowser import TransmissionLCDSummary
        return TransmissionLCDSummary

    def getLCDSummary(self):
        try:
            name = self["name"].getText()
        except Exception:
            name = ""
        try:
            progress = self["progress"].getValue()
        except Exception:
            progress = 0
        return {
            "title": "Transmission – Details",
            "line1": name[:32],
            "line2": "",
            "line3": "",
            "progress": int(progress or 0),
        }

    def __init__(self, session, daemon, torrent, prevFunc=None, nextFunc=None):
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        logger.debug(f"Initializing Detailview for torrent: {torrent.id}")
        self.skin = getSkin("EmissionDetailview2")
        self.skinName = "EmissionDetailview2"
        self.transmission = daemon
        self.torrentid = torrent.id
        self.prevFunc = prevFunc
        self.nextFunc = nextFunc
        logger.debug(f"Torrent ID: {self.torrentid}, Name: {torrent.name}")

        self["ChannelSelectBaseActions"] = HelpableActionMap(self, "ChannelSelectBaseActions",
        {
            "prevMarker": (self.prevDl, _("show previous download details")),
            "nextMarker": (self.nextDl, _("show next download details")),
        })

        self["SetupActions"] = HelpableActionMap(self, "SetupActions",
        {
            "ok": (self.ok, _("toggle file status")),
            "cancel": self.close,
        })

        self["ColorActions"] = HelpableActionMap(self, "ColorActions",
        {
            "yellow": (self.toggleStatus, _("toggle download status")),
            "green": (self.bandwidth, _("open bandwidth settings")),
            "blue": (self.remove, _("remove torrent")),
        })

        self["key_red"] = StaticText(_("Close"))
        self["key_green"] = StaticText(_("Bandwidth"))
        if torrent.status == "stopped":
            self["key_yellow"] = StaticText(_("start"))
        else:
            self["key_yellow"] = StaticText(_("stop"))
        self["key_blue"] = StaticText(_("remove"))

        self["upspeed"] = StaticText("")
        self["downspeed"] = StaticText("")
        self["peers"] = StaticText("")
        self["name"] = StaticText(str(torrent.name))
        self["files_text"] = StaticText(_("Files"))
        self.menu_list = []
        self["files"] = List(self.menu_list)
        # Ensure progress is always an integer and not None
        progress_value = int(torrent.progress if torrent.progress is not None else 0)
        self["progress"] = Progress(progress_value)

        self["progress_text"] = StaticText("")
        self["ratio"] = StaticText("")
        self["eta"] = StaticText("")
        self["tracker"] = StaticText("")
        self["private"] = StaticText("")

        self.timer = eTimer()
        self.timer.callback.append(self.updateList)
        self.timer.start(0, 1)
        logger.debug("Timer started for initial update")

        # CRITICAL FIX: Perform initial update immediately
        self.onFirstExecBegin.append(self.initialUpdate)

    def initialUpdate(self):
        """Force the first update immediately after screen is shown"""
        logger.debug("Performing initial update")
        self.timer.stop()
        self.updateList()

    def bandwidthCallback(self, ret=None):
        if ret:
            try:
                self.transmission.change_torrent([self.torrentid], **ret)
            except TransmissionError as te:
                logger.error(f"Bandwidth change error: {te}")
                self.session.open(
                    MessageBox,
                    _("Error communicating with transmission-daemon: %s.") % (te),
                    type=MessageBox.TYPE_ERROR,
                    timeout=5
                )
        self.updateList()

    def bandwidth(self):
        logger.debug("Opening bandwidth settings")
        self.timer.stop()
        id = self.torrentid
        try:
            torrent = self.transmission.get_torrent(id)
            rpc_version = self.transmission.rpc_version
        except TransmissionError as te:
            logger.error(f"Bandwidth retrieval error: {te}")
            self.session.open(
                MessageBox,
                _("Error communicating with transmission-daemon: %s.") % (te),
                type=MessageBox.TYPE_ERROR,
                timeout=5
            )
            self.updateList()
        else:
            self.session.openWithCallback(
                self.bandwidthCallback,
                EmissionBandwidth.EmissionBandwidth,
                torrent,
                True,
                rpc_version
            )

    def prevDl(self):
        if self.prevFunc:
            torrent = self.prevFunc()
            if torrent:
                logger.debug(f"Moving to previous torrent: {torrent.id}")
                self.timer.stop()
                self.torrentid = torrent.id
                self["name"].text = str(torrent.name)
                self.updateList()

    def nextDl(self):
        if self.nextFunc:
            torrent = self.nextFunc()
            if torrent:
                logger.debug(f"Moving to next torrent: {torrent.id}")
                self.timer.stop()
                self.torrentid = torrent.id
                self["name"].text = str(torrent.name)
                self.updateList()

    def toggleStatus(self):
        id = self.torrentid
        try:
            torrent = self.transmission.get_torrent(id)
            status = torrent.status
            logger.debug(f"Toggling status from {status}")
            if status == "stopped":
                self.transmission.start_torrent([id])
                self["key_yellow"].text = _("pause")
            elif status in ("downloading", "seeding"):
                self.transmission.stop_torrent([id])
                self["key_yellow"].text = _("start")
        except TransmissionError as te:
            logger.error(f"Status toggle error: {te}")
            self.session.open(
                MessageBox,
                _("Error communicating with transmission-daemon: %s.") % (te),
                type=MessageBox.TYPE_ERROR,
                timeout=5
            )

    def remove(self):
        logger.debug("Remove torrent requested")
        self.session.openWithCallback(
            self.removeCallback,
            ChoiceBox,
            _("Really delete torrent?"),
            [(_("no"), "no"),
            (_("yes"), "yes"),
            (_("yes, including data"), "data")]
        )

    def removeCallback(self, ret=None):
        if ret:
            ret = ret[1]
            logger.debug(f"Remove confirmed with option: {ret}")
            try:
                if ret == "yes":
                    self.transmission.remove_torrent([self.torrentid], delete_data=False)
                    self.close()
                elif ret == "data":
                    self.transmission.remove_torrent([self.torrentid], delete_data=True)
                    self.close()
            except TransmissionError as te:
                logger.error(f"Remove error: {te}")
                self.session.open(
                    MessageBox,
                    _("Error communicating with transmission-daemon: %s.") % (te),
                    type=MessageBox.TYPE_ERROR,
                    timeout=5
                )

    def updateList(self, *args, **kwargs):
        logger.debug(f"UpdateList called for torrent ID: {self.torrentid}")
        try:
            torrent = self.transmission.get_torrent(self.torrentid)
            # Log torrent (safely)
            logger.debug(f"Retrieved torrent: {torrent}")

            # Get files safely
            files = {}
            if isinstance(torrent, dict):
                files = torrent.get('files', {})
            else:
                if hasattr(torrent, 'files'):
                    if callable(torrent.files):
                        files = torrent.files()
                    else:
                        files = torrent.files
                elif hasattr(torrent, 'get_files'):
                    files = torrent.get_files()
            
            # Normalize files to dictionary if it's a list
            if isinstance(files, list):
                files_dict = {}
                for idx, f in enumerate(files):
                    files_dict[idx] = f
                files = files_dict

            logger.debug(f"Files count: {len(files)}")

            self.updateUI(torrent, files)

        except TransmissionError as te:
            logger.error(f"TransmissionError: {te}", exc_info=True)
            self.clearUI()
        except Exception as e:
            logger.error(f"Unexpected error: {e}", exc_info=True)
            self.clearUI()
        finally:
            self.timer.startLongTimer(5)

    def clearUI(self):
        logger.warning("Clearing UI due to error")
        self["upspeed"].text = ""
        self["downspeed"].text = ""
        self["peers"].text = ""
        self["progress_text"].text = ""
        self["ratio"].text = ""
        self["eta"].text = ""
        self["tracker"].text = ""
        self["private"].text = ""
        self["files"].setList([])

    def updateUI(self, torrent, files):
        logger.debug("Updating UI with torrent data")
        try:
            # Update name
            self["name"].text = str(self.get_attr(torrent, 'name', 'Unknown'))

            # Update status button
            status = self.get_attr(torrent, 'status', 'unknown')
            if status == "stopped":
                self["key_yellow"].text = _("start")
            else:
                self["key_yellow"].text = _("stop")

            # Ensure progress value is valid
            progress = self.get_attr(torrent, 'progress')
            progress_value = int(progress if progress is not None else 0)
            self["progress"].setValue(progress_value)
            logger.debug(f"Progress set to: {progress_value}")

            # Update speed displays
            rate_upload = self.get_attr(torrent, 'rate_upload', 0)
            rate_download = self.get_attr(torrent, 'rate_download', 0)
            up_kb = max(0, (rate_upload or 0) // 1024)
            down_kb = max(0, (rate_download or 0) // 1024)
            self["upspeed"].text = _("%d kb/s") % up_kb
            self["downspeed"].text = _("%d kb/s") % down_kb

            # Prepare and set file list
            self.menu_list = self.prepareFileList(files)
            current_index = self["files"].index if self["files"].index is not None else 0
            safe_index = min(current_index, max(0, len(self.menu_list) - 1))
            self["files"].setList(self.menu_list)
            self["files"].index = safe_index

            # Update status texts
            status_text, progress_text = self.getStatusText(torrent, status)
            self["peers"].text = status_text
            self["progress_text"].text = progress_text

            # Update additional info
            ratio = self.get_attr(torrent, 'ratio', 0)
            self["ratio"].text = _("Ratio: %.2f") % (ratio or 0)

            # Handle ETA
            eta = self.get_attr(torrent, 'eta', -1)
            if eta >= 0:
                # Try to use format_eta method safely
                formatted_eta = None
                if hasattr(torrent, 'format_eta') and callable(torrent.format_eta):
                    formatted_eta = torrent.format_eta()
                
                self["eta"].text = _("ETA: %s") % (formatted_eta or _("Unknown"))
            else:
                self["eta"].text = _("ETA: Unknown")

            tracker = self.get_attr(torrent, 'tracker', 'Unknown')
            self["tracker"].text = _("Tracker: %s") % (tracker or _("Unknown"))
            
            is_private = self.get_attr(torrent, 'private', False)
            self["private"].text = _("Private: %s") % (_("Yes") if is_private else _("No"))

        except Exception as e:
            logger.error(f"Error in updateUI: {e}", exc_info=True)

    def getStatusText(self, torrent, status):
        try:
            if status == 'check pending':
                peerText = _("check pending")
                progressText = ""
            elif status == 'checking':
                peerText = _("checking")
                recheck_progress = self.get_attr(torrent, 'recheck_progress', 0)
                progressText = str(recheck_progress)
            elif status == 'downloading':
                peers_sending = self.get_attr(torrent, 'peers_sending_to_us', 0)
                peers_connected = self.get_attr(torrent, 'peers_connected', 0)
                peerText = _("Downloading from %d of %d peers") % (peers_sending, peers_connected)
                
                downloaded = self.get_attr(torrent, 'downloaded_ever', 0)
                size_done = self.get_attr(torrent, 'size_when_done', 0)
                progress = self.get_attr(torrent, 'progress', 0)
                
                progressText = _("Downloaded %d of %d MB (%d%%)") % (
                    (downloaded or 0) // 1048576,
                    (size_done or 0) // 1048576,
                    progress or 0
                )
            elif status == 'seeding':
                peers_getting = self.get_attr(torrent, 'peers_getting_from_us', 0)
                peers_connected = self.get_attr(torrent, 'peers_connected', 0)
                peerText = _("Seeding to %d of %d peers") % (peers_getting, peers_connected)
                
                downloaded = self.get_attr(torrent, 'downloaded_ever', 0)
                uploaded = self.get_attr(torrent, 'uploaded_ever', 0)
                
                progressText = _("Downloaded %d and uploaded %d MB") % (
                    (downloaded or 0) // 1048576,
                    (uploaded or 0) // 1048576
                )
            elif status == 'stopped':
                peerText = _("stopped")
                downloaded = self.get_attr(torrent, 'downloaded_ever', 0)
                uploaded = self.get_attr(torrent, 'uploaded_ever', 0)
                progressText = _("Downloaded %d and uploaded %d MB") % (
                    (downloaded or 0) // 1048576,
                    (uploaded or 0) // 1048576
                )
            else:
                peerText = str(status)
                progressText = ""
            return peerText, progressText
        except Exception as e:
            logger.error(f"Error in getStatusText: {e}")
            return _("Status error"), _("Data error")

    def get_attr(self, obj, attr, default=None):
        """Safely get attribute from object or key from dict"""
        if isinstance(obj, dict):
            return obj.get(attr, default)
        return getattr(obj, attr, default)

    def prepareFileList(self, files):
        logger.debug("Preparing file list for display")
        file_list = []
        for file_id, file in files.items():
            try:
                completed = int(self.get_attr(file, 'completed', 0))
                size = int(self.get_attr(file, 'size', 1))  # Avoid division by zero
                progress = int(100.0 * completed / size) if size > 0 else 0
                selected = self.get_attr(file, 'selected', False)
                name = str(self.get_attr(file, 'name', 'Unknown'))
                priority = str(self.get_attr(file, 'priority', 'Normal'))

                file_entry = (
                    file_id,
                    progress,
                    "%d MB" % max(0, completed // 1048576),
                    selected,
                    name,
                    "%d MB" % max(0, size // 1048576),
                    _("downloading") if selected else _("skipping"),
                    priority
                )
                file_list.append(file_entry)

            except Exception as e:
                logger.error(f"Error processing file {file_id}: {e}", exc_info=True)

        logger.debug(f"Prepared {len(file_list)} file entries")
        return file_list

    def ok(self):
        cur = self["files"].getCurrent()
        if cur:
            logger.debug(f"Toggling file status for file ID: {cur[0]}")
            self.timer.stop()
            id = self.torrentid
            try:
                torrent = self.transmission.get_torrent(id)
                files = torrent.files()

                # XXX: we need to make sure that at least one file is selected for
                # download so unfortunately we might have to check all files if
                # we are unselecting this one
                if cur[3]:
                    files[cur[0]]['selected'] = False
                    atLeastOneSelected = False
                    for file in list(files.values()):
                        if file['selected']:
                            atLeastOneSelected = True
                            break
                    if not atLeastOneSelected:
                        logger.warning("Attempted to unselect the only selected file")
                        self.session.open(
                            MessageBox,
                            _("Unselecting the only file scheduled for download is not possible through RPC."),
                            type=MessageBox.TYPE_ERROR
                        )
                        self.updateList()
                        return
                else:
                    files[cur[0]]['selected'] = True

                self.transmission.set_torrent_files({self.torrentid: files})
            except TransmissionError as te:
                logger.error(f"File toggle error: {te}")
                self.session.open(
                    MessageBox,
                    _("Error communicating with transmission-daemon: %s.") % (te),
                    type=MessageBox.TYPE_ERROR,
                    timeout=5
                )
            self.updateList()

    def close(self):
        logger.debug("Closing Detailview")
        self.timer.stop()
        Screen.close(self)
