# -*- coding: UTF-8 -*-
# version: 07/12/2021
import json
import traceback 
from . import Request, urlencode, urlopen, PY3, ENCODE_UTF8

tls_http = None
tls = None
BUFFER = 1000

def prepare_url(url):
    newurl = url.strip(" ")
    newurl = newurl.replace("http://", "")
    newurl = newurl.replace("https://", "")
    parts = newurl.split("/")
    #host = parts[0] if parts[0].startswith("www.") else "www.{0}".format(parts[0])
    host = parts[0]
    res = "/".join([""]+parts[1:]) if ( len(parts)>1 ) else ""
    return (host, res)


def tls_import():
    global tls
    global tls_http
    retval = True
    try:
        if not tls_http:
            import tlslite.integration.httptlsconnection as tls_http
            #print "importing tls_http"
        else:
            #print "don't importing tls_http"
            pass
        if not tls:
            import tlslite.tlsconnection as tls
            #print "importing tls"
        else:
            #print "don't importing tls"
            pass
    except:
        retval = False
    return retval

def request_url(url, values = {}, context = None, timeout = None):
    retval = {"result":False, "data":'', "error":None}
    data = None
    try:
        if values and (type(values) == dict):
            data = urlencode(values)
            req = Request(url + '?' + data)
        elif values and (type(values) == str):
            req = Request(url, values)
        else:
            req = Request(url)
        #raise Exception("Error:SSL routines:SSL23_GET_SERVER_HELLO")
        if context:
            resp = urlopen(req, context=context, timeout = timeout)
        else:
            resp = urlopen(req, timeout = timeout)
        retval["data"] = resp.read()
        if PY3: retval["data"] = retval["data"].decode()
        retval["result"] = True
    except Exception as err:
        retval["error"] = err
        try:
            print(ENCODE_UTF8("Error request: [%s] to url: [%s] with parametrs: [%s]" % (err, url, values) ))
        except:
            print("Can't encode error message due request to url: [%s] with parametrs: [%s]" % (url, values))
        if ":SSL routines:SSL23_GET_SERVER_HELLO" in str(err):
            #print("Try import tls_http...")
            if tls_import():
                try:
                #if True:
                    print("try connect over tls...")
                    newurl = prepare_url(url)
                    #print newurl
                    hs = tls.HandshakeSettings()
                    hs.minVersion = (3, 1)
                    hs.maxVersion = (3, 3)
                    conn = tls_http.HTTPTLSConnection(newurl[0], 443, settings=hs)
                    hdrs = {'User-agent': 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/2008071615 Fedora/3.0.1-1.fc9 Firefox/3.0.1'}
                    #conn.request("GET", newurl[1], headers = hdrs, body=data)
                    add_url = ("%s?%s"%(newurl[1], data)) if data else newurl[1]
                    conn.request("GET", add_url.encode("utf-8", "ignore"), headers = hdrs)
                    resp = conn.getresponse()
                    resp_code = resp.status
                    #print("resp code == %s" % resp_code)
                    if resp_code == 200:
                        myArr = bytearray()
                        bytes = resp.read(BUFFER)
                        while bytes:
                            [myArr.append(ord(one)) for one in bytes]
                            bytes = resp.read(BUFFER)
                        retval["data"] = str(myArr)  #.decode("utf-8", "ignore")
                        #print "myVar len = %s, type = %s" % (len(myArr), type(myArr))
                        #print myArr
                        #print "LEN = %s, type - %s" % (len(retval["data"]), type(retval["data"]))
                        #print retval["data"].encode('ascii', 'ignore').decode('ascii')
                        retval["result"] = True
                    elif resp_code == 302:
                        iter_count = 10
                        i = 1
                        while resp_code == 302 and i <= iter_count:
                            newurl = prepare_url( resp.msg.dict['location'] )
                            conn = tls_http.HTTPTLSConnection(newurl[0], 443, settings=hs)
                            hdrs = {'User-agent': 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/2008071615 Fedora/3.0.1-1.fc9 Firefox/3.0.1'}
                            add_url = ("%s?%s"%(newurl[1], data)) if data else newurl[1]
                            #conn.request("GET", newurl[1], headers = hdrs)
                            conn.request("GET", add_url.encode("utf-8", "ignore"), headers = hdrs, body=data)
                            resp = conn.getresponse()
                            resp_code = resp.status
                            #print("resp code == %s" % resp_code)
                            if resp_code == 200:
                                myArr = bytearray()
                                bytes = resp.read(BUFFER)
                                while bytes:
                                    [myArr.append(ord(one)) for one in bytes]
                                    bytes = resp.read(BUFFER)
                                retval["data"] = str(myArr)  #.decode("utf-8", "ignore")
                                retval["result"] = True
                            i += 1
                        #print "Stert recursion..."
                        #retval = request_url(resp.msg.dict['location'], values = {}, context = context, timeout = timeout)
                        #print "Result recursion = %s" % retval["result"]
                except Exception as err_tls:
                #else:
                    print(traceback.format_exc())
                    print("Error request [%s] over tlslite-ng" % err_tls)
                    retval["error"] = err_tls
                else:
                    print("tls result = %s"%retval["result"])
                    #print retval
            else:
                print("tls not loaded!")
    return retval
