from . import _, getSkin, medialist
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Screens.HelpMenu import HelpableScreen
from Screens.LocationBox import LocationBox
from Screens.MessageBox import MessageBox
from Tools.Directories import resolveFilename, fileExists, SCOPE_PLUGINS
from Components.ActionMap import HelpableActionMap
from Components.FileList import FileList
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.config import config
from enigma import eTimer, ePixmap
from transmission_rpc import Client, TransmissionError
from . import EmissionBandwidth
from . import EmissionDetailview
from . import EmissionSetup
from six.moves import reload_module
import re
import os

try:
    from Plugins.Extensions.MoviesManager.MoviesScreen import MovieScreen

    MoviesManager_installed = True
except:
    MoviesManager_installed = False

LIST_TYPE_ALL = 0
LIST_TYPE_DOWNLOADING = 1
LIST_TYPE_SEEDING = 2
SORT_TYPE_TIME = 0
SORT_TYPE_PROGRESS = 1
SORT_TYPE_ADDED = 2
SORT_TYPE_SPEED = 3


def logdata(label_name='', data=None):
    try:
        data = str(data)
        fp = open('/tmp/overview.log', 'a')
        fp.write(str(label_name) + ' : ' + data + '\n')
        fp.close()
    except:
        logdata()


class TorrentLocationBox(LocationBox):

    def __init__(self, session):
        LocationBox.__init__(self, session)
        self.skinName = ['TorrentLocationBox', 'LocationBox']
        self['filelist'] = FileList(None, showDirectories=True, showFiles=True, matchingPattern='^.*\\.tor(rent)?')

    def ok(self):
        if self.currList == 'filelist':
            if self['filelist'].canDescent():
                self['filelist'].descent()
                self.updateTarget()
            else:
                self.select()
        else:
            self['filelist'].changeDir(self['booklist'].getCurrent())

    def selectConfirmed(self, ret):
        if ret:
            dir = self['filelist'].getCurrentDirectory()
            cur = self['filelist'].getSelection()
            ret = dir and cur and dir + cur[0]
            if self.realBookmarks:
                if self.autoAdd and ret not in self.bookmarks:
                    self.bookmarks.append(self.getPreferredFolder())
                    self.bookmarks.sort()
                if self.bookmarks != self.realBookmarks.value:
                    self.realBookmarks.value = self.bookmarks
                    self.realBookmarks.save()
            self.close(ret)

    def select(self):
        if self.currList == 'filelist' and (not self['filelist'].canDescent()):
            self.selectConfirmed(True)


class EmissionOverview(Screen, HelpableScreen):
    def createSummary(self):
        from .TransmissionBrowser import TransmissionLCDSummary
        return TransmissionLCDSummary

    def getLCDSummary(self):
        try:
            txt = self['torrents'].getText()
        except Exception:
            txt = ""
        cur = self['list'].getCurrent()
        name = cur[1] if cur else ""
        prog = cur[3] if cur and len(cur) > 3 else 0
        return {
            "title": "Transmission – Torrents",
            "line1": name[:32],
            "line2": txt,
            "line3": "",
            "progress": int(prog or 0),
        }

    def __init__(self, session):
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        self.skin = getSkin('EmissionOverview2')
        self.skinName = 'EmissionOverview2'
        try:
            self.transmission = Client(host=config.plugins.emission.hostname.value,
                                       port=config.plugins.emission.port.value,
                                       username=config.plugins.emission.username.value,
                                       password=config.plugins.emission.password.value)
        except TransmissionError as te:
            self.transmission = None
        self['SetupActions'] = HelpableActionMap(self, 'SetupActions', {'ok': (self.ok, _('show details')),
                                                                        'cancel': (self.close, _('close'))})
        self['ColorActions'] = HelpableActionMap(self, 'ColorActions',
                                                 {'green': (self.bandwidth, _('open bandwidth settings')),
                                                  'yellow': (self.prevlist, _('show previous list')),
                                                  'blue': (self.nextlist, _('show next list'))})
        self['MenuActions'] = HelpableActionMap(self, 'MenuActions', {'menu': (self.menu, _('open context menu'))})
        if MoviesManager_installed:
            self['EPGSelectActions'] = HelpableActionMap(self, 'EPGSelectActions',
                                                         {'info': (self.info, _('open my movies collections'))})
        self['key_red'] = StaticText(_('Close'))
        self['key_green'] = StaticText(_('Bandwidth'))
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        self['all_text'] = StaticText(_('All'))
        self['downloading_text'] = StaticText(_('DL'))
        self['seeding_text'] = StaticText(_('UL'))
        self['upspeed'] = StaticText('')
        self['downspeed'] = StaticText('')
        self['torrents'] = StaticText('')
        self['all_sel'] = Pixmap()
        self['downloading_sel'] = Pixmap()
        self['seeding_sel'] = Pixmap()
        self['list'] = List([])
        self.list_type = config.plugins.emission.last_tab.value
        self.sort_type = config.plugins.emission.last_sort.value
        self.showHideSetTextMagic()
        self.timer = eTimer()
        self.timer.callback.append(self.updateList)
        self.timer.start(0, 1)
        self.darwin_directory = resolveFilename(SCOPE_PLUGINS, 'Extensions/Transmission/skins')
        self.poster_directory = '/media/hdd/transmission/poster'
        self['poster'] = Pixmap()
        self['list'].onSelectionChanged.append(self.showPoster)

    def bandwidthCallback(self, ret=None):
        if self.transmission is not None and ret:
            try:
                self.transmission.set_session(**ret)
            except TransmissionError as te:
                self.session.open(MessageBox, _('Error communicating with transmission-daemon: %s.') % te,
                                  type=MessageBox.TYPE_ERROR, timeout=5)
        self.updateList()

    def menuCallback(self, ret=None):
        ret and ret[1]()

    def newDlCallback(self, ret=None):
        if self.transmission is not None and ret:
            try:
                res = self.transmission.add_torrent(ret)
            except TransmissionError as te:
                self.session.open(MessageBox, _('Error communicating with transmission-daemon: %s.') % te,
                                  type=MessageBox.TYPE_ERROR, timeout=5)
            else:
                if not res:
                    self.session.open(MessageBox, _('Torrent could not be scheduled not download!'),
                                      type=MessageBox.TYPE_ERROR, timeout=5)
                    pass
        self.updateList()

    def newDl(self):
        self.timer.stop()
        self.session.openWithCallback(self.newDlCallback, TorrentLocationBox)

    def sortCallback(self, ret=None):
        if ret is not None:
            self.sort_type = config.plugins.emission.last_sort.value = ret[1]
            config.plugins.emission.last_sort.save()
        self.updateList()

    def sort(self):
        self.timer.stop()
        self.session.openWithCallback(self.sortCallback, ChoiceBox, _('Which sorting method do you prefer?'),
                                      [(_('by eta'), SORT_TYPE_TIME), (_('by progress'), SORT_TYPE_PROGRESS),
                                       (_('by age'), SORT_TYPE_ADDED), (_('by speed'), SORT_TYPE_SPEED)])

    def pauseShown(self):
        if self.transmission is not None:
            self.transmission.stop([x[0].id for x in self.list])

    def unpauseShown(self):
        if self.transmission is not None:
            self.transmission.start([x[0].id for x in self.list])

    def pauseAll(self):
        if self.transmission is None:
            return
        try:
            self.transmission.stop([x.id for x in list(self.transmission.list().values())])
        except TransmissionError as te:
            self.session.open(MessageBox, _('Error communicating with transmission-daemon: %s.') % te,
                              type=MessageBox.TYPE_ERROR, timeout=5)

    def unpauseAll(self):
        if self.transmission is None:
            return
        try:
            self.transmission.start([x.id for x in list(self.transmission.list().values())])
        except TransmissionError as te:
            self.session.open(MessageBox, _('Error communicating with transmission-daemon: %s.') % te,
                              type=MessageBox.TYPE_ERROR, timeout=5)

    def configure(self):
        self.timer.stop()
        self.session.openWithCallback(self.configureCallback, EmissionSetup.EmissionSetup)

    def menu(self):
        self.session.openWithCallback(self.menuCallback, ChoiceBox, _('What do you want to do?'),
                                      [(_('Configure connection'), self.configure), (_('Change sorting'), self.sort),
                                       (_('Add new download'), self.newDl), (_('Pause shown'), self.pauseShown),
                                       (_('Unpause shown'), self.unpauseShown), (_('Pause all'), self.pauseAll),
                                       (_('Unpause all'), self.unpauseAll)])

    def showHideSetTextMagic(self):
        list_type = self.list_type
        if list_type == LIST_TYPE_ALL:
            self['all_sel'].show()
            self['downloading_sel'].hide()
            self['seeding_sel'].hide()
            self['key_yellow'].setText(_('Seeding'))
            self['key_blue'].setText(_('Download'))
        elif list_type == LIST_TYPE_DOWNLOADING:
            self['all_sel'].hide()
            self['downloading_sel'].show()
            self['seeding_sel'].hide()
            self['key_yellow'].setText(_('All'))
            self['key_blue'].setText(_('Seeding'))
        else:
            self['all_sel'].hide()
            self['downloading_sel'].hide()
            self['seeding_sel'].show()
            self['key_yellow'].setText(_('Download'))
            self['key_blue'].setText(_('All'))

    def prevlist(self):
        self.timer.stop()
        list_type = self.list_type
        if list_type == LIST_TYPE_ALL:
            self.list_type = LIST_TYPE_SEEDING
        elif list_type == LIST_TYPE_DOWNLOADING:
            self.list_type = LIST_TYPE_ALL
        else:
            self.list_type = LIST_TYPE_DOWNLOADING
        self.showHideSetTextMagic()
        self.updateList()

    def nextlist(self):
        self.timer.stop()
        list_type = self.list_type
        if list_type == LIST_TYPE_ALL:
            self.list_type = LIST_TYPE_DOWNLOADING
        elif list_type == LIST_TYPE_DOWNLOADING:
            self.list_type = LIST_TYPE_SEEDING
        else:
            self.list_type = LIST_TYPE_ALL
        self.showHideSetTextMagic()
        self.updateList()

    def prevItem(self):
        self['list'].selectPrevious()
        cur = self['list'].getCurrent()
        return cur and cur[0]

    def nextItem(self):
        self['list'].selectNext()
        cur = self['list'].getCurrent()
        return cur and cur[0]

    def bandwidth(self):
        if self.transmission is None:
            return
        self.timer.stop()
        try:
            sess = self.transmission.get_session()
            rpc_version = self.transmission.rpc_version
        except TransmissionError as te:
            self.session.open(MessageBox, _('Error communicating with transmission-daemon: %s.') % te,
                              type=MessageBox.TYPE_ERROR, timeout=5)
            self.updateList()
        else:
            self.session.openWithCallback(self.bandwidthCallback, EmissionBandwidth.EmissionBandwidth, sess, False,
                                          rpc_version)

    def configureCallback(self):
        try:
            self.transmission = Client(host=config.plugins.emission.hostname.value,
                                       port=config.plugins.emission.port.value,
                                       username=config.plugins.emission.username.value,
                                       password=config.plugins.emission.password.value)
        except TransmissionError as te:
            self.transmission = None
            self.session.open(MessageBox, _('Error communicating with transmission-daemon: %s.') % te,
                              type=MessageBox.TYPE_ERROR, timeout=5)
        else:
            self.updateList()

    def updateList(self, *args, **kwargs):
        if self.transmission is None:
            return
        try:
            torrents = list(self.transmission.get_torrents())
            session = self.transmission.session_stats()
        except TransmissionError:
            self['list'].setList([])
            self['torrents'].setText('')
            self['upspeed'].setText('')
            self['downspeed'].setText('')
        else:
            sort_type = self.sort_type
            if sort_type == SORT_TYPE_TIME:
                torrents.sort(key=lambda x: (x.fields['eta'], x.progress), reverse=True)
            elif sort_type == SORT_TYPE_PROGRESS:
                torrents.sort(key=lambda x: x.progress, reverse=True)
            elif sort_type == SORT_TYPE_SPEED:
                torrents.sort(key=lambda x: (x.rateDownload, x.rateUpload), reverse=True)
        list_type = self.list_type
        if list_type == LIST_TYPE_ALL:
            filtered_torrents = torrents
        elif list_type == LIST_TYPE_DOWNLOADING:
            filtered_torrents = [x for x in torrents if x.status == 'downloading']
        else:
            filtered_torrents = [x for x in torrents if x.status == 'seeding']
        lst = [(x, x.name, str(x.eta or 'Downloaded or Stopped'), int(x.progress if x.progress is not None else 0)) for x in filtered_torrents]
        logdata('Populated list', lst)
        self['torrents'].setText(_('Active Torrents: %d/%d') % (session.active_torrent_count, session.torrent_count))
        self['upspeed'].setText(_('Upload: %d kb/s') % (session.upload_speed // 1024))
        self['downspeed'].setText(_('Download: %d kb/s') % (session.download_speed // 1024))
        index = min(self['list'].index, len(lst) - 1)
        self['list'].setList(lst)
        self['list'].index = index
        self.list = lst
        self.timer.startLongTimer(10)

    def ok(self):
        cur = self['list'].getCurrent()
        logdata('Selected item ok', cur)
        if self.transmission is not None and cur:
            self.timer.stop()
            self.session.openWithCallback(self.updateList, EmissionDetailview.EmissionDetailview, self.transmission,
                                          cur[0], self.prevItem, self.nextItem)

    def showPoster(self):
        selected_item = self['list'].getCurrent()
        if selected_item and isinstance(selected_item, tuple) and (len(selected_item) > 1):
            torrent_name = selected_item[1]
            if torrent_name:
                torrent_name_cleaned = re.sub('\\[.*?\\]', '', torrent_name).strip()
                torrentx = torrent_name_cleaned.replace('Torrent', '').strip()
                titles = torrentx.replace(' ', '')
                title = titles.replace('.', '').replace('"', '').replace(' ', '').lower()
                poster_file = '%s/%s.jpg' % (self.poster_directory, title)
                poster_file_default = '%s/default.svg' % self.darwin_directory
                if os.path.exists(poster_file):
                    self['poster'].instance.setPixmapFromFile(poster_file)
                    self['poster'].show()
                else:
                    self['poster'].instance.setPixmapFromFile(poster_file_default)
                    self['poster'].hide()
            else:
                self['poster'].hide()
        else:
            logdata('Selected item is invalid or not a tuple with enough elements: {}'.format(selected_item))
            self['poster'].hide()

    def info(self):
        self.session.open(MovieScreen, '/media/hdd/movies/movies.json')

    def close(self):
        self.timer.stop()
        config.plugins.emission.last_tab.value = self.list_type
        config.plugins.emission.last_tab.save()
        Screen.close(self)


__all__ = ['LIST_TYPE_ALL', 'LIST_TYPE_DOWNLOADING', 'LIST_TYPE_SEEDING', 'EmissionOverview', 'SORT_TYPE_TIME',
           'SORT_TYPE_PROGRESS', 'SORT_TYPE_ADDED', 'SORT_TYPE_SPEED']
