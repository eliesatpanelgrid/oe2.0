from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Plugins.Plugin import PluginDescriptor
import requests, re
def get_name(s):
 try:
  n=s.nav.getCurrentService().info().getName().strip()
  return n if n else "Movie"
 except: return "Movie"
def clean(t): return re.sub("<[^>]+>","",t).strip()
def tr(txt,l):
 try:
  txt=txt[:450]
  u="https://api.mymemory.translated.net/get?q=%s&langpair=en|%s"%(requests.utils.quote(txt),l)
  r=requests.get(u,timeout=8).json()
  return r.get("responseData",{}).get("translatedText","")
 except: return ""
def fetch(m,lg):
 try:
  q=requests.utils.quote(m)
  r=requests.get("https://api.tvmaze.com/search/shows?q=%s"%q,timeout=8).json()
  en=clean(r[0]['show'].get('summary',''))[:700] if r else m
  if lg=="en": return en
  t=tr(en,lg); return t or en
 except Exception as e: return str(e)
def main(session,**k):
 raw=get_name(session); cl=re.sub(r"\b(HD|FHD|UHD)\b","",raw,flags=re.I).strip() or "Movie"
 def cb(c):
  if not c: return
  session.open(MessageBox, fetch(cl,c[1]), MessageBox.TYPE_INFO)
 session.openWithCallback(cb, ChoiceBox, title="Film: %s"%cl, list=[("Arabic","ar"),("Francais","fr"),("English","en")])
def Plugins(**k): return [PluginDescriptor(name="Hamza Movie Summary",description="V10 Icon Fixed",where=PluginDescriptor.WHERE_PLUGINMENU,icon="plugin.png",fnc=main)]
