# -*- coding: utf-8 -*-
# HamzaMovie V3.0 GOLD - by Hamza Mellab
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
import re, threading, json, ssl, urllib.request, urllib.parse
try: ssl._create_default_https_context = ssl._create_unverified_context
except: pass

__version__ = "3.0"
__author__ = "Hamza Mellab"

def translate_ar(text):
    try:
        q=urllib.parse.quote(text[:450])
        url=f"https://api.mymemory.translated.net/get?q={q}&langpair=en|ar"
        ctx=ssl._create_unverified_context()
        data=json.loads(urllib.request.urlopen(url,timeout=5,context=ctx).read().decode('utf-8'))
        tr=data.get("responseData",{}).get("translatedText","")
        if tr and len(tr)>10 and "MYMEMORY WARNING" not in tr: return tr
    except: pass
    return text

def get_name():
    try:
        from Screens.InfoBar import InfoBar
        ev=InfoBar.instance.session.nav.getCurrentService().info().getEvent(0).getEventName()
        clean=re.sub(r'\(.*?\)|\[.*?\]|HD|MIX|MBC|KSA|VF|VOST|TRUEFRENCH','',ev,flags=re.I).strip()
        return ev.strip(), clean
    except: return "Film","Film"

def main(session, **k):
    orig, clean=get_name()
    def run():
        plot_en=""
        try:
            q=urllib.parse.quote(clean); ctx=ssl._create_unverified_context()
            url=f"http://www.omdbapi.com/?apikey=thewdb&t={q}&plot=short&r=json"
            d=json.loads(urllib.request.urlopen(url,timeout=6,context=ctx).read().decode('utf-8'))
            if d.get("Response")=="True": plot_en=d.get("Plot","")
        except: pass
        if not plot_en or plot_en=="N/A": plot_ar=f"قصة فيلم {clean} مشوقة ومليئة بالاكشن - by Hamza Mellab"
        else:
            plot_ar=translate_ar(plot_en)
            if len(plot_ar)>250: plot_ar=plot_ar[:247]+"..."
        from twisted.internet import reactor
        reactor.callFromThread(lambda: session.open(MessageBox, f"{orig}\n\n{plot_ar}\n\n--- HamzaMovie V3.0 GOLD ---", MessageBox.TYPE_INFO))
    session.open(MessageBox, f"كنقلب على: {clean} ...", MessageBox.TYPE_INFO, timeout=1)
    threading.Thread(target=run,daemon=True).start()

def Plugins(**k):
    return [PluginDescriptor(name="HamzaMovie V3.0 GOLD", description="by Hamza Mellab - ترجمة عربية + بوستر", where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main),
            PluginDescriptor(name="HamzaMovie V3.0 GOLD", where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon="plugin.png", fnc=main)]
